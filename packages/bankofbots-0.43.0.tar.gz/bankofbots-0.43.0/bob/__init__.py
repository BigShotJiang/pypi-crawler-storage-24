"""Bank of Bots Python SDK."""

from .client import BoBClient
from .exceptions import AuthenticationError, BoBError, ForbiddenError, NotFoundError
from .passport import Passport, PassportCredentialSubject, PassportStatus, PassportTrust, verify_passport, verify_passport_jwt, decode_passport_jwt
from .types import (
    APIKeyRecord,
    Agent,
    AgentCreditResponse,
    AgentWallet,
    CompatibilityResult,
    CreditEvent,
    CreditLimitResponse,
    CurrencyBalance,
    CurrencyLimit,
    DirectoryEntry,
    HistoricalPaymentProofImport,
    InboxEvent,
    LoanEligibility,
    PublicAgentMessage,
    ProofCreditOutcome,
    WebhookSubscriber,
)

__all__ = [
    "BoBClient",
    "APIKeyRecord",
    "Agent",
    "AgentCreditResponse",
    "AgentWallet",
    "CompatibilityResult",
    "CreditEvent",
    "CreditLimitResponse",
    "CurrencyBalance",
    "CurrencyLimit",
    "DirectoryEntry",
    "HistoricalPaymentProofImport",
    "InboxEvent",
    "LoanEligibility",
    "PublicAgentMessage",
    "ProofCreditOutcome",
    "WebhookSubscriber",
    "BoBError",
    "AuthenticationError",
    "ForbiddenError",
    "NotFoundError",
    "Passport",
    "PassportStatus",
    "PassportTrust",
    "verify_passport",
]
