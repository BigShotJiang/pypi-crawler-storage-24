"""Tests for enhanced security guardrails.

These tests demonstrate the additional safety features in tools.py.
Run with: pytest tests/test_enhanced_guardrails.py
"""

import tempfile
from pathlib import Path

import pytest


@pytest.fixture
def temp_repo(monkeypatch):
    """Create a temporary repository for testing."""
    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir_path = Path(tmpdir)

        # Create test files
        (tmpdir_path / "normal.txt").write_text("normal file")
        (tmpdir_path / "large.txt").write_text("x" * (11 * 1024 * 1024))  # 11MB
        (tmpdir_path / ".env").write_text("SECRET_KEY=abc123")
        (tmpdir_path / "package.json").write_text('{"name": "test"}')

        # Create binary file
        (tmpdir_path / "binary.bin").write_bytes(b"\x00\x01\x02\x03")

        # Monkey-patch REPO_ROOT
        import patchpal.tools.common

        monkeypatch.setattr(patchpal.tools.common, "REPO_ROOT", tmpdir_path)

        # Disable permission prompts during tests
        monkeypatch.setenv("PATCHPAL_REQUIRE_PERMISSION", "false")

        yield tmpdir_path


class TestSensitiveFileProtection:
    """Test sensitive file detection and blocking."""

    def test_blocks_env_file_access(self, temp_repo):
        """Test that .env files are blocked by default."""
        from patchpal.tools import read_file

        with pytest.raises(ValueError, match="sensitive file"):
            read_file(".env")

    def test_blocks_credentials_file(self, temp_repo, monkeypatch):
        """Test that credential files are blocked."""
        from patchpal.tools import read_file

        (temp_repo / "credentials.json").write_text('{"key": "secret"}')

        with pytest.raises(ValueError, match="sensitive file"):
            read_file("credentials.json")

    def test_allows_with_override(self, temp_repo, monkeypatch):
        """Test that ALLOW_SENSITIVE override works."""
        # Monkeypatch the config property
        monkeypatch.setenv("PATCHPAL_ALLOW_SENSITIVE", "true")

        from patchpal.tools import read_file

        content = read_file(".env")
        assert "SECRET_KEY" in content


class TestFileSizeLimits:
    """Test file size restrictions."""

    def test_blocks_large_file_read(self, temp_repo):
        """Test that files over size limit are blocked."""
        from patchpal.tools import read_file

        with pytest.raises(ValueError, match="too large"):
            read_file("large.txt")

    def test_blocks_large_file_write(self, temp_repo):
        """Test that writing large content is blocked."""
        from patchpal.tools import write_file

        large_content = "x" * (11 * 1024 * 1024)

        with pytest.raises(ValueError, match="too large"):
            write_file("output.txt", large_content)

    def test_allows_normal_size_file(self, temp_repo):
        """Test that normal-sized files work."""
        from patchpal.tools import read_file

        content = read_file("normal.txt")
        assert content == "normal file"


class TestBinaryFileDetection:
    """Test binary file handling."""

    def test_blocks_binary_file_read(self, temp_repo):
        """Test that binary files are blocked."""
        from patchpal.tools import read_file

        with pytest.raises(ValueError, match="binary file"):
            read_file("binary.bin")

    def test_allows_text_file(self, temp_repo):
        """Test that text files are allowed."""
        from patchpal.tools import read_file

        content = read_file("normal.txt")
        assert content == "normal file"


class TestCriticalFileWarnings:
    """Test warnings for critical files."""

    def test_warns_on_package_json_modify(self, temp_repo):
        """Test that modifying package.json shows warning."""
        from patchpal.tools import write_file

        result = write_file("package.json", '{"name": "modified"}')
        assert "WARNING" in result
        assert "critical" in result.lower()

    def test_no_warning_on_normal_file(self, temp_repo):
        """Test that normal files don't show warning."""
        from patchpal.tools import write_file

        result = write_file("normal.txt", "modified content")
        assert "WARNING" not in result


class TestReadOnlyMode:
    """Test read-only mode."""

    def test_blocks_writes_in_readonly(self, temp_repo, monkeypatch):
        """Test that writes are blocked in read-only mode."""
        # Monkeypatch the config property via environment variable
        monkeypatch.setenv("PATCHPAL_READ_ONLY", "true")

        from patchpal.tools import write_file

        with pytest.raises(ValueError, match="read-only mode"):
            write_file("test.txt", "content")

    def test_allows_reads_in_readonly(self, temp_repo, monkeypatch):
        """Test that reads work in read-only mode."""
        # Monkeypatch the config property via environment variable
        monkeypatch.setenv("PATCHPAL_READ_ONLY", "true")

        from patchpal.tools import read_file

        content = read_file("normal.txt")
        assert content == "normal file"


class TestCommandSafety:
    """Test enhanced command safety."""

    def test_blocks_dangerous_patterns(self, temp_repo):
        """Test that dangerous command patterns are blocked."""
        import platform

        from patchpal.tools import run_shell

        if platform.system() == "Windows":
            dangerous_commands = [
                "echo test > \\\\.\\PhysicalDrive0",  # Writing to device
                "cat file | dd of=output",  # Piping to dd
                "echo test | shred",  # Piping to shred
                "mkfs.ext4 /dev/sda1",  # Format filesystem
                ":(){:|:&};:",  # Fork bomb
            ]
        else:
            dangerous_commands = [
                "echo test > /dev/sda",
                "rm -rf /",
                "cat file | dd of=/dev/sda",
                "echo test | sudo tee /etc/test",  # Piping to sudo
            ]

        for cmd in dangerous_commands:
            with pytest.raises(ValueError, match="dangerous"):
                run_shell(cmd)

    def test_allows_safe_commands(self, temp_repo):
        """Test that safe commands work."""
        from patchpal.tools import run_shell

        result = run_shell("echo 'test'")
        assert "test" in result

    def test_command_timeout(self, temp_repo, monkeypatch):
        """Test that long-running commands timeout."""
        import sys

        # Skip on Windows - subprocess timeout with shell=True doesn't work reliably
        if sys.platform == "win32":
            pytest.skip("Subprocess timeout with shell=True unreliable on Windows")

        # Monkeypatch the config property via environment variable
        monkeypatch.setenv("PATCHPAL_SHELL_TIMEOUT", "2")

        import subprocess

        from patchpal.tools import run_shell

        if sys.platform == "win32":
            # Windows: timeout command (but we use Python for better cross-platform consistency)
            sleep_cmd = f'{sys.executable} -c "import time; time.sleep(10)"'
        else:
            # Unix/Linux/macOS: sleep command
            sleep_cmd = "sleep 10"

        with pytest.raises(subprocess.TimeoutExpired):
            run_shell(sleep_cmd)


class TestPathTraversal:
    """Test path access security model (matches Claude Code approach).

    - Read operations: Allowed anywhere (system files, libraries, etc.)
    - Write operations: Restricted to repository unless permission granted
    """

    def test_allows_reading_parent_directories(self, temp_repo):
        """Test that read operations can access parent directories."""
        from patchpal.tools import read_file

        # Create a file in parent directory for testing
        outside_file = temp_repo.parent / "test_file.txt"
        outside_file.write_text("outside content")

        try:
            # Should now allow reading files outside repository
            content = read_file(str(outside_file))
            assert content == "outside content"
        finally:
            outside_file.unlink()

    def test_allows_reading_absolute_paths(self, temp_repo):
        """Test that read operations can access absolute paths."""
        # Create a temp file with absolute path
        import tempfile

        from patchpal.tools import read_file

        with tempfile.NamedTemporaryFile(mode="w", delete=False, suffix=".txt") as f:
            f.write("absolute path content")
            temp_path = f.name

        try:
            content = read_file(temp_path)
            assert content == "absolute path content"
        finally:
            Path(temp_path).unlink()

    def test_blocks_writing_outside_repository(self, temp_repo, monkeypatch):
        """Test that write operations outside repository are blocked/require permission."""
        from pathlib import Path

        # Import modules
        import patchpal.permissions
        import patchpal.tools

        # Ensure writes are enabled via environment variable
        monkeypatch.setenv("PATCHPAL_READ_ONLY", "false")

        # Reset cached permission managers
        patchpal.permissions._permission_manager = None
        patchpal.tools.common._permission_manager = None

        # Patch REPO_ROOT
        repo_root = Path(temp_repo).resolve()
        monkeypatch.setattr(patchpal.tools.common, "REPO_ROOT", repo_root)

        # Mock permission request to deny access
        def mock_request_permission(
            self, tool_name, description, pattern=None, context=None, full_command=None
        ):
            return False  # Deny permission

        monkeypatch.setattr(
            patchpal.permissions.PermissionManager, "request_permission", mock_request_permission
        )

        from patchpal.tools import write_file

        # Try to write to parent directory
        outside_path = repo_root.parent / "test_write.txt"

        # Should be blocked - permission denied returns a cancellation message
        result = write_file(str(outside_path), "malicious content")
        assert "cancelled" in result.lower()

    def test_blocks_editing_outside_repository(self, temp_repo, monkeypatch):
        """Test that edit operations outside repository are blocked/require permission."""
        from pathlib import Path

        # Import modules
        import patchpal.permissions
        import patchpal.tools

        # Ensure writes are enabled via environment variable
        monkeypatch.setenv("PATCHPAL_READ_ONLY", "false")

        # Reset cached permission managers
        patchpal.permissions._permission_manager = None
        patchpal.tools.common._permission_manager = None

        # Patch REPO_ROOT
        repo_root = Path(temp_repo).resolve()
        monkeypatch.setattr(patchpal.tools.common, "REPO_ROOT", repo_root)

        # Mock permission request to deny access
        def mock_request_permission(
            self, tool_name, description, pattern=None, context=None, full_command=None
        ):
            return False  # Deny permission

        monkeypatch.setattr(
            patchpal.permissions.PermissionManager, "request_permission", mock_request_permission
        )

        from patchpal.tools import edit_file

        # Create a file outside repo to try editing
        outside_file = repo_root.parent / "test_edit.txt"
        outside_file.write_text("original content")

        try:
            # Should be blocked - permission denied returns a cancellation message
            result = edit_file(str(outside_file), "original", "modified")
            assert "cancelled" in result.lower()
        finally:
            if outside_file.exists():
                outside_file.unlink()

    def test_allows_reading_symlink_outside_repo(self, temp_repo):
        """Test that symlinks pointing outside repo can be read."""
        import sys

        # Skip on Windows unless running with admin privileges (symlinks require special permissions)
        if sys.platform == "win32":
            pytest.skip("Symlink creation requires admin privileges on Windows")

        from patchpal.tools import read_file

        # Create file outside repo and symlink to it
        outside_file = temp_repo.parent / "outside.txt"
        outside_file.write_text("outside content")

        symlink = temp_repo / "link.txt"
        symlink.symlink_to(outside_file)

        try:
            # Should now allow reading via symlink
            content = read_file("link.txt")
            assert content == "outside content"
        finally:
            symlink.unlink()
            outside_file.unlink()


class TestConfigurability:
    """Test configuration via environment variables."""

    def test_custom_max_file_size(self, temp_repo, monkeypatch):
        """Test that MAX_FILE_SIZE can be configured."""
        # Monkeypatch the config property via environment variable
        monkeypatch.setenv("PATCHPAL_MAX_FILE_SIZE", "1000")

        # Should now block even small files
        (temp_repo / "medium.txt").write_text("x" * 2000)

        from patchpal.tools import read_file

        with pytest.raises(ValueError, match="too large"):
            read_file("medium.txt")


# Summary test to demonstrate all guardrails
def test_comprehensive_security_demo(temp_repo, monkeypatch):
    """Comprehensive test showing all security features (reload-free)."""
    import sys
    from pathlib import Path

    import pytest

    ## If this test is flaky in CI, skip explicitly
    # if os.getenv("CI"):
    # pytest.skip("Known module-global state issues in CI")

    # ----------------------------
    # Mock permission request
    # ----------------------------
    def mock_request_permission(
        self, tool_name, description, pattern=None, context=None, full_command=None
    ):
        # Deny write operations for paths outside repo
        if tool_name in ("write_file", "edit_file") and pattern:
            if pattern.endswith("/"):  # outside repo
                return False
            return True
        return True

    # ----------------------------
    # Environment configuration
    # ----------------------------
    monkeypatch.setenv("PATCHPAL_REQUIRE_PERMISSION", "true")
    monkeypatch.setenv("PATCHPAL_READ_ONLY", "false")

    # ----------------------------
    # Import modules (once)
    # ----------------------------
    import patchpal.permissions
    import patchpal.tools
    import patchpal.tools.common

    # ----------------------------
    # Reset all cached globals
    # ----------------------------
    patchpal.permissions._permission_manager = None
    patchpal.tools.common._permission_manager = None

    # ----------------------------
    # Patch REPO_ROOT (normalized)
    # ----------------------------
    repo_root = Path(temp_repo).resolve()
    monkeypatch.setattr(patchpal.tools.common, "REPO_ROOT", repo_root)

    # ----------------------------
    # Patch permission manager BEFORE use
    # ----------------------------
    monkeypatch.setattr(
        patchpal.permissions.PermissionManager,
        "request_permission",
        mock_request_permission,
    )

    # ----------------------------
    # Access functions via module
    # ----------------------------
    read_file = patchpal.tools.read_file
    write_file = patchpal.tools.write_file
    run_shell = patchpal.tools.run_shell

    # ----------------------------
    # 1. Normal operations
    # ----------------------------
    content = read_file("normal.txt")
    assert content == "normal file"

    result = write_file("test.txt", "new content")
    assert "success" in result.lower()

    output = run_shell(
        f"{sys.executable} -c \"import os; print('normal.txt' if os.path.exists('normal.txt') else 'not found')\""
    )
    assert "normal.txt" in output

    # Test file listing with run_shell (replaces grep/get_file_info tests)
    import shutil

    if shutil.which("ls") or sys.platform == "win32":
        # Use ls on Unix or dir on Windows
        cmd = "ls *.txt" if shutil.which("ls") else "dir /b *.txt"
        result = run_shell(cmd)
        assert "normal.txt" in result

    # ----------------------------
    # 2. Sensitive files blocked
    # ----------------------------
    with pytest.raises(ValueError):
        read_file(".env")

    # ----------------------------
    # 3. Large files blocked
    # ----------------------------
    with pytest.raises(ValueError):
        read_file("large.txt")

    # ----------------------------
    # 4. Binary files blocked
    # ----------------------------
    with pytest.raises(ValueError):
        read_file("binary.bin")

    # ----------------------------
    # 5. Critical files warned
    # ----------------------------
    result = write_file("package.json", '{"modified": true}')
    assert "warning" in result.lower()

    # ----------------------------
    # 6. Dangerous commands blocked
    # ----------------------------
    import platform

    if platform.system() == "Windows":
        # Use Windows-specific dangerous pattern
        with pytest.raises(ValueError):
            run_shell("cat file | dd of=output")
    else:
        with pytest.raises(ValueError):
            run_shell("rm -rf /")

    # ----------------------------
    # 7. Outside-repo writes blocked
    # ----------------------------
    outside_path = repo_root.parent / "test_outside.txt"
    result = write_file(str(outside_path), "test")
    assert "cancel" in result.lower()

    print("✅ All security guardrails working correctly!")


# def test_comprehensive_security_demo(temp_repo, monkeypatch):
# """Comprehensive test showing all security features."""
# import os
# import sys

## Skip on Windows/macOS in CI/CD environments due to module reload issues
## The test passes locally but fails in CI/CD for unknown reasons
## Issue tracked: module reload with monkeypatching behaves differently in CI
# if sys.platform in ("win32", "darwin") and os.getenv("CI"):
# pytest.skip("Module reload issues in CI/CD environment on Windows/macOS")

## Mock permission request to deny only for outside-repo writes

# def mock_request_permission(self, tool_name, description, pattern=None, context=None, full_command=None):
## Only deny write operations (write_file/edit_file) for paths outside repo
# if tool_name in ("write_file", "edit_file") and pattern:
## New pattern format: directory-based (e.g., "tmp/") for files outside repo
## Inside repo uses relative path (e.g., "src/app.py")

## If pattern ends with "/", it's a directory pattern for outside repo
# if pattern.endswith("/"):
## Outside repo - deny
# return False

## Otherwise it's a relative path inside repo - allow
# return True
## Allow everything else by returning True or checking original behavior
# return True

## Enable permissions but set up mock
# monkeypatch.setenv("PATCHPAL_REQUIRE_PERMISSION", "true")
# monkeypatch.setenv("PATCHPAL_READ_ONLY", "false")  # Ensure writes are allowed

# import importlib

# import patchpal.permissions
# import patchpal.tools

## Re-patch REPO_ROOT BEFORE reload so PATCHPAL_DIR is calculated correctly
# monkeypatch.setattr("patchpal.tools.common.REPO_ROOT", temp_repo)

## Reload modules to pick up the new env var
# importlib.reload(patchpal.permissions)
# importlib.reload(patchpal.tools)

## Re-patch REPO_ROOT again after reload (gets reset during reload)
# monkeypatch.setattr("patchpal.tools.common.REPO_ROOT", temp_repo)

## Reset the cached permission manager BEFORE importing functions
# patchpal.tools._permission_manager = None

## Mock the request_permission method BEFORE importing
# monkeypatch.setattr(
# patchpal.permissions.PermissionManager, "request_permission", mock_request_permission
# )

# from patchpal.tools import write_file, list_files, read_file, run_shell

## 1. Normal operations work
# content = read_file("normal.txt")
# assert content == "normal file"

# result = write_file("test.txt", "new content")
# assert "Successfully updated" in result

## Test shell command (use cross-platform Python instead of ls)
# import sys

# output = run_shell(
# f"{sys.executable} -c \"import os; print('normal.txt' if os.path.exists('normal.txt') else 'not found')\""
# )
# assert "normal.txt" in output

# files = list_files()
# assert "normal.txt" in files

## 2. Sensitive files blocked
# with pytest.raises(ValueError, match="sensitive"):
# read_file(".env")

## 3. Large files blocked
# with pytest.raises(ValueError, match="too large"):
# read_file("large.txt")

## 4. Binary files blocked
# with pytest.raises(ValueError, match="binary"):
# read_file("binary.bin")

## 5. Critical files warned
# result = write_file("package.json", '{"modified": true}')
# assert "WARNING" in result

## 6. Dangerous commands blocked
# with pytest.raises(ValueError, match="dangerous"):
# run_shell("rm -rf /")

## 7. Write operations outside repo blocked
# outside_path = temp_repo.parent / "test_outside.txt"
# result = write_file(str(outside_path), "test")
# assert "cancelled" in result.lower()

# print("✅ All security guardrails working correctly!")
