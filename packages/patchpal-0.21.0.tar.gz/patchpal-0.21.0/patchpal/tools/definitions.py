"""Tool definitions for PatchPal agent.

This module contains the tool schemas (in LiteLLM format) and the mapping
from tool names to their implementation functions.
"""

from patchpal.config import config
from patchpal.tools import (
    ask_user,
    code_structure,
    edit_file,
    get_repo_map,
    grep,
    list_files,
    list_skills,
    read_file,
    read_lines,
    run_shell,
    todo_add,
    todo_clear,
    todo_complete,
    todo_list,
    todo_remove,
    todo_update,
    use_skill,
    web_fetch,
    web_search,
    write_file,
)
from patchpal.tools.mcp import load_mcp_tools

# Define tools in LiteLLM format
TOOLS = [
    {
        "type": "function",
        "function": {
            "name": "read_file",
            "description": "Read the contents of a file. Can read files anywhere on the system (repository files, system configs like /etc/fstab, logs, etc.) for automation and debugging. Supports text files, images (PNG, JPG, GIF, etc.), and documents (PDF, DOCX, PPTX) with automatic format detection. Images are returned as base64 data URLs for vision model analysis. Sensitive files (.env, credentials) are blocked for safety.",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string",
                        "description": "Path to the file - can be relative to repository root or an absolute path (e.g., /etc/fstab, /var/log/app.log)",
                    }
                },
                "required": ["path"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "read_lines",
            "description": "Read specific lines from a file without loading the entire file. Useful for viewing code sections, error context, or specific regions of large files. More efficient than read_file when you only need a few lines.",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string",
                        "description": "Path to the file - can be relative to repository root or an absolute path",
                    },
                    "start_line": {
                        "type": "integer",
                        "description": "Starting line number (1-indexed)",
                    },
                    "end_line": {
                        "type": "integer",
                        "description": "Ending line number (inclusive, 1-indexed). If omitted, reads only start_line",
                    },
                },
                "required": ["path", "start_line"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "code_structure",
            "description": "Analyze code structure using tree-sitter AST parsing without reading the full file. Returns a compact overview showing functions, classes, methods with their line numbers and signatures. Supports 40+ languages including Python, JavaScript, TypeScript, Go, Rust, Java, C/C++. Use this INSTEAD OF read_file when you need structure overview but not implementation details (e.g., finding function names, understanding file organization). For exploring multiple files or getting oriented in a codebase, use get_repo_map instead—it's much more efficient than calling code_structure on each file individually.",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string",
                        "description": "Path to the code file to analyze - can be relative to repository root or absolute path",
                    },
                    "max_symbols": {
                        "type": "integer",
                        "description": "Maximum number of symbols (functions/classes) to show (default: 50)",
                    },
                },
                "required": ["path"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "get_repo_map",
            "description": """Generate a repository map showing code structure across the entire codebase.

This provides a consolidated view of ALL files in the repository, showing function and class
signatures without implementations. More efficient than calling code_structure on each file individually.

Use this when you need to:
- Understand the overall codebase structure
- Find relevant files without analyzing them all
- Discover related code across the project
- Get oriented in an unfamiliar codebase

Supports 20+ languages: Python, JavaScript, TypeScript, Go, Rust, Java, C/C++, C#, Ruby,
PHP, Swift, Kotlin, Scala, Elm, Elixir, and more. Language detection is automatic.

Token efficiency: 38-70% reduction compared to calling code_structure on each file
(e.g., 20 files: 4,916 tokens vs 1,459 tokens = 70% savings; 37 files: 8,052 tokens vs 4,988 tokens = 38% savings)
Combines multiple file structures into one compact output with reduced redundant formatting.

Tip: Read README first for context when exploring repositories.""",
            "parameters": {
                "type": "object",
                "properties": {
                    "max_files": {
                        "type": "integer",
                        "description": "Maximum number of files to include in the map (default: 100)",
                    },
                    "include_patterns": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "Glob patterns to include (e.g., ['*.py', 'src/**/*.js']). If specified, only matching files are included.",
                    },
                    "exclude_patterns": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "Glob patterns to exclude (e.g., ['*test*', '*_pb2.py', 'vendor/**']). Useful for filtering out generated code, tests, or dependencies.",
                    },
                    "focus_files": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "Files to prioritize in the output (e.g., files mentioned in conversation). These appear first in the map.",
                    },
                },
                "required": [],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "edit_file",
            "description": "Edit a file by finding and replacing a code section. Handles indentation and whitespace differences automatically. Most efficient for small, targeted changes (1-20 lines). The search string should be unique within the file.",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string",
                        "description": "Path to the file - relative to repository root or absolute path",
                    },
                    "old_string": {
                        "type": "string",
                        "description": "The code section to find and replace (indentation is normalized automatically - focus on content uniqueness)",
                    },
                    "new_string": {
                        "type": "string",
                        "description": "The replacement code section",
                    },
                },
                "required": ["path", "old_string", "new_string"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "write_file",
            "description": "Write complete file contents from scratch. Overwrites existing files entirely or creates new ones. Use edit_file for small targeted changes. Use write_file for large-scale rewrites or creating new files. You MUST provide complete file content.",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string",
                        "description": "Path to the file - relative to repository root or absolute path",
                    },
                    "content": {
                        "type": "string",
                        "description": "Complete file content (entire file, not just changes)",
                    },
                },
                "required": ["path", "content"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "web_search",
            "description": "Search the web for information.",
            "parameters": {
                "type": "object",
                "properties": {
                    "query": {"type": "string", "description": "The search query"},
                    "max_results": {
                        "type": "integer",
                        "description": "Maximum number of results to return (default: 5, max: 10)",
                    },
                },
                "required": ["query"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "web_fetch",
            "description": "Fetch and read content from a URL. Supports text extraction from HTML, PDF, DOCX (Word), PPTX (PowerPoint), and plain text files.",
            "parameters": {
                "type": "object",
                "properties": {
                    "url": {
                        "type": "string",
                        "description": "The URL to fetch (must start with http:// or https://)",
                    },
                    "extract_text": {
                        "type": "boolean",
                        "description": "If true, extract readable text from HTML/PDF/DOCX/PPTX (default: true)",
                    },
                },
                "required": ["url"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "list_skills",
            "description": "List all available skills. When telling users about skills, instruct them to use /skillname syntax (e.g., /commit).",
            "parameters": {"type": "object", "properties": {}, "required": []},
        },
    },
    {
        "type": "function",
        "function": {
            "name": "use_skill",
            "description": "Invoke a skill programmatically when it's relevant to the user's request. Note: Users invoke skills via /skillname at the CLI, not by calling tools.",
            "parameters": {
                "type": "object",
                "properties": {
                    "skill_name": {
                        "type": "string",
                        "description": "Name of the skill to invoke (without / prefix)",
                    },
                    "args": {
                        "type": "string",
                        "description": "Optional arguments to pass to the skill",
                    },
                },
                "required": ["skill_name"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "todo_add",
            "description": "Add a new task to the TODO list. Use this to break down complex tasks into manageable subtasks. Essential for planning multi-step work.",
            "parameters": {
                "type": "object",
                "properties": {
                    "description": {
                        "type": "string",
                        "description": "Brief task description (one line)",
                    },
                    "details": {
                        "type": "string",
                        "description": "Optional detailed notes about the task",
                    },
                },
                "required": ["description"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "todo_list",
            "description": "List all tasks in the TODO list with their status and progress.",
            "parameters": {
                "type": "object",
                "properties": {
                    "show_completed": {
                        "type": "boolean",
                        "description": "If true, show completed tasks; if false, show only pending tasks (default: false)",
                    },
                },
                "required": [],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "todo_complete",
            "description": "Mark a task as completed.",
            "parameters": {
                "type": "object",
                "properties": {
                    "task_id": {
                        "type": "integer",
                        "description": "The ID of the task to complete",
                    },
                },
                "required": ["task_id"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "todo_update",
            "description": "Update a task's description or details.",
            "parameters": {
                "type": "object",
                "properties": {
                    "task_id": {
                        "type": "integer",
                        "description": "The ID of the task to update",
                    },
                    "description": {
                        "type": "string",
                        "description": "New description (optional)",
                    },
                    "details": {
                        "type": "string",
                        "description": "New details (optional)",
                    },
                },
                "required": ["task_id"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "todo_remove",
            "description": "Remove a task from the TODO list.",
            "parameters": {
                "type": "object",
                "properties": {
                    "task_id": {
                        "type": "integer",
                        "description": "The ID of the task to remove",
                    },
                },
                "required": ["task_id"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "todo_clear",
            "description": "Clear tasks from the TODO list (completed tasks only by default, or all tasks).",
            "parameters": {
                "type": "object",
                "properties": {
                    "completed_only": {
                        "type": "boolean",
                        "description": "If true, clear only completed tasks; if false, clear all tasks (default: true)",
                    },
                },
                "required": [],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "ask_user",
            "description": "Ask the user a question and wait for their response. Use this to clarify requirements, get decisions, or gather additional information during task execution.",
            "parameters": {
                "type": "object",
                "properties": {
                    "question": {
                        "type": "string",
                        "description": "The question to ask the user",
                    },
                    "options": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "Optional list of predefined answer choices (e.g., ['yes', 'no', 'skip']). User can select from these or provide custom answer.",
                    },
                },
                "required": ["question"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "run_shell",
            "description": "Run a shell command in the repository. Commands execute from repository root automatically (no need for 'cd'). Privilege escalation (sudo, su) and destructive patterns (rm -rf /, piping to dd, writing to /dev/) blocked by default unless PATCHPAL_ALLOW_SUDO=true.",
            "parameters": {
                "type": "object",
                "properties": {
                    "cmd": {"type": "string", "description": "The shell command to execute"}
                },
                "required": ["cmd"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "grep",
            "description": "Search for a pattern in files using grep or ripgrep. Useful for read-only agents that need search capabilities without run_shell access. Supports case-insensitive search, file globs, and path filtering.",
            "parameters": {
                "type": "object",
                "properties": {
                    "pattern": {
                        "type": "string",
                        "description": "Regular expression pattern to search for",
                    },
                    "file_glob": {
                        "type": "string",
                        "description": "Optional glob pattern to filter files (e.g., '*.py', 'src/**/*.js')",
                    },
                    "case_sensitive": {
                        "type": "boolean",
                        "description": "Whether the search should be case-sensitive (default: True)",
                    },
                    "max_results": {
                        "type": "integer",
                        "description": "Maximum number of results to return (default: 100)",
                    },
                    "path": {
                        "type": "string",
                        "description": "Optional file or directory path to search in (relative to repo root or absolute). Defaults to repository root.",
                    },
                },
                "required": ["pattern"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "list_files",
            "description": "List all files in the repository or a specific directory. Fast file listing without shell access or code parsing. Useful for read-only agents that need to explore repository structure.",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string",
                        "description": "Optional directory path to list (relative to repo root or absolute). Defaults to repository root.",
                    },
                    "include_hidden": {
                        "type": "boolean",
                        "description": "Whether to include hidden files/directories (default: False)",
                    },
                },
                "required": [],
            },
        },
    },
]

# Map tool names to functions
TOOL_FUNCTIONS = {
    "read_file": read_file,
    "read_lines": read_lines,
    "code_structure": code_structure,
    "get_repo_map": get_repo_map,
    "edit_file": edit_file,
    "write_file": write_file,
    "web_search": web_search,
    "web_fetch": web_fetch,
    "list_skills": list_skills,
    "use_skill": use_skill,
    "todo_add": todo_add,
    "todo_list": todo_list,
    "todo_complete": todo_complete,
    "todo_update": todo_update,
    "todo_remove": todo_remove,
    "todo_clear": todo_clear,
    "ask_user": ask_user,
    "run_shell": run_shell,
    "grep": grep,  # Optional tool
    "list_files": list_files,  # Optional tool
}


def get_tools(web_tools_enabled: bool = True):
    """Get the list of available tools, optionally filtering out web tools.

    Args:
        web_tools_enabled: Whether to include web_search and web_fetch tools

    Returns:
        Tuple of (tools_list, tool_functions_dict)
    """
    # Tools that are available but disabled by default
    # They can be enabled via enabled_tools parameter/env var
    disabled_by_default = ["grep", "list_files"]

    # Check if minimal tools mode is enabled (for local models with tool confusion)
    minimal_mode = config.MINIMAL_TOOLS

    if minimal_mode:
        # Base minimal tools (always included)
        minimal_tool_names = ["read_file", "read_lines", "edit_file", "write_file", "run_shell"]

        # Add web tools if enabled
        if web_tools_enabled:
            minimal_tool_names.extend(["web_search", "web_fetch"])

        tools = [tool for tool in TOOLS if tool["function"]["name"] in minimal_tool_names]
        functions = {
            name: func for name, func in TOOL_FUNCTIONS.items() if name in minimal_tool_names
        }

        return tools, functions

    # Start with built-in tools
    tools = TOOLS.copy()
    functions = TOOL_FUNCTIONS.copy()

    # Filter out disabled-by-default tools (can be enabled via enabled_tools)
    tools = [tool for tool in tools if tool["function"]["name"] not in disabled_by_default]
    # Note: Keep functions dict complete so enabled_tools can access them

    # Filter out web tools if disabled
    if not web_tools_enabled:
        tools = [
            tool for tool in tools if tool["function"]["name"] not in ("web_search", "web_fetch")
        ]
        functions = {k: v for k, v in functions.items() if k not in ("web_search", "web_fetch")}

    # Load MCP tools dynamically (unless disabled via environment variable)
    if config.ENABLE_MCP:
        try:
            mcp_tools, mcp_functions = load_mcp_tools()
            if mcp_tools:
                tools.extend(mcp_tools)
                functions.update(mcp_functions)
        except Exception as e:
            # Graceful degradation - MCP tools are optional
            print(f"Warning: Failed to load MCP tools: {e}")

    return tools, functions
