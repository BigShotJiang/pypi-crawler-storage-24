"""
CLI 入口

主入口模式：
  roborock-cli              → 显示帮助（CLI 为主）
  roborock-cli auth         → 交互式认证
  roborock-cli devices      → 列出设备
  roborock-cli status       → 获取状态
  ...
  roborock-cli mcp          → 启动 MCP stdio server（降级为子命令）
"""

import argparse
import logging
import sys

from . import __version__


def _setup_logging(debug: bool) -> None:
    """配置日志级别"""
    if debug:
        logging.basicConfig(
            level=logging.DEBUG,
            format="%(asctime)s %(levelname)-5s [%(name)s] %(message)s",
            datefmt="%H:%M:%S",
        )
    else:
        logging.basicConfig(level=logging.WARNING)


def main():
    parser = argparse.ArgumentParser(
        prog="roborock-cli",
        description="Roborock 扫地机控制工具",
        epilog="使用 'roborock-cli <command> --help' 查看子命令详情",
    )
    parser.add_argument("--version", "-V", action="version", version=f"%(prog)s {__version__}")
    parser.add_argument("--debug", action="store_true", help="启用调试日志（显示 MQTT 连接/重连/订阅详情）")
    subparsers = parser.add_subparsers(dest="command")

    # CLI 子命令（主入口）
    from .cli import add_cli_subparsers
    add_cli_subparsers(subparsers)

    # MCP 子命令（降级）
    mcp_parser = subparsers.add_parser("mcp", help="启动 MCP stdio server")
    mcp_parser.set_defaults(func=cmd_mcp)

    args = parser.parse_args()
    _setup_logging(args.debug)

    if args.command is None:
        # 无参数时显示帮助
        parser.print_help()
        sys.exit(0)
    elif hasattr(args, "func"):
        # 执行子命令
        from .cli import CLIError, format_error
        try:
            args.func(args)
        except CLIError as e:
            print(format_error(e))
            sys.exit(e.exit_code)
        except KeyboardInterrupt:
            sys.exit(130)
    else:
        parser.error(f"未知子命令: {args.command}")


def cmd_mcp(args):
    """启动 MCP stdio server"""
    import anyio
    from .server import mcp

    # Windows 的 ProactorEventLoop 不支持 add_reader/add_writer，
    # 而 aiomqtt (paho-mqtt) 依赖这些方法。
    # mcp.run() 内部调用 anyio.run() 但不传 loop_factory，
    # 所以直接调用 anyio.run() 显式指定 SelectorEventLoop。
    # MCP stdio transport 用 anyio.wrap_file()（线程模式），不受影响。
    if sys.platform == "win32":
        import asyncio
        backend_options = {"loop_factory": asyncio.SelectorEventLoop}
    else:
        backend_options = {}

    anyio.run(mcp.run_stdio_async, backend_options=backend_options)


if __name__ == "__main__":
    main()
