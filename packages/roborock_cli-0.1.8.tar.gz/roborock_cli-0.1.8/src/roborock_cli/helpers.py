"""
共享辅助函数，供 server.py 和 cli.py 使用
"""

import logging
from enum import Enum
from typing import Any

logger = logging.getLogger(__name__)


async def safe_refresh(trait, name: str) -> bool:
    """安全刷新单个 trait，失败不影响其他"""
    try:
        await trait.refresh()
        return True
    except Exception as e:
        logger.warning("Trait %s refresh 失败: %s", name, e)
        return False


def serialize_value(value: Any) -> Any:
    """将 Enum 等特殊类型转为可序列化值"""
    if value is None:
        return None
    if isinstance(value, Enum):
        return value.name
    if isinstance(value, list):
        return [serialize_value(v) for v in value]
    return value


def field(value: Any, description: str) -> dict[str, Any]:
    """包装字段值和描述"""
    return {"value": value, "description": description}


# StatusV2 白名单：仅输出有意义的字段
# state/error_code 改在 computed properties 中输出（避免与 state_name/error_code_name 重复）
STATUS_FIELDS: dict[str, str] = {
    # 核心状态
    "battery": "电池电量 (%)",
    "charge_status": "充电状态 (0=未充电, 1=充电中, 2=充电完成)",
    # 清洁进度
    "clean_percent": "清洁任务完成百分比 (%)",
    "in_cleaning": "清洁状态 (complete/global_clean_not_complete/zone_clean_not_complete/segment_clean_not_complete)",
    "in_returning": "是否在返回途中 (0=否, 1=是)",
    "avoid_count": "当前任务避障次数",
    "repeat": "当前任务重复遍数",
    # 地图
    "map_present": "是否有地图 (0=无, 1=有)",
    # 基座
    "dock_type": "基座类型 (no_dock/auto_empty_dock/empty_wash_fill_dock/p10_pro_dock 等)",
    "dock_error_status": "基座错误状态 (ok/duct_blockage/water_empty/waste_water_tank_full 等)",
    "dust_collection_status": "集尘状态 (0=未集尘, 1=集尘中)",
    "auto_dust_collection": "自动集尘开关 (0=关闭, 1=开启)",
    # 洗拖布/烘干
    "wash_status": "洗拖布状态 (0=空闲, 1=洗涤中)",
    "wash_phase": "洗拖布阶段 (0=空闲)",
    "wash_ready": "是否准备好洗拖布 (0=否, 1=是)",
    "dry_status": "热风烘干状态 (0=关闭, 1=烘干中)",
    # 水箱
    "water_box_status": "水箱安装状态 (0=未安装, 1=已安装)",
    "water_box_carriage_status": "水箱托架状态 (0=正常)",
    "water_shortage_status": "缺水状态 (0=正常)",
    # 其他
    "is_locating": "是否正在定位 (0=否, 1=是)",
    "lock_status": "童锁状态 (0=未锁定, 1=锁定)",
    "mop_forbidden_enable": "拖地禁区是否启用 (0=关闭, 1=启用)",
    "collision_avoid_status": "避障功能 (0=关闭, 1=开启)",
}
