"""Trait for wash towel mode."""

from roborock_cli._vendor.roborock.data import WashTowelMode
from roborock_cli._vendor.roborock.device_features import is_wash_n_fill_dock
from roborock_cli._vendor.roborock.devices.traits.v1 import common
from roborock_cli._vendor.roborock.roborock_typing import RoborockCommand


class WashTowelModeTrait(WashTowelMode, common.V1TraitMixin):
    """Trait for wash towel mode."""

    command = RoborockCommand.GET_WASH_TOWEL_MODE
    requires_dock_type = is_wash_n_fill_dock
