"""Reddit CLI."""

__version__ = "0.3.2"
