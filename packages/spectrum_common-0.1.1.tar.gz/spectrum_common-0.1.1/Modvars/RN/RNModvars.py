def init_modvars(countryID, first_year, final_year, extra):
    return {}