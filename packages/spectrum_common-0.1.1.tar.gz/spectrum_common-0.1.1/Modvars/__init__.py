"""SpectrumCommon model variables package."""
