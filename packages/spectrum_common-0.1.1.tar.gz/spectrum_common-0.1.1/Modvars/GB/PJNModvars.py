import uuid
from os import environ

from AvenirCommon.Database import GB_get_db_json

from SpectrumCommon.Const.GB import *
from SpectrumCommon.Const.PJ import *


def create_library_id():
    return uuid.uuid4().hex


def init_modvars(countryID, first_year, final_year, extra):
    subnatCode = extra.get(GB_Extra_SubnatCode, 0)
    subnatName = extra.get(GB_Extra_subnatName, '')

    projection_title = extra.get(GB_Extra_projection_title, '')
    modules = extra.get(GB_Extra_modules, '')
    author = extra.get(GB_Extra_Author, '')
    organization = extra.get(GB_Extra_organization, '')
    notes =  extra.get(GB_Extra_notes, '')
    appID = extra.get(GB_Extra_appID, '')
    library_id = create_library_id()

    LiST_costing_on = extra.get(GB_LIST_COSTING_ON, False)
    TB_costing_on   = extra.get(GB_TB_COSTING_ON, False)
    TB_statistical  = extra.get(GB_TB_ImpactStatistical, True)
    TB_dynamical    = extra.get(GB_TB_ImpactDynamical, False)
    # IHT costing is on if it was passed in and true or if both LiST and TB costing on are not on. This makes it so we
    # can be lazy and not have to specify IHT costing on for an IHT projection.
    if ((GB_IHT_ON in extra) and (extra[GB_IHT_ON])) or (not (LiST_costing_on or TB_costing_on)):
        IHT_costing_on = True
    else:
        IHT_costing_on = False

    if 'TBSubnatRegion' in extra:
        DBName = "subnationals\\TB_subnationalList_V2.JSON"
        tb_subnat_list = GB_get_db_json(environ["AVENIR_SW_DEFAULT_DATA_CONNECTION"], "tuberculosis", DBName)
        tb_subnat = tb_subnat_list[countryID][extra['TBSubnatRegion']] if countryID in tb_subnat_list else {}
    else:
        tb_subnat = {}

    #modvar creation list
    return {
            # db,
            #General
            PJN_TitleTag : projection_title,
            PJN_AppIDTag : appID,

            PJN_ProjectionValidTag: False,
            PJN_ProjectionSavedTag: False,
            PJN_AIMImpactCalculatedTag: False,
            PJN_UserSourceTag : [],
            #Versions
            PJN_VersionTag : GB_PM_Version,
            # PJN_VersionNumberTag :  GB_PM_VersionNumber,
            # PJN_BetaVersionTag :  GB_PM_BetaNumber,

            #years
            # PJN_BaseYearTag : GB_BaseYear,
            PJN_FirstYearTag : first_year,
            PJN_FinalYearTag : final_year,
        #     PJN_FinalCostingYearTag : final_costing_year,

            PJN_ReadOnlyTag : extra.get(GB_Extra_readonly, False),

            #country info
            PJN_CountryNameTag : extra['countryDetails']['name'],
            PJN_ISO3NumericTag : extra['countryDetails']['ISO3_Numeric'],
            PJN_ISO3AlphaTag : extra['countryDetails']['ISO3_Alpha'],
            PJN_SubNationalCodeTag : subnatCode,
            PJN_SubNationalNameTag : subnatName,

            PJN_IHTPlanTypeTag : extra.get(GB_Extra_plantype, ''),
            PJN_ModulesTag : modules,
            PJN_TBSubnatTag : tb_subnat,

            PJN_AuthorTag : author,
            PJN_OrganizationTag  : organization,
            PJN_NotesTag  : notes,
            # Note we need to set this library ID here instead of on "save"
            # because if we only do it on save if the user saves an open projection
            # then clicks save again we want to use the same library ID. If we only
            # generated it on save it wouldn't get passed on the 2nd save (with
            # current front end impl)
            PJN_LibraryIDTag: library_id,
            # Library version ID is the version of this projection in the library
            # initially empty but will be set on first save. Used for
            # optimistic locking of resource
            PJN_LibraryVersionIDTag: '',
            # PJN_Modes_Tag : {
            #     'LiSTCostingOn': LiST_costing_on,
            #     'TBCostingOn': TB_costing_on,
            #     'IHTOn': IHT_costing_on,
            #     'RAPIDSectorsOn':extra.get(GB_RAPID_SECTORS_ON, RP_init_sector_list()),
            #     'TBStatisticalOn':TB_statistical,
            #     'TBDynamicalOn':TB_dynamical,
            #     'GSKOn' : extra.get('GSKMode', False)
            # },

            "<PJN_ADRResourceID_V1>"    : '',
            "<PJN_ADRDataSetTitle_V1>"      : '',
    }



