
from SpectrumCommon.Modvars.TB.TBNaomiSubnational import tb_apply_naomi_subnat
from SpectrumCommon.Modvars.DP.DPNaomiSubnational import dp_apply_naomi_subnat
from SpectrumCommon.Modvars.AM.AMNaomiSubnational import am_apply_naomi_subnat
from SpectrumCommon.Const.PJ.PJNTags import PJN_ModulesTag 
from SpectrumCommon.Const.GB.GBConst import GB_TB


def gb_apply_naomi_subnat(projection, subnat_region):
    
    projection = dp_apply_naomi_subnat(projection, subnat_region)       
    projection = am_apply_naomi_subnat(projection, subnat_region)
    # if projection['']
    if GB_TB in projection[PJN_ModulesTag]:
        projection = tb_apply_naomi_subnat(projection, subnat_region)

    return projection