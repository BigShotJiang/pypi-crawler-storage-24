
from os import environ

from loguru import logger
import numpy as np

from AvenirCommon.Database import GB_get_db_json
from AvenirCommon.Util import GBGetKeyValue

from SpectrumCommon.Const.GB import *
from SpectrumCommon.Const.PJ import *
from SpectrumCommon.Modvars.GB.GBUtil import  getYearIdx
from SpectrumCommon.Const.GB import GB_UseInflation, GB_NumInflationTypes, GB_Female, GB_DW_MaxAgeGrp, GB_JSON

import SpectrumCommon.Const.IH as ihc
import SpectrumCommon.Const.IH.IHDatabaseKeys as ihdbk


# Please keep for now in case they change their minds

# Initializes exchange rate using IH values instead of GB values if IHT is on.
def init_exchange_infl_rate_IHT(countryID):
    environment = environ[GB_SPECT_MOD_DATA_CONN_ENV]
    exchange_rate_DB_file_name = ihc.IH_EXCHANGE_RATE_DB_DIR.replace('\\', '/') + '/' + countryID + '_' + ihc.IH_EXCHANGE_RATE_DB_CURR_VERSION + '.' + GB_JSON
    exchange_rate_DB = GB_get_db_json(environment, GB_IH_CORE_CONTAINER, exchange_rate_DB_file_name)

    return exchange_rate_DB[ihdbk.IH_EXCHANGE_RATE_KEY_EXDB], exchange_rate_DB[ihdbk.IH_INFLATION_RATE_KEY_EXDB]

def init_modvars(countryID, first_year, final_year, extra):
    modules = GBGetKeyValue(extra, 'modules', '')

    # Please keep for now in case they change their minds
    if (GB_IH in modules) or (GB_IC in modules):
        exchange_rate_val, domestic_inflation_rate_val = init_exchange_infl_rate_IHT(countryID)
    else:
        exchange_rate_val = extra['countryDetails']['exchangeRate']
        domestic_inflation_rate_val = 0.0

    exchange_rate = np.full(getYearIdx(final_year, first_year) + 1, exchange_rate_val).tolist()
    inflation = np.zeros((getYearIdx(final_year, first_year) + 1, GB_NumInflationTypes))
    inflation[:, GB_InflationLocal - 1] = domestic_inflation_rate_val
    inflation[:, GB_InflationUS - 1] = 3.0
    inflation = inflation.tolist()

    LiST_costing_on = extra.get(GB_LIST_COSTING_ON, False)
    GSKMode         = extra.get(GB_GSKMode, False)
    TB_costing_on   = extra.get(GB_TB_COSTING_ON, False)
    TB_statistical  = extra.get(GB_TB_ImpactStatistical, True)
    TB_dynamical    = extra.get(GB_TB_ImpactDynamical, False)
    useLeapfrog     = extra.get(GB_Extra_UseLeapfrog, False)
    # IHT costing is on if it was passed in and true or if both LiST and TB costing on are not on. This makes it so we
    # can be lazy and not have to specify IHT costing on for an IHT projection.
    if ((GB_IHT_ON in extra) and (extra[GB_IHT_ON])) or (not (LiST_costing_on or TB_costing_on)):
        IHT_costing_on = True
    else:
        IHT_costing_on = False
    # RAPID_sectors_on = extra.get(GB_RAPID_SECTORS_ON, RP_init_sector_list())

    #modvar creation list
    modvars = {
            # db,
        GB_UseLeapfrogTag: useLeapfrog,

        GB_DataChangedTag : False,
        GB_CalcStateValidTag : False,

        #country info
        GB_CustomEasyDataSetTag : [],

        GB_CurrencyNameTag : extra['countryDetails']['currency'], # Not sure what "currencyName" is, but currency value matches what we used to see in IHT, so switching to that
        GB_DiscountRateCostsTag : 3.0,
        GB_ExchangeRateTag : exchange_rate,
        GB_InflationTag : inflation,
        GB_InflationMethodTag : GB_UseInflation,

        GB_DisabilityWeightsTag : np.zeros((GB_Female + 1, GB_DW_MaxAgeGrp + 1)).tolist(),
        GB_DisabilityWeightsSetTag : [],

        GB_LCOnTag : LiST_costing_on,
        GB_GSKModeTag : GSKMode,
        GB_TBCostingOnTag : TB_costing_on,
        GB_IHTOnTag : IHT_costing_on,
        # GB_RAPIDSectorsOnTag : RAPID_sectors_on,

        GB_SubnatWizProjTag : 'NotImplemented',
        GB_SubnatRegionTag  : 'NotImplemented',
        GB_SubnatSurveydTag : 'NotImplemented',

        GB_TBImpactStatisticalTag : TB_statistical,
        GB_TBImpactDynamicalTag   : TB_dynamical,
        GB_UserSourcesTag : '',
        GB_TaskGUIDsTag : [],
        # GB_CloseStateDBProjTag : True #EPP will turn this False
    }

    return modvars






