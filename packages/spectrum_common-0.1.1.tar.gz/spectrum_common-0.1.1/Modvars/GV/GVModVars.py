
import SpectrumCommon.Const.GB as gbc
import SpectrumCommon.Modvars.GB.GBUtil as gbu

import SpectrumCommon.Const.PJ.PJNTags as pjmvt

# import SpectrumCommon.Const.PC.PCConstLink as pccl
# import SpectrumCommon.Const.PC.PCTags as pcmvt
# import SpectrumCommon.Modvars.PC.PCModVarDefs as pcmvd

# import SpectrumCommon.Modvars.PC.PCReadDatabases as pcrd

def init_modvars(countryID, first_year, final_year, extra):
    '''
        Initializes HIS MVs for new IHT projections.

            Parameters:
                countryID (string):  Ex: BEN for Benin.

                first_year (int): First year selected by user.

                final_year (int): Final year selected by user. 

                extra (dict): Any other fields.  
 
            Returns:
                mod_vars_rec (dict): MVs.
    '''
    
    IHT_costing_on = extra[gbc.GB_IHT_ON] if gbc.GB_IHT_ON in extra else False
    TB_costing_on = extra[gbc.GB_TB_COSTING_ON] if gbc.GB_TB_COSTING_ON in extra else False
    LiST_costing_on = extra[gbc.GB_LIST_COSTING_ON] if gbc.GB_LIST_COSTING_ON in extra else False
    costing_mode_mod_vars = {
        pjmvt.GB_IHTOnTag       : IHT_costing_on,
        pjmvt.GB_TBCostingOnTag : TB_costing_on,
        pjmvt.GB_LCOnTag        : LiST_costing_on,
    }

    costing_mode = gbu.get_costing_mode(costing_mode_mod_vars)

    # Load databases
    # cost_cat_DB = pcrd.PC_load_cost_cat_DB()
    # cost_input_DB = pcrd.PC_load_cost_input_DB()
    # costing_sect_DB = pcrd.PC_load_costing_sect_DB()
    # activity_DB = pcrd.PC_load_activity_DB()
    # activity_line_item_DB = pcrd.PC_load_activity_line_item_DB()

    # value_bool = False
    # value_int = 0
    # value_flt = 0.0
    # value_str = ''
    # value_date = date.today().strftime("%B %d, %Y"),   

    num_years_inputs = final_year - first_year + 1

    #prog_area_ID_list = pcrd.get_prog_area_ID_list(group_DB)
    #area_data_list = pcmvd.init_area_dict_list(prog_area_ID_list, num_total_years)
    # area_data_list = pcmvd.PC_init_area_dict_list(pccl.PC_IH_PROG_AREA_MST_ID, extra[pccl.PC_IH_PROG_AREA_RECORDS_TAG_V1], num_years_inputs, costing_mode)
    
    # cost_cat_records = pcrd.PC_init_cost_cat_records(cost_cat_DB)
    # cost_input_records = pcrd.PC_init_cost_input_records(cost_input_DB)
    # costing_sect_records = pcrd.PC_init_costing_sect_records(costing_sect_DB, num_years_inputs, costing_mode)
    # activity_records = pcrd.PC_init_activity_records(activity_DB, costing_mode)
    # activity_line_item_records = pcrd.PC_init_activity_line_item_records(activity_line_item_DB, num_years_inputs, costing_mode)

    # deliv_chan_pack_record_list []
    # nat_prog_record_list = []
    # audit_record_list = []
    # locked_area_record_list = []

    # add flag modvars to one modes modvar. If flag is in set, turn mode on. Else, turn mode off. Just like how you will do with intervention sets in IC.

    mod_vars_rec = {            
        # pcmvt.PC_DATA_CHANGED_TAG_V1          : value_bool, 
        # pcmvt.PC_PROJ_VALID_TAG_V1            : value_bool, 
        # pcmvt.PC_FILE_NAME_TAG_V1             : value_str,                          
        # pcmvt.PC_PROJ_VALID_DATE_TAG_V1       : value_date,    

        # pcmvt.PC_AREA_DATA_TAG_V1             : area_data_list,
        
        # pcmvt.PC_COST_CAT_RECORDS_TAG_V1      : cost_cat_records,
        # pcmvt.PC_COSTING_SECT_RECORDS_TAG_V1  : costing_sect_records, 
        # pcmvt.PC_COST_INPUT_RECORDS_TAG_V1    : cost_input_records,
        # pcmvt.PC_ACT_RECORDS_TAG_V1           : activity_records, 
        # pcmvt.PC_ACT_LINE_ITEM_RECORDS_TAG_V1 : activity_line_item_records,

        # pcmvt.PC_RES_COSTS_BY_SECT_TAG_V1    : [],
        # pcmvt.PC_RES_COSTS_BY_SUBSECT_TAG_V1 : [],
        # pcmvt.PC_RES_COSTS_BY_ACT_TAG_V1     : [],
        # pcmvt.PC_RES_COSTS_BY_CAT_TAG_V1     : [],

        # pcmvt.PC_STD_ROW_INFO_META_TAG_V1 : pcmvd.PC_init_row_info_meta(gbc.GB_NOT_FOUND), # Standard
        # pcmvt.PC_HIV_ROW_INFO_META_TAG_V1 : pcmvd.PC_init_row_info_meta(pccl.PC_IH_HIV_AIDS_MST_ID) # HIV
    }

    # if costing_mode == gbc.GB_LIST_COSTING_MODE:
    #     mod_vars_rec[pcmvt.PC_ENTER_COSTING_SECT_COSTS_ALL_YEARS_CS_TAG_V1] = False

    #Debugging
    #with open('C:\Proj\IHTSampleFile.JSON', 'w') as f:
    #   json.dump(mod_vars_dict, f)

    return mod_vars_rec

    