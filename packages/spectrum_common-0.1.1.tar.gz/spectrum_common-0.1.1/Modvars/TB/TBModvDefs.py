from copy import deepcopy

from SpectrumCommon.Const.TB  import *



def replace_in_list(ls, value):
    for i,e in enumerate(ls):
        if type(e)==list:
            replace_in_list(ls[i], value)
        else:
            ls[i] = value

def PatientClincalAssessmentAlgUsed():
    


    IDs = [[TB_ClinicalAssessment, TB_ChestXRay],                       # PTB_HIVn_014             
           [TB_ClinicalAssessment, TB_ChestXRay, TB_ComputerAidedDtct], # PTB_HIVn_15p
           [TB_W3SS],                                                   # PTB_HIVp_09 
           [TB_4SymptomScreening, TB_C_ReactiveProtein],                # PTB_HIVp_1014
           [TB_4SymptomScreening, TB_C_ReactiveProtein],                # PTB_HIVp_15p
           [TB_ClinicalExtraPulm],           # ETB_HIVn_014
           [TB_ClinicalExtraPulm],           # ETB_HIVn_15p
           [TB_ClinicalExtraPulm],           # ETB_HIVp_09
           [TB_ClinicalExtraPulm],           # ETB_HIVp_1014
           [TB_ClinicalExtraPulm],           # ETB_HIVp_15p
    ]

    Perc_Receiving = deepcopy(IDs)
    replace_in_list(Perc_Receiving, 1.00)

    return (Perc_Receiving, IDs)






def HouseholdClincalAssessmentAlgUsed():
    

    IDs = [[TB_W4SS, TB_ChestXRay],                                     # TB_HH0_4             
           [TB_SingleSymptomScrn],                                     # TB_HH5_14
           [TB_ClinicalAssessment, TB_ChestXRay, TB_ComputerAidedDtct], # TB_HH15p
 
    ]

    Perc_Receiving = deepcopy(IDs)
    replace_in_list(Perc_Receiving, 1.00)

    return (Perc_Receiving, IDs)


def HouseholdPreventionMethodsUsed():
    

    IDs = [[TB_TuberculinSkinTest, TB_AntigenSkinTest, TB_IGRA],  # TB_HH0_4             
           [TB_TuberculinSkinTest, TB_AntigenSkinTest, TB_IGRA], # TB_HH5_14
           [TB_TuberculinSkinTest, TB_AntigenSkinTest, TB_IGRA], # TB_HH15p
 
    ]
    
    
    
    Perc_Receiving = deepcopy(IDs)
    replace_in_list(Perc_Receiving, 0.00)
    for hh in TB_HHList:
        Perc_Receiving[hh][0] = 0.65 # Tuberculin skin test (TST)	65%
        Perc_Receiving[hh][1] = 0.05 # TB antigen-based skin test (TBST) for diagnosis	5%
        Perc_Receiving[hh][2] = 0.30 # Interferon-gamma release assay (IGRA)	30%

    return (Perc_Receiving, IDs)


def ARTClincalAssessmentAlgUsed():
    

    IDs = [[TB_W3SS],         # TB_HH0_4             
           [TB_mWRDPrevGT10], # TB_HH5_14
           [TB_mWRDPrevGT10], # TB_HH15p
 
    ]

    Perc_Receiving = deepcopy(IDs)
    replace_in_list(Perc_Receiving, 1.00)

    return ([Perc_Receiving,Perc_Receiving] , [IDs, IDs])




def ARTPreventionMethodsUsed():
    child = [TB_TuberculinSkinTest, TB_AntigenSkinTest, TB_IGRA]
    adult = [TB_TuberculinSkinTest, TB_AntigenSkinTest, TB_IGRA]    
   
    IDs = [child, # TB_HH0_4             
           adult, # TB_HH5_14
           adult, # TB_HH15p
 
    ]

    Perc_Receiving = deepcopy(IDs)
    replace_in_list(Perc_Receiving, 0.00)
    for i,e in enumerate(Perc_Receiving):
        Perc_Receiving[i][0] = 0.65 # Tuberculin skin test (TST)	65%
        Perc_Receiving[i][1] = 0.05 # TB antigen-based skin test (TBST) for diagnosis	5%
        Perc_Receiving[i][2] = 0.30 # Interferon-gamma release assay (IGRA)	30%

    return ([Perc_Receiving, Perc_Receiving], [IDs, IDs])


def HRGClincalAssessmentAlgUsed():
    

    IDs = [[TB_ClinicalAssessment, TB_ChestXRay, TB_ComputerAidedDtct], # TB_HRG_Prisoners                     
           [TB_ClinicalAssessment, TB_ChestXRay, TB_ComputerAidedDtct], # TB_HRG_Miners           
           [TB_4SymptomScreening, TB_ChestXRay, TB_ComputerAidedDtct], # TB_HRG_SeekingCare      
           [TB_4SymptomScreening, TB_ChestXRay, TB_ComputerAidedDtct], # TB_HRG_StructuralRFs    
           [TB_4SymptomScreening, TB_ChestXRay, TB_ComputerAidedDtct], # TB_HRG_HighTBPrev       
           [TB_4SymptomScreening, TB_ChestXRay, TB_ComputerAidedDtct], # TB_HRG_UntreatedFibrosis
 
    ]

  

    Perc_Receiving = deepcopy(IDs)
    replace_in_list(Perc_Receiving, 1.00)

    return (Perc_Receiving, IDs)




def HRGPreventionMethodsUsed():
    

    IDs = [
           [TB_TuberculinSkinTest, TB_AntigenSkinTest, TB_IGRA], # TB_HRG_Prisoners                     
           [TB_TuberculinSkinTest, TB_AntigenSkinTest, TB_IGRA], # TB_HRG_Miners           
           [TB_TuberculinSkinTest, TB_AntigenSkinTest, TB_IGRA], # TB_HRG_SeekingCare      
           [TB_TuberculinSkinTest, TB_AntigenSkinTest, TB_IGRA], # TB_HRG_StructuralRFs    
           [TB_TuberculinSkinTest, TB_AntigenSkinTest, TB_IGRA], # TB_HRG_HighTBPrev       
           [TB_TuberculinSkinTest, TB_AntigenSkinTest, TB_IGRA], # TB_HRG_UntreatedFibrosis
 
    ]

    Perc_Receiving = deepcopy(IDs)
    replace_in_list(Perc_Receiving, 0.00)
    for i,e in enumerate(Perc_Receiving):
        Perc_Receiving[i][0] = 0.65 # Tuberculin skin test (TST)	65%
        Perc_Receiving[i][1] = 0.05 # TB antigen-based skin test (TBST) for diagnosis	5%
        Perc_Receiving[i][2] = 0.30 # Interferon-gamma release assay (IGRA)	30%

    return (Perc_Receiving, IDs)


