from SpectrumCommon.Const.TB import *
def TB_screening_alg_patient_options():
    
    return [[TB_Scrn_g_sym_any_cxr_cad_parallel, TB_Scrn_1Step_custom, TB_Scrn_2Step_custom], # PTB_HIVn_014             
            [TB_Scrn_g_sym_any_cxr_cad_parallel, TB_Scrn_1Step_custom, TB_Scrn_2Step_custom], # PTB_HIVn_15p
            [TB_Scrn_h_clhiv_sym, TB_Scrn_1Step_custom, TB_Scrn_2Step_custom], # PTB_HIVp_09 
            [TB_Scrn_g_sym_any_cxr_tb_parallel,	TB_Scrn_h_hiv_w4ss,	TB_Scrn_h_hiv_crp,	TB_Scrn_h_hiv_cxr_abn,
             TB_Scrn_h_hiv_w4ss_hiv_crp_parallel, 
             TB_Scrn_h_hiv_w4ss_hiv_cxr_abn_sequential_pos, TB_Scrn_h_hiv_w4ss_hiv_cxr_abn_sequential_neg, 
             TB_Scrn_h_hiv_w4ss_hiv_crp_sequential_pos,	TB_Scrn_h_hiv_w4ss_hiv_crp_sequential_neg,
             TB_Scrn_h_hiv_mwrd_sn, TB_Scrn_1Step_custom, TB_Scrn_2Step_custom], # PTB_HIVp_1014
            [TB_Scrn_g_sym_any_cxr_tb_parallel,	TB_Scrn_h_hiv_w4ss,	TB_Scrn_h_hiv_crp,	TB_Scrn_h_hiv_cxr_abn,
             TB_Scrn_h_hiv_w4ss_hiv_crp_parallel, 
             TB_Scrn_h_hiv_w4ss_hiv_cxr_abn_sequential_pos, TB_Scrn_h_hiv_w4ss_hiv_cxr_abn_sequential_neg, 
             TB_Scrn_h_hiv_w4ss_hiv_crp_sequential_pos,	TB_Scrn_h_hiv_w4ss_hiv_crp_sequential_neg,
             TB_Scrn_h_hiv_mwrd_sn, TB_Scrn_1Step_custom, TB_Scrn_2Step_custom], # PTB_HIVp_15p
            [TB_Scrn_g_sym_any, TB_Scrn_1Step_custom, TB_Scrn_2Step_custom], # ETB_HIVn_014
            [TB_Scrn_g_sym_any, TB_Scrn_1Step_custom, TB_Scrn_2Step_custom], # ETB_HIVn_15p
            [TB_Scrn_g_sym_any, TB_Scrn_1Step_custom, TB_Scrn_2Step_custom], # ETB_HIVp_09
            [TB_Scrn_g_sym_any, TB_Scrn_1Step_custom, TB_Scrn_2Step_custom], # ETB_HIVp_1014
            [TB_Scrn_g_sym_any, TB_Scrn_1Step_custom, TB_Scrn_2Step_custom], # ETB_HIVp_15p
    ]

def TB_screening_alg_patient_defaults():
    return [TB_Scrn_g_sym_any_cxr_cad_parallel, # PTB_HIVn_014             
            TB_Scrn_g_sym_any_cxr_cad_parallel, # PTB_HIVn_15p
            TB_Scrn_h_clhiv_sym, # PTB_HIVp_09 
            TB_Scrn_g_sym_any_cxr_tb_parallel, # PTB_HIVp_1014
            TB_Scrn_g_sym_any_cxr_tb_parallel, # PTB_HIVp_15p
            TB_Scrn_g_sym_any, # ETB_HIVn_014
            TB_Scrn_g_sym_any, # ETB_HIVn_15p
            TB_Scrn_g_sym_any, # ETB_HIVp_09
            TB_Scrn_g_sym_any, # ETB_HIVp_1014
            TB_Scrn_g_sym_any, # ETB_HIVp_15p
    ]

def TB_screening_alg_household_options():
    
    return [[TB_Scrn_c_hiv_w4ss_cc_cxr_tb_parallel,
             TB_Scrn_c_cc_sym,  TB_Scrn_c_cc_cxr_tb, 
             TB_Scrn_c_hiv_w4ss_cc_cxr_tb_sequential_pos, TB_Scrn_c_hiv_w4ss_cc_cxr_tb_sequential_neg, TB_Scrn_1Step_custom, TB_Scrn_2Step_custom], # HH 0-4
            [TB_Scrn_c_hiv_w4ss_cc_cxr_tb_parallel,
             TB_Scrn_c_cc_sym,  TB_Scrn_c_cc_cxr_tb, 
             TB_Scrn_c_hiv_w4ss_cc_cxr_tb_sequential_pos, TB_Scrn_c_hiv_w4ss_cc_cxr_tb_sequential_neg, TB_Scrn_1Step_custom, TB_Scrn_2Step_custom], # HH 5-14
            [TB_Scrn_g_sym_any_cxr_tb_parallel, TB_Scrn_g_sym_cgh2w, TB_Scrn_g_sym_cgh2w_cxr_cad_parallel,
             TB_Scrn_g_sym_cgh2w_cxr_cad_sequential_pos,	TB_Scrn_g_sym_cgh2w,	TB_Scrn_g_sym_any,
             TB_Scrn_g_sym_any_cxr_tb_sequential_pos, TB_Scrn_g_sym_any_cxr_tb_sequential_neg,
             TB_Scrn_g_mwrd_sn, TB_Scrn_1Step_custom, TB_Scrn_2Step_custom] # HH 15+
        ]

def TB_screening_alg_household_defaults():
    
    return [TB_Scrn_c_hiv_w4ss_cc_cxr_tb_parallel, # HH 0-4
            TB_Scrn_c_hiv_w4ss_cc_cxr_tb_parallel, # HH 5-14
            TB_Scrn_g_sym_any_cxr_tb_parallel,  # HH 15+
        ]



def TB_screening_alg_art_options():
    result = [[],[]] 
    art_not_serious = [[TB_Scrn_h_clhiv_sym, TB_Scrn_1Step_custom, TB_Scrn_2Step_custom], # ART 0-9
                       [TB_Scrn_h_hiv_w4ss_cxr_cad_parallel, TB_Scrn_h_hiv_w4ss, TB_Scrn_h_hiv_crp, TB_Scrn_h_hiv_cxr_abn,
                        TB_Scrn_h_hiv_w4ss_hiv_cxr_abn_sequential_pos, TB_Scrn_h_hiv_w4ss_cxr_cad_sequential_neg,
                        TB_Scrn_h_hiv_w4ss_hiv_crp_sequential_pos, TB_Scrn_h_hiv_w4ss_hiv_crp_sequential_neg, TB_Scrn_h_hiv_mwrd_sn, TB_Scrn_1Step_custom, TB_Scrn_2Step_custom], # ART 10-14   
                       [TB_Scrn_h_hiv_w4ss_cxr_cad_parallel, TB_Scrn_h_hiv_w4ss, TB_Scrn_h_hiv_crp, TB_Scrn_h_hiv_cxr_abn,
                        TB_Scrn_h_hiv_w4ss_hiv_cxr_abn_sequential_pos, TB_Scrn_h_hiv_w4ss_cxr_cad_sequential_neg,
                        TB_Scrn_h_hiv_w4ss_hiv_crp_sequential_pos, TB_Scrn_h_hiv_w4ss_hiv_crp_sequential_neg, TB_Scrn_h_hiv_mwrd_sn, TB_Scrn_1Step_custom, TB_Scrn_2Step_custom]] # ART 15+

    art_serious = [[TB_Scrn_h_clhiv_sym, TB_Scrn_1Step_custom, TB_Scrn_2Step_custom], # ART 0-9
                   [TB_Scrn_h_hiv_mwrd_sn, TB_Scrn_1Step_custom, TB_Scrn_2Step_custom], # ART 10-14
                   [TB_Scrn_h_hiv_mwrd_sn, TB_Scrn_1Step_custom, TB_Scrn_2Step_custom]] # ART 15+
    
    result[TB_ARTNotServere] = art_not_serious
    result[TB_ARTSevereIllness] = art_serious

    return result

def TB_screening_alg_art_defaults():
    result = [[],[]] 
    art_not_serious = [TB_Scrn_h_clhiv_sym, # ART 0-9
                       TB_Scrn_h_hiv_w4ss_cxr_cad_parallel, # ART 10-14   
                       TB_Scrn_h_hiv_w4ss_cxr_cad_parallel] # ART 15+

    art_serious = [TB_Scrn_h_clhiv_sym, # ART 0-9
                   TB_Scrn_h_hiv_mwrd_sn, # ART 10-14
                   TB_Scrn_h_hiv_mwrd_sn] # ART 15+
    
    result[TB_ARTNotServere] = art_not_serious
    result[TB_ARTSevereIllness] = art_serious

    return result


def TB_screening_alg_hrg_options():

    prisoners  = [TB_Scrn_g_sym_any_cxr_tb_parallel, TB_Scrn_g_sym_cgh2w, TB_Scrn_g_sym_cgh2w_cxr_tb_parallel, TB_Scrn_g_sym_cgh2w_cxr_cad_sequential_pos,
                  TB_Scrn_g_sym_cgh2w_cxr_cad_sequential_neg, TB_Scrn_g_sym_any, TB_Scrn_g_sym_any_cxr_tb_sequential_pos, 
                  TB_Scrn_g_sym_any_cxr_tb_sequential_neg, TB_Scrn_g_mwrd_sn, TB_Scrn_1Step_custom, TB_Scrn_2Step_custom]
    other_hrgs = [TB_Scrn_g_sym_any_cxr_tb_parallel, TB_Scrn_g_sym_cgh2w, TB_Scrn_g_sym_cgh2w_cxr_cad_sequential_pos,	
                  TB_Scrn_g_sym_cgh2w_cxr_tb_sequential_neg,	TB_Scrn_g_sym_any,
                  TB_Scrn_g_sym_any_cxr_tb_parallel,	TB_Scrn_g_sym_any_cxr_tb_sequential_pos,	TB_Scrn_g_sym_any_cxr_tb_sequential_neg,	TB_Scrn_g_mwrd_sn, TB_Scrn_1Step_custom, TB_Scrn_2Step_custom]
     
    result = [other_hrgs for hrg in TB_HRG_List] # default everything to other
    result[TB_HRG_Prisoners]  = prisoners

    return result

def TB_screening_alg_hrg_defaults():

    prisoners  = TB_Scrn_g_sym_any_cxr_tb_parallel
    other_hrgs = TB_Scrn_g_sym_any_cxr_tb_parallel
     
    result = [other_hrgs for hrg in TB_HRG_List] # default everything to other
    result[TB_HRG_Prisoners] = prisoners

    return result



def TB_screening_sens_spec_combined(screenID):
    screen_map = TB_screening_sens_spec_map()
    return screen_map[screenID]

def TB_screening_sens_spec_map():
    return {
        TB_Scrn_g_sym_cgh2w                           : (0.420, 0.940),           
        TB_Scrn_g_sym_any                             : (0.710, 0.640),           
        TB_Scrn_g_mwrd_sn                             : (0.690, 0.990),           
        TB_Scrn_g_sym_cgh2w_cxr_tb_sequential_pos     : (0.357, 0.998),           
        TB_Scrn_g_sym_cgh2w_cxr_tb_sequential_neg     : (0.357, 0.902),           
        TB_Scrn_g_sym_cgh2w_cxr_tb_parallel           : (0.913, 0.902),           
        TB_Scrn_g_sym_cgh2w_cxr_cad_sequential_pos    : (0.395, 0.993),           
        TB_Scrn_g_sym_cgh2w_cxr_cad_sequential_neg    : (0.395, 0.837),           
        TB_Scrn_g_sym_cgh2w_cxr_cad_parallel          : (0.965, 0.837),           
        TB_Scrn_g_sym_any_cxr_tb_sequential_pos       : (0.604, 0.986),           
        TB_Scrn_g_sym_any_cxr_tb_sequential_neg       : (0.604, 0.614),           
        TB_Scrn_g_sym_any_cxr_tb_parallel             : (0.957, 0.614),           
        TB_Scrn_g_sym_any_cxr_cad_sequential_pos      : (0.667, 0.960),           
        TB_Scrn_g_sym_any_cxr_cad_sequential_neg      : (0.667, 0.570),           
        TB_Scrn_g_sym_any_cxr_cad_parallel            : (0.983, 0.570),           
        TB_Scrn_h_clhiv_sym                           : (0.610, 0.940),           
        TB_Scrn_h_hiv_mwrd_sn                         : (0.690, 0.980),           
        TB_Scrn_h_hiv_w4ss                            : (0.830, 0.380),           
        TB_Scrn_h_hiv_crp                             : (0.900, 0.500),           
        TB_Scrn_h_hiv_cxr_abn                         : (0.930, 0.200),           
        TB_Scrn_h_hiv_w4ss_hiv_crp_sequential_pos     : (0.747, 0.690),           
        TB_Scrn_h_hiv_w4ss_hiv_crp_sequential_neg     : (0.747, 0.190),           
        TB_Scrn_h_hiv_w4ss_hiv_crp_parallel           : (0.983, 0.190),           
        TB_Scrn_h_hiv_w4ss_hiv_cxr_abn_sequential_pos : (0.772, 0.504),           
        TB_Scrn_h_hiv_w4ss_hiv_cxr_abn_sequential_neg : (0.772, 0.076),           
        TB_Scrn_h_hiv_w4ss_hiv_cxr_abn_parallel       : (0.988, 0.076),           
        TB_Scrn_h_hiv_w4ss_cxr_cad_sequential_pos     : (0.780, 0.932),           
        TB_Scrn_h_hiv_w4ss_cxr_cad_sequential_neg     : (0.780, 0.338),           
        TB_Scrn_h_hiv_w4ss_cxr_cad_parallel           : (0.990, 0.338),           
        TB_Scrn_c_cc_sym                              : (0.890, 0.690),           
        TB_Scrn_c_cc_cxr_tb                           : (0.840, 0.910),           
        TB_Scrn_c_hiv_w4ss_cc_cxr_tb_sequential_pos   : (0.697, 0.944),           
        TB_Scrn_c_hiv_w4ss_cc_cxr_tb_sequential_neg   : (0.697, 0.346),           
        TB_Scrn_c_hiv_w4ss_cc_cxr_tb_parallel         : (0.973, 0.346),           
        TB_Scrn_c_hiv_w4ss_cxr_cad_sequential_pos     : (0.780, 0.932),           
        TB_Scrn_c_hiv_w4ss_cxr_cad_sequential_neg     : (0.780, 0.338),           
        TB_Scrn_c_hiv_w4ss_cxr_cad_parallel           : (0.990, 0.338),           
    }





























	



















































