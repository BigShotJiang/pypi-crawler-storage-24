
import numpy as np

from SpectrumCommon.Const.TB import *

def TB_PreventionDefaults(rp_Rif, year_len):
    preventionTargets =  np.zeros((TB_ResistanceLen, TB_ResistAgeLen, year_len))
    preventionTargets[TB_SEN][TB_Child] = rp_Rif[TB_SEN][TB_ResistAge0_14] 
    preventionTargets[TB_SEN][TB_Adult] = rp_Rif[TB_SEN][TB_ResistAge15p] 

    preventionTargets[TB_MDR][TB_Child] = rp_Rif[TB_MDR][TB_ResistAge0_14] 
    preventionTargets[TB_MDR][TB_Adult] = rp_Rif[TB_MDR][TB_ResistAge15p]

    # preventionTargets[TB_SEN][TB_Child] = 1 - preventionTargets[TB_MDR][TB_Child]
    # preventionTargets[TB_SEN][TB_Adult] = 1 - preventionTargets[TB_MDR][TB_Adult]
 
    return preventionTargets