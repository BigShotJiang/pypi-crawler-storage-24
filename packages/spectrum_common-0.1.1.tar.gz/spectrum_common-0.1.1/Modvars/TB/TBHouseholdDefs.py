import numpy as np

from SpectrumCommon.Const.TB import *


def TB_HHPropPrvntPresumpDefaults(year_len):
    HHPropPrvntPresump = np.zeros((TB_HHAgeLen, year_len))  
    HHPropPrvntPresump[TB_HH0_4]  += 0.5
    HHPropPrvntPresump[TB_HH5_14] += 0.5
    HHPropPrvntPresump[TB_HH15p]  += 0.5
    return HHPropPrvntPresump

def TB_HHPropPrvntTested(year_len):
    HHPropPrvntTested = np.zeros((TB_HHAgeLen, year_len))
    # HHPropPrvntTested[TB_HH15p] += 1.0
    return HHPropPrvntTested