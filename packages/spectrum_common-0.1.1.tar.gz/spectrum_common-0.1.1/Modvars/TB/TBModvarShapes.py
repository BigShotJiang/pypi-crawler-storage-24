


# from SpectrumCommon.Const.GB import *
# from SpectrumCommon.Const.DP import *
from SpectrumCommon.Const.TB import *
from SpectrumCommon.Modvars.GB.GBDefs import *
from SpectrumCommon.Modvars.TB.TBIndices import *



tb_patient_shape = lambda d, **kwargs : gb_shape(d,'1D float',
                                                  dim=['tb_patient'], 
                                                  indices=[tb_patient_indices], **kwargs)

tb_patient_year_shape = lambda d, **kwargs : gb_shape(d,'2D float',
                                                  dim=['tb_patient',  gb_year_dim], 
                                                  indices=[tb_patient_indices, gb_year_indices], **kwargs)

tb_hh_shape = lambda d, **kwargs : gb_shape(d,'1D float',
                                                  dim=['tb_household'], 
                                                  indices=[tb_household_indices], **kwargs)

tb_hh_year_shape = lambda d, **kwargs : gb_shape(d,'2D float',
                                                  dim=['tb_household',  gb_year_dim], 
                                                  indices=[tb_household_indices, gb_year_indices], **kwargs)

tb_art_shape = lambda d, **kwargs : gb_shape(d,'2D float',
                                                  dim=['tb_art_severity', 'tb_art_age'], 
                                                  indices=[tb_art_severity_indices, tb_art_age_indices], **kwargs)

tb_art_year_shape = lambda d, **kwargs : gb_shape(d,'3D float',
                                                  dim=['tb_art_severity','tb_art_age',  gb_year_dim], 
                                                  indices=[tb_art_severity_indices, tb_art_age_indices,  gb_year_indices], **kwargs)


tb_hrg_shape = lambda d, **kwargs : gb_shape(d,'1D float',
                                                  dim=['tb_highriskgroup'], 
                                                  indices=[tb_hrg_indices], **kwargs)

tb_hrg_year_shape = lambda d, **kwargs : gb_shape(d,'2D float',
                                                  dim=['tb_highriskgroup',  gb_year_dim], 
                                                  indices=[tb_hrg_indices, gb_year_indices], **kwargs)
                                                  
tb_child_adult_year_shape = lambda d, **kwargs : gb_shape(d,'2D float',
                                                  dim=['tb_child_adult',  gb_year_dim], 
                                                  indices=[tb_child_adult_indices, gb_year_indices], **kwargs)

tb_pulmonary_year_shape = lambda d, **kwargs : gb_shape(d,'2D float',
                                                  dim=['tp_pulmonary',  gb_year_dim], 
                                                  indices=[tb_pulmonary_indices, gb_year_indices], **kwargs)

tb_pulmonary_child_adult_year_shape = lambda d, **kwargs : gb_shape(d,'3D float',
                                                  dim=['tp_pulmonary', 'tb_child_adult',  gb_year_dim], 
                                                  indices=[tb_pulmonary_indices, tb_child_adult_indices, gb_year_indices], **kwargs)

tb_case_resistance_shape = lambda d, **kwargs : gb_shape(d,'3D float',
                                        dim=['tb_cases', 'tb_resistance_ages',  gb_year_dim], 
                                        indices=[tb_cases_indices, tb_resist_age_indices, gb_year_indices], **kwargs)

tb_impact_year_shape = lambda d, **kwargs : gb_shape(d,'2D float',
                                                  dim=['tp_impact',  gb_year_dim], 
                                                  indices=[tb_impact_indices, gb_year_indices], **kwargs)

tb_resbounds_year_shape = lambda d, **kwargs : gb_shape(d,'2D float',
                                                  dim=['tp_result_bounds',  gb_year_dim], 
                                                  indices=[tb_result_bound_indices, gb_year_indices], **kwargs)




TB_modvar_shapes = {

        TB_BaseYearTag: gb_int_shape('Base year is the starting notification year', range=[TB_Min_First_Year, TB_Max_First_Year], note='Not editable'),
        TB_DataSourceTag : gb_str_shape('Source of TB data'),
        TB_UseOldFailsafeTag: gb_bool_shape('Only true for old 2021 projections',  note='Not editable'), 
        TB_UseOldIPTag: gb_bool_shape('only true for old 2022 projections',  note='Not editable'),


        TB_HistNotifStartYearTag : gb_int_shape('Historical notification start year'),
        TB_HistNotifTag          : gb_shape('Historical notification','dict', innerdict={  
                                    key:gb_shape(f'Historical data for {key}',
                                                         "1D float", 
                                                         dim=['tb_hist_year']
                                                         ) for key in TB_NOTIF_DB_KEYS
                                  }),
        TB_HistNotiDistributionTag : gb_shape('Historical notification distribution','dict', innerdict={  
                                    key:gb_shape(f'Historical data for {key}',
                                                         "1D float", 
                                                         dim=['tb_hist_year']
                                                         ) for key in TB_HistNotiDistributionTag
                                  }),
                                            
        TB_ScreeningAlgMapTag              : gb_shape('Screening algorithm mapping','dict', innerdict={            
                                                       i : gb_shape(i, 
                                                         "1D float", 
                                                         dim=['tb_sens_spec'],
                                                         indices=[{'Sensitivity':0, 'Specificity':1}]) for i in tb_screening_options 

                                            }),

                            


        # From the wireframes
        TB_PulmonaryAgeTag                 : gb_shape('Selected patient screening algorithm','1D int',
                                                       dim=['tb_patient'], 
                                                       indices = [tb_patient_indices],
                                                       has_default=False),
        
        TB_PrevalenceTag                   : tb_patient_year_shape('Prevalence by patient groups'),
        TB_PatientScreenSensitivityTag     : tb_patient_shape('Patient screening sensitivity'),
        TB_PatientScreenSpecificityTag     : tb_patient_shape('Patient screening specificity'), 
        TB_PatientScreenAlgOptionsTag      : gb_shape('Patient screening algorithm options','2D str',
                                                       dim=['tb_patient', 'tb_screening_options'], 
                                                       indices = [tb_patient_indices, tb_screening_options],
                                                       has_default=False),

        TB_PatientScreenAlgSelectedTag     : gb_shape('Selected patient screening algorithm','1D str',
                                                       dim=['tb_patient'], 
                                                       indices = [tb_patient_indices],
                                                       options = tb_patient_screening_options,
                                                       has_default=False),

        TB_NumClinicallyAssessedTag        : tb_patient_year_shape('Patient number clinically assessed'),
        TB_NumReferredTag                  : tb_patient_year_shape('Patient number referred'),
        TB_NumScreenedToReferTag           : tb_patient_year_shape('Patient number screened top refer'),
        TB_PercTrueCasesTag                : tb_patient_year_shape('Patient percent true cases'),

        TB_PatientDiagCaseValuesTag            : gb_shape('Patient diagnostic values', '3D float',
                                                  dim=['tb_patient', 'tb_dynamic', 'tb_dynamic' ], 
                                                  indices = [tb_patient_indices, [], []]),
        TB_PatientDiagCaseIDsTag               : gb_shape('Patient diagnostic IDs', '3D int',
                                                  dim=['tb_patient', 'tb_dynamic', 'tb_dynamic' ], 
                                                  indices = [tb_patient_indices, [], []]),
        TB_PatientDiagCaseMethodsTag         : gb_shape('Patient diagnostic Method IDs', '2D int',
                                                  dim=['tb_patient', 'tb_dynamic'], 
                                                  indices = [tb_patient_indices, [], []]),
        TB_PatientDiagCaseSensitivityTag       : gb_shape('Patient diagnostic Sesnitivity', '3D float',
                                                  dim=['tb_patient', 'tb_dynamic', 'tb_dynamic' ], 
                                                  indices = [tb_patient_indices, [], []]),
        TB_PatientDiagCaseSpecificityTag       : gb_shape('Patient diagnostic Specificity', '3D float',
                                                  dim=['tb_patient', 'tb_dynamic', 'tb_dynamic' ], 
                                                  indices = [tb_patient_indices, [], []]),

        TB_PatientDiagSensitivityTag       : tb_patient_shape('Patient diagnosistic sensitivity'),
        TB_PatientDiagSpecificityTag       : tb_patient_shape('Patient diagnosistic specificity'),
        TB_NumDiagnosedPTBTag              : tb_patient_year_shape('Patient number diagnosed PTB'),
        TB_NumConfirmedPTBTag              : tb_patient_year_shape('Patient number confirmed PTB'),
        TB_NumDiagnosedTBTag               : tb_patient_year_shape('Patient number diagnosed TB'),
        TB_NumInitTreatmentTag             : tb_patient_year_shape('Patient number initializad on treatment'),

        TB_PatientScreeningOutputTag       : gb_shape('Patient screening output', '2D float',
                                                       dim=['tb_patient', 'tb_screening',  gb_year_dim], 
                                                       indices=[tb_patient_indices, tb_screening_indices, gb_year_indices]),
        TB_PatientDiagnosticOutputTag      : gb_shape('Patient screening output', '2D float',
                                                       dim=['tb_patient', 'tb_diagnosis',  gb_year_dim], 
                                                       indices=[tb_patient_indices, tb_diagnosis_indices, gb_year_indices]),
        TB_PatientTargetPopTag             : gb_shape('Patient screening output', '2D float',
                                                       dim=['tb_patient', 'tb_patient_targ_pop',  gb_year_dim], 
                                                       indices=[tb_patient_indices, tb_patient_targ_pop_indices, gb_year_indices]),
            

        # provider households
        
        # Household 
        ## Household demographics
        ### Demographics
        TB_HHSizeTag         : gb_float_shape('Average household size'),
        TB_HHPropU5Tag       : gb_float_shape('Proportion of household that is u5 '),
        TB_HHProp5_14Tag     : gb_float_shape('Proportion of household that is 5-14 yrs'),
        TB_HHCasesinIndexTag : gb_float_shape('Average number of TB cases in household with at least one case'),

        ###  TB infection characteristics
        TB_HHPropU5LTBITag : gb_year_shape('Proportion of u5s with TB infection in household with TB infection'),
        TB_HHPropO5LTBITag : gb_year_shape('Proportion of other household members with TB infection in household with active case'),

        ####  TB disease characteristics
        TB_HHPropU5TBTag  :  gb_year_shape('Proportion of u5s with TB disease in household with TB disease'),
        TB_HHPropU5PTBTag :  gb_year_shape('Proportion of u5s with TB disease in household with PTB disease'),  
        TB_HHPropO5TBTag  :  gb_year_shape('Proportion of other household members with TB disease in household with TB disease'),
        TB_HHPropO5PTBTag : gb_year_shape('Proportion with pulmonary TB, PTB'), 

        ##     Index cases
        TB_HHNumNewBactPosTag : gb_year_shape('Number of new bacteriologically positive TB cases (adult)'),
        TB_HHNumNewBactNegTag : gb_year_shape('Number of new bacteriologically negative TB cases (adult)'),

        ## household contact tracing coverage
        TB_HHPIndexCasesScreenedTag : gb_year_shape('Proportion of households of index cases screened/evaluated'),
        TB_HHPropBACnScreenedTag    : gb_year_shape('Proportion of contacts of new bacteriologically negative cases screened/evaluated'),
        
        # ## Tab Household contacts by age
        TB_HHContacts                : gb_shape('Household contacts', '3D float',
                                                 dim=['tb_household', 'tb_contact',  gb_year_dim], 
                                                 indices=[tb_household_indices, tb_contact_indices, gb_year_indices]),
        
        # ## Tab Household screeningtb_contact_indices
        # ### Household proportion
        TB_HHProportionTag           : tb_hh_year_shape('Household proportion'),

        # ### Household sensitivity amd specificity
        TB_HHScreenSensitivityTag : tb_hh_shape('Household sensitivity'), # np.full((TB_HHAgeLen), 0.90),
        TB_HHScreenSpecificityTag : tb_hh_shape('Household specificity'), # np.full((TB_HHAgeLen), 0.99),  
        TB_HHScreenAlgOptionsTag  : gb_shape('Household screening algorithm options','2D str',
                                              dim=['tb_household', 'tb_screening_options'], 
                                              indices = [tb_household_indices, tb_screening_options],
                                              has_default=False),
        TB_HHScreenAlgSelectedTag : gb_shape('Selected household screening algorithm','1D str',
                                              dim=['tb_household'], 
                                              indices = [tb_household_indices],
                                              options = tb_household_screening_options,
                                              has_default=False),


        # ### Household screening outputs
        TB_HHNumScreenedTag           : tb_hh_year_shape('Household number of screened'),
        TB_HHNumReferredTag           : tb_hh_year_shape('Household number referred '),
        TB_HHNumScreenedToReferTag    : tb_hh_year_shape('Household number screened to refer '),
        TB_HHPercTrueCasesTag         : tb_hh_year_shape('Household percent of true cases'),     

        # ## Tab Household diagnostic evaluation
        # ###  TB Case type split by treatment and sputum status

        TB_HHDiagCaseValuesTag            : gb_shape('Household diagnostic values', '3D float',
                                                  dim=['tb_household', 'tb_dynamic', 'tb_dynamic' ], 
                                                  indices = [tb_household_indices, [], []]),
        TB_HHDiagCaseIDsTag               : gb_shape('Household diagnostic IDs', '3D int',
                                                  dim=['tb_household', 'tb_dynamic', 'tb_dynamic' ], 
                                                  indices = [tb_household_indices, [], []]),
        TB_HHDiagCaseMethodsTag         : gb_shape('Household diagnostic Method IDs', '2D int',
                                                  dim=['tb_household', 'tb_dynamic'], 
                                                  indices = [tb_household_indices, [], []]),
        TB_HHDiagCaseSensitivityTag       : gb_shape('Household diagnostic Sesnitivity', '3D float',
                                                  dim=['tb_household', 'tb_dynamic', 'tb_dynamic' ], 
                                                  indices = [tb_household_indices, [], []]),
        TB_HHDiagCaseSpecificityTag       : gb_shape('Household diagnostic Specificity', '3D float',
                                                  dim=['tb_household', 'tb_dynamic', 'tb_dynamic' ], 
                                                  indices = [tb_household_indices, [], []]),
        # ### Household sensitivity and specificity

        TB_HHDiagSensitivityTag : tb_hh_shape('Household diagnostic sensitivity'),
        TB_HHDiagSpecificityTag : tb_hh_shape('Household diagnostic specificity'),

        # ### Diagnosis outputs
        TB_HHNumDiagnosedPTBTag       : tb_hh_year_shape('Household diagnosed PTB'),             
        TB_HHNumConfirmedPTBTag       : tb_hh_year_shape('Household confirmed PTB'),  

        # ## Tab Household disease and treatment
        TB_HHPropLinkedTreatTag       : tb_hh_year_shape('Household proportion linked to treatment'),           
        TB_HHNumInitTreatmentTag      : tb_hh_year_shape('Household number initialized on treatment'),         
        
        # ## Tab Household prevention
        TB_HHPrvntInActiveEligibleTag  : tb_hh_year_shape('Household prevention inactive eligible'),   
        TB_HHPrvntReceivePTPrevTag     : tb_hh_year_shape('Household prevention received PTB prevention'),   
        TB_HHPropPrvntPresumpTag       : tb_hh_year_shape('Household proportion prevention presumed'),
        TB_HHPropPrvntTestedTag        : tb_hh_year_shape('Household proportion prevention tested'), 
        
        TB_HHPrvntMethodsTag           : gb_shape('Household prevention method values', '2D float',
                                             dim=['tb_household', 'tb_dynamic_id'], 
                                             indices=[tb_household_indices, []]),   
        TB_HHPrvntMethodIDsTag         : gb_shape('Household prevention method IDs', '2D int',
                                             dim=['tb_household', 'tb_dynamic_id'], 
                                             indices=[tb_household_indices, []],
                                             options=tb_test_ids),

        TB_HHPropEligiblePrvntLinkTag  : tb_hh_year_shape('Household proportion linked to treatment'),   
        TB_HHNumberOnTPTTag            : tb_hh_year_shape("Household Number initiated on TB preventative treatment"),
        TB_HHTPTCompleteRateTag        : tb_hh_year_shape("Household TB prevention completion rate"),
        TB_HHNumberCompleteTPTTag      : tb_hh_year_shape("Household Number complete preventative treatment"),

        # ## Tab Household output
        TB_HHScreeningOutputTag  : gb_shape('Household screening output', '3D float',
                                             dim=['tb_household', 'tb_screening',  gb_year_dim], 
                                             indices=[tb_household_indices, tb_screening_indices, gb_year_indices]),
        TB_HHDiagnosticOutputTag : gb_shape('Household screening output', '3D float',
                                             dim=['tb_household', 'tb_diagnosis',  gb_year_dim], 
                                             indices=[tb_household_indices, tb_diagnosis_indices, gb_year_indices]),  
        TB_HHTargetPopsTag       : gb_shape('Household screening output', '3D float',
                                             dim=['tb_household', 'tb_provider_targ_pop',  gb_year_dim], 
                                             indices=[tb_household_indices, tb_provider_targ_pop_indices, gb_year_indices]),
   

        
        # ## Tab ART cohort sizes and TB characteristics
        # ### ART cohort sizes
        TB_ARTCohortSizesTag         : gb_shape('ART Cohort sizes', '3D float', 
                                                dim=['tb_art_all_severity', 'tb_art_age', gb_year_dim],
                                                indices=[tb_art_all_severity, tb_art_age_indices, gb_year_indices]),
        

        # ###  TB characteristics
        TB_ARTCharacteristicsTag     : gb_shape('ART Characteristics', '3D float', 
                                                dim=['tb_art_age', 'tb_art_characteristics', gb_year_dim],
                                                indices=[tb_art_age_indices, tb_art_char_indices, gb_year_indices]),
        
        # ## Tab ART screening
        # ### ART proportion
        TB_ARTProportionTag           : tb_art_year_shape("ART proportions"),

        # ### ART sensitivity amd specificity
        TB_ARTScreenSensitivityTag : tb_art_shape("ART screening sensiticity"),#art_sensitivity, # np.full((TB_ARTAgeLen), 0.90),
        TB_ARTScreenSpecificityTag : tb_art_shape("ART screening specificity"),#art_specificity, # np.full((TB_ARTAgeLen), 0.99),  
        TB_ARTScreenAlgOptionsTag  : gb_shape('ART screening algorithm options','3D str',
                                              dim=['tb_art_severity', 'tb_art_age', 'tb_screening_options'], 
                                              indices = [tb_art_severity_indices, tb_art_age_indices, tb_screening_options],
                                              has_default=False),
        TB_ARTScreenAlgSelectedTag : gb_shape('Selected ART screening algorithm','2D float',
                                                  dim=['tb_art_severity', 'tb_art_age'], 
                                                  indices = [tb_art_severity_indices, tb_art_age_indices],
                                                  options = tb_art_screening_options,
                                                  has_default=False),

        # ### ART screening outputs
        TB_ARTNumScreenedTag           : tb_art_year_shape("ART number of screened"),
        TB_ARTNumReferredTag           : tb_art_year_shape("ART number referred"),
        TB_ARTNumScreenedToReferTag    : tb_art_year_shape("ART number screened to refer"),
        TB_ARTPercTrueCasesTag         : tb_art_year_shape("ART percent of true cases"), 

        # ## Tab ART diagnostic evaluation
        # ###  TB Case type split by treatment and sputum status
        #                : [diagnostic_db['art']['values']]*TB_ARTSevereLen,
        #                   : [diagnostic_db['art']['IDs']]*TB_ARTSevereLen,
        #               : [diagnostic_db['art']['methods']]*TB_ARTSevereLen,
        #           : [diagnostic_db['art']['sensitivity']]*TB_ARTSevereLen,
        #           : [diagnostic_db['art']['specificity']]*TB_ARTSevereLen,

        TB_ARTDiagCaseValuesTag            : gb_shape('ART diagnostic values', '4D float',
                                                  dim=['tb_art_severity', 'tb_art_age',  'tb_dynamic', 'tb_dynamic' ], 
                                                  indices = [tb_art_severity_indices, tb_art_age_indices, [], []]),
        TB_ARTDiagCaseIDsTag               : gb_shape('ART diagnostic IDs', '4D int',
                                                  dim=['tb_art_severity', 'tb_art_age',  'tb_dynamic', 'tb_dynamic' ], 
                                                  indices = [tb_art_severity_indices, tb_art_age_indices, [], []]),
        TB_ARTDiagCaseMethodsTag         : gb_shape('ART diagnostic Method IDs', '3D int',
                                                  dim=['tb_art_severity', 'tb_art_age', 'tb_dynamic'], 
                                                  indices = [tb_art_severity_indices, tb_art_age_indices, [], []]),
        TB_ARTDiagCaseSensitivityTag       : gb_shape('ART diagnostic Sesnitivity', '4D float',
                                                  dim=['tb_art_severity', 'tb_art_age', 'tb_dynamic', 'tb_dynamic' ], 
                                                  indices = [tb_art_severity_indices, tb_art_age_indices, [], []]),
        TB_ARTDiagCaseSpecificityTag       : gb_shape('ART diagnostic Specificity', '4D float',
                                                  dim=['tb_art_severity', 'tb_art_age', 'tb_dynamic', 'tb_dynamic' ], 
                                                  indices = [tb_art_severity_indices, tb_art_age_indices, [], []]),

        # ### ART sensitivity amd specificity
        TB_ARTDiagSensitivityTag : tb_art_shape("ART diagnostic sensitivity"),
        TB_ARTDiagSpecificityTag : tb_art_shape("ART diagnostic specificity"),

        # ### Diagnosis outputs
        TB_ARTNumDiagnosedPTBTag       : tb_art_year_shape("ART number diagnosed with PTB"),
        TB_ARTNumConfirmedPTBTag       : tb_art_year_shape("ART number confirmed with PTB"),

        # ## Tab ART disease and treatment
        TB_ARTPropLinkedTreatTag       : tb_art_year_shape("ART proportion linked with treatment"),
        TB_ARTNumInitTreatmentTag      : tb_art_year_shape("ART number initialized on treatment"),
        
        # ## Tab ART prevention
        TB_ARTPrvntInActiveEligibleTag  : tb_art_year_shape("ART prevention inactive eligible"),
        TB_ARTPrvntReceivePTPrevTag     : tb_art_year_shape('ART prevention received PTB prevention'),   
        TB_ARTPropPrvntPresumpTag       : tb_art_year_shape("ART proportion prevention presumed"),
        TB_ARTPropPrvntTestedTag        : tb_art_year_shape("ART proportion prevention tested"),
        
        TB_ARTPrvntMethodsTag           : gb_shape('Household prevention method values', '3D float',
                                             dim=['tb_art_severity', 'tb_art_age',  'tb_dynamic_id'], 
                                             indices=[tb_art_severity_indices, tb_art_age_indices, []]),    
        TB_ARTPrvntMethodIDsTag         : gb_shape('Household prevention method IDs', '3D int',
                                             dim=['tb_art_severity', 'tb_art_age',  'tb_dynamic_id'], 
                                             indices=[tb_art_severity_indices, tb_art_age_indices, []],
                                             options=tb_test_ids), 
        TB_ARTPropEligiblePrvntLinkTag  : tb_art_year_shape("ART proportion eligible prevention link"),
        TB_ARTNumberOnTPTTag            : tb_art_year_shape("ART Number initiated on TB preventative treatment"),
        TB_ARTTPTCompleteRateTag        : tb_art_year_shape("ART TB prevention completion rate"),
        TB_ARTNumberCompleteTPTTag      : tb_art_year_shape("ART Number complete preventative treatment"),


        # ## Tab ART output
        TB_ARTScreeningOutputTag  : gb_shape('ART screening output', '4D float',
                                             dim=['tb_art_severity', 'tb_art_age', 'tb_screening',  gb_year_dim], 
                                             indices=[tb_art_severity_indices, tb_art_age_indices, tb_screening_indices, gb_year_indices]),
        TB_ARTDiagnosticOutputTag : gb_shape('ART screening output', '4D float',
                                             dim=['tb_art_severity', 'tb_art_age', 'tb_diagnosis',  gb_year_dim], 
                                             indices=[tb_art_severity_indices, tb_art_age_indices, tb_diagnosis_indices, gb_year_indices]), 
        TB_ARTTargetPopsTag       : gb_shape('ART screening output', '4D float',
                                             dim=['tb_art_severity', 'tb_art_age', 'tb_provider_targ_pop',  gb_year_dim], 
                                             indices=[tb_art_severity_indices, tb_art_age_indices, tb_provider_targ_pop_indices, gb_year_indices]),

        # ## Tab HRG demographics
        TB_HRGDemographicsTag      : gb_shape('HRG Demographic data','1D int',
                                               dim=['tb_highriskgroup', 'tb_highriskgroup_demographics', gb_year_dim], 
                                               indices = [tb_hrg_indices, tb_hrg_demographic_indices, gb_year_indices]),

        # ## Tab HRG screening
        # ### HRG proportion
        TB_HRGProportionTag        : tb_hrg_year_shape('High risk group proportions'), 

        # ### HRG sensitivity amd specificity
        TB_HRGScreenSensitivityTag : tb_hrg_shape('High risk group screening sensitivity'),
        TB_HRGScreenSpecificityTag : tb_hrg_shape('High risk group screening specificity'), 
        TB_HRGScreenAlgOptionsTag  : gb_shape('High risk group screening algorithm options','2D str',
                                               dim=['tb_highriskgroup', 'tb_screening_options'], 
                                              indices = [tb_hrg_indices, tb_screening_options],
                                              has_default=False),
        TB_HRGScreenAlgSelectedTag : gb_shape('Selected high risk group screening algorithm','1D int',
                                               dim=['tb_highriskgroup'], 
                                               indices = [tb_hrg_indices],
                                               options = tb_hrg_screening_options,
                                               has_default=False),

        # ### HRG screening outputs
        TB_HRGNumScreenedTag           : tb_hrg_year_shape('High risk group number screened'),
        TB_HRGNumReferredTag           : tb_hrg_year_shape('High risk group number referred'),
        TB_HRGNumScreenedToReferTag    : tb_hrg_year_shape('High risk group number screned to refer'),
        TB_HRGPercTrueCasesTag         : tb_hrg_year_shape('High risk group percent of true cases'),

        # ## Tab HRG diagnostic evaluation
        # ###  TB Case type split by treatment and sputum status

        TB_HRGDiagCaseValuesTag            : gb_shape('High risk group diagnostic values', '3D float',
                                                  dim=['tb_highriskgroup', 'tb_dynamic', 'tb_dynamic' ], 
                                                  indices = [tb_hrg_indices, [], []]),
        TB_HRGDiagCaseIDsTag               : gb_shape('High risk group diagnostic IDs', '3D int',
                                                  dim=['tb_highriskgroup', 'tb_dynamic', 'tb_dynamic' ], 
                                                  indices = [tb_hrg_indices, [], []]),
        TB_HRGDiagCaseMethodsTag         : gb_shape('High risk group diagnostic Method IDs', '2D int',
                                                  dim=['tb_highriskgroup', 'tb_dynamic'], 
                                                  indices = [tb_hrg_indices, [], []]),
        TB_HRGDiagCaseSensitivityTag       : gb_shape('High risk group diagnostic Sesnitivity', '3D float',
                                                  dim=['tb_highriskgroup', 'tb_dynamic', 'tb_dynamic' ], 
                                                  indices = [tb_hrg_indices, [], []]),
        TB_HRGDiagCaseSpecificityTag       : gb_shape('High risk group diagnostic Specificity', '3D float',
                                                  dim=['tb_highriskgroup', 'tb_dynamic', 'tb_dynamic' ], 
                                                  indices = [tb_hrg_indices, [], []]),

        # ### HRG sensitivity amd specificity
        TB_HRGDiagSensitivityTag : tb_hrg_shape('High risk group diagnostic sensitivity'), # np.full((TB_HRG_Len),  db['Sensitivity']['High risk group'][0]),
        TB_HRGDiagSpecificityTag : tb_hrg_shape('High risk group diagnostic specificity'), # np.full((TB_HRG_Len),  db['Specificity']['High risk group'][0]),  

        # ### Diagnosis outputs
        TB_HRGNumDiagnosedPTBTag       : tb_hrg_year_shape('High risk group number diagnosted with PTB'),
        TB_HRGNumConfirmedPTBTag       : tb_hrg_year_shape('High risk group number confirmed with PTB'),

        # ## Tab HRG disease and treatment
        TB_HRGPropLinkedTreatTag       : tb_hrg_year_shape('High risk group proportion linked with treatment'),
        TB_HRGNumInitTreatmentTag      : tb_hrg_year_shape('High risk group initialized with with treatment'),
        
        # ## Tab HRG prevention
        TB_HRGPrvntInActiveEligibleTag  : tb_hrg_year_shape('High risk group prevention inactive eligible'),
        TB_HRGPrvntReceivePTPrevTag     : tb_hrg_year_shape('High risk group prevention received PTB prevention'),   
        TB_HRGPropPrvntPresumpTag       : tb_hrg_year_shape('High risk group proportion prevention presumed'),
        TB_HRGPropPrvntTestedTag        : tb_hrg_year_shape('High risk group proportion prevention tested'),
        
        TB_HRGPrvntMethodsTag           : gb_shape('Household prevention method values', '2D float',
                                             dim=['tb_highriskgroup', 'tb_dynamic_id'], 
                                             indices=[tb_hrg_indices, []]),    
        TB_HRGPrvntMethodIDsTag         : gb_shape('Household prevention method IDs', '2D int',
                                             dim=['tb_highriskgroup', 'tb_dynamic_id'], 
                                             indices=[tb_hrg_indices, []],
                                             options=tb_test_ids), 
        TB_HRGPropEligiblePrvntLinkTag  : tb_hrg_year_shape('High risk group eligible prevention linked'),
        TB_HRGNumberOnTPTTag            : tb_hrg_year_shape("High risk group Number initiated on TB preventative treatment"),
        TB_HRGTPTCompleteRateTag        : tb_hrg_year_shape("High risk group TB prevention completion rate"),
        TB_HRGNumberCompleteTPTTag      : tb_hrg_year_shape("High risk group Number complete preventative treatment"),
        ## Tab HRG soutput
        TB_HRGScreeningOutputTag       : gb_shape('High risk group screening output', '3D float',
                                             dim=['tb_highriskgroup', 'tb_screening',  gb_year_dim], 
                                             indices=[tb_hrg_indices, tb_screening_indices, gb_year_indices]), 
        TB_HRGDiagnosticOutputTag      : gb_shape('High risk group screening output', '3D float',
                                             dim=['tb_highriskgroup', 'tb_diagnosis',  gb_year_dim], 
                                             indices=[tb_hrg_indices, tb_diagnosis_indices, gb_year_indices]),  
        TB_HRGTargetPopsTag            : gb_shape('High risk group screening output', '3D float',
                                             dim=['tb_highriskgroup', 'tb_provider_targ_pop',  gb_year_dim], 
                                             indices=[tb_hrg_indices, tb_provider_targ_pop_indices, gb_year_indices]),


        TB_ResistProfileTag  : gb_shape('Propotion of prevention', '4D float',
                                         dim=['tb_cases', 'tb_resistance_ages', 'tb_rr_profile', gb_year_dim], 
                                         indices=[tb_case_indices, tb_resistance_age_indices, tb_resistance_profile_indices, gb_year_indices]),
        TB_ResistPropNonSevereTag     : tb_case_resistance_shape('Resistance proportion non-severe'),
        TB_ResistPropLungSurgeryTag   : tb_case_resistance_shape('Resistance proportion lung surgery'),
        TB_ResistMeningitisTag        : tb_case_resistance_shape('Resistance meningitis'),
        TB_ResistPropTreatExhaustTag  : tb_case_resistance_shape('Resistance proportion treated exhaustively'),

        TB_PatientTestNumPTB  : gb_year_shape('Patient test number PTB'),
        TB_PatientTestNumXDR  : gb_year_shape('Patient tet number XDR'),
        TB_PatientTestNumEPTB : gb_year_shape('Patient test number ETB'), 

        TB_CoverageTag : gb_shape('Resistance coverages', '2D float',
                                   dim=['tb_coverages', gb_year_dim], 
                                   indices=[tb_coverage_indices, gb_year_indices]),
        TB_ResistNumToBeTestedTag : gb_shape('Resistance number to be tested', '2D float',
                                              dim=['tb_num_tested', gb_year_dim], 
                                              indices=[tb_num_tested_indices, gb_year_indices]),
        TB_ResistNumTestedTag : gb_shape('Resistance number tested', '2D float',
                                          dim=['tb_num_tested', gb_year_dim], 
                                          indices=[tb_num_tested_indices, gb_year_indices]),
        TB_ResistNumConfirmedTag : gb_shape('Resistance number confirmed', '3D float',
                                             dim=['tb_num_confirmed', 'tb_resistance_ages', gb_year_dim], 
                                             indices=[tb_num_confirmed_indices, tb_resistance_age_indices, gb_year_indices]),
        TB_ResistNumNotConfirmedTag : gb_shape('Resistance number not confirmed', '3D float',
                                                dim=['tb_num_confirmed', 'tb_resistance_ages', gb_year_dim], 
                                                indices=[tb_num_confirmed_indices, tb_resistance_age_indices, gb_year_indices]),


        ## Prevention of TB
        TB_PropPreventionTag : gb_shape('Propotion of prevention', '3D float',
                                          dim=['tb_resistance', 'tb_resistance_ages', gb_year_dim], 
                                          indices=[tb_resistance_indices, tb_resistance_age_indices, gb_year_indices]),


        ## Vaccination
        TB_BCGImmunizationTag : gb_year_shape('BCG immunization'),
        TB_InfantVaccineTag : gb_year_shape('Infant vaccine'),
        TB_AdolAdultVaccineTag : gb_year_shape('Adolescent/Adult vaccine'),

        ## Palliative care
        TB_PalliativeCareTag : gb_shape('Palliative care', '2D float',
                                         dim=['tb_resistance_ages', gb_year_dim], 
                                         indices=[tb_resistance_age_indices, gb_year_indices]), 

        TB_BCGTargetPopTag          : gb_year_shape('BCG target pop'),
        TB_InfantVaccTargPopTag     : gb_year_shape('Infant vaccine target pop'),
        TB_AdultVaccTargPopTag      : gb_year_shape('Adult vaccine target pop'),
        TB_PalliativeCareTargPopTag : gb_shape('Palliative care target population', '2D float',
                                          dim=['tb_resistance_ages', gb_year_dim], 
                                          indices=[tb_resistance_age_indices, gb_year_indices]),



        #Extra target populations
        TB_PreventionTargetTag : gb_shape('Extra prevention target pops', '3D float',
                                          dim=['tb_resistance', 'tb_resistance_ages', gb_year_dim], 
                                          indices=[tb_resistance_indices, tb_resistance_age_indices, gb_year_indices]),

        TB_RR_DST_PTBTag     : gb_year_shape('RR_DST_PTB target pop'),
        TB_RR_DST_ETBTag     : gb_year_shape('RR_DST_ETB target pop'),
        TB_INH_DST_PTBTag    : gb_year_shape('INH_DST_PTB target pop'),
        TB_INH_DST_ETBTag    : gb_year_shape('INH_DST_ETB target pop'),
        TB_BDQ_DST_PTBTag    : gb_year_shape('BDQ_DST_PTB target pop'),
        TB_BDQ_DST_ETBTag    : gb_year_shape('BDQ_DST_ETB target pop'),
        TB_FQ_DST_PTBTag     : gb_year_shape('FQ_DST_PTB target pop'),
        TB_FQ_DST_ETBTag     : gb_year_shape('FQ_DST_ETB target pop'),
        TB_BDQ_FQ_DST_PTBTag : gb_year_shape('BDQ_FQ_DST_PTB target pop'),
        TB_BDQ_FQ_DST_ETBTag : gb_year_shape('BDQ_FQ_DST_ETB target pop'),
        TB_LZD_RR_DST_PTBTag : gb_year_shape('LZD_RR_DST_PTB target pop'),
        TB_LZD_RR_DST_ETBTag : gb_year_shape('LZD_RR_DST_ETB target pop'),
        TB_LZD_FQ_DST_PTBTag : gb_year_shape('LZD_FQ_DST_PTB target pop'),
        TB_LZD_FQ_DST_ETBTag : gb_year_shape('LZD_FQ_DST_ETB target pop'),
        TB_PZA_DSTTag        : gb_year_shape('PZA_DST target pop'),
        TB_ETO_DSTTag        : gb_year_shape('ETO_DST target pop'),
        TB_EMC_DSTTag        : gb_year_shape('EMC_DST target pop'),
        TB_BDQ_LZD_NumDx_U15Tag         : gb_year_shape('BDQ_LZD_NumDx_U15 target pop'),
        TB_BDQ_LZD_NumDx_15PLusTag      : gb_year_shape('BDQ_LZD_NumDx_15PLus target pop'),
        TB_BDQ_LZD_NumDx_PTB_U15Tag     : gb_year_shape('BDQ_LZD_NumDx_PTB_U15 target pop'),
        TB_BDQ_LZD_NumDx_PTB_15PLusTag  : gb_year_shape('BDQ_LZD_NumDx_PTB_15PLus target pop'),
        TB_BDQ_LZD_NumDx_ETB_U15Tag     : gb_year_shape('BDQ_LZD_NumDx_ETB_U15 target pop'),
        TB_BDQ_LZD_NumDx_ETB_15PLusTag  : gb_year_shape('BDQ_LZD_NumDx_ETB_15PLus target pop'),



        TB_AmikacynRifampicinResistant     : tb_pulmonary_year_shape('Amikacyn rifampicin resistant'), 
        TB_EthionamideRifampicinResistant  : tb_pulmonary_year_shape('Ethionamide rifampicin resistant'), 
        TB_PyrazinamideRifampicinResistant : tb_pulmonary_year_shape('Pyrazinamide rifampicin resistant'), 

        TB_Rif_INH_Sen_SevereTag     : tb_child_adult_year_shape('Rif_INH_Sen_Severe'),
        TB_Rif_INH_Sen_NotSevereTag  : tb_child_adult_year_shape('Rif_INH_Sen_NotSevere'),
        TB_Rif_INH_Sen_MeningitisTag : tb_child_adult_year_shape('Rif_INH_Sen_Meningitis'),
        TB_Rif_INH_ResTag            : tb_child_adult_year_shape('Rif_INH_Res'),
        TB_RR_FQ_SenTag              : tb_child_adult_year_shape('RR_FQ_Sen'),
        TB_Rif_FQ_Res_PlusTag        : tb_child_adult_year_shape('Rif_FQ_Res_Plus'),
        TB_BQD_LZD_Tag               : tb_child_adult_year_shape('BQD_LZD'),
        TB_TxFL_Tag                  : tb_child_adult_year_shape('TxFL'),
        TB_TxSL_Tag                  : tb_child_adult_year_shape('TxSL'),
        TB_TxPreXDR_Tag              : tb_child_adult_year_shape('TxPreXDR'),
        TB_LungSurgeryTag            : tb_child_adult_year_shape('Lung surgery'),
        TB_lPTB_ReferredDxTag        : tb_child_adult_year_shape('lPTB_ReferredDx'),

        TB_HIVnClinicallyAssessedTag : tb_pulmonary_child_adult_year_shape('HIV- clinically assessed'), 
        TB_HIVAnyReferredDxTag       : tb_pulmonary_child_adult_year_shape('HIV any referred diagnosed'), 

        # Notification
        TB_HisNotificationTag  : gb_year_shape('Historical notification', has_default=True),
        TB_TargNotificationTag : gb_year_shape('Target notification', has_default=True),
        TB_ResNotificationTag  : tb_impact_year_shape('Result notification', has_default=True),
        TB_CounterfactualNotifTag : gb_year_shape('Counterfactual notification', has_default=True),
        
        

        TB_ResHIVTBCoInfTag    : gb_shape('Result HIV TB Coinfected', '2D float',
                                          dim=['tb_hiv_coinfected', gb_year_dim], 
                                          indices=[tb_hiv_coinfected_indices, gb_year_indices]),


        TB_ResIncidenceTag  : tb_impact_year_shape('Result incidence', has_default=True),
        TB_ResMortalityTag  : tb_impact_year_shape('Result mortality', has_default=True),
        TB_ResPrevalenceTag : tb_impact_year_shape('Result prevalence', has_default=True),
        
        TB_UserEnteredIncidenceTag  : gb_year_shape('User entered incidence', has_default=True),
        TB_UserEnteredMortalityTag  : gb_year_shape('User entered mortality', has_default=True),
        TB_AlternativeProjBurdenTag :  gb_bool_shape('Checkbox use alternative projection of TB burden', 
                                                     note='''When this is true, then the calculations will use 
                                                             TB_UserEnteredIncidenceTag and TB_UserEnteredMortalityTag '''), 

        TB_FortIncidenceTag    : tb_resbounds_year_shape('Fort incidence', has_default=True),
        TB_FortNotificationTag : tb_resbounds_year_shape('Fort notification', has_default=True),
        TB_FortPrevalenceTag   : tb_resbounds_year_shape('Fort prevalence', has_default=True),
        TB_FortMortalityTag    : tb_resbounds_year_shape('Fort mortality', has_default=True),


        TB_ResPrevalencePctTag : gb_year_shape('Result prevalence percent', has_default=True), 

        TB_CounterfactualScenarioTag : gb_shape('Counterfactual scenario', '2D float',
                                          dim=['tb_scenarios', gb_year_dim], 
                                          indices=[tb_scenario_indices, gb_year_indices]),
        TB_CurrentScenarioTag        :  gb_shape('Current scenario', '2D float',
                                          dim=['tb_scenarios', gb_year_dim], 
                                          indices=[tb_scenario_indices, gb_year_indices]),
        TB_Baseline_HRi_allTag : gb_year_shape('Baseline HRi all'),
        TB_Scaleup_HRi_allTag  : gb_year_shape('Scaleup HRi all'),

        TB_NotificationByCaseTypeTag :  gb_shape('Notification by case type', '2D float',
                                          dim=['tb_notification_cases', gb_year_dim], 
                                          indices=[tb_notification_indices, gb_year_indices], has_default=True),

        TB_PercNotificationTag       :  gb_shape('Notification base year by case type percents', '1D float',
                                          dim=['tb_notification_cases'], 
                                          indices=[tb_notification_indices], has_default=True),

        
        TB_FortVsnTag : gb_str_shape('Last fort version used in calculations', has_default=True),
        
        TB_DataSourceTag : gb_str_shape('Data source', has_default=True), 

        TB_FinalHistoricalYearTag : gb_int_shape('Final historical year', has_default=True), 
        TB_FortInputVersionTag : gb_str_shape('Fort input version', has_default=True), 
        TB_FortInputTag : gb_shape('Fort input object', 'dict', has_default=True), 
        TB_FortInputScaleupTag : gb_shape('Fort input scaleup object', 'dict', has_default=True), 
        TB_FortOutputVersionTag : gb_str_shape('Fort output version', has_default=True), 
        TB_FortOutputTag : gb_shape('Fort output object', 'dict', has_default=True), 
        

    }
