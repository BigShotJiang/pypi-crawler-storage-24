from SpectrumCommon.Const.TB import *
from SpectrumCommon.Modvars.TB.TBScreeningDefs import *

tb_patient_indices = {
    
    # Pulmonary TB
    'Pulmonary TB HIV- 0-14'  : TB_PTB_HIVn_014_grp ,
    'Pulmonary TB HIV- 15+'   : TB_PTB_HIVn_15p_grp ,
    'Pulmonary TB HIV+ 0-9'   : TB_PTB_HIVp_09_grp  ,
    'Pulmonary TB HIV+ 10-14' : TB_PTB_HIVp_1014_grp,
    'Pulmonary TB HIV+ 15+ ' : TB_PTB_HIVp_15p_grp ,

    # Extra-Pulmonary TB
    'Extra-pulmonary TB HIV- 0-14'   : TB_ETB_HIVn_014_grp ,
    'Extra-pulmonary TB HIV- 15+'    : TB_ETB_HIVn_15p_grp ,
    'Extra-pulmonary TB HIV+ 0-9'    : TB_ETB_HIVp_09_grp  ,
    'Extra-pulmonary TB HIV+ 10-14'  : TB_ETB_HIVp_1014_grp,
    'Extra-pulmonary TB HIV+ 15+ '  : TB_ETB_HIVp_15p_grp 
}

tb_screening_indices = {
    'Screened'                     : TB_ScreenedNum,
    'Screened number referred'     : TB_ScreenedNumReferred,
    'Screened true postives (TP)'  : TB_ScreenedTP,
    'Screened false postives (FP)' : TB_ScreenedFP,
    'Screened true cases'          : TB_ScreenedTrueCases,
    'Screened NNTS'                : TB_ScreenedNNTS,
    'Screened TP and FP'           : TB_ScreenedTPFP,
    'Screened TP missed'           : TB_ScreenedTPMissed
}

tb_diagnosis_indices = {
    'Diagnosis'                      : TB_DiagnosisNum, 
    'Diagnosis Confirmed'            : TB_DiagnosisConfirmed,
    'Diagnosis true postives (TP)'   : TB_DiagnosisTP,
    'Diagnosis false positives (FP)' : TB_DiagnosisFP,
    'Diagnosis true cases'           : TB_DiagnosisTrueCases,
    'Diagnosis NNTT'                 : TB_DiagnosisNNTT,
    'Diagnosis TP and FP'            : TB_DiagnosisTPFP,
    'Diagnosis TP Missed '          : TB_DiagnosisTPMissed ,
}

tb_patient_targ_pop_indices = {
    'Clinically assessed'   : TB_ClinicallyAssessed,
    'Referred Dx'           : TB_ReferredDx, 
    'Diagnosis TB'          : TB_DiagnosisTB, 
    'Treatment initialized' : TB_TreatmentInit
}

tb_provider_targ_pop_indices = {
    'Number eligible for screening'   : TB_NumEligibleScreen,
    'Number screened'                 : TB_NumScreened,
    'Number referredDiag'             : TB_NumReferredDiag,
    'Number diagnosed with PTB'       : TB_NumDiagPulmTB,
    'Number initialized on Treatment' : TB_NumInitTreatment,
    'Number eligible for evaluation'  : TB_NumEligibleEval,
    'Number tested for infection'     : TB_NumTestedInfect,
    'Number confirmed infected'       : TB_NumConfirmInfect,
    'Number initialized on TPT'       : TB_NumInitTPT,
}

tb_contact_indices = {
    'Total contacts'          : TB_TotalContacts,
    'Disease infect contacts' : TB_DiseaseInfectCntct,
    'Infection contacts'      : TB_InfectionCntct, 
    'Disease contacts'        : TB_DiseaseCntct,
    'Pulmonary TB contacts'   : TB_PulmTBCntct
}

tb_household_indices = {
    'Household 0 to 4'  : TB_HH0_4, 
    'Household 5 to 14' : TB_HH5_14,
    'Household 15+'     : TB_HH15p 
}

tb_art_age_indices ={
    'ART 0 to 9'   : TB_ART0_9,   
    'ART 10 to 14' : TB_ART10_14,
    'ART 15+'      : TB_ART15p  
}

tb_art_severity_indices = {
    'Not servere'    : TB_ARTNotServere,
    'Severe illness' : TB_ARTSevereIllness
}

tb_hrg_indices ={
    'Prisoners'                                                                         : TB_HRG_Prisoners,
    'Miners exposed to silica '                                                        : TB_HRG_Miners,
    'People with risk factors for TB seeking health care'                               : TB_HRG_SeekingCare,
    'Populations with structural risk factors for TB and limited access to health care' : TB_HRG_StructuralRFs,
    'General population in settings with high TB'                                       : TB_HRG_HighTBPrev,
    'People with untreated fibrotic lesions on chest x-ray'                             : TB_HRG_UntreatedFibrosis,
}

tb_pulmonary_indices = {
    'pulmonary tb'       : TB_PTB,
    'extra-pulmonary tb' : TB_ETB,
}

tb_child_adult_indices = {
     'Child' : TB_Child,
     'Adul' : TB_Adult,
}

tb_cases_indices = {
    'New cases' : TB_NewCases,
    'Retreated cases' : TB_RetreatCases ,
}

tb_resist_age_indices = {
    '0 to 14' : TB_ResistAge0_14,
    '15+' : TB_ResistAge15p ,
}

tb_coverage_indices = {
    'Coverage RR_DST_PTB'          : TB_Cov_RR_DST_PTB,
    'Coverage RR_DST_ETB'          : TB_Cov_RR_DST_ETB,
    'Coverage INH_RR_Sens_DST_PTB' : TB_Cov_INH_RR_Sens_DST_PTB,
    'Coverage INH_RR_Sens_DST_ETB' : TB_Cov_INH_RR_Sens_DST_ETB,
    'Coverage FQ_RR_Res_DST_PTB'   : TB_Cov_FQ_RR_Res_DST_PTB,
    'Coverage FQ_RR_Res_DST_ETB'   : TB_Cov_FQ_RR_Res_DST_ETB,
    'Coverage BDQ RR Res DST PTB'  : TB_Cov_BDQ_RR_Res_DST_PTB ,
    'Coverage BDQ RR Res DST ETB'  : TB_Cov_BDQ_RR_Res_DST_ETB ,
    'Coverage BDQ FQ Res DST PTB'  : TB_Cov_BDQ_FQ_Res_DST_PTB ,
    'Coverage BDQ FQ Res DST ETB'  : TB_Cov_BDQ_FQ_Res_DST_ETB ,
    'Coverage LZD RR Res DST PTB'  : TB_Cov_LZD_RR_Res_DST_PTB ,
    'Coverage LZD RR Res DST ETB'  : TB_Cov_LZD_RR_Res_DST_ETB ,
    'Coverage LZD FQ Res DST PTB'  : TB_Cov_LZD_FQ_Res_DST_PTB ,
    'Coverage LZD FQ Res DST ETB'  : TB_Cov_LZD_FQ_Res_DST_ETB ,
    'Coverage EMC XDR DST XDR'     : TB_Cov_EMC_XDR_DST_XDR,
    'Coverage EMC RR Res DST TB'   : TB_Cov_EMC_RR_Res_DST_TB,
    'Coverage ETO XDR_DST_XDR'     : TB_Cov_ETO_XDR_DST_XDR,
    'Coverage ETO RR_Res_DST_TB'   : TB_Cov_ETO_RR_Res_DST_TB,
    'Coverage PZA XDR_DST_XDR'     : TB_Cov_PZA_XDR_DST_XDR,
    'Coverage PZA RR_Res_DST_TB'   : TB_Cov_PZA_RR_Res_DST_TB,
    'Coverage DR_BDQ_LZD_MOX'      : TB_CovXDR_BDQ_LZD_MOX
}   

tb_impact_indices = {
    'Counterfactual' : TB_Counterfactual, 
    'Scaleup' : TB_Scaleup,
    'Difference' : TB_Difference,
}

tb_result_bound_indices = {
    'Lower' : TB_ResLowerIdx,
    'Mid'   : TB_ResMidIdx,
    'Upper' : TB_ResUpperIdx,
    'SD'    : TB_ResSdIdx 
}

tb_hiv_coinfected_indices = {
   'Number PLHIV with TB '                                                         : TB_HIVCoInf,
   'Number PLHIV with TB, adults'                                                   : TB_HIVCoInfAdult,
   'Number PLHIV with TB, children'                                                 : TB_HIVCoInfChild,
   'Number PLHIV with TB, neonates'                                                 : TB_HIVCoInfNeonates,
   'Number failing this first-line HIV regimen: TDF + 3TC (or FTC) + DTG, adults'   : TB_HIVCoInfFailAdult,
   'Number failing this first-line HIV regimen: TDF + 3TC (or FTC) + DTG, children' : TB_HIVCoInfFailChild,
   'Number failing this first-line HIV regimen: TDF + 3TC (or FTC) + DTG, neonates' : TB_HIVCoInfFailNeonates
}

tb_scenario_indices = {
    'Average probability to detect'             : TB_AvgProbDetect,
    'Average probability to receive prevention' : TB_AvgProbReceivPrvnt,
    'Treatment success'                         : TB_TreatmentSuccess
}

tb_notification_indices = {
    #TB notification case types
    'New cases'                                         : TB_NewCases,
    'New cases, Pulmonary, bacteriologically confirmed' : TB_NewBacterConfirmCases,
    'New cases, Pulmonary, clinically diagnosed cases'  : TB_NewClinicDiagCases,
    'New cases,  extrapulmonary cases'                  : TB_NewExtrapulmonaryCases,

    'Relapse cases'                                         : TB_RelapseCases,
    'Relapse cases, Pulmonary, bacteriologically confirmed' : TB_RelapseBacterConfirmCases,
    'Relapse cases, Pulmonary, clinically diagnosed'        : TB_RelapseClinicDiagCases,
    'Relapse cases, extrapulmonary'                         : TB_RelapseExtrapulmonaryCases,

    'New and relapsed cases'                      : TB_NewAndRelapsedCases,
    'Previously treated, excluding relapse cases' : TB_PrevTreatExcludeRelapseCases,
    'Previously treated, including relapse cases' : TB_PrevTreatIncludeRelapseCases,
    # #Split by age*                    
    'Children 0-9 years'                    : TB_NewRelapse0_9Cases,
    'Children 10-14 years, new and relapse' : TB_NewRelapse10_14Cases,
    'Adults 15+ years'                      : TB_NewRelapse15pCases,

    # #Split by HIV status*             
    'HIV+'                                                        : TB_HIVpCases,
    'HIV+ Adults 15+ years'                                       : TB_HIVp15pCases,
    'HIV+ Children 0-14 years'                                    : TB_HIVp0_14Cases,
    'HIV+ Neonates'                                               : TB_HIVpNeonateCases,
    'Not on ART'                                                  : TB_NotOnARTCases,
    'On ART'                                                      : TB_OnARTCases,
    'On ART Adults 15+ years, failing this frst-line regimen '   : TB_OnART15pCases,
    'On ART Children 0-14 years, failing this first-line regimen' : TB_OnARRT0_14Cases,
    'On ART Neonates, failing this first-line regimen'            : TB_OnARTNeonateCases,
    'Proportion HIVp in pop that excludes ART'                    : TB_HIVpExcludeART
}

tb_resistance_indices = {
    'SEN' : TB_SEN,
    'MDR' : TB_MDR
}


tb_resistance_age_indices = {
    'Age 0-14' : TB_ResistAge0_14,
    'Age 15+'  : TB_ResistAge15p
}

tb_resistance_profile_indices = {
    'Rif Sen' : TB_Rif_Sen,
    'INH Sen' : TB_INH_Sen,
    'INH Res' : TB_INH_Res,
    'Rif Res' : TB_Rif_Res,
    'FQ_Sen'  : TB_FQ_Sen ,
    'FQ_Res'  : TB_FQ_Res ,
    'XDR'     : TB_XDR    
}
TB_ResistProfileLen = 7


tb_num_tested_indices = {
    'PTB RIF INH MDR'      : TB_NumTestPTB_RIF_INH_MDR,
    'PTB INH MDR RIF Sens' : TB_NumTestPTB_INHMDR_RIFSens,
    'PTB FQ RIF MDR'       : TB_NumTestPTB_FQ_RIF_MDR,
    'PTB BDQ RIF MDR'      : TB_NumTestPTB_BDQ_RIF_MDR,
    'PTB BDQ FQ MDR'       : TB_NumTestPTB_BDQ_FQ_MDR,
    'PTB LZD RIF MDR'      : TB_NumTestPTB_LZD_RIF_MDR,
    'PTB LZD FQ MDR'       : TB_NumTestPTB_LZD_FQ_MDR ,
    'ETB RIF INH MDR'      : TB_NumTestETB_RIF_INH_MDR,
    'ETB INH MDR RIF Sens' : TB_NumTestETB_INHMDR_RIFSens,
    'ETB FQ RIF MDR'       : TB_NumTestETB_FQ_RIF_MDR,
    'ETB BDQ RIF MDR'      : TB_NumTestETB_BDQ_RIF_MDR,
    'ETB BDQ FQ MDR'       : TB_NumTestETB_BDQ_FQ_MDR,
    'ETB LZD RIF MDR'      : TB_NumTestETB_LZD_RIF_MDR,
    'ETB LZD FQ MDR'       : TB_NumTestETB_LZD_FQ_MDR,
    'XDR Amikacin'         : TB_NumTextXDR_Amikacin,
    'XDR Ethionamide'      : TB_NumTextXDR_Ethionamide,
    'XDR Pyrazinamide'     : TB_NumTextXDR_Pyrazinamide,
    'XDR BDQ_LZD_MOX'      : TB_NumTextXDR_BDQ_LZD_MOX

}

tb_num_confirmed_indices = {
    'RIF INH Sen' : TB_NumConfRIF_INHSen    ,
    'RIF Sen INH MDR' : TB_NumConfRIFSen_INHMDR ,
    'RIF MDR FQ Sen' : TB_NumConfRIFMDR_FQSen  ,
    'RIF MDR FQ MDR' : TB_NumConfRIFMDR_FQMDR  ,
    'Atleast one' : TB_NumConfAtLeastOne    ,
    'Meningitis Peri' : TB_NumConfMeningitisPeri,
}

tb_case_indices = {
    'New cases' : TB_NewCases,
    'Retreated cases' : TB_RetreatCases
}

tb_art_char_indices = {
    'With TB infection' :  TB_ART_WithTBInfection,
    'With TB disease'   :  TB_ART_WithTBDisease,
    'Percent PTB'       :  TB_ART_PercPTB
}

tb_art_all_severity = {
    'Total' : 0,
    'Without serious illness':1,
    'With serious illness':2
}

tb_screening_options = {
    'g_sym_cgh2w' : TB_Scrn_g_sym_cgh2w,
    'g_sym_any'   : TB_Scrn_g_sym_any,
    'g_mwrd_sn'   : TB_Scrn_g_mwrd_sn,
    'g_sym_cgh2w_cxr_tb_sequential_pos' : TB_Scrn_g_sym_cgh2w_cxr_tb_sequential_pos,
    'g_sym_cgh2w_cxr_tb_sequential_neg' : TB_Scrn_g_sym_cgh2w_cxr_tb_sequential_neg,
    'g_sym_cgh2w_cxr_tb_parallel' : TB_Scrn_g_sym_cgh2w_cxr_tb_parallel,
    'g_sym_cgh2w_cxr_cad_sequential_pos' : TB_Scrn_g_sym_cgh2w_cxr_cad_sequential_pos,
    'g_sym_cgh2w_cxr_cad_sequential_neg' : TB_Scrn_g_sym_cgh2w_cxr_cad_sequential_neg,
    'g_sym_cgh2w_cxr_cad_parallel' : TB_Scrn_g_sym_cgh2w_cxr_cad_parallel,
    'g_sym_any_cxr_tb_sequential_pos' : TB_Scrn_g_sym_any_cxr_tb_sequential_pos,
    'g_sym_any_cxr_tb_sequential_neg' : TB_Scrn_g_sym_any_cxr_tb_sequential_neg,
    'g_sym_any_cxr_tb_parallel' : TB_Scrn_g_sym_any_cxr_tb_parallel,
    'g_sym_any_cxr_cad_sequential_pos' : TB_Scrn_g_sym_any_cxr_cad_sequential_pos,
    'g_sym_any_cxr_cad_sequential_neg' : TB_Scrn_g_sym_any_cxr_cad_sequential_neg,
    'g_sym_any_cxr_cad_parallel' : TB_Scrn_g_sym_any_cxr_cad_parallel,
    'h_clhiv_sym' : TB_Scrn_h_clhiv_sym,
    'h_hiv_mwrd_sn' : TB_Scrn_h_hiv_mwrd_sn,
    'h_hiv_w4ss' : TB_Scrn_h_hiv_w4ss,
    'h_hiv_crp' : TB_Scrn_h_hiv_crp,
    'h_hiv_cxr_abn' : TB_Scrn_h_hiv_cxr_abn,
    'h_hiv_w4ss_hiv_crp_sequential_pos' : TB_Scrn_h_hiv_w4ss_hiv_crp_sequential_pos,
    'h_hiv_w4ss_hiv_crp_sequential_neg' : TB_Scrn_h_hiv_w4ss_hiv_crp_sequential_neg,
    'h_hiv_w4ss_hiv_crp_parallel' : TB_Scrn_h_hiv_w4ss_hiv_crp_parallel,
    'h_hiv_w4ss_hiv_cxr_abn_sequential_pos' : TB_Scrn_h_hiv_w4ss_hiv_cxr_abn_sequential_pos,
    'h_hiv_w4ss_hiv_cxr_abn_sequential_neg' : TB_Scrn_h_hiv_w4ss_hiv_cxr_abn_sequential_neg,
    'h_hiv_w4ss_hiv_cxr_abn_parallel' : TB_Scrn_h_hiv_w4ss_hiv_cxr_abn_parallel,
    'h_hiv_w4ss_cxr_cad_sequential_pos' : TB_Scrn_h_hiv_w4ss_cxr_cad_sequential_pos,
    'h_hiv_w4ss_cxr_cad_sequential_neg' : TB_Scrn_h_hiv_w4ss_cxr_cad_sequential_neg,
    'h_hiv_w4ss_cxr_cad_parallel' : TB_Scrn_h_hiv_w4ss_cxr_cad_parallel,
    'c_cc_sym' : TB_Scrn_c_cc_sym,
    'c_cc_cxr_tb' : TB_Scrn_c_cc_cxr_tb,
    'c_hiv_w4ss_cc_cxr_tb_sequential_pos' : TB_Scrn_c_hiv_w4ss_cc_cxr_tb_sequential_pos,
    'c_hiv_w4ss_cc_cxr_tb_sequential_neg' : TB_Scrn_c_hiv_w4ss_cc_cxr_tb_sequential_neg,
    'c_hiv_w4ss_cc_cxr_tb_parallel' : TB_Scrn_c_hiv_w4ss_cc_cxr_tb_parallel,
    'c_hiv_w4ss_cxr_cad_sequential_pos' : TB_Scrn_c_hiv_w4ss_cxr_cad_sequential_pos,
    'c_hiv_w4ss_cxr_cad_sequential_neg' : TB_Scrn_c_hiv_w4ss_cxr_cad_sequential_neg,
    'c_hiv_w4ss_cxr_cad_parallel' : TB_Scrn_c_hiv_w4ss_cxr_cad_parallel,
}


tb_patients_opt = TB_screening_alg_patient_options()
tb_patient_screening_options = {
    
    # Pulmonary TB
    'Pulmonary TB HIV- 0-14'  : tb_patients_opt[TB_PTB_HIVn_014_grp],
    'Pulmonary TB HIV- 15+'   : tb_patients_opt[TB_PTB_HIVn_15p_grp],
    'Pulmonary TB HIV+ 0-9'   : tb_patients_opt[TB_PTB_HIVp_09_grp],
    'Pulmonary TB HIV+ 10-14' : tb_patients_opt[TB_PTB_HIVp_1014_grp],
    'Pulmonary TB HIV+ 15+ '  : tb_patients_opt[TB_PTB_HIVp_15p_grp],

    # Extra-Pulmonary TB
    'Extra-pulmonary TB HIV- 0-14'  : tb_patients_opt[TB_ETB_HIVn_014_grp],
    'Extra-pulmonary TB HIV- 15+'   : tb_patients_opt[TB_ETB_HIVn_15p_grp],
    'Extra-pulmonary TB HIV+ 0-9'   : tb_patients_opt[TB_ETB_HIVp_09_grp],
    'Extra-pulmonary TB HIV+ 10-14' : tb_patients_opt[TB_ETB_HIVp_1014_grp],
    'Extra-pulmonary TB HIV+ 15+ '  : tb_patients_opt[TB_ETB_HIVp_15p_grp]
}

tb_household_opt = TB_screening_alg_household_options()
tb_household_screening_options = {
    'Household 0 to 4'  : tb_household_opt[TB_HH0_4], 
    'Household 5 to 14' : tb_household_opt[TB_HH5_14],
    'Household 15+'     : tb_household_opt[TB_HH15p] 
}

tb_art_screen_opt = TB_screening_alg_art_options()
tb_art_screening_options = {
    'not serious':{
        'Age 0 - 9'   : tb_art_screen_opt[TB_ARTNotServere][TB_ART0_9], 
        'Age 10 - 14' : tb_art_screen_opt[TB_ARTNotServere][TB_ART10_14],
        'Age 15+'     : tb_art_screen_opt[TB_ARTNotServere][TB_ART15p]
    },
    'with serious illness':{
        'Age 0 - 9'   : tb_art_screen_opt[TB_ARTSevereIllness][TB_ART0_9], 
        'Age 10 - 14' : tb_art_screen_opt[TB_ARTSevereIllness][TB_ART10_14],
        'Age 15+'     : tb_art_screen_opt[TB_ARTSevereIllness][TB_ART15p]
    }
}

tb_hrg_opt = TB_screening_alg_hrg_options()
tb_hrg_screening_options ={
    'Prisoners'                                                                         : tb_hrg_opt[TB_HRG_Prisoners],
    'Miners exposed to silica '                                                         : tb_hrg_opt[TB_HRG_Miners],
    'People with risk factors for TB seeking health care'                               : tb_hrg_opt[TB_HRG_SeekingCare],
    'Populations with structural risk factors for TB and limited access to health care' : tb_hrg_opt[TB_HRG_StructuralRFs],
    'General population in settings with high TB'                                       : tb_hrg_opt[TB_HRG_HighTBPrev],
    'People with untreated fibrotic lesions on chest x-ray'                             : tb_hrg_opt[TB_HRG_UntreatedFibrosis],
}

tb_hrg_demographic_indices = {
    'Total pop'      : TG_HRG_Dem_TotalPop, 
    'Proportion 15+' : TG_HRG_Dem_Prop15p,
    'TB infected'    : TG_HRG_Dem_TBInfect,
    'TB diseased'    : TB_HRG_Dem_TBDisease,
    'Relative risk'  : TB_HRG_Dem_RelRisk,
    'PTB'            : TB_HRG_Dem_PTB
}

tb_test_ids = {
     'Clinical assessment: any symptom ' : TB_ClinicalAssessment, 
     'Chest X-ray [ digital (dxr) vs conventional (cxr) ] [ screening test ]' : TB_ChestXRay         , 
     'Computer-aided detection software for automated reading of digital chest radiographs [ screening test ]' : TB_ComputerAidedDtct , 
     'W3SS (3 symptom) single screening algorithm' : TB_W3SS              , 
     '4 symptom screening (no test) / History and physical examination and information on TB' : TB_4SymptomScreening , 
     'C-reactive protein with a cut-off of > 5 mg/L [ screening test ]' : TB_C_ReactiveProtein , 
     'Clinical assessment: any extra-pulmonary TB symptom* ' : TB_ClinicalExtraPulm , 
     'W4SS' : TB_W4SS              , 
     'Single Symptom screening' : TB_SingleSymptomScrn , 
     'Tuberculin Skin Test (TST) ' : TB_TuberculinSkinTest, 
     'TB antigen-based skin tests for the diagnosis of TB infection (TBST)  *, 0% ' : TB_AntigenSkinTest   , 
     'Interferon-Gamma Release Assay (IGRA)*, 100%' : TB_IGRA              , 
     'mWRD single screening algorithm for medical inpatients in settings with TB prevalence > 10%' : TB_mWRDPrevGT10      , 
     'First-line regimen (preferred): TDF + 3TC (or FTC) + DTG' : TB_FirstlinePreferred, 
     'First-line regimen (alternative): TDF + 3TC + EFV 400 mg' : TB_FirstlineAltern   , 
     'Special circumstances: TDF + 3TC (or FTC) + EFV 600mg' : TB_SpecialCircTDF_EFV, 
     'Special circumstances:  AZT + 3TC+ EFV 600mg' : TB_SpecialCircAZT    , 
     'Special circumstances:  TDF + 3TC (or FTC)+ PI' : TB_SpecialCircTDF_PI , 
     'Special circumstances:  TDF + 3TC (or FTC)+  RAL' : TB_SpecialCircTDF_RAL, 
     'Special circumstances:  TAF + 3TC (or FTC)+ DTG' : TB_SpecialCircTAF    , 
     'Special circumstances:  ABC+ 3TC + DTG' : TB_SpecialCircABC    , 
     'First-line regimen (preferred):  ABC + 3TC + DTG' : TB_FirstlineABC_DTG  , 
     'First-line regimen (alternative): ABC + 3TC + LPV/r' : TB_FirstlineABC_LPV  , 
     'First-line regimen (alternative): TAF + 3TC (or FTC) + DTG' : TB_FirstlineTAF_DTG  , 
     'Special circumstances:  ABC+ 3TC + EFV (or NVP)' : TB_SpecialCircABC_EFV, 
     'Special circumstances: ABC + 3TC + RAL' : TB_SpecialCircABC_RAL, 
     'Special circumstances: AZT + 3TC + EFV(or NVP)' : TB_SpecialCircAZT_LPV, 
     'Special circumstances: AZT + 3TC + LPV/r (or RAL)' : TB_SpecialCircAZT_EFV, 
}