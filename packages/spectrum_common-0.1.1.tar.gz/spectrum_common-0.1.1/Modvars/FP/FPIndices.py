from SpectrumCommon.Const.FP import *

fp_age_indices = {
    'All Ages' : FP_All_Ages,
    'Age 15 to 19'   : FP_A15_19,
    'Age 20 to 24'   : FP_A20_24,
    'Age 25 to 29'   : FP_A25_29,
    'Age 30 to 34'   : FP_A30_34,
    'Age 35 to 39'   : FP_A35_39,
    'Age 40 to 44'   : FP_A40_44,
    'Age 45 to 49'   : FP_A45_49,
}

fp_method_indices = {
  #'All methods' : FP_all_methods ,
  'Condom(Female)' : FP_CondomFM,
  'Condom(Male)' : FP_CondomML,
  'Female sterilization' : FP_fster,
  'Male sterilization' : FP_mster,
  'Vaginal barrier' : FP_vag_barrier,
  'VFT' : FP_VFT,
  'Withdrawal' : FP_withdrawal,
  'Periodic Abstinance' : FP_PerAbst,
  'Traditional' : FP_Traditional,
  'Injectable 3 month' : FP_inj3month,
  'Injectable 2 month' : FP_inj2month,
  'Injectable 1 month' : FP_inj1month,
  'Injectable 6 month' : FP_inj6month,
  'Uninject' : FP_Uninject,
  'Implanon' : FP_Implanon,
  'Jadelle' : FP_Jadelle,
  'Sino implant' : FP_Sino_Implant,
  'Standard Pill' : FP_StandardPill,
  'Progestin' : FP_Progestin,
  'Peri coital' : FP_Peri_coital ,
  'IUD Copper' : FP_IUDCopper,
  'IUD LngIus' : FP_IUDLngIus,
  'LAM' : FP_LAM,
  'SDM' : FP_SDM,
  'other' : FP_other,
  'custom methods':f'{FP_LastDefMethod+1} - {FP_Max_Methods}'
}

fp_all_method_indices ={
    'All methods' : FP_all_methods,
}
fp_all_method_indices.update(fp_method_indices)


fp_need_indices = {
 'All need' : FP_all_need,
 'Spacing ' : FP_spacing,
 'Limiting' : FP_limiting
}

fp_child_survival_indices = {
    'Per birth risk'          : FP_PerBirthRisk,
    'Fertility Adjusted IMR'  : FP_FertAdjIMR,
    'Fertility Adjusted U5MR' : FP_FertAdjU5MR,
    'Relative risky birth'    : FP_RelRiskyBirth,
    'Relative IMR'            : FP_RelIMR,
    'Relative U5MR'           : FP_RelU5MR      
}

# PAC Input Constants 
fp_pac_inputs_indices = {
    'PerAbortLegal'           : FP_PerAbortLegal,
    'PerIllAbortTreat'        : FP_PerIllAbortTreat,
    'PerLegalAbortTreat'      : FP_PerLegalAbortTreat,
    'MMRMaternDeath'          : FP_MMRMaternDeath,
    'PerMaternDeathAbortion'  : FP_PerMaternDeathAbortion ,
    'MortalityUntreatVsTreat' : FP_MortalityUntreatVsTreat,
    'AnnPostAbortCare'        : FP_AnnPostAbortCare,
    'CostAbortCompTreat'      : FP_CostAbortCompTreat,
    'CostCounServCase'        : FP_CostCounServCase,
}
fp_pac_outputs_indices = {

    'Wanted pregnancies'    : FP_WantedPreg,
    'Unwanted pregnancies'  : FP_UnwantedPreg,
    'Per abortion need treatment received' : FP_PerAbortNeedTreatReceive,
    'MMR births one' : FP_MMRBirthsOne,
    'Abortion deaths per abortion' : FP_AbortDeathsPerAbort,
    'Death treat Ill Abort      ' : FP_DeathTreatIllAbort,
    'Death untreat Ill Abort    ' : FP_DeathUntreatIllAbort,
    'MD Total          ' : FP_MDTotal,
    'MD WantBirths     ' : FP_MDWantBirths,
    'MD UnwantBirths   ' : FP_MDUnwantBirths, 
    'MD TreatIllAbort  ' : FP_MDTreatIllAbort, 
    'MD UntreatIllAbort' : FP_MDUntreatIllAbort, 
    'TotDeathAvert' : FP_TotDeathAvert, 
    'Births' : FP_Births, 
    'WantedBirths' : FP_WantedBirths, 
    'UnwantedBirths' : FP_UnwantedBirths , 
    'Abortions' : FP_Abortions, 
    'IllAbortions' : FP_IllAbortions, 
    'IllAbortNoTreat' : FP_IllAbortNoTreat, 
    'IllAbortTreat' : FP_IllAbortTreat, 
    'TreatIllAbort' : FP_TreatIllAbort, 
    'UntreatIllAbort' : FP_UntreatIllAbort, 
    'MMR' : FP_MMR, 
    'MMRBirthsTwo' : FP_MMRBirthsTwo, 
    'MMRAbort' : FP_MMRAbort, 
    'MaternDeathAbort' : FP_MaternDeathAbort, 
    'LivesSaved' : FP_LivesSaved, 
    'CostTreatUnsafeAbort' : FP_CostTreatUnsafeAbort   , 
    'CostPerMaternDeathAvert ' : FP_CostPerMaternDeathAvert, 
}

fp_lam_indices = {
    'LAM 0 to 1' : FP_LAM0_1,
    'LAM 2 to 3' : FP_LAM2_3,
    'LAM 4 to 5' : FP_LAM4_5,
}

# Pregnancy constants 
fp_pregnancies_indices = {
    'All pregnancies' : FP_all_PREG,
    'Wanted pregnancies' : FP_wanted,
    'Unwanted pregnancies' : FP_unwanted,
    'Mistimed pregnancies' : FP_mistimed
}

fp_rr_birth_order_indices = {  
    'First birth'            : FP_RRFirstBirth,
    'Second to third births' : FP_RRSecToThirdBirth,
    'More than four births'  : FP_RRMoreFourBirth
}
fp_rr_age_order_indices = {
    'Less than 18'   : FP_RRLess18,
    '18 to 34'       : FP_RR18To34,
    'More than 34'   : FP_RRMore34
}
fp_rr_birth_interval_indices = {
    # 'First birth'            : FP_RRFirstBirth, 
    'Less 18 Months'     : FP_RRLess18Months,
    '18 to 23Months'     : FP_RR18to23Months,
    'More than 24Months'     : FP_RRMore24Months
}
fp_rr_advance_indices = {
    
    'RR Intercept' : FP_RRIntrcept,
    'RR C1'        : FP_RRC1,
    'RR C2'        : FP_RRC2 
}

fp_rr_mothers_age_indices = {
    'RR birth order greater than 3' : FP_RRBOGreater3,
    'RR mothers age Greater than 35'  : FP_RRMAGreat35,
    'RR mothers age 18 to 34'   : FP_RRMA18To34 
}