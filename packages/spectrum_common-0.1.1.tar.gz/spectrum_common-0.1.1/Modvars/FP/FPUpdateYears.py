from SpectrumCommon.Modvars.FP.FPModvarShapes import FP_modvar_shapes
from SpectrumCommon.Modvars.GB.GBDefs import gb_update_years

def FP_UpdateYears(projection, new_projection, params):
    gb_update_years(projection, params, FP_modvar_shapes)
    pass