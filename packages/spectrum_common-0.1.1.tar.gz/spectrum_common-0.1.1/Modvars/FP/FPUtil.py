from SpectrumCommon.Const.FP import *

def GetFP_methodName(m):
    result = ''
    if m == FP_CondomFM:
        result = 'GB_stCondomFM'
    elif m == FP_CondomML:
        result = 'GB_stCondomML'
    elif m == FP_fster:
        result = 'FP_stFemaleSt'
    elif m == FP_IUDCopper:
        result = 'GB_stIUDCopper'
    elif m == FP_IUDLngIus:
        result = 'GB_stIUDLngIus' 
    elif m == FP_mster:
        result = 'FP_stMaleSt'
    elif m == FP_vag_barrier:
        result = 'FP_stVagBarr'
    elif m == FP_VFT:
        result = 'GB_stSpermicides'
    elif m == FP_withdrawal:
        result = 'FP_stWithdrawal'
    elif m == FP_other:
        result = 'FP_stOther'
    elif m == FP_LAM:
        result = 'FP_stLAM'
    elif m == FP_SDM:
        result = 'GB_stSDM'
    elif m == FP_inj3month:
        result = 'GB_st3MonthDepoProvera'
    elif m == FP_inj2month:
        result = 'GB_st2MonthNoristerat'
    elif m == FP_inj1month:
        result = 'GB_st1monthLunelle'
    elif m == FP_inj6month:
        result = 'GB_st6Month'
    elif m == FP_Uninject:
        result = 'GB_stUninject'
    elif m == FP_Implanon:
        result = 'GB_stImplanon3Years'
    elif m == FP_Jadelle:
        result = 'GB_stJadelle5years'
    elif m == FP_Sino_Implant:
        result = 'GB_stSinoImplant4years'
    elif m == FP_StandardPill:
        result = 'GB_stStandardDailyRegiment'
    elif m == FP_Progestin:
        result = 'GB_stProgestinOnly'
    elif m == FP_Peri_coital:
        result = 'GB_stPeriCoitalContraception'
    elif m == FP_PerAbst:
        result = 'FP_stRhythm'
    elif m == FP_Traditional:
        result = 'GB_stOtherTraditional'
    # else:
    #     result = ''
    return result