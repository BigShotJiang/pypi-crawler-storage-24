# Contains methods for setting up IHT ModVars

import numpy as np

import SpectrumCommon.Const.GB.GBConst as gbc

import SpectrumCommon.Const.IH as ihc

import SpectrumCommon.Const.IH.IHModVarFields as ihf

#######################################################################################################
#                                                                                                     #
#                                       Programme areas and subgroups                                 #
#                                                                                                     #
#######################################################################################################

def IH_create_prog_area_rec(ID: str, name: str, string_const: str, active: bool):

    return {
        ihf.IH_PROG_AREA_ID               : ID,
        ihf.IH_PROG_AREA_NAME             : name,
        ihf.IH_SUBGROUP_STR_CONSTANT      : string_const,
        ihf.IH_PROG_AREA_SUBGROUP_RECORDS : [],
        ihf.IH_PROG_AREA_ACTIVE           : active,
        ihf.IH_PROG_AREA_CUSTOM           : False,
    }

def IH_create_prog_area_subgroup_rec(ID: str, name: str, string_const: str, active: bool):

    return {
        ihf.IH_SUBGROUP_ID           : ID,
        ihf.IH_SUBGROUP_NAME         : name,
        ihf.IH_SUBGROUP_STR_CONSTANT : string_const,
        ihf.IH_SUBGROUP_ACTIVE       : active,
        ihf.IH_SUBGROUP_CUSTOM       : False,
    }

# This creates a programme area record with only enough info in it to identify and display it in a list.
def IH_create_prog_area_rec_ID_info_only(ID: str, name: str, string_const: str):

    return {
        ihf.IH_PROG_AREA_ID               : ID,
        ihf.IH_PROG_AREA_NAME             : name,
        ihf.IH_SUBGROUP_STR_CONSTANT      : string_const,
        ihf.IH_PROG_AREA_SUBGROUP_RECORDS : [],
    }

# This creates a subgroup record with only enough info in it to identify and display it in a list.
def IH_create_prog_area_subgroup_rec_ID_info_only(ID: str, name: str, string_const: str):

    return {
        ihf.IH_SUBGROUP_ID           : ID,
        ihf.IH_SUBGROUP_NAME         : name,
        ihf.IH_SUBGROUP_STR_CONSTANT : string_const,
    }

#######################################################################################################
#                                                                                                     #
#                                       Delivery channels                                             #
#                                                                                                     #
#######################################################################################################

def IH_create_deliv_chan_rec(ID: str, name: str, string_constant: str, active: bool):

    return {
        ihf.IH_DELIV_CHAN_ID           : ID,
        ihf.IH_DELIV_CHAN_NAME         : name,
        ihf.IH_DELIV_CHAN_STR_CONSTANT : string_constant,
        ihf.IH_DELIV_CHAN_ACTIVE       : active,
        ihf.IH_DELIV_CHAN_CUSTOM       : False,
    }

def IH_init_deliv_chan_records(costing_mode = int):
    deliv_chan_dict_list = []

    if costing_mode == gbc.GB_LIST_COSTING_MODE:

        deliv_chan_dict_list.append(
            IH_create_deliv_chan_rec(
                str(ihc.IH_COMMUNITY_CHAN_MST_ID), 
                "Community", 
                "GB_stCommunity",
                True,
            )
        )

        deliv_chan_dict_list.append(
            IH_create_deliv_chan_rec(
                str(ihc.IH_OUTREACH_CHAN_MST_ID), 
                "Outreach", 
                "GB_stOutreach",
                True,
            )
        )

        # Keep name as Clnic to match desktop.
        deliv_chan_dict_list.append(
            IH_create_deliv_chan_rec(
                str(ihc.IH_GEN_OUTPATIENT_SERV_CHAN_MST_ID), 
                "Clinic", 
                "GB_stClinic",
                True,
            )
        )

        # Keep name as Hospital to match desktop.
        deliv_chan_dict_list.append(
            IH_create_deliv_chan_rec(
                str(ihc.IH_FIRST_REFERRAL_CHAN_MST_ID), 
                "Hospital", 
                "GB_stHospital",
                True,
            )
        )

    else:
        
        deliv_chan_dict_list.append(
            IH_create_deliv_chan_rec(
                str(ihc.IH_COMMUNITY_CHAN_MST_ID), 
                "Community", 
                "GB_stCommunity",
                True,
            )
        )

        deliv_chan_dict_list.append(
            IH_create_deliv_chan_rec(
                str(ihc.IH_OUTREACH_CHAN_MST_ID), 
                "Outreach", 
                "GB_stOutreach",
                True,
            )
        )

        deliv_chan_dict_list.append(
            IH_create_deliv_chan_rec(
                str(ihc.IH_PREHOSPITAL_EMERGENCY_CHAN_MST_ID), 
                "Prehospital emergency", 
                "GB_stPrehospitalEmergency",
                True,
            )
        )

        deliv_chan_dict_list.append(
            IH_create_deliv_chan_rec(
                str(ihc.IH_GEN_OUTPATIENT_SERV_CHAN_MST_ID), 
                "General outpatient services", 
                "GB_stGenOutpatientServices",
                True,
            )
        )

        deliv_chan_dict_list.append(
            IH_create_deliv_chan_rec(
                str(ihc.IH_FIRST_REFERRAL_CHAN_MST_ID), 
                "First referral", 
                "GB_stFirstReferral",
                True,
            )
        )

        deliv_chan_dict_list.append(
            IH_create_deliv_chan_rec(
                str(ihc.IH_SEC_REFERRAL_CHAN_MST_ID), 
                "Second referral and above", 
                "GB_stSecReferralAndAbove",
                True,
            )
        )

    return deliv_chan_dict_list

#######################################################################################################
#                                                                                                     #
#                                       Delivery channel packages                                     #
#                                                                                                     #
#######################################################################################################

def IH_create_deliv_chan_pack_rec(ID: str, name: str, active: bool):

    return {
        ihf.IH_DELIV_CHAN_PACK_ID     : ID,
        ihf.IH_DELIV_CHAN_PACK_NAME   : name,
        ihf.IH_DELIV_CHAN_PACK_ACTIVE : active,
        ihf.IH_DELIV_CHAN_PACK_CUSTOM : False,
    }

#######################################################################################################
#                                                                                                     #
#                                       National programmes                                           #
#                                                                                                     #
#######################################################################################################

def IH_create_nat_prog_rec(ID: str, name: str, active: bool):

    return {
        ihf.IH_NAT_PROG_ID     : ID,
        ihf.IH_NAT_PROG_NAME   : name,
        ihf.IH_NAT_PROG_ACTIVE : active,
        ihf.IH_NAT_PROG_CUSTOM : False,
    }

#######################################################################################################
#                                                                                                     #
#                                       Audit records                                                 #
#                                                                                                     #
#######################################################################################################

def IH_create_audit_rec(status_overridden: bool, comment: str):

    return {
        ihf.IH_AUDIT_STATUS_OVERRIDDEN : status_overridden,
        ihf.IH_AUDIT_COMMENT           : comment,
    }

#######################################################################################################
#                                                                                                     #
#                                            Results                                                  #
#                                                                                                     #
#######################################################################################################

def IH_init_prog_area_staff_year_arr(num_prog_areas: int, num_staff_types: int, num_years: int, value = 0.0):
    return np.full((num_prog_areas, num_staff_types, num_years), value, gbc.GB_CALC_FLOAT_TYPE)

#######################################################################################################
#                                                                                                     #
#                                    Health system administrative units                               #
#                                                                                                     #
#######################################################################################################

def IH_create_health_sys_admin_unit_rec(ID: str, name: str, string_const: str, active: bool):

    return {
        ihf.IH_HEALTH_SYS_ADMIN_UNIT_ID               : ID,
        ihf.IH_HEALTH_SYS_ADMIN_UNIT_NAME             : name,
        ihf.IH_HEALTH_SYS_ADMIN_UNIT_STR_CONSTANT     : string_const,
        ihf.IH_HEALTH_SYS_ADMIN_UNIT_ACTIVE           : active,
        ihf.IH_HEALTH_SYS_ADMIN_UNIT_CUSTOM           : False,
        ihf.IH_HEALTH_SYS_ADMIN_UNIT_NUMBER           : 0,
    }


def IH_init_health_sys_admin_unit_records():
    health_sys_admin_unit_dict_list = []

    health_sys_admin_unit_dict_list.append(
        IH_create_health_sys_admin_unit_rec(
            str(ihc.IH_NATIONAL_HSAU_MST_ID), 
            "National", 
            "GB_stNational",
            True,
        )
    )

    health_sys_admin_unit_dict_list.append(
        IH_create_health_sys_admin_unit_rec(
            str(ihc.IH_PROVINCE_HSAU_MST_ID), 
            "Province", 
            "GB_stProvince",
            True,
        )
    )

    health_sys_admin_unit_dict_list.append(
        IH_create_health_sys_admin_unit_rec(
            str(ihc.IH_DISTRICT_HSAU_MST_ID), 
            "District", 
            "GB_stDistrict",
            True,
        )
    )

    health_sys_admin_unit_dict_list.append(
        IH_create_health_sys_admin_unit_rec(
            str(ihc.IH_ADMIN_LEVEL_4_HSAU_MST_ID), 
            "Admin level 4", 
            "GB_stAdminLevel4",
            True,
        )
    )

    health_sys_admin_unit_dict_list.append(
        IH_create_health_sys_admin_unit_rec(
            str(ihc.IH_ADMIN_LEVEL_5_HSAU_MST_ID), 
            "Admin level 5", 
            "GB_stAdminLevel5",
            True,
        )
    )

    return health_sys_admin_unit_dict_list