from datetime import date
from copy import deepcopy

import SpectrumCommon.Const.GB as gbc
import SpectrumCommon.Const.PJ.PJNTags as pjmvt
import SpectrumCommon.Modvars.GB.GBUtil as gbu

import SpectrumCommon.Const.IH.IHConstLink as ihcl
import SpectrumCommon.Const.IH.IHTags as ihmvt
import SpectrumCommon.Modvars.IH.IHModVarDefs as ihmvd
import SpectrumCommon.Modvars.IH.IHModVarUtil as ihmvu

import SpectrumCommon.Modvars.IH.IHReadDatabases as ihrd

def init_modvars(countryID, first_year, final_year, extra):
    '''
        Initializes IHT Configuration MVs for new IHT projections.

            Parameters:
                countryID (string):  Ex: BEN for Benin.

                first_year (int): First year selected by user.

                final_year (int): Final year selected by user. 

                extra (dict): Any other fields.  
 
            Returns:
                mod_vars_rec (dict): MVs.
    '''
    
    # Load databases

    IHT_costing_on = extra[gbc.GB_IHT_ON] if gbc.GB_IHT_ON in extra else False
    TB_costing_on = extra[gbc.GB_TB_COSTING_ON] if gbc.GB_TB_COSTING_ON in extra else False
    LiST_costing_on = extra[gbc.GB_LIST_COSTING_ON] if gbc.GB_LIST_COSTING_ON in extra else False
    costing_mode_mod_vars = {
        pjmvt.GB_IHTOnTag       : IHT_costing_on,
        pjmvt.GB_TBCostingOnTag : TB_costing_on,
        pjmvt.GB_LCOnTag        : LiST_costing_on,
    }

    costing_mode = gbu.get_costing_mode(costing_mode_mod_vars)

    group_DB, group_DB_IHT_ID_info_only = ihrd.IH_load_group_DB(costing_mode)

    value_bool = False
    value_int = 0
    value_flt = 0.0
    value_str = ''
    value_date = date.today().strftime("%B %d, %Y"),   

    prog_area_rec_list = ihrd.IH_init_prog_area_records(group_DB)
    deliv_chan_rec_list = ihmvd.IH_init_deliv_chan_records(costing_mode)
    health_sys_admin_unit_rec_list = ihmvd.IH_init_health_sys_admin_unit_records()

    # If TB costing is on, we'll need access to the IHT programme areas well, because the user is allowed to move IHT interventions into TB. 
    prog_area_records_IHT_ID_info_only = []

    if TB_costing_on:
        prog_area_records_IHT_ID_info_only = ihrd.IH_init_prog_area_records_ID_info_only(group_DB_IHT_ID_info_only)

    # deliv_chan_pack_record_list []
    # nat_prog_record_list = []
    # audit_record_list = []
    # locked_area_record_list = []

    num_prog_areas = ihmvu.get_IH_num_prog_areas(prog_area_rec_list)
    #num_years_inputs = final_year - first_year + 1 
    num_years_outputs = final_year - first_year + 1

    staff_cap_utiliz_list = ihmvd.IH_init_prog_area_staff_year_arr(num_prog_areas, ihcl.HW_NUM_STATIC_STAFF_TYPES, num_years_outputs, 0.0)

    # add flag modvars to one modes modvar. If flag is in set, turn mode on. Else, turn mode off. Just like how you will do with intervention sets in IC.

    mod_vars_rec = {
        ihmvt.IH_VERSION_TAG_V1                                    : 1,
        ihmvt.IH_HLTH_SERV_ANAL_MODE_MST_ID_TAG_V1                 : value_int,  # Programme or Delivery Channel Mode
        ihmvt.IH_PROG_AREA_DELIV_CHAN_FILTER_MST_ID_TAG_V1         : value_int, # programme area or delivery channel mstID
        ihmvt.IH_MAX_CUST_INTERV_MST_ID_TAG_V1                     : value_int,      
        ihmvt.IH_MOH_BUDGET_TAG_V1                                 : value_flt,                 
        ihmvt.IH_DATA_CHANGED_TAG_V1                               : value_bool, 
        ihmvt.IH_PROJ_VALID_TAG_V1                                 : value_bool, 
        ihmvt.IH_USING_ADOL_STRATA_MODE_TAG_V1                     : value_bool, 
        ihmvt.IH_USING_DIS_SPEC_COST_MODE_TAG_V1                   : value_bool, 
        ihmvt.IH_USING_PHC_MODE_TAG_V1                             : value_bool, 
        ihmvt.IH_USING_DEF_MED_STAFF_TYPES_TAG_V1                  : value_bool, 
        ihmvt.IH_USING_DEF_FAC_TYPES_TAG_V1                        : value_bool, 
        ihmvt.IH_USING_MOH_BUDGET_RES_TAG_V1                       : value_bool, 
        ihmvt.IH_USING_HPV_PROG_AREA_TAG_V1                        : value_bool, 
        ihmvt.IH_USING_WORK_HLTH_PROG_AREA_TAG_V1                  : value_bool, 
        ihmvt.IH_USING_TP_FROM_TIME_TAG_V1                         : value_bool, 
        ihmvt.IH_USING_TB_IMPACT_CALCS_TP_TAG_V1                   : value_bool, 
        ihmvt.IH_USING_TB_DAT_TP_TAG_V1                            : value_bool, 
        ihmvt.IH_USING_LOCAL_CURR_TAG_V1                           : value_bool, 
        ihmvt.IH_FILE_NAME_TAG_V1                                  : value_str,                          
        ihmvt.IH_PROJ_VALID_DATE_TAG_V1                            : value_date,             
        ihmvt.IH_PROG_AREA_RECORDS_TAG_V1                          : prog_area_rec_list,              
        ihmvt.IH_DELIV_CHAN_RECORDS_TAG_V1                         : deliv_chan_rec_list,            
        ihmvt.IH_PERC_PROG_MGMT_COSTS_PHC_VIS_TAG_V1               : value_bool,       
        ihmvt.IH_HR_FACTOR_PHC_TAG_V1                              : value_flt,         
        ihmvt.IH_LG_PERC_DRUG_SUPP_COSTS_PHC_TAG_V1                : value_int,    
        ihmvt.IH_SHOW_INACTIVE_PROG_AREAS_EXIST_INTERV_V1          : value_bool,
        ihmvt.IH_SHOW_INACTIVE_PROG_AREAS_EXIST_DRUG_SUPP_V1       : value_bool,
        ihmvt.IH_ENTER_UNIT_COSTS_ALL_YEARS_DRUG_SUPP_V1           : value_bool,
        ihmvt.IH_HEALTH_SYS_ADMIN_UNIT_RECORDS_TAG                 : health_sys_admin_unit_rec_list,

        # Results
        ihmvt.IH_RES_STAFF_CAP_UTILIZATION_STATIC_TAG_V1           : deepcopy(staff_cap_utiliz_list),
        ihmvt.IH_RES_STAFF_CAP_UTILIZATION_DYNAMIC_TAG_V1          : deepcopy(staff_cap_utiliz_list),
    }

    if TB_costing_on:
        # Disease-specific costing (DSC), TB Costing

        # TB costing
        
        # If TB costing is on, we'll need access to the IHT programme areas as well, because the user is allowed to move IHT interventions into TB. 
        mod_vars_rec[ihmvt.IH_PROG_AREA_RECORDS_IHT_ID_INFO_ONLY_TAG_V1] = prog_area_records_IHT_ID_info_only

    #Debugging
    #with open('C:\Proj\IHTSampleFile.JSON', 'w') as f:
    #   json.dump(mod_vars_dict, f)

    return mod_vars_rec

    