import SpectrumCommon.Const.GB.GBConst as gbc

import SpectrumCommon.Const.IH.IHModVarFields as ihmvf

#######################################################################################################
#                                                                                                     #
#                                       Programme areas                                               #
#                                                                                                     #
#######################################################################################################

def get_IH_num_prog_areas(prog_area_records: list):
    return len(prog_area_records)

def get_IH_prog_area_rec(prog_area_records: list, ID: str):
    prog_area_recs = [prog_area_rec for prog_area_rec in prog_area_records if prog_area_rec[ihmvf.IH_PROG_AREA_ID] == ID]
    return prog_area_recs[0] if len(prog_area_recs) > 0 else gbc.GB_NOT_FOUND

    # prog_area_dict = None
    
    # pa = 0
    # stop = False
    # num_prog_areas = get_IH_num_prog_areas(prog_area_dict_list)

    # while (pa < num_prog_areas) and (not stop):

    #     prog_area_ID = get_IH_prog_area_ID(prog_area_dict_list[pa])

    #     if prog_area_ID == ID:
    #         prog_area_dict = prog_area_dict_list[pa]
    #         stop = True

    #     pa += 1

    # return prog_area_dict

def get_IH_prog_area_idx(prog_area_records: list, ID: str):
    indices = [idx for (idx, prog_area_rec) in enumerate(prog_area_records) if prog_area_rec[ihmvf.IH_PROG_AREA_ID] == ID]
    return indices[0] if len(indices) > 0 else gbc.GB_NOT_FOUND

    # idx = gbc.GB_NOT_FOUND
    
    # pa = 0
    # stop = False
    # num_prog_areas = get_IH_num_prog_areas(prog_area_dict_list)

    # while (pa < num_prog_areas) and (not stop):

    #     prog_area_ID = get_IH_prog_area_ID(prog_area_dict_list[pa])

    #     if prog_area_ID == ID:
    #         idx = pa
    #         stop = True

    #     pa += 1

    # return idx

###

def get_IH_prog_area_name(prog_area_rec: dict):
    return prog_area_rec[ihmvf.IH_PROG_AREA_NAME]

def set_IH_prog_area_name(prog_area_rec: dict, value: str):
    prog_area_rec[ihmvf.IH_PROG_AREA_NAME] = value

###

def get_IH_prog_area_string_constant(prog_area_rec: dict):
    return prog_area_rec[ihmvf.IH_PROG_AREA_STR_CONSTANT]

def set_IH_prog_area_string_constant(prog_area_rec: dict, value: str):
    prog_area_rec[ihmvf.IH_PROG_AREA_STR_CONSTANT] = value

###

def get_IH_prog_area_ID(prog_area_rec: dict):
    return prog_area_rec[ihmvf.IH_PROG_AREA_ID]

def set_IH_prog_area_ID(prog_area_rec: dict, value: str):
    prog_area_rec[ihmvf.IH_PROG_AREA_ID] = value

###

def get_IH_prog_area_active(prog_area_rec: dict):
    return prog_area_rec[ihmvf.IH_PROG_AREA_ACTIVE]

def set_IH_prog_area_active(prog_area_rec: dict, value: bool):
    prog_area_rec[ihmvf.IH_PROG_AREA_ACTIVE] = value

###

def get_IH_prog_area_custom(prog_area_rec: dict):
    return prog_area_rec[ihmvf.IH_PROG_AREA_CUSTOM]

def set_IH_prog_area_custom(prog_area_rec: dict, value: bool):
    prog_area_rec[ihmvf.IH_PROG_AREA_CUSTOM] = value

###

def get_IH_prog_area_subgroups(prog_area_dict: dict):
    return prog_area_dict[ihmvf.IH_PROG_AREA_SUBGROUP_RECORDS]

#######################################################################################################
#                                                                                                     #
#                                       Subgroups                                                     #
#                                                                                                     #
#######################################################################################################

def get_IH_num_subgroups(subgroup_records: list):
    return len(subgroup_records)

def get_IH_subgroup_rec(prog_area_records: list, prog_area_ID: str, ID: str):
    prog_area_rec = get_IH_prog_area_rec(prog_area_records, prog_area_ID)
    subgroup_records = get_IH_prog_area_subgroups(prog_area_rec)

    subgroup_recs = [subgroup_rec for subgroup_rec in subgroup_records if subgroup_rec[ihmvf.IH_SUBGROUP_ID] == ID]
    return subgroup_recs[0] if len(subgroup_recs) > 0 else gbc.GB_NOT_FOUND

    # sg = 0
    # stop = False
    # num_subgroups = get_IH_num_subgroups(subgroup_records)

    # while (sg < num_subgroups) and (not stop):

    #     subgroup_ID = get_IH_subgroup_ID(subgroup_records[sg])

    #     if subgroup_ID == ID:
    #         subgroup_rec = subgroup_records[sg]
    #         stop = True

    #     sg += 1

    # return subgroup_rec

def get_IH_subgroup_idx(prog_area_records: list, prog_area_ID: str, ID: str):
    prog_area_rec = get_IH_prog_area_rec(prog_area_records, prog_area_ID)
    subgroup_records = get_IH_prog_area_subgroups(prog_area_rec)
    
    indices = [idx for (idx, subgroup_rec) in enumerate(subgroup_records) if subgroup_rec[ihmvf.IH_SUBGROUP_ID] == ID]
    return indices[0] if len(indices) > 0 else gbc.GB_NOT_FOUND

    # idx = gbc.GB_NOT_FOUND

    # sg = 0
    # stop = False
    # num_subgroups = get_IH_num_subgroups(subgroup_records)

    # while (sg < num_subgroups) and (not stop):

    #     subgroup_ID = get_IH_subgroup_ID(subgroup_records[sg])

    #     if subgroup_ID == ID:
    #         idx = sg
    #         stop = True

    #     sg += 1

    # return idx

def get_IH_subgroup_name(subgroup_rec: dict):
    return subgroup_rec[ihmvf.IH_SUBGROUP_NAME]

def set_IH_subgroup_name(subgroup_rec: dict, value: str):
    subgroup_rec[ihmvf.IH_SUBGROUP_NAME] = value

###

def get_IH_subgroup_string_constant(subgroup_rec: dict):
    return subgroup_rec[ihmvf.IH_SUBGROUP_STR_CONSTANT]

def set_IH_subgroup_string_constant(subgroup_rec: dict, value: str):
    subgroup_rec[ihmvf.IH_SUBGROUP_STR_CONSTANT] = value

###

def get_IH_subgroup_ID(subgroup_rec: dict):
    return subgroup_rec[ihmvf.IH_SUBGROUP_ID]

def set_IH_subgroup_ID(subgroup_rec: dict, value: str):
    subgroup_rec[ihmvf.IH_SUBGROUP_ID] = value

###

def get_IH_subgroup_active(subgroup_rec: dict):
    return subgroup_rec[ihmvf.IH_SUBGROUP_ACTIVE]

def set_IH_subgroup_active(subgroup_rec: dict, value: bool):
    subgroup_rec[ihmvf.IH_SUBGROUP_ACTIVE] = value

###

def get_IH_subgroup_custom(subgroup_rec: dict):
    return subgroup_rec[ihmvf.IH_SUBGROUP_CUSTOM]

def set_IH_subgroup_custom(subgroup_rec: dict, value: bool):
    subgroup_rec[ihmvf.IH_SUBGROUP_CUSTOM] = value

#######################################################################################################
#                                                                                                     #
#                                      Delivery channels                                              #
#                                                                                                     #
#######################################################################################################

def get_IH_num_deliv_chans(deliv_chan_records: list):
    return len(deliv_chan_records)

def get_IH_deliv_chan_rec_from_curr_ID(deliv_chan_records: list, curr_ID: int):
    return deliv_chan_records[curr_ID - 1]

def get_IH_deliv_chan_rec(deliv_chan_records: list, ID: str):
    deliv_chan_recs = [deliv_chan_rec for deliv_chan_rec in deliv_chan_records if deliv_chan_rec[ihmvf.IH_DELIV_CHAN_ID] == ID]
    return deliv_chan_recs[0] if len(deliv_chan_recs) > 0 else gbc.GB_NOT_FOUND

    # deliv_chan_rec = None
    
    # dc = 0
    # stop = False
    # num_deliv_chans = get_IH_num_deliv_chans(deliv_chan_records)

    # while (dc < num_deliv_chans) and (not stop):

    #     deliv_chan_ID = get_IH_deliv_chan_ID(deliv_chan_records[dc])

    #     if deliv_chan_ID == ID:
    #         deliv_chan_rec = deliv_chan_records[dc]
    #         stop = True

    #     dc += 1

    # return deliv_chan_rec

def get_IH_deliv_chan_idx(deliv_chan_records: list, ID: str):
    indices = [idx for (idx, deliv_chan_rec) in enumerate(deliv_chan_records) if deliv_chan_rec[ihmvf.IH_DELIV_CHAN_ID] == ID]
    return indices[0] if len(indices) > 0 else gbc.GB_NOT_FOUND

    # idx = gbc.GB_NOT_FOUND
    
    # dc = 0
    # stop = False
    # num_deliv_chans = get_IH_num_deliv_chans(deliv_chan_records)

    # while (dc < num_deliv_chans) and (not stop):

    #     deliv_chan_ID = get_IH_deliv_chan_ID(deliv_chan_records[dc])

    #     if deliv_chan_ID == ID:
    #         idx = dc
    #         stop = True

    #     dc += 1

    # return idx

###

def get_IH_deliv_chan_name(deliv_chan_rec: dict):
    return deliv_chan_rec[ihmvf.IH_DELIV_CHAN_NAME]

def set_IH_deliv_chan_name(deliv_chan_rec: dict, value: str):
    deliv_chan_rec[ihmvf.IH_DELIV_CHAN_NAME] = value

###

def get_IH_deliv_chan_string_constant(deliv_chan_rec: dict):
    return deliv_chan_rec[ihmvf.IH_DELIV_CHAN_STR_CONSTANT]

def set_IH_deliv_chan_string_constant(deliv_chan_rec: dict, value: str):
    deliv_chan_rec[ihmvf.IH_DELIV_CHAN_STR_CONSTANT] = value

###

def get_IH_deliv_chan_ID(deliv_chan_rec: dict):
    return deliv_chan_rec[ihmvf.IH_DELIV_CHAN_ID]

def set_IH_deliv_chan_ID(deliv_chan_rec, value: str):
    deliv_chan_rec[ihmvf.IH_DELIV_CHAN_ID] = value

###

def get_IH_deliv_chan_active(deliv_chan_rec: dict):
    return deliv_chan_rec[ihmvf.IH_DELIV_CHAN_ACTIVE]

def set_IH_deliv_chan_active(deliv_chan_rec: dict, value: bool):
    deliv_chan_rec[ihmvf.IH_DELIV_CHAN_ACTIVE] = value

###

def get_IH_deliv_chan_custom(deliv_chan_rec: dict):
    return deliv_chan_rec[ihmvf.IH_DELIV_CHAN_CUSTOM]

def set_IH_deliv_chan_custom(deliv_chan_rec: dict, value: bool):
    deliv_chan_rec[ihmvf.IH_DELIV_CHAN_CUSTOM] = value

###
    
#######################################################################################################
#                                                                                                     #
#                              Health system administrative units                                     #
#                                                                                                     #
#######################################################################################################

def get_IH_num_health_sys_admin_units(health_sys_admin_unit_records: list):
    return len(health_sys_admin_unit_records)

def get_IH_health_sys_admin_unit_rec(health_sys_admin_unit_records: list, ID: str):
    health_sys_admin_unit_recs = [health_sys_admin_unit_rec for health_sys_admin_unit_rec in health_sys_admin_unit_records if health_sys_admin_unit_rec[ihmvf.IH_HEALTH_SYS_ADMIN_UNIT_ID] == ID]
    return health_sys_admin_unit_recs[0] if len(health_sys_admin_unit_recs) > 0 else gbc.GB_NOT_FOUND

def get_IH_health_sys_admin_unit_idx(health_sys_admin_unit_records: list, ID: str):
    indices = [idx for (idx, health_sys_admin_unit_rec) in enumerate(health_sys_admin_unit_records) if health_sys_admin_unit_rec[ihmvf.IH_HEALTH_SYS_ADMIN_UNIT_ID] == ID]
    return indices[0] if len(indices) > 0 else gbc.GB_NOT_FOUND

###

def get_IH_health_sys_admin_unit_name(health_sys_admin_unit_rec: dict):
    return health_sys_admin_unit_rec[ihmvf.IH_HEALTH_SYS_ADMIN_UNIT_NAME]

def set_IH_health_sys_admin_unit_name(health_sys_admin_unit_rec: dict, value: str):
    health_sys_admin_unit_rec[ihmvf.IH_HEALTH_SYS_ADMIN_UNIT_NAME] = value

###

def get_IH_health_sys_admin_unit_string_constant(health_sys_admin_unit_rec: dict):
    return health_sys_admin_unit_rec[ihmvf.IH_HEALTH_SYS_ADMIN_UNIT_STR_CONSTANT]

def set_IH_health_sys_admin_unit_string_constant(health_sys_admin_unit_rec: dict, value: str):
    health_sys_admin_unit_rec[ihmvf.IH_HEALTH_SYS_ADMIN_UNIT_STR_CONSTANT] = value

###

def get_IH_health_sys_admin_unit_ID(health_sys_admin_unit_rec: dict):
    return health_sys_admin_unit_rec[ihmvf.IH_HEALTH_SYS_ADMIN_UNIT_ID]

def set_IH_health_sys_admin_unit_ID(health_sys_admin_unit_rec: dict, value: str):
    health_sys_admin_unit_rec[ihmvf.IH_HEALTH_SYS_ADMIN_UNIT_ID] = value

###

def get_IH_health_sys_admin_unit_active(health_sys_admin_unit_rec: dict):
    return health_sys_admin_unit_rec[ihmvf.IH_HEALTH_SYS_ADMIN_UNIT_ACTIVE]

def set_IH_health_sys_admin_unit_active(health_sys_admin_unit_rec: dict, value: bool):
    health_sys_admin_unit_rec[ihmvf.IH_HEALTH_SYS_ADMIN_UNIT_ACTIVE] = value

###

def get_IH_health_sys_admin_unit_custom(health_sys_admin_unit_rec: dict):
    return health_sys_admin_unit_rec[ihmvf.IH_HEALTH_SYS_ADMIN_UNIT_CUSTOM]

def set_IH_health_sys_admin_unit_custom(health_sys_admin_unit_rec: dict, value: bool):
    health_sys_admin_unit_rec[ihmvf.IH_HEALTH_SYS_ADMIN_UNIT_CUSTOM] = value

###

def get_IH_health_sys_admin_unit_number(health_sys_admin_unit_rec: dict):
    return health_sys_admin_unit_rec[ihmvf.IH_HEALTH_SYS_ADMIN_UNIT_NUMBER]

def set_IH_health_sys_admin_unit_number(health_sys_admin_unit_rec: dict, value = int):
    health_sys_admin_unit_rec[ihmvf.IH_HEALTH_SYS_ADMIN_UNIT_NUMBER] = value

#######################################################################################################
#                                                                                                     #
#                                      Delivery channel packages                                      #
#                                                                                                     #
#######################################################################################################

#######################################################################################################
#                                                                                                     #
#                                      National programmes                                            #
#                                                                                                     #
#######################################################################################################

#######################################################################################################
#                                                                                                     #
#                                      Years                                                          #
#                                                                                                     #
#######################################################################################################