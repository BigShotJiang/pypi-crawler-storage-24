from os import environ

from AvenirCommon.Database import GB_get_db_json

import SpectrumCommon.Const.GB as gbc

import SpectrumCommon.Const.IH.IHConstLink as ihcl

import SpectrumCommon.Const.IH.IHModVarFields as ihf
import SpectrumCommon.Modvars.IH.IHModVarDefs as ihmvd

#######################################################################################################
#                                                                                                     #
#                                       Database loading methods                                      #
#                                                                                                     #
#######################################################################################################

def IH_load_group_DB(costing_mode = int):
    environment = environ[gbc.GB_SPECT_MOD_DATA_CONN_ENV]

    group_DB = []
    group_DB_IHT_ID_info_only = None

    if costing_mode == gbc.GB_IHT_COSTING_MODE:
        group_DB_file_name = ihcl.IH_IV_GROUP_DB_NAME + '_OH_' + ihcl.IH_IV_GROUP_DB_CURR_VERSION + '.' + gbc.GB_JSON 
        group_DB = GB_get_db_json(environment, gbc.GB_IH_CORE_CONTAINER, group_DB_file_name) 

    # If costing mode was not specified, assume IHT since that is Intervention Costing's main purpose for existing.
    elif costing_mode == gbc.GB_TB_COSTING_MODE:
        group_DB_file_name = ihcl.IH_IV_GROUP_DB_NAME + '_TI_' + ihcl.IH_IV_TI_GROUP_DB_CURR_VERSION + '.' + gbc.GB_JSON 
        group_DB = GB_get_db_json(environment, gbc.GB_IH_CORE_CONTAINER, group_DB_file_name) 

        group_DB_IHT_ID_info_only_file_name = ihcl.IH_IV_GROUP_DB_NAME + '_OH_' + ihcl.IH_IV_TI_GROUP_DB_CURR_VERSION + '.' + gbc.GB_JSON 
        group_DB_IHT_ID_info_only = GB_get_db_json(environment, gbc.GB_IH_CORE_CONTAINER, group_DB_IHT_ID_info_only_file_name) 

    elif costing_mode == gbc.GB_LIST_COSTING_MODE:
        group_DB_file_name = ihcl.IH_IV_GROUP_DB_NAME + '_' + ihcl.IH_IV_CS_GROUP_DB_CURR_VERSION + '.' + gbc.GB_JSON 
        group_DB = GB_get_db_json(environment, gbc.GB_CS_CONTAINER, group_DB_file_name) 

    return group_DB, group_DB_IHT_ID_info_only

#######################################################################################################
#                                                                                                     #
#                                       Programme areas and subgroups                                 #
#                                                                                                     #
#######################################################################################################

def IH_init_prog_area_records(group_DB):

    prog_area_records = []

    for group_DB_obj in group_DB:

        prog_area_mstID = str(group_DB_obj[ihcl.IH_IV_GROUP_MST_ID_KEY_GDB]) 
        subgroup_mstID = str(group_DB_obj[ihcl.IH_IV_SUBGROUP_MST_ID_KEY_GDB])
        english_str = group_DB_obj[ihcl.IH_IV_ENGLISH_STRING_KEY_GDB]
        str_constant = group_DB_obj[ihcl.IH_IV_STRING_CONSTANT_KEY_GDB]

        # Programme areas will have a subgroup master ID of -1. Programme areas should always come before their subgroups in the database.
        if subgroup_mstID == str(gbc.GB_NOT_FOUND):
            prog_area_rec = ihmvd.IH_create_prog_area_rec(prog_area_mstID, english_str, str_constant, True)
            prog_area_records.append(prog_area_rec)

        else:
            subgroup_rec = ihmvd.IH_create_prog_area_subgroup_rec(subgroup_mstID, english_str, str_constant, True)
            '''
                Since the database lists programme areas first, then their subgroups, then repeats, we should always be able to add the subgroup to 
                the current programme area.
            '''
            prog_area_records[-1][ihf.IH_PROG_AREA_SUBGROUP_RECORDS].append(subgroup_rec)
            

    return prog_area_records

# Initializes a list of programme area records containing only enough info to identify and display them in a list. Used for TB Costing to allow
# the users to pick IHT interventions and transfer them to TB standalone app.
def IH_init_prog_area_records_ID_info_only(group_DB):

    prog_area_records = []

    for group_DB_obj in group_DB:

        prog_area_mstID = str(group_DB_obj[ihcl.IH_IV_GROUP_MST_ID_KEY_GDB]) 
        subgroup_mstID = str(group_DB_obj[ihcl.IH_IV_SUBGROUP_MST_ID_KEY_GDB])
        english_str = group_DB_obj[ihcl.IH_IV_ENGLISH_STRING_KEY_GDB]
        str_constant = group_DB_obj[ihcl.IH_IV_STRING_CONSTANT_KEY_GDB]

        # Programme areas will have a subgroup master ID of -1. Programme areas should always come before their subgroups in the database.
        if subgroup_mstID == str(gbc.GB_NOT_FOUND):
            prog_area_rec = ihmvd.IH_create_prog_area_rec_ID_info_only(prog_area_mstID, english_str, str_constant)
            prog_area_records.append(prog_area_rec)

        else:
            subgroup_rec = ihmvd.IH_create_prog_area_subgroup_rec_ID_info_only(subgroup_mstID, english_str, str_constant)
            '''
                Since the database lists programme areas first, then their subgroups, then repeats, we should always be able to add the subgroup to 
                the current programme area.
            '''
            prog_area_records[-1][ihf.IH_PROG_AREA_SUBGROUP_RECORDS].append(subgroup_rec)

    return prog_area_records


#######################################################################################################
#                                                                                                     #
#                                       Delivery channels                                             #
#                                                                                                     #
#######################################################################################################

#######################################################################################################
#                                                                                                     #
#                                       Delivery channel packages                                     #
#                                                                                                     #
#######################################################################################################

#######################################################################################################
#                                                                                                     #
#                                       National programmes                                           #
#                                                                                                     #
#######################################################################################################

#######################################################################################################
#                                                                                                     #
#                                       Audit records                                                 #
#                                                                                                     #
#######################################################################################################
