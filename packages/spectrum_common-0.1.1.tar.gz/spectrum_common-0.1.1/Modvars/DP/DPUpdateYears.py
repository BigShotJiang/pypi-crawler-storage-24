from SpectrumCommon.Modvars.DP.DPModvarShapes import DP_modvar_shapes
from SpectrumCommon.Modvars.GB.GBDefs import gb_update_years
from SpectrumCommon.Const.DP import *

def DP_UpdateYears(projection, new_projection, params):

    projection[DP_InitialConditionsTag] = new_projection[DP_InitialConditionsTag]

    gb_update_years(projection, params, DP_modvar_shapes)
    pass