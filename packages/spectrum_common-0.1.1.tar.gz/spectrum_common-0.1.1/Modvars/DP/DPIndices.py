from AvenirCommon.Util import GBRange
from SpectrumCommon.Const.DP import *

dp_default_data_dim = 'dp_default_data_dim'
dp_default_data_indices = {
    'Default' : DP_Default,
    'Data' : DP_Data,   
}

dp_regions_dim = 'dp_regions_dim'
dp_regions_indices = {
    region : DP_GlobalRegions[region] for region in DP_GlobalRegions
}

# ARV Regimen Period
dp_arv_regimen_period_dim = 'dp_arv_regimen_period'
dp_arv_regimen_period_indices = {
    'PrenatalProphylaxis'   : DP_PrenatalProphylaxis,
    'PostnatalProphylaxis'  : DP_PostnatalProphylaxis,
    'AnnDropPostnatalProph' : DP_AnnDropPostnatalProph
}
# ARV Regimen Treatments
dp_arv_regimen_treatments_dim = 'dp_arv_regimen_treatments'
dp_arv_regimen_treatments_indices = {
    'NoProphylaxis'         : DP_NoProphylaxis,
    'SingleDoseNevir'       : DP_SingleDoseNevir,
    'DualARV'               : DP_DualARV,
    'OptA'                  : DP_OptA,
    'OptB'                  : DP_OptB,
    'TripleARTBefPreg'      : DP_TripleARTBefPreg,
    'TripleARTDurPreg'      : DP_TripleARTDurPreg,
    'TripleARTDurPreg_Late' : DP_TripleARTDurPreg_Late,
    'TotalTreat'            : DP_TotalTreat,
}

dp_percent_or_number_dim = 'dp_percent_or_number'
dp_percent_or_number_indices = {
    'Number'    : DP_Number,
    'Percent'   : DP_Percent,
    'NumAndPer' : DP_NumAndPer
}

dp_upd_source_indices = {
'Pop' : DP_UPD_Pop,            
'TFR' : DP_UPD_TFR,            
'LE' : DP_UPD_LE,             
'AgeMortality' : DP_UPD_AgeMortality,   
'ChildMortality' : DP_UPD_ChildMortality, 
'Migration' : DP_UPD_Migration      
}

dp_surv_rate_indices = {
    (str(a)) : a for a in GBRange(0, DP_MAX_SURVRATE)
}

dp_asfr_table_indices = {
    'UNAfrica'  : 1,
    'UNArab'    : 2,
    'UNAsia'    : 3,
    'Average'   : 4
}

dp_asfr_col_indices = {
    ('Col ' + str(col)) : col for col in GBRange(0, DP_ASFR_NumCols)
}
dp_asfr_row_indices = {
    ('Row ' + str(row)) : row for row in GBRange(0, DP_ASFR_NumRows)
}

dp_infant_feed_months_dim = 'infant_feed_months'
dp_infant_feed_months_indices = {
    ('Month ' + str(m)) : m for m in GBRange(0, DP_InfantFeedingMths)
}

dp_infant_feed_types_dim = 'infant_feed_types'
dp_infant_feed_types_indices = {
  'No breastfeeding'        : DP_NoBF,
  'Exclusive breastfeeding' : DP_ExBF
}

dp_PMTCT_dim = 'PMTCT'
dp_PMTCT_indices = {
  'Not in PMTCT' : DP_NotInPMTCT,
  'In PMTCT'     : DP_InPMTCT
}

dp_elig_treat_children_dim = 'elig_treat_children'
dp_elig_treat_children_indices = {
  'Age < 11 months'     : DP_AgeLT11Mths,
  'Age 12 to 35 months' : DP_Age12to35Mths,
  'Age 35 to 59 months' : DP_Age35to59Mths,
  'Age > 5 years'       : DP_AgeGT5Years,
}

dp_ART_delivery_dim = 'ART_delivery'
dp_ART_delivery_indices = {
    'On ART at delivery'       : DP_OnARTAtDelivery,
    'Starting ART at delivery' : DP_StartingARTAtDelivery,
}

dp_ART_coverage_method_dim = 'ART_coverage_method'
dp_ART_coverage_method_indices = {
    'Number or percent'          : DP_NumOrPercent,
    'CD4 percent'                : DP_CD4Percent,  
    'CD4 number'                 : DP_CD4Number,       
    'Number of new ART patients' : DP_NumNewARTPats,
    'Percent by risk group'      : DP_PcntByRiskGrp,
}

dp_CD4_count_cat_dim = 'CD4_count_cat'
dp_CD4_count_cat_indices = {
    'CD4 count > 500'  : DP_CD4_GT500,
    'CD4 count 350-500': DP_CD4_350_500,
    'CD4 count 250-349': DP_CD4_250_349,
    'CD4 count 200-249': DP_CD4_200_249,
    'CD4 count 100-199': DP_CD4_100_199,
    'CD4 count 50-99'  : DP_CD4_50_99,
    'CD4 count < 50'   : DP_CD4_LT50,
}
dp_CD4_count_cat_noLT50_indices = dp_CD4_count_cat_indices.popitem()


dp_GAM_age_group_dim = 'GAM_age_group'
dp_GAM_age_group_indices = {
    'All Ages'      : GB_AllAges,
    'Age 0 to 4'    : GB_A0_4,
    'Age 5 to 9'    : GB_A5_9,
    'Age 10 to 14'  : GB_A10_14,
    'Age 15 to 19'  : GB_A15_19,
    'Age 20 to 24'  : GB_A20_24,
    'Age 25 to 49'  : DP_GAMAG_A25_49,
    'Age 50+'       : DP_GAMAG_A50Plus,
}


dp_pop_elig_treat_regardless_CD4_count_dim = 'pop_elig_treat_regardless_CD4_count'
dp_pop_elig_treat_regardless_CD4_count_indices = {
    'Pregnant women'         : DP_EligTreatPregnantWomen,
    'People with TB and HIV' : DP_EligTreatTB_HIV,
    'Discordant couples'     : DP_EligTreatDiscordantCouples,
    'Sex workers'            : DP_EligTreatSexWorkers,
    'MSM'                    : DP_EligTreatMSM,
    'IDU'                    : DP_EligTreatIDU,
    'Other populations'      : DP_EligTreatOtherPop,
}


dp_per_child_HIV_dim = 'per_child_HIV'
dp_per_child_HIV_indices = {
    'HIV positive children receiving cotrimoxazole' : DP_PerChildHIVPosCot,
    'HIV positive children receiving ART'           : DP_PerChildHIVRecART,
    'HIV positive children age 0-4 receiving ART'   : DP_PerChildHIVRecART0_4,
    'HIV positive children age 5-9 receiving ART'   : DP_PerChildHIVRecART5_9,
    'HIV positive children age 10-14 receiving ART' : DP_PerChildHIVRecART10_14,
}

# ANC Testing Editor constants 
dp_ANC_testing_dim = 'ANC_testing'
dp_ANC_testing_indices = {
    'First ANC visits'                                       : DP_FirstANCVisits,
    'People receiving at least one HIV test'                 : DP_RecAtLeast1HIVTest,
    'People testing positive on the first HIV test'          : DP_PosOnFirstHIVTest,
    'People testing positive for HIV on the first ANC visit' : DP_HIVPosFirstANCVisit,
    'Percent HIV positive on census'                         : DP_PercHIVPosCensus,
    'Number retested'                                        : DP_NumRetested,
    'Number testing positive at retest'                      : DP_NumPosAtRetest,
    'Reported births'                                        : DP_ProgReportedBirths,
    'People testing negative for HIV on the first ANC visit' : DP_HIVNegFirstANCVisit,
}

dp_HIV_status_dim = 'HIV_status'
dp_HIV_status_indices = {
    'Total pop' : DP_D_All,   
    'HIV- pop' : DP_D_HIVNeg,
    'HIV+ pop' : DP_D_HIVPos,
}

dp_num_type_dim = 'Number type'
dp_num_type_indices = {
    'Number' : DP_Number,
    'Percent' : DP_Percent,
    'Lower Bound' : DP_LowerBound,
    'Upper Bound' : DP_UpperBound,
}

dp_shiny90_age_group_dim = 'Shiny90_age_groups'
dp_shiny90_age_group_indices = {
    '15-24' : DP_S90_15_24, 
    '25-34' : DP_S90_25_34, 
    '35-49' : DP_S90_35_49, 
    '15-49' : DP_S90_15_49, 
    '15+' : DP_S90_15Plus,
}

dp_cascade_age_group_dim = 'Cascade_age_groups'
dp_cascade_age_group_indices = {
    'Child' : DP_Cas_AG_Child,      
    'Male' : DP_Cas_AG_AdultMale,  
    'Female' : DP_Cas_AG_AdultFemale,
}

dp_pediatric_age_group_dim = 'Pediatric_age_groups'
dp_pediatric_age_group_indices = {
    '0' : DP_A0,  
    '1-2' : DP_A1t2,
    '3-4' : DP_A3t4,
    '5-14' : DP_A5t14,
}
dp_pediatric_mort_no_ART_LT5_age_group_dim = 'Pediatric_mort_no_ART_LT5_age_groups'
dp_pediatric_mort_no_ART_LT5_age_group_indices = {
    '0' : DP_A0,  
    '1-2' : DP_A1t2,
    '3-4' : DP_A3t4,
}

dp_pediatric_mort_no_ART_GT5_age_group_dim = 'Pediatric_mort_no_ART_GT5_age_groups'
dp_pediatric_mort_no_ART_GT5_age_group_indices = {
    '5-9' : DP_A5t9,
    '10-14' : DP_A10t14,
}

dp_pediatric_CD4_categories_dim = 'Pediatric_CD4_categories'
dp_pediatric_CD4_categories_indices = {
    'A0-4:GT30%, A5-14:Top' : DP_CD4_Per_GT30, #DP_CD4_Ped_Top 
    'A0-4:26-30%, A5-14:GT1000' : DP_CD4_Per_26_30, #DP_CD4_Ped_GT1000
    'A0-4:21-25%, A5-14:750-999' : DP_CD4_Per_21_25, #DP_CD4_Ped_750_999
    'A0-4:16-20%, A5-14:500-749' : DP_CD4_Per_16_20, #DP_CD4_Ped_500_749
    'A0-4:11-15%, A5-14:350-499' : DP_CD4_Per_11_15, #DP_CD4_Ped_350_499
    'A0-4:5-10%, A5-14:200-349' : DP_CD4_Per_5_10, #DP_CD4_Ped_200_349 
    'A0-4:LT5%, A5-14:LT200' : DP_CD4_Per_LT5, #DP_CD4_Ped_LT200  
}
dp_pediatric_CD4_categories_noLT5_indices = dp_pediatric_CD4_categories_indices.popitem()

dp_viral_suppression_dim = 'Viral_suppression_status'
dp_viral_suppression_indices = {
    'NumOnART' : DP_VS_NumOnART,       
    'NumTested' : DP_VS_NumTested,      
    'PLHIVSuppressed' : DP_VS_PLHIVSuppressed,
}

dp_HIV_acquisition_dim = 'ART status or timing of HIV acquisition'
dp_HIV_acquisition_indices = {
    'Children who acquired HIV perinatally' : DP_P_Perinatal,
    'Children who acquired HIV during 0-6 months of breastfeeding' : DP_P_BF0,
    'Children who acquired HIV during 7-12 months of breastfeeding' : DP_P_BF7,
    'Children who acquired HIV during 12+ months of breastfeeding' : DP_P_BF12,
}

dp_mort_rate_dim = 'Mortality rate time periods'
dp_mort_rate_indices = {
    'MortRates_LT12Mo' : DP_MortRates_LT12Mo,
    'MortRates_GT12Mo' : DP_MortRates_GT12Mo,
}

dp_child_treat_effectiveness_dim = 'Effectiveness of Treatment, Child'
dp_child_treat_effectiveness_indices = {
    'Cotrim' : DP_Cotrim,         
    'ChildEffNoART' : DP_ChildEffNoART,  
    'ChildEffWithART' : DP_ChildEffWithART,   
}

dp_child_treat_years_dim = 'Child treatment years'
dp_child_treat_years_indices = {
    ('Treatment year ' + str(i)) : i for i in GBRange(DP_MIN_YEAR, DP_MaxChildTreatmentYears)
}

dp_10y_age_dim = '10y_age'
dp_10y_age_indices = {
    'Age 15 to 24' : DP_CD4_15_24,
    'Age 25 to 34' : DP_CD4_25_34,
    'Age 35 to 44' : DP_CD4_35_44,
    'Age 45 to 54' : DP_CD4_45_54,
}

dp_ART_status_dim = 'ART_status'
dp_ART_status_indices = {
    'NoTreat' : DP_NoTreat,
    'OnART' : DP_OnART,  
}

dp_regimen_transmission_efficacy_MTCT_dim = 'regimen_transmission_efficacy_MTCT'
dp_regimen_transmission_efficacy_MTCT_indices = {
    'No prophylaxis existing inf CD4 < 200'   : DP_NoProphExistInfCD4LT200,
    'No prophylaxis existing inf CD4 200-350' : DP_NoProphExistInfCD4200_350,
    'No prophylaxis existing inf CD4 > 350'   : DP_NoProphExistInfCD4GT350,
    'No prophylaxis incidence inf'            : DP_NoProphIncidentInf,
    'Single dose nev'                         : DP_SingleDoseNev,
    'WHO 2006 dual ARV'                       : DP_WHO2006DualARV,
    'Option A'                                : DP_OptionA,
    'Option B'                                : DP_OptionB,
    'ART starting pre-pregnancy'              : DP_ARTStartPrePreg,
    'ART starting during pregnancy'           : DP_ARTStartDurPreg,
    'ART starting during late pregnancy'      : DP_ARTStartDurPreg_Late, 
}

dp_stage_transmission_efficacy_MTCT_dim = 'stage_transmission_efficacy_MTCT'
dp_stage_transmission_efficacy_MTCT_indices = {
    'Perinatal'            : DP_Perinatal,
    'Breastfeeding < 350'  : DP_BreastfeedingLT350,
    'Breastfeeding >= 350' : DP_BreastfeedingGE350,
}

dp_DALY_weights_dim = 'DALY_weights'
dp_DALY_weights_indices = {
    'DALY CD4 >= 200' : DP_DALY_CD4CountGE200,
    'DALY CD4 < 200'  : DP_DALY_CD4CountLT200,
    'DALY on ART'     : DP_DALY_OnART,
}

dp_adult_child_dim = 'adult_child'
dp_adult_child_indices = {
    'Adult'           : DP_Adult,
    'Child'           : DP_Child,
    'Adult and child' : DP_AdultAndChild,
}

dp_risk_group_dim = 'risk_group'
dp_risk_group_indices = {
    'Injecting drug users'      : DP_InjectingDrugUsers,
    'Men who have sex with men' : DP_MenSexWithMen,
    'Sex workers'               : DP_SexWorkers,
    'Lower risk general pop'    : DP_LowerRiskGenPop,
}

dp_AIDS_deaths_married_dim = 'AIDS_deaths_married'
dp_AIDS_deaths_married_indices = {
    'Percent AIDS deaths': DP_PercAIDSDeaths,
    'Percent married'    : DP_PercMarried,
}

dp_nosocomial_infection_ages_dim = 'nosocomial_infection_ages'
dp_nosocomial_infection_ages_indices = {
    'All ages'     : DP_AllAges,
    'Age 0 to 4'   : DP_A0_4,
    'Age 5 to 9'   : DP_A5_9,
    'Age 10 to 14' : DP_A10_14,
}

dp_CSAVR_reporting_dim = 'CSAVR_reporting'
dp_CSAVR_reporting_indices = {
    'Number reported'    : CSAVRNumReported,
    'Number not reported': CSAVRNumNotReported,
}

dp_CSAVR_source_dim = 'CSAVR_source'   
dp_CSAVR_source_indices = {
    'Source 1': CSAVRSource1,
    'Source 2': CSAVRSource2,
    'Source 3': CSAVRSource3,
} 

dp_CSAVR_ages_dim = 'CSAVR_ages'
dp_CSAVR_ages_indices = {
    'All ages'       : DP_AllAges,
    'Age 0 to 4'     : DP_A0_4,
    'Age 5 to 9'     : DP_A5_9,
    'Age 10 to 14'   : DP_A10_14,
    'Age 15 to 19'   : DP_A15_19,
    'Age 20 to 24'   : DP_A20_24,
    'Age 25 to 29'   : DP_A25_29,
    'Age 30 to 34'   : DP_A30_34,
    'Age 35 to 39'   : DP_A35_39,
    'Age 40 to 44'   : DP_A40_44,
    'Age 45 to 49'   : DP_A45_49,
    'Age 50 to 54'   : DP_A50_54,
    'Age 50 plus'    : DP_A50Plus,
}

dp_CSAVR_CD4_dim = 'CSAVR_CD4'
dp_CSAVR_CD4_indices = {
    'CD4 < 200'      : CSAVR_CD4_LT200,
    'CD4 200 to 350' : CSAVR_CD4_200_350,
    'CD4 350 to 500' : CSAVR_CD4_350_500,
    'CD4 500 plus'   : CSAVR_CD4_500Plus,
}

dp_CSAVR_CD4_2_dim = 'CSAVR_CD4_2'
dp_CSAVR_CD4_2_indices = {
    'CD4 < 200'      : CSAVR_CD4_LT200,
    'CD4 200 to 350' : CSAVR_CD4_200_350,
    'CD4 350 to 500' : CSAVR_CD4_350_500,
    'CD4 500 plus'   : CSAVR_CD4_500Plus,
    'CD4 all'        : CSAVR_CD4_All,
}
    
dp_AIDS_deaths_all_ages_num_dim = 'AIDS_deaths_all_ages_num'
dp_AIDS_deaths_all_ages_num_indices = {
    'Median'      : DP_Median,
    'Under count' : DP_UnderCount,
}

dp_fitting_incidence_option_dim = 'fitting_incidence_option'
dp_fitting_incidence_option_indices = {
    'PLHIV'                : DP_PLHIV,
    'New HIV cases'        : DP_NewHIVCases,
    'AIDS deaths'          : DP_AIDSDeaths,
    'HIV positive deaths'  : DP_DeathsHIVPos,
    'CD4 dist at diagnosis': DP_CD4DistAtDiag,
}

dp_CSAVR_fit_types_dim = 'CSAVR_fit_types'
dp_CSAVR_fit_types_indices = {
    'Fit not calculated' : DP_FitNotCalculated,
    'Double logistic'    : DP_DoubleLogistic,
    'Single logistic'    : DP_SingleLogistic,
    'Spline 5 knots'     : DP_Spline5Knots,
    'Logistic'           : DP_rLogistic,
    'Spline 4 knots'     : DP_Spline4Knots,
    'Spline 3 knots'     : DP_Spline3Knots,
}

dp_CSAVR_uncertainty_types_dim = 'CSAVR_uncertainty_types'
dp_CSAVR_uncertainty_types_indices = {
    'Uncertainty burn-in'           : CSAVR_Unc_BurnIn,
    'Uncertainty number of samples' : CSAVR_Unc_NumSamples,
}

dp_CSAVR_adjust_IRRs_dim = 'CSAVR_adjust_IRRs'
dp_CSAVR_adjust_IRRs_indices = {
    'Sex ratio'           : DP_CSAVR_SexRatio,
    'Distribution of HIV' : DP_CSAVR_DistOfHIV,
}

dp_age_ratio_patterns_dim = 'age_ratio_patterns'
dp_age_ratio_patterns_indices = {
    'Generalized'    : DP_Generalized_Index,
    'Concentrated'   : DP_NonIDUConcentrated_Index,
    'Concentrated 2' : DP_IDUConcentrated_Index,
}

dp_prev_surveys_dim = 'prev_surveys'
dp_prev_surveys_indices = {
    'Prev survey 1' : DP_PrevSurvey1,
    'Prev survey 2' : DP_PrevSurvey2,
    'Prev survey 3' : DP_PrevSurvey3,
    'Prev survey 4' : DP_PrevSurvey4,
    'Prev survey 5' : DP_PrevSurvey5,
    'Prev survey 6' : DP_PrevSurvey6,
    'Prev survey 7' : DP_PrevSurvey7,
    'Prev survey 8' : DP_PrevSurvey8,
}

dp_sample_sizes_dim = 'sample_sizes'
dp_sample_sizes_indices = {
    'Number'               : DP_Number,
    'Percent'              : DP_Percent,
    'Lower bound'          : DP_LowerBound,
    'Upper bound'          : DP_UpperBound,
    'Weighted sample size' : DP_WeightedSampleSize,
}

dp_sample_sizes_2_dim = 'sample_sizes_2'
dp_sample_sizes_2_indices = {
    'Number'               : DP_Number,
    'Percent'              : DP_Percent,
    'Lower bound'          : DP_LowerBound,
    'Upper bound'          : DP_UpperBound,
}

# Key Populations
dp_key_pops_1_dim = 'key_pops_1'
dp_key_pops_1_indices = {
    'FSW'  : DP_KP_FSW,
    'MSM'  : DP_KP_MSM,
    'PWID' : DP_KP_PWID,
    'TG'   : DP_KP_TG,
}

dp_key_pops_2_dim = 'key_pops_2'
dp_key_pops_2_indices = {
    'PSE'            : DP_KP_PSE,
    'HIV prevention' : DP_KP_HIVPrev,
    'ART coverage'   : DP_KP_ARTCov,
    'New infections' : DP_KP_NewInfs,
}

dp_ART_cov_validation_ages_dim = 'ART_coverage_validation'
dp_ART_cov_validation_ages_indices = {
    'Validation ages 0 to 14'  : DP_Val_A0_14,
    'Validation ages 15 to 49' : DP_Val_A15_49,
    'Validation ages 50 plus'  : DP_Val_A50Plus,
}

dp_incidence_option_dim = 'incidence_option'
dp_incidence_option_indices = {
    'Direct incidence input' : DP_DirectIncidenceInputOpt,
    'EPP incidence'          : DP_EPPIncOpt,
    'AEM incidence'          : DP_AEMIncOpt,
    'Fit to program data'    : DP_FitToProgramDataOpt,
    'Fit to mortality data'  : DP_FitToMortalityDataOpt,
    'ECDC'                   : DP_ECDCOpt,
}

dp_EPP_epi_1_dim = 'EPP_epi_1'
dp_EPP_epi_1_indices = {
    'Country ID'   : DP_CountryID,
    'Min epidemic' : DP_MinEpidemic,
    'Max epidemic' : DP_MaxEpidemic,
}

dp_EPP_epi_2_dim = 'EPP_epi_2'
dp_EPP_epi_2_indices = {
    'Min epidemic' : DP_MinEpidemic,
    'Max epidemic' : DP_MaxEpidemic,
}
 
dp_CD4_count_cats_children_5_14_dim = 'dp_CD4_count_cats_children_5_14'
dp_CD4_count_cats_children_5_14_indices = {
    'CD4 top'        : DP_CD4_Ped_Top,
    'CD4 > 1000'     : DP_CD4_Ped_GT1000,
    'CD4 750 to 999' : DP_CD4_Ped_750_999,
    'CD4 500 to 749' : DP_CD4_Ped_500_749,
    'CD4 350 to 499' : DP_CD4_Ped_350_499,
    'CD4 200 to 349' : DP_CD4_Ped_200_349,
    'CD4 < 200'      : DP_CD4_Ped_LT200,
}

dp_HIV_mort_with_ART_treat_interval_dim = 'dp_HIV_mort_with_ART_treat_interval'
dp_HIV_mort_with_ART_treat_interval_indices = {
    '0 to 6 months'  : DP_0to6monthsTreat,
    '7 to 12 months' : DP_7to12monthsTreat,
    '> 12 months'    : DP_GT12monthsTreat,
}

dp_HIV_status_dim = 'dp_HIV_status'
dp_HIV_status_indices = {
    'All'                         : DP_H_All,
    'No'                          : DP_H_No,
    'Asymptomatic'                : DP_H_Asym,
    'Need treatment'              : DP_H_NeedTx,
    'On first-line ART'           : DP_H_OnFLArt,
    'Needing second-line ART'     : DP_H_NeedSL,
    'On second-line ART'          : DP_H_OnSLArt,
    'Breastfeeding < 6 months'    : DP_H_BF_LT6_Asym,
    'Breastfeeding 6 to 12 months': DP_H_BF_6to12_Asym,
}

dp_CD4_dist_not_on_ART_dim = 'CD4_dist_not_on_ART'
dp_CD4_dist_not_on_ART_indices = {
    '0 to 4'  : DP_CD4_0t4,
    '5 to 14' : DP_CD4_5t14,    
}

dp_HIV_duration_status_timing_dim = 'HIV_duration_status_timing'
dp_HIV_duration_status_timing_indices = {
    'All'                : DP_D_All,
    'HIV negative'       : DP_D_HIVNeg,
    'HIV positive'       : DP_D_HIVPos,
    'ART 1 to 6 months'  : DP_D_ARTlt6m,
    'ART 6 to 12 months' : DP_D_ART6to12m,
    'ART > 12 months'    : DP_D_ARTgt12m,
}

dp_subpop_summary_ind_dim = 'subpop_summary_ind'
dp_subpop_summary_ind_indices = {
    'Adults - Total HIV population' : DP_HIVPopTot_Ad,
    'Adults - Male HIV population' : DP_HIVPopMale_Ad,
    'Adults - Female HIV population' : DP_HIVPopFemale_Ad,
    'Adults - Adult prevalence' : DP_AdultPrev_Ad,
    'Adults - Total new HIV infections' : DP_NewHIVInfectTot_Ad,
    'Adults - Male new HIV infections' : DP_NewHIVInfectMale_Ad,
    'Adults - Female new HIV infections' : DP_NewHIVInfectFemale_Ad,
    'Adults - Adult HIV incidence' : DP_AdultHIVInc_Ad,
    'Adults - Total annual AIDS deaths' : DP_AnnAIDSDeathTot_Ad,
    'Adults - Male annual AIDS deaths' : DP_AnnAIDSDeathMale_Ad,
    'Adults - Female annual AIDS deaths' : DP_AnnAIDSDeathFemale_Ad,
    'Adults - Total number on ART' : DP_NumOnARTTot_Ad,
    'Adults - Male number on ART' : DP_NumOnARTMale_Ad,
    'Adults - Female number on ART' : DP_NumOnARTFemale_Ad,
    'Adults - Total number needing ART' : DP_NumNeedARTTot_Ad,
    'Adults - Male number needing ART' : DP_NumNeedARTMale_Ad,
    'Adults - Female number needing ART' : DP_NumNeedARTFemale_Ad,
    'Adults - Total population 15 plus' : DP_AdPop15PlusTot_Ad,
    'Adults - Male population 15 plus' : DP_AdPop15PlusMale_Ad,
    'Adults - Female population 15 plus' : DP_AdPop15PlusFemale_Ad,
    'Children - Total HIV population' : DP_HIVPopTot_Child,
    'Children - Male HIV population' : DP_HIVPopMale_Child,
    'Children - Female HIV population' : DP_HIVPopFemale_Child,
    'Children - Total new HIV infections' : DP_NewHIVInfectTot_Child,
    'Children - Male new HIV infections' : DP_NewHIVInfectMale_Child,
    'Children - Female new HIV infections' : DP_NewHIVInfectFemale_Child,
    'Children - Total annual AIDS deaths' : DP_AnnAIDSDeathTot_Child,
    'Children - Male annual AIDS deaths' : DP_AnnAIDSDeathMale_Child,
    'Children - Female annual AIDS deaths' : DP_AnnAIDSDeathFemale_Child,
    'Children - Number needing PMTCT' : DP_NeedPMTCT_Child,
    'Children - Number on PMTCT' : DP_OnPMTCT_Child,
    'Children - Total population 0 to 14' : DP_AdPop0_14Tot_Child,
    'Children - Male population 0 to 14' : DP_AdPop0_14Male_Child,
    'Children - Female population 0 to 14' : DP_AdPop0_14Female_Child,
}

dp_orphans_dim = 'orphans'
dp_orphans_indices = {
    'Total'             : DP_Total_orphans,
    'Maternal AIDS'     : DP_Maternal_AIDS,
    'Maternal non-AIDS' : DP_Maternal_Non_AIDS,
    'Paternal AIDS'     : DP_Paternal_AIDS,
    'Paternal non-AIDS' : DP_Paternal_Non_AIDS,
    'Dual AIDS'         : DP_Dual_AIDS,
    'Dual non-AIDS'     : DP_Dual_Non_AIDS,
    'Total AIDS'        : DP_Total_AIDS,
    'Total non-AIDS'    : DP_Total_Non_AIDS,
    'Dual total'        : DP_Dual_Total,
    'Maternal'          : DP_Maternal_Orphans,
    'Paternal'          : DP_Paternal_Orphans,
}

dp_ALB_dim = ''
dp_ALB_indices = {
    'Maternal AIDS'     : DP_MaternalAIDS_ALB,
    'Maternal non-AIDS' : DP_MaternalNonAIDS_ALB,
    'Paternal AIDS'     : DP_PaternalAIDS_ALB,
    'Paternal non-AIDS' : DP_PaternalNonAIDS_ALB,
    'Dual AIDS'         : DP_DualAIDS_ALB,
    'Dual non-AIDS'     : DP_DualNonAIDS_ALB,
    'Dual'              : DP_Dual_ALB,
}

dp_orphans_total_dim = 'orphans_total'
dp_orphans_total_indices = {
    'Maternal total' : DP_MaternalTotal,
    'Paternal total' : DP_PaternalTotal,
    'Dual total'     : DP_DualTotal,
    'Total'          : DP_TotalOrphans,
}

dp_orphans_total_2_dim = 'orphans_total_2'
dp_orphans_total_2_indices = {
    'Maternal total'       : DP_MaternalTotal,
    'Paternal total'       : DP_PaternalTotal,
    'Dual total'           : DP_DualTotal,
    'Total'                : DP_TotalOrphans,
    'All non-AIDS orphans' : DP_AllNonAIDSOrphans,
    'All AIDS orphans'     : DP_AllAIDSOrphans,
}

dp_AIDS_dim = 'AIDS'
dp_AIDS_indices = {
    'Total'    : DP_Total_AIDS_NonAIDS,
    'AIDS'     : DP_AIDS,
    'Non-AIDS' : DP_Non_AIDS,
}

dp_time_steps_dim = 'time_steps'
dp_time_steps_indices = {
    ('Time step ' + str(t)) : t for t in GBRange(0, 10)
}

dp_regions_dim = 'regions'
dp_regions_indices = {
    'Asia'                            : DP_Asia,
    'Central Africa'                  : DP_CAfrica,
    'Developed countries'             : DP_DevCountries,
    'Eastern Africa'                  : DP_EAfrica,
    'Eastern Europe'                  : DP_EEurope,
    'Latin American and Caribbean'    : DP_LatAmerCarr,
    'Northern Africa and Middle East' : DP_NAfrMiddEast,
    'Southern Africa'                 : DP_SAfrica,
    'Western Africa'                  : DP_WAfrica,
}

dp_15_19_coefficients_dim = '15_19_coefficients'
dp_15_19_coefficients_indices = {
    'Intercept' : DP_Intercept,
    'Slope'     : DP_Slope,
}

dp_HIV_ART_age_dim = 'HIV_ART_age'
dp_HIV_ART_age_indices = {
    '1 to 6 months' : DP_HIVARTlt6m,
    '> 6 months'    : DP_HIVARTgt6m,
    '> 12 months'   : DP_HIVARTgt12m,
}

dp_ART_regimen_PMTCT_costing_dim = 'ART_regimen_PMTCT_costing'
dp_ART_regimen_PMTCT_costing_indices = {
    'Option A breastfeeding' : DP_OptB_BF,
    'Option B breastfeeding' : DP_OptB_BF,
}

dp_advanced_opt_new_ART_patient_alloc_method_dim = 'advanced_opt_new_ART_patient_alloc_method'
dp_advanced_opt_new_ART_patient_alloc_method_indices = {
    'Exp mortality'       : DP_AdvOpt_ART_ExpMort,
    'Proportion eligible' : DP_AdvOpt_ART_PropElig,
}

dp_PMTCT_2_dim = 'PMTCT_2'
dp_PMTCT_2_indices = {
    'Number of women'      : PMTCT_NumberOfWomen,
    'New child infections' : PMTCT_NewChildInfections,
    'Transmission rate'    : PMTCT_TransmissionRate,
}

dp_MTCT_dim = 'MTCT'
dp_MTCT_indices = {
    'ARV before perinatal'             : MTCT_Ind_ARVBeforePerinatal,
    'ARV during perinatal'             : MTCT_Ind_ARVDuringPerinatal,
    'ARV during dropout child inf'     : MTCT_Ind_ARVDuringDropoutChildInf,
    'ARV late perinatal'               : MTCT_Ind_ARVLatePerinatal,
    'No ARVperinatal'                  : MTCT_Ind_NoARVPerinatal,
    'Incident perinatal'               : MTCT_Ind_IncidentPerinatal,
    'ARV before breastfeeding'         : MTCT_Ind_ARVBeforeBF,
    'ARV during breastfeeding'         : MTCT_Ind_ARVDuringBF,
    'Dropped ART during breastfeeding' : MTCT_Ind_DroppedARTDurBF,
    'ARV late breastfeeding'           : MTCT_Ind_ARVLateBF,
    'No ART breastfeeding'             : MTCT_Ind_NoARVBF,
    'Incident breastfeeding'           : MTCT_Ind_IncidentBF,
}

dp_child_weight_bands_kg_dim = 'child_weight_bands_kg'
dp_child_weight_bands_kg_indices = {
    '3 to 5.9'   : DP_Kgs_3_5pt9,
    '6 to 9.9'   : DP_Kgs_6_9pt9,
    '10 to 13.9' : DP_Kgs_10_13pt9,
    '14 to 19.9' : DP_Kgs_14_19pt9,
    '20 to 24.9' : DP_Kgs_20_24pt9,
    '25 to 34.9' : DP_Kgs_25_34pt9,
    '35 plus'    : DP_Kgs_35_Plus,
}

DP_Cas_AG_dim = 'cas_age_group'
DP_Cas_AG_indices = {
    DP_Cas_AG_Child           : 'Children',
    DP_Cas_AG_AdultMale       : 'Adult Males',
    DP_Cas_AG_AdultFemale     : 'Adult Females',
    DP_Cas_AG_AllAges         : 'All ages',
    DP_Cas_AG_AdultBothSexes  : 'Adult Both Sexes'
}


DP_Cas_IND_dim = 'case indicator'
DP_Cas_IND_indices = {
    DP_Cas_IND_Numbers    : 'Numbers',
    DP_Cas_IND_PerElig    : 'Percent eligible',
    DP_Cas_IND_PerPLHIV   : 'Percent PLHIV'
}


DP_Cas_dim = 'case data type'
DP_Cas_indices = {
    DP_Cas_PLHIV          : 'PLHIV',
    DP_Cas_KnowStatus     : 'People who know their HIV status',
    DP_Cas_OnART          : 'People on ART',
    DP_Cas_ViralSuppr     : 'People who are viral suppressed',
}

DP_DetCas_dim = 'Detected case data type'
DP_DetCas_indices = {
    DP_DetCas_KoSDiagOnTreat             : 'Diagnosed on treatment',
    DP_DetCas_KoSDiagNeverTreat          : 'Diagnosed never treated',
    DP_DetCas_KoSDiagPrevOnTreat         : 'Diagnost previously on treatment',
    DP_DetCas_KoSLongStandingInfNotDiag  : 'Long standing infection not diagnosed',
    DP_DetCas_KoSIncidentInfNotDiag      : 'Incident infection not diagnosed',
}