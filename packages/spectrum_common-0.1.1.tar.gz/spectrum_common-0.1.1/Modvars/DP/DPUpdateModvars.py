from copy import deepcopy

from SpectrumCommon.Const.AM import *
from SpectrumCommon.Const.DP import *
from SpectrumCommon.Const.PJ import *
from SpectrumCommon.Modvars.DP.DPModvarDef import DPSources_Init

def DP_UpdateModvars(projection, created_projection):
    
    # old iteration of DP_DPSourcesTag was set to 0
    if type(projection[DP_DPSourcesTag]) == int:
        projection[DP_DPSourcesTag] = DPSources_Init({})

    # from module-specific to projection-wide sources
    if DP_EdDmSourceTag in projection:
        for src in projection[DP_EdDmSourceTag]:
            projection[PJN_UserSourceTag].append(src)
            
    if AM_CMRTag in projection:
        projection[DP_CMRTag] = projection[AM_CMRTag]

    created_projection[DP_InitialConditionsTag].update(projection[DP_InitialConditionsTag])
    projection[DP_InitialConditionsTag] = deepcopy(created_projection[DP_InitialConditionsTag])

    return projection

AM_CMRTag                           = '<AM_CMR_V1>'
DP_EdDmSourceTag                    = '<DP_EdDmSource_V1>'