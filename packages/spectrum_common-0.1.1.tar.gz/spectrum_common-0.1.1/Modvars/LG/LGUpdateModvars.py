



# Notes:
#
#   1. You cannot base logic on whether a current MV tag exists in the code below.  It will always exist, because before this gets called, all missing MVs
#      will get added to the projection.
#
#   2. To trigger this, create a projection, say on the client, save, and grab it's projection ID.  Call GetModvars to get the library ID and put that into the appropriate
#      environment variable. Then call OpenProjection. Make sure to leave the projection on the client open while doing this because the proj ID changes when you open/close.
def LG_UpdateModvars(projection, created_projection):

    # if IS_FACILITY_MED_EQUIP_GROUP_RECORDS_TAG_V1 in projection:
    #     # String constants were added for facility medical equipment group records.
    #     facility_MEG_records = projection[IS_FACILITY_MED_EQUIP_GROUP_RECORDS_TAG_V1 ]

    #     for rec in facility_MEG_records:
    #         if not (ismvf.IS_FACIL_MEG_STR_CONST in rec):
    #             rec[ismvf.IS_FACIL_MEG_STR_CONST] = ''

    #     projection[ismvt.IS_FACILITY_MED_EQUIP_GROUP_RECORDS_TAG] = deepcopy(facility_MEG_records)

    # if IS_FACILITY_MED_EQUIP_RECORDS_TAG_V1 in projection:
    #     # String constants were added for facility equipment records.
    #     facility_equip_records = projection[IS_FACILITY_MED_EQUIP_RECORDS_TAG_V1]

    #     for rec in facility_equip_records:
    #         if not (ismvf.IS_FACIL_EQUIP_STR_CONST in rec):
    #             rec[ismvf.IS_FACIL_EQUIP_STR_CONST] = ''

    #     projection[ismvt.IS_FACILITY_MED_EQUIP_RECORDS_TAG] = deepcopy(facility_equip_records)

    # delete tags
    for tag in LG_TagsForDeletion:
        if tag in projection:
            del projection[tag]

    return projection

# IS_FACILITY_MED_EQUIP_RECORDS_TAG_V1           = '<IS_FacilityMedEquipRecords_V1>'
# IS_FACILITY_MED_EQUIP_GROUP_RECORDS_TAG_V1     = '<IS_FacilityMedEquipGroupRecords_V1>'

LG_TagsForDeletion = [
    # IS_FACILITY_MED_EQUIP_RECORDS_TAG_V1,
    # IS_FACILITY_MED_EQUIP_GROUP_RECORDS_TAG_V1
]
