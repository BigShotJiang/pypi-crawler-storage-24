import SpectrumCommon.Const.LG.LGConst as lgc
import SpectrumCommon.Const.GB.GBConst as gbc

from AvenirCommon.Database import GB_get_db_json
from os import environ

#######################################################################################################
#                                                                                                     #
#                                       Cold chain                                                    #
#                                                                                                     #
#######################################################################################################


def LG_load_cold_chain_DB():
    cold_chain_DB_file_name = lgc.LG_COLD_CHAIN_DB_NAME + "_" + lgc.LG_COLD_CHAIN_DB_CURR_VERSION + "." + gbc.GB_JSON
    cold_chain_DB = GB_get_db_json(
        environ[gbc.GB_SPECT_MOD_DATA_CONN_ENV], gbc.GB_LG_CONTAINER, cold_chain_DB_file_name
    )

    return cold_chain_DB
