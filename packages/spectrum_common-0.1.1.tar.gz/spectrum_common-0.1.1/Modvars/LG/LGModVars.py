# Test 2

from datetime import date


import SpectrumCommon.Const.LG.LGConst as lgc
import SpectrumCommon.Const.LG.LGTags as lgmvt
import SpectrumCommon.Modvars.LG.LGModVarDefs as lgmvd
import SpectrumCommon.Modvars.LG.LGModVarUtil as lgmvu
import SpectrumCommon.Modvars.LG.LGReadDatabases as lgrdb
# import SpectrumCommon.Util.LG.LGTransactionCalcUtil as lgtcu


def init_modvars(countryID, first_year, final_year, extra):
    """
    Initializes Logistic MVs for new IHT projections.

        Parameters:
            countryID (string):  Ex: BEN for Benin.

            first_year (int): First year selected by user.

            final_year (int): Final year selected by user.

            extra (dict): Any other fields.

        Returns:
            mod_vars_rec (dict): MVs.
    """

    # Load databases
    # IHT_costing_on = extra[gbc.GB_IHT_ON] if gbc.GB_IHT_ON in extra else False
    # TB_costing_on = extra[gbc.GB_TB_COSTING_ON] if gbc.GB_TB_COSTING_ON in extra else False

    # facility_med_equip_group_DB = isrd.IS_load_facility_med_equip_group_DB()
    # facility_equip_input_DB = isrd.IS_load_facility_equip_input_DB()

    value_bool_false = False

    value_str = ""
    value_date = (date.today().strftime("%B %d, %Y"),)

    num_years_inputs = final_year - first_year + 1

    default_cold_chain_records_DB = lgrdb.LG_load_cold_chain_DB()

    supply_chain_level_records = lgmvd.LG_init_supply_chain_level_records(num_years_inputs)
    num_supply_chain_levels = lgmvu.get_LG_num_supply_chain_levels(supply_chain_level_records)
    vehicle_type_records = lgmvd.LG_init_vehicle_type_records(num_supply_chain_levels, num_years_inputs)
    worker_type_records = lgmvd.LG_init_worker_type_records(
        num_supply_chain_levels, vehicle_type_records, num_years_inputs
    )
    cold_chain_records = lgmvd.LG_init_cold_chain_records(num_supply_chain_levels, num_years_inputs)
    default_cold_chain_records = lgmvd.LG_init_default_cold_chain_records(default_cold_chain_records_DB)

    mod_vars_rec = {
        # Inputs / pre-result / calculated
        lgmvt.LG_VERSION_TAG: 1,
        lgmvt.LG_DATA_CHANGED_TAG: value_bool_false,
        lgmvt.LG_PROJ_VALID_TAG: value_bool_false,
        lgmvt.LG_FILE_NAME_TAG: value_str,
        lgmvt.LG_PROJ_VALID_DATE_TAG: value_date,
        lgmvt.LG_SUPPLY_CHAIN_LEVEL_RECORDS_TAG: supply_chain_level_records,
        lgmvt.LG_WAREHOUSE_RECORDS_TAG: [],
        lgmvt.LG_DISAGGREGATION_LEVEL_TAG: lgc.LG_NATIONAL_NO_DISAGGREGATION,
        lgmvt.LG_CALC_APPROACH_TAG: lgc.LG_CALC_APPROACH_COSTING_MST_ID,
        lgmvt.LG_VEHICLE_TYPE_RECORDS_TAG: vehicle_type_records,
        lgmvt.LG_WORKER_TYPE_RECORDS_TAG: worker_type_records,
        lgmvt.LG_COLD_CHAIN_RECORDS_TAG: cold_chain_records,
        lgmvt.LG_DEFAULT_COLD_CHAIN_RECORDS_MEGA_TAG: default_cold_chain_records,
        lgmvt.LG_THIRD_PARTY_LOG_CONTRACT_RECORDS_TAG: [],
        lgmvt.LG_ENTER_COMP_OP_COSTS_WAREHOUSES_TAG: value_bool_false,
        lgmvt.LG_ENTER_COMP_CONSTRUCT_COSTS_WAREHOUSES_TAG: value_bool_false,
        lgmvt.LG_ENTER_COMP_MAINT_OP_COSTS_VEHICLES_TAG: value_bool_false,
        lgmvt.LG_COST_FUEL_PER_LITER_TAG: 0.0,
        lgmvt.LG_VEHICLE_TARG_CONFIG_OPTION_TAG: lgc.LG_TARGET_CONFIG_WAREHOUSE_STD_MST_ID,
        lgmvt.LG_VEHICLE_TARG_VARY_TRIPS_PER_YEAR_TAG: value_bool_false,
        lgmvt.LG_COLD_CHAIN_TARG_CONFIG_OPTION_TAG: lgc.LG_TARGET_CONFIG_WAREHOUSE_STD_MST_ID,
        lgmvt.LG_VEHICLE_PERFORMANCE_CONFIG_OPTION_TAG: lgc.LG_PERFORMANCE_CONFIG_OPTION_ROUTE_BASED,
        lgmvt.LG_NUM_WORK_HOURS_PER_DAY: 8,
        lgmvt.LG_NUM_WORK_DAYS_PER_YEAR: 220,
    }

    # Debugging
    # with open('C:\Proj\IHTSampleFile.JSON', 'w') as f:
    #   json.dump(mod_vars_dict, f)

    return mod_vars_rec
