import SpectrumCommon.Const.GB.GBConst as gbc
import SpectrumCommon.Const.LG.LGModVarFields as lgmvf

#######################################################################################################
#                                                                                                     #
#                                      Supply chain levels                                            #
#                                                                                                     #
#######################################################################################################


def get_LG_num_supply_chain_levels(supply_chain_level_records: list):
    return len(supply_chain_level_records)


def get_LG_supply_chain_level_rec(supply_chain_level_records: list, ID: int):
    supply_chain_level_recs = [
        supply_chain_level_rec
        for supply_chain_level_rec in supply_chain_level_records
        if supply_chain_level_rec[lgmvf.LG_SUPPLY_CHAIN_LEVEL_ID] == ID
    ]
    return supply_chain_level_recs[0] if len(supply_chain_level_recs) > 0 else {}


def get_LG_supply_chain_level_idx(supply_chain_level_records: list, ID: str):
    indices = [
        idx
        for (idx, supply_chain_level_rec) in enumerate(supply_chain_level_records)
        if supply_chain_level_rec[lgmvf.LG_SUPPLY_CHAIN_LEVEL_ID] == ID
    ]
    return indices[0] if len(indices) > 0 else gbc.GB_NOT_FOUND


###


def get_LG_supply_chain_level_name(supply_chain_level_rec: dict):
    return supply_chain_level_rec[lgmvf.LG_SUPPLY_CHAIN_LEVEL_NAME]


def set_LG_supply_chain_level_name(supply_chain_level_rec: dict, value: str):
    supply_chain_level_rec[lgmvf.LG_SUPPLY_CHAIN_LEVEL_NAME] = value


###


def get_LG_supply_chain_level_custom(supply_chain_level_rec: dict):
    return supply_chain_level_rec[lgmvf.LG_SUPPLY_CHAIN_LEVEL_CUSTOM]


def set_LG_supply_chain_level_custom(supply_chain_level_rec: dict, value: bool):
    supply_chain_level_rec[lgmvf.LG_SUPPLY_CHAIN_LEVEL_CUSTOM] = value


#######################################################################################################
#                                                                                                     #
#                                      Warehouses                                                     #
#                                                                                                     #
#######################################################################################################


def get_LG_warehouse_idx(warehouse_records: list, ID: str):
    indices = [
        idx for (idx, warehouse_rec) in enumerate(warehouse_records) if warehouse_rec[lgmvf.LG_WAREHOUSE_ID] == ID
    ]
    return indices[0] if len(indices) > 0 else gbc.GB_NOT_FOUND


def get_LG_warehouse_rec(warehouse_records: list, ID: str):
    warehouse_recs = [
        warehouse_rec for warehouse_rec in warehouse_records if warehouse_rec[lgmvf.LG_WAREHOUSE_ID] == ID
    ]
    return warehouse_recs[0] if len(warehouse_recs) > 0 else {}


def get_LG_warehouse_records_for_disag_level(warehouse_records: list, disag_level: int):
    return [
        warehouse_record
        for warehouse_record in warehouse_records
        if warehouse_record.get(lgmvf.LG_WAREHOUSE_SUPPLY_CHAIN_LEVEL_ID) == disag_level
    ]


def get_LG_warehouse_records_up_to_disag_level(warehouse_records: list, disag_level: int):
    return [
        warehouse_record
        for warehouse_record in warehouse_records
        if warehouse_record.get(lgmvf.LG_WAREHOUSE_SUPPLY_CHAIN_LEVEL_ID) <= disag_level
    ]


def get_LG_warehouse_type(warehouse_record: dict = {}):
    return warehouse_record.get(lgmvf.LG_WAREHOUSE_TYPE)


def set_LG_warehouse_name(warehouse_rec: dict, value: str):
    warehouse_rec[lgmvf.LG_WAREHOUSE_NAME] = value


def get_LG_warehouse_supply_chain_level_ID(warehouse_rec: dict):
    return warehouse_rec[lgmvf.LG_WAREHOUSE_SUPPLY_CHAIN_LEVEL_ID]


def get_LG_warehouse_ID(warehouse_rec: dict):
    return warehouse_rec[lgmvf.LG_WAREHOUSE_ID]


#######################################################################################################
#                                                                                                     #
#                                      Vehicle types                                                  #
#                                                                                                     #
#######################################################################################################


def get_LG_num_vehicle_types(vehicle_type_records: list):
    return len(vehicle_type_records)


def get_LG_vehicle_type_rec(vehicle_type_records: list, ID: str):
    for vehicle_type_rec in vehicle_type_records:
        if vehicle_type_rec.get(lgmvf.LG_VEHICLE_TYPE_ID) == ID:
            return vehicle_type_rec
    return {}


def get_LG_vehicle_type_idx(vehicle_type_records: list, ID: str):
    indices = [
        idx
        for (idx, vehicle_type_rec) in enumerate(vehicle_type_records)
        if vehicle_type_rec[lgmvf.LG_VEHICLE_TYPE_ID] == ID
    ]
    return indices[0] if len(indices) > 0 else gbc.GB_NOT_FOUND


###


def get_LG_vehicle_type_name(vehicle_type_rec: dict):
    return vehicle_type_rec[lgmvf.LG_VEHICLE_TYPE_NAME]


def set_LG_vehicle_type_name(vehicle_type_rec: dict, value: str):
    vehicle_type_rec[lgmvf.LG_VEHICLE_TYPE_NAME] = value


###


def get_LG_vehicle_type_custom(vehicle_type_rec: dict):
    return vehicle_type_rec[lgmvf.LG_VEHICLE_TYPE_CUSTOM]


def set_LG_vehicle_type_custom(vehicle_type_rec: dict, value: bool):
    vehicle_type_rec[lgmvf.LG_VEHICLE_TYPE_CUSTOM] = value


#######################################################################################################
#                                                                                                     #
#                                      Worker types                                                  #
#                                                                                                     #
#######################################################################################################


def get_LG_num_worker_types(worker_type_records: list):
    return len(worker_type_records)


def get_LG_worker_type_rec(worker_type_records: list, ID: str):
    worker_type_recs = [
        worker_type_rec for worker_type_rec in worker_type_records if worker_type_rec[lgmvf.LG_WORKER_TYPE_ID] == ID
    ]
    return worker_type_recs[0] if len(worker_type_recs) > 0 else {}


def get_LG_worker_type_idx(worker_type_records: list, ID: str):
    indices = [
        idx
        for (idx, worker_type_rec) in enumerate(worker_type_records)
        if worker_type_rec[lgmvf.LG_WORKER_TYPE_ID] == ID
    ]
    return indices[0] if len(indices) > 0 else gbc.GB_NOT_FOUND


###


def get_LG_worker_type_name(worker_type_rec: dict):
    return worker_type_rec[lgmvf.LG_WORKER_TYPE_NAME]


def set_LG_worker_type_name(worker_type_rec: dict, value: str):
    worker_type_rec[lgmvf.LG_WORKER_TYPE_NAME] = value


###


def get_LG_worker_type_custom(worker_type_rec: dict):
    return worker_type_rec[lgmvf.LG_WORKER_TYPE_CUSTOM]


def set_LG_worker_type_custom(worker_type_rec: dict, value: bool):
    worker_type_rec[lgmvf.LG_WORKER_TYPE_CUSTOM] = value


#######################################################################################################
#                                                                                                     #
#                                      Cold chain records                                             #
#                                                                                                     #
#######################################################################################################


def get_LG_cold_chain_rec(cold_chain_records: list, ID: str):
    cold_chain_recs = [
        cold_chain_rec for cold_chain_rec in cold_chain_records if cold_chain_rec[lgmvf.LG_COLD_CHAIN_ID] == ID
    ]
    return cold_chain_recs[0] if len(cold_chain_recs) > 0 else {}


def get_LG_cold_chain_rec_idx(cold_chain_records: list, ID: str):
    indices = [
        idx for (idx, cold_chain_rec) in enumerate(cold_chain_records) if cold_chain_rec[lgmvf.LG_COLD_CHAIN_ID] == ID
    ]
    return indices[0] if len(indices) > 0 else gbc.GB_NOT_FOUND


def set_LG_cold_chain_rec_name(cold_chain_rec: dict, value: str):
    cold_chain_rec[lgmvf.LG_COLD_CHAIN_NAME] = value


def set_LG_cold_chain_rec_custom(cold_chain_rec: dict, value: bool):
    cold_chain_rec[lgmvf.LG_COLD_CHAIN_CUSTOM] = value


def set_LG_cold_chain_rec_capacity(cold_chain_rec: dict, value: int):
    cold_chain_rec[lgmvf.LG_COLD_CHAIN_CAPACITY] = value


def set_LG_cold_chain_rec_unit_cost(cold_chain_rec: dict, value: int):
    cold_chain_rec[lgmvf.LG_COLD_CHAIN_UNIT_COST] = value


#######################################################################################################
#                                                                                                     #
#                                      Third party logistics contracts                                #
#                                                                                                     #
#######################################################################################################


def get_LG_num_third_party_log_contracts(third_party_log_contract_records: list):
    return len(third_party_log_contract_records)


def get_LG_third_party_log_contract_rec(third_party_log_contract_records: list, ID: str):
    third_party_log_contract_recs = [
        third_party_log_contract_rec
        for third_party_log_contract_rec in third_party_log_contract_records
        if third_party_log_contract_rec[lgmvf.LG_TPL_CONTRACT_ID] == ID
    ]
    return third_party_log_contract_recs[0] if len(third_party_log_contract_recs) > 0 else {}


def get_LG_third_party_log_contract_idx(third_party_log_contract_records: list, ID: str):
    indices = [
        idx
        for (idx, third_party_log_contract_rec) in enumerate(third_party_log_contract_records)
        if third_party_log_contract_rec[lgmvf.LG_F_THIRD_PARTY_LOG_CONTRACT_ID] == ID
    ]
    return indices[0] if len(indices) > 0 else gbc.GB_NOT_FOUND


###


def get_LG_third_party_log_contract_name(third_party_log_contract_rec: dict):
    return third_party_log_contract_rec[lgmvf.LG_TPL_CONTRACT_NAME]


def set_LG_third_party_log_contract_name(third_party_log_contract_rec: dict, value: str):
    third_party_log_contract_rec[lgmvf.LG_TPL_CONTRACT_NAME] = value


###


def get_LG_third_party_log_contract_custom(third_party_log_contract_rec: dict):
    return third_party_log_contract_rec[lgmvf.LG_TPL_CONTRACT_CUSTOM]


def set_LG_third_party_log_contract_custom(third_party_log_contract_rec: dict, value: bool):
    third_party_log_contract_rec[lgmvf.LG_TPL_CONTRACT_CUSTOM] = value
