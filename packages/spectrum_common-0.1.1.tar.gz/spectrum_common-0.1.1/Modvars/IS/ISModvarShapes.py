from SpectrumCommon.Const.IS import *
import SpectrumCommon.Const.IS.ISTags as ismvt
from SpectrumCommon.Modvars.GB.GBDefs import *

is_facility_dim = 'is_facility'
is_facility_ids = {}

is_pc_standard_rows_dim = 'is_pc_standard_rows_dim'
is_pc_standard_rows_id = {}

is_rehab_dim='is_rehab'
is_rehab_ids={
        
        IS_REHAB_SMALL_SCALE_CURR_ID         : 'Small',
        IS_REHAB_MEDIUM_SCALE_CURR_ID        : 'Medium',
        IS_REHAB_LARGE_SCALE_CURR_ID         : 'Large',
        IS_REHAB_MAINT_REPLACE_EQUIP_CURR_ID : 'Maintenance and equipment replacement',
}
is_facility_equip_types_dim = 'is_facility_equip_types'
is_facility_equip_types_ids = {
        IS_FACIL_MEDICAL_EQUIP_CURR_ID   : 'Medical',
        IS_FACIL_FURNITURE_EQUIP_CURR_ID : 'Furniture',
}
is_program_areas_dim = 'is_program_areas'
is_program_areas_indices = {}

is_med_equip_dim = 'is_med_equip'
is_med_equip_ids = {}

is_med_equip_group_dim = 'is_med_equip_group'
is_med_equip_group_ids = {}

is_furniture_dim = 'is_furniture'
is_furniture_ids = {}
is_vehicle_dim = 'is_vehicle'
is_vehicle_ids = {}
is_ict_dim = 'is_ict'
is_ict_ids = {}

IS_modvar_shapes = {
    
        #       
        ismvt.IS_VERSION_TAG_V1                               : gb_int_shape('IS Version'),
        ismvt.IS_DATA_CHANGED_TAG_V1                          : gb_bool_shape('IS Data Changed'), 
        ismvt.IS_PROJ_VALID_TAG_V1                            : gb_bool_shape('IS Project Valid'), 
        ismvt.IS_FILE_NAME_TAG_V1                             : gb_str_shape('File name'),
        ismvt.IS_PROJ_VALID_DATE_TAG_V1                       : gb_str_shape('IS projection valid date'),
        ismvt.IS_FACILITY_TYPE_RECORDS_TAG                    : gb_shape('IS Facility Type Records', '1D dict',
                                                                         dim=[is_facility_dim],
                                                                         indicies=[is_facility_ids],
                                                                         innerShape={
                                                                             'facilityTypeID' :gb_str_shape('facility type id'), 
                                                                             'stringConstant': gb_str_shape('string constant'), 
                                                                             'name': gb_str_shape('Name'), 
                                                                             'active':gb_bool_shape('Is active flag'), 
                                                                             'custom': gb_bool_shape('Is custom facility flag'), 
                                                                             'supportTypeMstID':gb_int_shape('support type master ID'), 
                                                                             'delivChanMstID':gb_str_shape('Delivery channel master id'), 
                                                                             'defFacilityTypeMapMstID':gb_int_shape('default facility type map master ID'), 
                                                                             'totalNumBaseline':gb_int_shape('Total number baseline'), 
                                                                             'avgNumBeds':gb_float_shape('Average number of beds'), 
                                                                             'avgOccupancyRateBeds':gb_float_shape('Average occupancy rate'), 
                                                                             'avgNumOutpatVisitsPerYear':gb_float_shape('Average outpatient visits per year'), 
                                                                             'yearsToBuild':gb_int_shape('Year to build'), 
                                                                             'totalConstructCost':gb_float_shape('Total construction cost'), 
                                                                             'landCost':gb_float_shape('Land cost'), 
                                                                             'constructionCostPerSqM':gb_float_shape('Construction cost per square meter'), 
                                                                             'avgSizeSqM':gb_float_shape('Average size square meter'), 
                                                                             'rehabCost':gb_shape('Rehab cost', '1D float', dim=[is_rehab_dim], indicies=[is_rehab_ids]), 
                                                                             'totalOpCost':gb_float_shape('Total operating cost'), 
                                                                             'totalOpCostAsPercOfConstructCost':gb_float_shape('total operating cost as percent of construction cost'), 
                                                                             'desiredPopPerFacilityRatioPopNorms':gb_float_shape('desired population per facility ratio'), 
                                                                             'targScaleUpPopNorms' : gb_year_shape('Target scale up population norms'), 
                                                                             'targScaleUpExistingPlansExpectedOp':gb_year_shape('Taget scale up existing plans expected Op'), 
                                                                             'targScaleUpExistingPlansBeginConstruct':gb_year_shape('taget scaleup existing plans begin construct'), 
                                                                             'targNumToRehab':gb_shape('Target number to rehab', '1D float', dim=[is_rehab_dim], indicies=[is_rehab_ids]), 
                                                                             'targNumToRehabByYear':gb_shape('Rehab cost', '2D float', dim=[is_rehab_dim, gb_year_dim], indicies=[is_rehab_ids, gb_year_indices]), 
                                                                             'numToEquip':gb_shape('Number to equip', '1D float',
                                                                                                   dim=[gb_year_dim], 
                                                                                                   indicies=[gb_year_indices]), #Todo: if iht is in specific plan mode then this key/value is 2d.  
                                                                             'equipmentPurchaseCost':gb_shape('Target number to rehab', '1D float', dim=[is_facility_equip_types_dim], indicies=[is_facility_equip_types_ids]), 
                                                                         }
                                                                ),
        ismvt.IS_FACILITY_MED_EQUIP_RECORDS_TAG               : gb_shape('IS Medical equipment Records', '1D dict',
                                                                         dim=[is_med_equip_dim],
                                                                         indicies=[is_med_equip_ids],
                                                                         innerShape={
                                                                                'facilityEquipID' : gb_str_shape('Facility equipment ID'),
                                                                                'custom' : gb_bool_shape('Is custom equipment flag'),
                                                                                'name' : gb_str_shape('Name'),
                                                                                'stringConstant' : gb_str_shape('String constant'),
                                                                                'facilityTypeID' : gb_str_shape('Facility type ID'),   
                                                                                'unitCost' : gb_float_shape('Unit cost'),
                                                                                'numUnits' : gb_int_shape('Number of units'),
                                                                                'workingLife' : gb_float_shape('Working life'),
                                                                                'facilityMedEquipGroupID' : gb_str_shape('Facility medical equipment group ID'),
                                                                 
                                                                        }
                                                                ),       
        ismvt.IS_FACILITY_MED_EQUIP_GROUP_RECORDS_TAG         : gb_shape('IS Medical equipment group Records', '1D dict',
                                                                         dim=[is_med_equip_group_dim],
                                                                         indicies=[is_med_equip_group_ids],
                                                                         innerShape={
                                                                             'facilityMedEquipGroupID' : gb_str_shape('Facility medical equipment group ID'),
                                                                             'name' : gb_str_shape('Name'),
                                                                             'stringConstant' : gb_str_shape('String constant'),
                                                                             'facilityTypeID' : gb_str_shape('Facility type ID'),                                                                      
                                                                        }
                                                                ),  
        ismvt.IS_FACILITY_FURNITURE_RECORDS_TAG_V1            : gb_shape('IS furniture Type Records', '1D dict',
                                                                         dim=[is_furniture_dim],
                                                                         indicies=[is_furniture_ids],
                                                                         innerShape={
                                                                             'facilityEquipID' : gb_str_shape('Facility equipment ID'),
                                                                             'custom' : gb_bool_shape('Is custom furniture flag'),
                                                                             'name' : gb_str_shape('Name'),
                                                                             'stringConstant' : gb_str_shape('String constant'),
                                                                             'facilityTypeID' : gb_str_shape('Facility type ID'),
                                                                             'unitCost' : gb_float_shape('Unit cost'),
                                                                             'numUnits' : gb_int_shape('Number of units'),
                                                                             'workingLife' : gb_float_shape('Working life')
                                                                        }
                                                                ),       
        ismvt.IS_ENTER_CONSTRUCT_COSTS_BY_COMP_TAG_V1         : gb_bool_shape('Enter construct costs by component'),  
        ismvt.IS_ENTER_OP_COST_PERC_CONSTRUCT_COST_TAG_V1     : gb_bool_shape('Enter operating costs as percentage of construct costs'),        
        ismvt.IS_FACIL_TARGET_SETTING_METHOD_TAG_V1           : gb_int_shape('Facility target setting method'),  
        ismvt.IS_VEHICLE_TYPE_RECORDS_TAG_V1                  : gb_shape('IS Vehicle Type Records', '1D dict',
                                                                         dim=[is_vehicle_dim],  
                                                                         indicies=[is_vehicle_ids],
                                                                         innerShape={
                                                                                        'vehicleTypeID' : gb_str_shape('Vehicle type ID'),
                                                                                        'name' : gb_str_shape('Name'),
                                                                                        'currNumber' : gb_float_shape('Current number'),
                                                                                        'unitCost' : gb_float_shape('Unit cost'),
                                                                                        'workingLifeInYears' : gb_float_shape('Working life in years'),
                                                                                        'driverSalary' : gb_float_shape('Driver salary'),
                                                                                        'fuelConsumption' : gb_float_shape('Fuel consumption'),
                                                                                        'fuelCostDirectEntry' : gb_float_shape('Fuel cost direct entry'),
                                                                                        'distanceDrivenPerYear' : gb_float_shape('Distance driven per year'),
                                                                                        'repairAndMaintPercCapCost' : gb_float_shape('Repair and maintenance percent capital cost'),
                                                                                        'targNumPerFacility' : gb_shape('Target number per facility', '1D float', dim=[is_facility_dim], indicies=[is_facility_ids]),
                                                                                        'targNumPerFacilityOtherNonFacBased' : gb_int_shape('Target number per facility other non-facility based'),
                                                                                }
                                                                ),
        ismvt.IS_DIRECT_ENTRY_FUEL_EXPEND_TAG_V1              : gb_bool_shape('Direct entry fuel expenditure'),
        ismvt.IS_COST_FUEL_PER_LITER_TAG_V1                   : gb_float_shape('Cost of fuel per liter'),
        ismvt.IS_ICT_EQUIPMENT_RECORDS_TAG_V1                 : gb_shape('IS ICT Equipment Records', '1D dict',
                                                                         dim=[is_ict_dim],      
                                                                         indicies=[is_ict_ids],
                                                                         innerShape={
                                                                                        'ictEquipID' : gb_str_shape('ICT equipment ID'),
                                                                                        'name' : gb_str_shape('Name'),
                                                                                        'currNumber' : gb_float_shape('Current number'),
                                                                                        'unitCost' : gb_float_shape('Unit cost'),
                                                                                        'workingLifeInYears' : gb_float_shape('Working life in years'),
                                                                                        'opCostPercCapCost' : gb_float_shape('Operating cost percent capital cost'),
                                                                                        'repairAndMaintPercCapCost' : gb_float_shape('Repair and maintenance percent capital cost'),
                                                                                        'targNumPerFacility' : gb_shape('Target number per facility', '1D float', dim=[is_facility_dim], indicies=[is_facility_ids]),
                                                                                        'targNumPerFacilityOtherNonFacBased' : gb_int_shape('Target number per facility other non-facility based'),
                                                                                        
                                                                                }
                                                                ),
        ismvt.IS_PROG_MGMT_DATA_TAG_V1                        : gb_shape('IS Program Management Data',  'dict',
                                                                           innerShape={
                                                                              'mainRowCosts': gb_shape('Main row costs', '2D float',
                                                                                dim=[is_pc_standard_rows_dim, gb_year_dim],
                                                                                indicies=[is_pc_standard_rows_id, gb_year_indices])
                                                                        },
                                                                           has_default=False
                                                                ),
        ismvt.IS_CALC_TOTAL_MED_EQUIP_COSTS_V1                : gb_bool_shape('Calculate total medical equipment costs flags'),
        ismvt.IS_CALC_MAINT_COSTS_AS_PERC_MED_EQUIP_COSTS_TAG : gb_bool_shape('Calculate maintenance costs as perc med equip costs flags'), # Enter directly/absolute number is default

        # # Outputs / results

        ismvt.IS_RES_TOTAL_NUM_FAC_AVAIL_TAG                     : gb_shape('Total number of facilities available', '2D float', dim=[is_facility_dim, gb_year_dim], indicies=[is_facility_ids, gb_year_indices]),
        ismvt.IS_RES_TOTAL_COST_BUILD_EQUIP_NEW_FAC_TAG          : gb_shape('Total cost to build and equip new facilities', '2D float', dim=[is_facility_dim, gb_year_dim], indicies=[is_facility_ids, gb_year_indices]),
        ismvt.IS_RES_NEW_FAC_CONSTRUCT_TAG                       : gb_shape('New facility construction costs', '2D float', dim=[is_facility_dim, gb_year_dim], indicies=[is_facility_ids, gb_year_indices]),
        ismvt.IS_RES_TOTAL_NUM_BEDS_AVAIL_TAG                    : gb_shape('Total number of beds available', '2D float', dim=[is_facility_dim, gb_year_dim], indicies=[is_facility_ids, gb_year_indices]),
        ismvt.IS_RES_NEW_FAC_FURNITURE_COSTS_TAG                 : gb_shape('New facility furniture costs', '2D float', dim=[is_facility_dim, gb_year_dim], indicies=[is_facility_ids, gb_year_indices]),
        ismvt.IS_RES_FAC_LAND_COSTS_TAG                          : gb_shape('Facility land costs', '2D float', dim=[is_facility_dim, gb_year_dim], indicies=[is_facility_ids, gb_year_indices]),
        ismvt.IS_RES_NEW_FAC_CONSTRUCT_COSTS_TAG                 : gb_shape('New facility construction costs', '2D float', dim=[is_facility_dim, gb_year_dim], indicies=[is_facility_ids, gb_year_indices]),
        ismvt.IS_RES_NEW_FAC_MED_EQUIP_COSTS_TAG                 : gb_shape('New facility medical equipment costs', '2D float', dim=[is_facility_dim, gb_year_dim], indicies=[is_facility_ids, gb_year_indices]),
        ismvt.IS_RES_FAC_REHAB_COSTS_TAG                         : gb_shape('Facility rehab costs', '2D float', dim=[is_facility_dim, gb_year_dim], indicies=[is_facility_ids, gb_year_indices]),
        ismvt.IS_RES_FAC_TOTAL_OP_COSTS_TAG                      : gb_shape('Facility total operating costs', '2D float', dim=[is_facility_dim, gb_year_dim], indicies=[is_facility_ids, gb_year_indices]),
        ismvt.IS_RES_OTHER_FAC_OP_COSTS_TAG                      : gb_shape('Other facility operating costs', '2D float', dim=[is_facility_dim, gb_year_dim], indicies=[is_facility_ids, gb_year_indices]),
        ismvt.IS_RES_FAC_WATER_COSTS_TAG                         : gb_shape('Facility water costs', '2D float', dim=[is_facility_dim, gb_year_dim], indicies=[is_facility_ids, gb_year_indices]),
        ismvt.IS_RES_FAC_ELECTRIC_COSTS_TAG                      : gb_shape('Facility electric costs', '2D float', dim=[is_facility_dim, gb_year_dim], indicies=[is_facility_ids, gb_year_indices]),
        
        ismvt.IS_RES_VEHIC_AVAIL_TAG                             : gb_shape('Vehicles available', '2D float', contingent=True, dim=[is_vehicle_dim, gb_year_dim], indicies=[is_vehicle_ids, gb_year_indices]),
        ismvt.IS_RES_VEHIC_PURCH_TAG                             : gb_shape('Vehicle purchase costs', '2D float', contingent=True, dim=[is_vehicle_dim, gb_year_dim], indicies=[is_vehicle_ids, gb_year_indices]),
        ismvt.IS_RES_VEHIC_PURCH_CAP_COSTS_TAG                   : gb_shape('Vehicle purchase capital costs', '2D float', contingent=True, dim=[is_vehicle_dim, gb_year_dim], indicies=[is_vehicle_ids, gb_year_indices]),
        ismvt.IS_RES_VEHIC_PURCH_CAP_COSTS_BY_FAC_TAG            : gb_shape('Vehicle purchase capital costs by facility', '2D float', contingent=True, dim=[is_vehicle_dim, is_facility_dim], indicies=[is_vehicle_ids, is_facility_ids]),
        ismvt.IS_RES_VEHIC_PURCH_CAP_COSTS_OTHER_NON_FAC_TAG     : gb_shape('Vehicle purchase capital costs other non-facility', '2D float', contingent=True, dim=[is_vehicle_dim, gb_year_dim], indicies=[is_vehicle_ids, gb_year_indices]),
        ismvt.IS_RES_VEHIC_MAINT_REPAIR_COSTS_TAG                : gb_shape('Vehicle maintenance and repair costs', '2D float', contingent=True, dim=[is_vehicle_dim, gb_year_dim], indicies=[is_vehicle_ids, gb_year_indices]),
        ismvt.IS_RES_VEHIC_MAINT_REPAIR_COSTS_BY_FAC_TAG         : gb_shape('Vehicle maintenance and repair costs by facility', '2D float', contingent=True, dim=[is_vehicle_dim, is_facility_dim], indicies=[is_vehicle_ids, is_facility_ids]),
        ismvt.IS_RES_VEHIC_MAINT_REPAIR_COSTS_OTHER_NON_FAC_TAG  : gb_shape('Vehicle maintenance and repair costs other non-facility', '2D float', contingent=True, dim=[is_vehicle_dim, gb_year_dim], indicies=[is_vehicle_ids, gb_year_indices]),
        ismvt.IS_RES_VEHIC_FUEL_COSTS_TAG                        : gb_shape('Vehicle fuel costs', '2D float', contingent=True, dim=[is_vehicle_dim, gb_year_dim], indicies=[is_vehicle_ids, gb_year_indices]),
        ismvt.IS_RES_VEHIC_FUEL_COSTS_BY_FAC_TAG                 : gb_shape('Vehicle fuel costs by facility', '2D float', contingent=True, dim=[is_vehicle_dim, is_facility_dim], indicies=[is_vehicle_ids, is_facility_ids]),
        ismvt.IS_RES_VEHIC_FUEL_COSTS_OTHER_NON_FAC_TAG          : gb_shape('Vehicle fuel costs other non-facility', '2D float', contingent=True, dim=[is_vehicle_dim, gb_year_dim], indicies=[is_vehicle_ids, gb_year_indices]),
        ismvt.IS_RES_VEHIC_DRIVER_SALARIES_TAG                   : gb_shape('Vehicle driver salaries', '2D float', contingent=True, dim=[is_vehicle_dim, gb_year_dim], indicies=[is_vehicle_ids, gb_year_indices]),
        ismvt.IS_RES_VEHIC_DRIVER_SALARIES_BY_FAC_TAG            : gb_shape('Vehicle driver salaries by facility', '2D float', contingent=True, dim=[is_vehicle_dim, is_facility_dim], indicies=[is_vehicle_ids, is_facility_ids]),
        ismvt.IS_RES_VEHIC_DRIVER_SALARIES_OTHER_NON_FAC_TAG     : gb_shape('Vehicle driver salaries other non-facility', '2D float', contingent=True, dim=[is_vehicle_dim, gb_year_dim], indicies=[is_vehicle_ids, gb_year_indices]),
        
        ismvt.IS_RES_ICT_AVAIL_TAG                               : gb_shape('ICT available', '2D float', contingent=True, dim=[is_ict_dim, gb_year_dim], indicies=[is_ict_ids, gb_year_indices]),
        ismvt.IS_RES_ICT_PURCH_TAG                               : gb_shape('ICT purchase costs', '2D float', contingent=True, dim=[is_ict_dim, gb_year_dim], indicies=[is_ict_ids, gb_year_indices]),
        ismvt.IS_RES_ICT_CAP_COSTS_TAG                           : gb_shape('ICT capital costs', '2D float', contingent=True, dim=[is_ict_dim, gb_year_dim], indicies=[is_ict_ids, gb_year_indices]),
        ismvt.IS_RES_ICT_CAP_COSTS_BY_FAC_TAG                    : gb_shape('ICT capital costs by facility', '2D float', contingent=True, dim=[is_ict_dim, is_facility_dim], indicies=[is_ict_ids, is_facility_ids]),
        ismvt.IS_RES_ICT_CAP_COSTS_OTHER_NON_FAC_TAG             : gb_shape('ICT capital costs other non-facility', '2D float', contingent=True, dim=[is_ict_dim, gb_year_dim], indicies=[is_ict_ids, gb_year_indices]),
        ismvt.IS_RES_ICT_MAINT_REPAIR_OP_COSTS_TAG               : gb_shape('ICT maintenance and repair operating costs', '2D float', contingent=True, dim=[is_ict_dim, gb_year_dim], indicies=[is_ict_ids, gb_year_indices]),
        ismvt.IS_RES_ICT_MAINT_REPAIR_OP_COSTS_BY_FAC_TAG        : gb_shape('ICT maintenance and repair operating costs by facility', '2D float', contingent=True, dim=[is_ict_dim, is_facility_dim], indicies=[is_ict_ids, is_facility_ids]),
        ismvt.IS_RES_ICT_MAINT_REPAIR_OP_COSTS_OTHER_NON_FAC_TAG : gb_shape('ICT maintenance and repair operating costs other non-facility', '2D float', contingent=True, dim=[is_ict_dim, gb_year_dim], indicies=[is_ict_ids, gb_year_indices]),
        
        ismvt.IS_RES_MED_EQUIP_MAINT_CALIB_COSTS_TB_TAG          : gb_shape('Medical equipment maintenance calibration costs by facility', '2D float', contingent=True, dim=[is_facility_dim, gb_year_dim], indicies=[is_facility_ids, gb_year_indices]),

        # # TB costing mode
        ismvt.IS_RES_EQUIPMENT_COSTS_DSC_V1                      : gb_shape('Equipment costs by facility', '2D float', dim=[is_facility_dim, gb_year_dim], indicies=[is_facility_ids, gb_year_indices])
    
}