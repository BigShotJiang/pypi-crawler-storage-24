import SpectrumCommon.Const.GB.GBConst as gbc

import SpectrumCommon.Const.IS.ISModVarFields as ismvf

#######################################################################################################
#                                                                                                     #
#                                      Facility types                                                 #
#                                                                                                     #
#######################################################################################################

def get_IS_num_facility_types(facility_type_records = list):
    return len(facility_type_records)

def get_IS_facility_type_rec_from_curr_ID(facility_type_records = list, curr_ID = int):
    return facility_type_records[curr_ID - 1]

def get_IS_facility_type_rec(facility_type_records = list, ID = str):
    facility_type_recs = [facility_type_rec for facility_type_rec in facility_type_records if facility_type_rec[ismvf.IS_FACIL_TYPE_ID] == ID]
    return facility_type_recs[0] if len(facility_type_recs) > 0 else gbc.GB_NOT_FOUND

    # facility_type_rec = None
    
    # ft = 0
    # stop = False
    # num_facility_types = get_IS_num_facility_types(facility_type_records)

    # while (ft < num_facility_types) and (not stop):

    #     facility_type_ID = get_IS_facility_type_ID(facility_type_records[ft])

    #     if facility_type_ID == ID:
    #         facility_type_rec = facility_type_records[ft]
    #         stop = True

    #     ft += 1

    # return facility_type_rec

def get_IS_facility_type_idx(facility_type_records = list, ID = str):
    indices = [idx for (idx, facility_type_rec) in enumerate(facility_type_records) if facility_type_rec[ismvf.IS_FACIL_TYPE_ID] == ID]
    return indices[0] if len(indices) > 0 else gbc.GB_NOT_FOUND

    # idx = gbc.GB_NOT_FOUND
    
    # ft = 0
    # stop = False
    # num_facility_types = get_IS_num_facility_types(facility_type_records)

    # while (ft < num_facility_types) and (not stop):

    #     facility_type_ID = get_IS_facility_type_ID(facility_type_records[ft])

    #     if facility_type_ID == ID:
    #         idx = ft
    #         stop = True

    #     ft += 1

    # return idx

###

def get_IS_facility_type_idx_and_rec(facility_type_records, ID = str):
    indices_and_recs = [(idx, facility_type_rec) for (idx, facility_type_rec) in enumerate(facility_type_records) if facility_type_rec[ismvf.IS_FACIL_TYPE_ID] == ID]
    return indices_and_recs[0] if len(indices_and_recs) > 0 else (gbc.GB_NOT_FOUND, {})

###

def get_IS_facility_type_ID(facility_type_rec = dict):
    return facility_type_rec[ismvf.IS_FACIL_TYPE_ID]

def set_IS_faciilty_type_ID(facility_type_rec = dict, value = str):
    facility_type_rec[ismvf.IS_FACIL_TYPE_ID] = value

###

def get_IS_facility_type_name(facility_type_rec = dict):
    return facility_type_rec[ismvf.IS_FACIL_NAME]

def set_IS_facility_type_name(facility_type_rec = dict, value = str):
    facility_type_rec[ismvf.IS_FACIL_NAME] = value

###

def get_IS_facility_type_string_constant(facility_type_rec = dict):
    return facility_type_rec[ismvf.IS_FACIL_STR_CONSTANT]

def set_IS_facility_type_string_constant(facility_type_rec = dict, value = str):
    facility_type_rec[ismvf.IS_FACIL_STR_CONSTANT] = value

###

def get_IS_facility_type_active(facility_type_rec = dict):
    return facility_type_rec[ismvf.IS_FACIL_ACTIVE]

def set_IS_facility_type_active(facility_type_rec = dict, value = bool):
    facility_type_rec[ismvf.IS_FACIL_ACTIVE] = value

###

def get_IS_facility_type_custom(facility_type_rec = dict):
    return facility_type_rec[ismvf.IS_FACIL_CUSTOM]

def set_IS_facility_type_custom(facility_type_rec = dict, value = bool):
    facility_type_rec[ismvf.IS_FACIL_CUSTOM] = value

###

def get_IS_facility_support_type_map(facility_type_rec = dict):
    return facility_type_rec[ismvf.IS_FACIL_SUPP_TYPE_MST_ID]

def set_IS_facility_support_type_map(facility_type_rec = dict, value = int):
    facility_type_rec[ismvf.IS_FACIL_SUPP_TYPE_MST_ID] = value

###

def get_IS_facility_deliv_chan_map(facility_type_rec = dict):
    return facility_type_rec[ismvf.IS_FACIL_DELIV_CHAN_MST_ID]

def set_IS_facility_deliv_chan_map(facility_type_rec = dict, value = str):
    facility_type_rec[ismvf.IS_FACIL_DELIV_CHAN_MST_ID] = value

###

def get_IS_facility_type_default_map(facility_type_rec = dict):
    return facility_type_rec[ismvf.IS_FACIL_DEFAULT_MAP_MST_ID]

def set_IS_facility_type_default_map(facility_type_rec = dict, value = int):
    facility_type_rec[ismvf.IS_FACIL_DEFAULT_MAP_MST_ID] = value

###

def get_IS_facility_type_total_equip_cost(facility_type_rec = dict, equip_type_curr_ID = int):
    return facility_type_rec[ismvf.IS_FACIL_EQUIP_PURCHASE_COST][equip_type_curr_ID - 1]

def set_IS_facility_type_total_equip_cost(facility_type_rec = dict, equip_type_curr_ID = int, value = float):
    facility_type_rec[ismvf.IS_FACIL_EQUIP_PURCHASE_COST][equip_type_curr_ID - 1] = value

###

def get_IS_facility_type_total_equip_cost_by_prog_area(facility_type_rec = dict, equip_type_curr_ID = int, prog_area_curr_ID = int):
    return facility_type_rec[ismvf.IS_FACIL_EQUIP_PURCHASE_COST][prog_area_curr_ID - 1][equip_type_curr_ID - 1]

def set_IS_facility_type_total_equip_cost_by_prog_area(facility_type_rec = dict, equip_type_curr_ID = int, prog_area_curr_ID = int, value = float):
    facility_type_rec[ismvf.IS_FACIL_EQUIP_PURCHASE_COST][prog_area_curr_ID - 1][equip_type_curr_ID - 1] = value

###

def get_IS_facility_type_med_equip_maint_cost(facility_type_rec = dict):
    return facility_type_rec[ismvf.IS_FACIL_MED_EQUIP_MAINT_COST]

def set_IS_facility_type_med_equip_maint_cost(facility_type_rec = dict, value = float):
    facility_type_rec[ismvf.IS_FACIL_MED_EQUIP_MAINT_COST] = value

###

def get_IS_facility_type_med_equip_maint_cost_by_prog_area(facility_type_rec = dict, prog_area_curr_ID = int):
    return facility_type_rec[ismvf.IS_FACIL_MED_EQUIP_MAINT_COST][prog_area_curr_ID - 1]

def set_IS_facility_type_med_equip_maint_cost_by_prog_area(facility_type_rec = dict, prog_area_curr_ID = int, value = float):
    facility_type_rec[ismvf.IS_FACIL_MED_EQUIP_MAINT_COST][prog_area_curr_ID - 1] = value

###

def get_IS_facility_type_med_equip_calib_cost(facility_type_rec = dict):
    return facility_type_rec[ismvf.IS_FACIL_MED_EQUIP_CALIB_COST]

def set_IS_facility_type_med_equip_calib_cost(facility_type_rec = dict, value = float):
    facility_type_rec[ismvf.IS_FACIL_MED_EQUIP_CALIB_COST] = value

###

def get_IS_facility_type_med_equip_calib_cost_by_prog_area(facility_type_rec = dict, prog_area_curr_ID = int):
    return facility_type_rec[ismvf.IS_FACIL_MED_EQUIP_CALIB_COST][prog_area_curr_ID - 1]

def set_IS_facility_type_med_equip_calib_cost_by_prog_area(facility_type_rec = dict, prog_area_curr_ID = int, value = float):
    facility_type_rec[ismvf.IS_FACIL_MED_EQUIP_CALIB_COST][prog_area_curr_ID - 1] = value

###

def get_IS_facility_type_num_baseline(facility_type_rec = dict):
    return facility_type_rec[ismvf.IS_FACIL_TOTAL_NUMBER_BASELINE]

def set_IS_facility_type_num_baseline(facility_type_rec = dict, value = int):
    facility_type_rec[ismvf.IS_FACIL_TOTAL_NUMBER_BASELINE] = value

###

def get_IS_facility_type_num_baseline(facility_type_rec = dict):
    return facility_type_rec[ismvf.IS_FACIL_TOTAL_NUMBER_BASELINE]

def set_IS_facility_type_num_baseline(facility_type_rec = dict, value = int):
    facility_type_rec[ismvf.IS_FACIL_TOTAL_NUMBER_BASELINE] = value

###

def get_IS_facility_type_num_years_to_build(facility_type_rec = dict):
    return facility_type_rec[ismvf.IS_FACIL_YEARS_TO_BUILD]

def set_IS_facility_type_num_years_to_build(facility_type_rec = dict, value = int):
    facility_type_rec[ismvf.IS_FACIL_YEARS_TO_BUILD] = value

###

def get_IS_facility_type_scale_up_pop_norms(facility_type_rec = dict, t = int):
    return facility_type_rec[ismvf.IS_FACIL_TARG_SCALE_UP_POP_NORMS][t]

def set_IS_facility_type_scale_up_pop_norms(facility_type_rec = dict, t = int, value = int):
    facility_type_rec[ismvf.IS_FACIL_TARG_SCALE_UP_POP_NORMS][t] = value

###

def get_IS_facility_type_scale_up_exist_plans_expected_op(facility_type_rec = dict, t = int):
    return facility_type_rec[ismvf.IS_FACIL_TARG_SCALE_UP_EXIST_PLANS_EXPECTED_OP][t]

def set_IS_facility_type_scale_up_existing_plans_expected_op(facility_type_rec = dict, t = int, value = int):
    facility_type_rec[ismvf.IS_FACIL_TARG_SCALE_UP_EXIST_PLANS_EXPECTED_OP][t] = value

###

def get_IS_facility_type_scale_up_exist_plans_begin_construct(facility_type_rec = dict, t = int):
    return facility_type_rec[ismvf.IS_FACIL_TARG_SCALE_UP_EXIST_PLANS_BEGIN_CONSTRUCT][t]

def set_IS_facility_type_scale_up_existing_plans_begin_construct(facility_type_rec = dict, t = int, value = int):
    facility_type_rec[ismvf.IS_FACIL_TARG_SCALE_UP_EXIST_PLANS_BEGIN_CONSTRUCT][t] = value

###

def get_IS_facility_type_total_construction_cost(facility_type_rec = dict):
    return facility_type_rec[ismvf.IS_FACIL_TOTAL_CONSTRUCT_COST]

def set_IS_facility_type_total_construction_cost(facility_type_rec = dict, value = int):
    facility_type_rec[ismvf.IS_FACIL_TOTAL_CONSTRUCT_COST] = value

###

def get_IS_facility_type_desired_pop_facility_ratio(facility_type_rec = dict):
    return facility_type_rec[ismvf.IS_FACIL_DESIRED_POP_FACIL_RATIO_POP_NORMS]

def set_IS_facility_type_desired_pop_facility_ratio(facility_type_rec = dict, value = float):
    facility_type_rec[ismvf.IS_FACIL_DESIRED_POP_FACIL_RATIO_POP_NORMS] = value

###

def get_IS_facility_type_avg_num_beds(facility_type_rec = dict):
    return facility_type_rec[ismvf.IS_FACIL_AVG_NUM_BEDS]

def set_IS_facility_type_avg_num_beds(facility_type_rec = dict, value = int):
    facility_type_rec[ismvf.IS_FACIL_AVG_NUM_BEDS] = value

###

def get_IS_facility_type_rehab_cost(facility_type_rec = dict, rehab_type_curr_ID = int):
    return facility_type_rec[ismvf.IS_FACIL_REHAB_COST][rehab_type_curr_ID - 1]

def set_IS_facility_type_rehab_cost(facility_type_rec = dict, rehab_type_curr_ID = int, value = float):
    facility_type_rec[ismvf.IS_FACIL_REHAB_COST][rehab_type_curr_ID - 1] = value

###

def get_IS_facility_type_targ_num_to_rehab_by_year(facility_type_rec = dict, rehab_type_curr_ID = int, t = int):
    return facility_type_rec[ismvf.IS_FACIL_TARG_NUM_TO_REHAB_BY_YEAR][rehab_type_curr_ID - 1][t]

def set_IS_facility_type_targ_num_to_rehab_by_year(facility_type_rec = dict, rehab_type_curr_ID = int, t = int, value = float):
    facility_type_rec[ismvf.IS_FACIL_TARG_NUM_TO_REHAB_BY_YEAR][rehab_type_curr_ID - 1][t] = value

###

def get_IS_facility_type_total_op_cost(facility_type_rec = dict):
    return facility_type_rec[ismvf.IS_FACIL_TOTAL_OP_COST]

def set_IS_facility_type_total_op_cost(facility_type_rec = dict, value = float):
    facility_type_rec[ismvf.IS_FACIL_TOTAL_OP_COST] = value


###

def get_IS_facility_type_land_cost(facility_type_rec = dict):
    return facility_type_rec[ismvf.IS_FACIL_LAND_COST]

def set_IS_facility_type_land_cost(facility_type_rec = dict, value = float):
    facility_type_rec[ismvf.IS_FACIL_LAND_COST] = value

###

def get_IS_facility_type_construct_cost_per_sq_m(facility_type_rec = dict):
    return facility_type_rec[ismvf.IS_FACIL_CONSTRUCT_COST_PER_SQ_M]

def set_IS_facility_type_construct_cost_per_sq_m(facility_type_rec = dict, value = float):
    facility_type_rec[ismvf.IS_FACIL_CONSTRUCT_COST_PER_SQ_M] = value

###

def get_IS_facility_type_avg_size_in_sq_m(facility_type_rec = dict):
    return facility_type_rec[ismvf.IS_FACIL_AVG_SIZE_IN_SQ_M]

def set_IS_facility_type_avg_size_in_sq_m(facility_type_rec = dict, value = float):
    facility_type_rec[ismvf.IS_FACIL_AVG_SIZE_IN_SQ_M] = value

###

def get_IS_facility_type_num_to_equip(facility_type_rec = dict, t = int):
    return facility_type_rec[ismvf.IS_FACIL_NUM_TO_EQUIP][t]

def set_IS_facility_type_num_to_equip(facility_type_rec = dict, t = int, value = float):
    facility_type_rec[ismvf.IS_FACIL_NUM_TO_EQUIP][t] = value

#######################################################################################################
#                                                                                                     #
#                                      Vehicle types                                                  #
#                                                                                                     #
#######################################################################################################

def add_IS_vehicle_type_rec(vehicle_type_records = list, vehicle_type_rec = dict):
    vehicle_type_records.append(vehicle_type_rec)

def get_IS_num_vehicle_types(vehicle_type_records = list):
    return len(vehicle_type_records)

def get_IS_vehicle_type_rec(vehicle_type_records = list, ID = str):
    vehicle_type_recs = [vehicle_type_rec for vehicle_type_rec in vehicle_type_records if vehicle_type_rec[ismvf.IS_VEHIC_ID] == ID]
    return vehicle_type_recs[0] if len(vehicle_type_recs) > 0 else gbc.GB_NOT_FOUND

    # vehicle_type_rec = None
    
    # vt = 0
    # stop = False
    # num_vehicle_types = get_IS_num_vehicle_types(vehicle_type_records)

    # while (vt < num_vehicle_types) and (not stop):

    #     vehicle_type_ID = get_IS_vehicle_type_ID(vehicle_type_records[vt])

    #     if vehicle_type_ID == ID:
    #         vehicle_type_rec = vehicle_type_records[vt]
    #         stop = True

    #     vt += 1

    # return vehicle_type_rec

def get_IS_vehicle_type_rec_from_curr_ID(vehicle_type_records = list, curr_ID = int):
    return vehicle_type_records[curr_ID - 1]

def get_IS_vehicle_type_idx(vehicle_type_records = list, ID = str):
    indices = [idx for (idx, vehicle_type_rec) in enumerate(vehicle_type_records) if vehicle_type_rec[ismvf.IS_VEHIC_ID] == ID]
    return indices[0] if len(indices) > 0 else gbc.GB_NOT_FOUND

    # idx = gbc.GB_NOT_FOUND
    
    # vt = 0
    # stop = False
    # num_vehicle_types = get_IS_num_vehicle_types(vehicle_type_records)

    # while (vt < num_vehicle_types) and (not stop):

    #     vehicle_type_ID = get_IS_vehicle_type_ID(vehicle_type_records[vt])

    #     if vehicle_type_ID == ID:
    #         idx = vt
    #         stop = True

    #     vt += 1

    # return idx

###

def get_IS_vehicle_type_ID(vehicle_type_rec = dict):
    return vehicle_type_rec[ismvf.IS_VEHIC_ID]

def set_IS_vehicle_type_ID(vehicle_type_rec = dict, value = str):
    vehicle_type_rec[ismvf.IS_VEHIC_ID] = value

###

def get_IS_vehicle_type_name(vehicle_type_rec = dict):
    return vehicle_type_rec[ismvf.IS_VEHIC_NAME]

def set_IS_vehicle_type_name(vehicle_type_rec = dict, value = str):
    vehicle_type_rec[ismvf.IS_VEHIC_NAME] = value

###

def get_IS_vehicle_type_custom(vehicle_type_rec = dict):
    return vehicle_type_rec[ismvf.IS_VEHIC_CUSTOM]

def set_IS_vehicle_type_custom(vehicle_type_rec = dict, value = bool):
    vehicle_type_rec[ismvf.IS_VEHIC_CUSTOM] = value

###

def get_IS_vehicle_type_curr_number(vehicle_type_rec = dict):
    return vehicle_type_rec[ismvf.IS_VEHIC_CURR_NUMBER]

def set_IS_vehicle_type_curr_number(vehicle_type_rec = dict, value = str):
    vehicle_type_rec[ismvf.IS_VEHIC_CURR_NUMBER] = value

###

def get_IS_vehicle_type_unit_cost(vehicle_type_rec = dict):
    return vehicle_type_rec[ismvf.IS_VEHIC_UNIT_COST]

def set_IS_vehicle_type_unit_cost(vehicle_type_rec = dict, value = str):
    vehicle_type_rec[ismvf.IS_VEHIC_UNIT_COST] = value

###

def get_IS_vehicle_type_working_life_years(vehicle_type_rec = dict):
    return vehicle_type_rec[ismvf.IS_VEHIC_WORKING_LIFE_YEARS]

def set_IS_vehicle_type_working_life_years(vehicle_type_rec = dict, value = str):
    vehicle_type_rec[ismvf.IS_VEHIC_WORKING_LIFE_YEARS] = value

###

def get_IS_vehicle_type_drivery_salary(vehicle_type_rec = dict):
    return vehicle_type_rec[ismvf.IS_VEHIC_DRIVER_SALARY]

def set_IS_vehicle_type_drivery_salary(vehicle_type_rec = dict, value = str):
    vehicle_type_rec[ismvf.IS_VEHIC_DRIVER_SALARY] = value

###

def get_IS_vehicle_type_fuel_consumption(vehicle_type_rec = dict):
    return vehicle_type_rec[ismvf.IS_VEHIC_FUEL_CONSUMPTION]

def set_IS_vehicle_type_fuel_consumption(vehicle_type_rec = dict, value = str):
    vehicle_type_rec[ismvf.IS_VEHIC_FUEL_CONSUMPTION] = value

###

def get_IS_vehicle_type_distance_driver_per_year(vehicle_type_rec = dict):
    return vehicle_type_rec[ismvf.IS_VEHIC_DISTANCE_DRIVEN_PER_YEAR]

def set_IS_vehicle_type_distance_driven_per_year(vehicle_type_rec = dict, value = str):
    vehicle_type_rec[ismvf.IS_VEHIC_DISTANCE_DRIVEN_PER_YEAR] = value

###

def get_IS_vehicle_type_fuel_cost_direct_entry(vehicle_type_rec = dict):
    return vehicle_type_rec[ismvf.IS_VEHIC_FUEL_COST_DIRECT_ENTRY]

def set_IS_vehicle_type_fuel_cost_direct_entry(vehicle_type_rec = dict, value = str):
    vehicle_type_rec[ismvf.IS_VEHIC_FUEL_COST_DIRECT_ENTRY] = value

###

def get_IS_vehicle_type_repair_maint_perc_cap_cost(vehicle_type_rec = dict):
    return vehicle_type_rec[ismvf.IS_VEHIC_REPAIR_MAINT_PERC_CAP_COST]

def set_IS_vehicle_type_repair_maint_perc_cap_cost(vehicle_type_rec = dict, value = str):
    vehicle_type_rec[ismvf.IS_VEHIC_REPAIR_MAINT_PERC_CAP_COST] = value

###

def get_IS_vehicle_type_targ_num_per_facility(vehicle_type_rec = dict, facility_type_curr_ID = int):
    return vehicle_type_rec[ismvf.IS_VEHIC_TARG_NUM_PER_FACILITY][facility_type_curr_ID - 1]

def set_IS_vehicle_type_targ_num_per_facility(vehicle_type_rec = dict, facility_type_curr_ID = int, value = str):
    vehicle_type_rec[ismvf.IS_VEHIC_TARG_NUM_PER_FACILITY][facility_type_curr_ID - 1] = value

###

def get_IS_vehicle_type_targ_num_per_facility_other(vehicle_type_rec = dict):
    return vehicle_type_rec[ismvf.IS_VEHIC_TARG_NUM_PER_FACILITY_OTHER]

def set_IS_vehicle_type_targ_num_per_facility_other(vehicle_type_rec = dict, value = str):
    vehicle_type_rec[ismvf.IS_VEHIC_TARG_NUM_PER_FACILITY_OTHER] = value

#######################################################################################################
#                                                                                                     #
#                                      ICT equipment types                                            #
#                                                                                                     #
#######################################################################################################

def get_IS_num_ICT_equipment_types(ICT_equipment_type_records = list):
    return len(ICT_equipment_type_records)

def get_IS_ICT_equipment_type_rec(ICT_equip_type_records = list, ID = str):
    ICT_equip_type_recs = [ICT_equip_type_rec for ICT_equip_type_rec in ICT_equip_type_records if ICT_equip_type_rec[ismvf.IS_ICT_EQUIP_ID] == ID]
    return ICT_equip_type_recs[0] if len(ICT_equip_type_recs) > 0 else gbc.GB_NOT_FOUND

    # ICT_equipment_type_rec = None
    
    # ict = 0
    # stop = False
    # num_ICT_equipment_types = get_IS_num_ICT_equipment_types(ICT_equipment_type_records)

    # while (ict < num_ICT_equipment_types) and (not stop):

    #     ICT_equipment_type_ID = get_IS_ICT_equipment_type_ID(ICT_equipment_type_records[ict])

    #     if ICT_equipment_type_ID == ID:
    #         ICT_equipment_type_rec = ICT_equipment_type_records[ict]
    #         stop = True

    #     ict += 1

    # return ICT_equipment_type_rec

###

def get_IS_ICT_equipment_type_idx(ICT_equip_type_records = list, ID = str):
    indices = [idx for (idx, ICT_equip_type_rec) in enumerate(ICT_equip_type_records) if ICT_equip_type_rec[ismvf.IS_ICT_EQUIP_ID] == ID]
    return indices[0] if len(indices) > 0 else gbc.GB_NOT_FOUND

    # idx = gbc.GB_NOT_FOUND
    
    # ict = 0
    # stop = False
    # num_ICT_equipment_types = get_IS_num_ICT_equipment_types(ICT_equipment_type_records)

    # while (ict < num_ICT_equipment_types) and (not stop):

    #     ICT_equipment_type_ID = get_IS_ICT_equipment_type_ID(ICT_equipment_type_records[ict])

    #     if ICT_equipment_type_ID == ID:
    #         idx = ict
    #         stop = True

    #     ict += 1

    # return idx

###

def get_IS_ICT_equipment_type_ID(ICT_equipment_type_rec = dict):
    return ICT_equipment_type_rec[ismvf.IS_ICT_EQUIP_ID]

def set_IS_ICT_equipment_type_ID(ICT_equipment_type_rec = dict, value = str):
    ICT_equipment_type_rec[ismvf.IS_ICT_EQUIP_ID] = value

###

def get_IS_ICT_equipment_type_name(ICT_equipment_type_rec = dict):
    return ICT_equipment_type_rec[ismvf.IS_ICT_EQUIP_NAME]

def set_IS_ICT_equipment_type_name(ICT_equipment_type_rec = dict, value = str):
    ICT_equipment_type_rec[ismvf.IS_ICT_EQUIP_NAME] = value

###

def get_IS_ICT_equipment_type_custom(ICT_equipment_type_rec = dict):
    return ICT_equipment_type_rec[ismvf.IS_ICT_EQUIP_CUSTOM]

def set_IS_ICT_equipment_type_custom(ICT_equipment_type_rec = dict, value = bool):
    ICT_equipment_type_rec[ismvf.IS_ICT_EQUIP_CUSTOM] = value

#######################################################################################################
#                                                                                                     #
#                                 Facility medical equipment groups (MEGs)                            #
#                                                                                                     #
#######################################################################################################

# Returns all facility MEG records for a particular facility type
def get_IS_facility_MEG_records(facility_MEG_records_all = list, facility_type_ID = str):
    # Reduce list to contain only groups for the specified facility.
    facility_MEG_records_for_facility = [facility_MEG_rec for facility_MEG_rec in facility_MEG_records_all \
        if facility_MEG_rec[ismvf.IS_FACIL_MEG_FACIL_TYPE_ID] == facility_type_ID]
    return facility_MEG_records_for_facility

###

def get_IS_facility_MEG_rec(facility_MEG_records_all = list, facility_type_ID = str, ID = str):
    facility_MEG_recs = [facility_MEG_rec for facility_MEG_rec in facility_MEG_records_all \
        if (facility_MEG_rec[ismvf.IS_FACIL_TYPE_ID] == facility_type_ID) and (facility_MEG_rec[ismvf.IS_FACIL_MEG_ID] == ID)]
    return facility_MEG_recs[0] if len(facility_MEG_recs) > 0 else gbc.GB_NOT_FOUND
    
    # num_groups = len(facility_MEG_records_all)

    # stop = False
    # i = 0
    # while (i < num_groups) and (not stop):
    #     facility_MEG_rec_i = facility_MEG_records_all[i]
        
    #     facility_type_ID_i = get_IS_facility_MEG_facility_type_ID(facility_MEG_rec_i)
    #     ID_i = get_IS_facility_MEG_ID(facility_MEG_rec_i)

    #     if (facility_type_ID_i == facility_type_ID) and (ID_i == ID):
    #         stop = True
    #     else:
    #         i = i + 1

    # if stop: 
    #     return facility_MEG_records_all[i]
    # else:
    #     return gbc.GB_NOT_FOUND

###

def get_IS_facility_MEG_name(facility_MEG_rec = dict):
    return facility_MEG_rec[ismvf.IS_FACIL_MEG_NAME]

def set_IS_facility_MEG_name(facility_MEG_rec = dict, value = str):
    facility_MEG_rec[ismvf.IS_FACIL_MEG_NAME] = value

###

def get_IS_facility_MEG_string_constant(facility_MEG_rec = dict):
    return facility_MEG_rec[ismvf.IS_FACIL_MEG_STR_CONST]

def set_IS_facility_MEG_string_constant(facility_MEG_rec = dict, value = str):
    facility_MEG_rec[ismvf.IS_FACIL_MEG_STR_CONST] = value

###

def get_IS_facility_MEG_ID(facility_MEG_rec = dict):
    return facility_MEG_rec[ismvf.IS_FACIL_MEG_ID]

def set_IS_facility_MEG_ID(facility_MEG_rec = dict, value = str):
    facility_MEG_rec[ismvf.IS_FACIL_MEG_ID] = value

###

def get_IS_facility_MEG_facility_type_ID(facility_MEG_rec = dict):
    return facility_MEG_rec[ismvf.IS_FACIL_MEG_FACIL_TYPE_ID]

def set_IS_facility_MEG_facility_type_ID(facility_MEG_rec = dict, value = str):
    facility_MEG_rec[ismvf.IS_FACIL_MEG_FACIL_TYPE_ID] = value

###

def add_IS_facility_MEG_rec(facility_MEG_records_all = list, value = dict):
    facility_MEG_records_all.append(value)

def remove_IS_facility_MEG_rec(facility_MEG_records_all, facility_type_ID, ID):
    facility_MEG_recs = [facility_MEG_rec for facility_MEG_rec in facility_MEG_records_all \
        if not ((facility_MEG_rec[ismvf.IS_FACIL_MEG_FACIL_TYPE_ID] == facility_type_ID) and (facility_MEG_rec[ismvf.IS_FACIL_MEG_ID] == ID))]
    return facility_MEG_recs

    # i = 0
    # stop = False
    # num_groups = len(facility_MEG_records_all)

    # while (i < num_groups) and (not stop):
    #     facility_MEG_rec = facility_MEG_records_all[i]

    #     facility_type_ID_i = get_IS_facility_MEG_facility_type_ID(facility_MEG_rec)
    #     ID_i = get_IS_facility_MEG_ID(facility_MEG_rec)

    #     if (facility_type_ID_i == facility_type_ID) and (ID_i == ID):
    #         del facility_MEG_records_all[i]
    #         stop = True
        
    #     i = i + 1

# Removes all facility MEGs corresponding to a particular facility type
def remove_IS_facility_MEG_records(facility_MEG_records_all = list, facility_type_ID = str):
    # Reduce list to contain only groups for the specified facility.
    facility_MEG_records = [facility_MEG_rec for facility_MEG_rec in facility_MEG_records_all \
        if facility_MEG_rec[ismvf.IS_FACIL_MEG_FACIL_TYPE_ID] != facility_type_ID]
    return facility_MEG_records

#######################################################################################################
#                                                                                                     #
#                                 Facility equipment                                                  #
#                                                                                                     #
#######################################################################################################

# Returns all facility equipment records for a particular facility type
def get_IS_facility_equip_records(facility_equip_records_all = list, facility_type_ID = str):
    # Reduce list to contain only groups for the specified facility.
    facility_equip_records_for_facility = [facility_equip_rec for facility_equip_rec in facility_equip_records_all
        if facility_equip_rec[ismvf.IS_FACIL_EQUIP_FACIL_TYPE_ID] == facility_type_ID]
    return facility_equip_records_for_facility

###

def get_IS_facility_equip_rec(facility_equip_records_all = list, facility_type_ID = str, facility_MEG_ID = str, facility_equip_ID = str):
    facility_equip_recs = [facility_equip_rec for facility_equip_rec in facility_equip_records_all 
        if ((facility_equip_rec[ismvf.IS_FACIL_EQUIP_FACIL_TYPE_ID] == facility_type_ID) 
        and (facility_equip_rec[ismvf.IS_FACIL_EQUIP_MEG_ID] == facility_MEG_ID)
        and (facility_equip_rec[ismvf.IS_FACIL_EQUIP_ID] == facility_equip_ID))]
    return facility_equip_recs[0] if len(facility_equip_recs) > 0 else gbc.GB_NOT_FOUND

    # num_facility_equip = len(facility_equip_records_all)

    # stop = False
    # i = 0
    # while (i < num_facility_equip) and (not stop):
    #     facility_equip_rec = facility_equip_records_all[i]
        
    #     facility_type_ID_i = get_IS_facility_equip_facility_type_ID(facility_equip_rec)
    #     facility_equip_ID_i = get_IS_facility_equip_ID(facility_equip_rec)

    #     if (facility_type_ID_i == facility_type_ID) and (facility_equip_ID_i == facility_equip_ID):
    #         stop = True
    #     else:
    #         i = i + 1

    # if stop: 
    #     return facility_equip_records_all[i]
    # else:
    #     return gbc.GB_NOT_FOUND

###

def get_IS_facility_equip_idx(facility_equip_records_all = list, facility_type_ID = str, facility_MEG_ID = str, facility_equip_ID = str):
    indices = [idx for (idx, facility_equip_rec) in enumerate(facility_equip_records_all) if (
        (facility_equip_rec[ismvf.IS_FACIL_EQUIP_FACIL_TYPE_ID] == facility_type_ID) 
        and (facility_equip_rec[ismvf.IS_FACIL_EQUIP_ID] == facility_equip_ID)
        and (facility_equip_rec[ismvf.IS_FACIL_EQUIP_MEG_ID] == facility_MEG_ID))
    ]
    return indices[0] if len(indices) > 0 else gbc.GB_NOT_FOUND

    # idx = gbc.GB_NOT_FOUND
    
    # i = 0
    # stop = False
    # num_facility_equip = len(facility_equip_records_all)

    # while (i < num_facility_equip) and (not stop):
    #     facility_equip_rec = facility_equip_records_all[i]

    #     facility_type_ID_i = get_IS_facility_equip_facility_type_ID(facility_equip_rec)
    #     facility_equip_ID_i = get_IS_facility_equip_ID(facility_equip_rec)

    #     if (facility_type_ID_i == facility_type_ID) and (facility_equip_ID_i == facility_equip_ID):
    #         idx = i
    #         stop = True

    #     i += 1

    # return idx

###

def get_IS_facility_equip_name(facility_equip_rec = dict):
    return facility_equip_rec[ismvf.IS_FACIL_EQUIP_NAME]

def set_IS_facility_equip_name(facility_equip_rec = dict, value = str):
    facility_equip_rec[ismvf.IS_FACIL_EQUIP_NAME] = value

###

def get_IS_facility_equip_string_constant(facility_equip_rec = dict):
    return facility_equip_rec[ismvf.IS_FACIL_EQUIP_STR_CONST]

def set_IS_facility_equip_string_constant(facility_equip_rec = dict, value = str):
    facility_equip_rec[ismvf.IS_FACIL_EQUIP_STR_CONST] = value

###

def get_IS_facility_equip_ID(facility_equip_rec = dict):
    return facility_equip_rec[ismvf.IS_FACIL_EQUIP_ID]

def set_IS_facility_equip_ID(facility_equip_rec = dict, value = str):
    facility_equip_rec[ismvf.IS_FACIL_EQUIP_ID] = value

###

def get_IS_facility_equip_custom(facility_equip_rec = dict):
    return facility_equip_rec[ismvf.IS_FACIL_EQUIP_CUSTOM]

def set_IS_facility_equip_custom(facility_equip_rec = dict, value = str):
    facility_equip_rec[ismvf.IS_FACIL_EQUIP_CUSTOM] = value

###

def get_IS_facility_equip_facility_type_ID(facility_equip_rec = dict):
    return facility_equip_rec[ismvf.IS_FACIL_EQUIP_FACIL_TYPE_ID]

def set_IS_facility_equip_facility_type_ID(facility_equip_rec = dict, value = str):
    facility_equip_rec[ismvf.IS_FACIL_EQUIP_FACIL_TYPE_ID] = value

###

def get_IS_facility_equip_unit_cost(facility_equip_rec = dict):
    return facility_equip_rec[ismvf.IS_FACIL_EQUIP_UNIT_COST]

def set_IS_facility_equip_unit_cost(facility_equip_rec = dict, value = float):
    facility_equip_rec[ismvf.IS_FACIL_EQUIP_UNIT_COST] = value

###

def get_IS_facility_equip_maint_cost(facility_equip_rec = dict):
    return facility_equip_rec[ismvf.IS_FACIL_EQUIP_MAINT_COST]

def set_IS_facility_equip_maint_cost(facility_equip_rec = dict, value = float):
    facility_equip_rec[ismvf.IS_FACIL_EQUIP_MAINT_COST] = value

###

def get_IS_facility_equip_calib_cost(facility_equip_rec = dict):
    return facility_equip_rec[ismvf.IS_FACIL_EQUIP_CALIB_COST]

def set_IS_facility_equip_calib_cost(facility_equip_rec = dict, value = float):
    facility_equip_rec[ismvf.IS_FACIL_EQUIP_CALIB_COST] = value

###

def get_IS_facility_equip_units_per_facility(facility_equip_rec = dict):
    return facility_equip_rec[ismvf.IS_FACIL_EQUIP_NUM_UNITS]

def set_IS_facility_equip_units_per_facility(facility_equip_rec = dict, value = float):
    facility_equip_rec[ismvf.IS_FACIL_EQUIP_NUM_UNITS] = value

###

def get_IS_facility_equip_working_life(facility_equip_rec = dict):
    return facility_equip_rec[ismvf.IS_FACIL_EQUIP_WORKING_LIFE]

def set_IS_facility_equip_working_life(facility_equip_rec = dict, value = float):
    facility_equip_rec[ismvf.IS_FACIL_EQUIP_WORKING_LIFE] = value

###

# Medical equipment only (furniture does not have groups)
def get_IS_facility_med_equip_MEG_mst_ID(facility_equip_rec = dict):
    return facility_equip_rec[ismvf.IS_FACIL_EQUIP_MEG_ID]

def set_IS_facility_med_equip_MEG_mst_ID(facility_equip_rec = dict, value = str):
    facility_equip_rec[ismvf.IS_FACIL_EQUIP_MEG_ID] = value

###

# Removes all facility equipment corresponding to a particular facility type
def remove_IS_facility_equip_records(facility_equip_records_all = list, facility_type_ID = str):
    # Reduce list to contain only equipment for the specified facility.
    facility_equip_records = [facility_equip_rec for facility_equip_rec in facility_equip_records_all
        if (facility_equip_rec[ismvf.IS_FACIL_EQUIP_FACIL_TYPE_ID] != facility_type_ID)]
    return facility_equip_records

# Removes all facility equipment corresponding to a particular facility type
def remove_IS_facility_equip_records_for_MEG(facility_equip_records_all = list, facility_type_ID = str, facility_MEG = str):
    # Reduce list to contain only equipment for the specified facility.
    facility_equip_records = [facility_equip_rec for facility_equip_rec in facility_equip_records_all              
        if not ((facility_equip_rec[ismvf.IS_FACIL_EQUIP_FACIL_TYPE_ID] == facility_type_ID)
        and (facility_equip_rec[ismvf.IS_FACIL_EQUIP_MEG_ID] == facility_MEG))]

    return facility_equip_records

#######################################################################################################
#                                                                                                     #
#                                        Results                                                      #
#                                                                                                     #
#######################################################################################################

def get_IS_total_num_facilities_available(mv_value, ft = int, t = int):
    return mv_value[ft - 1, t]