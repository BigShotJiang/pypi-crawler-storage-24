from os import environ

from AvenirCommon.Database import GB_get_db_json

import SpectrumCommon.Const.GB.GBConst as gbc

import SpectrumCommon.Const.IS.ISConst as isc
import SpectrumCommon.Const.IS.ISDatabaseKeys as isdbk
import SpectrumCommon.Modvars.IS.ISModVarUtil as ismvu
import SpectrumCommon.Modvars.IS.ISModVarDefs as ismvd
import SpectrumCommon.Const.IS.ISConstLink as iscl
import SpectrumCommon.Const.IS.ISModVarFields as ismvf

#######################################################################################################
#                                                                                                     #
#                                       Database loading methods                                      #
#                                                                                                     #
#######################################################################################################

def IS_load_facility_med_equip_group_DB():
    facility_med_equip_group_DB_file_name = isc.IS_FACILITY_MED_EQUIP_GROUP_DB_NAME + '_' + isc.IS_FACILITY_EQUIP_DB_CURR_VERSION + '.' + gbc.GB_JSON
    facility_med_equip_group_DB = GB_get_db_json(environ[gbc.GB_SPECT_MOD_DATA_CONN_ENV], gbc.GB_IS_CONTAINER, facility_med_equip_group_DB_file_name)

    return facility_med_equip_group_DB

def IS_load_facility_equip_input_DB():
    facility_equip_input_DB_file_name = isc.IS_FACILITY_EQUIP_DB_NAME + '_' + isc.IS_FACILITY_EQUIP_DB_CURR_VERSION + '.' + gbc.GB_JSON
    facility_equip_input_DB = GB_get_db_json(environ[gbc.GB_SPECT_MOD_DATA_CONN_ENV], gbc.GB_IS_CONTAINER, facility_equip_input_DB_file_name)

    return facility_equip_input_DB

#######################################################################################################
#                                                                                                     #
#                               Facility medical equipment group (MEG) records                        #
#                                                                                                     #
#######################################################################################################

def IS_init_facility_MEG_records(facility_med_equip_group_DB, TB_costing_on):
    facility_MEG_records = []

    for facility_med_equip_group_DB_obj in facility_med_equip_group_DB:
        group_mst_ID = facility_med_equip_group_DB_obj[isdbk.IS_GROUP_MST_ID_KEY_FEIDB]
    
        # Medical equipment groups are only initialized for the default medical equipment group ID.
        if (
            (TB_costing_on and (facility_med_equip_group_DB_obj[isdbk.IS_MOD_ID_KEY_FEIDB] == gbc.GB_TB))
            or ((not TB_costing_on) and (facility_med_equip_group_DB_obj[isdbk.IS_MOD_ID_KEY_FEIDB] != gbc.GB_TB))
            and group_mst_ID == isc.IS_DEF_MED_EQUIP_GROUP_ID
        ):
            facility_type_mst_ID = facility_med_equip_group_DB_obj[isdbk.IS_FACILITY_TYPE_MST_ID_KEY_FEIDB]
            group_name = facility_med_equip_group_DB_obj[isdbk.IS_GROUP_NAME_ID_KEY_FEIDB]
            group_string_constant = facility_med_equip_group_DB_obj[isdbk.IS_GROUP_STR_CONST_KEY_FEIDB]
            facility_MEG_record = ismvd.IS_create_facility_MEG_record(group_mst_ID, group_name, facility_type_mst_ID)
            ismvu.set_IS_facility_MEG_string_constant(facility_MEG_record, group_string_constant)
            ismvu.add_IS_facility_MEG_rec(facility_MEG_records, facility_MEG_record)

    # Normally, default groups are determined by looping over the equipment database and finding all the groups used for the various equipment. 
    # As a result, if we want empty groups, we manually add them here.
    if TB_costing_on:
        # Add a blank medical equipment group for Prehospital emergency.
        facility_type_mst_ID = str(isc.IS_PREHOSPITAL_EMERGENCY_MST_ID)
        group_mst_ID = '1'
        group_name = 'TB equipment'
        group_string_constant = 'GB_stTBEquipment'
        facility_MEG_record = ismvd.IS_create_facility_MEG_record(group_mst_ID, group_name, facility_type_mst_ID)
        ismvu.set_IS_facility_MEG_string_constant(facility_MEG_record, group_string_constant)
        ismvu.add_IS_facility_MEG_rec(facility_MEG_records, facility_MEG_record)

    return facility_MEG_records

#######################################################################################################
#                                                                                                     #
#                                       Facility equipment records                                    #
#                                                                                                     #
#######################################################################################################

# 
def IS_init_facility_equip_records(facility_equip_input_DB, costing_mode, IHT_plan_type, facility_type_ID : str = str(gbc.GB_NOT_FOUND)):

    facility_med_equip_dict_list, facility_furniture_dict_list = [], []

    for facility_equip_input_DB_obj in facility_equip_input_DB:
        facility_MEG_mst_ID = facility_equip_input_DB_obj[isdbk.IS_GROUP_MST_ID_KEY_FEIDB]
        equip_type_mst_ID = facility_equip_input_DB_obj[isdbk.IS_FACILITY_EQUIP_TYPE_MST_ID_KEY_FEIDB]

        # Records are initialized from the equipment database according to module ID and equipment type. All furniture records for the corresponding
        # module are initialized. Medical equipment is initialized for only the default equipment group ID.
        if (((costing_mode == gbc.GB_TB_COSTING_MODE) and (facility_equip_input_DB_obj[isdbk.IS_MOD_ID_KEY_FEIDB] == gbc.GB_TB)) 
            or (((costing_mode != gbc.GB_TB_COSTING_MODE)) and (facility_equip_input_DB_obj[isdbk.IS_MOD_ID_KEY_FEIDB] != gbc.GB_TB))
            and (equip_type_mst_ID == isc.IS_FACIL_FURNITURE_EQUIP_MST_ID or facility_MEG_mst_ID == isc.IS_DEF_MED_EQUIP_GROUP_ID)):
        
            facility_type_mst_ID = facility_equip_input_DB_obj[isdbk.IS_FACILITY_TYPE_MST_ID_KEY_FEIDB]

            if (facility_type_ID == str(gbc.GB_NOT_FOUND)) or (facility_type_ID == facility_type_mst_ID): 

                equip_mst_ID = facility_equip_input_DB_obj[isdbk.IS_EQUIP_MST_ID_KEY_FEIDB]
                equip_name = facility_equip_input_DB_obj[isdbk.IS_EQUIP_NAME_MST_ID_KEY_FEIDB]
                equip_string_constant = facility_equip_input_DB_obj[isdbk.IS_EQUIP_STR_CONST_KEY_FEIDB]
                unit_cost = facility_equip_input_DB_obj[isdbk.IS_UNIT_COST_KEY_FEIDB]
                units_per_facility = facility_equip_input_DB_obj[isdbk.IS_UNITS_PER_FACILITY_TYPE_KEY_FEIDB]

                # Note that the equipment mstID currently isn't used in the record but still passing it in, in case the winds change direction
                facility_equip_record = ismvd.IS_create_facility_equip_record(equip_mst_ID, equip_name, facility_type_mst_ID, equip_type_mst_ID, costing_mode, IHT_plan_type)
                ismvu.set_IS_facility_equip_string_constant(facility_equip_record, equip_string_constant)

                # Only facility medical equipment has a corresponding MEG (medical equipment group).
                if equip_type_mst_ID == isc.IS_FACIL_MEDICAL_EQUIP_MST_ID:
                    ismvu.set_IS_facility_med_equip_MEG_mst_ID(facility_equip_record, facility_MEG_mst_ID)
                
                ismvu.set_IS_facility_equip_unit_cost(facility_equip_record, unit_cost)
                ismvu.set_IS_facility_equip_units_per_facility(facility_equip_record, units_per_facility)

                if equip_type_mst_ID == isc.IS_FACIL_MEDICAL_EQUIP_MST_ID:
                    facility_med_equip_dict_list.append(facility_equip_record)
                else:
                    facility_furniture_dict_list.append(facility_equip_record)

    return facility_med_equip_dict_list, facility_furniture_dict_list

#######################################################################################################
#                                                                                                     #
#                                       Meta data                                                     #
#                                                                                                     #
#######################################################################################################

def IS_init_default_MEG_list_meta(facility_MEG_DB, costing_mode, plan_type):
    default_MEG_list_meta = []

    if (costing_mode == gbc.GB_IHT_COSTING_MODE and plan_type == iscl.IH_SPECIFIC_PLAN):
        modID = iscl.GB_IS
    elif (costing_mode == gbc.GB_TB_COSTING_MODE):
        modID = iscl.GB_TB
    else:
        return []

    for facility_MEG_DB_obj in facility_MEG_DB:
        if (facility_MEG_DB_obj[isdbk.IS_MOD_ID_KEY_FEIDB] == modID):
            default_MEG_list_meta.append({
                ismvf.IS_FACIL_MEG_NAME : facility_MEG_DB_obj[isdbk.IS_GROUP_NAME_ID_KEY_FEIDB],
                ismvf.IS_FACIL_MEG_ID : facility_MEG_DB_obj[isdbk.IS_GROUP_MST_ID_KEY_FEIDB],
                ismvf.IS_FACIL_MEG_FACIL_TYPE_ID : facility_MEG_DB_obj[isdbk.IS_FACILITY_TYPE_MST_ID_KEY_FEIDB],
                ismvf.IS_FACIL_MEG_STR_CONST : facility_MEG_DB_obj[isdbk.IS_GROUP_STR_CONST_KEY_FEIDB]
            })

    return default_MEG_list_meta