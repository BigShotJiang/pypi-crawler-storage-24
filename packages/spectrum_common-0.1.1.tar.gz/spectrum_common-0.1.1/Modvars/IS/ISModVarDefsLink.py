from SpectrumCommon.Const.GB.GBConst import *

from SpectrumCommon.Modvars.PC.PCModVarDefs import *

def IS_create_prog_mgmt_data_dict(num_years = int):
    return PC_create_prog_mgmt_data_dict(GB_IS, num_years)