from pydantic import BaseModel
from typing import Any, List

'''
	TransactionRecord 

	See TRConst in Spectrum Transaction Server for a list of possible values that targets and commands can be.
	
	target: 
		String representing type of item to be modified.

	command:
		String representing type of transaction to perform.
		
	ID: 
		Master ID / key to identify item to be changed as a string.
	
	name: 
		Item name.

	SpeciaL:
		progAreaID: 
			For ProgramAreaSubgroups and Interventions targets only. Ignore otherwise.

		subgroupID:
			For Interventions only. Ignore otherwise.
                                                                
		value:
			Value to be set by transaction. The only value we do not set using this field is name.     

'''
# Base class for any transaction record
class TransactionRecord(BaseModel): 
	target     : str = ''
	command    : str = ''
	params     : Any = {} # Prefer this to value when possible. Object with all needed fields. 

	ID         : str = '' 
	name       : str = ''

	# Special
	progAreaID : str = '' # *See below
	subgroupID : str = '' # *See below
	value      : Any = ''

# *Can we make this a part of value at some point? WHY: There is more than just progAreaID and subgroupID and I'd rather not flood this
# base class with fields every time we need new ones

'''
	ModVarRecord

	module:
		Two-letter module code. Ex: DP

	modvars:
		List of ModVar tags. Ex: ['<DP_Tag1_V1>', '<DP_Tag2_V1>']
'''

class ModVarRecord(BaseModel):
	module  : str = ''
	modvars : List[str] = ['']

# Base class for any list of transactions
class Transactions(BaseModel):
	projID           : str = ''
	clientModvarList : List[ModVarRecord] = [dict(ModVarRecord())]
	transactions     : List[TransactionRecord] = [dict(TransactionRecord())]

