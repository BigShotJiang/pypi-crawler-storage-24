# import numpy as np
# from copy import deepcopy
# from AvenirCommon.Util import GBRange
from SpectrumCommon.Const.VW import *

# ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
# /////                                                                                                          /////
# /////                                                                                                          /////
# /////                                                                                                          /////
# ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

def Simple_Value_Init(value):
    return value