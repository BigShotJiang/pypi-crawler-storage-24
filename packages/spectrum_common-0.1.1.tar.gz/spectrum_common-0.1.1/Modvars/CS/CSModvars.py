from os import environ
from .CSModvarDef import *
from SpectrumCommon.Const.CS import *
from SpectrumCommon.Const.GB.GBConst import GB_IHT_Client_lc
from SpectrumCommon.Const.IV.IVConst import IV_INTERVENTION_DB_NAME, IV_CS_INTERVENTION_DB_CURR_VERSION, IV_GROUP_DB_NAME, IV_CS_GROUP_DB_CURR_VERSION
from SpectrumCommon.Util.CS.CSDataUtil import *
from AvenirCommon.Database import GB_get_db_json, GB_file_exists

def updateFname(DBName, countryID, Region):
    FName = DBName + '_' + latest_DB_Version[DBName]
    
    if DBName == RegionData: 
        FName += '/' + Region
    
    elif DBName in DBC_DB_Names: 
        FName += '/' + countryID
    
    return FName    

def downloadDatabase(connection, countryID, DBName, Region = ''):    
    FName = updateFname(DBName, countryID, Region) + '.JSON'
    
    if GB_file_exists(connection, 'list', FName):
        return GB_get_db_json(connection, 'list', FName)

def init_modvars(countryID, first_year, final_year, extra):     
    connection = environ[GB_SPECT_MOD_DATA_CONN_ENV]

    CSModvars = {}

    GSKMode = extra[GB_GSKMode]
    exploreLiST = extra['exploreLiST']
    level = extra['level']
    source = extra['source']
    appID = extra['appID']

    DBCName = DataByCountry
    if exploreLiST:
        DBCName = DBC_DataPoints
    
    latest_DB_Version[IV_INTERVENTION_DB_NAME] = IV_CS_INTERVENTION_DB_CURR_VERSION
    latest_DB_Version[IV_GROUP_DB_NAME] = IV_CS_GROUP_DB_CURR_VERSION

    Intervention_DB   = downloadDatabase(connection, countryID, IV_INTERVENTION_DB_NAME)
    DefaultData_DB    = downloadDatabase(connection, countryID, DefaultData)
    IVDefaultData_DB  = downloadDatabase(connection, countryID, IVDefaultData)
    IVGroup_DB        = downloadDatabase(connection, countryID, IV_GROUP_DB_NAME)
    GNI_Per_Cap_DB    = downloadDatabase(connection, countryID, GNI_Per_Cap)
    DataByCountry_DB  = downloadDatabase(connection, countryID, DBCName)
    Readiness_DB      = downloadDatabase(connection, countryID, Readiness)
    CSection_Cov_DB   = downloadDatabase(connection, countryID, CSection_Cov)
    DiarrShigella_DB  = downloadDatabase(connection, countryID, DiarrShigella)
    
    efficacy_choice = extra.get('EfficacyDatabase', CS_DefaultJHUFlag)

    # if IHT client and no efficacy database specified, default to WHO
    if (appID == GB_IHT_Client_lc) and ('EfficacyDatabase' not in extra):
        efficacy_choice = CS_DefaultWHOFlag

    # Download data if WHO efficacy database is selected
    if efficacy_choice == CS_DefaultWHOFlag:
        DefaultData_DB   = downloadDatabase(connection, countryID, DefaultWHOData)
        IVDefaultData_DB = downloadDatabase(connection, countryID, IVDefaultWHOData)

    
    RegionData_DB = downloadDatabase(connection, countryID, RegionData, DataByCountry_DB['Region']) 
    easyFPData = GB_get_db_json(connection, 'famplan', 'countries/' + countryID + '_V1.JSON')

    final_year_idx = final_year - first_year

    DataByCountry_DB['exploreLiST'] = exploreLiST
    DataByCountry_DB['ProjFirstYear'] = first_year
    DataByCountry_DB['ProjFinalYearIdx'] = final_year_idx

    DevMode = False
    
    IVInfo, numIntervs = IVInfo_Init(Intervention_DB, DevMode, GSKMode)
    
    isSubnatWizProj = not level == ""
    
    dataSource = source if (isSubnatWizProj) else DataByCountry_DB[TG_DataSource]
        
    CSModvars = {
        CS_DebugTag                              : [0.0],
        # Subnational Wizard
        CS_SubnatWizProjTag                      : Simple_Value_Init(isSubnatWizProj),
        CS_SubnatRegionTag                       : Simple_Value_Init(level),
        CS_FirstTimeEnteringCoverageTag          : Simple_Value_Init(True),
        CS_SubnatDefDataMstIDsetTag              : Simple_Value_Init([]),
        CS_SubnatDataSourceArrayTag              : Simple_Value_Init({}),

        CS_DataSourceTag	                     : Simple_Value_Init(dataSource),
        
        # Meta data
        CS_IDMapTag                              : IDMap_init(),
        CS_FinalIndicesTag                       : FinalIndices_init(),
        
        # Intervention info
        CS_NumIntervsTag                         : Simple_Value_Init(numIntervs),
        CS_IVInfoTag                             : IVInfo,
        CS_IVGroupInfoTag                        : IVGroupInfo_Init(IVGroup_DB),  
        CS_IVSubgroupInfoTag                     : IVSubgroupInfo_Init(IVGroup_DB),            
        
        # General
        CS_DevModeTag                            : Simple_Value_Init(DevMode),
        CS_FirstYearTag                          : Simple_Value_Init(first_year),
        CS_FinalYearTag                          : Simple_Value_Init(final_year),
        CS_ProjValidTag	                         : Simple_Value_Init(False),
        CS_ProjValidDateTag	                     : Simple_Value_Init('Unavailable'),
        CS_DefaultDBChoiceTag                    : Simple_Value_Init(efficacy_choice),

        # Controls
        CS_CovBYTag                              : Simple_Value_Init(0),
        CS_MenARecommendedTag                    : MenARecommended_Init(DataByCountry_DB),                         
        CS_IPTpCBCheckedTag                      : IPTpCBChecked_Init(DataByCountry_DB),                          
        CS_HaveCalculatedChDeathsByCauseTag      : Simple_Value_Init(False),                          
        CS_FirstYearAtWorkTag                    : Simple_Value_Init(CS_DefMinFirstYrAtWork),
        CS_LastYearAtWorkTag                     : Simple_Value_Init(CS_DefMaxFinalYrAtWork),
        CS_AbortCalcFamPlanTag                   : Simple_Value_Init(True),
        CS_CovEntryModeTag                       : Simple_Value_Init(CS_DirectEntryMode if (appID == GB_IHT_Client_lc) else CS_QualityMode),      
        CS_CalcCovFromInputsTag                  : Simple_Value_Init([CS_ThermalCare_CCFI, CS_InjectAntib_CCFI, CS_VitAMeasTreat_CCFI]),
        CS_EnterBFImproveDataTag                 : Simple_Value_Init(CS_MstBFPromotionMode), # 2025-09-02 All apps now start in promotion "mode". # CS_MstBFPrevMode if not extra[GB_IHT_ON] else CS_MstBFPromotionMode),
        CS_BFPromoCBsTag                         : Simple_Value_Init([False, True, False]),
        CS_StuntMatrixOnTag                      : Simple_Value_Init(False),
        CS_WasteMatrixOnTag                      : Simple_Value_Init(False),
        CS_UseDetailedStuntMatrixTag             : Simple_Value_Init(True),
        CS_UseDetailedWasteMatrixTag             : Simple_Value_Init(True),
        CS_FertilityRisksMatrixOnTag             : Simple_Value_Init(False),
        CS_DirectEntryFITag                      : Simple_Value_Init(False),
        CS_SelectedIVSetTag                      : Simple_Value_Init([]),

        # Health status
        CS_NutrDeficTag                          : NutrDefic_Init(DataByCountry_DB),
        CS_VitADefInPWTag                        : VitADefInPW_Init(DataByCountry_DB),
        CS_StatusAtBirthTag                      : StatusAtBirth_Init(DataByCountry_DB),
        CS_DiarrIncTag                           : Incidence_Init(DataByCountry_DB, TG_IncDiarrhea),
        CS_SevereDiarrIncTag                     : Incidence_Init(DataByCountry_DB, TG_IncSevereDiarrhea),
        CS_PneumIncTag                           : Incidence_Init(DataByCountry_DB, TG_IncPneum),
        CS_MeninIncTag                           : Incidence_Init(DataByCountry_DB, TG_IncMening),
        CS_MaternalAnemiaTag                     : MaternalAnemia_Init(DataByCountry_DB),
        CS_PercWom15t49LowBMITag                 : PercWom15t49LowBMI_Init(DataByCountry_DB),
        CS_SyphilisAmongWRATag                   : SyphilisAmongWRA_Init(DataByCountry_DB),
        CS_PercExposedFalciparumTag              : PercExposedFalciparum_Init(DataByCountry_DB),
        CS_PercWomenWithPrevPreEclampTag         : PercWomenWithPrevPreEclamp_Init(DataByCountry_DB),
        CS_PercWomenWithChronicHypertensionTag   : PercWomenWithChronicHypertension_Init(DataByCountry_DB),
        CS_FolicAcidDeficPrevTag                 : FolicAcidDeficPrev_Init(DataByCountry_DB),
        CS_CongenitalDueToNTDsAFTag              : CongenitalDueToNTDsAF_Init(DataByCountry_DB),
        CS_StuntDistrTag                         : StuntWasteDistr_Init(DataByCountry_DB, TG_StuntingDist),
        CS_WasteDistrTag                         : StuntWasteDistr_Init(DataByCountry_DB, TG_WastingDist),
        CS_SingleStuntDistrTag                   : SingleStuntWasteDistr_Init(final_year_idx),
        CS_SingleWasteDistrTag                   : SingleStuntWasteDistr_Init(final_year_idx),
        CS_DiarrPathTag	                         : DiarrPath_Init(DataByCountry_DB),
        CS_PneumPathTag                          : PneumPath_Init(DataByCountry_DB),
        CS_MeninPathTag	                         : MeninPath_Init(DataByCountry_DB),
        CS_BaselineMortTag                       : BaselineMort_Init(DataByCountry_DB, exploreLiST, final_year_idx),
        CS_PercDthByCauseTag	                 : PercDthByCause_Init(DataByCountry_DB, exploreLiST, final_year_idx),
        CS_AdolMortRatioTag                      : AdolMortRatio_Init(DataByCountry_DB, exploreLiST, final_year_idx),
        CS_PercAdolDeathsByCauseTag	             : PercAdolDeathsByCause_Init(DataByCountry_DB, exploreLiST, final_year_idx),
        CS_MatMortRatioTag                       : MatMortRatio_Init(DataByCountry_DB, exploreLiST, final_year_idx),
        CS_PercMatDthByCauseTag                  : PercMatDthByCause_Init(DataByCountry_DB, exploreLiST, final_year_idx),
        CS_PercPregEndAbortTag                   : PercPregEndAbort_Init(DataByCountry_DB),
        CS_AbortIncRatioTag                      : AbortIncRatio_Init(DataByCountry_DB),
        CS_SBRateTag                             : SBRate_Init(DataByCountry_DB, exploreLiST, final_year_idx),
        CS_SBCausesTag                           : SBCauses_Init(DataByCountry_DB, exploreLiST, final_year_idx),
        CS_PerCapitaIncTag                       : PerCapitaInc_Init(DataByCountry_DB),
        CS_FoodInsecureTag                       : FoodInsecure_Init(DataByCountry_DB),
        CS_AvgHouseholdSizeTag	                 : AvgHouseholdSize_Init(DataByCountry_DB),
        CS_IncludeCostForBCRTag                  : IncludeCostForBCR_Init(),
        CS_IncludeBenefitForBCRTag               : IncludeBenefitForBCR_Init(),
        CS_BaselineGDPTag                        : BaselineGDP_Init(DataByCountry_DB),
        CS_AnnualPercGrowthRateTag	             : AnnualPercGrowthRate_Init(DataByCountry_DB, GNI_Per_Cap_DB, final_year_idx),
        CS_LaborForceParRateTag	                 : LaborForceParRate_Init(DataByCountry_DB, final_year_idx),
        CS_FemaleLaborForceParRateTag	         : FemaleLaborForceParRate_Init(DataByCountry_DB, final_year_idx),
        CS_PercGDPAllocWageTag	                 : PercGDPAllocWage_Init(DataByCountry_DB, final_year_idx),
        CS_DiscountRatesTag                      : DiscountRates_Init(),
        CS_FactorsTag                            : Factors_Init(),

        # Coverage
        CS_CoverageTag                           : Coverage_Init(IVInfo, numIntervs, DataByCountry_DB, Readiness_DB, CSection_Cov_DB),
        CS_BFPrevTag                             : BFPrev_Init(DataByCountry_DB),
        CS_EarlyInitBFPrevTag                    : EarlyInitBFPrev_Init(DataByCountry_DB),
        CS_RoutDetVaccCovTag                     : RoutDetVaccCov_Init(IVInfo, DataByCountry_DB),
        CS_PentaDetVaccCovTag                    : PentaDetVaccCov_Init(final_year_idx),
        CS_VaccineSuppPercTag                    : VaccineSuppPerc_Init(final_year_idx),
        CS_AgeAndBirthOrderMatrixTag	         : AgeAndBirthOrderMatrix_Init(final_year_idx, easyFPData),
        CS_BirthIntervalsMatrixTag               : BirthIntervalsMatrix_Init(final_year_idx, easyFPData),

        # Maternal, Stillbirth, and Child Efficacy
        CS_MatEffTag                             : MatEff_Init(IVInfo, numIntervs, IVDefaultData_DB, DataByCountry_DB),
        CS_SBEffTag                              : SBEff_Init(IVInfo, numIntervs, IVDefaultData_DB, DataByCountry_DB),
        CS_ChildEffTag                           : ChildEff_Init(IVInfo, numIntervs, DefaultData_DB, DataByCountry_DB),
        CS_DetVaccEffTag                         : DetVaccEff_Init(IVInfo, DefaultData_DB, DataByCountry_DB),

        # Effectiveness of interventions on incidence
        CS_DiarrIncReductionTag                  : DiarrIncReduction_Init(DefaultData_DB, DataByCountry_DB),
        CS_SevDiarrIncReductionTag               : SevDiarrIncReduction_Init(DataByCountry_DB),
        CS_PneumIncReductionTag                  : PneumIncReduction_Init(DefaultData_DB, DataByCountry_DB),
        CS_MeninIncReductionTag                  : MeninIncReduction_Init(DefaultData_DB, DataByCountry_DB),
        CS_RelRisksDiarrTag                      : RelRisks_Init(DefaultData_DB, TG_RelRiskDiarrBF),
        CS_RelRisksPneumTag          	         : RelRisks_Init(DefaultData_DB, TG_RelRiskPneumBF),
        CS_RelRisksMeninTag	                     : RelRisks_Init(DefaultData_DB, TG_RelRiskMeninBF),

        # Herd effectiveness of vaccines
        CS_HerdVaccEffTag                        : HerdVaccEff_Init(DataByCountry_DB),

        # Impact on food security
        CS_ImpOnFoodSecurityTag                  : ImpOnFoodSecurity_Init(),

        # Effectiveness of nutrition interventions
        CS_AgeAndBirthOrderTag                   : AgeAndBirthOrder_Init(DefaultData_DB),
        CS_BirthIntervalsTag	                 : BirthIntervals_Init(DefaultData_DB),
        CS_IntervForBOTag                        : IntervForBO_Init(DefaultData_DB, DataByCountry_DB),
        CS_ImpactOnStuntTag                      : ImpactOnStunt_Init(DefaultData_DB),
        CS_ImpactOnWasteTag                      : ImpactOnWaste_Init(DefaultData_DB),
        CS_ImpactOnMatAnemiaTag  	             : ImpactOnMatAnemia_Init(DefaultData_DB),
        CS_ImpactBFPromoTag                      : ImpactBFPromo_Init(DefaultData_DB),
        CS_KMConBFTag                            : KMConBF_Init(DefaultData_DB),
        CS_LBWFTag                               : LBWF_Init(DataByCountry_DB),
        CS_ReducStuntTag                         : ReducStunt_Init(DefaultData_DB),
        CS_EducAttainTag                         : EducAttain_Init(DefaultData_DB, DataByCountry_DB),

        # Impact of under-nutrition on mortality
        CS_RelRisksStuntTag                      : RelRisksStuntWast_Init(DefaultData_DB, DataByCountry_DB, TG_RelRiskStunting),
        CS_RelRisksWasteTag                      : RelRisksStuntWast_Init(DefaultData_DB, DataByCountry_DB, TG_RelRiskWasting),
        CS_RelRisksIUGR_LBWTag	                 : RelRisksIUGR_LBW_Init(DataByCountry_DB),
        CS_ImpactBFOnMortNeoNatTag               : ImpactBFOnMortNeoNat_Init(DefaultData_DB),
        CS_ImpactBFOnMortPostNatTag              : ImpactBFOnMortPostNat_Init(DefaultData_DB),
        CS_RelRisksAnemiaTag                     : RelRisksAnemia_Init(DefaultData_DB, DataByCountry_DB),

        # ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        # /////                                                                                                          /////
        # /////                                         Result Modvars                                                   /////
        # /////                                                                                                          /////
        # ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        CS_PercDeathsAvtdSeqPTag                 : CauseByAgeByYear_Init(final_year_idx),
        CS_MortalityRatesTag                     : MortalityRates_Init(final_year_idx),
        CS_DistPathDiarIncResultTag              : DiarrPathsByAgeByYear_Init(final_year_idx),
        
        # Neonatal, child sectors
        CS_ChDeathsTag                           : AgeByYear_Init(final_year_idx),
        CS_ChDeathsByYearTag                     : ChDeathsByYear_Init(final_year_idx),
        CS_ChDeathsPrevdTag                      : AgeByYear_Init(final_year_idx),
        CS_ChDeathsByCauseTag                    : CauseByAgeByYear_Init(final_year_idx),
        CS_DeathsByCauseByBirthCohortTag         : DeathsByCauseByBirthCohort_Init(final_year_idx),
        CS_ChDeathsPrevdByCauseTag               : CauseByAgeByYear_Init(final_year_idx),
        CS_ChDeathsPrevdByIntTag                 : IntervsByAgeByYear_Init(numIntervs, final_year_idx),
        CS_ChDeathsPrevByInterByCauseTag         : ChDeathsPrevByInterByCause_Init(numIntervs, final_year_idx),
        CS_DetVaccCovResultsTag                  : DetVaccCovResults_Init(final_year_idx),
        CS_DAvtdByVaccByCohortTag                : DAvtdByVaccByCohort_Init(final_year_idx),
        CS_DAvtdByVaccByCohortByCauseTag	     : DAvtdByVaccByCohortByCause_Init(final_year_idx),

        # Maternal sector
        CS_MatDeathsTag                          : Year_Init(final_year_idx),
        CS_MatDeathsPrevTag                      : Year_Init(final_year_idx),
        CS_MatDeathsByCauseTag                   : MatDeathCausesByYear_Init(final_year_idx),
        CS_MatDeathsPrevByCauseTag               : MatDeathCausesByYear_Init(final_year_idx),
        CS_MatDeathsPrevByInterTag               : IntervsByYear_Init(numIntervs, final_year_idx),
        CS_MatDeathsPrevByInterByCauseTag	     : MatDeathsPrevByInterByCause_Init(numIntervs, final_year_idx),
        CS_NumAbortionsTag	                     : NumAbortions_Init(final_year_idx),

        # Stillbirth sector
        CS_SBResultsTag                          : Year_Init(final_year_idx),
        CS_SBPrevResultsTag                      : Year_Init(final_year_idx),
        CS_SBByCauseResultsTag                   : SBCausesByYear_Init(final_year_idx),
        CS_SBPrevByCauseResultsTag               : SBCausesByYear_Init(final_year_idx),
        CS_SBPrevByInterResultsTag               : IntervsByYear_Init(numIntervs, final_year_idx),
        CS_SBPrevByInterByCauseTag               : SBPrevByInterByCause_Init(numIntervs, final_year_idx),

        # Mortality rates sector
        CS_SBRateResultTag                       : Year_Init(final_year_idx),
        CS_MatMortRatioResultTag                 : Year_Init(final_year_idx),
        CS_MatMortRateResultTag                  : Year_Init(final_year_idx),
        CS_MortalityRateResultTag                : MortalityRateResult_Init(final_year_idx),
        CS_RedMortIntervResultTag                : RedMortIntervResult_Init(numIntervs),
        CS_RedMortIntervSortedIDsTag             : RedMortIntervSortedIDs_Init(numIntervs),

        # Nutrition sector
        CS_ShutDownBOAttriByIVTag                : Simple_Value_Init(False),
        CS_SubOpBOAvertByInterTag	             : SubOpBOAvertByInter_Init(numIntervs, final_year_idx),
        CS_MAM_PINTag                            : MAM_PIN_Init(),
        CS_SAM_PINTag                            : AgeByYear_Init(final_year_idx),
        CS_PInVarHtForAgeStuntTag	             : StdDevByAgeByYear_Init(final_year_idx),
        CS_PInVarWtForHtWasteTag                 : StdDevByAgeByYear_Init(final_year_idx),
        CS_PInVarWtForHtWasteCFTag               : StdDevByAgeByYear_Init(final_year_idx),
        CS_NumStuntedTag                         : AgeByYear_Init(final_year_idx),
        CS_NumStuntedAvertedTag	                 : AgeByYear_Init(final_year_idx),
        CS_NumStuntedAvertedByInterTag	         : IntervsByAgeByYear_Init(numIntervs, final_year_idx),
        CS_PStuntRedAccountByIntBaseYrTag        : IntervsByAgeByYear_Init(numIntervs, final_year_idx),
        CS_AdditionalYrsSchoolingGainedTag	     : Year_Init(final_year_idx),
        CS_PercIncEarnStuntDeclineTag	         : Year_Init(final_year_idx),
        CS_ImpLifeEarnDueToStuntReducTag         : DiscountRate_Init(final_year_idx),
        CS_LifetimeEarningsObtainedTag	         : DiscountRate_Init(final_year_idx),
        CS_BFPrevResultTag                       : BFPrevResult_Init(final_year_idx),
        CS_BirthTermResultTag	                 : BirthTermResult_Init(final_year_idx),
        CS_PercAnemicWomenTag                    : AnemiaByYear_Init(final_year_idx),
        CS_NumAnemicWomenTag                     : AnemiaByYear_Init(final_year_idx),
        CS_NumAnemiaCasesPrevTag                 : AnemiaByYear_Init(final_year_idx),
        CS_PrevFoodInsecurityTag                 : Year_Init(final_year_idx),

        # Incidence and etiology sector
        CS_DiarrIncResultTag                     : AgeByYear_Init(final_year_idx),
        CS_SevereDiarrIncResultTag               : AgeByYear_Init(final_year_idx),
        CS_PneumIncResultTag                     : AgeByYear_Init(final_year_idx),
        CS_MeninIncResultTag	                 : AgeByYear_Init(final_year_idx),
        CS_NumDiarrCasesTag                      : AgeByYear_Init(final_year_idx),
        CS_NumSevereDiarrCasesTag                : AgeByYear_Init(final_year_idx),
        CS_NumPneumCasesTag                      : AgeByYear_Init(final_year_idx),
        CS_NumMeninCasesTag                      : AgeByYear_Init(final_year_idx),
        CS_DiarrCasesAvertByInterTag             : DiarrCasesAvertByInter_Init(final_year_idx),
        CS_SevereDiarrCasesAvertByInterTag       : DiarrIntervsByAgeByYear_Init(final_year_idx),
        CS_PneumCasesAvertByInterTag             : PneumCasesAvertByInter_Init(final_year_idx),
        CS_MeninCasesAvertByInterTag             : MeninCasesAvertByInter_Init(final_year_idx),
        CS_PercDiarrDeathsByPathTag	             : DiarrPathsByAgeByYear_Init(final_year_idx),
        CS_PercPneumDeathsByPathTag              : PneumPathsByAgeByYear_Init(final_year_idx),
        CS_PercMeninDeathsByPathTag              : MeninPathsByAgeByYear_Init(final_year_idx),
        CS_DiarrDeathsByPathTag                  : DiarrPathsByAgeByYear_Init(final_year_idx),
        CS_PneumDeathsByPathTag                  : PneumPathsByAgeByYear_Init(final_year_idx),
        CS_MeninDeathsByPathTag                  : MeninPathsByAgeByYear_Init(final_year_idx),
        CS_DiarrDeathsByPathBy1yrAgeGrpsTag      : DiarrPathsBy1YrAgeGrpsByYear_Init(final_year_idx),
        CS_PneumDeathsByPathBy1yrAgeGrpsTag      : PneumPathsBy1YrAgeGrpsByYear_Init(final_year_idx),
        CS_MeninDeathsByPathBy1yrAgeGrpsTag      : MeninPathsBy1YrAgeGrpsByYear_Init(final_year_idx),
        CS_PercDiarrCasesByPathTag	             : DiarrPathsByAgeByYear_Init(final_year_idx),
        CS_PercSevDiarrCasesByPathTag	         : DiarrPathsByAgeByYear_Init(final_year_idx),
        CS_PercPneumCasesByPathTag               : PneumPathsByAgeByYear_Init(final_year_idx),
        CS_PercMeninCasesByPathTag               : MeninPathsByAgeByYear_Init(final_year_idx),
        CS_DiarrCasesByPathTag                   : DiarrPathsByAgeByYear_Init(final_year_idx),
        CS_SevereDiarrCasesByPathTag             : DiarrPathsByAgeByYear_Init(final_year_idx),
        CS_PneumCasesByPathTag                   : PneumPathsByAgeByYear_Init(final_year_idx),
        CS_MeninCasesByPathTag                   : MeninPathsByAgeByYear_Init(final_year_idx),
        CS_DiarrCasesByPathBy1YrAgeGrpsTag       : DiarrPathsBy1YrAgeGrpsByYear_Init(final_year_idx),
        CS_SevereDiarrCasesByPathBy1YrAgeGrpsTag : DiarrPathsBy1YrAgeGrpsByYear_Init(final_year_idx),
        CS_PneumCasesByPathBy1YrAgeGrpsTag       : PneumPathsBy1YrAgeGrpsByYear_Init(final_year_idx),
        CS_MeninCasesByPathBy1YrAgeGrpsTag       : MeninPathsBy1YrAgeGrpsByYear_Init(final_year_idx),
        CS_DiarrCasesByBirthCohTag               : Year_Init(final_year_idx),
        CS_PneumCasesByBirthCohTag               : Year_Init(final_year_idx),
        CS_MeninCasesByBirthCohTag               : Year_Init(final_year_idx),
        CS_SevDiarrCasesByBirthCohTag            : Year_Init(final_year_idx),
        CS_DiarCasesAvtdByYr1stDoseVaccTag       : DetVaccByAgeByYear_Init(final_year_idx),
        CS_PneumCasesAvtdByYr1stDoseVaccTag      : DetVaccByAgeByYear_Init(final_year_idx),
        CS_MeninCasesAvtdByYr1stDoseVaccTag      : DetVaccByAgeByYear_Init(final_year_idx),
        CS_SevDiarrCasesAvtdByYr1stDoseVaccTag   : DetVaccByAgeByYear_Init(final_year_idx),
        CS_DiarrDeathsByPathBirthCohTag          : DiarrPathsByYear_Init(final_year_idx),
        CS_PneumDeathsByPathBirthCohTag          : PneumPathsByYear_Init(final_year_idx),
        CS_MeninDeathsByPathBirthCohTag          : MeninPathsByYear_Init(final_year_idx),
        CS_DiarrCasesByPathBirthCohTag           : DiarrPathsByYear_Init(final_year_idx),
        CS_PneumCasesByPathBirthCohTag           : PneumPathsByYear_Init(final_year_idx),
        CS_MeninCasesByPathBirthCohTag           : MeninPathsByYear_Init(final_year_idx),
        CS_SevDiarrCasesByPathBirthCohTag        : DiarrPathsByYear_Init(final_year_idx),
        CS_DiarrDeathsByPathBirthCohVCTag        : DiarrPathsByYear_Init(final_year_idx),
        CS_PneumDeathsByPathBirthCohVCTag        : PneumPathsByYear_Init(final_year_idx),
        CS_MeninDeathsByPathBirthCohVCTag        : MeninPathsByYear_Init(final_year_idx),
        CS_DiarrCasesByPathBirthCohVCTag         : DiarrPathsByYear_Init(final_year_idx),
        CS_PneumCasesByPathBirthCohVCTag         : PneumPathsByYear_Init(final_year_idx),
        CS_MeninCasesByPathBirthCohVCTag         : MeninPathsByYear_Init(final_year_idx),
        CS_PersonsVaccByIntervTag                : PersonsVaccByInterv_Init(final_year_idx),
        CS_PersonsVaccByIntervBy1YrAgeGrpsTag    : DetVaccByDoseBy1YrAgeGrpsByYear_Init(final_year_idx),

        CS_DiscountedCostsTag                    : Year_Init(final_year_idx),
        CS_DiscountedSocialBenefitsTag           : Year_Init(final_year_idx),
        CS_DiscountedEconBenefitsTag             : Year_Init(final_year_idx),
        CS_IncLifetimeEarningsDueToStuntTag      : Year_Init(final_year_idx),
        
        CS_TotalDiscountedCostsTag               : Simple_Value_Init(0),
        CS_TotalDiscountedSocialBenefitsTag      : Simple_Value_Init(0),
        CS_TotalDiscountedEconBenefitsTag        : Simple_Value_Init(0),
        CS_LifetimeEarningsIncTag                : Simple_Value_Init(0),
        CS_BCRTag                                : Simple_Value_Init(0),
    }

    if GSKMode:
        SetDiarrShigellaDistr(CSModvars, DiarrShigella_DB)
    
    if not exploreLiST:
        SetRegionalValues(CSModvars, RegionData_DB, final_year_idx)
    
    if CSModvars[CS_SubnatWizProjTag]["value"]:
        dataSource = dataSource.split(" ")
        source = dataSource[0]
        surveyYear = dataSource[1]
        SubnatData_DB = downloadDatabase(connection, countryID, SubnatData)[level][surveyYear][source]
        SubnatCov_Init(CSModvars, SubnatData_DB, final_year_idx)

    ModifyCoverage(CSModvars, final_year_idx)    
    ModifyEffectivenessFromHealthStatus(CSModvars)

    Meta_MV_Init(CSModvars)

    return CSModvars