from SpectrumCommon.Modvars.CS.CSModvarShapes import CS_modvar_shapes
from SpectrumCommon.Modvars.GB.GBDefs import gb_update_years, gb_reshape_years
from SpectrumCommon.Const.CS import *
from SpectrumCommon.Const.PJ import *

def CS_UpdateYears(projection, new_projection, params):

    
    gb_update_years(projection, params, CS_modvar_shapes)

    for tag in [CS_AnnualPercGrowthRateTag, CS_LaborForceParRateTag, CS_FemaleLaborForceParRateTag, CS_PercGDPAllocWageTag]:
        projection[tag] = CS_Update_work_years(tag, projection, params)

    pass

def CS_Update_work_years(tag, projection, params):
    modvar = gb_reshape_years(projection[tag], 
                              {'dim':['year']}, 
                              projection[PJN_FirstYearTag], 
                              projection[PJN_FinalYearTag]+CS_MaxFinalYrAtWork,
                              params.firstYear, 
                              params.finalYear+CS_MaxFinalYrAtWork)
    return modvar

