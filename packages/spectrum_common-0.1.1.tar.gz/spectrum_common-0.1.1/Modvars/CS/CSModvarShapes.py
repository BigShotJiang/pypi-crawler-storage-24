# fmt: off
from SpectrumCommon.Const.CS import *
from  SpectrumCommon.Const.CS import *
from SpectrumCommon.Modvars.GB.GBDefs import *

cs_bounds_dim = 'cs_bounds'
cs_bounds_indices = {
    CS_bAuto   : 'Auto',
    #  User results
    CS_bUser   : 'bUser',
    #  Estimate Bounds
    CS_bMin    : 'Min',
    CS_bMax    : 'Max',
    #  CSUA
    CS_bLow    : 'Low',
    CS_bMed    : 'Med',
    CS_bHigh   : 'High',
}
cs_age_dim = 'cs_age'
cs_age_indices = {
    CS_Birth       : 'Birth',
    CS_0t1months   : '0 to 1 months',
    CS_1t6months   : '1 to 6 months',
    CS_6t12months  : '6 to 12 months',
    CS_12t24months : '12 to 24 months',
    CS_24t60months : '24 to 60 months'
}


cs_work_year_dim = 'cs_work_year'
cs_work_year_indices = {'firstYear':0, 'finalYear':-1}

cs_costs_dim = 'cs_costs'
cs_costs_indices = {
    CS_Benefits : 'Benefits',
    CS_Costs    : 'Costs',
}

cs_factors_dim = 'cs_factors'
cs_factors_indices = {
    CS_SocialValue : 'Social value',
    CS_PercStillbirthsIncluded : 'Percentage of stillbirths included',
}

cs_cost_types_dim = 'cs_cost_types'
cs_cost_types_indices = {
    CS_InterventionCosts : 'Intervention costs',
    CS_ProgramCosts : 'Program costs',
    CS_LogisticsAndWastage : 'Logistics and wastage',
    CS_InfrastructureInvest : 'Infrastructure investment',
    CS_OtherHealthSysCosts : 'Other health system costs',
}

cs_benefit_types_dim = 'cs_benefit_types'
cs_benefit_types_indices = {
    CS_SocBenSB :   'Social benefit for stillbirths',
    CS_SocBenChild : 'Social benefit for child deaths',
    CS_SocBenMat :  'Social benefit for maternal deaths',
    CS_EarnSB :   'Economic benefit for stillbirths',
    CS_EarnChild :  'Economic benefit for child deaths',
    CS_EarnMat : 'Economic benefit for maternal deaths',
    CS_StuntReducAddEarn : 'Stunting reduction additional earnings',
}

cs_gdp_dim = 'cs_gdp'
cs_gdp_indices = {
    CS_PerCapita : 'Per capita GDP',
    CS_PerWorker : 'Per worker GDP',
}

cs_nutrition_dim = 'cs_nutrition'
cs_nutrition_indices = {
    CS_VitADefic   : 'Vitamin A deficiency',
    CS_ZincDefic   : 'Zinc deficiency',
    CS_CalcDefic   : 'Calcium deficiency',
    CS_FolDefic    : 'Folate deficiency',
    CS_IronDefic   : 'Iron deficiency',
    CS_VitB6Defic  : 'Vitamin B6 deficiency',
    CS_VitB12Defic : 'Vitamin B12 deficiency',
    CS_VitCDefic   : 'Vitamin C deficiency',
    CS_CoppDefic   : 'Copper deficiency',
    CS_MagDefic    : 'Magnesium deficiency',
    CS_NiaDefic    : 'Niacin deficiency',
    CS_PhosDefic   : 'Phosphorus deficiency',
    CS_RiboDefic   : 'Riboflavin deficiency',
    CS_ThiaDefic   : 'Thiamine deficiency',
}
    


cs_cause_dim= 'cs_cause'
cs_cause_indices = {
    CS_NNDiarr           : 'NNDiarr',
    CS_FirstNNDeath      : 'FirstNNDeath',
    CS_NNSepsis          : 'NNSepsis',
    CS_NNPneumonia       : 'NNPneumonia',
    CS_NNAsphyxia        : 'NNAsphyxia',
    CS_NNPreterm         : 'NNPreterm',
    CS_NNTetanus         : 'NNTetanus',
    CS_NNCongen          : 'NNCongen',
    CS_NNOther           : 'NNOther',
    CS_FinalStdNNDeath   : 'FinalStdNNDeath',
    CS_CustomNNCOD1      : 'CustomNNCOD1',
    CS_FirstCustNNDeath  : 'FirstCustNNDeath ',
    CS_CustomNNCOD2      : 'CustomNNCOD2',
    CS_CustomNNCOD3      : 'CustomNNCOD3',
    CS_CustomNNCOD4      : 'CustomNNCOD4',
    CS_FinalCustNNDeath  : 'FinalCustNNDeath',
    CS_FinalNNDeath      : 'FinalNNDeath',
    CS_Diarrhea          : 'Diarrhea',
    CS_FirstPNNDeath     : 'FirstPNNDeath',
    CS_Pneumonia         : 'Pneumonia',
    CS_Meningitis        : 'Meningitis',
    CS_Measles           : 'Measles',
    CS_Malaria           : 'Malaria',
    CS_Pertussis         : 'Pertussis',
    CS_AIDS              : 'AIDS',
    CS_Injury            : 'Injury',
    CS_OtherInfecDis     : 'OtherInfecDis',
    CS_OtherNCD          : 'OtherNCD',
    CS_FinalStdPNNDeath  : 'FinalStdPNNDeath',
    CS_MaxDefDeathCauses : 'MaxDefDeathCauses',
    CS_CustomPNNCOD1     : 'CustomPNNCOD1',
    CS_FirstCustPNNDeath : 'FirstCustPNNDeath',
    CS_CustomPNNCOD2     : 'CustomPNNCOD2',
    CS_CustomPNNCOD3     : 'CustomPNNCOD3',
    CS_CustomPNNCOD4     : 'CustomPNNCOD4',
}

cs_perc_covered_dim = 'cs_perc_covered'
cs_perc_covered_indices = {
    CS_0PercCov   : '0%',
    CS_5PercCov   : '5%',
    CS_10PercCov  : '10%',
    CS_15PercCov  : '15%',
    CS_20PercCov  : '20%',
    CS_25PercCov  : '25%',
    CS_30PercCov  : '30%',
    CS_35PercCov  : '35%',
    CS_40PercCov  : '40%',
    CS_45PercCov  : '45%',
    CS_50PercCov  : '50%',
    CS_55PercCov  : '55%',
    CS_60PercCov  : '60%',
    CS_65PercCov  : '65%',
    CS_70PercCov  : '70%',
    CS_75PercCov  : '75%',
    CS_80PercCov  : '80%',
    CS_85PercCov  : '85%',
    CS_90PercCov  : '90%',
    CS_95PercCov  : '95%',
    CS_100PercCov : '100%',
}
    
cs_mort_dim = 'cs_mort'
cs_mort_indices = {
    CS_NeonatalMR : 'Neonatal mortality rate',
    CS_InfantMR   : 'Infant mortality rate',
    CS_U5MR       : 'Under-5 mortality rate'
}
cs_diarr_path_dim = 'cs_diarr_path'
cs_diarr_path_indices = {
    CS_RotaPathDiar   : 'RotaPathDiar',
    CS_PathBDiar      : 'Path B Diarrea',
    CS_PathCDiar      : 'Path C Diarrea',
    CS_OtherPathsDiar : 'Other Paths Diarrea',
}
cs_fatality_dim = 'cs_fatality'
cs_fatality_indices = {
    CS_Distr_All   : 'Distribution All',
    CS_Distr_Sevr  : 'Distribution Severe',
    CS_Distr_Fatal : 'Distribution Fatal',
}

cs_mortality_age_dim = 'cs_mortality_age'
cs_mortality_age_indices = {
    
    CS_NeonatalMR : 'Neonatal MR',
    CS_InfantMR   : 'Infant MR',
    CS_U5MR       : 'Under-5 MR',
}
cs_death_cause_dim = 'cs_death_cause'
cs_death_cause_indices = {
    CS_DxC_Default    : 'Default',
    CS_DxC_Normalized : 'Normalized',
    CS_DxC_NoAIDS     : 'No AIDS',
}

cs_adol_age_dim = 'cs_adol_age'
cs_adol_age_indices = {
    CS_5yrs_9yrs   : '5  to 9 years',
    CS_10yrs_14yrs : '10 to 14 years',
    CS_15yrs_19yrs : '15 to 19 years',
}
cs_adol_causes_dim = 'cs_adol_causes'
cs_adol_causes_indices = {
    CS_Adol_HIV            : 'Adolecsent HIV',
    CS_Adol_Diarrhoeal     : 'Adolescent Diarrhoeal',
    CS_Adol_Measles        : 'Adolescent Measles',
    CS_Adol_Malaria        : 'Adolescent Malaria',
    CS_Adol_LRI            : 'Adolescent LRI',
    CS_Adol_TB             : 'Adolescent TB',
    CS_Adol_Maternal       : 'Adolescent Maternal',
    CS_Adol_OtherCMPN      : 'Adolescent Other CMPN',
    CS_Adol_Congenital     : 'Adolescent Congenital',
    CS_Adol_Neoplasm       : 'Adolescent Neoplasm',
    CS_Adol_Cardiovascular : 'Adolescent Cardiovascular',
    CS_Adol_Digestive      : 'Adolescent Digestive',
    CS_Adol_OtherNCD       : 'Adolescent Other NCD',
    CS_Adol_RTI            : 'Adolescent RTI',
    CS_Adol_Drowning       : 'Adolescent Drowning',
    CS_Adol_NatDis         : 'Adolescent NatDis',
    CS_Adol_InterpVio      : 'Adolescent Interpersonal Violence',
    CS_Adol_CollectVio     : 'Adolescent Collective Violence',
    CS_Adol_SelfHarm       : 'Adolescent Self Harm',
    CS_Adol_OtherInj       : 'Adolescent Other Injury',
}


cs_4t5Yr_dim = 'cs_4t5Yr'
cs_4t5Yr_indices = {
    CS_0t1Yr : '0  to 1 year',
    CS_1t2Yr : '1  to 2 years', 
    CS_2t3Yr : '2  to 3 years',
    CS_3t4Yr : '3  to 4 years', 
    CS_4t5Yr : '4  to 5 years'
}

cs_interv_dim = 'cs_interv'
cs_interv_indices = {}

cs_last_vacc_dim = 'cs_last_vacc'
cs_last_vacc_indices = {
    CS_BCG_Det         : 'BCG Det vaccine',
    CS_Polio_Det       : 'Polio Det vaccine',
    CS_DPT_Det         : 'DPT Det vaccine',
    CS_HiB_Det         : 'HiB Det vaccine',
    CS_HepB_Det        : 'HepB Det vaccine',
    CS_PCV_Det         : 'PCV Det vaccine',
    CS_Rota_Det        : 'Rota Det vaccine',
    CS_MenA_Det        : 'MenA Det vaccine',
    CS_Malaria_Det     : 'Malaria Det vaccine',
    CS_Meas_Det        : 'Meas Det vaccine',
    CS_VaccB_Det       : 'VaccB Det vaccine',
    CS_VaccC_Det       : 'VaccC Det vaccine',
    CS_VaccD_Det       : 'VaccD Det vaccine',
    CS_VaccE_Det       : 'VaccE Det vaccine',
    CS_VaccF_Det       : 'VaccF Det vaccine',
}

cs_vacc_dose_dim = 'cs_vacc_dose'
cs_vacc_dose_indices = {
    
    CS_VaccDoseZero   : 'Dose 0',
    CS_VaccDoseOne    : 'Dose 1',
    CS_VaccDoseTwo    : 'Dose 2',
    CS_VaccDoseThree  : 'Dose 3',
    CS_VaccBooster    : 'Dose booster',
}

cs_retro_years_dim = 'cs_retro_years'
cs_retro_years_indices = {}

cs_mat_death_dim = 'cs_max_death'
cs_mat_death_indices = {
    CS_Mat_AntepartHemorr    : 'Maternal AntepartHemorr',
    CS_Mat_MinDeathCauses    : 'Maternal MinDeathCauses',
    CS_Mat_IntrapartHemorr   : 'Maternal IntrapartHemorr',
    CS_Mat_PostpartHemorr    : 'Maternal PostpartHemorr',
    CS_Mat_HypertensiveDis   : 'Maternal HypertensiveDis',
    CS_Mat_Sepsis            : 'Maternal Sepsis',
    CS_Mat_Abortion          : 'Maternal Abortion',
    CS_Mat_Embolism          : 'Maternal Embolism',
    CS_Mat_OtherDirectCauses : 'Maternal OtherDirectCauses',
    CS_Mat_IndirectCauses    : 'Maternal IndirectCauses',
}

cs_abort_dim = 'cs_abort'
cs_abort_indices = {
    CS_TotalAbort  : 'Total abortions',
    CS_UnsafeAbort : 'Unsafe abortions',
    CS_SafeAbort   : 'Safe abortions',
}
cs_sbcauses_dim = 'cs_sbcauses'
cs_sbcauses_indices = {
    CS_SB_Antepartum  : 'Antepartum stillbirth',
    CS_SB_Intrapartum : 'Intrapartum stillbirth',
}

cs_perc_U5_mort_dim = 'cs_perc_U5_mort'
cs_perc_U5_mort_indices = {}

cs_std_dim = 'cs_std'
cs_std_indices = {
    CS_GT1STD : 'GT1STD',
    CS_1t2STD : '1t2STD',
    CS_2t3STD : '2t3STD',
    CS_GT3STD : 'GT3STD',
}
cs_discount_dim = 'cs_discount'
cs_discount_indices = {
    CS_3Perc  : '3%',
    CS_5Perc  : '5%',
    CS_10Perc : '10%',
}

cs_bf_type_dim= 'cs_bf_type'
cs_bf_type_indices = {
    CS_ExclusiveBF    : 'Exclusively breastfed',
    CS_PredominantBF  : 'Predominantly breastfed',
    CS_PartialBF      : 'Partially breastfed',
    CS_NotBF          : 'Not breastfed',
}

cs_latebf_dim = 'cs_latebf'
cs_latebf_indices = {
    CS_EarlyInitBF : 'Early initiation of breastfeeding',
    CS_LateInitBF  : 'Late initiation of breastfeeding',
}


cs_birth_term_dim = 'cs_birth_term'
cs_birth_term_indices = {
    CS_PreTermSGA  : 'Preterm SGA',
    CS_PreTermAGA  : 'Preterm AGA',
    CS_TermSGA     : 'Term SGA',
    CS_TermAGA     : 'Term AGA',
}

cs_birth_order_dim = 'cs_birth_order'
cs_birth_order_indices = {
    CS_FirstBirth         : 'First birth',
    CS_SecAndThirdBirths  : 'Second and third births',
    CS_GTThirdBirth       : 'Greater than third birth',
}

cs_mothers_age_dim = 'cs_mothers_age'
cs_mothers_age_indices = {
    CS_AllYrs       : 'All years',
    CS_LT18Yrs      : 'Less than 18 years',
    CS_18_34Yrs     : '18 to 34 years',
    CS_35_49Yrs     : '35 to 49 years',
}

    
CS_Efficacy                 = 1
CS_OddsRatio                = 1
CS_RelRisk                  = 1
CS_AffecFract               = 2
CS_AdjustedRR               = 3

    
cs_birth_interval_dim = 'cs_birth_interval'
cs_birth_interval_indices = {
    CS_FirstBirth         : 'First birth',
    CS_LT18Mths   : 'Less than 18 months',
    CS_18to23Mths : '18 to 23 months',
    CS_GE24Mths   : '24 months or greater',
}

cs_anemia_dim = 'cs_anemia'
cs_anemia_indices = {
    CS_Preg_Anemia              : 'Pregnant anemia',
    CS_NonPreg_Anemia           : 'Non-pregnant anemia',
    CS_Preg_IronDeficAnemia     : 'Pregnant iron deficiency anemia',
    CS_NonPreg_IronDeficAnemia  : 'Non-pregnant iron deficiency anemia',
}

cs_mat_anemia_dim = 'cs_mat_anemia'
cs_mat_anemia_indices = {
    CS_Mat_NotAnemic : 'Not anemic',
    CS_Mat_Anemic    : 'Anemic',
}

cs_bfpromotion_dim = 'cs_bfpromotion'
cs_bfpromotion_indices = {
    CS_BasicSanitation_DiarInterv         : 'Basic sanitation',
    CS_PointOfUseFilteredWater_DiarInterv : 'Point of use filtered water',
    CS_PipedWater_DiarInterv              : 'Piped water',
    CS_HandWashWSoap_DiarInterv           : 'Hand wash with soap',
    CS_HygDisposalStools_DiarInterv       : 'Hygienic disposal of stools',
    CS_ZincP_DiarInterv                   : 'Zinc supplementation',
    CS_VitAPTwoDoses_DiarInterv           : 'Vitamin A (two doses)',
    CS_RotavirusVacc_DiarInterv           : 'Rotavirus vaccine',
    CS_DiarVaccPathB_DiarInterv           : 'Diarrhea vaccine Path B',
    CS_DiarVaccPathC_DiarInterv           : 'Diarrhea vaccine Path C',
    CS_BFPromotion_DiarInterv             : 'BF promotion',
}
cs_server_diarr_dim = 'cs_server_diarr'
cs_server_diarr_indices = {
    CS_RotavirusVacc_SevDiarInterv  : 'Rotavirus vaccine',
}
cs_pnuem_dim = 'cs_pnuem'
cs_pnuem_indices = {
    CS_HibVacc_PneumInterv   : 'HIB vaccine',
    CS_PneumVacc_PneumInterv : 'Pneumococcal vaccine',
    CS_ZincP_PneumInterv     : 'Zinc supplementation',
}

cs_menin_dim = 'cs_menin'
cs_menin_indices = {
    CS_HibVacc_MeningInterv   : 'HIB vaccine',
    CS_PneumVacc_MeningInterv : 'Pneumococcal vaccine',
    CS_MeningA_MeningInterv   : 'Meningitis A vaccine',
}
cs_pnuem_path_dim= 'cs_pnuem_path'
cs_pnuem_path_indices = {
    CS_HibPathPneumVT     : 'Hib Path Pneum VT',
    CS_PneumocPathPneum   : 'Pneumoc Path Pneum',
    CS_PneumocPathPneumVT : 'Pneumoc Path Pneum VT',
    CS_OtherPathsPneum    : 'Other Paths Pneum',
}
cs_menin_path_dim= 'cs_menin_path'
cs_menin_path_indices = {
    CS_HibPathMeninVT       : 'Hib Path Menin VT',
    CS_PneumocPathMenin     : 'Pneumoc Path Menin',
    CS_PneumocPathMeninVT   : 'Pneumoc Path Menin VT',
    CS_MeningitPathMenin    : 'Meningit Path Menin',
    CS_MeningitAPathMeninVT : 'Meningit A Path Menin VT',
    CS_OtherPathsMenin      : 'Other Paths Menin',
}

cs_data_dim = 'cs_data'
cs_data_indices = {
    
    CS_Default : 'Defaults',
    CS_Data    : 'Editable user data',
}
cs_affect_fract_dim = 'cs_affect_fract'
cs_affect_fract_indices = {
    CS_RelRisk     : 'Relative risk or odds ratio or efficacy',
    CS_AffecFract  : 'Affected fraction',
    CS_AdjustedRR  : 'Adjusted relative risk',
} 
cs_birth_outcomes_dim = 'cs_birth_outcomes'
cs_birth_outcomes_indices = {
    
    CS_IPTp               : 'Intermittent preventive treatment in pregnancy',
    CS_FirstIntervForBO   : 'First intervention for birth outcomes',
    CS_BalEnergy          : 'Balanced energy',
    CS_MultMicroLowBMI    : 'Multimicronutrient supplementation for low BMI',
    CS_MultMicroNormBMI   : 'Multimicronutrient supplementation for normal BMI',
    CS_CalciumSupp        : 'Calcium supplementation',
    CS_FolicAcidFort      : 'Folic acid fortification',
    CS_ZincFort           : 'Zinc fortification',
    CS_SyphilisTreat      : 'Syphilis treatment',
    CS_IronFolateSupp     : 'Iron and folate supplementation',
    CS_ZincSuppInPreg     : 'Zinc supplementation in pregnancy',
    CS_TreatOfBacteriuria : 'Treatment of bacteriuria',
    CS_Omeg3FASupp        : 'Omega-3 fatty acid supplementation',
    CS_AspirinLowDose     : 'Low-dose aspirin',
    CS_Progesterone       : 'Progesterone',
    CS_StopSmokingEduc    : 'Stop smoking education',
    CS_SpareBOInterv1     : 'Spare birth outcomes intervention 1',
    CS_SpareBOInterv2     : 'Spare birth outcomes intervention 2',
    CS_SpareBOInterv3     : 'Spare birth outcomes intervention 3',
    CS_SpareBOInterv4     : 'Spare birth outcomes intervention 4',
    CS_FoodInsecBES       : 'Food insecurity basic education and support',
    CS_ITN                : 'Insecticide-treated nets',
    CS_FirstBOMax         : 'First birth outcome maximum',
    CS_AgeAndBirthOrder   : 'Age and birth order',
    CS_BirthInterval      : 'Birth interval',
}

cs_stunting_dim = 'cs_stunting'
cs_stunting_indices = {
    CS_LowBirthWeight_TermAGA    : 'Low birth weight term AGA',
    CS_LowBirthWeight_TermSGA    : 'Low birth weight term SGA',
    CS_LowBirthWeight_PreTermAGA : 'Low birth weight preterm AGA',
    CS_LowBirthWeight_PreTermSGA : 'Low birth weight preterm SGA',
    CS_NotStuntedPrevAge         : 'Not stunted previous age',
    CS_StuntedPrevAge            : 'Stunted previous age',
    CS_FoodSecureWPromo          : 'Food secure with promotion',
    CS_FoodSecureWOPromo         : 'Food secure without promotion',
    CS_InsecureWPromoSupp        : 'Insecure with promotion and supplementation',
    CS_InsecureWOPromoSupp       : 'Insecure without promotion and supplementation',
    CS_ImpDiarrPerEpisode        : 'Impact of diarrhea per episode', 
    CS_ZincSupp                  : 'Zinc supplementation',
    CS_NotZincSupp               : 'Not zinc supplementation',
    CS_ImpactsOnStuntingFinal    : 'Impacts on stunting final',
}

cs_wasting_dim = 'cs_wasting'
cs_wasting_indices = {
    CS_ImpactsOnWaste_FractionChildrenMovModWastWithTreat : 'Fraction of children moving from moderate to severe wasting with treatment',
    CS_ImpactsOnWaste_FractionChildrenMovSevWastWithTreat : 'Fraction of children moving from severe wasting to moderate wasting with treatment',
}

cs_preg_dim = 'cs_preg'
cs_preg_indices = {
    CS_Preg    : 'Pregnant',
    CS_NonPreg : 'Not pregnant',
}

cs_impacts_mat_anemia_dim = 'cs_impacts_mat_anemia'
cs_impacts_mat_anemia_indices = {
    CS_IronFolatePW_MatAnemia : 'Iron and folate supplementation in pregnancy',
    CS_MMicroSuppPW_MatAnemia : 'Multimicronutrient supplementation in pregnancy',
    CS_IronFortNPW_MatAnemia  : 'Iron fortification in non-pregnant in pregnancy',
    CS_IPTP_MatAnemia         : 'Intermittent preventive treatment in pregnancy',
    CS_ITN_MatAnemia          : 'Insecticide-treated nets in pregnancy',
}

cs_impacts_bf_dim = 'cs_impacts_bf'
cs_impacts_bf_indices = {
    CS_ImpactPromoBF      : 'Impact on breast feeding promo',
    CS_ImpactPromoEarlyBF : 'Early impact on breast feeding promo',
}

cs_bf_promo_dim = 'cs_bf_promo'
cs_bf_promo_indices = {
    CS_BFPromoHealthSystem : 'Health system',
    CS_BFPromoHomeComm     : 'Home and community',
    CS_BFPromoBoth         : 'Both',
}   

cs_final_interv_for_fi_for_calcs_dim = 'cs_final_interv_for_fi_for_calcs'
cs_final_interv_for_fi_for_calcs_indices = {
    CS_ConditionalCashTransfer  : 'Conditional cash transfer',
    CS_FoodAssistanceToFamilies : 'Food assistance to families',
    CS_DirectSupport            : 'Direct support',
    CS_FoodShock                : 'Food shock',
}

# Originally created all these wrappers because
# the cs modvars appeared to have multiple fields in the code.
# However, it seems all the extra fields are moved to meta modvars 
# at the end of CSModvars in Meta_MV_Init

def cs_bool_shape(d):
    return  gb_bool_shape(d)

def cs_int_shape(d):
    return  gb_int_shape(d)

def cs_float_shape(d):
    return  gb_float_shape(d)

def cs_str_shape(d):
    return gb_str_shape(d)

def cs_year_shape(d):
    return gb_shape(d, '2D float', dim=[cs_bounds_dim, gb_year_dim], indices=[cs_bounds_indices, gb_year_indices])

def cs_age_year_shape(d):
    return gb_shape(d, '3D float', dim=[cs_bounds_dim, cs_age_dim, gb_year_dim], indices=[cs_bounds_indices, cs_age_indices, gb_year_indices])

def cs_cause_age_year_shape(d):
    return gb_shape(d, '4D float', dim=[cs_bounds_dim, cs_cause_dim, cs_age_dim, gb_year_dim], indices=[cs_bounds_indices, cs_cause_indices, cs_age_indices, gb_year_indices])

def cs_diarr_paths_age_year_shape(d):
    return gb_shape(d, '4D float', dim=[cs_bounds_dim, cs_diarr_path_dim, cs_age_dim, gb_year_dim], indices=[cs_bounds_indices, cs_diarr_path_indices, cs_age_indices, gb_year_indices])

def cs_diarr_paths_agegroup_year_shape(d):
    return gb_shape(d, '4D float', dim=[cs_bounds_dim, cs_diarr_path_dim, cs_4t5Yr_dim, gb_year_dim], indices=[cs_bounds_indices, cs_diarr_path_indices, cs_4t5Yr_indices, gb_year_indices])

def cs_diarr_paths_year_shape(d):
    return gb_shape(d, '3D float', dim=[cs_bounds_dim, cs_diarr_path_dim,  gb_year_dim], indices=[cs_bounds_indices, cs_diarr_path_indices, gb_year_indices])


def cs_deaths_year_shape(d):
    return gb_shape(d, '3D float', dim=[cs_bounds_dim, cs_cause_dim, gb_year_dim], indices=[cs_bounds_indices, cs_cause_indices, gb_year_indices])

def cs_interv_age_year_shape(d):
    return gb_shape(d, '4D float', dim=[cs_bounds_dim, cs_interv_dim, cs_age_dim, gb_year_dim], indices=[cs_bounds_indices, cs_interv_indices, cs_age_indices, gb_year_indices])


def cs_interv_year_shape(d):
    return gb_shape(d, '3D float', dim=[cs_bounds_dim, cs_interv_dim, gb_year_dim], indices=[cs_bounds_indices, cs_interv_indices, gb_year_indices])

def cs_interv_age_year_shape(d):
    return gb_shape(d, '4D float', dim=[cs_bounds_dim, cs_interv_dim, cs_age_dim, gb_year_dim], indices=[cs_bounds_indices, cs_interv_indices, cs_age_indices, gb_year_indices])

def cs_interv_cause_age_year_shape(d):
    return gb_shape(d, '5D float', dim=[cs_bounds_dim, cs_interv_dim, cs_cause_dim, cs_age_dim, gb_year_dim], indices=[cs_bounds_indices, cs_interv_indices, cs_cause_indices, cs_age_indices, gb_year_indices])

def cs_mat_death_causes_by_year_shape(d):
    return gb_shape(d, '3D float', dim=[cs_bounds_dim, cs_mat_death_dim, gb_year_dim], indices=[cs_bounds_indices, cs_mat_death_indices, gb_year_indices])


def cs_mat_deaths_prev_by_inter_shape(d):
    return gb_shape(d, '3D float', dim=[cs_bounds_dim, cs_interv_dim, cs_mat_death_dim, gb_year_dim], indices=[cs_bounds_indices, cs_interv_indices, cs_mat_death_indices, gb_year_indices])


def cs_num_abortions_shape(d):
    return gb_shape(d, '3D float', dim=[CS_bHigh+1, cs_abort_dim, gb_year_dim], indices=[cs_bounds_indices, cs_abort_indices, gb_year_indices])

def cs_sbcauses_year(d):
    return gb_shape(d, '3D float', dim=[cs_bounds_dim, cs_sbcauses_dim, gb_year_dim], indices=[cs_bounds_indices, cs_sbcauses_indices, gb_year_indices])

def cs_interv_sbcauses_year(d):
    return gb_shape(d, '4D float', dim=[cs_bounds_dim, cs_interv_dim, cs_sbcauses_dim, gb_year_dim], indices=[cs_bounds_indices, cs_interv_indices, cs_sbcauses_indices, gb_year_indices])

def cs_red_mort_interv_shape(d):
    return gb_shape(d, '4D float', dim=[cs_bounds_dim, cs_perc_U5_mort_dim, cs_interv_dim], indices=[cs_bounds_indices, cs_perc_U5_mort_indices, cs_interv_indices, cs_sbcauses_indices, gb_year_indices])

def cs_interv_shape(d):
    return gb_shape(d, '4D float', dim=[cs_bounds_dim, cs_interv_dim], indices=[cs_bounds_indices, cs_interv_indices, cs_sbcauses_indices, gb_year_indices])

def cs_subop_bo_avert_by_inter_shape(d):
    return gb_shape(d, '4D float', dim=[cs_bounds_dim, cs_interv_dim, cs_std_dim, gb_year_dim], indices=[cs_bounds_indices, cs_interv_indices, cs_std_indices, gb_year_indices])

def cs_age_shape(d):
    return gb_shape(d, '2D float', dim=[cs_bounds_dim, cs_age_dim], indices=[cs_bounds_indices, cs_age_indices])

def cs_std_age_shape(d):
    return gb_shape(d, '4D float', dim=[cs_bounds_dim, cs_std_dim, cs_age_dim, gb_year_dim], indices=[cs_bounds_indices, cs_std_indices, cs_age_indices, gb_year_indices])

def cs_discount_shape(d):
    return gb_shape(d, '3D float', dim=[cs_bounds_dim, cs_discount_dim, gb_year_dim], indices=[cs_bounds_indices, cs_discount_indices, gb_year_indices])


def cs_bf_prev_shape(d):
    return gb_shape(d, '4D float', dim=[cs_bounds_dim, cs_bf_type_dim, cs_age_dim, gb_year_dim], indices=[cs_bounds_indices, cs_bf_type_indices, cs_age_indices, gb_year_indices])

def cs_birth_term_shape(d):
    return gb_shape(d, '3D float', dim=[cs_bounds_dim, cs_birth_term_dim, gb_year_dim], indices=[cs_bounds_indices, cs_birth_term_indices, gb_year_indices])

def cs_anemia_by_year_shape(d):
    return gb_shape(d, '3D float', dim=[cs_bounds_dim, cs_anemia_dim, gb_year_dim], indices=[cs_bounds_indices, cs_anemia_indices, gb_year_indices])

def cs_bfpromotion_age_year_shape(d):
    return gb_shape(d, '4D float', dim=[cs_bounds_dim, cs_bfpromotion_dim, cs_age_dim, gb_year_dim], indices=[cs_bounds_indices, cs_bfpromotion_dim, cs_age_indices, gb_year_indices])

def cs_pneum_age_year_shape(d):
    return gb_shape(d, '4D float', dim=[cs_bounds_dim, cs_pnuem_dim, cs_age_dim, gb_year_dim], indices=[cs_bounds_indices, cs_pnuem_indices, cs_age_indices, gb_year_indices])

def cs_menin_age_year_shape(d):
    return gb_shape(d, '4D float', dim=[cs_bounds_dim, cs_menin_dim, cs_age_dim, gb_year_dim], indices=[cs_bounds_indices, cs_menin_indices, cs_age_indices, gb_year_indices])


def cs_pneum_path_age_year_shape(d):
    return gb_shape(d, '4D float', dim=[cs_bounds_dim, cs_pnuem_path_dim, cs_age_dim, gb_year_dim], indices=[cs_bounds_indices, cs_pnuem_path_indices, cs_age_indices, gb_year_indices])


def cs_menin_path_age_year_shape(d):
    return gb_shape(d, '4D float', dim=[cs_bounds_dim, cs_menin_path_dim, cs_age_dim, gb_year_dim], indices=[cs_bounds_indices, cs_menin_path_indices, cs_age_indices, gb_year_indices])

def cs_pneum_path_agegroup_year_shape(d):
    return gb_shape(d, '4D float', dim=[cs_bounds_dim, cs_pnuem_path_dim, cs_4t5Yr_dim, gb_year_dim], indices=[cs_bounds_indices, cs_pnuem_path_indices, cs_4t5Yr_indices, gb_year_indices])


def cs_menin_path_agegroup_year_shape(d):
    return gb_shape(d, '4D float', dim=[cs_bounds_dim, cs_menin_path_dim, cs_4t5Yr_dim, gb_year_dim], indices=[cs_bounds_indices, cs_menin_path_indices, cs_4t5Yr_indices, gb_year_indices])

def cs_pneum_path_year_shape(d):
    return gb_shape(d, '3D float', dim=[cs_bounds_dim, cs_pnuem_path_dim, gb_year_dim], indices=[cs_bounds_indices, cs_pnuem_path_indices, gb_year_indices])


def cs_menin_path_year_shape(d):
    return gb_shape(d, '3D float', dim=[cs_bounds_dim, cs_menin_path_dim, gb_year_dim], indices=[cs_bounds_indices, cs_menin_path_indices, gb_year_indices])

def cs_vacc_age_year_shape(d):
    return gb_shape(d, '4D float', dim=[cs_bounds_dim, cs_last_vacc_dim, cs_age_dim, gb_year_dim], indices=[cs_bounds_indices, cs_last_vacc_indices,  cs_age_indices, gb_year_indices])

def cs_vacc_dose_agegroup_year_shape(d):
    return gb_shape(d, '5D float', dim=[cs_bounds_dim, cs_last_vacc_dim, cs_vacc_dose_dim, cs_4t5Yr_dim, gb_year_dim], indices=[cs_bounds_indices, cs_last_vacc_indices, cs_vacc_dose_indices,  cs_4t5Yr_indices, gb_year_indices])

def cs_vacc_dose_year_shape(d):
    return gb_shape(d, '4D float', dim=[cs_bounds_dim, cs_last_vacc_dim, cs_vacc_dose_dim,  gb_year_dim], indices=[cs_bounds_indices, cs_last_vacc_indices, cs_vacc_dose_indices,  gb_year_indices])

cs_age_cohort_dim = 'cs_age_cohort'
cs_age_cohort_indices = {}
def cs_agecohort_shape(d):
    return gb_shape(d, '1D float', dim=[cs_age_cohort_dim], indices=[cs_age_cohort_indices])


CS_modvar_shapes = {
        CS_DebugTag                              : gb_shape('Debug flag', '1D float'),
        # Subnational Wizard
        CS_SubnatWizProjTag                      : cs_bool_shape('Subnational wizard flag'),
        CS_SubnatRegionTag                       : cs_str_shape('Subnational region'),
        CS_FirstTimeEnteringCoverageTag          : cs_bool_shape('First time entering coverage flag'),
        CS_SubnatDefDataMstIDsetTag              : gb_shape('Subnational default mstID set', '1D int'),
        CS_SubnatDataSourceArrayTag              : gb_shape('Subnational source array', 'dict'),

        CS_DataSourceTag	                     : cs_str_shape('Data source'),
        
        # Meta data
        CS_IDMapTag                              : gb_shape('ID map', 'dict', notes='Map of IDs'),
        CS_FinalIndicesTag                       : gb_shape('Final indices constants', 'dict', notes='Max constants for indices'),
        
        # Intervention info
        CS_NumIntervsTag                         : cs_int_shape('Number of interventions'),
        CS_IVInfoTag                             : gb_shape('Intervention information by intervention id', 'dict'),   
        CS_IVGroupInfoTag                        : gb_shape('Intervention group information by group id', 'dict'),      
        CS_IVSubgroupInfoTag                     : gb_shape('Intervention subgroup information by subgroup id', 'dict'),      
        
        # General
        CS_DevModeTag                            : cs_bool_shape('Developer mode'),  
        CS_FirstYearTag                          : cs_int_shape('First year'),   
        CS_FinalYearTag                          : cs_int_shape('Final year'),  
        CS_ProjValidTag	                         : cs_bool_shape('projection valid flag'),
        CS_ProjValidDateTag	                     : cs_str_shape('projection valid date'),

        # Controls
        CS_CovBYTag                              : gb_int_shape('Coverage by year'),
        CS_MenARecommendedTag                    : cs_bool_shape('MenARecommended'),
        CS_IPTpCBCheckedTag                      : cs_bool_shape('IPTpCBChecked'),
        CS_HaveCalculatedChDeathsByCauseTag      : cs_bool_shape('Have calculated child deaths by cause flag'),                     
        CS_FirstYearAtWorkTag                    : cs_int_shape('First year at work'),
        CS_LastYearAtWorkTag                     : cs_int_shape('Last year at work'),
        CS_AbortCalcFamPlanTag                   : cs_bool_shape('Abortions calculated for family planning flag'),  
        CS_CovEntryModeTag                       : cs_int_shape('Coverage entry mode'),      
        CS_CalcCovFromInputsTag                  : gb_shape('Calculation coverage from inputs',  '1D int'),
        CS_EnterBFImproveDataTag                 : cs_int_shape('Enter BF improvement data'),
        CS_BFPromoCBsTag                         : gb_shape('Breast feeding promo CB',  '1D bool'),
        CS_StuntMatrixOnTag                      : cs_bool_shape('Stunt matrix on'),  
        CS_WasteMatrixOnTag                      : cs_bool_shape('Waste matrix on'),  
        CS_UseDetailedStuntMatrixTag             : cs_bool_shape('Use detailed stunt matrix'),  
        CS_UseDetailedWasteMatrixTag             : cs_bool_shape('Use detailed waste matrix'),  
        CS_FertilityRisksMatrixOnTag             : cs_bool_shape('Fertility risks matrix on'),  
        CS_DirectEntryFITag                      : cs_bool_shape('Direct entry FI flag'),  
        CS_SelectedIVSetTag                      : gb_shape('Selected IV set', '1D int'),

        # Health status
        CS_NutrDeficTag                          : gb_shape('Nutritional deficiency', '1D float',
                                                            dim=[cs_nutrition_dim],
                                                            indices=[cs_nutrition_indices]),
        
        CS_VitADefInPWTag                        : cs_float_shape('Vitamin A deficiency in pregnant women'),
        CS_StatusAtBirthTag                      : gb_shape('Nutritional deficiency', '1D float',
                                                            dim=[cs_birth_term_dim],
                                                            indices=[cs_birth_term_indices]),
        CS_DiarrIncTag                           : cs_agecohort_shape('Diarrhea incidence'),
        CS_SevereDiarrIncTag                     : cs_agecohort_shape('Severe diarrhea incidence'),
        CS_PneumIncTag                           : cs_agecohort_shape('Pneumonia incidence'),
        CS_MeninIncTag                           : cs_agecohort_shape('Meningitis incidence'),
        CS_MaternalAnemiaTag                     : gb_shape('Nutritional deficiency', '1D float',
                                                            dim=[cs_mat_anemia_dim],
                                                            indices=[cs_mat_anemia_indices]),
        CS_PercWom15t49LowBMITag                 : cs_float_shape('Percentage women 15 to 49 with low BMI'),
        CS_SyphilisAmongWRATag                   : cs_float_shape('Syphilis among Women of Reproductive Age'),
        CS_PercExposedFalciparumTag              : cs_float_shape('Percentage exposed to falciparum malaria'),
        CS_PercWomenWithPrevPreEclampTag         : cs_float_shape('Percentage with previous pre-eclampsia'),
        CS_PercWomenWithChronicHypertensionTag   : cs_float_shape('Percentage with chronic hypertension'),
        CS_FolicAcidDeficPrevTag                 : cs_float_shape('Folic acid deficiency prevalence'),
        CS_CongenitalDueToNTDsAFTag              : cs_float_shape('Congenital due to NTDs Affected Fraction'),
        CS_StuntDistrTag                         : gb_shape('Wasting distribution', '3D float',
                                                            dim=[cs_std_dim, cs_age_dim, gb_year_dim],
                                                            indices=[cs_std_indices, cs_age_indices, gb_year_indices]),
        CS_WasteDistrTag                         : gb_shape('Wasting distribution', '1D float',
                                                            dim=[cs_std_dim, cs_age_dim, gb_year_dim],
                                                            indices=[cs_std_indices, cs_age_indices, gb_year_indices]),
        CS_SingleStuntDistrTag                   : gb_shape('Single stunting distribution', '1D float',
                                                            dim=[gb_year_dim],
                                                            indices=[gb_year_indices]),
        CS_SingleWasteDistrTag                   : gb_shape('Single wasting distribution', '1D float',
                                                            dim=[gb_year_dim],
                                                            indices=[gb_year_indices]),
        CS_DiarrPathTag	                         : gb_shape('Diarrhea Path', '3D float',
                                                            dim=[cs_fatality_dim, cs_diarr_path_dim, cs_age_dim],
                                                            indices=[cs_fatality_indices, cs_diarr_path_indices, cs_age_indices]),
        CS_PneumPathTag                          : gb_shape('Diarrhea Path', '3D float',
                                                            dim=[cs_fatality_dim, cs_pnuem_path_dim, cs_age_dim],
                                                            indices=[cs_fatality_indices, cs_pnuem_path_indices, cs_age_indices]),
        CS_MeninPathTag	                         : gb_shape('Diarrhea Path', '3D float',
                                                            dim=[cs_fatality_dim, cs_menin_path_dim, cs_age_dim],
                                                            indices=[cs_fatality_indices, cs_menin_path_indices, cs_age_indices]),
                                                            
        CS_BaselineMortTag                       : gb_shape('Diarrhea Path', '1D float',
                                                            dim=[cs_mortality_age_dim],
                                                            indices=[cs_mortality_age_indices]),
            
        CS_PercDthByCauseTag	                 : gb_shape('Percent death by cause', '3D float',
                                                            dim=[cs_death_cause_dim, cs_cause_dim, cs_age_dim],
                                                            indices=[cs_death_cause_indices, cs_cause_dim, cs_age_indices]),
            
        CS_AdolMortRatioTag                      : gb_shape('Adolescent mortality ratio', '2D float',
                                                            dim=[gb_sex_dim, cs_adol_age_dim],
                                                            indices=[gb_sex_indices, cs_adol_age_indices]),
        CS_PercAdolDeathsByCauseTag	             : gb_shape('Adolescent mortality ratio', '3D float',
                                                            dim=[cs_adol_causes_dim, gb_sex_dim, cs_adol_age_dim],
                                                            indices=[cs_adol_causes_indices, gb_sex_indices, cs_adol_age_indices]),
        
        CS_MatMortRatioTag                       : cs_float_shape('Maternal mortality ratio'),
        CS_PercMatDthByCauseTag                  : gb_shape('Maternal deaths by cause', '1D float',
                                                            dim = [cs_mat_death_dim],
                                                            indices = [cs_mat_death_indices]),
        CS_PercPregEndAbortTag                   : cs_float_shape('Percentage of pregnancies ending in abortion'),
        CS_AbortIncRatioTag                      : gb_shape('Abortion incidence ratio', '1D float',
                                                            dim=[gb_year_dim],
                                                            indices=[gb_year_indices]),
        CS_SBRateTag                             : cs_float_shape('Stillbirth rate'),
        CS_SBCausesTag                           : gb_shape('Still birth causes', '1D float',
                                                            dim=[cs_sbcauses_dim],
                                                            indices=[cs_sbcauses_indices]),
        CS_PerCapitaIncTag                       : gb_shape('Per capita inc', '1D float',
                                                            dim=[gb_year_dim],
                                                            indices=[gb_year_indices]),
        CS_FoodInsecureTag                       : gb_shape('Food insecurity', '1D float',
                                                            dim=[gb_year_dim],
                                                            indices=[gb_year_indices]),
        CS_AvgHouseholdSizeTag	                 : gb_shape('Average household size', '1D float',
                                                            dim=[gb_year_dim],
                                                            indices=[gb_year_indices]),
        CS_IncludeCostForBCRTag                  : gb_shape('Include costs for BCR', '1D bool',
                                                            dim=[cs_cost_types_dim],
                                                            indices=[cs_cost_types_indices]),
                                                            
        CS_IncludeBenefitForBCRTag               : gb_shape('Include costs for BCR', '1D bool',
                                                            dim=[cs_benefit_types_dim],
                                                            indices=[cs_benefit_types_indices]),
        CS_BaselineGDPTag                        : gb_shape('Include costs for BCR', '1D bool',
                                                            dim=[cs_gdp_dim],
                                                            indices=[cs_gdp_indices]),
        CS_AnnualPercGrowthRateTag	             : gb_shape('Annual percent growth rate', '1D float',
                                                            dim=[cs_work_year_dim],
                                                            indices=[cs_work_year_indices]),
        CS_LaborForceParRateTag	                 : gb_shape('Labor force par rate', '1D float',
                                                            dim=[cs_work_year_dim],
                                                            indices=[cs_work_year_indices]),
        CS_FemaleLaborForceParRateTag	         : gb_shape('Female labor force par rate', '1D float',
                                                            dim=[cs_work_year_dim],
                                                            indices=[cs_work_year_indices]),
    
        CS_PercGDPAllocWageTag	                 : gb_shape('Percent GDP alloc wage', '1D float',
                                                            dim=[cs_work_year_dim],
                                                            indices=[cs_work_year_indices]),
    
    
        CS_DiscountRatesTag                      : gb_shape('Discount rates', '1D float',
                                                            dim=[cs_costs_dim],
                                                            indices=[cs_costs_indices]),
    
        CS_FactorsTag                            : gb_shape('Factors', '1D float',
                                                            dim=[cs_factors_dim],
                                                            indices=[cs_factors_indices]),

        # Coverage
        CS_CoverageTag                           : gb_shape('Coverage', '2D float',
                                                            dim=[ cs_interv_dim, gb_year_dim],
                                                            indices=[cs_interv_indices, gb_year_indices]),
        CS_BFPrevTag                             : gb_shape('Breast feeding prevelance', '3D float',
                                                            dim=[ cs_bf_type_dim, cs_age_dim, gb_year_dim],
                                                            indices=[cs_bf_type_indices, cs_age_indices, gb_year_indices]),
        CS_EarlyInitBFPrevTag                    : gb_shape('Early breast feeding prevelance', '2D float',
                                                            dim=[ cs_age_dim, gb_year_dim],
                                                            indices=[cs_age_indices, gb_year_indices]),
        CS_RoutDetVaccCovTag                     : gb_shape('Routa vaccine coverage', '3D float',
                                                            dim=[ cs_last_vacc_dim, cs_vacc_dose_dim, gb_year_dim],
                                                            indices=[cs_last_vacc_indices, cs_vacc_dose_indices, gb_year_indices]),
        CS_PentaDetVaccCovTag                    : gb_shape('Penta vaccine coverage', '1D float',
                                                            dim=[gb_year_dim],
                                                            indices=[gb_year_indices]),
        CS_VaccineSuppPercTag                    : gb_shape('Vaccine Supp percent', '3D float',
                                                            dim=[cs_last_vacc_dim, cs_age_dim, gb_year_dim],
                                                            indices=[cs_last_vacc_indices, cs_age_indices, gb_year_indices]),
        CS_AgeAndBirthOrderMatrixTag	         : gb_shape('Age and birth order matrix', '3D float',
                                                            dim=[cs_mothers_age_dim, cs_birth_order_dim, gb_year_dim],
                                                            indices=[cs_mothers_age_indices, cs_birth_order_indices, gb_year_indices]),
        CS_BirthIntervalsMatrixTag               : gb_shape('Birth interval matrix', '2D float',
                                                            dim=[cs_birth_interval_dim, gb_year_dim],
                                                            indices=[cs_birth_interval_dim, gb_year_indices]),
        # Maternal, Stillbirth, and Child Efficacy
        CS_MatEffTag                             : gb_shape('Maternal efficacy', '4D float',
                                                            dim=[cs_data_dim, cs_affect_fract_dim, cs_interv_dim, cs_mat_death_dim],
                                                            indices=[cs_data_indices, cs_affect_fract_indices, cs_interv_indices, cs_mat_death_indices]),

        CS_SBEffTag                              : gb_shape('Still birth efficacy', '4D float',
                                                            dim=[cs_data_dim, cs_affect_fract_dim, cs_interv_dim, cs_sbcauses_dim],
                                                            indices=[cs_data_indices, cs_affect_fract_indices, cs_interv_indices, cs_sbcauses_indices]),

        CS_ChildEffTag                           : gb_shape('Still birth efficacy', '5D float',
                                                            dim=[cs_data_dim, cs_affect_fract_dim, cs_interv_dim, cs_cause_dim, cs_age_dim],
                                                            indices=[cs_data_indices, cs_affect_fract_indices, cs_interv_indices, cs_cause_indices, cs_age_indices]),

        CS_DetVaccEffTag                         : gb_shape('Still birth efficacy', '6D float',
                                                            dim=[cs_data_dim, cs_affect_fract_dim, cs_last_vacc_dim, cs_cause_dim, cs_vacc_dose_dim, cs_age_dim],
                                                            indices=[cs_data_indices, cs_affect_fract_indices, cs_last_vacc_indices, cs_cause_indices, cs_vacc_dose_indices, cs_age_indices]),


        # Effectiveness of interventions on incidence
        CS_DiarrIncReductionTag                  : gb_shape('Diarrea incidence intervention effectiveness', '4D float',
                                                            dim=[cs_data_dim, cs_bfpromotion_dim, cs_affect_fract_dim,  cs_age_dim],
                                                            indices=[cs_data_indices, cs_bfpromotion_indices ,cs_affect_fract_indices, cs_age_indices]),

        CS_SevDiarrIncReductionTag               : gb_shape('Severe diarrea incidence intervention effectiveness', '4D float',
                                                            dim=[cs_data_dim, cs_server_diarr_dim, cs_affect_fract_dim,  cs_age_dim],
                                                            indices=[cs_data_indices, cs_server_diarr_indices, cs_affect_fract_indices, cs_age_indices]),
        
        CS_PneumIncReductionTag                  : gb_shape('Pneumonia incidence intervention effectiveness', '4D float',
                                                            dim=[cs_data_dim, cs_pnuem_dim, cs_affect_fract_dim,  cs_age_dim],
                                                            indices=[cs_data_indices, cs_pnuem_dim,cs_affect_fract_indices, cs_age_indices]),
        
        CS_MeninIncReductionTag                  : gb_shape('Meningitis incidence intervention effectiveness', '4D float',
                                                            dim=[cs_data_dim, cs_menin_dim, cs_affect_fract_dim,  cs_age_dim],
                                                            indices=[cs_data_indices, cs_menin_indices, cs_affect_fract_indices, cs_age_indices]),

        
        CS_RelRisksDiarrTag                      : gb_shape('Relative risks of diarrhea', '4D float',
                                                            dim=[cs_data_dim, cs_affect_fract_dim, cs_bf_type_dim,  cs_age_dim],
                                                            indices=[cs_data_indices, cs_affect_fract_indices, cs_bf_type_indices, cs_age_indices]),

        CS_RelRisksPneumTag          	         : gb_shape('Relative risks of pneumonia', '4D float',
                                                            dim=[cs_data_dim, cs_affect_fract_dim, cs_bf_type_dim,  cs_age_dim],
                                                            indices=[cs_data_indices, cs_affect_fract_indices, cs_bf_type_indices, cs_age_indices]),
        CS_RelRisksMeninTag	                     : gb_shape('Relative risks of meningitis', '4D float',
                                                            dim=[cs_data_dim, cs_affect_fract_dim, cs_bf_type_dim,  cs_age_dim],
                                                            indices=[cs_data_indices, cs_affect_fract_indices, cs_bf_type_indices, cs_age_indices]),

        # Herd effectiveness of vaccines
        CS_HerdVaccEffTag                        : gb_shape('Herd vaccine effectiveness', '5D float',
                                                            dim=[cs_data_dim, cs_last_vacc_dim, cs_cause_dim, cs_perc_covered_dim, cs_age_dim],
                                                            indices=[cs_data_indices, cs_last_vacc_indices, cs_cause_indices, cs_perc_covered_indices, cs_age_indices]),


        # Impact on food security
        CS_ImpOnFoodSecurityTag                  :  gb_shape('Impact on food security', '3D float',
                                                                                                             dim = [cs_data_dim, cs_affect_fract_dim, cs_final_interv_for_fi_for_calcs_dim],
                                                                                                             indices = [cs_data_indices, cs_affect_fract_indices, cs_final_interv_for_fi_for_calcs_indices]),

        # Effectiveness of nutrition interventions
        CS_AgeAndBirthOrderTag                   : gb_shape('Age and birth order', '5D float',
                                                            dim=[cs_data_dim, cs_affect_fract_dim, cs_age_dim, cs_birth_order_dim,  cs_birth_term_dim],
                                                            indices=[cs_data_indices, cs_affect_fract_indices, cs_age_indices, cs_birth_order_indices, cs_birth_term_indices]),
                                                            
                                                        
        CS_BirthIntervalsTag	                 : gb_shape('Birth intervals', '4D float',
                                                            dim=[cs_data_dim, cs_affect_fract_dim, cs_birth_interval_dim, cs_birth_term_dim],
                                                            indices=[cs_data_indices, cs_affect_fract_indices, cs_birth_interval_indices, cs_birth_term_indices]),
       
        CS_IntervForBOTag                        : gb_shape('Intervention for birth order', '4D float',
                                                            dim=[cs_data_dim, cs_affect_fract_dim, cs_birth_outcomes_dim, cs_birth_term_dim],
                                                            indices=[cs_data_indices, cs_affect_fract_indices, cs_birth_outcomes_indices, cs_birth_term_indices]),

        CS_ImpactOnStuntTag                      : gb_shape('Impact on stunting', '4D float',   
                                                            dim=[cs_data_dim, cs_stunting_dim, cs_affect_fract_dim,  cs_age_dim],
                                                            indices=[cs_data_indices, cs_stunting_indices, cs_affect_fract_indices,  cs_age_indices]),
        
        CS_ImpactOnWasteTag                      : gb_shape('Impact on wasting', '4D float',   
                                                            dim=[cs_data_dim, cs_wasting_dim, cs_affect_fract_dim,  cs_age_dim],
                                                            indices=[cs_data_indices, cs_wasting_indices, cs_affect_fract_indices,  cs_age_indices]),

        
        CS_ImpactOnMatAnemiaTag  	             : gb_shape('Impact on wasting', '4D float',   
                                                            dim=[cs_data_dim, cs_preg_dim,  cs_impacts_mat_anemia_dim, cs_affect_fract_dim],
                                                            indices=[cs_data_indices, cs_preg_indices, cs_impacts_mat_anemia_indices, cs_affect_fract_indices]), 

        
        CS_ImpactBFPromoTag                      :  gb_shape('Impact on breast feeding promo', '5D float',   
                                                            dim=[cs_data_dim, cs_impacts_bf_dim, cs_bf_promo_dim, cs_affect_fract_dim,  cs_age_dim],
                                                            indices=[cs_data_indices, cs_impacts_bf_indices, cs_bf_promo_indices, cs_affect_fract_indices,  cs_age_indices]),
        # 'value'     : np.zeros((CS_Data+1, CS_ImpactPromoEarlyBF+1, CS_BFPromoBoth+1, CS_AffecFract+1, CS_24t60months+1)).tolist(),
        
        CS_KMConBFTag                            :  gb_shape('KMC on Breast feeding', '3D float',   
                                                            dim=[cs_data_dim, cs_affect_fract_dim, cs_age_dim],
                                                            indices=[cs_data_indices, cs_affect_fract_indices, cs_age_indices]),
        CS_LBWFTag                               :  gb_shape('LBWF', '3D float',   
                                                            dim=[cs_data_dim, cs_birth_term_dim],
                                                            indices=[cs_data_indices, cs_birth_term_indices]),
        CS_ReducStuntTag                         : gb_shape('reduction on stunting', '2D float',   
                                                            dim=[cs_data_dim, cs_affect_fract_dim],
                                                            indices=[cs_data_indices, cs_affect_fract_indices]),
        CS_EducAttainTag                         : gb_shape('Education attainment', '2D float',   
                                                            dim=[cs_data_dim, cs_affect_fract_dim],
                                                            indices=[cs_data_indices, cs_affect_fract_indices]),

        # Impact of under-nutrition on mortality
        CS_RelRisksStuntTag                      : gb_shape('Relative risks of stunting', '5D float',
                                                            dim=[cs_data_dim, cs_cause_dim, cs_affect_fract_dim, cs_std_dim, cs_age_dim],
                                                            indices=[cs_data_indices, cs_cause_indices, cs_affect_fract_indices, cs_std_indices, cs_age_indices]),

        CS_RelRisksWasteTag                      : gb_shape('Relative risks of wasting', '3D float',
                                                            dim=[cs_data_dim, cs_cause_dim, cs_birth_term_dim],
                                                            indices=[cs_data_indices, cs_cause_indices, cs_birth_term_indices]),
        #  np.zeros((CS_Data+1, CS_MaxDeathCauses+1, CS_TermAGA+1)).tolist(),
         
        CS_RelRisksIUGR_LBWTag	                 : gb_shape('Relative risks of IUGR and low birth weight', '5D float',
                                                            dim=[cs_data_dim, cs_cause_dim, cs_affect_fract_dim, cs_latebf_dim, cs_bf_type_dim],
                                                            indices=[cs_data_indices, cs_cause_indices, cs_affect_fract_indices, cs_latebf_indices, cs_bf_type_indices]),
        # np.zeros((CS_Data+1, CS_MaxDeathCauses+1, CS_AffecFract+1, CS_LateInitBF + 1, CS_NotBF + 1)).tolist(),
        
        CS_ImpactBFOnMortNeoNatTag               : gb_shape('Impact of breastfeeding on neonatal mortality', '5D float',
                                                            dim=[cs_data_dim, cs_cause_dim, cs_affect_fract_dim, cs_latebf_dim, cs_bf_type_dim],
                                                            indices=[cs_data_indices, cs_cause_indices, cs_affect_fract_indices, cs_latebf_indices, cs_bf_type_indices]),
        # np.zeros((CS_Data+1, CS_MaxDeathCauses+1, CS_AffecFract+1, CS_LateInitBF + 1, CS_NotBF + 1)).tolist(),
        
        CS_ImpactBFOnMortPostNatTag              : gb_shape('Impact of breastfeeding on post-neonatal mortality', '5D float',
                                                            dim=[cs_data_dim, cs_cause_dim, cs_affect_fract_dim, cs_bf_type_dim, cs_age_dim],
                                                            indices=[cs_data_indices, cs_cause_indices, cs_affect_fract_indices, cs_bf_type_indices, cs_age_indices]),

        
        CS_RelRisksAnemiaTag                     : gb_shape('Relative risks of anemia', '4D float',
                                                            dim=[cs_data_dim, cs_cause_dim, cs_mat_anemia_dim, cs_affect_fract_dim],
                                                            indices=[cs_data_indices, cs_cause_indices, cs_mat_anemia_indices, cs_affect_fract_indices]),
        #  np.zeros((CS_Data + 1, CS_Mat_MaxDeathCauses + 1, CS_Mat_Anemic + 1, CS_AffecFract + 1)).tolist(),

        # ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        # /////                                                                                                          /////
        # /////                                         Result Modvars                                                   /////
        # /////                                                                                                          /////
        # ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        CS_PercDeathsAvtdSeqPTag                 : cs_cause_age_year_shape('Percentage of deaths averted by sequence P'),
        CS_MortalityRatesTag                     : gb_shape('Mortality rates', '3D float', dim=[cs_bounds_dim, cs_mort_dim, gb_year_dim], indices=[cs_bounds_indices, cs_mort_indices, gb_year_indices]),
        CS_DistPathDiarIncResultTag              : cs_diarr_paths_age_year_shape('Distribution of diarrhea incidence results'),
        
        # Neonatal, child sectors
        CS_ChDeathsTag                           : cs_age_year_shape('Child deaths'),
        CS_ChDeathsByYearTag                     : gb_shape('Child deaths by year', '3D float', dim=[cs_bounds_dim, cs_4t5Yr_dim, gb_year_dim], indices=[cs_bounds_indices, cs_4t5Yr_indices, gb_year_indices]),

        CS_ChDeathsPrevdTag                      : cs_age_year_shape('Child deaths prevented'),
        CS_ChDeathsByCauseTag                    : cs_cause_age_year_shape('Child deaths by cause'),
        CS_DeathsByCauseByBirthCohortTag         : cs_deaths_year_shape('Deaths by cause by birth cohort'),
        CS_ChDeathsPrevdByCauseTag               : cs_cause_age_year_shape('Child deaths prevented by cause'),
        CS_ChDeathsPrevdByIntTag                 : cs_interv_age_year_shape('Child deaths prevented by intervention'),
        CS_ChDeathsPrevByInterByCauseTag         : cs_interv_cause_age_year_shape('Child deaths prevented by intervention by cause'),
        CS_DetVaccCovResultsTag                  : gb_shape('Det vacc coverage results', '5D float', dim=[cs_bounds_dim, cs_last_vacc_dim, cs_vacc_dose_dim, cs_age_dim, gb_year_dim], indices=[cs_bounds_indices, cs_last_vacc_indices, cs_vacc_dose_indices,  cs_age_indices, gb_year_indices]),
        # gb_shape('', 'dict', 
        #                                                     innerShape={
        #                                                         'value' : ),
        #                                                         'retro' : gb_shape('retro', '5D float', dim=[cs_bounds_dim, cs_last_vacc_dim, cs_vacc_dose_dim, cs_age_dim, cs_retro_years_dim], indices=[cs_bounds_indices, cs_last_vacc_indices, cs_vacc_dose_indices, cs_age_indices, cs_retro_years_indices])
        #                                                     }),

        CS_DAvtdByVaccByCohortTag                : gb_shape('Deaths varted by vaccine by cohort', '4D float', dim=[cs_bounds_dim, cs_last_vacc_dim, cs_age_dim, gb_year_dim], indices=[cs_bounds_indices, cs_last_vacc_indices, cs_vacc_dose_indices,  cs_age_indices, gb_year_indices]),
        # gb_shape('', 'dict', 
        #                                                     innerShape={
        #                                                         'value' : ,
        #                                                         'retro' : gb_shape('retro', '4D float', dim=[cs_bounds_dim, cs_last_vacc_dim, cs_age_dim, cs_retro_years_dim], indices=[cs_bounds_indices, cs_last_vacc_indices, cs_vacc_dose_indices, cs_age_indices, cs_retro_years_indices])
        #                                                     }),

        CS_DAvtdByVaccByCohortByCauseTag	     : gb_shape('value', '5D float', dim=[cs_bounds_dim, cs_last_vacc_dim, cs_cause_dim, cs_age_dim, gb_year_dim], indices=[cs_bounds_indices, cs_last_vacc_indices, cs_cause_indices,  cs_age_indices, gb_year_indices]),
        # gb_shape('Deaths averated by vaccine by cohort by cause', 'dict', 
        #                                                     innerShape={
        #                                                         'value' : ,
        #                                                         'retro' : gb_shape('retro', '5D float', dim=[cs_bounds_dim, cs_last_vacc_dim, cs_cause_dim, cs_age_dim, cs_retro_years_dim], indices=[cs_bounds_indices, cs_last_vacc_indices, cs_cause_indices, cs_age_indices, cs_retro_years_indices])
        #                                                     }),

        # Maternal sector
        CS_MatDeathsTag                          : cs_year_shape('Maternal deaths'),
        CS_MatDeathsPrevTag                      : cs_year_shape('Maternal deaths prevented'),
        CS_MatDeathsByCauseTag                   : cs_mat_death_causes_by_year_shape('Maternal deaths by cause'),
        CS_MatDeathsPrevByCauseTag               : cs_mat_death_causes_by_year_shape('Maternal deaths prevented by cause'),
        CS_MatDeathsPrevByInterTag               : cs_interv_year_shape('Maternal deaths prevented by intervention'),
        CS_MatDeathsPrevByInterByCauseTag	     : cs_mat_deaths_prev_by_inter_shape('Maternal deaths prevented by intervention by cause'),
        CS_NumAbortionsTag	                     : cs_num_abortions_shape('Number of abortions'),

        # Stillbirth sector
        CS_SBResultsTag                          : cs_year_shape('Stillbirth results'),
        CS_SBPrevResultsTag                      : cs_year_shape('Stillbirth prevented results'),
        CS_SBByCauseResultsTag                   : cs_sbcauses_year('Stillbirth by cause results'),
        CS_SBPrevByCauseResultsTag               : cs_sbcauses_year('Stillbirth prevented by cause results'),
        CS_SBPrevByInterResultsTag               : cs_interv_year_shape('Stillbirth prevented by intervention results'),
        CS_SBPrevByInterByCauseTag               : cs_interv_sbcauses_year('Stillbirth prevented by intervention by cause results'),

        # Mortality rates sector
        CS_SBRateResultTag                       : cs_year_shape('Stillbirth rate results'),
        CS_MatMortRatioResultTag                 : cs_year_shape('Maternal mortality ratio results'),
        CS_MatMortRateResultTag                  : cs_year_shape('Maternal mortality rate results'),
        CS_MortalityRateResultTag                : gb_shape('Mortality rates result', '3D float', 
                                                            dim=[cs_bounds_dim, cs_mort_dim, gb_year_dim], 
                                                            indices=[cs_bounds_indices, cs_mort_indices, gb_year_indices]),
        CS_RedMortIntervResultTag                : cs_red_mort_interv_shape('Reductions in mortality by intervention results'),
        CS_RedMortIntervSortedIDsTag             : cs_interv_shape('Reductions in mortality by intervention sorted IDs'),

        # Nutrition sector
        CS_ShutDownBOAttriByIVTag                : cs_bool_shape('Shut down BO attributes by intervention'),
        CS_SubOpBOAvertByInterTag	             : cs_subop_bo_avert_by_inter_shape('SubOpBOAvertByInter'),
        CS_MAM_PINTag                            : cs_age_shape('MAM PIN'),
        CS_SAM_PINTag                            : cs_age_year_shape('SAM PIN'),
        CS_PInVarHtForAgeStuntTag	             : cs_std_age_shape('Percentage in variable height for age stunting'),
        CS_PInVarWtForHtWasteTag                 : cs_std_age_shape('Percentage in variable weight for height wasting'),
        CS_PInVarWtForHtWasteCFTag               : cs_std_age_shape('Percentage in variable weight for height wasting CF'),
        CS_NumStuntedTag                         : cs_age_year_shape('Number of stunted children'),
        CS_NumStuntedAvertedTag	                 : cs_age_year_shape('Number of stunted children averted'),
        CS_NumStuntedAvertedByInterTag	         : cs_interv_age_year_shape('Number of stunted children averted by intervention'),
        CS_PStuntRedAccountByIntBaseYrTag        : cs_interv_age_year_shape('Percentage stunt reduction accounted by intervention base year'),
        CS_AdditionalYrsSchoolingGainedTag	     : cs_year_shape('Additional years of schooling gained'),
        CS_PercIncEarnStuntDeclineTag	         : cs_year_shape('Percentage increase in earnings due to stunt reduction'),
        CS_ImpLifeEarnDueToStuntReducTag         : cs_discount_shape('Impact on lifetime earnings due to stunt reduction'),
        CS_LifetimeEarningsObtainedTag	         : cs_discount_shape('Lifetime earnings obtained'),
        CS_BFPrevResultTag                       : cs_bf_prev_shape('Breastfeeding prevalence results'),
        CS_BirthTermResultTag	                 : cs_birth_term_shape('Birth term results'),
        CS_PercAnemicWomenTag                    : cs_anemia_by_year_shape('Percentage of anemic women'),
        CS_NumAnemicWomenTag                     : cs_anemia_by_year_shape('Number of anemic women'),
        CS_NumAnemiaCasesPrevTag                 : cs_anemia_by_year_shape('Number of anemia cases prevented'),
        CS_PrevFoodInsecurityTag                 : cs_year_shape('Prevalence of food insecurity'),

        # Incidence and etiology sector
        CS_DiarrIncResultTag                     : cs_age_year_shape('Diarrhea incidence results'),
        CS_SevereDiarrIncResultTag               : cs_age_year_shape('Severe diarrhea incidence results'),
        CS_PneumIncResultTag                     : cs_age_year_shape('Pneumonia incidence results'),
        CS_MeninIncResultTag	                 : cs_age_year_shape('Meningitis incidence results'),
        CS_NumDiarrCasesTag                      : cs_age_year_shape('Number of diarrhea cases'),
        CS_NumSevereDiarrCasesTag                : cs_age_year_shape('Number of severe diarrhea cases'),
        CS_NumPneumCasesTag                      : cs_age_year_shape('Number of pneumonia cases'),
        CS_NumMeninCasesTag                      : cs_age_year_shape('Number of meningitis cases'),
        CS_DiarrCasesAvertByInterTag             : cs_bfpromotion_age_year_shape('Diarrhea cases averted by intervention'),
        CS_SevereDiarrCasesAvertByInterTag       : cs_bfpromotion_age_year_shape('Severe diarrhea cases averted by intervention'),
        CS_PneumCasesAvertByInterTag             : cs_pneum_age_year_shape('Pneumonia cases averted by intervention'),
        CS_MeninCasesAvertByInterTag             : cs_menin_age_year_shape('Meningitis cases averted by intervention'),
        CS_PercDiarrDeathsByPathTag	             : cs_diarr_paths_age_year_shape('Percentage of diarrhea deaths by path'),
        CS_PercPneumDeathsByPathTag              : cs_pneum_path_age_year_shape('Percentage of pneumonia deaths by path'),
        CS_PercMeninDeathsByPathTag              : cs_menin_path_age_year_shape('Percentage of meningitis deaths by path'),
        CS_DiarrDeathsByPathTag                  : cs_diarr_paths_age_year_shape('Diarrhea deaths by path'),
        CS_PneumDeathsByPathTag                  : cs_pneum_path_age_year_shape('Pneumonia deaths by path'),
        CS_MeninDeathsByPathTag                  : cs_menin_path_age_year_shape('Meningitis deaths by path'),
        CS_DiarrDeathsByPathBy1yrAgeGrpsTag      : cs_diarr_paths_agegroup_year_shape('Diarrhea deaths by path by 1 year age groups'),
        CS_PneumDeathsByPathBy1yrAgeGrpsTag      : cs_pneum_path_agegroup_year_shape('Pneumonia deaths by path by 1 year age groups'),
        CS_MeninDeathsByPathBy1yrAgeGrpsTag      : cs_menin_path_agegroup_year_shape('Meningitis deaths by path by 1 year age groups'),
        CS_PercDiarrCasesByPathTag	             : cs_diarr_paths_age_year_shape('Percentage of diarrhea cases by path'),
        CS_PercSevDiarrCasesByPathTag	         : cs_diarr_paths_age_year_shape('Percentage of severe diarrhea cases by path'),
        CS_PercPneumCasesByPathTag               : cs_pneum_path_age_year_shape('Percentage of pneumonia cases by path'),
        CS_PercMeninCasesByPathTag               : cs_menin_path_age_year_shape('Percentage of meningitis cases by path'),
        CS_DiarrCasesByPathTag                   : cs_diarr_paths_age_year_shape('Diarrhea cases by path'),
        CS_SevereDiarrCasesByPathTag             : cs_diarr_paths_age_year_shape('Severe diarrhea cases by path'),
        CS_PneumCasesByPathTag                   : cs_pneum_path_age_year_shape('Pneumonia cases by path'),
        CS_MeninCasesByPathTag                   : cs_menin_path_age_year_shape('Meningitis cases by path'),
        CS_DiarrCasesByPathBy1YrAgeGrpsTag       : cs_diarr_paths_agegroup_year_shape('Diarrhea cases by path by 1 year age groups'),
        CS_SevereDiarrCasesByPathBy1YrAgeGrpsTag : cs_diarr_paths_agegroup_year_shape('Severe diarrhea cases by path by 1 year age groups'),
        CS_PneumCasesByPathBy1YrAgeGrpsTag       : cs_pneum_path_agegroup_year_shape('Pneumonia cases by path by 1 year age groups'),
        CS_MeninCasesByPathBy1YrAgeGrpsTag       : cs_menin_path_agegroup_year_shape('Meningitis cases by path by 1 year age groups'),
        CS_DiarrCasesByBirthCohTag               : cs_year_shape('Diarrhea cases by birth cohort'),
        CS_PneumCasesByBirthCohTag               : cs_year_shape('Pneumonia cases by birth cohort'),
        CS_MeninCasesByBirthCohTag               : cs_year_shape('Meningitis cases by birth cohort'),
        CS_SevDiarrCasesByBirthCohTag            : cs_year_shape('Severe diarrhea cases by birth cohort'),
        CS_DiarCasesAvtdByYr1stDoseVaccTag       : cs_vacc_age_year_shape('Diarrhea cases averted by year 1st dose vaccine'),
        CS_PneumCasesAvtdByYr1stDoseVaccTag      : cs_vacc_age_year_shape('Pneumonia cases averted by year 1st dose vaccine'),
        CS_MeninCasesAvtdByYr1stDoseVaccTag      : cs_vacc_age_year_shape('Meningitis cases averted by year 1st dose vaccine'),
        CS_SevDiarrCasesAvtdByYr1stDoseVaccTag   : cs_vacc_age_year_shape('Severe diarrhea cases averted by year 1st dose vaccine'),
        CS_DiarrDeathsByPathBirthCohTag          : cs_diarr_paths_year_shape('Diarrhea deaths by path by birth cohort'),
        CS_PneumDeathsByPathBirthCohTag          : cs_pneum_path_year_shape('Pneumonia deaths by path by birth cohort'),
        CS_MeninDeathsByPathBirthCohTag          : cs_menin_path_year_shape('Meningitis deaths by path by birth cohort'),
        CS_DiarrCasesByPathBirthCohTag           : cs_diarr_paths_year_shape('Diarrhea cases by path by birth cohort'),
        CS_PneumCasesByPathBirthCohTag           : cs_pneum_path_year_shape('Pneumonia cases by path by birth cohort'),
        CS_MeninCasesByPathBirthCohTag           : cs_menin_path_year_shape('Meningitis cases by path by birth cohort'),
        CS_SevDiarrCasesByPathBirthCohTag        : cs_diarr_paths_year_shape('Severe diarrhea cases by path by birth cohort'),
        CS_DiarrDeathsByPathBirthCohVCTag        : cs_diarr_paths_year_shape('Diarrhea deaths by path by birth cohort VC'),
        CS_PneumDeathsByPathBirthCohVCTag        : cs_pneum_path_year_shape('Pneumonia deaths by path by birth cohort VC'),
        CS_MeninDeathsByPathBirthCohVCTag        : cs_menin_path_year_shape('Meningitis deaths by path by birth cohort VC'),
        CS_DiarrCasesByPathBirthCohVCTag         : cs_diarr_paths_year_shape('Diarrhea cases by path by birth cohort VC'),
        CS_PneumCasesByPathBirthCohVCTag         : cs_pneum_path_year_shape('Pneumonia cases by path by birth cohort VC'),
        CS_MeninCasesByPathBirthCohVCTag         : cs_menin_path_year_shape('Menin cases by path by birth cohort VC'),
        CS_PersonsVaccByIntervTag                : cs_vacc_dose_year_shape('Persons vaccinated by intervention'),
        CS_PersonsVaccByIntervBy1YrAgeGrpsTag    : cs_vacc_dose_agegroup_year_shape('Persons vaccinated by intervention by 1 year age groups'),

        CS_DiscountedCostsTag                    : cs_year_shape('Discounted costs'),
        CS_DiscountedSocialBenefitsTag           : cs_year_shape('Discounted social benefits'),
        CS_DiscountedEconBenefitsTag             : cs_year_shape('Discounted economic benefits'),
        CS_IncLifetimeEarningsDueToStuntTag      : cs_year_shape('Increase in lifetime earnings due to stunt reduction'),
        
        CS_TotalDiscountedCostsTag               : cs_int_shape('Total discounted costs'),
        CS_TotalDiscountedSocialBenefitsTag      : cs_int_shape('Total discounted social benefits'),
        CS_TotalDiscountedEconBenefitsTag        : cs_int_shape('Total discounted economic benefits'),
        CS_LifetimeEarningsIncTag                : cs_int_shape('Lifetime earnings increase due to stunt reduction'),
        CS_BCRTag                                : cs_int_shape('Benefit-cost ratio'),
}
