

from SpectrumCommon.Const.CS import *
from SpectrumCommon.Const.DP import *
from SpectrumCommon.Const.PJ import *

from SpectrumCommon.Modvars.GB.GBUtil import getYearIdx

def CS_PreUpdateModvars(projection, created_projection):
    if CS_DefaultDBChoiceTag not in projection:
        projection[CS_DefaultDBChoiceTag] = CS_DefaultJHUFlag # old projections have JHU by default

    return projection

def CS_UpdateModvars(projection, created_projection):
    finalYrIdx = getYearIdx(projection[PJN_FinalYearTag], projection[PJN_FirstYearTag])

    if CS_GSKModeTag in projection:
        projection[GB_GSKModeTag] = projection[CS_GSKModeTag]
        del projection[CS_GSKModeTag]
        
    return projection

CS_GSKModeTag = '<CS_GSKMode_V1>'