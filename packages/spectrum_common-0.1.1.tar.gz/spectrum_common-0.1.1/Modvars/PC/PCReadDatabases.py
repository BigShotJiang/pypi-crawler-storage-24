from os import environ

import SpectrumCommon.Const.GB as gbc

from AvenirCommon.Database import GB_get_db_json
import AvenirCommon.Util as acu

import SpectrumCommon.Const.PC.PCConst as pcc
import SpectrumCommon.Const.PC.PCConstLink as pccl
import SpectrumCommon.Const.PC.PCDatabaseKeys as pcdbk

import SpectrumCommon.Const.PC.PCModVarFields as pcmvf
import SpectrumCommon.Modvars.PC.PCModVarDefs as pcmvd
import SpectrumCommon.Modvars.PC.PCModVarUtil as pcmvu
import SpectrumCommon.Modvars.PC.PCUtil as pcu

#######################################################################################################
#                                                                                                     #
#                                       Database loading methods                                      #
#                                                                                                     #
#######################################################################################################

def PC_load_cost_cat_DB():
    cost_cat_DB_file_name = pcc.PC_COST_CAT_DB_NAME + '_' + pcc.PC_COST_CAT_DB_CURR_VERSION + '.' + gbc.GB_JSON 
    cost_cat_DB = GB_get_db_json(environ[gbc.GB_SPECT_MOD_DATA_CONN_ENV], gbc.GB_PC_CONTAINER, cost_cat_DB_file_name) 

    return cost_cat_DB

def PC_load_cost_input_DB():
    cost_input_DB_file_name = pcc.PC_COST_INPUT_DB_NAME + '_' + pcc.PC_COST_INPUT_DB_CURR_VERSION + '.' + gbc.GB_JSON 
    cost_input_DB = GB_get_db_json(environ[gbc.GB_SPECT_MOD_DATA_CONN_ENV], gbc.GB_PC_CONTAINER, cost_input_DB_file_name) 

    return cost_input_DB

def PC_load_activity_DB():
    activity_DB_file_name = pcc.PC_ACTIVITY_DB_NAME + '_' + pcc.PC_ACTIVITY_DB_CURR_VERSION + '.' + gbc.GB_JSON 
    activity_DB = GB_get_db_json(environ[gbc.GB_SPECT_MOD_DATA_CONN_ENV], gbc.GB_PC_CONTAINER, activity_DB_file_name) 

    return activity_DB

def PC_load_activity_line_item_DB():
    activity_line_item_DB_file_name = pcc.PC_ACTIVITY_LINE_ITEM_DB_NAME + '_' + pcc.PC_ACTIVITY_LINE_ITEM_DB_CURR_VERSION + '.' + gbc.GB_JSON 
    activity_line_item_DB = GB_get_db_json(environ[gbc.GB_SPECT_MOD_DATA_CONN_ENV], gbc.GB_PC_CONTAINER, activity_line_item_DB_file_name) 

    return activity_line_item_DB

def PC_load_PPLI_activity_line_item_DB():
    PPLI_activity_line_item_DB_file_name = pcc.PC_PPLI_ACTIVITY_LINE_ITEM_DB_NAME + '_' + pcc.PC_PPLI_ACTIVITY_LINE_ITEM_DB_CURR_VERSION + '.' + gbc.GB_JSON 
    PPLI_activity_line_item_DB = GB_get_db_json(environ[gbc.GB_SPECT_MOD_DATA_CONN_ENV], gbc.GB_PC_CONTAINER, PPLI_activity_line_item_DB_file_name) 

    return PPLI_activity_line_item_DB

def PC_load_costing_sect_DB():
    costing_sect_DB_file_name = pcc.PC_COSTING_SECT_DB_NAME + '_' + pcc.PC_COSTING_SECT_DB_CURR_VERSION + '.' + gbc.GB_JSON 
    costing_sect_DB = GB_get_db_json(environ[gbc.GB_SPECT_MOD_DATA_CONN_ENV], gbc.GB_PC_CONTAINER, costing_sect_DB_file_name) 

    return costing_sect_DB

def PC_load_PPLI_phase_DB(country_ID):
    PPLI_phase_DB_file_name = pcc.PC_PPLI_PHASES_DB_DIR.replace('\\', '/') + '/' + country_ID + '_' + pcc.PC_PPLI_PHASE_DB_CURR_VERSION + '.' + gbc.GB_JSON 
    PPLI_phase_DB = GB_get_db_json(environ[gbc.GB_SPECT_MOD_DATA_CONN_ENV], gbc.GB_PC_CONTAINER, PPLI_phase_DB_file_name) 

    return PPLI_phase_DB

def PC_load_PPLI_taxation_DB(country_ID):
    PPLI_taxation_DB_file_name = pcc.PC_PPLI_TAXATION_DB_DIR.replace('\\', '/') + '/' + country_ID + '_' + pcc.PC_PPLI_TAXATION_DB_CURR_VERSION + '.' + gbc.GB_JSON 
    PPLI_taxation_DB = GB_get_db_json(environ[gbc.GB_SPECT_MOD_DATA_CONN_ENV], gbc.GB_PC_CONTAINER, PPLI_taxation_DB_file_name) 

    return PPLI_taxation_DB

#######################################################################################################
#                                                                                                     #
#                                       Cost categories                                               #
#                                                                                                     #
#######################################################################################################

def PC_init_cost_cat_records(cost_cat_DB):
    cost_cat_records = []

    for cost_cat_DB_obj in cost_cat_DB:
        ID = str(cost_cat_DB_obj[pcdbk.PC_COST_CAT_ID_KEY_CCDB])
        name = cost_cat_DB_obj[pcdbk.PC_COST_CAT_NAME_KEY_CCDB] 
        string_constant = cost_cat_DB_obj[pcdbk.PC_COST_CAT_STR_CONST_KEY_CCDB] 

        cost_cat_rec = pcmvd.PC_create_cost_cat_rec(ID, name, string_constant)
        cost_cat_records.append(cost_cat_rec)

    return cost_cat_records

#######################################################################################################
#                                                                                                     #
#                                       Cost inputs                                                   #
#                                                                                                     #
#######################################################################################################

def PC_init_cost_input_records(cost_input_DB):
    cost_input_records = []

    for cost_input_DB_obj in cost_input_DB:
        cost_input_ID = str(cost_input_DB_obj[pcdbk.PC_COST_INPUT_ID_KEY_CIDB]) 
        name = cost_input_DB_obj[pcdbk.PC_COST_INPUT_NAME_KEY_CIDB] 
        cost_input_string_constant = cost_input_DB_obj[pcdbk.PC_COST_INPUT_STR_CONST_KEY_CIDB] 
        cost_cat_ID = str(cost_input_DB_obj[pcdbk.PC_COST_CAT_ID_KEY_CIDB])
        unit_cost = cost_input_DB_obj[pcdbk.PC_UNIT_COST_KEY_CIDB] 
        unit_of_measure = cost_input_DB_obj[pcdbk.PC_UNIT_OF_MEASURE_KEY_CIDB] 
        unit_of_measure_string_constant = cost_input_DB_obj[pcdbk.PC_UNIT_OF_MEASURE_STR_CONST_KEY_CIDB]
        note = cost_input_DB_obj[pcdbk.PC_NOTE_KEY_CIDB]
        source = cost_input_DB_obj[pcdbk.PC_SOURCE_KEY_CIDB]

        cost_input_rec = pcmvd.PC_create_cost_input_rec(cost_input_ID, name, cost_cat_ID)

        pcmvu.set_PC_cost_input_string_constant(cost_input_rec, cost_input_string_constant)
        pcmvu.set_PC_cost_input_unit_cost(cost_input_rec, unit_cost)
        pcmvu.set_PC_cost_input_unit_of_measure(cost_input_rec, unit_of_measure)
        pcmvu.set_PC_cost_input_unit_of_measure_string_constant(cost_input_rec, unit_of_measure_string_constant)
        pcmvu.set_PC_cost_input_note(cost_input_rec, note)
        pcmvu.set_PC_cost_input_source(cost_input_rec, source)

        cost_input_records.append(cost_input_rec)

    return cost_input_records

def PC_create_rec_from_DB_data(area_type_ID = int, area_ID = int, costing_mode = int, modules = list):
    # Process the DB data if one of the following is true.
    #
    #    1. The area type is modules and one of the following is true
    #       a) the area is the TB module and we're doing IHT TB costing.
    #       b) the area is the CS module and we're doing LiST Costing.
    #       c) the area is the HS module and HS is an active module.
    # 
    #    2. The area type is health systems/programme management, we're doing IHT costing, and
    #       a) the area is health information systems and HS is an active module.
    #       b) the area is infrastructure and IS is an active module.
    #       c) the area is health workforce and HW is an active module.
    #       d) the area is logistics and LG is an active module.
    #
    #    3. The area type is a programme area and we're doing IHT costing.
    #
    #    4. The area type is the special PPLI area in the NCD programme area and we're doing IHT costing.
    # 
    #    5. The area type is the special social enablers area in the HIV programme area and we're doing IHT costing.
    #

    return (
        ((area_type_ID == pccl.PC_IH_MODULE_MST_ID) 
        and (((area_ID == str(gbc.GB_TB)) and (costing_mode == gbc.GB_TB_COSTING_MODE)) 
        or ((area_ID == str(gbc.GB_CS)) and (costing_mode == gbc.GB_LIST_COSTING_MODE))
        or ((area_ID == str(gbc.GB_HS)) and (gbc.GB_HS in modules))))
    
        or
    
        ((area_type_ID == pccl.PC_IH_HEALTH_SYS_MST_ID) and (costing_mode == gbc.GB_IHT_COSTING_MODE)
        and (((area_ID == str(pccl.PC_IH_HEALTH_INFORM_SYSTEMS_HSPM_MST_ID)) and (gbc.GB_HS in modules))
        or ((area_ID == str(pccl.PC_IH_INFRASTRUCTURE_HSPM_MST_ID)) and (gbc.GB_IS in modules))
        or ((area_ID == str(pccl.PC_IH_HEALTH_WORKFORCE_HSPM_MST_ID)) and (gbc.GB_HW in modules))
        or ((area_ID == str(pccl.PC_IH_LOGISTICS_HSPM_MST_ID)) and (gbc.GB_LG in modules))))

        or 

        ((area_type_ID == pccl.PC_IH_PROG_AREA_MST_ID) and (costing_mode == gbc.GB_IHT_COSTING_MODE))

        or

        ((area_type_ID == pccl.PC_IH_PPLI_MST_ID) and (costing_mode == gbc.GB_IHT_COSTING_MODE))

        or

        ((area_type_ID == pccl.PC_IH_SOCIAL_ENABLERS_MST_ID) and (costing_mode == gbc.GB_IHT_COSTING_MODE))
    )

#######################################################################################################
#                                                                                                     #
#                         Costing categories and costing category sections                            #
#                                                                                                     #
#######################################################################################################

def PC_init_costing_sect_records(costing_sect_DB, num_years, costing_mode, modules, PPLI):
    costing_sect_records = []

    i = 0

    for costing_sect_DB_obj in costing_sect_DB:
        area_type_ID = costing_sect_DB_obj[pcdbk.PC_AREA_TYPE_ID_KEY_CSDB]
        area_ID = str(costing_sect_DB_obj[pcdbk.PC_AREA_ID_KEY_CSDB]) 
        costing_sect_ID = str(costing_sect_DB_obj[pcdbk.PC_COSTING_SECT_ID_KEY_CSDB]) 
        costing_sect_name = str(costing_sect_DB_obj[pcdbk.PC_COSTING_SECT_NAME_KEY_CSDB])
        costing_sect_string_constant = str(costing_sect_DB_obj[pcdbk.PC_COSTING_SECT_STR_CONST_KEY_CSDB])
        costing_subsect_ID = str(costing_sect_DB_obj[pcdbk.PC_COSTING_SUBSECT_ID_KEY_CSDB]) 
        costing_subsect_name = str(costing_sect_DB_obj[pcdbk.PC_COSTING_SUBSECT_NAME_KEY_CSDB]) 
        costing_subsect_string_constant = str(costing_sect_DB_obj[pcdbk.PC_COSTING_SUBSECT_STR_CONST_KEY_CSDB]) 

        if (not PPLI) and PC_create_rec_from_DB_data(area_type_ID, area_ID, costing_mode, modules):

            # Costing section will have a costing subsection ID of -1. Costing section should always come before their costing subsections in the database.
            if costing_subsect_ID == str(gbc.GB_NOT_FOUND):
                costing_sect_rec = pcmvd.PC_create_costing_section_rec(area_type_ID, area_ID, costing_sect_ID, costing_sect_name, costing_sect_string_constant, num_years, costing_mode)
                costing_sect_records.append(costing_sect_rec)

                if costing_mode == gbc.GB_LIST_COSTING_MODE:
                    for t in acu.GBRange(1, num_years):
                        pcmvu.set_PC_costing_sect_costs_CS(costing_sect_rec, t - 1, costing_sect_DB_obj[pcdbk.PC_COSTS_CS_KEY_CSDB])

            else:
                costing_subsect_rec = pcmvd.PC_create_costing_subsection_rec(costing_subsect_ID, costing_subsect_name, costing_subsect_string_constant)
                '''
                    Since the database lists costing sections first, then their subsections, then repeats, we should always be able to add the subsection to
                    the current section.
                '''
                costing_sect_records[-1][pcmvf.PC_COSTING_SECT_SUBSECT_RECORDS].append(costing_subsect_rec)

            i += 1

        elif PPLI and (area_type_ID == pccl.PC_IH_PPLI_MST_ID) and (costing_mode == gbc.GB_IHT_COSTING_MODE):

            # Costing section will have a costing subsection ID of -1. Costing section should always come before their costing subsections in the database.
            if costing_subsect_ID == str(gbc.GB_NOT_FOUND):
                costing_sect_rec = pcmvd.PC_create_costing_section_rec_PPLI(area_ID, costing_sect_ID, costing_sect_name, costing_sect_string_constant, num_years)
                costing_sect_records.append(costing_sect_rec)

            else:
                costing_subsect_rec = pcmvd.PC_create_costing_subsection_rec_PPLI(costing_subsect_ID, costing_subsect_name, costing_subsect_string_constant, num_years)
                '''
                    Since the database lists costing sections first, then their subsections, then repeats, we should always be able to add the subsection to 
                    the current section.
                '''
                costing_sect_records[-1][pcmvf.PC_COSTING_SECT_SUBSECT_RECORDS].append(costing_subsect_rec)
            
    return costing_sect_records

def PC_init_custom_prog_area_costing_sect_records(costing_mode, custom_prog_area_ID):
    # Custom programme areas can only be added in IHT
    if not costing_mode == gbc.GB_IHT_COSTING_MODE: pass

    costing_sect_DB = PC_load_costing_sect_DB()

    custom_DB_records = [costing_sect_DB_obj for costing_sect_DB_obj in costing_sect_DB if costing_sect_DB_obj[pcdbk.PC_AREA_ID_KEY_CSDB] == pcc.PC_COSTING_SECT_DB_AREA_ID_CUSTOM]

    custom_costing_sect_records = []

    for costing_sect_DB_obj in custom_DB_records:
        area_type_ID = costing_sect_DB_obj[pcdbk.PC_AREA_TYPE_ID_KEY_CSDB]
        area_ID = custom_prog_area_ID
        costing_sect_ID = str(costing_sect_DB_obj[pcdbk.PC_COSTING_SECT_ID_KEY_CSDB]) 
        costing_sect_name = str(costing_sect_DB_obj[pcdbk.PC_COSTING_SECT_NAME_KEY_CSDB])
        costing_sect_string_constant = str(costing_sect_DB_obj[pcdbk.PC_COSTING_SECT_STR_CONST_KEY_CSDB])
        costing_subsect_ID = str(costing_sect_DB_obj[pcdbk.PC_COSTING_SUBSECT_ID_KEY_CSDB]) 
        costing_subsect_name = str(costing_sect_DB_obj[pcdbk.PC_COSTING_SUBSECT_NAME_KEY_CSDB]) 
        costing_subsect_string_constant = str(costing_sect_DB_obj[pcdbk.PC_COSTING_SUBSECT_STR_CONST_KEY_CSDB]) 

        # Costing section will have a costing subsection ID of -1. Costing section should always come before their costing subsections in the database.
        if costing_subsect_ID == str(gbc.GB_NOT_FOUND):
            costing_sect_rec = pcmvd.PC_create_costing_section_rec(area_type_ID, area_ID, costing_sect_ID, costing_sect_name, costing_sect_string_constant, 0, costing_mode)
            custom_costing_sect_records.append(costing_sect_rec)

        else:
            costing_subsect_rec = pcmvd.PC_create_costing_subsection_rec(costing_subsect_ID, costing_subsect_name, costing_subsect_string_constant)
            # Since the database lists costing sections first, then their subsections, then repeats, we should always be able to add the subsection to the current section.
            custom_costing_sect_records[-1][pcmvf.PC_COSTING_SECT_SUBSECT_RECORDS].append(costing_subsect_rec)
            
    return custom_costing_sect_records

#######################################################################################################
#                                                                                                     #
#                                              Activities                                             #
#                                                                                                     #
#######################################################################################################

def PC_init_activity_records(activity_DB, costing_mode, modules, PPLI):
    activity_records = []

    for activity_DB_obj in activity_DB:
        area_type_ID = activity_DB_obj[pcdbk.PC_AREA_TYPE_ID_KEY_ADB]
        area_ID = activity_DB_obj[pcdbk.PC_AREA_ID_KEY_ADB]
        costing_sect_ID = str(activity_DB_obj[pcdbk.PC_COSTING_SECT_ID_KEY_ADB])
        costing_subsect_ID = str(activity_DB_obj[pcdbk.PC_COSTING_SUBSECT_ID_KEY_ADB])  
        activity_ID = str(activity_DB_obj[pcdbk.PC_ACT_ID_KEY_ADB])     
        name = activity_DB_obj[pcdbk.PC_ACT_NAME_KEY_ADB]   
        string_constant = activity_DB_obj[pcdbk.PC_ACT_STR_CONST_KEY_ADB]   

        if (
            ((not PPLI) and PC_create_rec_from_DB_data(area_type_ID, area_ID, costing_mode, modules)) 
            or (PPLI and (area_type_ID == pccl.PC_IH_PPLI_MST_ID) and (costing_mode == gbc.GB_IHT_COSTING_MODE))
        ):
            activity_rec = pcmvd.PC_create_activity_rec(area_type_ID, area_ID, costing_sect_ID, costing_subsect_ID, activity_ID, name)
            pcmvu.set_PC_act_string_constant(activity_rec, string_constant)
            pcmvu.add_PC_activity_rec(activity_records, activity_rec)
            
    return activity_records

#######################################################################################################
#                                                                                                     #
#                                       Activity line items (ALIs)                                    #
#                                                                                                     #
#######################################################################################################

def PC_init_activity_line_item_records(activity_line_item_DB, num_years, costing_mode, modules):
    ALI_records = []

    for ALI_DB_obj in activity_line_item_DB:
        area_type_ID = ALI_DB_obj[pcdbk.PC_AREA_TYPE_ID_KEY_ALIDB]
        area_ID = ALI_DB_obj[pcdbk.PC_AREA_ID_KEY_ALIDB]
        costing_sect_ID = ALI_DB_obj[pcdbk.PC_COSTING_SECT_ID_KEY_ALIDB]
        costing_subsect_ID = ALI_DB_obj[pcdbk.PC_COSTING_SUBSECT_ID_KEY_ALIDB]
        act_ID = ALI_DB_obj[pcdbk.PC_ACT_ID_KEY_ALIDB]
        cost_input_ID = ALI_DB_obj[pcdbk.PC_COST_INPUT_ID_KEY_ALIDB]
        units = ALI_DB_obj[pcdbk.PC_NUM_UNITS_KEY_ALIDB]
        duration = ALI_DB_obj[pcdbk.PC_DURATION_KEY_ALIDB]
        frequency = ALI_DB_obj[pcdbk.PC_FREQUENCY_KEY_ALIDB]

        if PC_create_rec_from_DB_data(area_type_ID, area_ID, costing_mode, modules):
            ALI_rec = pcmvd.PC_create_activity_line_item_rec(area_type_ID, area_ID, costing_sect_ID, costing_subsect_ID, act_ID, cost_input_ID, num_years, False)

            pcmvu.set_PC_ALI_num_units(ALI_rec, units)
            pcmvu.set_PC_ALI_duration(ALI_rec, duration)

            for t in acu.GBRange(1, num_years):
                pcmvu.set_PC_ALI_frequency(ALI_rec, t - 1, frequency)

            pcmvu.add_PC_ALI_rec(ALI_records, ALI_rec)

    return ALI_records

def PC_init_PPLI_activity_line_item_records(activity_line_item_DB, costing_sect_records, num_years):
    ALI_records = []

    for ALI_DB_obj in activity_line_item_DB:
        area_type_ID = ALI_DB_obj[pcdbk.PC_AREA_TYPE_ID_KEY_PALIDB]
        area_ID = ALI_DB_obj[pcdbk.PC_AREA_ID_KEY_PALIDB]
        costing_sect_ID = ALI_DB_obj[pcdbk.PC_COSTING_SECT_ID_KEY_PALIDB]
        costing_subsect_ID = ALI_DB_obj[pcdbk.PC_COSTING_SUBSECT_ID_KEY_PALIDB]
        act_ID = ALI_DB_obj[pcdbk.PC_ACT_ID_KEY_PALIDB]
        cost_input_ID = ALI_DB_obj[pcdbk.PC_COST_INPUT_ID_KEY_PALIDB]
        units = ALI_DB_obj[pcdbk.PC_NUM_UNITS_KEY_PALIDB]
        duration = ALI_DB_obj[pcdbk.PC_DURATION_KEY_PALIDB]
        quantity = ALI_DB_obj[pcdbk.PC_QUANTITY_KEY_PALIDB]

        costing_subsect_rec = pcmvu.get_PC_costing_subsect_rec(costing_sect_records, area_type_ID, area_ID, costing_sect_ID, costing_subsect_ID)

        ALI_rec = pcmvd.PC_create_activity_line_item_rec_PPLI(area_ID, costing_sect_ID, costing_subsect_ID, act_ID, cost_input_ID, num_years)

        for al in acu.GBRange(1, pcc.PC_PPLI_NUM_ADMIN_LEVELS):
            pcmvu.set_PC_ALI_num_units_PPLI(ALI_rec, al, units[al - 1])
            pcmvu.set_PC_ALI_duration_PPLI(ALI_rec, al, duration[al - 1])

            for pas in acu.GBRange(1, pcc.PC_NUM_PPLI_ALI_SETS):
                for t in acu.GBRange(1, num_years):
                    phase_ID = pcmvu.get_PC_costing_subsect_PPLI_phase_intensity(costing_subsect_rec, pcc.PC_PHASE_ROW_PPLI_CURR_ID, t - 1)
                    phase_curr_ID = pcu.get_PPLI_phase_curr_ID(phase_ID)

                    pcmvu.set_PC_ALI_quantity(ALI_rec, pas, al, t - 1, quantity[phase_curr_ID - 1][al - 1])

        pcmvu.add_PC_ALI_rec(ALI_records, ALI_rec)

    return ALI_records

#######################################################################################################
#                                                                                                     #
#                                       PPLI phases                                                   #
#                                                                                                     #
#######################################################################################################

def PC_init_PPLI_phase_and_intensity(PPLI_phase_DB, costing_sect_records_PPLI, num_years):
    phase_intensity_records = PPLI_phase_DB[pcdbk.PC_PHASE_INTENSITY_RECORDS_KEY_PPLIPDB]

    for phase_intensity_rec in phase_intensity_records:
        area_type_ID = phase_intensity_rec[pcdbk.PC_AREA_TYPE_ID_KEY_PPLIPDB] 
        area_ID = str(phase_intensity_rec[pcdbk.PC_AREA_ID_KEY_PPLIPDB]) 
        costing_sect_ID = str(phase_intensity_rec[pcdbk.PC_COSTING_SECT_ID_KEY_PPLIPDB])    
        costing_subsect_ID = str(phase_intensity_rec[pcdbk.PC_COSTING_SUBSECT_ID_KEY_PPLIPDB]) 

        costing_subsect_rec = pcmvu.get_PC_costing_subsect_rec(costing_sect_records_PPLI, area_type_ID, area_ID, costing_sect_ID, costing_subsect_ID)

        if costing_subsect_rec != gbc.GB_NOT_FOUND:

            phase_ID = phase_intensity_rec[pcdbk.PC_PHASE_ID_KEY_PPLIPDB]                

            if (
                (area_type_ID == pccl.PC_IH_PPLI_MST_ID)
                and (area_ID == str(pccl.PC_IH_NCD_MST_ID)) 
                and (costing_sect_ID == pcc.PC_PPLI_TOBACCO_CTRL_COST_SECT_ID)
                and (costing_subsect_ID == pcc.PC_RAISE_TAXES_PPLI_COSTING_SUBSECT_ID)
            ):
                for t in acu.GBRange(1, num_years):
                    pcmvu.set_PC_costing_subsect_PPLI_phase_intensity(costing_subsect_rec, pcc.PC_PHASE_ROW_PPLI_CURR_ID, t - 1, phase_ID)
                # Make the final year full implementation for all countries.
                pcmvu.set_PC_costing_subsect_PPLI_phase_intensity(costing_subsect_rec, pcc.PC_PHASE_ROW_PPLI_CURR_ID, num_years - 1, 
                    pcc.PC_FULL_IMP_PHASE_100_PPLI_MST_ID)
                
                pcmvu.set_PC_costing_subsect_PPLI_phase_intensity(costing_subsect_rec, pcc.PC_INTENSITY_ROW_PPLI_CURR_ID, num_years - 1, 
                    pcu.get_PPLI_intensity_value(pcc.PC_FULL_IMP_PHASE_100_PPLI_MST_ID))
            
            else:
                for t in acu.GBRange(1, num_years):
                    pcmvu.set_PC_costing_subsect_PPLI_phase_intensity(costing_subsect_rec, pcc.PC_PHASE_ROW_PPLI_CURR_ID, t - 1, phase_ID)
                    pcmvu.set_PC_costing_subsect_PPLI_phase_intensity(costing_subsect_rec, pcc.PC_INTENSITY_ROW_PPLI_CURR_ID, t - 1, 
                        pcu.get_PPLI_intensity_value(phase_ID))

#######################################################################################################
#                                                                                                     #
#                                       PPLI taxation                                                 #
#                                                                                                     #
#######################################################################################################

def PC_set_price_elasticity_params(PPLI_taxation_DB, tobacco_costing_sect_rec):
    if tobacco_costing_sect_rec != gbc.GB_NOT_FOUND:
        pcmvu.set_PC_costing_sect_price_elasticity_PPLI(tobacco_costing_sect_rec, pcc.PC_TAX_PARAMS_PPLI_CURR_ID,
            PPLI_taxation_DB[pcdbk.PC_PRICE_ELASTICITY_PARAMS_KEY_PPLITDB])


