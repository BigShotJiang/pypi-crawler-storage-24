import SpectrumCommon.Const.GB.GBConst as gbc

import SpectrumCommon.Const.PC.PCModVarFields as pcmvf

#######################################################################################################
#                                                                                                     #
#                                       Cost categories                                               #
#                                                                                                     #
#######################################################################################################

def get_PC_cost_cat_rec(cost_cat_records = list, ID = str):
    cost_cat_recs = [cost_cat_rec for cost_cat_rec in cost_cat_records if cost_cat_rec[pcmvf.PC_COST_CAT_ID] == ID]
    return cost_cat_recs[0] if len(cost_cat_recs) > 0 else gbc.GB_NOT_FOUND
   
###
   
def get_PC_cost_cat_idx(cost_cat_records = list, ID = str):
    indices = [idx for (idx, cost_cat_rec) in enumerate(cost_cat_records) if cost_cat_rec[pcmvf.PC_COST_CAT_ID] == ID]
    return indices[0] if len(indices) > 0 else gbc.GB_NOT_FOUND

### 

def get_PC_cost_cat_ID(cost_cat_rec = dict):
    return cost_cat_rec[pcmvf.PC_COST_CAT_ID]

def set_PC_cost_cat_ID(cost_cat_rec = dict, value = str):
    cost_cat_rec[pcmvf.PC_COST_CAT_ID] = value

###
   
def get_PC_cost_cat_name(cost_cat_rec = dict):
    return cost_cat_rec[pcmvf.PC_COST_CAT_NAME]

def set_PC_cost_cat_name(cost_cat_rec = dict, value = str):
    cost_cat_rec[pcmvf.PC_COST_CAT_NAME] = value

###
   
def get_PC_cost_cat_string_constant(cost_cat_rec = dict):
    return cost_cat_rec[pcmvf.PC_COST_CAT_STR_CONST]

def set_PC_cost_cat_string_constant(cost_cat_rec = dict, value = str):
    cost_cat_rec[pcmvf.PC_COST_CAT_STR_CONST] = value
 
###

def get_PC_cost_cat_custom(cost_cat_rec = dict):
    return cost_cat_rec[pcmvf.PC_COST_CAT_CUSTOM]

def set_PC_cost_cat_custom(cost_cat_rec = dict, value = bool):
    cost_cat_rec[pcmvf.PC_COST_CAT_CUSTOM] = value

###

#######################################################################################################
#                                                                                                     #
#                                       Cost inputs                                                   #
#                                                                                                     #
#######################################################################################################

def get_PC_num_cost_inputs(cost_input_records = list):
    return len(cost_input_records)

def get_PC_cost_input_rec(cost_input_records = list, ID = str):
    cost_input_recs = [cost_input_rec for cost_input_rec in cost_input_records if cost_input_rec[pcmvf.PC_COST_INPUT_ID] == ID]
    return cost_input_recs[0] if len(cost_input_recs) > 0 else gbc.GB_NOT_FOUND
   
###
   
def get_PC_cost_input_idx(cost_input_records = list, ID = str):
    indices = [idx for (idx, cost_input_rec) in enumerate(cost_input_records) if cost_input_rec[pcmvf.PC_COST_INPUT_ID] == ID]
    return indices[0] if len(indices) > 0 else gbc.GB_NOT_FOUND
   
###
   
def get_PC_cost_input_cat_ID(cost_input_rec = dict):
    return cost_input_rec[pcmvf.PC_COST_INPUT_CAT_ID]

def set_PC_cost_input_cat_ID(cost_input_rec = dict, value = str):
    cost_input_rec[pcmvf.PC_COST_INPUT_CAT_ID] = value

###

def get_PC_cost_input_ID(cost_input_rec = dict):
    return cost_input_rec[pcmvf.PC_COST_INPUT_ID]

def set_PC_cost_input_ID(cost_input_rec = dict, value = str):
    cost_input_rec[pcmvf.PC_COST_INPUT_ID] = value

###
   
def get_PC_cost_input_name(cost_input_rec = dict):
    return cost_input_rec[pcmvf.PC_COST_INPUT_NAME]

def set_PC_cost_input_name(cost_input_rec = dict, value = str):
    cost_input_rec[pcmvf.PC_COST_INPUT_NAME] = value
 
###

def get_PC_cost_input_string_constant(cost_input_rec = dict):
    return cost_input_rec[pcmvf.PC_COST_INPUT_STR_CONST]

def set_PC_cost_input_string_constant(cost_input_rec = dict, value = str):
    cost_input_rec[pcmvf.PC_COST_INPUT_STR_CONST] = value
 
###

def get_PC_cost_input_custom(cost_input_rec = dict):
    return cost_input_rec[pcmvf.PC_COST_INPUT_CUSTOM]

def set_PC_cost_input_custom(cost_input_rec = dict, value = bool):
    cost_input_rec[pcmvf.PC_COST_INPUT_CUSTOM] = value

###


def get_PC_cost_input_unit_cost(cost_input_rec = dict):
    return cost_input_rec[pcmvf.PC_COST_INPUT_UNIT_COST]

def set_PC_cost_input_unit_cost(cost_input_rec = dict, value = float):
    cost_input_rec[pcmvf.PC_COST_INPUT_UNIT_COST] = value

###

def get_PC_cost_input_unit_of_measure(cost_input_rec = dict):
    return cost_input_rec[pcmvf.PC_COST_INPUT_UNIT_OF_MEASURE]

def set_PC_cost_input_unit_of_measure(cost_input_rec = dict, value = str):
    cost_input_rec[pcmvf.PC_COST_INPUT_UNIT_OF_MEASURE] = value

###

def get_PC_cost_input_unit_of_measure_string_constant(cost_input_rec = dict):
    return cost_input_rec[pcmvf.PC_COST_INPUT_UNIT_OF_MEASURE_STR_CONST]

def set_PC_cost_input_unit_of_measure_string_constant(cost_input_rec = dict, value = str):
    cost_input_rec[pcmvf.PC_COST_INPUT_UNIT_OF_MEASURE_STR_CONST] = value

###

def get_PC_cost_input_note(cost_input_rec = dict):
    return cost_input_rec[pcmvf.PC_COST_INPUT_NOTE]

def set_PC_cost_input_note(cost_input_rec = dict, value = str):
    cost_input_rec[pcmvf.PC_COST_INPUT_NOTE] = value

###

def get_PC_cost_input_source(cost_input_rec = dict):
    return cost_input_rec[pcmvf.PC_COST_INPUT_SOURCE]

def set_PC_cost_input_source(cost_input_rec = dict, value = str):
    cost_input_rec[pcmvf.PC_COST_INPUT_SOURCE] = value

###

# def get_PC_cost_input_source_string_constant(cost_input_rec = dict):
#     return cost_input_rec[pcmvf.PC_COST_INPUT_SOURCE_STR_CONST]

# def set_PC_cost_input_source_string_constant(cost_input_rec = dict, value = str):
#     cost_input_rec[pcmvf.PC_COST_INPUT_SOURCE_STR_CONST] = value

#######################################################################################################
#                                                                                                     #
#                                           Costing sections                                          #
#                                                                                                     #
#######################################################################################################

def get_PC_costing_sect_recs(costing_sect_records = list, area_type_ID = str, area_ID = str):
    costing_sect_recs = [costing_sect_rec for costing_sect_rec in costing_sect_records if \
        ((costing_sect_rec[pcmvf.PC_COSTING_SECT_AREA_TYPE_ID] == area_type_ID) \
        and (costing_sect_rec[pcmvf.PC_COSTING_SECT_AREA_ID] == area_ID))]
    return costing_sect_recs

def get_PC_num_costing_sects(costing_sect_records = list, area_type_ID = str, area_ID = str):
    costing_sect_records_reduced = get_PC_costing_sect_recs(costing_sect_records, area_type_ID, area_ID)
    if costing_sect_records_reduced == gbc.GB_NOT_FOUND:
        return 0
    else:
        return len(costing_sect_records_reduced)

def get_PC_costing_sect_rec(costing_sect_records: list, area_type_ID: str, area_ID: str, ID: str):
    costing_sect_recs = [costing_sect_rec for costing_sect_rec in costing_sect_records if \
        ((costing_sect_rec[pcmvf.PC_COSTING_SECT_AREA_TYPE_ID] == area_type_ID) \
        and (costing_sect_rec[pcmvf.PC_COSTING_SECT_AREA_ID] == area_ID) \
        and (costing_sect_rec[pcmvf.PC_COSTING_SECT_ID] == ID))]
    return costing_sect_recs[0] if len(costing_sect_recs) > 0 else gbc.GB_NOT_FOUND
   
###
   
def get_PC_costing_sect_idx(costing_sect_records = list, area_type_ID = str, area_ID = str, ID = str):
    indices = [idx for (idx, costing_sect_rec) in enumerate(costing_sect_records) if \
        ((costing_sect_rec[pcmvf.PC_COSTING_SECT_AREA_TYPE_ID] == area_type_ID) \
        and (costing_sect_rec[pcmvf.PC_COSTING_SECT_AREA_ID] == area_ID) \
        and (costing_sect_rec[pcmvf.PC_COSTING_SECT_ID] == ID))]
    return indices[0] if len(indices) > 0 else gbc.GB_NOT_FOUND
   
###
   
def get_PC_costing_sect_ID(costing_sect_rec = dict):
    return costing_sect_rec[pcmvf.PC_COSTING_SECT_ID]

def set_PC_costing_sect_ID(costing_sect_rec = dict, value = str):
    costing_sect_rec[pcmvf.PC_COSTING_SECT_ID] = value

###
   
def get_PC_costing_sect_name(costing_sect_rec = dict):
    return costing_sect_rec[pcmvf.PC_COSTING_SECT_NAME]

def set_PC_costing_sect_name(costing_sect_rec = dict, value = str):
    costing_sect_rec[pcmvf.PC_COSTING_SECT_NAME] = value

###

def get_PC_costing_sect_string_constant(costing_sect_rec = dict):
    return costing_sect_rec[pcmvf.PC_COSTING_SECT_STR_CONST]

def set_PC_costing_sect_string_constant(costing_sect_rec = dict, value = str):
    costing_sect_rec[pcmvf.PC_COSTING_SECT_STR_CONST] = value

###

def get_PC_costing_sect_custom(costing_sect_rec = dict):
    return costing_sect_rec[pcmvf.PC_COSTING_SECT_CUSTOM]

def set_PC_costing_sect_custom(costing_sect_rec = dict, value = bool):
    costing_sect_rec[pcmvf.PC_COSTING_SECT_CUSTOM] = value

###

def get_PC_costing_sect_costs_CS(costing_sect_rec = dict, t = int):
    return costing_sect_rec[pcmvf.PC_COSTING_SECT_COSTS_CS][t]

def set_PC_costing_sect_costs_CS(costing_sect_rec = dict, t = int, value = float):
    costing_sect_rec[pcmvf.PC_COSTING_SECT_COSTS_CS][t] = value

###

def get_PC_costing_section_subsect_recs(costing_sect_rec = dict):
    return costing_sect_rec[pcmvf.PC_COSTING_SECT_SUBSECT_RECORDS]

###

def get_PC_costing_sect_price_elasticity_PPLI(costing_sect_rec = dict, col_curr_ID = int):
    return costing_sect_rec[pcmvf.PC_COSTING_SECT_PRICE_ELASTICITY_PPLI][col_curr_ID - 1]

def set_PC_costing_sect_price_elasticity_PPLI(costing_sect_rec = dict, col_curr_ID = int, value = float):
    costing_sect_rec[pcmvf.PC_COSTING_SECT_PRICE_ELASTICITY_PPLI][col_curr_ID - 1] = value

###

def get_PC_costing_sect_income_elasticity_PPLI(costing_sect_rec = dict, col_curr_ID = int):
    return costing_sect_rec[pcmvf.PC_COSTING_SECT_INCOME_ELASTICITY_PPLI][col_curr_ID - 1]

def set_PC_costing_sect_income_elasticity_PPLI(costing_sect_rec = dict, col_curr_ID = int, value = float):
    costing_sect_rec[pcmvf.PC_COSTING_SECT_INCOME_ELASTICITY_PPLI][col_curr_ID - 1] = value

###

def get_PC_costing_sect_price_income_only_PPLI(costing_sect_rec = dict, col_curr_ID = int):
    return costing_sect_rec[pcmvf.PC_COSTING_SECT_PRICE_INCOME_ONLY_PPLI][col_curr_ID - 1]

def set_PC_costing_sect_price_income_only_PPLI(costing_sect_rec = dict, col_curr_ID = int, value = int):
    costing_sect_rec[pcmvf.PC_COSTING_SECT_PRICE_INCOME_ONLY_PPLI][col_curr_ID - 1] = value

###

def get_PC_costing_sect_non_price_measures_PPLI(costing_sect_rec = dict, col_curr_ID = int):
    return costing_sect_rec[pcmvf.PC_COSTING_SECT_NON_PRICE_MEASURES_PPLI][col_curr_ID - 1]

def set_PC_costing_sect_non_price_measures_PPLI(costing_sect_rec = dict, col_curr_ID = int, value = int):
    costing_sect_rec[pcmvf.PC_COSTING_SECT_NON_PRICE_MEASURES_PPLI][col_curr_ID - 1] = value

###

def get_PC_costing_sect_all_MPOWER_PPLI(costing_sect_rec = dict, col_curr_ID = int):
    return costing_sect_rec[pcmvf.PC_COSTING_SECT_ALL_MPOWER_PPLI][col_curr_ID - 1]

def set_PC_costing_sect_all_MPOWER_PPLI(costing_sect_rec = dict, col_curr_ID = int, value = int):
    costing_sect_rec[pcmvf.PC_COSTING_SECT_ALL_MPOWER_PPLI][col_curr_ID - 1] = value

###

def get_PC_costing_sect_tax_entry_mode_PPLI(costing_sect_rec = dict):
    return costing_sect_rec[pcmvf.PC_COSTING_SECT_TAX_ENTRY_MODE_PPLI]

def set_PC_costing_sect_tax_entry_mode_PPLI(costing_sect_rec = dict, value = int):
    costing_sect_rec[pcmvf.PC_COSTING_SECT_TAX_ENTRY_MODE_PPLI] = value

###

def get_PC_costing_sect_real_retail_price_PPLI(costing_sect_rec = dict, year_endpoint_curr_ID = int):
    return costing_sect_rec[pcmvf.PC_COSTING_SECT_REAL_RETAIL_PRICE_PPLI][year_endpoint_curr_ID - 1]

def set_PC_costing_sect_real_retail_price_PPLI(costing_sect_rec = dict, year_endpoint_curr_ID = int, value = int):
    costing_sect_rec[pcmvf.PC_COSTING_SECT_REAL_RETAIL_PRICE_PPLI][year_endpoint_curr_ID - 1] = value

###

def get_PC_costing_sect_excise_share_PPLI(costing_sect_rec = dict, year_endpoint_curr_ID = int):
    return costing_sect_rec[pcmvf.PC_COSTING_SECT_EXCISE_SHARE_PPLI][year_endpoint_curr_ID - 1]

def set_PC_costing_sect_excise_share_PPLI(costing_sect_rec = dict, year_endpoint_curr_ID = int, value = int):
    costing_sect_rec[pcmvf.PC_COSTING_SECT_EXCISE_SHARE_PPLI][year_endpoint_curr_ID - 1] = value

###

def get_PC_costing_sect_tax_share_PPLI(costing_sect_rec = dict, year_endpoint_curr_ID = int):
    return costing_sect_rec[pcmvf.PC_COSTING_SECT_TAX_SHARE_PPLI][year_endpoint_curr_ID - 1]

def set_PC_costing_sect_tax_share_PPLI(costing_sect_rec = dict, year_endpoint_curr_ID = int, value = int):
    costing_sect_rec[pcmvf.PC_COSTING_SECT_TAX_SHARE_PPLI][year_endpoint_curr_ID - 1] = value

###

def get_PC_costing_sect_real_exise_per_pack_PPLI(costing_sect_rec = dict, year_endpoint_curr_ID = int):
    return costing_sect_rec[pcmvf.PC_COSTING_SECT_REAL_EXCISE_PER_PACK_PPLI][year_endpoint_curr_ID - 1]

def set_PC_costing_sect_real_excise_per_pack_PPLI(costing_sect_rec = dict, year_endpoint_curr_ID = int, value = int):
    costing_sect_rec[pcmvf.PC_COSTING_SECT_REAL_EXCISE_PER_PACK_PPLI][year_endpoint_curr_ID - 1] = value

###

def get_PC_costing_sect_real_tax_per_pack_PPLI(costing_sect_rec = dict, year_endpoint_curr_ID = int):
    return costing_sect_rec[pcmvf.PC_COSTING_SECT_REAL_TAX_PER_PACK_PPLI][year_endpoint_curr_ID - 1]

def set_PC_costing_sect_real_tax_per_pack_PPLI(costing_sect_rec = dict, year_endpoint_curr_ID = int, value = int):
    costing_sect_rec[pcmvf.PC_COSTING_SECT_REAL_TAX_PER_PACK_PPLI][year_endpoint_curr_ID - 1] = value

###

def get_PC_costing_sect_real_industry_price_PPLI(costing_sect_rec = dict, year_endpoint_curr_ID = int):
    return costing_sect_rec[pcmvf.PC_COSTING_SECT_REAL_INDUSTRY_PRICE_PPLI][year_endpoint_curr_ID - 1]

def set_PC_costing_sect_real_industry_price_PPLI(costing_sect_rec = dict, year_endpoint_curr_ID = int, value = int):
    costing_sect_rec[pcmvf.PC_COSTING_SECT_REAL_INDUSTRY_PRICE_PPLI][year_endpoint_curr_ID - 1] = value

###

def get_PC_costing_sect_tax_adjust_consump_PPLI(costing_sect_rec = dict, year_endpoint_curr_ID = int):
    return costing_sect_rec[pcmvf.PC_COSTING_SECT_TAX_ADJUST_CONSUMP_PPLI][year_endpoint_curr_ID - 1]

def set_PC_costing_sect_tax_adjust_consump_PPLI(costing_sect_rec = dict, year_endpoint_curr_ID = int, value = int):
    costing_sect_rec[pcmvf.PC_COSTING_SECT_TAX_ADJUST_CONSUMP_PPLI][year_endpoint_curr_ID - 1] = value

###

def get_PC_costing_sect_excise_revenue_PPLI(costing_sect_rec = dict, year_endpoint_curr_ID = int):
    return costing_sect_rec[pcmvf.PC_COSTING_SECT_EXCISE_REVENUE_PPLI][year_endpoint_curr_ID - 1]

def set_PC_costing_sect_excise_revenue_PPLI(costing_sect_rec = dict, year_endpoint_curr_ID = int, value = int):
    costing_sect_rec[pcmvf.PC_COSTING_SECT_EXCISE_REVENUE_PPLI][year_endpoint_curr_ID - 1] = value

###

def get_PC_costing_sect_tax_revenue_PPLI(costing_sect_rec = dict, year_endpoint_curr_ID = int):
    return costing_sect_rec[pcmvf.PC_COSTING_SECT_TAX_REVENUE_PPLI][year_endpoint_curr_ID - 1]

def set_PC_costing_sect_tax_revenue_PPLI(costing_sect_rec = dict, year_endpoint_curr_ID = int, value = int):
    costing_sect_rec[pcmvf.PC_COSTING_SECT_TAX_REVENUE_PPLI][year_endpoint_curr_ID - 1] = value

###

def get_PC_costing_sect_usage_rate_PPLI(costing_sect_rec = dict, year_endpoint_curr_ID = int):
    return costing_sect_rec[pcmvf.PC_COSTING_SECT_USAGE_RATE_PPLI][year_endpoint_curr_ID - 1]

def set_PC_costing_sect_usage_rate_PPLI(costing_sect_rec = dict, year_endpoint_curr_ID = int, value = float):
    costing_sect_rec[pcmvf.PC_COSTING_SECT_USAGE_RATE_PPLI][year_endpoint_curr_ID - 1] = value

###

def get_PC_costing_sect_num_users_PPLI(costing_sect_rec = dict, year_endpoint_curr_ID = int):
    return costing_sect_rec[pcmvf.PC_COSTING_SECT_NUM_USERS][year_endpoint_curr_ID - 1]

def set_PC_costing_sect_num_users_PPLI(costing_sect_rec = dict, year_endpoint_curr_ID = int, value = int):
    costing_sect_rec[pcmvf.PC_COSTING_SECT_NUM_USERS][year_endpoint_curr_ID - 1] = value

#######################################################################################################
#                                                                                                     #
#                                           Costing subsections                                       #
#                                                                                                     #
#######################################################################################################

def get_PC_costing_subsect_rec(costing_sect_records: list, area_type_ID: str, area_ID: str, costing_sect_ID: str, ID: str):
    costing_sect_rec = get_PC_costing_sect_rec(costing_sect_records, area_type_ID, area_ID, costing_sect_ID)
    if costing_sect_rec == gbc.GB_NOT_FOUND: return gbc.GB_NOT_FOUND
    costing_subsect_records = get_PC_costing_section_subsect_recs(costing_sect_rec)

    costing_subsect_recs = [costing_subsect_rec for costing_subsect_rec in costing_subsect_records if \
        (costing_subsect_rec[pcmvf.PC_COSTING_SUBSECT_ID] == ID)]
    return costing_subsect_recs[0] if len(costing_subsect_recs) > 0 else gbc.GB_NOT_FOUND
   
###
   
def get_PC_costing_subsect_idx(costing_sect_records = list, area_type_ID = str, area_ID = str, costing_sect_ID = str, ID = str):
    costing_sect_rec = get_PC_costing_sect_rec(costing_sect_records, area_type_ID, area_ID, costing_sect_ID)
    costing_subsect_records = get_PC_costing_section_subsect_recs(costing_sect_rec)

    indices = [idx for (idx, costing_subsect_rec) in enumerate(costing_subsect_records) if \
        (costing_subsect_rec[pcmvf.PC_COSTING_SUBSECT_ID] == ID)]
    return indices[0] if len(indices) > 0 else gbc.GB_NOT_FOUND

###
   
def get_PC_costing_subsect_name(costing_subsect_rec = dict):
    return costing_subsect_rec[pcmvf.PC_COSTING_SUBSECT_NAME]

def set_PC_costing_subsect_name(costing_subsect_rec = dict, value = str):
    costing_subsect_rec[pcmvf.PC_COSTING_SUBSECT_NAME] = value
 
###

def get_PC_costing_subsect_string_constant(costing_subsect_rec = dict):
    return costing_subsect_rec[pcmvf.PC_COSTING_SUBSECT_STR_CONST]

def set_PC_costing_subsect_string_constant(costing_subsect_rec = dict, value = str):
    costing_subsect_rec[pcmvf.PC_COSTING_SUBSECT_STR_CONST] = value
 
###

def get_PC_costing_subsect_ID(costing_subsect_rec = dict):
    return costing_subsect_rec[pcmvf.PC_COSTING_SUBSECT_ID]

def set_PC_costing_subsect_ID(costing_subsect_rec = dict, value = str):
    costing_subsect_rec[pcmvf.PC_COSTING_SUBSECT_ID] = value

###

def get_PC_costing_subsect_custom(costing_subsect_rec = dict):
    return costing_subsect_rec[pcmvf.PC_COSTING_SUBSECT_CUSTOM]

def set_PC_costing_subsect_custom(costing_subsect_rec = dict, value = bool):
    costing_subsect_rec[pcmvf.PC_COSTING_SUBSECT_CUSTOM] = value

###

def get_PC_costing_subsect_PPLI_phase_intensity(costing_subsect_rec = dict, row_type_curr_ID = int, t = int):
    return costing_subsect_rec[pcmvf.PC_COSTING_SUBSECT_PHASE_INTENSITY_VALUES_PPLI][row_type_curr_ID - 1][t]

def set_PC_costing_subsect_PPLI_phase_intensity(costing_subsect_rec = dict, row_type_curr_ID = int, t = int, value = float):
    costing_subsect_rec[pcmvf.PC_COSTING_SUBSECT_PHASE_INTENSITY_VALUES_PPLI][row_type_curr_ID - 1][t] = value

###

def get_PC_costing_subsect_raise_taxes_price_PPLI(costing_subsect_rec = dict, t = int):
    return costing_subsect_rec[pcmvf.PC_COSTING_SUBSECT_RAISE_TAXES_PRICE_PPLI][t]

def set_PC_costing_subsect_raise_taxes_price_PPLI(costing_subsect_rec = dict, t = int, value = int):
    costing_subsect_rec[pcmvf.PC_COSTING_SUBSECT_RAISE_TAXES_PRICE_PPLI][t] = value

###

def get_PC_costing_subsect_raise_taxes_excise_share_PPLI(costing_subsect_rec = dict, t = int):
    return costing_subsect_rec[pcmvf.PC_COSTING_SUBSECT_RAISE_TAXES_EXCISE_SHARE_PPLI][t]

def set_PC_costing_subsect_raise_taxes_excise_share_PPLI(costing_subsect_rec = dict, t = int, value = int):
    costing_subsect_rec[pcmvf.PC_COSTING_SUBSECT_RAISE_TAXES_EXCISE_SHARE_PPLI][t] = value

###

def get_PC_costing_subsect_raise_taxes_tax_share_PPLI(costing_subsect_rec = dict, t = int):
    return costing_subsect_rec[pcmvf.PC_COSTING_SUBSECT_RAISE_TAXES_TAX_SHARE_PPLI][t]

def set_PC_costing_subsect_raise_taxes_tax_share_PPLI(costing_subsect_rec = dict, t = int, value = int):
    costing_subsect_rec[pcmvf.PC_COSTING_SUBSECT_RAISE_TAXES_TAX_SHARE_PPLI][t] = value

###

def get_PC_costing_subsect_enter_total_inputs_per_admin_reg_year_PPLI(costing_subsect_rec = dict):
    return costing_subsect_rec[pcmvf.PC_COSTING_SUBSECT_ENTER_TOTAL_INPUTS_PER_ADMIN_REG_YEAR_PPLI]

def set_PC_costing_subsect_enter_total_inputs_per_admin_reg_year_PPLI(costing_subsect_rec = dict, value = bool):
    costing_subsect_rec[pcmvf.PC_COSTING_SUBSECT_ENTER_TOTAL_INPUTS_PER_ADMIN_REG_YEAR_PPLI] = value

#######################################################################################################
#                                                                                                     #
#                                           Activities                                                #
#                                                                                                     #
#######################################################################################################

def add_PC_activity_rec(activity_records = list, value = dict):
    activity_records.append(value)

def get_PC_act_rec(act_records = list, area_type_ID = str, area_ID = str, costing_sect_ID = str, costing_subsect_ID = str, ID = str):
    act_recs = [act_rec for act_rec in act_records if \
        ((act_rec[pcmvf.PC_ACT_AREA_TYPE_ID] == area_type_ID) \
        and (act_rec[pcmvf.PC_ACT_AREA_ID] == area_ID) \
        and (act_rec[pcmvf.PC_ACT_COSTING_SECT_ID] == costing_sect_ID) \
        and (act_rec[pcmvf.PC_ACT_COSTING_SUBSECT_ID] == costing_subsect_ID) \
        and (act_rec[pcmvf.PC_ACT_ID] == ID))]
    return act_recs[0] if len(act_recs) > 0 else gbc.GB_NOT_FOUND
   
###
   
def get_PC_act_idx(act_records = list, area_type_ID = str, area_ID = str, costing_sect_ID = str, costing_subsect_ID = str, ID = str):
    indices = [idx for (idx, act_rec) in enumerate(act_records) if \
        ((act_rec[pcmvf.PC_ACT_AREA_TYPE_ID] == area_type_ID) \
        and (act_rec[pcmvf.PC_ACT_AREA_ID] == area_ID) \
        and (act_rec[pcmvf.PC_ACT_COSTING_SECT_ID] == costing_sect_ID) \
        and (act_rec[pcmvf.PC_ACT_COSTING_SUBSECT_ID] == costing_subsect_ID) \
        and (act_rec[pcmvf.PC_ACT_ID] == ID))]
    return indices[0] if len(indices) > 0 else gbc.GB_NOT_FOUND
   
###
   
def get_PC_act_name(act_rec = dict):
    return act_rec[pcmvf.PC_ACT_NAME]

def set_PC_act_name(act_rec = dict, value = str):
    act_rec[pcmvf.PC_ACT_NAME] = value

###

def get_PC_act_string_constant(act_rec = dict):
    return act_rec[pcmvf.PC_ACT_STR_CONST]

def set_PC_act_string_constant(act_rec = dict, value = str):
    act_rec[pcmvf.PC_ACT_STR_CONST] = value

###

def get_PC_act_ID(act_rec = dict):
    return act_rec[pcmvf.PC_ACT_ID]

def set_PC_act_ID(act_rec = dict, value = str):
    act_rec[pcmvf.PC_ACT_ID] = value

###

def get_PC_act_custom(act_rec = dict):
    return act_rec[pcmvf.PC_ACT_CUSTOM]

def set_PC_act_custom(act_rec = dict, value = str):
    act_rec[pcmvf.PC_ACT_CUSTOM] = value

def get_PC_act_recs_for_costing_subsect(act_records = list, area_type_ID = str, area_ID = str, costing_sect_ID = str, costing_subsect_ID = str):
    act_recs = [act_rec for act_rec in act_records if ((act_rec[pcmvf.PC_ACT_AREA_TYPE_ID] == area_type_ID) \
        and (act_rec[pcmvf.PC_ACT_AREA_ID] == area_ID) and (act_rec[pcmvf.PC_ACT_COSTING_SECT_ID] == costing_sect_ID) \
        and (act_rec[pcmvf.PC_ACT_COSTING_SUBSECT_ID] == costing_subsect_ID))]
    return act_recs

###

def remove_PC_act_rec(act_records: list, area_type_ID: str, area_ID: str, costing_sect_ID: str, costing_subsect_ID: str, act_ID: str):
    act_recs = [act_rec for act_rec in act_records if not ((act_rec[pcmvf.PC_ACT_AREA_TYPE_ID] == area_type_ID) \
        and (act_rec[pcmvf.PC_ACT_AREA_ID] == area_ID) and (act_rec[pcmvf.PC_ACT_COSTING_SECT_ID] == costing_sect_ID) \
        and (act_rec[pcmvf.PC_ACT_COSTING_SUBSECT_ID] == costing_subsect_ID) and (act_rec[pcmvf.PC_ACT_ID] == act_ID))]
    return act_recs

###

# Remove all activities for the specified costing section
def remove_PC_acts_for_costing_sect(act_records = list, area_type_ID = str, area_ID = str, costing_sect_ID = str):
    act_recs = [act_rec for act_rec in act_records if not ((act_rec[pcmvf.PC_ACT_AREA_TYPE_ID] == area_type_ID) \
        and (act_rec[pcmvf.PC_ACT_AREA_ID] == area_ID) and (act_rec[pcmvf.PC_ACT_COSTING_SECT_ID] == costing_sect_ID))]
    return act_recs

###

# Remove all activities for the specified costing subsection
def remove_PC_acts_for_costing_subsect(act_records = list, area_type_ID = str, area_ID = str, costing_sect_ID = str, costing_subsect_ID = str):
    act_recs = [act_rec for act_rec in act_records if not ((act_rec[pcmvf.PC_ACT_AREA_TYPE_ID] == area_type_ID) \
        and (act_rec[pcmvf.PC_ACT_AREA_ID] == area_ID) and (act_rec[pcmvf.PC_ACT_COSTING_SECT_ID] == costing_sect_ID) \
        and (act_rec[pcmvf.PC_ACT_COSTING_SUBSECT_ID] == costing_subsect_ID))]
    return act_recs

#######################################################################################################
#                                                                                                     #
#                                           Activity line items                                       #
#                                                                                                     #
#######################################################################################################

def get_PC_num_ALIs(ALI_records = list):
    return len(ALI_records)

def get_PC_ALI_rec(ALI_records = list, area_type_ID = str, area_ID = str, costing_sect_ID = str, costing_subsect_ID = str, act_ID = str, cost_input_ID = str):
    ALI_recs = [ALI_rec for ALI_rec in ALI_records if \
        ((ALI_rec[pcmvf.PC_ALI_AREA_TYPE_ID] == area_type_ID) \
        and (ALI_rec[pcmvf.PC_ALI_AREA_ID] == area_ID) \
        and (ALI_rec[pcmvf.PC_ALI_COSTING_SECT_ID] == costing_sect_ID) \
        and (ALI_rec[pcmvf.PC_ALI_COSTING_SUBSECT_ID] == costing_subsect_ID) \
        and (ALI_rec[pcmvf.PC_ALI_ACT_ID] == act_ID) \
        and (ALI_rec[pcmvf.PC_ALI_COST_INPUT_ID] == cost_input_ID))]
    return ALI_recs[0] if len(ALI_recs) > 0 else gbc.GB_NOT_FOUND
   
###
   
def get_PC_ALI_idx(ALI_records = list, area_type_ID = str, area_ID = str, costing_sect_ID = str, costing_subsect_ID = str, act_ID = str, cost_input_ID = str):
    indices = [idx for (idx, ALI_rec) in enumerate(ALI_records) if \
        ((ALI_rec[pcmvf.PC_ALI_AREA_TYPE_ID] == area_type_ID) \
        and (ALI_rec[pcmvf.PC_ALI_AREA_ID] == area_ID) \
        and (ALI_rec[pcmvf.PC_ALI_COSTING_SECT_ID] == costing_sect_ID) \
        and (ALI_rec[pcmvf.PC_ALI_COSTING_SUBSECT_ID] == costing_subsect_ID) \
        and (ALI_rec[pcmvf.PC_ALI_ACT_ID] == act_ID) \
        and (ALI_rec[pcmvf.PC_ALI_COST_INPUT_ID] == cost_input_ID))]
    return indices[0] if len(indices) > 0 else gbc.GB_NOT_FOUND

###

def get_PC_ALI_area_type_ID(ALI_rec = dict):
    return ALI_rec[pcmvf.PC_ALI_AREA_TYPE_ID]

def set_PC_ALI_area_type_ID(ALI_rec = dict, value = int):
    ALI_rec[pcmvf.PC_ALI_AREA_TYPE_ID] = value

###

def get_PC_ALI_area_ID(ALI_rec = dict):
    return ALI_rec[pcmvf.PC_ALI_AREA_ID]

def set_PC_ALI_area_ID(ALI_rec = dict, value = int):
    ALI_rec[pcmvf.PC_ALI_AREA_ID] = value


###

def get_PC_ALI_costing_sect_ID(ALI_rec = dict):
    return ALI_rec[pcmvf.PC_ALI_COSTING_SECT_ID]

def set_PC_ALI_costing_sect_ID(ALI_rec = dict, value = int):
    ALI_rec[pcmvf.PC_ALI_COSTING_SECT_ID] = value

###

def get_PC_ALI_costing_subsect_ID(ALI_rec = dict):
    return ALI_rec[pcmvf.PC_ALI_COSTING_SUBSECT_ID]

def set_PC_ALI_costing_subsect_ID(ALI_rec = dict, value = int):
    ALI_rec[pcmvf.PC_ALI_COSTING_SUBSECT_ID] = value

###

def get_PC_ALI_act_ID(ALI_rec = dict):
    return ALI_rec[pcmvf.PC_ALI_ACT_ID]

def set_PC_ALI_act_ID(ALI_rec = dict, value = int):
    ALI_rec[pcmvf.PC_ALI_ACT_ID] = value

###

def get_PC_ALI_cost_input_ID(ALI_rec = dict):
    return ALI_rec[pcmvf.PC_ALI_COST_INPUT_ID]

def set_PC_ALI_cost_input_ID(ALI_rec = dict, value = int):
    ALI_rec[pcmvf.PC_ALI_COST_INPUT_ID] = value

###

def get_PC_ALI_num_units(ALI_rec = dict):
    return ALI_rec[pcmvf.PC_ALI_NUM_UNITS]

def set_PC_ALI_num_units(ALI_rec = dict, value = int):
    ALI_rec[pcmvf.PC_ALI_NUM_UNITS] = value

###

def get_PC_ALI_num_units_PPLI(ALI_rec = dict, admin_level_curr_ID = int):
    return ALI_rec[pcmvf.PC_ALI_NUM_UNITS][admin_level_curr_ID - 1]

def set_PC_ALI_num_units_PPLI(ALI_rec = dict, admin_level_curr_ID = int, value = int):
    ALI_rec[pcmvf.PC_ALI_NUM_UNITS][admin_level_curr_ID - 1] = value

###

def get_PC_ALI_duration(ALI_rec = dict):
    return ALI_rec[pcmvf.PC_ALI_DURATION]

def set_PC_ALI_duration(ALI_rec = dict, value = int):
    ALI_rec[pcmvf.PC_ALI_DURATION] = value

###

def get_PC_ALI_duration_PPLI(ALI_rec = dict, admin_level_curr_ID = int):
    return ALI_rec[pcmvf.PC_ALI_DURATION][admin_level_curr_ID - 1]

def set_PC_ALI_duration_PPLI(ALI_rec = dict, admin_level_curr_ID = int, value = int):
    ALI_rec[pcmvf.PC_ALI_DURATION][admin_level_curr_ID - 1] = value

###

def get_PC_ALI_frequency(ALI_rec = dict, t = int):
    return ALI_rec[pcmvf.PC_ALI_FREQUENCY][t]

def set_PC_ALI_frequency(ALI_rec = dict, t = int, value = int):
    ALI_rec[pcmvf.PC_ALI_FREQUENCY][t] = value

###

def get_PC_ALI_quantity(ALI_rec = dict, ALI_set_curr_ID = int, admin_level_curr_ID = int, t = int):
    return ALI_rec[pcmvf.PC_ALI_QUANTITY_PER_ADMIN_REG_YEAR_PPLI][ALI_set_curr_ID - 1][admin_level_curr_ID - 1][t]

def set_PC_ALI_quantity(ALI_rec = dict, ALI_set_curr_ID = int, admin_level_curr_ID = int, t = int, value = int):
    ALI_rec[pcmvf.PC_ALI_QUANTITY_PER_ADMIN_REG_YEAR_PPLI][ALI_set_curr_ID - 1][admin_level_curr_ID - 1][t] = value

###

def add_PC_ALI_rec(ALI_records = list, value = dict):
    ALI_records.append(value)

###

# Return all activity line items for the specified costing section
def get_PC_ALIs_for_costing_sect(ALI_records = list, area_type_ID = str, area_ID = str, costing_sect_ID = str):
    ALI_recs = [ALI_rec for ALI_rec in ALI_records if ((ALI_rec[pcmvf.PC_ALI_AREA_TYPE_ID] == area_type_ID) and \
        (ALI_rec[pcmvf.PC_ALI_AREA_ID] == area_ID) and (ALI_rec[pcmvf.PC_ALI_COSTING_SECT_ID] == costing_sect_ID))]
    return ALI_recs

###

# Return all activity line items for the specified costing subsection
def get_PC_ALIs_for_costing_subsect(ALI_records = list, area_type_ID = str, area_ID = str, costing_sect_ID = str, costing_subsect_ID = str):
    ALI_recs = [ALI_rec for ALI_rec in ALI_records if (
        (ALI_rec[pcmvf.PC_ALI_AREA_TYPE_ID] == area_type_ID) 
        and (ALI_rec[pcmvf.PC_ALI_AREA_ID] == area_ID) 
        and (ALI_rec[pcmvf.PC_ALI_COSTING_SECT_ID] == costing_sect_ID) 
        and (ALI_rec[pcmvf.PC_ALI_COSTING_SUBSECT_ID] == costing_subsect_ID)
    )]
    return ALI_recs

###

# Return all activity line items for the specified activity
def get_PC_ALIs_for_act(ALI_records = list, area_type_ID = str, area_ID = str, costing_sect_ID = str, costing_subsect_ID = str, act_ID = str):
    ALI_recs = [ALI_rec for ALI_rec in ALI_records if ((ALI_rec[pcmvf.PC_ALI_AREA_TYPE_ID] == area_type_ID) \
        and (ALI_rec[pcmvf.PC_ALI_AREA_ID] == area_ID) and (ALI_rec[pcmvf.PC_ALI_COSTING_SECT_ID] == costing_sect_ID) \
        and (ALI_rec[pcmvf.PC_ALI_COSTING_SUBSECT_ID] == costing_subsect_ID) and (ALI_rec[pcmvf.PC_ALI_ACT_ID] == act_ID))]
    return ALI_recs

###

# Return all activity line items for the specified activity and cost category.
def get_PC_ALIs_for_act_and_cost_cat(ALI_records = list, cost_input_records = list, area_type_ID = str, area_ID = str, costing_sect_ID = str, costing_subsect_ID = str, act_ID = str, cost_cat_ID = str):
    ALI_recs = [ALI_rec for ALI_rec in ALI_records if (
        (ALI_rec[pcmvf.PC_ALI_AREA_TYPE_ID] == area_type_ID)
        and (ALI_rec[pcmvf.PC_ALI_AREA_ID] == area_ID) 
        and (ALI_rec[pcmvf.PC_ALI_COSTING_SECT_ID] == costing_sect_ID) 
        and (ALI_rec[pcmvf.PC_ALI_COSTING_SUBSECT_ID] == costing_subsect_ID) 
        and (ALI_rec[pcmvf.PC_ALI_ACT_ID] == act_ID) 
        and (get_PC_cost_input_cat_ID(get_PC_cost_input_rec(cost_input_records, ALI_rec[pcmvf.PC_ALI_COST_INPUT_ID])) == cost_cat_ID)
    )]
    return ALI_recs

###

# Remove all activity line items for the specified costing section
def remove_PC_ALIs_for_costing_sect(ALI_records: list, area_type_ID: str, area_ID: str, costing_sect_ID: str):
    ALI_recs = [ALI_rec for ALI_rec in ALI_records if not ((ALI_rec[pcmvf.PC_ALI_AREA_TYPE_ID] == area_type_ID) and \
        (ALI_rec[pcmvf.PC_ALI_AREA_ID] == area_ID) and (ALI_rec[pcmvf.PC_ALI_COSTING_SECT_ID] == costing_sect_ID))]
    return ALI_recs

###

# Remove all activity line items for the specified costing subsection
def remove_PC_ALIs_for_costing_subsect(ALI_records: list, area_type_ID: str, area_ID: str, costing_sect_ID: str, costing_subsect_ID: str):
    ALI_recs = [ALI_rec for ALI_rec in ALI_records if not ((ALI_rec[pcmvf.PC_ALI_AREA_TYPE_ID] == area_type_ID) \
        and (ALI_rec[pcmvf.PC_ALI_AREA_ID] == area_ID) and (ALI_rec[pcmvf.PC_ALI_COSTING_SECT_ID] == costing_sect_ID) \
        and (ALI_rec[pcmvf.PC_ALI_COSTING_SUBSECT_ID] == costing_subsect_ID))]
    return ALI_recs

# Remove all activity line items for the specified activity
def remove_PC_ALIs_for_act(ALI_records = list, area_type_ID = str, area_ID = str, costing_sect_ID = str, costing_subsect_ID = str, act_ID = str):
    ALI_recs = [ALI_rec for ALI_rec in ALI_records if (
        not ((ALI_rec[pcmvf.PC_ALI_AREA_TYPE_ID] == area_type_ID) 
        and (ALI_rec[pcmvf.PC_ALI_AREA_ID] == area_ID) 
        and (ALI_rec[pcmvf.PC_ALI_COSTING_SECT_ID] == costing_sect_ID) 
        and (ALI_rec[pcmvf.PC_ALI_COSTING_SUBSECT_ID] == costing_subsect_ID) 
        and (ALI_rec[pcmvf.PC_ALI_ACT_ID] == act_ID))
    )]
    return ALI_recs

# Remove all activity line items associated with the cost input
def remove_PC_ALIs_for_cost_input(ALI_records = list, cost_input_ID = str):
    ALI_recs = [ALI_rec for ALI_rec in ALI_records if not ((ALI_rec[pcmvf.PC_ALI_COST_INPUT_ID] == cost_input_ID))]
    return ALI_recs

def remove_PC_ALI_rec(ALI_records: list, area_type_ID: str, area_ID: str, costing_sect_ID: str, costing_subsect_ID: str, act_ID: str, cost_input_ID: str):
    ALI_recs = [ALI_rec for ALI_rec in ALI_records if not (
        (ALI_rec[pcmvf.PC_ALI_AREA_TYPE_ID] == area_type_ID)
        and (ALI_rec[pcmvf.PC_ALI_AREA_ID] == area_ID)
        and (ALI_rec[pcmvf.PC_ALI_COSTING_SECT_ID] == costing_sect_ID)
        and (ALI_rec[pcmvf.PC_ALI_COSTING_SUBSECT_ID] == costing_subsect_ID)
        and (ALI_rec[pcmvf.PC_ALI_ACT_ID] == act_ID)
        and (ALI_rec[pcmvf.PC_ALI_COST_INPUT_ID] == cost_input_ID)
    )]
    return ALI_recs

#######################################################################################################
#                                                                                                     #
#                                           Results                                                   #
#                                                                                                     #
#######################################################################################################

def get_PC_costs_by_sect(costs_by_sect_records = list, area_type_ID = str, area_ID = str, costing_sect_ID = str):
    recs = [rec for rec in costs_by_sect_records if (
        (rec[pcmvf.PC_F_AREA_TYPE_ID] == area_type_ID) 
        and (rec[pcmvf.PC_F_AREA_ID] == area_ID) 
        and (rec[pcmvf.PC_F_COSTING_SECT_ID] == costing_sect_ID) 
    )]
    # There will be either one or zero entries.
    return recs[0][pcmvf.PC_F_VALUE] if len(recs) > 0 else gbc.GB_NOT_FOUND

###
 
def get_PC_costs_by_subsect(costs_by_subsect_records = list, area_type_ID = str, area_ID = str, costing_sect_ID = str, costing_subsect_ID = str):
    recs = [rec for rec in costs_by_subsect_records if (
        (rec[pcmvf.PC_F_AREA_TYPE_ID] == area_type_ID) 
        and (rec[pcmvf.PC_F_AREA_ID] == area_ID) 
        and (rec[pcmvf.PC_F_COSTING_SECT_ID] == costing_sect_ID) 
        and (rec[pcmvf.PC_F_COSTING_SUBSECT_ID] == costing_subsect_ID) 
    )]
    # There will be either one or zero entries.
    return recs[0][pcmvf.PC_F_VALUE] if len(recs) > 0 else gbc.GB_NOT_FOUND

###

def get_PC_costs_by_act(costs_by_act_records = list, area_type_ID = str, area_ID = str, costing_sect_ID = str, costing_subsect_ID = str, act_ID = str):
    recs = [rec for rec in costs_by_act_records if (
        (rec[pcmvf.PC_F_AREA_TYPE_ID] == area_type_ID) 
        and (rec[pcmvf.PC_F_AREA_ID] == area_ID) 
        and (rec[pcmvf.PC_F_COSTING_SECT_ID] == costing_sect_ID) 
        and (rec[pcmvf.PC_F_COSTING_SUBSECT_ID] == costing_subsect_ID) 
        and (rec[pcmvf.PC_F_ACT_ID] == act_ID)
    )]
    # There will be either one or zero entries.
    return recs[0][pcmvf.PC_F_VALUE] if len(recs) > 0 else gbc.GB_NOT_FOUND