from datetime import date
import math as math

import SpectrumCommon.Const.GB as gbc
import SpectrumCommon.Const.PJ.PJNTags as pjmvt
import SpectrumCommon.Modvars.GB.GBUtil as gbu

import SpectrumCommon.Const.BG.BGConstLink as bgcl
import SpectrumCommon.Const.BG.BGConst as bgc
import SpectrumCommon.Const.BG.BGTags as bgmvt
import SpectrumCommon.Modvars.BG.BGReadDatabases as bgrd

def init_modvars(country_ID, first_year, final_year, extra):
    '''
        Initializes Budget Mapping MVs for new IHT projections.

            Parameters:
                countryID (string):  Ex: BEN for Benin.

                first_year (int): First year selected by user.

                final_year (int): Final year selected by user. 

                extra (dict): Any other fields.  
 
            Returns:
                mod_vars_rec (dict): MVs.
    '''

    # Needed to initialize IC indicators 
    deliv_chan_records_mv = extra[bgcl.BG_IH_DELIV_CHAN_RECORDS_TAG]
    interv_records_mv = extra[bgcl.BG_IC_INTERV_RECORDS_TAG]
    drug_supply_records_mv = extra[bgcl.BG_IC_DRUG_SUPPLY_RECORDS_TAG]
    facility_records_mv = extra[bgcl.BG_IS_FACILITY_TYPE_RECORDS_TAG]
    staff_types_mv = extra[bgcl.BG_HW_STAFF_TYPE_RECORDS_TAG]

    # Needed for various costing modes.
    IHT_costing_on = extra[gbc.GB_IHT_ON] if gbc.GB_IHT_ON in extra else False
    TB_costing_on = extra[gbc.GB_TB_COSTING_ON] if gbc.GB_TB_COSTING_ON in extra else False
    LiST_costing_on = extra[gbc.GB_LIST_COSTING_ON] if gbc.GB_LIST_COSTING_ON in extra else False
    costing_mode_mod_vars = {
        pjmvt.GB_IHTOnTag       : IHT_costing_on,
        pjmvt.GB_TBCostingOnTag : TB_costing_on,
        pjmvt.GB_LCOnTag        : LiST_costing_on,
    }
    costing_mode = gbu.get_costing_mode(costing_mode_mod_vars)
    # active_modules = extra[gbc.GB_MODULES]

    # file_list = GB_file_list(environment, gbc.GB_IC_CONTAINER, '')
    # for i, file_name in enumerate(file_list):
    #     log(file_name)

    num_years_inputs = final_year - first_year + 1 
    # num_years_outputs = final_year - first_year + 1
    # num_deliv_chan_IC = iccl.IC_IH_NUM_DEFAULT_DELIV_CHANS_COSTED + icc.IC_NUM_DELIV_CHANS
    # num_prog_areas = icmvul.IC_get_IH_num_prog_areas(prog_area_records_mv)

    #######################################################################################################
    #                                                                                                     #
    #                                       Inputs                                                        #
    #                                                                                                     #
    #######################################################################################################

    budget_DB = bgrd.BG_load_budget_DB()
    fund_framework_DB = bgrd.BG_load_funding_framework_DB()
    fund_source_DB = bgrd.BG_load_funding_source_DB()

    value_bool_False = False
    value_bool_True = True
    value_int = 0
    value_flt = 0.0
    value_date = date.today().strftime("%B %d, %Y"),   
    value_list = []

    #######################################################################################################
    #                                                                                                     #
    #                                       Inputs                                                        #
    #                                                                                                     #
    #######################################################################################################

    fund_framework_records = bgrd.BG_init_fund_framework_records(fund_framework_DB, costing_mode)
    fund_source_records = bgrd.BG_init_fund_source_records(fund_source_DB, costing_mode)

    budget_records = []
    budget_cat_records = []
    ind_records_IC = []
    ind_records_PC = []
    ind_records_IS = []
    ind_records_HW = []
    ind_records_HS = []
    ind_records_GV = []
    ind_records_HF = []

    # Put back in if for some reason we want to load certain budgets (or all default budgets; hopefully not) by default.
    #  = bgrd.BG_init_budgets_complete(
    #     costing_mode, IHT_plan_type, num_years_inputs, fund_framework_records, fund_source_records, deliv_chan_records_mv, 
    #     interv_records_mv, drug_supply_records_mv)

    # Meta data
    default_budget_list_meta = bgrd.BG_init_default_budget_list_meta(budget_DB, costing_mode)
    default_fund_fw_list_meta = bgrd.BG_init_default_fund_framework_list_meta(fund_framework_DB, costing_mode)

    mod_vars_rec = {
        # Inputs / pre-result / calculated
		
        bgmvt.BG_VERSION_TAG                              : bgc.BG_FILE_VERSION_1_0,
        bgmvt.BG_BUDGET_RECORDS_TAG                       : budget_records,
        bgmvt.BG_INDICATOR_RECORDS_IC_TAG                 : ind_records_IC,
        bgmvt.BG_INDICATOR_RECORDS_PC_TAG                 : ind_records_PC,
        bgmvt.BG_INDICATOR_RECORDS_IS_TAG                 : ind_records_IS,
        bgmvt.BG_INDICATOR_RECORDS_HW_TAG                 : ind_records_HW,
        bgmvt.BG_INDICATOR_RECORDS_HS_TAG                 : ind_records_HS,
        bgmvt.BG_INDICATOR_RECORDS_GV_TAG                 : ind_records_GV,
        bgmvt.BG_INDICATOR_RECORDS_HF_TAG                 : ind_records_HF,
        bgmvt.BG_BUDGET_CAT_RECORDS_TAG                   : budget_cat_records,
        bgmvt.BG_BUDGET_CAT_SHARE_RECORDS_IC_TAG          : [],
        bgmvt.BG_BUDGET_CAT_SHARE_RECORDS_PC_TAG          : [],
        bgmvt.BG_BUDGET_CAT_SHARE_RECORDS_IS_TAG          : [],
        bgmvt.BG_BUDGET_CAT_SHARE_RECORDS_HW_TAG          : [],
        bgmvt.BG_BUDGET_CAT_SHARE_RECORDS_HS_TAG          : [],
        bgmvt.BG_BUDGET_CAT_SHARE_RECORDS_GV_TAG          : [],
        bgmvt.BG_BUDGET_CAT_SHARE_RECORDS_HF_TAG          : [],
        bgmvt.BG_FUND_FW_RECORDS_TAG                      : fund_framework_records,
        bgmvt.BG_FUND_SOURCE_RECORDS_TAG                  : fund_source_records,
        bgmvt.BG_FUND_SOURCE_SHARE_RECORDS_IC_TAG         : [],
        bgmvt.BG_FUND_SOURCE_SHARE_RECORDS_PC_TAG         : [],
        bgmvt.BG_FUND_SOURCE_SHARE_RECORDS_IS_TAG         : [],  
        bgmvt.BG_FUND_SOURCE_SHARE_RECORDS_HW_TAG         : [],  
        bgmvt.BG_FUND_SOURCE_SHARE_RECORDS_HS_TAG         : [],  
        bgmvt.BG_FUND_SOURCE_SHARE_RECORDS_GV_TAG         : [],
        bgmvt.BG_FUND_SOURCE_SHARE_RECORDS_HF_TAG         : [],  
        bgmvt.BG_USING_SAME_FUND_MAPPINGS_ALL_BUDGETS_TAG : False,
        bgmvt.BG_QUICK_MAP_RECORDS_TAG                    : [],

        #icmvt.IC_DATA_CHANGED_TAG_V1                        : value_bool_False, 

        #icmvt.IC_RES_NUM_SERVICES_BY_DELIV_CHAN_TAG_V1      : icmvd.IC_init_interv_deliv_chan_all_year_arr(num_intervs, num_deliv_chan_IC, num_years_outputs, 0.0).tolist(),
        
        bgmvt.BG_RES_TOTAL_COSTS_BY_BUDGET_CAT_TAG             : [],
        bgmvt.BG_RES_TOTAL_COSTS_BY_FUND_SOURCE_TAG            : [],
        bgmvt.BG_RES_TOTAL_COSTS_BY_BUDGET_CAT_FUND_SOURCE_TAG : [],

        bgmvt.BG_DEFAULT_BUDGET_LIST_META_TAG             : default_budget_list_meta,
        bgmvt.BG_DEFAULT_FUND_FW_LIST_META_TAG            : default_fund_fw_list_meta,
    }

    #Debugging
    #with open('C:\Proj\BGSampleFile.JSON', 'w') as f:
    #    json.dump(mod_vars_dict, f)

    return mod_vars_rec