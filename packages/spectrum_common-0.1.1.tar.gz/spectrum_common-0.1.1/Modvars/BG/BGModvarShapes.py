from SpectrumCommon.Const.BG import *
from SpectrumCommon.Modvars.GB.GBDefs import *


BG_modvar_shapes = {
        # bgmvt.BG_VERSION_TAG                              : bgc.BG_FILE_VERSION_1_0,
        # bgmvt.BG_BUDGET_RECORDS_TAG                       : budget_records,
        # bgmvt.BG_INDICATOR_RECORDS_IC_TAG                 : ind_records_IC,
        # bgmvt.BG_INDICATOR_RECORDS_PC_TAG                 : ind_records_PC,
        # bgmvt.BG_INDICATOR_RECORDS_IS_TAG                 : ind_records_IS,
        # bgmvt.BG_INDICATOR_RECORDS_HW_TAG                 : ind_records_HW,
        # bgmvt.BG_INDICATOR_RECORDS_HS_TAG                 : ind_records_HS,
        # bgmvt.BG_INDICATOR_RECORDS_GV_TAG                 : ind_records_GV,
        # bgmvt.BG_INDICATOR_RECORDS_HF_TAG                 : ind_records_HF,
        # bgmvt.BG_BUDGET_CAT_RECORDS_TAG                   : budget_cat_records,
        # bgmvt.BG_BUDGET_CAT_SHARE_RECORDS_IC_TAG          : [],
        # bgmvt.BG_BUDGET_CAT_SHARE_RECORDS_PC_TAG          : [],
        # bgmvt.BG_BUDGET_CAT_SHARE_RECORDS_IS_TAG          : [],
        # bgmvt.BG_BUDGET_CAT_SHARE_RECORDS_HW_TAG          : [],
        # bgmvt.BG_BUDGET_CAT_SHARE_RECORDS_HS_TAG          : [],
        # bgmvt.BG_BUDGET_CAT_SHARE_RECORDS_GV_TAG          : [],
        # bgmvt.BG_BUDGET_CAT_SHARE_RECORDS_HF_TAG          : [],
        # bgmvt.BG_FUND_FW_RECORDS_TAG                      : fund_framework_records,
        # bgmvt.BG_FUND_SOURCE_RECORDS_TAG                  : fund_source_records,
        # bgmvt.BG_FUND_SOURCE_SHARE_RECORDS_IC_TAG         : [],
        # bgmvt.BG_FUND_SOURCE_SHARE_RECORDS_PC_TAG         : [],
        # bgmvt.BG_FUND_SOURCE_SHARE_RECORDS_IS_TAG         : [],  
        # bgmvt.BG_FUND_SOURCE_SHARE_RECORDS_HW_TAG         : [],  
        # bgmvt.BG_FUND_SOURCE_SHARE_RECORDS_HS_TAG         : [],  
        # bgmvt.BG_FUND_SOURCE_SHARE_RECORDS_GV_TAG         : [],
        # bgmvt.BG_FUND_SOURCE_SHARE_RECORDS_HF_TAG         : [],  
        # bgmvt.BG_USING_SAME_FUND_MAPPINGS_ALL_BUDGETS_TAG : False,
        # bgmvt.BG_QUICK_MAP_RECORDS_TAG                    : [],

        # #icmvt.IC_DATA_CHANGED_TAG_V1                        : value_bool_False, 

        # #icmvt.IC_RES_NUM_SERVICES_BY_DELIV_CHAN_TAG_V1      : icmvd.IC_init_interv_deliv_chan_all_year_arr(num_intervs, num_deliv_chan_IC, num_years_outputs, 0.0).tolist(),
        
        # bgmvt.BG_RES_TOTAL_COSTS_BY_BUDGET_CAT_TAG             : [],
        # bgmvt.BG_RES_TOTAL_COSTS_BY_FUND_SOURCE_TAG            : [],
        # bgmvt.BG_RES_TOTAL_COSTS_BY_BUDGET_CAT_FUND_SOURCE_TAG : [],

        # bgmvt.BG_DEFAULT_BUDGET_LIST_META_TAG             : default_budget_list_meta,
        # bgmvt.BG_DEFAULT_FUND_FW_LIST_META_TAG            : default_fund_fw_list_meta,
}