import SpectrumCommon.Const.GB.GBConst as gbc

import SpectrumCommon.Const.BG.BGConst as bgc
import SpectrumCommon.Const.BG.BGModVarFields as bgmvf

#######################################################################################################
#                                                                                                     #
#                                       Budgets                                                       #
#                                                                                                     #
#######################################################################################################

def get_BG_budget_rec(budget_records = list, ID = str):
    budget_recs = [budget_rec for budget_rec in budget_records if budget_rec[bgmvf.BG_BUDGET_ID] == ID]
    return budget_recs[0] if len(budget_recs) > 0 else gbc.GB_NOT_FOUND

def get_BG_budget_idx(budget_records = list, ID = str):
    indices = [idx for (idx, budget_rec) in enumerate(budget_records) if budget_rec[bgmvf.BG_BUDGET_ID] == ID]
    return indices[0] if len(indices) > 0 else gbc.GB_NOT_FOUND

def get_BG_budget_idx_and_rec(budget_records = list, ID = str):
    indices_and_recs = [(idx, budget_rec) for (idx, budget_rec) in enumerate(budget_records) if (budget_rec[bgmvf.BG_BUDGET_ID] == ID)]
    return indices_and_recs[0] if len(indices_and_recs) > 0 else (gbc.GB_NOT_FOUND, {})

def get_BG_num_budgets(budget_records = list):
    return len(budget_records)

def add_BG_budget_rec(budget_records = list, value = dict):
    budget_records.append(value)

def remove_BG_budget_rec(budget_records = list, ID = str):
    budget_recs = [budget_rec for budget_rec in budget_records if not (budget_rec[bgmvf.BG_BUDGET_ID] == ID)]
    return budget_recs

def get_BG_budget_ID(budget_rec = dict):
    return budget_rec[bgmvf.BG_BUDGET_ID]

def set_BG_budget_ID(budget_rec = dict, value = str):
    budget_rec[bgmvf.BG_BUDGET_ID] = value

def get_BG_budget_name(budget_rec = dict):
    return budget_rec[bgmvf.BG_BUDGET_NAME]

def set_BG_budget_name(budget_rec = dict, value = str):
    budget_rec[bgmvf.BG_BUDGET_NAME] = value

def get_BG_budget_custom(budget_rec = dict):
    return budget_rec[bgmvf.BG_BUDGET_CUSTOM]

def set_BG_budget_custom(budget_rec = dict, value = str):
    budget_rec[bgmvf.BG_BUDGET_CUSTOM] = value

def get_BG_budget_str_const(budget_rec = dict):
    return budget_rec[bgmvf.BG_BUDGET_STR_CONST]

def set_BG_budget_str_const(budget_rec = dict, value = str):
    budget_rec[bgmvf.BG_BUDGET_STR_CONST] = value

def get_BG_budget_fund_framework(budget_rec = dict):
    return budget_rec[bgmvf.BG_BUDGET_FW_ID]

def set_BG_budget_fund_framework(budget_rec = dict, fund_framework_ID = str):
    budget_rec[bgmvf.BG_BUDGET_FW_ID] = fund_framework_ID

def get_BG_budget_aggr_deliv_chan_IC(budget_rec = dict):
    return budget_rec[bgmvf.BG_BUDGET_AGGR_DELIV_CHANS_IC]

def set_BG_budget_aggr_deliv_chan_IC(budget_rec = dict, value = bool):
    budget_rec[bgmvf.BG_BUDGET_AGGR_DELIV_CHANS_IC] = value

def get_BG_budget_cost_interv_or_drugs_supplies_IC(budget_rec = dict):
    return budget_rec[bgmvf.BG_BUDGET_COST_INTERVS_DRUGS_SUPPLIES_IC]

def set_BG_budget_cost_interv_or_drugs_supplies_IC(budget_rec = dict, value = int):
    budget_rec[bgmvf.BG_BUDGET_COST_INTERVS_DRUGS_SUPPLIES_IC] = value

def get_BG_budget_cost_cat_IC_ID(budget_rec = dict):
    return budget_rec[bgmvf.BG_COST_CAT_IC_ID]

def set_BG_budget_cost_cat_IC_ID(budget_rec = dict, value = int):
    budget_rec[bgmvf.BG_COST_CAT_IC_ID] = value

def get_BG_budget_aggr_inserv_train_all_staff_HW(budget_rec = dict):
    return budget_rec[bgmvf.BG_BUDGET_AGGR_INSERV_TRAIN_ALL_STAFF_HW]

def set_BG_budget_aggr_inserv_train_all_staff_HW(budget_rec = dict, value = bool):
    budget_rec[bgmvf.BG_BUDGET_AGGR_INSERV_TRAIN_ALL_STAFF_HW] = value

def get_BG_budget_aggr_preserv_train_all_staff_HW(budget_rec = dict):
    return budget_rec[bgmvf.BG_BUDGET_AGGR_PRESERV_TRAIN_ALL_STAFF_HW]

def set_BG_budget_aggr_preserv_train_all_staff_HW(budget_rec = dict, value = bool):
    budget_rec[bgmvf.BG_BUDGET_AGGR_PRESERV_TRAIN_ALL_STAFF_HW] = value

def get_BG_budget_aggr_total_compens_all_staff_HW(budget_rec = dict, staff_level_curr_ID = int, compens_type_curr_ID = int):
    return budget_rec[bgmvf.BG_BUDGET_AGGR_TOTAL_COMPENS_ALL_STAFF_HW][staff_level_curr_ID - 1][compens_type_curr_ID - 1]

def set_BG_budget_aggr_total_compens_all_staff_HW(budget_rec = dict, staff_level_curr_ID = int, compens_type_curr_ID = int, value = bool):
    budget_rec[bgmvf.BG_BUDGET_AGGR_TOTAL_COMPENS_ALL_STAFF_HW][staff_level_curr_ID - 1][compens_type_curr_ID - 1] = value

def get_BG_budget_aggr_staff_inserv_train_all_staff_lev_HW(budget_rec = dict, staff_type_curr_ID = int):
    return budget_rec[bgmvf.BG_BUDGET_AGGR_STAFF_INSERV_TRAIN_ALL_STAFF_LEV_HW][staff_type_curr_ID - 1]

def set_BG_budget_aggr_staff_inserv_train_all_staff_lev_HW(budget_rec = dict, staff_type_curr_ID = int, value = bool):
    budget_rec[bgmvf.BG_BUDGET_AGGR_STAFF_INSERV_TRAIN_ALL_STAFF_LEV_HW][staff_type_curr_ID - 1] = value

def get_BG_budget_aggr_staff_lev_inserv_train_all_staff_HW(budget_rec = dict, staff_level_curr_ID = int):
    return budget_rec[bgmvf.BG_BUDGET_AGGR_STAFF_LEV_INSERV_TRAIN_ALL_STAFF_HW][staff_level_curr_ID - 1]

def set_BG_budget_aggr_staff_lev_inserv_train_all_staff_HW(budget_rec = dict, staff_level_curr_ID = int, value = bool):
    budget_rec[bgmvf.BG_BUDGET_AGGR_STAFF_LEV_INSERV_TRAIN_ALL_STAFF_HW][staff_level_curr_ID - 1] = value

def get_BG_budget_aggr_total_compens_staff_lev_compens_type_HW(budget_rec = dict, staff_type_curr_ID = int):
    return budget_rec[bgmvf.BG_BUDGET_AGGR_TOTAL_COMPENS_STAFF_LEV_COMPENS_TYPE_HW][staff_type_curr_ID - 1]

def set_BG_budget_aggr_total_compens_staff_lev_compens_type_HW(budget_rec = dict, staff_type_curr_ID = int, value = bool):
    budget_rec[bgmvf.BG_BUDGET_AGGR_TOTAL_COMPENS_STAFF_LEV_COMPENS_TYPE_HW][staff_type_curr_ID - 1] = value

def get_BG_budget_cost_level_HW(budget_rec = dict):
    return budget_rec[bgmvf.BG_BUDGET_COST_LEVEL_HW_ID]

def set_BG_budget_cost_level_HW(budget_rec = dict, value = int):
    budget_rec[bgmvf.BG_BUDGET_COST_LEVEL_HW_ID] = value

def get_BG_budget_group_ind_aggr_IS(budget_rec = dict, ind_ID = int):
    return ind_ID in budget_rec[bgmvf.BG_BUDGET_GROUP_IND_AGGR_SET_IS]

def set_BG_budget_group_ind_aggr_IS(budget_rec = dict, ind_ID = int, include = bool):
    if include:
        budget_rec[bgmvf.BG_BUDGET_GROUP_IND_AGGR_SET_IS].append(ind_ID)
    else:
        budget_rec[bgmvf.BG_BUDGET_GROUP_IND_AGGR_SET_IS].remove(ind_ID)

def get_BG_budget_facility_ind_aggr_IS(budget_rec = dict, ind_ID = int):
    return ind_ID in budget_rec[bgmvf.BG_BUDGET_FACILITY_IND_AGGR_SET_IS]

def set_BG_budget_facility_ind_aggr_IS(budget_rec = dict, ind_ID = int, include = bool):
    if include:
        budget_rec[bgmvf.BG_BUDGET_FACILITY_IND_AGGR_SET_IS].append(ind_ID)
    else:
        budget_rec[bgmvf.BG_BUDGET_FACILITY_IND_AGGR_SET_IS].remove(ind_ID)

def get_BG_budget_cost_level_IS(budget_rec = dict):
    return budget_rec[bgmvf.BG_BUDGET_COST_LEVEL_IS_ID]

def set_BG_budget_cost_level_IS(budget_rec = dict, value = int):
    budget_rec[bgmvf.BG_BUDGET_COST_LEVEL_IS_ID] = value

def get_BG_budget_cost_level_PC(budget_rec = dict):
    return budget_rec[bgmvf.BG_BUDGET_COST_LEVEL_PC_ID]

def set_BG_budget_cost_level_PC(budget_rec = dict, value = int):
    budget_rec[bgmvf.BG_BUDGET_COST_LEVEL_PC_ID] = value

def get_BG_budget_cost_level_HS(budget_rec = dict):
    return budget_rec[bgmvf.BG_BUDGET_COST_LEVEL_HS_ID]

def set_BG_budget_cost_level_HS(budget_rec = dict, value = int):
    budget_rec[bgmvf.BG_BUDGET_COST_LEVEL_HS_ID] = value

def get_BG_budget_cost_level_LG(budget_rec = dict):
    return budget_rec[bgmvf.BG_BUDGET_COST_LEVEL_LG_ID]

def set_BG_budget_cost_level_LG(budget_rec = dict, value = int):
    budget_rec[bgmvf.BG_BUDGET_COST_LEVEL_LG_ID] = value

def get_BG_budget_cost_level_GV(budget_rec = dict):
    return budget_rec[bgmvf.BG_BUDGET_COST_LEVEL_GV_ID]

def set_BG_budget_cost_level_GV(budget_rec = dict, value = int):
    budget_rec[bgmvf.BG_BUDGET_COST_LEVEL_GV_ID] = value

def get_BG_budget_cost_level_HF(budget_rec = dict):
    return budget_rec[bgmvf.BG_BUDGET_COST_LEVEL_HF_ID]

def set_BG_budget_cost_level_HF(budget_rec = dict, value = int):
    budget_rec[bgmvf.BG_BUDGET_COST_LEVEL_HF_ID] = value

def get_BG_budget_active(budget_rec: dict):
    return budget_rec[bgmvf.BG_BUDGET_ACTIVE]

def set_BG_budget_active(budget_rec: dict, value: bool):
    budget_rec[bgmvf.BG_BUDGET_ACTIVE] = value

#######################################################################################################
#                                                                                                     #
#                                       Budget categories                                             #
#                                                                                                     #
#######################################################################################################

def get_BG_num_budget_cats(budget_cat_records = list):
    return len(budget_cat_records)

def get_BG_num_budget_cat_records_for_budget(budget_cat_records = list, budget_ID = str):
    budget_cat_recs_reduced = [budget_cat_rec for budget_cat_rec in budget_cat_records if budget_cat_rec[bgmvf.BG_BUDGET_CAT_BUDGET_ID] == budget_ID]
    return len(budget_cat_recs_reduced)

def get_BG_budget_cat_records(budget_cat_records = list, budget_ID = str):
    budget_cat_recs_reduced = [budget_cat_rec for budget_cat_rec in budget_cat_records if budget_cat_rec[bgmvf.BG_BUDGET_CAT_BUDGET_ID] == budget_ID]
    return budget_cat_recs_reduced

# Remove all budget categories for a budget.
def remove_BG_budget_cat_records(budget_cat_records = list, budget_ID = str):
    budget_cat_recs = [budget_cat_rec for budget_cat_rec in budget_cat_records if not (budget_cat_rec[bgmvf.BG_BUDGET_CAT_BUDGET_ID] == budget_ID)]
    return budget_cat_recs

# Remove a specific budget category.
def remove_BG_budget_cat_rec(budget_cat_records = list, budget_ID = str, ID = str):
    budget_cat_recs = [budget_cat_rec for budget_cat_rec in budget_cat_records if 
        (not ((budget_cat_rec[bgmvf.BG_BUDGET_CAT_BUDGET_ID] == budget_ID) and 
        (budget_cat_rec[bgmvf.BG_BUDGET_CAT_ID] == ID)))]
    return budget_cat_recs

# Change the budget of a budget category. Useful when copying a budget.
def change_BG_budget_cat_budget_ID(budget_cat_records = list, budget_ID = str):
    budget_cat_recs = [set_BG_budget_cat_budget_ID(budget_cat_rec, budget_ID) for budget_cat_rec in budget_cat_records]
    return budget_cat_recs

# Returns the index of the budget category record within the budget category list.
def get_BG_budget_cat_idx(budget_cat_records = list, budget_ID = str, ID = str):
    indices = [idx for (idx, budget_cat_rec) in enumerate(budget_cat_records) if  
        ((budget_cat_rec[bgmvf.BG_BUDGET_CAT_BUDGET_ID] == budget_ID) and (budget_cat_rec[bgmvf.BG_BUDGET_CAT_ID] == ID))]
    return indices[0] if len(indices) > 0 else gbc.GB_NOT_FOUND

def get_BG_budget_cat_rec(budget_cat_records = list, budget_ID = str, ID = str):
    budget_cat_recs = [budget_cat_rec for budget_cat_rec in budget_cat_records if 
        ((budget_cat_rec[bgmvf.BG_BUDGET_CAT_BUDGET_ID] == budget_ID) and (budget_cat_rec[bgmvf.BG_BUDGET_CAT_ID] == ID))]
    return budget_cat_recs[0] if len(budget_cat_recs) > 0 else gbc.GB_NOT_FOUND

def get_BG_budget_cat_budget_ID(budget_cat_rec = dict):
    return budget_cat_rec[bgmvf.BG_BUDGET_CAT_BUDGET_ID]

def set_BG_budget_cat_budget_ID(budget_cat_rec = dict, value = str):
    budget_cat_rec[bgmvf.BG_BUDGET_CAT_BUDGET_ID] = value
    # Unconventional, but allows us to use in list comprehensions to set values.
    return budget_cat_rec

def get_BG_budget_cat_ID(budget_cat_rec = dict):
    return budget_cat_rec[bgmvf.BG_BUDGET_CAT_ID]

def set_BG_budget_cat_ID(budget_cat_rec = dict, value = str):
    budget_cat_rec[bgmvf.BG_BUDGET_CAT_ID] = value

def get_BG_budget_cat_custom(budget_cat_rec = dict):
    return budget_cat_rec[bgmvf.BG_BUDGET_CAT_CUSTOM]

def set_BG_budget_cat_custom(budget_cat_rec = dict, value = str):
    budget_cat_rec[bgmvf.BG_BUDGET_CAT_CUSTOM] = value

def get_BG_budget_cat_name(budget_cat_rec = dict):
    return budget_cat_rec[bgmvf.BG_BUDGET_CAT_NAME]

def set_BG_budget_cat_name(budget_cat_rec = dict, value = str):
    budget_cat_rec[bgmvf.BG_BUDGET_CAT_NAME] = value

def get_BG_budget_cat_string_constant(budget_cat_rec = dict):
    return budget_cat_rec[bgmvf.BG_BUDGET_CAT_STR_CONST]

def set_BG_budget_cat_string_constant(budget_cat_rec = dict, value = str):
    budget_cat_rec[bgmvf.BG_BUDGET_CAT_STR_CONST] = value

#######################################################################################################
#                                                                                                     #
#                                       Funding frameworks                                            #
#                                                                                                     #
#######################################################################################################

def get_BG_fund_framework_rec(fund_framework_records = list, ID = str):
    fund_framework_recs = [fund_framework_rec for fund_framework_rec in fund_framework_records if fund_framework_rec[bgmvf.BG_FUND_FW_ID] == ID]
    return fund_framework_recs[0] if len(fund_framework_recs) > 0 else gbc.GB_NOT_FOUND

def get_BG_fund_framework_idx(fund_framework_records = list, ID = str):
    indices = [idx for (idx, fund_framework_rec) in enumerate(fund_framework_records) if fund_framework_rec[bgmvf.BG_FUND_FW_ID] == ID]
    return indices[0] if len(indices) > 0 else gbc.GB_NOT_FOUND

def get_BG_num_fund_frameworks(fund_framework_records = list):
    return len(fund_framework_records)

def add_BG_fund_framework_rec(fund_framework_records = list, value = dict):
    fund_framework_records.append(value)

def remove_BG_fund_framework_rec(fund_framework_records = list, ID = str):
    fund_framework_recs = [fund_framework_rec for fund_framework_rec in fund_framework_records if not (fund_framework_rec[bgmvf.BG_FUND_FW_ID] == ID)]
    return fund_framework_recs

def get_BG_fund_framework_ID_from_idx(fund_framework_records = list, idx = int):
    return fund_framework_records[idx][bgmvf.BG_FUND_FW_ID]

def set_BG_fund_framework_ID(fund_framework_rec = dict, value = str):
    fund_framework_rec[bgmvf.BG_FUND_FW_ID] = value

def get_BG_fund_framework_ID(fund_framework_rec = dict):
    return fund_framework_rec[bgmvf.BG_FUND_FW_ID]

def get_BG_fund_framework_name(fund_framework_rec = dict):
    return fund_framework_rec[bgmvf.BG_FUND_FW_NAME]

def set_BG_fund_framework_name(fund_framework_rec = dict, value = str):
    fund_framework_rec[bgmvf.BG_FUND_FW_NAME] = value

def get_BG_fund_framework_custom(fund_framework_rec = dict):
    return fund_framework_rec[bgmvf.BG_FUND_FW_CUSTOM]

def set_BG_fund_framework_custom(fund_framework_rec = dict, value = str):
    fund_framework_rec[bgmvf.BG_FUND_FW_CUSTOM] = value

def get_BG_fund_framework_str_const(fund_framework_rec = dict):
    return fund_framework_rec[bgmvf.BG_FUND_FW_STR_CONSTANT]

def set_BG_fund_framework_str_const(fund_framework_rec = dict, value = str):
    fund_framework_rec[bgmvf.BG_FUND_FW_STR_CONSTANT] = value

#######################################################################################################
#                                                                                                     #
#                                       Funding sources                                               #
#                                                                                                     #
#######################################################################################################

def get_BG_num_fund_sources(fund_source_records = list):
    return len(fund_source_records)

def get_BG_num_fund_source_records_for_framework(fund_source_records = list, fund_framework_ID = str):
    fund_source_recs_reduced = [fund_source_rec for fund_source_rec in fund_source_records if fund_source_rec[bgmvf.BG_FUND_SOURCE_FW_ID] == fund_framework_ID]
    return len(fund_source_recs_reduced)

def get_BG_fund_source_records(fund_source_records = list, fund_framework_ID = str):
    fund_source_recs_reduced = [fund_source_rec for fund_source_rec in fund_source_records if fund_source_rec[bgmvf.BG_FUND_SOURCE_FW_ID] == fund_framework_ID]
    return fund_source_recs_reduced

# Remove all budget categories for a budget.
def remove_BG_funding_source_records(fund_source_records = list, fund_framework_ID = str):
    fund_source_recs = [fund_source_rec for fund_source_rec in fund_source_records if not (fund_source_rec[bgmvf.BG_FUND_SOURCE_FW_ID] == fund_framework_ID)]
    return fund_source_recs

# Remove a specific funding source.
def remove_BG_funding_source_rec(funding_source_records = list, fund_framework_ID = str, ID = str):
    funding_source_recs = [funding_source_rec for funding_source_rec in funding_source_records if 
        (not ((funding_source_rec[bgmvf.BG_FUND_SOURCE_FW_ID] == fund_framework_ID) and 
        (funding_source_rec[bgmvf.BG_FUND_SOURCE_ID] == ID)))]
    return funding_source_recs

def get_BG_funding_source_idx(funding_source_records = list, fund_framework_ID = str, ID = str):
    indices = [idx for (idx, funding_source_rec) in enumerate(funding_source_records) if  
        ((funding_source_rec[bgmvf.BG_FUND_SOURCE_FW_ID] == fund_framework_ID) and (funding_source_rec[bgmvf.BG_FUND_SOURCE_ID] == ID))]
    return indices[0] if len(indices) > 0 else gbc.GB_NOT_FOUND

def get_BG_funding_source_rec(funding_source_records = list, fund_framework_ID = str, ID = str):
    funding_source_recs = [funding_source_rec for funding_source_rec in funding_source_records if 
        ((funding_source_rec[bgmvf.BG_FUND_SOURCE_FW_ID] == fund_framework_ID) and (funding_source_rec[bgmvf.BG_FUND_SOURCE_ID] == ID))]
    return funding_source_recs[0] if len(funding_source_recs) > 0 else gbc.GB_NOT_FOUND

def get_BG_funding_source_framework_ID(funding_source_rec = dict):
    return funding_source_rec[bgmvf.BG_FUND_SOURCE_FW_ID]

def set_BG_funding_source_framework_ID(funding_source_rec = dict, value = str):
    funding_source_rec[bgmvf.BG_FUND_SOURCE_FW_ID] = value
    # Unconventional, but allows us to use in list comprehensions to set values.
    return funding_source_rec

def get_BG_funding_source_custom(funding_source_rec = dict):
    return funding_source_rec[bgmvf.BG_FUND_SOURCE_CUSTOM]

def set_BG_funding_source_custom(funding_source_rec = dict, value = str):
    funding_source_rec[bgmvf.BG_FUND_SOURCE_CUSTOM] = value

def get_BG_funding_source_name(funding_source_rec = dict):
    return funding_source_rec[bgmvf.BG_FUND_SOURCE_NAME]

def set_BG_funding_source_name(funding_source_rec = dict, value = str):
    funding_source_rec[bgmvf.BG_FUND_SOURCE_NAME] = value

def get_BG_fund_source_ID(fund_source_rec = dict):
    return fund_source_rec[bgmvf.BG_FUND_SOURCE_ID]

def set_BG_fund_source_ID(fund_source_rec = dict, value = str):
    fund_source_rec[bgmvf.BG_FUND_SOURCE_ID] = value

#######################################################################################################
#                                                                                                     #
#                                       Indicators - All                                              #
#                                                                                                     #
#######################################################################################################

def get_BG_ind_records_for_budget(ind_records = list, budget_ID = str):
    ind_recs_reduced = [ind_rec for ind_rec in ind_records if ind_rec[bgmvf.BG_IND_BUDGET_ID] == budget_ID]
    return ind_recs_reduced

def get_BG_ind_records_other_budgets(ind_records = list, budget_ID = str):
    ind_recs_reduced = [ind_rec for ind_rec in ind_records if ind_rec[bgmvf.BG_IND_BUDGET_ID] != budget_ID]
    return ind_recs_reduced

def get_BG_ind_records_all_budgets(ind_records = list, ind_type_ID = int, ind_ID = int, isAggregate = bool):
    # Options:
    #   1. use zip(*list_of_tuples) to unzip the list of tuples. 
    #   2. list_1 = [tuple[0] for tuple in list_of_tuples],
    #      list_2 = tuple[1] for tuple in list_of_tuples]
    # 
    #   List comprehensions are signficantly faster, so we're using those.
    # ind_recs_indices, ind_recs_reduced = zip(*[(i, ind_rec) for i, ind_rec in enumerate(ind_records) if (
    #     (ind_rec[bgmvf.BG_IND_TYPE_ID] == ind_type_ID)
    #     and (ind_rec[bgmvf.BG_IND_ID] == ind_ID)
    #     and (ind_rec[bgmvf.BG_IND_IS_AGGREGATE] == isAggregate))])
    list_of_tuples = [(i, ind_rec) for i, ind_rec in enumerate(ind_records) if (
        (ind_rec[bgmvf.BG_IND_TYPE_ID] == ind_type_ID)
        and (ind_rec[bgmvf.BG_IND_ID] == ind_ID)
        # and (ind_rec[bgmvf.BG_IND_IS_AGGREGATE] == isAggregate)
    )]
    ind_recs_indices = [tuple[0] for tuple in list_of_tuples]
    ind_recs_reduced = [tuple[1] for tuple in list_of_tuples]
    return ind_recs_indices, ind_recs_reduced

def remove_BG_ind_records(ind_records = list, budget_ID = str):
    ind_recs = [ind_rec for ind_rec in ind_records if not (ind_rec[bgmvf.BG_IND_BUDGET_ID] == budget_ID)]
    return ind_recs

# Change the budget of a indicator. Useful when copying a budget.
def change_BG_ind_budget_ID(ind_records = list, budget_ID = str):
    ind_recs = [set_BG_ind_budget_ID(ind_rec, budget_ID) for ind_rec in ind_records]
    return ind_recs

def reset_BG_ind_funding_sources_unalloc(ind_rec = dict, fund_framework_ID = str):
    return add_BG_ind_fund_source_by_framework_dict_entry(ind_rec, fund_framework_ID, str(bgc.BG_FS_UNALLOCATED_MST_ID))

def get_BG_ind_name(ind_rec = dict):
    return ind_rec[bgmvf.BG_IND_NAME]

def set_BG_ind_name(ind_rec = dict, value = str):
    ind_rec[bgmvf.BG_IND_NAME] = value
    # Unconventional, but allows us to use in list comprehensions to set values.
    return ind_rec

def get_BG_ind_type_ID(ind_rec = dict):
    return ind_rec[bgmvf.BG_IND_TYPE_ID]

def set_BG_ind_type_ID(ind_rec = dict, value = str):
    ind_rec[bgmvf.BG_IND_TYPE_ID] = value
    return ind_rec

def get_BG_ind_ID(ind_rec = dict):
    return ind_rec[bgmvf.BG_IND_ID]

def set_BG_ind_ID(ind_rec = dict, value = str):
    ind_rec[bgmvf.BG_IND_ID] = value
    return ind_rec

def get_BG_ind_mod_ID(ind_rec = dict):
    return ind_rec[bgmvf.BG_IND_MOD_ID]

def set_BG_ind_mod_ID(ind_rec = dict, value = str):
    ind_rec[bgmvf.BG_IND_MOD_ID] = value
    return ind_rec

def get_BG_ind_budget_ID(ind_rec = dict):
    return ind_rec[bgmvf.BG_IND_BUDGET_ID]

def set_BG_ind_budget_ID(ind_rec = dict, value = str):
    ind_rec[bgmvf.BG_IND_BUDGET_ID] = value
    # Unconventional, but allows us to use in list comprehensions to set values.
    return ind_rec

# def get_BG_ind_is_aggregate(ind_rec = dict):
#     return ind_rec[bgmvf.BG_IND_IS_AGGREGATE]

# def set_BG_ind_is_aggregate(ind_rec = dict, value = str):
#     ind_rec[bgmvf.BG_IND_IS_AGGREGATE] = value

def get_BG_ind_budget_cat_ID(ind_rec = dict):
    return ind_rec[bgmvf.BG_IND_BUDGET_CAT_ID]

def set_BG_ind_budget_cat_ID(ind_rec = dict, value = str):
    ind_rec[bgmvf.BG_IND_BUDGET_CAT_ID] = value
    # Unconventional, but allows us to use in list comprehensions to set values.
    return ind_rec

# def get_BG_ind_fund_fw_ID(ind_rec = dict):
#     return ind_rec[bgmvf.BG_IND_FUND_FW_ID]

# def set_BG_ind_fund_fw_ID(ind_rec = dict, value = str):
#     ind_rec[bgmvf.BG_IND_FUND_FW_ID] = value

def get_BG_ind_fund_source_ID(ind_rec = dict, fund_framework_ID = str):
    return ind_rec[bgmvf.BG_IND_FUND_SOURCE_BY_FRAMEWORK][fund_framework_ID]

# def set_BG_ind_fund_source_ID(ind_rec = dict, value = str):
#     ind_rec[bgmvf.BG_IND_FUND_SOURCE_ID] = value
#     # Unconventional, but allows us to use in list comprehensions to set values.
#     return ind_rec

def get_BG_ind_fund_source_by_framework_dict(ind_rec = dict):
    return ind_rec[bgmvf.BG_IND_FUND_SOURCE_BY_FRAMEWORK]

def set_BG_ind_fund_source_by_framework_dict(ind_rec = dict, value = dict):
    ind_rec[bgmvf.BG_IND_FUND_SOURCE_BY_FRAMEWORK] = value
    # Unconventional, but allows us to use in list comprehensions to set values.
    return ind_rec

# Either adds a new funding framework / funding source pair or changes an existing funding source.
def add_BG_ind_fund_source_by_framework_dict_entry(ind_rec = dict, fund_framework_ID = str, fund_source_ID = str):
    ind_rec[bgmvf.BG_IND_FUND_SOURCE_BY_FRAMEWORK][fund_framework_ID] = fund_source_ID
    # Unconventional, but allows us to use in list comprehensions to set values.
    return ind_rec

def remove_BG_ind_fund_source_by_framework_dict_entry(ind_rec = dict, fund_framework_ID = str):
    ind_rec[bgmvf.BG_IND_FUND_SOURCE_BY_FRAMEWORK].pop(fund_framework_ID, None)
    # Unconventional, but allows us to use in list comprehensions to set values.
    return ind_rec

# def get_BG_ind_distrib_multi_cats(ind_rec = dict):
#     return ind_rec[bgmvf.BG_IND_DISTRIB_MULTI_CATS]

# def set_BG_ind_distrib_multi_cats(ind_rec = dict, value = bool):
#     ind_rec[bgmvf.BG_IND_DISTRIB_MULTI_CATS] = value

# def get_BG_ind_distrib_multi_fund_sources(ind_rec = dict):
#     return ind_rec[bgmvf.BG_IND_DISTRIB_MULTI_FUND_SOURCES]

# def set_BG_ind_distrib_multi_fund_sources(ind_rec = dict, value = bool):
#     ind_rec[bgmvf.BG_IND_DISTRIB_MULTI_FUND_SOURCES] = value

#######################################################################################################
#                                                                                                     #
#                                       Indicators - IC                                               #
#                                                                                                     #
#######################################################################################################

def get_BG_ind_deliv_chan_ID_IC(ind_rec = dict):
    return ind_rec[bgmvf.BG_IND_DELIV_CHAN_ID_IC]

def set_BG_ind_deliv_chan_ID_IC(ind_rec = dict, value = str):
    ind_rec[bgmvf.BG_IND_DELIV_CHAN_ID_IC] = value

# Use this to grab a specific indicator for a budget. It should give you either one or zero records.
def get_BG_ind_record_IC_deliv_chan(ind_records = list, budget_ID = str, ind_type_ID = int, ind_ID = str, isAggregate = bool, deliv_chan_ID = str):
    ind_recs_reduced = [ind_rec for ind_rec in ind_records if (
        (ind_rec[bgmvf.BG_IND_BUDGET_ID] == budget_ID)
        and (ind_rec[bgmvf.BG_IND_TYPE_ID] == ind_type_ID)
        and (ind_rec[bgmvf.BG_IND_ID] == ind_ID)
        # and (ind_rec[bgmvf.BG_IND_IS_AGGREGATE] == isAggregate)
        and (ind_rec[bgmvf.BG_IND_DELIV_CHAN_ID_IC] == deliv_chan_ID)
    )]
    return ind_recs_reduced[0] if len(ind_recs_reduced) > 0 else gbc.GB_NOT_FOUND

def get_BG_ind_record_IC_prog_area(ind_records = list, budget_ID = str, ind_type_ID = int, ind_ID = str, isAggregate = bool, prog_area_ID = str):
    ind_recs_reduced = [ind_rec for ind_rec in ind_records if (
        (ind_rec[bgmvf.BG_IND_BUDGET_ID] == budget_ID)
        and (ind_rec[bgmvf.BG_IND_TYPE_ID] == ind_type_ID)
        and (ind_rec[bgmvf.BG_IND_ID] == ind_ID)
        # and (ind_rec[bgmvf.BG_IND_IS_AGGREGATE] == isAggregate)
        and (ind_rec[bgmvf.BG_IND_PROG_AREA_ID_PC] == prog_area_ID)
    )]
    return ind_recs_reduced[0] if len(ind_recs_reduced) > 0 else gbc.GB_NOT_FOUND

def get_BG_ind_idx_and_rec_IC(ind_records = list, budget_ID = str, ind_type_ID = int, ind_ID = str, isAggregate = bool, deliv_chan_ID = str):
    indices_and_recs = [(idx, ind_rec) for (idx, ind_rec) in enumerate(ind_records) if (
        (ind_rec[bgmvf.BG_IND_BUDGET_ID] == budget_ID)
        and (ind_rec[bgmvf.BG_IND_TYPE_ID] == ind_type_ID)
        and (ind_rec[bgmvf.BG_IND_ID] == ind_ID)
        # and (ind_rec[bgmvf.BG_IND_IS_AGGREGATE] == isAggregate)
        and (ind_rec[bgmvf.BG_IND_DELIV_CHAN_ID_IC] == deliv_chan_ID)
    )]
    return indices_and_recs[0] if len(indices_and_recs) > 0 else (gbc.GB_NOT_FOUND, {})

def get_BG_ind_records_for_budget_ind_type_deliv_chan_IC(ind_records = list, budget_ID = str, ind_type_ID = int, deliv_chan_ID = str):
    recs = [ind_rec for ind_rec in ind_records if (
        (ind_rec[bgmvf.BG_IND_BUDGET_ID] == budget_ID)
        and (ind_rec[bgmvf.BG_IND_TYPE_ID] == ind_type_ID)
        and (ind_rec[bgmvf.BG_IND_DELIV_CHAN_ID_IC] == deliv_chan_ID)
    )]
    return recs if len(recs) > 0 else gbc.GB_NOT_FOUND

def get_BG_ind_records_for_budget_ind_type_prog_area_IC(ind_records = list, budget_ID = str, ind_type_ID = int, prog_area_ID = str):
    recs = [ind_rec for ind_rec in ind_records if (
        (ind_rec[bgmvf.BG_IND_BUDGET_ID] == budget_ID)
        and (ind_rec[bgmvf.BG_IND_TYPE_ID] == ind_type_ID)
        and (ind_rec[bgmvf.BG_IND_PROG_AREA_ID_PC] == prog_area_ID)
    )]
    return recs if len(recs) > 0 else gbc.GB_NOT_FOUND

#######################################################################################################
#                                                                                                     #
#                                       Indicators - PC                                               #
#                                                                                                     #
#######################################################################################################

# Use for standard PC and prog mgmt for all health systems modules (HS, IS, HW, LG, etc.)
def get_BG_ind_costing_section_ID_PC(ind_rec = dict):
    return ind_rec[bgmvf.BG_IND_COSTING_SECT_ID_PC]

def set_BG_ind_costing_section_ID_PC(ind_rec = dict, value = str):
    ind_rec[bgmvf.BG_IND_COSTING_SECT_ID_PC] = value

# Use for standard PC and prog mgmt for all health systems modules (HS, IS, HW, LG, etc.)
def get_BG_ind_costing_subsection_ID_PC(ind_rec = dict):
    return ind_rec[bgmvf.BG_IND_COSTING_SUBSECT_ID_PC]

def set_BG_ind_costing_subsection_ID_PC(ind_rec = dict, value = str):
    ind_rec[bgmvf.BG_IND_COSTING_SUBSECT_ID_PC] = value

# Use for standard PC and prog mgmt for all health systems modules (HS, IS, HW, LG, etc.)
def get_BG_ind_activity_ID_PC(ind_rec = dict):
    return ind_rec[bgmvf.BG_IND_ACT_ID_PC]

def set_BG_ind_activity_ID_PC(ind_rec = dict, value = str):
    ind_rec[bgmvf.BG_IND_ACT_ID_PC] = value

def get_BG_ind_prog_area_ID_PC(ind_rec = dict):
    return ind_rec[bgmvf.BG_IND_PROG_AREA_ID_PC]

def set_BG_ind_prog_area_ID_PC(ind_rec = dict, value = str):
    ind_rec[bgmvf.BG_IND_PROG_AREA_ID_PC] = value

def get_BG_ind_record_PC(ind_records = list, budget_ID = str, ind_type_ID = int, prog_area_ID = str, costing_sect_ID = str, costing_subsect_ID = str, activity_ID = str):
    ind_recs_reduced = [ind_rec for ind_rec in ind_records if (
        (ind_rec[bgmvf.BG_IND_BUDGET_ID] == budget_ID)
        and (ind_rec[bgmvf.BG_IND_TYPE_ID] == ind_type_ID)
        and (ind_rec[bgmvf.BG_IND_PROG_AREA_ID_PC] == prog_area_ID)
        and (ind_rec[bgmvf.BG_IND_COSTING_SECT_ID_PC] == costing_sect_ID)
        and (ind_rec[bgmvf.BG_IND_COSTING_SUBSECT_ID_PC] == costing_subsect_ID)
        and (ind_rec[bgmvf.BG_IND_ACT_ID_PC] == activity_ID)
    )]
    return ind_recs_reduced[0] if len(ind_recs_reduced) > 0 else gbc.GB_NOT_FOUND

def get_BG_ind_records_for_ind_type_PC(ind_records = list, budget_ID = str, ind_type_ID = int, prog_area_ID = str):
    recs = [ind_rec for ind_rec in ind_records if (
        (ind_rec[bgmvf.BG_IND_BUDGET_ID] == budget_ID)
        and (ind_rec[bgmvf.BG_IND_TYPE_ID] == ind_type_ID)
        and (ind_rec[bgmvf.BG_IND_PROG_AREA_ID_PC] == prog_area_ID)
    )]
    return recs if len(recs) > 0 else gbc.GB_NOT_FOUND

def get_BG_ind_records_for_section_PC(ind_records = list, budget_ID = str, ind_type_ID = int, prog_area_ID = str, costing_sect_ID = str, excluded_costing_subsect_ID = str):
    recs = [ind_rec for ind_rec in ind_records if (
        (ind_rec[bgmvf.BG_IND_BUDGET_ID] == budget_ID)
        and (ind_rec[bgmvf.BG_IND_TYPE_ID] == ind_type_ID)
        and (ind_rec[bgmvf.BG_IND_PROG_AREA_ID_PC] == prog_area_ID)
        and (ind_rec[bgmvf.BG_IND_COSTING_SECT_ID_PC] == costing_sect_ID)
        and (ind_rec[bgmvf.BG_IND_COSTING_SUBSECT_ID_PC] != excluded_costing_subsect_ID)
    )]
    return recs if len(recs) > 0 else gbc.GB_NOT_FOUND

def get_BG_ind_records_for_subsection_PC(ind_records = list, budget_ID = str, ind_type_ID = int, prog_area_ID = str, costing_sect_ID = str, costing_subsect_ID = str, excluded_activity_ID = str):
    recs = [ind_rec for ind_rec in ind_records if (
        (ind_rec[bgmvf.BG_IND_BUDGET_ID] == budget_ID)
        and (ind_rec[bgmvf.BG_IND_TYPE_ID] == ind_type_ID)
        and (ind_rec[bgmvf.BG_IND_PROG_AREA_ID_PC] == prog_area_ID)
        and (ind_rec[bgmvf.BG_IND_COSTING_SECT_ID_PC] == costing_sect_ID)
        and (ind_rec[bgmvf.BG_IND_COSTING_SUBSECT_ID_PC] == costing_subsect_ID)
        and (ind_rec[bgmvf.BG_IND_ACT_ID_PC] != excluded_activity_ID)
    )]
    return recs if len(recs) > 0 else gbc.GB_NOT_FOUND

#######################################################################################################
#                                                                                                     #
#                                       Indicators - IS                                               #
#                                                                                                     #
#######################################################################################################

def get_BG_ind_record_IS_non_prog_mgmt(ind_records = list, budget_ID = str, ind_type_ID = int, ind_ID = str, prog_area_ID = str):
    ind_recs_reduced = [ind_rec for ind_rec in ind_records if (
        (ind_rec[bgmvf.BG_IND_BUDGET_ID] == budget_ID)
        and (ind_rec[bgmvf.BG_IND_TYPE_ID] == ind_type_ID)
        and (ind_rec[bgmvf.BG_IND_ID] == ind_ID)
        and (ind_rec[bgmvf.BG_IND_PROG_AREA_ID_PC] == prog_area_ID)
    )]
    return ind_recs_reduced[0] if len(ind_recs_reduced) > 0 else gbc.GB_NOT_FOUND

def get_BG_ind_record_IS_prog_mgmt(ind_records = list, budget_ID = str, ind_type_ID = int, costing_sect_ID = str, costing_subsect_ID = str, activity_ID = str):
    ind_recs_reduced = [ind_rec for ind_rec in ind_records if (
        (ind_rec[bgmvf.BG_IND_BUDGET_ID] == budget_ID)
        and (ind_rec[bgmvf.BG_IND_TYPE_ID] == ind_type_ID)
        and (ind_rec[bgmvf.BG_IND_COSTING_SECT_ID_PC] == costing_sect_ID)
        and (ind_rec[bgmvf.BG_IND_COSTING_SUBSECT_ID_PC] == costing_subsect_ID)
        and (ind_rec[bgmvf.BG_IND_ACT_ID_PC] == activity_ID)
    )]
    return ind_recs_reduced[0] if len(ind_recs_reduced) > 0 else gbc.GB_NOT_FOUND

def get_BG_ind_records_for_budget_ind_type_IS(ind_records = list, budget_ID = str, ind_type_ID = int):
    recs = [ind_rec for ind_rec in ind_records if (
        (ind_rec[bgmvf.BG_IND_BUDGET_ID] == budget_ID)
        and (ind_rec[bgmvf.BG_IND_TYPE_ID] == ind_type_ID)
    )]
    return recs if len(recs) > 0 else gbc.GB_NOT_FOUND

def get_BG_ind_records_for_section_IS(ind_records = list, budget_ID = str, ind_type_ID = int, costing_sect_ID = str, excluded_costing_subsect_ID = str):
    recs = [ind_rec for ind_rec in ind_records if (
        (ind_rec[bgmvf.BG_IND_BUDGET_ID] == budget_ID)
        and (ind_rec[bgmvf.BG_IND_TYPE_ID] == ind_type_ID)
        and (ind_rec[bgmvf.BG_IND_COSTING_SECT_ID_PC] == costing_sect_ID)
        and (ind_rec[bgmvf.BG_IND_COSTING_SUBSECT_ID_PC] != excluded_costing_subsect_ID)
    )]
    return recs if len(recs) > 0 else gbc.GB_NOT_FOUND

def get_BG_ind_records_for_subsection_IS(ind_records = list, budget_ID = str, ind_type_ID = int, costing_sect_ID = str, costing_subsect_ID = str, excluded_activity_ID = str):
    recs = [ind_rec for ind_rec in ind_records if (
        (ind_rec[bgmvf.BG_IND_BUDGET_ID] == budget_ID)
        and (ind_rec[bgmvf.BG_IND_TYPE_ID] == ind_type_ID)
        and (ind_rec[bgmvf.BG_IND_COSTING_SECT_ID_PC] == costing_sect_ID)
        and (ind_rec[bgmvf.BG_IND_COSTING_SUBSECT_ID_PC] == costing_subsect_ID)
        and (ind_rec[bgmvf.BG_IND_ACT_ID_PC] != excluded_activity_ID)
    )]
    return recs if len(recs) > 0 else gbc.GB_NOT_FOUND

#######################################################################################################
#                                                                                                     #
#                                       Indicators - HW                                               #
#                                                                                                     #
#######################################################################################################

def get_BG_ind_staff_level_ID_HW(ind_rec = dict):
    return ind_rec[bgmvf.BG_IND_STAFF_LEVEL_ID_HW]

def set_BG_ind_staff_level_ID_HW(ind_rec = dict, value = str):
    ind_rec[bgmvf.BG_IND_STAFF_LEVEL_ID_HW] = value

def get_BG_ind_compens_type_ID_HW(ind_rec = dict):
    return ind_rec[bgmvf.BG_IND_COMPENS_TYPE_ID_HW]

def set_BG_ind_compens_type_ID_HW(ind_rec = dict, value = str):
    ind_rec[bgmvf.BG_IND_COMPENS_TYPE_ID_HW] = value

# For 
#   Total compensation  
#
#   indicators. "-1" is all dynamic staff types combined.
def get_BG_ind_record_by_level_compens_staff_type_HW(ind_records = list, budget_ID = str, ind_type_ID = int, staff_level_ID = int, compens_type_ID = int, dynamic_staff_type_ID = str):
    ind_recs_reduced = [ind_rec for ind_rec in ind_records if (
        (ind_rec[bgmvf.BG_IND_BUDGET_ID] == budget_ID)
        and (ind_rec[bgmvf.BG_IND_TYPE_ID] == ind_type_ID)
        and (ind_rec[bgmvf.BG_IND_STAFF_LEVEL_ID_HW] == staff_level_ID)
        and (ind_rec[bgmvf.BG_IND_COMPENS_TYPE_ID_HW] == compens_type_ID)
        and (ind_rec[bgmvf.BG_IND_ID] == dynamic_staff_type_ID)
    )]
    return ind_recs_reduced[0] if len(ind_recs_reduced) > 0 else gbc.GB_NOT_FOUND

# For: 
#   Total compensation, single staff type
#   Inservice training, single staff type
#   Inservice training, 
#   Preservice training  
#
#   indicators. "-1" is all dynamic staff types combined.
def get_BG_ind_record_by_staff_type_HW(ind_records = list, budget_ID = str, ind_type_ID = int, dynamic_staff_type_ID = str):
    ind_recs_reduced = [ind_rec for ind_rec in ind_records if (
        (ind_rec[bgmvf.BG_IND_BUDGET_ID] == budget_ID)
        and (ind_rec[bgmvf.BG_IND_TYPE_ID] == ind_type_ID)
        and (ind_rec[bgmvf.BG_IND_ID] == dynamic_staff_type_ID)
    )]
    return ind_recs_reduced[0] if len(ind_recs_reduced) > 0 else gbc.GB_NOT_FOUND

# For 
#   Inservice training by staffing level 
#
#   indicators. "-1" is all dynamic staff types combined.
def get_BG_ind_record_by_level_staff_type_HW(ind_records = list, budget_ID = str, ind_type_ID = int, staff_level_ID = int, dynamic_staff_type_ID = str):
    ind_recs_reduced = [ind_rec for ind_rec in ind_records if (
        (ind_rec[bgmvf.BG_IND_BUDGET_ID] == budget_ID)
        and (ind_rec[bgmvf.BG_IND_TYPE_ID] == ind_type_ID)
        and (ind_rec[bgmvf.BG_IND_STAFF_LEVEL_ID_HW] == staff_level_ID)
        and (ind_rec[bgmvf.BG_IND_ID] == dynamic_staff_type_ID)
    )]
    return ind_recs_reduced[0] if len(ind_recs_reduced) > 0 else gbc.GB_NOT_FOUND

def get_BG_ind_record_HW_prog_mgmt(ind_records = list, budget_ID = str, ind_type_ID = int, costing_sect_ID = str, costing_subsect_ID = str, activity_ID = str):
    ind_recs_reduced = [ind_rec for ind_rec in ind_records if (
        (ind_rec[bgmvf.BG_IND_BUDGET_ID] == budget_ID)
        and (ind_rec[bgmvf.BG_IND_TYPE_ID] == ind_type_ID)
        and (ind_rec[bgmvf.BG_IND_COSTING_SECT_ID_PC] == costing_sect_ID)
        and (ind_rec[bgmvf.BG_IND_COSTING_SUBSECT_ID_PC] == costing_subsect_ID)
        and (ind_rec[bgmvf.BG_IND_ACT_ID_PC] == activity_ID)
    )]
    return ind_recs_reduced[0] if len(ind_recs_reduced) > 0 else gbc.GB_NOT_FOUND

def get_BG_ind_records_for_section_HW(ind_records = list, budget_ID = str, ind_type_ID = int, costing_sect_ID = str, excluded_costing_subsect_ID = str):
    recs = [ind_rec for ind_rec in ind_records if (
        (ind_rec[bgmvf.BG_IND_BUDGET_ID] == budget_ID)
        and (ind_rec[bgmvf.BG_IND_TYPE_ID] == ind_type_ID)
        and (ind_rec[bgmvf.BG_IND_COSTING_SECT_ID_PC] == costing_sect_ID)
        and (ind_rec[bgmvf.BG_IND_COSTING_SUBSECT_ID_PC] != excluded_costing_subsect_ID)
    )]
    return recs if len(recs) > 0 else gbc.GB_NOT_FOUND

def get_BG_ind_records_for_subsection_HW(ind_records = list, budget_ID = str, ind_type_ID = int, costing_sect_ID = str, costing_subsect_ID = str, excluded_activity_ID = str):
    recs = [ind_rec for ind_rec in ind_records if (
        (ind_rec[bgmvf.BG_IND_BUDGET_ID] == budget_ID)
        and (ind_rec[bgmvf.BG_IND_TYPE_ID] == ind_type_ID)
        and (ind_rec[bgmvf.BG_IND_COSTING_SECT_ID_PC] == costing_sect_ID)
        and (ind_rec[bgmvf.BG_IND_COSTING_SUBSECT_ID_PC] == costing_subsect_ID)
        and (ind_rec[bgmvf.BG_IND_ACT_ID_PC] != excluded_activity_ID)
    )]
    return recs if len(recs) > 0 else gbc.GB_NOT_FOUND

def get_BG_ind_records_for_budget_ind_type_HW(ind_records = list, budget_ID = str, ind_type_ID = int):
    recs = [ind_rec for ind_rec in ind_records if (
        (ind_rec[bgmvf.BG_IND_BUDGET_ID] == budget_ID)
        and (ind_rec[bgmvf.BG_IND_TYPE_ID] == ind_type_ID)
    )]
    return recs if len(recs) > 0 else gbc.GB_NOT_FOUND

#######################################################################################################
#                                                                                                     #
#                                       Indicators - HS                                               #
#                                                                                                     #
#######################################################################################################

def get_BG_ind_costing_section_HS_costing_ID(ind_rec = dict):
    return ind_rec[bgmvf.BG_IND_COSTING_SECT_HS_COSTING_ID]

def set_BG_ind_costing_section_HS_costing_ID(ind_rec = dict, value = str):
    ind_rec[bgmvf.BG_IND_COSTING_SECT_HS_COSTING_ID] = value

def get_BG_ind_costing_subsection_HS_costing_ID(ind_rec = dict):
    return ind_rec[bgmvf.BG_IND_COSTING_SUBSECT_HS_COSTING_ID]

def set_BG_ind_costing_subsection_HS_costing_ID(ind_rec = dict, value = str):
    ind_rec[bgmvf.BG_IND_COSTING_SUBSECT_HS_COSTING_ID] = value

def get_BG_ind_activity_HS_costing_ID(ind_rec = dict):
    return ind_rec[bgmvf.BG_IND_ACT_HS_COSTING_ID]

def set_BG_ind_activity_HS_costing_ID(ind_rec = dict, value = str):
    ind_rec[bgmvf.BG_IND_ACT_HS_COSTING_ID] = value

def get_BG_ind_costing_section_HS_prog_mgmt_ID(ind_rec = dict):
    return ind_rec[bgmvf.BG_IND_COSTING_SECT_HS_PROG_MGMT_ID]

def set_BG_ind_costing_section_HS_prog_mgmt_ID(ind_rec = dict, value = str):
    ind_rec[bgmvf.BG_IND_COSTING_SECT_HS_PROG_MGMT_ID] = value

def get_BG_ind_costing_subsection_HS_prog_mgmt_ID(ind_rec = dict):
    return ind_rec[bgmvf.BG_IND_COSTING_SUBSECT_HS_PROG_MGMT_ID]

def set_BG_ind_costing_subsection_HS_prog_mgmt_ID(ind_rec = dict, value = str):
    ind_rec[bgmvf.BG_IND_COSTING_SUBSECT_HS_PROG_MGMT_ID] = value

def get_BG_ind_activity_HS_prog_mgmt_ID(ind_rec = dict):
    return ind_rec[bgmvf.BG_IND_ACT_HS_PROG_MGMT_ID]

def set_BG_ind_activity_HS_prog_mgmt_ID(ind_rec = dict, value = str):
    ind_rec[bgmvf.BG_IND_ACT_HS_PROG_MGMT_ID] = value

def get_BG_ind_record_HS_costing(ind_records = list, budget_ID = str, ind_type_ID = int, costing_sect_ID = str, costing_subsect_ID = str, activity_ID = str):
    ind_recs_reduced = [ind_rec for ind_rec in ind_records if (
        (ind_rec[bgmvf.BG_IND_BUDGET_ID] == budget_ID)
        and (ind_rec[bgmvf.BG_IND_TYPE_ID] == ind_type_ID)
        and (ind_rec[bgmvf.BG_IND_COSTING_SECT_HS_COSTING_ID] == costing_sect_ID)
        and (ind_rec[bgmvf.BG_IND_COSTING_SUBSECT_HS_COSTING_ID] == costing_subsect_ID)
        and (ind_rec[bgmvf.BG_IND_ACT_HS_COSTING_ID] == activity_ID)
    )]
    return ind_recs_reduced[0] if len(ind_recs_reduced) > 0 else gbc.GB_NOT_FOUND

def get_BG_ind_record_HS_prog_mgmt(ind_records = list, budget_ID = str, ind_type_ID = int, costing_sect_ID = str, costing_subsect_ID = str, activity_ID = str):
    ind_recs_reduced = [ind_rec for ind_rec in ind_records if (
        (ind_rec[bgmvf.BG_IND_BUDGET_ID] == budget_ID)
        and (ind_rec[bgmvf.BG_IND_TYPE_ID] == ind_type_ID)
        and (ind_rec[bgmvf.BG_IND_COSTING_SECT_HS_PROG_MGMT_ID] == costing_sect_ID)
        and (ind_rec[bgmvf.BG_IND_COSTING_SUBSECT_HS_PROG_MGMT_ID] == costing_subsect_ID)
        and (ind_rec[bgmvf.BG_IND_ACT_HS_PROG_MGMT_ID] == activity_ID)
    )]
    return ind_recs_reduced[0] if len(ind_recs_reduced) > 0 else gbc.GB_NOT_FOUND

def get_BG_ind_records_for_ind_type_HS(ind_records = list, budget_ID = str, ind_type_ID = int):
    recs = [ind_rec for ind_rec in ind_records if (
        (ind_rec[bgmvf.BG_IND_BUDGET_ID] == budget_ID)
        and (ind_rec[bgmvf.BG_IND_TYPE_ID] == ind_type_ID)
    )]
    return recs if len(recs) > 0 else gbc.GB_NOT_FOUND

def get_BG_ind_records_for_section_HS_costing(ind_records = list, budget_ID = str, ind_type_ID = int, costing_sect_ID = str, excluded_costing_subsect_ID = str):
    recs = [ind_rec for ind_rec in ind_records if (
        (ind_rec[bgmvf.BG_IND_BUDGET_ID] == budget_ID)
        and (ind_rec[bgmvf.BG_IND_TYPE_ID] == ind_type_ID)
        and (ind_rec[bgmvf.BG_IND_COSTING_SECT_HS_COSTING_ID] == costing_sect_ID)
        and (ind_rec[bgmvf.BG_IND_COSTING_SUBSECT_HS_COSTING_ID] != excluded_costing_subsect_ID)
    )]
    return recs if len(recs) > 0 else gbc.GB_NOT_FOUND

def get_BG_ind_records_for_section_HS_prog_mgmt(ind_records = list, budget_ID = str, ind_type_ID = int, costing_sect_ID = str, excluded_costing_subsect_ID = str):
    recs = [ind_rec for ind_rec in ind_records if (
        (ind_rec[bgmvf.BG_IND_BUDGET_ID] == budget_ID)
        and (ind_rec[bgmvf.BG_IND_TYPE_ID] == ind_type_ID)
        and (ind_rec[bgmvf.BG_IND_COSTING_SECT_HS_PROG_MGMT_ID] == costing_sect_ID)
        and (ind_rec[bgmvf.BG_IND_COSTING_SUBSECT_HS_PROG_MGMT_ID] != excluded_costing_subsect_ID)
    )]
    return recs if len(recs) > 0 else gbc.GB_NOT_FOUND

def get_BG_ind_records_for_subsection_HS_costing(ind_records = list, budget_ID = str, ind_type_ID = int, costing_sect_ID = str, costing_subsect_ID = str, excluded_activity_ID = str):
    recs = [ind_rec for ind_rec in ind_records if (
        (ind_rec[bgmvf.BG_IND_BUDGET_ID] == budget_ID)
        and (ind_rec[bgmvf.BG_IND_TYPE_ID] == ind_type_ID)
        and (ind_rec[bgmvf.BG_IND_COSTING_SECT_HS_COSTING_ID] == costing_sect_ID)
        and (ind_rec[bgmvf.BG_IND_COSTING_SUBSECT_HS_COSTING_ID] == costing_subsect_ID)
        and (ind_rec[bgmvf.BG_IND_ACT_HS_COSTING_ID] != excluded_activity_ID)
    )]
    return recs if len(recs) > 0 else gbc.GB_NOT_FOUND

def get_BG_ind_records_for_subsection_HS_prog_mgmt(ind_records = list, budget_ID = str, ind_type_ID = int, costing_sect_ID = str, costing_subsect_ID = str, excluded_activity_ID = str):
    recs = [ind_rec for ind_rec in ind_records if (
        (ind_rec[bgmvf.BG_IND_BUDGET_ID] == budget_ID)
        and (ind_rec[bgmvf.BG_IND_TYPE_ID] == ind_type_ID)
        and (ind_rec[bgmvf.BG_IND_COSTING_SECT_HS_PROG_MGMT_ID] == costing_sect_ID)
        and (ind_rec[bgmvf.BG_IND_COSTING_SUBSECT_HS_PROG_MGMT_ID] == costing_subsect_ID)
        and (ind_rec[bgmvf.BG_IND_ACT_HS_PROG_MGMT_ID] != excluded_activity_ID)
    )]
    return recs if len(recs) > 0 else gbc.GB_NOT_FOUND

#######################################################################################################
#                                                                                                     #
#                                       Indicators - GV                                               #
#                                                                                                     #
#######################################################################################################

def get_BG_ind_costing_section_GV_costing_ID(ind_rec = dict):
    return ind_rec[bgmvf.BG_IND_COSTING_SECT_GV_COSTING_ID]

def set_BG_ind_costing_section_GV_costing_ID(ind_rec = dict, value = str):
    ind_rec[bgmvf.BG_IND_COSTING_SECT_GV_COSTING_ID] = value

def get_BG_ind_costing_subsection_GV_costing_ID(ind_rec = dict):
    return ind_rec[bgmvf.BG_IND_COSTING_SUBSECT_GV_COSTING_ID]

def set_BG_ind_costing_subsection_GV_costing_ID(ind_rec = dict, value = str):
    ind_rec[bgmvf.BG_IND_COSTING_SUBSECT_GV_COSTING_ID] = value

def get_BG_ind_activity_GV_costing_ID(ind_rec = dict):
    return ind_rec[bgmvf.BG_IND_ACT_GV_COSTING_ID]

def set_BG_ind_activity_GV_costing_ID(ind_rec = dict, value = str):
    ind_rec[bgmvf.BG_IND_ACT_GV_COSTING_ID] = value

def get_BG_ind_costing_section_GV_prog_mgmt_ID(ind_rec = dict):
    return ind_rec[bgmvf.BG_IND_COSTING_SECT_GV_PROG_MGMT_ID]

def set_BG_ind_costing_section_GV_prog_mgmt_ID(ind_rec = dict, value = str):
    ind_rec[bgmvf.BG_IND_COSTING_SECT_GV_PROG_MGMT_ID] = value

def get_BG_ind_costing_subsection_GV_prog_mgmt_ID(ind_rec = dict):
    return ind_rec[bgmvf.BG_IND_COSTING_SUBSECT_GV_PROG_MGMT_ID]

def set_BG_ind_costing_subsection_GV_prog_mgmt_ID(ind_rec = dict, value = str):
    ind_rec[bgmvf.BG_IND_COSTING_SUBSECT_GV_PROG_MGMT_ID] = value

def get_BG_ind_activity_GV_prog_mgmt_ID(ind_rec = dict):
    return ind_rec[bgmvf.BG_IND_ACT_GV_PROG_MGMT_ID]

def set_BG_ind_activity_GV_prog_mgmt_ID(ind_rec = dict, value = str):
    ind_rec[bgmvf.BG_IND_ACT_GV_PROG_MGMT_ID] = value

def get_BG_ind_record_GV_costing(ind_records = list, budget_ID = str, ind_type_ID = int, costing_sect_ID = str, costing_subsect_ID = str, activity_ID = str):
    ind_recs_reduced = [ind_rec for ind_rec in ind_records if (
        (ind_rec[bgmvf.BG_IND_BUDGET_ID] == budget_ID)
        and (ind_rec[bgmvf.BG_IND_TYPE_ID] == ind_type_ID)
        and (ind_rec[bgmvf.BG_IND_COSTING_SECT_GV_COSTING_ID] == costing_sect_ID)
        and (ind_rec[bgmvf.BG_IND_COSTING_SUBSECT_GV_COSTING_ID] == costing_subsect_ID)
        and (ind_rec[bgmvf.BG_IND_ACT_GV_COSTING_ID] == activity_ID)
    )]
    return ind_recs_reduced[0] if len(ind_recs_reduced) > 0 else gbc.GB_NOT_FOUND

def get_BG_ind_record_GV_prog_mgmt(ind_records = list, budget_ID = str, ind_type_ID = int, costing_sect_ID = str, costing_subsect_ID = str, activity_ID = str):
    ind_recs_reduced = [ind_rec for ind_rec in ind_records if (
        (ind_rec[bgmvf.BG_IND_BUDGET_ID] == budget_ID)
        and (ind_rec[bgmvf.BG_IND_TYPE_ID] == ind_type_ID)
        and (ind_rec[bgmvf.BG_IND_COSTING_SECT_GV_PROG_MGMT_ID] == costing_sect_ID)
        and (ind_rec[bgmvf.BG_IND_COSTING_SUBSECT_GV_PROG_MGMT_ID] == costing_subsect_ID)
        and (ind_rec[bgmvf.BG_IND_ACT_GV_PROG_MGMT_ID] == activity_ID)
    )]
    return ind_recs_reduced[0] if len(ind_recs_reduced) > 0 else gbc.GB_NOT_FOUND

def get_BG_ind_records_for_ind_type_GV(ind_records = list, budget_ID = str, ind_type_ID = int):
    recs = [ind_rec for ind_rec in ind_records if (
        (ind_rec[bgmvf.BG_IND_BUDGET_ID] == budget_ID)
        and (ind_rec[bgmvf.BG_IND_TYPE_ID] == ind_type_ID)
    )]
    return recs if len(recs) > 0 else gbc.GB_NOT_FOUND

def get_BG_ind_records_for_section_GV_costing(ind_records = list, budget_ID = str, ind_type_ID = int, costing_sect_ID = str, excluded_costing_subsect_ID = str):
    recs = [ind_rec for ind_rec in ind_records if (
        (ind_rec[bgmvf.BG_IND_BUDGET_ID] == budget_ID)
        and (ind_rec[bgmvf.BG_IND_TYPE_ID] == ind_type_ID)
        and (ind_rec[bgmvf.BG_IND_COSTING_SECT_GV_COSTING_ID] == costing_sect_ID)
        and (ind_rec[bgmvf.BG_IND_COSTING_SUBSECT_GV_COSTING_ID] != excluded_costing_subsect_ID)
    )]
    return recs if len(recs) > 0 else gbc.GB_NOT_FOUND

def get_BG_ind_records_for_section_GV_prog_mgmt(ind_records = list, budget_ID = str, ind_type_ID = int, costing_sect_ID = str, excluded_costing_subsect_ID = str):
    recs = [ind_rec for ind_rec in ind_records if (
        (ind_rec[bgmvf.BG_IND_BUDGET_ID] == budget_ID)
        and (ind_rec[bgmvf.BG_IND_TYPE_ID] == ind_type_ID)
        and (ind_rec[bgmvf.BG_IND_COSTING_SECT_GV_PROG_MGMT_ID] == costing_sect_ID)
        and (ind_rec[bgmvf.BG_IND_COSTING_SUBSECT_GV_PROG_MGMT_ID] != excluded_costing_subsect_ID)
    )]
    return recs if len(recs) > 0 else gbc.GB_NOT_FOUND

def get_BG_ind_records_for_subsection_GV_costing(ind_records = list, budget_ID = str, ind_type_ID = int, costing_sect_ID = str, costing_subsect_ID = str, excluded_activity_ID = str):
    recs = [ind_rec for ind_rec in ind_records if (
        (ind_rec[bgmvf.BG_IND_BUDGET_ID] == budget_ID)
        and (ind_rec[bgmvf.BG_IND_TYPE_ID] == ind_type_ID)
        and (ind_rec[bgmvf.BG_IND_COSTING_SECT_GV_COSTING_ID] == costing_sect_ID)
        and (ind_rec[bgmvf.BG_IND_COSTING_SUBSECT_GV_COSTING_ID] == costing_subsect_ID)
        and (ind_rec[bgmvf.BG_IND_ACT_GV_COSTING_ID] != excluded_activity_ID)
    )]
    return recs if len(recs) > 0 else gbc.GB_NOT_FOUND

def get_BG_ind_records_for_subsection_GV_prog_mgmt(ind_records = list, budget_ID = str, ind_type_ID = int, costing_sect_ID = str, costing_subsect_ID = str, excluded_activity_ID = str):
    recs = [ind_rec for ind_rec in ind_records if (
        (ind_rec[bgmvf.BG_IND_BUDGET_ID] == budget_ID)
        and (ind_rec[bgmvf.BG_IND_TYPE_ID] == ind_type_ID)
        and (ind_rec[bgmvf.BG_IND_COSTING_SECT_GV_PROG_MGMT_ID] == costing_sect_ID)
        and (ind_rec[bgmvf.BG_IND_COSTING_SUBSECT_GV_PROG_MGMT_ID] == costing_subsect_ID)
        and (ind_rec[bgmvf.BG_IND_ACT_GV_PROG_MGMT_ID] != excluded_activity_ID)
    )]
    return recs if len(recs) > 0 else gbc.GB_NOT_FOUND

#######################################################################################################
#                                                                                                     #
#                                       Indicators - HF                                               #
#                                                                                                     #
#######################################################################################################

def get_BG_ind_costing_section_HF_costing_ID(ind_rec = dict):
    return ind_rec[bgmvf.BG_IND_COSTING_SECT_HF_COSTING_ID]

def set_BG_ind_costing_section_HF_costing_ID(ind_rec = dict, value = str):
    ind_rec[bgmvf.BG_IND_COSTING_SECT_HF_COSTING_ID] = value

def get_BG_ind_costing_subsection_HF_costing_ID(ind_rec = dict):
    return ind_rec[bgmvf.BG_IND_COSTING_SUBSECT_HF_COSTING_ID]

def set_BG_ind_costing_subsection_HF_costing_ID(ind_rec = dict, value = str):
    ind_rec[bgmvf.BG_IND_COSTING_SUBSECT_HF_COSTING_ID] = value

def get_BG_ind_activity_HF_costing_ID(ind_rec = dict):
    return ind_rec[bgmvf.BG_IND_ACT_HF_COSTING_ID]

def set_BG_ind_activity_HF_costing_ID(ind_rec = dict, value = str):
    ind_rec[bgmvf.BG_IND_ACT_HF_COSTING_ID] = value

def get_BG_ind_costing_section_HF_prog_mgmt_ID(ind_rec = dict):
    return ind_rec[bgmvf.BG_IND_COSTING_SECT_HF_PROG_MGMT_ID]

def set_BG_ind_costing_section_HF_prog_mgmt_ID(ind_rec = dict, value = str):
    ind_rec[bgmvf.BG_IND_COSTING_SECT_HF_PROG_MGMT_ID] = value

def get_BG_ind_costing_subsection_HF_prog_mgmt_ID(ind_rec = dict):
    return ind_rec[bgmvf.BG_IND_COSTING_SUBSECT_HF_PROG_MGMT_ID]

def set_BG_ind_costing_subsection_HF_prog_mgmt_ID(ind_rec = dict, value = str):
    ind_rec[bgmvf.BG_IND_COSTING_SUBSECT_HF_PROG_MGMT_ID] = value

def get_BG_ind_activity_HF_prog_mgmt_ID(ind_rec = dict):
    return ind_rec[bgmvf.BG_IND_ACT_HF_PROG_MGMT_ID]

def set_BG_ind_activity_HF_prog_mgmt_ID(ind_rec = dict, value = str):
    ind_rec[bgmvf.BG_IND_ACT_HF_PROG_MGMT_ID] = value

def get_BG_ind_record_HF_costing(ind_records = list, budget_ID = str, ind_type_ID = int, costing_sect_ID = str, costing_subsect_ID = str, activity_ID = str):
    ind_recs_reduced = [ind_rec for ind_rec in ind_records if (
        (ind_rec[bgmvf.BG_IND_BUDGET_ID] == budget_ID)
        and (ind_rec[bgmvf.BG_IND_TYPE_ID] == ind_type_ID)
        and (ind_rec[bgmvf.BG_IND_COSTING_SECT_HF_COSTING_ID] == costing_sect_ID)
        and (ind_rec[bgmvf.BG_IND_COSTING_SUBSECT_HF_COSTING_ID] == costing_subsect_ID)
        and (ind_rec[bgmvf.BG_IND_ACT_HF_COSTING_ID] == activity_ID)
    )]
    return ind_recs_reduced[0] if len(ind_recs_reduced) > 0 else gbc.GB_NOT_FOUND

def get_BG_ind_record_HF_prog_mgmt(ind_records = list, budget_ID = str, ind_type_ID = int, costing_sect_ID = str, costing_subsect_ID = str, activity_ID = str):
    ind_recs_reduced = [ind_rec for ind_rec in ind_records if (
        (ind_rec[bgmvf.BG_IND_BUDGET_ID] == budget_ID)
        and (ind_rec[bgmvf.BG_IND_TYPE_ID] == ind_type_ID)
        and (ind_rec[bgmvf.BG_IND_COSTING_SECT_HF_PROG_MGMT_ID] == costing_sect_ID)
        and (ind_rec[bgmvf.BG_IND_COSTING_SUBSECT_HF_PROG_MGMT_ID] == costing_subsect_ID)
        and (ind_rec[bgmvf.BG_IND_ACT_HF_PROG_MGMT_ID] == activity_ID)
    )]
    return ind_recs_reduced[0] if len(ind_recs_reduced) > 0 else gbc.GB_NOT_FOUND

def get_BG_ind_records_for_ind_type_HF(ind_records = list, budget_ID = str, ind_type_ID = int):
    recs = [ind_rec for ind_rec in ind_records if (
        (ind_rec[bgmvf.BG_IND_BUDGET_ID] == budget_ID)
        and (ind_rec[bgmvf.BG_IND_TYPE_ID] == ind_type_ID)
    )]
    return recs if len(recs) > 0 else gbc.GB_NOT_FOUND

def get_BG_ind_records_for_section_HF_costing(ind_records = list, budget_ID = str, ind_type_ID = int, costing_sect_ID = str, excluded_costing_subsect_ID = str):
    recs = [ind_rec for ind_rec in ind_records if (
        (ind_rec[bgmvf.BG_IND_BUDGET_ID] == budget_ID)
        and (ind_rec[bgmvf.BG_IND_TYPE_ID] == ind_type_ID)
        and (ind_rec[bgmvf.BG_IND_COSTING_SECT_HF_COSTING_ID] == costing_sect_ID)
        and (ind_rec[bgmvf.BG_IND_COSTING_SUBSECT_HF_COSTING_ID] != excluded_costing_subsect_ID)
    )]
    return recs if len(recs) > 0 else gbc.GB_NOT_FOUND

def get_BG_ind_records_for_section_HF_prog_mgmt(ind_records = list, budget_ID = str, ind_type_ID = int, costing_sect_ID = str, excluded_costing_subsect_ID = str):
    recs = [ind_rec for ind_rec in ind_records if (
        (ind_rec[bgmvf.BG_IND_BUDGET_ID] == budget_ID)
        and (ind_rec[bgmvf.BG_IND_TYPE_ID] == ind_type_ID)
        and (ind_rec[bgmvf.BG_IND_COSTING_SECT_HF_PROG_MGMT_ID] == costing_sect_ID)
        and (ind_rec[bgmvf.BG_IND_COSTING_SUBSECT_HF_PROG_MGMT_ID] != excluded_costing_subsect_ID)
    )]
    return recs if len(recs) > 0 else gbc.GB_NOT_FOUND

def get_BG_ind_records_for_subsection_HF_costing(ind_records = list, budget_ID = str, ind_type_ID = int, costing_sect_ID = str, costing_subsect_ID = str, excluded_activity_ID = str):
    recs = [ind_rec for ind_rec in ind_records if (
        (ind_rec[bgmvf.BG_IND_BUDGET_ID] == budget_ID)
        and (ind_rec[bgmvf.BG_IND_TYPE_ID] == ind_type_ID)
        and (ind_rec[bgmvf.BG_IND_COSTING_SECT_HF_COSTING_ID] == costing_sect_ID)
        and (ind_rec[bgmvf.BG_IND_COSTING_SUBSECT_HF_COSTING_ID] == costing_subsect_ID)
        and (ind_rec[bgmvf.BG_IND_ACT_HF_COSTING_ID] != excluded_activity_ID)
    )]
    return recs if len(recs) > 0 else gbc.GB_NOT_FOUND

def get_BG_ind_records_for_subsection_HF_prog_mgmt(ind_records = list, budget_ID = str, ind_type_ID = int, costing_sect_ID = str, costing_subsect_ID = str, excluded_activity_ID = str):
    recs = [ind_rec for ind_rec in ind_records if (
        (ind_rec[bgmvf.BG_IND_BUDGET_ID] == budget_ID)
        and (ind_rec[bgmvf.BG_IND_TYPE_ID] == ind_type_ID)
        and (ind_rec[bgmvf.BG_IND_COSTING_SECT_HF_PROG_MGMT_ID] == costing_sect_ID)
        and (ind_rec[bgmvf.BG_IND_COSTING_SUBSECT_HF_PROG_MGMT_ID] == costing_subsect_ID)
        and (ind_rec[bgmvf.BG_IND_ACT_HF_PROG_MGMT_ID] != excluded_activity_ID)
    )]
    return recs if len(recs) > 0 else gbc.GB_NOT_FOUND

#######################################################################################################
#                                                                                                     #
#                                       Quick map records                                             #
#                                                                                                     #
#######################################################################################################

def get_BG_quick_map_records(quick_map_records = list, budget_ID = str):
    quick_map_recs_reduced = [quick_map_rec for quick_map_rec in quick_map_records if quick_map_rec[bgmvf.BG_QUICK_MAP_BUDGET_ID] == budget_ID]
    return quick_map_recs_reduced
    
# Change the budget of a indicator. Useful when copying a budget.
def change_BG_quick_map_budget_ID(quick_map_records = list, budget_ID = str):
    quick_map_recs = [set_BG_quick_map_budget_ID(quick_map_rec, budget_ID) for quick_map_rec in quick_map_records]
    return quick_map_recs

def remove_BG_quick_map_records(quick_map_records = list, budget_ID = str):
    quick_map_recs = [quick_map_rec for quick_map_rec in quick_map_records if not (quick_map_rec[bgmvf.BG_QUICK_MAP_BUDGET_ID] == budget_ID)]
    return quick_map_recs

def get_BG_quick_map_budget_ID(quick_map_rec = dict):
    return quick_map_rec[bgmvf.BG_QUICK_MAP_BUDGET_ID]

def set_BG_quick_map_budget_ID(quick_map_rec = dict, value = str):
    quick_map_rec[bgmvf.BG_QUICK_MAP_BUDGET_ID] = value
    # Unconventional, but allows us to use in list comprehensions to set values.
    return quick_map_rec

def get_BG_quick_map_mod_ID(quick_map_rec = dict):
    return quick_map_rec[bgmvf.BG_QUICK_MAP_MOD_ID]

def set_BG_quick_map_mod_ID(quick_map_rec = dict, value = int):
    quick_map_rec[bgmvf.BG_QUICK_MAP_MOD_ID] = value
    return quick_map_rec

def get_BG_quick_map_target_ID(quick_map_rec = dict):
    return quick_map_rec[bgmvf.BG_QUICK_MAP_TARGET_ID]

def set_BG_quick_map_target_ID(quick_map_rec = dict, value = int):
    quick_map_rec[bgmvf.BG_QUICK_MAP_TARGET_ID] = value
    return quick_map_rec

def get_BG_quick_map_ind_type_ID(quick_map_rec = dict):
    return quick_map_rec[bgmvf.BG_QUICK_MAP_IND_TYPE_ID]

def set_BG_quick_map_ind_type_ID(quick_map_rec = dict, value = int):
    quick_map_rec[bgmvf.BG_QUICK_MAP_IND_TYPE_ID] = value
    return quick_map_rec

def get_BG_quick_map_is_aggregate(quick_map_rec = dict):
    return quick_map_rec[bgmvf.BG_QUICK_MAP_IS_AGGREGATE]

def set_BG_quick_map_is_aggregate(quick_map_rec = dict, value = bool):
    quick_map_rec[bgmvf.BG_QUICK_MAP_IS_AGGREGATE] = value

def get_BG_quick_map_on(quick_map_rec = dict):
    return quick_map_rec[bgmvf.BG_QUICK_MAP_ON]

def set_BG_quick_map_on(quick_map_rec = dict, value = bool):
    quick_map_rec[bgmvf.BG_QUICK_MAP_ON] = value

# def get_BG_quick_map_deliv_chan_IC(quick_map_rec = dict):
#     return quick_map_rec[bgmvf.BG_QUICK_MAP_DELIV_CHAN_ID_IC]

# def set_BG_quick_map_deliv_chan_IC(quick_map_rec = dict, value = str):
#     quick_map_rec[bgmvf.BG_QUICK_MAP_DELIV_CHAN_ID_IC] = value

def get_BG_quick_map_on_search(quick_map_records = list, budget_ID = str, mod_ID = int, target_ID = int, ind_type_ID = int):
    quick_map_recs = [quick_map_rec for quick_map_rec in quick_map_records if (
        (quick_map_rec[bgmvf.BG_QUICK_MAP_BUDGET_ID] == budget_ID)
        and (quick_map_rec[bgmvf.BG_QUICK_MAP_MOD_ID] == mod_ID)
        and (quick_map_rec[bgmvf.BG_QUICK_MAP_TARGET_ID] == target_ID)
        and (quick_map_rec[bgmvf.BG_QUICK_MAP_IND_TYPE_ID] == ind_type_ID)
    )]
    return quick_map_recs[0][bgmvf.BG_QUICK_MAP_ON] if len(quick_map_recs) > 0 else False

#######################################################################################################
#                                                                                                     #
#                                       Funding source share records                                  #
#                                                                                                     #
#######################################################################################################

def get_BG_fund_source_share_rec_from_curr_ID(fund_source_share_records = list, curr_ID = int):
    return fund_source_share_records[curr_ID - 1]

def get_BG_fund_source_share_fund_framework_ID(fund_source_share_record = dict):
    return fund_source_share_record[bgmvf.BG_FUND_SOURCE_SHARE_FW_ID]

def get_BG_fund_source_share_fund_source_ID(fund_source_share_record = dict):
    return fund_source_share_record[bgmvf.BG_FUND_SOURCE_SHARE_FUND_SOURCE_ID]

def get_BG_fund_source_share_budget_ID(fund_source_share_record = dict):
    return fund_source_share_record[bgmvf.BG_FUND_SOURCE_SHARE_BUDGET_ID]

def set_BG_fund_source_share_budget_ID(fund_source_share_record = dict, budget_ID = str):
    fund_source_share_record[bgmvf.BG_FUND_SOURCE_SHARE_BUDGET_ID] = budget_ID
    # Unconventional, but allows us to use in list comprehensions to set values.
    return fund_source_share_record

def get_BG_fund_source_share_mod_ID(fund_source_share_record = dict):
    return fund_source_share_record[bgmvf.BG_FUND_SOURCE_SHARE_MOD_ID]

def set_BG_fund_source_share_mod_ID(fund_source_share_record = dict, mod_ID = int):
    fund_source_share_record[bgmvf.BG_FUND_SOURCE_SHARE_MOD_ID] = mod_ID

def get_BG_fund_source_share_ind_type_ID(fund_source_share_record = dict):
    return fund_source_share_record[bgmvf.BG_FUND_SOURCE_SHARE_IND_TYPE_ID]

def set_BG_fund_source_share_ind_type_ID(fund_source_share_record = dict, ind_type_ID = int):
    fund_source_share_record[bgmvf.BG_FUND_SOURCE_SHARE_IND_TYPE_ID] = ind_type_ID

def get_BG_fund_source_share_ind_ID(fund_source_share_record = dict):
    return fund_source_share_record[bgmvf.BG_FUND_SOURCE_SHARE_IND_ID]

def set_BG_fund_source_share_ind_ID(fund_source_share_record = dict, ind_ID = int):
    fund_source_share_record[bgmvf.BG_FUND_SOURCE_SHARE_IND_ID] = ind_ID

def get_BG_fund_source_share_deliv_chan_ID(fund_source_share_record = dict):
    return fund_source_share_record[bgmvf.BG_FUND_SOURCE_SHARE_DELIV_CHAN_ID]

def set_BG_fund_source_share_deliv_chan_ID(fund_source_share_record = dict, ind_ID = int):
    fund_source_share_record[bgmvf.BG_FUND_SOURCE_SHARE_DELIV_CHAN_ID] = ind_ID

def get_BG_fund_source_share_prog_area_ID_PC(fund_source_share_rec = dict):
    return fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_PROG_AREA_ID_PC]

def set_BG_fund_source_share_prog_area_ID_PC(fund_source_share_rec = dict, value = str):
    fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_PROG_AREA_ID_PC] = value

def get_BG_fund_source_share_costing_sect_ID_PC(fund_source_share_rec = dict):
    return fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_COSTING_SECT_ID_PC]

def set_BG_fund_source_share_costing_sect_ID_PC(fund_source_share_rec = dict, value = str):
    fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_COSTING_SECT_ID_PC] = value

def get_BG_fund_source_share_costing_subsect_ID_PC(fund_source_share_rec = dict):
    return fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_COSTING_SUBSECT_ID_PC]

def set_BG_fund_source_share_costing_subsect_ID_PC(fund_source_share_rec = dict, value = str):
    fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_COSTING_SUBSECT_ID_PC] = value

def get_BG_fund_source_share_act_ID_PC(fund_source_share_rec = dict):
    return fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_ACT_ID_PC]

def set_BG_fund_source_share_act_ID_PC(fund_source_share_rec = dict, value = str):
    fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_ACT_ID_PC] = value

def get_BG_fund_source_share_staff_level_ID_HW(fund_source_share_rec = dict):
    return fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_STAFF_LEVEL_ID_HW]

def set_BG_fund_source_share_staff_level_ID_HW(fund_source_share_rec = dict, value = int):
    fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_STAFF_LEVEL_ID_HW] = value

def get_BG_fund_source_share_compens_type_ID_HW(fund_source_share_rec = dict):
    return fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_COMPENS_TYPE_ID_HW]

def set_BG_fund_source_share_compen_type_ID_HW(fund_source_share_rec = dict, value = int):
    fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_COMPENS_TYPE_ID_HW] = value

def get_BG_fund_source_share_costing_sect_HS_costing_ID(fund_source_share_rec = dict):
    return fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_COSTING_SECT_HS_COSTING_ID]

def set_BG_fund_source_share_costing_sect_HS_costing_ID(fund_source_share_rec = dict, value = str):
    fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_COSTING_SECT_HS_COSTING_ID] = value

def get_BG_fund_source_share_costing_subsect_HS_costing_ID(fund_source_share_rec = dict):
    return fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_COSTING_SUBSECT_HS_COSTING_ID]

def set_BG_fund_source_share_costing_subsect_HS_costing_ID(fund_source_share_rec = dict, value = str):
    fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_COSTING_SUBSECT_HS_COSTING_ID] = value

def get_BG_fund_source_share_act_HS_costing_ID(fund_source_share_rec = dict):
    return fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_ACT_HS_COSTING_ID]

def set_BG_fund_source_share_act_HS_costing_ID(fund_source_share_rec = dict, value = str):
    fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_ACT_HS_COSTING_ID] = value

def get_BG_fund_source_share_costing_sect_HS_prog_mgmt_ID(fund_source_share_rec = dict):
    return fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_COSTING_SECT_HS_PROG_MGMT_ID]

def set_BG_fund_source_share_costing_sect_HS_prog_mgmt_ID(fund_source_share_rec = dict, value = str):
    fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_COSTING_SECT_HS_PROG_MGMT_ID] = value

def get_BG_fund_source_share_costing_subsect_HS_prog_mgmt_ID(fund_source_share_rec = dict):
    return fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_COSTING_SUBSECT_HS_PROG_MGMT_ID]

def set_BG_fund_source_share_costing_subsect_HS_prog_mgmt_ID(fund_source_share_rec = dict, value = str):
    fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_COSTING_SUBSECT_HS_PROG_MGMT_ID] = value

def get_BG_fund_source_share_act_HS_prog_mgmt_ID(fund_source_share_rec = dict):
    return fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_ACT_HS_PROG_MGMT_ID]

def set_BG_fund_source_share_act_HS_prog_mgmt_ID(fund_source_share_rec = dict, value = str):
    fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_ACT_HS_PROG_MGMT_ID] = value

def get_BG_fund_source_share_costing_sect_GV_costing_ID(fund_source_share_rec = dict):
    return fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_COSTING_SECT_GV_COSTING_ID]

def set_BG_fund_source_share_costing_sect_GV_costing_ID(fund_source_share_rec = dict, value = str):
    fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_COSTING_SECT_GV_COSTING_ID] = value

def get_BG_fund_source_share_costing_subsect_GV_costing_ID(fund_source_share_rec = dict):
    return fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_COSTING_SUBSECT_GV_COSTING_ID]

def set_BG_fund_source_share_costing_subsect_GV_costing_ID(fund_source_share_rec = dict, value = str):
    fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_COSTING_SUBSECT_GV_COSTING_ID] = value

def get_BG_fund_source_share_act_GV_costing_ID(fund_source_share_rec = dict):
    return fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_ACT_GV_COSTING_ID]

def set_BG_fund_source_share_act_GV_costing_ID(fund_source_share_rec = dict, value = str):
    fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_ACT_GV_COSTING_ID] = value

def get_BG_fund_source_share_costing_sect_GV_prog_mgmt_ID(fund_source_share_rec = dict):
    return fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_COSTING_SECT_GV_PROG_MGMT_ID]

def set_BG_fund_source_share_costing_sect_GV_prog_mgmt_ID(fund_source_share_rec = dict, value = str):
    fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_COSTING_SECT_GV_PROG_MGMT_ID] = value

def get_BG_fund_source_share_costing_subsect_GV_prog_mgmt_ID(fund_source_share_rec = dict):
    return fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_COSTING_SUBSECT_GV_PROG_MGMT_ID]

def set_BG_fund_source_share_costing_subsect_GV_prog_mgmt_ID(fund_source_share_rec = dict, value = str):
    fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_COSTING_SUBSECT_GV_PROG_MGMT_ID] = value

def get_BG_fund_source_share_act_GV_prog_mgmt_ID(fund_source_share_rec = dict):
    return fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_ACT_GV_PROG_MGMT_ID]

def set_BG_fund_source_share_act_GV_prog_mgmt_ID(fund_source_share_rec = dict, value = str):
    fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_ACT_GV_PROG_MGMT_ID] = value

def get_BG_fund_source_share_costing_sect_HF_costing_ID(fund_source_share_rec = dict):
    return fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_COSTING_SECT_HF_COSTING_ID]

def set_BG_fund_source_share_costing_sect_HF_costing_ID(fund_source_share_rec = dict, value = str):
    fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_COSTING_SECT_HF_COSTING_ID] = value

def get_BG_fund_source_share_costing_subsect_HF_costing_ID(fund_source_share_rec = dict):
    return fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_COSTING_SUBSECT_HF_COSTING_ID]

def set_BG_fund_source_share_costing_subsect_HF_costing_ID(fund_source_share_rec = dict, value = str):
    fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_COSTING_SUBSECT_HF_COSTING_ID] = value

def get_BG_fund_source_share_act_HF_costing_ID(fund_source_share_rec = dict):
    return fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_ACT_HF_COSTING_ID]

def set_BG_fund_source_share_act_HF_costing_ID(fund_source_share_rec = dict, value = str):
    fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_ACT_HF_COSTING_ID] = value

def get_BG_fund_source_share_costing_sect_HF_prog_mgmt_ID(fund_source_share_rec = dict):
    return fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_COSTING_SECT_HF_PROG_MGMT_ID]

def set_BG_fund_source_share_costing_sect_HF_prog_mgmt_ID(fund_source_share_rec = dict, value = str):
    fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_COSTING_SECT_HF_PROG_MGMT_ID] = value

def get_BG_fund_source_share_costing_subsect_HF_prog_mgmt_ID(fund_source_share_rec = dict):
    return fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_COSTING_SUBSECT_HF_PROG_MGMT_ID]

def set_BG_fund_source_share_costing_subsect_HF_prog_mgmt_ID(fund_source_share_rec = dict, value = str):
    fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_COSTING_SUBSECT_HF_PROG_MGMT_ID] = value

def get_BG_fund_source_share_act_HF_prog_mgmt_ID(fund_source_share_rec = dict):
    return fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_ACT_HF_PROG_MGMT_ID]

def set_BG_fund_source_share_act_HF_prog_mgmt_ID(fund_source_share_rec = dict, value = str):
    fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_ACT_HF_PROG_MGMT_ID] = value

# Currently unused
def get_BG_fund_source_share_idx(fund_source_share_records = list, budget_ID = str, mod_ID = int, ind_type_ID = int, ind_ID = str, deliv_chan_ID = str, fund_framework_ID = str, fund_source_ID = str):
    indices = [idx for (idx, fund_source_share_rec) in enumerate(fund_source_share_records) if (
        (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_BUDGET_ID] == budget_ID) 
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_MOD_ID] == mod_ID) 
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_IND_TYPE_ID] == ind_type_ID) 
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_IND_ID] == ind_ID) 
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_DELIV_CHAN_ID] == deliv_chan_ID)
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_FW_ID] == fund_framework_ID) 
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_FUND_SOURCE_ID] == fund_source_ID) 
    )]
    return indices[0] if len(indices) > 0 else gbc.GB_NOT_FOUND

# Currently unused
def get_BG_fund_source_share_idx_and_rec(fund_source_share_records = list, budget_ID = str, mod_ID = int, ind_type_ID = int, ind_ID = str, deliv_chan_ID = str, fund_framework_ID = str, fund_source_ID = str):
    indices_and_recs = [(idx, fund_source_share_rec) for (idx, fund_source_share_rec) in enumerate(fund_source_share_records) if (
        (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_BUDGET_ID] == budget_ID) 
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_MOD_ID] == mod_ID) 
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_IND_TYPE_ID] == ind_type_ID) 
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_IND_ID] == ind_ID) 
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_DELIV_CHAN_ID] == deliv_chan_ID)
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_FW_ID] == fund_framework_ID) 
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_FUND_SOURCE_ID] == fund_source_ID) 
    )]
    return indices_and_recs[0] if len(indices_and_recs) > 0 else (gbc.GB_NOT_FOUND, {})

# Currently unused
def get_BG_fund_source_share_records_unallocated_IC(fund_source_share_records = list, budget_ID = str, ind_type_ID = int, ind_ID = str, deliv_chan_ID = str, fund_framework_ID = str):
    records_reduced = [fund_source_share_rec for fund_source_share_rec in fund_source_share_records if (
        (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_BUDGET_ID] == budget_ID) 
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_MOD_ID] == gbc.GB_IC) 
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_IND_TYPE_ID] == ind_type_ID) 
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_IND_ID] == ind_ID) 
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_DELIV_CHAN_ID] == deliv_chan_ID)
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_FW_ID] == fund_framework_ID)
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_FUND_SOURCE_ID] != str(bgc.BG_FS_UNALLOCATED_MST_ID)) 
    )]
    return records_reduced if len(records_reduced) > 0 else gbc.GB_NOT_FOUND

# For this method and the ones like it, specify all possible params needed for an indicator and just pass in -1 or "-1" for the params that are not
# applicable to a particular indicator type.  That will save us from having to make multiple methods.

def get_BG_fund_source_share_indices_and_records_all_sources_IC(fund_source_share_records = list, budget_ID = str, ind_type_ID = int, ind_ID = str, deliv_chan_ID = str, prog_area_ID = str, fund_framework_ID = str):
    indices_and_recs = [(idx, fund_source_share_rec) for (idx, fund_source_share_rec) in enumerate(fund_source_share_records) if (
        (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_BUDGET_ID] == budget_ID) 
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_MOD_ID] == gbc.GB_IC) 
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_IND_TYPE_ID] == ind_type_ID) 
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_IND_ID] == ind_ID) 
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_DELIV_CHAN_ID] == deliv_chan_ID)
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_PROG_AREA_ID_PC] == prog_area_ID)
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_FW_ID] == fund_framework_ID)
    )]
    return indices_and_recs if len(indices_and_recs) > 0 else (gbc.GB_NOT_FOUND, {})

def get_BG_fund_source_share_indices_and_records_all_sources_PC(fund_source_share_records = list, budget_ID = str, ind_type_ID = int, prog_area_ID = str, costing_sect_ID = str, costing_subsect_ID = str, act_ID = str, fund_framework_ID = str):
    indices_and_recs = [(idx, fund_source_share_rec) for (idx, fund_source_share_rec) in enumerate(fund_source_share_records) if (
        (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_BUDGET_ID] == budget_ID) 
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_MOD_ID] == gbc.GB_PC) 
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_IND_TYPE_ID] == ind_type_ID) 
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_PROG_AREA_ID_PC] == prog_area_ID) 
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_COSTING_SECT_ID_PC] == costing_sect_ID) 
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_COSTING_SUBSECT_ID_PC] == costing_subsect_ID) 
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_ACT_ID_PC] == act_ID) 
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_FW_ID] == fund_framework_ID)
    )]
    return indices_and_recs if len(indices_and_recs) > 0 else (gbc.GB_NOT_FOUND, {})

def get_BG_fund_source_share_indices_and_records_all_sources_IS_non_prog_mgmt(
        fund_source_share_records = list, budget_ID = str, ind_type_ID = int, ind_ID = str, prog_area_ID = str, fund_framework_ID = str
):
    indices_and_recs = [(idx, fund_source_share_rec) for (idx, fund_source_share_rec) in enumerate(fund_source_share_records) if (
        (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_BUDGET_ID] == budget_ID) 
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_MOD_ID] == gbc.GB_IS) 
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_IND_TYPE_ID] == ind_type_ID) 
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_IND_ID] == ind_ID) 
        and (prog_area_ID is None or fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_PROG_AREA_ID_PC] == prog_area_ID) 
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_FW_ID] == fund_framework_ID)
    )]
    return indices_and_recs if len(indices_and_recs) > 0 else (gbc.GB_NOT_FOUND, {})

def get_BG_fund_source_share_indices_and_records_all_sources_IS_prog_mgmt(fund_source_share_records = list, budget_ID = str, ind_type_ID = int, costing_sect_ID = str, costing_subsect_ID = str, act_ID = str, fund_framework_ID = str):
    indices_and_recs = [(idx, fund_source_share_rec) for (idx, fund_source_share_rec) in enumerate(fund_source_share_records) if (
        (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_BUDGET_ID] == budget_ID) 
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_MOD_ID] == gbc.GB_IS) 
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_IND_TYPE_ID] == ind_type_ID) 
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_COSTING_SECT_ID_PC] == costing_sect_ID) 
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_COSTING_SUBSECT_ID_PC] == costing_subsect_ID) 
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_ACT_ID_PC] == act_ID) 
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_FW_ID] == fund_framework_ID)
    )]
    return indices_and_recs if len(indices_and_recs) > 0 else (gbc.GB_NOT_FOUND, {})

def get_BG_fund_source_share_indices_and_records_all_sources_HW_non_prog_mgmt(fund_source_share_records = list, budget_ID = str, ind_type_ID = int, staff_level_ID = int, compens_type_ID = int, dynamic_staff_type_ID = str, fund_framework_ID = str):
    indices_and_recs = [(idx, fund_source_share_rec) for (idx, fund_source_share_rec) in enumerate(fund_source_share_records) if (
        (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_BUDGET_ID] == budget_ID) 
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_MOD_ID] == gbc.GB_HW) 
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_IND_TYPE_ID] == ind_type_ID) 
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_STAFF_LEVEL_ID_HW] == staff_level_ID) 
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_COMPENS_TYPE_ID_HW] == compens_type_ID) 
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_IND_ID] == dynamic_staff_type_ID) 
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_FW_ID] == fund_framework_ID)
    )]
    return indices_and_recs if len(indices_and_recs) > 0 else (gbc.GB_NOT_FOUND, {})

def get_BG_fund_source_share_indices_and_records_all_sources_HW_prog_mgmt(fund_source_share_records = list, budget_ID = str, ind_type_ID = int, costing_sect_ID = str, costing_subsect_ID = str, act_ID = str, fund_framework_ID = str):
    indices_and_recs = [(idx, fund_source_share_rec) for (idx, fund_source_share_rec) in enumerate(fund_source_share_records) if (
        (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_BUDGET_ID] == budget_ID) 
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_MOD_ID] == gbc.GB_HW) 
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_IND_TYPE_ID] == ind_type_ID) 
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_COSTING_SECT_ID_PC] == costing_sect_ID) 
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_COSTING_SUBSECT_ID_PC] == costing_subsect_ID) 
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_ACT_ID_PC] == act_ID) 
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_FW_ID] == fund_framework_ID)
    )]
    return indices_and_recs if len(indices_and_recs) > 0 else (gbc.GB_NOT_FOUND, {})

def get_BG_fund_source_share_indices_and_records_all_sources_HS_costing(fund_source_share_records = list, budget_ID = str, ind_type_ID = int, costing_sect_ID = str, costing_subsect_ID = str, act_ID = str, fund_framework_ID = str):
    indices_and_recs = [(idx, fund_source_share_rec) for (idx, fund_source_share_rec) in enumerate(fund_source_share_records) if (
        (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_BUDGET_ID] == budget_ID) 
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_MOD_ID] == gbc.GB_HS) 
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_IND_TYPE_ID] == ind_type_ID) 
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_COSTING_SECT_HS_COSTING_ID] == costing_sect_ID) 
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_COSTING_SUBSECT_HS_COSTING_ID] == costing_subsect_ID) 
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_ACT_HS_COSTING_ID] == act_ID) 
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_FW_ID] == fund_framework_ID)
    )]
    return indices_and_recs if len(indices_and_recs) > 0 else (gbc.GB_NOT_FOUND, {})

def get_BG_fund_source_share_indices_and_records_all_sources_HS_prog_mgmt(fund_source_share_records = list, budget_ID = str, ind_type_ID = int, costing_sect_ID = str, costing_subsect_ID = str, act_ID = str, fund_framework_ID = str):
    indices_and_recs = [(idx, fund_source_share_rec) for (idx, fund_source_share_rec) in enumerate(fund_source_share_records) if (
        (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_BUDGET_ID] == budget_ID) 
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_MOD_ID] == gbc.GB_HS) 
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_IND_TYPE_ID] == ind_type_ID) 
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_COSTING_SECT_HS_PROG_MGMT_ID] == costing_sect_ID) 
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_COSTING_SUBSECT_HS_PROG_MGMT_ID] == costing_subsect_ID) 
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_ACT_HS_PROG_MGMT_ID] == act_ID) 
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_FW_ID] == fund_framework_ID)
    )]
    return indices_and_recs if len(indices_and_recs) > 0 else (gbc.GB_NOT_FOUND, {})

def get_BG_fund_source_share_indices_and_records_all_sources_GV_costing(fund_source_share_records = list, budget_ID = str, ind_type_ID = int, costing_sect_ID = str, costing_subsect_ID = str, act_ID = str, fund_framework_ID = str):
    indices_and_recs = [(idx, fund_source_share_rec) for (idx, fund_source_share_rec) in enumerate(fund_source_share_records) if (
        (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_BUDGET_ID] == budget_ID) 
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_MOD_ID] == gbc.GB_GV) 
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_IND_TYPE_ID] == ind_type_ID) 
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_COSTING_SECT_GV_COSTING_ID] == costing_sect_ID) 
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_COSTING_SUBSECT_GV_COSTING_ID] == costing_subsect_ID) 
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_ACT_GV_COSTING_ID] == act_ID) 
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_FW_ID] == fund_framework_ID)
    )]
    return indices_and_recs if len(indices_and_recs) > 0 else (gbc.GB_NOT_FOUND, {})

def get_BG_fund_source_share_indices_and_records_all_sources_GV_prog_mgmt(fund_source_share_records = list, budget_ID = str, ind_type_ID = int, costing_sect_ID = str, costing_subsect_ID = str, act_ID = str, fund_framework_ID = str):
    indices_and_recs = [(idx, fund_source_share_rec) for (idx, fund_source_share_rec) in enumerate(fund_source_share_records) if (
        (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_BUDGET_ID] == budget_ID) 
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_MOD_ID] == gbc.GB_GV) 
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_IND_TYPE_ID] == ind_type_ID) 
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_COSTING_SECT_GV_PROG_MGMT_ID] == costing_sect_ID) 
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_COSTING_SUBSECT_GV_PROG_MGMT_ID] == costing_subsect_ID) 
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_ACT_GV_PROG_MGMT_ID] == act_ID) 
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_FW_ID] == fund_framework_ID)
    )]
    return indices_and_recs if len(indices_and_recs) > 0 else (gbc.GB_NOT_FOUND, {})

def get_BG_fund_source_share_indices_and_records_all_sources_HF_costing(fund_source_share_records = list, budget_ID = str, ind_type_ID = int, costing_sect_ID = str, costing_subsect_ID = str, act_ID = str, fund_framework_ID = str):
    indices_and_recs = [(idx, fund_source_share_rec) for (idx, fund_source_share_rec) in enumerate(fund_source_share_records) if (
        (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_BUDGET_ID] == budget_ID) 
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_MOD_ID] == gbc.GB_HF) 
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_IND_TYPE_ID] == ind_type_ID) 
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_COSTING_SECT_HF_COSTING_ID] == costing_sect_ID) 
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_COSTING_SUBSECT_HF_COSTING_ID] == costing_subsect_ID) 
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_ACT_HF_COSTING_ID] == act_ID) 
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_FW_ID] == fund_framework_ID)
    )]
    return indices_and_recs if len(indices_and_recs) > 0 else (gbc.GB_NOT_FOUND, {})

def get_BG_fund_source_share_indices_and_records_all_sources_HF_prog_mgmt(fund_source_share_records = list, budget_ID = str, ind_type_ID = int, costing_sect_ID = str, costing_subsect_ID = str, act_ID = str, fund_framework_ID = str):
    indices_and_recs = [(idx, fund_source_share_rec) for (idx, fund_source_share_rec) in enumerate(fund_source_share_records) if (
        (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_BUDGET_ID] == budget_ID) 
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_MOD_ID] == gbc.GB_HF) 
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_IND_TYPE_ID] == ind_type_ID) 
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_COSTING_SECT_HF_PROG_MGMT_ID] == costing_sect_ID) 
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_COSTING_SUBSECT_HF_PROG_MGMT_ID] == costing_subsect_ID) 
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_ACT_HF_PROG_MGMT_ID] == act_ID) 
        and (fund_source_share_rec[bgmvf.BG_FUND_SOURCE_SHARE_FW_ID] == fund_framework_ID)
    )]
    return indices_and_recs if len(indices_and_recs) > 0 else (gbc.GB_NOT_FOUND, {})

def get_BG_fund_source_share_records_for_budget(fund_source_share_records = list, budget_ID = str):
    fund_source_share_records_value = [share_rec for share_rec in fund_source_share_records if 
        (get_BG_fund_source_share_budget_ID(share_rec) == budget_ID)]
    return fund_source_share_records_value

def remove_BG_fund_source_share_records_for_budget(fund_source_share_records: list, budget_ID: str):
    fund_source_share_records_value = [share_rec for share_rec in fund_source_share_records if 
        (not get_BG_fund_source_share_budget_ID(share_rec) == budget_ID)]
    return fund_source_share_records_value

def remove_BG_fund_source_share_rec_at_curr_ID(fund_source_share_records = list, curr_ID = int):
    return fund_source_share_records.pop(curr_ID - 1)

def remove_BG_fund_source_share_records_for_framework(fund_source_share_records = list, fund_framework_ID = str):
    fund_source_share_records_value = [share_rec for share_rec in fund_source_share_records if 
        (get_BG_fund_source_share_fund_framework_ID(share_rec) != fund_framework_ID)]
    return fund_source_share_records_value

def remove_BG_fund_source_share_records(fund_source_share_records = list, fund_framework_ID = str, fund_source_ID = str):
    fund_source_share_records_value = [share_rec for share_rec in fund_source_share_records if 
        (not ((get_BG_fund_source_share_fund_framework_ID(share_rec) == fund_framework_ID) and 
        (get_BG_fund_source_share_fund_source_ID(share_rec) == fund_source_ID)))]
    return fund_source_share_records_value

# For this method and the ones like it, specify all possible params needed for an indicator and just pass in -1 or "-1" for the params that are not
# applicable to a particular indicator type.  That will save us from having to make multiple methods.
#
# These are only set up differently for each module because IC used to be different.

def remove_BG_fund_source_share_records_IC(fund_source_share_records = list, budget_ID = str, ind_type_ID = int, fund_framework_ID = str):#deliv_chan_ID = str, fund_framework_ID = str):
    fund_source_share_records_value = [share_rec for share_rec in fund_source_share_records if 
        (not ((get_BG_fund_source_share_budget_ID(share_rec) == budget_ID)
        and (get_BG_fund_source_share_ind_type_ID(share_rec) == ind_type_ID)
        #and (get_BG_fund_source_share_deliv_chan_ID(share_rec) == deliv_chan_ID)
        and (get_BG_fund_source_share_fund_framework_ID(share_rec) == fund_framework_ID)))]
    return fund_source_share_records_value

def remove_BG_fund_source_share_records_PC(fund_source_share_records = list, budget_ID = str, ind_type_ID = int, fund_framework_ID = str):
    fund_source_share_records_value = [share_rec for share_rec in fund_source_share_records if 
        (not ((get_BG_fund_source_share_budget_ID(share_rec) == budget_ID)
        and (get_BG_fund_source_share_ind_type_ID(share_rec) == ind_type_ID)
        and (get_BG_fund_source_share_fund_framework_ID(share_rec) == fund_framework_ID)))]
    return fund_source_share_records_value

def remove_BG_fund_source_share_records_IS(fund_source_share_records = list, budget_ID = str, ind_type_ID = int, fund_framework_ID = str):
    fund_source_share_records_value = [share_rec for share_rec in fund_source_share_records if 
        (not ((get_BG_fund_source_share_budget_ID(share_rec) == budget_ID)
        and (get_BG_fund_source_share_ind_type_ID(share_rec) == ind_type_ID)
        and (get_BG_fund_source_share_fund_framework_ID(share_rec) == fund_framework_ID)))]
    return fund_source_share_records_value

def remove_BG_fund_source_share_records_HW(fund_source_share_records = list, budget_ID = str, ind_type_ID = int, fund_framework_ID = str):
    fund_source_share_records_value = [share_rec for share_rec in fund_source_share_records if 
        (not ((get_BG_fund_source_share_budget_ID(share_rec) == budget_ID)
        and (get_BG_fund_source_share_ind_type_ID(share_rec) == ind_type_ID)
        and (get_BG_fund_source_share_fund_framework_ID(share_rec) == fund_framework_ID)))]
    return fund_source_share_records_value

def remove_BG_fund_source_share_records_HS(fund_source_share_records = list, budget_ID = str, ind_type_ID = int, fund_framework_ID = str):
    fund_source_share_records_value = [share_rec for share_rec in fund_source_share_records if 
        (not ((get_BG_fund_source_share_budget_ID(share_rec) == budget_ID)
        and (get_BG_fund_source_share_ind_type_ID(share_rec) == ind_type_ID)
        and (get_BG_fund_source_share_fund_framework_ID(share_rec) == fund_framework_ID)))]
    return fund_source_share_records_value

def remove_BG_fund_source_share_records_GV(fund_source_share_records = list, budget_ID = str, ind_type_ID = int, fund_framework_ID = str):
    fund_source_share_records_value = [share_rec for share_rec in fund_source_share_records if 
        (not ((get_BG_fund_source_share_budget_ID(share_rec) == budget_ID)
        and (get_BG_fund_source_share_ind_type_ID(share_rec) == ind_type_ID)
        and (get_BG_fund_source_share_fund_framework_ID(share_rec) == fund_framework_ID)))]
    return fund_source_share_records_value

def remove_BG_fund_source_share_records_HF(fund_source_share_records = list, budget_ID = str, ind_type_ID = int, fund_framework_ID = str):
    fund_source_share_records_value = [share_rec for share_rec in fund_source_share_records if 
        (not ((get_BG_fund_source_share_budget_ID(share_rec) == budget_ID)
        and (get_BG_fund_source_share_ind_type_ID(share_rec) == ind_type_ID)
        and (get_BG_fund_source_share_fund_framework_ID(share_rec) == fund_framework_ID)))]
    return fund_source_share_records_value

# For this method and the ones like it, specify all possible params needed for an indicator and just pass in -1 or "-1" for the params that are not
# applicable to a particular indicator type.  That will save us from having to make multiple methods.
#
# These are only set up differently for each module because IC used to be different.

def remove_BG_fund_source_share_records_IC_all_budgets(fund_source_share_records = list, ind_type_ID = int, fund_framework_ID = str): #deliv_chan_ID = str, fund_framework_ID = str):
    fund_source_share_records_value = [share_rec for share_rec in fund_source_share_records if 
        (not ((get_BG_fund_source_share_ind_type_ID(share_rec) == ind_type_ID)
        #and (get_BG_fund_source_share_deliv_chan_ID(share_rec) == deliv_chan_ID)
        and (get_BG_fund_source_share_fund_framework_ID(share_rec) == fund_framework_ID)))]
    return fund_source_share_records_value

def remove_BG_fund_source_share_records_PC_all_budgets(fund_source_share_records = list, ind_type_ID = int, fund_framework_ID = str):
    fund_source_share_records_value = [share_rec for share_rec in fund_source_share_records if 
        (not ((get_BG_fund_source_share_ind_type_ID(share_rec) == ind_type_ID)
        and (get_BG_fund_source_share_fund_framework_ID(share_rec) == fund_framework_ID)))]
    return fund_source_share_records_value

def remove_BG_fund_source_share_records_IS_all_budgets(fund_source_share_records = list, ind_type_ID = int, fund_framework_ID = str):
    fund_source_share_records_value = [share_rec for share_rec in fund_source_share_records if 
        (not ((get_BG_fund_source_share_ind_type_ID(share_rec) == ind_type_ID)
        and (get_BG_fund_source_share_fund_framework_ID(share_rec) == fund_framework_ID)))]
    return fund_source_share_records_value

def remove_BG_fund_source_share_records_HW_all_budgets(fund_source_share_records = list, ind_type_ID = int, fund_framework_ID = str):
    fund_source_share_records_value = [share_rec for share_rec in fund_source_share_records if 
        (not ((get_BG_fund_source_share_ind_type_ID(share_rec) == ind_type_ID)
        and (get_BG_fund_source_share_fund_framework_ID(share_rec) == fund_framework_ID)))]
    return fund_source_share_records_value

def remove_BG_fund_source_share_records_HS_all_budgets(fund_source_share_records = list, ind_type_ID = int, fund_framework_ID = str):
    fund_source_share_records_value = [share_rec for share_rec in fund_source_share_records if 
        (not ((get_BG_fund_source_share_ind_type_ID(share_rec) == ind_type_ID)
        and (get_BG_fund_source_share_fund_framework_ID(share_rec) == fund_framework_ID)))]
    return fund_source_share_records_value

def remove_BG_fund_source_share_records_GV_all_budgets(fund_source_share_records = list, ind_type_ID = int, fund_framework_ID = str):
    fund_source_share_records_value = [share_rec for share_rec in fund_source_share_records if 
        (not ((get_BG_fund_source_share_ind_type_ID(share_rec) == ind_type_ID)
        and (get_BG_fund_source_share_fund_framework_ID(share_rec) == fund_framework_ID)))]
    return fund_source_share_records_value

def remove_BG_fund_source_share_records_HF_all_budgets(fund_source_share_records = list, ind_type_ID = int, fund_framework_ID = str):
    fund_source_share_records_value = [share_rec for share_rec in fund_source_share_records if 
        (not ((get_BG_fund_source_share_ind_type_ID(share_rec) == ind_type_ID)
        and (get_BG_fund_source_share_fund_framework_ID(share_rec) == fund_framework_ID)))]
    return fund_source_share_records_value

# Change the budget ID of a funding source share record. Useful when copying a budget.
def change_BG_fund_source_share_budget_ID(fund_source_share_records = list, budget_ID = str):
    fund_source_share_recs = [set_BG_fund_source_share_budget_ID(fund_source_share_rec, budget_ID) for fund_source_share_rec in fund_source_share_records]
    return fund_source_share_recs

def get_BG_fund_source_share_value(fund_source_share_record = dict):
    return fund_source_share_record[bgmvf.BG_FUND_SOURCE_SHARE_VALUE]

def set_BG_fund_source_share_value(fund_source_share_record = dict, value = float):
    fund_source_share_record[bgmvf.BG_FUND_SOURCE_SHARE_VALUE] = value

#######################################################################################################
#                                                                                                     #
#                                       Budget category share records                                 #
#                                                                                                     #
#######################################################################################################

def get_BG_budget_cat_share_record_IC_prog_area(budget_cat_share_records = list, budget_ID = str, ind_type_ID = int, ind_ID = str, budget_cat_ID = str, prog_area_ID = str):
    budget_cat_share_recs_reduced = [budget_cat_share_rec for budget_cat_share_rec in budget_cat_share_records if (
        (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_BUDGET_ID] == budget_ID)
        and (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_IND_TYPE_ID] == ind_type_ID)
        and (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_IND_ID] == ind_ID)
        and (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_BUDGET_CAT_ID] == budget_cat_ID)
        and (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_PROG_AREA_ID_PC] == prog_area_ID)
    )]
    return budget_cat_share_recs_reduced[0] if len(budget_cat_share_recs_reduced) > 0 else gbc.GB_NOT_FOUND

def get_BG_budget_cat_share_rec_from_curr_ID(budget_cat_share_records = list, curr_ID = int):
    return budget_cat_share_records[curr_ID - 1]

def get_BG_budget_cat_share_budget_ID(budget_cat_share_record = dict):
    return budget_cat_share_record[bgmvf.BG_BUDGET_CAT_SHARE_BUDGET_ID]

def set_BG_budget_cat_share_budget_ID(budget_cat_share_record = dict, budget_ID = str):
    budget_cat_share_record[bgmvf.BG_BUDGET_CAT_SHARE_BUDGET_ID] = budget_ID
    # Unconventional, but allows us to use in list comprehensions to set values.
    return budget_cat_share_record

def get_BG_budget_cat_share_mod_ID(budget_cat_share_record = dict):
    return budget_cat_share_record[bgmvf.BG_BUDGET_CAT_SHARE_MOD_ID]

def set_BG_budget_cat_share_mod_ID(budget_cat_share_record = dict, mod_ID = str):
    budget_cat_share_record[bgmvf.BG_BUDGET_CAT_SHARE_MOD_ID] = mod_ID

def get_BG_budget_cat_share_ind_type_ID(budget_cat_share_record = dict):
    return budget_cat_share_record[bgmvf.BG_BUDGET_CAT_SHARE_IND_TYPE_ID]

def set_BG_budget_cat_share_ind_type_ID(budget_cat_share_record = dict, ind_type_ID = str):
    budget_cat_share_record[bgmvf.BG_BUDGET_CAT_SHARE_IND_TYPE_ID] = ind_type_ID

def get_BG_budget_cat_share_ind_ID(budget_cat_share_record = dict):
    return budget_cat_share_record[bgmvf.BG_BUDGET_CAT_SHARE_IND_ID]

def set_BG_budget_cat_share_ind_ID(budget_cat_share_record = dict, ind_ID = str):
    budget_cat_share_record[bgmvf.BG_BUDGET_CAT_SHARE_IND_ID] = ind_ID

def get_BG_budget_cat_share_deliv_chan_ID(budget_cat_share_record = dict):
    return budget_cat_share_record[bgmvf.BG_BUDGET_CAT_SHARE_DELIV_CHAN_ID]

def set_BG_budget_cat_share_deliv_chan_ID(budget_cat_share_record = dict, deliv_chan_ID = str):
    budget_cat_share_record[bgmvf.BG_BUDGET_CAT_SHARE_DELIV_CHAN_ID] = deliv_chan_ID

def get_BG_budget_cat_share_prog_area_ID_PC(budget_cat_share_rec = dict):
    return budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_PROG_AREA_ID_PC]

def set_BG_budget_cat_share_prog_area_ID_PC(budget_cat_share_rec = dict, value = str):
    budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_PROG_AREA_ID_PC] = value

def get_BG_budget_cat_share_costing_sect_ID_PC(budget_cat_share_rec = dict):
    return budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_COSTING_SECT_ID_PC]

def set_BG_budget_cat_share_costing_sect_ID_PC(budget_cat_share_rec = dict, value = str):
    budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_COSTING_SECT_ID_PC] = value

def get_BG_budget_cat_share_costing_subsect_ID_PC(budget_cat_share_rec = dict):
    return budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_COSTING_SUBSECT_ID_PC]

def set_BG_budget_cat_share_costing_subsect_ID_PC(budget_cat_share_rec = dict, value = str):
    budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_COSTING_SUBSECT_ID_PC] = value

def get_BG_budget_cat_share_act_ID_PC(budget_cat_share_rec = dict):
    return budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_ACT_ID_PC]

def set_BG_budget_cat_share_act_ID_PC(budget_cat_share_rec = dict, value = str):
    budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_ACT_ID_PC] = value

def get_BG_budget_cat_share_staff_level_ID_PC(budget_cat_share_rec = dict):
    return budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_STAFF_LEVEL_ID_HW]

def set_BG_budget_cat_share_staff_level_ID_PC(budget_cat_share_rec = dict, value = str):
    budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_STAFF_LEVEL_ID_HW] = value

def get_BG_budget_cat_share_compens_type_ID_PC(budget_cat_share_rec = dict):
    return budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_COMPENS_TYPE_ID_HW]

def set_BG_budget_cat_share_compens_type_ID_PC(budget_cat_share_rec = dict, value = str):
    budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_COMPENS_TYPE_ID_HW] = value

def get_BG_budget_cat_share_staff_level_ID_HW(budget_cat_share_rec = dict):
    return budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_STAFF_LEVEL_ID_HW]

def set_BG_budget_cat_share_staff_level_ID_HW(budget_cat_share_rec = dict, value = int):
    budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_STAFF_LEVEL_ID_HW] = value

def get_BG_budget_cat_share_compens_type_ID_HW(budget_cat_share_rec = dict):
    return budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_COMPENS_TYPE_ID_HW]

def set_BG_budget_cat_share_compen_type_ID_HW(budget_cat_share_rec = dict, value = int):
    budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_COMPENS_TYPE_ID_HW] = value

def get_BG_budget_cat_share_budget_cat_ID(budget_cat_share_rec = dict):
    return budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_BUDGET_CAT_ID]

def set_BG_budget_cat_share_value(budget_cat_share_rec = dict, value = float):
    budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_VALUE] = value

def get_BG_budget_cat_share_value(budget_cat_share_rec = dict):
    return budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_VALUE]

def get_BG_budget_cat_share_costing_sect_HS_costing_ID(budget_cat_share_rec = dict):
    return budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_COSTING_SECT_HS_COSTING_ID]

def set_BG_budget_cat_share_costing_sect_HS_costing_ID(budget_cat_share_rec = dict, value = str):
    budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_COSTING_SECT_HS_COSTING_ID] = value

def get_BG_budget_cat_share_costing_subsect_HS_costing_ID(budget_cat_share_rec = dict):
    return budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_COSTING_SUBSECT_HS_COSTING_ID]

def set_BG_budget_cat_share_costing_subsect_HS_costing_ID(budget_cat_share_rec = dict, value = str):
    budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_COSTING_SUBSECT_HS_COSTING_ID] = value

def get_BG_budget_cat_share_act_HS_costing_ID(budget_cat_share_rec = dict):
    return budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_ACT_HS_COSTING_ID]

def set_BG_budget_cat_share_act_HS_costing_ID(budget_cat_share_rec = dict, value = str):
    budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_ACT_HS_COSTING_ID] = value

def get_BG_budget_cat_share_costing_sect_HS_prog_mgmt_ID(budget_cat_share_rec = dict):
    return budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_COSTING_SECT_HS_PROG_MGMT_ID]

def set_BG_budget_cat_share_costing_sect_HS_prog_mgmt_ID(budget_cat_share_rec = dict, value = str):
    budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_COSTING_SECT_HS_PROG_MGMT_ID] = value

def get_BG_budget_cat_share_costing_subsect_HS_prog_mgmt_ID(budget_cat_share_rec = dict):
    return budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_COSTING_SUBSECT_HS_PROG_MGMT_ID]

def set_BG_budget_cat_share_costing_subsect_HS_prog_mgmt_ID(budget_cat_share_rec = dict, value = str):
    budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_COSTING_SUBSECT_HS_PROG_MGMT_ID] = value

def get_BG_budget_cat_share_act_HS_prog_mgmt_ID(budget_cat_share_rec = dict):
    return budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_ACT_HS_PROG_MGMT_ID]

def set_BG_budget_cat_share_act_HS_prog_mgmt_ID(budget_cat_share_rec = dict, value = str):
    budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_ACT_HS_PROG_MGMT_ID] = value

def get_BG_budget_cat_share_costing_sect_GV_costing_ID(budget_cat_share_rec = dict):
    return budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_COSTING_SECT_GV_COSTING_ID]

def set_BG_budget_cat_share_costing_sect_GV_costing_ID(budget_cat_share_rec = dict, value = str):
    budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_COSTING_SECT_GV_COSTING_ID] = value

def get_BG_budget_cat_share_costing_subsect_GV_costing_ID(budget_cat_share_rec = dict):
    return budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_COSTING_SUBSECT_GV_COSTING_ID]

def set_BG_budget_cat_share_costing_subsect_GV_costing_ID(budget_cat_share_rec = dict, value = str):
    budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_COSTING_SUBSECT_GV_COSTING_ID] = value

def get_BG_budget_cat_share_act_GV_costing_ID(budget_cat_share_rec = dict):
    return budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_ACT_GV_COSTING_ID]

def set_BG_budget_cat_share_act_GV_costing_ID(budget_cat_share_rec = dict, value = str):
    budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_ACT_GV_COSTING_ID] = value

def get_BG_budget_cat_share_costing_sect_GV_prog_mgmt_ID(budget_cat_share_rec = dict):
    return budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_COSTING_SECT_GV_PROG_MGMT_ID]

def set_BG_budget_cat_share_costing_sect_GV_prog_mgmt_ID(budget_cat_share_rec = dict, value = str):
    budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_COSTING_SECT_GV_PROG_MGMT_ID] = value

def get_BG_budget_cat_share_costing_subsect_GV_prog_mgmt_ID(budget_cat_share_rec = dict):
    return budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_COSTING_SUBSECT_GV_PROG_MGMT_ID]

def set_BG_budget_cat_share_costing_subsect_GV_prog_mgmt_ID(budget_cat_share_rec = dict, value = str):
    budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_COSTING_SUBSECT_GV_PROG_MGMT_ID] = value

def get_BG_budget_cat_share_act_GV_prog_mgmt_ID(budget_cat_share_rec = dict):
    return budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_ACT_GV_PROG_MGMT_ID]

def set_BG_budget_cat_share_act_GV_prog_mgmt_ID(budget_cat_share_rec = dict, value = str):
    budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_ACT_GV_PROG_MGMT_ID] = value

def get_BG_budget_cat_share_costing_sect_HF_costing_ID(budget_cat_share_rec = dict):
    return budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_COSTING_SECT_HF_COSTING_ID]

def set_BG_budget_cat_share_costing_sect_HF_costing_ID(budget_cat_share_rec = dict, value = str):
    budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_COSTING_SECT_HF_COSTING_ID] = value

def get_BG_budget_cat_share_costing_subsect_HF_costing_ID(budget_cat_share_rec = dict):
    return budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_COSTING_SUBSECT_HF_COSTING_ID]

def set_BG_budget_cat_share_costing_subsect_HF_costing_ID(budget_cat_share_rec = dict, value = str):
    budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_COSTING_SUBSECT_HF_COSTING_ID] = value

def get_BG_budget_cat_share_act_HF_costing_ID(budget_cat_share_rec = dict):
    return budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_ACT_HF_COSTING_ID]

def set_BG_budget_cat_share_act_HF_costing_ID(budget_cat_share_rec = dict, value = str):
    budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_ACT_HF_COSTING_ID] = value

def get_BG_budget_cat_share_costing_sect_HF_prog_mgmt_ID(budget_cat_share_rec = dict):
    return budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_COSTING_SECT_HF_PROG_MGMT_ID]

def set_BG_budget_cat_share_costing_sect_HF_prog_mgmt_ID(budget_cat_share_rec = dict, value = str):
    budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_COSTING_SECT_HF_PROG_MGMT_ID] = value

def get_BG_budget_cat_share_costing_subsect_HF_prog_mgmt_ID(budget_cat_share_rec = dict):
    return budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_COSTING_SUBSECT_HF_PROG_MGMT_ID]

def set_BG_budget_cat_share_costing_subsect_HF_prog_mgmt_ID(budget_cat_share_rec = dict, value = str):
    budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_COSTING_SUBSECT_HF_PROG_MGMT_ID] = value

def get_BG_budget_cat_share_act_HF_prog_mgmt_ID(budget_cat_share_rec = dict):
    return budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_ACT_HF_PROG_MGMT_ID]

def set_BG_budget_cat_share_act_HF_prog_mgmt_ID(budget_cat_share_rec = dict, value = str):
    budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_ACT_HF_PROG_MGMT_ID] = value

# Currently unused
def get_BG_budget_cat_share_idx(budget_cat_share_records = list, budget_ID = str, mod_ID = int, ind_type_ID = int, ind_ID = str, deliv_chan_ID = str, budget_cat_ID = str):
    indices = [idx for (idx, budget_cat_share_rec) in enumerate(budget_cat_share_records) if (
        (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_BUDGET_ID] == budget_ID) 
        and (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_MOD_ID] == mod_ID) 
        and (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_IND_TYPE_ID] == ind_type_ID) 
        and (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_IND_ID] == ind_ID) 
        and (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_DELIV_CHAN_ID] == deliv_chan_ID)
        and (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_BUDGET_CAT_ID] == budget_cat_ID) 
    )]
    return indices[0] if len(indices) > 0 else gbc.GB_NOT_FOUND

# Currently unused
def get_BG_budget_cat_share_idx_and_rec(budget_cat_share_records = list, budget_ID = str, mod_ID = int, ind_type_ID = int, ind_ID = str, deliv_chan_ID = str, budget_cat_ID = str):
    indices_and_recs = [(idx, budget_cat_share_rec) for (idx, budget_cat_share_rec) in enumerate(budget_cat_share_records) if (
        (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_BUDGET_ID] == budget_ID) 
        and (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_MOD_ID] == mod_ID) 
        and (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_IND_TYPE_ID] == ind_type_ID) 
        and (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_IND_ID] == ind_ID) 
        and (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_DELIV_CHAN_ID] == deliv_chan_ID)
        and (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_BUDGET_CAT_ID] == budget_cat_ID) 
    )]
    return indices_and_recs[0] if len(indices_and_recs) > 0 else (gbc.GB_NOT_FOUND, {})

# Currently unused
def get_BG_budget_cat_share_records_unallocated(budget_cat_share_records = list, budget_ID = str, mod_ID = int, ind_type_ID = int, ind_ID = str, deliv_chan_ID = str):
    records_reduced = [budget_cat_share_rec for budget_cat_share_rec in budget_cat_share_records if (
        (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_BUDGET_ID] == budget_ID) 
        and (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_MOD_ID] == mod_ID) 
        and (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_IND_TYPE_ID] == ind_type_ID) 
        and (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_IND_ID] == ind_ID) 
        and (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_DELIV_CHAN_ID] == deliv_chan_ID)
        and (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_BUDGET_CAT_ID] != str(bgc.BG_BC_UNALLOCATED_MST_ID)) 
    )]
    return records_reduced if len(records_reduced) > 0 else gbc.GB_NOT_FOUND

# For this method and the ones like it, specify all possible params needed for an indicator and just pass in -1 or "-1" for the params that are not
# applicable to a particular indicator type.  That will save us from having to make multiple methods.

def get_BG_budget_cat_share_indices_and_records_all_cats_IC(budget_cat_share_records = list, budget_ID = str, ind_type_ID = int, ind_ID = str, deliv_chan_ID = str, prog_area_ID = str):
    indices_and_recs = [(idx, budget_cat_share_rec) for (idx, budget_cat_share_rec) in enumerate(budget_cat_share_records) if (
        (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_BUDGET_ID] == budget_ID) 
        and (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_MOD_ID] == gbc.GB_IC) 
        and (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_IND_TYPE_ID] == ind_type_ID) 
        and (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_IND_ID] == ind_ID) 
        and (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_DELIV_CHAN_ID] == deliv_chan_ID)
        and (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_PROG_AREA_ID_PC] == prog_area_ID)
    )]
    return indices_and_recs if len(indices_and_recs) > 0 else (gbc.GB_NOT_FOUND, {})

def get_BG_budget_cat_share_indices_and_records_all_cats_PC(budget_cat_share_records = list, budget_ID = str, ind_type_ID = int, prog_area_ID = str, costing_sect_ID = str, costing_subsect_ID = str, activity_ID = str):
    indices_and_recs = [(idx, budget_cat_share_rec) for (idx, budget_cat_share_rec) in enumerate(budget_cat_share_records) if (
        (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_BUDGET_ID] == budget_ID) 
        and (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_MOD_ID] == gbc.GB_PC) 
        and (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_IND_TYPE_ID] == ind_type_ID) 
        and (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_PROG_AREA_ID_PC] == prog_area_ID) 
        and (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_COSTING_SECT_ID_PC] == costing_sect_ID) 
        and (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_COSTING_SUBSECT_ID_PC] == costing_subsect_ID) 
        and (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_ACT_ID_PC] == activity_ID) 
    )]
    return indices_and_recs if len(indices_and_recs) > 0 else (gbc.GB_NOT_FOUND, {})

def get_BG_budget_cat_share_indices_and_records_all_cats_IS_non_prog_mgmt(budget_cat_share_records = list, budget_ID = str, ind_type_ID = int, ind_ID = str, prog_area_ID = str):
    indices_and_recs = [(idx, budget_cat_share_rec) for (idx, budget_cat_share_rec) in enumerate(budget_cat_share_records) if (
        (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_BUDGET_ID] == budget_ID) 
        and (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_MOD_ID] == gbc.GB_IS) 
        and (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_IND_TYPE_ID] == ind_type_ID) 
        and (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_IND_ID] == ind_ID) 
        and (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_PROG_AREA_ID_PC] == prog_area_ID) 
    )]
    return indices_and_recs if len(indices_and_recs) > 0 else (gbc.GB_NOT_FOUND, {})

def get_BG_budget_cat_share_indices_and_records_all_cats_IS_prog_mgmt(budget_cat_share_records = list, budget_ID = str, ind_type_ID = int, costing_sect_ID = str, costing_subsect_ID = str, act_ID = str):
    indices_and_recs = [(idx, budget_cat_share_rec) for (idx, budget_cat_share_rec) in enumerate(budget_cat_share_records) if (
        (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_BUDGET_ID] == budget_ID) 
        and (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_MOD_ID] == gbc.GB_IS) 
        and (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_IND_TYPE_ID] == ind_type_ID) 
        and (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_COSTING_SECT_ID_PC] == costing_sect_ID) 
        and (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_COSTING_SUBSECT_ID_PC] == costing_subsect_ID) 
        and (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_ACT_ID_PC] == act_ID) 
    )]
    return indices_and_recs if len(indices_and_recs) > 0 else (gbc.GB_NOT_FOUND, {})

def get_BG_budget_cat_share_indices_and_records_all_cats_HW_non_prog_mgmt(budget_cat_share_records = list, budget_ID = str, ind_type_ID = int, staff_level_ID = int, compens_type_ID = int, dynamic_staff_type_ID = str):
    indices_and_recs = [(idx, budget_cat_share_rec) for (idx, budget_cat_share_rec) in enumerate(budget_cat_share_records) if (
        (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_BUDGET_ID] == budget_ID) 
        and (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_MOD_ID] == gbc.GB_HW) 
        and (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_IND_TYPE_ID] == ind_type_ID) 
        and (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_STAFF_LEVEL_ID_HW] == staff_level_ID) 
        and (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_COMPENS_TYPE_ID_HW] == compens_type_ID) 
        and (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_IND_ID] == dynamic_staff_type_ID) 
    )]
    return indices_and_recs if len(indices_and_recs) > 0 else (gbc.GB_NOT_FOUND, {})

def get_BG_budget_cat_share_indices_and_records_all_cats_HW_prog_mgmt(budget_cat_share_records = list, budget_ID = str, ind_type_ID = int, costing_sect_ID = str, costing_subsect_ID = str, act_ID = str):
    indices_and_recs = [(idx, budget_cat_share_rec) for (idx, budget_cat_share_rec) in enumerate(budget_cat_share_records) if (
        (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_BUDGET_ID] == budget_ID) 
        and (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_MOD_ID] == gbc.GB_HW) 
        and (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_IND_TYPE_ID] == ind_type_ID) 
        and (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_COSTING_SECT_ID_PC] == costing_sect_ID) 
        and (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_COSTING_SUBSECT_ID_PC] == costing_subsect_ID) 
        and (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_ACT_ID_PC] == act_ID)  
    )]
    return indices_and_recs if len(indices_and_recs) > 0 else (gbc.GB_NOT_FOUND, {})

def get_BG_budget_cat_share_indices_and_records_all_cats_HS_costing(budget_cat_share_records = list, budget_ID = str, ind_type_ID = int, costing_sect_ID = str, costing_subsect_ID = str, act_ID = str):
    indices_and_recs = [(idx, budget_cat_share_rec) for (idx, budget_cat_share_rec) in enumerate(budget_cat_share_records) if (
        (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_BUDGET_ID] == budget_ID) 
        and (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_MOD_ID] == gbc.GB_HS) 
        and (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_IND_TYPE_ID] == ind_type_ID) 
        and (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_COSTING_SECT_HS_COSTING_ID] == costing_sect_ID) 
        and (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_COSTING_SUBSECT_HS_COSTING_ID] == costing_subsect_ID) 
        and (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_ACT_HS_COSTING_ID] == act_ID) 
    )]
    return indices_and_recs if len(indices_and_recs) > 0 else (gbc.GB_NOT_FOUND, {})
    
def get_BG_budget_cat_share_indices_and_records_all_cats_HS_prog_mgmt(budget_cat_share_records = list, budget_ID = str, ind_type_ID = int, costing_sect_ID = str, costing_subsect_ID = str, act_ID = str):
    indices_and_recs = [(idx, budget_cat_share_rec) for (idx, budget_cat_share_rec) in enumerate(budget_cat_share_records) if (
        (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_BUDGET_ID] == budget_ID) 
        and (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_MOD_ID] == gbc.GB_HS) 
        and (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_IND_TYPE_ID] == ind_type_ID) 
        and (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_COSTING_SECT_HS_PROG_MGMT_ID] == costing_sect_ID) 
        and (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_COSTING_SUBSECT_HS_PROG_MGMT_ID] == costing_subsect_ID) 
        and (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_ACT_HS_PROG_MGMT_ID] == act_ID) 
    )]
    return indices_and_recs if len(indices_and_recs) > 0 else (gbc.GB_NOT_FOUND, {})

def get_BG_budget_cat_share_indices_and_records_all_cats_GV_costing(budget_cat_share_records = list, budget_ID = str, ind_type_ID = int, costing_sect_ID = str, costing_subsect_ID = str, act_ID = str):
    indices_and_recs = [(idx, budget_cat_share_rec) for (idx, budget_cat_share_rec) in enumerate(budget_cat_share_records) if (
        (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_BUDGET_ID] == budget_ID) 
        and (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_MOD_ID] == gbc.GB_GV) 
        and (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_IND_TYPE_ID] == ind_type_ID) 
        and (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_COSTING_SECT_GV_COSTING_ID] == costing_sect_ID) 
        and (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_COSTING_SUBSECT_GV_COSTING_ID] == costing_subsect_ID) 
        and (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_ACT_GV_COSTING_ID] == act_ID) 
    )]
    return indices_and_recs if len(indices_and_recs) > 0 else (gbc.GB_NOT_FOUND, {})
    
def get_BG_budget_cat_share_indices_and_records_all_cats_GV_prog_mgmt(budget_cat_share_records = list, budget_ID = str, ind_type_ID = int, costing_sect_ID = str, costing_subsect_ID = str, act_ID = str):
    indices_and_recs = [(idx, budget_cat_share_rec) for (idx, budget_cat_share_rec) in enumerate(budget_cat_share_records) if (
        (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_BUDGET_ID] == budget_ID) 
        and (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_MOD_ID] == gbc.GB_GV) 
        and (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_IND_TYPE_ID] == ind_type_ID) 
        and (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_COSTING_SECT_GV_PROG_MGMT_ID] == costing_sect_ID) 
        and (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_COSTING_SUBSECT_GV_PROG_MGMT_ID] == costing_subsect_ID) 
        and (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_ACT_GV_PROG_MGMT_ID] == act_ID) 
    )]
    return indices_and_recs if len(indices_and_recs) > 0 else (gbc.GB_NOT_FOUND, {})

def get_BG_budget_cat_share_indices_and_records_all_cats_HF_costing(budget_cat_share_records = list, budget_ID = str, ind_type_ID = int, costing_sect_ID = str, costing_subsect_ID = str, act_ID = str):
    indices_and_recs = [(idx, budget_cat_share_rec) for (idx, budget_cat_share_rec) in enumerate(budget_cat_share_records) if (
        (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_BUDGET_ID] == budget_ID) 
        and (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_MOD_ID] == gbc.GB_HF) 
        and (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_IND_TYPE_ID] == ind_type_ID) 
        and (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_COSTING_SECT_HF_COSTING_ID] == costing_sect_ID) 
        and (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_COSTING_SUBSECT_HF_COSTING_ID] == costing_subsect_ID) 
        and (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_ACT_HF_COSTING_ID] == act_ID) 
    )]
    return indices_and_recs if len(indices_and_recs) > 0 else (gbc.GB_NOT_FOUND, {})
    
def get_BG_budget_cat_share_indices_and_records_all_cats_HF_prog_mgmt(budget_cat_share_records = list, budget_ID = str, ind_type_ID = int, costing_sect_ID = str, costing_subsect_ID = str, act_ID = str):
    indices_and_recs = [(idx, budget_cat_share_rec) for (idx, budget_cat_share_rec) in enumerate(budget_cat_share_records) if (
        (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_BUDGET_ID] == budget_ID) 
        and (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_MOD_ID] == gbc.GB_HF) 
        and (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_IND_TYPE_ID] == ind_type_ID) 
        and (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_COSTING_SECT_HF_PROG_MGMT_ID] == costing_sect_ID) 
        and (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_COSTING_SUBSECT_HF_PROG_MGMT_ID] == costing_subsect_ID) 
        and (budget_cat_share_rec[bgmvf.BG_BUDGET_CAT_SHARE_ACT_HF_PROG_MGMT_ID] == act_ID) 
    )]
    return indices_and_recs if len(indices_and_recs) > 0 else (gbc.GB_NOT_FOUND, {})

def get_BG_budget_cat_share_records_for_budget(budget_cat_share_records = list, budget_ID = str):
    budget_cat_share_records_value = [share_rec for share_rec in budget_cat_share_records if 
        (get_BG_budget_cat_share_budget_ID(share_rec) == budget_ID)]
    return budget_cat_share_records_value

def remove_BG_budget_cat_share_rec_at_curr_ID(budget_cat_share_records = list, curr_ID = int):
    return budget_cat_share_records.pop(curr_ID - 1)

def remove_BG_budget_cat_share_records_for_budget(budget_cat_share_records = list, budget_ID = str):
    budget_cat_share_records_value = [share_rec for share_rec in budget_cat_share_records if 
        (get_BG_budget_cat_share_budget_ID(share_rec) != budget_ID)]
    return budget_cat_share_records_value

def remove_BG_budget_cat_share_records(budget_cat_share_records = list, budget_ID = str, budget_cat_ID = str):
    budget_cat_share_records_value = [share_rec for share_rec in budget_cat_share_records if 
        (not ((get_BG_budget_cat_share_budget_ID(share_rec) == budget_ID) and 
        (get_BG_budget_cat_share_budget_cat_ID(share_rec) == budget_cat_ID)))]
    return budget_cat_share_records_value

# For this method and the ones like it, specify all possible params needed for an indicator and just pass in -1 or "-1" for the params that are not
# applicable to a particular indicator type.  That will save us from having to make multiple methods.
#
# These are only set up differently for each module because IC used to be different.

def remove_BG_budget_cat_share_records_IC(budget_cat_share_records = list, budget_ID = str, ind_type_ID = int):#, deliv_chan_ID = str):
    budget_cat_share_records_value = [share_rec for share_rec in budget_cat_share_records if 
        (not ((get_BG_budget_cat_share_budget_ID(share_rec) == budget_ID)
        and (get_BG_budget_cat_share_ind_type_ID(share_rec) == ind_type_ID)))]
        #and (get_BG_budget_cat_share_deliv_chan_ID(share_rec) == deliv_chan_ID)))]
    return budget_cat_share_records_value

def remove_BG_budget_cat_share_records_PC(budget_cat_share_records = list, budget_ID = str, ind_type_ID = int):
    budget_cat_share_records_value = [share_rec for share_rec in budget_cat_share_records if 
        (not ((get_BG_budget_cat_share_budget_ID(share_rec) == budget_ID)
        and (get_BG_budget_cat_share_ind_type_ID(share_rec) == ind_type_ID)))]
    return budget_cat_share_records_value

def remove_BG_budget_cat_share_records_IS(budget_cat_share_records = list, budget_ID = str, ind_type_ID = int):
    budget_cat_share_records_value = [share_rec for share_rec in budget_cat_share_records if 
        (not ((get_BG_budget_cat_share_budget_ID(share_rec) == budget_ID)
        and (get_BG_budget_cat_share_ind_type_ID(share_rec) == ind_type_ID)))]
    return budget_cat_share_records_value

def remove_BG_budget_cat_share_records_HW(budget_cat_share_records = list, budget_ID = str, ind_type_ID = int):
    budget_cat_share_records_value = [share_rec for share_rec in budget_cat_share_records if 
        (not ((get_BG_budget_cat_share_budget_ID(share_rec) == budget_ID)
        and (get_BG_budget_cat_share_ind_type_ID(share_rec) == ind_type_ID)))]
    return budget_cat_share_records_value

def remove_BG_budget_cat_share_records_HS(budget_cat_share_records = list, budget_ID = str, ind_type_ID = int):
    budget_cat_share_records_value = [share_rec for share_rec in budget_cat_share_records if 
        (not ((get_BG_budget_cat_share_budget_ID(share_rec) == budget_ID)
        and (get_BG_budget_cat_share_ind_type_ID(share_rec) == ind_type_ID)))]
    return budget_cat_share_records_value

def remove_BG_budget_cat_share_records_GV(budget_cat_share_records = list, budget_ID = str, ind_type_ID = int):
    budget_cat_share_records_value = [share_rec for share_rec in budget_cat_share_records if 
        (not ((get_BG_budget_cat_share_budget_ID(share_rec) == budget_ID)
        and (get_BG_budget_cat_share_ind_type_ID(share_rec) == ind_type_ID)))]
    return budget_cat_share_records_value

def remove_BG_budget_cat_share_records_HF(budget_cat_share_records = list, budget_ID = str, ind_type_ID = int):
    budget_cat_share_records_value = [share_rec for share_rec in budget_cat_share_records if 
        (not ((get_BG_budget_cat_share_budget_ID(share_rec) == budget_ID)
        and (get_BG_budget_cat_share_ind_type_ID(share_rec) == ind_type_ID)))]
    return budget_cat_share_records_value

# Change the budget ID of a budget category share record. Useful when copying a budget.
def change_BG_budget_cat_share_budget_ID(budget_cat_share_records = list, budget_ID = str):
    budget_cat_share_recs = [set_BG_budget_cat_share_budget_ID(budget_cat_share_rec, budget_ID) for budget_cat_share_rec in budget_cat_share_records]
    return budget_cat_share_recs
    

            
