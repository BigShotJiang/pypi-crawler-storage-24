
import numpy as np

from SpectrumCommon.Const.GB import GB_BaseYear 
from SpectrumCommon.Const.FS import *


def create_absolute_dict(numbers, percents, opt):
    return {
        'absolute': numbers,
        'percents': percents,
        'option': opt
    }

#@autoreload
def init_modvars(countryID, first_year, final_year,  extra):
    #Variables needed for multiple modvars
    #final_year = 2030
    
    scenario_names = ['Scenario 1', 'Scenario 2', 'Scenario 3']


    base_year = GB_BaseYear
    first_year_idx = first_year - base_year
    final_year_idx = final_year - base_year 

    year_zeroes = np.zeros((final_year_idx+1)).tolist() 
    blank_num_perc = create_absolute_dict(year_zeroes.copy(), year_zeroes.copy(), 'absolute')
    
    #modvar creation list
    return {
        # General
        FS_ScenarioNameTag     : scenario_names,

        # MacroEconomics
        ## GDP tab
        FS_MacroGDPTag          : [blank_num_perc for s in scenario_names],

        ## General government expenditure tab
        FS_MacroExpenditureTag  : [blank_num_perc for s in scenario_names],

        ## General government revenue
        FS_MacroTaxesTag        : [blank_num_perc for s in scenario_names],
        FS_MacroNonTaxesTag     : [blank_num_perc for s in scenario_names],
        FS_MacroGrantsTag       : [blank_num_perc for s in scenario_names],
        FS_MacroOtherRevenueTag : [blank_num_perc for s in scenario_names],


        # Health Expenditures
        ## General government health expenditure
        FS_GGHEApproachTag: FS_MANUAL_APPROACH,

        FS_GGHEDomesticTag:[blank_num_perc for s in scenario_names], 
        FS_GGHEExternalTag:[blank_num_perc for s in scenario_names], 

        FS_HealthExpCoeffTag : [{'GDP':0, 'GGHE':0} for s in scenario_names] ,
        FS_PercOfGGETag : [{'baseline':0, 'target':0, 'yearsOfDelay':0, 'yearsUntilArrival':0} for s in scenario_names] ,
        FS_ConstantPricesTag : [{'baseline':0, 'target':0, 'yearsOfDelay':0, 'yearsUntilArrival':0} for s in scenario_names] ,

        ## Private health expenditure
        FS_OutOfPocketTag : [blank_num_perc for s in scenario_names],
        FS_PrePaidRiskPlansTag : [blank_num_perc for s in scenario_names],

        FS_GrowthOptionTag: [False for s in scenario_names] ,
        FS_PrivateHealthCoeffTag : [{'GDP':0, 'GGHE':0} for s in scenario_names] ,

        ## External resources for health
        FS_HealthExpOtherTag : [year_zeroes.copy() for s in scenario_names],
        
        # # Results
        # FS_PlannedExpVSFiscalSpaceTag: [],
        # FS_PlannedExpVSFinancialSpaceTag: [],
        # FS_HealthExpenditureRatioTag: [],
        # FS_PerCapitaTag: [{'GDP':year_zeroes, 'THE':year_zeroes, 'GGHE':year_zeroes} for s in scenario_names],
        
        # ## Macroeconomic results
        # FS_FinancialSpaceTag: [],

        # ## Macroeconomic results
        # FS_MacroPopResTag:[],
        # FS_MacroGDPResTag:[],
        # FS_MacroExpendResTag:[],
        # FS_MacroExpendCompResTag:[],
        # FS_MacroRevenueResTag:[],
        # FS_MacroCurrentPricesTag:[],

        # ## Health expenditure results
        # ## Custom graph results

        
    }