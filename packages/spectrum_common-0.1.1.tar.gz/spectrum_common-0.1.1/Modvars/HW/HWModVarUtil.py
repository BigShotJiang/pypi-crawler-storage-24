import SpectrumCommon.Const.GB.GBConst as gbc

import SpectrumCommon.Const.HW.HWModVarFields as hwmvf

#######################################################################################################
#                                                                                                     #
#                                      Staff types                                                    #
#                                                                                                     #
#######################################################################################################

def get_HW_num_staff_types(staff_type_records: list):
    return len(staff_type_records)

def get_HW_staff_type_rec_from_curr_ID(staff_type_records: list, curr_ID: int):
    return staff_type_records[curr_ID - 1]

def get_HW_staff_type_rec(staff_type_records: list, ID: str):
    staff_type_recs = [staff_type_rec for staff_type_rec in staff_type_records if staff_type_rec[hwmvf.HW_STAFF_ID] == ID]
    return staff_type_recs[0] if len(staff_type_recs) > 0 else gbc.GB_NOT_FOUND

    # staff_type_rec = None
    
    # st = 0
    # stop = False
    # num_staff_types = get_HW_num_staff_types(staff_type_records)

    # while (st < num_staff_types) and (not stop):

    #     staff_type_ID = get_HW_staff_type_ID(staff_type_records[st])

    #     if staff_type_ID == ID:
    #         staff_type_rec = staff_type_records[st]
    #         stop = True

    #     st += 1

    # return staff_type_rec

def get_HW_staff_type_idx(staff_type_records: list, ID: str):
    indices = [idx for (idx, staff_type_rec) in enumerate(staff_type_records) if staff_type_rec[hwmvf.HW_STAFF_ID] == ID]
    return indices[0] if len(indices) > 0 else gbc.GB_NOT_FOUND

    # idx = gbc.GB_NOT_FOUND
    
    # st = 0
    # stop = False
    # num_staff_types = get_HW_num_staff_types(staff_type_records)

    # while (st < num_staff_types) and (not stop):

    #     staff_type_ID = get_HW_staff_type_ID(staff_type_records[st])

    #     if staff_type_ID == ID:
    #         idx = st
    #         stop = True

    #     st += 1

    # return idx

###

def get_HW_staff_type_ID(staff_type_rec: dict):
    return staff_type_rec[hwmvf.HW_STAFF_ID]

def set_HW_staff_type_ID(staff_type_rec: dict, value: str):
    staff_type_rec[hwmvf.HW_STAFF_ID] = value

###

def get_HW_staff_type_name(staff_type_rec: dict):
    return staff_type_rec[hwmvf.HW_STAFF_NAME]

def set_HW_staff_type_name(staff_type_rec: dict, value: str):
    staff_type_rec[hwmvf.HW_STAFF_NAME] = value

###

def get_HW_staff_type_string_constant(staff_type_rec: dict):
    return staff_type_rec[hwmvf.HW_STAFF_STR_CONSTANT]

def set_HW_staff_type_string_constant(staff_type_rec: dict, value: str):
    staff_type_rec[hwmvf.HW_STAFF_STR_CONSTANT] = value

###

def get_HW_staff_type_active(staff_type_rec: dict):
    return staff_type_rec[hwmvf.HW_STAFF_ACTIVE]

def set_HW_staff_type_active(staff_type_rec: dict, value = bool):
    staff_type_rec[hwmvf.HW_STAFF_ACTIVE] = value

###

def get_HW_staff_type_custom(staff_type_rec: dict):
    return staff_type_rec[hwmvf.HW_STAFF_CUSTOM]

def set_HW_staff_type_custom(staff_type_rec: dict, value = bool):
    staff_type_rec[hwmvf.HW_STAFF_CUSTOM] = value

###

def get_HW_staff_type_division(staff_type_rec: dict):
    return staff_type_rec[hwmvf.HW_STAFF_DIVISION_MST_ID]

def set_HW_staff_type_division(staff_type_rec: dict, value: int):
    staff_type_rec[hwmvf.HW_STAFF_DIVISION_MST_ID] = value

###

def get_HW_staff_type_static_map(staff_type_rec: dict):
    return staff_type_rec[hwmvf.HW_STAFF_STATIC_MAP_MST_ID]

def set_HW_staff_type_default_map(staff_type_rec: dict, value: int):
    staff_type_rec[hwmvf.HW_STAFF_STATIC_MAP_MST_ID] = value

###


def get_HW_staff_type_avg_days_worked_per_year(staff_type_rec: dict):
    return staff_type_rec[hwmvf.HW_STAFF_AVG_DAYS_WORKED_PER_YEAR]

def set_HW_staff_type_avg_days_worked_per_year(staff_type_rec: dict, value: int):
    staff_type_rec[hwmvf.HW_STAFF_AVG_DAYS_WORKED_PER_YEAR] = value

###

def get_HW_staff_type_hours_in_a_work_day(staff_type_rec: dict):
    return staff_type_rec[hwmvf.HW_STAFF_HOURS_IN_WORK_DAY]

def set_HW_staff_type_hours_in_a_work_day(staff_type_rec: dict, value: int):
    staff_type_rec[hwmvf.HW_STAFF_HOURS_IN_WORK_DAY] = value

###

def get_HW_staff_type_curr_attr_per_year(staff_type_rec: dict, attrit_type_curr_ID: int):
    return staff_type_rec[hwmvf.HW_STAFF_CURR_ATTRIT_PER_YEAR][attrit_type_curr_ID - 1]

def set_HW_staff_type_curr_attr_per_year(staff_type_rec: dict, attrit_type_curr_ID: int, value: int):
    staff_type_rec[hwmvf.HW_STAFF_CURR_ATTRIT_PER_YEAR][attrit_type_curr_ID - 1] = value

###

def get_HW_staff_type_perc_receiv_attrit_reduc_incents(staff_type_rec: dict, retent_incent_curr_ID: int):
    return staff_type_rec[hwmvf.HW_STAFF_PERC_REC_ATTRIT_REDUC_INCENTS][retent_incent_curr_ID - 1]

def set_HW_staff_type_perc_receiv_attrit_reduc_incents(staff_type_rec: dict, retent_incent_curr_ID: int, value: int):
    staff_type_rec[hwmvf.HW_STAFF_PERC_REC_ATTRIT_REDUC_INCENTS][retent_incent_curr_ID - 1] = value

###

def get_HW_staff_type_ann_cost_attrit_reduc_incents(staff_type_rec: dict, retent_incent_curr_ID: int):
    return staff_type_rec[hwmvf.HW_STAFF_ANNUAL_COST_ATTRIT_REDUC_INCENTS][retent_incent_curr_ID - 1]

def set_HW_staff_type_ann_cost_attrit_reduc_incents(staff_type_rec: dict, retent_incent_curr_ID: int, value = float):
    staff_type_rec[hwmvf.HW_STAFF_ANNUAL_COST_ATTRIT_REDUC_INCENTS][retent_incent_curr_ID - 1] = value

###

def get_HW_staff_type_target_num_per_facility(staff_type_rec: dict, staffing_level: int, facility_type_curr_ID: int):
    return staff_type_rec[hwmvf.HW_STAFF_TARGET_STAFF_PER_FACILITY][staffing_level - 1][facility_type_curr_ID - 1]

def set_HW_staff_type_target_num_per_facility(staff_type_rec: dict, staffing_level: int, facility_type_curr_ID: int, value: int):
    staff_type_rec[hwmvf.HW_STAFF_TARGET_STAFF_PER_FACILITY][staffing_level - 1][facility_type_curr_ID - 1] = value

###

def get_HW_staff_type_target_retent_incent_levels(staff_type_rec: dict, retent_incent_curr_ID: int, t: int):
    return staff_type_rec[hwmvf.HW_STAFF_TARGET_RETENT_INCENT_LEVELS][retent_incent_curr_ID - 1][t]

def set_HW_staff_type_target_retent_incent_levels(staff_type_rec: dict, retent_incent_curr_ID: int, t: int, value: int):
    staff_type_rec[hwmvf.HW_STAFF_TARGET_RETENT_INCENT_LEVELS][retent_incent_curr_ID - 1][t] = value

###

def get_HW_staff_type_num_in_base_year(staff_type_rec: dict, staff_level_curr_ID: int):
    return staff_type_rec[hwmvf.HW_STAFF_BASE_YEAR][staff_level_curr_ID - 1]

def set_HW_staff_type_num_in_base_year(staff_type_rec: dict, staff_level_curr_ID: int, value: int):
    staff_type_rec[hwmvf.HW_STAFF_BASE_YEAR][staff_level_curr_ID - 1] = value

###

def get_HW_staff_type_target_setting_method(staff_type_rec: dict, staff_level_curr_ID: int):
    return staff_type_rec[hwmvf.HW_STAFF_TARGET_SETTING_METHOD][staff_level_curr_ID - 1]

def set_HW_staff_type_target_setting_method(staff_type_rec: dict, staff_level_curr_ID: int, value: int):
    staff_type_rec[hwmvf.HW_STAFF_TARGET_SETTING_METHOD][staff_level_curr_ID - 1] = value

###

def get_HW_staff_type_target_staff_pop_ratio(staff_type_rec: dict, staff_level_curr_ID: int):
    return staff_type_rec[hwmvf.HW_STAFF_TARGET_STAFF_POP_RATIO][staff_level_curr_ID - 1]

def set_HW_staff_type_target_staff_pop_ratio(staff_type_rec: dict, staff_level_curr_ID: int, value = float):
    staff_type_rec[hwmvf.HW_STAFF_TARGET_STAFF_POP_RATIO][staff_level_curr_ID - 1] = value

###

def get_HW_staff_type_annual_salary(staff_type_rec: dict):
    return staff_type_rec[hwmvf.HW_STAFF_ANNUAL_SALARY]

def set_HW_staff_type_annual_salary(staff_type_rec: dict, value = float):
    staff_type_rec[hwmvf.HW_STAFF_ANNUAL_SALARY] = value

###

def get_HW_staff_type_benefits(staff_type_rec: dict):
    return staff_type_rec[hwmvf.HW_STAFF_ANNUAL_BENEFITS]

def set_HW_staff_type_benefits(staff_type_rec: dict, value = float):
    staff_type_rec[hwmvf.HW_STAFF_ANNUAL_BENEFITS] = value

###

def get_HW_staff_type_annual_real_salary_incr(staff_type_rec: dict):
    return staff_type_rec[hwmvf.HW_STAFF_ANNUAL_REAL_SALARY_INCR]

def set_HW_staff_type_annual_real_salary_incr(staff_type_rec: dict, value = float):
    staff_type_rec[hwmvf.HW_STAFF_ANNUAL_REAL_SALARY_INCR] = value

###

def get_HW_staff_type_annual_benefits_adj(staff_type_rec: dict):
    return staff_type_rec[hwmvf.HW_STAFF_ANNUAL_BENEFITS_ADJUST]

def set_HW_staff_type_annual_benefits_adj(staff_type_rec: dict, value: int):
    staff_type_rec[hwmvf.HW_STAFF_ANNUAL_BENEFITS_ADJUST] = value

###

def get_HW_staff_type_scale_up_existing_plans(staff_type_rec: dict, staff_level_curr_ID: int, t: int):
    return staff_type_rec[hwmvf.HW_STAFF_TARGET_SCALE_UP_EXISTING_PLANS][staff_level_curr_ID - 1][t]

def set_HW_staff_type_scale_up_existing_plans(staff_type_rec: dict, staff_level_curr_ID: int, t: int, value: int):
    staff_type_rec[hwmvf.HW_STAFF_TARGET_SCALE_UP_EXISTING_PLANS][staff_level_curr_ID - 1][t] = value

###

def get_HW_staff_type_target_graduation(staff_type_rec: dict, t: int):
    return staff_type_rec[hwmvf.HW_STAFF_TARGET_GRADUATION][t]

def set_HW_staff_type_target_graduation(staff_type_rec: dict, t: int, value: int):
    staff_type_rec[hwmvf.HW_STAFF_TARGET_GRADUATION][t] = value

###

def get_HW_staff_type_target_enrollment(staff_type_rec: dict, t: int):
    return staff_type_rec[hwmvf.HW_STAFF_TARGET_ENROLLMENT][t]

def set_HW_staff_type_target_enrollment(staff_type_rec: dict, t: int, value: int):
    staff_type_rec[hwmvf.HW_STAFF_TARGET_ENROLLMENT][t] = value

###

def get_HW_staff_type_inserv_train_cost_perc_salary(staff_type_rec: dict):
    return staff_type_rec[hwmvf.HW_STAFF_INSERV_TRAIN_COST_PERC_SALARY]

def set_HW_staff_type_inserv_train_cost_perc_salary(staff_type_rec: dict, value = float):
    staff_type_rec[hwmvf.HW_STAFF_INSERV_TRAIN_COST_PERC_SALARY] = value

###

def get_HW_inserv_train_type_name(inserv_train_type_rec: dict):
    return inserv_train_type_rec[hwmvf.HW_INSERV_TRAIN_NAME]

def set_HW_inserv_train_type_name(inserv_train_type_rec: dict, value: str):
    inserv_train_type_rec[hwmvf.HW_INSERV_TRAIN_NAME] = value

###

def get_HW_inserv_train_type_inserv_train_cost_per_staff_trained(inserv_train_type_rec: dict):
    return inserv_train_type_rec[hwmvf.HW_INSERV_TRAIN_COST_PER_STAFF_TRAINED]

def set_HW_inserv_train_type_inserv_train_cost_per_staff_trained(inserv_train_type_rec: dict, value = float):
    inserv_train_type_rec[hwmvf.HW_INSERV_TRAIN_COST_PER_STAFF_TRAINED] = value

###

def get_HW_inserv_train_type_inserv_train_num_staff_to_train(inserv_train_type_rec: dict, t: int):
    return inserv_train_type_rec[hwmvf.HW_INSERV_TRAIN_NUM_STAFF_TO_TRAIN][t] 

def set_HW_inserv_train_type_inserv_train_num_staff_to_train(inserv_train_type_rec: dict, t: int, value: int):
    inserv_train_type_rec[hwmvf.HW_INSERV_TRAIN_NUM_STAFF_TO_TRAIN][t]  = value

###

def get_HW_staff_type_preserv_num_schools(staff_type_rec: dict):
    return staff_type_rec[hwmvf.HW_STAFF_PRESERV_NUM_SCHOOLS]

def set_HW_staff_type_preserv_num_schools(staff_type_rec: dict, value: int):
    staff_type_rec[hwmvf.HW_STAFF_PRESERV_NUM_SCHOOLS] = value

###

def get_HW_staff_type_preserv_annual_cost_per_student(staff_type_rec: dict):
    return staff_type_rec[hwmvf.HW_STAFF_PRESERV_ANNUAL_COST_PER_STUDENT]

def set_HW_staff_type_preserv_annual_cost_per_student(staff_type_rec: dict, value = float):
    staff_type_rec[hwmvf.HW_STAFF_PRESERV_ANNUAL_COST_PER_STUDENT] = value

###

def get_HW_staff_type_preserv_years_training(staff_type_rec: dict):
    return staff_type_rec[hwmvf.HW_STAFF_PRESERV_YEARS_TRAINING]

def set_HW_staff_type_preserv_years_training(staff_type_rec: dict, value: int):
    staff_type_rec[hwmvf.HW_STAFF_PRESERV_YEARS_TRAINING] = value

###

def get_HW_staff_type_preserv_curr_enrollment(staff_type_rec: dict):
    return staff_type_rec[hwmvf.HW_STAFF_PRESERV_CURR_ENROLLMENT]

def set_HW_staff_type_preserv_curr_enrollment(staff_type_rec: dict, value: int):
    staff_type_rec[hwmvf.HW_STAFF_PRESERV_CURR_ENROLLMENT] = value

###

def get_HW_staff_type_preserv_grads_most_recent_year(staff_type_rec: dict):
    return staff_type_rec[hwmvf.HW_STAFF_PRESERV_GRADS_MOST_RECENT_YEAR]

def set_HW_staff_type_preserv_grads_most_recent_year(staff_type_rec: dict, value: int):
    staff_type_rec[hwmvf.HW_STAFF_PRESERV_GRADS_MOST_RECENT_YEAR] = value

###

def get_HW_staff_type_preserv_inst_name(staff_type_rec: dict, inst_curr_ID: int):
    return staff_type_rec[hwmvf.HW_STAFF_PRESERV_INST_NAMES][inst_curr_ID - 1]

def set_HW_staff_type_preserv_inst_name(staff_type_rec: dict, inst_curr_ID: int, value: str):
    staff_type_rec[hwmvf.HW_STAFF_PRESERV_INST_NAMES][inst_curr_ID - 1] = value

###

def get_HW_staff_type_preserv_annual_avg_cost_per_student_by_inst(staff_type_rec: dict, inst_curr_ID: int):
    return staff_type_rec[hwmvf.HW_STAFF_PRESERV_ANNUAL_AVG_COST_PER_STUDENT_BY_INST][inst_curr_ID - 1]

def set_HW_staff_type_preserv_annual_avg_cost_per_student_by_inst(staff_type_rec: dict, inst_curr_ID: int, value = float):
    staff_type_rec[hwmvf.HW_STAFF_PRESERV_ANNUAL_AVG_COST_PER_STUDENT_BY_INST][inst_curr_ID - 1] = value

###

def get_HW_staff_type_avg_years_training_by_inst(staff_type_rec: dict, inst_curr_ID: int):
    return staff_type_rec[hwmvf.HW_STAFF_PRESERV_AVG_YEARS_TRAINING_BY_INST][inst_curr_ID - 1]

def set_HW_staff_type_avg_years_training_by_inst(staff_type_rec: dict, inst_curr_ID: int, value: int):
    staff_type_rec[hwmvf.HW_STAFF_PRESERV_AVG_YEARS_TRAINING_BY_INST][inst_curr_ID - 1] = value

###

def get_HW_staff_type_preserv_curr_intake_by_inst(staff_type_rec: dict, inst_curr_ID: int):
    return staff_type_rec[hwmvf.HW_STAFF_PRESERV_CURR_INTAKE_BY_INST][inst_curr_ID - 1]

def set_HW_staff_type_preserv_curr_intake_by_inst(staff_type_rec: dict, inst_curr_ID: int, value: int):
    staff_type_rec[hwmvf.HW_STAFF_PRESERV_CURR_INTAKE_BY_INST][inst_curr_ID - 1] = value

###

def get_HW_staff_type_preserv_grads_most_recent_year_by_inst(staff_type_rec: dict, inst_curr_ID: int):
    return staff_type_rec[hwmvf.HW_STAFF_PRESERV_GRADS_MOST_RECENT_YEAR_BY_INST][inst_curr_ID - 1]

def set_HW_staff_type_preserv_grads_most_recent_year_by_inst(staff_type_rec: dict, inst_curr_ID: int, value: int):
    staff_type_rec[hwmvf.HW_STAFF_PRESERV_GRADS_MOST_RECENT_YEAR_BY_INST][inst_curr_ID - 1] = value

###

def get_HW_staff_perc_time_spent_not_train_serv(staff_type_rec: dict):
    return staff_type_rec[hwmvf.HW_STAFF_PERC_TIME_SPENT_NOT_TRAIN_SERV]

# def set_HW_staff_type_preserv_grads_most_recent_year_by_inst(staff_type_rec: dict, value: int):
#     staff_type_rec[hwmvf.HW_STAFF_PERC_TIME_SPENT_NOT_TRAIN_SERV ] = value

#######################################################################################################
#                                                                                                     #
#                                      Attrition types                                                #
#                                                                                                     #
#######################################################################################################

def get_HW_num_attrit_types(attrit_type_records: list):
    return len(attrit_type_records)

def get_HW_attrit_type_rec(attrit_type_records: list, ID: str):
    attrit_type_recs = [attrit_type_rec for attrit_type_rec in attrit_type_records if attrit_type_rec[hwmvf.HW_ATTRIT_TYPE_ID] == ID]
    return attrit_type_recs[0] if len(attrit_type_recs) > 0 else gbc.GB_NOT_FOUND

    # attrit_type_rec = None
    
    # at = 0
    # stop = False
    # num_attrit_types = get_HW_num_attrit_types(attrit_type_records)

    # while (at < num_attrit_types) and (not stop):

    #     attrit_type_ID = get_HW_attrit_type_ID(attrit_type_records[at])

    #     if attrit_type_ID == ID:
    #         attrit_type_rec = attrit_type_records[at]
    #         stop = True

    #     at += 1

    # return attrit_type_rec

def get_HW_attrit_type_idx(attrit_type_records: list, ID: str):
    indices = [idx for (idx, attrit_type_rec) in enumerate(attrit_type_records) if attrit_type_rec[hwmvf.HW_ATTRIT_TYPE_ID] == ID]
    return indices[0] if len(indices) > 0 else gbc.GB_NOT_FOUND

    # idx = gbc.GB_NOT_FOUND
    
    # at = 0
    # stop = False
    # num_attrit_types = get_HW_num_attrit_types(attrit_type_records)

    # while (at < num_attrit_types) and (not stop):

    #     attrit_type_ID = get_HW_attrit_type_ID(attrit_type_records[at])

    #     if attrit_type_ID == ID:
    #         idx = at
    #         stop = True

    #     at += 1

    # return idx

###

def get_HW_attrit_type_name(attrit_type_rec: dict):
    return attrit_type_rec[hwmvf.HW_ATTRIT_TYPE_NAME]

def set_HW_attrit_type_name(attrit_type_rec: dict, value: str):
    attrit_type_rec[hwmvf.HW_ATTRIT_TYPE_NAME] = value

###

def get_HW_attrit_type_ID(attrit_type_rec: dict):
    return attrit_type_rec[hwmvf.HW_ATTRIT_TYPE_ID]

def set_HW_attrit_type_ID(attrit_type_rec: dict, value: str):
    attrit_type_rec[hwmvf.HW_ATTRIT_TYPE_ID] = value

#######################################################################################################
#                                                                                                     #
#                                      Retention incentives                                           #
#                                                                                                     #
#######################################################################################################

def get_HW_num_retent_incents(retent_incent_records: list):
    return len(retent_incent_records)

def get_HW_retent_incent_rec_from_curr_ID(retent_incent_records: list, curr_ID: int):
    return retent_incent_records[curr_ID - 1]

def get_HW_retent_incent_rec(retent_incent_records: list, ID: str):
    retent_incent_recs = [retent_incent_rec for retent_incent_rec in retent_incent_records if retent_incent_rec[hwmvf.HW_RETENT_INCENT_ID] == ID]
    return retent_incent_recs[0] if len(retent_incent_recs) > 0 else gbc.GB_NOT_FOUND

    # retent_incent_rec = None
    
    # ri = 0
    # stop = False
    # num_retent_incents = get_HW_num_retent_incents(retent_incent_records)

    # while (ri < num_retent_incents) and (not stop):

    #     retent_incent_ID = get_HW_retent_incent_ID(retent_incent_records[ri])

    #     if retent_incent_ID == ID:
    #         retent_incent_rec = retent_incent_records[ri]
    #         stop = True

    #     ri += 1

    # return retent_incent_rec

def get_HW_retent_incent_idx(retent_incent_records: list, ID: str):
    indices = [idx for (idx, retent_incent_rec) in enumerate(retent_incent_records) if retent_incent_rec[hwmvf.HW_RETENT_INCENT_ID] == ID]
    return indices[0] if len(indices) > 0 else gbc.GB_NOT_FOUND

    # idx = gbc.GB_NOT_FOUND
    
    # ri = 0
    # stop = False
    # num_retent_incents = get_HW_num_retent_incents(retent_incent_records)

    # while (ri < num_retent_incents) and (not stop):

    #     retent_incent_ID = get_HW_retent_incent_ID(retent_incent_records[ri])

    #     if retent_incent_ID == ID:
    #         idx = ri
    #         stop = True

    #     ri += 1

    # return idx

###

def get_HW_retent_incent_name(retent_incent_rec: dict):
    return retent_incent_rec[hwmvf.HW_RETENT_INCENT_NAME]

def set_HW_retent_incent_name(retent_incent_rec: dict, value: str):
    retent_incent_rec[hwmvf.HW_RETENT_INCENT_NAME] = value

###

def get_HW_retent_incent_ID(retent_incent_rec: dict):
    return retent_incent_rec[hwmvf.HW_RETENT_INCENT_ID]

def set_HW_retent_incent_ID(retent_incent_rec: dict, value: str):
    retent_incent_rec[hwmvf.HW_RETENT_INCENT_ID] = value

###

def get_HW_retent_incent_reduc_attrit(retent_incent_rec: dict, attrit_type_curr_ID: int):
    return retent_incent_rec[hwmvf.HW_RETENT_INCENT_PERC_REDUC_ATTRIT][attrit_type_curr_ID - 1]

def set_HW_retent_incent_reduc_attrit(retent_incent_rec: dict, attrit_type_curr_ID: int, value: int):
    retent_incent_rec[hwmvf.HW_RETENT_INCENT_PERC_REDUC_ATTRIT][attrit_type_curr_ID - 1] = value

###

def get_HW_target_scale_up_visited(target_scale_up_visited: list, staff_level_curr_ID: int):
    return target_scale_up_visited[staff_level_curr_ID - 1]

def set_HW_target_scale_up_visited(target_scale_up_visited: list, staff_level_curr_ID: int, value = bool):
    target_scale_up_visited[staff_level_curr_ID - 1] = value



#######################################################################################################
#                                                                                                     #
#                                 Inservice training type (tt) records                                #
#                                                                                                     #
#######################################################################################################

def get_HW_inserv_train_type_staff_type_ID(inserv_train_type_rec: dict):
    return inserv_train_type_rec[hwmvf.HW_INSERV_TRAIN_STAFF_TYPE_TO_TRAIN]

def set_HW_inserv_train_type_staff_type_ID(inserv_train_type_rec: dict, value: str):
    inserv_train_type_rec[hwmvf.HW_INSERV_TRAIN_STAFF_TYPE_TO_TRAIN] = value