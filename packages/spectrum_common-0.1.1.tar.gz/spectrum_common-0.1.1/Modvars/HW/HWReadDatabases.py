# Contains methods for setting up OHT ModVars

from os import environ

from AvenirCommon.Database import GB_get_db_json, GB_file_exists

import SpectrumCommon.Const.GB as gbc

import SpectrumCommon.Const.HW.HWConst as hwc
import SpectrumCommon.Const.HW.HWDatabaseConst as hwdbc
import SpectrumCommon.Modvars.HW.HWModVarUtil as hwmvu

#######################################################################################################
#                                                                                                     #
#                                       Database loading methods                                      #
#                                                                                                     #
#######################################################################################################

def HW_load_staff_salaries_DB(country_ID):
    staff_salaries_DB_file_name = hwc.HW_STAFF_SALARIES_DB_DIR.replace('\\', '/') + '/' + country_ID + '_' + hwc.HW_STAFF_SALARIES_DB_CURR_VERSION + '.' + gbc.GB_JSON
    
    if GB_file_exists(environ[gbc.GB_SPECT_MOD_DATA_CONN_ENV], gbc.GB_HW_CONTAINER, staff_salaries_DB_file_name):
        staff_salaries_DB = GB_get_db_json(environ[gbc.GB_SPECT_MOD_DATA_CONN_ENV], gbc.GB_HW_CONTAINER, staff_salaries_DB_file_name)
    else:
        staff_salaries_DB = gbc.GB_NOT_FOUND

    return staff_salaries_DB

#######################################################################################################
#                                                                                                     #
#                                       Database loading methods                                      #
#                                                                                                     #
#######################################################################################################

def HW_set_staff_salaries(staff_type_records, staff_salaries_DB):
    if staff_salaries_DB != gbc.GB_NOT_FOUND:
        edu_code_1_salary = staff_salaries_DB[hwdbc.HW_EDU_CODE_1_SALARY_KEY_SSDB]
        edu_code_2_salary = staff_salaries_DB[hwdbc.HW_EDU_CODE_2_SALARY_KEY_SSDB]
        edu_code_3_salary = staff_salaries_DB[hwdbc.HW_EDU_CODE_3_SALARY_KEY_SSDB]
        edu_code_4_salary = staff_salaries_DB[hwdbc.HW_EDU_CODE_4_SALARY_KEY_SSDB]
        edu_code_5_salary = staff_salaries_DB[hwdbc.HW_EDU_CODE_5_SALARY_KEY_SSDB]

        for staff_type_rec in staff_type_records:
            staff_type_ID = hwmvu.get_HW_staff_type_ID(staff_type_rec)

            if staff_type_ID == str(hwc.HW_GENERAL_MEDICAL_PRACTITIONERS_MST_ID):
                hwmvu.set_HW_staff_type_annual_salary(staff_type_rec, edu_code_4_salary)

            # elif staff_type_ID == str(hwc.HW_OB_GYNS_MST_ID):
            #     hwmvu.set_HW_staff_type_annual_salary(staff_type_rec, 0.0)

            # elif staff_type_ID == str(hwc.HW_PEDIATRICIANS_MST_ID):
            #     hwmvu.set_HW_staff_type_annual_salary(staff_type_rec, 0.0)
                                    
            elif staff_type_ID == str(hwc.HW_SPECIAL_MEDICAL_PRACTITIONERS_MST_ID):
                hwmvu.set_HW_staff_type_annual_salary(staff_type_rec, edu_code_5_salary)
            
            # elif staff_type_ID == str(hwc.HW_CLINIC_OFF_SURG_TECHS_MST_ID):
            #     hwmvu.set_HW_staff_type_annual_salary(staff_type_rec, 0.0)
            
            elif staff_type_ID == str(hwc.HW_NURSING_PROFESSIONALS_MST_ID):
                hwmvu.set_HW_staff_type_annual_salary(staff_type_rec, edu_code_3_salary)
            
            elif staff_type_ID == str(hwc.HW_MIDWIFERY_PROFESSIONALS_MST_ID):
                hwmvu.set_HW_staff_type_annual_salary(staff_type_rec, edu_code_3_salary)
            
            elif staff_type_ID == str(hwc.HW_MIDWIFERY_ASSOCIATE_PROFESSIONALS_MST_ID):
                hwmvu.set_HW_staff_type_annual_salary(staff_type_rec, edu_code_2_salary)
            
            elif staff_type_ID == str(hwc.HW_NURSING_ASSOCIATE_PROFESSIONALS_MST_ID):
                hwmvu.set_HW_staff_type_annual_salary(staff_type_rec, edu_code_2_salary)
            
            elif staff_type_ID == str(hwc.HW_MED_PATH_LAB_TECHS_MST_ID):
                hwmvu.set_HW_staff_type_annual_salary(staff_type_rec, edu_code_3_salary)
            
            elif staff_type_ID == str(hwc.HW_PHARM_TECHS_ASSIST_MST_ID):
                hwmvu.set_HW_staff_type_annual_salary(staff_type_rec, edu_code_3_salary)
            
            elif staff_type_ID == str(hwc.HW_MED_IMAGING_THERA_EQUIP_TECHS_MST_ID):
                hwmvu.set_HW_staff_type_annual_salary(staff_type_rec, edu_code_3_salary)
            
            elif staff_type_ID == str(hwc.HW_AMBULANCE_WORKERS_MST_ID):
                hwmvu.set_HW_staff_type_annual_salary(staff_type_rec, edu_code_3_salary)
            
            elif staff_type_ID == str(hwc.HW_COMM_HLTH_WORKERS_MST_ID):
                hwmvu.set_HW_staff_type_annual_salary(staff_type_rec, edu_code_1_salary)
            
            # elif staff_type_ID == str(hwc.HW_OTHER_STAFF_TYPE_MST_ID):
            #     hwmvu.set_HW_staff_type_annual_salary(staff_type_rec, 0.0)
            
            elif staff_type_ID == str(hwc.HW_DENTISTS_MST_ID):
                hwmvu.set_HW_staff_type_annual_salary(staff_type_rec, edu_code_4_salary)
            
            elif staff_type_ID == str(hwc.HW_DENTAL_ASSIST_THERAPISTS_MST_ID):
                hwmvu.set_HW_staff_type_annual_salary(staff_type_rec, edu_code_3_salary)
            
            elif staff_type_ID == str(hwc.HW_MED_DENTAL_PROSTHETIC_REL_TECHS_MST_ID):
                hwmvu.set_HW_staff_type_annual_salary(staff_type_rec, edu_code_3_salary)
            
            elif staff_type_ID == str(hwc.HW_PHARMACISTS_MST_ID):
                hwmvu.set_HW_staff_type_annual_salary(staff_type_rec, edu_code_4_salary)
            
            elif staff_type_ID == str(hwc.HW_PARAMED_PRACTITIONERS_MST_ID):
                hwmvu.set_HW_staff_type_annual_salary(staff_type_rec, edu_code_2_salary)
            
            elif staff_type_ID == str(hwc.HW_ENVIRON_OCCUPAT_HEALTH_HYGIENE_PROF_MST_ID):
                hwmvu.set_HW_staff_type_annual_salary(staff_type_rec, edu_code_3_salary)
            
            elif staff_type_ID == str(hwc.HW_DIETICIANS_NUTRITIONISTS_MST_ID):
                hwmvu.set_HW_staff_type_annual_salary(staff_type_rec, edu_code_3_salary)
            
            elif staff_type_ID == str(hwc.HW_AUDIOLOGISTS_SPEECH_THERAPISTS_MST_ID):
                hwmvu.set_HW_staff_type_annual_salary(staff_type_rec, edu_code_4_salary)
            
            elif staff_type_ID == str(hwc.HW_OPTOMETRISTS_OPHTHALMIC_OPTICIANS_MST_ID):
                hwmvu.set_HW_staff_type_annual_salary(staff_type_rec, edu_code_5_salary)
            
            elif staff_type_ID == str(hwc.HW_DISPENSING_OPTICIANS_MST_ID):
                hwmvu.set_HW_staff_type_annual_salary(staff_type_rec, edu_code_4_salary)
            
            elif staff_type_ID == str(hwc.HW_ENVIRON_OCCUPAT_HEALTH_INSPEC_ASSO_MST_ID):
                hwmvu.set_HW_staff_type_annual_salary(staff_type_rec, edu_code_2_salary)
            
            elif staff_type_ID == str(hwc.HW_TRAD_COMP_MED_PROF_MST_ID):
                hwmvu.set_HW_staff_type_annual_salary(staff_type_rec, edu_code_3_salary)
            
            elif staff_type_ID == str(hwc.HW_TRAD_COMP_MED_ASSOC_PROF_MST_ID):
                hwmvu.set_HW_staff_type_annual_salary(staff_type_rec, edu_code_2_salary)
            
            elif staff_type_ID == str(hwc.HW_HEALTH_CARE_ASSISTS_MST_ID):
                hwmvu.set_HW_staff_type_annual_salary(staff_type_rec, edu_code_1_salary)
            
            elif staff_type_ID == str(hwc.HW_HOME_BASED_PERS_CARE_WORKERS_MST_ID):
                hwmvu.set_HW_staff_type_annual_salary(staff_type_rec, edu_code_1_salary)
            
            elif staff_type_ID == str(hwc.HW_PERS_CARE_WORKERS_HEALTH_SERV_NOT_CLASS_MST_ID):
                hwmvu.set_HW_staff_type_annual_salary(staff_type_rec, edu_code_1_salary)
            
            elif staff_type_ID == str(hwc.HW_PHYSIOTHERAPISTS_MST_ID):
                hwmvu.set_HW_staff_type_annual_salary(staff_type_rec, edu_code_3_salary)
            
            elif staff_type_ID == str(hwc.HW_PHYSIOTHERAPY_TECHS_ASSISTS_MST_ID):
                hwmvu.set_HW_staff_type_annual_salary(staff_type_rec, edu_code_2_salary)
            
            elif staff_type_ID == str(hwc.HW_HEALTH_ASSOC_PROF_NOT_CLASS_MST_ID):
                hwmvu.set_HW_staff_type_annual_salary(staff_type_rec, edu_code_2_salary)
            
            elif staff_type_ID == str(hwc.HW_PSYCHOLOGISTS_MST_ID):
                hwmvu.set_HW_staff_type_annual_salary(staff_type_rec, edu_code_5_salary)
            
            elif staff_type_ID == str(hwc.HW_SOCIAL_WORK_COUNSELLING_PROF_MST_ID):
                hwmvu.set_HW_staff_type_annual_salary(staff_type_rec, edu_code_4_salary)
            
            elif staff_type_ID == str(hwc.HW_SOCIAL_WORK_ASSOC_PROF_MST_ID):
                hwmvu.set_HW_staff_type_annual_salary(staff_type_rec, edu_code_3_salary)

            elif staff_type_ID == str(hwc.HW_BIOMED_ENGINEER_MST_ID):
                hwmvu.set_HW_staff_type_annual_salary(staff_type_rec, edu_code_4_salary)

            elif staff_type_ID == str(hwc.HW_HLTH_SERV_MANAGERS_MST_ID):
                hwmvu.set_HW_staff_type_annual_salary(staff_type_rec, edu_code_3_salary)

            elif staff_type_ID == str(hwc.HW_AGED_CARE_SERVICE_MANAGERS_MST_ID):
                hwmvu.set_HW_staff_type_annual_salary(staff_type_rec, edu_code_3_salary)

            elif staff_type_ID == str(hwc.HW_MED_SECRETARIES_MST_ID):
                hwmvu.set_HW_staff_type_annual_salary(staff_type_rec, edu_code_2_salary)

            elif staff_type_ID == str(hwc.HW_MED_REC_HEALTH_INFO_TECHS_MST_ID):
                hwmvu.set_HW_staff_type_annual_salary(staff_type_rec, edu_code_2_salary)






