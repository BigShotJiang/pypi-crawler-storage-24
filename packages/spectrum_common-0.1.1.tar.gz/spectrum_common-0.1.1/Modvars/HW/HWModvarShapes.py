from SpectrumCommon.Const.HW import *
import SpectrumCommon.Const.HW.HWTags as hwmvt
from SpectrumCommon.Modvars.GB.GBDefs import *

hw_staff_dim = 'hw_staff_dim'
hw_staff_id = {
}

hw_institutions_dim = 'hw_institutions_dim'
hw_institution_id = {
    
}
hw_attrition_type_dim = 'hw_attrition_type'
hw_attrition_type_ids = {}

hw_retention_type_dim ='hw_retention_type'
hw_retention_type_ids = {}

hw_staffing_levels_dim = 'hw_staffing_levels_dim'
hw_staffing_levels_id = {
        HW_STAFF_LEVEL_FACILITY_CURR_ID : 'Facility',
        HW_STAFF_LEVEL_DISTRICT_CURR_ID : 'District',
        HW_STAFF_LEVEL_REGIONAL_CURR_ID : 'Regional',
        HW_STAFF_LEVEL_NATIONAL_CURR_ID : 'National',
}
hw_staff_types_dim = 'hw_staff_types'
hw_staff_types_id = {
    
}

hw_staff_comp_dim = 'hw_staff_comp'
hw_staff_comp_id = {}

hw_facility_types_dim = 'hw_facility_types_dim'
hw_facility_types_id = {
}

hw_inservice_dim = 'hw_inservice_dim'    
hw_inservice_id = {}

hw_staff_trained_dim = 'hw_staff_trained'
hw_staff_trained_id = {}

hw_pc_standard_rows_dim = 'hw_pc_standard_rows_dim'
hw_pc_standard_rows_id = {}
    
hw_static_staff_dim = 'hw_static_staff_dim'
hw_static_staff_id = {
        HW_GENERAL_MEDICAL_PRACTITIONERS_CURR_ID           : 'General medical practitioners',        
        HW_SPECIAL_MEDICAL_PRACTITIONERS_CURR_ID           : 'Special medical practitioners',        
        HW_CLINIC_OFF_SURG_TECHS_CURR_ID                   : 'Clinic off surg techs',        
        HW_NURSING_PROFESSIONALS_CURR_ID                   : 'Nursing professionals',        
        HW_MIDWIFERY_PROFESSIONALS_CURR_ID                 : 'Midwifery professionals',        
        HW_MIDWIFERY_ASSOCIATE_PROFESSIONALS_CURR_ID       : 'Midwifery associate professionals',        
        HW_NURSING_ASSOCIATE_PROFESSIONALS_CURR_ID         : 'Nursing associate professionals',        
        HW_MED_PATH_LAB_TECHS_CURR_ID                      : 'Med path lab techs',       
        HW_PHARM_TECHS_ASSIST_CURR_ID                      : 'Pharm techs assist',        
        HW_MED_IMAGING_THERA_EQUIP_TECHS_CURR_ID           : 'Med imaging thera equip techs',
        HW_AMBULANCE_WORKERS_CURR_ID                       : 'Ambulance workers',
        HW_COMM_HLTH_WORKERS_CURR_ID                       : 'Comm hlth workers',
        HW_OTHER_STAFF_TYPE_CURR_ID                        : 'Other staff type',
        HW_DENTISTS_CURR_ID                                : 'Dentists',
        HW_DENTAL_ASSIST_THERAPISTS_CURR_ID                : 'Dental assist therapists',
        HW_MED_DENTAL_PROSTHETIC_REL_TECHS_CURR_ID         : 'Med dental prosthetic rel techs',
        HW_PHARMACISTS_CURR_ID                             : 'Pharmacists',
        HW_PARAMED_PRACTITIONERS_CURR_ID                   : 'Paramed practitioners',
        HW_ENVIRON_OCCUPAT_HEALTH_HYGIENE_PROF_CURR_ID     : 'Environ occupat health hygiene prof',
        HW_DIETICIANS_NUTRITIONISTS_CURR_ID                : 'Dieticians nutritionists',
        HW_AUDIOLOGISTS_SPEECH_THERAPISTS_CURR_ID          : 'Audiologists speech therapists',
        HW_OPTOMETRISTS_OPHTHALMIC_OPTICIANS_CURR_ID       : 'Optometrists ophthalmic opticians',
        HW_DISPENSING_OPTICIANS_CURR_ID                    : 'Dispensing opticians',
        HW_ENVIRON_OCCUPAT_HEALTH_INSPEC_ASSO_CURR_IDC     : 'Environ occupat health inspec assoc',
        HW_TRAD_COMP_MED_PROF_CURR_ID                      : 'Trad comp med prof',
        HW_TRAD_COMP_MED_ASSOC_PROF_CURR_ID                : 'Trad comp med assoc prof',
        HW_HEALTH_CARE_ASSISTS_CURR_ID                     : 'Health care assists',
        HW_HOME_BASED_PERS_CARE_WORKERS_CURR_ID            : 'Home based pers care workers',
        HW_PERS_CARE_WORKERS_HEALTH_SERV_NOT_CLASS_CURR_ID : 'Pers care workers health serv not class',
        HW_PHYSIOTHERAPISTS_CURR_ID                        : 'Physiotherapists',
        HW_PHYSIOTHERAPY_TECHS_ASSISTS_CURR_ID             : 'Physiotherapy techs assists',
        HW_HEALTH_ASSOC_PROF_NOT_CLASS_CURR_ID             : 'Health assoc prof not class',
        HW_PSYCHOLOGISTS_CURR_ID                           : 'Psychologists',
        HW_SOCIAL_WORK_COUNSELLING_PROF_CURR_ID            : 'Social work counselling prof',
        HW_SOCIAL_WORK_ASSOC_PROF_CURR_ID                  : 'Social work assoc prof',
}

HW_modvar_shapes = {
    

        hwmvt.HW_VERSION_TAG_V1                                : gb_int_shape('HW Version'),
        hwmvt.HW_DATA_CHANGED_TAG_V1                           : gb_bool_shape('HW Data Changed'), 
        hwmvt.HW_PROJ_VALID_TAG_V1                             : gb_bool_shape('HW Project Valid'), 
        hwmvt.HW_FILE_NAME_TAG_V1                              : gb_str_shape('HW File Name'),                          
        hwmvt.HW_PROJ_VALID_DATE_TAG_V1                        : gb_str_shape('HW Project Valid Date'),    
        hwmvt.HW_COST_INSERV_TRAIN_BY_PERC_SALARY_TAG_V1       : gb_bool_shape('HW Cost Inserv Train By Perc Salary'),
        hwmvt.HW_SHOW_PRESERV_TRAIN_BY_INSTITUTION_TAG_V1      : gb_bool_shape('HW Show Preserv Train By Institution'),  
        hwmvt.HW_STAFF_TYPE_RECORDS_TAG_V1                     : gb_shape('HW Staff Type Records', '1D dict',
                                                                          dim=[hw_staff_dim],
                                                                          indicies=[hw_staff_id],
                                                                          innerShape={
                                                                              'staffTypeID':gb_str_shape('Staff Type ID'), 
                                                                              'stringConstant':gb_str_shape('String Constant'), 
                                                                              'name':gb_str_shape('Name'), 
                                                                              'active': gb_bool_shape('Active'), 
                                                                              'custom': gb_bool_shape('Custom'),
                                                                              'staffDivisionMstID': gb_int_shape('Staff Division Mst ID'),
                                                                              'defStaffTypeMapMstID': gb_int_shape('Default Staff Type Map Mst ID'),
                                                                              'numInBaseYear': gb_shape('Number in Base Year', '1D list'), 
                                                                              'annualSalary': gb_float_shape('Annual Salary'), 
                                                                              'annualRealSalaryIncrease':gb_float_shape('Annual Real Salary Increase'), 
                                                                              'annualBenefits':gb_float_shape('Annual Benefits'), 
                                                                              'annualBenefitsAdjustment': gb_float_shape('Annual Benefits Adjustment'), 
                                                                              'percTimeSpentNotTrainServ': gb_float_shape('Percentage Time Spent Not Train Serv'), 
                                                                              'avgDaysWorkedPerYear':gb_float_shape('Average Days Worked Per Year'), 
                                                                              'hoursInWorkDay':gb_float_shape('Hours in Work Day'), 
                                                                              'currAttritPerYear':gb_shape('Current Attrition Per Year', '1D float',
                                                                                                           dim=[hw_attrition_type_dim],
                                                                                                           indicies=[hw_attrition_type_ids]),
                                                                              'percReceivAttritReducIncents': gb_shape('Percentage Receive Attrition Reduction Incentives', '1D float',
                                                                                                                       dim=[hw_retention_type_dim],
                                                                                                                       indicies=[hw_retention_type_ids]),
                                                                              'annCostAttrReducIncents':gb_shape('Annual Cost Attrition Reduction Incentives',  '1D float',
                                                                                                                       dim=[hw_retention_type_dim],
                                                                                                                       indicies=[hw_retention_type_ids]),
                                                                              'preservNumSchools':gb_int_shape('Preserv Number Schools'), 
                                                                              'preservYearsTraining':gb_int_shape('Preserv Years Training'), 
                                                                              'preservAnnCostPerStudent': gb_float_shape('Preserv Annual Cost Per Student'), 
                                                                              'preservCurrEnrollment':gb_int_shape('Preserv Current Enrollment'), 
                                                                              'gradsMostRecentYear':gb_int_shape('Graduates Most Recent Year'), 
                                                                              'trainingInstNames':gb_shape('Training Institution Names', '1D str',     
                                                                                                            dim=[hw_institutions_dim],
                                                                                                            indicies=[hw_institution_id]),
                                                                              'avgYearsTrainingByInst':gb_shape('average years training by institution', '1D float',     
                                                                                                            dim=[hw_institutions_dim],
                                                                                                            indicies=[hw_institution_id]), 
                                                                              'annualAvgCostPerStudentByInst':gb_shape('annual average cost per student by institution', '1D float',     
                                                                                                            dim=[hw_institutions_dim],
                                                                                                            indicies=[hw_institution_id]), 
                                                                              'currIntakeFirstYearStudentsByInst':gb_shape('current intake first year students by institution', '1D float',     
                                                                                                            dim=[hw_institutions_dim],
                                                                                                            indicies=[hw_institution_id]), 
                                                                              'gradsMostRecentYearByInst':gb_shape('graduates most recent year by institution', '1D float',     
                                                                                                            dim=[hw_institutions_dim],
                                                                                                            indicies=[hw_institution_id]), 
                                                                              'totalAnnualRecruitment':gb_int_shape('Total Annual Recruitment'), 
                                                                              'percNewGradsPublicSector':gb_float_shape('Percentage New Graduates Public Sector'), 
                                                                              'inservTrainCostAsPercSalary':gb_float_shape('Inserv Training Cost as Percentage Salary'), 
                                                                              'targetSettingMethod':gb_shape('Target Setting Method', '1D int',
                                                                                                             dim=[hw_staffing_levels_dim],
                                                                                                             indicies=[hw_staffing_levels_id]),
                                                                              'targetStaffPopRatio': gb_shape('Target Staff Population Ratio', '1D float',
                                                                                                             dim=[hw_staffing_levels_dim],      
                                                                                                             indicies=[hw_staffing_levels_id]),
                                                                              'targetNumPerFacility':gb_shape('Target Number Per Facility', '2D float',
                                                                                                              dim=[hw_staffing_levels_dim, hw_facility_types_dim],
                                                                                                              indicies=[hw_staffing_levels_id, hw_facility_types_id]),
                                                                              'targetScaleUpExistingPlans':gb_shape('Target Scale Up Existing Plans', '2D float',
                                                                                                                    dim=[hw_staffing_levels_dim, gb_year_dim],
                                                                                                                    indicies=[hw_staffing_levels_id, gb_year_indices]),
                                                                              'targetEnrollment': gb_year_shape('Target Enrollment'),    
                                                                              'targetGraduation':gb_year_shape('Target Graduation'),
                                                                              'targetRetentIncentLevels': gb_shape('Target retention incent levels',  '2D float',
                                                                                                                       dim=[hw_retention_type_dim, gb_year_dim],
                                                                                                                       indicies=[hw_retention_type_ids, gb_year_indices],
                                                                                                                       contingent=True),
                                                                          },
                                                                          has_default=False
                                                                          
                                                                 ),        
        hwmvt.HW_INSERV_TRAIN_TYPE_RECORDS_TAG_V1              : gb_shape('HW Staff Type Records', '1D dict',
                                                                          dim=[hw_staff_trained_dim],
                                                                          indicies=[hw_staff_trained_id],
                                                                          innerShape={  
                                                                                'staffTypeToBeTrainedID': gb_str_shape('staff type to be trained ID'),
                                                                                'name': gb_str_shape('Name'),
                                                                                'costPerStaffTrained': gb_float_shape('Cost Per Staff Trained'),
                                                                                'numStaffToBeTrained': gb_year_shape('Number of Staff to be Trained')
                                                                          }
                                                                        ),
        
        hwmvt.HW_ATTRITION_TYPE_RECORDS_TAG_V1                 : gb_shape('Current Attrition Per Year', '1D dict',
                                                                           dim=[hw_attrition_type_dim],
                                                                           indicies=[hw_attrition_type_ids],
                                                                           innerShape={    
                                                                                 'attrTypeID': gb_str_shape('Attrition Type ID'),
                                                                                 'name': gb_str_shape('Name')
                                                                        }
                                                                ),
        hwmvt.HW_RETENTION_INCENTIVE_RECORDS_TAG_V1            :  gb_shape('Annual Cost Attrition Reduction Incentives',  '1D dict',
                                                                           dim=[hw_retention_type_dim],
                                                                           indicies=[hw_retention_type_ids],
                                                                           innerShape={
                                                                               'retentIncentID': gb_str_shape('Retention Incentive ID'),
                                                                               'name': gb_str_shape('Name'),
                                                                               'percReductionAttrition': gb_shape('Percentage Reduction Attrition', '1D float',
                                                                                                                        dim=[hw_attrition_type_dim],
                                                                                                                        indicies=[hw_attrition_type_ids])
                                                                               
                                                                           }, 
                                                                           has_default=False
                                                                ),
        hwmvt.HW_TARG_SCALE_UP_VISITED_TAG_V1                  : gb_shape('Target scale up visited', '1D bool',
                                                                          dim=[hw_staffing_levels_dim],
                                                                          indicies=[hw_staffing_levels_id]),
        hwmvt.HW_TARG_ENROLLMENT_VISITED_TAG_V1                : gb_bool_shape('HW Target Enrollment Visited'),                
        hwmvt.HW_TARG_GRADUATION_VISITED_TAG_V1                : gb_bool_shape('HW Target Graduation Visited'),
        hwmvt.HW_TARG_RETENT_INCENT_LEVELS_VISITED_TAG_V1      : gb_bool_shape('HW Target Retention Incentive Levels Visited'),
        hwmvt.HW_PROG_MGMT_DATA_TAG_V1                         : gb_shape('HW Program Management Data',  'dict',
                                                                           innerShape={
                                                                              'mainRowCosts': gb_shape('Main row costs', '2D float',
                                                                                dim=[hw_pc_standard_rows_dim, gb_year_dim],
                                                                                indicies=[hw_pc_standard_rows_id, gb_year_indices])
                                                                        },
                                                                           has_default=False
                                                                ),

        # # Outputs / results 
        hwmvt.HW_RES_TOTAL_STAFF_TAG_V1                         : gb_shape('Result total staff',  '3D float',
                                                                            dim=[hw_staffing_levels_dim, hw_staff_types_dim, gb_year_dim],
                                                                            indicies=[hw_staffing_levels_id, hw_staff_types_id, gb_year_indices]),
                                                                                
        hwmvt.HW_RES_TOTAL_COMPENSATION_TAG_V1                  : gb_shape('Result total compensation',  '4D float',
                                                                            dim=[hw_staffing_levels_dim, hw_staff_types_dim, hw_staff_comp_dim, gb_year_dim],
                                                                            indicies=[hw_staffing_levels_id, hw_staff_types_id, hw_staff_comp_id, gb_year_indices]),
        hwmvt.HW_RES_STAFF_NEEDING_TO_BE_HIRED_TAG_V1           : gb_shape('Result staff needing to be hired',  '3D float',
                                                                            dim=[hw_staffing_levels_dim, hw_staff_types_dim, gb_year_dim],
                                                                            indicies=[hw_staffing_levels_id, hw_staff_types_id, gb_year_indices]),

        hwmvt.HW_RES_ATTRITION_RATE_TAG_V1                      : gb_shape('Result attrition rate',  '2D float',
                                                                            dim=[hw_staff_types_dim, gb_year_dim],
                                                                            indicies=[hw_staff_types_id, gb_year_indices]),
        hwmvt.HW_RES_INSERV_TRAIN_COSTS_BY_STAFF_TAG_V1         : gb_shape('Result inservice training costs by staff',  '3D float',
                                                                            dim=[hw_staffing_levels_dim, hw_staff_types_dim, gb_year_dim],
                                                                            indicies=[hw_staffing_levels_id, hw_staff_types_id, gb_year_indices]),

        hwmvt.HW_RES_INSERV_TRAIN_COSTS_BY_TRAIN_TYPE_TAG_V1    : gb_shape('Result preserv training costs',  '2D float',
                                                                            dim=[hw_inservice_dim, gb_year_dim],
                                                                            indicies=[hw_inservice_id, gb_year_indices]),
        hwmvt.HW_RES_PRESERV_TRAIN_COSTS_TAG_V1                 : gb_shape('Result preserv training costs',  '2D float',
                                                                            dim=[hw_staff_types_dim, gb_year_dim],
                                                                            indicies=[hw_staff_types_id, gb_year_indices]),
        hwmvt.HW_RES_STAFF_PER_10K_POP_TAG_V1                   : gb_shape('Result staff per 10k population',  '3D float',
                                                                            dim=[hw_staffing_levels_dim, hw_staff_types_dim, gb_year_dim],
                                                                            indicies=[hw_staffing_levels_id, hw_staff_types_id, gb_year_indices]),

        hwmvt.HW_STATIC_STAFF_LIST_META_TAG_V1                  : gb_shape('HW Staff Type Records', '1D dict',
                                                                          dim=[hw_static_staff_dim],
                                                                          indicies=[hw_static_staff_id],
                                                                          innerShape={
                                                                              'mstID' : gb_str_shape('MST ID'),
                                                                              'name' : gb_str_shape('Name'),
                                                                              'stringConstant' : gb_str_shape('String Constant'),
                                                                          }
        )

}