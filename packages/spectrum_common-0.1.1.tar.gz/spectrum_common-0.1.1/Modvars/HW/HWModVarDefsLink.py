from SpectrumCommon.Const.GB.GBConst import *

from SpectrumCommon.Modvars.PC.PCModVarDefs import *

def HW_create_prog_mgmt_data_dict(num_years = int):
    return PC_create_prog_mgmt_data_dict(GB_HW, num_years)