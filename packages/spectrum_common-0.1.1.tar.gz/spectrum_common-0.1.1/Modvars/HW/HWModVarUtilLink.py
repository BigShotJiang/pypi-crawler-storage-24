from  SpectrumCommon.Modvars.IS.ISModVarUtil import *

#############################    IS    ##########################

def HW_get_IS_num_facility_types(facility_type_dict_list):
    return get_IS_num_facility_types(facility_type_dict_list)

def HW_get_IS_facility_type_rec_from_curr_ID(facility_type_records = list, curr_ID = int):
    return get_IS_facility_type_rec_from_curr_ID(facility_type_records, curr_ID)

def HW_get_IS_total_num_facilities_available(mv_value, ft = int, t = int):
    return get_IS_total_num_facilities_available(mv_value, ft, t)

