import math as math

import SpectrumCommon.Const.GB.GBConst as gbc

import SpectrumCommon.Const.IC.ICModVarFields as icmvf
import SpectrumCommon.Const.IC.ICConst as icc

#######################################################################################################
#                                                                                                     #
#                                       Interventions                                                 #
#                                                                                                     #
#######################################################################################################


def get_IC_num_intervs(interv_records: list):
    return len(interv_records)


def get_IC_interv_rec_from_curr_ID(interv_records: list, curr_ID: int):
    return interv_records[curr_ID - 1]


def get_IC_interv_rec(interv_records: list, ID: str):
    interv_recs = [interv_rec for interv_rec in interv_records if interv_rec[icmvf.IC_INTERV_ID] == ID]
    return interv_recs[0] if len(interv_recs) > 0 else gbc.GB_NOT_FOUND

    # num_intervs = get_IC_num_intervs(interv_records)

    # stop = False
    # i = 0
    # while (i < num_intervs) and (not stop):
    #     interv_rec = interv_records[i]

    #     interv_ID = get_IC_interv_ID(interv_rec)

    #     if interv_ID == ID:
    #         stop = True
    #     else:
    #         i = i + 1

    # if stop:
    #     return interv_records[i]
    # else:
    #     return gbc.GB_NOT_FOUND


def get_IC_interv_idx(interv_records: list, ID: str):
    indices = [idx for (idx, interv_rec) in enumerate(interv_records) if interv_rec[icmvf.IC_INTERV_ID] == ID]
    return indices[0] if len(indices) > 0 else gbc.GB_NOT_FOUND

    # idx = gbc.GB_NOT_FOUND

    # i = 0
    # stop = False
    # num_intervs = get_IC_num_intervs(interv_records)

    # while (i < num_intervs) and (not stop):
    #     interv_rec = interv_records[i]

    #     interv_ID = get_IC_interv_ID(interv_rec)

    #     if interv_ID == ID:
    #         idx = i
    #         stop = True

    #     i += 1

    # return idx


###


def get_IC_interv_idx_and_rec(interv_records, ID: str):
    indices_and_recs = [
        (idx, interv_rec) for (idx, interv_rec) in enumerate(interv_records) if interv_rec[icmvf.IC_INTERV_ID] == ID
    ]
    return indices_and_recs[0] if len(indices_and_recs) > 0 else (gbc.GB_NOT_FOUND, {})


###


def get_IC_interv_ID(interv_rec: dict):
    return interv_rec[icmvf.IC_INTERV_ID]


def set_IC_interv_ID(interv_rec: dict, value: str):
    interv_rec[icmvf.IC_INTERV_ID] = value


###


def get_IC_interv_name(interv_rec: dict):
    return interv_rec[icmvf.IC_INTERV_NAME]


def set_IC_interv_name(interv_rec: dict, value: str):
    interv_rec[icmvf.IC_INTERV_NAME] = value


###


def get_IC_interv_string_constant(interv_rec: dict):
    return interv_rec[icmvf.IC_INTERV_STR_CONST]


def set_IC_interv_string_constant(interv_rec: dict, value: str):
    interv_rec[icmvf.IC_INTERV_STR_CONST] = value


###


def get_IC_interv_active(interv_rec: dict):
    return interv_rec[icmvf.IC_INTERV_ACTIVE]


def set_IC_interv_active(interv_rec: dict, value: bool):
    interv_rec[icmvf.IC_INTERV_ACTIVE] = value


###


def get_IC_impact_interv(interv_rec: dict):
    return interv_rec[icmvf.IC_INTERV_IMPACT]


def set_IC_impact_interv(interv_rec: dict, value: bool):
    interv_rec[icmvf.IC_INTERV_IMPACT] = value


###


def get_IC_interv_custom(interv_rec: dict):
    return interv_rec[icmvf.IC_INTERV_CUSTOM]


def set_IC_interv_custom(interv_rec: dict, value: bool):
    interv_rec[icmvf.IC_INTERV_CUSTOM] = value


###


def get_IC_interv_prog_area_ID(interv_rec: dict):
    return interv_rec[icmvf.IC_INTERV_PROG_AREA_ID]


def set_IC_interv_prog_area_ID(interv_rec: dict, value: str):
    interv_rec[icmvf.IC_INTERV_PROG_AREA_ID] = value


###


def get_IC_interv_subgroup_ID(interv_rec: dict):
    return interv_rec[icmvf.IC_INTERV_SUBGROUP_ID]


def set_IC_interv_subgroup_ID(interv_rec: dict, value: str):
    interv_rec[icmvf.IC_INTERV_SUBGROUP_ID] = value


###


def get_IC_interv_special_cases(interv_rec: dict):
    return interv_rec[icmvf.IC_INTERV_SPECIAL_CASES]


def set_IC_interv_special_cases(interv_rec: dict, special_cases: list):
    interv_rec[icmvf.IC_INTERV_SPECIAL_CASES] = special_cases


def add_IC_interv_special_case(interv_rec: dict, mst_ID: str):
    interv_rec[icmvf.IC_INTERV_SPECIAL_CASES].append(mst_ID)
    return interv_rec


def remove_IC_interv_special_case(interv_rec: dict, mst_ID: str):
    interv_rec[icmvf.IC_INTERV_SPECIAL_CASES].remove(mst_ID)
    return interv_rec


###

# def get_IC_interv_PIN(interv_rec: dict, t: int):
#     return interv_rec[icmvf.IC_INTERV_PIN][t]

# def set_IC_interv_PIN(interv_rec: dict, t: int, value: float):
#     interv_rec[icmvf.IC_INTERV_PIN][t] = value

###


def get_IC_interv_targ_pop_direct_entry(interv_rec: dict, t: int):
    return interv_rec[icmvf.IC_INTERV_TARG_POP_REC][icmvf.IC_TARG_POP_DIRECT_ENTRY_VALUES][t]


def set_IC_interv_targ_pop_direct_entry(interv_rec: dict, t: int, value: float):
    interv_rec[icmvf.IC_INTERV_TARG_POP_REC][icmvf.IC_TARG_POP_DIRECT_ENTRY_VALUES][t] = value


###


def get_IC_interv_targ_pop_sex(interv_rec: dict):
    return interv_rec[icmvf.IC_INTERV_TARG_POP_REC][icmvf.IC_TARG_POP_SEX]


def set_IC_interv_targ_pop_sex(interv_rec: dict, value: int):
    interv_rec[icmvf.IC_INTERV_TARG_POP_REC][icmvf.IC_TARG_POP_SEX] = value


###


def get_IC_interv_targ_pop_start_age(interv_rec: dict):
    return interv_rec[icmvf.IC_INTERV_TARG_POP_REC][icmvf.IC_TARG_POP_START_AGE]


def set_IC_interv_targ_pop_start_age(interv_rec: dict, value: int):
    interv_rec[icmvf.IC_INTERV_TARG_POP_REC][icmvf.IC_TARG_POP_START_AGE] = value


###


def get_IC_interv_targ_pop_end_age(interv_rec: dict):
    return interv_rec[icmvf.IC_INTERV_TARG_POP_REC][icmvf.IC_TARG_POP_END_AGE]


def set_IC_interv_targ_pop_end_age(interv_rec: dict, value: int):
    interv_rec[icmvf.IC_INTERV_TARG_POP_REC][icmvf.IC_TARG_POP_END_AGE] = value


###


def get_IC_interv_targ_pop_mst_ID(interv_rec: dict):
    return interv_rec[icmvf.IC_INTERV_TARG_POP_REC][icmvf.IC_TARG_POP_MST_ID]


def set_IC_interv_targ_pop_mst_ID(interv_rec: dict, targ_pop_mstID: int):
    interv_rec[icmvf.IC_INTERV_TARG_POP_REC][icmvf.IC_TARG_POP_MST_ID] = targ_pop_mstID


###


def get_IC_interv_PIN_string_constant(interv_rec: dict):
    return interv_rec[icmvf.IC_INTERV_PIN_STR_CONSTANT]


def set_IC_interv_PIN_string_constant(interv_rec: dict, value: str):
    interv_rec[icmvf.IC_INTERV_PIN_STR_CONSTANT] = value


###


def get_IC_interv_perc_deliv(interv_rec: dict, deliv_chan_IC_curr_ID: int, year_curr_ID: int):
    return interv_rec[icmvf.IC_INTERV_PERC_DELIV_THROUGH_CHAN][deliv_chan_IC_curr_ID - 1][year_curr_ID - 1]


def set_IC_interv_perc_deliv(interv_rec: dict, deliv_chan_IC_curr_ID: int, year_curr_ID: int, value: float):
    interv_rec[icmvf.IC_INTERV_PERC_DELIV_THROUGH_CHAN][deliv_chan_IC_curr_ID - 1][year_curr_ID - 1] = value


###


def get_IC_interv_PIN(interv_rec: dict, t: int):
    return interv_rec[icmvf.IC_INTERV_PIN][t]


def set_IC_interv_PIN(interv_rec: dict, t: int, value: float):
    interv_rec[icmvf.IC_INTERV_PIN][t] = value


###


def get_IC_interv_coverage(interv_rec: dict, t: int):
    return interv_rec[icmvf.IC_INTERV_COVERAGE][t]


def set_IC_interv_coverage(interv_rec: dict, t: int, value: float):
    interv_rec[icmvf.IC_INTERV_COVERAGE][t] = value


###


def get_IC_interv_PIN_editor_visited(interv_rec: dict):
    return interv_rec[icmvf.IC_INTERV_PIN_EDITOR_VISITED]


def set_IC_interv_PIN_editor_visited(interv_rec: dict, value: bool):
    interv_rec[icmvf.IC_INTERV_PIN_EDITOR_VISITED] = value


###

# These are small calculations that are part of the main calculations but also shown in the inputs

###

# def get_IC_interv_drug_cost_per_case(interv_rec: dict, deliv_chan_curr_ID: int, t: int):
#     return interv_rec[icmvf.IC_INTERV_DRUG_COST_PER_AVG_CASE][deliv_chan_curr_ID - 1][t]

# def set_IC_interv_drug_cost_per_case(interv_rec: dict, deliv_chan_curr_ID: int, t: int, value: float):
#     interv_rec[icmvf.IC_INTERV_DRUG_COST_PER_CASE][deliv_chan_curr_ID - 1][t] = value

# ###

# def get_IC_interv_supply_cost_per_case(interv_rec: dict, deliv_chan_curr_ID: int, t: int):
#     return interv_rec[icmvf.IC_INTERV_SUPPLY_COST_PER_CASE][deliv_chan_curr_ID - 1][t]

# def set_IC_interv_supply_cost_per_case(interv_rec: dict, deliv_chan_curr_ID: int, t: int, value: float):
#     interv_rec[icmvf.IC_INTERV_SUPPLY_COST_PER_CASE][deliv_chan_curr_ID - 1][t] = value

# ###

# def get_IC_interv_labor_cost_per_case(interv_rec: dict, deliv_chan_curr_ID: int, t: int):
#     return interv_rec[icmvf.IC_INTERV_LABOR_COST_PER_CASE][deliv_chan_curr_ID - 1][t]

# def set_IC_interv_labor_cost_per_case(interv_rec: dict, deliv_chan_curr_ID: int, t: int, value: float):
#     interv_rec[icmvf.IC_INTERV_LABOR_COST_PER_CASE][deliv_chan_curr_ID - 1][t] = value

# ###

# def get_IC_interv_min_per_avg_case_custom_staff(interv_rec: dict, deliv_chan_curr_ID: int, staff_type_curr_ID: int, t: int):
#     return interv_rec[icmvf.IC_INTERV_MIN_PER_AVG_CASE_CUSTOM_STAFF][deliv_chan_curr_ID - 1][staff_type_curr_ID - 1][t]

# def set_IC_interv_min_per_avg_case_custom_staff(interv_rec: dict, deliv_chan_curr_ID: int, staff_type_curr_ID: int, t: int, value: float):
#     interv_rec[icmvf.IC_INTERV_MIN_PER_AVG_CASE_CUSTOM_STAFF][deliv_chan_curr_ID - 1][staff_type_curr_ID - 1][t] = value

# ###

# def get_IC_interv_min_per_avg_case_default_staff(interv_rec: dict, deliv_chan_curr_ID: int, def_staff_type_curr_ID: int, t: int):
#     return interv_rec[icmvf.IC_INTERV_MIN_PER_AVG_CASE_DEFAULT_STAFF][deliv_chan_curr_ID - 1][def_staff_type_curr_ID - 1][t]

# def set_IC_interv_min_per_avg_case_default_staff(interv_rec: dict, deliv_chan_curr_ID: int, def_staff_type_curr_ID: int, t: int, value: float):
#     interv_rec[icmvf.IC_INTERV_MIN_PER_AVG_CASE_DEFAULT_STAFF][deliv_chan_curr_ID - 1][def_staff_type_curr_ID - 1][t] = value

#######################################################################################################
#                                                                                                     #
#                                       Drugs and supplies                                            #
#                                                                                                     #
#######################################################################################################


def get_IC_num_drugs_supplies(drug_supply_records: list):
    return len(drug_supply_records)


def get_IC_drug_supply_rec_from_curr_ID(drug_supply_records: list, curr_ID: int):
    return drug_supply_records[curr_ID - 1]


def get_IC_drug_supply_rec(drug_supply_records: list, ID: str):
    drug_supply_recs = [
        drug_supply_rec for drug_supply_rec in drug_supply_records if drug_supply_rec[icmvf.IC_DRUG_SUPPLY_ID] == ID
    ]
    return drug_supply_recs[0] if len(drug_supply_recs) > 0 else gbc.GB_NOT_FOUND

    # drug_supply_rec = None

    # ds = 0
    # stop = False
    # num_drug_supplies = get_IC_num_drugs_supplies(drug_supply_records)

    # while (ds < num_drug_supplies) and (not stop):

    #     drug_supply_ID = get_IC_drug_supply_ID(drug_supply_records[ds])

    #     if drug_supply_ID == ID:
    #         drug_supply_rec = drug_supply_records[ds]
    #         stop = True

    #     ds += 1

    # return drug_supply_rec


###


def get_IC_drug_supply_idx(drug_supply_records, ID: str):
    indices = [
        idx
        for (idx, drug_supply_rec) in enumerate(drug_supply_records)
        if drug_supply_rec[icmvf.IC_DRUG_SUPPLY_ID] == ID
    ]
    return indices[0] if len(indices) > 0 else gbc.GB_NOT_FOUND

    # idx = gbc.GB_NOT_FOUND

    # ds = 0
    # stop = False
    # num_drug_supplies = get_IC_num_drugs_supplies(drug_supply_records)

    # while (ds < num_drug_supplies) and (not stop):

    #     drug_supply_ID = get_IC_drug_supply_ID(drug_supply_records[ds])

    #     if drug_supply_ID == ID:
    #         idx = ds
    #         stop = True

    #     ds += 1

    # return idx


###


def get_IC_drug_supply_idx_and_rec(drug_supply_records, ID: str):
    indices_and_recs = [
        (idx, drug_supply_rec)
        for (idx, drug_supply_rec) in enumerate(drug_supply_records)
        if drug_supply_rec[icmvf.IC_DRUG_SUPPLY_ID] == ID
    ]
    return indices_and_recs[0] if len(indices_and_recs) > 0 else (gbc.GB_NOT_FOUND, {})


###


def get_IC_drug_supply_name(drug_supply_rec: dict):
    return drug_supply_rec[icmvf.IC_DRUG_SUPPLY_NAME]


def set_IC_drug_supply_name(drug_supply_rec: dict, value: str):
    drug_supply_rec[icmvf.IC_DRUG_SUPPLY_NAME] = value


###


def get_IC_drug_supply_string_constant(drug_supply_rec: dict):
    return drug_supply_rec[icmvf.IC_DRUG_SUPPLY_STR_CONST]


def set_IC_drug_supply_string_constant(drug_supply_rec: dict, value: str):
    drug_supply_rec[icmvf.IC_DRUG_SUPPLY_STR_CONST] = value


###


def get_IC_drug_supply_ID(drug_supply_rec: dict):
    return drug_supply_rec[icmvf.IC_DRUG_SUPPLY_ID]


def set_IC_drug_supply_ID(drug_supply_rec: dict, value: str):
    drug_supply_rec[icmvf.IC_DRUG_SUPPLY_ID] = value


###


def get_IC_drug_supply_active(drug_supply_rec: dict):
    return drug_supply_rec[icmvf.IC_DRUG_SUPPLY_ACTIVE]


def set_IC_drug_supply_active(drug_supply_rec: dict, value: bool):
    drug_supply_rec[icmvf.IC_DRUG_SUPPLY_ACTIVE] = value


###


def get_IC_drug_supply_custom(drug_supply_rec: dict):
    return drug_supply_rec[icmvf.IC_DRUG_SUPPLY_CUSTOM]


def set_IC_drug_supply_custom(drug_supply_rec: dict, value: bool):
    drug_supply_rec[icmvf.IC_DRUG_SUPPLY_CUSTOM] = value


###


def get_IC_drug_supply_type_mst_ID(drug_supply_rec: dict):
    return drug_supply_rec[icmvf.IC_DRUG_SUPPLY_TYPE_MST_ID]


def set_IC_drug_supply_type_mst_ID(drug_supply_rec: dict, value: int):
    drug_supply_rec[icmvf.IC_DRUG_SUPPLY_TYPE_MST_ID] = value


###


def get_IC_drug_supply_unit_cost(drug_supply_rec: dict, t: int):
    return drug_supply_rec[icmvf.IC_DRUG_SUPPLY_UNIT_COST][t]


def set_IC_drug_supply_unit_cost(drug_supply_rec: dict, t: int, value: float):
    drug_supply_rec[icmvf.IC_DRUG_SUPPLY_UNIT_COST][t] = value


###


def add_IC_drug_supply_applic_prog_area(drug_supply_rec: dict, prog_area_ID: str):
    drug_supply_rec[icmvf.IC_DRUG_SUPPLY_APPLIC_PROG_AREA_LIST].append(prog_area_ID)
    return drug_supply_rec


def remove_IC_drug_supply_applic_prog_area(drug_supply_rec: dict, prog_area_ID: str):
    drug_supply_rec[icmvf.IC_DRUG_SUPPLY_APPLIC_PROG_AREA_LIST].remove(prog_area_ID)
    return drug_supply_rec


def clear_IC_drug_supply_applic_prog_area(drug_supply_rec: dict):
    drug_supply_rec[icmvf.IC_DRUG_SUPPLY_APPLIC_PROG_AREA_LIST].clear()
    return drug_supply_rec


#######################################################################################################
#                                                                                                     #
#                                       Treatment input groups (TIGs)                                 #
#                                                                                                     #
#######################################################################################################


# Returns all TIG records for a particular intervention
def get_IC_TIG_records(TIG_records_all: list, interv_ID: str):
    # Reduce list to contain only records for the specified intervention.
    TIG_records_for_interv = [TIG_rec for TIG_rec in TIG_records_all if TIG_rec[icmvf.IC_TIG_INTERV_ID] == interv_ID]
    return TIG_records_for_interv


#


def add_IC_TIG_rec(TIG_records: list, value: dict):
    TIG_records.append(value)


###


def remove_IC_TIG_rec(TIG_records: list, interv_ID: str, deliv_chan_ID: str, treat_input_group_ID: str):
    TIG_recs = [
        TIG_rec
        for TIG_rec in TIG_records
        if not (
            (TIG_rec[icmvf.IC_TIG_INTERV_ID] == interv_ID)
            and (TIG_rec[icmvf.IC_TIG_DELIV_CHAN_ID] == deliv_chan_ID)
            and (TIG_rec[icmvf.IC_TIG_ID] == treat_input_group_ID)
        )
    ]
    return TIG_recs


###


def remove_IC_TIG_rec_by_name(TIG_records: list, interv_ID: str, deliv_chan_ID: str, name: str):
    TIG_recs = [
        TIG_rec
        for TIG_rec in TIG_records
        if not (
            (TIG_rec[icmvf.IC_TIG_INTERV_ID] == interv_ID)
            and (TIG_rec[icmvf.IC_TIG_DELIV_CHAN_ID] == deliv_chan_ID)
            and (TIG_rec[icmvf.IC_TIG_NAME] == name)
        )
    ]
    return TIG_recs


###


# Return all treatment input groups that are not associated with an intervention, or the ones associated with the intervention at the particular delivery
# channel specified. Used when copying treatment inputs so we can clear intervention treatment input groups at all channels except one.
def remove_IC_TIG_records_for_interv_except_deliv_chan(TIG_records: list, interv_ID: str, deliv_chan_ID: str):
    TIG_records_reduced = [
        TIG_rec
        for TIG_rec in TIG_records
        if (TIG_rec[icmvf.IC_TIG_INTERV_ID] != interv_ID) or (TIG_rec[icmvf.IC_TIG_DELIV_CHAN_ID] == deliv_chan_ID)
    ]
    return TIG_records_reduced


###


def remove_IC_TIG_records(TIG_records: list, interv_ID: str):
    TIG_records_reduced = [TIG_rec for TIG_rec in TIG_records if TIG_rec[icmvf.IC_TIG_INTERV_ID] != interv_ID]
    return TIG_records_reduced


###


def get_IC_TIG_rec(TIG_records: list, interv_ID: str, deliv_chan_ID: str, treat_input_group_ID: str):
    TIG_recs = [
        TIG_rec
        for TIG_rec in TIG_records
        if (
            (TIG_rec[icmvf.IC_TIG_INTERV_ID] == interv_ID)
            and (TIG_rec[icmvf.IC_TIG_DELIV_CHAN_ID] == deliv_chan_ID)
            and (TIG_rec[icmvf.IC_TIG_ID] == treat_input_group_ID)
        )
    ]
    return TIG_recs[0] if len(TIG_recs) > 0 else gbc.GB_NOT_FOUND

    # num_groups = len(TIG_records)
    # stop = False
    # i = 0

    # while (i < num_groups) and (not stop):
    #     TIG_rec_i = TIG_records[i]

    #     interv_ID_i = get_IC_TIG_interv_ID(TIG_rec_i)
    #     deliv_chan_ID_i = get_IC_TIG_deliv_chan_ID(TIG_rec_i)
    #     treat_input_group_ID_i = get_IC_TIG_ID(TIG_rec_i)

    #     if (interv_ID_i == interv_ID) and (deliv_chan_ID_i == deliv_chan_ID) and (treat_input_group_ID_i == treat_input_group_ID):
    #         stop = True
    #     else:
    #         i = i + 1

    # if stop:
    #     return TIG_records[i]
    # else:
    #     return gbc.GB_NOT_FOUND


###


def get_IC_TIG_rec_from_name(TIG_records: list, interv_ID: str, deliv_chan_ID: str, name: str):
    TIG_recs = [
        TIG_rec
        for TIG_rec in TIG_records
        if (
            (TIG_rec[icmvf.IC_TIG_INTERV_ID] == interv_ID)
            and (TIG_rec[icmvf.IC_TIG_DELIV_CHAN_ID] == deliv_chan_ID)
            and (TIG_rec[icmvf.IC_TIG_NAME] == name)
        )
    ]
    return TIG_recs[0] if len(TIG_recs) > 0 else gbc.GB_NOT_FOUND


###


def get_IC_TIG_records_for_interv_and_deliv_chan(TIG_records: list, interv_ID: str, deliv_chan_ID: str):
    TIG_records_reduced = [
        TIG_rec
        for TIG_rec in TIG_records
        if (TIG_rec[icmvf.IC_TIG_INTERV_ID] == interv_ID) and (TIG_rec[icmvf.IC_TIG_DELIV_CHAN_ID] == deliv_chan_ID)
    ]
    return TIG_records_reduced


###


def get_IC_TIG_idx(TIG_records: list, interv_ID: str, deliv_chan_ID: str, treat_input_group_ID: str):
    indices = [
        idx
        for (idx, TIG_rec) in enumerate(TIG_records)
        if (TIG_rec[icmvf.IC_TIG_INTERV_ID] == interv_ID)
        and (TIG_rec[icmvf.IC_TIG_DELIV_CHAN_ID] == deliv_chan_ID)
        and (TIG_rec[icmvf.IC_TIG_ID] == treat_input_group_ID)
    ]
    return indices[0] if len(indices) > 0 else gbc.GB_NOT_FOUND

    # idx = gbc.GB_NOT_FOUND

    # i = 0
    # stop = False
    # num_groups = len(TIG_records)

    # while (i < num_groups) and (not stop):
    #     TIG_rec_i = TIG_records[i]

    #     interv_ID_i = get_IC_TIG_interv_ID(TIG_rec_i)
    #     deliv_chan_ID_i = get_IC_TIG_deliv_chan_ID(TIG_rec_i)
    #     treat_input_group_ID_i = get_IC_TIG_ID(TIG_rec_i)

    #     if (interv_ID_i == interv_ID) and (deliv_chan_ID_i == deliv_chan_ID) and (treat_input_group_ID_i == treat_input_group_ID):
    #         idx = i
    #         stop = True

    #     i = i + 1

    # return idx


###


def get_IC_TIG_name(treat_input_group_rec: dict):
    return treat_input_group_rec[icmvf.IC_TIG_NAME]


def set_IC_TIG_name(treat_input_group_rec: dict, value: str):
    treat_input_group_rec[icmvf.IC_TIG_NAME] = value
    # Unconventional, but allows us to use in list comprehensions to set values.
    return treat_input_group_rec


def set_IC_TIG_names_for_interv_and_deliv_chan(
    TIG_records: list, interv_ID: str, deliv_chan_ID: str, old_name: str, new_name: str
):
    for TIG_rec in TIG_records:
        if (
            TIG_rec[icmvf.IC_TIG_INTERV_ID] == interv_ID
            and TIG_rec[icmvf.IC_TIG_DELIV_CHAN_ID] == deliv_chan_ID
            and TIG_rec[icmvf.IC_TIG_NAME] == old_name
        ):
            set_IC_TIG_name(TIG_rec, new_name)
    return TIG_records


###


def get_IC_TIG_string_constant(treat_input_group_rec: dict):
    return treat_input_group_rec[icmvf.IC_TIG_STR_CONST]


def set_IC_TIG_string_constant(treat_input_group_rec: dict, value: str):
    treat_input_group_rec[icmvf.IC_TIG_STR_CONST] = value


###


def get_IC_TIG_interv_ID(treat_input_group_rec: dict):
    return treat_input_group_rec[icmvf.IC_TIG_INTERV_ID]


def set_IC_TIG_interv_ID(treat_input_group_rec: dict, value: str):
    treat_input_group_rec[icmvf.IC_TIG_INTERV_ID] = value


###


def get_IC_TIG_deliv_chan_ID(treat_input_group_rec: dict):
    return treat_input_group_rec[icmvf.IC_TIG_DELIV_CHAN_ID]


def set_IC_TIG_deliv_chan_ID(treat_input_group_rec: dict, value: str):
    treat_input_group_rec[icmvf.IC_TIG_DELIV_CHAN_ID] = value


###


def get_IC_TIG_ID(treat_input_group_rec: dict):
    return treat_input_group_rec[icmvf.IC_TIG_ID]


def set_IC_TIG_ID(treat_input_group_rec: dict, value: str):
    treat_input_group_rec[icmvf.IC_TIG_ID] = value


###

#######################################################################################################
#                                                                                                     #
#                                       Treatment inputs (TI) - all                                   #
#                                                                                                     #
#######################################################################################################


def get_IC_TI_rec(TI_records: list, interv_ID: str, deliv_chan_ID: str, TIG_ID: str, TI_ID: str):
    TI_recs = [
        TI_rec
        for TI_rec in TI_records
        if (
            (TI_rec[icmvf.IC_TI_INTERV_ID] == interv_ID)
            and (TI_rec[icmvf.IC_TI_DELIV_CHAN_ID] == deliv_chan_ID)
            and (TI_rec[icmvf.IC_TI_GROUP_ID] == TIG_ID)
            and (TI_rec[icmvf.IC_TI_ID] == TI_ID)
        )
    ]
    return TI_recs[0] if len(TI_recs) > 0 else gbc.GB_NOT_FOUND


def get_IC_TI_records_for_interv(TI_records: list, interv_ID: str):
    # Reduce list to contain only records for the specified intervention.
    TI_records_for_interv = [TI_rec for TI_rec in TI_records if TI_rec[icmvf.IC_TI_INTERV_ID] == interv_ID]
    return TI_records_for_interv


###


def get_IC_TI_records_for_deliv_chan(TI_records: list, deliv_chan_ID: str):
    # Reduce list to contain only records for the specified delivery channel.
    TI_records_for_deliv_chan = [TI_rec for TI_rec in TI_records if TI_rec[icmvf.IC_TI_DELIV_CHAN_ID] == deliv_chan_ID]
    return TI_records_for_deliv_chan


###


def get_IC_TI_records_for_interv_and_deliv_chan(TI_records: list, interv_ID: str, deliv_chan_ID: str):
    TI_records_reduced = [
        TI_rec
        for TI_rec in TI_records
        if (TI_rec[icmvf.IC_TI_INTERV_ID] == interv_ID) and (TI_rec[icmvf.IC_TI_DELIV_CHAN_ID] == deliv_chan_ID)
    ]
    return TI_records_reduced


###


# Useful for getting all treatment inputs that are the same for multiple delivery channels.
def get_IC_TI_records_for_interv_group_input(TI_records: list, TI_type_mst_ID: int, TI_rec_match: dict):
    TI_records_reduced = [
        TI_rec
        for TI_rec in TI_records
        if (
            (TI_rec[icmvf.IC_TI_INTERV_ID] == TI_rec_match[icmvf.IC_TI_INTERV_ID])
            and (TI_rec[icmvf.IC_TI_GROUP_ID] == TI_rec_match[icmvf.IC_TI_GROUP_ID])
            and (TI_rec[icmvf.IC_TI_ID] == TI_rec_match[icmvf.IC_TI_ID])
            and (math.isclose(TI_rec[icmvf.IC_TI_PERC_APPLIED][0], TI_rec_match[icmvf.IC_TI_PERC_APPLIED][0]))
            and (TI_rec[icmvf.IC_TI_NOTE] == TI_rec_match[icmvf.IC_TI_NOTE])
            and (
                (
                    (TI_type_mst_ID == icc.IC_TI_DRUGS_SUPPLIES_MST_ID)
                    and (
                        math.isclose(
                            TI_rec[icmvf.IC_TI_DRUG_SUPPLY_TIMES_PER_DAY],
                            TI_rec_match[icmvf.IC_TI_DRUG_SUPPLY_TIMES_PER_DAY],
                        )
                    )
                    and (
                        math.isclose(
                            TI_rec[icmvf.IC_TI_DRUG_SUPPLY_DAYS_PER_CASE],
                            TI_rec_match[icmvf.IC_TI_DRUG_SUPPLY_DAYS_PER_CASE],
                        )
                    )
                    and (
                        math.isclose(
                            TI_rec[icmvf.IC_TI_DRUG_SUPPLY_NUMBER], TI_rec_match[icmvf.IC_TI_DRUG_SUPPLY_NUMBER]
                        )
                    )
                )
                or (
                    (TI_type_mst_ID == icc.IC_TI_MED_PERSONNEL_TIME_MST_ID)
                    and (
                        math.isclose(
                            TI_rec[icmvf.IC_TI_MED_PERSONNEL_NUM_OF_DAYS],
                            TI_rec_match[icmvf.IC_TI_MED_PERSONNEL_NUM_OF_DAYS],
                        )
                    )
                    and (
                        math.isclose(
                            TI_rec[icmvf.IC_TI_MED_PERSONNEL_MINUTES], TI_rec_match[icmvf.IC_TI_MED_PERSONNEL_MINUTES]
                        )
                    )
                )
                or (
                    (TI_type_mst_ID == icc.IC_TI_OUTPAT_VISITS_INPAT_DAYS_MST_ID)
                    and (
                        math.isclose(
                            TI_rec[icmvf.IC_TI_OUTPAT_INPAT_UNITS_PER_CASE],
                            TI_rec_match[icmvf.IC_TI_OUTPAT_INPAT_UNITS_PER_CASE],
                        )
                    )
                )
            )
        )
    ]
    return TI_records_reduced


###


def add_IC_TI_rec(TI_records: list, value: dict):
    TI_records.append(value)


##


# Removes a single treatment input record.
def remove_IC_TI_rec(TI_records_all: list, interv_ID: str, deliv_chan_ID: str, TIG_ID: str, TI_ID: str):
    TI_recs = [
        TI_rec
        for TI_rec in TI_records_all
        if not (
            (TI_rec[icmvf.IC_TI_INTERV_ID] == interv_ID)
            and (TI_rec[icmvf.IC_TI_DELIV_CHAN_ID] == deliv_chan_ID)
            and (TI_rec[icmvf.IC_TI_GROUP_ID] == TIG_ID)
            and (TI_rec[icmvf.IC_TI_ID] == TI_ID)
        )
    ]
    return TI_recs

    # idx = gbc.GB_NOT_FOUND

    # i = 0
    # stop = False
    # num_treat_inputs = len(TI_records_all)

    # while (i < num_treat_inputs) and (not stop):
    #     TI_rec_i = TI_records_all[i]

    #     interv_ID_i = get_IC_TI_interv_ID(TI_rec_i)
    #     deliv_chan_ID_i = get_IC_TI_deliv_chan_ID(TI_rec_i)
    #     treat_input_group_ID_i = get_IC_TI_group_ID(TI_rec_i)
    #     treat_input_ID_i = get_IC_TI_ID(TI_rec_i)

    #     if (interv_ID_i == interv_ID) and (deliv_chan_ID_i == deliv_chan_ID) and (treat_input_group_ID_i == treat_input_group_ID) and (treat_input_ID_i == treat_input_ID):
    #         del TI_records_all[i]
    #         stop = True

    #     i = i + 1

    # return idx


###


# Removes all treatment input records associated with a particular intervention
def remove_IC_TI_records_for_interv(TI_records: list, interv_ID: str):
    TI_records_reduced = [TI_rec for TI_rec in TI_records if TI_rec[icmvf.IC_TI_INTERV_ID] != interv_ID]
    return TI_records_reduced


# Return all treatment inputs that are not associated with an intervention, or the ones associated with the intervention at the particular delivery
# channel specified. Used when copying treatment inputs so we can clear intervention treatment inputs at all channels except one.
def remove_IC_TI_records_for_interv_except_deliv_chan(TI_records: list, interv_ID: str, deliv_chan_ID: str):
    TI_records_reduced = [
        TI_rec
        for TI_rec in TI_records
        if (TI_rec[icmvf.IC_TI_INTERV_ID] != interv_ID) or (TI_rec[icmvf.IC_TI_DELIV_CHAN_ID] == deliv_chan_ID)
    ]
    return TI_records_reduced


# Removes all treatment input records in a particular group.
def remove_IC_TI_records_for_group(TI_records_all: list, interv_ID: str, deliv_chan_ID: str, TIG_ID: str):
    TI_recs = [
        TI_rec
        for TI_rec in TI_records_all
        if not (
            (TI_rec[icmvf.IC_TI_INTERV_ID] == interv_ID)
            and (TI_rec[icmvf.IC_TI_DELIV_CHAN_ID] == deliv_chan_ID)
            and (TI_rec[icmvf.IC_TI_GROUP_ID] == TIG_ID)
        )
    ]
    return TI_recs


###


def get_IC_TI_interv_ID(treat_input_rec: dict):
    return treat_input_rec[icmvf.IC_TI_INTERV_ID]


def set_IC_TI_interv_ID(treat_input_rec: dict, value: str):
    treat_input_rec[icmvf.IC_TI_INTERV_ID] = value


###


def get_IC_TI_deliv_chan_ID(treat_input_rec: dict):
    return treat_input_rec[icmvf.IC_TI_DELIV_CHAN_ID]


def set_IC_TI_deliv_chan_ID(treat_input_rec: dict, value: str):
    treat_input_rec[icmvf.IC_TI_DELIV_CHAN_ID] = value


###


def get_IC_TI_group_name(treat_input_rec: dict):
    return treat_input_rec[icmvf.IC_TIG_NAME]


def set_IC_TI_group_name(treat_input_rec: dict, value: str):
    treat_input_rec[icmvf.IC_TIG_NAME] = value


###


def get_IC_TI_group_string_constant(treat_input_rec: dict):
    return treat_input_rec[icmvf.IC_TIG_STR_CONST]


def set_IC_TI_group_string_constant(treat_input_rec: dict, value: str):
    treat_input_rec[icmvf.IC_TIG_STR_CONST] = value


###


def get_IC_TI_group_ID(treat_input_rec: dict):
    return treat_input_rec[icmvf.IC_TIG_ID]


def set_IC_TI_group_ID(treat_input_rec: dict, value: str):
    treat_input_rec[icmvf.IC_TIG_ID] = value


###


def get_IC_TI_ID(treat_input_rec: dict):
    return treat_input_rec[icmvf.IC_TI_ID]


def set_IC_TI_ID(treat_input_rec: dict, value: str):
    treat_input_rec[icmvf.IC_TI_ID] = value


###


def get_IC_TI_perc_applied(treat_input_rec: dict, t: int):
    return treat_input_rec[icmvf.IC_TI_PERC_APPLIED][t]


def set_IC_TI_perc_applied(treat_input_rec: dict, t: int, value: float):
    treat_input_rec[icmvf.IC_TI_PERC_APPLIED][t] = value


###


def get_IC_TI_note_string_constant(treat_input_rec: dict):
    return treat_input_rec[icmvf.IC_TI_NOTE_STR_CONST]


def set_IC_TI_note_string_constant(treat_input_rec: dict, value: str):
    treat_input_rec[icmvf.IC_TI_NOTE_STR_CONST] = value


###


def get_IC_TI_note(treat_input_rec: dict):
    return treat_input_rec[icmvf.IC_TI_NOTE]


def set_IC_TI_note(treat_input_rec: dict, value: str):
    treat_input_rec[icmvf.IC_TI_NOTE] = value


#######################################################################################################
#                                                                                                     #
#                                  Treatment inputs (TI) - drugs and supplies only                    #
#                                                                                                     #
#######################################################################################################


def get_IC_TI_drug_supply_times_per_day(TI_drug_supply_rec: dict):
    return TI_drug_supply_rec[icmvf.IC_TI_DRUG_SUPPLY_TIMES_PER_DAY]


def set_IC_TI_drug_supply_times_per_day(TI_drug_supply_rec: dict, value: int):
    TI_drug_supply_rec[icmvf.IC_TI_DRUG_SUPPLY_TIMES_PER_DAY] = value


###


def get_IC_TI_drug_supply_days_per_case(TI_drug_supply_rec: dict):
    return TI_drug_supply_rec[icmvf.IC_TI_DRUG_SUPPLY_DAYS_PER_CASE]


def set_IC_TI_drug_supply_days_per_case(TI_drug_supply_rec: dict, value: int):
    TI_drug_supply_rec[icmvf.IC_TI_DRUG_SUPPLY_DAYS_PER_CASE] = value


###


def get_IC_TI_drug_supply_number(TI_drug_supply_rec: dict):
    return TI_drug_supply_rec[icmvf.IC_TI_DRUG_SUPPLY_NUMBER]


def set_IC_TI_drug_supply_number(TI_drug_supply_rec: dict, value: int):
    TI_drug_supply_rec[icmvf.IC_TI_DRUG_SUPPLY_NUMBER] = value


#######################################################################################################
#                                                                                                     #
#                          Treatment inputs - medical personnel time only                             #
#                                                                                                     #
#######################################################################################################


def get_IC_TI_med_personnel_num_days(TI_med_personnel_rec: dict):
    return TI_med_personnel_rec[icmvf.IC_TI_MED_PERSONNEL_NUM_OF_DAYS]


def set_IC_TI_med_personnel_num_days(TI_med_personnel_rec: dict, value: int):
    TI_med_personnel_rec[icmvf.IC_TI_MED_PERSONNEL_NUM_OF_DAYS] = value


###


def get_IC_TI_med_personnel_minutes(TI_med_personnel_rec: dict):
    return TI_med_personnel_rec[icmvf.IC_TI_MED_PERSONNEL_MINUTES]


def set_IC_TI_med_personnel_minutes(TI_med_personnel_rec: dict, value: float):
    TI_med_personnel_rec[icmvf.IC_TI_MED_PERSONNEL_MINUTES] = value


###


def get_IC_TI_med_personnel_custom(TI_med_personnel_rec: dict):
    return TI_med_personnel_rec[icmvf.IC_TI_MED_PERSONNEL_CUSTOM_STAFF_TYPE]


def set_IC_TI_med_personnel_custom(TI_med_personnel_rec: dict, value: bool):
    TI_med_personnel_rec[icmvf.IC_TI_MED_PERSONNEL_CUSTOM_STAFF_TYPE] = value


#######################################################################################################
#                                                                                                     #
#                           Treatment inputs - outpatient days and inpatient visits only              #
#                                                                                                     #
#######################################################################################################


def get_IC_TI_outpat_inpat_units_per_case(TI_outpat_inpat_rec: dict):
    return TI_outpat_inpat_rec[icmvf.IC_TI_OUTPAT_INPAT_UNITS_PER_CASE]


def set_IC_TI_outpat_inpat_units_per_case(TI_outpat_inpat_rec: dict, value: float):
    TI_outpat_inpat_rec[icmvf.IC_TI_OUTPAT_INPAT_UNITS_PER_CASE] = value


#######################################################################################################
#                                                                                                     #
#                                       Target populations                                            #
#                                                                                                     #
#######################################################################################################


def get_IC_num_def_targ_pops(targ_pop_records: list):
    return len(targ_pop_records)


###


def get_IC_def_targ_pop_rec(targ_pop_records: list = [], mst_ID: int | None = None):
    targ_pop_recs = [
        targ_pop_rec for targ_pop_rec in targ_pop_records if targ_pop_rec[icmvf.IC_TARG_POP_DEF_MST_ID] == mst_ID
    ]
    return targ_pop_recs[0] if len(targ_pop_recs) > 0 else gbc.GB_NOT_FOUND

    # num_targ_pops = get_num_targ_pops(targ_pop_records)

    # stop = False
    # i = 0
    # while (i < num_targ_pops - 1) and (not stop):
    #     targ_pop_rec = targ_pop_records[i]

    #     mst_ID_i = get_IC_targ_pop_mst_ID(targ_pop_rec)

    #     if mst_ID_i == mst_ID:
    #         stop = True
    #     else:
    #         i = i + 1

    # if stop:
    #     return targ_pop_records[i]
    # else:
    #     return gbc.GB_NOT_FOUND


###


def get_IC_def_targ_pop_mst_ID(targ_pop_rec: dict):
    return targ_pop_rec[icmvf.IC_TARG_POP_DEF_MST_ID]


def set_IC_def_targ_pop_mst_ID(targ_pop_rec: dict, value: int):
    targ_pop_rec[icmvf.IC_TARG_POP_DEF_MST_ID] = value


###


def get_IC_def_targ_pop_string_constant(targ_pop_rec: dict):
    return targ_pop_rec[icmvf.IC_TARG_POP_DEF_STR_CONST]


def set_IC_def_targ_pop_string_constant(targ_pop_rec: dict, value: str):
    targ_pop_rec[icmvf.IC_TARG_POP_DEF_STR_CONST] = value


###


def get_IC_def_targ_pop_name(targ_pop_rec: dict):
    return targ_pop_rec[icmvf.IC_TARG_POP_DEF_NAME]


def set_IC_def_targ_pop_name(targ_pop_rec: dict, value: str):
    targ_pop_rec[icmvf.IC_TARG_POP_DEF_NAME] = value


###


def add_IC_def_targ_pop_applic_prog_area(targ_pop_rec: dict, prog_area_ID: str):
    targ_pop_rec[icmvf.IC_TARG_POP_DEF_APPLIC_PROG_AREA_IDS].append(prog_area_ID)
    return targ_pop_rec


def remove_IC_def_targ_pop_applic_prog_area(targ_pop_rec: dict, prog_area_ID: str):
    targ_pop_rec[icmvf.IC_TARG_POP_DEF_APPLIC_PROG_AREA_IDS].remove(prog_area_ID)
    return targ_pop_rec


def get_IC_def_targ_pop_applic_prog_area(targ_pop_rec: dict, prog_area_ID: str):
    return prog_area_ID in targ_pop_rec[icmvf.IC_TARG_POP_DEF_APPLIC_PROG_AREA_IDS]


###


def get_IC_def_targ_pop_req_mod(targ_pop_rec: dict, mod_mst_ID: str):
    return mod_mst_ID in targ_pop_rec[icmvf.IC_TARG_POP_DEF_REQ_MOD_MST_IDS]


def add_IC_def_targ_pop_req_mod(targ_pop_rec: dict, mod_mst_ID: str):
    targ_pop_rec[icmvf.IC_TARG_POP_DEF_REQ_MOD_MST_IDS].append(mod_mst_ID)
    return targ_pop_rec


def remove_IC_def_targ_pop_applic_req_mod(targ_pop_rec: dict, mod_mst_ID: str):
    targ_pop_rec[icmvf.IC_TARG_POP_DEF_REQ_MOD_MST_IDS].remove(mod_mst_ID)
    return targ_pop_rec


#######################################################################################################
#                                                                                                     #
#                                       Alternative PIN age group set 1                               #
#                                                                                                     #
#######################################################################################################


def get_IC_alt_PIN_age_group_set_1_rec(get_IC_alt_PIN_age_group_set_1_records: list, interv_ID: str):
    get_IC_alt_PIN_age_group_set_1_recs = [
        rec
        for rec in get_IC_alt_PIN_age_group_set_1_records
        if rec[icmvf.IC_ALT_PIN_AGE_GROUP_SET_1_INTERV_ID] == interv_ID
    ]
    return get_IC_alt_PIN_age_group_set_1_recs[0] if len(get_IC_alt_PIN_age_group_set_1_recs) > 0 else gbc.GB_NOT_FOUND

    # num_records = len(get_IC_alt_PIN_age_group_set_1_list)

    # stop = False
    # i = 0
    # while (i < num_records - 1) and (not stop):
    #     alt_PIN_age_group_set_1_rec = get_IC_alt_PIN_age_group_set_1_list[i]

    #     interv_ID_i = alt_PIN_age_group_set_1_rec[icmvf.IC_ALT_PIN_AGE_GROUP_SET_1_INTERV_ID]

    #     if interv_ID_i == interv_ID:
    #         stop = True
    #     else:
    #         i = i + 1

    # if stop:
    #     return alt_PIN_age_group_set_1_rec[i]
    # else:
    #     return gbc.GB_NOT_FOUND


def get_IC_alt_PIN_age_group_set_1(alt_PIN_age_group_set_1_rec: dict, t: int, a: int):
    return alt_PIN_age_group_set_1_rec[icmvf.IC_ALT_PIN_AGE_GROUP_SET_1_VALUE][a - 1][t]


#######################################################################################################
#                                                                                                     #
#                                       Alternative PIN age group set 2                               #
#                                                                                                     #
#######################################################################################################


def get_IC_alt_PIN_age_group_set_2_rec(get_IC_alt_PIN_age_group_set_2_list: list, interv_ID: str):
    get_IC_alt_PIN_age_group_set_2_recs = [
        rec
        for rec in get_IC_alt_PIN_age_group_set_2_list
        if rec[icmvf.IC_ALT_PIN_AGE_GROUP_SET_2_INTERV_ID] == interv_ID
    ]
    return get_IC_alt_PIN_age_group_set_2_recs[0] if len(get_IC_alt_PIN_age_group_set_2_recs) > 0 else gbc.GB_NOT_FOUND

    # num_records = len(get_IC_alt_PIN_age_group_set_2_list)

    # stop = False
    # i = 0
    # while (i < num_records - 1) and (not stop):
    #     alt_PIN_age_group_set_2_rec = get_IC_alt_PIN_age_group_set_2_list[i]

    #     interv_ID_i = alt_PIN_age_group_set_2_rec[icmvf.IC_ALT_PIN_AGE_GROUP_SET_2_INTERV_ID]

    #     if interv_ID_i == interv_ID:
    #         stop = True
    #     else:
    #         i = i + 1

    # if stop:
    #     return alt_PIN_age_group_set_2_rec[i]
    # else:
    #     return gbc.GB_NOT_FOUND


def get_IC_alt_PIN_age_group_set_2(alt_PIN_age_group_set_2_rec: dict, t: int, a: int):
    return alt_PIN_age_group_set_2_rec[icmvf.IC_ALT_PIN_AGE_GROUP_SET_2_VALUE][a - 1][t]


#######################################################################################################
#                                                                                                     #
#                                   Disease-specific costing  / TB costing                            #
#                                                                                                     #
#######################################################################################################


def get_IC_outpat_visit_inpat_day_unit_cost_DSC(
    outpat_visit_inpat_day_unit_cost_list, visit_type_curr_ID, deliv_chan_curr_ID, prog_area_curr_ID
):
    return outpat_visit_inpat_day_unit_cost_list[visit_type_curr_ID - 1, deliv_chan_curr_ID - 1, prog_area_curr_ID - 1]


def set_IC_outpat_visit_inpat_day_unit_cost_DSC(
    outpat_visit_inpat_day_unit_cost_list, visit_type_curr_ID, deliv_chan_curr_ID, prog_area_curr_ID, value
):
    outpat_visit_inpat_day_unit_cost_list[visit_type_curr_ID - 1, deliv_chan_curr_ID - 1, prog_area_curr_ID - 1] = value


#######################################################################################################
#                                                                                                     #
#                                       Comprehensive vs Specific Costing                             #
#                                                                                                     #
#######################################################################################################


def get_IC_outpat_visit_inpat_day_costs_CVS(outpat_visit_inpat_day_costs_list, visit_type_curr_ID, deliv_chan_curr_ID):
    return outpat_visit_inpat_day_costs_list[visit_type_curr_ID - 1, deliv_chan_curr_ID - 1]


def set_IC_outpat_visit_inpat_day_costs_CVS(
    outpat_visit_inpat_day_costs_list, visit_type_curr_ID, deliv_chan_curr_ID, value
):
    outpat_visit_inpat_day_costs_list[visit_type_curr_ID - 1, deliv_chan_curr_ID - 1] = value


#######################################################################################################
#                                                                                                     #
#                                       Results                                                       #
#                                                                                                     #
#######################################################################################################

###


def get_IC_num_services_by_deliv_chan(num_services_by_deliv_chan_array, interv_curr_ID, deliv_chan_curr_ID, t):
    return num_services_by_deliv_chan_array[interv_curr_ID - 1, deliv_chan_curr_ID - 1, t]


def set_IC_num_services_by_deliv_chan(num_services_by_deliv_chan_array, interv_curr_ID, deliv_chan_curr_ID, t, value):
    num_services_by_deliv_chan_array[interv_curr_ID - 1, deliv_chan_curr_ID - 1, t] = value
