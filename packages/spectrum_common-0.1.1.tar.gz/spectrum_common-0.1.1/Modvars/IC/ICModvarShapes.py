from SpectrumCommon.Const.IC import *
import SpectrumCommon.Const.IC.ICTags as icmvt
from SpectrumCommon.Modvars.GB.GBDefs import *

ic_interv_dim = 'ic_interv'
ic_interv_indices = {
    
}

ic_targ_pop_dim = 'ic_targ_pop'
ic_targ_pop_indices = {}

ic_deliv_channel_dim = 'ic_deliv_channel'
ic_deliv_channel_indices = {
    1: "Community",
    2: "Outreach",
    5: "Prehospital emergency",
    6: "General outpatient services",
    4: "First referral",
    7: "Second referral and above",
    
}

ic_visit_type_dim = 'ic_visit_type'
ic_visit_type_indices = {
    IC_OUTPATIENT_VISIT_CURR_ID : 'Outpatient visit',
    IC_INPATIENT_DAY_CURR_ID    : 'Inpatient day'
}

ic_treat_input_type_dim = 'ic_treat_input_type'
ic_treat_input_type_indices = {
}

ic_drug_supply_dim = 'ic_drug_supply'
ic_drug_supply_indices = {
}

ic_med_personnel_dim = 'ic_med_personnel'
ic_med_personnel_indices = {
}

ic_costed_deliv_chan_dim = 'ic_costed_deliv_chan'
ic_costed_deliv_chan_ids = {}

ic_staff_dim = 'ic_staff'
ic_staff_indices = {}   

ic_prog_area_dim = 'ic_prog_area'
ic_prog_area_indices = {}

ic_group_set_1_dim = 'ic_group_set_1'
ic_group_set_1_indices = { 
    IC_AGE_GROUP_1_LT_50_CURR_ID    : 'Less than 50',
    IC_AGE_GROUP_1_50_TO_59_CURR_ID : '50 to 59',
    IC_AGE_GROUP_1_60_TO_69_CURR_ID : '60 to 69',
    IC_AGE_GROUP_1_70_PLUS_CURR_ID  : '70+',
}
ic_group_set_2_dim = 'ic_group_set_2'
ic_group_set_2_indices = {

# Age group 2: 0-4, 5-14, 15-29, 30-44, 45-59, 60-69, 70-79, 80+
    IC_AGE_GROUP_2_0_TO_4_CURR_ID    : '0 to 4',
    IC_AGE_GROUP_2_5_TO_14_CURR_ID   : '5 to 14',
    IC_AGE_GROUP_2_15_TO_29_CURR_ID  : '15 to 29',
    IC_AGE_GROUP_2_30_TO_44_CURR_ID  : '30 to 44',  
    IC_AGE_GROUP_2_45_TO_59_CURR_ID  : '45 to 59',
    IC_AGE_GROUP_2_60_TO_69_CURR_ID  : '60 to 69',
    IC_AGE_GROUP_2_70_TO_79_CURR_ID  : '70 to 79',
    IC_AGE_GROUP_2_80_PLUS_CURR_ID   : '80+',
}

IC_modvar_shapes = {
        icmvt.IC_VERSION_TAG_V1                                   : gb_int_shape('IC Version'),
        icmvt.IC_DATA_CHANGED_TAG_V1                              : gb_bool_shape('IC Data Changed'), 
        icmvt.IC_PROJ_VALID_TAG_V1                                : gb_bool_shape('IC Projection Valid'), 
        icmvt.IC_PROJ_VALID_DATE_TAG_V1                           : gb_str_shape('IC Projection Valid Date'),  
        icmvt.IC_SHOW_ALL_YEARS_INTERV_COV_TAG_V1                 : gb_bool_shape('IC Show All Years Intervention Coverage'), 
        icmvt.IC_SHOW_ALL_FP_METHODS_INTERV_COV_TAG_V1            : gb_bool_shape('IC Show All Years FP Methods Intervention Coverage'), 
        icmvt.IC_SHOW_ALL_YEARS_INTERV_PIN_TAG_V1                 : gb_bool_shape('IC Show All Years Intervention PIN'), 
        icmvt.IC_ENTER_DET_PMTCT_DATA_TAG_V1                      : gb_bool_shape('IC Enter Detailed PMTCT Data'), 
        icmvt.IC_ENTER_NET_AGE_DIST_PERC_TAG_V1                   : gb_bool_shape('IC Enter Net Age Distribution as Percentages'), 
        icmvt.IC_POST_TREAT_SURV_FOLLOW_UP_VIS_TAG_V1             : gb_bool_shape('IC Post Treatment Survey Follow Up Visited'), 
        icmvt.IC_MAX_CUSTOM_DRUG_SUPP_MST_ID_TAG_V1               : gb_int_shape('IC Max Custom Drug Supply Master ID'), 
        icmvt.IC_COV_YEAR_BEF_BASE_YEAR_ITN_TAG_V1                : gb_float_shape('IC Coverage Year Before Base Year ITN'),
        icmvt.IC_NET_LIFETIME_ITN_TAG_V1                          : gb_float_shape('IC Net Lifetime ITN'),
        icmvt.IC_AVG_NET_AGE_ITN_TAG_V1                           : gb_float_shape('IC Average Net Age ITN'),
        icmvt.IC_INTERV_RECORDS_TAG                               : gb_shape('IC Intervention Records', '1D dict',
                                                                             dim=[ic_interv_dim],
                                                                             indices=[ic_interv_indices],
                                                                             innerShape= {
                                                                                 
                                                                                 'intervID':gb_str_shape('Intervention ID'), 
                                                                                 'name':gb_str_shape('Intervention Name'), 
                                                                                 'stringConstant':gb_str_shape('Intervention String Constant'), 
                                                                                 'active':gb_bool_shape('Is active'), 
                                                                                 'custom':gb_bool_shape('Is custom intervention'), 
                                                                                 'impact':gb_bool_shape('Is impact intervention'), 
                                                                                 'progAreaID':gb_str_shape('Program Area ID'), 
                                                                                 'subgroupID':gb_str_shape('Subgroup ID'),
                                                                                 'specialCases':gb_shape('Special Cases - contains tags for special use', '1D str'), 
                                                                                 'stratifying':gb_bool_shape('Is stratifying intervention'), 
                                                                                 'costForPHC':gb_bool_shape('Is cost for PHC'), 
                                                                                 'PIN_EditorVisited':gb_bool_shape('PIN Editor Visited'), 
                                                                                 'coverageChanged':gb_bool_shape('Coverage Changed'), 
                                                                                 'PIN_StringConstant':gb_str_shape('PIN String Constant'), 
                                                                                 'coverage':gb_year_shape('Coverage'), # This is a percentage, so it is a float.
                                                                                 'treatInputNotReq' : gb_shape('Treatment Input Not Required', '2D float', 
                                                                                                               dim=[ic_deliv_channel_dim, ic_treat_input_type_dim],
                                                                                                               indices=[ic_deliv_channel_indices, ic_treat_input_type_indices]),
                                                                                 'maxCustomTIGroupMstID': gb_shape('max custom TI group master id', '2D int', 
                                                                                                               dim=[ic_deliv_channel_dim, ic_treat_input_type_dim],
                                                                                                               indices=[ic_deliv_channel_indices, ic_treat_input_type_indices]),
                                                                                 'PIN':gb_year_shape('Population in need'), # This is a percentage, so it is a float.
                                                                                 'percDelivThroughChan':gb_shape('Percent delivery through channel', '2D float', 
                                                                                                               dim=[ic_deliv_channel_dim, 'ic_base_targ_dim'],
                                                                                                               indices=[ic_deliv_channel_indices, {}]),
                                                                                 'visitCostPerCase':gb_shape('Vist cost per case', '3D float', 
                                                                                                               dim=[ic_visit_type_dim, ic_deliv_channel_dim, gb_year_dim],
                                                                                                               indices=[ic_visit_type_indices, ic_deliv_channel_indices, gb_year_indices],
                                                                                                               contingent=True), # This is a percentage, so it is a float.
                                                                                 'targPopRec':gb_shape('Target Population Records', 'dict',
                                                                                                        innerShape={
                                                                                                                'targPopMstID': gb_str_shape('Target Population ID'),
                                                                                                                'sex': gb_int_shape('sex id'),
                                                                                                                'startAge':gb_int_shape('Start Age'),
                                                                                                                'endAge':gb_int_shape('End Age'),
                                                                                                                'directEntryValues':gb_year_shape('Direct Entry Values')
                                                                                                            })
                                                                                },
                                                                             has_default=False,
                                                                             contingent=True, # Contingent upon filling out this MV shape based on the file above in a maintainable way.
                                                                             ),
        icmvt.IC_TREAT_INPUT_DRUG_SUPPLY_RECORDS_TAG              : gb_shape('Drug and supply records', '1D dict',
                                                                             dim=[ic_drug_supply_dim],
                                                                             indices=[ic_drug_supply_indices],
                                                                             innerShape= {
                                                                                 'intervID':gb_str_shape('Intervention ID'), 
                                                                                 'delivChanID': gb_str_shape('Delivery Channel ID'), 
                                                                                 'treatInputGroupID':gb_str_shape('Treatment Input Group ID'), 
                                                                                 'treatInputID':gb_str_shape('Treatment Input ID'), 
                                                                                 'percApplied':gb_year_shape('Percentage Applied'), # This is a percentage, so it is a float.
                                                                                 'note':gb_str_shape('Note'), 
                                                                                 'stringConstant':gb_str_shape('String Constant'), 
                                                                                 'timesPerDay': gb_float_shape('Times per Day'), 
                                                                                 'daysPerCase': gb_float_shape('Days per Case'), 
                                                                                 'number': gb_float_shape('Number'),
                                                                             },
                                                                             has_default=False
                                                                    ),
        icmvt.IC_TREAT_INPUT_MED_PERSONNEL_RECORDS_TAG            : gb_shape('Med personnel records', '1D dict',
                                                                             dim=[ic_med_personnel_dim],
                                                                             indices=[ic_med_personnel_indices],
                                                                             innerShape= {
                                                                                 'intervID':gb_str_shape('Intervention ID'), 
                                                                                 'delivChanID': gb_str_shape('Delivery Channel ID'), 
                                                                                 'treatInputGroupID':gb_str_shape('Treatment Input Group ID'), 
                                                                                 'treatInputID':gb_int_shape('Treatment Input ID'),  # why int?
                                                                                 'percApplied':gb_year_shape('Percentage Applied'), # This is a percentage, so it is a float.
                                                                                 'note':gb_str_shape('Note'), 
                                                                                 'stringConstant':gb_str_shape('String Constant'), 
                                                                                 'customStaffType': gb_bool_shape('Custom Staff Type'),
                                                                                 'skilledStaffCost': gb_bool_shape('Skilled Staff Cost'),
                                                                                 'numOfDays': gb_float_shape('Number of days'), 
                                                                                 'minutes': gb_float_shape('Minutes'), 
                                                                             },
                                                                             has_default=False
                                                                    ),
        icmvt.IC_TREAT_INPUT_OUTPAT_INPAT_RECORDS_TAG             : gb_shape('Outpatient inpatient records', '1D dict',
                                                                             innerShape={
                                                                                 'intervID':gb_str_shape('Intervention ID'),
                                                                                 'delivChanID': gb_str_shape('Delivery Channel ID'),
                                                                                 'treatInputGroupID':gb_str_shape('Treatment Input Group ID'),
                                                                                 'treatInputID':gb_str_shape('Treatment Input ID'),
                                                                                 'percApplied':gb_year_shape('Percentage Applied'), # This is a percentage, so it is a float.
                                                                                 'note':gb_str_shape('Note'),
                                                                                 'stringConstant':gb_str_shape('String Constant'),
                                                                                 'unitsPerCase': gb_float_shape('Units per Case')
                                                                                 }
                                                                    ),
        icmvt.IC_TREAT_INPUT_GROUP_DRUG_SUPPLY_RECORDS_TAG        : gb_shape('IC Treatment Input Group Drug Supply Records', '1D dict',
                                                                             innerShape={
                                                                                 'intervID': gb_str_shape('Intervention ID'),
                                                                                    'delivChanID': gb_str_shape('Delivery Channel ID'),
                                                                                    'treatInputGroupID': gb_str_shape('Treatment Input Group ID'),
                                                                                    'name': gb_str_shape('Name'),
                                                                                    'stringConstant': gb_str_shape('String Constant'),
                                                                             }
                                                                    ),
        icmvt.IC_TREAT_INPUT_GROUP_MED_PERSONNEL_RECORDS_TAG      : gb_shape('IC Treatment Input Group Medical Personnel Records', '1D dict',
                                                                             innerShape={   
                                                                                    'intervID': gb_str_shape('Intervention ID'),
                                                                                    'delivChanID': gb_str_shape('Delivery Channel ID'),
                                                                                    'treatInputGroupID': gb_str_shape('Treatment Input Group ID'),
                                                                                    'name': gb_str_shape('Name'),
                                                                                    'stringConstant': gb_str_shape('String Constant')
                                                                             }
                                                                    ),
        icmvt.IC_TREAT_INPUT_GROUP_OUTPAT_INPAT_RECORDS_TAG       : gb_shape('IC Treatment Input Group Outpatient Inpatient Records', '1D dict',
                                                                                innerShape={
                                                                                    'intervID': gb_str_shape('Intervention ID'),
                                                                                    'delivChanID': gb_str_shape('Delivery Channel ID'), 
                                                                                    'treatInputGroupID': gb_str_shape('Treatment Input Group ID'),
                                                                                    'name': gb_str_shape('Name'),
                                                                                    'stringConstant': gb_str_shape('String Constant')
                                                                                }
                                                                    ),
        icmvt.IC_DRUG_SUPPLY_RECORDS_TAG                          : gb_shape('IC Drug Supply Records', '1D dict',
                                                                            dim=[ic_drug_supply_dim],
                                                                            indices=[ic_drug_supply_indices],
                                                                            innerShape={
                                                                                'drugSupplyID': gb_str_shape('Drug Supply ID'),
                                                                                'name': gb_str_shape('Name'),
                                                                                'stringConstant': gb_str_shape('String Constant'),
                                                                                'custom': gb_bool_shape('Is custom drug supply'),
                                                                                #'cost': gb_year_shape('Cost'),  
                                                                                'active': gb_bool_shape('Is active'),
                                                                                'costTypeMstID': gb_int_shape('Cost Type Master ID'),
                                                                                'unitCost': gb_year_shape('Unit Cost'),  
                                                                                'applicProgAreaIDs': gb_shape('Applicable Program Area ID', '1D str'),  
                                                                            }    
                                                                    ),                                     
        icmvt.IC_TARG_POP_RECORDS_TAG                             : gb_shape('IC Target Population Records', '1D dict',
                                                                            dim=[ic_targ_pop_dim],    
                                                                            indices=[ic_targ_pop_indices],
                                                                            innerShape={    
                                                                                'name': gb_str_shape('Target Population Name'),
                                                                                'stringConstant': gb_str_shape('Target Population String Constant'),
                                                                                'defTargPopMstID': gb_int_shape('Default Target Population Master ID'),
                                                                                'applicProgAreaIDs': gb_shape('Applicable Program Area ID', '1D str'),  
                                                                                'requiredModMstIDs' : gb_shape('Required modules', '1D str'),  
                                                                            }   
                                                                    ),
		icmvt.IC_ALT_PIN_AGE_GROUP_SET_1_LIST_TAG_V1              : gb_shape('IC Alternative PIN Age Group Set 1 List', '1D dict',
                                                                       innerShape={
                                                                           'intervID': gb_str_shape('Intervention ID'),
                                                                           'PIN' : gb_shape('PIN', '2D float',  
                                                                                      dim=[ic_group_set_1_dim, gb_year_dim],
                                                                                      indicies=[ic_group_set_1_indices, gb_year_indices]),
                                                                       }
                                                                    ),
        icmvt.IC_ALT_PIN_AGE_GROUP_SET_2_LIST_TAG_V1              : gb_shape('IC Alternative PIN Age Group Set 1 List', '1D dict',
                                                                       innerShape={
                                                                           'intervID': gb_str_shape('Intervention ID'),
                                                                           'PIN' : gb_shape('PIN', '2D float',  
                                                                                      dim=[ic_group_set_2_dim, gb_year_dim],
                                                                                      indicies=[ic_group_set_2_indices, gb_year_indices]),
                                                                       }
                                                                    ),
        icmvt.IC_VARY_TREATMENT_INPUTS_BY_TIME_TAG_V1             : gb_float_shape('IC Vary Treatment Inputs by Time'),
        icmvt.IC_DRUG_COST_PER_CASE_TAG_V1                        : gb_shape('IC Drug Cost per Case', '1D dict',
                                                                            dim=[ic_drug_supply_dim],
                                                                            indices=[ic_drug_supply_indices],
                                                                            innerShape={
                                                                                'intervID': gb_str_shape('Intervention ID'),
                                                                                'delivChanID': gb_str_shape('Delivery Channel ID'),
                                                                                'value': gb_year_shape('Value')  # This is a percentage, so it is a float.
                                                                            },
                                                                            has_default=False
                                                                        ),
                                                                             
        icmvt.IC_SUPPLY_COST_PER_CASE_TAG_V1                      : gb_shape('IC Supply Cost per Case', '1D dict',
                                                                            dim=[ic_drug_supply_dim],
                                                                            indices=[ic_drug_supply_indices],
                                                                            innerShape={
                                                                                'intervID': gb_str_shape('Intervention ID'),
                                                                                'delivChanID': gb_str_shape('Delivery Channel ID'),
                                                                                'value': gb_year_shape('Value')  # This is a percentage, so it is a float.
                                                                            },
                                                                            has_default=False
                                                                        ),
        icmvt.IC_MIN_PER_AVG_CASE_STATIC_STAFF_TAG_V1             :  gb_shape('IC Min per average case static staff', '1D dict',
                                                                            innerShape={
                                                                                'intervID': gb_str_shape('Intervention ID'),
                                                                                'delivChanID': gb_str_shape('Delivery Channel ID'),
                                                                                'defaultStaffTypeMstID': gb_int_shape('Default Staff Master ID'),
                                                                                'value': gb_year_shape('Value')  # This is a percentage, so it is a float.
                                                                            },
                                                                            has_default=False
                                                                        ),
        # icmvt.IC_MIN_PER_AVG_CASE_DYNAMIC_STAFF_TAG_V1            : value_list,
        icmvt.IC_FAM_PLAN_GOAL_TAG_V1                             : gb_int_shape('IC Family Planning Goal'),
        icmvt.IC_PERC_UNMET_NEED_COVERED_TAG_V1                   : gb_year_shape('Percentage Unmet Need Covered'), # This is a percentage, so it is a float.

        # Outputs / results

        icmvt.IC_RES_NUM_SERVICES_BY_DELIV_CHAN_TAG_V1           : gb_shape('IC Number of Services by Delivery Channel', '3D float',
                                                                            dim=[ic_interv_dim, ic_deliv_channel_dim, gb_year_dim],
                                                                            indices=[ic_interv_indices, ic_deliv_channel_indices, gb_year_indices]),
        icmvt.IC_RES_TARG_POPS_TAG_V1                            : gb_shape('IC Target Populations', '2D float', dims=[ic_interv_dim, gb_year_dim], indices=[ic_interv_indices, gb_year_indices]),
        icmvt.IC_RES_PEOPLE_NEEDING_SERVICES_TAG_V1              : gb_shape('IC Target Populations', '2D float', dims=[ic_interv_dim, gb_year_dim], indices=[ic_interv_indices, gb_year_indices]),
        icmvt.IC_RES_NUM_SERVICES_TAG_V1                         : gb_shape('IC Target Populations', '2D float', dims=[ic_interv_dim, gb_year_dim], indices=[ic_interv_indices, gb_year_indices]),
        icmvt.IC_RES_PERC_DELIV_THROUGH_CHAN_BY_YEAR_TAG_V1      : gb_shape('IC Number of Services by Delivery Channel', '3D float',
                                                                            dim=[ic_interv_dim, ic_deliv_channel_dim, gb_year_dim],
                                                                            indices=[ic_interv_indices, ic_deliv_channel_indices, gb_year_indices]),
        icmvt.IC_RES_DRUG_COSTS_TAG_V1                           : gb_shape('IC Labor Costs DSC', '3D float',
                                                                          dim=[ic_interv_dim, ic_costed_deliv_chan_dim, gb_year_dim],
                                                                          indices=[ic_interv_indices, ic_costed_deliv_chan_ids, gb_year_indices]),
        icmvt.IC_RES_DRUG_COSTS_BY_YEAR_ONLY_TAG_V1              : gb_year_shape('IC Drug Costs by Year Only'),
        icmvt.IC_RES_SUPPLY_COSTS_TAG_V1                         : gb_shape('IC Labor Costs DSC', '3D float',
                                                                          dim=[ic_interv_dim, ic_costed_deliv_chan_dim, gb_year_dim],
                                                                          indices=[ic_interv_indices, ic_costed_deliv_chan_ids, gb_year_indices]),
        icmvt.IC_RES_SUPPLY_COSTS_BY_YEAR_ONLY_TAG_V1            : gb_year_shape('IC Supply Costs by Year Only'),
        icmvt.IC_RES_STATIC_STAFF_TIME_REQ_BY_DELIV_CHAN_TAG_V1  : gb_shape('IC Static Staff Time Required by Delivery Channel', '3D float',
                                                                          dim=[ic_staff_dim, ic_costed_deliv_chan_dim, gb_year_dim],
                                                                            indices=[ic_staff_indices, ic_costed_deliv_chan_ids, gb_year_indices]),
        icmvt.IC_RES_STATIC_STAFF_TIME_REQ_BY_INTERV_TAG_V1      : gb_shape('IC Static Staff Time Required by Intervention', '2D float',
                                                                          dim=[ic_staff_dim, ic_interv_dim, gb_year_dim],
                                                                            indices=[ic_staff_indices, ic_interv_indices, gb_year_indices]),
        icmvt.IC_RES_STATIC_STAFF_TIME_REQ_BY_PROG_AREA_TAG_V1   : gb_shape('IC Static Staff Time Required by Program Area', '2D float',
                                                                          dim=[ic_staff_dim, ic_prog_area_dim, gb_year_dim],  
                                                                            indices=[ic_staff_indices, ic_prog_area_indices, gb_year_indices]),
        icmvt.IC_RES_DYNAMIC_STAFF_TIME_REQ_BY_DELIV_CHAN_TAG_V1 : gb_shape('IC Dynamic Staff Time Required by Delivery Channel', '3D float',
                                                                            dim=[ic_staff_dim, ic_costed_deliv_chan_dim, gb_year_dim],
                                                                            indices=[ic_staff_indices, ic_costed_deliv_chan_ids, gb_year_indices]),
        icmvt.IC_RES_DYNAMIC_STAFF_TIME_REQ_BY_INTERV_TAG_V1     : gb_shape('IC Dynamic Staff Time Required by Intervention', '3D float',
                                                                            dim=[ic_staff_dim, ic_interv_dim, gb_year_dim],
                                                                            indices=[ic_staff_indices, ic_interv_indices, gb_year_indices]),
        icmvt.IC_RES_DYNAMIC_STAFF_TIME_REQ_BY_PROG_AREA_TAG_V1  : gb_shape('IC Dynamic Staff Time Required by Program Area', '3D float',
                                                                            dim=[ic_staff_dim, ic_prog_area_dim, gb_year_dim],
                                                                            indices=[ic_staff_indices, ic_prog_area_indices, gb_year_indices]),
        
        
        # These two are too large and need to be converted to records.
        icmvt.IC_RES_DRUGS_REQUIRED_BY_DELIV_CHAN_TAG            : gb_shape('IC Drugs Required by Delivery Channel', '3D float',
                                                                            dim=[ic_drug_supply_dim, ic_costed_deliv_chan_dim, gb_year_dim],
                                                                            indices=[ic_drug_supply_indices, ic_costed_deliv_chan_ids, gb_year_indices]),
                                                                            
        icmvt.IC_RES_SUPPLIES_REQUIRED_BY_DELIV_CHAN_TAG         : gb_shape('IC Supplies Required by Delivery Channel', '3D float',
                                                                            dim=[ic_drug_supply_dim, ic_costed_deliv_chan_dim, gb_year_dim],
                                                                            indices=[ic_drug_supply_indices, ic_costed_deliv_chan_ids, gb_year_indices]),
       
        icmvt.IC_RES_DRUGS_REQUIRED_BY_PROG_AREA_TAG            : gb_shape('IC Drugs Required by Program Area', '3D float',
                                                                           dim=[ic_drug_supply_dim, ic_prog_area_dim, gb_year_dim],
                                                                           indices=[ic_drug_supply_indices, ic_prog_area_indices, gb_year_indices]),
                                                                            
        
        icmvt.IC_RES_SUPPLIES_REQUIRED_BY_PROG_AREA_TAG         : gb_shape('IC Supplies Required by Program Area', '3D float',
                                                                           dim=[ic_drug_supply_dim, ic_prog_area_dim, gb_year_dim],
                                                                           indices=[ic_drug_supply_indices, ic_prog_area_indices, gb_year_indices]),
        
       
        icmvt.IC_RES_OUTPAT_VISITS_INPAT_DAYS_TAG_V1             : gb_shape('IC Outpatient Visits Inpatient Days', '4D float',
                                                                            dim=[ic_interv_dim, ic_visit_type_dim, ic_costed_deliv_chan_dim, gb_year_dim],
                                                                            indices=[ic_interv_indices, ic_visit_type_indices, ic_costed_deliv_chan_ids, gb_year_indices]),
		
		# Comprehensive vs specific plan (CVS)
        icmvt.IC_OUTPAT_INPAT_COSTS_CVS_TAG_V1 : gb_shape('IC Outpatient Inpatient Costs CVS', '2D float',
                                                           dims=[ic_visit_type_dim, ic_costed_deliv_chan_dim],
                                                           indices=[ic_visit_type_indices, ic_costed_deliv_chan_ids]),
        icmvt.IC_RES_LABOR_COSTS_DSC_TAG_V1 : gb_shape('IC Labor Costs DSC', '3D float',
                                                        dim=[ic_interv_dim, ic_costed_deliv_chan_dim, gb_year_dim],
                                                        indices=[ic_interv_indices, ic_costed_deliv_chan_ids, gb_year_indices]),
                                                                          
}