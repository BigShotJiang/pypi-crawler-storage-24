from SpectrumCommon.Modvars.AM.AMModvarShapes import AM_modvar_shapes
from SpectrumCommon.Modvars.GB.GBDefs import gb_update_years
from SpectrumCommon.Const.AM import *

def AM_UpdateYears(projection, new_projection, params):

    projection[AM_InitialConditionsTag] = new_projection[AM_InitialConditionsTag]
    
    gb_update_years(projection, params, AM_modvar_shapes)
    pass