from SpectrumCommon.Modvars.GB.GBDefs import *
from SpectrumCommon.Const.AM import *
from SpectrumCommon.Modvars.DP.DPIndices import *

AM_modvar_shapes = {

    AM_InitialConditionsTag : 
        gb_shape(
            'AM_InitialConditionsTag', 
            type='dict', 
            innerShape={
                'hiv_infections' : 
                    gb_shape(
                        'hiv_infections description',
                        type='2D float',
                        dim=[gb_sex_dim, gb_single_age_dim],
                        indices=[{'male' : 0, 'female' : 1}, gb_single_age_indices]
                    ),
                'hiv_deaths' : 
                    gb_shape(
                        'hiv_deaths description',
                        type='2D float',
                        dim=[gb_sex_dim, gb_single_age_dim],
                        indices=[{'male' : 0, 'female' : 1}, gb_single_age_indices]
                    ),
            }, 
            has_default=True,
            has_initial_conditions=True
        ),
    
    AM_DataSourceTag : gb_shape('AM_DataSourceTag', type='str', has_default=True, has_easy_aim=True),

    AM_AMSourcesTag : gb_shape('AM_AMSourcesTag', type='1D str', has_default=False),

    # Not in AMModvars AM_RetroYearsCalibrationTag

    AM_ChangesLogTag : gb_shape('AM_ChangesLogTag', type='1D str', has_default=False),
    
    AM_CD4ThreshHoldTag : 
        gb_shape('AM_CD4ThreshHoldTag', type='3D float', 
            dim=[dp_elig_treat_children_dim, dp_percent_or_number_dim, gb_year_dim], 
            indices=[dp_elig_treat_children_indices, dp_percent_or_number_indices, gb_year_indices], 
            has_default=False
        ),

    AM_PopsEligTreatTag : 
        gb_shape('AM_PopsEligTreatTag', type='1D dict', 
            dim=[dp_pop_elig_treat_regardless_CD4_count_dim], 
            indices=[dp_pop_elig_treat_regardless_CD4_count_indices],
            innerShape=gb_shape('', 'dict', innerShape={
                'Eligible'   : gb_shape('', type='bool'),
                'PercentHIV' : gb_shape('', type='float'),
                'Year'       : gb_shape('', type='int'),
            }),   
            has_default=True,
        ), 

    AM_AgeHIVChildOnTreatmentTag : gb_shape('AM_AgeHIVChildOnTreatmentTag', type='1D int', dim=[gb_year_dim], indices=[gb_year_indices], has_default=False),

    AM_CD4ThreshHoldAdultsTag : gb_shape('AM_CD4ThreshHoldAdultsTag', type='1D int', dim=[gb_year_dim], indices=[gb_year_indices], has_default=False),

    AM_InfantFeedingOptionsTag : gb_shape('AM_InfantFeedingOptionsTag', type='3D float', 
        dim=[dp_infant_feed_months_dim, dp_PMTCT_dim, gb_year_dim],
        indices=[dp_infant_feed_months_indices, dp_PMTCT_indices, gb_year_indices],
        has_default=True, has_easy_aim=True, has_global=True),

    AM_InfantFeedingOptions_MetaTag : 
        gb_shape('AM_InfantFeedingOptions_MetaTag', type='dict', 
            innerShape={
                'surveyData':
                    gb_shape(
                        'surveyData description',
                        type='3D float',
                        dim=[dp_infant_feed_months_dim, dp_PMTCT_dim, gb_year_dim],
                        indices=[dp_infant_feed_months_indices, dp_PMTCT_indices, gb_year_indices]
                    ),
                'hasSurveyData':
                    gb_shape(
                        'default survey data available?',
                        type='bool',
                    ),
            },
            has_default=True, 
            has_country=True,
            has_global=True
        ),

    AM_ARVRegimenTag : gb_shape('ARV Regimen', 
                                '4D float', 
                                has_default=True, 
                                has_easy_aim=True,
                                dim=[dp_arv_regimen_period_dim, dp_arv_regimen_treatments_dim, dp_percent_or_number_dim, gb_year_dim],
                                indices=[dp_arv_regimen_period_indices, 
                                         dp_arv_regimen_treatments_indices, 
                                         dp_percent_or_number_indices, 
                                         gb_year_indices],
                                ),
    AM_ARVRegimen_MetaTag: 
        gb_shape('ARV Regimen default data', 
            'dict', 
            has_default=True, 
            has_easy_aim=True,
            
            innerShape = {
                'default': 
                gb_shape('ARV Regimen', 
                    '4D float', 
                    dim=[dp_arv_regimen_period_dim, dp_arv_regimen_treatments_dim, dp_percent_or_number_dim, gb_year_dim],
                    indices=[dp_arv_regimen_period_indices, 
                    dp_arv_regimen_treatments_indices, 
                    dp_percent_or_number_indices, 
                    gb_year_indices],
                )
            },
            note= "not editable"
        ),

    AM_PatientsReallocatedTag : gb_shape('AM_PatientsReallocatedTag', type='1D int', dim=[gb_year_dim], indices=[gb_year_indices], has_default=False),

    AM_PercentARTDeliveryTag : gb_shape('AM_PercentARTDeliveryTag', type='2D int', 
        dim=[dp_ART_delivery_dim, gb_year_dim], 
        indices=[dp_ART_delivery_indices, gb_year_indices],
        has_default=False),

    AM_PregTermAbortionPerNumTag : gb_shape('AM_PregTermAbortionPerNumTag', type='1D int', dim=[gb_year_dim], indices=[gb_year_indices], has_default=False),
    
    AM_PregTermAbortionTag : gb_shape('AM_PregTermAbortionTag', type='1D int', dim=[gb_year_dim], indices=[gb_year_indices], has_default=False),

    # Not in AMmodvars AM_NumNewARTPatsTag

    AM_MedCD4CountInitTag : gb_shape('AM_MedCD4CountInitTag', type='1D int', dim=[gb_year_dim], indices=[gb_year_indices], has_default=False),

    AM_PercInterruptedTag : gb_shape('AM_PercInterruptedTag', type='1D float', dim=[gb_year_dim], indices=[gb_year_indices], has_default=True, has_easy_aim=True),

    AM_NumberInitTreatmentReinitsTag : gb_shape('AM_NumberInitTreatmentReinitsTag', type='1D int', dim=[gb_year_dim], indices=[gb_year_indices], has_default=False),

    AM_NumNewlyInitARTTag : gb_shape('AM_NumNewlyInitARTTag', type='2D int', 
        dim=[gb_sex_dim, gb_year_dim], 
        indices=[gb_sex_indices, gb_year_indices],                 
        has_default=False),

    AM_PercInterruptedChildTag : gb_shape('AM_PercInterruptedChildTag', type='1D int', dim=[gb_year_dim], indices=[gb_year_indices], has_default=False),

    AM_NumberInitTreatmentReinitsChildTag : gb_shape('AM_NumberInitTreatmentReinitsChildTag', type='1D int', dim=[gb_year_dim], indices=[gb_year_indices], has_default=False),

    AM_NumNewlyInitARTChildTag : gb_shape('AM_NumNewlyInitARTChildTag', type='1D int', dim=[gb_year_dim], indices=[gb_year_indices], has_default=False),

    AM_HAARTBySexTag : gb_shape('AM_HAARTBySexTag', type='2D int', 
        dim=[gb_sex_dim, gb_year_dim], 
        indices=[gb_sex_indices, gb_year_indices],     
        has_default=True, has_easy_aim=True),

    AM_CD4CoverageTag : gb_shape('AM_CD4CoverageTag', type='3D float', 
        dim=[dp_ART_coverage_method_dim, dp_CD4_count_cat_dim, gb_year_dim], 
        indices=[dp_ART_coverage_method_indices, dp_CD4_count_cat_indices, gb_year_indices],     
        has_default=False),

    AM_ARTByAgeInputTypeTag : gb_shape('AM_ARTByAgeInputTypeTag', type='int', has_default=False),

    AM_ARTByAge5YearAGTag : gb_shape('AM_ARTByAge5YearAGTag', type='3D int', 
        dim=[gb_sex_dim, gb_5y_age_dim, gb_year_dim], 
        indices=[gb_sex_indices, gb_5y_age_indices, gb_year_indices],  
        has_default=False),

    AM_ARTByAgeGAMAGTag : gb_shape('AM_ARTByAgeGAMAGTag', type='3D float', 
        dim=[gb_sex_dim, dp_GAM_age_group_dim, gb_year_dim], 
        indices=[gb_sex_indices, dp_GAM_age_group_indices, gb_year_indices],  
        has_default=False),
    
    AM_CovPopsEligTreatTag : gb_shape('AM_CovPopsEligTreatTag', type='2D float', 
        dim=[dp_pop_elig_treat_regardless_CD4_count_dim, gb_year_dim], 
        indices=[dp_pop_elig_treat_regardless_CD4_count_indices, gb_year_indices],  
        has_default=False),

    AM_ChildTreatInputsTag : gb_shape('AM_ChildTreatInputsTag', type='2D float', 
        dim=[dp_per_child_HIV_dim, gb_year_dim], 
        indices=[dp_per_child_HIV_indices, gb_year_indices],  
        has_default=True, has_easy_aim=True),
        
    AM_ChildARTByAgeGroupPerNumTag : gb_shape('AM_ChildARTByAgeGroupPerNumTag', type='2D int', 
        dim=[dp_per_child_HIV_dim, gb_year_dim], 
        indices=[dp_per_child_HIV_indices, gb_year_indices],                                  
        has_default=True, has_easy_aim=True),

    AM_ANCTestingValuesTag : gb_shape('AM_ANCTestingValuesTag', type='2D int',
        dim=[dp_ANC_testing_dim, gb_year_dim], 
        indices=[dp_ANC_testing_indices, gb_year_indices],
        has_default=False),
    
    AM_NewInfectionsLessImmigrantsTag : gb_sex_single_age_year_shape('AM_NewInfectionsLessImmigrantsTag', has_default=False),

    AM_HIVTestingTag : gb_shape('AM_HIVTestingTag', type='1D dict',
        dim=[gb_year_dim],  
        indices=[gb_year_indices],
        innerShape={
            'DiagTests' : gb_shape('', type='int'),
            'PosTests' : gb_shape('', type='int'),
            'HTSTests' : gb_shape('', type='int'),
            'PosHTSTests' : gb_shape('', type='int'),
            'ANCTests' : gb_shape('', type='int'),
            'PosANCTests' : gb_shape('', type='int'),
            'SelfTests' : gb_shape('', type='int'),
            'AssistedSelfTests' : gb_shape('', type='int'),
            'UnassistedSelfTests' : gb_shape('', type='int'),
            'AssistedPosReactiveSelfTests' : gb_shape('', type='int'),
            'PrimarySelfTests' : gb_shape('', type='int'),
            'SecondarySelfTests' : gb_shape('', type='int'),
            'PosHTSTestsWPrevReactiveSelfTest' : gb_shape('', type='int'),
            'IndexPartnerTests' : gb_shape('', type='int'),
            'PosIndexPartnerTests' : gb_shape('', type='int'),
        },
        has_default=False),
    
    AM_HIVTestingHTSTestsByAgeTag : gb_shape('AM_HIVTestingHTSTestsByAgeTag', type='3D int',
        dim=[gb_sex_dim, dp_GAM_age_group_dim, gb_year_dim], 
        indices=[gb_sex_indices, dp_GAM_age_group_indices, gb_year_indices], 
        has_default=False),

    AM_Shiny90SurveyDataTag : gb_shape('AM_Shiny90SurveyDataTag', type='1D dict', 
        dim=['Shiny90Surveys'],
        # indices={},
        innerShape={
            'isUsed' : gb_shape('', type='bool'),       
            'surveyID' : gb_shape('', type='str'),     
            'year' : gb_shape('', type='int'),         
            'ageGroup' : gb_shape('', type='int'),     
            'sex' : gb_shape('', type='int'),          
            'HIVStatus' : gb_shape('', type='int'),    
            'estimate' : gb_shape('', type='float'),     
            'standardError' : gb_shape('', type='float'),
            'lowerBound' : gb_shape('', type='float'),   
            'upperBound' : gb_shape('', type='float'),   
            'count' : gb_shape('', type='int'),    
        },
        has_default=False),

    AM_Shiny90SurveyData_MetaTag : gb_shape('AM_Shiny90SurveyData_MetaTag', type='dict', 
        innerShape = {
            'default': 
            gb_shape('Survey Data', 
                'dict',
                innerShape={
                    'isUsed' : gb_shape('', type='bool'),       
                    'surveyID' : gb_shape('', type='str'),     
                    'year' : gb_shape('', type='int'),         
                    'ageGroup' : gb_shape('', type='int'),     
                    'sex' : gb_shape('', type='int'),          
                    'HIVStatus' : gb_shape('', type='int'),    
                    'estimate' : gb_shape('', type='float'),     
                    'standardError' : gb_shape('', type='float'),
                    'lowerBound' : gb_shape('', type='float'),   
                    'upperBound' : gb_shape('', type='float'),   
                    'count' : gb_shape('', type='int'),        
                },
            )
        },
        has_default=False),

    AM_Shiny90ProgramDataTag : gb_shape('AM_Shiny90ProgramDataTag', type='1D dict', 
        dim=['Shiny90ProgramData'],
        # indices={},
        innerShape={
            'isUsed' : gb_shape('', type='bool'),       
            'year' : gb_shape('', type='int'),                 
            'sex' : gb_shape('', type='int'),                  
            'totalTests' : gb_shape('', type='int'),           
            'totalPosTests' : gb_shape('', type='int'),        
            'totalHTCTests' : gb_shape('', type='int'),        
            'totalPosHTCTests' : gb_shape('', type='int'),     
            'totalANCTests' : gb_shape('', type='int'),        
            'totalPosANCTests' : gb_shape('', type='int'),      
        },
        has_default=False),

    AM_Shiny90ProgramData_MetaTag : gb_shape('AM_Shiny90ProgramData_MetaTag', type='dict',
        innerShape = {
            'default': 
            gb_shape('Survey Data', 
                'dict',
                innerShape={
                    'isUsed' : gb_shape('', type='bool'),       
                    'year' : gb_shape('', type='int'),                 
                    'sex' : gb_shape('', type='int'),                  
                    'totalTests' : gb_shape('', type='int'),           
                    'totalPosTests' : gb_shape('', type='int'),        
                    'totalHTCTests' : gb_shape('', type='int'),        
                    'totalPosHTCTests' : gb_shape('', type='int'),     
                    'totalANCTests' : gb_shape('', type='int'),        
                    'totalPosANCTests' : gb_shape('', type='int'),        
                },
            )
        }, has_default=False),

    AM_Shiny90AIDSDeathsFYearTag : gb_shape('AM_Shiny90AIDSDeathsFYearTag', type='int', has_default=False),

    AM_Shiny90PopTag : gb_shape('AM_Shiny90PopTag', type='5D float',
        dim=[dp_HIV_status_dim, gb_sex_dim, dp_shiny90_age_group_dim, dp_num_type_dim, gb_year_dim], 
        indices=[dp_HIV_status_indices, gb_sex_indices, dp_shiny90_age_group_indices, dp_num_type_indices, gb_year_indices], 
        has_default=False),
    AM_Shiny90NumTestsTag : gb_shape('AM_Shiny90NumTestsTag', type='5D float',
        dim=[dp_HIV_status_dim, gb_sex_dim, dp_shiny90_age_group_dim, dp_num_type_dim, gb_year_dim], 
        indices=[dp_HIV_status_indices, gb_sex_indices, dp_shiny90_age_group_indices, dp_num_type_indices, gb_year_indices], 
        has_default=False),
    AM_Shiny90NumTested12MTag : gb_shape('AM_Shiny90NumTested12MTag', type='5D float',
        dim=[dp_HIV_status_dim, gb_sex_dim, dp_shiny90_age_group_dim, dp_num_type_dim, gb_year_dim], 
        indices=[dp_HIV_status_indices, gb_sex_indices, dp_shiny90_age_group_indices, dp_num_type_indices, gb_year_indices], 
        has_default=False),
    AM_Shiny90TotalTestsTag : gb_shape('AM_Shiny90TotalTestsTag', type='5D float',
        dim=[dp_HIV_status_dim, gb_sex_dim, dp_shiny90_age_group_dim, dp_num_type_dim, gb_year_dim], 
        indices=[dp_HIV_status_indices, gb_sex_indices, dp_shiny90_age_group_indices, dp_num_type_indices, gb_year_indices], 
        has_default=False),
    AM_Shiny90EverTestedTag : gb_shape('AM_Shiny90EverTestedTag', type='5D float',
        dim=[dp_HIV_status_dim, gb_sex_dim, dp_shiny90_age_group_dim, dp_num_type_dim, gb_year_dim], 
        indices=[dp_HIV_status_indices, gb_sex_indices, dp_shiny90_age_group_indices, dp_num_type_indices, gb_year_indices], 
        has_default=False),
    AM_Shiny90DiagnosedTag : gb_shape('AM_Shiny90DiagnosedTag', type='5D float',
        dim=[dp_HIV_status_dim, gb_sex_dim, dp_shiny90_age_group_dim, dp_num_type_dim, gb_year_dim], 
        indices=[dp_HIV_status_indices, gb_sex_indices, dp_shiny90_age_group_indices, dp_num_type_indices, gb_year_indices], 
        has_default=False),
    AM_Shiny90NumAwareTag : gb_shape('AM_Shiny90NumAwareTag', type='5D float',
        dim=[dp_HIV_status_dim, gb_sex_dim, dp_shiny90_age_group_dim, dp_num_type_dim, gb_year_dim], 
        indices=[dp_HIV_status_indices, gb_sex_indices, dp_shiny90_age_group_indices, dp_num_type_indices, gb_year_indices], 
        has_default=False),
    AM_Shiny90NumDiagnosesTag : gb_shape('AM_Shiny90NumDiagnosesTag', type='5D float',
        dim=[dp_HIV_status_dim, gb_sex_dim, dp_shiny90_age_group_dim, dp_num_type_dim, gb_year_dim], 
        indices=[dp_HIV_status_indices, gb_sex_indices, dp_shiny90_age_group_indices, dp_num_type_indices, gb_year_indices], 
        has_default=False),
    AM_Shiny90NumDiagnosesModTag : gb_shape('AM_Shiny90NumDiagnosesModTag', type='5D float',
        dim=[dp_HIV_status_dim, gb_sex_dim, dp_shiny90_age_group_dim, dp_num_type_dim, gb_year_dim], 
        indices=[dp_HIV_status_indices, gb_sex_indices, dp_shiny90_age_group_indices, dp_num_type_indices, gb_year_indices], 
        has_default=False),
    AM_Shiny90NumLateDiagnosesTag : gb_shape('AM_Shiny90NumLateDiagnosesTag', type='5D float',
        dim=[dp_HIV_status_dim, gb_sex_dim, dp_shiny90_age_group_dim, dp_num_type_dim, gb_year_dim], 
        indices=[dp_HIV_status_indices, gb_sex_indices, dp_shiny90_age_group_indices, dp_num_type_indices, gb_year_indices], 
        has_default=False),
    AM_Shiny90NotDiagHIV1YrTag : gb_shape('AM_Shiny90NotDiagHIV1YrTag', type='5D float',
        dim=[dp_HIV_status_dim, gb_sex_dim, dp_shiny90_age_group_dim, dp_num_type_dim, gb_year_dim], 
        indices=[dp_HIV_status_indices, gb_sex_indices, dp_shiny90_age_group_indices, dp_num_type_indices, gb_year_indices], 
        has_default=False),
    # mark next 7 new
    AM_Shiny90NumFirstTestHIVNeg_Tag : gb_shape('AM_Shiny90NumFirstTestHIVNeg_V1', type='5D float',
        dim=[dp_HIV_status_dim, gb_sex_dim, dp_shiny90_age_group_dim, dp_num_type_dim, gb_year_dim], 
        indices=[dp_HIV_status_indices, gb_sex_indices, dp_shiny90_age_group_indices, dp_num_type_indices, gb_year_indices], 
        has_default=False),
    AM_Shiny90NumReTestHIVNeg_Tag : gb_shape('AM_Shiny90NumReTestHIVNeg_V1', type='5D float',
        dim=[dp_HIV_status_dim, gb_sex_dim, dp_shiny90_age_group_dim, dp_num_type_dim, gb_year_dim], 
        indices=[dp_HIV_status_indices, gb_sex_indices, dp_shiny90_age_group_indices, dp_num_type_indices, gb_year_indices], 
        has_default=False),
    AM_Shiny90NumRetestPLHIVOnART_Tag : gb_shape('AM_Shiny90NumRetestPLHIVOnART_V1', type='5D float',
        dim=[dp_HIV_status_dim, gb_sex_dim, dp_shiny90_age_group_dim, dp_num_type_dim, gb_year_dim], 
        indices=[dp_HIV_status_indices, gb_sex_indices, dp_shiny90_age_group_indices, dp_num_type_indices, gb_year_indices], 
        has_default=False),
    AM_Shiny90NumRetestPLHIVNoART_Tag : gb_shape('AM_Shiny90NumRetestPLHIVNoART_V1', type='5D float',
        dim=[dp_HIV_status_dim, gb_sex_dim, dp_shiny90_age_group_dim, dp_num_type_dim, gb_year_dim], 
        indices=[dp_HIV_status_indices, gb_sex_indices, dp_shiny90_age_group_indices, dp_num_type_indices, gb_year_indices], 
        has_default=False),
    AM_Shiny90NumNewDiagnoses_Tag : gb_shape('AM_Shiny90NumNewDiagnoses_V1', type='5D float',
        dim=[dp_HIV_status_dim, gb_sex_dim, dp_shiny90_age_group_dim, dp_num_type_dim, gb_year_dim], 
        indices=[dp_HIV_status_indices, gb_sex_indices, dp_shiny90_age_group_indices, dp_num_type_indices, gb_year_indices], 
        has_default=False),
    AM_Shiny90PosRate_Tag : gb_shape('AM_Shiny90PosRate_V1', type='5D float',
        dim=[dp_HIV_status_dim, gb_sex_dim, dp_shiny90_age_group_dim, dp_num_type_dim, gb_year_dim], 
        indices=[dp_HIV_status_indices, gb_sex_indices, dp_shiny90_age_group_indices, dp_num_type_indices, gb_year_indices], 
        has_default=False),
    AM_Shiny90YieldNewDiagn_Tag : gb_shape('AM_Shiny90YieldNewDiagn_V1', type='5D float',
        dim=[dp_HIV_status_dim, gb_sex_dim, dp_shiny90_age_group_dim, dp_num_type_dim, gb_year_dim], 
        indices=[dp_HIV_status_indices, gb_sex_indices, dp_shiny90_age_group_indices, dp_num_type_indices, gb_year_indices], 
        has_default=False),
    AM_Shiny90IsFittedTag : gb_shape('AM_Shiny90IsFittedTag', type='bool', has_default=False),
    
    AM_KnowledgeOfStatusInputTypeTag : gb_shape('AM_KnowledgeOfStatusInputTypeTag', type='int', has_default=False),
    AM_KnowledgeOfStatusInputTag : gb_shape('AM_KnowledgeOfStatusInputTag', type='2D float',
        dim=[dp_cascade_age_group_dim, gb_year_dim],
        indices=[dp_cascade_age_group_indices, gb_year_indices],
        has_default=False),

    AM_KOSNewDiagnosesChildren0t14Tag : gb_shape('AM_KOSNewDiagnosesChildren0t14_V1', type='1D int', dim=[gb_year_dim], indices=[gb_year_indices], has_default=False),
    AM_KOSNewDiagnosesAdults15PlusTag : gb_shape('AM_KOSNewDiagnosesAdults15Plus_V1', type='1D int', dim=[gb_year_dim], indices=[gb_year_indices], has_default=False),
    AM_KOSNewDiagnosesRecCD4TestTag : gb_shape('AM_KOSNewDiagnosesRecCD4Test_V1', type='1D int', dim=[gb_year_dim], indices=[gb_year_indices], has_default=False),
    AM_ViralSuppressionInputTypeTag : gb_shape('AM_ViralSuppressionInputTypeTag', type='int', has_default=False),
    AM_ViralSuppressionInputTag : gb_shape('AM_ViralSuppressionInputTag', type='3D int', 
        dim=[dp_cascade_age_group_dim, dp_viral_suppression_dim, gb_year_dim], 
        indices=[dp_cascade_age_group_indices, dp_viral_suppression_indices, gb_year_indices], 
        has_default=False),
    AM_ViralSuppressionThresholdTag : gb_shape('AM_ViralSuppressionThresholdTag', type='1D int', dim=[gb_year_dim], indices=[gb_year_indices], has_default=False),

    # mark added next 2
    AM_Meningitis_Tag : 
        gb_shape('AM_Meningitis_V1', type='dict', 
            innerShape={
                'prev'           : gb_shape('', 'int'), 
                'percUnknown'    : gb_shape('', 'float'), 
                'percKnownPos'   : gb_shape('', 'float'), 
                'percOnART'      : gb_shape('', 'float'), 
                'covFluconazole' : gb_shape('', 'int'),     
            },
            has_default=True,
            has_country=True
        ), 
    
    AM_AdvOptsMeningitis_Tag : 
        gb_shape('AM_AdvOptsMeningitis_V1', type='dict', 
            innerShape={
                'progInCare'           : gb_shape('', 'float'), 
                'progNotInCare'        : gb_shape('', 'float'), 
                'progWithFluconazole'  : gb_shape('', 'float'), 
                'mortRateCMInCare'     : gb_shape('', 'int'), 
                'mortRateCMNotInCare'  : gb_shape('', 'int'),     
            },
            has_default=True,
            has_country=True
        ),
    
    AM_ChildAnnRateProgressLowerCD4Tag : gb_shape('AM_ChildAnnRateProgressLowerCD4Tag', type='4D float', 
        dim=[dp_default_data_dim, gb_sex_dim, dp_pediatric_age_group_dim, dp_pediatric_CD4_categories_dim], 
        indices=[dp_default_data_indices, gb_sex_indices, dp_pediatric_age_group_indices, dp_pediatric_CD4_categories_noLT5_indices], 
        has_default=True, has_global=True),
    AM_ChildDistNewInfectionsCD4Tag : gb_shape('AM_ChildDistNewInfectionsCD4Tag', type='2D float', 
        dim=[dp_default_data_dim, dp_pediatric_CD4_categories_dim], 
        indices=[dp_default_data_indices, dp_pediatric_CD4_categories_indices], 
        has_default=False),
    AM_ChildMortByCD4NoARTTag : gb_shape('AM_ChildMortByCD4NoARTTag', type='4D float', 
        dim=[dp_default_data_dim, dp_pediatric_age_group_dim, dp_HIV_acquisition_dim, dp_pediatric_CD4_categories_dim], 
        indices=[dp_default_data_indices, dp_pediatric_age_group_indices, dp_HIV_acquisition_indices, dp_pediatric_CD4_categories_indices], 
        has_default=False),
    AM_ChildMortalityRatesTag : gb_shape('AM_ChildMortalityRatesTag', type='4D int', 
        dim=[dp_default_data_dim, dp_pediatric_age_group_dim, dp_mort_rate_dim, gb_year_dim], 
        indices=[dp_default_data_indices, dp_pediatric_age_group_indices, dp_mort_rate_indices, gb_year_indices], 
        has_default=True, has_global=True),
    AM_ChildMortalityRates_MetaTag : gb_shape('AM_ChildMortalityRates_MetaTag', type='dict', 
        innerShape = {
            'default': 
                gb_shape('ChildMortalityRates', 
                    '4D float', 
                    dim=[dp_regions_dim, dp_pediatric_age_group_dim, dp_mort_rate_dim, gb_year_dim],
                    indices=[dp_regions_indices, dp_pediatric_age_group_indices, dp_mort_rate_indices, gb_year_indices],
                )
        },
        has_default=True,
        has_global=True),
    AM_ChildMortalityRatesMultiplierTag : gb_shape('AM_ChildMortalityRatesMultiplierTag', type='int', has_default=False),
    AM_ChildMortByCD4WithART0to6Tag : gb_shape('AM_ChildMortByCD4WithART0to6Tag', type='4D float', 
        dim=[dp_default_data_dim, gb_sex_dim, dp_pediatric_mort_no_ART_GT5_age_group_dim, dp_pediatric_CD4_categories_dim], 
        indices=[dp_default_data_indices, gb_sex_indices, dp_pediatric_mort_no_ART_GT5_age_group_indices, dp_pediatric_CD4_categories_indices], 
        has_default=False),
    AM_ChildMortByCD4WithART0to6_MetaTag : gb_shape('AM_ChildMortByCD4WithART0to6_MetaTag', type='dict', 
        innerShape = {
            'default': 
                gb_shape('ChildMortByCD4WithART0to6', 
                    '4D float', 
                    dim=[dp_regions_dim, gb_sex_dim, dp_pediatric_mort_no_ART_GT5_age_group_dim, dp_pediatric_CD4_categories_dim],
                    indices=[dp_regions_indices, gb_sex_indices, dp_pediatric_mort_no_ART_GT5_age_group_indices, dp_pediatric_CD4_categories_indices],
                )
        },
        has_default=False),
    AM_ChildMortByCD4WithART0to6PercTag : gb_shape('AM_ChildMortByCD4WithART0to6PercTag', type='4D float', 
        dim=[dp_default_data_dim, gb_sex_dim, dp_pediatric_mort_no_ART_LT5_age_group_dim, dp_pediatric_CD4_categories_dim], 
        indices=[dp_default_data_indices, gb_sex_indices, dp_pediatric_mort_no_ART_LT5_age_group_indices, dp_pediatric_CD4_categories_indices], 
        has_default=False),
    AM_ChildMortByCD4WithART0to6Perc_MetaTag : gb_shape('AM_ChildMortByCD4WithART0to6Perc_MetaTag', type='dict', 
        innerShape = {
            'default': 
            gb_shape('ChildMortByCD4WithART0to6Perc', 
                '4D float', 
                dim=[dp_regions_dim, gb_sex_dim, dp_pediatric_mort_no_ART_LT5_age_group_dim, dp_pediatric_CD4_categories_dim],
                indices=[dp_regions_indices, gb_sex_indices, dp_pediatric_mort_no_ART_LT5_age_group_indices, dp_pediatric_CD4_categories_indices],
            )
        },
        has_default=False),
    AM_ChildMortByCD4WithART7to12Tag : gb_shape('AM_ChildMortByCD4WithART7to12Tag', type='4D float', 
        dim=[dp_default_data_dim, gb_sex_dim, dp_pediatric_mort_no_ART_GT5_age_group_dim, dp_pediatric_CD4_categories_dim], 
        indices=[dp_default_data_indices, gb_sex_indices, dp_pediatric_mort_no_ART_GT5_age_group_indices, dp_pediatric_CD4_categories_indices], 
        has_default=False),
    AM_ChildMortByCD4WithART7to12_MetaTag : gb_shape('AM_ChildMortByCD4WithART7to12_MetaTag', type='dict',  
        innerShape = {
            'default': 
            gb_shape('ChildMortByCD4WithART7to12', 
                '4D float', 
                dim=[dp_regions_dim, gb_sex_dim, dp_pediatric_mort_no_ART_GT5_age_group_dim, dp_pediatric_CD4_categories_dim],
                indices=[dp_regions_indices, gb_sex_indices, dp_pediatric_mort_no_ART_GT5_age_group_indices, dp_pediatric_CD4_categories_indices],
            )
        },
        has_default=False),
    AM_ChildMortByCD4WithART7to12PercTag : gb_shape('AM_ChildMortByCD4WithART7to12PercTag', type='4D float',  
        dim=[dp_default_data_dim, gb_sex_dim, dp_pediatric_mort_no_ART_LT5_age_group_dim, dp_pediatric_CD4_categories_dim], 
        indices=[dp_default_data_indices, gb_sex_indices, dp_pediatric_mort_no_ART_LT5_age_group_indices, dp_pediatric_CD4_categories_indices], 
        has_default=False),
    AM_ChildMortByCD4WithART7to12Perc_MetaTag : gb_shape('AM_ChildMortByCD4WithART7to12Perc_MetaTag', type='dict',  
        innerShape = {
            'default': 
            gb_shape('ChildMortByCD4WithART7to12Perc', 
                '4D float', 
                dim=[dp_regions_dim, gb_sex_dim, dp_pediatric_mort_no_ART_LT5_age_group_dim, dp_pediatric_CD4_categories_dim],
                indices=[dp_regions_indices, gb_sex_indices, dp_pediatric_mort_no_ART_LT5_age_group_indices, dp_pediatric_CD4_categories_indices],
            )
        },
        has_default=False),
    AM_ChildMortByCD4WithARTGT12Tag : gb_shape('AM_ChildMortByCD4WithARTGT12Tag', type='4D float', 
        dim=[dp_default_data_dim, gb_sex_dim, dp_pediatric_mort_no_ART_GT5_age_group_dim, dp_pediatric_CD4_categories_dim], 
        indices=[dp_default_data_indices, gb_sex_indices, dp_pediatric_mort_no_ART_GT5_age_group_indices, dp_pediatric_CD4_categories_indices], 
        has_default=False),
    AM_ChildMortByCD4WithARTGT12_MetaTag : gb_shape('AM_ChildMortByCD4WithARTGT12_MetaTag', type='dict',  
        innerShape = {
            'default': 
            gb_shape('ChildMortByCD4WithARTGT12', 
                '4D float', 
                dim=[dp_regions_dim, gb_sex_dim, dp_pediatric_mort_no_ART_GT5_age_group_dim, dp_pediatric_CD4_categories_dim],
                indices=[dp_regions_indices, gb_sex_indices, dp_pediatric_mort_no_ART_GT5_age_group_indices, dp_pediatric_CD4_categories_indices],
            )
        },
        has_default=False),
    AM_ChildMortByCD4WithARTGT12PercTag : gb_shape('AM_ChildMortByCD4WithARTGT12PercTag', type='4D float',  
        dim=[dp_default_data_dim, gb_sex_dim, dp_pediatric_mort_no_ART_LT5_age_group_dim, dp_pediatric_CD4_categories_dim], 
        indices=[dp_default_data_indices, gb_sex_indices, dp_pediatric_mort_no_ART_LT5_age_group_indices, dp_pediatric_CD4_categories_indices], 
        has_default=False),
    AM_ChildMortByCD4WithARTGT12Perc_MetaTag : gb_shape('AM_ChildMortByCD4WithARTGT12Perc_MetaTag', type='dict',  
        innerShape = {
            'default': 
            gb_shape('ChildMortByCD4WithARTGT12Perc', 
                '4D float', 
                dim=[dp_regions_dim, gb_sex_dim, dp_pediatric_mort_no_ART_LT5_age_group_dim, dp_pediatric_CD4_categories_dim],
                indices=[dp_regions_indices, gb_sex_indices, dp_pediatric_mort_no_ART_LT5_age_group_indices, dp_pediatric_CD4_categories_indices],
            )
        },
        has_default=False),
    AM_ChildARTDistTag : gb_shape('AM_ChildARTDistTag', type='3D float',   
        dim=[dp_default_data_dim, gb_single_age_child_dim, gb_year_dim], 
        indices=[dp_default_data_indices, gb_single_age_child_indices, gb_year_indices], 
        has_default=False),
    AM_ChildARTDist_MetaTag : gb_shape('AM_ChildARTDist_MetaTag', type='dict',   
        innerShape = {
            'default': 
            gb_shape('ChildARTDist', 
                '3D float', 
                dim=[dp_regions_dim, gb_single_age_child_dim, gb_year_dim],
                indices=[dp_regions_indices, gb_single_age_child_indices, gb_year_indices],
            )
        },
        has_default=False),
    AM_EffectTreatChildTag : gb_shape('AM_EffectTreatChildTag', type='3D float',   
        dim=[dp_default_data_dim, dp_child_treat_effectiveness_dim, dp_child_treat_years_dim], 
        indices=[dp_default_data_indices, dp_child_treat_effectiveness_indices, dp_child_treat_years_indices], 
        has_default=False),
    AM_ChildWeightBandsTag : gb_shape('AM_ChildWeightBandsTag', type='4D float',  
        dim=[dp_default_data_dim, gb_sex_dim, gb_single_age_child_dim, dp_child_weight_bands_kg_dim], 
        indices=[dp_default_data_indices, gb_sex_indices, gb_single_age_child_indices, dp_child_weight_bands_kg_indices], 
        has_default=False),
    AM_AdultAnnRateProgressLowerCD4Tag : gb_shape('AM_AdultAnnRateProgressLowerCD4Tag', type='4D float', 
        dim=[dp_default_data_dim, gb_sex_dim, dp_10y_age_dim, dp_CD4_count_cat_dim], 
        indices=[dp_default_data_indices, gb_sex_indices, dp_10y_age_indices, dp_CD4_count_cat_noLT50_indices], 
        has_default=False),
    AM_AdultAnnRateProgressLowerCD4_MetaTag : gb_shape('AM_AdultAnnRateProgressLowerCD4_MetaTag', type='dict',   
        innerShape = {
            'default': 
            gb_shape('AdultAnnRateProgressLowerCD4', 
                '4D float', 
                dim=[dp_regions_dim, gb_sex_dim, dp_10y_age_dim, dp_CD4_count_cat_dim],
                indices=[dp_regions_indices, gb_sex_indices, dp_10y_age_indices, dp_CD4_count_cat_noLT50_indices],
            )
        },
        has_default=False),
    AM_AdultDistNewInfectionsCD4Tag : gb_shape('AM_AdultDistNewInfectionsCD4Tag', type='4D float',  
        dim=[dp_default_data_dim, gb_sex_dim, dp_10y_age_dim, dp_CD4_count_cat_dim], 
        indices=[dp_default_data_indices, gb_sex_indices, dp_10y_age_indices, dp_CD4_count_cat_indices], 
        has_default=False),
    AM_AdultDistNewInfectionsCD4_MetaTag : gb_shape('AM_AdultDistNewInfectionsCD4_MetaTag', type='dict',    
        innerShape = {
            'default': 
            gb_shape('AdultDistNewInfectionsCD4', 
                '4D float', 
                dim=[dp_regions_dim, gb_sex_dim, dp_10y_age_dim, dp_CD4_count_cat_dim],
                indices=[dp_regions_indices, gb_sex_indices, dp_10y_age_indices, dp_CD4_count_cat_indices],
            )
        },
        has_default=False),
    AM_AdultMortByCD4NoARTTag : gb_shape('AM_AdultMortByCD4NoARTTag', type='4D float', 
        dim=[dp_default_data_dim, gb_sex_dim, dp_10y_age_dim, dp_CD4_count_cat_dim], 
        indices=[dp_default_data_indices, gb_sex_indices, dp_10y_age_indices, dp_CD4_count_cat_indices], 
        has_default=False),
    AM_AdultMortByCD4NoART_MetaTag : gb_shape('AM_AdultMortByCD4NoART_MetaTag', type='dict', 
        innerShape = {
            'default': 
            gb_shape('AdultMortByCD4NoART', 
                '4D float', 
                dim=[dp_regions_dim, gb_sex_dim, dp_10y_age_dim, dp_CD4_count_cat_dim],
                indices=[dp_regions_indices, gb_sex_indices, dp_10y_age_indices, dp_CD4_count_cat_indices],
            )
        },
        has_default=False),
    AM_AdultInfectReducTag : gb_shape('AM_AdultInfectReducTag', type='1D float',  
        dim=[dp_default_data_dim], indices=[dp_default_data_indices], has_default=False),
    AM_MortalityRatesTag : gb_shape('AM_MortalityRatesTag', type='3D float', 
        dim=[dp_default_data_dim, dp_mort_rate_dim, gb_year_dim], 
        indices=[dp_default_data_indices, dp_mort_rate_indices, gb_year_indices], 
        has_default=False),
    AM_MortalityRates_MetaTag : gb_shape('AM_MortalityRates_MetaTag', type='dict', 
        innerShape = {
            'default': 
            gb_shape('MortalityRates', 
                '3D float', 
                dim=[dp_regions_dim, dp_mort_rate_dim, gb_year_dim],
                indices=[dp_regions_indices, dp_mort_rate_indices, gb_year_indices],
            )
        },
        has_default=False),
    AM_MortalityRatesMultiplierTag : gb_shape('AM_MortalityRatesMultiplierTag', type='int', has_default=False),
    AM_AdultMortByCD4WithART0to6Tag : gb_shape('AM_AdultMortByCD4WithART0to6Tag', type='4D float', 
        dim=[dp_default_data_dim, gb_sex_dim, dp_10y_age_dim, dp_CD4_count_cat_dim], 
        indices=[dp_default_data_indices, gb_sex_indices, dp_10y_age_indices, dp_CD4_count_cat_indices], 
        has_default=False),
    AM_AdultMortByCD4WithART0to6_MetaTag : gb_shape('AM_AdultMortByCD4WithART0to6_MetaTag', type='dict', 
        innerShape = {
            'default': 
            gb_shape('AdultMortByCD4WithART0to6', 
                '4D float', 
                dim=[dp_regions_dim, gb_sex_dim, dp_10y_age_dim, dp_CD4_count_cat_dim],
                indices=[dp_regions_indices, gb_sex_indices, dp_10y_age_indices, dp_CD4_count_cat_indices],
            )
        },
        has_default=False),
    AM_AdultMortByCD4WithART7to12Tag : gb_shape('AM_AdultMortByCD4WithART7to12Tag', type='4D float', 
        dim=[dp_default_data_dim, gb_sex_dim, dp_10y_age_dim, dp_CD4_count_cat_dim], 
        indices=[dp_default_data_indices, gb_sex_indices, dp_10y_age_indices, dp_CD4_count_cat_indices], 
        has_default=False),
    AM_AdultMortByCD4WithART7to12_MetaTag : gb_shape('AM_AdultMortByCD4WithART7to12_MetaTag', type='dict', 
        innerShape = {
            'default': 
            gb_shape('AdultMortByCD4WithART7to12', 
                '4D float', 
                dim=[dp_regions_dim, gb_sex_dim, dp_10y_age_dim, dp_CD4_count_cat_dim],
                indices=[dp_regions_indices, gb_sex_indices, dp_10y_age_indices, dp_CD4_count_cat_indices],
            )
        },
        has_default=False),
    AM_AdultMortByCD4WithARTGT12Tag : gb_shape('AM_AdultMortByCD4WithARTGT12Tag', type='4D float', 
        dim=[dp_default_data_dim, gb_sex_dim, dp_10y_age_dim, dp_CD4_count_cat_dim], 
        indices=[dp_default_data_indices, gb_sex_indices, dp_10y_age_indices, dp_CD4_count_cat_indices], 
        has_default=False),
    AM_AdultMortByCD4WithARTGT12_MetaTag : gb_shape('AM_AdultMortByCD4WithARTGT12_MetaTag', type='dict', 
        innerShape = {
            'default': 
            gb_shape('AdultMortByCD4WithARTGT12', 
                '4D float', 
                dim=[dp_regions_dim, gb_sex_dim, dp_10y_age_dim, dp_CD4_count_cat_dim],
                indices=[dp_regions_indices, gb_sex_indices, dp_10y_age_indices, dp_CD4_count_cat_indices],
            )
        },
        has_default=False),
    # mark added next 5
    AM_AdultNonAIDSExcessMortTag : gb_shape('AM_AdultNonAIDSExcessMort_V2', type='5D float', 
        dim=[dp_default_data_dim, gb_sex_dim, dp_10y_age_dim, dp_CD4_count_cat_dim, dp_ART_status_dim], 
        indices=[dp_default_data_indices, gb_sex_indices, dp_10y_age_indices, dp_CD4_count_cat_indices, dp_ART_status_indices], 
        has_default=False),
    AM_AdultNonAIDSExcessMort_Meta_Tag : gb_shape('AM_AdultNonAIDSExcessMort_Meta_V1', type='dict', 
        innerShape = {
            'default': 
            gb_shape('AdultNonAIDSExcessMort', 
                '5D float', 
                dim=[dp_regions_dim, gb_sex_dim, dp_10y_age_dim, dp_CD4_count_cat_dim, dp_ART_status_dim],
                indices=[dp_regions_indices, gb_sex_indices, dp_10y_age_indices, dp_CD4_count_cat_indices, dp_ART_status_indices],
            )
        },
        has_default=False),
    AM_AdultNonAIDSExcessMortRegionTag : gb_shape('AM_AdultNonAIDSExcessMortRegion_V1', type='int', has_default=False),
    AM_AdultNonAIDSExcessMortCustomFlagTag : gb_shape('AM_AdultNonAIDSExcessMortCustomFlag_V1', type='bool', has_default=False),
    AM_NonAIDSExcessDeathsSingleAgeTag : gb_shape('AM_NonAIDSExcessDeathsSingleAge_V2', type='4D float', 
        dim=[dp_ART_status_dim, gb_sex_dim, gb_single_age_dim, gb_year_dim], 
        indices=[dp_ART_status_indices, gb_sex_indices, gb_single_age_indices, gb_year_indices], 
        has_default=False),
    AM_TFRRegionTag : gb_shape('AM_TFRRegionTag', type='int', has_default=False),
    AM_TFRRegion_MetaTag : gb_shape('AM_TFRRegion_MetaTag', type='dict', 
        innerShape = {
            'default': gb_shape('TFRRegion', type='int')
        },
        has_default=False),
    AM_HIVTFRCustomFlagTag : gb_shape('AM_HIVTFRCustomFlagTag', type='bool', has_default=False),
    AM_HIVTFRTag : gb_shape('AM_HIVTFRTag', type='3D float', 
        dim=[dp_default_data_dim, gb_5y_age_adult_dim, gb_year_dim], 
        indices=[dp_default_data_indices, gb_5y_age_adult_indices, gb_year_indices], 
        has_default=True,
        has_global=True, 
        has_country=True),
    AM_HIVTFR_MetaTag : gb_shape('AM_HIVTFR_MetaTag', type='dict', 
        innerShape = {
            'default': 
            gb_shape('HIVTFR', 
                '3D float', 
                dim=[dp_regions_dim, gb_5y_age_adult_dim, gb_year_dim],
                indices=[dp_regions_indices, gb_5y_age_adult_indices, gb_year_indices],
            )
        },
        has_default=True,
        has_global=True, 
        has_country=True),
    AM_TFRInputTypeTag : gb_shape('AM_TFRInputTypeTag', type='int', has_default=False),
    AM_FertCD4DiscountTag : gb_shape('AM_FertCD4DiscountTag', type='2D float', 
        dim=[dp_default_data_dim, dp_CD4_count_cat_dim], 
        indices=[dp_default_data_indices, dp_CD4_count_cat_indices], 
        has_default=False),
    AM_FertCD4Discount_MetaTag : gb_shape('AM_FertCD4Discount_MetaTag', type='dict', 
        innerShape = {
            'default': 
            gb_shape('FertCD4Discount', 
                '2D float', 
                dim=[dp_regions_dim, dp_CD4_count_cat_dim],
                indices=[dp_regions_indices, dp_CD4_count_cat_indices],
            )
        },
        has_default=False),
    AM_RatioWomenOnARTTag : gb_shape('AM_RatioWomenOnARTTag', type='2D float', 
        dim=[dp_default_data_dim, gb_5y_age_adult_dim], 
        indices=[dp_default_data_indices, gb_5y_age_adult_indices], 
        has_default=False),
    AM_RatioWomenOnART_MetaTag : gb_shape('AM_RatioWomenOnART_MetaTag', type='dict', 
        innerShape = {
            'default': 
            gb_shape('RatioWomenOnART', 
                '2D float', 
                dim=[dp_regions_dim, gb_5y_age_adult_dim],
                indices=[dp_regions_indices, gb_5y_age_adult_indices],
            )
        },
        has_default=False),

    AM_FRRFitInputTag : 
        gb_shape('AM_FRRFitInputTag', type='2D float', 
            dim=[dp_percent_or_number_dim, gb_year_dim], 
            indices=[dp_percent_or_number_indices, gb_year_indices], 
            has_default=False
        ),
        
    AM_FRRbyLocationTag : 
        gb_shape('AM_FRRbyLocationTag', type='1D float', 
            dim=[dp_default_data_dim],
            indices=[dp_default_data_indices], 
            has_default=True, has_easy_aim=True
        ),

    AM_TransEffAssumpTag : 
        gb_shape('AM_TransEffAssumpTag', type='3D float', 
            dim=[dp_default_data_dim, dp_regimen_transmission_efficacy_MTCT_dim, dp_stage_transmission_efficacy_MTCT_dim],
            indices=[dp_default_data_indices, dp_regimen_transmission_efficacy_MTCT_indices, dp_stage_transmission_efficacy_MTCT_indices],                     
            has_default=False
        ),

    AM_DALYDisabilityWeightsTag : 
        gb_shape('AM_DALYDisabilityWeightsTag', type='2D float', 
            dim=[dp_DALY_weights_dim, dp_adult_child_dim],
            indices=[dp_DALY_weights_indices, dp_adult_child_indices], 
            has_default=False
        ),

    AM_RiskPopOrphansTag : 
        gb_shape('AM_RiskPopOrphansTag', type='2D float', 
            dim=[dp_risk_group_dim, dp_AIDS_deaths_married_dim],
            indices=[dp_risk_group_indices, dp_AIDS_deaths_married_indices], 
            has_default=False
        ),

    AM_ECDCValuesTag : 
        gb_shape('AM_ECDCValuesTag', type='2D float', 
            dim=[dp_num_type_dim, gb_year_dim],
            indices=[dp_num_type_indices, gb_year_indices], 
            has_default=False
        ),

    AM_NosocomialInfectionsByAgeTag : 
        gb_shape('AM_NosocomialInfectionsByAgeTag', type='2D float', 
            dim=[dp_nosocomial_infection_ages_dim, gb_year_dim],
            indices=[dp_nosocomial_infection_ages_indices, gb_year_indices], 
            has_default=False
        ),

    AM_HIVMigrantsBySexAgeTag : 
        gb_shape('AM_HIVMigrantsBySexAgeTag', type='3D int', 
            dim=[gb_sex_dim, gb_5y_age_dim, gb_year_dim],
            indices=[gb_sex_indices, gb_5y_age_indices, gb_year_indices], 
            has_default=False
        ),

    AM_HIVMigrantsBySingleAgeTag : 
        gb_shape('AM_HIVMigrantsBySingleAgeTag', type='3D int', 
            dim=[gb_sex_dim, gb_5y_age_dim, gb_year_dim],
            indices=[gb_sex_indices, gb_5y_age_indices, gb_year_indices], 
            has_default=False)
        ,
    
    AM_IncidenceInput1970Tag : 
        gb_shape('AM_IncidenceInput1970Tag', type='1D float', 
            dim=[gb_year_dim],
            indices=[gb_year_indices], 
            has_default=True, has_easy_aim=True
        ),

    AM_CSAVRInputAIDSDeathsTag : 
        gb_shape('AM_CSAVRInputAIDSDeathsTag', type='3D int', 
            dim=[dp_CSAVR_source_dim, dp_CSAVR_reporting_dim, gb_year_dim],
            indices=[dp_CSAVR_source_indices, dp_CSAVR_reporting_indices, gb_year_indices], 
            has_default=False
        ),

    AM_CSAVRInputAIDSDeathsBySexTag : 
        gb_shape('AM_CSAVRInputAIDSDeathsBySexTag', type='4D int', 
            dim=[dp_CSAVR_source_dim, gb_sex_dim, dp_CSAVR_reporting_dim, gb_year_dim],
            indices=[dp_CSAVR_source_dim, gb_sex_indices, dp_CSAVR_reporting_indices, gb_year_indices], 
            has_default=False
        ),

    AM_CSAVRInputAIDSDeathsBySexAgeTag : 
        gb_shape('AM_CSAVRInputAIDSDeathsBySexAgeTag', type='4D int', 
            dim=[dp_CSAVR_source_dim, gb_sex_dim, dp_CSAVR_ages_dim, gb_year_dim],
            indices=[dp_CSAVR_source_indices, gb_sex_indices, dp_CSAVR_ages_indices, gb_year_indices], 
            has_default=False
        ),

    AM_CSAVRInputAIDSDeathsSourceTag : gb_shape('AM_CSAVRInputAIDSDeathsSourceTag', type='int', has_default=False),

    AM_CSAVRInputAIDSDeathsSourceNameTag : 
        gb_shape('AM_CSAVRInputAIDSDeathsSourceNameTag', type='1D str', 
            dim=[dp_CSAVR_source_dim],
            indices=[dp_CSAVR_source_indices], 
            has_default=False
        ),
    
    AM_CSAVRInputNewDiagnosesTag : 
        gb_shape('AM_CSAVRInputNewDiagnosesTag', type='2D int', 
            dim=[dp_CSAVR_reporting_dim, gb_year_dim],
            indices=[dp_CSAVR_reporting_indices, gb_year_indices], 
            has_default=False
        ),

    AM_CSAVRInputNewDiagnosesBySexTag : 
        gb_shape('AM_CSAVRInputNewDiagnosesBySexTag', type='3D int', 
            dim=[gb_sex_dim, dp_CSAVR_reporting_dim, gb_year_dim],
            indices=[gb_sex_indices, dp_CSAVR_reporting_indices, gb_year_indices], 
            has_default=False
        ),

    AM_CSAVRInputNewDiagnosesBySexAgeTag : 
        gb_shape('AM_CSAVRInputNewDiagnosesBySexAgeTag', type='3D int', 
            dim=[gb_sex_dim, dp_CSAVR_ages_dim, gb_year_dim],
            indices=[gb_sex_indices, dp_CSAVR_ages_indices, gb_year_indices], 
            has_default=False
        ),

    AM_CSAVRInputNewDiagnosesBySexAgeCD4Tag : 
        gb_shape('AM_CSAVRInputNewDiagnosesBySexAgeCD4Tag', type='4D int', 
            dim=[gb_sex_dim, dp_CSAVR_ages_dim, dp_CSAVR_CD4_dim, gb_year_dim],
            indices=[gb_sex_indices, dp_CSAVR_ages_indices, dp_CSAVR_CD4_indices, gb_year_indices], 
            has_default=False
        ),

    AM_CSAVRInputCD4DistAtDiagTag : 
        gb_shape('AM_CSAVRInputCD4DistAtDiagTag', type='2D int', 
            dim=[dp_CSAVR_CD4_dim, gb_year_dim],
            indices=[dp_CSAVR_CD4_indices, gb_year_indices], 
            has_default=False
        ),

    AM_CSAVRPopulationValueTag : gb_shape('AM_CSAVRPopulationValueTag', type='int', has_default=False),

    AM_AIDSMortalityAllAgesTag : 
        gb_shape('AM_AIDSMortalityAllAgesTag', type='2D float', 
            dim=[dp_AIDS_deaths_all_ages_num_dim, gb_year_dim],
            indices=[dp_AIDS_deaths_all_ages_num_indices, gb_year_indices],                       
            has_default=False
        ),

    AM_AnnualInterruptionRateTag : gb_shape('AM_AnnualInterruptionRateTag', type='int', has_default=False),

    AM_IncreasedLikelihoodOfReinitTag : gb_shape('AM_IncreasedLikelihoodOfReinitTag', type='int', has_default=False),

    AM_OffARTMortRateMultiplierTag : gb_shape('AM_OffARTMortRateMultiplierTag', type='int', has_default=False),

    AM_ChildAnnualInterruptionRateTag : gb_shape('AM_ChildAnnualInterruptionRateTag', type='int', has_default=False),

    AM_ChildIncreasedLikelihoodOfReinitTag : gb_shape('AM_ChildIncreasedLikelihoodOfReinitTag', type='int', has_default=False),

    AM_ChildOffARTMortRateMultiplierTag : gb_shape('AM_ChildOffARTMortRateMultiplierTag', type='int', has_default=False),

    AM_CSAVRFitOptionsTag : 
        gb_shape('AM_CSAVRFitOptionsTag', type='1D bool', 
            dim=[dp_fitting_incidence_option_dim],
            indices=[dp_fitting_incidence_option_indices],     
            has_default=False
        ),


    #skip next 2; They have a large, unique shape, currently with no years. First one comes from CSAVRParams.json.  No utility functions in Python to return the many different 
    # possible keys for the various possible fit types. We could make them, but the CSAVRParams.json is not generated in Python, so it wouldn't use the utility functions. We 
    # could hardcode all the keys, but they change often and would likely fall out-of-sync. Sample of what we're dealing with (362 lines long):
    # {
	# "1": {
	# 	"alpha": {
	# 		"mstID": "0",
	# 		"value": -1.51410738923358
	# 	},
	# 	"beta": {
	# 		"mstID": "1",
	# 		"value": -0.623374237780359
	# 	},

    AM_CSAVRParametersTag : 
        gb_shape('AM_CSAVRParametersTag', type='dict', 
            contingent=True, # Contingent upon filling out this MV shape based on the file above in a maintainable way.
            has_default=False
        ),
    
    AM_CSAVRIncScaleParametersTag : 
        gb_shape('AM_CSAVRIncScaleParametersTag', type='dict', 
            contingent=True, # Contingent upon filling out this MV shape based on the file above in a maintainable way.
            has_default=False
        ), 

    AM_CSAVRUncertaintyParamsTag : 
        gb_shape('AM_CSAVRUncertaintyParamsTag', type='2D float',
            dim=[dp_CSAVR_fit_types_dim, dp_CSAVR_uncertainty_types_dim],
            indices=[dp_CSAVR_fit_types_indices, dp_CSAVR_uncertainty_types_indices],                                        
            has_default=False
        ),
        
    AM_CSAVRConstrainPLHIVGTNumARTTag : 
        gb_shape('AM_CSAVRConstrainPLHIVGTNumARTTag', type='1D bool', 
            dim=[dp_CSAVR_fit_types_dim],
            indices=[dp_CSAVR_fit_types_indices], 
            has_default=False
        ),

    AM_CSAVRTypeOfFitTag : gb_shape('AM_CSAVRTypeOfFitTag', type='int', has_default=False),

    AM_CSAVRAdjustIRRsTag : 
        gb_shape('AM_CSAVRAdjustIRRsTag', type='2D bool', 
            dim=[dp_CSAVR_fit_types_dim, dp_CSAVR_adjust_IRRs_dim],
            indices=[dp_CSAVR_fit_types_indices, dp_CSAVR_adjust_IRRs_indices], 
            has_default=False
        ),

    # Removed
    # AM_CSAVRFitMethodTag : 
    #     gb_shape('AM_CSAVRFitMethodTag', type='1D int', 
    #         dim=[dp_CSAVR_fit_types_dim],
    #         indices=[dp_CSAVR_fit_types_indices], 
    #         has_default=False
    #     ),

    AM_CSAVRMetaDataTag : 
        gb_shape('AM_CSAVRMetaDataTag', type='1D dict', 
            dim=[dp_CSAVR_fit_types_dim],
            indices=[dp_CSAVR_fit_types_indices], 
            innerShape=gb_shape('', type='dict',  innerShape={
                'AIC'       : gb_shape('', type='float'),
                'isFitted'  : gb_shape('', type='bool'),
                'date'      : gb_shape('', type='int'),
            }),
            has_default=False
        ),

    AM_CSAVRMeanCD4atDiagnosisTag : 
        gb_shape('AM_CSAVRMeanCD4atDiagnosisTag', type='4D float', 
            dim=[dp_CSAVR_fit_types_dim, gb_sex_dim, dp_num_type_dim, gb_year_dim],
            indices=[dp_CSAVR_fit_types_indices, gb_sex_indices, dp_num_type_indices, gb_year_indices], 
            has_default=False
        ),

    AM_CSAVRMeanCD4atDiagnosisByAgeSexTag : 
        gb_shape('AM_CSAVRMeanCD4atDiagnosisByAgeSexTag', type='5D float', 
            dim=[dp_CSAVR_fit_types_dim, gb_sex_dim, dp_CSAVR_ages_dim, dp_num_type_dim, gb_year_dim],
            indices=[dp_CSAVR_fit_types_indices, gb_sex_indices, dp_CSAVR_ages_indices, dp_num_type_indices, gb_year_indices], 
            has_default=False
        ),

    AM_CSAVRTimeInfToDiagTag : 
        gb_shape('AM_CSAVRTimeInfToDiagTag', type='4D float', 
            dim=[dp_CSAVR_fit_types_dim, gb_sex_dim, dp_num_type_dim, gb_year_dim],
            indices=[dp_CSAVR_fit_types_indices, gb_sex_indices, dp_num_type_indices, gb_year_indices], 
            has_default=False
        ),

    AM_CSAVRPropOfDiagnosedTag : 
        gb_shape('AM_CSAVRPropOfDiagnosedTag', type='4D float', 
            dim=[dp_CSAVR_fit_types_dim, gb_sex_dim, dp_num_type_dim, gb_year_dim],
            indices=[dp_CSAVR_fit_types_indices, gb_sex_indices, dp_num_type_indices, gb_year_indices],                                
            has_default=False
        ),

    AM_CSAVRPropOfDiagnosedNoARTTag : 
        gb_shape('AM_CSAVRPropOfDiagnosedNoARTTag', type='4D float', 
            dim=[dp_CSAVR_fit_types_dim, gb_sex_dim, dp_num_type_dim, gb_year_dim],
            indices=[dp_CSAVR_fit_types_indices, gb_sex_indices, dp_num_type_indices, gb_year_indices],      
            has_default=False
        ),

    AM_CSAVRPropOfDiagnosedByAgeSexCD4Tag : 
        gb_shape('AM_CSAVRPropOfDiagnosedByAgeSexCD4Tag', type='6D float', 
            dim=[dp_CSAVR_fit_types_dim, gb_sex_dim, dp_CSAVR_ages_dim, dp_CSAVR_CD4_2_dim, dp_num_type_dim, gb_year_dim],
            indices=[dp_CSAVR_fit_types_indices, gb_sex_indices, dp_CSAVR_ages_indices, dp_CSAVR_CD4_2_indices, dp_num_type_indices, gb_year_indices], 
            has_default=False
        ),

    AM_CSAVRNumPLHIVTag : 
        gb_shape('AM_CSAVRNumPLHIVTag', type='4D float', 
            dim=[dp_CSAVR_fit_types_dim, gb_sex_dim, dp_num_type_dim, gb_year_dim],
            indices=[dp_CSAVR_fit_types_indices, gb_sex_indices, dp_num_type_indices, gb_year_indices], 
            has_default=False
        ),

    AM_CSAVRNumPLHIVByAgeSexCD4Tag : 
        gb_shape('AM_CSAVRNumPLHIVByAgeSexCD4Tag', type='6D float', 
            dim=[dp_CSAVR_fit_types_dim, gb_sex_dim, dp_CSAVR_ages_dim, dp_CSAVR_CD4_2_dim, dp_num_type_dim, gb_year_dim],
            indices=[dp_CSAVR_fit_types_indices, gb_sex_indices, dp_CSAVR_ages_indices, dp_CSAVR_CD4_2_indices, dp_num_type_indices, gb_year_indices], 
            has_default=False
        ),

    AM_CSAVRNumDiagnosedTag : 
        gb_shape('AM_CSAVRNumDiagnosedTag', type='4D float', 
            dim=[dp_CSAVR_fit_types_dim, gb_sex_dim, dp_num_type_dim, gb_year_dim],
            indices=[dp_CSAVR_fit_types_indices, gb_sex_indices, dp_num_type_indices, gb_year_indices], 
            has_default=False
        ),

    AM_CSAVRNumDiagnosedByAgeSexCD4Tag : 
        gb_shape('AM_CSAVRNumDiagnosedByAgeSexCD4Tag', type='6D float', 
            dim=[dp_CSAVR_fit_types_dim, gb_sex_dim, dp_CSAVR_ages_dim, dp_CSAVR_CD4_2_dim, dp_num_type_dim, gb_year_dim],
            indices=[dp_CSAVR_fit_types_indices, gb_sex_indices, dp_CSAVR_ages_indices, dp_CSAVR_CD4_2_indices, dp_num_type_indices, gb_year_indices], 
            has_default=False
        ),

    AM_CSAVRAIDSDeathsTag : 
        gb_shape('AM_CSAVRAIDSDeathsTag', type='4D float', 
            dim=[dp_CSAVR_fit_types_dim, gb_sex_dim, dp_num_type_dim, gb_year_dim],
            indices=[dp_CSAVR_fit_types_indices, gb_sex_indices, dp_num_type_indices, gb_year_indices], 
            has_default=False
        ),

    AM_CSAVRAIDSDeathsByAgeSexTag : 
        gb_shape('AM_CSAVRAIDSDeathsByAgeSexTag', type='5D float', 
            dim=[dp_CSAVR_fit_types_dim, gb_sex_dim, dp_CSAVR_ages_dim, dp_num_type_dim, gb_year_dim],
            indices=[dp_CSAVR_fit_types_indices, gb_sex_indices, dp_CSAVR_ages_indices, dp_num_type_indices, gb_year_indices], 
            has_default=False
        ),

    AM_CSAVRNumNewInfectionsTag : 
        gb_shape('AM_CSAVRNumNewInfectionsTag', type='4D float', 
            dim=[dp_CSAVR_fit_types_dim, gb_sex_dim, dp_num_type_dim, gb_year_dim],
            indices=[dp_CSAVR_fit_types_indices, gb_sex_indices, dp_num_type_indices, gb_year_indices], 
            has_default=False
        ),

    AM_HIVSexRatioTag : 
        gb_shape('AM_HIVSexRatioTag', type='1D float', 
            dim=[gb_year_dim],
            indices=[gb_year_indices], 
            has_default=True, 
            has_easy_aim=True
        ),

    AM_HIVSexRatio_MetaTag : 
        gb_shape('AM_HIVSexRatio_MetaTag', type='dict', 
            innerShape={
                'default' : 
                    gb_shape('', type='2D float',
                        dim=[dp_age_ratio_patterns_dim, gb_year_dim],
                        indices=[dp_age_ratio_patterns_indices, gb_year_indices]
                    ),
            },
            has_default=True, 
            has_easy_aim=True
        ),

    AM_CSAVRHIVSexRatioTag : 
        gb_shape('AM_CSAVRHIVSexRatioTag', type='2D float', 
            dim=[dp_CSAVR_fit_types_dim, gb_year_dim],
            indices=[dp_CSAVR_fit_types_indices, gb_year_indices], 
            has_default=True, 
            has_easy_aim=True
        ),

    #AM_HIVSexRatioFittingValuesTag : gb_shape('AM_HIVSexRatioFittingValuesTag', type='incomplete', has_default=False),

    AM_CustomSAPDataTag : 
        gb_shape('AM_CustomSAPDataTag', type='1D dict', 
            dim=['CustomSAPData'],
            innerShape={
                'name'         : gb_shape('', type='str'),  
                'id'           : gb_shape('', type='int'),  
                'dataSource'   : gb_shape('', type='int'),  
                'fitType'      : gb_shape('', type='int'),  
                'HIVPrevModel' : gb_shape('', type='int'),  
                'AIC'          : gb_shape('', type='int'),  
                'HIVSexRatio'  : gb_shape('', type='1D float', dim=[gb_year_dim], indices=[gb_year_indices]),  
                'DistOfHIV'    : 
                    gb_shape('', type='3D float', 
                        dim=[gb_sex_dim, gb_5y_age_dim, gb_year_dim], 
                        indices=[gb_sex_indices, gb_5y_age_indices, gb_year_indices]
                    ),  
            },
            has_default=False
        ),

    AM_CustomSAPData_MetaTag : 
        gb_shape('AM_CustomSAPData_MetaTag', type='dict', 
            innerShape={
                'name'         : gb_shape('', type='str'),  
                'id'           : gb_shape('', type='int'),  
                'dataSource'   : gb_shape('', type='int'),  
                'fitType'      : gb_shape('', type='int'),  
                'HIVPrevModel' : gb_shape('', type='int'),  
                'AIC'          : gb_shape('', type='int'),  
                'HIVSexRatio'  : gb_shape('', type='1D float', dim=[gb_year_dim], indices=[gb_year_indices]),  
                'DistOfHIV'    : 
                    gb_shape('', type='3D float', 
                        dim=[gb_sex_dim, gb_5y_age_dim, gb_year_dim], 
                        indices=[gb_sex_indices, gb_5y_age_indices, gb_year_indices]
                    ),  
            },
            has_default=False
        ),

    AM_CustomSAPDataIndexTag : gb_shape('AM_CustomSAPDataIndexTag', type='int', has_default=False),

    # AM_ARTTreatFitDistOfHIVTag : gb_shape('#AM_ARTTreatFitDistOfHIVTag', type='incomplete', has_default=False),
    # AM_ARTTreatFitHIVSexRatioTag : gb_shape('#AM_ARTTreatFitHIVSexRatioTag', type='incomplete', has_default=False),
    # AM_ARTTreatFitHIVSexRatio_MetaTag : gb_shape('#AM_ARTTreatFitHIVSexRatio_MetaTag', type='incomplete', has_default=False),
    # AM_FittingDataTag : gb_shape('#AM_FittingDataTag', type='incomplete', has_default=False),
    # AM_ARTTreatFittingDataTag : gb_shape('#AM_ARTTreatFittingDataTag', type='incomplete', has_default=False),

    AM_DistOfHIVTag : 
        gb_shape('AM_DistOfHIVTag', type='3D int', 
            dim=[gb_sex_dim, gb_5y_age_dim, gb_year_dim], 
            indices=[gb_sex_indices, gb_5y_age_indices, gb_year_indices],
            has_default=False
        ),

    AM_DistOfHIV_MetaTag : 
        gb_shape('AM_DistOfHIV_MetaTag', type='dict', 
            innerShape={
                'default' : 
                    gb_shape('', type='4D float',
                        dim=[dp_age_ratio_patterns_dim, gb_sex_dim, gb_5y_age_dim, gb_year_dim],
                        indices=[dp_age_ratio_patterns_indices, gb_sex_indices, gb_5y_age_indices, gb_year_indices]
                    ),
            },
            has_default=False
        ),

    AM_CSAVRDistOfHIVTag : 
        gb_shape('AM_CSAVRDistOfHIVTag', type='4D float', 
            dim=[dp_CSAVR_fit_types_dim, gb_sex_dim, gb_5y_age_dim, gb_year_dim],
            indices=[dp_CSAVR_fit_types_indices, gb_sex_indices, gb_5y_age_indices, gb_year_indices],
            has_default=False
        ),
    
    AM_EPPANCRTDataTag : 
        gb_shape('AM_EPPANCRTDataTag', type='dict', 
            innerShape={
                'hasData'   : gb_shape('', type='bool'),  
                'SizeValue' : gb_shape('', type='1D float', dim=[gb_year_dim], indices=[gb_year_indices]),
                'PrevValue' : gb_shape('', type='1D float', dim=[gb_year_dim], indices=[gb_year_indices]),
            },
            has_default=False
        ),
        
    AM_SAPFormDHSFitSurveyTag : 
        gb_shape('AM_SAPFormDHSFitSurveyTag', type='1D dict', 
            dim=[dp_prev_surveys_dim],
            innerShape={
                'data' : 
                    gb_shape('', type='3D float',
                        dim=[gb_sex_dim, dp_sample_sizes_dim, gb_5y_age_dim],
                        indices=[gb_sex_indices, dp_sample_sizes_indices, gb_5y_age_indices],
                    ),
                'used' : gb_shape('', type='bool'),  
                'name' : gb_shape('', type='str'),  
                'year' : gb_shape('', type='int'),  
            },
            has_default=False
        ),

    # AM_IRRFittingValuesTag : gb_shape('#AM_IRRFittingValuesTag', type='incomplete', has_default=False),
    AM_AIDS45q15Tag : 
        gb_shape('AM_AIDS45q15Tag', type='1D int', 
            dim=[gb_year_dim], 
            indices=[gb_year_indices],           
            has_default=False
        ),

    AM_NonAIDS45q15Tag : 
        gb_shape('AM_NonAIDS45q15Tag', type='1D int', 
            dim=[gb_year_dim], 
            indices=[gb_year_indices],   
            has_default=False
        ),

    AM_Total45q15Tag : 
        gb_shape('AM_Total45q15Tag', type='1D int', 
            dim=[gb_year_dim], 
            indices=[gb_year_indices],   
            has_default=True,
            has_country=True
        ),
    
    AM_Total45q15_MetaTag : 
        gb_shape('AM_Total45q15_MetaTag', type='dict', 
            innerShape={
                'default': 
                    gb_shape('', type='dict', 
                        innerShape={
                            'default' : 
                                gb_shape('', type='1D float',        
                                        dim=[gb_year_dim],
                                        indices=[gb_year_indices]
                                    ),
                            'hasData' : gb_shape('', type='bool'),
                        },
                    )
            },
            has_default=True,
            has_country=True
        ),

    AM_Under5MortRateTag : 
        gb_shape('AM_Under5MortRateTag', type='1D int', 
            dim=[gb_year_dim],
            indices=[gb_year_indices],
            has_default=False
        ),

    AM_PMTCTProgEstNeedTag : 
        gb_shape('AM_PMTCTProgEstNeedTag', type='1D int', 
            dim=[gb_year_dim],
            indices=[gb_year_indices],
            has_default=False
        ),

    AM_NumberOnARTTag : 
        gb_shape('AM_NumberOnARTTag', type='1D int', 
            dim=[gb_year_dim],
            indices=[gb_year_indices],
            has_default=False
        ),
    
    AM_ARTCovByAgeTag : 
        gb_shape('AM_ARTCovByAgeTag', type='3D int', 
            dim=[gb_sex_dim, gb_5y_age_dim, gb_year_dim], 
            indices=[gb_sex_indices, gb_5y_age_indices, gb_year_indices],   
            has_default=False
        ),
    
    AM_KeyPopsTag : 
        gb_shape('AM_KeyPopsTag', type='dict', 
            innerShape={
                'data'  : gb_shape('', type='2D float',
                            dim=[dp_key_pops_2_dim, dp_key_pops_1_dim], 
                            indices=[dp_key_pops_2_indices, dp_key_pops_1_indices]
                        ),
                'year'  : gb_shape('', type='int'),
                'fName' : gb_shape('', type='str'),
            },
            has_default=False
        ),
    
    AM_PregWomenPrevRoutineTestTag : gb_shape('AM_PregWomenPrevRoutineTestTag', type='float', has_default=False),

    AM_PregWomenPrevTag : 
        gb_shape('AM_PregWomenPrevTag', type='1D int', 
            dim=[gb_year_dim], 
            indices=[ gb_year_indices],  
            has_default=True,
            has_country=True
        ),

    AM_PregWomenPrev_MetaTag : 
        gb_shape('AM_PregWomenPrev_MetaTag', type='dict', 
            innerShape={
                'default': 
                    gb_shape('', type='dict', 
                        innerShape={
                            'defaultValue': 
                                gb_shape('', type='1D float',        
                                    dim=[gb_year_dim],
                                    indices=[gb_year_indices]
                                ),
                            'hasData': gb_shape('', type='bool'),
                        },
                    )
            },
            has_default=True,
            has_country=True
        ),
    
    AM_PrevSurveyTag : 
        gb_shape('AM_PrevSurveyTag', type='1D dict', 
            dim=[dp_prev_surveys_dim],
            innerShape={
                'data' : 
                    gb_shape('', type='3D float',
                        dim=[gb_sex_dim, dp_sample_sizes_dim, gb_5y_age_dim],
                        indices=[gb_sex_indices, dp_sample_sizes_indices, gb_5y_age_indices],
                    ),
                'used' : gb_shape('', type='bool'),  
                'name' : gb_shape('', type='str'),  
                'year' : gb_shape('', type='int'),  
            },
            has_default=False
        ),
    
    AM_PrevSurvey_MetaTag : 
        gb_shape('AM_PrevSurvey_MetaTag', type='dict', 
            innerShape={
                'default': 
                    gb_shape('', type='1D dict', 
                        innerShape={
                            'data' : 
                                gb_shape('', type='3D float',
                                    dim=[gb_sex_dim, dp_sample_sizes_dim, gb_5y_age_dim],
                                    indices=[gb_sex_indices, dp_sample_sizes_indices, gb_5y_age_indices],
                                ),
                            'used' : gb_shape('', type='bool'),  
                            'name' : gb_shape('', type='str'),  
                            'year' : gb_shape('', type='int'),  
                        },
                    )
            },
            has_default=True,
            contingent=True, # Contingent upon data being added to the MV.,
            has_country=True
        ),

    AM_ARTCovSurveyTag : 
        gb_shape('AM_ARTCovSurveyTag', type='1D dict', 
            dim=[dp_prev_surveys_dim],
            innerShape={
                'data' : 
                    gb_shape('', type='3D float',
                        dim=[gb_sex_dim, dp_sample_sizes_dim, gb_5y_age_dim + '_' + dp_ART_cov_validation_ages_dim],
                        indices=[gb_sex_indices, dp_sample_sizes_indices, {**gb_5y_age_indices, **dp_ART_cov_validation_ages_indices}],
                    ),
                'used' : gb_shape('', type='bool'),  
                'name' : gb_shape('', type='str'),  
                'year' : gb_shape('', type='int'),  
            },
            has_default=False,
        ),

    AM_ARTCovSurvey_MetaTag : 
        gb_shape('AM_ARTCovSurvey_MetaTag', type='dict', 
            innerShape={
                'default' : gb_shape('', type='0D empty'), # skip; no default for AFG  
            },
            has_default=True,
            has_country=True
        ),

    AM_MortRateByAgeTag : 
        gb_shape('AM_MortRateByAgeTag', type='3D int', 
            dim=[gb_sex_dim, gb_5y_age_dim, gb_year_dim], 
            indices=[gb_sex_indices, gb_5y_age_indices, gb_year_indices],
            has_default=False
        ),
    
    AM_AllCauseMortalityTag : 
        gb_shape('AM_AllCauseMortalityTag', type='3D int', 
            dim=[gb_sex_dim, gb_5y_age_dim, gb_year_dim], 
            indices=[gb_sex_indices, gb_5y_age_indices, gb_year_indices],
            has_default=False
        ),

    AM_AllCauseMortality_MetaTag : 
        gb_shape('AM_AllCauseMortality_MetaTag', type='dict', 
            innerShape={
                'default' : 
                    gb_shape('', type='3D int', 
                        dim=[gb_sex_dim, gb_5y_age_dim, gb_year_dim], 
                        indices=[gb_sex_indices, gb_5y_age_indices, gb_year_indices]
                    ),
                'hasData' : 
                    gb_shape('', type='bool'),
            },
            has_default=True,
            has_country=True
        ),

    AM_AIDSMortalityTag : 
        gb_shape('AM_AIDSMortalityTag', type='3D int', 
            dim=[gb_sex_dim, gb_5y_age_dim, gb_year_dim], 
            indices=[gb_sex_indices, gb_5y_age_indices, gb_year_indices],
            has_default=False
        ),

    AM_AIDSMortality_MetaTag : 
        gb_shape('AM_AIDSMortality_MetaTag', type='dict', 
            innerShape={
                'default' : 
                    gb_shape('', type='3D int', 
                        dim=[gb_sex_dim, gb_5y_age_dim, gb_year_dim], 
                        indices=[gb_sex_indices, gb_5y_age_indices, gb_year_indices]
                    ),
                'hasData' : 
                    gb_shape('', type='bool'),
            },
            has_default=True,
            has_country=True
        ),

    AM_NumberOnARTByAgeTag : 
        gb_shape('AM_NumberOnARTByAgeTag', type='3D int', 
            dim=[gb_sex_dim, gb_5y_age_dim, gb_year_dim], 
            indices=[gb_sex_indices, gb_5y_age_indices, gb_year_indices],
            has_default=False
        ),

    AM_NewlyStartingARTTag : 
        gb_shape('AM_NewlyStartingARTTag', type='3D int', 
            dim=[gb_sex_dim, gb_5y_age_dim, gb_year_dim], 
            indices=[gb_sex_indices, gb_5y_age_indices, gb_year_indices],
            has_default=False
        ),

    AM_AdultsChildrenStartingARTTag : 
        gb_shape('AM_AdultsChildrenStartingARTTag', type='3D int', 
            dim=[gb_sex_dim, gb_5y_age_dim, gb_year_dim], 
            indices=[gb_sex_indices, gb_5y_age_indices, gb_year_indices],
            has_default=False
        ),

    AM_PercentOfPopTag : 
        gb_shape('AM_PercentOfPopTag', type='1D float',
            dim=[gb_year_dim], 
            indices=[gb_year_indices],
            has_default=False
        ),

    AM_ARTCoverageSelectionTag : gb_shape('AM_ARTCoverageSelectionTag', type='int', has_default=False),

    AM_BFYearsRGIdxTag : gb_shape('AM_BFYearsRGIdxTag', type='int', has_default=False),

    AM_BFArvRGIdxTag : gb_shape('AM_BFArvRGIdxTag', type='int', has_default=False),

    AM_ChildHIVMortARTRegionTag : gb_shape('AM_ChildHIVMortARTRegionTag', type='int', has_default=False),

    AM_ChildHIVMortARTCustomFlagTag : gb_shape('AM_ChildHIVMortARTCustomFlagTag', type='bool', has_default=False),

    AM_ChildARTDistRegionTag : gb_shape('AM_ChildARTDistRegionTag', type='int', has_default=False),

    AM_ChildARTDistCustomFlagTag : gb_shape('AM_ChildARTDistCustomFlagTag', type='bool', has_default=False),

    AM_AdultProgressRatesRegionTag : gb_shape('AM_AdultProgressRatesRegionTag', type='int', has_default=False),

    AM_AdultProgressRatesCustomFlagTag : gb_shape('AM_AdultProgressRatesCustomFlagTag', type='bool', has_default=False),

    AM_AdultHIVMortNoARTRegionTag : gb_shape('AM_AdultHIVMortNoARTRegionTag', type='int', has_default=False),

    AM_AdultHIVMortNoARTCustomFlagTag : gb_shape('AM_AdultHIVMortNoARTCustomFlagTag', type='bool', has_default=False),

    AM_AdultHIVMortARTRegionTag : gb_shape('AM_AdultHIVMortARTRegionTag', type='int', has_default=False),

    AM_AdultHIVMortARTCustomFlagTag : gb_shape('AM_AdultHIVMortARTCustomFlagTag', type='bool', has_default=False),

    AM_DALYBaseYearTag : gb_shape('AM_DALYBaseYearTag', type='int', has_default=False),

    AM_DALYDiscountRateTag : gb_shape('AM_DALYDiscountRateTag', type='float', has_default=False),

    AM_DALYUseStandardLifeTableTag : gb_shape('AM_DALYUseStandardLifeTableTag', type='bool', has_default=False),

    AM_OrphansRegionalPatternTag : gb_shape('AM_OrphansRegionalPatternTag', type='int', has_default=False),

    AM_IncidenceInput1970BoolTag : gb_shape('AM_IncidenceInput1970BoolTag', type='bool', has_default=False),

    AM_IncidenceOptionsTag : gb_shape('AM_IncidenceOptionsTag', type='int', has_default=False),

    AM_IncidenceByFitTag : 
        gb_shape('AM_IncidenceByFitTag', type='2D float', 
            dim=[dp_incidence_option_dim, gb_year_dim], 
            indices=[dp_incidence_option_indices, gb_year_indices],
        has_default=True, has_easy_aim=True),

    AM_FourDecPlaceIDTag : gb_shape('AM_FourDecPlaceIDTag', type='bool', has_default=False),

    AM_EPPPrevAdjTag : gb_shape('AM_EPPPrevAdjTag', type='bool', has_default=False),

    AM_EPPMaxAdjFactorTag : gb_shape('AM_EPPMaxAdjFactorTag', type='int', has_default=False),

    AM_EPPPopulationAgesTag : gb_shape('AM_EPPPopulationAgesTag', type='int', has_default=False),

    # Removed
    # AM_IncEpidemicRGIdxTag : gb_shape('AM_IncEpidemicRGIdxTag', type='int', has_default=False),

    AM_IncEpidemicCustomFlagTag : gb_shape('AM_IncEpidemicCustomFlagTag', type='bool', has_default=False),

    AM_SexRatioFromEPPTag : gb_shape('AM_SexRatioFromEPPTag', type='bool', has_default=False),

    AM_HIVSexRatioFromEPPTag : 
        gb_shape('AM_HIVSexRatioFromEPPTag', type='1D int', 
            dim=[gb_year_dim], 
            indices=[gb_year_indices],
            has_default=False
        ),

    AM_EpidemicTypeFromEPPTag : gb_shape('AM_EpidemicTypeFromEPPTag', type='str', has_default=False),

    AM_AdultPrevalenceTag : gb_shape('AM_AdultPrevalenceTag', type='1D float', 
        dim=[gb_year_dim], 
        indices=[gb_year_indices],
        has_default=True, has_easy_aim=True),

    AM_EPPCountryNameTag : gb_shape('AM_EPPCountryNameTag', type='str', has_default=False),

    AM_EPPEpiNameTag : 
        gb_shape('AM_EPPEpiNameTag', type='1D str', 
            dim=[dp_EPP_epi_2_dim], 
            indices=[dp_EPP_epi_2_indices],
            has_default=False
        ),
    
    AM_EPPEpidemicTag : 
        gb_shape('AM_EPPEpidemicTag', type='1D str', 
            dim=[dp_EPP_epi_2_dim], 
            indices=[dp_EPP_epi_2_indices],
            has_default=False
        ),

    AM_EPPPrevDataTag : 
        gb_shape('AM_EPPPrevDataTag', type='2D float', 
            dim=[dp_EPP_epi_2_dim, gb_year_dim], 
            indices=[dp_EPP_epi_2_indices, gb_year_indices],
            has_default=False,
            contingent=True # Contingent upon data being added to the MV.
        ),
    
    AM_EPPIncDataTag : 
        gb_shape('AM_EPPIncDataTag', type='2D float', 
            dim=[dp_EPP_epi_2_dim, gb_year_dim], 
            indices=[dp_EPP_epi_2_indices, gb_year_indices],
            has_default=False,
            contingent=True # Contingent upon data being added to the MV.
        ),
   
    AM_EPPPopDataTag : 
        gb_shape('AM_EPPPopDataTag', type='2D float', 
            dim=[dp_EPP_epi_2_dim, gb_year_dim], 
            indices=[dp_EPP_epi_2_indices, gb_year_indices],
            has_default=False,
            contingent=True # Contingent upon data being added to the MV.
        ),
    
    AM_EPPSexRatioTag : 
        gb_shape('AM_EPPSexRatioTag', type='2D float', 
            dim=[dp_EPP_epi_2_dim, gb_year_dim], 
            indices=[dp_EPP_epi_2_indices, gb_year_indices],
            has_default=False,
            contingent=True # Contingent upon data being added to the MV.
        ),

    AM_EPPBaseYrPopTag : 
        gb_shape('AM_EPPBaseYrPopTag', type='1D float', 
            dim=[dp_EPP_epi_1_dim], 
            indices=[dp_EPP_epi_1_indices],  
            has_default=False,
            contingent=True # Contingent upon data being added to the MV.
        ),
    
    AM_EPPIDUMortalityTag : 
        gb_shape('AM_EPPIDUMortalityTag', type='1D float',
            dim=[dp_EPP_epi_1_dim], 
            indices=[dp_EPP_epi_1_indices],    
            has_default=False,
            contingent=True # Contingent upon data being added to the MV.
        ),
    
    AM_EPPPathInfoTag : 
        gb_shape('AM_EPPPathInfoTag', type='1D dict', 
            dim=[dp_EPP_epi_2_dim], 
            indices=[dp_EPP_epi_2_indices],  
            innerShape={
                'IsTotal'  : gb_shape('', type='bool'),
                'FullName' : gb_shape('', type='str'),
            } ,
            has_default=False,
        ),
    
    AM_EPPAgeRangeTag : gb_shape('AM_EPPAgeRangeTag', type='int', has_default=False),

    AM_NumOfEPPEpidemicsTag : gb_shape('AM_NumOfEPPEpidemicsTag', type='int', has_default=False),

    AM_YrPtPrevalence_WBTag : gb_shape('AM_YrPtPrevalence_WBTag', type='str', has_default=False),

    AM_AIDSDeathsAmongIDUTag : 
        gb_shape('AM_AIDSDeathsAmongIDUTag', type='1D int', 
            dim=[gb_year_dim], 
            indices=[gb_year_indices],            
            has_default=False
        ),

    AM_PropIDU_WBTag : 
        gb_shape('AM_PropIDU_WBTag', type='2D float', 
            dim=[dp_EPP_epi_1_dim, gb_year_dim], 
            indices=[dp_EPP_epi_1_indices, gb_year_indices], 
            has_default=False,
            contingent=True # Contingent upon data being added to the MV.
        ),

    AM_NonAIDSDeathsAmongIDUTag : 
        gb_shape('AM_NonAIDSDeathsAmongIDUTag', type='1D int', 
            dim=[gb_year_dim], 
            indices=[gb_year_indices],
            has_default=False
        ),

    AM_ChAged14ByCD4CatTag : 
        gb_shape('AM_ChAged14ByCD4CatTag', type='4D float', 
            dim=[gb_sex_dim, dp_CD4_count_cats_children_5_14_dim, dp_CD4_count_cats_children_5_14_indices, gb_year_dim], 
            indices=[gb_sex_indices, dp_HIV_mort_with_ART_treat_interval_dim, dp_HIV_mort_with_ART_treat_interval_indices, gb_year_indices],                           
            has_default=False
        ),

    AM_HIVExpUninfChildrenTag : 
        gb_shape('AM_HIVExpUninfChildrenTag', type='2D int',
            dim=[gb_sex_dim, gb_year_dim], 
            indices=[gb_sex_indices, gb_year_indices],                           
            has_default=False
        ),

    AM_ARTExpUninfChildrenTag : 
        gb_shape('AM_ARTExpUninfChildrenTag', type='2D int', 
            dim=[gb_sex_dim, gb_year_dim], 
            indices=[gb_sex_indices, gb_year_indices],                           
            has_default=False
        ),

    AM_NewInfantInfectionsTag : 
        gb_shape('AM_NewInfantInfectionsTag', type='1D int', 
            dim=[gb_year_dim], 
            indices=[gb_year_indices],                           
            has_default=False
        ),

    AM_CD4DistributionTag : 
        gb_shape('AM_CD4DistributionTag', type='4D float', 
            dim=[gb_sex_dim, dp_HIV_status_dim, dp_ART_status_dim, gb_year_dim], 
            indices=[gb_sex_indices, dp_HIV_status_indices, dp_ART_status_indices, gb_year_indices],  
            has_default=False
        ),

    AM_CD4Distribution15_49Tag : 
        gb_shape('AM_CD4Distribution15_49Tag', type='4D float', 
            dim=[gb_sex_dim, dp_HIV_status_dim, dp_ART_status_dim, gb_year_dim], 
            indices=[gb_sex_indices, dp_HIV_status_indices, dp_ART_status_indices, gb_year_indices],  
            has_default=False
        ),

    AM_CD4DistributionChildTag : 
        gb_shape('AM_CD4DistributionChildTag', type='6D float', 
            dim=[gb_sex_dim, dp_CD4_dist_not_on_ART_dim, dp_pediatric_CD4_categories_dim, dp_HIV_duration_status_timing_dim, dp_ART_status_dim, gb_year_dim], 
            indices=[gb_sex_indices, dp_CD4_dist_not_on_ART_indices, dp_pediatric_CD4_categories_indices, dp_HIV_duration_status_timing_indices, dp_ART_status_indices, gb_year_indices],                                  
            has_default=False
        ),
    
    AM_DeathsByAgeTag : 
        gb_shape('AM_DeathsByAgeTag', type='3D int', 
            dim=[gb_sex_dim, gb_single_age_dim, gb_year_dim], 
            indices=[gb_sex_indices, gb_single_age_indices, gb_year_indices],
            has_default=False
        ),
    
    AM_HIVBySingleAgeTag : 
        gb_shape('AM_HIVBySingleAgeTag', type='3D int', 
            dim=[gb_sex_dim, gb_single_age_dim, gb_year_dim], 
            indices=[gb_sex_indices, gb_single_age_indices, gb_year_indices],
            has_default=False
        ),
    
    AM_RegionalOutputTag : 
        gb_shape('AM_RegionalOutputTag', type='3D int', 
            dim=[dp_subpop_summary_ind_dim, dp_EPP_epi_1_dim, gb_year_dim], 
            indices=[dp_subpop_summary_ind_indices, dp_EPP_epi_1_indices, gb_year_indices],
            contingent=True, # Contingent upon data being added to the MV.
            has_default=False
        ),
    
    AM_OrphansTag : 
        gb_shape('AM_OrphansTag', type='3D float', 
            dim=[dp_orphans_dim, gb_single_age_child_17_dim, gb_year_dim], 
            indices=[dp_orphans_indices, gb_single_age_child_17_indices, gb_year_indices],                    
            has_default=False
        ),
    
    AM_AgeLastBDayTag : 
        gb_shape('AM_AgeLastBDayTag', type='3D float', 
            dim=[dp_ALB_dim, gb_single_age_child_17_dim, gb_year_dim], 
            indices=[dp_ALB_indices, gb_single_age_child_17_indices, gb_year_indices],                   
            has_default=False
        ),
    
    AM_PopAdjTag : 
        gb_shape('AM_PopAdjTag', type='2D int', 
            dim=[gb_sex_dim, gb_year_dim], 
            indices=[gb_sex_indices, gb_year_indices],
            has_default=False
        ),

    AM_PopAdjAmountTag : 
        gb_shape('AM_PopAdjAmountTag', type='3D int', 
            dim=[gb_sex_dim, gb_5y_age_dim, gb_year_dim], 
            indices=[gb_sex_indices, gb_5y_age_indices, gb_year_indices],
            has_default=False
        ),

    AM_AIDSDeathsByAgeTag : 
        gb_shape('AM_AIDSDeathsByAgeTag', type='3D int', 
            dim=[gb_sex_dim, gb_single_age_dim, gb_year_dim], 
            indices=[gb_sex_indices, gb_single_age_indices, gb_year_indices],
            has_default=False
        ),

    AM_AIDSDeathsARTSingleAgeTag : 
        gb_shape('AM_AIDSDeathsARTSingleAgeTag', type='3D int', 
            dim=[gb_sex_dim, gb_single_age_dim, gb_year_dim], 
            indices=[gb_sex_indices, gb_single_age_indices, gb_year_indices],
            has_default=False
        ),

    AM_AIDSDeathsNoARTSingleAgeTag : 
        gb_shape('AM_AIDSDeathsNoARTSingleAgeTag', type='3D int', 
            dim=[gb_sex_dim, gb_single_age_dim, gb_year_dim], 
            indices=[gb_sex_indices, gb_single_age_indices, gb_year_indices],
            has_default=False
        ),

    AM_HIVPregWomenTag : 
        gb_shape('AM_HIVPregWomenTag', type='1D int', 
            dim=[gb_year_dim], 
            indices=[gb_year_indices],
            has_default=False
        ),

    AM_HIVPregWomenCD4LT350Tag : 
        gb_shape('AM_HIVPregWomenCD4LT350Tag', type='1D int', 
            dim=[gb_year_dim], 
            indices=[gb_year_indices],
            has_default=False
        ),

    AM_ChildOnCotrimTag : 
        gb_shape('AM_ChildOnCotrimTag', type='2D int', 
            dim=[gb_sex_dim, gb_year_dim], 
            indices=[gb_sex_indices, gb_year_indices],
            has_default=False
        ),

    AM_ChildNeedCotrimTag : 
        gb_shape('AM_ChildNeedCotrimTag', type='2D int', 
            dim=[gb_sex_dim, gb_year_dim], 
            indices=[gb_sex_indices, gb_year_indices],
            has_default=False
        ),

    AM_NeedARTTag : 
        gb_shape('AM_NeedARTTag', type='3D int', 
            dim=[gb_sex_dim, gb_single_age_dim, gb_year_dim], 
            indices=[gb_sex_indices, gb_single_age_indices, gb_year_indices],
            has_default=False
        ),

    AM_UnmetNeedARTTag : 
        gb_shape('AM_UnmetNeedARTTag', type='3D int', 
            dim=[gb_sex_dim, gb_5y_age_dim, gb_year_dim], 
            indices=[gb_sex_indices, gb_5y_age_indices, gb_year_indices],
            has_default=False
        ),

    AM_PerinatalTransmissionTag : 
        gb_shape('AM_PerinatalTransmissionTag', type='1D int', 
            dim=[gb_year_dim], 
            indices=[gb_year_indices],
            has_default=False
        ),

    AM_ChildCTXNeed1To4Tag : 
        gb_shape('AM_ChildCTXNeed1To4Tag', type='2D int', 
            dim=[gb_sex_dim, gb_year_dim], 
            indices=[gb_sex_indices, gb_year_indices],
            has_default=False
        ),

    AM_TotalOrphansTag : 
        gb_shape('AM_TotalOrphansTag', type='3D float', 
            dim=[dp_orphans_total_dim, dp_AIDS_dim, gb_year_dim], 
            indices=[dp_orphans_total_indices, dp_AIDS_indices, gb_year_indices],
            has_default=False
        ),

    AM_AllAIDSOrphTag : 
        gb_shape('AM_AllAIDSOrphTag', type='2D float', 
            dim=[dp_orphans_total_2_dim, gb_year_dim], 
            indices=[dp_orphans_total_2_indices, gb_year_indices],
            has_default=False
        ),

    AM_AllAIDSNewOrphTag : 
        gb_shape('AM_AllAIDSNewOrphTag', type='2D float', 
            dim=[dp_orphans_total_2_dim, gb_year_dim], 
            indices=[dp_orphans_total_2_indices, gb_year_indices],
            has_default=False
        ),

    AM_NewlyNeedARTTag : 
        gb_shape('AM_NewlyNeedARTTag', type='3D int', 
            dim=[gb_sex_dim, gb_5y_age_dim, gb_year_dim], 
            indices=[gb_sex_indices, gb_5y_age_indices, gb_year_indices],
            has_default=False
        ),

    AM_ChildNeedPMTCTTag : 
        gb_shape('AM_ChildNeedPMTCTTag', type='1D int', 
            dim=[gb_year_dim], 
            indices=[gb_year_indices],
            has_default=False
        ),

    AM_ChildOnPMTCTTag : 
        gb_shape('AM_ChildOnPMTCTTag', type='1D int', 
            dim=[gb_year_dim], 
            indices=[gb_year_indices],
            has_default=False
        ),

    AM_MTCTRate6WksTag : 
        gb_shape('AM_MTCTRate6WksTag', type='1D int', 
            dim=[gb_year_dim], 
            indices=[gb_year_indices],
            has_default=False
        ),

    AM_OnARTBySingleAgeTag : 
        gb_shape('AM_OnARTBySingleAgeTag', type='3D int', 
            dim=[gb_sex_dim, gb_single_age_dim, gb_year_dim], 
            indices=[gb_sex_indices, gb_single_age_indices, gb_year_indices],
            has_default=False
        ),

    AM_OnARTBySingleAge_ProgDataTag : 
        gb_shape('AM_OnARTBySingleAge_ProgDataTag', type='3D int', 
            dim=[gb_sex_dim, gb_single_age_dim, gb_year_dim], 
            indices=[gb_sex_indices, gb_single_age_indices, gb_year_indices],
            has_default=False
        ),

    AM_NewInfectionsBySingleAgeTag : 
        gb_shape('AM_NewInfectionsBySingleAgeTag', type='3D int', 
            dim=[gb_sex_dim, gb_single_age_dim, gb_year_dim], 
            indices=[gb_sex_indices, gb_single_age_indices, gb_year_indices],
            has_default=False
        ),

    AM_NewlyOnARTTag : 
        gb_shape('AM_NewlyOnARTTag', type='5D float', 
            dim=[dp_time_steps_dim, gb_sex_dim, gb_5y_age_dim, dp_HIV_status_dim, gb_year_dim], 
            indices=[dp_time_steps_indices, gb_sex_indices, gb_5y_age_indices, dp_HIV_status_indices, gb_year_indices],
            has_default=False
        ),

    AM_ViralSupprPhi_TempTag : 
        gb_shape('AM_ViralSupprPhi_TempTag', type='2D float', 
            dim=[dp_regions_dim, dp_sample_sizes_2_dim], 
            indices=[dp_regions_indices, dp_sample_sizes_2_indices],
            has_default=False
        ),

    AM_SexuallyActive15to19Tag : 
        gb_shape('AM_SexuallyActive15to19Tag', type='dict', 
            innerShape = {
                'value' : gb_shape('', 'float'),
                'str'   : gb_shape('', 'str')
            },
            has_default=True,
            has_country=True
        ),

    AM_SexuallyActive15to19_MetaTag : 
        gb_shape('AM_SexuallyActive15to19_MetaTag', type='dict', 
            innerShape = {
                'default' : 
                    gb_shape('', 'dict',
                        innerShape = {
                            'value' : gb_shape('', 'float'),
                            'str'   : gb_shape('', 'str')  
                        }
                    ),
            },
            has_default=True,
            has_country=True
        ),

    AM_ReadFRR15_19Coefs_TempTag : 
        gb_shape('AM_ReadFRR15_19Coefs_TempTag', type='1D float', 
            dim=[dp_15_19_coefficients_dim], 
            indices=[dp_15_19_coefficients_indices],
            has_default=False
        ),

    AM_TFR15_19DefaultDataTag : 
        gb_shape('AM_TFR15_19DefaultDataTag', type='1D float', 
            dim=[dp_regions_dim], 
            indices=[dp_regions_indices],
            has_default=True,
            has_country=True
        ),

    AM_FRRFitXMLDefaultDataTag : 
        gb_shape('AM_FRRFitXMLDefaultDataTag', type='dict', 
            innerShape = {
                'value': 
                    gb_shape('AM_FRRFitXMLDefaultDataTag', type='2D float',
                        dim=[dp_percent_or_number_dim, gb_year_dim], 
                        indices=[dp_regions_indices, gb_year_indices],
                    ),
                'fileExists': gb_shape('AM_FRRFitXMLDefaultDataTag', type='bool'),
            },
            has_default=False
        ),

    AM_HAARTBySexPerNumTag : 
        gb_shape('AM_HAARTBySexPerNumTag', type='2D int', 
            dim=[gb_sex_dim, gb_year_dim], 
            indices=[gb_sex_indices, gb_year_indices],
            has_default=True, has_easy_aim=True
        ),

    AM_AdultARTAdjFactorTag : 
        gb_shape('AM_AdultARTAdjFactorTag', type='2D int', 
            dim=[gb_sex_dim, gb_year_dim], 
            indices=[gb_sex_indices, gb_year_indices],
            has_default=False
        ),

    AM_AdultARTAdjFactorFlagTag : gb_shape('AM_AdultARTAdjFactorFlagTag', type='bool', has_default=False),

    AM_AdultPatsAllocToFromOtherRegionTag : 
        gb_shape('AM_AdultPatsAllocToFromOtherRegion_V1', type='2D int', 
            dim=[gb_sex_dim, gb_year_dim], 
            indices=[gb_sex_indices, gb_year_indices],
            has_default=False
        ),

    AM_KnowledgeOfStatusFileTitleTag : gb_shape('AM_KnowledgeOfStatusFileTitleTag', type='str', has_default=False),

    AM_CascadeActiveTag : gb_shape('AM_CascadeActiveTag', type='bool', has_default=False),

    AM_PMTCTEffRegTag : 
        gb_shape('AM_PMTCTEffRegTag', type='1D int', 
            dim=[gb_year_dim], 
            indices=[gb_year_indices],
            has_default=False
        ),

    AM_HIVPosBFWomen3MonthsTag : 
        gb_shape('AM_HIVPosBFWomen3MonthsTag', type='1D int', 
            dim=[gb_year_dim], 
            indices=[gb_year_indices],
            has_default=False
        ),

    AM_HIVPosBFWomen12MonthsTag : 
        gb_shape('AM_HIVPosBFWomen12MonthsTag', type='1D int', 
            dim=[gb_year_dim], 
            indices=[gb_year_indices],
            has_default=False
        ),

    AM_AIDSDeathsNoIntervTag : 
        gb_shape('AM_AIDSDeathsNoIntervTag', type='2D float', 
            dim=[gb_single_age_child_4_dim, gb_year_dim], 
            indices=[gb_single_age_child_4_indices, gb_year_indices],
            has_default=False
        ),

    AM_DeathsAvertARTTag : 
        gb_shape('AM_DeathsAvertARTTag', type='1D int', 
            dim=[gb_year_dim], 
            indices=[gb_year_indices],
            has_default=False
        ),

    AM_InfectAvertPMTCTTag : 
        gb_shape('AM_InfectAvertPMTCTTag', type='1D int', 
            dim=[gb_year_dim], 
            indices=[gb_year_indices],
            has_default=False
        ),

    AM_LifeYearsGainedTag : 
        gb_shape('AM_LifeYearsGainedTag', type='1D int', 
            dim=[gb_year_dim], 
            indices=[gb_year_indices],
            has_default=False
        ),

    AM_ChildDeathsAvertARTTag : 
        gb_shape('AM_ChildDeathsAvertARTTag', type='2D float', 
            dim=[gb_single_age_child_4_dim, gb_year_dim], 
            indices=[gb_single_age_child_4_indices, gb_year_indices],
            has_default=False
        ),

    AM_DeathsAvertCotrimTag : 
        gb_shape('AM_DeathsAvertCotrimTag', type='2D float', 
            dim=[gb_single_age_child_4_dim, gb_year_dim], 
            indices=[gb_single_age_child_4_indices, gb_year_indices],
            has_default=False
        ),

    AM_DeathsAvertPMTCTTag : 
        gb_shape('AM_DeathsAvertPMTCTTag', type='2D float', 
            dim=[gb_single_age_child_4_dim, gb_year_dim], 
            indices=[gb_single_age_child_4_indices, gb_year_indices],
            has_default=False
        ),

    AM_HIVAgingRateTag : 
        gb_shape('AM_HIVAgingRateTag', type='4D float', 
            dim=[gb_sex_dim, gb_5y_age_dim, gb_single_age_child_4_dim, gb_year_dim], 
            indices=[gb_sex_indices, gb_5y_age_indices, gb_single_age_child_4_indices, gb_year_indices],
            has_default=False
        ),

    AM_HIVChildNoARTByInfectionTag : 
        gb_shape('AM_HIVChildNoARTByInfectionTag', type='4D float', 
            dim=[gb_sex_dim, gb_single_age_child_dim, dp_HIV_acquisition_dim, gb_year_dim], 
            indices=[gb_sex_indices, gb_single_age_child_indices, dp_HIV_acquisition_indices, gb_year_indices],
            has_default=False
        ),

    AM_TreatPercentTag : 
        gb_shape('AM_TreatPercentTag', type='2D float', 
            dim=[dp_ART_regimen_PMTCT_costing_dim, gb_year_dim], 
            indices=[dp_ART_regimen_PMTCT_costing_indices, gb_year_indices],
            has_default=False
        ),

    AM_MedianCD4Tag : 
        gb_shape('AM_MedianCD4Tag', type='1D int', 
            dim=[gb_year_dim], 
            indices=[gb_year_indices],
            has_default=False
        ),

    AM_AIDSMortAllAgesFYrAdjIdxTag : gb_shape('AM_AIDSMortAllAgesFYrAdjIdxTag', type='int', has_default=False),
    
    AM_ValidationNumberOnARTByAgeTag : 
        gb_shape('AM_ValidationNumberOnARTByAgeTag', type='dict', 
            innerShape={
                'sexValue'     : gb_shape('', type='int'),
                'yearIdxValue' : gb_shape('', type='int'),
            },
            has_default=False
        ),

    AM_ValidationNewlyOnARTTag : 
        gb_shape('AM_ValidationNewlyOnARTTag', type='dict', 
            innerShape={
                'sexValue'     : gb_shape('', type='int'),
                'yearIdxValue' : gb_shape('', type='int'),
            },
            has_default=False
        ),


    AM_ValidationMortalityRateByAgeTag : 
        gb_shape('AM_ValidationMortalityRateByAgeTag', type='dict', 
            innerShape={
                'sexValue'     : gb_shape('', type='int'),
                'yearIdxValue' : gb_shape('', type='int'),
            },
            has_default=False
        ),


    AM_ValidationAIDSMortalityByAgeTag : 
        gb_shape('AM_ValidationAIDSMortalityByAgeTag', type='dict', 
            innerShape={
                'sexValue'     : gb_shape('', type='int'),
                'yearIdxValue' : gb_shape('', type='int'),
            },
            has_default=False
        ),


    AM_ValidationAllCausesMortalityByAgeTag : 
        gb_shape('AM_ValidationAllCausesMortalityByAgeTag', type='dict', 
            innerShape={
                'sexValue'     : gb_shape('', type='int'),
                'yearIdxValue' : gb_shape('', type='int'),
            },
            has_default=False
        ),

    AM_ValidationPrevalenceSelectionTag : 
        gb_shape('AM_ValidationPrevalenceSelectionTag', type='dict', 
            innerShape={
                'sexValue'    : gb_shape('', type='int'),
                'surveyValue' : gb_shape('', type='int'),
            },
            has_default=False
        ),

    AM_ValidationARTCoverageSelectionTag : 
        gb_shape('AM_ValidationARTCoverageSelectionTag', type='dict', 
            innerShape={
                'sexValue'      : gb_shape('', type='int'),
                'surveyValue'   : gb_shape('', type='int'),
                'ageGroupValue' : gb_shape('', type='int'),
            },
            has_default=False
        ),

    AM_ValidationAllCauseDeathsARTTag : 
        gb_shape('AM_ValidationAllCauseDeathsARTTag', type='1D int',
            dim=[gb_year_dim], 
            indices=[gb_year_indices],
            has_default=False
        ),

    AM_ValidationWaterfallTag : 
        gb_shape('AM_ValidationWaterfallTag', type='1D dict', 
            dim=[gb_year_dim], 
            indices=[gb_year_indices],
            innerShape={
                'NewlyOnART'  : gb_shape('', type='int'),  
                'ReEngaged'   : gb_shape('', type='int'),    
                'Died'        : gb_shape('', type='int'),        
                'Interrupted' : gb_shape('', type='int'),  
            },
            has_default=False
        ),
    
    AM_PercART50PlusTag : 
        gb_shape('AM_PercART50PlusTag', type='2D int', 
            dim=[gb_sex_dim, gb_year_dim], 
            indices=[gb_sex_indices, gb_year_indices],
            has_default=False
        ),

    AM_Prop350_500Tag : gb_shape('AM_Prop350_500Tag', type='int', has_default=False),

    AM_IncidenceAdjustmentFactorTag : 
        gb_shape('AM_IncidenceAdjustmentFactorTag', type='1D int', 
            dim=[gb_year_dim], 
            indices=[gb_year_indices],
            has_default=False
        ),

    AM_ECDCFQNameTag : gb_shape('AM_ECDCFQNameTag', type='str', has_default=False),

    AM_NewARTPatAllocTag : 
        gb_shape('AM_NewARTPatAllocTag', type='1D float', 
            dim=[dp_advanced_opt_new_ART_patient_alloc_method_dim], 
            indices=[dp_advanced_opt_new_ART_patient_alloc_method_indices],
            has_default=True, 
            has_easy_aim=True
        ),

    AM_NewARTPatAlloc_MetaTag : 
        gb_shape('AM_NewARTPatAlloc_MetaTag', type='dict', 
            innerShape={
                'default' : 
                    gb_shape('', type='float',
                        dim=[dp_advanced_opt_new_ART_patient_alloc_method_dim], 
                        indices=[dp_advanced_opt_new_ART_patient_alloc_method_indices],
                    ),
            },
            has_default=True,
            has_easy_aim=True
        ),

    AM_NewARTPatAllocMethodTag : gb_shape('AM_NewARTPatAllocMethodTag', type='int', has_default=True, has_easy_aim=True),

    AM_DefaultEpidemicTag : gb_shape('AM_DefaultEpidemicTag', type='int', has_default=False),

    AM_FirstYearOfEpidemicTag : gb_shape('AM_FirstYearOfEpidemicTag', type='int', has_default=False),
    
    AM_ResNonAIDSDeathsHIVPopNoARTTag : 
        gb_shape('AM_ResNonAIDSDeathsHIVPopNoARTTag', type='3D int', 
            dim=[gb_sex_dim, gb_single_age_dim, gb_year_dim], 
            indices=[gb_sex_indices, gb_single_age_indices, gb_year_indices],
            has_default=False
        ),



    AM_ResMTCTBySourceTag : 
        gb_shape('AM_ResMTCTBySourceTag', type='3D float', 
            dim=[dp_PMTCT_2_dim, dp_MTCT_dim, gb_year_dim], 
            indices=[dp_PMTCT_2_indices, dp_MTCT_indices, gb_year_indices],
            has_default=False
        ),

    AM_ResDetailedTreatmentCascadeTag : 
        gb_shape('AM_ResDetailedTreatmentCascadeTag', type='3D float', 
            dim=[DP_Cas_dim, DP_DetCas_dim, gb_year_dim], 
            indices=[DP_Cas_indices, DP_DetCas_indices, gb_year_indices],
            has_default=False
        ),

    AM_ResTreatmentCascadeTag : 
        gb_shape('AM_ResTreatmentCascadeTag', type='4D float', 
            dim=[DP_Cas_AG_dim, DP_Cas_IND_dim, DP_Cas_dim, gb_year_dim], 
            indices=[DP_Cas_AG_indices, DP_Cas_IND_indices, DP_Cas_indices, gb_year_indices],
            has_default=False
        ),

    AM_ResPerinatallyInf15_19Tag : 
        gb_shape('AM_ResPerinatallyInf15_19Tag', type='2D int', 
            dim=[gb_sex_dim, gb_year_dim], 
            indices=[gb_sex_indices, gb_year_indices],
            has_default=False
        ),

    AM_ResPerinatallyInf20_24Tag : 
        gb_shape('AM_ResPerinatallyInf20_24Tag', type='2D int', 
            dim=[gb_sex_dim, gb_year_dim], 
            indices=[gb_sex_indices, gb_year_indices],
            has_default=False
        ),

    AM_ResQALYsTag : 
        gb_shape('AM_ResQALYsTag', type='1D int', 
            dim=[gb_year_dim], 
            indices=[gb_year_indices],
            has_default=False
        ),

    AM_ResDALYsAIDSOnlyTag : 
        gb_shape('AM_ResDALYsAIDSOnlyTag', type='1D int', 
            dim=[gb_year_dim], 
            indices=[gb_year_indices],
            has_default=False
        ),

    AM_ResDALYsTag : 
        gb_shape('AM_ResDALYsTag', type='1D int', 
            dim=[gb_year_dim], 
            indices=[gb_year_indices],
            has_default=False
        ),

    AM_ResYLDTag : 
        gb_shape('AM_ResYLDTag', type='1D int', 
            dim=[gb_year_dim], 
            indices=[gb_year_indices],
            has_default=False
        ),

    AM_ResNonAIDSDeathsHIVPopARTTag : 
        gb_shape('AM_ResNonAIDSDeathsHIVPopARTTag', type='3D int', 
            dim=[gb_sex_dim, gb_single_age_dim, gb_year_dim], 
            indices=[gb_sex_indices, gb_single_age_indices, gb_year_indices],
            has_default=False
        ),

    AM_ResTotalDeathsHIVPopTag : 
        gb_shape('AM_ResTotalDeathsHIVPopTag', type='3D int', 
            dim=[gb_sex_dim, gb_single_age_dim, gb_year_dim], 
            indices=[gb_sex_indices, gb_single_age_indices, gb_year_indices],
            has_default=False
        ),

    AM_ResAIDS45q15Tag : 
        gb_shape('AM_ResAIDS45q15Tag', type='1D int', 
            dim=[gb_year_dim], 
            indices=[gb_year_indices],
            has_default=False
        ),

    AM_ResNonAIDS45q15Tag : 
        gb_shape('AM_ResNonAIDS45q15Tag', type='1D int', 
            dim=[gb_year_dim], 
            indices=[gb_year_indices],
            has_default=False
        ),

    # mark next 9 new
    AM_ResNumWithAHDTag : 
        gb_shape('AM_ResNumWithAHD_V1', type='2D int', 
            dim=[gb_sex_dim, gb_year_dim], 
            indices=[gb_sex_indices, gb_year_indices],
            has_default=False
        ),     

    AM_ResNumWithAHDOnARTTag : 
        gb_shape('<AM_ResNumWithAHDOnART_V1', type='2D int', 
            dim=[gb_sex_dim, gb_year_dim], 
            indices=[gb_sex_indices, gb_year_indices],
            has_default=False
        ),

    AM_ResNumWithAHDNoARTTag : 
        gb_shape('<AM_ResNumWithAHDNoART_V1', type='2D int', 
            dim=[gb_sex_dim, gb_year_dim], 
            indices=[gb_sex_indices, gb_year_indices],
            has_default=False
        ),

    AM_Res15PlusNumWithCryptoAntigenemiaTag : 
        gb_shape('<AM_Res15PlusNumWithCryptoAntigenemia_V1', type='2D int', 
            dim=[gb_sex_dim, gb_year_dim], 
            indices=[gb_sex_indices, gb_year_indices],
            has_default=False
        ),

    AM_Res15PlusNumWithCryptoMeningitisTag : 
        gb_shape('<AM_Res15PlusNumWithCryptoMeningitis_V1', type='2D int', 
            dim=[gb_sex_dim, gb_year_dim], 
            indices=[gb_sex_indices, gb_year_indices],
            has_default=False
        ),

    AM_Res15PlusDeathsToPLHIVFromCMTag : 
        gb_shape('<AM_Res15PlusDeathsToPLHIVFromCM_V1', type='2D int', 
            dim=[gb_sex_dim, gb_year_dim], 
            indices=[gb_sex_indices, gb_year_indices],
            has_default=False
        ),

    AM_Res15PlusPercAIDSDeathsFromCMTag : 
        gb_shape('<AM_Res15PlusPercAIDSDeathsFromCM_V1', type='2D int', 
            dim=[gb_sex_dim, gb_year_dim], 
            indices=[gb_sex_indices, gb_year_indices],
            has_default=False
        ),

    AM_ResOnARTgt1Yr15PlusTag : 
        gb_shape('<AM_OnARTgt1Yr15Plus_V1', type='2D int', 
            dim=[gb_sex_dim, gb_year_dim], 
            indices=[gb_sex_indices, gb_year_indices],
            has_default=False
        ),

    AM_ResOnARTlt1Yr15PlusTag : 
        gb_shape('<AM_OnARTlt1Yr15Plus_V1', type='2D int',
            dim=[gb_sex_dim, gb_year_dim], 
            indices=[gb_sex_indices, gb_year_indices],
            has_default=False
        ),

    AM_ChildARTAdjFactorTag : 
        gb_shape('AM_ChildARTAdjFactorTag', type='1D float', 
            dim=[gb_year_dim], 
            indices=[gb_year_indices],
            has_default=False
        ),

    AM_ChildARTAdjFactorFlagTag : gb_shape('AM_ChildARTAdjFactorFlagTag', type='bool', has_default=False),

    # mark new
    AM_ChildPatsAllocToFromOtherRegionTag : 
        gb_shape('AM_ChildPatsAllocToFromOtherRegion_V1', type='1D int', 
            dim=[gb_year_dim], 
            indices=[gb_year_indices],
            has_default=False
        ),

    # new
    AM_CSAVRModelFitTypesTag :
        gb_shape('AM_CSAVRModelFitTypesTag', type='1D bool', 
            dim=[dp_CSAVR_fit_types_dim], 
            indices=[dp_CSAVR_fit_types_indices],
            has_default=False
        ),

    AM_CSAVRIncidenceByFitTag :
        gb_shape('AM_CSAVRIncidenceByFitTag', type='2D float', 
            dim=[dp_CSAVR_fit_types_dim, gb_year_dim], 
            indices=[dp_CSAVR_fit_types_indices, gb_year_indices],
            has_default=False
        ),
        
    AM_PMTCTPrEPParametersTag : gb_shape('AM_PMTCTPrEPParametersTag', 
            type='dict', 
            innerShape={
                
                "adherence":  gb_shape('adherence', 
                    type='dict', 
                    innerShape={
                        "oral": gb_shape('oral', type='float'),
                        "longActing": gb_shape('longActing', type='float'),
                    }),
                "selection":  gb_shape('selection', 
                    type='dict', 
                    innerShape={
                        # Ratio of incidence among those receiving PrEP to all pregnant and breastfeeding women
                        "incidenceRatio": gb_shape('injectable', type='float')
                    }),
                # Person-years of PrEP per person receiving any PrEP during pregnancy and breastfeeding
                "personYearsPrEP":gb_shape('personYearsPrEP', 
                    type='dict', 
                    innerShape={
                        "oral":  gb_shape('oral', type='float'),
                        "injectable": gb_shape('injectable', type='float')
                    })
            }
    ),
    AM_PMTCTReceivingOralPrEPTag : gb_shape('AM_PMTCTReceivingOralPrEP', type='1D float', 
                                            dim=[gb_year_dim], indices=[gb_year_indices], 
                                            has_default=False),
    AM_PMTCTReceivingInjectablePrEPTag : gb_shape('AM_PMTCTReceivingInjectablePrEP', type='1D float', 
                                                  dim=[gb_year_dim], indices=[gb_year_indices], 
                                                  has_default=False)

}