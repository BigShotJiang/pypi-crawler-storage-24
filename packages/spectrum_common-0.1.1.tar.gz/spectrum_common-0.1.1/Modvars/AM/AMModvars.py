from os import environ

from SpectrumCommon.Const.GB import *
from SpectrumCommon.Const.AM import *
from SpectrumCommon.Util.AM.AMUtil import GetDefaultRegionCode
# from ...DP.DATA.DPModvarDef import *
from .AMModvarDef import *
from .AMUtil import getDefaultEpidemicConst
from AvenirCommon.Util import formatCountryFName, GBGetKeyValue
from AvenirCommon.Database import GB_get_db_json, GB_file_exists
from ..GB.GBDefs import *
from .AMPreventionNeeds import *
# AM modvar creates


def init_modvars(countryID, first_year, final_year, extra):
    subnatCode = GBGetKeyValue(extra, 'subNatCode', 0)
        
    connection = environ[GB_SPECT_MOD_DATA_CONN_ENV]
    
    easyAIMCountryName = formatCountryFName(countryID, AMEasyAIMDatabaseVersion)#, subnatCode)
    
    if GB_file_exists(connection, 'aim', 'easyAIM/' + easyAIMCountryName):
        easyAIMData = GB_get_db_json(connection, 'aim', 'easyAIM/' + easyAIMCountryName) 
    else:
        easyAIMData = {}
        
    countryName = formatCountryFName(countryID, AMDatabaseVersion)#, subnatCode)
    if GB_file_exists(connection, 'aim', 'country/' + countryName):
        AMCountryData = GB_get_db_json(connection, 'aim', 'country/' +countryName) 
    else:
        AMCountryData = {}

    
    subnatName = formatCountryFName(countryID, AMDatabaseVersion, subnatCode)
    if GB_file_exists(connection, 'aim', 'country/' + subnatName):
        AMSubnatData = GB_get_db_json(connection, 'aim', 'country/' +subnatName) 
    else:
        AMSubnatData = {}

    initialConditionsCountryName = formatCountryFName(countryID, DPInitialConditionsDBVersion)#, subnatCode)
    if GB_file_exists(connection, 'demproj', DPInitialConditionsDBSubDir + initialConditionsCountryName):
        InitialConditionsDB = GB_get_db_json(connection, 'demproj', DPInitialConditionsDBSubDir + initialConditionsCountryName) 
    else:
        InitialConditionsDB = {}

    AMGlobalData = GB_get_db_json(connection, 'aim', formatCountryFName('AM_Global', AMDatabaseVersion)) 

    region = GetDefaultRegionCode(countryID)    
    
    CSAVRCountryName = formatCountryFName(countryID, AMCSAVRDatabaseVersion)
    CSAVRGlobalName = formatCountryFName('Global', AMCSAVRDatabaseVersion)
    # country-level data
    if GB_file_exists(connection, 'aim', 'CSAVR/' + CSAVRCountryName):                                      
        CSAVRData = GB_get_db_json(connection, 'aim', 'CSAVR/' + CSAVRCountryName) 
    # if no country data, get global
    elif GB_file_exists(connection, 'aim', 'CSAVR/' + CSAVRGlobalName):
        CSAVRData = GB_get_db_json(connection, 'aim', 'CSAVR/' + CSAVRGlobalName)
    # if global is somehow missing, return empty dict
    else:
        CSAVRData = {}
        
    prevNeededName = f'PreventionNeedsDB/{countryID}_{AMPreventionsNeedsVersion}.JSON'
    if GB_file_exists(connection, 'aim', prevNeededName):        
        PreventionNeedsDB = GB_get_db_json(connection, 'aim', prevNeededName)   
    else:
        PreventionNeedsDB = {}

    projInfo = {
        'firstYr'           : first_year,
        'finalYr'           : final_year,
        'firstYrIdx'        : 0,
        'finalYrIdx'        : final_year - first_year,
        'subnatCode'        : GBGetKeyValue(extra, 'subNatCode', 0),
        'region'            : GBGetKeyValue(extra, 'region', region),
        'defaultEpidemic'   : getDefaultEpidemicConst(AMCountryData),
        'epidemicStartYr'   : 1980,
    }
    if 'EpidemicStartYear' in AMCountryData:
        projInfo['epidemicStartYr'] = AMCountryData['EpidemicStartYear']['Start year']

    # let the caller override epidemic start year
    if 'epidemicStartYr' in extra:
        projInfo['epidemicStartYr'] = extra['epidemicStartYr']

    incidenceByFit = IncidenceByFit_Init(projInfo, easyAIMData)
    ARVRegimen = ARVRegimen_Init(projInfo, easyAIMData)

    MVs = {
        AM_InitialConditionsTag : AM_InitialConditions_Init(projInfo, InitialConditionsDB),

        AM_DataSourceTag : '' if easyAIMData == {} else extra['countryDetails']['sources']['AMSource'],
        AM_AMSourcesTag : AMSources_Init(countryID),
        AM_ChangesLogTag : [],
        
        AM_CD4ThreshHoldTag : CD4ThreshHold_Init(projInfo),
        AM_PopsEligTreatTag : PopsEligTreat_Init(easyAIMData),
        AM_AgeHIVChildOnTreatmentTag : AgeHIVChildOnTreatment_Init(projInfo),
        AM_CD4ThreshHoldAdultsTag : CD4ThreshHoldAdults_Init(projInfo),
        AM_InfantFeedingOptionsTag : InfantFeedingOptions_Init(projInfo, easyAIMData, AMGlobalData),
        AM_InfantFeedingOptions_MetaTag : InfantFeedingOptions_Meta_Init(projInfo, AMCountryData, AMGlobalData),
        AM_ARVRegimenTag : ARVRegimen.tolist(),
        AM_ARVRegimen_MetaTag:  {'default': ARVRegimen.tolist()},
        AM_PatientsReallocatedTag : getList_year(projInfo['finalYrIdx']),
        AM_PercentARTDeliveryTag : PercentARTDelivery_Init(projInfo),
        AM_PregTermAbortionPerNumTag : getList_year(projInfo['finalYrIdx']),
        AM_PregTermAbortionTag : getList_year(projInfo['finalYrIdx']),
        AM_MedCD4CountInitTag : getList_year(projInfo['finalYrIdx']),
        AM_PercInterruptedTag : PercLostFollowup_Init(projInfo, easyAIMData), 
        AM_NumberInitTreatmentReinitsTag : getList_year(projInfo['finalYrIdx']),
        AM_NumNewlyInitARTTag : NumNewlyInitART_Init(projInfo),
        AM_PercInterruptedChildTag : getList_year(projInfo['finalYrIdx']),
        AM_NumberInitTreatmentReinitsChildTag : getList_year(projInfo['finalYrIdx']),
        AM_NumNewlyInitARTChildTag : getList_year(projInfo['finalYrIdx']),
        AM_HAARTBySexTag : HAARTBySex_Init(projInfo, easyAIMData),
        AM_CD4CoverageTag : CD4Coverage_Init(projInfo),    
        AM_ARTByAgeInputTypeTag : ARTByAge5YearAG,
        AM_ARTByAge5YearAGTag : getList_sex_5yrAge_year(projInfo['finalYrIdx']),
        AM_ARTByAgeGAMAGTag : ARTByAgeGAMAG_Init(projInfo),
        AM_CovPopsEligTreatTag : CovPopsEligTreat_Init(projInfo),
        AM_ChildTreatInputsTag : ChildTreatInputs_Init(projInfo, easyAIMData),
        AM_ChildARTByAgeGroupPerNumTag : ChildARTByAgeGroupPerNum_Init(projInfo, easyAIMData),
        AM_ANCTestingValuesTag : ANCTestingValues_Init(projInfo),
        AM_NewInfectionsLessImmigrantsTag : getList_sex_singleAge_year(projInfo['finalYrIdx']),
        AM_HIVTestingTag : HIVTesting_Init(projInfo),
        AM_HIVTestingHTSTestsByAgeTag : np.full((GB_Female + 1, DP_GAMAG_A50Plus + 1, projInfo['finalYrIdx'] + 1), DPNotAvail).tolist(),
        AM_Shiny90SurveyDataTag : [],
        AM_Shiny90SurveyData_MetaTag : Shiny90SurveyData_Meta_Init(),
        AM_Shiny90ProgramDataTag : [],
        AM_Shiny90ProgramData_MetaTag : Shiny90ProgramData_Meta_Init(),
        AM_Shiny90AIDSDeathsFYearTag : 0,
        AM_Shiny90PopTag : np.zeros((DP_D_HIVPos + 1, GB_Female + 1, DP_S90_15Plus + 1, DP_UpperBound + 1, projInfo['finalYrIdx'] + 1)).tolist(),
        AM_Shiny90NumTestsTag : np.zeros((DP_D_HIVPos + 1, GB_Female + 1, DP_S90_15Plus + 1, DP_UpperBound + 1, projInfo['finalYrIdx'] + 1)).tolist(),
        AM_Shiny90NumTested12MTag : np.zeros((DP_D_HIVPos + 1, GB_Female + 1, DP_S90_15Plus + 1, DP_UpperBound + 1, projInfo['finalYrIdx'] + 1)).tolist(),
        AM_Shiny90TotalTestsTag : np.zeros((DP_D_HIVPos + 1, GB_Female + 1, DP_S90_15Plus + 1, DP_UpperBound + 1, projInfo['finalYrIdx'] + 1)).tolist(),
        AM_Shiny90EverTestedTag : np.zeros((DP_D_HIVPos + 1, GB_Female + 1, DP_S90_15Plus + 1, DP_UpperBound + 1, projInfo['finalYrIdx'] + 1)).tolist(),
        AM_Shiny90DiagnosedTag : np.zeros((DP_D_HIVPos + 1, GB_Female + 1, DP_S90_15Plus + 1, DP_UpperBound + 1, projInfo['finalYrIdx'] + 1)).tolist(),
        AM_Shiny90NumAwareTag : np.zeros((DP_D_HIVPos + 1, GB_Female + 1, DP_S90_15Plus + 1, DP_UpperBound + 1, projInfo['finalYrIdx'] + 1)).tolist(),
        AM_Shiny90NumDiagnosesTag : np.zeros((DP_D_HIVPos + 1, GB_Female + 1, DP_S90_15Plus + 1, DP_UpperBound + 1, projInfo['finalYrIdx'] + 1)).tolist(),
        AM_Shiny90NumDiagnosesModTag : np.zeros((DP_D_HIVPos + 1, GB_Female + 1, DP_S90_15Plus + 1, DP_UpperBound + 1, projInfo['finalYrIdx'] + 1)).tolist(),
        AM_Shiny90NumLateDiagnosesTag : np.zeros((DP_D_HIVPos + 1, GB_Female + 1, DP_S90_15Plus + 1, DP_UpperBound + 1, projInfo['finalYrIdx'] + 1)).tolist(),
        AM_Shiny90NotDiagHIV1YrTag : np.zeros((DP_D_HIVPos + 1, GB_Female + 1, DP_S90_15Plus + 1, DP_UpperBound + 1, projInfo['finalYrIdx'] + 1)).tolist(),
        AM_Shiny90NumFirstTestHIVNeg_Tag : np.zeros((DP_D_HIVPos + 1, GB_Female + 1, DP_S90_15Plus + 1, DP_UpperBound + 1, projInfo['finalYrIdx'] + 1)).tolist(),            
        AM_Shiny90NumReTestHIVNeg_Tag : np.zeros((DP_D_HIVPos + 1, GB_Female + 1, DP_S90_15Plus + 1, DP_UpperBound + 1, projInfo['finalYrIdx'] + 1)).tolist(),               
        AM_Shiny90NumRetestPLHIVOnART_Tag : np.zeros((DP_D_HIVPos + 1, GB_Female + 1, DP_S90_15Plus + 1, DP_UpperBound + 1, projInfo['finalYrIdx'] + 1)).tolist(),           
        AM_Shiny90NumRetestPLHIVNoART_Tag : np.zeros((DP_D_HIVPos + 1, GB_Female + 1, DP_S90_15Plus + 1, DP_UpperBound + 1, projInfo['finalYrIdx'] + 1)).tolist(),           
        AM_Shiny90NumNewDiagnoses_Tag : np.zeros((DP_D_HIVPos + 1, GB_Female + 1, DP_S90_15Plus + 1, DP_UpperBound + 1, projInfo['finalYrIdx'] + 1)).tolist(),               
        AM_Shiny90PosRate_Tag : np.zeros((DP_D_HIVPos + 1, GB_Female + 1, DP_S90_15Plus + 1, DP_UpperBound + 1, projInfo['finalYrIdx'] + 1)).tolist(),                       
        AM_Shiny90YieldNewDiagn_Tag : np.zeros((DP_D_HIVPos + 1, GB_Female + 1, DP_S90_15Plus + 1, DP_UpperBound + 1, projInfo['finalYrIdx'] + 1)).tolist(),
        AM_Shiny90IsFittedTag : False,

        AM_KnowledgeOfStatusInputTypeTag : DP_KoS_CaseReps,
        AM_KnowledgeOfStatusInputTag : np.zeros((DP_Cas_AG_AdultFemale + 1, projInfo['finalYrIdx'] + 1)).tolist(),
        AM_KOSNewDiagnosesChildren0t14Tag : getList_year(projInfo['finalYrIdx'], DPNotAvail),
        AM_KOSNewDiagnosesAdults15PlusTag : getList_year(projInfo['finalYrIdx'], DPNotAvail),
        AM_KOSNewDiagnosesRecCD4TestTag : getList_year(projInfo['finalYrIdx'], DPNotAvail),
        AM_ViralSuppressionInputTypeTag : 0,
        AM_ViralSuppressionInputTag : np.full((DP_Cas_AG_AdultFemale + 1, DP_VS_PLHIVSuppressed + 1, projInfo['finalYrIdx'] + 1), DPNotAvail).tolist(),
        AM_ViralSuppressionThresholdTag : np.full(projInfo['finalYrIdx'] + 1, 1000).tolist(),
        AM_ChildAnnRateProgressLowerCD4Tag : ChildAnnRateProgressLowerCD4_Init(AMGlobalData),
        AM_ChildDistNewInfectionsCD4Tag : ChildDistNewInfectionsCD4_Init(),
        AM_ChildMortByCD4NoARTTag : ChildMortByCD4NoART_Init(),
        AM_ChildMortalityRatesTag : ChildMortalityRates_Init(projInfo, AMGlobalData),
        AM_ChildMortalityRates_MetaTag : {'default': ChildMortalityRates_Meta_Init(projInfo, AMGlobalData)},
        AM_ChildMortalityRatesMultiplierTag : 1,
        AM_ChildMortByCD4WithART0to6Tag : ChildMortByCD4WithART0to6_Init(projInfo, AMGlobalData['ChildMortByCD4WithART0to6Count']), 
        AM_ChildMortByCD4WithART0to6_MetaTag :  {'default' : AMGlobalData['ChildMortByCD4WithART0to6Count']},
        AM_ChildMortByCD4WithART0to6PercTag : ChildMortByCD4WithART0to6Perc_Init(projInfo, AMGlobalData['ChildMortByCD4WithART0to6Perc']),
        AM_ChildMortByCD4WithART0to6Perc_MetaTag :  {'default': AMGlobalData['ChildMortByCD4WithART0to6Perc']},
        AM_ChildMortByCD4WithART7to12Tag : ChildMortByCD4WithART7to12_Init(projInfo, AMGlobalData['ChildMortByCD4WithART7to12Count']),
        AM_ChildMortByCD4WithART7to12_MetaTag :  {'default': AMGlobalData['ChildMortByCD4WithART7to12Count']},
        AM_ChildMortByCD4WithART7to12PercTag : ChildMortByCD4WithART7to12Perc_Init(projInfo, AMGlobalData['ChildMortByCD4WithART7to12Perc']),
        AM_ChildMortByCD4WithART7to12Perc_MetaTag :  {'default': AMGlobalData['ChildMortByCD4WithART7to12Perc']},
        AM_ChildMortByCD4WithARTGT12Tag : ChildMortByCD4WithARTGT12_Init(projInfo, AMGlobalData['ChildMortByCD4WithARTGT12Count']),
        AM_ChildMortByCD4WithARTGT12_MetaTag :  {'default': AMGlobalData['ChildMortByCD4WithARTGT12Count']},
        AM_ChildMortByCD4WithARTGT12PercTag : ChildMortByCD4WithARTGT12Perc_Init(projInfo, AMGlobalData['ChildMortByCD4WithARTGT12Perc']),
        AM_ChildMortByCD4WithARTGT12Perc_MetaTag :  {'default': AMGlobalData['ChildMortByCD4WithARTGT12Perc']},
        AM_ChildARTDistTag : ChildARTDist_Init(projInfo, AMGlobalData),
        AM_ChildARTDist_MetaTag :  {'default': ChildARTDist_Meta_Init(projInfo, AMGlobalData)},
        AM_EffectTreatChildTag : EffectTreatChild_Init(),
        AM_ChildWeightBandsTag : ChildWeightBands_Init(AMGlobalData),
        AM_AdultAnnRateProgressLowerCD4Tag : AdultAnnRateProgressLowerCD4_Init(projInfo, AMGlobalData),
        AM_AdultAnnRateProgressLowerCD4_MetaTag : {'default': AdultAnnRateProgressLowerCD4_Meta_Init(projInfo, AMGlobalData)},
        AM_AdultDistNewInfectionsCD4Tag : AdultDistNewInfectionsCD4_Init(projInfo, AMGlobalData['InitialCD4CountByRegion']),
        AM_AdultDistNewInfectionsCD4_MetaTag :  {'default': AMGlobalData['InitialCD4CountByRegion']},
        AM_AdultMortByCD4NoARTTag : AdultMortByCD4NoART_Init(projInfo, AMGlobalData['MortalityNoARTByRegion']),
        AM_AdultMortByCD4NoART_MetaTag :  {'default': AMGlobalData['MortalityNoARTByRegion']},
        AM_AdultInfectReducTag : AdultInfectReduc_Init(),
        AM_MortalityRatesTag : MortalityRates_Init(projInfo, AMGlobalData),
        AM_MortalityRates_MetaTag :  {'default': MortalityRates_Meta_Init(projInfo, AMGlobalData)},
        AM_MortalityRatesMultiplierTag : 4 if projInfo['region'] == DP_Asia else 1,
        AM_AdultMortByCD4WithART0to6Tag : AdultMortByCD4WithART0to6_Init(projInfo, AMGlobalData['AdultMortByCD4WithART0to6']),
        AM_AdultMortByCD4WithART0to6_MetaTag :  {'default': AMGlobalData['AdultMortByCD4WithART0to6']},
        AM_AdultMortByCD4WithART7to12Tag : AdultMortByCD4WithART7to12_Init(projInfo, AMGlobalData['AdultMortByCD4WithART7to12']),
        AM_AdultMortByCD4WithART7to12_MetaTag :  {'default': AMGlobalData['AdultMortByCD4WithART7to12']},
        AM_AdultMortByCD4WithARTGT12Tag : AdultMortByCD4WithARTGT12_Init(projInfo, AMGlobalData['AdultMortByCD4WithARTGT12']),
        AM_AdultMortByCD4WithARTGT12_MetaTag :  {'default': AMGlobalData['AdultMortByCD4WithARTGT12']}, 
        AM_AdultNonAIDSExcessMortTag : AdultNonAIDSExcessMort_Init(projInfo, AMGlobalData['NonAIDSExcessMortality']),
        AM_AdultNonAIDSExcessMort_Meta_Tag :  {'default': AdultNonAIDSExcessMort_Meta_Init(projInfo, AMGlobalData['NonAIDSExcessMortality'])},
        AM_AdultNonAIDSExcessMortRegionTag : projInfo['region'],
        AM_AdultNonAIDSExcessMortCustomFlagTag : False,
        AM_NonAIDSExcessDeathsSingleAgeTag : np.zeros((DP_OnART+1, GB_Female+1, 80 + 1, projInfo['finalYrIdx'] + 1)).tolist(),
        AM_TFRRegionTag : projInfo['region'],
        AM_TFRRegion_MetaTag : {'default' : projInfo['region']},
        AM_HIVTFRCustomFlagTag : False,  
        AM_HIVTFRTag : HIVTFR_Init(projInfo, AMCountryData, AMGlobalData),
        AM_HIVTFR_MetaTag :  {'default': HIVTFR_Meta_Init(projInfo, AMCountryData, AMGlobalData)},
        AM_TFRInputTypeTag : DP_FRR_SingleYearInput,
        AM_FertCD4DiscountTag : FertCD4Discount_Init(projInfo, AMGlobalData),
        AM_FertCD4Discount_MetaTag :  {'default': FertCD4Discount_Meta_Init(AMGlobalData)},
        AM_RatioWomenOnARTTag : RatioWomenOnART_Init(projInfo, AMGlobalData),
        AM_RatioWomenOnART_MetaTag :  {'default': RatioWomenOnART_Meta_Init(projInfo, AMGlobalData)},
        AM_FRRFitInputTag : FRRFitInput_Init(projInfo),
        AM_FRRbyLocationTag : FRRbyLocation_Init(easyAIMData, AMCountryData),
        AM_TransEffAssumpTag : TransEffAssump_Init(),
        AM_DALYDisabilityWeightsTag : DALYDisabilityWeights_Init(),
        AM_RiskPopOrphansTag : RiskPopOrphans_Init(),
        AM_ECDCValuesTag : ECDCValues_Init(projInfo),
        AM_NosocomialInfectionsByAgeTag : NosocomialInfectionsByAge_Init(projInfo),
        AM_HIVMigrantsBySexAgeTag : getList_sex_5yrAge_year(projInfo['finalYrIdx']),
        AM_HIVMigrantsBySingleAgeTag : getList_sex_singleAge_year(projInfo['finalYrIdx']),

        AM_IncidenceInput1970Tag : IncidenceInput1970_Init(projInfo, easyAIMData),
        AM_CSAVRInputAIDSDeathsTag : CSAVRInputAIDSDeaths_Init(projInfo),
        AM_CSAVRInputAIDSDeathsBySexTag : CSAVRInputAIDSDeathsBySex_Init(projInfo),
        AM_CSAVRInputAIDSDeathsBySexAgeTag : CSAVRInputAIDSDeathsBySexAge_Init(projInfo),
        AM_CSAVRInputAIDSDeathsSourceTag : CSAVRSource1,
        AM_CSAVRInputAIDSDeathsSourceNameTag : [('Source ' + str(i + 1)) for i in GBRange(CSAVRSource1, CSAVRSource3)],
        AM_CSAVRInputNewDiagnosesTag : CSAVRInputNewDiagnoses_Init(projInfo),
        AM_CSAVRInputNewDiagnosesBySexTag : CSAVRInputNewDiagnosesBySex_Init(projInfo),
        AM_CSAVRInputNewDiagnosesBySexAgeTag : CSAVRInputNewDiagnosesBySexAge_Init(projInfo),
        AM_CSAVRInputNewDiagnosesBySexAgeCD4Tag : CSAVRInputNewDiagnosesBySexAgeCD4_Init(projInfo),
        AM_CSAVRInputCD4DistAtDiagTag : np.full((CSAVR_CD4_500Plus + 1, projInfo['finalYrIdx'] + 1), DPNotAvail).tolist(),
        AM_CSAVRPopulationValueTag : DP_FitToTotal,
        AM_AIDSMortalityAllAgesTag : AIDSMortalityAllAges_Init(projInfo),
        AM_AnnualInterruptionRateTag : 5,
        AM_IncreasedLikelihoodOfReinitTag : 1,
        AM_OffARTMortRateMultiplierTag : 1,
        AM_ChildAnnualInterruptionRateTag : 5,
        AM_ChildIncreasedLikelihoodOfReinitTag : 1,
        AM_ChildOffARTMortRateMultiplierTag : 1,
        AM_CSAVRFitOptionsTag : CSAVRFitOptions_Init(),
        AM_CSAVRParametersTag : CSAVRParameters_Init(CSAVRData),
        AM_CSAVRIncScaleParametersTag : CSAVRIncScaleParameters_Init(CSAVRData),
        AM_CSAVRUncertaintyParamsTag : CSAVRUncertaintyParams_Init(),
        AM_CSAVRConstrainPLHIVGTNumARTTag : np.full(DP_CSAVRMaxFit + 1, False).tolist(),
        AM_CSAVRTypeOfFitTag : DP_DoubleLogistic,
        AM_CSAVRAdjustIRRsTag : np.full((DP_CSAVRMaxFit + 1, DP_CSAVR_DistOfHIV + 1), False).tolist(),
        AM_CSAVRModelFitTypesTag : np.full(DP_CSAVRMaxFit + 1, True).tolist(),
        AM_CSAVRMetaDataTag : [getIRRFittingDataDict() for i in GBRange(0, DP_CSAVRMaxFit)],
        AM_CSAVRMeanCD4atDiagnosisTag : np.zeros((DP_CSAVRMaxFit + 1, GB_Female + 1, DP_UpperBound + 1, projInfo['finalYrIdx'] + 1)).tolist(), #MeanCD4atDiagnosis_Init(projInfo),
        AM_CSAVRMeanCD4atDiagnosisByAgeSexTag : np.zeros((DP_CSAVRMaxFit + 1, GB_Female + 1, DP_A50Plus + 1, DP_UpperBound + 1, projInfo['finalYrIdx'] + 1)).tolist(), #MeanCD4atDiagnosisByAgeSex_Init(projInfo),
        AM_CSAVRTimeInfToDiagTag : np.zeros((DP_CSAVRMaxFit + 1, GB_Female + 1, DP_UpperBound + 1, projInfo['finalYrIdx'] + 1)).tolist(), #TimeInfToDiag_Init(projInfo),
        AM_CSAVRPropOfDiagnosedTag : np.zeros((DP_CSAVRMaxFit + 1, GB_Female + 1, DP_UpperBound + 1, projInfo['finalYrIdx'] + 1)).tolist(), #PropOfDiagnosed_Init(projInfo),
        AM_CSAVRPropOfDiagnosedNoARTTag : np.zeros((DP_CSAVRMaxFit + 1, GB_Female + 1, DP_UpperBound + 1, projInfo['finalYrIdx'] + 1)).tolist(),
        AM_CSAVRPropOfDiagnosedByAgeSexCD4Tag : np.zeros((DP_CSAVRMaxFit + 1, GB_Female + 1, DP_A50Plus + 1, CSAVR_CD4_All + 1, DP_UpperBound + 1, projInfo['finalYrIdx'] + 1)).tolist(), #PropOfDiagnosedByAgeSexCD4_Init(projInfo),
        AM_CSAVRNumPLHIVTag : np.zeros((DP_CSAVRMaxFit + 1, GB_Female + 1, DP_UpperBound + 1, projInfo['finalYrIdx'] + 1)).tolist(), #CSAVRNumPLHIV_Init(projInfo),
        AM_CSAVRNumPLHIVByAgeSexCD4Tag : np.zeros((DP_CSAVRMaxFit + 1, GB_Female + 1, DP_A50Plus + 1, CSAVR_CD4_All + 1, DP_UpperBound + 1, projInfo['finalYrIdx'] + 1)).tolist(), #CSAVRNumPLHIVByAgeSexCD4_Init(projInfo),
        AM_CSAVRNumDiagnosedTag : np.zeros((DP_CSAVRMaxFit + 1, GB_Female + 1, DP_UpperBound + 1, projInfo['finalYrIdx'] + 1)).tolist(), #CSAVRNumDiagnosed_Init(projInfo),
        AM_CSAVRNumDiagnosedByAgeSexCD4Tag : np.zeros((DP_CSAVRMaxFit + 1, GB_Female + 1, DP_A50Plus + 1, CSAVR_CD4_All + 1, DP_UpperBound + 1, projInfo['finalYrIdx'] + 1)).tolist(), #CSAVRNumDiagnosedByAgeSexCD4_Init(projInfo),
        AM_CSAVRAIDSDeathsTag : np.zeros((DP_CSAVRMaxFit + 1, GB_Female + 1, DP_UpperBound + 1, projInfo['finalYrIdx'] + 1)).tolist(), #CSAVRAIDSDeaths_Init(projInfo),
        AM_CSAVRAIDSDeathsByAgeSexTag : np.zeros((DP_CSAVRMaxFit + 1, GB_Female + 1, DP_A50Plus + 1, DP_UpperBound + 1, projInfo['finalYrIdx'] + 1)).tolist(), #CSAVRAIDSDeathsByAgeSex_Init(projInfo),
        AM_CSAVRNumNewInfectionsTag : np.zeros((DP_CSAVRMaxFit + 1, GB_Female + 1, DP_UpperBound + 1, projInfo['finalYrIdx'] + 1)).tolist(), #CSAVRNumNewInfections_Init(projInfo),
        AM_CSAVRIncidenceByFitTag : np.zeros((DP_CSAVRMaxFit + 1, projInfo['finalYrIdx'] + 1)).tolist(),
        AM_HIVSexRatioTag : HIVSexRatio_Init(projInfo, easyAIMData, AMGlobalData),
        AM_HIVSexRatio_MetaTag : {'default': HIVSexRatio_Meta_Init(projInfo, AMGlobalData)},
        AM_CSAVRHIVSexRatioTag : CSAVRHIVSexRatio_Init(projInfo, easyAIMData, AMGlobalData),
        AM_CustomSAPDataTag : CustomSAPData_Init(projInfo, easyAIMData, AMGlobalData),
        AM_CustomSAPData_MetaTag : CustomSAPData_Meta_Init(projInfo),
        AM_CustomSAPDataIndexTag : projInfo['defaultEpidemic'],
        AM_DistOfHIVTag : DistOfHIV_Init(projInfo, AMGlobalData),
        AM_DistOfHIV_MetaTag : {'default': DistOfHIV_Meta_Init(projInfo, AMGlobalData)},
        AM_CSAVRDistOfHIVTag : CSAVRDistOfHIV_Init(projInfo, AMGlobalData),
        AM_EPPANCRTDataTag : EPPANCRTData_Init(projInfo),
        AM_SAPFormDHSFitSurveyTag : SAPFormDHSFitData_Init(projInfo),
        AM_AIDS45q15Tag : getList_year(projInfo['finalYrIdx']),
        AM_NonAIDS45q15Tag : getList_year(projInfo['finalYrIdx']),
        AM_Total45q15Tag : Total45q15_Init(projInfo, AMCountryData),
        AM_Total45q15_MetaTag : {'default' : Total45q15_Meta_Init(projInfo, AMCountryData)},
        AM_Under5MortRateTag : getList_year(projInfo['finalYrIdx']),
        AM_PMTCTProgEstNeedTag : getList_year(projInfo['finalYrIdx']),
        AM_NumberOnARTTag : getList_year(projInfo['finalYrIdx']),
        AM_ARTCovByAgeTag : getList_sex_5yrAge_year(projInfo['finalYrIdx'], DPNotAvail),
        AM_KeyPopsTag : KeyPops_Init(),
        AM_Meningitis_Tag : Meningitis_Init(projInfo, AMCountryData),
        AM_AdvOptsMeningitis_Tag : AdvOptsMeningitis_Init(projInfo, AMCountryData),

        AM_PregWomenPrevRoutineTestTag : 0.0,
        AM_PregWomenPrevTag : PregWomenPrev_Init(projInfo, AMCountryData),
        AM_PregWomenPrev_MetaTag : {'default' : PregWomenPrev_Meta_Init(projInfo, AMCountryData)},
        
        AM_PrevSurveyTag : PrevSurvey_Init(projInfo),
        AM_PrevSurvey_MetaTag : PrevSurvey_Meta_Init(projInfo, AMCountryData, AMSubnatData),
        AM_ARTCovSurveyTag : ARTCovSurvey_Init(projInfo),
        AM_ARTCovSurvey_MetaTag : ARTCovSurvey_Meta_Init(projInfo, AMCountryData),
        AM_MortRateByAgeTag : getList_sex_5yrAge_year(projInfo['finalYrIdx']),
        AM_AllCauseMortalityTag : getList_sex_5yrAge_year(projInfo['finalYrIdx']),
        AM_AllCauseMortality_MetaTag : AllCauseMortality_Meta_Init(projInfo, AMCountryData),
        AM_AIDSMortalityTag : getList_sex_5yrAge_year(projInfo['finalYrIdx']),
        AM_AIDSMortality_MetaTag : AIDSMortality_Meta_Init(projInfo, AMCountryData),
        AM_NumberOnARTByAgeTag : getList_sex_5yrAge_year(projInfo['finalYrIdx']),
        AM_NewlyStartingARTTag : getList_sex_5yrAge_year(projInfo['finalYrIdx']), 
        AM_AdultsChildrenStartingARTTag : getList_sex_5yrAge_year(projInfo['finalYrIdx']), 
        AM_PercentOfPopTag : PercentOfPop_Init(projInfo),
        AM_ARTCoverageSelectionTag : DP_NumOrPercent,
        AM_BFYearsRGIdxTag : DP_DataAllYears,
        AM_BFArvRGIdxTag : (DP_NotInPMTCT -1),
        AM_ChildHIVMortARTRegionTag : projInfo['region'],
        AM_ChildHIVMortARTCustomFlagTag : False,
        AM_ChildARTDistRegionTag : projInfo['region'],
        AM_ChildARTDistCustomFlagTag : False,
        AM_AdultProgressRatesRegionTag : projInfo['region'],
        AM_AdultProgressRatesCustomFlagTag : False,
        AM_AdultHIVMortNoARTRegionTag : projInfo['region'],
        AM_AdultHIVMortNoARTCustomFlagTag : False,
        AM_AdultHIVMortARTRegionTag : projInfo['region'],
        AM_AdultHIVMortARTCustomFlagTag : False,
        AM_DALYBaseYearTag : max(2015, projInfo['firstYr']),
        AM_DALYDiscountRateTag : 3.0,
        AM_DALYUseStandardLifeTableTag : False,
        AM_OrphansRegionalPatternTag : DP_SSA,
        AM_IncidenceInput1970BoolTag : False,
        AM_IncidenceOptionsTag : DP_DirectIncidenceInputOpt,
        AM_IncidenceByFitTag : incidenceByFit,
        AM_FourDecPlaceIDTag : False,
        AM_EPPPrevAdjTag : True,
        AM_EPPMaxAdjFactorTag : 10,
        AM_EPPPopulationAgesTag : DP_EPP_15t49,
        # AM_IncEpidemicRGIdxTag : 0,
        AM_IncEpidemicCustomFlagTag : False,
        AM_SexRatioFromEPPTag : False,
        AM_HIVSexRatioFromEPPTag : getList_year(projInfo['finalYrIdx']),
        AM_EpidemicTypeFromEPPTag : DP_EPP_GENERALIZED,
        AM_AdultPrevalenceTag : AdultPrevalence_Init(projInfo, easyAIMData),
        AM_EPPCountryNameTag : '',
        AM_EPPEpiNameTag : EPPEpiName_Init(),
        AM_EPPEpidemicTag : EPPEpidemic_Init(),
        AM_EPPPrevDataTag : EPPPrevData_Init(projInfo),
        AM_EPPIncDataTag : EPPIncData_Init(projInfo),
        AM_EPPPopDataTag : EPPPopData_Init(projInfo),
        AM_EPPSexRatioTag : EPPSexRatio_Init(projInfo),
        AM_EPPBaseYrPopTag : EPPBaseYrPop_Init(),
        AM_EPPIDUMortalityTag : EPPIDUMortality_Init(),
        AM_EPPPathInfoTag : EPPPathInfo_Init(),
        AM_EPPAgeRangeTag : 0,
        AM_NumOfEPPEpidemicsTag : 0,
        AM_YrPtPrevalence_WBTag : YrPtPrevalence_WB_Init(),
        AM_AIDSDeathsAmongIDUTag : getList_year(projInfo['finalYrIdx']),
        AM_PropIDU_WBTag : PropIDU_WB_Init(projInfo),
        AM_NonAIDSDeathsAmongIDUTag : getList_year(projInfo['finalYrIdx']),
        AM_ChAged14ByCD4CatTag : ChAged14ByCD4Cat_Init(projInfo), 
        AM_NewHIVInfByRiskGroupTag  : [],
        # AM_IMRTag : getList_sex_year(projInfo['finalYrIdx']),  
        # AM_CMRTag : getList_sex_year(projInfo['finalYrIdx']),
        AM_HIVExpUninfChildrenTag : getList_sex_year(projInfo['finalYrIdx']), 
        AM_ARTExpUninfChildrenTag : getList_sex_year(projInfo['finalYrIdx']),
        AM_NewInfantInfectionsTag : getList_year(projInfo['finalYrIdx']), 
        AM_CD4DistributionTag : CD4Distribution_Init(projInfo), 
        AM_CD4Distribution15_49Tag : CD4Distribution15_49_Init(projInfo), 
        AM_CD4DistributionChildTag : CD4DistributionChild_Init(projInfo), 
        AM_DeathsByAgeTag : getList_sex_singleAge_year(projInfo['finalYrIdx']), 
        AM_HIVBySingleAgeTag : getList_sex_singleAge_year(projInfo['finalYrIdx']), 


        AM_RegionalOutputTag : [],#np.zeros((DP_AdPop0_14Female_Child + 1, DP_MaxEpidemic + 1, projInfo['finalYrIdx'] + 1)).tolist(), 
        AM_OrphansTag : np.zeros((DP_Paternal_Orphans + 1, DP_MaxChildAge + 1, projInfo['finalYrIdx'] + 1)).tolist(), 
        AM_AgeLastBDayTag : np.zeros((DP_Dual_ALB + 1, DP_MaxChildAge + 1, projInfo['finalYrIdx'] + 1)).tolist(), 
        AM_PopAdjTag : getList_sex_year(projInfo['finalYrIdx']), 
        AM_PopAdjAmountTag : getList_sex_5yrAge_year(projInfo['finalYrIdx']), 
        AM_AIDSDeathsByAgeTag : getList_sex_singleAge_year(projInfo['finalYrIdx']), 
        AM_AIDSDeathsARTSingleAgeTag : getList_sex_singleAge_year(projInfo['finalYrIdx']), 
        AM_AIDSDeathsNoARTSingleAgeTag : getList_sex_singleAge_year(projInfo['finalYrIdx']), 
        AM_HIVPregWomenTag : getList_year(projInfo['finalYrIdx']), 
        AM_HIVPregWomenCD4LT350Tag : getList_year(projInfo['finalYrIdx']), 
        AM_ChildOnCotrimTag : getList_sex_year(projInfo['finalYrIdx']), 
        AM_ChildNeedCotrimTag : getList_sex_year(projInfo['finalYrIdx']), 
        AM_NeedARTTag : getList_sex_singleAge_year(projInfo['finalYrIdx']), 
        AM_UnmetNeedARTTag : getList_sex_5yrAge_year(projInfo['finalYrIdx']), 
        AM_PerinatalTransmissionTag : getList_year(projInfo['finalYrIdx']), 
        AM_ChildCTXNeed1To4Tag : getList_sex_year(projInfo['finalYrIdx']), 
        AM_TotalOrphansTag : np.zeros((DP_TotalOrphans + 1, DP_Non_AIDS + 1, projInfo['finalYrIdx'] + 1)).tolist(), 
        AM_AllAIDSOrphTag : np.zeros((DP_AllAIDSOrphans + 1, projInfo['finalYrIdx'] + 1)).tolist(), 
        AM_AllAIDSNewOrphTag : np.zeros((DP_AllAIDSOrphans + 1, projInfo['finalYrIdx'] + 1)).tolist(), 
        AM_NewlyNeedARTTag : getList_sex_5yrAge_year(projInfo['finalYrIdx']), 
        AM_ChildNeedPMTCTTag : getList_year(projInfo['finalYrIdx']), 
        AM_ChildOnPMTCTTag : getList_year(projInfo['finalYrIdx']), 
        AM_MTCTRate6WksTag : getList_year(projInfo['finalYrIdx']), 
        AM_OnARTBySingleAgeTag : getList_sex_singleAge_year(projInfo['finalYrIdx']), 
        AM_OnARTBySingleAge_ProgDataTag : getList_sex_singleAge_year(projInfo['finalYrIdx']), 
        AM_NewInfectionsBySingleAgeTag : getList_sex_singleAge_year(projInfo['finalYrIdx']), 
        AM_NewlyOnARTTag : np.zeros(((10) + 1, GB_Female + 1, GB_MAX_AGE + 1, DP_H_Max + 1, projInfo['finalYrIdx'] + 1)).tolist(), 
        AM_ViralSupprPhi_TempTag : ViralSupprPhi_Init(AMGlobalData),
        AM_SexuallyActive15to19Tag : SexuallyActive15to19_Init(AMCountryData), 
        AM_SexuallyActive15to19_MetaTag : {'default' : SexuallyActive15to19_Init(AMCountryData)}, 
        AM_ReadFRR15_19Coefs_TempTag : ReadFRR15_19Coefs_Init(projInfo, AMGlobalData),
        AM_TFR15_19DefaultDataTag : TFR15_19DefaultData_Init(projInfo, AMCountryData, AMGlobalData),
        AM_FRRFitXMLDefaultDataTag : FRRFitXMLDefaultData_Init(projInfo),
        AM_HAARTBySexPerNumTag : HAARTBySexPerNum_Init(projInfo, easyAIMData),
        AM_AdultARTAdjFactorTag : getList_sex_year(projInfo['finalYrIdx'], 1),
        AM_AdultARTAdjFactorFlagTag : False,
        AM_AdultPatsAllocToFromOtherRegionTag : getList_sex_year(projInfo['finalYrIdx']),
        AM_KnowledgeOfStatusFileTitleTag : '',
        AM_CascadeActiveTag :  False,
        AM_PMTCTEffRegTag : getList_year(projInfo['finalYrIdx']), 
        AM_HIVPosBFWomen3MonthsTag : getList_year(projInfo['finalYrIdx']), 
        AM_HIVPosBFWomen12MonthsTag : getList_year(projInfo['finalYrIdx']), 
        AM_AIDSDeathsNoIntervTag : np.zeros((4 + 1, projInfo['finalYrIdx'] + 1)).tolist(), 
        AM_DeathsAvertARTTag : getList_year(projInfo['finalYrIdx']), 
        AM_InfectAvertPMTCTTag : getList_year(projInfo['finalYrIdx']), 
        AM_LifeYearsGainedTag : getList_year(projInfo['finalYrIdx']), 
        AM_ChildDeathsAvertARTTag : np.zeros((4 + 1, projInfo['finalYrIdx'] + 1)).tolist(), 
        AM_DeathsAvertCotrimTag : np.zeros((4 + 1, projInfo['finalYrIdx'] + 1)).tolist(), 
        AM_DeathsAvertPMTCTTag : np.zeros((4 + 1, projInfo['finalYrIdx'] + 1)).tolist(), 
        AM_HIVAgingRateTag : np.zeros((GB_Female + 1, GB_MAX_AGE + 1, DP_HIVARTgt12m + 1, projInfo['finalYrIdx'] + 1)).tolist(), 
        AM_HIVChildNoARTByInfectionTag : np.zeros((GB_Female + 1, 14 + 1, DP_P_BF12 + 1, projInfo['finalYrIdx'] + 1)).tolist(), 
        AM_TreatPercentTag : np.zeros((DP_OptB_BF + 1, projInfo['finalYrIdx'] + 1)).tolist(), 
        AM_MedianCD4Tag : getList_year(projInfo['finalYrIdx']), 
        AM_AIDSMortAllAgesFYrAdjIdxTag : 0,
        
        AM_ValidationNumberOnARTByAgeTag : ValidationControlMV_Init(projInfo),
        AM_ValidationNewlyOnARTTag : ValidationControlMV_Init(projInfo),
        AM_ValidationMortalityRateByAgeTag : ValidationControlMV_Init(projInfo),
        AM_ValidationAIDSMortalityByAgeTag : ValidationControlMV_Init(projInfo),
        AM_ValidationAllCausesMortalityByAgeTag : ValidationControlMV_Init(projInfo),
        AM_ValidationPrevalenceSelectionTag : PrevalenceValidationControlMV_Init(projInfo),
        AM_ValidationARTCoverageSelectionTag : ValidationARTCovSelection_Init(),
        AM_ValidationAllCauseDeathsARTTag : getList_year(projInfo['finalYrIdx']),
        AM_ValidationWaterfallTag : ValidationWaterfall_Init(projInfo),
        
        AM_PercART50PlusTag : getList_sex_year(projInfo['finalYrIdx']), 
        AM_Prop350_500Tag : 0, 
        AM_IncidenceAdjustmentFactorTag : getList_year(projInfo['finalYrIdx']), 
        AM_ECDCFQNameTag : '',
        AM_NewARTPatAllocTag : NewARTPatAlloc_Init(easyAIMData),
        AM_NewARTPatAlloc_MetaTag : {'default' : NewARTPatAlloc_Init(easyAIMData)},       
        AM_NewARTPatAllocMethodTag : NewARTPatAllocMethod_Init(easyAIMData),
        AM_DefaultEpidemicTag : projInfo['defaultEpidemic'],
        AM_FirstYearOfEpidemicTag : projInfo['epidemicStartYr'],        
        
        AM_ResNonAIDSDeathsHIVPopNoARTTag : getList_sex_singleAge_year(projInfo['finalYrIdx']),
        AM_ResMTCTBySourceTag : np.zeros((PMTCT_TransmissionRate + 1, max(MTCT_Ind_NumWomen_MaxInd, MTCT_Ind_MaxInd) + 1, projInfo['finalYrIdx'] + 1)).tolist(), 
        AM_ResDetailedTreatmentCascadeTag : np.zeros((DP_Cas_ViralSuppr + 1,  max(max(DP_DetCas_KoSIncidentInfNotDiag, DP_DetCas_TreatStatusDiagNoTreat), DP_DetCas_ViralSupprNotSuppressedOnTreat) + 1, projInfo['finalYrIdx'] + 1)).tolist(), 
        AM_ResTreatmentCascadeTag : np.zeros((DP_Cas_AG_AdultBothSexes + 1, DP_Cas_IND_PerPLHIV + 1, DP_Cas_ViralSuppr + 1, projInfo['finalYrIdx'] + 1)).tolist(), 
        AM_ResPerinatallyInf15_19Tag : getList_sex_year(projInfo['finalYrIdx']),
        AM_ResPerinatallyInf20_24Tag : getList_sex_year(projInfo['finalYrIdx']),
        AM_ResQALYsTag : getList_year(projInfo['finalYrIdx']),
        AM_ResDALYsAIDSOnlyTag : getList_year(projInfo['finalYrIdx']),
        AM_ResDALYsTag : getList_year(projInfo['finalYrIdx']),
        AM_ResYLDTag : getList_year(projInfo['finalYrIdx']),
        AM_ResNonAIDSDeathsHIVPopARTTag : getList_sex_singleAge_year(projInfo['finalYrIdx']),
        AM_ResTotalDeathsHIVPopTag : getList_sex_singleAge_year(projInfo['finalYrIdx']),
        AM_ResAIDS45q15Tag : getList_year(projInfo['finalYrIdx']),
        AM_ResNonAIDS45q15Tag : getList_year(projInfo['finalYrIdx']),
        AM_ResNumWithAHDTag : getList_sex_year(projInfo['finalYrIdx']),                     
        AM_ResNumWithAHDOnARTTag : getList_sex_year(projInfo['finalYrIdx']),               
        AM_ResNumWithAHDNoARTTag : getList_sex_year(projInfo['finalYrIdx']),                
        AM_Res15PlusNumWithCryptoAntigenemiaTag : getList_sex_year(projInfo['finalYrIdx']), 
        AM_Res15PlusNumWithCryptoMeningitisTag : getList_sex_year(projInfo['finalYrIdx']),  
        AM_Res15PlusDeathsToPLHIVFromCMTag : getList_sex_year(projInfo['finalYrIdx']),      
        AM_Res15PlusPercAIDSDeathsFromCMTag : getList_sex_year(projInfo['finalYrIdx']),   
        AM_ResOnARTgt1Yr15PlusTag : getList_sex_year(projInfo['finalYrIdx']),     
        AM_ResOnARTlt1Yr15PlusTag : getList_sex_year(projInfo['finalYrIdx']),     
        
        AM_ChildARTAdjFactorTag : np.ones((projInfo['finalYrIdx'] + 1)).tolist(),
        AM_ChildARTAdjFactorFlagTag : False,
        AM_ChildPatsAllocToFromOtherRegionTag : getList_year(projInfo['finalYrIdx']),
        
        AM_SubnatPrevalenceTag       : {}, #Created in AMNaomiSubnational.py
        AM_SubnatARTCoverageTag      : {}, #Created in AMNaomiSubnational.py
        AM_SubnatCustomBaseYrFlagTag : False,
        
        # AM_PreventionNeedsFirstTimeTag   : True,
        AM_PreventionNeedsShowVMMCTabTag : 'VMMC'in PreventionNeedsDB,
        AM_PreventionNeedsCondomsTag     : ReadPreventionNeeds_Condoms(PreventionNeedsDB),
        AM_PreventionNeedsVMMCTag        : ReadPreventionNeeds_VMMC(PreventionNeedsDB),
        AM_PreventionNeedsKeyPopsTag     : ReadPreventionNeeds_KeyPopulations(PreventionNeedsDB),
        AM_PreventionNeedsPrEPTag        : ReadPreventionNeeds_PrEP(PreventionNeedsDB),
        # AM_PrEPParametersTag             : [0.0]*5,
        
        AM_PMTCTPrEPParametersTag    : {
            "adherence": {
                "oral": 0.75,
                "injectable": 0.9
            },
            "selection": {
                # Ratio of incidence among those receiving PrEP to all pregnant and breastfeeding women
                "incidenceRatio": 1.0
            },
            # Person-years of PrEP per person receiving any PrEP during pregnancy and breastfeeding
            "personYearsPrEP": { 
                "oral": 0.59, 
                "injectable": 0.85
            }
        },

        AM_PMTCTReceivingOralPrEPTag       : getList_year(projInfo['finalYrIdx']),
        AM_PMTCTReceivingInjectablePrEPTag : getList_year(projInfo['finalYrIdx']),

    }

    return MVs # only put this here to aid debugging