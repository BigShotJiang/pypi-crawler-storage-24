from SpectrumCommon.Const.DP import *
from SpectrumCommon.Const.GB import *
import numpy as np

def getIRRFittingDataDict():
    return {
        'AIC'       : 0.0,
        'isFitted'  : False,
        'date'      : DPNotAvail,
    }

def getDefaultEpidemicConst(countryData):
    result = DP_Concentrated
    if 'EpidemicType' in countryData:
        epidemicType = countryData['EpidemicType']['Epidemic Type']
        if epidemicType == 'Generalized':
            result = DP_Generalized
        elif epidemicType == 'Concentrated':
            result = DP_LowLevel
    return result

def getPrevSurveyDict(calcYear):
    result = {
        'data' : np.zeros((GB_Female + 1, DP_WeightedSampleSize + 1, DP_A80_Up + 1)).tolist(),
        'used' : False,
        'name' : '',
        'year' : max(calcYear, DP_DefaultSurveyYear),
    }
    return result

def getARTCovSurveyDict(calcYear):
    result = {
        'data' : np.zeros((GB_Female + 1, DP_WeightedSampleSize + 1, DP_Val_A50Plus + 1)).tolist(),
        'used' : False,
        'name' : '',
        'year' : max(calcYear, DP_DefaultSurveyYear),
    }
    return result
    
def getCustomSAPDataDict(finalYearIdx):
    result = {
        'name' : '',  
        'id' : DPNotAvail,  
        'dataSource' : DPNotAvail,                   # IncEpidemicRGIdx
        'fitType' : DPNotAvail,                      # SAPFitType
        'HIVPrevModel' : DPNotAvail,                 # HIVPrevModel
        'AIC' : DPNotAvail,
        'HIVSexRatio' : np.zeros((finalYearIdx + 1)).tolist(),
        'DistOfHIV' : np.zeros((GB_Female + 1, DP_MAX_AGE + 1, finalYearIdx + 1)).tolist(),
    }
    return result




