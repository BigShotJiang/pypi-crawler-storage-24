from os import environ

from AvenirCommon.Database import GB_get_db_json

from SpectrumCommon.Const.GB import GB_SPECT_MOD_DATA_CONN_ENV
from SpectrumCommon.Const.AM import AM_IncidenceByFitTag, AM_SubnatPrevalenceTag, AM_SubnatARTCoverageTag, AM_SubnatCustomBaseYrFlagTag

def am_apply_naomi_subnat(projection, subnat_region):
    
    subnat = GB_get_db_json(environ[GB_SPECT_MOD_DATA_CONN_ENV], 'demproj', f'subnationals\\{subnat_region}_V1.JSON')
    
    projection[AM_IncidenceByFitTag][0] =[subnat['totalIncidence'] for v in projection[AM_IncidenceByFitTag][0]]
    projection[AM_SubnatPrevalenceTag] = subnat['prevalence']
    projection[AM_SubnatARTCoverageTag] = subnat['art_coverage']
    projection[AM_SubnatCustomBaseYrFlagTag] = True
    
    return projection