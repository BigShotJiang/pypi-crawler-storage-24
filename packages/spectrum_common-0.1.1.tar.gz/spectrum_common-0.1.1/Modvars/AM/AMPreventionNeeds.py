from os import environ
from SpectrumCommon.Const.GB.GBConst import GB_SPECT_MOD_DATA_CONN_ENV
from SpectrumCommon.Const.PJ.PJNTags import PJN_ISO3AlphaTag
from SpectrumCommon.Const.DP import AMPreventionsNeedsVersion
from SpectrumCommon.Const.AM import (
    AM_PreventionNeedsFirstTimeTag,
    AM_PreventionNeedsShowVMMCTabTag,
    AM_PreventionNeedsCondomsTag,
    AM_PreventionNeedsVMMCTag,
    AM_PreventionNeedsKeyPopsTag,
    AM_PreventionNeedsPrEPTag
)
from SpectrumCommon.ServerUtils.FilterUtils import get_pjn_modvars, set_all_modvars
from AvenirCommon.Database import GB_get_db_json

def ReadPreventionNeeds_KeyPopulations(PreventionNeedsDB):
    return PreventionNeedsDB.get('KeyPopulations', {})

def ReadPreventionNeeds_VMMC(PreventionNeedsDB):
    return PreventionNeedsDB.get('VMMC', [])

def ReadPreventionNeeds_Condoms(PreventionNeedsDB):
    return PreventionNeedsDB.get('Condoms', {})

def ReadPreventionNeeds_PrEP(PreventionNeedsDB):
    return PreventionNeedsDB.get('PrEP', {})

def reload_prevention_needs(projID, modvarTags=None):
    pjn_modvars = get_pjn_modvars(projID)
    ISO3 = pjn_modvars[PJN_ISO3AlphaTag]
    PreventionNeedsDB = GB_get_db_json(environ[GB_SPECT_MOD_DATA_CONN_ENV], 
                                        'aim', 
                                        f'PreventionNeedsDB/{ISO3}_{AMPreventionsNeedsVersion}.JSON')
    
    aim_modvars = {
        AM_PreventionNeedsFirstTimeTag   : True,
        AM_PreventionNeedsShowVMMCTabTag : 'VMMC'in PreventionNeedsDB,
        AM_PreventionNeedsCondomsTag     : ReadPreventionNeeds_Condoms(PreventionNeedsDB),
        AM_PreventionNeedsVMMCTag        : ReadPreventionNeeds_VMMC(PreventionNeedsDB),
        AM_PreventionNeedsKeyPopsTag     : ReadPreventionNeeds_KeyPopulations(PreventionNeedsDB),
        AM_PreventionNeedsPrEPTag        : ReadPreventionNeeds_PrEP(PreventionNeedsDB)
    }
    if modvarTags and len(modvarTags) > 0:
        aim_modvars = {k: v for k, v in aim_modvars.items() if k in modvarTags}
    set_all_modvars(projID, aim_modvars)
    return aim_modvars# "Reloaded Prevention Needs Successfully"