# fmt: off
from copy import deepcopy
from SpectrumCommon.Const.DP import *

from .AMUtil import getIRRFittingDataDict, getPrevSurveyDict, getARTCovSurveyDict, getCustomSAPDataDict
from ..GB.GBDefs import *

from SpectrumCommon.Const.GB import *
from AvenirCommon.Util import GBRange, getYearIndexFromT, GBNormalize
from SpectrumCommon.Modvars.GB.GBUtil import  getYearIdx, getYear
import numpy as np
import math


    
def AM_InitialConditions_Init(projInfo, InitialConditionsDB):
    firstYear = projInfo['firstYr']
    result = {
        'hiv_infections'    : InitialConditionsDB['hiv_infections'][firstYear - GB_BaseYear] if (not (firstYear == GB_BaseYear)) else 'why are you here',
        'hiv_deaths'        : InitialConditionsDB['hiv_deaths'][firstYear - GB_BaseYear] if (not (firstYear == GB_BaseYear)) else 'why are you here',
        'pmtct_need_15_49'  : InitialConditionsDB['pmtct_need_15_49'][firstYear - GB_BaseYear] if (not (firstYear == GB_BaseYear)) else 'why are you here',
        'pmtct_need_15_24'  : InitialConditionsDB['pmtct_need_15_24'][firstYear - GB_BaseYear] if (not (firstYear == GB_BaseYear)) else 'why are you here',
        'cotrim_need'       : InitialConditionsDB['cotrim_need'][firstYear - GB_BaseYear] if (not (firstYear == GB_BaseYear)) else 'why are you here',
        'art_need'          : InitialConditionsDB['art_need'][firstYear - GB_BaseYear] if (not (firstYear == GB_BaseYear)) else 'because i am here',
    }

    return result
def EdAdSource_Init():
    result = []
    # (* Data Source Variables *)
    # result : TstringList.Create
    # 'Sorted : False
    return result

def AMSources_Init(countryID):
    result = []
    result.append('HIV incidence through 2020 is from the UNAIDS AIDS Info database ' + 
                  '(www.unaids.org). If the projection extends beyond 2020 ' + 
                  'then incidence is maintained at the 2020 level.')
    result.append('')
    result.append('Adult and child ART and PMTCT data are as reported by countries ' + 
                  'to UNAIDS/WHO including projections to 2020. Numbers are constant beyond 2020).')
    
    if countryID in ['BEN', 'IND', 'NGA']:
        result.append('')
        result.append('Please note: The values were taken from an aggregated national ' + 
                      'projection and are NOT from an official UNAIDS file.')
        
    if countryID in ['ETH']:
        result.append('')
        result.append('Please note: The values for Ethiopia are from the official UNAIDS 2015 ' + 
                      'file not the official UNAIDS 2016 file.')


    return result

def CD4ThreshHold_Init(projInfo):
    result = np.zeros((DP_Percent + 1, DP_AgeGT5Years + 1, projInfo['finalYrIdx'] + 1))

    # {* Set default values][based on year and age for CD4 Count Threshhold *}
    for t in GBRange(DP_MIN_YEAR, projInfo['finalYrIdx']):
        year = getYear(t, projInfo['firstYr'])
        if (year <= 2009):
            result[DP_Number][DP_AgeLT11Mths][t]  = 1500
            result[DP_Number][DP_Age12to35Mths][t] = 750
            result[DP_Number][DP_Age35to59Mths][t] = 350
            result[DP_Number][DP_AgeGT5Years][t] = 200
        else:                                      
            result[DP_Number][DP_AgeLT11Mths][t] = 750
            result[DP_Number][DP_Age12to35Mths][t] = 750
            result[DP_Number][DP_Age35to59Mths][t] = 750
            result[DP_Number][DP_AgeGT5Years][t]= 350

    # {* Set default percentage values][based on age for the CD4 Threshhold *}
    # for t in GBRange(DP_MIN_YEAR, projInfo['finalYrIdx']):
    result[DP_Percent, DP_AgeLT11Mths, :]	= 25
    result[DP_Percent, DP_Age12to35Mths, :]	= 25
    result[DP_Percent, DP_Age35to59Mths, :]	= 25
    result[DP_Percent, DP_AgeGT5Years, :]	= 15
        
    return result.tolist() 

def PopsEligTreat_Init(easyAIMData):

    popsEligTreat = {
        'Eligible' : False,
        'PercentHIV' : 0,
        'Year' : 0,
    }
    result = []
    for v in GBRange(0, DP_EligTreatPopsMax):
        result.append(popsEligTreat.copy())



    result[DP_EligTreatPregnantWomen]['PercentHIV'] = 10
    result[DP_EligTreatPregnantWomen]['Year'] = 2013

    result[DP_EligTreatTB_HIV]['PercentHIV'] = 5
    result[DP_EligTreatTB_HIV]['Year'] = 2009

    result[DP_EligTreatDiscordantCouples]['PercentHIV'] = 40
    result[DP_EligTreatDiscordantCouples]['Year'] = 2011

    result[DP_EligTreatSexWorkers]['PercentHIV'] = 2
    result[DP_EligTreatSexWorkers]['Year'] = 2015

    result[DP_EligTreatMSM]['PercentHIV'] = 5
    result[DP_EligTreatMSM]['Year'] = 2015

    result[DP_EligTreatIDU]['PercentHIV'] = 0.5
    result[DP_EligTreatIDU]['Year'] = 2015

    result[DP_EligTreatOtherPop]['PercentHIV'] = 10
    result[DP_EligTreatOtherPop]['Year'] = 2015

    if 'PercentHIVPopEligible' in easyAIMData:
        percentHIVPopEligible = easyAIMData['PercentHIVPopEligible']

        result[DP_EligTreatTB_HIV]['PercentHIV'] = percentHIVPopEligible['TB/HIV']
        result[DP_EligTreatTB_HIV]['Year'] = percentHIVPopEligible['TB/HIV Year']

        result[DP_EligTreatDiscordantCouples]['PercentHIV'] = percentHIVPopEligible['DC']
        result[DP_EligTreatDiscordantCouples]['Year'] = percentHIVPopEligible['DC Year']

        result[DP_EligTreatSexWorkers]['PercentHIV'] = percentHIVPopEligible['FSW']
        result[DP_EligTreatSexWorkers]['Year'] = percentHIVPopEligible['FSW Year']

        result[DP_EligTreatMSM]['PercentHIV'] = percentHIVPopEligible['MSM']
        result[DP_EligTreatMSM]['Year'] = percentHIVPopEligible['MSM Year']

        result[DP_EligTreatIDU]['PercentHIV'] = percentHIVPopEligible['IDU']
        result[DP_EligTreatIDU]['Year'] = percentHIVPopEligible['IDU Year']

        result[DP_EligTreatOtherPop]['PercentHIV'] = percentHIVPopEligible['Other']
        result[DP_EligTreatOtherPop]['Year'] = percentHIVPopEligible['Other Year']

    return result

def AgeHIVChildOnTreatment_Init(projInfo):
    result = getList_year(projInfo['finalYrIdx'])
#     {* Set default values][based on year][for Age below which
#       all HIV+ children should be on ART *}
    for t in GBRange(DP_MIN_YEAR, projInfo['finalYrIdx']):
        year = getYear(t, projInfo['firstYr'])
        if year <= 2006:
            result[t] = 0
        elif year <= 2009:
            result[t] = 12
        elif year <= 2017:
            result[t] = 24
        else:
            result[t] = 180
    return result
    
def CD4ThreshHoldAdults_Init(projInfo):
    result = getList_year(projInfo['finalYrIdx'])
    # (* Set default number values for adults *)
    for t in GBRange(DP_MIN_YEAR, projInfo['finalYrIdx']):
        year = getYear(t, projInfo['firstYr'])
        if (year < 2009):
            result[t] = 200
        elif (year >= 2009) and (year <= 2012):
            result[t] = 350
        elif (year >= 2013) and (year <= 2015):
            result[t] = 500
        else:
            result[t] = 999
    return result

def InfantFeedingOptions_Init(projInfo, easyAIMData, globalData):
    result = np.zeros((DP_InfantFeedingMths + 1, DP_InPMTCT + 1, projInfo['finalYrIdx'] + 1))

    if 'PercNotBFNotRecARVs' in easyAIMData:
        PercNotBFNotRecARVs = easyAIMData['PercNotBFNotRecARVs'].copy()
        PercNotBFNotRecARVs.pop("countryName")
        PercNotBFNotRecARVs.pop("countryCode")
        PercNotBFNotRecARVsList = list(PercNotBFNotRecARVs.values())
        # for t in GBRange(DP_MIN_YEAR, projInfo['finalYrIdx']):
        for r in GBRange(1, DP_InfantFeedingMths):
            result[r, DP_NotInPMTCT, :] = PercNotBFNotRecARVsList[r - 1]

    if 'PercNotBFRecARVs' in easyAIMData:
        PercNotBFRecARVs = easyAIMData['PercNotBFRecARVs'].copy()
        PercNotBFRecARVs.pop("countryName")
        PercNotBFRecARVs.pop("countryCode")
        PercNotBFRecARVsList = list(PercNotBFRecARVs.values())
        # for t in GBRange(DP_MIN_YEAR, projInfo['finalYrIdx']):
        for r in GBRange(1, DP_InfantFeedingMths):
            result[r, DP_InPMTCT, :] = PercNotBFRecARVsList[r - 1]

    return result.tolist()

def InfantFeedingOptions_Meta_Init(projInfo, countryData, globalData):
    result = {
        'surveyData' : np.zeros((DP_InfantFeedingMths + 1, DP_InPMTCT + 1, projInfo['finalYrIdx'] + 1)).tolist(),
        'hasSurveyData' : False
    }
    
    if (projInfo['region'] in [DP_EAfrica, DP_SAfrica, DP_WAfrica]) and ('InfantFeedingModel' in countryData):
        result['hasSurveyData'] = True

        # Load country effect estimates
        IFMCountry = countryData['InfantFeedingModel'][0]
        ce_bgn = IFMCountry['bgn']
        ce_med = IFMCountry['med']
        ce_shp = IFMCountry['shp']

        # Load regional effect estimates, using region from country data
        # Load region data, use the first regional pattern as a fallback
        IFMRegion = list(globalData['InfantFeedingModel'].values())[0] 
        for region in globalData['InfantFeedingModel']:
            if region == IFMCountry['region']:
                IFMRegion = globalData['InfantFeedingModel'][region]

        re_bgn_time = IFMRegion['bgn.time']
        re_bgn_hiv = IFMRegion['bgn.hiv']
        re_bgn_both = IFMRegion['bgn.hiv.time']
        re_med_time = IFMRegion['med.time']
        re_med_hiv = IFMRegion['med.hiv']
        re_med_both = IFMRegion['med.hiv.time']
        re_shp_time = IFMRegion['shp.time']

        # We keep breastfeeding patterns constant before the earliest survey
        # and after the latest survey in each region. Changes are relative to
        # year_base
        tbase = getYearIdx(IFMRegion['year.base'], projInfo['firstYr'])  
        tstart = getYearIdx(IFMRegion['year.start'], projInfo['firstYr'])
        tfinal = getYearIdx(IFMRegion['year.final'], projInfo['firstYr'])

        for t in GBRange(DP_MIN_YEAR, projInfo['finalYrIdx']):
            if(t < tstart):
                dt = tstart - tbase
            elif(t > tfinal):
                dt = tfinal - tbase
            else:
                dt = t - tbase

            bgnLog = math.log(ce_bgn/(1-ce_bgn)) + re_bgn_hiv + (re_bgn_time + re_bgn_both) * dt
            bgn = math.exp(bgnLog) / (1 + math.exp(bgnLog))
            med = math.exp(ce_med + re_med_hiv + (re_med_time + re_med_both) * dt)
            shp = math.exp(ce_shp + re_shp_time * dt) 

            for m in GBRange(1,DP_InfantFeedingMths):
                mon = 2.0 * m - 1.0
                val = bgn * (1.0 - 1.0 / (1.0 + np.power(mon / med, -shp)))
                result['surveyData'][m][DP_NotInPMTCT][t] = 100 * (1.0 - val)
                result['surveyData'][m][DP_InPMTCT][t] = 100 * (1.0 - val)
    else:
        if 'InfantFeedingData' in countryData:
            InfantFeedingData = countryData['InfantFeedingData']
            result['hasSurveyData'] = True
            for m in GBRange(1,DP_InfantFeedingMths):
                for t in GBRange(DP_MIN_YEAR, projInfo['finalYrIdx']):
                    result['surveyData'][m][DP_NotInPMTCT][t] =InfantFeedingData[0]['values'][m]
                    result['surveyData'][m][DP_InPMTCT][t] = InfantFeedingData[0]['values'][m]

    return result

def ARVRegimen_Init(projInfo, easyAIMData):
    result = np.zeros((DP_AnnDropPostnatalProph + 1, DP_TotalTreat + 1, DP_Percent + 1, projInfo['finalYrIdx'] + 1))#.tolist()

    ### Prenatal section ###

    # #Defaults copied from delphi MV init

    def getEasyAIMDataIDPrenatal(arvReg):
        sheetID = ''
        if arvReg == DP_SingleDoseNevir:
            sheetID = DP_EAD_PMTCTSingleDoseNevirapine
        elif arvReg == DP_DualARV:
            sheetID = DP_EAD_PMTCTDualARV
        elif arvReg == DP_OptA:
            sheetID = DP_EAD_PMTCTOptA
        elif arvReg == DP_OptB:
            sheetID = DP_EAD_PMTCTOptB
        elif arvReg == DP_TripleARTBefPreg:
            sheetID = DP_EAD_PMTCTOptBPlusStartBefPreg
        elif arvReg == DP_TripleARTDurPreg:
            sheetID = DP_EAD_PMTCTOptBPlusStartDurPregGT4Wks
        elif arvReg == DP_TripleARTDurPreg_Late:
            sheetID = DP_EAD_PMTCTOptBPlusStartDurPregLT4Wks
        return sheetID

    # init no prophylaxis
    for year in GBRange(projInfo['firstYr'], projInfo['finalYr']):
        t = getYearIdx(year, projInfo['firstYr'])
        result[DP_PrenatalProphylaxis][DP_NoProphylaxis][DP_Percent][t] = 100

    #Set from EasyAIM
    for arvReg in GBRange(DP_SingleDoseNevir, DP_TripleARTDurPreg_Late):    
        sheetID = getEasyAIMDataIDPrenatal(arvReg)
        if sheetID in easyAIMData:
            defaultData = easyAIMData[sheetID]
            for year in GBRange(projInfo['firstYr'], projInfo['finalYr']):
                t = getYearIdx(year, projInfo['firstYr'])
                if year >= defaultData['startYear']:
                    result[DP_PrenatalProphylaxis][arvReg][DP_Percent][t] = defaultData['values'][getYearIndexFromT(defaultData['startYear'], defaultData['endYear'], year)]
                    result[DP_PrenatalProphylaxis][DP_NoProphylaxis][DP_Percent][t] -= result[DP_PrenatalProphylaxis][arvReg][DP_Percent][t]

    ### Postnatal section ###

    # def getEasyAIMDataIDPostnatal(arvReg):
    #     sheetID = ''
    #     if arvReg == DP_OptA:
    #         sheetID = DP_EAD_PMTCTPostnatalOptA
    #     elif arvReg == DP_OptB:
    #         sheetID = DP_EAD_PMTCTPostnatalOptB
    #     return sheetID

    # init no prophylaxis
    for year in GBRange(projInfo['firstYr'], projInfo['finalYr']):
        t = getYearIdx(year, projInfo['firstYr'])
        result[DP_PostnatalProphylaxis][DP_NoProphylaxis][DP_Percent][t] = 100

    #Set from EasyAIM
    # for arvReg in [DP_OptA, DP_OptB]:
    #     sheetID = getEasyAIMDataIDPostnatal(arvReg)
    #     if sheetID in easyAIMData:
    #         defaultData = easyAIMData[sheetID]
    #         for year in GBRange(projInfo['firstYr'], projInfo['finalYr']):
    #             t = getYearIdx(year, projInfo['firstYr'])
    #             if year >= defaultData['startYear']:
    #                 result[DP_PostnatalProphylaxis][arvReg][DP_Percent][t] = defaultData['values'][getYearIndexFromT(defaultData['startYear'], defaultData['endYear'], year)]
    #                 result[DP_PostnatalProphylaxis][DP_NoProphylaxis][DP_Percent][t] -= result[DP_PostnatalProphylaxis][arvReg][DP_Percent][t]

    ### Monthly dropout section ###
    #Defaults copied from delphi MV init
    for year in GBRange(projInfo['firstYr'], projInfo['finalYr']):
        t = getYearIdx(year, projInfo['firstYr'])
        result[DP_AnnDropPostnatalProph][DP_OptA][DP_Percent][t] = 2.2
        result[DP_AnnDropPostnatalProph][DP_OptB][DP_Percent][t] = 2.2
        result[DP_AnnDropPostnatalProph][DP_ART0_12MthsBF][DP_Percent][t] = 1.2
        result[DP_AnnDropPostnatalProph][DP_ARTGT12MthsBF][DP_Percent][t] = 0.7
    
    return result    

def PercentARTDelivery_Init(projInfo):
    result = np.full((DP_StartingARTAtDelivery + 1, projInfo['finalYrIdx'] + 1), 80).tolist()
    return result

def NumNewARTPats_Init(projInfo):
    result = getList_sex_year(projInfo['finalYrIdx'])
    return result

def PercLostFollowup_Init(projInfo, easyAIMData):
    result = getList_year(projInfo['finalYrIdx'])
    if 'PercLostToFollowup' in easyAIMData:
        PercLostToFollowup = easyAIMData['PercLostToFollowup']
        for year in GBRange(projInfo['firstYr'], projInfo['finalYr']):
            t = getYearIdx(year, projInfo['firstYr'])
            if year >= PercLostToFollowup['startYear']:
                result [t] = PercLostToFollowup['values'][getYearIndexFromT(PercLostToFollowup['startYear'], PercLostToFollowup['endYear'], year)]

    return result

def NumNewlyInitART_Init(projInfo):
    result = getList_sex_year(projInfo['finalYrIdx'])
    return result

def HAARTBySex_Init(projInfo, easyAIMData):
    result = getList_sex_year(projInfo['finalYrIdx'])

    if 'AdultARTMale' in easyAIMData:
        AdultARTMale = easyAIMData['AdultARTMale'] 
        for year in GBRange(projInfo['firstYr'], projInfo['finalYr']):
            t = getYearIdx(year, projInfo['firstYr'])
            if year >= AdultARTMale['startYear']:
                result[GB_Male][t] = AdultARTMale['values'][getYearIndexFromT(AdultARTMale['startYear'], AdultARTMale['endYear'], year)]

    if 'AdultARTFemale' in easyAIMData:
        AdultARTFemale = easyAIMData['AdultARTFemale']
        for year in GBRange(projInfo['firstYr'], projInfo['finalYr']):
            t = getYearIdx(year, projInfo['firstYr'])
            if year >= AdultARTFemale['startYear']:
                result[GB_Female][t] = AdultARTFemale['values'][getYearIndexFromT(AdultARTFemale['startYear'], AdultARTFemale['endYear'], year)]

    return result

def HAARTBySexPerNum_Init(projInfo, easyAIMData):
    result = getList_sex_year(projInfo['finalYrIdx'], DP_Percent)

    if 'AdultARTMale' in easyAIMData:
        AdultARTMale = easyAIMData['AdultARTMale'] 
        for year in GBRange(projInfo['firstYr'], projInfo['finalYr']):
            t = getYearIdx(year, projInfo['firstYr'])
            if year >= AdultARTMale['startYear']:
                result[GB_Male][t] = DP_Percent


    if 'AdultARTFemale' in easyAIMData:
        AdultARTFemale = easyAIMData['AdultARTFemale']
        for year in GBRange(projInfo['firstYr'], projInfo['finalYr']):
            t = getYearIdx(year, projInfo['firstYr'])
            if year >= AdultARTFemale['startYear']:
                result[GB_Female][t] = DP_Percent

    return result

def ViralSupprPhi_Init(globalData):
    ViralSupprPhiByRegion = globalData['ViralSupprPhiByRegion']

    result = np.zeros((DP_WAfrica + 1,DP_UpperBound + 1)).tolist()

    for region in GBRange(DP_Asia, DP_WAfrica):
        result[region][DP_Number] = ViralSupprPhiByRegion[region]['Phi']
        result[region][DP_LowerBound] = ViralSupprPhiByRegion[region]['Lower bound']
        result[region][DP_UpperBound] = ViralSupprPhiByRegion[region]['Upper bound']

    return result

def SexuallyActive15to19_Init(countryData):
    result = {
        'value' : 0,
        'str' : '',
    }
    if 'SexualActivity15-19' in countryData:
        result['value'] = countryData['SexualActivity15-19']['SexAct_F_15_19']
        result['str'] = countryData['SexualActivity15-19']['Source'],
        
    return result

def ReadFRR15_19Coefs_Init(projInfo, globalData):
    FRR15_19Coefs = globalData['FRR15_19Coefs']
    
    result = np.zeros(DP_Slope + 1).tolist()

    result[DP_Intercept] = FRR15_19Coefs[projInfo['region']]['Intercept']
    result[DP_Slope] = FRR15_19Coefs[projInfo['region']]['Slope']

    return result
   
def TFR15_19DefaultData_Init(projInfo, countryData, globalData):
    result = np.zeros(DP_WAfrica + 1).tolist()

    for region in GBRange(DP_Asia, DP_WAfrica):
        result[region] = CalcTFRAllInputs(projInfo['region'], countryData, globalData)
    
    return result

def CalcTFRAllInputs(region, countryData, globalData): 
    sexuallyActive = 0
    if 'SexualActivity15-19' in countryData:
        sexuallyActive = countryData['SexualActivity15-19']['SexAct_F_15_19']
    intercept = globalData['FRR15_19Coefs'][region]['Intercept']
    slope = globalData['FRR15_19Coefs'][region]['Slope']
    return math.exp(intercept - slope * sexuallyActive)

def FRRFitXMLDefaultData_Init(projInfo):
    result = { 
        'value' : np.zeros((DP_Percent + 1, projInfo['finalYrIdx'] + 1)).tolist(), 
        'fileExists' : False,
    }
    return result

# def AdultARTByMonth_Init():
#     result = np.zeros((GB_Female + 1, DP_ART_2021 + 1, GB_December + 1)).tolist()
#     return result

# def AdultPercentLTFUByMonth_Init():
#     result = np.zeros((DP_ART_2021 + 1, GB_December + 1)).tolist()
#     return result

def CD4Coverage_Init(projInfo):
    result = np.zeros((DP_CD4Number + 1, DP_CD4_LT50 + 1, projInfo['finalYrIdx'] + 1)).tolist()
    return result

def ARTByAgeGAMAG_Init(projInfo):
    result = np.zeros((GB_Female + 1, DP_GAMAG_A50Plus + 1, projInfo['finalYrIdx'] + 1)).tolist()
    return result

def CovPopsEligTreat_Init(projInfo):
    result = np.zeros((DP_EligTreatOtherPop + 1, projInfo['finalYrIdx'] + 1)).tolist()
    return result

def ChildTreatInputs_Init(projInfo, easyAIMData):
    result = np.zeros((DP_PerChildHIVRecART10_14 + 1, projInfo['finalYrIdx'] + 1)).tolist()

    if 'ChildCotrim' in easyAIMData:
        ChildCotrim = easyAIMData['ChildCotrim']
        for year in GBRange(projInfo['firstYr'], projInfo['finalYr']):
            t = getYearIdx(year, projInfo['firstYr'])
            if year >= ChildCotrim['startYear']:
                result[DP_PerChildHIVPosCot][t] = ChildCotrim['values'][getYearIndexFromT(ChildCotrim['startYear'], ChildCotrim['endYear'], year)]

    if 'ChildART' in easyAIMData:
        ChildART = easyAIMData['ChildART']
        for year in GBRange(projInfo['firstYr'], projInfo['finalYr']):
            t = getYearIdx(year, projInfo['firstYr'])
            if year >= ChildART['startYear']:
                result[DP_PerChildHIVRecART][t] = ChildART['values'][getYearIndexFromT(ChildART['startYear'], ChildART['endYear'], year)]
        
    for year in GBRange(projInfo['firstYr'], projInfo['finalYr']):
        t = getYearIdx(year, projInfo['firstYr'])
        result[DP_PerChildHIVRecART0_4][t] = DPNotAvail
        result[DP_PerChildHIVRecART5_9][t] = DPNotAvail
        result[DP_PerChildHIVRecART10_14][t] = DPNotAvail
        
    return result

def CotrimPerNum_Init(projInfo):
    result = getList_year(projInfo['finalYrIdx'] + 1, DP_Percent)
    return result

def ChildARTByAgeGroupPerNum_Init(projInfo, easyAIMData):
    result = np.full((DP_PerChildHIVRecART10_14 + 1, projInfo['finalYrIdx'] + 1), DP_Percent).tolist()

    if 'ChildCotrim' in easyAIMData:
        ChildCotrim = easyAIMData['ChildCotrim']
        for year in GBRange(projInfo['firstYr'], projInfo['finalYr']):
            t = getYearIdx(year, projInfo['firstYr'])
            if year in GBRange(ChildCotrim['startYear'], ChildCotrim['endYear']):
                result[DP_PerChildHIVPosCot][t] = DP_Percent

    if 'ChildART' in easyAIMData:
        ChildART = easyAIMData['ChildART']
        for year in GBRange(projInfo['firstYr'], projInfo['finalYr']):
            t = getYearIdx(year, projInfo['firstYr'])
            if year in GBRange(ChildART['startYear'], ChildART['endYear']):
                result[DP_PerChildHIVRecART][t] = DP_Percent

    return result

# def ChildARTByMonth_Init():
#     result = np.zeros((DP_ART_2021 + 1, GB_December + 1)).tolist()
#     return result  

# def ChildPercentLTFUByMonth_Init():
#     result = np.zeros((DP_ART_2021 + 1, GB_December + 1)).tolist()
#     return result  

def ANCTestingValues_Init(projInfo):
    result = np.full((DP_HIVNegFirstANCVisit + 1, projInfo['finalYrIdx'] + 1), DPNotAvail).tolist()
    return result

def HIVTesting_Init(projInfo):
    return [{
        'DiagTests': DPNotAvail,
        'PosTests': DPNotAvail,
        'HTSTests': DPNotAvail,
        'PosHTSTests': DPNotAvail,
        'ANCTests': DPNotAvail,
        'PosANCTests': DPNotAvail,
        'CommunityBasedTests': DPNotAvail,
        'CommunityBasedTestsHIVPos': DPNotAvail,
        'SelfTests': DPNotAvail,
        'TestsChild0t14': DPNotAvail,
        'TestsMen15Plus': DPNotAvail,
        'TestsFemale15Plus': DPNotAvail,
        'TestsTrans15Plus': DPNotAvail,
        'TestsHIVPosChild0t14': DPNotAvail,
        'TestsHIVPosMen15Plus': DPNotAvail,
        'TestsHIVPosFemale15Plus': DPNotAvail,
        'TestsHIVPosTrans15Plus': DPNotAvail
    } for t in range(projInfo['finalYrIdx'] + 1)]

def Shiny90SurveyData_Meta_Init():
    return {
        'default' : {
            'isUsed'                : True,
            'surveyID'              : '',
            'year'                  : 0,
            'ageGroup'              : 0,
            'sex'                   : 0,
            'HIVStatus'             : 0,
            'estimate'              : 0.0,
            'standardError'         : 0.0,
            'lowerBound'            : 0.0,
            'upperBound'            : 0.0,
            'count'                 : 0,
        }
    }

def Shiny90ProgramData_Meta_Init():
    return {
        'default' : {
            'isUsed'                : True,
            'year'                  : 0,
            'sex'                   : 0,
            'totalTests'            : 0,
            'totalPosTests'         : 0,
            'totalHTCTests'         : 0,
            'totalPosHTCTests'      : 0,
            'totalANCTests'         : 0,
            'totalPosANCTests'      : 0,  
        }
    }    

def Meningitis_Init(projInfo, countryData):
    result = {
        'prev' : 0,
        'percUnknown' : 0.50,
        'percKnownPos' : 0.60,
        'percOnART' : 0.95,
        'covFluconazole' : 0,      
    }
    if 'Meningitis' in countryData:
        result['prev'] = countryData['Meningitis']['CrAGPlus']
    
    return result

def AdvOptsMeningitis_Init(projInfo, countryData):
    result = {
        'progInCare' : 0.78,
        'progNotInCare' : 0.95,
        'progWithFluconazole' : 0.11,
        'mortRateCMInCare' : 0,
        'mortRateCMNotInCare' : 0,        
    }
    if 'Meningitis' in countryData:
        result['mortRateCMInCare'] = countryData['Meningitis']['InCare']
        result['mortRateCMNotInCare'] = countryData['Meningitis']['NotInCare']
    
    return result

def ChildAnnRateProgressLowerCD4_Init(globalData):
    PedTransParamsPercent = globalData['PedTransParamsPercent']
    PedTransParamsCount = globalData['PedTransParamsCount']

    result = np.zeros((DP_Data + 1, GB_Female + 1, DP_A5t14 + 1, DP_CD4_Per_5_10 + 1)).tolist()
    
    for cd4 in GBRange(DP_CD4_Per_GT30, DP_CD4_Per_5_10):
        for s in GBRange(GB_Male, GB_Female):
            for a in GBRange(DP_A0, DP_A3t4):
                result[DP_Data][s][a][cd4] = PedTransParamsPercent[s][a][cd4]
                result[DP_Default][s][a][cd4] = PedTransParamsPercent[s][a][cd4]

    for cd4 in GBRange(DP_CD4_Ped_GT1000, DP_CD4_Ped_200_349):
        for s in GBRange(GB_Male, GB_Female):
            result[DP_Data][s][DP_A5t14][cd4] = PedTransParamsCount[s][cd4]
            result[DP_Default][s][DP_A5t14][cd4] = PedTransParamsCount[s][cd4]
 
    return result


def ChildDistNewInfectionsCD4_Init():
    result = np.zeros((DP_Data + 1, DP_CD4_Per_LT5 + 1)).tolist()
    for d in GBRange(DP_Default, DP_Data):
        result[d][DP_CD4_Per_GT30]  = 60
        result[d][DP_CD4_Per_26_30] = 12
        result[d][DP_CD4_Per_21_25] = 10
        result[d][DP_CD4_Per_16_20] = 9
        result[d][DP_CD4_Per_11_15] = 5
        result[d][DP_CD4_Per_5_10]	= 3
        result[d][DP_CD4_Per_LT5]	= 1
    return result

def ChildMortByCD4NoART_Init():
    result = np.zeros((DP_Data + 1, DP_A5t14 + 1, DP_P_BF12 + 1, DP_CD4_Per_LT5 + 1)).tolist()
    for d in GBRange(DP_Default, DP_Data):
        result[d][DP_A0t2][DP_P_Perinatal][DP_CD4_Per_GT30] = 0.258013774150955
        result[d][DP_A0t2][DP_P_Perinatal][DP_CD4_Per_26_30] = 0.315133265680154
        result[d][DP_A0t2][DP_P_Perinatal][DP_CD4_Per_21_25] = 0.384897959285447
        result[d][DP_A0t2][DP_P_Perinatal][DP_CD4_Per_16_20] = 0.470107269514553
        result[d][DP_A0t2][DP_P_Perinatal][DP_CD4_Per_11_15] = 0.574180349671666
        result[d][DP_A0t2][DP_P_Perinatal][DP_CD4_Per_5_10] = 0.701293290549447
        result[d][DP_A0t2][DP_P_Perinatal][DP_CD4_Per_LT5] = 0.856546692430183

        result[d][DP_A0t2][DP_P_BF0][DP_CD4_Per_GT30] = 0.15384803221304
        result[d][DP_A0t2][DP_P_BF0][DP_CD4_Per_26_30] = 0.18790714941209
        result[d][DP_A0t2][DP_P_BF0][DP_CD4_Per_21_25] = 0.229506327070103
        result[d][DP_A0t2][DP_P_BF0][DP_CD4_Per_16_20] = 0.28031479552539
        result[d][DP_A0t2][DP_P_BF0][DP_CD4_Per_11_15] = 0.342371321930659
        result[d][DP_A0t2][DP_P_BF0][DP_CD4_Per_5_10] = 0.418166018889037
        result[d][DP_A0t2][DP_P_BF0][DP_CD4_Per_LT5] = 0.510740264013474

        result[d][DP_A0t2][DP_P_BF7][DP_CD4_Per_GT30] = 0.0874347060867091
        result[d][DP_A0t2][DP_P_BF7][DP_CD4_Per_26_30] = 0.0874347060867091
        result[d][DP_A0t2][DP_P_BF7][DP_CD4_Per_21_25] = 0.0874347060867091
        result[d][DP_A0t2][DP_P_BF7][DP_CD4_Per_16_20] = 0.0874347060867091
        result[d][DP_A0t2][DP_P_BF7][DP_CD4_Per_11_15] = 0.0874347060867091
        result[d][DP_A0t2][DP_P_BF7][DP_CD4_Per_5_10] = 0.0874347060867091
        result[d][DP_A0t2][DP_P_BF7][DP_CD4_Per_LT5] = 0.0874347060867091

        result[d][DP_A0t2][DP_P_BF12][DP_CD4_Per_GT30] = 0.0244958560675074
        result[d][DP_A0t2][DP_P_BF12][DP_CD4_Per_26_30] = 0.0244958560675074
        result[d][DP_A0t2][DP_P_BF12][DP_CD4_Per_21_25] = 0.0244958560675074
        result[d][DP_A0t2][DP_P_BF12][DP_CD4_Per_16_20] = 0.0244958560675074
        result[d][DP_A0t2][DP_P_BF12][DP_CD4_Per_11_15] = 0.0244958560675074
        result[d][DP_A0t2][DP_P_BF12][DP_CD4_Per_5_10] = 0.0244958560675074
        result[d][DP_A0t2][DP_P_BF12][DP_CD4_Per_LT5] = 0.0244958560675074

        result[d][DP_A3t4][DP_P_Perinatal][DP_CD4_Per_GT30] = 0.0647002175597198
        result[d][DP_A3t4][DP_P_Perinatal][DP_CD4_Per_26_30] = 0.0790236525817493
        result[d][DP_A3t4][DP_P_Perinatal][DP_CD4_Per_21_25] = 0.0965180319772028
        result[d][DP_A3t4][DP_P_Perinatal][DP_CD4_Per_16_20] = 0.117885344354531
        result[d][DP_A3t4][DP_P_Perinatal][DP_CD4_Per_11_15] = 0.143982985654626
        result[d][DP_A3t4][DP_P_Perinatal][DP_CD4_Per_5_10] = 0.175858163468337
        result[d][DP_A3t4][DP_P_Perinatal][DP_CD4_Per_LT5] = 0.214789917835425

        result[d][DP_A3t4][DP_P_BF0][DP_CD4_Per_GT30] = 0.0462200487129095
        result[d][DP_A3t4][DP_P_BF0][DP_CD4_Per_26_30] = 0.0462200487129095
        result[d][DP_A3t4][DP_P_BF0][DP_CD4_Per_21_25] = 0.0462200487129095
        result[d][DP_A3t4][DP_P_BF0][DP_CD4_Per_16_20] = 0.0462200487129095
        result[d][DP_A3t4][DP_P_BF0][DP_CD4_Per_11_15] = 0.0462200487129095
        result[d][DP_A3t4][DP_P_BF0][DP_CD4_Per_5_10] = 0.0462200487129095
        result[d][DP_A3t4][DP_P_BF0][DP_CD4_Per_LT5] = 0.0462200487129095

        result[d][DP_A3t4][DP_P_BF7][DP_CD4_Per_GT30] = 0.0338288504056146
        result[d][DP_A3t4][DP_P_BF7][DP_CD4_Per_26_30] = 0.0348460681250735
        result[d][DP_A3t4][DP_P_BF7][DP_CD4_Per_21_25] = 0.0360884790889675
        result[d][DP_A3t4][DP_P_BF7][DP_CD4_Per_16_20] = 0.0376059369287946
        result[d][DP_A3t4][DP_P_BF7][DP_CD4_Per_11_15] = 0.0394593319507088
        result[d][DP_A3t4][DP_P_BF7][DP_CD4_Per_5_10] = 0.0417230344517599
        result[d][DP_A3t4][DP_P_BF7][DP_CD4_Per_LT5] = 0.0444878789412917

        result[d][DP_A3t4][DP_P_BF12][DP_CD4_Per_GT30] = 0.0214376520983197
        result[d][DP_A3t4][DP_P_BF12][DP_CD4_Per_26_30] = 0.0234720875372376
        result[d][DP_A3t4][DP_P_BF12][DP_CD4_Per_21_25] = 0.0259569094650256
        result[d][DP_A3t4][DP_P_BF12][DP_CD4_Per_16_20] = 0.0289918251446798
        result[d][DP_A3t4][DP_P_BF12][DP_CD4_Per_11_15] = 0.0326986151885081
        result[d][DP_A3t4][DP_P_BF12][DP_CD4_Per_5_10] = 0.0372260201906104
        result[d][DP_A3t4][DP_P_BF12][DP_CD4_Per_LT5] = 0.042755709169674

        result[d][DP_A5t14][DP_P_Perinatal][DP_CD4_Ped_Top] = 0
        result[d][DP_A5t14][DP_P_Perinatal][DP_CD4_Ped_GT1000] = 0.0261740119076762
        result[d][DP_A5t14][DP_P_Perinatal][DP_CD4_Ped_750_999] = 0.0319684554654492
        result[d][DP_A5t14][DP_P_Perinatal][DP_CD4_Ped_500_749] = 0.0390456819707751
        result[d][DP_A5t14][DP_P_Perinatal][DP_CD4_Ped_350_499] = 0.0476896759122639
        result[d][DP_A5t14][DP_P_Perinatal][DP_CD4_Ped_200_349] = 0.0582472907073062
        result[d][DP_A5t14][DP_P_Perinatal][DP_CD4_Ped_LT200] = 0.071142166723531

        result[d][DP_A5t14][DP_P_BF0][DP_CD4_Ped_Top] = 0
        result[d][DP_A5t14][DP_P_BF0][DP_CD4_Ped_GT1000] = 0.0257224805238841
        result[d][DP_A5t14][DP_P_BF0][DP_CD4_Ped_750_999] = 0.0314169633600384
        result[d][DP_A5t14][DP_P_BF0][DP_CD4_Ped_500_749] = 0.0383720996833689
        result[d][DP_A5t14][DP_P_BF0][DP_CD4_Ped_350_499] = 0.0468669749280504
        result[d][DP_A5t14][DP_P_BF0][DP_CD4_Ped_200_349] = 0.0572424588967309
        result[d][DP_A5t14][DP_P_BF0][DP_CD4_Ped_LT200] = 0.0699148836803373

        result[d][DP_A5t14][DP_P_BF7][DP_CD4_Ped_Top] = 0
        result[d][DP_A5t14][DP_P_BF7][DP_CD4_Ped_GT1000] = 0.024085399765426
        result[d][DP_A5t14][DP_P_BF7][DP_CD4_Ped_750_999] = 0.0294174631112911
        result[d][DP_A5t14][DP_P_BF7][DP_CD4_Ped_500_749] = 0.0359299469526106
        result[d][DP_A5t14][DP_P_BF7][DP_CD4_Ped_350_499] = 0.0438841746187797
        result[d][DP_A5t14][DP_P_BF7][DP_CD4_Ped_200_349] = 0.0535993216052221
        result[d][DP_A5t14][DP_P_BF7][DP_CD4_Ped_LT200] = 0.0654652229760889

        result[d][DP_A5t14][DP_P_BF12][DP_CD4_Ped_Top] = 0
        result[d][DP_A5t14][DP_P_BF12][DP_CD4_Ped_GT1000] = 0.0224483190069678
        result[d][DP_A5t14][DP_P_BF12][DP_CD4_Ped_750_999] = 0.0274179628625438
        result[d][DP_A5t14][DP_P_BF12][DP_CD4_Ped_500_749] = 0.0334877942218522
        result[d][DP_A5t14][DP_P_BF12][DP_CD4_Ped_350_499] = 0.0409013743095089
        result[d][DP_A5t14][DP_P_BF12][DP_CD4_Ped_200_349] = 0.0499561843137134
        result[d][DP_A5t14][DP_P_BF12][DP_CD4_Ped_LT200] = 0.0610155622718406
    return result

def ChildMortalityRates_Init(projInfo, globalData):
    result = np.full((DP_Data + 1, DP_CD4_5t14 + 1, DP_MortRates_GT12Mo + 1, projInfo['finalYrIdx'] + 1), 1).tolist()

    defaultData = globalData['ChildARTMortalityTrends']
    dataFirstYear = defaultData['startYear'] 
    dataFinalYear = defaultData['endYear'] 

    for yr in GBRange(projInfo['firstYr'], projInfo['finalYr']):
        t = getYearIdx(int(yr), projInfo['firstYr'])
        dataYear = max(min(yr, dataFinalYear), dataFirstYear)
        for d in GBRange(DP_Default, DP_Data):
            for age in GBRange(DP_CD4_0t4, DP_CD4_5t14):
                for timePeriod in GBRange(DP_MortRates_LT12Mo, DP_MortRates_GT12Mo):                   
                    result[d][age][timePeriod][t] = defaultData['values'][projInfo['region']][age][timePeriod][getYearIndexFromT(dataFirstYear, dataFinalYear, yr)]

    return result

def ChildMortalityRates_Meta_Init(projInfo, globalData):
    result = np.full((DP_MaxNumRegions + 1, DP_CD4_5t14 + 1, DP_MortRates_GT12Mo + 1, projInfo['finalYrIdx'] + 1), 1).tolist()

    defaultData = globalData['ChildARTMortalityTrends']
    dataFirstYear = defaultData['startYear'] 
    dataFinalYear = defaultData['endYear'] 

    for yr in GBRange(projInfo['firstYr'], projInfo['finalYr']):
        t = getYearIdx(int(yr), projInfo['firstYr'])
        dataYear = max(min(yr, dataFinalYear), dataFirstYear)
        for region in GBRange(DP_Asia, DP_WAfrica):
            for age in GBRange(DP_CD4_0t4, DP_CD4_5t14):
                for timePeriod in GBRange(DP_MortRates_LT12Mo, DP_MortRates_GT12Mo):                   
                    result[region][age][timePeriod][t] = defaultData['values'][region][age][timePeriod][getYearIndexFromT(dataFirstYear, dataFinalYear, yr)]

    return result

def ChildMortByCD4WithART0to6_Init(projInfo, defaultData):
    #(GB_Female + 1, DP_A10t14 + 1, DP_CD4_Ped_LT200 + 1)
    result = np.zeros((DP_Data + 1, ) + np.shape(defaultData[projInfo['region']])).tolist()
    result[DP_Data] = defaultData[projInfo['region']].copy()
    result[DP_Default] = defaultData[projInfo['region']].copy()
    return result

def ChildMortByCD4WithART0to6Perc_Init(projInfo, defaultData):
    #(GB_Female + 1, DP_A3t4 + 1, DP_CD4_Per_LT5 + 1)
    result = np.zeros((DP_Data + 1, ) + np.shape(defaultData[projInfo['region']])).tolist()
    result[DP_Data] = defaultData[projInfo['region']].copy()
    result[DP_Default] = defaultData[projInfo['region']].copy()
    return result

def ChildMortByCD4WithART7to12_Init(projInfo, defaultData):
    result = np.zeros((DP_Data + 1, ) + np.shape(defaultData[projInfo['region']])).tolist()
    result[DP_Data] = defaultData[projInfo['region']].copy()
    result[DP_Default] = defaultData[projInfo['region']].copy()
    return result

def ChildMortByCD4WithART7to12Perc_Init(projInfo, defaultData):
    result = np.zeros((DP_Data + 1, ) + np.shape(defaultData[projInfo['region']])).tolist()
    result[DP_Data] = defaultData[projInfo['region']].copy()
    result[DP_Default] = defaultData[projInfo['region']].copy()
    return result

def ChildMortByCD4WithARTGT12_Init(projInfo, defaultData):
    result = np.zeros((DP_Data + 1, ) + np.shape(defaultData[projInfo['region']])).tolist()
    result[DP_Data] = defaultData[projInfo['region']].copy()
    result[DP_Default] = defaultData[projInfo['region']].copy()
    return result

def ChildMortByCD4WithARTGT12Perc_Init(projInfo, defaultData):
    result = np.zeros((DP_Data + 1, ) + np.shape(defaultData[projInfo['region']])).tolist()
    result[DP_Data] = defaultData[projInfo['region']].copy()
    result[DP_Default] = defaultData[projInfo['region']].copy()
    return result

def ChildARTDist_Init(projInfo, globalData):
    result=np.zeros((DP_Data + 1, 14 + 1, projInfo['finalYrIdx'] + 1)).tolist()
      
    defaultData = globalData['ChildARTDistByRegion']
    dataFirstYear = int(min(list(defaultData[projInfo['region']].keys())))
    dataFinalYear = int(max(list(defaultData[projInfo['region']].keys())))
    for year in GBRange(projInfo['firstYr'], projInfo['finalYr']):
        t = getYearIdx(int(year), projInfo['firstYr'])
        dataYear = max(min(year, dataFinalYear), dataFirstYear)
        for a in GBRange(0, 14):
            result[DP_Data][a][t] = defaultData[projInfo['region']][str(dataYear)][a]
            result[DP_Default][a][t] = defaultData[projInfo['region']][str(dataYear)][a]

    return result

    
def ChildARTDist_Meta_Init(projInfo, globalData):
    result=np.zeros((DP_WAfrica + 1, 14 + 1, projInfo['finalYrIdx'] + 1)).tolist()

    defaultData = globalData['ChildARTDistByRegion']
    dataFirstYear = int(min(list(defaultData[projInfo['region']].keys())))
    dataFinalYear = int(max(list(defaultData[projInfo['region']].keys())))
    for region in GBRange(DP_Asia, DP_WAfrica):
        for year in GBRange(projInfo['firstYr'], projInfo['finalYr']):
            t = getYearIdx(int(year), projInfo['firstYr'])
            dataYear = max(min(year, dataFinalYear), dataFirstYear)
            for a in GBRange(0, 14):
                result[region][a][t] = defaultData[region][str(dataYear)][a]

    return result

def EffectTreatChild_Init():
    result = np.zeros((DP_Data + 1, DP_ChildEffWithART + 1, DP_MaxChildTreatmentYears + 1)).tolist()
    for d in GBRange(DP_Default, DP_Data):
        for t in GBRange(DP_MIN_YEAR, DP_MaxChildTreatmentYears):
            if (t <= 5):
                result[d][DP_ChildEffNoART][t] = 0.33
            else:
                result[d][DP_ChildEffNoART][t] = 0.0

        result[d][DP_ChildEffWithART][1] = 0.33
        for t in GBRange(2, DP_MaxChildTreatmentYears):
            result[d][DP_ChildEffWithART][t] = 0.0
    return result 
    
def ChildWeightBands_Init(globalData):
    result = np.zeros((DP_Data + 1, GB_Female + 1, DP_A14 + 1, DP_Kgs_35_Plus + 1)).tolist()

    childWeightBands = globalData['ChildWeightBands']
    for d in GBRange(DP_Default, DP_Data):
        for sex in GBRange(GB_Male, GB_Female):
            for age in GBRange(DP_A0, DP_A14):
                for wt in GBRange(DP_Kgs_3_5pt9, DP_Kgs_35_Plus):
                    result[d][sex][age][wt] = childWeightBands[sex][age][wt]
                GBNormalize(result[d][sex][age], 1)

    return result

def AdultAnnRateProgressLowerCD4_Init(projInfo, globalData):
    result =np.zeros((DP_Data + 1, GB_Female + 1, DP_CD4_45_54 + 1, DP_CD4_LT50 + 1)).tolist()
    
    ProgressionRatesByRegion = globalData['ProgressionRatesByRegion']
    for cd4 in GBRange(DP_CD4_GT500, DP_CD4_50_99):
        for a in GBRange(DP_CD4_15_24, DP_CD4_45_54):
            for s in GBRange(GB_BothSexes, GB_Female):
                result[DP_Data][s][a][cd4] = ProgressionRatesByRegion[projInfo['region']][s][a][cd4]
                result[DP_Default][s][a][cd4] = ProgressionRatesByRegion[projInfo['region']][s][a][cd4]
    return result

def AdultAnnRateProgressLowerCD4_Meta_Init(projInfo, globalData):
    result =np.zeros((DP_WAfrica + 1, GB_Female + 1, DP_CD4_45_54 + 1, DP_CD4_50_99 + 1)).tolist()
    
    ProgressionRatesByRegion = globalData['ProgressionRatesByRegion']
    for region in GBRange(DP_Asia, DP_WAfrica):
        for cd4 in GBRange(DP_CD4_GT500, DP_CD4_50_99):
            for a in GBRange(DP_CD4_15_24, DP_CD4_45_54):
                for s in GBRange(GB_BothSexes, GB_Female):
                    result[region][s][a][cd4] = ProgressionRatesByRegion[region][s][a][cd4]
    return result

def AdultDistNewInfectionsCD4_Init(projInfo, InitialCD4CountByRegion):
    result = np.zeros((DP_Data + 1, GB_Female + 1, DP_CD4_45_54 + 1, DP_CD4_LT50 + 1)).tolist()
    for cd4 in GBRange(DP_CD4_GT500, DP_CD4_LT50):
        for a in GBRange(DP_CD4_15_24, DP_CD4_45_54):
            for s in GBRange(GB_BothSexes, GB_Female):
                result[DP_Data][s][a][cd4] = InitialCD4CountByRegion[projInfo['region']][s][a][cd4]
                result[DP_Default][s][a][cd4] = InitialCD4CountByRegion[projInfo['region']][s][a][cd4]
    return result

def AdultMortByCD4NoART_Init(projInfo, MortalityNoARTByRegion):
    result=np.zeros((DP_Data + 1, GB_Female + 1, DP_CD4_45_54 + 1, DP_CD4_LT50 + 1)).tolist()

    for cd4 in GBRange(DP_CD4_GT500, DP_CD4_LT50):
        for a in GBRange(DP_CD4_15_24, DP_CD4_45_54):
            for s in GBRange(GB_BothSexes, GB_Female):
                result[DP_Data][s][a][cd4] = MortalityNoARTByRegion[projInfo['region']][s][a][cd4]
                result[DP_Default][s][a][cd4] = MortalityNoARTByRegion[projInfo['region']][s][a][cd4]

    return result
    
def AdultInfectReduc_Init(): 
    result=np.zeros(DP_Data + 1).tolist()
    result[DP_Default] = 0.8
    result[DP_Data] = 0.8
    return result

def MortalityRates_Init(projInfo, globalData):
    result=np.zeros((DP_Data + 1, DP_MortRates_GT12Mo + 1 , projInfo['finalYrIdx'] + 1)).tolist()
        
    if 'ARTmortalityTrends' in globalData:
        ARTmortalityTrends = globalData['ARTmortalityTrends'][projInfo['region']]  
        dataFirstYear = ARTmortalityTrends['startYear'] 
        dataFinalYear = ARTmortalityTrends['endYear'] 
        for yr in GBRange(projInfo['firstYr'], projInfo['finalYr']):
            t = getYearIdx(yr, projInfo['firstYr'])
            
            for timePeriod in GBRange(DP_MortRates_LT12Mo, DP_MortRates_GT12Mo):
                for dt in GBRange(DP_Default, DP_Data):
                    result[dt][timePeriod][t] = ARTmortalityTrends['values'][timePeriod][getYearIndexFromT(dataFirstYear, dataFinalYear, yr)]

    return result

def MortalityRates_Meta_Init(projInfo, globalData):
    result=np.zeros((DP_WAfrica + 1, DP_MortRates_GT12Mo + 1 , projInfo['finalYrIdx'] + 1)).tolist()
        
    if 'ARTmortalityTrends' in globalData:
        for region in GBRange(DP_Asia, DP_WAfrica):
            ARTmortalityTrends = globalData['ARTmortalityTrends'][region]  
            dataFirstYear = ARTmortalityTrends['startYear'] 
            dataFinalYear = ARTmortalityTrends['endYear'] 
            for yr in GBRange(projInfo['firstYr'], projInfo['finalYr']):
                t = getYearIdx(yr, projInfo['firstYr'])
                
                for timePeriod in GBRange(DP_MortRates_LT12Mo, DP_MortRates_GT12Mo):
                        result[region][timePeriod][t] = ARTmortalityTrends['values'][timePeriod][getYearIndexFromT(dataFirstYear, dataFinalYear, yr)]

    return result

def AdultMortByCD4WithART0to6_Init(projInfo, defaultData):
    result = np.zeros((DP_Data + 1, GB_Female + 1, DP_CD4_45_54 + 1, DP_CD4_LT50 + 1)).tolist()
    
    for cd4 in GBRange(DP_CD4_GT500, DP_CD4_LT50):
        for a in GBRange(DP_CD4_15_24, DP_CD4_45_54):
            for s in GBRange(GB_BothSexes, GB_Female):
                result[DP_Data][s][a][cd4] = defaultData[projInfo['region']][s][a][cd4]
                result[DP_Default][s][a][cd4] = defaultData[projInfo['region']][s][a][cd4]
    return result

def AdultMortByCD4WithART7to12_Init(projInfo, defaultData):
    result = np.zeros((DP_Data + 1, GB_Female + 1, DP_CD4_45_54 + 1, DP_CD4_LT50 + 1)).tolist()
    
    for cd4 in GBRange(DP_CD4_GT500, DP_CD4_LT50):
        for a in GBRange(DP_CD4_15_24, DP_CD4_45_54):
            for s in GBRange(GB_BothSexes, GB_Female):
                result[DP_Data][s][a][cd4] = defaultData[projInfo['region']][s][a][cd4]
                result[DP_Default][s][a][cd4] = defaultData[projInfo['region']][s][a][cd4]
    return result


def AdultMortByCD4WithARTGT12_Init(projInfo, defaultData):
    result = np.zeros((DP_Data + 1, GB_Female + 1, DP_CD4_45_54 + 1, DP_CD4_LT50 + 1)).tolist()
    
    for cd4 in GBRange(DP_CD4_GT500, DP_CD4_LT50):
        for a in GBRange(DP_CD4_15_24, DP_CD4_45_54):
            for s in GBRange(GB_BothSexes, GB_Female):
                result[DP_Data][s][a][cd4] = defaultData[projInfo['region']][s][a][cd4]
                result[DP_Default][s][a][cd4] = defaultData[projInfo['region']][s][a][cd4]
    return result

def AdultNonAIDSExcessMort_Init(projInfo, defaultData):
    result = np.zeros((DP_Data + 1, GB_Female + 1, DP_CD4_45_54 + 1, DP_CD4_LT50 + 1, DP_OnART + 1)).tolist()
    
    for art in GBRange(DP_NoTreat, DP_OnART):
        for cd4 in GBRange(DP_CD4_GT500, DP_CD4_LT50):
            for a in GBRange(DP_CD4_15_24, DP_CD4_45_54):
                for s in GBRange(GB_BothSexes, GB_Female):
                    result[DP_Data][s][a][cd4][art] = defaultData[projInfo['region']][art][s][a][cd4]
                    result[DP_Default][s][a][cd4][art] = defaultData[projInfo['region']][art][s][a][cd4]
    return result

def AdultNonAIDSExcessMort_Meta_Init(projInfo, defaultData):
    result = np.zeros((DP_WAfrica + 1, GB_Female + 1, DP_CD4_45_54 + 1, DP_CD4_LT50 + 1, DP_OnART + 1)).tolist()
    
    for region in GBRange(DP_Asia, DP_WAfrica):
        for art in GBRange(DP_NoTreat, DP_OnART):
            for cd4 in GBRange(DP_CD4_GT500, DP_CD4_LT50):
                for a in GBRange(DP_CD4_15_24, DP_CD4_45_54):
                    for s in GBRange(GB_BothSexes, GB_Female):
                        result[region][s][a][cd4][art] = defaultData[region][art][s][a][cd4]
    return result


def IncCD4FirstYrWithART_Init():
    result = np.zeros(DP_Data + 1).tolist()
    return result

def IncCD4SubYrWithART_Init():
    result = np.zeros(DP_Data + 1).tolist()
    return result

def HIVTFR_Init(projInfo, countryData, globalData):
    result = np.zeros((DP_Data + 1, DP_A45_49 + 1, projInfo['finalYrIdx'] + 1)).tolist()
    
    FertilityRatio = globalData['FertilityRatio']
    TFR15_19 = CalcTFRAllInputs(projInfo['region'], countryData, globalData)
    for year in GBRange(projInfo['firstYr'], projInfo['finalYr']):
        t = getYearIdx(year, projInfo['firstYr'])
        for d in GBRange(DP_Default, DP_Data):
            result[d][DP_A15_19][t] = TFR15_19

            for a in GBRange(DP_A20_24, DP_A45_49):
                result[d][a][t] = FertilityRatio[projInfo['region']][a]

    return result

def HIVTFR_Meta_Init(projInfo, countryData, globalData):
    result = np.zeros((DP_WAfrica + 1, DP_A45_49 + 1, projInfo['finalYrIdx'] + 1)).tolist()
    
    FertilityRatio = globalData['FertilityRatio']
    for region in GBRange(DP_Asia, DP_WAfrica):
        TFR15_19 = CalcTFRAllInputs(region, countryData, globalData)
        for year in GBRange(projInfo['firstYr'], projInfo['finalYr']):
            t = getYearIdx(year, projInfo['firstYr'])
            result[region][DP_A15_19][t] = TFR15_19

            for a in GBRange(DP_A20_24, DP_A45_49):
                result[region][a][t] = FertilityRatio[region][a]

    return result

def FertCD4Discount_Init(projInfo, globalData):
    result = np.zeros((DP_Data + 1, DP_CD4_LT50 + 1)).tolist()

    FRRByCD4Category = globalData['FRRByCD4Category']
    for cd4 in GBRange(DP_CD4_GT500, DP_CD4_LT50):
        result[DP_Data][cd4] = FRRByCD4Category[projInfo['region']][cd4]
        result[DP_Default][cd4] = FRRByCD4Category[projInfo['region']][cd4]
    return result

def FertCD4Discount_Meta_Init(globalData):
    result = np.zeros((DP_WAfrica + 1, DP_CD4_LT50 + 1)).tolist()

    FRRByCD4Category = globalData['FRRByCD4Category']
    for region in GBRange(DP_Asia, DP_WAfrica):
        for cd4 in GBRange(DP_CD4_GT500, DP_CD4_LT50):
            result[region][cd4] = FRRByCD4Category[region][cd4]
    return result

def RatioWomenOnART_Init(projInfo, globalData):
    result = np.zeros((DP_Data + 1, DP_A45_49 + 1)).tolist()

    RatioWomenOnART = globalData['RatioWomenOnART']
    for a in GBRange(DP_A15_19, DP_A45_49):
        result[DP_Data][a] = RatioWomenOnART[projInfo['region']][a]
        result[DP_Default][a] = RatioWomenOnART[projInfo['region']][a]
    return result

def RatioWomenOnART_Meta_Init(projInfo, globalData):
    result = np.zeros((DP_WAfrica + 1, DP_A45_49 + 1)).tolist()

    RatioWomenOnART = globalData['RatioWomenOnART']
    for region in GBRange(DP_Asia, DP_WAfrica):
        for a in GBRange(DP_A15_19, DP_A45_49):
            result[region][a] = RatioWomenOnART[projInfo['region']][a]
    return result

def FRRFitInput_Init(projInfo):
    result = np.zeros((DP_Percent + 1, projInfo['finalYrIdx'] + 1)).tolist()
    return result

def FRRbyLocation_Init(easyAIMData, AMCountryData):
    result = np.full(DP_Data + 1, 1.0).tolist()

    if 'LocalAdjustmentFactor' in easyAIMData:
        LocalAdjustmentFactor = easyAIMData['LocalAdjustmentFactor']
        result[DP_Data] = LocalAdjustmentFactor['value']
        result[DP_Default] = AMCountryData['FRRbyLocation']['Ratio'] if 'FRRbyLocation' in AMCountryData else result[DP_Data] 
    return result

def TransEffAssump_Init():
    result = np.zeros((DP_Data + 1, DP_ARTStartDurPreg_Late + 1, DP_BreastfeedingGE350 + 1)).tolist()
    for d in GBRange(DP_Default, DP_Data):
        result[d][DP_NoProphExistInfCD4LT200][DP_Perinatal] = 33.4
        result[d][DP_NoProphExistInfCD4LT200][DP_BreastfeedingLT350] = 1.07 #{2018 was 0.81}

        result[d][DP_NoProphExistInfCD4200_350][DP_Perinatal] = 25.1
        result[d][DP_NoProphExistInfCD4200_350][DP_BreastfeedingLT350] = 0.94 #{1.57}

        result[d][DP_NoProphExistInfCD4GT350][DP_Perinatal] = 16.7
        result[d][DP_NoProphExistInfCD4GT350][DP_BreastfeedingGE350] = 0.8

        result[d][DP_NoProphIncidentInf][DP_Perinatal] = 18 #{2018 was 18.2}
        result[d][DP_NoProphIncidentInf][DP_BreastfeedingLT350] = 28.2 #{28.0}
        result[d][DP_NoProphIncidentInf][DP_BreastfeedingGE350] = 28.2  #{28.0}

        result[d][DP_SingleDoseNev][DP_Perinatal] = 8.3 #{2018 was 8.9}
        result[d][DP_SingleDoseNev][DP_BreastfeedingLT350] = 0.74 #{2018 was 0.78}
        result[d][DP_SingleDoseNev][DP_BreastfeedingGE350] = 0.33 #{2018 was 0.51}

        result[d][DP_WHO2006DualARV][DP_Perinatal] = 3.1 #{2018 was 4.1}
        result[d][DP_WHO2006DualARV][DP_BreastfeedingLT350] = 0.2 #{2018 was 0.78}
        result[d][DP_WHO2006DualARV][DP_BreastfeedingGE350] = 0.2 #{2018 was 0.51}

        result[d][DP_OptionA][DP_Perinatal] = 3.1
        result[d][DP_OptionA][DP_BreastfeedingGE350] = 0.2

        result[d][DP_OptionB][DP_Perinatal] = 1.8 #{0.9}
        result[d][DP_OptionB][DP_BreastfeedingGE350] = 0.14 #{0.2}

        result[d][DP_ARTStartPrePreg][DP_Perinatal] = 0.33 #{2018 was 0.21}
        result[d][DP_ARTStartPrePreg][DP_BreastfeedingLT350] = 0.02 #{2018 was 0.013}

        result[d][DP_ARTStartDurPreg][DP_Perinatal] = 1.0 #{2018 was 1.9}
        result[d][DP_ARTStartDurPreg][DP_BreastfeedingLT350] = 0.13 #{2018 was 0.13}

        result[d][DP_ARTStartDurPreg_Late][DP_Perinatal] =  5.2 #{2018 was 7.6}
        result[d][DP_ARTStartDurPreg_Late][DP_BreastfeedingLT350] = 0.13

    return result
    
def DALYDisabilityWeights_Init():
    result = np.zeros((DP_DALY_OnART + 1, DP_Child + 1)).tolist()
    
    result[DP_DALY_CD4CountLT200][DP_Adult] = DP_W1
    result[DP_DALY_CD4CountGE200][DP_Adult] = DP_W2
    result[DP_DALY_OnART][DP_Adult] = DP_W3

    result[DP_DALY_CD4CountLT200][DP_Child] = DP_W4
    result[DP_DALY_CD4CountGE200][DP_Child] = DP_W5
    result[DP_DALY_OnART][DP_Child] = DP_W6
    return result

def RiskPopOrphans_Init():
    result = np.zeros((DP_LowerRiskGenPop + 1, DP_PercMarried + 1)).tolist()

    result[DP_InjectingDrugUsers][DP_PercAIDSDeaths]  = 60.0
    result[DP_MenSexWithMen][DP_PercAIDSDeaths]       = 25.0
    result[DP_SexWorkers][DP_PercAIDSDeaths]          = 5.0
    result[DP_LowerRiskGenPop][DP_PercAIDSDeaths]     = 10.0

    result[DP_InjectingDrugUsers][DP_PercMarried]     = 30.0
    result[DP_MenSexWithMen][DP_PercMarried]          = 40.0
    result[DP_SexWorkers][DP_PercMarried]             = 50.0
    result[DP_LowerRiskGenPop][DP_PercMarried]        = 70.0
    return result

def ECDCValues_Init(projInfo):
    result = np.zeros((DP_UpperBound + 1, projInfo['finalYrIdx'] + 1)).tolist()
    return result

def NosocomialInfectionsByAge_Init(projInfo):
    result = np.zeros((DP_A10_14 + 1, projInfo['finalYrIdx'] + 1)).tolist()
    return result

def IncidenceInput1970_Init(projInfo,  easyAIMData):
    result = getList_year(projInfo['finalYrIdx'])
    
    if 'Incidence' in easyAIMData:
        Incidence = easyAIMData['Incidence']       
        dataFirstYear = Incidence['startYear'] 
        dataFinalYear = Incidence['endYear'] 
        for year in GBRange(projInfo['firstYr'], projInfo['finalYr']):
            t = getYearIdx(year, projInfo['firstYr'])
            if year >= Incidence['startYear']:
                result[t] = Incidence['values'][getYearIndexFromT(dataFirstYear, dataFinalYear, year)]

    return result

def CSAVRInputAIDSDeaths_Init(projInfo):
    result = np.full((CSAVRSource3 + 1, CSAVRNumNotReported + 1, projInfo['finalYrIdx'] + 1), DPNotAvail).tolist()
    return result

def CSAVRInputAIDSDeathsBySex_Init(projInfo):
    result = np.full((CSAVRSource3 + 1, GB_Female + 1, CSAVRNumNotReported + 1, projInfo['finalYrIdx'] + 1), DPNotAvail).tolist()
    return result

def CSAVRInputAIDSDeathsBySexAge_Init(projInfo):
    result = np.full((CSAVRSource3 + 1, GB_Female + 1, DP_A50Plus + 1, projInfo['finalYrIdx'] + 1), DPNotAvail).tolist()
    return result

def CSAVRInputNewDiagnoses_Init(projInfo):
    result = np.full((CSAVRNumNotReported + 1, projInfo['finalYrIdx'] + 1), DPNotAvail).tolist()
    return result

def CSAVRInputNewDiagnosesBySex_Init(projInfo):
    result = np.full((GB_Female + 1, CSAVRNumNotReported + 1, projInfo['finalYrIdx'] + 1), DPNotAvail).tolist()
    return result

def CSAVRInputNewDiagnosesBySexAge_Init(projInfo):
    result = np.full((GB_Female + 1, DP_A50Plus + 1, projInfo['finalYrIdx'] + 1), DPNotAvail).tolist()
    return result

def CSAVRInputNewDiagnosesBySexAgeCD4_Init(projInfo):
    result = np.full((GB_Female + 1, DP_A50Plus + 1, CSAVR_CD4_500Plus + 1, projInfo['finalYrIdx'] + 1), DPNotAvail).tolist()
    return result

def AIDSMortalityAllAges_Init(projInfo):
    result = np.zeros((DP_UnderCount + 1, projInfo['finalYrIdx'] + 1)).tolist()
    return result

def CSAVRFitOptions_Init():
    result = np.full(DP_CD4DistAtDiag + 1, False).tolist()
    return result

def CSAVRParameters_Init(CSAVRData):
    # result = CSAVRData
    return deepcopy(CSAVRData)

def CSAVRIncScaleParameters_Init(CSAVRData):
    result = deepcopy(CSAVRData)
    for fit in result:
        for param in result[fit]:
            result[fit][param]['value'] = DPNotAvail
    return result

def CSAVRUncertaintyParams_Init():
    result = np.zeros((DP_CSAVRMaxFit + 1, CSAVR_Unc_NumSamples + 1)).tolist()
    for fit in DP_CSAVR_FitSet:
      result[fit][CSAVR_Unc_BurnIn] = 10000
      result[fit][CSAVR_Unc_NumSamples] = 1000
    return result

def HIVSexRatio_Init(projInfo, easyAIMData, globalData): 
    result = getList_year(projInfo['finalYrIdx'])   

    if 'SexRatio' in easyAIMData:
        sexRatio = easyAIMData['SexRatio']
 
        dataFirstYear = sexRatio['startYear'] 
        dataFinalYear = sexRatio['endYear'] 
        for year in GBRange(projInfo['firstYr'], projInfo['finalYr']):
            t = getYearIdx(year, projInfo['firstYr'])
            result[t] = sexRatio['values'][getYearIndexFromT(dataFirstYear, dataFinalYear, year)]
    else:
        defaultData = HIVSexRatio_Meta_Init(projInfo, globalData)
        defaultEpidemic = projInfo['defaultEpidemic']
        result[:] = defaultData[defaultEpidemic][:]
       
    return result

def HIVSexRatio_Meta_Init(projInfo, globalData): 
    result = np.zeros((DP_IDUConcentrated_Index + 1, projInfo['finalYrIdx'] + 1)).tolist() 
        
    def returnDataIndex(year, epidemicStartYear, dataFirstIdx, dataFinalIdx):
        result = dataFirstIdx   #base case, year prior or equal to epidemic start year
        if year > epidemicStartYear:
            result = min(dataFinalIdx, year - epidemicStartYear + 1) #handles all years > epidemic start year
        return result

    sexRatio = globalData['AgeRatioPatternsSexRatio']
    epidemicStartYear = projInfo['epidemicStartYr']
    
    for epi in GBRange(DP_Generalized_Index, DP_IDUConcentrated_Index):
        for year in GBRange(projInfo['firstYr'], projInfo['finalYr']):
            t = getYearIdx(year, projInfo['firstYr'])

            result[epi][t] = sexRatio[epi][returnDataIndex(year, epidemicStartYear, 1, len(sexRatio[epi]) - 1)-1]

            if epi == DP_Generalized_Index:
                irr_phase1 = result[epi][t]
                irr_phase2 = 1.38 + 0.55883 / (1.0 + math.exp(-0.4001542 * (year - 2015)))
                if (year < 1995):
                    result[epi][t] = irr_phase1
                elif (year > 2010):
                    result[epi][t] = irr_phase2
                else:
                    result[epi][t] = (irr_phase1 * (2010 - year) + irr_phase2 * (year - 1995)) / (2010 - 1995)

    return result

def CSAVRHIVSexRatio_Init(projInfo, easyAIMData, globalData):   
    result = np.zeros((DP_CSAVRMaxFit + 1, projInfo['finalYrIdx'] + 1)).tolist() 

    HIVSexRatioVals = HIVSexRatio_Init(projInfo, easyAIMData, globalData)

    for fitType in DP_CSAVR_FitSet:
        result[fitType] = HIVSexRatioVals.copy()
        
    return result

def HIVSexRatioFittingValues_Init(projInfo, easyAIMData, globalData):   
    result = np.zeros((DP_SAP_TimeDependentIR + 1, projInfo['finalYrIdx'] + 1)).tolist()

    HIVSexRatioVals = HIVSexRatio_Init(projInfo, easyAIMData, globalData)

    for fitType in GBRange(DP_SAP_FixedIROverTime, DP_SAP_TimeDependentIR):
        result[fitType] = HIVSexRatioVals.copy()

    return result

def CustomSAPData_Init(projInfo, easyAIMData, globalData):
    SAP = getCustomSAPDataDict(projInfo['finalYrIdx'])
    
    if 'SexRatio' in easyAIMData:
        sexRatio = easyAIMData['SexRatio']
 
        dataFirstYear = sexRatio['startYear'] 
        dataFinalYear = sexRatio['endYear'] 
        for year in GBRange(projInfo['firstYr'], projInfo['finalYr']):
            t = getYearIdx(year, projInfo['firstYr'])
            SAP['HIVSexRatio'] [t] = sexRatio['values'][getYearIndexFromT(dataFirstYear, dataFinalYear, year)]
            
    age_ratio = globalData['AgeRatioPatternsIncidence'][projInfo['defaultEpidemic']]
    for s in GBRange(GB_Male, GB_Female):
        for a in GBRange(DP_A15_19, DP_A75_Up):
            for t in GBRange(DP_MIN_YEAR, projInfo['finalYrIdx']):
                SAP['DistOfHIV'] [s][a][t] = age_ratio[s][a]

    result = []
    for i in GBRange(DP_Generalized_Index, DP_FittedToART_Index):
        sap_copy = SAP.copy()
        sap_copy['id'] = i
        sap_copy['dataSource'] = i
        result.append(sap_copy)
    
    # custom changes from thomas
    result[DP_FittedToART_Index]['fitType'] = DP_SAP_ARTByAge

    result[DP_HIVPrevTime_Index]['fitType'] = DP_SAP_HIVPrevByAge
    result[DP_HIVPrevTime_Index]['HIVPrevModel'] = DP_SAP_TimeDependentIR

    result[DP_HIVPrevFixed_Index]['fitType'] = DP_SAP_HIVPrevByAge
    result[DP_HIVPrevFixed_Index]['HIVPrevModel'] = DP_SAP_FixedIROverTime   
    
    for i in GBRange(DP_Generalized_Index, DP_IDUConcentrated_Index):
        age_ratio = globalData['AgeRatioPatternsIncidence'][i]
        for s in GBRange(GB_Male, GB_Female):
            for a in GBRange(DP_A15_19, DP_A75_Up):
                for t in GBRange(DP_MIN_YEAR, projInfo['finalYrIdx']):
                     result[i]['DistOfHIV'][s][a][t] = age_ratio[s][a]
    return result 
  
def CustomSAPData_Meta_Init(projInfo):
    result = getCustomSAPDataDict(projInfo['finalYrIdx']).copy()
    return result 

def FittingData_Init():
    result = np.full(DP_SAP_TimeDependentIR + 1, getIRRFittingDataDict().copy()).tolist()
    return result

def ARTTreatFittingData_Init():
    result = getIRRFittingDataDict().copy()
    return result

def DistOfHIV_Init(projInfo, globalData):
    result = getList_sex_5yrAge_year(projInfo['finalYrIdx'])
    defaultData = globalData['AgeRatioPatternsIncidence']
    
    for s in GBRange(GB_Male, GB_Female):
        for a in GBRange(DP_A15_19, DP_A75_Up):
            for t in GBRange(DP_MIN_YEAR, projInfo['finalYrIdx']):
                result[s][a][t] = defaultData[projInfo['defaultEpidemic']][s][a]
    
    return result

def DistOfHIV_Meta_Init(projInfo, globalData):
    result = np.zeros((DP_IDUConcentrated_Index + 1, GB_Female + 1, GB_MAX_AGE + 1, projInfo['finalYrIdx'] + 1)).tolist()
    defaultData = globalData['AgeRatioPatternsIncidence']
    
    for s in GBRange(GB_Male, GB_Female):
        for a in GBRange(DP_A15_19, DP_A75_Up):
            for t in GBRange(DP_MIN_YEAR, projInfo['finalYrIdx']):
                for id in GBRange(DP_Generalized_Index, DP_IDUConcentrated_Index):
                    result[id][s][a][t] = defaultData[id][s][a]
    
    return result

def CSAVRDistOfHIV_Init(projInfo, globalData):
    result = np.zeros((DP_CSAVRMaxFit + 1, GB_Female + 1, GB_MAX_AGE + 1, projInfo['finalYrIdx'] + 1))
    defaultData = globalData['AgeRatioPatternsIncidence']
    
    for s in GBRange(GB_Male, GB_Female):
        for a in GBRange(DP_A15_19, DP_A75_Up):
            result[:, s, a, :] = defaultData[projInfo['defaultEpidemic']][s][a]
    return result.tolist()

def EPPANCRTData_Init(projInfo):
    result = {
        'hasData' : False,
        'SizeValue' : getList_year(projInfo['finalYrIdx']), 
        'PrevValue' : getList_year(projInfo['finalYrIdx']), 
    }
    return result

def SAPFormDHSFitData_Init(projInfo):
    result = []
    for v in GBRange(0, DP_PrevSurveyMax):
        result.append(getPrevSurveyDict(projInfo['firstYr']).copy())
    return result


def getTotal45q15(projInfo, countryData):
    
    hasData = False
    result = getList_year(projInfo['finalYrIdx'])
    if '45q15WPP' in countryData:
        defaultData = countryData['45q15WPP']
        for year in defaultData:
            yr = round(float(year))
            if yr in GBRange(projInfo['firstYr'], projInfo['finalYr']):
                hasData = True
                t = getYearIdx(yr, projInfo['firstYr'])
                result[t] = defaultData[year]
    return hasData, result

def Total45q15_Init(projInfo, countryData):
    hasData, result = getTotal45q15(projInfo, countryData)
    return result

def Total45q15_Meta_Init(projInfo, countryData):
    hasData, result = getTotal45q15(projInfo, countryData)
    return {
        'default' : result, 
        'hasData' : hasData
        }
    
def KeyPops_Init():
    result =  {
        'data' : np.zeros((DP_KP_NewInfs + 1, DP_KP_TG + 1)).tolist(),
        'year' : 0,
        'fName': '',
    }
    
    return result

def getPregWomenPrev(projInfo, countryData):
    result = getList_year(projInfo['finalYrIdx'])
    hasData = False
    if 'Preg_woman_prev' in countryData:
        dataYear = countryData['Preg_woman_prev']['year']
        if dataYear in GBRange(projInfo['firstYr'], projInfo['finalYr']):
            hasData = True
            t = getYearIdx(dataYear, projInfo['firstYr'])
            result[t] = countryData['Preg_woman_prev']['Prevalence'] * 100
    return hasData, result

def PregWomenPrev_Init(projInfo, countryData):
    hasData, result = getPregWomenPrev(projInfo, countryData)
    return result
    
def PregWomenPrev_Meta_Init(projInfo, countryData):
    hasData, values = getPregWomenPrev(projInfo, countryData)
    result = {
        'defaultValue' : values,
        'hasData' : hasData,
    }
    return result

def PrevSurvey_Init(projInfo):
    result = []
    for v in GBRange(0, DP_PrevSurveyMax):
        result.append(getPrevSurveyDict(projInfo['firstYr']).copy())
        result[v]['name'] = 'Survey' + ' ' + str(v)
    return result

def PrevSurvey_Meta_Init(projInfo, AMCountryData, AMSubnatData):
    DHSPrevalenceByAge = None
    result = []
    
    if 'DHSPrevalenceByAge' in AMSubnatData:
        DHSPrevalenceByAge = AMSubnatData['DHSPrevalenceByAge']
    elif 'DHSPrevalenceByAge' in AMCountryData:
        DHSPrevalenceByAge = AMCountryData['DHSPrevalenceByAge']

     
    if DHSPrevalenceByAge:
        for survey in DHSPrevalenceByAge:
            prevSurvey = getPrevSurveyDict(survey['surveyYear']).copy() 
            prevSurvey['name'] = survey['surveyName']
            prevSurvey['used'] = True
            for sex in GBRange(GB_Male, GB_Female):
                for dt in GBRange(DP_Percent, DP_WeightedSampleSize):
                    for a in GBRange(DP_A0_4, DP_A55_59): 
                        prevSurvey['data'][sex][dt][a] = survey['values'][sex][dt][a]
            result.append(prevSurvey)

    return {
        'default' : result, 
    }

def ARTCovSurvey_Init(projInfo): 
    result = []
    for v in GBRange(0, DP_PrevSurveyMax):
        result.append(getARTCovSurveyDict(projInfo['firstYr']).copy())
        result[v]['name'] = 'Survey' + ' ' + str(v)

    return result

def ARTCovSurvey_Meta_Init(projInfo, countryData):
    result = []
    if 'ARTCoverageSurveys' in countryData:
        result = countryData['ARTCoverageSurveys']
    return {'default' : result}

def AllCauseMortality_Meta_Init(projInfo, countryData):
    result = getList_sex_5yrAge_year(projInfo['finalYrIdx'])
    hasData = False

    if 'MortalityByAge' in countryData:
        defaultData = countryData['MortalityByAge']
        for data in defaultData:
            if ((data['year'] in GBRange(projInfo['firstYr'], projInfo['finalYr'])) and 
               (data['cause'] == 'tot') and (data['sex'] in [GB_Male, GB_Female])):
                t = getYearIdx(data['year'], projInfo['firstYr'])
                hasData = True
                for age in GBRange(GB_A0_4, GB_MAX_AGE):
                    result[data['sex']][age][t] = data['values'][age]

    return {
        'default' : result, 
        'hasData' : hasData
        }

def AIDSMortality_Meta_Init(projInfo, countryData):
    result = getList_sex_5yrAge_year(projInfo['finalYrIdx'])
    hasData = False

    if 'MortalityByAge' in countryData:
        defaultData = countryData['MortalityByAge']
        for data in defaultData:
            if ((data['year'] in GBRange(projInfo['firstYr'], projInfo['finalYr'])) and 
               (data['cause'] == 'HIV') and (data['sex'] in [GB_Male, GB_Female])):
                t = getYearIdx(data['year'], projInfo['firstYr'])
                hasData = True
                for age in GBRange(GB_A0_4, GB_MAX_AGE):
                    result[data['sex']][age][t] = data['values'][age]

    return {
        'default' : result, 
        'hasData' : hasData
        }

def PercentOfPop_Init(projInfo):
    result = np.full(projInfo['finalYrIdx'] + 1, 100.0).tolist()
    return result

def FutureART_Init():
    result = {
        'lastYr' : 0,
        'firstYr3': 0,
        'targetYr': 0,
        'PerRedNew' : 0,
        'PerRedTot' : 0,
        'TargetNew' : 0,
        'TargetTot' : 0,
    }
    return result

# def DALYBaseYear_Init(projInfo):
#     if (projInfo['firstYr'] <= 2015):
#         result = 2015
#     else:
#         result = projInfo['firstYr']
#     return result

def IncidenceByFit_Init(projInfo, easyAIMData):
    result = np.zeros((DP_ECDCOpt + 1, projInfo['finalYrIdx'] + 1))#.tolist()  
    
    if 'Incidence' in easyAIMData:
        Incidence = easyAIMData['Incidence']  
        dataFirstYear = Incidence['startYear'] 
        dataFinalYear = Incidence['endYear'] 
        for yr in GBRange(projInfo['firstYr'], projInfo['finalYr']):
            t = getYearIdx(yr, projInfo['firstYr'])
            result[DP_DirectIncidenceInputOpt][t] = Incidence['values'][getYearIndexFromT(dataFirstYear, dataFinalYear, yr)]
    return result.tolist()

# def EPPPrevAdj_Init(projInfo, easyAIMData):
#     return not ('Incidence' in easyAIMData)

# def HIVSexRatioFromEPP_Init(projInfo):
#     result = np.zeros(projInfo['finalYrIdx'] + 1).tolist()
#     return result

def AdultPrevalence_Init(projInfo, easyAIMData):
    result = getList_year(projInfo['finalYrIdx'])
     
    if 'AdultHIVPrev' in easyAIMData:
        AdultHIVPrev = easyAIMData['AdultHIVPrev']  
        dataFirstYear = AdultHIVPrev['startYear'] 
        dataFinalYear = AdultHIVPrev['endYear'] 
        for yr in GBRange(projInfo['firstYr'], projInfo['finalYr']):
            t = getYearIdx(yr, projInfo['firstYr'])
            result[t] = AdultHIVPrev['values'][getYearIndexFromT(dataFirstYear, dataFinalYear, yr)]
    return result

def EPPEpiName_Init():
    result = [] #np.full(DP_MaxEpidemic + 1, '').tolist()
    return result

def EPPEpidemic_Init():
    result = [] #np.full(DP_MaxEpidemic + 1, '').tolist()
    return result

def EPPPrevData_Init(projInfo):
    result = [] #np.zeros((DP_MaxEpidemic + 1, projInfo['finalYrIdx'] + 1)).tolist()
    return result

def EPPIncData_Init(projInfo):
    result = [] #np.zeros((DP_MaxEpidemic + 1, projInfo['finalYrIdx'] + 1)).tolist()
    return result

def EPPPopData_Init(projInfo):
    result = [] #np.zeros((DP_MaxEpidemic + 1, projInfo['finalYrIdx'] + 1)).tolist()
    return result

def EPPSexRatio_Init(projInfo):
    result = [] #np.zeros((DP_MaxEpidemic + 1, projInfo['finalYrIdx'] + 1)).tolist()
    return result

def EPPBaseYrPop_Init():
    result = [] #np.zeros(DP_MaxEpidemic + 1).tolist()
    return result

def EPPIDUMortality_Init():
    result = [] #np.zeros(DP_MaxEpidemic + 1).tolist()
    # result[DP_MinEpidemic] = 2.5
    return result

def EPPPathInfo_Init():
    result = [] #np.full(DP_MaxEpidemic + 1, {
        # 'IsTotal'  : False,
        # 'FullName' : '',
    # }).tolist()
    
    return result

def YrPtPrevalence_WB_Init():
    result = '' #np.full(DP_MaxEpidemic + 1, '').tolist()
    return result

def PropIDU_WB_Init(projInfo):
    result = [] #np.zeros((DP_MaxEpidemic + 1, projInfo['finalYrIdx'] + 1)).tolist()
    return result

def ChAged14ByCD4Cat_Init(projInfo):
    result = np.zeros((GB_Female + 1, DP_CD4_Ped_LT200 + 1, DP_GT12monthsTreat + 1, projInfo['finalYrIdx'] + 1)).tolist()
    return result

def NewHIVInfByRiskGroup_Init(projInfo):
    result = [] #np.zeros((DP_MaxEpidemic + 1, projInfo['finalYrIdx'] + 1)).tolist()
    return result

def HIVPopByRiskGroup_Init(projInfo):
    result = [] #np.zeros((DP_MaxEpidemic + 1, projInfo['finalYrIdx'] + 1)).tolist()
    return result

def CD4Distribution_Init(projInfo):
    result = np.zeros((GB_Female + 1, DP_H_Max + 1, DP_OnART + 1, projInfo['finalYrIdx'] + 1)).tolist()
    return result

def CD4Distribution15_49_Init(projInfo):
    result = np.zeros((GB_Female + 1, DP_H_Max + 1, DP_OnART + 1, projInfo['finalYrIdx'] + 1)).tolist()
    return result

def CD4DistributionChild_Init(projInfo):
    result = np.zeros((GB_Female + 1, DP_CD4_5t14 + 1,DP_CD4_Per_LT5 + 1, DP_D_ARTgt12m + 1, DP_OnART + 1, projInfo['finalYrIdx'] + 1)).tolist()
    return result

def NewARTPatAlloc_Init(easyAIMData):
    
    result = np.zeros(DP_AdvOpt_ART_PropElig + 1).tolist()
    result[DP_AdvOpt_ART_ExpMort] = 0.2
    result[DP_AdvOpt_ART_PropElig] = 0.8

    if 'NewARTPatAllocation' in easyAIMData:
        # if bool(easyAIMData['NewARTPatAllocation']['NotDefault']):
        result[DP_AdvOpt_ART_ExpMort] = easyAIMData['NewARTPatAllocation']['ExpectedMortality']
        result[DP_AdvOpt_ART_PropElig] = easyAIMData['NewARTPatAllocation']['ProportionEligible']

    return result

def NewARTPatAllocMethod_Init(easyAIMData):
    
    result = DP_AdvOpt_ART_MixedRelWeight

    if 'NewARTPatAllocation' in easyAIMData:
        # if bool(easyAIMData['NewARTPatAllocation']['NotDefault']):
        result = easyAIMData['NewARTPatAllocation']['NewARTPatAllocationMethod']

    return result

# def DefaultDataCheck_Init():
#     return {
#         'PMTCT' : False,
#         'ARTPed' : False,
#         'ARTMale' : False,
#         'ARTFemale' : False,
#         'KOSChild' : False,
#         'KOSMale' : False,
#         'KOSFemale' : False,
#         'VSChild' : False,
#         'VSMale' : False,
#         'VSFemale' : False,
#         'ChildProgression' : False,
#         'ChildDistribution' : False,
#         'ChildMort' : False,
#         'ChildARTMort' : False,
#         'AdultProg' : False,
#         'AdultDist' : False,
#         'AdultMort' : False,
#         'AdultARTMort' : False,
#         'FRRCD4' : False,
#         'FRRAge' : False,
#         'CdArt' : False,
#         'MTCTRate' : False,
#         'AllocDef' : False,
#         'Shiny90Valid' : False,
#         'UAValid' : False,
#         'AdultARTCov' : False,
#         'ChildARTCov' : False,
#         'PMTCTCov' : False,
#         }

def ValidationControlMV_Init(projInfo):
    year = min(max(2000, projInfo['firstYr']), projInfo['finalYr'])
    result = {
        'sexValue' : GB_BothSexes,
        'yearIdxValue' : getYearIdx(year, projInfo['firstYr'])
    }
    return result

def PrevalenceValidationControlMV_Init(projInfo):
    result = {
        'sexValue' : DP_PrevSurvey1,
        'surveyValue' : DP_PrevSurvey1,
    }
    return result

def ValidationARTCovSelection_Init():
    result = {
        'sexValue' : GB_Male,
        'surveyValue' : DP_PrevSurvey1,
        'ageGroupValue' : 0,
    }
    return result

def ValidationWaterfall_Init(projInfo):
    tempDict = {
        'NewlyOnART' : DPNotAvail,    
        'ReEngaged' : DPNotAvail,     
        'Died' : DPNotAvail,         
        'Interrupted' : DPNotAvail,    
    }
    result = [tempDict for i in GBRange(0, projInfo['finalYrIdx'])]

    return result
