from os import environ
import numpy as np

import SpectrumCommon.Const.GB as gbc
import SpectrumCommon.Modvars.GB.GBUtil as gbu

from AvenirCommon.Database import GB_get_db_json, GB_file_exists
import AvenirCommon.Util as acu

import SpectrumCommon.Const.RP.RPConst as rpc
import SpectrumCommon.Const.RP.RPConstLink as rpcl
import SpectrumCommon.Const.RP.RPDatabaseConst as rpdbc

import SpectrumCommon.Const.RP.RPModVarFields as rpmvf
import SpectrumCommon.Modvars.RP.RPModVarUtil as rpmvu

#######################################################################################################
#                                                                                                     #
#                                       Database loading methods                                      #
#                                                                                                     #
#######################################################################################################

def RP_load_country_defaults_DB(country_ID):
    country_defaults_DB_file_name = rpc.RP_COUNTRY_DEFAULTS_DB_DIR.replace('\\', '/') + '/' + country_ID + '_' + rpc.RP_COUNTRY_DEFAULTS_DB_CURR_VERSION + '.' + gbc.GB_JSON 
    
    if GB_file_exists(environ[gbc.GB_SPECT_MOD_DATA_CONN_ENV], gbc.GB_RP_CONTAINER, country_defaults_DB_file_name):
        country_defaults_DB = GB_get_db_json(environ[gbc.GB_SPECT_MOD_DATA_CONN_ENV], gbc.GB_RP_CONTAINER, country_defaults_DB_file_name) 
    
    else:
        country_defaults_DB = gbc.GB_NOT_FOUND

    return country_defaults_DB

def RP_load_country_defaults_sources_DB(country_ID):
    country_defaults_sources_DB_file_name = rpc.RP_COUNTRY_DEFAULTS_SOURCES_DB_DIR.replace('\\', '/') + '/' + country_ID + '_' + rpc.RP_COUNTRY_DEFAULTS_SOURCES_DB_CURR_VERSION + '.' + gbc.GB_JSON 

    if GB_file_exists(environ[gbc.GB_SPECT_MOD_DATA_CONN_ENV], gbc.GB_RP_CONTAINER, country_defaults_sources_DB_file_name):
        country_defaults_sources_DB = GB_get_db_json(environ[gbc.GB_SPECT_MOD_DATA_CONN_ENV], gbc.GB_RP_CONTAINER, country_defaults_sources_DB_file_name) 
    
    else:
        country_defaults_sources_DB = gbc.GB_NOT_FOUND

    return country_defaults_sources_DB

def RP_load_contraceptive_use_med_DB(country_ID):
    contraceptive_use_med_DB_file_name = rpc.RP_CONTRACEPTIVE_USE_MED_DB_DIR.replace('\\', '/') + '/' + country_ID + '_' + rpc.RP_CONTRACEPTIVE_USE_MED_DB_CURR_VERSION + '.' + gbc.GB_JSON 

    if GB_file_exists(environ[gbc.GB_SPECT_MOD_DATA_CONN_ENV], gbc.GB_RP_CONTAINER, contraceptive_use_med_DB_file_name):
        contraceptive_use_med_DB = GB_get_db_json(environ[gbc.GB_SPECT_MOD_DATA_CONN_ENV], gbc.GB_RP_CONTAINER, contraceptive_use_med_DB_file_name) 
    
    else:
        contraceptive_use_med_DB = gbc.GB_NOT_FOUND

    return contraceptive_use_med_DB

def RP_load_contraceptive_use_acc_DB(country_ID):
    contraceptive_use_acc_DB_file_name = rpc.RP_CONTRACEPTIVE_USE_ACC_DB_DIR.replace('\\', '/') + '/' + country_ID + '_' + rpc.RP_CONTRACEPTIVE_USE_ACC_DB_CURR_VERSION + '.' + gbc.GB_JSON 

    if GB_file_exists(environ[gbc.GB_SPECT_MOD_DATA_CONN_ENV], gbc.GB_RP_CONTAINER, contraceptive_use_acc_DB_file_name):
        contraceptive_use_acc_DB = GB_get_db_json(environ[gbc.GB_SPECT_MOD_DATA_CONN_ENV], gbc.GB_RP_CONTAINER, contraceptive_use_acc_DB_file_name) 
    
    else:
        contraceptive_use_acc_DB = gbc.GB_NOT_FOUND

    return contraceptive_use_acc_DB

def RP_load_urban_DB(country_ID):
    urban_DB_file_name = rpc.RP_URBAN_DB_DIR.replace('\\', '/') + '/' + country_ID + '_' + rpc.RP_URBAN_DB_CURR_VERSION + '.' + gbc.GB_JSON 

    if GB_file_exists(environ[gbc.GB_SPECT_MOD_DATA_CONN_ENV], gbc.GB_RP_CONTAINER, urban_DB_file_name):
        urban_DB = GB_get_db_json(environ[gbc.GB_SPECT_MOD_DATA_CONN_ENV], gbc.GB_RP_CONTAINER, urban_DB_file_name) 
    
    else:
        urban_DB = gbc.GB_NOT_FOUND

    return urban_DB

def RP_load_SSP1_DB(country_ID):
    SSP1_DB_file_name = rpc.RP_SSP1_TEMPS_DB_DIR.replace('\\', '/') + '/' + country_ID + '_' + rpc.RP_SSP1_TEMPS_DB_CURR_VERSION + '.' + gbc.GB_JSON 

    if GB_file_exists(environ[gbc.GB_SPECT_MOD_DATA_CONN_ENV], gbc.GB_RP_CONTAINER, SSP1_DB_file_name):
        SSP1_DB = GB_get_db_json(environ[gbc.GB_SPECT_MOD_DATA_CONN_ENV], gbc.GB_RP_CONTAINER, SSP1_DB_file_name) 
    
    else:
        SSP1_DB = gbc.GB_NOT_FOUND

    return SSP1_DB

def RP_load_SSP2_DB(country_ID):
    SSP2_DB_file_name = rpc.RP_SSP2_TEMPS_DB_DIR.replace('\\', '/') + '/' + country_ID + '_' + rpc.RP_SSP2_TEMPS_DB_CURR_VERSION + '.' + gbc.GB_JSON 

    if GB_file_exists(environ[gbc.GB_SPECT_MOD_DATA_CONN_ENV], gbc.GB_RP_CONTAINER, SSP2_DB_file_name):
        SSP2_DB = GB_get_db_json(environ[gbc.GB_SPECT_MOD_DATA_CONN_ENV], gbc.GB_RP_CONTAINER, SSP2_DB_file_name) 
    
    else:
        SSP2_DB = gbc.GB_NOT_FOUND

    return SSP2_DB

def RP_load_SSP3_DB(country_ID):
    SSP3_DB_file_name = rpc.RP_SSP3_TEMPS_DB_DIR.replace('\\', '/') + '/' + country_ID + '_' + rpc.RP_SSP3_TEMPS_DB_CURR_VERSION + '.' + gbc.GB_JSON 

    if GB_file_exists(environ[gbc.GB_SPECT_MOD_DATA_CONN_ENV], gbc.GB_RP_CONTAINER, SSP3_DB_file_name):
        SSP3_DB = GB_get_db_json(environ[gbc.GB_SPECT_MOD_DATA_CONN_ENV], gbc.GB_RP_CONTAINER, SSP3_DB_file_name) 
    
    else:
        SSP3_DB = gbc.GB_NOT_FOUND

    return SSP3_DB

def RP_load_SSP5_DB(country_ID):
    SSP5_DB_file_name = rpc.RP_SSP5_TEMPS_DB_DIR.replace('\\', '/') + '/' + country_ID + '_' + rpc.RP_SSP5_TEMPS_DB_CURR_VERSION + '.' + gbc.GB_JSON 

    if GB_file_exists(environ[gbc.GB_SPECT_MOD_DATA_CONN_ENV], gbc.GB_RP_CONTAINER, SSP5_DB_file_name):
        SSP5_DB = GB_get_db_json(environ[gbc.GB_SPECT_MOD_DATA_CONN_ENV], gbc.GB_RP_CONTAINER, SSP5_DB_file_name) 
    
    else:
        SSP5_DB = gbc.GB_NOT_FOUND

    return SSP5_DB

#######################################################################################################
#                                                                                                     #
#                                       Cost inputs                                                   #
#                                                                                                     #
#######################################################################################################

def RP_set_sector_defaults(country_defaults_DB, urban_DB, sectors_mv, first_year, final_year):
    first_year_idx = gbu.getYearIdx(first_year, first_year)
    final_year_idx = gbu.getYearIdx(final_year, first_year)

    education_sector_rec = rpmvu.get_RP_sector_rec(sectors_mv, rpc.RP_EDUCATION_SECTOR_MST_ID)
    health_sector_rec = rpmvu.get_RP_sector_rec(sectors_mv, rpc.RP_HEALTH_SECTOR_MST_ID)
    WASH_sector_rec = rpmvu.get_RP_sector_rec(sectors_mv, rpc.RP_WASH_SECTOR_MST_ID)
    food_security_sector_rec = rpmvu.get_RP_sector_rec(sectors_mv, rpc.RP_FOOD_SECURITY_SECTOR_MST_ID)
    urbanization_sector_rec = rpmvu.get_RP_sector_rec(sectors_mv, rpc.RP_URBANIZATION_SECTOR_MST_ID)
    energy_sector_rec = rpmvu.get_RP_sector_rec(sectors_mv, rpc.RP_ENERGY_SECTOR_MST_ID)
    economic_sector_rec = rpmvu.get_RP_sector_rec(sectors_mv, rpc.RP_ECONOMIC_SECTOR_MST_ID)

    # Education

    rpmvu.set_RP_edu_sector_prim_sch_start_age(education_sector_rec, country_defaults_DB[rpdbc.RP_AGE_START_PRIM_KEY_CDDB])
    rpmvu.set_RP_edu_sector_prim_sch_end_age(education_sector_rec, country_defaults_DB[rpdbc.RP_AGE_END_PRIM_KEY_CDDB])
    rpmvu.set_RP_edu_sector_sec_sch_start_age(education_sector_rec, country_defaults_DB[rpdbc.RP_AGE_START_SEC_KEY_CDDB])
    rpmvu.set_RP_edu_sector_sec_sch_end_age(education_sector_rec, country_defaults_DB[rpdbc.RP_AGE_END_SEC_KEY_CDDB])
    # rpmvu.set_RP_edu_sector_student_per_teacher_prim(education_sector_rec, country_defaults_DB[rpdbc.RP_TEACHER_RATIO_PRIM_KEY_CDDB])
    rpmvu.set_RP_edu_sector_avg_ann_teacher_sal_prim_GDP_ratio(education_sector_rec, country_defaults_DB[rpdbc.RP_PRIM_TEACHER_SALARY_KEY_CDDB])
    # rpmvu.set_RP_edu_sector_avg_ann_teacher_sal_sec(education_sector_rec, country_defaults_DB[rpdbc.RP_SEC_TEACHER_SALARY_KEY_CDDB])
    rpmvu.set_RP_edu_sector_prim_spend_per_student_perc_GDP(education_sector_rec, country_defaults_DB[rpdbc.RP_PRIM_COSTS_KEY_CDDB])
    rpmvu.set_RP_edu_sector_sec_spend_per_student_perc_GDP(education_sector_rec, country_defaults_DB[rpdbc.RP_SEC_COSTS_KEY_CDDB])

    goal_rec = rpmvu.get_RP_goal_rec(education_sector_rec, rpc.RP_EDU_1_INCR_PRIM_ENROLL_GOAL_MST_ID)

    for subgoal_ID in rpc.RP_EDU_1_SUBGOAL_MST_IDS:
        subgoal_rec = rpmvu.get_RP_subgoal_rec(goal_rec, subgoal_ID)

        if subgoal_rec != gbc.GB_NOT_FOUND:
            # Base year values are the same for all subgoals and different for each sex
            rpmvu.set_RP_subgoal_resulting_change_by_sex(subgoal_rec, gbc.GB_Female, first_year_idx, country_defaults_DB[rpdbc.RP_PRIM_ENROLL_FEMALES_KEY_CDDB])
            rpmvu.set_RP_subgoal_resulting_change_by_sex(subgoal_rec, gbc.GB_Male, first_year_idx, country_defaults_DB[rpdbc.RP_PRIM_ENROLL_MALES_KEY_CDDB])

            # Final year values vary by subgoal but are the same for each sex
            for sex in [gbc.GB_Male, gbc.GB_Female]:

                if subgoal_ID == rpc.RP_EDU_1_1_UNIVERSAL_PRIMARY_EDU_SUBG_MST_ID:
                    rpmvu.set_RP_subgoal_resulting_change_by_sex(subgoal_rec, sex, final_year_idx, 100)

                elif subgoal_ID == rpc.RP_EDU_1_2_ACHIEVE_GENDER_EQUALITY_SUBG_MST_ID:
                    value = max(country_defaults_DB[rpdbc.RP_PRIM_ENROLL_FEMALES_KEY_CDDB], country_defaults_DB[rpdbc.RP_PRIM_ENROLL_MALES_KEY_CDDB])
                    rpmvu.set_RP_subgoal_resulting_change_by_sex(subgoal_rec, sex, final_year_idx, value)
            
    goal_rec = rpmvu.get_RP_goal_rec(education_sector_rec, rpc.RP_EDU_2_INCR_SEC_ENROLL_GOAL_MST_ID)

    for subgoal_ID in rpc.RP_EDU_2_SUBGOAL_MST_IDS:
        subgoal_rec = rpmvu.get_RP_subgoal_rec(goal_rec, subgoal_ID)

        if subgoal_rec != gbc.GB_NOT_FOUND:
            # Base year values are the same for all subgoals and different for each sex
            rpmvu.set_RP_subgoal_resulting_change_by_sex(subgoal_rec, gbc.GB_Female, first_year_idx, country_defaults_DB[rpdbc.RP_SEC_ENROLL_FEMALES_KEY_CDDB])
            rpmvu.set_RP_subgoal_resulting_change_by_sex(subgoal_rec, gbc.GB_Male, first_year_idx, country_defaults_DB[rpdbc.RP_SEC_ENROLL_MALES_KEY_CDDB])

            # Final year values are the same for each subgoal and sex
            for sex in [gbc.GB_Male, gbc.GB_Female]:

                if subgoal_ID == rpc.RP_EDU_2_1_UNIVERSAL_PRIMARY_EDU_SUBG_MST_ID:
                    rpmvu.set_RP_subgoal_resulting_change_by_sex(subgoal_rec, sex, final_year_idx, 100)

                elif subgoal_ID == rpc.RP_EDU_2_2_ACHIEVE_GENDER_EQUALITY_SUBG_MST_ID:
                    rpmvu.set_RP_subgoal_resulting_change_by_sex(subgoal_rec, sex, final_year_idx, 
                        max(country_defaults_DB[rpdbc.RP_SEC_ENROLL_FEMALES_KEY_CDDB], country_defaults_DB[rpdbc.RP_SEC_ENROLL_MALES_KEY_CDDB])
                    )

    goal_rec = rpmvu.get_RP_goal_rec(education_sector_rec, rpc.RP_EDU_3_IMPR_STUDENT_TEACHER_RATIO_GOAL_MST_ID)
    
    subgoal_rec = rpmvu.get_RP_subgoal_rec(goal_rec, rpc.RP_EDU_3_1_REC_RATIO_SUBG_MST_ID)
    if subgoal_rec != gbc.GB_NOT_FOUND:
        rpmvu.set_RP_subgoal_resulting_change(subgoal_rec, first_year_idx, country_defaults_DB[rpdbc.RP_TEACHER_RATIO_PRIM_KEY_CDDB])
        rpmvu.set_RP_subgoal_resulting_change(subgoal_rec, final_year_idx, 25)

    subgoal_rec = rpmvu.get_RP_subgoal_rec(goal_rec, rpc.RP_EDU_3_2_USER_SPEC_RATIO_SUBG_MST_ID)
    if subgoal_rec != gbc.GB_NOT_FOUND:
        rpmvu.set_RP_subgoal_resulting_change(subgoal_rec, first_year_idx, country_defaults_DB[rpdbc.RP_TEACHER_RATIO_PRIM_KEY_CDDB])

    # Health

    rpmvu.set_RP_health_sector_avg_unit_cost_skilled_deliv(health_sector_rec, country_defaults_DB[rpdbc.RP_SKILLED_BIRTH_COSTS_KEY_CDDB])
    rpmvu.set_RP_health_sector_avg_unit_cost_ANC_4_plus_visits(health_sector_rec, country_defaults_DB[rpdbc.RP_ANC_COSTS_KEY_CDDB])
    rpmvu.set_RP_health_sector_perc_skilled_hlth_prof_doctors(health_sector_rec, country_defaults_DB[rpdbc.RP_PERC_DOCTORS_KEY_CDDB])
    rpmvu.set_RP_health_sector_perc_skilled_hlth_prof_nurses(health_sector_rec, country_defaults_DB[rpdbc.RP_PERC_NURSES_KEY_CDDB])
    rpmvu.set_RP_health_sector_avg_salary_doctors(health_sector_rec, country_defaults_DB[rpdbc.RP_DOCTOR_SALARY_PUBLIC_KEY_CDDB])
    rpmvu.set_RP_health_sector_avg_salary_nurses(health_sector_rec, country_defaults_DB[rpdbc.RP_NURSE_SALARY_PUBLIC_KEY_CDDB])

    goal_rec = rpmvu.get_RP_goal_rec(health_sector_rec, rpc.RP_HLTH_1_INCR_PERC_BIRTHS_SKILLED_GOAL_MST_ID)

    for subgoal_ID in rpc.RP_HLTH_1_SUBGOAL_MST_IDS:
        subgoal_rec = rpmvu.get_RP_subgoal_rec(goal_rec, subgoal_ID)

        if subgoal_rec != gbc.GB_NOT_FOUND:
            # Base year values are the same for all subgoals
            rpmvu.set_RP_subgoal_resulting_change(subgoal_rec, first_year_idx, country_defaults_DB[rpdbc.RP_SKILLED_BIRTHS_KEY_CDDB])
    
            if subgoal_ID == rpc.RP_HLTH_1_1_ALL_SUBG_MST_ID:
                rpmvu.set_RP_subgoal_resulting_change(subgoal_rec, final_year_idx, 100)

            elif subgoal_ID == rpc.RP_HLTH_1_2_X_PERC_BASED_Y_TARGETS_SUBG_MST_ID:
                rpmvu.set_RP_subgoal_resulting_change(subgoal_rec, final_year_idx, 90)

    goal_rec = rpmvu.get_RP_goal_rec(health_sector_rec, rpc.RP_HLTH_2_INCR_PERC_PREG_WOMEN_REC_VISITS_GOAL_MST_ID)

    for subgoal_ID in rpc.RP_HLTH_2_SUBGOAL_MST_IDS:
        subgoal_rec = rpmvu.get_RP_subgoal_rec(goal_rec, subgoal_ID)

        if subgoal_rec != gbc.GB_NOT_FOUND:
            # Base year values are the same for all subgoals
            rpmvu.set_RP_subgoal_resulting_change(subgoal_rec, first_year_idx, country_defaults_DB[rpdbc.RP_ANC_4_PLUS_KEY_CDDB])
    
            if subgoal_ID == rpc.RP_HLTH_2_1_ALL_SUBG_MST_ID:
                rpmvu.set_RP_subgoal_resulting_change(subgoal_rec, final_year_idx, 100)

            elif subgoal_ID == rpc.RP_HLTH_2_2_X_PERC_BASED_Y_TARGETS_SUBG_MST_ID:
                rpmvu.set_RP_subgoal_resulting_change(subgoal_rec, final_year_idx, 90)

    goal_rec = rpmvu.get_RP_goal_rec(health_sector_rec, rpc.RP_HLTH_3_INCR_ACCESS_HEALTH_PROF_GOAL_MST_ID)

    for subgoal_ID in rpc.RP_HLTH_3_SUBGOAL_MST_IDS:
        subgoal_rec = rpmvu.get_RP_subgoal_rec(goal_rec, subgoal_ID)

        if subgoal_rec != gbc.GB_NOT_FOUND:
            # Base year values are the same for all subgoals
            rpmvu.set_RP_subgoal_resulting_change(subgoal_rec, first_year_idx, country_defaults_DB[rpdbc.RP_PROFS_KEY_CDDB])
    
            if subgoal_ID == rpc.RP_HLTH_3_1_WHO_REC_SUBG_MST_ID:
                rpmvu.set_RP_subgoal_resulting_change(subgoal_rec, final_year_idx, 2.5)

    # WASH

    rpmvu.set_RP_WASH_sector_cap_costs_per_HH_impr_water(WASH_sector_rec, country_defaults_DB[rpdbc.RP_CAP_COST_PP_IMPROVED_WATER_KEY_CDDB])
    # Defunct?? rpmvu.set_RP_WASH_sector_ann_cost_menstrual_hlth_comm(WASH_sector_rec, country_defaults_DB[rpdbc.RP_UNIT_COST_1000_L_WATER_CDDB])
    rpmvu.set_RP_WASH_sector_cap_costs_per_HH_impr_sani(WASH_sector_rec, country_defaults_DB[rpdbc.RP_CAP_COST_PP_IMPROVED_SANI_KEY_CDDB])

    goal_rec = rpmvu.get_RP_goal_rec(WASH_sector_rec, rpc.RP_WASH_1_INCR_ACCESS_IMPR_WATER_SRC_GOAL_MST_ID)

    for subgoal_ID in rpc.RP_WASH_1_SUBGOAL_MST_IDS:
        subgoal_rec = rpmvu.get_RP_subgoal_rec(goal_rec, subgoal_ID)

        if subgoal_rec != gbc.GB_NOT_FOUND:
            # Base year values are the same for all subgoals
            rpmvu.set_RP_subgoal_resulting_change(subgoal_rec, first_year_idx, country_defaults_DB[rpdbc.RP_PERC_IMPROVED_WATER_SOURCE_KEY_CDDB])
    
            if subgoal_ID == rpc.RP_WASH_1_1_UNIVERSAL_ACCESS_SUBG_MST_ID:
                rpmvu.set_RP_subgoal_resulting_change(subgoal_rec, final_year_idx, 100)

    goal_rec = rpmvu.get_RP_goal_rec(WASH_sector_rec, rpc.RP_WASH_2_INCR_ACCESS_IMPR_SANI_GOAL_MST_ID)

    for subgoal_ID in rpc.RP_WASH_2_SUBGOAL_MST_IDS:
        subgoal_rec = rpmvu.get_RP_subgoal_rec(goal_rec, subgoal_ID)

        if subgoal_rec != gbc.GB_NOT_FOUND:
            # Base year values are the same for all subgoals
            rpmvu.set_RP_subgoal_resulting_change(subgoal_rec, first_year_idx, country_defaults_DB[rpdbc.RP_PERC_IMPROVED_SANI_KEY_CDDB])
    
            if subgoal_ID == rpc.RP_WASH_2_1_UNIVERSAL_ACCESS_SUBG_MST_ID:
                rpmvu.set_RP_subgoal_resulting_change(subgoal_rec, final_year_idx, 100)

    # Food security

    production = country_defaults_DB[rpdbc.RP_STAPLE_PRODUCTION_KEY_CDDB]
    area = country_defaults_DB[rpdbc.RP_AREA_HARVESTED_KEY_CDDB]
    rpmvu.set_RP_food_sector_prim_staple_crop(food_security_sector_rec, country_defaults_DB[rpdbc.RP_DOMINANT_CROP_KEY_CDDB])
    rpmvu.set_RP_food_sector_agricult_land(food_security_sector_rec, country_defaults_DB[rpdbc.RP_AGRICULTURAL_LAND_KEY_CDDB])
    rpmvu.set_RP_food_sector_crop_land(food_security_sector_rec, country_defaults_DB[rpdbc.RP_CROPLAND_HECTARES_KEY_CDDB])
    rpmvu.set_RP_food_sector_staple_crop_prod_baseline(food_security_sector_rec, country_defaults_DB[rpdbc.RP_STAPLE_PRODUCTION_KEY_CDDB])
    rpmvu.set_RP_food_sector_area_harv_staple_crop(food_security_sector_rec, country_defaults_DB[rpdbc.RP_AREA_HARVESTED_KEY_CDDB])
    rpmvu.set_RP_food_sector_tonnes_harv_perc_hect(food_security_sector_rec,  (production / area) if area > 0 else 0)
    rpmvu.set_RP_food_sector_ann_kg_per_year_consump_staple_crop(food_security_sector_rec, country_defaults_DB[rpdbc.RP_STAPLE_ANNUAL_CONSUMP_PER_CAP_KEY_CDDB])
    rpmvu.set_RP_food_sector_prod_costs_staple_crop(food_security_sector_rec, country_defaults_DB[rpdbc.RP_PROD_COST_PER_TON_DOMINANT_CROP_KEY_CDDB])
    rpmvu.set_RP_food_sector_daily_cost_food_aid(food_security_sector_rec, country_defaults_DB[rpdbc.RP_DAILY_COST_FOOD_AID_PER_PERSON_KEY_CDDB])

    # base_pop is bsaed on the Goal scenario, so we would have to calculate before setting the default?
    # ('Review Defaults'!F53*1000)/('Review Defaults'!F57*DemProj!B6)
    # (country_defaults_DB[rpdbc.RP_STAPLE_PRODUCTION_CDDB] * 1000) / (country_defaults_DB[rpdbc.RP_STAPLE_ANNUAL_CONSUMP_PER_CAP_CDDB] * base_pop)

    goal_rec = rpmvu.get_RP_goal_rec(food_security_sector_rec, rpc.RP_FOOD_1_INCR_PROP_DOM_PROD_STAPLE_CROP_GOAL_MST_ID)

    for subgoal_ID in rpc.RP_FOOD_1_SUBGOAL_MST_IDS:
        subgoal_rec = rpmvu.get_RP_subgoal_rec(goal_rec, subgoal_ID)

        if subgoal_rec != gbc.GB_NOT_FOUND:
            # Base year value - see commented out code above...
    
            if subgoal_ID == rpc.RP_FOOD_1_1_ALL_DOMEST_PROD_SUBG_MST_ID:
                rpmvu.set_RP_subgoal_resulting_change(subgoal_rec, final_year_idx, 100)

    goal_rec = rpmvu.get_RP_goal_rec(food_security_sector_rec, rpc.RP_FOOD_2_REDUCE_FOOD_INSEC_GOAL_MST_ID)

    for subgoal_ID in rpc.RP_FOOD_2_SUBGOAL_MST_IDS:
        subgoal_rec = rpmvu.get_RP_subgoal_rec(goal_rec, subgoal_ID)

        if subgoal_rec != gbc.GB_NOT_FOUND:
            # Base year values are the same for all subgoals
            rpmvu.set_RP_subgoal_resulting_change(subgoal_rec, first_year_idx, country_defaults_DB[rpdbc.RP_SEVERE_INSECURITY_KEY_CDDB])
    
            if subgoal_ID == rpc.RP_FOOD_2_2_HALVE_SEV_FOOD_INSECURITY_SUBG_MST_ID:
                rpmvu.set_RP_subgoal_resulting_change(subgoal_rec, final_year_idx, country_defaults_DB[rpdbc.RP_SEVERE_INSECURITY_KEY_CDDB] / 2)

    # Urbanization

    t1_UDB = gbu.getYearIdx(first_year, rpdbc.RP_FIRST_YEAR_CUDB)
    t2_UDB = gbu.getYearIdx(final_year, rpdbc.RP_FIRST_YEAR_CUDB)

    rpmvu.set_RP_urb_sector_perc_pop_urb_baseline_year(urbanization_sector_rec, urban_DB[rpdbc.RP_PERC_POP_LIVING_URBAN_AREAS_KEY_UDB][t1_UDB])
    rpmvu.set_RP_urb_sector_perc_pop_urb_endline_year(urbanization_sector_rec, urban_DB[rpdbc.RP_PERC_POP_LIVING_URBAN_AREAS_KEY_UDB][t2_UDB])
    rpmvu.set_RP_urb_sector_cost_per_HH_move_to_housing(urbanization_sector_rec, country_defaults_DB[rpdbc.RP_COST_BUILD_URBAN_HOUSEHOLD_KEY_CDDB])

    goal_rec = rpmvu.get_RP_goal_rec(urbanization_sector_rec, rpc.RP_URB_2_INCR_ACCESS_URBAN_HOUS_GOAL_MST_ID)

    for subgoal_ID in rpc.RP_URB_2_SUBGOAL_MST_IDS:
        subgoal_rec = rpmvu.get_RP_subgoal_rec(goal_rec, subgoal_ID)

        if subgoal_rec != gbc.GB_NOT_FOUND:
            # Base year values are the same for all subgoals
            rpmvu.set_RP_subgoal_resulting_change(subgoal_rec, first_year_idx, country_defaults_DB[rpdbc.RP_PERC_URBAN_INFORMAL_KEY_CDDB])
    
            if subgoal_ID == rpc.RP_URB_2_2_HALVE_POP_INFORMAL_SETTLEMENTS_SUBG_MST_ID:
                rpmvu.set_RP_subgoal_resulting_change(subgoal_rec, final_year_idx, country_defaults_DB[rpdbc.RP_PERC_URBAN_INFORMAL_KEY_CDDB] / 2)

    # Energy

    rpmvu.set_RP_energy_sector_energy_KWh_prod_per_cap_per_year(energy_sector_rec, country_defaults_DB[rpdbc.RP_ELECTRICITY_PROD_PER_CAP_KEY_CDDB])
    rpmvu.set_RP_energy_sector_cap_cost_per_HH_connect_grid(energy_sector_rec, country_defaults_DB[rpdbc.RP_LCOE_0_PER_PERSON_PER_DAY_KEY_CDDB])
    rpmvu.set_RP_energy_sector_cap_cost_per_HH_clean_cooking(energy_sector_rec, country_defaults_DB[rpdbc.RP_CLEAN_COOKING_CAP_COST_KEY_CDDB])
    rpmvu.set_RP_energy_sector_cost_per_KWh(energy_sector_rec, country_defaults_DB[rpdbc.RP_COST_PER_KWH_KEY_CDDB])

    goal_rec = rpmvu.get_RP_goal_rec(energy_sector_rec, rpc.RP_ENERGY_1_INCR_POP_ACC_ELEC_GOAL_MST_ID)

    for subgoal_ID in rpc.RP_ENERGY_1_SUBGOAL_MST_IDS:
        subgoal_rec = rpmvu.get_RP_subgoal_rec(goal_rec, subgoal_ID)

        if subgoal_rec != gbc.GB_NOT_FOUND:
            rpmvu.set_RP_subgoal_resulting_change(subgoal_rec, first_year_idx, country_defaults_DB[rpdbc.RP_PERC_POP_ELECTRICITY_KEY_CDDB])

            if subgoal_ID == rpc.RP_ENERGY_1_1_UNIV_ACCESS_SUBG_MST_ID:
                rpmvu.set_RP_subgoal_resulting_change(subgoal_rec, final_year_idx, 100)

    goal_rec = rpmvu.get_RP_goal_rec(energy_sector_rec, rpc.RP_ENERGY_2_INCR_PROD_ELEC_SUFF_LEVELS_GOAL_MST_ID)

    for subgoal_ID in rpc.RP_ENERGY_2_SUBGOAL_MST_IDS:
        subgoal_rec = rpmvu.get_RP_subgoal_rec(goal_rec, subgoal_ID)

        if subgoal_rec != gbc.GB_NOT_FOUND:
            rpmvu.set_RP_subgoal_resulting_change(subgoal_rec, first_year_idx, country_defaults_DB[rpdbc.RP_ELECTRICITY_PROD_PER_CAP_KEY_CDDB])

            if subgoal_ID == rpc.RP_ENERGY_2_1_1000_KWH_PER_PERSON_YEAR_MST_ID:
                rpmvu.set_RP_subgoal_resulting_change(subgoal_rec, final_year_idx, 1000)

    goal_rec = rpmvu.get_RP_goal_rec(energy_sector_rec, rpc.RP_ENERGY_3_INCR_HOUS_ACCESS_CLEAN_GOAL_MST_ID)

    for subgoal_ID in rpc.RP_ENERGY_3_SUBGOAL_MST_IDS:
        subgoal_rec = rpmvu.get_RP_subgoal_rec(goal_rec, subgoal_ID)

        if subgoal_rec != gbc.GB_NOT_FOUND:
            rpmvu.set_RP_subgoal_resulting_change(subgoal_rec, first_year_idx, country_defaults_DB[rpdbc.RP_CLEAN_COOKING_KEY_CDDB])

            if subgoal_ID == rpc.RP_ENERGY_3_1_UNIV_ACCESS_SUBG_MST_ID:
                rpmvu.set_RP_subgoal_resulting_change(subgoal_rec, final_year_idx, 100)

    # Economic

    rpmvu.set_RP_eco_sector_GDP_per_capita(economic_sector_rec, country_defaults_DB[rpdbc.RP_GDP_PER_CAP_KEY_CDDB])
    # base_pop is bsaed on the Goal scenario, so we would have to calculate before setting the default?
    # defunct rpmvu.set_RP_eco_sector_baseline_GDP(economic_sector_rec, (country_defaults_DB[rpdbc.RP_GDP_PER_CAP_CDDB] * base_pop) / 1000000)
    # defunct rpmvu.set_RP_eco_sector_GDP_growth_rate(economic_sector_rec, country_defaults_DB[rpdbc.RP_AVG_GROWTH_RATE_CDDB])
    rpmvu.set_RP_eco_sector_labor_partic_rate(economic_sector_rec, country_defaults_DB[rpdbc.RP_LABOR_BOTH_KEY_CDDB])
    rpmvu.set_RP_eco_sector_change_GDP_CDR(economic_sector_rec, country_defaults_DB[rpdbc.RP_GDP_BOOST_PERC_CHANGE_CDR_KEY_CDDB])
    
    goal_rec = rpmvu.get_RP_goal_rec(economic_sector_rec, rpc.RP_ECON_3_DECR_UNEMPLOYMENT_GOAL_MST_ID)

    for subgoal_ID in rpc.RP_ECON_3_SUBGOAL_MST_IDS:
        subgoal_rec = rpmvu.get_RP_subgoal_rec(goal_rec, subgoal_ID)

        if subgoal_rec != gbc.GB_NOT_FOUND:
            # Base year values are the same for all subgoals
            rpmvu.set_RP_subgoal_resulting_change(subgoal_rec, first_year_idx, country_defaults_DB[rpdbc.RP_UNEMPLOYMENT_KEY_CDDB])
    
            if subgoal_ID == rpc.RP_ECON_3_1_5_PERC_UNEMPLOYMENT_SUBG_MST_ID:
                rpmvu.set_RP_subgoal_resulting_change(subgoal_rec, final_year_idx, 5)
    
    goal_rec = rpmvu.get_RP_goal_rec(economic_sector_rec, rpc.RP_ECON_4_REDUCE_YOUTH_NEET_GOAL_MST_ID)

    for subgoal_ID in rpc.RP_ECON_4_SUBGOAL_MST_IDS:
        subgoal_rec = rpmvu.get_RP_subgoal_rec(goal_rec, subgoal_ID)

        if subgoal_rec != gbc.GB_NOT_FOUND:
            # Base year values are the same for all subgoals and different for each sex
            rpmvu.set_RP_subgoal_resulting_change_by_sex(subgoal_rec, gbc.GB_Female, first_year_idx, country_defaults_DB[rpdbc.RP_YOUTH_NEET_FEMALE_KEY_CDDB])
            rpmvu.set_RP_subgoal_resulting_change_by_sex(subgoal_rec, gbc.GB_Male, first_year_idx, country_defaults_DB[rpdbc.RP_YOUTH_NEET_MALE_KEY_CDDB])

            # Final year values are the same for each sex
            for sex in [gbc.GB_Male, gbc.GB_Female]:

                if subgoal_ID == rpc.RP_ECON_4_2_ACHIEVE_GENDER_EQUALITY_SUBG_MST_ID:
                    value = min(country_defaults_DB[rpdbc.RP_YOUTH_NEET_FEMALE_KEY_CDDB], country_defaults_DB[rpdbc.RP_YOUTH_NEET_MALE_KEY_CDDB])
                    rpmvu.set_RP_subgoal_resulting_change_by_sex(subgoal_rec, sex, final_year_idx, value)

def RP_set_climate_param_defaults(country_defaults_DB, climate_params):
    rpmvu.set_RP_climate_baseline_mean_med_temp(climate_params, country_defaults_DB[rpdbc.RP_BASELINE_AVG_TEMP_KEY_CDDB])
    rpmvu.set_RP_climate_perc_change_GDP_1_degree_warm(climate_params, country_defaults_DB[rpdbc.RP_1_DEGREE_GDP_KEY_CDDB])
    rpmvu.set_RP_climate_perc_change_staple_crop_1_degree_warm(climate_params, country_defaults_DB[rpdbc.RP_1_DEGREE_STAPLE_KEY_CDDB])
    rpmvu.set_RP_climate_perc_change_staple_crop_2_degree_warm(climate_params, country_defaults_DB[rpdbc.RP_2_DEGREE_STAPLE_KEY_CDDB])
    rpmvu.set_RP_climate_perc_change_staple_crop_3_degree_warm(climate_params, country_defaults_DB[rpdbc.RP_3_DEGREE_STAPLE_KEY_CDDB])
    rpmvu.set_RP_climate_perc_change_energy_needs_1_degree_warm(climate_params, country_defaults_DB[rpdbc.RP_1_DEGREE_ON_ENERGY_KEY_CDDB])

def RP_set_FP_scen_scale_up_defaults(contraceptive_use_med_DB, contraceptive_use_acc_DB, 
    FP_scen_scale_up_rec, scenario_goal_scale_up, scenario_counterfactual_scale_up, first_year, final_year):

    year_range = acu.GBRange(first_year, final_year)
    year_range_DB = acu.GBRange(rpdbc.RP_FIRST_YEAR_CUDB, rpdbc.RP_FINAL_YEAR_CUDB)

    # We're assuming here that the projection years fall within the database years (2020-2075). If they don't, this will break. Both databases have
    # the same set of years.
    t1_DB = gbu.getYearIdx(first_year, rpdbc.RP_FIRST_YEAR_CUDB)
    t2_DB = gbu.getYearIdx(final_year, rpdbc.RP_FIRST_YEAR_CUDB)
    
    # acc_t1 = contraceptive_use_acc_DB[rpdbc.RP_CONTRACEPTIVE_USE_KEY_CUDB][t1_DB]
    med_t1 = contraceptive_use_med_DB[rpdbc.RP_CONTRACEPTIVE_USE_KEY_CUDB][t1_DB]
    acc_t2 = contraceptive_use_acc_DB[rpdbc.RP_CONTRACEPTIVE_USE_KEY_CUDB][t2_DB]
    med_t2 = contraceptive_use_med_DB[rpdbc.RP_CONTRACEPTIVE_USE_KEY_CUDB][t2_DB]

    acc_avg_annual_change = (acc_t2 - med_t1) / (final_year - first_year) # Not a mistake, should be med and not acc
    med_avg_annual_change = (med_t2 - med_t1) / (final_year - first_year)

    for year in year_range:
        if year in year_range_DB:
            t = gbu.getYearIdx(year, first_year)

            # First year values for all three types should be median, first year from database.
            if year == first_year:
                FP_scen_scale_up_rec[rpmvf.RP_FP_SCEN_SC_ACCELERATED][t] = med_t1
                FP_scen_scale_up_rec[rpmvf.RP_FP_SCEN_SC_MEDIAN][t] = med_t1
                FP_scen_scale_up_rec[rpmvf.RP_FP_SCEN_SC_FLATLINE][t] = med_t1
                scenario_goal_scale_up[t] = med_t1
                scenario_counterfactual_scale_up[t] = med_t1

            else:
                FP_scen_scale_up_rec[rpmvf.RP_FP_SCEN_SC_ACCELERATED][t] = (
                    FP_scen_scale_up_rec[rpmvf.RP_FP_SCEN_SC_ACCELERATED][t - 1] + acc_avg_annual_change
                )

                FP_scen_scale_up_rec[rpmvf.RP_FP_SCEN_SC_MEDIAN][t] = (
                    FP_scen_scale_up_rec[rpmvf.RP_FP_SCEN_SC_MEDIAN][t - 1] + med_avg_annual_change 
                )

                FP_scen_scale_up_rec[rpmvf.RP_FP_SCEN_SC_FLATLINE][t] = FP_scen_scale_up_rec[rpmvf.RP_FP_SCEN_SC_FLATLINE][t - 1]

def RP_set_FP_method_cost_defaults(country_defaults_DB, FP_methods, avg_annual_unit_direct_costs):
    
    for m, value in enumerate(FP_methods):

        # If the method is active, set a default cost. 
        if value:

            if m == rpcl.RP_FP_M_CONDOM_M_CURR_ID:
                avg_annual_unit_direct_costs[m] = country_defaults_DB[rpdbc.RP_COST_CONDOMS_KEY_CDDB]

            elif m == rpcl.RP_FP_M_STERILIZ_F_CURR_ID:    
                avg_annual_unit_direct_costs[m] = country_defaults_DB[rpdbc.RP_COST_F_STERILIZATION_KEY_CDDB]

            elif m == rpcl.RP_FP_M_STERILIZ_M_CURR_ID:  
                avg_annual_unit_direct_costs[m] = country_defaults_DB[rpdbc.RP_COST_M_STERILIZATION_KEY_CDDB]

            elif m == rpcl.RP_FP_M_IUD_COPPER_10_YR_CURR_ID: 
                avg_annual_unit_direct_costs[m] = country_defaults_DB[rpdbc.RP_COST_IUD_KEY_CDDB]

            elif m == rpcl.RP_FP_M_INJECT_DEPO_3_MO_CURR_ID:
                avg_annual_unit_direct_costs[m] = country_defaults_DB[rpdbc.RP_COST_INJECTIONS_KEY_CDDB]

            elif m == rpcl.RP_FP_M_IMPLANT_JADELLE_5_YR_CURR_ID:
                avg_annual_unit_direct_costs[m] = country_defaults_DB[rpdbc.RP_COST_IMPLANT_KEY_CDDB]
            
            elif m == rpcl.RP_FP_M_PILL_STANDARD_CURR_ID:
                avg_annual_unit_direct_costs[m] = country_defaults_DB[rpdbc.RP_COST_PILL_KEY_CDDB]

            elif m == rpcl.RP_FP_M_VAG_BARRIER_CURR_ID:
                avg_annual_unit_direct_costs[m] = country_defaults_DB[rpdbc.RP_COST_VAG_BARR_KEY_CDDB]

            elif m == rpcl.RP_FP_M_OTHER_MODERN_METHODS_CURR_ID:
                avg_annual_unit_direct_costs[m] = country_defaults_DB[rpdbc.RP_COST_OTHER_MODERN_KEY_CDDB]

def RP_set_SSP_data(first_year, final_year, SSP1_DB, SSP2_DB, SSP3_DB, SSP5_DB):
    SSP_data = {}

    year_range = acu.GBRange(first_year, final_year)
    year_range_DB = acu.GBRange(rpdbc.RP_FIRST_YEAR_SSPDB, rpdbc.RP_FINAL_YEAR_SSPDB)

    num_years = final_year - first_year + 1

    if SSP1_DB != gbc.GB_NOT_FOUND:
        SSP_data[rpmvf.RP_SSP1] = np.full((num_years), 0.0).tolist()

        for year in year_range:
            if year in year_range_DB:
                t = gbu.getYearIdx(year, first_year)

                SSP_data[rpmvf.RP_SSP1][t] = SSP1_DB[rpdbc.RP_BASELINE_AVG_TEMP_KEY_SSPDB][t]

    if SSP2_DB != gbc.GB_NOT_FOUND:
        SSP_data[rpmvf.RP_SSP2] = np.full((num_years), 0.0).tolist()

        for year in year_range:
            if year in year_range_DB:
                t = gbu.getYearIdx(year, first_year)

                SSP_data[rpmvf.RP_SSP2][t] = SSP2_DB[rpdbc.RP_BASELINE_AVG_TEMP_KEY_SSPDB][t]

    if SSP3_DB != gbc.GB_NOT_FOUND:
        SSP_data[rpmvf.RP_SSP3] = np.full((num_years), 0.0).tolist()

        for year in year_range:
            if year in year_range_DB:
                t = gbu.getYearIdx(year, first_year)

                SSP_data[rpmvf.RP_SSP3][t] = SSP3_DB[rpdbc.RP_BASELINE_AVG_TEMP_KEY_SSPDB][t]

    if SSP5_DB != gbc.GB_NOT_FOUND:
        SSP_data[rpmvf.RP_SSP5] = np.full((num_years), 0.0).tolist()

        for year in year_range:
            if year in year_range_DB:
                t = gbu.getYearIdx(year, first_year)

                SSP_data[rpmvf.RP_SSP5][t] = SSP5_DB[rpdbc.RP_BASELINE_AVG_TEMP_KEY_SSPDB][t]

    return SSP_data

def RP_set_sources_defaults(country_default_sources_DB, sources_mv):

    sources_mv[rpmvf.RP_SRC_HH_SIZE] = country_default_sources_DB[rpdbc.RP_HH_SIZE_KEY_CDDB]
    sources_mv[rpmvf.RP_SRC_FP_METHOD_MIX] = 'FamPlan'
    sources_mv[rpmvf.RP_SRC_FP_EFFECTIVENESS] = 'FamPlan'
    sources_mv[rpmvf.RP_SRC_FP_UNIT_COSTS] = 'Adding it up - adjusted to 2024'
    sources_mv[rpmvf.RP_SRC_DP_FIRST_YEAR_POP] = 'WPP 2024'
    sources_mv[rpmvf.RP_SRC_FP_TFR] = 'FamPlan'

    sources_mv[rpmvf.RP_SRC_GOALS_PRIMARY_ENROLL_ALL] = country_default_sources_DB[rpdbc.RP_PERC_ENROLL_PRIM_KEY_CDDB]
    sources_mv[rpmvf.RP_SRC_GOALS_PRIMARY_ENROLL_MALE] = country_default_sources_DB[rpdbc.RP_PRIM_ENROLL_MALES_KEY_CDDB]
    sources_mv[rpmvf.RP_SRC_GOALS_PRIMARY_ENROLL_FEMALE] = country_default_sources_DB[rpdbc.RP_PRIM_ENROLL_FEMALES_KEY_CDDB]
    sources_mv[rpmvf.RP_SRC_GOALS_SECONDARY_ENROLL_ALL] = country_default_sources_DB[rpdbc.RP_PERC_ENROLL_SEC_KEY_CDDB]
    sources_mv[rpmvf.RP_SRC_GOALS_SECONDARY_ENROLL_MALE] = country_default_sources_DB[rpdbc.RP_SEC_ENROLL_MALES_KEY_CDDB]
    sources_mv[rpmvf.RP_SRC_GOALS_SECONDARY_ENROLL_FEMALE] = country_default_sources_DB[rpdbc.RP_SEC_ENROLL_FEMALES_KEY_CDDB]
    sources_mv[rpmvf.RP_SRC_GOALS_STUDENT_TEACHER_RATIO] = country_default_sources_DB[rpdbc.RP_TEACHER_RATIO_PRIM_KEY_CDDB]
    sources_mv[rpmvf.RP_SRC_GOALS_BIRTHS_ATTEND_SKILLED_PERS] = country_default_sources_DB[rpdbc.RP_SKILLED_BIRTH_COSTS_KEY_CDDB]
    sources_mv[rpmvf.RP_SRC_GOALS_PREG_W_4_PLUS_ANC_VISITS] = country_default_sources_DB[rpdbc.RP_ANC_4_PLUS_KEY_CDDB]
    sources_mv[rpmvf.RP_SRC_GOALS_HLTH_PROF_1000_POP] = country_default_sources_DB[rpdbc.RP_PROFS_KEY_CDDB]
    sources_mv[rpmvf.RP_SRC_GOALS_PERC_ACCESS_IMP_WATER] = country_default_sources_DB[rpdbc.RP_PERC_IMPROVED_WATER_SOURCE_KEY_CDDB]
    sources_mv[rpmvf.RP_SRC_GOALS_PERC_ACCESS_IMP_SANI] = country_default_sources_DB[rpdbc.RP_PERC_IMPROVED_SANI_KEY_CDDB]
    sources_mv[rpmvf.RP_SRC_GOALS_PERC_PROD_STAPLE_CROP] = country_default_sources_DB[rpdbc.RP_STAPLE_PRODUCTION_KEY_CDDB]
    sources_mv[rpmvf.RP_SRC_GOALS_PERC_SEV_FOOD_INSEC] = country_default_sources_DB[rpdbc.RP_SEVERE_INSECURITY_KEY_CDDB]
    sources_mv[rpmvf.RP_SRC_GOALS_PERC_URB_POP_INFORM_SET] = country_default_sources_DB[rpdbc.RP_PERC_URBAN_INFORMAL_KEY_CDDB]
    sources_mv[rpmvf.RP_SRC_GOALS_PERC_POP_ACCESS_ELEC] = country_default_sources_DB[rpdbc.RP_PERC_POP_ELECTRICITY_KEY_CDDB]
    sources_mv[rpmvf.RP_SRC_GOALS_KWH_PRODUCED] = country_default_sources_DB[rpdbc.RP_ELECTRICITY_PROD_PER_CAP_KEY_CDDB]
    sources_mv[rpmvf.RP_SRC_GOALS_PERC_ACCESS_CLEAN_COOK_TECH] = country_default_sources_DB[rpdbc.RP_CLEAN_COOKING_KEY_CDDB]
    sources_mv[rpmvf.RP_SRC_GOALS_UNEMPLOYMENT_RATE] = country_default_sources_DB[rpdbc.RP_UNEMPLOYMENT_KEY_CDDB]
    sources_mv[rpmvf.RP_SRC_GOALS_PERC_NEET_ALL] = country_default_sources_DB[rpdbc.RP_YOUTH_NEET_ALL_KEY_CDDB]
    sources_mv[rpmvf.RP_SRC_GOALS_PERC_NEET_MALES] = country_default_sources_DB[rpdbc.RP_YOUTH_NEET_MALE_KEY_CDDB]
    sources_mv[rpmvf.RP_SRC_GOALS_PERC_NEET_FEMALES] = country_default_sources_DB[rpdbc.RP_YOUTH_NEET_FEMALE_KEY_CDDB]

    sources_mv[rpmvf.RP_SRC_SECTOR_EDU_SCHOOL_AGE_RANGES] = country_default_sources_DB[rpdbc.RP_HH_SIZE_KEY_CDDB]
    sources_mv[rpmvf.RP_SRC_SECTOR_EDU_AVG_ANN_TEACHER_SAL_PRIM] = country_default_sources_DB[rpdbc.RP_PRIM_TEACHER_SALARY_KEY_CDDB]
    sources_mv[rpmvf.RP_SRC_SECTOR_EDU_ANN_COST_EDU_PRIM_STUDENT] = country_default_sources_DB[rpdbc.RP_PRIM_COSTS_KEY_CDDB]
    sources_mv[rpmvf.RP_SRC_SECTOR_EDU_ANN_COST_EDU_SEC_STUDENT] = country_default_sources_DB[rpdbc.RP_SEC_COSTS_KEY_CDDB]
    sources_mv[rpmvf.RP_SRC_SECTOR_HLTH_AVG_UNIT_COST_SKILLED_DELIV] = country_default_sources_DB[rpdbc.RP_SKILLED_BIRTH_COSTS_KEY_CDDB]
    sources_mv[rpmvf.RP_SRC_SECTOR_HLTH_AVG_UNIT_COST_ANC_4_PLUS_VISITS] = country_default_sources_DB[rpdbc.RP_ANC_COSTS_KEY_CDDB]
    sources_mv[rpmvf.RP_SRC_SECTOR_HLTH_PERC_SKILLED_HLTH_PROF_DOCTORS] = country_default_sources_DB[rpdbc.RP_PERC_DOCTORS_KEY_CDDB]
    sources_mv[rpmvf.RP_SRC_SECTOR_HLTH_PERC_SKILLED_HLTH_PROF_NURSES] = country_default_sources_DB[rpdbc.RP_PERC_NURSES_KEY_CDDB]
    sources_mv[rpmvf.RP_SRC_SECTOR_HLTH_AVG_SALARY_DOCTORS] = country_default_sources_DB[rpdbc.RP_DOCTOR_SALARY_PUBLIC_KEY_CDDB]
    sources_mv[rpmvf.RP_SRC_SECTOR_HLTH_AVG_SALARY_NURSES] = country_default_sources_DB[rpdbc.RP_NURSE_SALARY_PUBLIC_KEY_CDDB]
    sources_mv[rpmvf.RP_SRC_SECTOR_WASH_CAP_COSTS_PER_HH_IMPR_WATER] = country_default_sources_DB[rpdbc.RP_CAP_COST_PP_IMPROVED_WATER_KEY_CDDB]
    sources_mv[rpmvf.RP_SRC_SECTOR_WASH_CAP_COSTS_PER_HH_IMPR_SANI] = country_default_sources_DB[rpdbc.RP_CAP_COST_PP_IMPROVED_SANI_KEY_CDDB]
    sources_mv[rpmvf.RP_SRC_SECTOR_FOOD_PRIM_STAPLE_CROP] = country_default_sources_DB[rpdbc.RP_DOMINANT_CROP_KEY_CDDB]
    sources_mv[rpmvf.RP_SRC_SECTOR_FOOD_CROP_LAND] = country_default_sources_DB[rpdbc.RP_CROPLAND_HECTARES_KEY_CDDB]
    sources_mv[rpmvf.RP_SRC_SECTOR_FOOD_STAPLE_CROP_PROD_BASE] = country_default_sources_DB[rpdbc.RP_STAPLE_PRODUCTION_KEY_CDDB]
    sources_mv[rpmvf.RP_SRC_SECTOR_FOOD_TONNES_HARV_PERC_HECT] = country_default_sources_DB[rpdbc.RP_AREA_HARVESTED_KEY_CDDB]
    sources_mv[rpmvf.RP_SRC_SECTOR_FOOD_ANN_KG_PER_YEAR_CONSUMP_STAPLE_CROP] = country_default_sources_DB[rpdbc.RP_STAPLE_ANNUAL_CONSUMP_PER_CAP_KEY_CDDB]
    sources_mv[rpmvf.RP_SRC_SECTOR_FOOD_PROD_COSTS_STAPLE_CROP] = country_default_sources_DB[rpdbc.RP_PROD_COST_PER_TON_DOMINANT_CROP_KEY_CDDB]
    sources_mv[rpmvf.RP_SRC_SECTOR_FOOD_DAILY_COST_FOOD_AID] = country_default_sources_DB[rpdbc.RP_DAILY_COST_FOOD_AID_PER_PERSON_KEY_CDDB]
    sources_mv[rpmvf.RP_SRC_SECTOR_URB_PERC_POP_URB_BASE_END] = 'UN Population Division'
    sources_mv[rpmvf.RP_SRC_SECTOR_URB_COST_PER_HH_MOVE_TO_HOUSING] = country_default_sources_DB[rpdbc.RP_COST_BUILD_URBAN_HOUSEHOLD_KEY_CDDB]
    sources_mv[rpmvf.RP_SRC_SECTOR_ENERGY_CAP_COSTS_PER_HH_CONNECT_GRID] = country_default_sources_DB[rpdbc.RP_LCOE_0_PER_PERSON_PER_DAY_KEY_CDDB]
    sources_mv[rpmvf.RP_SRC_SECTOR_ENERGY_CAP_COSTS_PER_HH_CLEAN_COOKING] = country_default_sources_DB[rpdbc.RP_CLEAN_COOKING_CAP_COST_KEY_CDDB]
    sources_mv[rpmvf.RP_SRC_SECTOR_ECO_GDP_PER_CAPITA] = country_default_sources_DB[rpdbc.RP_GDP_PER_CAP_KEY_CDDB]
    sources_mv[rpmvf.RP_SRC_SECTOR_ECO_LABOR_PARTIC_RATE] = country_default_sources_DB[rpdbc.RP_LABOR_BOTH_KEY_CDDB]
    sources_mv[rpmvf.RP_SRC_SECTOR_ECO_CHANGE_GDP_CDR] = country_default_sources_DB[rpdbc.RP_GDP_BOOST_PERC_CHANGE_CDR_KEY_CDDB]

    sources_mv[rpmvf.RP_SRC_CLIM_BASELINE_MEAN_MED_TEMP] = 'SSP scenarios'
    sources_mv[rpmvf.RP_SRC_CLIM_PERC_CHANGE_GDP_1_DEG_WARM] = 'Roson & Sartori, 2016'
    sources_mv[rpmvf.RP_SRC_CLIM_PERC_CHANGE_ENERGY_NEEDS_1_DEG_WARM] = 'Roson & Sartori, 2016'
    sources_mv[rpmvf.RP_SRC_CLIM_PERC_CHANGE_STAPLE_CROP_1_DEG_WARM] = 'Roson & Sartori, 2016'
    sources_mv[rpmvf.RP_SRC_CLIM_PERC_CHANGE_STAPLE_CROP_2_DEG_WARM] = 'Roson & Sartori, 2016'
    sources_mv[rpmvf.RP_SRC_CLIM_PERC_CHANGE_STAPLE_CROP_3_DEG_WARM] = 'Roson & Sartori, 2016'