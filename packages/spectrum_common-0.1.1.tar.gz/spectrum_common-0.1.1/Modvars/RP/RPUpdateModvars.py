



# Notes:
#
#   1. You cannot base logic on whether a current MV tag exists in the code below.  It will always exist, because before this gets called, all missing MVs
#      will get added to the projection.
#
#   2. To trigger this, create a projection, say on the client, save, and grab it's projection ID.  Call GetModvars to get the library ID and put that into the appropriate
#      environment variable. Then call OpenProjection. Make sure to leave the projection on the client open while doing this because the proj ID changes when you open/close.
# def PC_UpdateModvars(projection, created_projection):

#     if PC_COST_INPUT_RECORDS_TAG_V1 in projection:
#         _convert_cost_input_records_1(projection, PC_COST_INPUT_RECORDS_TAG_V1)
#         _convert_cost_input_records_2(projection, pcmvt.PC_COST_INPUT_RECORDS_TAG)

#     elif PC_COST_INPUT_RECORDS_TAG_V2 in projection:
#         _convert_cost_input_records_2(projection, PC_COST_INPUT_RECORDS_TAG_V2)

#     if PC_COSTING_SECT_RECORDS_TAG_V1 in projection:
#         _convert_costing_sect_records_1(projection, PC_COSTING_SECT_RECORDS_TAG_V1)

#     if PC_ACT_RECORDS_TAG_V1 in projection:
#         _convert_act_records_1(projection, PC_ACT_RECORDS_TAG_V1)

#     # delete tags
#     for tag in PC_TagsForDeletion:
#         if tag in projection:
#             del projection[tag]

#     return projection

# PC_COST_INPUT_RECORDS_TAG_V1    = '<PC_CostInputRecords_V1>'
# PC_COST_INPUT_RECORDS_TAG_V2    = '<PC_CostInputRecords_V2>'
# PC_COSTING_SECT_RECORDS_TAG_V1  = '<PC_CostingSectionRecords_V1>'
# PC_ACT_RECORDS_TAG_V1           = '<PC_ActivityRecords_V1>'

# PC_TagsForDeletion = [
#     PC_COST_INPUT_RECORDS_TAG_V1,
#     PC_COST_INPUT_RECORDS_TAG_V2,
#     PC_COSTING_SECT_RECORDS_TAG_V1,
#     PC_ACT_RECORDS_TAG_V1,
# ]

# def _reload_string_constants_cost_inputs(cost_input_records_value):
#     cost_input_DB = pcrd.PC_load_cost_input_DB()

#     # Create a dict out of the database for fast lookups. Key-value pairs are input ID - inner dicts where the inner dicts are
#     # cost input string constant IDs and unit of measure string constant IDs
#     cost_input_DB_dict = {}

#     for cost_input_DB_obj in cost_input_DB:
#         cost_input_DB_dict[str(cost_input_DB_obj[pcdbk.PC_COST_INPUT_ID_KEY_CIDB])] = {
#             'costInputStringConstant'     : cost_input_DB_obj[pcdbk.PC_COST_INPUT_STR_CONST_KEY_CIDB],
#             'unitOfMeasureStringConstant' : cost_input_DB_obj[pcdbk.PC_UNIT_OF_MEASURE_STR_CONST_KEY_CIDB],
#         }

#     for rec in cost_input_records_value:
#         cost_input_ID = rec[pcmvf.PC_COST_INPUT_ID]

#         if cost_input_ID in cost_input_DB_dict:
#             rec[pcmvf.PC_COST_INPUT_STR_CONST] = cost_input_DB_dict[cost_input_ID]['costInputStringConstant']
#             rec[pcmvf.PC_COST_INPUT_UNIT_OF_MEASURE_STR_CONST] = cost_input_DB_dict[cost_input_ID]['unitOfMeasureStringConstant']

# def _reload_string_constants_cost_sections_and_subsections(cost_section_records_value):
#     # Both come from the same database.
#     cost_section_DB = pcrd.PC_load_costing_sect_DB()

#     ##########   Costing sections   ###########

#     # Create a dict out of the database for fast lookups. Key-value pairs are keys described below and costing string constants.
#     cost_sections_DB_dict = {}

#     for cost_section_DB_obj in cost_section_DB:
#         # Costing section rows will have a subsection ID of -1
#         costing_subsect_ID = cost_section_DB_obj[pcdbk.PC_COSTING_SUBSECT_ID_KEY_CSDB]

#         if costing_subsect_ID == -1:
#             # Costing sections require area type ID, area ID, and costing section ID to positively identify them.
#             key = (str(
#                 str(cost_section_DB_obj[pcdbk.PC_AREA_TYPE_ID_KEY_CSDB])
#                 + '_' + str(cost_section_DB_obj[pcdbk.PC_AREA_ID_KEY_CSDB])
#                 + '_' + str(cost_section_DB_obj[pcdbk.PC_COSTING_SECT_ID_KEY_CSDB])
#             ))
#             cost_sections_DB_dict[key] = cost_section_DB_obj[pcdbk.PC_COSTING_SECT_STR_CONST_KEY_CSDB]

#     for rec in cost_section_records_value:
#         area_type_ID = rec[pcmvf.PC_COSTING_SECT_AREA_TYPE_ID]
#         area_ID = rec[pcmvf.PC_COSTING_SECT_AREA_ID]
#         costing_sect_ID = rec[pcmvf.PC_COSTING_SECT_ID]

#         key = str(str(area_type_ID) + '_' + str(area_ID) + '_' + str(costing_sect_ID))

#         if key in cost_sections_DB_dict:
#             rec[pcmvf.PC_COSTING_SECT_STR_CONST] = cost_sections_DB_dict[key]

#     ##########   Costing subsections   ###########

#     cost_subsection_DB_dict = {}

#     for cost_subsection_DB_obj in cost_section_DB:
#         # Costing subsection rows will have a subsection ID other than -1
#         costing_subsect_ID = cost_subsection_DB_obj[pcdbk.PC_COSTING_SUBSECT_ID_KEY_CSDB]

#         if costing_subsect_ID != -1:
#             # Costing sections require area type ID, area ID, and costing section ID to positively identify them. Costing subsections require these in addition to
#             # the costing subsection ID.
#             key = (str(
#                 str(cost_subsection_DB_obj[pcdbk.PC_AREA_TYPE_ID_KEY_CSDB])
#                 + '_' + str(cost_subsection_DB_obj[pcdbk.PC_AREA_ID_KEY_CSDB])
#                 + '_' + str(cost_subsection_DB_obj[pcdbk.PC_COSTING_SECT_ID_KEY_CSDB])
#                 + '_' + str(cost_subsection_DB_obj[pcdbk.PC_COSTING_SUBSECT_ID_KEY_CSDB])
#             ))
#             cost_subsection_DB_dict[key] = cost_subsection_DB_obj[pcdbk.PC_COSTING_SUBSECT_STR_CONST_KEY_CSDB]

#     for section_rec in cost_section_records_value:
#         area_type_ID = section_rec[pcmvf.PC_COSTING_SECT_AREA_TYPE_ID]
#         area_ID = section_rec[pcmvf.PC_COSTING_SECT_AREA_ID]
#         costing_sect_ID = section_rec[pcmvf.PC_COSTING_SECT_ID]
#         subsect_records = section_rec[pcmvf.PC_COSTING_SECT_SUBSECT_RECORDS]

#         for subsect_rec in subsect_records:
#             subsect_ID = subsect_rec[pcmvf.PC_COSTING_SUBSECT_ID]

#             key = str(str(area_type_ID) + '_' + str(area_ID) + '_' + str(costing_sect_ID) + '_' + str(subsect_ID))

#             if key in cost_subsection_DB_dict:
#                 subsect_rec[pcmvf.PC_COSTING_SUBSECT_STR_CONST] = cost_subsection_DB_dict[key]

# def _convert_cost_input_records_1(projection, cost_input_records_tag):
#     cost_input_records_value = projection[cost_input_records_tag]

#     # String constants were added.

#     for rec in cost_input_records_value:
#         if not (pcmvf.PC_COST_INPUT_STR_CONST in rec):
#             rec[pcmvf.PC_COST_INPUT_STR_CONST] = ''

#         if not (pcmvf.PC_COST_INPUT_UNIT_OF_MEASURE_STR_CONST in rec):
#             rec[pcmvf.PC_COST_INPUT_UNIT_OF_MEASURE_STR_CONST] = ''

#     if cost_input_records_tag != pcmvt.PC_COST_INPUT_RECORDS_TAG:
#         projection[pcmvt.PC_COST_INPUT_RECORDS_TAG] = deepcopy(cost_input_records_value)

# def _convert_cost_input_records_2(projection, cost_input_records_tag):
#     cost_input_records_value = projection[cost_input_records_tag]

#     _reload_string_constants_cost_inputs(cost_input_records_value)

#     if cost_input_records_tag != pcmvt.PC_COST_INPUT_RECORDS_TAG:
#         projection[pcmvt.PC_COST_INPUT_RECORDS_TAG] = deepcopy(cost_input_records_value)

# def _convert_act_records_1(projection, act_records_tag):
#     act_records_value = projection[act_records_tag]

#     for rec in act_records_value:
#         if not (pcmvf.PC_ACT_STR_CONST in rec):
#             rec[pcmvf.PC_ACT_STR_CONST] = ''

#     if act_records_tag != pcmvt.PC_ACT_RECORDS_TAG:
#         projection[pcmvt.PC_ACT_RECORDS_TAG] = deepcopy(act_records_value)

# def _convert_costing_sect_records_1(projection, costing_sect_records_tag):
#     cost_section_records_value = projection[costing_sect_records_tag]

#     _reload_string_constants_cost_sections_and_subsections(cost_section_records_value)

#     if costing_sect_records_tag != pcmvt.PC_COSTING_SECT_RECORDS_TAG:
#         projection[pcmvt.PC_COSTING_SECT_RECORDS_TAG] = deepcopy(cost_section_records_value)
