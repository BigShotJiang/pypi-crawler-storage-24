from datetime import date
from copy import deepcopy

import numpy as np




import SpectrumCommon.Const.RP.RPConst as rpc
import SpectrumCommon.Const.RP.RPDatabaseConst as rpdbc
import SpectrumCommon.Const.RP.RPConstLink as rpcl
import SpectrumCommon.Const.RP.RPTags as rpmvt
import SpectrumCommon.Modvars.RP.RPModVarDefs as rpmvd
# import SpectrumCommon.Util.RP.RPUtilLink as pcul

import SpectrumCommon.Modvars.RP.RPReadDatabases as rprd

def init_modvars(country_ID, first_year, final_year, extra):
    '''
        Initializes RAPID MVs for new projections.

            Parameters:
                countryID (string):  Ex: BEN for Benin.

                first_year (int): First year selected by user.

                final_year (int): Final year selected by user. 

                extra (dict): Any other fields.  
 
            Returns:
                mod_vars_rec (dict): MVs.
    '''
    
    # modules = extra[gbc.GB_MODULES]
    # sector_on_MV = extra[gbc.GB_RAPID_SECTORS_ON]
    active_methods_MV = extra[rpcl.RP_FP_ACTIVE_METHODS_TAG]
    method_mix_MV = extra[rpcl.RP_FP_METHOD_MIX_TAG]

    # Load databases
    country_defaults_DB = rprd.RP_load_country_defaults_DB(country_ID)
    contraceptive_use_med_DB = rprd.RP_load_contraceptive_use_med_DB(country_ID)
    contraceptive_use_acc_DB = rprd.RP_load_contraceptive_use_acc_DB(country_ID)
    country_defaults_sources_DB = rprd.RP_load_country_defaults_sources_DB(country_ID)
    urban_DB = rprd.RP_load_urban_DB(country_ID)
    SSP1_DB = rprd.RP_load_SSP1_DB(country_ID)
    SSP2_DB = rprd.RP_load_SSP2_DB(country_ID)
    SSP3_DB = rprd.RP_load_SSP3_DB(country_ID)
    SSP5_DB = rprd.RP_load_SSP5_DB(country_ID)

    value_bool = False
    value_int = 0
    value_flt = 0.0
    value_str = ''
    value_date = date.today().strftime("%B %d, %Y"),   
    use_lists = True
    include_status_quo = True

    num_years_inputs = final_year - first_year + 1
    num_years_outputs = final_year - first_year + 1

    indirect_prog_costs = country_defaults_DB[rpdbc.RP_COST_INDIRECTS_KEY_CDDB]

    # sector_records = rpmvd.RP_init_sector_records(sector_on_MV, num_years_inputs)
    sector_records = rpmvd.RP_init_sector_records(num_years_inputs)
    rprd.RP_set_sector_defaults(country_defaults_DB, urban_DB, sector_records, first_year, final_year)
    # sector_records_meta = rpmvd.RP_init_sector_records(sector_on_MV, num_years_inputs, True)
    sector_records_meta = rpmvd.RP_init_sector_records(num_years_inputs, True)
    rprd.RP_set_sector_defaults(country_defaults_DB, urban_DB, sector_records_meta, first_year, final_year)

    climate_params_rec = rpmvd.RP_create_climate_params_rec()
    rprd.RP_set_climate_param_defaults(country_defaults_DB, climate_params_rec)

    scenario_goal_scale_up = np.full((num_years_inputs), 0).tolist()
    scenario_counterfactual_scale_up = np.full((num_years_inputs), 0).tolist()

    FP_scen_scale_up_rec = rpmvd.RP_init_FP_scen_scale_up_rec(num_years_inputs)
    rprd.RP_set_FP_scen_scale_up_defaults(contraceptive_use_med_DB, contraceptive_use_acc_DB, 
        FP_scen_scale_up_rec, scenario_goal_scale_up, scenario_counterfactual_scale_up, first_year, final_year)

    avg_annual_unit_direct_costs = np.full((rpcl.RP_FP_NUM_METHODS + 1), 0.0).tolist()
    rprd.RP_set_FP_method_cost_defaults(country_defaults_DB, active_methods_MV, avg_annual_unit_direct_costs)

    perc_users = np.full((rpcl.RP_FP_NUM_METHODS + 1), 0.0).tolist()

    SSP_data = rprd.RP_set_SSP_data(first_year, final_year, SSP1_DB, SSP2_DB, SSP3_DB, SSP5_DB)

    # Get the sum of the active modern FamPlan method using the method mix.
    modern_methods_sum = 0.0
    for m, value in enumerate(active_methods_MV):
        if value and (m not in rpcl.RP_FP_M_TRAD_METHODS):
            modern_methods_sum += method_mix_MV[rpcl.RP_FP_ALL_AGES][m][rpcl.RP_FP_ALL_NEED][0]

    for m, value in enumerate(active_methods_MV):
        if value and (m not in rpcl.RP_FP_M_TRAD_METHODS):
            perc_users[m] = ((method_mix_MV[rpcl.RP_FP_ALL_AGES][m][rpcl.RP_FP_ALL_NEED][0]) / modern_methods_sum) * 100

    sources = rpmvd.RP_init_sources_rec()
    rprd.RP_set_sources_defaults(country_defaults_sources_DB, sources)

    mod_vars_rec = {            
        rpmvt.RP_VERSION_TAG                           : 1,
        rpmvt.RP_DATA_CHANGED_TAG                      : value_bool, 
        rpmvt.RP_PROJ_VALID_TAG                        : value_bool, 
        rpmvt.RP_FILE_NAME_TAG                         : value_str,                          
        rpmvt.RP_PROJ_VALID_DATE_TAG                   : value_date,    
          
        rpmvt.RP_SECTORS_ON_TAG                        : rpmvd.RP_init_sector_list(),
        rpmvt.RP_SECTOR_RECORDS_TAG                    : sector_records,

        rpmvt.RP_FP_SCEN_GOAL_TAG                      : rpc.RP_FP_SCEN_GOAL_ACCELERATE_MST_ID,
        rpmvt.RP_FP_SCEN_GOAL_SCALE_UP_TAG             : scenario_goal_scale_up,
        rpmvt.RP_FP_SCEN_COUNTERFACTUAL_TAG            : rpc.RP_FP_SCEN_CF_MEDIAN_MST_ID,
        rpmvt.RP_FP_SCEN_COUNTERFACTUAL_SCALE_UP_TAG   : scenario_counterfactual_scale_up,

        rpmvt.RP_HOUSEHOLD_SIZE_BASELINE_TAG           : country_defaults_DB[rpdbc.RP_HH_SIZE_KEY_CDDB],

        rpmvt.RP_CLIMATE_PARAMS_TAG                    : climate_params_rec,

        rpmvt.RP_FP_PERC_USERS_TAG                     : perc_users,
        # rpmvt.RP_FP_TYPICAL_USE_EFFECTIVENESS_TAG      : np.full((rpcl.RP_FP_NUM_METHODS + 1), 0.0).tolist(),
        rpmvt.RP_FP_AVG_ANNUAL_UNIT_DIRECT_COSTS_TAG   : avg_annual_unit_direct_costs,
        rpmvt.RP_FP_INDIRECT_PROG_COSTS_TAG            : indirect_prog_costs,
        rpmvt.RP_REVISED_SOURCES_TAG                   : rpmvd.RP_init_sources_rec(),

        rpmvt.RP_RES_DP_BIG_POP_TAG                    : rpmvd.RP_init_res_FP_scen_rec_by_sex_age_year(use_lists, num_years_outputs, 0.0),
        rpmvt.RP_RES_DP_TFR_TAG                        : rpmvd.RP_init_res_FP_scen_rec_by_year(use_lists, rpc.RP_FP_SCEN_NO_STATUS_QUO_LIST, num_years_outputs, 0.0),
        rpmvt.RP_RES_FP_BIRTHS_TAG                     : rpmvd.RP_init_res_FP_scen_rec_by_year(use_lists, rpc.RP_FP_SCEN_NO_STATUS_QUO_LIST, num_years_outputs, 0.0),

        rpmvt.RP_RES_PRIM_SCH_STUDENTS_TAG             : rpmvd.RP_init_res_FP_scen_rec_by_sex_year(use_lists, include_status_quo, num_years_outputs, 0.0),
        rpmvt.RP_RES_PRIM_EDU_COSTS_TAG                : rpmvd.RP_init_res_FP_scen_rec_by_sex_year(use_lists, not include_status_quo, num_years_outputs, 0.0),
        rpmvt.RP_RES_SEC_SCH_STUDENTS_TAG              : rpmvd.RP_init_res_FP_scen_rec_by_sex_year(use_lists, include_status_quo, num_years_outputs, 0.0),
        rpmvt.RP_RES_SEC_EDU_COSTS_TAG                 : rpmvd.RP_init_res_FP_scen_rec_by_sex_year(use_lists, not include_status_quo, num_years_outputs, 0.0),
        rpmvt.RP_RES_PRIM_SCH_TEACHERS_NEEDED_TAG      : rpmvd.RP_init_res_FP_scen_rec_by_year(use_lists, rpc.RP_FP_SCEN_LIST, num_years_outputs, 0.0),
        rpmvt.RP_RES_PRIM_SCH_TEACHER_SALARY_COSTS_TAG : rpmvd.RP_init_res_FP_scen_rec_by_year(use_lists, rpc.RP_FP_SCEN_NO_STATUS_QUO_LIST, num_years_outputs, 0.0),

        rpmvt.RP_RES_SKILLED_DELIV_TAG                 : rpmvd.RP_init_res_FP_scen_rec_by_year(use_lists, rpc.RP_FP_SCEN_LIST, num_years_outputs, 0.0),
        rpmvt.RP_RES_SKILLED_DELIV_COSTS_TAG           : rpmvd.RP_init_res_FP_scen_rec_by_year(use_lists, rpc.RP_FP_SCEN_NO_STATUS_QUO_LIST, num_years_outputs, 0.0),
        rpmvt.RP_RES_PREG_W_4_PLUS_ANC_VISITS_TAG      : rpmvd.RP_init_res_FP_scen_rec_by_year(use_lists, rpc.RP_FP_SCEN_LIST, num_years_outputs, 0.0),
        rpmvt.RP_RES_COST_4_PLUS_ANC_VISITS_TAG        : rpmvd.RP_init_res_FP_scen_rec_by_year(use_lists, rpc.RP_FP_SCEN_NO_STATUS_QUO_LIST, num_years_outputs, 0.0),
        rpmvt.RP_RES_HLTH_PROF_TAG                     : rpmvd.RP_init_res_FP_scen_rec_by_year(use_lists, rpc.RP_FP_SCEN_LIST, num_years_outputs, 0.0),
        rpmvt.RP_RES_HLTH_PROF_SALARY_COSTS_TAG        : rpmvd.RP_init_res_FP_scen_rec_by_year(use_lists, rpc.RP_FP_SCEN_NO_STATUS_QUO_LIST, num_years_outputs, 0.0),

        rpmvt.RP_RES_PEOPLE_ACCESS_IMRP_WATER_SOURCES_TAG           : rpmvd.RP_init_res_FP_scen_rec_by_year(use_lists, rpc.RP_FP_SCEN_LIST, num_years_outputs, 0.0),
        rpmvt.RP_RES_ADD_PEOPLE_NEED_ACCESS_IMPR_WATER_CUMU_TAG     : rpmvd.RP_init_res_FP_scen_rec(include_status_quo, 0.0),
        rpmvt.RP_RES_CAP_COST_ADD_PEOPLE_GAIN_ACCESS_IMPR_WATER_TAG : rpmvd.RP_init_res_FP_scen_rec_by_year(use_lists, rpc.RP_FP_SCEN_NO_STATUS_QUO_LIST, num_years_outputs, 0.0),
        rpmvt.RP_RES_PEOPLE_ACCESS_IMPR_SANI_FAC_TAG                : rpmvd.RP_init_res_FP_scen_rec_by_year(use_lists, rpc.RP_FP_SCEN_LIST, num_years_outputs, 0.0),
        rpmvt.RP_RES_ADD_PEOPLE_ACCESS_IMPR_SANI_FAC_CUMU_TAG       : rpmvd.RP_init_res_FP_scen_rec(include_status_quo, 0.0),
        rpmvt.RP_RES_CAP_COST_ADD_PEOPLE_GAIN_ACCESS_IMPR_SANI_TAG  : rpmvd.RP_init_res_FP_scen_rec_by_year(use_lists, rpc.RP_FP_SCEN_NO_STATUS_QUO_LIST, num_years_outputs, 0.0),

        rpmvt.RP_RES_MAIN_STAPLE_CROP_PROD_NEEDED_TAG               : rpmvd.RP_init_res_FP_scen_rec_by_year(use_lists, rpc.RP_FP_SCEN_LIST, num_years_outputs, 0.0),
        rpmvt.RP_RES_HECTARES_CROP_NEEDED_MEET_GOAL_TAG             : rpmvd.RP_init_res_FP_scen_rec_by_year(use_lists, rpc.RP_FP_SCEN_NO_STATUS_QUO_LIST, num_years_outputs, 0.0),
        rpmvt.RP_RES_PERC_CROP_NEEDED_MEET_GOAL_TAG                 : rpmvd.RP_init_res_FP_scen_rec_by_year(use_lists, rpc.RP_FP_SCEN_NO_STATUS_QUO_LIST, num_years_outputs, 0.0),
        rpmvt.RP_RES_COST_MAIN_STAPLE_CROP_PROD_TAG                 : rpmvd.RP_init_res_FP_scen_rec_by_year(use_lists, rpc.RP_FP_SCEN_NO_STATUS_QUO_LIST, num_years_outputs, 0.0),
        rpmvt.RP_RES_FOOD_NEEDED_RED_FOOD_INSEC_CUMU_TAG            : rpmvd.RP_init_res_FP_scen_rec(not include_status_quo, 0.0),
        rpmvt.RP_RES_COST_PROV_FOOD_AID_PEOPLE_FOOD_INSEC_ELIM_TAG  : rpmvd.RP_init_res_FP_scen_rec_by_year(use_lists, rpc.RP_FP_SCEN_NO_STATUS_QUO_LIST, num_years_outputs, 0.0),

        rpmvt.RP_RES_URBAN_POP_TAG                                  : rpmvd.RP_init_res_FP_scen_rec_by_year(use_lists, rpc.RP_FP_SCEN_NO_STATUS_QUO_LIST, num_years_outputs, 0.0),
        rpmvt.RP_RES_URBAN_HHS_LIVING_INF_SETTLEMENTS_TAG           : rpmvd.RP_init_res_FP_scen_rec_by_year(use_lists, rpc.RP_FP_SCEN_LIST, num_years_outputs, 0.0),
        rpmvt.RP_RES_HOUSES_TO_BUILD_CUMU_TAG                       : rpmvd.RP_init_res_FP_scen_rec(include_status_quo, 0.0),
        rpmvt.RP_RES_COST_BUILD_HOUSES_PEOPLE_RELOC_TAG             : rpmvd.RP_init_res_FP_scen_rec_by_year(use_lists, rpc.RP_FP_SCEN_NO_STATUS_QUO_LIST, num_years_outputs, 0.0),

        rpmvt.RP_RES_POP_ACCESS_ELEC_TAG                            : rpmvd.RP_init_res_FP_scen_rec_by_year(use_lists, rpc.RP_FP_SCEN_LIST, num_years_outputs, 0.0),
        rpmvt.RP_RES_ADD_PEOPLE_NEED_ACCESS_ELEC_CUMU_TAG           : rpmvd.RP_init_res_FP_scen_rec(include_status_quo, 0.0),
        rpmvt.RP_RES_CAP_COST_CONNECT_ADD_HHS_ELEC_TAG              : rpmvd.RP_init_res_FP_scen_rec_by_year(use_lists, rpc.RP_FP_SCEN_NO_STATUS_QUO_LIST, num_years_outputs, 0.0),
        rpmvt.RP_RES_KWH_NEEDED_SUFF_ELEC_LEVELS_TAG                : rpmvd.RP_init_res_FP_scen_rec_by_year(use_lists, rpc.RP_FP_SCEN_LIST, num_years_outputs, 0.0),
        rpmvt.RP_RES_COST_ELEC_TAG                                  : rpmvd.RP_init_res_FP_scen_rec_by_year(use_lists, rpc.RP_FP_SCEN_NO_STATUS_QUO_LIST, num_years_outputs, 0.0),
        rpmvt.RP_RES_HHS_CLEAN_COOK_FUEL_TECH_TAG                   : rpmvd.RP_init_res_FP_scen_rec_by_year(use_lists, rpc.RP_FP_SCEN_LIST, num_years_outputs, 0.0),
        rpmvt.RP_RES_ADD_HHS_NEED_ACCESS_CLEAN_COOK_TECH_CUMU_TAG   : rpmvd.RP_init_res_FP_scen_rec(include_status_quo, 0.0),
        rpmvt.RP_RES_COST_PROV_ADD_HHS_CLEAN_COOK_FUEL_TECH_TAG     : rpmvd.RP_init_res_FP_scen_rec_by_year(use_lists, rpc.RP_FP_SCEN_NO_STATUS_QUO_LIST, num_years_outputs, 0.0),

        rpmvt.RP_RES_AGE_DEPENDENCY_RATIO_TAG                       : rpmvd.RP_init_res_FP_scen_rec_by_year(use_lists, rpc.RP_FP_SCEN_NO_COUNTERFACTUAL_LIST, num_years_outputs, 0.0),
        rpmvt.RP_RES_GDP_PER_CAPITA_TAG                             : rpmvd.RP_init_res_FP_scen_rec_by_year(use_lists, rpc.RP_FP_SCEN_NO_COUNTERFACTUAL_LIST, num_years_outputs, 0.0),
        rpmvt.RP_RES_TOTAL_PEOPLE_WITH_JOBS_TAG                     : rpmvd.RP_init_res_FP_scen_rec_by_year(use_lists, rpc.RP_FP_SCEN_LIST, num_years_outputs, 0.0),
        rpmvt.RP_RES_ADD_JOBS_NEEDED_TAG                            : rpmvd.RP_init_res_FP_scen_rec_by_year(use_lists, rpc.RP_FP_SCEN_NO_STATUS_QUO_LIST, num_years_outputs, 0.0),
        rpmvt.RP_RES_NEET_TAG                                       : rpmvd.RP_init_res_FP_scen_rec_by_sex_year(use_lists, True, num_years_outputs, 0.0),
        rpmvt.RP_RES_ADD_NEET_TAG                                   : rpmvd.RP_init_res_FP_scen_rec_by_sex_year(use_lists, False, num_years_outputs, 0.0),
  
        rpmvt.RP_RES_NUM_POP_WITH_INTERV_TAG                   : rpmvd.RP_init_res_FP_scen_rec_by_year(use_lists, rpc.RP_FP_SCEN_LIST, num_years_outputs, 0.0),
        rpmvt.RP_RES_COST_POP_WITH_INTERV_TAG                  : rpmvd.RP_init_res_FP_scen_rec_by_year(use_lists, rpc.RP_FP_SCEN_NO_STATUS_QUO_LIST, num_years_outputs, 0.0),
    
        rpmvt.RP_RES_SSP_TEMP_CHANGES_FROM_BASE_TAG           : rpmvd.RP_init_res_SSP_scen_rec_by_year(use_lists, rpc.RP_SSP_LIST, num_years_outputs, 0.0),
        rpmvt.RP_RES_FEWER_KWH_NEEDED_BASED_ON_FP_ACC_TAG     : rpmvd.RP_init_res_SSP_scen_rec_by_year(use_lists, rpc.RP_SSP_LIST, num_years_outputs, 0.0),
        rpmvt.RP_RES_CUMU_SAVINGS_ELEC_COSTS_DUE_FP_ACC_TAG   : rpmvd.RP_init_res_SSP_cumu_rec(),
        rpmvt.RP_RES_ADD_HECTARES_SAVED_CLIMATE_COND_TAG      : rpmvd.RP_init_res_SSP_scen_rec_by_year(use_lists, rpc.RP_SSP_LIST, num_years_outputs, 0.0),
        rpmvt.RP_RES_GDP_PER_CAPITA_STATUS_QUO_TAG            : rpmvd.RP_init_res_SSP_scen_rec_by_year(use_lists, rpc.RP_SSP_BASE_LIST, num_years_outputs, 0.0),
        rpmvt.RP_RES_GDP_PER_CAPITA_ACC_TAG                   : rpmvd.RP_init_res_SSP_scen_rec_by_year(use_lists, rpc.RP_SSP_BASE_LIST, num_years_outputs, 0.0),
   
        rpmvt.RP_RES_SUMMARY_TAG : rpmvd.RP_init_res_summary_rec(),
    }

    # Meta MVs

    mod_vars_rec[rpmvt.RP_SECTOR_RECORDS_META_TAG]                   = sector_records_meta

    mod_vars_rec[rpmvt.RP_FP_SCEN_GOAL_META_TAG]                     = deepcopy(mod_vars_rec[rpmvt.RP_FP_SCEN_GOAL_TAG])
    mod_vars_rec[rpmvt.RP_FP_SCEN_COUNTERFACTUAL_META_TAG]           = deepcopy(mod_vars_rec[rpmvt.RP_FP_SCEN_COUNTERFACTUAL_TAG])
    mod_vars_rec[rpmvt.RP_FP_SCEN_SCALE_UP_META_TAG]                 = FP_scen_scale_up_rec

    mod_vars_rec[rpmvt.RP_HOUSEHOLD_SIZE_BASELINE_META_TAG]          = deepcopy(mod_vars_rec[rpmvt.RP_HOUSEHOLD_SIZE_BASELINE_TAG])

    mod_vars_rec[rpmvt.RP_FP_PERC_USERS_META_TAG]                    = deepcopy(mod_vars_rec[rpmvt.RP_FP_PERC_USERS_TAG])
    # mod_vars_rec[rpmvt.RP_FP_TYPICAL_USE_EFFECTIVENESS_META_TAG]     = []
    mod_vars_rec[rpmvt.RP_FP_AVG_ANNUAL_UNIT_DIRECT_COSTS_META_TAG]  = deepcopy(mod_vars_rec[rpmvt.RP_FP_AVG_ANNUAL_UNIT_DIRECT_COSTS_TAG])
    mod_vars_rec[rpmvt.RP_FP_INDIRECT_PROG_COSTS_META_TAG]           = deepcopy(mod_vars_rec[rpmvt.RP_FP_INDIRECT_PROG_COSTS_TAG])

    mod_vars_rec[rpmvt.RP_CLIMATE_PARAMS_META_TAG]                   = deepcopy(mod_vars_rec[rpmvt.RP_CLIMATE_PARAMS_TAG])

    mod_vars_rec[rpmvt.RP_SSP_META_TAG] = SSP_data

    mod_vars_rec[rpmvt.RP_SOURCES_META_TAG] = sources

    mod_vars_rec[rpmvt.RP_RP_SOURCES_TAG] = (
        'RAPID draws on a wide range of sources for initial parameter values that can be edited by the user.  ' +
        'Please refer to the source information on each page for details on the source for specific input.'
    )

    #Debugging
    #with open('C:\Proj\IHTSampleFile.JSON', 'w') as f:
    #   json.dump(mod_vars_dict, f)

    return mod_vars_rec