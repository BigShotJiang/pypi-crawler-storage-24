

# def get_PC_row_curr_ID(mst_ID):
#     curr_ID = 0

#     # Standard rows
#     if mst_ID == pcc.PC_PROG_SPEC_HR_HEADER_ROW_MST_ID:
#         curr_ID = pcc.PC_PROG_SPEC_HR_HEADER_ROW_CURR_ID

#     elif mst_ID == pcc.PC_NAT_LEVEL_STAFF_ROW_MST_ID:
#         curr_ID = pcc.PC_NAT_LEVEL_STAFF_ROW_CURR_ID

#     elif mst_ID == pcc.PC_REG_LEVEL_STAFF_ROW_MST_ID:
#         curr_ID = pcc.PC_REG_LEVEL_STAFF_ROW_CURR_ID

#     elif mst_ID == pcc.PC_DIST_LEVEL_STAFF_ROW_MST_ID:
#         curr_ID = pcc.PC_DIST_LEVEL_STAFF_ROW_CURR_ID

#     elif mst_ID == pcc.PC_TRAIN_HEADER_ROW_MST_ID:
#         curr_ID = pcc.PC_TRAIN_HEADER_ROW_CURR_ID

#     elif mst_ID == pcc.PC_INSERV_REFRESH_TRAIN_ROW_MST_ID:
#         curr_ID = pcc.PC_INSERV_REFRESH_TRAIN_ROW_CURR_ID

#     elif mst_ID == pcc.PC_TRAIN_OF_TRAIN_ROW_MST_ID:
#         curr_ID = pcc.PC_TRAIN_OF_TRAIN_ROW_CURR_ID

#     elif mst_ID == pcc.PC_DEV_TRAIN_PROG_MAT_ROW_MST_ID:
#         curr_ID = pcc.PC_DEV_TRAIN_PROG_MAT_ROW_CURR_ID

#     elif mst_ID == pcc.PC_CHANGE_PRESERV_TRAIN_CURRIC_ROW_MST_ID:
#         curr_ID = pcc.PC_CHANGE_PRESERV_TRAIN_CURRIC_ROW_CURR_ID

#     elif mst_ID == pcc.PC_SUPP_ACT_ROW_MST_ID:
#         curr_ID = pcc.PC_SUPP_ACT_ROW_CURR_ID

#     elif mst_ID == pcc.PC_SUPERVIS_HEADER_ROW_MST_ID:
#         curr_ID = pcc.PC_SUPERVIS_HEADER_ROW_CURR_ID

#     elif mst_ID == pcc.PC_COORD_MEET_ROW_MST_ID:
#         curr_ID = pcc.PC_COORD_MEET_ROW_CURR_ID

#     elif mst_ID == pcc.PC_NAT_STAFF_VISIT_LOCAL_ROW_MST_ID:
#         curr_ID = pcc.PC_NAT_STAFF_VISIT_LOCAL_ROW_CURR_ID

#     elif mst_ID == pcc.PC_MONITOR_EVAL_HEADER_ROW_MST_ID:
#         curr_ID = pcc.PC_MONITOR_EVAL_HEADER_ROW_CURR_ID

#     elif mst_ID == pcc.PC_DESIGN_ME_FRAME_SYS_ROW_MST_ID:
#         curr_ID = pcc.PC_DESIGN_ME_FRAME_SYS_ROW_CURR_ID

#     elif mst_ID == pcc.PC_DESIGN_QC_QA_ROW_MST_ID:
#         curr_ID = pcc.PC_DESIGN_QC_QA_ROW_CURR_ID

#     elif mst_ID == pcc.PC_DESIGN_REV_DATA_MGMT_SYS_ROW_MST_ID:
#         curr_ID = pcc.PC_DESIGN_REV_DATA_MGMT_SYS_ROW_CURR_ID
 
#     elif mst_ID == pcc.PC_DATA_COLLECT_ANALYSIS_ROW_MST_ID:
#         curr_ID = pcc.PC_DATA_COLLECT_ANALYSIS_ROW_CURR_ID

#     elif mst_ID == pcc.PC_QC_QA_ROW_MST_ID:
#         curr_ID = pcc.PC_QC_QA_ROW_CURR_ID

#     elif mst_ID == pcc.PC_INFRA_EQUIP_HEADER_ROW_MST_ID:
#         curr_ID = pcc.PC_INFRA_EQUIP_HEADER_ROW_CURR_ID

#     elif mst_ID == pcc.PC_SIT_ASSESS_INFRA_ROW_MST_ID:
#         curr_ID = pcc.PC_SIT_ASSESS_INFRA_ROW_CURR_ID

#     elif mst_ID == pcc.PC_EQUIP_UPGRADES_LOW_TIER_ROW_MST_ID:
#         curr_ID = pcc.PC_EQUIP_UPGRADES_LOW_TIER_ROW_CURR_ID

#     elif mst_ID == pcc.PC_EQUIP_UPGRADES_HOSP_ROW_MST_ID:
#         curr_ID = pcc.PC_EQUIP_UPGRADES_HOSP_ROW_CURR_ID

#     elif mst_ID == pcc.PC_TRANSPORT_HEADER_ROW_MST_ID:
#         curr_ID = pcc.PC_TRANSPORT_HEADER_ROW_CURR_ID

#     elif mst_ID == pcc.PC_SIT_ASSESS_TRANSPORT_ROW_MST_ID:
#         curr_ID = pcc.PC_SIT_ASSESS_TRANSPORT_ROW_CURR_ID

#     elif mst_ID == pcc.PC_NEW_VEHIC_PURCHASE_ROW_MST_ID:
#         curr_ID = pcc.PC_NEW_VEHIC_PURCHASE_ROW_CURR_ID

#     elif mst_ID == pcc.PC_VEHIC_OP_MAINT_ROW_MST_ID:
#         curr_ID = pcc.PC_VEHIC_OP_MAINT_ROW_CURR_ID

#     elif mst_ID == pcc.PC_COMM_MEDIA_HEADER_ROW_MST_ID:
#         curr_ID = pcc.PC_COMM_MEDIA_HEADER_ROW_CURR_ID

#     elif mst_ID == pcc.PC_DEV_COMM_STRAT_ROW_MST_ID:
#         curr_ID = pcc.PC_DEV_COMM_STRAT_ROW_CURR_ID

#     elif mst_ID == pcc.PC_MASS_MEDIA_COMM_ROW_MST_ID:
#         curr_ID = pcc.PC_MASS_MEDIA_COMM_ROW_CURR_ID

#     elif mst_ID == pcc.PC_PRINTED_MATS_ROW_MST_ID:
#         curr_ID = pcc.PC_PRINTED_MATS_ROW_CURR_ID

#     elif mst_ID == pcc.PC_SOCIAL_OUTR_ACTIV_ROW_MST_ID:
#         curr_ID = pcc.PC_SOCIAL_OUTR_ACTIV_ROW_CURR_ID

#     elif mst_ID == pcc.PC_ADVOC_HEADER_ROW_MST_ID:
#         curr_ID = pcc.PC_ADVOC_HEADER_ROW_CURR_ID

#     elif mst_ID == pcc.PC_PLAN_ADVOC_STRAT_ROW_MST_ID:
#         curr_ID = pcc.PC_PLAN_ADVOC_STRAT_ROW_CURR_ID

#     elif mst_ID == pcc.PC_ADVOC_ACTS_ROW_MST_ID:
#         curr_ID = pcc.PC_ADVOC_ACTS_ROW_CURR_ID

#     elif mst_ID == pcc.PC_ADVOC_MATS_ROW_MST_ID:
#         curr_ID = pcc.PC_ADVOC_MATS_ROW_CURR_ID

#     elif mst_ID == pcc.PC_GEN_PROG_MGMT_HEADER_ROW_MST_ID:
#         curr_ID = pcc.PC_GEN_PROG_MGMT_HEADER_ROW_CURR_ID

#     elif mst_ID == pcc.PC_DESIGN_REV_COUNTRY_STRAT_ROW_MST_ID:
#         curr_ID = pcc.PC_DESIGN_REV_COUNTRY_STRAT_ROW_CURR_ID

#     elif mst_ID == pcc.PC_DEV_REVIEW_ANNUAL_WORKPLAN_ROW_MST_ID:
#         curr_ID = pcc.PC_DEV_REVIEW_ANNUAL_WORKPLAN_ROW_CURR_ID

#     elif mst_ID == pcc.PC_DEV_REVIEW_HR_PLAN_ROW_MST_ID:
#         curr_ID = pcc.PC_DEV_REVIEW_HR_PLAN_ROW_CURR_ID

#     elif mst_ID == pcc.PC_PROG_COORD_MEET_ROW_MST_ID:
#         curr_ID = pcc.PC_PROG_COORD_MEET_ROW_CURR_ID

#     elif mst_ID == pcc.PC_COMMOD_REG_POL_ROW_MST_ID:
#         curr_ID = pcc.PC_COMMOD_REG_POL_ROW_CURR_ID

#     elif mst_ID == pcc.PC_SIT_ANALYSIS_ROW_MST_ID:
#         curr_ID = pcc.PC_SIT_ANALYSIS_ROW_CURR_ID

#     elif mst_ID == pcc.PC_OTHER_HEADER_ROW_MST_ID:
#         curr_ID = pcc.PC_OFFICE_EQUIP_SUPP_ROW_CURR_ID

#     elif mst_ID == pcc.PC_DBL_CLICK_ADD_OTHER_ITEMS_ROW_MST_ID:
#         curr_ID = pcc.PC_DBL_CLICK_ADD_OTHER_ITEMS_ROW_CURR_ID 

#     elif mst_ID == pcc.PC_OFFICE_EQUIP_SUPP_ROW_MST_ID:
#         curr_ID = pcc.PC_OTHER_HEADER_ROW_CURR_ID

#     elif mst_ID == pcc.PC_UTIL_ROW_MST_ID:
#         curr_ID = pcc.PC_UTIL_ROW_CURR_ID

#     # HIV rows

#     elif mst_ID == pcc.PC_POLICY_BASED_INTERV_ROW_MST_ID:
#         curr_ID = pcc.PC_POLICY_BASED_INTERV_ROW_CURR_ID

#     elif mst_ID == pcc.PC_SOC_ECON_SUPP_CHILD_ROW_MST_ID:
#         curr_ID = pcc.PC_SOC_ECON_SUPP_CHILD_ROW_CURR_ID

#     elif mst_ID == pcc.PC_PREV_VIOL_WOMEN_ROW_MST_ID: 
#         curr_ID = pcc.PC_PREV_VIOL_WOMEN_ROW_CURR_ID

#     elif mst_ID == pcc.PC_DECRIM_KEY_POP_BEHAV_ROW_MST_ID:
#         curr_ID = pcc.PC_DECRIM_KEY_POP_BEHAV_ROW_CURR_ID

#     elif mst_ID == pcc.PC_PREV_STIGMA_DISCRIM_ROW_MST_ID:
#         curr_ID = pcc.PC_PREV_STIGMA_DISCRIM_ROW_CURR_ID

#     elif mst_ID == pcc.PC_COMM_CIVIL_SOC_LEAD_ROW_MST_ID:
#         curr_ID = pcc.PC_COMM_CIVIL_SOC_LEAD_ROW_CURR_ID

#     elif mst_ID == pcc.PC_LEGAL_POLICY_REFORMS_ROW_MST_ID:
#         curr_ID = pcc.PC_LEGAL_POLICY_REFORMS_ROW_CURR_ID

#     elif mst_ID == pcc.PC_HIV_OTHER_HEADER_ROW_MST_ID:
#         curr_ID = pcc.PC_HIV_OTHER_HEADER_ROW_CURR_ID

#     elif mst_ID == pcc.PC_HIV_DBL_CLICK_ADD_OTHER_ITEMS_ROW_MST_ID:
#         curr_ID = pcc.PC_HIV_DBL_CLICK_ADD_OTHER_ITEMS_ROW_CURR_ID

#     return curr_ID

# # Need the programme area ID because some programme areas have different rows and the current IDs can overlap, unlike the master IDs.
# def get_PC_row_mst_ID(prog_area_ID = str, curr_ID = int):
#     mst_ID = 0

#     if (prog_area_ID == pccl.PC_IH_HIV_AIDS_MST_ID) and (curr_ID >= pcc.PC_POLICY_BASED_INTERV_ROW_CURR_ID):

#         if curr_ID == pcc.PC_POLICY_BASED_INTERV_ROW_CURR_ID:
#             mst_ID = pcc.PC_POLICY_BASED_INTERV_ROW_MST_ID

#         elif curr_ID == pcc.PC_SOC_ECON_SUPP_CHILD_ROW_CURR_ID:
#             mst_ID = pcc.PC_SOC_ECON_SUPP_CHILD_ROW_MST_ID

#         elif curr_ID == pcc.PC_PREV_VIOL_WOMEN_ROW_CURR_ID: 
#             mst_ID = pcc.PC_PREV_VIOL_WOMEN_ROW_MST_ID

#         elif curr_ID == pcc.PC_DECRIM_KEY_POP_BEHAV_ROW_CURR_ID:
#             mst_ID = pcc.PC_DECRIM_KEY_POP_BEHAV_ROW_MST_ID

#         elif curr_ID == pcc.PC_PREV_STIGMA_DISCRIM_ROW_CURR_ID:
#             mst_ID = pcc.PC_PREV_STIGMA_DISCRIM_ROW_MST_ID

#         elif curr_ID == pcc.PC_COMM_CIVIL_SOC_LEAD_ROW_CURR_ID:
#             mst_ID = pcc.PC_COMM_CIVIL_SOC_LEAD_ROW_MST_ID

#         elif curr_ID == pcc.PC_LEGAL_POLICY_REFORMS_ROW_CURR_ID:
#             mst_ID = pcc.PC_LEGAL_POLICY_REFORMS_ROW_MST_ID

#         elif curr_ID == pcc.PC_HIV_OTHER_HEADER_ROW_CURR_ID:
#             mst_ID = pcc.PC_HIV_OTHER_HEADER_ROW_MST_ID           

#         elif curr_ID == pcc.PC_HIV_DBL_CLICK_ADD_OTHER_ITEMS_ROW_CURR_ID:
#             mst_ID = pcc.PC_HIV_DBL_CLICK_ADD_OTHER_ITEMS_ROW_MST_ID

#     elif (prog_area_ID != pccl.PC_IH_HIV_AIDS_MST_ID) or (curr_ID < pcc.PC_SOC_ECON_SUPP_CHILD_ROW_CURR_ID):

#         if curr_ID == pcc.PC_PROG_SPEC_HR_HEADER_ROW_CURR_ID:
#             mst_ID = pcc.PC_PROG_SPEC_HR_HEADER_ROW_MST_ID

#         elif curr_ID == pcc.PC_NAT_LEVEL_STAFF_ROW_CURR_ID:
#             mst_ID = pcc.PC_NAT_LEVEL_STAFF_ROW_MST_ID

#         elif curr_ID == pcc.PC_REG_LEVEL_STAFF_ROW_CURR_ID:
#             mst_ID = pcc.PC_REG_LEVEL_STAFF_ROW_MST_ID

#         elif curr_ID == pcc.PC_DIST_LEVEL_STAFF_ROW_CURR_ID:
#             mst_ID = pcc.PC_DIST_LEVEL_STAFF_ROW_MST_ID

#         elif curr_ID == pcc.PC_TRAIN_HEADER_ROW_CURR_ID:
#             mst_ID = pcc.PC_TRAIN_HEADER_ROW_MST_ID

#         elif curr_ID == pcc.PC_INSERV_REFRESH_TRAIN_ROW_CURR_ID:
#             mst_ID = pcc.PC_INSERV_REFRESH_TRAIN_ROW_MST_ID

#         elif curr_ID == pcc.PC_TRAIN_OF_TRAIN_ROW_CURR_ID:
#             mst_ID = pcc.PC_TRAIN_OF_TRAIN_ROW_MST_ID

#         elif curr_ID == pcc.PC_DEV_TRAIN_PROG_MAT_ROW_CURR_ID:
#             mst_ID = pcc.PC_DEV_TRAIN_PROG_MAT_ROW_MST_ID

#         elif curr_ID == pcc.PC_CHANGE_PRESERV_TRAIN_CURRIC_ROW_CURR_ID:
#             mst_ID = pcc.PC_CHANGE_PRESERV_TRAIN_CURRIC_ROW_MST_ID

#         elif curr_ID == pcc.PC_SUPP_ACT_ROW_CURR_ID:
#             mst_ID = pcc.PC_SUPP_ACT_ROW_MST_ID

#         elif curr_ID == pcc.PC_SUPERVIS_HEADER_ROW_CURR_ID:
#             mst_ID = pcc.PC_SUPERVIS_HEADER_ROW_MST_ID

#         elif curr_ID == pcc.PC_COORD_MEET_ROW_CURR_ID:
#             mst_ID = pcc.PC_COORD_MEET_ROW_MST_ID

#         elif curr_ID == pcc.PC_NAT_STAFF_VISIT_LOCAL_ROW_CURR_ID:
#             mst_ID = pcc.PC_NAT_STAFF_VISIT_LOCAL_ROW_MST_ID

#         elif curr_ID == pcc.PC_MONITOR_EVAL_HEADER_ROW_CURR_ID:
#             mst_ID = pcc.PC_MONITOR_EVAL_HEADER_ROW_MST_ID

#         elif curr_ID == pcc.PC_DESIGN_ME_FRAME_SYS_ROW_CURR_ID:
#             mst_ID = pcc.PC_DESIGN_ME_FRAME_SYS_ROW_MST_ID

#         elif curr_ID == pcc.PC_DESIGN_QC_QA_ROW_CURR_ID:
#             mst_ID = pcc.PC_DESIGN_QC_QA_ROW_MST_ID

#         elif curr_ID == pcc.PC_DESIGN_REV_DATA_MGMT_SYS_ROW_CURR_ID:
#             mst_ID = pcc.PC_DESIGN_REV_DATA_MGMT_SYS_ROW_MST_ID
    
#         elif curr_ID == pcc.PC_DATA_COLLECT_ANALYSIS_ROW_CURR_ID:
#             mst_ID = pcc.PC_DATA_COLLECT_ANALYSIS_ROW_MST_ID

#         elif curr_ID == pcc.PC_QC_QA_ROW_CURR_ID:
#             mst_ID = pcc.PC_QC_QA_ROW_MST_ID

#         elif curr_ID == pcc.PC_INFRA_EQUIP_HEADER_ROW_CURR_ID:
#             mst_ID = pcc.PC_INFRA_EQUIP_HEADER_ROW_MST_ID

#         elif curr_ID == pcc.PC_SIT_ASSESS_INFRA_ROW_CURR_ID:
#             mst_ID = pcc.PC_SIT_ASSESS_INFRA_ROW_MST_ID

#         elif curr_ID == pcc.PC_EQUIP_UPGRADES_LOW_TIER_ROW_CURR_ID:
#             mst_ID = pcc.PC_EQUIP_UPGRADES_LOW_TIER_ROW_MST_ID

#         elif curr_ID == pcc.PC_EQUIP_UPGRADES_HOSP_ROW_CURR_ID:
#             mst_ID = pcc.PC_EQUIP_UPGRADES_HOSP_ROW_MST_ID

#         elif curr_ID == pcc.PC_TRANSPORT_HEADER_ROW_CURR_ID:
#             mst_ID = pcc.PC_TRANSPORT_HEADER_ROW_MST_ID

#         elif curr_ID == pcc.PC_SIT_ASSESS_TRANSPORT_ROW_CURR_ID:
#             mst_ID = pcc.PC_SIT_ASSESS_TRANSPORT_ROW_MST_ID

#         elif curr_ID == pcc.PC_NEW_VEHIC_PURCHASE_ROW_CURR_ID:
#             mst_ID = pcc.PC_NEW_VEHIC_PURCHASE_ROW_MST_ID

#         elif curr_ID == pcc.PC_VEHIC_OP_MAINT_ROW_CURR_ID:
#             mst_ID = pcc.PC_VEHIC_OP_MAINT_ROW_MST_ID

#         elif curr_ID == pcc.PC_COMM_MEDIA_HEADER_ROW_CURR_ID:
#             mst_ID = pcc.PC_COMM_MEDIA_HEADER_ROW_MST_ID

#         elif curr_ID == pcc.PC_DEV_COMM_STRAT_ROW_CURR_ID:
#             mst_ID = pcc.PC_DEV_COMM_STRAT_ROW_MST_ID

#         elif curr_ID == pcc.PC_MASS_MEDIA_COMM_ROW_CURR_ID:
#             mst_ID = pcc.PC_MASS_MEDIA_COMM_ROW_MST_ID

#         elif curr_ID == pcc.PC_PRINTED_MATS_ROW_CURR_ID:
#             mst_ID = pcc.PC_PRINTED_MATS_ROW_MST_ID

#         elif curr_ID == pcc.PC_SOCIAL_OUTR_ACTIV_ROW_CURR_ID:
#             mst_ID = pcc.PC_SOCIAL_OUTR_ACTIV_ROW_MST_ID

#         elif curr_ID == pcc.PC_ADVOC_HEADER_ROW_CURR_ID:
#             mst_ID = pcc.PC_ADVOC_HEADER_ROW_MST_ID

#         elif curr_ID == pcc.PC_PLAN_ADVOC_STRAT_ROW_CURR_ID:
#             mst_ID = pcc.PC_PLAN_ADVOC_STRAT_ROW_MST_ID

#         elif curr_ID == pcc.PC_ADVOC_ACTS_ROW_CURR_ID:
#             mst_ID = pcc.PC_ADVOC_ACTS_ROW_MST_ID

#         elif curr_ID == pcc.PC_ADVOC_MATS_ROW_CURR_ID:
#             mst_ID = pcc.PC_ADVOC_MATS_ROW_MST_ID

#         elif curr_ID == pcc.PC_GEN_PROG_MGMT_HEADER_ROW_CURR_ID:
#             mst_ID = pcc.PC_GEN_PROG_MGMT_HEADER_ROW_MST_ID

#         elif curr_ID == pcc.PC_DESIGN_REV_COUNTRY_STRAT_ROW_CURR_ID:
#             mst_ID = pcc.PC_DESIGN_REV_COUNTRY_STRAT_ROW_MST_ID

#         elif curr_ID == pcc.PC_DEV_REVIEW_ANNUAL_WORKPLAN_ROW_CURR_ID:
#             mst_ID = pcc.PC_DEV_REVIEW_ANNUAL_WORKPLAN_ROW_MST_ID

#         elif curr_ID == pcc.PC_DEV_REVIEW_HR_PLAN_ROW_CURR_ID:
#             mst_ID = pcc.PC_DEV_REVIEW_HR_PLAN_ROW_MST_ID

#         elif curr_ID == pcc.PC_PROG_COORD_MEET_ROW_CURR_ID:
#             mst_ID = pcc.PC_PROG_COORD_MEET_ROW_MST_ID

#         elif curr_ID == pcc.PC_COMMOD_REG_POL_ROW_CURR_ID:
#             mst_ID = pcc.PC_COMMOD_REG_POL_ROW_MST_ID

#         elif curr_ID == pcc.PC_SIT_ANALYSIS_ROW_CURR_ID:
#             mst_ID = pcc.PC_SIT_ANALYSIS_ROW_MST_ID

#         elif curr_ID == pcc.PC_OTHER_HEADER_ROW_CURR_ID:
#             mst_ID = pcc.PC_OTHER_HEADER_ROW_MST_ID

#         elif curr_ID == pcc.PC_DBL_CLICK_ADD_OTHER_ITEMS_ROW_CURR_ID:
#             mst_ID = pcc.PC_DBL_CLICK_ADD_OTHER_ITEMS_ROW_MST_ID 

#         elif curr_ID == pcc.PC_OFFICE_EQUIP_SUPP_ROW_CURR_ID:
#             mst_ID = pcc.PC_OFFICE_EQUIP_SUPP_ROW_MST_ID

#         elif curr_ID == pcc.PC_UTIL_ROW_CURR_ID:
#             mst_ID = pcc.PC_UTIL_ROW_MST_ID

#     return mst_ID

# def get_PC_row_name(mst_ID):
#     name = ''

#     # Standard rows

#     if mst_ID == pcc.PC_PROG_SPEC_HR_HEADER_ROW_MST_ID:
#         name = '1. Programme-specific human resources'

#     elif mst_ID == pcc.PC_NAT_LEVEL_STAFF_ROW_MST_ID:
#         name = '1.1 National-level staff'

#     elif mst_ID == pcc.PC_REG_LEVEL_STAFF_ROW_MST_ID:
#         name = '1.2 Regional-level staff'

#     elif mst_ID == pcc.PC_DIST_LEVEL_STAFF_ROW_MST_ID:
#         name = '1.3 District-level staff'

#     elif mst_ID == pcc.PC_TRAIN_HEADER_ROW_MST_ID:
#         name = '2. Training'

#     elif mst_ID == pcc.PC_INSERV_REFRESH_TRAIN_ROW_MST_ID:
#         name = '2.1 In-service / Refresher training'

#     elif mst_ID == pcc.PC_TRAIN_OF_TRAIN_ROW_MST_ID:
#         name = '2.2 Training of trainers'

#     elif mst_ID == pcc.PC_DEV_TRAIN_PROG_MAT_ROW_MST_ID:
#         name = '2.3 Development of training programmes and material'

#     elif mst_ID == pcc.PC_CHANGE_PRESERV_TRAIN_CURRIC_ROW_MST_ID:
#         name = '2.4 Changing the pre-service training curriculum'

#     elif mst_ID == pcc.PC_SUPP_ACT_ROW_MST_ID:
#         name = '2.5 Support activities'

#     elif mst_ID == pcc.PC_SUPERVIS_HEADER_ROW_MST_ID:
#         name = '3. Supervision'

#     elif mst_ID == pcc.PC_COORD_MEET_ROW_MST_ID:
#         name = '3.1 Coordination meetings'

#     elif mst_ID == pcc.PC_NAT_STAFF_VISIT_LOCAL_ROW_MST_ID:
#         name = '3.2 National staff visiting local staff'

#     elif mst_ID == pcc.PC_MONITOR_EVAL_HEADER_ROW_MST_ID:
#         name = '4. Monitoring and evaluation'

#     elif mst_ID == pcc.PC_DESIGN_ME_FRAME_SYS_ROW_MST_ID:
#         name = '4.1 Design of M & E frameworks and systems'

#     elif mst_ID == pcc.PC_DESIGN_QC_QA_ROW_MST_ID:
#         name = '4.2 Design of quality control and assurance'

#     elif mst_ID == pcc.PC_DESIGN_REV_DATA_MGMT_SYS_ROW_MST_ID:
#         name = '4.3 Design / review of data management systems'
 
#     elif mst_ID == pcc.PC_DATA_COLLECT_ANALYSIS_ROW_MST_ID:
#         name = '4.4 Data collection and analysis'

#     elif mst_ID == pcc.PC_QC_QA_ROW_MST_ID:
#         name = '4.5 Quality control / quality assurance'

#     elif mst_ID == pcc.PC_INFRA_EQUIP_HEADER_ROW_MST_ID:
#         name = '5. Infrastructure and equipment'

#     elif mst_ID == pcc.PC_SIT_ASSESS_INFRA_ROW_MST_ID:
#         name = '5.1  Situational assessment'

#     elif mst_ID == pcc.PC_EQUIP_UPGRADES_LOW_TIER_ROW_MST_ID:
#         name = '5.2 Equipment upgrades for lower-tier facilities'

#     elif mst_ID == pcc.PC_EQUIP_UPGRADES_HOSP_ROW_MST_ID:
#         name = '5.3 Equipment upgrades for hospitals'

#     elif mst_ID == pcc.PC_TRANSPORT_HEADER_ROW_MST_ID:
#         name = '6. Transport'

#     elif mst_ID == pcc.PC_SIT_ASSESS_TRANSPORT_ROW_MST_ID:
#         name = '6.1 Situational assessment'

#     elif mst_ID == pcc.PC_NEW_VEHIC_PURCHASE_ROW_MST_ID:
#         name = '6.2 New vehicle purchase'

#     elif mst_ID == pcc.PC_VEHIC_OP_MAINT_ROW_MST_ID:
#         name = '6.3 Vehicle operation and maintenance'

#     elif mst_ID == pcc.PC_COMM_MEDIA_HEADER_ROW_MST_ID:
#         name = '7. Communication, media, and outreach'

#     elif mst_ID == pcc.PC_DEV_COMM_STRAT_ROW_MST_ID:
#         name = '7.1 Development of communication strategy'

#     elif mst_ID == pcc.PC_MASS_MEDIA_COMM_ROW_MST_ID:
#         name = '7.2 Mass media'

#     elif mst_ID == pcc.PC_PRINTED_MATS_ROW_MST_ID:
#         name = '7.3 Printed materials'

#     elif mst_ID == pcc.PC_SOCIAL_OUTR_ACTIV_ROW_MST_ID:
#         name = '7.4 Social outreach activities'

#     elif mst_ID == pcc.PC_ADVOC_HEADER_ROW_MST_ID:
#         name = '8. Advocacy'

#     elif mst_ID == pcc.PC_PLAN_ADVOC_STRAT_ROW_MST_ID:
#         name = '8.1 Planning on advocacy strategy'

#     elif mst_ID == pcc.PC_ADVOC_ACTS_ROW_MST_ID:
#         name = '8.2 Advocacy activities'

#     elif mst_ID == pcc.PC_ADVOC_MATS_ROW_MST_ID:
#         name = '8.3 Advocacy materials'

#     elif mst_ID == pcc.PC_GEN_PROG_MGMT_HEADER_ROW_MST_ID:
#         name = '9. General programme management'

#     elif mst_ID == pcc.PC_DESIGN_REV_COUNTRY_STRAT_ROW_MST_ID:
#         name = '9.1 Design and review of country strategy'

#     elif mst_ID == pcc.PC_DEV_REVIEW_ANNUAL_WORKPLAN_ROW_MST_ID:
#         name = '9.2 Development and review of annual work plan'

#     elif mst_ID == pcc.PC_DEV_REVIEW_HR_PLAN_ROW_MST_ID:
#         name = '9.3 Development and review of human resources plan'

#     elif mst_ID == pcc.PC_PROG_COORD_MEET_ROW_MST_ID:
#         name = '9.4 Programme coordination meetings'

#     elif mst_ID == pcc.PC_COMMOD_REG_POL_ROW_MST_ID:
#         name = '9.5 Commodity regulation and policies'

#     elif mst_ID == pcc.PC_SIT_ANALYSIS_ROW_MST_ID:
#         name = '9.6 Situation analysis'

#     elif mst_ID == pcc.PC_OFFICE_EQUIP_SUPP_ROW_MST_ID:
#         name = '9.7 Office equipment and supplies'
        
#     elif mst_ID == pcc.PC_UTIL_ROW_MST_ID:
#         name = '9.8 Utilities'

#     elif mst_ID == pcc.PC_OTHER_HEADER_ROW_MST_ID:
#         name = '10. Other'

#     elif mst_ID == pcc.PC_DBL_CLICK_ADD_OTHER_ITEMS_ROW_MST_ID:
#         name = '10.1 Other items'

#     # HIV-specific rows

#     elif mst_ID == pcc.PC_POLICY_BASED_INTERV_ROW_MST_ID:
#         name = '10. Policy-based interventions'      

#     elif mst_ID == pcc.PC_SOC_ECON_SUPP_CHILD_ROW_MST_ID:
#         name = '10.1 Socioeconomic support for orphans and vulnerable children'         

#     elif mst_ID == pcc.PC_PREV_VIOL_WOMEN_ROW_MST_ID:           
#         name = '10.2 Prevention of violence against women'    

#     elif mst_ID == pcc.PC_DECRIM_KEY_POP_BEHAV_ROW_MST_ID:      
#         name = '10.3 Decriminalization of key population behaviors'   

#     elif mst_ID == pcc.PC_PREV_STIGMA_DISCRIM_ROW_MST_ID:       
#         name = '10.4 Prevention of stigma and discrimination'    

#     elif mst_ID == pcc.PC_COMM_CIVIL_SOC_LEAD_ROW_MST_ID:       
#         name = '10.5 Community and civil society leadership, including young people'    

#     elif mst_ID == pcc.PC_LEGAL_POLICY_REFORMS_ROW_MST_ID:       
#         name = '10.6 Legal, policy reforms'    

#     elif mst_ID == pcc.PC_HIV_OTHER_HEADER_ROW_MST_ID:                 
#         name = '11. Other'  

#     elif mst_ID == pcc.PC_HIV_DBL_CLICK_ADD_OTHER_ITEMS_ROW_MST_ID:    
#         name = '11.1 Other items'

#     return name

# def get_PC_row_string_constant(mst_ID):
#     string_constant = ''

#     # Standard rows
#     if mst_ID == pcc.PC_PROG_SPEC_HR_HEADER_ROW_MST_ID:
#         string_constant = 'GB_stprogSpecHR'

#     elif mst_ID == pcc.PC_NAT_LEVEL_STAFF_ROW_MST_ID:
#         string_constant = 'GB_stNatStaff'

#     elif mst_ID == pcc.PC_REG_LEVEL_STAFF_ROW_MST_ID:
#         string_constant = 'GB_stISProvinStaff'

#     elif mst_ID == pcc.PC_DIST_LEVEL_STAFF_ROW_MST_ID:
#         string_constant = 'GB_stDistStaff'

#     elif mst_ID == pcc.PC_TRAIN_HEADER_ROW_MST_ID:
#         string_constant = 'GB_stTraining'

#     elif mst_ID == pcc.PC_INSERV_REFRESH_TRAIN_ROW_MST_ID:
#         string_constant = 'GB_stInServRefTrain'

#     elif mst_ID == pcc.PC_TRAIN_OF_TRAIN_ROW_MST_ID:
#         string_constant = 'GB_stTrainOfTrainers'

#     elif mst_ID == pcc.PC_DEV_TRAIN_PROG_MAT_ROW_MST_ID:
#         string_constant = 'GB_stDevTrainProgAndMat'

#     elif mst_ID == pcc.PC_CHANGE_PRESERV_TRAIN_CURRIC_ROW_MST_ID:
#         string_constant = 'GB_stChangePreServTrain'

#     elif mst_ID == pcc.PC_SUPP_ACT_ROW_MST_ID:
#         string_constant = 'GB_stSuppActivities'

#     elif mst_ID == pcc.PC_SUPERVIS_HEADER_ROW_MST_ID:
#         string_constant = 'GB_stSupervision'

#     elif mst_ID == pcc.PC_COORD_MEET_ROW_MST_ID:
#         string_constant = 'GB_stCoordMeets'

#     elif mst_ID == pcc.PC_NAT_STAFF_VISIT_LOCAL_ROW_MST_ID:
#         string_constant = 'GB_stNatStaffVisLocal'

#     elif mst_ID == pcc.PC_MONITOR_EVAL_HEADER_ROW_MST_ID:
#         string_constant = 'GB_stMonitAndEval'

#     elif mst_ID == pcc.PC_DESIGN_ME_FRAME_SYS_ROW_MST_ID:
#         string_constant = 'GB_stDesMEFramewrkSys'

#     elif mst_ID == pcc.PC_DESIGN_QC_QA_ROW_MST_ID:
#         string_constant = 'GB_stDesQCAssur'

#     elif mst_ID == pcc.PC_DESIGN_REV_DATA_MGMT_SYS_ROW_MST_ID:
#         string_constant = 'GB_stDesRevDataMgmt'
 
#     elif mst_ID == pcc.PC_DATA_COLLECT_ANALYSIS_ROW_MST_ID:
#         string_constant = 'GB_stDataCollectAna'

#     elif mst_ID == pcc.PC_QC_QA_ROW_MST_ID:
#         string_constant = 'GB_stMonitQualityControl'

#     elif mst_ID == pcc.PC_INFRA_EQUIP_HEADER_ROW_MST_ID:
#         string_constant = 'GB_stInfraEquip'

#     elif mst_ID == pcc.PC_SIT_ASSESS_INFRA_ROW_MST_ID:
#         string_constant = 'GB_stInfraSituationalAsses'

#     elif mst_ID == pcc.PC_EQUIP_UPGRADES_LOW_TIER_ROW_MST_ID:
#         string_constant = 'GB_stEquipUpgradesLowTierFac'

#     elif mst_ID == pcc.PC_EQUIP_UPGRADES_HOSP_ROW_MST_ID:
#         string_constant = 'GB_stEquipUpgradesHospitals'

#     elif mst_ID == pcc.PC_TRANSPORT_HEADER_ROW_MST_ID:
#         string_constant = 'SM_stTransport'

#     elif mst_ID == pcc.PC_SIT_ASSESS_TRANSPORT_ROW_MST_ID:
#         string_constant = 'GB_stTransSituationalAsses'

#     elif mst_ID == pcc.PC_NEW_VEHIC_PURCHASE_ROW_MST_ID:
#         string_constant = 'GB_stNewVehicPurchase'

#     elif mst_ID == pcc.PC_VEHIC_OP_MAINT_ROW_MST_ID:
#         string_constant = 'GB_stVehicOpMaint'

#     elif mst_ID == pcc.PC_COMM_MEDIA_HEADER_ROW_MST_ID:
#         string_constant = 'GB_stCommMediaOutrch'

#     elif mst_ID == pcc.PC_DEV_COMM_STRAT_ROW_MST_ID:
#         string_constant = 'GB_stDevCommStrat'

#     elif mst_ID == pcc.PC_MASS_MEDIA_COMM_ROW_MST_ID:
#         string_constant = 'GB_stMassMedia'

#     elif mst_ID == pcc.PC_PRINTED_MATS_ROW_MST_ID:
#         string_constant = 'GB_stPrintedMats'

#     elif mst_ID == pcc.PC_SOCIAL_OUTR_ACTIV_ROW_MST_ID:
#         string_constant = 'GB_stSocialOutreachActiv'

#     elif mst_ID == pcc.PC_ADVOC_HEADER_ROW_MST_ID:
#         string_constant = 'GB_stAdvocacy'

#     elif mst_ID == pcc.PC_PLAN_ADVOC_STRAT_ROW_MST_ID:
#         string_constant = 'GB_stPannAdvocacyStrat'

#     elif mst_ID == pcc.PC_ADVOC_ACTS_ROW_MST_ID:
#         string_constant = 'GB_stAdvocacyActiv'

#     elif mst_ID == pcc.PC_ADVOC_MATS_ROW_MST_ID:
#         string_constant = 'GB_stAdvocacyMats'

#     elif mst_ID == pcc.PC_GEN_PROG_MGMT_HEADER_ROW_MST_ID:
#         string_constant = 'GB_stGenProgMgmt'

#     elif mst_ID == pcc.PC_DESIGN_REV_COUNTRY_STRAT_ROW_MST_ID:
#         string_constant = 'GB_stDesRevCntyStrat'

#     elif mst_ID == pcc.PC_DEV_REVIEW_ANNUAL_WORKPLAN_ROW_MST_ID:
#         string_constant = 'GB_stDevRevAnnWrkPlan'

#     elif mst_ID == pcc.PC_DEV_REVIEW_HR_PLAN_ROW_MST_ID:
#         string_constant = 'GB_stDevRevHRPlan'

#     elif mst_ID == pcc.PC_PROG_COORD_MEET_ROW_MST_ID:
#         string_constant = 'GB_stProgCoordMeet'

#     elif mst_ID == pcc.PC_COMMOD_REG_POL_ROW_MST_ID:
#         string_constant = 'GB_stCommodityRegPolicyNoNum'

#     elif mst_ID == pcc.PC_SIT_ANALYSIS_ROW_MST_ID:
#         string_constant = 'GB_stPCSitAnaCoordGrp'

#     elif mst_ID == pcc.PC_OTHER_HEADER_ROW_MST_ID:
#         string_constant = 'GB_stOther'

#     elif mst_ID == pcc.PC_DBL_CLICK_ADD_OTHER_ITEMS_ROW_MST_ID:
#         string_constant = 'GB_stAddOtherItems'

#     elif mst_ID == pcc.PC_OFFICE_EQUIP_SUPP_ROW_MST_ID:
#         string_constant = 'GB_stOfficeEquipSupplies'
        
#     elif mst_ID == pcc.PC_UTIL_ROW_MST_ID:
#         string_constant = 'GB_stUtilities'

#     # HIV-specific rows

#     elif mst_ID == pcc.PC_POLICY_BASED_INTERV_ROW_MST_ID:
#         string_constant = 'GB_stPolicyBasedInterventions'

#     elif mst_ID == pcc.PC_SOC_ECON_SUPP_CHILD_ROW_MST_ID:
#         string_constant = 'GB_stSocioeconSuppChildren'

#     elif mst_ID == pcc.PC_PREV_VIOL_WOMEN_ROW_MST_ID:           
#         string_constant = 'GB_stPrevViolenceAgainstWomen'       

#     elif mst_ID == pcc.PC_DECRIM_KEY_POP_BEHAV_ROW_MST_ID:      
#         string_constant = 'GB_stDecrimKeyPopBehav'           

#     elif mst_ID == pcc.PC_PREV_STIGMA_DISCRIM_ROW_MST_ID:       
#         string_constant = 'GB_stPrevStigmaDiscrim'    

#     elif mst_ID == pcc.PC_COMM_CIVIL_SOC_LEAD_ROW_MST_ID:       
#         string_constant = 'GB_stCommCivilSocLead'    

#     elif mst_ID == pcc.PC_LEGAL_POLICY_REFORMS_ROW_MST_ID:       
#         string_constant = 'GB_stLegalPolicyReforms'    

#     elif mst_ID == pcc.PC_HIV_OTHER_HEADER_ROW_MST_ID:                 
#         string_constant = 'GB_stOther'  

#     elif mst_ID == pcc.PC_HIV_DBL_CLICK_ADD_OTHER_ITEMS_ROW_MST_ID:    
#         string_constant = 'GB_stAddOtherItems'

#     return string_constant

# def get_PC_row_is_aggregate(mst_ID):
#     # HIV programme area has different rows at the end, but the master IDs don't overlap with the standard programme areas, so we can utilize
#     # the same function.
#     if (mst_ID == pcc.PC_PROG_SPEC_HR_HEADER_ROW_MST_ID) \
#         or (mst_ID == pcc.PC_TRAIN_HEADER_ROW_MST_ID) \
#         or (mst_ID == pcc.PC_SUPERVIS_HEADER_ROW_MST_ID) \
#         or (mst_ID == pcc.PC_MONITOR_EVAL_HEADER_ROW_MST_ID) \
#         or (mst_ID == pcc.PC_INFRA_EQUIP_HEADER_ROW_MST_ID) \
#         or (mst_ID == pcc.PC_TRANSPORT_HEADER_ROW_MST_ID) \
#         or (mst_ID == pcc.PC_COMM_MEDIA_HEADER_ROW_MST_ID) \
#         or (mst_ID == pcc.PC_ADVOC_HEADER_ROW_MST_ID) \
#         or (mst_ID == pcc.PC_GEN_PROG_MGMT_HEADER_ROW_MST_ID) \
#         or (mst_ID == pcc.PC_OTHER_HEADER_ROW_MST_ID) \
#         or (mst_ID == pcc.PC_HIV_OTHER_HEADER_ROW_MST_ID):
#             return True
#     else:
#         return False

# def get_PC_row_has_data(prog_area_ID = str, mst_ID = str):
#     if (prog_area_ID == pccl.PC_IH_HIV_AIDS_MST_ID) and (mst_ID == pcc.PC_POLICY_BASED_INTERV_ROW_MST_ID):
#         return False
#     else:
#         return True

# def get_PC_row_is_cost(prog_area_ID = str, mst_ID = str):
#     if (prog_area_ID == pccl.PC_IH_HIV_AIDS_MST_ID) and (mst_ID == pcc.PC_POLICY_BASED_INTERV_ROW_MST_ID):
#         return False
#     else:
#         return True

# def get_PC_row_is_single_line(prog_area_ID = str, mst_ID = str):
#     if ((prog_area_ID == pccl.PC_IH_HIV_AIDS_MST_ID) and ((mst_ID == pcc.PC_SOC_ECON_SUPP_CHILD_ROW_MST_ID) 
#         or (mst_ID == pcc.PC_PREV_VIOL_WOMEN_ROW_MST_ID) 
#         or (mst_ID == pcc.PC_DECRIM_KEY_POP_BEHAV_ROW_MST_ID) 
#         or (mst_ID == pcc.PC_PREV_STIGMA_DISCRIM_ROW_MST_ID) 
#         or (mst_ID == pcc.PC_PREV_STIGMA_DISCRIM_ROW_MST_ID) 
#         or (mst_ID == pcc.PC_COMM_CIVIL_SOC_LEAD_ROW_MST_ID) 
#         or (mst_ID == pcc.PC_LEGAL_POLICY_REFORMS_ROW_MST_ID))):
#             return True
#     else:
#         return False

# def get_PPLI_intensity_value(phase_ID):
#     intensity = 0

#     if phase_ID == pcc.PC_EARLY_IMP_PHASE_25_PPLI_MST_ID:
#         intensity = 25

#     elif phase_ID == pcc.PC_PARTIAL_IMP_PHASE_50_PPLI_MST_ID:
#         intensity = 50

#     elif phase_ID == pcc.PC_FULL_IMP_PHASE_100_PPLI_MST_ID:
#         intensity = 100

#     return intensity

# def get_PPLI_phase_curr_ID(phase_ID):
#     phase_curr_ID = gbc.GB_NOT_FOUND

#     if phase_ID == pcc.PC_NO_ACTION_PHASE_0_PPLI_MST_ID:
#         phase_curr_ID = pcc.PC_NO_ACTION_PHASE_0_PPLI_CURR_ID

#     elif phase_ID == pcc.PC_PLANNING_PHASE_0_PPLI_MST_ID:
#         phase_curr_ID = pcc.PC_PLANNING_PHASE_0_PPLI_CURR_ID

#     elif phase_ID == pcc.PC_EARLY_IMP_PHASE_25_PPLI_MST_ID:
#         phase_curr_ID = pcc.PC_EARLY_IMP_PHASE_25_PPLI_CURR_ID

#     elif phase_ID == pcc.PC_PARTIAL_IMP_PHASE_50_PPLI_MST_ID:
#         phase_curr_ID = pcc.PC_PARTIAL_IMP_PHASE_50_PPLI_CURR_ID

#     elif phase_ID == pcc.PC_FULL_IMP_PHASE_100_PPLI_MST_ID:
#         phase_curr_ID = pcc.PC_FULL_IMP_PHASE_100_PPLI_CURR_ID

#     return phase_curr_ID

# def PC_get_health_sys_admin_unit_ID(admin_level_curr_ID):
#     ID = str(gbc.GB_NOT_FOUND)

#     if admin_level_curr_ID == pcc.PC_PPLI_NATIONAL_ADMIN_LEVEL_CURR_ID:
#         ID = str(pccl.PC_IH_NATIONAL_HSAU_MST_ID)

#     elif admin_level_curr_ID == pcc.PC_PPLI_PROVINCE_ADMIN_LEVEL_CURR_ID:
#         ID = str(pccl.PC_IH_PROVINCE_HSAU_MST_ID)

#     elif admin_level_curr_ID == pcc.PC_PPLI_DISTRICT_ADMIN_LEVEL_CURR_ID:
#         ID = str(pccl.PC_IH_DISTRICT_HSAU_MST_ID)

#     return ID

