import SpectrumCommon.Const.GB.GBConst as gbc

import SpectrumCommon.Const.RP.RPModVarFields as rpmvf

#######################################################################################################
#                                                                                                     #
#                                       Sectors                                                       #
#                                                                                                     #
#######################################################################################################

def get_RP_sector_rec(sector_records = list, ID = str):
    sector_recs = [sector_rec for sector_rec in sector_records if sector_rec[rpmvf.RP_SECTOR_ID] == ID]
    return sector_recs[0] if len(sector_recs) > 0 else gbc.GB_NOT_FOUND
   
def set_RP_edu_sector_prim_sch_start_age(sector_rec = dict, value = int):
    sector_rec[rpmvf.RP_SECTOR_EDU_PRIM_SCH_START_AGE] = value

# Education

def set_RP_edu_sector_prim_sch_end_age(sector_rec = dict, value = int):
    sector_rec[rpmvf.RP_SECTOR_EDU_PRIM_SCH_END_AGE] = value

def set_RP_edu_sector_sec_sch_start_age(sector_rec = dict, value = int):
    sector_rec[rpmvf.RP_SECTOR_EDU_SEC_SCH_START_AGE] = value

def set_RP_edu_sector_sec_sch_end_age(sector_rec = dict, value = int):
    sector_rec[rpmvf.RP_SECTOR_EDU_SEC_SCH_END_AGE] = value

# def set_RP_edu_sector_student_per_teacher_prim(sector_rec = dict, value = float):
#     sector_rec[rpmvf.RP_SECTOR_EDU_STUDENT_PER_TEACHER_PRIM] = value

def get_RP_edu_sector_avg_ann_teacher_sal_prim_GDP_ratio(sector_rec = dict):
    return sector_rec[rpmvf.RP_SECTOR_EDU_AVG_ANN_TEACHER_SAL_PRIM_GDP_RATIO]

def set_RP_edu_sector_avg_ann_teacher_sal_prim_GDP_ratio(sector_rec = dict, value = int):
    sector_rec[rpmvf.RP_SECTOR_EDU_AVG_ANN_TEACHER_SAL_PRIM_GDP_RATIO] = value

# def set_RP_edu_sector_avg_ann_teacher_sal_sec(sector_rec = dict, value = int):
#     sector_rec[rpmvf.RP_SECTOR_EDU_AVG_ANN_TEACHER_SAL_SEC] = value

def get_RP_edu_sector_prim_spend_per_student_perc_GDP(sector_rec = dict):
    return sector_rec[rpmvf.RP_SECTOR_EDU_PRIM_SPEND_PER_STUDENT_PERC_GDP]

def set_RP_edu_sector_prim_spend_per_student_perc_GDP(sector_rec = dict, value = int):
    sector_rec[rpmvf.RP_SECTOR_EDU_PRIM_SPEND_PER_STUDENT_PERC_GDP] = value

def set_RP_edu_sector_sec_spend_per_student_perc_GDP(sector_rec = dict, value = int):
    sector_rec[rpmvf.RP_SECTOR_EDU_SEC_SPEND_PER_STUDENT_PERC_GDP] = value

# Health

def get_RP_health_sector_avg_unit_cost_skilled_deliv(sector_rec = dict):
    return sector_rec[rpmvf.RP_SECTOR_HLTH_AVG_UNIT_COST_SKILLED_DELIV]

def set_RP_health_sector_avg_unit_cost_skilled_deliv(sector_rec = dict, value = float):
    sector_rec[rpmvf.RP_SECTOR_HLTH_AVG_UNIT_COST_SKILLED_DELIV] = value

def get_RP_health_sector_avg_unit_cost_ANC_4_plus_visits(sector_rec = dict):
    return sector_rec[rpmvf.RP_SECTOR_HLTH_AVG_UNIT_COST_ANC_4_PLUS_VISITS]

def set_RP_health_sector_avg_unit_cost_ANC_4_plus_visits(sector_rec = dict, value = float):
    sector_rec[rpmvf.RP_SECTOR_HLTH_AVG_UNIT_COST_ANC_4_PLUS_VISITS] = value

def get_RP_health_sector_perc_skilled_hlth_prof_doctors(sector_rec = dict):
    return sector_rec[rpmvf.RP_SECTOR_HLTH_PERC_SKILLED_HLTH_PROF_DOCTORS]

def set_RP_health_sector_perc_skilled_hlth_prof_doctors(sector_rec = dict, value = int):
    sector_rec[rpmvf.RP_SECTOR_HLTH_PERC_SKILLED_HLTH_PROF_DOCTORS] = value

def get_RP_health_sector_perc_skilled_hlth_prof_nurses(sector_rec = dict):
    return sector_rec[rpmvf.RP_SECTOR_HLTH_PERC_SKILLED_HLTH_PROF_NURSES]

def set_RP_health_sector_perc_skilled_hlth_prof_nurses(sector_rec = dict, value = int):
    sector_rec[rpmvf.RP_SECTOR_HLTH_PERC_SKILLED_HLTH_PROF_NURSES] = value

def get_RP_health_sector_avg_salary_doctors(sector_rec = dict):
    return sector_rec[rpmvf.RP_SECTOR_HLTH_AVG_SALARY_DOCTORS]

def set_RP_health_sector_avg_salary_doctors(sector_rec = dict, value = float):
    sector_rec[rpmvf.RP_SECTOR_HLTH_AVG_SALARY_DOCTORS] = value

def get_RP_health_sector_avg_salary_nurses(sector_rec = dict):
    return sector_rec[rpmvf.RP_SECTOR_HLTH_AVG_SALARY_NURSES]

def set_RP_health_sector_avg_salary_nurses(sector_rec = dict, value = float):
    sector_rec[rpmvf.RP_SECTOR_HLTH_AVG_SALARY_NURSES] = value

# WASH

def get_RP_WASH_sector_cap_costs_per_HH_impr_water(sector_rec = dict):
    return sector_rec[rpmvf.RP_SECTOR_WASH_CAP_COSTS_PER_HH_IMPR_WATER]

def set_RP_WASH_sector_cap_costs_per_HH_impr_water(sector_rec = dict, value = float):
    sector_rec[rpmvf.RP_SECTOR_WASH_CAP_COSTS_PER_HH_IMPR_WATER] = value

def set_RP_WASH_sector_ann_cost_menstrual_hlth_comm(sector_rec = dict, value = float):
    sector_rec[rpmvf.RP_SECTOR_WASH_ANN_COST_MENSTRUAL_HLTH_COMM] = value

def get_RP_WASH_sector_cap_costs_per_HH_impr_sani(sector_rec = dict):
    return sector_rec[rpmvf.RP_SECTOR_WASH_CAP_COSTS_PER_HH_IMPR_SANI]

def set_RP_WASH_sector_cap_costs_per_HH_impr_sani(sector_rec = dict, value = float):
    sector_rec[rpmvf.RP_SECTOR_WASH_CAP_COSTS_PER_HH_IMPR_SANI] = value

# Food security

def set_RP_food_sector_prim_staple_crop(sector_rec = dict, value = str):
    sector_rec[rpmvf.RP_SECTOR_FOOD_PRIM_STAPLE_CROP] = value

def set_RP_food_sector_agricult_land(sector_rec = dict, value = int):
    sector_rec[rpmvf.RP_SECTOR_FOOD_AGRICULT_LAND] = value

def get_RP_food_sector_crop_land(sector_rec = dict):
    return sector_rec[rpmvf.RP_SECTOR_FOOD_CROP_LAND]

def set_RP_food_sector_crop_land(sector_rec = dict, value = int):
    sector_rec[rpmvf.RP_SECTOR_FOOD_CROP_LAND] = value

def get_RP_food_sector_staple_crop_prod_baseline(sector_rec = dict):
    return sector_rec[rpmvf.RP_SECTOR_FOOD_STAPLE_CROP_PROD_BASELINE]

def set_RP_food_sector_staple_crop_prod_baseline(sector_rec = dict, value = int):
    sector_rec[rpmvf.RP_SECTOR_FOOD_STAPLE_CROP_PROD_BASELINE] = value

def set_RP_food_sector_area_harv_staple_crop(sector_rec = dict, value = int):
    sector_rec[rpmvf.RP_SECTOR_FOOD_AREA_HARV_STAPLE_CROP] = value

def get_RP_food_sector_tonnes_harv_perc_hect(sector_rec = dict):
    return sector_rec[rpmvf.RP_SECTOR_FOOD_TONNES_HARV_PERC_HECT]

def set_RP_food_sector_tonnes_harv_perc_hect(sector_rec = dict, value = float):
    sector_rec[rpmvf.RP_SECTOR_FOOD_TONNES_HARV_PERC_HECT] = value

def get_RP_food_sector_ann_kg_per_year_consump_staple_crop(sector_rec = dict):
    return sector_rec[rpmvf.RP_SECTOR_FOOD_ANN_KG_PER_YEAR_CONSUMP_STAPLE_CROP]

def set_RP_food_sector_ann_kg_per_year_consump_staple_crop(sector_rec = dict, value = int):
    sector_rec[rpmvf.RP_SECTOR_FOOD_ANN_KG_PER_YEAR_CONSUMP_STAPLE_CROP] = value

def get_RP_food_sector_prod_costs_staple_crop(sector_rec = dict):
    return sector_rec[rpmvf.RP_SECTOR_FOOD_PROD_COSTS_STAPLE_CROP]

def set_RP_food_sector_prod_costs_staple_crop(sector_rec = dict, value = float):
    sector_rec[rpmvf.RP_SECTOR_FOOD_PROD_COSTS_STAPLE_CROP] = value

def get_RP_food_sector_daily_cost_food_aid(sector_rec = dict):
    return sector_rec[rpmvf.RP_SECTOR_FOOD_DAILY_COST_FOOD_AID]

def set_RP_food_sector_daily_cost_food_aid(sector_rec = dict, value = float):
    sector_rec[rpmvf.RP_SECTOR_FOOD_DAILY_COST_FOOD_AID] = value

# Urbanization

def get_RP_urb_sector_perc_pop_urb_baseline_year(sector_rec = dict):
    return sector_rec[rpmvf.RP_SECTOR_URB_PERC_POP_URB_BASELINE_YEAR]

def set_RP_urb_sector_perc_pop_urb_baseline_year(sector_rec = dict, value = int):
    sector_rec[rpmvf.RP_SECTOR_URB_PERC_POP_URB_BASELINE_YEAR] = value

def get_RP_urb_sector_perc_pop_urb_endline_year(sector_rec = dict):
    return sector_rec[rpmvf.RP_SECTOR_URB_PERC_POP_URB_ENDLINE_YEAR]

def set_RP_urb_sector_perc_pop_urb_endline_year(sector_rec = dict, value = int):
    sector_rec[rpmvf.RP_SECTOR_URB_PERC_POP_URB_ENDLINE_YEAR] = value

def get_RP_urb_sector_cost_per_HH_move_to_housing(sector_rec = dict):
    return sector_rec[rpmvf.RP_SECTOR_URB_COST_PER_HH_MOVE_TO_HOUSING]

def set_RP_urb_sector_cost_per_HH_move_to_housing(sector_rec = dict, value = float):
    sector_rec[rpmvf.RP_SECTOR_URB_COST_PER_HH_MOVE_TO_HOUSING] = value

# Energy

def set_RP_energy_sector_energy_KWh_prod_per_cap_per_year(sector_rec = dict, value = float):
    sector_rec[rpmvf.RP_SECTOR_ENERGY_KWH_PROD_PER_CAP_PER_YEAR] = value

def get_RP_energy_sector_cap_cost_per_HH_connect_grid(sector_rec = dict):
    return sector_rec[rpmvf.RP_SECTOR_ENERGY_CAP_COSTS_PER_HH_CONNECT_GRID]

def set_RP_energy_sector_cap_cost_per_HH_connect_grid(sector_rec = dict, value = int):
    sector_rec[rpmvf.RP_SECTOR_ENERGY_CAP_COSTS_PER_HH_CONNECT_GRID] = value

def get_RP_energy_sector_cap_cost_per_HH_clean_cooking(sector_rec = dict):
    return sector_rec[rpmvf.RP_SECTOR_ENERGY_CAP_COSTS_PER_HH_CLEAN_COOKING]

def set_RP_energy_sector_cap_cost_per_HH_clean_cooking(sector_rec = dict, value = int):
    sector_rec[rpmvf.RP_SECTOR_ENERGY_CAP_COSTS_PER_HH_CLEAN_COOKING] = value

def get_RP_energy_sector_cost_per_KWh(sector_rec = dict):
    return sector_rec[rpmvf.RP_SECTOR_ENERGY_COST_PER_KWH]

def set_RP_energy_sector_cost_per_KWh(sector_rec = dict, value = float):
    sector_rec[rpmvf.RP_SECTOR_ENERGY_COST_PER_KWH] = value

# Economic

def get_RP_eco_sector_GDP_per_capita(sector_rec = dict):
    return sector_rec[rpmvf.RP_SECTOR_ECO_GDP_PER_CAPITA]

def set_RP_eco_sector_GDP_per_capita(sector_rec = dict, value = float):
    sector_rec[rpmvf.RP_SECTOR_ECO_GDP_PER_CAPITA] = value

# def set_RP_eco_sector_baseline_GDP(sector_rec = dict, value = int):
#     sector_rec[rpmvf.RP_SECTOR_ECO_BASELINE_GDP] = value

# def set_RP_eco_sector_GDP_growth_rate(sector_rec = dict, value = float):
#     sector_rec[rpmvf.RP_SECTOR_ECO_GDP_GROWTH_RATE] = value

def get_RP_eco_sector_labor_partic_rate(sector_rec = dict):
    return sector_rec[rpmvf.RP_SECTOR_ECO_LABOR_PARTIC_RATE]

def set_RP_eco_sector_labor_partic_rate(sector_rec = dict, value = float):
    sector_rec[rpmvf.RP_SECTOR_ECO_LABOR_PARTIC_RATE] = value

def get_RP_eco_sector_change_GDP_CDR(sector_rec = dict):
    return sector_rec[rpmvf.RP_SECTOR_ECO_CHANGE_GDP_CDR]

def set_RP_eco_sector_change_GDP_CDR(sector_rec = dict, value = float):
    sector_rec[rpmvf.RP_SECTOR_ECO_CHANGE_GDP_CDR] = value

# Build Your Own

def get_RP_BYO_sector_targ_pop(sector_rec = dict):
    return sector_rec[rpmvf.RP_SECTOR_BYO_TARG_POP]

def set_RP_BYO_sector_targ_pop(sector_rec = dict, value = int):
    sector_rec[rpmvf.RP_SECTOR_BYO_TARG_POP] = value

def get_RP_BYO_sector_multiplier_1(sector_rec = dict):
    return sector_rec[rpmvf.RP_SECTOR_BYO_MULTIPLIER_1]

def set_RP_BYO_sector_multiplier_1(sector_rec = dict, value = int):
    sector_rec[rpmvf.RP_SECTOR_BYO_MULTIPLIER_1] = value

def get_RP_BYO_sector_unit_cost_2(sector_rec = dict):
    return sector_rec[rpmvf.RP_SECTOR_BYO_UNIT_COST_2]

def set_RP_BYO_sector_unit_cost_2(sector_rec = dict, value = float):
    sector_rec[rpmvf.RP_SECTOR_BYO_UNIT_COST_2] = value

#######################################################################################################
#                                                                                                     #
#                                       Goals                                                         #
#                                                                                                     #
#######################################################################################################

def get_RP_goal_rec(sector_rec = dict, ID = str):
    goal_recs = [goal_rec for goal_rec in sector_rec[rpmvf.RP_SECTOR_GOAL_RECORDS] if goal_rec[rpmvf.RP_GOAL_ID] == ID]
    return goal_recs[0] if len(goal_recs) > 0 else gbc.GB_NOT_FOUND

def get_RP_goal_selected_subgoal_ID(goal_rec = dict):
    return goal_rec[rpmvf.RP_GOAL_SELECTED_SUBGOAL_ID]

def get_RP_BYO_goal_resulting_change(goal_rec = dict, t = int):
    return goal_rec[rpmvf.RP_GOAL_RESULTING_CHANGE][t]

def set_RP_BYO_goal_resulting_change(goal_rec = dict, t = int, value = float):
    goal_rec[rpmvf.RP_GOAL_RESULTING_CHANGE][t] = value

#######################################################################################################
#                                                                                                     #
#                                       Subgoals                                                      #
#                                                                                                     #
#######################################################################################################

def get_RP_subgoal_rec(goal_rec = dict, ID = str):
    subgoal_recs = [subgoal_rec for subgoal_rec in goal_rec[rpmvf.RP_GOAL_SUBGOAL_RECORDS] if subgoal_rec[rpmvf.RP_SUBGOAL_ID] == ID]
    return subgoal_recs[0] if len(subgoal_recs) > 0 else gbc.GB_NOT_FOUND

def get_RP_subgoal_resulting_change(subgoal_rec = dict, t = int):
    return subgoal_rec[rpmvf.RP_SUBGOAL_RESULTING_CHANGE][t]

def set_RP_subgoal_resulting_change(subgoal_rec = dict, t = int, value = float):
    subgoal_rec[rpmvf.RP_SUBGOAL_RESULTING_CHANGE][t] = value

def get_RP_subgoal_resulting_change_by_sex(subgoal_rec = dict, sex = int, t = int):
    return subgoal_rec[rpmvf.RP_SUBGOAL_RESULTING_CHANGE][sex - 1][t]

def set_RP_subgoal_resulting_change_by_sex(subgoal_rec = dict, sex = int, t = int, value = float):
    subgoal_rec[rpmvf.RP_SUBGOAL_RESULTING_CHANGE][sex - 1][t] = value

#######################################################################################################
#                                                                                                     #
#                                       Climate parameters                                            #
#                                                                                                     #
#######################################################################################################

def get_RP_climate_baseline_mean_med_temp(climate_params_rec = dict):
    return climate_params_rec[rpmvf.RP_CLIM_BASELINE_MEAN_MED_TEMP]

def set_RP_climate_baseline_mean_med_temp(climate_params_rec = dict, value = float):
    climate_params_rec[rpmvf.RP_CLIM_BASELINE_MEAN_MED_TEMP] = value

def get_RP_climate_perc_change_GDP_1_degree_warm(climate_params_rec = dict):
    return climate_params_rec[rpmvf.RP_CLIM_PERC_CHANGE_GDP_1_DEG_WARM]

def set_RP_climate_perc_change_GDP_1_degree_warm(climate_params_rec = dict, value = float):
    climate_params_rec[rpmvf.RP_CLIM_PERC_CHANGE_GDP_1_DEG_WARM] = value

def get_RP_climate_perc_change_energy_needs_1_degree_warm(climate_params_rec = dict):
    return climate_params_rec[rpmvf.RP_CLIM_PERC_CHANGE_ENERGY_NEEDS_1_DEG_WARM]

def set_RP_climate_perc_change_energy_needs_1_degree_warm(climate_params_rec = dict, value = float):
    climate_params_rec[rpmvf.RP_CLIM_PERC_CHANGE_ENERGY_NEEDS_1_DEG_WARM] = value

def get_RP_climate_perc_change_staple_crop_1_degree_warm(climate_params_rec = dict):
    return climate_params_rec[rpmvf.RP_CLIM_PERC_CHANGE_STAPLE_CROP_1_DEG_WARM]

def set_RP_climate_perc_change_staple_crop_1_degree_warm(climate_params_rec = dict, value = float):
    climate_params_rec[rpmvf.RP_CLIM_PERC_CHANGE_STAPLE_CROP_1_DEG_WARM] = value

def get_RP_climate_perc_change_staple_crop_2_degree_warm(climate_params_rec = dict):
    return climate_params_rec[rpmvf.RP_CLIM_PERC_CHANGE_STAPLE_CROP_2_DEG_WARM]

def set_RP_climate_perc_change_staple_crop_2_degree_warm(climate_params_rec = dict, value = float):
    climate_params_rec[rpmvf.RP_CLIM_PERC_CHANGE_STAPLE_CROP_2_DEG_WARM] = value

def get_RP_climate_perc_change_staple_crop_3_degree_warm(climate_params_rec = dict):
    return climate_params_rec[rpmvf.RP_CLIM_PERC_CHANGE_STAPLE_CROP_3_DEG_WARM]

def set_RP_climate_perc_change_staple_crop_3_degree_warm(climate_params_rec = dict, value = float):
    climate_params_rec[rpmvf.RP_CLIM_PERC_CHANGE_STAPLE_CROP_3_DEG_WARM] = value