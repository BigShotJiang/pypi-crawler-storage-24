import numpy as np
from copy import deepcopy


import SpectrumCommon.Const.GB.GBConst as gbc
import SpectrumCommon.Const.RP.RPConst as rpc
import SpectrumCommon.Const.RP.RPModVarFields as rpmvf
# import SpectrumCommon.Util.RP.RPUtilLink as rpul

# def RP_create_sector_rec(ID = int, on = bool, num_years = int, meta : bool = False):
def RP_create_sector_rec(ID = int, num_years = int, meta : bool = False):
    sector_rec = { 
        rpmvf.RP_SECTOR_ID           : ID,
        # rpmvf.RP_SECTOR_ON           : on, # Moved to GB since this info is shown in the Projection Manager which apparently can only use GB/PJ MVs
        rpmvf.RP_SECTOR_GOAL_RECORDS : RP_init_goal_records(ID, num_years, meta),
    }

    if ID == rpc.RP_EDUCATION_SECTOR_MST_ID:
        sector_rec[rpmvf.RP_SECTOR_EDU_PRIM_SCH_START_AGE] = 0
        sector_rec[rpmvf.RP_SECTOR_EDU_PRIM_SCH_END_AGE] = 0
        sector_rec[rpmvf.RP_SECTOR_EDU_SEC_SCH_START_AGE] = 0
        sector_rec[rpmvf.RP_SECTOR_EDU_SEC_SCH_END_AGE] = 0
        # sector_rec[rpmvf.RP_SECTOR_EDU_STUDENT_PER_TEACHER_PRIM] = 0.0
        sector_rec[rpmvf.RP_SECTOR_EDU_AVG_ANN_TEACHER_SAL_PRIM_GDP_RATIO] = 0
        # sector_rec[rpmvf.RP_SECTOR_EDU_AVG_ANN_TEACHER_SAL_SEC] = 0
        sector_rec[rpmvf.RP_SECTOR_EDU_PRIM_SPEND_PER_STUDENT_PERC_GDP] = 0
        sector_rec[rpmvf.RP_SECTOR_EDU_SEC_SPEND_PER_STUDENT_PERC_GDP] = 0

    elif ID == rpc.RP_HEALTH_SECTOR_MST_ID:
        sector_rec[rpmvf.RP_SECTOR_HLTH_AVG_UNIT_COST_SKILLED_DELIV] = 0.0
        sector_rec[rpmvf.RP_SECTOR_HLTH_AVG_UNIT_COST_ANC_4_PLUS_VISITS] = 0.0
        sector_rec[rpmvf.RP_SECTOR_HLTH_PERC_SKILLED_HLTH_PROF_DOCTORS] = 0
        sector_rec[rpmvf.RP_SECTOR_HLTH_PERC_SKILLED_HLTH_PROF_NURSES] = 0
        sector_rec[rpmvf.RP_SECTOR_HLTH_AVG_SALARY_DOCTORS] = 0.0
        sector_rec[rpmvf.RP_SECTOR_HLTH_AVG_SALARY_NURSES] = 0.0

    elif ID == rpc.RP_WASH_SECTOR_MST_ID:
        sector_rec[rpmvf.RP_SECTOR_WASH_CAP_COSTS_PER_HH_IMPR_WATER] = 0.0
        sector_rec[rpmvf.RP_SECTOR_WASH_ANN_COST_MENSTRUAL_HLTH_COMM] = 0.0
        sector_rec[rpmvf.RP_SECTOR_WASH_CAP_COSTS_PER_HH_IMPR_SANI] = 0.0

    elif ID == rpc.RP_FOOD_SECURITY_SECTOR_MST_ID:
        sector_rec[rpmvf.RP_SECTOR_FOOD_PRIM_STAPLE_CROP] = ''
        sector_rec[rpmvf.RP_SECTOR_FOOD_AGRICULT_LAND] = 0
        sector_rec[rpmvf.RP_SECTOR_FOOD_CROP_LAND] = 0
        sector_rec[rpmvf.RP_SECTOR_FOOD_STAPLE_CROP_PROD_BASELINE] = 0
        sector_rec[rpmvf.RP_SECTOR_FOOD_AREA_HARV_STAPLE_CROP] = 0
        sector_rec[rpmvf.RP_SECTOR_FOOD_TONNES_HARV_PERC_HECT] = 0.0
        sector_rec[rpmvf.RP_SECTOR_FOOD_ANN_KG_PER_YEAR_CONSUMP_STAPLE_CROP] = 0
        sector_rec[rpmvf.RP_SECTOR_FOOD_PROD_COSTS_STAPLE_CROP] = 0.0
        sector_rec[rpmvf.RP_SECTOR_FOOD_DAILY_COST_FOOD_AID] = 0.0

    elif ID == rpc.RP_URBANIZATION_SECTOR_MST_ID:
        sector_rec[rpmvf.RP_SECTOR_URB_PERC_POP_URB_BASELINE_YEAR] = 0
        sector_rec[rpmvf.RP_SECTOR_URB_PERC_POP_URB_ENDLINE_YEAR] = 0
        sector_rec[rpmvf.RP_SECTOR_URB_COST_PER_HH_MOVE_TO_HOUSING] = 0.0

    elif ID == rpc.RP_ENERGY_SECTOR_MST_ID:
        sector_rec[rpmvf.RP_SECTOR_ENERGY_KWH_PROD_PER_CAP_PER_YEAR] = 0.0
        sector_rec[rpmvf.RP_SECTOR_ENERGY_CAP_COSTS_PER_HH_CONNECT_GRID] = 0
        sector_rec[rpmvf.RP_SECTOR_ENERGY_CAP_COSTS_PER_HH_CLEAN_COOKING] = 0
        sector_rec[rpmvf.RP_SECTOR_ENERGY_COST_PER_KWH] = 0.0

    elif ID == rpc.RP_ECONOMIC_SECTOR_MST_ID:
        sector_rec[rpmvf.RP_SECTOR_ECO_GDP_PER_CAPITA] = 0.0
        # sector_rec[rpmvf.RP_SECTOR_ECO_BASELINE_GDP] = 0
        # sector_rec[rpmvf.RP_SECTOR_ECO_GDP_GROWTH_RATE] = 0.0
        sector_rec[rpmvf.RP_SECTOR_ECO_LABOR_PARTIC_RATE] = 0.0

    elif ID == rpc.RP_BUILD_YOUR_OWN_SECTOR_MST_ID:
        # sector_rec[rpmvf.RP_SECTOR_BYO_POP] = ''
        sector_rec[rpmvf.RP_SECTOR_BYO_INTERV] = ''
        sector_rec[rpmvf.RP_SECTOR_BYO_TARG_POP] = rpc.RP_TP_TOTAL_POP_MST_ID
        # sector_rec[rpmvf.RP_SECTOR_BYO_UNIT_OF_ANALYSIS_1] = ''
        sector_rec[rpmvf.RP_SECTOR_BYO_MULTIPLIER_1] = 0
        sector_rec[rpmvf.RP_SECTOR_BYO_UNIT_OF_ANALYSIS_2] = ''
        sector_rec[rpmvf.RP_SECTOR_BYO_UNIT_COST_2] = 0.0

    return sector_rec

def RP_create_goal_rec(sector_ID = int, goal_ID = int, num_years = int, meta : bool = False):
    goal_rec = {
        rpmvf.RP_GOAL_ON  : True,
        rpmvf.RP_GOAL_ID  : goal_ID,
    }

    RC_format = rpc.RP_SECTOR_GOAL_RC_FORMATS[sector_ID][goal_ID]

    if RC_format != rpc.RP_RC_NOT_APPLICABLE:
        if rpc.RP_SECTOR_DEFAULT_SUBGOALS[sector_ID]:
            if meta:
                goal_rec[rpmvf.RP_GOAL_DEFAULT_SUBGOAL_ID] = rpc.RP_SECTOR_DEFAULT_SUBGOALS[sector_ID][goal_ID]
            else:
                goal_rec[rpmvf.RP_GOAL_SELECTED_SUBGOAL_ID] = rpc.RP_SECTOR_DEFAULT_SUBGOALS[sector_ID][goal_ID]

    # Special case: Build your own sector has it's resulting change in the goal record, since it has no subgoals. All other sectors have at 
    # least one goal with a subgoal.
    if sector_ID == rpc.RP_BUILD_YOUR_OWN_SECTOR_MST_ID:
        goal_rec[rpmvf.RP_GOAL_RESULTING_CHANGE] = np.full((num_years), 0.0).tolist()
    else:
        goal_rec[rpmvf.RP_GOAL_SUBGOAL_RECORDS] = RP_init_subgoal_records(sector_ID, goal_ID, num_years, meta)

    return goal_rec

def RP_create_subgoal_rec(sector_ID = int, goal_ID = int, subgoal_ID = int, num_years = int):
    subgoal_rec = {
        rpmvf.RP_SUBGOAL_ID : subgoal_ID,
    }

    # Resulting change will take one of three forms depending on the goal: sex x time, time, or non-existant
    RC_format = rpc.RP_SECTOR_GOAL_RC_FORMATS[sector_ID][goal_ID]

    if RC_format == rpc.RP_RC_BY_SEX_YEAR:
        subgoal_rec[rpmvf.RP_SUBGOAL_RESULTING_CHANGE] = np.full((gbc.GB_NumSexes, num_years), 0.0).tolist()

    elif RC_format == rpc.RP_RC_BY_YEAR:
        subgoal_rec[rpmvf.RP_SUBGOAL_RESULTING_CHANGE] = np.full((num_years), 0.0).tolist()

    return subgoal_rec

def RP_create_climate_params_rec():
    return {
        rpmvf.RP_CLIM_BASELINE_MEAN_MED_TEMP              : 0.0,
        rpmvf.RP_CLIM_PERC_CHANGE_GDP_1_DEG_WARM          : 0.0,
        rpmvf.RP_CLIM_PERC_CHANGE_ENERGY_NEEDS_1_DEG_WARM : 0.0,
        rpmvf.RP_CLIM_PERC_CHANGE_STAPLE_CROP_1_DEG_WARM  : 0.0,
        rpmvf.RP_CLIM_PERC_CHANGE_STAPLE_CROP_2_DEG_WARM  : 0.0,
        rpmvf.RP_CLIM_PERC_CHANGE_STAPLE_CROP_3_DEG_WARM  : 0.0,
    }

# def RP_init_sector_records(sector_on = list, num_years = int, meta : bool = False):
def RP_init_sector_records(num_years = int, meta : bool = False):
    sectors = []

    for sector_ID in rpc.RP_SECTOR_MST_IDS:
        if (not meta) or (sector_ID != rpc.RP_BUILD_YOUR_OWN_SECTOR_MST_ID):
            # sector_rec = RP_create_sector_rec(sector_ID, sector_ID in sector_on, num_years, meta)
            sector_rec = RP_create_sector_rec(sector_ID, num_years, meta)
            # sector_rec = RP_create_sector_rec(sector_ID, sector_on[rpc.RP_SECTOR_CURR_ID_MAP[sector_ID] - 1] , num_years)
            sectors.append(sector_rec)

    return sectors

def RP_init_goal_records(sector_ID = int, num_years = int, meta : bool = False):
    goals = []

    for goal_ID in rpc.RP_SECTOR_GOALS[sector_ID]:
        goal_rec = RP_create_goal_rec(sector_ID, goal_ID, num_years, meta)
        goals.append(goal_rec)

    return goals

def RP_init_subgoal_records(sector_ID = int, goal_ID = int, num_years = int, meta : bool = False):
    subgoals = []

    for subgoal_ID in rpc.RP_GOAL_SUBGOALS[f"{sector_ID}_{goal_ID}"]:
        # user_spec_subgoal_ID = rpc.RP_GOAL_USER_SPEC_SUBGOALS[f"{sector_ID}_{goal_ID}"]

        # if meta or ((not meta) and (subgoal_ID == user_spec_subgoal_ID)):
        subgoal_rec = RP_create_subgoal_rec(sector_ID, goal_ID, subgoal_ID, num_years)
        subgoals.append(subgoal_rec)

    return subgoals

def RP_init_sector_list():
    sectors_on = deepcopy(rpc.RP_SECTOR_MST_IDS)
    sectors_on.remove(rpc.RP_BUILD_YOUR_OWN_SECTOR_MST_ID)
    return sectors_on
    # return np.full((rpc.RP_NUM_DEFAULT_SECTORS), True).tolist()

def RP_init_res_FP_scen_rec(include_status_quo = bool, value = 0.0):
    scenario_rec = {
        rpmvf.RP_RES_FP_SCEN_GOAL           : value,
        rpmvf.RP_RES_FP_SCEN_COUNTERFACTUAL : value
    }

    if include_status_quo:
        scenario_rec[rpmvf.RP_RES_FP_SCEN_STATUS_QUO] = value

    return scenario_rec

def RP_init_res_FP_scen_rec_by_year(use_lists = bool, scenarios_to_include : list = rpc.RP_FP_SCEN_LIST, num_years = int, value = 0.0):
    scenario_rec = {}

    if rpc.RP_FP_SCEN_STATUS_QUO_MST_ID in scenarios_to_include:
        scenario_rec[rpmvf.RP_RES_FP_SCEN_STATUS_QUO] = np.full((num_years), value, gbc.GB_CALC_FLOAT_TYPE)

    if rpc.RP_FP_SCEN_GOAL_MST_ID in scenarios_to_include:
        scenario_rec[rpmvf.RP_RES_FP_SCEN_GOAL] = np.full((num_years), value, gbc.GB_CALC_FLOAT_TYPE)

    if rpc.RP_FP_SCEN_COUNTERFACTUAL_MST_ID in scenarios_to_include:
        scenario_rec[rpmvf.RP_RES_FP_SCEN_COUNTERFACTUAL] = np.full((num_years), value, gbc.GB_CALC_FLOAT_TYPE)

    if use_lists:
        for key, value in scenario_rec.items():
            if isinstance(value, np.ndarray):
                scenario_rec[key] = value.tolist()

    return scenario_rec

def RP_init_res_FP_scen_rec_by_sex_year(use_lists = bool, include_status_quo = bool, num_years = int, value = 0.0):
    scenario_rec = {
        rpmvf.RP_RES_FP_SCEN_GOAL           : np.full((gbc.GB_NumSexes + 1, num_years), value, gbc.GB_CALC_FLOAT_TYPE),
        rpmvf.RP_RES_FP_SCEN_COUNTERFACTUAL : np.full((gbc.GB_NumSexes + 1, num_years), value, gbc.GB_CALC_FLOAT_TYPE)
    }

    if include_status_quo:
        scenario_rec[rpmvf.RP_RES_FP_SCEN_STATUS_QUO] = np.full((gbc.GB_NumSexes + 1, num_years), value, gbc.GB_CALC_FLOAT_TYPE)

    if use_lists:
        scenario_rec[rpmvf.RP_RES_FP_SCEN_GOAL] = scenario_rec[rpmvf.RP_RES_FP_SCEN_GOAL].tolist()
        scenario_rec[rpmvf.RP_RES_FP_SCEN_COUNTERFACTUAL] = scenario_rec[rpmvf.RP_RES_FP_SCEN_COUNTERFACTUAL].tolist()

        if include_status_quo:
            scenario_rec[rpmvf.RP_RES_FP_SCEN_STATUS_QUO] = scenario_rec[rpmvf.RP_RES_FP_SCEN_STATUS_QUO].tolist()

    return scenario_rec

def RP_init_res_FP_scen_rec_by_sex_age_year(use_lists = bool, num_years = int, value = 0.0):
    scenario_rec = {
        rpmvf.RP_RES_FP_SCEN_GOAL           : np.full((gbc.GB_NumSexes + 1, gbc.GB_MaxSingleAges + 1, num_years), value, gbc.GB_CALC_FLOAT_TYPE),
        rpmvf.RP_RES_FP_SCEN_COUNTERFACTUAL : np.full((gbc.GB_NumSexes + 1, gbc.GB_MaxSingleAges + 1, num_years), value, gbc.GB_CALC_FLOAT_TYPE)
    }

    if use_lists:
        scenario_rec[rpmvf.RP_RES_FP_SCEN_GOAL] = scenario_rec[rpmvf.RP_RES_FP_SCEN_GOAL].tolist()
        scenario_rec[rpmvf.RP_RES_FP_SCEN_COUNTERFACTUAL] = scenario_rec[rpmvf.RP_RES_FP_SCEN_COUNTERFACTUAL].tolist()

    return scenario_rec

def RP_init_FP_scen_scale_up_rec(num_years):
    return {
        rpmvf.RP_FP_SCEN_SC_ACCELERATED : np.full((num_years), 0.0, gbc.GB_CALC_FLOAT_TYPE).tolist(),
        rpmvf.RP_FP_SCEN_SC_MEDIAN      : np.full((num_years), 0.0, gbc.GB_CALC_FLOAT_TYPE).tolist(),
        rpmvf.RP_FP_SCEN_SC_FLATLINE    : np.full((num_years), 0.0, gbc.GB_CALC_FLOAT_TYPE).tolist(),
    }

def RP_init_res_SSP_cumu_rec():
    return {
        rpmvf.RP_SSP1 : 0,
        rpmvf.RP_SSP2 : 0,
        rpmvf.RP_SSP5 : 0,
    }

def RP_init_res_SSP_scen_rec_by_year(use_lists = bool, scenarios_to_include : list = rpc.RP_SSP_LIST, num_years = int, value = 0.0):
    scenario_rec = {}

    if rpc.RP_SSP_BASE_MST_ID in scenarios_to_include:
        scenario_rec[rpmvf.RP_SSP_BASE] = np.full((num_years), value, gbc.GB_CALC_FLOAT_TYPE)

    if rpc.RP_SSP1_MST_ID in scenarios_to_include:
        scenario_rec[rpmvf.RP_SSP1] = np.full((num_years), value, gbc.GB_CALC_FLOAT_TYPE)

    if rpc.RP_SSP2_MST_ID in scenarios_to_include:
        scenario_rec[rpmvf.RP_SSP2] = np.full((num_years), value, gbc.GB_CALC_FLOAT_TYPE)

    if rpc.RP_SSP3_MST_ID in scenarios_to_include:
        scenario_rec[rpmvf.RP_SSP3] = np.full((num_years), value, gbc.GB_CALC_FLOAT_TYPE)

    if rpc.RP_SSP5_MST_ID in scenarios_to_include:
        scenario_rec[rpmvf.RP_SSP5] = np.full((num_years), value, gbc.GB_CALC_FLOAT_TYPE)

    if use_lists:
        for key, value in scenario_rec.items():
            if isinstance(value, np.ndarray):
                scenario_rec[key] = value.tolist()

    return scenario_rec

def RP_init_sources_rec():
    return {
        rpmvf.RP_SRC_HH_SIZE                               : '',
        rpmvf.RP_SRC_FP_METHOD_MIX                         : '',
        rpmvf.RP_SRC_FP_EFFECTIVENESS                      : '',
        rpmvf.RP_SRC_FP_UNIT_COSTS                         : '',
        rpmvf.RP_SRC_DP_FIRST_YEAR_POP                     : '',
        rpmvf.RP_SRC_FP_TFR                                : '',

        rpmvf.RP_SRC_SECTOR_EDU_SCHOOL_AGE_RANGES          : '',
        rpmvf.RP_SRC_SECTOR_EDU_AVG_ANN_TEACHER_SAL_PRIM   : '',
        rpmvf.RP_SRC_SECTOR_EDU_ANN_COST_EDU_PRIM_STUDENT  : '',
        rpmvf.RP_SRC_SECTOR_EDU_ANN_COST_EDU_SEC_STUDENT    : '',

        rpmvf.RP_SRC_SECTOR_HLTH_AVG_UNIT_COST_SKILLED_DELIV     : '',
        rpmvf.RP_SRC_SECTOR_HLTH_AVG_UNIT_COST_ANC_4_PLUS_VISITS : '',
        rpmvf.RP_SRC_SECTOR_HLTH_PERC_SKILLED_HLTH_PROF_DOCTORS  : '',
        rpmvf.RP_SRC_SECTOR_HLTH_PERC_SKILLED_HLTH_PROF_NURSES   : '',
        rpmvf.RP_SRC_SECTOR_HLTH_AVG_SALARY_DOCTORS              : '',
        rpmvf.RP_SRC_SECTOR_HLTH_AVG_SALARY_NURSES               : '',

        rpmvf.RP_SRC_SECTOR_WASH_CAP_COSTS_PER_HH_IMPR_WATER     : '',
        rpmvf.RP_SRC_SECTOR_WASH_CAP_COSTS_PER_HH_IMPR_SANI      : '',

        rpmvf.RP_SRC_SECTOR_FOOD_PRIM_STAPLE_CROP                    : '',
        rpmvf.RP_SRC_SECTOR_FOOD_CROP_LAND                           : '',
        rpmvf.RP_SRC_SECTOR_FOOD_STAPLE_CROP_PROD_BASE               : '',
        rpmvf.RP_SRC_SECTOR_FOOD_TONNES_HARV_PERC_HECT               : '',
        rpmvf.RP_SRC_SECTOR_FOOD_ANN_KG_PER_YEAR_CONSUMP_STAPLE_CROP : '',
        rpmvf.RP_SRC_SECTOR_FOOD_PROD_COSTS_STAPLE_CROP              : '',
        rpmvf.RP_SRC_SECTOR_FOOD_DAILY_COST_FOOD_AID                 : '',

        rpmvf.RP_SRC_SECTOR_URB_PERC_POP_URB_BASE_END         : '',
        rpmvf.RP_SRC_SECTOR_URB_COST_PER_HH_MOVE_TO_HOUSING   : '',

        rpmvf.RP_SRC_SECTOR_ENERGY_CAP_COSTS_PER_HH_CONNECT_GRID    : '',
        rpmvf.RP_SRC_SECTOR_ENERGY_CAP_COSTS_PER_HH_CLEAN_COOKING   : '',

        rpmvf.RP_SRC_SECTOR_ECO_GDP_PER_CAPITA    : '',
        rpmvf.RP_SRC_SECTOR_ECO_LABOR_PARTIC_RATE : '',
        rpmvf.RP_SRC_SECTOR_ECO_CHANGE_GDP_CDR    : '',

        rpmvf.RP_SRC_GOALS_PRIMARY_ENROLL_ALL          : '',
        rpmvf.RP_SRC_GOALS_PRIMARY_ENROLL_MALE         : '',
        rpmvf.RP_SRC_GOALS_PRIMARY_ENROLL_FEMALE       : '',
        rpmvf.RP_SRC_GOALS_SECONDARY_ENROLL_ALL        : '',
        rpmvf.RP_SRC_GOALS_SECONDARY_ENROLL_MALE       : '',
        rpmvf.RP_SRC_GOALS_SECONDARY_ENROLL_FEMALE     : '',
        rpmvf.RP_SRC_GOALS_BIRTHS_ATTEND_SKILLED_PERS  : '',
        rpmvf.RP_SRC_GOALS_PREG_W_4_PLUS_ANC_VISITS    : '',
        rpmvf.RP_SRC_GOALS_HLTH_PROF_1000_POP          : '',
        rpmvf.RP_SRC_GOALS_PERC_ACCESS_IMP_WATER       : '',
        rpmvf.RP_SRC_GOALS_PERC_ACCESS_IMP_SANI        : '',
        rpmvf.RP_SRC_GOALS_PERC_SEV_FOOD_INSEC         : '',
        rpmvf.RP_SRC_GOALS_PERC_URB_POP_INFORM_SET     : '',
        rpmvf.RP_SRC_GOALS_PERC_POP_ACCESS_ELEC        : '',
        rpmvf.RP_SRC_GOALS_PERC_ACCESS_CLEAN_COOK_TECH : '',
        rpmvf.RP_SRC_GOALS_UNEMPLOYMENT_RATE           : '',
        rpmvf.RP_SRC_GOALS_PERC_NEET_ALL               : '',
        rpmvf.RP_SRC_GOALS_PERC_NEET_MALES             : '',
        rpmvf.RP_SRC_GOALS_PERC_NEET_FEMALES           : '',
    }

def RP_init_res_summary_rec():
    summary_rec = {
        rpmvf.RP_RES_SUM_CUMU_COSTS : {
            rpmvf.RP_RES_SUM_DIRECT   : 0.00,
            rpmvf.RP_RES_SUM_INDIRECT : 0.00,
        },

        rpmvf.RP_RES_SUM_CUMU_SAVINGS : {
            rpmvf.RP_RES_SUM_EDU_SECT_PRIM                    : 0.00,
            rpmvf.RP_RES_SUM_EDU_SECT_SEC                     : 0.00,
            rpmvf.RP_RES_SUM_HLTH_SECT_SKILLED_DELIV          : 0.00,
            rpmvf.RP_RES_SUM_HLTH_SECT_ANC                    : 0.00,
            rpmvf.RP_RES_SUM_WASH_SECT_IMPR_WATER             : 0.00,
            rpmvf.RP_RES_SUM_WASH_SECT_IMPR_SANI              : 0.00,
            rpmvf.RP_RES_SUM_FOOD_SEC_SECT_RED_FOOD_INSEC     : 0.00,
            rpmvf.RP_RES_SUM_URB_SECT_REDUCE_INFORM_SETT      : 0.00,
            rpmvf.RP_RES_SUM_ENERGY_SECT_INCR_ACC_ELEC        : 0.00,
            rpmvf.RP_RES_SUM_ENERGY_SECT_INCR_ACC_CLEAN_COOK  : 0.00,
        },

        rpmvf.RP_RES_SUM_SAVINGS_PER_DOLLAR_INVEST : 0.00,
    }

    return summary_rec