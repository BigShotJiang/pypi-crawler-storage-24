from SpectrumCommon.Modvars.DP.DPModvarShapes import DP_modvar_shapes
from SpectrumCommon.Modvars.AM.AMModvarShapes import AM_modvar_shapes
from SpectrumCommon.Modvars.FP.FPModvarShapes import FP_modvar_shapes
from SpectrumCommon.Modvars.TB.TBModvarShapes import TB_modvar_shapes
from SpectrumCommon.Modvars.IH.IHModvarShapes import IH_modvar_shapes

spectrum_modvar_shapes = {
    'demproj':DP_modvar_shapes,
    'aim':AM_modvar_shapes,
    'famplan':FP_modvar_shapes,
    'tuberculosis':TB_modvar_shapes,
    'iht':IH_modvar_shapes
}