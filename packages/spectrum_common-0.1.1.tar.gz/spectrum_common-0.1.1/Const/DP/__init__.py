from .DPConst import *
from .DPTags import *
from .DPPJNZTags import *