# Fields used in HW data structures

HW_F_STAFF_TYPE_ID    = 'staffTypeID' 
HW_F_ATTR_TYPE_ID     = 'attrTypeID'
HW_F_RETENT_INCENT_ID = 'retentIncentID'

# staff records 

HW_STAFF_ID                               = HW_F_STAFF_TYPE_ID               # string;  numeric mstID for defaults. GUID for customs.
HW_STAFF_STR_CONSTANT                     = 'stringConstant'                 # string;  Defaults only.
HW_STAFF_NAME                             = 'name'                           # string;  Holds custom name or overridden default name.
HW_STAFF_ACTIVE                           = 'active'                         # boolean; Is user using this item or not?
HW_STAFF_DIVISION_MST_ID                  = 'staffDivisionMstID'             # integer;
HW_STAFF_CUSTOM                           = 'custom'                         # boolean; user-entered = true; default = false
HW_STAFF_STATIC_MAP_MST_ID                = 'defStaffTypeMapMstID'           # string;  mstID of staff type user maps custom staff types to
# baseline - staff baseline
HW_STAFF_BASE_YEAR                        = 'numInBaseYear'                  # 1d list of integer; by staff level
# baseline - salaries and benefits
HW_STAFF_ANNUAL_SALARY                    = 'annualSalary'                   # float
HW_STAFF_ANNUAL_REAL_SALARY_INCR          = 'annualRealSalaryIncrease'       # float
HW_STAFF_ANNUAL_BENEFITS                  = 'annualBenefits'                 # float
HW_STAFF_ANNUAL_BENEFITS_ADJUST           = 'annualBenefitsAdjustment'       # integer
# baseline - staff time utilization
HW_STAFF_PERC_TIME_SPENT_NOT_TRAIN_SERV   = 'percTimeSpentNotTrainServ'      # integer
HW_STAFF_AVG_DAYS_WORKED_PER_YEAR         = 'avgDaysWorkedPerYear'           # integer
HW_STAFF_HOURS_IN_WORK_DAY                = 'hoursInWorkDay'                 # integer
# baseline - attrition
HW_STAFF_CURR_ATTRIT_PER_YEAR             = 'currAttritPerYear'              # 1d list of integer; by attrition type
# baseline - retention incentives 
HW_STAFF_PERC_REC_ATTRIT_REDUC_INCENTS    = 'percReceivAttritReducIncents'   # 1d list of integer; by retention incentive
HW_STAFF_ANNUAL_COST_ATTRIT_REDUC_INCENTS = 'annCostAttrReducIncents'        # 1d list of double; by retention incentive
# baseline - pre-service training (when not disaggregated by training instution)
HW_STAFF_PRESERV_NUM_SCHOOLS              = 'preservNumSchools'              # integer
HW_STAFF_PRESERV_YEARS_TRAINING           = 'preservYearsTraining'           # integer
HW_STAFF_PRESERV_ANNUAL_COST_PER_STUDENT  = 'preservAnnCostPerStudent'       # float
HW_STAFF_PRESERV_CURR_ENROLLMENT          = 'preservCurrEnrollment'          # integer
HW_STAFF_PRESERV_GRADS_MOST_RECENT_YEAR   = 'gradsMostRecentYear'            # integer
# baseline - pre-service training (when disaggregated by training instution)
HW_STAFF_PRESERV_INST_NAMES                          = 'trainingInstNames'                 # 1d list of string; by training institution 
HW_STAFF_PRESERV_AVG_YEARS_TRAINING_BY_INST          = 'avgYearsTrainingByInst'             # 1d list of integer; by training institution
HW_STAFF_PRESERV_ANNUAL_AVG_COST_PER_STUDENT_BY_INST = 'annualAvgCostPerStudentByInst'      # 1d list of double; by training institution
HW_STAFF_PRESERV_CURR_INTAKE_BY_INST                 = 'currIntakeFirstYearStudentsByInst'  # 1d list of integer; by training institution
HW_STAFF_PRESERV_GRADS_MOST_RECENT_YEAR_BY_INST      = 'gradsMostRecentYearByInst'          # 1d list of integer; by training institution
# baseline - recruitment baseline
HW_STAFF_TOTAL_ANNUAL_RECRUITMENT                    = 'totalAnnualRecruitment'         # integer
HW_STAFF_PERC_NEW_GRADS_PUBLIC_SECTOR                = 'percNewGradsPublicSector'       # float
# baseline - in-service training
HW_STAFF_INSERV_TRAIN_COST_PERC_SALARY               = 'inservTrainCostAsPercSalary'    # float
# target setting - configuration
HW_STAFF_TARGET_SETTING_METHOD                       = 'targetSettingMethod'            # 1d list of integer; by staffing level 
# target setting - target entry and scale-up
HW_STAFF_TARGET_STAFF_POP_RATIO                      = 'targetStaffPopRatio'            # 1d list of float; by staff level
HW_STAFF_TARGET_STAFF_PER_FACILITY                   = 'targetNumPerFacility'           # 2d list of integer; staff level x facility type
HW_STAFF_TARGET_SCALE_UP_EXISTING_PLANS              = 'targetScaleUpExistingPlans'     # 2d list of integer; staff level x year
# target setting - target enrollment
HW_STAFF_TARGET_ENROLLMENT                           = 'targetEnrollment'               # 1d list of integer; by year
# target setting - target graduation
HW_STAFF_TARGET_GRADUATION                           = 'targetGraduation'               # 1d list of integer; by year
# target setting - retention incentives
HW_STAFF_TARGET_RETENT_INCENT_LEVELS                 = 'targetRetentIncentLevels'       # 2d list of integer; retention incentive x year 
# baseNumStaffTypeCountryPrivSect     # integer
# totAnnIntake                        # integer
# attrToReachStaffTargYrAchieved      # integer
# recrToReachStaffTargYrAchieved      # integer
# hirNewGradsTargYrAchieved           # integer
# hirExperStaffTargYrAchieved         # integer
# generalIncrTrainCapacTargYrAchieved # integer
# newGradsPubSectTargYrAchieved       # integer
# dropOutRateByInst                   # 1d list of float; by training institution
# incrTrainCapacInstTargYrAchieved    # 1d list of integer; by training institution
# incrTrainCapacInstTarg              # 1d list of integer; by training institution
# totAnnIntakeByInst                  # 1d list of integer; by training institution
# targTrainCapacity                   # 1d list of integer; by year
# targPubSectRecruit                  # 1d list of integer; by year
# attrToReachStaffTarg                # 1d list of integer; by year
# recrToReachStaffTarg                # 1d list of integer; by year
# hirNewGradsTarg                     # 1d list of integer; by year
# hirExperStaffTarg                   # 1d list of integer; by year
# generalIncrTrainCapacTarg           # 1d list of integer; by year
# newGradsPubSectTarg                 # 1d list of float; by year
# baseStaffReceivGradIncents          # 1d list of integer; by graduation incentive
# annCostMatricIncents                # 1d list of float; by graduation incentive
# baseStaffReceivTransfIncents        # 1d list of integer; by recruitment incentive
# costHirExpStaffIncents              # 1d list of float; by recruitment incentive
# measTargRedAttrPolData              # 2d list of integer; policy scenario x retention incentive
# measIncMatPubSectPolData            # 2d list of integer; policy scenario x graduation incentive
# measIncHirExpStaffPolData           # 2d list of integer; policy scenario x recruitment incentive
# attrReducIncentTarg                 # 2d list of integer; retention incentive x year
# attrReducIncentTargYrAchieved       # 1d list of integer; by retention incentive


# in-service training type records (new)

HW_INSERV_TRAIN_STAFF_TYPE_TO_TRAIN    = 'staffTypeToBeTrainedID' # string; numermic mstID for defaults (still cast as string). GUID for custom interventions.
HW_INSERV_TRAIN_NAME                   = 'name'                   # string
HW_INSERV_TRAIN_COST_PER_STAFF_TRAINED = 'costPerStaffTrained'    # float
HW_INSERV_TRAIN_NUM_STAFF_TO_TRAIN     = 'numStaffToBeTrained'    # 1d list of integer; by year

# attrition type records

HW_ATTRIT_TYPE_ID   = HW_F_ATTR_TYPE_ID   # string; GUID
HW_ATTRIT_TYPE_NAME = 'name'              # string

# retention incentive records

HW_RETENT_INCENT_ID                = HW_F_RETENT_INCENT_ID      # string; GUID
HW_RETENT_INCENT_NAME              = 'name'                     # string
HW_RETENT_INCENT_PERC_REDUC_ATTRIT = 'percReductionAttrition'   # 1d list of integer; by attrition type