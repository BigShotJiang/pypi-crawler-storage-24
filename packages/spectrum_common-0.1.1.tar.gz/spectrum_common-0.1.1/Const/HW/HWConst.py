from SpectrumCommon.Const.GB import *

HW_STAFF_LEVEL_FACILITY_CURR_ID = 1
HW_STAFF_LEVEL_DISTRICT_CURR_ID = 2
HW_STAFF_LEVEL_REGIONAL_CURR_ID = 3
HW_STAFF_LEVEL_NATIONAL_CURR_ID = 4
HW_NUM_STAFFING_LEVELS  = HW_STAFF_LEVEL_NATIONAL_CURR_ID

HW_STAFF_LEVEL_FACILITY_MST_ID = 1
HW_STAFF_LEVEL_DISTRICT_MST_ID = 2
HW_STAFF_LEVEL_REGIONAL_MST_ID = 3
HW_STAFF_LEVEL_NATIONAL_MST_ID = 4

HW_STAFF_LEVEL_MAP = {
    HW_STAFF_LEVEL_FACILITY_MST_ID : HW_STAFF_LEVEL_FACILITY_CURR_ID,
    HW_STAFF_LEVEL_DISTRICT_MST_ID : HW_STAFF_LEVEL_DISTRICT_CURR_ID,
    HW_STAFF_LEVEL_REGIONAL_MST_ID : HW_STAFF_LEVEL_REGIONAL_CURR_ID,
    HW_STAFF_LEVEL_NATIONAL_MST_ID : HW_STAFF_LEVEL_NATIONAL_CURR_ID,
}

HW_STAFF_LEVELS_MST_IDS = [HW_STAFF_LEVEL_FACILITY_MST_ID, HW_STAFF_LEVEL_DISTRICT_MST_ID, HW_STAFF_LEVEL_REGIONAL_MST_ID, HW_STAFF_LEVEL_NATIONAL_MST_ID]

# These work a bit differently than the standard user-entered items. Instead of adding and deleting like normal,
# there are a set number of rows and the user just enters the names on the rows. Not sure why.
HW_NUM_INSERV_TRAIN_TYPES         = 12
HW_NUM_PRESERV_TRAIN_INSTITUTIONS = 12

# Staffing methods

HW_POP_NORMS_CURR_ID           = 1
HW_FAC_STAFF_STANDARDS_CURR_ID = 2
HW_EXISTING_PLANS_CURR_ID      = 3
HW_NO_STAFF_CURR_ID            = 4
HW_NUM_STAFFING_METHODS        = 4

HW_POP_NORMS_MST_ID           = 1
HW_FAC_STAFF_STANDARDS_MST_ID = 2
HW_EXISTING_PLANS_MST_ID      = 3
HW_NO_STAFF_MST_ID            = 4

# Default ISCO medical staff types (health service providers).
# OLD -- needs to be updated if we use these anywhere.
# HR_GEN_PRIM_CARE_DOC_CURR_ID               = 1
# UH_FirstDefStaffType                       = HR_GEN_PRIM_CARE_DOC_CURR_ID
# HR_OB_GYNS_CURR_ID                         = 2
# HR_PEDIATRICIANS_CURR_ID                   = 3
# HR_OTHER_SPECIALISTS_CURR_ID               = 4
# HR_CLINIC_OFF_SURG_TECHS_CURR_ID           = 5
# HR_NURSES_CURR_ID                          = 6
# HR_MIDWIVES_CURR_ID                        = 7
# HR_ASSIST_NURSES_MIDWIVES_CURR_ID          = 8
# HR_NURSING_AIDES_CURR_ID                   = 9
# HR_LAB_TECHS_ASSIST_CURR_ID                = 10
# HR_PHARM_TECHS_ASSIST_CURR_ID              = 11
# HR_RADIO_XRAY_TECHS_CURR_ID                = 12
# HR_EMERG_MED_TECHS_CURR_ID                 = 13
# HR_COMM_HLTH_WORKERS_CURR_ID               = 14
# # Final defined default ISCO staff type. Staff types after this are placeholders.
# # for other types of staff.
# HR_NUM_DEF_ISCO_MED_STAFF_TYPES            = HR_COMM_HLTH_WORKERS_CURR_ID
# HR_OTHER_STAFF_TYPE_CURR_ID                = 15 # not necessarily a health service provider
# HR_NUM_DEF_ISCO_MED_STAFF_TYPES_PLUS_OTHER = HR_OTHER_STAFF_TYPE_CURR_ID
# HR_ADD_TO_TREAT_INPUTS_CURR_ID             = 16 # occasionally tacked on to ISCO default list to use custom staff in Intervention Costing

HW_GENERAL_MEDICAL_PRACTITIONERS_MST_ID           = 1
HW_OB_GYNS_MST_ID                                 = 2 # defunct
HW_PEDIATRICIANS_MST_ID                           = 3 # defunct
HW_SPECIAL_MEDICAL_PRACTITIONERS_MST_ID           = 4
HW_CLINIC_OFF_SURG_TECHS_MST_ID                   = 5
HW_NURSING_PROFESSIONALS_MST_ID                   = 6
HW_MIDWIFERY_PROFESSIONALS_MST_ID                 = 7
HW_MIDWIFERY_ASSOCIATE_PROFESSIONALS_MST_ID       = 8
HW_NURSING_ASSOCIATE_PROFESSIONALS_MST_ID         = 9
HW_MED_PATH_LAB_TECHS_MST_ID                      = 10
HW_PHARM_TECHS_ASSIST_MST_ID                      = 11
HW_MED_IMAGING_THERA_EQUIP_TECHS_MST_ID           = 12
HW_AMBULANCE_WORKERS_MST_ID                       = 13
HW_COMM_HLTH_WORKERS_MST_ID                       = 14
HW_OTHER_STAFF_TYPE_MST_ID                        = 15
HW_ADD_TO_TREAT_INPUTS_MST_ID                     = 16 # Special - not really a staff type
HW_DENTISTS_MST_ID                                = 25
HW_DENTAL_ASSIST_THERAPISTS_MST_ID                = 26
HW_MED_DENTAL_PROSTHETIC_REL_TECHS_MST_ID         = 27
HW_PHARMACISTS_MST_ID                             = 28
HW_PARAMED_PRACTITIONERS_MST_ID                   = 29
HW_ENVIRON_OCCUPAT_HEALTH_HYGIENE_PROF_MST_ID     = 30
HW_DIETICIANS_NUTRITIONISTS_MST_ID                = 31
HW_AUDIOLOGISTS_SPEECH_THERAPISTS_MST_ID          = 32
HW_OPTOMETRISTS_OPHTHALMIC_OPTICIANS_MST_ID       = 33
HW_DISPENSING_OPTICIANS_MST_ID                    = 34
HW_ENVIRON_OCCUPAT_HEALTH_INSPEC_ASSO_MST_ID      = 35
HW_TRAD_COMP_MED_PROF_MST_ID                      = 36
HW_TRAD_COMP_MED_ASSOC_PROF_MST_ID                = 37
HW_HEALTH_CARE_ASSISTS_MST_ID                     = 38
HW_HOME_BASED_PERS_CARE_WORKERS_MST_ID            = 39
HW_PERS_CARE_WORKERS_HEALTH_SERV_NOT_CLASS_MST_ID = 40
HW_PHYSIOTHERAPISTS_MST_ID                        = 41
HW_PHYSIOTHERAPY_TECHS_ASSISTS_MST_ID             = 42
HW_HEALTH_ASSOC_PROF_NOT_CLASS_MST_ID             = 43
HW_PSYCHOLOGISTS_MST_ID                           = 44
HW_SOCIAL_WORK_COUNSELLING_PROF_MST_ID            = 45
HW_SOCIAL_WORK_ASSOC_PROF_MST_ID                  = 46

HW_GENERAL_MEDICAL_PRACTITIONERS_CURR_ID           = 1
HW_SPECIAL_MEDICAL_PRACTITIONERS_CURR_ID           = 2
HW_CLINIC_OFF_SURG_TECHS_CURR_ID                   = 3
HW_NURSING_PROFESSIONALS_CURR_ID                   = 4
HW_MIDWIFERY_PROFESSIONALS_CURR_ID                 = 5
HW_MIDWIFERY_ASSOCIATE_PROFESSIONALS_CURR_ID       = 6
HW_NURSING_ASSOCIATE_PROFESSIONALS_CURR_ID         = 7
HW_MED_PATH_LAB_TECHS_CURR_ID                      = 8
HW_PHARM_TECHS_ASSIST_CURR_ID                      = 9
HW_MED_IMAGING_THERA_EQUIP_TECHS_CURR_ID           = 10
HW_AMBULANCE_WORKERS_CURR_ID                       = 11
HW_COMM_HLTH_WORKERS_CURR_ID                       = 12
HW_OTHER_STAFF_TYPE_CURR_ID                        = 13
HW_DENTISTS_CURR_ID                                = 14
HW_DENTAL_ASSIST_THERAPISTS_CURR_ID                = 15
HW_MED_DENTAL_PROSTHETIC_REL_TECHS_CURR_ID         = 16
HW_PHARMACISTS_CURR_ID                             = 17
HW_PARAMED_PRACTITIONERS_CURR_ID                   = 18
HW_ENVIRON_OCCUPAT_HEALTH_HYGIENE_PROF_CURR_ID     = 19
HW_DIETICIANS_NUTRITIONISTS_CURR_ID                = 20
HW_AUDIOLOGISTS_SPEECH_THERAPISTS_CURR_ID          = 21
HW_OPTOMETRISTS_OPHTHALMIC_OPTICIANS_CURR_ID       = 22
HW_DISPENSING_OPTICIANS_CURR_ID                    = 23
HW_ENVIRON_OCCUPAT_HEALTH_INSPEC_ASSO_CURR_IDC     = 24
HW_TRAD_COMP_MED_PROF_CURR_ID                      = 25
HW_TRAD_COMP_MED_ASSOC_PROF_CURR_ID                = 26
HW_HEALTH_CARE_ASSISTS_CURR_ID                     = 27
HW_HOME_BASED_PERS_CARE_WORKERS_CURR_ID            = 28
HW_PERS_CARE_WORKERS_HEALTH_SERV_NOT_CLASS_CURR_ID = 29
HW_PHYSIOTHERAPISTS_CURR_ID                        = 30
HW_PHYSIOTHERAPY_TECHS_ASSISTS_CURR_ID             = 31
HW_HEALTH_ASSOC_PROF_NOT_CLASS_CURR_ID             = 32
HW_PSYCHOLOGISTS_CURR_ID                           = 33
HW_SOCIAL_WORK_COUNSELLING_PROF_CURR_ID            = 34
HW_SOCIAL_WORK_ASSOC_PROF_CURR_ID                  = 35
HW_NUM_STATIC_STAFF_TYPES                          = HW_SOCIAL_WORK_ASSOC_PROF_CURR_ID

# Use this to refer to all default and custom staff combined.
UH_AllDefaultAndCustomStaff = 10000

# Default health management and support (HMS) personnel.
# OLD -- needs to be updated if we use these anywhere.
# HR_HLTH_SERV_MANAGERS_CURR_ID        = 1
# HR_FirstDefHMSStaffType_CURR_ID      = HR_HLTH_SERV_MANAGERS_CURR_ID
# HR_HLTH_MGMT_PERSONNEL_CURR_ID       = 2
# HR_NON_HLTH_PROFESSIONALS_CURR_ID    = 3
# HR_MED_SECRETARIES_CURR_ID           = 4
# HR_NON_HLTH_TECHS_ASSOC_PROF_CURR_ID = 5
# HR_CLERICAL_SUPP_WORKERS_CURR_ID     = 6
# HR_PLANT_MACH_OPER_ASSEMB_CURR_ID    = 7
# HR_ELEMENTARY_OCCUPATIONS_CURR_ID    = 8
# HR_NUM_DEF_HMS_STAFF_TYPES           = HR_ELEMENTARY_OCCUPATIONS_CURR_ID

# These are added to the same staff list as the medical staff, so make it so their master IDs don't overlap.
HW_HLTH_SERV_MANAGERS_MST_ID                  = 17
HW_HLTH_PROF_NOT_ELSEWHERE_CLASSIFIED_MST_ID  = 18
HW_NON_HLTH_PROFESSIONALS_MST_ID              = 19
HW_MED_SECRETARIES_MST_ID                     = 20
HW_NON_HLTH_TECHS_ASSOC_PROF_MST_ID           = 21
HW_CLERICAL_SUPP_WORKERS_MST_ID               = 22
HW_PLANT_MACH_OPER_ASSEMB_MST_ID              = 23
HW_ELEMENTARY_OCCUPATIONS_MST_ID              = 24
HW_MED_REC_HEALTH_INFO_TECHS_MST_ID           = 47
HW_BIOMED_ENGINEER_MST_ID                     = 48
HW_AGED_CARE_SERVICE_MANAGERS_MST_ID          = 49

# Maximum number of staff types the user can enter.
HW_MAX_STAFF_TYPES = 500

# Constants for which staff division a staff type goes under.
HW_HLTH_SERV_PROVIDER_CURR_ID  = 1
HW_HLTH_MGMT_SUPP_PERS_CURR_ID = 2
HW_NUM_STAFF_DIVISIONS         = HW_HLTH_MGMT_SUPP_PERS_CURR_ID

HW_HLTH_SERV_PROVIDER_MST_ID  = 1
HW_HLTH_MGMT_SUPP_PERS_MST_ID = 2

# Compensation types
HW_SALARIES_CURR_ID   = 1
HW_BENEFITS_CURR_ID   = 2
HW_INCENTIVES_CURR_ID = 3
HW_NUM_COMPENS_TYPES  = HW_INCENTIVES_CURR_ID

HW_SALARIES_MST_ID   = 1
HW_BENEFITS_MST_ID   = 2
HW_INCENTIVES_MST_ID = 3

HW_COMPENS_TYPE_MAP = {
    HW_SALARIES_MST_ID   : HW_SALARIES_CURR_ID,
    HW_BENEFITS_MST_ID   : HW_BENEFITS_CURR_ID,
    HW_INCENTIVES_MST_ID : HW_INCENTIVES_CURR_ID,
}

HW_COMPENS_TYPE_MST_IDS = [HW_SALARIES_MST_ID, HW_BENEFITS_MST_ID, HW_INCENTIVES_MST_ID]

HW_POP_FACTOR = 10000

# Database latest versions
HW_STAFF_SALARIES_DB_CURR_VERSION = 'V1'

# Database names (also the names of the sheets in HWModData.xlsx)
HW_STAFF_SALARIES_DB_NAME = 'StaffSalariesDB'

# Database directories for data by country. Files in these folders are named using the 3 letter iso country codes instead of the database names above.
HW_STAFF_SALARIES_DB_DIR = r'StaffSalaries\countries'
