#######################################################################################################
#                                                                                                     #
#                                       Staff Salaries DB (SSDB)                                      #
#                                                                                                     #
#######################################################################################################

HW_ISO_ALPHA_3_COUNTRY_CODE_KEY_SSDB = 'ISO3AlphaCountryCode'
HW_INTERVENTION_LIST_KEY_SSDB        = 'interventions'

HW_INTERV_MST_ID_KEY_SSDB     = 'intervMstID'
HW_EDU_CODE_1_SALARY_KEY_SSDB = 'eduCode1Salary'
HW_EDU_CODE_2_SALARY_KEY_SSDB = 'eduCode2Salary'
HW_EDU_CODE_3_SALARY_KEY_SSDB = 'eduCode3Salary'
HW_EDU_CODE_4_SALARY_KEY_SSDB = 'eduCode4Salary'
HW_EDU_CODE_5_SALARY_KEY_SSDB = 'eduCode5Salary'