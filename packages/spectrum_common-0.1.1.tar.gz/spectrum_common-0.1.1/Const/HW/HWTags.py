# Input ModVars

HW_VERSION_TAG_V1                                = '<HR_Version_V1>'
HW_DATA_CHANGED_TAG_V1                           = '<HR_DataChanged_V1>'
HW_PROJ_VALID_TAG_V1                             = '<HR_ProjectionValid_V1>'
HW_FILE_NAME_TAG_V1                              = '<HR_FileName_V1>'                        
HW_PROJ_VALID_DATE_TAG_V1                        = '<HR_ProjectionValidDate_V1>'   
HW_COST_INSERV_TRAIN_BY_PERC_SALARY_TAG_V1       = '<HR_CostInservTrainByPercSalary_V1>'
HW_SHOW_PRESERV_TRAIN_BY_INSTITUTION_TAG_V1      = '<HR_ShowPreservTrainByInstitution_V1>'
# no longer used?  HR_SHOW_ALL_YEARS_SCALE_UP_POL_ANA_TAG_V1   = '<HR_ShowAllYearsScaleUpPolAna_V1>'
HW_TARG_ENROLLMENT_VISITED_TAG_V1                = '<HR_TargEnrollmentVisited_V1>'                  
HW_TARG_GRADUATION_VISITED_TAG_V1                = '<HR_TargGraduationVisited_V1>'      
HW_STAFF_TYPE_RECORDS_TAG_V1                     = '<HR_StaffRecords_V1>'             
HW_INSERV_TRAIN_TYPE_RECORDS_TAG_V1              = '<HR_InserviceTrainingTypeRecords_V1>'
    #HR_INSERV_TRAIN_STAFF_MAP_TAG_V1              = '<HR_InservTrainStaffMap_V1>'    
    #HR_trainTypeNames            
    #HR_costPerStaffTrained 
    #HR_numStaffToBeTrained   
# no longer used? HR_INCOME_ELASTICITY_TAG_V1                = '<HR_IncomeElasticity_V1>'
# no longer used? HR_ECONOMIC_GROWTH_TAG_V1                  = '<HR_EconomicGrowth_V1>'   
# no longer used? HR_INCR_PUBLIC_SECTOR_MATRIC_INCENT_TAG_V1 = '<HR_IncrPublicSectorMatricIncentives_V1>'   
# no longer used? HR_IMP_PUBLIC_SECTOR_MATRIC_INCENT_TAG_V1  = '<HR_ImpPublicSectorMatricIncentives_V1>'
HW_TARG_SCALE_UP_VISITED_TAG_V1                  = '<HR_TargetScaleUpVisited_V1>'  
HW_TARG_RETENT_INCENT_LEVELS_VISITED_TAG_V1      = '<HR_TargetRetentIncentLevelsVisited_V1>'        
HW_ATTRITION_TYPE_RECORDS_TAG_V1                 = '<HR_AttritionTypeRecords_V1>'
HW_RETENTION_INCENTIVE_RECORDS_TAG_V1            = '<HR_RetentionIncentiveRecords_V1>'
HW_RECRUITMENT_INCENTIVE_RECORDS_TAG_V1          = '<HR_RecruitmentIncentiveRecords_V1>'
# no longer used? HR_PRIVATE_SECTOR_HRH_TAG_V1            = '<HR_PrivateSectorHRH_V1>'
HW_PRESERV_ENROLLMENT_TAG_V1                     = '<HR_PreservEnrollment_V1>'
HW_PROJECTED_GRADUATION_TAG_V1                   = '<HR_ProjectedGraduation_V1>'                    
HW_TOTAL_INSERV_TRAIN_COSTS_BY_TRAIN_TYPE_TAG_V1 = '<HR_TotalInservTrainCostsByTrainType_V1>'
HW_CURR_GRAD_PERC_CURR_ENROLL_TAG_V1             = '<HR_CurrGraduationAsPercCurrEnrollment_V1>'
HW_ATTRITION_RATE_TAG_V1                         = '<HR_AttritionRate_V1>'
HW_COST_PRESERV_TRAIN_TAG_V1                     = '<HR_CostPreservTrain_V1>'  
HW_TOTAL_INSERV_TRAIN_COSTS_BY_STAFF_TAG_V1      = '<HR_TotalInservTrainCostsByStaffType_V1>'     
HW_STAFF_NEEDING_TO_BE_HIRED_TAG_V1              = '<HR_StaffNeedingToBeHired_V1>'
HW_TOTAL_STAFF_TAG_V1                            = '<HR_TotalStaff_V1>'               
HW_TOTAL_COMPENSATION_TAG_V1                     = '<HR_TotalCompensation_V1>'
HW_PROG_MGMT_DATA_TAG_V1                         = '<HR_ProgMgmtData_V1>'

# Output / Result ModVars

HW_RES_TOTAL_STAFF_TAG_V1                        = '<HR_ResTotalStaff_V1>'
HW_RES_STAFF_PER_10K_POP_TAG_V1                  = '<HR_ResStaffPer10KPop_V1>'
HW_RES_TOTAL_COMPENSATION_TAG_V1                 = '<HR_ResTotalCompensation_V1>'
HW_RES_STAFF_NEEDING_TO_BE_HIRED_TAG_V1          = '<HR_ResStaffNeedingToBeHired_V1>'
HW_RES_ATTRITION_RATE_TAG_V1                     = '<HR_ResAttritionRate_V1>'
HW_RES_INSERV_TRAIN_COSTS_BY_STAFF_TAG_V1        = '<HR_ResInservTrainCostsByStaff_V1>'
HW_RES_INSERV_TRAIN_COSTS_BY_TRAIN_TYPE_TAG_V1   = '<HR_ResInservTrainCostsByTrainType_V1>'
HW_RES_PRESERV_TRAIN_COSTS_TAG_V1                = '<HR_ResPreservTrainCosts_V1>'

# Meta ModVars. The values inside these do not change. 

HW_STATIC_STAFF_LIST_META_TAG_V1 = '<HR_DefaultStaffList_Meta_V1>'
