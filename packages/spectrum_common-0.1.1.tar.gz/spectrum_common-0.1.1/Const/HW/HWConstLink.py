from SpectrumCommon.Const.DP.DPConst import *

from SpectrumCommon.Const.IS.ISTags import *

#############################    IS    ##########################

HW_IS_FACILITY_RECORDS_TAG_V1          = IS_FACILITY_TYPE_RECORDS_TAG   
HW_IS_RES_TOTAL_NUM_FACIL_AVAIL_TAG_V1 = IS_RES_TOTAL_NUM_FAC_AVAIL_TAG   

#######################################################################################################
#                                                                                                     #
#                                      DP                                                             #
#                                                                                                     #
#######################################################################################################

HW_DP_ALL_AGES     = DP_AllAges