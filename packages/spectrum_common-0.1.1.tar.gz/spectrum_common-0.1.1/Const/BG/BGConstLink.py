from SpectrumCommon.Const.IH.IHConst import *
from SpectrumCommon.Const.IH.IHTags import *
from SpectrumCommon.Const.IH.IHModVarFields import *

from SpectrumCommon.Const.IC.ICModVarFields import *
from SpectrumCommon.Const.IC.ICTags import *
from SpectrumCommon.Const.IC.ICInterventionIDs import *
from SpectrumCommon.Const.IC.IC_TI_InterventionIDs import *

from SpectrumCommon.Const.PC.PCModVarFields import *
from SpectrumCommon.Const.PC.PCTags import *

from SpectrumCommon.Const.IS.ISTags import *
from SpectrumCommon.Const.IS.ISModVarFields import *

from SpectrumCommon.Const.HW.HWTags import *
from SpectrumCommon.Const.HW.HWConst import *
from SpectrumCommon.Const.HW.HWModVarFields import *

#######################################################################################################
#                                                                                                     #
#                                      IH                                                             #
#                                                                                                     #
#######################################################################################################

BG_IH_DELIV_CHAN_RECORDS_TAG            = IH_DELIV_CHAN_RECORDS_TAG_V1
BG_IH_PROG_AREA_RECORDS_TAG             = IH_PROG_AREA_RECORDS_TAG_V1
BG_IH_COMMUNITY_CHAN_MST_ID             = IH_COMMUNITY_CHAN_MST_ID
BG_IH_SPECIFIC_PLAN                     = IH_SPECIFIC_PLAN
BG_IH_MODULE_MST_ID                     = IH_MODULE_MST_ID      
BG_IH_PROG_AREA_MST_ID                  = IH_PROG_AREA_MST_ID 
BG_IH_F_PROG_AREA_ID                    = IH_F_PROG_AREA_ID
BG_IH_HEALTH_SYS_MST_ID                 = IH_HEALTH_SYS_MST_ID
BG_IH_HEALTH_WORKFORCE_HSPM_MST_ID      = IH_HEALTH_WORKFORCE_HSPM_MST_ID
BG_IH_INFRASTRUCTURE_HSPM_MST_ID        = IH_INFRASTRUCTURE_HSPM_MST_ID
BG_IH_LOGISTICS_HSPM_MST_ID             = IH_LOGISTICS_HSPM_MST_ID
BG_IH_HEALTH_INFORM_SYSTEMS_HSPM_MST_ID = IH_HEALTH_INFORM_SYSTEMS_HSPM_MST_ID
BG_IH_PPLI_MST_ID                       = IH_PPLI_MST_ID
BG_IH_SOCIAL_ENABLERS_MST_ID            = IH_SOCIAL_ENABLERS_MST_ID
BG_IH_NCD_MST_ID                        = IH_NCD_MST_ID
BG_IH_HIV_AIDS_MST_ID                   = IH_HIV_AIDS_MST_ID

#######################################################################################################
#                                                                                                     #
#                                      IC                                                             #
#                                                                                                     #
#######################################################################################################

BG_IC_INTERV_RECORDS_TAG                       = IC_INTERV_RECORDS_TAG 
BG_IC_DRUG_SUPPLY_RECORDS_TAG                  = IC_DRUG_SUPPLY_RECORDS_TAG
BG_IC_RES_DRUGS_REQUIRED_TAG                   = IC_RES_DRUGS_REQUIRED_BY_DELIV_CHAN_TAG
BG_IC_RES_SUPPLIES_REQUIRED_TAG                = IC_RES_SUPPLIES_REQUIRED_BY_DELIV_CHAN_TAG
BG_IC_RES_DRUG_COSTS_TAG                       = IC_RES_DRUG_COSTS_TAG_V1
BG_IC_RES_SUPPLY_COSTS_TAG                     = IC_RES_SUPPLY_COSTS_TAG_V1
BG_IC_RES_LABOR_COSTS_DSC_TAG                  = IC_RES_LABOR_COSTS_DSC_TAG_V1
BG_IC_RES_OUTPAT_VISIT_INPAT_DAY_COSTS_DSC_TAG = IC_RES_OUTPAT_VISIT_INPAT_DAY_COSTS_DSC_TAG_V1
BG_IC_RES_LOG_SUPPLY_CHAIN_COSTS_TB_TAG        = IC_RES_LOG_SUPPLY_CHAIN_COSTS_TB_TAG
BG_IC_RES_WASTAGE_COSTS_TB_TAG                 = IC_RES_WASTAGE_COSTS_TB_TAG

BG_IC_F_DELIV_CHAN_ID              = IC_F_DELIV_CHAN_ID

#######################################################################################################
#                                                                                                     #
#                                      PC                                                             #
#                                                                                                     #
#######################################################################################################

BG_PC_COSTING_SECT_RECORDS_TAG       = PC_COSTING_SECT_RECORDS_TAG
BG_PC_ACT_RECORDS_TAG                = PC_ACT_RECORDS_TAG
BG_PC_COSTING_SECT_RECORDS_PPLI_TAG  = PC_COSTING_SECT_RECORDS_PPLI_TAG
BG_PC_ACT_RECORDS_PPLI_TAG           = PC_ACT_RECORDS_PPLI_TAG
BG_PC_RES_COSTS_BY_SECT_TAG          = PC_RES_COSTS_BY_SECT_TAG
BG_PC_RES_COSTS_BY_SECT_PPLI_TAG     = PC_RES_COSTS_BY_SECT_PPLI_TAG
BG_PC_RES_COSTS_BY_SUBSECT_TAG       = PC_RES_COSTS_BY_SUBSECT_TAG
BG_PC_RES_COSTS_BY_SUBSECT_PPLI_TAG  = PC_RES_COSTS_BY_SUBSECT_PPLI_TAG
BG_PC_RES_COSTS_BY_ACT_TAG           = PC_RES_COSTS_BY_ACT_TAG
BG_PC_RES_COSTS_BY_ACT_PPLI_TAG      = PC_RES_COSTS_BY_ACT_PPLI_TAG

BG_PC_F_COSTING_SECT_ID           = PC_F_COSTING_SECT_ID
BG_PC_F_COSTING_SUBSECT_ID        = PC_F_COSTING_SUBSECT_ID
BG_PC_F_ACT_ID                    = PC_F_ACT_ID

#######################################################################################################
#                                                                                                     #
#                                      IS                                                             #
#                                                                                                     #
#######################################################################################################

BG_IS_FACILITY_TYPE_RECORDS_TAG                       = IS_FACILITY_TYPE_RECORDS_TAG 
BG_IS_RES_TOTAL_COST_BUILD_EQUIP_NEW_FAC_TAG          = IS_RES_TOTAL_COST_BUILD_EQUIP_NEW_FAC_TAG                                                                                 
BG_IS_RES_VEHIC_PURCH_CAP_COSTS_TAG                   = IS_RES_VEHIC_PURCH_CAP_COSTS_TAG   
BG_IS_RES_VEHIC_PURCH_CAP_COSTS_BY_FAC_TAG            = IS_RES_VEHIC_PURCH_CAP_COSTS_BY_FAC_TAG
BG_IS_RES_VEHIC_PURCH_CAP_COSTS_OTHER_NON_FAC_TAG     = IS_RES_VEHIC_PURCH_CAP_COSTS_OTHER_NON_FAC_TAG        
BG_IS_RES_VEHIC_MAINT_REPAIR_COSTS_TAG                = IS_RES_VEHIC_MAINT_REPAIR_COSTS_TAG   
BG_IS_RES_VEHIC_MAINT_REPAIR_COSTS_BY_FAC_TAG         = IS_RES_VEHIC_MAINT_REPAIR_COSTS_BY_FAC_TAG
BG_IS_RES_VEHIC_MAINT_REPAIR_COSTS_OTHER_NON_FAC_TAG  = IS_RES_VEHIC_MAINT_REPAIR_COSTS_OTHER_NON_FAC_TAG                
BG_IS_RES_VEHIC_FUEL_COSTS_TAG                        = IS_RES_VEHIC_FUEL_COSTS_TAG  
BG_IS_RES_VEHIC_FUEL_COSTS_BY_FAC_TAG                 = IS_RES_VEHIC_FUEL_COSTS_BY_FAC_TAG
BG_IS_RES_VEHIC_FUEL_COSTS_OTHER_NON_FAC_TAG          = IS_RES_VEHIC_FUEL_COSTS_OTHER_NON_FAC_TAG                                
BG_IS_RES_VEHIC_DRIVER_SALARIES_TAG                   = IS_RES_VEHIC_DRIVER_SALARIES_TAG        
BG_IS_RES_VEHIC_DRIVER_SALARIES_BY_FAC_TAG            = IS_RES_VEHIC_DRIVER_SALARIES_BY_FAC_TAG
BG_IS_RES_VEHIC_DRIVER_SALARIES_OTHER_NON_FAC_TAG     = IS_RES_VEHIC_DRIVER_SALARIES_OTHER_NON_FAC_TAG              
BG_IS_RES_NEW_FAC_FURNITURE_COSTS_TAG                 = IS_RES_NEW_FAC_FURNITURE_COSTS_TAG            
BG_IS_RES_NEW_FAC_CONSTRUCT_COSTS_TAG                 = IS_RES_NEW_FAC_CONSTRUCT_COSTS_TAG       
BG_IS_RES_NEW_FAC_MED_EQUIP_COSTS_TAG                 = IS_RES_NEW_FAC_MED_EQUIP_COSTS_TAG       
BG_IS_RES_FAC_REHAB_COSTS_TAG                         = IS_RES_FAC_REHAB_COSTS_TAG                             
BG_IS_RES_FAC_TOTAL_OP_COSTS_TAG                      = IS_RES_FAC_TOTAL_OP_COSTS_TAG  
BG_IS_RES_ICT_CAP_COSTS_BY_FAC_TAG                    = IS_RES_ICT_CAP_COSTS_BY_FAC_TAG
BG_IS_RES_ICT_CAP_COSTS_OTHER_NON_FAC_TAG             = IS_RES_ICT_CAP_COSTS_OTHER_NON_FAC_TAG
BG_IS_RES_ICT_MAINT_REPAIR_OP_COSTS_BY_FAC_TAG        = IS_RES_ICT_MAINT_REPAIR_OP_COSTS_BY_FAC_TAG
BG_IS_RES_ICT_MAINT_REPAIR_OP_COSTS_OTHER_NON_FAC_TAG = IS_RES_ICT_MAINT_REPAIR_OP_COSTS_OTHER_NON_FAC_TAG
                                                                            
BG_IS_RES_EQUIPMENT_COSTS_DSC_V1   = IS_RES_EQUIPMENT_COSTS_DSC_V1

#######################################################################################################
#                                                                                                     #
#                                      HW                                                             #
#                                                                                                     #
#######################################################################################################

BG_HW_STAFF_TYPE_RECORDS_TAG                   = HW_STAFF_TYPE_RECORDS_TAG_V1
BG_HW_INSERV_TRAIN_TYPE_RECORDS_TAG            = HW_INSERV_TRAIN_TYPE_RECORDS_TAG_V1
BG_HW_RES_TOTAL_COMPENSATION_TAG               = HW_RES_TOTAL_COMPENSATION_TAG_V1
BG_HW_RES_PRESERV_TRAIN_COSTS_TAG              = HW_RES_PRESERV_TRAIN_COSTS_TAG_V1
BG_HW_RES_INSERV_TRAIN_COSTS_BY_STAFF_TAG      = HW_RES_INSERV_TRAIN_COSTS_BY_STAFF_TAG_V1
BG_HW_RES_INSERV_TRAIN_COSTS_BY_TRAIN_TYPE_TAG = HW_RES_INSERV_TRAIN_COSTS_BY_TRAIN_TYPE_TAG_V1

BG_HW_NUM_STAFFING_LEVELS  = HW_NUM_STAFFING_LEVELS
BG_HW_STAFF_LEVELS_MST_IDS = HW_STAFF_LEVELS_MST_IDS
BG_HW_STAFF_LEVEL_MAP      = HW_STAFF_LEVEL_MAP

BG_HW_NUM_COMPENS_TYPES    = HW_NUM_COMPENS_TYPES
BG_HW_COMPENS_TYPE_MST_IDS = HW_COMPENS_TYPE_MST_IDS
BG_HW_COMPENS_TYPE_MAP     = HW_COMPENS_TYPE_MAP

BG_HW_NUM_INSERV_TRAIN_TYPES = HW_NUM_INSERV_TRAIN_TYPES