# File Version
BG_FILE_VERSION_1_0 = 1.0

# Database latest versions
BG_BUDGET_DB_CURR_VERSION            = 'V3'  
BG_BUDGET_CAT_DB_CURR_VERSION        = 'V3'
BG_INDICATOR_MAPPING_DB_CURR_VERSION = 'V2'
BG_FUND_FW_DB_CURR_VERSION           = 'V3'
BG_FUND_SOURCE_DB_CURR_VERSION       = 'V3'

BG_BUDGET_DB_NAME            = 'BudgetDB'  
BG_BUDGET_CAT_DB_NAME        = 'BudgetCategoryDB'
BG_INDICATOR_MAPPING_DB_NAME = 'IndicatorMappingDB'
BG_FUND_FW_DB_NAME           = 'FundingFrameworkDB'
BG_FUND_SOURCE_DB_NAME       = 'FundingSourceDB'

# Budget category master IDs. (cast as str)
BG_BC_DISTRIB_MULTI_CATS_MST_ID = 0
BG_BC_UNALLOCATED_MST_ID        = 1

# Funding source master IDs. (cast as str)
BG_FS_DISTRIB_MULTI_SOURCES_MST_ID = 0
BG_FS_UNALLOCATED_MST_ID           = 1

# Quick mapping targets
BG_QUICK_MAP_BUDGET_CATS_MST_ID  = 1
BG_QUICK_MAP_FUND_SOURCES_MST_ID = 2

BG_QUICK_MAP_TARGET_MST_IDS = [BG_QUICK_MAP_BUDGET_CATS_MST_ID, BG_QUICK_MAP_FUND_SOURCES_MST_ID]

#   *************************   IC indicator types   **************************

#  Note that BG_IC_DRUG_SUPPLY_IND_MST_ID and BG_IC_INTERV_IND_MST_ID are really the
#  same thing (intervention drug and supply costs), but the former is shown
#  by drug and supply and the latter is shown by intervention (as the labor
#  and visit costs are).

BG_IC_DRUG_SUPPLY_IND_MST_ID        = 1 # Drug/supply costs by drug/supply; by delivery channel; IHT, TB
BG_IC_INTERV_IND_MST_ID             = 2 # Drug/supply costs by intervention; by delivery channel; IHT, TB
BG_IC_LABOR_COSTS_IND_MST_ID        = 3 # Disease-specific costing in IHT, TB app; by delivery channel
BG_IC_VISIT_COSTS_IND_MST_ID        = 4 # Disease-specific costing in IHT, TB app; by delivery channel
BG_IC_LOG_SUPPLY_CHAIN_COSTS_MST_ID = 5 # TB app; not by delivery channel
BG_IC_WASTAGE_COSTS_MST_ID          = 6 # TB app; not by delivery channel
BG_IC_NUM_IND_TYPES                 = 6

# All possible IC indicators

BG_IC_IND_TYPE_MST_IDS = [
    BG_IC_DRUG_SUPPLY_IND_MST_ID, 
    BG_IC_INTERV_IND_MST_ID, 
    BG_IC_LABOR_COSTS_IND_MST_ID, 
    BG_IC_VISIT_COSTS_IND_MST_ID, 
    BG_IC_LOG_SUPPLY_CHAIN_COSTS_MST_ID,
    BG_IC_WASTAGE_COSTS_MST_ID,
]

# All IC indicators than can be displayed by intervention
BG_IC_INTERV_IND_SET = [
    BG_IC_INTERV_IND_MST_ID, 
    BG_IC_LABOR_COSTS_IND_MST_ID, 
    BG_IC_VISIT_COSTS_IND_MST_ID
]

# All IC indicators that can be displayed by drug/supply
BG_IC_DRUG_SUPPLY_IND_SET = [
    BG_IC_DRUG_SUPPLY_IND_MST_ID, 
    BG_IC_LOG_SUPPLY_CHAIN_COSTS_MST_ID, 
    BG_IC_WASTAGE_COSTS_MST_ID
]

# All IC indicators that vary by delivery channel
BG_IC_DELIV_CHAN_IND_SET = [
    BG_IC_DRUG_SUPPLY_IND_MST_ID, 
    BG_IC_INTERV_IND_MST_ID,  
    BG_IC_LABOR_COSTS_IND_MST_ID, 
    BG_IC_VISIT_COSTS_IND_MST_ID
]

# Drug and supply costs can be done either by drug and supply or at the intervention level 
# (only one at a time, otherwise we'd be double-counting).
BG_IC_DRUG_SUPPLY_COSTS_IND_SET = [
    BG_IC_DRUG_SUPPLY_IND_MST_ID, 
    BG_IC_INTERV_IND_MST_ID
]

# Indicators that should only show up in disease-specific mode in IHT or for TB app.
BG_IC_DIS_SPEC_IND_SET = [
    BG_IC_LABOR_COSTS_IND_MST_ID, 
    BG_IC_VISIT_COSTS_IND_MST_ID
]

# Indicators that should only show up for TB app or in IHT specific mode.
BG_IC_TB_IHT_SPEC_IND_TYPE_MST_IDS = [
    BG_IC_LOG_SUPPLY_CHAIN_COSTS_MST_ID, 
    BG_IC_WASTAGE_COSTS_MST_ID
]

# Cost categories 

BG_IC_DRUGS_SUPPLIES_CC_MST_ID = 1
BG_IC_LABOR_CC_MST_ID          = 2
BG_IC_VISITS_CC_MST_ID         = 3
BG_IC_NUM_COST_CATEGORIES      = 3

# Is the user costing intervention budget indicators or drug/supply budget indicators?

BG_IC_COST_INTERVENTIONS_MST_ID  = 1
BG_IC_COST_DRUGS_SUPPLIES_MST_ID = 2

#   *************************   PC indicator types   **************************
# 
BG_PC_COST_SECT_IND_MST_ID             = 1
BG_PC_COST_SUBSECT_IND_MST_ID          = 2
BG_PC_ACTIVITY_IND_MST_ID              = 3
BG_PC_COST_SECT_PPLI_IND_MST_ID        = 4
BG_PC_COST_SUBSECT_PPLI_IND_MST_ID     = 5
BG_PC_ACTIVITY_PPLI_IND_MST_ID         = 6
BG_PC_COST_SECT_SOC_ENAB_IND_MST_ID    = 7
BG_PC_COST_SUBSECT_SOC_ENAB_IND_MST_ID = 8
BG_PC_ACTIVITY_SOC_ENAB_IND_MST_ID     = 9
BG_PC_NUM_IND_TYPES                    = 9

# Standard indicators
BG_PC_STD_IND_TYPE_MST_IDS = [BG_PC_COST_SECT_IND_MST_ID, BG_PC_COST_SUBSECT_IND_MST_ID, BG_PC_ACTIVITY_IND_MST_ID]

# PPLI indicators
BG_PC_PPLI_IND_TYPE_MST_IDS = [BG_PC_COST_SECT_PPLI_IND_MST_ID, BG_PC_COST_SUBSECT_PPLI_IND_MST_ID, BG_PC_ACTIVITY_PPLI_IND_MST_ID]

# Social enablers indicators
BG_PC_SOC_ENAB_IND_TYPE_MST_IDS = [BG_PC_COST_SECT_SOC_ENAB_IND_MST_ID, BG_PC_COST_SUBSECT_SOC_ENAB_IND_MST_ID, BG_PC_ACTIVITY_SOC_ENAB_IND_MST_ID]

# All possible PC indicators

BG_PC_IND_TYPE_MST_IDS = [
    BG_PC_COST_SECT_IND_MST_ID, BG_PC_COST_SUBSECT_IND_MST_ID, BG_PC_ACTIVITY_IND_MST_ID,
    BG_PC_COST_SECT_PPLI_IND_MST_ID, BG_PC_COST_SUBSECT_PPLI_IND_MST_ID, BG_PC_ACTIVITY_PPLI_IND_MST_ID,
    BG_PC_COST_SECT_SOC_ENAB_IND_MST_ID, BG_PC_COST_SUBSECT_SOC_ENAB_IND_MST_ID, BG_PC_ACTIVITY_SOC_ENAB_IND_MST_ID
]

BG_PC_COST_SECT_IND_TYPE_MST_IDS = [BG_PC_COST_SECT_IND_MST_ID, BG_PC_COST_SECT_PPLI_IND_MST_ID, BG_PC_COST_SECT_SOC_ENAB_IND_MST_ID]

BG_PC_COST_SUBSECT_IND_TYPE_MST_IDS = [BG_PC_COST_SUBSECT_IND_MST_ID, BG_PC_COST_SUBSECT_PPLI_IND_MST_ID, BG_PC_COST_SUBSECT_SOC_ENAB_IND_MST_ID]

BG_PC_ACTIVITY_IND_TYPE_MST_IDS = [BG_PC_ACTIVITY_IND_MST_ID, BG_PC_ACTIVITY_PPLI_IND_MST_ID, BG_PC_ACTIVITY_SOC_ENAB_IND_MST_ID]

#   *************************   IS indicator types   **************************

# Note that Total facility operating costs used to be a group indicator that aggregated facility water, electric, non utility operating costs.  However, we no longer have
# that breakdown available, so now it because a regular lump sum indicator by facility type.

# BG_IS_CONSTR_LAND_IND_MST_ID             = 1
BG_IS_CONSTR_BUILD_IND_MST_ID            = 2
BG_IS_REHAB_COSTS_IND_MST_ID             = 3
BG_IS_MED_EQUIPMENT_IND_MST_ID           = 4 # Used by TB Costing. Also used by IHT
BG_IS_FURNITURE_IND_MST_ID               = 5
BG_IS_VEHICLES_IND_MST_ID                = 6
BG_IS_COMMUNIC_EQUIP_IND_MST_ID          = 7
#BG_IS_FACIL_NON_UTIL_OP_COSTS_IND_MST_ID = 8
# BG_IS_FACIL_ELECTR_COSTS_IND_MST_ID      = 9
# BG_IS_FACIL_WATER_COSTS_IND_MST_ID       = 10
BG_IS_VEHIC_FUEL_EXPENSE_IND_MST_ID      = 11
BG_IS_VEHIC_MAINT_REPAIR_IND_MST_ID      = 12
BG_IS_VEHIC_DRIVER_SAL_IND_MST_ID        = 13
BG_IS_ICT_MAINT_REPAIR_IND_MST_ID        = 14
BG_IS_TOTAL_NEW_FACIL_COSTS_IND_MST_ID   = 15
BG_IS_TOTAL_OP_COSTS_IND_MST_ID          = 16
# BG_IS_TOTAL_CONSTR_COSTS_IND_MST_ID      = 17
BG_IS_TOTAL_FACIL_OP_COSTS_IND_MST_ID    = 18
BG_IS_TOTAL_VEHIC_OP_COSTS_IND_MST_ID    = 19
# BG_IS_ProgMgmtInd            = 20
# BG_IS_ProgMgmtOtherActInd    = 21
BG_IS_MED_EQUIP_MAINT_CALIB_COSTS_TB_IND_MST_ID = 22 # Only used by TB Costing
BG_IS_PROG_MGMT_COST_SECT_IND_MST_ID    = 23
BG_IS_PROG_MGMT_COST_SUBSECT_IND_MST_ID = 24
BG_IS_PROG_MGMT_ACTIVITY_IND_MST_ID     = 25

BG_IS_NUM_IND_TYPES            = 17

# IS has no need of a current and master ID for the other non-facility-based indicator entry but BG does. 
BG_IS_OTHER_NON_FACIL_BASED_MST_ID = 'Non-facility-based-ID'

# All possible IS indicators

BG_IS_IND_TYPE_MST_IDS = [
    # BG_IS_CONSTR_LAND_IND_MST_ID,
    BG_IS_CONSTR_BUILD_IND_MST_ID,
    BG_IS_REHAB_COSTS_IND_MST_ID,
    BG_IS_MED_EQUIPMENT_IND_MST_ID,
    BG_IS_FURNITURE_IND_MST_ID,
    BG_IS_VEHICLES_IND_MST_ID,
    BG_IS_COMMUNIC_EQUIP_IND_MST_ID,
    #BG_IS_FACIL_NON_UTIL_OP_COSTS_IND_MST_ID,
    # BG_IS_FACIL_ELECTR_COSTS_IND_MST_ID,
    # BG_IS_FACIL_WATER_COSTS_IND_MST_ID,
    BG_IS_VEHIC_FUEL_EXPENSE_IND_MST_ID,
    BG_IS_VEHIC_MAINT_REPAIR_IND_MST_ID,
    BG_IS_VEHIC_DRIVER_SAL_IND_MST_ID,
    BG_IS_ICT_MAINT_REPAIR_IND_MST_ID,
    BG_IS_TOTAL_NEW_FACIL_COSTS_IND_MST_ID,
    BG_IS_TOTAL_OP_COSTS_IND_MST_ID,
    # BG_IS_TOTAL_CONSTR_COSTS_IND_MST_ID,
    BG_IS_TOTAL_FACIL_OP_COSTS_IND_MST_ID,
    BG_IS_TOTAL_VEHIC_OP_COSTS_IND_MST_ID,
    BG_IS_PROG_MGMT_COST_SECT_IND_MST_ID,
    BG_IS_PROG_MGMT_COST_SUBSECT_IND_MST_ID,
    BG_IS_PROG_MGMT_ACTIVITY_IND_MST_ID,
]

# IS indicators that appear for TB app.
BG_IS_TB_IHT_SPEC_IND_TYPE_MST_IDS = [
    BG_IS_MED_EQUIPMENT_IND_MST_ID,
    BG_IS_MED_EQUIP_MAINT_CALIB_COSTS_TB_IND_MST_ID,
]

BG_IS_TB_ONLY_IND_TYPE_MST_IDS = [
  BG_IS_MED_EQUIP_MAINT_CALIB_COSTS_TB_IND_MST_ID,  
]

# All IS indicators than can be displayed by a dynamic facility type

BG_IS_FACILITY_TYPE_IND_SET = [
    # BG_IS_CONSTR_LAND_IND_MST_ID, 
    BG_IS_CONSTR_BUILD_IND_MST_ID,
    BG_IS_REHAB_COSTS_IND_MST_ID, 
    BG_IS_MED_EQUIPMENT_IND_MST_ID, 
    BG_IS_FURNITURE_IND_MST_ID,
    BG_IS_VEHICLES_IND_MST_ID, 
    BG_IS_COMMUNIC_EQUIP_IND_MST_ID, 
    #BG_IS_FACIL_NON_UTIL_OP_COSTS_IND_MST_ID,
    # BG_IS_FACIL_ELECTR_COSTS_IND_MST_ID, 
    # BG_IS_FACIL_WATER_COSTS_IND_MST_ID,
    BG_IS_VEHIC_FUEL_EXPENSE_IND_MST_ID, 
    BG_IS_VEHIC_MAINT_REPAIR_IND_MST_ID,
    BG_IS_VEHIC_DRIVER_SAL_IND_MST_ID, 
    BG_IS_ICT_MAINT_REPAIR_IND_MST_ID,
    BG_IS_TOTAL_NEW_FACIL_COSTS_IND_MST_ID, 
    BG_IS_TOTAL_OP_COSTS_IND_MST_ID, 
    # BG_IS_TOTAL_CONSTR_COSTS_IND_MST_ID,
    BG_IS_TOTAL_FACIL_OP_COSTS_IND_MST_ID, 
    BG_IS_TOTAL_VEHIC_OP_COSTS_IND_MST_ID,
    BG_IS_MED_EQUIP_MAINT_CALIB_COSTS_TB_IND_MST_ID,
]

# All IS indicators that can be displayed by a single Non-facility based indicator in addition to the facility type indicators. The last three are in here because one or more 
# constituent indicators are also have a single Non-facility based line that needs to be accounted for. The first six are numbered here:
#
#     New facilities
#         1. Vehicles
#         2. Communication equipment
#
#     Operating costs
#         Total vehicle operating costs
#             3. Vehicle fuel expenses
#             4. Vehicle maintenace and repair
#             5. Driver salary
#         6. ICT maintenance and repair
#        
#        
#  Since 1 and 2 are part of the "New facilities" aggregate indicator type, if aggregating "New facilities", there needs to be a Non-facility based indicator line.
#  Since 3-5 are part of "Total vehicle operating costs" aggregate indicator type, which is in turn part of "Operating costs" aggregate indicator type, if 
#  aggregating "Operating costs" or "Total vehicle operating costs", there needs to be a Non-facility based indicator line. 
BG_IS_NON_FACIL_IND_SET = [
    BG_IS_VEHICLES_IND_MST_ID, 
    BG_IS_COMMUNIC_EQUIP_IND_MST_ID,
    BG_IS_VEHIC_FUEL_EXPENSE_IND_MST_ID,
    BG_IS_VEHIC_MAINT_REPAIR_IND_MST_ID, 
    BG_IS_VEHIC_DRIVER_SAL_IND_MST_ID,
    BG_IS_ICT_MAINT_REPAIR_IND_MST_ID, 
    BG_IS_TOTAL_NEW_FACIL_COSTS_IND_MST_ID, 
    BG_IS_TOTAL_VEHIC_OP_COSTS_IND_MST_ID, 
    BG_IS_TOTAL_OP_COSTS_IND_MST_ID
]

# This set contains all IS indicators that can be aggregated and disaggregated by facility type, NOT including indicators that use Non-facility-based
BG_IS_FACIL_AGGR_IND_SET = [
    # BG_IS_CONSTR_LAND_IND_MST_ID, 
    BG_IS_CONSTR_BUILD_IND_MST_ID,
    BG_IS_REHAB_COSTS_IND_MST_ID, 
    BG_IS_MED_EQUIPMENT_IND_MST_ID, 
    BG_IS_FURNITURE_IND_MST_ID,
    #BG_IS_FACIL_NON_UTIL_OP_COSTS_IND_MST_ID,
    # BG_IS_FACIL_ELECTR_COSTS_IND_MST_ID, 
    # BG_IS_FACIL_WATER_COSTS_IND_MST_ID,
    BG_IS_TOTAL_FACIL_OP_COSTS_IND_MST_ID
]

# This set contains all IS indicators that can be aggregated and disaggregated by facility type PLUS an additional slot for non-facility-based related costs.
BG_IS_FACIL_NON_FACIL_AGGR_IND_SET = [
    BG_IS_VEHICLES_IND_MST_ID, 
    BG_IS_COMMUNIC_EQUIP_IND_MST_ID,
    BG_IS_VEHIC_FUEL_EXPENSE_IND_MST_ID,
    BG_IS_VEHIC_MAINT_REPAIR_IND_MST_ID, 
    BG_IS_VEHIC_DRIVER_SAL_IND_MST_ID,
    BG_IS_ICT_MAINT_REPAIR_IND_MST_ID, 
]

# This set contains all IS indicators that can be aggregated and disaggregated by costing groups. 
BG_IS_GROUP_IND_SET = [
    BG_IS_TOTAL_NEW_FACIL_COSTS_IND_MST_ID, 
    BG_IS_TOTAL_OP_COSTS_IND_MST_ID,
    # BG_IS_TOTAL_CONSTR_COSTS_IND_MST_ID, 
    # BG_IS_TOTAL_FACIL_OP_COSTS_IND_MST_ID, now a lump sum indicator
    BG_IS_TOTAL_VEHIC_OP_COSTS_IND_MST_ID
]

# This set contains all IS indicators that fall under the total new facilities group.
BG_IS_NEW_FACIL_IND_SET = [
    # BG_IS_CONSTR_LAND_IND_MST_ID, 
    BG_IS_CONSTR_BUILD_IND_MST_ID,
    BG_IS_REHAB_COSTS_IND_MST_ID, 
    BG_IS_MED_EQUIPMENT_IND_MST_ID, 
    BG_IS_FURNITURE_IND_MST_ID,
    BG_IS_VEHICLES_IND_MST_ID, 
    BG_IS_COMMUNIC_EQUIP_IND_MST_ID, 
    # BG_IS_TOTAL_CONSTR_COSTS_IND_MST_ID
]

# This set contains all IS groups that fall under the total construction costs group.
BG_IS_CONSTR_COSTS_IND_SET = [
    # BG_IS_CONSTR_LAND_IND_MST_ID, 
    BG_IS_CONSTR_BUILD_IND_MST_ID
]

# This set contains all IS groups that fall under the total operating costs group.
BG_IS_OP_COSTS_IND_SET = [
    #BG_IS_FACIL_NON_UTIL_OP_COSTS_IND_MST_ID,
    # BG_IS_FACIL_ELECTR_COSTS_IND_MST_ID, 
    # BG_IS_FACIL_WATER_COSTS_IND_MST_ID,
    BG_IS_VEHIC_FUEL_EXPENSE_IND_MST_ID, 
    BG_IS_VEHIC_MAINT_REPAIR_IND_MST_ID,
    BG_IS_VEHIC_DRIVER_SAL_IND_MST_ID, 
    BG_IS_ICT_MAINT_REPAIR_IND_MST_ID, 
    BG_IS_TOTAL_FACIL_OP_COSTS_IND_MST_ID,
    BG_IS_TOTAL_VEHIC_OP_COSTS_IND_MST_ID
]

# This set contains all IS groups that fall under the total facility operating costs group.
# BG_IS_FACIL_OP_COSTS_IND_SET = [
#     BG_IS_FACIL_NON_UTIL_OP_COSTS_IND_MST_ID,
#     BG_IS_FACIL_ELECTR_COSTS_IND_MST_ID, 
#     BG_IS_FACIL_WATER_COSTS_IND_MST_ID
# ]

# This set contains all IS groups that fall under the total vehicle operating costs group.  
BG_IS_VEHIC_OP_COSTS_IND_SET = [
    BG_IS_VEHIC_FUEL_EXPENSE_IND_MST_ID,
    BG_IS_VEHIC_MAINT_REPAIR_IND_MST_ID, 
    BG_IS_VEHIC_DRIVER_SAL_IND_MST_ID
]

# Programme management
BG_IS_PROG_MGMT_IND_TYPE_MST_IDS = [
    BG_IS_PROG_MGMT_COST_SECT_IND_MST_ID, 
    BG_IS_PROG_MGMT_COST_SUBSECT_IND_MST_ID, 
    BG_IS_PROG_MGMT_ACTIVITY_IND_MST_ID,
]

#  *************************   HW indicator types  ***************************

# Notes: BG_HW_INSERV_TRAIN_SPEC_TRAIN_DET_IND_MST_ID and BG_HW_INSERV_TRAIN_PERC_SAL_MST_ID, BG_HW_INSERV_TRAIN_PERC_SAL_SINGLE_STAFF_TYPE_MST_ID are mutually exclusive. The 
# former one should only be shown/costed if the user is using the specific training details approach in HW and the latter two should only be shown if the user is using the 
# percent of salary approach.

BG_HW_TOTAL_COMP_MST_ID                              = 1 # by staffing level, compensation type, dynamic staff type (aggregable by staff type)
BG_HW_PRESERV_TRAIN_MST_ID                           = 2 # by dynamic staff type (aggregable by staff type)
BG_HW_INSERV_TRAIN_PERC_SAL_MST_ID                   = 3 # only when HW uses % salary approach; by staffing level, dynamic staff type (aggregable by staff type)
# BG_HW_PROG_MGMT_MST_ID                             = 4
BG_HW_TOTAL_COMP_SINGLE_STAFF_TYPE_MST_ID            = 5 # by dynamic staff type (not aggregable by staff type)
BG_HW_INSERV_TRAIN_SPEC_TRAIN_DET_IND_MST_ID         = 6 # only when HW uses specific training details approach; by dynamic staff type (aggregable by staff type)
BG_HW_INSERV_TRAIN_PERC_SAL_SINGLE_STAFF_TYPE_MST_ID = 7 # only when HW uses % salary approach; by dynamic staff type (not aggregable by staff type; same as BG_HW_TOTAL_COMP_SINGLE_STAFF_TYPE_MST_ID)
# BG_HW_PROG_MGMT_OTHER_ACT_MST_ID                   = 8
BG_HW_PROG_MGMT_COST_SECT_IND_MST_ID                 = 9
BG_HW_PROG_MGMT_COST_SUBSECT_IND_MST_ID              = 10
BG_HW_PROG_MGMT_ACTIVITY_IND_MST_ID                  = 11

BG_HW_NUM_IND_TYPES                                  = 9

# All possible HW indicators

BG_HW_IND_TYPE_MST_IDS = [
    BG_HW_TOTAL_COMP_MST_ID, 
    BG_HW_PRESERV_TRAIN_MST_ID, 
    BG_HW_INSERV_TRAIN_PERC_SAL_MST_ID, 
    BG_HW_TOTAL_COMP_SINGLE_STAFF_TYPE_MST_ID, 
    BG_HW_INSERV_TRAIN_SPEC_TRAIN_DET_IND_MST_ID, 
    BG_HW_INSERV_TRAIN_PERC_SAL_SINGLE_STAFF_TYPE_MST_ID,
    BG_HW_PROG_MGMT_COST_SECT_IND_MST_ID,
    BG_HW_PROG_MGMT_COST_SUBSECT_IND_MST_ID,
    BG_HW_PROG_MGMT_ACTIVITY_IND_MST_ID,
]

#   All HW indicators that can (dis)aggregated by staff type. 
BG_HW_STAFF_AGGR_IND_SET = [
    BG_HW_TOTAL_COMP_MST_ID, BG_HW_PRESERV_TRAIN_MST_ID,
    BG_HW_INSERV_TRAIN_PERC_SAL_MST_ID, BG_HW_INSERV_TRAIN_SPEC_TRAIN_DET_IND_MST_ID
]

#   All HW indicators that that can be displayed by dynamic staff type.
BG_HW_STAFF_TYPE_IND_SET = [
    BG_HW_TOTAL_COMP_MST_ID, BG_HW_PRESERV_TRAIN_MST_ID,
    BG_HW_INSERV_TRAIN_PERC_SAL_MST_ID, BG_HW_TOTAL_COMP_SINGLE_STAFF_TYPE_MST_ID,
    BG_HW_INSERV_TRAIN_SPEC_TRAIN_DET_IND_MST_ID, BG_HW_INSERV_TRAIN_PERC_SAL_SINGLE_STAFF_TYPE_MST_ID
]

# Programme management
BG_HW_PROG_MGMT_IND_TYPE_MST_IDS = [
    BG_HW_PROG_MGMT_COST_SECT_IND_MST_ID, 
    BG_HW_PROG_MGMT_COST_SUBSECT_IND_MST_ID, 
    BG_HW_PROG_MGMT_ACTIVITY_IND_MST_ID,
]

#   *************************   HS indicator types  ***************************

BG_HS_COSTING_COST_SECT_IND_MST_ID      = 5
BG_HS_COSTING_COST_SUBSECT_IND_MST_ID   = 6
BG_HS_COSTING_ACTIVITY_IND_MST_ID       = 7
BG_HS_PROG_MGMT_COST_SECT_IND_MST_ID    = 8
BG_HS_PROG_MGMT_COST_SUBSECT_IND_MST_ID = 9
BG_HS_PROG_MGMT_ACTIVITY_IND_MST_ID     = 10
BG_HS_NUM_IND_TYPES                     = 6

# All possible HS indicators

BG_HS_IND_TYPE_MST_IDS = [
    BG_HS_COSTING_COST_SECT_IND_MST_ID, 
    BG_HS_COSTING_COST_SUBSECT_IND_MST_ID, 
    BG_HS_COSTING_ACTIVITY_IND_MST_ID,
    BG_HS_PROG_MGMT_COST_SECT_IND_MST_ID,
    BG_HS_PROG_MGMT_COST_SUBSECT_IND_MST_ID,
    BG_HS_PROG_MGMT_ACTIVITY_IND_MST_ID
]

# HS costing indicators

BG_HS_COSTING_IND_TYPE_MST_IDS = [
    BG_HS_COSTING_COST_SECT_IND_MST_ID, 
    BG_HS_COSTING_COST_SUBSECT_IND_MST_ID, 
    BG_HS_COSTING_ACTIVITY_IND_MST_ID,
]

# HS programme management indicators

BG_HS_PROG_MGMT_IND_TYPE_MST_IDS = [
    BG_HS_PROG_MGMT_COST_SECT_IND_MST_ID, 
    BG_HS_PROG_MGMT_COST_SUBSECT_IND_MST_ID, 
    BG_HS_PROG_MGMT_ACTIVITY_IND_MST_ID,
]

BG_HS_SECTION_IND_MST_IDS = [
    BG_HS_COSTING_COST_SECT_IND_MST_ID, 
    BG_HS_PROG_MGMT_COST_SECT_IND_MST_ID, 
]

BG_HS_SUBSECTION_IND_MST_IDS = [
    BG_HS_COSTING_COST_SUBSECT_IND_MST_ID, 
    BG_HS_PROG_MGMT_COST_SUBSECT_IND_MST_ID,
]

BG_HS_ACT_IND_MST_IDS = [
    BG_HS_COSTING_ACTIVITY_IND_MST_ID,
    BG_HS_PROG_MGMT_ACTIVITY_IND_MST_ID,
]

# HIS or programme management?
BG_HS_COSTING_IND_TYPE_DIVISION_MST_ID   = 1
BG_HS_PROG_MGMT_IND_TYPE_DIVISION_MST_ID = 2

#   *************************   GV indicator types  ***************************

BG_GV_COSTING_COST_SECT_IND_MST_ID      = 5
BG_GV_COSTING_COST_SUBSECT_IND_MST_ID   = 6
BG_GV_COSTING_ACTIVITY_IND_MST_ID       = 7
BG_GV_PROG_MGMT_COST_SECT_IND_MST_ID    = 8
BG_GV_PROG_MGMT_COST_SUBSECT_IND_MST_ID = 9
BG_GV_PROG_MGMT_ACTIVITY_IND_MST_ID     = 10
BG_GV_NUM_IND_TYPES                     = 6

# All possible GV indicators

BG_GV_IND_TYPE_MST_IDS = [
    BG_GV_COSTING_COST_SECT_IND_MST_ID, 
    BG_GV_COSTING_COST_SUBSECT_IND_MST_ID, 
    BG_GV_COSTING_ACTIVITY_IND_MST_ID,
    BG_GV_PROG_MGMT_COST_SECT_IND_MST_ID,
    BG_GV_PROG_MGMT_COST_SUBSECT_IND_MST_ID,
    BG_GV_PROG_MGMT_ACTIVITY_IND_MST_ID
]

# GV costing indicators

BG_GV_COSTING_IND_TYPE_MST_IDS = [
    BG_GV_COSTING_COST_SECT_IND_MST_ID, 
    BG_GV_COSTING_COST_SUBSECT_IND_MST_ID, 
    BG_GV_COSTING_ACTIVITY_IND_MST_ID,
]

# GV programme management indicators

BG_GV_PROG_MGMT_IND_TYPE_MST_IDS = [
    BG_GV_PROG_MGMT_COST_SECT_IND_MST_ID, 
    BG_GV_PROG_MGMT_COST_SUBSECT_IND_MST_ID, 
    BG_GV_PROG_MGMT_ACTIVITY_IND_MST_ID,
]

BG_GV_SECTION_IND_MST_IDS = [
    BG_GV_COSTING_COST_SECT_IND_MST_ID, 
    BG_GV_PROG_MGMT_COST_SECT_IND_MST_ID, 
]

BG_GV_SUBSECTION_IND_MST_IDS = [
    BG_GV_COSTING_COST_SUBSECT_IND_MST_ID, 
    BG_GV_PROG_MGMT_COST_SUBSECT_IND_MST_ID,
]

BG_GV_ACT_IND_MST_IDS = [
    BG_GV_COSTING_ACTIVITY_IND_MST_ID,
    BG_GV_PROG_MGMT_ACTIVITY_IND_MST_ID,
]

# GV or programme management?
BG_GV_COSTING_IND_TYPE_DIVISION_MST_ID   = 1
BG_GV_PROG_MGMT_IND_TYPE_DIVISION_MST_ID = 2

#   *************************   HF indicator types  ***************************

BG_HF_COSTING_COST_SECT_IND_MST_ID      = 5
BG_HF_COSTING_COST_SUBSECT_IND_MST_ID   = 6
BG_HF_COSTING_ACTIVITY_IND_MST_ID       = 7
BG_HF_PROG_MGMT_COST_SECT_IND_MST_ID    = 8
BG_HF_PROG_MGMT_COST_SUBSECT_IND_MST_ID = 9
BG_HF_PROG_MGMT_ACTIVITY_IND_MST_ID     = 10
BG_HF_NUM_IND_TYPES                     = 6

# All possible HF indicators

BG_HF_IND_TYPE_MST_IDS = [
    BG_HF_COSTING_COST_SECT_IND_MST_ID, 
    BG_HF_COSTING_COST_SUBSECT_IND_MST_ID, 
    BG_HF_COSTING_ACTIVITY_IND_MST_ID,
    BG_HF_PROG_MGMT_COST_SECT_IND_MST_ID,
    BG_HF_PROG_MGMT_COST_SUBSECT_IND_MST_ID,
    BG_HF_PROG_MGMT_ACTIVITY_IND_MST_ID
]

# HF costing indicators

BG_HF_COSTING_IND_TYPE_MST_IDS = [
    BG_HF_COSTING_COST_SECT_IND_MST_ID, 
    BG_HF_COSTING_COST_SUBSECT_IND_MST_ID, 
    BG_HF_COSTING_ACTIVITY_IND_MST_ID,
]

# HF programme management indicators

BG_HF_PROG_MGMT_IND_TYPE_MST_IDS = [
    BG_HF_PROG_MGMT_COST_SECT_IND_MST_ID, 
    BG_HF_PROG_MGMT_COST_SUBSECT_IND_MST_ID, 
    BG_HF_PROG_MGMT_ACTIVITY_IND_MST_ID,
]

BG_HF_SECTION_IND_MST_IDS = [
    BG_HF_COSTING_COST_SECT_IND_MST_ID, 
    BG_HF_PROG_MGMT_COST_SECT_IND_MST_ID, 
]

BG_HF_SUBSECTION_IND_MST_IDS = [
    BG_HF_COSTING_COST_SUBSECT_IND_MST_ID, 
    BG_HF_PROG_MGMT_COST_SUBSECT_IND_MST_ID,
]

BG_HF_ACT_IND_MST_IDS = [
    BG_HF_COSTING_ACTIVITY_IND_MST_ID,
    BG_HF_PROG_MGMT_ACTIVITY_IND_MST_ID,
]

# HF or programme management?
BG_HF_COSTING_IND_TYPE_DIVISION_MST_ID   = 1
BG_HF_PROG_MGMT_IND_TYPE_DIVISION_MST_ID = 2

# Costing level; now used for all health systems with programme management. Note that for HS, the user cannot mix 
# HS Costing and HS Programme Management levels in the editor. Both must be costing, subsection, activity, etc.
# Used for HS, IS, HW, LG. Also note that each module needs to be able to save a different level at the same time.
# That is, HS could be at the section level, IS could be at the subsection level, etc.

BG_COST_COSTING_SECTIONS_LEVEL_MST_ID     = 1
BG_COST_COSTING_SUBSECTIONS_LEVEL_MST_ID  = 2
BG_COST_ACTIVITIES_LEVEL_MST_ID           = 3