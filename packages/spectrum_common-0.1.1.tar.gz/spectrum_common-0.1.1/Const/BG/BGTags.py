# Input ModVars

BG_VERSION_TAG                              = '<BG_FileVersion_V1>'
BG_BUDGET_RECORDS_TAG                       = '<BG_BudgetRecords_V1>'
BG_INDICATOR_RECORDS_IC_TAG                 = '<BG_IndicatorRecordsIC_V4>' 
BG_INDICATOR_RECORDS_PC_TAG                 = '<BG_IndicatorRecordsPC_V1>' 
BG_INDICATOR_RECORDS_IS_TAG                 = '<BG_IndicatorRecordsIS_V3>' 
BG_INDICATOR_RECORDS_HW_TAG                 = '<BG_IndicatorRecordsHW_V1>' 
BG_INDICATOR_RECORDS_HS_TAG                 = '<BG_IndicatorRecordsHS_V1>' 
BG_INDICATOR_RECORDS_GV_TAG                 = '<BG_IndicatorRecordsGV_V1>'
BG_INDICATOR_RECORDS_HF_TAG                 = '<BG_IndicatorRecordsHF_V1>'
BG_BUDGET_CAT_RECORDS_TAG                   = '<BG_BudgetCategoryRecords_V1>'
BG_BUDGET_CAT_SHARE_RECORDS_IC_TAG          = '<BG_BudgetCategoryShareRecordsIC_V2>'
BG_BUDGET_CAT_SHARE_RECORDS_PC_TAG          = '<BG_BudgetCategoryShareRecordsPC_V1>'
BG_BUDGET_CAT_SHARE_RECORDS_IS_TAG          = '<BG_BudgetCategoryShareRecordsIS_V2>'
BG_BUDGET_CAT_SHARE_RECORDS_HW_TAG          = '<BG_BudgetCategoryShareRecordsHW_V1>'
BG_BUDGET_CAT_SHARE_RECORDS_HS_TAG          = '<BG_BudgetCategoryShareRecordsHS_V1>'
BG_BUDGET_CAT_SHARE_RECORDS_GV_TAG          = '<BG_BudgetCategoryShareRecordsGV_V1>'
BG_BUDGET_CAT_SHARE_RECORDS_HF_TAG          = '<BG_BudgetCategoryShareRecordsHF_V1>'
BG_FUND_FW_RECORDS_TAG                      = '<BG_FundingFrameworkRecords_V1>'
BG_FUND_SOURCE_RECORDS_TAG                  = '<BG_FundingSourceRecords_V1>'
BG_FUND_SOURCE_SHARE_RECORDS_IC_TAG         = '<BG_FundingSourceShareRecordsIC_V2>'
BG_FUND_SOURCE_SHARE_RECORDS_PC_TAG         = '<BG_FundingSourceShareRecordsPC_V1>'
BG_FUND_SOURCE_SHARE_RECORDS_IS_TAG         = '<BG_FundingSourceShareRecordsIS_V2>'
BG_FUND_SOURCE_SHARE_RECORDS_HW_TAG         = '<BG_FundingSourceShareRecordsHW_V1>'
BG_FUND_SOURCE_SHARE_RECORDS_HS_TAG         = '<BG_FundingSourceShareRecordsHS_V1>'
BG_FUND_SOURCE_SHARE_RECORDS_GV_TAG         = '<BG_FundingSourceShareRecordsGV_V1>'
BG_FUND_SOURCE_SHARE_RECORDS_HF_TAG         = '<BG_FundingSourceShareRecordsHF_V1>'
BG_USING_SAME_FUND_MAPPINGS_ALL_BUDGETS_TAG = '<BG_UsingSameFundingMappingsAllBudgets_V1>'
BG_QUICK_MAP_RECORDS_TAG                    = '<BG_QuickMapRecords_V3>'

# IC_SUPPLY_CHAIN_STATUS_CS_META_TAG_V1              = '<IC_SupplyChainStatusCS_Meta_V1>'

# # Output / Result ModVars

BG_RES_TOTAL_COSTS_BY_BUDGET_CAT_TAG             = '<IC_ResTotalCostsByBudgetCategory_V1>'
BG_RES_TOTAL_COSTS_BY_FUND_SOURCE_TAG            = '<IC_ResTotalCostsByFundingSource_V1>'
BG_RES_TOTAL_COSTS_BY_BUDGET_CAT_FUND_SOURCE_TAG = '<IC_ResTotalCostsByBudgetCategoryFundingSource_V1>'

# Meta ModVars. The values inside these do not change. 

BG_DEFAULT_BUDGET_LIST_META_TAG = '<BG_DefaultBudgetList_Meta_V3>'
BG_DEFAULT_FUND_FW_LIST_META_TAG = '<BG_DefaultFundingFrameworkList_Meta_V2>'