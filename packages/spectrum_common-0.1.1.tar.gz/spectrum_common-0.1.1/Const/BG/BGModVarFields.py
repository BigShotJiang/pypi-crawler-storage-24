# Fields used in BG ModVar data structures

from SpectrumCommon.Const.BG.BGConstLink import *

# general fields for keeping ID fields consistent when relating records to each other and for use in result records

BG_F_BUDGET_ID          = 'budgetID'
BG_F_MOD_ID             = 'modID'
BG_F_IND_TYPE_ID        = 'indTypeID'
BG_F_IND_ID             = 'indID'
BG_F_BUDGET_CAT_ID      = 'budgetCatID'
BG_F_FUND_SOURCE_ID     = 'fundSourceID'
BG_F_FUND_FW_ID         = 'fundFrameworkID' 
BG_F_IS_AGGREGATE       = 'isAggregate' 
BG_F_STAFF_LEVEL_ID_HW  = 'staffLevelID'                
BG_F_COMPENS_TYPE_ID_HW = 'compensTypeID'  
BG_F_VALUE              = 'value'

BG_F_COSTING_SECT_HS_COSTING_ID         = 'costingSectionHSCostingID'         # string; 
BG_F_COSTING_SUBSECT_HS_COSTING_ID      = 'costingSubsectionHSCostingID'      # string; 
BG_F_ACT_HS_COSTING_ID                  = 'activityHSCostingID'               # string; 
BG_F_COSTING_SECT_HS_PROG_MGMT_ID       = 'costingSectionHSProgMgmtID'        # string; 
BG_F_COSTING_SUBSECT_HS_PROG_MGMT_ID    = 'costingSubsectionHSProgMgmtID'     # string; 
BG_F_ACT_HS_PROG_MGMT_ID                = 'activityHSProgMgmtID'              # string; 

BG_F_COSTING_SECT_GV_COSTING_ID         = 'costingSectionGVCostingID'         # string;
BG_F_COSTING_SUBSECT_GV_COSTING_ID      = 'costingSubsectionGVCostingID'      # string;
BG_F_ACT_GV_COSTING_ID                  = 'activityGVCostingID'               # string;
BG_F_COSTING_SECT_GV_PROG_MGMT_ID       = 'costingSectionGVProgMgmtID'        # string;
BG_F_COSTING_SUBSECT_GV_PROG_MGMT_ID    = 'costingSubsectionGVProgMgmtID'     # string;
BG_F_ACT_GV_PROG_MGMT_ID                = 'activityGVProgMgmtID'              # string;

BG_F_COSTING_SECT_HF_COSTING_ID         = 'costingSectionHFCostingID'         # string;
BG_F_COSTING_SUBSECT_HF_COSTING_ID      = 'costingSubsectionHFCostingID'      # string;
BG_F_ACT_HF_COSTING_ID                  = 'activityHFCostingID'               # string;
BG_F_COSTING_SECT_HF_PROG_MGMT_ID       = 'costingSectionHFProgMgmtID'        # string;
BG_F_COSTING_SUBSECT_HF_PROG_MGMT_ID    = 'costingSubsectionHFProgMgmtID'     # string;
BG_F_ACT_HF_PROG_MGMT_ID                = 'activityHFProgMgmtID'              # string;

# budget records

BG_BUDGET_ID                                           = BG_F_BUDGET_ID                      # string; Numeric mstID for defaults (still cast as string). GUID for custom budgets.
BG_BUDGET_NAME                                         = 'name'                              # string; Holds custom name or overridden default name.
BG_BUDGET_STR_CONST                                    = 'stringConstant'                    # string
BG_BUDGET_COST_INTERVS_DRUGS_SUPPLIES_IC               = 'costIntervsOrDrugsSuppliesIC'      # integer; 1 = interventions, 2 = drugs/supplies
BG_BUDGET_AGGR_DELIV_CHANS_IC                          = 'aggrDelivChansIC'                  # boolean; Are we costing IC indicators across all delivery channels combined or each individually?
BG_BUDGET_CUSTOM                                       = 'custom'                            # boolean
BG_BUDGET_ACTIVE                                       = 'active'                            # boolean
BG_BUDGET_FW_ID                                        = BG_F_FUND_FW_ID                     # string; Numeric mstID for defaults (still cast as string). GUID for custom funding frameworks.
BG_BUDGET_COST_LEVEL_PC_ID                             = 'levelPC'                           # integer; costing section = 1, subsection = 2, or activity level = 3
#BG_BUDGET_AGGR_PROG_MGMT_IND_HW                       = 'aggrProgMgmtIndHW'                 # boolean
BG_BUDGET_AGGR_INSERV_TRAIN_ALL_STAFF_HW               = 'aggrInservTrainAllStaffHW'         # boolean; Are we aggregating in-service training across all dynamic staff types? (Only applicable if Specific training details option chosen in HW)
BG_BUDGET_AGGR_PRESERV_TRAIN_ALL_STAFF_HW              = 'aggrPreservTrainAllStaffHW'        # boolean; Are we aggregating pre-service training across all dynamic staff types?
BG_BUDGET_AGGR_TOTAL_COMPENS_ALL_STAFF_HW              = 'aggrTotalCompensAllStaffHW'        # 2d list of boolean; For each staffing level and compensation type, are we aggregating total compensation across all dynamic staff types?
BG_BUDGET_AGGR_STAFF_INSERV_TRAIN_ALL_STAFF_LEV_HW     = 'aggrStaffInservTrainAllStaffLevHW' # 1d list of boolean; For each dynamic staff type, are we aggregating in-service training across all staffing levels? (Only applicable if Percent of salary approach option chosen in HW)
BG_BUDGET_AGGR_STAFF_LEV_INSERV_TRAIN_ALL_STAFF_HW     = 'aggrStaffLevInservTrainAllStaffHW' # 1d list of boolean; For each staffing level, are we aggregating in-service training across all dynamic staff types? (Only applicable if Percent of salary approach option chosen in HW)
BG_BUDGET_AGGR_TOTAL_COMPENS_STAFF_LEV_COMPENS_TYPE_HW = 'aggrTotalCompensAllStaffCompensHW' # 1d list of boolean; For each dynamic staff type, are we aggregating total compensation across all staffing levels and compensation types?
BG_BUDGET_COST_LEVEL_HW_ID                             = 'levelHW'                           # integer; costing section = 1, subsection = 2, or activity level = 3
BG_BUDGET_GROUP_IND_AGGR_SET_IS                        = 'aggrGroupIndIS'                    # 1d list of int; contains the master IDs of all IS indicators that the user wants to aggregate by group.
BG_BUDGET_FACILITY_IND_AGGR_SET_IS                     = 'aggrFacilityIndIS'                 # 1d list of int; contains the master IDs of all IS indicators that the user wants to aggregate by facility.
BG_BUDGET_COST_LEVEL_IS_ID                             = 'levelIS'                           # integer; costing section = 1, subsection = 2, or activity level = 3
BG_BUDGET_COST_LEVEL_HS_ID                             = 'levelHS'                           # integer; costing section = 1, subsection = 2, or activity level = 3
BG_BUDGET_COST_LEVEL_GV_ID                             = 'levelGV'                           # integer; costing section = 1, subsection = 2, or activity level = 3
BG_BUDGET_COST_LEVEL_HF_ID                             = 'levelHF'                           # integer; costing section = 1, subsection = 2, or activity level = 3
BG_BUDGET_COST_LEVEL_LG_ID                             = 'levelLG'                           # integer; costing section = 1, subsection = 2, or activity level = 3

# quick map records

BG_QUICK_MAP_BUDGET_ID        = BG_F_BUDGET_ID            # string; Numeric mstID for defaults (still cast as string). GUID for custom budgets.
BG_QUICK_MAP_MOD_ID           = BG_F_MOD_ID               # integer; Module code
BG_QUICK_MAP_TARGET_ID        = 'targetID'                # integer; budget categories vs funding sources
BG_QUICK_MAP_IND_TYPE_ID      = BG_F_IND_TYPE_ID          # integer; Range of possible values depends on module.
BG_QUICK_MAP_IS_AGGREGATE     = BG_F_IS_AGGREGATE         # boolean; Is the indicator being aggregated?
#BG_QUICK_MAP_DELIV_CHAN_ID_IC = BG_IC_F_DELIV_CHAN_ID    # string; Only applicable if BG_BUDGET_AGGR_DELIV_CHANS_IC is false
BG_QUICK_MAP_ON               = 'on'                      # boolean; True if turned on, false otherwise

# Indicator records. We add different fields according to the module represented.

BG_IND_BUDGET_ID                  = BG_F_BUDGET_ID               # string
# BG_IND_FUND_FW_ID                 = BG_F_FUND_FW_ID              # string
BG_IND_MOD_ID                     = BG_F_MOD_ID                  # integer; Module code
BG_IND_TYPE_ID                    = BG_F_IND_TYPE_ID             # integer; Range of possible values depends on module.
BG_IND_ID                         = BG_F_IND_ID                  # integer; Range of possible values depends on module.
BG_IND_BUDGET_CAT_ID              = BG_F_BUDGET_CAT_ID           # string
# BG_IND_FUND_SOURCE_ID             = BG_F_FUND_SOURCE_ID          # string
BG_IND_NAME                       = 'name'                       # string
#BG_IND_IS_AGGREGATE               = 'isAggregate'                # boolean; Is the indicator being aggregated?
#BG_IND_DISTRIB_MULTI_CATS         = 'distribMultiBudgetCats'     # boolean; Distribute indicator across multiple budget categories?
#BG_IND_DISTRIB_MULTI_FUND_SOURCES = 'distribMultiFundSources'    # boolean; Distribute indicator across multiple funding sources?
BG_IND_FUND_SOURCE_BY_FRAMEWORK   = 'fundSourceByFramework'      # dict; keys are funding funding framework IDs, values are funding source IDs (both strings)
BG_COST_CAT_IC_ID                 = 'costCatIC_ID'               # integer; ID of what we're showing in IC

BG_IND_DELIV_CHAN_ID_IC           = BG_IC_F_DELIV_CHAN_ID        # string; Only applicable if BG_BUDGET_AGGR_DELIV_CHANS_IC is false

BG_IND_COSTING_SECT_ID_PC         = BG_PC_F_COSTING_SECT_ID         # string; 
BG_IND_COSTING_SUBSECT_ID_PC      = BG_PC_F_COSTING_SUBSECT_ID      # string; 
BG_IND_ACT_ID_PC                  = BG_PC_F_ACT_ID                  # string; 
BG_IND_PROG_AREA_ID_PC            = BG_IH_F_PROG_AREA_ID            # string    

BG_IND_STAFF_LEVEL_ID_HW          = BG_F_STAFF_LEVEL_ID_HW          # int
BG_IND_COMPENS_TYPE_ID_HW         = BG_F_COMPENS_TYPE_ID_HW         # int

BG_IND_COSTING_SECT_HS_COSTING_ID         = BG_F_COSTING_SECT_HS_COSTING_ID      # string; 
BG_IND_COSTING_SUBSECT_HS_COSTING_ID      = BG_F_COSTING_SUBSECT_HS_COSTING_ID   # string; 
BG_IND_ACT_HS_COSTING_ID                  = BG_F_ACT_HS_COSTING_ID               # string; 
BG_IND_COSTING_SECT_HS_PROG_MGMT_ID       = BG_F_COSTING_SECT_HS_PROG_MGMT_ID    # string; 
BG_IND_COSTING_SUBSECT_HS_PROG_MGMT_ID    = BG_F_COSTING_SUBSECT_HS_PROG_MGMT_ID # string; 
BG_IND_ACT_HS_PROG_MGMT_ID                = BG_F_ACT_HS_PROG_MGMT_ID             # string; 

BG_IND_COSTING_SECT_GV_COSTING_ID         = BG_F_COSTING_SECT_GV_COSTING_ID      # string; 
BG_IND_COSTING_SUBSECT_GV_COSTING_ID      = BG_F_COSTING_SUBSECT_GV_COSTING_ID   # string; 
BG_IND_ACT_GV_COSTING_ID                  = BG_F_ACT_GV_COSTING_ID               # string; 
BG_IND_COSTING_SECT_GV_PROG_MGMT_ID       = BG_F_COSTING_SECT_GV_PROG_MGMT_ID    # string; 
BG_IND_COSTING_SUBSECT_GV_PROG_MGMT_ID    = BG_F_COSTING_SUBSECT_GV_PROG_MGMT_ID # string; 
BG_IND_ACT_GV_PROG_MGMT_ID                = BG_F_ACT_GV_PROG_MGMT_ID             # string; 

BG_IND_COSTING_SECT_HF_COSTING_ID         = BG_F_COSTING_SECT_HF_COSTING_ID      # string; 
BG_IND_COSTING_SUBSECT_HF_COSTING_ID      = BG_F_COSTING_SUBSECT_HF_COSTING_ID   # string; 
BG_IND_ACT_HF_COSTING_ID                  = BG_F_ACT_HF_COSTING_ID               # string; 
BG_IND_COSTING_SECT_HF_PROG_MGMT_ID       = BG_F_COSTING_SECT_HF_PROG_MGMT_ID    # string; 
BG_IND_COSTING_SUBSECT_HF_PROG_MGMT_ID    = BG_F_COSTING_SUBSECT_HF_PROG_MGMT_ID # string; 
BG_IND_ACT_HF_PROG_MGMT_ID                = BG_F_ACT_HF_PROG_MGMT_ID             # string; 

# budget category records

BG_BUDGET_CAT_BUDGET_ID                  = BG_F_BUDGET_ID               # string
BG_BUDGET_CAT_ID                         = BG_F_BUDGET_CAT_ID           # string; Numeric mstID for defaults (still cast as string). GUID for custom budgets.
BG_BUDGET_CAT_NAME                       = 'name'                       # string
BG_BUDGET_CAT_STR_CONST                  = 'stringConstant'             # string
BG_BUDGET_CAT_TOTAL_COST                 = 'totalCost'                  # list of float; by year
BG_BUDGET_CAT_CUSTOM                     = 'custom'                     # boolean

# budget category share rec

BG_BUDGET_CAT_SHARE_BUDGET_ID     = BG_F_BUDGET_ID         # string
BG_BUDGET_CAT_SHARE_MOD_ID        = BG_F_MOD_ID            # integer; Module code
BG_BUDGET_CAT_SHARE_IND_TYPE_ID   = BG_F_IND_TYPE_ID       # integer; Range of possible values depends on module.
BG_BUDGET_CAT_SHARE_IND_ID        = BG_F_IND_ID
BG_BUDGET_CAT_SHARE_BUDGET_CAT_ID = BG_F_BUDGET_CAT_ID     # string
BG_BUDGET_CAT_SHARE_VALUE         = 'value'                # float

BG_BUDGET_CAT_SHARE_DELIV_CHAN_ID = BG_IC_F_DELIV_CHAN_ID  # string

BG_BUDGET_CAT_SHARE_COSTING_SECT_ID_PC         = BG_PC_F_COSTING_SECT_ID         # string; 
BG_BUDGET_CAT_SHARE_COSTING_SUBSECT_ID_PC      = BG_PC_F_COSTING_SUBSECT_ID      # string; 
BG_BUDGET_CAT_SHARE_ACT_ID_PC                  = BG_PC_F_ACT_ID                  # string; 
BG_BUDGET_CAT_SHARE_PROG_AREA_ID_PC            = BG_IH_F_PROG_AREA_ID            # string    

BG_BUDGET_CAT_SHARE_STAFF_LEVEL_ID_HW  = BG_F_STAFF_LEVEL_ID_HW    # int
BG_BUDGET_CAT_SHARE_COMPENS_TYPE_ID_HW = BG_F_COMPENS_TYPE_ID_HW   # int

BG_BUDGET_CAT_SHARE_COSTING_SECT_HS_COSTING_ID         = BG_F_COSTING_SECT_HS_COSTING_ID      # string; 
BG_BUDGET_CAT_SHARE_COSTING_SUBSECT_HS_COSTING_ID      = BG_F_COSTING_SUBSECT_HS_COSTING_ID   # string; 
BG_BUDGET_CAT_SHARE_ACT_HS_COSTING_ID                  = BG_F_ACT_HS_COSTING_ID               # string; 
BG_BUDGET_CAT_SHARE_COSTING_SECT_HS_PROG_MGMT_ID       = BG_F_COSTING_SECT_HS_PROG_MGMT_ID    # string; 
BG_BUDGET_CAT_SHARE_COSTING_SUBSECT_HS_PROG_MGMT_ID    = BG_F_COSTING_SUBSECT_HS_PROG_MGMT_ID # string; 
BG_BUDGET_CAT_SHARE_ACT_HS_PROG_MGMT_ID                = BG_F_ACT_HS_PROG_MGMT_ID             # string; 

BG_BUDGET_CAT_SHARE_COSTING_SECT_GV_COSTING_ID         = BG_F_COSTING_SECT_GV_COSTING_ID      # string; 
BG_BUDGET_CAT_SHARE_COSTING_SUBSECT_GV_COSTING_ID      = BG_F_COSTING_SUBSECT_GV_COSTING_ID   # string; 
BG_BUDGET_CAT_SHARE_ACT_GV_COSTING_ID                  = BG_F_ACT_GV_COSTING_ID               # string; 
BG_BUDGET_CAT_SHARE_COSTING_SECT_GV_PROG_MGMT_ID       = BG_F_COSTING_SECT_GV_PROG_MGMT_ID    # string; 
BG_BUDGET_CAT_SHARE_COSTING_SUBSECT_GV_PROG_MGMT_ID    = BG_F_COSTING_SUBSECT_GV_PROG_MGMT_ID # string; 
BG_BUDGET_CAT_SHARE_ACT_GV_PROG_MGMT_ID                = BG_F_ACT_GV_PROG_MGMT_ID             # string; 

BG_BUDGET_CAT_SHARE_COSTING_SECT_HF_COSTING_ID         = BG_F_COSTING_SECT_HF_COSTING_ID      # string; 
BG_BUDGET_CAT_SHARE_COSTING_SUBSECT_HF_COSTING_ID      = BG_F_COSTING_SUBSECT_HF_COSTING_ID   # string; 
BG_BUDGET_CAT_SHARE_ACT_HF_COSTING_ID                  = BG_F_ACT_HF_COSTING_ID               # string; 
BG_BUDGET_CAT_SHARE_COSTING_SECT_HF_PROG_MGMT_ID       = BG_F_COSTING_SECT_HF_PROG_MGMT_ID    # string; 
BG_BUDGET_CAT_SHARE_COSTING_SUBSECT_HF_PROG_MGMT_ID    = BG_F_COSTING_SUBSECT_HF_PROG_MGMT_ID # string; 
BG_BUDGET_CAT_SHARE_ACT_HF_PROG_MGMT_ID                = BG_F_ACT_HF_PROG_MGMT_ID             # string; 

# funding framework records

BG_FUND_FW_ID                  = BG_F_FUND_FW_ID    # string; Numeric mstID for defaults (still cast as string). GUID for custom budgets.
BG_FUND_FW_NAME                = 'name'             # string
BG_FUND_FW_STR_CONSTANT        = 'stringConstant'   # string
BG_FUND_FW_CUSTOM              = 'custom'           # boolean

# funding source records

BG_FUND_SOURCE_FW_ID        = BG_F_FUND_FW_ID         # string
BG_FUND_SOURCE_ID            = BG_F_FUND_SOURCE_ID     # string; Numeric mstID for defaults (still cast as string). GUID for custom budgets.
BG_FUND_SOURCE_NAME          = 'name'                  # string
BG_FUND_SOURCE_STR_CONSTANT  = 'stringConstant'        # string
BG_FUND_SOURCE_CUSTOM        = 'custom'                # boolean

# funding source share rec
BG_FUND_SOURCE_SHARE_BUDGET_ID       = BG_F_BUDGET_ID         # string
BG_FUND_SOURCE_SHARE_MOD_ID          = BG_F_MOD_ID            # integer; Module code
BG_FUND_SOURCE_SHARE_IND_TYPE_ID     = BG_F_IND_TYPE_ID       # integer; Range of possible values depends on module.
BG_FUND_SOURCE_SHARE_IND_ID          = BG_F_IND_ID            # string
BG_FUND_SOURCE_SHARE_FW_ID           = BG_F_FUND_FW_ID        # string
BG_FUND_SOURCE_SHARE_FUND_SOURCE_ID  = BG_F_FUND_SOURCE_ID    # string
BG_FUND_SOURCE_SHARE_VALUE           = 'value'                # float         #??? 'values'             # list of float by year

BG_FUND_SOURCE_SHARE_DELIV_CHAN_ID   = BG_IC_F_DELIV_CHAN_ID  # string

BG_FUND_SOURCE_SHARE_COSTING_SECT_ID_PC         = BG_PC_F_COSTING_SECT_ID         # string; 
BG_FUND_SOURCE_SHARE_COSTING_SUBSECT_ID_PC      = BG_PC_F_COSTING_SUBSECT_ID      # string; 
BG_FUND_SOURCE_SHARE_ACT_ID_PC                  = BG_PC_F_ACT_ID                  # string; 
BG_FUND_SOURCE_SHARE_PROG_AREA_ID_PC            = BG_IH_F_PROG_AREA_ID            # string    

BG_FUND_SOURCE_SHARE_STAFF_LEVEL_ID_HW   = BG_F_STAFF_LEVEL_ID_HW    # int
BG_FUND_SOURCE_SHARE_COMPENS_TYPE_ID_HW  = BG_F_COMPENS_TYPE_ID_HW   # int

BG_FUND_SOURCE_SHARE_COSTING_SECT_HS_COSTING_ID         = BG_F_COSTING_SECT_HS_COSTING_ID      # string; 
BG_FUND_SOURCE_SHARE_COSTING_SUBSECT_HS_COSTING_ID      = BG_F_COSTING_SUBSECT_HS_COSTING_ID   # string; 
BG_FUND_SOURCE_SHARE_ACT_HS_COSTING_ID                  = BG_F_ACT_HS_COSTING_ID               # string; 
BG_FUND_SOURCE_SHARE_COSTING_SECT_HS_PROG_MGMT_ID       = BG_F_COSTING_SECT_HS_PROG_MGMT_ID    # string; 
BG_FUND_SOURCE_SHARE_COSTING_SUBSECT_HS_PROG_MGMT_ID    = BG_F_COSTING_SUBSECT_HS_PROG_MGMT_ID # string; 
BG_FUND_SOURCE_SHARE_ACT_HS_PROG_MGMT_ID                = BG_F_ACT_HS_PROG_MGMT_ID             # string; 

BG_FUND_SOURCE_SHARE_COSTING_SECT_GV_COSTING_ID         = BG_F_COSTING_SECT_GV_COSTING_ID      # string; 
BG_FUND_SOURCE_SHARE_COSTING_SUBSECT_GV_COSTING_ID      = BG_F_COSTING_SUBSECT_GV_COSTING_ID   # string; 
BG_FUND_SOURCE_SHARE_ACT_GV_COSTING_ID                  = BG_F_ACT_GV_COSTING_ID               # string; 
BG_FUND_SOURCE_SHARE_COSTING_SECT_GV_PROG_MGMT_ID       = BG_F_COSTING_SECT_GV_PROG_MGMT_ID    # string; 
BG_FUND_SOURCE_SHARE_COSTING_SUBSECT_GV_PROG_MGMT_ID    = BG_F_COSTING_SUBSECT_GV_PROG_MGMT_ID # string; 
BG_FUND_SOURCE_SHARE_ACT_GV_PROG_MGMT_ID                = BG_F_ACT_GV_PROG_MGMT_ID             # string; 

BG_FUND_SOURCE_SHARE_COSTING_SECT_HF_COSTING_ID         = BG_F_COSTING_SECT_HF_COSTING_ID      # string; 
BG_FUND_SOURCE_SHARE_COSTING_SUBSECT_HF_COSTING_ID      = BG_F_COSTING_SUBSECT_HF_COSTING_ID   # string; 
BG_FUND_SOURCE_SHARE_ACT_HF_COSTING_ID                  = BG_F_ACT_HF_COSTING_ID               # string; 
BG_FUND_SOURCE_SHARE_COSTING_SECT_HF_PROG_MGMT_ID       = BG_F_COSTING_SECT_HF_PROG_MGMT_ID    # string; 
BG_FUND_SOURCE_SHARE_COSTING_SUBSECT_HF_PROG_MGMT_ID    = BG_F_COSTING_SUBSECT_HF_PROG_MGMT_ID # string; 
BG_FUND_SOURCE_SHARE_ACT_HF_PROG_MGMT_ID                = BG_F_ACT_HF_PROG_MGMT_ID             # string; 