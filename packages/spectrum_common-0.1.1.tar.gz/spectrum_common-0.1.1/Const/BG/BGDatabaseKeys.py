#######################################################################################################
#                                                                                                     #
#                                       Budget DB (BDB)                                               #
#                                                                                                     #
#######################################################################################################

BG_COSTING_MODES_KEY_BDB    = 'costingModes'
BG_ENGLISH_STRING_KEY_BDB   = 'englishString'
BG_STRING_CONSTANT_KEY_BDB  = 'stringConst'  
BG_ID_KEY_BDB               = 'ID'

#######################################################################################################
#                                                                                                     #
#                                       Budget Category DB (BCDB)                                     #
#                                                                                                     #
#######################################################################################################

BG_COSTING_MODES_KEY_BCDB   = 'costingModes'
BG_BUDGET_ID_KEY_BCDB       = 'budgetID'
BG_ENGLISH_STRING_KEY_BCDB  = 'englishString'
BG_STRING_CONSTANT_KEY_BCDB = 'stringConst' 
BG_ID_KEY_BCDB              = 'ID'

#######################################################################################################
#                                                                                                     #
#                                       Indicator Mapping DB (IMDB)                                   #
#                                                                                                     #
#######################################################################################################

BG_BUDGET_ID_KEY_IMDB           = 'budgetID'
BG_COSTING_MODES_KEY_IMDB       = 'costingModes'
BG_MOD_ID_KEY_IMDB              = 'modID'
BG_COSTING_SECT_ID_KEY_IMDB     = 'costingSectID'
BG_COSTING_SUBSECT_ID_KEY_IMDB  = 'costingSubsectID'
BG_ACTIVITY_ID_KEY_IMDB         = 'activityID'
BG_IND_TYPE_IDS_KEY_IMDB        = 'indTypeIDs'
BG_IND_ID_KEY_IMDB              = 'indID'
BG_BUDGET_CAT_ID_KEY_IMDB       = 'budgetCatID'

#######################################################################################################
#                                                                                                     #
#                                       Funding Framework DB (FFWDB)                                  #
#                                                                                                     #
#######################################################################################################

BG_COSTING_MODES_KEY_FFWDB   = ''
BG_ENGLISH_STRING_KEY_FFWDB  = 'englishString'
BG_STRING_CONSTANT_KEY_FFWDB = 'stringConst' 
BG_ID_KEY_FFWDB              = 'ID'

#######################################################################################################
#                                                                                                     #
#                                       Funding Source DB (FSDB)                                      #
#                                                                                                     #
#######################################################################################################

BG_COSTING_MODES_KEY_FSDB   = 'costingModes'
BG_FUND_FW_ID_KEY_FSDB      = 'fundFrameworkID'
BG_ENGLISH_STRING_KEY_FSDB  = 'englishString'
BG_STRING_CONSTANT_KEY_FSDB = 'stringConst' 
BG_ID_KEY_FSDB              = 'ID'