# fmt: off
#######################################################################################################
#                                                                                                     #
#                                       Drug Supply DB (DSDB)                                         #
#                                                                                                     #
#######################################################################################################

IC_MST_ID_KEY_DSDB                       = 'mstID'
IC_CONSTANT_KEY_DSDB                     = 'constant'
IC_ENGLISH_STRING_KEY_DSDB               = 'englishString'
IC_STR_CONST_KEY_DSDB                    = 'stringConstant' 
IC_TYPE_MST_ID_KEY_DSCB                  = 'typeMstID'
IC_UNIT_COST_KEY_DSCB                    = 'unitCost'
IC_FAMILY_KEY_LG_DSCB                    = 'family'
IC_WEIGHT_KEY_LG_DSCB                    = 'weight'
IC_UOM_KEY_LG_DSCB                       = 'weightUOM'
IC_VOLUME_KEY_LG_DSCB                    = 'volume'
IC_VOLUME_UOM_KEY_LG_DSCB                = 'volumeUOM'
IC_FORECAST_ERROR_KEY_LG_DSCB            = 'forecastError'
IC_IMPORTANCE_KEY_LG_DSCB                = 'importance'
IC_NON_CRIT_FRACTION_KEY_LG_DSCB         = 'nonCriticalFraction'
IC_STD_FRACTION_KEY_LG_DSCB              = 'standardFraction'
IC_CRIT_FRACTION_KEY_LG_DSCB             = 'criticalFraction'
IC_COST_PER_PACK_KEY_LG_DSCB             = 'costPerPack'
IC_UNITS_PER_PACK_KEY_LG_DSCB            = 'unitsPerPack'
IC_COST_TYPE_MST_ID_KEY_LG_DSCB          = 'costTypeMstID'
IC_FAMILY_KEY_LG_DSCB                    = 'family'
IC_SOURCE_KEY_DSCB                       = 'source'
IC_PROG_AREA_FILTER_MST_IDS_KEY_DSCB     = 'progAreaFilterMstIDs'
IC_COLD_STORAGE_KEY_LG_DSDB              = 'requiresColdStorage'

#######################################################################################################
#                                                                                                     #
#                                       Treatment Input DB (TIDB)                                     #
#                                                                                                     #
#######################################################################################################

IC_INTERV_MST_ID_KEY_TIDB           = 'intervMstID'
IC_DELIV_CHAN_MST_ID_KEY_TIDB       = 'delivChanMstID'
IC_TREAT_INPUT_TYPE_MST_ID_KEY_TIDB = 'treatInputTypeMstID'
IC_GROUP_MST_ID_KEY_TIDB            = 'groupMstID'
IC_TREATMENT_INPUT_MST_ID_KEY_TIDB  = 'treatmentInputMstID'
IC_PERC_APPLIED_KEY_TIDB            = 'percApplied'
IC_NOTE_KEY_TIDB                    = 'note'
IC_NOTE_STR_CONST_KEY_TIDB          = 'noteStringConstant'
IC_NUM_ITEMS_KEY_TIDB               = 'numItems'
IC_TIMES_PER_DAY_MIN_KEY_TIDB       = 'timesPerDayOrMin'
IC_DAYS_PER_CASE_NUM_DAYS_KEY_TIDB  = 'daysPerCaseOrNumDays'
IC_UNITS_PER_CASE_PERSON_KEY_TIDB   = 'unitsPerCaseOrPerson'

# Normally we don't need these here, but we do if we want to access them outside of the Tools folder.

IC_INTERV_MST_ID_TAG_TIDB             = '<Intervention Master ID>'  
IC_INTERV_NAME_TAG_TIDB               = '<Intervention Name>'
IC_SPECIAL_CASE_TYPE_MST_IDS_TAG_TIDB = '<Special Case Type Master IDs>' # Currently just for LiST Costing, so ignoring
IC_DELIV_CHAN_MST_IDS_TAG_TIDB        = '<Delivery Channel Master IDs>'
IC_TREAT_INPUT_TYPE_MST_ID_TAG_TIDB   = '<Treatment Input Type Master ID>'
IC_GROUP_MST_ID_TAG_TIDB              = '<Group Master ID>'
IC_GROUP_NAME_TAG_TIDB                = '<Group Name>'
IC_GROUP_STR_CONST_TAG_TIDB           = '<Group String Constant>'
IC_INPUT_MST_ID_TAG_TIDB              = '<Input Master ID>'
IC_INPUT_NAME_TAG_TIDB                = '<Input Name>'
IC_PERC_REC_TREATED_BY_TAG_TIDB       = '<Percent Receiving or Percent Treated By>'
IC_NOTE_TAG_TIDB                      = '<Note>'
IC_NOTE_STR_CONST_TAG_TIDB            = '<Note String Constant>'
IC_NUM_ITEMS_TAG_TIDB                 = '<Number of Items>'
IC_TIMES_PER_DAY_MIN_TAG_TIDB         = '<Times per Day or Minutes>'
IC_DAYS_PER_CASE_NUM_DAYS_TAG_TIDB    = '<Days per Case or Number of Days>'
IC_UNITS_PER_CASE_PERSON_TAG_TIDB     = '<Units per Case or Units per Person>'

#######################################################################################################
#                                                                                                     #
#                                       Treatment Input GroupDB (TIGDB)                               #
#                                                                                                     #
#######################################################################################################

IC_INTERV_MST_ID_KEY_TIGDB           = 'intervMstID'
IC_DELIV_CHAN_MST_ID_KEY_TIGDB       = 'delivChanMstID'
IC_TREAT_INPUT_TYPE_MST_ID_KEY_TIGDB = 'treatInputTypeMstID'
IC_GROUP_MST_ID_KEY_TIGDB            = 'groupMstID'
IC_GROUP_NAME_KEY_TIGDB              = 'groupName'
IC_GROUP_STR_CONST_KEY_TIGDB         = 'groupStringConstant'

#######################################################################################################
#                                                                                                     #
#                                       PIN DB (PINDB)                                                #
#                                                                                                     #
#######################################################################################################

IC_ISO_ALPHA_3_COUNTRY_CODE_KEY_PINDB = 'ISO3AlphaCountryCode'
IC_INTERVENTION_LIST_KEY_PINDB        = 'interventions'

IC_INTERV_MST_ID_KEY_PINDB = 'intervMstID'
IC_PIN_KEY_PINDB           = 'PIN'

#######################################################################################################
#                                                                                                     #
#                                       PIN by Year DB (PbYDB)                                        #
#                                                                                                     #
#######################################################################################################

IC_ISO_ALPHA_3_COUNTRY_CODE_KEY_PbYDB = 'ISO3AlphaCountryCode'
IC_INTERVENTION_LIST_KEY_PbYDB        = 'interventions'

IC_INTERV_MST_ID_KEY_PbYDB = 'intervMstID'
IC_PIN_KEY_PbYDB           = 'PIN'
IC_FIRST_YEAR_KEY_PbYDB    = 'firstYear'
IC_FINAL_YEAR_KEY_PbYDB    = 'finalYear'

#######################################################################################################
#                                                                                                     #
#                                       Non Impact Coverage DB (NICDB)                                #
#                                                                                                     #
#######################################################################################################

IC_ISO_ALPHA_3_COUNTRY_CODE_KEY_NICDB = 'ISO3AlphaCountryCode'
IC_INTERVENTION_LIST_KEY_NICDB        = 'interventions'

IC_INTERV_MST_ID_KEY_NICDB  = 'intervMstID'
IC_NON_IMPACT_COV_KEY_NICDB = 'nonImpactCoverage'

#######################################################################################################
#                                                                                                     #
#                                       Non Impact Coverage DB (NbYDB)                                #
#                                                                                                     #
#######################################################################################################

IC_ISO_ALPHA_3_COUNTRY_CODE_KEY_NbYDB = 'ISO3AlphaCountryCode'
IC_INTERVENTION_LIST_KEY_NbYDB        = 'interventions'

IC_INTERV_MST_ID_KEY_NbYDB  = 'intervMstID'
IC_NON_IMPACT_COV_KEY_NbYDB = 'nonImpactCoverage'
IC_FIRST_YEAR_KEY_NbYDB     = 'firstYear'
IC_FINAL_YEAR_KEY_NbYDB     = 'finalYear'

#######################################################################################################
#                                                                                                     #
#                                       Target Population Direct Entry DB (TPDEDB)                    #
#                                                                                                     #
#######################################################################################################

IC_ISO_ALPHA_3_COUNTRY_CODE_KEY_TPDEDB = 'ISO3AlphaCountryCode'
IC_INTERVENTION_LIST_KEY_TPDEDB        = 'interventions'

IC_INTERV_MST_ID_KEY_TPDEDB = 'intervMstID'
IC_TARG_POP_KEY_TPDEDB      = 'targPop'

#######################################################################################################
#                                                                                                     #
#                                       Target Population DB (TPDB)                                   #
#                                                                                                     #
#######################################################################################################

IC_CONSTANT_KEY_TPDB                  = 'constant'
IC_MST_ID_KEY_TPDB                    = 'mstID'
IC_NAME_KEY_TPDB                      = 'name'
IC_STR_CONST_KEY_TPDB                 = 'stringConstant'
IC_APPLIC_PROG_AREA_IDS_IHT_KEY_TPDB  = 'applicProgAreaIDsIHT'
IC_APPLIC_PROG_AREA_IDS_TB_KEY_TPDB   = 'applicProgAreaIDsTB'
IC_APPLIC_PROG_AREA_IDS_LIST_KEY_TPDB = 'applicProgAreaIDsLiST'
IC_REQ_MOD_MST_IDS_KEY_TPDB           = 'reqModMstIDs'

#######################################################################################################
#                                                                                                     #
#                                       Adolescent Health PIN DB (AHPINDB)                            #
#                                                                                                     #
#######################################################################################################

#######################################################################################################
#                                                                                                     #
#                                       Adolescent Health Coverage DB (AHCDB)                         #
#                                                                                                     #
#######################################################################################################

#######################################################################################################
#                                                                                                     #
#                                       OutpatVisitInpatDayCostsDB (OVIDCTBDB)                          #
#                                                                                                     #
#######################################################################################################

IC_ISO_ALPHA_3_COUNTRY_CODE_KEY_OVIDCTBDB        = 'ISO3AlphaCountryCode'

IC_COST_PER_OUTPAT_VISIT_INPAT_DAY_KEY_OVIDCTBDB = 'costPerOutpatVisitInpatDay'

#######################################################################################################
#                                                                                                     #
#                                       OutpatVisitInpatDayCostsCSDB (OVIDCCSDB)                      #
#                                                                                                     #
#######################################################################################################

IC_ISO_ALPHA_3_COUNTRY_CODE_KEY_OVIDCCSDB  = 'ISO3AlphaCountryCode'

IC_OTHER_RECURRENT_COSTS_KEY_OVIDCCSDB     = 'otherRecurrentCosts'
IC_CAPITAL_COSTS_KEY_OVIDCCSDB             = 'capitalCosts'

#######################################################################################################
#                                                                                                     #
#                                       HealthSystemCostsDB (HSCDB)                                   #
#                                                                                                     #
#######################################################################################################

IC_ISO_ALPHA_3_COUNTRY_CODE_KEY_HSCDB              = 'ISO3AlphaCountryCode'

IC_SUPPLY_CHAIN_COST_PERC_COMMODITY_COST_KEY_HSCDB = 'supplyChainCostPercCommodityCost'
IC_INFRASTRUCTURE_INVESTMENT_RATIO_KEY_HSCDB       = 'infrastructureInvestmentRatio' 
IC_OTHER_TO_INVESTMENT_COSTS_RATIO_KEY_HSCDB       = 'otherToInvestmentCostsRatio'
IC_INCOME_LEVEL_KEY_HSCDB                          = 'incomeLevel'
IC_SUPPLY_CHAIN_STATUS_KEY_HSCDB                   = 'supplyChainStatus'
