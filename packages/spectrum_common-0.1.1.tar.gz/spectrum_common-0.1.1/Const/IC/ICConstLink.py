from SpectrumCommon.Const.IV.IVConst import *
from SpectrumCommon.Const.IV.IVDatabaseKeys import *

from SpectrumCommon.Const.IH.IHConst import *
from SpectrumCommon.Const.IH.IH_TI_ProgAreaIDs import *
from SpectrumCommon.Const.IH.IHModVarFields import *
from SpectrumCommon.Const.IH.IHTags import *

from SpectrumCommon.Const.CS.CSGroupIDs import *
from SpectrumCommon.Const.CS.CSInterventionIDs import *
from SpectrumCommon.Const.CS.CSTags import *
from SpectrumCommon.Const.CS.CSConst import *

from SpectrumCommon.Const.HW.HWConst import *
from SpectrumCommon.Const.HW.HWTags import *

from SpectrumCommon.Const.PC.PCTags import *
from SpectrumCommon.Const.PC.PCModVarFields import *

from SpectrumCommon.Const.DP.DPConst import *

from SpectrumCommon.Const.AM.AMTags import *

from SpectrumCommon.Const.FP.FPTags import *

#######################################################################################################
#                                                                                                     #
#                                      IV                                                             #
#                                                                                                     #
#######################################################################################################

IC_IV_IH_INTERVENTION_DB_CURR_VERSION = IV_IH_INTERVENTION_DB_CURR_VERSION
IC_IV_TI_INTERVENTION_DB_CURR_VERSION = IV_TI_INTERVENTION_DB_CURR_VERSION
IC_IV_CS_INTERVENTION_DB_CURR_VERSION = IV_CS_INTERVENTION_DB_CURR_VERSION
IC_IV_INTERVENTION_DB_NAME            = IV_INTERVENTION_DB_NAME

# Intervention DB (IDB)

IC_IV_MST_ID_KEY_IDB               = IV_MST_ID_KEY_IDB
IC_IV_ENGLISH_STRING_KEY_IH_IDB    = IV_ENGLISH_STRING_KEY_IDB
IC_IV_ROOT_CONSTANT_KEY_IDB        = IV_ROOT_CONSTANT_KEY_IDB
IC_IV_STRING_CONSTANT_KEY_IH_IDB   = IV_STRING_CONSTANT_KEY_IDB
IC_IV_GROUP_MST_ID_KEY_IH_IDB      = IV_GROUP_MST_ID_KEY_IDB
IC_IV_SUBGROUP_MST_ID_KEY_IH_IDB   = IV_SUBGROUP_MST_ID_KEY_IDB
IC_IV_INTERV_IMPACT_KEY_IDB        = IV_INTERV_IMPACT_KEY_IDB
IC_IV_SPECIAL_CASES_IH_KEY_IDB     = IV_SPECIAL_CASES_IH_KEY_IDB
IC_IV_PIN_STRING_CONSTANT_KEY_IDB  = IV_PIN_STRING_CONSTANT_KEY_IDB
IC_IV_TARG_POP_MST_ID_KEY_IDB      = IV_TARG_POP_MST_ID_KEY_IDB
IC_IV_PERC_DELIV_KEY_IDB           = IV_PERC_DELIV_KEY_IDB

#######################################################################################################
#                                                                                                     #
#                                      IH                                                             #
#                                                                                                     #
#######################################################################################################

IC_IH_DELIV_CHAN_ID = IH_DELIV_CHAN_ID

IC_IH_COMMUNITY_CHAN_CURR_ID             = IH_COMMUNITY_CHAN_CURR_ID
IC_IH_OUTREACH_CHAN_CURR_ID              = IH_OUTREACH_CHAN_CURR_ID           
IC_IH_PREHOSPITAL_EMERGENCY_CHAN_CURR_ID = IH_PREHOSPITAL_EMERGENCY_CHAN_CURR_ID
IC_IH_GEN_OUTPATIENT_SERV_CHAN_CURR_ID   = IH_GEN_OUTPATIENT_SERV_CHAN_CURR_ID
IC_IH_FIRST_REFERRAL_CHAN_CURR_ID        = IH_FIRST_REFERRAL_CHAN_CURR_ID
IC_IH_SEC_REFERRAL_CHAN_CURR_ID          = IH_SEC_REFERRAL_CHAN_CURR_ID
IC_IH_NUM_DEFAULT_DELIV_CHANS_COSTED     = IH_NUM_DEFAULT_DELIV_CHANS_COSTED
IC_IH_COMMUNITY_CHAN_CURR_ID_CS          = IH_COMMUNITY_CHAN_CURR_ID_CS
IC_IH_OUTREACH_CHAN_CURR_ID_CS           = IH_OUTREACH_CHAN_CURR_ID_CS
IC_IH_CLINICAL_CURR_ID_CS                = IH_CLINICAL_CURR_ID_CS
IC_IH_HOSPITAL_CHAN_CURR_ID_CS           = IH_HOSPITAL_CHAN_CURR_ID_CS
IC_IH_NUM_DEFAULT_DELIV_CHANS_COSTED_CS  = IH_NUM_DEFAULT_DELIV_CHANS_COSTED_CS

IC_IH_COMMUNITY_CHAN_MST_ID             = IH_COMMUNITY_CHAN_MST_ID
IC_IH_PREHOSPITAL_EMERGENCY_CHAN_MST_ID = IH_PREHOSPITAL_EMERGENCY_CHAN_MST_ID
IC_IH_GEN_OUTPATIENT_SERV_CHAN_MST_ID   = IH_GEN_OUTPATIENT_SERV_CHAN_MST_ID
IC_IH_FIRST_REFERRAL_CHAN_MST_ID        = IH_FIRST_REFERRAL_CHAN_MST_ID
IC_IH_SEC_REFERRAL_CHAN_MST_ID          = IH_SEC_REFERRAL_CHAN_MST_ID

IC_IH_ALL_PROG_AREAS_MST_ID             = IH_ALL_PROG_AREAS_MST_ID
IC_IH_NCD_MST_ID                        = IH_NCD_MST_ID                 
IC_IH_NTD_MST_ID                        = IH_NTD_MST_ID            
IC_IH_TB_MST_ID                         = IH_TB_MST_ID    

IC_IH_TBC_TB_MST_ID                     = IH_TI_IVG_TB_MST_ID

IC_IH_TI_PROG_AREA_MST_IDS              = IH_TI_PROG_AREA_MST_IDS
IC_CS_GROUP_MST_IDS                     = CS_GROUP_MST_IDS

IC_IH_DELIV_CHAN_RECORDS_TAG_V1         = IH_DELIV_CHAN_RECORDS_TAG_V1
IC_IH_PROG_AREA_RECORDS_TAG_V1          = IH_PROG_AREA_RECORDS_TAG_V1

IC_IH_MODULE_MST_ID                     = IH_MODULE_MST_ID

IC_IH_COMPREHENSIVE_PLAN                = IH_COMPREHENSIVE_PLAN
IC_IH_SPECIFIC_PLAN                     = IH_SPECIFIC_PLAN     

#######################################################################################################
#                                                                                                     #
#                                      HW                                                             #
#                                                                                                     #
#######################################################################################################

IC_HW_STAFF_TYPE_RECORDS_TAG_V1  = HW_STAFF_TYPE_RECORDS_TAG_V1
IC_HW_ADD_TO_TREAT_INPUTS_MST_ID = HW_ADD_TO_TREAT_INPUTS_MST_ID
IC_HW_NUM_STATIC_STAFF_TYPES     = HW_NUM_STATIC_STAFF_TYPES

#######################################################################################################
#                                                                                                     #
#                                      PC                                                             #
#                                                                                                     #
#######################################################################################################

IC_PC_COSTING_SECT_RECORDS_TAG_V1 = PC_COSTING_SECT_RECORDS_TAG

IC_PC_COSTING_SECT_ENTRY_MODE_CS = PC_COSTING_SECT_ENTRY_MODE_CS
IC_PC_COSTING_SECT_COSTS_CS      = PC_COSTING_SECT_COSTS_CS  

#######################################################################################################
#                                                                                                     #
#                                      DP                                                             #
#                                                                                                     #
#######################################################################################################

IC_DP_ALL_AGES     = GB_AllAges
IC_DP_AGE_0_TO_4   = GB_A0_4
IC_DP_AGE_10_TO_14 = GB_A10_14
IC_DP_AGE_15_TO_19 = GB_A15_19 
IC_DP_AGE_45_TO_49 = GB_A45_49
IC_DP_AGE_80_PLUS  = GB_A80_Up

IC_DP_NUM_NEED_COTRIM = DP_NumNeedCot
IC_DP_NUM_NEED_ART    = DP_NumNeedART

IC_DP_PER_CHILD_HIV_POS_COTRIM = DP_PerChildHIVPosCot

IC_DP_NUMBER_ = DP_Number
IC_DP_PERCENT = DP_Percent

#######################################################################################################
#                                                                                                     #
#                                      AM                                                             #
#                                                                                                     #
#######################################################################################################

IC_AM_AIDSDeathsNoARTSingleAgeTag = AM_AIDSDeathsNoARTSingleAgeTag
IC_AM_AIDSDeathsARTSingleAgeTag = AM_AIDSDeathsARTSingleAgeTag #Rob; AM_AIDSDeathsARTTagno longer exists, but comes from this other one

#######################################################################################################
#                                                                                                     #
#                                      CS                                                             #
#                                                                                                     #
#######################################################################################################

IC_CS_B_USER               = CS_bUser
IC_CS_DATA                 = CS_Data
IC_CS_AFFECT_FRACT         = CS_AffecFract
IC_CS_SYPHILIS_TREAT       = CS_SyphilisTreat
IC_CS_PRETERM_AGA          = CS_PreTermAGA
IC_CS_PRETERM_SGA          = CS_PreTermSGA
IC_CS_ZINC_DEFIC           = CS_ZincDefic
IC_CS_PROGESTERONE         = CS_Progesterone
IC_CS_TREAT_OF_BACTERIURIA = CS_TreatOfBacteriuria
IC_CS_STOP_SMOKING_EDUC    = CS_StopSmokingEduc
IC_CS_ASPIRIN_LOW_DOSE     = CS_AspirinLowDose
IC_CS_AGE_SUMMARY          = CS_AgeSummary
IC_CS_DIARRHEA             = CS_Diarrhea
IC_CS_MALARIA              = CS_Malaria
IC_CS_MEASLES              = CS_Measles
IC_CS_PNEUMONIA            = CS_Pneumonia
IC_CS_0_TO_1_MONTHS        = CS_0t1months
IC_CS_12_TO_24_MONTHS      = CS_12t24months
IC_CS_PRE_TERM_SGA         = CS_PreTermSGA
IC_CS_PRE_TERM_AGA         = CS_PreTermAGA
IC_CS_VIT_A_DEFIC          = CS_VitADefic

IC_CS_MstFamPlanInt        = CS_MstFamPlanInt
IC_CS_MstPercOnART         = CS_MstPercOnART

IC_CS_IV_AspirinLowDose_MST_ID     = CS_IV_AspirinLowDose_MST_ID
IC_CS_IV_StopSmokingEduc_MST_ID    = CS_IV_StopSmokingEduc_MST_ID
IC_CS_IV_TreatOfBacteriuria_MST_ID = CS_IV_TreatOfBacteriuria_MST_ID
#IC_CS_IV_Progesterone_MST_ID       = CS_IV_Progesterone_MST_ID

IC_CS_FoodInsecureTag          = CS_FoodInsecureTag
IC_CS_BirthTermResultTag       = CS_BirthTermResultTag
IC_CS_CoverageTag              = CS_CoverageTag
IC_CS_SAM_PINTag               = CS_SAM_PINTag
IC_CS_MAM_PINTag               = CS_MAM_PINTag
IC_CS_StatusAtBirthTag         = CS_StatusAtBirthTag
IC_CS_PercExposedFalciparumTag = CS_PercExposedFalciparumTag
IC_CS_NutrDeficTag             = CS_NutrDeficTag
IC_CS_IntervForBOTag           = CS_IntervForBOTag
IC_CS_AvgHouseholdSizeTag      = CS_AvgHouseholdSizeTag
IC_CS_SBResultsTag             = CS_SBResultsTag
IC_CS_PerCapitaIncTag          = CS_PerCapitaIncTag
IC_CS_SelectedIVSetTag         = CS_SelectedIVSetTag
IC_CS_IVInfoTag                = CS_IVInfoTag
IC_CS_SyphilisAmongWRATag      = CS_SyphilisAmongWRATag
IC_CS_EnterBFImproveDataTag    = CS_EnterBFImproveDataTag

IC_CS_ANC1Mode                 = CS_ANC1Mode
IC_CS_ANC4Mode                 = CS_ANC4Mode

IC_CS_Pentavalent_CCFI         = CS_Pentavalent_CCFI

IC_CS_MstDirectEntryOfBF       = CS_MstDirectEntryOfBF
IC_CS_MstBFPromotion           = CS_MstBFPromotion    
IC_CS_MstBFPromotionMode       = CS_MstBFPromotionMode

#######################################################################################################
#                                                                                                     #
#                                      FP                                                             #
#                                                                                                     #
#######################################################################################################

IC_FP_ActiveMethodsTag = FP_ActiveMethodsTag