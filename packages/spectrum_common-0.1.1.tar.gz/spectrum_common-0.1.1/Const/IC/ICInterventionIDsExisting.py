# Intervention IDs contained in this file belong to interventions that have been removed/replaced in the 
# intervention database and do not appear in new projections. The IDs are referenced at least once in the 
# codebase and need to remain in the code so that we can support existing projections.

# The file containing current intervention IDs is overwritten when generating a new database, so these IDs 
# must be stored here in a separate file as opposed to alongside the current intervention IDs.

IC_IV_PulmTBCaseFindPatInitHIVNegChildren_MST_ID = '571'
IC_IV_PulmTBCaseFindPatInitHIVNegAdults_MST_ID = '570'
IC_IV_ExtraPulmTBCaseFindPatInitHIVNegChildren_MST_ID = '573'
IC_IV_ExtraPulmTBCaseFindPatInitHIVNegAdults_MST_ID = '572'