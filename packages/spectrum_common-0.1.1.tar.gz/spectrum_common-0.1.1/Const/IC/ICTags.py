# Input ModVars

IC_VERSION_TAG_V1                                  = '<IC_Version_V1>'
IC_DATA_CHANGED_TAG_V1                             = '<IC_DataChanged_V1>'
IC_PROJ_VALID_TAG_V1                               = '<IC_ProjectionValid_V1>'
IC_PROJ_VALID_DATE_TAG_V1                          = '<IC_ProjectionValidDate_V1>'
IC_SHOW_ALL_YEARS_INTERV_COV_TAG_V1                = '<IC_ShowAllYearsIntervCov_V1>'
IC_SHOW_ALL_YEARS_INTERV_PIN_TAG_V1                = '<IC_ShowAllYearsIntervPIN_V1>'
IC_SHOW_ALL_FP_METHODS_INTERV_COV_TAG_V1           = '<IC_ShowAllFPMethodsIntervCov_V1>'
IC_ENTER_DET_PMTCT_DATA_TAG_V1                     = '<IC_EnterDetailedPMTCT_Data_V1>'
IC_ENTER_NET_AGE_DIST_PERC_TAG_V1                  = '<IC_EnterNetAgeDistribAsPerc_V1>'
IC_POST_TREAT_SURV_FOLLOW_UP_VIS_TAG_V1            = '<IC_PostTreatSurvFollowUpVisited_V1>'
IC_MAX_CUSTOM_DRUG_SUPP_MST_ID_TAG_V1              = '<IC_MaxCustomDrugSupplyMstID_V1>'
IC_COV_YEAR_BEF_BASE_YEAR_ITN_TAG_V1               = '<IC_CovYearBeforeBaseYearITN_V1>'
IC_NET_LIFETIME_ITN_TAG_V1                         = '<IC_NetLifetimeITN_V1>'
IC_AVG_NET_AGE_ITN_TAG_V1                          = '<IC_AvgNetAgeITN_V1>'
IC_NUM_PERC_NETS_BY_AGE_TAG_V1                     = '<IC_NumPercNetsByAge_V1>'
IC_DRUG_PRICE_ADJUST_TAG_V1                        = '<IC_DrugPriceAdjust_V1>'
IC_INTERV_RECORDS_TAG                              = '<IC_InterventionRecords_V4>' 
IC_TREAT_INPUT_DRUG_SUPPLY_RECORDS_TAG             = '<IC_TreatInputDrugSupplyRecords_V2>' # Treatment inputs = Intervention inputs     
IC_TREAT_INPUT_MED_PERSONNEL_RECORDS_TAG           = '<IC_TreatInputMedPersonnelRecords_V2>' # Medical personnel = Health providers      
IC_TREAT_INPUT_OUTPAT_INPAT_RECORDS_TAG            = '<IC_TreatInputOutpatInpatRecords_V2>'        
IC_TREAT_INPUT_GROUP_DRUG_SUPPLY_RECORDS_TAG       = '<IC_TreatInputGroupDrugSupplyRecords_V2>'     
IC_TREAT_INPUT_GROUP_MED_PERSONNEL_RECORDS_TAG     = '<IC_TreatInputGroupMedPersonnelRecords_V2>'   
IC_TREAT_INPUT_GROUP_OUTPAT_INPAT_RECORDS_TAG      = '<IC_TreatInputGroupOutpatInpatRecords_V2>'   
IC_INTERV_STRATUM_RECORDS_TAG_V1                   = '<IC_InterventionStratumRecords_V1>'
IC_DRUG_SUPPLY_RECORDS_TAG                         = '<IC_DrugSupplyRecords_V3>' 
IC_TARG_POP_RECORDS_TAG                            = '<IC_TargPopRecords_V1>'
IC_NEED_BRST_CNCR_TRT_FLLW_UP_TAG_V1               = '<IC_NeedBrstCncrTrtFllwUp_V1>'
IC_OWNER_USAGE_RATIO_ARRAY_ITN_TAG_V1              = '<IC_OwnerUsageRatioArrayITN_V1>'
IC_STRATA_INTERV_LIST_TAG_V1                       = '<IC_StrataIntervList_V1>'
IC_ALT_COV_LIST_TAG_V1                             = '<IC_AltCoverageList_V1>'
IC_ALT_PIN_AGE_GROUP_SET_1_LIST_TAG_V1             = '<IC_AltPINAgeGroupSet1List_V1>'
IC_ALT_PIN_AGE_GROUP_SET_2_LIST_TAG_V1             = '<IC_AltPINAgeGroupSet2List_V1>'    
IC_STRATUM_RECORDS_TAG_V1                          = '<IC_StratumRecords_V1>'
IC_OUTP_VISIT_INP_DAY_UNIT_COST_TAG_V1             = '<IC_OutpVisitInpDayUnitCost_V1>'
IC_NON_DEF_TARG_POPS_TAG_V1                        = '<IC_NonDefaultTargPops_V1>'
IC_VARY_TREATMENT_INPUTS_BY_TIME_TAG_V1            = '<IC_VaryTreatmentInputsByTime_V1>'
# by intervention in intervention records now IC_POP_IN_NEED_VISITED_TAG_V1                      = '<IC_PopInNeedVisited_V1>'
IC_FAM_PLAN_GOAL_TAG_V1                            = '<IC_FamPlanGoal_V1>'
IC_PERC_UNMET_NEED_COVERED_TAG_V1                  = '<IC_PercUnmetNeedCovered_V1>'

# Inputs - TB Costing

IC_INTERV_RECORDS_IHT_ID_INFO_ONLY_TB_TAG_V1 = '<IC_InterventionRecordsIHT_IDInfoOnly_V1>'

# Inputs - LiST Costing
                                                                                                                           
IC_OTHER_RECURRENT_COSTS_CS_TAG_V1                     = '<IC_OtherRecurrentCostsCS_V1>'
IC_CAPITAL_COSTS_CS_TAG_V1                             = '<IC_CapitalCostsCS_V1>'
IC_SUPPLY_CHAIN_COST_PERC_COMMODITY_COST_CS_TAG_V1     = '<IC_SupplyChainCostPercCommodityCostCS_V1>' # = 'Logistics'
IC_WASTAGE_CS_TAG_V1                                   = '<IC_WastageCS_V1>'
IC_INFRASTRUCTURE_INVESTMENT_CS_TAG_V1                 = '<IC_InfrastructureInvestmentCS_V1>' 
IC_INFRASTRUCTURE_ALLOC_PORTION_FOR_PROJ_CS_TAG_V1     = '<IC_InfrastructureAllocPortionForProjCS_V1>'
IC_RATIO_OTHER_HEALTH_SYSTEM_TO_INTERV_COSTS_CS_TAG_V1 = '<IC_RatioOtherHealthSystemToIntervCostsCS_V1>'
IC_HEALTH_SYSTEM_PROG_COSTS_SUM_CS_TAG_V1              = '<IC_HealthSystemProgrammeCostsSumCS_V1>'
IC_OTHER_HEALTH_SYSTEM_COSTS_VIS_CS_TAG_V1             = '<IC_OtherHealthSystemCostsVisitedCS_V1>'

IC_INCOME_LEVEL_CS_META_TAG_V1                         = '<IC_IncomeLevelCS_Meta_V1>'
IC_SUPPLY_CHAIN_STATUS_CS_META_TAG_V1                  = '<IC_SupplyChainStatusCS_Meta_V1>'

# Inputs - Comprehensive vs Specific (CVS) plan mode

IC_OUTPAT_INPAT_COSTS_CVS_TAG_V1                    = '<IC_OutpatInpatCostsCVS_V1>'

# Pre-result / Calculated ModVars

IC_DRUG_COST_PER_CASE_TAG_V1                       = '<IC_DrugCostPerCase_V1>'
IC_SUPPLY_COST_PER_CASE_TAG_V1                     = '<IC_SupplyCostPerCase_V1>'
IC_LABOR_COST_PER_CASE_TAG_V1                      = '<IC_LaborCostPerCase_V1>'
IC_MIN_PER_AVG_CASE_STATIC_STAFF_TAG_V1            = '<IC_MinPerAvgCaseDefaultStaff_V1>'
IC_MIN_PER_AVG_CASE_DYNAMIC_STAFF_TAG_V1           = '<IC_MinPerAvgCaseCustomStaff_V1>'
IC_INPATIENT_DAYS_PER_CASE_TAG_V1                  = '<IC_InpatientDaysPerCase_V1>'
IC_OUTPATIENT_VISITS_PER_CASE_TAG_V1               = '<IC_OutpatientVisitsPerCase_V1>'

# Output / Result ModVars

IC_RES_TARG_POPS_TAG_V1                                        = '<IC_ResTargetPopulations_V1>'
IC_RES_PEOPLE_NEEDING_SERVICES_TAG_V1                          = '<IC_ResPeopleNeedingServices_V1>'
IC_RES_NUM_SERVICES_TAG_V1                                     = '<IC_ResNumServices_V1>'
IC_RES_NUM_SERVICES_BY_DELIV_CHAN_TAG_V1                       = '<IC_ResNumServicesByDelivChan_V1>'
IC_RES_ADDIT_NUM_SERVICES_BY_DELIV_CHAN_TAG_V1                 = '<IC_ResAdditNumServicesByDelivChan_V1>'
IC_RES_ADDIT_NUM_SERVICES_TAG_V1                               = '<IC_ResAdditNumServices_V1>'
IC_RES_PERC_DELIV_THROUGH_CHAN_BY_YEAR_TAG_V1                  = '<IC_ResPercDeliveredThroughChanByYear_V1>'
IC_RES_DRUG_COSTS_TAG_V1                                       = '<IC_ResDrugCosts_V1>'
IC_RES_ADDIT_DRUG_COSTS_TAG_V1                                 = '<IC_ResAdditDrugCosts_V1>'
IC_RES_DRUG_COSTS_BY_YEAR_ONLY_TAG_V1                          = '<IC_ResDrugCostsByYearOnly_V1>'
IC_RES_SUPPLY_COSTS_TAG_V1                                     = '<IC_ResSupplyCosts_V1>'
IC_RES_ADDIT_SUPPLY_COSTS_TAG_V1                               = '<IC_ResAdditSupplyCosts_V1>'
IC_RES_SUPPLY_COSTS_BY_YEAR_ONLY_TAG_V1                        = '<IC_ResSupplyCostsByYearOnly_V1>'
IC_RES_ADDIT_DRUG_SUPPLY_COSTS_TAG_V1                          = '<IC_ResAdditDrugSupplyCosts_V1>'
IC_RES_STATIC_STAFF_TIME_REQ_BY_DELIV_CHAN_TAG_V1              = '<IC_ResStaffTimeReqByDelivChan_V1>'
IC_RES_STATIC_STAFF_TIME_REQ_BY_INTERV_TAG_V1                  = '<IC_ResStaffTimeReqByInterv_V1>'
IC_RES_STATIC_STAFF_TIME_REQ_BY_PROG_AREA_TAG_V1               = '<IC_ResStaffTimeReqByProgArea_V1>'
IC_RES_STATIC_STAFF_TIME_REQ_BY_PROG_AREA_DELIV_CHAN_TAG_V1    = '<IC_ResStaffTimeReqByProgAreaDelivChan_V1>'
IC_RES_DYNAMIC_STAFF_TIME_REQ_BY_DELIV_CHAN_TAG_V1             = '<IC_ResCustomStaffTimeReqByDelivChan_V1>'
IC_RES_DYNAMIC_STAFF_TIME_REQ_BY_INTERV_TAG_V1                 = '<IC_ResCustomStaffTimeReqByInterv_V1>' 
IC_RES_DYNAMIC_STAFF_TIME_REQ_BY_PROG_AREA_TAG_V1              = '<IC_ResCustomStaffTimeReqByProgArea_V1>'
IC_RES_DYNAMIC_STAFF_TIME_REQ_BY_PROG_AREA_DELIV_CHAN_TAG_V1   = '<IC_ResCustomStaffTimeReqByProgAreaDelivChan_V1>'
IC_RES_DRUG_UNITS_PER_AVG_CASE_TAG_V1               = '<IC_ResDrugUnitsPerAvgCase_V1>'
IC_RES_SUPPLY_UNITS_PER_AVG_CASE_TAG_V1             = '<IC_ResSupplyUnitsPerAvgCase_V1>'
IC_RES_DRUGS_REQUIRED_BY_DELIV_CHAN_TAG             = '<IC_ResDrugsRequired_V1>'
IC_RES_SUPPLIES_REQUIRED_BY_DELIV_CHAN_TAG          = '<IC_ResSuppliesRequired_V1>'
IC_RES_DRUGS_REQUIRED_BY_PROG_AREA_TAG              = '<IC_ResDrugsRequiredByProgArea_V1>'
IC_RES_SUPPLIES_REQUIRED_BY_PROG_AREA_TAG           = '<IC_ResSuppliesRequiredByProgArea_V1>'
IC_RES_OUTPAT_VISITS_INPAT_DAYS_TAG_V1              = '<IC_ResOutpatVisitsInpatDays_V1>'

# Outputs - Disease-specific costing (DSC), TB Costing, LiST Costing

IC_RES_LABOR_COSTS_DSC_TAG_V1                       = '<IC_ResLaborCostsDSC_V1>'

# Outputs - Disease-specific costing (DSC), TB Costing

#IC_OUTPAT_VISIT_INPAT_DAY_UNIT_COSTS_DSC_TAG_V1     = '<IC_OutpatVisitInpatDayUnitCostsDSC_V1>'
IC_RES_OUTPAT_VISIT_INPAT_DAY_COSTS_DSC_TAG_V1   = '<IC_ResOutpatVisitInpatDayCostsDSC_V1>'
IC_RES_LOG_SUPPLY_CHAIN_COSTS_TB_TAG             = '<IC_ResLogisticsSupplyChainCostsTB_V1>'
IC_RES_WASTAGE_COSTS_TB_TAG                      = '<IC_ResWastageCostsTB_V1>'

# Outputs - LiST Costing

IC_RES_OTHER_RECURRENT_COSTS_CS_TAG_V1           = '<IC_ResOtherRecurrentCostsCS_V1>'
IC_RES_CAPITAL_COSTS_CS_TAG_V1                   = '<IC_ResCapitalCostsCS_V1>'
IC_RES_PROGRAM_COSTS_CS_TAG_V1                   = '<IC_ResProgramCostsCS_V1>'
IC_RES_LOGISTICS_COSTS_CS_TAG_V1                 = '<IC_ResLogisticsCostsCS_V1>'
IC_RES_WASTAGE_COSTS_CS_TAG_V1                   = '<IC_ResWastageCostsCS_V1>'
IC_RES_INFRASTRUCTURE_INVESTMENT_COSTS_CS_TAG_V1 = '<IC_ResInfrastructureInvestmentCostsCS_V1>'
IC_RES_OTHER_HEALTH_SYSTEM_COSTS_CS_TAG_V1       = '<IC_ResOtherHealthSystemCostsCS_V1>'

IC_COSTS_BY_INT_CS_TAG_V1                        = '<IC_CostsByInt_V1>'
IC_DISC_SOCIAL_BENEFITS_BY_INT_CS_TAG_V1         = '<IC_DiscountedSocialBenefitsByInt_V1>'
IC_DISC_ECON_BENEFITS_BY_INT_CS_TAG_V1           = '<IC_DiscountedEconomicBenefitsByInt_V1>'
IC_DISC_INC_IN_EARN_REDUC_BY_INT_CS_TAG_V1       = '<IC_DiscIncInLifetimeEarnReducByInt_V1>'
IC_BCR_BY_INT_CS_TAG_V1                          = '<IC_BCRByInt_V1>'