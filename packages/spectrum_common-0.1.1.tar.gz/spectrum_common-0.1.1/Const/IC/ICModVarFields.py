# Fields used in IC ModVar data structures

# general fields for keeping ID fields consistent when relating records to each other and for use in result records

IC_F_INTERV_ID = "intervID"
IC_F_DELIV_CHAN_ID = "delivChanID"
IC_F_TREAT_INPUT_ID = "treatInputID"
IC_F_TREAT_INPUT_GROUP_ID = "treatInputGroupID"
IC_F_STATIC_STAFF_MST_ID = "defaultStaffTypeMstID"  # was defaultStaffMstID
IC_F_DYNAMIC_STAFF_MST_ID = "customStaffID"
IC_F_DRUG_SUPPLY_ID = "drugSupplyID"
IC_F_DRUG_SUPPLY_TYPE_MST_ID = "drugSupplyTypeMstID"
IC_F_YEAR = "year"
IC_F_VALUE = "value"
IC_F_APPLIC_PROG_AREA_IDS = "applicProgAreaIDs"
IC_F_CUSTOM_STAFF_TYPE = "customStaffType"

# target population records (contained within intervention list)

IC_TARG_POP_NAME = "name"  # string
IC_TARG_POP_MST_ID = "targPopMstID"  # integer
IC_TARG_POP_SEX = "sex"  # integer; 1 = male, 2 = female
IC_TARG_POP_START_AGE = "startAge"  # integer; 0-80
IC_TARG_POP_END_AGE = "endAge"  # integer; 0-80
IC_TARG_POP_DIRECT_ENTRY_VALUES = "directEntryValues"  # list of floats; by year

# target population default records (contain info about each target population)

IC_TARG_POP_DEF_NAME = "name"
IC_TARG_POP_DEF_STR_CONST = "stringConstant"
IC_TARG_POP_DEF_MST_ID = "defTargPopMstID"
IC_TARG_POP_DEF_APPLIC_PROG_AREA_IDS = IC_F_APPLIC_PROG_AREA_IDS
IC_TARG_POP_DEF_REQ_MOD_MST_IDS = "requiredModMstIDs"

# intervention records

IC_INTERV_ID = (
    IC_F_INTERV_ID  # string; numeric mstID for defaults (still cast as string). GUID for custom interventions.
)
IC_INTERV_STR_CONST = "stringConstant"  # string;  Defaults only. Ex: GB_stTetanusToxoid.
IC_INTERV_NAME = "name"  # string;  Holds custom name or overridden default name.
IC_INTERV_ACTIVE = "active"  # boolean; Is user using this item or not?
IC_INTERV_PROG_AREA_ID = "progAreaID"  # string;  ID from programme area records.
IC_INTERV_SUBGROUP_ID = "subgroupID"  # string;  ID from subgroup records.
IC_INTERV_IMPACT = "impact"  # boolean; yes = gets coverage from Impact module like LiST. No otherwise.
IC_INTERV_CUSTOM = "custom"  # boolean; user-entered = true; default = false.
IC_INTERV_SPECIAL_CASES = (
    "specialCases"  # list;    Flags (strings) that tell us if an intervention should have a special case applied to it
)
IC_INTERV_STRATIFYING = "stratifying"  # boolean;
IC_INTERV_COST_FOR_PHC = "costForPHC"  # boolean;
IC_INTERV_PIN_EDITOR_VISITED = "PIN_EditorVisited"  # boolean;
IC_INTERV_COVERAGE_CHANGED = "coverageChanged"  # boolean;
IC_INTERV_PIN_STR_CONSTANT = "PIN_StringConstant"  # string; from Intervention DB // not saved out to file on desktop
IC_INTERV_COVERAGE = "coverage"  # list of float; by year
IC_INTERV_TREAT_INPUT_NOT_REQ = "treatInputNotReq"  # 2d list of boolean; delivery channel x treatment input type
IC_INTERV_MAX_CUSTOM_TI_GROUP_MST_ID = (
    "maxCustomTIGroupMstID"  # 2d list of integer; delivery channel x treatment input type // 'purpose group'
)
# Moved these out because they were huge
# IC_INTERV_DRUG_COST_PER_CASE             = 'drugCostPerCase'             # 2d list of float; delivery channel x year
# IC_INTERV_SUPPLY_COST_PER_CASE           = 'supplyCostPerCase'           # 2d list of float; delivery channel x year
# IC_INTERV_MIN_PER_AVG_CASE_DEFAULT_STAFF = 'minPerAvgCaseDefaultStaff'   # 3d list of float; delivery channel x default staff type x year
# IC_INTERV_MIN_PER_AVG_CASE_CUSTOM_STAFF  = 'minPerAvgCaseCustomStaff'    # 3d list of float; delivery channel x custom staff type x year
# IC_INTERV_LABOR_COST_PER_CASE            = 'laborCostPerCase'            # 2d list of float; delivery channel x year
IC_INTERV_PIN = "PIN"  # list of float; by year
IC_INTERV_PERC_DELIV_THROUGH_CHAN = "percDelivThroughChan"  # 2d list of float; yearID x IC deliv channel
IC_INTERV_VISIT_COST_PER_CASE = "visitCostPerCase"  # 3d list of float; visit type x delivery channel x year
IC_INTERV_TARG_POP_REC = "targPopRec"  # targ pop dict

# Alternative coverage records

IC_ALT_COV_INTERV_ID = "intervID"
IC_ALT_COV_VALUE = "altCoverage"

# Alternative PIN age group set 1 records

IC_ALT_PIN_AGE_GROUP_SET_1_INTERV_ID = "intervID"
IC_ALT_PIN_AGE_GROUP_SET_1_VALUE = "PIN"

# Alternative PIN age group set 2 records

IC_ALT_PIN_AGE_GROUP_SET_2_INTERV_ID = "intervID"
IC_ALT_PIN_AGE_GROUP_SET_2_VALUE = "PIN"

# drug and supply records (NOT the same as treatment inputs but used to create drug and supply treatment inputs)

IC_DRUG_SUPPLY_ID = IC_F_DRUG_SUPPLY_ID  # string; numeric mstID for defaults (still cast as string). GUID for custom drugs and supplies.
IC_DRUG_SUPPLY_NAME = "name"  # string;  Holds custom name or overridden default name.
IC_DRUG_SUPPLY_STR_CONST = "stringConstant"  # string;  Defaults only.
IC_DRUG_SUPPLY_COST_TYPE_LG_MST_ID = "costTypeMstID"  # integer;
IC_DRUG_SUPPLY_ACTIVE = "active"  # boolean; Is user using this item or not?
IC_DRUG_SUPPLY_CUSTOM = "custom"  # boolean; user-entered = true; default = false.
IC_DRUG_SUPPLY_TYPE_MST_ID = IC_F_DRUG_SUPPLY_TYPE_MST_ID  # integer; 1 = drug, 2 = supply
IC_DRUG_SUPPLY_APPLIC_PROG_AREA_LIST = (
    IC_F_APPLIC_PROG_AREA_IDS  # list of programme area mstIDs for which the drug/supply should appear
)
IC_DRUG_SUPPLY_UNIT_COST = "unitCost"  # list of floats; by year
IC_DRUG_SUPPLY_LOG_SUPP_CHAIN_COSTS_PERC = "logisticsSupplyChainCostsPerc"  # int; TB app only
IC_DRUG_SUPPLY_WASTAGE_PERC = "wastagePerc"  # int; TB app only
# For Logistics
IC_DRUG_SUPPLY_PERC_WASTAGE = "percWastage"  # integer
IC_DRUG_SUPPLY_PERC_SAFETY_STOCK_NEEDED = "percSafetyStockNeeded"  # integer
IC_DRUG_SUPPLY_SAFETY_STOCK_BASELINE = "safetyStockBaseline"  # integer
IC_DRUG_SUPPLY_PERC_SAFETY_STOCK_REC = "percSafetyStockRecommended"  # 1d list of integer; by year
IC_DRUG_SUPPLY_QUANTITY = "quantity"  # 1d list of integer; by year
IC_DRUG_SUPPLY_UNIT_WEIGHT = "unitWeight"  # float
IC_DRUG_SUPPLY_UNIT_VOLUME = "unitVolume"  # float
IC_DRUG_SUPPLY_REQUIRES_COLD_STORAGE = "requiresColdStorage"

# treatment input group (TIG) records

IC_TIG_ID = (
    IC_F_TREAT_INPUT_GROUP_ID  # string; numeric mstID for defaults (still cast as string). GUID for custom groups
)
IC_TIG_INTERV_ID = IC_F_INTERV_ID  # string; numeric mstID for defaults (still cast as string). GUID for custom groups
IC_TIG_DELIV_CHAN_ID = (
    IC_F_DELIV_CHAN_ID  # string; numeric mstID for defaults (still cast as string). GUID for custom groups and supplies
)
IC_TIG_NAME = "name"  # string
IC_TIG_STR_CONST = "stringConstant"  # string;  Defaults only.

# treatment input (TI) record common fields

IC_TI_ID = (
    IC_F_TREAT_INPUT_ID  # string; (either a drug/supply ID, personnel ID, or outpatient visit/inpatient visit ID)
)
IC_TI_INTERV_ID = IC_F_INTERV_ID  # string; numeric mstID for defaults (still cast as string). GUID for custom groups
IC_TI_DELIV_CHAN_ID = (
    IC_F_DELIV_CHAN_ID  # string; numeric mstID for defaults (still cast as string). GUID for custom delivery channels
)
IC_TI_GROUP_ID = (
    IC_F_TREAT_INPUT_GROUP_ID  # string; numeric mstID for defaults (still cast as string). GUID for custom groups
)
IC_TI_PERC_APPLIED = "percApplied"  # float
IC_TI_NOTE = "note"  # string
IC_TI_NOTE_STR_CONST = "stringConstant"  # string;  Defaults only.

# treatment input drug and supply record fields

IC_TI_DRUG_SUPPLY_TIMES_PER_DAY = "timesPerDay"  # integer
IC_TI_DRUG_SUPPLY_DAYS_PER_CASE = "daysPerCase"  # integer
IC_TI_DRUG_SUPPLY_NUMBER = "number"  # integer

# treatment input medical personnel record fields

IC_TI_MED_PERSONNEL_CUSTOM_STAFF_TYPE = IC_F_CUSTOM_STAFF_TYPE  # boolean
IC_TI_MED_PERSONNEL_SKILLED_STAFF_COST = "skilledStaffCost"  # boolean; GCEA
IC_TI_MED_PERSONNEL_NUM_OF_DAYS = "numOfDays"  # integer
IC_TI_MED_PERSONNEL_MINUTES = "minutes"  # float

# treatment input outpatient visits and inpatient day record fields

IC_TI_OUTPAT_INPAT_UNITS_PER_CASE = "unitsPerCase"  # double
