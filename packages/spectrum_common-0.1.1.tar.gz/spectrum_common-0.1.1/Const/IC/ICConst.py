import SpectrumCommon.Const.IC.ICTargetPopulationIDs as ictpi

# These delivery channels get tacked on at the end of the IH delivery channels and cannot be changed by the user.
IC_WASH_CHAN_CURR_ID = 1
IC_OTHER_NON_HEALTH_CHAN_CURR_ID = 2
IC_PRIVATE_SECTOR_CHAN_CURR_ID = 3
IC_NUM_DELIV_CHANS = 3

# Constants reflecting which year user wants to display *)
IC_CURRENT_YEAR = 1
IC_TARGET_YEAR = 2
IC_NUM_YEAR_ENDPOINTS = IC_TARGET_YEAR

IC_OUTPATIENT_VISIT_CURR_ID = 1
IC_INPATIENT_DAY_CURR_ID = 2
IC_NUM_VISIT_TYPES = IC_INPATIENT_DAY_CURR_ID
IC_ALL_VISIT_TYPES = IC_NUM_VISIT_TYPES + 1

IC_OUTPATIENT_VISIT_MST_ID = 1
IC_INPATIENT_DAY_MST_ID = 2

# Database latest versions
IC_DRUG_SUPPLY_DB_CURR_VERSION = "V11"
IC_TREATMENT_INPUT_DB_CURR_VERSION = "V12"
IC_PIN_DB_CURR_VERSION = "V7"
IC_PIN_BY_YEAR_DB_CURR_VERSION = "V1"
IC_NON_IMPACT_COVERAGE_DB_CURR_VERSION = "V2"
IC_NON_IMPACT_COVERAGE_BY_YEAR_DB_CURR_VERSION = "V1"
IC_TARG_POP_DB_CURR_VERSION = "V13"
IC_TARG_POP_DIRECT_ENTRY_DB_CURR_VERSION = "V1"
IC_ADOLESCENT_HEALTH_PIN_DB_CURR_VERSION = "V1"
IC_ADOLESCENT_HEALTH_COV_DB_CURR_VERSION = "V1"
IC_OTHER_COSTS_DB_CURR_VERSION = "V1"
# Databases for TB
IC_OUTPAT_VISIT_INPAT_DAY_COSTS_TB_DB_CURR_VERSION = "V1"
# Databases for LiST Costing
IC_OUTPAT_VISIT_INPAT_DAY_COSTS_CS_DB_CURR_VERSION = "V3"
IC_HEALTH_SYSTEM_COSTS_DB_CURR_VERSION = "V1"
# Databases for calculated things created in ICProj
IC_DRUG_COST_PER_AVG_CASE_DB_CURR_VERSION = "V1"
IC_SUPPLY_COST_PER_AVG_CASE_DB_CURR_VERSION = "V1"
IC_MED_PERSONNEL_MIN_PER_AVG_CASE_DB_CURR_VERSION = "V1"

# Database names (also the names of the sheets in ICModData.xlsx)
IC_DRUG_SUPPLY_DB_NAME = "DrugSupplyDB"
IC_TREATMENT_INPUT_DB_NAME = "TreatmentInputDB"
IC_TREATMENT_INPUT_GROUP_DB_NAME = "TreatmentInputGroupDB"  # Derived from TreatmentInputDB in ICModData but written to separate file for ease of processing.
IC_PIN_DB_NAME = "PIN_DB"
IC_PIN_BY_YEAR_DB_NAME = "PIN_ByYearDB"
IC_NON_IMPACT_COVERAGE_DB_NAME = "NonImpactCoverageDB"
IC_NON_IMPACT_COVERAGE_BY_YEAR_DB_NAME = "NonImpactCoverageByYearDB"
IC_TARG_POP_DB_NAME = "TargPopDB"
IC_TARG_POP_DIRECT_ENTRY_DB_NAME = "TargPopDirectEntryDB"
IC_ADOLESCENT_HEALTH_PIN_DB_NAME = "AdolescentHealthPIN_DB"
IC_ADOLESCENT_HEALTH_COV_DB_NAME = "AdolescentHealthCovDB"
# Databases for TB
IC_OUTPAT_VISIT_INPAT_DAY_COSTS_TB_DB_NAME = "OutpatVisitInpatDayCostsTBDB"
# Databases for LiST Costing
IC_OUTPAT_VISIT_INPAT_DAY_COSTS_CS_DB_NAME = "OutpatVisitInpatDayCostsCSDB"
IC_HEALTH_SYSTEM_COSTS_DB_NAME = "HealthSystemCostsDB"
# Databases for calculated things created in ICProj
IC_DRUG_COST_PER_AVG_CASE_DB_NAME = "DrugCostPerAvgCaseDB"
IC_SUPPLY_COST_PER_AVG_CASE_DB_NAME = "SupplyCostPerAvgCaseDB"
IC_MED_PERSONNEL_MIN_PER_AVG_CASE_DB_NAME = "MedPersonnelMinPerAvgCase"

# Database directories for data by country. Files in these folders are named using the 3 letter iso country codes instead of the database names above.
IC_NON_IMPACT_COVERAGE_BY_YEAR_DB_DIR = r"NonImpactCoverageByYear\countries"
IC_NON_IMPACT_COVERAGE_DB_DIR = r"NonImpactCoverage\countries"
IC_PIN_BY_YEAR_DB_DIR = r"PINsByYear\countries"
IC_PIN_DB_DIR = r"PINs\countries"
IC_TARG_POP_DIRECT_ENTRY_DB_DIR = r"TargPopDirectEntry\countries"
IC_OUTPAT_VISIT_INPAT_DAY_COSTS_TB_DB_DIR = r"OutpatVisitInpatDayCostsTBDB\countries"
IC_OUTPAT_VISIT_INPAT_DAY_COSTS_CS_DB_DIR = r"OutpatVisitInpatDayCostsCSDB\countries"
IC_HEALTH_SYSTEM_COSTS_DB_DIR = r"HealthSystemCostsDB\countries"

IC_DRUG_CURR_ID = 1
IC_SUPPLY_CURR_ID = 2
IC_NUM_DRUG_SUPPLY_TYPES = IC_SUPPLY_CURR_ID

IC_DRUG_MST_ID = 1
IC_SUPPLY_MST_ID = 2

# Treatment input item type master IDs
IC_TI_ALL_TREAT_INPUT_TYPES_MST_ID = 0
IC_TI_DRUGS_SUPPLIES_MST_ID = 1
IC_TI_MED_PERSONNEL_TIME_MST_ID = 2
IC_TI_OUTPAT_VISITS_MST_ID = 3  # defunct
IC_TI_INPAT_DAYS_MST_ID = 4  # defunct
IC_TI_SUPPLIES_MST_ID = 5  # defunct
IC_TI_PERSONNEL_TIME_MST_ID = 6  # defunct
IC_TI_EQUIPMENT_MST_ID = 7  # defunct
IC_TI_OTHER_MST_ID = 8  # defunct
IC_TI_OUTPAT_VISITS_INPAT_DAYS_MST_ID = 9

IC_TI_TREAT_INPUT_TYPES = [
    IC_TI_DRUGS_SUPPLIES_MST_ID,
    IC_TI_MED_PERSONNEL_TIME_MST_ID,
    IC_TI_OUTPAT_VISITS_INPAT_DAYS_MST_ID,
]

IC_TP_INTERV_MST_ID = 1
IC_TP_TARG_POP_MST_ID = 2

# Age group 1: <50, 50-59, 60-69, 70+
IC_AGE_GROUP_1_LT_50_CURR_ID = 1
IC_AGE_GROUP_1_50_TO_59_CURR_ID = 2
IC_AGE_GROUP_1_60_TO_69_CURR_ID = 3
IC_AGE_GROUP_1_70_PLUS_CURR_ID = 4
IC_NUM_AGE_GROUPS_SET_1 = IC_AGE_GROUP_1_70_PLUS_CURR_ID

# Age group 2: 0-4, 5-14, 15-29, 30-44, 45-59, 60-69, 70-79, 80+
IC_AGE_GROUP_2_0_TO_4_CURR_ID = 1
IC_AGE_GROUP_2_5_TO_14_CURR_ID = 2
IC_AGE_GROUP_2_15_TO_29_CURR_ID = 3
IC_AGE_GROUP_2_30_TO_44_CURR_ID = 4
IC_AGE_GROUP_2_45_TO_59_CURR_ID = 5
IC_AGE_GROUP_2_60_TO_69_CURR_ID = 6
IC_AGE_GROUP_2_70_TO_79_CURR_ID = 7
IC_AGE_GROUP_2_80_PLUS_CURR_ID = 8
IC_NUM_AGE_GROUPS_SET_2 = IC_AGE_GROUP_2_80_PLUS_CURR_ID

# Intervention special cases constants

IC_CS_IMPACT = "<CS Impact>"  # Coverage for intervention comes from CS
IC_AM_IMPACT = "<AM Impact>"  # Coverage for intervention comes from AM
IC_RN_IMPACT = "<RN Impact>"  # Coverage for intervention comes from RN
IC_FP_IMPACT = "<FP Impact>"  # Coverage for intervention comes from FP
IC_TB_IMPACT = "<TB Impact>"  # Coverage for intervention comes from TB
IC_MA_IMPACT = "<MA Impact>"  # Coverage for intervention comes from MA
IC_NC_IMPACT = "<NC Impact>"  # Coverage for intervention comes from NC
IC_IS_PROG_MGMT = "<IS Programme Management>"
IC_RN_PC_HIV = "<RN PC HIV>"
IC_RN_STIS = "<RN STIs>"
IC_NOT_DELIV_MAIN_CHANNELS = (
    "<Not Delivered in Main Delivery Channels>"  # Not delivered in IH delivery channels, only IC delivery channels.
)
IC_BREAST_CANCER_TREATMENT = "<Breast Cancer Treatment>"
IC_TB_NOTIF_TREATMENT = "<TB Notification and Treatment>"
IC_CS_CHILDBIRTH = "<CS Childbirth>"
IC_PREG_WOMEN_MALARIA = "<Pregnant Women Malaria>"
IC_ITN_IRS_MALARIA = "<ITM and IRS Malaria>"
IC_MALARIA_PSEUDO_IMPACT = "<Malaria Pseudo Impact>"
IC_ART_SET_1 = "<ART Set 1>"
IC_ART_SET_2 = "<ART Set 2>"
IC_PC_MNS = "<NC PC MNS>"
IC_NC_CANCER = "<NC Cancer>"
IC_BASIC_INTENS_DEPRESSION = "<Basic Intensive Depression>"
IC_BASIC_INTENS_PSYCHOSIS = "<Basic Intensive Psychosis>"
IC_BASIC_INTENS_BIPOLAR = "<Basic Intensive Bipolar>"
IC_BASIC_INTENS_DEV_DISORDERS = "<Basic Intensive Developmental Disorders>"
IC_BASIC_INTENS_BEHAV_DISORDERS = "<Basic Intensive Behavioral Disorders>"
IC_PENTA_VACC = "<Pentavalent Vaccine>"
IC_CS_STANDARD_VACC = "<CS Standard Vaccines>"
IC_CS_DET_VACC = "<CS Detailed Vaccines>"
IC_DEV_MODE_VACC = "<CS Developer Mode Vaccines>"
IC_BREAST_CANCER_TR_PINS = "<Breast Cancer Treatment PINs>"
IC_WORKERS_HEALTH = "<Workers Health>"  # Intervention should only show up for Worker's Health mode.
IC_ADOLESCENT_HEALTH = "<Adolescent Health>"  # Intervention should only show up for Adolescent Health mode.
IC_TB_DAT_DISAG = "<TB DAT Disaggregate>"
IC_TB_DAT_AG = "<TB DAT Aggregate>"
IC_PHC = "<PHC>"  # Intervention should only show up for PHC mode.
IC_ALT_COVERAGE = "<Alternative Coverage>"
IC_HIDE_CONFIG = (
    "<Hide Configuration>"  # Hide intervention in configuration (where interventions are selected, added, etc.)
)
IC_HIDE_INPUT_OUTPUT_DATA = "<Hide Input Output Data>"  # Essentially show intervention as label everywhere.
IC_HIDE_INPUT_DATA = "<Hide Input Data>"  # Show intervention as label in inputs, with data next to it in results.
IC_HIDE_PINS = "<Hide PINs>"  # Hide intervention in PINs table.
IC_HIDE_TARG_POPS = "<Hide Target Populations>"  # Hide intervention in Target population table.
IC_HIDE_COVERAGES = "<Hide Coverages>"  # Hide intervention in Coverages table.
IC_LOCK_COVERAGES = "<Lock Coverages>"  # Lock intervention in Coverages table.
IC_HIDE_TREAT_INPUTS = "<Hide Treatment Inputs>"  # Hide intervention in Treatment inputs table.
IC_HIDE_DELIV_CHANNELS = "<Hide Delivery Channels>"  # Hide intervention in Delivery channels table.
IC_HIDE_RESULTS = "<Hide Results>"  # Hide intervention in IC results tables.
IC_CALC_PINS_ALL_YEARS_LOCKED = "<Calculate PINs for All Years, Locked>"  # PINs are calculated at all years but locked in table (cannot be changed).
IC_CALC_PINS_ALL_YEARS_OVERRIDE = "<Calculate PINs for All Years, Overridable>"  # PINs are calculated at all years, but user can override them in table.
IC_CALC_PINS_TWO_PLUS_LOCKED = (
    "<Calculate PINs for Year Two Forward>"  # PINs are calculated and locked from the second year forward.
)
IC_MULTIPLY_PINS_100 = "<Multiply PINs by 100>"  # PINs need to be multiplied by 100 in table.
IC_PINS_OVER_100 = "<PINs Over 100>"  # PINs can be > 100 in table.
IC_MALARIA_PINS = "<Malaria PINs>"

# Maximum number of custom interventions that the user can have.
IC_MaxCustomInterventions = 500

# Minimum master ID that a UHM custom intervention must have in order to
# avoid conflicting with the master IDs in MstIVDB.csv in IV and the
# minimum master ID that a LiST custom intervention must have.
IC_MinCustIntervMstID = 10000

# Target populations that use the number of services of various interventions in their calculation
IC_SERVICE_TARG_POPS = [
    ictpi.IC_TP_PAT_6_MO_ISON_RESIST_SHORTER_SEC_LINE_15_PLUS_MST_ID,
    ictpi.IC_TP_PAT_6_MO_ISON_RESIST_SHORTER_SEC_LINE_0_TO_14_MST_ID,
    ictpi.IC_TP_PAT_LONGER_REG_MDR_RR_TB_XDR_MST_ID,
    ictpi.IC_TP_PAT_6_MO_ISON_RESIST_SHORTER_SEC_LINE_MST_ID,
]

CPR_GOAL_CURR_ID = 1
UNMET_NEED_GOAL_CURR_ID = 2
NUM_FAM_PLAN_GOALS = 2

CPR_GOAL_MST_ID = 1
UNMET_NEED_GOAL_MST_ID = 2
