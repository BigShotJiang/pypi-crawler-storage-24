# Main transaction record fields

TR_TARGET = "target"  # string; Type of item to perform transaction on.
TR_COMMAND = "command"  # string; Type of transaction to perform.
TR_PARAMS = "params"  # Any; Put all parameters in here

# Params (P) for 'params' field of service call. Declare in TRConstLink and pull from the appropriate
# module if you can so we can stay consistent. If those fields don't exist in modules or we can use a single field for all modules (like in the
# case with 'name' or 'active'), declare them here instead.

TR_P_NAME = "name"  # string
TR_P_ACTIVE = "active"  # boolean
TR_P_INTERV_IDS = "intervIDs"  # list of string
TR_P_PROG_AREA_IDS = "progAreaIDs"  # list of string
TR_P_FACILITY_TYPE_IDS = "facilityTypeIDs"  # list of string
TR_P_GROUP_NAME = "groupName"  # string
TR_P_NEW_GROUP_ID = "newGroupID"  # string
TR_P_TREAT_INPUT_TYPE_MST_ID = "treatInputTypeMstID"  # integer
TR_P_DRUG_SUPPLY_NAME = "drugSupplyName"  # string
TR_P_UNIT_COST = "unitCost"  # float OR list of float
TR_P_UNIT_COST_YEAR = "unitCostYear"  # int
TR_P_FACILITY_EQUIP_TYPE_MST_ID = "facilityEquipTypeMstID"  # int
TR_P_MOD_ID = "modID"  # int
TR_P_VALUE = "value"  # Any
TR_P_FILE_TITLE = "fileTitle"  # string
TR_P_INTERV_DICT = "intervDict"  # dict where keys are intervID's
TR_P_LANGUAGE_ID = "languageID"  # int
TR_P_ADD_IND_TYPE_IDS = "additionalIndTypeIDs"  # list
TR_P_PPLI_PHASES_CHANGED = "PPLIPhasesChanged"  # 2d list of boolean (costing subsection x year)
TR_P_FIRST_YEAR_POP_FIVE_YEAR_AGE_GROUPS = "firstYearPopFiveYearAgeGroups"  # 2d list of int (sex x five year age group)
# TR_P_POLICY_POP_LEVEL_INTERV_ENTRY = 'policyPopLevelIntervEntry' # boolean

# ModVar tag record fields (contained within the TR_MOD_VAR_TAGS field))

TR_MV_MODULE = "module"
TR_MV_TAGS = "modvars"

# Transaction service fields

TR_PROJ_ID = "projID"  # string; returned by CreateProjection
TR_TRANSACTIONS = "transactions"  # list of transaction dicts
TR_CLIENT_MODULE_MOD_VAR_TAGS = "clientModvarList"  # Transaction Server will return all ModVars corresponding to this list of ModVar tags that were changed.

# Targets

TR_PROJECTION = "Projection"
TR_YEARS = "Years"
TR_INTERVENTIONS = "Interventions"
TR_PROG_AREAS = "ProgramAreas"
TR_PROG_AREA_SUBGROUPS = "ProgramAreaSubgroups"
TR_DELIV_CHANNELS = "DeliveryChannels"
TR_DELIV_CHAN_PACKS = "DeliveryChannelPackages"
TR_NAT_PROGRAMS = "NationalPrograms"
TR_DRUGS_SUPPLIES = "DrugsAndSupplies"
TR_FACILITY_TYPES = "FacilityTypes"
TR_FACILITY_EQUIPMENT = "FacilityEquipment"
TR_FACILITY_MED_EQUIP_GROUPS = "FacilityMedicalEquipmentGroups"
TR_VEHICLES_IS = "Vehicles"  # Should be VehicleTypesIS
TR_ICT_EQUIPMENT = "ICT_Equipment"
TR_STAFF_TYPES = "StaffTypes"
TR_ATTRITION_TYPES = "AttritionTypes"
TR_RETENTION_INCENTIVES = "RetentionIncentives"
TR_TREATMENT_INPUTS = "TreatmentInputs"
TR_TREATMENT_INPUT_GROUPS = "TreatmentInputGroups"
TR_TREATMENT_INPUT_CALCS_IC = "TreatmentInputCalcsIC"
TR_POP_AND_COV_CALCS_IC = "PopulationAndCoverageCalcsIC"
TR_COST_PER_CASE_CALC_IC = "CostPerCaseIC"
TR_MIN_PER_AVG_CASE_CALC_IC = "MinutesPerAvgCaseIC"
TR_INPAT_DAYS_OUTPAT_VISITS_PER_CASE_CALC_IC = "InpatDaysOutpatVisitsPerCaseIC"
TR_PIN_CALC_IC = "PopInNeedIC"
TR_TRANSFER_COV_TO_IMPACT_MODS_CALC_IC = "TransferCoveragesToImpactModulesIC"
TR_TRANSFER_COV_TO_IHT_CALC_IC = "TransferCoveragesToIHT_IC"
TR_COST_CATS_PC = "CostCategoriesPC"
TR_COST_INPUTS_PC = "CostInputsPC"
TR_COSTING_SECT_PC = "CostingSectionsPC"
TR_COSTING_SUBSECT_PC = "CostingSubsectionsPC"
TR_ACTIVITIES_PC = "ActivitiesPC"
TR_ACT_LINE_ITEMS_PC = "ActivityLineItemsPC"
TR_TOTAL_EQUIP_COSTS_IS = "TotalEquipmentCostsIS"
TR_BUDGETS = "Budgets"
TR_BUDGET_CATS = "BudgetCategories"
TR_BUDGET_CAT_SHARES = "BudgetCategoryShares"
TR_FUND_FRAMEWORKS = "FundingFrameworks"
TR_FUND_SOURCES = "FundingSources"
TR_FUND_SOURCE_SHARES = "FundingSourceShares"
TR_BUDGET_INDICATORS = "BudgetIndicators"
TR_QUICK_MAPPING = "QuickMapping"
TR_HEALTH_SYS_ADMIN_UNITS = "HealthSystemAdminUnits"
TR_TAXATION_CALC_PC = "TaxationCalcPC"
TR_PHASE_INTENSITY_CALC_PC = "PhaseIntensityCalcPC"
TR_TAX_PHASE_INTENS_CALCS_PC = "TaxationPhaseIntensityCalcsPC"
TR_POP_DP = "PopulationDP"
TR_SUPPLY_CHAIN_LEVELS = "SupplyChainLevels"
TR_WAREHOUSES = "Warehouses"
TR_THIRD_PARTY_LOG_CONTRACTS = "ThirdPartyLogisticsContracts"
TR_VEHICLE_TYPES_LG = "VehicleTypesLG"
TR_WORKER_TYPES_LG = "WorkerTypesLG"
TR_COLD_CHAIN_LG = "ColdChainLG"
TR_CALC_VEHICLE_TARGETS_LG = "CalcVehicleTargetsLG"
TR_CALC_WORKER_TARGETS_LG = "CalcWorkerTargetsLG"
TR_CALC_COLD_CHAIN_TARGETS_LG = "CalcColdChainTargetsLG"
TR_INITIALIZE_VEHICLE_TARGETS_LG = "InitializeVechileTargetsLG"
TR_INITIALIZE_WORKER_TARGETS_LG = "InitializeWorkerTargetsLG"
TR_INITIALIZE_COLD_CHAIN_TARGETS_LG = "InitializeColdChainTargetsLG"
TR_CALC_VEHICLE_TARGETS_ALL_LG = "CalcVehicleTargetsAllLG"
TR_CALC_WORKER_TARGETS_ALL_LG = "CalcWorkerTargetsAllLG"
TR_CALC_COLD_CHAIN_TARGETS_ALL_LG = "CalcColdChainTargetsAllLG"


# Commands, Generic

TR_CREATE = "Create"  # Create/Add new item. (custom only)
TR_CREATE_MULTIPLE = "CreateMultiple"  # Create batches of items in one shot (custom only)
TR_MANAGE_MULTIPLE = "ManageMultiple"  # Creates and/or deletes batches of items in one shot
TR_RENAME = "Rename"  # Change name of item.
TR_DELETE = "Delete"  # Delete item (custom only).
TR_ACTIVATE = "Activate"  # Set one item active.
TR_ACTIVATE_ALL = "ActivateAll"  # Set all items active.
TR_DEACTIVATE = "Deactivate"  # Set one item inactive.
TR_DEACTIVATE_ALL = "DeactivateAll"  # Set all items inactive.
TR_MOVE = "Move"  # Move item(s).
TR_CHANGE = "Change"  # For increasing/decreasing years.
TR_COPY = "Copy"  # Copy items
TR_CALC = "Calculate"  # Calculate something and fill ModVar(s)
TR_SET_TESTING_DEFAULTS = "SetTestingDefaults"  # Set default values for testing a projection.
TR_TEST_TRANSACTIONS = "TestTransactions"  # Run one or more transaction test(s)
TR_GENERATE_FILE = "GenerateFile"  # Generate file.
TR_CHANGE_LANGUAGE = (
    "ChangeLanguage"  # Updates the name of all non-custom server strings depending on the language passed to it.
)
TR_UPDATE_STRINGS = "UpdateStrings"  # Updates all string constants to the latest.
TR_RELOAD_DEFAULTS = "ReloadDefaultValues"  # Reload default values

# Commands, Special/non-generic

TR_SET_STAFF_DIVISION = "SetStaffDivision"  # target: TR_STAFF_TYPES only. Set staff type's staff division
TR_SET_STAFF_DEF_MAP = "SetStaffDefaultMapping"  # target: TR_STAFF_TYPES only. Set staff type's default staff mapping.
TR_SET_FACIL_SUPP_TYPE = "SetFacilitySupportType"  # target: TR_FACILITY_TYPES only. Set facility type's support type.
TR_SET_FACIL_DELIV_CHAN = (
    "SetFacilityDeliveryChannel"  # target: TR_FACILITY_TYPES only. Set facility type's delivery channel.
)
TR_SET_FACIL_DEF_MAP = (
    "SetFacilityDefaultMapping"  # target: TR_FACILITY_TYPES only. Set facility type's default facility mapping.
)
TR_SET_FACIL_EQUIP_TOTAL_COST = (
    "SetFacilityTotalEquipmentCost"  # target: TR_FACILITY_TYPES only. Set total equipment cost.
)
TR_SET_FACIL_MED_EQUIP_LISTS = "SetFacilityMedicalEquipmentLists"  # target: TR_FACILITY_TYPES only. Loads initial facility equipment lists for one or more facilities.
TR_SET_INTERV_PARAMS_MULTIIPLE = "SetInterventionParametersMultiple"  # target: TR_INTERVENTIONS only. Set multiple parameters at once for an intervention.
TR_SET_INTERV_PROG_AREA = (
    "SetInterventionProgramArea"  # target: TR_INTERVENTIONS only. Set intervention's programme area.
)
TR_SET_INTERV_SUBGROUP = "SetInterventionSubgroup"  # target: TR_INTERVENTIONS only. Set intervention's subgroup.
TR_SET_INTERV_ACTIVE_FROM_CS = "SetInterventionsActiveFromCS"  # target: TR_INTERVENTIONS only. Set intervention's active status based on LiST's 'selected' status.
TR_SET_INTERV_ACTIVE_FROM_FP = "SetInterventionsActiveFromFP"  # target: TR_INTERVENTIONS only. Set intervention's active status based on FamPlan's active methods MV.
TR_SET_DRUG_SUPP_PARAMS_MULTIPLE = "SetDrugSupplyParametersMultiple"  # target: TR_DRUGS_SUPPLIES only. Set multiple parameters at once for a drug/supply.
TR_SET_BUDGET_FUNDING_FRAMEWORKS = "SetBudgetFundingFrameworks"  # target: TR_BUDGETS only. Sets the funding framework for all budgets to the one of the budget ID specified.
TR_SET_IND_BUDGET_CAT = "SetIndicatorBudgetCategory"  # target: TR_BUDGET_INDICATORS only.
TR_SET_IND_FUND_SOURCE = "SetIndicatorFundingSource"  # target: TR_BUDGET_INDICATORS only.
TR_SET_BUDGET_CATS_UNALLOCATED = "SetIndicatorBudgetCategoriesUnallocated"  # target: TR_BUDGET_INDICATORS only. Sets all indicator mappings to Unallocated.
TR_SET_FUND_SOURCES_UNALLOCATED = "SetIndicatorFundingSourcesUnallocated"  # target: TR_BUDGET_INDICATORS only. Sets all indicator mappings to Unallocated.
TR_SET_COVERAGES = "SetCoverages"  # target: TR_INTERVENTIONS only. Set one or more intervention coverages.
TR_SET_QUICK_MAPPING = "SetQuickMapping"  # target : TR_QUICK_MAPPING only.  Sets quick mapping on/off
TR_SPLIT_FIRST_YEAR_POP = (
    "SplitFirstYearPop"  # target : TR_POP_DP only. Splits first year pop by five year age groups into single year ages
)
TR_SET_NUM_SUPPLY_CHAIN_LEVELS = "SetNumSupplyChainLevels"  # target:
