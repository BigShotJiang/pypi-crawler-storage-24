# #######################################################################################################
# #                                                                                                     #
# #                                       Facility Equipment Inputs DB (FEIDB)                          #
# #                                                                                                     #
# #######################################################################################################

# IS_MOD_ID_KEY_FEIDB                     = '<Module ID>'
# IS_MOD_NAME_KEY_FEIDB                   = '<Module Name>'
# IS_FACILITY_TYPE_MST_ID_KEY_FEIDB       = '<Facility Type Master ID>'
# IS_FACILITY_TYPE_NAME_ID_KEY_FEIDB      = '<Facility Type Name>'
# IS_GROUP_MST_ID_KEY_FEIDB               = '<Group Master ID>'
# IS_GROUP_NAME_ID_KEY_FEIDB              = '<Group Name>'
# IS_GROUP_STR_CONST_KEY_FEIDB            = '<Group String Constant>'
# IS_FACILITY_EQUIP_TYPE_MST_ID_KEY_FEIDB = '<Facility Equipment Type Master ID>'
# IS_EQUIP_MST_ID_KEY_FEIDB               = '<Equipment Master ID>'
# IS_EQUIP_NAME_MST_ID_KEY_FEIDB          = '<Equipment Name>'
# IS_EQUIP_STR_CONST_KEY_FEIDB            = '<Equipment String Constant>'
# IS_UNIT_COST_KEY_FEIDB                  = '<Unit Cost>'
# IS_UNITS_PER_FACILITY_TYPE_KEY_FEIDB    = '<Units per Facility Type>'

#######################################################################################################
#                                                                                                     #
#                                     Cold Chain Records DB                                           #
#                                                                                                     #
#######################################################################################################

LG_COLD_CHAIN_ID_KEY = "coldChainID"
LG_COLD_CHAIN_TYPE_KEY = "coldChainType"
LG_COLD_CHAIN_NAME_KEY = "name"
LG_COLD_CHAIN_UNIT_COST_KEY = "unitCost"
LG_COLD_CHAIN_CAPACITY_KEY = "capacity"
