import SpectrumCommon.Const.LG.LGModVarFields as lgmvf

# =========================
# Global
# =========================

# Database latest versions
LG_COLD_CHAIN_DB_CURR_VERSION = "V2"

# Database names (also the names of the sheets in LGModData.xlsx)
LG_COLD_CHAIN_DB_NAME = "ColdChainDB"

# Disaggregation options
LG_NATIONAL_NO_DISAGGREGATION = 0

# Calculation approaches
LG_CALC_APPROACH_COSTING_MST_ID = 1
LG_CALC_APPROACH_VOLUME_MST_ID = 2

# Target configuration options
# Set globally as a modvar for vehicles/cold chain and individually for worker records
# Used to determine how to process scale up in calculation transactions

LG_TARGET_CONFIG_WAREHOUSE_STD_MST_ID = 1
LG_TARGET_CONFIG_EXISTING_PLANS_MST_ID = 2
LG_TARGET_CONFIG_VEHICLE_STD_MST_ID = 3

# =========================
# Supply chain levels
# =========================

# Default supply chain levels
LG_WL_CENTRAL_MST_ID = 1
LG_WL_PROVINCIAL_MST_ID = 2
LG_WL_DISTRICT_MST_ID = 3
LG_WL_FACILITY_MST_ID = 4

LG_DEFAULT_SUPPLY_CHAIN_LEVELS = [
    {
        lgmvf.LG_SUPPLY_CHAIN_LEVEL_ID: LG_WL_CENTRAL_MST_ID,
        lgmvf.LG_SUPPLY_CHAIN_LEVEL_NAME: "Central",
        lgmvf.LG_SUPPLY_CHAIN_LEVEL_STR_CONST: "GB_stCentral",
    },
    {
        lgmvf.LG_SUPPLY_CHAIN_LEVEL_ID: LG_WL_PROVINCIAL_MST_ID,
        lgmvf.LG_SUPPLY_CHAIN_LEVEL_NAME: "Provincial",
        lgmvf.LG_SUPPLY_CHAIN_LEVEL_STR_CONST: "GB_stProvincial",
    },
    {
        lgmvf.LG_SUPPLY_CHAIN_LEVEL_ID: LG_WL_DISTRICT_MST_ID,
        lgmvf.LG_SUPPLY_CHAIN_LEVEL_NAME: "District",
        lgmvf.LG_SUPPLY_CHAIN_LEVEL_STR_CONST: "GB_stDistrict",
    },
    {
        lgmvf.LG_SUPPLY_CHAIN_LEVEL_ID: LG_WL_FACILITY_MST_ID,
        lgmvf.LG_SUPPLY_CHAIN_LEVEL_NAME: "Facility",
        lgmvf.LG_SUPPLY_CHAIN_LEVEL_STR_CONST: "GB_stFacility",
    },
]

LG_NUM_DEF_SUPPLY_CHAIN_LEVELS = len(LG_DEFAULT_SUPPLY_CHAIN_LEVELS)

# =========================
# Warehouses
# =========================

# Warehouse types
LG_WAREHOUSE_TYPE_EXISTING_MST_ID = 1
LG_WAREHOUSE_TYPE_NEW_MST_ID = 2

# =========================
# Vehicles
# =========================

# Default vehicles
LG_VT_4X4_VEHICLE_MST_ID = 1
LG_VT_SMALL_TRUCK_MST_ID = 2
LG_VT_LARGE_TRUCK_MST_ID = 3

LG_DEFAULT_VEHICLE_TYPES = [
    {
        lgmvf.LG_VEHICLE_TYPE_ID: LG_VT_4X4_VEHICLE_MST_ID,
        lgmvf.LG_VEHICLE_TYPE_NAME: "4x4 vehicle",
        lgmvf.LG_VEHICLE_TYPE_STR_CONST: "GB_st4x4Vehicle",
    },
    {
        lgmvf.LG_VEHICLE_TYPE_ID: LG_VT_SMALL_TRUCK_MST_ID,
        lgmvf.LG_VEHICLE_TYPE_NAME: "Small truck",
        lgmvf.LG_VEHICLE_TYPE_STR_CONST: "GB_stSmallTruck",
    },
    {
        lgmvf.LG_VEHICLE_TYPE_ID: LG_VT_LARGE_TRUCK_MST_ID,
        lgmvf.LG_VEHICLE_TYPE_NAME: "Large truck",
        lgmvf.LG_VEHICLE_TYPE_STR_CONST: "GB_stLargeTruck",
    },
]

LG_PERFORMANCE_CONFIG_OPTION_ROUTE_BASED = 1
LG_PERFORMANCE_CONFIG_OPTION_TRIP_BASED = 2


# =========================
# Workers
# =========================

# Default workers

LG_WT_WAREHOUSE_WORKER_MST_ID = 1
LG_WT_DRIVER_MST_ID = 2
LG_WT_MECHANIC_MST_ID = 3
LG_WT_SUPERVISOR_MST_ID = 4
LG_WT_WAREHOUSE_MANAGER_MST_ID = 5

LG_DEFAULT_WORKER_TYPES = [
    {
        lgmvf.LG_WORKER_TYPE_ID: LG_WT_WAREHOUSE_WORKER_MST_ID,
        lgmvf.LG_WORKER_TYPE_NAME: "Warehouse worker",
        lgmvf.LG_WORKER_TYPE_STR_CONST: "GB_stWarehouseWorker",
    },
    {
        lgmvf.LG_WORKER_TYPE_ID: LG_WT_DRIVER_MST_ID,
        lgmvf.LG_WORKER_TYPE_NAME: "Driver",
        lgmvf.LG_WORKER_TYPE_STR_CONST: "GB_stDriver",
    },
    {
        lgmvf.LG_WORKER_TYPE_ID: LG_WT_MECHANIC_MST_ID,
        lgmvf.LG_WORKER_TYPE_NAME: "Mechanic",
        lgmvf.LG_WORKER_TYPE_STR_CONST: "GB_stMechanic",
    },
    {
        lgmvf.LG_WORKER_TYPE_ID: LG_WT_SUPERVISOR_MST_ID,
        lgmvf.LG_WORKER_TYPE_NAME: "Supervisor",
        lgmvf.LG_WORKER_TYPE_STR_CONST: "GB_stSupervisor",
    },
    {
        lgmvf.LG_WORKER_TYPE_ID: LG_WT_WAREHOUSE_MANAGER_MST_ID,
        lgmvf.LG_WORKER_TYPE_NAME: "Warehouse manager",
        lgmvf.LG_WORKER_TYPE_STR_CONST: "GB_stWarehouseManager",
    },
]

LG_WORKER_CLASSIFICATION_OTHER = 1
LG_WORKER_CLASSIFICATION_DRIVER = 2
LG_WORKER_CLASSIFICATION_STOCK_MOVER = 3


# =========================
# Cold chain
# =========================

# Cold chain types
LG_COLD_CHAIN_TYPE_STORAGE_MST_ID = 1
LG_COLD_CHAIN_TYPE_TRANSPORT_MST_ID = 2
LG_COLD_CHAIN_TYPE_ACCESSORIES_MST_ID = 3

# Default cold chain records
LG_DEFAULT_COLD_CHAIN_RECORDS = [
    # Storage
    {
        lgmvf.LG_COLD_CHAIN_ID: 1,
        lgmvf.LG_COLD_CHAIN_UNIT_COST: 32813,
        lgmvf.LG_COLD_CHAIN_NAME: "Walk in cold room / freezer room",
        lgmvf.LG_COLD_CHAIN_STR_CONST: "",
        lgmvf.LG_COLD_CHAIN_CAPACITY: 29.7,
        lgmvf.LG_COLD_CHAIN_TYPE: LG_COLD_CHAIN_TYPE_STORAGE_MST_ID,
    },
    {
        lgmvf.LG_COLD_CHAIN_ID: 2,
        lgmvf.LG_COLD_CHAIN_UNIT_COST: 4798,
        lgmvf.LG_COLD_CHAIN_NAME: "Solar direct drive refrigerator",
        lgmvf.LG_COLD_CHAIN_STR_CONST: "",
        lgmvf.LG_COLD_CHAIN_CAPACITY: 0.13,
        lgmvf.LG_COLD_CHAIN_TYPE: LG_COLD_CHAIN_TYPE_STORAGE_MST_ID,
    },
    {
        lgmvf.LG_COLD_CHAIN_ID: 3,
        lgmvf.LG_COLD_CHAIN_UNIT_COST: 6987,
        lgmvf.LG_COLD_CHAIN_NAME: "Solar direct drive freezer",
        lgmvf.LG_COLD_CHAIN_STR_CONST: "",
        lgmvf.LG_COLD_CHAIN_CAPACITY: 0.07,
        lgmvf.LG_COLD_CHAIN_TYPE: LG_COLD_CHAIN_TYPE_STORAGE_MST_ID,
    },
    {
        lgmvf.LG_COLD_CHAIN_ID: 4,
        lgmvf.LG_COLD_CHAIN_UNIT_COST: 2722.6,
        lgmvf.LG_COLD_CHAIN_NAME: "Ice-lined refrigerator (ILR)",
        lgmvf.LG_COLD_CHAIN_STR_CONST: "",
        lgmvf.LG_COLD_CHAIN_CAPACITY: 0.115281,
        lgmvf.LG_COLD_CHAIN_TYPE: LG_COLD_CHAIN_TYPE_STORAGE_MST_ID,
    },
    {
        lgmvf.LG_COLD_CHAIN_ID: 5,
        lgmvf.LG_COLD_CHAIN_UNIT_COST: 1075.30,
        lgmvf.LG_COLD_CHAIN_NAME: "Freezer",
        lgmvf.LG_COLD_CHAIN_STR_CONST: "",
        lgmvf.LG_COLD_CHAIN_CAPACITY: 0,
        lgmvf.LG_COLD_CHAIN_TYPE: LG_COLD_CHAIN_TYPE_STORAGE_MST_ID,
    },
    {
        lgmvf.LG_COLD_CHAIN_ID: 6,
        lgmvf.LG_COLD_CHAIN_UNIT_COST: 2632,
        lgmvf.LG_COLD_CHAIN_NAME: "Long-term passive storage device",
        lgmvf.LG_COLD_CHAIN_STR_CONST: "",
        lgmvf.LG_COLD_CHAIN_CAPACITY: 0.005,
        lgmvf.LG_COLD_CHAIN_TYPE: LG_COLD_CHAIN_TYPE_STORAGE_MST_ID,
    },
    {
        lgmvf.LG_COLD_CHAIN_ID: 7,
        lgmvf.LG_COLD_CHAIN_UNIT_COST: 50,
        lgmvf.LG_COLD_CHAIN_NAME: "Mobile passive storage device",
        lgmvf.LG_COLD_CHAIN_STR_CONST: "",
        lgmvf.LG_COLD_CHAIN_CAPACITY: 0.0036,
        lgmvf.LG_COLD_CHAIN_TYPE: LG_COLD_CHAIN_TYPE_STORAGE_MST_ID,
    },
    # Transport
    {
        lgmvf.LG_COLD_CHAIN_ID: 8,
        lgmvf.LG_COLD_CHAIN_UNIT_COST: 2172,
        lgmvf.LG_COLD_CHAIN_NAME: "Transportable Powered Vaccine Storage Devices (TPVS)",
        lgmvf.LG_COLD_CHAIN_STR_CONST: "",
        lgmvf.LG_COLD_CHAIN_CAPACITY: 0,
        lgmvf.LG_COLD_CHAIN_TYPE: LG_COLD_CHAIN_TYPE_TRANSPORT_MST_ID,
    },
    {
        lgmvf.LG_COLD_CHAIN_ID: 9,
        lgmvf.LG_COLD_CHAIN_UNIT_COST: 34.81,
        lgmvf.LG_COLD_CHAIN_NAME: "Freeze Free Vaccine Carriers",
        lgmvf.LG_COLD_CHAIN_STR_CONST: "",
        lgmvf.LG_COLD_CHAIN_CAPACITY: 1.92,
        lgmvf.LG_COLD_CHAIN_TYPE: LG_COLD_CHAIN_TYPE_TRANSPORT_MST_ID,
    },
    {
        lgmvf.LG_COLD_CHAIN_ID: 10,
        lgmvf.LG_COLD_CHAIN_UNIT_COST: 280.79,
        lgmvf.LG_COLD_CHAIN_NAME: "Freeze Free Cold Boxes ",
        lgmvf.LG_COLD_CHAIN_STR_CONST: "",
        lgmvf.LG_COLD_CHAIN_CAPACITY: 12.09,
        lgmvf.LG_COLD_CHAIN_TYPE: LG_COLD_CHAIN_TYPE_TRANSPORT_MST_ID,
    },
    {
        lgmvf.LG_COLD_CHAIN_ID: 11,
        lgmvf.LG_COLD_CHAIN_UNIT_COST: 171255.13,
        lgmvf.LG_COLD_CHAIN_NAME: "Refrigerated vehicle",
        lgmvf.LG_COLD_CHAIN_STR_CONST: "",
        lgmvf.LG_COLD_CHAIN_CAPACITY: 26.37,
        lgmvf.LG_COLD_CHAIN_TYPE: LG_COLD_CHAIN_TYPE_TRANSPORT_MST_ID,
    },
    # Accessories
    {
        lgmvf.LG_COLD_CHAIN_ID: 12,
        lgmvf.LG_COLD_CHAIN_UNIT_COST: 43.10,
        lgmvf.LG_COLD_CHAIN_NAME: "Temperature monitoring device",
        lgmvf.LG_COLD_CHAIN_STR_CONST: "",
        lgmvf.LG_COLD_CHAIN_CAPACITY: None,
        lgmvf.LG_COLD_CHAIN_TYPE: LG_COLD_CHAIN_TYPE_ACCESSORIES_MST_ID,
    },
    {
        lgmvf.LG_COLD_CHAIN_ID: 13,
        lgmvf.LG_COLD_CHAIN_UNIT_COST: 599.66,
        lgmvf.LG_COLD_CHAIN_NAME: "Remote temperature monitoring devices (RTMDs) ",
        lgmvf.LG_COLD_CHAIN_STR_CONST: "",
        lgmvf.LG_COLD_CHAIN_CAPACITY: None,
        lgmvf.LG_COLD_CHAIN_TYPE: LG_COLD_CHAIN_TYPE_ACCESSORIES_MST_ID,
    },
    {
        lgmvf.LG_COLD_CHAIN_ID: 14,
        lgmvf.LG_COLD_CHAIN_UNIT_COST: 1,
        lgmvf.LG_COLD_CHAIN_NAME: "Icepacks",
        lgmvf.LG_COLD_CHAIN_STR_CONST: "",
        lgmvf.LG_COLD_CHAIN_CAPACITY: None,
        lgmvf.LG_COLD_CHAIN_TYPE: LG_COLD_CHAIN_TYPE_ACCESSORIES_MST_ID,
    },
]


# =========================
# Drugs and supplies
# =========================

# Drug/supply quantity sources
LG_USER_SUPPLIED_QUANTITIES_MST_ID = 1
LG_PROG_AREA_QUANTITIES_MST_ID = 2

LG_USER_SUPPLIED_QUANTITIES_CURR_ID = 1
LG_PROG_AREA_QUANTITIES_CURR_ID = 2
LG_NUM_QUANTITY_SOURCES = LG_PROG_AREA_QUANTITIES_CURR_ID

LG_DRUG_SUPPLY_QUANTITY_SOURCES = [LG_USER_SUPPLIED_QUANTITIES_CURR_ID, LG_PROG_AREA_QUANTITIES_CURR_ID]
