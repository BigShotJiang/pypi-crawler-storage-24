

#Selecting an approach for projecting 
FS_MANUAL_APPROACH = 'Manual'
FS_COEFF_APPROACH = 'Coefficient'
FS_GGE_APPROACH = 'GGE'
FS_CONSTANT_APPROACH = 'constantPrices'