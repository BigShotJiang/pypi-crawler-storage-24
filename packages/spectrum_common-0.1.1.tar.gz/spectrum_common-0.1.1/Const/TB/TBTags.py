
TB_UseOldFailsafeTag   = '<TB_UseOldFailsafe_V1>'
TB_UseOldIPTag         = '<TB_UseIPModel_V1>'
TB_BaseYearTag         = '<TB_BaseYear_V2>'
TB_FirstYearIdxTag     = '<TB_FirstYearIdx_V1>' # deprecated
TB_ScreeningAlgMapTag  = '<TB_ScreeningAlgMap_V1>'
# TB_ImpactModelTag      = '<TB_ImpactModelSelected_V1>'

TB_HistNotifStartYearTag = '<TB_HistNotifStartYear_V1>'
TB_HistNotifTag = '<TB_HistNotif_V1>'
TB_HistNotiDistributionTag = '<TB_HistNotiDistribution_V1>'

# Household demographic info    
TB_HHSizeTag         = '<TB_HHSize_V1>'# Average household size (#)
TB_HHPropU5Tag       = '<TB_HHPropU5_V1>'#  Proportion of household that is u5 (# )
TB_HHProp5_14Tag     = '<TB_HHProp5_14_V1>'# Proportion of household that is 5-14 yrs 
TB_HHCasesinIndexTag = '<TB_HHCasesinIndex_V1>'# Average number of TB cases in household with at least one case (#)

# TB infection
TB_HHPropU5LTBITag = '<TB_HHPropU5LTBI_V1>' # Proportion of u5s with TB infection in household with TB infection (# )
TB_HHPropO5LTBITag = '<TB_HHPropO5LTBI_V1>' # Proportion of other household members with TB infection in household with active case (# )

# TB disease
TB_HHPropU5TBTag  = '<TB_HHPropU5TB_V1>'  # Proportion of�u5s with TB disease in household with TB disease (# )
TB_HHPropU5PTBTag = '<TB_HHPropU5PTB_V1>' # Proportion with pulmonary TB, PTB (# )
TB_HHPropO5TBTag  = '<TB_HHPropO5TB_V1>'  # Proportion of other household members with TB disease in household with TB disease (# )
TB_HHPropO5PTBTag = '<TB_HHPropO5PTB_V1>'# Proportion with pulmonary TB, PTB (# )
TB_HHNumNewBactPosTag = '<TB_HHNumNewBactPos_V1>'# Number of new bacteriologically positive TB cases (adult)
TB_HHNumNewBactNegTag = '<TB_HHNumNewBactNeg_V1>'# Number of new bacteriologically negative TB cases (adult)

TB_HHPIndexCasesScreenedTag     = '<TB_HHIndexCasesScreened_V1>'     # Proportion of households of index cases screened/evaluated
TB_HHProportionTag       = '<TB_HHProportionScreen_V1>'
TB_HHPropBACnScreenedTag = '<TB_HHPropBACnScreened_V1>' # Proportion of contacts of new bacteriologically negative cases screened/evaluated

TB_HHContacts = '<TB_HHContacts_V1>'   
TB_HHScreeningAlgTag           = '<TB_HHScreeningAlg_V1>'
TB_HHScreeningAlgIDTag         = '<TB_HHScreeningAlgID_V1>'
TB_HHScreenSensitivityTag      = '<TB_HHScreenSensitivity_V1>' 
TB_HHScreenSpecificityTag      = '<TB_HHScreenSpecificity_V1>' 
TB_HHScreenAlgOptionsTag       = '<TB_HHScreenAlgOptions_V2>'
TB_HHScreenAlgSelectedTag      = '<TB_HHScreenAlgSelected_V1>'   
TB_ScreenCustomTag             = '<TB_ScreenCustom_V1>' 
TB_DiagnosticCustomTag         = '<TB_DiagnosticCustom_V1>' 
TB_HHDiagSensitivityTag        = '<TB_HHDiagSensitivity_V1>' 
TB_HHDiagSpecificityTag        = '<TB_HHDiagSpecificity_V1>'            
TB_HHNumScreenedTag            = '<TB_HHNumScreened_V1>'        
TB_HHNumReferredTag            = '<TB_HHNumReferred_V1>'                  
TB_HHNumScreenedToReferTag     = '<TB_HHNumScreenedToRefer_V1>'           
TB_HHPercTrueCasesTag          = '<TB_HHPercTrueCases_V1>'          
TB_HHDiagCaseValuesTag         = '<TB_HHDiagCaseValues_V1>'                      
TB_HHDiagCaseIDsTag            = '<TB_HHDiagCaseIDs_V1>'                    
TB_HHDiagCaseMethodsTag        = '<TB_HHDiagCaseMethodIDs_V1>'  
TB_HHDiagCaseSensitivityTag    = '<TB_HHDiagCaseSensitivity_V1>'
TB_HHDiagCaseSpecificityTag    = '<TB_HHDiagCaseSpecificity_V1>'
TB_HHNumDiagnosedPTBTag        = '<TB_HHNumDiagnosedPTB_V1>'              
TB_HHNumConfirmedPTBTag        = '<TB_HHNumConfirmedPTB_V1>'           
TB_HHPropLinkedTreatTag        = '<TB_HHPropLinkedTreatment_V1>'    
TB_HHNumInitTreatmentTag       = '<TB_HHNumInitTreatment_V1>'  
TB_HHPrvntInActiveEligibleTag  = '<TB_HHPrvntInActiveEligible_V1>'  
TB_HHPrvntReceivePTPrevTag    = '<TB_HHPrvntReceivevPTPrev_V1>'  
TB_HHPropPrvntPresumpTag       = '<TB_HHPrvntGivenPT_V1>'  
TB_HHPropPrvntTestedTag        = '<TB_HHPrvntTestedLTBI_V1>'  
TB_HHPrvntMethodsTag           = '<TB_HHPrvntMethods_V2>'  
TB_HHPrvntMethodIDsTag         = '<TB_HHPrvntMethodIDs_V2>'  
TB_HHPropEligiblePrvntLinkTag  = '<TB_HHPrvntEligibleCases_V1>'   
TB_HHNumberOnTPTTag            = '<TB_HHNumberOnTPT_V1>'
TB_HHTPTCompleteRateTag        = '<TB_HHTPTCompleteRate_V1>'
TB_HHNumberCompleteTPTTag      = '<TB_HHNumberCompleteTPT_V1>' 
TB_HHScreeningOutputTag        = '<TB_HHScreeningOutput_V1>' 
TB_HHDiagnosticOutputTag       = '<TB_HHDiagnosticOutput_V1>' 
TB_HHTargetPopsTag             = '<TB_HHTargetPops_V1>'

TB_ARTCohortSizesTag            = '<TB_ARTCohortSizes_V1>'
TB_ARTCharacteristicsTag        = '<TB_ARTCharacteristics_V1>'

TB_ARTProportionTag             = '<TB_ARTProportionScreen_V1>'
TB_ARTScreeningAlgTag           = '<TB_ARTScreeningAlg_V1>'
TB_ARTScreeningAlgIDTag         = '<TB_ARTScreeningAlgID_V1>'
TB_ARTScreenSensitivityTag      = '<TB_ARTScreenSensitivity_V1>' 
TB_ARTScreenSpecificityTag      = '<TB_ARTScreenSpecificity_V1>'  
TB_ARTScreenAlgOptionsTag       = '<TB_ARTScreenAlgOptions_V2>'
TB_ARTScreenAlgSelectedTag      = '<TB_ARTScreenAlgSelected_V1>'
TB_ARTDiagSensitivityTag        = '<TB_ARTDiagSensitivity_V1>' 
TB_ARTDiagSpecificityTag        = '<TB_ARTDiagSpecificity_V1>'                
TB_ARTNumScreenedTag            = '<TB_ARTNumScreened_V1>'        
TB_ARTNumReferredTag            = '<TB_ARTNumReferred_V1>'                  
TB_ARTNumScreenedToReferTag     = '<TB_ARTNumScreenedToRefer_V1>'           
TB_ARTPercTrueCasesTag          = '<TB_ARTPercTrueCases_V1>'          
TB_ARTDiagCaseValuesTag         = '<TB_ARTDiagCaseValues_V2>'                      
TB_ARTDiagCaseIDsTag            = '<TB_ARTDiagCaseIDs_V2>'                    
TB_ARTDiagCaseMethodsTag        = '<TB_ARTDiagCaseMethodIDs_V2>'   
TB_ARTDiagCaseSensitivityTag    = '<TB_ARTDiagCaseSensitivity_V2>'
TB_ARTDiagCaseSpecificityTag    = '<TB_ARTDiagCaseSpecificity_V2>'            
TB_ARTNumDiagnosedPTBTag        = '<TB_ARTNumDiagnosedPTB_V1>'              
TB_ARTNumConfirmedPTBTag        = '<TB_ARTNumConfirmedPTB_V1>'           
TB_ARTPropLinkedTreatTag        = '<TB_ARTPropLinkedTreatment_V1>'    
TB_ARTNumInitTreatmentTag       = '<TB_ARTNumInitTreatment_V1>'  
TB_ARTPrvntInActiveEligibleTag  = '<TB_ARTPrvntInActiveEligible_V1>'  
TB_ARTPrvntReceivePTPrevTag    = '<TB_ARTPrvntReceivevPTPrev_V1>'  
TB_ARTPropPrvntPresumpTag       = '<TB_ARTPrvntGivenPT_V1>'  
TB_ARTPropPrvntTestedTag        = '<TB_ARTPrvntTestedLTBI_V1>'  
TB_ARTPrvntMethodsTag           = '<TB_ARTPrvntMethods_V1>'  
TB_ARTPrvntMethodIDsTag         = '<TB_ARTPrvntMethodIDs_V1>'  
TB_ARTPropEligiblePrvntLinkTag  = '<TB_ARTPrvntEligibleCases_V1>' 
TB_ARTNumberOnTPTTag            = '<TB_ARTNumberOnTPT_V1>'
TB_ARTTPTCompleteRateTag        = '<TB_ARTTPTCompleteRate_V1>'
TB_ARTNumberCompleteTPTTag      = '<TB_ARTNumberCompleteTPT_V1>' 
TB_ARTScreeningOutputTag        = '<TB_ARTScreeningOutput_V1>' 
TB_ARTDiagnosticOutputTag       = '<TB_ARTDiagnosticOutput_V1>' 
TB_ARTTargetPopsTag             = '<TB_ARTargetPops_V1>'


TB_HRGDemographicsTag           = '<TB_HRGDemographics_V1>'

TB_HRGProportionTag             = '<TB_HRGProportionScreen_V1>'
TB_HRGScreeningAlgTag           = '<TB_HRGScreeningAlg_V1>'
TB_HRGScreeningAlgIDTag         = '<TB_HRGScreeningAlgID_V1>'
TB_HRGScreenSensitivityTag      = '<TB_HRGScreenSensitivity_V1>' 
TB_HRGScreenSpecificityTag      = '<TB_HRGScreenSpecificity_V1>' 
TB_HRGScreenAlgOptionsTag       = '<TB_HRGScreenAlgOptions_V2>'
TB_HRGScreenAlgSelectedTag      = '<TB_HRGScreenAlgSelected_V1>'
TB_HRGDiagSensitivityTag        = '<TB_HRGDiagSensitivity_V1>' 
TB_HRGDiagSpecificityTag        = '<TB_HRGDiagSpecificity_V1>'                  
TB_HRGNumScreenedTag            = '<TB_HRGNumScreened_V1>'        
TB_HRGNumReferredTag            = '<TB_HRGNumReferred_V1>'                  
TB_HRGNumScreenedToReferTag     = '<TB_HRGNumScreenedToRefer_V1>'           
TB_HRGPercTrueCasesTag          = '<TB_HRGPercTrueCases_V1>'          
TB_HRGDiagCaseValuesTag         = '<TB_HRGDiagCaseValues_V1>'                      
TB_HRGDiagCaseIDsTag            = '<TB_HRGDiagCaseIDs_V1>'                    
TB_HRGDiagCaseMethodsTag        = '<TB_HRGDiagCaseMethodIDs_V1>' 
TB_HRGDiagCaseSensitivityTag    = '<TB_HRGDiagCaseSensitivity_V1>'
TB_HRGDiagCaseSpecificityTag    = '<TB_HRGDiagCaseSpecificity_V1>'                  
TB_HRGNumDiagnosedPTBTag        = '<TB_HRGNumDiagnosedPTB_V1>'              
TB_HRGNumConfirmedPTBTag        = '<TB_HRGNumConfirmedPTB_V1>'           
TB_HRGPropLinkedTreatTag        = '<TB_HRGPropLinkedTreatment_V1>'    
TB_HRGNumInitTreatmentTag       = '<TB_HRGNumInitTreatment_V1>'  
TB_HRGPrvntInActiveEligibleTag  = '<TB_HRGPrvntInActiveEligible_V1>'  
TB_HRGPrvntReceivePTPrevTag    = '<TB_HRGPrvntReceivevPTPrev_V1>'  
TB_HRGPropPrvntPresumpTag       = '<TB_HRGPrvntGivenPT_V1>'  
TB_HRGPropPrvntTestedTag        = '<TB_HRGPrvntTestedLTBI_V1>'  
TB_HRGPrvntMethodsTag           = '<TB_HRGPrvntMethods_V1>'  
TB_HRGPrvntMethodIDsTag         = '<TB_HRGPrvntMethodIDs_V1>'  
TB_HRGPropEligiblePrvntLinkTag  = '<TB_HRGPrvntEligibleCases_V1>' 
TB_HRGNumberOnTPTTag            = '<TB_HRGNumberOnTPT_V1>'
TB_HRGTPTCompleteRateTag        = '<TB_HRGTPTCompleteRate_V1>'
TB_HRGNumberCompleteTPTTag      = '<TB_HRGNumberCompleteTPT_V1>' 
TB_HRGScreeningOutputTag        = '<TB_HRGScreeningOutput_V1>' 
TB_HRGDiagnosticOutputTag       = '<TB_HRGDiagnosticOutput_V1>' 
TB_HRGTargetPopsTag             = '<TB_HRGTargetPops_V1>'

# Prevalence of active TB    
# Pulmonary TB 
# TB_PIHIVn014_PTBTag  = '<TB_PIHIVn014_PTB_V1>' 
# TB_PIHIVn15p_PTBTag  = '<TB_PIHIVn15p_PTB_V1>' 
# TB_PIHIVn09_PTBTag   = '<TB_PIHIVn09_PTB_V1>' 
# TB_PIHIVn1014_PTBTag = '<TB_PIHIVn1014_PTB_V1>' 
# TB_PIHIVn15p_PTBTag  = '<TB_PIHIVn15p_PTB_V1>' 
# # Extra-Pulmonary TB
# TB_PIHIVp014_ETBTag  = '<TB_PIHIVp014_ETB_V1>' 
# TB_PIHIVp15p_ETBTag  = '<TB_PIHIVp15p_ETB_V1>' 
# TB_PIHIVp09_ETBTag   = '<TB_PIHIVp09_ETB_V1>' 
# TB_PIHIVp1014_ETBTag = '<TB_PIHIVp1014_ETB_V1>' 
# TB_PIHIVp15p_ETBTag  = '<TB_PIHIVp15p_ETB_V1>' 



        
# TB_PropScreenedTag  = '<TB_PropScreened_V1>'

# Screening algorithm used for screening
# Sensitivity for PTB
# Specificity for PTB
TB_PatientScreenSensTag = '<TB_PatientScreenSens_V1>' 
TB_PatientScreenSpecTag = '<TB_PatientScreenSpec_V1>' 
TB_DiagSensTag   = '<TB_DiagSens_V1>' 
TB_DiagSpecTag   = '<TB_DiagSpec_V1>' 


# TB_PropDiagLinkedTxTag       = '<TB_PropDiagLinkedTx_V1>'      
# TB_PropTPTPresumptiveTxTag   = '<TB_PropTPTPresumptiveTx_V1>'# Proportion given PT presumptively
# TB_PropEligibleTPTtestedTag  = '<TB_PropEligibleTPTtested_V1>'# Proportion of remaining household contacts tested for LTBI
# TB_PropEligibleLinkedTPTTag  = '<TB_PropEligibleLinkedTPT_V1>'# Proportion of presumed or confirmed TB preventive treatment-eligible cases linked to TB preventive treatment

# TB_ART09_PropNotSeriouslyIllTag    = '<TB_ART09_PropNotSeriouslyIll_V1>'
# TB_ART09_PropSeriouslyIllTag       = '<TB_ART09_PropSeriouslyIll_V1>'
# TB_ART1014_PropNotSeriouslyIllTag  = '<TB_ART1014_PropNotSeriouslyIll_V1>'
# TB_ART1014_PropSeriouslyIllTag     = '<TB_ART1014_PropSeriouslyIll_V1>'
# TB_ART15p_PropNotSeriouslyIllTag   = '<TB_ART15p_PropNotSeriouslyIll_V1>' # Without serious illness (# )
# TB_ART15p_PropSeriouslyIllTag      = '<TB_ART15p_PropSeriouslyIll_V1>' # With serious illness (# )  
# # ART, TB infection and disease characteristics
# TB_ART09_PropLTBITag   = '<TB_ART09_PropLTBI_V1>' # Proportion of�ART patients 0 to 9 years with TB infection (# )
# TB_ART09_PropTBTag     = '<TB_ART09_PropTB_V1>' # Proportion of�ART patients 0 to 9 years with TB disease (# )
# TB_ART09_PropPTBTag    = '<TB_RT09_PropPTB_V1>' # Proportion with pulmonary TB, PTB (# )
# TB_ART1014_PropLTBITag = '<TB_ART1014_PropLTBI_V1>' # Proportion of�ART patients 10 to 14 years with TB infection (# )        
# TB_ART1014_PropTBTag   = '<TB_ART1014_PropTB_V1>' # Proportion of�ART patients 10 to 14 years with TB disease (# )
# TB_ART1014_PropPTBTag  = '<TB_ART1014_PropPTB_V1>' # Proportion with pulmonary TB, PTB (# )
# TB_ART15p_PropLTBITag  = '<TB_ART15p_PropLTBI_V1>' # Proportion of�ART patients 15 years and older with TB infection (# )
# TB_ART15p_PropTBTag    = '<TB_ART15p_PropTB_V1>' # Proportion of�ART patients 15 years and older with TB disease (# )    
# TB_ART15p_PropPTBTag   = '<TB_ART15p_PropPTB_V1>' # Proportion with pulmonary TB, PTB (# )


        
# TB_PropPop15pHRGTag = '<TB_PropPop15pHRG_V1>' # Proportion of population 15+ in HRG    
# TB_HRG_PropLTBITag  = '<TB_HRG_PropLTBI_V1>' # Proportion of�ART patients 15 years and older with TB infection (# )
# TB_HRG_PropTBTag    = '<TB_HRG_PropTB_V1>' # Proportion of�ART patients 15 years and older with TB disease (# )
# TB_HRG_PropPTBTag   = '<TB_HRG_PropPTB_V1>' # Proportion with pulmonary TB, PTB (# )

# From the wireframes
TB_PulmonaryAgeTag                 = '<TB_PulmonaryAges_V1>'   
TB_PrevalenceTag                   = '<TB_Prevalence_V1>'                          

TB_PatientScreenSensitivityTag     = '<TB_PatientScreenSensitivity_V1>'                  
TB_PatientScreenSpecificityTag     = '<TB_PatientScreenSpecificity_V1>' 
TB_PatientScreenAlgOptionsTag      = '<TB_PatientScreenAlgOptions_V2>'
TB_PatientScreenAlgSelectedTag     = '<TB_PatientScreenAlgSelected_V1>'
                
TB_NumClinicallyAssessedTag        = '<TB_NumClinicallyAssessed_V1>'        
TB_NumReferredTag                  = '<TB_NumReferred_V1>'                  
TB_NumScreenedToReferTag           = '<TB_NumScreenedToRefer_V1>'           
TB_PercTrueCasesTag                = '<TB_PercTrueCases_V1>' 

TB_PatientDiagCaseValuesTag         = '<TB_PatientDiagCaseValues_V1>'                      
TB_PatientDiagCaseIDsTag            = '<TB_PatientDiagCaseIDs_V1>'                      
TB_PatientDiagCaseMethodsTag      = '<TB_PatientDiagCaseMethodIDs_V1>'   
TB_PatientDiagCaseSensitivityTag    = '<TB_PatientDiagCaseSensitivity_V1>'   
TB_PatientDiagCaseSpecificityTag    = '<TB_PatientDiagCaseSpecificity_V1>'  

TB_PatientDiagSensitivityTag       = '<TB_PatientDiagSensitivity_V1>'                  
TB_PatientDiagSpecificityTag       = '<TB_PatientDiagSpecificity_V1>' 

TB_NumDiagnosedPTBTag              = '<TB_NumDiagnosedPTB_V1>'              
TB_NumConfirmedPTBTag              = '<TB_NumConfirmedPTB_V1>'      
TB_NumDiagnosedTBTag               = '<TB_NumDiagnosedTB_V1>' 
TB_NumInitTreatmentTag             = '<TB_NumInitTreatment_V1>'  

TB_PatientScreeningOutputTag       = '<TB_PatientScreeningOutput_V1>'
TB_PatientDiagnosticOutputTag      = '<TB_PatientDiagnosticOutput_V1>'
TB_PatientTargetPopTag             = '<TB_PatientTargetPop_V1>'

TB_HisNotificationTag  = '<TB_HistoricalNotification_V1>'
TB_HisIncidenceTag     = '<TB_HistoricalIncidence_V1>'
TB_HisMortalityTag     = '<TB_HistoricalMortality_V1>'
TB_RetNrelPercTag      = '<TB_ret_nrel_perc_V1>'
TB_TargNotificationTag = '<TB_TargetNotification_V1>'
TB_ResNotificationTag  = '<TB_ResNotification_V1>'
TB_ResNotificationV2Tag  = '<TB_ResNotification_V2>'

TB_ResPrevalenceTag    = '<TB_ResPrevalence_V1>'
TB_ResPrevalencePctTag = '<TB_ResPrevalencePct_V1>'
TB_ResHIVTBCoInfTag    = '<TB_ResHIVTBCoInfTag_V1>'

TB_ResIncidenceTag     = '<TB_ResIncidence_V1>'
TB_ResMortalityTag     = '<TB_ResMortality_V1>'

TB_UserEnteredIncidenceTag     = '<TB_UserEnteredIncidence_V1>'
TB_UserEnteredMortalityTag     = '<TB_UserEnteredMortality_V1>'

TB_CounterfactualScenarioTag  = '<TB_CounterfactualScenario_V1>'
TB_CurrentScenarioTag         = '<TB_CurrentScenario_V1>'

TB_CounterfactualNotifTag = '<TB_CounterfactualNotification_V1>'

TB_FortIncidenceTag    = '<TB_FortIncidence_V1>'
TB_FortNotificationTag = '<TB_FortNotification_V1>'
TB_FortPrevalenceTag   = '<TB_FortPrevalence_V1>'
TB_FortMortalityTag    = '<TB_FortMortality_V1>'


TB_NotificationByCaseTypeTag = '<TB_NotificationByCaseType_V2>'
TB_PercNotificationTag = '<TB_PercentNotification_V2>'
TB_Baseline_HRi_allTag = '<TB_Baseline_HRi_all_V1>'
TB_Scaleup_HRi_allTag = '<TB_Scaleup_HRi_all_V1>'

TB_SubnationalRatioTag    = '<TB_SubnationalRatio_V1>'

TB_AlternativeProjBurdenTag = '<TB_AlternativeProjBurden_V1>'



TB_ResistProfileTag          = '<TB_ResistProfile_V1>'
TB_ResistPropNonSevereTag    = '<TB_ResistPropNonSevere_V1>'
TB_ResistPropLungSurgeryTag  = '<TB_ResistPropLungSurgery_V1>'
TB_ResistMeningitisTag       = '<TB_ResistMeningitis_V1>'
TB_ResistPropTreatExhaustTag = '<TB_ResistPropTreatExhaust_V1>'
TB_PatientTestNumPTB         = '<TB_PatientTestNumPTB_V1>'
TB_PatientTestNumXDR         = '<TB_PatientTestNumXDR_V1>'
TB_PatientTestNumEPTB        = '<TB_PatientTestNumETB_V1>'
TB_CoverageTag               = '<TB_Coverage_V1>'
TB_ResistNumToBeTestedTag    = '<TB_ResistNumToBeTested_V1>'
TB_ResistNumTestedTag        = '<TB_ResistNumTested_V1>'
TB_ResistNumConfirmedTag     = '<TB_ResistNumConfirmed_V1>'
TB_ResistNumNotConfirmedTag  = '<TB_ResistNumNotConfirmed_V1>'
TB_PropPreventionTag         = '<TB_PropPrevention_V1>'
TB_BCGImmunizationTag        = '<TB_BCGImmunization_V1>'
TB_InfantVaccineTag          = '<TB_InfantVaccine_V1>'
TB_AdolAdultVaccineTag       = '<TB_AdolAdultVaccine_V1>'
TB_PalliativeCareTag         = '<TB_PalliativeCare_V1>'

TB_BCGTargetPopTag          = '<TB_BCGTargetPop_V1>'
TB_InfantVaccTargPopTag     = '<TB_InfantVaccineTargPop_V1>'
TB_AdultVaccTargPopTag      = '<TB_AdolAdultVaccineTargPop_V1>'
# TB_PalliativeCareTargPopTag = '<TB_PalliativeCareTargPop_V1>'
TB_PalliativeCareTargPopTag = '<TB_PalliativeCareTargPop_V2>'


TB_PreventionTargetTag       = '<TB_PreventionTargets_V1>'


TB_RR_DST_PTBTag     = '<TB_RR_DST_PTB_V1>'
TB_RR_DST_ETBTag     = '<TB_RR_DST_ETB_V1>'
TB_INH_DST_PTBTag    = '<TB_INH_DST_PTB_V1>'
TB_INH_DST_ETBTag    = '<TB_INH_DST_ETB_V1>'
TB_FQ_DST_PTBTag     = '<TB_FQ_DST_PTB_V1>'
TB_FQ_DST_ETBTag     = '<TB_FQ_DST_ETB_V1>'
TB_BDQ_DST_PTBTag    = '<TB_BDQ_DST_PTB_V1>'
TB_BDQ_DST_ETBTag    = '<TB_BDQ_DST_ETB_V1>'
TB_BDQ_FQ_DST_PTBTag = '<TB_BDQ_FQ_DST_PTB_V1>'
TB_BDQ_FQ_DST_ETBTag = '<TB_BDQ_FQ_DST_ETB_V1>'
TB_LZD_RR_DST_PTBTag = '<TB_LZD_RR_DST_PTB_V1>'
TB_LZD_RR_DST_ETBTag = '<TB_LZD_RR_DST_ETB_V1>'
TB_LZD_FQ_DST_PTBTag = '<TB_LZD_FQ_DST_PTB_V1>'
TB_LZD_FQ_DST_ETBTag = '<TB_LZD_FQ_DST_ETB_V1>'
TB_PZA_DSTTag        = '<TB_PZA_DST_V1>'
TB_ETO_DSTTag        = '<TB_ETO_DST_V1>'
TB_EMC_DSTTag        = '<TB_EMC_DST_V1>'

TB_BDQ_LZD_NumDx_U15Tag         = '<TB_BDQ_LZD_NumDx_U15_V1>'
TB_BDQ_LZD_NumDx_15PLusTag      = '<TB_BDQ_LZD_NumDx_15PLus_V1>'
TB_BDQ_LZD_NumDx_PTB_U15Tag     = '<TB_BDQ_LZD_NumDx_PTB_U15_V1>'
TB_BDQ_LZD_NumDx_PTB_15PLusTag  = '<TB_BDQ_LZD_NumDx_PTB_15PLus_V1>'
TB_BDQ_LZD_NumDx_ETB_U15Tag     = '<TB_BDQ_LZD_NumDx_ETB_U15_V1>'
TB_BDQ_LZD_NumDx_ETB_15PLusTag  = '<TB_BDQ_LZD_NumDx_ETB_15PLus_V1>'


TB_AmikacynRifampicinResistant     = '<TB_AmikacynRifampicinResistant_V1>'
TB_EthionamideRifampicinResistant  = '<TB_EthionamideRifampicinResistant_V1>'
TB_PyrazinamideRifampicinResistant = '<TB_PyrazinamideRifampicinResistant_V1>'


TB_Rif_INH_Sen_SevereTag     = '<TB_Rif_INH_Sen_Severe_V1>'
TB_Rif_INH_Sen_NotSevereTag  = '<TB_Rif_INH_Sen_NotSevere_V1>'
TB_Rif_INH_Sen_MeningitisTag = '<TB_Rif_INH_Sen_Meningitis_V1>'
TB_Rif_INH_ResTag            = '<TB_Rif_INH_Res_V1>'
TB_RR_FQ_SenTag              = '<TB_RR_FQ_Sen_V1>'
TB_Rif_FQ_Res_PlusTag        = '<TB_Rif_FQ_Res_V1>'
TB_BQD_LZD_Tag               = '<TB_BQD_LZD_V1>' # Number confirmed Pre-XDR and resistant to at least one of Bedaquiline, Linezolid, Levofloxacin, Moxifloxacin';

TB_TxFL_Tag                  = '<TB_TxFL_V1>'
TB_TxSL_Tag                  = '<TB_TxSL_V1>'
TB_TxPreXDR_Tag              = '<TB_TxPreXDR_V1>'

TB_LungSurgeryTag            = '<TB_LungSurgery_V1>'

TB_lPTB_ReferredDxTag        = '<TB_lPTB_ReferredDxT_V1>'

TB_HIVnClinicallyAssessedTag  = '<TB_HIVnClinicallyAssessed_V1>'
TB_HIVAnyReferredDxTag        = '<TB_HIVAnyReferredDx_V1>'

TB_DynProportionsTag   = '<TB_DynamicalModelProportions_V1>'
TB_DynRatesTag         = '<TB_DynamicalModelRates_V1>'
TB_DynPRMTag           = '<TB_DynamicalModelPRM_V1>'
TB_DynUsedFitParamTag  = '<TB_DynamicalModelUsedFitParam_V1>'
TB_DynUsedHIVIncdTag   = '<TB_DynamicalModelHIVIncd_V1>'
TB_DynRangesTag        = '<TB_DynamicalModelRange_V1>'
TB_DynXSTag            = '<TB_DynamicalModelXS_V1>'
TB_DynPopDataTag       = '<TB_DynamicalModelPopData_V1>'

TB_FortVsnTag = '<TB_FortVersion_V1>'
TB_DynamicalVsnTag = '<TB_DynamicalVersion_V1>'

TB_PatientCustStepMenu  = '<TB_PatientCustStepMenu_V1>'
TB_PatientCustStep1     = '<TB_PatientCustStep1_V1>'
TB_PatientCustStep2     = '<TB_PatientCustStep2_V1>'
TB_PatientCustParallel = '<TB_PatientCustParallelOpt_V1>'

TB_HHCustStepMenu  = '<TB_HHCustStepMenu_V1>'
TB_HHCustStep1     = '<TB_HHCustStep1_V1>'
TB_HHCustStep2     = '<TB_HHCustStep2_V1>'
TB_HHCustParallel  = '<TB_HHCustParallelOpt_V1>'

TB_ARTCustStepMenu  = '<TB_ARTCustStepMenu_V1>'
TB_ARTCustStep1     = '<TB_ARTCustStep1_V1>'
TB_ARTCustStep2     = '<TB_ARTCustStep2_V1>'
TB_ARTCustParallel  = '<TB_ARTCustParallelOpt_V1>'

TB_HRGCustStepMenu  = '<TB_HRGCustStepMenu_V1>'
TB_HRGCustStep1     = '<TB_HRGCustStep1_V1>'
TB_HRGCustStep2     = '<TB_HRGCustStep2_V1>'
TB_HRGCustParallel  = '<TB_HRGCustParallelOpt_V1>'
TB_DynamicalFirstYearTag = '<TB_DynamicalFirstYear_V1>'
TB_DynamicalFinalYearTag = '<TB_DynamicalFinalYear_V1>'

TB_DataSourceTag = '<TB_DataSource_V1>'

TB_FinalHistoricalYearTag = '<TB_FinalHistoricalYear_V1>'
TB_FortInputVersionTag = '<TB_FortInputVersion_V1>'
TB_FortInputTag = '<TB_FortInputTag_V1>'
TB_FortInputScaleupTag = '<TB_FortInputScaleupTag_V1>'
TB_FortOutputVersionTag = '<TB_FortOutputVersion_V1>'
TB_FortOutputTag = '<TB_FortOutputTag_V1>'

TB_ALL_TAGS = [
    TB_BaseYearTag,
    TB_FirstYearIdxTag,
    TB_ScreeningAlgMapTag,
    TB_HHSizeTag,
    TB_HHPropU5Tag,
    TB_HHProp5_14Tag,
    TB_HHCasesinIndexTag,
    TB_HHPropU5LTBITag,
    TB_HHPropO5LTBITag,
    TB_HHPropU5TBTag,
    TB_HHPropU5PTBTag,
    TB_HHPropO5TBTag,
    TB_HHPropO5PTBTag,
    TB_HHNumNewBactPosTag,
    TB_HHNumNewBactNegTag,
    TB_HHPIndexCasesScreenedTag,
    TB_HHProportionTag,
    TB_HHPropBACnScreenedTag,
    TB_HHContacts,
    TB_HHScreeningAlgTag,
    TB_HHScreeningAlgIDTag,
    TB_HHScreenSensitivityTag,
    TB_HHScreenSpecificityTag,
    TB_HHScreenAlgOptionsTag,
    TB_HHScreenAlgSelectedTag,
    TB_HHDiagSensitivityTag,
    TB_HHDiagSpecificityTag,
    TB_HHNumScreenedTag,
    TB_HHNumReferredTag,
    TB_HHNumScreenedToReferTag,
    TB_HHPercTrueCasesTag,
    TB_HHDiagCaseValuesTag,
    TB_HHDiagCaseIDsTag,
    TB_HHDiagCaseMethodsTag,
    TB_HHDiagCaseSensitivityTag,
    TB_HHDiagCaseSpecificityTag,
    TB_HHNumDiagnosedPTBTag,
    TB_HHNumConfirmedPTBTag,
    TB_HHPropLinkedTreatTag,
    TB_HHNumInitTreatmentTag,
    TB_HHPrvntInActiveEligibleTag,
    TB_HHPropPrvntPresumpTag,
    TB_HHPropPrvntTestedTag,
    TB_HHPrvntMethodsTag,
    TB_HHPrvntMethodIDsTag,
    TB_HHPropEligiblePrvntLinkTag,
    TB_HHScreeningOutputTag,
    TB_HHDiagnosticOutputTag,
    TB_HHTargetPopsTag,
    TB_ARTCohortSizesTag,
    TB_ARTCharacteristicsTag,
    TB_ARTProportionTag,
    TB_ARTScreeningAlgTag,
    TB_ARTScreeningAlgIDTag,
    TB_ARTScreenSensitivityTag,
    TB_ARTScreenSpecificityTag,
    TB_ARTScreenAlgOptionsTag,
    TB_ARTScreenAlgSelectedTag,
    TB_ARTDiagSensitivityTag,
    TB_ARTDiagSpecificityTag,
    TB_ARTNumScreenedTag,
    TB_ARTNumReferredTag,
    TB_ARTNumScreenedToReferTag,
    TB_ARTPercTrueCasesTag,
    TB_ARTDiagCaseValuesTag,
    TB_ARTDiagCaseIDsTag,
    TB_ARTDiagCaseMethodsTag,
    TB_ARTDiagCaseSensitivityTag,
    TB_ARTDiagCaseSpecificityTag,
    TB_ARTNumDiagnosedPTBTag,
    TB_ARTNumConfirmedPTBTag,
    TB_ARTPropLinkedTreatTag,
    TB_ARTNumInitTreatmentTag,
    TB_ARTPrvntInActiveEligibleTag,
    TB_ARTPropPrvntPresumpTag,
    TB_ARTPropPrvntTestedTag,
    TB_ARTPrvntMethodsTag,
    TB_ARTPrvntMethodIDsTag,
    TB_ARTPropEligiblePrvntLinkTag,
    TB_ARTScreeningOutputTag,
    TB_ARTDiagnosticOutputTag,
    TB_ARTTargetPopsTag,
    TB_HRGDemographicsTag,
    TB_HRGProportionTag,
    TB_HRGScreeningAlgTag,
    TB_HRGScreeningAlgIDTag,
    TB_HRGScreenSensitivityTag,
    TB_HRGScreenSpecificityTag,
    TB_HRGScreenAlgOptionsTag,
    TB_HRGScreenAlgSelectedTag,
    TB_HRGDiagSensitivityTag,
    TB_HRGDiagSpecificityTag,
    TB_HRGNumScreenedTag,
    TB_HRGNumReferredTag,
    TB_HRGNumScreenedToReferTag,
    TB_HRGPercTrueCasesTag,
    TB_HRGDiagCaseValuesTag,
    TB_HRGDiagCaseIDsTag,
    TB_HRGDiagCaseMethodsTag,
    TB_HRGDiagCaseSensitivityTag,
    TB_HRGDiagCaseSpecificityTag,
    TB_HRGNumDiagnosedPTBTag,
    TB_HRGNumConfirmedPTBTag,
    TB_HRGPropLinkedTreatTag,
    TB_HRGNumInitTreatmentTag,
    TB_HRGPrvntInActiveEligibleTag,
    TB_HRGPropPrvntPresumpTag,
    TB_HRGPropPrvntTestedTag,
    TB_HRGPrvntMethodsTag,
    TB_HRGPrvntMethodIDsTag,
    TB_HRGPropEligiblePrvntLinkTag,
    TB_HRGScreeningOutputTag,
    TB_HRGDiagnosticOutputTag,
    TB_HRGTargetPopsTag,
    TB_PatientScreenSensTag,
    TB_PatientScreenSpecTag,
    TB_DiagSensTag,
    TB_DiagSpecTag,
    TB_PulmonaryAgeTag,
    TB_PrevalenceTag,
    TB_PatientScreenSensitivityTag,
    TB_PatientScreenSpecificityTag,
    TB_PatientScreenAlgOptionsTag,
    TB_PatientScreenAlgSelectedTag,
    TB_NumClinicallyAssessedTag,
    TB_NumReferredTag,
    TB_NumScreenedToReferTag,
    TB_PercTrueCasesTag,
    TB_PatientDiagCaseValuesTag,
    TB_PatientDiagCaseIDsTag,
    TB_PatientDiagCaseMethodsTag,
    TB_PatientDiagCaseSensitivityTag,
    TB_PatientDiagCaseSpecificityTag,
    TB_PatientDiagSensitivityTag,
    TB_PatientDiagSpecificityTag,
    TB_NumDiagnosedPTBTag,
    TB_NumConfirmedPTBTag,
    TB_NumDiagnosedTBTag,
    TB_NumInitTreatmentTag,
    TB_PatientScreeningOutputTag,
    TB_PatientDiagnosticOutputTag,
    TB_PatientTargetPopTag,
    TB_HisNotificationTag,
    TB_TargNotificationTag,
    TB_ResNotificationTag,
    TB_ResNotificationV2Tag,
    TB_ResPrevalenceTag,
    TB_ResPrevalencePctTag,
    TB_ResHIVTBCoInfTag,
    TB_ResIncidenceTag,
    TB_ResMortalityTag,
    TB_CounterfactualScenarioTag,
    TB_CurrentScenarioTag,
    TB_FortIncidenceTag,
    TB_FortNotificationTag,
    TB_FortPrevalenceTag,
    TB_FortMortalityTag,
    TB_NotificationByCaseTypeTag,
    TB_PercNotificationTag,
    TB_Baseline_HRi_allTag,
    TB_Scaleup_HRi_allTag,
    TB_ResistProfileTag,
    TB_ResistPropNonSevereTag,
    TB_ResistPropLungSurgeryTag,
    TB_ResistMeningitisTag,
    TB_ResistPropTreatExhaustTag,
    TB_PatientTestNumPTB,
    TB_PatientTestNumXDR,
    TB_PatientTestNumEPTB,
    TB_CoverageTag,
    TB_ResistNumToBeTestedTag,
    TB_ResistNumTestedTag,
    TB_ResistNumConfirmedTag,
    TB_ResistNumNotConfirmedTag,
    TB_PropPreventionTag,
    TB_BCGImmunizationTag,
    TB_InfantVaccineTag,
    TB_AdolAdultVaccineTag,
    TB_PalliativeCareTag,
    TB_BCGTargetPopTag,
    TB_InfantVaccTargPopTag,
    TB_AdultVaccTargPopTag,
    TB_PalliativeCareTargPopTag,
    TB_PreventionTargetTag,
    TB_RR_DST_PTBTag,
    TB_RR_DST_ETBTag,
    TB_INH_DST_PTBTag,
    TB_INH_DST_ETBTag,
    TB_FQ_DST_PTBTag,
    TB_FQ_DST_ETBTag,
    TB_BDQ_DST_PTBTag,
    TB_BDQ_DST_ETBTag,
    TB_BDQ_FQ_DST_PTBTag,
    TB_BDQ_FQ_DST_ETBTag,
    TB_LZD_RR_DST_PTBTag,
    TB_LZD_RR_DST_ETBTag,
    TB_LZD_FQ_DST_PTBTag,
    TB_LZD_FQ_DST_ETBTag,
    TB_PZA_DSTTag,
    TB_ETO_DSTTag,
    TB_EMC_DSTTag,
    TB_AmikacynRifampicinResistant,
    TB_EthionamideRifampicinResistant,
    TB_PyrazinamideRifampicinResistant,
    TB_Rif_INH_Sen_SevereTag,
    TB_Rif_INH_Sen_NotSevereTag,
    TB_Rif_INH_Sen_MeningitisTag,
    TB_Rif_INH_ResTag,
    TB_RR_FQ_SenTag,
    TB_Rif_FQ_Res_PlusTag,
    TB_BQD_LZD_Tag,
    TB_TxFL_Tag,
    TB_TxSL_Tag,
    TB_TxPreXDR_Tag,
    TB_LungSurgeryTag,
    TB_lPTB_ReferredDxTag,
    TB_HIVnClinicallyAssessedTag,
    TB_HIVAnyReferredDxTag,
    TB_DynProportionsTag,
    TB_DynRatesTag,
    TB_DynPRMTag  ,
    TB_DynUsedFitParamTag,
    TB_DynUsedHIVIncdTag,
    TB_DynRangesTag,
    TB_FortVsnTag,
    
    TB_PatientCustStepMenu ,
    TB_PatientCustStep1    ,
    TB_PatientCustStep2    ,
    TB_PatientCustParallel,

    TB_HHCustStepMenu,
    TB_HHCustStep1,
    TB_HHCustStep2,
    TB_HHCustParallel,

    TB_ARTCustStepMenu,
    TB_ARTCustStep1,
    TB_ARTCustStep2,
    TB_ARTCustParallel,

    TB_HRGCustStepMenu,
    TB_HRGCustStep1,
    TB_HRGCustStep2,
    TB_HRGCustParallel
]


