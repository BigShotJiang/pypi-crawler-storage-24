TB_FirstHist_Year = 2000 # First year WHO data
TB_FinalHist_Year = 2024 # Final year WHO data, update when TB global report is updated
TB_FinalHist_Idx = TB_FinalHist_Year-TB_FirstHist_Year 
TB_FinalHist_Len = TB_FinalHist_Idx+1 

# TB_Base_Year  = 2021 #deafult to TB_FirstHist_Year
TB_Base_Year  = 2024 #default to TB_FirstHist_Year
TB_Min_First_Year = 2015
TB_Max_First_Year = 2026

# #Impact Models
# TB_StatisticalModel = "TB_StatisticalModel"
# TB_DynamicalModel   = "TB_DynamicalModel"

#Split by age
TB_Adults15p=0
TB_Chilren0to14=1

#Split by treatment history
TB_NewCases=0
TB_RetRelCases=1

#Split by pulmonary status
TB_PulmonaryTB=0
TB_ExtraPulmonaryTB=1

#Split by XDR status
TB_PreXDRorXDR=1 
TB_RR=2 # Rifampicine resitant, Pulmonary and Extra-Pulmonary TB

TB_noti_num=0 
TB_noti_perc=1

TB_HH_Contacts_A04  = 1
TB_HH_Contacts_A514 = 2
TB_HH_Contacts_A15p = 3





# HRG cohorts
# 1)Prisoners
# 2)Miners exposed to silica 
# 3)People with risk factors for TB seeking health care in settings with ? 0.1#  TB prevalence
# 4)Populations with structural risk factors for TB and limited access to health care
# 5)General population in settings with ? 0.5#  general prevalence
# 6)People with untreated fibrotic lesions on chest x-ray
# 7)Other high-risk groups
TB_HRG_Prisoners         = 0
TB_HRG_Miners            = 1
TB_HRG_SeekingCare       = 2
TB_HRG_StructuralRFs     = 3
TB_HRG_HighTBPrev        = 4
TB_HRG_UntreatedFibrosis = 5
# TB_HRG_Other             = 6
TB_HRG_Len               = 6

TB_HRG_List = [
    TB_HRG_Prisoners        ,
    TB_HRG_Miners           ,
    TB_HRG_SeekingCare      ,
    TB_HRG_StructuralRFs    ,
    TB_HRG_HighTBPrev       ,
    TB_HRG_UntreatedFibrosis,
]

#HRG demographic indexes
TG_HRG_Dem_TotalPop  = 0 
TG_HRG_Dem_Prop15p   = 1
TG_HRG_Dem_TBInfect  = 2
TB_HRG_Dem_TBDisease = 3
TB_HRG_Dem_RelRisk   = 4
TB_HRG_Dem_PTB       = 5
TG_HRG_DemoGraphics_Len = 6


# Pulmonary TB
TB_PTB_HIVn_014_grp  = 0
TB_PTB_HIVn_15p_grp  = 1
TB_PTB_HIVp_09_grp   = 2
TB_PTB_HIVp_1014_grp = 3
TB_PTB_HIVp_15p_grp  = 4

# Extra-Pulmonary TB
TB_ETB_HIVn_014_grp  = 5
TB_ETB_HIVn_15p_grp  = 6
TB_ETB_HIVp_09_grp   = 7
TB_ETB_HIVp_1014_grp = 8
TB_ETB_HIVp_15p_grp  = 9

TB_Pulmonary_count = 10


TB_Pulmonary_list = [
    TB_PTB_HIVn_014_grp, 
    TB_PTB_HIVn_15p_grp, 
    TB_PTB_HIVp_09_grp, 
    TB_PTB_HIVp_1014_grp,
    TB_PTB_HIVp_15p_grp, 
    TB_ETB_HIVn_014_grp, 
    TB_ETB_HIVn_15p_grp, 
    TB_ETB_HIVp_09_grp, 
    TB_ETB_HIVp_1014_grp,
    TB_ETB_HIVp_15p_grp 
]


TB_ScreenedNum         = 0
TB_ScreenedNumReferred = 1
TB_ScreenedTP          = 2
TB_ScreenedFP          = 3
TB_ScreenedTrueCases   = 4
TB_ScreenedNNTS        = 5
TB_ScreenedTPFP        = 6
TB_ScreenedTPMissed    = 7
TB_ScreenOutputLen     = 8

TB_DiagnosisNum       = 0 
TB_DiagnosisConfirmed = 1
TB_DiagnosisTP        = 2
TB_DiagnosisFP        = 3
TB_DiagnosisTrueCases = 4
TB_DiagnosisNNTT      = 5
TB_DiagnosisTPFP      = 6
TB_DiagnosisTPMissed  = 7
TB_DiagnosisLen       = 8  

TB_ClinicallyAssessed = 0
TB_ReferredDx         = 1  
TB_DiagnosisTB        = 2  
TB_TreatmentInit      = 3
TB_PatientTargPopLen  = 4          


# ART cohorts
TB_ARTCohort_A09_NotSeriouslyIll   = 1
TB_ARTCohort_A1014_NotSeriouslyIll = 2
TB_ARTCohort_A15p_NotSeriouslyIll  = 3
TB_ARTCohort_A09_SeriouslyIll      = 4
TB_ARTCohort_A1014_SeriouslyIll    = 5
TB_ARTCohort_A15p_SeriouslyIll     = 6


# Clinical assessment algorithm used
TB_ClinicalAssessment = 1  # Clinical assessment: any symptom 
TB_ChestXRay          = 2  # Chest X-ray [ digital (dxr) vs conventional (cxr) ] [ screening test ]
TB_ComputerAidedDtct  = 3  # Computer-aided detection software for automated reading of digital chest radiographs [ screening test ]
TB_W3SS               = 4  # W3SS (3 symptom) single screening algorithm
TB_4SymptomScreening  = 5  # 4 symptom screening (no test) / History and physical examination and information on TB
TB_C_ReactiveProtein  = 6  # C-reactive protein with a cut-off of > 5 mg/L [ screening test ]
TB_ClinicalExtraPulm  = 7  # Clinical assessment: any extra-pulmonary TB symptom* 
TB_W4SS               = 8  # W4SS
TB_SingleSymptomScrn  = 9  # Single Symptom screening
TB_TuberculinSkinTest = 10 # Tuberculin Skin Test (TST) 
TB_AntigenSkinTest    = 11 # TB antigen-based skin tests for the diagnosis of TB infection (TBST)  *, 0% 
TB_IGRA               = 12 # Interferon-Gamma Release Assay (IGRA)*, 100%
TB_mWRDPrevGT10       = 13 # mWRD single screening algorithm for medical inpatients in settings with TB prevalence > 10%
TB_FirstlinePreferred = 14 # First-line regimen (preferred): TDF + 3TC (or FTC) + DTG
TB_FirstlineAltern    = 15 # First-line regimen (alternative): TDF + 3TC + EFV 400 mg
TB_SpecialCircTDF_EFV = 16 # Special circumstances: TDF + 3TC (or FTC) + EFV 600mg
TB_SpecialCircAZT     = 17 # Special circumstances:  AZT + 3TC+ EFV 600mg
TB_SpecialCircTDF_PI  = 18 # Special circumstances:  TDF + 3TC (or FTC)+ PI
TB_SpecialCircTDF_RAL = 19 # Special circumstances:  TDF + 3TC (or FTC)+  RAL
TB_SpecialCircTAF     = 20 # Special circumstances:  TAF + 3TC (or FTC)+ DTG
TB_SpecialCircABC     = 21 # Special circumstances:  ABC+ 3TC + DTG
TB_FirstlineABC_DTG   = 22 # First-line regimen (preferred):  ABC + 3TC + DTG
TB_FirstlineABC_LPV   = 23 # First-line regimen (alternative): ABC + 3TC + LPV/r
TB_FirstlineTAF_DTG   = 24 # First-line regimen (alternative): TAF + 3TC (or FTC) + DTG
TB_SpecialCircABC_EFV = 25 # Special circumstances:  ABC+ 3TC + EFV (or NVP)
TB_SpecialCircABC_RAL = 26 # Special circumstances: ABC + 3TC + RAL
TB_SpecialCircAZT_LPV = 27 # Special circumstances: AZT + 3TC + EFV(or NVP)
TB_SpecialCircAZT_EFV = 28 # Special circumstances: AZT + 3TC + LPV/r (or RAL)


#TB Screening methods
TB_ScrnAnySympCXRMeth = 0
TB_ScrnW3SSMeth       = 1
TB_ScrnW4SSCRPMeth    = 2
TB_ScrnClinicAssMeth  = 3


#TB notification case types
TB_NewCases                       = 0
TB_NewBacterConfirmCases          = 1 #Pulmonary, bacteriologically confirmed
TB_NewClinicDiagCases             = 2 #Pulmonary, clinically diagnosed,
TB_NewExtrapulmonaryCases         = 3 #Extrapulmonary,
TB_RelapseCases                   = 4 #  
TB_RelapseBacterConfirmCases      = 5 #Pulmonary, bacteriologically confirmed
TB_RelapseClinicDiagCases         = 6 #Pulmonary, clinically diagnosed,
TB_RelapseExtrapulmonaryCases     = 7 #Extrapulmonary,
TB_NewAndRelapsedCases            = 8 #
TB_PrevTreatExcludeRelapseCases   = 9 #Previously treated, excluding relapse
TB_PrevTreatIncludeRelapseCases   = 10 #Previously treated, including relapse
#Split by age*                    
TB_NewRelapse0_9Cases             = 11 #Children 0-9 years\, 
TB_NewRelapse10_14Cases           = 12 #Children 10-14 years\, new and relapse
TB_NewRelapse15pCases             = 13 #Adults 15+ years
#Split by HIV status*             
TB_HIVpCases                      = 14 #HIV+
TB_HIVp15pCases                   = 15 #HIV+ Adults 15+ years
TB_HIVp0_14Cases                  = 16 #HIV+ Children 0-14 years
TB_HIVpNeonateCases               = 17 #HIV+ Neonates
TB_NotOnARTCases                  = 18 #Not on ART
TB_OnARTCases                     = 19 #On ART
TB_OnART15pCases                  = 20 #On ART Adults 15+ years, failing this frst-line regimen 
TB_OnARRT0_14Cases                = 21 #On ART Children 0-14 years, failing this first-line regimen
TB_OnARTNeonateCases              = 22 #On ART Neonates, failing this first-line regimen
TB_HIVpExcludeART                 = 23 #Proportion HIVp in pop that excludes ART
TB_NotificationCaseCount = 24


TB_AbbottRealTimeMTB  = 0  # Abottv Real TIME MTB and MTB RIF/INH assays (Abbott Laboratories, Abbott Park, USA) - only on sputum sample
TB_BDMAXMDRTBAssay    = 1  # BD MAX MDR-TB assay (Becton, Dickinson and Company, Franklin Lakes, USA) - only on sputum sample
TB_BloodBoneMarrow    = 2  # blood or bone marrow
TB_CerebrospinalFluid = 3  # cerebrospinal fluid (CSF) and lumbar puncture
TB_CultureBactConfirm = 4  # Culture (liquid) - for bacteriological confirmation
TB_CultureDiagTB      = 5  # Culture (liquid) for diagnosis of TB
TB_DiagKidAspirates   = 6  # Diagnostic procedure (children)  - gastric aspirates [recommended for < 7 years]
TB_DiagKidSputum      = 7  # Diagnostic procedure (children)  - Induced sputum 
TB_DiagKidnasopharyn  = 8  # Diagnostic procedure (children)  - nasopharyngeal aspiration [recommended for < 7 years]
TB_DiagKidBronchos    = 9  # Diagnostic procedure (children) - Bronchoscopy (Bronchoalveolar lavage)
TB_DiagKidGasLavage   = 10 # Diagnostic procedure (children)  -gastric lavage [recommended for < 7 years]
TB_DiagKidStools      = 11 # Diagnostic procedure (children) - Stools sampling + Xpert MTB/RIF or Ultra)
TB_Disseminated       = 12 # Disseminated TB
TB_FineNeedleAspir    = 13 # Fine-needle aspiration or biopsy other than lymph node
TB_HainFlouroType     = 14 # Hain FluoroType MTBDR assay (Bruker/Hain Lifescience, Nehren, Germany) - only on sputum sample
TB_LymphNodeAspirate  = 15 # Lymph node aspirate
TB_LymphNodeBiopsy    = 16 # Lymph node biopsy
TB_MicroscopyConvent  = 17 # Microscopy conventional
TB_MicroscopyLED      = 18 # Microscopy LED
TB_ModCmplxAbbott     = 19 # Moderate complexity automated NAAT: Abbott RealTime MTB and MTB RIF/INH assays (Abbott Laboratories, Abbott Park, USA)
TB_ModCmplxBDMAXMDR   = 20 # Moderate complexity automated NAAT: BD MAX MDR-TB assay (Becton, Dickinson and Company, Franklin Lakes, USA)
TB_ModCmplxHainFlouro = 21 # Moderate complexity automated NAAT: Hain FluoroType MTBDR assay (Bruker/Hain Lifescience, Nehren, Germany)
TB_ModCmplxRocheCobas = 22 # Moderate complexity automated NAAT: Roche cobas MTB and MTB-RIF/INH assays (Hoffmann-La Roche, Basel, Switzerland)
TB_OtherTypes         = 23 # Other types of TB
TB_PericardialFluid   = 24 # Pericardial fluid
TB_PeritonealFluid    = 25 # Peritoneal fluid
TB_PlueralFluid       = 26 # Pleural fluid
TB_RocheCobasMTBAssay = 27 # Roche cobas MTB and MTB-RIF/INH assays (Hoffmann-La Roche, Basel, Switzerland) - only on sputum sample
TB_SerosalFluid       = 28 # Serosal fluid aspirate with serosal tissue biopsy
TB_SynovialFluid      = 29 # Synovial fluid
TB_MeningitisTesting  = 30 # TB meningitis testing
TB_TissueBiopsy       = 31 # TB tissue biopsy or aspirates 
TB_LAMPEikenChemical  = 32 # TB-LAMP; Eiken Chemical, Tokyo, Japan
TB_LAMPEikenSputum    = 33 # TB-LAMP; Eiken Chemical, Tokyo, Japan - only on sputum sample
TB_TruenatMTB_mWRD    = 34 # Truenat MTB  (mWRD)
TB_TruenatMTB_Sputum  = 35 # Truenat MTB  (mWRD) - only on sputum sample
TB_TruenatMTBp_mWRD   = 36 # Truenat MTB Plus  (mWRD)
TB_TruenatMTBp_Sputum = 37 # Truenat MTB Plus  (mWRD) - only on sputum sample
TB_Urine              = 38 # Urine (for tract TB detection only)
TB_XpertMTB_RIF       = 39 # Xpert MTB/RIF (mWRD)
TB_XpertUltra         = 40 # Xpert Ultra  (mWRD)
TB_CD4Count           = 41 # CD4 count
TB_LFLAM              = 42 # LF-LAM [ Biomarker-based lateral flow lipoarabinomannan assay (LF-LAM) test (Alere Determine TB LAM Ag, USA
TB_TruenatMTB_RIF     = 43 # Truenat MTB RIF D x  (mWRD)  
TB_ConcurrentPLHIV    = 44 # Concurrent testing in PLHIV: LC-aNAAT + LF-LAM	44
TB_ConcurrentChildren = 45 # Concurrent testing in children: LC-aNAAT on respiratory sample (i.e. sputum) + stool	45
TB_ConcurrentCLHIV    = 46 # Concurrent testing in CLHIV: LC-aNAAT on respiratory sample  + LC-aNAAT on stool + LF-LAM	46


#TB Diagnostic methods
TB_MethodOnlySputum        = 0 # mWRD [ all samples ] and Moderate complexity automated NAAT [ MC- aNAAT ] [ only on sputum samples ] [ Choice ]
TB_MethodDiagProcTBInKids  = 1 # Diagnostic procedure\, pulmonary TB evaluation in children
TB_MethodMicroscopyCulture = 2 # Microscropy (conventional vs LED) and culture
TB_MethodmWRDModComplex    = 3 # mWRD and Moderate complexity automated NAAT [ MC - aNAAT] [ choice ]*
TB_MethodNonSputumETB      = 4 # Non-sputum sample extraction for EPTB
TB_MethodmWRD_ETB          = 5 # mWRD and Moderate complexity automated NAAT (choice) with sample extraction for EPTB
TB_MethodLAM_mWRD          = 6 # LF-LAM followed by mWRD 
TB_MethodLAM_LAMP          = 7 # LF-LAM\, TB-LAMP\, CD4-count
TB_MethodCustom            = 8 # Custom method     



TB_TotalContacts      = 0
TB_DiseaseInfectCntct = 1
TB_InfectionCntct     = 2 
TB_DiseaseCntct       = 3
TB_PulmTBCntct        = 4
TB_ContactLen         = 5

TB_HH0_4  = 0 
TB_HH5_14 = 1
TB_HH15p  = 2
TB_HHAgeLen = 3
TB_HHList= [
    TB_HH0_4  , 
    TB_HH5_14 ,
    TB_HH15p
]

TB_ART0_9  = 0 
TB_ART10_14 = 1
TB_ART15p  = 2
TB_ARTAgeLen = 3
TB_ARTAgeList = [
    TB_ART0_9,
    TB_ART10_14,
    TB_ART15p
]

TB_ARTNotServere    = 0
TB_ARTSevereIllness = 1
TB_ARTSevereLen     = 2


TB_NumEligibleScreen = 0
TB_NumScreened       = 1
TB_NumReferredDiag   = 2 
TB_NumDiagPulmTB     = 3
TB_NumInitTreatment  = 4
TB_NumEligibleEval   = 5
TB_NumTestedInfect   = 6
TB_NumConfirmInfect  = 7
TB_NumInitTPT        = 8
TB_TargetPopLen      = 9


TB_ART_LHIV_Num = 0
TB_ART_PercWithoutSerIll = 1
TB_ART_LHIV_Len = 2


TB_ART_WithTBInfection = 0
TB_ART_WithTBDisease   = 1
TB_ART_PercPTB         = 2
TB_ART_Charac_len      = 3

TB_SEN = 0
TB_MDR = 1
TB_ResistanceLen = 2

TB_ResistAge0_14 = 0
TB_ResistAge15p  = 1
TB_ResistAgeLen  = 2

TB_NewCases=0
TB_RetreatCases = 1
TB_NewRetreatLen = 2




TB_Rif_Sen = 0
TB_INH_Sen = 1
TB_INH_Res = 2
TB_Rif_Res = 3
TB_FQ_Sen  = 4
TB_FQ_Res  = 5
TB_XDR     = 6
TB_ResistProfileLen = 7


TB_Cov_RR_DST_PTB          =  0
TB_Cov_RR_DST_ETB          =  1
TB_Cov_INH_RR_Sens_DST_PTB =  2
TB_Cov_INH_RR_Sens_DST_ETB =  3
TB_Cov_FQ_RR_Res_DST_PTB   =  4
TB_Cov_FQ_RR_Res_DST_ETB   =  5
TB_Cov_BDQ_RR_Res_DST_PTB  =  6
TB_Cov_BDQ_RR_Res_DST_ETB  =  7
TB_Cov_BDQ_FQ_Res_DST_PTB  =  8
TB_Cov_BDQ_FQ_Res_DST_ETB  =  9
TB_Cov_LZD_RR_Res_DST_PTB  = 10
TB_Cov_LZD_RR_Res_DST_ETB  = 11
TB_Cov_LZD_FQ_Res_DST_PTB  = 12
TB_Cov_LZD_FQ_Res_DST_ETB  = 13
TB_Cov_EMC_XDR_DST_XDR     = 14
TB_Cov_EMC_RR_Res_DST_TB   = 15
TB_Cov_ETO_XDR_DST_XDR     = 16
TB_Cov_ETO_RR_Res_DST_TB   = 17
TB_Cov_PZA_XDR_DST_XDR     = 18
TB_Cov_PZA_RR_Res_DST_TB   = 19
TB_CovXDR_BDQ_LZD_MOX      = 20
TB_CoverageLen = 21

TB_NumTestPTB_RIF_INH_MDR    = 0
TB_NumTestPTB_INHMDR_RIFSens = 1
TB_NumTestPTB_FQ_RIF_MDR     = 2
TB_NumTestPTB_BDQ_RIF_MDR    = 3
TB_NumTestPTB_BDQ_FQ_MDR     = 4
TB_NumTestPTB_LZD_RIF_MDR    = 5
TB_NumTestPTB_LZD_FQ_MDR     = 6
TB_NumTestETB_RIF_INH_MDR    = 7
TB_NumTestETB_INHMDR_RIFSens = 8
TB_NumTestETB_FQ_RIF_MDR     = 9
TB_NumTestETB_BDQ_RIF_MDR    = 10
TB_NumTestETB_BDQ_FQ_MDR     = 11
TB_NumTestETB_LZD_RIF_MDR    = 12
TB_NumTestETB_LZD_FQ_MDR     = 13
TB_NumTextXDR_Amikacin       = 14
TB_NumTextXDR_Ethionamide    = 15
TB_NumTextXDR_Pyrazinamide   = 16
TB_NumTextXDR_BDQ_LZD_MOX    = 17

TB_NumTestLen = 18

TB_NumConfRIF_INHSen      = 0
TB_NumConfRIFSen_INHMDR   = 1			
TB_NumConfRIFMDR_FQSen    = 2
TB_NumConfRIFMDR_FQMDR    = 3
TB_NumConfAtLeastOne      = 4
TB_NumConfMeningitisPeri  = 5
TB_NumConfResistLen       = 6 

TB_Child = 0
TB_Adult = 1
TB_ChildAdultLen = 2

TB_PTB = 0
TB_ETB = 1
TB_PulLen = 2

#HIV TB CoInfection
TB_HIVCoInf             = 0 # Number PLHIV with TB 
TB_HIVCoInfAdult        = 1 # Number PLHIV with TB, adults';
TB_HIVCoInfChild        = 2 # Number PLHIV with TB, children';
TB_HIVCoInfNeonates     = 3 # Number PLHIV with TB, neonates';
TB_HIVCoInfFailAdult    = 4 # Number failing this first-line HIV regimen: TDF + 3TC (or FTC) + DTG, adults';
TB_HIVCoInfFailChild    = 5 # Number failing this first-line HIV regimen: TDF + 3TC (or FTC) + DTG, children';
TB_HIVCoInfFailNeonates = 6 # Number failing this first-line HIV regimen: TDF + 3TC (or FTC) + DTG, neonates';
TB_HIVCoInfLen = 7


# Scenarios 
TB_AvgProbDetect      = 0 
TB_AvgProbReceivPrvnt = 1
TB_TreatmentSuccess   = 2
TB_ScenarioLen = 3
   
# 
TB_Counterfactual = 0 
TB_Scaleup        = 1
TB_Difference     = 2
TB_ImpactResultLen = 3

TB_ResLowerIdx   = 0
TB_ResMidIdx   = 1 
TB_ResUpperIdx = 2
TB_ResSdIdx    = 3 
TB_ResultBounds = 4

TB_Scrn_g_sym_cgh2w = 'g_sym_cgh2w'
TB_Scrn_g_sym_any = 'g_sym_any'
TB_Scrn_g_mwrd_sn = 'g_mwrd_sn'
TB_Scrn_g_sym_cgh2w_cxr_tb_sequential_pos = 'g_sym_cgh2w_cxr_tb_sequential_pos'
TB_Scrn_g_sym_cgh2w_cxr_tb_sequential_neg = 'g_sym_cgh2w_cxr_tb_sequential_neg'
TB_Scrn_g_sym_cgh2w_cxr_tb_parallel = 'g_sym_cgh2w_cxr_tb_parallel'
TB_Scrn_g_sym_cgh2w_cxr_cad_sequential_pos = 'g_sym_cgh2w_cxr_cad_sequential_pos'
TB_Scrn_g_sym_cgh2w_cxr_cad_sequential_neg = 'g_sym_cgh2w_cxr_cad_sequential_neg'
TB_Scrn_g_sym_cgh2w_cxr_cad_parallel = 'g_sym_cgh2w_cxr_cad_parallel'
TB_Scrn_g_sym_any_cxr_tb_sequential_pos = 'g_sym_any_cxr_tb_sequential_pos'
TB_Scrn_g_sym_any_cxr_tb_sequential_neg = 'g_sym_any_cxr_tb_sequential_neg'
TB_Scrn_g_sym_any_cxr_tb_parallel = 'g_sym_any_cxr_tb_parallel'
TB_Scrn_g_sym_any_cxr_cad_sequential_pos = 'g_sym_any_cxr_cad_sequential_pos'
TB_Scrn_g_sym_any_cxr_cad_sequential_neg = 'g_sym_any_cxr_cad_sequential_neg'
TB_Scrn_g_sym_any_cxr_cad_parallel = 'g_sym_any_cxr_cad_parallel'
TB_Scrn_h_clhiv_sym = 'h_clhiv_sym'
TB_Scrn_h_hiv_mwrd_sn = 'h_hiv_mwrd_sn'
TB_Scrn_h_hiv_w4ss = 'h_hiv_w4ss'
TB_Scrn_h_hiv_crp = 'h_hiv_crp'
TB_Scrn_h_hiv_cxr_abn = 'h_hiv_cxr_abn'
TB_Scrn_h_hiv_w4ss_hiv_crp_sequential_pos = 'h_hiv_w4ss_hiv_crp_sequential_pos'
TB_Scrn_h_hiv_w4ss_hiv_crp_sequential_neg = 'h_hiv_w4ss_hiv_crp_sequential_neg'
TB_Scrn_h_hiv_w4ss_hiv_crp_parallel = 'h_hiv_w4ss_hiv_crp_parallel'
TB_Scrn_h_hiv_w4ss_hiv_cxr_abn_sequential_pos = 'h_hiv_w4ss_hiv_cxr_abn_sequential_pos'
TB_Scrn_h_hiv_w4ss_hiv_cxr_abn_sequential_neg = 'h_hiv_w4ss_hiv_cxr_abn_sequential_neg'
TB_Scrn_h_hiv_w4ss_hiv_cxr_abn_parallel = 'h_hiv_w4ss_hiv_cxr_abn_parallel'
TB_Scrn_h_hiv_w4ss_cxr_cad_sequential_pos = 'h_hiv_w4ss_cxr_cad_sequential_pos'
TB_Scrn_h_hiv_w4ss_cxr_cad_sequential_neg = 'h_hiv_w4ss_cxr_cad_sequential_neg'
TB_Scrn_h_hiv_w4ss_cxr_cad_parallel = 'h_hiv_w4ss_cxr_cad_parallel'
TB_Scrn_c_cc_sym = 'c_cc_sym'
TB_Scrn_c_cc_cxr_tb = 'c_cc_cxr_tb'
TB_Scrn_c_hiv_w4ss_cc_cxr_tb_sequential_pos = 'c_hiv_w4ss_cc_cxr_tb_sequential_pos'
TB_Scrn_c_hiv_w4ss_cc_cxr_tb_sequential_neg = 'c_hiv_w4ss_cc_cxr_tb_sequential_neg'
TB_Scrn_c_hiv_w4ss_cc_cxr_tb_parallel = 'c_hiv_w4ss_cc_cxr_tb_parallel'
TB_Scrn_c_hiv_w4ss_cxr_cad_sequential_pos = 'c_hiv_w4ss_cxr_cad_sequential_pos'
TB_Scrn_c_hiv_w4ss_cxr_cad_sequential_neg = 'c_hiv_w4ss_cxr_cad_sequential_neg'
TB_Scrn_c_hiv_w4ss_cxr_cad_parallel = 'c_hiv_w4ss_cxr_cad_parallel'
TB_Scrn_1Step_custom = '1step_custom'
TB_Scrn_2Step_custom = '2step_custom'
TB_Scrn_custom       = 'custom_'



TB_Cust_Scrn_cxr_abn     = 'cxr_abn'
TB_Cust_Scrn_cxr_tb      = 'cxr_tb'
TB_Cust_Scrn_cxr_cad     = 'cxr_cad'
TB_Cust_Scrn_sym_cgh2w   = 'sym_cgh2w'
TB_Cust_Scrn_sym_cghany  = 'sym_cghany'
TB_Cust_Scrn_sym_any     = 'sym_any'
TB_Cust_Scrn_mwrd_sn     = 'mwrd_sn'
TB_Cust_Scrn_cxr_second  = 'cxr_second'
TB_Cust_Scrn_hiv_w4ss    = 'hiv_w4ss'
TB_Cust_Scrn_hiv_cxr_abn = 'hiv_cxr_abn'
TB_Cust_Scrn_hiv_crp     = 'hiv_crp'
TB_Cust_Scrn_hiv_mwrd_sn = 'hiv_mwrd_sn'
TB_Cust_Scrn_clhiv_sym   = 'clhiv_sym'
TB_Cust_Scrn_cc_sym      = 'cc_sym'
TB_Cust_Scrn_cc_cxr_tb   = 'cc_cxr_tb'
TB_Cust_Scrn_ssm_sz      = 'ssm_sz'
TB_Cust_Scrn_xpert       = 'xpert'


TB_Cust_SensSpec = {
    TB_Cust_Scrn_cxr_abn     : (0.94, 0.89),
    TB_Cust_Scrn_cxr_tb      : (0.85, 0.96),
    TB_Cust_Scrn_cxr_cad     : (0.94, 0.89),
    TB_Cust_Scrn_sym_cgh2w   : (0.42, 0.94),
    TB_Cust_Scrn_sym_cghany  : (0.51, 0.88),
    TB_Cust_Scrn_sym_any     : (0.71, 0.64),
    TB_Cust_Scrn_mwrd_sn     : (0.69, 0.99),
    TB_Cust_Scrn_cxr_second  : (0.90, 0.41),
    TB_Cust_Scrn_hiv_w4ss    : (0.83, 0.38),
    TB_Cust_Scrn_hiv_cxr_abn : (0.93, 0.20),
    TB_Cust_Scrn_hiv_crp     : (0.90, 0.50),
    TB_Cust_Scrn_hiv_mwrd_sn : (0.69, 0.98),
    TB_Cust_Scrn_clhiv_sym   : (0.61, 0.94),
    TB_Cust_Scrn_cc_sym      : (0.89, 0.69),
    TB_Cust_Scrn_cc_cxr_tb   : (0.84, 0.91),
    TB_Cust_Scrn_ssm_sz      : (0.61, 0.98),
    TB_Cust_Scrn_xpert       : (0.85, 0.98),
}


TB_Sensitivity_index = 0
TB_Specificity_index = 1


TB_Fort_Final_Year = 2050 #  model values are good up to 2030


TB_DynAge0_4   = 0 
TB_DynAge5_9   = 1 
TB_DynAge10_14 = 2 
TB_DynAge15_64 = 3 
TB_DynAge65p   = 4
TB_DynAgeLen   = 5

TB_DynHIVn       = 0
TB_DynHIVpNoART  = 1
TB_DynHIVpOnART  = 2
TB_DynHIVARTLen  = 3

# TB_DynHIVn    = 0 Already declared
TB_DynHIVp    = 1
TB_DynHIVLen  = 2

TB_DynRelapseTreatment = 0 
TB_DynRelapseSelfCure  = 1
TB_DynRelapseGt2Yrs    = 2
TB_DynRelapseLen       = 3

TB_DynPublicSector  = 0 
TB_DynPrivateSector = 1
TB_DynSectorLen     = 2

TB_DynPreExposure  = 0
TB_DynPostExposire = 1
TB_DynExposureLen  = 2


TB_general_public_screenings = [
TB_Cust_Scrn_cxr_abn,	  
TB_Cust_Scrn_cxr_tb,	  
TB_Cust_Scrn_cxr_cad,	  
TB_Cust_Scrn_sym_cgh2w,
TB_Cust_Scrn_sym_cghany,
TB_Cust_Scrn_sym_any,	  
TB_Cust_Scrn_mwrd_sn,	  
TB_Cust_Scrn_cxr_second,
TB_Cust_Scrn_ssm_sz, 
TB_Cust_Scrn_xpert]

TB_PLHIV_screenings = [
TB_Cust_Scrn_hiv_w4ss,	
TB_Cust_Scrn_hiv_cxr_abn,
TB_Cust_Scrn_hiv_crp,	   
TB_Cust_Scrn_hiv_mwrd_sn,
TB_Cust_Scrn_ssm_sz, 
TB_Cust_Scrn_xpert]

TB_CLHIV_screenings = [
TB_Cust_Scrn_clhiv_sym,       
TB_Cust_Scrn_ssm_sz, 
TB_Cust_Scrn_xpert]

TB_child_contact_screenings = [
TB_Cust_Scrn_cc_sym,
TB_Cust_Scrn_cc_cxr_tb,         
TB_Cust_Scrn_ssm_sz, 
TB_Cust_Scrn_xpert]

# Pulmonary TB	
TB_Cust_patient_menu =[ 
 TB_general_public_screenings, #  TB_PTB_HIVn_014_grp, 
 TB_general_public_screenings, #  TB_PTB_HIVn_15p_grp, 
 TB_CLHIV_screenings, #  TB_PTB_HIVp_09_grp, 
 TB_CLHIV_screenings, #  TB_PTB_HIVp_1014_grp, 
 TB_PLHIV_screenings, #  TB_PTB_HIVp_15p_grp, 
# Extra-Pulmonary TB	
 TB_general_public_screenings, # TB_ETB_HIVn_014_grp 
 TB_general_public_screenings, # TB_ETB_HIVn_15p_grp	
 TB_CLHIV_screenings, # TB_ETB_HIVp_09_grp	
 TB_CLHIV_screenings, # TB_ETB_HIVp_1014_grp
 TB_PLHIV_screenings] # TB_ETB_HIVp_15p_grp	

TB_Cust_patient_default =[ 
 TB_general_public_screenings[0], #  TB_general_public_screenings, 
 TB_general_public_screenings[0], #  TB_general_public_screenings, 
 TB_CLHIV_screenings[0], #  TB_CLHIV_screenings, 
 TB_CLHIV_screenings[0], #  TB_CLHIV_screenings, 
 TB_PLHIV_screenings[0], #  TB_PLHIV_screenings, 
# Extra-Pulmonary TB	
 TB_general_public_screenings[0], # TB_ETB_HIVn_014_grp 
 TB_general_public_screenings[0], # TB_ETB_HIVn_15p_grp	
 TB_CLHIV_screenings[0], # TB_ETB_HIVp_09_grp	
 TB_CLHIV_screenings[0], # TB_ETB_HIVp_1014_grp
 TB_PLHIV_screenings[0]] # TB_ETB_HIVp_15p_grp	

# ART cohorts	
TB_Cust_ART_NotSerous_menu =[
	TB_CLHIV_screenings, # Age 0-9 
	TB_CLHIV_screenings, # Age 10-14 
	TB_PLHIV_screenings  # Age 15+ 
]
TB_Cust_ART_Serious_menu = [
    TB_CLHIV_screenings, # Age 0-9 
    TB_CLHIV_screenings, # Age 10-14 
    TB_PLHIV_screenings  # Age 15+ 
]
TB_Cust_ART_menu =[TB_Cust_ART_NotSerous_menu, TB_Cust_ART_Serious_menu]


TB_Cust_ART_NotSerous_default =[
	TB_CLHIV_screenings[0], # Age 0-9 
	TB_CLHIV_screenings[0], # Age 10-14 
	TB_PLHIV_screenings[0] #  Age 15+ 
 ]
TB_Cust_ART_Serious_default = [
    TB_CLHIV_screenings[0], #  Age 0-9 
    TB_CLHIV_screenings[0], #  Age 10-14 
    TB_PLHIV_screenings[0]  #  Age 15+ 
]
TB_Cust_ART_default =[TB_Cust_ART_NotSerous_default, TB_Cust_ART_Serious_default]
#HH contacts	
TB_Cust_HH_menu = [
    TB_child_contact_screenings, # TB_HH0_4	
    TB_child_contact_screenings, # TB_HH5_14	
    TB_general_public_screenings, # TB_HH15p	
]
TB_Cust_HH_default = [
    TB_child_contact_screenings[0], # TB_HH0_4	
    TB_child_contact_screenings[0], # TB_HH5_14	
    TB_general_public_screenings[0], # TB_HH15p	
]
#High risk groups	
TB_Cust_HRG_menu = [
    TB_general_public_screenings, # TB_HRG_Prisoners	    
    TB_general_public_screenings, # TB_HRG_Miners	        
    TB_general_public_screenings, # TB_HRG_SeekingCare	    
    TB_general_public_screenings, # TB_HRG_StructuralRFs	
    TB_general_public_screenings, # TB_HRG_HighTBPrev	    
    TB_general_public_screenings, # TB_HRG_UntreatedFibrosis
]

TB_Cust_HRG_default = [
    TB_general_public_screenings[0], # TB_HRG_Prisoners	    
    TB_general_public_screenings[0], # TB_HRG_Miners	        
    TB_general_public_screenings[0], # TB_HRG_SeekingCare	    
    TB_general_public_screenings[0], # TB_HRG_StructuralRFs	
    TB_general_public_screenings[0], # TB_HRG_HighTBPrev	    
    TB_general_public_screenings[0], # TB_HRG_UntreatedFibrosis
]

TB_NOTIF_DB_KEYS = ['new_labconf', 'new_clindx', 'new_ep', 
                     'ret_rel_labconf','ret_rel_clindx', 'ret_rel_ep',   # Retreatment and relapse patients
                     'ret_nrel',                                         # Retreatment without relapse
                     'c_newinc',                                         # New cases  
                     'newrel_f04', 'newrel_f59',  'newrel_f1014',
                     'newrel_f1519', 'newrel_f2024', 'newrel_f2534',
                     'newrel_f3544', 'newrel_f4554', 'newrel_f5564',
                     'newrel_f65',
                     'newrel_m04', 'newrel_m59',  'newrel_m1014',
                     'newrel_m1519', 'newrel_m2024', 'newrel_m2534',
                     'newrel_m3544', 'newrel_m4554', 'newrel_m5564',
                     'newrel_m65',
                     'ret_rel_labconf', 'ret_rel_clindx', 'ret_rel_ep',
                     'ret_nrel', 'c_newinc', 'newrel_hivpos', 
                     'newrel_art'
                     ]
TB_NOTIF_DIST_KEYS = ['new_labconf_perc', 'ret_rel_labconf_perc']


TB_RUN_DEFAULT_COUNTRIES = None#("ZWE", )

# "ALB",
# "ASM",
# "AND",
# "ABW",
# "BHR",
# "BEL",
# "BMU",
# "VGB",
# "BRN",
# "CYM",
# "COK",
# "CUW",
# "CYP",
# "PRK",
# "GRD",
# "JOR",
# "KWT",
# "LVA",
# "LUX",
# "MDV",
# "MLT",
# "MCO",
# "MNE",
# "MSR",
# "NRU",
# "NIU",
# "NOR",
# "PLW",
# "PRT",
# "QAT",
# "KOR",
# "KNA",
# "SMR",
# "SYC",
# "SGP",
# "SXM",
# "SVK",
# "SVN",
# "SSD",
# "TON",
# "TKM",
# "TCA",
# "TUV",
# "WLF" 
# )