PC_VERSION_TAG          = '<PC_Version_V1>'
PC_DATA_CHANGED_TAG     = '<PC_DataChanged_V1>'
PC_PROJ_VALID_TAG       = '<PC_ProjectionValid_V1>'
PC_FILE_NAME_TAG        = '<PC_FileName_V1>'                        
PC_PROJ_VALID_DATE_TAG  = '<PC_ProjectionValidDate_V1>'   
PC_AREA_DATA_TAG        = '<PC_AreaData_V1>'

PC_COST_CAT_RECORDS_TAG                      = '<PC_CostCategoryRecords_V1>'
PC_COST_INPUT_RECORDS_TAG                    = '<PC_CostInputRecords_V3>'
PC_COSTING_SECT_RECORDS_TAG                  = '<PC_CostingSectionRecords_V2>'
PC_ACT_RECORDS_TAG                           = '<PC_ActivityRecords_V2>'
PC_ACT_LINE_ITEM_RECORDS_TAG                 = '<PC_ActivityLineItemRecords_V1>'
PC_ENTER_COSTING_SECT_COSTS_ALL_YEARS_CS_TAG = '<PC_EnterCostingSectionCostsAllYearsCS_V1>'

# Policy and population level interventions
PC_COSTING_SECT_RECORDS_PPLI_TAG                  = '<PC_CostingSectionRecordsPPLI_V1>'
PC_ACT_RECORDS_PPLI_TAG                           = '<PC_ActivityRecordsPPLI_V1>'
PC_ACT_LINE_ITEM_RECORDS_PPLI_TAG                 = '<PC_ActivityLineItemRecordsPPLI_V1>'

# Results

PC_RES_COSTS_BY_SECT_TAG    = '<PC_ResCostsBySection_V1>'
PC_RES_COSTS_BY_SUBSECT_TAG = '<PC_ResCostsBySubsection_V1>'
PC_RES_COSTS_BY_ACT_TAG     = '<PC_ResCostsByActivity_V1>'
PC_RES_COSTS_BY_CAT_TAG     = '<PC_ResCostsByCategory_V1>'

PC_RES_COSTS_BY_SECT_PPLI_TAG    = '<PC_ResCostsBySectionPPLI_V1>'
PC_RES_COSTS_BY_SUBSECT_PPLI_TAG = '<PC_ResCostsBySubsectionPPLI_V1>'
PC_RES_COSTS_BY_ACT_PPLI_TAG     = '<PC_ResCostsByActivityPPLI_V1>'
PC_RES_COSTS_BY_CAT_PPLI_TAG     = '<PC_ResCostsByCategoryPPLI_V1>'

# Meta ModVars. The values inside these do not change. 

PC_STD_ROW_INFO_META_TAG = '<PC_StandardRowInfo_Meta_V1>'
PC_HIV_ROW_INFO_META_TAG = '<PC_HIVRowInfo_Meta_V1>'