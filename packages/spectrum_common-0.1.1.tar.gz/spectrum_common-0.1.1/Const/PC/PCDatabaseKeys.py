#######################################################################################################
#                                                                                                     #
#                                       Cost Category DB (CCDB)                                       #
#                                                                                                     #
#######################################################################################################

PC_COST_CAT_ID_KEY_CCDB        = 'costCatID'
PC_COST_CAT_NAME_KEY_CCDB      = 'costCatName'
PC_COST_CAT_STR_CONST_KEY_CCDB = 'costCatStringConstant'

#######################################################################################################
#                                                                                                     #
#                                       Cost Input DB (CIDB)                                          #
#                                                                                                     #
#######################################################################################################

PC_COST_CAT_ID_KEY_CIDB               = 'costCatID'
PC_COST_CAT_NAME_KEY_CIDB             = 'costCatName'
PC_COST_INPUT_ID_KEY_CIDB             = 'costInputID' 
PC_COST_INPUT_NAME_KEY_CIDB           = 'costInputName'
PC_COST_INPUT_STR_CONST_KEY_CIDB      = 'costInputStringConstant'
PC_UNIT_COST_KEY_CIDB                 = 'unitCost'
PC_UNIT_OF_MEASURE_KEY_CIDB           = 'unitOfMeasure'
PC_UNIT_OF_MEASURE_STR_CONST_KEY_CIDB = 'unitOfMeasureStringConstant'
PC_NOTE_KEY_CIDB                      = 'note'
PC_SOURCE_KEY_CIDB                    = 'source'

#######################################################################################################
#                                                                                                     #
#                                       Activity Line Item DB (ALIDB)                                 #
#                                                                                                     #
#######################################################################################################

PC_AREA_TYPE_ID_KEY_ALIDB           = 'areaTypeID'
PC_AREA_TYPE_NAME_KEY_ALIDB         = 'areaTypeName'
PC_AREA_ID_KEY_ALIDB                = 'areaID'
PC_AREA_NAME_KEY_ALIDB              = 'areaName'
PC_COSTING_SECT_ID_KEY_ALIDB        = 'costingSectionID'
PC_COSTING_SECT_NAME_KEY_ALIDB      = 'costingSectionName'
PC_COSTING_SUBSECT_ID_KEY_ALIDB     = 'costingSubsectionID'
PC_COSTING_SUBSECT_NAME_KEY_ALIDB   = 'costingSubsectionName'
PC_ACT_ID_KEY_ALIDB                 = 'activityID'
PC_ACT_NAME_KEY_ALIDB               = 'activityName'
PC_COST_INPUT_ID_KEY_ALIDB          = 'costInputID'
PC_COST_INPUT_NAME_KEY_ALIDB        = 'costInputName'
PC_NUM_UNITS_KEY_ALIDB              = 'numUnits'
PC_DURATION_KEY_ALIDB               = 'duration'
PC_FREQUENCY_KEY_ALIDB              = 'frequency'

#######################################################################################################
#                                                                                                     #
#                                       PPLI Activity Line Item DB (PALIDB)                           #
#                                                                                                     #
#######################################################################################################

PC_AREA_TYPE_ID_KEY_PALIDB           = 'areaTypeID'
PC_AREA_TYPE_NAME_KEY_PALIDB         = 'areaTypeName'
PC_AREA_ID_KEY_PALIDB                = 'areaID'
PC_AREA_NAME_KEY_PALIDB              = 'areaName'
PC_COSTING_SECT_ID_KEY_PALIDB        = 'costingSectionID'
PC_COSTING_SECT_NAME_KEY_PALIDB      = 'costingSectionName'
PC_COSTING_SUBSECT_ID_KEY_PALIDB     = 'costingSubsectionID'
PC_COSTING_SUBSECT_NAME_KEY_PALIDB   = 'costingSubsectionName'
PC_ACT_ID_KEY_PALIDB                 = 'activityID'
PC_ACT_NAME_KEY_PALIDB               = 'activityName'
PC_COST_INPUT_ID_KEY_PALIDB          = 'costInputID'
PC_COST_INPUT_NAME_KEY_PALIDB        = 'costInputName'
PC_NUM_UNITS_KEY_PALIDB              = 'numUnits'
PC_DURATION_KEY_PALIDB               = 'duration'
PC_QUANTITY_KEY_PALIDB               = 'quantity'

#######################################################################################################
#                                                                                                     #
#                                       Activity DB (ADB)                                             #
#                                                                                                     #
#######################################################################################################

PC_AREA_TYPE_ID_KEY_ADB           = 'areaTypeID'
PC_AREA_TYPE_NAME_KEY_ADB         = 'areaTypeName'
PC_AREA_ID_KEY_ADB                = 'areaID'
PC_AREA_NAME_KEY_ADB              = 'areaName'
PC_COSTING_SECT_ID_KEY_ADB        = 'costingSectionID'
PC_COSTING_SECT_NAME_KEY_ADB      = 'costingSectionName'
PC_COSTING_SUBSECT_ID_KEY_ADB     = 'costingSubsectionID'
PC_COSTING_SUBSECT_NAME_KEY_ADB   = 'costingSubsectionName'
PC_ACT_ID_KEY_ADB                 = 'activityID'
PC_ACT_NAME_KEY_ADB               = 'activityName'
PC_ACT_STR_CONST_KEY_ADB          = 'activityStringConstant'

#######################################################################################################
#                                                                                                     #
#                                       Costing Section DB (CSDB)                                     #
#                                                                                                     #
#######################################################################################################

PC_AREA_TYPE_ID_KEY_CSDB              = 'areaTypeID'
PC_AREA_TYPE_NAME_KEY_CSDB            = 'areaTypeName'
PC_AREA_ID_KEY_CSDB                   = 'areaID'
PC_AREA_NAME_KEY_CSDB                 = 'areaName'
PC_COSTING_SECT_ID_KEY_CSDB           = 'costingSectionID'
PC_COSTING_SECT_NAME_KEY_CSDB         = 'costingSectionName'
PC_COSTING_SECT_STR_CONST_KEY_CSDB    = 'costingSectionStringConstant'
PC_COSTING_SUBSECT_ID_KEY_CSDB        = 'costingSubsectionID'
PC_COSTING_SUBSECT_NAME_KEY_CSDB      = 'costingSubsectionName'
PC_COSTING_SUBSECT_STR_CONST_KEY_CSDB = 'costingSubsectionStringConstant'
PC_COSTS_CS_KEY_CSDB                  = 'costsCS'


#######################################################################################################
#                                                                                                     #
#                                       PPLI Phase DB (PPLIPDB)                                       #
#                                                                                                     #
#######################################################################################################

PC_ISO_ALPHA_3_COUNTRY_CODE_KEY_PPLIPDB  = 'ISO3AlphaCountryCode'
PC_PHASE_INTENSITY_RECORDS_KEY_PPLIPDB   = 'phaseIntensityRecords'
PC_AREA_TYPE_ID_KEY_PPLIPDB              = 'areaTypeID'
PC_AREA_ID_KEY_PPLIPDB                   = 'areaID'
PC_COSTING_SECT_ID_KEY_PPLIPDB           = 'costingSectionID'
PC_COSTING_SUBSECT_ID_KEY_PPLIPDB        = 'costingSubsectionID'
PC_PHASE_ID_KEY_PPLIPDB                  = 'phaseID'

#######################################################################################################
#                                                                                                     #
#                                       PPLI Taxation DB (PPLITDB)                                    #
#                                                                                                     #
#######################################################################################################

PC_ISO_ALPHA_3_COUNTRY_CODE_KEY_PPLITDB  = 'ISO3AlphaCountryCode'
PC_PRICE_ELASTICITY_PARAMS_KEY_PPLITDB   = 'priceElasticityParams'

