# Fields used in PC data structures

PC_F_COST_CAT_ID         = 'costCatID'
PC_F_COST_INPUT_ID       = 'costInputID'
PC_F_AREA_ID             = 'areaID'
PC_F_AREA_TYPE_ID        = 'areaTypeID'
PC_F_COSTING_SECT_ID     = 'costingSectionID'
PC_F_COSTING_SUBSECT_ID  = 'costingSubsectionID'
PC_F_ACT_ID              = 'activityID'
PC_F_VALUE               = 'value'

# area data record (main object in PC; basically contains everything you need to know about PC for a given 
# programme area/delivery channel/package/national programme)

PC_AREA_TYPE_MST_ID = 'areaTypeMstID' #int; programme area, delivery channel, etc.
PC_AREA_ID          = 'areaID'        # string; represents programme area, delivery channel, package, or national programme; numeric mstID for defaults. GUID for customs.
PC_MAIN_ROW_COSTS   = 'mainRowCosts'  # list of float, row x year; PCDetailCostingArray on desktop

# cost category records; Groups to which user adds cost inputs.  

PC_COST_CAT_ID        = PC_F_COST_CAT_ID # string, numeric mstID for defaults (still cast as string). GUID for custom ones
PC_COST_CAT_NAME      = 'name'           # string;  Holds custom name or overridden default name.
PC_COST_CAT_STR_CONST = 'stringConstant' # string;  Defaults only. 
PC_COST_CAT_CUSTOM    = 'custom'         # boolean; user-entered = true; default = false.

# cost input records; Items belonging to cost categories that are used for activity line items.

PC_COST_INPUT_CAT_ID                    = PC_F_COST_CAT_ID              # string, numeric mstID for defaults (still cast as string). GUID for custom ones
PC_COST_INPUT_ID                        = PC_F_COST_INPUT_ID            # string; numeric mstID for defaults (still cast as string). GUID for custom ones
PC_COST_INPUT_NAME                      = 'name'                        # string;  Holds custom name or overridden default name.
PC_COST_INPUT_STR_CONST                 = 'stringConstant'              # string;  Defaults only. 
PC_COST_INPUT_UNIT_OF_MEASURE           = 'unitOfMeasure'               # string; Activity cost per "x"
PC_COST_INPUT_UNIT_OF_MEASURE_STR_CONST = 'unitOfMeasureStringConstant' # string;  Defaults only. 
PC_COST_INPUT_UNIT_COST                 = 'unitCost'                    # float
PC_COST_INPUT_NOTE                      = 'note'                        # string
PC_COST_INPUT_SOURCE                    = 'source'                      # string
#PC_COST_INPUT_SOURCE_STR_CONST          = 'stringConstant'             # string;  Defaults only. 
PC_COST_INPUT_CUSTOM                    = 'custom'                      # boolean; user-entered = true; default = false.

# costing section records; Top-level groups for costing.

PC_COSTING_SECT_ID                                = PC_F_COSTING_SECT_ID  # string; numeric mstID for defaults (still cast as string). GUID for custom ones
PC_COSTING_SECT_NAME                              = 'name'                # string;  Holds custom name or overridden default name.
PC_COSTING_SECT_STR_CONST                         = 'stringConstant'      # string;  Defaults only. 
PC_COSTING_SECT_CUSTOM                            = 'custom'              # boolean; user-entered = true; default = false.
PC_COSTING_SECT_SUBSECT_RECORDS                   = 'subsectionRecords'   # list; Subgroup dicts
PC_COSTING_SECT_AREA_TYPE_ID                      = PC_F_AREA_TYPE_ID     # integer; tells us whether it's a module, programme area, etc.
PC_COSTING_SECT_AREA_ID                           = PC_F_AREA_ID          # string; ID of module, programme area, delivery channel, national programme, etc.
PC_COSTING_SECT_ENTRY_MODE_CS                     = 'entryMode'
PC_COSTING_SECT_COSTS_CS                          = 'costs'              
# Policy and population level interventions (PPLI)
PC_COSTING_SECT_PRICE_ELASTICITY_PPLI             = 'priceElasticity'          # list of float (length 2, can be negative, calculated packs change as integer)
PC_COSTING_SECT_INCOME_ELASTICITY_PPLI            = 'incomeElasticity'         # list of float (length 2, calculated packs change as integer)
PC_COSTING_SECT_PRICE_INCOME_ONLY_PPLI            = 'priceIncomeOnly'          # list of integer (length 2, can be negative, percent, calculated packs change only)
PC_COSTING_SECT_NON_PRICE_MEASURES_PPLI           = 'nonPriceMeasures'         # list of integer (length 2, can be negative, percent)
PC_COSTING_SECT_ALL_MPOWER_PPLI                   = 'allMPOWER'                # list of integer (length 2, calculated packs change only)

PC_COSTING_SECT_TAX_ENTRY_MODE_PPLI               = 'taxEntryModeID'           # integer (radio group choice)
PC_COSTING_SECT_REAL_RETAIL_PRICE_PPLI            = 'realRetailPrice'          # list of integer (length 2, projection sometimes calculated)
PC_COSTING_SECT_EXCISE_SHARE_PPLI                 = 'exciseShare'              # list of integer (length 2, percent, projection sometimes calculated)
PC_COSTING_SECT_TAX_SHARE_PPLI                    = 'taxShare'                 # list of integer (length 2, percent, projection sometimes calculated)
PC_COSTING_SECT_REAL_EXCISE_PER_PACK_PPLI         = 'realExcisePerPack'        # list of integer (length 2, calculated)
PC_COSTING_SECT_REAL_TAX_PER_PACK_PPLI            = 'realTaxPerPack'           # list of integer (length 2, calculated)
PC_COSTING_SECT_REAL_INDUSTRY_PRICE_PPLI          = 'realIndustryPrice'        # list of integer (length 2, calculated)
PC_COSTING_SECT_TAX_ADJUST_CONSUMP_PPLI           = 'taxAdjustedConsumption'   # list of integer (length 2, projection calculated)
PC_COSTING_SECT_EXCISE_REVENUE_PPLI               = 'exciseRevenue'            # list of integer (length 2, projection calculated)
PC_COSTING_SECT_TAX_REVENUE_PPLI                  = 'taxRevenue'               # list of integer (length 2, projection calculated)
PC_COSTING_SECT_USAGE_RATE_PPLI                   = 'usageRate'                # list of float (length 2, percent, projection claculated as a float)
PC_COSTING_SECT_NUM_USERS                         = 'numUsers'                 # list of integer (length 2, calculated)

PC_COSTING_SECT_REAL_RETAIL_PRICE_PPLI            = 'realRetailPrice'          # list of integer (length 2)

# costing subsection records; Second-level groups for costing that belong to costing sections.

PC_COSTING_SUBSECT_ID         = PC_F_COSTING_SUBSECT_ID  # string; numeric mstID for defaults (still cast as string). GUID for custom ones
PC_COSTING_SUBSECT_NAME       = 'name'                   # string;  Holds custom name or overridden default name.
PC_COSTING_SUBSECT_STR_CONST  = 'stringConstant'         # string;  Defaults only. 
PC_COSTING_SUBSECT_CUSTOM     = 'custom'                 # boolean; user-entered = true; default = false.
# Policy and population level interventions (PPLI)
PC_COSTING_SUBSECT_ADMIN_UNITS_PER_LEVEL_OPTION_PPLI          = 'numAdminUnitsPerLevelOption' # integer
PC_COSTING_SUBSECT_ADMIN_UNITS_STD_POP_SIZE_PPLI              = 'adminUnitsStdPopSize' # 1D list of integer; by health system admin unit
PC_COSTING_SUBSECT_ENTER_TOTAL_INPUTS_PER_ADMIN_REG_YEAR_PPLI = 'enterTotalInputsPerAdminRegYear' # boolean

PC_COSTING_SUBSECT_RAISE_TAXES_PRICE_PPLI            = 'raiseTaxesPrice'          # list of integer; by year
PC_COSTING_SUBSECT_RAISE_TAXES_EXCISE_SHARE_PPLI     = 'raiseTaxesExciseShare'    # list of integer; by year
PC_COSTING_SUBSECT_RAISE_TAXES_TAX_SHARE_PPLI        = 'raiseTaxesTaxShare'       # list of integer; by year
PC_COSTING_SUBSECT_PHASE_INTENSITY_VALUES_PPLI       = 'phaseIntensityValues'     # 2d list of integer; phase/intensity type x year

# activity records; Third-level groups for costing that belong to costing subsection records. Activity line items are added to these.

PC_ACT_ID                 = PC_F_ACT_ID             # string; numeric mstID for defaults (still cast as string). GUID for custom ones
PC_ACT_NAME               = 'name'                  # string;  Holds custom name or overridden default name.
PC_ACT_STR_CONST          = 'stringConstant'        # string;  Defaults only. 
PC_ACT_AREA_TYPE_ID       = PC_F_AREA_TYPE_ID       # integer; tells us whether it's a module, programme area, etc.
PC_ACT_AREA_ID            = PC_F_AREA_ID            # string; ID of module, programme area, delivery channel, national programme, etc.
PC_ACT_COSTING_SECT_ID    = PC_F_COSTING_SECT_ID    # string; numeric mstID for defaults (still cast as string). GUID for custom ones
PC_ACT_COSTING_SUBSECT_ID = PC_F_COSTING_SUBSECT_ID # string; numeric mstID for defaults (still cast as string). GUID for custom ones
PC_ACT_CUSTOM             = 'custom'                # boolean; user-entered = true; default = false.

# activity line item (ALI) records; Items based on cost inputs that the user adds to activities.

PC_ALI_COST_INPUT_ID      = PC_F_COST_INPUT_ID   # string; numeric mstID for defaults (still cast as string). GUID for custom ones
PC_ALI_ACT_ID             = PC_F_ACT_ID             # string; numeric mstID for defaults (still cast as string). GUID for custom ones
PC_ALI_AREA_TYPE_ID       = PC_F_AREA_TYPE_ID       # integer; tells us whether it's a module, programme area, etc.
PC_ALI_AREA_ID            = PC_F_AREA_ID            # string; ID of module, programme area, delivery channel, national programme, etc.
PC_ALI_COSTING_SECT_ID    = PC_F_COSTING_SECT_ID    # string; numeric mstID for defaults (still cast as string). GUID for custom ones
PC_ALI_COSTING_SUBSECT_ID = PC_F_COSTING_SUBSECT_ID # string; numeric mstID for defaults (still cast as string). GUID for custom ones
PC_ALI_NUM_UNITS          = 'numUnits'              # integer
PC_ALI_DURATION           = 'duration'              # integer
PC_ALI_FREQUENCY          = 'frequency'             # list of integer
# Policy and population level interventions (PPLI)
PC_ALI_QUANTITY_PER_ADMIN_REG_YEAR_PPLI = 'quantityPerAdminRegYear' # 2D list of float; health sys admin unit (dynamic) x year