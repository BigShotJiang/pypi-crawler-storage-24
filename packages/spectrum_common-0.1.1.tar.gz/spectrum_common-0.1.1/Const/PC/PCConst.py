
import SpectrumCommon.Const.PC.PCConstLink as pccl

# Database latest versions
PC_COST_CAT_DB_CURR_VERSION                = 'V6'
PC_COST_INPUT_DB_CURR_VERSION              = 'V7'#'Testing'
PC_ACTIVITY_DB_CURR_VERSION                = 'V7'
PC_ACTIVITY_LINE_ITEM_DB_CURR_VERSION      = 'V4'#Testing
PC_PPLI_ACTIVITY_LINE_ITEM_DB_CURR_VERSION = 'V2'
PC_COSTING_SECT_DB_CURR_VERSION            = 'V10'
PC_PPLI_PHASE_DB_CURR_VERSION              = 'V2'
PC_PPLI_TAXATION_DB_CURR_VERSION           = 'V1'

# Database names (also the names of the sheets in PCModData.xlsx)
PC_COST_CAT_DB_NAME                = 'CostCategoryDB'
PC_COST_INPUT_DB_NAME              = 'CostInputDB'
PC_ACTIVITY_DB_NAME                = 'ActivityDB'
PC_ACTIVITY_LINE_ITEM_DB_NAME      = 'ActivityLineItemDB' 
PC_PPLI_ACTIVITY_LINE_ITEM_DB_NAME = 'PPLIActivityLineItemDB' 
PC_COSTING_SECT_DB_NAME            = 'CostingSectionDB'
PC_PPLI_PHASE_DB_NAME              = 'PPLIPhaseDB'
PC_PPLI_TAXATION_DB_NAME           = 'PPLITaxationDB'

# Database directories for data by country. Files in these folders are named using the 3 letter iso country codes instead of the database names above.
PC_PPLI_PHASES_DB_DIR          = r'PPLIPhases\countries'
PC_PPLI_TAXATION_DB_DIR        = r'PPLITaxation\countries'

#######################################################################################################
#                                                                                                     #
#                                       Programme costing (PC) rows                                   #
#                                                                                                     #
#######################################################################################################

# row current IDs for standard programme areas; NOTE: These only include rows with data attached. UI-only rows are skipped.

PC_PROG_SPEC_HR_HEADER_ROW_CURR_ID         = 1
PC_NAT_LEVEL_STAFF_ROW_CURR_ID	  	       = 2
PC_REG_LEVEL_STAFF_ROW_CURR_ID   	       = 3
PC_DIST_LEVEL_STAFF_ROW_CURR_ID	 	       = 4
PC_TRAIN_HEADER_ROW_CURR_ID                = 5
PC_INSERV_REFRESH_TRAIN_ROW_CURR_ID        = 6
PC_TRAIN_OF_TRAIN_ROW_CURR_ID              = 7
PC_DEV_TRAIN_PROG_MAT_ROW_CURR_ID          = 8
PC_CHANGE_PRESERV_TRAIN_CURRIC_ROW_CURR_ID = 9
PC_SUPP_ACT_ROW_CURR_ID                    = 10
PC_SUPERVIS_HEADER_ROW_CURR_ID             = 11
PC_COORD_MEET_ROW_CURR_ID                  = 12
PC_NAT_STAFF_VISIT_LOCAL_ROW_CURR_ID       = 13
PC_MONITOR_EVAL_HEADER_ROW_CURR_ID         = 14
PC_DESIGN_ME_FRAME_SYS_ROW_CURR_ID         = 15
PC_DESIGN_QC_QA_ROW_CURR_ID                = 16
PC_DESIGN_REV_DATA_MGMT_SYS_ROW_CURR_ID    = 17
PC_DATA_COLLECT_ANALYSIS_ROW_CURR_ID       = 18
PC_QC_QA_ROW_CURR_ID                       = 19
PC_INFRA_EQUIP_HEADER_ROW_CURR_ID          = 20
PC_SIT_ASSESS_INFRA_ROW_CURR_ID            = 21
PC_EQUIP_UPGRADES_LOW_TIER_ROW_CURR_ID     = 22
PC_EQUIP_UPGRADES_HOSP_ROW_CURR_ID         = 23
PC_TRANSPORT_HEADER_ROW_CURR_ID            = 24
PC_SIT_ASSESS_TRANSPORT_ROW_CURR_ID  	   = 25
PC_NEW_VEHIC_PURCHASE_ROW_CURR_ID 		   = 26
PC_VEHIC_OP_MAINT_ROW_CURR_ID       	   = 27
PC_COMM_MEDIA_HEADER_ROW_CURR_ID           = 28
PC_DEV_COMM_STRAT_ROW_CURR_ID              = 29
PC_MASS_MEDIA_COMM_ROW_CURR_ID             = 30
PC_PRINTED_MATS_ROW_CURR_ID                = 31
PC_SOCIAL_OUTR_ACTIV_ROW_CURR_ID           = 32
PC_ADVOC_HEADER_ROW_CURR_ID                = 33
PC_PLAN_ADVOC_STRAT_ROW_CURR_ID            = 34
PC_ADVOC_ACTS_ROW_CURR_ID                  = 35
PC_ADVOC_MATS_ROW_CURR_ID                  = 36
PC_GEN_PROG_MGMT_HEADER_ROW_CURR_ID        = 37
PC_DESIGN_REV_COUNTRY_STRAT_ROW_CURR_ID    = 38
PC_DEV_REVIEW_ANNUAL_WORKPLAN_ROW_CURR_ID  = 39
PC_DEV_REVIEW_HR_PLAN_ROW_CURR_ID		   = 40
PC_PROG_COORD_MEET_ROW_CURR_ID             = 41
PC_COMMOD_REG_POL_ROW_CURR_ID              = 42
PC_SIT_ANALYSIS_ROW_CURR_ID                = 43
PC_OFFICE_EQUIP_SUPP_ROW_CURR_ID           = 44
PC_UTIL_ROW_CURR_ID                        = 45
PC_OTHER_HEADER_ROW_CURR_ID                = 46
PC_DBL_CLICK_ADD_OTHER_ITEMS_ROW_CURR_ID   = 47
PC_NUM_STANDARD_ROWS                       = PC_DBL_CLICK_ADD_OTHER_ITEMS_ROW_CURR_ID 

# row master IDs for standard programme areas

PC_PROG_SPEC_HR_HEADER_ROW_MST_ID         = '1'   # 1.   Programme-specific human resources
PC_NAT_LEVEL_STAFF_ROW_MST_ID	  	      = '2'   # 1.1    National-level staff
PC_REG_LEVEL_STAFF_ROW_MST_ID   	      = '3'   # 1.2    Regional-level staff
PC_DIST_LEVEL_STAFF_ROW_MST_ID	 	      = '4'   # 1.3    District-level staff
PC_TRAIN_HEADER_ROW_MST_ID                = '5'   # 2.   Training
PC_INSERV_REFRESH_TRAIN_ROW_MST_ID        = '6'   # 2.1    In-service / Refresher training
PC_TRAIN_OF_TRAIN_ROW_MST_ID              = '7'   # 2.2    Training of trainers
PC_DEV_TRAIN_PROG_MAT_ROW_MST_ID          = '8'   # 2.3    Development of training programmes and material
PC_CHANGE_PRESERV_TRAIN_CURRIC_ROW_MST_ID = '9'   # 2.4    Changing the pre-service training curriculum (not in PM)
PC_SUPP_ACT_ROW_MST_ID                    = '10'  # 2.5    Support activities (2.4 for PM)
PC_SUPERVIS_HEADER_ROW_MST_ID             = '11'  # 3.   Supervision
PC_COORD_MEET_ROW_MST_ID                  = '12'  # 3.1    Coordination meetings
PC_NAT_STAFF_VISIT_LOCAL_ROW_MST_ID       = '13'  # 3.2    National staff visiting local staff (called Supervision visits in PM, but same)
PC_MONITOR_EVAL_HEADER_ROW_MST_ID         = '14'  # 4.   Monitoring and evaluation 
PC_DESIGN_ME_FRAME_SYS_ROW_MST_ID         = '15'  # 4.1    Design of M & E frameworks and systems
PC_DESIGN_QC_QA_ROW_MST_ID                = '16'  # 4.2    Design of quality control and assurance 
PC_DESIGN_REV_DATA_MGMT_SYS_ROW_MST_ID    = '17'  # 4.3    Design / review of data management systems 
PC_DATA_COLLECT_ANALYSIS_ROW_MST_ID       = '18'  # 4.4    Data collection and analysis 
PC_QC_QA_ROW_MST_ID                       = '19'  # 4.5    Quality control / quality assurance
PC_INFRA_EQUIP_HEADER_ROW_MST_ID          = '20'  # 5.   Infrastructure and equipment
PC_SIT_ASSESS_INFRA_ROW_MST_ID            = '21'  # 5.1    Situational assessment
PC_EQUIP_UPGRADES_LOW_TIER_ROW_MST_ID     = '22'  # 5.2    Equipment upgrades for lower-tier facilities
PC_EQUIP_UPGRADES_HOSP_ROW_MST_ID         = '23'  # 5.3    Equipment upgrades for hospitals
PC_TRANSPORT_HEADER_ROW_MST_ID            = '24'  # 6.   Transport
PC_SIT_ASSESS_TRANSPORT_ROW_MST_ID  	  = '25'  # 6.1    Situational assessment
PC_NEW_VEHIC_PURCHASE_ROW_MST_ID 		  = '26'  # 6.2    New vehicle purchase
PC_VEHIC_OP_MAINT_ROW_MST_ID       	      = '27'  # 6.3    Vehicle operation and maintenance
PC_COMM_MEDIA_HEADER_ROW_MST_ID           = '28'  # 7.   Communication, media, and outreach
PC_DEV_COMM_STRAT_ROW_MST_ID              = '29'  # 7.1    Development of communication strategy
PC_MASS_MEDIA_COMM_ROW_MST_ID             = '30'  # 7.2    Mass media
PC_PRINTED_MATS_ROW_MST_ID                = '31'  # 7.3    Printed materials
PC_SOCIAL_OUTR_ACTIV_ROW_MST_ID           = '32'  # 7.4    Social outreach activities
PC_ADVOC_HEADER_ROW_MST_ID                = '33'  # 8.    Advocacy
PC_PLAN_ADVOC_STRAT_ROW_MST_ID            = '34'  # 8.1     Planning on advocacy strategy
PC_ADVOC_ACTS_ROW_MST_ID                  = '35'  # 8.2     Advocacy activities
PC_ADVOC_MATS_ROW_MST_ID                  = '36'  # 8.3     Advocacy materials
PC_GEN_PROG_MGMT_HEADER_ROW_MST_ID        = '37'  # 9.    General programme management
PC_DESIGN_REV_COUNTRY_STRAT_ROW_MST_ID    = '38'  # 9.1     Design and review of country strategy
PC_DEV_REVIEW_ANNUAL_WORKPLAN_ROW_MST_ID  = '39'  # 9.2     Development and review of annual work plan
PC_DEV_REVIEW_HR_PLAN_ROW_MST_ID		  = '40'  # 9.3     Development and review of human resources plan
PC_PROG_COORD_MEET_ROW_MST_ID             = '41'  # 9.4     Programme coordination meetings
PC_COMMOD_REG_POL_ROW_MST_ID              = '42'  # 9.5     Commodity regulation and policies
PC_SIT_ANALYSIS_ROW_MST_ID                = '43'  # 9.6     Situation analysis
PC_OTHER_HEADER_ROW_MST_ID                = '44'  # 10.   Other   
PC_DBL_CLICK_ADD_OTHER_ITEMS_ROW_MST_ID   = '45'  # 10.1    Double-click to add other items
PC_OFFICE_EQUIP_SUPP_ROW_MST_ID           = '46'  # 9.7     Office equipment and supplies
PC_UTIL_ROW_MST_ID                        = '47'  # 9.8     Utilities

# row current IDs for HIV programme area.

PC_POLICY_BASED_INTERV_ROW_CURR_ID              = 46
PC_SOC_ECON_SUPP_CHILD_ROW_CURR_ID              = 47
PC_PREV_VIOL_WOMEN_ROW_CURR_ID                  = 48
PC_DECRIM_KEY_POP_BEHAV_ROW_CURR_ID             = 49
PC_PREV_STIGMA_DISCRIM_ROW_CURR_ID              = 50
PC_COMM_CIVIL_SOC_LEAD_ROW_CURR_ID              = 51
PC_LEGAL_POLICY_REFORMS_ROW_CURR_ID             = 52
PC_HIV_OTHER_HEADER_ROW_CURR_ID                 = 53
PC_HIV_DBL_CLICK_ADD_OTHER_ITEMS_ROW_CURR_ID    = 54
PC_TOTAL_NUM_HIV_ROWS                           = PC_HIV_DBL_CLICK_ADD_OTHER_ITEMS_ROW_CURR_ID

# row master IDs for HIV programme area

PC_POLICY_BASED_INTERV_ROW_MST_ID              = 'HIV_1'  # 10.   Policy-base interventions
PC_SOC_ECON_SUPP_CHILD_ROW_MST_ID              = 'HIV_2'  # 10.1     Socioeconomic support for orphans and vulnerable children        
PC_PREV_VIOL_WOMEN_ROW_MST_ID                  = 'HIV_3'  # 10.2     Prevention of violence against women          
PC_DECRIM_KEY_POP_BEHAV_ROW_MST_ID             = 'HIV_4'  # 10.3     Decriminalization of key population behaviors            
PC_PREV_STIGMA_DISCRIM_ROW_MST_ID              = 'HIV_5'  # 10.4     Prevention of stigma and discrimination    
PC_COMM_CIVIL_SOC_LEAD_ROW_MST_ID              = 'HIV_6'  # 10.5     Community and civil society leadership, including young people
PC_LEGAL_POLICY_REFORMS_ROW_MST_ID             = 'HIV_7'  # 10.6     Legal, policy reforms 
PC_HIV_OTHER_HEADER_ROW_MST_ID                 = 'HIV_8'  # 11.    Other                  was 56
PC_HIV_DBL_CLICK_ADD_OTHER_ITEMS_ROW_MST_ID    = 'HIV_9'  # 11.1     Double-click to add other rows      was 57

#######################################################################################################
#                                                                                                     #
#                                       Programme management (PM) rows                                #
#                                                                                                     #
#######################################################################################################

# row master IDs for standard programme management. Generally the same for each Health system module except IS, which has 
# additional rows at the end.  Rows are also generally the same as for PC until we hit 4 (except PM skips Changing the pre-service
# training curriculum in section 2).

# Section 4 for PM is different than PC
PC_PM_GEN_PROG_MGMT_ROW_MST_ID               = 'PM_1' # 4.   General programme management
PC_PM_DESIGN_REVIEW_COUNTRY_STRAT_ROW_MST_ID = 'PM_2' # 4.1    Design and review of country strategy     
PC_PM_DEV_REVIEW_ANNUAL_WORK_PLAN_ROW_MST_ID = 'PM_3' # 4.2    Development and review of annual work plan
PC_PM_DEV_REVIEW_HR_PLANN_ROW_MST_ID         = 'PM_4' # 4.3    Development and review of human resources plan
PC_PM_SITUAT_ANALYSIS_ROW_MST_ID             = 'PM_5' # 4.4    Situation analysis
PC_PM_OTHER_COSTS_MST_ID                     = 'PM_6' # 5.   Other costs
PC_PM_DBL_CLICK_ADD_OTHER_ITEMS_ROW_MST_ID   = 'PM_7' # 5.1     Double-click to add other

PC_PM_BLOOD_SAFETY_MST_ID                            = 'PM_IS_1'  # 6.      Blood safety
PC_PM_BLOOD_SAFETY_COV_MST_ID                        = 'PM_IS_2'  # 6.1         Coverage
PC_PM_ESTAB_TRANSFUSION_SERVICE_MST_ID               = 'PM_IS_3'  # 6.2         Establishment of nationally coordinated blood transfusion service
PC_PM_ADMIN_BLOOD_SAFETY_SERVICE_MST_ID              = 'PM_IS_4'  # 6.3         Administration of nationally coordinated blood safety service
PC_PM_RECURRENT_COSTS_BLOOD_MST_ID                   = 'PM_IS_5'  # 6.4         Recurrent handling costs of blood
PC_PM_TRAINING_BLOOD_SAFETY_MST_ID                   = 'PM_IS_6'  # 6.5         Training for blood safety
PC_PM_UNIVERSAL_PRECAUTIONS_MST_ID                   = 'PM_IS_7'  # 7.      Universal precautions
PC_PM_UNIVERSAL_PRECAUTIONS_COV_MST_ID               = 'PM_IS_8'  # 7.1         Coverage
PC_PM_UNIVERSAL_PRECAUTIONS_COST_MST_ID              = 'PM_IS_9'  # 7.2         Universal precautions
PC_PM_UNSAFE_INJECT_SYRINGES_MST_ID                  = 'PM_IS_10' # 8.      Unsafe injections replaced with AD syringes
PC_PM_UNSAFE_INJECT_COV_MST_ID                       = 'PM_IS_11' # 8.1         Coverage
PC_PM_UNSAFE_INJECT_ADMIN_SAFE_INJECT_PROG_MST_ID    = 'PM_IS_12' # 8.2         Administration of safe injection programme
PC_PM_UNSAFE_INJECT_CONSTRUCT_NEEDLE_PITS_MST_ID     = 'PM_IS_13' # 8.3         Construction of needle pits
PC_PM_UNSAFE_INJECT_DEV_SAFE_INJECT_POLICY_MST_ID    = 'PM_IS_14' # 8.4         Development of a safe injection policy
PC_PM_UNSAFE_INJECT_TRAINING_SAFE_INJECT_MST_ID      = 'PM_IS_15' # 8.5         Training for safe injections
PC_PM_UNSAFE_INJECT_COMMUNICATION_MST_ID             = 'PM_IS_16' # 8.6         Communication
PC_PM_UNSAFE_INJECT_AUTO_DESTRUCT_SYRINGES_MST_ID    = 'PM_IS_17' # 8.7         Auto-destruct syringes
PC_PM_REDUCT_INJECT_MST_ID                           = 'PM_IS_18' # 9.      Reduction in number of other injections
PC_PM_REDUCT_INJECT_COV_MST_ID                       = 'PM_IS_19' # 9.1         Coverage
PC_PM_REDUCT_INJECT_ADMIN_SAFE_INJECTION_PROG_MST_ID = 'PM_IS_20' # 9.2         Administration of safe injection programme
PC_PM_REDUCT_INJECT_CONSTRUCT_NEEDLE_PITS_MST_ID     = 'PM_IS_21' # 9.3         Construction of needle pits
PC_PM_REDUCT_INJECT_DEV_SAFE_INJECT_POLICY_MST_ID    = 'PM_IS_22' # 9.4         Development of a safe injection policy
PC_PM_REDUCT_INJECT_TRAINING_SAFE_INJECT_MST_ID      = 'PM_IS_23' # 9.5         Training for safe injections
PC_PM_REDUCT_INJECT_COMMUNICATION_MST_ID             = 'PM_IS_24' # 9.6         Communication
PC_PM_REDUCT_INJECT_AUTO_DESTRUCT_SYRINGES_MST_ID    = 'PM_IS_25' # 9.7         Auto-destruct syringes

PC_PM_NUM_STANDARD_ROWS    = 19 # includes the two Other costs rows
PC_PM_NUM_IS_SPECIFIC_ROWS = 25
PC_PM_TOTAL_NUM_IS_ROWS    = PC_PM_NUM_STANDARD_ROWS + PC_PM_NUM_IS_SPECIFIC_ROWS

#
PC_TAX_PARAMS_PPLI_CURR_ID       = 1
PC_TAX_PACKS_CHANGE_PPLI_CURR_ID = 2
PC_NUM_TAX_COLS_PPLI             = PC_TAX_PACKS_CHANGE_PPLI_CURR_ID

# Year endpoints (PPLI)

PC_BASELINE_VALUE_PPLI_CURR_ID   = 1
PC_PROJECTION_VALUE_PPLI_CURR_ID = 2
PC_NUM_YEAR_ENDPOINTS_PPLI       = PC_PROJECTION_VALUE_PPLI_CURR_ID

# Taxation entry mode (PPLI)

PC_ENTER_REAL_RETAIL_PRICE_PPLI_MST_ID = 1
PC_ENTER_EXCISE_SHARE_MST_PPLI_ID      = 2
PC_ENTER_TAX_SHARE_MST_PPLI_ID         = 3
PC_NUM_TAX_ENTRY_MODES                 = 3

# Phases (PPLI)

PC_NO_ACTION_PHASE_0_PPLI_CURR_ID    = 1
PC_PLANNING_PHASE_0_PPLI_CURR_ID     = 2
PC_EARLY_IMP_PHASE_25_PPLI_CURR_ID   = 3
PC_PARTIAL_IMP_PHASE_50_PPLI_CURR_ID = 4
PC_FULL_IMP_PHASE_100_PPLI_CURR_ID   = 5
PC_NUM_PHASES                        = PC_FULL_IMP_PHASE_100_PPLI_CURR_ID

PC_NO_ACTION_PHASE_0_PPLI_MST_ID    = 1
PC_PLANNING_PHASE_0_PPLI_MST_ID     = 2
PC_EARLY_IMP_PHASE_25_PPLI_MST_ID   = 3
PC_PARTIAL_IMP_PHASE_50_PPLI_MST_ID = 4
PC_FULL_IMP_PHASE_100_PPLI_MST_ID   = 5

# Phase and intensity row type (PPLI)

PC_PHASE_ROW_PPLI_CURR_ID             = 1
PC_INTENSITY_ROW_PPLI_CURR_ID         = 2
PC_NUM_PHASE_INTENSITY_ROW_TYPES_PPLI = PC_INTENSITY_ROW_PPLI_CURR_ID

PC_PHASE_ROW_PPLI_MST_ID     = 1
PC_INTENSITY_ROW_PPLI_MST_ID = 2

# Number of administrative units per level options

PC_USE_NUM_ADMIN_UNITS_FROM_CONFIG_PPLI_MST_ID = 1
PC_ENTER_STD_POP_ADMIN_UNITS_PPLI_MST_ID       = 2

# All PPLI ALIs exist under two tabs (two sets of data).  The Inputs per admin level tab feeds the Total inputs tab, and the Total inputs tab is the set used in PCProj.
PC_INPUTS_PER_ADMIN_LEVEL_PPLI_ALI_SET_CURR_ID = 1
PC_TOTAL_INPUTS_PPLI_ALI_SET_CURR_ID           = 2
PC_NUM_PPLI_ALI_SETS                           = 2

PC_PPLI_NATIONAL_ADMIN_LEVEL_CURR_ID = 1
PC_PPLI_PROVINCE_ADMIN_LEVEL_CURR_ID = 2
PC_PPLI_DISTRICT_ADMIN_LEVEL_CURR_ID = 3
PC_PPLI_NUM_ADMIN_LEVELS             = PC_PPLI_DISTRICT_ADMIN_LEVEL_CURR_ID

PC_PPLI_NATIONAL_ADMIN_LEVEL_MST_ID = 1
PC_PPLI_PROVINCE_ADMIN_LEVEL_MST_ID = 2
PC_PPLI_DISTRICT_ADMIN_LEVEL_MST_ID = 3

# Costing section IDs (normally these come from the database, but we need to access particular ones at times)

PC_PPLI_TOBACCO_CTRL_COST_SECT_ID = '1'
PC_PROG_AREA_STAFF_FOR_PROG_ADMIN_COST_SECT_ID = 1
PC_COSTING_SECT_DB_AREA_ID_CUSTOM = 'custom' # for identifying costing sections to be loaded from the database when adding custom prog areas

# Costing subsection IDs (normally these come from the database, but we need to access particular ones at times)

# These are for Programme costing --> Staff for programme administration for each programme area
PC_NAT_LEVEL_STAFF_COST_SUBSECT_ID  = 1
PC_REG_LEVEL_STAFF_COST_SUBSECT_ID  = 2
PC_DIST_LEVEL_STAFF_COST_SUBSECT_ID = 3
PC_ADMIN_LEVEL_4_STAFF_SUBSECT_ID   = 4
PC_ADMIN_LEVEL_5_STAFF_SUBSECT_ID   = 5

PC_RAISE_TAXES_PPLI_COSTING_SUBSECT_ID = '1'

PC_PROG_MGMT_MODS = [pccl.IH_HEALTH_WORKFORCE_HSPM_MST_ID, pccl.IH_INFRASTRUCTURE_HSPM_MST_ID, pccl.IH_LOGISTICS_HSPM_MST_ID]