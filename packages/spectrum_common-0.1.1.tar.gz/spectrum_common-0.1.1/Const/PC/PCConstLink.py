from SpectrumCommon.Const.IV.IVConst import *
from SpectrumCommon.Const.IV.IVDatabaseKeys import *

from SpectrumCommon.Const.IH.IHConst import *
from SpectrumCommon.Const.IH.IHTags import *

from SpectrumCommon.Const.CS.CSTags import *

#############################    IV    ##########################

PC_IV_GROUP_DB_CURR_VERSION = IV_IH_GROUP_DB_CURR_VERSION

PC_IV_GROUP_DB_NAME         = IV_GROUP_DB_NAME

# Group DB (GDB)

PC_IV_GROUP_MST_ID_KEY_GDB     = IV_GROUP_MST_ID_KEY_GDB
PC_IV_SUBGROUP_MST_ID_KEY_GDB  = IV_SUBGROUP_MST_ID_KEY_GDB   

#############################    IH    ##########################

PC_IH_PROG_AREA_MST_ID                  = IH_PROG_AREA_MST_ID
PC_IH_MODULE_MST_ID                     = IH_MODULE_MST_ID  
PC_IH_HEALTH_SYS_MST_ID                 = IH_HEALTH_SYS_MST_ID
PC_IH_HEALTH_INFORM_SYSTEMS_HSPM_MST_ID = IH_HEALTH_INFORM_SYSTEMS_HSPM_MST_ID
PC_IH_HEALTH_WORKFORCE_HSPM_MST_ID      = IH_HEALTH_WORKFORCE_HSPM_MST_ID
PC_IH_INFRASTRUCTURE_HSPM_MST_ID        = IH_INFRASTRUCTURE_HSPM_MST_ID
PC_IH_LOGISTICS_HSPM_MST_ID             = IH_LOGISTICS_HSPM_MST_ID
PC_IH_PPLI_MST_ID                       = IH_PPLI_MST_ID
PC_IH_SOCIAL_ENABLERS_MST_ID            = IH_SOCIAL_ENABLERS_MST_ID
PC_IH_NATIONAL_HSAU_MST_ID              = IH_NATIONAL_HSAU_MST_ID 
PC_IH_PROVINCE_HSAU_MST_ID              = IH_PROVINCE_HSAU_MST_ID
PC_IH_DISTRICT_HSAU_MST_ID              = IH_DISTRICT_HSAU_MST_ID

PC_IH_HIV_AIDS_MST_ID = IH_HIV_AIDS_MST_ID
PC_IH_NCD_MST_ID      = IH_NCD_MST_ID

PC_IH_PROG_AREA_RECORDS_TAG_V1 = IH_PROG_AREA_RECORDS_TAG_V1
PC_IH_HEALTH_SYS_ADMIN_UNIT_RECORDS_TAG = IH_HEALTH_SYS_ADMIN_UNIT_RECORDS_TAG

#############################    CS    ##########################

PC_CS_ANNUAL_PERC_GROWTH_RATE_TAG = CS_AnnualPercGrowthRateTag

