from SpectrumCommon.Const.IV.IVConst import *
from SpectrumCommon.Const.IV.IVDatabaseKeys import *

from SpectrumCommon.Const.IH.IHConst import *
from SpectrumCommon.Const.IH.IHTags import *

from SpectrumCommon.Const.CS.CSTags import *

from SpectrumCommon.Const.FP.FPConst import *
from SpectrumCommon.Const.FP.FPTags import *

from SpectrumCommon.Const.DP.DPTags import *

##############################    DP    ##########################

RP_DP_BIG_POP_TAG = DP_BigPopTag
RP_DP_TFR_TAG = DP_TFRTag

##############################    FP    ##########################

RP_FP_ACTIVE_METHODS_TAG = FP_ActiveMethodsTag
RP_FP_EFFECTIVENESS_TAG  = FP_EffectivenessTag
RP_FP_METHOD_MIX_TAG     = FP_MethodMixTag
RP_FP_USERS_TAG          = FP_UsersTag
RP_FP_PREVALENCE_TAG     = FP_PrevalenceTag
RP_FP_BIRTHS_TAG         = FP_BirthsTag

RP_FP_NUM_METHODS = FP_Max_Methods

RP_FP_ALL_AGES = FP_All_Ages
RP_FP_ALL_NEED = FP_all_need

# These are all possible active FamPlan methods that have default values for FamPlan (substantially shorter than the full list of FamPlan methods)

RP_FP_M_CONDOM_M_CURR_ID             = FP_CondomML
RP_FP_M_STERILIZ_F_CURR_ID           = FP_fster          
RP_FP_M_STERILIZ_M_CURR_ID           = FP_mster       
RP_FP_M_IUD_COPPER_10_YR_CURR_ID     = FP_IUDCopper     
RP_FP_M_INJECT_DEPO_3_MO_CURR_ID     = FP_inj3month 
RP_FP_M_IMPLANT_JADELLE_5_YR_CURR_ID = FP_Jadelle
RP_FP_M_PILL_STANDARD_CURR_ID        = FP_StandardPill
RP_FP_M_VAG_BARRIER_CURR_ID          = FP_vag_barrier
RP_FP_M_OTHER_MODERN_METHODS_CURR_ID = FP_other

# Traditional methods that are not modelled by RAPID
RP_FP_M_TRAD_WITHDRAWAL_CURR_ID    = FP_withdrawal   
RP_FP_M_TRAD_PERIODIC_ABST_CURR_ID = FP_PerAbst        
RP_FP_M_TRAD_OTHER_CURR_ID         = FP_Traditional
RP_FP_M_TRAD_METHODS               = FP_TRAD_METH