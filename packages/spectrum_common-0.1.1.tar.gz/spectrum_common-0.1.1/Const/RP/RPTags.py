# Inputs

RP_VERSION_TAG                          = '<RP_Version_V1>'
RP_DATA_CHANGED_TAG                     = '<RP_DataChanged_V1>'
RP_PROJ_VALID_TAG                       = '<RP_ProjectionValid_V1>'
RP_FILE_NAME_TAG                        = '<RP_FileName_V1>'                        
RP_PROJ_VALID_DATE_TAG                  = '<RP_ProjectionValidDate_V1>'   

RP_SECTOR_RECORDS_TAG                   = '<RP_SectorRecords_V1>'
RP_SECTORS_ON_TAG                       = '<RP_RAPIDSectorsOn_V1>'

RP_FP_SCEN_GOAL_TAG                     = '<RP_FPScenarioGoal_V1>'
RP_FP_SCEN_GOAL_SCALE_UP_TAG            = '<RP_FPScenarioGoalScaleUp_V1>'
RP_FP_SCEN_COUNTERFACTUAL_TAG           = '<RP_FPScenarioCounterfactual_V1>'
RP_FP_SCEN_COUNTERFACTUAL_SCALE_UP_TAG  = '<RP_FPScenarioCounterfactualScaleUp_V1>'

RP_HOUSEHOLD_SIZE_BASELINE_TAG           = '<RP_HouseholdSizeBaseline_V1>' 

RP_FP_PERC_USERS_TAG                    = '<RP_FPPercUsers_V1>'
# RP_FP_TYPICAL_USE_EFFECTIVENESS_TAG     = '<RP_FPTypicalUseEffectiveness_V1>'
RP_FP_AVG_ANNUAL_UNIT_DIRECT_COSTS_TAG  = '<RP_FPAvgAnnualUnitDirectCosts_V1>'
RP_FP_INDIRECT_PROG_COSTS_TAG           = '<RP_FPIndirectProgramCosts_V1>'

RP_CLIMATE_PARAMS_TAG                  = '<RP_ClimateParameters_V1>'

RP_REVISED_SOURCES_TAG = '<RP_RevisedSources_V1>'

# Results

RP_RES_DP_BIG_POP_TAG                                 = '<RP_ResDPBigPop_V1>'
RP_RES_DP_TFR_TAG                                     = '<RP_ResDP_TFR_V1>'
RP_RES_FP_BIRTHS_TAG                                  = '<RP_ResFPBirths_V1>'

RP_RES_PRIM_SCH_STUDENTS_TAG                          = '<RP_ResPrimarySchoolStudents_V1>'
RP_RES_PRIM_EDU_COSTS_TAG                             = '<RP_ResPrimaryEducationCosts_V1>'
RP_RES_SEC_SCH_STUDENTS_TAG                           = '<RP_ResSecondarySchoolStudents_V1>'
RP_RES_SEC_EDU_COSTS_TAG                              = '<RP_ResSecondaryEducationCosts_V1>'
RP_RES_PRIM_SCH_TEACHERS_NEEDED_TAG                   = '<RP_ResPrimarySchoolTeachersNeeded_V1>'
RP_RES_PRIM_SCH_TEACHER_SALARY_COSTS_TAG              = '<RP_ResPrimaryTeacherSalaryCosts_V1>'

RP_RES_SKILLED_DELIV_TAG                              = '<RP_ResSkilledDeliveries_V1>'
RP_RES_SKILLED_DELIV_COSTS_TAG                        = '<RP_ResSkilledDeliveryCosts_V1>'
RP_RES_PREG_W_4_PLUS_ANC_VISITS_TAG                   = '<RP_ResPregnantWomen4PlusANCVisits_V1>'
RP_RES_COST_4_PLUS_ANC_VISITS_TAG                     = '<RP_ResCostOf4PlusANCVisits_V1>'
RP_RES_HLTH_PROF_TAG                                  = '<RP_ResHealthProfessionals_V1>'
RP_RES_HLTH_PROF_SALARY_COSTS_TAG                     = '<RP_ResHealthProfessionalSalaryCosts_V1>'

RP_RES_PEOPLE_ACCESS_IMRP_WATER_SOURCES_TAG           = '<RP_ResPeopleAccessImprWaterSources_V1>'
RP_RES_ADD_PEOPLE_NEED_ACCESS_IMPR_WATER_CUMU_TAG     = '<RP_ResAddPeopleNeedAccessImprWaterCumu_V1>'
RP_RES_CAP_COST_ADD_PEOPLE_GAIN_ACCESS_IMPR_WATER_TAG = '<RP_ResCapCostAddPeopleGainAccessImprWater_V1>'
RP_RES_PEOPLE_ACCESS_IMPR_SANI_FAC_TAG                = '<RP_ResPeopleAccessImprSaniFacilities_V1>'
RP_RES_ADD_PEOPLE_ACCESS_IMPR_SANI_FAC_CUMU_TAG       = '<RP_ResAddPeopleNeedAccessImprSaniFacilitiesCumu_V1>'
RP_RES_CAP_COST_ADD_PEOPLE_GAIN_ACCESS_IMPR_SANI_TAG  = '<RP_ResCapCostAddPeopleGainAccessImprSani_V1>'

RP_RES_MAIN_STAPLE_CROP_PROD_NEEDED_TAG               = '<RP_ResMainStapleCropProductionNeeded_V1>'
RP_RES_HECTARES_CROP_NEEDED_MEET_GOAL_TAG             = '<RP_ResHectaresCroplandNeededMeetGoal_V1>'
RP_RES_PERC_CROP_NEEDED_MEET_GOAL_TAG                 = '<RP_ResPercCroplandNeededMeetGoal_V1>'
RP_RES_COST_MAIN_STAPLE_CROP_PROD_TAG                 = '<RP_ResCostMainStapleCropProduction_V1>'
RP_RES_FOOD_NEEDED_RED_FOOD_INSEC_CUMU_TAG            = '<RP_ResFoodAidNeededReduceFoodInsecCumu_V1>'
RP_RES_COST_PROV_FOOD_AID_PEOPLE_FOOD_INSEC_ELIM_TAG  = '<RP_ResCostProvFoodAidPeopleFoodInsecElim_V1>'

RP_RES_URBAN_POP_TAG                                  = '<RP_ResUrbanPop_V1>'
RP_RES_URBAN_HHS_LIVING_INF_SETTLEMENTS_TAG           = '<RP_ResUrbanHHsLivingInformalSettlements_V1>'
RP_RES_HOUSES_TO_BUILD_CUMU_TAG                       = '<RP_ResHousesToBuildCumu_V1>'
RP_RES_COST_BUILD_HOUSES_PEOPLE_RELOC_TAG             = '<RP_ResCostBuildHousesPeopleRelocInfUrbanSettlements_V1>'

RP_RES_POP_ACCESS_ELEC_TAG                            = '<RP_ResPopAccessElectricity_V1>'
RP_RES_ADD_PEOPLE_NEED_ACCESS_ELEC_CUMU_TAG           = '<RP_ResAddPeopleNeedAccessElectricityCumu_V1>'
RP_RES_CAP_COST_CONNECT_ADD_HHS_ELEC_TAG              = '<RP_ResCapCostConnectAddHHsElectricity_V1>'
RP_RES_KWH_NEEDED_SUFF_ELEC_LEVELS_TAG                = '<RP_ResKWhNeededSufficientElectricityLevels_V1>'
RP_RES_COST_ELEC_TAG                                  = '<RP_ResCostElectricity_V1>'
RP_RES_HHS_CLEAN_COOK_FUEL_TECH_TAG                   = '<RP_ResHHsCleanCookingFuelTech_V1>'
RP_RES_ADD_HHS_NEED_ACCESS_CLEAN_COOK_TECH_CUMU_TAG   = '<RP_ResAddHHsNeedAccessCleanCookTechCumu_V1>'
RP_RES_COST_PROV_ADD_HHS_CLEAN_COOK_FUEL_TECH_TAG     = '<RP_ResCostProvAddHHsCleanCookFuelTech_V1>'

RP_RES_AGE_DEPENDENCY_RATIO_TAG                       = '<RP_ResAgeDependencyRatio_V1>'
RP_RES_GDP_PER_CAPITA_TAG                             = '<RP_ResGDPPerCapita_V1>'
RP_RES_TOTAL_PEOPLE_WITH_JOBS_TAG                     = '<RP_ResTotalPeopleWithJobs_V1>'
RP_RES_ADD_JOBS_NEEDED_TAG                            = '<RP_ResAddJobsNeeded_V1>'
RP_RES_NEET_TAG                                       = '<RP_ResNEET_V1>'
RP_RES_ADD_NEET_TAG                                   = '<RP_ResAddNEET_V1>'

RP_RES_NUM_POP_WITH_INTERV_TAG                        = '<RP_ResNumPopWithIntervention_V1>'
RP_RES_COST_POP_WITH_INTERV_TAG                       = '<RP_ResCostPopWithIntervention_V1>'

RP_RES_SSP_TEMP_CHANGES_FROM_BASE_TAG                 = '<RP_ResSSPTempChangesFromBaseline_V1>'
RP_RES_FEWER_KWH_NEEDED_BASED_ON_FP_ACC_TAG           = '<RP_ResFewerKWhNeededBasedFPAcceleration_V1>'
RP_RES_CUMU_SAVINGS_ELEC_COSTS_DUE_FP_ACC_TAG         = '<RP_ResCumulativeSavingsElectricityCostsDueFPAcc_V1>'
RP_RES_ADD_HECTARES_SAVED_CLIMATE_COND_TAG            = '<RP_ResAddHectaresSavedDueFPDiffClimateConditions_V1>'
RP_RES_GDP_PER_CAPITA_STATUS_QUO_TAG                  = '<RP_ResGDPPerCapitaStatusQuo_V1>'
RP_RES_GDP_PER_CAPITA_ACC_TAG                         = '<RP_ResGDPPerCapitaAccelerated_V1>'

RP_RES_SUMMARY_TAG                                    = '<RP_ResSummary_V1>'

# Meta ModVars. The values inside these do not change. They will automatically receive the latest default data when UpdateModvars is called. 

RP_SECTOR_RECORDS_META_TAG                   = '<RP_SectorRecords_Meta_V1>'

RP_FP_SCEN_GOAL_META_TAG                     = '<RP_FPScenarioGoal_Meta_V1>'
RP_FP_SCEN_COUNTERFACTUAL_META_TAG           = '<RP_FPScenarioCounterfactual_Meta_V1>'
RP_FP_SCEN_SCALE_UP_META_TAG                 = '<RP_FPScenarioScaleUp_Meta_V1>'

RP_HOUSEHOLD_SIZE_BASELINE_META_TAG          = '<RP_HouseholdSizeBaseline_Meta_V1>' 

RP_FP_PERC_USERS_META_TAG                    = '<RP_FPPercUsers_Meta_V1>'
RP_FP_TYPICAL_USE_EFFECTIVENESS_META_TAG     = '<RP_FPTypicalUseEffectiveness_Meta_V1>'
RP_FP_AVG_ANNUAL_UNIT_DIRECT_COSTS_META_TAG  = '<RP_FPAvgAnnualUnitDirectCosts_Meta_V1>'
RP_FP_INDIRECT_PROG_COSTS_META_TAG           = '<RP_FPIndirectProgramCosts_Meta_V1>'

RP_CLIMATE_PARAMS_META_TAG                   = '<RP_ClimateParameters_Meta_V1>'

RP_SSP_META_TAG                              = '<RP_SSP_Meta_V1>'

RP_SOURCES_META_TAG                          = '<RP_Sources_Meta_V1>'

# This is specifically singled out from all other sources because the client is running code that expects this particular format for every module.
# If that wasn't the case, this would just be a part of the sources meta MV above.
RP_RP_SOURCES_TAG                             = '<RP_RPSources_V1>'

