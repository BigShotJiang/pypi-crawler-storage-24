# Fields used in RP data structures

RP_SECTOR_ID = 'sectorID'
# RP_SECTOR_ON = 'on'
RP_SECTOR_GOAL_RECORDS = 'goalRecords'

RP_SECTOR_EDU_PRIM_SCH_START_AGE                  = 'primarySchoolStartAge'            # int
RP_SECTOR_EDU_PRIM_SCH_END_AGE                    = 'primarySchoolEndAge'              # int
RP_SECTOR_EDU_SEC_SCH_START_AGE                   = 'secondarySchoolStartAge'          # int
RP_SECTOR_EDU_SEC_SCH_END_AGE                     = 'secondarySchoolEndAge'            # int
# RP_SECTOR_EDU_STUDENT_PER_TEACHER_PRIM           = 'studentsPerTeacherPrimary'        # float
RP_SECTOR_EDU_AVG_ANN_TEACHER_SAL_PRIM_GDP_RATIO  = 'avgAnnualTeacherSalaryPrimaryGDPRatio'    # int
# RP_SECTOR_EDU_AVG_ANN_TEACHER_SAL_SEC            = 'avgAnnualTeacherSalarySecondary'  # int
RP_SECTOR_EDU_PRIM_SPEND_PER_STUDENT_PERC_GDP     = 'primarySpendPerStudentPercGDP'     # int
RP_SECTOR_EDU_SEC_SPEND_PER_STUDENT_PERC_GDP      = 'secondarySpendPerStudentPercGDP'   # int

RP_SECTOR_HLTH_AVG_UNIT_COST_SKILLED_DELIV     = 'avgUnitCostSkilledDelivery'    # float
RP_SECTOR_HLTH_AVG_UNIT_COST_ANC_4_PLUS_VISITS = 'avgUnitCostANC4PlusVisits'     # float
RP_SECTOR_HLTH_PERC_SKILLED_HLTH_PROF_DOCTORS  = 'percSkilledHealthProfDoctors'  # int
RP_SECTOR_HLTH_PERC_SKILLED_HLTH_PROF_NURSES   = 'percSkilledHealthProfNurses'   # int
RP_SECTOR_HLTH_AVG_SALARY_DOCTORS              = 'avgSalaryDoctors'              # float
RP_SECTOR_HLTH_AVG_SALARY_NURSES               = 'avgSalaryNurses'               # float

RP_SECTOR_WASH_CAP_COSTS_PER_HH_IMPR_WATER     = 'capCostsPerHHImprovedWater'       # float
RP_SECTOR_WASH_ANN_COST_MENSTRUAL_HLTH_COMM    = 'annualCostMenstrualHealthComm'    # float
RP_SECTOR_WASH_CAP_COSTS_PER_HH_IMPR_SANI      = 'capCostsPerHHImprovedSanitation'  # float

RP_SECTOR_FOOD_PRIM_STAPLE_CROP                    = 'primaryStapleCrop'                    # string
RP_SECTOR_FOOD_AGRICULT_LAND                       = 'agriculturalLand'                     # int
RP_SECTOR_FOOD_CROP_LAND                           = 'cropLand'                             # int
RP_SECTOR_FOOD_STAPLE_CROP_PROD_BASELINE           = 'stapleCropProductionBaseline'         # int
RP_SECTOR_FOOD_AREA_HARV_STAPLE_CROP               = 'areaHarvestedStapleCrop'              # int
RP_SECTOR_FOOD_TONNES_HARV_PERC_HECT               = 'tonnesHarvestedPerHectare'            # float
RP_SECTOR_FOOD_ANN_KG_PER_YEAR_CONSUMP_STAPLE_CROP = 'annualKgPerYearConsumptionStapleCrop' # int
RP_SECTOR_FOOD_PROD_COSTS_STAPLE_CROP              = 'productionCostsStapleCrop'            # float
RP_SECTOR_FOOD_DAILY_COST_FOOD_AID                 = 'dailyCostFoodAid'                     # float

RP_SECTOR_URB_PERC_POP_URB_BASELINE_YEAR    = 'percPopUrbanBaselineYear' # int
RP_SECTOR_URB_PERC_POP_URB_ENDLINE_YEAR     = 'percPopUrbanEndlineYear'  # int
RP_SECTOR_URB_COST_PER_HH_MOVE_TO_HOUSING   = 'costPerHHMoveToHousing'   # float

RP_SECTOR_ENERGY_KWH_PROD_PER_CAP_PER_YEAR        = 'KWhProducedPerCapitaPerYear'  # float
RP_SECTOR_ENERGY_CAP_COSTS_PER_HH_CONNECT_GRID    = 'capCostsPerHHConnectGrid'     # int
RP_SECTOR_ENERGY_CAP_COSTS_PER_HH_CLEAN_COOKING   = 'capCostPerHHCleanCooking'     # float
RP_SECTOR_ENERGY_COST_PER_KWH                     = 'costPerKWh'                   # float

RP_SECTOR_ECO_GDP_PER_CAPITA    = 'GDPPerCapita'                # float
# RP_SECTOR_ECO_BASELINE_GDP      = 'baselineGDP'               # int
# RP_SECTOR_ECO_GDP_GROWTH_RATE   = 'GDPGrowthRate'             # float
RP_SECTOR_ECO_LABOR_PARTIC_RATE = 'laborParticipationRate'      # float
RP_SECTOR_ECO_CHANGE_GDP_CDR    = 'changeInGDPPerPercChangeCDR' # float

# RP_SECTOR_BYO_POP                = 'population'      # string
RP_SECTOR_BYO_INTERV             = 'intervention'    # string
RP_SECTOR_BYO_TARG_POP           = 'targPop'         # int; 
# RP_SECTOR_BYO_UNIT_OF_ANALYSIS_1 = 'unitOfAnalysis1' # string
RP_SECTOR_BYO_MULTIPLIER_1       = 'multiplier1'     # int
RP_SECTOR_BYO_UNIT_OF_ANALYSIS_2 = 'unitOfAnalysis2' # string
RP_SECTOR_BYO_UNIT_COST_2        = 'unitCost2'       # float

RP_CLIM_BASELINE_MEAN_MED_TEMP              = 'baselineMeanMedianTemp'                       # float
RP_CLIM_PERC_CHANGE_GDP_1_DEG_WARM          = 'percChangeGDP1DegreeWarming'                  # float; can be negative
RP_CLIM_PERC_CHANGE_ENERGY_NEEDS_1_DEG_WARM = 'percChangeEnergyNeeds1DegreeWarming'          # float; can be negative
RP_CLIM_PERC_CHANGE_STAPLE_CROP_1_DEG_WARM  = 'percChangeStapleCroplandNeeds1DegreeWarming'  # float; can be negative
RP_CLIM_PERC_CHANGE_STAPLE_CROP_2_DEG_WARM  = 'percChangeStapleCroplandNeeds2DegreesWarming' # float; can be negative
RP_CLIM_PERC_CHANGE_STAPLE_CROP_3_DEG_WARM  = 'percChangeStapleCroplandNeeds3DegreesWarming' # float; can be negative

RP_GOAL_ON                  = 'on'                # bool
RP_GOAL_ID                  = 'goalID'            # int
RP_GOAL_SELECTED_SUBGOAL_ID = 'selectedSubgoalID' # int; for MV
RP_GOAL_DEFAULT_SUBGOAL_ID  = 'defaultSubgoalID'  # int; for meta MV
RP_GOAL_SUBGOAL_RECORDS     = 'subgoalRecords'    # list of dict
# RP_GOAL_INTERP_TYPE       = 'interpTypeID'    # int
RP_GOAL_RESULTING_CHANGE    = 'resultingChange' # list of int; only used for Build Your Own Sector, which is the only sector without subgoals (where resultingChange is normally stored).

RP_SUBGOAL_ID               = 'subgoalID'
RP_SUBGOAL_RESULTING_CHANGE = 'resultingChange' # list of int

RP_FP_SCEN_SC_ACCELERATED = 'accelerated'
RP_FP_SCEN_SC_MEDIAN      = 'median'
RP_FP_SCEN_SC_FLATLINE    = 'flatline'

# Used for various result MVs to separate portions of MVs into status quo, goal, and counterfactual. Sometimes results will have statusQuo, 
# sometimes they won't
RP_RES_FP_SCEN_STATUS_QUO     = 'statusQuo'
RP_RES_FP_SCEN_GOAL           = 'goal'
RP_RES_FP_SCEN_COUNTERFACTUAL = 'counterfactual'

RP_RES_SUM_CUMU_COSTS                      = 'cumulativeCosts'
RP_RES_SUM_DIRECT                          = 'direct'
RP_RES_SUM_INDIRECT                        = 'indirect'
RP_RES_SUM_CUMU_SAVINGS                    = 'cumulativeSavings'
RP_RES_SUM_EDU_SECT_PRIM                   = 'eduSectorPrimary'
RP_RES_SUM_EDU_SECT_SEC                    = 'eduSectorSecondary'
RP_RES_SUM_HLTH_SECT_SKILLED_DELIV         = 'healthSectorSkilledDeliveries'
RP_RES_SUM_HLTH_SECT_ANC                   = 'healthSectorANC'
RP_RES_SUM_WASH_SECT_IMPR_WATER            = 'WASHSectorImprovedWater'
RP_RES_SUM_WASH_SECT_IMPR_SANI             = 'WASHSectorImprovedSanitation'
RP_RES_SUM_FOOD_SEC_SECT_RED_FOOD_INSEC    = 'foodSecSectorReduceFoodInsecurity'
RP_RES_SUM_URB_SECT_REDUCE_INFORM_SETT     = 'urbSectorReduceInformalSettlements'
RP_RES_SUM_ENERGY_SECT_INCR_ACC_ELEC       = 'energySectorIncreaseAccessElectricity'
RP_RES_SUM_ENERGY_SECT_INCR_ACC_CLEAN_COOK = 'energySectorIncreaseAccessCleanCooking'
RP_RES_SUM_SAVINGS_PER_DOLLAR_INVEST       = 'savingsPerDollarInvested'

# Sources (for Sector goals and Review defaults; since they are not guaranteed to be a 1-1 correspondence between the fields there and the available
# sources, we store them in a separate MV)

RP_SRC_HH_SIZE                               = 'householdSizeSource'                    # str
RP_SRC_SECTOR_EDU_SCHOOL_AGE_RANGES          = 'schoolAgeRangesSource'                  # str
RP_SRC_FP_METHOD_MIX                         = 'FPMethodMixSource'                      # str; only for revised sources; default comes from FamPlan
RP_SRC_FP_EFFECTIVENESS                      = 'FPEffectivenessSource'                  # str; only for revised sources; default comes from FamPlan
RP_SRC_FP_UNIT_COSTS                         = 'FPUnitCostsSource'                      # str
RP_SRC_DP_FIRST_YEAR_POP                     = 'DPFirstYearPopSource'                   # str
RP_SRC_FP_TFR                                = 'FP_TFRSource'                           # str

RP_SRC_SECTOR_EDU_AVG_ANN_TEACHER_SAL_PRIM   = 'avgAnnualTeacherSalaryPrimarySource'    # str
RP_SRC_SECTOR_EDU_ANN_COST_EDU_PRIM_STUDENT  = 'annualCostEducPrimaryStudentSource'     # str
RP_SRC_SECTOR_EDU_ANN_COST_EDU_SEC_STUDENT   = 'annualCostEducSecondaryStudentSource'   # str

RP_SRC_SECTOR_HLTH_AVG_UNIT_COST_SKILLED_DELIV     = 'avgUnitCostSkilledDeliverySource'    # str
RP_SRC_SECTOR_HLTH_AVG_UNIT_COST_ANC_4_PLUS_VISITS = 'avgUnitCostANC4PlusVisitsSource'     # str
RP_SRC_SECTOR_HLTH_PERC_SKILLED_HLTH_PROF_DOCTORS  = 'percSkilledHealthProfDoctorsSource'  # str
RP_SRC_SECTOR_HLTH_PERC_SKILLED_HLTH_PROF_NURSES   = 'percSkilledHealthProfNursesSource'   # str
RP_SRC_SECTOR_HLTH_AVG_SALARY_DOCTORS              = 'avgSalaryDoctorsSource'              # str
RP_SRC_SECTOR_HLTH_AVG_SALARY_NURSES               = 'avgSalaryNursesSource'               # str

RP_SRC_SECTOR_WASH_CAP_COSTS_PER_HH_IMPR_WATER     = 'capCostsPerHHImprovedWaterSource'       # str
RP_SRC_SECTOR_WASH_CAP_COSTS_PER_HH_IMPR_SANI      = 'capCostsPerHHImprovedSanitationSource'  # str

RP_SRC_SECTOR_FOOD_PRIM_STAPLE_CROP                    = 'primaryStapleCropSource'                      # str
RP_SRC_SECTOR_FOOD_CROP_LAND                           = 'cropLandSource'                               # str
RP_SRC_SECTOR_FOOD_STAPLE_CROP_PROD_BASE               = 'stapleCropProductionBaselineSource'           # str
RP_SRC_SECTOR_FOOD_TONNES_HARV_PERC_HECT               = 'tonnesHarvestedPerHectareSource'              # str
RP_SRC_SECTOR_FOOD_ANN_KG_PER_YEAR_CONSUMP_STAPLE_CROP = 'annualKgPerYearConsumptionStapleCropSource'   # str
RP_SRC_SECTOR_FOOD_PROD_COSTS_STAPLE_CROP              = 'productionCostsStapleCropSource'              # str
RP_SRC_SECTOR_FOOD_DAILY_COST_FOOD_AID                 = 'dailyCostFoodAidSource'                       # str

RP_SRC_SECTOR_URB_PERC_POP_URB_BASE_END         = 'percPopUrbanBaselineEndlineSource'  # str
RP_SRC_SECTOR_URB_COST_PER_HH_MOVE_TO_HOUSING   = 'costPerHHMoveToHousingSource'       # str

RP_SRC_SECTOR_ENERGY_CAP_COSTS_PER_HH_CONNECT_GRID    = 'capCostsPerHHConnectGridSource'     # str
RP_SRC_SECTOR_ENERGY_CAP_COSTS_PER_HH_CLEAN_COOKING   = 'capCostPerHHCleanCookingSource'     # str

RP_SRC_SECTOR_ECO_GDP_PER_CAPITA    = 'GDPPerCapitaSource'                # str
RP_SRC_SECTOR_ECO_LABOR_PARTIC_RATE = 'laborParticipationRateSource'      # str
RP_SRC_SECTOR_ECO_CHANGE_GDP_CDR    = 'changeInGDPPerPercChangeCDRSource' # str

RP_SRC_GOALS_PRIMARY_ENROLL_ALL          = 'primaryEnrollmentAllSource'
RP_SRC_GOALS_PRIMARY_ENROLL_MALE         = 'primaryEnrollmentMaleSource'
RP_SRC_GOALS_PRIMARY_ENROLL_FEMALE       = 'primaryEnrollmentFemaleSource'
RP_SRC_GOALS_SECONDARY_ENROLL_ALL        = 'secondaryEnrollmentAllSource'
RP_SRC_GOALS_SECONDARY_ENROLL_MALE       = 'secondaryEnrollmentMaleSource'
RP_SRC_GOALS_SECONDARY_ENROLL_FEMALE     = 'secondaryEnrollmentFemaleSource'
RP_SRC_GOALS_STUDENT_TEACHER_RATIO       = 'studentTeacherRatioSource'
RP_SRC_GOALS_BIRTHS_ATTEND_SKILLED_PERS  = 'birthsAttendedBySkilledPersonnelSource'
RP_SRC_GOALS_PREG_W_4_PLUS_ANC_VISITS    = 'pregnantWomenRec4PlusANCVisitsSource'
RP_SRC_GOALS_HLTH_PROF_1000_POP          = 'healthProfPer1000PopSource'
RP_SRC_GOALS_PERC_ACCESS_IMP_WATER       = 'percAccessImprovedWaterSource'
RP_SRC_GOALS_PERC_ACCESS_IMP_SANI        = 'percAccessImprovedSanitationSource'
RP_SRC_GOALS_PERC_PROD_STAPLE_CROP       = 'percDomesticProductionStapleCropSource'
RP_SRC_GOALS_PERC_SEV_FOOD_INSEC         = 'percSevereFoodInsecuritySource'
RP_SRC_GOALS_PERC_URB_POP_INFORM_SET     = 'percUrbanPopInformalSettlementsSource'
RP_SRC_GOALS_PERC_POP_ACCESS_ELEC        = 'percPopAccessElectricitySource'
RP_SRC_GOALS_KWH_PRODUCED                = 'KWhProducedPerPersonPerYearSource'
RP_SRC_GOALS_PERC_ACCESS_CLEAN_COOK_TECH = 'percAccessCleanCookingTechSource'
RP_SRC_GOALS_UNEMPLOYMENT_RATE           = 'unemploymentRateSource'
RP_SRC_GOALS_PERC_NEET_ALL               = 'percNEETAllSource'
RP_SRC_GOALS_PERC_NEET_MALES             = 'percNEETMalesSource'
RP_SRC_GOALS_PERC_NEET_FEMALES           = 'percNEETFemalesSource'

RP_SRC_CLIM_BASELINE_MEAN_MED_TEMP              = 'baselineMeanMedianTempSource'                       # str
RP_SRC_CLIM_PERC_CHANGE_GDP_1_DEG_WARM          = 'percChangeGDP1DegreeWarmingSource'                  # str
RP_SRC_CLIM_PERC_CHANGE_ENERGY_NEEDS_1_DEG_WARM = 'percChangeEnergyNeeds1DegreeWarmingSource'          # str
RP_SRC_CLIM_PERC_CHANGE_STAPLE_CROP_1_DEG_WARM  = 'percChangeStapleCroplandNeeds1DegreeWarmingSource'  # str
RP_SRC_CLIM_PERC_CHANGE_STAPLE_CROP_2_DEG_WARM  = 'percChangeStapleCroplandNeeds2DegreesWarmingSource' # str
RP_SRC_CLIM_PERC_CHANGE_STAPLE_CROP_3_DEG_WARM  = 'percChangeStapleCroplandNeeds3DegreesWarmingSource' # str

RP_SSP_BASE = 'base'
RP_SSP1     = 'SSP1'
RP_SSP2     = 'SSP2'
RP_SSP3     = 'SSP3'
RP_SSP5     = 'SSP5'


