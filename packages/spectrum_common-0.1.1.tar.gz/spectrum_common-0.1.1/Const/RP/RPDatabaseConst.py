from SpectrumCommon.Const.GB.GBConst import GB_NOT_FOUND

#######################################################################################################
#                                                                                                     #
#                                       Country Defaults DB (CDDB)                                    #
#                                                                                                     #
#######################################################################################################

RP_ISO_NUMERIC_COUNTRY_CODE_TAG_CDDB        = '<ISO Numeric Country Code>'
RP_ISO_ALPHA_3_COUNTRY_CODE_TAG_CDDB        = '<ISO Alpha-3 Country Code>'
RP_COUNTRY_NAME_TAG_CDDB                    = '<Country Name>'
RP_CLASSIFICATION_TAG_CDDB                  = '<Classification>'
RP_REGION_TAG_CDDB                          = '<Region>'
RP_BASELINE_AVG_TEMP_TAG_CDDB               = '<Baseline Average Temperature Celcius>'
RP_EXCH_RATE_TAG_CDDB                       = '<Exchange Rate to USD>'
RP_HH_SIZE_TAG_CDDB                         = '<Household Size (Overall)>'
RP_PERC_URBAN_INFORMAL_TAG_CDDB             = '<Percent Urban Informal>'
RP_COST_F_STERILIZATION_TAG_CDDB            = '<Cost Female Sterilization>'
RP_COST_M_STERILIZATION_TAG_CDDB            = '<Cost Male Sterilization>'
RP_COST_IUD_TAG_CDDB                        = '<Cost IUD>'
RP_COST_IMPLANT_TAG_CDDB                    = '<Cost Implant>'
RP_COST_INJECTIONS_TAG_CDDB                 = '<Cost Injections>'
RP_COST_PILL_TAG_CDDB                       = '<Cost Pill>'
RP_COST_CONDOMS_TAG_CDDB                    = '<Cost Condoms>'
RP_COST_VAG_BARR_TAG_CDDB                   = '<Cost Vaginal Barrier>'
RP_COST_OTHER_MODERN_TAG_CDDB               = '<Cost Other Modern>'
RP_COST_INDIRECTS_TAG_CDDB                  = '<Indirects>'
RP_AGE_START_PRIM_TAG_CDDB                  = '<Age Start Primary>'
RP_AGE_END_PRIM_TAG_CDDB                    = '<Age End Primary>'
RP_AGE_START_SEC_TAG_CDDB                   = '<Age Start Secondary>'
RP_AGE_END_SEC_TAG_CDDB                     = '<Age End Secondary>'
RP_PERC_ENROLL_PRIM_TAG_CDDB                = '<Percent Enrollment (Primary)>'
RP_PRIM_ENROLL_FEMALES_TAG_CDDB             = '<Primary Enrollment (Females)>'
RP_PRIM_ENROLL_MALES_TAG_CDDB               = '<Primary Enrollment (Males)>'
RP_PERC_ENROLL_SEC_TAG_CDDB                 = '<Percent Enrollment (Secondary)>'
RP_SEC_ENROLL_FEMALES_TAG_CDDB              = '<Secondary Enrollment (Females)>'
RP_SEC_ENROLL_MALES_TAG_CDDB                = '<Secondary Enrollment (Males)>'
RP_TEACHER_RATIO_PRIM_TAG_CDDB              = '<Teacher Ratio (Primary)>'
RP_TEACHER_RATIO_SEC_TAG_CDDB               = '<Teacher Ratio (Secondary)>'
RP_PRIM_COSTS_TAG_CDDB                      = '<Primary Costs>'
RP_SEC_COSTS_TAG_CDDB                       = '<Secondary Costs>'
RP_PRIM_TEACHER_SALARY_TAG_CDDB             = '<Primary Teacher Salary>'
RP_SEC_TEACHER_SALARY_TAG_CDDB              = '<Secondary Teacher Salary>'
RP_SKILLED_BIRTHS_TAG_CDDB                  = '<Skilled Births>'
RP_ANC_4_PLUS_TAG_CDDB                      = '<ANC 4 Plus>'
RP_PROFS_TAG_CDDB                           = '<Profs>'
RP_DOCTOR_SALARY_PUBLIC_TAG_CDDB            = '<Doctor Salary Public>'
RP_NURSE_SALARY_PUBLIC_TAG_CDDB             = '<Nurse Salary Public>'
RP_SKILLED_BIRTH_COSTS_TAG_CDDB             = '<Skilled Birth Costs>'
RP_ANC_COSTS_TAG_CDDB                       = '<ANC Costs>'
RP_PERC_DOCTORS_TAG_CDDB                    = '<Percent Doctors>'
RP_PERC_NURSES_TAG_CDDB                     = '<Percent Nurses>'
RP_PERC_IMPROVED_WATER_SOURCE_TAG_CDDB      = '<Percent Improved Water Source>'
RP_PERC_IMPROVED_SANI_TAG_CDDB              = '<Percent Improved Sanitation>'
RP_CAP_COST_PP_IMPROVED_WATER_TAG_CDDB      = '<Capital Cost PP Improved Water>'
RP_CAP_COST_PP_IMPROVED_SANI_TAG_CDDB       = '<Capital Cost PP Improved Sanitation>'
RP_PERC_PEOPLE_PHASE_4_PLUS_TAG_CDDB        = '<Percent People in Phase 4 Plus>'
RP_SEVERE_INSECURITY_TAG_CDDB               = '<Severe Insecurity>'
RP_AREA_HARVESTED_TAG_CDDB                  = '<Area Harvested>'
RP_STAPLE_PRODUCTION_TAG_CDDB               = '<Staple Production (In Tons)>'
RP_DOMINANT_CROP_TAG_CDDB                   = '<Dominant Crop (Maize, Wheat or Rice)>'
RP_AGRICULTURAL_LAND_TAG_CDDB               = '<Agricultural Land (Hectares)>'
RP_CROPLAND_HECTARES_TAG_CDDB               = '<Cropland Hectares>'
RP_STAPLE_ANNUAL_CONSUMP_PER_CAP_TAG_CDDB   = '<Staple Annual Consumption per Capita (kg)>'
RP_PROD_COST_PER_TON_DOMINANT_CROP_TAG_CDDB = '<Production Cost per Ton for Dominant Crop>'
RP_DAILY_COST_FOOD_AID_PER_PERSON_TAG_CDDB  = '<Daily Cost of Food Aid per Person>'
RP_PERC_POP_ELECTRICITY_TAG_CDDB            = '<Percent Pop Electricity>'
RP_ELECTRICITY_PROD_PER_CAP_TAG_CDDB        = '<Electricity Produced per Capita>'
RP_COST_PER_KWH_TAG_CDDB                    = '<Cost per KWh>'
RP_LCOE_0_PER_PERSON_PER_DAY_TAG_CDDB       = '<LCOE 0 per Person per Day>'
RP_CLEAN_COOKING_TAG_CDDB                   = '<Clean Cooking>'
RP_CLEAN_COOKING_CAP_COST_TAG_CDDB          = '<Clean Cooking Capital Cost>'
RP_COST_BUILD_URBAN_HOUSEHOLD_TAG_CDDB      = '<Cost to Build Urban Household>'
RP_UNEMPLOYMENT_TAG_CDDB                    = '<Unemployment>'
RP_GDP_PER_CAP_TAG_CDDB                     = '<GDP per Capita>'
RP_LABOR_MALES_TAG_CDDB                     = '<Labor Males>'
RP_LABOR_FEMALES_TAG_CDDB                   = '<Labor Females>'
RP_LABOR_BOTH_TAG_CDDB                      = '<Labor Both>'
RP_GDP_BOOST_PERC_CHANGE_CDR_TAG_CDDB       = '<GDP Boost per Percent Change in CDR>'
RP_YOUTH_NEED_ALL_TAG_CDDB                  = '<Youth NEET All>'
RP_YOUTH_NEED_MALE_TAG_CDDB                 = '<Youth NEET Male>'
RP_YOUTH_NEED_FEMALE_TAG_CDDB               = '<Youth NEET Female>'
RP_1_DEGREE_GDP_TAG_CDDB                    = '<1 Degree GDP>'
RP_1_DEGREE_STAPLE_TAG_CDDB                 = '<1 Degree Staple>'
RP_2_DEGREE_STAPLE_TAG_CDDB                 = '<2 Degree Staple>'
RP_3_DEGREE_STAPLE_TAG_CDDB                 = '<3 Degree Staple>'
RP_1_DEGREE_ON_ENERGY_TAG_CDDB              = '<1 Degree on Energy>'

RP_ISO_ALPHA_3_COUNTRY_CODE_KEY_CDDB        = 'ISO3AlphaCountryCode'
RP_COUNTRY_NAME_KEY_CDDB                    = 'countryName'
RP_CLASSIFICATION_KEY_CDDB                  = 'classification'
RP_REGION_KEY_CDDB                          = 'region'
RP_BASELINE_AVG_TEMP_KEY_CDDB               = 'baselineAvgTemp'
RP_EXCH_RATE_KEY_CDDB                       = 'exchangeRate'
RP_HH_SIZE_KEY_CDDB                         = 'HHSize'
RP_PERC_URBAN_INFORMAL_KEY_CDDB             = 'percUrbanInformal'
RP_COST_F_STERILIZATION_KEY_CDDB            = 'costFSterilization'
RP_COST_M_STERILIZATION_KEY_CDDB            = 'costMSterilization'
RP_COST_IUD_KEY_CDDB                        = 'costIUD'
RP_COST_IMPLANT_KEY_CDDB                    = 'costImplant'
RP_COST_INJECTIONS_KEY_CDDB                 = 'costInjections'
RP_COST_PILL_KEY_CDDB                       = 'costPill'
RP_COST_CONDOMS_KEY_CDDB                    = 'costCondoms'
RP_COST_VAG_BARR_KEY_CDDB                   = 'costVaginalBarrier'
RP_COST_OTHER_MODERN_KEY_CDDB               = 'costOtherModern'
RP_COST_INDIRECTS_KEY_CDDB                  = 'indirects'
RP_AGE_START_PRIM_KEY_CDDB                  = 'ageStartPrimary'
RP_AGE_END_PRIM_KEY_CDDB                    = 'ageEndPrimary'
RP_AGE_START_SEC_KEY_CDDB                   = 'ageStartSecondary'
RP_AGE_END_SEC_KEY_CDDB                     = 'ageEndSecondary'
RP_PERC_ENROLL_PRIM_KEY_CDDB                = 'percEnrollmentPrimary'
RP_PRIM_ENROLL_FEMALES_KEY_CDDB             = 'primaryEnrollmentFemales'
RP_PRIM_ENROLL_MALES_KEY_CDDB               = 'primaryEnrollmentMales'
RP_PERC_ENROLL_SEC_KEY_CDDB                 = 'percEnrollmentSecondary'
RP_SEC_ENROLL_FEMALES_KEY_CDDB              = 'secondaryEnrollmentFemales'
RP_SEC_ENROLL_MALES_KEY_CDDB                = 'secondaryEnrollmentMales'
RP_TEACHER_RATIO_PRIM_KEY_CDDB              = 'teacherRatioPrimary'
RP_TEACHER_RATIO_SEC_KEY_CDDB               = 'teacherRatioSecondary'
RP_PRIM_COSTS_KEY_CDDB                      = 'primaryCosts'
RP_SEC_COSTS_KEY_CDDB                       = 'secondaryCosts'
RP_PRIM_TEACHER_SALARY_KEY_CDDB             = 'primaryTeacherSalary'
RP_SEC_TEACHER_SALARY_KEY_CDDB              = 'secondaryTeacherSalary'
RP_SKILLED_BIRTHS_KEY_CDDB                  = 'skilledBirths'
RP_ANC_4_PLUS_KEY_CDDB                      = 'ANC4Plus'
RP_PROFS_KEY_CDDB                           = 'profs'
RP_DOCTOR_SALARY_PUBLIC_KEY_CDDB            = 'doctorSalaryPublic'
RP_NURSE_SALARY_PUBLIC_KEY_CDDB             = 'nurseSalaryPublic'
RP_SKILLED_BIRTH_COSTS_KEY_CDDB             = 'skilledBirthCosts'
RP_ANC_COSTS_KEY_CDDB                       = 'ANCCosts'
RP_PERC_DOCTORS_KEY_CDDB                    = 'percDoctors'
RP_PERC_NURSES_KEY_CDDB                     = 'percNurses'
RP_PERC_IMPROVED_WATER_SOURCE_KEY_CDDB      = 'percImprovedWaterSource'
RP_PERC_IMPROVED_SANI_KEY_CDDB              = 'percImprovedSanitation'
RP_CAP_COST_PP_IMPROVED_WATER_KEY_CDDB      = 'capitalCostPPImprovedWater'
RP_CAP_COST_PP_IMPROVED_SANI_KEY_CDDB       = 'capitalCostPPImprovedSanitation'
RP_PERC_PEOPLE_PHASE_4_PLUS_KEY_CDDB        = 'percPeoplePhase4Plus'
RP_SEVERE_INSECURITY_KEY_CDDB               = 'severeInsecurity'
RP_AREA_HARVESTED_KEY_CDDB                  = 'areaHarvested'
RP_STAPLE_PRODUCTION_KEY_CDDB               = 'stapleProduction'
RP_DOMINANT_CROP_KEY_CDDB                   = 'dominantCrop'
RP_AGRICULTURAL_LAND_KEY_CDDB               = 'agriculturalLand'
RP_CROPLAND_HECTARES_KEY_CDDB               = 'croplandHectares'
RP_STAPLE_ANNUAL_CONSUMP_PER_CAP_KEY_CDDB   = 'stapleAnnualConsumptionPerCapita'
RP_PROD_COST_PER_TON_DOMINANT_CROP_KEY_CDDB = 'productionCostPerTonDominantCrop'
RP_DAILY_COST_FOOD_AID_PER_PERSON_KEY_CDDB  = 'dailyCostFoodAidPerPerson'
RP_PERC_POP_ELECTRICITY_KEY_CDDB            = 'percPopElectricity'
RP_ELECTRICITY_PROD_PER_CAP_KEY_CDDB        = 'electricityProducedPerCapita'
RP_COST_PER_KWH_KEY_CDDB                    = 'costPerKWh'
RP_LCOE_0_PER_PERSON_PER_DAY_KEY_CDDB       = 'LCOE0PerPersonPerDay'
RP_CLEAN_COOKING_KEY_CDDB                   = 'cleanCooking'
RP_CLEAN_COOKING_CAP_COST_KEY_CDDB          = 'cleanCookingCapitalCost'
RP_COST_BUILD_URBAN_HOUSEHOLD_KEY_CDDB      = 'costBuildUrbanHH'
RP_UNEMPLOYMENT_KEY_CDDB                    = 'unemployment'
RP_GDP_PER_CAP_KEY_CDDB                     = 'GDPPerCapita'
RP_LABOR_MALES_KEY_CDDB                     = 'laborMales'
RP_LABOR_FEMALES_KEY_CDDB                   = 'laborFemales'
RP_LABOR_BOTH_KEY_CDDB                      = 'laborBoth'
RP_GDP_BOOST_PERC_CHANGE_CDR_KEY_CDDB       = 'GDPBoostPercChangeCDR'
RP_YOUTH_NEET_ALL_KEY_CDDB                  = 'youthNEETAll'
RP_YOUTH_NEET_MALE_KEY_CDDB                 = 'youthNEETMale'
RP_YOUTH_NEET_FEMALE_KEY_CDDB               = 'youthNEETFemale'
RP_1_DEGREE_GDP_KEY_CDDB                    = 'oneDegreeGDP'
RP_1_DEGREE_STAPLE_KEY_CDDB                 = 'oneDegreeStaple'
RP_2_DEGREE_STAPLE_KEY_CDDB                 = 'twoDegreeStaple'
RP_3_DEGREE_STAPLE_KEY_CDDB                 = 'threeDegreeStaple'
RP_1_DEGREE_ON_ENERGY_KEY_CDDB              = 'oneDegreeEnergy'

RP_tag_fields_CDDB = {
    RP_ISO_NUMERIC_COUNTRY_CODE_TAG_CDDB        : GB_NOT_FOUND,
    RP_ISO_ALPHA_3_COUNTRY_CODE_TAG_CDDB        : RP_ISO_ALPHA_3_COUNTRY_CODE_KEY_CDDB,
    RP_COUNTRY_NAME_TAG_CDDB                    : RP_COUNTRY_NAME_KEY_CDDB,
    RP_CLASSIFICATION_TAG_CDDB                  : RP_CLASSIFICATION_KEY_CDDB,
    RP_REGION_TAG_CDDB                          : RP_REGION_KEY_CDDB,
    RP_BASELINE_AVG_TEMP_TAG_CDDB               : RP_BASELINE_AVG_TEMP_KEY_CDDB,
    RP_EXCH_RATE_TAG_CDDB                       : RP_EXCH_RATE_KEY_CDDB,
    RP_HH_SIZE_TAG_CDDB                         : RP_HH_SIZE_KEY_CDDB,
    RP_PERC_URBAN_INFORMAL_TAG_CDDB             : RP_PERC_URBAN_INFORMAL_KEY_CDDB,
    RP_COST_F_STERILIZATION_TAG_CDDB            : RP_COST_F_STERILIZATION_KEY_CDDB,
    RP_COST_M_STERILIZATION_TAG_CDDB            : RP_COST_M_STERILIZATION_KEY_CDDB,
    RP_COST_IUD_TAG_CDDB                        : RP_COST_IUD_KEY_CDDB,
    RP_COST_IMPLANT_TAG_CDDB                    : RP_COST_IMPLANT_KEY_CDDB,
    RP_COST_INJECTIONS_TAG_CDDB                 : RP_COST_INJECTIONS_KEY_CDDB,
    RP_COST_PILL_TAG_CDDB                       : RP_COST_PILL_KEY_CDDB,
    RP_COST_CONDOMS_TAG_CDDB                    : RP_COST_CONDOMS_KEY_CDDB,
    RP_COST_VAG_BARR_TAG_CDDB                   : RP_COST_VAG_BARR_KEY_CDDB,
    RP_COST_OTHER_MODERN_TAG_CDDB               : RP_COST_OTHER_MODERN_KEY_CDDB,
    RP_COST_INDIRECTS_TAG_CDDB                  : RP_COST_INDIRECTS_KEY_CDDB,
    RP_AGE_START_PRIM_TAG_CDDB                  : RP_AGE_START_PRIM_KEY_CDDB,
    RP_AGE_END_PRIM_TAG_CDDB                    : RP_AGE_END_PRIM_KEY_CDDB,
    RP_AGE_START_SEC_TAG_CDDB                   : RP_AGE_START_SEC_KEY_CDDB,
    RP_AGE_END_SEC_TAG_CDDB                     : RP_AGE_END_SEC_KEY_CDDB,
    RP_PERC_ENROLL_PRIM_TAG_CDDB                : RP_PERC_ENROLL_PRIM_KEY_CDDB,
    RP_PRIM_ENROLL_FEMALES_TAG_CDDB             : RP_PRIM_ENROLL_FEMALES_KEY_CDDB,
    RP_PRIM_ENROLL_MALES_TAG_CDDB               : RP_PRIM_ENROLL_MALES_KEY_CDDB,
    RP_PERC_ENROLL_SEC_TAG_CDDB                 : RP_PERC_ENROLL_SEC_KEY_CDDB,
    RP_SEC_ENROLL_FEMALES_TAG_CDDB              : RP_SEC_ENROLL_FEMALES_KEY_CDDB,
    RP_SEC_ENROLL_MALES_TAG_CDDB                : RP_SEC_ENROLL_MALES_KEY_CDDB,
    RP_TEACHER_RATIO_PRIM_TAG_CDDB              : RP_TEACHER_RATIO_PRIM_KEY_CDDB,
    RP_TEACHER_RATIO_SEC_TAG_CDDB               : RP_TEACHER_RATIO_SEC_KEY_CDDB,
    RP_PRIM_COSTS_TAG_CDDB                      : RP_PRIM_COSTS_KEY_CDDB,
    RP_SEC_COSTS_TAG_CDDB                       : RP_SEC_COSTS_KEY_CDDB,
    RP_PRIM_TEACHER_SALARY_TAG_CDDB             : RP_PRIM_TEACHER_SALARY_KEY_CDDB,
    RP_SEC_TEACHER_SALARY_TAG_CDDB              : RP_SEC_TEACHER_SALARY_KEY_CDDB,
    RP_SKILLED_BIRTHS_TAG_CDDB                  : RP_SKILLED_BIRTHS_KEY_CDDB,
    RP_ANC_4_PLUS_TAG_CDDB                      : RP_ANC_4_PLUS_KEY_CDDB,
    RP_PROFS_TAG_CDDB                           : RP_PROFS_KEY_CDDB,
    RP_DOCTOR_SALARY_PUBLIC_TAG_CDDB            : RP_DOCTOR_SALARY_PUBLIC_KEY_CDDB,
    RP_NURSE_SALARY_PUBLIC_TAG_CDDB             : RP_NURSE_SALARY_PUBLIC_KEY_CDDB,
    RP_SKILLED_BIRTH_COSTS_TAG_CDDB             : RP_SKILLED_BIRTH_COSTS_KEY_CDDB,
    RP_ANC_COSTS_TAG_CDDB                       : RP_ANC_COSTS_KEY_CDDB,
    RP_PERC_DOCTORS_TAG_CDDB                    : RP_PERC_DOCTORS_KEY_CDDB,
    RP_PERC_NURSES_TAG_CDDB                     : RP_PERC_NURSES_KEY_CDDB,
    RP_PERC_IMPROVED_WATER_SOURCE_TAG_CDDB      : RP_PERC_IMPROVED_WATER_SOURCE_KEY_CDDB,
    RP_PERC_IMPROVED_SANI_TAG_CDDB              : RP_PERC_IMPROVED_SANI_KEY_CDDB,
    RP_CAP_COST_PP_IMPROVED_WATER_TAG_CDDB      : RP_CAP_COST_PP_IMPROVED_WATER_KEY_CDDB,
    RP_CAP_COST_PP_IMPROVED_SANI_TAG_CDDB       : RP_CAP_COST_PP_IMPROVED_SANI_KEY_CDDB,
    RP_PERC_PEOPLE_PHASE_4_PLUS_TAG_CDDB        : RP_PERC_PEOPLE_PHASE_4_PLUS_KEY_CDDB,
    RP_SEVERE_INSECURITY_TAG_CDDB               : RP_SEVERE_INSECURITY_KEY_CDDB,
    RP_AREA_HARVESTED_TAG_CDDB                  : RP_AREA_HARVESTED_KEY_CDDB,
    RP_STAPLE_PRODUCTION_TAG_CDDB               : RP_STAPLE_PRODUCTION_KEY_CDDB,
    RP_DOMINANT_CROP_TAG_CDDB                   : RP_DOMINANT_CROP_KEY_CDDB,
    RP_AGRICULTURAL_LAND_TAG_CDDB               : RP_AGRICULTURAL_LAND_KEY_CDDB,
    RP_CROPLAND_HECTARES_TAG_CDDB               : RP_CROPLAND_HECTARES_KEY_CDDB,
    RP_STAPLE_ANNUAL_CONSUMP_PER_CAP_TAG_CDDB   : RP_STAPLE_ANNUAL_CONSUMP_PER_CAP_KEY_CDDB,
    RP_PROD_COST_PER_TON_DOMINANT_CROP_TAG_CDDB : RP_PROD_COST_PER_TON_DOMINANT_CROP_KEY_CDDB,
    RP_DAILY_COST_FOOD_AID_PER_PERSON_TAG_CDDB  : RP_DAILY_COST_FOOD_AID_PER_PERSON_KEY_CDDB,
    RP_PERC_POP_ELECTRICITY_TAG_CDDB            : RP_PERC_POP_ELECTRICITY_KEY_CDDB,
    RP_ELECTRICITY_PROD_PER_CAP_TAG_CDDB        : RP_ELECTRICITY_PROD_PER_CAP_KEY_CDDB,
    RP_COST_PER_KWH_TAG_CDDB                    : RP_COST_PER_KWH_KEY_CDDB,
    RP_LCOE_0_PER_PERSON_PER_DAY_TAG_CDDB       : RP_LCOE_0_PER_PERSON_PER_DAY_KEY_CDDB,
    RP_CLEAN_COOKING_TAG_CDDB                   : RP_CLEAN_COOKING_KEY_CDDB,
    RP_CLEAN_COOKING_CAP_COST_TAG_CDDB          : RP_CLEAN_COOKING_CAP_COST_KEY_CDDB,
    RP_COST_BUILD_URBAN_HOUSEHOLD_TAG_CDDB      : RP_COST_BUILD_URBAN_HOUSEHOLD_KEY_CDDB,
    RP_UNEMPLOYMENT_TAG_CDDB                    : RP_UNEMPLOYMENT_KEY_CDDB,
    RP_GDP_PER_CAP_TAG_CDDB                     : RP_GDP_PER_CAP_KEY_CDDB,
    RP_LABOR_MALES_TAG_CDDB                     : RP_LABOR_MALES_KEY_CDDB,
    RP_LABOR_FEMALES_TAG_CDDB                   : RP_LABOR_FEMALES_KEY_CDDB,
    RP_LABOR_BOTH_TAG_CDDB                      : RP_LABOR_BOTH_KEY_CDDB,
    RP_GDP_BOOST_PERC_CHANGE_CDR_TAG_CDDB       : RP_GDP_BOOST_PERC_CHANGE_CDR_KEY_CDDB,
    RP_YOUTH_NEED_ALL_TAG_CDDB                  : RP_YOUTH_NEET_ALL_KEY_CDDB,
    RP_YOUTH_NEED_MALE_TAG_CDDB                 : RP_YOUTH_NEET_MALE_KEY_CDDB,
    RP_YOUTH_NEED_FEMALE_TAG_CDDB               : RP_YOUTH_NEET_FEMALE_KEY_CDDB,
    RP_1_DEGREE_GDP_TAG_CDDB                    : RP_1_DEGREE_GDP_KEY_CDDB,
    RP_1_DEGREE_STAPLE_TAG_CDDB                 : RP_1_DEGREE_STAPLE_KEY_CDDB,
    RP_2_DEGREE_STAPLE_TAG_CDDB                 : RP_2_DEGREE_STAPLE_KEY_CDDB,
    RP_3_DEGREE_STAPLE_TAG_CDDB                 : RP_3_DEGREE_STAPLE_KEY_CDDB,
    RP_1_DEGREE_ON_ENERGY_TAG_CDDB              : RP_1_DEGREE_ON_ENERGY_KEY_CDDB,
}

RP_tag_columns_CDDB = {
    RP_ISO_NUMERIC_COUNTRY_CODE_TAG_CDDB        : 1,
    RP_ISO_ALPHA_3_COUNTRY_CODE_TAG_CDDB        : 2,
    RP_COUNTRY_NAME_TAG_CDDB                    : 3,
    RP_CLASSIFICATION_TAG_CDDB                  : GB_NOT_FOUND,
    RP_REGION_TAG_CDDB                          : GB_NOT_FOUND,
    RP_BASELINE_AVG_TEMP_TAG_CDDB               : GB_NOT_FOUND,
    RP_EXCH_RATE_TAG_CDDB                       : GB_NOT_FOUND,
    RP_HH_SIZE_TAG_CDDB                         : GB_NOT_FOUND,
    RP_PERC_URBAN_INFORMAL_TAG_CDDB             : GB_NOT_FOUND,
    RP_COST_F_STERILIZATION_TAG_CDDB            : GB_NOT_FOUND,
    RP_COST_M_STERILIZATION_TAG_CDDB            : GB_NOT_FOUND,
    RP_COST_IUD_TAG_CDDB                        : GB_NOT_FOUND,
    RP_COST_IMPLANT_TAG_CDDB                    : GB_NOT_FOUND,
    RP_COST_INJECTIONS_TAG_CDDB                 : GB_NOT_FOUND,
    RP_COST_PILL_TAG_CDDB                       : GB_NOT_FOUND,
    RP_COST_CONDOMS_TAG_CDDB                    : GB_NOT_FOUND,
    RP_COST_VAG_BARR_TAG_CDDB                   : GB_NOT_FOUND,
    RP_COST_OTHER_MODERN_TAG_CDDB               : GB_NOT_FOUND,
    RP_COST_INDIRECTS_TAG_CDDB                  : GB_NOT_FOUND,
    RP_AGE_START_PRIM_TAG_CDDB                  : GB_NOT_FOUND,
    RP_AGE_END_PRIM_TAG_CDDB                    : GB_NOT_FOUND,
    RP_AGE_START_SEC_TAG_CDDB                   : GB_NOT_FOUND,
    RP_AGE_END_SEC_TAG_CDDB                     : GB_NOT_FOUND,
    RP_PERC_ENROLL_PRIM_TAG_CDDB                : GB_NOT_FOUND,
    RP_PRIM_ENROLL_FEMALES_TAG_CDDB             : GB_NOT_FOUND,
    RP_PRIM_ENROLL_MALES_TAG_CDDB               : GB_NOT_FOUND,
    RP_PERC_ENROLL_SEC_TAG_CDDB                 : GB_NOT_FOUND,
    RP_SEC_ENROLL_FEMALES_TAG_CDDB              : GB_NOT_FOUND,
    RP_SEC_ENROLL_MALES_TAG_CDDB                : GB_NOT_FOUND,
    RP_TEACHER_RATIO_PRIM_TAG_CDDB              : GB_NOT_FOUND,
    RP_TEACHER_RATIO_SEC_TAG_CDDB               : GB_NOT_FOUND,
    RP_PRIM_COSTS_TAG_CDDB                      : GB_NOT_FOUND,
    RP_SEC_COSTS_TAG_CDDB                       : GB_NOT_FOUND,
    RP_PRIM_TEACHER_SALARY_TAG_CDDB             : GB_NOT_FOUND,
    RP_SEC_TEACHER_SALARY_TAG_CDDB              : GB_NOT_FOUND,
    RP_SKILLED_BIRTHS_TAG_CDDB                  : GB_NOT_FOUND,
    RP_ANC_4_PLUS_TAG_CDDB                      : GB_NOT_FOUND,
    RP_PROFS_TAG_CDDB                           : GB_NOT_FOUND,
    RP_DOCTOR_SALARY_PUBLIC_TAG_CDDB            : GB_NOT_FOUND,
    RP_NURSE_SALARY_PUBLIC_TAG_CDDB             : GB_NOT_FOUND,
    RP_SKILLED_BIRTH_COSTS_TAG_CDDB             : GB_NOT_FOUND,
    RP_ANC_COSTS_TAG_CDDB                       : GB_NOT_FOUND,
    RP_PERC_DOCTORS_TAG_CDDB                    : GB_NOT_FOUND,
    RP_PERC_NURSES_TAG_CDDB                     : GB_NOT_FOUND,
    RP_PERC_IMPROVED_WATER_SOURCE_TAG_CDDB      : GB_NOT_FOUND,
    RP_PERC_IMPROVED_SANI_TAG_CDDB              : GB_NOT_FOUND,
    RP_CAP_COST_PP_IMPROVED_WATER_TAG_CDDB      : GB_NOT_FOUND,
    RP_CAP_COST_PP_IMPROVED_SANI_TAG_CDDB       : GB_NOT_FOUND,
    RP_PERC_PEOPLE_PHASE_4_PLUS_TAG_CDDB        : GB_NOT_FOUND,
    RP_SEVERE_INSECURITY_TAG_CDDB               : GB_NOT_FOUND,
    RP_AREA_HARVESTED_TAG_CDDB                  : GB_NOT_FOUND,
    RP_STAPLE_PRODUCTION_TAG_CDDB               : GB_NOT_FOUND,
    RP_DOMINANT_CROP_TAG_CDDB                   : GB_NOT_FOUND,
    RP_AGRICULTURAL_LAND_TAG_CDDB               : GB_NOT_FOUND,
    RP_CROPLAND_HECTARES_TAG_CDDB               : GB_NOT_FOUND,
    RP_STAPLE_ANNUAL_CONSUMP_PER_CAP_TAG_CDDB   : GB_NOT_FOUND,
    RP_PROD_COST_PER_TON_DOMINANT_CROP_TAG_CDDB : GB_NOT_FOUND,
    RP_DAILY_COST_FOOD_AID_PER_PERSON_TAG_CDDB  : GB_NOT_FOUND,
    RP_PERC_POP_ELECTRICITY_TAG_CDDB            : GB_NOT_FOUND,
    RP_ELECTRICITY_PROD_PER_CAP_TAG_CDDB        : GB_NOT_FOUND,
    RP_COST_PER_KWH_TAG_CDDB                    : GB_NOT_FOUND,
    RP_LCOE_0_PER_PERSON_PER_DAY_TAG_CDDB       : GB_NOT_FOUND,
    RP_CLEAN_COOKING_TAG_CDDB                   : GB_NOT_FOUND,
    RP_CLEAN_COOKING_CAP_COST_TAG_CDDB          : GB_NOT_FOUND,
    RP_COST_BUILD_URBAN_HOUSEHOLD_TAG_CDDB      : GB_NOT_FOUND,
    RP_UNEMPLOYMENT_TAG_CDDB                    : GB_NOT_FOUND,
    RP_GDP_PER_CAP_TAG_CDDB                     : GB_NOT_FOUND,
    RP_LABOR_MALES_TAG_CDDB                     : GB_NOT_FOUND,
    RP_LABOR_FEMALES_TAG_CDDB                   : GB_NOT_FOUND,
    RP_LABOR_BOTH_TAG_CDDB                      : GB_NOT_FOUND,
    RP_GDP_BOOST_PERC_CHANGE_CDR_TAG_CDDB       : GB_NOT_FOUND,
    RP_YOUTH_NEED_ALL_TAG_CDDB                  : GB_NOT_FOUND,
    RP_YOUTH_NEED_MALE_TAG_CDDB                 : GB_NOT_FOUND,
    RP_YOUTH_NEED_FEMALE_TAG_CDDB               : GB_NOT_FOUND,
    RP_1_DEGREE_GDP_TAG_CDDB                    : GB_NOT_FOUND,
    RP_1_DEGREE_STAPLE_TAG_CDDB                 : GB_NOT_FOUND,
    RP_2_DEGREE_STAPLE_TAG_CDDB                 : GB_NOT_FOUND,
    RP_3_DEGREE_STAPLE_TAG_CDDB                 : GB_NOT_FOUND,
    RP_1_DEGREE_ON_ENERGY_TAG_CDDB              : GB_NOT_FOUND,
}

#######################################################################################################
#                                                                                                     #
#                                       Contraceptive Use DBs (CUDB)                                  #
#                                                                                                     #
#######################################################################################################

RP_MEDIAN_DB      = 1
RP_ACCELERATED_DB = 2

RP_ISO_NUMERIC_COUNTRY_CODE_DB_TAG_CUDB        = '<ISO Numeric Country Code>'
RP_ISO_ALPHA_3_COUNTRY_CODE_DB_TAG_CUDB        = '<ISO Alpha-3 Country Code>'
RP_COUNTRY_NAME_DB_TAG_CUDB                    = '<Country Name>'

RP_ISO_ALPHA_3_COUNTRY_CODE_KEY_CUDB    = 'ISO3AlphaCountryCode'
RP_COUNTRY_NAME_KEY_UDDB                = 'countryName'
RP_CONTRACEPTIVE_USE_KEY_CUDB           = 'contraceptiveUse'

RP_FIRST_YEAR_CUDB = 2020
RP_FINAL_YEAR_CUDB = 2075

#######################################################################################################
#                                                                                                     #
#                                       SSP DBs (SSPDB)                                  #
#                                                                                                     #
#######################################################################################################

RP_SSP1_DB = 1
RP_SSP2_DB = 2
RP_SSP3_DB = 3
RP_SSP5_DB = 4

RP_ISO_NUMERIC_COUNTRY_CODE_DB_TAG_SSPDB  = '<ISO Numeric Country Code>'
RP_ISO_ALPHA_3_COUNTRY_CODE_DB_TAG_SSPDB  = '<ISO Alpha-3 Country Code>'
RP_COUNTRY_NAME_DB_TAG_SSPDB              = '<Country Name>'

RP_ISO_ALPHA_3_COUNTRY_CODE_KEY_SSPDB     = 'ISO3AlphaCountryCode'
RP_COUNTRY_NAME_KEY_SSPDB                 = 'countryName'
RP_BASELINE_AVG_TEMP_KEY_SSPDB            = 'baselineAvgTemp'

RP_FIRST_YEAR_SSPDB = 2020
RP_FINAL_YEAR_SSPDB = 2075

#######################################################################################################
#                                                                                                     #
#                                       Urban DB (UDB)                                                #
#                                                                                                     #
#######################################################################################################

RP_ISO_NUMERIC_COUNTRY_CODE_DB_TAG_UDB  = '<ISO Numeric Country Code>'
RP_ISO_ALPHA_3_COUNTRY_CODE_DB_TAG_UDB  = '<ISO Alpha-3 Country Code>'
RP_COUNTRY_NAME_DB_TAG_UDB              = '<Country Name>'

RP_ISO_ALPHA_3_COUNTRY_CODE_KEY_UDB     = 'ISO3AlphaCountryCode'
RP_COUNTRY_NAME_KEY_UDB                 = 'countryName'
RP_PERC_POP_LIVING_URBAN_AREAS_KEY_UDB  = 'percPopLivingInUrbanAreas'

RP_FIRST_YEAR_UDB = 2020
RP_FINAL_YEAR_UDB = 2075