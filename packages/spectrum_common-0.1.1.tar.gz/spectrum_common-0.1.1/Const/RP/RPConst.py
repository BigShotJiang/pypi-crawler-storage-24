from SpectrumCommon.Const.GB import *

# Database latest versions

RP_COUNTRY_DEFAULTS_DB_CURR_VERSION          = 'V4'
RP_COUNTRY_DEFAULTS_SOURCES_DB_CURR_VERSION  = 'V1'
RP_CONTRACEPTIVE_USE_MED_DB_CURR_VERSION     = 'V1'
RP_CONTRACEPTIVE_USE_ACC_DB_CURR_VERSION     = 'V1'
RP_SSP1_TEMPS_DB_CURR_VERSION                = 'V1'
RP_SSP2_TEMPS_DB_CURR_VERSION                = 'V1'
RP_SSP3_TEMPS_DB_CURR_VERSION                = 'V1'
RP_SSP5_TEMPS_DB_CURR_VERSION                = 'V1'
RP_URBAN_DB_CURR_VERSION                     = 'V1'

# Database names (also the names of the sheets in RPModData.xlsx)

RP_COUNTRY_DEFAULTS_DB_NAME         = 'CountryDefaultsDB'
RP_COUNTRY_DEFAULTS_SOURCES_DB_NAME = 'CountryDefaultsSourcesDB'
RP_CONTRACEPTIVE_USE_MED_DB_NAME    = 'ContraceptiveUseMedDB'
RP_CONTRACEPTIVE_USE_ACC_DB_NAME    = 'ContraceptiveUseAccDB'
RP_SSP1_TEMPS_DB_NAME               = 'SSP1TempsDB'
RP_SSP2_TEMPS_DB_NAME               = 'SSP2TempsDB'
RP_SSP3_TEMPS_DB_NAME               = 'SSP3TempsDB'
RP_SSP5_TEMPS_DB_NAME               = 'SSP5TempsDB'
RP_URBAN_DB_NAME                    = 'UrbanDB'

# Database directories for data by country. Files in these folders are named using the 3 letter iso country codes instead of the database names above.

RP_COUNTRY_DEFAULTS_DB_DIR          = r'CountryDefaults\countries'
RP_COUNTRY_DEFAULTS_SOURCES_DB_DIR  = r'CountryDefaultsSources\countries'
RP_CONTRACEPTIVE_USE_MED_DB_DIR     = r'ContraceptiveUseMed\countries'
RP_CONTRACEPTIVE_USE_ACC_DB_DIR     = r'ContraceptiveUseAcc\countries'
RP_SSP1_TEMPS_DB_DIR                = r'SSP1Temps\countries'
RP_SSP2_TEMPS_DB_DIR                = r'SSP2Temps\countries'
RP_SSP3_TEMPS_DB_DIR                = r'SSP3Temps\countries'
RP_SSP5_TEMPS_DB_DIR                = r'SSP5Temps\countries'
RP_URBAN_DB_DIR                     = r'Urban\countries'

# Resulting change (RC) shapes

RP_RC_BY_SEX_YEAR = 1
RP_RC_BY_YEAR = 2
RP_RC_NOT_APPLICABLE = 3

# #####################################################################################################
#                                                                                                     #
#                                       Sectors                                                       #
#                                                                                                     #
#######################################################################################################

RP_EDUCATION_SECTOR_CURR_ID      = 1
RP_HEALTH_SECTOR_CURR_ID         = 2
RP_WASH_SECTOR_CURR_ID           = 3
RP_FOOD_SECURITY_SECTOR_CURR_ID  = 4
RP_URBANIZATION_SECTOR_CURR_ID   = 5
RP_ENERGY_SECTOR_CURR_ID         = 6
RP_ECONOMIC_SECTOR_CURR_ID       = 7
RP_BUILD_YOUR_OWN_SECTOR_CURR_ID = 8
RP_NUM_DEFAULT_SECTORS           = RP_BUILD_YOUR_OWN_SECTOR_CURR_ID

RP_EDUCATION_SECTOR_MST_ID      = 1
RP_HEALTH_SECTOR_MST_ID         = 2
RP_WASH_SECTOR_MST_ID           = 3
RP_FOOD_SECURITY_SECTOR_MST_ID  = 4
RP_URBANIZATION_SECTOR_MST_ID   = 5
RP_ENERGY_SECTOR_MST_ID         = 6
RP_ECONOMIC_SECTOR_MST_ID       = 7
RP_BUILD_YOUR_OWN_SECTOR_MST_ID = 8

RP_SECTOR_MST_IDS = [
    RP_EDUCATION_SECTOR_MST_ID,
    RP_HEALTH_SECTOR_MST_ID,
    RP_WASH_SECTOR_MST_ID,
    RP_FOOD_SECURITY_SECTOR_MST_ID,
    RP_URBANIZATION_SECTOR_MST_ID,
    RP_ENERGY_SECTOR_MST_ID,
    RP_ECONOMIC_SECTOR_MST_ID,
    RP_BUILD_YOUR_OWN_SECTOR_MST_ID,
]

RP_SECTOR_CURR_ID_MAP = {
    RP_EDUCATION_SECTOR_MST_ID      : RP_EDUCATION_SECTOR_CURR_ID,
    RP_HEALTH_SECTOR_MST_ID         : RP_HEALTH_SECTOR_CURR_ID,
    RP_WASH_SECTOR_MST_ID           : RP_WASH_SECTOR_CURR_ID,
    RP_FOOD_SECURITY_SECTOR_MST_ID  : RP_FOOD_SECURITY_SECTOR_CURR_ID,
    RP_URBANIZATION_SECTOR_MST_ID   : RP_URBANIZATION_SECTOR_CURR_ID,
    RP_ENERGY_SECTOR_MST_ID         : RP_ENERGY_SECTOR_CURR_ID,
    RP_ECONOMIC_SECTOR_MST_ID       : RP_ECONOMIC_SECTOR_CURR_ID,
    RP_BUILD_YOUR_OWN_SECTOR_MST_ID : RP_BUILD_YOUR_OWN_SECTOR_CURR_ID,
}

# #####################################################################################################
#                                                                                                     #
#                                       Goals                                                         #
#                                                                                                     #
#######################################################################################################

#######################################   Education Sector   ##########################################

RP_EDU_1_INCR_PRIM_ENROLL_GOAL_MST_ID           = 1 # 1. Increase primary enrollment
RP_EDU_2_INCR_SEC_ENROLL_GOAL_MST_ID            = 2 # 2. Increase secondary enrollment 
RP_EDU_3_IMPR_STUDENT_TEACHER_RATIO_GOAL_MST_ID = 3 # 3. Improve the student-to-teacher ratio (primary)

RP_EDU_GOAL_MST_IDS = [
    RP_EDU_1_INCR_PRIM_ENROLL_GOAL_MST_ID,
    RP_EDU_2_INCR_SEC_ENROLL_GOAL_MST_ID,
    RP_EDU_3_IMPR_STUDENT_TEACHER_RATIO_GOAL_MST_ID,
]

# Tells us the shape of the resulting change field for each goal.

RP_EDU_GOAL_RC_FORMAT = {
    RP_EDU_1_INCR_PRIM_ENROLL_GOAL_MST_ID           : RP_RC_BY_SEX_YEAR,
    RP_EDU_2_INCR_SEC_ENROLL_GOAL_MST_ID            : RP_RC_BY_SEX_YEAR,
    RP_EDU_3_IMPR_STUDENT_TEACHER_RATIO_GOAL_MST_ID : RP_RC_BY_YEAR,
}

#########################################   Health Sector   ##########################################

RP_HLTH_1_INCR_PERC_BIRTHS_SKILLED_GOAL_MST_ID        = 1 # 1. Increase percentage of births attended by skilled personnel
RP_HLTH_2_INCR_PERC_PREG_WOMEN_REC_VISITS_GOAL_MST_ID = 2 # 2. Increase percentage of pregnant women receiving 4+ antenatal care visits
RP_HLTH_3_INCR_ACCESS_HEALTH_PROF_GOAL_MST_ID         = 3 # 3. Increase access to health professionals

RP_HLTH_GOAL_MST_IDS = [
    RP_HLTH_1_INCR_PERC_BIRTHS_SKILLED_GOAL_MST_ID,
    RP_HLTH_2_INCR_PERC_PREG_WOMEN_REC_VISITS_GOAL_MST_ID,
    RP_HLTH_3_INCR_ACCESS_HEALTH_PROF_GOAL_MST_ID,
]

# Tells us the shape of the resulting change field for each goal.

RP_HLTH_GOAL_RC_FORMAT = {
    RP_HLTH_1_INCR_PERC_BIRTHS_SKILLED_GOAL_MST_ID        : RP_RC_BY_YEAR,
    RP_HLTH_2_INCR_PERC_PREG_WOMEN_REC_VISITS_GOAL_MST_ID : RP_RC_BY_YEAR,
    RP_HLTH_3_INCR_ACCESS_HEALTH_PROF_GOAL_MST_ID         : RP_RC_BY_YEAR,
}

#########################################   WASH   ##########################################

RP_WASH_1_INCR_ACCESS_IMPR_WATER_SRC_GOAL_MST_ID = 1 # 1. Increase access to an improved water source
RP_WASH_2_INCR_ACCESS_IMPR_SANI_GOAL_MST_ID      = 2 # 2. Increase access to improved sanitation facility

RP_WASH_GOAL_MST_IDS = [
    RP_WASH_1_INCR_ACCESS_IMPR_WATER_SRC_GOAL_MST_ID,
    RP_WASH_2_INCR_ACCESS_IMPR_SANI_GOAL_MST_ID,
]

# Tells us the shape of the resulting change field for each goal.

RP_WASH_GOAL_RC_FORMAT = {
    RP_WASH_1_INCR_ACCESS_IMPR_WATER_SRC_GOAL_MST_ID  : RP_RC_BY_YEAR,
    RP_WASH_2_INCR_ACCESS_IMPR_SANI_GOAL_MST_ID       : RP_RC_BY_YEAR,
}

#########################################   Food security   ##########################################

RP_FOOD_1_INCR_PROP_DOM_PROD_STAPLE_CROP_GOAL_MST_ID = 1 # 1. Increase proportion of domestic production of main staple crop
RP_FOOD_2_REDUCE_FOOD_INSEC_GOAL_MST_ID              = 2 # 2. Reduce severe food insecurity

RP_FOOD_GOAL_MST_IDS = [
    RP_FOOD_1_INCR_PROP_DOM_PROD_STAPLE_CROP_GOAL_MST_ID,
    RP_FOOD_2_REDUCE_FOOD_INSEC_GOAL_MST_ID,
]

# Tells us the shape of the resulting change field for each goal.

RP_FOOD_GOAL_RC_FORMAT = {
    RP_FOOD_1_INCR_PROP_DOM_PROD_STAPLE_CROP_GOAL_MST_ID : RP_RC_BY_YEAR,
    RP_FOOD_2_REDUCE_FOOD_INSEC_GOAL_MST_ID              : RP_RC_BY_YEAR,
}

#########################################   Urbanization   ##########################################

RP_URB_1_SLOW_INCR_NUM_PEOPLE_GOAL_MST_ID   = 1 # 1. Slow increase in the number of people living in urban areas
RP_URB_2_INCR_ACCESS_URBAN_HOUS_GOAL_MST_ID = 2 # 2. Increase access to urban housing: reduction of living in informal settlements

RP_URB_GOAL_MST_IDS = [
    RP_URB_1_SLOW_INCR_NUM_PEOPLE_GOAL_MST_ID,
    RP_URB_2_INCR_ACCESS_URBAN_HOUS_GOAL_MST_ID,
]

# Tells us the shape of the resulting change field for each goal.

RP_URB_GOAL_RC_FORMAT = {
    RP_URB_1_SLOW_INCR_NUM_PEOPLE_GOAL_MST_ID    : RP_RC_NOT_APPLICABLE,
    RP_URB_2_INCR_ACCESS_URBAN_HOUS_GOAL_MST_ID  : RP_RC_BY_YEAR,
}

#########################################   Energy   ##########################################

RP_ENERGY_1_INCR_POP_ACC_ELEC_GOAL_MST_ID          = 1 # 1. Increase population access to electricity
RP_ENERGY_2_INCR_PROD_ELEC_SUFF_LEVELS_GOAL_MST_ID = 2 # 2. Increase production of electricity to sufficient levels
RP_ENERGY_3_INCR_HOUS_ACCESS_CLEAN_GOAL_MST_ID     = 3 # 3. Increase household access to clean cooking fuel and technologies

RP_ENERGY_GOAL_MST_IDS = [
    RP_ENERGY_1_INCR_POP_ACC_ELEC_GOAL_MST_ID,
    RP_ENERGY_2_INCR_PROD_ELEC_SUFF_LEVELS_GOAL_MST_ID,
    RP_ENERGY_3_INCR_HOUS_ACCESS_CLEAN_GOAL_MST_ID,
]

# Tells us the shape of the resulting change field for each goal.

RP_ENERGY_GOAL_RC_FORMAT = {
    RP_ENERGY_1_INCR_POP_ACC_ELEC_GOAL_MST_ID           : RP_RC_BY_YEAR,
    RP_ENERGY_2_INCR_PROD_ELEC_SUFF_LEVELS_GOAL_MST_ID  : RP_RC_BY_YEAR,
    RP_ENERGY_3_INCR_HOUS_ACCESS_CLEAN_GOAL_MST_ID      : RP_RC_BY_YEAR,
}

#########################################   Economic   ##########################################

RP_ECON_1_REDUCE_AGE_DEPEND_RATIO_GOAL_MST_ID = 1 # 1. Reduce age dependency ratio 
RP_ECON_2_INCR_GDP_PER_CAPITA_GOAL_MST_ID     = 2 # 2. Increase GDP per capita
RP_ECON_3_DECR_UNEMPLOYMENT_GOAL_MST_ID       = 3 # 3. Decrease unemployment 
RP_ECON_4_REDUCE_YOUTH_NEET_GOAL_MST_ID       = 4 # 4. Reduce proportion of youth not in education, employment, or training (NEET)

RP_ECON_GOAL_MST_IDS = [
    RP_ECON_1_REDUCE_AGE_DEPEND_RATIO_GOAL_MST_ID,
    RP_ECON_2_INCR_GDP_PER_CAPITA_GOAL_MST_ID,
    RP_ECON_3_DECR_UNEMPLOYMENT_GOAL_MST_ID,
    RP_ECON_4_REDUCE_YOUTH_NEET_GOAL_MST_ID
]

# Tells us the shape of the resulting change field for each goal.

RP_ECON_GOAL_RC_FORMAT = {
    RP_ECON_1_REDUCE_AGE_DEPEND_RATIO_GOAL_MST_ID  : RP_RC_NOT_APPLICABLE,
    RP_ECON_2_INCR_GDP_PER_CAPITA_GOAL_MST_ID      : RP_RC_NOT_APPLICABLE,
    RP_ECON_3_DECR_UNEMPLOYMENT_GOAL_MST_ID        : RP_RC_BY_YEAR,
    RP_ECON_4_REDUCE_YOUTH_NEET_GOAL_MST_ID        : RP_RC_BY_SEX_YEAR
}

#########################################   Build Your Own   ##########################################

RP_BYO_1_BYO_GOAL_MST_ID = 1 # 1. Reduce age dependency ratio 

RP_BYO_GOAL_MST_IDS = [
    RP_BYO_1_BYO_GOAL_MST_ID,
]

# Tells us the shape of the resulting change field for each goal.

RP_BYO_GOAL_RC_FORMAT = {
    RP_BYO_1_BYO_GOAL_MST_ID : RP_RC_BY_YEAR,
}

###################################################################################################

RP_SECTOR_GOAL_RC_FORMATS = {
    RP_EDUCATION_SECTOR_MST_ID       : RP_EDU_GOAL_RC_FORMAT,
    RP_HEALTH_SECTOR_MST_ID          : RP_HLTH_GOAL_RC_FORMAT,
    RP_WASH_SECTOR_MST_ID            : RP_WASH_GOAL_RC_FORMAT,
    RP_FOOD_SECURITY_SECTOR_MST_ID   : RP_FOOD_GOAL_RC_FORMAT,
    RP_URBANIZATION_SECTOR_MST_ID    : RP_URB_GOAL_RC_FORMAT,
    RP_ENERGY_SECTOR_MST_ID          : RP_ENERGY_GOAL_RC_FORMAT,
    RP_ECONOMIC_SECTOR_MST_ID        : RP_ECON_GOAL_RC_FORMAT,
    RP_BUILD_YOUR_OWN_SECTOR_MST_ID  : RP_BYO_GOAL_RC_FORMAT,
}

# #####################################################################################################
#                                                                                                     #
#                                       Subgoals                                                      #
#                                                                                                     #
#######################################################################################################

#######################################   Education Sector   ##########################################

# Education Sector, 1. Increase primary enrollment Goal

RP_EDU_1_1_UNIVERSAL_PRIMARY_EDU_SUBG_MST_ID   = 1 # 1. Universal primary education
RP_EDU_1_2_ACHIEVE_GENDER_EQUALITY_SUBG_MST_ID = 2 # 2. Achieve gender equality
RP_EDU_1_3_USER_SPEC_PERC_CHILDREN_SUBG_MST_ID = 3 # 3. User-specified as percent of children

RP_EDU_1_SUBGOAL_MST_IDS = [
    RP_EDU_1_1_UNIVERSAL_PRIMARY_EDU_SUBG_MST_ID,
    RP_EDU_1_2_ACHIEVE_GENDER_EQUALITY_SUBG_MST_ID,
    RP_EDU_1_3_USER_SPEC_PERC_CHILDREN_SUBG_MST_ID, 
]

# Education Sector, 2. Increase secondary enrollment Goal

RP_EDU_2_1_UNIVERSAL_PRIMARY_EDU_SUBG_MST_ID   = 1 # 1. Universal primary education
RP_EDU_2_2_ACHIEVE_GENDER_EQUALITY_SUBG_MST_ID = 2 # 2. Achieve gender equality
RP_EDU_2_3_USER_SPEC_PERC_CHILDREN_SUBG_MST_ID = 3 # 3. User-specified as percent of children

RP_EDU_2_SUBGOAL_MST_IDS = [
    RP_EDU_2_1_UNIVERSAL_PRIMARY_EDU_SUBG_MST_ID,
    RP_EDU_2_2_ACHIEVE_GENDER_EQUALITY_SUBG_MST_ID,
    RP_EDU_2_3_USER_SPEC_PERC_CHILDREN_SUBG_MST_ID, 
]

# Education Sector, 3. Improve the student-to-teacher ratio  Goal

RP_EDU_3_1_REC_RATIO_SUBG_MST_ID       = 1 # 1. Recommended ratio (25:1)
RP_EDU_3_2_USER_SPEC_RATIO_SUBG_MST_ID = 2 # 2. User specifies ratio

RP_EDU_3_SUBGOAL_MST_IDS = [
    RP_EDU_3_1_REC_RATIO_SUBG_MST_ID,
    RP_EDU_3_2_USER_SPEC_RATIO_SUBG_MST_ID,
]

RP_EDU_SECTOR_DEFAULT_SUBGOAL_MST_IDS = {
    RP_EDU_1_INCR_PRIM_ENROLL_GOAL_MST_ID           : RP_EDU_1_1_UNIVERSAL_PRIMARY_EDU_SUBG_MST_ID,
    RP_EDU_2_INCR_SEC_ENROLL_GOAL_MST_ID            : RP_EDU_2_1_UNIVERSAL_PRIMARY_EDU_SUBG_MST_ID,
    RP_EDU_3_IMPR_STUDENT_TEACHER_RATIO_GOAL_MST_ID : RP_EDU_3_1_REC_RATIO_SUBG_MST_ID,
}

#########################################   Health Sector   ##########################################

# Health Sector, 1. Increase percentage of births attended by skilled personnel Goal

RP_HLTH_1_1_ALL_SUBG_MST_ID                    = 1 # 1. All
RP_HLTH_1_2_X_PERC_BASED_Y_TARGETS_SUBG_MST_ID = 2 # 2. X percent based on Y targets
RP_HLTH_1_3_USER_SPEC_PERC_BIRTHS_SUBG_MST_ID  = 3 # 3. User-specified as percent of children

RP_HLTH_1_SUBGOAL_MST_IDS = [
    RP_HLTH_1_1_ALL_SUBG_MST_ID,
    RP_HLTH_1_2_X_PERC_BASED_Y_TARGETS_SUBG_MST_ID,
    RP_HLTH_1_3_USER_SPEC_PERC_BIRTHS_SUBG_MST_ID, 
]

# Health Sector, 2. Increase percentage of pregnant women receiving 4+ antenatal care visits Goal

RP_HLTH_2_1_ALL_SUBG_MST_ID                        = 1 # 1. All
RP_HLTH_2_2_X_PERC_BASED_Y_TARGETS_SUBG_MST_ID     = 2 # 2. X percent based on Y targets
RP_HLTH_2_3_USER_SPEC_PERC_PREGNANCIES_SUBG_MST_ID = 3 # 3. User-specified as percent of pregnancies

RP_HLTH_2_SUBGOAL_MST_IDS = [
    RP_HLTH_2_1_ALL_SUBG_MST_ID,
    RP_HLTH_2_2_X_PERC_BASED_Y_TARGETS_SUBG_MST_ID,
    RP_HLTH_2_3_USER_SPEC_PERC_PREGNANCIES_SUBG_MST_ID, 
]

# Health Sector, 3. Increase access to health professionals Goal

RP_HLTH_3_1_WHO_REC_SUBG_MST_ID       = 1 # 1. WHO recommendation of 2.5 per 1,000
RP_HLTH_3_2_USER_SPEC_NUM_SUBG_MST_ID = 2 # 2. User-specified as # per 1,000

RP_HLTH_3_SUBGOAL_MST_IDS = [
    RP_HLTH_3_1_WHO_REC_SUBG_MST_ID,
    RP_HLTH_3_2_USER_SPEC_NUM_SUBG_MST_ID,
]

RP_HLTH_SECTOR_DEFAULT_SUBGOAL_MST_IDS = {
    RP_HLTH_1_INCR_PERC_BIRTHS_SKILLED_GOAL_MST_ID        : RP_HLTH_1_1_ALL_SUBG_MST_ID,
    RP_HLTH_2_INCR_PERC_PREG_WOMEN_REC_VISITS_GOAL_MST_ID : RP_HLTH_2_1_ALL_SUBG_MST_ID,
    RP_HLTH_3_INCR_ACCESS_HEALTH_PROF_GOAL_MST_ID         : RP_HLTH_3_1_WHO_REC_SUBG_MST_ID,
}

#########################################   WASH   ##########################################

RP_WASH_1_1_UNIVERSAL_ACCESS_SUBG_MST_ID  = 1 # 1. Universal access
RP_WASH_1_2_USER_SPEC_PERC_HH_SUBG_MST_ID = 2 # 2. User-specified as % of households

RP_WASH_1_SUBGOAL_MST_IDS = [
    RP_WASH_1_1_UNIVERSAL_ACCESS_SUBG_MST_ID,
    RP_WASH_1_2_USER_SPEC_PERC_HH_SUBG_MST_ID,
]

RP_WASH_2_1_UNIVERSAL_ACCESS_SUBG_MST_ID  = 1 # 1. Universal access
RP_WASH_2_2_USER_SPEC_PERC_HH_SUBG_MST_ID = 2 # 2. User-specified as % of households

RP_WASH_2_SUBGOAL_MST_IDS = [
    RP_WASH_2_1_UNIVERSAL_ACCESS_SUBG_MST_ID,
    RP_WASH_2_2_USER_SPEC_PERC_HH_SUBG_MST_ID,
]

RP_WASH_SECTOR_DEFAULT_SUBGOAL_MST_IDS = {
    RP_WASH_1_INCR_ACCESS_IMPR_WATER_SRC_GOAL_MST_ID  : RP_WASH_1_1_UNIVERSAL_ACCESS_SUBG_MST_ID,
    RP_WASH_2_INCR_ACCESS_IMPR_SANI_GOAL_MST_ID       : RP_WASH_2_1_UNIVERSAL_ACCESS_SUBG_MST_ID,
}

#########################################   Food security   ##########################################

RP_FOOD_1_1_ALL_DOMEST_PROD_SUBG_MST_ID          = 1 # 1. All domestically produced
RP_FOOD_1_2_USER_SPEC_PERC_DOM_GROWN_SUBG_MST_ID = 2 # 2. User-specified % domestically grown

RP_FOOD_1_SUBGOAL_MST_IDS = [
    RP_FOOD_1_1_ALL_DOMEST_PROD_SUBG_MST_ID,
    RP_FOOD_1_2_USER_SPEC_PERC_DOM_GROWN_SUBG_MST_ID,
]

RP_FOOD_2_1_ELIM_SEV_FOOD_INSECURITY_SUBG_MST_ID     = 1 # 1. Eliminate severe food insecurity
RP_FOOD_2_2_HALVE_SEV_FOOD_INSECURITY_SUBG_MST_ID    = 2 # 2. Halve severe food insecurity
RP_FOOD_2_3_USER_SPEC_PERC_FOOD_INSECURE_SUBG_MST_ID = 3 # 3. User-specified as % food insecure

RP_FOOD_2_SUBGOAL_MST_IDS = [
    RP_FOOD_2_1_ELIM_SEV_FOOD_INSECURITY_SUBG_MST_ID,
    RP_FOOD_2_2_HALVE_SEV_FOOD_INSECURITY_SUBG_MST_ID,
    RP_FOOD_2_3_USER_SPEC_PERC_FOOD_INSECURE_SUBG_MST_ID,
]

RP_FOOD_SECTOR_DEFAULT_SUBGOAL_MST_IDS = {
    RP_FOOD_1_INCR_PROP_DOM_PROD_STAPLE_CROP_GOAL_MST_ID : RP_FOOD_1_1_ALL_DOMEST_PROD_SUBG_MST_ID,
    RP_FOOD_2_REDUCE_FOOD_INSEC_GOAL_MST_ID              : RP_FOOD_2_1_ELIM_SEV_FOOD_INSECURITY_SUBG_MST_ID,
}

#########################################   Urbanization   ##########################################

# Nothing for Goal 1
RP_URB_1_SUBGOAL_MST_IDS = []

RP_URB_2_1_NO_POP_INFORMAL_SETTLEMENTS_SUBG_MST_ID    = 1 # 1. No population living in informal settlements
RP_URB_2_2_HALVE_POP_INFORMAL_SETTLEMENTS_SUBG_MST_ID = 2 # 2. Halve % of population living in informal settlements
RP_URB_2_3_USER_SPEC_PERC_URBAN_SUBG_MST_ID           = 3 # 3. User-specified % of urban in informal settlements

RP_URB_2_SUBGOAL_MST_IDS = [
    RP_URB_2_1_NO_POP_INFORMAL_SETTLEMENTS_SUBG_MST_ID,
    RP_URB_2_2_HALVE_POP_INFORMAL_SETTLEMENTS_SUBG_MST_ID,
    RP_URB_2_3_USER_SPEC_PERC_URBAN_SUBG_MST_ID,
]

RP_URB_SECTOR_DEFAULT_SUBGOAL_MST_IDS = {
    RP_URB_2_INCR_ACCESS_URBAN_HOUS_GOAL_MST_ID : RP_URB_2_1_NO_POP_INFORMAL_SETTLEMENTS_SUBG_MST_ID,
}

#########################################   Energy   ##########################################

RP_ENERGY_1_1_UNIV_ACCESS_SUBG_MST_ID          = 1 # 1. Universal access (SDG 2030 goal)
RP_ENERGY_1_2_USER_SPEC_PERC_POP_SUBG_MST_ID   = 2 # 2. User-specified % of population

RP_ENERGY_1_SUBGOAL_MST_IDS = [
    RP_ENERGY_1_1_UNIV_ACCESS_SUBG_MST_ID,
    RP_ENERGY_1_2_USER_SPEC_PERC_POP_SUBG_MST_ID,
]

RP_ENERGY_2_1_1000_KWH_PER_PERSON_YEAR_MST_ID  = 1 # 1. 1000 kilowatt hour per person, per year
RP_ENERGY_2_2_USER_SPEC_PERC_POP_SUBG_MST_ID   = 2 # 2. User-specified % of population

RP_ENERGY_2_SUBGOAL_MST_IDS = [
    RP_ENERGY_2_1_1000_KWH_PER_PERSON_YEAR_MST_ID,
    RP_ENERGY_2_2_USER_SPEC_PERC_POP_SUBG_MST_ID,
]

RP_ENERGY_3_1_UNIV_ACCESS_SUBG_MST_ID          = 1 # 1. Universal access
RP_ENERGY_3_2_USER_SPEC_PERC_POP_SUBG_MST_ID   = 2 # 2. User-specified % of population

RP_ENERGY_3_SUBGOAL_MST_IDS = [
    RP_ENERGY_3_1_UNIV_ACCESS_SUBG_MST_ID,
    RP_ENERGY_3_2_USER_SPEC_PERC_POP_SUBG_MST_ID,
]

RP_ENERGY_SECTOR_DEFAULT_SUBGOAL_MST_IDS = {
    RP_ENERGY_1_INCR_POP_ACC_ELEC_GOAL_MST_ID           : RP_ENERGY_1_1_UNIV_ACCESS_SUBG_MST_ID,
    RP_ENERGY_2_INCR_PROD_ELEC_SUFF_LEVELS_GOAL_MST_ID  : RP_ENERGY_2_1_1000_KWH_PER_PERSON_YEAR_MST_ID,
    RP_ENERGY_3_INCR_HOUS_ACCESS_CLEAN_GOAL_MST_ID      : RP_ENERGY_3_1_UNIV_ACCESS_SUBG_MST_ID,
}

#########################################   Economic   ##########################################

# Nothing for Goals 1, 2

RP_ECON_1_SUBGOAL_MST_IDS = []
RP_ECON_2_SUBGOAL_MST_IDS = []

RP_ECON_3_1_5_PERC_UNEMPLOYMENT_SUBG_MST_ID = 1 # 1. 5% unemployment
RP_ECON_3_2_USER_SPEC_RATE_SUBG_MST_ID      = 2 # 2. User-specified rate

RP_ECON_3_SUBGOAL_MST_IDS = [
    RP_ECON_3_1_5_PERC_UNEMPLOYMENT_SUBG_MST_ID,
    RP_ECON_3_2_USER_SPEC_RATE_SUBG_MST_ID,
]

RP_ECON_4_1_ELIM_NEET_SUBG_MST_ID               = 1 # 3. Eliminate NEET
RP_ECON_4_2_ACHIEVE_GENDER_EQUALITY_SUBG_MST_ID = 2 # 1. Achieve gender equity
RP_ECON_4_3_USER_SPEC_PERC_SUBG_MST_ID          = 3 # 4. User-specified %

RP_ECON_4_SUBGOAL_MST_IDS = [
    RP_ECON_4_1_ELIM_NEET_SUBG_MST_ID,
    RP_ECON_4_2_ACHIEVE_GENDER_EQUALITY_SUBG_MST_ID,
    RP_ECON_4_3_USER_SPEC_PERC_SUBG_MST_ID,
]

RP_ECON_SECTOR_DEFAULT_SUBGOAL_MST_IDS = {
    RP_ECON_3_DECR_UNEMPLOYMENT_GOAL_MST_ID  : RP_ECON_3_1_5_PERC_UNEMPLOYMENT_SUBG_MST_ID,
    RP_ECON_4_REDUCE_YOUTH_NEET_GOAL_MST_ID  : RP_ECON_4_2_ACHIEVE_GENDER_EQUALITY_SUBG_MST_ID,
}

#########################################   Build Your Own   ##########################################

RP_BYO_1_SUBGOAL_MST_IDS = []

# BYO has no default subgoals for its one goal
RP_BYO_SECTOR_DEFAULT_SUBGOAL_MST_IDS = {
}

#######################################################################################################

RP_SECTOR_GOALS = {
    RP_EDUCATION_SECTOR_MST_ID      : RP_EDU_GOAL_MST_IDS,
    RP_HEALTH_SECTOR_MST_ID         : RP_HLTH_GOAL_MST_IDS,
    RP_WASH_SECTOR_MST_ID           : RP_WASH_GOAL_MST_IDS,
    RP_FOOD_SECURITY_SECTOR_MST_ID  : RP_FOOD_GOAL_MST_IDS,
    RP_URBANIZATION_SECTOR_MST_ID   : RP_URB_GOAL_MST_IDS,
    RP_ENERGY_SECTOR_MST_ID         : RP_ENERGY_GOAL_MST_IDS,
    RP_ECONOMIC_SECTOR_MST_ID       : RP_ECON_GOAL_MST_IDS,
    RP_BUILD_YOUR_OWN_SECTOR_MST_ID : RP_BYO_GOAL_MST_IDS,
}

RP_SECTOR_DEFAULT_SUBGOALS = {
    RP_EDUCATION_SECTOR_MST_ID      : RP_EDU_SECTOR_DEFAULT_SUBGOAL_MST_IDS,
    RP_HEALTH_SECTOR_MST_ID         : RP_HLTH_SECTOR_DEFAULT_SUBGOAL_MST_IDS,
    RP_WASH_SECTOR_MST_ID           : RP_WASH_SECTOR_DEFAULT_SUBGOAL_MST_IDS,
    RP_FOOD_SECURITY_SECTOR_MST_ID  : RP_FOOD_SECTOR_DEFAULT_SUBGOAL_MST_IDS,
    RP_URBANIZATION_SECTOR_MST_ID   : RP_URB_SECTOR_DEFAULT_SUBGOAL_MST_IDS,
    RP_ENERGY_SECTOR_MST_ID         : RP_ENERGY_SECTOR_DEFAULT_SUBGOAL_MST_IDS,
    RP_ECONOMIC_SECTOR_MST_ID       : RP_ECON_SECTOR_DEFAULT_SUBGOAL_MST_IDS,
    RP_BUILD_YOUR_OWN_SECTOR_MST_ID : RP_BYO_SECTOR_DEFAULT_SUBGOAL_MST_IDS
}

RP_GOAL_SUBGOALS = {

    f"{RP_EDUCATION_SECTOR_MST_ID}_{RP_EDU_1_INCR_PRIM_ENROLL_GOAL_MST_ID}"                    : RP_EDU_1_SUBGOAL_MST_IDS, 
    f"{RP_EDUCATION_SECTOR_MST_ID}_{RP_EDU_2_INCR_SEC_ENROLL_GOAL_MST_ID}"                     : RP_EDU_2_SUBGOAL_MST_IDS,
    f"{RP_EDUCATION_SECTOR_MST_ID}_{RP_EDU_3_IMPR_STUDENT_TEACHER_RATIO_GOAL_MST_ID}"          : RP_EDU_3_SUBGOAL_MST_IDS,

    f"{RP_HEALTH_SECTOR_MST_ID}_{RP_HLTH_1_INCR_PERC_BIRTHS_SKILLED_GOAL_MST_ID}"              : RP_HLTH_1_SUBGOAL_MST_IDS,
    f"{RP_HEALTH_SECTOR_MST_ID}_{RP_HLTH_2_INCR_PERC_PREG_WOMEN_REC_VISITS_GOAL_MST_ID}"       : RP_HLTH_2_SUBGOAL_MST_IDS,
    f"{RP_HEALTH_SECTOR_MST_ID}_{RP_HLTH_3_INCR_ACCESS_HEALTH_PROF_GOAL_MST_ID}"               : RP_HLTH_3_SUBGOAL_MST_IDS,

    f"{RP_WASH_SECTOR_MST_ID}_{RP_WASH_1_INCR_ACCESS_IMPR_WATER_SRC_GOAL_MST_ID}"              : RP_WASH_1_SUBGOAL_MST_IDS, 
    f"{RP_WASH_SECTOR_MST_ID}_{RP_WASH_2_INCR_ACCESS_IMPR_SANI_GOAL_MST_ID}"                   : RP_WASH_2_SUBGOAL_MST_IDS, 

    f"{RP_FOOD_SECURITY_SECTOR_MST_ID}_{RP_FOOD_1_INCR_PROP_DOM_PROD_STAPLE_CROP_GOAL_MST_ID}" : RP_FOOD_1_SUBGOAL_MST_IDS, 
    f"{RP_FOOD_SECURITY_SECTOR_MST_ID}_{RP_FOOD_2_REDUCE_FOOD_INSEC_GOAL_MST_ID}"              : RP_FOOD_2_SUBGOAL_MST_IDS, 

    f"{RP_URBANIZATION_SECTOR_MST_ID}_{RP_URB_1_SLOW_INCR_NUM_PEOPLE_GOAL_MST_ID}"             : RP_URB_1_SUBGOAL_MST_IDS, 
    f"{RP_URBANIZATION_SECTOR_MST_ID}_{RP_URB_2_INCR_ACCESS_URBAN_HOUS_GOAL_MST_ID}"           : RP_URB_2_SUBGOAL_MST_IDS, 

    f"{RP_ENERGY_SECTOR_MST_ID}_{RP_ENERGY_1_INCR_POP_ACC_ELEC_GOAL_MST_ID}"                   : RP_ENERGY_1_SUBGOAL_MST_IDS, 
    f"{RP_ENERGY_SECTOR_MST_ID}_{RP_ENERGY_2_INCR_PROD_ELEC_SUFF_LEVELS_GOAL_MST_ID}"          : RP_ENERGY_2_SUBGOAL_MST_IDS, 
    f"{RP_ENERGY_SECTOR_MST_ID}_{RP_ENERGY_3_INCR_HOUS_ACCESS_CLEAN_GOAL_MST_ID}"              : RP_ENERGY_3_SUBGOAL_MST_IDS, 

    f"{RP_ECONOMIC_SECTOR_MST_ID}_{RP_ECON_1_REDUCE_AGE_DEPEND_RATIO_GOAL_MST_ID}"             : RP_ECON_1_SUBGOAL_MST_IDS, 
    f"{RP_ECONOMIC_SECTOR_MST_ID}_{RP_ECON_2_INCR_GDP_PER_CAPITA_GOAL_MST_ID}"                 : RP_ECON_2_SUBGOAL_MST_IDS, 
    f"{RP_ECONOMIC_SECTOR_MST_ID}_{RP_ECON_3_DECR_UNEMPLOYMENT_GOAL_MST_ID}"                   : RP_ECON_3_SUBGOAL_MST_IDS, 
    f"{RP_ECONOMIC_SECTOR_MST_ID}_{RP_ECON_4_REDUCE_YOUTH_NEET_GOAL_MST_ID}"                   : RP_ECON_4_SUBGOAL_MST_IDS, 

    # f"{RP_BUILD_YOUR_OWN_SECTOR_MST_ID}_{RP_BYO_1_BYO_GOAL_MST_ID}"                            : RP_BYO_1_SUBGOAL_MST_IDS, 
}

RP_GOAL_USER_SPEC_SUBGOALS = {

    f"{RP_EDUCATION_SECTOR_MST_ID}_{RP_EDU_1_INCR_PRIM_ENROLL_GOAL_MST_ID}"                    : RP_EDU_1_3_USER_SPEC_PERC_CHILDREN_SUBG_MST_ID, 
    f"{RP_EDUCATION_SECTOR_MST_ID}_{RP_EDU_2_INCR_SEC_ENROLL_GOAL_MST_ID}"                     : RP_EDU_2_3_USER_SPEC_PERC_CHILDREN_SUBG_MST_ID,
    f"{RP_EDUCATION_SECTOR_MST_ID}_{RP_EDU_3_IMPR_STUDENT_TEACHER_RATIO_GOAL_MST_ID}"          : RP_EDU_3_2_USER_SPEC_RATIO_SUBG_MST_ID,

    f"{RP_HEALTH_SECTOR_MST_ID}_{RP_HLTH_1_INCR_PERC_BIRTHS_SKILLED_GOAL_MST_ID}"              : RP_HLTH_1_3_USER_SPEC_PERC_BIRTHS_SUBG_MST_ID,
    f"{RP_HEALTH_SECTOR_MST_ID}_{RP_HLTH_2_INCR_PERC_PREG_WOMEN_REC_VISITS_GOAL_MST_ID}"       : RP_HLTH_2_3_USER_SPEC_PERC_PREGNANCIES_SUBG_MST_ID,
    f"{RP_HEALTH_SECTOR_MST_ID}_{RP_HLTH_3_INCR_ACCESS_HEALTH_PROF_GOAL_MST_ID}"               : RP_HLTH_3_2_USER_SPEC_NUM_SUBG_MST_ID,

    f"{RP_WASH_SECTOR_MST_ID}_{RP_WASH_1_INCR_ACCESS_IMPR_WATER_SRC_GOAL_MST_ID}"              : RP_WASH_1_2_USER_SPEC_PERC_HH_SUBG_MST_ID, 
    f"{RP_WASH_SECTOR_MST_ID}_{RP_WASH_2_INCR_ACCESS_IMPR_SANI_GOAL_MST_ID}"                   : RP_WASH_2_2_USER_SPEC_PERC_HH_SUBG_MST_ID, 

    f"{RP_FOOD_SECURITY_SECTOR_MST_ID}_{RP_FOOD_1_INCR_PROP_DOM_PROD_STAPLE_CROP_GOAL_MST_ID}" : RP_FOOD_1_2_USER_SPEC_PERC_DOM_GROWN_SUBG_MST_ID, 
    f"{RP_FOOD_SECURITY_SECTOR_MST_ID}_{RP_FOOD_2_REDUCE_FOOD_INSEC_GOAL_MST_ID}"              : RP_FOOD_2_3_USER_SPEC_PERC_FOOD_INSECURE_SUBG_MST_ID, 

    # NA f"{RP_URBANIZATION_SECTOR_MST_ID}_{RP_URB_1_SLOW_INCR_NUM_PEOPLE_GOAL_MST_ID}"             : 0, 
    f"{RP_URBANIZATION_SECTOR_MST_ID}_{RP_URB_2_INCR_ACCESS_URBAN_HOUS_GOAL_MST_ID}"           : RP_URB_2_3_USER_SPEC_PERC_URBAN_SUBG_MST_ID, 

    f"{RP_ENERGY_SECTOR_MST_ID}_{RP_ENERGY_1_INCR_POP_ACC_ELEC_GOAL_MST_ID}"                   : RP_ENERGY_1_2_USER_SPEC_PERC_POP_SUBG_MST_ID, 
    f"{RP_ENERGY_SECTOR_MST_ID}_{RP_ENERGY_2_INCR_PROD_ELEC_SUFF_LEVELS_GOAL_MST_ID}"          : RP_ENERGY_2_2_USER_SPEC_PERC_POP_SUBG_MST_ID, 
    f"{RP_ENERGY_SECTOR_MST_ID}_{RP_ENERGY_3_INCR_HOUS_ACCESS_CLEAN_GOAL_MST_ID}"              : RP_ENERGY_3_2_USER_SPEC_PERC_POP_SUBG_MST_ID, 

    #f"{RP_ECONOMIC_SECTOR_MST_ID}_{RP_ECON_1_REDUCE_AGE_DEPEND_RATIO_GOAL_MST_ID}"             : 0, 
    #f"{RP_ECONOMIC_SECTOR_MST_ID}_{RP_ECON_2_INCR_GDP_PER_CAPITA_GOAL_MST_ID}"                 : 0, 
    f"{RP_ECONOMIC_SECTOR_MST_ID}_{RP_ECON_3_DECR_UNEMPLOYMENT_GOAL_MST_ID}"                   : RP_ECON_3_2_USER_SPEC_RATE_SUBG_MST_ID, 
    f"{RP_ECONOMIC_SECTOR_MST_ID}_{RP_ECON_4_REDUCE_YOUTH_NEET_GOAL_MST_ID}"                   : RP_ECON_4_3_USER_SPEC_PERC_SUBG_MST_ID, 

    #f"{RP_BUILD_YOUR_OWN_SECTOR_MST_ID}_{RP_BYO_1_BYO_GOAL_MST_ID}"                            : 0, 
}

#######################################################################################################

# FP Scenario Goal options

RP_FP_SCEN_GOAL_ACCELERATE_MST_ID = 1
RP_FP_SCEN_GOAL_MEDIAN_MST_ID = 2
RP_FP_SCEN_GOAL_CUSTOM_MST_ID = 3

# FP Scenario Counterfactual (CF) options

RP_FP_SCEN_CF_MEDIAN_MST_ID   = 1
RP_FP_SCEN_CF_FLATLINE_MST_ID = 2
RP_FP_SCEN_CF_CUSTOM_MST_ID   = 3

# FP Scenarios

RP_FP_SCEN_STATUS_QUO_MST_ID     = 1
RP_FP_SCEN_GOAL_MST_ID           = 2 # 'Accelerated' in spreadsheet sometimes for some reason
RP_FP_SCEN_COUNTERFACTUAL_MST_ID = 3
RP_NUM_FP_SCENARIOS              = 3

RP_FP_SCEN_LIST = [RP_FP_SCEN_STATUS_QUO_MST_ID, RP_FP_SCEN_GOAL_MST_ID, RP_FP_SCEN_COUNTERFACTUAL_MST_ID]
RP_FP_SCEN_NO_STATUS_QUO_LIST = [RP_FP_SCEN_GOAL_MST_ID, RP_FP_SCEN_COUNTERFACTUAL_MST_ID]
RP_FP_SCEN_NO_COUNTERFACTUAL_LIST = [RP_FP_SCEN_STATUS_QUO_MST_ID, RP_FP_SCEN_GOAL_MST_ID]

# FP Scenario Scale-up (SC) Options

RP_FP_SCEN_SC_ACCELERATED = 1
RP_FP_SCEN_SC_MEDIAN      = 2
RP_FP_SCEN_SC_FLATLINE    = 3
RP_FP_SCEN_NUM_SC_OPTIONS = 3

# Target populations for BYO sector

RP_TP_TOTAL_POP_MST_ID        = 1
RP_TP_WOMEN_REPROD_AGE_MST_ID = 2
RP_TP_URBAN_POP_MST_ID        = 3
RP_TP_YOUTH_15_TO_29_MST_ID   = 4
RP_TP_HOUSEHOLDS_MST_ID       = 5
RP_TP_CHILDREN_UNDER_2_MST_ID = 6

# SSP scenarios

RP_SSP_BASE_MST_ID = 1
RP_SSP1_MST_ID     = 2
RP_SSP2_MST_ID     = 3
RP_SSP3_MST_ID     = 4
RP_SSP5_MST_ID     = 5

RP_SSP_LIST        = [RP_SSP1_MST_ID, RP_SSP2_MST_ID, RP_SSP5_MST_ID]
RP_SSP_BASE_LIST   = [RP_SSP_BASE_MST_ID, RP_SSP1_MST_ID, RP_SSP2_MST_ID, RP_SSP5_MST_ID]
RP_SSP_BASE_3_LIST = [RP_SSP_BASE_MST_ID, RP_SSP1_MST_ID, RP_SSP2_MST_ID, RP_SSP3_MST_ID, RP_SSP5_MST_ID]

