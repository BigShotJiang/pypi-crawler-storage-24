
################ GB ################

################ AM ################
AMDatabaseVersion = 'V8'
AMEasyAIMDatabaseVersion = 'V5'
AMCSAVRDatabaseVersion = 'V3'
AMPreventionsNeedsVersion = 'V4'

#  UNAIDS output file template 
AMUNAIDSSummaryTemplateVersion = 'V2'

DPDatabaseVersion = 'v0'
DPUPDVersion = 'V5'
DPInitialConditionsDBVersion = 'V9'

DPUADatabaseVersion = 'v0'


################ TB ################
TB_WHO_DB_VERSION = 'V6'
TB_FORT_INPUT_VERSION = 'V7'
TB_FORT_OUTPUT_VERSION = 'V7'
TB_DIAGNOSTICS_VERSION = 'V6'
TB_DYNAMICAL_MODEL_VERSION= 'V2'

