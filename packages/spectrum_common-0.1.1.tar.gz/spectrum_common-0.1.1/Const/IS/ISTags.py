# Input ModVars

# IS_CALC_TOTAL_MED_EQUIP_COSTS_V1:
# 
#   TB app, Infrastructure and equipment tab, Manage medical equipment per facility radio group. 
#   Enter total cost directly (false), Enter details used to calculate total costs (true) 
#
# IS_CALC_MAINT_COSTS_AS_PERC_MED_EQUIP_COSTS_TAG:
#
#  TB app, Infrastructure and equipment tab
#  Enter as absolute number (false), Calculate percentage of equipment costs (true)

IS_VERSION_TAG_V1                                = '<IS_Version_V1>'
IS_DATA_CHANGED_TAG_V1                           = '<IS_DataChanged_V1>'
IS_FILE_NAME_TAG_V1                              = '<IS_FileName_V1>'    
IS_PROJ_VALID_TAG_V1                             = '<IS_ProjectionValid_V1>'
IS_FACILITY_TYPE_RECORDS_TAG                     = '<IS_FacilityRecords_V2>'   
IS_FACILITY_MED_EQUIP_RECORDS_TAG                = '<IS_FacilityMedEquipRecords_V3>'    
IS_FACILITY_MED_EQUIP_GROUP_RECORDS_TAG          = '<IS_FacilityMedEquipGroupRecords_V3>' 
IS_FACILITY_FURNITURE_RECORDS_TAG_V1             = '<IS_FacilityFurnitureRecords_V1>'       
IS_PROJ_VALID_DATE_TAG_V1                        = '<IS_ProjectionValidDate_V1>'   
IS_ENTER_CONSTRUCT_COSTS_BY_COMP_TAG_V1          = '<IS_EnterConstructCostsByComponent_V1>'
IS_ENTER_OP_COST_PERC_CONSTRUCT_COST_TAG_V1      = '<IS_EnterOpCostAsPercOfConstructCost_V1>'
IS_FACIL_TARGET_SETTING_METHOD_TAG_V1            = '<IS_FacilityTargetSettingMethod_V1>'        
IS_VEHICLE_TYPE_RECORDS_TAG_V1                   = '<IS_VehicleRecords_V1>'
IS_DIRECT_ENTRY_FUEL_EXPEND_TAG_V1               = '<IS_EnterFuelExpendituresDirectly_V1>'
IS_COST_FUEL_PER_LITER_TAG_V1                    = '<IS_CostOfFuelPerLiter_V1>'
IS_ICT_EQUIPMENT_RECORDS_TAG_V1                  = '<IS_ICT_EquipmentRecords_V1>'
IS_PROG_MGMT_DATA_TAG_V1                         = '<IS_ProgMgmtData_V1>'       
IS_CALC_TOTAL_MED_EQUIP_COSTS_V1                 = '<IS_CalcTotalMedEquipCosts_V1>'       
IS_CALC_MAINT_COSTS_AS_PERC_MED_EQUIP_COSTS_TAG  = '<IS_CalcMaintCostsAsPercMedEquipCosts_V1>'

# Output / Result ModVars

IS_RES_TOTAL_NUM_FAC_AVAIL_TAG                     = '<IS_ResTotalNumFacilitiesAvail_V1>'
IS_RES_TOTAL_COST_BUILD_EQUIP_NEW_FAC_TAG          = '<IS_ResTotalCostBuildEquipNewFacilities_V1>'
IS_RES_NEW_FAC_CONSTRUCT_TAG                       = '<IS_ResNewFacilityConstruction_V1>'
IS_RES_TOTAL_NUM_BEDS_AVAIL_TAG                    = '<IS_ResTotalNumBedsAvail_V1>'
IS_RES_VEHIC_AVAIL_TAG                             = '<IS_ResVehiclesAvail_V1>'
IS_RES_VEHIC_PURCH_TAG                             = '<IS_ResVehiclesPurch_V1>'
IS_RES_VEHIC_PURCH_CAP_COSTS_TAG                   = '<IS_ResVehiclesPurchCapCosts_V1>'
IS_RES_VEHIC_PURCH_CAP_COSTS_BY_FAC_TAG            = '<IS_ResVehiclesPurchCapCostsByFacility_V1>' # For BG
IS_RES_VEHIC_PURCH_CAP_COSTS_OTHER_NON_FAC_TAG     = '<IS_ResVehiclesPurchCapCostsOtherNonFacility_V1>' # For BG
IS_RES_VEHIC_MAINT_REPAIR_COSTS_TAG                = '<IS_ResVehicleMaintRepairCosts_V1>'
IS_RES_VEHIC_MAINT_REPAIR_COSTS_BY_FAC_TAG         = '<IS_ResVehicleMaintRepairCostsByFacility_V1>' # For BG
IS_RES_VEHIC_MAINT_REPAIR_COSTS_OTHER_NON_FAC_TAG  = '<IS_ResVehicleMaintRepairCostsOtherNonFacility_V1>' # For BG
IS_RES_VEHIC_FUEL_COSTS_TAG                        = '<IS_ResVehicleFuelCosts_V1>'
IS_RES_VEHIC_FUEL_COSTS_BY_FAC_TAG                 = '<IS_ResVehicleFuelCostsByFacility_V1>' # For BG
IS_RES_VEHIC_FUEL_COSTS_OTHER_NON_FAC_TAG          = '<IS_ResVehicleFuelCostsOtherNonFacility_V1>' # For BG
IS_RES_VEHIC_DRIVER_SALARIES_TAG                   = '<IS_ResVehicleDriverSalaries_V1>'
IS_RES_VEHIC_DRIVER_SALARIES_BY_FAC_TAG            = '<IS_ResVehicleDriverSalariesByFacility_V1>' # For BG
IS_RES_VEHIC_DRIVER_SALARIES_OTHER_NON_FAC_TAG     = '<IS_ResVehicleDriverSalariesOtherNonFacility_V1>' # For BG
IS_RES_NEW_FAC_FURNITURE_COSTS_TAG                 = '<IS_ResNewFacilityFurnitureCosts_V1>'
IS_RES_FAC_LAND_COSTS_TAG                          = '<IS_ResFacilityLandCosts_V1>'
IS_RES_NEW_FAC_CONSTRUCT_COSTS_TAG                 = '<IS_ResNewFacilityConstructCosts_V1>'
IS_RES_NEW_FAC_MED_EQUIP_COSTS_TAG                 = '<IS_ResNewFacilityMedEquipCosts_V1>'
IS_RES_FAC_REHAB_COSTS_TAG                         = '<IS_ResFacilityRehabCosts_V1>'
IS_RES_FAC_TOTAL_OP_COSTS_TAG                      = '<IS_ResFacilityTotalOpCosts_V1>'
IS_RES_OTHER_FAC_OP_COSTS_TAG                      = '<IS_ResOtherFacilityOpCosts_V1>'
IS_RES_FAC_WATER_COSTS_TAG                         = '<IS_ResFacilityWaterCosts_V1>'
IS_RES_FAC_ELECTRIC_COSTS_TAG                      = '<IS_ResFacilityElectricCosts_V1>'
IS_RES_ICT_AVAIL_TAG                               = '<IS_ResICTAvail_V1>'
IS_RES_ICT_PURCH_TAG                               = '<IS_ResICTPurch_V1>'
IS_RES_ICT_CAP_COSTS_TAG                           = '<IS_ResICTCapCosts_V1>'
IS_RES_ICT_CAP_COSTS_BY_FAC_TAG                    = '<IS_ResICTCapCostsByFacility_V1>' # For BG
IS_RES_ICT_CAP_COSTS_OTHER_NON_FAC_TAG             = '<IS_ResICTCapCostsOtherNonFacility_V1>' # For BG
IS_RES_ICT_MAINT_REPAIR_OP_COSTS_TAG               = '<IS_ResICTMaintRepairOpCosts_V1>'
IS_RES_ICT_MAINT_REPAIR_OP_COSTS_BY_FAC_TAG        = '<IS_ResICTMaintRepairOpCostsByFacility_V1>' # For BG
IS_RES_ICT_MAINT_REPAIR_OP_COSTS_OTHER_NON_FAC_TAG = '<IS_ResICTMaintRepairOpCostsOtherNonFacility_V1>' # For BG
IS_RES_MED_EQUIP_MAINT_CALIB_COSTS_TB_TAG          = '<IS_ResMedEquipMaintCalibCostsTB_V1>'

# Disease-specific costing (DSC), TB costing mode

# "Equipment costs"; Replaces <IS_ResNewFacilityConstructCosts_V1> for TB app because we don't have access 
# to the same inputs without having Infrastructure on and have to therefore calculate it differently.
IS_RES_EQUIPMENT_COSTS_DSC_V1                     = '<IS_ResEquipmentCostsDSC_V1>'

# Meta modvars; the values inside these do not change. 

IS_DEFAULT_MED_EQUIP_GROUP_LIST_META_TAG = '<IS_DefaultMedEquipGroupList_Meta_V1>'