# Database latest versions
IS_FACILITY_EQUIP_DB_CURR_VERSION = 'V6' # Use for facility equipment medical group database as well since they are derived from the same place.

# Database names (also the names of the sheets in ISModData.xlsx)
IS_FACILITY_EQUIP_DB_NAME            = 'FacilityEquipmentDB'
IS_FACILITY_MED_EQUIP_GROUP_DB_NAME  = 'FacilityMedEquipmentGroupDB' # Derived from FacilityEquipmentDB in ISModData but written to separate file for ease of processing.

# Default facility types 
IS_HEALTH_POST_CURR_ID                   = 1
IS_PREHOSPITAL_EMERGENCY_CURR_ID         = 2
IS_HEALTH_CENTER_CURR_ID                 = 3
IS_FREE_STAND_GEN_OUTPAT_CLINIC_CURR_ID  = 4
IS_DISTRICT_GEN_HOSPITAL_CURR_ID         = 5
IS_NAT_REG_PROV_HOSPITAL_CURR_ID         = 6
IS_FREE_STAND_SPEC_OUTPAT_CLINIC_CURR_ID = 7
IS_NUM_DEF_FACILITY_TYPES                = IS_FREE_STAND_SPEC_OUTPAT_CLINIC_CURR_ID

IS_NO_FACILITY_MST_ID                   = 0 # only use as an id type, dont alter arrays
IS_HEALTH_POST_MST_ID                   = 1
IS_HEALTH_CENTER_MST_ID                 = 2
IS_DISTRICT_GEN_HOSPITAL_MST_ID         = 3
IS_NAT_REG_PROV_HOSPITAL_MST_ID         = 4
IS_CENTRAL_HOSPITAL_MST_ID              = 5 # Defunct; merged with provincial hospital, which is now National/regional/provincial hospital
IS_PREHOSPITAL_EMERGENCY_MST_ID         = 6
IS_FREE_STAND_GEN_OUTPAT_CLINIC_MST_ID  = 7
IS_FREE_STAND_SPEC_OUTPAT_CLINIC_MST_ID = 8

# Support facility types

IS_FACILITY_DELIV_INTERV_CURR_ID = 1
IS_FACILITY_SUPPORT_FUNC_CURR_ID = 2
IS_NUM_FACILIT_SUPPORT_TYPES = IS_FACILITY_SUPPORT_FUNC_CURR_ID

IS_FACILITY_DELIV_INTERV_MST_ID = 1
IS_FACILITY_SUPPORT_FUNC_MST_ID = 2

# Facility equipment types

IS_FACIL_MEDICAL_EQUIP_CURR_ID   = 1
IS_FACIL_FURNITURE_EQUIP_CURR_ID = 2
IS_NUM_FACIL_EQUIP_TYPES = IS_FACIL_FURNITURE_EQUIP_CURR_ID

IS_FACIL_MEDICAL_EQUIP_MST_ID   = 1
IS_FACIL_FURNITURE_EQUIP_MST_ID = 2

# Target setting facility methods (TSFM)

IS_TSFM_POP_NORMS_CURR_ID                   = 1
IS_TSFM_EXIST_PLANS_EXPECTED_OP_CURR_ID     = 2
IS_TSFM_EXIST_PLANS_BEGIN_CONSTRUCT_CURR_ID = 3
IS_NUM_TARG_SET_FACIL_METHODS               = IS_TSFM_EXIST_PLANS_BEGIN_CONSTRUCT_CURR_ID

IS_TSFM_POP_NORMS_MST_ID                   = 1
IS_TSFM_EXISTING_PLANS_MST_ID              = 3 # defunct
IS_TSFM_EXIST_PLANS_EXPECTED_OP_MST_ID     = 4
IS_TSFM_EXIST_PLANS_BEGIN_CONSTRUCT_MST_ID = 5

# Rehab types

IS_REHAB_SMALL_SCALE_CURR_ID         = 1
IS_REHAB_MEDIUM_SCALE_CURR_ID        = 2
IS_REHAB_LARGE_SCALE_CURR_ID         = 3
IS_REHAB_MAINT_REPLACE_EQUIP_CURR_ID = 4
IS_NUM_REHAB_TYPES                   = IS_REHAB_MAINT_REPLACE_EQUIP_CURR_ID

IS_DEF_MED_EQUIP_GROUP_ID = '1'