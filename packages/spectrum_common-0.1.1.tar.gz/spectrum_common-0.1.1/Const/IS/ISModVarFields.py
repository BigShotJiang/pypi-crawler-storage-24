# Fields used in IS data structures

'''
    General notes:

    We avoid keeping lists of records inside of records (for example, medical equipment records inside facility records) mainly to keep 
    structures from becoming too large.  This will hopefully prevent slowdowns and memory inefficiency as well as make certain things easier
    to spot manually when looking through records. Use a field (such as facilityTypeID) to connect these records.

    IDs are spelled out like facilityTypeID rather than just ID inside records to make things obvious when manually looking through records.
'''

IS_F_FACILITY_TYPE_ID            = 'facilityTypeID' 
IS_F_FACILITY_MED_EQUIP_GROUP_ID = 'facilityMedEquipGroupID'
IS_F_FACILITY_EQUIP_ID           = 'facilityEquipID' 
IS_F_VEHICLE_TYPE_ID             = 'vehicleID'   
IS_F_ICT_EQUIP_ID                = 'ICT_EquipID' 

# facility records - contains all inputs that are not also lists of records. Those are kept outside mainly for size issues. Use 
# facilityTypeID to connect the facility records to those other lists of records.

IS_FACIL_TYPE_ID                                   = IS_F_FACILITY_TYPE_ID                     # string;  numeric mstID for defaults. GUID for customs.
IS_FACIL_STR_CONSTANT                              = 'stringConstant'                          # string;  Defaults only.
IS_FACIL_NAME                                      = 'name'                                    # string;  Holds custom name or overridden default name.
IS_FACIL_ACTIVE                                    = 'active'                                  # boolean; Is user using this item or not?
IS_FACIL_SUPP_TYPE_MST_ID                          = 'supportTypeMstID'                        # integer;
IS_FACIL_DELIV_CHAN_MST_ID                         = 'delivChanMstID'                          # string;  ID from delivery channel records
IS_FACIL_CUSTOM                                    = 'custom'                                  # boolean; user-entered = true; default = false
IS_FACIL_DEFAULT_MAP_MST_ID                        = 'defFacilityTypeMapMstID'                 # int;  mstID of facility type (from facility type records) user maps custom facility types to
IS_FACIL_EQUIP_PURCHASE_COST                       = 'equipmentPurchaseCost'                   # 1d list of float; by equipment type
IS_FACIL_MED_EQUIP_MAINT_COST                      = 'medEquipmentMaintCost'                   # float; TB app only
IS_FACIL_MED_EQUIP_CALIB_COST                      = 'medEquipmentCalibrationCost'             # float; TB app only
IS_FACIL_NUM_TO_EQUIP                              = 'numToEquip'                              # 1d list of integer; by year
IS_FACIL_TOTAL_NUMBER_BASELINE                     = 'totalNumBaseline'                        # integer
IS_FACIL_AVG_NUM_BEDS                              = 'avgNumBeds'                              # integer
IS_FACIL_AVG_OCCUP_RATE_BEDS                       = 'avgOccupancyRateBeds'                    # integer
IS_FACIL_AVG_NUM_OUTPAT_VISITS_PER_YEAR            = 'avgNumOutpatVisitsPerYear'               # integer
IS_FACIL_YEARS_TO_BUILD                            = 'yearsToBuild'                            # integer
IS_FACIL_TOTAL_CONSTRUCT_COST                      = 'totalConstructCost'                      # integer
IS_FACIL_LAND_COST                                 = 'landCost'                                # float
IS_FACIL_CONSTRUCT_COST_PER_SQ_M                   = 'constructionCostPerSqM'                  # float
IS_FACIL_AVG_SIZE_IN_SQ_M                          = 'avgSizeSqM'                              # float
IS_FACIL_REHAB_COST                                = 'rehabCost'                               # 1d list of float; by rehab type
IS_FACIL_TOTAL_OP_COST                             = 'totalOpCost'                             # float
IS_FACIL_TOTAL_OP_COSTS_PERC_CONSTRUCT_COST        = 'totalOpCostAsPercOfConstructCost'        # float
IS_FACIL_DESIRED_POP_FACIL_RATIO_POP_NORMS         = 'desiredPopPerFacilityRatioPopNorms'      # integer
IS_FACIL_TARG_SCALE_UP_POP_NORMS                   = 'targScaleUpPopNorms'                     # 1d list of integer; by year
IS_FACIL_TARG_SCALE_UP_EXIST_PLANS_EXPECTED_OP     = 'targScaleUpExistingPlansExpectedOp'      # 1d list of integer; by year
IS_FACIL_TARG_SCALE_UP_EXIST_PLANS_BEGIN_CONSTRUCT = 'targScaleUpExistingPlansBeginConstruct'  # 1d list of integer; by year
IS_FACIL_TARG_NUM_TO_REHAB                         = 'targNumToRehab'                          # 1d list of integer; by rehab type
IS_FACIL_TARG_NUM_TO_REHAB_BY_YEAR                 = 'targNumToRehabByYear'                    # 2d list of integer; rehab type x year

# facility medical equipment group records

IS_FACIL_MEG_ID                = IS_F_FACILITY_MED_EQUIP_GROUP_ID # string; numeric mstID for defaults (still cast as string). GUID for custom groups
IS_FACIL_MEG_NAME              = 'name'                           # string
IS_FACIL_MEG_STR_CONST         = 'stringConstant'                 # string;  Defaults only.
IS_FACIL_MEG_FACIL_TYPE_ID     = IS_F_FACILITY_TYPE_ID            # string

# facility equipment records (can be either medical equipment or furniture)

IS_FACIL_EQUIP_ID            = IS_F_FACILITY_EQUIP_ID # string; numermic mstID for defaults (still cast as string). GUID for custom equipment.
IS_FACIL_EQUIP_NAME          = 'name'                 # string
IS_FACIL_EQUIP_STR_CONST     = 'stringConstant'       # string;  Defaults only.
IS_FACIL_EQUIP_CUSTOM        = 'custom'               # boolean
IS_FACIL_EQUIP_FACIL_TYPE_ID = IS_F_FACILITY_TYPE_ID  # string
IS_FACIL_EQUIP_UNIT_COST     = 'unitCost'             # float
IS_FACIL_EQUIP_NUM_UNITS     = 'numUnits'             # float
IS_FACIL_EQUIP_WORKING_LIFE  = 'workingLife'          # float
#IS_FACIL_EQUIP_REQ_PURCHASE = 'reqPurchase'          # float
IS_FACIL_EQUIP_MAINT_COST    = 'maintenanceCost'      # float, medical equipment only, TB app only
IS_FACIL_EQUIP_CALIB_COST    = 'calibrationCost'      # float, medical equipment only, TB app only

# for facility medical equipment records

IS_FACIL_EQUIP_MEG_ID  = IS_F_FACILITY_MED_EQUIP_GROUP_ID  # string; numeric mstID for defaults (still cast as string). GUID for custom groups

# vehicle records

IS_VEHIC_ID                          = IS_F_VEHICLE_TYPE_ID                      # string; numermic mstID for defaults (still cast as string). GUID for custom equipment.
IS_VEHIC_NAME                        = 'name'                               # string
IS_VEHIC_CUSTOM                      = 'custom'                             # bool
IS_VEHIC_CURR_NUMBER                 = 'currNumber'                         # float
IS_VEHIC_UNIT_COST                   = 'unitCost'                           # float
IS_VEHIC_WORKING_LIFE_YEARS          = 'workingLifeInYears'                 # float
IS_VEHIC_DRIVER_SALARY               = 'driverSalary'                       # float
IS_VEHIC_FUEL_CONSUMPTION            = 'fuelConsumption'                    # float
IS_VEHIC_FUEL_COST_DIRECT_ENTRY      = 'fuelCostDirectEntry'                # float
IS_VEHIC_DISTANCE_DRIVEN_PER_YEAR    = 'distanceDrivenPerYear'              # float
IS_VEHIC_REPAIR_MAINT_PERC_CAP_COST  = 'repairAndMaintPercCapCost'          # float
IS_VEHIC_TARG_NUM_PER_FACILITY       = 'targNumPerFacility'                 # 1d list of integer; by facility
IS_VEHIC_TARG_NUM_PER_FACILITY_OTHER = 'targNumPerFacilityOtherNonFacBased' # integer

# ICT equipment records

IS_ICT_EQUIP_ID                      = IS_F_ICT_EQUIP_ID                     # string; numermic mstID for defaults (still cast as string). GUID for custom equipment.
IS_ICT_EQUIP_NAME                    = 'name'                                # string
IS_ICT_EQUIP_CUSTOM                  = 'custom'                              # bool
IS_ICT_EQUIP_CURR_NUMBER             = 'currNumber'                          # float
IS_ICT_EQUIP_UNIT_COST               = 'unitCost'                            # float
IS_ICT_EQUIP_WORKING_LIFE_YEARS      = 'workingLifeInYears'                  # float
IS_ICT_EQUIP_OP_COST_PERC_CAP_COST   = 'opCostPercCapCost'                   # float
IS_ICT_REPAIR_MAINT_PERC_CAP_COST    = 'repairAndMaintPercCapCost'           # float
IS_ICT_TARG_NUM_PER_FACILITY         = 'targNumPerFacility'                  # 1d list of integer; by facility
IS_ICT_TARG_NUM_PER_FACILITY_OTHER   = 'targNumPerFacilityOtherNonFacBased'  # integer