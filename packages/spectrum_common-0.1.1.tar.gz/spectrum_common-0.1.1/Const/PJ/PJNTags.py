PJN_TitleTag = "<PJN_Title_V1>"
PJN_AppIDTag = "<PJN_AppID_V1>"
PJN_ProjectionValidTag = "<PJN_ProjectionValid_V1>"
PJN_ProjectionSavedTag = "<PJN_ProjectionSaved_V1>"
PJN_AIMImpactCalculatedTag = '<PJN_AIMImpactCalculated_V1>'

PJN_UserSourceTag = "<PJN_UserSource_V1>"

# Versions'<PJN_ _V1>'
PJN_VersionTag = "<PJN_Version_V1>"
PJN_VersionNumberTag = "<PJN_VersionNumber_V1>"
PJN_BetaVersionTag = "<PJN_BetaVersion_V1>"

# years'<PJN_ _V1>'
# PJN_BaseYearTag = "<PJN_BaseYear_V1>"
PJN_FirstYearTag = "<PJN_FirstYear_V1>"
PJN_FinalYearTag = "<PJN_FinalYear_V1>"

# country info'<PJN_ _V1>'
PJN_CountryNameTag = "<PJN_CountryName_V1>"
PJN_ISO3NumericTag = "<PJN_ISO3Numeric_V1>"
PJN_ISO3AlphaTag = "<PJN_ISO3Alpha_V1>"


PJN_IHTPlanTypeTag = "<PJN_IHTPlanType_V1>"

PJN_SubNationalCodeTag = "<PJN_SubNationalCode_V1>"
PJN_SubNationalNameTag = "<PJN_SubNationalName_V1>"

PJN_ModulesTag = "<PJN_Modules_V1>"

PJN_TBSubnatTag = "<PJN_TBSubnat_V1>"

PJN_AuthorTag = "<PJN_Author_V1>"
PJN_OrganizationTag = "<PJN_Organization_V1>"
PJN_NotesTag = "<PJN_Notes_V1>"
PJN_CKAN_NameID_Tag = "<PJN_CKAN_NameID_V1>"
PJN_LibraryIDTag = "<PJN_LibraryID_V1>"
PJN_LibraryVersionIDTag = "<PJN_LibraryVersionID_V1>"

PJN_ReadOnlyTag = "<PJN_ReadOnly_V1>"
PJN_CKANCapacityTag = "<PJN_CKAN_CAPACITY_V1>"
PJN_Modes_Tag = "<PJN_Modes_V1>"

GB_UseLeapfrogTag = "<GB_UseLeapfrog_V1>"
GB_DataChangedTag = "<GB_DataChanged_V1>"
GB_CalcStateValidTag = "<GB_CalcStateValid_V1>"
GB_CustomEasyDataSetTag = "<GB_CustomEasyDataSet_V1>"

GB_CurrencyNameTag = "<GB_CurrencyName_V1>"
GB_DiscountRateCostsTag = "<GB_DiscountRateCosts_V1>"
GB_ExchangeRateTag = "<GB_ExchangeRate_V1>"
GB_InflationTag = "<GB_Inflation_V1>"
GB_InflationMethodTag = "<GB_InflationMethod_V1>"

GB_DisabilityWeightsTag = "<GB_DisabilityWeights_V1>"
GB_DisabilityWeightsSetTag = "<GB_DisabilityWeightsSet_V1>"

GB_LCOnTag = "<GB_LCOn_V1>"
GB_GSKModeTag = '<GB_GSKMode_V1>'
GB_TBCostingOnTag = "<GB_TBCostingOn_V1>"
GB_IHTOnTag = "<GB_IHTOn_V1>"
# GB_RAPIDSectorsOnTag = "<GB_RAPIDSectorsOn_V1>"

GB_SubnatWizProjTag = "<GB_SubnatWizProj_V1>"
GB_SubnatRegionTag = "<GB_SubnatRegion_V1>"
GB_SubnatRegionCodeTag = "<GB_SubnatRegionCode_V1>"
GB_SubnatSurveydTag = "<GB_SubnatSurveyd_V1>"

GB_TBImpactStatisticalTag = "<GB_TBImpactStatistical_V1>"
GB_TBImpactDynamicalTag   = "<GB_TBImpactDynamical_V1>"
GB_UserSourcesTag         = "<GB_UserSources_V1>"
GB_TaskGUIDsTag           = "<GB_TaskGUIDs_V1>"
