
# Global Constants }
#$I FPTagsRW.INC}
FP_Table           = 101
#  FP_Pie             = 102

# Read Write determines size of numbers in file 
FP_FileNumSpace = 20
FP_FileRDec     = 6
FP_Version      = 4.5
# Error Messages 
FP_NOERROR           = 0
FP_ERROR             = 1

# Special family planning constants }
FP_DataFileTitle     = 'Family Planning Module Data File - The POLICY Project'

FP_DatFVersion       = 7.00
FP_DatFVersion70     = 7.00   #reduced FileName.FP file size
FP_DatFVersion60     = 6.00         #added SDM method
FP_DatFVersion50     = 5.00
FP_DatFVersion43     = 4.30        #Added LAM Method}
FP_DatFVersion42     = 4.20
FP_DatFVersion41     = 4.10
FP_DatFVersion4      = 4.00

FP_All = 0
FP_MAR = 1
FP_MARUMSA = 2
FP_AllUninterpolated = 3
FP_MARUninterpolated = 4
FP_MARUMSAUninterpolated = 5

FP_DB_SheetName = {
    FP_All: 'All Data',
    FP_MAR: 'MAR',
    FP_MARUMSA: 'MARUMSA',
    FP_AllUninterpolated: 'All Data (Uninterpolated)',
    FP_MARUninterpolated: 'MAR (Uninterpolated)',
    FP_MARUMSAUninterpolated: 'MARUMSA (Uninterpolated)'
}

FP_InterpDir = 'countries/interpolated' 
FP_Uninterp  = 'countries/uninterpolated'

FP_DB_Dir = {
    FP_All : FP_InterpDir,
    FP_MAR : FP_InterpDir,
    FP_MARUMSA : FP_InterpDir,
    FP_AllUninterpolated : FP_Uninterp,
    FP_MARUninterpolated : FP_Uninterp,
    FP_MARUMSAUninterpolated : FP_Uninterp
}

FP_All_SubDir = 'All'
FP_MAR_SubDir = 'MAR'
FP_MARUMSA_SubDir = 'MARUMSA'

FP_DB_SubDir = {
    FP_All : FP_All_SubDir,
    FP_MAR : FP_MAR_SubDir,
    FP_MARUMSA : FP_MARUMSA_SubDir,
    FP_AllUninterpolated : FP_All_SubDir,
    FP_MARUninterpolated : FP_MAR_SubDir,
    FP_MARUMSAUninterpolated : FP_MARUMSA_SubDir
}

FP_DB_Version = {
    FP_All : 'V2',
    FP_MAR : 'V2',
    FP_MARUMSA : 'V2',
    FP_AllUninterpolated : 'V2',
    FP_MARUninterpolated : 'V2',
    FP_MARUMSAUninterpolated : 'V2'
}

FP_ShowNewFeatures = True

# Age constants }
FP_All_Ages = 0
FP_A15_19   = 1
FP_A20_24   = 2
FP_A25_29   = 3
FP_A30_34   = 4
FP_A35_39   = 5
FP_A40_44   = 6
FP_A45_49   = 7
FP_MAX_AGE  = 7

#   FP_AgeCats : array[FP_All_Ages..FP_MAX_AGE] of string =
#                  ('All Ages', '15-19', '20-24', '25-29',
#                   '30-34', '35-39', '40-44',
#                   '45-49')

# Need constants }
FP_all_need     = 0
FP_spacing      = 1
FP_limiting     = 2
FP_max_need     = 2


# Time constants
FP_FirstDBYear   = 1990
FP_FinalDBYear   = 2030

# Age group constants }
FP_Single_Age_Group     = 1
FP_Five_Year_Age_Groups = 2

# Goal constants }
FP_Unmet_need     = 1
FP_Desired_TFR    = 2
FP_Prevalence     = 3
FP_TFR            = 4  #Total fertility rate goal
FP_mCPR           = 5  #modern contraceptive prevalence goal
FP_AddMdrnMeth    = 6  #additional modern method users goal
FP_Pregnancy      = 7

FP_TFR_MT_TFRGOAL   = 0
FP_ASFR_TFRGOAL     = 1

# Abortion constants }
FP_specify_TAR         = 1
FP_calculate_abortions = 2


# Method constants
FP_all_methods    = 0
# condoms
FP_CondomFM       = 1
FP_CondomML       = 2
# sterilization
FP_fster          = 3
FP_mster          = 4

# vaginal barriers and tablets
FP_vag_barrier    = 5
FP_VFT            = 6

# traditional contraceptive methods
FP_withdrawal     = 7
FP_PerAbst        = 8 # periodic abstinence
FP_Traditional    = 9

# injectables
FP_inj3month      = 10
FP_inj2month      = 11
FP_inj1month      = 12
FP_inj6month      = 13
FP_Uninject       = 14

# implants
FP_Implanon       = 15
FP_Jadelle        = 16
FP_Sino_Implant   = 17

# pills
FP_StandardPill   = 18
FP_Progestin      = 19
FP_Peri_coital    = 20

# IUD
FP_IUDCopper      = 21
FP_IUDLngIus      = 22

FP_LAM            = 23
FP_SDM            = 24
FP_other          = 25

FP_LastDefMethod  = 25
FP_MstDefMeth     = 31
FP_CustMethodMax  = 12
FP_Max_Methods    = FP_MstDefMeth+FP_CustMethodMax
FP_first_method   = 1
FP_last_method    = FP_Max_Methods

FP_Condoms        = [FP_CondomML, FP_CondomFM]
FP_Sterilizations = [FP_fster,FP_mster]
FP_Injectables    = [FP_inj3month,FP_inj2month,FP_inj1month,
                    FP_inj6month, FP_Uninject]
FP_Implants       = [FP_Implanon,FP_Jadelle,FP_Sino_Implant]
FP_IUD            = [FP_IUDCopper, FP_IUDLngIus]
FP_Pills          = [FP_StandardPill, FP_Progestin, FP_Peri_coital]
FP_FertAware      = [FP_LAM,FP_SDM]
FP_Barrier        = [FP_vag_barrier,FP_VFT]


FP_TRAD_METH  = [FP_PerAbst, FP_withdrawal, FP_Traditional]
# FP_AllMethods = [1..FP_Max_Methods]

# # FP_otherMethods = FP_AllMethods-(FP_Condoms  + FP_Sterilizations + FP_Injectables
#                                 + FP_Implants + FP_Pills + FP_IUD+FP_TRAD_METH
#                                 + FP_FertAware+ FP_Barrier)

# # default Type of Methods(shortTerm/LongTerm)
# FP_DEFPermMeth      = [FP_fster,FP_mster]
# FP_DefLongTermMeth  = [FP_Implanon, FP_Jadelle, FP_Sino_Implant, FP_IUDCopper,
#                         FP_IUDLngIus]
# FP_DefShortTermMeth = [FP_condomFM, FP_condomML, FP_VFT, FP_Lam, FP_Other,
#                         FP_Uninject, FP_SDM, FP_vag_barrier]+FP_Injectables+FP_Pills



FP_PermanentMethods  = [FP_fster,FP_mster]
FP_LongTermtMethods  = [FP_Implanon, FP_Jadelle, FP_Sino_Implant, FP_IUDCopper, 
                         FP_IUDLngIus]
FP_ShortTermMethods = ([FP_CondomFM, FP_CondomML, FP_VFT, FP_LAM, FP_other, 
                         FP_Uninject, FP_SDM, FP_vag_barrier] + FP_Injectables + FP_Pills)

# FP_ActiveMethodsDefault = [FP_StandardPill,FP_IUDCopper,FP_inj3month,FP_condomML,
#                             FP_fster,FP_mster,FP_Jadelle,FP_LAM,FP_vag_barrier,
#                             FP_VFT,FP_withdrawal]

# #      Condom, sterilization, Injectable, Implant, Pill, IUD, LAM, SDM, vaginal barrier, spermicide
# # FP_ModernCPRMeth = FP_Condoms+FP_Sterilizations+FP_Injectables+FP_Implants
# #                 + FP_IUD+FP_Pills+[FP_LAM, FP_SDM, FP_vag_barrier]


#   # Fecundity constants 
#   FP_Fecundity_constant : array[FP_All_Ages..FP_MAX_AGE] of single =
#                           (1.08, 1.02, 1.02, 1.03, 1.04, 1.12, 1.33, 1.08)

  # Source constants 
FP_all_sources        = 0
FP_max_sources        = 10
FP_PUB_SRC            = 1

# Scale constants 
FP_units             = 1
FP_thousands         = 2
FP_millions          = 3
FP_thousand_millions = 4

# Pregnancy constants 
FP_all_PREG = 0
FP_wanted   = 1
FP_unwanted = 2
FP_mistimed = 3
FP_MAX_PREG = 3

# Method Mix Editor style constants 
FP_METHMIXED_1 = 1
FP_METHMIXED_2 = 2
FP_METHMIXED_3 = 3
FP_METHMIXED_4 = 4

FP_LAM0_1   = 1
FP_LAM2_3   = 2
FP_LAM4_5   = 3

# Indicator constants
FP_SecFertility        = 1
FP_SecImpactFP         = 2
FP_SecWRA              = 2 #bump back up after removing FP_ShowNewFeatures
FP_Sec_DemoEvents      = 3 #formerly FP_SecPregnancies
FP_SecRelativeRisk     = 4
FP_SecMortRate         = 5
FP_PACSec              = 6
FP_SecGrossCost        = 7
FP_SecSummary          = 8
FP_MAXSEC              = 8

FP_FirstInd            = 201
FP_cmAvgEff            = 201
FP_cmPrevalence        = 202
FP_cmUnmetNeed         = 203
FP_cmTFR               = 204
FP_cmWRA               = 205
FP_cmMWRA              = 206
FP_cmUsers             = 207
FP_cmAcceptors         = 208
FP_cmCYP               = 209
FP_cmGrossCost         = 210
FP_cmCostPerUser       = 211
FP_cmRevenue           = 212
FP_cmNetCost           = 213
FP_cmCommodities       = 214
FP_cmBirths            = 215
FP_cmAbortions         = 216
FP_cmPregnancies       = 217

FP_cmTF                = 218
FP_cmGrowthRates       = 219
FP_cmFPSumInp          = 220
FP_cmFPSumOut          = 221

# PAC Indicator Constants 
FP_cmMaternDeathTotal  = 222
FP_cmMDWantBirth       = 223
FP_cmMDUnWantBirth     = 224
FP_cmMDTreatIllAbort   = 225
FP_cmMDUnTreatIllAbort = 226
FP_cmTotDeathAvert     = 227
FP_cmPACAbortions      = 228
FP_cmIllAbortions      = 229
FP_cmIllAbortNoTreat   = 230
FP_cmIllAbortTreat     = 231
FP_cmTreatIllAbort     = 232
FP_cmUntreatIllAbort   = 233
FP_cmMMR               = 234
FP_cmMaternDeathAbort  = 235
FP_cmPACSummary        = 236

# Child Survival 
FP_cmPerBirthRisk      = 237
FP_cmFertAdjIMR        = 238
FP_cmFertAdjU5MR       = 239

#relative risk indicators
FP_cmAgeAndBirth       = 240
FP_cmBirthInterv       = 241
FP_cmBirthAverted      = 242
FP_cmModernCPR         = 243
FP_cmAddModernUsers    = 244
FP_cmPregAvertModern   = 245
FP_cmMatDeathAvertMdrn = 246
FP_cmAbortAvertedMdrn  = 247
FP_cmPercWomenUnmetNeed= 248
FP_cmPercSatisfiedMdrn = 249
FP_cmPreganancyRate    = 250


FP_MAXIND              = 250#239

#Relative Risk
FP_NumRelativeRiskCat = 15
#constants for order of births
FP_RRFirstBirth      = 1
FP_RRSecToThirdBirth = 2
FP_RRMoreFourBirth   = 3
FP_RRBirthOrderMax   = 3

#mothers ages
FP_RRLess18   = 1
FP_RR18To34   = 2
FP_RRMore34   = 3
FP_RRAgeOrderMax = 3

#  FP_RRFirstBirth       = 1
FP_RRLess18Months     = 2
FP_RR18to23Months     = 3
FP_RRMore24Months     = 4
FP_RRBirthIntervalMax = 4
FP_RRExtraBirthIntervals = 5

FP_RRIntrcept = 1
FP_RRC1       = 2
FP_RRC2       = 3

FP_RRBOGreater3 = 1
FP_RRMAGreat35  = 2
FP_RRMA18To34   = 3



#Constants used for Results
FP_MethodInd        = 11
FP_SourceInd        = 12
FP_AgeInd           = 13
FP_NeedInd          = 14
FP_PREGInd          = 15
FP_SINGLE_METHODIND = 16
FP_NO_TOTAL         = 17
FP_RelRiskInd       = 18
FP_SUMInd           = 19

# PAC Input Constants 
FP_PerAbortLegal            = 1
FP_PerIllAbortTreat         = 2
FP_PerLegalAbortTreat       = 3
FP_MMRMaternDeath           = 4
FP_PerMaternDeathAbortion   = 5
FP_MortalityUntreatVsTreat  = 6
FP_AnnPostAbortCare         = 7
FP_CostAbortCompTreat       = 8
FP_CostCounServCase         = 9

FP_PACMaternalSet = [FP_MMRMaternDeath]

# PAC Output/Calculated Constants 
FP_WantedPreg               = 1
FP_UnwantedPreg             = 2
FP_PerAbortNeedTreatReceive = 3
FP_MMRBirthsOne             = 4
FP_AbortDeathsPerAbort      = 5
FP_DeathTreatIllAbort       = 6
FP_DeathUntreatIllAbort     = 7
FP_MDTotal                  = 8
FP_MDWantBirths             = 9
FP_MDUnwantBirths           = 10
FP_MDTreatIllAbort          = 11
FP_MDUntreatIllAbort        = 12
FP_TotDeathAvert            = 13
FP_Births                   = 14
FP_WantedBirths             = 15
FP_UnwantedBirths           = 16
FP_Abortions                = 17
FP_IllAbortions             = 18
FP_IllAbortNoTreat          = 19
FP_IllAbortTreat            = 20
FP_TreatIllAbort            = 21
FP_UntreatIllAbort          = 22
FP_MMR                      = 23
FP_MMRBirthsTwo             = 24
FP_MMRAbort                 = 25
FP_MaternDeathAbort         = 26
FP_LivesSaved               = 27
FP_CostTreatUnsafeAbort     = 28
FP_CostPerMaternDeathAvert  = 29

# Calculation method constants 
FP_TotFec = 1   #Use total fecundity and proximate determinants
FP_PregRate = 2   # Use pregnancy rate approach 
FP_CalculationMethods = [FP_TotFec, FP_PregRate]

FP_MiscarriagePercent       = 15.0 # 15%

# Child Survival 
FP_PerBirthRisk  = 1
FP_FertAdjIMR    = 2
FP_FertAdjU5MR   = 3
FP_RelRiskyBirth = 4
FP_RelIMR        = 5
FP_RelU5MR       = 6

# EC 
FP_AvgCoitFr = 1
FP_EffEmerContr = 2
FP_TF = 3

FP_PercUnpro = 1
FP_PercElig = 2
FP_IndexEC = 3

# Policy analysis 
FP_BYear    = 0
FP_TYear    = 1

#easy famplan file
FP_EasyFamPlanDBFileName2 = 'EasyFamPlan_Source.xlsx'

# Help file constants 
FP_Help_Configuration           = 'Configuration'
FP_Help_MethodMix               = 'Method_mix'
FP_Help_SourceMix               = 'Source_mix'
FP_Help_ProximateDeterminants   = 'Proximate_determinants'
FP_Help_ChildSurvival           = 'Child_survival'
FP_Help_CostsOfServices         = 'Costs_of_services'
FP_Help_Fees                    = 'Fees'
FP_Help_MethodAttributes        = 'Method_attributes'
FP_Help_LAM                     = 'LAM'
FP_Help_Effectiveness           = 'Effectiveness'
FP_Help_ReducingUnmetNeed       = 'Reducing_unmet_need_for_contraception'
FP_Help_TotalWantedFertility    = 'Total_wanted_fertility'
FP_Help_ReachingGoalPrevalence  = 'Reaching_a_goal_for_contraceptive_prevalence'
FP_Help_ReachingGoalTFR         = 'Reaching_a_goal_for_total_fertility_rate'
FP_Help_PostAbortionCare        = 'Post_abortion_care'
FP_Help_RelativeRisk            = 'fertility_relative_risk'

FP_EasyAWarning  = 1
FP_EasyABWarning = 2
FP_EasyBWarning  = 3
FP_EasyCWarning  = 4


# FPEdFm glow button constants 
FP_configBtn     = 1
FP_methodMixBtn  = 2
FP_GoalBtn       = 3
FP_PACBtn        = 4
FP_RelRiskBtn    = 5
FP_policyBtn     = 6
FP_ResultsBtn    = 7


# #EasyFamplan tags
# FP_countryCodeTag   = 'Code'
# #
# FP_countryCodeTag_1   = 'ISO'
# FP_countryCodeTag_2   = 'Country Code'

# FP_countryNameTag   = 'Country'
# FP_surveyYrTag      = 'Year'
# FP_SterilityTag     = 'Childless Women ages 45-49 (Sterility)'
# #
# FP_SterilityTag_1     = 'Childless Women45-49(Sterility)'
# FP_SourceTag        = 'Group'#'source'
# FP_PillStandardTag  = 'Pill (standard)'
# FP_PillProgestinTag = 'Pill (progestin only)l'
# FP_PillPCTag        = 'Pill (PCC)'
# FP_IUDCopperTag     = 'IUD (Copper T, 10 years)'
# FP_IUDLNGTag        = 'IUD (LNG-IUS 5 years)'
# FP_InjDepoTag       = 'Injection (Depo 3 months default)'
# #                       Injectable(Depo3months default)
# FP_InjDepoTag_1       = 'Injectable(Depo3months default)'
# FP_InjNoristeratTag = 'Injectable(Noristerat 2 months)'
# FP_InjLunelleTag    = 'Injectable(Lunelle 1 months)'
# FP_Inj6monthTag     = 'Injectable(6 month)'
# FP_InjUnijectTag    = 'Injectable (Uniject)'
# FP_CondomMaleTag    = 'Condom (Male)'
# FP_CondomFemTag     = 'Condom (Female)'
# FP_SterilFemTag     = 'Sterilization (Female)'
# FP_SterilMaleTag    = 'Sterilization (Male)'
# FP_ImpJadelleTag    = 'Implant (Jadelle 5 years default)'
# #
# FP_ImpJadelleTag_1    = 'Implant(Jadelle 5years Default)'
# FP_ImpImplanonTag   = 'Implant (Implanon 3 years)'
# FP_ImpSinoTag       = 'Implant (Sino-Implant 4 years)'
# FP_LAMTag           = 'Fertility Awaremeness (Amenorrhea (LAM))'
# #
# FP_LAMTag_1           = 'Fertility Awaremeness (LAM)'
# FP_SDMTag           = 'Fertility Awareness (SDM)'
# FP_DiaphramTag      = 'Vaginal Barrier (Diaphragm)'
# FP_SpermicTageTag   = 'Vaginal Barrier (Foam or Jelly, Spermicides)'
# #
# FP_SpermicTage_1      = 'VaginalBarrier(FoamSpermicides)'
# FP_TradOtherTag     = 'Traditional (Other)'
# FP_WithdrawalTag    = 'Traditional (Withdrawal)'
# FP_PeriodicTag      = 'Traditional (Periodic Abstenance)'
# #
# # FP_PeriodicTag_1      = 'Traditional(PeriodicAbstinence)'  # Rhythm
# FP_PeriodicTag_1      = 'Traditional(PeriodicAbstinence)'



# FP_OtherMethTag     = 'Other Modern'
# FP_unionPercTag     = 'In Union (Curr. Married + Living togthr)'
# #
# FP_unionPercTag_1     = 'In Union'
# FP_PPITag           = 'PPI Median Duration'
# FP_unmetNeedTag     = 'Unmet need'
# FP_abortPercTag     = 'Abortions per unwanted pregnancy'
# #                         Proportion of unintended pregnancies terminated by abortion
# FP_abortPercTag_1     = 'Proportion of unintended pregnancies terminated by abortion'
# #  FP_unmetSrcTag      = 'Unmet need data sources (see "Unmet Need" tab for codes)'
# #
# #  FP_unmetSrcTag_1      = 'Unmet need data sources'
# FP_RiskYearTag      = 'RiskYear'
# FP_MAL18FirstBirthTag  = 'MA<18 & First Birth'
# FP_MAL18BO2_3Tag    = 'MA<18 & BO2_3'
# FP_MAL18BOG3Tag     = 'MA<18 & BO>3'
# FP_MA18_34FirstBirthTag  = 'MA18_34 & First Birth'
# FP_MA18_34BO2_3Tag  = 'MA18_34 & BO2_3'
# FP_MA18_34BOG3Tag   = 'MA18_34 & BO>3'
# FP_MAG34FirstBirthTag  = 'MA>35 & First Birth'
# FP_MAG34BO2_3Tag    = 'MA>35 & BO2_3'
# FP_MAG34BOG3Tag     = 'MA>35 & BO>3'
# FP_BOFirstBirthTag  = 'FirstBirth Interval'
# FP_BOlt18Tag        = '<18Months'
# FP_BO18_24Tag       = '<24Months'
# FP_BOgt24Tag        = '24 monthers or Greater'
# FP_houseHoldSizeTag = 'Household Size'
# FP_houseHoldSrcTag  = 'Household size source'
# FP_AnyFertilRiskTag = 'Any fertility risk'
# FP_MainDataSource   = 'Main data sources and references (refer to citations tab)'
# FP_MMRTag           = 'MMR'
# #
# FP_MainDataSource_1   = 'Main data sources(citationsTab)'


# FP_UnintendedPregTag  = 'Proportion of unintended pregnancies terminated by abortion'
# FP_UnsafeAbortMMRTag  = 'Ratio Unsafe abortion MMR to MMR'
# FP_UnsafeAbortionsTag = 'Proportion of abortions that are unsafe'
# FP_CPRTag             = 'CPR'
# FP_TARTag             = 'TAR'
# #
# FP_TheRestTag         = 'The Rest'
# #
# FP_SingleYearDataTag         = 'Single Year Data'

# FP_EffectivenessTag          = 'Effectiveness'

FP_MaxEditorVal = 999999999999999 #999 trillion

# Modes 
FP_StandardMode   = 1 # normal
FP_CWFMode        = 2 # CHOICE Work Flow Scenario Generator

FP_CWFBaseYrIdx = 1
FP_CWFTargYrIdx = 2
FP_CWF_MaxCPR = 85


FP_Fecundity_constant = (1.08, 1.02, 1.02, 1.03, 1.04, 1.12, 1.33, 1.08)

FP_COUNTRY_PROXY = {
    "BYR" : "UKR", # Belarus	Has data (using Ukraine as proxy)
    "BWP" : "UKR", # Botswana*	Has data (using Ukraine as proxy)
    #Cote d'Ivoire	is this a name issues?
    "KPW" : "MMK", # Dem. People's Republic of Korea	Has data (using Myanmar as proxy)
    "DJF" : "ETB",# Djibouti	Has data (using Ethiopia as proxy)
    # Ecuador	NOT in Database at al????
    "XAF" : "GNF", # Equatorial Guinea	Has data (using Guinea as proxy)
    # Eritrea	NOT in Database at al????
    "GEL" : "AMD", # Georgia	Has data (using  Armenia as proxy)
    "QAR" : "TRY", # Qatar	Has data (using Turkey  as proxy)
    "MKD" : "MDL", # Republic of North Macedonia	Has data (using  Moldova as proxy)
    "WST" : "IDR", # Samoa	Has data (using Indonesia  as proxy)
    "SAR" : "TRY", # Saudi Arabia	Has data (using Turkey  as proxy)
    "SBD" : "IDR", # Solomon Islands	Has data (using Indonesia  as proxy)
    "SSP" : "UGX", # South Sudan	Has data (using Uganda  as proxy)
    # Sri Lanka	NOT in Database at al????
    "SYP" : "TRY", # Syrian Arab Republic	Has data (using Turkey  as proxy)
    # Thailand*	Missing data- look to see who their proxie is
    "AED" : "TRY", # United Arab Emirates	Has data (using Turkey  as proxy)
    "VUV" : "IDR"# Vanatu	Has data (using Indonesia  as proxy)

}