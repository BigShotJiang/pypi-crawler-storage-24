IV_GROUP_TYPE = 1
IV_SUBGROUP_TYPE = 2

# Database latest versions. We need to have different versions for each app or else we would have to upload
# all databases each time they change.
IV_IH_INTERVENTION_DB_CURR_VERSION = "V26"
IV_IH_GROUP_DB_CURR_VERSION = "V7"

IV_TI_INTERVENTION_DB_CURR_VERSION = "V18"
IV_TI_GROUP_DB_CURR_VERSION = "V5"

IV_CS_INTERVENTION_DB_CURR_VERSION = "V22"
IV_CS_GROUP_DB_CURR_VERSION = "V2"

# Database names (also the names of the sheets in IVModData.xlsx)
IV_INTERVENTION_DB_NAME = "InterventionDB"
IV_GROUP_DB_NAME = "GroupDB"
