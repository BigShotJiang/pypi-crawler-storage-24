from SpectrumCommon.Const.IH import *
from SpectrumCommon.Const.IC import *

# IH 

IV_IH_NUM_DEFAULT_DELIV_CHANS_COSTED = IH_NUM_DEFAULT_DELIV_CHANS_COSTED

# IC

IV_IC_CS_IMPACT                    = IC_CS_IMPACT                     
IV_IC_AM_IMPACT                    = IC_AM_IMPACT                     
IV_IC_RN_IMPACT                    = IC_RN_IMPACT                     
IV_IC_FP_IMPACT                    = IC_FP_IMPACT                     
IV_IC_TB_IMPACT                    = IC_TB_IMPACT                     
IV_IC_MA_IMPACT                    = IC_MA_IMPACT                     
IV_IC_NC_IMPACT                    = IC_NC_IMPACT                     
IV_IC_IS_PROG_MGMT                 = IC_IS_PROG_MGMT                  
IV_IC_RN_PC_HIV                    = IC_RN_PC_HIV                     
IV_IC_RN_STIS                      = IC_RN_STIS                       
IV_IC_NOT_DELIV_MAIN_CHANNELS      = IC_NOT_DELIV_MAIN_CHANNELS       
IV_IC_BREAST_CANCER_TREATMENT      = IC_BREAST_CANCER_TREATMENT       
IV_IC_TB_NOTIF_TREATMENT           = IC_TB_NOTIF_TREATMENT            
IV_IC_CS_CHILDBIRTH                = IC_CS_CHILDBIRTH                 
IV_IC_PREG_WOMEN_MALARIA           = IC_PREG_WOMEN_MALARIA            
IV_IC_ITN_IRS_MALARIA              = IC_ITN_IRS_MALARIA               
IV_IC_MALARIA_PSEUDO_IMPACT        = IC_MALARIA_PSEUDO_IMPACT         
IV_IC_ART_SET_1                    = IC_ART_SET_1                     
IV_IC_ART_SET_2                    = IC_ART_SET_2                     
IV_IC_PC_MNS                       = IC_PC_MNS                        
IV_IC_NC_CANCER                    = IC_NC_CANCER                     
IV_IC_BASIC_INTENS_DEPRESSION      = IC_BASIC_INTENS_DEPRESSION       
IV_IC_BASIC_INTENS_PSYCHOSIS       = IC_BASIC_INTENS_PSYCHOSIS        
IV_IC_BASIC_INTENS_BIPOLAR         = IC_BASIC_INTENS_BIPOLAR          
IV_IC_BASIC_INTENS_DEV_DISORDERS   = IC_BASIC_INTENS_DEV_DISORDERS    
IV_IC_BASIC_INTENS_BEHAV_DISORDERS = IC_BASIC_INTENS_BEHAV_DISORDERS  
IV_IC_PENTA_VACC                   = IC_PENTA_VACC                    
IV_IC_CS_STANDARD_VACC             = IC_CS_STANDARD_VACC              
IV_IC_CS_DET_VACC                  = IC_CS_DET_VACC                   
IV_IC_DEV_MODE_VACC                = IC_DEV_MODE_VACC                 
IV_IC_BREAST_CANCER_TR_PINS        = IC_BREAST_CANCER_TR_PINS         
IV_IC_WORKERS_HEALTH               = IC_WORKERS_HEALTH                
IV_IC_ADOLESCENT_HEALTH            = IC_ADOLESCENT_HEALTH             
IV_IC_TB_DAT_DISAG                 = IC_TB_DAT_DISAG                  
IV_IC_TB_DAT_AG                    = IC_TB_DAT_AG                     
IV_IC_PHC                          = IC_PHC                           
IV_IC_ALT_COVERAGE                 = IC_ALT_COVERAGE        
IV_IC_HIDE_CONFIG                  = IC_HIDE_CONFIG
IV_IC_HIDE_INPUT_OUTPUT_DATA       = IC_HIDE_INPUT_OUTPUT_DATA
IV_IC_HIDE_INPUT_DATA              = IC_HIDE_INPUT_DATA
IV_IC_HIDE_PINS                    = IC_HIDE_PINS                     
IV_IC_HIDE_TARG_POPS               = IC_HIDE_TARG_POPS                
IV_IC_HIDE_COVERAGES               = IC_HIDE_COVERAGES       
IV_IC_LOCK_COVERAGES               = IC_LOCK_COVERAGES         
IV_IC_HIDE_TREAT_INPUTS            = IC_HIDE_TREAT_INPUTS             
IV_IC_HIDE_DELIV_CHANNELS          = IC_HIDE_DELIV_CHANNELS           
IV_IC_HIDE_RESULTS                 = IC_HIDE_RESULTS                  
IV_IC_CALC_PINS_ALL_YEARS_LOCKED   = IC_CALC_PINS_ALL_YEARS_LOCKED    
IV_IC_CALC_PINS_ALL_YEARS_OVERRIDE = IC_CALC_PINS_ALL_YEARS_OVERRIDE  
IV_IC_CALC_PINS_TWO_PLUS_LOCKED    = IC_CALC_PINS_TWO_PLUS_LOCKED     
IV_IC_MULTIPLY_PINS_100            = IC_MULTIPLY_PINS_100             
IV_IC_PINS_OVER_100                = IC_PINS_OVER_100                 
IV_IC_MALARIA_PINS                 = IC_MALARIA_PINS                  

IV_IC_WASH_CHAN_CURR_ID             = IC_WASH_CHAN_CURR_ID
IV_IC_OTHER_NON_HEALTH_CHAN_CURR_ID = IC_OTHER_NON_HEALTH_CHAN_CURR_ID
IV_IC_PRIVATE_SECTOR_CHAN_CURR_ID   = IC_PRIVATE_SECTOR_CHAN_CURR_ID
IV_IC_NUM_DELIV_CHANS               = IC_NUM_DELIV_CHANS

IV_IC_NUM_YEAR_ENDPOINTS = IC_NUM_YEAR_ENDPOINTS