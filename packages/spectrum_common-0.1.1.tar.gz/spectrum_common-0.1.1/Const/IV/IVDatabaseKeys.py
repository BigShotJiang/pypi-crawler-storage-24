#######################################################################################################
#                                                                                                     #
#                                       Intervention DB (IDB)                                         #
#                                                                                                     #
#######################################################################################################


# Keys corresponding to columns. Uncomment/add as needed.

# General - Applies to each module.

IV_ROOT_CONSTANT_KEY_IDB   = 'rootConstant'
IV_MST_ID_KEY_IDB          = 'mstID'
IV_MODULES_KEY_IDB         = 'modMstIDs'
IV_MODULES_ENGLISH_KEY_IDB = 'modCodes'       # just for readability; not used

# For repeated blocks for each module (IHT, TB Costing, LiST Costing; shouldn't need different constants for each)

IV_GROUP_ORDER_KEY_IDB      = 'groupOrder'
IV_GROUP_CURR_ID_KEY_IDB    = 'groupCurrID'    # not needed?
IV_GROUP_MST_ID_KEY_IDB     = 'groupMstID'   
IV_SUBGROUP_CURR_ID_KEY_IDB = 'subgroupCurrID' # not needed?
IV_SUBGROUP_MST_ID_KEY_IDB  = 'subgroupMstID' 
IV_INDENTS_KEY_IDB          = 'indents'         # not needed?
IV_STRING_CONSTANT_KEY_IDB  = 'stringConst'
IV_STRING_NUMBER_KEY_IDB    = 'stringNum'  
IV_ENGLISH_STRING_KEY_IDB   = 'englishString' 

# IHT-specific

IV_INTERV_IMPACT_KEY_IDB       = 'impactInterv'

# '<UH - Community default package>' : '',
# '<UH - Outreach default package>'  : '',
# '<UH - Clinic default package>'    : '',
# '<UH - Hospital default package>'  : '',

IV_AVAIL_COMMUNITY_CHAN_KEY_IDB = 'availCommunityChan'
IV_AVAIL_OUTREACH_CHAN_KEY_IDB  = 'availOutreachChan'
IV_AVAIL_CLINIC_CHAN_KEY_IDB    = 'availClinicChan'
IV_AVAIL_HOSPITAL_CHAN_KEY_IDB  = 'availHospitalChan'

IV_PIN_STRING_CONSTANT_KEY_IDB = 'PINStringConst'
IV_PIN_STRING_NUMBER_KEY_IDB   = 'PINStringNum'
IV_TARG_POP_MST_ID_KEY_IDB     = 'targPopMstID'

IV_PERC_DELIV_KEY_IDB = 'percentDelivered'
# IV_PERC_DELIV_COMMUNITY_CURR_YEAR_KEY_IDB         = 'percDelivCommunityCurrYear'
# IV_PERC_DELIV_COMMUNITY_TARG_YEAR_KE_IDBY         = 'percDelivCommunityTargYear'
# IV_PERC_DELIV_OUTREACH_CURR_YEAR_KEY_IDB          = 'percDelivOutreachCurrYear'
# IV_PERC_DELIV_OUTREACH_TARG_YEAR_KEY_IDB          = 'percDelivOutreachTargYear'
# IV_PERC_DELIV_CLINIC_CURR_YEAR_KEY_IDB            = 'percDelivClinicCurrYear'
# IV_PERC_DELIV_CLINIC_TARG_YEAR_KEY_IDB            = 'percDelivClinicTargYear'
# IV_PERC_DELIV_HOSPITAL_CURR_YEAR_KEY_IDB          = 'percDelivHospitalCurrYear'
# IV_PERC_DELIV_HOSPITAL_TARG_YEAR_KEY_IDB          = 'percDelivHospitalTargYear'
# IV_PERC_DELIV_WASH_CURR_YEAR_KEY_IDB              = 'percDelivWASHCurrYear'
# IV_PERC_DELIV_WASH_TARG_YEAR_KEY_IDB              = 'percDelivWASHTargYear'
# IV_PERC_DELIV_OTHER_NON_HEALTH_CURR_YEAR_KEY_IDB  = 'percDelivOtherNonHealthCurrYear'
# IV_PERC_DELIV_OTHER_NON_HEALTH_TARG_YEAR_KEY_IDB  = 'percDelivOtherNonHealthTargYear'
# IV_PERC_DELIV_PRIVATE_SECTOR_CURR_YEAR_KEY_IDB    = 'percDelivPrivateSectorCurrYear'
# IV_PERC_DELIV_PRIVATE_SECTOR_TARG_YEAR_KEY_IDB    = 'percDelivPrivateSectorTargYear'

# # LiST-specific

IV_NUTRITION_CS_KEY_IDB          = 'isNutritionIV'
IV_BIRTH_OUTCOME_CS_KEY_IDB      = 'isBirthOutcomeIV'
IV_INTERV_TYPE_CS_KEY_IDB        = 'intervType'
IV_QUALITY_MODE_CS_KEY_IDB       = 'QualityMode'
IV_OTHER_MODULE_CS_KEY_IDB       = 'FromOtherModule'
IV_M_CS_KEY_IDB                  = 'MaternalEff_ED'
IV_SB_CS_KEY_IDB                 = 'StillbirthEff_ED'
IV_NN_CS_KEY_IDB                 = 'NNEff_ED'
IV_PNN_CS_KEY_IDB                = 'PNNEff_ED'
IV_ADOL_EFF_CS_KEY_IDB           = 'AdolEff_ED'
IV_COVERAGE_CS_KEY_IDB           = 'Coverage_ED'
IV_DISPLAY_CS_KEY_IDB            = 'Display_ED'
IV_MATERNAL_DISPLAY_CS_KEY_IDB   = 'DisplayMat_ED'
IV_STILLBIRTH_DISPLAY_CS_KEY_IDB = 'DisplaySB_ED'
IV_ADOLESCENT_DISPLAY_CS_KEY_IDB = 'DisplayAdol_ED'
IV_VACCINES_BEDNET_CS_KEY_IDB    = 'VaccinesBednet_ED'
IV_IS_STUNT_INTERV_CS_KEY_IDB    = 'isStuntInterv_ED'

# # TIME Econ-specific

IV_SPECIAL_CASES_IH_KEY_IDB = 'specialCases'

#######################################################################################################
#                                                                                                     #
#                                       Group DB (GDB)                                                #
#                                                                                                     #
#######################################################################################################

# Keys corresponding to columns. Uncomment/add as needed.

# General - Applies to each module.

IV_ROOT_CONSTANT_KEY_GDB    = 'rootConstant'
IV_GROUP_MST_ID_KEY_GDB     = 'groupMstID'
IV_SUBGROUP_MST_ID_KEY_GDB  = 'subgroupMstID'
IV_GROUP_CURR_ID_KEY_GDB    = 'groupCurrID' 
IV_SUBGROUP_CURR_ID_KEY_GDB = 'subgroupCurrID'       
IV_ENGLISH_STRING_KEY_GDB   = 'englishString' 
IV_STRING_CONSTANT_KEY_GDB  = 'stringConst'     
IV_STRING_NUMBER_KEY_GDB    = 'stringNum'  