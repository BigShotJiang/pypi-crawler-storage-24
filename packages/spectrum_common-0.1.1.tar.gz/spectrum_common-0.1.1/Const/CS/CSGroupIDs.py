CS_IVG_Periconceptual_MST_ID = '1'
CS_IVG_Pregnancy_MST_ID = '4'
CS_IVG_Childbirth_MST_ID = '7'
CS_IVG_Breastfeeding_MST_ID = '13'
CS_IVG_PostnatalPreventive_MST_ID = '14'
CS_IVG_Vaccines_MST_ID = '15'
CS_IVG_PostnatalCurative_MST_ID = '16'
CS_GROUP_MST_IDS = [CS_IVG_Periconceptual_MST_ID, CS_IVG_Pregnancy_MST_ID, CS_IVG_Childbirth_MST_ID, CS_IVG_Breastfeeding_MST_ID, CS_IVG_PostnatalPreventive_MST_ID, CS_IVG_Vaccines_MST_ID, CS_IVG_PostnatalCurative_MST_ID]