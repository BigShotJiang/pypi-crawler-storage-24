# fmt: off
# Database names
DefaultData                             = 'DefaultData'
IVDefaultData                           = 'IVDefaultData'
IVDefaultWHOData                        = 'IVDefaultWHOData'
GNI_Per_Cap                             = 'GNI_Per_Cap'
Readiness                               = 'Readiness'
CSection_Cov                            = 'CSection_Cov'
DiarrShigella                           = 'DiarrShigella'
DefaultWHOData                          = 'DefaultWHOData'
DataByCountry                           = 'DataByCountry'
DBC_DataPoints                          = 'DBC_DataPoints'
RegionData                              = 'RegionData'
SubnatData                              = 'SubnationalData'
SubnatMetaData                          = 'SubnatMetaData'
MissOpData                              = 'MissOpData'

CS_DefaultWHOFlag = 'WHO'
CS_DefaultJHUFlag = 'JHU'

All_Country_DB_Names = [
    DefaultData,
    DefaultWHOData,
    IVDefaultData,
    IVDefaultWHOData,
    SubnatMetaData
]

DBC_DB_Names = [
    GNI_Per_Cap,
    Readiness,
    CSection_Cov,
    DiarrShigella,
    DataByCountry,
    DBC_DataPoints,
    RegionData,
    SubnatData,
    MissOpData
]

DBC_Version = 'V11'
Subnat_Version = 'V4'

# Database versions
latest_DB_Version = {
    DefaultData             : 'V4',
    DefaultWHOData          : 'V4',
    IVDefaultData           : 'V1',
    IVDefaultWHOData        : 'V1',
    GNI_Per_Cap             : 'V3',
    Readiness               : 'V1',
    CSection_Cov            : 'V1',
    DiarrShigella           : 'V2',
    DataByCountry           : DBC_Version,
    DBC_DataPoints          : DBC_Version,
    RegionData              : DBC_Version,
    SubnatData              : Subnat_Version,
    SubnatMetaData          : Subnat_Version,
    MissOpData              : 'V3'
}

CS_Interpolated = 0
CS_Uninterpolated = 1

# Missed opportunities column constants
MO_InterventionTag        = '<Intervention>'
MO_InterventionMstIDTag   = '<Intervention Master ID>'
MO_DelivPointTag          = '<Intervention Type>'
MO_DelivPointMstIDTag     = '<Intervention Type Master ID>'
MO_OutcomeTag             = '<Outcome>'
MO_OutcomeMstIDTag        = '<Outcome Master ID>'
MO_DeathCauseTypeTag      = '<Cause of Death Type>'
MO_DeathCauseTypeMstIDTag = '<Cause of Death Type Master ID>'
MO_DeathCauseTag          = '<Cause of Death>'
MO_DeathCauseMstIDTag     = '<Cause of Death Master ID>'
MO_LivesSavedTag          = '<Number of Lives Saved>'
MO_DeathsTag              = '<Deaths>'
MO_TotDeathsTag           = '<Total Deaths>'
MO_StuntingAvertedTag     = '<Stunting Averted>'
MO_StuntingAvertedIDTag   = '<Stunting Averted ID>'
MO_InterventionCostTag    = '<Intervention Cost>'
MO_BOPreTermSGATag        = '<Suboptimal birth outcomes Pre-term SGA>'
MO_BOPreTermAGATag        = '<Suboptimal birth outcomes Pre-term AGA>'
MO_BOTermSGATag           = '<Suboptimal birth outcomes Term SGA>'
MO_BOLowBirthWeightTag    = '<Suboptimal birth outcomes Low birth weight>'
MO_CountryTag             = '<Country>'
MO_ISOCodeTag             = '<ISO Code>'
MO_BaselineCoverageTag    = '<Baseline Coverage>'
MO_ScaleupCoverageTag     = '<Scaleup Coverage>'

CS_TG_Zeros = '<ZEROS>'

CS_SG_Version = 'V4'

#  Default Constants
CS_Default           = 1
CS_Data              = 2
CS_DefConstFinal     = CS_Data

#  Time constants
CS_FIRST_INDEX       = 1
CS_Min_Year          = 1

CS_EasyListOn        = 0

CS_Coverage = 0
CS_RetroCov = 1
CS_Quality  = 2

                    #  ______________________________
                    # /                               \
                    # /             Results             \
                    # /_____/_________________\_________o_\
                    # \_____\_________________|___________/ 


CS_ShowAdol = False

#  Input Constants
#  General constant
# { Either efficacy, odds ratio, relative risk is used }
CS_Efficacy                 = 1
CS_OddsRatio                = 1
CS_RelRisk                  = 1
CS_AffecFract               = 2
CS_AdjustedRR               = 3
CS_EfficacyFinal            = CS_AdjustedRR

#  Endpoints for CSUA
CS_MinEndPoint              = 1
CS_MaxEndPoint              = 2

#  Age Constants
#  [Standard] age cohorts
CS_AgeSummary               = 0
CS_Birth                    = 0
CS_0t1months                = 1
CS_1t6months                = 2
CS_6t12months               = 3
CS_12t24months              = 4
CS_24t60months              = 5

CS_AgeCat_Map_Str = {
    CS_Birth       : 'Birth',
    CS_0t1months   : '0 to 1 months',
    CS_1t6months   : '1 to 6 months',
    CS_6t12months  : '6 to 12 months',
    CS_12t24months : '12 to 24 months',
    CS_24t60months : '24 to 60 months'
}

CS_FirstAgeCohort           = CS_0t1months
CS_NumAgeCohorts            = CS_24t60months

#  Additional age cohorts - for detailed vaccines
CS_24t36months              = 6
CS_36t48months              = 7
CS_48t60months              = 8

CS_NumExtraAgeCohorts       = CS_48t60months

CS_0months                  = 0
CS_1months                  = 1
CS_6months                  = 2
CS_12months                 = 3
CS_24months                 = 4
CS_60months                 = 5

#  Adolescent Age Constants
CS_5yrs_9yrs                = 1
CS_10yrs_14yrs              = 2
CS_15yrs_19yrs              = 3
CS_NumAdolAgeCohorts        = CS_15yrs_19yrs

#  Years
CS_0t1Yr                    = 0
CS_1t2Yr                    = 1
CS_2t3Yr                    = 2
CS_3t4Yr                    = 3
CS_4t5Yr                    = 4
CS_5t6Yr                    = 5

#  Every 6 mos
CS_0mos                     = 0
CS_6mos                     = 1
CS_12mos                    = 2
CS_18mos                    = 3
CS_24mos                    = 4
CS_30mos                    = 5
CS_36mos                    = 6
CS_42mos                    = 7
CS_48mos                    = 8
CS_54mos                    = 9
CS_60mos                    = 10

#  Discount rate
CS_3Perc                    = 0
CS_5Perc                    = 1
CS_10Perc                   = 2
CS_DiscRateFinal            = CS_10Perc

#  Nutritional Deficiencies
CS_VitADefic                = 1
CS_FirstNutDef              = CS_VitADefic
CS_ZincDefic                = 2
CS_CalcDefic                = 3
CS_FolDefic                 = 4
CS_IronDefic                = 5
CS_VitB6Defic               = 6
CS_VitB12Defic              = 7
CS_VitCDefic                = 8
CS_CoppDefic                = 9
CS_MagDefic                 = 10
CS_NiaDefic                 = 11
CS_PhosDefic                = 12
CS_RiboDefic                = 13
CS_ThiaDefic                = 14
CS_FinalNutDef              = CS_ThiaDefic

#  Anemia among women of reproductive age (WRA)
CS_Preg_Anemia              = 1
CS_NonPreg_Anemia           = 2
CS_Preg_IronDeficAnemia     = 3
CS_NonPreg_IronDeficAnemia  = 4
CS_MaxMaternalAnemia        = 4

CS_WRA_Anemia           = 2 #//used for results since the values displayed are for WRA, not just non-pregnant women
CS_WRA_IronDeficAnemia  = 4 #//used for results since the values displayed are for WRA, not just non-pregnant women
CS_WRAAnemiaFinal       = CS_WRA_IronDeficAnemia


CS_PREG_NAMES = {
        CS_Preg_Anemia          : 'Pregnant with anemia',
        CS_WRA_Anemia           : 'WRA with anemia',
        CS_Preg_IronDeficAnemia : 'Pregnant with iron deficiant anemia',
        CS_WRA_IronDeficAnemia  : 'WRA with iron deficiant anemia',
}

#  Baseline mort risk constants
CS_Base1t5monthsMRisk           = 1
CS_Base6t11monthsMRisk          = 2
CS_MaxBaseMortRisk              = 2

#  Mortality rate constants
CS_NeonatalMR               = 1
CS_InfantMR                 = 2
CS_U5MR                     = 3
CS_MaxBaselineMort          = 3

#  Percent of child deaths by proximate causes constants
CS_Neonatal = 1
CS_PostNN   = 2

#  Poverty/food security constants
CS_FoodInsecure = 1
CS_PerPopBelow1 = 2

#  Get/SetCSIndData use the value below
CS_MaternalMRatio           = CS_MaxBaselineMort + 1
CS_MaternalMRate            = CS_MaxBaselineMort + 2

#  Breastfeeding constants
CS_ExclusiveBF              = 1
CS_PredominantBF            = 2
CS_PartialBF                = 3
CS_NotBF                    = 4
CS_MaxBFType                = 4

#  Measles vaccine coverage constants
CS_MCV1Cov                 = 1
CS_MCV2Cov                 = 2
CS_SIACov                  = 3
CS_MaxDetMeasCov           = 3

#  Since SIA coverage needs to go back 4 years before LiST base year, we
# have a separate array for the early coverage and these constants will be
# used to access the coverage
CS_DetVacc4YrsRetro        = 4
CS_DetVacc3YrsRetro        = 3
CS_DetVacc2YrsRetro        = 2
CS_DetVacc1YrsRetro        = 1
CS_DetVaccRetroOffset      = 4
CS_LastDetVaccRetroYr      = CS_DetVacc4YrsRetro

#  Bounds for the standard retro array.
CS_RetroFirstIdx = CS_Min_Year - 4
CS_RetroFinalIdx = 0

#  Vaccine doses
CS_VaccDoseZero   = 0
CS_FirstVaccDose  = CS_VaccDoseZero
CS_VaccDoseOne    = 1
CS_VaccDoseTwo    = 2
CS_VaccDoseThree  = 3
CS_VaccBooster    = 4
CS_MaxVaccDose    = CS_VaccBooster

#  Supplemental doses
CS_SuppVaccDoseOne = 1
CS_SuppVaccDoseTwo = 2

#  Vaccine sector data
# // Coverage percentage constants     Old min and max 1 - 11
CS_MinPercCov               = 1
CS_0PercCov                 = 1
CS_5PercCov                 = 2
CS_10PercCov                = 3
CS_15PercCov                = 4
CS_20PercCov                = 5
CS_25PercCov                = 6
CS_30PercCov                = 7
CS_35PercCov                = 8
CS_40PercCov                = 9
CS_45PercCov                = 10
CS_50PercCov                = 11
CS_55PercCov                = 12
CS_60PercCov                = 13
CS_65PercCov                = 14
CS_70PercCov                = 15
CS_75PercCov                = 16
CS_80PercCov                = 17
CS_85PercCov                = 18
CS_90PercCov                = 19
CS_95PercCov                = 20
CS_100PercCov               = 21
CS_MaxPercCov               = 21

#  Herd constants - change with great risk, it might mess up CSDataRW
#  There are 3 "constants" categories that need consideration: Detailed vaccines(below),
#     Herd vaccines, Current ID from IVConst.Inc
CS_FirstVacc_Herd      = 1
CS_Rotavirus_Herd      = 1
CS_Measles_Herd        = 2
CS_Hib_Herd            = 3
CS_Pneumococcal_Herd   = 4
CS_MeningococcalA_Herd = 5
CS_DPT_Herd            = 6
CS_Bednets_Herd        = 7
CS_DiarVaccPathB_Herd  = 8
CS_DiarVaccPathC_Herd  = 9
CS_Malaria_Herd        = 10
CS_VaccineD_Herd       = 11
CS_VaccineE_Herd       = 12
CS_VaccineF_Herd       = 13
CS_LastVacc_Herd       = 13

#  Detailed vaccines
#  There are 3 "constants" categories that need consideration: Detailed vaccines,
#     Herd vaccines(above), Current ID from IVConst.Inc
CS_BCG_Det          = 1                                                      #//Jared 5/23/17 changed these around a bit.
CS_FirstVacc_Det    = CS_BCG_Det
CS_Polio_Det        = 2
CS_DPT_Det          = 3
CS_HiB_Det          = 4
CS_HepB_Det         = 5
CS_PCV_Det          = 6
CS_Rota_Det         = 7
CS_MenA_Det         = 8
CS_Malaria_Det      = 9
CS_Meas_Det         = 10
CS_LastRegVacc_Det  = CS_Meas_Det
CS_VaccB_Det        = 11
CS_VaccC_Det        = 12
CS_VaccD_Det        = 13
CS_VaccE_Det        = 14
CS_VaccF_Det        = 15
CS_LastVacc_Det     = CS_VaccF_Det

# ***************************   Pathogens   ********************************)

#  Constants for distribution of pathogens among incident, fatal, and all cases.
CS_Distr_All      = 1
CS_Distr_Sevr     = 2
CS_Distr_Fatal    = 3
CS_Distr_Final    = CS_Distr_Fatal

#  Diarrhea

#     CS_AllPathsDiar is used to save data for all pathogens combined.
#     If you don't need to save data for all pathogens combined, loop
#     from CS_FirstPathDiar to CS_NumPathsDiar. Otherwise, loop from
#     CS_FirstPathDiar to CS_MaxPathDiar. Likewise for pneumonia and
#     meningitis.
CS_RotaPathDiar   = 1
CS_FirstPathDiar  = CS_RotaPathDiar
CS_PathBDiar      = 2
CS_PathCDiar      = 3
CS_OtherPathsDiar = 4
CS_NumPathsDiar   = CS_OtherPathsDiar
CS_AllPathsDiar   = 5
CS_MaxPathDiar    = CS_AllPathsDiar

#  Pneumonia 
CS_HibPathPneumVT     = 1
CS_FirstPathPneum     = CS_HibPathPneumVT
CS_PneumocPathPneum   = 2
CS_PneumocPathPneumVT = 3
CS_OtherPathsPneum    = 4
CS_NumPathsPneum      = CS_OtherPathsPneum
CS_AllPathsPneum      = 5
CS_MaxPathPneum       = CS_AllPathsPneum

#  Pneumonia Extract Only (combine vt and non-vt's) 
CS_HibPathPneumExOnly     = 1
CS_FirstPathPneumExOnly   = CS_HibPathPneumExOnly
CS_PneumocPathPneumExOnly = 2
CS_OtherPathsPneumExOnly  = 3
CS_NumPathsPneumExOnly    = CS_OtherPathsPneumExOnly
CS_AllPathsPneumExOnly    = 4
CS_MaxPathPneumExOnly     = CS_AllPathsPneumExOnly

#  Meningitis
CS_HibPathMeninVT       = 1
CS_FirstPathMenin       = CS_HibPathMeninVT
CS_PneumocPathMenin     = 2
CS_PneumocPathMeninVT   = 3
CS_MeningitPathMenin    = 4
CS_MeningitAPathMeninVT = 5
CS_OtherPathsMenin      = 6
CS_NumPathsMenin        = CS_OtherPathsMenin
CS_AllPathsMenin        = 7
CS_MaxPathMenin         = CS_AllPathsMenin

#  Meningitis Extract Only (combine vt and non-vt's)
CS_HibPathMeninExOnly       = 1
CS_FirstPathMeninExOnly     = CS_HibPathMeninExOnly
CS_PneumocPathMeninExOnly   = 2
CS_MeningitPathMeninExOnly  = 3
CS_OtherPathsMeninExOnly    = 4
CS_NumPathsMeninExOnly      = CS_OtherPathsMeninExOnly
CS_AllPathsMeninExOnly      = 5
CS_MaxPathMeninExOnly       = CS_AllPathsMeninExOnly

#  Other
CS_Pneumococcus_OtherPath = 1
CS_Max_OtherPath          = 1

#  Diarrheal incidence reduction interventions. Each one of these corresponds
#     with an intervention from the IV module. Also used for severe diarrhea
#     cases averted.
CS_BasicSanitation_DiarInterv         = 1  #// CS_IV_BasicSanitation
CS_FirstDiarInterv                    = CS_BasicSanitation_DiarInterv
CS_PointOfUseFilteredWater_DiarInterv = 2  #// CS_IV_PointOfUseFilteredWater
CS_PipedWater_DiarInterv              = 3  #// CS_IV_PipedWater
CS_HandWashWSoap_DiarInterv           = 4  #// CS_IV_HandWashWSoap
CS_HygDisposalStools_DiarInterv       = 5  #// CS_IV_HygDisposalStools
CS_ZincP_DiarInterv                   = 6  #// CS_IV_ZincP
CS_VitAPTwoDoses_DiarInterv           = 7  #// CS_IV_VitASupp
CS_RotavirusVacc_DiarInterv           = 8  #// CS_IV_RotavirusVacc
CS_FirstVacc_DiarInterv               = CS_RotavirusVacc_DiarInterv
CS_DiarVaccPathB_DiarInterv           = 9  #// CS_IV_DiarVaccPathB
CS_DiarVaccPathC_DiarInterv           = 10 #// CS_IV_DiarVaccPathC
CS_BFPromotion_DiarInterv             = 11 #// CS_IV_ChangesInBF
CS_NumDiarIntervs                     = CS_BFPromotion_DiarInterv

#  Set of diarrhea incidence reduction interventions that are
#     only available in detailed vaccine mode.
CS_DiarIntervDetVaccModeSet = [CS_DiarVaccPathB_DiarInterv,
CS_DiarVaccPathC_DiarInterv]

#  Severe diarrheal incidence reduction interventions. Each one of these
#     corresponds with an intervention from the IV module. Used by the
#     Effectiveness of interventions on incidence --> Impacts on diarrhea
#     incidence editor only.*)
CS_RotavirusVacc_SevDiarInterv = 1
CS_FirstSevDiarInterv          = CS_RotavirusVacc_SevDiarInterv
CS_NumSevDiarIntervs           = CS_RotavirusVacc_SevDiarInterv

#  Pneumonia incidence reduction interventions. Each one of these corresponds
#     with an intervention from the IV module.
CS_HibVacc_PneumInterv   = 1 #// CS_IV_HibVacc
CS_FirstPneumInterv      = CS_HibVacc_PneumInterv
CS_PneumVacc_PneumInterv = 2 #// CS_IV_PneumVacc
CS_ZincP_PneumInterv     = 3 #// CS_IV_ZincP
CS_NumPneumIntervs       = CS_ZincP_PneumInterv

#  Meningitis incidence reduction interventions. Each one of these corresponds
#     with an intervention from the IV module.
CS_HibVacc_MeningInterv   = 1 #// CS_IV_HibVacc
CS_FirstMeningInterv      = CS_HibVacc_MeningInterv
CS_PneumVacc_MeningInterv = 2 #// CS_IV_PneumVacc
CS_MeningA_MeningInterv   = 3 #// CS_IV_MeningA
CS_NumMeningIntervs       = CS_MeningA_MeningInterv

#  Reduction in mortality by intervention display constants
CS_CovIncIntervPrgm        = 1
CS_PercRedU5MortDueInterv  = 2
CS_PercU5MortRedAttrInterv = 3
CS_ReducInMortFinal        = CS_PercU5MortRedAttrInterv

#  Impacts on stunting constant
#  Constants for the direct entry of stunting
CS_ImpactsOnStunting        = 1.0000
CS_StuntMatrixOn            = 1.0000

#  Impact of IUGR/Low birth weight on stunting 
CS_ImpactsOnStuntingFirst     = 1
CS_LowBirthWeight_TermAGA     = 1
CS_LowBirthWeight_TermSGA     = 2
CS_LowBirthWeight_PreTermAGA  = 3
CS_LowBirthWeight_PreTermSGA  = 4

#  Impact of previous stunting on stunting
# //Swapped these two so positive would be first.
CS_NotStuntedPrevAge          = 5
CS_StuntedPrevAge             = 6

#  Impact of complementary feeding on stunting
#     These same constants are used for impact of compementary feeding on wasting
#     as well even though there is a gap between the last constant for wasting,
#     CS_ImpactsOnWaste_TreatMAM and CS_FoodSecureWPromo, this gap can be saved for
#     future use do if the LiST folks decide that the other items impacting stunting
#     also need to impact wasting
CS_FoodSecureWPromo           = 7
CS_FoodSecureWOPromo          = 8
CS_InsecureWPromoSupp         = 9
CS_InsecureWOPromoSupp        = 10

#  Impact of diarrhea on stunting
CS_ImpDiarrPerEpisode         = 11

#  Impact of zinc supplementation on stunting
CS_ZincSupp                   = 12
CS_NotZincSupp                = 13
CS_ImpactsOnStuntingFinal     = 14

#  Impacts on Wasting Editor constants
CS_ImpactsOnWaste_Therafeed                            = 1          #//treatment for severe wasting
CS_ImpactsOnWaste_FractionChildrenMovMildWastWithTreat = 2          #//treatment for moderate wasting

#  Custom intervention comment

#  note that 7-10 from above

CS_ImpactsOnWaste_FractionChildrenMovModWastWithTreat = 11
CS_ImpactsOnWaste_FractionChildrenMovSevWastWithTreat = 12
CS_ImpactsOnWaste_MAX                                 = CS_ImpactsOnWaste_FractionChildrenMovSevWastWithTreat

#  Impacts on Wasting CSProj constants
CS_ImpactsOnWaste_All                               = 0
CS_ImpactsOnWaste_CompFeed                          = 3
CS_ImpactsOnWaste_Severe                            = 1
CS_ImpactsOnWaste_Moderate                          = 2
CS_ImpactsOnWaste_OverallReducSevereWaste           = 0
CS_ImpactsOnWaste_OverallPercRecovRateModerateWaste = 1

#  Constants for the direct entry of wasting
CS_ImpactsOnWasting        = 0.0000

#  Impacts on maternal anemia constants
CS_IronFolatePW_MatAnemia = 1
CS_MMicroSuppPW_MatAnemia = 2
CS_IronFortNPW_MatAnemia  = 3
CS_IPTP_MatAnemia         = 4
CS_ITN_MatAnemia          = 5
CS_MAX_MatAnemia          = 5

CS_Preg     = 1
CS_NonPreg  = 2
CS_PregFinal = CS_NonPreg

#  Cause of death types
CS_CoD_NNPostNN     = 0
CS_FirstCoDType     = CS_CoD_NNPostNN
CS_CoD_Stillbirth   = 1
CS_CoD_Neonatal     = 2
CS_CoD_PostNeonatal = 3
CS_CoD_Maternal     = 4
CS_CoD_Adolescent   = 5
CS_NumCoDTypes      = CS_CoD_Adolescent

#  Stillbirth constants
CS_SB_Antepartum      = 1
CS_SB_FirstSBCause    = CS_SB_Antepartum
CS_SB_Intrapartum     = 2
CS_SB_MaxCauses       = CS_SB_Intrapartum

CS_Adol_HIV             = 1
CS_Adol_FirstCause      = CS_Adol_HIV
CS_Adol_Diarrhoeal      = 2
CS_Adol_Measles         = 3
CS_Adol_Malaria         = 4
CS_Adol_LRI             = 5
CS_Adol_TB              = 6
CS_Adol_Maternal        = 7
CS_Adol_OtherCMPN       = 8
CS_Adol_Congenital      = 9
CS_Adol_Neoplasm        = 10
CS_Adol_Cardiovascular  = 11
CS_Adol_Digestive       = 12
CS_Adol_OtherNCD        = 13
CS_Adol_RTI             = 14
CS_Adol_Drowning        = 15
CS_Adol_NatDis          = 16
CS_Adol_InterpVio       = 17
CS_Adol_CollectVio      = 18
CS_Adol_SelfHarm        = 19
CS_Adol_OtherInj        = 20
CS_Adol_MaxCauses       = CS_Adol_OtherInj

#  Causes of Death (CoD) Constants
# { Do not change order without adjusting PercReductMortStunt,                 }
# { percReductMortWaste, CorrectedAF in CSproj                                 }
# { Must also change CS_TRelRisksStunting (in CSDefs) and all associated loops }
CS_NNDiarr                  = 1
CS_FirstNNDeath             = CS_NNDiarr
CS_NNSepsis                 = 2
CS_NNPneumonia              = 3
CS_NNAsphyxia               = 4
CS_NNPreterm                = 5
CS_NNTetanus                = 6
CS_NNCongen                 = 7
CS_NNOther                  = 8
CS_FinalStdNNDeath          = CS_NNOther
CS_CustomNNCOD1             = 9
CS_FirstCustNNDeath         = CS_CustomNNCOD1
CS_CustomNNCOD2             = 10
CS_CustomNNCOD3             = 11
CS_CustomNNCOD4             = 12
CS_FinalCustNNDeath         = CS_CustomNNCOD4
CS_FinalNNDeath             = CS_CustomNNCOD4
CS_Diarrhea                 = 13
CS_FirstPNNDeath            = CS_Diarrhea
CS_Pneumonia                = 14
CS_Meningitis               = 15
CS_Measles                  = 16
CS_Malaria                  = 17
CS_Pertussis                = 18
CS_AIDS                     = 19
CS_Injury                   = 20
CS_OtherInfecDis            = 21
CS_OtherNCD                 = 22
CS_FinalStdPNNDeath         = CS_OtherNCD
CS_MaxDefDeathCauses        = CS_OtherNCD
CS_CustomPNNCOD1            = 23
CS_FirstCustPNNDeath        = CS_CustomPNNCOD1
CS_CustomPNNCOD2            = 24
CS_CustomPNNCOD3            = 25
CS_CustomPNNCOD4            = 26
CS_FinalCustPNNDeath        = CS_CustomPNNCOD4
CS_MaxDeathCauses           = 26
CS_FinalPostNNDeath         = CS_MaxDeathCauses


CS_Death_Cause_Name = {
    CS_NNDiarr           : 'NNDiarr',
    CS_FirstNNDeath      : 'FirstNNDeath',
    CS_NNSepsis          : 'NNSepsis',
    CS_NNPneumonia       : 'NNPneumonia',
    CS_NNAsphyxia        : 'NNAsphyxia',
    CS_NNPreterm         : 'NNPreterm',
    CS_NNTetanus         : 'NNTetanus',
    CS_NNCongen          : 'NNCongen',
    CS_NNOther           : 'NNOther',
    CS_FinalStdNNDeath   : 'FinalStdNNDeath',
    CS_CustomNNCOD1      : 'CustomNNCOD1',
    CS_FirstCustNNDeath  : 'FirstCustNNDeath ',
    CS_CustomNNCOD2      : 'CustomNNCOD2',
    CS_CustomNNCOD3      : 'CustomNNCOD3',
    CS_CustomNNCOD4      : 'CustomNNCOD4',
    CS_FinalCustNNDeath  : 'FinalCustNNDeath',
    CS_FinalNNDeath      : 'FinalNNDeath',
    CS_Diarrhea          : 'Diarrhea',
    CS_FirstPNNDeath     : 'FirstPNNDeath',
    CS_Pneumonia         : 'Pneumonia',
    CS_Meningitis        : 'Meningitis',
    CS_Measles           : 'Measles',
    CS_Malaria           : 'Malaria',
    CS_Pertussis         : 'Pertussis',
    CS_AIDS              : 'AIDS',
    CS_Injury            : 'Injury',
    CS_OtherInfecDis     : 'OtherInfecDis',
    CS_OtherNCD          : 'OtherNCD',
    CS_FinalStdPNNDeath  : 'FinalStdPNNDeath',
    CS_MaxDefDeathCauses : 'MaxDefDeathCauses',
    CS_CustomPNNCOD1     : 'CustomPNNCOD1',
    CS_FirstCustPNNDeath : 'FirstCustPNNDeath',
    CS_CustomPNNCOD2     : 'CustomPNNCOD2',
    CS_CustomPNNCOD3     : 'CustomPNNCOD3',
    CS_CustomPNNCOD4     : 'CustomPNNCOD4',
}
#  Other neonatal cause of death constants

CS_MaxNumStdNNCOD           = CS_FinalStdNNDeath - CS_FirstNNDeath + 1
CS_MaxNumCustNNCOD          = CS_CustomNNCOD4 - CS_CustomNNCOD1 + 1

#  Other post neonatal cause of death constants
CS_MaxNumStdPNNCOD          = CS_FinalStdPNNDeath - CS_FirstPNNDeath + 1
CS_MaxNumCustPNNCOD         = CS_CustomPNNCOD4 - CS_CustomPNNCOD1 + 1

#  need constants for the GBListBoxFm to determine which COD is being modified.
#     can't use the constants for PNN and NN because their value could change and
#     then old projections wouldn't work. we could use the master IDs, but this just
#     seems to be simpler to do and less confusing. in addition it allows us to use
#     just one ModVar for both PNN and NN since the parameter showing which COD number
#     is being used in the get/set will be the same regardless of whether it is PNN or NN*)
CS_CustomCOD1               = 1
CS_CustomCOD2               = 2
CS_CustomCOD3               = 3
CS_CustomCOD4               = 4
CS_MaxNumCustCOD            = 4

CS_CustomCodNN              = 1           #//ELH
CS_CustomCodPNN             = 2           #//ELH

#  used to determine if a custom COD has been entered into the specific array location.
CS_NotActive                = 0

#  Maternal deaths by cause
CS_Mat_AntepartHemorr       = 1
CS_Mat_MinDeathCauses       = CS_Mat_AntepartHemorr
CS_Mat_IntrapartHemorr      = 2
CS_Mat_PostpartHemorr       = 3
CS_Mat_HypertensiveDis      = 4
CS_Mat_Sepsis               = 5
CS_Mat_Abortion             = 6
CS_Mat_Embolism             = 7
CS_Mat_OtherDirectCauses    = 8
CS_Mat_IndirectCauses       = 9
CS_Mat_MaxDeathCauses       = CS_Mat_IndirectCauses

CS_Mat_Disease_Name = {
    CS_Mat_AntepartHemorr    : 'Maternal AntepartHemorr',
    CS_Mat_MinDeathCauses    : 'Maternal MinDeathCauses',
    CS_Mat_IntrapartHemorr   : 'Maternal IntrapartHemorr',
    CS_Mat_PostpartHemorr    : 'Maternal PostpartHemorr',
    CS_Mat_HypertensiveDis   : 'Maternal HypertensiveDis',
    CS_Mat_Sepsis            : 'Maternal Sepsis',
    CS_Mat_Abortion          : 'Maternal Abortion',
    CS_Mat_Embolism          : 'Maternal Embolism',
    CS_Mat_OtherDirectCauses : 'Maternal OtherDirectCauses',
    CS_Mat_IndirectCauses    : 'Maternal IndirectCauses',
}

CS_Mat_NotAnemic  = 1
CS_Mat_Anemic     = 2
CS_AnemicFinal    = CS_Mat_Anemic

#  used for CS_CalcFractionForDistributingDeathsOrCasesByPathByDisease to know what vaccine eff and AF to use
CS_DeathsProcedure = 1
CS_CasesProcedure  = 2

#  If new deaths are added in between these some editors will be impacted
#  diseases should be diarrhea, pneumonia, malaria, measles
StuntDiseaseSet = [CS_Diarrhea, CS_Pneumonia, CS_Measles,
                    CS_Meningitis, CS_Malaria, CS_OtherInfecDis]

WasteDiseaseSet = [CS_Diarrhea, CS_Pneumonia, CS_Measles,
                    CS_Meningitis, CS_Malaria, CS_OtherInfecDis]

CS_NNDeathCauseSet = [CS_NNAsphyxia, CS_NNPreterm, CS_NNSepsis,
                    CS_NNPneumonia, CS_NNTetanus, CS_NNDiarr,
                    CS_NNCongen, CS_NNOther]

CS_PNNDeathCauseSet = [CS_Diarrhea, CS_Pneumonia,
                        CS_Meningitis, CS_Measles, CS_Malaria, CS_Pertussis,
                        CS_AIDS, CS_Injury, CS_OtherInfecDis, CS_OtherNCD]

CS_CustNNCODSet = [CS_CustomNNCOD1, CS_CustomNNCOD2, CS_CustomNNCOD3,
                    CS_CustomNNCOD4]

CS_CustPNNCODSet = [CS_CustomPNNCOD1, CS_CustomPNNCOD2, CS_CustomPNNCOD3,
                    CS_CustomPNNCOD4]

#  Diseases impacted by complementary feeding, should mirror dimensions of relative risk array
CS_CompFeedDiseases         = [CS_Diarrhea, CS_Pneumonia, CS_Measles,
                                CS_Malaria, CS_OtherInfecDis]

#  Set of diseases broken down by pathogen in LiST
CS_PathDeathCauseSet = [CS_Diarrhea, CS_Pneumonia, CS_Meningitis]

#  Random large number, may be increased if needed
CS_MaxCountryNames            = 200

#  Standard deviation Constants
CS_GT1STD                     = 1
CS_1t2STD                     = 2
CS_2t3STD                     = 3
CS_GT3STD                     = 4
CS_FinalSTD                   = CS_GT3STD

# {* StuntingMatrixYN Constants *}
CS_CalcStuntBaseInterv        = 0
CS_DirectEntryStunting        = 1

#  Constants for Calculations
#  Baseline growth constants
CS_Baseline_Beg = 1
CS_Baseline_End = 2
CS_Baseline_Avg = 3

#  IHO Standards
CS_Mean = 1
CS_SD = 2

#  Configuration options
CS_AgeCohort     = 0
CS_AgeYear       = 1

#  Result constants
#  Keep order the same, unless you are changing in ReadWrite
CS_DeathRateBase   = 1
CS_PDeathsPrevd    = 2
CS_DeathRateWInter = 3

#  AIDS Result Constants
CS_TotalResult    = 0
CS_PMTCTResult    = 1
CS_CotrimResult   = 2
CS_ARTResult      = 3

#  Editor source constants
#  This is used for the sources
#  Do not change these constants, you may add new ones, but deleting or
#  moving existing ones around will cause sources to be misappropriated
CS_MstHealthStatSheetSrcId                = 1
CS_MstStuntingSheetSrcId                  = 2
CS_MstDiarIncSheetSrcId                   = 3
CS_MstBaselineMortSheetSrcId              = 4
CS_MstPerCapitaIncSheetSrcId              = 5
CS_MstPNNEfficacySheetSrcId               = 6
CS_MstNNEfficacySheetSrcId                = 7
CS_MstRelEfficacySheetSrcId               = 8      #// obselete
CS_MstDeathsByCauseSheetSrcId             = 9      #//obselete (split into NN and PNN)
CS_MstPericonceptualSheetSrcId            = 10
CS_MstAntenatalSheetSrcId                 = 11
CS_MstBirthCareSheetSrcId                 = 12
CS_MstImmPostnatalSheetSrcId              = 13
CS_MstPostnatalPSheetSrcId                = 14
CS_MstVaccineSheetSrcId                   = 15
CS_MstPostnatalCSheetSrcId                = 16
CS_MstDelivModeDistSheetSrcId             = 17
CS_MstSingleAgeCoverageSheetSrcId         = 18
CS_MstRelRisksStuntingSheetSrcId          = 19
CS_MstImpactsOnStuntingSheetSrcId         = 20
CS_MstImpactOnIUGRSheetSrcId              = 21    #// obselete
CS_MstImpactBFImproveSheetSrcId           = 22
CS_MstDiarrIncReductionSheetSrcId         = 23
CS_MstRelRisksDiarrheaSheetSrcId          = 24
CS_MstRelRisksIUGR_LBWSheetSrcId          = 25
CS_MstImpactBFOnMortPNNSheetSrcId         = 26
CS_MstPopInNeedSheetSrcId                 = 27     #// obselete
CS_MstUnitCostSheetSrcId                  = 28     #// obselete
CS_MstBreastfeedImproveSheetSrcID         = 29     #// obselete
CS_MstBreastfeedPrevSheetSrcID            = 30
CS_MstMatDeathsByCauseSheetSrcId          = 31
CS_MstMatMortRatioSheetSrcId              = 32
CS_MstAbortIncRatioSheetSrcId             = 33
CS_MstPercPregEndAbortSheetSrcId          = 34
CS_MstMatEfficacySheetSrcId               = 35
CS_MstHerdRotavirusSheetSrcID             = 36
CS_MstHerdMeaslesSheetSrcID               = 37
CS_MstHerdHibSheetSrcID                   = 38
CS_MstHerdPneumococcalSheetSrcID          = 39
CS_MstHerdDPTSheetSrcID                   = 40
CS_MstHerdBednetsSheetSrcID               = 41
CS_MstIPTpSheetSrcID                      = 42
CS_MstWastingSheetSrcID                   = 43
CS_MstImpactsOnWastingSheetSrcID          = 44
CS_MstRelRisksWastingSheetSrcID           = 45
CS_MstStuntingMatrixSheetSrcID            = 46
CS_MstPneumoMeninSheetSrcID               = 47
CS_MstHIBMeninSheetSrcID                  = 48
CS_MstStillbirthRateSheetSrcID            = 49
CS_MstStillbirthsByCauseSheetSrcID        = 50
CS_MstStillbirthEfficacySheetSrcID        = 51
CS_MstDetMeaslesVaccCovSheetSrcID         = 52
CS_MstDetMeaslesVaccEffSheetSrcID         = 53
CS_MstHerdCustomVaccSheetSrcID            = 54
CS_MstBirthSurveyCovSheetSrcID            = 55
CS_MstDelivLevelCovSheetSrcID             = 56
CS_MstDelivLevelIntSheetSrcId             = 57
CS_MstDelivIntCovSheetSrcId               = 58
CS_MstDelEfficacySheetSrcId               = 59
CS_MstMatDelEfficacySheetSrcId            = 60
CS_MstSBDelEfficacySheetSrcId             = 61
CS_MstDetVaccineCovSheetSrcID             = 62
CS_MstDetVaccEfficacySheetSrcId           = 63
CS_MstWastingMatrixSheetSrcID             = 64
CS_MstDeathsByCausePNNSheetSrcId          = 65
CS_MstDeathsByCauseNNSheetSrcId           = 66
CS_MstHerdVaccBSheetSrcID                 = 67
CS_MstHerdVaccCSheetSrcID                 = 68
CS_MstPathIncAllMortSheetSrcID            = 69
CS_MstPneumIncReductionSheetSrcId         = 70
CS_MstRelRisksPneumoniaSheetSrcId         = 71
CS_MstPneumIncSheetSrcId                  = 72
CS_MstAgeAndBirthOrderSheetSrcId          = 73
CS_MstBirthIntervalsSheetSrcId            = 74
CS_MstIntervForBOSheetSrcId               = 75
CS_MstZincSheetSrcId                      = 76    #//obselete
CS_MstVitaminASheetSrcID                  = 77   #//obselete
CS_MstWastingDistrSheetSrcId              = 78
CS_MstStuntingDistrSheetSrcId             = 79
CS_MstAgeAndBirthOrderMatrixSheetSrcId    = 80
CS_MstBirthIntervalsMatrixSheetSrcId      = 81
CS_MstHerdMalariaSheetSrcID               = 82
CS_MstHerdVaccDSheetSrcID                 = 83
CS_MstNutrDefSheetSrcID                   = 84
CS_MstImpactsOnMatAnemiaSheetSrcID        = 85
CS_MstMeningIncReductionSheetSrcId        = 86
CS_MstDeathCauseIncSheetSrcId             = 87
CS_MstRelRisksMeningitisSheetSrcId        = 88
CS_MstImpactsOnSevereWastingSheetSrcID    = 89
CS_MstImpactsOnModerateWastingSheetSrcID  = 90
CS_MstImpactBFOnMortNNSheetSrcID          = 91
CS_MstHSMaternalAnemiaSheetSrcID          = 92
CS_MstOddsRatioAnemiaSheetSrcID           = 93
CS_MstImpactEarlyInitBFSheetSrcID         = 94
CS_MstImpactCompFeedWastingSheetSrcID     = 95
CS_MstLBWFSheetSrcID                      = 96                                     #//Jared 5/4/17
CS_MstMatAnemiaAFSheetSrcID               = 97                                     #//Jared 5/9/17
CS_MstSingleWastingDistrSheetSrcId        = 98                                     #//Jared 5/9/17
CS_MstSingleStuntingDistrSheetSrcId       = 99                                     #//Jared 5/9/17
CS_MstPercWom15t49LowBMISheetSrcID        = 100                                    #//Jared 6/22/17
CS_MstImpactBFOnMortPNNSheet2SrcID        = 101                                    #//Jared 7/14/17
CS_MstAvgHouseholdSizeSheetSrcId          = 102                                    #//Jared 7/14/17
CS_MstPneumIncMortSheetSrcID              = 103 #//obsolete                         //Jared
CS_MstMeniIncMortSheetSrcID               = 104 #//obsolete                         //Jared 7/14/17
CS_MstGNIPerCapSheetSrcId                 = 105
CS_MstLaborForceParRateSheetSrcId         = 106
CS_MstLaborShareIncSheetSrcId             = 107
CS_MstWorkingYearsSheetSrcId              = 108
CS_ReducStuntSheetSrcId                   = 109
CS_EduAttainSheetSrcId                    = 110
CS_MstAdolEfficacySheetSrcId              = 111
CS_MstMatNutrDefSheetSrcID                = 112
CS_MstHerdVaccESheetSrcID                 = 113
CS_MstHerdVaccFSheetSrcID                 = 114
CS_MstMaxEditorSources                    = 114

#  Abortions
CS_TotalAbort               = 1
CS_UnsafeAbort              = 2
CS_SafeAbort                = 3
CS_AbortionFinal            = CS_SafeAbort

#  Max summed indicators -- this can be changed at any time
CS_MaxSummedIndicators      = 10

#  Percent deaths by cause constants
CS_DxC_Default              = 1
CS_DxC_Normalized           = 2
CS_DxC_NoAIDS               = 3
CS_DxC_Final                = CS_DxC_NoAIDS

#  Flipflop constants used in CSProj
#  These are used to handle positive and negative changes in mortality reduction
CS_FPos                     = 1
CS_FNeg                     = 2
CS_FTot                     = 3

#  Constants used in Uncertainty Analysis (LiST)
#  Parameter constants
CS_Min = 1
CS_Max = 2

# *****************************   CS UA   **********************************)

#  General parameters for indicators in CS UA. P1 is always the year and
#     P2 is always the age group, when applicable.
CS_P1     = 1
CS_P2     = 2
CS_P3     = 3
CS_P4     = 4
CS_MaxP   = 4

#  Projection numbers for CS UA
CS_OrP    = 1 #// original; used to make other projections
CS_LoP    = 2 #// low
CS_MeP    = 3 #// median
CS_HiP    = 4 #// high
CS_MnP    = 5 #// mean
CS_SdP    = 6 #// standard deviation

CSUA_DefNum_Iterations     = 400
CSUA_MAX_Iterations        = 1000
CSUA_DefConfInterval       = 0.95
CSUA_NumTrials             = 1000
CSUA_DefProcessTime        = ''

CSUA_RandomSeed = 17 #//Random number for seed, actually a favorite number of Ingrid Friberg
CSUA_RandomSeed2 = 83 #//Random number from Thomas

#  CSUA inputs
CSUA_Coverage             = 1
CSUA_FirstInput           = CSUA_Coverage
CSUA_Effectiveness        = 2
CSUA_MortalityRates       = 3
CSUA_DeathCauses          = 4
CSUA_RelativeRisks        = 5
CSUA_Incidence            = 6
CSUA_ApplyConstraints     = 7
CSUA_MaxInput             = CSUA_ApplyConstraints

#  Calculate components from inputs constants (CCFI).

#     These correspond to checkboxes in the CSedCovfm and are used in
#     conjunction with the <CS - Lock Calc> and <CS - Lock Calc Off> values
#     (from MstIVDB.csv) to determine if certain interventions are locked or
#     not in the coverage editors. Constants affecting
#     multiple interventions are as follows:

#     CS_AntenatalCare_CCFI: Antenatal care checkbox and
#     a) Lock calc off (checkbox is unchecked)
#         CS_IV_ANC4
#     b) Lock calc (checkbox is checked)
#         CS_IV_SyphDetectTr, CS_IV_MicronutrientSupp,
#         CS_IV_DiabetesScreenMan, CS_IV_MgSO4MgmtPreEclampsia

#     CS_Delivery_CCFI: Calculate intervention coverages checkbox and
#     a) Lock calc off (checkbox is unchecked)
#         CS_IV_SkBirthAttend, CS_IV_InstitutDeliv = 36;
#     b) Lock calc (checkbox is checked)
#         CS_IV_CleanPractices, CS_IV_ImmNewbrnAssess, CS_IV_LaborAndDelivMan
#         CS_IV_NeoResusc, CS_IV_AnteCortPretermLabor, CS_IV_AntipPRoM
#         CS_IV_MgSO4MgmtEclampsia, CS_IV_AMTSL, CS_IV_InductionOfLabour

#     CS_Pentavalent_CCFI: Calculate pentavalent components checkbox and
#     a) Lock calc off (checkbox is unchecked)
#         CS_IV_Pentavalent = 66;
#     b) Lock calc (checkbox is checked)
#         CS_IV_DPTVacc, CS_IV_HibVaccm CS_IV_HepBVacc = 69;
#
CS_AntenatalCare_CCFI  = 1
CS_First_CCFI          = CS_AntenatalCare_CCFI
CS_Delivery_CCFI       = 2
CS_Pentavalent_CCFI    = 3
CS_ThermalCare_CCFI    = 4
CS_FSCPrematurity_CCFI = 5
CS_InjectAntib_CCFI    = 6
CS_FSCSepsisPneum_CCFI = 7
CS_VitAMeasTreat_CCFI  = 8
CS_Max_CCFI            = CS_VitAMeasTreat_CCFI

#  Delivery interventions
CS_CleanPractices           = 1
CS_ImmNewbrnAssess          = 2
CS_LaborAndDelivMan         = 3
CS_NeoResusc                = 4
CS_AnteCortSte              = 5
CS_AntipPRoM                = 6
CS_MagnesSulfTrEclampsia    = 7
CS_AMTSL                    = 8
CS_InductionOfLabour        = 9
CS_MaxDelivInts             = 9

#  Birth survey constants
CS_SBA = 1
CS_FacDeliv = 2
CS_MaxBirthSurveyCov = 2

#  Delivery checkbox constants
CS_CalcDelivLevCov      = 1
CS_CalcDelivIntCov      = 2

#  Under sized babies categories
CS_PreTermSGA   = 1
CS_FirstTerm    = CS_PreTermSGA
CS_PreTermAGA   = 2
CS_TermSGA      = 3
CS_TermAGA      = 4
CS_FinalTerm    = CS_TermAGA

#  LBWF region groups
CS_AsiaNorthAfricaMiddleEastEasternEurope = 1
CS_FirstLBWFRegionGroup = CS_AsiaNorthAfricaMiddleEastEasternEurope
CS_SouthWestEastAfrica = 2
CS_LatinAmericaCaribbean = 3
CS_LastLBWFRegionGroup = CS_LatinAmericaCaribbean

#  Interventions for birth outcomes
CS_ConditionalCashTransfer  = 1
CS_FirstIntervForFI         = CS_ConditionalCashTransfer
CS_FoodAssistanceToFamilies = 2
CS_DirectSupport            = 3
CS_FinalIntervForFI         = CS_DirectSupport
CS_FoodShock                = 4 #EPW added to line up with dll
CS_FinalIntervForFIForCalcs = CS_FoodShock

#  Fert-brth outcomes RR's
#  Age and Birth Order
#  Mother's Age
CS_AllYrs       = 1
CS_LT18Yrs      = 2
CS_18_34Yrs     = 3
CS_35_49Yrs     = 4
CS_MA_Final     = CS_35_49Yrs

#  Birth order of child
CS_FirstBirth         = 1
CS_SecAndThirdBirths  = 2
CS_GTThirdBirth       = 3
CS_BO_Final           = CS_GTThirdBirth

#  Birth Intervals
# //CS_FirstBirth     = 1  // use CS_FirstBirth from above
CS_LT18Mths         = 2
CS_18to23Mths       = 3
CS_GE24Mths         = 4
CS_BI_Final         = CS_GE24Mths

#  Interventions for birth outcomes
CS_IPTp                         = 1
CS_FirstIntervForBO             = CS_IPTp
CS_BalEnergy                    = 2
CS_MultMicroLowBMI              = 3
CS_MultMicroNormBMI             = 4
CS_CalciumSupp                  = 5
CS_FolicAcidFort                = 6
CS_ZincFort                     = 7
CS_SyphilisTreat                = 8
CS_IronFolateSupp               = 9
CS_ZincSuppInPreg               = 10
CS_TreatOfBacteriuria           = 11
CS_Omeg3FASupp                  = 12
CS_AspirinLowDose               = 13
CS_Progesterone                 = 14
CS_StopSmokingEduc              = 15
CS_SpareBOInterv1               = 16
CS_SpareBOInterv2               = 17
CS_SpareBOInterv3               = 18
CS_SpareBOInterv4               = 19
CS_FoodInsecBES                 = 20
CS_ITN                          = 21
CS_FirstBOMax                   = CS_ITN
CS_AgeAndBirthOrder             = 22
CS_BirthInterval                = 23
CS_LastBOMax                    = CS_BirthInterval

#  Average % of time spent in age cohort that is spent in the year the child
#     is born. Used in several results.
CS_AvgPercTimeIn1t5AgeCohRate = 45/60
CS_AvgPercTimeIn6t11AgeCohRate = 21/72

#  Supplemental vaccines
CS_SuppCampaignImplemented = 3
CS_SuppGeoCoverage         = 4
CS_AgeGroupSupp            = 5
CS_SuppMinAge              = 6
CS_SuppMaxAge              = 7
CS_SuppDosesPerChild       = 8
CS_SuppPercPopTargeted     = 9
CS_DosesProvidedSupp       = 10

CS_bAuto   = 0
#  User results
CS_bUser   = 1
#  Estimate Bounds
CS_bMin    = 2
CS_bMax    = 3
#  CSUA
CS_bLow    = 4
CS_bMed    = 5
CS_bHigh   = 6
CS_BoundsFinal = CS_bHigh

CS_SG_NoScaleUp     = 0 #// = not using Scenario Generator
CS_SG_ScaleTargPerc = 1
CS_SG_ScalePercPts  = 2

# CS_SG_TemplateURL   = GB_SpectrumDataURL + '/LiST/';
CS_SG_TemplateFName = 'Scenario_Generator_Excel_Template.xlsx'

CS_QualityMode     = 1
CS_DirectEntryMode = 2

CS_QualityInactive = 0
CS_ANC1Mode        = 1
CS_ANC4Mode        = 2
CS_FascDelivMode   = 3

#  These are master ID's and cannot change.
CS_MstBFPrevMode      = 1
CS_MstBFPromotionMode = 2

#  Coverage form modes
CS_StandardMode   = 1 #// normal
CS_SGMode         = 2 #// LiST Scenario Generator
CS_LiSTSubNatView = 3 #// has cooresponding constant in VW
CS_CWFMode        = 4 #// CHOICE Work Flow Scenario Generator

#  Constants reflecting which Wasting/Stunting Editor user wants to display
CS_Single   = 1
CS_Detailed = 2

CS_CWFBaseYrIdx = 1
CS_CWFTargYrIdx = 2

#  Breastfeeding Promotion constants
CS_BFPromoHealthSystem  = 1
CS_BFPromoHomeComm      = 2
CS_BFPromoBoth          = 3
CS_BFPromoFinal         = CS_BFPromoBoth

CS_ImpactPromoBF      = 1
CS_ImpactPromoEarlyBF = 2
CS_ImpactPromoFinal   = CS_ImpactPromoEarlyBF

CS_EarlyInitBF = 1
CS_LateInitBF  = 2
CS_InitBFFinal = CS_LateInitBF

CS_PromotedBF    = 1
CS_NotPromotedBF = 2
CS_PromotionBF   = 1
CS_KangarooBF    = 2

CS_MinFirstYrAtWork = 15
CS_MaxFinalYrAtWork = 80

CS_DefMinFirstYrAtWork = 16
CS_DefMaxFinalYrAtWork = 60

CS_PerCapita = 1
CS_PerWorker = 2
CS_BaselineGDPFinal = CS_PerWorker

CS_Benefits = 1
CS_Costs = 2
CS_CostBenFinal = CS_Costs

CS_SocialValue = 1
CS_PercStillbirthsIncluded = 2
CS_FactorsFinal = CS_PercStillbirthsIncluded

CS_InterventionCosts = 1
CS_ProgramCosts = 2
CS_LogisticsAndWastage = 3
CS_InfrastructureInvest = 4
CS_OtherHealthSysCosts = 5

CS_FirstCostCat = CS_InterventionCosts
CS_FinalCostCat = CS_OtherHealthSysCosts

CS_SocBenSB = 1
CS_SocBenChild = 2
CS_SocBenMat = 3
CS_EarnSB = 4
CS_EarnChild = 5
CS_EarnMat = 6
CS_StuntReducAddEarn = 7

CS_FirstBenefitCat = CS_SocBenSB
CS_FinalBenefitCat = CS_StuntReducAddEarn

#  Special master IDs to be used in tools. Values should be higher than
#     the max default and custom intervention master IDs. There should also
#     be ample space between each set of these ids in case new categories, etc.
#     are developed in the future. Without these master IDs, you'll need some
#     way of identifying standard interventions from special ones, such as a
#     second column of IDs.

#  Breastfeeding prevalence

CS_MstBFExclusive_0t1M   = 10000
CS_MstBFPredominant_0t1M = 10001
CS_MstBFPartial_0t1M     = 10002
CS_MstBFNot_0t1M         = 10003

CS_MstBFExclusive_1t6M   = 10004
CS_MstBFPredominant_1t6M = 10005
CS_MstBFPartial_1t6M     = 10006
CS_MstBFNot_1t6M         = 10007

CS_MstBFAny_6t12M        = 10008
CS_MstBFNot_6t12M        = 10009

CS_MstBFAny_12t24M       = 10010
CS_MstBFNot_12t24M       = 10011

CS_MstEarlyInitBF        = 10012

#  Stunting

CS_MstStunt_GT1Std_LT1M   = 10500
CS_MstStunt_1t2Std_LT1M   = 10501
CS_MstStunt_2t3Std_LT1M   = 10502
CS_MstStunt_GT3Std_LT1M   = 10503

CS_MstStunt_GT1Std_1t5M   = 10504
CS_MstStunt_1t2Std_1t5M   = 10505
CS_MstStunt_2t3Std_1t5M   = 10506
CS_MstStunt_GT3Std_1t5M   = 10507

CS_MstStunt_GT1Std_6t11M  = 10508
CS_MstStunt_1t2Std_6t11M  = 10509
CS_MstStunt_2t3Std_6t11M  = 10510
CS_MstStunt_GT3Std_6t11M  = 10511

CS_MstStunt_GT1Std_12t23M = 10512
CS_MstStunt_1t2Std_12t23M = 10513
CS_MstStunt_2t3Std_12t23M = 10514
CS_MstStunt_GT3Std_12t23M = 10515

CS_MstStunt_GT1Std_24t59M = 10516
CS_MstStunt_1t2Std_24t59M = 10517
CS_MstStunt_2t3Std_24t59M = 10518
CS_MstStunt_GT3Std_24t59M = 10519

CS_MstStunt_GT2StdSingle  = 10520

#  Wasting

CS_MstWast_GT1Std_LT1M   = 11000
CS_MstWast_1t2Std_LT1M   = 11001
CS_MstWast_2t3Std_LT1M   = 11002
CS_MstWast_GT3Std_LT1M   = 11003

CS_MstWast_GT1Std_1t5M   = 11004
CS_MstWast_1t2Std_1t5M   = 11005
CS_MstWast_2t3Std_1t5M   = 11006
CS_MstWast_GT3Std_1t5M   = 11007

CS_MstWast_GT1Std_6t11M  = 11008
CS_MstWast_1t2Std_6t11M  = 11009
CS_MstWast_2t3Std_6t11M  = 11010
CS_MstWast_GT3Std_6t11M  = 11011

CS_MstWast_GT1Std_12t23M = 11012
CS_MstWast_1t2Std_12t23M = 11013
CS_MstWast_2t3Std_12t23M = 11014
CS_MstWast_GT3Std_12t23M = 11015

CS_MstWast_GT1Std_24t59M = 11016
CS_MstWast_1t2Std_24t59M = 11017
CS_MstWast_2t3Std_24t59M = 11018
CS_MstWast_GT3Std_24t59M = 11019

CS_MstWast_GT2StdSingle  = 11020

BF_Set = set([
    CS_MstBFExclusive_0t1M,
    CS_MstBFPredominant_0t1M,
    CS_MstBFPartial_0t1M,
    CS_MstBFNot_0t1M,

    CS_MstBFExclusive_1t6M,
    CS_MstBFPredominant_1t6M,
    CS_MstBFPartial_1t6M,
    CS_MstBFNot_1t6M,

    CS_MstBFAny_6t12M,
    CS_MstBFNot_6t12M,

    CS_MstBFAny_12t24M,
    CS_MstBFNot_12t24M,
])

Stunt_Set = set([
    CS_MstStunt_GT1Std_LT1M,
    CS_MstStunt_1t2Std_LT1M,
    CS_MstStunt_2t3Std_LT1M, 
    CS_MstStunt_GT3Std_LT1M, 
    CS_MstStunt_GT1Std_1t5M, 
    CS_MstStunt_1t2Std_1t5M, 
    CS_MstStunt_2t3Std_1t5M, 
    CS_MstStunt_GT3Std_1t5M, 
    CS_MstStunt_GT1Std_6t11M,
    CS_MstStunt_1t2Std_6t11M,
    CS_MstStunt_2t3Std_6t11M,
    CS_MstStunt_GT3Std_6t11M,
    CS_MstStunt_GT1Std_12t23M,
    CS_MstStunt_1t2Std_12t23M,
    CS_MstStunt_2t3Std_12t23M,
    CS_MstStunt_GT3Std_12t23M,
    CS_MstStunt_GT1Std_24t59M,
    CS_MstStunt_1t2Std_24t59M,
    CS_MstStunt_2t3Std_24t59M,
    CS_MstStunt_GT3Std_24t59M
])

Waste_Set = set([
    CS_MstWast_GT1Std_LT1M,
    CS_MstWast_1t2Std_LT1M,
    CS_MstWast_2t3Std_LT1M,
    CS_MstWast_GT3Std_LT1M,
    CS_MstWast_GT1Std_1t5M,
    CS_MstWast_1t2Std_1t5M,
    CS_MstWast_2t3Std_1t5M,
    CS_MstWast_GT3Std_1t5M,
    CS_MstWast_GT1Std_6t11M,
    CS_MstWast_1t2Std_6t11M,
    CS_MstWast_2t3Std_6t11M,
    CS_MstWast_GT3Std_6t11M,
    CS_MstWast_GT1Std_12t23M,
    CS_MstWast_1t2Std_12t23M,
    CS_MstWast_2t3Std_12t23M,
    CS_MstWast_GT3Std_12t23M,
    CS_MstWast_GT1Std_24t59M,
    CS_MstWast_1t2Std_24t59M,
    CS_MstWast_2t3Std_24t59M,
    CS_MstWast_GT3Std_24t59M
])

#  Delivery Level Coverage

CS_MstDelivLevelCov_Assisted_Home      = 11500                               #//Jared 1/26/18
CS_MstDelivLevelCov_EssentialCare_Fac  = 11501                               #//Jared 1/26/18
CS_MstDelivLevelCov_BEmOC_Fac          = 11502                               #//Jared 1/26/18
CS_MstDelivLevelCov_CEmOC_Fac          = 11503                               #//Jared 1/26/18

#  Essential care interventions

CS_MstDelivIntCov_Assisted_Home_CleanPractices        = 12000                #//Jared 1/30/18
CS_MstDelivIntCov_Assisted_Home_ImmNewbrnAssess       = 12001                #//Jared 1/30/18
CS_MstDelivIntCov_Assisted_Home_LaborAndDelivMan      = 12002                #//Jared 1/30/18
CS_MstDelivIntCov_Assisted_Home_NeoResusc             = 12003                #//Jared 1/30/18
CS_MstDelivIntCov_Assisted_Home_AnteCortSte           = 12004                #//Jared 1/30/18
CS_MstDelivIntCov_Assisted_Home_AntipPRoM             = 12005                #//Jared 1/30/18
CS_MstDelivIntCov_Assisted_Home_MagnesSulfTrEclampsia = 12006                #//Jared 1/30/18
CS_MstDelivIntCov_Assisted_Home_AMTSL                 = 12007                #//Jared 1/30/18
CS_MstDelivIntCov_Assisted_Home_InductionOfLabour     = 12008                #//Jared 1/30/18

#  Essential care interventions

CS_MstDelivIntCov_EssCare_CleanPractices              = 12009                #//Jared 1/30/18
CS_MstDelivIntCov_EssCare_ImmNewbrnAssess             = 12010                #//Jared 1/30/18
CS_MstDelivIntCov_EssCare_LaborAndDelivMan            = 12011                #//Jared 1/30/18
CS_MstDelivIntCov_EssCare_NeoResusc                   = 12012                #//Jared 1/30/18
CS_MstDelivIntCov_EssCare_AnteCortSte                 = 12013                #//Jared 1/30/18
CS_MstDelivIntCov_EssCare_AntipPRoM                   = 12014                #//Jared 1/30/18
CS_MstDelivIntCov_EssCare_MagnesSulfTrEclampsia       = 12015                #//Jared 1/30/18
CS_MstDelivIntCov_EssCare_AMTSL                       = 12016                #//Jared 1/30/18
CS_MstDelivIntCov_EssCare_InductionOfLabour           = 12017                #//Jared 1/30/18

#  BEmOC delivery interventions

CS_MstDelivIntCov_BEmOC_CleanPractices                = 12018                #//Jared 1/30/18
CS_MstDelivIntCov_BEmOC_ImmNewbrnAssess               = 12019                #//Jared 1/30/18
CS_MstDelivIntCov_BEmOC_LaborAndDelivMan              = 12020                #//Jared 1/30/18
CS_MstDelivIntCov_BEmOC_NeoResusc                     = 12021                #//Jared 1/30/18
CS_MstDelivIntCov_BEmOC_AnteCortSte                   = 12022                #//Jared 1/30/18
CS_MstDelivIntCov_BEmOC_AntipPRoM                     = 12023                #//Jared 1/30/18
CS_MstDelivIntCov_BEmOC_MagnesSulfTrEclampsia         = 12024                #//Jared 1/30/18
CS_MstDelivIntCov_BEmOC_AMTSL                         = 12025                #//Jared 1/30/18
CS_MstDelivIntCov_BEmOC_InductionOfLabour             = 12026                #//Jared 1/30/18

#  CEmOC delivery interventions

CS_MstDelivIntCov_CEmOC_CleanPractices                = 12027                #//Jared 1/30/18
CS_MstDelivIntCov_CEmOC_ImmNewbrnAssess               = 12028                #//Jared 1/30/18
CS_MstDelivIntCov_CEmOC_LaborAndDelivMan              = 12029                #//Jared 1/30/18
CS_MstDelivIntCov_CEmOC_NeoResusc                     = 12030                #//Jared 1/30/18
CS_MstDelivIntCov_CEmOC_AnteCortSte                   = 12031                #//Jared 1/30/18
CS_MstDelivIntCov_CEmOC_AntipPRoM                     = 12032                #//Jared 1/30/18
CS_MstDelivIntCov_CEmOC_MagnesSulfTrEclampsia         = 12033                #//Jared 1/30/18
CS_MstDelivIntCov_CEmOC_AMTSL                         = 12034                #//Jared 1/30/18
CS_MstDelivIntCov_CEmOC_InductionOfLabour             = 12035                #//Jared 1/30/18

#  FamPlan Goal
CS_MstCPR       = 12500
CS_MstTFR       = 12501
CS_MstUnmetNeed = 12502

#  FamPlan Proximate determinants
CS_MstPercWom15t49InUnion = 12503
CS_MstPostpartumInsus     = 12504
CS_MstUnintendedPreg      = 12505
CS_MstSterility           = 12506

#  FamPlan Method mix
CS_MstMethMixFemaleCondom        = 12507
CS_MstMethMixMaleCondom          = 12508
CS_MstMethMixFemaleSterilization = 12509
CS_MstMethMixMaleSterilization   = 12510
CS_MstMethMixVaginalBarrier      = 12511
CS_MstMethMixSpermicides         = 12512
CS_MstMethMixWithdrawal          = 12513
CS_MstMethMixPeriAbstinence      = 12514
CS_MstMethMixTraditional         = 12515
CS_MstMethMix3Month              = 12516
CS_MstMethMix2Month              = 12517
CS_MstMethMix1Month              = 12518
CS_MstMethMix6Month              = 12519
CS_MstMethMixUniject             = 12520
CS_MstMethMixImplanon            = 12521
CS_MstMethMixJadelle             = 12522
CS_MstMethMixSinoImplant         = 12523
CS_MstMethMixStandDailyReg       = 12524
CS_MstMethMixProgestin           = 12525
CS_MstMethMixPCC                 = 12526
CS_MstMethMixIUD                 = 12527
CS_MstMethMixLNGIUS              = 12528
CS_MstMethMixLAM                 = 12529
CS_MstMethMixSDM                 = 12530
CS_MstMethMixOther               = 12531

#  FamPlan Effectiveness
CS_MstEffFemaleCondom        = 12532
CS_MstEffMaleCondom          = 12533
CS_MstEffFemaleSterilization = 12534
CS_MstEffMaleSterilization   = 12535
CS_MstEffVaginalBarrier      = 12536
CS_MstEffSpermicides         = 12537
CS_MstEffWithdrawal          = 12538
CS_MstEffPeriAbstinence      = 12539
CS_MstEffTraditional         = 12540
CS_MstEff3Month              = 12541
CS_MstEff2Month              = 12542
CS_MstEff1Month              = 12543
CS_MstEff6Month              = 12544
CS_MstEffUniject             = 12545
CS_MstEffImplanon            = 12546
CS_MstEffJadelle             = 12547
CS_MstEffSinoImplant         = 12548
CS_MstEffStandDailyReg       = 12549
CS_MstEffProgestin           = 12550
CS_MstEffPCC                 = 12551
CS_MstEffIUD                 = 12552
CS_MstEffLNGIUS              = 12553
CS_MstEffLAM                 = 12554
CS_MstEffSDM                 = 12555
CS_MstEffOther               = 12556

#  Maternal age and birth order
CS_MstLessThn18YrsFirstBirth           = 12557
CS_MstLessThn18YrsSecondAndThirdBirths = 12558
CS_MstLessThn18YrsGrThanThirdBirth     = 12559
CS_Mst18t34YrsFirstBirth               = 12560
CS_Mst18t34YrsSecondAndThirdBirths     = 12561
CS_Mst18t34YrsGrThanThirdBirth         = 12562
CS_Mst35t49YrsFirstBirth               = 12563
CS_Mst35t49YrsSecondAndThirdBirths     = 12564
CS_Mst35t49YrsGrThanThirdBirth         = 12565

#  Birth intervals
CS_MstFirstBirth               = 12566
CS_MstLessThan18Mnths          = 12567
CS_Mst18to23Mnths              = 12568
CS_Mst24MnthsOrGr              = 12569

#  Special checkboxes

CS_MstPentaCalcCheckBox          = 20000
CS_MstThermalCalcCheckBox        = 20001
CS_MstInjAntibCalcCheckBox       = 20002
CS_MstVitATrCalcCheckBox         = 20003
CS_MstIpTPCalcCheckBox           = 20004                                     #//Jared 10/19/17
CS_MstBFPromoMode                = 20005                                     #//Jared 10/19/17
CS_MstSingleStunt                = 20006                                     #//Jared 10/19/17
CS_MstSingleWaste                = 20007                                     #//Jared 10/19/17
CS_MstAllowLiSTCalcPlaceLvlDeliv = 20008                                     #//Jared 10/20/17
CS_MstAllowListCalcIntervCov     = 20009                                     #//Jared 10/20/17
CS_MstPercCurDelivOn             = 20010                                     #//Jared 1/26/18
CS_MstANCQualityAndUtil          = 20011                                     #//Jared 10/20/17
CS_MstChildbirthQualityAndUtil   = 20012                                     #//Jared 1/26/18
CS_MstFertilityRisksOn           = 20013                                     #//Jared 1/26/18

CS_FP_MstEstimateUnmetNeedFromPrev = 20100
CS_FP_MstActivateMethods           = 20101

CS_IpTPCalcCheckBox           = 1
CS_FirstID                    = CS_IpTPCalcCheckBox
CS_ANCQualityAndUtil          = 2                                     #//Jared 10/20/17
CS_ChildbirthQualityAndUtil   = 3                                     #//Jared 1/26/18
CS_BFPromoModeSG              = 4
CS_SingleStunt                = 5
CS_PentaCalcCheckBox          = 6
# //  CS_ThermalCalcCheckBox        = 7;
# //  CS_InjAntibCalcCheckBox       = 8;
# //  CS_VitATrCalcCheckBox         = 9;
CS_SingleWaste                = 7
CS_FertilityRisksOn           = 8
CS_LastID                     = CS_FertilityRisksOn

CS_FP_EstimateUnmetNeedFromPrev = 1
CS_FP_FirstID                   = CS_FP_EstimateUnmetNeedFromPrev
CS_FP_ActivateMethods           = 2
CS_FP_LastID                    = CS_FP_ActivateMethods

# //==============================================================================
# //                              Master ID's
# //==============================================================================

#  Master IDs corresponding to various lists of current IDs. The
#  order of these IDs CANNOT be changed. New IDs can only be added to the
#  ends of these lists, and must be added for each new current ID in
#  CSConst. Master IDs are used to identify items written out to file.

CS_MstbAuto   = 0
#  User results
CS_MstbUser   = 1
#  Estimate Bounds
CS_MstbMin    = 2
CS_MstbMax    = 3
#  CSUA
CS_MstbLow    = 4
CS_MstbMed    = 5
CS_MstbHigh   = 6

CS_Mst0t1Yr   = 0
CS_Mst1t2Yr   = 1
CS_Mst2t3Yr   = 2
CS_Mst3t4Yr   = 3
CS_Mst4t5Yr   = 4
CS_Mst5t6Yr   = 5

#  Cause of death types
CS_CoD_MstStillbirth   = 1
CS_CoD_MstNeonatal     = 2
CS_CoD_MstPostNeonatal = 3
CS_CoD_MstMaternal     = 4
CS_CoD_MstNNPostNN     = 5
CS_CoD_MstAdolescent   = 6

#  Stillbirth causes of death/death causes/CoDs
CS_SB_MstAntepartum  = 1
CS_SB_MstIntrapartum = 2
CS_SB_MstMaxCauses   = 2

CS_Adol_mstHIV             = 1
CS_Adol_mstDiarrhoeal      = 2
CS_Adol_mstMeasles         = 3
CS_Adol_mstMalaria         = 4
CS_Adol_mstLRI             = 5
CS_Adol_mstTB              = 6
CS_Adol_mstMaternal        = 7
CS_Adol_mstOtherCMPN       = 8
CS_Adol_mstCongenital      = 9
CS_Adol_mstNeoplasm        = 10
CS_Adol_mstCardiovascular  = 11
CS_Adol_mstDigestive       = 12
CS_Adol_mstOtherNCD        = 13
CS_Adol_mstRTI             = 14
CS_Adol_mstDrowning        = 15
CS_Adol_mstNatDis          = 16
CS_Adol_mstInterpVio       = 17
CS_Adol_mstCollectVio      = 18
CS_Adol_mstSelfHarm        = 19
CS_Adol_mstOtherInj        = 20

#  [Neonatal and Postneonatal] Causes of death/death causes/CoDs
CS_MstNNDiarr        = 1
CS_MstNNSepPneu      = 2
CS_MstNNAsphyxia     = 3
CS_MstNNPreterm      = 4
CS_MstNNTetanus      = 5
CS_MstNNCongen       = 6
CS_MstNNOther        = 7
CS_MstDiarrhea       = 8
CS_MstPneumonia      = 9
CS_MstMeasles        = 10
CS_MstMalaria        = 11
CS_MstAIDS           = 12
CS_MstOther          = 13
CS_MstPertussis      = 14
CS_MstMeningitis     = 15
CS_MstInjury         = 16
CS_MstNNSepsis       = 17
CS_MstNNPneu         = 18
CS_MstCustomNNCOD1   = 19
CS_MstCustomNNCOD2   = 20
CS_MstCustomNNCOD3   = 21
CS_MstCustomNNCOD4   = 22
CS_MstCustomPNNCOD1  = 23
CS_MstCustomPNNCOD2  = 24
CS_MstCustomPNNCOD3  = 25
CS_MstCustomPNNCOD4  = 26
CS_MstMaxDeaths      = 26
CS_MstOtherInfecDis  = 27
CS_MstOtherNCD       = 28

#  Maternal causes of death/death causes/CoDs
CS_Mat_MstAntepartHemorr    = 1
CS_Mat_MstPostpartHemorr    = 2
CS_Mat_MstHypertensiveDis   = 3
CS_Mat_MstEclampsia         = 4  #// obsolete
CS_Mat_MstSepsis            = 5
CS_Mat_MstAbortion          = 6
CS_Mat_MstObstructedLabor   = 7  #// obsolete
CS_Mat_MstEctopic           = 8  #// obsolete
CS_Mat_MstOtherDirectCauses = 9
CS_Mat_MstMalaria           = 10 #// obsolete
CS_Mat_MstCardiovascDis     = 11 #// obsolete
CS_Mat_MstIndirectCauses    = 12
CS_Mat_MstIntrapartHemorr   = 13
CS_Mat_MstEmbolism          = 14
CS_Mat_MstMaxDeaths         = 14

#  Delivery level master IDs. Note: We do not need master IDs for the
#  delivery interventions because we can map them to their corresponding
#  current interventions IDs, which already have corresponding master
#  intervention IDs.
CS_MstAllDelivLevels    = 0
CS_MstUnassisted_Home   = 1
CS_MstAssisted_Home     = 2
CS_MstEssentialCare_Fac = 3
CS_MstBEmOC_Fac         = 4
CS_MstCEmOC_Fac         = 5
CS_MstNumDelivLevels    = 5

#  Diarrhea pathogens
CS_MstRotavirus_DiarPath = 1
CS_MstPathogenB_DiarPath = 2
CS_MstPathogenC_DiarPath = 3
CS_MstOther_DiarPath     = 4
CS_MstNum_DiarPath       = 4

#  Pneumonia pathogens
CS_MstHib_PneumPathVT          = 1
CS_MstPneumococcus_PneumPath   = 2
CS_MstInfluenza_PneumPath      = 3
CS_MstOther_PneumPath          = 4
CS_MstPneumococcus_PneumPathVT = 5

#  Meningitis pathogens
CS_MstHib_MeningPathVT           = 1
CS_MstPneumococcus_MeningPath    = 2
CS_MstMeningitidisA_MeningPathVT = 3
CS_MstOther_MeningPath           = 4
CS_MstPneumococcus_MeningPathVT  = 5
CS_MstMeningitidis_MeningPath    = 6

#  Vaccine doses
CS_MstVaccDoseZero   = 0
CS_MstVaccDoseOne    = 1
CS_MstVaccDoseTwo    = 2
CS_MstVaccDoseThree  = 3
CS_MstVaccBooster    = 4

#  Herd master ID's.
CS_MstRotavirus_Herd      = 1
CS_MstMeasles_Herd        = 2
CS_MstHib_Herd            = 3
CS_MstPneumococcal_Herd   = 4
CS_MstDPT_Herd            = 5
CS_MstBednets_Herd        = 6
CS_MstDiarVaccPathB_Herd  = 7
CS_MstDiarVaccPathC_Herd  = 8
CS_MstMalaria_Herd        = 9
CS_MstVaccineD_Herd       = 10
CS_MstMeningococcalA_Herd = 11
CS_MstVaccineE_Herd       = 12
CS_MstVaccineF_Herd       = 13

#  Detailed vaccines
CS_MstBCG_Det          = 1
CS_MstPolio_Det        = 2
CS_MstDPT_Det          = 3
CS_MstHiB_Det          = 4
CS_MstHepB_Det         = 5
CS_MstPCV_Det          = 6
CS_MstRota_Det         = 7
CS_MstMeas_Det         = 8
CS_MstMenA_Det         = 9
CS_MstVaccB_Det        = 10
CS_MstVaccC_Det        = 11
CS_MstMalaria_Det      = 12
CS_MstVaccD_Det        = 13
CS_MstVaccE_Det        = 14
CS_MstVaccF_Det        = 15

#  Nutritional Deficiencies
CS_MstVitADefic      = 1
CS_MstZincDefic      = 2
CS_MstVitB6Defic     = 3
CS_MstVitB12Defic    = 4
CS_MstVitCDefic      = 5
CS_MstCalcDefic      = 6
CS_MstCoppDefic      = 7
CS_MstFolDefic       = 8
CS_MstIronDefic      = 9
CS_MstMagDefic       = 10
CS_MstNiaDefic       = 11
CS_MstPhosDefic      = 12
CS_MstRiboDefic      = 13
CS_MstThiaDefic      = 14

#  Calculate Coverage From Inputs (CCFI) constants
CS_MstAntenatalCare_CCFI  = 1
CS_MstDelivery_CCFI       = 2
CS_MstAbortCaseMan_CCFI   = 3
CS_MstPostNatCare_CCFI    = 4
CS_MstPentavalent_CCFI    = 5
CS_MstNeonatalCM_CCFI     = 6
CS_MstThermalCare_CCFI    = 7
CS_MstFSCPrematurity_CCFI = 8
CS_MstInjectAntib_CCFI    = 9
CS_MstFSCSepsisPneum_CCFI = 10
CS_MstVitAMeasTreat_CCFI  = 11
CS_MstMax_CCFI            = 11

#  CSUA constants for inputs to activate
CSUA_Mst_Coverage             = 1
CSUA_Mst_Effectiveness        = 2
CSUA_Mst_MortalityRates       = 3
CSUA_Mst_DeathCauses          = 4
CSUA_Mst_RelativeRisks        = 5
CSUA_Mst_Incidence            = 6
CSUA_Mst_ApplyConstraints     = 7
CSUA_Mst_MaxInputs            = 7

#  Master Section IDs for the sections in DatabyCountry. **Must not be changed.
#  Used to help ascertain if column being read in is still in the same section.
#  Especially useful for items with confusing loop structures.
CS_DxC_Sec_BaselineMort                             = 1
CS_DxC_Sec_RiskOfMort                               = 2 #//not currently in use
CS_DxC_Sec_Stunting                                 = 3 #//not currently in use
CS_DxC_Sec_Wasting                                  = 4 #//not currently in use
CS_DxC_Sec_DiarrheaInc                              = 5
CS_DxC_Sec_PercDeathsByCause                        = 6
CS_DxC_Sec_NutritionalDeficiencies                  = 7
CS_DxC_Sec_SBAffFrac                                = 8
CS_DxC_Sec_AffFrac                                  = 9
CS_DxC_Sec_BreastfeedPrev                           = 10
CS_DxC_Sec_PerCapitaInc                             = 11
CS_DxC_Sec_IPTRecdCountry                           = 12
CS_DxC_Sec_AbortionIncRat                           = 13
CS_DxC_Sec_MatMortRatio                             = 14
CS_DxC_Sec_PercMatDeathsByCause                     = 15
CS_DxC_Sec_SBRate                                   = 16
CS_DxC_Sec_PercSBByCause                            = 17
CS_DxC_Sec_DetMeaslesCov                            = 18 #//not currently in use
CS_DxC_Sec_RotavirusEff                             = 19
CS_DxC_Sec_Coverage                                 = 20
CS_DxC_Sec_PneumoniaInc                             = 21
CS_DxC_Sec_StatusAtBirth                            = 22
CS_DxC_Sec_PathogenInc                              = 23
CS_DxC_Sec_PneumoEffects                            = 24 #//not currently in use
CS_DxC_Sec_RelRisksIUGR_LBW                         = 25
CS_DxC_Sec_IncMeningitis                            = 26
CS_DxC_Sec_StuntingDistr                            = 27
CS_DxC_Sec_WastingDistr                             = 28
CS_DxC_Sec_PneumococcalEffMortPneum                 = 30
CS_DxC_Sec_PneumIncReduction                        = 31
CS_DxC_Sec_MeningIncReduction                       = 32
CS_DxC_Sec_AbortionIncRatio                         = 33
CS_DxC_Sec_PercPregEndAbort                         = 34
CS_DxC_Sec_AffFracImpTherapFeedOnOther              = 36
CS_DxC_Sec_AffFracRiskStuntWastOnOtherDueToInfecDis = 37
CS_DxC_Sec_AffFracRiskStuntWastOnOtherOtherCauses   = 38
CS_DxC_Sec_DiarPath                                 = 39
CS_DxC_Sec_PneumPath                                = 40
CS_DxC_Sec_MenPath                                  = 41
CS_DxC_Sec_AvgHouseholdSize                         = 42
CS_DxC_Sec_LiSTCostingOtherDirectCosts              = 43
CS_DxC_Sec_LiSTCostingIndirectCosts                 = 44
CS_DxC_Sec_MatAffFrac                               = 45
CS_DxC_Sec_RotaImpOnSevereDiarrIncEff               = 46
CS_DxC_Sec_IncSevereDiarr                           = 47
CS_DxC_Sec_EarlyInitBF                              = 48
CS_DxC_Sec_PercExposedFalciparum                    = 49
CS_DxC_Sec_MatAnemia                                = 50
CS_DxC_Sec_PercWomenWithSevereAnemia                = 51
CS_DxC_Sec_PercWom15t49LowBMI                       = 52
CS_DxC_Sec_LBWF                                     = 53
CS_DxC_Sec_DiarrIncReduction                        = 54
CS_DxC_Sec_MenARecommended                          = 55
CS_DxC_Sec_HerdVaccEff                              = 56
CS_DxC_Sec_AFBalancedEnergySupp                     = 57
CS_DxC_Sec_AFStopSmokingEdu                         = 58
CS_DxC_Sec_PercWomenWithPrevPreEclamp               = 59
CS_DxC_Sec_PercWomenWithChronicHypertension         = 60
CS_DxC_Sec_VitADefInPW                              = 61
CS_NUM_DxCSecs                                      = CS_DxC_Sec_VitADefInPW

CS_MstPointOfUseFilteredWater_DiarInterv = 1  #// CS_IV_PointOfUseFilteredWater
CS_MstPipedWater_DiarInterv              = 2  #// CS_IV_PipedWater
CS_MstBasicSanitation_DiarInterv         = 3  #// CS_IV_BasicSanitation
CS_MstHandWashWSoap_DiarInterv           = 4  #// CS_IV_HandWashWSoap
CS_MstHygDisposalStools_DiarInterv       = 5  #// CS_IV_HygDisposalStools
CS_MstZincP_DiarInterv                   = 6  #// CS_IV_ZincP
CS_MstVitAPTwoDoses_DiarInterv           = 7  #// CS_IV_VitASupp
CS_MstRotavirusVacc_DiarInterv           = 8  #// CS_IV_RotavirusVacc
CS_MstDiarVaccPathB_DiarInterv           = 9  #// CS_IV_DiarVaccPathB
CS_MstDiarVaccPathC_DiarInterv           = 10 #// CS_IV_DiarVaccPathC
CS_MstBFPromotion_DiarInterv             = 11 #// CS_IV_ChangesInBF

#  Interventions for birth outcomes master ID's
CS_MstIPTp               = 1
CS_MstBalEnergy          = 2
CS_MstIronFolateSupp     = 3
CS_MstMultMicroLowBMI    = 4
CS_MstMultMicroNormBMI   = 5
CS_MstCalciumSupp        = 6
CS_MstITN                = 7
CS_MstAgeAndBirthOrder   = 8
CS_MstBirthInterval      = 9
CS_MstAspirinLowDose     = 10
CS_MstProgesterone       = 11
CS_MstStopSmokingEduc    = 12
CS_MstTreatOfBacteriuria = 13
CS_MstOmeg3FASupp        = 14
CS_MstFolicAcidFort      = 15
CS_MstZincFort           = 16
CS_MstSyphilisTreat      = 17
CS_MstSpareBOInterv1     = 18
CS_MstSpareBOInterv2     = 19
CS_MstSpareBOInterv3     = 20
CS_MstSpareBOInterv4     = 21
CS_MstCleanCordCare      = 22
CS_MstZincSuppInPreg     = 23
CS_MstFoodInsecBES       = 24

#  Interventions for food insecurity master ID's
CS_MstConditionalCashTransfer   = 1
CS_MstFoodAssistanceToFamilies  = 2
CS_MstDirectSupport             = 3
CS_MstFoodShock                 = 4

CS_MstPreTermSGA = 1
CS_MstPreTermAGA = 2
CS_MstTermSGA    = 3
CS_MstTermAGA    = 4

#  Age Constants
#  [Standard] age cohorts
CS_MstAgeSummary               = 0
CS_MstBirth                    = 0
CS_Mst0t1months                = 1
CS_Mst1t6months                = 2
CS_Mst6t12months               = 3
CS_Mst12t24months              = 4
CS_Mst24t60months              = 5

#  Additional age cohorts - for detailed vaccines
CS_Mst24t36months              = 6
CS_Mst36t48months              = 7
CS_Mst48t60months              = 8

#  Anemia among women of reproductive age (WRA)
CS_MstPreg_Anemia              = 1
CS_MstNonPreg_Anemia           = 2
CS_MstPreg_IronDeficAnemia     = 3
CS_MstNonPreg_IronDeficAnemia  = 4

#  Standard deviation Constants
CS_MstGT1STD                     = 1
CS_Mst1t2STD                     = 2
CS_Mst2t3STD                     = 3
CS_MstGT3STD                     = 4

#  Constants for distribution of pathogens among incident, fatal, and all cases.
CS_MstDistr_All      = 1
CS_MstDistr_Sevr     = 2
CS_MstDistr_Fatal    = 3

#  Mortality rate constants
CS_MstNeonatalMR               = 1
CS_MstInfantMR                 = 2
CS_MstU5MR                     = 3

#  Endpoints for CSUA
CS_MstMinEndPoint              = 1
CS_MstMaxEndPoint              = 2

#  Percent deaths by cause constants
CS_MstDxC_Default              = 1
CS_MstDxC_Normalized           = 2
CS_MstDxC_NoAIDS               = 3

#  Adolescent Age Constants
CS_Mst5yrs_9yrs                = 1
CS_Mst10yrs_14yrs              = 2
CS_Mst15yrs_19yrs              = 3

CS_MstInterventionCosts = 1
CS_MstProgramCosts = 2
CS_MstLogisticsAndWastage = 3
CS_MstInfrastructureInvest = 4
CS_MstOtherHealthSysCosts = 5

CS_MstSocBenSB = 1
CS_MstSocBenChild = 2
CS_MstSocBenMat = 3
CS_MstEarnSB = 4
CS_MstEarnChild = 5
CS_MstEarnMat = 6
CS_MstStuntReducAddEarn = 7

CS_MstPerCapita = 1
CS_MstPerWorker = 2

CS_MstBenefits = 1
CS_MstCosts = 2

CS_MstSocialValue = 1
CS_MstPercStillbirthsIncluded = 2

#  Breastfeeding constants
CS_MstExclusiveBF              = 1
CS_MstPredominantBF            = 2
CS_MstPartialBF                = 3
CS_MstNotBF                    = 4

#  Since SIA coverage needs to go back 4 years before LiST base year, we
# have a separate array for the early coverage and these constants will be
# used to access the coverage
CS_MstDetVacc4YrsRetro        = 4
CS_MstDetVacc3YrsRetro        = 3
CS_MstDetVacc2YrsRetro        = 2
CS_MstDetVacc1YrsRetro        = 1

#  Fert-brth outcomes RR's
#  Age and Birth Order
#  Mother's Age
CS_MstAllYrs       = 1
CS_MstLT18Yrs      = 2
CS_Mst18_34Yrs     = 3
CS_Mst35_49Yrs     = 4

#  Birth order of child
CS_MstFirstBirth         = 1
CS_MstSecAndThirdBirths  = 2
CS_MstGTThirdBirth       = 3

#  Birth Intervals
CS_MstLT18Mths         = 2
CS_Mst18to23Mths       = 3
CS_MstGE24Mths         = 4

#  Default Constants
CS_MstDefault           = 1
CS_MstData              = 2

CS_MstEfficacy                 = 1
CS_MstAffecFract               = 2
CS_MstAdjustedRR               = 3

#  Severe diarrheal incidence reduction interventions. 
CS_MstRotavirusVacc_SevDiarInterv = 1

#  Pneumonia incidence reduction interventions. 
CS_MstHibVacc_PneumInterv   = 1
CS_MstPneumVacc_PneumInterv = 2
CS_MstZincP_PneumInterv     = 3

#  Meningitis incidence reduction interventions. 
CS_MstHibVacc_MeningInterv   = 1
CS_MstPneumVacc_MeningInterv = 2
CS_MstMeningA_MeningInterv   = 3

#  Vaccine sector data
CS_Mst0PercCov                 = 1
CS_Mst5PercCov                 = 2
CS_Mst10PercCov                = 3
CS_Mst15PercCov                = 4
CS_Mst20PercCov                = 5
CS_Mst25PercCov                = 6
CS_Mst30PercCov                = 7
CS_Mst35PercCov                = 8
CS_Mst40PercCov                = 9
CS_Mst45PercCov                = 10
CS_Mst50PercCov                = 11
CS_Mst55PercCov                = 12
CS_Mst60PercCov                = 13
CS_Mst65PercCov                = 14
CS_Mst70PercCov                = 15
CS_Mst75PercCov                = 16
CS_Mst80PercCov                = 17
CS_Mst85PercCov                = 18
CS_Mst90PercCov                = 19
CS_Mst95PercCov                = 20
CS_Mst100PercCov               = 21

#  Impact of IUGR/Low birth weight on stunting 
CS_MstLowBirthWeight_TermAGA     = 1
CS_MstLowBirthWeight_TermSGA     = 2
CS_MstLowBirthWeight_PreTermAGA  = 3
CS_MstLowBirthWeight_PreTermSGA  = 4

#  Impact of previous stunting on stunting
CS_MstNotStuntedPrevAge          = 5
CS_MstStuntedPrevAge             = 6

#  Impact of complementary feeding on stunting
CS_MstFoodSecureWPromo           = 7
CS_MstFoodSecureWOPromo          = 8
CS_MstInsecureWPromoSupp         = 9
CS_MstInsecureWOPromoSupp        = 10

#  Impact of diarrhea on stunting
CS_MstImpDiarrPerEpisode         = 11

#  Impact of zinc supplementation on stunting
CS_MstZincSupp                   = 12
CS_MstNotZincSupp                = 13
CS_MstImpactsOnStuntingFinal     = 14

#  Impacts on Wasting Editor constants
CS_MstImpactsOnWaste_Therafeed                            = 1          
CS_MstImpactsOnWaste_FractionChildrenMovMildWastWithTreat = 2         

#  note that 7-10 from above

CS_MstImpactsOnWaste_FractionChildrenMovModWastWithTreat = 11
CS_MstImpactsOnWaste_FractionChildrenMovSevWastWithTreat = 12

CS_MstPreg     = 1
CS_MstNonPreg  = 2

#  Impacts on maternal anemia constants
CS_MstIronFolatePW_MatAnemia = 1
CS_MstMMicroSuppPW_MatAnemia = 2
CS_MstIronFortNPW_MatAnemia  = 3
CS_MstIPTP_MatAnemia         = 4
CS_MstITN_MatAnemia          = 5

CS_MstImpactPromoBF      = 1
CS_MstImpactPromoEarlyBF = 2

#  Breastfeeding Promotion constants
CS_MstBFPromoHealthSystem  = 1
CS_MstBFPromoHomeComm      = 2
CS_MstBFPromoBoth          = 3

CS_MstEarlyInitBF = 1
CS_MstLateInitBF  = 2

CS_MstMat_NotAnemic  = 1
CS_MstMat_Anemic     = 2

#  Abortions
CS_MstTotalAbort              = 1
CS_MstUnsafeAbort             = 2
CS_MstSafeAbort               = 3

#  Reduction in mortality by intervention display constants
CS_MstCovIncIntervPrgm        = 1
CS_MstPercRedU5MortDueInterv  = 2
CS_MstPercU5MortRedAttrInterv = 3

#  Discount rate
CS_Mst3Perc                    = 0
CS_Mst5Perc                    = 1
CS_Mst10Perc                   = 2

CS_MstWRA_Anemia           = 2 
CS_MstWRA_IronDeficAnemia  = 4 

# /* Intervention Master ID's from IVModData.xlsx **Cannot change!!!***) */
# /* Periconceptual */
IV_ContraceptiveUse	           = 47
IV_FolicAcidSupp               = 7
IV_SafeAbortServ               = 73
IV_PostAbortCaseMgmt           = 170
IV_EctopicPregCaseMgmt         = 171
IV_BlanketIronSuppFort         = 446
IV_ZincFort                    = 534

# /* Pregnancy */
IV_ANC1                        = 504
IV_ANC4                        = 37
IV_TetToxVacc                  = 4
IV_IPT_Mal                     = 3
IV_SyphDetectTr                = 1
IV_CalciumSupp                 = 72
IV_ZincSuppInPreg              = 548
IV_TreatOfBacteriuria          = 532
IV_Omeg3FASupp                 = 533
IV_AspirinLowDose              = 529
IV_Progesterone                = 530
IV_StopSmokingEduc             = 531
IV_SpareBOInterv1              = 536
IV_SpareBOInterv2              = 537
IV_SpareBOInterv3              = 538
IV_SpareBOInterv4              = 539
IV_MicronSupp                  = 254
IV_IronSuppPreg                = 235
IV_MultiMicronSuppPreg         = 9
IV_BalEnergySupp	           = 8
IV_FoodInsecBES                = 643
IV_HyperDisCaseMgmt	           = 82
IV_DiabCaseMgmt                = 87
IV_MalCaseMgmt                 = 172
IV_FGRDetMgmt                  = 91
IV_PMTCT	                   = 14
IV_AgeAndBirthOrder	           = 233
IV_BirthIntervals	           = 234

# /* Childbirth */
IV_SkBirthAttend               = 53
IV_HealthFacDelivery           = 10
IV_CleanCordCare               = 255
IV_CleanBirthEnvironment       = 11
IV_ImmDryAndAdditionalStim     = 174
IV_LaborAndDelivMan            = 74
IV_NeoResusc                   = 15
IV_CortPretermLabor            = 5
IV_AntipPRoM                   = 6
IV_MgSO4ForEclampsia           = 83
IV_ParenteralAdminOfUter       = 62
IV_ParenteralAdminOfAntibiotics = 505
IV_SurgeryChildbirth           = 509
IV_InductionOfLabour           = 94
IV_CaseMgmtPrematBabies        = 321
IV_KangarooMothCare            = 16
IV_FullSuppCarePremat          = 322
IV_iKMC                        = 547

# /* Breastfeeding */
IV_ChangesInBF                 = 17

# /* Preventive */
IV_ImpWaterSource              = 40
IV_ImprovedSanitation          = 42
IV_HandWashWSoap               = 43
IV_HygDisposalStools	       = 44
IV_NNVitASupp                  = 540
IV_VitASupp                    = 46
IV_ZincSupp	                   = 24
IV_WaterConnectionHome         = 41
IV_ITN_IRS	                   = 22
IV_CompFeedPrevStunting        = 86
IV_CompFeedPrevWasting         = 482
IV_ApprCompFeed                = 489
IV_BasicSanitation             = 42
IV_PointOfUseFilteredWater     = 40
IV_PipedWater                  = 41

# /* Vaccines */
IV_BCG_Vacc                    = 49
IV_PolioVacc                   = 34
IV_PentaVacc                   = 175
IV_DPT_Vacc                    = 33
IV_HibVacc                     = 25
IV_HepBVacc                    = 167
IV_PneuVacc                    = 26
IV_RotavirusVacc               = 45
IV_MeningA                     = 191
IV_MalVacc                     = 251
IV_MeasVacc                    = 21
IV_DiarVaccPathB               = 192
IV_DiarVaccPathC               = 193
IV_VaccineD                    = 252
IV_VaccineE                    = 657
IV_VaccineF                    = 699

# /* Curative */
IV_SepsisCaseMngmnt            = 173
IV_CaseMgmtNeonSepsPneu        = 75
IV_OralAntibNeonSeps           = 69
IV_InjectAntibNeonSeps         = 70
IV_FullSuppCareNeonSepsPneu    = 13
IV_VitATrMeas                  = 31
IV_SAM                         = 71
IV_TrMAM                       = 237
IV_Cotrimoxazole	           = 35
IV_ART	                       = 36

IV_MstSAM                      = 71
IV_MstTrMAM                    = 237
IV_MstChangesInBF_BFPromo      = 17

IV_MstMicronSupp               = 254
IV_MstIronSuppPreg             = 235
IV_MstMultiMicronSuppPreg      = 9

IV_MstPentaVacc                = 175
IV_MstDPT_Vacc                 = 33
IV_MstHibVacc                  = 25
IV_MstHepBVacc                 = 167

IV_MstCaseMgmtPrematBabies     = 321
IV_MstKangarooMothCare         = 16
IV_MstFullSuppCarePremat       = 322

IV_MstCaseMgmtNeonSepsPneu     = 75
IV_MstOralAntibNeonSeps        = 69
IV_MstInjectAntibNeonSeps      = 70
IV_MstFullSuppCareNeonSepsPneu = 13

IV_ChangeStuntingPrev          = 39
IV_ChangeWastingPrev	       = 195

# //Intervention Group Master ID's from IVModData.xlsx **Cannot change!!!***)
CS_GroupMstID_Periconceptual = 1
CS_GroupMstID_Pregnancy = 4
CS_GroupMstID_Childbirth = 7
CS_GroupMstID_Breastfeeding = 13
CS_GroupMstID_Preventive = 14
CS_GroupMstID_Vaccines = 15
CS_GroupMstID_Curative = 16

# LiST intervention calculation type (CT) determines the order of intervention calculations in CSProj. 
IV_CS_AllIntervCalcTypes      = 0
IV_CS_FirstIntervCalcType     = 1
IV_CS_Abortion                = 1
IV_CS_Periconceptual          = 2
IV_CS_ANC                     = 3  # pregnancy
IV_CS_Delivery                = 4  # childbirth
IV_CS_Vaccine                 = 5
IV_CS_Preventive              = 6
IV_CS_Curative                = 7

IV_CS_NumIntervCalcTypes      = 7

IV_CS_CurativeModerateWasting = 8
IV_CS_CurativeSevereWasting   = 9
IV_CS_PregnancyBirthOutcomes  = 10
IV_CS_PreventiveStunting      = 11

IV_CS_MaxCustomCalcType       = 4

IV_CS_NoIntervCalcType        = IV_CS_NumIntervCalcTypes + IV_CS_MaxCustomCalcType + 1

# Maximum type for stillbirths and maternal- neither of these use Vaccine, Preventive, Curative
IV_CS_MaxNeonatalType = IV_CS_Delivery




























##############################################################################

CS_MstMaternalAgeOfBirthOrder = 13013

CS_MstDirectEntryOfStunting = 13500
CS_FirstNutMstID            = CS_MstDirectEntryOfStunting
CS_MstDirectEntryOfWasting  = 13501
CS_MstDirectEntryOfBF       = 13502
CS_MstBFPromotion           = 13503
CS_LastNutMstID             = CS_MstBFPromotion

#    Special LiST Online Adolescent intervention master ID's
#    FamPlan
CS_MstFamPlanInt                   = 13599
CS_FirstFPMstID                    = CS_MstFamPlanInt
CS_MstPercMarried                  = 13600
CS_MstPercUsingContra              = 13601
CS_MstContraMethMix                = 13602
CS_MstPercUnintendedPregTermByAbor = 13603
CS_LastFPMstID                     = CS_MstPercUnintendedPregTermByAbor
#    HIV
CS_MstHIVInt                        = 13604
CS_FirstAMMstID                     = CS_MstHIVInt
CS_MstPercUsingCondWNonMarContacts  = 13605
CS_MstPercUsingPrEP                 = 13606
CS_MstPercOnART                     = 13607
CS_MstPercMalesCircum               = 13608
CS_MstPercReceivCompSexEd           = 13609
CS_MstPercFemalesReceivEconStrength = 13610
CS_LastAMMstID                      = CS_MstPercFemalesReceivEconStrength

#    Special LiST Online intervention group master ID's
CS_MstLiSTOnline_BF               = 1000
CS_MstLiSTOnline_Stunt            = 1001
CS_MstLiSTOnline_Waste            = 1002
CS_MstLiSTOnline_AgeAndBirthOrder = 1003
CS_MstLiSTOnline_BirthInterval    = 1004
CS_MstLiSTOnline_Nutrition        = 1005
CS_MstLiSTOnline_FamPlanHIV       = 1006

#    Special LiST Online intervention subgroup master ID's
CS_MstLiST               = 1500
CS_FirstLOLSubGroupMstID = CS_MstLiST
CS_MstFamPlan            = 1501
CS_MstHIV                = 1502
CS_LastLOLSubGroupMstID  = CS_MstHIV

###########################################################################

CS_LiSTOnline_Periconcep       = 1
CS_LiSTOnline_Preg             = CS_LiSTOnline_Periconcep + 1
CS_LiSTOnline_Childbirth       = CS_LiSTOnline_Preg + 1
CS_LiSTOnline_Nutrition        = CS_LiSTOnline_Childbirth + 1
CS_LiSTOnline_Preventive       = CS_LiSTOnline_Nutrition + 1
CS_LiSTOnline_Vaccines         = CS_LiSTOnline_Preventive + 1
CS_LiSTOnline_Curative         = CS_LiSTOnline_Vaccines + 1
CS_LiSTOnline_FamPlanHIV       = CS_LiSTOnline_Curative + 1
CS_LiSTOnline_MaxGroups        = CS_LiSTOnline_FamPlanHIV
