"""SpectrumCommon constants package."""
