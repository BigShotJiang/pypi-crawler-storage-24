#######################################################################################################
#                                                                                                     #
#                                       Exchange Rate (EXDB)                                          #
#                                                                                                     #
#######################################################################################################

IH_ISO_ALPHA_3_COUNTRY_CODE_KEY_EXDB = 'ISO3AlphaCountryCode'
IH_EXCHANGE_RATE_KEY_EXDB            = 'exchangeRate'
IH_INFLATION_RATE_KEY_EXDB           = 'inflationRate'