from SpectrumCommon.Const.IV.IVConst import *
from SpectrumCommon.Const.IV.IVDatabaseKeys import *

from SpectrumCommon.Const.IC.ICTags import *
from SpectrumCommon.Const.IC.ICConst import *
from SpectrumCommon.Const.IC.ICDatabaseConst import *

from SpectrumCommon.Const.HW.HWConst import *
from SpectrumCommon.Const.HW.HWTags import *

########################    IV    ##########################

IH_IV_GROUP_DB_CURR_VERSION        = IV_IH_GROUP_DB_CURR_VERSION
IH_IV_TI_GROUP_DB_CURR_VERSION     = IV_TI_GROUP_DB_CURR_VERSION
IH_IV_CS_GROUP_DB_CURR_VERSION     = IV_CS_GROUP_DB_CURR_VERSION

IH_IV_GROUP_DB_NAME        = IV_GROUP_DB_NAME

# Group DB (GDB)

IH_IV_ROOT_CONSTANT_KEY_GDB    = IV_ROOT_CONSTANT_KEY_GDB
IH_IV_GROUP_MST_ID_KEY_GDB     = IV_GROUP_MST_ID_KEY_GDB
IH_IV_SUBGROUP_MST_ID_KEY_GDB  = IV_SUBGROUP_MST_ID_KEY_GDB   
IH_IV_ENGLISH_STRING_KEY_GDB   = IV_ENGLISH_STRING_KEY_GDB
IH_IV_STRING_CONSTANT_KEY_GDB  = IV_STRING_CONSTANT_KEY_GDB     

#############################    IC    ##########################

IH_IC_DRUG_SUPPLY_DB_NAME         = IC_DRUG_SUPPLY_DB_NAME
IH_IC_DRUG_SUPPLY_DB_CURR_VERSION = IC_DRUG_SUPPLY_DB_CURR_VERSION

IH_IC_MST_ID_KEY_DSDB              = IC_MST_ID_KEY_DSDB    
IH_IC_CONSTANT_KEY_DSDB            = IC_CONSTANT_KEY_DSDB 
IH_IC_ENGLISH_STRING_KEY_DSDB      = IC_ENGLISH_STRING_KEY_DSDB  
IH_IC_COST_TYPE_MST_ID_KEY_LG_DSCB = IC_COST_TYPE_MST_ID_KEY_LG_DSCB  

IH_IC_RES_STATIC_STAFF_TIME_REQ_BY_PROG_AREA_TAG_V1 = IC_RES_STATIC_STAFF_TIME_REQ_BY_PROG_AREA_TAG_V1
IH_IC_RES_DYNAMIC_STAFF_TIME_REQ_BY_PROG_AREA_TAG_V1 = IC_RES_DYNAMIC_STAFF_TIME_REQ_BY_PROG_AREA_TAG_V1

#######################################################################################################
#                                                                                                     #
#                                      HW                                                             #
#                                                                                                     #
#######################################################################################################

IH_HW_ADD_TO_TREAT_INPUTS_MST_ID = HW_ADD_TO_TREAT_INPUTS_MST_ID
IH_HW_NUM_STATIC_STAFF_TYPES     = HW_NUM_STATIC_STAFF_TYPES
IH_HW_NUM_STAFFING_LEVELS        = HW_NUM_STAFFING_LEVELS

IH_HW_STAFF_TYPE_RECORDS_TAG_V1  = HW_STAFF_TYPE_RECORDS_TAG_V1
IH_HW_RES_TOTAL_STAFF_TAG_V1     = HW_RES_TOTAL_STAFF_TAG_V1

