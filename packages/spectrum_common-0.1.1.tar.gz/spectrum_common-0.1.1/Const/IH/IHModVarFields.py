# Fields used in IH data structures

IH_F_PROG_AREA_ID             = 'progAreaID'
IH_F_SUBGROUP_ID              = 'subgroupID'
IH_F_DELIV_CHAN_ID            = 'delivChanID'
IH_F_DELIV_CHAN_PACK_ID       = 'delivChanPackID'
IH_F_HEALTH_SYS_ADMIN_UNIT_ID = 'healthSysAdminUnitID'
IH_F_NAT_PROG_ID              = 'natProgID'

# programme area records

IH_PROG_AREA_ID                 = IH_F_PROG_AREA_ID  # string;  numeric mstID for defaults. GUID for customs.
IH_PROG_AREA_STR_CONSTANT       = 'stringConstant'   # string;  Defaults only.
IH_PROG_AREA_NAME               = 'name'             # string;  Holds custom name or overridden default name.
IH_PROG_AREA_ACTIVE             = 'active'           # boolean; Is user using this item or not?
IH_PROG_AREA_SUBGROUP_RECORDS   = 'subgroupRecords'  # list; Subgroup dicts
IH_PROG_AREA_CUSTOM             = 'custom'           # boolean; user-entered = true; default = false

# subgroup records (these sit inside the programme area records)

IH_SUBGROUP_ID           = IH_F_SUBGROUP_ID # string;  numeric mstID for defaults. GUID for customs.
IH_SUBGROUP_STR_CONSTANT = 'stringConstant' # string;  Defaults only.
IH_SUBGROUP_NAME         = 'name'           # string;  Holds custom name or overridden default name.
IH_SUBGROUP_ACTIVE       = 'active'         # boolean; Is user using this item or not?
IH_SUBGROUP_CUSTOM       = 'custom'         # boolean; user-entered = true; default = false

# delivery channel records

IH_DELIV_CHAN_ID           = IH_F_DELIV_CHAN_ID  # string;  numeric mstID for defaults. GUID for customs.
IH_DELIV_CHAN_STR_CONSTANT = 'stringConstant'    # string;  Defaults only.
IH_DELIV_CHAN_NAME         = 'name'              # string;  Holds custom name or overridden default name.
IH_DELIV_CHAN_ACTIVE       = 'active'            # boolean; Is user using this item or not?
IH_DELIV_CHAN_CUSTOM       = 'custom'            # boolean; user-entered = true; default = false

# delivery channel package records (Delivery Channel Mode only)

IH_DELIV_CHAN_PACK_ID     = IH_F_DELIV_CHAN_PACK_ID # string;  numeric mstID for defaults. GUID for customs.
IH_DELIV_CHAN_PACK_NAME   = 'name'                  # string;  Holds custom name or overridden default name.
IH_DELIV_CHAN_PACK_ACTIVE = 'active'                # boolean; For defaults only.
IH_DELIV_CHAN_PACK_CUSTOM = 'custom'                # boolean; user-entered = true; default = false

# national programme records (Delivery Channel Mode only)

IH_NAT_PROG_ID     = IH_F_NAT_PROG_ID # string;  numeric mstID for defaults. GUID for customs.
IH_NAT_PROG_NAME   = 'name'           # string;  Holds custom name or overridden default name.
IH_NAT_PROG_ACTIVE = 'active'         # boolean; For defaults only.
IH_NAT_PROG_CUSTOM = 'custom'         # boolean; user-entered = true; default = false

# aduit records (tool that is used when an IHT projection is loaded)

IH_AUDIT_STATUS_OVERRIDDEN = 'statusOverridden'
IH_AUDIT_COMMENT           = 'comment'

# health system administrative units

IH_HEALTH_SYS_ADMIN_UNIT_ID                 = IH_F_HEALTH_SYS_ADMIN_UNIT_ID  # string;  numeric mstID for defaults. GUID for customs.
IH_HEALTH_SYS_ADMIN_UNIT_STR_CONSTANT       = 'stringConstant'        # string;  Defaults only.
IH_HEALTH_SYS_ADMIN_UNIT_NAME               = 'name'                  # string;  Holds custom name or overridden default name.
IH_HEALTH_SYS_ADMIN_UNIT_ACTIVE             = 'active'                # boolean; Is user using this item or not?
IH_HEALTH_SYS_ADMIN_UNIT_CUSTOM             = 'custom'                # boolean; user-entered = true; default = false
IH_HEALTH_SYS_ADMIN_UNIT_NUMBER             = 'number'                # integer

