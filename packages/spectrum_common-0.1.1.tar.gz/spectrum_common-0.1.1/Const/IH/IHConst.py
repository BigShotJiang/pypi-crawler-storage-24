# NOTE: If you use any of the constants below, please change the UH to IH before using them.
# This will signal that the constant is actually being used. Otherwise, the constant is just
# a carryover from the desktop.

# This unit declares constants used throughout the module and the other IHT
# modules. Try to use as many standard global constants from GB as possible
# (ex: GB_NOERROR, GB_MAX_PROJ).

from SpectrumCommon.Const.GB import *

# Database latest versions
IH_EXCHANGE_RATE_DB_CURR_VERSION = 'V2'

# Database names (also the names of the sheets in IHModData.xlsx)
IH_EXCHANGE_RATE_DB_NAME = 'ExchangeRateDB'

# Database directories for data by country. Files in these folders are named using the 3 letter iso country codes instead of the database names above.
IH_EXCHANGE_RATE_DB_DIR = r'ExchangeRate\countries'

# Data Import tool version
IH_DATA_IMPORT_TOOL_VERSION = 'V1'

# Any user-entered item must have an ID of 10000 or higher so the ID does not potentially overlap with defaults.
IH_MIN_CUSTOM_ITEM_ID = 10000

# Constants for writing to file 
UH_Version1       = 1.0
UH_Version2       = 1.1
UH_Version3       = 1.2
UH_Version4       = 1.3
UH_Version5       = 1.4
UH_DataFileTitle  = 'Unified Health Model (UHM) Data File'
UH_DataFileTitle2 = 'OneHealth Tool (OHT) Core Data File'
UH_MinColCount    = 12

# Locked projection constants 
UH_LockAreas = 1
UH_LoadAreas = 2

# Maximum number of regions the user can enter 
UH_MaxRegions = 100

# Maximum total number of interventions that the user can have in IHT. 
#UH_MaxTotalInterventions = UH_NumDefaultIntervs + UH_MaxCustomInterventions

# UHM Mode constants. 
UH_ProgAreaMode  = 1
UH_DelivChanMode = 2

# Default delivery channel IDs. 

IH_COMMUNITY_CHAN_CURR_ID             = 1
IH_OUTREACH_CHAN_CURR_ID              = 2
IH_PREHOSPITAL_EMERGENCY_CHAN_CURR_ID = 3
IH_GEN_OUTPATIENT_SERV_CHAN_CURR_ID   = 4
IH_FIRST_REFERRAL_CHAN_CURR_ID        = 5
IH_SEC_REFERRAL_CHAN_CURR_ID          = 6
IH_NUM_DEFAULT_DELIV_CHANS_COSTED     = IH_SEC_REFERRAL_CHAN_CURR_ID # Applies to IHT and TB but no longer CS

IH_COMMUNITY_CHAN_CURR_ID_CS             = 1
IH_OUTREACH_CHAN_CURR_ID_CS              = 2
IH_CLINICAL_CURR_ID_CS                   = 3
IH_HOSPITAL_CHAN_CURR_ID_CS              = 4
IH_NUM_DEFAULT_DELIV_CHANS_COSTED_CS     = 4 # Community, Outreach, Clinic, Hospital (See below for mapping)

IH_NO_CHAN_MST_ID = 0 

IH_COMMUNITY_CHAN_MST_ID              = 1 # Community
IH_OUTREACH_CHAN_MST_ID               = 2 # Now un-DEFUNCT - Outreach; WAS part of General outpatient services
IH_CLINIC_CHAN_MST_ID                 = 3 # DEFUNCT - Clinic; part of General outpatient services now
IH_FIRST_REFERRAL_CHAN_MST_ID         = 4 # Hospital --> First referral
IH_PREHOSPITAL_EMERGENCY_CHAN_MST_ID  = 5 # Prehospital emergency 
IH_GEN_OUTPATIENT_SERV_CHAN_MST_ID    = 6 # General outpatient services (Clinic gets rolled into this)
IH_SEC_REFERRAL_CHAN_MST_ID           = 7 # Second referral and above

IH_MAX_DELIV_CHANS_COSTED = 15

# Default delivery channel package current IDs. 

# Community 
UH_FamPrevWASHServ  = 1
UH_FamNeonatalCare  = 2
UH_InfantChildFeed  = 3
UH_CommIllnessManag = 4

# Outreach 
UH_PrevCareAdolAdul  = 1
UH_PrevPregnancyCare = 2
UH_HIVAIDSPrevCare   = 3
UH_PrevInfChildCare  = 4

# Clinic 
UH_MatNeonCareClinic  = 1
UH_ManagIllnessClinic = 2

# Hospital 
UH_ClinicFirstRefCare = 1
UH_ClinicSecRefCare   = 2

# Constant for the maximum number of packages each delivery channel can
# have. 
UH_MaxNumPacksPerDelivChan = 4

# Constant for whether to consider costed delivery channels, non-costed
# delivery channels, or both. 
UH_CostedDelivChans    = 1
UH_NonCostedDelivChans = 2
UH_AllDelivChans       = 3

# Constants for the various levels available in delivery channel mode. 
UH_NatProgramLev = 1
UH_DelivChanLev  = 2
UH_PackageLev    = 3
UH_NumDCMLevels  = 3

# Display Summary Costs constants for Costing Type 
UH_ActualCosts      = 0
UH_IncrementalCosts = 1

#  Row for 'Actual costs'/'Planned expenditures' in the UH Summary Costs
# indicator table. 
UH_TotSumCosts = 50

# Maximum number of facility types the user can enter. 
UH_MaxFacTypes = 20

# Maximum number of program areas the user can enter. 
IH_MAX_PROG_AREAS  = 50

# Maximum number of subgroups allowed in a given program area 
IH_MAX_SUBGROUPS = 20

# Below are the master program area IDs. The master ID for a particular
# program area will never change and should correspond to the master IDs for
# the groups in GroupDB.csv. These master IDs should be used to identify
# program areas in all databases. 
IH_ALL_PROG_AREAS_MST_ID          = 0
IH_MATERNAL_NEWBORN_HEALTH_MST_ID = 1
IH_SEXUAL_REPROD_HEALTH_MST_ID    = 111
UH_ChildHealthMstID               = 15
UH_VaccinationMstID               = 20
UH_MalariaMstID                   = 21
IH_TB_MST_ID                      = 22
IH_HIV_AIDS_MST_ID                = 23
UH_NutritionMstID                 = 28
UH_WASHMstID                      = 29
IH_NCD_MST_ID                     = 30 # NCD = Non-communicable diseases
UH_MentalNueroSubsUseDisMstID     = 42
UH_AdolescentHealthMstID          = 73
IH_NTD_MST_ID                     = 74 # NTD = Neglected tropical diseases
UH_NumDefProgramAreas             = 13

IH_LC_PERICONCEPTUAL_MST_ID = 1
IH_LC_PREGNANCY_MST_ID = 4
IH_LC_CHILDBIRTH_MST_ID = 7
IH_LC_BREASTFEEDING_MST_ID = 13
IH_LC_POSTNATAL_PREV_MST_ID = 14
IH_LC_VACCINES_MST_ID = 15
IH_LC_POSTNATAL_CURATIVE_MST_ID = 16

IH_LC_PROG_AREA_MST_IDS = [IH_LC_PERICONCEPTUAL_MST_ID, IH_LC_PREGNANCY_MST_ID, IH_LC_CHILDBIRTH_MST_ID, IH_LC_BREASTFEEDING_MST_ID,
  IH_LC_POSTNATAL_PREV_MST_ID, IH_LC_VACCINES_MST_ID, IH_LC_POSTNATAL_CURATIVE_MST_ID]

# TIME Econ - For each active pathway, if using target populations from DAT,
# we create a custom intervention and assign it to a special programme area in
# TIME Econ. Default interventions belong to a different group structure
# than the programme areas. It's the same group structure LiST Costing uses
# (from the IV module).
# 
#TIME Econ will also have a custom programme area for custom interventions. 
UH_TE_ActivePathProgArea    = 1
UH_TE_CustomIntervsProgArea = 2

# Special programme areas that are not created by default but need a
# master ID so that it can be referred to specifically. 
UH_HPVMstID                 = 31
UH_WorkersHealthMstID       = 32
UH_ActiveCaseFindingMstID   = 33

#HPV transfers
UH_manufactToCentral = 1
UH_CentralToInterm   = 2
UH_IntermToFacility  = 3
UH_MaxHPVTransfer    = 3

UH_DefHPVCost = 500000

UH_Age15To44 = 1
UH_Age45To54 = 2
UH_Age55To64 = 3
UH_Age65ToXX = 4
UH_NumHPVAges = 4

UH_MaxHPVOutReach = 4

UH_Age15 = 15
UH_Age45 = 45
UH_Age55 = 55
UH_Age65 = 65
UH_Age75 = 75

UH_HPVUnDiscount = 1
UH_HPVDiscount   = 2
UH_HPVLifesYears = 2

UH_HPVstartAge = 15
UH_HPVEndAge   = 75

UH_HPVPreVaccine = 1
UH_HPVPostVaccine = 2
UH_HPVDiffVaccine = 3
UH_HPVNumVaccineDisp = 2

# intervention group IDS for TB, may be removed later when dynamic groups are created
# constants come from groupDB.csv file
UH_mstNotificationSubGrp = 31
UH_mstMDRNotiSubGrp      = 32
UH_mstCollabTBHIVSubGrp  = 33

# Year constants 
UH_FirstYear = 1
UH_FinalYear = 2

#IC Drugs/Supplies 
UH_malariaSupplies        = 1
UH_ChildHealthSupplies    = 3
UH_ContraceptiveSupplies  = 5
UH_EPIPM                  = 6
UH_EquipmentSupplies      = 7
UH_HIVCareTreatment       = 11
UH_ITNs                   = 18
UH_MaternalHealthSupplies = 20
UH_NutritionSupplies      = 23
UH_TBSupplies             = 28
UH_VaccineSupplies        = 31
UH_AllOtherSupplies       = 34

# Constants indicating which data set to use (default or user-entered
# data)
UH_Default = 1
UH_Data    = 2

#*************************************************************************
#***************************   Area constants   **************************
#*************************************************************************

# Area type constants 
IH_PROG_AREA_MST_ID                 = 1
IH_DELIV_CHAN_MST_ID                = 2
IH_DELIV_CHAN_PACK_MST_ID           = 3
IH_NAT_PROG_MST_ID                  = 4
IH_HEALTH_SYS_MST_ID                = 5
IH_TOOL_MST_ID                      = 6
IH_MODULE_MST_ID                    = 7
IH_PPLI_MST_ID                      = 8
IH_SOCIAL_ENABLERS_MST_ID           = 9

# Health Systems / Programme Management (HSPM) constants 
IH_HEALTH_WORKFORCE_HSPM_MST_ID      = 1
IH_INFRASTRUCTURE_HSPM_MST_ID        = 2
IH_LOGISTICS_HSPM_MST_ID             = 3
IH_HEALTH_FINANCING_HSPM_MST_ID      = 4
IH_HEALTH_INFORM_SYSTEMS_HSPM_MST_ID = 5
IH_GOVERNANCE_HSPM_MST_ID            = 6
IH_FINANCIAL_SPACE_HSPM_MST_ID       = 7
IH_NUM_HEALTH_SYSTEMS                = 7

# Audit item (AI) constants 
# Health services
UH_AI_DirectEntryTargPop0Intervs      = 1
UH_AI_FirstAuditItem                  = UH_AI_DirectEntryTargPop0Intervs
UH_AI_FirstHealthServicesItem         = UH_AI_DirectEntryTargPop0Intervs
UH_AI_IntervsNoTreatInputs            = 2
UH_AI_DrugSupplyUsedCostZero          = 3
UH_AI_PercDelivTreatInputMismatch     = 4
UH_AI_CostPerAvgCaseZero              = 5
UH_AI_IntervsScaledDownCoverage       = 6
UH_AI_IntervsConstantCoverage         = 7
UH_AI_ModernFPMethodsHighCoverage     = 8
UH_AI_ModernFPMethodsCovIncrTooFast   = 9
UH_AI_Adults2ndLineARTHighCoverage    = 10
UH_AI_PCAreaTotalsNonZero             = 11
UH_AI_HealthServicesCostTooHigh       = 12
UH_AI_FinalHealthServicesItem         = UH_AI_HealthServicesCostTooHigh
# Logistics 
UH_AI_WastageFilledIn                 = 13
UH_AI_FirstLGItem                     = UH_AI_WastageFilledIn
UH_AI_DrugsSuppliesHighCost           = 14
UH_AI_FinalLGItem                     = UH_AI_DrugsSuppliesHighCost
# Human Resources 
UH_AI_TotalCompensTooHigh             = 15
UH_AI_FirstHRItem                     = UH_AI_TotalCompensTooHigh
UH_AI_StaffTimeUtilizFilledIn         = 16
UH_AI_StaffCapUtilizTooHigh           = 17
UH_AI_KeyStaffCritThresholdReached    = 18
UH_AI_StaffTotalScaledDown            = 19
UH_AI_FinalHRItem                     = UH_AI_StaffTotalScaledDown
# Infrastructure 
UH_AI_FacilNoOpCosts                  = 20
UH_AI_FirstISItem                     = UH_AI_FacilNoOpCosts
UH_AI_FacilBuildEquipOpCostsTooHigh   = 21
UH_AI_FinalISItem                     = UH_AI_FacilBuildEquipOpCostsTooHigh
# Health Information Systems 
UH_AI_HSCostsNonZero                  = 22
UH_AI_FirstHSItem                     = UH_AI_HSCostsNonZero
UH_AI_HSCostsTooHigh                  = 23
UH_AI_FinalHSItem                     = UH_AI_HSCostsTooHigh
# Health Financing 
UH_AI_HFCostsNonZero                  = 24
UH_AI_FirstHFItem                     = UH_AI_HFCostsNonZero
UH_AI_HFCostsTooHigh                  = 25
UH_AI_FinalHFItem                     = UH_AI_HFCostsTooHigh
# Governance 
UH_AI_GVCostsNonZero                  = 26
UH_AI_FirstGVItem                     = UH_AI_GVCostsNonZero
UH_AI_GetGVCostsTooHigh               = 27
UH_AI_FinalGVItem                     = UH_AI_GetGVCostsTooHigh
UH_AI_NumAuditItems                   = UH_AI_GetGVCostsTooHigh

# Set of all audit items that are the first items under their headings. 
UH_AI_FirstItems = [UH_AI_FirstHealthServicesItem, UH_AI_FirstLGItem,
  UH_AI_FirstHRItem, UH_AI_FirstISItem, UH_AI_FirstHSItem, UH_AI_FirstHFItem,
  UH_AI_FirstGVItem]

# Set of all audit items allowing the user to click a button to view
# details AND FIX the problem. 
UH_AI_DetailsAvailableSet = [UH_AI_DirectEntryTargPop0Intervs,
  UH_AI_IntervsNoTreatInputs, UH_AI_DrugSupplyUsedCostZero,
  UH_AI_PercDelivTreatInputMismatch, UH_AI_CostPerAvgCaseZero,
  UH_AI_IntervsScaledDownCoverage, UH_AI_IntervsConstantCoverage,
  UH_AI_StaffTimeUtilizFilledIn, UH_AI_StaffCapUtilizTooHigh,
  UH_AI_PCAreaTotalsNonZero]

# Set of all audit items allowing the user to click a button to DIRECTLY
# FIX them without going to an intermediate form to view details first. 
UH_AI_FixDirectLinkSet = [UH_AI_ModernFPMethodsHighCoverage,
  UH_AI_ModernFPMethodsCovIncrTooFast, UH_AI_Adults2ndLineARTHighCoverage,
  UH_AI_WastageFilledIn]

# Set of all audit items allowing the user to click a button to view details
# BUT NOT FIX the problems. 
UH_AI_ShowDetailsNoFixSet = [UH_AI_DrugsSuppliesHighCost,
  UH_AI_TotalCompensTooHigh, UH_AI_StaffTotalScaledDown,
  UH_AI_FacilNoOpCosts, UH_AI_FacilBuildEquipOpCostsTooHigh,
  UH_AI_StaffCapUtilizTooHigh]

# All audit items that list interventions. 

UH_AI_InterventionsSet = [UH_AI_DirectEntryTargPop0Intervs,
  UH_AI_IntervsNoTreatInputs, UH_AI_PercDelivTreatInputMismatch,
  UH_AI_IntervsScaledDownCoverage, UH_AI_IntervsConstantCoverage]

# All audit items that list custom staff types. 

UH_AI_StaffTypesSet = [UH_AI_TotalCompensTooHigh,
  UH_AI_StaffTimeUtilizFilledIn, UH_AI_StaffTotalScaledDown]

# All audit items that list drugs and supplies. 

UH_AI_DrugSupplySet = [UH_AI_DrugSupplyUsedCostZero,
  UH_AI_DrugsSuppliesHighCost]

# All audit items that list facilities. 

UH_AI_FacilitiesSet = [UH_AI_FacilNoOpCosts,
  UH_AI_FacilBuildEquipOpCostsTooHigh]

UH_StandardTotalCosts = 1
UH_PHC_TotalCosts     = 2
UH_TotalCostTypes     = UH_PHC_TotalCosts

# Custom intervention types
# 
#      IHT :
#       Standard and active pathway. Both types managed by UH.
# 
#      TIME Econ :
#        Standard and active pathway. Standard managed by IV, active pathway
#        managed by UH.
# 
#      LiST Costing :
#        Standard. Managed by IV.

UH_AnyCustomInterv           = 1
UH_StdCustomInterv           = 2
UH_ActivePathwayCustomInterv = 3

IH_INTERVENTION_DB_NAME = ''
IH_GROUP_DB_NAME        = ''

IH_COMPREHENSIVE_PLAN = 0
IH_SPECIFIC_PLAN      = 1

# Staff capacity utilization result is number of programme areas + these 3 things long in the first dimension.
IH_SCU_TRAINING                  = 1
IH_SCU_TASKS_OTHER_THAN_TRAINING = 2
IH_SCU_FTE_AVAILABLE             = 3
IH_STAFF_CAP_UTIL_EXTRAS         = 3

# Health system administration unit (HSAU) defaults

IH_NATIONAL_HSAU_MST_ID         = 1 
IH_PROVINCE_HSAU_MST_ID         = 2
IH_DISTRICT_HSAU_MST_ID         = 3
IH_ADMIN_LEVEL_4_HSAU_MST_ID    = 4 
IH_ADMIN_LEVEL_5_HSAU_MST_ID    = 5 