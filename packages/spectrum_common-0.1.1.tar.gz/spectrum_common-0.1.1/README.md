# spectrum-common

Shared constants, model variable helpers, and utilities used by Spectrum Engine tools.

## Install

```bash
pip install spectrum-common
```

## Notes

This package publishes the `SpectrumCommon` namespace and subpackages.
