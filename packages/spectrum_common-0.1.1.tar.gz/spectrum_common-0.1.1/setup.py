from setuptools import find_packages, setup


subpackages = [pkg for pkg in find_packages(where=".") if not pkg.startswith("SpectrumCommon")]

packages = ["SpectrumCommon"]
package_dir = {"SpectrumCommon": "."}

for package_name in subpackages:
    full_name = f"SpectrumCommon.{package_name}"
    packages.append(full_name)
    package_dir[full_name] = package_name.replace(".", "/")


setup(
    packages=packages,
    package_dir=package_dir,
)
