from SpectrumCommon.Const.DP import DP_BigPopTag
from SpectrumCommon.Const.IC import IC_INTERV_RECORDS_TAG, IC_F_INTERV_ID
import SpectrumCommon.Const.NC as ncc
from SpectrumCommon.Const.PJ import PJN_FirstYearTag, PJN_FinalYearTag

def call_ncd_model(modvars):
    year_len = modvars[PJN_FinalYearTag]-[PJN_FirstYearTag]+1
    interv_id_list = []
    interv_info = []
    ncd_results = []
    for rec in modvars[IC_INTERV_RECORDS_TAG] :
        if(rec[IC_F_INTERV_ID] in interv_id_list):
            interv_info.append(rec)
            ncd_res = {
                IC_F_INTERV_ID:rec[IC_F_INTERV_ID],
                'targetPop': [0.0]*year_len,
            }
            ncd_results.append(ncd_res)

    # interv_coverages = [rec for rec in modvars[IC_INTERV_RECORDS_TAG] if rec['id']=='']
    
    package = {
        'firstYear':modvars[PJN_FirstYearTag], #Int
        'finalYear':modvars[PJN_FinalYearTag], #Int
        'interventions': interv_info, 
        'pop':modvars[DP_BigPopTag], #Sex, Age, Time
        'asthma':{
            'IncidenceResult'  : modvars[ncc.NC_AsthmaIncidenceResultTag],
            'PrevalnceResult'  : modvars[ncc.NC_AsthmaPrevalnceResultTag],
            'MortalityResult'  : modvars[ncc.NC_AsthmaMortalityResultTag],
            'RemissionResult'  : modvars[ncc.NC_AsthmaRemissionResultTag],
            'RecurrenceResult' : modvars[ncc.NC_AsthmaRecurrenceResultTag],
            'HYLResult'        : modvars[ncc.NC_AsthmaHYLResultTag],
            'YLDResult'        : modvars[ncc.NC_AsthmaYLDResultTag],
            'DWResult'         : modvars[ncc.NC_AsthmaDWResultTag],
        }
    }
    
    return None