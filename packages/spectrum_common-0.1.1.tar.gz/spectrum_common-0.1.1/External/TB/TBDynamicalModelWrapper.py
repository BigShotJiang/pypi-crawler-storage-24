from os import environ, getcwd
from requests import get
import time

from AvenirCommon.Database import GB_get_db_json


from SpectrumCommon.Const.PJ import PJN_ISO3AlphaTag, PJN_FinalYearTag
import SpectrumCommon.Const.TB as tbc
from SpectrumCommon.Const.DP import DP_BigPopTag
from SpectrumCommon.Const.GB import GB_BothSexes

from SpectrumCommon.Const.GB.GBVersions import TB_FORT_OUTPUT_VERSION, TB_WHO_DB_VERSION
from SpectrumCommon.External.TB.FinalModel2.SpectrumWebConnect import run_dynamical_model
# from Calc.TB.TBEstimateIntervImpacts import TB_EstimateInterventionImpacts

import numpy as np
from loguru import logger


def get_tb_dynamical_outputs(ISO3, reported_year=None, reported_notif=None, vsn=TB_FORT_OUTPUT_VERSION):
    fort_outputs = GB_get_db_json(environ['AVENIR_SW_DEFAULT_DATA_CONNECTION'], 'tuberculosis', f'fort/outputs/{ISO3}_{vsn}.JSON')

    # Rescaling notification to the reported 2021 values
    # idx   = reported_year-TB_FirstHist_Year
    # scale = reported_notif/fort_outputs['nMid'][idx]
    # fort_outputs['nMid'][idx:] = scale*np.array(fort_outputs['nMid'][idx:])
    # fort_outputs['nLo'][idx:]  = scale*np.array(fort_outputs['nLo'][idx:])
    # fort_outputs['nHi'][idx:]  = scale*np.array(fort_outputs['nHi'][idx:])
    # fort_outputs['nSd'][idx:]  = scale*np.array(fort_outputs['nSd'][idx:])
 
    return fort_outputs


def get_tb_dynamical_version():
    fort_url = environ.get("AVENIR_SW_FORT_URL", "https://tbbetafort-server.azurewebsites.net")
    response = get(f'{fort_url}/version')
    return response.json()['version']

def call_tb_dynamical(ISO3, prm_modvar, xs_modvar, pop_data_modvar, Hi_scn, Hi_ref, TxTSFL_scn, TxTSFL_ref, Hd_scn, Hd_ref, firstImpactYr, finalImpactYr, finalYr):
    epi_outputs_base = None
    final_model_path = getcwd()+ '/SpectrumCommon/External/TB/FinalModel2'
    # ones = Hd_scn/Hd_scn
    # Hd_scn=ones*1.3
    # Hd_ref=ones*1


    # Hi_scn=ones*0.03
    # Hi_ref=ones*0.02

    # TxTSFL_scn=ones*0.90
    # TxTSFL_ref=ones*0.84
    
    # with open(f'TB_DYN_MODEL/{ISO3}/inputs/PRM_Modvar.JSON', 'w+') as fp:
    #     ujson.dump(prm_modvar, fp)
    # with open(f'TB_DYN_MODEL/{ISO3}/inputs/xs_Modvar.JSON', 'w+') as fp:
    #     ujson.dump(xs_modvar, fp)
    # with open(f'TB_DYN_MODEL/{ISO3}/inputs/pop_data_Modvar.JSON', 'w+') as fp:
    #     pop_data_modvar['HIV_prev'] = pop_data_modvar['HIV_prev'].tolist()
    #     ujson.dump(pop_data_modvar, fp)
    #     pop_data_modvar['HIV_prev'] = np.array(pop_data_modvar['HIV_prev'])
    # with open(f'TB_DYN_MODEL/{ISO3}/inputs/Hi_scn.JSON', 'w+') as fp:
    #     ujson.dump(Hi_scn, fp)
    # with open(f'TB_DYN_MODEL/{ISO3}/inputs/Hi_ref.JSON', 'w+') as fp:
    #     ujson.dump(Hi_ref, fp)
    # with open(f'TB_DYN_MODEL/{ISO3}/inputs/TxTSFL_scn.JSON', 'w+') as fp:
    #     ujson.dump(TxTSFL_scn, fp)
    # with open(f'TB_DYN_MODEL/{ISO3}/inputs/TxTSFL_ref.JSON', 'w+') as fp:
    #     ujson.dump(TxTSFL_ref, fp)
    # with open(f'TB_DYN_MODEL/{ISO3}/inputs/Hd_ref.JSON', 'w+') as fp:
    #     ujson.dump(Hd_ref, fp)
    # with open(f'TB_DYN_MODEL/{ISO3}/inputs/Hd_scn.JSON', 'w+') as fp:
    #     ujson.dump(Hd_scn, fp)
    # Outputs_Scn = [[np.ones(9)]*8, [np.ones(9)]*8]
    Outputs_Scn = run_dynamical_model(ISO3, prm_modvar, xs_modvar, pop_data_modvar, Hi_scn, Hi_ref, TxTSFL_scn, TxTSFL_ref, Hd_scn, Hd_ref, firstImpactYr, finalImpactYr, finalYr, final_model_path)
    # with open(f'TB_DYN_MODEL/{ISO3}/results/model_outputs_scn.JSON', 'r') as fp: 
    #     Outputs_Scn = ujson.load(fp)
        
    #     for i, scen in enumerate(Outputs_Scn):
    #         for j, ind in enumerate(Outputs_Scn[i]):
    #             Outputs_Scn[i][j] = np.array(Outputs_Scn[i][j])
    # for i,e in enumerate(prm_modvar['rHIV']):
    #     prm_modvar['rHIV'][i] = e.tolist() 
    # prm_modvar['N'] = prm_modvar['N'].tolist() 
    # prm_modvar['gth'] = prm_modvar['gth'].tolist()
    # prm_modvar['r']['ageing'] = prm_modvar['r']['ageing'].tolist()
    # prm_modvar['r']['self_cure'] = prm_modvar['r']['self_cure'].tolist()
    # if 'error' in fort_outputs:
        # raise Exception('TB Fort API called failed')
        
    # with open(f'TB_DYN_MODEL/{ISO3}/results/model_outputs_scn.JSON', 'w+') as fp:
    #     for i, scen in enumerate(Outputs_Scn):
    #         for j, ind in enumerate(Outputs_Scn[i]):
    #             Outputs_Scn[i][j] = Outputs_Scn[i][j].tolist()
    #     ujson.dump(Outputs_Scn, fp)
    #     for i, scen in enumerate(Outputs_Scn):
    #         for j, ind in enumerate(Outputs_Scn[i]):
    #             Outputs_Scn[i][j] = np.array(Outputs_Scn[i][j])
               
    return Outputs_Scn


def calculate_dynamical_impacts(modvars):
    ISO3       = modvars[PJN_ISO3AlphaTag]
    final_year = modvars[PJN_FinalYearTag]
    final_history_year = modvars[tbc.TB_FinalHistoricalYearTag]
    base_year  = modvars[tbc.TB_BaseYearTag]# deafult to TB_FirstHist_Year
    # yr_len = final_year - base_year + 1
    # import ujson
    # with open('TB_INDIA_11_20.JSON', 'w+') as fp:
    #     ujson.dump(modvars, fp)
    fort_out_version = modvars[tbc.TB_FortOutputVersionTag ]
    fort_outputs = GB_get_db_json(environ['AVENIR_SW_DEFAULT_DATA_CONNECTION'], 'tuberculosis', f'fort/outputs/{ISO3}_{fort_out_version}.JSON') 
    start = time.time()
    modvars[tbc.TB_DynPopDataTag]['HIV_prev'] =  np.array(modvars[tbc.TB_DynPopDataTag]['HIV_prev'])
    if len(modvars[tbc.TB_DynPRMTag]['r']['ageing'])==5 :
        modvars[tbc.TB_DynPRMTag]['r']['ageing'] = modvars[tbc.TB_DynPRMTag]['r']['ageing'][1: ]
       
    firstImpactYr  = modvars[tbc.TB_DynamicalFirstYearTag]
    finalImpactYr  = modvars[tbc.TB_DynamicalFinalYearTag]
    fiirstImpactIdx = firstImpactYr - base_year
    finalImpactIdx = finalImpactYr - base_year
    dyn_yr_slice = slice(0, final_year-base_year+1)
    Outputs_Scn = call_tb_dynamical(ISO3, 
                                      modvars[tbc.TB_DynPRMTag],
                                      None, # modvars[tbc.TB_DynXSTag],
                                      modvars[tbc.TB_DynPopDataTag],
                                      Hi_scn = modvars[tbc.TB_Scaleup_HRi_allTag][finalImpactIdx],
                                      Hi_ref = modvars[tbc.TB_Baseline_HRi_allTag][finalImpactIdx],
                                      TxTSFL_scn = modvars[tbc.TB_CurrentScenarioTag][tbc.TB_TreatmentSuccess][finalImpactIdx],
                                      TxTSFL_ref = modvars[tbc.TB_CounterfactualScenarioTag][tbc.TB_TreatmentSuccess][finalImpactIdx],
                                      Hd_scn = modvars[tbc.TB_TargNotificationTag][finalImpactIdx],
                                      Hd_ref = modvars[tbc.TB_CounterfactualNotifTag][finalImpactIdx],
                                      firstImpactYr=firstImpactYr,
                                      finalImpactYr=finalImpactYr,
                                      finalYr=final_year)
    
    if type(modvars[tbc.TB_DynPRMTag]['r']['cs_1997'])!=list:
        modvars[tbc.TB_DynPRMTag]['r']['cs_1997']  =  modvars[tbc.TB_DynPRMTag]['r']['cs_1997'].tolist()
        modvars[tbc.TB_DynPRMTag]['r']['cs_2022']  =  modvars[tbc.TB_DynPRMTag]['r']['cs_2022'].tolist()
        modvars[tbc.TB_DynPRMTag]['r']['cs2_1997'] =  modvars[tbc.TB_DynPRMTag]['r']['cs2_1997'].tolist()
        modvars[tbc.TB_DynPRMTag]['r']['cs2_2022'] =  modvars[tbc.TB_DynPRMTag]['r']['cs2_2022'].tolist()
    if len(modvars[tbc.TB_DynPRMTag]['r']['ageing'])==4 :
        modvars[tbc.TB_DynPRMTag]['r']['ageing'] = [0]+modvars[tbc.TB_DynPRMTag]['r']['ageing']
    
    numpy_type = type(np.array([]))
            
    for key in modvars[tbc.TB_DynPopDataTag]:
        if numpy_type == type(modvars[tbc.TB_DynPopDataTag][key]):
            modvars[tbc.TB_DynPopDataTag][key] = modvars[tbc.TB_DynPopDataTag][key].tolist()
    # tb_dyn_output = []
    # for i in range(0,10):
    #     tb_dyn_output.append(np.zeros(len(modvars[tbc.TB_ResNotificationTag][0])))
    # if 'error' in scaleup_results:
    #     modvars['timings']['TB_Dynamical'] = 'Failed'
    #     return None
    if 'timings' not in  modvars:
        modvars['timings'] = {}
    modvars['timings']['TB_Dynamical'] = time.time()-start
    big_pop_ratio = np.sum(modvars[DP_BigPopTag][GB_BothSexes], axis=0)/1e5
    
    for s in [tbc.TB_Counterfactual, tbc.TB_Scaleup]:
        noti = modvars[tbc.TB_ResNotificationTag][s].copy()
        inci = modvars[tbc.TB_ResIncidenceTag][s].copy()
        prev = modvars[tbc.TB_ResPrevalenceTag][s].copy()
        mort = modvars[tbc.TB_ResMortalityTag][s].copy()
        
        noti[dyn_yr_slice] = Outputs_Scn[s][5]*big_pop_ratio[dyn_yr_slice]
        inci[dyn_yr_slice] = Outputs_Scn[s][0]*big_pop_ratio[dyn_yr_slice]
        prev[dyn_yr_slice] = Outputs_Scn[s][7]*big_pop_ratio[dyn_yr_slice]
        mort[dyn_yr_slice] = (Outputs_Scn[s][3]+Outputs_Scn[s][4])*big_pop_ratio[dyn_yr_slice]
        
        logger.debug(f'BigPopRatio {big_pop_ratio}')
        logger.debug(f'noti {noti}')
        logger.debug(f'inci {inci}')
        logger.debug(f'prev {prev}')
        logger.debug(f'mort {mort}')
        
        idx = max(final_history_year-base_year, 0)
        fort_idx = final_history_year-2000
        noti_scale = fort_outputs['nMid'][fort_idx]/noti[idx]
        inci_scale = fort_outputs['iMid'][fort_idx]/inci[idx]
        mort_scale = fort_outputs['mMid'][fort_idx]/mort[idx]

        # noti_scale = fort_outputs['nMid'][tbc.TB_FinalHist_Year-2000]/noti[tbc.TB_FinalHist_Year-base_year]
        # inci_scale = fort_outputs['iMid'][tbc.TB_FinalHist_Year-2000]/inci[tbc.TB_FinalHist_Year-base_year]
        prev_scale = inci_scale
        # mort_scale = fort_outputs['mMid'][tbc.TB_FinalHist_Year-2000]/mort[tbc.TB_FinalHist_Year-base_year]
        logger.debug(f'noti scale {noti_scale}')
        logger.debug(f'inci scale {inci_scale}')
        logger.debug(f'prev scale {prev_scale}')
        logger.debug(f'mort scale {mort_scale}')
        pass
        modvars[tbc.TB_ResNotificationTag][s] = (noti*noti_scale).tolist()
        modvars[tbc.TB_ResIncidenceTag][s]    = (inci*inci_scale).tolist()
        modvars[tbc.TB_ResPrevalenceTag][s]   = (prev*prev_scale).tolist()
        modvars[tbc.TB_ResMortalityTag][s]    = (mort*mort_scale).tolist()
        
    # Notification TB_Counterfactual should match the locked baseline notification 
    # modvars[tbc.TB_ResNotificationTag][tbc.TB_Counterfactual] = modvars[tbc.TB_HisNotificationTag]
        
    # scaleup_HRd, scaleup_HRi, scaleup_HRi_all = TB_EstimateInterventionImpacts(yr_len, HH_Contacts, ART_Cohorts, HRGs, PatientInitiated, modvars[tbc.TB_ResPrevalenceTag][tbc.TB_Counterfactual], pop_sum)
    # modvars[tbc.TB_Scaleup_HRi_allTag] = scaleup_HRi_all

    modvars[tbc.TB_ResNotificationTag][tbc.TB_Difference] = modvars[tbc.TB_ResNotificationTag][tbc.TB_Scaleup] - modvars[tbc.TB_ResNotificationTag][tbc.TB_Counterfactual] 
    modvars[tbc.TB_ResIncidenceTag][tbc.TB_Difference]    = modvars[tbc.TB_ResIncidenceTag][tbc.TB_Counterfactual]    - modvars[tbc.TB_ResIncidenceTag][tbc.TB_Scaleup]
    modvars[tbc.TB_ResMortalityTag][tbc.TB_Difference]    = modvars[tbc.TB_ResMortalityTag][tbc.TB_Counterfactual]    - modvars[tbc.TB_ResMortalityTag][tbc.TB_Scaleup]
    modvars[tbc.TB_ResPrevalenceTag][tbc.TB_Difference]   = modvars[tbc.TB_ResPrevalenceTag][tbc.TB_Counterfactual]    - modvars[tbc.TB_ResPrevalenceTag][tbc.TB_Scaleup]
        
        
    # with open(f'TB_DYN_MODEL/{ISO3}/results/TB_ResNotificationTag.JSON', 'w+') as fp:
    #     ujson.dump(modvars[tbc.TB_ResNotificationTag].tolist(), fp)
    # with open(f'TB_DYN_MODEL/{ISO3}/results/TB_ResIncidenceTag.JSON', 'w+') as fp:
    #     ujson.dump(modvars[tbc.TB_ResIncidenceTag].tolist(), fp)
    # with open(f'TB_DYN_MODEL/{ISO3}/results/TB_ResMortalityTag.JSON', 'w+') as fp:
    #     ujson.dump(modvars[tbc.TB_ResMortalityTag].tolist(), fp)
    # with open(f'TB_DYN_MODEL/{ISO3}/results/TB_ResPrevalenceTag.JSON', 'w+') as fp:
    #     ujson.dump(modvars[tbc.TB_ResPrevalenceTag].tolist(), fp)
    
    db =  GB_get_db_json(environ['AVENIR_SW_DEFAULT_DATA_CONNECTION'], 'tuberculosis', f'countries\\{ISO3}_{TB_WHO_DB_VERSION}.JSON')
    db_year_index = tbc.TB_FinalHist_Year-db['burden']['startYear']
    e_inc_num    = db['burden']['e_inc_num'][db_year_index]
    e_inc_num_lo = db['burden']['e_inc_num_lo'][db_year_index]
    e_inc_num_hi = db['burden']['e_inc_num_hi'][db_year_index]
    
    e_mort_num    = db['burden']['e_mort_num'][db_year_index]
    e_mort_num_lo = db['burden']['e_mort_num_lo'][db_year_index]
    e_mort_num_hi = db['burden']['e_mort_num_hi'][db_year_index]
    
    modvars[tbc.TB_FortNotificationTag][tbc.TB_ResMidIdx]   = modvars[tbc.TB_ResNotificationTag][tbc.TB_Counterfactual]
    modvars[tbc.TB_FortNotificationTag][tbc.TB_ResLowerIdx] = 0.9*modvars[tbc.TB_ResNotificationTag][tbc.TB_Counterfactual]
    modvars[tbc.TB_FortNotificationTag][tbc.TB_ResUpperIdx] = 1.1*modvars[tbc.TB_ResNotificationTag][tbc.TB_Counterfactual]
    modvars[tbc.TB_FortNotificationTag][tbc.TB_ResSdIdx]    = modvars[tbc.TB_ResNotificationTag][tbc.TB_Counterfactual]

    modvars[tbc.TB_FortIncidenceTag][tbc.TB_ResMidIdx]   = modvars[tbc.TB_ResIncidenceTag][tbc.TB_Counterfactual]
    modvars[tbc.TB_FortIncidenceTag][tbc.TB_ResLowerIdx] = modvars[tbc.TB_ResIncidenceTag][tbc.TB_Counterfactual]*(e_inc_num_lo/e_inc_num)
    modvars[tbc.TB_FortIncidenceTag][tbc.TB_ResUpperIdx] = modvars[tbc.TB_ResIncidenceTag][tbc.TB_Counterfactual]*(e_inc_num_hi/e_inc_num)
    modvars[tbc.TB_FortIncidenceTag][tbc.TB_ResSdIdx]    = modvars[tbc.TB_ResIncidenceTag][tbc.TB_Counterfactual]

    modvars[tbc.TB_FortMortalityTag][tbc.TB_ResMidIdx]   = modvars[tbc.TB_ResMortalityTag][tbc.TB_Counterfactual]
    modvars[tbc.TB_FortMortalityTag][tbc.TB_ResLowerIdx] = modvars[tbc.TB_ResMortalityTag][tbc.TB_Counterfactual]*(e_mort_num_lo/e_mort_num)
    modvars[tbc.TB_FortMortalityTag][tbc.TB_ResUpperIdx] = modvars[tbc.TB_ResMortalityTag][tbc.TB_Counterfactual]*(e_mort_num_hi/e_mort_num)
    modvars[tbc.TB_FortMortalityTag][tbc.TB_ResSdIdx]    = modvars[tbc.TB_ResMortalityTag][tbc.TB_Counterfactual]

    modvars[tbc.TB_FortPrevalenceTag][tbc.TB_ResMidIdx]   = modvars[tbc.TB_ResPrevalenceTag][tbc.TB_Counterfactual]
    modvars[tbc.TB_FortPrevalenceTag][tbc.TB_ResLowerIdx] = modvars[tbc.TB_ResPrevalenceTag][tbc.TB_Counterfactual]*(e_inc_num_lo/e_inc_num)
    modvars[tbc.TB_FortPrevalenceTag][tbc.TB_ResUpperIdx] = modvars[tbc.TB_ResPrevalenceTag][tbc.TB_Counterfactual]*(e_inc_num_hi/e_inc_num)
    modvars[tbc.TB_FortPrevalenceTag][tbc.TB_ResSdIdx]    = modvars[tbc.TB_ResPrevalenceTag][tbc.TB_Counterfactual]
    
    
    logger.debug(f'noti after scaling {modvars[tbc.TB_ResNotificationTag][0] }')
        
    pass


        
    #scaleup_prev = calc_prevalence_from_notif_inci(np.array(scaleup_results['nMid']), np.array(scaleup_results['iMid']))[fort_slice]
    # scaleup_prev = scaleup_results['pMid'][fort_slice]
    # modvars[tbc.TB_ResPrevalenceTag][tbc.TB_Scaleup][tb_slice] = np.array(scaleup_prev)


    # # send results to modvars
    # modvars[tbc.TB_CurrentScenarioTag][tbc.TB_AvgProbDetect] = scaleup_HRd
    # modvars[tbc.TB_CurrentScenarioTag][tbc.TB_AvgProbReceivPrvnt] = scaleup_HRi
    # modvars[tbc.TB_Scaleup_HRi_allTag] = scaleup_HRi_all


    # # db =  GB_get_db_json(environ['AVENIR_SW_DEFAULT_DATA_CONNECTION'], 'tuberculosis', 'countries\\'+ISO3+'_V1.JSON')

    # # idx = TB_FinalHist_Year-base_year
    # # db_idx = TB_FinalHist_Year-db['projections']['startYear']
    # # scale = modvars[tbc.TB_HisNotificationTag][idx]/db['projections']['notification'][db_idx]
    # if modvars[tbc.TB_UseOldFailsafeTag]:
    #     fort_vsn = '_V2'
    # elif  modvars[tbc.TB_UseOldIPTag]:
    #     fort_vsn = '_V3'
    # else: 
    #     fort_vsn = '_V5' 
    # fort_outputs = tb_dyn.get_tb_dynamical_outputs(ISO3=ISO3, vsn=fort_vsn)
    # # fort_outputs = GB_get_db_json(environ['AVENIR_SW_DEFAULT_DATA_CONNECTION'], 'tuberculosis', 'fort/outputs/'+ISO3+fort_vsn+'.JSON') 
    
    # if modvars[tbc.TB_UseOldFailsafeTag]:
    #     scale = modvars[tbc.TB_HisNotificationTag][0]/fort_outputs['nMid'][base_year-2000]
    # if modvars[tbc.TB_UseOldIPTag]:
    #     scale = modvars[tbc.TB_HisNotificationTag][0]/fort_outputs['nMid'][base_year-2000]
    # else:
    #     scale = modvars[tbc.TB_HisNotificationTag][tbc.TB_FinalHist_Year-base_year]/fort_outputs['nMid'][tbc.TB_FinalHist_Year-2000]
    
    # # fort_outputs = get_tb_fort_outputs(ISO3, TB_FinalHist_Year, modvars[tbc.TB_HisNotificationTag][0])
    # # if modvars[tbc.TB_UseOldFailsafeTag]:
    #     # scale = modvars[tbc.TB_HisNotificationTag][0]/fort_outputs['nMid'][tbc.TB_FinalHist_Year-2000]

    # modvars[tbc.TB_ResNotificationTag][tbc.TB_Scaleup][tb_slice] = np.array(scaleup_results['nMid'][fort_slice])*scale
    # modvars[tbc.TB_ResIncidenceTag][tbc.TB_Scaleup][tb_slice]    = scaleup_results['iMid'][fort_slice]
    # modvars[tbc.TB_ResMortalityTag][tbc.TB_Scaleup][tb_slice]    = scaleup_results['mMid'][fort_slice]

    
    modvars[tbc.TB_ResNotificationTag][tbc.TB_Difference] = modvars[tbc.TB_ResNotificationTag][tbc.TB_Scaleup] - modvars[tbc.TB_ResNotificationTag][tbc.TB_Counterfactual] 
    modvars[tbc.TB_ResIncidenceTag][tbc.TB_Difference]    = modvars[tbc.TB_ResIncidenceTag][tbc.TB_Counterfactual]    - modvars[tbc.TB_ResIncidenceTag][tbc.TB_Scaleup]
    modvars[tbc.TB_ResMortalityTag][tbc.TB_Difference]    = modvars[tbc.TB_ResMortalityTag][tbc.TB_Counterfactual]    - modvars[tbc.TB_ResMortalityTag][tbc.TB_Scaleup]
    modvars[tbc.TB_ResPrevalenceTag][tbc.TB_Difference]   = modvars[tbc.TB_ResPrevalenceTag][tbc.TB_Counterfactual]    - modvars[tbc.TB_ResPrevalenceTag][tbc.TB_Scaleup]


    # #Projection model results

    # modvars[tbc.TB_FortNotificationTag][tbc.TB_ResMidIdx][tb_slice]   = np.array(scaleup_results['nMid'][fort_slice])*scale
    # modvars[tbc.TB_FortNotificationTag][tbc.TB_ResLowerIdx][tb_slice] = np.array(scaleup_results['nLo'][fort_slice])*scale
    # modvars[tbc.TB_FortNotificationTag][tbc.TB_ResUpperIdx][tb_slice] = np.array(scaleup_results['nHi'][fort_slice])*scale
    # modvars[tbc.TB_FortNotificationTag][tbc.TB_ResSdIdx][tb_slice]    = np.array(scaleup_results['nSd'][fort_slice])*scale

    # modvars[tbc.TB_FortIncidenceTag][tbc.TB_ResMidIdx][tb_slice]   = scaleup_results['iMid'][fort_slice]
    # modvars[tbc.TB_FortIncidenceTag][tbc.TB_ResLowerIdx][tb_slice] = scaleup_results['iLo'][fort_slice]
    # modvars[tbc.TB_FortIncidenceTag][tbc.TB_ResUpperIdx][tb_slice] = scaleup_results['iHi'][fort_slice]
    # modvars[tbc.TB_FortIncidenceTag][tbc.TB_ResSdIdx][tb_slice]    = scaleup_results['iSd'][fort_slice]

    # modvars[tbc.TB_FortMortalityTag][tbc.TB_ResMidIdx][tb_slice]   = scaleup_results['mMid'][fort_slice]
    # modvars[tbc.TB_FortMortalityTag][tbc.TB_ResLowerIdx][tb_slice] = scaleup_results['mLo'][fort_slice]
    # modvars[tbc.TB_FortMortalityTag][tbc.TB_ResUpperIdx][tb_slice] = scaleup_results['mHi'][fort_slice]
    # modvars[tbc.TB_FortMortalityTag][tbc.TB_ResSdIdx][tb_slice]    = scaleup_results['mSd'][fort_slice]

    # modvars[tbc.TB_FortPrevalenceTag][tbc.TB_ResMidIdx][tb_slice]   = scaleup_results['pMid'][fort_slice]
    # modvars[tbc.TB_FortPrevalenceTag][tbc.TB_ResLowerIdx][tb_slice] = scaleup_results['pLo'][fort_slice]
    # modvars[tbc.TB_FortPrevalenceTag][tbc.TB_ResUpperIdx][tb_slice] = scaleup_results['pHi'][fort_slice]
    # modvars[tbc.TB_FortPrevalenceTag][tbc.TB_ResSdIdx][tb_slice]    = scaleup_results['pSd'][fort_slice]
    

    pass
