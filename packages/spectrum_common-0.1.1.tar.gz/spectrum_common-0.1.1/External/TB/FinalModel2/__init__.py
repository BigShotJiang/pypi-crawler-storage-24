"""SpectrumCommon TB FinalModel2 package."""
