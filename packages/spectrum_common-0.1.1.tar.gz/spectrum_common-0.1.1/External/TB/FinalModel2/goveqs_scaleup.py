from .goveqs_basis2 import goveqs_basis2

def goveqs_scaleup(input, t, r, M0, M1, times, i, prm, sel, agg):
    scale = min(max((t-times[0])/(times[1]-times[0]),0),1) # % <--- NEW: removed min(,1), so that model can continue extrapolating ART coverage into future
    Mt = M1.copy()
    Mt['lin'] = M0['lin'] + scale*(M1['lin']-M0['lin'])
    Mt['Dxlin'] =  M0['Dxlin'] + scale*(M1['Dxlin'] - M0['Dxlin']) #Mt.Dxlin =  M0.Dxlin + scale*(M1.Dxlin - M0.Dxlin);
    Mt['linHIV'] = M0['linHIV'] + scale*(M1['linHIV'] - M0['linHIV']) #Mt['linHIV'] = M0.linHIV + scale*(M1.linHIV - M0.linHIV);
    Mt['linLTBI'] = M0['linLTBI'] + scale*(M1['linLTBI'] - M0['linLTBI']) #Mt.linLTBI = M0.linLTBI + scale*(M1.linLTBI - M0.linLTBI);

    out = goveqs_basis2(input, t, r, Mt, i, prm, sel, agg)
    return out

