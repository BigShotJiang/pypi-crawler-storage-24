import numpy as np

def alloc_parameters(x, f_r, f_p, f_xi):
    
    r = f_r.copy()
    p = f_p.copy()
    xi = f_xi.copy()
    r['beta'] = x[xi['r_beta']] #r.beta         = x(xi.r_beta); #Transmission for HIV-ve, D3S-TB
    p['rfbeta_mdr'] = x[xi['rfbeta_mdr']] #p.rfbeta_mdr   = x(xi.rfbeta_mdr);
    p['rfbeta_hiv'] = x[xi['rfbeta_hiv']] #p.rfbeta_hiv   = x(xi.rfbeta_hiv);
    r['betared']      = x[xi['r_betared']] #r.betared      = x(xi.r_betared); #New, added on 2024-04-02
    r['r_sym'] = x[xi['r_sym']] # r.sym          = x(xi.r_sym);
    p['pu_2022'] = x[xi['p_pu']] #p['pu'] = x[xi['p_pu']] #p.pu           = x(xi.p_pu);
    #r['cs'] = x[xi['r_cs']]*np.array([1,1,1,1,1]) # r.cs           = x(xi.r_cs);
    #r['cs2'] = x[xi['r_cs2']]*np.array([1,1,1,1,1]) #r.cs2          = x(xi.r_cs2);
    #r['cs3'] = x[xi['r_cs3']]*[1,1,1,1,1] #r.cs2          = x(xi.r_cs2);
    ##
    r['cs_1997'] = x[xi['r_cs']]*np.array([1,1,1,1,1]) #r.cs_1997      = x(xi.r_cs).*[1,1,1,1,1];
    r['cs_2022'] = x[xi['r_cs']]*x[xi['rf_cs2022']]*np.array([1,1,1,1,1]) #r.cs_2022      = x(xi.r_cs)*x(xi.rf_cs2022).*[1,1,1,1,1];
    r['cs2_1997'] = x[xi['r_cs']]*x[xi['rf_cs2']]*np.array([1,1,1,1,1]) #r.cs2_1997     = x(xi.r_cs)*x(xi.rf_cs2).*[1,1,1,1,1];
    r['cs2_2022'] = x[xi['r_cs']]*x[xi['rf_cs2']]*np.array([1,1,1,1,1]) #r.cs2_2022     = x(xi.r_cs)*x(xi.rf_cs2).*[1,1,1,1,1];
    ##
    r['cs3'] = r['cs3']*np.array([1,1,1,1,1]) #r.cs2          = x(xi.r_cs2);
    #p['Tx_init'] = x[xi['Tx_init']]
    r['mort_TB'] = x[xi['r_mort_TB']] #r.mort_TB      = x(xi.r_mort_TB);
    p['Dx'] = x[xi['p_Dx']] #p.Dx           = x(xi.p_Dx);
    r['default'] = r['Tx']*(1-x[xi['p_Tx_complete']])/x[xi['p_Tx_complete']] #r.default      = r.Tx*(1-x(xi.p_Tx_complete))./x(xi.p_Tx_complete);
   
    #r['HIV_acqu'] = x[xi['r_HIV_acqu']] #% r.HIV_acqu = x(xi.r_HIV_acqu);
    r['ART_init'] = x[xi['r_ART_init']] #r.ART_init     = x(xi.r_ART_init);

    #p['MDR_rec'] = [x[xi['p_MDRrec2019']],0] #p.MDR_rec      = [x(xi.p_MDRrec2019),0]; Modified after Sandip changes on 2024-04-02 (next line)
    p['MDR_rec']      = [x[xi['p_MDRrec2022']],0] #p.MDR_rec      = [x(xi.p_MDRrec2022),0];
    r['MDR_acqu'] = x[xi['r_MDR_acqu']] #r.MDR_acqu     = x(xi.r_MDR_acqu);
    r['HIV_mort'] = x[xi['r_HIV_mort']] #r.HIV_mort     = x(xi.r_HIV_mort);
    
    r['progression'] = np.array(r['progression'])
    r['reactivation'] = np.array(r['reactivation'])
    r['progression'][[1,2]] = r['progression'][0]*x[xi['p_HIV_relrate']]*np.array([1, 0.4]).T #r.progression([2,3])  = r.progression(1)*x(xi.p_HIV_relrate)*[1 0.4];
    r['reactivation'][[1,2]] = r['reactivation'][0]*x[xi['p_HIV_relrate']]*np.array([1, 0.4]) #r.reactivation([2,3]) = r.reactivation(1)*x(xi.p_HIV_relrate)*[1 0.4];
   
    #New lines
    #r['progression']   = np.tile(r['progression'],[5,1])#repmat(r.progression,[5,1]); #%[0.0826    3.4262    1.3705].*[1 1 1 1 1]'; %
    #r['reactivation']  = np.tile(r['reactivation'],[5,1])#repmat(r.reactivation,[5,1]); #%[0.0006    0.0249    0.0100].*[1 1 1 1 1]'; %
   
    r['progression']   = (np.reshape(np.array(r['progression']),(3,1))@np.reshape(np.array([1, 1, 1, 1, 1]),(1,5))).T #;    %[0.0826    3.4262    1.3705].*[1 1 1 1 1]'; %
    r['reactivation']  = (np.reshape(np.array(r['reactivation']),(3,1))@np.reshape(np.array([1, 1, 1, 1, 1]),(1,5))).T #r.reactivation  = r.reactivation.*[1 1 1 1 1]';   %[0.0006    0.0249    0.0100].*[1 1 1 1 1]'; %

    #if len(x)>xi['calib']:
    #    r['self_cure']   = x[xi['r_self_cure']]
    r['self_cure'][[0,2]]   = x[xi['r_self_cure']]
    return (r, p)
