import math
from scipy import integrate

def ode15s(fun, init, steps, args):
    #fin_result = integrate.odeint(fun, init, steps, args, atol=1e-10, rtol=1e-10)
    fin_result = integrate.odeint(fun, init, steps, args, atol=1e-6, rtol=1e-6)
    #fin_result = integrate.odeint(fun, init, steps, args)
    return steps, fin_result

def create_steps(first, final, step):
    result = []
    i = first
    while((i<final) and (math.isclose(i, final)==False)):
        result.append(i)
        i = i+step
    result.append(final)
    return result
