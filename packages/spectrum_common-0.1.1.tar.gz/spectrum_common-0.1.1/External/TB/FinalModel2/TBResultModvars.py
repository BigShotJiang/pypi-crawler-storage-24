from ...GB.Util.GBDate import GBDate

def create_simple_modvar(tag, value):
    return {'tag':tag, 'module':'TB', 'value':value}

def init_result_modvars(modvars):
    lockdownDate = GBDate('March', 2020)
    return [
            create_simple_modvar('TB_Incidence', []),
            create_simple_modvar('TB_Notification', []),
            create_simple_modvar('TB_Mortality', []),
    ]
