xi = {
    'r_beta' : 0,
    'rfbeta_mdr' : 1,
    'rfbeta_hiv' : 2,
    'r_sym' : 3,
    'p_pu' : 4,
    'r_cs' : 5,
    'r_cs2': 6,
    'r_Tx_init' : 7,
    'r_mort_TB' : 8,
    'p_Dx' : 9,
    'p_Tx_complete' : 10,
    'r_HIV_acqu' : 11,
    'r_ART_init' : 12,
    'p_MDRrec2019' : 13,
    'r_MDR_acqu' : 14,
    'r_HIV_mort' : 15 
}