from .goveqs_basis_disruption import goveqs_basis_disruption

def goveqs_scaleup_disruption(input, t, M0, M1, notif_fac, times, i, prm, sel, agg):
    scale = max((t-times[0])/(times[1]-times[0]),0) # % <--- NEW: removed min(,1), so that model can continue extrapolating ART coverage into future
    Mt = M1.copy()
    Mt['lin'] = M0['lin'] + scale*(M1['lin']-M0['lin'])
    out = goveqs_basis_disruption(input, t, Mt, notif_fac, i, prm, sel, agg)
    return out

