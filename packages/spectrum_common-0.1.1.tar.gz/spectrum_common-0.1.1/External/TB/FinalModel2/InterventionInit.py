def InterventionInit(): #function [Intvn]=InterventionInit()

    Intvn={} #Intvn=[];
    Intvn['year1']=[] #Intvn['year1']=[];
    Intvn['year2']=[] #Intvn.year2=[];
    Intvn['year1_vac']=[] #Intvn.year1_vac=[];
    Intvn['year2_vac']=[] #Intvn.year2_vac=[];

    Intvn['r_cs']=[] #Intvn.r_cs=[];           
    Intvn['r_cs2']=[] #Intvn.r_cs2=[];          
    Intvn['r_cs3']=[] #Intvn.r_cs3=[];  

    Intvn['p_Dx']=[] #Intvn.p_Dx=[];  

    Intvn['p_MDRrec']=[] #Intvn.p_MDRrec=[]; 
    Intvn['p_cure']=[] #Intvn.p_cure=[]; 
    Intvn['r_default']=[] #Intvn.r_default=[]; 
    Intvn['r_default2']=[] #; 

    Intvn['r_progression']=[] #Intvn.r_progression=[];	
    Intvn['r_reactivation']=[] #Intvn.r_reactivation=[]; 

    Intvn['p_pu']=[] #Intvn.p_pu=[];                  
    Intvn['r_Tx2']=[]#Intvn.r_Tx2=[];          
    Intvn['p_cure2']=[]#Intvn.p_cure2=[];        
    Intvn['p_TX_complete']=[] #Intvn.p_TX_complete=[]; 
    Intvn['r_relapse_1']=[] #Intvn.r_relapse_1=[];	
    Intvn['r_relapse_2']=[] #Intvn.r_relapse_2=[];   
    Intvn['r_relapse_3']=[] #Intvn.r_relapse_3=[]; 	
    Intvn['p_VE_1']=[] #Intvn.p_VE_1=[];        
    Intvn['p_VE_2']=[] #Intvn.p_VE_2=[];      
    Intvn['r_vacc']=[] #Intvn.r_vacc=[];        
    Intvn['r_waning']=[] #Intvn.r_waning=[]; 

    return(Intvn)