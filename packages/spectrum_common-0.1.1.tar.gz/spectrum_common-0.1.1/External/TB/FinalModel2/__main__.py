import time
import json
import os
from .SpectrumWebConnect import run_dynamical_model


#retrieve modvars from json file
final_model_path = os.getcwd()+'\\FinalModel2'
#with open(f"{final_model_path}\\data\\CtriesDefaults\\NGA_modvars.JSON", "r") as fp:
#    modvars = json.load(fp)


with open(f"{final_model_path}\\data\\CtriesDefaults\\TB_NGA_10_21.JSON", "r") as fp:
    modvars = json.load(fp)

#Copied constants from spectrum engine
TB_DynPRMTag           = '<TB_DynamicalModelPRM_V1>'
TB_DynPopDataTag       = '<TB_DynamicalModelPopData_V1>'
TB_CounterfactualScenarioTag  = '<TB_CounterfactualScenario_V1>'
TB_CurrentScenarioTag         = '<TB_CurrentScenario_V1>'
# Scenarios 
TB_AvgProbDetect      = 0 
TB_AvgProbReceivPrvnt = 1
TB_TreatmentSuccess   = 2
TB_ScenarioLen = 3

#run the dynamical model
start_time = time.time()
results = run_dynamical_model('NGA',
                            modvars[TB_DynPRMTag],
                            None, # modvars[tbc.TB_DynXSTag],
                            modvars[TB_DynPopDataTag],
                            modvars[TB_CurrentScenarioTag][TB_AvgProbReceivPrvnt][-1],
                            modvars[TB_CounterfactualScenarioTag][TB_AvgProbReceivPrvnt][-1],
                            modvars[TB_CurrentScenarioTag][TB_TreatmentSuccess][-1],
                            modvars[TB_CounterfactualScenarioTag][TB_TreatmentSuccess][-1],
                            modvars[TB_CurrentScenarioTag][TB_AvgProbDetect][-1],
                            modvars[TB_CounterfactualScenarioTag][TB_AvgProbDetect][-1],
                            final_model_path)
end_time = time.time()
print(f'time {end_time-start_time}')