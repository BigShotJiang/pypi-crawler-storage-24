"""SpectrumCommon external integrations package."""
