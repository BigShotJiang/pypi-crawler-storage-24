from os import environ
from SpectrumCommon.Const.GB import *
from AvenirCommon.Database import GB_get_db_json

def _get_language_strings_dict(lang_ID):
    language_strings_dict = {}

    if lang_ID == GB_ENGLISH_MST_ID:
        english_DB_file_name = GB_ENGLISH_STRINGS_DB_NAME + '_' + GB_STRING_DB_CURR_VERSION + '.' + GB_JSON
        language_strings_dict = GB_get_db_json(environ[GB_SPECT_MOD_DATA_CONN_ENV], GB_GB_CONTAINER, english_DB_file_name)

    elif lang_ID == GB_SPANISH_MST_ID:
        spanish_DB_file_name = GB_SPANISH_STRINGS_DB_NAME + '_' + GB_STRING_DB_CURR_VERSION + '.' + GB_JSON
        language_strings_dict = GB_get_db_json(environ[GB_SPECT_MOD_DATA_CONN_ENV], GB_GB_CONTAINER, spanish_DB_file_name)

    elif lang_ID == GB_FRENCH_MST_ID:
        french_DB_file_name = GB_FRENCH_STRINGS_DB_NAME + '_' + GB_STRING_DB_CURR_VERSION + '.' + GB_JSON
        language_strings_dict = GB_get_db_json(environ[GB_SPECT_MOD_DATA_CONN_ENV], GB_GB_CONTAINER, french_DB_file_name)

    elif lang_ID == GB_ARABIC_MST_ID:
        pass

    elif lang_ID == GB_RUSSIAN_MST_ID:
        russian_DB_file_name = GB_RUSSIAN_STRINGS_DB_NAME + '_' + GB_STRING_DB_CURR_VERSION + '.' + GB_JSON
        language_strings_dict = GB_get_db_json(environ[GB_SPECT_MOD_DATA_CONN_ENV], GB_GB_CONTAINER, russian_DB_file_name)

    elif lang_ID == GB_PORTUGUESE_MST_ID:
        pass

    elif lang_ID == GB_CHINESE_MST_ID:
        pass

    elif lang_ID == GB_INDONESIAN_MST_ID:
        pass

    elif lang_ID == GB_UKRANIAN_MST_ID:
        ukranian_DB_file_name = GB_UKRANIAN_STRINGS_DB_NAME + '_' + GB_STRING_DB_CURR_VERSION + '.' + GB_JSON
        language_strings_dict = GB_get_db_json(environ[GB_SPECT_MOD_DATA_CONN_ENV], GB_GB_CONTAINER, ukranian_DB_file_name)

    return language_strings_dict

def _get_strings(lang_ID):
    enStrings = _get_language_strings_dict(GB_ENGLISH_MST_ID)
    langStrings = _get_language_strings_dict(lang_ID)
    enStrings.update(langStrings)
    return enStrings
