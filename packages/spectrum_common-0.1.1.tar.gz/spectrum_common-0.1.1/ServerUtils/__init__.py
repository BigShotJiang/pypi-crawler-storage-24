from .FilterUtils import *
from .MakeAuthenticatedCalls import *
from .MiddlewareUtils import *
from .RouterLoggingMiddleware import *
from .VersionUtils import *
from .ExceptionUtils import *
from .Utils import *


def setup_general_server_calls(app):
    # general version calls
    setup_version_services(app)

    # middleware
    setup_exception_handler(app)
    if getenv("AVENIR_RUN_LOCAL", "") == "":
        setup_middleware(app)
