
import numpy as np
from loguru import logger



def convert_to_numpy(projection):
    _dtype = np.float64
    dt = np.dtype(np.float64)  

    for tag in projection:
        if tag[0] == '<':
            mod_str = tag[1:3]
                
            if type(projection[tag]) == list:
                try:
                    if len(projection[tag])>0 and ((type(projection[tag][0])==dict) or(type(projection[tag][0])==str)) :
                        projection[tag] = np.array(projection[tag], order='C')#, dtype = dt)
                    else:
                        projection[tag] = np.array(projection[tag], order='C', dtype= dt )#, dtype = dt)
                except:
                    logger.warning(f"Could not convert {tag} to numpy array")
                    pass


def convert_to_list(projection):

    numpy_type = type(np.array([]))
    for tag in projection:
        if type(projection[tag]) == numpy_type:
            projection[tag] = np.nan_to_num(projection[tag], copy=True, nan=0.0, posinf=None, neginf=None)
            projection[tag] = projection[tag].tolist()



    
def remove_nonmodvars(projection):
    
    # Using a list comprehension to make a list of the keys to be deleted
    delete = [tag for tag in projection if tag[0] != '<']
    # delete the non tags key/s
    for key in delete:
        del projection[key]
