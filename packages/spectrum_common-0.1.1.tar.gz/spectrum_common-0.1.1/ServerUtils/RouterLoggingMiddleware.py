from starlette.middleware.base import BaseHTTPMiddleware


class RouterLoggingMiddleware(BaseHTTPMiddleware):
    def __init__(self, app, logger, subsystem):
        super().__init__(app)

        self._logger = logger
        self._subsystem = subsystem

    async def dispatch(self, request, call_next):
        self._logger.info(f"{request.method} {request.url}")

        response = await call_next(request)

        self._logger.info(
            f"{request.method} {request.url} {response.status_code}",
            extra={"custom_dimensions": {"subsystem": self._subsystem}},
        )

        return response
