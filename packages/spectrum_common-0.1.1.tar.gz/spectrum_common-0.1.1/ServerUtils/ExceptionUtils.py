from SpectrumCommon.Const.GB import *

class SpectrumException(Exception):
    def __init__(self, SWErrorCode, status_code=None, message=None, extra_info={}):
        #self.detail = args[0]
        self.SWErrorCode = SWErrorCode
        self.message = message if message!= None else GB_SW_ExceptMessages[SWErrorCode]
        # self.detail = {'msg':message, 'extra_info':extra_info}
        self.status_code = status_code if status_code!= None else GB_SW_StatusCode[SWErrorCode]
        self.extra_info = extra_info