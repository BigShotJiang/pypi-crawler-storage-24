"""SpectrumCommon package root."""
