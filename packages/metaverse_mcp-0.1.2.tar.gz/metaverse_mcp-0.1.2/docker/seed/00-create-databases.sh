#!/bin/bash
# Creates the metabase_app database for Metabase's internal state.
# The primary "metaverse" database is created automatically by POSTGRES_DB.
set -e
psql -U metaverse -c "CREATE DATABASE metabase_app;"
