-- Metaverse seed schema
-- Runs against the "metaverse" database (default POSTGRES_DB)

CREATE TABLE customers (
    id         SERIAL PRIMARY KEY,
    name       VARCHAR(255) NOT NULL,
    email      VARCHAR(255) UNIQUE NOT NULL,
    country    VARCHAR(100),
    state      VARCHAR(100),
    city       VARCHAR(100),
    tier       VARCHAR(50)  NOT NULL DEFAULT 'standard',
    created_at TIMESTAMP    NOT NULL DEFAULT NOW()
);

CREATE TABLE products (
    id         SERIAL PRIMARY KEY,
    name       VARCHAR(255) NOT NULL,
    category   VARCHAR(100),
    price      DECIMAL(10, 2),
    provider   VARCHAR(100),
    active     BOOLEAN      NOT NULL DEFAULT true,
    created_at TIMESTAMP    NOT NULL DEFAULT NOW()
);

CREATE TABLE orders (
    id           SERIAL PRIMARY KEY,
    customer_id  INTEGER REFERENCES customers(id),
    product_id   INTEGER REFERENCES products(id),
    quantity     INTEGER      NOT NULL DEFAULT 1,
    total_amount DECIMAL(10, 2),
    status       VARCHAR(50)  NOT NULL,
    provider     VARCHAR(100),
    created_at   TIMESTAMP    NOT NULL DEFAULT NOW(),
    refunded_at  TIMESTAMP
);

CREATE TABLE gift_cards (
    id          SERIAL PRIMARY KEY,
    code        VARCHAR(50)  UNIQUE NOT NULL,
    amount_usd  DECIMAL(10, 2),
    customer_id INTEGER REFERENCES customers(id),
    issued_at   TIMESTAMP    NOT NULL DEFAULT NOW(),
    redeemed_at TIMESTAMP,
    redeemed_by INTEGER REFERENCES customers(id)
);

CREATE INDEX ON orders(customer_id);
CREATE INDEX ON orders(product_id);
CREATE INDEX ON orders(status);
CREATE INDEX ON orders(created_at);
CREATE INDEX ON gift_cards(customer_id);
