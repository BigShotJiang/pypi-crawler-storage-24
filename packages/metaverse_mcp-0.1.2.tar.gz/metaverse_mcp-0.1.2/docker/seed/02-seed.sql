-- Seed data for Metaverse demo
-- Generates realistic customers, products, orders and gift cards

DO $$
DECLARE
    first_names  text[] := ARRAY['Alice','Bob','Carol','David','Emma','Frank','Grace','Henry',
                                  'Iris','James','Kate','Liam','Mia','Noah','Olivia','Paul',
                                  'Quinn','Rachel','Sam','Tina','Uma','Victor','Wendy','Xander',
                                  'Yara','Zoe'];
    last_names   text[] := ARRAY['Smith','Johnson','Williams','Brown','Jones','Garcia','Miller',
                                  'Davis','Wilson','Taylor','Anderson','Thomas','Jackson','White',
                                  'Harris','Martin','Thompson','Lee','Walker','Hall'];
    countries    text[] := ARRAY['US','US','US','US','US','UK','UK','DE','DE','FR','CA','AU'];
    us_states    text[] := ARRAY['CA','NY','TX','FL','WA','IL','MA','CO','AZ','GA','OR','NC'];
    cities       text[] := ARRAY['San Francisco','New York','Austin','Miami','Seattle','Chicago',
                                  'Boston','Denver','Phoenix','Atlanta','Portland','Charlotte',
                                  'London','Berlin','Paris','Toronto','Sydney'];
    tiers        text[] := ARRAY['standard','standard','standard','premium','premium','enterprise'];
    categories   text[] := ARRAY['Electronics','Clothing','Home','Sports','Books','Beauty','Food'];
    providers    text[] := ARRAY['FedEx','UPS','DHL','USPS'];
    statuses     text[] := ARRAY['completed','completed','completed','completed','pending','refunded','cancelled'];

    i            int;
    cid          int;
    pid          int;
    country      text;
    qty          int;
    price        numeric;
    total        numeric;
    status       text;
    provider     text;
    order_at     timestamp;
    n_customers  int := 200;
    n_products   int := 30;
    n_orders     int := 800;
    n_gift_cards int := 120;
BEGIN

    -- Customers
    FOR i IN 1..n_customers LOOP
        country := countries[1 + mod(i * 7, array_length(countries, 1))];
        INSERT INTO customers (name, email, country, state, city, tier, created_at)
        VALUES (
            first_names[1 + mod(i, array_length(first_names, 1))] || ' ' ||
            last_names[1 + mod(i * 3, array_length(last_names, 1))],
            'user' || i || '@example.com',
            country,
            CASE WHEN country = 'US' THEN us_states[1 + mod(i * 5, array_length(us_states, 1))] ELSE NULL END,
            cities[1 + mod(i * 11, array_length(cities, 1))],
            tiers[1 + mod(i * 2, array_length(tiers, 1))],
            NOW() - (mod(i * 13, 730) || ' days')::interval
        );
    END LOOP;

    -- Products
    FOR i IN 1..n_products LOOP
        price := round((10 + mod(i * 17, 490))::numeric, 2);
        INSERT INTO products (name, category, price, provider, active, created_at)
        VALUES (
            categories[1 + mod(i, array_length(categories, 1))] || ' Item #' || i,
            categories[1 + mod(i, array_length(categories, 1))],
            price,
            providers[1 + mod(i, array_length(providers, 1))],
            (mod(i, 10) != 0),  -- 10% inactive
            NOW() - (mod(i * 7, 500) || ' days')::interval
        );
    END LOOP;

    -- Orders
    FOR i IN 1..n_orders LOOP
        cid      := 1 + mod(i * 3, n_customers);
        pid      := 1 + mod(i * 7, n_products);
        qty      := 1 + mod(i, 4);
        status   := statuses[1 + mod(i * 5, array_length(statuses, 1))];
        provider := providers[1 + mod(i * 11, array_length(providers, 1))];
        order_at := NOW() - (mod(i * 2, 180) || ' days')::interval
                          - (mod(i * 3, 24) || ' hours')::interval;

        SELECT p.price INTO price FROM products p WHERE p.id = pid;
        total := round((price * qty)::numeric, 2);

        INSERT INTO orders (customer_id, product_id, quantity, total_amount, status, provider, created_at, refunded_at)
        VALUES (
            cid, pid, qty, total, status, provider, order_at,
            CASE WHEN status = 'refunded' THEN order_at + interval '3 days' ELSE NULL END
        );
    END LOOP;

    -- Gift cards
    FOR i IN 1..n_gift_cards LOOP
        cid := 1 + mod(i * 9, n_customers);
        INSERT INTO gift_cards (code, amount_usd, customer_id, issued_at, redeemed_at, redeemed_by)
        VALUES (
            'GC-' || upper(md5(i::text)) ,
            (ARRAY[10,25,50,100])[1 + mod(i, 4)],
            cid,
            NOW() - (mod(i * 4, 200) || ' days')::interval,
            CASE WHEN mod(i, 3) = 0  -- ~33% redeemed
                 THEN NOW() - (mod(i * 2, 60) || ' days')::interval
                 ELSE NULL
            END,
            CASE WHEN mod(i, 3) = 0 THEN 1 + mod(i * 5, n_customers) ELSE NULL END
        );
    END LOOP;

END $$;
