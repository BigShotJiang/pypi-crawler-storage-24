"""Shared test fixtures."""

import pytest
import respx
from httpx import Response

from metaverse import cache as mb_cache
from metaverse import client as mb_client
from metaverse.config import settings


@pytest.fixture(autouse=True)
def reset_client():
    """Reset the shared httpx client and cache before each test so mocks take effect."""
    mb_client._client = None
    mb_cache.clear()
    yield
    mb_client._client = None
    mb_cache.clear()


@pytest.fixture
def mock_api():
    """Activate respx mock router for the Metabase API base URL."""
    with respx.mock(base_url=f"{settings.url}/api", assert_all_called=False) as router:
        yield router


def json_response(data: dict | list, status_code: int = 200) -> Response:
    """Helper to build an httpx Response with JSON body."""
    import json

    return Response(
        status_code, content=json.dumps(data).encode(), headers={"content-type": "application/json"}
    )
