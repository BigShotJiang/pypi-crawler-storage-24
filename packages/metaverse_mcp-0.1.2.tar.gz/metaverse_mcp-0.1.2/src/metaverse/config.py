from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Application settings loaded from environment variables and .env file."""

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    url: str = Field(default="http://localhost:3000", validation_alias="METABASE_URL")
    api_key: str = Field(default="", validation_alias="METABASE_API_KEY")
    mcp_host: str = Field(default="0.0.0.0", validation_alias="MCP_HOST")
    mcp_port: int = Field(default=8000, validation_alias="MCP_PORT")
    mcp_transport: str = Field(default="stdio", validation_alias="MCP_TRANSPORT")
    cache_ttl: int = Field(default=3600, validation_alias="CACHE_TTL_SECONDS")


settings = Settings()
