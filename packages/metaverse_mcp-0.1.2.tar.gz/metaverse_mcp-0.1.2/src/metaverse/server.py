"""MCP server entry point.

Imports tool modules to trigger @mcp.tool registration, then runs the server.
"""

import logging
import sys

import metaverse.prompts  # noqa: F401
import metaverse.resources  # noqa: F401
import metaverse.tools.alerts  # noqa: F401
import metaverse.tools.dashboards  # noqa: F401
import metaverse.tools.databases  # noqa: F401
import metaverse.tools.metrics  # noqa: F401
import metaverse.tools.queries  # noqa: F401
from metaverse.app import mcp
from metaverse.config import settings

logging.basicConfig(stream=sys.stderr, level=logging.INFO, format="[metaverse] %(message)s")
logger = logging.getLogger(__name__)


def main() -> None:
    api_key_preview = (settings.api_key[:6] + "…") if settings.api_key else "(empty)"
    logger.info("transport=%s", settings.mcp_transport)
    logger.info("metabase_url=%s", settings.url)
    logger.info("api_key=%s", api_key_preview)

    if settings.mcp_transport == "http":
        mcp.run(transport="http", host=settings.mcp_host, port=settings.mcp_port)
    else:
        mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
