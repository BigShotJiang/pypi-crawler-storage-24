"""In-memory TTL cache for Metabase schema metadata."""

import logging
import time
from typing import Any

from metaverse.client import ApiResponse
from metaverse.client import get as api_get

logger = logging.getLogger(__name__)

_store: dict[str, tuple[ApiResponse, float]] = {}


async def cached_get(path: str, **kwargs: Any) -> ApiResponse:
    """GET with TTL caching. Use only for schema metadata paths."""
    from metaverse.config import settings  # late import avoids circular at module load

    entry = _store.get(path)
    if entry and (time.monotonic() - entry[1]) < settings.cache_ttl:
        logger.info("cache hit  %s", path)
        return entry[0]
    logger.info("cache miss %s", path)
    data = await api_get(path, **kwargs)
    _store[path] = (data, time.monotonic())
    return data


def clear() -> None:
    """Clear all cached entries."""
    _store.clear()
