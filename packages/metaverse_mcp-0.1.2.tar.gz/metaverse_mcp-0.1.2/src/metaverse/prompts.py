"""MCP prompts — exposed to Claude Code and any MCP client (Claude Desktop, etc.)."""

from metaverse.app import mcp

_DB = 87  # Snowflake ingested from Postgres — default database


@mcp.prompt()
def metaask(question: str) -> str:
    """Answer a data question by querying Metabase. Returns a markdown table + one-line summary."""
    return f"""Answer this data question using Metabase: {question}

Rules:
- Use only MCP tools. No scripts, no shell commands.
- Default database_id={_DB} (Snowflake/Postgres). Skip list_databases unless the user references a different database.

Steps:
1. list_tables({_DB}) — scan table names to identify which are relevant
2. describe_tables([...relevant ids...]) — fetch field details only for those tables
3. Write a focused SQL query that answers the question precisely. Use JOINs if needed.
4. run_query({_DB}, sql) — execute it
5. Format output:
   - Bold one-sentence summary first: **Result**: [direct answer]
   - Markdown table of results
   - If truncated: "_Showing top N rows — refine the query for more._"

Be direct. Lead with the answer."""


@mcp.prompt()
def metaquery(description: str) -> str:
    """Build and save a reusable Metabase question from a natural language description."""
    return f"""Build a Metabase saved question for: {description}

Rules:
- Use only MCP tools. No scripts, no shell commands.
- Default database_id={_DB} (Snowflake/Postgres). Skip list_databases unless the user references a different database.

Phase 1 — Explore:
1. list_tables({_DB}) — identify relevant tables by name
2. describe_tables([...relevant ids...]) — fetch field details only for those tables
3. Write the SQL query
4. run_query({_DB}, sql) — validate it returns expected data

Phase 2 — Confirm:
Present to the user:
- Proposed question name
- The SQL (in a code block)
- Preview of first 5 rows as a markdown table
  If 0 rows: show a warning and suggest a fix before asking to save.
Ask for approval before saving. If they request changes, revise and re-confirm.

Phase 3 — Save:
5. create_question(name, {_DB}, sql, description)
6. execute_question(card_id) — confirm it runs; if it fails, delete_question(card_id) and fix
7. Return: question name and full Metabase URL"""


@mcp.prompt()
def metaboard(description: str) -> str:
    """Build a complete Metabase dashboard — creates all questions and assembles the layout."""
    return f"""Build a Metabase dashboard for: {description}

Rules:
- Use only MCP tools. No scripts, no shell commands.
- Default database_id={_DB} (Snowflake/Postgres). Skip list_databases unless the user references a different database.
- Dashboard grid is 24 columns wide; default card size 12×8.

Phase 1 — Explore:
1. list_tables({_DB}) — identify relevant tables by name
2. describe_tables([...relevant ids...]) — fetch field details only for those tables
3. Break the description into 3–6 distinct metrics (e.g. "monthly revenue", "top customers")
4. For each metric: write SQL → validate with run_query({_DB}, sql)

Choose display type from the query result:
- Single number → scalar
- Time series (date/month on X) → line
- Rankings or category comparisons → bar
- Multi-column breakdown → table

Phase 2 — Confirm:
Present to the user:
- Proposed dashboard name
- Each card: metric name, display type, SQL (in a code block), first 3 rows as a markdown table
- Proposed layout (grid positions)
Ask for approval before creating anything.

Phase 3 — Create:
5. create_question for each metric (pass x_column and y_columns for bar/line/area)
   execute_question(card_id) after each — if it fails, delete_question and fix before continuing
6. create_dashboard(name, description)
7. add_card_to_dashboard for each question (left-to-right, top-to-bottom)
8. Return: dashboard name and full Metabase URL"""


@mcp.prompt()
def metalert(condition: str) -> str:
    """Set up a Metabase alert that triggers when a metric condition is met."""
    return f"""Set up a Metabase alert for: {condition}

Rules:
- Use only MCP tools. No scripts, no shell commands.
- Default database_id={_DB} (Snowflake/Postgres). Skip list_databases unless the user references a different database.

Phase 1 — Explore:
1. Parse: what metric, what trigger threshold, what schedule
2. list_questions — check if a matching question already exists
3. If not: list_tables({_DB}) → describe_tables([...relevant ids...]) → write SQL → validate with run_query
   - SQL must return rows ONLY when the condition is met (e.g. WHERE refund_count > 10)

Phase 2 — Confirm:
Present to the user:
- Trigger condition and schedule
- Whether an existing question is reused or a new one will be created
- If new: question name, SQL (in a code block), validation result as a markdown table
  (0 rows is expected — means the condition is not currently triggered)
Ask for approval before creating anything.

Phase 3 — Create:
4. If needed: create_question for the metric
5. create_alert(card_id, schedule_type, alert_condition="rows")
6. Return: what it watches, schedule, and full Metabase question URL

Schedule: "hourly" → hourly | "daily" → daily | "weekly" → weekly | default: hourly"""


@mcp.prompt()
def metametric(description: str) -> str:
    """Create or explore a reusable MBQL metric in Metabase."""
    return f"""Create or explore a Metabase metric for: {description}

Rules:
- Use only MCP tools. No scripts, no shell commands.
- Default database_id={_DB} (Snowflake/Postgres). Skip list_databases unless the user references a different database.

Phase 1 — Explore:

If the request is about an existing metric (e.g. "show me", "what does X return", "run X"):
1. list_metrics — find the matching metric by name
2. get_metric — retrieve its definition
3. execute_metric — run it and show the result
Skip to Output (no confirmation needed for read-only).

If the request is to create a new metric:
1. list_metrics — check if a metric with the same purpose already exists; confirm with the user before creating a duplicate
2. list_tables({_DB}) — identify the right table
3. describe_tables([table_id]) — find exact field names and IDs (id is required for non-count aggregations)
4. Determine:
   - aggregation_type: count (no field) · sum · avg · distinct · min · max
   - field_id: from describe_tables results (required for everything except count)

Phase 2 — Confirm:
Present to the user:
- Metric name and description
- Table it will be based on
- Aggregation: <type>(<field_name>) — e.g. sum(TOTAL) or count(*)
- The field_id that will be used
Ask for approval before creating.

Phase 3 — Create:
5. create_metric(name, {_DB}, table_id, aggregation_type, field_id, description)
6. execute_metric(metric_id) — confirm it works
7. Return:
   Metric: <name>
   Aggregation: <type>(<field>) on <table>
   Result: <value or table>
   URL: <link>"""
