"""Metaverse — AI-powered Metabase interface via MCP."""
