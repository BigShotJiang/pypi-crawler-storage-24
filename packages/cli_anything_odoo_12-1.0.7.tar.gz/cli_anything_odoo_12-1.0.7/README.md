# cli-anything-odoo12

![TypeScript](https://img.shields.io/badge/TypeScript-007ACC?style=flat&logo=typescript&logoColor=white) ![AI Context](https://img.shields.io/badge/AI-Context%20Enabled-blueviolet)

CLI harness for Odoo 12 ERP — perform CRUD operations, manage modules, databases, generate reports, export data, and run natural language queries, all from the command line via REST API (muk_rest) or XML-RPC.

## Getting Started

### Prerequisites

- Node.js >= 18.0.0
- npm

### Installation

```bash
npm install
```

### Development

```bash
# Start development
npm run dev

# Run tests
npm run test

# Build for production
npm run build
```

## Features

- **Documentation** - Comprehensive docs

## AI Context

This project is configured with AI-assisted development context. The `.context/` directory contains:

- **docs/** - Project documentation for AI assistants
- **agents/** - Agent playbooks and roles
- **skills/** - Reusable skill definitions
- **plans/** - Implementation plans

### Using with AI Assistants

1. Install the MCP server: `npx @ai-coders/context mcp`
2. Configure your IDE to use the MCP server
3. The AI assistant will have access to project context

## Git Strategy

This project follows **github-flow** branching strategy.

## License

MIT
