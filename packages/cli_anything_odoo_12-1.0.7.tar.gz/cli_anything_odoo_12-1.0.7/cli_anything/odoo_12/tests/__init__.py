"""Tests for Odoo 12 CLI harness."""
