"""Allow running as python3 -m cli_anything.odoo_12"""
from cli_anything.odoo_12.odoo_12_cli import main
main()
