"""Odoo 12 CLI - Stateful CLI harness for Odoo 12 ERP via XML-RPC."""
