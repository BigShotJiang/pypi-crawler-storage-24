"""Report generation — render Odoo reports as PDF via the real Odoo engine."""

from cli_anything.odoo_12.utils.odoo_backend import OdooBackend


def render(rpc: OdooBackend, report_name: str, record_ids: list[int],
           output_path: str) -> dict:
    """Render a report to PDF using the REAL Odoo report engine.

    The rendering is done by Odoo's wkhtmltopdf integration — not reimplemented.
    """
    return rpc.render_report(report_name, record_ids, output_path)


def list_reports(rpc: OdooBackend, model: str | None = None) -> dict:
    """List available reports, optionally filtered by model."""
    domain = []
    if model:
        domain.append(("model", "=", model))
    reports = rpc.search_read(
        "ir.actions.report", domain,
        fields=["name", "report_name", "model", "report_type"],
        order="model, name",
    )
    return {
        "count": len(reports),
        "filter": {"model": model},
        "reports": reports,
    }
