"""Database management — list, create, backup, restore, drop databases."""

from cli_anything.odoo_12.utils.odoo_backend import OdooBackend


def list_databases(rpc: OdooBackend) -> dict:
    """List all databases on the Odoo instance."""
    dbs = rpc.db_list()
    return {
        "count": len(dbs),
        "databases": dbs,
    }


def create_database(rpc: OdooBackend, db_name: str,
                    admin_password: str = "admin",
                    demo: bool = False,
                    lang: str = "pt_BR") -> dict:
    """Create a new database."""
    rpc.db_create(db_name, admin_password, demo, lang)
    return {
        "database": db_name,
        "action": "created",
        "demo": demo,
        "lang": lang,
    }


def drop_database(rpc: OdooBackend, db_name: str,
                  admin_password: str = "admin") -> dict:
    """Drop a database."""
    rpc.db_drop(db_name, admin_password)
    return {
        "database": db_name,
        "action": "dropped",
    }


def backup_database(rpc: OdooBackend, db_name: str, output_path: str,
                    admin_password: str = "admin",
                    backup_format: str = "zip") -> dict:
    """Backup a database to a file."""
    return rpc.db_backup(db_name, output_path, admin_password, backup_format)


def restore_database(rpc: OdooBackend, db_name: str, backup_path: str,
                     admin_password: str = "admin") -> dict:
    """Restore a database from a backup file."""
    rpc.db_restore(db_name, backup_path, admin_password)
    return {
        "database": db_name,
        "action": "restored",
        "source": backup_path,
    }
