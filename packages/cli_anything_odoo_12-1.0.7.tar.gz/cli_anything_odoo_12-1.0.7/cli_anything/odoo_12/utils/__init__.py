"""Utility modules for Odoo 12 CLI harness."""
