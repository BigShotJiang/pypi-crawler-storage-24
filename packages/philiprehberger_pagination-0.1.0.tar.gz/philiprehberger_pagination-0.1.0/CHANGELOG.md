# Changelog

## 0.1.0 (2026-03-21)

- Initial release
- Offset pagination with `paginate()` returning `Page` dataclass
- Cursor pagination with `CursorPage.encode()` and `CursorPage.decode()`
- Base64 + JSON cursor encoding
