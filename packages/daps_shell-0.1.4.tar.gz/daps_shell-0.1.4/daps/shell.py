#!/usr/bin/env python3
import os, sys, signal, json, importlib.util, subprocess, glob, shutil, difflib, threading
from prompt_toolkit import PromptSession
from prompt_toolkit.completion import Completer, Completion
from prompt_toolkit.lexers import Lexer
from prompt_toolkit.styles import Style
from prompt_toolkit.formatted_text import FormattedText
from prompt_toolkit.history import FileHistory

plugins = {}

def loadconf():
        conf_dir = os.path.expanduser("~/.config/daps")
        whereis = os.path.join(conf_dir, "config.json")
        plugin_dir = os.path.join(conf_dir, "plugins")
        os.makedirs(plugin_dir, exist_ok=True)
        if not os.path.exists(whereis):
                with open(whereis, "w") as f:
                        json.dump({"aliases": {}, "cleargreet": "no"}, f, indent=2)
        for filename in os.listdir(plugin_dir):
                if filename.endswith(".py"):
                        name = filename[:-3]
                        try:
                                spec = importlib.util.spec_from_file_location(name, os.path.join(plugin_dir, filename))
                                module = importlib.util.module_from_spec(spec)
                                spec.loader.exec_module(module)
                                plugins[name] = module
                        except Exception as e:
                                print(f"\033[91merror\033[0m loading plugin '{name}': {e}", file=sys.stderr)
        try:
                with open(whereis) as f:
                        return json.load(f)
        except json.JSONDecodeError as e:
                print(f"\033[91merror\033[0m invalid JSON in config: {e}", file=sys.stderr)
                sys.exit(1)

def load_local_conf(base):
        local = os.path.join(os.getcwd(), ".daps")
        if not os.path.exists(local):
                return base
        try:
                with open(local) as f:
                        overrides = json.load(f)
                merged = dict(base)
                merged["aliases"] = {**base.get("aliases", {}), **overrides.get("aliases", {})}
                for k, v in overrides.items():
                        if k != "aliases":
                                merged[k] = v
                return merged
        except Exception:
                return base

def save_conf(config):
        whereis = os.path.join(os.path.expanduser("~/.config/daps"), "config.json")
        with open(whereis, "w") as f:
                json.dump(config, f, indent=2)

def git_branch():
        try:
                r = subprocess.run(["git", "branch", "--show-current"], capture_output=True, text=True, timeout=1)
                b = r.stdout.strip()
                return b if b else None
        except Exception:
                return None

def expand_env(s):
        return os.path.expandvars(os.path.expanduser(s))

BUILTINS = ["cd", "exit", "clear", "plugins", "daps"]

class DapsCompleter(Completer):
        def __init__(self, aliases):
                self.aliases = aliases
        def _commands(self):
                return list(self.aliases.keys()) + list(plugins.keys()) + BUILTINS
        def get_completions(self, document, complete_event):
                text = document.text_before_cursor
                parts = text.split()
                word = document.get_word_before_cursor(WORD=True)
                if not parts or (len(parts) == 1 and not text.endswith(" ")):
                        for cmd in self._commands():
                                if cmd.startswith(word):
                                        yield Completion(cmd, start_position=-len(word))
                        return
                expanded = os.path.expanduser(expand_env(word))
                for m in glob.glob(expanded + "*"):
                        display = m.replace(os.path.expanduser("~"), "~", 1) if word.startswith("~") else m
                        if os.path.isdir(m): display += "/"
                        yield Completion(display, start_position=-len(word))

def is_executable(cmd): return shutil.which(cmd) is not None
def is_existing_path(token): return os.path.exists(os.path.expanduser(expand_env(token)))

class DapsLexer(Lexer):
        def __init__(self, aliases):
                self.aliases = aliases
        def lex_document(self, document):
                def inner(line_no):
                        line = document.lines[line_no]
                        parts = line.split()
                        if not parts: return FormattedText([("", "")])
                        tokens = []
                        cmd = parts[0]
                        if cmd in BUILTINS: tokens.append(("class:builtin", cmd))
                        elif cmd in self.aliases: tokens.append(("class:alias", cmd))
                        elif cmd in plugins: tokens.append(("class:plugin", cmd))
                        elif is_executable(cmd): tokens.append(("class:cmd-real", cmd))
                        else: tokens.append(("class:cmd", cmd))
                        for arg in parts[1:]:
                                tokens.append(("class:args", " "))
                                tokens.append(("class:arg-real" if is_existing_path(arg) else "class:args", arg))
                        return FormattedText(tokens)
                return inner

STYLE = Style.from_dict({
        "username": "#00d787 bold", "at": "#ffffff", "hostname": "#5fafff bold",
        "paren": "#00d787", "ident": "#00d787 bold", "dash": "#ffffff",
        "path": "#00d7af bold", "arrow": "#00d787 bold", "errcode": "#ff5f5f bold",
        "branch": "#d7af5f", "builtin": "#00d787 bold", "alias": "#5fafff bold",
        "plugin": "#d7af5f bold", "cmd": "#ffffff", "cmd-real": "#ffffff underline",
        "args": "#aaaaaa", "arg-real": "#aaaaaa underline",
})

def build_prompt(user, host, errcode):
        home = os.path.expanduser("~")
        cwd = os.getcwd()
        display_cwd = cwd.replace(home, "~", 1) if cwd.startswith(home) else cwd
        ident = "#" if user == "root" else "$"
        branch = git_branch()
        tokens = []
        if errcode and errcode != "0":
                tokens += [("class:errcode", f"[{errcode}]"), ("class:dash", " - ")]
        tokens += [
                ("class:username", user), ("class:at", "@"), ("class:hostname", host),
                ("class:dash", " "), ("class:paren", "("), ("class:ident", ident), ("class:paren", ")"),
                ("class:dash", " - "), ("class:path", display_cwd),
        ]
        if branch:
                tokens += [("class:dash", " "), ("class:branch", f"[{branch}]")]
        tokens += [("", "\n"), ("class:arrow", "> ")]
        return tokens

def fmt_error(msg): print(f"\033[91mdaps error\033[0m  {msg}", file=sys.stderr)
def fmt_info(msg): print(f"\033[96mdaps\033[0m  {msg}")

def runfc(config, key):
        cmd = config.get(key)
        if cmd: os.system(cmd)

def do_clear(config):
        os.system("clear")
        if config.get("cleargreet") == "yes": runfc(config, "greeter")

def suggest(cmd, alias):
        candidates = list(alias.keys()) + list(plugins.keys()) + BUILTINS
        candidates += [f for f in os.environ.get("PATH", "").split(":") if f]
        all_cmds = candidates + [c for p in candidates if os.path.isdir(p) for c in os.listdir(p)]
        matches = difflib.get_close_matches(cmd, [c for c in all_cmds if isinstance(c, str)], n=3, cutoff=0.6)
        if matches:
                print(f"\033[93mdaps\033[0m  command not found: {cmd}")
                print(f"       did you mean: {', '.join(matches)}?")
        else:
                print(f"\033[93mdaps\033[0m  command not found: {cmd}")

def do_plugins():
        if not plugins:
                fmt_info("no plugins loaded")
                return
        fmt_info(f"{len(plugins)} plugin(s) loaded:")
        for name, mod in plugins.items():
                doc = getattr(mod, "__doc__", None) or (mod.run.__doc__ if hasattr(mod, "run") else None) or "no description"
                print(f"  \033[96m{name}\033[0m  {doc.strip()}")

def do_daps_cmd(args, base_config):
        if not args:
                fmt_info("usage: daps config set <key> <value>  |  daps config get <key>  |  daps plugins")
                return "0"
        if args[0] == "plugins":
                do_plugins()
                return "0"
        if args[0] == "config":
                if len(args) < 2:
                        fmt_info("usage: daps config set <key> <value>  |  daps config get <key>")
                        return "0"
                if args[1] == "get" and len(args) >= 3:
                        val = base_config.get(args[2], "\033[91mnot set\033[0m")
                        print(f"  {args[2]} = {json.dumps(val)}")
                        return "0"
                if args[1] == "set" and len(args) >= 4:
                        key, val = args[2], " ".join(args[3:])
                        if val.lower() in ("true", "false"): val = val.lower() == "true"
                        base_config[key] = val
                        save_conf(base_config)
                        fmt_info(f"set {key} = {json.dumps(val)}")
                        return "0"
                if args[1] == "set-alias" and len(args) >= 4:
                        base_config.setdefault("aliases", {})[args[2]] = " ".join(args[3:])
                        save_conf(base_config)
                        fmt_info(f"alias {args[2]} set")
                        return "0"
                if args[1] == "del-alias" and len(args) >= 3:
                        base_config.get("aliases", {}).pop(args[2], None)
                        save_conf(base_config)
                        fmt_info(f"alias {args[2]} removed")
                        return "0"
        fmt_error(f"unknown daps command: {' '.join(args)}")
        return "1"

def run_bg(cmd_parts):
        def target():
                subprocess.run(" ".join(cmd_parts), shell=True)
        t = threading.Thread(target=target, daemon=True)
        t.start()
        print(f"\033[96m[bg]\033[0m  {' '.join(cmd_parts)} (pid thread {t.ident})")

def main():
        signal.signal(signal.SIGINT, lambda *_: sys.exit(255))
        base_config = loadconf()
        history_path = os.path.expanduser("~/.daps.history")
        user = subprocess.run(["whoami"], capture_output=True, text=True).stdout.strip()
        try:
                with open("/etc/hostname") as f: host = f.read().strip()
        except Exception: host = "daps-station"

        prev_dir = os.getcwd()
        errcode = None

        def make_session(alias):
                return PromptSession(
                        history=FileHistory(history_path),
                        completer=DapsCompleter(alias), lexer=DapsLexer(alias),
                        style=STYLE, complete_while_typing=False,
                )

        config = load_local_conf(base_config)
        session = make_session(config.get("aliases", {}))
        do_clear(config)
        runfc(config, "greeter")

        while True:
                try:
                        cur_dir = os.getcwd()
                        if cur_dir != prev_dir:
                                config = load_local_conf(base_config)
                                session = make_session(config.get("aliases", {}))
                                prev_dir = cur_dir
                        alias = config.get("aliases", {})
                        try:
                                raw = session.prompt(FormattedText(build_prompt(user, host, errcode))).strip()
                        except EOFError: sys.exit(0)
                        except KeyboardInterrupt: print(); continue
                        if not raw: continue

                        bg = raw.endswith("&")
                        if bg: raw = raw[:-1].strip()

                        parts = [expand_env(p) for p in raw.split()]
                        cmd_base = parts[0]
                        args = parts[1:]

                        if cmd_base in alias:
                                translated = alias[cmd_base]
                                for i, arg in enumerate(args): translated = translated.replace(f"${i + 1}", arg)
                                translated = translated.replace("$*", " ".join(args))
                                cmd_parts = [expand_env(p) for p in translated.split()]
                        else: cmd_parts = parts

                        ccmd = cmd_parts[0]
                        ccmar = cmd_parts[1:]

                        if ccmd == "cd":
                                target = os.path.expanduser(ccmar[0] if ccmar else "~")
                                try: os.chdir(target); errcode = "0"
                                except FileNotFoundError: fmt_error(f"cd: no such directory: {target}"); errcode = "1"
                                except PermissionError: fmt_error(f"cd: permission denied: {target}"); errcode = "1"
                        elif ccmd == "exit": sys.exit(0)
                        elif ccmd == "clear": do_clear(config); errcode = "0"
                        elif ccmd == "plugins": do_plugins(); errcode = "0"
                        elif ccmd == "daps": errcode = do_daps_cmd(ccmar, base_config); config = load_local_conf(base_config); session = make_session(config.get("aliases", {}))
                        elif ccmd in plugins:
                                try: errcode = str(plugins[ccmd].run(ccmar))
                                except Exception as e: fmt_error(f"plugin '{ccmd}' raised: {type(e).__name__}: {e}"); errcode = "1"
                        else:
                                if bg: run_bg(cmd_parts); errcode = "0"
                                else:
                                        try:
                                                result = subprocess.run(" ".join(cmd_parts), shell=True)
                                                errcode = str(result.returncode)
                                                if result.returncode == 127: suggest(ccmd, alias)
                                        except Exception as e: fmt_error(f"could not run command: {e}"); errcode = "1"
                except Exception as e: fmt_error(f"unexpected shell error: {type(e).__name__}: {e}")
