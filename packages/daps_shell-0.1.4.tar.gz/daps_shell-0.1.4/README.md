# daps

A customisable Python shell with plugins, aliases, and syntax highlighting.

## Install

```bash
pip install daps
```

Then just run:

```bash
daps
```

## Config

Config lives at `~/.config/daps/config.json`:

```json
{
  "aliases": {
    "ll": "ls -la $*",
    "gs": "git status"
  },
  "cleargreet": "yes",
  "greeter": "echo 'welcome back'"
}
```

### Alias placeholders

| Placeholder | Expands to |
|-------------|-----------|
| `$1`, `$2`… | individual args |
| `$*`        | all args joined |

## Plugins

Drop a `.py` file into `~/.config/daps/plugins/`. It must expose a `run(args: list) -> int` function. The return value sets the exit code shown in the prompt.

```python
# ~/.config/daps/plugins/hello.py
def run(args):
    print(f"hello, {args[0] if args else 'world'}")
    return 0
```

Plugins become commands and appear in tab completion automatically.

## Features

- Syntax highlighting as you type
- Tab completion for commands and file paths
- Alias expansion with `$1`/`$*` placeholders
- Plugin system — drop in `.py` files
- Persistent history at `~/.daps.history`
- Error code shown in prompt on non-zero exit
- Greeter command on startup (and optionally on `clear`)

## License

MIT
