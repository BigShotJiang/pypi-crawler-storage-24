# coding=utf-8
#
# clipboard.py - 剪贴板读取工具
#
# 支持平台：
#   macOS  — 已实现
#   Linux  — 预留入口（TODO）
#

import os
import base64
import platform
import subprocess
import tempfile
from typing import Optional


# ──────────────────────────────────────────────
# 剪贴板读取
# ──────────────────────────────────────────────


def get_clipboard_text() -> Optional[str]:
    """读取剪贴板文本内容，无文本则返回 None"""
    system = platform.system()
    if system == "Darwin":
        try:
            r = subprocess.run(["pbpaste"], capture_output=True, text=True, timeout=2)
            return r.stdout if r.returncode == 0 and r.stdout else None
        except Exception:
            return None
    elif system == "Linux":
        # TODO X11:     xclip -selection clipboard -o
        # TODO Wayland: wl-paste
        return None
    return None


def get_clipboard_image() -> Optional[tuple[bytes, str]]:
    """
    读取剪贴板图像，返回 (bytes, fmt_label)。
    fmt_label 为格式字符串，如 "PNG"、"TIFF"。
    无图像则返回 None。
    """
    system = platform.system()
    if system == "Darwin":
        return _clipboard_image_macos()
    elif system == "Linux":
        # TODO X11:     xclip -selection clipboard -t image/png -o
        # TODO Wayland: wl-paste --type image/png
        return None
    return None


def _clipboard_image_macos() -> Optional[tuple[bytes, str]]:
    """macOS: 通过 osascript 将剪贴板图像写入临时文件，读取后删除"""
    try:
        r = subprocess.run(
            ["osascript", "-e", "clipboard info"],
            capture_output=True,
            text=True,
            timeout=3,
        )
        info = r.stdout
        has_png = "«class PNGf»" in info
        has_tiff = "«class TIFF»" in info
        if not (has_png or has_tiff):
            return None
    except Exception:
        return None

    fmt_class = "«class PNGf»" if has_png else "«class TIFF»"
    fmt_label = "PNG" if has_png else "TIFF"

    with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as tmp:
        tmp_path = tmp.name

    script = f'''
set fileRef to open for access POSIX file "{tmp_path}" with write permission
write (the clipboard as {fmt_class}) to fileRef
close access fileRef
'''
    try:
        r = subprocess.run(
            ["osascript", "-e", script], capture_output=True, text=True, timeout=5
        )
        if r.returncode != 0:
            os.unlink(tmp_path)
            return None
        with open(tmp_path, "rb") as f:
            data = f.read()
        os.unlink(tmp_path)
        return (data, fmt_label) if data else None
    except Exception:
        try:
            os.unlink(tmp_path)
        except Exception:
            pass
        return None


# ──────────────────────────────────────────────
# 媒体类型映射
# ──────────────────────────────────────────────

_FMT_TO_MEDIA_TYPE: dict[str, str] = {
    "PNG": "image/png",
    "TIFF": "image/tiff",
    "JPEG": "image/jpeg",
    "GIF": "image/gif",
    "WEBP": "image/webp",
}


def fmt_to_media_type(fmt_label: str) -> str:
    """将格式标签（如 'PNG'）转换为 MIME 类型（如 'image/png'）"""
    return _FMT_TO_MEDIA_TYPE.get(fmt_label.upper(), "image/png")


def image_to_base64(data: bytes) -> str:
    """将图片字节数据编码为 base64 字符串"""
    return base64.b64encode(data).decode("ascii")


# ──────────────────────────────────────────────
# 输入状态
# ──────────────────────────────────────────────


class InputState:
    """
    跟踪本轮输入状态，特别是通过 Ctrl+Y 粘贴的图片数据。

    支持同一轮多次粘贴图片。
    设计目的：Enter 提交时不重新读剪贴板，避免误判。
    Ctrl+Y 时存入图片，Enter 时取出使用。
    """

    def __init__(self):
        # 每个元素为 (bytes, fmt_label)，如 (b'...', 'PNG')
        self.images: list[tuple[bytes, str]] = []

    @property
    def has_images(self) -> bool:
        return len(self.images) > 0

    def add_image(self, data: bytes, fmt: str):
        """添加一张图片"""
        self.images.append((data, fmt))

    def clear(self):
        """清空图片列表"""
        self.images.clear()
