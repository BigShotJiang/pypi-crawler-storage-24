"""Main AgentAtlas SDK facade."""

import logging
import os

from dotenv import load_dotenv
from openai import OpenAI

from agentatlas.browser_runtime import AtlasBrowserRuntimeMixin
from agentatlas.client import AtlasHostedClientMixin
from agentatlas.models import PlaybookRecord, SiteSchema, ValidationReport
from agentatlas.registry import (
    AtlasRegistry,
    DEFAULT_REGISTRY_SCOPE,
    DEFAULT_TASK_KEY,
    DEFAULT_VARIANT_KEY,
)
from agentatlas.supabase_client import get_supabase

load_dotenv()


class Atlas(AtlasHostedClientMixin, AtlasBrowserRuntimeMixin):
    def __init__(
        self,
        api_url: str | None = None,
        api_key: str | None = None,
        tenant_id: str | None = None,
        use_api: bool | None = None,
        api_timeout: float = 20.0,
        registry_scope: str = DEFAULT_REGISTRY_SCOPE,
        logger: logging.Logger | None = None,
    ):
        resolved_api_url = api_url or os.getenv("AGENTATLAS_API_URL")
        self.api_key = api_key or os.getenv("AGENTATLAS_API_KEY")
        self.tenant_id = tenant_id or os.getenv("AGENTATLAS_TENANT_ID")
        self.api_timeout = api_timeout
        self.registry_scope = registry_scope or os.getenv("AGENTATLAS_REGISTRY_SCOPE", DEFAULT_REGISTRY_SCOPE)
        self.api_url = resolved_api_url.rstrip("/") if resolved_api_url else None
        self.use_api = bool(self.api_url) if use_api is None else use_api
        if self.use_api and not self.api_url:
            raise ValueError("Hosted client mode requires api_url or AGENTATLAS_API_URL.")

        self.logger = logger or logging.getLogger("agentatlas")
        self.sb = None
        self.registry = None
        self.client = None
        if not self.use_api:
            self.sb = get_supabase()
            self.registry = AtlasRegistry(self.sb)
            self.client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
        self._session_cache = {}

    async def get_schema(
        self,
        site: str,
        url: str,
        variant_key: str | None = None,
        tenant_id: str | None = None,
        registry_scope: str | None = None,
    ) -> SiteSchema:
        resolved_variant_key = self.infer_variant_key(url=url, variant_key=variant_key)
        resolved_tenant_id = self.tenant_id if tenant_id is None else tenant_id
        resolved_registry_scope = registry_scope or self.registry_scope
        if self.use_api:
            return self._get_schema_via_api(
                site=site,
                url=url,
                variant_key=resolved_variant_key,
                registry_scope=resolved_registry_scope,
            )

        self.logger.info("agentatlas_schema_lookup", extra={"site": site, "url": url, "variant_key": resolved_variant_key})
        schema = self.registry.fetch_schema(
            site,
            url,
            variant_key=resolved_variant_key,
            tenant_id=resolved_tenant_id,
            registry_scope=resolved_registry_scope,
        )
        if schema:
            self.logger.info("agentatlas_registry_hit", extra={"site": site, "url": url, "variant_key": resolved_variant_key})
            return SiteSchema(
                site=site,
                url=url,
                route_key=schema["route_key"],
                status="found",
                confidence=schema["confidence"],
                elements=schema["elements"],
                source="registry",
                tokens_used=0,
                message="Schema found in registry. No LLM used.",
            )

        self.logger.info("agentatlas_schema_cold_start", extra={"site": site, "url": url, "variant_key": resolved_variant_key})
        learned = await self._learn_site(site, url)
        if not learned:
            return SiteSchema(
                site=site,
                url=url,
                route_key="unknown",
                status="not_found",
                confidence=0.0,
                elements={},
                source="not_found",
                tokens_used=0,
                message="Could not learn site. Page may be blocked or empty.",
            )
        learned = await self._admit_learned_schema(url, learned)
        if not learned or not learned.get("elements"):
            return SiteSchema(
                site=site,
                url=url,
                route_key=learned["route_key"] if learned else "unknown",
                status="not_found",
                confidence=0.0,
                elements={},
                source="not_found",
                tokens_used=learned.get("tokens_used", 0) if learned else 0,
                message="Learned schema did not produce any actionable locators.",
            )
        self.registry.save_schema(
            site,
            url,
            learned,
            variant_key=resolved_variant_key,
            tenant_id=resolved_tenant_id,
            registry_scope="private" if resolved_registry_scope == "private" else "public",
        )
        self.logger.info("agentatlas_schema_saved", extra={"site": site, "url": url, "variant_key": resolved_variant_key})
        return SiteSchema(
            site=site,
            url=url,
            route_key=learned["route_key"],
            status="learned",
            confidence=0.6,
            elements=learned["elements"],
            source="llm_learned",
            tokens_used=learned["tokens_used"],
            message=f"Schema learned and saved. Tokens used: {learned['tokens_used']}.",
        )

    async def get_playbook(
        self,
        site: str,
        url: str,
        task_key: str = DEFAULT_TASK_KEY,
        variant_key: str | None = None,
        tenant_id: str | None = None,
        registry_scope: str | None = None,
    ) -> PlaybookRecord | None:
        resolved_variant_key = self.infer_variant_key(url=url, variant_key=variant_key)
        resolved_tenant_id = self.tenant_id if tenant_id is None else tenant_id
        resolved_registry_scope = registry_scope or self.registry_scope
        if self.use_api:
            return self._resolve_schema_via_api(
                site=site,
                url=url,
                task_key=task_key,
                variant_key=resolved_variant_key,
                registry_scope=resolved_registry_scope,
            ).playbook
        return self.registry.get_playbook(
            site,
            url,
            task_key=task_key,
            variant_key=resolved_variant_key,
            tenant_id=resolved_tenant_id,
            registry_scope=resolved_registry_scope,
        )

    async def resolve_locator(
        self,
        site: str,
        url: str,
        element_name: str,
        variant_key: str | None = None,
        tenant_id: str | None = None,
        registry_scope: str | None = None,
    ) -> dict | None:
        resolved_variant_key = self.infer_variant_key(url=url, variant_key=variant_key)
        resolved_tenant_id = self.tenant_id if tenant_id is None else tenant_id
        resolved_registry_scope = registry_scope or self.registry_scope
        if self.use_api:
            return self._resolve_locator_via_api(
                site=site,
                url=url,
                element_name=element_name,
                variant_key=resolved_variant_key,
                registry_scope=resolved_registry_scope,
            ).locator
        return self.registry.resolve_locator(
            site,
            url,
            element_name,
            variant_key=resolved_variant_key,
            tenant_id=resolved_tenant_id,
            registry_scope=resolved_registry_scope,
        )

    async def record_outcome(
        self,
        site: str,
        url: str,
        status: str,
        task_key: str = DEFAULT_TASK_KEY,
        variant_key: str | None = None,
        metadata: dict | None = None,
        tenant_id: str | None = None,
        registry_scope: str | None = None,
    ) -> bool:
        resolved_variant_key = self.infer_variant_key(url=url, variant_key=variant_key)
        resolved_tenant_id = self.tenant_id if tenant_id is None else tenant_id
        resolved_registry_scope = registry_scope or self.registry_scope
        if self.use_api:
            return self._record_outcome_via_api(
                site=site,
                url=url,
                status=status,
                task_key=task_key,
                variant_key=resolved_variant_key,
                registry_scope=resolved_registry_scope,
                metadata=metadata,
            )
        return self.registry.record_outcome(
            site,
            url,
            status=status,
            task_key=task_key,
            variant_key=resolved_variant_key,
            metadata=metadata,
            tenant_id=resolved_tenant_id,
            registry_scope=resolved_registry_scope,
        )

    async def validate(
        self,
        site: str,
        url: str,
        task_key: str = DEFAULT_TASK_KEY,
        variant_key: str | None = None,
        tenant_id: str | None = None,
        registry_scope: str | None = None,
        learn_if_missing: bool = True,
        persist: bool = True,
        headless: bool = True,
        relearn_on_degraded: bool = True,
    ) -> ValidationReport:
        resolved_variant_key = self.infer_variant_key(url=url, variant_key=variant_key)
        resolved_tenant_id = self.tenant_id if tenant_id is None else tenant_id
        resolved_registry_scope = registry_scope or self.registry_scope
        if self.use_api:
            return self._validate_via_api(
                site=site,
                url=url,
                task_key=task_key,
                variant_key=resolved_variant_key,
                registry_scope=resolved_registry_scope,
                learn_if_missing=learn_if_missing,
                persist=persist,
                headless=headless,
                relearn_on_degraded=relearn_on_degraded,
            )
        return await self._validate_direct(
            site=site,
            url=url,
            task_key=task_key,
            variant_key=resolved_variant_key,
            tenant_id=resolved_tenant_id,
            registry_scope=resolved_registry_scope,
            learn_if_missing=learn_if_missing,
            persist=persist,
            headless=headless,
            relearn_on_degraded=relearn_on_degraded,
        )

    async def list_review_queue(self, limit: int = 50) -> list[dict]:
        scope = self.registry_scope if self.registry_scope != "auto" else "public"
        if self.use_api:
            return [item.__dict__ for item in self._list_review_queue_via_api(limit=limit, registry_scope=scope)]
        return self.registry.list_review_queue(
            tenant_id=self.tenant_id,
            registry_scope=scope,
            limit=limit,
        )

    async def list_review_audit(self, limit: int = 100) -> list[dict]:
        scope = self.registry_scope if self.registry_scope != "auto" else "auto"
        if self.use_api:
            return [item.__dict__ for item in self._list_review_audit_via_api(limit=limit, registry_scope=scope)]
        return self.registry.list_review_audit(
            tenant_id=self.tenant_id,
            registry_scope=scope,
            limit=limit,
        )

    async def promote_playbook(self, playbook_id, reviewer: str, approved: bool = True, notes: str = "") -> bool:
        if self.use_api:
            return self._promote_playbook_via_api(
                playbook_id=playbook_id,
                reviewer=reviewer,
                approved=approved,
                notes=notes,
            )
        return self.registry.promote_playbook(
            playbook_id=playbook_id,
            reviewer=reviewer,
            approved=approved,
            notes=notes,
        )

    async def get_route_scope_diff(
        self,
        site: str,
        url: str,
        task_key: str = DEFAULT_TASK_KEY,
        variant_key: str | None = None,
    ) -> dict | None:
        resolved_variant_key = self.infer_variant_key(url=url, variant_key=variant_key)
        if self.use_api:
            return self._get_route_scope_diff_via_api(
                site=site,
                url=url,
                task_key=task_key,
                variant_key=resolved_variant_key,
            ).__dict__
        return self.registry.get_route_scope_diff(
            site=site,
            url=url,
            task_key=task_key,
            variant_key=resolved_variant_key,
            tenant_id=self.tenant_id,
        )

    def list_revalidation_candidates(
        self,
        max_age_hours: int = 24,
        limit: int = 25,
        tenant_id: str | None = None,
        registry_scope: str | None = None,
    ) -> list[dict]:
        self._require_direct_mode("list_revalidation_candidates")
        resolved_tenant_id = self.tenant_id if tenant_id is None else tenant_id
        resolved_registry_scope = registry_scope or self.registry_scope
        return self.registry.list_revalidation_candidates(
            max_age_hours=max_age_hours,
            limit=limit,
            tenant_id=resolved_tenant_id,
            registry_scope=resolved_registry_scope,
        )

    async def run_revalidation_cycle(
        self,
        max_age_hours: int = 24,
        limit: int = 25,
        headless: bool = True,
        tenant_id: str | None = None,
        registry_scope: str | None = None,
    ) -> list[dict]:
        self._require_direct_mode("run_revalidation_cycle")
        resolved_tenant_id = self.tenant_id if tenant_id is None else tenant_id
        resolved_registry_scope = registry_scope or self.registry_scope
        candidates = self.registry.list_revalidation_candidates(
            max_age_hours=max_age_hours,
            limit=limit,
            tenant_id=resolved_tenant_id,
            registry_scope=resolved_registry_scope,
        )
        results = []
        for candidate in candidates:
            report = await self.validate(
                site=candidate["site"],
                url=candidate["url"],
                variant_key=candidate.get("variant_key"),
                tenant_id=resolved_tenant_id,
                registry_scope=resolved_registry_scope,
                learn_if_missing=False,
                persist=True,
                headless=headless,
                relearn_on_degraded=True,
            )
            results.append(
                {
                    "playbook_id": candidate["playbook_id"],
                    "site": candidate["site"],
                    "url": candidate["url"],
                    "variant_key": candidate.get("variant_key"),
                    "revalidation_reason": candidate.get("revalidation_reason"),
                    "status": report.status,
                    "success_rate": report.success_rate,
                    "last_validated_at": report.last_validated_at,
                }
            )
        return results

    async def execute(self, *args, **kwargs):
        raise RuntimeError(
            "Atlas.execute() has been demoted from the main SDK surface. "
            "Use agentatlas.executor.AgentExecutor for browser execution tooling."
        )
