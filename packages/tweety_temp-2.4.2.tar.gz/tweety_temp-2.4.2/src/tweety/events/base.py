class BaseUpdateMethod:
    pass

