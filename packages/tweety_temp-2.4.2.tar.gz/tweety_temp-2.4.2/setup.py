from distutils.core import setup

install_requires = [
    "beautifulsoup4[lxml]~=4.12",
    "openpyxl",
    "httpx[http2]",
    "dateutils",
    "anticaptchaofficial",
    "capsolver",
    "2captcha-python",
    "python-magic",
    "python-magic-bin; platform_system == 'Windows'"
]

setup(
    name='tweety-temp',
    packages=['tweety', 'tweety.types', 'tweety.events', 'tweety.captcha'],
    version='2.4.2',
    license='MIT',
)
