"""Tests for endpoint path constants."""

import pytest

from skytells._endpoints import API_BASE_URL, ENDPOINTS


def test_api_base_url():
    assert API_BASE_URL == "https://api.skytells.ai/v1"


def test_static_endpoints():
    assert ENDPOINTS.PREDICT == "/predict"
    assert ENDPOINTS.PREDICTIONS == "/predictions"
    assert ENDPOINTS.MODELS == "/models"


def test_model_by_slug():
    assert ENDPOINTS.MODEL_BY_SLUG("flux-pro") == "/model/flux-pro"
    assert ENDPOINTS.MODEL_BY_SLUG("truefusion") == "/model/truefusion"


def test_prediction_by_id():
    assert ENDPOINTS.PREDICTION_BY_ID("pred_abc") == "/predictions/pred_abc"


def test_stream_prediction_by_id():
    assert ENDPOINTS.STREAM_PREDICTION_BY_ID("pred_abc") == "/predictions/pred_abc/stream"


def test_cancel_prediction_by_id():
    assert ENDPOINTS.CANCEL_PREDICTION_BY_ID("pred_abc") == "/predictions/pred_abc/cancel"


def test_delete_prediction_by_id():
    assert ENDPOINTS.DELETE_PREDICTION_BY_ID("pred_abc") == "/predictions/pred_abc/delete"
