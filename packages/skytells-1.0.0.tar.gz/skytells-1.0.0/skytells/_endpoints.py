"""API base URL and endpoint path constants."""

from __future__ import annotations

API_BASE_URL: str = "https://api.skytells.ai/v1"


class ENDPOINTS:
    """Namespace for all Skytells API endpoint paths."""

    PREDICT: str = "/predict"
    PREDICTIONS: str = "/predictions"
    MODELS: str = "/models"

    @staticmethod
    def MODEL_BY_SLUG(slug: str) -> str:
        return f"/model/{slug}"

    @staticmethod
    def PREDICTION_BY_ID(id: str) -> str:
        return f"/predictions/{id}"

    @staticmethod
    def STREAM_PREDICTION_BY_ID(id: str) -> str:
        return f"/predictions/{id}/stream"

    @staticmethod
    def CANCEL_PREDICTION_BY_ID(id: str) -> str:
        return f"/predictions/{id}/cancel"

    @staticmethod
    def DELETE_PREDICTION_BY_ID(id: str) -> str:
        return f"/predictions/{id}/delete"
