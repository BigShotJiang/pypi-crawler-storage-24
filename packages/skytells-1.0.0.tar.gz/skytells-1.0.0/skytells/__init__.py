"""
Skytells Python SDK.

Official Python SDK for the Skytells AI platform — run image, video, audio, music,
text, and code models with a single function call.

Usage::

    from skytells import SkytellsClient

    client = SkytellsClient("sk-your-api-key")
    prediction = client.run("flux-pro", input={"prompt": "An astronaut on the moon"})
    print(prediction.output)

Async usage::

    import asyncio
    import skytells

    async def main():
        client = skytells.AsyncSkytellsClient("sk-your-api-key")
        prediction = await client.run("flux-pro", input={"prompt": "A cat"})
        print(prediction.output)

    asyncio.run(main())
"""

from __future__ import annotations

from typing import Any, Dict, Optional, Union

from ._client import (
    AsyncPrediction,
    AsyncSkytellsClient,
    ModelsAPI,
    Prediction,
    PredictionsAPI,
    SkytellsClient,
)
from ._endpoints import API_BASE_URL
from .types import (
    ApiErrorId,
    ClientOptions,
    ModelFieldsOptions,
    ModelPrivacy,
    ModelType,
    OnProgressCallback,
    PaginatedResponse,
    Pagination,
    PredictionRequest,
    PredictionSource,
    PredictionStatus,
    PredictionType,
    PredictionsListOptions,
    PricingOperator,
    PricingUnit,
    QueueItem,
    RetryOptions,
    RunOptions,
    WaitOptions,
)
from .types.shared import SkytellsError

__version__: str = "1.0.0"
__all__ = [
    # Factory
    "Skytells",
    "create_client",
    # Clients
    "SkytellsClient",
    "AsyncSkytellsClient",
    # Sub-APIs
    "PredictionsAPI",
    "ModelsAPI",
    # Prediction objects
    "Prediction",
    "AsyncPrediction",
    # Error
    "SkytellsError",
    # Constants
    "API_BASE_URL",
    # Enums
    "ApiErrorId",
    "ModelPrivacy",
    "ModelType",
    "PredictionSource",
    "PredictionStatus",
    "PredictionType",
    "PricingOperator",
    "PricingUnit",
    # Options / request types
    "ClientOptions",
    "ModelFieldsOptions",
    "OnProgressCallback",
    "PaginatedResponse",
    "Pagination",
    "PredictionRequest",
    "PredictionsListOptions",
    "QueueItem",
    "RetryOptions",
    "RunOptions",
    "WaitOptions",
    # Version
    "__version__",
]


def Skytells(
    api_key: Optional[str] = None,
    options: Optional[Union[ClientOptions, Dict[str, Any]]] = None,
    *,
    base_url: Optional[str] = None,
    timeout: int = 60_000,
    headers: Optional[Dict[str, str]] = None,
    retry: Optional[Any] = None,
) -> SkytellsClient:
    """
    Factory function — creates and returns a :class:`SkytellsClient`.

    Mirrors the JavaScript SDK's ``Skytells(apiKey?, options?)`` factory.

    Args:
        api_key: Your Skytells API key (starts with ``sk-``).
        options: Client options as a :class:`ClientOptions` instance or dict.
        base_url: Override the default API base URL.
        timeout:  Request timeout in milliseconds (default: ``60000``).
        headers:  Custom headers to include in every request.
        retry:    Retry config as a :class:`RetryOptions` instance or dict.

    Returns:
        A configured :class:`SkytellsClient` instance.

    Example::

        import skytells

        client = skytells.Skytells("sk-your-api-key")
        prediction = client.run("flux-pro", input={"prompt": "A cat"})

        # With options
        client = skytells.Skytells(
            "sk-your-api-key",
            timeout=30000,
            retry={"retries": 2},
        )
    """
    return SkytellsClient(
        api_key=api_key,
        options=options,
        base_url=base_url,
        timeout=timeout,
        headers=headers,
        retry=retry,
    )


#: Deprecated alias for :func:`Skytells`. Use ``Skytells()`` instead.
create_client = Skytells
