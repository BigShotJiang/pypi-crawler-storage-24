"""
Lean parity tests -- verify the compiled Lean kernel produces identical
results to the Python implementation for all test cases.

Runs the same test_parity.py scenarios but through the Lean subprocess bridge.
"""
import json
import time
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

try:
    from guardspine_kernel.lean_shim import (
        canonical_json,
        compute_content_hash,
        seal_bundle,
        verify_bundle,
    )
    LEAN_AVAILABLE = True
except ImportError as e:
    LEAN_AVAILABLE = False
    LEAN_IMPORT_ERROR = str(e)

# Also import Python implementations for comparison
from guardspine_kernel.canonical import canonical_json as py_canonical_json
from guardspine_kernel.seal import compute_content_hash as py_compute_content_hash
from guardspine_kernel.seal import seal_bundle as py_seal_bundle

pytestmark = pytest.mark.skipif(not LEAN_AVAILABLE, reason="Lean binary not found")


class TestCanonicalJsonParity:
    """Lean canonical_json must match Python canonical_json exactly."""

    CASES = [
        {"z": 1, "a": 2},
        {"key": [1, 2, 3]},
        {"outer": {"z": 1, "a": 2}},
        {"key": None},
        True,
        False,
        42,
        -17,
        0,
        3.14,
        1.0,
        "hello\nworld",
        {},
        [],
        {"a": 1, "b": [True, None, {"c": 3}]},
    ]

    @pytest.mark.parametrize("value", CASES, ids=[str(c)[:40] for c in CASES])
    def test_parity(self, value):
        lean_result = canonical_json(value)
        py_result = py_canonical_json(value)
        assert lean_result == py_result, (
            f"Canonical JSON mismatch:\n  Lean:   {lean_result!r}\n  Python: {py_result!r}"
        )


class TestContentHashParity:
    """Lean compute_content_hash must match Python compute_content_hash exactly."""

    CASES = [
        {"message": "test"},
        {},
        {"a": 1, "b": 2},
        {"z": 1, "a": 2},  # key order
        {"nested": {"x": [1, 2, 3]}},
    ]

    @pytest.mark.parametrize("content", CASES, ids=[str(c)[:40] for c in CASES])
    def test_parity(self, content):
        lean_result = compute_content_hash(content)
        py_result = py_compute_content_hash(content)
        assert lean_result == py_result


class TestSealBundleParity:
    """Lean seal_bundle must produce identical hashes to Python seal_bundle."""

    def test_single_item(self):
        items = [
            {"item_id": "item-001", "content_type": "guardspine/audit_event",
             "content": {"message": "test"}}
        ]
        lean_result = seal_bundle(items, bundle_id="fixed", created_at="2026-01-01T00:00:00Z")
        py_result = py_seal_bundle(items, bundle_id="fixed", created_at="2026-01-01T00:00:00Z")

        # Compare cryptographic outputs (not metadata)
        assert lean_result["immutability_proof"]["root_hash"] == py_result["immutability_proof"]["root_hash"]
        assert len(lean_result["immutability_proof"]["hash_chain"]) == len(py_result["immutability_proof"]["hash_chain"])

        for i, (lean_link, py_link) in enumerate(zip(
            lean_result["immutability_proof"]["hash_chain"],
            py_result["immutability_proof"]["hash_chain"]
        )):
            assert lean_link["chain_hash"] == py_link["chain_hash"], f"chain_hash mismatch at {i}"
            assert lean_link["content_hash"] == py_link["content_hash"], f"content_hash mismatch at {i}"
            assert lean_link["previous_hash"] == py_link["previous_hash"], f"previous_hash mismatch at {i}"

    def test_multi_item(self):
        items = [
            {"item_id": f"item-{i:03d}", "content_type": "test", "content": {"seq": i}}
            for i in range(5)
        ]
        lean_result = seal_bundle(items, bundle_id="fixed", created_at="2026-01-01T00:00:00Z")
        py_result = py_seal_bundle(items, bundle_id="fixed", created_at="2026-01-01T00:00:00Z")

        assert lean_result["immutability_proof"]["root_hash"] == py_result["immutability_proof"]["root_hash"]

        for i in range(5):
            lean_link = lean_result["immutability_proof"]["hash_chain"][i]
            py_link = py_result["immutability_proof"]["hash_chain"][i]
            assert lean_link["chain_hash"] == py_link["chain_hash"], f"chain_hash mismatch at {i}"


class TestVerifyBundleParity:
    """Lean verify_bundle must agree with Python verify_bundle."""

    def test_valid_bundle(self):
        items = [
            {"item_id": "item-001", "content_type": "guardspine/audit_event",
             "content": {"message": "test"}}
        ]
        bundle = py_seal_bundle(items, bundle_id="fixed", created_at="2026-01-01T00:00:00Z")
        result = verify_bundle(bundle)
        assert result["valid"], f"Lean verify failed: {result['errors']}"

    def test_multi_item_valid(self):
        items = [
            {"item_id": f"item-{i:03d}", "content_type": "test", "content": {"seq": i}}
            for i in range(5)
        ]
        bundle = py_seal_bundle(items, bundle_id="fixed", created_at="2026-01-01T00:00:00Z")
        result = verify_bundle(bundle)
        assert result["valid"], f"Lean verify failed: {result['errors']}"

    def test_tampered_content_detected(self):
        items = [
            {"item_id": "item-001", "content_type": "test", "content": {"ok": True}}
        ]
        bundle = py_seal_bundle(items)
        # Tamper with content
        bundle["items"][0]["content"] = {"ok": False}
        result = verify_bundle(bundle)
        assert not result["valid"]
        error_codes = [e["code"] for e in result["errors"]]
        assert "CONTENT_HASH_MISMATCH" in error_codes


class TestSubprocessLatency:
    """Measure subprocess call latency for the exit gate."""

    def test_latency_100_calls(self):
        """100+ subprocess round-trips with no hangs."""
        times = []
        for i in range(100):
            start = time.perf_counter()
            result = compute_content_hash({"seq": i})
            elapsed = time.perf_counter() - start
            times.append(elapsed)
            assert result.startswith("sha256:")

        avg_ms = sum(times) / len(times) * 1000
        p99_ms = sorted(times)[98] * 1000
        total_s = sum(times)

        print(f"\n  Subprocess latency (100 calls):")
        print(f"    Average: {avg_ms:.1f} ms")
        print(f"    P99:     {p99_ms:.1f} ms")
        print(f"    Total:   {total_s:.2f} s")

        # No hangs: all calls completed
        assert len(times) == 100
        # Sanity: each call should be < 5s
        assert max(times) < 5.0, f"Max latency {max(times)*1000:.0f}ms exceeds 5s"
