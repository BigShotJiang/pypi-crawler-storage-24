"""
Lean bridge shim for guardspine-kernel.

Drop-in replacement for canonical.py, seal.py, verify.py that delegates
to the compiled Lean binary via subprocess. Used for cross-language parity
testing and as a migration step toward Lean-canonical kernel.

Protocol: guardspine.exe <entrypoint> reads JSON from stdin, writes
{"ok":true,"result":...} or {"ok":false,"error":"..."} to stdout.

Fallback: if LEAN_EXE is not found, raises ImportError so callers can
fall back to the Python implementation.
"""
from __future__ import annotations

import json
import os
import subprocess
import time
from pathlib import Path
from typing import Any

# Lean binary location: env var only (no hard-coded paths)
_LEAN_EXE_PATH = os.environ.get("GUARDSPINE_LEAN_BIN") or os.environ.get("GUARDSPINE_LEAN_EXE")

if not _LEAN_EXE_PATH:
    raise ImportError(
        "Lean binary not configured. "
        "Set GUARDSPINE_LEAN_BIN to the path of the guardspine binary, "
        "or build with 'lake build guardspine' in the guardspine-lean repo."
    )

LEAN_EXE = Path(_LEAN_EXE_PATH)

if not LEAN_EXE.exists():
    raise ImportError(
        f"Lean binary not found at {LEAN_EXE}. "
        "Verify GUARDSPINE_LEAN_BIN points to a valid guardspine executable."
    )


def _call_lean(entrypoint: str, payload: dict[str, Any]) -> Any:
    """Call a Lean entrypoint via subprocess. Returns the result field."""
    start = time.perf_counter()
    proc = subprocess.run(
        [str(LEAN_EXE), entrypoint],
        input=json.dumps(payload) + "\n",
        text=True,
        capture_output=True,
        check=False,
        timeout=30,
    )
    elapsed_ms = (time.perf_counter() - start) * 1000

    if proc.returncode != 0:
        stderr = proc.stderr.strip()
        stdout = proc.stdout.strip()
        raise RuntimeError(
            f"Lean {entrypoint} failed (exit {proc.returncode}, {elapsed_ms:.1f}ms): "
            f"{stderr or stdout or 'no output'}"
        )

    response = json.loads(proc.stdout)
    if not response.get("ok"):
        raise RuntimeError(f"Lean {entrypoint} error: {response.get('error', 'unknown')}")

    return response["result"]


# ---------- canonical.py replacement ----------

def canonical_json(value: Any) -> str:
    """RFC 8785 canonical JSON via Lean."""
    return _call_lean("canonical_json", {"value": value})


# ---------- seal.py replacements ----------

def compute_content_hash(content: dict[str, Any]) -> str:
    """SHA-256 of canonical JSON via Lean."""
    return _call_lean("compute_content_hash", {"content": content})


def seal_bundle(
    items: list[dict[str, Any]],
    options: Any = None,
    bundle_id: str | None = None,
    version: str = "0.2.0",
    created_at: str | None = None,
) -> dict[str, Any]:
    """Seal a bundle via Lean. Returns dict with immutability_proof and items.

    Note: bundle_id, version, created_at are handled Python-side since the
    Lean kernel only computes hashes (no UUID/timestamp generation).
    """
    import uuid
    from datetime import datetime, timezone

    # Lean computes the cryptographic parts
    lean_result = _call_lean("seal_bundle", {"items": items})

    # Python adds metadata (Lean kernel is pure math, no IO)
    if bundle_id is None:
        bundle_id = str(uuid.uuid4())
    if created_at is None:
        created_at = datetime.now(timezone.utc).isoformat()

    return {
        "bundle_id": bundle_id,
        "version": version,
        "created_at": created_at,
        "immutability_proof": lean_result["immutability_proof"],
        "items": lean_result["items"],
    }


# ---------- verify.py replacements ----------

def verify_bundle(
    bundle: dict[str, Any],
    accept_proof_versions: list[str] | None = None,
    public_keys: dict[str, str] | None = None,
    hmac_secret: str | None = None,
    require_signatures: bool = False,
) -> dict[str, Any]:
    """Verify a bundle via Lean. Returns {"valid": bool, "errors": [...]}.

    Note: signature verification is not yet implemented in Lean.
    If require_signatures is True, falls back to Python verify.
    """
    if require_signatures:
        # Signature verification not in Lean yet -- fall back
        from .verify import verify_bundle as py_verify_bundle
        return py_verify_bundle(
            bundle,
            accept_proof_versions=accept_proof_versions,
            public_keys=public_keys,
            hmac_secret=hmac_secret,
            require_signatures=require_signatures,
        )

    # Pass the bundle structure to Lean for hash/chain/root verification
    payload: dict[str, Any] = {
        "items": bundle.get("items", []),
        "immutability_proof": bundle.get("immutability_proof", {}),
    }
    # Include version if present (Lean validates it)
    if "version" in bundle:
        payload["version"] = bundle["version"]
    return _call_lean("verify_bundle", payload)
