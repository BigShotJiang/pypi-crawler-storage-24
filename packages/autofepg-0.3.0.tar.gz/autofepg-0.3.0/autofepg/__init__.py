"""
AutoFE - Playground (autofepg) v0.3.0
Automatic Feature Engineering & Selection for Tabular ML Competitions.

Generate, evaluate, and select engineered features with zero target leakage.

Quick Start
    from autofepg import select_features
    result = select_features(X_train, y_train, X_test, task="classification")
    X_train_new = result["X_train"]
    X_test_new = result["X_test"]

Class API
    from autofepg import AutoFE
    autofe = AutoFE(task="classification", time_budget=3600)
    X_train_new, X_test_new = autofe.fit_select(X_train, y_train, X_test)
"""

from autofepg.core import AutoFE, select_features
from autofepg.generators import (
    BayesianPriorFeature,
    CountEncoding,
    CountEncodingOnDigit,
    CountEncodingOnPair,
    CyclicalFeature,
    DecimalDigitFeature,
    DigitBasePairTE,
    DigitFeature,
    DigitInteraction,
    DualRepresentationFeature,
    EntropyFeature,
    ExternalEntropyFeature,
    ExternalWoEFeature,
    FeatureGenerator,
    FrequencyEncoding,
    GeneticProgrammingFeature,
    NumToCat,
    OOFTargetAggFeature,
    PairInteraction,
    PairProductFeature,
    QuantileBinFeature,
    RoundFeature,
    TargetEncoding,
    TargetEncodingOnDigit,
    TargetEncodingOnPair,
    WoEFeature,
)
from autofepg.builder import FeatureCandidateBuilder
from autofepg.engine import XGBCVEngine

__version__ = "0.3.0"

__all__ = [
    # Main API
    "AutoFE",
    "select_features",
    # Building blocks
    "FeatureCandidateBuilder",
    "XGBCVEngine",
    # Generators
    "FeatureGenerator",
    "TargetEncoding",
    "CountEncoding",
    "FrequencyEncoding",
    "DigitFeature",
    "DecimalDigitFeature",
    "DigitInteraction",
    "QuantileBinFeature",
    "NumToCat",
    "RoundFeature",
    "DualRepresentationFeature",
    "PairInteraction",
    "PairProductFeature",
    "TargetEncodingOnPair",
    "CountEncodingOnPair",
    "TargetEncodingOnDigit",
    "CountEncodingOnDigit",
    "DigitBasePairTE",
    "OOFTargetAggFeature",
    "CyclicalFeature",
    "WoEFeature",
    "EntropyFeature",
    "GeneticProgrammingFeature",
    # Original-dataset features
    "BayesianPriorFeature",
    "ExternalWoEFeature",
    "ExternalEntropyFeature",
]
