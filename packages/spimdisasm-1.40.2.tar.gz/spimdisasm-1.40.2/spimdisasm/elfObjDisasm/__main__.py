#!/usr/bin/env python3

# SPDX-FileCopyrightText: © 2022-2024 Decompollaborate
# SPDX-License-Identifier: MIT

from __future__ import annotations

from . import elfObjDisasmMain


if __name__ == "__main__":
    elfObjDisasmMain()
