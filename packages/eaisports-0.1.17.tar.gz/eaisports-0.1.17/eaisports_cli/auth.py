"""
Multi-provider authentication system for EAISports.

Supports OAuth device code flows (Nous Portal, future: OpenAI Codex) and
traditional API key providers (OpenRouter, custom endpoints). Auth state
is persisted in ~/.eaisports/auth.json with cross-process file locking.

Architecture:
- ProviderConfig registry defines known OAuth providers
- Auth store (auth.json) holds per-provider credential state
- resolve_provider() picks the active provider via priority chain
- resolve_*_runtime_credentials() handles token refresh and key minting
- logout_command() is the CLI entry point for clearing auth

This module is the dispatch/orchestration layer.  Provider-specific logic
lives in auth_store (persistence), auth_codex (Codex/OpenAI), and
auth_nous (Nous Portal).  All public names are re-exported here for
backward compatibility.
"""

from __future__ import annotations

import logging
import os
from typing import Any, Dict, List, Optional

import httpx
import yaml

from eaisports_cli.config import get_config_path
from eaisports_constants import OPENROUTER_BASE_URL

logger = logging.getLogger(__name__)

# =============================================================================
# Re-exports from auth_store (shared persistence & utilities)
# =============================================================================

from eaisports_cli.auth_store import (  # noqa: E402, F401
    AUTH_STORE_VERSION,
    AUTH_LOCK_TIMEOUT_SECONDS,
    AuthError,
    ProviderConfig,
    PROVIDER_REGISTRY,
    format_auth_error,
    _token_fingerprint,
    _oauth_trace_enabled,
    _oauth_trace,
    _auth_file_path,
    _auth_lock_path,
    _auth_lock_holder,
    _auth_store_lock,
    _load_auth_store,
    _save_auth_store,
    _load_provider_state,
    _save_provider_state,
    get_provider_auth_state,
    get_active_provider,
    clear_provider_auth,
    deactivate_provider,
    _parse_iso_timestamp,
    _is_expiring,
    _coerce_ttl_seconds,
    _optional_base_url,
    _decode_jwt_claims,
    _codex_access_token_is_expiring,
    _is_remote_session,
    _resolve_verify,
)

# =============================================================================
# Re-exports from auth_codex (Codex/OpenAI OAuth)
# =============================================================================

from eaisports_cli.auth_codex import (  # noqa: E402, F401
    DEFAULT_CODEX_BASE_URL,
    CODEX_OAUTH_CLIENT_ID,
    CODEX_OAUTH_TOKEN_URL,
    CODEX_ACCESS_TOKEN_REFRESH_SKEW_SECONDS,
    _read_codex_tokens,
    _save_codex_tokens,
    _refresh_codex_auth_tokens,
    _import_codex_cli_tokens,
    resolve_codex_runtime_credentials,
    get_codex_auth_status,
    _login_openai_codex,
    _codex_device_code_login,
)

# =============================================================================
# Re-exports from auth_nous (Nous Portal OAuth)
# =============================================================================

from eaisports_cli.auth_wallet import (  # noqa: E402, F401
    DEFAULT_EAISPORTS_API_URL,
    _read_wallet_tokens,
    _save_wallet_tokens,
    _request_device_code as _request_wallet_device_code,
    _poll_for_token as _poll_wallet_for_token,
    _login_wallet,
    resolve_wallet_runtime_credentials,
    get_wallet_auth_status,
)

# =============================================================================
# Re-exports from auth_nous (Nous Portal OAuth)
# =============================================================================

from eaisports_cli.auth_nous import (  # noqa: E402, F401
    DEFAULT_NOUS_PORTAL_URL,
    DEFAULT_NOUS_INFERENCE_URL,
    DEFAULT_NOUS_CLIENT_ID,
    DEFAULT_NOUS_SCOPE,
    DEFAULT_AGENT_KEY_MIN_TTL_SECONDS,
    ACCESS_TOKEN_REFRESH_SKEW_SECONDS,
    DEVICE_AUTH_POLL_INTERVAL_CAP_SECONDS,
    _request_device_code,
    _poll_for_token,
    _refresh_access_token,
    _mint_agent_key,
    fetch_nous_models,
    _agent_key_is_usable,
    resolve_nous_runtime_credentials,
    get_nous_auth_status,
    _login_nous,
)


# =============================================================================
# Kimi Code Endpoint Detection
# =============================================================================

# Kimi Code (platform.kimi.ai) issues keys prefixed "sk-kimi-" that only work
# on api.kimi.com/coding/v1.  Legacy keys from platform.moonshot.ai work on
# api.moonshot.ai/v1 (the default).  Auto-detect when user hasn't set
# KIMI_BASE_URL explicitly.
KIMI_CODE_BASE_URL = "https://api.kimi.com/coding/v1"


def _resolve_kimi_base_url(api_key: str, default_url: str, env_override: str) -> str:
    """Return the correct Kimi base URL based on the API key prefix.

    If the user has explicitly set KIMI_BASE_URL, that always wins.
    Otherwise, sk-kimi- prefixed keys route to api.kimi.com/coding/v1.
    """
    if env_override:
        return env_override
    if api_key.startswith("sk-kimi-"):
        return KIMI_CODE_BASE_URL
    return default_url


# =============================================================================
# Z.AI Endpoint Detection
# =============================================================================

# Z.AI has separate billing for general vs coding plans, and global vs China
# endpoints.  A key that works on one may return "Insufficient balance" on
# another.  We probe at setup time and store the working endpoint.

ZAI_ENDPOINTS = [
    # (id, base_url, default_model, label)
    ("global",        "https://api.z.ai/api/paas/v4",        "glm-5",   "Global"),
    ("cn",            "https://open.bigmodel.cn/api/paas/v4", "glm-5",   "China"),
    ("coding-global", "https://api.z.ai/api/coding/paas/v4",  "glm-4.7", "Global (Coding Plan)"),
    ("coding-cn",     "https://open.bigmodel.cn/api/coding/paas/v4", "glm-4.7", "China (Coding Plan)"),
]


def detect_zai_endpoint(api_key: str, timeout: float = 8.0) -> Optional[Dict[str, str]]:
    """Probe z.ai endpoints to find one that accepts this API key.

    Returns {"id": ..., "base_url": ..., "model": ..., "label": ...} for the
    first working endpoint, or None if all fail.
    """
    for ep_id, base_url, model, label in ZAI_ENDPOINTS:
        try:
            resp = httpx.post(
                f"{base_url}/chat/completions",
                headers={
                    "Authorization": f"Bearer {api_key}",
                    "Content-Type": "application/json",
                },
                json={
                    "model": model,
                    "stream": False,
                    "max_tokens": 1,
                    "messages": [{"role": "user", "content": "ping"}],
                },
                timeout=timeout,
            )
            if resp.status_code == 200:
                logger.debug("Z.AI endpoint probe: %s (%s) OK", ep_id, base_url)
                return {
                    "id": ep_id,
                    "base_url": base_url,
                    "model": model,
                    "label": label,
                }
            logger.debug("Z.AI endpoint probe: %s returned %s", ep_id, resp.status_code)
        except Exception as exc:
            logger.debug("Z.AI endpoint probe: %s failed: %s", ep_id, exc)
    return None


# =============================================================================
# Provider Resolution — picks which provider to use
# =============================================================================

def resolve_provider(
    requested: Optional[str] = None,
    *,
    explicit_api_key: Optional[str] = None,
    explicit_base_url: Optional[str] = None,
) -> str:
    """
    Determine which inference provider to use.

    Priority (when requested="auto" or None):
    1. active_provider in auth.json with valid credentials
    2. Explicit CLI api_key/base_url -> "openrouter"
    3. OPENAI_API_KEY or OPENROUTER_API_KEY env vars -> "openrouter"
    4. Provider-specific API keys (GLM, Kimi, MiniMax) -> that provider
    5. Fallback: "openrouter"
    """
    normalized = (requested or "auto").strip().lower()

    # Normalize provider aliases
    _PROVIDER_ALIASES = {
        "glm": "zai", "z-ai": "zai", "z.ai": "zai", "zhipu": "zai",
        "kimi": "kimi-coding", "moonshot": "kimi-coding",
        "minimax-china": "minimax-cn", "minimax_cn": "minimax-cn",
    }
    normalized = _PROVIDER_ALIASES.get(normalized, normalized)

    if normalized in {"openrouter", "custom"}:
        return "openrouter"
    if normalized in PROVIDER_REGISTRY:
        return normalized
    if normalized != "auto":
        raise AuthError(
            f"Unknown provider '{normalized}'.",
            code="invalid_provider",
        )

    # Explicit one-off CLI creds always mean openrouter/custom
    if explicit_api_key or explicit_base_url:
        return "openrouter"

    # Check auth store for an active OAuth provider
    try:
        auth_store = _load_auth_store()
        active = auth_store.get("active_provider")
        if active and active in PROVIDER_REGISTRY:
            status = get_auth_status(active)
            if status.get("logged_in"):
                return active
    except Exception as e:
        logger.debug("Could not detect active auth provider: %s", e)

    if os.getenv("OPENAI_API_KEY") or os.getenv("OPENROUTER_API_KEY"):
        return "openrouter"

    # Auto-detect API-key providers by checking their env vars
    for pid, pconfig in PROVIDER_REGISTRY.items():
        if pconfig.auth_type != "api_key":
            continue
        for env_var in pconfig.api_key_env_vars:
            if os.getenv(env_var, "").strip():
                return pid

    return "openrouter"


# =============================================================================
# Status helpers
# =============================================================================

def get_api_key_provider_status(provider_id: str) -> Dict[str, Any]:
    """Status snapshot for API-key providers (z.ai, Kimi, MiniMax)."""
    pconfig = PROVIDER_REGISTRY.get(provider_id)
    if not pconfig or pconfig.auth_type != "api_key":
        return {"configured": False}

    api_key = ""
    key_source = ""
    for env_var in pconfig.api_key_env_vars:
        val = os.getenv(env_var, "").strip()
        if val:
            api_key = val
            key_source = env_var
            break

    env_url = ""
    if pconfig.base_url_env_var:
        env_url = os.getenv(pconfig.base_url_env_var, "").strip()

    if provider_id == "kimi-coding":
        base_url = _resolve_kimi_base_url(api_key, pconfig.inference_base_url, env_url)
    elif env_url:
        base_url = env_url
    else:
        base_url = pconfig.inference_base_url

    return {
        "configured": bool(api_key),
        "provider": provider_id,
        "name": pconfig.name,
        "key_source": key_source,
        "base_url": base_url,
        "logged_in": bool(api_key),  # compat with OAuth status shape
    }


def get_auth_status(provider_id: Optional[str] = None) -> Dict[str, Any]:
    """Generic auth status dispatcher."""
    target = provider_id or get_active_provider()
    if target == "nous":
        return get_nous_auth_status()
    if target == "openai-codex":
        return get_codex_auth_status()
    if target == "eaisports-wallet":
        return get_wallet_auth_status()
    # API-key providers
    pconfig = PROVIDER_REGISTRY.get(target)
    if pconfig and pconfig.auth_type == "api_key":
        return get_api_key_provider_status(target)
    return {"logged_in": False}


def resolve_api_key_provider_credentials(provider_id: str) -> Dict[str, Any]:
    """Resolve API key and base URL for an API-key provider.

    Returns dict with: provider, api_key, base_url, source.
    """
    pconfig = PROVIDER_REGISTRY.get(provider_id)
    if not pconfig or pconfig.auth_type != "api_key":
        raise AuthError(
            f"Provider '{provider_id}' is not an API-key provider.",
            provider=provider_id,
            code="invalid_provider",
        )

    api_key = ""
    key_source = ""
    for env_var in pconfig.api_key_env_vars:
        val = os.getenv(env_var, "").strip()
        if val:
            api_key = val
            key_source = env_var
            break

    env_url = ""
    if pconfig.base_url_env_var:
        env_url = os.getenv(pconfig.base_url_env_var, "").strip()

    if provider_id == "kimi-coding":
        base_url = _resolve_kimi_base_url(api_key, pconfig.inference_base_url, env_url)
    elif env_url:
        base_url = env_url.rstrip("/")
    else:
        base_url = pconfig.inference_base_url

    return {
        "provider": provider_id,
        "api_key": api_key,
        "base_url": base_url.rstrip("/"),
        "source": key_source or "default",
    }


# =============================================================================
# External credential detection
# =============================================================================

def detect_external_credentials() -> List[Dict[str, Any]]:
    """Scan for credentials from other CLI tools that EAISports can reuse.

    Returns a list of dicts, each with:
      - provider: str   -- EAISports provider id (e.g. "openai-codex")
      - path: str       -- filesystem path where creds were found
      - label: str      -- human-friendly description for the setup UI
    """
    from pathlib import Path
    found: List[Dict[str, Any]] = []

    # Codex CLI: ~/.codex/auth.json (importable, not shared)
    cli_tokens = _import_codex_cli_tokens()
    if cli_tokens:
        codex_path = Path.home() / ".codex" / "auth.json"
        found.append({
            "provider": "openai-codex",
            "path": str(codex_path),
            "label": f"Codex CLI credentials found ({codex_path}) — run `eaisports login` to create a separate session",
        })

    return found


# =============================================================================
# CLI Commands — login / logout
# =============================================================================

def _update_config_for_provider(provider_id: str, inference_base_url: str):
    """Update config.yaml and auth.json to reflect the active provider."""
    # Set active_provider in auth.json so auto-resolution picks this provider
    with _auth_store_lock():
        auth_store = _load_auth_store()
        auth_store["active_provider"] = provider_id
        _save_auth_store(auth_store)

    # Update config.yaml model section
    config_path = get_config_path()
    config_path.parent.mkdir(parents=True, exist_ok=True)

    config: Dict[str, Any] = {}
    if config_path.exists():
        try:
            loaded = yaml.safe_load(config_path.read_text()) or {}
            if isinstance(loaded, dict):
                config = loaded
        except Exception:
            config = {}

    current_model = config.get("model")
    if isinstance(current_model, dict):
        model_cfg = dict(current_model)
    elif isinstance(current_model, str) and current_model.strip():
        model_cfg = {"default": current_model.strip()}
    else:
        model_cfg = {}

    model_cfg["provider"] = provider_id
    model_cfg["base_url"] = inference_base_url.rstrip("/")
    config["model"] = model_cfg

    config_path.write_text(yaml.safe_dump(config, sort_keys=False))
    return config_path


def _reset_config_provider():
    """Reset config.yaml provider back to auto after logout."""
    config_path = get_config_path()
    if not config_path.exists():
        return config_path

    try:
        config = yaml.safe_load(config_path.read_text()) or {}
    except Exception:
        return config_path

    if not isinstance(config, dict):
        return config_path

    model = config.get("model")
    if isinstance(model, dict):
        model["provider"] = "auto"
        if "base_url" in model:
            model["base_url"] = OPENROUTER_BASE_URL
    config_path.write_text(yaml.safe_dump(config, sort_keys=False))
    return config_path


def _prompt_model_selection(model_ids: List[str], current_model: str = "") -> Optional[str]:
    """Interactive model selection. Puts current_model first with a marker. Returns chosen model ID or None."""
    # Reorder: current model first, then the rest (deduplicated)
    ordered = []
    if current_model and current_model in model_ids:
        ordered.append(current_model)
    for mid in model_ids:
        if mid not in ordered:
            ordered.append(mid)

    # Build display labels with marker on current
    def _label(mid):
        if mid == current_model:
            return f"{mid}  ← currently in use"
        return mid

    # Default cursor on the current model (index 0 if it was reordered to top)
    default_idx = 0

    # Try arrow-key menu first, fall back to number input
    try:
        from simple_term_menu import TerminalMenu
        choices = [f"  {_label(mid)}" for mid in ordered]
        choices.append("  Enter custom model name")
        choices.append("  Skip (keep current)")
        menu = TerminalMenu(
            choices,
            cursor_index=default_idx,
            menu_cursor="-> ",
            menu_cursor_style=("fg_green", "bold"),
            menu_highlight_style=("fg_green",),
            cycle_cursor=True,
            clear_screen=False,
            title="Select default model:",
        )
        idx = menu.show()
        if idx is None:
            return None
        print()
        if idx < len(ordered):
            return ordered[idx]
        elif idx == len(ordered):
            custom = input("Enter model name: ").strip()
            return custom if custom else None
        return None
    except (ImportError, NotImplementedError):
        pass

    # Fallback: numbered list
    print("Select default model:")
    for i, mid in enumerate(ordered, 1):
        print(f"  {i}. {_label(mid)}")
    n = len(ordered)
    print(f"  {n + 1}. Enter custom model name")
    print(f"  {n + 2}. Skip (keep current)")
    print()

    while True:
        try:
            choice = input(f"Choice [1-{n + 2}] (default: skip): ").strip()
            if not choice:
                return None
            idx = int(choice)
            if 1 <= idx <= n:
                return ordered[idx - 1]
            elif idx == n + 1:
                custom = input("Enter model name: ").strip()
                return custom if custom else None
            elif idx == n + 2:
                return None
            print(f"Please enter 1-{n + 2}")
        except ValueError:
            print("Please enter a number")
        except (KeyboardInterrupt, EOFError):
            return None


def _save_model_choice(model_id: str) -> None:
    """Save the selected model to config.yaml and .env."""
    from eaisports_cli.config import save_config, load_config, save_env_value

    config = load_config()
    # Handle both string and dict model formats
    if isinstance(config.get("model"), dict):
        config["model"]["default"] = model_id
    else:
        config["model"] = model_id
    save_config(config)
    save_env_value("LLM_MODEL", model_id)


def login_command(args) -> None:
    """Deprecated: use 'eaisports model' or 'eaisports setup' instead."""
    print("The 'eaisports login' command has been removed.")
    print("Use 'eaisports model' to select a provider and model,")
    print("or 'eaisports setup' for full interactive setup.")
    raise SystemExit(0)


def logout_command(args) -> None:
    """Clear auth state for a provider."""
    provider_id = getattr(args, "provider", None)

    if provider_id and provider_id not in PROVIDER_REGISTRY:
        print(f"Unknown provider: {provider_id}")
        raise SystemExit(1)

    active = get_active_provider()
    target = provider_id or active

    if not target:
        print("No provider is currently logged in.")
        return

    provider_name = PROVIDER_REGISTRY[target].name if target in PROVIDER_REGISTRY else target

    if clear_provider_auth(target):
        _reset_config_provider()
        print(f"Logged out of {provider_name}.")
        if os.getenv("OPENROUTER_API_KEY"):
            print("EAISports will use OpenRouter for inference.")
        else:
            print("Run `eaisports model` or configure an API key to use EAISports.")
    else:
        print(f"No auth state found for {provider_name}.")
