"""EAISports update commands.

Extracted from main.py — handles git-pull, pip, and zip-based updates.
"""

import logging
import os
import sys
from pathlib import Path

from eaisports_cli import __version__

logger = logging.getLogger(__name__)

# Re-derive PROJECT_ROOT the same way main.py does
PROJECT_ROOT = Path(__file__).parent.parent.resolve()


def _update_via_zip(args):
    """Update EAISports by downloading a ZIP archive.

    Used on Windows when git file I/O is broken (antivirus, NTFS filter
    drivers causing 'Invalid argument' errors on file creation).
    """
    import shutil
    import tempfile
    import zipfile
    from urllib.request import urlretrieve

    branch = "main"
    zip_url = f"https://github.com/NousResearch/eaisports/archive/refs/heads/{branch}.zip"

    print("\u2192 Downloading latest version...")
    try:
        tmp_dir = tempfile.mkdtemp(prefix="eaisports-update-")
        zip_path = os.path.join(tmp_dir, f"eaisports-{branch}.zip")
        urlretrieve(zip_url, zip_path)

        print("\u2192 Extracting...")
        with zipfile.ZipFile(zip_path, 'r') as zf:
            zf.extractall(tmp_dir)

        # GitHub ZIPs extract to eaisports-<branch>/
        extracted = os.path.join(tmp_dir, f"eaisports-{branch}")
        if not os.path.isdir(extracted):
            # Try to find it
            for d in os.listdir(tmp_dir):
                candidate = os.path.join(tmp_dir, d)
                if os.path.isdir(candidate) and d != "__MACOSX":
                    extracted = candidate
                    break

        # Copy updated files over existing installation, preserving venv/node_modules/.git
        preserve = {'venv', 'node_modules', '.git', '__pycache__', '.env'}
        update_count = 0
        for item in os.listdir(extracted):
            if item in preserve:
                continue
            src = os.path.join(extracted, item)
            dst = os.path.join(str(PROJECT_ROOT), item)
            if os.path.isdir(src):
                if os.path.exists(dst):
                    shutil.rmtree(dst)
                shutil.copytree(src, dst)
            else:
                shutil.copy2(src, dst)
            update_count += 1

        print(f"\u2713 Updated {update_count} items from ZIP")

        # Cleanup
        shutil.rmtree(tmp_dir, ignore_errors=True)

    except Exception as e:
        print(f"\u2717 ZIP update failed: {e}")
        sys.exit(1)

    # Reinstall Python dependencies
    print("\u2192 Updating Python dependencies...")
    import subprocess
    uv_bin = shutil.which("uv")
    if uv_bin:
        subprocess.run(
            [uv_bin, "pip", "install", "-e", ".", "--quiet"],
            cwd=PROJECT_ROOT, check=True,
            env={**os.environ, "VIRTUAL_ENV": str(PROJECT_ROOT / "venv")}
        )
    else:
        venv_pip = PROJECT_ROOT / "venv" / ("Scripts" if sys.platform == "win32" else "bin") / "pip"
        if venv_pip.exists():
            subprocess.run([str(venv_pip), "install", "-e", ".", "--quiet"], cwd=PROJECT_ROOT, check=True)

    # Sync skills
    try:
        from tools.skills_sync import sync_skills
        print("\u2192 Syncing bundled skills...")
        result = sync_skills(quiet=True)
        if result["copied"]:
            print(f"  + {len(result['copied'])} new: {', '.join(result['copied'])}")
        if result.get("updated"):
            print(f"  \u2191 {len(result['updated'])} updated: {', '.join(result['updated'])}")
        if result.get("user_modified"):
            print(f"  ~ {len(result['user_modified'])} user-modified (kept)")
        if result.get("cleaned"):
            print(f"  \u2212 {len(result['cleaned'])} removed from manifest")
        if not result["copied"] and not result.get("updated"):
            print("  \u2713 Skills are up to date")
    except Exception:
        pass

    print()
    print("\u2713 Update complete!")


def _update_via_pip():
    """Update EAISports via pip (for pip-installed users)."""
    import subprocess
    import shutil

    print("  Checking PyPI for updates...")

    # Find the pip that owns this installation
    pip_cmd = None

    # 1. Check if we're in a venv with pip
    venv_prefix = getattr(sys, "prefix", None)
    if venv_prefix:
        candidate = Path(venv_prefix) / ("Scripts" if sys.platform == "win32" else "bin") / "pip"
        if candidate.exists():
            pip_cmd = [str(candidate)]

    # 2. Fall back to sys.executable -m pip (always correct)
    if not pip_cmd:
        pip_cmd = [sys.executable, "-m", "pip"]

    # Check current vs latest version
    try:
        result = subprocess.run(
            pip_cmd + ["index", "versions", "eaisports"],
            capture_output=True, text=True, timeout=15,
        )
        if result.returncode == 0 and result.stdout.strip():
            import re
            m = re.search(r"eaisports \(([^)]+)\)", result.stdout)
            latest = m.group(1) if m else None
            if latest and latest == __version__:
                print(f"  Already on latest version ({__version__}).")
                return
            elif latest:
                print(f"  New version available: {latest} (current: {__version__})")
    except Exception:
        pass  # Proceed with upgrade anyway

    print("  Upgrading...")
    try:
        subprocess.run(
            pip_cmd + ["install", "--upgrade", "--no-cache-dir", "eaisports"],
            check=True,
        )
        print()
        print("  Update complete! Restart eaisports to use the new version.")
    except subprocess.CalledProcessError as e:
        print(f"  pip upgrade failed (exit {e.returncode}).")
        print(f"  Try manually: pip install --upgrade eaisports")
        sys.exit(1)


def cmd_update(args):
    """Update EAISports to the latest version."""
    import subprocess
    import shutil

    print("  Updating EAISports...")
    print()

    # Detect install method: git repo vs pip package
    use_zip_update = False
    git_dir = PROJECT_ROOT / '.git'

    if not git_dir.exists():
        # Not a git clone -- use pip to update
        _update_via_pip()
        return

    # On Windows, git can fail with "unable to write loose object file: Invalid argument"
    # due to filesystem atomicity issues. Set the recommended workaround.
    if sys.platform == "win32" and git_dir.exists():
        subprocess.run(
            ["git", "-c", "windows.appendAtomically=false", "config", "windows.appendAtomically", "false"],
            cwd=PROJECT_ROOT, check=False, capture_output=True
        )

    if use_zip_update:
        # ZIP-based update for Windows when git is broken
        _update_via_zip(args)
        return

    # Fetch and pull
    try:
        print("\u2192 Fetching updates...")
        git_cmd = ["git"]
        if sys.platform == "win32":
            git_cmd = ["git", "-c", "windows.appendAtomically=false"]

        subprocess.run(git_cmd + ["fetch", "origin"], cwd=PROJECT_ROOT, check=True)

        # Get current branch
        result = subprocess.run(
            git_cmd + ["rev-parse", "--abbrev-ref", "HEAD"],
            cwd=PROJECT_ROOT,
            capture_output=True,
            text=True,
            check=True
        )
        branch = result.stdout.strip()

        # Check if there are updates
        result = subprocess.run(
            git_cmd + ["rev-list", f"HEAD..origin/{branch}", "--count"],
            cwd=PROJECT_ROOT,
            capture_output=True,
            text=True,
            check=True
        )
        commit_count = int(result.stdout.strip())

        if commit_count == 0:
            # Even with no new commits, the installed package may be stale
            # (e.g., developer bumped version locally but didn't reinstall)
            try:
                import tomllib
                pyproject = PROJECT_ROOT / "pyproject.toml"
                if pyproject.exists():
                    with open(pyproject, "rb") as f:
                        toml_ver = tomllib.load(f)["project"]["version"]
                    if toml_ver != __version__:
                        print(f"  Installed version ({__version__}) differs from source ({toml_ver})")
                        print("\u2192 Reinstalling...")
                        uv_bin = shutil.which("uv")
                        if uv_bin:
                            subprocess.run(
                                [uv_bin, "pip", "install", "-e", ".", "--quiet"],
                                cwd=PROJECT_ROOT, check=True,
                                env={**os.environ, "VIRTUAL_ENV": str(PROJECT_ROOT / "venv")}
                            )
                        else:
                            subprocess.run(
                                [sys.executable, "-m", "pip", "install", "-e", ".", "--quiet"],
                                cwd=PROJECT_ROOT, check=True,
                            )
                        print(f"\u2713 Updated to {toml_ver}!")
                        return
            except Exception:
                pass
            print("\u2713 Already up to date!")
            return

        print(f"\u2192 Found {commit_count} new commit(s)")
        print("\u2192 Pulling updates...")
        subprocess.run(git_cmd + ["pull", "origin", branch], cwd=PROJECT_ROOT, check=True)

        # Reinstall Python dependencies (prefer uv for speed, fall back to pip)
        print("\u2192 Updating Python dependencies...")
        uv_bin = shutil.which("uv")
        if uv_bin:
            subprocess.run(
                [uv_bin, "pip", "install", "-e", ".", "--quiet"],
                cwd=PROJECT_ROOT, check=True,
                env={**os.environ, "VIRTUAL_ENV": str(PROJECT_ROOT / "venv")}
            )
        else:
            venv_pip = PROJECT_ROOT / "venv" / ("Scripts" if sys.platform == "win32" else "bin") / "pip"
            if venv_pip.exists():
                subprocess.run([str(venv_pip), "install", "-e", ".", "--quiet"], cwd=PROJECT_ROOT, check=True)
            else:
                subprocess.run(["pip", "install", "-e", ".", "--quiet"], cwd=PROJECT_ROOT, check=True)

        # Check for Node.js deps
        if (PROJECT_ROOT / "package.json").exists():
            if shutil.which("npm"):
                print("\u2192 Updating Node.js dependencies...")
                subprocess.run(["npm", "install", "--silent"], cwd=PROJECT_ROOT, check=False)

        print()
        print("\u2713 Code updated!")

        # Sync bundled skills (copies new, updates changed, respects user deletions)
        try:
            from tools.skills_sync import sync_skills
            print()
            print("\u2192 Syncing bundled skills...")
            result = sync_skills(quiet=True)
            if result["copied"]:
                print(f"  + {len(result['copied'])} new: {', '.join(result['copied'])}")
            if result.get("updated"):
                print(f"  \u2191 {len(result['updated'])} updated: {', '.join(result['updated'])}")
            if result.get("user_modified"):
                print(f"  ~ {len(result['user_modified'])} user-modified (kept)")
            if result.get("cleaned"):
                print(f"  \u2212 {len(result['cleaned'])} removed from manifest")
            if not result["copied"] and not result.get("updated"):
                print("  \u2713 Skills are up to date")
        except Exception as e:
            logger.debug("Skills sync during update failed: %s", e)

        # Check for config migrations
        print()
        print("\u2192 Checking configuration for new options...")

        from eaisports_cli.config import (
            get_missing_env_vars, get_missing_config_fields,
            check_config_version, migrate_config
        )

        missing_env = get_missing_env_vars(required_only=True)
        missing_config = get_missing_config_fields()
        current_ver, latest_ver = check_config_version()

        needs_migration = missing_env or missing_config or current_ver < latest_ver

        if needs_migration:
            print()
            if missing_env:
                print(f"  \u26a0\ufe0f  {len(missing_env)} new required setting(s) need configuration")
            if missing_config:
                print(f"  \u2139\ufe0f  {len(missing_config)} new config option(s) available")

            print()
            response = input("Would you like to configure them now? [Y/n]: ").strip().lower()

            if response in ('', 'y', 'yes'):
                print()
                results = migrate_config(interactive=True, quiet=False)

                if results["env_added"] or results["config_added"]:
                    print()
                    print("\u2713 Configuration updated!")
            else:
                print()
                print("Skipped. Run 'eaisports config migrate' later to configure.")
        else:
            print("  \u2713 Configuration is up to date")

        print()
        print("\u2713 Update complete!")

        print()
        print("Tip: You can now select a provider and model:")
        print("  eaisports model              # Select provider and model")

    except subprocess.CalledProcessError as e:
        if sys.platform == "win32":
            print(f"\u26a0 Git update failed: {e}")
            print("\u2192 Falling back to ZIP download...")
            print()
            _update_via_zip(args)
        else:
            print(f"\u2717 Update failed: {e}")
            sys.exit(1)
