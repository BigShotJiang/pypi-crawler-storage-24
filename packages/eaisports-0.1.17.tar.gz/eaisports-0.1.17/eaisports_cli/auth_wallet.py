"""
EAISports Wallet OAuth device code authentication.

Handles device code flow for Solana wallet-based authentication.
The user authenticates via browser (connects wallet, signs message),
and the CLI polls for completion.
"""

from __future__ import annotations

import logging
import os
import time
import webbrowser
from datetime import datetime, timezone
from typing import Any, Dict, Optional

import httpx

from eaisports_cli.auth_store import (
    AuthError,
    _auth_store_lock,
    _is_remote_session,
    _load_auth_store,
    _load_provider_state,
    _oauth_trace,
    _save_auth_store,
    _save_provider_state,
    _token_fingerprint,
    format_auth_error,
    get_provider_auth_state,
)

logger = logging.getLogger(__name__)

# =============================================================================
# Constants
# =============================================================================

DEFAULT_EAISPORTS_API_URL = "https://api.eaisports.ai"
_DEVICE_CODE_ENDPOINT = "/api/auth/device-code"
_DEVICE_CODE_POLL_ENDPOINT = "/api/auth/device-code/poll"
_POLL_INTERVAL = 5  # seconds
_POLL_TIMEOUT = 300  # 5 minutes


# =============================================================================
# Auth Store — wallet token persistence
# =============================================================================

def _read_wallet_tokens(*, _lock=True) -> dict | None:
    """Read wallet auth state from auth store."""
    if _lock:
        with _auth_store_lock():
            auth_store = _load_auth_store()
            return _load_provider_state(auth_store, "eaisports-wallet")
    auth_store = _load_auth_store()
    return _load_provider_state(auth_store, "eaisports-wallet")


def _save_wallet_tokens(tokens: dict, *, _lock=True) -> None:
    """Save wallet auth state to auth store."""
    if _lock:
        with _auth_store_lock():
            auth_store = _load_auth_store()
            _save_provider_state(auth_store, "eaisports-wallet", tokens)
            _save_auth_store(auth_store)
        return
    auth_store = _load_auth_store()
    _save_provider_state(auth_store, "eaisports-wallet", tokens)
    _save_auth_store(auth_store)


# =============================================================================
# Device Code Flow — request and poll
# =============================================================================

def _request_device_code(api_url: str) -> dict:
    """POST /api/auth/device-code -> { device_code, user_code, verification_url }"""
    timeout = httpx.Timeout(15.0)
    with httpx.Client(timeout=timeout, headers={"Accept": "application/json"}) as client:
        response = client.post(f"{api_url}{_DEVICE_CODE_ENDPOINT}")

    response.raise_for_status()
    data = response.json()

    required_fields = ["device_code", "user_code", "verification_url"]
    missing = [f for f in required_fields if f not in data]
    if missing:
        raise ValueError(f"Device code response missing fields: {', '.join(missing)}")
    return data


def _poll_for_token(api_url: str, device_code: str) -> dict:
    """Poll /api/auth/device-code/poll until user completes browser auth."""
    deadline = time.time() + _POLL_TIMEOUT
    timeout = httpx.Timeout(15.0)

    with httpx.Client(timeout=timeout, headers={"Accept": "application/json"}) as client:
        while time.time() < deadline:
            response = client.post(
                f"{api_url}{_DEVICE_CODE_POLL_ENDPOINT}",
                json={"device_code": device_code},
            )

            if response.status_code == 200:
                payload = response.json()
                if "token" not in payload:
                    raise ValueError("Poll response did not include token")
                return payload

            try:
                error_payload = response.json()
            except Exception:
                response.raise_for_status()
                raise RuntimeError("Poll endpoint returned a non-JSON error response")

            error_code = error_payload.get("error", "")
            if error_code == "authorization_pending":
                time.sleep(_POLL_INTERVAL)
                continue
            if error_code == "slow_down":
                time.sleep(_POLL_INTERVAL + 5)
                continue
            if error_code == "expired_token":
                raise TimeoutError("Device code expired before authorization was completed")

            description = error_payload.get("error_description") or "Unknown authentication error"
            raise RuntimeError(f"{error_code}: {description}")

    raise TimeoutError("Timed out waiting for wallet authorization")


# =============================================================================
# Login flow
# =============================================================================

def _login_wallet(args, pconfig) -> None:
    """Main login flow: request code -> display URL -> poll -> save tokens."""
    from eaisports_cli.auth import _update_config_for_provider
    from eaisports_cli.config import load_config

    config = load_config()
    api_url = (
        os.getenv("EAISPORTS_API_URL")
        or config.get("api_url")
        or DEFAULT_EAISPORTS_API_URL
    ).rstrip("/")

    open_browser = not getattr(args, "no_browser", False)
    if _is_remote_session():
        open_browser = False

    print(f"Starting EAISports wallet authentication...")
    print(f"API: {api_url}")

    try:
        device_data = _request_device_code(api_url)

        verification_url = str(device_data["verification_url"])
        user_code = str(device_data["user_code"])
        device_code = str(device_data["device_code"])

        print()
        print("To continue:")
        print(f"  1. Open: {verification_url}")
        print(f"  2. Enter code: {user_code}")
        print(f"  3. Connect your Solana wallet and sign the message")

        if open_browser:
            opened = webbrowser.open(verification_url)
            if opened:
                print("  (Opened browser for verification)")
            else:
                print("  Could not open browser automatically — use the URL above.")

        print(f"Waiting for wallet authorization (polling every {_POLL_INTERVAL}s, timeout {_POLL_TIMEOUT // 60}min)...")

        token_data = _poll_for_token(api_url, device_code)

        # Process response
        now = datetime.now(timezone.utc)
        jwt_token = token_data["token"]
        wallet_address = token_data.get("wallet_address", "")

        auth_state = {
            "api_url": api_url,
            "token": jwt_token,
            "wallet_address": wallet_address,
            "obtained_at": now.isoformat(),
        }

        # Save auth state
        with _auth_store_lock():
            auth_store = _load_auth_store()
            _save_provider_state(auth_store, "eaisports-wallet", auth_state)
            saved_to = _save_auth_store(auth_store)

        _oauth_trace(
            "wallet_login_success",
            wallet_address=wallet_address,
            token_fp=_token_fingerprint(jwt_token),
        )

        config_path = _update_config_for_provider("eaisports-wallet", api_url)
        print()
        print("Wallet authentication successful!")
        print(f"  Wallet: {wallet_address}")
        print(f"  Auth state: {saved_to}")
        print(f"  Config updated: {config_path}")

    except KeyboardInterrupt:
        print("\nLogin cancelled.")
        raise SystemExit(130)
    except Exception as exc:
        print(f"Wallet login failed: {exc}")
        raise SystemExit(1)


# =============================================================================
# Runtime credential resolution
# =============================================================================

def resolve_wallet_runtime_credentials() -> dict:
    """Return { provider, api_key (JWT token), wallet_address, base_url, source }."""
    with _auth_store_lock():
        auth_store = _load_auth_store()
        state = _load_provider_state(auth_store, "eaisports-wallet")

    if not state:
        raise AuthError(
            "EAISports is not authenticated with a wallet.",
            provider="eaisports-wallet",
            relogin_required=True,
        )

    token = state.get("token")
    if not isinstance(token, str) or not token:
        raise AuthError(
            "No wallet auth token found. Run `eaisports model` to re-authenticate.",
            provider="eaisports-wallet",
            relogin_required=True,
        )

    api_url = state.get("api_url") or DEFAULT_EAISPORTS_API_URL
    wallet_address = state.get("wallet_address", "")

    return {
        "provider": "eaisports-wallet",
        "api_key": token,
        "wallet_address": wallet_address,
        "base_url": api_url.rstrip("/"),
        "source": "auth_store",
    }


# =============================================================================
# Status
# =============================================================================

def get_wallet_auth_status() -> dict:
    """Return current auth status snapshot."""
    state = get_provider_auth_state("eaisports-wallet")
    if not state:
        return {
            "logged_in": False,
            "api_url": None,
            "wallet_address": None,
            "has_token": False,
        }
    return {
        "logged_in": bool(state.get("token")),
        "api_url": state.get("api_url"),
        "wallet_address": state.get("wallet_address"),
        "has_token": bool(state.get("token")),
    }
