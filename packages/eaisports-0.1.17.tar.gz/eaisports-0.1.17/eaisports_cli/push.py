"""
EAISports Push Command -- deploy a game to the EAISports platform.

Bundles the built game (dist/) into a tarball and uploads it to the
EAISports deploy API.

Usage (from CLI):
    eaisports push                  # pick a game interactively
    eaisports push my-trivia-game   # push a specific game by slug
"""

import contextlib
import hashlib
import io
import logging
import subprocess
import sys
import tarfile
import tempfile
import time
import uuid
from pathlib import Path

import requests

from eaisports_cli.colors import Colors, color
from eaisports_cli.config import load_config, get_eaisports_home
from eaisports_cli.auth_store import get_active_provider

logger = logging.getLogger(__name__)

DEFAULT_API_URL = "https://api.eaisports.ai"


def _resolve_auth_headers(wallet_address: str) -> dict[str, str]:
    """Build auth headers — prefer JWT Bearer token if wallet provider is active,
    otherwise fall back to legacy X-Wallet-Address header."""
    try:
        if get_active_provider() == "eaisports-wallet":
            from eaisports_cli.auth_wallet import resolve_wallet_runtime_credentials
            creds = resolve_wallet_runtime_credentials()
            token = creds.get("api_key", "")
            if token:
                return {"Authorization": f"Bearer {token}"}
    except Exception:
        logger.debug("Failed to resolve wallet JWT, falling back to X-Wallet-Address")
    # Legacy fallback
    return {"X-Wallet-Address": wallet_address}

# Must match server-side limit (Railway API rejects bundles above this).
MAX_BUNDLE_SIZE_BYTES = 5 * 1024 * 1024  # 5 MB

# Retry configuration (overridable via config.yaml deploy section)
_RETRYABLE_STATUS_CODES = {502, 503, 504}
_MAX_DEPLOY_RETRIES = 3
_BACKOFF_BASE_SECONDS = 2


def _load_deploy_config() -> dict:
    """Load deploy settings from config.yaml, falling back to module defaults."""
    try:
        cfg = load_config().get("deploy", {})
    except Exception:
        cfg = {}
    return {
        "max_retries": cfg.get("max_retries", _MAX_DEPLOY_RETRIES),
        "backoff_base": cfg.get("backoff_base", _BACKOFF_BASE_SECONDS),
        "max_bundle_size_bytes": cfg.get("max_bundle_size_mb", 5) * 1024 * 1024,
        "preflight_check": cfg.get("preflight_check", True),
    }

# Cross-platform file locking
try:
    import fcntl
except ImportError:
    fcntl = None
    try:
        import msvcrt
    except ImportError:
        msvcrt = None


# =========================================================================
# Bundle helpers
# =========================================================================

def _create_bundle(game_dir: Path) -> Path:
    """Create a tarball of the game's dist/ directory.

    Returns the path to the temporary .tar.gz file.  The caller is
    responsible for cleaning it up.
    """
    dist_dir = game_dir / "dist"
    if not dist_dir.exists() or not any(dist_dir.iterdir()):
        raise FileNotFoundError(f"No dist/ directory found in {game_dir}")

    tmp = tempfile.NamedTemporaryFile(
        suffix=".tar.gz", prefix="eaisports-bundle-", delete=False
    )
    tmp.close()
    bundle_path = Path(tmp.name)

    with tarfile.open(bundle_path, "w:gz") as tar:
        tar.add(dist_dir, arcname="dist")

    logger.debug("Bundle created: %s", bundle_path)
    return bundle_path


def _compute_bundle_hash(bundle_path: Path) -> str:
    """Compute SHA-256 hash of the bundle file for dedup."""
    sha256 = hashlib.sha256()
    with open(bundle_path, "rb") as f:
        while chunk := f.read(8192):
            sha256.update(chunk)
    return sha256.hexdigest()


def _verify_build(game_dir: Path) -> tuple[list[str], list[str]]:
    """Run lightweight pre-push checks against the built dist/ output."""
    errors: list[str] = []
    warnings: list[str] = []

    dist_dir = game_dir / "dist"
    if not dist_dir.exists():
        return (["dist/ directory is missing."], warnings)

    index_path = dist_dir / "index.html"
    if not index_path.exists():
        errors.append("dist/index.html is missing.")
        html = ""
    else:
        html = index_path.read_text(encoding="utf-8", errors="ignore")
        if len(html.strip()) <= 100:
            errors.append("dist/index.html looks too small; expected more than 100 characters.")
        if "<script" not in html.lower():
            errors.append("dist/index.html does not contain a <script tag.")

    js_files = sorted(
        path for path in dist_dir.rglob("*.js") if path.is_file()
    )
    if not js_files:
        errors.append("No JavaScript bundle found in dist/ or dist/assets/.")

    total_size = sum(path.stat().st_size for path in dist_dir.rglob("*") if path.is_file())
    if total_size <= 1024:
        errors.append("Build output is too small; total dist/ size must be greater than 1KB.")
    if total_size >= MAX_BUNDLE_SIZE_BYTES:
        size_mb = total_size / (1024 * 1024)
        limit_mb = MAX_BUNDLE_SIZE_BYTES / (1024 * 1024)
        errors.append(
            f"Build output is too large ({size_mb:.1f}MB). "
            f"Maximum is {limit_mb:.0f}MB."
        )

    for js_path in js_files[:5]:
        js_content = js_path.read_text(encoding="utf-8", errors="ignore")
        if "process.env" in js_content:
            errors.append(f"Unresolved process.env reference found in {js_path.relative_to(game_dir)}.")

    return errors, warnings


# =========================================================================
# Push lock (prevents concurrent pushes of the same game)
# =========================================================================

@contextlib.contextmanager
def _push_lock(game_dir: Path):
    """Acquire an exclusive lock for pushing this game.

    Prevents concurrent pushes of the same game from the same machine.
    Uses fcntl on Unix, msvcrt on Windows (same pattern as cron/scheduler.py).
    """
    lock_path = game_dir / ".push.lock"
    lock_fd = None
    try:
        lock_fd = open(lock_path, "w")
        if fcntl:
            fcntl.flock(lock_fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        elif msvcrt:
            msvcrt.locking(lock_fd.fileno(), msvcrt.LK_NBLCK, 1)
        yield
    except (OSError, IOError):
        if lock_fd is not None:
            lock_fd.close()
        print(color("  Another push for this game is already in progress.", Colors.RED))
        sys.exit(1)
    finally:
        if lock_fd is not None:
            try:
                if fcntl:
                    fcntl.flock(lock_fd, fcntl.LOCK_UN)
                elif msvcrt:
                    try:
                        msvcrt.locking(lock_fd.fileno(), msvcrt.LK_UNLCK, 1)
                    except (OSError, IOError):
                        pass
            finally:
                lock_fd.close()


# =========================================================================
# Pre-flight slug check
# =========================================================================

def _preflight_check(api_url: str, slug: str, wallet_address: str) -> tuple[bool, str]:
    """Check slug availability before uploading.

    Returns (should_proceed, message).
    Gracefully degrades if the backend endpoint doesn't exist yet.
    """
    try:
        resp = requests.get(
            f"{api_url}/api/games/check-slug",
            params={"slug": slug, "wallet": wallet_address},
            headers=_resolve_auth_headers(wallet_address),
            timeout=10,
        )
        if resp.status_code == 404:
            return True, ""  # Endpoint not deployed yet
        if resp.status_code == 200:
            data = resp.json()
            if data.get("available") is False and data.get("owner") != wallet_address:
                return False, f"Slug '{slug}' is already taken by another creator."
            if data.get("exists") and data.get("owner") == wallet_address:
                return True, f"Updating existing game '{slug}'."
            return True, ""
        return True, ""  # Unknown status, proceed anyway
    except requests.RequestException:
        return True, ""  # Network issue, skip preflight


# =========================================================================
# Upload progress wrapper
# =========================================================================

class _ProgressFileWrapper(io.RawIOBase):
    """Wrap a file to report read progress to a callback."""

    def __init__(self, file_obj, total_bytes: int, callback):
        self._file = file_obj
        self._total = total_bytes
        self._callback = callback
        self._bytes_read = 0

    def read(self, size=-1):
        data = self._file.read(size)
        if data:
            self._bytes_read += len(data)
            self._callback(self._bytes_read, self._total)
        return data

    def readinto(self, b):
        data = self._file.read(len(b))
        n = len(data)
        b[:n] = data
        if n:
            self._bytes_read += len(data)
            self._callback(self._bytes_read, self._total)
        return n

    def readable(self):
        return True


# =========================================================================
# Deploy request with retry + progress
# =========================================================================

def _deploy_request(
    deploy_url: str,
    bundle_path: Path,
    slug: str,
    wallet_address: str,
    idempotency_key: str,
    bundle_hash: str,
    show_progress: bool = True,
    auth_headers: dict[str, str] | None = None,
) -> requests.Response:
    """POST bundle to deploy API with retry on transient failures.

    Retries on ConnectionError, Timeout, and 502/503/504.
    Does NOT retry on 4xx client errors (deterministic failures).
    """
    last_exc = None
    resp = None

    for attempt in range(1, _MAX_DEPLOY_RETRIES + 1):
        try:
            with open(bundle_path, "rb") as bundle_file:
                total_bytes = bundle_path.stat().st_size

                if show_progress and sys.stdout.isatty() and total_bytes > 50_000:
                    try:
                        from rich.progress import Progress, BarColumn, DownloadColumn, TransferSpeedColumn
                        with Progress(
                            "[progress.description]{task.description}",
                            BarColumn(),
                            DownloadColumn(),
                            TransferSpeedColumn(),
                            transient=True,
                        ) as progress:
                            task = progress.add_task("  Uploading...", total=total_bytes)

                            def _update(bytes_read, total):
                                progress.update(task, completed=bytes_read)

                            wrapped = _ProgressFileWrapper(bundle_file, total_bytes, _update)
                            resp = requests.post(
                                deploy_url,
                                headers={
                                    **(auth_headers or _resolve_auth_headers(wallet_address)),
                                    "X-Idempotency-Key": idempotency_key,
                                    "X-Bundle-Hash": bundle_hash,
                                },
                                files={"bundle": ("bundle.tar.gz", wrapped, "application/gzip")},
                                data={"slug": slug, "wallet_address": wallet_address},
                                timeout=120,
                            )
                    except ImportError:
                        # rich not available, fall through to plain upload
                        resp = requests.post(
                            deploy_url,
                            headers={
                                "X-Wallet-Address": wallet_address,
                                "X-Idempotency-Key": idempotency_key,
                                "X-Bundle-Hash": bundle_hash,
                            },
                            files={"bundle": ("bundle.tar.gz", bundle_file, "application/gzip")},
                            data={"slug": slug, "wallet_address": wallet_address},
                            timeout=120,
                        )
                else:
                    resp = requests.post(
                        deploy_url,
                        headers={
                            "X-Wallet-Address": wallet_address,
                            "X-Idempotency-Key": idempotency_key,
                            "X-Bundle-Hash": bundle_hash,
                        },
                        files={"bundle": ("bundle.tar.gz", bundle_file, "application/gzip")},
                        data={"slug": slug, "wallet_address": wallet_address},
                        timeout=120,
                    )

            # Handle 429 rate limiting
            if resp.status_code == 429:
                retry_after = int(resp.headers.get("Retry-After", _BACKOFF_BASE_SECONDS ** attempt))
                print(color(f"  Rate limited. Retrying in {retry_after}s...", Colors.YELLOW))
                time.sleep(retry_after)
                continue

            # Success or non-retryable error
            if resp.status_code not in _RETRYABLE_STATUS_CODES:
                return resp

            if attempt < _MAX_DEPLOY_RETRIES:
                delay = _BACKOFF_BASE_SECONDS ** attempt
                print(color(f"  Server error ({resp.status_code}). Retrying in {delay}s... [{attempt}/{_MAX_DEPLOY_RETRIES}]", Colors.YELLOW))
                time.sleep(delay)

        except (requests.ConnectionError, requests.Timeout) as exc:
            last_exc = exc
            if attempt < _MAX_DEPLOY_RETRIES:
                delay = _BACKOFF_BASE_SECONDS ** attempt
                print(color(f"  {type(exc).__name__}. Retrying in {delay}s... [{attempt}/{_MAX_DEPLOY_RETRIES}]", Colors.YELLOW))
                time.sleep(delay)

    # Exhausted retries
    if last_exc:
        raise last_exc
    return resp


# =========================================================================
# Push command
# =========================================================================

def run_push(slug: str = None, api_url: str = None, skip_verify: bool = False) -> None:
    """Bundle and deploy a game to the EAISports platform.

    Parameters
    ----------
    slug:
        Game slug (directory name under ``~/.eaisports/games/``).
        If *None*, the most-recently-modified game is used.
    api_url:
        Base URL for the EAISports API.  Defaults to ``DEFAULT_API_URL``.
    skip_verify:
        Skip pre-push build verification checks when set to *True*.
    """
    api_url = api_url or DEFAULT_API_URL
    config = load_config()
    deploy_cfg = _load_deploy_config()
    home = get_eaisports_home()

    # -- Resolve wallet
    wallet_address = config.get("wallet_address")
    if not wallet_address:
        print(color("  Configure your wallet first: `eaisports init`", Colors.RED))
        sys.exit(1)

    # -- Resolve game directory
    games_root = home / "games"
    if slug:
        game_dir = games_root / slug
    else:
        # Pick the most-recently-modified game directory
        if not games_root.exists():
            print(color("  No games found. Run `eaisports build` first.", Colors.RED))
            sys.exit(1)
        candidates = sorted(
            [d for d in games_root.iterdir() if d.is_dir()],
            key=lambda d: d.stat().st_mtime,
            reverse=True,
        )
        if not candidates:
            print(color("  No games found. Run `eaisports build` first.", Colors.RED))
            sys.exit(1)
        game_dir = candidates[0]
        slug = game_dir.name

    if not game_dir.exists():
        print(color(f"  Game not found: {game_dir}", Colors.RED))
        sys.exit(1)

    # Resolve auth headers once for all API calls in this push
    auth_headers = _resolve_auth_headers(wallet_address)

    print(color(f"  Deploying game: {slug}", Colors.CYAN))
    print(color(f"  Game directory: {game_dir}", Colors.DIM))

    # -- Pre-flight slug check
    if not deploy_cfg["preflight_check"]:
        proceed, msg = True, ""
    else:
        proceed, msg = _preflight_check(api_url, slug, wallet_address)
    if not proceed:
        print(color(f"  {msg}", Colors.RED))
        sys.exit(1)
    if msg:
        print(color(f"  {msg}", Colors.DIM))

    # -- Acquire push lock and execute build+deploy
    with _push_lock(game_dir):
        # -- Build the game
        print(color("  Running build...", Colors.DIM))
        try:
            subprocess.run(
                ["npm", "run", "build"],
                cwd=game_dir,
                check=True,
                capture_output=True,
                text=True,
            )
        except subprocess.CalledProcessError as exc:
            print(color("  Build failed. Run `eaisports preview` to debug.", Colors.RED))
            if exc.stderr:
                print(color(f"  {exc.stderr.strip()}", Colors.DIM))
            sys.exit(1)

        dist_dir = game_dir / "dist"
        if not dist_dir.exists() or not any(dist_dir.iterdir()):
            print(color("  Build failed. Run `eaisports preview` to debug.", Colors.RED))
            sys.exit(1)

        print(color("  Build complete.", Colors.GREEN))

        if not skip_verify:
            errors, warnings = _verify_build(game_dir)
            for w in warnings:
                print(color(f"  Warning: {w}", Colors.YELLOW))
            for e in errors:
                print(color(f"  Error: {e}", Colors.RED))
            if errors:
                print(color("  Pre-push verification failed.", Colors.RED))
                sys.exit(1)
            print(color("  Verification passed.", Colors.GREEN))

        # -- Create bundle
        print(color("  Creating bundle...", Colors.DIM))
        try:
            bundle_path = _create_bundle(game_dir)
        except FileNotFoundError:
            print(color("  Build failed. Run `eaisports preview` to debug.", Colors.RED))
            sys.exit(1)

        # -- Compute bundle hash and idempotency key
        bundle_hash = _compute_bundle_hash(bundle_path)
        idempotency_key = str(uuid.uuid4())

        # -- Upload to deploy API
        deploy_url = f"{api_url}/api/games/deploy"

        try:
            resp = _deploy_request(
                deploy_url=deploy_url,
                bundle_path=bundle_path,
                slug=slug,
                wallet_address=wallet_address,
                idempotency_key=idempotency_key,
                bundle_hash=bundle_hash,
                auth_headers=auth_headers,
            )

            if resp.status_code == 200:
                data = resp.json()
                live_url = data.get("url", f"https://eaisports.ai/games/{slug}")
                tokens = data.get("tokens_earned", 0)

                # Check for dedup response
                if data.get("status") == "already_deployed":
                    print()
                    print(color("  No changes detected — game is already up to date.", Colors.GREEN))
                    print(color(f"  Live URL: {live_url}", Colors.CYAN))
                    print()
                    return

                print()
                print(color("  Game deployed!", Colors.GREEN, Colors.BOLD))
                print(color(f"  Live URL: {live_url}", Colors.CYAN))
                print(color(f"  Share: Check out my game on EAISports! {live_url}", Colors.DIM))
                if tokens:
                    print(color(f"  Points earned: +{tokens} pts", Colors.YELLOW))

                # -- Generate desktop icon (best-effort, server-side)
                print(color("  Generating game icon...", Colors.DIM))
                try:
                    icon_resp = requests.post(
                        f"{api_url}/api/games/{slug}/generate-icon",
                        headers=auth_headers,
                        timeout=60,
                    )
                    if icon_resp.ok:
                        print(color("  Game icon generated!", Colors.GREEN))
                    else:
                        print(color("  Icon generation skipped.", Colors.DIM))
                except Exception:
                    print(color("  Icon generation skipped.", Colors.DIM))

                print()
            else:
                error_msg = ""
                try:
                    error_msg = resp.json().get("error", resp.text)
                except Exception:
                    error_msg = resp.text
                print(color(f"  Deploy failed ({resp.status_code}): {error_msg}", Colors.RED))
                sys.exit(1)

        except requests.ConnectionError:
            print(color("  Could not reach the EAISports API. Check your connection.", Colors.RED))
            sys.exit(1)
        except requests.Timeout:
            print(color("  Request timed out after retries. Try again later.", Colors.RED))
            sys.exit(1)
        except requests.RequestException as exc:
            print(color(f"  Network error: {exc}", Colors.RED))
            sys.exit(1)
        finally:
            # -- Clean up the tarball
            try:
                bundle_path.unlink(missing_ok=True)
                logger.debug("Cleaned up bundle: %s", bundle_path)
            except OSError:
                pass
