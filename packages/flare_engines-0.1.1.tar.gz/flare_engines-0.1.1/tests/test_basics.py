from __future__ import annotations

import flare_engines

from flare_engines import (
    build_context_envelope,
    build_mode_execution_artifact,
    get_mode_definition,
    resolve_context_budget,
    resolve_mode_key,
)


def test_package_smoke_imports_public_api() -> None:
    assert hasattr(flare_engines, "resolve_context_budget")
    assert hasattr(flare_engines, "build_mode_execution_artifact")


def test_resolve_context_budget_honors_explicit_env_overrides() -> None:
    budget = resolve_context_budget(
        profile="light",
        env={
            "CONTEXT_TOTAL_TOKEN_BUDGET": "9000",
            "CONTEXT_HISTORY_TOKEN_BUDGET": "300",
            "CONTEXT_KNOWLEDGE_TOKEN_BUDGET": "400",
            "CONTEXT_MEMORY_TOKEN_BUDGET": "500",
        },
    )

    assert budget.profile == "light"
    assert budget.total_token_budget == 9000
    assert budget.history_token_budget == 300
    assert budget.knowledge_token_budget == 400
    assert budget.memory_token_budget == 500


def test_build_context_envelope_coerces_mapping_inputs() -> None:
    envelope = build_context_envelope(
        request_id="req-1",
        session_id="session-1",
        function_type="requirement_canvas",
        scenario="smoke",
        agent="agent-1",
        layers=[
            {
                "layer_type": "knowledge",
                "source": "payload",
                "content": "hello",
                "priority": "1",
                "token_estimate": "7",
                "included": 1,
                "inclusion_reason": "needed",
            }
        ],
        token_budget={
            "profile": "heavy",
            "total_token_budget": "42",
            "history_token_budget": "11",
            "knowledge_token_budget": "12",
            "memory_token_budget": "13",
        },
        metadata={"source": "smoke"},
    )

    assert envelope.request_id == "req-1"
    assert envelope.layers[0].layer_type == "knowledge"
    assert envelope.layers[0].token_estimate == 7
    assert envelope.layers[0].included is True
    assert envelope.token_budget.profile == "heavy"
    assert envelope.token_budget.total_token_budget == 42
    assert envelope.metadata == {"source": "smoke"}


def test_build_mode_execution_artifact_returns_expected_events() -> None:
    assert resolve_mode_key(intent="需求梳理") == "requirement_canvas"

    artifact = build_mode_execution_artifact(
        trace_id="trace-1",
        session_id="session-1",
        mode_key="requirement_canvas",
        payload={"message": "Need supplier shortlist", "project_id": "PRJ-1"},
    )

    definition = get_mode_definition("requirement_canvas")

    assert artifact["mode_key"] == "requirement_canvas"
    assert artifact["mode_state_sequence"] == list(definition.state_sequence)
    assert [event["event_type"] for event in artifact["events"]] == list(definition.events)
    assert artifact["summary"]
