from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(slots=True)
class ModeDefinition:
    mode_key: str
    state_sequence: tuple[str, ...]
    events: tuple[str, ...]
    metadata: dict[str, Any] = field(default_factory=dict)


_MODE_DEFINITIONS: dict[str, ModeDefinition] = {
    "requirement_canvas": ModeDefinition(
        mode_key="requirement_canvas",
        state_sequence=("collecting", "drafting", "awaiting_confirm", "ready"),
        events=("field_progress", "requirement_draft", "next_actions"),
    ),
    "intelligent_sourcing": ModeDefinition(
        mode_key="intelligent_sourcing",
        state_sequence=("collecting", "matching", "screening", "shortlisted", "report_ready"),
        events=("sourcing_candidates", "risk_summary", "shortlist_updated", "evaluation_report_ready"),
    ),
}

_MODE_ALIASES: dict[str, set[str]] = {
    "requirement_canvas": {
        "requirement_canvas",
        "requirement",
        "requirements",
        "req",
        "canvas",
        "需求",
        "需求梳理",
        "采购需求",
        "信息补全",
    },
    "intelligent_sourcing": {
        "intelligent_sourcing",
        "sourcing",
        "source",
        "sources",
        "supplier",
        "supplier_search",
        "寻源",
        "智能寻源",
        "供应商",
        "选型",
    },
}


def _normalize_mode_text(value: str | None) -> str:
    return str(value or "").strip().lower().replace("-", "_").replace(" ", "_")


def resolve_mode_key(intent: str | None = None, function_type: str | None = None) -> str:
    candidates = (_normalize_mode_text(function_type), _normalize_mode_text(intent))
    for candidate in candidates:
        if candidate in _MODE_DEFINITIONS:
            return candidate
        for mode_key, aliases in _MODE_ALIASES.items():
            if candidate in aliases:
                return mode_key
    raise ValueError(f"Unable to resolve mode key from intent={intent!r}, function_type={function_type!r}")


def get_mode_definition(mode_key: str) -> ModeDefinition:
    normalized_mode_key = str(mode_key).strip().lower()
    if normalized_mode_key not in _MODE_DEFINITIONS:
        raise ValueError(f"Unsupported mode definition: {mode_key!r}")
    return _MODE_DEFINITIONS[normalized_mode_key]
