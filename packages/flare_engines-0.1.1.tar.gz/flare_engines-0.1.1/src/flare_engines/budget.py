from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Final, Literal, Mapping, cast

ContextProfile = Literal["light", "medium", "heavy"]

_ALLOWED_CONTEXT_PROFILES: Final[set[str]] = {"light", "medium", "heavy"}
_DEFAULT_TOTAL_TOKEN_BUDGET = 12000
_DEFAULT_HISTORY_TOKEN_BUDGET = 3000
_DEFAULT_KNOWLEDGE_TOKEN_BUDGET = 3000
_DEFAULT_MEMORY_TOKEN_BUDGET = 2000


@dataclass(slots=True)
class ContextBudget:
    profile: ContextProfile
    total_token_budget: int
    history_token_budget: int
    knowledge_token_budget: int
    memory_token_budget: int


def _normalize_profile(profile: str) -> ContextProfile:
    normalized = str(profile).strip().lower()
    if normalized not in _ALLOWED_CONTEXT_PROFILES:
        raise ValueError(f"Unsupported context profile: {profile!r}")
    return cast(ContextProfile, normalized)


def _read_budget_value(name: str, default: int, environment: Mapping[str, str]) -> int:
    raw = environment.get(name)
    if raw is None or not str(raw).strip():
        return default
    try:
        return max(0, int(str(raw).strip()))
    except ValueError:
        return default


def resolve_context_budget(
    profile: ContextProfile | str = "medium",
    env: Mapping[str, str] | None = None,
) -> ContextBudget:
    environment = os.environ if env is None else env
    normalized_profile = _normalize_profile(profile)
    return ContextBudget(
        profile=normalized_profile,
        total_token_budget=_read_budget_value(
            "CONTEXT_TOTAL_TOKEN_BUDGET", _DEFAULT_TOTAL_TOKEN_BUDGET, environment
        ),
        history_token_budget=_read_budget_value(
            "CONTEXT_HISTORY_TOKEN_BUDGET", _DEFAULT_HISTORY_TOKEN_BUDGET, environment
        ),
        knowledge_token_budget=_read_budget_value(
            "CONTEXT_KNOWLEDGE_TOKEN_BUDGET", _DEFAULT_KNOWLEDGE_TOKEN_BUDGET, environment
        ),
        memory_token_budget=_read_budget_value(
            "CONTEXT_MEMORY_TOKEN_BUDGET", _DEFAULT_MEMORY_TOKEN_BUDGET, environment
        ),
    )
