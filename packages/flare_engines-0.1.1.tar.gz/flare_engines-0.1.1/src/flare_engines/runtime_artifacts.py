from __future__ import annotations

from typing import Any, TypedDict

from flare_engines.mode_runtime import ModeDefinition, get_mode_definition


class ModeExecutionEvent(TypedDict):
    event_type: str
    mode_key: str
    state: str
    step_index: int
    label: str
    detail: str


class ModeExecutionArtifact(TypedDict):
    trace_id: str
    session_id: str
    mode_key: str
    mode_state_sequence: list[str]
    events: list[ModeExecutionEvent]
    summary: str
    payload: dict[str, Any]


def _build_mode_execution_events(definition: ModeDefinition) -> list[ModeExecutionEvent]:
    events: list[ModeExecutionEvent] = []
    state_sequence = definition.state_sequence

    for step_index, event_type in enumerate(definition.events):
        state_index = min(step_index, len(state_sequence) - 1)
        state = state_sequence[state_index]
        events.append(
            {
                "event_type": event_type,
                "mode_key": definition.mode_key,
                "state": state,
                "step_index": step_index,
                "label": f"{definition.mode_key}:{event_type}",
                "detail": f"{definition.mode_key} enters {state}",
            }
        )

    return events


def build_mode_execution_artifact(
    *,
    trace_id: str,
    session_id: str,
    mode_key: str,
    payload: dict[str, Any] | None = None,
) -> ModeExecutionArtifact:
    definition = get_mode_definition(mode_key)
    events = _build_mode_execution_events(definition)
    return {
        "trace_id": trace_id,
        "session_id": session_id,
        "mode_key": definition.mode_key,
        "mode_state_sequence": list(definition.state_sequence),
        "events": events,
        "summary": f"{definition.mode_key} execution artifact with {len(events)} events",
        "payload": dict(payload or {}),
    }
