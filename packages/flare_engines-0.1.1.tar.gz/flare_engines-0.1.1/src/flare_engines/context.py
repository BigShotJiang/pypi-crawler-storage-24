from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Mapping, Sequence

from flare_engines.budget import ContextBudget, resolve_context_budget


@dataclass(slots=True)
class ContextLayer:
    layer_type: str
    source: str
    content: str
    priority: int
    token_estimate: int
    included: bool
    inclusion_reason: str


@dataclass(slots=True)
class ContextEnvelope:
    request_id: str
    session_id: str
    function_type: str
    scenario: str
    agent: str
    layers: list[ContextLayer] = field(default_factory=list)
    token_budget: ContextBudget = field(default_factory=resolve_context_budget)
    metadata: dict[str, Any] = field(default_factory=dict)


def _coerce_layer(layer: ContextLayer | Mapping[str, Any]) -> ContextLayer:
    if isinstance(layer, ContextLayer):
        return layer
    return ContextLayer(
        layer_type=str(layer["layer_type"]),
        source=str(layer["source"]),
        content=str(layer["content"]),
        priority=int(layer["priority"]),
        token_estimate=int(layer["token_estimate"]),
        included=bool(layer["included"]),
        inclusion_reason=str(layer["inclusion_reason"]),
    )


def _coerce_budget(token_budget: ContextBudget | Mapping[str, Any] | None) -> ContextBudget:
    if token_budget is None:
        return resolve_context_budget()
    if isinstance(token_budget, ContextBudget):
        return token_budget
    validated_profile = resolve_context_budget(profile=str(token_budget.get("profile", "medium"))).profile
    return ContextBudget(
        profile=validated_profile,
        total_token_budget=int(token_budget["total_token_budget"]),
        history_token_budget=int(token_budget["history_token_budget"]),
        knowledge_token_budget=int(token_budget["knowledge_token_budget"]),
        memory_token_budget=int(token_budget["memory_token_budget"]),
    )


def build_context_envelope(
    *,
    request_id: str,
    session_id: str,
    function_type: str,
    scenario: str,
    agent: str,
    layers: Sequence[ContextLayer | Mapping[str, Any]] | None = None,
    token_budget: ContextBudget | Mapping[str, Any] | None = None,
    metadata: Mapping[str, Any] | None = None,
) -> ContextEnvelope:
    return ContextEnvelope(
        request_id=request_id,
        session_id=session_id,
        function_type=function_type,
        scenario=scenario,
        agent=agent,
        layers=[_coerce_layer(layer) for layer in layers or []],
        token_budget=_coerce_budget(token_budget),
        metadata=dict(metadata or {}),
    )
