# flare-engines

七层引擎实现集合包。

当前范围：

1. Ingestion
2. Context
3. Memory
4. Observation
5. Presentation
6. Decision
7. Execution
