"""SecAgent result parsers / normalizers."""
