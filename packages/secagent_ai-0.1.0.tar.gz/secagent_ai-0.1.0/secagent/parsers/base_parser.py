"""Abstract base parser for normalizing scanner output."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from secagent.models import Vulnerability


class BaseParser(ABC):
    """Every scanner-specific parser inherits from this class."""

    @abstractmethod
    def parse(self, raw_findings: list[dict[str, Any]]) -> list[Vulnerability]:
        """Convert raw scanner output into unified ``Vulnerability`` objects.

        Parameters
        ----------
        raw_findings:
            List of raw findings as returned by the scanner's ``run()`` method.

        Returns
        -------
        list[Vulnerability]
            Normalized findings.
        """
