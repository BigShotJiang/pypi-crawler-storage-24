"""Built-in secret scanner result parser."""

from __future__ import annotations

from typing import Any

from secagent.models import Severity, Vulnerability
from secagent.parsers.base_parser import BaseParser


class BuiltinParser(BaseParser):
    """Convert built-in scanner findings into ``Vulnerability`` objects."""

    def parse(self, raw_findings: list[dict[str, Any]]) -> list[Vulnerability]:
        results: list[Vulnerability] = []

        for finding in raw_findings:
            vuln = Vulnerability(
                scanner="builtin-secrets",
                file=finding.get("File", "unknown"),
                line=finding.get("StartLine", 0),
                severity=Severity.HIGH,
                vuln_type="secret",
                description=(
                    finding.get("Description", "Secret detected")
                    + f" ({finding.get('RuleID', '')})"
                ),
                raw=finding,
            )
            results.append(vuln)

        return results
