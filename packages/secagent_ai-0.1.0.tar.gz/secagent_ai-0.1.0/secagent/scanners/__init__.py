"""SecAgent scanner integrations."""
