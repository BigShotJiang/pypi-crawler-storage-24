"""Allow running SecAgent as ``python -m secagent``."""

from secagent.cli import main

main()
