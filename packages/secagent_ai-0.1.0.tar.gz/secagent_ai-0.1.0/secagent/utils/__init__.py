"""SecAgent utility helpers."""
