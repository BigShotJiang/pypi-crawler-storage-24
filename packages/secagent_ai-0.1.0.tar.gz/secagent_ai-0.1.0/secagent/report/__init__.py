"""SecAgent report generation."""
