"""SecAgent LLM integration layer."""
