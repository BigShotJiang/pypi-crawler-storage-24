"""SecAgent context management utilities."""
