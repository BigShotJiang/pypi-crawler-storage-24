# SecAgent 🛡️

**Autonomous Security Agent** — scan, verify, fix vulnerabilities, and generate reports.

SecAgent is a Python CLI tool that runs an 8-stage security pipeline:

1. **Planner Agent** — decides which scanners to run  
2. **Scanner Executor** — runs Gitleaks / Trivy via subprocess  
3. **Result Parser** — normalises findings into a unified format  
4. **Verifier Agent** — classifies True Positive vs False Positive (via Grok)  
5. **Fixer Agent** — generates a secure patch (via Grok)  
6. **Patch Applier** — safely edits the file with backup  
7. **Validator Agent** — confirms fix correctness (via Grok)  
8. **Report Builder** — generates `fix.md`

---

## Quick Start

```bash
# Install
pip install -e .

# Set your Grok API key
export GROK_API_KEY="xai-..."

# Scan a file
secagent scan ./main.py

# Scan a directory
secagent scan ./project/
```

## Prerequisites

| Tool | Purpose | Install |
|------|---------|---------|
| Python 3.11+ | Runtime | [python.org](https://python.org) |
| Gitleaks | Secret scanning | `brew install gitleaks` / [GitHub releases](https://github.com/gitleaks/gitleaks) |
| Trivy | Vulnerability scanning | `brew install trivy` / [GitHub releases](https://github.com/aquasecurity/trivy) |
| Grok API key | LLM reasoning | [x.ai](https://x.ai) |

> SecAgent degrades gracefully — scanners that aren't installed are skipped, and agents fall back to reasonable defaults when no API key is set.

## Configuration

| Env Variable | Default | Description |
|---|---|---|
| `GROK_API_KEY` | — | xAI API key for agent reasoning |
| `GROK_MODEL` | `grok-4-1-fast-reasoning` | Model to use for chat completions |

## Architecture

```
secagent/
├── cli.py                  # Typer CLI entry point
├── pipeline.py             # 8-stage orchestrator
├── models.py               # Shared dataclasses
├── llm/
│   └── grok_client.py      # Grok API wrapper
├── agents/
│   ├── planner_agent.py    # Scanner selection
│   ├── verifier_agent.py   # TP / FP classification
│   ├── fixer_agent.py      # Patch generation
│   └── validator_agent.py  # Fix validation
├── scanners/
│   ├── base_scanner.py     # Abstract plugin interface
│   ├── gitleaks_scanner.py # Secret scanning
│   └── trivy_scanner.py    # Filesystem vuln scanning
├── parsers/
│   ├── base_parser.py      # Abstract parser
│   ├── gitleaks_parser.py  # Gitleaks → Vulnerability
│   └── trivy_parser.py     # Trivy → Vulnerability
├── context/
│   ├── context_builder.py  # Code-window extraction
│   └── dependency_resolver.py  # Import analysis
├── utils/
│   ├── file_loader.py      # File I/O helpers
│   └── patch_applier.py    # Safe file patching
└── report/
    └── fix_report.py       # Markdown report generator
```

### Adding a new scanner

1. Create `secagent/scanners/my_scanner.py` inheriting from `BaseScanner`
2. Create `secagent/parsers/my_parser.py` inheriting from `BaseParser`
3. Register in `pipeline.py` → `_SCANNER_MAP`

## License

MIT
