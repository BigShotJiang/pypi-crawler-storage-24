"""Reusable runner package for BitShop's fAIk Dev worker."""

from __future__ import annotations

from functools import lru_cache
from importlib import metadata
from pathlib import Path


def _iter_version_candidates(module_file: str | Path) -> list[Path]:
    module_path = Path(module_file).resolve()
    search_roots = [module_path.parent, *module_path.parents]
    return [root / "VERSION" for root in search_roots]


@lru_cache(maxsize=1)
def _read_repo_version() -> str | None:
    for candidate in _iter_version_candidates(__file__):
        if candidate.is_file():
            return candidate.read_text(encoding="utf-8").strip()
    return None


repo_version = _read_repo_version()
__version__ = repo_version or metadata.version("faikdev-runner")
