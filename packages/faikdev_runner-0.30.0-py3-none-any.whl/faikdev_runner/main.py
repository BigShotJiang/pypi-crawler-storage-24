#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
import random
import re
import shutil
import subprocess
import sys
import tempfile
import threading
import time
from pathlib import Path
from typing import Callable
from urllib.parse import quote, urljoin

import requests
from jinja2 import Environment, FileSystemLoader
from websockets.sync.client import connect as websocket_connect

PROMPT_TEMPLATE_DIR = Path(__file__).resolve().parent / "templates"
PROMPT_TEMPLATE_NAME = "task_prompt.txt.j2"
PROMPT_OUTPUT_PATH = Path("/tmp/my-prompt.txt")
DEFAULT_TIMEOUT_SECONDS = 3600
HEARTBEAT_PING_INTERVAL_SECONDS = 60
HEARTBEAT_RECONNECT_MIN_SECONDS = 1.0
HEARTBEAT_RECONNECT_MAX_SECONDS = 30.0
MAIN_BRANCH = "main"
EMPTY_QUEUE_INITIAL_POLL_SECONDS = 15
EMPTY_QUEUE_MAX_POLL_SECONDS = 90


class NoPendingTasksError(RuntimeError):
    """Raised when the backend reports there is no task to run yet."""


def fetch_task(worker_name: str, project_id: str, api_url: str, resume_task_id: int | None) -> dict:
    if resume_task_id:
        response = requests.get(f"{api_url}/api/tasks/{resume_task_id}")
        if response.status_code != 200:
            raise RuntimeError(f"Error fetching task {resume_task_id}: {response.status_code}")
        return response.json()

    response = requests.get(
        f"{api_url}/api/tasks/next/{project_id}",
        params={"worker_name": worker_name},
    )
    if response.status_code == 404:
        raise NoPendingTasksError(f"No pending tasks for project: {project_id}")
    if response.status_code != 200:
        raise RuntimeError(f"Error fetching next task: {response.status_code}")

    return response.json()


def compute_empty_queue_poll_delay(attempt: int) -> int:
    """Return the capped exponential delay for polling an empty queue."""
    return min(
        EMPTY_QUEUE_MAX_POLL_SECONDS,
        EMPTY_QUEUE_INITIAL_POLL_SECONDS * (2**attempt),
    )


def poll_for_task(worker_name: str, project_id: str, api_url: str, resume_task_id: int | None) -> dict:
    """Fetch the next task, retrying with backoff while the queue is empty."""
    empty_queue_attempt = 0

    while True:
        try:
            return fetch_task(worker_name, project_id, api_url, resume_task_id)
        except NoPendingTasksError as exc:
            if resume_task_id:
                raise RuntimeError(str(exc)) from exc

            delay_seconds = compute_empty_queue_poll_delay(empty_queue_attempt)
            empty_queue_attempt += 1
            print(f"{exc}. Sleeping {delay_seconds}s before polling again.", flush=True)
            time.sleep(delay_seconds)


def ensure_cli_selection(task: dict, api_url: str) -> dict:
    """Ensure task has CLI selection by resolving from backend if needed."""
    task_id = task.get("id") or task.get("task_id")
    if not task_id:
        return task

    # CLI selection is now handled by the backend when fetching the task
    # This function is kept for backward compatibility but does nothing
    return task


def render_prompt(task: dict) -> str:
    env = Environment(loader=FileSystemLoader(str(PROMPT_TEMPLATE_DIR)), autoescape=False)
    template = env.get_template(PROMPT_TEMPLATE_NAME)

    return template.render(
        title=task.get("title", "") or "",
        description=task.get("description", "") or "",
        task=task,
    )


def write_prompt_file(prompt_text: str) -> Path:
    PROMPT_OUTPUT_PATH.write_text(prompt_text, encoding="utf-8")
    return PROMPT_OUTPUT_PATH


def resolve_timeout_seconds() -> int:
    raw_timeout = os.getenv("TIMEOUT_SECONDS")
    if not raw_timeout:
        return DEFAULT_TIMEOUT_SECONDS

    try:
        parsed = int(raw_timeout)
    except ValueError:
        return DEFAULT_TIMEOUT_SECONDS

    return parsed if parsed > 0 else DEFAULT_TIMEOUT_SECONDS


def build_worker_heartbeat_ws_url(api_url: str, project_id: str, worker_name: str) -> str:
    """Convert the API base URL into the worker heartbeat websocket URL."""
    normalized = api_url.rstrip("/")
    if normalized.startswith("https://"):
        ws_base = "wss://" + normalized[len("https://"):]
    elif normalized.startswith("http://"):
        ws_base = "ws://" + normalized[len("http://"):]
    elif normalized.startswith("wss://") or normalized.startswith("ws://"):
        ws_base = normalized
    else:
        ws_base = "ws://" + normalized
    return f"{ws_base}/api/workers/ws/heartbeat/{project_id}/{quote(worker_name, safe='')}"


def compute_reconnect_delay(
    attempt: int,
    min_delay_seconds: float = HEARTBEAT_RECONNECT_MIN_SECONDS,
    max_delay_seconds: float = HEARTBEAT_RECONNECT_MAX_SECONDS,
) -> float:
    """Return decorrelated exponential backoff with jitter."""
    base_delay = min(max_delay_seconds, min_delay_seconds * (2**attempt))
    return random.uniform(base_delay * 0.5, base_delay)


class WorkerHeartbeatManager:
    """Maintains worker websocket heartbeat with auto-reconnect."""

    def __init__(
        self,
        api_url: str,
        project_id: str,
        worker_name: str,
        ping_interval_seconds: int = HEARTBEAT_PING_INTERVAL_SECONDS,
    ):
        self.api_url = api_url
        self.project_id = project_id
        self.worker_name = worker_name
        self.ping_interval_seconds = ping_interval_seconds
        self.ws_url = build_worker_heartbeat_ws_url(api_url, project_id, worker_name)
        self._stop_event = threading.Event()
        self._thread: threading.Thread | None = None
        self._status = "active"
        self._status_lock = threading.Lock()

    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._stop_event.clear()
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop_event.set()
        if self._thread:
            self._thread.join(timeout=5)

    def set_status(self, status: str) -> None:
        with self._status_lock:
            self._status = status

    def _current_status(self) -> str:
        with self._status_lock:
            return self._status

    def _wait_or_stop(self, seconds: float) -> bool:
        return self._stop_event.wait(timeout=max(0.0, seconds))

    def _run(self) -> None:
        reconnect_attempt = 0
        while not self._stop_event.is_set():
            try:
                with websocket_connect(
                    self.ws_url,
                    open_timeout=10,
                    close_timeout=5,
                    ping_interval=20,
                    ping_timeout=20,
                ) as websocket:
                    reconnect_attempt = 0
                    while not self._stop_event.is_set():
                        websocket.send(
                            json.dumps(
                                {
                                    "type": "ping",
                                    "project_id": self.project_id,
                                    "worker_name": self.worker_name,
                                    "status": self._current_status(),
                                }
                            )
                        )
                        if self._wait_or_stop(self.ping_interval_seconds):
                            break
            except Exception as exc:
                delay = compute_reconnect_delay(reconnect_attempt)
                reconnect_attempt += 1
                print(
                    f"Worker heartbeat websocket disconnected ({exc}); reconnecting in {delay:.1f}s",
                    file=sys.stderr,
                    flush=True,
                )
                if self._wait_or_stop(delay):
                    break

def build_prompt_with_images(prompt_text: str, image_paths: list[Path] | None = None) -> str:
    """Prefix Kiro prompts with attached image paths when present."""
    if not image_paths:
        return prompt_text
    image_prefix = "\n".join(str(path) for path in image_paths)
    return f"{image_prefix}\n\n{prompt_text}"


def build_cli_command(
    prompt_path: Path,
    timeout_seconds: int,
    cli_name: str,
    model: str | None = None,
    profile: str | None = None,
    image_paths: list[Path] | None = None,
) -> tuple[list[str], str | None]:
    """Build the CLI command and return any inline prompt argument."""
    if cli_name == "codex":
        cmd = [
            "timeout",
            str(timeout_seconds),
            "codex",
            "--search",
            "exec",
        ]
        if profile:
            cmd.extend(["--profile", profile])
        if model and model not in {"default", "auto"}:
            cmd.extend(["--model", model])
        for image_path in image_paths or []:
            cmd.extend(["-i", str(image_path)])
        cmd.extend([
            "--dangerously-bypass-approvals-and-sandbox",
            "-",
        ])
        return cmd, None

    full_prompt = build_prompt_with_images(
        prompt_path.read_text(encoding="utf-8"),
        image_paths=image_paths,
    )
    cmd = [
        "timeout",
        str(timeout_seconds),
        "kiro-cli",
        "chat",
        "-a",
        "--no-interactive",
        full_prompt
    ]
    return cmd, full_prompt


def run_cli(
    prompt_path: Path,
    timeout_seconds: int,
    cli_name: str,
    model: str | None = None,
    profile: str | None = None,
    image_paths: list[Path] | None = None,
) -> int:
    """Run CLI without capturing output (for backward compatibility)."""
    normalized_cli_name = "codex" if cli_name in {"codex", "codex-cli"} else cli_name
    cmd, _ = build_cli_command(
        prompt_path,
        timeout_seconds,
        normalized_cli_name,
        model=model,
        profile=profile,
        image_paths=image_paths,
    )
    print(f"Running: {' '.join(cmd)}", flush=True)
    if normalized_cli_name == "codex":
        with prompt_path.open("r", encoding="utf-8") as prompt_file:
            result = subprocess.run(cmd, check=False, stdin=prompt_file)
    else:
        result = subprocess.run(cmd, check=False, stdin=None)
    return result.returncode


def _extract_tag_content(output: str, tag: str) -> str | None:
    """Extract marker content for a tag.

    Order:
    1) the last start/end marker pair, allowing optional surrounding dashes
    2) the last start marker through end-of-file if no end marker is present
    """
    lines = output.splitlines(keepends=True)
    start_pattern = re.compile(
        rf"^\s*-*<\s*{re.escape(tag)}\s*>\s*-*\s*(?P<rest>.*)$",
        re.IGNORECASE,
    )
    end_pattern = re.compile(
        rf"^\s*-*</\s*{re.escape(tag)}\s*>\s*-*\s*$",
        re.IGNORECASE,
    )
    start_matches: list[tuple[int, str]] = []

    for idx, line in enumerate(lines):
        match = start_pattern.match(line)
        if match:
            start_matches.append((idx, match.group("rest")))

    for start_idx, rest in reversed(start_matches):
        for end_idx in range(start_idx + 1, len(lines)):
            if end_pattern.match(lines[end_idx]):
                content_lines: list[str] = []
                if rest:
                    content_lines.append(rest.rstrip("\r\n"))
                content_lines.extend(line.rstrip("\r\n") for line in lines[start_idx + 1 : end_idx])
                return strip_ansi_codes("\n".join(content_lines).strip())

    if start_matches:
        start_idx, rest = start_matches[-1]
        content_lines = []
        if rest:
            content_lines.append(rest.rstrip("\r\n"))
        content_lines.extend(line.rstrip("\r\n") for line in lines[start_idx + 1 :])
        return strip_ansi_codes("\n".join(content_lines).strip())

    return None


def extract_success_content(output: str) -> str:
    """Extract success content, with a fallback marker format."""
    extracted = _extract_tag_content(output, "Success")
    if extracted is not None:
        return extracted
    return "End Success marker not found in output."


def extract_failure_content(output: str) -> str:
    """Extract failure content, with a fallback marker format."""
    extracted = _extract_tag_content(output, "Failure")
    if extracted is not None:
        return extracted
    return "End Failure marker not found in output."


def strip_ansi_codes(text: str) -> str:
    """Remove ANSI escape sequences from text."""
    # Pattern matches ANSI escape sequences including:
    # - CSI sequences: ESC [ ... (letter or @)
    # - OSC sequences: ESC ] ... (terminated by BEL or ST)
    # - Simple sequences: ESC (letter)
    # Also matches the [K pattern and other bracket sequences
    ansi_pattern = re.compile(r'\x1b\[[0-9;]*[a-zA-Z@]|\x1b\][^\x07]*\x07|\x1b[a-zA-Z]|\[K|\[[0-9;]*m')
    return ansi_pattern.sub('', text)


class OutputCapture:
    """Capture stdout/stderr separately and in combined arrival order."""

    def __init__(
        self,
        on_data: Callable[[str, str, "OutputCapture"], None] | None = None,
    ) -> None:
        self.stdout = ""
        self.stderr = ""
        self.combined = ""
        self._on_data = on_data
        self._lock = threading.Lock()

    def write_stdout(self, text: str) -> None:
        self._write("stdout", text)

    def write_stderr(self, text: str) -> None:
        self._write("stderr", text)

    def _write(self, stream_name: str, text: str) -> None:
        cleaned_text = strip_ansi_codes(text)
        if not cleaned_text:
            return

        with self._lock:
            if stream_name == "stdout":
                self.stdout += cleaned_text
            else:
                self.stderr += cleaned_text
            self.combined += cleaned_text

        print(cleaned_text, end="", flush=True)

        if self._on_data is not None:
            self._on_data(stream_name, cleaned_text, self)


def resolve_cli_outcome(returncode: int, full_output: str, cli_name: str) -> tuple[int, str]:
    """Resolve task outcome from process status and structured output markers."""
    failure_content = extract_failure_content(full_output)
    has_failure_marker = failure_content != "End Failure marker not found in output."
    success_content = extract_success_content(full_output)
    has_success_marker = success_content != "End Success marker not found in output."
    effective_returncode = returncode

    # Codex can sometimes emit a valid success block while still returning 1.
    # This appears to be a known behavior where codex returns exit code 1 even when
    # the task completes successfully and emits a success marker.
    if cli_name in {"codex", "codex-cli"} and returncode == 1 and has_success_marker and not has_failure_marker:
        print("INFO: Codex returned exit code 1 but has success marker, treating as success", flush=True)
        effective_returncode = 0

    # A Failure marker in output means task failure, even if the CLI exited 0.
    if effective_returncode == 0 and has_failure_marker:
        effective_returncode = 1

    if effective_returncode == 0:
        return effective_returncode, success_content

    if has_failure_marker:
        captured_content = failure_content
    elif has_success_marker:
        captured_content = success_content
    else:
        captured_content = strip_ansi_codes(full_output).strip()

    if captured_content:
        captured_content = f"Task failed with exit code {effective_returncode}\n\n{captured_content}"
    else:
        captured_content = f"Task failed with exit code {effective_returncode}"

    return effective_returncode, captured_content


def run_cli_with_capture(
    prompt_path: Path,
    timeout_seconds: int,
    cli_name: str,
    model: str | None = None,
    profile: str | None = None,
    on_stream_data: Callable[[str, str, OutputCapture], None] | None = None,
    image_paths: list[Path] | None = None,
) -> tuple[int, str, str]:
    """Run CLI and capture output while displaying in real-time."""
    output_capture = OutputCapture(on_data=on_stream_data)

    def read_stream(stream, writer):
        """Read from stream and write each chunk to the capture buffer."""
        for chunk in stream:
            writer(chunk)
    
    normalized_cli_name = "codex" if cli_name in {"codex", "codex-cli"} else cli_name
    cmd, _ = build_cli_command(
        prompt_path,
        timeout_seconds,
        normalized_cli_name,
        model=model,
        profile=profile,
        image_paths=image_paths,
    )
    if normalized_cli_name == "codex":
        print(f"Running: {' '.join(cmd)}", flush=True)
        with prompt_path.open("r", encoding="utf-8") as prompt_file:
            process = subprocess.Popen(
                cmd,
                stdin=prompt_file,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
            stdout_thread = threading.Thread(target=read_stream, args=(process.stdout, output_capture.write_stdout))
            stderr_thread = threading.Thread(target=read_stream, args=(process.stderr, output_capture.write_stderr))
            stdout_thread.start()
            stderr_thread.start()
            stdout_thread.join()
            stderr_thread.join()
            returncode = process.wait()
    else:  # kiro-cli
        print(f"Running: {' '.join(cmd)}", flush=True)
        process = subprocess.Popen(
            cmd,
            stdin=None,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True
        )
        stdout_thread = threading.Thread(target=read_stream, args=(process.stdout, output_capture.write_stdout))
        stderr_thread = threading.Thread(target=read_stream, args=(process.stderr, output_capture.write_stderr))
        stdout_thread.start()
        stderr_thread.start()
        stdout_thread.join()
        stderr_thread.join()
        returncode = process.wait()
    
    full_output = output_capture.combined
    resolved_returncode, captured_output = resolve_cli_outcome(returncode, full_output, cli_name)
    return resolved_returncode, captured_output, full_output.strip()


def post_output_to_tasklog(task_id: int, output: str, api_url: str, log_type: str = "output") -> None:
    """Post captured output to TaskLog."""
    try:
        response = requests.post(
            f"{api_url}/api/tasks/{task_id}/logs",
            json={
                "message": output,
                "log_type": log_type,
                "metadata": {
                    "markdown": output,
                },
            }
        )
        if response.status_code == 200:
            print(f"Posted output to TaskLog for task {task_id}", flush=True)
        else:
            print(f"Failed to post output to TaskLog: {response.status_code}", file=sys.stderr)
    except Exception as exc:
        print(f"Error posting output to TaskLog: {exc}", file=sys.stderr)


def post_full_output_to_tasklog(task_id: int, output: str, api_url: str) -> None:
    """Post full combined stdout/stderr output as a lazy-loaded task log entry."""
    if not output:
        return

    try:
        response = requests.post(
            f"{api_url}/api/tasks/{task_id}/logs",
            json={
                "message": output,
                "log_type": "full_output",
                "metadata": {
                    "lazy": True,
                    "collapsed": True,
                    "stream": "combined",
                    "summary": "Full combined stdout/stderr",
                },
            },
        )
        if response.status_code == 200:
            print(f"Posted full output to TaskLog for task {task_id}", flush=True)
        else:
            print(f"Failed to post full output to TaskLog: {response.status_code}", file=sys.stderr)
    except Exception as exc:
        print(f"Error posting full output to TaskLog: {exc}", file=sys.stderr)


def stage_task_images(task: dict, api_url: str) -> tuple[list[Path], Path | None]:
    """Download attached task images to a temporary directory for CLI consumption."""
    images = task.get("images")
    if not isinstance(images, list) or not images:
        return [], None

    temp_dir = Path(tempfile.mkdtemp(prefix="faikdev-task-images-"))
    staged_paths: list[Path] = []

    try:
        for index, image in enumerate(images):
            if not isinstance(image, dict):
                continue
            content_url = image.get("content_url")
            if not isinstance(content_url, str) or not content_url:
                continue
            filename = image.get("original_filename") or f"task-image-{index}"
            safe_name = Path(str(filename)).name or f"task-image-{index}"
            destination = temp_dir / safe_name
            if destination.exists():
                destination = temp_dir / f"{destination.stem}-{index}{destination.suffix}"
            response = requests.get(urljoin(f"{api_url.rstrip('/')}/", content_url.lstrip("/")))
            if response.status_code != 200:
                raise RuntimeError(
                    f"Error downloading task image from {content_url}: {response.status_code}"
                )
            destination.write_bytes(response.content)
            staged_paths.append(destination)
        return staged_paths, temp_dir
    except Exception:
        shutil.rmtree(temp_dir, ignore_errors=True)
        raise


def cleanup_task_images(temp_dir: Path | None) -> None:
    """Remove staged task images after the runner finishes."""
    if temp_dir is not None:
        shutil.rmtree(temp_dir, ignore_errors=True)


def revert_local_git_changes() -> None:
    """Revert local uncommitted git changes to keep the workspace clean for the next run."""
    commands = [
        ["git", "reset", "--hard", "HEAD"],
        ["git", "clean", "-fd"],
    ]
    for cmd in commands:
        subprocess.run(cmd, check=False)


def run_git_command(args: list[str]) -> subprocess.CompletedProcess[str]:
    """Run a git command and capture stdout/stderr."""
    return subprocess.run(
        ["git", *args],
        check=False,
        capture_output=True,
        text=True,
    )


def get_current_git_branch() -> str:
    """Return the current git branch name, defaulting to an empty string on failure."""
    result = run_git_command(["rev-parse", "--abbrev-ref", "HEAD"])
    if result.returncode != 0:
        return ""
    return result.stdout.strip()


def get_pending_commit_count(main_branch: str = MAIN_BRANCH) -> int:
    """Return the number of local commits that are ahead of main."""
    result = run_git_command(["rev-list", "--count", f"{main_branch}..HEAD"])
    if result.returncode != 0:
        return 0
    try:
        return int(result.stdout.strip() or "0")
    except ValueError:
        return 0


def has_uncommitted_git_changes() -> bool:
    """Return True when the working tree has tracked or untracked changes."""
    result = run_git_command(["status", "--porcelain"])
    if result.returncode != 0:
        return False
    return bool(result.stdout.strip())


def restore_workspace_to_main(main_branch: str = MAIN_BRANCH) -> None:
    """Force the workspace back to a clean main branch state."""
    commands = [
        ["git", "checkout", "-f", main_branch],
        ["git", "reset", "--hard", main_branch],
        ["git", "clean", "-fd"],
    ]
    for cmd in commands:
        subprocess.run(cmd, check=False)


def lookup_worker(api_url: str, project_id: str, worker_name: str) -> dict | None:
    """Find the current worker record by external worker name."""
    response = requests.get(
        f"{api_url}/api/workers/",
        params={"project_id": project_id, "limit": 100},
    )
    if response.status_code != 200:
        return None

    for worker in response.json():
        if worker.get("worker_id") == worker_name:
            return worker
    return None


def set_worker_status(api_url: str, project_id: str, worker_name: str, status: str) -> None:
    """Update worker status using the existing worker API."""
    worker = lookup_worker(api_url, project_id, worker_name)
    if not worker or not worker.get("id"):
        return

    payload = dict(worker)
    payload["project_id"] = worker.get("project_id") or project_id
    payload["worker_id"] = worker_name
    payload["status"] = status
    requests.put(f"{api_url}/api/workers/{worker['id']}", json=payload)


def ensure_workspace_ready_for_next_task(
    api_url: str,
    project_id: str,
    worker_name: str,
    main_branch: str = MAIN_BRANCH,
) -> tuple[bool, str | None]:
    """Ensure the repo matches main before polling for more work."""
    pending_commits = get_pending_commit_count(main_branch)
    if pending_commits > 0:
        set_worker_status(api_url, project_id, worker_name, "needs_attention")
        return (
            False,
            f"Workspace has {pending_commits} pending commit(s) ahead of {main_branch}; worker marked needs_attention.",
        )

    current_branch = get_current_git_branch()
    if current_branch != main_branch or has_uncommitted_git_changes():
        restore_workspace_to_main(main_branch)

    return True, None


def push_current_branch() -> subprocess.CompletedProcess[str]:
    """Push the current branch to origin."""
    return run_git_command(["push", "--set-upstream", "origin", "HEAD"])


def render_push_retry_prompt(task: dict, push_error: str) -> str:
    """Render a follow-up prompt that focuses only on fixing a rejected push."""
    base_prompt = render_prompt(task)
    return (
        f"{base_prompt}\n\n"
        "The implementation is complete, but `git push --set-upstream origin HEAD` failed.\n"
        "pull latest, work out any merge conflicts, and push the changes.\n"
        f"Git push output:\n{push_error.strip() or 'git push failed without additional output'}\n"
    )


def ensure_changes_pushed(
    task: dict,
    timeout_seconds: int,
    cli_name: str,
    model: str | None = None,
    profile: str | None = None,
    image_paths: list[Path] | None = None,
    main_branch: str = MAIN_BRANCH,
) -> tuple[int, str, str]:
    """Push successful task changes, retrying via the assigned CLI if push is rejected."""
    if get_pending_commit_count(main_branch) <= 0:
        return 0, "", ""

    push_result = push_current_branch()
    if push_result.returncode == 0:
        return 0, "", ""

    push_output = "\n".join(
        part for part in [push_result.stdout.strip(), push_result.stderr.strip()] if part
    ).strip()
    retry_prompt = render_push_retry_prompt(task, push_output)
    retry_prompt_path = write_prompt_file(retry_prompt)
    retry_result, retry_captured_output, retry_full_output = run_cli_with_capture(
        retry_prompt_path,
        timeout_seconds,
        cli_name,
        model=model,
        profile=profile,
        image_paths=image_paths,
    )
    if retry_result != 0:
        return retry_result, retry_captured_output, retry_full_output

    push_result = push_current_branch()
    if push_result.returncode == 0:
        return 0, retry_captured_output, retry_full_output

    final_push_output = "\n".join(
        part for part in [push_result.stdout.strip(), push_result.stderr.strip()] if part
    ).strip()
    message = (
        "git push still failed after conflict-resolution retry.\n\n"
        f"{final_push_output or 'git push failed without additional output'}"
    )
    return 1, message, message


def report_completion(task_id: int, exit_code: int, duration: float, api_url: str) -> None:
    """Report task completion to the API."""
    from datetime import datetime, timezone
    
    payload = {
        "exit_code": exit_code,
        "completed_at": datetime.now(timezone.utc).isoformat(),
        "duration": duration,
    }
    
    try:
        response = requests.post(f"{api_url}/api/tasks/{task_id}/complete", json=payload)
        if response.status_code == 200:
            status = "completed" if exit_code == 0 else "failed"
            print(f"Reported {status} to API", flush=True)
        else:
            print(f"Failed to report completion: {response.status_code}", file=sys.stderr)
    except Exception as exc:
        print(f"Error reporting completion: {exc}", file=sys.stderr)


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Fetch task, build prompt, and run codex")
    parser.add_argument("--worker-name", required=True, help="Worker identifier")
    parser.add_argument("--project-id", required=True, help="Project ID")
    parser.add_argument("--resume-task-id", type=int, help="Resume specific task ID")
    parser.add_argument("--api-url", default="http://localhost:8000", help="Backend API URL")
    parser.add_argument(
        "--fetch-only",
        action="store_true",
        help="Fetch and print task JSON without rendering prompt or running codex",
    )
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    heartbeat_manager = WorkerHeartbeatManager(
        args.api_url,
        args.project_id,
        args.worker_name,
        ping_interval_seconds=HEARTBEAT_PING_INTERVAL_SECONDS,
    )
    heartbeat_manager.start()

    try:
        workspace_ready, workspace_error = ensure_workspace_ready_for_next_task(
            args.api_url,
            args.project_id,
            args.worker_name,
        )
        if not workspace_ready:
            print(workspace_error or "Workspace is not ready for the next task.", file=sys.stderr)
            return 1

        try:
            task = poll_for_task(
                args.worker_name,
                args.project_id,
                args.api_url,
                args.resume_task_id,
            )
            task = ensure_cli_selection(task, args.api_url)
        except RuntimeError as exc:
            print(str(exc), file=sys.stderr)
            return 1

        task_id = task.get("id") or task.get("task_id")
        print(json.dumps(task, indent=2), flush=True)
        if args.fetch_only:
            return 0

        prompt_text = render_prompt(task)
        prompt_path = write_prompt_file(prompt_text)
        image_paths, temp_image_dir = stage_task_images(task, args.api_url)

        print(f"Rendered prompt written to {prompt_path}", flush=True)
        print(prompt_text, flush=True)

        # Extract CLI name, model, and profile from task
        # Support both old field names (cli_name, model, profile) and new field names (selected_cli, selected_model, selected_profile)
        cli_name = task.get("selected_cli") or task.get("cli_name", "kiro-cli")
        model = task.get("selected_model") or task.get("model")
        profile = task.get("selected_profile") or task.get("profile")

        # TODO: Move timeout into backend API task/job configuration instead of env/default fallback.
        timeout_seconds = resolve_timeout_seconds()
        start_time = time.time()
        set_heartbeat_status = getattr(heartbeat_manager, "set_status", None)
        if callable(set_heartbeat_status):
            set_heartbeat_status("busy")
        try:
            result, captured_output, full_output = run_cli_with_capture(
                prompt_path,
                timeout_seconds,
                cli_name,
                model=model,
                profile=profile,
                image_paths=image_paths,
            )
            duration = time.time() - start_time

            if result == 0:
                push_result, push_captured_output, push_full_output = ensure_changes_pushed(
                    task,
                    timeout_seconds,
                    cli_name,
                    model=model,
                    profile=profile,
                    image_paths=image_paths,
                )
                if push_full_output:
                    full_output = "\n\n".join(part for part in [full_output, push_full_output] if part)
                if push_captured_output:
                    captured_output = "\n\n".join(
                        part for part in [captured_output, push_captured_output] if part
                    )
                result = push_result
        finally:
            cleanup_task_images(temp_image_dir)

        if task_id and full_output:
            post_full_output_to_tasklog(task_id, full_output, args.api_url)

        if result == 0:
            if captured_output and task_id:
                post_output_to_tasklog(task_id, captured_output, args.api_url)
        else:
            if captured_output and task_id:
                post_output_to_tasklog(task_id, captured_output, args.api_url, log_type="error")
            revert_local_git_changes()

        if task_id:
            report_completion(task_id, result, duration, args.api_url)

        if result == 0:
            print("Codex execution completed successfully", flush=True)
        else:
            print(f"Codex execution failed with return code: {result}", flush=True)
        
        return result
    finally:
        heartbeat_manager.stop()


def console_main() -> int:
    return main()


if __name__ == "__main__":
    sys.exit(console_main())
