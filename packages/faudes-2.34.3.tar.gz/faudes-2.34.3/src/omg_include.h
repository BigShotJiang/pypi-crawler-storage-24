/** @file omg_include.h Include omegaaut plug-in headers */

/*
 **************************************************** 
 Convenience header file that includes all headers 
 relevant to the omegaaut plug-in. The build system will
 append an include directive  for this file to
 the "allplugins.h" include file.

 (c) Thomas Moor 2025
 ****************************************************
 */

#ifndef FAUDES_OMG_INCLUDE_H
#define FAUDES_OMG_INCLUDE_H

#include "omg_rabinacc.h"
#include "omg_rabinaut.h"
#include "omg_hoa.h"
#include "omg_buechifnct.h"
#include "omg_buechictrl.h"
#include "omg_rabinfnct.h"
#include "omg_rabinctrl.h"
#include "omg_rabinctrlrk.h"
#include "omg_pseudodet.h"
#include "omg_rabinctrlpartialobs.h"

#endif


/**
 
@defgroup OmgPlugin Omega Automata  Plug-In

@ingroup AllPlugins

<p>
The omega-automata plug-in collects data structures and functions to support
supervisory control of non-termination processes.
</p>


@subsection OmgLicense License

<p>
The omega-automata plugin is distributed with libFAUDES and under the terms of
the LGPL.
</p>
<p>
Copyright (c) 2025 Thomas Moor.
</p>


*/
