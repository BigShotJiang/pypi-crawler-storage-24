/* Auto-generated file to include all enabled plugins */

/* 
The build system appends include directives to the template 
./src/allplugins.h. To check the effective configuration, 
visit ./include/allplugins.h 
*/

#include "syn_include.h"
#include "omg_include.h"
#include "pev_include.h"
#include "op_include.h"
#include "diag_include.h"
