/* Auto-generated file to set compiletime configuration */

/* 
The build system appends macro definitions to the template 
./src/configuration.h. To check the effective configuration, 
visit ./include/configuration.h 
*/

/* faudes core configuration */
#define  FAUDES_VERSION "libFAUDES 2.34d"
#define  FAUDES_CONFIG_TIMESTAMP "2026-03-09T11-30-38"
#define  FAUDES_PLUGINS "synthesis-omegaaut-priorities-observer-diagnosis-pybindings"
#define  FAUDES_PLUGINS_RTILOAD {}
#define  FAUDES_SYSTIME
#define  FAUDES_NETWORK
#define  FAUDES_THREADS
#define  FAUDES_CHECKED
#define  FAUDES_DEBUG_EXCEPTIONS
#define  FAUDES_COMPATIBILITY
 
/* synthesis configuration */
#define  FAUDES_PLUGIN_SYNTHESIS
 
/* omegaaut plugin configuration */
#define  FAUDES_PLUGIN_OMEGAAUT
 
/* priorities plugin configuration */
#define  FAUDES_PLUGIN_PRIORITIES
 
/* observer configuration */
#define  FAUDES_PLUGIN_OBSERVER
 
/* pybindings configuration */
#define  FAUDES_PLUGIN_PYBINDINGS
/* diagnosis configuration */
 
#define  FAUDES_PLUGIN_DIAGNOSIS
 
