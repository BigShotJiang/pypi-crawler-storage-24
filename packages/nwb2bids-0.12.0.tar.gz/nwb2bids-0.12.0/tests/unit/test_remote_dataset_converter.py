"""Unit tests for the `DatasetConverter` class and its methods."""

import pathlib

import numpy
import pydantic
import pytest

import nwb2bids


@pytest.mark.remote
def test_remote_dataset_converter_initialization(temporary_bids_directory: pathlib.Path):
    run_config = nwb2bids.RunConfig(bids_directory=temporary_bids_directory)
    dataset_converter = nwb2bids.DatasetConverter.from_remote_dandiset(
        dandiset_id="000003", limit=2, run_config=run_config
    )
    assert not any(dataset_converter.notifications)

    assert isinstance(dataset_converter, nwb2bids.DatasetConverter)


@pytest.mark.remote
def test_remote_dataset_converter_metadata_extraction(temporary_bids_directory: pathlib.Path):
    run_config = nwb2bids.RunConfig(bids_directory=temporary_bids_directory)
    dataset_converter = nwb2bids.DatasetConverter.from_remote_dandiset(
        dandiset_id="000003", limit=2, run_config=run_config
    )
    dataset_converter.extract_metadata()
    assert len(dataset_converter.notifications) == 4

    assert len(dataset_converter.session_converters) == 2

    session_converter = dataset_converter.session_converters[0]
    assert session_converter.session_id == "YutaMouse20-140321"
    assert session_converter.nwbfile_paths == [
        pydantic.HttpUrl("https://dandiarchive.s3.amazonaws.com/blobs/bb8/1f7/bb81f7b3-4cfa-40e7-aa89-95beb1954d8c")
    ]

    session_metadata = session_converter.session_metadata
    assert session_metadata.participant == nwb2bids.bids_models.Participant(
        notifications=[
            nwb2bids.Notification.from_definition(identifier="MissingParticipantSex"),
        ],
        participant_id="YutaMouse20",
        species="Mus musculus",
        sex=None,
        strain=None,
    )
    assert session_metadata.events is not None

    assert session_metadata.probe_table == nwb2bids.bids_models.ProbeTable(
        probes=[
            nwb2bids.bids_models.Probe(
                probe_name="Implant", type="n/a", manufacturer=None, description="Silicon electrodes on Intan probe."
            )
        ],
        modality="ecephys",
    )

    assert session_metadata.channel_table is not None
    assert len(session_metadata.channel_table.channels) == 65
    assert session_metadata.channel_table.channels[0] == nwb2bids.bids_models.Channel(
        name="ch000",
        electrode_name="e000",
        type="n/a",
        units="V",
        sampling_frequency=1250.0,
        stream_id="LFP",
        gain=1.9499999999999999e-07,
    )

    assert session_metadata.electrode_table is not None
    assert len(session_metadata.channel_table.channels) == 65
    assert session_metadata.electrode_table.electrodes[0] == nwb2bids.bids_models.Electrode(
        name="e000",
        probe_name="Implant",
        hemisphere="n/a",
        x=numpy.nan,
        y=numpy.nan,
        z=numpy.nan,
        impedance=-0.001,
        shank_id="shank1",
        location="n/a",
    )


@pytest.mark.remote
def test_remote_dataset_converter_initialization_on_invalid_metadata(temporary_bids_directory: pathlib.Path):
    run_config = nwb2bids.RunConfig(bids_directory=temporary_bids_directory)
    dataset_converter = nwb2bids.DatasetConverter.from_remote_dandiset(
        dandiset_id="000005", version_id="0.220126.1853", limit=2, run_config=run_config
    )
    assert isinstance(dataset_converter, nwb2bids.DatasetConverter)

    expected_notifications = [nwb2bids.Notification.from_definition(identifier="InvalidDandisetMetadata")]
    assert dataset_converter.notifications == expected_notifications

    assert dataset_converter.dataset_description == nwb2bids.bids_models.DatasetDescription(
        Name="Electrophysiology data from thalamic and cortical neurons during somatosensation",
        BIDSVersion="1.10",
        HEDVersion="8.3.0",
        Description=(
            "intracellular and extracellular electrophysiology recordings performed on mouse barrel cortex and "
            "ventral posterolateral nucleus (vpm) in whisker-based object locating task."
        ),
        DatasetType="raw",
        Authors=["Yu, Jianing", "Gutnisky, Diego A", "Hires, S Andrew", "Svoboda, Karel"],
        License="CC-BY-4.0",
    )
