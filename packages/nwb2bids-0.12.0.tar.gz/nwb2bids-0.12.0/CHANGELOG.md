# v0.12.0 (Thu Mar 19 2026)

#### 🚀 Enhancement

- Added general metadata support [#333](https://github.com/con/nwb2bids/pull/333) (codycbakerphd@gmail.com [@CodyCBakerPhD](https://github.com/CodyCBakerPhD))

#### 🐛 Bug Fix

- Require semantic version label in PR label check workflow [#357](https://github.com/con/nwb2bids/pull/357) ([@Copilot](https://github.com/Copilot) [@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- Updated PR labels and changelog section formatting [#355](https://github.com/con/nwb2bids/pull/355) ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- Made channel requirements explicit [#358](https://github.com/con/nwb2bids/pull/358) ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- Record original (pre-sanitization) entity labels in participants.tsv and sessions.tsv [#347](https://github.com/con/nwb2bids/pull/347) ([@Copilot](https://github.com/Copilot) [@CodyCBakerPhD](https://github.com/CodyCBakerPhD) [@pre-commit-ci[bot]](https://github.com/pre-commit-ci[bot]))
- Add `--space` flag with atlas-specific `coordsystem.json` sidecar generation [#344](https://github.com/con/nwb2bids/pull/344) ([@Copilot](https://github.com/Copilot) [@CodyCBakerPhD](https://github.com/CodyCBakerPhD) [@pre-commit-ci[bot]](https://github.com/pre-commit-ci[bot]))
- Add `.bidsignore` with `dandiset.yaml` for archive-targeted conversions [#346](https://github.com/con/nwb2bids/pull/346) ([@Copilot](https://github.com/Copilot) [@CodyCBakerPhD](https://github.com/CodyCBakerPhD) [@pre-commit-ci[bot]](https://github.com/pre-commit-ci[bot]))
- Eliminate static typing errors in `_bids_session_metadata.py` [#322](https://github.com/con/nwb2bids/pull/322) ([@candleindark](https://github.com/candleindark))

#### 🏠 Internal

- Notified admin via email when `major` label is applied to a PR [#360](https://github.com/con/nwb2bids/pull/360) ([@Copilot](https://github.com/Copilot))
- Standardized assertion order (actual left, expected right) throughout tests [#345](https://github.com/con/nwb2bids/pull/345) ([@Copilot](https://github.com/Copilot) [@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- Relaxed sphinx version to latest [#340](https://github.com/con/nwb2bids/pull/340) ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- [pre-commit.ci] pre-commit autoupdate [#339](https://github.com/con/nwb2bids/pull/339) ([@pre-commit-ci[bot]](https://github.com/pre-commit-ci[bot]) [@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- Added workflow to require labels on PRs [#335](https://github.com/con/nwb2bids/pull/335) ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD) [@pre-commit-ci[bot]](https://github.com/pre-commit-ci[bot]))
- Fixed failing remote tests [#334](https://github.com/con/nwb2bids/pull/334) ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- [pre-commit.ci] pre-commit autoupdate [#332](https://github.com/con/nwb2bids/pull/332) ([@pre-commit-ci[bot]](https://github.com/pre-commit-ci[bot]))
- [pre-commit.ci] pre-commit autoupdate [#329](https://github.com/con/nwb2bids/pull/329) ([@pre-commit-ci[bot]](https://github.com/pre-commit-ci[bot]))
- Eliminate static typing errors in `_probes.py` [#321](https://github.com/con/nwb2bids/pull/321) ([@candleindark](https://github.com/candleindark))

#### 📝 Documentation

- Added TSV table rendering directive for Sphinx documentation [#328](https://github.com/con/nwb2bids/pull/328) ([@Copilot](https://github.com/Copilot) [@pre-commit-ci[bot]](https://github.com/pre-commit-ci[bot]) [@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- Fixed some doc links related to BEPs [#326](https://github.com/con/nwb2bids/pull/326) ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- Added external link checking to CI [#324](https://github.com/con/nwb2bids/pull/324) ([@asmacdo](https://github.com/asmacdo) [@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- Expanded README with installation, usage, and DANDI ecosystem context [#318](https://github.com/con/nwb2bids/pull/318) ([@Copilot](https://github.com/Copilot) [@CodyCBakerPhD](https://github.com/CodyCBakerPhD) [@pre-commit-ci[bot]](https://github.com/pre-commit-ci[bot]))

#### 🔩 Dependency Updates

- [pre-commit.ci] pre-commit autoupdate [#336](https://github.com/con/nwb2bids/pull/336) ([@pre-commit-ci[bot]](https://github.com/pre-commit-ci[bot]) [@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- [pre-commit.ci] pre-commit autoupdate [#325](https://github.com/con/nwb2bids/pull/325) ([@pre-commit-ci[bot]](https://github.com/pre-commit-ci[bot]))

#### Authors: 6

- [@Copilot](https://github.com/Copilot)
- [@pre-commit-ci[bot]](https://github.com/pre-commit-ci[bot])
- Austin Macdonald ([@asmacdo](https://github.com/asmacdo))
- Cody Baker ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- CodyCBakerPhD (codycbakerphd@gmail.com)
- Isaac To ([@candleindark](https://github.com/candleindark))

---

# v0.11.1 (Thu Jan 29 2026)

#### 🐛 Bug Fix

- Tested auto release for final time [#315](https://github.com/con/nwb2bids/pull/315) ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- Automatic release [#314](https://github.com/con/nwb2bids/pull/314) ([@github-actions[bot]](https://github.com/github-actions[bot]) [@nwb2bids-releaser[bot]](https://github.com/nwb2bids-releaser[bot]))
- Eliminate typing errors in `_channels.py` [#308](https://github.com/con/nwb2bids/pull/308) ([@candleindark](https://github.com/candleindark) [@CodyCBakerPhD](https://github.com/CodyCBakerPhD))

#### 📝 Documentation

- Expanded data standards documentation section [#299](https://github.com/con/nwb2bids/pull/299) ([@yarikoptic](https://github.com/yarikoptic) [@CodyCBakerPhD](https://github.com/CodyCBakerPhD))

#### Authors: 5

- [@github-actions[bot]](https://github.com/github-actions[bot])
- [@nwb2bids-releaser[bot]](https://github.com/nwb2bids-releaser[bot])
- Cody Baker ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- Isaac To ([@candleindark](https://github.com/candleindark))
- Yaroslav Halchenko ([@yarikoptic](https://github.com/yarikoptic))

---

# v0.11.1 (Wed Jan 28 2026)

#### 🐛 Bug Fix

- Eliminate typing errors in `_channels.py` [#308](https://github.com/con/nwb2bids/pull/308) ([@candleindark](https://github.com/candleindark) [@CodyCBakerPhD](https://github.com/CodyCBakerPhD))

#### 📝 Documentation

- Expanded data standards documentation section [#299](https://github.com/con/nwb2bids/pull/299) ([@yarikoptic](https://github.com/yarikoptic) [@CodyCBakerPhD](https://github.com/CodyCBakerPhD))

#### Authors: 3

- Cody Baker ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- Isaac To ([@candleindark](https://github.com/candleindark))
- Yaroslav Halchenko ([@yarikoptic](https://github.com/yarikoptic))

---

# v0.10.0 (Wed Jan 28 2026)

#### 🚀 Enhancement

- Populated JSON sidecars [#301](https://github.com/con/nwb2bids/pull/301) ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- Centralized more notifications [#296](https://github.com/con/nwb2bids/pull/296) ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- Mapped "unknown" electrode locations to "n/a" [#295](https://github.com/con/nwb2bids/pull/295) ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- Standardized `n/a` to be BIDS compliant and added probe description [#289](https://github.com/con/nwb2bids/pull/289) ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- Created common `Notification` definitions [#284](https://github.com/con/nwb2bids/pull/284) ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD) [@pre-commit-ci[bot]](https://github.com/pre-commit-ci[bot]))
- Refactored `_read_first_bytes` to `_file_startswith` for clarity of use [#287](https://github.com/con/nwb2bids/pull/287) ([@Copilot](https://github.com/Copilot))
- Updated model fields to the latest BEP32 state [#278](https://github.com/con/nwb2bids/pull/278) ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- Clean up Dockerfiles, reduce image, add latest-minimal [#273](https://github.com/con/nwb2bids/pull/273) ([@asmacdo](https://github.com/asmacdo))

#### 🐛 Bug Fix

- test release workflow 2 [#312](https://github.com/con/nwb2bids/pull/312) ([@asmacdo](https://github.com/asmacdo))
- Test auto-release workflow [#310](https://github.com/con/nwb2bids/pull/310) ([@asmacdo](https://github.com/asmacdo))
- Use GitHub App token for auto-release check runs [#309](https://github.com/con/nwb2bids/pull/309) ([@asmacdo](https://github.com/asmacdo))
- Required CI checks to pass before auto-release merges [#306](https://github.com/con/nwb2bids/pull/306) ([@asmacdo](https://github.com/asmacdo) [@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- Eliminated typing errors in `_electrodes.py` [#305](https://github.com/con/nwb2bids/pull/305) ([@candleindark](https://github.com/candleindark) [@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- [pre-commit.ci] pre-commit autoupdate [#298](https://github.com/con/nwb2bids/pull/298) ([@pre-commit-ci[bot]](https://github.com/pre-commit-ci[bot]))
- Added copy-on-write support (requires Python 3.14) [#294](https://github.com/con/nwb2bids/pull/294) ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- Corrected model field descriptions for Notifications [#277](https://github.com/con/nwb2bids/pull/277) ([@candleindark](https://github.com/candleindark))
- bump codecov-action [#270](https://github.com/con/nwb2bids/pull/270) ([@asmacdo](https://github.com/asmacdo))
- [pre-commit.ci] pre-commit autoupdate [#269](https://github.com/con/nwb2bids/pull/269) ([@pre-commit-ci[bot]](https://github.com/pre-commit-ci[bot]))
- Resolved more MyPy errors in Events [#268](https://github.com/con/nwb2bids/pull/268) ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- Removed trailing period in testing assertions [#264](https://github.com/con/nwb2bids/pull/264) ([@yarikoptic](https://github.com/yarikoptic) [@CodyCBakerPhD](https://github.com/CodyCBakerPhD) [@pre-commit-ci[bot]](https://github.com/pre-commit-ci[bot]))
- Updated logo image source in README [#263](https://github.com/con/nwb2bids/pull/263) ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD) [@pre-commit-ci[bot]](https://github.com/pre-commit-ci[bot]))

#### ⚠️ Pushed to `main`

- revert ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- ideas ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD))

#### 🏠 Internal

- Finish standardizing remaining notification definitions [#302](https://github.com/con/nwb2bids/pull/302) ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD) [@pre-commit-ci[bot]](https://github.com/pre-commit-ci[bot]))
- Fix dependency groups definition [#285](https://github.com/con/nwb2bids/pull/285) ([@candleindark](https://github.com/candleindark))
- Added tests for container images [#282](https://github.com/con/nwb2bids/pull/282) ([@asmacdo](https://github.com/asmacdo) [@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- Replaced `pip` with `uv` as the installer for Hatch [#283](https://github.com/con/nwb2bids/pull/283) ([@candleindark](https://github.com/candleindark))
- Removed hatch workaround for `dependency-groups` [#281](https://github.com/con/nwb2bids/pull/281) ([@candleindark](https://github.com/candleindark))
- [pre-commit.ci] pre-commit autoupdate [#276](https://github.com/con/nwb2bids/pull/276) ([@pre-commit-ci[bot]](https://github.com/pre-commit-ci[bot]))
- Enable mypy precommit [#272](https://github.com/con/nwb2bids/pull/272) ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD) [@candleindark](https://github.com/candleindark))
- Fixed mypy errors in `src/nwb2bids/bids_models/_events.py` that are not results of the `Events` model definition [#261](https://github.com/con/nwb2bids/pull/261) ([@candleindark](https://github.com/candleindark) [@CodyCBakerPhD](https://github.com/CodyCBakerPhD))

#### 📝 Documentation

- Added conversion gallery showcasing NWB to BIDS field mappings [#288](https://github.com/con/nwb2bids/pull/288) ([@Copilot](https://github.com/Copilot) [@pre-commit-ci[bot]](https://github.com/pre-commit-ci[bot]) [@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- Enhanced developer documentation [#291](https://github.com/con/nwb2bids/pull/291) ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD))

#### Authors: 6

- [@Copilot](https://github.com/Copilot)
- [@pre-commit-ci[bot]](https://github.com/pre-commit-ci[bot])
- Austin Macdonald ([@asmacdo](https://github.com/asmacdo))
- Cody Baker ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- Isaac To ([@candleindark](https://github.com/candleindark))
- Yaroslav Halchenko ([@yarikoptic](https://github.com/yarikoptic))

---

# v0.10.0 (Wed Jan 28 2026)

#### 🚀 Enhancement

- Populated JSON sidecars [#301](https://github.com/con/nwb2bids/pull/301) ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- Centralized more notifications [#296](https://github.com/con/nwb2bids/pull/296) ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- Mapped "unknown" electrode locations to "n/a" [#295](https://github.com/con/nwb2bids/pull/295) ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- Standardized `n/a` to be BIDS compliant and added probe description [#289](https://github.com/con/nwb2bids/pull/289) ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- Created common `Notification` definitions [#284](https://github.com/con/nwb2bids/pull/284) ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD) [@pre-commit-ci[bot]](https://github.com/pre-commit-ci[bot]))
- Refactored `_read_first_bytes` to `_file_startswith` for clarity of use [#287](https://github.com/con/nwb2bids/pull/287) ([@Copilot](https://github.com/Copilot))
- Updated model fields to the latest BEP32 state [#278](https://github.com/con/nwb2bids/pull/278) ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- Clean up Dockerfiles, reduce image, add latest-minimal [#273](https://github.com/con/nwb2bids/pull/273) ([@asmacdo](https://github.com/asmacdo))

#### 🐛 Bug Fix

- Test auto-release workflow [#310](https://github.com/con/nwb2bids/pull/310) ([@asmacdo](https://github.com/asmacdo))
- Use GitHub App token for auto-release check runs [#309](https://github.com/con/nwb2bids/pull/309) ([@asmacdo](https://github.com/asmacdo))
- Required CI checks to pass before auto-release merges [#306](https://github.com/con/nwb2bids/pull/306) ([@asmacdo](https://github.com/asmacdo) [@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- Eliminated typing errors in `_electrodes.py` [#305](https://github.com/con/nwb2bids/pull/305) ([@candleindark](https://github.com/candleindark) [@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- [pre-commit.ci] pre-commit autoupdate [#298](https://github.com/con/nwb2bids/pull/298) ([@pre-commit-ci[bot]](https://github.com/pre-commit-ci[bot]))
- Added copy-on-write support (requires Python 3.14) [#294](https://github.com/con/nwb2bids/pull/294) ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- Corrected model field descriptions for Notifications [#277](https://github.com/con/nwb2bids/pull/277) ([@candleindark](https://github.com/candleindark))
- bump codecov-action [#270](https://github.com/con/nwb2bids/pull/270) ([@asmacdo](https://github.com/asmacdo))
- [pre-commit.ci] pre-commit autoupdate [#269](https://github.com/con/nwb2bids/pull/269) ([@pre-commit-ci[bot]](https://github.com/pre-commit-ci[bot]))
- Resolved more MyPy errors in Events [#268](https://github.com/con/nwb2bids/pull/268) ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- Removed trailing period in testing assertions [#264](https://github.com/con/nwb2bids/pull/264) ([@yarikoptic](https://github.com/yarikoptic) [@CodyCBakerPhD](https://github.com/CodyCBakerPhD) [@pre-commit-ci[bot]](https://github.com/pre-commit-ci[bot]))
- Updated logo image source in README [#263](https://github.com/con/nwb2bids/pull/263) ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD) [@pre-commit-ci[bot]](https://github.com/pre-commit-ci[bot]))

#### ⚠️ Pushed to `main`

- revert ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- ideas ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD))

#### 🏠 Internal

- Finish standardizing remaining notification definitions [#302](https://github.com/con/nwb2bids/pull/302) ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD) [@pre-commit-ci[bot]](https://github.com/pre-commit-ci[bot]))
- Fix dependency groups definition [#285](https://github.com/con/nwb2bids/pull/285) ([@candleindark](https://github.com/candleindark))
- Added tests for container images [#282](https://github.com/con/nwb2bids/pull/282) ([@asmacdo](https://github.com/asmacdo) [@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- Replaced `pip` with `uv` as the installer for Hatch [#283](https://github.com/con/nwb2bids/pull/283) ([@candleindark](https://github.com/candleindark))
- Removed hatch workaround for `dependency-groups` [#281](https://github.com/con/nwb2bids/pull/281) ([@candleindark](https://github.com/candleindark))
- [pre-commit.ci] pre-commit autoupdate [#276](https://github.com/con/nwb2bids/pull/276) ([@pre-commit-ci[bot]](https://github.com/pre-commit-ci[bot]))
- Enable mypy precommit [#272](https://github.com/con/nwb2bids/pull/272) ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD) [@candleindark](https://github.com/candleindark))
- Fixed mypy errors in `src/nwb2bids/bids_models/_events.py` that are not results of the `Events` model definition [#261](https://github.com/con/nwb2bids/pull/261) ([@candleindark](https://github.com/candleindark) [@CodyCBakerPhD](https://github.com/CodyCBakerPhD))

#### 📝 Documentation

- Added conversion gallery showcasing NWB to BIDS field mappings [#288](https://github.com/con/nwb2bids/pull/288) ([@Copilot](https://github.com/Copilot) [@pre-commit-ci[bot]](https://github.com/pre-commit-ci[bot]) [@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- Enhanced developer documentation [#291](https://github.com/con/nwb2bids/pull/291) ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD))

#### Authors: 6

- [@Copilot](https://github.com/Copilot)
- [@pre-commit-ci[bot]](https://github.com/pre-commit-ci[bot])
- Austin Macdonald ([@asmacdo](https://github.com/asmacdo))
- Cody Baker ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- Isaac To ([@candleindark](https://github.com/candleindark))
- Yaroslav Halchenko ([@yarikoptic](https://github.com/yarikoptic))

---

# v0.9.0 (Wed Jan 07 2026)

### Release Notes

#### Added sanitization feature ([#244](https://github.com/con/nwb2bids/pull/244))

The sanitization feature is now available. 'Sanitization' refers to actively altering various values extracted from the NWB files in an effort to adhere to BIDS validation requirements.

An example would be a NWB file containing the field `nwbfile.session_id = "my session #2"`. While this is perfectly allowed in NWB, attempting to write filenames such as `_ses-my session #2_` would not be valid in BIDS and the resulting files including these labels would not be uploadable to common data archives. Sanitization would instead generate BIDS filenames as `_ses-my+session+2_`.

Currently, only the codes 'sub-labels' or 'ses-labels' are available. These sanitize session or subject ID labels in a way guaranteed to be valid BIDS. We plan to add more capabilities in the future, including some limited in-place modification of NWB contents to allow consistency with the BIDS validation requirements.

---

#### 🚀 Enhancement

- Added icephys support [#254](https://github.com/con/nwb2bids/pull/254) ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD) [@asmacdo](https://github.com/asmacdo))
- Standardized notification assertions [#256](https://github.com/con/nwb2bids/pull/256) ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- Renamed InspectionResult to Notification [#255](https://github.com/con/nwb2bids/pull/255) ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- Standardized all reference to notifications [#253](https://github.com/con/nwb2bids/pull/253) ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- Added sanitization feature [#244](https://github.com/con/nwb2bids/pull/244) ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD) [@pre-commit-ci[bot]](https://github.com/pre-commit-ci[bot]))

#### 🐛 Bug Fix

- [pre-commit.ci] pre-commit autoupdate [#249](https://github.com/con/nwb2bids/pull/249) ([@pre-commit-ci[bot]](https://github.com/pre-commit-ci[bot]))
- Eliminate mypy errors in `src/nwb2bids/bids_models/_probes.py` [#248](https://github.com/con/nwb2bids/pull/248) ([@candleindark](https://github.com/candleindark))
- Eliminate mypy errors related to the `run_config` param in functions and the `run_config` field in Pydantic models [#247](https://github.com/con/nwb2bids/pull/247) ([@candleindark](https://github.com/candleindark))
- Eliminate mypy errors in `nwb2bids/bids_models/_base_metadata_model.py` [#246](https://github.com/con/nwb2bids/pull/246) ([@candleindark](https://github.com/candleindark))
- Disable mypy error code prop-decorator [#245](https://github.com/con/nwb2bids/pull/245) ([@candleindark](https://github.com/candleindark))
- Remove mypy errors in `src/nwb2bids/testing/_assert_subdirectory_structure.py` [#241](https://github.com/con/nwb2bids/pull/241) ([@candleindark](https://github.com/candleindark) [@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- Address mypy errors in `nwb2bids/testing/_mocks/_tutorials.py` and fix incorrect paths in `generate_ephys_tutorial()` [#242](https://github.com/con/nwb2bids/pull/242) ([@candleindark](https://github.com/candleindark))
- [pre-commit.ci] pre-commit autoupdate [#237](https://github.com/con/nwb2bids/pull/237) ([@pre-commit-ci[bot]](https://github.com/pre-commit-ci[bot]))

#### 🏠 Internal

- Added tmate debugging support and custom dispatch workflow [#258](https://github.com/con/nwb2bids/pull/258) ([@yarikoptic](https://github.com/yarikoptic) [@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- Removed labels workflow [#257](https://github.com/con/nwb2bids/pull/257) ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- Fix placecholder debug workflow [#260](https://github.com/con/nwb2bids/pull/260) ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- Added dummy workflow file for debug mode testing [#259](https://github.com/con/nwb2bids/pull/259) ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD))

#### 📝 Documentation

- Move data generation page out of main tutorials [#251](https://github.com/con/nwb2bids/pull/251) ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- Fix light logo readme [#243](https://github.com/con/nwb2bids/pull/243) ([@asmacdo](https://github.com/asmacdo))

#### Authors: 5

- [@pre-commit-ci[bot]](https://github.com/pre-commit-ci[bot])
- Austin Macdonald ([@asmacdo](https://github.com/asmacdo))
- Cody Baker ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- Isaac To ([@candleindark](https://github.com/candleindark))
- Yaroslav Halchenko ([@yarikoptic](https://github.com/yarikoptic))

---

# v0.8.0 (Mon Dec 15 2025)

#### 🚀 Enhancement

- Added `HEDVersion` to dataset description [#232](https://github.com/con/nwb2bids/pull/232) ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- Replaced pytest/doctest with Sybil to add hidden assertions verifying tutorial outputs [#227](https://github.com/con/nwb2bids/pull/227) ([@asmacdo](https://github.com/asmacdo) [@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- Updated writing of channels TSV file [#225](https://github.com/con/nwb2bids/pull/225) ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- Updated writing of probes TSV file [#220](https://github.com/con/nwb2bids/pull/220) ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD))

#### 🐛 Bug Fix

- Fixed confusing labels in `assert_subdirectory_structure` error messages [#228](https://github.com/con/nwb2bids/pull/228) ([@asmacdo](https://github.com/asmacdo) [@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- Updated writing of electrode TSV file [#221](https://github.com/con/nwb2bids/pull/221) ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- [pre-commit.ci] pre-commit autoupdate [#223](https://github.com/con/nwb2bids/pull/223) ([@pre-commit-ci[bot]](https://github.com/pre-commit-ci[bot]))
- Fixed some test markers and imports based on latest conda-forge tests [#219](https://github.com/con/nwb2bids/pull/219) ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD))

#### ⚠️ Pushed to `main`

- Fix typo in CHANGELOG.md ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD))

#### 🏠 Internal

- Restored intel runners [#233](https://github.com/con/nwb2bids/pull/233) ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- Config mypy [#229](https://github.com/con/nwb2bids/pull/229) ([@candleindark](https://github.com/candleindark) [@CodyCBakerPhD](https://github.com/CodyCBakerPhD))

#### 📝 Documentation

- Updated DOI badge link in README [#230](https://github.com/con/nwb2bids/pull/230) ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- Added CITATION.cff to repository (to be used for all formal citations) [#224](https://github.com/con/nwb2bids/pull/224) ([@asmacdo](https://github.com/asmacdo))

#### Authors: 4

- [@pre-commit-ci[bot]](https://github.com/pre-commit-ci[bot])
- Austin Macdonald ([@asmacdo](https://github.com/asmacdo))
- Cody Baker ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- Isaac To ([@candleindark](https://github.com/candleindark))

---

# v0.7.0 (Mon Dec 08 2025)

### Release Notes

#### Added and integrated a configuration model ([#164](https://github.com/con/nwb2bids/pull/164))

This release includes big changes to how arguments are passed in the `nwb2bids` API: the `RunConfig` object.

This class is a Pydantic model which encapsulates all previous configuration settings, such as the output BIDS directory and the additional metadata file path. This class is also now passed at time of initialization for all `Converter` classes and prior to calling the `convert_nwb_dataset` helper function. This reduces any confusion about which steps of the workflow take which arguments, and allows all internal actions to refer to the common location instead of having to manage passing values back-and-forth. It also has the added benefit of simplifying any future additions to configuration options, such as sanitization parameters.

CLI users are unaffected by these changes, aside from gaining a few new arguments - check them out with

```bash
nwb2bids convert --help
```

---

#### 🚀 Enhancement

- Enhance error notifications [#193](https://github.com/con/nwb2bids/pull/193) ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD) [@pre-commit-ci[bot]](https://github.com/pre-commit-ci[bot]) codycbakerphd@gmail.com)
- Added and integrated a configuration model [#164](https://github.com/con/nwb2bids/pull/164) ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD) [@candleindark](https://github.com/candleindark) [@pre-commit-ci[bot]](https://github.com/pre-commit-ci[bot]))

#### 🐛 Bug Fix

- Added automatic notification dump [#216](https://github.com/con/nwb2bids/pull/216) (codycbakerphd@gmail.com [@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- Aggregated unique values across participant rows [#206](https://github.com/con/nwb2bids/pull/206) ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD) [@pre-commit-ci[bot]](https://github.com/pre-commit-ci[bot]))
- Skipped indexed columns; simplified skipping of timeseries [#205](https://github.com/con/nwb2bids/pull/205) ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- Added column metadata to sidecar files [#203](https://github.com/con/nwb2bids/pull/203) ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- Added tutorials to documentation [#173](https://github.com/con/nwb2bids/pull/173) ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD) [@pre-commit-ci[bot]](https://github.com/pre-commit-ci[bot]) codycbakerphd@gmail.com [@asmacdo](https://github.com/asmacdo))
- Fixed broken symlinking of source NWB file [#207](https://github.com/con/nwb2bids/pull/207) ([@asmacdo](https://github.com/asmacdo) [@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- Restrict sphinx version to below 9.0.0 [#201](https://github.com/con/nwb2bids/pull/201) ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- Fixed regression when `bids_directory` does not exist, automatically create it [#183](https://github.com/con/nwb2bids/pull/183) ([@asmacdo](https://github.com/asmacdo) [@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- [pre-commit.ci] pre-commit autoupdate [#200](https://github.com/con/nwb2bids/pull/200) ([@pre-commit-ci[bot]](https://github.com/pre-commit-ci[bot]))
- Fix notification targets and add manual dispatch to daily tests [#196](https://github.com/con/nwb2bids/pull/196) ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- Corrected the labeling notification to proper BIDS [#176](https://github.com/con/nwb2bids/pull/176) ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD) [@pre-commit-ci[bot]](https://github.com/pre-commit-ci[bot]) codycbakerphd@gmail.com)
- Added GeneratedBy to `dataset_description.json` [#170](https://github.com/con/nwb2bids/pull/170) ([@asmacdo](https://github.com/asmacdo) [@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- [pre-commit.ci] pre-commit autoupdate [#184](https://github.com/con/nwb2bids/pull/184) ([@pre-commit-ci[bot]](https://github.com/pre-commit-ci[bot]))
- Added support for operating on DataLad datasets [#165](https://github.com/con/nwb2bids/pull/165) ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD) [@pre-commit-ci[bot]](https://github.com/pre-commit-ci[bot]) codycbakerphd@gmail.com [@github-actions[bot]](https://github.com/github-actions[bot]))
- Revise config model [#175](https://github.com/con/nwb2bids/pull/175) ([@candleindark](https://github.com/candleindark))
- Automatic release [#157](https://github.com/con/nwb2bids/pull/157) ([@github-actions[bot]](https://github.com/github-actions[bot]) [@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- Testing auto release (again) [#156](https://github.com/con/nwb2bids/pull/156) ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD))

#### 🏠 Internal

- Completely remove macOS-13 from all workflows and split daily workflows into remote vs. non-remote [#194](https://github.com/con/nwb2bids/pull/194) ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- Reduced CodeCov spam [#161](https://github.com/con/nwb2bids/pull/161) ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- Automatic release [#155](https://github.com/con/nwb2bids/pull/155) ([@github-actions[bot]](https://github.com/github-actions[bot]) [@CodyCBakerPhD](https://github.com/CodyCBakerPhD))

#### 📝 Documentation

- Added container usage instructions [#209](https://github.com/con/nwb2bids/pull/209) ([@asmacdo](https://github.com/asmacdo) [@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- Improve README badge names [#195](https://github.com/con/nwb2bids/pull/195) ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- Add documentation link/badge to README [#186](https://github.com/con/nwb2bids/pull/186) ([@asmacdo](https://github.com/asmacdo))
- doc: clarify NWB_PATHS are space separated [#182](https://github.com/con/nwb2bids/pull/182) ([@asmacdo](https://github.com/asmacdo))
- Small CHANGELOG fixes [#166](https://github.com/con/nwb2bids/pull/166) ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD))

#### 🧪 Tests

- Skip two DataLad tests in Windows CI [#197](https://github.com/con/nwb2bids/pull/197) ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD) [@yarikoptic](https://github.com/yarikoptic))

#### 🔩 Dependency Updates

- [pre-commit.ci] pre-commit autoupdate [#204](https://github.com/con/nwb2bids/pull/204) ([@pre-commit-ci[bot]](https://github.com/pre-commit-ci[bot]))
- [pre-commit.ci] pre-commit autoupdate [#192](https://github.com/con/nwb2bids/pull/192) ([@pre-commit-ci[bot]](https://github.com/pre-commit-ci[bot]) [@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- [pre-commit.ci] pre-commit autoupdate [#174](https://github.com/con/nwb2bids/pull/174) ([@pre-commit-ci[bot]](https://github.com/pre-commit-ci[bot]))
- [pre-commit.ci] pre-commit autoupdate [#169](https://github.com/con/nwb2bids/pull/169) ([@pre-commit-ci[bot]](https://github.com/pre-commit-ci[bot]))

#### Authors: 7

- [@github-actions[bot]](https://github.com/github-actions[bot])
- [@pre-commit-ci[bot]](https://github.com/pre-commit-ci[bot])
- Austin Macdonald ([@asmacdo](https://github.com/asmacdo))
- Cody Baker ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- CodyCBakerPhD (codycbakerphd@gmail.com)
- Isaac To ([@candleindark](https://github.com/candleindark))
- Yaroslav Halchenko ([@yarikoptic](https://github.com/yarikoptic))

---

# v0.6.0 (Fri Oct 24 2025)

#### 🚀 Enhancement

- Always include session entity, even with only one subject [#148](https://github.com/con/nwb2bids/pull/148) ([@asmacdo](https://github.com/asmacdo))

#### 🐛 Bug Fix

- Testing auto release (again) [#156](https://github.com/con/nwb2bids/pull/156) ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- Testing auto release [#152](https://github.com/con/nwb2bids/pull/152) ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- Resolved protected branch problem in execution of the "Release with Auto" GH workflow [#151](https://github.com/con/nwb2bids/pull/151) ([@candleindark](https://github.com/candleindark))
- Add ability to read from raw dandiset metadata when invalid [#107](https://github.com/con/nwb2bids/pull/107) ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- Upgraded to `rich-click` backend for CLI [#121](https://github.com/con/nwb2bids/pull/121) ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD))

#### ⚠️ Pushed to `main`

- fix: hotfix failure point ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD))

#### 🏠 Internal

- Automatic release [#155](https://github.com/con/nwb2bids/pull/155) ([@github-actions[bot]](https://github.com/github-actions[bot]) [@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- Use two GitHub tokens in Release with Auto workflow [#154](https://github.com/con/nwb2bids/pull/154) ([@candleindark](https://github.com/candleindark) [@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- Improved and consolidated release and deploy workflow [#138](https://github.com/con/nwb2bids/pull/138) ([@candleindark](https://github.com/candleindark))
- Provided fix for Setup Release Labels workflow [#137](https://github.com/con/nwb2bids/pull/137) ([@candleindark](https://github.com/candleindark))
- Automated release and versioning with AUTO and `hatch-vcs` [#114](https://github.com/con/nwb2bids/pull/114) ([@candleindark](https://github.com/candleindark) [@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- Updated email notification conditions and body URL [#135](https://github.com/con/nwb2bids/pull/135) ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- Set the default python version in a Hatch-managed environment to the project's lowest support Python version [#117](https://github.com/con/nwb2bids/pull/117) ([@candleindark](https://github.com/candleindark) [@CodyCBakerPhD](https://github.com/CodyCBakerPhD))

#### 📝 Documentation

- Document how to install and run tests locally [#144](https://github.com/con/nwb2bids/pull/144) ([@asmacdo](https://github.com/asmacdo) [@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- Moved repo files under `.github` [#143](https://github.com/con/nwb2bids/pull/143) ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- Added contributing file [#142](https://github.com/con/nwb2bids/pull/142) ([@asmacdo](https://github.com/asmacdo) [@pre-commit-ci[bot]](https://github.com/pre-commit-ci[bot]) [@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- Filled in docs [#139](https://github.com/con/nwb2bids/pull/139) ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- Fixed RTD build [#131](https://github.com/con/nwb2bids/pull/131) ([@asmacdo](https://github.com/asmacdo) [@pre-commit-ci[bot]](https://github.com/pre-commit-ci[bot]) [@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- Added logo for dark theme [#127](https://github.com/con/nwb2bids/pull/127) ([@asmacdo](https://github.com/asmacdo) [@pre-commit-ci[bot]](https://github.com/pre-commit-ci[bot]))
- Removed project title from README [#125](https://github.com/con/nwb2bids/pull/125) ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- Updated logo image source in `README.md` [#120](https://github.com/con/nwb2bids/pull/120) ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD))

#### 🧪 Tests

- Add daily tests and notifications [#110](https://github.com/con/nwb2bids/pull/110) ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD))

#### 🔩 Dependency Updates

- [pre-commit.ci] pre-commit autoupdate [#146](https://github.com/con/nwb2bids/pull/146) ([@pre-commit-ci[bot]](https://github.com/pre-commit-ci[bot]))
- Added `macos-15-intel` runner; deprecate `macos-13`; removed temporary pin on `h5py` [#145](https://github.com/con/nwb2bids/pull/145) ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- [pre-commit.ci] pre-commit autoupdate [#134](https://github.com/con/nwb2bids/pull/134) ([@pre-commit-ci[bot]](https://github.com/pre-commit-ci[bot]) [@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- Blacklisted `h5py` version dependency for macOS platform [#136](https://github.com/con/nwb2bids/pull/136) ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- [pre-commit.ci] pre-commit autoupdate [#122](https://github.com/con/nwb2bids/pull/122) ([@pre-commit-ci[bot]](https://github.com/pre-commit-ci[bot]))

#### Authors: 5

- [@github-actions[bot]](https://github.com/github-actions[bot])
- [@pre-commit-ci[bot]](https://github.com/pre-commit-ci[bot])
- Austin Macdonald ([@asmacdo](https://github.com/asmacdo))
- Cody Baker ([@CodyCBakerPhD](https://github.com/CodyCBakerPhD))
- Isaac To ([@candleindark](https://github.com/candleindark))


# v0.5.1

# Fixes

Fixed a bug where failure points would not be captured and reported as notifications.



# v0.5.0

# Features

Added a notification system via the return of `nwb2bids.convert_nwb_dataset` and attached as the `.messages` attribute to all converter objects.

# Improvements

Began filtering benign PyNWB warnings during read operations.

# Documentation

Preliminary documentation is now available at [nwb2bids.readthedocs.io](https://nwb2bids.readthedocs.io/en/latest/).



# v0.4.0

# Features

Added a `.from_remote_dandiset` instantiation method for the `DatasetConverter` class. This requires installing the `pip install nwb2bids[dandi]` extra dependencies.



# v0.3.0

# Deprecations

The CLI call `nwb2bids reposit` and API function `nwb2bids.reposit` have been removed - please use `nwb2bids convert` and `nwb2bids.convert_nwb_dataset` instead.

The API instantiation method `.from_nwb_directory` has been standardized as `.from_nwb_paths` and now takes an iterable of either file or directory paths.

# Features

The CLI now accepts a list of space-separated NWB file paths as input, enabling more robust wildcard syntax or `xargs` usage.
For example:
 - `nwb2bids convert file1.nwb file2.nwb`
 - `nwb2bids convert file*.nwb`
 - `find -iname "file*.nwb" | xargs nwb2bids convert`

Added an API argument `nwb_paths: list[str | pathlib.Path]` to all relevant conversion functions.

# Improvements

The BIDS directory arguments to the CLI (`--bids-directory`/`-o`) and API (`bids_directory`) are now optional, with the default case being the current working directory (which must be either empty or BIDS-compatible).

The default of all `file_mode` arguments is now the string `"auto"` instead of `None`.

# Fixes

Ensured removal of any temporary directory created by `BaseConverter._handle_file_mode()`. @candleindark [PR #44](https://github.com/con/nwb2bids/pull/44)

# Documentation

Updated README to accurately reflect CLI call syntax.



# v0.2.0

# Deprecations

The function `nwb2bids.reposit` has been soft deprecated - please use `nwb2bids.convert_nwb_dataset` instead.

# Features

Added events table support.

Added ability to specify additional metadata to write into the BIDS dataset.

Added new object-oriented API, complete with Pydantic model validation, has been added in the form of `nwb2bids.DatasetConverter`, `nwb2bids.SessionConverter`, and the `nwb2bids.bids_models` submodule.

# Improvements

Refactored source code to modern Python packaging standards.

# Fixes

Debugged ecephys structure against BEP032 BIDS schema current to 6/26/2025.



# v0.0.3

fixed sanitization syntax, added more robust tests



# v0.0.2

Make tests ignore order of files



# v0.0.1

Update proper file names
