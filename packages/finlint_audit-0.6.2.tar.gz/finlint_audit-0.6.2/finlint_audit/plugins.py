"""Dynamic plugin loader — imports and validates user-defined assertion functions.

Trust boundary: Plugin module paths come from the YAML config file, which is
operator-authored (same privilege level as database credentials). The operator
who writes the config already has shell access and could run arbitrary code.
importlib.import_module() will execute top-level code in the target module,
which is acceptable within this trust boundary.

Module and function names are validated against safe identifier patterns in
config.py before reaching this loader.
"""

from __future__ import annotations

import importlib
import inspect
from typing import Any, Callable

from finlint_audit.config import PluginConfig
from finlint_audit.result import AssertionContext, AssertionResult


class PluginLoadError(Exception):
    """Raised when a plugin cannot be loaded or validated."""


def load_plugin(cfg: PluginConfig) -> tuple[str, Callable[[AssertionContext], AssertionResult]]:
    """Load and validate a plugin function from its config.

    Returns (assertion_id, callable).
    Raises PluginLoadError if the module/function cannot be loaded or has wrong signature.
    """
    # Import module
    try:
        mod = importlib.import_module(cfg.module)
    except ImportError as exc:
        raise PluginLoadError(
            f"Plugin '{cfg.id}': cannot import module '{cfg.module}': {exc}"
        ) from exc

    # Get function attribute
    try:
        fn = getattr(mod, cfg.function)
    except AttributeError as exc:
        raise PluginLoadError(
            f"Plugin '{cfg.id}': module '{cfg.module}' has no attribute '{cfg.function}'"
        ) from exc

    # Check callable
    if not callable(fn):
        raise PluginLoadError(
            f"Plugin '{cfg.id}': '{cfg.module}.{cfg.function}' is not callable"
        )

    # Validate signature — must accept at least 1 positional argument
    try:
        sig = inspect.signature(fn)
    except (ValueError, TypeError):
        # Some callables (builtins, C extensions) don't have inspectable signatures
        # Allow them through — runtime will catch errors
        return cfg.id, fn

    positional_kinds = {
        inspect.Parameter.POSITIONAL_ONLY,
        inspect.Parameter.POSITIONAL_OR_KEYWORD,
    }
    has_var_positional = any(
        p.kind == inspect.Parameter.VAR_POSITIONAL for p in sig.parameters.values()
    )

    required_positional = sum(
        1 for p in sig.parameters.values()
        if p.kind in positional_kinds and p.default is inspect.Parameter.empty
    )
    total_positional = sum(
        1 for p in sig.parameters.values()
        if p.kind in positional_kinds
    )

    if not has_var_positional and total_positional == 0:
        # Only **kwargs or no params at all
        raise PluginLoadError(
            f"Plugin '{cfg.id}': function must accept at least 1 positional argument "
            f"(the AssertionContext), but '{cfg.function}' accepts 0"
        )

    if required_positional > 1:
        raise PluginLoadError(
            f"Plugin '{cfg.id}': function has {required_positional} required positional "
            f"arguments, but only 1 (AssertionContext) will be provided"
        )

    # Check return type annotation (warning only, not error)
    return_annotation = sig.return_annotation
    if return_annotation is not inspect.Parameter.empty:
        if (
            return_annotation is not AssertionResult
            and getattr(return_annotation, "__name__", None) != "AssertionResult"
        ):
            import warnings
            warnings.warn(
                f"Plugin '{cfg.id}': return type annotation is "
                f"'{return_annotation}', expected AssertionResult",
                stacklevel=2,
            )

    return cfg.id, fn
