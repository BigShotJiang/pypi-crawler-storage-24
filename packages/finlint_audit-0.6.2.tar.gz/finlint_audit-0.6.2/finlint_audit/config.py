"""YAML config parser with env var expansion."""

from __future__ import annotations

import os
import re
from dataclasses import dataclass, field
from typing import Any

import yaml

_PLUGIN_ID_RE = re.compile(r"^[a-z]+-[0-9]{3}$")
_MODULE_RE = re.compile(r"^[a-zA-Z_][a-zA-Z0-9_.]*$")
_FUNCTION_RE = re.compile(r"^[a-zA-Z_][a-zA-Z0-9_]*$")


@dataclass
class DatabaseConfig:
    type: str
    connection: str


@dataclass
class MappingConfig:
    table: str
    columns: dict[str, str]
    filter: str | None = None
    joins: list[dict[str, str]] = field(default_factory=list)


@dataclass
class AssertionConfig:
    enabled: bool = True
    params: dict[str, Any] = field(default_factory=dict)


@dataclass
class PluginConfig:
    id: str
    module: str
    function: str
    enabled: bool = True
    params: dict[str, Any] = field(default_factory=dict)


@dataclass
class AuditConfig:
    database: DatabaseConfig
    mapping: dict[str, MappingConfig]
    assertions: dict[str, AssertionConfig]
    output_format: str = "text"
    plugins: list[PluginConfig] = field(default_factory=list)


_ENV_PATTERN = re.compile(r"\$\{(\w+)\}")


def _expand_env(value: str) -> str:
    """Expand ${VAR} references in a string."""

    def _replace(m: re.Match) -> str:
        name = m.group(1)
        val = os.environ.get(name)
        if val is None:
            raise ValueError(
                f"Environment variable '{name}' is not set"
            )
        return val

    return _ENV_PATTERN.sub(_replace, value)


def parse_config(yaml_str: str) -> AuditConfig:
    """Parse YAML config string into AuditConfig."""
    try:
        raw = yaml.safe_load(yaml_str)
    except yaml.YAMLError as e:
        raise ValueError(f"Parse error in YAML config: {e}") from e

    if not isinstance(raw, dict):
        raise ValueError("Parse error: YAML root must be a mapping")

    # Version check
    version = raw.get("version")
    if version is not None and str(version) != "1":
        raise ValueError(
            f"Unsupported config version '{version}'. Only version '1' is supported."
        )

    # Database
    db_raw = raw.get("database", {})
    connection = _expand_env(str(db_raw.get("connection", "")))
    database = DatabaseConfig(
        type=str(db_raw.get("type", "sqlite")),
        connection=connection,
    )

    # Mappings
    mapping_raw = raw.get("mapping", {})
    if "accounts" not in mapping_raw:
        raise ValueError("Config must include 'mapping.accounts'")

    mapping: dict[str, MappingConfig] = {}
    for name, m in mapping_raw.items():
        mapping[name] = MappingConfig(
            table=m.get("table", name),
            columns=m.get("columns", {}),
            filter=m.get("filter"),
            joins=m.get("joins", []),
        )

    # Assertions
    assertions_raw = raw.get("assertions", {})
    assertions: dict[str, AssertionConfig] = {}
    for name, a in assertions_raw.items():
        if a is None:
            a = {}
        assertions[name] = AssertionConfig(
            enabled=a.get("enabled", True),
            params=a.get("params", {}),
        )

    # Output
    output_raw = raw.get("output", {})
    output_format = output_raw.get("format", "text") if output_raw else "text"

    # Plugins
    plugins = _parse_plugins(raw.get("plugins", []))

    return AuditConfig(
        database=database,
        mapping=mapping,
        assertions=assertions,
        output_format=output_format,
        plugins=plugins,
    )


def _get_builtin_ids() -> set[str]:
    """Derive built-in assertion IDs from the runner's BUILTIN_ASSERTIONS list."""
    from finlint_audit.runner import BUILTIN_ASSERTIONS
    return {assertion_id for assertion_id, _ in BUILTIN_ASSERTIONS}


# Lazy singleton — populated on first use
_BUILTIN_IDS: set[str] | None = None


def _builtin_ids() -> set[str]:
    global _BUILTIN_IDS
    if _BUILTIN_IDS is None:
        _BUILTIN_IDS = _get_builtin_ids()
    return _BUILTIN_IDS


def _parse_plugins(plugins_raw: list | None) -> list[PluginConfig]:
    """Parse and validate plugin configurations."""
    if not plugins_raw:
        return []

    plugins: list[PluginConfig] = []
    seen_ids: set[str] = set()

    for i, p in enumerate(plugins_raw):
        if not isinstance(p, dict):
            raise ValueError(f"Plugin at index {i} must be a mapping")

        # Required fields
        pid = p.get("id")
        if pid is None:
            raise ValueError(f"Plugin at index {i} is missing required 'id' field")
        module = p.get("module")
        if module is None:
            raise ValueError(f"Plugin '{pid}' is missing required 'module' field")
        function = p.get("function")
        if function is None:
            raise ValueError(f"Plugin '{pid}' is missing required 'function' field")

        # Validate ID pattern
        if not _PLUGIN_ID_RE.match(str(pid)):
            raise ValueError(
                f"Plugin ID '{pid}' does not match required pattern: "
                "lowercase letters, hyphen, 3 digits (e.g., 'custom-001')"
            )

        # Check collision with built-in IDs
        if pid in _builtin_ids():
            raise ValueError(
                f"Plugin ID '{pid}' collides with a built-in assertion ID"
            )

        # Check duplicate plugin IDs
        if pid in seen_ids:
            raise ValueError(f"Duplicate plugin ID: '{pid}'")
        seen_ids.add(pid)

        # Validate module and function names
        module_str = str(module)
        function_str = str(function)
        if not _MODULE_RE.match(module_str):
            raise ValueError(
                f"Plugin '{pid}': invalid module name '{module_str}'. "
                "Only alphanumeric characters, underscores, and dots are allowed."
            )
        if not _FUNCTION_RE.match(function_str):
            raise ValueError(
                f"Plugin '{pid}': invalid function name '{function_str}'. "
                "Only alphanumeric characters and underscores are allowed."
            )

        plugins.append(PluginConfig(
            id=str(pid),
            module=module_str,
            function=function_str,
            enabled=p.get("enabled", True),
            params=p.get("params", {}),
        ))

    return plugins
