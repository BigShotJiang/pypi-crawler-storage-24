"""In-memory data adapter for testing."""

from __future__ import annotations

from dataclasses import dataclass, field

from finlint_audit.models import Account, Holding, Liability, Snapshot, Transaction


@dataclass
class MemoryAdapter:
    accounts: list[Account] = field(default_factory=list)
    holdings: list[Holding] = field(default_factory=list)
    liabilities: list[Liability] = field(default_factory=list)
    snapshots: list[Snapshot] = field(default_factory=list)
    transactions: list[Transaction] = field(default_factory=list)
    user_id: str | None = None

    def _user_account_ids(self) -> set[str] | None:
        """Return account IDs for the filtered user, or None if no filter."""
        if self.user_id is None:
            return None
        return {a.id for a in self.accounts if a.user_id == self.user_id}

    def load_accounts(self) -> list[Account]:
        if self.user_id is None:
            return self.accounts
        return [a for a in self.accounts if a.user_id == self.user_id]

    def load_holdings(self) -> list[Holding]:
        ids = self._user_account_ids()
        if ids is None:
            return self.holdings
        return [h for h in self.holdings if h.account_id in ids]

    def load_liabilities(self) -> list[Liability]:
        ids = self._user_account_ids()
        if ids is None:
            return self.liabilities
        return [li for li in self.liabilities if li.account_id in ids]

    def load_snapshots(self) -> list[Snapshot]:
        ids = self._user_account_ids()
        if ids is None:
            return self.snapshots
        return [s for s in self.snapshots if s.account_id in ids]

    def load_transactions(self) -> list[Transaction]:
        ids = self._user_account_ids()
        if ids is None:
            return self.transactions
        return [t for t in self.transactions if t.account_id in ids]
