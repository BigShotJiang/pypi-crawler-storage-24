"""FinLint Audit — Financial data integrity assertions engine."""

__version__ = "0.6.2"

from finlint_audit.adapters.memory import MemoryAdapter
from finlint_audit.assertions.allocation_sanity import assert_allocation_sanity
from finlint_audit.assertions.asset_class_coverage import assert_asset_class_coverage
from finlint_audit.assertions.balance_drift import assert_balance_drift
from finlint_audit.assertions.balance_reconciliation import assert_balance_reconciliation
from finlint_audit.assertions.completeness import assert_completeness
from finlint_audit.assertions.data_completeness import assert_data_completeness
from finlint_audit.assertions.data_freshness import assert_data_freshness
from finlint_audit.assertions.geographic_coverage import assert_geographic_coverage
from finlint_audit.assertions.holdings_account_type import assert_holdings_account_type
from finlint_audit.assertions.liability_balance_freshness import assert_liability_balance_freshness
from finlint_audit.assertions.liability_mismatch import assert_liability_mismatch
from finlint_audit.assertions.negative_holdings import assert_negative_holdings
from finlint_audit.assertions.net_worth import assert_net_worth
from finlint_audit.assertions.overlap import assert_overlap_detection
from finlint_audit.assertions.sign_correctness import assert_sign_correctness
from finlint_audit.assertions.snapshot import assert_snapshot_consistency
from finlint_audit.assertions.stale_accounts import assert_stale_accounts
from finlint_audit.assertions.txn_duplicate import assert_txn_duplicate
from finlint_audit.assertions.txn_orphan import assert_txn_orphan
from finlint_audit.assertions.txn_pending_staleness import assert_txn_pending_staleness
from finlint_audit.assertions.txn_recurring_inflow import assert_txn_recurring_inflow
from finlint_audit.assertions.txn_transfer_conservation import assert_txn_transfer_conservation
from finlint_audit.assertions.uninvested_cash_gap import assert_uninvested_cash_gap
from finlint_audit.config import PluginConfig
from finlint_audit.models import (
    Account,
    AccountType,
    Evidence,
    Holding,
    Liability,
    Snapshot,
    Transaction,
)
from finlint_audit.plugins import PluginLoadError, load_plugin
from finlint_audit.result import AssertionContext, AssertionResult
from finlint_audit.runner import AuditRunner

__all__ = [
    "Account",
    "AccountType",
    "AssertionContext",
    "AssertionResult",
    "AuditRunner",
    "Evidence",
    "Holding",
    "Liability",
    "MemoryAdapter",
    "Snapshot",
    "Transaction",
    "assert_allocation_sanity",
    "assert_asset_class_coverage",
    "assert_balance_drift",
    "assert_balance_reconciliation",
    "assert_completeness",
    "assert_data_completeness",
    "assert_data_freshness",
    "assert_geographic_coverage",
    "assert_holdings_account_type",
    "assert_liability_balance_freshness",
    "assert_liability_mismatch",
    "assert_negative_holdings",
    "assert_net_worth",
    "assert_overlap_detection",
    "assert_sign_correctness",
    "assert_snapshot_consistency",
    "assert_stale_accounts",
    "assert_txn_duplicate",
    "assert_txn_orphan",
    "assert_txn_pending_staleness",
    "assert_txn_recurring_inflow",
    "assert_txn_transfer_conservation",
    "assert_uninvested_cash_gap",
    "load_plugin",
    "PluginConfig",
    "PluginLoadError",
]
