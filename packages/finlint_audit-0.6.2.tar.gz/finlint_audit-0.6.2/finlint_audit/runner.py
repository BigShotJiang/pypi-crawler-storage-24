"""Assertion runner — orchestrates adapter → context → assertions → results."""

from __future__ import annotations

from typing import Callable

from finlint_audit.adapters.base import DataAdapter
from finlint_audit.assertions.allocation_sanity import assert_allocation_sanity
from finlint_audit.assertions.asset_class_coverage import assert_asset_class_coverage
from finlint_audit.assertions.balance_drift import assert_balance_drift
from finlint_audit.assertions.balance_reconciliation import assert_balance_reconciliation
from finlint_audit.assertions.completeness import assert_completeness
from finlint_audit.assertions.data_completeness import assert_data_completeness
from finlint_audit.assertions.data_freshness import assert_data_freshness
from finlint_audit.assertions.geographic_coverage import assert_geographic_coverage
from finlint_audit.assertions.holdings_account_type import assert_holdings_account_type
from finlint_audit.assertions.liability_balance_freshness import assert_liability_balance_freshness
from finlint_audit.assertions.liability_mismatch import assert_liability_mismatch
from finlint_audit.assertions.negative_holdings import assert_negative_holdings
from finlint_audit.assertions.net_worth import assert_net_worth
from finlint_audit.assertions.overlap import assert_overlap_detection
from finlint_audit.assertions.sign_correctness import assert_sign_correctness
from finlint_audit.assertions.snapshot import assert_snapshot_consistency
from finlint_audit.assertions.stale_accounts import assert_stale_accounts
from finlint_audit.assertions.txn_duplicate import assert_txn_duplicate
from finlint_audit.assertions.txn_orphan import assert_txn_orphan
from finlint_audit.assertions.txn_pending_staleness import assert_txn_pending_staleness
from finlint_audit.assertions.txn_recurring_inflow import assert_txn_recurring_inflow
from finlint_audit.assertions.txn_transfer_conservation import assert_txn_transfer_conservation
from finlint_audit.assertions.uninvested_cash_gap import assert_uninvested_cash_gap
from finlint_audit.config import PluginConfig
from finlint_audit.result import AssertionContext, AssertionResult

# Ordered list of built-in assertions
BUILTIN_ASSERTIONS: list[tuple[str, Callable[[AssertionContext], AssertionResult]]] = [
    ("nw-001", assert_net_worth),
    ("sign-001", assert_sign_correctness),
    ("overlap-001", assert_overlap_detection),
    ("snap-001", assert_snapshot_consistency),
    ("drift-001", assert_balance_drift),
    ("txn-001", assert_txn_duplicate),
    ("txn-002", assert_txn_orphan),
    ("txn-003", assert_txn_pending_staleness),
    ("bal-001", assert_balance_reconciliation),
    ("alloc-001", assert_allocation_sanity),
    ("acct-001", assert_stale_accounts),
    ("hold-001", assert_negative_holdings),
    ("liab-001", assert_liability_mismatch),
    ("txn-004", assert_txn_transfer_conservation),
    ("hold-002", assert_holdings_account_type),
    ("comp-001", assert_completeness),
    ("inv-001", assert_uninvested_cash_gap),
    ("alloc-002", assert_asset_class_coverage),
    ("geo-001", assert_geographic_coverage),
    ("txn-005", assert_txn_recurring_inflow),
    ("fresh-001", assert_data_freshness),
    ("liab-002", assert_liability_balance_freshness),
    ("data-001", assert_data_completeness),
]


class AuditRunner:
    def __init__(
        self,
        adapter: DataAdapter,
        disabled: set[str] | None = None,
        only: set[str] | None = None,
        params: dict[str, dict] | None = None,
        plugins: list[PluginConfig] | None = None,
    ) -> None:
        self.adapter = adapter
        self.disabled = disabled or set()
        self.only = only
        self.params = params or {}
        self.plugins = plugins or []

    def run(self) -> list[AssertionResult]:
        # Load all data once
        ctx_base = AssertionContext(
            accounts=self.adapter.load_accounts(),
            holdings=self.adapter.load_holdings(),
            liabilities=self.adapter.load_liabilities(),
            snapshots=self.adapter.load_snapshots(),
            transactions=self.adapter.load_transactions(),
        )

        results: list[AssertionResult] = []

        # Run built-in assertions
        for assertion_id, fn in BUILTIN_ASSERTIONS:
            if assertion_id in self.disabled:
                continue
            if self.only and assertion_id not in self.only:
                continue

            # Build context with assertion-specific params
            ctx = AssertionContext(
                accounts=ctx_base.accounts,
                holdings=ctx_base.holdings,
                liabilities=ctx_base.liabilities,
                snapshots=ctx_base.snapshots,
                transactions=ctx_base.transactions,
                params=self.params.get(assertion_id, {}),
            )
            try:
                results.append(fn(ctx))
            except Exception as exc:
                results.append(AssertionResult(
                    assertion_id=assertion_id,
                    name=assertion_id,
                    status="fail",
                    message=f"Assertion raised an error: {exc}",
                    evidence=[],
                    metadata={"error": str(exc)},
                ))

        # Run plugin assertions
        if self.plugins:
            import sys

            from finlint_audit.plugins import PluginLoadError, load_plugin

            for plugin_cfg in self.plugins:
                if not plugin_cfg.enabled:
                    continue
                if plugin_cfg.id in self.disabled:
                    continue
                if self.only and plugin_cfg.id not in self.only:
                    continue

                ctx = AssertionContext(
                    accounts=ctx_base.accounts,
                    holdings=ctx_base.holdings,
                    liabilities=ctx_base.liabilities,
                    snapshots=ctx_base.snapshots,
                    transactions=ctx_base.transactions,
                    params=plugin_cfg.params,
                )

                try:
                    _, fn = load_plugin(plugin_cfg)
                    result = fn(ctx)
                    # Ensure the result has the correct assertion_id
                    if result.assertion_id != plugin_cfg.id:
                        result = AssertionResult(
                            assertion_id=plugin_cfg.id,
                            name=result.name,
                            status=result.status,
                            message=result.message,
                            evidence=result.evidence,
                            metadata=result.metadata,
                        )
                    results.append(result)
                except PluginLoadError as exc:
                    print(f"Warning: {exc}", file=sys.stderr)
                    results.append(AssertionResult(
                        assertion_id=plugin_cfg.id,
                        name=plugin_cfg.id,
                        status="fail",
                        message=f"Plugin load error: {exc}",
                        evidence=[],
                        metadata={"error": str(exc)},
                    ))
                except Exception as exc:
                    results.append(AssertionResult(
                        assertion_id=plugin_cfg.id,
                        name=plugin_cfg.id,
                        status="fail",
                        message=f"Plugin raised an error: {exc}",
                        evidence=[],
                        metadata={"error": str(exc)},
                    ))

        return results
