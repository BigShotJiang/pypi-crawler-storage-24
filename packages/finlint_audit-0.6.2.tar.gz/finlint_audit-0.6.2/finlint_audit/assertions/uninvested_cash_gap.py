"""Uninvested Cash Gap assertion (inv-001).

Checks that investment account balances are reasonably covered by holdings.
A large gap between balance_current and SUM(holdings) suggests uninvested
cash, settlement lag, or data sync issues.

Accounts with NO holdings are skipped — comp-001 covers that case.
"""

from __future__ import annotations

from decimal import Decimal

from finlint_audit.assertions import cap_evidence
from finlint_audit.models import AccountType, Evidence
from finlint_audit.result import AssertionContext, AssertionResult

_DEFAULT_MAX_CASH_GAP_PCT = Decimal("0.05")
_DEFAULT_MIN_BALANCE = Decimal("100")


def assert_uninvested_cash_gap(ctx: AssertionContext) -> AssertionResult:
    max_gap = Decimal(ctx.params.get("max_cash_gap_pct", str(_DEFAULT_MAX_CASH_GAP_PCT)))
    min_bal = Decimal(ctx.params.get("min_balance", str(_DEFAULT_MIN_BALANCE)))

    investment = [
        a for a in ctx.accounts
        if a.is_active and a.type == AccountType.INVESTMENT
    ]

    if not investment:
        return AssertionResult(
            assertion_id="inv-001",
            name="Uninvested Cash Gap",
            status="pass",
            message="No investment accounts to check",
            evidence=[],
            metadata={},
        )

    # Sum holdings by account
    holdings_by_account: dict[str, Decimal] = {}
    for h in ctx.holdings:
        holdings_by_account[h.account_id] = (
            holdings_by_account.get(h.account_id, Decimal("0")) + h.institution_value
        )

    evidence: list[Evidence] = []
    for a in investment:
        # Skip accounts below min balance
        if a.balance_current < min_bal:
            continue

        holdings_sum = holdings_by_account.get(a.id)
        # Skip accounts with no holdings (comp-001 handles that)
        if holdings_sum is None:
            continue

        gap = a.balance_current - holdings_sum
        gap_pct = abs(gap) / a.balance_current

        if gap_pct > max_gap:
            evidence.append(Evidence(
                field=f"account.id={a.id}",
                expected=f"cash gap <= {max_gap * 100:.0f}% of balance",
                actual=f"gap={gap:.2f} ({gap_pct * 100:.1f}% of ${a.balance_current})",
            ))

    evidence = cap_evidence(evidence, ctx.params)

    if evidence:
        flagged = len([e for e in evidence if e.field != "(capped)"])
        return AssertionResult(
            assertion_id="inv-001",
            name="Uninvested Cash Gap",
            status="warn",
            message=f"{flagged} investment account(s) have large uninvested cash gap",
            evidence=evidence,
            metadata={"flagged_count": str(flagged)},
        )

    return AssertionResult(
        assertion_id="inv-001",
        name="Uninvested Cash Gap",
        status="pass",
        message=f"All investment accounts have reasonable holdings coverage",
        evidence=[],
        metadata={"flagged_count": "0"},
    )
