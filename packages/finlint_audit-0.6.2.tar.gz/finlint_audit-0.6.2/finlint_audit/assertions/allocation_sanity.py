"""Allocation Sanity assertion (alloc-001).

Checks that holdings sum to ~100% of investment account balance.
"""

from __future__ import annotations

from decimal import Decimal

from finlint_audit.models import AccountType, Evidence
from finlint_audit.result import AssertionContext, AssertionResult

_DEFAULT_LOW_THRESHOLD = Decimal("90")
_DEFAULT_HIGH_THRESHOLD = Decimal("110")
_MIN_BALANCE = Decimal("1")


def assert_allocation_sanity(ctx: AssertionContext) -> AssertionResult:
    low = Decimal(ctx.params.get("low_threshold", str(_DEFAULT_LOW_THRESHOLD)))
    high = Decimal(ctx.params.get("high_threshold", str(_DEFAULT_HIGH_THRESHOLD)))

    investment = [a for a in ctx.accounts if a.is_active and a.type == AccountType.INVESTMENT]

    if not investment:
        return AssertionResult(
            assertion_id="alloc-001",
            name="Allocation Sanity",
            status="pass",
            message="No investment accounts to check",
            evidence=[],
            metadata={},
        )

    # Group holdings by account_id
    holdings_by_account: dict[str, Decimal] = {}
    for h in ctx.holdings:
        holdings_by_account[h.account_id] = holdings_by_account.get(h.account_id, Decimal("0")) + h.institution_value

    evidence: list[Evidence] = []
    for a in investment:
        # Skip zero, negative, or very small balances
        if a.balance_current <= Decimal("0") or a.balance_current < _MIN_BALANCE:
            continue

        holdings_sum = holdings_by_account.get(a.id, Decimal("0"))
        pct = (holdings_sum / a.balance_current) * Decimal("100")

        if pct < low or pct > high:
            evidence.append(Evidence(
                field=f"account.id={a.id}",
                expected=f"allocation between {low}% and {high}%",
                actual=f"allocation={pct:.1f}% (holdings=${holdings_sum}, balance=${a.balance_current})",
            ))

    if evidence:
        return AssertionResult(
            assertion_id="alloc-001",
            name="Allocation Sanity",
            status="warn",
            message=f"{len(evidence)} investment account(s) have unusual allocation",
            evidence=evidence,
            metadata={"flagged_count": str(len(evidence))},
        )

    return AssertionResult(
        assertion_id="alloc-001",
        name="Allocation Sanity",
        status="pass",
        message=f"All {len(investment)} investment account(s) have reasonable allocation",
        evidence=[],
        metadata={"flagged_count": "0"},
    )
