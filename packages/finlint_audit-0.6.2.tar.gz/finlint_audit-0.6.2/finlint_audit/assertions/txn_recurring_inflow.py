"""Recurring Inflow Detection assertion (txn-005).

Checks that active accounts have detectable income-like transaction patterns.
Uses Plaid sign convention: negative amounts = inflows (money coming in).

Useful for validating that income data is present for financial health scoring.
"""

from __future__ import annotations

from collections import defaultdict
from datetime import timedelta
from decimal import Decimal

from finlint_audit.assertions import cap_evidence
from finlint_audit.models import Evidence
from finlint_audit.result import AssertionContext, AssertionResult

_DEFAULT_LOOKBACK_DAYS = 90
_DEFAULT_MIN_OCCURRENCES = 3
_DEFAULT_MIN_AMOUNT = Decimal("500")


def assert_txn_recurring_inflow(ctx: AssertionContext) -> AssertionResult:
    lookback = int(ctx.params.get("lookback_days", str(_DEFAULT_LOOKBACK_DAYS)))
    min_occ = int(ctx.params.get("min_occurrences", str(_DEFAULT_MIN_OCCURRENCES)))
    min_amt = Decimal(ctx.params.get("min_amount", str(_DEFAULT_MIN_AMOUNT)))

    if not ctx.transactions:
        return AssertionResult(
            assertion_id="txn-005",
            name="Recurring Inflow Detection",
            status="skip",
            message="No transactions to analyze",
            evidence=[],
            metadata={},
        )

    # Filter non-pending transactions
    non_pending = [t for t in ctx.transactions if not t.pending]
    if not non_pending:
        return AssertionResult(
            assertion_id="txn-005",
            name="Recurring Inflow Detection",
            status="skip",
            message="No non-pending transactions to analyze",
            evidence=[],
            metadata={},
        )

    # Check if we have enough history
    dates = sorted(t.date for t in non_pending)
    history_days = (dates[-1] - dates[0]).days
    if history_days < lookback:
        return AssertionResult(
            assertion_id="txn-005",
            name="Recurring Inflow Detection",
            status="skip",
            message=f"Insufficient history ({history_days} days < {lookback} required)",
            evidence=[],
            metadata={"history_days": str(history_days)},
        )

    # Find qualifying inflows (negative amounts in Plaid convention)
    cutoff = dates[-1] - timedelta(days=lookback)
    inflows = [
        t for t in non_pending
        if t.date >= cutoff and t.amount < Decimal("0") and abs(t.amount) >= min_amt
    ]

    if not inflows:
        return AssertionResult(
            assertion_id="txn-005",
            name="Recurring Inflow Detection",
            status="fail",
            message="No qualifying inflows detected in lookback period",
            evidence=[Evidence(
                field="transactions",
                expected=f">= {min_occ} months with inflows >= ${min_amt}",
                actual="no qualifying inflows found",
            )],
            metadata={
                "qualifying_inflow_count": "0",
                "months_with_inflows": "0",
            },
        )

    # Group by year-month
    months_with_inflows: dict[str, Decimal] = defaultdict(lambda: Decimal("0"))
    for t in inflows:
        key = f"{t.date.year}-{t.date.month:02d}"
        months_with_inflows[key] += abs(t.amount)

    month_count = len(months_with_inflows)
    total_inflow = sum(months_with_inflows.values())
    estimated_monthly = total_inflow / Decimal(str(max(month_count, 1)))

    if month_count >= min_occ:
        return AssertionResult(
            assertion_id="txn-005",
            name="Recurring Inflow Detection",
            status="pass",
            message=f"Recurring inflows detected in {month_count} months",
            evidence=[],
            metadata={
                "qualifying_inflow_count": str(len(inflows)),
                "months_with_inflows": str(month_count),
                "estimated_monthly_income": str(estimated_monthly.quantize(Decimal("0.01"))),
            },
        )

    # Some inflows but below threshold
    evidence = [Evidence(
        field="transactions",
        expected=f">= {min_occ} months with inflows >= ${min_amt}",
        actual=f"{month_count} month(s) with qualifying inflows",
    )]

    return AssertionResult(
        assertion_id="txn-005",
        name="Recurring Inflow Detection",
        status="warn",
        message=f"Inflows detected but inconsistent ({month_count} of {min_occ} months)",
        evidence=evidence,
        metadata={
            "qualifying_inflow_count": str(len(inflows)),
            "months_with_inflows": str(month_count),
            "estimated_monthly_income": str(estimated_monthly.quantize(Decimal("0.01"))),
        },
    )
