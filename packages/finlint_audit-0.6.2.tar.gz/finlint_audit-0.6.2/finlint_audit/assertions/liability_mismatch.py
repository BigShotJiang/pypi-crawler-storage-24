"""Liability-Account Mismatch assertion (liab-001).

Checks that credit/loan accounts have liabilities and liabilities reference valid accounts.
"""

from __future__ import annotations

from finlint_audit.models import AccountType, Evidence
from finlint_audit.result import AssertionContext, AssertionResult

_LIABILITY_TYPES = {AccountType.CREDIT, AccountType.LOAN}


def assert_liability_mismatch(ctx: AssertionContext) -> AssertionResult:
    if not ctx.accounts and not ctx.liabilities:
        return AssertionResult(
            assertion_id="liab-001",
            name="Liability-Account Mismatch",
            status="pass",
            message="No accounts or liabilities to check",
            evidence=[],
            metadata={},
        )

    account_map = {a.id: a for a in ctx.accounts}
    liability_account_ids = {l.account_id for l in ctx.liabilities}

    fails: list[Evidence] = []
    warns: list[Evidence] = []

    # Direction A: Active credit/loan accounts should have liabilities
    for a in ctx.accounts:
        if not a.is_active:
            continue
        if a.type in _LIABILITY_TYPES and a.id not in liability_account_ids:
            fails.append(Evidence(
                field=f"account.id={a.id}",
                expected=f"{a.type.value} account should have liability record",
                actual="no matching liability found",
            ))

    # Direction B: Liabilities should reference existing accounts
    for l in ctx.liabilities:
        acct = account_map.get(l.account_id)
        if acct is None:
            fails.append(Evidence(
                field=f"liability.id={l.id}",
                expected="liability references existing account",
                actual=f"account_id={l.account_id} not found",
            ))
        elif acct.type not in _LIABILITY_TYPES:
            # Direction C: Wrong type
            warns.append(Evidence(
                field=f"liability.id={l.id}",
                expected="liability on credit or loan account",
                actual=f"account {l.account_id} is type={acct.type.value}",
            ))

    all_evidence = fails + warns
    missing_count = len([e for e in fails if e.field.startswith("account.")])
    orphan_count = len([e for e in fails if e.field.startswith("liability.")])

    if fails:
        return AssertionResult(
            assertion_id="liab-001",
            name="Liability-Account Mismatch",
            status="fail",
            message=f"{len(fails)} liability/account mismatch(es) found",
            evidence=all_evidence,
            metadata={
                "missing_liability_count": str(missing_count),
                "orphan_liability_count": str(orphan_count),
            },
        )

    if warns:
        return AssertionResult(
            assertion_id="liab-001",
            name="Liability-Account Mismatch",
            status="warn",
            message=f"{len(warns)} liability on unexpected account type(s)",
            evidence=warns,
            metadata={
                "missing_liability_count": "0",
                "orphan_liability_count": "0",
            },
        )

    return AssertionResult(
        assertion_id="liab-001",
        name="Liability-Account Mismatch",
        status="pass",
        message="All liability/account relationships valid",
        evidence=[],
        metadata={
            "missing_liability_count": "0",
            "orphan_liability_count": "0",
        },
    )
