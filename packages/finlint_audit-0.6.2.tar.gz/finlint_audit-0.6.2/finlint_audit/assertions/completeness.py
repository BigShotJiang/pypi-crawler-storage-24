"""Completeness assertion (comp-001).

Checks that each active account has the expected supporting data.
"""

from __future__ import annotations

from finlint_audit.assertions import cap_evidence
from finlint_audit.models import AccountType, Evidence
from finlint_audit.result import AssertionContext, AssertionResult

_LIABILITY_TYPES = {AccountType.CREDIT, AccountType.LOAN}


def assert_completeness(ctx: AssertionContext) -> AssertionResult:
    active = [a for a in ctx.accounts if a.is_active]

    if not active:
        return AssertionResult(
            assertion_id="comp-001",
            name="Completeness",
            status="pass",
            message="No active accounts to check",
            evidence=[],
            metadata={},
        )

    # Build lookup sets
    accounts_with_holdings = {h.account_id for h in ctx.holdings}
    accounts_with_liabilities = {li.account_id for li in ctx.liabilities}
    accounts_with_snapshots = {s.account_id for s in ctx.snapshots}

    evidence: list[Evidence] = []

    for a in active:
        # Check holdings requirement (investment only)
        if a.type == AccountType.INVESTMENT and a.id not in accounts_with_holdings:
            evidence.append(Evidence(
                field=f"account.id={a.id}",
                expected="investment account should have holdings",
                actual="no holdings found",
            ))

        # Check liability requirement (credit/loan only)
        if a.type in _LIABILITY_TYPES and a.id not in accounts_with_liabilities:
            evidence.append(Evidence(
                field=f"account.id={a.id}",
                expected=f"{a.type.value} account should have liability record",
                actual="no liability found",
            ))

        # Check snapshot requirement (all account types)
        if a.id not in accounts_with_snapshots:
            evidence.append(Evidence(
                field=f"account.id={a.id}",
                expected="account should have at least one snapshot",
                actual="no snapshots found",
            ))

    incomplete_count = len({e.field for e in evidence})  # unique accounts
    total_issues = len(evidence)
    evidence = cap_evidence(evidence, ctx.params)

    if total_issues > 0:
        return AssertionResult(
            assertion_id="comp-001",
            name="Completeness",
            status="warn",
            message=f"{incomplete_count} account(s) have incomplete data",
            evidence=evidence,
            metadata={"incomplete_count": str(incomplete_count)},
        )

    return AssertionResult(
        assertion_id="comp-001",
        name="Completeness",
        status="pass",
        message=f"All {len(active)} account(s) have complete data",
        evidence=[],
        metadata={"incomplete_count": "0"},
    )
