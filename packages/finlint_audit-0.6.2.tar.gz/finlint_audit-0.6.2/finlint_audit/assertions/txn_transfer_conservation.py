"""Transfer Conservation assertion (txn-004).

Checks that transfer transactions net to approximately $0 per date.
"""

from __future__ import annotations

from decimal import Decimal

from finlint_audit.assertions import cap_evidence
from finlint_audit.models import Evidence, Transaction
from finlint_audit.result import AssertionContext, AssertionResult

_DEFAULT_TOLERANCE = Decimal("1.00")


def _is_transfer(txn: Transaction) -> bool:
    """Check if transaction is a transfer by category or name fallback."""
    if txn.category:
        return "transfer" in txn.category.lower()
    return "transfer" in txn.name.lower()


def assert_txn_transfer_conservation(ctx: AssertionContext) -> AssertionResult:
    tolerance = Decimal(ctx.params.get("tolerance", str(_DEFAULT_TOLERANCE)))

    transfers = [t for t in ctx.transactions if _is_transfer(t)]

    if not transfers:
        return AssertionResult(
            assertion_id="txn-004",
            name="Transfer Conservation",
            status="pass",
            message="No transfer transactions to check",
            evidence=[],
            metadata={},
        )

    # Group by date
    by_date: dict[str, Decimal] = {}
    for t in transfers:
        key = str(t.date)
        by_date[key] = by_date.get(key, Decimal("0")) + t.amount

    evidence: list[Evidence] = []
    for dt, net in sorted(by_date.items()):
        if abs(net) > tolerance:
            evidence.append(Evidence(
                field=f"date={dt}",
                expected=f"net within ${tolerance}",
                actual=f"net=${net}",
            ))

    imbalanced_count = len(evidence)
    evidence = cap_evidence(evidence, ctx.params)

    if imbalanced_count > 0:
        return AssertionResult(
            assertion_id="txn-004",
            name="Transfer Conservation",
            status="warn",
            message=f"{imbalanced_count} date(s) have imbalanced transfers",
            evidence=evidence,
            metadata={"imbalanced_count": str(imbalanced_count)},
        )

    return AssertionResult(
        assertion_id="txn-004",
        name="Transfer Conservation",
        status="pass",
        message=f"All transfer dates balance within ${tolerance}",
        evidence=[],
        metadata={"imbalanced_count": "0"},
    )
