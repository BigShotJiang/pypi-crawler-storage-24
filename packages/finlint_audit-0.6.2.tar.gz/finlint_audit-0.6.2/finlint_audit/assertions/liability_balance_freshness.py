"""Liability Balance Freshness assertion (liab-002).

Checks that last_statement_balance and current_balance on liabilities
are not diverging unreasonably. Large divergence may indicate stale
statement data or missed payments.

In rosie, both fields currently map to the same column, so this assertion
always passes. It's ready for when rosie adds a real current_balance column.
"""

from __future__ import annotations

from decimal import Decimal

from finlint_audit.assertions import cap_evidence
from finlint_audit.models import Evidence
from finlint_audit.result import AssertionContext, AssertionResult

_DEFAULT_MAX_DIVERGENCE_PCT = Decimal("0.10")
_DEFAULT_MIN_BALANCE = Decimal("50")


def assert_liability_balance_freshness(ctx: AssertionContext) -> AssertionResult:
    max_div = Decimal(ctx.params.get("max_divergence_pct", str(_DEFAULT_MAX_DIVERGENCE_PCT)))
    min_bal = Decimal(ctx.params.get("min_balance", str(_DEFAULT_MIN_BALANCE)))

    if not ctx.liabilities:
        return AssertionResult(
            assertion_id="liab-002",
            name="Liability Balance Freshness",
            status="pass",
            message="No liabilities to check",
            evidence=[],
            metadata={},
        )

    evidence: list[Evidence] = []
    checked = 0

    for li in ctx.liabilities:
        # Need both balances to compare
        if li.last_statement_balance is None or li.current_balance is None:
            continue

        # Skip small balances
        denom = max(abs(li.last_statement_balance), abs(li.current_balance))
        if denom < min_bal:
            continue

        checked += 1
        divergence = abs(li.last_statement_balance - li.current_balance) / denom

        if divergence > max_div:
            evidence.append(Evidence(
                field=f"liability.id={li.id}",
                expected=f"divergence <= {max_div * 100:.0f}%",
                actual=(
                    f"divergence={divergence * 100:.1f}% "
                    f"(statement=${li.last_statement_balance}, current=${li.current_balance})"
                ),
            ))

    evidence = cap_evidence(evidence, ctx.params)

    if evidence:
        flagged = len([e for e in evidence if e.field != "(capped)"])
        return AssertionResult(
            assertion_id="liab-002",
            name="Liability Balance Freshness",
            status="warn",
            message=f"{flagged} liability(ies) have divergent balances",
            evidence=evidence,
            metadata={"flagged_count": str(flagged), "checked_count": str(checked)},
        )

    return AssertionResult(
        assertion_id="liab-002",
        name="Liability Balance Freshness",
        status="pass",
        message=f"Checked {checked} liability(ies), all balances consistent",
        evidence=[],
        metadata={"flagged_count": "0", "checked_count": str(checked)},
    )
