"""Built-in financial assertions."""

from __future__ import annotations

from finlint_audit.models import Evidence

_DEFAULT_MAX_EVIDENCE = 50


def cap_evidence(evidence: list[Evidence], params: dict) -> list[Evidence]:
    """Truncate evidence list and append a summary item if over the cap.

    Reads ``max_evidence`` from *params* (default 50).  A value of 0 means
    unlimited (no cap).  When the list exceeds the cap, the first *max_evidence*
    items are kept and a summary ``Evidence`` is appended describing how many
    were omitted.
    """
    try:
        max_ev = int(params.get("max_evidence", _DEFAULT_MAX_EVIDENCE))
    except (ValueError, TypeError):
        max_ev = _DEFAULT_MAX_EVIDENCE

    if max_ev <= 0 or len(evidence) <= max_ev:
        return evidence

    omitted = len(evidence) - max_ev
    return evidence[:max_ev] + [
        Evidence(
            field="(capped)",
            expected=f"max_evidence={max_ev}",
            actual=f"{omitted} more evidence item(s) omitted",
        )
    ]
