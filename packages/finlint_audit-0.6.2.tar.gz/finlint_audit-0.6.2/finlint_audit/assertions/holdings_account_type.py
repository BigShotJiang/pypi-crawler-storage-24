"""Holdings-Account Type Mismatch assertion (hold-002).

Checks that holdings only exist on investment accounts.
"""

from __future__ import annotations

from finlint_audit.assertions import cap_evidence
from finlint_audit.models import AccountType, Evidence
from finlint_audit.result import AssertionContext, AssertionResult


def assert_holdings_account_type(ctx: AssertionContext) -> AssertionResult:
    if not ctx.holdings:
        return AssertionResult(
            assertion_id="hold-002",
            name="Holdings-Account Type",
            status="pass",
            message="No holdings to check",
            evidence=[],
            metadata={},
        )

    account_type_map = {a.id: a.type for a in ctx.accounts}

    fails: list[Evidence] = []
    warns: list[Evidence] = []

    for h in ctx.holdings:
        label = h.ticker if h.ticker else f"holding.id={h.id}"
        acct_type = account_type_map.get(h.account_id)

        if acct_type is None:
            warns.append(Evidence(
                field=label,
                expected="holding on investment account",
                actual=f"account_id={h.account_id} not found",
            ))
        elif acct_type == AccountType.OTHER:
            warns.append(Evidence(
                field=label,
                expected="holding on investment account",
                actual=f"account {h.account_id} is type=other",
            ))
        elif acct_type != AccountType.INVESTMENT:
            fails.append(Evidence(
                field=label,
                expected="holding on investment account",
                actual=f"account {h.account_id} is type={acct_type.value}",
            ))

    mismatch_count = len(fails) + len(warns)
    all_evidence = fails + warns
    all_evidence = cap_evidence(all_evidence, ctx.params)

    if fails:
        return AssertionResult(
            assertion_id="hold-002",
            name="Holdings-Account Type",
            status="fail",
            message=f"{len(fails)} holding(s) on non-investment accounts",
            evidence=all_evidence,
            metadata={"mismatch_count": str(mismatch_count)},
        )

    if warns:
        return AssertionResult(
            assertion_id="hold-002",
            name="Holdings-Account Type",
            status="warn",
            message=f"{len(warns)} holding(s) on unknown or ambiguous account types",
            evidence=all_evidence,
            metadata={"mismatch_count": str(mismatch_count)},
        )

    return AssertionResult(
        assertion_id="hold-002",
        name="Holdings-Account Type",
        status="pass",
        message=f"All {len(ctx.holdings)} holding(s) are on investment accounts",
        evidence=[],
        metadata={"mismatch_count": "0"},
    )
