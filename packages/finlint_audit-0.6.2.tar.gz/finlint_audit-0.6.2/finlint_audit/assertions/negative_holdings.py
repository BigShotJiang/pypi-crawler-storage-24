"""Negative Holdings assertion (hold-001).

Checks for holdings with negative quantity or institution_value.
"""

from __future__ import annotations

from decimal import Decimal

from finlint_audit.assertions import cap_evidence
from finlint_audit.models import Evidence
from finlint_audit.result import AssertionContext, AssertionResult


def assert_negative_holdings(ctx: AssertionContext) -> AssertionResult:
    if not ctx.holdings:
        return AssertionResult(
            assertion_id="hold-001",
            name="Negative Holdings",
            status="pass",
            message="No holdings to check",
            evidence=[],
            metadata={},
        )

    evidence: list[Evidence] = []
    for h in ctx.holdings:
        issues = []
        if h.quantity < Decimal("0"):
            issues.append(f"quantity={h.quantity}")
        if h.institution_value < Decimal("0"):
            issues.append(f"institution_value={h.institution_value}")

        if issues:
            label = h.ticker if h.ticker else f"holding.id={h.id}"
            evidence.append(Evidence(
                field=label,
                expected="non-negative quantity and institution_value",
                actual=", ".join(issues),
            ))

    negative_count = len(evidence)
    evidence = cap_evidence(evidence, ctx.params)

    if negative_count > 0:
        return AssertionResult(
            assertion_id="hold-001",
            name="Negative Holdings",
            status="fail",
            message=f"{negative_count} holding(s) have negative values",
            evidence=evidence,
            metadata={"negative_count": str(negative_count)},
        )

    return AssertionResult(
        assertion_id="hold-001",
        name="Negative Holdings",
        status="pass",
        message=f"All {len(ctx.holdings)} holding(s) have non-negative values",
        evidence=[],
        metadata={"negative_count": "0"},
    )
