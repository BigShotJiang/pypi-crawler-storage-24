"""Stale Accounts assertion (acct-001).

Checks that all active accounts have at least one snapshot within N days.
"""

from __future__ import annotations

from datetime import datetime, timezone

from finlint_audit.assertions import cap_evidence
from finlint_audit.models import Evidence, Snapshot
from finlint_audit.result import AssertionContext, AssertionResult

_DEFAULT_STALE_DAYS = 7


def assert_stale_accounts(ctx: AssertionContext) -> AssertionResult:
    stale_days = int(ctx.params.get("stale_days", _DEFAULT_STALE_DAYS))

    active = [a for a in ctx.accounts if a.is_active]

    if not active:
        return AssertionResult(
            assertion_id="acct-001",
            name="Stale Accounts",
            status="pass",
            message="No active accounts to check",
            evidence=[],
            metadata={},
        )

    # Group snapshots by account, find latest
    latest_by_account: dict[str, Snapshot] = {}
    for s in ctx.snapshots:
        if (
            s.account_id not in latest_by_account
            or s.captured_at > latest_by_account[s.account_id].captured_at
        ):
            latest_by_account[s.account_id] = s

    # Determine now
    if ctx.now is not None:
        now = ctx.now
    else:
        has_tz = any(s.captured_at.tzinfo is not None for s in ctx.snapshots)
        now = datetime.now(tz=timezone.utc) if has_tz else datetime.now()

    evidence: list[Evidence] = []
    for a in active:
        snap = latest_by_account.get(a.id)
        if snap is None:
            evidence.append(Evidence(
                field=f"account.id={a.id}",
                expected=f"snapshot within {stale_days} days",
                actual="no snapshots found",
            ))
            continue

        age = (now - snap.captured_at).days
        if age > stale_days:
            evidence.append(Evidence(
                field=f"account.id={a.id}",
                expected=f"snapshot within {stale_days} days",
                actual=f"latest snapshot is {age} days old",
            ))

    stale_count = len(evidence)
    evidence = cap_evidence(evidence, ctx.params)

    if stale_count > 0:
        return AssertionResult(
            assertion_id="acct-001",
            name="Stale Accounts",
            status="warn",
            message=f"{stale_count} account(s) have stale or missing snapshots",
            evidence=evidence,
            metadata={"stale_count": str(stale_count)},
        )

    return AssertionResult(
        assertion_id="acct-001",
        name="Stale Accounts",
        status="pass",
        message=f"All {len(active)} account(s) have fresh snapshots",
        evidence=[],
        metadata={"stale_count": "0"},
    )
