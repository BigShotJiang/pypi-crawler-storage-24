"""Geographic Coverage assertion (geo-001).

Checks that holdings can be classified as domestic or international
for a sufficient proportion of total portfolio value. Uses heuristics:
1. Known international ETF tickers (VXUS, VEA, VWO, etc.)
2. Known domestic ETF tickers (VTI, VOO, SPY, etc.)
3. Name keywords ("international", "emerging", "global", etc.)
4. Cash/fixed income → domestic
5. Everything else → unclassified

More lenient default threshold (70%) because individual stocks are
hard to classify without external data.
"""

from __future__ import annotations

from decimal import Decimal

from finlint_audit.assertions import cap_evidence
from finlint_audit.models import Evidence
from finlint_audit.result import AssertionContext, AssertionResult

_DEFAULT_MIN_CLASSIFIED_PCT = Decimal("0.70")

_INTERNATIONAL_TICKERS = {
    "VXUS", "IXUS", "VEA", "VWO", "EFA", "EEM", "IEFA", "IEMG",
    "VYMI", "VSS", "SCZ", "GWX", "DLS", "FNDF", "SCHE", "SPDW",
    "ACWX", "CWI", "VEU", "VSGX",
}

_DOMESTIC_TICKERS = {
    "VTI", "VOO", "SPY", "QQQ", "IVV", "VIG", "SCHD", "VYM",
    "VTSAX", "VFIAX", "SWTSX", "SWPPX", "IWM", "IWF", "IWD",
    "VTV", "VUG", "VB", "VO", "MGK", "SCHG", "SCHV", "DGRO",
    "RSP", "DIA", "MDY", "IJR", "IJH",
}

_INTERNATIONAL_KEYWORDS = {
    "international", "emerging", "global", "foreign", "world",
    "ex-us", "ex us", "developed markets", "emerging markets",
}


def _classify_holding(h) -> str:
    """Classify a holding as 'domestic', 'international', or 'unknown'."""
    ticker_upper = (h.ticker or "").strip().upper()

    if ticker_upper in _INTERNATIONAL_TICKERS:
        return "international"
    if ticker_upper in _DOMESTIC_TICKERS:
        return "domestic"

    # Check name keywords
    name_lower = (h.name or "").strip().lower()
    if name_lower:
        for keyword in _INTERNATIONAL_KEYWORDS:
            if keyword in name_lower:
                return "international"

    # Cash and fixed income → domestic
    sec_type = (getattr(h, "security_type", None) or "").strip().lower()
    if sec_type in ("cash", "fixed income"):
        return "domestic"

    return "unknown"


def assert_geographic_coverage(ctx: AssertionContext) -> AssertionResult:
    min_pct = Decimal(ctx.params.get("min_classified_pct", str(_DEFAULT_MIN_CLASSIFIED_PCT)))

    if not ctx.holdings:
        return AssertionResult(
            assertion_id="geo-001",
            name="Geographic Coverage",
            status="pass",
            message="No holdings to check",
            evidence=[],
            metadata={},
        )

    total_value = Decimal("0")
    domestic_value = Decimal("0")
    international_value = Decimal("0")
    unclassified: list[Evidence] = []

    for h in ctx.holdings:
        if h.institution_value <= Decimal("0"):
            continue
        total_value += h.institution_value

        classification = _classify_holding(h)
        if classification == "domestic":
            domestic_value += h.institution_value
        elif classification == "international":
            international_value += h.institution_value
        else:
            unclassified.append(Evidence(
                field=f"holding.id={h.id}",
                expected="classifiable as domestic or international",
                actual=f"ticker={h.ticker!r}, name={h.name!r}",
            ))

    if total_value == Decimal("0"):
        return AssertionResult(
            assertion_id="geo-001",
            name="Geographic Coverage",
            status="pass",
            message="No holdings with positive value",
            evidence=[],
            metadata={},
        )

    classified_value = domestic_value + international_value
    coverage = classified_value / total_value
    domestic_pct = (domestic_value / total_value * 100).quantize(Decimal("0.1"))
    international_pct = (international_value / total_value * 100).quantize(Decimal("0.1"))

    metadata = {
        "classified_pct": str((coverage * 100).quantize(Decimal("0.1"))),
        "domestic_pct": str(domestic_pct),
        "international_pct": str(international_pct),
        "total_value": str(total_value),
    }

    if coverage < min_pct:
        unclassified = cap_evidence(unclassified, ctx.params)
        return AssertionResult(
            assertion_id="geo-001",
            name="Geographic Coverage",
            status="warn",
            message=f"Only {coverage * 100:.0f}% of holdings classifiable by geography",
            evidence=unclassified,
            metadata=metadata,
        )

    return AssertionResult(
        assertion_id="geo-001",
        name="Geographic Coverage",
        status="pass",
        message=f"{coverage * 100:.0f}% of holdings classifiable by geography",
        evidence=[],
        metadata=metadata,
    )
