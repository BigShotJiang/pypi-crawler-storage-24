"""Balance Reconciliation assertion (bal-001).

Checks that investment account balance ~ sum of holdings' institution_value.
"""

from __future__ import annotations

from decimal import Decimal

from finlint_audit.models import AccountType, Evidence
from finlint_audit.result import AssertionContext, AssertionResult

_DEFAULT_TOLERANCE = Decimal("1.00")


def assert_balance_reconciliation(ctx: AssertionContext) -> AssertionResult:
    tolerance = Decimal(ctx.params.get("tolerance", str(_DEFAULT_TOLERANCE)))

    # Only check investment accounts
    investment = [a for a in ctx.accounts if a.is_active and a.type == AccountType.INVESTMENT]

    if not investment:
        return AssertionResult(
            assertion_id="bal-001",
            name="Balance Reconciliation",
            status="pass",
            message="No investment accounts to check",
            evidence=[],
            metadata={},
        )

    # Group holdings by account_id
    holdings_by_account: dict[str, Decimal] = {}
    for h in ctx.holdings:
        holdings_by_account[h.account_id] = holdings_by_account.get(h.account_id, Decimal("0")) + h.institution_value

    evidence: list[Evidence] = []
    for a in investment:
        holdings_sum = holdings_by_account.get(a.id, Decimal("0"))
        drift = abs(a.balance_current - holdings_sum)
        if drift > tolerance:
            evidence.append(Evidence(
                field=f"account.id={a.id}",
                expected=f"holdings sum within ${tolerance} of balance",
                actual=f"balance=${a.balance_current}, holdings_sum=${holdings_sum}, drift=${drift}",
            ))

    if evidence:
        return AssertionResult(
            assertion_id="bal-001",
            name="Balance Reconciliation",
            status="fail",
            message=f"{len(evidence)} investment account(s) have balance/holdings mismatch",
            evidence=evidence,
            metadata={"mismatch_count": str(len(evidence))},
        )

    return AssertionResult(
        assertion_id="bal-001",
        name="Balance Reconciliation",
        status="pass",
        message=f"All {len(investment)} investment account(s) reconcile within ${tolerance}",
        evidence=[],
        metadata={"mismatch_count": "0"},
    )
