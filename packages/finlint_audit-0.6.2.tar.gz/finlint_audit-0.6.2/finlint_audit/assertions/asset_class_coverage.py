"""Asset Class Coverage assertion (alloc-002).

Checks that holdings have valid security_type classification for a
sufficient proportion of total portfolio value. Unclassified holdings
limit the quality of asset allocation analysis.

Known types are based on Plaid's security type enum.
"""

from __future__ import annotations

from decimal import Decimal

from finlint_audit.assertions import cap_evidence
from finlint_audit.models import Evidence
from finlint_audit.result import AssertionContext, AssertionResult

_DEFAULT_MIN_CLASSIFIED_PCT = Decimal("0.80")

_KNOWN_SECURITY_TYPES = {
    "equity",
    "etf",
    "mutual fund",
    "fixed income",
    "cash",
    "cryptocurrency",
    "derivative",
    "option",
}


def assert_asset_class_coverage(ctx: AssertionContext) -> AssertionResult:
    min_pct = Decimal(ctx.params.get("min_classified_pct", str(_DEFAULT_MIN_CLASSIFIED_PCT)))

    if not ctx.holdings:
        return AssertionResult(
            assertion_id="alloc-002",
            name="Asset Class Coverage",
            status="pass",
            message="No holdings to check",
            evidence=[],
            metadata={},
        )

    total_value = Decimal("0")
    classified_value = Decimal("0")
    unclassified: list[Evidence] = []

    for h in ctx.holdings:
        if h.institution_value <= Decimal("0"):
            continue
        total_value += h.institution_value

        sec_type = (h.security_type or "").strip().lower()
        if sec_type in _KNOWN_SECURITY_TYPES:
            classified_value += h.institution_value
        else:
            unclassified.append(Evidence(
                field=f"holding.id={h.id}",
                expected="known security_type",
                actual=f"security_type={h.security_type!r} (ticker={h.ticker})",
            ))

    if total_value == Decimal("0"):
        return AssertionResult(
            assertion_id="alloc-002",
            name="Asset Class Coverage",
            status="pass",
            message="No holdings with positive value",
            evidence=[],
            metadata={},
        )

    coverage = classified_value / total_value

    if coverage < min_pct:
        unclassified = cap_evidence(unclassified, ctx.params)
        return AssertionResult(
            assertion_id="alloc-002",
            name="Asset Class Coverage",
            status="warn",
            message=f"Only {coverage * 100:.0f}% of holdings value has known security type",
            evidence=unclassified,
            metadata={
                "classified_pct": str((coverage * 100).quantize(Decimal("0.1"))),
                "total_value": str(total_value),
                "classified_value": str(classified_value),
            },
        )

    return AssertionResult(
        assertion_id="alloc-002",
        name="Asset Class Coverage",
        status="pass",
        message=f"{coverage * 100:.0f}% of holdings value has known security type",
        evidence=[],
        metadata={
            "classified_pct": str((coverage * 100).quantize(Decimal("0.1"))),
            "total_value": str(total_value),
            "classified_value": str(classified_value),
        },
    )
