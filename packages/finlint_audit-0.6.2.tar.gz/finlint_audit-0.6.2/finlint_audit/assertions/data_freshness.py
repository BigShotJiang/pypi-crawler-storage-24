"""Data Freshness assertion (fresh-001).

Checks that account data is sufficiently recent by examining the
last_updated field on accounts. Stale data may indicate broken syncs
or disconnected providers.

If ALL accounts have last_updated=None, the assertion skips (data not
available from provider). Respects ctx.now for deterministic testing.
"""

from __future__ import annotations

from datetime import datetime, timezone

from finlint_audit.assertions import cap_evidence
from finlint_audit.models import Evidence
from finlint_audit.result import AssertionContext, AssertionResult

_DEFAULT_WARNING_DAYS = 3
_DEFAULT_ERROR_DAYS = 7


def assert_data_freshness(ctx: AssertionContext) -> AssertionResult:
    warn_days = int(ctx.params.get("warning_days", str(_DEFAULT_WARNING_DAYS)))
    error_days = int(ctx.params.get("error_days", str(_DEFAULT_ERROR_DAYS)))

    active = [a for a in ctx.accounts if a.is_active]

    if not active:
        return AssertionResult(
            assertion_id="fresh-001",
            name="Data Freshness",
            status="pass",
            message="No active accounts to check",
            evidence=[],
            metadata={},
        )

    # Filter to accounts with last_updated
    with_dates = [a for a in active if a.last_updated is not None]

    if not with_dates:
        return AssertionResult(
            assertion_id="fresh-001",
            name="Data Freshness",
            status="skip",
            message="No accounts have last_updated data",
            evidence=[],
            metadata={},
        )

    now = ctx.now or datetime.now(tz=timezone.utc)
    # Make now timezone-aware if it isn't
    if now.tzinfo is None:
        now = now.replace(tzinfo=timezone.utc)

    evidence: list[Evidence] = []
    stale_count = 0
    error_count = 0

    for a in with_dates:
        last = a.last_updated
        # Make last_updated timezone-aware if it isn't
        if last.tzinfo is None:
            last = last.replace(tzinfo=timezone.utc)

        age_days = (now - last).days

        if age_days > error_days:
            error_count += 1
            evidence.append(Evidence(
                field=f"account.id={a.id}",
                expected=f"last_updated within {error_days} days",
                actual=f"last_updated {age_days} days ago",
            ))
        elif age_days > warn_days:
            stale_count += 1
            evidence.append(Evidence(
                field=f"account.id={a.id}",
                expected=f"last_updated within {warn_days} days",
                actual=f"last_updated {age_days} days ago",
            ))

    evidence = cap_evidence(evidence, ctx.params)

    if error_count > 0:
        return AssertionResult(
            assertion_id="fresh-001",
            name="Data Freshness",
            status="fail",
            message=f"{error_count} account(s) have critically stale data",
            evidence=evidence,
            metadata={
                "stale_count": str(stale_count),
                "error_count": str(error_count),
            },
        )

    if stale_count > 0:
        return AssertionResult(
            assertion_id="fresh-001",
            name="Data Freshness",
            status="warn",
            message=f"{stale_count} account(s) have stale data",
            evidence=evidence,
            metadata={
                "stale_count": str(stale_count),
                "error_count": "0",
            },
        )

    return AssertionResult(
        assertion_id="fresh-001",
        name="Data Freshness",
        status="pass",
        message=f"All {len(with_dates)} account(s) have fresh data",
        evidence=[],
        metadata={
            "stale_count": "0",
            "error_count": "0",
        },
    )
