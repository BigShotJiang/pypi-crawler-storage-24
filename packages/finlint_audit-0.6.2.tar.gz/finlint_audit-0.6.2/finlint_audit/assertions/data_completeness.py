"""Scoring Data Completeness assertion (data-001).

Portfolio-level check that the user has enough data for meaningful
financial analysis. Unlike comp-001 (per-account), this checks whether
the overall portfolio has the required data categories.

Components checked:
- At least 1 active depository account (for emergency fund, cash flow)
- At least 1 account with transactions (for spending/income analysis)
- If investment accounts exist, at least 1 has holdings
- If credit/loan accounts exist, at least 1 has liability records
"""

from __future__ import annotations

from finlint_audit.models import AccountType, Evidence
from finlint_audit.result import AssertionContext, AssertionResult

_LIABILITY_TYPES = {AccountType.CREDIT, AccountType.LOAN}


def assert_data_completeness(ctx: AssertionContext) -> AssertionResult:
    active = [a for a in ctx.accounts if a.is_active]

    if not active:
        return AssertionResult(
            assertion_id="data-001",
            name="Scoring Data Completeness",
            status="fail",
            message="No active accounts — cannot perform financial analysis",
            evidence=[Evidence(
                field="accounts",
                expected="at least 1 active account",
                actual="0 active accounts",
            )],
            metadata={"missing_components": "accounts"},
        )

    missing: list[str] = []
    evidence: list[Evidence] = []

    # Check: at least 1 depository account
    has_depository = any(a.type == AccountType.DEPOSITORY for a in active)
    if not has_depository:
        missing.append("depository")
        evidence.append(Evidence(
            field="accounts",
            expected="at least 1 depository account",
            actual="no depository accounts found",
        ))

    # Check: at least 1 account with transactions
    accounts_with_txns = {t.account_id for t in ctx.transactions}
    active_ids = {a.id for a in active}
    has_transactions = bool(accounts_with_txns & active_ids)
    if not has_transactions:
        missing.append("transactions")
        evidence.append(Evidence(
            field="transactions",
            expected="at least 1 account with transactions",
            actual="no transactions found for active accounts",
        ))

    # Check: if investment accounts exist, at least 1 has holdings
    investment_accounts = [a for a in active if a.type == AccountType.INVESTMENT]
    if investment_accounts:
        accounts_with_holdings = {h.account_id for h in ctx.holdings}
        has_holdings = bool(accounts_with_holdings & {a.id for a in investment_accounts})
        if not has_holdings:
            missing.append("holdings")
            evidence.append(Evidence(
                field="holdings",
                expected="at least 1 investment account with holdings",
                actual=f"{len(investment_accounts)} investment account(s), none with holdings",
            ))

    # Check: if credit/loan accounts exist, at least 1 has liability
    liability_accounts = [a for a in active if a.type in _LIABILITY_TYPES]
    if liability_accounts:
        accounts_with_liabilities = {li.account_id for li in ctx.liabilities}
        has_liabilities = bool(accounts_with_liabilities & {a.id for a in liability_accounts})
        if not has_liabilities:
            missing.append("liabilities")
            evidence.append(Evidence(
                field="liabilities",
                expected="at least 1 credit/loan account with liability record",
                actual=f"{len(liability_accounts)} credit/loan account(s), none with liability",
            ))

    if missing:
        status = "fail" if "accounts" in missing else "warn"
        return AssertionResult(
            assertion_id="data-001",
            name="Scoring Data Completeness",
            status=status,
            message=f"Missing data components: {', '.join(missing)}",
            evidence=evidence,
            metadata={"missing_components": ",".join(missing)},
        )

    return AssertionResult(
        assertion_id="data-001",
        name="Scoring Data Completeness",
        status="pass",
        message="All required data components present for financial analysis",
        evidence=[],
        metadata={"missing_components": ""},
    )
