"""Integration tests for per-user filtering using SQLite fixtures."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from finlint_audit.adapters.sql import SqlAdapter
from finlint_audit.cli import format_results, format_results_json
from finlint_audit.config import parse_config
from finlint_audit.runner import AuditRunner

FIXTURES_DIR = Path(__file__).parent / "fixtures"


def _load_config(db_name: str) -> str:
    yaml_text = (FIXTURES_DIR / "fixture.yaml").read_text()
    db_path = str(FIXTURES_DIR / db_name)
    return yaml_text.replace("FIXTURE_DB_PATH", f"sqlite:///{db_path}")


def _run_audit(db_name: str, user_id: str | None = None, only: set[str] | None = None):
    cfg = parse_config(_load_config(db_name))
    try:
        from sqlalchemy import create_engine
    except ImportError:
        pytest.skip("sqlalchemy not installed")
    engine = create_engine(cfg.database.connection)
    adapter = SqlAdapter(cfg, engine=engine, user_id=user_id)
    runner = AuditRunner(adapter=adapter, only=only)
    return runner.run()


class TestPassingFixtureUserU1AllPass:
    def test_all_pass(self):
        results = _run_audit("passing.db", user_id="u1")
        assert len(results) == 23
        for r in results:
            assert r.status in ("pass", "warn", "skip"), f"{r.assertion_id}: {r.status} — {r.message}"


class TestFailingFixtureUserU2IsClean:
    def test_u2_all_pass(self):
        results = _run_audit("failing.db", user_id="u2")
        assert len(results) == 23
        # u2 only has one clean depository account — no failures when isolated
        for r in results:
            assert r.status in ("pass", "warn", "skip"), f"{r.assertion_id}: {r.status} — {r.message}"


class TestNoUserIdFailingFixture:
    def test_unfiltered_sees_failures(self):
        results = _run_audit("failing.db")
        statuses = {r.assertion_id: r.status for r in results}
        assert statuses["sign-001"] == "fail"


class TestUserIdWithOnlyFilter:
    def test_combined(self):
        results = _run_audit("passing.db", user_id="u1", only={"nw-001"})
        assert len(results) == 1
        assert results[0].assertion_id == "nw-001"


class TestUserIdJsonOutput:
    def test_json_has_user_id(self):
        results = _run_audit("passing.db", user_id="u1")
        json_str = format_results_json(results, user_id="u1")
        data = json.loads(json_str)
        assert data["user_id"] == "u1"
        assert data["summary"]["total"] == 23

    def test_json_no_user_id(self):
        results = _run_audit("passing.db")
        json_str = format_results_json(results)
        data = json.loads(json_str)
        assert "user_id" not in data


class TestUserIdTextOutput:
    def test_text_shows_filter(self):
        # The CLI adds the header — we test format_results doesn't break
        results = _run_audit("passing.db", user_id="u1")
        text = format_results(results)
        assert "passed" in text


class TestDryRunUserId:
    def test_dry_run_shows_param(self):
        cfg = parse_config(_load_config("passing.db"))
        adapter = SqlAdapter(cfg, user_id="u1")
        queries = adapter.get_queries()
        for name, sql in queries.items():
            assert ":user_id" in sql, f"{name} missing :user_id"


class TestUserIdGitHubActionsFormat:
    def test_github_actions_works(self):
        from finlint_audit.cli import format_results_github
        results = _run_audit("passing.db", user_id="u1")
        output = format_results_github(results)
        # All pass — no ::error:: lines
        assert "::error" not in output
