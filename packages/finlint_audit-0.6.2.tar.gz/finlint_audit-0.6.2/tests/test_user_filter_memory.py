"""MemoryAdapter user_id filtering tests."""

from __future__ import annotations

from decimal import Decimal

from finlint_audit.adapters.memory import MemoryAdapter
from tests.helpers import (
    make_account,
    make_holding,
    make_liability,
    make_snapshot,
    make_transaction,
)


def _two_user_adapter(**kwargs) -> MemoryAdapter:
    """Build adapter with data split across u1 (a1, a2) and u2 (a3)."""
    return MemoryAdapter(
        accounts=[
            make_account("a1", "depository", balance=15000, user_id="u1"),
            make_account("a2", "investment", balance=70000, user_id="u1"),
            make_account("a3", "credit", balance=2500, user_id="u2"),
        ],
        holdings=[
            make_holding("h1", "a2", 50000, ticker="VTI"),
            make_holding("h2", "a2", 20000, ticker="VXUS"),
            make_holding("h3", "a3", 1000, ticker="SPY"),  # u2's holding
        ],
        liabilities=[
            make_liability("l1", "a3", "credit", current_balance=Decimal("2500")),
        ],
        snapshots=[
            make_snapshot("s1", "a1", 15000, "2026-03-15T12:00:00"),
            make_snapshot("s2", "a2", 70000, "2026-03-15T12:00:00"),
            make_snapshot("s3", "a3", 2500, "2026-03-15T12:00:00"),
        ],
        transactions=[
            make_transaction("t1", "a1", 50, "2026-03-10"),
            make_transaction("t2", "a3", 45, "2026-03-12"),
        ],
        **kwargs,
    )


# ── Blackbox tests ──────────────────────────────────────────────────

class TestNoUserIdReturnsAll:
    def test_all_accounts(self):
        adapter = _two_user_adapter()
        assert len(adapter.load_accounts()) == 3

    def test_all_holdings(self):
        adapter = _two_user_adapter()
        assert len(adapter.load_holdings()) == 3

    def test_all_transactions(self):
        adapter = _two_user_adapter()
        assert len(adapter.load_transactions()) == 2


class TestUserIdFiltersAccounts:
    def test_u1_gets_two(self):
        adapter = _two_user_adapter(user_id="u1")
        accounts = adapter.load_accounts()
        assert len(accounts) == 2
        assert {a.id for a in accounts} == {"a1", "a2"}

    def test_u2_gets_one(self):
        adapter = _two_user_adapter(user_id="u2")
        accounts = adapter.load_accounts()
        assert len(accounts) == 1
        assert accounts[0].id == "a3"


class TestUserIdFiltersHoldings:
    def test_u1_holdings(self):
        adapter = _two_user_adapter(user_id="u1")
        holdings = adapter.load_holdings()
        assert len(holdings) == 2
        assert all(h.account_id == "a2" for h in holdings)

    def test_u2_holdings(self):
        adapter = _two_user_adapter(user_id="u2")
        holdings = adapter.load_holdings()
        assert len(holdings) == 1
        assert holdings[0].account_id == "a3"


class TestUserIdFiltersSnapshots:
    def test_u1_snapshots(self):
        adapter = _two_user_adapter(user_id="u1")
        snapshots = adapter.load_snapshots()
        assert len(snapshots) == 2
        assert {s.account_id for s in snapshots} == {"a1", "a2"}


class TestUserIdFiltersTransactions:
    def test_u1_transactions(self):
        adapter = _two_user_adapter(user_id="u1")
        txns = adapter.load_transactions()
        assert len(txns) == 1
        assert txns[0].account_id == "a1"


class TestUserIdFiltersLiabilities:
    def test_u1_no_liabilities(self):
        adapter = _two_user_adapter(user_id="u1")
        assert len(adapter.load_liabilities()) == 0

    def test_u2_has_liability(self):
        adapter = _two_user_adapter(user_id="u2")
        liabs = adapter.load_liabilities()
        assert len(liabs) == 1
        assert liabs[0].account_id == "a3"


class TestNonexistentUserReturnsEmpty:
    def test_empty(self):
        adapter = _two_user_adapter(user_id="nobody")
        assert adapter.load_accounts() == []
        assert adapter.load_holdings() == []
        assert adapter.load_liabilities() == []
        assert adapter.load_snapshots() == []
        assert adapter.load_transactions() == []


class TestSingleUserReturnsEverything:
    def test_all_data_for_single_user(self):
        adapter = MemoryAdapter(
            accounts=[make_account("a1", "depository", user_id="u1")],
            holdings=[make_holding("h1", "a1", 5000)],
            snapshots=[make_snapshot("s1", "a1", 5000, "2026-03-15T12:00:00")],
            transactions=[make_transaction("t1", "a1", 50, "2026-03-10")],
            liabilities=[make_liability("l1", "a1")],
            user_id="u1",
        )
        assert len(adapter.load_accounts()) == 1
        assert len(adapter.load_holdings()) == 1
        assert len(adapter.load_snapshots()) == 1
        assert len(adapter.load_transactions()) == 1
        assert len(adapter.load_liabilities()) == 1


# ── Whitebox tests ──────────────────────────────────────────────────

class TestAccountWithoutUserIdExcluded:
    def test_none_user_id_excluded(self):
        adapter = MemoryAdapter(
            accounts=[
                make_account("a1", "depository", user_id="u1"),
                make_account("a2", "depository", user_id=None),
            ],
            user_id="u1",
        )
        accounts = adapter.load_accounts()
        assert len(accounts) == 1
        assert accounts[0].id == "a1"


class TestHoldingOrphanAccountExcluded:
    def test_orphan_holding(self):
        adapter = MemoryAdapter(
            accounts=[make_account("a1", "investment", user_id="u1")],
            holdings=[
                make_holding("h1", "a1", 5000),
                make_holding("h2", "a99", 3000),  # orphan — a99 not in u1's accounts
            ],
            user_id="u1",
        )
        holdings = adapter.load_holdings()
        assert len(holdings) == 1
        assert holdings[0].id == "h1"


class TestUserIdEmptyString:
    def test_empty_string_is_filter(self):
        adapter = MemoryAdapter(
            accounts=[
                make_account("a1", "depository", user_id="u1"),
                make_account("a2", "depository", user_id=""),
            ],
            user_id="",
        )
        accounts = adapter.load_accounts()
        assert len(accounts) == 1
        assert accounts[0].id == "a2"


class TestAccountsCachedForChildFilter:
    """Both load_holdings and load_transactions use the same account ID set."""

    def test_consistent_filtering(self):
        adapter = _two_user_adapter(user_id="u1")
        holdings = adapter.load_holdings()
        txns = adapter.load_transactions()
        # Both should only reference u1's account IDs
        holding_accts = {h.account_id for h in holdings}
        txn_accts = {t.account_id for t in txns}
        assert holding_accts <= {"a1", "a2"}
        assert txn_accts <= {"a1", "a2"}
