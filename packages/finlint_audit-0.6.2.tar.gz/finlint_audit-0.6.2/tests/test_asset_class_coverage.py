"""Tests for alloc-002: Asset Class Coverage."""

from decimal import Decimal

from finlint_audit.assertions.asset_class_coverage import assert_asset_class_coverage
from tests.helpers import make_ctx, make_holding


class TestAssetClassCoverage:
    """Blackbox tests for alloc-002."""

    def test_empty_holdings(self):
        r = assert_asset_class_coverage(make_ctx())
        assert r.status == "pass"
        assert r.assertion_id == "alloc-002"

    def test_all_classified_pass(self):
        r = assert_asset_class_coverage(make_ctx(
            holdings=[
                make_holding("h1", "a1", 5000, security_type="equity"),
                make_holding("h2", "a1", 3000, security_type="etf"),
                make_holding("h3", "a1", 2000, security_type="fixed income"),
            ],
        ))
        assert r.status == "pass"
        assert r.metadata["classified_pct"] == "100.0"

    def test_all_unknown_warns(self):
        r = assert_asset_class_coverage(make_ctx(
            holdings=[
                make_holding("h1", "a1", 5000, security_type="other"),
                make_holding("h2", "a1", 3000, security_type=None),
            ],
        ))
        assert r.status == "warn"
        assert r.metadata["classified_pct"] == "0.0"

    def test_mixed_above_threshold_pass(self):
        """90% classified > 80% threshold → pass."""
        r = assert_asset_class_coverage(make_ctx(
            holdings=[
                make_holding("h1", "a1", 9000, security_type="equity"),
                make_holding("h2", "a1", 1000, security_type=None),
            ],
        ))
        assert r.status == "pass"
        assert r.metadata["classified_pct"] == "90.0"

    def test_mixed_below_threshold_warns(self):
        """70% classified < 80% threshold → warn."""
        r = assert_asset_class_coverage(make_ctx(
            holdings=[
                make_holding("h1", "a1", 7000, security_type="equity"),
                make_holding("h2", "a1", 3000, security_type="other"),
            ],
        ))
        assert r.status == "warn"
        assert r.metadata["classified_pct"] == "70.0"

    def test_each_known_type_recognized(self):
        known_types = [
            "equity", "etf", "mutual fund", "fixed income",
            "cash", "cryptocurrency", "derivative", "option",
        ]
        for sec_type in known_types:
            r = assert_asset_class_coverage(make_ctx(
                holdings=[make_holding("h1", "a1", 1000, security_type=sec_type)],
            ))
            assert r.status == "pass", f"Failed for {sec_type}"

    def test_case_insensitive(self):
        r = assert_asset_class_coverage(make_ctx(
            holdings=[make_holding("h1", "a1", 1000, security_type="EQUITY")],
        ))
        assert r.status == "pass"

    def test_none_not_classified(self):
        r = assert_asset_class_coverage(make_ctx(
            holdings=[make_holding("h1", "a1", 1000, security_type=None)],
        ))
        assert r.status == "warn"

    def test_empty_string_not_classified(self):
        r = assert_asset_class_coverage(make_ctx(
            holdings=[make_holding("h1", "a1", 1000, security_type="")],
        ))
        assert r.status == "warn"

    def test_zero_value_skip(self):
        r = assert_asset_class_coverage(make_ctx(
            holdings=[make_holding("h1", "a1", 0, security_type="other")],
        ))
        assert r.status == "pass"
        assert "No holdings with positive value" in r.message

    def test_custom_threshold(self):
        r = assert_asset_class_coverage(make_ctx(
            holdings=[
                make_holding("h1", "a1", 6000, security_type="equity"),
                make_holding("h2", "a1", 4000, security_type="other"),
            ],
            params={"min_classified_pct": "0.50"},
        ))
        assert r.status == "pass"

    def test_metadata_values(self):
        r = assert_asset_class_coverage(make_ctx(
            holdings=[
                make_holding("h1", "a1", 8000, security_type="equity"),
                make_holding("h2", "a1", 2000, security_type=None),
            ],
        ))
        assert r.metadata["total_value"] == "10000"
        assert r.metadata["classified_value"] == "8000"

    def test_evidence_on_warn(self):
        r = assert_asset_class_coverage(make_ctx(
            holdings=[
                make_holding("h1", "a1", 5000, security_type="other", ticker="XYZ"),
            ],
        ))
        assert len(r.evidence) >= 1
        assert "h1" in r.evidence[0].field
