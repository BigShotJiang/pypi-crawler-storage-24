"""SQL generation tests for per-user filtering (--user-id)."""

from __future__ import annotations

import pytest

from finlint_audit.adapters.sql import SqlAdapter, generate_select
from finlint_audit.config import AuditConfig, DatabaseConfig, MappingConfig


def _make_config(
    accounts_columns: dict | None = None,
    accounts_filter: str | None = None,
    accounts_table: str = "accounts",
    holdings_columns: dict | None = None,
    holdings_table: str = "holdings",
    snapshots_columns: dict | None = None,
    transactions_columns: dict | None = None,
    liabilities_columns: dict | None = None,
    include_holdings: bool = True,
    include_snapshots: bool = True,
    include_transactions: bool = True,
    include_liabilities: bool = True,
) -> AuditConfig:
    acct_cols = accounts_columns or {"id": "id", "type": "type", "balance_current": "balance_current", "user_id": "user_id"}
    mapping: dict[str, MappingConfig] = {
        "accounts": MappingConfig(table=accounts_table, columns=acct_cols, filter=accounts_filter),
    }
    if include_holdings:
        mapping["holdings"] = MappingConfig(
            table=holdings_table,
            columns=holdings_columns or {"id": "id", "account_id": "account_id", "institution_value": "institution_value"},
        )
    if include_snapshots:
        mapping["snapshots"] = MappingConfig(
            table="snapshots",
            columns=snapshots_columns or {"id": "id", "account_id": "account_id", "balance": "balance", "captured_at": "captured_at"},
        )
    if include_transactions:
        mapping["transactions"] = MappingConfig(
            table="transactions",
            columns=transactions_columns or {"id": "id", "account_id": "account_id", "amount": "amount", "date": "date"},
        )
    if include_liabilities:
        mapping["liabilities"] = MappingConfig(
            table="liabilities",
            columns=liabilities_columns or {"id": "id", "account_id": "account_id", "type": "type"},
        )
    return AuditConfig(
        database=DatabaseConfig(type="sqlite", connection="test.db"),
        mapping=mapping,
        assertions={},
    )


# ── Blackbox tests ──────────────────────────────────────────────────

class TestNoUserIdNoChange:
    """When user_id is None, SQL should be unchanged from existing behavior."""

    def test_accounts_no_filter(self):
        cfg = _make_config()
        sql = generate_select(cfg.mapping["accounts"])
        assert ":user_id" not in sql
        assert "WHERE" not in sql

    def test_holdings_no_filter(self):
        cfg = _make_config()
        sql = generate_select(cfg.mapping["holdings"])
        assert ":user_id" not in sql


class TestAccountsUserIdAppended:
    """Accounts table gets direct WHERE user_id = :user_id."""

    def test_basic(self):
        cfg = _make_config()
        sql = generate_select(cfg.mapping["accounts"], user_id="u1", is_accounts=True)
        assert "WHERE user_id = :user_id" in sql

    def test_no_existing_filter(self):
        cfg = _make_config(accounts_filter=None)
        sql = generate_select(cfg.mapping["accounts"], user_id="u1", is_accounts=True)
        assert "WHERE user_id = :user_id" in sql
        # Should not have AND without a preceding condition
        assert "AND user_id" not in sql


class TestAccountsWithExistingFilter:
    """When accounts already has a filter, user_id is ANDed."""

    def test_appended_with_and(self):
        cfg = _make_config(accounts_filter="is_active = 1")
        sql = generate_select(cfg.mapping["accounts"], user_id="u1", is_accounts=True)
        assert "WHERE is_active = 1 AND user_id = :user_id" in sql


class TestChildTableSubqueries:
    """Child tables get account_id IN (SELECT ...) subquery."""

    def test_holdings_subquery(self):
        cfg = _make_config()
        sql = generate_select(
            cfg.mapping["holdings"],
            user_id="u1",
            accounts_mapping=cfg.mapping["accounts"],
        )
        assert "account_id IN (SELECT id FROM accounts WHERE user_id = :user_id)" in sql

    def test_snapshots_subquery(self):
        cfg = _make_config()
        sql = generate_select(
            cfg.mapping["snapshots"],
            user_id="u1",
            accounts_mapping=cfg.mapping["accounts"],
        )
        assert "account_id IN (SELECT id FROM accounts WHERE user_id = :user_id)" in sql

    def test_transactions_subquery(self):
        cfg = _make_config()
        sql = generate_select(
            cfg.mapping["transactions"],
            user_id="u1",
            accounts_mapping=cfg.mapping["accounts"],
        )
        assert "account_id IN (SELECT id FROM accounts WHERE user_id = :user_id)" in sql

    def test_liabilities_subquery(self):
        cfg = _make_config()
        sql = generate_select(
            cfg.mapping["liabilities"],
            user_id="u1",
            accounts_mapping=cfg.mapping["accounts"],
        )
        assert "account_id IN (SELECT id FROM accounts WHERE user_id = :user_id)" in sql


class TestDryRunShowsUserFilter:
    """Dry-run mode shows :user_id placeholder in output."""

    def test_dry_run_queries(self):
        cfg = _make_config()
        adapter = SqlAdapter(cfg, user_id="u1")
        queries = adapter.get_queries()
        assert ":user_id" in queries["accounts"]
        assert ":user_id" in queries["holdings"]
        assert ":user_id" in queries["snapshots"]


# ── Whitebox tests ──────────────────────────────────────────────────

class TestUserIdColFromMapping:
    """Uses the mapped column name, not hardcoded 'user_id'."""

    def test_non_standard_column(self):
        cfg = _make_config(accounts_columns={"id": "id", "type": "type", "balance_current": "balance_current", "user_id": "users_uid"})
        sql = generate_select(cfg.mapping["accounts"], user_id="u1", is_accounts=True)
        assert "users_uid = :user_id" in sql
        assert "user_id = :user_id" not in sql.replace("users_uid = :user_id", "")


class TestMissingUserIdColumnError:
    """Raises clear error if accounts mapping has no user_id column."""

    def test_generate_select_error(self):
        cfg = _make_config(accounts_columns={"id": "id", "type": "type", "balance_current": "balance_current"})
        with pytest.raises(ValueError, match="user_id"):
            generate_select(cfg.mapping["accounts"], user_id="u1", is_accounts=True)

    def test_adapter_construction_error(self):
        cfg = _make_config(accounts_columns={"id": "id", "type": "type", "balance_current": "balance_current"})
        with pytest.raises(ValueError, match="user_id"):
            SqlAdapter(cfg, user_id="u1")


class TestUserIdParameterizedNotInterpolated:
    """SQL injection attempt: user_id value should NOT appear in generated SQL."""

    def test_injection_attempt(self):
        cfg = _make_config()
        sql = generate_select(cfg.mapping["accounts"], user_id="'; DROP TABLE--", is_accounts=True)
        assert "'; DROP TABLE--" not in sql
        assert ":user_id" in sql


class TestSubqueryUsesAccountsTableName:
    """Subquery references the correct accounts table name from config."""

    def test_custom_table_name(self):
        cfg = _make_config(accounts_table="financial_accounts")
        sql = generate_select(
            cfg.mapping["holdings"],
            user_id="u1",
            accounts_mapping=cfg.mapping["accounts"],
        )
        assert "FROM financial_accounts WHERE" in sql


class TestSubqueryUsesAccountsIdColumn:
    """Subquery SELECT uses the correct id column from accounts mapping."""

    def test_custom_id_column(self):
        cfg = _make_config(accounts_columns={"id": "account_uid", "type": "type", "balance_current": "balance_current", "user_id": "user_id"})
        sql = generate_select(
            cfg.mapping["holdings"],
            user_id="u1",
            accounts_mapping=cfg.mapping["accounts"],
        )
        assert "SELECT account_uid FROM" in sql


class TestUserIdNoneSkipsAllFiltering:
    """Explicit user_id=None adds no filtering at all."""

    def test_none_no_filter(self):
        cfg = _make_config()
        for name, mapping in cfg.mapping.items():
            sql = generate_select(mapping, user_id=None)
            assert ":user_id" not in sql


class TestAccountsMappingRequired:
    """When config has no 'accounts' mapping, user_id filtering raises error."""

    def test_no_accounts_mapping_child(self):
        cfg = _make_config()
        with pytest.raises(ValueError, match="accounts mapping"):
            generate_select(cfg.mapping["holdings"], user_id="u1", accounts_mapping=None)

    def test_no_accounts_in_config(self):
        cfg = AuditConfig(
            database=DatabaseConfig(type="sqlite", connection="test.db"),
            mapping={
                "holdings": MappingConfig(table="holdings", columns={"id": "id", "account_id": "account_id"}),
            },
            assertions={},
        )
        with pytest.raises(ValueError, match="accounts"):
            SqlAdapter(cfg, user_id="u1")
