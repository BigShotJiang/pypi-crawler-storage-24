"""Tests for hold-002: Holdings-Account Type Mismatch."""

from __future__ import annotations

from decimal import Decimal

from finlint_audit.assertions.holdings_account_type import assert_holdings_account_type

from .helpers import make_account as _acct, make_ctx as _ctx, make_holding as _hold


# ===========================================================================
# Blackbox tests — correct outputs for known inputs
# ===========================================================================


def test_empty_dataset():
    """No holdings → pass."""
    result = assert_holdings_account_type(_ctx(holdings=[]))
    assert result.status == "pass"
    assert result.assertion_id == "hold-002"
    assert result.evidence == []


def test_holdings_on_investment():
    """3 holdings on investment accounts → pass."""
    accounts = [
        _acct("a1", "investment"),
        _acct("a2", "investment"),
    ]
    holdings = [
        _hold("h1", "a1", 5000, ticker="AAPL"),
        _hold("h2", "a1", 3000, ticker="GOOG"),
        _hold("h3", "a2", 2000, ticker="MSFT"),
    ]
    result = assert_holdings_account_type(_ctx(accounts=accounts, holdings=holdings))
    assert result.status == "pass"
    assert result.evidence == []
    assert result.metadata["mismatch_count"] == "0"


def test_holding_on_depository():
    """Holding refs depository account → fail."""
    accounts = [_acct("a1", "depository")]
    holdings = [_hold("h1", "a1", 5000, ticker="AAPL")]
    result = assert_holdings_account_type(_ctx(accounts=accounts, holdings=holdings))
    assert result.status == "fail"
    assert len(result.evidence) == 1


def test_holding_on_credit():
    """Holding refs credit account → fail."""
    accounts = [_acct("a1", "credit")]
    holdings = [_hold("h1", "a1", 5000, ticker="AAPL")]
    result = assert_holdings_account_type(_ctx(accounts=accounts, holdings=holdings))
    assert result.status == "fail"
    assert len(result.evidence) == 1


def test_holding_on_loan():
    """Holding refs loan account → fail."""
    accounts = [_acct("a1", "loan")]
    holdings = [_hold("h1", "a1", 5000, ticker="AAPL")]
    result = assert_holdings_account_type(_ctx(accounts=accounts, holdings=holdings))
    assert result.status == "fail"
    assert len(result.evidence) == 1


def test_holding_on_other():
    """Holding refs 'other' type account → warn."""
    accounts = [_acct("a1", "other")]
    holdings = [_hold("h1", "a1", 5000, ticker="AAPL")]
    result = assert_holdings_account_type(_ctx(accounts=accounts, holdings=holdings))
    assert result.status == "warn"
    assert len(result.evidence) == 1


def test_multiple_mismatched():
    """3 holdings on wrong account types → fail, 3 evidence."""
    accounts = [
        _acct("a1", "depository"),
        _acct("a2", "credit"),
        _acct("a3", "loan"),
    ]
    holdings = [
        _hold("h1", "a1", 5000, ticker="AAPL"),
        _hold("h2", "a2", 3000, ticker="GOOG"),
        _hold("h3", "a3", 2000, ticker="MSFT"),
    ]
    result = assert_holdings_account_type(_ctx(accounts=accounts, holdings=holdings))
    assert result.status == "fail"
    assert len(result.evidence) == 3


def test_mixed_valid_invalid():
    """5 holdings: 3 on investment, 2 on depository → fail, 2 evidence."""
    accounts = [
        _acct("a1", "investment"),
        _acct("a2", "depository"),
    ]
    holdings = [
        _hold("h1", "a1", 5000, ticker="AAPL"),
        _hold("h2", "a1", 3000, ticker="GOOG"),
        _hold("h3", "a1", 2000, ticker="MSFT"),
        _hold("h4", "a2", 1000, ticker="TSLA"),
        _hold("h5", "a2", 4000, ticker="AMZN"),
    ]
    result = assert_holdings_account_type(_ctx(accounts=accounts, holdings=holdings))
    assert result.status == "fail"
    assert len(result.evidence) == 2


# ===========================================================================
# Whitebox tests — internal behaviour and edge cases
# ===========================================================================


def test_unknown_account_id():
    """Holding refs account not in ctx.accounts → warn."""
    accounts = [_acct("a1", "investment")]
    holdings = [_hold("h1", "a999", 5000, ticker="AAPL")]
    result = assert_holdings_account_type(_ctx(accounts=accounts, holdings=holdings))
    assert result.status == "warn"
    assert "not found" in result.evidence[0].actual


def test_no_accounts_in_context():
    """Holdings exist but ctx.accounts=[] → warn for all."""
    holdings = [
        _hold("h1", "a1", 5000, ticker="AAPL"),
        _hold("h2", "a2", 3000, ticker="GOOG"),
    ]
    result = assert_holdings_account_type(_ctx(accounts=[], holdings=holdings))
    assert result.status == "warn"
    assert len(result.evidence) == 2


def test_inactive_account_still_checked():
    """Holding on inactive depository → still fails."""
    accounts = [_acct("a1", "depository", is_active=False)]
    holdings = [_hold("h1", "a1", 5000, ticker="AAPL")]
    result = assert_holdings_account_type(_ctx(accounts=accounts, holdings=holdings))
    assert result.status == "fail"


def test_evidence_shows_account_type():
    """Holding on credit → evidence.actual contains 'credit'."""
    accounts = [_acct("a1", "credit")]
    holdings = [_hold("h1", "a1", 5000, ticker="AAPL")]
    result = assert_holdings_account_type(_ctx(accounts=accounts, holdings=holdings))
    assert "credit" in result.evidence[0].actual


def test_evidence_includes_ticker():
    """ticker='AAPL' → evidence.field contains 'AAPL'."""
    accounts = [_acct("a1", "depository")]
    holdings = [_hold("h1", "a1", 5000, ticker="AAPL")]
    result = assert_holdings_account_type(_ctx(accounts=accounts, holdings=holdings))
    assert result.evidence[0].field == "AAPL"


def test_evidence_capping():
    """60 mismatched → 51 items (50 + summary)."""
    accounts = [_acct("a1", "depository")]
    holdings = [
        _hold(f"h{i}", "a1", 1000, ticker=f"T{i}")
        for i in range(60)
    ]
    result = assert_holdings_account_type(_ctx(accounts=accounts, holdings=holdings))
    assert result.status == "fail"
    assert len(result.evidence) == 51
    assert result.evidence[-1].field == "(capped)"


def test_metadata_mismatch_count():
    """3 mismatched → metadata['mismatch_count'] == '3'."""
    accounts = [_acct("a1", "depository")]
    holdings = [
        _hold("h1", "a1", 5000, ticker="A"),
        _hold("h2", "a1", 3000, ticker="B"),
        _hold("h3", "a1", 2000, ticker="C"),
    ]
    result = assert_holdings_account_type(_ctx(accounts=accounts, holdings=holdings))
    assert result.metadata["mismatch_count"] == "3"


def test_holding_null_ticker():
    """ticker=None → evidence.field uses holding ID."""
    accounts = [_acct("a1", "depository")]
    holdings = [_hold("h1", "a1", 5000, ticker=None)]
    result = assert_holdings_account_type(_ctx(accounts=accounts, holdings=holdings))
    assert result.evidence[0].field == "holding.id=h1"
