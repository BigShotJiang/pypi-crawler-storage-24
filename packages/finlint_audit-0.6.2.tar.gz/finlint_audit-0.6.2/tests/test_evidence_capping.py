"""Tests for evidence capping across transaction assertions.

Each assertion supports a `max_evidence` param (default 50) via ctx.params.
When evidence exceeds the cap, the list is truncated and a summary item appended.
Metadata always reflects full (uncapped) counts.
"""

from __future__ import annotations

from datetime import datetime, timedelta, timezone

from finlint_audit.assertions.txn_duplicate import assert_txn_duplicate
from finlint_audit.assertions.txn_orphan import assert_txn_orphan
from finlint_audit.assertions.txn_pending_staleness import assert_txn_pending_staleness

from .helpers import make_ctx, make_transaction, make_account

# Aliases
_ctx = make_ctx
_txn = make_transaction
_acct = make_account

# Fixed reference point for deterministic tests
_NOW = datetime(2026, 3, 16, 12, 0, 0, tzinfo=timezone.utc)
_TODAY = _NOW.date()


def _dup_pairs(n: int):
    """Generate n duplicate groups (each a pair of txns with matching fields)."""
    txns = []
    for i in range(n):
        txns.append(_txn(f"t{i}a", f"a{i}", "50.00", "2026-03-01", name="Coffee"))
        txns.append(_txn(f"t{i}b", f"a{i}", "50.00", "2026-03-01", name="Coffee"))
    return txns


def _orphan_txns(n: int, accounts=None):
    """Generate txns referencing n distinct missing account IDs."""
    accts = accounts or [_acct("valid-1", "depository")]
    txns = [
        _txn(f"t{i}", f"missing-{i}", "50.00", "2026-03-01")
        for i in range(n)
    ]
    return accts, txns


def _stale_pending_txns(n: int):
    """Generate n stale pending txns (each 20+i days old)."""
    return [
        _txn(
            f"t{i}",
            "a1",
            "50.00",
            (_TODAY - timedelta(days=20 + i)).isoformat(),
            pending=True,
        )
        for i in range(n)
    ]


class TestEvidenceCapping:
    # ===================================================================
    # txn-001: Duplicate Detection
    # ===================================================================

    def test_duplicate_under_cap(self) -> None:
        """3 duplicate groups, max_evidence=5 → all 3 evidence items."""
        result = assert_txn_duplicate(
            _ctx(transactions=_dup_pairs(3), params={"max_evidence": 5})
        )
        assert result.status == "fail"
        assert len(result.evidence) == 3

    def test_duplicate_at_cap(self) -> None:
        """5 duplicate groups, max_evidence=5 → exactly 5 evidence items (no summary)."""
        result = assert_txn_duplicate(
            _ctx(transactions=_dup_pairs(5), params={"max_evidence": 5})
        )
        assert result.status == "fail"
        assert len(result.evidence) == 5

    def test_duplicate_over_cap(self) -> None:
        """10 duplicate groups, max_evidence=3 → 4 items (3 + 1 summary).
        Summary evidence mentions omitted count. Metadata still shows full count.
        """
        result = assert_txn_duplicate(
            _ctx(transactions=_dup_pairs(10), params={"max_evidence": 3})
        )
        assert result.status == "fail"
        assert len(result.evidence) == 4
        # Summary item
        summary = result.evidence[-1]
        assert "7 more" in summary.actual or "7" in summary.actual
        # Metadata reflects full count
        assert result.metadata["duplicate_group_count"] == "10"

    def test_duplicate_unlimited(self) -> None:
        """10 duplicate groups, max_evidence=0 → all 10 evidence items."""
        result = assert_txn_duplicate(
            _ctx(transactions=_dup_pairs(10), params={"max_evidence": 0})
        )
        assert result.status == "fail"
        assert len(result.evidence) == 10

    def test_duplicate_default_cap(self) -> None:
        """60 duplicate groups, no max_evidence param → 51 items (50 + 1 summary)."""
        result = assert_txn_duplicate(
            _ctx(transactions=_dup_pairs(60))
        )
        assert result.status == "fail"
        assert len(result.evidence) == 51
        summary = result.evidence[-1]
        assert "10 more" in summary.actual or "10" in summary.actual
        assert result.metadata["duplicate_group_count"] == "60"

    # ===================================================================
    # txn-002: Orphan Transactions
    # ===================================================================

    def test_orphan_under_cap(self) -> None:
        """3 orphan account IDs, max_evidence=5 → all 3 evidence items."""
        accts, txns = _orphan_txns(3)
        result = assert_txn_orphan(
            _ctx(accounts=accts, transactions=txns, params={"max_evidence": 5})
        )
        assert result.status == "fail"
        assert len(result.evidence) == 3

    def test_orphan_over_cap(self) -> None:
        """10 orphan account IDs, max_evidence=3 → 4 items (3 + 1 summary).
        Metadata orphan_count still reflects total.
        """
        accts, txns = _orphan_txns(10)
        result = assert_txn_orphan(
            _ctx(accounts=accts, transactions=txns, params={"max_evidence": 3})
        )
        assert result.status == "fail"
        assert len(result.evidence) == 4
        summary = result.evidence[-1]
        assert "7 more" in summary.actual or "7" in summary.actual
        assert result.metadata["orphan_count"] == "10"

    def test_orphan_unlimited(self) -> None:
        """10 orphan account IDs, max_evidence=0 → all 10 evidence items."""
        accts, txns = _orphan_txns(10)
        result = assert_txn_orphan(
            _ctx(accounts=accts, transactions=txns, params={"max_evidence": 0})
        )
        assert result.status == "fail"
        assert len(result.evidence) == 10

    # ===================================================================
    # txn-003: Pending Staleness
    # ===================================================================

    def test_staleness_under_cap(self) -> None:
        """3 stale pending txns, max_evidence=5 → all 3 evidence items."""
        result = assert_txn_pending_staleness(
            _ctx(
                transactions=_stale_pending_txns(3),
                now=_NOW,
                params={"max_evidence": 5},
            )
        )
        assert result.status == "warn"
        assert len(result.evidence) == 3

    def test_staleness_over_cap(self) -> None:
        """10 stale pending txns, max_evidence=3 → 4 items (3 + 1 summary).
        Metadata stale_pending_count still "10".
        """
        result = assert_txn_pending_staleness(
            _ctx(
                transactions=_stale_pending_txns(10),
                now=_NOW,
                params={"max_evidence": 3},
            )
        )
        assert result.status == "warn"
        assert len(result.evidence) == 4
        summary = result.evidence[-1]
        assert "7 more" in summary.actual or "7" in summary.actual
        assert result.metadata["stale_pending_count"] == "10"

    def test_staleness_unlimited(self) -> None:
        """10 stale pending txns, max_evidence=0 → all 10 evidence items."""
        result = assert_txn_pending_staleness(
            _ctx(
                transactions=_stale_pending_txns(10),
                now=_NOW,
                params={"max_evidence": 0},
            )
        )
        assert result.status == "warn"
        assert len(result.evidence) == 10

    # ===================================================================
    # Summary evidence format
    # ===================================================================

    def test_summary_evidence_format(self) -> None:
        """Verify the summary Evidence item has the expected structure."""
        result = assert_txn_duplicate(
            _ctx(transactions=_dup_pairs(10), params={"max_evidence": 3})
        )
        summary = result.evidence[-1]
        assert summary.field == "(capped)"
        assert "max_evidence=3" in summary.expected
        assert "omitted" in summary.actual
