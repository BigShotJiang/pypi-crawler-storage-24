"""Tests for txn-005: Recurring Inflow Detection."""

from datetime import date

from finlint_audit.assertions.txn_recurring_inflow import assert_txn_recurring_inflow
from tests.helpers import make_ctx, make_transaction


class TestTxnRecurringInflow:
    """Blackbox tests for txn-005."""

    def test_empty_transactions(self):
        r = assert_txn_recurring_inflow(make_ctx())
        assert r.status == "skip"
        assert r.assertion_id == "txn-005"

    def test_all_pending_skipped(self):
        r = assert_txn_recurring_inflow(make_ctx(
            transactions=[
                make_transaction("t1", "a1", -1000, "2026-01-15", pending=True),
            ],
        ))
        assert r.status == "skip"

    def test_insufficient_history(self):
        """Less than lookback_days of history → skip."""
        r = assert_txn_recurring_inflow(make_ctx(
            transactions=[
                make_transaction("t1", "a1", -1000, "2026-01-01"),
                make_transaction("t2", "a1", -1000, "2026-01-15"),
            ],
        ))
        assert r.status == "skip"
        assert "Insufficient history" in r.message

    def test_regular_monthly_inflows_pass(self):
        """Monthly inflows over 3+ months → pass."""
        txns = [
            make_transaction("t1", "a1", -3000, "2025-10-15"),
            make_transaction("t2", "a1", -3000, "2025-11-15"),
            make_transaction("t3", "a1", -3000, "2025-12-15"),
            make_transaction("t4", "a1", -3000, "2026-01-15"),
            # Need enough history span
            make_transaction("t5", "a1", 50, "2025-10-01"),
        ]
        r = assert_txn_recurring_inflow(make_ctx(transactions=txns))
        assert r.status == "pass"
        assert int(r.metadata["months_with_inflows"]) >= 3
        assert "estimated_monthly_income" in r.metadata

    def test_biweekly_inflows_pass(self):
        """Biweekly paychecks also detected."""
        txns = [
            make_transaction("t1", "a1", -1500, "2025-10-01"),
            make_transaction("t2", "a1", -1500, "2025-10-15"),
            make_transaction("t3", "a1", -1500, "2025-11-01"),
            make_transaction("t4", "a1", -1500, "2025-11-15"),
            make_transaction("t5", "a1", -1500, "2025-12-01"),
            make_transaction("t6", "a1", -1500, "2025-12-15"),
            make_transaction("t7", "a1", -1500, "2026-01-01"),
            make_transaction("t8", "a1", 50, "2025-10-01"),
        ]
        r = assert_txn_recurring_inflow(make_ctx(transactions=txns))
        assert r.status == "pass"

    def test_irregular_inflows_warn(self):
        """Inflows in only 2 of 3 required months → warn."""
        txns = [
            make_transaction("t1", "a1", -3000, "2025-11-15"),
            make_transaction("t2", "a1", -3000, "2026-01-15"),
            # Outflow to extend history span
            make_transaction("t3", "a1", 50, "2025-10-01"),
        ]
        r = assert_txn_recurring_inflow(make_ctx(transactions=txns))
        assert r.status == "warn"
        assert r.metadata["months_with_inflows"] == "2"

    def test_no_qualifying_inflows_fail(self):
        """Only outflows → fail."""
        txns = [
            make_transaction("t1", "a1", 500, "2025-10-01"),
            make_transaction("t2", "a1", 300, "2025-11-01"),
            make_transaction("t3", "a1", 200, "2025-12-01"),
            make_transaction("t4", "a1", 100, "2026-01-15"),
        ]
        r = assert_txn_recurring_inflow(make_ctx(transactions=txns))
        assert r.status == "fail"
        assert r.metadata["qualifying_inflow_count"] == "0"

    def test_below_min_amount_not_counted(self):
        """Inflows below min_amount ($500) are not qualifying."""
        txns = [
            make_transaction("t1", "a1", -100, "2025-10-15"),
            make_transaction("t2", "a1", -100, "2025-11-15"),
            make_transaction("t3", "a1", -100, "2025-12-15"),
            make_transaction("t4", "a1", -100, "2026-01-15"),
            make_transaction("t5", "a1", 50, "2025-10-01"),
        ]
        r = assert_txn_recurring_inflow(make_ctx(transactions=txns))
        assert r.status == "fail"

    def test_pending_excluded(self):
        """Pending transactions are excluded from analysis."""
        txns = [
            make_transaction("t1", "a1", -3000, "2025-12-15"),
            make_transaction("t2", "a1", -3000, "2026-01-15"),
            make_transaction("t3", "a1", -3000, "2026-02-15", pending=True),
            make_transaction("t4", "a1", -3000, "2026-03-15", pending=True),
            # Non-pending outflow to extend history
            make_transaction("t5", "a1", 50, "2025-09-01"),
        ]
        r = assert_txn_recurring_inflow(make_ctx(transactions=txns))
        # Only 2 non-pending months with qualifying inflows
        assert r.status == "warn"

    def test_custom_params(self):
        """Custom lookback_days, min_occurrences, min_amount."""
        txns = [
            make_transaction("t1", "a1", -200, "2025-12-15"),
            make_transaction("t2", "a1", -200, "2026-01-15"),
            make_transaction("t3", "a1", 50, "2025-12-01"),
        ]
        r = assert_txn_recurring_inflow(make_ctx(
            transactions=txns,
            params={
                "lookback_days": "45",
                "min_occurrences": "2",
                "min_amount": "100",
            },
        ))
        assert r.status == "pass"

    def test_plaid_sign_convention(self):
        """Negative amounts are inflows per Plaid convention."""
        txns = [
            # Negative = money coming in
            make_transaction("t1", "a1", -3000, "2025-12-15"),
            make_transaction("t2", "a1", -3000, "2026-01-15"),
            make_transaction("t3", "a1", -3000, "2026-02-15"),
            # Positive = money going out (not an inflow)
            make_transaction("t4", "a1", 3000, "2026-03-01"),
            # Extend history span
            make_transaction("t5", "a1", 50, "2025-09-01"),
        ]
        r = assert_txn_recurring_inflow(make_ctx(transactions=txns))
        assert r.status == "pass"
        assert r.metadata["months_with_inflows"] == "3"

    def test_metadata_has_estimated_income(self):
        txns = [
            make_transaction("t1", "a1", -3000, "2025-10-15"),
            make_transaction("t2", "a1", -3000, "2025-11-15"),
            make_transaction("t3", "a1", -3000, "2025-12-15"),
            make_transaction("t4", "a1", -3000, "2026-01-15"),
            make_transaction("t5", "a1", 50, "2025-10-01"),
        ]
        r = assert_txn_recurring_inflow(make_ctx(transactions=txns))
        assert r.status == "pass"
        income = r.metadata["estimated_monthly_income"]
        assert income == "3000.00"

    def test_evidence_on_fail(self):
        txns = [
            make_transaction("t1", "a1", 500, "2025-10-01"),
            make_transaction("t2", "a1", 300, "2025-11-01"),
            make_transaction("t3", "a1", 200, "2025-12-01"),
            make_transaction("t4", "a1", 100, "2026-01-15"),
        ]
        r = assert_txn_recurring_inflow(make_ctx(transactions=txns))
        assert r.status == "fail"
        assert len(r.evidence) == 1
        assert "transactions" in r.evidence[0].field
