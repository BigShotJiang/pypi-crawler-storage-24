"""TDD tests for liability-account mismatch assertion (liab-001)."""

from finlint_audit.assertions.liability_mismatch import assert_liability_mismatch

from tests.helpers import make_ctx as _ctx, make_account as _acct, make_liability as _liab


# -- Blackbox tests --------------------------------------------------------


class TestLiabilityMismatchBlackbox:
    def test_empty_dataset(self) -> None:
        """Nothing provided -> pass."""
        result = assert_liability_mismatch(_ctx())
        assert result.status == "pass"
        assert result.assertion_id == "liab-001"

    def test_credit_with_liability(self) -> None:
        """Credit account with matching liability -> pass."""
        result = assert_liability_mismatch(
            _ctx(
                accounts=[_acct("a1", "credit", balance=-500)],
                liabilities=[_liab("l1", "a1", type="credit")],
            )
        )
        assert result.status == "pass"

    def test_loan_with_liability(self) -> None:
        """Loan account with matching liability -> pass."""
        result = assert_liability_mismatch(
            _ctx(
                accounts=[_acct("a1", "loan", balance=-10000)],
                liabilities=[_liab("l1", "a1", type="student")],
            )
        )
        assert result.status == "pass"

    def test_credit_without_liability(self) -> None:
        """Credit account with no liabilities -> fail."""
        result = assert_liability_mismatch(
            _ctx(accounts=[_acct("a1", "credit", balance=-500)])
        )
        assert result.status == "fail"
        assert len(result.evidence) >= 1
        assert "account.id=a1" in result.evidence[0].field

    def test_loan_without_liability(self) -> None:
        """Loan account with no liabilities -> fail."""
        result = assert_liability_mismatch(
            _ctx(accounts=[_acct("a1", "loan", balance=-20000)])
        )
        assert result.status == "fail"
        assert len(result.evidence) >= 1

    def test_orphan_liability(self) -> None:
        """Liability references non-existent account -> fail."""
        result = assert_liability_mismatch(
            _ctx(liabilities=[_liab("l1", "no-such-account", type="credit")])
        )
        assert result.status == "fail"
        assert "not found" in result.evidence[0].actual

    def test_liability_on_depository(self) -> None:
        """Liability on depository account -> warn (wrong type)."""
        result = assert_liability_mismatch(
            _ctx(
                accounts=[_acct("a1", "depository", balance=5000)],
                liabilities=[_liab("l1", "a1", type="credit")],
            )
        )
        assert result.status == "warn"
        assert "depository" in result.evidence[0].actual

    def test_depository_without_liability(self) -> None:
        """Depository account with no liabilities -> pass (not a liability type)."""
        result = assert_liability_mismatch(
            _ctx(accounts=[_acct("a1", "depository", balance=5000)])
        )
        assert result.status == "pass"

    def test_investment_without_liability(self) -> None:
        """Investment account with no liabilities -> pass (not a liability type)."""
        result = assert_liability_mismatch(
            _ctx(accounts=[_acct("a1", "investment", balance=50000)])
        )
        assert result.status == "pass"

    def test_multiple_issues(self) -> None:
        """1 missing liability + 1 orphan liability -> fail, 2 evidence items."""
        result = assert_liability_mismatch(
            _ctx(
                accounts=[_acct("a1", "credit", balance=-500)],
                liabilities=[_liab("l1", "no-such-account", type="credit")],
            )
        )
        assert result.status == "fail"
        assert len(result.evidence) == 2


# -- Whitebox tests --------------------------------------------------------


class TestLiabilityMismatchWhitebox:
    def test_inactive_credit_skipped(self) -> None:
        """Inactive credit account is not checked for missing liability."""
        result = assert_liability_mismatch(
            _ctx(accounts=[_acct("a1", "credit", balance=-500, is_active=False)])
        )
        assert result.status == "pass"

    def test_liability_refs_inactive_depository(self) -> None:
        """Liability referencing inactive depository -> warn (wrong type, not orphan)."""
        result = assert_liability_mismatch(
            _ctx(
                accounts=[_acct("a1", "depository", balance=1000, is_active=False)],
                liabilities=[_liab("l1", "a1", type="credit")],
            )
        )
        assert result.status == "warn"
        assert "depository" in result.evidence[0].actual

    def test_multiple_liabilities_per_account(self) -> None:
        """Credit account with 2 liabilities -> pass."""
        result = assert_liability_mismatch(
            _ctx(
                accounts=[_acct("a1", "credit", balance=-1000)],
                liabilities=[
                    _liab("l1", "a1", type="credit"),
                    _liab("l2", "a1", type="credit"),
                ],
            )
        )
        assert result.status == "pass"

    def test_bidirectional_both_fail(self) -> None:
        """Credit without liability + orphan liability -> both in evidence."""
        result = assert_liability_mismatch(
            _ctx(
                accounts=[_acct("a1", "credit", balance=-500)],
                liabilities=[_liab("l1", "ghost", type="credit")],
            )
        )
        assert result.status == "fail"
        fields = [e.field for e in result.evidence]
        assert any("account." in f for f in fields)
        assert any("liability." in f for f in fields)

    def test_metadata_counts(self) -> None:
        """2 missing + 1 orphan -> metadata has correct counts."""
        result = assert_liability_mismatch(
            _ctx(
                accounts=[
                    _acct("a1", "credit", balance=-500),
                    _acct("a2", "loan", balance=-10000),
                ],
                liabilities=[_liab("l1", "ghost", type="credit")],
            )
        )
        assert result.status == "fail"
        assert result.metadata["missing_liability_count"] == "2"
        assert result.metadata["orphan_liability_count"] == "1"

    def test_evidence_direction_label(self) -> None:
        """Missing -> field starts with 'account.', orphan -> 'liability.'."""
        result = assert_liability_mismatch(
            _ctx(
                accounts=[_acct("a1", "credit", balance=-500)],
                liabilities=[_liab("l1", "ghost", type="credit")],
            )
        )
        account_evidence = [e for e in result.evidence if e.field.startswith("account.")]
        liability_evidence = [e for e in result.evidence if e.field.startswith("liability.")]
        assert len(account_evidence) == 1
        assert len(liability_evidence) == 1

    def test_liability_type_credit(self) -> None:
        """liability.type='credit' on credit account -> pass."""
        result = assert_liability_mismatch(
            _ctx(
                accounts=[_acct("a1", "credit", balance=-500)],
                liabilities=[_liab("l1", "a1", type="credit")],
            )
        )
        assert result.status == "pass"

    def test_liability_type_student(self) -> None:
        """liability.type='student' on loan account -> pass."""
        result = assert_liability_mismatch(
            _ctx(
                accounts=[_acct("a1", "loan", balance=-25000)],
                liabilities=[_liab("l1", "a1", type="student")],
            )
        )
        assert result.status == "pass"
