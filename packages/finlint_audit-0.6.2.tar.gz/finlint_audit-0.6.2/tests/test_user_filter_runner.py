"""Runner integration tests for per-user filtering."""

from __future__ import annotations

from decimal import Decimal

from finlint_audit.adapters.memory import MemoryAdapter
from finlint_audit.runner import AuditRunner
from tests.helpers import (
    make_account,
    make_holding,
    make_liability,
    make_snapshot,
    make_transaction,
)


def _build_adapter(user_id: str | None = None) -> MemoryAdapter:
    """Build adapter with u1=clean data, u2=dirty data (sign-001 fail)."""
    return MemoryAdapter(
        accounts=[
            # u1: clean — depository + investment (holdings match) + credit (has liability)
            make_account("a1", "depository", balance=15000, user_id="u1", institution_name="Chase", mask="4521"),
            make_account("a2", "investment", balance=70000, user_id="u1", institution_name="Fidelity", mask="8832"),
            make_account("a3", "credit", balance=2500, user_id="u1", institution_name="Chase", mask="1234"),
            # u2: dirty — credit with negative balance (sign-001 fail), depository overlap with u1
            make_account("a4", "credit", balance=-500, user_id="u2", institution_name="BadBank", mask="9999"),
            make_account("a5", "depository", balance=15000, user_id="u2", institution_name="Chase", mask="4521"),
        ],
        holdings=[
            make_holding("h1", "a2", 50000, ticker="VTI"),
            make_holding("h2", "a2", 20000, ticker="VXUS"),
        ],
        liabilities=[
            make_liability("l1", "a3", "credit", current_balance=Decimal("2500")),
        ],
        snapshots=[
            make_snapshot("s1", "a1", 15000, "2026-03-15T12:00:00"),
            make_snapshot("s2", "a2", 70000, "2026-03-15T12:00:00"),
            make_snapshot("s3", "a3", 2500, "2026-03-15T12:00:00"),
            make_snapshot("s4", "a4", -500, "2026-03-15T12:00:00"),
            make_snapshot("s5", "a5", 15000, "2026-03-15T12:00:00"),
        ],
        transactions=[
            make_transaction("t1", "a1", 50, "2026-03-10", name="Coffee"),
            make_transaction("t2", "a3", 45, "2026-03-12", name="Gas"),
            make_transaction("t3", "a4", 25, "2026-03-13", name="Store"),
        ],
        user_id=user_id,
    )


class TestRunnerWithUserIdAllPass:
    def test_u1_all_pass(self):
        adapter = _build_adapter(user_id="u1")
        runner = AuditRunner(adapter=adapter)
        results = runner.run()
        assert len(results) == 23
        for r in results:
            assert r.status in ("pass", "warn", "skip"), f"{r.assertion_id} unexpectedly {r.status}: {r.message}"


class TestRunnerWithoutUserIdSeesFailures:
    def test_unfiltered_has_failures(self):
        adapter = _build_adapter(user_id=None)
        runner = AuditRunner(adapter=adapter)
        results = runner.run()
        statuses = {r.assertion_id: r.status for r in results}
        # sign-001 should fail due to u2's negative credit balance
        assert statuses["sign-001"] == "fail"


class TestRunnerUserIdU2SeesFailures:
    def test_u2_sign_fail(self):
        adapter = _build_adapter(user_id="u2")
        runner = AuditRunner(adapter=adapter)
        results = runner.run()
        statuses = {r.assertion_id: r.status for r in results}
        assert statuses["sign-001"] == "fail"


class TestRunnerUserIdPlusOnly:
    def test_combined(self):
        adapter = _build_adapter(user_id="u1")
        runner = AuditRunner(adapter=adapter, only={"nw-001"})
        results = runner.run()
        assert len(results) == 1
        assert results[0].assertion_id == "nw-001"
        assert results[0].status == "pass"


class TestRunnerUserIdPlusDisabled:
    def test_combined(self):
        adapter = _build_adapter(user_id="u1")
        runner = AuditRunner(adapter=adapter, disabled={"nw-001"})
        results = runner.run()
        assert len(results) == 22
        assert all(r.assertion_id != "nw-001" for r in results)


class TestRunnerNonexistentUser:
    def test_nobody_all_pass(self):
        adapter = _build_adapter(user_id="nobody")
        runner = AuditRunner(adapter=adapter)
        results = runner.run()
        assert len(results) == 23
        # No data = all pass/skip, except data-001 which fails on empty accounts
        for r in results:
            if r.assertion_id == "data-001":
                assert r.status == "fail"
            else:
                assert r.status in ("pass", "warn", "skip"), f"{r.assertion_id} unexpectedly {r.status}"
