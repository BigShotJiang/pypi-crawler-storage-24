"""Tests for fresh-001: Data Freshness."""

from datetime import datetime, timezone

from finlint_audit.assertions.data_freshness import assert_data_freshness
from tests.helpers import make_account, make_ctx


class TestDataFreshness:
    """Blackbox tests for fresh-001."""

    def test_empty_accounts(self):
        r = assert_data_freshness(make_ctx())
        assert r.status == "pass"
        assert r.assertion_id == "fresh-001"

    def test_all_fresh_pass(self):
        now = datetime(2026, 3, 18, tzinfo=timezone.utc)
        r = assert_data_freshness(make_ctx(
            accounts=[
                make_account(
                    "a1", "depository", 5000,
                    last_updated=datetime(2026, 3, 17, tzinfo=timezone.utc),
                ),
            ],
            now=now,
        ))
        assert r.status == "pass"
        assert r.metadata["stale_count"] == "0"
        assert r.metadata["error_count"] == "0"

    def test_stale_warning(self):
        """4 days old > 3 day warning threshold."""
        now = datetime(2026, 3, 18, tzinfo=timezone.utc)
        r = assert_data_freshness(make_ctx(
            accounts=[
                make_account(
                    "a1", "depository", 5000,
                    last_updated=datetime(2026, 3, 14, tzinfo=timezone.utc),
                ),
            ],
            now=now,
        ))
        assert r.status == "warn"
        assert r.metadata["stale_count"] == "1"

    def test_stale_error(self):
        """10 days old > 7 day error threshold."""
        now = datetime(2026, 3, 18, tzinfo=timezone.utc)
        r = assert_data_freshness(make_ctx(
            accounts=[
                make_account(
                    "a1", "depository", 5000,
                    last_updated=datetime(2026, 3, 8, tzinfo=timezone.utc),
                ),
            ],
            now=now,
        ))
        assert r.status == "fail"
        assert r.metadata["error_count"] == "1"

    def test_mixed_worst_wins(self):
        """One warning + one error → fail status."""
        now = datetime(2026, 3, 18, tzinfo=timezone.utc)
        r = assert_data_freshness(make_ctx(
            accounts=[
                make_account(
                    "a1", "depository", 5000,
                    last_updated=datetime(2026, 3, 14, tzinfo=timezone.utc),
                ),
                make_account(
                    "a2", "investment", 10000,
                    last_updated=datetime(2026, 3, 1, tzinfo=timezone.utc),
                ),
            ],
            now=now,
        ))
        assert r.status == "fail"
        assert r.metadata["stale_count"] == "1"
        assert r.metadata["error_count"] == "1"

    def test_all_none_skip(self):
        """No accounts have last_updated → skip."""
        r = assert_data_freshness(make_ctx(
            accounts=[
                make_account("a1", "depository", 5000),
                make_account("a2", "investment", 10000),
            ],
        ))
        assert r.status == "skip"

    def test_custom_thresholds(self):
        now = datetime(2026, 3, 18, tzinfo=timezone.utc)
        r = assert_data_freshness(make_ctx(
            accounts=[
                make_account(
                    "a1", "depository", 5000,
                    last_updated=datetime(2026, 3, 14, tzinfo=timezone.utc),
                ),
            ],
            params={"warning_days": "7", "error_days": "14"},
            now=now,
        ))
        assert r.status == "pass"

    def test_inactive_skipped(self):
        now = datetime(2026, 3, 18, tzinfo=timezone.utc)
        r = assert_data_freshness(make_ctx(
            accounts=[
                make_account(
                    "a1", "depository", 5000,
                    is_active=False,
                    last_updated=datetime(2026, 1, 1, tzinfo=timezone.utc),
                ),
            ],
            now=now,
        ))
        assert r.status == "pass"
        assert "No active accounts" in r.message

    def test_timezone_aware_comparison(self):
        """Timezone-aware last_updated works correctly."""
        now = datetime(2026, 3, 18, 12, 0, tzinfo=timezone.utc)
        r = assert_data_freshness(make_ctx(
            accounts=[
                make_account(
                    "a1", "depository", 5000,
                    last_updated=datetime(2026, 3, 17, 12, 0, tzinfo=timezone.utc),
                ),
            ],
            now=now,
        ))
        assert r.status == "pass"

    def test_naive_datetime_handled(self):
        """Naive datetimes are treated as UTC."""
        now = datetime(2026, 3, 18, 12, 0)
        r = assert_data_freshness(make_ctx(
            accounts=[
                make_account(
                    "a1", "depository", 5000,
                    last_updated=datetime(2026, 3, 17, 12, 0),
                ),
            ],
            now=now,
        ))
        assert r.status == "pass"

    def test_ctx_now_respected(self):
        """Uses ctx.now, not real clock."""
        now = datetime(2026, 6, 1, tzinfo=timezone.utc)
        r = assert_data_freshness(make_ctx(
            accounts=[
                make_account(
                    "a1", "depository", 5000,
                    last_updated=datetime(2026, 3, 1, tzinfo=timezone.utc),
                ),
            ],
            now=now,
        ))
        assert r.status == "fail"

    def test_boundary_warning_days(self):
        """Exactly 3 days should NOT warn (> not >=)."""
        now = datetime(2026, 3, 18, tzinfo=timezone.utc)
        r = assert_data_freshness(make_ctx(
            accounts=[
                make_account(
                    "a1", "depository", 5000,
                    last_updated=datetime(2026, 3, 15, tzinfo=timezone.utc),
                ),
            ],
            now=now,
        ))
        assert r.status == "pass"

    def test_boundary_error_days(self):
        """Exactly 7 days should NOT fail (> not >=)."""
        now = datetime(2026, 3, 18, tzinfo=timezone.utc)
        r = assert_data_freshness(make_ctx(
            accounts=[
                make_account(
                    "a1", "depository", 5000,
                    last_updated=datetime(2026, 3, 11, tzinfo=timezone.utc),
                ),
            ],
            now=now,
        ))
        assert r.status == "warn"  # warn, not fail

    def test_evidence_format(self):
        now = datetime(2026, 3, 18, tzinfo=timezone.utc)
        r = assert_data_freshness(make_ctx(
            accounts=[
                make_account(
                    "a1", "depository", 5000,
                    last_updated=datetime(2026, 3, 1, tzinfo=timezone.utc),
                ),
            ],
            now=now,
        ))
        assert r.evidence[0].field == "account.id=a1"
        assert "days ago" in r.evidence[0].actual

    def test_multiple_some_fresh_some_stale(self):
        now = datetime(2026, 3, 18, tzinfo=timezone.utc)
        r = assert_data_freshness(make_ctx(
            accounts=[
                make_account(
                    "a1", "depository", 5000,
                    last_updated=datetime(2026, 3, 17, tzinfo=timezone.utc),
                ),
                make_account(
                    "a2", "investment", 10000,
                    last_updated=datetime(2026, 3, 14, tzinfo=timezone.utc),
                ),
                make_account(
                    "a3", "credit", 2000,
                    last_updated=datetime(2026, 3, 16, tzinfo=timezone.utc),
                ),
            ],
            now=now,
        ))
        assert r.status == "warn"
        assert r.metadata["stale_count"] == "1"
