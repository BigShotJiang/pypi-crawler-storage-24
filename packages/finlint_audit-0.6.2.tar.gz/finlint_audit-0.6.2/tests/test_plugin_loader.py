"""Plugin loader tests — dynamic import and signature validation."""

from __future__ import annotations

import sys
import warnings
from pathlib import Path

import pytest

from finlint_audit.config import PluginConfig
from finlint_audit.plugins import PluginLoadError, load_plugin

# Ensure test fixtures are importable
_FIXTURES_DIR = Path(__file__).parent / "fixtures"
if str(_FIXTURES_DIR.parent) not in sys.path:
    sys.path.insert(0, str(_FIXTURES_DIR.parent))


def _plugin(module: str = "fixtures.sample_plugin", function: str = "assert_sample", **kw) -> PluginConfig:
    return PluginConfig(id=kw.pop("id", "test-001"), module=module, function=function, **kw)


# ── Blackbox tests ──────────────────────────────────────────────────

class TestLoadValidPlugin:
    def test_returns_id_and_callable(self):
        pid, fn = load_plugin(_plugin())
        assert pid == "test-001"
        assert callable(fn)


class TestLoadedFunctionCallable:
    def test_end_to_end(self):
        _, fn = load_plugin(_plugin())
        from tests.helpers import make_ctx
        result = fn(make_ctx())
        assert result.status == "pass"
        assert result.assertion_id == "sample-001"


class TestLoadMissingModule:
    def test_raises(self):
        with pytest.raises(PluginLoadError, match="cannot import"):
            load_plugin(_plugin(module="nonexistent.module"))


class TestLoadMissingFunction:
    def test_raises(self):
        with pytest.raises(PluginLoadError, match="has no attribute"):
            load_plugin(_plugin(function="nonexistent_fn"))


class TestLoadNonCallable:
    def test_raises(self):
        with pytest.raises(PluginLoadError, match="not callable"):
            load_plugin(_plugin(module="fixtures.non_callable_plugin", function="assert_not_callable"))


class TestLoadWrongSignatureNoParams:
    def test_raises(self):
        with pytest.raises(PluginLoadError, match="0"):
            load_plugin(_plugin(module="fixtures.bad_signature_plugin", function="assert_bad"))


class TestLoadWrongSignatureTooManyParams:
    def test_raises(self):
        # Create an inline module with 3 required params
        import types
        mod = types.ModuleType("too_many_params_mod")
        exec("def bad_fn(a, b, c): pass", mod.__dict__)
        sys.modules["too_many_params_mod"] = mod
        try:
            with pytest.raises(PluginLoadError, match="3 required"):
                load_plugin(_plugin(module="too_many_params_mod", function="bad_fn"))
        finally:
            del sys.modules["too_many_params_mod"]


class TestPluginLoadErrorIncludesId:
    def test_id_in_message(self):
        with pytest.raises(PluginLoadError, match="myplug-001"):
            load_plugin(_plugin(id="myplug-001", module="nonexistent.mod"))


# ── Whitebox tests ──────────────────────────────────────────────────

class TestSignatureOptionalSecondParam:
    def test_allowed(self):
        import types
        mod = types.ModuleType("opt_mod")
        exec("def fn(ctx, debug=False): pass", mod.__dict__)
        sys.modules["opt_mod"] = mod
        try:
            pid, fn = load_plugin(_plugin(module="opt_mod", function="fn"))
            assert callable(fn)
        finally:
            del sys.modules["opt_mod"]


class TestSignatureWithKwargsOk:
    def test_allowed(self):
        import types
        mod = types.ModuleType("kwargs_mod")
        exec("def fn(ctx, **kwargs): pass", mod.__dict__)
        sys.modules["kwargs_mod"] = mod
        try:
            _, fn = load_plugin(_plugin(module="kwargs_mod", function="fn"))
            assert callable(fn)
        finally:
            del sys.modules["kwargs_mod"]


class TestSignatureOnlyKwargsRejected:
    def test_rejected(self):
        import types
        mod = types.ModuleType("only_kwargs_mod")
        exec("def fn(**kwargs): pass", mod.__dict__)
        sys.modules["only_kwargs_mod"] = mod
        try:
            with pytest.raises(PluginLoadError, match="0"):
                load_plugin(_plugin(module="only_kwargs_mod", function="fn"))
        finally:
            del sys.modules["only_kwargs_mod"]


class TestSignatureWithOnlyArgsOk:
    def test_allowed(self):
        import types
        mod = types.ModuleType("args_mod")
        exec("def fn(*args): pass", mod.__dict__)
        sys.modules["args_mod"] = mod
        try:
            _, fn = load_plugin(_plugin(module="args_mod", function="fn"))
            assert callable(fn)
        finally:
            del sys.modules["args_mod"]


class TestReturnTypeAnnotationWrongTypeWarned:
    def test_warning(self):
        import types
        mod = types.ModuleType("wrong_ret_mod")
        exec("def fn(ctx) -> str: pass", mod.__dict__)
        sys.modules["wrong_ret_mod"] = mod
        try:
            with warnings.catch_warnings(record=True) as w:
                warnings.simplefilter("always")
                load_plugin(_plugin(module="wrong_ret_mod", function="fn"))
                assert len(w) == 1
                assert "return type" in str(w[0].message)
        finally:
            del sys.modules["wrong_ret_mod"]


class TestNoReturnTypeAnnotationOk:
    def test_no_warning(self):
        # sample_plugin has no return annotation
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            load_plugin(_plugin())
            assert len(w) == 0


class TestCallableClassAccepted:
    def test_class_with_call(self):
        import types
        mod = types.ModuleType("class_mod")
        exec("""
class MyChecker:
    def __call__(self, ctx):
        pass
checker = MyChecker()
""", mod.__dict__)
        sys.modules["class_mod"] = mod
        try:
            _, fn = load_plugin(_plugin(module="class_mod", function="checker"))
            assert callable(fn)
        finally:
            del sys.modules["class_mod"]


class TestLambdaAccepted:
    def test_lambda(self):
        import types
        from finlint_audit.result import AssertionResult
        mod = types.ModuleType("lambda_mod")
        mod.assert_lambda = lambda ctx: AssertionResult(
            assertion_id="lam-001", name="Lambda", status="pass",
            message="ok", evidence=[], metadata={},
        )
        sys.modules["lambda_mod"] = mod
        try:
            _, fn = load_plugin(_plugin(module="lambda_mod", function="assert_lambda"))
            assert callable(fn)
        finally:
            del sys.modules["lambda_mod"]


class TestModulePathRelativeImport:
    def test_dotted_path(self):
        # fixtures.sample_plugin is a relative import via dotted path
        _, fn = load_plugin(_plugin(module="fixtures.sample_plugin", function="assert_sample"))
        assert callable(fn)
