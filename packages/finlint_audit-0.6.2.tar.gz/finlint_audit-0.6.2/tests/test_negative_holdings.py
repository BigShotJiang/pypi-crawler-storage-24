"""Tests for hold-001: Negative Holdings Detection."""

from __future__ import annotations

from decimal import Decimal

from finlint_audit.assertions.negative_holdings import assert_negative_holdings

from .helpers import make_ctx, make_holding

# Aliases
_ctx = make_ctx
_hold = make_holding


# ===========================================================================
# Blackbox tests — correct outputs for known inputs
# ===========================================================================


def test_empty_dataset():
    """No holdings → pass."""
    result = assert_negative_holdings(_ctx(holdings=[]))
    assert result.status == "pass"
    assert result.assertion_id == "hold-001"
    assert result.evidence == []


def test_all_positive():
    """3 holdings, all positive qty and value → pass."""
    holdings = [
        _hold("h1", "a1", 5000, quantity=Decimal("10"), ticker="AAPL"),
        _hold("h2", "a1", 3000, quantity=Decimal("20"), ticker="GOOG"),
        _hold("h3", "a1", 2000, quantity=Decimal("5"), ticker="MSFT"),
    ]
    result = assert_negative_holdings(_ctx(holdings=holdings))
    assert result.status == "pass"
    assert len(result.evidence) == 0


def test_negative_quantity():
    """quantity=-10, value=$5000 → fail."""
    holdings = [
        _hold("h1", "a1", 5000, quantity=Decimal("-10"), ticker="AAPL"),
    ]
    result = assert_negative_holdings(_ctx(holdings=holdings))
    assert result.status == "fail"
    assert len(result.evidence) == 1
    assert "quantity=" in result.evidence[0].actual
    assert "institution_value" not in result.evidence[0].actual


def test_negative_institution_value():
    """quantity=10, value=-$5000 → fail."""
    holdings = [
        _hold("h1", "a1", -5000, quantity=Decimal("10"), ticker="AAPL"),
    ]
    result = assert_negative_holdings(_ctx(holdings=holdings))
    assert result.status == "fail"
    assert len(result.evidence) == 1
    assert "institution_value=" in result.evidence[0].actual
    assert "quantity=" not in result.evidence[0].actual


def test_both_negative():
    """quantity=-10, value=-$5000 → fail, 1 evidence (single holding)."""
    holdings = [
        _hold("h1", "a1", -5000, quantity=Decimal("-10"), ticker="AAPL"),
    ]
    result = assert_negative_holdings(_ctx(holdings=holdings))
    assert result.status == "fail"
    assert len(result.evidence) == 1
    assert "quantity=" in result.evidence[0].actual
    assert "institution_value=" in result.evidence[0].actual


def test_zero_quantity():
    """quantity=0, value=$0 → pass."""
    holdings = [
        _hold("h1", "a1", 0, quantity=Decimal("0"), ticker="AAPL"),
    ]
    result = assert_negative_holdings(_ctx(holdings=holdings))
    assert result.status == "pass"


def test_multiple_negative():
    """3 negative holdings → fail, 3 evidence."""
    holdings = [
        _hold("h1", "a1", -1000, quantity=Decimal("-5"), ticker="AAPL"),
        _hold("h2", "a1", -2000, quantity=Decimal("-10"), ticker="GOOG"),
        _hold("h3", "a1", -3000, quantity=Decimal("-15"), ticker="MSFT"),
    ]
    result = assert_negative_holdings(_ctx(holdings=holdings))
    assert result.status == "fail"
    assert len(result.evidence) == 3


def test_mixed_positive_negative():
    """5 holdings: 3 positive, 2 negative → fail, 2 evidence."""
    holdings = [
        _hold("h1", "a1", 5000, quantity=Decimal("10"), ticker="AAPL"),
        _hold("h2", "a1", -2000, quantity=Decimal("-10"), ticker="GOOG"),
        _hold("h3", "a1", 3000, quantity=Decimal("5"), ticker="MSFT"),
        _hold("h4", "a1", -1000, quantity=Decimal("-3"), ticker="TSLA"),
        _hold("h5", "a1", 4000, quantity=Decimal("20"), ticker="AMZN"),
    ]
    result = assert_negative_holdings(_ctx(holdings=holdings))
    assert result.status == "fail"
    assert len(result.evidence) == 2


# ===========================================================================
# Whitebox tests — internal behaviour and edge cases
# ===========================================================================


def test_negative_cost_basis_allowed():
    """cost_basis=-$2000, qty/value positive → pass (cost_basis not checked)."""
    holdings = [
        _hold(
            "h1", "a1", 5000,
            quantity=Decimal("10"),
            ticker="AAPL",
            cost_basis=Decimal("-2000"),
        ),
    ]
    result = assert_negative_holdings(_ctx(holdings=holdings))
    assert result.status == "pass"


def test_very_small_negative():
    """quantity=Decimal('-0.0001') → fail."""
    holdings = [
        _hold("h1", "a1", 5000, quantity=Decimal("-0.0001"), ticker="AAPL"),
    ]
    result = assert_negative_holdings(_ctx(holdings=holdings))
    assert result.status == "fail"
    assert len(result.evidence) == 1


def test_ticker_in_evidence():
    """ticker='AAPL' → evidence.field contains 'AAPL'."""
    holdings = [
        _hold("h1", "a1", -5000, quantity=Decimal("10"), ticker="AAPL"),
    ]
    result = assert_negative_holdings(_ctx(holdings=holdings))
    assert result.evidence[0].field == "AAPL"


def test_null_ticker_in_evidence():
    """ticker=None → evidence.field shows holding ID."""
    holdings = [
        _hold("h1", "a1", -5000, quantity=Decimal("10"), ticker=None),
    ]
    result = assert_negative_holdings(_ctx(holdings=holdings))
    assert result.evidence[0].field == "holding.id=h1"


def test_evidence_capping():
    """60 negative holdings → 51 items (50 + summary)."""
    holdings = [
        _hold(f"h{i}", "a1", 1000, quantity=Decimal("-1"), ticker=f"T{i}")
        for i in range(60)
    ]
    result = assert_negative_holdings(_ctx(holdings=holdings))
    assert result.status == "fail"
    assert len(result.evidence) == 51
    assert result.evidence[-1].field == "(capped)"
    assert result.metadata["negative_count"] == "60"


def test_metadata_negative_count():
    """3 negative → metadata['negative_count'] == '3'."""
    holdings = [
        _hold("h1", "a1", -1000, quantity=Decimal("-5"), ticker="A"),
        _hold("h2", "a1", -2000, quantity=Decimal("-10"), ticker="B"),
        _hold("h3", "a1", -3000, quantity=Decimal("-15"), ticker="C"),
    ]
    result = assert_negative_holdings(_ctx(holdings=holdings))
    assert result.metadata["negative_count"] == "3"


def test_evidence_distinguishes_qty_vs_value():
    """One neg qty, one neg value → different actual text."""
    holdings = [
        _hold("h1", "a1", 5000, quantity=Decimal("-10"), ticker="A"),
        _hold("h2", "a1", -5000, quantity=Decimal("10"), ticker="B"),
    ]
    result = assert_negative_holdings(_ctx(holdings=holdings))
    assert result.status == "fail"
    assert len(result.evidence) == 2
    actuals = {e.field: e.actual for e in result.evidence}
    assert "quantity=" in actuals["A"]
    assert "institution_value=" not in actuals["A"]
    assert "institution_value=" in actuals["B"]
    assert "quantity=" not in actuals["B"]


def test_negative_quantity_zero_value():
    """quantity=-5, value=$0 → fail."""
    holdings = [
        _hold("h1", "a1", 0, quantity=Decimal("-5"), ticker="AAPL"),
    ]
    result = assert_negative_holdings(_ctx(holdings=holdings))
    assert result.status == "fail"
    assert len(result.evidence) == 1
    assert "quantity=" in result.evidence[0].actual
