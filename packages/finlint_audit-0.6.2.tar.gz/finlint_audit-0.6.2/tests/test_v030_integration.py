"""Integration tests for v0.3.0 — full pipeline: adapter → runner → results."""

from __future__ import annotations

import json
from datetime import datetime, timezone
from decimal import Decimal

from finlint_audit.adapters.memory import MemoryAdapter
from finlint_audit.cli import format_results, format_results_json
from finlint_audit.runner import AuditRunner

from .helpers import make_account, make_holding, make_liability, make_snapshot, make_transaction


def _clean_adapter() -> MemoryAdapter:
    """Adapter with clean data — all 23 assertions should pass."""
    return MemoryAdapter(
        accounts=[
            make_account("a1", "depository", balance=15000),
            make_account("a2", "investment", balance=70000),
            make_account("a3", "credit", balance=2500),
        ],
        holdings=[
            make_holding("h1", "a2", 50000, ticker="VTI", quantity=Decimal("100")),
            make_holding("h2", "a2", 20000, ticker="VXUS", quantity=Decimal("200")),
        ],
        liabilities=[
            make_liability("l1", "a3", type="credit"),
        ],
        snapshots=[
            make_snapshot("s1", "a1", 15000, "2026-03-15T12:00:00"),
            make_snapshot("s2", "a2", 70000, "2026-03-15T12:00:00"),
            make_snapshot("s3", "a3", 2500, "2026-03-15T12:00:00"),
        ],
        transactions=[
            make_transaction("t1", "a1", "50.00", "2026-03-10", name="Coffee"),
            make_transaction("t2", "a3", "45.99", "2026-03-12", name="Gas"),
        ],
    )


def _dirty_adapter() -> MemoryAdapter:
    """Adapter with issues — some assertions should fail/warn."""
    return MemoryAdapter(
        accounts=[
            make_account("a1", "depository", balance=15000),
            make_account("a2", "investment", balance=50000),
            make_account("a3", "credit", balance=2500),
        ],
        holdings=[
            # bal-001 fail: sum=30000 vs balance=50000
            make_holding("h1", "a2", 20000, ticker="SPY", quantity=Decimal("50")),
            make_holding("h2", "a2", 10000, ticker="AAPL", quantity=Decimal("-10")),  # hold-001
            make_holding("h3", "a1", 5000, ticker="GOOF", quantity=Decimal("10")),  # hold-002
        ],
        liabilities=[],  # liab-001: credit a3 missing liability
        snapshots=[
            make_snapshot("s1", "a1", 15000, "2026-03-15T12:00:00"),
            make_snapshot("s2", "a2", 50000, "2026-03-15T12:00:00"),
            make_snapshot("s3", "a3", 2500, "2026-03-15T12:00:00"),
        ],
        transactions=[
            make_transaction("t1", "a1", "500.00", "2026-03-10", category="TRANSFER"),
            make_transaction("t2", "a1", "-300.00", "2026-03-10", category="TRANSFER"),
        ],
    )


class TestV030Integration:
    def test_runner_executes_23_assertions(self) -> None:
        runner = AuditRunner(adapter=_clean_adapter())
        results = runner.run()
        assert len(results) == 23

    def test_runner_only_filter_new_ids(self) -> None:
        runner = AuditRunner(adapter=_clean_adapter(), only={"bal-001"})
        results = runner.run()
        assert len(results) == 1
        assert results[0].assertion_id == "bal-001"

    def test_runner_only_multiple_new(self) -> None:
        runner = AuditRunner(adapter=_clean_adapter(), only={"bal-001", "hold-001"})
        results = runner.run()
        ids = {r.assertion_id for r in results}
        assert ids == {"bal-001", "hold-001"}

    def test_runner_disables_new_assertions(self) -> None:
        new_ids = {"bal-001", "alloc-001", "acct-001", "hold-001",
                   "liab-001", "txn-004", "hold-002", "comp-001"}
        runner = AuditRunner(adapter=_clean_adapter(), disabled=new_ids)
        results = runner.run()
        result_ids = {r.assertion_id for r in results}
        assert result_ids.isdisjoint(new_ids)
        assert len(results) == 15

    def test_params_propagated_tolerance(self) -> None:
        runner = AuditRunner(
            adapter=_clean_adapter(),
            only={"bal-001"},
            params={"bal-001": {"tolerance": "5.00"}},
        )
        results = runner.run()
        assert results[0].status == "pass"

    def test_params_propagated_stale_days(self) -> None:
        runner = AuditRunner(
            adapter=_clean_adapter(),
            only={"acct-001"},
            params={"acct-001": {"stale_days": "30"}},
        )
        results = runner.run()
        assert results[0].status in ("pass", "warn")

    def test_clean_adapter_all_pass(self) -> None:
        runner = AuditRunner(adapter=_clean_adapter())
        results = runner.run()
        for r in results:
            assert r.status in ("pass", "warn", "skip"), (
                f"{r.assertion_id} unexpected: {r.status} - {r.message}"
            )

    def test_dirty_adapter_mixed_results(self) -> None:
        runner = AuditRunner(adapter=_dirty_adapter())
        results = runner.run()
        statuses = {r.assertion_id: r.status for r in results}
        assert statuses["bal-001"] == "fail"
        assert statuses["hold-001"] == "fail"
        assert statuses["hold-002"] == "fail"
        assert statuses["liab-001"] == "fail"

    def test_text_output_includes_new_ids(self) -> None:
        runner = AuditRunner(adapter=_dirty_adapter())
        results = runner.run()
        text = format_results(results)
        for aid in ("bal-001", "alloc-001", "acct-001", "hold-001",
                     "liab-001", "txn-004", "hold-002", "comp-001"):
            assert aid in text, f"{aid} missing from text output"

    def test_json_output_includes_new_ids(self) -> None:
        runner = AuditRunner(adapter=_dirty_adapter())
        results = runner.run()
        output = format_results_json(results)
        data = json.loads(output)
        ids = [r["assertion_id"] for r in data["results"]]
        assert len(ids) == 23
        for aid in ("bal-001", "alloc-001", "acct-001", "hold-001",
                     "liab-001", "txn-004", "hold-002", "comp-001"):
            assert aid in ids

    def test_exit_code_1_on_new_failure(self) -> None:
        from finlint_audit.cli import compute_exit_code
        runner = AuditRunner(adapter=_dirty_adapter())
        results = runner.run()
        assert compute_exit_code(results) == 1

    def test_exit_code_0_only_new_pass(self) -> None:
        from finlint_audit.cli import compute_exit_code
        runner = AuditRunner(adapter=_clean_adapter(), only={"bal-001", "alloc-001"})
        results = runner.run()
        assert compute_exit_code(results) == 0

    def test_empty_data_no_crash(self) -> None:
        runner = AuditRunner(adapter=MemoryAdapter())
        results = runner.run()
        assert len(results) == 23
        # data-001 intentionally fails on empty data (no accounts)
        for r in results:
            if r.assertion_id == "data-001":
                assert r.status == "fail"
            else:
                assert r.status in ("pass", "warn", "skip")

    def test_new_assertions_dont_break_existing(self) -> None:
        runner = AuditRunner(adapter=_clean_adapter())
        results = runner.run()
        existing_ids = {"nw-001", "sign-001", "overlap-001", "snap-001", "drift-001",
                       "txn-001", "txn-002", "txn-003"}
        for r in results:
            if r.assertion_id in existing_ids:
                assert r.status in ("pass", "warn", "skip"), (
                    f"Existing {r.assertion_id} broken: {r.status} - {r.message}"
                )
