"""Tests for liab-002: Liability Balance Freshness."""

from decimal import Decimal

from finlint_audit.assertions.liability_balance_freshness import (
    assert_liability_balance_freshness,
)
from tests.helpers import make_ctx, make_liability


class TestLiabilityBalanceFreshness:
    """Blackbox tests for liab-002."""

    def test_empty_liabilities(self):
        r = assert_liability_balance_freshness(make_ctx())
        assert r.status == "pass"
        assert r.assertion_id == "liab-002"

    def test_both_none_skipped(self):
        r = assert_liability_balance_freshness(make_ctx(
            liabilities=[make_liability("l1", "a1")],
        ))
        assert r.status == "pass"
        assert r.metadata["checked_count"] == "0"

    def test_one_none_skipped(self):
        r = assert_liability_balance_freshness(make_ctx(
            liabilities=[make_liability(
                "l1", "a1",
                last_statement_balance=Decimal("1000"),
            )],
        ))
        assert r.status == "pass"

    def test_equal_balances_pass(self):
        r = assert_liability_balance_freshness(make_ctx(
            liabilities=[make_liability(
                "l1", "a1",
                last_statement_balance=Decimal("1000"),
                current_balance=Decimal("1000"),
            )],
        ))
        assert r.status == "pass"
        assert r.metadata["checked_count"] == "1"

    def test_small_divergence_passes(self):
        """5% divergence is below default 10% threshold."""
        r = assert_liability_balance_freshness(make_ctx(
            liabilities=[make_liability(
                "l1", "a1",
                last_statement_balance=Decimal("1000"),
                current_balance=Decimal("1050"),
            )],
        ))
        assert r.status == "pass"

    def test_large_divergence_warns(self):
        """50% divergence exceeds default 10% threshold."""
        r = assert_liability_balance_freshness(make_ctx(
            liabilities=[make_liability(
                "l1", "a1",
                last_statement_balance=Decimal("1000"),
                current_balance=Decimal("1500"),
            )],
        ))
        assert r.status == "warn"
        assert r.metadata["flagged_count"] == "1"

    def test_below_min_balance_skipped(self):
        r = assert_liability_balance_freshness(make_ctx(
            liabilities=[make_liability(
                "l1", "a1",
                last_statement_balance=Decimal("10"),
                current_balance=Decimal("40"),
            )],
        ))
        assert r.status == "pass"
        assert r.metadata["checked_count"] == "0"

    def test_negative_balances(self):
        """Negative balances still compute divergence correctly."""
        r = assert_liability_balance_freshness(make_ctx(
            liabilities=[make_liability(
                "l1", "a1",
                last_statement_balance=Decimal("-1000"),
                current_balance=Decimal("-500"),
            )],
        ))
        assert r.status == "warn"

    def test_custom_threshold(self):
        r = assert_liability_balance_freshness(make_ctx(
            liabilities=[make_liability(
                "l1", "a1",
                last_statement_balance=Decimal("1000"),
                current_balance=Decimal("1200"),
            )],
            params={"max_divergence_pct": "0.25"},
        ))
        assert r.status == "pass"

    def test_multiple_liabilities(self):
        r = assert_liability_balance_freshness(make_ctx(
            liabilities=[
                make_liability(
                    "l1", "a1",
                    last_statement_balance=Decimal("1000"),
                    current_balance=Decimal("1000"),
                ),
                make_liability(
                    "l2", "a2",
                    last_statement_balance=Decimal("2000"),
                    current_balance=Decimal("3000"),
                ),
            ],
        ))
        assert r.status == "warn"
        assert r.metadata["flagged_count"] == "1"
        assert r.metadata["checked_count"] == "2"

    def test_evidence_format(self):
        r = assert_liability_balance_freshness(make_ctx(
            liabilities=[make_liability(
                "l1", "a1",
                last_statement_balance=Decimal("1000"),
                current_balance=Decimal("2000"),
            )],
        ))
        assert r.evidence[0].field == "liability.id=l1"
        assert "divergence" in r.evidence[0].actual.lower()

    def test_zero_denominator_skipped(self):
        """Both balances zero → below min_balance."""
        r = assert_liability_balance_freshness(make_ctx(
            liabilities=[make_liability(
                "l1", "a1",
                last_statement_balance=Decimal("0"),
                current_balance=Decimal("0"),
            )],
        ))
        assert r.status == "pass"

    def test_boundary_at_threshold(self):
        """Exactly 10% divergence should not warn (> not >=)."""
        r = assert_liability_balance_freshness(make_ctx(
            liabilities=[make_liability(
                "l1", "a1",
                last_statement_balance=Decimal("1000"),
                current_balance=Decimal("1100"),
            )],
        ))
        assert r.status == "pass"
