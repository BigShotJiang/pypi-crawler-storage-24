"""TDD tests for completeness assertion (comp-001)."""

import pytest

from finlint_audit.assertions.completeness import assert_completeness

from tests.helpers import (
    make_ctx as _ctx,
    make_account as _acct,
    make_holding as _hold,
    make_liability as _liab,
    make_snapshot as _snap,
)

_TS = "2026-03-15T12:00:00"


# ── Blackbox tests ──────────────────────────────────────────────────


class TestCompletenessBlackbox:
    def test_empty_dataset(self) -> None:
        result = assert_completeness(_ctx())
        assert result.status == "pass"
        assert result.assertion_id == "comp-001"

    def test_fully_complete_investment(self) -> None:
        result = assert_completeness(_ctx(
            accounts=[_acct("a1", "investment", 50000)],
            holdings=[_hold("h1", "a1", 50000)],
            snapshots=[_snap("s1", "a1", 50000, _TS)],
        ))
        assert result.status == "pass"

    def test_fully_complete_credit(self) -> None:
        result = assert_completeness(_ctx(
            accounts=[_acct("a1", "credit", 2000)],
            liabilities=[_liab("l1", "a1", "credit")],
            snapshots=[_snap("s1", "a1", 2000, _TS)],
        ))
        assert result.status == "pass"

    def test_fully_complete_depository(self) -> None:
        result = assert_completeness(_ctx(
            accounts=[_acct("a1", "depository", 10000)],
            snapshots=[_snap("s1", "a1", 10000, _TS)],
        ))
        assert result.status == "pass"

    def test_investment_no_holdings(self) -> None:
        result = assert_completeness(_ctx(
            accounts=[_acct("a1", "investment", 50000)],
            snapshots=[_snap("s1", "a1", 50000, _TS)],
        ))
        assert result.status == "warn"
        assert any("holdings" in e.actual for e in result.evidence)

    def test_credit_no_liability(self) -> None:
        result = assert_completeness(_ctx(
            accounts=[_acct("a1", "credit", 2000)],
            snapshots=[_snap("s1", "a1", 2000, _TS)],
        ))
        assert result.status == "warn"
        assert any("liability" in e.actual for e in result.evidence)

    def test_loan_no_liability(self) -> None:
        result = assert_completeness(_ctx(
            accounts=[_acct("a1", "loan", 150000)],
            snapshots=[_snap("s1", "a1", 150000, _TS)],
        ))
        assert result.status == "warn"
        assert any("liability" in e.actual for e in result.evidence)

    def test_account_no_snapshot(self) -> None:
        result = assert_completeness(_ctx(
            accounts=[_acct("a1", "depository", 10000)],
        ))
        assert result.status == "warn"
        assert any("snapshots" in e.actual for e in result.evidence)

    def test_all_incomplete(self) -> None:
        """3 accounts, each missing something."""
        result = assert_completeness(_ctx(
            accounts=[
                _acct("a1", "investment", 50000),   # no holdings, no snapshot
                _acct("a2", "credit", 2000),         # no liability, no snapshot
                _acct("a3", "depository", 10000),    # no snapshot
            ],
        ))
        assert result.status == "warn"
        assert len(result.evidence) >= 3

    def test_investment_no_holdings_no_snapshot(self) -> None:
        result = assert_completeness(_ctx(
            accounts=[_acct("a1", "investment", 50000)],
        ))
        assert result.status == "warn"
        # Two issues: no holdings + no snapshot
        assert len(result.evidence) == 2

    def test_depository_no_holdings_ok(self) -> None:
        """Depository with snapshot doesn't need holdings."""
        result = assert_completeness(_ctx(
            accounts=[_acct("a1", "depository", 10000)],
            snapshots=[_snap("s1", "a1", 10000, _TS)],
        ))
        assert result.status == "pass"

    def test_many_accounts_mixed(self) -> None:
        """5 accounts: 3 complete, 2 incomplete."""
        result = assert_completeness(_ctx(
            accounts=[
                _acct("a1", "depository", 10000),    # complete
                _acct("a2", "investment", 50000),     # complete
                _acct("a3", "credit", 2000),          # complete
                _acct("a4", "depository", 5000),      # incomplete — no snapshot
                _acct("a5", "investment", 30000),     # incomplete — no holdings
            ],
            holdings=[_hold("h1", "a2", 50000)],
            liabilities=[_liab("l1", "a3", "credit")],
            snapshots=[
                _snap("s1", "a1", 10000, _TS),
                _snap("s2", "a2", 50000, _TS),
                _snap("s3", "a3", 2000, _TS),
                _snap("s5", "a5", 30000, _TS),
            ],
        ))
        assert result.status == "warn"
        assert result.metadata["incomplete_count"] == "2"


# ── Whitebox tests ──────────────────────────────────────────────────


class TestCompletenessWhitebox:
    def test_inactive_accounts_skipped(self) -> None:
        result = assert_completeness(_ctx(
            accounts=[_acct("a1", "investment", 50000, is_active=False)],
        ))
        assert result.status == "pass"

    def test_exclude_from_net_worth_still_checked(self) -> None:
        result = assert_completeness(_ctx(
            accounts=[_acct("a1", "depository", 10000, exclude_from_net_worth=True)],
        ))
        assert result.status == "warn"

    def test_investment_doesnt_need_liability(self) -> None:
        result = assert_completeness(_ctx(
            accounts=[_acct("a1", "investment", 50000)],
            holdings=[_hold("h1", "a1", 50000)],
            snapshots=[_snap("s1", "a1", 50000, _TS)],
        ))
        assert result.status == "pass"

    def test_other_type_only_needs_snapshot(self) -> None:
        result = assert_completeness(_ctx(
            accounts=[_acct("a1", "other", 5000)],
            snapshots=[_snap("s1", "a1", 5000, _TS)],
        ))
        assert result.status == "pass"

    def test_other_type_no_snapshot(self) -> None:
        result = assert_completeness(_ctx(
            accounts=[_acct("a1", "other", 5000)],
        ))
        assert result.status == "warn"

    def test_loan_needs_liability_not_holdings(self) -> None:
        result = assert_completeness(_ctx(
            accounts=[_acct("a1", "loan", 150000)],
            liabilities=[_liab("l1", "a1", "student")],
            snapshots=[_snap("s1", "a1", 150000, _TS)],
        ))
        assert result.status == "pass"

    def test_evidence_capping(self) -> None:
        """60 incomplete accounts → 50 + 1 cap summary = 51 items."""
        accounts = [_acct(f"a{i}", "depository", 1000) for i in range(60)]
        result = assert_completeness(_ctx(accounts=accounts))
        assert result.status == "warn"
        assert len(result.evidence) == 51
        assert result.evidence[-1].field == "(capped)"

    def test_metadata_incomplete_count(self) -> None:
        accounts = [_acct(f"a{i}", "depository", 1000) for i in range(4)]
        result = assert_completeness(_ctx(accounts=accounts))
        assert result.metadata["incomplete_count"] == "4"

    def test_evidence_issue_type(self) -> None:
        """Investment without holdings → evidence mentions 'holdings'."""
        result = assert_completeness(_ctx(
            accounts=[_acct("a1", "investment", 50000)],
            snapshots=[_snap("s1", "a1", 50000, _TS)],
        ))
        holdings_evidence = [e for e in result.evidence if "holdings" in e.actual]
        assert len(holdings_evidence) == 1

    def test_multiple_snapshots_satisfies(self) -> None:
        result = assert_completeness(_ctx(
            accounts=[_acct("a1", "depository", 10000)],
            snapshots=[
                _snap("s1", "a1", 9000, "2026-03-13T12:00:00"),
                _snap("s2", "a1", 9500, "2026-03-14T12:00:00"),
                _snap("s3", "a1", 10000, _TS),
            ],
        ))
        assert result.status == "pass"
