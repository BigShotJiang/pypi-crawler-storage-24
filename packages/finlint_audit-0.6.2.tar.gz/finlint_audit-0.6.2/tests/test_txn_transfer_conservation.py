"""Tests for txn-004: Transfer Conservation."""

from __future__ import annotations

from decimal import Decimal

from finlint_audit.assertions.txn_transfer_conservation import (
    assert_txn_transfer_conservation,
)

from .helpers import make_ctx, make_transaction

# Aliases
_ctx = make_ctx
_txn = make_transaction


# ===========================================================================
# Blackbox tests — correct outputs for known inputs
# ===========================================================================


class TestTransferConservationBlackbox:
    def test_empty_dataset(self) -> None:
        result = assert_txn_transfer_conservation(_ctx())
        assert result.status == "pass"
        assert result.assertion_id == "txn-004"

    def test_no_transfer_transactions(self) -> None:
        txns = [
            _txn("t1", "a1", "50", "2026-03-01", name="Coffee"),
            _txn("t2", "a1", "100", "2026-03-02", name="Grocery"),
            _txn("t3", "a1", "75", "2026-03-03", name="Gas"),
            _txn("t4", "a2", "200", "2026-03-04", name="Rent"),
            _txn("t5", "a2", "30", "2026-03-05", name="Lunch"),
        ]
        result = assert_txn_transfer_conservation(_ctx(transactions=txns))
        assert result.status == "pass"
        assert result.message == "No transfer transactions to check"

    def test_balanced_pair(self) -> None:
        txns = [
            _txn("t1", "a1", "500", "2026-03-01", category="TRANSFER"),
            _txn("t2", "a2", "-500", "2026-03-01", category="TRANSFER"),
        ]
        result = assert_txn_transfer_conservation(_ctx(transactions=txns))
        assert result.status == "pass"

    def test_unbalanced_pair(self) -> None:
        txns = [
            _txn("t1", "a1", "500", "2026-03-01", category="TRANSFER"),
            _txn("t2", "a2", "-400", "2026-03-01", category="TRANSFER"),
        ]
        result = assert_txn_transfer_conservation(_ctx(transactions=txns))
        assert result.status == "warn"
        assert len(result.evidence) == 1

    def test_single_sided_transfer(self) -> None:
        txns = [
            _txn("t1", "a1", "500", "2026-03-01", category="TRANSFER"),
        ]
        result = assert_txn_transfer_conservation(_ctx(transactions=txns))
        assert result.status == "warn"

    def test_multiple_balanced_pairs(self) -> None:
        txns = [
            _txn("t1", "a1", "500", "2026-03-01", category="TRANSFER"),
            _txn("t2", "a2", "-500", "2026-03-01", category="TRANSFER"),
            _txn("t3", "a1", "300", "2026-03-05", category="TRANSFER"),
            _txn("t4", "a2", "-300", "2026-03-05", category="TRANSFER"),
        ]
        result = assert_txn_transfer_conservation(_ctx(transactions=txns))
        assert result.status == "pass"

    def test_three_leg_transfer(self) -> None:
        txns = [
            _txn("t1", "a1", "500", "2026-03-01", category="TRANSFER"),
            _txn("t2", "a2", "-300", "2026-03-01", category="TRANSFER"),
            _txn("t3", "a3", "-200", "2026-03-01", category="TRANSFER"),
        ]
        result = assert_txn_transfer_conservation(_ctx(transactions=txns))
        assert result.status == "pass"

    def test_within_tolerance(self) -> None:
        txns = [
            _txn("t1", "a1", "500.50", "2026-03-01", category="TRANSFER"),
            _txn("t2", "a2", "-500", "2026-03-01", category="TRANSFER"),
        ]
        result = assert_txn_transfer_conservation(_ctx(transactions=txns))
        assert result.status == "pass"

    def test_different_dates_separate(self) -> None:
        txns = [
            _txn("t1", "a1", "500", "2026-03-01", category="TRANSFER"),
            _txn("t2", "a2", "-500", "2026-03-02", category="TRANSFER"),
        ]
        result = assert_txn_transfer_conservation(_ctx(transactions=txns))
        assert result.status == "warn"
        assert len(result.evidence) == 2

    def test_non_transfer_ignored(self) -> None:
        txns = [
            _txn("t1", "a1", "500", "2026-03-01", category="TRANSFER"),
            _txn("t2", "a2", "-500", "2026-03-01", category="TRANSFER"),
            _txn("t3", "a1", "999", "2026-03-01", name="Coffee"),
        ]
        result = assert_txn_transfer_conservation(_ctx(transactions=txns))
        assert result.status == "pass"


# ===========================================================================
# Whitebox tests — internal logic, edge cases, parameters
# ===========================================================================


class TestTransferConservationWhitebox:
    def test_custom_tolerance(self) -> None:
        txns = [
            _txn("t1", "a1", "504", "2026-03-01", category="TRANSFER"),
            _txn("t2", "a2", "-500", "2026-03-01", category="TRANSFER"),
        ]
        result = assert_txn_transfer_conservation(
            _ctx(transactions=txns, params={"tolerance": "5.00"})
        )
        assert result.status == "pass"

    def test_category_case_insensitive(self) -> None:
        txns = [
            _txn("t1", "a1", "500", "2026-03-01", category="transfer"),
            _txn("t2", "a2", "-500", "2026-03-01", category="transfer"),
        ]
        result = assert_txn_transfer_conservation(_ctx(transactions=txns))
        assert result.status == "pass"

    def test_category_mixed_case(self) -> None:
        txns = [
            _txn("t1", "a1", "500", "2026-03-01", category="Transfer"),
            _txn("t2", "a2", "-500", "2026-03-01", category="Transfer"),
        ]
        result = assert_txn_transfer_conservation(_ctx(transactions=txns))
        assert result.status == "pass"

    def test_name_fallback_no_category(self) -> None:
        txns = [
            _txn("t1", "a1", "500", "2026-03-01", category="", name="Bank Transfer"),
            _txn("t2", "a2", "-500", "2026-03-01", category="", name="Bank Transfer"),
        ]
        result = assert_txn_transfer_conservation(_ctx(transactions=txns))
        assert result.status == "pass"

    def test_name_fallback_case_insensitive(self) -> None:
        txns = [
            _txn("t1", "a1", "500", "2026-03-01", category="", name="INTERNAL TRANSFER"),
        ]
        result = assert_txn_transfer_conservation(_ctx(transactions=txns))
        assert result.status == "warn"

    def test_name_no_match(self) -> None:
        txns = [
            _txn("t1", "a1", "500", "2026-03-01", category="", name="Coffee Shop"),
        ]
        result = assert_txn_transfer_conservation(_ctx(transactions=txns))
        assert result.status == "pass"
        assert result.message == "No transfer transactions to check"

    def test_category_takes_precedence(self) -> None:
        txns = [
            _txn("t1", "a1", "500", "2026-03-01", category="TRANSFER", name="Coffee"),
        ]
        result = assert_txn_transfer_conservation(_ctx(transactions=txns))
        assert result.status == "warn"
        assert len(result.evidence) == 1

    def test_tolerance_boundary_exact(self) -> None:
        """Net exactly at tolerance should pass (> not >=)."""
        txns = [
            _txn("t1", "a1", "501", "2026-03-01", category="TRANSFER"),
            _txn("t2", "a2", "-500", "2026-03-01", category="TRANSFER"),
        ]
        result = assert_txn_transfer_conservation(_ctx(transactions=txns))
        assert result.status == "pass"

    def test_tolerance_boundary_over(self) -> None:
        """Net just over tolerance should warn."""
        txns = [
            _txn("t1", "a1", "501.01", "2026-03-01", category="TRANSFER"),
            _txn("t2", "a2", "-500", "2026-03-01", category="TRANSFER"),
        ]
        result = assert_txn_transfer_conservation(_ctx(transactions=txns))
        assert result.status == "warn"

    def test_metadata_imbalanced_count(self) -> None:
        txns = []
        for i, day in enumerate(["01", "02", "03"]):
            txns.append(
                _txn(f"t{i}", "a1", "500", f"2026-03-{day}", category="TRANSFER")
            )
        result = assert_txn_transfer_conservation(_ctx(transactions=txns))
        assert result.status == "warn"
        assert result.metadata["imbalanced_count"] == "3"

    def test_evidence_shows_date_and_net(self) -> None:
        txns = [
            _txn("t1", "a1", "500", "2026-03-01", category="TRANSFER"),
            _txn("t2", "a2", "-400", "2026-03-01", category="TRANSFER"),
        ]
        result = assert_txn_transfer_conservation(_ctx(transactions=txns))
        assert len(result.evidence) == 1
        ev = result.evidence[0]
        assert "2026-03-01" in ev.field
        assert "100" in ev.actual

    def test_evidence_capping(self) -> None:
        txns = []
        for i in range(60):
            day = f"{(i % 28) + 1:02d}"
            month = f"{(i // 28) + 1:02d}"
            txns.append(
                _txn(f"t{i}", "a1", "500", f"2026-{month}-{day}", category="TRANSFER")
            )
        result = assert_txn_transfer_conservation(_ctx(transactions=txns))
        assert result.status == "warn"
        # 50 capped + 1 summary = 51
        assert len(result.evidence) == 51
        assert result.evidence[-1].field == "(capped)"
