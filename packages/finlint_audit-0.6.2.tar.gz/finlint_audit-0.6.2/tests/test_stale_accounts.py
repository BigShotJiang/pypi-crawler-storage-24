"""TDD tests for stale accounts assertion (acct-001)."""

from datetime import datetime, timedelta, timezone

import pytest

from finlint_audit.assertions.stale_accounts import assert_stale_accounts

from tests.helpers import make_ctx as _ctx, make_account as _acct, make_snapshot as _snap


# ---------------------------------------------------------------------------
# Blackbox tests (10)
# ---------------------------------------------------------------------------


class TestStaleAccountsBlackbox:
    def test_empty_dataset(self) -> None:
        result = assert_stale_accounts(_ctx())
        assert result.status == "pass"
        assert result.assertion_id == "acct-001"

    def test_no_active_accounts(self) -> None:
        result = assert_stale_accounts(_ctx(
            accounts=[
                _acct("a1", "depository", is_active=False),
                _acct("a2", "credit", is_active=False),
            ],
        ))
        assert result.status == "pass"
        assert "No active accounts" in result.message

    def test_all_fresh(self) -> None:
        now = datetime(2026, 3, 16, 12, 0, 0)
        result = assert_stale_accounts(_ctx(
            accounts=[
                _acct("a1", "depository"),
                _acct("a2", "investment"),
                _acct("a3", "credit"),
            ],
            snapshots=[
                _snap("s1", "a1", 1000, "2026-03-14T12:00:00"),
                _snap("s2", "a2", 2000, "2026-03-14T12:00:00"),
                _snap("s3", "a3", 3000, "2026-03-14T12:00:00"),
            ],
            now=now,
        ))
        assert result.status == "pass"
        assert "3 account(s) have fresh snapshots" in result.message

    def test_one_stale(self) -> None:
        now = datetime(2026, 3, 16, 12, 0, 0)
        result = assert_stale_accounts(_ctx(
            accounts=[
                _acct("a1", "depository"),
                _acct("a2", "investment"),
                _acct("a3", "credit"),
            ],
            snapshots=[
                _snap("s1", "a1", 1000, "2026-03-14T12:00:00"),
                _snap("s2", "a2", 2000, "2026-03-06T12:00:00"),  # 10 days old
                _snap("s3", "a3", 3000, "2026-03-14T12:00:00"),
            ],
            now=now,
        ))
        assert result.status == "warn"
        assert len(result.evidence) == 1
        assert "a2" in result.evidence[0].field

    def test_no_snapshots_for_account(self) -> None:
        now = datetime(2026, 3, 16, 12, 0, 0)
        result = assert_stale_accounts(_ctx(
            accounts=[_acct("a1", "depository")],
            snapshots=[],
            now=now,
        ))
        assert result.status == "warn"
        assert len(result.evidence) == 1
        assert "no snapshots found" in result.evidence[0].actual

    def test_multiple_stale(self) -> None:
        now = datetime(2026, 3, 16, 12, 0, 0)
        result = assert_stale_accounts(_ctx(
            accounts=[
                _acct("a1", "depository"),
                _acct("a2", "investment"),
                _acct("a3", "credit"),
            ],
            snapshots=[
                _snap("s1", "a1", 1000, "2026-03-01T12:00:00"),  # 15 days
                _snap("s2", "a2", 2000, "2026-03-01T12:00:00"),
                _snap("s3", "a3", 3000, "2026-03-01T12:00:00"),
            ],
            now=now,
        ))
        assert result.status == "warn"
        assert len(result.evidence) == 3

    def test_mix_fresh_and_stale(self) -> None:
        now = datetime(2026, 3, 16, 12, 0, 0)
        result = assert_stale_accounts(_ctx(
            accounts=[
                _acct("a1", "depository"),
                _acct("a2", "investment"),
                _acct("a3", "credit"),
                _acct("a4", "loan"),
            ],
            snapshots=[
                _snap("s1", "a1", 1000, "2026-03-15T12:00:00"),  # fresh
                _snap("s2", "a2", 2000, "2026-03-01T12:00:00"),  # stale
                _snap("s3", "a3", 3000, "2026-03-14T12:00:00"),  # fresh
                _snap("s4", "a4", 4000, "2026-03-01T12:00:00"),  # stale
            ],
            now=now,
        ))
        assert result.status == "warn"
        assert len(result.evidence) == 2

    def test_all_accounts_stale(self) -> None:
        now = datetime(2026, 3, 16, 12, 0, 0)
        result = assert_stale_accounts(_ctx(
            accounts=[
                _acct(f"a{i}", "depository") for i in range(5)
            ],
            snapshots=[
                _snap(f"s{i}", f"a{i}", 1000, "2026-03-01T00:00:00")
                for i in range(5)
            ],
            now=now,
        ))
        assert result.status == "warn"
        assert "5 account(s)" in result.message

    def test_inactive_accounts_excluded(self) -> None:
        now = datetime(2026, 3, 16, 12, 0, 0)
        result = assert_stale_accounts(_ctx(
            accounts=[
                _acct("a1", "depository", is_active=True),
                _acct("a2", "credit", is_active=False),
            ],
            snapshots=[
                _snap("s1", "a1", 1000, "2026-03-15T12:00:00"),  # fresh
                _snap("s2", "a2", 2000, "2026-03-01T12:00:00"),  # stale but inactive
            ],
            now=now,
        ))
        assert result.status == "pass"

    def test_single_account_single_snapshot(self) -> None:
        now = datetime(2026, 3, 16, 12, 0, 0)
        result = assert_stale_accounts(_ctx(
            accounts=[_acct("a1", "depository")],
            snapshots=[_snap("s1", "a1", 500, "2026-03-15T10:00:00")],
            now=now,
        ))
        assert result.status == "pass"


# ---------------------------------------------------------------------------
# Whitebox tests (10)
# ---------------------------------------------------------------------------


class TestStaleAccountsWhitebox:
    def test_custom_stale_days_30(self) -> None:
        now = datetime(2026, 3, 16, 12, 0, 0)
        result = assert_stale_accounts(_ctx(
            accounts=[_acct("a1", "depository")],
            snapshots=[_snap("s1", "a1", 1000, "2026-03-06T12:00:00")],  # 10 days
            params={"stale_days": 30},
            now=now,
        ))
        assert result.status == "pass"

    def test_custom_stale_days_1(self) -> None:
        now = datetime(2026, 3, 16, 12, 0, 0)
        result = assert_stale_accounts(_ctx(
            accounts=[_acct("a1", "depository")],
            snapshots=[_snap("s1", "a1", 1000, "2026-03-14T12:00:00")],  # 2 days
            params={"stale_days": 1},
            now=now,
        ))
        assert result.status == "warn"

    def test_ctx_now_injection(self) -> None:
        fixed_now = datetime(2026, 1, 1, 0, 0, 0)
        result = assert_stale_accounts(_ctx(
            accounts=[_acct("a1", "depository")],
            snapshots=[_snap("s1", "a1", 1000, "2025-12-30T00:00:00")],  # 2 days
            now=fixed_now,
        ))
        assert result.status == "pass"

    def test_latest_snapshot_used(self) -> None:
        now = datetime(2026, 3, 16, 12, 0, 0)
        result = assert_stale_accounts(_ctx(
            accounts=[_acct("a1", "depository")],
            snapshots=[
                _snap("s1", "a1", 100, "2026-02-01T00:00:00"),  # old
                _snap("s2", "a1", 200, "2026-03-15T00:00:00"),  # recent
                _snap("s3", "a1", 150, "2026-02-15T00:00:00"),  # middle
            ],
            now=now,
        ))
        assert result.status == "pass"

    def test_boundary_exactly_stale_days(self) -> None:
        now = datetime(2026, 3, 16, 12, 0, 0)
        # Exactly 7 days old: age=7, stale_days=7, 7 > 7 is False → pass
        result = assert_stale_accounts(_ctx(
            accounts=[_acct("a1", "depository")],
            snapshots=[_snap("s1", "a1", 1000, "2026-03-09T12:00:00")],
            now=now,
        ))
        assert result.status == "pass"

    def test_boundary_one_past(self) -> None:
        now = datetime(2026, 3, 16, 12, 0, 0)
        # 8 days old: age=8, stale_days=7, 8 > 7 is True → warn
        result = assert_stale_accounts(_ctx(
            accounts=[_acct("a1", "depository")],
            snapshots=[_snap("s1", "a1", 1000, "2026-03-08T12:00:00")],
            now=now,
        ))
        assert result.status == "warn"

    def test_timezone_aware_snapshots(self) -> None:
        now = datetime(2026, 3, 16, 12, 0, 0, tzinfo=timezone.utc)
        captured = datetime(2026, 3, 14, 12, 0, 0, tzinfo=timezone.utc)
        result = assert_stale_accounts(_ctx(
            accounts=[_acct("a1", "depository")],
            snapshots=[_snap("s1", "a1", 1000, captured)],
            now=now,
        ))
        assert result.status == "pass"

    def test_exclude_from_net_worth_still_checked(self) -> None:
        now = datetime(2026, 3, 16, 12, 0, 0)
        result = assert_stale_accounts(_ctx(
            accounts=[_acct("a1", "depository", exclude_from_net_worth=True)],
            snapshots=[_snap("s1", "a1", 1000, "2026-03-01T12:00:00")],  # 15 days
            now=now,
        ))
        assert result.status == "warn"
        assert len(result.evidence) == 1

    def test_metadata_stale_count(self) -> None:
        now = datetime(2026, 3, 16, 12, 0, 0)
        result = assert_stale_accounts(_ctx(
            accounts=[
                _acct("a1", "depository"),
                _acct("a2", "investment"),
                _acct("a3", "credit"),
            ],
            snapshots=[
                _snap("s1", "a1", 1000, "2026-03-01T00:00:00"),
                _snap("s2", "a2", 2000, "2026-03-01T00:00:00"),
                _snap("s3", "a3", 3000, "2026-03-01T00:00:00"),
            ],
            now=now,
        ))
        assert result.metadata["stale_count"] == "3"

    def test_evidence_shows_age(self) -> None:
        now = datetime(2026, 3, 16, 12, 0, 0)
        result = assert_stale_accounts(_ctx(
            accounts=[_acct("a1", "depository")],
            snapshots=[_snap("s1", "a1", 1000, "2026-03-01T12:00:00")],  # 15 days
            now=now,
        ))
        assert result.status == "warn"
        assert "15 days old" in result.evidence[0].actual
