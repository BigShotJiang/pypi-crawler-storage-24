"""Tests for data-001: Scoring Data Completeness."""

from finlint_audit.assertions.data_completeness import assert_data_completeness
from tests.helpers import (
    make_account,
    make_ctx,
    make_holding,
    make_liability,
    make_transaction,
)


class TestDataCompleteness:
    """Blackbox tests for data-001."""

    def test_no_accounts_fail(self):
        r = assert_data_completeness(make_ctx())
        assert r.status == "fail"
        assert r.assertion_id == "data-001"
        assert "accounts" in r.metadata["missing_components"]

    def test_single_depository_with_transactions_pass(self):
        r = assert_data_completeness(make_ctx(
            accounts=[make_account("a1", "depository", 5000)],
            transactions=[make_transaction("t1", "a1", 50, "2026-01-15")],
        ))
        assert r.status == "pass"

    def test_no_depository_warns(self):
        r = assert_data_completeness(make_ctx(
            accounts=[make_account("a1", "investment", 10000)],
            holdings=[make_holding("h1", "a1", 10000)],
            transactions=[make_transaction("t1", "a1", 50, "2026-01-15")],
        ))
        assert r.status == "warn"
        assert "depository" in r.metadata["missing_components"]

    def test_no_transactions_warns(self):
        r = assert_data_completeness(make_ctx(
            accounts=[make_account("a1", "depository", 5000)],
        ))
        assert r.status == "warn"
        assert "transactions" in r.metadata["missing_components"]

    def test_investment_no_holdings_warns(self):
        r = assert_data_completeness(make_ctx(
            accounts=[
                make_account("a1", "depository", 5000),
                make_account("a2", "investment", 10000),
            ],
            transactions=[make_transaction("t1", "a1", 50, "2026-01-15")],
        ))
        assert r.status == "warn"
        assert "holdings" in r.metadata["missing_components"]

    def test_investment_with_holdings_pass(self):
        r = assert_data_completeness(make_ctx(
            accounts=[
                make_account("a1", "depository", 5000),
                make_account("a2", "investment", 10000),
            ],
            holdings=[make_holding("h1", "a2", 10000)],
            transactions=[make_transaction("t1", "a1", 50, "2026-01-15")],
        ))
        assert r.status == "pass"

    def test_credit_no_liability_warns(self):
        r = assert_data_completeness(make_ctx(
            accounts=[
                make_account("a1", "depository", 5000),
                make_account("a2", "credit", 2000),
            ],
            transactions=[make_transaction("t1", "a1", 50, "2026-01-15")],
        ))
        assert r.status == "warn"
        assert "liabilities" in r.metadata["missing_components"]

    def test_loan_no_liability_warns(self):
        r = assert_data_completeness(make_ctx(
            accounts=[
                make_account("a1", "depository", 5000),
                make_account("a2", "loan", 50000),
            ],
            transactions=[make_transaction("t1", "a1", 50, "2026-01-15")],
        ))
        assert r.status == "warn"
        assert "liabilities" in r.metadata["missing_components"]

    def test_credit_with_liability_pass(self):
        r = assert_data_completeness(make_ctx(
            accounts=[
                make_account("a1", "depository", 5000),
                make_account("a2", "credit", 2000),
            ],
            liabilities=[make_liability("l1", "a2")],
            transactions=[make_transaction("t1", "a1", 50, "2026-01-15")],
        ))
        assert r.status == "pass"

    def test_fully_complete_pass(self):
        r = assert_data_completeness(make_ctx(
            accounts=[
                make_account("a1", "depository", 5000),
                make_account("a2", "investment", 10000),
                make_account("a3", "credit", 2000),
            ],
            holdings=[make_holding("h1", "a2", 10000)],
            liabilities=[make_liability("l1", "a3")],
            transactions=[make_transaction("t1", "a1", 50, "2026-01-15")],
        ))
        assert r.status == "pass"
        assert r.metadata["missing_components"] == ""

    def test_multiple_missing(self):
        r = assert_data_completeness(make_ctx(
            accounts=[
                make_account("a1", "investment", 10000),
                make_account("a2", "credit", 2000),
            ],
        ))
        assert r.status == "warn"
        missing = r.metadata["missing_components"].split(",")
        assert "depository" in missing
        assert "transactions" in missing
        assert "holdings" in missing
        assert "liabilities" in missing

    def test_inactive_excluded(self):
        r = assert_data_completeness(make_ctx(
            accounts=[
                make_account("a1", "depository", 5000),
                make_account("a2", "investment", 10000, is_active=False),
            ],
            transactions=[make_transaction("t1", "a1", 50, "2026-01-15")],
        ))
        # Inactive investment account doesn't trigger holdings requirement
        assert r.status == "pass"

    def test_transactions_from_inactive_not_counted(self):
        """Transactions must belong to active accounts."""
        r = assert_data_completeness(make_ctx(
            accounts=[
                make_account("a1", "depository", 5000),
                make_account("a2", "depository", 3000, is_active=False),
            ],
            transactions=[make_transaction("t1", "a2", 50, "2026-01-15")],
        ))
        assert r.status == "warn"
        assert "transactions" in r.metadata["missing_components"]

    def test_evidence_on_fail(self):
        r = assert_data_completeness(make_ctx())
        assert len(r.evidence) == 1
        assert r.evidence[0].field == "accounts"
