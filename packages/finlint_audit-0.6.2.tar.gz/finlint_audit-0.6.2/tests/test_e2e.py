"""End-to-end tests: full pipeline from config → SQLite → assertions → output.

These tests exercise the complete finlint-audit pipeline against real
SQLite databases (fixture files), validating the same behavior that
Playwright E2E tests would verify via CLI subprocess.
"""

import json
import sqlite3
from pathlib import Path

import pytest

from finlint_audit.adapters.sql import SqlAdapter
from finlint_audit.cli import (
    compute_exit_code,
    format_results,
    format_results_github,
    format_results_json,
)
from finlint_audit.config import parse_config
from finlint_audit.runner import AuditRunner

FIXTURES_DIR = Path(__file__).parent / "fixtures"


def _load_config(yaml_file: str, db_file: str) -> str:
    """Load YAML config and substitute DB path."""
    yaml_path = FIXTURES_DIR / yaml_file
    db_path = FIXTURES_DIR / db_file
    content = yaml_path.read_text()
    return content.replace("FIXTURE_DB_PATH", str(db_path))


def _create_engine(db_path: str):
    """Create a SQLAlchemy engine for SQLite."""
    try:
        from sqlalchemy import create_engine
        return create_engine(f"sqlite:///{db_path}")
    except ImportError:
        pytest.skip("sqlalchemy not installed")


class TestE2EPassingFixture:
    """All assertions should pass against the clean fixture database."""

    def test_full_pipeline_passes(self) -> None:
        cfg = parse_config(_load_config("fixture.yaml", "passing.db"))
        engine = _create_engine(str(FIXTURES_DIR / "passing.db"))
        adapter = SqlAdapter(cfg, engine=engine)
        runner = AuditRunner(adapter=adapter)
        results = runner.run()

        assert len(results) >= 5
        # All should pass (drift may warn due to stale snapshots)
        for r in results:
            assert r.status in ("pass", "warn", "skip"), f"{r.assertion_id} unexpected: {r.status} - {r.message}"

    def test_exit_code_zero(self) -> None:
        cfg = parse_config(_load_config("fixture.yaml", "passing.db"))
        engine = _create_engine(str(FIXTURES_DIR / "passing.db"))
        adapter = SqlAdapter(cfg, engine=engine)
        runner = AuditRunner(adapter=adapter)
        results = runner.run()
        assert compute_exit_code(results) == 0

    def test_text_output_readable(self) -> None:
        cfg = parse_config(_load_config("fixture.yaml", "passing.db"))
        engine = _create_engine(str(FIXTURES_DIR / "passing.db"))
        adapter = SqlAdapter(cfg, engine=engine)
        runner = AuditRunner(adapter=adapter)
        results = runner.run()
        text = format_results(results)
        assert "nw-001" in text
        assert "Results:" in text

    def test_json_output_valid(self) -> None:
        cfg = parse_config(_load_config("fixture.yaml", "passing.db"))
        engine = _create_engine(str(FIXTURES_DIR / "passing.db"))
        adapter = SqlAdapter(cfg, engine=engine)
        runner = AuditRunner(adapter=adapter)
        results = runner.run()
        output = format_results_json(results)
        data = json.loads(output)
        assert data["summary"]["failed"] == 0
        assert data["summary"]["total"] >= 5


class TestE2EFailingFixture:
    """Should detect overlaps, sign errors, and drift in the failing fixture."""

    def test_detects_failures(self) -> None:
        cfg = parse_config(_load_config("fixture.yaml", "failing.db"))
        engine = _create_engine(str(FIXTURES_DIR / "failing.db"))
        adapter = SqlAdapter(cfg, engine=engine)
        runner = AuditRunner(adapter=adapter)
        results = runner.run()

        statuses = {r.assertion_id: r.status for r in results}
        # Overlap: a1 and a2 are duplicates across users
        assert statuses["overlap-001"] == "fail"
        # Sign: a3 has negative credit balance
        assert statuses["sign-001"] == "fail"
        # Drift: a4 has account=$10000 but snapshot=$5000
        assert statuses["drift-001"] == "fail"

    def test_exit_code_one(self) -> None:
        cfg = parse_config(_load_config("fixture.yaml", "failing.db"))
        engine = _create_engine(str(FIXTURES_DIR / "failing.db"))
        adapter = SqlAdapter(cfg, engine=engine)
        runner = AuditRunner(adapter=adapter)
        results = runner.run()
        assert compute_exit_code(results) == 1

    def test_evidence_contains_account_ids(self) -> None:
        cfg = parse_config(_load_config("fixture.yaml", "failing.db"))
        engine = _create_engine(str(FIXTURES_DIR / "failing.db"))
        adapter = SqlAdapter(cfg, engine=engine)
        runner = AuditRunner(adapter=adapter)
        results = runner.run()

        # Check that failing assertions include identifiable references in evidence
        for r in results:
            if r.status == "fail":
                assert len(r.evidence) > 0, f"{r.assertion_id} failed but has no evidence"
                # Verify evidence references specific IDs from fixture
                all_evidence_text = " ".join(
                    f"{e.field} {e.expected} {e.actual}" for e in r.evidence
                )
                known_refs = ("a1", "a2", "a3", "a4", "a5", "deleted-acct",
                              "h1", "h2", "h3", "AAPL", "SPY", "GOOF")
                has_ref = any(ref in all_evidence_text for ref in known_refs)
                assert has_ref, (
                    f"{r.assertion_id} evidence should reference known IDs, got: {all_evidence_text}"
                )

    def test_json_output_has_failures(self) -> None:
        cfg = parse_config(_load_config("fixture.yaml", "failing.db"))
        engine = _create_engine(str(FIXTURES_DIR / "failing.db"))
        adapter = SqlAdapter(cfg, engine=engine)
        runner = AuditRunner(adapter=adapter)
        results = runner.run()
        output = format_results_json(results)
        data = json.loads(output)
        assert data["summary"]["failed"] >= 3

    def test_github_actions_annotations(self) -> None:
        cfg = parse_config(_load_config("fixture.yaml", "failing.db"))
        engine = _create_engine(str(FIXTURES_DIR / "failing.db"))
        adapter = SqlAdapter(cfg, engine=engine)
        runner = AuditRunner(adapter=adapter)
        results = runner.run()
        text = format_results_github(results)
        assert "::error::" in text


class TestE2EDryRun:
    def test_dry_run_shows_sql(self) -> None:
        cfg = parse_config(_load_config("fixture.yaml", "passing.db"))
        adapter = SqlAdapter(cfg)  # No engine
        queries = adapter.get_queries()
        assert "accounts" in queries
        assert "SELECT" in queries["accounts"]
        assert "holdings" in queries
        assert "snapshots" in queries

    def test_dry_run_no_db_connection(self) -> None:
        """Dry run should work without a database connection."""
        cfg = parse_config(_load_config("fixture.yaml", "passing.db"))
        adapter = SqlAdapter(cfg)  # No engine
        # Should not raise
        assert adapter.load_accounts() == []


class TestE2ETransactionAssertions:
    """Verify transaction assertions work against fixture databases."""

    def test_passing_fixture_all_8_pass(self) -> None:
        cfg = parse_config(_load_config("fixture.yaml", "passing.db"))
        engine = _create_engine(str(FIXTURES_DIR / "passing.db"))
        adapter = SqlAdapter(cfg, engine=engine)
        runner = AuditRunner(adapter=adapter)
        results = runner.run()

        assert len(results) >= 8
        for r in results:
            assert r.status in ("pass", "warn", "skip"), f"{r.assertion_id}: {r.status} - {r.message}"

    def test_failing_fixture_txn_assertions(self) -> None:
        cfg = parse_config(_load_config("fixture.yaml", "failing.db"))
        engine = _create_engine(str(FIXTURES_DIR / "failing.db"))
        adapter = SqlAdapter(cfg, engine=engine)
        runner = AuditRunner(adapter=adapter)
        results = runner.run()

        statuses = {r.assertion_id: r.status for r in results}
        assert statuses["txn-001"] == "fail"
        assert statuses["txn-002"] == "fail"
        assert statuses["txn-003"] == "warn"

    def test_failing_fixture_json_txn_evidence(self) -> None:
        cfg = parse_config(_load_config("fixture.yaml", "failing.db"))
        engine = _create_engine(str(FIXTURES_DIR / "failing.db"))
        adapter = SqlAdapter(cfg, engine=engine)
        runner = AuditRunner(adapter=adapter)
        results = runner.run()
        output = format_results_json(results)
        data = json.loads(output)

        txn_results = [r for r in data["results"] if r["assertion_id"].startswith("txn-")]
        assert len(txn_results) == 5  # txn-001, txn-002, txn-003, txn-004, txn-005
        for r in txn_results:
            if r["status"] in ("fail", "warn"):
                assert len(r["evidence"]) > 0
                for e in r["evidence"]:
                    assert "field" in e
                    assert "expected" in e
                    assert "actual" in e

    def test_failing_fixture_github_txn_annotations(self) -> None:
        cfg = parse_config(_load_config("fixture.yaml", "failing.db"))
        engine = _create_engine(str(FIXTURES_DIR / "failing.db"))
        adapter = SqlAdapter(cfg, engine=engine)
        runner = AuditRunner(adapter=adapter)
        results = runner.run()
        text = format_results_github(results)
        assert "txn-001" in text
        assert "txn-002" in text
        assert "txn-003" in text

    def test_dry_run_shows_transaction_query(self) -> None:
        cfg = parse_config(_load_config("fixture.yaml", "passing.db"))
        adapter = SqlAdapter(cfg)
        queries = adapter.get_queries()
        assert "transactions" in queries
        assert "SELECT" in queries["transactions"]

    def test_only_txn_001_filter(self) -> None:
        cfg = parse_config(_load_config("fixture.yaml", "passing.db"))
        engine = _create_engine(str(FIXTURES_DIR / "passing.db"))
        adapter = SqlAdapter(cfg, engine=engine)
        runner = AuditRunner(adapter=adapter, only={"txn-001"})
        results = runner.run()
        assert len(results) == 1
        assert results[0].assertion_id == "txn-001"

    def test_only_txn_001_003_filter(self) -> None:
        cfg = parse_config(_load_config("fixture.yaml", "passing.db"))
        engine = _create_engine(str(FIXTURES_DIR / "passing.db"))
        adapter = SqlAdapter(cfg, engine=engine)
        runner = AuditRunner(adapter=adapter, only={"txn-001", "txn-003"})
        results = runner.run()
        ids = [r.assertion_id for r in results]
        assert ids == ["txn-001", "txn-003"]


class TestE2EFilterOnly:
    def test_only_runs_selected_assertions(self) -> None:
        cfg = parse_config(_load_config("fixture.yaml", "passing.db"))
        engine = _create_engine(str(FIXTURES_DIR / "passing.db"))
        adapter = SqlAdapter(cfg, engine=engine)
        runner = AuditRunner(
            adapter=adapter,
            only={"nw-001", "sign-001"},
        )
        results = runner.run()
        ids = [r.assertion_id for r in results]
        assert ids == ["nw-001", "sign-001"]


class TestE2EV030Assertions:
    """Verify all 23 assertions work against fixture databases."""

    def test_passing_fixture_23_assertions(self) -> None:
        cfg = parse_config(_load_config("fixture.yaml", "passing.db"))
        engine = _create_engine(str(FIXTURES_DIR / "passing.db"))
        adapter = SqlAdapter(cfg, engine=engine)
        runner = AuditRunner(adapter=adapter)
        results = runner.run()

        assert len(results) == 23
        for r in results:
            assert r.status in ("pass", "warn", "skip"), (
                f"{r.assertion_id}: {r.status} - {r.message}"
            )

    def test_failing_bal001_in_output(self) -> None:
        cfg = parse_config(_load_config("fixture.yaml", "failing.db"))
        engine = _create_engine(str(FIXTURES_DIR / "failing.db"))
        adapter = SqlAdapter(cfg, engine=engine)
        runner = AuditRunner(adapter=adapter)
        results = runner.run()
        statuses = {r.assertion_id: r.status for r in results}
        assert statuses["bal-001"] == "fail"

    def test_failing_hold001_in_output(self) -> None:
        cfg = parse_config(_load_config("fixture.yaml", "failing.db"))
        engine = _create_engine(str(FIXTURES_DIR / "failing.db"))
        adapter = SqlAdapter(cfg, engine=engine)
        runner = AuditRunner(adapter=adapter)
        results = runner.run()
        statuses = {r.assertion_id: r.status for r in results}
        assert statuses["hold-001"] == "fail"

    def test_failing_hold002_in_output(self) -> None:
        cfg = parse_config(_load_config("fixture.yaml", "failing.db"))
        engine = _create_engine(str(FIXTURES_DIR / "failing.db"))
        adapter = SqlAdapter(cfg, engine=engine)
        runner = AuditRunner(adapter=adapter)
        results = runner.run()
        statuses = {r.assertion_id: r.status for r in results}
        assert statuses["hold-002"] == "fail"

    def test_failing_liab001_in_output(self) -> None:
        cfg = parse_config(_load_config("fixture.yaml", "failing.db"))
        engine = _create_engine(str(FIXTURES_DIR / "failing.db"))
        adapter = SqlAdapter(cfg, engine=engine)
        runner = AuditRunner(adapter=adapter)
        results = runner.run()
        statuses = {r.assertion_id: r.status for r in results}
        assert statuses["liab-001"] == "fail"

    def test_failing_txn004_in_output(self) -> None:
        cfg = parse_config(_load_config("fixture.yaml", "failing.db"))
        engine = _create_engine(str(FIXTURES_DIR / "failing.db"))
        adapter = SqlAdapter(cfg, engine=engine)
        runner = AuditRunner(adapter=adapter)
        results = runner.run()
        statuses = {r.assertion_id: r.status for r in results}
        assert statuses["txn-004"] == "warn"

    def test_failing_comp001_in_output(self) -> None:
        cfg = parse_config(_load_config("fixture.yaml", "failing.db"))
        engine = _create_engine(str(FIXTURES_DIR / "failing.db"))
        adapter = SqlAdapter(cfg, engine=engine)
        runner = AuditRunner(adapter=adapter)
        results = runner.run()
        statuses = {r.assertion_id: r.status for r in results}
        assert statuses["comp-001"] == "warn"

    def test_failing_acct001_in_output(self) -> None:
        cfg = parse_config(_load_config("fixture.yaml", "failing.db"))
        engine = _create_engine(str(FIXTURES_DIR / "failing.db"))
        adapter = SqlAdapter(cfg, engine=engine)
        runner = AuditRunner(adapter=adapter)
        results = runner.run()
        statuses = {r.assertion_id: r.status for r in results}
        # a5 has stale snapshot (30 days old)
        assert statuses["acct-001"] == "warn"

    def test_json_contains_new_assertion_ids(self) -> None:
        cfg = parse_config(_load_config("fixture.yaml", "failing.db"))
        engine = _create_engine(str(FIXTURES_DIR / "failing.db"))
        adapter = SqlAdapter(cfg, engine=engine)
        runner = AuditRunner(adapter=adapter)
        results = runner.run()
        output = format_results_json(results)
        data = json.loads(output)
        ids = [r["assertion_id"] for r in data["results"]]
        assert len(ids) == 23
        for aid in ("bal-001", "alloc-001", "acct-001", "hold-001",
                     "liab-001", "txn-004", "hold-002", "comp-001"):
            assert aid in ids

    def test_json_evidence_structure(self) -> None:
        cfg = parse_config(_load_config("fixture.yaml", "failing.db"))
        engine = _create_engine(str(FIXTURES_DIR / "failing.db"))
        adapter = SqlAdapter(cfg, engine=engine)
        runner = AuditRunner(adapter=adapter)
        results = runner.run()
        output = format_results_json(results)
        data = json.loads(output)
        for r in data["results"]:
            if r["status"] in ("fail", "warn") and r["evidence"]:
                for e in r["evidence"]:
                    assert "field" in e
                    assert "expected" in e
                    assert "actual" in e

    def test_github_actions_new_failures(self) -> None:
        cfg = parse_config(_load_config("fixture.yaml", "failing.db"))
        engine = _create_engine(str(FIXTURES_DIR / "failing.db"))
        adapter = SqlAdapter(cfg, engine=engine)
        runner = AuditRunner(adapter=adapter)
        results = runner.run()
        text = format_results_github(results)
        assert "bal-001" in text
        assert "hold-001" in text
        assert "hold-002" in text
        assert "liab-001" in text

    def test_only_filter_new_ids(self) -> None:
        cfg = parse_config(_load_config("fixture.yaml", "passing.db"))
        engine = _create_engine(str(FIXTURES_DIR / "passing.db"))
        adapter = SqlAdapter(cfg, engine=engine)
        runner = AuditRunner(adapter=adapter, only={"bal-001", "hold-001"})
        results = runner.run()
        assert len(results) == 2

    def test_dry_run_shows_liabilities_query(self) -> None:
        cfg = parse_config(_load_config("fixture.yaml", "passing.db"))
        adapter = SqlAdapter(cfg)
        queries = adapter.get_queries()
        assert "liabilities" in queries
        assert "SELECT" in queries["liabilities"]

    def test_dry_run_shows_category_column(self) -> None:
        cfg = parse_config(_load_config("fixture.yaml", "passing.db"))
        adapter = SqlAdapter(cfg)
        queries = adapter.get_queries()
        assert "category" in queries["transactions"]
