"""Tests for assertion registration sync between runner and CLI."""

from __future__ import annotations

from finlint_audit.runner import BUILTIN_ASSERTIONS
from finlint_audit.cli import _NAME_TO_ID


class TestRegistrationSync:
    def test_every_builtin_has_config_name(self) -> None:
        """Every assertion ID in BUILTIN_ASSERTIONS must appear as a value in _NAME_TO_ID."""
        builtin_ids = {aid for aid, _fn in BUILTIN_ASSERTIONS}
        cli_ids = set(_NAME_TO_ID.values())
        missing = builtin_ids - cli_ids
        assert not missing, f"Assertions registered in runner but missing from CLI config: {missing}"

    def test_every_config_name_has_builtin(self) -> None:
        """Every assertion ID in _NAME_TO_ID must appear in BUILTIN_ASSERTIONS."""
        builtin_ids = {aid for aid, _fn in BUILTIN_ASSERTIONS}
        cli_ids = set(_NAME_TO_ID.values())
        orphaned = cli_ids - builtin_ids
        assert not orphaned, f"Config names in CLI map to non-existent assertions: {orphaned}"

    def test_no_duplicate_assertion_ids(self) -> None:
        """No duplicate assertion IDs in BUILTIN_ASSERTIONS."""
        ids = [aid for aid, _fn in BUILTIN_ASSERTIONS]
        assert len(ids) == len(set(ids)), f"Duplicate assertion IDs: {[x for x in ids if ids.count(x) > 1]}"

    def test_no_duplicate_config_names(self) -> None:
        """No duplicate config names in _NAME_TO_ID."""
        # dict keys are inherently unique, but values could repeat
        values = list(_NAME_TO_ID.values())
        assert len(values) == len(set(values)), f"Duplicate config name targets: {[x for x in values if values.count(x) > 1]}"

    def test_bidirectional_count_match(self) -> None:
        """Same number of entries in both registrations."""
        assert len(BUILTIN_ASSERTIONS) == len(_NAME_TO_ID), (
            f"BUILTIN_ASSERTIONS has {len(BUILTIN_ASSERTIONS)} entries, "
            f"_NAME_TO_ID has {len(_NAME_TO_ID)} entries"
        )
