"""Tests for inv-001: Uninvested Cash Gap."""

from decimal import Decimal

from finlint_audit.assertions.uninvested_cash_gap import assert_uninvested_cash_gap
from tests.helpers import make_account, make_ctx, make_holding


class TestUninvestedCashGap:
    """Blackbox tests for inv-001."""

    def test_empty_accounts(self):
        r = assert_uninvested_cash_gap(make_ctx())
        assert r.status == "pass"
        assert r.assertion_id == "inv-001"

    def test_no_investment_accounts(self):
        r = assert_uninvested_cash_gap(make_ctx(
            accounts=[make_account("a1", "depository", 5000)],
        ))
        assert r.status == "pass"

    def test_exact_match_passes(self):
        r = assert_uninvested_cash_gap(make_ctx(
            accounts=[make_account("a1", "investment", 10000)],
            holdings=[make_holding("h1", "a1", 10000)],
        ))
        assert r.status == "pass"
        assert r.metadata["flagged_count"] == "0"

    def test_small_gap_passes(self):
        """3% gap is below default 5% threshold."""
        r = assert_uninvested_cash_gap(make_ctx(
            accounts=[make_account("a1", "investment", 10000)],
            holdings=[make_holding("h1", "a1", 9700)],
        ))
        assert r.status == "pass"

    def test_large_gap_warns(self):
        """20% gap exceeds default 5% threshold."""
        r = assert_uninvested_cash_gap(make_ctx(
            accounts=[make_account("a1", "investment", 10000)],
            holdings=[make_holding("h1", "a1", 8000)],
        ))
        assert r.status == "warn"
        assert r.metadata["flagged_count"] == "1"
        assert len(r.evidence) == 1
        assert "a1" in r.evidence[0].field

    def test_negative_gap_warns(self):
        """Holdings exceed balance (margin, options). Still flags."""
        r = assert_uninvested_cash_gap(make_ctx(
            accounts=[make_account("a1", "investment", 10000)],
            holdings=[make_holding("h1", "a1", 12000)],
        ))
        assert r.status == "warn"

    def test_multiple_holdings_summed(self):
        """Multiple holdings for one account are summed."""
        r = assert_uninvested_cash_gap(make_ctx(
            accounts=[make_account("a1", "investment", 10000)],
            holdings=[
                make_holding("h1", "a1", 5000),
                make_holding("h2", "a1", 4800),
            ],
        ))
        assert r.status == "pass"

    def test_mixed_accounts(self):
        """Only investment accounts checked, depository ignored."""
        r = assert_uninvested_cash_gap(make_ctx(
            accounts=[
                make_account("a1", "investment", 10000),
                make_account("a2", "depository", 50000),
            ],
            holdings=[make_holding("h1", "a1", 9800)],
        ))
        assert r.status == "pass"

    def test_inactive_skipped(self):
        r = assert_uninvested_cash_gap(make_ctx(
            accounts=[make_account("a1", "investment", 10000, is_active=False)],
            holdings=[make_holding("h1", "a1", 5000)],
        ))
        assert r.status == "pass"
        assert "No investment accounts" in r.message

    def test_zero_balance_skipped(self):
        """Accounts below min_balance are skipped."""
        r = assert_uninvested_cash_gap(make_ctx(
            accounts=[make_account("a1", "investment", 0)],
            holdings=[],
        ))
        assert r.status == "pass"

    def test_below_min_balance_skipped(self):
        r = assert_uninvested_cash_gap(make_ctx(
            accounts=[make_account("a1", "investment", 50)],
            holdings=[make_holding("h1", "a1", 10)],
        ))
        assert r.status == "pass"

    def test_no_holdings_skipped(self):
        """Accounts with NO holdings are skipped (comp-001 handles that)."""
        r = assert_uninvested_cash_gap(make_ctx(
            accounts=[make_account("a1", "investment", 10000)],
            holdings=[],
        ))
        assert r.status == "pass"

    def test_custom_max_gap(self):
        """Custom max_cash_gap_pct of 20%."""
        r = assert_uninvested_cash_gap(make_ctx(
            accounts=[make_account("a1", "investment", 10000)],
            holdings=[make_holding("h1", "a1", 8500)],
            params={"max_cash_gap_pct": "0.20"},
        ))
        assert r.status == "pass"

    def test_custom_min_balance(self):
        r = assert_uninvested_cash_gap(make_ctx(
            accounts=[make_account("a1", "investment", 200)],
            holdings=[make_holding("h1", "a1", 100)],
            params={"min_balance": "500"},
        ))
        assert r.status == "pass"

    def test_multiple_flagged(self):
        r = assert_uninvested_cash_gap(make_ctx(
            accounts=[
                make_account("a1", "investment", 10000),
                make_account("a2", "investment", 20000),
            ],
            holdings=[
                make_holding("h1", "a1", 5000),
                make_holding("h2", "a2", 10000),
            ],
        ))
        assert r.status == "warn"
        assert r.metadata["flagged_count"] == "2"

    def test_evidence_format(self):
        r = assert_uninvested_cash_gap(make_ctx(
            accounts=[make_account("a1", "investment", 10000)],
            holdings=[make_holding("h1", "a1", 8000)],
        ))
        assert r.evidence[0].field == "account.id=a1"
        assert "gap" in r.evidence[0].actual.lower()

    def test_boundary_at_threshold(self):
        """Exactly 5% gap should not warn (> not >=)."""
        r = assert_uninvested_cash_gap(make_ctx(
            accounts=[make_account("a1", "investment", 10000)],
            holdings=[make_holding("h1", "a1", 9500)],
        ))
        assert r.status == "pass"
