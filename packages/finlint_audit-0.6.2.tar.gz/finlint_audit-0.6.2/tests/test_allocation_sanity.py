"""Tests for allocation sanity assertion (alloc-001)."""

from decimal import Decimal

import pytest

from finlint_audit.assertions.allocation_sanity import assert_allocation_sanity

from tests.helpers import make_ctx as _ctx, make_account as _acct, make_holding as _hold


# ── Blackbox tests ──────────────────────────────────────────────────


class TestAllocationSanityBlackbox:
    def test_empty_dataset(self) -> None:
        result = assert_allocation_sanity(_ctx())
        assert result.status == "pass"
        assert result.assertion_id == "alloc-001"

    def test_no_investment_accounts(self) -> None:
        result = assert_allocation_sanity(
            _ctx(accounts=[
                _acct("a1", "depository", balance=5000),
                _acct("a2", "depository", balance=3000),
            ])
        )
        assert result.status == "pass"
        assert "No investment accounts" in result.message

    def test_allocation_100_percent(self) -> None:
        result = assert_allocation_sanity(
            _ctx(
                accounts=[_acct("a1", "investment", balance=50000)],
                holdings=[_hold("h1", "a1", 50000)],
            )
        )
        assert result.status == "pass"

    def test_allocation_99_percent(self) -> None:
        result = assert_allocation_sanity(
            _ctx(
                accounts=[_acct("a1", "investment", balance=50000)],
                holdings=[_hold("h1", "a1", 49500)],
            )
        )
        assert result.status == "pass"

    def test_allocation_95_percent(self) -> None:
        result = assert_allocation_sanity(
            _ctx(
                accounts=[_acct("a1", "investment", balance=50000)],
                holdings=[_hold("h1", "a1", 47500)],
            )
        )
        assert result.status == "pass"

    def test_allocation_under_90_percent(self) -> None:
        result = assert_allocation_sanity(
            _ctx(
                accounts=[_acct("a1", "investment", balance=50000)],
                holdings=[_hold("h1", "a1", 40000)],
            )
        )
        assert result.status == "warn"
        assert len(result.evidence) == 1

    def test_allocation_over_110_percent(self) -> None:
        result = assert_allocation_sanity(
            _ctx(
                accounts=[_acct("a1", "investment", balance=50000)],
                holdings=[_hold("h1", "a1", 60000)],
            )
        )
        assert result.status == "warn"
        assert len(result.evidence) == 1

    def test_allocation_89_percent(self) -> None:
        # 44500/50000 = 89%
        result = assert_allocation_sanity(
            _ctx(
                accounts=[_acct("a1", "investment", balance=50000)],
                holdings=[_hold("h1", "a1", 44500)],
            )
        )
        assert result.status == "warn"

    def test_multiple_accounts_mixed(self) -> None:
        result = assert_allocation_sanity(
            _ctx(
                accounts=[
                    _acct("a1", "investment", balance=50000),
                    _acct("a2", "investment", balance=50000),
                ],
                holdings=[
                    _hold("h1", "a1", 50000),   # 100% - good
                    _hold("h2", "a2", 40000),   # 80% - bad
                ],
            )
        )
        assert result.status == "warn"
        assert len(result.evidence) == 1
        assert "a2" in result.evidence[0].field

    def test_multiple_holdings_aggregate(self) -> None:
        result = assert_allocation_sanity(
            _ctx(
                accounts=[_acct("a1", "investment", balance=50000)],
                holdings=[
                    _hold("h1", "a1", 12500),
                    _hold("h2", "a1", 12500),
                    _hold("h3", "a1", 12500),
                    _hold("h4", "a1", 12500),
                ],
            )
        )
        assert result.status == "pass"


# ── Whitebox tests ──────────────────────────────────────────────────


class TestAllocationSanityWhitebox:
    def test_custom_low_threshold(self) -> None:
        # 93% is below custom low of 95
        result = assert_allocation_sanity(
            _ctx(
                accounts=[_acct("a1", "investment", balance=50000)],
                holdings=[_hold("h1", "a1", 46500)],
                params={"low_threshold": "95"},
            )
        )
        assert result.status == "warn"

    def test_custom_high_threshold(self) -> None:
        # 107% is above custom high of 105
        result = assert_allocation_sanity(
            _ctx(
                accounts=[_acct("a1", "investment", balance=50000)],
                holdings=[_hold("h1", "a1", 53500)],
                params={"high_threshold": "105"},
            )
        )
        assert result.status == "warn"

    def test_zero_balance_skipped(self) -> None:
        result = assert_allocation_sanity(
            _ctx(
                accounts=[_acct("a1", "investment", balance=0)],
                holdings=[],
            )
        )
        assert result.status == "pass"

    def test_negative_balance_skipped(self) -> None:
        result = assert_allocation_sanity(
            _ctx(
                accounts=[_acct("a1", "investment", balance=-5000)],
                holdings=[],
            )
        )
        assert result.status == "pass"

    def test_very_small_balance_skipped(self) -> None:
        result = assert_allocation_sanity(
            _ctx(
                accounts=[_acct("a1", "investment", balance="0.50")],
                holdings=[],
            )
        )
        assert result.status == "pass"

    def test_boundary_exactly_90(self) -> None:
        # 45000/50000 = 90% exactly - should pass
        result = assert_allocation_sanity(
            _ctx(
                accounts=[_acct("a1", "investment", balance=50000)],
                holdings=[_hold("h1", "a1", 45000)],
            )
        )
        assert result.status == "pass"

    def test_boundary_exactly_110(self) -> None:
        # 55000/50000 = 110% exactly - should pass
        result = assert_allocation_sanity(
            _ctx(
                accounts=[_acct("a1", "investment", balance=50000)],
                holdings=[_hold("h1", "a1", 55000)],
            )
        )
        assert result.status == "pass"

    def test_inactive_skipped(self) -> None:
        result = assert_allocation_sanity(
            _ctx(
                accounts=[_acct("a1", "investment", balance=50000, is_active=False)],
                holdings=[_hold("h1", "a1", 10000)],  # 20% - would warn if checked
            )
        )
        assert result.status == "pass"
        assert "No investment accounts" in result.message

    def test_metadata_flagged_count(self) -> None:
        result = assert_allocation_sanity(
            _ctx(
                accounts=[
                    _acct("a1", "investment", balance=50000),
                    _acct("a2", "investment", balance=50000),
                ],
                holdings=[
                    _hold("h1", "a1", 40000),   # 80% - flagged
                    _hold("h2", "a2", 40000),   # 80% - flagged
                ],
            )
        )
        assert result.status == "warn"
        assert result.metadata["flagged_count"] == "2"

    def test_evidence_shows_percentage(self) -> None:
        result = assert_allocation_sanity(
            _ctx(
                accounts=[_acct("a1", "investment", balance=50000)],
                holdings=[_hold("h1", "a1", 40000)],
            )
        )
        assert result.status == "warn"
        assert "80" in result.evidence[0].actual
