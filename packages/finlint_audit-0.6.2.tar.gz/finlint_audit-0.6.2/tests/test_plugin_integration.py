"""Integration tests — full pipeline with plugin fixtures."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import pytest

from finlint_audit.adapters.memory import MemoryAdapter
from finlint_audit.cli import compute_exit_code, format_results, format_results_github, format_results_json
from finlint_audit.config import PluginConfig, parse_config
from finlint_audit.runner import AuditRunner
from tests.helpers import make_account

# Ensure fixtures importable
_FIXTURES_DIR = Path(__file__).parent / "fixtures"
if str(_FIXTURES_DIR.parent) not in sys.path:
    sys.path.insert(0, str(_FIXTURES_DIR.parent))


def _adapter():
    return MemoryAdapter(accounts=[make_account("a1", "depository", balance=1000)])


def _plugin(id="custom-001", module="fixtures.sample_plugin", function="assert_sample", **kw):
    return PluginConfig(id=id, module=module, function=function, **kw)


_YAML_WITH_PLUGIN = """\
version: "1"
database:
  type: sqlite
  connection: "test.db"
mapping:
  accounts:
    table: accounts
    columns:
      id: id
plugins:
  - id: "custom-001"
    module: "fixtures.sample_plugin"
    function: "assert_sample"
"""


class TestYamlWithPluginFullPipeline:
    def test_parse_and_run(self):
        cfg = parse_config(_YAML_WITH_PLUGIN)
        runner = AuditRunner(adapter=_adapter(), plugins=cfg.plugins)
        results = runner.run()
        text = format_results(results)
        assert "custom-001" in text
        assert len(results) == 24


class TestYamlWithMultiplePlugins:
    def test_three_plugins(self):
        plugins = [
            _plugin(id="alpha-001"),
            _plugin(id="beta-001"),
            _plugin(id="gamma-001"),
        ]
        runner = AuditRunner(adapter=_adapter(), plugins=plugins)
        results = runner.run()
        text = format_results(results)
        assert "alpha-001" in text
        assert "beta-001" in text
        assert "gamma-001" in text


class TestYamlDisabledPluginNotInOutput:
    def test_disabled(self):
        plugins = [_plugin(enabled=False)]
        runner = AuditRunner(adapter=_adapter(), plugins=plugins)
        results = runner.run()
        assert all(r.assertion_id != "custom-001" for r in results)
        assert len(results) == 23


class TestYamlPluginParamsFlowToFunction:
    def test_params(self):
        plugins = [_plugin(
            id="param-001",
            module="fixtures.param_plugin",
            function="assert_with_params",
            params={"threshold": "5.00"},
        )]
        runner = AuditRunner(adapter=_adapter(), plugins=plugins)
        results = runner.run()
        p_result = [r for r in results if r.assertion_id == "param-001"][0]
        assert p_result.metadata["threshold"] == "5.00"


class TestYamlBadPluginGracefulDegradation:
    def test_bad_module(self):
        plugins = [
            _plugin(id="bad-001", module="nonexistent.mod"),
            _plugin(id="good-001"),
        ]
        runner = AuditRunner(adapter=_adapter(), plugins=plugins)
        results = runner.run()
        # Bad plugin produces fail result, good plugin still runs
        bad = [r for r in results if r.assertion_id == "bad-001"]
        good = [r for r in results if r.assertion_id == "good-001"]
        assert len(bad) == 1
        assert bad[0].status == "fail"
        assert len(good) == 1


class TestYamlPluginWithBuiltinAssertions:
    def test_combined(self):
        plugins = [_plugin()]
        runner = AuditRunner(adapter=_adapter(), plugins=plugins)
        results = runner.run()
        assert len(results) == 24
        ids = {r.assertion_id for r in results}
        assert "nw-001" in ids
        assert "custom-001" in ids


class TestJsonOutputIncludesPluginResults:
    def test_json(self):
        plugins = [_plugin()]
        runner = AuditRunner(adapter=_adapter(), plugins=plugins)
        results = runner.run()
        data = json.loads(format_results_json(results))
        ids = [r["assertion_id"] for r in data["results"]]
        assert "custom-001" in ids


class TestGitHubActionsOutputIncludesPlugins:
    def test_github_actions(self):
        plugins = [_plugin(
            id="fail-001",
            module="fixtures.failing_plugin",
            function="assert_failing",
        )]
        runner = AuditRunner(adapter=_adapter(), plugins=plugins)
        results = runner.run()
        output = format_results_github(results)
        assert "fail-001" in output
        assert "::error" in output


class TestTextOutputPluginSection:
    def test_text(self):
        plugins = [_plugin()]
        runner = AuditRunner(adapter=_adapter(), plugins=plugins)
        results = runner.run()
        text = format_results(results)
        assert "custom-001" in text
        assert "passed" in text


class TestExitCode1OnPluginFailure:
    def test_exit_code(self):
        plugins = [_plugin(
            id="fail-001",
            module="fixtures.failing_plugin",
            function="assert_failing",
        )]
        runner = AuditRunner(adapter=_adapter(), plugins=plugins)
        results = runner.run()
        assert compute_exit_code(results) == 1
