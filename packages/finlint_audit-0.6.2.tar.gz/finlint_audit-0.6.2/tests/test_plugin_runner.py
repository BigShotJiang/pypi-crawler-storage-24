"""Runner tests with plugin assertions."""

from __future__ import annotations

import sys
from pathlib import Path

from finlint_audit.adapters.memory import MemoryAdapter
from finlint_audit.config import PluginConfig
from finlint_audit.runner import AuditRunner
from tests.helpers import make_account

# Ensure test fixtures are importable
_FIXTURES_DIR = Path(__file__).parent / "fixtures"
if str(_FIXTURES_DIR.parent) not in sys.path:
    sys.path.insert(0, str(_FIXTURES_DIR.parent))


def _adapter():
    return MemoryAdapter(accounts=[make_account("a1", "depository", balance=1000)])


def _plugin(id="custom-001", module="fixtures.sample_plugin", function="assert_sample", **kw):
    return PluginConfig(id=id, module=module, function=function, **kw)


# ── Blackbox tests ──────────────────────────────────────────────────

class TestBuiltinsRunWithoutPlugins:
    def test_23_results(self):
        runner = AuditRunner(adapter=_adapter())
        results = runner.run()
        assert len(results) == 23


class TestSinglePluginAppended:
    def test_24_results(self):
        runner = AuditRunner(adapter=_adapter(), plugins=[_plugin()])
        results = runner.run()
        assert len(results) == 24
        assert results[-1].assertion_id == "custom-001"


class TestMultiplePluginsAppended:
    def test_26_results(self):
        plugins = [
            _plugin(id="alpha-001"),
            _plugin(id="beta-001"),
            _plugin(id="gamma-001"),
        ]
        runner = AuditRunner(adapter=_adapter(), plugins=plugins)
        results = runner.run()
        assert len(results) == 26


class TestPluginOrderAfterBuiltins:
    def test_order(self):
        plugins = [
            _plugin(id="alpha-001"),
            _plugin(id="beta-001"),
        ]
        runner = AuditRunner(adapter=_adapter(), plugins=plugins)
        results = runner.run()
        assert results[-2].assertion_id == "alpha-001"
        assert results[-1].assertion_id == "beta-001"


class TestPluginReceivesParams:
    def test_params_flow(self):
        runner = AuditRunner(
            adapter=_adapter(),
            plugins=[_plugin(
                id="param-001",
                module="fixtures.param_plugin",
                function="assert_with_params",
                params={"threshold": "5.00"},
            )],
        )
        results = runner.run()
        plugin_result = results[-1]
        assert plugin_result.metadata["threshold"] == "5.00"


class TestPluginResultInOutput:
    def test_failing_plugin(self):
        runner = AuditRunner(
            adapter=_adapter(),
            plugins=[_plugin(
                id="fail-001",
                module="fixtures.failing_plugin",
                function="assert_failing",
            )],
        )
        results = runner.run()
        fail_result = [r for r in results if r.assertion_id == "fail-001"]
        assert len(fail_result) == 1
        assert fail_result[0].status == "fail"


class TestDisabledPluginSkipped:
    def test_disabled(self):
        runner = AuditRunner(
            adapter=_adapter(),
            plugins=[_plugin()],
            disabled={"custom-001"},
        )
        results = runner.run()
        assert all(r.assertion_id != "custom-001" for r in results)
        assert len(results) == 23


class TestOnlyFilterIncludesPlugin:
    def test_only_plugin(self):
        runner = AuditRunner(
            adapter=_adapter(),
            plugins=[_plugin()],
            only={"custom-001"},
        )
        results = runner.run()
        assert len(results) == 1
        assert results[0].assertion_id == "custom-001"


class TestOnlyFilterExcludesPlugin:
    def test_only_builtin(self):
        runner = AuditRunner(
            adapter=_adapter(),
            plugins=[_plugin()],
            only={"nw-001"},
        )
        results = runner.run()
        assert len(results) == 1
        assert results[0].assertion_id == "nw-001"


class TestMixedOnlyBuiltinAndPlugin:
    def test_mixed(self):
        runner = AuditRunner(
            adapter=_adapter(),
            plugins=[_plugin()],
            only={"nw-001", "custom-001"},
        )
        results = runner.run()
        assert len(results) == 2
        ids = {r.assertion_id for r in results}
        assert ids == {"nw-001", "custom-001"}


# ── Whitebox tests ──────────────────────────────────────────────────

class TestPluginExceptionProducesFail:
    def test_exception_caught(self):
        runner = AuditRunner(
            adapter=_adapter(),
            plugins=[_plugin(
                id="boom-001",
                module="fixtures.exception_plugin",
                function="assert_exploding",
            )],
        )
        results = runner.run()
        boom = [r for r in results if r.assertion_id == "boom-001"]
        assert len(boom) == 1
        assert boom[0].status == "fail"
        assert "exploded" in boom[0].message.lower()


class TestPluginExceptionDoesntStopOthers:
    def test_isolation(self):
        plugins = [
            _plugin(id="boom-001", module="fixtures.exception_plugin", function="assert_exploding"),
            _plugin(id="good-001"),
        ]
        runner = AuditRunner(adapter=_adapter(), plugins=plugins)
        results = runner.run()
        ids = {r.assertion_id for r in results}
        assert "boom-001" in ids
        assert "good-001" in ids


class TestBuiltinExceptionDoesntStopPlugins:
    def test_independence(self):
        # Force a built-in to error by passing invalid params
        # Actually let's just verify plugins run even after builtins
        runner = AuditRunner(adapter=_adapter(), plugins=[_plugin()])
        results = runner.run()
        assert results[-1].assertion_id == "custom-001"


class TestPluginSharesLoadedData:
    def test_same_data(self):
        adapter = _adapter()
        runner = AuditRunner(adapter=adapter, plugins=[_plugin(
            id="data-001",
            module="fixtures.param_plugin",
            function="assert_with_params",
        )])
        results = runner.run()
        # Plugin ran successfully — means it got a valid context
        assert results[-1].status == "pass"


class TestPluginParamsIsolated:
    def test_isolation(self):
        plugins = [
            _plugin(id="pa-001", module="fixtures.param_plugin", function="assert_with_params", params={"threshold": "1.00"}),
            _plugin(id="pb-001", module="fixtures.param_plugin", function="assert_with_params", params={"threshold": "99.00"}),
        ]
        runner = AuditRunner(adapter=_adapter(), plugins=plugins)
        results = runner.run()
        pa = [r for r in results if r.assertion_id == "pa-001"][0]
        pb = [r for r in results if r.assertion_id == "pb-001"][0]
        assert pa.metadata["threshold"] == "1.00"
        assert pb.metadata["threshold"] == "99.00"


class TestPluginIdInResult:
    def test_id_propagated(self):
        runner = AuditRunner(adapter=_adapter(), plugins=[_plugin(id="myid-001")])
        results = runner.run()
        assert results[-1].assertion_id == "myid-001"


class TestEmptyPluginsList:
    def test_same_as_no_plugins(self):
        runner = AuditRunner(adapter=_adapter(), plugins=[])
        results = runner.run()
        assert len(results) == 23


class TestWarnPluginFlowsThrough:
    def test_warn_status(self):
        runner = AuditRunner(
            adapter=_adapter(),
            plugins=[_plugin(
                id="warn-001",
                module="fixtures.warn_plugin",
                function="assert_warn",
            )],
        )
        results = runner.run()
        warn_result = [r for r in results if r.assertion_id == "warn-001"]
        assert len(warn_result) == 1
        assert warn_result[0].status == "warn"

    def test_warn_does_not_affect_exit_code(self):
        from finlint_audit.cli import compute_exit_code
        runner = AuditRunner(
            adapter=_adapter(),
            plugins=[_plugin(
                id="warn-001",
                module="fixtures.warn_plugin",
                function="assert_warn",
            )],
        )
        results = runner.run()
        # Warn should not cause exit 1 (only fail does)
        assert compute_exit_code(results) == 0


class TestPluginEnabledFalseSkipped:
    def test_enabled_false(self):
        plugin = _plugin(enabled=False)
        runner = AuditRunner(adapter=_adapter(), plugins=[plugin])
        results = runner.run()
        assert all(r.assertion_id != "custom-001" for r in results)
        assert len(results) == 23


class TestPluginStatusAffectsExitCode:
    def test_fail_exit_1(self):
        from finlint_audit.cli import compute_exit_code
        runner = AuditRunner(
            adapter=_adapter(),
            plugins=[_plugin(
                id="fail-001",
                module="fixtures.failing_plugin",
                function="assert_failing",
            )],
        )
        results = runner.run()
        assert compute_exit_code(results) == 1
