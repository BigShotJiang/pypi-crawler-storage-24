"""Tests for geo-001: Geographic Coverage."""

from decimal import Decimal

from finlint_audit.assertions.geographic_coverage import assert_geographic_coverage
from tests.helpers import make_ctx, make_holding


class TestGeographicCoverage:
    """Blackbox tests for geo-001."""

    def test_empty_holdings(self):
        r = assert_geographic_coverage(make_ctx())
        assert r.status == "pass"
        assert r.assertion_id == "geo-001"

    def test_all_domestic_pass(self):
        r = assert_geographic_coverage(make_ctx(
            holdings=[
                make_holding("h1", "a1", 5000, ticker="VTI"),
                make_holding("h2", "a1", 3000, ticker="SPY"),
                make_holding("h3", "a1", 2000, ticker="QQQ"),
            ],
        ))
        assert r.status == "pass"
        assert Decimal(r.metadata["domestic_pct"]) == Decimal("100.0")
        assert Decimal(r.metadata["international_pct"]) == Decimal("0.0")

    def test_mixed_domestic_international_pass(self):
        r = assert_geographic_coverage(make_ctx(
            holdings=[
                make_holding("h1", "a1", 7000, ticker="VTI"),
                make_holding("h2", "a1", 3000, ticker="VXUS"),
            ],
        ))
        assert r.status == "pass"
        assert Decimal(r.metadata["domestic_pct"]) == Decimal("70.0")
        assert Decimal(r.metadata["international_pct"]) == Decimal("30.0")

    def test_unknown_below_threshold_warns(self):
        """>30% unclassified with default 70% threshold → warn."""
        r = assert_geographic_coverage(make_ctx(
            holdings=[
                make_holding("h1", "a1", 5000, ticker="VTI"),
                make_holding("h2", "a1", 5000, ticker="AAPL"),  # unknown
            ],
        ))
        assert r.status == "warn"
        assert Decimal(r.metadata["classified_pct"]) == Decimal("50.0")

    def test_name_keyword_international(self):
        r = assert_geographic_coverage(make_ctx(
            holdings=[
                make_holding("h1", "a1", 10000, name="Vanguard International Growth Fund"),
            ],
        ))
        assert r.status == "pass"
        assert Decimal(r.metadata["international_pct"]) == Decimal("100.0")

    def test_name_keyword_emerging(self):
        r = assert_geographic_coverage(make_ctx(
            holdings=[
                make_holding("h1", "a1", 10000, name="iShares Emerging Markets ETF"),
            ],
        ))
        assert r.status == "pass"
        assert Decimal(r.metadata["international_pct"]) == Decimal("100.0")

    def test_case_insensitive_ticker(self):
        r = assert_geographic_coverage(make_ctx(
            holdings=[make_holding("h1", "a1", 10000, ticker="vti")],
        ))
        assert r.status == "pass"
        assert Decimal(r.metadata["domestic_pct"]) == Decimal("100.0")

    def test_null_ticker_and_name(self):
        r = assert_geographic_coverage(make_ctx(
            holdings=[make_holding("h1", "a1", 10000)],
        ))
        assert r.status == "warn"

    def test_cash_classified_as_domestic(self):
        r = assert_geographic_coverage(make_ctx(
            holdings=[
                make_holding("h1", "a1", 10000, security_type="cash"),
            ],
        ))
        assert r.status == "pass"
        assert Decimal(r.metadata["domestic_pct"]) == Decimal("100.0")

    def test_fixed_income_classified_as_domestic(self):
        r = assert_geographic_coverage(make_ctx(
            holdings=[
                make_holding("h1", "a1", 10000, security_type="fixed income"),
            ],
        ))
        assert r.status == "pass"

    def test_zero_value_skip(self):
        r = assert_geographic_coverage(make_ctx(
            holdings=[make_holding("h1", "a1", 0)],
        ))
        assert r.status == "pass"
        assert "No holdings with positive value" in r.message

    def test_custom_threshold(self):
        r = assert_geographic_coverage(make_ctx(
            holdings=[
                make_holding("h1", "a1", 5000, ticker="VTI"),
                make_holding("h2", "a1", 5000, ticker="AAPL"),  # unknown
            ],
            params={"min_classified_pct": "0.40"},
        ))
        assert r.status == "pass"

    def test_metadata_values(self):
        r = assert_geographic_coverage(make_ctx(
            holdings=[
                make_holding("h1", "a1", 7000, ticker="VTI"),
                make_holding("h2", "a1", 3000, ticker="VXUS"),
            ],
        ))
        assert r.metadata["total_value"] == "10000"
        assert r.metadata["classified_pct"] == "100.0"

    def test_evidence_on_warn(self):
        r = assert_geographic_coverage(make_ctx(
            holdings=[
                make_holding("h1", "a1", 10000, ticker="AAPL"),
            ],
        ))
        assert len(r.evidence) >= 1
        assert "h1" in r.evidence[0].field
