"""Config parsing tests for plugin section."""

from __future__ import annotations

import pytest

from finlint_audit.config import PluginConfig, parse_config

_MINIMAL_YAML = """\
version: "1"
database:
  type: sqlite
  connection: "test.db"
mapping:
  accounts:
    table: accounts
    columns:
      id: id
"""


def _yaml_with_plugins(plugins_yaml: str) -> str:
    return _MINIMAL_YAML + plugins_yaml


# ── Blackbox tests ──────────────────────────────────────────────────

class TestEmptyPluginsSection:
    def test_empty_list(self):
        cfg = parse_config(_yaml_with_plugins("plugins: []\n"))
        assert cfg.plugins == []


class TestNoPluginsSection:
    def test_backward_compat(self):
        cfg = parse_config(_MINIMAL_YAML)
        assert cfg.plugins == []


class TestSingleValidPlugin:
    def test_happy_path(self):
        cfg = parse_config(_yaml_with_plugins("""\
plugins:
  - id: "custom-001"
    module: "my_company.audits"
    function: "assert_revenue_check"
"""))
        assert len(cfg.plugins) == 1
        p = cfg.plugins[0]
        assert p.id == "custom-001"
        assert p.module == "my_company.audits"
        assert p.function == "assert_revenue_check"
        assert p.enabled is True
        assert p.params == {}


class TestMultiplePlugins:
    def test_ordering_preserved(self):
        cfg = parse_config(_yaml_with_plugins("""\
plugins:
  - id: "alpha-001"
    module: "a"
    function: "f"
  - id: "beta-001"
    module: "b"
    function: "g"
  - id: "gamma-001"
    module: "c"
    function: "h"
"""))
        assert [p.id for p in cfg.plugins] == ["alpha-001", "beta-001", "gamma-001"]


class TestPluginWithParams:
    def test_params_populated(self):
        cfg = parse_config(_yaml_with_plugins("""\
plugins:
  - id: "custom-001"
    module: "m"
    function: "f"
    params:
      threshold: "5.00"
      max_days: 30
"""))
        p = cfg.plugins[0]
        assert p.params == {"threshold": "5.00", "max_days": 30}


class TestPluginDefaults:
    def test_enabled_true_params_empty(self):
        cfg = parse_config(_yaml_with_plugins("""\
plugins:
  - id: "custom-001"
    module: "m"
    function: "f"
"""))
        p = cfg.plugins[0]
        assert p.enabled is True
        assert p.params == {}


class TestPluginDisabled:
    def test_explicit_disable(self):
        cfg = parse_config(_yaml_with_plugins("""\
plugins:
  - id: "custom-001"
    module: "m"
    function: "f"
    enabled: false
"""))
        assert cfg.plugins[0].enabled is False


class TestPluginMissingId:
    def test_error(self):
        with pytest.raises(ValueError, match="missing required 'id'"):
            parse_config(_yaml_with_plugins("""\
plugins:
  - module: "m"
    function: "f"
"""))


class TestPluginMissingModule:
    def test_error(self):
        with pytest.raises(ValueError, match="missing required 'module'"):
            parse_config(_yaml_with_plugins("""\
plugins:
  - id: "custom-001"
    function: "f"
"""))


class TestPluginMissingFunction:
    def test_error(self):
        with pytest.raises(ValueError, match="missing required 'function'"):
            parse_config(_yaml_with_plugins("""\
plugins:
  - id: "custom-001"
    module: "m"
"""))


# ── Whitebox tests ──────────────────────────────────────────────────

class TestPluginIdPatternValid:
    def test_standard(self):
        cfg = parse_config(_yaml_with_plugins("""\
plugins:
  - id: "custom-001"
    module: "m"
    function: "f"
"""))
        assert cfg.plugins[0].id == "custom-001"


class TestPluginIdPatternInvalidCaps:
    def test_uppercase_rejected(self):
        with pytest.raises(ValueError, match="does not match"):
            parse_config(_yaml_with_plugins("""\
plugins:
  - id: "Custom-001"
    module: "m"
    function: "f"
"""))


class TestPluginIdPatternInvalidNoNumber:
    def test_letters_rejected(self):
        with pytest.raises(ValueError, match="does not match"):
            parse_config(_yaml_with_plugins("""\
plugins:
  - id: "custom-abc"
    module: "m"
    function: "f"
"""))


class TestPluginIdPatternInvalidTooManyDigits:
    def test_four_digits_rejected(self):
        with pytest.raises(ValueError, match="does not match"):
            parse_config(_yaml_with_plugins("""\
plugins:
  - id: "custom-0001"
    module: "m"
    function: "f"
"""))


class TestPluginIdCollidesWithBuiltin:
    def test_nw001_rejected(self):
        with pytest.raises(ValueError, match="collides with a built-in"):
            parse_config(_yaml_with_plugins("""\
plugins:
  - id: "nw-001"
    module: "m"
    function: "f"
"""))


class TestPluginIdCollidesWithAnotherPlugin:
    def test_duplicate_rejected(self):
        with pytest.raises(ValueError, match="Duplicate plugin ID"):
            parse_config(_yaml_with_plugins("""\
plugins:
  - id: "custom-001"
    module: "a"
    function: "f"
  - id: "custom-001"
    module: "b"
    function: "g"
"""))


class TestPluginIdSimilarToBuiltinOk:
    def test_nw002_allowed(self):
        cfg = parse_config(_yaml_with_plugins("""\
plugins:
  - id: "nw-002"
    module: "m"
    function: "f"
"""))
        assert cfg.plugins[0].id == "nw-002"


class TestPluginsCombinedWithAssertions:
    def test_both_parsed(self):
        cfg = parse_config(_yaml_with_plugins("""\
assertions:
  net-worth-equation:
    enabled: true
plugins:
  - id: "custom-001"
    module: "m"
    function: "f"
"""))
        assert len(cfg.assertions) == 1
        assert len(cfg.plugins) == 1


class TestPluginParamsAreNativeTypes:
    def test_int_preserved(self):
        cfg = parse_config(_yaml_with_plugins("""\
plugins:
  - id: "custom-001"
    module: "m"
    function: "f"
    params:
      stale_days: 7
      ratio: 0.5
"""))
        p = cfg.plugins[0]
        assert p.params["stale_days"] == 7
        assert p.params["ratio"] == 0.5


class TestPluginModuleWithDots:
    def test_dotted_path(self):
        cfg = parse_config(_yaml_with_plugins("""\
plugins:
  - id: "custom-001"
    module: "my.company.deep.module"
    function: "f"
"""))
        assert cfg.plugins[0].module == "my.company.deep.module"
