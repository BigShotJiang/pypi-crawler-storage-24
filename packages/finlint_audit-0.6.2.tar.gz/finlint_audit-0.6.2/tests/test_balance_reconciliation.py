"""TDD tests for balance reconciliation assertion (bal-001)."""

from decimal import Decimal

import pytest

from finlint_audit.assertions.balance_reconciliation import assert_balance_reconciliation

from tests.helpers import make_ctx as _ctx, make_account as _acct, make_holding as _hold


# -- Blackbox tests -----------------------------------------------------------


class TestBalanceReconciliationBlackbox:
    def test_empty_dataset(self) -> None:
        result = assert_balance_reconciliation(_ctx())
        assert result.status == "pass"
        assert result.assertion_id == "bal-001"

    def test_no_investment_accounts(self) -> None:
        result = assert_balance_reconciliation(
            _ctx(
                accounts=[
                    _acct("a1", "depository", balance=5000),
                    _acct("a2", "depository", balance=10000),
                ]
            )
        )
        assert result.status == "pass"

    def test_single_account_exact_match(self) -> None:
        result = assert_balance_reconciliation(
            _ctx(
                accounts=[_acct("a1", "investment", balance=50000)],
                holdings=[
                    _hold("h1", "a1", 30000),
                    _hold("h2", "a1", 20000),
                ],
            )
        )
        assert result.status == "pass"

    def test_single_account_within_tolerance(self) -> None:
        result = assert_balance_reconciliation(
            _ctx(
                accounts=[_acct("a1", "investment", balance=50000)],
                holdings=[_hold("h1", "a1", 49999.50)],
            )
        )
        assert result.status == "pass"

    def test_single_account_over_tolerance(self) -> None:
        result = assert_balance_reconciliation(
            _ctx(
                accounts=[_acct("a1", "investment", balance=50000)],
                holdings=[_hold("h1", "a1", 49998)],
            )
        )
        assert result.status == "fail"
        assert len(result.evidence) == 1

    def test_multiple_accounts_all_match(self) -> None:
        result = assert_balance_reconciliation(
            _ctx(
                accounts=[
                    _acct("a1", "investment", balance=50000),
                    _acct("a2", "investment", balance=25000),
                    _acct("a3", "investment", balance=10000),
                ],
                holdings=[
                    _hold("h1", "a1", 50000),
                    _hold("h2", "a2", 25000),
                    _hold("h3", "a3", 10000),
                ],
            )
        )
        assert result.status == "pass"

    def test_multiple_accounts_one_fails(self) -> None:
        result = assert_balance_reconciliation(
            _ctx(
                accounts=[
                    _acct("a1", "investment", balance=50000),
                    _acct("a2", "investment", balance=25000),
                    _acct("a3", "investment", balance=10000),
                ],
                holdings=[
                    _hold("h1", "a1", 50000),
                    _hold("h2", "a2", 20000),  # $5000 drift
                    _hold("h3", "a3", 10000),
                ],
            )
        )
        assert result.status == "fail"
        assert len(result.evidence) == 1

    def test_account_with_no_holdings(self) -> None:
        result = assert_balance_reconciliation(
            _ctx(
                accounts=[_acct("a1", "investment", balance=50000)],
                holdings=[],
            )
        )
        assert result.status == "fail"

    def test_zero_balance_zero_holdings(self) -> None:
        result = assert_balance_reconciliation(
            _ctx(
                accounts=[_acct("a1", "investment", balance=0)],
                holdings=[],
            )
        )
        assert result.status == "pass"

    def test_non_investment_accounts_ignored(self) -> None:
        """Depository, credit, loan accounts with mismatched holdings should not fail."""
        result = assert_balance_reconciliation(
            _ctx(
                accounts=[
                    _acct("a1", "depository", balance=50000),
                    _acct("a2", "credit", balance=5000),
                    _acct("a3", "loan", balance=200000),
                ],
                holdings=[
                    _hold("h1", "a1", 0),  # mismatch but not investment
                    _hold("h2", "a2", 0),
                ],
            )
        )
        assert result.status == "pass"

    def test_multiple_holdings_per_account(self) -> None:
        result = assert_balance_reconciliation(
            _ctx(
                accounts=[_acct("a1", "investment", balance=50000)],
                holdings=[
                    _hold("h1", "a1", 10000),
                    _hold("h2", "a1", 10000),
                    _hold("h3", "a1", 10000),
                    _hold("h4", "a1", 10000),
                    _hold("h5", "a1", 10000),
                ],
            )
        )
        assert result.status == "pass"

    def test_large_drift(self) -> None:
        result = assert_balance_reconciliation(
            _ctx(
                accounts=[_acct("a1", "investment", balance=100000)],
                holdings=[_hold("h1", "a1", 50000)],
            )
        )
        assert result.status == "fail"
        assert "drift=$50000" in result.evidence[0].actual


# -- Whitebox tests -----------------------------------------------------------


class TestBalanceReconciliationWhitebox:
    def test_custom_tolerance_param(self) -> None:
        result = assert_balance_reconciliation(
            _ctx(
                accounts=[_acct("a1", "investment", balance=50000)],
                holdings=[_hold("h1", "a1", 49995)],
                params={"tolerance": "10.00"},
            )
        )
        assert result.status == "pass"

    def test_tolerance_boundary_exact(self) -> None:
        """Drift exactly equal to tolerance should pass (> not >=)."""
        result = assert_balance_reconciliation(
            _ctx(
                accounts=[_acct("a1", "investment", balance=50000)],
                holdings=[_hold("h1", "a1", 49999)],
            )
        )
        assert result.status == "pass"

    def test_tolerance_boundary_one_cent_over(self) -> None:
        result = assert_balance_reconciliation(
            _ctx(
                accounts=[_acct("a1", "investment", balance=50000)],
                holdings=[_hold("h1", "a1", "49998.99")],
            )
        )
        assert result.status == "fail"

    def test_holdings_from_other_account_ignored(self) -> None:
        """Holdings with account_id=B should not count toward account A."""
        result = assert_balance_reconciliation(
            _ctx(
                accounts=[_acct("a1", "investment", balance=50000)],
                holdings=[
                    _hold("h1", "a1", 50000),
                    _hold("h2", "b1", 99999),  # different account
                ],
            )
        )
        assert result.status == "pass"

    def test_inactive_accounts_skipped(self) -> None:
        result = assert_balance_reconciliation(
            _ctx(
                accounts=[
                    _acct("a1", "investment", balance=50000, is_active=False),
                ],
                holdings=[],  # would fail if checked
            )
        )
        assert result.status == "pass"
        assert "No investment accounts" in result.message

    def test_exclude_from_net_worth_still_checked(self) -> None:
        result = assert_balance_reconciliation(
            _ctx(
                accounts=[
                    _acct("a1", "investment", balance=50000, exclude_from_net_worth=True),
                ],
                holdings=[],  # big drift
            )
        )
        assert result.status == "fail"

    def test_negative_institution_value(self) -> None:
        """Short position with negative value reduces holdings sum."""
        result = assert_balance_reconciliation(
            _ctx(
                accounts=[_acct("a1", "investment", balance=20000)],
                holdings=[
                    _hold("h1", "a1", 25000),
                    _hold("h2", "a1", -5000),  # short position
                ],
            )
        )
        assert result.status == "pass"

    def test_metadata_mismatch_count(self) -> None:
        result = assert_balance_reconciliation(
            _ctx(
                accounts=[
                    _acct("a1", "investment", balance=50000),
                    _acct("a2", "investment", balance=30000),
                ],
                holdings=[],  # both will fail
            )
        )
        assert result.status == "fail"
        assert result.metadata["mismatch_count"] == "2"

    def test_evidence_field_format(self) -> None:
        result = assert_balance_reconciliation(
            _ctx(
                accounts=[_acct("a1", "investment", balance=50000)],
                holdings=[],
            )
        )
        assert result.evidence[0].field == "account.id=a1"

    def test_evidence_expected_actual(self) -> None:
        result = assert_balance_reconciliation(
            _ctx(
                accounts=[_acct("a1", "investment", balance=50000)],
                holdings=[_hold("h1", "a1", 49500)],
            )
        )
        ev = result.evidence[0]
        assert "$1.00" in ev.expected  # tolerance
        assert "drift=$500" in ev.actual
