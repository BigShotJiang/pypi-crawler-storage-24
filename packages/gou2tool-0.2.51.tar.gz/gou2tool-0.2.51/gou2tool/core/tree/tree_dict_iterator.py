class TreeDictIterator:
    def __init__(self, root, config=None):
        if config is None:
            config = {}

        self.children_key = config.get("children", "children")
        self.id_key = config.get("id", "id")
        self.name_key = config.get("name", "name")
        self.parent_id_key = config.get("parent_id", "parent_id")

        # 栈元素：(node, parent, parent_indices, parent_full_names, parent_full_ids, parent_root_id, ancestors)
        if isinstance(root, list):
            self.stack = [(node, None, [], [], [], None, []) for node in reversed(root)]
        else:
            self.stack = [(root, None, [], [], [], None, [])]

        self._index = 0

    def __iter__(self):
        return self

    def __next__(self):
        if not self.stack:
            raise StopIteration

        current_index = self._index
        self._index += 1

        node, parent, parent_indices, parent_full_names, parent_full_ids, parent_root_id, ancestors = self.stack.pop()

        # 基础结果
        result = {
            "node": node,
            "parent": parent,
            "parents": ancestors,                # 祖先节点对象列表（不含当前节点）
            "children": node.get(self.children_key) if isinstance(node, dict) else None,
            "level": len(parent_indices) + 1,
            "index": current_index,
            "is_first": current_index == 0,
            "is_last": len(self.stack) == 0,
            "is_middle": current_index > 0 and len(self.stack) > 0,
            "parent_index": parent_indices[-1] if parent_indices else None,
            "full_index": None,
            "full_indexs": None,
            "parent_id": None,
            "root_id": None,
            "id": None,
            "name": None,
            "list_index": current_index + 1,
            "list_parent_index": (parent_indices[-1] + 1) if parent_indices else None,
            "full_list_index": None,
            "full_list_indexs": None,
            "full_name": None,
            "full_id": None,
            "full_names": [],
            "full_ids": [],
            "fulls": []                           # 新增：从根到当前节点的所有节点对象列表
        }

        # 计算索引路径
        full_indexes = parent_indices + [current_index]
        result["full_index"] = ",".join(str(i) for i in full_indexes)
        result["full_indexs"] = full_indexes
        full_list_indexes = [i + 1 for i in full_indexes]
        result["full_list_index"] = ",".join(str(i) for i in full_list_indexes)
        result["full_list_indexs"] = full_list_indexes

        if isinstance(node, dict):
            node_id = node.get(self.id_key)
            node_name = node.get(self.name_key)

            result["id"] = node_id
            result["name"] = node_name

            # 处理 parent_id
            parent_id_val = node.get(self.parent_id_key)
            if parent_id_val is not None:
                result["parent_id"] = parent_id_val
            elif parent is not None and isinstance(parent, dict):
                result["parent_id"] = parent.get(self.id_key)

            # 构建路径名称和ID（空值处理为字符串）
            node_name_str = node_name if node_name is not None else ""
            node_id_str = str(node_id) if node_id is not None else ""

            full_names = parent_full_names + [node_name_str]
            full_ids = parent_full_ids + [node_id_str]

            # 根节点 root_id 为自身 id，否则继承父节点的 root_id
            if parent_indices:
                root_id = parent_root_id
            else:
                root_id = node_id

            result["full_names"] = full_names
            result["full_ids"] = full_ids
            result["full_name"] = "/".join(full_names)
            result["full_id"] = ",".join(full_ids)
            result["root_id"] = root_id

            # 新增 fulls：从根到当前节点的所有节点对象列表
            full_nodes = ancestors + [node]
            result["fulls"] = full_nodes

            # 将子节点压栈，传递当前节点的路径信息，并更新祖先列表
            children = node.get(self.children_key)
            if isinstance(children, list):
                child_ancestors = full_nodes      # 子节点的祖先包括当前节点
                for child in reversed(children):
                    self.stack.append((
                        child,
                        node,
                        full_indexes,
                        full_names,
                        full_ids,
                        root_id,
                        child_ancestors
                    ))

        return result