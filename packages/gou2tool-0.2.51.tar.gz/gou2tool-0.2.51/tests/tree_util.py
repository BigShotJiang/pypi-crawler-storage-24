import json
import unittest

from gou2tool.core.tree.tree_dict_iterator import TreeDictIterator
from gou2tool.util import PathUtil, TreeUtil


class TestDemo(unittest.TestCase):

    private_list = [
        {"id": 1, "name": "湖北省", "pid": 0},
        {"id": 2, "name": "武汉市", "pid": 1},
        {"id": 3, "name": "襄阳市", "pid": 1},
        {"id": 4, "name": "汉阳区", "pid": 2},
        {"id": 5, "name": "襄州区", "pid": 3},
        {"id": 6, "name": "襄城区", "pid": 3},
        {"id": 7, "name": "樊城区", "pid": 3},
        {"id": 8, "name": "石桥镇", "pid": 5},
        {"id": 9, "name": "黄集镇", "pid": 5},
        {"id": 10, "name": "武昌区", "pid": 2},
        {"id": 11, "name": "江汉区", "pid": 2},
        {"id": 12, "name": "洪山区", "pid": 2},
        {"id": 13, "name": "硚口区", "pid": 2},
        {"id": 14, "name": "江岸区", "pid": 2},
        {"id": 15, "name": "青山区", "pid": 2},
        {"id": 16, "name": "高新区", "pid": 2},
        {"id": 17, "name": "建桥街道", "pid": 4},
        {"id": 18, "name": "晴川街道", "pid": 4},
        {"id": 19, "name": "鹦鹉街道", "pid": 4},
        {"id": 20, "name": "洲头街道", "pid": 4},
        {"id": 21, "name": "五里墩街道", "pid": 4},
        {"id": 22, "name": "琴断口街道", "pid": 4},
        {"id": 23, "name": "江堤街道", "pid": 4},
        {"id": 25, "name": "断层街道", "pid": 24, "pid_code": '1,2,4,24,25'},
        {"id": 26, "name": "中间断层街道", "pid": 24, "pid_code": '1'},
        {"id": 27, "name": "顶级断层街道", "pid": 24},
    ]

    private_tree = []

    def test_private_list(self):
        self.private_tree = TreeUtil.list_to_tree(self.private_list, {"children": "children", "parent_id": "pid", "full_id": "pid_code"})
        print(json.dumps(self.private_list, ensure_ascii=False))
        for node in TreeDictIterator(self.private_tree):
            # print(node["full_names"])
            # print(str(node["list_full_index"]) + node["name"])
            print(json.dumps(node, ensure_ascii=False))
        print(json.dumps(self.private_tree, ensure_ascii=False))

if __name__ == '__main__':
    unittest.main()