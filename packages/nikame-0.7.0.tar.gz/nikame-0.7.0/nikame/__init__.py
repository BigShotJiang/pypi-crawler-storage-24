"""NIKAME — Describe your infrastructure. NIKAME builds it."""

__version__ = "0.7.0"
