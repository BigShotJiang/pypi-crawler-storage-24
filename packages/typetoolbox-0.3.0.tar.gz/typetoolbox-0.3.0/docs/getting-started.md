# Getting Started

## Install

```bash
uv add typetoolbox
```

## Import pattern

The stable APIs currently live in `typetoolbox.generics` and `typetoolbox.utils`.

```python
from typetoolbox.generics import GenericTypeMap, resolve_typevars
from typetoolbox.utils import get_subclasses
```

## First useful operation

```python
from typing import Generic, TypeVar

from typetoolbox.generics import GenericTypeMap

X = TypeVar("X")
Y = TypeVar("Y")


class Pair(Generic[X, Y]):
    pass


class IntStrPair(Pair[int, str]):
    pass

mapping = GenericTypeMap(IntStrPair)
assert mapping[X] is int
assert mapping[Y] is str
```

## Typical workflow

1. Build a mapping: `GenericTypeMap(...)`.
2. Resolve nested type expressions: `resolve_typevars(...)`.
3. Discover concrete implementations: `inspect_specializations(...)` or `find_specializations(...)`.
