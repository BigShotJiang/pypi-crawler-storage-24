# API Reference: `typetoolbox.generics`

## Data model

### `SpecializationInfo`

Frozen dataclass used by discovery APIs.

Attributes:

- `implementation: type`
- `resolved_alias: object`
- `resolved_args: tuple[object, ...]`
- `mapping: dict[str, object]`
- `is_generic: bool`

## Mapping APIs

### `GenericTypeMap(cls: object)`

Runtime map from type variables to concrete values.

Methods:

- `is_mapping_generic() -> bool`
- `is_mapping_specialized() -> bool`
- `get(key: object, default=None)`
- `items()`
- `values()`
- `__getitem__(key)`

### `get_generic_mapping(obj_or_type: object) -> GenericTypeMap`

Builds a map from a class/type-alias/object instance.

## Type inspection APIs

### `is_generic_type(tp: object) -> bool`

Checks whether the input is a generic type (excluding special forms like `Union`, `ClassVar`, `Callable`).

### `get_generic_type_args(tp: object) -> tuple[object, ...]`

Returns the generic parameter tuple when available.

### `get_generic_type(obj: object) -> object`

Returns `__orig_class__` when available, otherwise `type(obj)`.

### `get_generic_bases(cls: type, filter=...) -> list[object]`

Traverses `__orig_bases__` recursively.

## Resolution APIs

### `resolve_typevars(tp: object, mapping_source: GenericTypeMap | object, strict=False) -> object`

Recursively substitutes `TypeVar` values from a mapping source.

### `try_to_map_generic_args_to_specialization(generic_type: object, specialization_type: object) -> object`

Projects generic args from `generic_type` onto `specialization_type`.

## Discovery APIs

### `inspect_specializations(base_generic: object, include_generic=False, where=None) -> list[SpecializationInfo]`

Primary discovery API with structured output.

### `find_specializations(base_generic: object, where=None) -> list[type]`

Convenience wrapper returning only concrete implementation classes.

### `find_specializations_by_args(base_generic: object, args: tuple[object, ...]) -> list[type]`

Returns implementations matching an exact resolved-arg tuple.

### `build_specialization_index(base_generic: object) -> dict[tuple[object, ...], list[type]]`

Groups implementations by resolved-arg tuple.
