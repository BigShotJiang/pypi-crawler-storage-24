# API Reference: `typetoolbox.utils`

## `get_type_args_for_function(fn: Callable) -> dict[str, type]`

Returns parameter type hints for a function (excluding return type).

## `get_subclasses(cls: type, *, filter: Callable[[type], bool] = ...) -> list[type]`

Recursively traverses subclasses of `cls` and applies an optional filter.
