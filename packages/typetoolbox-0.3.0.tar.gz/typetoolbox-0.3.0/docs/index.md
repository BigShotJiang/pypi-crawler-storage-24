# typetoolbox

`typetoolbox` helps you inspect runtime generics and resolve `TypeVar` bindings in Python.

## What it gives you

- Generic-to-concrete mappings with `GenericTypeMap`
- Recursive type replacement with `resolve_typevars(...)`
- Discovery tools for implementations of generic bases

## Documentation map

- Start with [Getting Started](getting-started.md)
- Learn terminology in [Concepts](concepts.md)
- Use practical recipes in [Guides](guides/mapping.md)
- See full call signatures in [API Reference](reference/generics.md)

## Quick example

```python
from typing import Generic, TypeVar

from typetoolbox.generics import GenericTypeMap, resolve_typevars

T = TypeVar("T")


class Box(Generic[T]):
    pass


class IntBox(Box[int]):
    pass

mapping = GenericTypeMap(IntBox)
assert mapping[T] is int
assert resolve_typevars(list[T], mapping) == list[int]
```
