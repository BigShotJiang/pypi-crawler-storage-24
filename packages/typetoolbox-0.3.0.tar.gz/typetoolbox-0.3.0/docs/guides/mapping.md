# Mapping TypeVars

## Build and inspect a map

```python
from typing import Generic, TypeVar

from typetoolbox.generics import GenericTypeMap

A = TypeVar("A")
B = TypeVar("B")


class Pair(Generic[A, B]):
    pass


class IntFloatPair(Pair[int, float]):
    pass

mapping = GenericTypeMap(IntFloatPair)

assert mapping[A] is int
assert mapping[B] is float
assert mapping.is_mapping_specialized()
```

## Use string lookup when needed

```python
assert mapping["A"] is int
assert mapping.get("Missing", None) is None
```

## From an instance

```python
from typetoolbox.generics import get_generic_mapping

instance_mapping = get_generic_mapping(IntFloatPair())
assert instance_mapping[A] is int
```
