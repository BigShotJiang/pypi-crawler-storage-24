# Resolving Types

`resolve_typevars(...)` recursively replaces `TypeVar` occurrences in nested types.

## Example

```python
from typing import Generic, TypeVar

from typetoolbox.generics import GenericTypeMap, resolve_typevars

T = TypeVar("T")
U = TypeVar("U")


class Pair(Generic[T, U]):
    pass


class IntStrPair(Pair[int, str]):
    pass

mapping = GenericTypeMap(IntStrPair)
result = resolve_typevars(dict[T, list[U]], mapping)

assert result == dict[int, list[str]]
```

## Strict mode

If a `TypeVar` cannot be resolved and `strict=True`, a `ValueError` is raised.

```python
partial = GenericTypeMap(Pair[int, U])
resolve_typevars(tuple[T, U], partial, strict=False)  # tuple[int, U]
```
