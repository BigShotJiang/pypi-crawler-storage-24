# Discovering Implementations

Use the discovery APIs to find classes that implement a generic base.

## Structured inspection

```python
from typing import Generic, TypeVar

from typetoolbox.generics import inspect_specializations

T = TypeVar("T")


class Repo(Generic[T]):
    pass


class User:
    pass


class UserRepo(Repo[User]):
    pass

infos = inspect_specializations(Repo)
assert infos[0].implementation is UserRepo
assert infos[0].resolved_args == (User,)
```

## Filter to exact args

```python
from typetoolbox.generics import find_specializations_by_args

repos = find_specializations_by_args(Repo, (User,))
```

## Build an index

```python
from typetoolbox.generics import build_specialization_index

index = build_specialization_index(Repo)
# { (User,): [UserRepo], ... }
```

## Include still-generic implementations

```python
all_infos = inspect_specializations(Repo, include_generic=True)
```
