# Concepts

## Generic vs specialized

- **Generic mapping**: still contains unresolved `TypeVar` values.
- **Specialized mapping**: every relevant type parameter is concrete.

`GenericTypeMap` exposes this via:

- `is_mapping_generic()`
- `is_mapping_specialized()`

## SpecializationInfo

`inspect_specializations(...)` returns `SpecializationInfo` records:

- `implementation`: subclass found during discovery
- `resolved_alias`: base generic with mapped args for that subclass
- `resolved_args`: resolved type argument tuple
- `mapping`: type-variable name to resolved value map
- `is_generic`: `True` when unresolved type vars still remain

## Mapping source

Most APIs accept either:

- a type (class or alias)
- or an object instance (using `__orig_class__` when available)

Use `get_generic_mapping(obj_or_type)` when you want one entry point for both.
