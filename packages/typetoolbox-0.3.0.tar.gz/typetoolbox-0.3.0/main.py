def main():
    print("Hello from typetoolbox!")


if __name__ == "__main__":
    main()
