from typing import Generic, TypeVar

from typetoolbox.utils import get_subclasses, get_type_args_for_function

T = TypeVar("T")


class Base(Generic[T]):
    pass


class ChildA(Base[int]):
    pass


class ChildB(Base[str]):
    pass


class GrandChild(ChildA):
    pass


def test_get_type_args_for_function():
    def typed_fn(a: int, b: str) -> bool:
        return True

    assert get_type_args_for_function(typed_fn) == {"a": int, "b": str}


def test_get_subclasses_recursive():
    subclasses = set(get_subclasses(Base))
    assert {ChildA, ChildB, GrandChild}.issubset(subclasses)


def test_get_subclasses_filter():
    only_a_lineage = set(get_subclasses(Base, filter=lambda cls: issubclass(cls, ChildA)))
    assert ChildA in only_a_lineage
    assert GrandChild in only_a_lineage
    assert ChildB not in only_a_lineage
