import asyncio
import inspect
from collections.abc import Callable
from typing import ClassVar, Generic, Protocol, TypeVar, Union

import pytest

from typetoolbox.generics import (
    GenericTypeMap,
    SpecializationInfo,
    build_specialization_index,
    create_specialized_function,
    find_specializations,
    find_specializations_by_args,
    get_generic_bases,
    get_generic_mapping,
    get_generic_type,
    get_generic_type_args,
    inspect_specializations,
    is_generic_type,
    resolve_typevars,
    try_to_map_generic_args_to_specialization,
)

X = TypeVar("X")
Y = TypeVar("Y")
Z = TypeVar("Z")


class TestXY(Generic[X, Y]):
    pass


class IntStr(TestXY[int, str]):
    pass


class IntY(TestXY[int, Y], Generic[Y]):
    pass


class IntFloat(IntY[float]):
    pass


class TestXYZ(Generic[X, Y, Z]):
    pass


class IntStrFloat(TestXYZ[int, str, float]):
    pass


class IntYFloat(TestXYZ[int, Y, float], Generic[Y]):
    pass


class IntByteFloat(IntYFloat[bytes]):
    pass


class XYBytes(TestXYZ[X, Y, bytes], Generic[X, Y]):
    pass


class IntYBytes(XYBytes[int, Y], Generic[Y]):
    pass


class IntStrBytes(IntYBytes[str]):
    pass


class XGeneric(Generic[X]):
    pass


class YGeneric(Generic[Y]):
    pass


class XyStrInt(XGeneric[str], YGeneric[int]):
    pass


class YxBytesFloat(YGeneric[bytes], XGeneric[float]):
    pass


class Parent(Generic[X]):
    pass


class Child(Parent[Y], Generic[Y]):
    pass


class GrandChild(Child[int]):
    pass


TOperation = TypeVar("TOperation")
TOperationResult = TypeVar("TOperationResult")


class Command:
    pass


TCommand = TypeVar("TCommand", bound=Command)


class Query:
    pass


class QueryResult:
    pass


TQuery = TypeVar("TQuery", bound=Query)
TQueryResult = TypeVar("TQueryResult", bound=QueryResult)


TContext = TypeVar("TContext")


class ACommand(Command):
    pass


class BQuery(Query):
    pass


class BQueryResult(QueryResult):
    pass


class OperationHandler(Protocol[TOperation, TOperationResult]):
    pass


class CommandHandler(OperationHandler[TCommand, None], Protocol[TCommand]):
    pass


class QueryHandler(OperationHandler[TQuery, TQueryResult], Protocol[TQuery, TQueryResult]):
    pass


class AHandler(CommandHandler[ACommand]):
    pass


class BHandler(QueryHandler[BQuery, BQueryResult]):
    pass


class ContextMapper(Protocol[TContext]):
    pass


@pytest.mark.parametrize(
    "test_type, x, y",
    [
        (TestXY, X, Y),
        (IntStr, int, str),
        (IntFloat, int, float),
        (IntY, int, Y),
        (XyStrInt, str, int),
        (YxBytesFloat, float, bytes),
    ],
)
def test_two_generic_type_args(test_type: type, x: type, y: type):
    mapping = GenericTypeMap(test_type)
    assert mapping[X] is x
    assert mapping[Y] is y


@pytest.mark.parametrize(
    "test_type, x, y, z",
    [
        (IntStrFloat, int, str, float),
        (IntByteFloat, int, bytes, float),
        (IntYFloat, int, Y, float),
        (IntStrBytes, int, str, bytes),
        (XYBytes, X, Y, bytes),
    ],
)
def test_three_generic_type_args(test_type: type, x: type, y: type, z: type):
    mapping = GenericTypeMap(test_type)
    assert mapping[X] is x
    assert mapping[Y] is y
    assert mapping[Z] is z


@pytest.mark.parametrize(
    "test_type, expected",
    [
        (TestXY, True),
        (IntStr, False),
        (IntY, True),
        (IntFloat, False),
        (TestXYZ, True),
        (IntStrFloat, False),
        (IntYFloat, True),
        (IntByteFloat, False),
        (XYBytes, True),
        (IntYBytes, True),
        (IntYBytes, True),
        (IntStrBytes, False),
        (XGeneric, True),
        (YGeneric, True),
        (XyStrInt, False),
        (int, False),
    ],
)
def test_is_mapping_generic(test_type: type, expected: bool):
    mapping = GenericTypeMap(test_type)
    assert mapping.is_mapping_generic() is expected


def test_is_mapping_specialized():
    assert GenericTypeMap(IntY).is_mapping_generic() is True
    assert GenericTypeMap(IntFloat).is_mapping_specialized() is True


def test_recursive_linking_in_mappings():
    a_map = GenericTypeMap(AHandler)
    b_map = GenericTypeMap(BHandler)

    assert a_map[TOperation] is ACommand
    assert a_map[TOperationResult] is type(None)
    assert a_map[TCommand] is ACommand

    assert b_map[TOperation] is BQuery
    assert b_map[TOperationResult] is BQueryResult
    assert b_map[TQuery] is BQuery
    assert b_map[TQueryResult] is BQueryResult


def test_is_singleton_per_type():
    mapping1 = GenericTypeMap(IntY)
    mapping2 = GenericTypeMap(IntY)
    mapping3 = GenericTypeMap(IntStr)

    assert mapping1 is mapping2

    assert mapping1 is not mapping3


@pytest.mark.parametrize(
    "generic_type, specialization_type, result_type",
    [
        (OperationHandler, AHandler, OperationHandler[ACommand, None]),
        (OperationHandler, BHandler, OperationHandler[BQuery, BQueryResult]),
        (CommandHandler, AHandler, CommandHandler[ACommand]),
        (QueryHandler, BHandler, QueryHandler[BQuery, BQueryResult]),
        (ContextMapper[TCommand], AHandler, ContextMapper[ACommand]),
        (CommandHandler[TCommand], int, CommandHandler[TCommand]),  # type: ignore
    ],
)
def test_try_to_map_generic_args_to_specialization(
    generic_type,
    specialization_type,
    result_type,
):
    assert (
        try_to_map_generic_args_to_specialization(generic_type, specialization_type) == result_type
    )


@pytest.mark.parametrize(
    "test_type, expected",
    [
        (TestXY, (X, Y)),
        (CommandHandler, (TCommand,)),
        (CommandHandler[TCommand], (TCommand,)),  # type: ignore
        (AHandler, (TCommand,)),
        (int, tuple()),
    ],
)
def test_get_generic_type_args(test_type, expected):
    result = get_generic_type_args(test_type)
    assert result == expected


def test_get_generic_type_from_instance():
    class Box(Generic[X]):
        pass

    assert get_generic_type(Box[int]()) == Box[int]
    assert get_generic_type(123) is int


@pytest.mark.parametrize(
    "test_type, expected",
    [
        (int, False),
        (Union[int, str], False),
        (ClassVar[list[int]], False),
        (Callable[[int], str], False),
        (Generic, True),
        (Generic[X], True),  # type: ignore
        (list[int], True),
    ],
)
def test_is_generic_type_edges(test_type, expected):
    assert is_generic_type(test_type) is expected


def test_get_generic_bases():
    bases = get_generic_bases(IntFloat)
    assert IntY[float] in bases
    assert TestXY[int, Y] in bases


def test_get_generic_mapping_with_type_and_instance():
    mapping_from_type = get_generic_mapping(IntFloat)
    assert mapping_from_type[X] is int
    assert mapping_from_type[Y] is float

    mapping_from_instance = get_generic_mapping(IntY[float]())
    assert mapping_from_instance[X] is int
    assert mapping_from_instance[Y] is float

    assert get_generic_mapping(123).is_mapping_specialized()


def test_resolve_typevars_nested_alias():
    mapping = GenericTypeMap(IntFloat)
    assert resolve_typevars(dict[X, list[Y]], mapping) == dict[int, list[float]]


def test_resolve_typevars_partial_mapping():
    mapping = GenericTypeMap(IntY)
    assert resolve_typevars(tuple[X, Y], mapping) == tuple[int, Y]


def test_resolve_typevars_strict_mode():
    mapping = GenericTypeMap(IntY)
    with pytest.raises(ValueError, match="Y"):
        resolve_typevars(tuple[X, Y], mapping, strict=True)


def test_resolve_typevars_mapping_source_accepts_type_or_instance():
    assert resolve_typevars(tuple[X, Y], IntFloat) == tuple[int, float]
    assert resolve_typevars(tuple[X, Y], IntY[float]()) == tuple[int, float]


def test_find_specializations():
    result = set(find_specializations(TestXY))
    assert result == {IntStr, IntFloat}


def test_find_specializations_with_predicate():
    result = find_specializations(TestXY, where=lambda args: args == (int, float))
    assert result == [IntFloat]


def test_inspect_specializations_specialization_only_by_default():
    infos = inspect_specializations(TestXY)

    assert {info.implementation for info in infos} == {IntStr, IntFloat}
    assert all(not info.is_generic for info in infos)
    assert all(isinstance(info, SpecializationInfo) for info in infos)


def test_inspect_specializations_include_generic():
    infos = inspect_specializations(TestXY, include_generic=True)
    info_by_impl = {info.implementation: info for info in infos}

    assert IntY in info_by_impl
    assert info_by_impl[IntY].is_generic is True
    assert info_by_impl[IntStr].mapping["X"] is int
    assert info_by_impl[IntStr].mapping["Y"] is str


def test_inspect_specializations_where_filter():
    infos = inspect_specializations(
        TestXY,
        where=lambda info: (not info.is_generic) and info.resolved_args == (int, float),
    )
    assert [info.implementation for info in infos] == [IntFloat]


def test_inspect_specializations_deduplicates_diamond_hierarchy():
    class BaseDup(Generic[X]):
        pass

    class MidDup(BaseDup[int]):
        pass

    class LeftDup(MidDup):
        pass

    class RightDup(MidDup):
        pass

    class LeafDup(LeftDup, RightDup):
        pass

    infos = inspect_specializations(BaseDup, include_generic=True)
    implementations = [info.implementation for info in infos]
    assert implementations.count(LeafDup) == 1


def test_find_specializations_by_args_exact_match_and_no_match():
    assert find_specializations_by_args(TestXY, (int, float)) == [IntFloat]
    assert find_specializations_by_args(TestXY, (bytes, str)) == []


def test_find_specializations_by_args_returns_multiple_matches():
    class BaseMulti(Generic[X]):
        pass

    class MatchOne(BaseMulti[int]):
        pass

    class MatchTwo(BaseMulti[int]):
        pass

    matches = find_specializations_by_args(BaseMulti, (int,))
    assert set(matches) == {MatchOne, MatchTwo}


def test_build_specialization_index_groups_by_resolved_args():
    index = build_specialization_index(TestXY)
    assert set(index[(int, str)]) == {IntStr}
    assert set(index[(int, float)]) == {IntFloat}


def test_build_specialization_index_ignores_generic_mappings():
    index = build_specialization_index(TestXY)
    assert (int, Y) not in index


def test_build_specialization_index_supports_multiple_classes_per_key():
    class BaseMulti(Generic[X]):
        pass

    class MatchOne(BaseMulti[int]):
        pass

    class MatchTwo(BaseMulti[int]):
        pass

    index = build_specialization_index(BaseMulti)
    assert set(index[(int,)]) == {MatchOne, MatchTwo}


def test_create_specialized_function_specializes_signature_and_annotations():
    def fn(left: X, right: list[Y]) -> tuple[X, list[Y]]:
        return left, right

    wrapped = create_specialized_function(fn, IntFloat)
    signature = inspect.signature(wrapped)

    assert signature.parameters["left"].annotation is int
    assert signature.parameters["right"].annotation == list[float]
    assert signature.return_annotation == tuple[int, list[float]]
    assert wrapped.__annotations__ == {
        "left": int,
        "right": list[float],
        "return": tuple[int, list[float]],
    }
    assert wrapped(1, [2.5]) == (1, [2.5])


def test_create_specialized_function_preserves_unresolved_typevars():
    def fn(left: X, right: Y) -> tuple[X, Y]:
        return left, right

    wrapped = create_specialized_function(fn, IntY)
    signature = inspect.signature(wrapped)

    assert signature.parameters["left"].annotation is int
    assert signature.parameters["right"].annotation is Y
    assert signature.return_annotation == tuple[int, Y]


def test_create_specialized_function_preserves_default_values():
    default_right = [2.5]

    def fn(left: X, right: list[Y] = default_right) -> tuple[X, list[Y]]:  # ty:ignore[invalid-parameter-default]
        return left, right

    wrapped = create_specialized_function(fn, IntFloat)
    signature = inspect.signature(wrapped)

    assert signature.parameters["left"].annotation is int
    assert signature.parameters["right"].annotation == list[float]
    assert signature.parameters["right"].default is default_right
    assert signature.return_annotation == tuple[int, list[float]]
    assert wrapped(1) == (1, default_right)


def test_create_specialized_function_preserves_generator_functions():
    def fn(left: X, right: Y):
        yield left
        yield right

    wrapped = create_specialized_function(fn, IntFloat)
    signature = inspect.signature(wrapped)

    assert inspect.isgeneratorfunction(wrapped)
    assert signature.parameters["left"].annotation is int
    assert signature.parameters["right"].annotation is float
    assert list(wrapped(1, 2.5)) == [1, 2.5]


def test_create_specialized_function_preserves_async_generator_functions():
    async def fn(left: X, right: Y):
        yield left
        yield right

    wrapped = create_specialized_function(fn, IntFloat)
    signature = inspect.signature(wrapped)

    async def collect():
        return [item async for item in wrapped(1, 2.5)]

    assert inspect.isasyncgenfunction(wrapped)
    assert signature.parameters["left"].annotation is int
    assert signature.parameters["right"].annotation is float
    assert asyncio.run(collect()) == [1, 2.5]


def test_create_specialized_function_returns_original_for_non_generic_function():
    def fn(left: int, right: float) -> tuple[int, float]:
        return left, right

    wrapped = create_specialized_function(fn, IntFloat)

    assert wrapped is fn
