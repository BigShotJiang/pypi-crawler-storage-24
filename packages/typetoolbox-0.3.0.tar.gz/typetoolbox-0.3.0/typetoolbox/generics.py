import inspect
import types
import typing
from collections import deque
from collections.abc import Callable
from dataclasses import dataclass
from functools import reduce, wraps
from operator import or_
from typing import Any, ClassVar, Generic, Protocol, TypeVar, Union, cast

from .utils import get_subclasses

_GENERIC_ALIAS_TYPE = getattr(typing, "_GenericAlias", None)
_SPECIAL_GENERIC_ALIAS_TYPE = getattr(typing, "_SpecialGenericAlias", None)
TypingGenericAlias: tuple[type, ...] = tuple(
    alias_type
    for alias_type in (_GENERIC_ALIAS_TYPE, _SPECIAL_GENERIC_ALIAS_TYPE, types.GenericAlias)
    if isinstance(alias_type, type)
)
GenericDefinitionClasses = (Generic, Protocol)
_NON_GENERIC_ORIGINS = {Union, tuple, Callable, ClassVar, types.UnionType}


@dataclass(frozen=True)
class SpecializationInfo:
    """
    Describes how a discovered subclass specializes a generic base type.

    Attributes:
        implementation: The concrete subclass or implementation that was found.
        resolved_alias: The base generic projected onto `implementation`.
        resolved_args: The resolved type arguments for the base generic in order.
        mapping: A string-keyed view of the generic argument mapping.
        is_generic: Whether the specialization still contains unresolved `TypeVar`s.
    """

    implementation: type
    resolved_alias: object
    resolved_args: tuple[object, ...]
    mapping: dict[str, object]
    is_generic: bool


def _apply_type_args(tp: object, args: tuple[object, ...]) -> object:
    if not args:
        return tp

    if isinstance(tp, types.UnionType):
        return reduce(or_, args)

    copy_with = getattr(tp, "copy_with", None)
    if callable(copy_with):
        return copy_with(args)

    target = getattr(tp, "__origin__", None) or tp
    tp_any = cast(Any, target)
    if len(args) == 1:
        try:
            return tp_any[args[0]]
        except TypeError:
            pass

    try:
        return tp_any[args]
    except TypeError:
        return tp


class _GenericTypeMapMeta(type):
    """
    Metaclass for GenericTypeMap that implements caching of instances.
    """

    _cache: dict[object, "GenericTypeMap"] = {}

    def __call__(cls, mapped_type: object):
        if mapped_type in cls._cache:
            return cls._cache[mapped_type]
        instance = super().__call__(mapped_type)
        cls._cache[mapped_type] = instance
        return instance


class GenericTypeMap(metaclass=_GenericTypeMapMeta):
    """
    Resolve the visible `TypeVar` bindings for a generic class, alias, or instance.

    `GenericTypeMap` walks generic definitions and implementations across the MRO-like
    `__orig_bases__` chain and stores the resulting mapping by `TypeVar` name. The
    resulting object is read-only and cached per input object, which makes it suitable
    for repeated runtime specialization lookups.

    Example:
        ```python
        class Node(Generic[T]):
            pass

        class IntNode(Node[int]):
            pass

        mapping = GenericTypeMap(IntNode)

        assert mapping["T"] is int
        assert mapping[T] is int
        ```
    """

    def __init__(self, cls: object):
        self._inner_map: dict[str, object] = {}

        mapping = self._build_map(cls)

        for k, v in mapping.items():
            lookup = self._lookup_key(k)
            if isinstance(lookup, str):
                self._inner_map[lookup] = v

    @classmethod
    def _get_generic_definitions(cls, type_cls: object):
        queue = deque()
        queue.append(type_cls)
        aliases = []

        if root_origin := (getattr(type_cls, "__origin__", None)):
            queue.append(root_origin)

        while queue:
            type_check = queue.popleft()
            if getattr(type_check, "__origin__", None) in GenericDefinitionClasses:
                aliases.append(type_check)

            for base in getattr(type_check, "__orig_bases__", ()):  # pragma: no branch
                queue.append(base)
                if orig := getattr(base, "__origin__", None):
                    queue.append(orig)

        return aliases

    @classmethod
    def _get_generic_implementations(cls, type_cls: object):
        queue = deque()
        queue.append(type_cls)
        if orig := getattr(type_cls, "__origin__", None):
            queue.append(orig)

        aliases = []
        while queue:
            type_check = queue.popleft()
            if (
                _GENERIC_ALIAS_TYPE is not None
                and type(type_check) is _GENERIC_ALIAS_TYPE
                and getattr(type_check, "__origin__", None) not in GenericDefinitionClasses
            ):
                aliases.append(type_check)

            for base in getattr(type_check, "__orig_bases__", ()):  # pragma: no branch
                queue.append(base)
                if base_orig := getattr(base, "__origin__", None):
                    queue.append(base_orig)

        return aliases

    @classmethod
    def _close_off_possible_type_aliases(
        cls,
        mapping: dict[TypeVar | str, object],
    ) -> None:
        found_link = False

        for k, v in list(mapping.items()):
            if isinstance(v, TypeVar) and v != k:
                linked = mapping.get(v)
                if linked is not None and linked != v:
                    mapping[k] = linked
                    found_link = True

        if found_link:
            cls._close_off_possible_type_aliases(mapping)

    @classmethod
    def _build_map(cls, type_cls: object) -> dict[TypeVar | str, object]:
        generic_definitions = cls._get_generic_definitions(type_cls)

        generic_implementations = cls._get_generic_implementations(type_cls)

        generic_definitions.reverse()
        generic_implementations.reverse()

        mapping: dict[TypeVar | str, object] = {}

        for definition in generic_definitions:
            additions = dict(zip(definition.__args__, definition.__args__, strict=False))
            mapping = {**mapping, **additions}

        reduced_generic_definitions = generic_definitions[: len(generic_implementations)]

        for definition, implementation in zip(
            reduced_generic_definitions,
            generic_implementations,
            strict=False,
        ):
            additions = dict(zip(definition.__args__, implementation.__args__, strict=False))
            mapping = {**mapping, **additions}

        cls._close_off_possible_type_aliases(mapping)

        return mapping

    @classmethod
    def _lookup_key(cls, key: object) -> object:
        if isinstance(key, TypeVar):
            return key.__name__
        return key

    def is_mapping_generic(self) -> bool:
        """Return `True` when at least one mapped value is still an unresolved `TypeVar`."""

        for value in self._inner_map.values():
            if isinstance(value, TypeVar):
                return True
        return False

    def is_mapping_specialized(self) -> bool:
        """Return `True` when the mapping is fully concrete and contains no `TypeVar`s."""

        return not self.is_mapping_generic()

    def __getitem__(self, key: TypeVar | str):
        lookup = self._lookup_key(key)
        if not isinstance(lookup, str):
            raise KeyError(key)
        return self._inner_map[lookup]

    def __setitem__(self, key: TypeVar | str, value: object):
        raise ValueError("Cannot set items in a GenericTypeMap")

    def values(self):
        """Return the resolved mapping values."""

        return self._inner_map.values()

    def get(self, key: object, default=None):
        """Look up a `TypeVar` or type-variable name and return `default` when missing."""

        lookup = self._lookup_key(key)
        if not isinstance(lookup, str):
            return default
        return self._inner_map.get(lookup, default)

    def items(self):
        """Return `(name, value)` pairs for the resolved generic mapping."""

        return self._inner_map.items()

    def __eq__(self, value: object) -> bool:
        if not isinstance(value, GenericTypeMap):
            return False
        return self._inner_map == value._inner_map

    def __repr__(self) -> str:
        return f"GenericTypeMap({self._inner_map})"


def get_generic_bases(cls: type, filter: Callable[[object], bool] = lambda _t: True):
    """
    Recursively collect generic base aliases from `cls.__orig_bases__`.

    Args:
        cls: The class whose generic bases should be traversed.
        filter: Optional predicate used to keep only matching base entries.

    Returns:
        A list of generic base aliases in traversal order.
    """

    queue = deque()
    queue.append(cls)
    items = []
    while queue:
        t = queue.popleft()

        for sub in getattr(t, "__orig_bases__", ()):  # pragma: no branch
            queue.append(sub)
            if orig := getattr(sub, "__origin__", None):
                queue.append(orig)

            if filter(sub):
                items.append(sub)

    return items


def is_generic_type(tp: object):
    """
    Return whether `tp` should be treated as a generic type definition or alias.

    This includes `Generic` subclasses and most parameterized aliases, but excludes
    special typing forms such as `Union`, `tuple`, `Callable`, and `ClassVar`.

    Example:

        is_generic_type(int) == False
        is_generic_type(Union[int, str]) == False
        is_generic_type(Union[int, T]) == False
        is_generic_type(ClassVar[List[int]]) == False
        is_generic_type(Callable[..., T]) == False

        is_generic_type(Generic) == True
        is_generic_type(Generic[T]) == True
        is_generic_type(Iterable[int]) == True
        is_generic_type(Mapping) == True
        is_generic_type(MutableMapping[T, List[int]]) == True
        is_generic_type(Sequence[Union[str, bytes]]) == True
    """

    if isinstance(tp, type):
        return issubclass(tp, Generic)

    if not isinstance(tp, TypingGenericAlias):
        return False

    origin = getattr(tp, "__origin__", None)
    return origin not in _NON_GENERIC_ORIGINS


def get_generic_type_args(tp: object):
    """
    Return the declared generic type parameters for a generic class or alias.

    The function walks origins and original bases until it finds the generic
    definition that introduced the type parameters. Non-generic inputs return `()`.
    """

    queue = deque()
    queue.append(tp)

    while queue:
        type_check = queue.popleft()
        if origin_type := getattr(type_check, "__origin__", None):
            queue.append(origin_type)
            if origin_type in GenericDefinitionClasses:
                return type_check.__args__

        for base in getattr(type_check, "__orig_bases__", ()):  # pragma: no branch
            queue.append(base)
            if base_origin := getattr(base, "__origin__", None):
                queue.append(base_origin)
    return ()


def try_to_map_generic_args_to_specialization(
    generic_type: object,
    specialization_type: object,
) -> object:
    """
    Project the type arguments from `specialization_type` onto `generic_type`.

    This is useful when `generic_type` is an abstract generic base and
    `specialization_type` is a concrete or partially concrete subclass. The returned
    value is `generic_type` rebuilt with the most specific arguments that can be
    inferred from the specialization.
    """

    generic_mapping = GenericTypeMap(generic_type)
    specialization_mapping = GenericTypeMap(specialization_type)

    if generic_mapping.is_mapping_specialized():
        return generic_type

    output_args = []

    generic_args = get_generic_type_args(generic_type)

    for arg in generic_args:
        if from_specialization := specialization_mapping.get(arg):
            output_args.append(from_specialization)
            continue

        if from_generic := generic_mapping.get(arg):
            if linked_to_generic := specialization_mapping.get(from_generic):
                output_args.append(linked_to_generic)
                continue

        output_args.append(arg)

    return _apply_type_args(generic_type, tuple(output_args))


def get_generic_type(obj: object):
    """
    Return an object's runtime generic alias when available, otherwise `type(obj)`.

    This prefers `__orig_class__`, which Python attaches to many instances of
    parameterized generic classes.

    Examples:
        class Node(Generic[T]):
            ...
        type(Node[int]()) == Node
        get_generic_type(Node[int]()) == Node[int]
        get_generic_type(Node[T]()) == Node[T]
        get_generic_type(1) == int
    """

    gen_type = getattr(obj, "__orig_class__", None)
    return gen_type if gen_type is not None else type(obj)


def get_generic_mapping(obj_or_type: object) -> GenericTypeMap:
    """
    Build a `GenericTypeMap` from a mapping, type alias, class, or object instance.

    Existing `GenericTypeMap` objects are returned unchanged. Instances are first
    converted with `get_generic_type(...)` so their runtime generic alias can be used
    when available.
    """

    if isinstance(obj_or_type, GenericTypeMap):
        return obj_or_type

    if isinstance(obj_or_type, type) or isinstance(obj_or_type, TypingGenericAlias):
        return GenericTypeMap(obj_or_type)

    return GenericTypeMap(get_generic_type(obj_or_type))


def _resolve_typevars_inner(tp: object, mapping: GenericTypeMap, *, strict: bool) -> object:
    if isinstance(tp, TypeVar):
        resolved = mapping.get(tp)
        if resolved is None or resolved is tp:
            if strict:
                raise ValueError(f"Unable to resolve TypeVar '{tp.__name__}'")
            return tp
        return _resolve_typevars_inner(resolved, mapping, strict=strict)

    if isinstance(tp, list):
        return [_resolve_typevars_inner(item, mapping, strict=strict) for item in tp]

    if isinstance(tp, tuple):
        return tuple(_resolve_typevars_inner(item, mapping, strict=strict) for item in tp)

    args = getattr(tp, "__args__", None)
    if not args:
        return tp

    resolved_args = tuple(_resolve_typevars_inner(arg, mapping, strict=strict) for arg in args)
    return _apply_type_args(tp, resolved_args)


def resolve_typevars(
    tp: object, mapping_source: GenericTypeMap | object, *, strict: bool = False
) -> object:
    """
    Resolve `TypeVar` occurrences inside a nested type expression.

    Args:
        tp: The type expression to rewrite.
        mapping_source: A `GenericTypeMap`, type, alias, or instance that can supply
            type-variable bindings.
        strict: When `True`, raise `ValueError` if any `TypeVar` cannot be resolved.

    Returns:
        The rewritten type expression with any resolvable `TypeVar`s substituted.
    """

    mapping = get_generic_mapping(mapping_source)
    return _resolve_typevars_inner(tp, mapping, strict=strict)


def find_specializations(
    base_generic: object,
    *,
    where: Callable[[tuple[object, ...]], bool] | None = None,
) -> list[type]:
    """
    Return concrete subclasses that fully specialize `base_generic`.

    Args:
        base_generic: The generic base class or alias to inspect.
        where: Optional predicate that receives the resolved argument tuple for each
            specialization.

    Returns:
        Matching implementation classes with no unresolved `TypeVar`s.
    """

    infos = inspect_specializations(base_generic, include_generic=False)

    predicate = where if where is not None else lambda _args: True
    return [
        info.implementation
        for info in infos
        if info.resolved_args and predicate(info.resolved_args)
    ]


def inspect_specializations(
    base_generic: object,
    *,
    include_generic: bool = False,
    where: Callable[[SpecializationInfo], bool] | None = None,
) -> list[SpecializationInfo]:
    """
    Discover subclasses of `base_generic` and describe how each one specializes it.

    Args:
        base_generic: The generic base class or alias to inspect.
        include_generic: When `True`, include partially specialized subclasses that
            still contain unresolved `TypeVar`s.
        where: Optional predicate applied to each `SpecializationInfo` record.

    Returns:
        A list of `SpecializationInfo` records for matching subclasses.
    """

    root = getattr(base_generic, "__origin__", None) or base_generic
    if not isinstance(root, type):
        return []

    predicate = where if where is not None else lambda _info: True
    base_args = get_generic_type_args(base_generic)

    specializations: list[SpecializationInfo] = []
    seen: set[type] = set()

    for sub in get_subclasses(root):
        if sub in seen:
            continue
        seen.add(sub)

        resolved_alias = try_to_map_generic_args_to_specialization(base_generic, sub)
        specialization_map = GenericTypeMap(resolved_alias)

        resolved_args = tuple(specialization_map.get(arg, arg) for arg in base_args)
        is_concrete_specialization = bool(resolved_args) and not any(
            isinstance(arg, TypeVar) for arg in resolved_args
        )
        if not include_generic and not is_concrete_specialization:
            continue

        info = SpecializationInfo(
            implementation=sub,
            resolved_alias=resolved_alias,
            resolved_args=resolved_args,
            mapping=dict(specialization_map.items()),
            is_generic=not is_concrete_specialization,
        )
        if predicate(info):
            specializations.append(info)

    return specializations


def find_specializations_by_args(base_generic: object, args: tuple[object, ...]) -> list[type]:
    """
    Return concrete specializations of `base_generic` whose resolved args exactly match `args`.
    """

    return [
        info.implementation
        for info in inspect_specializations(base_generic, include_generic=False)
        if info.resolved_args == args
    ]


def build_specialization_index(base_generic: object) -> dict[tuple[object, ...], list[type]]:
    """
    Build a lookup table from resolved generic-argument tuples to implementation classes.

    Only fully concrete specializations are included in the returned index.
    """

    index: dict[tuple[object, ...], list[type]] = {}
    for info in inspect_specializations(base_generic, include_generic=False):
        bucket = index.setdefault(info.resolved_args, [])
        bucket.append(info.implementation)

    return index


def _get_function_annotations(func: Callable) -> dict[str, object]:
    try:
        return typing.get_type_hints(func, include_extras=True)
    except Exception:
        return dict(getattr(func, "__annotations__", {}))


def _contains_typevars(tp: object) -> bool:
    if isinstance(tp, TypeVar):
        return True

    if isinstance(tp, list):
        return any(_contains_typevars(item) for item in tp)

    if isinstance(tp, tuple):
        return any(_contains_typevars(item) for item in tp)

    args = getattr(tp, "__args__", None)
    if not args:
        return False

    return any(_contains_typevars(arg) for arg in args)


def create_specialized_function(func: Callable, specialized_type: type) -> Callable:
    """
    Wrap a callable with a signature specialized from a generic type mapping.

    The returned callable forwards directly to `func` while replacing any annotated
    `TypeVar` occurrences in the function signature with concrete types resolved from
    `specialized_type`. Resolution is performed with `get_generic_mapping(...)` and
    `resolve_typevars(...)`, so nested generic expressions such as `list[T]` or
    `tuple[X, Y]` are specialized recursively.

    The wrapper preserves runtime behavior and metadata expected by introspection:

    - Parameter defaults are preserved.
    - Existing non-generic annotations are left unchanged.
    - Unresolved `TypeVar` values remain in the signature when `specialized_type`
      only partially closes the generic mapping.
    - `__annotations__` and `inspect.signature(...)` reflect the specialized types.
    - Regular callables, coroutine functions, generator functions, and async
      generator functions keep their original callable kind.

    Args:
        func: The callable whose annotated signature should be specialized.
        specialized_type: A type that can be converted into a `GenericTypeMap` and used
            as the source of resolved type arguments.

    Returns:
        A wrapper around `func` with the same runtime behavior but a rewritten
        signature and annotations derived from `specialized_type`.
    """

    mapping = get_generic_mapping(specialized_type)
    original_signature = inspect.signature(func)
    evaluated_annotations = _get_function_annotations(func)

    if not any(_contains_typevars(annotation) for annotation in evaluated_annotations.values()):
        return func

    specialized_annotations: dict[str, object] = {}
    specialized_parameters = []

    for parameter in original_signature.parameters.values():
        annotation = evaluated_annotations.get(parameter.name, parameter.annotation)
        if annotation is not inspect.Signature.empty:
            annotation = resolve_typevars(annotation, mapping)
            specialized_annotations[parameter.name] = annotation
        specialized_parameters.append(parameter.replace(annotation=annotation))

    return_annotation = evaluated_annotations.get("return", original_signature.return_annotation)
    if return_annotation is not inspect.Signature.empty:
        return_annotation = resolve_typevars(return_annotation, mapping)
        specialized_annotations["return"] = return_annotation

    specialized_signature = original_signature.replace(
        parameters=specialized_parameters,
        return_annotation=return_annotation,
    )

    if inspect.isasyncgenfunction(func):

        @wraps(func)
        async def wrapped(*args: object, **kwargs: object):
            async for item in func(*args, **kwargs):
                yield item

    elif inspect.iscoroutinefunction(func):

        @wraps(func)
        async def wrapped(*args: object, **kwargs: object):
            return await func(*args, **kwargs)

    elif inspect.isgeneratorfunction(func):

        @wraps(func)
        def wrapped(*args: object, **kwargs: object):
            yield from func(*args, **kwargs)

    else:

        @wraps(func)
        def wrapped(*args: object, **kwargs: object):
            return func(*args, **kwargs)

    wrapped.__annotations__ = specialized_annotations
    wrapped.__signature__ = specialized_signature  # ty:ignore[invalid-assignment]
    return wrapped
