# Bayesian Positive Matrix Factorization: Theory and Methods

This describes the mathematical foundations behind the Bayesian PMF solver (`pmf_bayes`) in the `pmf_acls` package. 

---

## 1. Starting from Bayes' Rule

### 1.1 The Basic Idea

Suppose you have a hypothesis (a model with some unknown parameters) and you observe some data. Bayes' rule tells you how to update your beliefs about the unknown parameters after seeing the data:

$$
P(\theta \mid D) = \frac{P(D \mid \theta) \, P(\theta)}{P(D)}
$$

Let us define each term:

| Symbol | Name | Meaning |
|--------|------|---------|
| $\theta$ | Parameters | The unknown quantities we want to learn |
| $D$ | Data | The observations we have collected |
| $P(\theta)$ | **Prior** | What we believe about $\theta$ *before* seeing the data |
| $P(D \mid \theta)$ | **Likelihood** | The probability of observing the data *if* the parameters took a particular value |
| $P(D)$ | **Evidence** (or marginal likelihood) | A normalizing constant that ensures the posterior integrates to 1 |
| $P(\theta \mid D)$ | **Posterior** | Our updated belief about $\theta$ *after* seeing the data |

The evidence $P(D) = \int P(D \mid \theta) P(\theta) \, d\theta$ is often intractable to compute directly. In practice, we note that it is just a constant with respect to $\theta$, so we can write:

$$
P(\theta \mid D) \propto P(D \mid \theta) \, P(\theta)
$$

This proportionality statement --- *the posterior is proportional to the likelihood times the prior* --- is the engine of Bayesian inference. We do not need to compute the normalizing constant; instead, we can use sampling methods (described in Section 4) to draw samples from the posterior.

### 1.2 Why Bayesian?

Classical (frequentist) methods give you a single "best" answer --- a point estimate. Bayesian methods give you a full *distribution* over possible answers. This is especially powerful because:

- **Uncertainty quantification**: Instead of just a best-fit answer, you get error bars that reflect both measurement noise and model ambiguity.
- **Incorporating prior knowledge**: If you know something about the problem before seeing data (e.g., concentrations must be non-negative), you can encode that directly.
- **Model comparison**: The evidence $P(D)$ provides a principled way to compare models of different complexity.

---

## 2. The PMF Problem

### 2.1 What Are We Factorizing?

Positive Matrix Factorization decomposes a data matrix $X$ (of size $m \times n$) into the product of two non-negative matrices:

$$
X \approx F \, G
$$

where:
- $F$ is $m \times p$ --- the **factor profiles** (what each source looks like)
- $G$ is $p \times n$ --- the **factor contributions** (how much each source contributes to each observation)
- $p$ is the number of factors (chosen by the analyst)

For example, in environmental science, $X$ might be a matrix of chemical species concentrations measured across many air quality samples. Each row is a chemical species, each column is a sample. The factors represent pollution sources (vehicle exhaust, industrial emissions, soil dust, etc.), $F$ tells you the chemical fingerprint of each source, and $G$ tells you how strongly each source contributed to each sample.

### 2.2 The Role of Measurement Uncertainty

What makes PMF different from ordinary non-negative matrix factorization (NMF) is the uncertainty matrix $\sigma$, also of size $m \times n$. Each element $\sigma_{ij}$ is the known standard deviation of the measurement $X_{ij}$.

Some measurements are precise (small $\sigma_{ij}$) and should strongly influence the factorization. Others are noisy (large $\sigma_{ij}$) and should have less influence. PMF achieves this by minimizing a weighted objective:

$$
Q = \sum_{i=1}^{m} \sum_{j=1}^{n} \left( \frac{X_{ij} - (FG)_{ij}}{\sigma_{ij}} \right)^2
$$

Each squared residual is divided by $\sigma_{ij}^2$, so precise measurements contribute more to the objective. This is the **heteroscedastic** (varying-variance) weighted least squares objective.

---

## 3. The Bayesian NMF Generative Model

### 3.1 From Optimization to Probability

The classical PMF approach minimizes $Q$ to find a single best $(F, G)$ pair. The Bayesian approach instead treats $(F, G)$ as random variables and writes down a complete probabilistic model that *generates* the observed data.

The generative model, due to Schmidt, Winther, and Hansen (2009), is:

$$
X_{ij} \mid F, G \sim \mathcal{N}\!\left((FG)_{ij},\; \sigma_{ij}^2\right)
$$

This says: the observed value $X_{ij}$ is drawn from a Gaussian (normal) distribution centered at the model prediction $(FG)_{ij}$, with variance $\sigma_{ij}^2$.

### 3.2 The Likelihood

The likelihood function collects the probability of *all* the data given the parameters. Since we treat each measurement as independent (conditional on the factors), the full likelihood is the product over all elements:

$$
P(X \mid F, G) = \prod_{i,j} \frac{1}{\sqrt{2\pi}\,\sigma_{ij}} \exp\!\left( -\frac{(X_{ij} - (FG)_{ij})^2}{2\,\sigma_{ij}^2} \right)
$$

Taking the logarithm (which is often more convenient):

$$
\log P(X \mid F, G) = -\frac{1}{2} \sum_{i,j} \left( \frac{X_{ij} - (FG)_{ij}}{\sigma_{ij}} \right)^2 + \text{const.}
$$

Notice that the sum on the right is exactly $Q/2$! Minimizing the PMF objective $Q$ is equivalent to maximizing the Gaussian log-likelihood. The Bayesian approach generalizes this by adding priors and exploring the full posterior, rather than just finding its peak.

### 3.3 The Prior on F and G

Non-negativity is a hard constraint in classical PMF. In the Bayesian version, we enforce it through the choice of prior distribution. Each element of $F$ and $G$ is given an **exponential prior**:

$$
F_{ik} \sim \text{Exp}(\lambda_F), \qquad G_{kj} \sim \text{Exp}(\lambda_G)
$$

The exponential distribution is defined only for non-negative values, so this prior automatically ensures $F_{ik} \geq 0$ and $G_{kj} \geq 0$. The rate parameter $\lambda$ controls how strongly the prior pushes values toward zero:

- Large $\lambda$: prior favors small values (sparse solutions)
- Small $\lambda$: prior is more diffuse (less regularization)

The probability density is $p(x) = \lambda \, e^{-\lambda x}$ for $x \geq 0$, so the log-prior for all of $F$ is:

$$
\log P(F \mid \lambda_F) = m \cdot p \cdot \log \lambda_F - \lambda_F \sum_{i,k} F_{ik}
$$

### 3.4 Hyperpriors: Learning the Prior Strength

How do we choose $\lambda_F$ and $\lambda_G$? Rather than fixing them, we can place a prior on the prior parameters themselves --- a **hyperprior**. This is a key advantage of the Bayesian framework: the model can learn the appropriate level of regularization from the data.

We use a conjugate Gamma hyperprior:

$$
\lambda_F \sim \text{Gamma}(a, b), \qquad \lambda_G \sim \text{Gamma}(a, b)
$$

where $a$ (shape) and $b$ (rate) are fixed hyperparameters. The default values $a = 1.0$, $b = 0.1$ give a prior mean of $a/b = 10$ with substantial spread, allowing the data to determine the appropriate regularization strength.

"Conjugate" means that the posterior for $\lambda_F$ given $F$ is also a Gamma distribution, which makes sampling straightforward (see Section 4.3).

### 3.5 The Full Posterior

Assembling all the pieces using Bayes' rule:

$$
P(F, G, \lambda_F, \lambda_G \mid X) \propto \underbrace{P(X \mid F, G)}_{\text{likelihood}} \cdot \underbrace{P(F \mid \lambda_F)\,P(G \mid \lambda_G)}_{\text{priors}} \cdot \underbrace{P(\lambda_F)\,P(\lambda_G)}_{\text{hyperpriors}}
$$

This joint posterior over all unknowns $(F, G, \lambda_F, \lambda_G)$ is a high-dimensional distribution that we cannot write in closed form. Instead, we use Gibbs sampling to draw samples from it.

---

## 4. Gibbs Sampling

### 4.1 The Idea

Gibbs sampling is a method for drawing samples from a complicated multi-dimensional distribution when you cannot sample from it directly but *can* sample from each variable's **full conditional distribution** --- the distribution of one variable given all the others held fixed.

The algorithm is:

1. Start with some initial values for all parameters.
2. For each parameter (or block of parameters) in turn:
   - Compute its full conditional distribution (the distribution of that parameter given the current values of all other parameters).
   - Draw a new value from that conditional distribution.
   - Replace the old value with the new one.
3. Repeat step 2 many times.

After enough iterations, the samples approximate draws from the true joint posterior distribution. The initial samples (the **burn-in** period) are discarded because they may be influenced by the arbitrary starting values.

### 4.2 Full Conditional for F (and G)

This is the core mathematical derivation that makes the Gibbs sampler work. We derive the full conditional for a single column of $F$; the derivation for a row of $G$ is analogous.

Consider updating $F_{ik}$ (the element in row $i$, factor $k$ of $F$) while holding everything else fixed. We need:

$$
P(F_{ik} \mid \text{everything else}) \propto P(X \mid F, G) \cdot P(F_{ik} \mid \lambda_F)
$$

Only terms involving $F_{ik}$ survive (everything else is constant). From the likelihood, only the terms in row $i$ of $X$ depend on $F_{ik}$:

$$
\log P \propto -\frac{1}{2} \sum_{j=1}^{n} \frac{\left(X_{ij} - \sum_{\ell} F_{i\ell} G_{\ell j}\right)^2}{\sigma_{ij}^2} - \lambda_F \, F_{ik}
$$

Define the **partial residual** --- the residual with factor $k$'s contribution removed:

$$
R_{ij}^{(k)} = X_{ij} - \sum_{\ell \neq k} F_{i\ell} \, G_{\ell j}
$$

Then the model prediction for element $(i,j)$ is $R_{ij}^{(k)} - F_{ik} \, G_{kj}$, and only the $F_{ik} \, G_{kj}$ part depends on $F_{ik}$. Collecting terms and completing the square in $F_{ik}$:

$$
\log P(F_{ik} \mid \text{rest}) \propto -\frac{1}{2\,\tau_k^2(i)} \left(F_{ik} - \mu_k(i)\right)^2
$$

where:

$$
\tau_k^2(i) = \frac{1}{\sum_{j} G_{kj}^2 / \sigma_{ij}^2}
$$

$$
\mu_k(i) = \tau_k^2(i) \left( \sum_{j} \frac{R_{ij}^{(k)} \, G_{kj}}{\sigma_{ij}^2} - \lambda_F \right)
$$

This is a Gaussian distribution in $F_{ik}$ with mean $\mu_k(i)$ and variance $\tau_k^2(i)$, but restricted to $F_{ik} \geq 0$ (from the exponential prior's support). The result is a **truncated Gaussian**:

$$
F_{ik} \mid \text{rest} \sim \text{TruncNormal}\!\left(\mu_k(i),\; \tau_k^2(i)\right) \text{ on } [0, \infty)
$$

Sampling from a truncated Gaussian is straightforward using the inverse-CDF method: draw $u \sim \text{Uniform}(0,1)$, map it to the truncated range, and apply the inverse normal CDF.

The full conditional for $G_{kj}$ is derived identically, with the roles of $F$ and $G$ swapped.

### 4.3 Full Conditional for the Hyperparameters

Thanks to conjugacy, the posterior for $\lambda_F$ given $F$ is also a Gamma distribution:

$$
\lambda_F \mid F \sim \text{Gamma}\!\left(a + m \cdot p,\;\; b + \sum_{i,k} F_{ik}\right)
$$

This follows directly from multiplying the Gamma prior by the exponential likelihood for $F$:

$$
P(\lambda_F \mid F) \propto \lambda_F^{a-1} e^{-b \, \lambda_F} \cdot \lambda_F^{mp} e^{-\lambda_F \sum F_{ik}} = \lambda_F^{(a + mp) - 1} e^{-(b + \sum F_{ik})\,\lambda_F}
$$

which is a Gamma distribution with updated shape $a + mp$ and rate $b + \sum F_{ik}$. The same form applies to $\lambda_G$.

### 4.4 Interleaved Sweeps

A naive approach would update all of $F$, then all of $G$, in each sweep. The `pmf_bayes` solver instead uses **interleaved** updates: for each factor $k$, it updates $F_{:,k}$ (column $k$ of $F$) and then *immediately* updates $G_{k,:}$ (row $k$ of $G$) before moving to the next factor.

Why does this matter? Each factor's profile ($F_{:,k}$) and contribution ($G_{k,:}$) are tightly coupled --- they must jointly explain a portion of the data. Updating them back-to-back allows each factor to immediately adjust its contribution in response to its updated profile. This reduces **factor collapse**, a pathology where multiple factors drift toward explaining the same signal.

### 4.5 Scalar Noise Precision

The solver also samples a scalar precision parameter $\tau_{\text{scale}}$ at each sweep. This multiplies the effective precision of all observations uniformly:

$$
\text{effective variance} = \sigma_{ij}^2 / \tau_{\text{scale}}
$$

When factors fit the data poorly (large residuals), $\tau_{\text{scale}}$ decreases, loosening the likelihood and allowing the sampler to explore more freely. When factors fit well, $\tau_{\text{scale}}$ increases, tightening the likelihood. This adaptive behavior helps the sampler navigate the complex posterior landscape.

---

## 5. From Samples to Summaries

### 5.1 Posterior Mean and Standard Deviation

After discarding burn-in samples, we have a collection of draws $(F^{(1)}, G^{(1)}), (F^{(2)}, G^{(2)}), \ldots, (F^{(S)}, G^{(S)})$ from the posterior. We summarize these using:

$$
\hat{F}_{ik} = \frac{1}{S} \sum_{s=1}^{S} F_{ik}^{(s)} \qquad \text{(posterior mean)}
$$

$$
\text{std}(F_{ik}) = \sqrt{\frac{1}{S-1} \sum_{s=1}^{S} \left(F_{ik}^{(s)} - \hat{F}_{ik}\right)^2} \qquad \text{(posterior standard deviation)}
$$

The posterior mean is the Bayesian point estimate, and the standard deviation provides **credible intervals** --- the Bayesian analog of confidence intervals. These are computed using Welford's numerically stable online algorithm, which avoids storing all samples in memory.

### 5.2 The Label Switching Problem

Matrix factorization has a fundamental symmetry: permuting the columns of $F$ and the corresponding rows of $G$ gives the same product $FG$. This means the posterior is **multimodal** --- it has $p!$ equivalent modes corresponding to all permutations of the factors.

If the sampler visits different modes during sampling, the posterior mean will blur together factors that are actually distinct. The solver addresses this with **Hungarian alignment**: after each sweep, factors are permuted to best match a reference configuration (typically the ACLS warm-start solution) using the Hungarian algorithm on cosine similarity of $G$ rows.

### 5.3 Normalization

Scaling is another symmetry: multiplying column $k$ of $F$ by a constant $c$ and dividing row $k$ of $G$ by $c$ leaves the product unchanged. To resolve this ambiguity, after each Gibbs sweep the solver normalizes each column of $F$ to unit $L_1$ norm (i.e., $\sum_i F_{ik} = 1$), absorbing the scale factor into the corresponding row of $G$. This ensures consistent comparison across samples.

---

## 6. Convergence Diagnostics

How do we know when the sampler has run long enough?

### 6.1 The Geweke Test

The **Geweke diagnostic** (Geweke 1992) compares the mean of the first 10% of the post-burn-in samples to the mean of the last 50%. If the chain has converged, both segments should be sampling from the same distribution, and their means should be similar. The test statistic is:

$$
z = \frac{\bar{\theta}_{\text{first}} - \bar{\theta}_{\text{last}}}{\sqrt{\text{Var}(\bar{\theta}_{\text{first}}) + \text{Var}(\bar{\theta}_{\text{last}})}}
$$

Under convergence, $|z| < 2$ (approximately a 95% test). The solver applies this to the trace of $Q$ values.

### 6.2 Effective Sample Size

Successive Gibbs samples are **autocorrelated** --- each sample is similar to the previous one. The **effective sample size** (ESS) estimates how many *independent* samples your chain is equivalent to:

$$
\text{ESS} = \frac{S}{1 + 2\sum_{k=1}^{K} \hat{\rho}(k)}
$$

where $\hat{\rho}(k)$ is the estimated autocorrelation at lag $k$. Thinning (keeping every $n_{\text{thin}}$-th sample) reduces autocorrelation at the cost of discarding samples.

---

## 7. Extensions

### 7.1 Automatic Relevance Determination (ARD)

In practice, the number of factors $p$ is unknown. **ARD** provides a principled way to let the model determine the effective number of factors automatically. Instead of a single shared $\lambda$, each factor $k$ gets its own rate parameter $\lambda_k$:

$$
F_{ik} \sim \text{Exp}(\lambda_k), \qquad G_{kj} \sim \text{Exp}(\lambda_k)
$$

Factors not supported by the data will have their $\lambda_k$ driven to large values by the posterior, effectively shrinking their elements to zero. You can specify a generous upper bound for $p$ and let ARD prune the unnecessary factors.

### 7.2 Hierarchical Sigma

Standard PMF treats the uncertainty matrix $\sigma$ as fixed and known. But in practice, uncertainty estimates are themselves uncertain. The **hierarchical sigma** extension places an Inverse-Gamma prior on each $\sigma_{ij}^2$ and samples it alongside $F$ and $G$:

$$
\sigma_i^2 \sim \text{InvGamma}(\alpha_c, \beta_c)
$$

where $c$ is a category label (e.g., "measured," "below detection limit," "guessed") that groups variables by data quality. The full conditional is conjugate:

$$
\sigma_i^2 \mid \text{rest} \sim \text{InvGamma}\!\left(\alpha_c + \frac{n}{2},\;\; \beta_c + \frac{1}{2}\sum_j (X_{ij} - (FG)_{ij})^2\right)
$$

This allows the model to learn that some measurements are more or less uncertain than initially specified, while anchoring near the analyst's best estimates through the prior.

### 7.3 Full Bayesian Mode: Volume Prior and Sparse Gamma Priors

The standard Bayesian NMF workflow (Sections 4–5) warm-starts the Gibbs sampler from an ACLS point estimate. This has clear advantages --- faster convergence and a sharp reference for label alignment --- but it also anchors the posterior exploration to a single basin of the objective landscape. The sampler explores *around* the ACLS solution rather than discovering the full posterior geometry from scratch.

**Full Bayesian mode** removes this dependency by setting `warm_start=False` and using two structural priors that provide the identifiability guarantees that ACLS warm-starting would otherwise supply.

#### 7.3.1 The Volume Prior

The core problem with random initialization (no ACLS anchor) is that NMF factors are not identifiable: any permutation or rotation of factors gives an equally good fit. Without guidance, Gibbs sampling from a random start tends toward **factor collapse** --- multiple factors drift toward explaining the same dominant signal, and weaker factors are lost.

The **volume prior** (Fu & Huang 2018) directly addresses this by penalizing collinear factor profiles:

$$
P(F) \propto \det(F^\top F)^{\alpha/2}
$$

The quantity $\det(F^\top F)$ is the squared volume of the parallelepiped spanned by the columns of $F$ in $\mathbb{R}^m$. When columns are orthogonal (maximally separated), this volume is large. When columns are collinear (factor collapse), it approaches zero.

The parameter `volume_alpha` ($\alpha$) controls the strength of this geometric penalty:

- **$\alpha = 0$** (default): No volume prior. Equivalent to the standard Bayesian NMF with ACLS warm-start.
- **$\alpha = 1$--$5$** (typical): Moderate to strong encouragement for factor separation. This is the recommended range for full Bayesian mode (`warm_start=False`). Larger values force factors further apart, which prevents collapse but may over-separate factors in data where true source profiles are genuinely similar.
- **$\alpha > 5$**: Aggressive separation. Useful when the number of factors $p$ is close to the rank of $X$, but may distort profiles if the true sources share spectral features.

The prior acts through the log-determinant:

$$
\log P(F) = \frac{\alpha}{2} \log \det(F^\top F) + \text{const.}
$$

When $F$ columns become linearly dependent, $\det(F^\top F) \to 0$ and $\log \det \to -\infty$, creating an infinite penalty that makes collapsed configurations impossible.

Geometrically, `volume_alpha` controls *how much the sampler prefers a fat parallelepiped over a thin one*. At $\alpha = 0$, the sampler is indifferent to the shape of the column space. At $\alpha = 2$, it strongly favors configurations where factors span a large volume --- meaning each factor profile captures a distinct direction in the space of chemical species (or whatever the variables represent). This is the Bayesian analog of what ACLS warm-starting achieves implicitly: because ACLS converges to well-separated local optima, it naturally provides an initialization where factors are non-collinear.

#### 7.3.2 Implementation via Metropolis-Hastings

The volume prior is **non-conjugate** --- it cannot be absorbed into the truncated Gaussian full conditional for $F$. Instead, it is implemented as a Metropolis-Hastings (MH) correction layered on top of the standard Gibbs proposal.

For each factor $k$, the sampler:

1. Draws a candidate $F_{:,k}^*$ from the truncated Gaussian full conditional (ignoring the volume prior).
2. Computes the log-determinant change:
$$
\Delta = \frac{\alpha}{2}\left[\log \det\!\left(F_*^\top F_*\right) - \log \det\!\left(F^\top F\right)\right]
$$
where $F_*$ is $F$ with column $k$ replaced by the candidate.
3. Accepts the candidate with probability $\min(1, e^{\Delta})$.

If the candidate column would reduce the volume of the factor parallelepiped (i.e., move toward collapse), $\Delta < 0$ and the proposal is likely rejected. If it increases the volume (better separation), it is always accepted. This is a standard MH accept/reject step; the Gibbs proposal serves as the proposal distribution, and the volume prior contributes only to the acceptance ratio.

The MH acceptance rate is tracked and reported as `result.mh_volume_acceptance_rate`. Rates below 10% indicate that `volume_alpha` is too large for the data --- the prior is rejecting most proposals, slowing mixing. Reducing $\alpha$ or increasing the burn-in period can help.

#### 7.3.3 Sparse Gamma Priors

The standard exponential prior $F_{ik} \sim \text{Exp}(\lambda)$ is a special case of the Gamma distribution with shape $a = 1$. The **sparse Gamma prior** generalizes this to:

$$
F_{ik} \sim \text{Gamma}(a_F,\; \lambda_F), \qquad G_{kj} \sim \text{Gamma}(a_G,\; \lambda_G)
$$

The shape parameters `prior_F_shape` ($a_F$) and `prior_G_shape` ($a_G$) control the sparsity of the factors:

- **$a = 1.0$** (default): Standard exponential prior. No additional sparsity.
- **$a < 1$** (e.g., 0.5): The Gamma density has a pole at zero, concentrating mass near zero and inducing **sparse** factor profiles. Many elements are driven close to zero, with a few large values. This is useful when true source profiles are expected to have only a handful of dominant species.
- **$a > 1$**: The density becomes bell-shaped, discouraging very small values. Rarely used in practice.

Like the volume prior, the sparse Gamma prior is non-conjugate (when $a \neq 1$) and is implemented as an MH correction. The log-acceptance ratio includes the term:

$$
(a - 1) \left[\sum_i \log F_{ik}^* - \sum_i \log F_{ik}\right]
$$

which penalizes or rewards the candidate column depending on whether it is sparser than the current one.

#### 7.3.4 Adaptive Relabeling

Without an ACLS warm-start, there is no fixed reference configuration for Hungarian alignment (Section 5.2). Instead, the solver uses **adaptive relabeling**: the alignment reference is initialized from the end-of-burn-in state and updated every 50 thinned samples to the running posterior mean. As the posterior mean stabilizes, the reference converges and label switching is suppressed. This is less sharp than ACLS-anchored alignment but sufficient when combined with the volume prior's geometric separation.

#### 7.3.5 When to Use Full Bayesian Mode

Full Bayesian mode (`warm_start=False, volume_alpha=1`--`5`) is appropriate when:

- You want the posterior to explore freely rather than orbit a single ACLS solution.
- You are combining with ARD to discover the number of factors (ARD defaults to random init for this reason).
- You want to assess whether the ACLS point estimate is representative of the posterior or an outlier.
- The data is small enough that ACLS itself is unreliable (few observations, high noise).

The ACLS warm-start mode remains the default and is recommended for routine environmental PMF applications where fast convergence and sharp factor profiles are the priority.

### 7.4 Robust Inference via Student's t Likelihood

Environmental data often contain **outliers** --- anomalous measurements that deviate far from the model. Under a Gaussian likelihood, these outliers exert strong influence on the factorization. The robust extension replaces the Gaussian likelihood with a **Student's t distribution**, which has heavier tails and is therefore less sensitive to outliers.

The Student's t distribution can be represented as a **Gaussian scale mixture**:

$$
X_{ij} \mid F, G, \eta_{ij} \sim \mathcal{N}\!\left((FG)_{ij},\; \sigma_{ij}^2 / \eta_{ij}\right)
$$

$$
\eta_{ij} \sim \text{Gamma}(\nu/2, \;\nu/2)
$$

where $\nu$ is the degrees of freedom (a user-specified parameter; lower values give heavier tails). The auxiliary variables $\eta_{ij}$ act as per-element precision weights:

- For well-fit data points (small residuals), $\eta_{ij} \approx 1$ and the model behaves like standard Gaussian PMF.
- For outliers (large residuals), $\eta_{ij}$ is driven toward zero, effectively inflating the variance for that element and down-weighting its influence.

This is mathematically elegant: by introducing the auxiliary variables $\eta$, we turn a non-conjugate problem (Student's t) into a sequence of conjugate Gaussian and Gamma updates that fit naturally into the Gibbs sampler.

---

## 8. Warm-Starting and Point Estimates

### 8.1 Why Warm-Start?

Gibbs sampling can be slow to converge from a random initialization, especially in high-dimensional problems. The solver offers a **warm-start** strategy: before beginning Gibbs sampling, it runs multiple independent classical PMF solves (using the ACLS algorithm) with different random seeds and selects the solution with the lowest $Q$.

This serves two purposes:
1. **Faster convergence**: Starting the Gibbs sampler near a good solution dramatically reduces the burn-in period needed.
2. **Sharp point estimate**: The ACLS solution provides well-separated factor profiles that are returned as the primary point estimate (`result.F`, `result.G`), while the Gibbs posterior mean (which may be slightly blurred by residual label switching) is available as `result.F_posterior_mean` and `result.G_posterior_mean`.

In **full Bayesian mode** (`warm_start=False`), no ACLS solve is performed. The sampler starts from a random initialization and relies on the volume prior (Section 7.3) for factor separation. In this case, `result.F` and `result.G` are set to the posterior mean rather than an ACLS point estimate.

### 8.2 Interpreting the Output

The Bayesian PMF solver thus provides two complementary views:

| Output | Source | Best For |
|--------|--------|----------|
| `F`, `G` | ACLS point estimate (warm-start) or posterior mean (full Bayesian) | Interpretation, visualization |
| `F_posterior_mean`, `G_posterior_mean` | Gibbs posterior mean | Prediction, averaging |
| `F_std`, `G_std` | Gibbs posterior std. dev. | Uncertainty quantification |
| `Q_samples` | $Q$ at each sample | Convergence diagnostics |
| `mh_volume_acceptance_rate` | Volume prior MH tracking | Tuning `volume_alpha` |

The posterior standard deviations are proper Bayesian credible-interval widths, reflecting both measurement noise and model non-identifiability. They are *not* bootstrap estimates --- they come directly from the posterior distribution.

---

## 9. Summary of the Algorithm

Putting it all together, the `pmf_bayes` algorithm proceeds as follows:

1. **Initialize** $F$ and $G$:
   - *Warm-start mode* (default): Run multi-seed ACLS solves, keep the best $Q$. The ACLS solution serves as both the Gibbs starting point and the Hungarian alignment reference.
   - *Full Bayesian mode* (`warm_start=False`): Random initialization. Requires `volume_alpha > 0` for factor separation.
2. **Burn-in**: Repeat for $n_{\text{burnin}}$ sweeps:
   - For each factor $k = 1, \ldots, p$:
     - Sample $F_{:,k}$ from its truncated Gaussian full conditional.
     - (If volume prior) Accept/reject via MH using $\det(F^\top F)^{\alpha/2}$.
     - Sample $G_{k,:}$ from its truncated Gaussian full conditional.
   - Sample the scalar noise precision $\tau_{\text{scale}}$.
   - (If hierarchical) Sample $\sigma^2$ from Inverse-Gamma full conditionals.
   - (If robust) Sample precision weights $\eta$ from Gamma full conditionals.
   - (If learning hyperparameters) Sample $\lambda_F$, $\lambda_G$ from Gamma posteriors.
   - Normalize $F$ columns to unit $L_1$ norm; absorb scale into $G$.
   - Align factors to the reference via Hungarian matching.
3. **Sampling**: Repeat for $n_{\text{samples}} \times n_{\text{thin}}$ sweeps:
   - Perform the same updates as in burn-in.
   - Every $n_{\text{thin}}$ sweeps, record the current $(F, G)$ and $Q$.
   - (If full Bayesian) Periodically update the alignment reference from the running posterior mean.
4. **Summarize**: Compute posterior means and standard deviations from the collected samples. Assess convergence via the Geweke test.

---

## References

- Cemgil, A. T. (2009). Bayesian inference for nonnegative matrix factorisation models. *Computational Intelligence and Neuroscience*, 2009.
- Geweke, J. (1992). Evaluating the accuracy of sampling-based approaches to the calculation of posterior moments. *Bayesian Statistics 4*, 169--193.
- Schmidt, M. N., Winther, O., & Hansen, L. K. (2009). Bayesian non-negative matrix factorization. *Proc. 8th Int. Conf. on Independent Component Analysis*, pp. 540--547.
- Brouwer, T., Frellsen, J., & Lio, P. (2017). Fast Bayesian non-negative matrix factorisation and tri-factorisation. *arXiv preprint arXiv:1610.08127*.
- Fu, X., & Huang, K. (2018). On identifiability of nonnegative matrix factorization. *IEEE Signal Processing Letters*, 25(3), 328--332. (Volume prior and sufficiently scattered condition for NMF identifiability.)
- Yuan, C., & Bhatt, U. (2023). Robust Bayesian non-negative matrix factorization. (Outlier-robust extension via Gaussian-scale mixture.)
