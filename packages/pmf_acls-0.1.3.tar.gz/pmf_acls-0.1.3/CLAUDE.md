# PMF Monorepo

Two projects in one repo:

## pmf_acls/ — PMF Solver Package
A Python implementation of Positive Matrix Factorization with five solver backends (ACLS, LS-NMF, Newton, Bayesian NMF, Bayesian LDA), featuring per-element uncertainty weighting.

## nmf_compare/ — NMF/PMF Benchmarking Framework
Benchmark harness comparing multiple NMF/PMF solvers (pmf_acls, ESAT, scikit-learn NMF) on synthetic data with configurable noise models and matrix sizes.

## Layout

```
pmf_acls/          # Solver package (installable)
nmf_compare/       # Benchmarking scripts and results
scripts/           # Ad-hoc / one-off analysis scripts
examples/          # Usage examples for pmf_acls
docs/              # Literature reviews, specs, notes
reference/         # PMF2/ME2 reference binaries
```

## Running Tests

```bash
pytest pmf_acls/tests/ -v
```

## Running Benchmarks

```bash
python nmf_compare/benchmark_simulation.py --noise-sweep --solvers PMF_ACLS --reps 3 --seeds 5
python nmf_compare/benchmark_simulation.py --size-sweep --solvers PMF_ACLS ESAT_LSNMF --reps 3 --seeds 5
```

## Conventions
- Package imports: `from pmf_acls import pmf, pmf_bayes, pmf_lda`
- Algorithms via `pmf()`: 'acls' (default), 'ls-nmf', 'newton', 'bayes'
- LDA is standalone: `pmf_lda(X, sigma, p)`
- Benchmark outputs go to `nmf_compare/results/`
- NumPy/SciPy only for the solver (no heavy deps)
