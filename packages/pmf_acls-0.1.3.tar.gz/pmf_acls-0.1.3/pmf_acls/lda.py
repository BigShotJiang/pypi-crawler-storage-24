"""
Bayesian LDA-style source apportionment via Dirichlet-Gaussian Gibbs sampling.

Generative model
----------------
    F[:,k]  ~  Dirichlet(α · 1_m)           [source profile k; column on simplex]
    G[k,j]  ~  Exponential(λ_F)              [mixing coefficient; positive]
    X[i,j]  ~  Normal((F@G)[i,j], σ[i,j]²)  [Gaussian emission; sigma exact]

Inference via Metropolis-within-Gibbs:
- F[:,k] columns are updated by coordinate-wise swap Metropolis-Hastings.
  Each step picks two elements (i1, i2), proposes F[i1] += δ, F[i2] -= δ
  for δ ~ N(0, σ_step²), and accepts/rejects via the exact MH ratio.  The
  swap proposal is symmetric on the simplex (no proposal correction needed),
  and only the two affected residual rows are recomputed per step (O(n)).
- G[k,:] rows are updated in closed form (truncated-Gaussian full conditional,
  identical to the Bayesian NMF in bayes.py).

Two convergence traces are stored at each thinned sample:
- kl_samples : generalized KL divergence D(X || F@G)  — primary Geweke trace.
- Q_samples  : weighted chi-squared Σ((X-F@G)/σ)²    — PMFResult compatibility.

Convention: F is (m, p), G is (p, n) — matches the rest of pmf_acls.
F[:,k] sums to 1 over variables (source composition); absolute scale is in G.

Key difference from pmf_bayes
------------------------------
In bayes.py, F columns have independent exponential priors and are normalized
to unit L1 post-hoc.  Here, each F[:,k] has a *joint* Dirichlet prior, so the
simplex constraint is enforced by the prior and the swap MH proposal — the
sum-to-one property is preserved exactly by construction throughout sampling.
This makes F[:,k] a proper compositional source fingerprint.

References
----------
Blei, D. M., Ng, A. Y., & Jordan, M. I. (2003).
    Latent Dirichlet Allocation. JMLR, 3, 993-1022.

Pritchard, J. K., Stephens, M., & Donnelly, P. (2000).
    Inference of population structure using multilocus genotype data.
    Genetics, 155(2), 945-959.

Schmidt, M. N., Winther, O., & Hansen, L. K. (2009).
    Bayesian non-negative matrix factorization. ICA, pp. 540-547.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Optional

import numpy as np

from .bayes import _geweke_z, _make_sampler, _sample_G_row
from .data_structures import PMFResult
from .validation import validate_data_matrix, validate_uncertainty_matrix, validate_rank


# ---------------------------------------------------------------------------
# Result container
# ---------------------------------------------------------------------------

@dataclass
class LDAResult:
    """
    Container for Bayesian LDA source apportionment results.

    Attributes
    ----------
    F : ndarray, shape (m, p)
        Posterior mean source profiles.  Each column lies on the probability
        simplex (sums to 1 over variables) — a compositional fingerprint.
    G : ndarray, shape (p, n)
        Posterior mean mixing coefficients (absolute scale, exponential prior).
        G[k, j] is the total contribution of source k to sample j.
    F_std : ndarray, shape (m, p)
        Posterior standard deviation of F.
    G_std : ndarray, shape (p, n)
        Posterior standard deviation of G.
    F_samples : ndarray or None, shape (n_samples, m, p)
        Full posterior samples of F if store_samples=True, else None.
    G_samples : ndarray or None, shape (n_samples, p, n)
        Full posterior samples of G if store_samples=True, else None.
    kl_samples : ndarray, shape (n_samples,)
        Generalized KL divergence D(X || F@G) at each thinned sample.
        Primary convergence trace; used for Geweke z-score diagnostic.
    Q_samples : ndarray, shape (n_samples,)
        Weighted chi-squared Q = Σ((X-F@G)/σ)² at each thinned sample.
        Secondary trace for compatibility with PMFResult diagnostics.
    kl : float
        KL divergence evaluated at the posterior mean F and G.
    Q : float
        Q evaluated at the posterior mean F and G.
    n_iter : int
        Total Gibbs sweeps performed (burn-in + sampling × thin).
    converged : bool
        True if abs(Geweke z-score) on kl_samples < 2.0.
    alpha : float
        Dirichlet concentration parameter (fixed; not updated during sampling).
    lambda_G : float
        Posterior mean of the exponential rate for G elements.
    mh_acceptance_rate : float
        Fraction of coordinate-swap MH proposals accepted for F during the
        sampling phase.  Includes non-negativity rejections in the denominator.
        Target range 0.1–0.5; tune mh_step_size if outside this range.
    residuals : ndarray, shape (m, n)
        X - F @ G evaluated at the posterior mean.
    explained_variance : float
        R² at the posterior mean.
    chi2 : float
        Q / degrees_of_freedom at the posterior mean.
    """

    F: np.ndarray
    G: np.ndarray
    F_std: np.ndarray
    G_std: np.ndarray
    F_samples: Optional[np.ndarray]
    G_samples: Optional[np.ndarray]
    kl_samples: np.ndarray
    Q_samples: np.ndarray
    kl: float
    Q: float
    n_iter: int
    converged: bool
    alpha: float
    lambda_G: float
    mh_acceptance_rate: float
    residuals: np.ndarray
    explained_variance: float
    chi2: float

    def __repr__(self) -> str:
        m, p = self.F.shape
        _, n = self.G.shape
        conv_str = "Yes" if self.converged else "No"
        return (
            f"LDAResult(\n"
            f"  Shape: {m} variables × {n} observations × {p} factors\n"
            f"  Converged (Geweke): {conv_str}\n"
            f"  Samples collected: {len(self.kl_samples)}\n"
            f"  KL (posterior mean): {self.kl:.4e}\n"
            f"  Q  (posterior mean): {self.Q:.4e}\n"
            f"  Explained variance: {self.explained_variance:.2%}\n"
            f"  chi2: {self.chi2:.4f}\n"
            f"  MH acceptance rate: {self.mh_acceptance_rate:.2%}\n"
            f"  alpha: {self.alpha:.4f}  lambda_G: {self.lambda_G:.4f}\n"
            f")"
        )

    def to_pmf_result(self) -> PMFResult:
        """
        Wrap as PMFResult for compatibility with diagnostics and uncertainty tools.

        F columns remain on the simplex.  Q_samples is used as Q_history.
        chi2 is computed from the Gaussian-noise Q objective using sigma.
        """
        return PMFResult(
            F=self.F.copy(),
            G=self.G.copy(),
            Q=self.Q,
            Q_history=list(self.Q_samples),
            n_iter=self.n_iter,
            converged=self.converged,
            residuals=self.residuals.copy(),
            explained_variance=self.explained_variance,
            chi2=self.chi2,
            F_std=self.F_std.copy(),
            G_std=self.G_std.copy(),
        )


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _compute_kl(F: np.ndarray, G: np.ndarray, X: np.ndarray) -> float:
    """
    Generalized KL divergence D(X || F@G) = Σ [X·log(X/GF) - X + GF].

    Entries where X == 0 contribute 0 by the limit x·log(x) → 0 as x → 0⁺.
    """
    GF = np.maximum(F @ G, 1e-300)
    mask = X > 0
    return float(
        np.sum(X[mask] * np.log(X[mask] / GF[mask]) - X[mask] + GF[mask])
        + np.sum(GF[~mask])
    )


def _compute_Q(F: np.ndarray, G: np.ndarray, X: np.ndarray, sigma: np.ndarray) -> float:
    """Weighted chi-squared Q = Σ((X - F@G)/σ)²."""
    return float(np.sum(((X - F @ G) / sigma) ** 2))


def _mh_steps_G_col(
    F_col: np.ndarray,
    G_row: np.ndarray,
    R: np.ndarray,
    sigma2: np.ndarray,
    alpha: float,
    step_sigma: float,
    rng: np.random.Generator,
) -> tuple:
    """
    m coordinate-wise swap MH steps for one column of F.

    Each step:
    1. Pick two distinct element indices i1, i2 uniformly at random.
    2. Propose δ ~ N(0, step_sigma²); update F[i1] += δ, F[i2] -= δ.
    3. Reject immediately if either proposed value is non-positive.
    4. Compute the exact log MH acceptance ratio and accept/reject.

    The swap proposal is symmetric (proposal ratio = 0), so:
        log r = (α−1) · [log F_new[i1]/F_cur[i1] + log F_new[i2]/F_cur[i2]]
              − ½ · ΔSS restricted to rows i1, i2

    Only rows i1 and i2 of the residual change per step (O(n) per step),
    making each coordinate update O(n) rather than O(m·n).

    The sum-to-one simplex constraint is preserved exactly throughout
    because accepted swaps add and subtract the same δ.

    Parameters
    ----------
    F_col     : (m,) current F[:,k]
    G_row     : (n,) current G[k,:]
    R         : (m, n) current full residual X - F@G
    sigma2    : (m, n) squared uncertainties
    alpha     : float, symmetric Dirichlet concentration (> 0)
    step_sigma: float, std of the coordinate swap proposal
    rng       : numpy random Generator

    Returns
    -------
    G_col_new : (m,) updated column (sum preserved = 1)
    R_new     : (m, n) updated full residual
    n_accepted: int, coordinate steps accepted (out of m proposals)
    """
    m = F_col.shape[0]
    F_cur = F_col.copy()
    R_cur = R.copy()
    n_accepted = 0

    for _ in range(m):
        i1, i2 = rng.choice(m, size=2, replace=False)
        delta = rng.normal(0.0, step_sigma)

        g1_new = F_cur[i1] + delta
        g2_new = F_cur[i2] - delta
        if g1_new <= 0.0 or g2_new <= 0.0:
            continue

        # Only rows i1, i2 of R change
        r1_new = R_cur[i1, :] - delta * G_row
        r2_new = R_cur[i2, :] + delta * G_row

        log_lik_ratio = -0.5 * (
            np.sum(r1_new ** 2 / sigma2[i1, :]) - np.sum(R_cur[i1, :] ** 2 / sigma2[i1, :])
            + np.sum(r2_new ** 2 / sigma2[i2, :]) - np.sum(R_cur[i2, :] ** 2 / sigma2[i2, :])
        )
        log_prior_ratio = (alpha - 1.0) * (
            np.log(g1_new) - np.log(F_cur[i1])
            + np.log(g2_new) - np.log(F_cur[i2])
        )

        if np.log(rng.uniform()) < log_lik_ratio + log_prior_ratio:
            F_cur[i1] = g1_new
            F_cur[i2] = g2_new
            R_cur[i1, :] = r1_new
            R_cur[i2, :] = r2_new
            n_accepted += 1

    return F_cur, R_cur, n_accepted


def _sort_factors(F: np.ndarray, G: np.ndarray) -> tuple:
    """
    Sort factors by decreasing G row L1 mass.

    F columns are already on the simplex; no normalization is applied.
    The F@G product is preserved (permutation of factors).
    """
    order = np.argsort(-G.sum(axis=1))
    return F[:, order], G[order, :]


def _gibbs_sweep_lda(
    F: np.ndarray,
    G: np.ndarray,
    R: np.ndarray,
    sigma2: np.ndarray,
    alpha: float,
    lambda_G: float,
    step_sigma: float,
    rng: np.random.Generator,
    sample_fn: Callable,
) -> tuple:
    """
    One full Gibbs sweep for the LDA model.

    Step 1 — For each factor k: m coordinate-wise swap MH steps for F[:,k].
    Step 2 — For each factor k: closed-form truncated-Gaussian update for G[k,:].

    R = X - F@G is maintained throughout both steps.

    Returns
    -------
    F, G, R    : updated matrices
    n_accepted : total coordinate MH steps accepted across all p factors
    n_proposed : total coordinate MH proposals made (= p * m)
    """
    p = F.shape[1]
    n_accepted = 0

    for k in range(p):
        F_new_col, R, n_acc = _mh_steps_G_col(
            F[:, k], G[k, :], R, sigma2, alpha, step_sigma, rng
        )
        F[:, k] = F_new_col
        n_accepted += n_acc

    for k in range(p):
        G_k_new = _sample_G_row(F[:, k], G[k, :], R, sigma2, lambda_G, rng, sample_fn)
        R += np.outer(F[:, k], G[k, :]) - np.outer(F[:, k], G_k_new)
        G[k, :] = G_k_new

    return F, G, R, n_accepted


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def pmf_lda(
    X: np.ndarray,
    sigma: np.ndarray,
    p: int,
    n_samples: int = 1000,
    n_burnin: int = 500,
    n_thin: int = 1,
    alpha: float = 1.0,
    lambda_G: float = 1.0,
    learn_hyperparams: bool = True,
    hyperparam_shape: float = 1.0,
    hyperparam_rate: float = 0.1,
    mh_step_size: float = 1.0,
    F_init: Optional[np.ndarray] = None,
    G_init: Optional[np.ndarray] = None,
    init_method: str = "random",
    store_samples: bool = False,
    sampler: str = "icdf",
    random_seed: Optional[int] = None,
    verbose: bool = False,
) -> LDAResult:
    """
    Bayesian LDA-style source apportionment via Dirichlet-Gaussian Gibbs sampling.

    Source profiles F[:,k] are Dirichlet-distributed (simplex-constrained
    compositions); mixing coefficients G[k,j] are exponentially distributed
    (positive); observations follow a Gaussian likelihood with known per-element
    uncertainties sigma.  F columns are updated via coordinate-wise swap
    Metropolis-Hastings; G rows are updated in closed form (truncated Gaussian).

    Parameters
    ----------
    X : ndarray, shape (m, n)
        Data matrix. Must be non-negative and finite.
    sigma : ndarray, shape (m, n)
        Per-element measurement uncertainties. Must be positive and finite.
        Enters the Gaussian emission likelihood exactly.
    p : int
        Number of sources (factors).
    n_samples : int, default=1000
        Number of posterior samples to collect after burn-in.
    n_burnin : int, default=500
        Number of Gibbs sweeps to discard as burn-in.
    n_thin : int, default=1
        Thinning factor: collect 1 sample every n_thin sweeps.
    alpha : float, default=1.0
        Symmetric Dirichlet concentration for F columns.  alpha=1 gives a
        uniform prior over compositions; alpha<1 promotes sparser profiles.
        Not updated during sampling (fixed hyperparameter).
    lambda_G : float, default=1.0
        Initial exponential rate for the G prior.  Auto-tuned when
        learn_hyperparams=True.
    learn_hyperparams : bool, default=True
        If True, update lambda_G each sweep via conjugate Gamma posterior.
        alpha is fixed and not updated.
    hyperparam_shape : float, default=1.0
        Shape (a) for the Gamma(a, b) hyperprior on lambda_G.
    hyperparam_rate : float, default=0.1
        Rate (b) for the Gamma(a, b) hyperprior on lambda_G.
    mh_step_size : float, default=1.0
        Scale of the coordinate-swap MH proposal for F columns.  The
        proposal std is step_sigma = mh_step_size / m, making it
        scale-invariant with respect to the number of variables.  With
        the default mh_step_size=1.0, proposals shift elements by ≈1/m
        (approximately one typical element magnitude for uniform F).
        Decrease for higher acceptance; increase for larger jumps.
        Target acceptance rate: 0.1–0.5.
    F_init : ndarray, shape (m, p), optional
        Initial F matrix.  Columns are projected onto the simplex after
        loading.  Warm-starting from an ACLS solution reduces burn-in.
    G_init : ndarray, shape (p, n), optional
        Initial G matrix.
    init_method : {'random', 'random_acol', 'svd_centroid'}, default='random'
        Initialization method when F_init/G_init are not provided.
    store_samples : bool, default=False
        If True, store full F and G posterior chains.
        Memory: O(n_samples × (m·p + p·n)).
    sampler : {'icdf', 'scipy'}, default='icdf'
        Truncated-normal sampler for G row updates.  'icdf' avoids
        scipy.stats dispatch overhead (3–5× faster).  See pmf_bayes.
    random_seed : int, optional
        Seed for reproducibility.
    verbose : bool, default=False
        Print progress every 100 iterations.

    Returns
    -------
    result : LDAResult
        Posterior means, standard deviations, convergence traces, and metadata.
        Call result.to_pmf_result() for compatibility with diagnostics.

    Notes
    -----
    F columns satisfy F[:,k].sum() == 1 for all k throughout sampling —
    the coordinate-swap proposal preserves the simplex constraint exactly.
    Absolute scale is carried by G, so X ≈ F @ G in the original units.

    The MH acceptance rate is reported in result.mh_acceptance_rate.
    It counts all m coordinate proposals per factor per sweep (including
    non-negativity rejections) in the denominator.  Values outside 0.1–0.5
    suggest mh_step_size should be adjusted.

    alpha is a fixed hyperparameter.  Smaller alpha (< 1) concentrates
    source profiles on fewer analytes; larger alpha (> 1) smooths profiles
    toward the uniform composition.

    References
    ----------
    Blei, D. M., Ng, A. Y., & Jordan, M. I. (2003).
        Latent Dirichlet Allocation. JMLR, 3, 993-1022.
    Pritchard, J. K., Stephens, M., & Donnelly, P. (2000).
        Inference of population structure using multilocus genotype data.
        Genetics, 155(2), 945-959.
    Schmidt, M. N., Winther, O., & Hansen, L. K. (2009).
        Bayesian non-negative matrix factorization. ICA, pp. 540-547.
    """
    # ---- Input validation ----
    validate_data_matrix(X, "X")
    m, n = X.shape
    validate_uncertainty_matrix(sigma, X.shape)
    validate_rank(p, m, n)

    if n_samples < 1:
        raise ValueError(f"n_samples must be >= 1, got {n_samples}")
    if n_burnin < 0:
        raise ValueError(f"n_burnin must be >= 0, got {n_burnin}")
    if n_thin < 1:
        raise ValueError(f"n_thin must be >= 1, got {n_thin}")
    if alpha <= 0:
        raise ValueError(f"alpha must be > 0, got {alpha}")
    if lambda_G <= 0:
        raise ValueError(f"lambda_G must be > 0, got {lambda_G}")
    if mh_step_size <= 0:
        raise ValueError(f"mh_step_size must be > 0, got {mh_step_size}")
    if hyperparam_shape <= 0:
        raise ValueError(f"hyperparam_shape must be > 0, got {hyperparam_shape}")
    if hyperparam_rate <= 0:
        raise ValueError(f"hyperparam_rate must be > 0, got {hyperparam_rate}")

    # step_sigma = mh_step_size / m gives scale-invariant proposal size
    step_sigma = mh_step_size / m

    sample_fn = _make_sampler(sampler)

    # ---- Initialization ----
    from .core import initialize_factors

    rng = np.random.default_rng(random_seed)
    seed_for_init = int(rng.integers(0, 2**31)) if random_seed is not None else None
    F, G = initialize_factors(
        m=m, n=n, p=p, X=X,
        F_init=F_init, G_init=G_init,
        random_seed=seed_for_init,
        init_method=init_method,
    )

    # Project F columns onto the probability simplex: clip to positive, then
    # normalize to unit L1.  Absorb the scale change into G to preserve F@G.
    for k in range(p):
        F[:, k] = np.maximum(F[:, k], 1e-10)
        col_sum = F[:, k].sum()
        F[:, k] /= col_sum
        G[k, :] *= col_sum

    sigma2 = sigma ** 2
    R = X - F @ G

    # ---- Storage ----
    kl_samples = np.empty(n_samples)
    Q_samples = np.empty(n_samples)
    if store_samples:
        F_samples_arr: Optional[np.ndarray] = np.empty((n_samples, m, p))
        G_samples_arr: Optional[np.ndarray] = np.empty((n_samples, p, n))
    else:
        F_samples_arr = None
        G_samples_arr = None

    # Welford online accumulators for posterior mean and variance
    F_mean = np.zeros((m, p))
    G_mean = np.zeros((p, n))
    F_M2 = np.zeros((m, p))
    G_M2 = np.zeros((p, n))
    n_collected = 0

    lambda_F_cur = float(lambda_G)
    lambda_F_acc = 0.0

    # MH tracking: proposals per sweep = p * m (m coordinate steps per factor)
    proposals_per_sweep = p * m
    mh_accepted_sample = 0
    mh_proposals_sample = 0

    # ---- Burn-in ----
    if verbose:
        print(f"LDA: burn-in ({n_burnin} sweeps)...")

    mh_accepted_burnin = 0
    for i in range(n_burnin):
        F, G, R, n_acc = _gibbs_sweep_lda(
            F, G, R, sigma2, alpha, lambda_F_cur, step_sigma, rng, sample_fn
        )
        mh_accepted_burnin += n_acc

        if learn_hyperparams:
            lambda_F_cur = float(rng.gamma(
                shape=hyperparam_shape + p * n,
                scale=1.0 / (hyperparam_rate + G.sum()),
            ))

        F, G = _sort_factors(F, G)
        R = X - F @ G  # recompute after sort

        if verbose and (i + 1) % 100 == 0:
            kl_cur = _compute_kl(F, G, X)
            acc_rate = mh_accepted_burnin / max((i + 1) * proposals_per_sweep, 1)
            print(
                f"  burn-in {i+1}/{n_burnin}  "
                f"KL={kl_cur:.4e}  λ_F={lambda_F_cur:.3f}  "
                f"MH acc={acc_rate:.2%}"
            )

    # ---- Sampling ----
    if verbose:
        print(f"LDA: sampling ({n_samples} draws, thin={n_thin})...")

    sample_idx = 0
    for i in range(n_samples * n_thin):
        F, G, R, n_acc = _gibbs_sweep_lda(
            F, G, R, sigma2, alpha, lambda_F_cur, step_sigma, rng, sample_fn
        )
        mh_accepted_sample += n_acc
        mh_proposals_sample += proposals_per_sweep

        if learn_hyperparams:
            lambda_F_cur = float(rng.gamma(
                shape=hyperparam_shape + p * n,
                scale=1.0 / (hyperparam_rate + G.sum()),
            ))

        F, G = _sort_factors(F, G)
        R = X - F @ G

        if (i + 1) % n_thin == 0:
            kl_cur = _compute_kl(F, G, X)
            Q_cur = _compute_Q(F, G, X, sigma)
            kl_samples[sample_idx] = kl_cur
            Q_samples[sample_idx] = Q_cur

            if store_samples:
                F_samples_arr[sample_idx] = F.copy()
                G_samples_arr[sample_idx] = G.copy()

            # Welford update
            n_collected += 1
            dG = F - F_mean
            F_mean += dG / n_collected
            F_M2 += dG * (F - F_mean)

            dF = G - G_mean
            G_mean += dF / n_collected
            G_M2 += dF * (G - G_mean)

            lambda_F_acc += lambda_F_cur
            sample_idx += 1

            if verbose and sample_idx % 100 == 0:
                acc_rate = mh_accepted_sample / max(mh_proposals_sample, 1)
                print(
                    f"  sample {sample_idx}/{n_samples}  "
                    f"KL={kl_cur:.4e}  Q={Q_cur:.4e}  "
                    f"λ_F={lambda_F_cur:.3f}  MH acc={acc_rate:.2%}"
                )

    # ---- Posterior summaries ----
    F_std = np.sqrt(F_M2 / max(n_collected - 1, 1))
    G_std = np.sqrt(G_M2 / max(n_collected - 1, 1))
    lambda_F_final = lambda_F_acc / n_collected if n_collected > 0 else lambda_F_cur
    mh_acceptance_rate = mh_accepted_sample / max(mh_proposals_sample, 1)

    kl_final = _compute_kl(F_mean, G_mean, X)
    Q_final = _compute_Q(F_mean, G_mean, X, sigma)
    residuals = X - F_mean @ G_mean

    SS_res = float(np.sum(residuals ** 2))
    SS_tot = float(np.sum((X - X.mean()) ** 2))
    explained_variance = 1.0 - SS_res / SS_tot if SS_tot > 1e-30 else 0.0

    dof = m * n - (m + n) * p
    chi2 = Q_final / dof if dof > 0 else float("nan")

    geweke = abs(_geweke_z(kl_samples)) if len(kl_samples) >= 10 else float("inf")
    converged = bool(geweke < 2.0)

    if verbose:
        print(
            f"Done. KL={kl_final:.4e}  Q={Q_final:.4e}  "
            f"Geweke |z|={geweke:.2f}  converged={converged}  "
            f"MH acc={mh_acceptance_rate:.2%}"
        )

    return LDAResult(
        F=F_mean,
        G=G_mean,
        F_std=F_std,
        G_std=G_std,
        F_samples=F_samples_arr,
        G_samples=G_samples_arr,
        kl_samples=kl_samples,
        Q_samples=Q_samples,
        kl=kl_final,
        Q=Q_final,
        n_iter=n_burnin + n_samples * n_thin,
        converged=converged,
        alpha=alpha,
        lambda_G=lambda_F_final,
        mh_acceptance_rate=mh_acceptance_rate,
        residuals=residuals,
        explained_variance=explained_variance,
        chi2=chi2,
    )
