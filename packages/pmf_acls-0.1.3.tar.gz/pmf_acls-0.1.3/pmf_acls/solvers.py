"""
Solver backends for PMF linear system.

This module provides multiple solver backends for solving the PMF linear system:
    LSM @ φ = RSV
where LSM is the left-side matrix and RSV is the right-side vector.

Available solvers:
- NumPy (default): Dense solver using numpy.linalg.solve
- PyTorch: Dense solver using torch.linalg.solve with optional GPU acceleration
- JAX: Dense solver using jax.scipy.linalg.solve with JIT compilation
- JAX Sparse: Sparse solver using jax.experimental.sparse
"""

from typing import Tuple, Union, Optional, Dict
import numpy as np
import scipy.sparse as sp
import warnings


def _to_dense(LSM: Union[np.ndarray, sp.spmatrix]) -> np.ndarray:
    """Convert a sparse matrix to dense; pass dense through."""
    return LSM.toarray() if sp.issparse(LSM) else LSM


def _compute_rcond_numpy(LSM: Union[np.ndarray, sp.spmatrix]) -> float:
    """
    Fast reciprocal condition estimator using NumPy.

    Using NumPy here keeps us off the JAX compilation path; we only need
    an approximate condition estimate to issue warnings.
    """
    LSM_dense = _to_dense(LSM)

    try:
        cond = np.linalg.cond(LSM_dense)
        rcond = 1.0 / cond if np.isfinite(cond) else 0.0
    except np.linalg.LinAlgError:
        rcond = 0.0

    return rcond


# Cache solver instances (especially JAX) to avoid repeated JIT compilation
_SOLVER_CACHE: Dict[str, "SolverBackend"] = {}


class SolverBackend:
    """Base class for solver backends."""

    def __init__(self, name: str):
        """Initialize solver backend."""
        self.name = name

    def solve(
        self, LSM: Union[np.ndarray, sp.spmatrix], RSV: np.ndarray
    ) -> np.ndarray:
        """
        Solve linear system LSM @ phi = RSV.

        Parameters
        ----------
        LSM : ndarray or sparse matrix
            Left-side matrix (system matrix)
        RSV : ndarray
            Right-side vector

        Returns
        -------
        phi : ndarray
            Solution vector

        Raises
        ------
        NotImplementedError
            Must be implemented by subclass
        """
        raise NotImplementedError("Subclasses must implement solve()")

    def compute_condition_number(
        self, LSM: Union[np.ndarray, sp.spmatrix]
    ) -> float:
        """
        Compute reciprocal condition number of LSM.

        Parameters
        ----------
        LSM : ndarray or sparse matrix
            System matrix

        Returns
        -------
        rcond : float
            Reciprocal condition number (0 = singular, 1 = well-conditioned)

        Notes
        -----
        Uses LAPACK's reciprocal condition estimator. A small rcond (< 1e-12)
        indicates the matrix is close to singular and regularization should
        be increased.

        See Lu & Wu (2005), Section 3.6.
        """
        raise NotImplementedError(
            "Subclasses must implement compute_condition_number()"
        )


class NumPySolver(SolverBackend):
    """
    NumPy-based dense solver.

    Uses numpy.linalg.solve for solving linear systems. This is the default
    solver and works for all problem sizes, though it may be slower for
    very large problems.
    """

    def __init__(self):
        """Initialize NumPy solver."""
        super().__init__("numpy")

    def solve(
        self, LSM: Union[np.ndarray, sp.spmatrix], RSV: np.ndarray
    ) -> np.ndarray:
        """
        Solve linear system using NumPy.

        Parameters
        ----------
        LSM : ndarray or sparse matrix
            Left-side matrix. If sparse, will be converted to dense.
        RSV : ndarray
            Right-side vector

        Returns
        -------
        phi : ndarray
            Solution vector
        """
        LSM_dense = _to_dense(LSM)

        try:
            phi = np.linalg.solve(LSM_dense, RSV)
        except np.linalg.LinAlgError as e:
            raise RuntimeError(
                f"Linear system solve failed: {e}. "
                f"Try increasing regularization (gamma, delta) or "
                f"check for ill-conditioned data."
            ) from e

        return phi

    def compute_condition_number(
        self, LSM: Union[np.ndarray, sp.spmatrix]
    ) -> float:
        """
        Compute reciprocal condition number using NumPy.

        Parameters
        ----------
        LSM : ndarray or sparse matrix
            System matrix

        Returns
        -------
        rcond : float
            Reciprocal condition number
        """
        return _compute_rcond_numpy(LSM)


class JAXSolver(SolverBackend):
    """
    JAX-based dense solver with JIT compilation.

    Uses jax.scipy.linalg.solve with JIT compilation for improved performance.
    Particularly beneficial for repeated solves and when GPU is available.

    Requires:
    - jax
    - jaxlib
    """

    def __init__(self):
        """
        Initialize JAX solver.

        Raises
        ------
        ImportError
            If JAX is not installed
        """
        super().__init__("jax")

        try:
            import jax
            import jax.numpy as jnp
            import jax.scipy.linalg as jla

            self.jax = jax
            self.jnp = jnp
            self.jla = jla

            # Create JIT-compiled solve function
            @jax.jit
            def _solve_jit(A, b):
                return jla.solve(A, b)

            self._solve_jit = _solve_jit

        except ImportError as e:
            raise ImportError(
                "JAX solver requires jax and jaxlib. "
                "Install with: pip install jax jaxlib"
            ) from e

    def solve(
        self, LSM: Union[np.ndarray, sp.spmatrix], RSV: np.ndarray
    ) -> np.ndarray:
        """
        Solve linear system using JAX.

        Parameters
        ----------
        LSM : ndarray or sparse matrix
            Left-side matrix. If sparse, will be converted to dense.
        RSV : ndarray
            Right-side vector

        Returns
        -------
        phi : ndarray
            Solution vector (as NumPy array)
        """
        # Convert sparse to dense if needed
        if sp.issparse(LSM):
            LSM_dense = LSM.toarray()
        else:
            LSM_dense = LSM

        # Convert to JAX arrays
        LSM_jax = self.jnp.array(LSM_dense)
        RSV_jax = self.jnp.array(RSV)

        # Solve using JIT-compiled function
        try:
            phi_jax = self._solve_jit(LSM_jax, RSV_jax)
        except Exception as e:
            raise RuntimeError(
                f"JAX linear system solve failed: {e}. "
                f"Try increasing regularization (gamma, delta) or "
                f"check for ill-conditioned data."
            ) from e

        # Convert back to NumPy
        phi = np.array(phi_jax)

        return phi

    def compute_condition_number(
        self, LSM: Union[np.ndarray, sp.spmatrix]
    ) -> float:
        """
        Compute reciprocal condition number using JAX.

        Parameters
        ----------
        LSM : ndarray or sparse matrix
            System matrix

        Returns
        -------
        rcond : float
            Reciprocal condition number
        """
        return _compute_rcond_numpy(LSM)


class PyTorchSolver(SolverBackend):
    """
    PyTorch-based dense solver with optional GPU acceleration.

    Uses torch.linalg.solve for solving linear systems. Benefits from
    automatic GPU acceleration when CUDA is available, and can be faster
    than NumPy for larger problems.

    Requires:
    - torch
    """

    def __init__(self, device: Optional[str] = None):
        """
        Initialize PyTorch solver.

        Parameters
        ----------
        device : str, optional
            Device to use ('cpu', 'cuda'). If None, auto-detect best device.
            Note: MPS (Apple Silicon) is not used because it doesn't support float64,
            which is required for numerical precision in PMF.

        Raises
        ------
        ImportError
            If PyTorch is not installed or incompatible with NumPy
        """
        super().__init__("pytorch")

        try:
            import torch

            self.torch = torch

            # Auto-detect best device
            # Note: MPS doesn't support float64, so we skip it for PMF precision
            if device is None:
                if torch.cuda.is_available():
                    self.device = torch.device("cuda")
                else:
                    # Skip MPS even if available - doesn't support float64
                    self.device = torch.device("cpu")
            else:
                self.device = torch.device(device)

        except (ImportError, RuntimeError) as e:
            error_msg = str(e)
            if "Numpy" in error_msg or "NumPy" in error_msg:
                raise ImportError(
                    "PyTorch solver requires a version of torch compatible with your NumPy version. "
                    "Your environment has NumPy 2.x, but the installed PyTorch was compiled against NumPy 1.x. "
                    "Try: pip install torch>=2.5.0 (requires CUDA or ARM Mac), or downgrade to numpy<2, "
                    "or use solver='numpy' or solver='jax' instead."
                ) from e
            else:
                raise ImportError(
                    "PyTorch solver requires torch. "
                    "Install with: pip install torch"
                ) from e

    def solve(
        self, LSM: Union[np.ndarray, sp.spmatrix], RSV: np.ndarray
    ) -> np.ndarray:
        """
        Solve linear system using PyTorch.

        Parameters
        ----------
        LSM : ndarray or sparse matrix
            Left-side matrix. If sparse, will be converted to dense.
        RSV : ndarray
            Right-side vector

        Returns
        -------
        phi : ndarray
            Solution vector (as NumPy array)
        """
        # Convert sparse to dense if needed
        if sp.issparse(LSM):
            LSM_dense = LSM.toarray()
        else:
            LSM_dense = LSM

        # Convert to PyTorch tensors and move to device
        LSM_torch = self.torch.tensor(
            LSM_dense, dtype=self.torch.float64, device=self.device
        )
        RSV_torch = self.torch.tensor(
            RSV, dtype=self.torch.float64, device=self.device
        )

        # Solve using PyTorch
        try:
            phi_torch = self.torch.linalg.solve(LSM_torch, RSV_torch)
        except Exception as e:
            raise RuntimeError(
                f"PyTorch linear system solve failed: {e}. "
                f"Try increasing regularization (gamma, delta) or "
                f"check for ill-conditioned data."
            ) from e

        # Convert back to NumPy (move to CPU first if needed)
        # Use detach() to avoid gradient tracking issues with NumPy conversion
        phi = phi_torch.detach().cpu().numpy()

        return phi

    def compute_condition_number(
        self, LSM: Union[np.ndarray, sp.spmatrix]
    ) -> float:
        """
        Compute reciprocal condition number using PyTorch.

        Parameters
        ----------
        LSM : ndarray or sparse matrix
            System matrix

        Returns
        -------
        rcond : float
            Reciprocal condition number
        """
        # Convert sparse to dense if needed
        if sp.issparse(LSM):
            LSM_dense = LSM.toarray()
        else:
            LSM_dense = LSM

        # Convert to PyTorch tensor
        LSM_torch = self.torch.tensor(
            LSM_dense, dtype=self.torch.float64, device=self.device
        )

        # Compute condition number
        try:
            cond = self.torch.linalg.cond(LSM_torch)
            cond_np = float(cond.cpu().item())
            rcond = 1.0 / cond_np if np.isfinite(cond_np) else 0.0
        except Exception:
            rcond = 0.0

        return rcond


class JAXSparseSolver(SolverBackend):
    """
    JAX-based sparse solver.

    Uses JAX's experimental sparse linear algebra for solving sparse systems.
    Best for large problems where the system matrix is sparse.

    Requires:
    - jax
    - jaxlib

    Note: JAX sparse support is experimental and may have limitations.
    """

    def __init__(self):
        """
        Initialize JAX sparse solver.

        Raises
        ------
        ImportError
            If JAX is not installed
        """
        super().__init__("jax_sparse")

        try:
            import jax
            import jax.numpy as jnp

            # Try to import sparse module
            try:
                import jax.experimental.sparse as jsp
                self.jsp = jsp
            except (ImportError, AttributeError):
                # Fallback for different JAX versions
                try:
                    from jax.experimental import sparse as jsp
                    self.jsp = jsp
                except ImportError:
                    raise ImportError(
                        "JAX sparse module not available. "
                        "JAX sparse support is experimental."
                    )

            self.jax = jax
            self.jnp = jnp

        except ImportError as e:
            raise ImportError(
                "JAX sparse solver requires jax and jaxlib. "
                "Install with: pip install jax jaxlib"
            ) from e

    def solve(
        self, LSM: Union[np.ndarray, sp.spmatrix], RSV: np.ndarray
    ) -> np.ndarray:
        """
        Solve linear system using JAX sparse solver.

        Parameters
        ----------
        LSM : ndarray or sparse matrix
            Left-side matrix. Should be sparse for best performance.
        RSV : ndarray
            Right-side vector

        Returns
        -------
        phi : ndarray
            Solution vector (as NumPy array)

        Notes
        -----
        JAX sparse support is experimental. For some problem configurations,
        this may fall back to dense solve or raise errors.
        """
        # Ensure LSM is in CSR format
        if sp.issparse(LSM):
            LSM_csr = sp.csr_matrix(LSM)
        else:
            LSM_csr = sp.csr_matrix(LSM)

        # Convert to JAX arrays
        RSV_jax = self.jnp.array(RSV)

        # Try to use JAX sparse solve
        # Note: JAX sparse API can vary by version
        try:
            # Convert scipy sparse to JAX sparse format
            # This may require different approaches depending on JAX version
            data = self.jnp.array(LSM_csr.data)
            indices = self.jnp.array(LSM_csr.indices)
            indptr = self.jnp.array(LSM_csr.indptr)

            # Create JAX sparse matrix
            # API may vary - try BCOO format as it's more stable
            LSM_jax_dense = self.jnp.array(LSM_csr.toarray())

            # For now, fall back to dense solve with JAX
            # True sparse solve in JAX is still evolving
            warnings.warn(
                "JAX sparse solver falling back to dense solve. "
                "JAX sparse linear solve support is limited.",
                UserWarning,
            )

            from jax.scipy.linalg import solve as jax_solve

            phi_jax = jax_solve(LSM_jax_dense, RSV_jax)

        except Exception as e:
            raise RuntimeError(
                f"JAX sparse solve failed: {e}. "
                f"Try using 'numpy' or 'jax' solver instead."
            ) from e

        # Convert back to NumPy
        phi = np.array(phi_jax)

        return phi

    def compute_condition_number(
        self, LSM: Union[np.ndarray, sp.spmatrix]
    ) -> float:
        """
        Compute reciprocal condition number.

        Parameters
        ----------
        LSM : ndarray or sparse matrix
            System matrix

        Returns
        -------
        rcond : float
            Reciprocal condition number
        """
        # For sparse matrices, convert to dense for condition number
        return _compute_rcond_numpy(LSM)


def get_solver(solver_name: str) -> SolverBackend:
    """
    Get solver backend by name.

    Parameters
    ----------
    solver_name : str
        Solver name: 'numpy', 'pytorch', 'jax', or 'jax_sparse'

    Returns
    -------
    solver : SolverBackend
        Solver backend instance

    Raises
    ------
    ValueError
        If solver name is not recognized
    ImportError
        If solver requires packages that are not installed
    """
    solver_map = {
        "numpy": NumPySolver,
        "pytorch": PyTorchSolver,
        "jax": JAXSolver,
        "jax_sparse": JAXSparseSolver,
    }

    # Reuse solver instances to avoid re-JIT compilation (notably for JAX)
    global _SOLVER_CACHE

    if solver_name not in solver_map:
        raise ValueError(
            f"Unknown solver '{solver_name}'. "
            f"Available: {list(solver_map.keys())}"
        )

    if solver_name in _SOLVER_CACHE:
        return _SOLVER_CACHE[solver_name]

    try:
        solver = solver_map[solver_name]()
    except ImportError as e:
        if "jax" in solver_name.lower():
            raise ImportError(
                f"Solver '{solver_name}' requires JAX. "
                f"Install with: pip install jax jaxlib\n"
                f"Or use solver='numpy' instead."
            ) from e
        elif solver_name == "pytorch":
            raise ImportError(
                f"Solver '{solver_name}' requires PyTorch. "
                f"Install with: pip install torch\n"
                f"Or use solver='numpy' instead."
            ) from e
        else:
            raise

    _SOLVER_CACHE[solver_name] = solver
    return solver


def check_condition_and_warn(
    LSM: Union[np.ndarray, sp.spmatrix],
    solver: SolverBackend,
    rcond_limit: float = 1e-12,
) -> Tuple[float, bool]:
    """
    Check matrix condition number and warn if poorly conditioned.

    Parameters
    ----------
    LSM : ndarray or sparse matrix
        System matrix
    solver : SolverBackend
        Solver backend
    rcond_limit : float, default=1e-12
        Reciprocal condition number threshold

    Returns
    -------
    rcond : float
        Reciprocal condition number
    is_singular : bool
        True if matrix is close to singular

    Warnings
    --------
    UserWarning
        If matrix is poorly conditioned
    """
    rcond = solver.compute_condition_number(LSM)
    is_singular = rcond < rcond_limit

    if is_singular:
        warnings.warn(
            f"System matrix is poorly conditioned (rcond={rcond:.2e}). "
            f"Increase regularization (gamma, delta) for numerical stability.",
            UserWarning,
        )

    return rcond, is_singular


def solve_pmf_system(
    LSM: Union[np.ndarray, sp.spmatrix],
    RSV: np.ndarray,
    solver_name: str = "numpy",
    check_condition: bool = True,
    rcond_limit: float = 1e-12,
) -> Tuple[np.ndarray, Optional[float]]:
    """
    Solve PMF linear system with specified backend.

    This is the main interface for solving the PMF linear system:
        LSM @ φ = RSV

    Parameters
    ----------
    LSM : ndarray or sparse matrix
        Left-side matrix (system matrix)
    RSV : ndarray
        Right-side vector
    solver_name : str, default='numpy'
        Solver backend: 'numpy', 'jax', or 'jax_sparse'
    check_condition : bool, default=True
        Whether to check matrix condition number
    rcond_limit : float, default=1e-12
        Reciprocal condition number threshold for warnings

    Returns
    -------
    phi : ndarray
        Solution vector
    rcond : float or None
        Reciprocal condition number (if check_condition=True)

    Raises
    ------
    ValueError
        If solver name is invalid
    ImportError
        If solver requires unavailable packages
    RuntimeError
        If solve fails

    Examples
    --------
    >>> import numpy as np
    >>> from pmf_acls.solvers import solve_pmf_system
    >>>
    >>> # Simple system
    >>> LSM = np.array([[2.0, 1.0], [1.0, 2.0]])
    >>> RSV = np.array([1.0, 1.0])
    >>>
    >>> phi, rcond = solve_pmf_system(LSM, RSV)
    >>> print(phi)
    [0.33333333 0.33333333]
    """
    # Get solver backend
    solver = get_solver(solver_name)

    # Check condition number if requested
    rcond = None
    if check_condition:
        rcond, is_singular = check_condition_and_warn(LSM, solver, rcond_limit)

    # Solve system
    phi = solver.solve(LSM, RSV)

    return phi, rcond
