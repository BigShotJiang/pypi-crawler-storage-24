"""
Input validation functions for PMF algorithm.

This module provides validation utilities to ensure inputs to PMF
functions are well-formed and satisfy necessary constraints.
"""

from typing import Optional, Union, Tuple
import numpy as np


def validate_data_matrix(X: np.ndarray, name: str = "X") -> None:
    """
    Validate data matrix.

    Parameters
    ----------
    X : ndarray
        Matrix to validate
    name : str, default="X"
        Name of matrix for error messages

    Raises
    ------
    ValueError
        If X is not a 2D numpy array or contains invalid values
    """
    if not isinstance(X, np.ndarray):
        raise ValueError(f"{name} must be a numpy array, got {type(X)}")

    if X.ndim != 2:
        raise ValueError(f"{name} must be 2-dimensional, got shape {X.shape}")

    if X.size == 0:
        raise ValueError(f"{name} must not be empty")

    if not np.all(np.isfinite(X)):
        n_nan = np.sum(np.isnan(X))
        n_inf = np.sum(np.isinf(X))
        raise ValueError(
            f"{name} contains non-finite values: "
            f"{n_nan} NaN(s), {n_inf} Inf(s). "
            f"Use prepare_data() to handle missing values."
        )


def validate_uncertainty_matrix(
    sigma: np.ndarray, X_shape: Tuple[int, int]
) -> None:
    """
    Validate uncertainty (standard deviation) matrix.

    Parameters
    ----------
    sigma : ndarray
        Uncertainty matrix
    X_shape : tuple of int
        Expected shape (m, n)

    Raises
    ------
    ValueError
        If sigma is invalid
    """
    validate_data_matrix(sigma, name="sigma")

    if sigma.shape != X_shape:
        raise ValueError(
            f"sigma shape {sigma.shape} does not match X shape {X_shape}"
        )

    if not np.all(sigma > 0):
        n_nonpos = np.sum(sigma <= 0)
        raise ValueError(
            f"sigma must contain only positive values, "
            f"found {n_nonpos} non-positive value(s)"
        )


def validate_rank(p: int, m: int, n: int) -> None:
    """
    Validate factorization rank.

    Parameters
    ----------
    p : int
        Number of factors
    m : int
        Number of variables (rows of X)
    n : int
        Number of observations (columns of X)

    Raises
    ------
    ValueError
        If p is not valid
    """
    if not isinstance(p, (int, np.integer)):
        raise ValueError(f"p must be an integer, got {type(p)}")

    if p < 1:
        raise ValueError(f"p must be at least 1, got {p}")

    if p > min(m, n):
        raise ValueError(
            f"p={p} exceeds min(m, n)={min(m, n)}. "
            f"Maximum rank is min(m, n)."
        )

    # Warning for identifiability
    if p > min(m, n) // 2:
        import warnings

        warnings.warn(
            f"Large p={p} relative to data dimensions ({m}×{n}). "
            f"Model may be poorly identified. Consider using fewer factors.",
            UserWarning,
        )


def validate_initial_matrix(
    M: Optional[np.ndarray],
    expected_shape: Tuple[int, int],
    name: str,
    allow_none: bool = True,
) -> None:
    """
    Validate initial factor matrix (F or G).

    Parameters
    ----------
    M : ndarray or None
        Initial matrix
    expected_shape : tuple of int
        Expected shape
    name : str
        Matrix name for error messages
    allow_none : bool, default=True
        Whether None is acceptable

    Raises
    ------
    ValueError
        If M is invalid
    """
    if M is None:
        if not allow_none:
            raise ValueError(f"{name} cannot be None")
        return

    validate_data_matrix(M, name=name)

    if M.shape != expected_shape:
        raise ValueError(
            f"{name} shape {M.shape} does not match "
            f"expected shape {expected_shape}"
        )

    if not np.all(M >= 0):
        n_neg = np.sum(M < 0)
        raise ValueError(
            f"{name} must be non-negative, found {n_neg} negative value(s)"
        )


def validate_mode(mode: str) -> None:
    """
    Validate algorithm mode.

    Parameters
    ----------
    mode : str
        Algorithm mode

    Raises
    ------
    ValueError
        If mode is not recognized
    """
    valid_modes = {"basic", "regularized", "full"}
    if mode not in valid_modes:
        raise ValueError(
            f"mode must be one of {valid_modes}, got '{mode}'"
        )


def validate_solver(solver: str) -> None:
    """
    Validate and check solver backend availability.

    Parameters
    ----------
    solver : str
        Solver name

    Raises
    ------
    ValueError
        If solver is not recognized or not available
    """
    valid_solvers = {"numpy", "pytorch", "jax", "jax_sparse"}
    if solver not in valid_solvers:
        raise ValueError(
            f"solver must be one of {valid_solvers}, got '{solver}'"
        )

    # Check PyTorch availability
    if solver == "pytorch":
        try:
            import torch  # noqa: F401
        except ImportError:
            raise ValueError(
                f"solver='{solver}' requires PyTorch, but PyTorch is not installed. "
                f"Install with: pip install torch"
            )

    # Check JAX availability
    if solver in {"jax", "jax_sparse"}:
        try:
            import jax  # noqa: F401
        except ImportError:
            raise ValueError(
                f"solver='{solver}' requires JAX, but JAX is not installed. "
                f"Install with: pip install jax jaxlib"
            )


def validate_positive_scalar(
    value: Union[int, float],
    name: str,
    allow_zero: bool = False,
) -> None:
    """
    Validate that a scalar is positive.

    Parameters
    ----------
    value : int or float
        Value to validate
    name : str
        Parameter name for error messages
    allow_zero : bool, default=False
        Whether zero is acceptable

    Raises
    ------
    ValueError
        If value is not positive
    """
    if not isinstance(value, (int, float, np.integer, np.floating)):
        raise ValueError(f"{name} must be a number, got {type(value)}")

    if np.isnan(value) or np.isinf(value):
        raise ValueError(f"{name} must be finite, got {value}")

    threshold = 0 if allow_zero else 0
    comparison = ">=" if allow_zero else ">"

    if allow_zero and value < 0:
        raise ValueError(f"{name} must be {comparison} 0, got {value}")
    elif not allow_zero and value <= 0:
        raise ValueError(f"{name} must be {comparison} 0, got {value}")


def validate_integer_range(
    value: int, name: str, min_val: Optional[int] = None, max_val: Optional[int] = None
) -> None:
    """
    Validate that an integer is within a range.

    Parameters
    ----------
    value : int
        Value to validate
    name : str
        Parameter name
    min_val : int, optional
        Minimum allowed value (inclusive)
    max_val : int, optional
        Maximum allowed value (inclusive)

    Raises
    ------
    ValueError
        If value is out of range
    """
    if not isinstance(value, (int, np.integer)):
        raise ValueError(f"{name} must be an integer, got {type(value)}")

    if min_val is not None and value < min_val:
        raise ValueError(f"{name} must be >= {min_val}, got {value}")

    if max_val is not None and value > max_val:
        raise ValueError(f"{name} must be <= {max_val}, got {value}")


def validate_strength_coefficient(
    value: Union[str, float],
    name: str,
) -> float:
    """
    Validate and process strength coefficient.

    Parameters
    ----------
    value : str or float
        Coefficient value or 'auto'
    name : str
        Parameter name

    Returns
    -------
    float or str
        Validated coefficient (returns 'auto' if input is 'auto')

    Raises
    ------
    ValueError
        If value is invalid
    """
    if isinstance(value, str):
        if value.lower() != "auto":
            raise ValueError(
                f"{name} must be 'auto' or a non-negative number, got '{value}'"
            )
        return "auto"

    validate_positive_scalar(value, name, allow_zero=True)
    return float(value)


def validate_boolean(value, name: str) -> None:
    """
    Validate boolean parameter.

    Parameters
    ----------
    value : any
        Value to validate
    name : str
        Parameter name

    Raises
    ------
    ValueError
        If value is not boolean
    """
    if not isinstance(value, (bool, np.bool_)):
        raise ValueError(f"{name} must be boolean, got {type(value)}")


def check_data_quality(X: np.ndarray, sigma: np.ndarray) -> None:
    """
    Check data quality and issue warnings if needed.

    Parameters
    ----------
    X : ndarray, shape (m, n)
        Data matrix
    sigma : ndarray, shape (m, n)
        Uncertainty matrix

    Warnings
    --------
    UserWarning
        If data quality issues are detected
    """
    import warnings

    # Check for very small or very large values
    if np.any(X < 0):
        n_neg = np.sum(X < 0)
        warnings.warn(
            f"X contains {n_neg} negative value(s). "
            f"PMF assumes non-negative data. Consider data preprocessing.",
            UserWarning,
        )

    # Check signal-to-noise ratio
    snr = X / sigma
    low_snr_frac = np.sum(snr < 3) / snr.size

    if low_snr_frac > 0.3:
        warnings.warn(
            f"{low_snr_frac:.1%} of data points have SNR < 3. "
            f"Results may be unreliable for low-SNR data.",
            UserWarning,
        )

    # Check for constant variables or observations
    const_vars = np.sum(np.std(X, axis=1) == 0)
    if const_vars > 0:
        warnings.warn(
            f"{const_vars} variable(s) have zero variance. "
            f"Consider removing constant variables.",
            UserWarning,
        )

    const_obs = np.sum(np.std(X, axis=0) == 0)
    if const_obs > 0:
        warnings.warn(
            f"{const_obs} observation(s) have zero variance. "
            f"Consider removing constant observations.",
            UserWarning,
        )

    # Check dynamic range
    X_pos = X[X > 0]
    if X_pos.size > 0:
        dynamic_range = np.max(X_pos) / np.min(X_pos)
        if dynamic_range > 1e6:
            warnings.warn(
                f"Data has large dynamic range ({dynamic_range:.2e}). "
                f"Consider scaling or log-transformation.",
                UserWarning,
            )


def validate_sigma_categories(
    categories: np.ndarray,
    expected_shape: Tuple[int, ...],
    name: str = "sigma_categories",
) -> None:
    """
    Validate sigma category labels for hierarchical uncertainty modeling.

    Parameters
    ----------
    categories : ndarray
        Integer array of category labels.
    expected_shape : tuple of int
        Expected shape — (m,) for per_variable, (m, n) for per_element.
    name : str, default="sigma_categories"
        Name for error messages.

    Raises
    ------
    ValueError
        If categories has wrong shape, dtype, or contains negative values.
    """
    if not isinstance(categories, np.ndarray):
        raise ValueError(f"{name} must be a numpy array, got {type(categories)}")

    if categories.shape != expected_shape:
        raise ValueError(
            f"{name} shape {categories.shape} does not match "
            f"expected shape {expected_shape}"
        )

    if not np.issubdtype(categories.dtype, np.integer):
        raise ValueError(
            f"{name} must have integer dtype, got {categories.dtype}"
        )

    if np.any(categories < 0):
        raise ValueError(f"{name} must contain non-negative values")
