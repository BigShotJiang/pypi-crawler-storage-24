"""
Bayesian NMF via Gibbs sampling.

Implements the Schmidt et al. (2009) model with heteroscedastic Gaussian
noise and exponential priors on factor elements. Full conditionals are
truncated Gaussians, sampled exactly via scipy.stats.truncnorm.
Hyperparameter rates (lambda_F, lambda_G) can be learned via conjugate
Gamma hyperpriors (Cemgil 2009).

Generative model
----------------
    X_ij ~ N((GF)_ij, sigma_ij^2)   [heteroscedastic Gaussian, sigma known]
    F_ik ~ Exp(lambda_F)              [non-negative exponential prior]
    G_kj ~ Exp(lambda_G)              [non-negative exponential prior]
    lambda_F ~ Gamma(a, b)            [optional conjugate hyperprior]
    lambda_G ~ Gamma(a, b)            [optional conjugate hyperprior]

Convention: F is (m, p), G is (p, n) — matches the rest of pmf_acls.

Hierarchical sigma (optional)
-----------------------------
Standard PMF (and EPA PMF/ME-2) treats sigma as fixed and known.  In
practice, uncertainty estimates are themselves uncertain — especially for
"wild guess" or "analogous study" entries.

When ``sigma_prior`` is set, this module places a conjugate Inverse-Gamma
prior on sigma^2 and samples it alongside F and G:

    sigma2_ij ~ InvGamma(alpha_c, beta_c)   where c = category(i) or (i,j)

Full conditional (per-variable pooling, recommended):

    sigma2_i | rest ~ InvGamma(alpha_c + n/2,
                                beta_c + 0.5 * sum_j (X_ij - (GF)_ij)^2)

Categories allow grouping variables by data quality tier (measured, MDL,
analogous, wild guess) with different prior tightness on each group.
High alpha anchors sigma near the initial estimate; low alpha lets the
data dominate.

References
----------
Schmidt, M. N., Winther, O., & Hansen, L. K. (2009).
    Bayesian non-negative matrix factorization.
    Proc. 8th Int. Conf. on Independent Component Analysis, pp. 540-547.

Cemgil, A. T. (2009).
    Bayesian inference for nonnegative matrix factorisation models.
    Computational Intelligence and Neuroscience, 2009.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Optional

import numpy as np
from scipy.stats import truncnorm

from .data_structures import PMFResult
from .validation import validate_data_matrix, validate_uncertainty_matrix, validate_rank


SIGMA_CATEGORY_PRESETS = {
    "measured": (10.0, None),
    "mdl": (5.0, None),
    "analogous": (2.0, None),
    "guess": (1.0, None),
}


@dataclass
class _SigmaPriorConfig:
    """Parsed/validated sigma prior settings."""
    mode: str                     # "per_variable" or "per_element"
    categories: np.ndarray        # (m,) or (m, n) integer labels
    n_categories: int
    alpha: np.ndarray             # (n_cat,) InvGamma shape
    beta_init: np.ndarray         # (n_cat,) InvGamma rate


def _validate_sigma_prior(sigma_prior, sigma_categories, sigma_prior_params, m, n, sigma):
    """Validate and resolve hierarchical sigma prior configuration.

    Returns None if sigma_prior is None, otherwise a _SigmaPriorConfig.
    """
    if sigma_prior is None:
        return None

    if sigma_prior not in ("per_variable", "per_element"):
        raise ValueError(
            f"sigma_prior must be 'per_variable' or 'per_element', got {sigma_prior!r}"
        )

    # --- Categories ---
    if sigma_categories is None:
        if sigma_prior == "per_variable":
            sigma_categories = np.zeros(m, dtype=int)
        else:
            sigma_categories = np.zeros((m, n), dtype=int)
    else:
        sigma_categories = np.asarray(sigma_categories, dtype=int)

    expected_shape = (m,) if sigma_prior == "per_variable" else (m, n)
    if sigma_categories.shape != expected_shape:
        raise ValueError(
            f"sigma_categories shape {sigma_categories.shape} does not match "
            f"expected {expected_shape} for sigma_prior='{sigma_prior}'"
        )

    if np.any(sigma_categories < 0):
        raise ValueError("sigma_categories must contain non-negative integers")

    unique_cats = np.unique(sigma_categories)
    n_categories = len(unique_cats)

    # Remap categories to contiguous 0..n_categories-1 so alpha/beta
    # arrays can be indexed directly by the category value.
    cat_remap = {int(old): new for new, old in enumerate(unique_cats)}
    if sigma_prior == "per_variable":
        sigma_categories = np.array([cat_remap[int(c)] for c in sigma_categories], dtype=int)
    else:
        sigma_categories = np.vectorize(lambda c: cat_remap[int(c)])(sigma_categories).astype(int)

    # --- Resolve hyperparameters ---
    alpha = np.empty(n_categories)
    beta_init = np.empty(n_categories)
    beta_needs_init = np.ones(n_categories, dtype=bool)

    if sigma_prior_params is None:
        # Default all categories to "analogous" preset
        default_alpha, _ = SIGMA_CATEGORY_PRESETS["analogous"]
        alpha[:] = default_alpha
    else:
        for old_cat_id in unique_cats:
            idx = cat_remap[int(old_cat_id)]
            if old_cat_id in sigma_prior_params:
                val = sigma_prior_params[old_cat_id]
            elif int(old_cat_id) in sigma_prior_params:
                val = sigma_prior_params[int(old_cat_id)]
            else:
                raise ValueError(
                    f"sigma_prior_params missing category {old_cat_id}. "
                    f"Required categories: {list(unique_cats)}"
                )
            if isinstance(val, str):
                if val not in SIGMA_CATEGORY_PRESETS:
                    raise ValueError(
                        f"Unknown preset '{val}'. Valid presets: "
                        f"{list(SIGMA_CATEGORY_PRESETS.keys())}"
                    )
                a, b = SIGMA_CATEGORY_PRESETS[val]
            else:
                a, b = val
            alpha[idx] = a
            if b is not None:
                beta_init[idx] = b
                beta_needs_init[idx] = False

    # --- Auto-initialize beta where needed ---
    # Note: sigma_categories is already remapped to contiguous indices
    sigma2_full = sigma ** 2
    for idx in range(n_categories):
        if beta_needs_init[idx]:
            mask = sigma_categories == idx
            if sigma_prior == "per_variable":
                mean_s2 = np.mean(sigma2_full[mask, :]) if mask.any() else 1.0
            else:
                mean_s2 = np.mean(sigma2_full[mask]) if mask.any() else 1.0
            beta_init[idx] = alpha[idx] * mean_s2

    return _SigmaPriorConfig(
        mode=sigma_prior,
        categories=sigma_categories,
        n_categories=n_categories,
        alpha=alpha,
        beta_init=beta_init,
    )


def _sample_sigma2_per_variable(R_squared_sum, sigma2, categories, alpha, beta, n_obs, rng):
    """
    Sample per-variable sigma2 from InvGamma full conditional.

    For variable i with category c:
        sigma2_i | rest ~ InvGamma(alpha_c + n/2, beta_c + 0.5 * sum_j R[i,j]^2)

    Parameters
    ----------
    R_squared_sum : (m,) sum of squared residuals per variable (sum_j R[i,j]^2)
    sigma2 : (m, n) current variance matrix — updated in place
    categories : (m,) integer category labels
    alpha : (n_cat,) InvGamma shape per category
    beta : (n_cat,) InvGamma rate per category
    n_obs : int, number of observations
    rng : numpy Generator

    Returns
    -------
    sigma2 : (m, n) updated variance matrix (rows set to new per-variable values)
    """
    m = len(R_squared_sum)
    for i in range(m):
        c = categories[i]
        alpha_post = alpha[c] + 0.5 * n_obs
        beta_post = beta[c] + 0.5 * R_squared_sum[i]
        # InvGamma sample: 1 / Gamma(alpha_post, 1/beta_post)
        sigma2_i = 1.0 / rng.gamma(shape=alpha_post, scale=1.0 / beta_post)
        sigma2[i, :] = sigma2_i
    return sigma2


def _sample_sigma2_per_element(R_squared, sigma2, categories, alpha, beta, rng):
    """
    Sample per-element sigma2 from InvGamma full conditional.

    For element (i,j) with category c:
        sigma2_ij | rest ~ InvGamma(alpha_c + 0.5, beta_c + 0.5 * R[i,j]^2)

    Parameters
    ----------
    R_squared : (m, n) squared residuals
    sigma2 : (m, n) current variance matrix — updated in place
    categories : (m, n) integer category labels
    alpha : (n_cat,) InvGamma shape per category
    beta : (n_cat,) InvGamma rate per category
    rng : numpy Generator

    Returns
    -------
    sigma2 : (m, n) updated variance matrix
    """
    alpha_full = alpha[categories] + 0.5
    beta_full = beta[categories] + 0.5 * R_squared
    sigma2[:] = 1.0 / rng.gamma(shape=alpha_full, scale=1.0 / beta_full)
    return sigma2


def _sample_eta(R_squared, sigma2, v, rng):
    """Sample per-element precision weights for robust Student's t likelihood.

    eta_ij ~ Gamma((v + 1) / 2, (v + R_ij^2 / sigma2_ij) / 2)
    """
    alpha_eta = (v + 1.0) / 2.0
    beta_eta = (v + R_squared / sigma2) / 2.0
    eta = rng.gamma(shape=alpha_eta, scale=1.0 / beta_eta)
    return np.maximum(eta, 1e-10)  # floor to prevent div-by-zero


@dataclass
class BayesNMFResult:
    """
    Container for Bayesian NMF results from Gibbs sampling.

    Attributes
    ----------
    F : ndarray, shape (m, p)
        Point estimate of factor profiles. When warm_start=True, this is the
        ACLS solution (sharp, well-separated profiles). Otherwise, this is
        the posterior mean.
    G : ndarray, shape (p, n)
        Point estimate of factor contributions. Same convention as F.
    F_posterior_mean : ndarray, shape (m, p)
        Posterior mean of F from Gibbs samples. May show higher inter-factor
        similarity than the point estimate due to label switching.
    G_posterior_mean : ndarray, shape (p, n)
        Posterior mean of G from Gibbs samples.
    F_std : ndarray, shape (m, p)
        Posterior standard deviation of F.
    G_std : ndarray, shape (p, n)
        Posterior standard deviation of G.
    F_samples : ndarray or None, shape (n_samples, m, p)
        Full posterior samples of F if store_samples=True, else None.
    G_samples : ndarray or None, shape (n_samples, p, n)
        Full posterior samples of G if store_samples=True, else None.
    Q_samples : ndarray, shape (n_samples,)
        Q values at each posterior sample (after thinning). Use for
        convergence diagnostics and trace plots.
    Q : float
        Q value evaluated at the posterior mean F and G.
    n_iter : int
        Total Gibbs sweeps performed (burnin + sampling × thin).
    converged : bool
        True if all three conditions hold: Geweke |z| < 2.0,
        min per-factor ESS >= 100, and label_switch_gap >= 0.1.
    lambda_F : float
        Posterior mean of the exponential rate for F elements.
    lambda_G : float
        Posterior mean of the exponential rate for G elements.
    residuals : ndarray, shape (m, n)
        X - F @ G evaluated at the posterior mean.
    explained_variance : float
        R² at the posterior mean.
    chi2 : float
        Q / degrees_of_freedom at the posterior mean.
    """

    F: np.ndarray
    G: np.ndarray
    F_posterior_mean: np.ndarray
    G_posterior_mean: np.ndarray
    F_std: np.ndarray
    G_std: np.ndarray
    F_samples: Optional[np.ndarray]
    G_samples: Optional[np.ndarray]
    Q_samples: np.ndarray
    Q: float
    n_iter: int
    converged: bool
    lambda_F: float
    lambda_G: float
    residuals: np.ndarray
    explained_variance: float
    chi2: float
    # ARD (automatic relevance determination) — populated when ard=True
    ard_lambda_F: Optional[np.ndarray] = None
    ard_lambda_G: Optional[np.ndarray] = None
    active_factors: Optional[np.ndarray] = None
    effective_p: Optional[int] = None
    # Likelihood model
    likelihood: str = "gaussian"
    mh_acceptance_rate: Optional[float] = None
    # Hierarchical sigma — populated when sigma_prior is set
    sigma_posterior_mean: Optional[np.ndarray] = None
    sigma_posterior_std: Optional[np.ndarray] = None
    sigma_samples: Optional[np.ndarray] = None
    sigma_prior_mode: Optional[str] = None
    # Robust Student's t — populated when robust=True
    eta_posterior_mean: Optional[np.ndarray] = None
    eta_posterior_std: Optional[np.ndarray] = None
    robust_df: Optional[float] = None
    outlier_mask: Optional[np.ndarray] = None
    eta_samples: Optional[np.ndarray] = None
    # Volume prior — populated when volume_alpha > 0
    volume_alpha: float = 0.0
    prior_F_shape: float = 1.0
    prior_G_shape: float = 1.0
    mh_volume_acceptance_rate: Optional[float] = None
    # Per-sample factor activity — populated when ard=True
    # Shape (n_samples, p): fractional contribution of each factor at each sample
    factor_activity_samples: Optional[np.ndarray] = None
    # Label-switching diagnostic: minimum Hungarian assignment gap during sampling.
    # Values near 0 indicate two factors are nearly interchangeable.
    label_switch_gap: Optional[float] = None
    # Rich convergence diagnostics: geweke_z, Q_ess, factor_ess, min_factor_ess
    convergence_details: Optional[dict] = None

    def __repr__(self) -> str:
        m, p = self.F.shape
        _, n = self.G.shape
        conv_str = "Yes" if self.converged else "No"
        _cd = self.convergence_details
        _conv_detail = ""
        if _cd is not None and not self.converged:
            _fails = []
            if not _cd.get("geweke_ok", True):
                _fails.append(f"Geweke |z|={_cd['geweke_z_abs']:.2f}")
            if not _cd.get("ess_ok", True):
                _fails.append(f"min_ESS={_cd['min_factor_ess']:.0f}")
            if not _cd.get("labels_ok", True):
                _fails.append(f"label_gap={self.label_switch_gap:.3f}")
            if _fails:
                _conv_detail = f" ({', '.join(_fails)})"
        return (
            f"BayesNMFResult(\n"
            f"  Shape: {m} variables × {n} observations × {p} factors\n"
            f"  Converged: {conv_str}{_conv_detail}\n"
            f"  Samples collected: {len(self.Q_samples)}\n"
            f"  Q (point estimate): {self.Q:.4e}\n"
            f"  Explained variance: {self.explained_variance:.2%}\n"
            f"  chi2: {self.chi2:.4f}\n"
            f"  lambda_F: {self.lambda_F:.4f}  lambda_G: {self.lambda_G:.4f}\n"
            + (
                f"  ARD: {self.effective_p}/{p} active factors\n"
                if self.effective_p is not None
                else ""
            )
            + (
                f"  Likelihood: {self.likelihood}"
                + (f"  MH accept: {self.mh_acceptance_rate:.1%}" if self.mh_acceptance_rate is not None else "")
                + "\n"
                if self.likelihood != "gaussian"
                else ""
            )
            + (
                f"  Hierarchical sigma: {self.sigma_prior_mode}\n"
                if self.sigma_prior_mode is not None
                else ""
            )
            + (
                f"  Robust Student's t: df={self.robust_df}"
                + (f"  outliers={int(self.outlier_mask.sum())}/{self.outlier_mask.size}" if self.outlier_mask is not None else "")
                + "\n"
                if self.robust_df is not None
                else ""
            )
            + f")"
        )

    def to_pmf_result(self) -> PMFResult:
        """
        Wrap as PMFResult for compatibility with diagnostics and uncertainty tools.

        Posterior standard deviations are placed in F_std/G_std.
        Q_samples is used as Q_history.
        """
        return PMFResult(
            F=self.F.copy(),
            G=self.G.copy(),
            Q=self.Q,
            Q_history=list(self.Q_samples),
            n_iter=self.n_iter,
            converged=self.converged,
            residuals=self.residuals.copy(),
            explained_variance=self.explained_variance,
            chi2=self.chi2,
            F_std=self.F_std.copy(),
            G_std=self.G_std.copy(),
        )


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _compute_Q(F: np.ndarray, G: np.ndarray, X: np.ndarray, sigma: np.ndarray) -> float:
    """Weighted sum-of-squares objective Q = sum((X - GF)^2 / sigma^2)."""
    return float(np.sum(((X - F @ G) / sigma) ** 2))


def _geweke_z(trace: np.ndarray) -> float:
    """
    Geweke (1992) z-score comparing first 10% to last 50% of trace.

    Returns 0.0 if variance is negligible (trace is essentially constant).
    Values |z| < 2 suggest convergence.
    """
    n = len(trace)
    n_first = max(int(0.1 * n), 2)
    n_last = max(int(0.5 * n), 2)
    first = trace[:n_first]
    last = trace[n - n_last:]
    mean_diff = float(np.mean(first) - np.mean(last))
    var_sum = float(
        np.var(first, ddof=1) / len(first) + np.var(last, ddof=1) / len(last)
    )
    if var_sum < 1e-30:
        return 0.0
    return mean_diff / np.sqrt(var_sum)


def _normalize_factors(F: np.ndarray, G: np.ndarray) -> tuple:
    """
    Normalize F columns to unit L1 norm, absorbing scale into G rows.
    Then sort factors by decreasing G row L1 mass.

    This is applied to the final posterior mean for consistent reporting.
    The GF product is preserved exactly.

    Returns (F, G, scales, order) where scales are the pre-normalization
    F column L1 norms and order is the sort permutation applied.
    """
    p = F.shape[1]
    scales = np.ones(p)
    for k in range(p):
        scales[k] = F[:, k].sum()
        if scales[k] > 1e-30:
            F[:, k] /= scales[k]
            G[k, :] *= scales[k]
    # Sort factors by decreasing G row mass
    order = np.argsort(-G.sum(axis=1))
    return F[:, order], G[order, :], scales[order], order


def _sort_factors(
    F: np.ndarray, G: np.ndarray,
    G_ref: Optional[np.ndarray] = None,
) -> tuple:
    """
    Permute factors to best match a reference configuration WITHOUT
    rescaling.  This prevents label switching across Gibbs sweeps.

    When a reference is provided, factors are matched via the Hungarian
    algorithm on cosine similarity of G rows.  Otherwise, factors are
    sorted by decreasing energy (F column sum * G row sum).

    Modifies F and G **in place** and returns (order, match_gap).

    match_gap is the minimum per-factor difference between assigned and
    second-best cosine similarity.  Values near 0 indicate two factors
    are nearly interchangeable (label-switching risk).  Returns 1.0
    when no reference is used (energy-based sorting).
    """
    from scipy.optimize import linear_sum_assignment

    p = F.shape[1]

    if G_ref is not None:
        G_norms = np.linalg.norm(G, axis=1, keepdims=True)
        ref_norms = np.linalg.norm(G_ref, axis=1, keepdims=True)
        sim = (G @ G_ref.T) / np.maximum(G_norms * ref_norms.T, 1e-30)
        cost = 1.0 - sim
        row_ind, order = linear_sum_assignment(cost)
        # Compute per-factor gap: assigned cost vs second-best cost
        match_gap = 1.0
        for i, j in zip(row_ind, order):
            assigned_cost = cost[i, j]
            other_costs = np.delete(cost[i, :], j)
            if len(other_costs) > 0:
                gap = float(np.min(other_costs) - assigned_cost)
                match_gap = min(match_gap, gap)
    else:
        energy = np.array([F[:, k].sum() * G[k, :].sum() for k in range(p)])
        order = np.argsort(-energy)
        match_gap = 1.0  # no reference → no ambiguity measure

    if np.all(order == np.arange(p)):
        return order, match_gap
    F[:] = F[:, order]
    G[:] = G[order, :]
    return order, match_gap


def _volume_log_det(F: np.ndarray) -> float:
    """
    Compute log det(F^T F) for the volume prior.

    The volume prior p(F) ∝ det(F^T F)^(α/2) penalizes collinear F columns,
    encouraging geometrically separated factor profiles.  See Fu & Huang
    (2018) for identifiability guarantees under the sufficiently scattered
    condition.

    Returns -inf when F columns are linearly dependent (degenerate).
    """
    sign, logdet = np.linalg.slogdet(F.T @ F)
    return logdet if sign > 0 else -np.inf


def _make_sampler(sampler: str) -> Callable:
    """
    Return a callable ``sample_fn(mu, tau, rng) -> ndarray`` that draws
    element-wise samples from TruncNormal[0, ∞)(mu, tau).

    Parameters
    ----------
    sampler : {'icdf', 'scipy'}
        'icdf'  — Inverse-CDF method: maps numpy uniform draws through
                  scipy.special.ndtr/ndtri.  Avoids scipy.stats dispatch
                  overhead; typically 3–5× faster per sweep.
        'scipy' — Uses scipy.stats.truncnorm.rvs; original behaviour.

    Raises
    ------
    ValueError
        If sampler is not 'icdf' or 'scipy'.
    """
    if sampler == "icdf":
        from scipy.special import ndtr, ndtri

        def _sample(
            mu: np.ndarray, tau: np.ndarray, rng: np.random.Generator
        ) -> np.ndarray:
            a = -mu / tau                           # standardized lower bound for x >= 0
            p_low = ndtr(a)                         # Φ(a): probability mass below 0
            u = rng.uniform(size=mu.shape)
            # Map u ~ U(0,1) → p ~ U(Φ(a), 1), then apply Φ⁻¹
            p = np.clip(p_low + u * (1.0 - p_low), 1e-300, 1.0 - 2.2e-16)
            return np.maximum(mu + tau * ndtri(p), 0.0)

        return _sample

    elif sampler == "scipy":

        def _sample(
            mu: np.ndarray, tau: np.ndarray, rng: np.random.Generator
        ) -> np.ndarray:
            a = -mu / tau
            return np.maximum(
                truncnorm.rvs(a=a, b=np.inf, loc=mu, scale=tau, random_state=rng),
                0.0,
            )

        return _sample

    else:
        raise ValueError(f"sampler must be 'icdf' or 'scipy', got {sampler!r}")


def _sample_F_column(
    F_col: np.ndarray,
    G_row: np.ndarray,
    R: np.ndarray,
    sigma2: np.ndarray,
    lambda_F: float,
    rng: np.random.Generator,
    sample_fn: Callable,
) -> np.ndarray:
    """
    Sample one column of F from its truncated-Gaussian full conditional.

    Given the partial residual R_k = R + outer(F_col, G_row) (shape m×n),
    the full conditional for F[:,k] is:

        F[:,k] | rest ~ TruncNormal(mu_k, tau2_k)[0, inf)

    where:
        tau2_k[i] = 1 / sum_j (G_row[j]^2 / sigma2[i,j])
        mu_k[i]   = tau2_k[i] * (sum_j R_k[i,j]*G_row[j]/sigma2[i,j] - lambda_F)

    Parameters
    ----------
    F_col : (m,) current F[:,k]
    G_row : (n,) current G[k,:]
    R : (m, n) current residual X - F @ G
    sigma2 : (m, n) squared uncertainties
    lambda_F : float, exponential rate prior on F elements
    rng : numpy random Generator
    sample_fn : callable(mu, tau, rng) -> ndarray
        Truncated normal sampler; see _make_sampler.

    Returns
    -------
    (m,) new sample for F[:,k]
    """
    R_k = R + np.outer(F_col, G_row)  # partial residual (m, n)

    precision = (G_row ** 2 / sigma2).sum(axis=1)          # (m,)
    precision = np.maximum(precision, 1e-30)
    tau2 = 1.0 / precision                                   # (m,)

    mu = tau2 * ((R_k * G_row / sigma2).sum(axis=1) - lambda_F)  # (m,)

    return sample_fn(mu, np.sqrt(tau2), rng)


def _sample_G_row(
    F_col: np.ndarray,
    G_row: np.ndarray,
    R: np.ndarray,
    sigma2: np.ndarray,
    lambda_G: float,
    rng: np.random.Generator,
    sample_fn: Callable,
) -> np.ndarray:
    """
    Sample one row of G from its truncated-Gaussian full conditional.

    Given the partial residual R_k = R + outer(F_col, G_row) (shape m×n),
    the full conditional for G[k,:] is:

        G[k,:] | rest ~ TruncNormal(mu_k, tau2_k)[0, inf)

    where:
        tau2_k[j] = 1 / sum_i (F_col[i]^2 / sigma2[i,j])
        mu_k[j]   = tau2_k[j] * (sum_i R_k[i,j]*F_col[i]/sigma2[i,j] - lambda_G)

    Parameters
    ----------
    F_col : (m,) current F[:,k]
    G_row : (n,) current G[k,:]
    R : (m, n) current residual X - F @ G
    sigma2 : (m, n) squared uncertainties
    lambda_G : float, exponential rate prior on G elements
    rng : numpy random Generator
    sample_fn : callable(mu, tau, rng) -> ndarray
        Truncated normal sampler; see _make_sampler.

    Returns
    -------
    (n,) new sample for G[k,:]
    """
    R_k = R + np.outer(F_col, G_row)  # partial residual (m, n)

    G_col2 = F_col[:, np.newaxis] ** 2  # (m, 1)
    precision = (G_col2 / sigma2).sum(axis=0)               # (n,)
    precision = np.maximum(precision, 1e-30)
    tau2 = 1.0 / precision                                   # (n,)

    mu = tau2 * ((R_k * F_col[:, np.newaxis] / sigma2).sum(axis=0) - lambda_G)  # (n,)

    return sample_fn(mu, np.sqrt(tau2), rng)


def _gibbs_sweep(
    F: np.ndarray,
    G: np.ndarray,
    R: np.ndarray,
    sigma2: np.ndarray,
    lambda_F: float,
    lambda_G: float,
    rng: np.random.Generator,
    sample_fn: Callable,
    volume_alpha: float = 0.0,
    prior_F_shape: float = 1.0,
    prior_G_shape: float = 1.0,
) -> tuple:
    """
    One full Gibbs sweep with interleaved factor updates.

    For each factor k, update F[:,k] then immediately G[k,:] before
    moving to the next factor.  This interleaved order couples each
    factor's profile and contribution updates, reducing the tendency
    for weak factors to drift toward dominant ones (factor collapse).

    The residual R = X - F @ G is maintained incrementally.

    When ``volume_alpha > 0`` or ``prior_F_shape != 1.0``, the Gibbs
    draw is wrapped in a Metropolis-Hastings accept/reject step whose
    ratio accounts for the non-conjugate volume prior and/or sparse
    Gamma(a, ·) prior on F elements.  Same for ``prior_G_shape != 1.0``
    on G rows (volume prior applies to F only).

    Returns (F, G, R, n_vol_accepted, n_vol_proposed) where the last
    two are volume+prior MH acceptance counts (0 when inactive).
    """
    p = F.shape[1]
    # lambda_F / lambda_G may be scalars or per-factor arrays.
    _lF = np.broadcast_to(np.asarray(lambda_F, dtype=float), (p,))
    _lG = np.broadcast_to(np.asarray(lambda_G, dtype=float), (p,))

    _mh_F = volume_alpha > 0 or prior_F_shape != 1.0
    _mh_G = prior_G_shape != 1.0
    n_vol_accepted = 0
    n_vol_proposed = 0

    for k in range(p):
        # Update F column k
        F_k_new = _sample_F_column(F[:, k], G[k, :], R, sigma2, float(_lF[k]), rng, sample_fn)

        if _mh_F:
            # MH correction for non-conjugate priors (volume + sparse Gamma)
            n_vol_proposed += 1
            log_accept = 0.0

            if volume_alpha > 0:
                log_det_old = _volume_log_det(F)
                F_save = F[:, k].copy()
                F[:, k] = F_k_new
                log_det_new = _volume_log_det(F)
                F[:, k] = F_save  # restore for potential reject
                log_accept += 0.5 * volume_alpha * (log_det_new - log_det_old)

            if prior_F_shape != 1.0:
                log_accept += (prior_F_shape - 1.0) * (
                    np.sum(np.log(np.maximum(F_k_new, 1e-300)))
                    - np.sum(np.log(np.maximum(F[:, k], 1e-300)))
                )

            if log_accept >= 0 or np.log(rng.uniform()) < log_accept:
                n_vol_accepted += 1
            else:
                F_k_new = F[:, k].copy()  # reject: keep old column

        R += np.outer(F[:, k], G[k, :]) - np.outer(F_k_new, G[k, :])
        F[:, k] = F_k_new

        # Immediately update G row k with the fresh F column
        G_k_new = _sample_G_row(F[:, k], G[k, :], R, sigma2, float(_lG[k]), rng, sample_fn)

        if _mh_G:
            # MH correction for sparse Gamma prior on G (no volume prior)
            log_accept_g = (prior_G_shape - 1.0) * (
                np.sum(np.log(np.maximum(G_k_new, 1e-300)))
                - np.sum(np.log(np.maximum(G[k, :], 1e-300)))
            )
            if log_accept_g < 0 and np.log(rng.uniform()) >= log_accept_g:
                G_k_new = G[k, :].copy()  # reject

        R += np.outer(F[:, k], G[k, :]) - np.outer(F[:, k], G_k_new)
        G[k, :] = G_k_new

    return F, G, R, n_vol_accepted, n_vol_proposed


# ---------------------------------------------------------------------------
# Log-normal likelihood helpers
# ---------------------------------------------------------------------------


def _compute_Q_lognormal(
    F: np.ndarray, G: np.ndarray, logX: np.ndarray, tau2: np.ndarray,
) -> float:
    """Weighted sum-of-squares in log-space: Q_ln = sum((logX - log(GF))^2 / tau2)."""
    GF = np.maximum(F @ G, 1e-300)
    return float(np.sum((logX - np.log(GF)) ** 2 / tau2))


def _mh_steps_F_col_lognormal(
    F_col: np.ndarray,
    G_row: np.ndarray,
    GF: np.ndarray,
    logX: np.ndarray,
    tau2: np.ndarray,
    lambda_F: float,
    step_sigma: float,
    rng: np.random.Generator,
    _prior_F_shape: float = 1.0,
) -> tuple:
    """
    Element-wise MH updates for one column of F under log-normal likelihood.

    For each element i in F[:,k]:
    1. Propose F_new[i] = F_cur[i] + N(0, step_sigma^2)
    2. Reject if F_new[i] <= 0
    3. Accept/reject via log MH ratio (symmetric additive proposal)

    The log-likelihood for row i is:
        -0.5 * sum_j (logX[i,j] - log(GF[i,j]))^2 / tau2[i,j]

    Only row i of GF changes when F[i,k] changes, so the ratio is O(n).

    Parameters
    ----------
    F_col    : (m,) current F[:,k]
    G_row    : (n,) current G[k,:]
    GF       : (m, n) current F @ G product
    logX     : (m, n) precomputed log(X)
    tau2     : (m, n) log-space variance (sigma/X)^2
    lambda_F : float, exponential rate prior
    step_sigma : float, proposal standard deviation
    rng      : numpy random Generator

    Returns
    -------
    G_col_new : (m,) updated column
    GF_new    : (m, n) updated product
    n_accepted : int
    """
    m = F_col.shape[0]
    F_cur = F_col.copy()
    GF_cur = GF.copy()
    n_accepted = 0

    for i in range(m):
        f_new = F_cur[i] + rng.normal(0.0, step_sigma)
        if f_new <= 0.0:
            continue

        # Update row i of GF
        gf_row_new = GF_cur[i, :] + (f_new - F_cur[i]) * G_row

        # Log-likelihood ratio (row i only)
        log_gf_old = np.log(np.maximum(GF_cur[i, :], 1e-300))
        log_gf_new = np.log(np.maximum(gf_row_new, 1e-300))
        ll_old = -0.5 * np.sum((logX[i, :] - log_gf_old) ** 2 / tau2[i, :])
        ll_new = -0.5 * np.sum((logX[i, :] - log_gf_new) ** 2 / tau2[i, :])

        # Prior ratio: Exp(lambda_F) or Gamma(shape, lambda_F)
        log_prior = -lambda_F * (f_new - F_cur[i])
        if _prior_F_shape != 1.0:
            log_prior += (_prior_F_shape - 1.0) * (
                np.log(max(f_new, 1e-300)) - np.log(max(F_cur[i], 1e-300))
            )

        if np.log(rng.uniform()) < (ll_new - ll_old) + log_prior:
            F_cur[i] = f_new
            GF_cur[i, :] = gf_row_new
            n_accepted += 1

    return F_cur, GF_cur, n_accepted


def _mh_steps_G_row_lognormal(
    F_col: np.ndarray,
    G_row: np.ndarray,
    GF: np.ndarray,
    logX: np.ndarray,
    tau2: np.ndarray,
    lambda_G: float,
    step_sigma: float,
    rng: np.random.Generator,
    _prior_G_shape: float = 1.0,
) -> tuple:
    """
    Element-wise MH updates for one row of G under log-normal likelihood.

    Mirror of _mh_steps_F_col_lognormal: for each element j in G[k,:],
    propose G_new[j] = G_cur[j] + N(0, step_sigma^2), reject if <= 0,
    accept/reject by log MH ratio.  Only column j of GF changes.

    Parameters
    ----------
    F_col    : (m,) current F[:,k]
    G_row    : (n,) current G[k,:]
    GF       : (m, n) current F @ G product
    logX     : (m, n) precomputed log(X)
    tau2     : (m, n) log-space variance
    lambda_G : float, exponential rate prior
    step_sigma : float, proposal standard deviation
    rng      : numpy random Generator

    Returns
    -------
    F_row_new : (n,) updated row
    GF_new    : (m, n) updated product
    n_accepted : int
    """
    n = G_row.shape[0]
    G_cur = G_row.copy()
    GF_cur = GF.copy()
    n_accepted = 0

    for j in range(n):
        g_new = G_cur[j] + rng.normal(0.0, step_sigma)
        if g_new <= 0.0:
            continue

        # Update column j of GF
        gf_col_new = GF_cur[:, j] + F_col * (g_new - G_cur[j])

        # Log-likelihood ratio (column j only)
        log_gf_old = np.log(np.maximum(GF_cur[:, j], 1e-300))
        log_gf_new = np.log(np.maximum(gf_col_new, 1e-300))
        ll_old = -0.5 * np.sum((logX[:, j] - log_gf_old) ** 2 / tau2[:, j])
        ll_new = -0.5 * np.sum((logX[:, j] - log_gf_new) ** 2 / tau2[:, j])

        # Prior ratio: Exp(lambda_G) or Gamma(shape, lambda_G)
        log_prior = -lambda_G * (g_new - G_cur[j])
        if _prior_G_shape != 1.0:
            log_prior += (_prior_G_shape - 1.0) * (
                np.log(max(g_new, 1e-300)) - np.log(max(G_cur[j], 1e-300))
            )

        if np.log(rng.uniform()) < (ll_new - ll_old) + log_prior:
            G_cur[j] = g_new
            GF_cur[:, j] = gf_col_new
            n_accepted += 1

    return G_cur, GF_cur, n_accepted


def _gibbs_sweep_lognormal(
    F: np.ndarray,
    G: np.ndarray,
    GF: np.ndarray,
    logX: np.ndarray,
    tau2: np.ndarray,
    lambda_F: np.ndarray,
    lambda_G: np.ndarray,
    step_F: float,
    step_G: float,
    rng: np.random.Generator,
    volume_alpha: float = 0.0,
    prior_F_shape: float = 1.0,
    prior_G_shape: float = 1.0,
) -> tuple:
    """
    One full MH sweep under log-normal likelihood.

    Step 1: For each factor k, element-wise MH on F[:,k], then column-level
            volume-prior MH accept/reject on the entire column change.
    Step 2: For each factor k, element-wise MH on G[k,:].

    GF = F @ G is maintained incrementally throughout.

    Returns
    -------
    F, G, GF : updated matrices
    n_accepted_F : total F element proposals accepted
    n_accepted_G : total G element proposals accepted
    n_vol_accepted : volume-prior column-level MH accepts
    n_vol_proposed : volume-prior column-level MH proposals
    """
    p = F.shape[1]
    n_acc_F = 0
    n_acc_G = 0
    n_vol_accepted = 0
    n_vol_proposed = 0

    for k in range(p):
        F_old_col = F[:, k].copy()
        F_new_col, GF, n_acc = _mh_steps_F_col_lognormal(
            F[:, k], G[k, :], GF, logX, tau2,
            float(lambda_F[k]), step_F, rng,
            _prior_F_shape=prior_F_shape,
        )
        F[:, k] = F_new_col
        n_acc_F += n_acc

        # Column-level volume prior MH on the net change from element-wise MH
        if volume_alpha > 0:
            n_vol_proposed += 1
            log_det_new = _volume_log_det(F)
            F[:, k] = F_old_col
            log_det_old = _volume_log_det(F)
            log_accept = 0.5 * volume_alpha * (log_det_new - log_det_old)
            if log_accept >= 0 or np.log(rng.uniform()) < log_accept:
                F[:, k] = F_new_col  # accept
                n_vol_accepted += 1
            else:
                # reject: restore old column and recompute GF
                GF = F @ G

    for k in range(p):
        G_new_row, GF, n_acc = _mh_steps_G_row_lognormal(
            F[:, k], G[k, :], GF, logX, tau2,
            float(lambda_G[k]), step_G, rng,
            _prior_G_shape=prior_G_shape,
        )
        G[k, :] = G_new_row
        n_acc_G += n_acc

    return F, G, GF, n_acc_F, n_acc_G, n_vol_accepted, n_vol_proposed


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def pmf_bayes(
    X: np.ndarray,
    sigma: np.ndarray,
    p: int,
    n_samples: int = 1000,
    n_burnin: int = 500,
    n_thin: int = 1,
    lambda_F: float = 1.0,
    lambda_G: float = 1.0,
    learn_hyperparams: bool = True,
    hyperparam_shape: float = 1.0,
    hyperparam_rate: float = 0.1,
    F_init: Optional[np.ndarray] = None,
    G_init: Optional[np.ndarray] = None,
    init_method: str = "random",
    warm_start: bool = True,
    warm_start_seeds: int = 30,
    warm_start_iter: int = 1000,
    store_samples: bool = False,
    random_seed: Optional[int] = None,
    sampler: str = "icdf",
    ard: bool = False,
    ard_threshold: float = 0.01,
    likelihood: str = "gaussian",
    mh_step_size_F: float = 0.1,
    mh_step_size_G: float = 0.1,
    sigma_prior: Optional[str] = None,
    sigma_categories: Optional[np.ndarray] = None,
    sigma_prior_params: Optional[dict] = None,
    robust: bool = False,
    robust_df: float = 5.0,
    volume_alpha: float = 0.0,
    prior_F_shape: float = 1.0,
    prior_G_shape: float = 1.0,
    verbose: bool = False,
) -> BayesNMFResult:
    """
    Bayesian NMF via Gibbs sampling (Schmidt et al. 2009).

    Fits the generative model with heteroscedastic Gaussian noise and
    exponential priors on factor elements. Full conditionals for F and G
    are truncated Gaussians, sampled exactly. Exponential rate hyperparameters
    are optionally updated via conjugate Gamma posteriors.

    No domain expertise in Bayesian statistics is required — the defaults
    are designed for environmental PMF applications.

    Parameters
    ----------
    X : ndarray, shape (m, n)
        Data matrix to factorize. Must be non-negative and finite.
    sigma : ndarray, shape (m, n)
        Per-element standard deviations (measurement uncertainties).
        Must be positive and finite.
    p : int
        Number of factors (rank).
    n_samples : int, default=1000
        Number of posterior samples to collect after burn-in.
    n_burnin : int, default=500
        Number of initial Gibbs sweeps to discard (burn-in period).
    n_thin : int, default=1
        Thinning factor: collect 1 sample every n_thin sweeps.
        Increase to reduce autocorrelation at the cost of more computation.
    lambda_F : float, default=1.0
        Initial exponential rate for the F prior. Larger values impose
        stronger shrinkage toward zero. Auto-tuned when learn_hyperparams=True.
    lambda_G : float, default=1.0
        Initial exponential rate for the G prior. See lambda_F.
    learn_hyperparams : bool, default=True
        If True, update lambda_F and lambda_G each iteration using conjugate
        Gamma posteriors. Recommended: allows the model to adapt the prior
        strength to the data scale.
    hyperparam_shape : float, default=1.0
        Shape (a) for the Gamma(a, b) hyperprior on lambda.
    hyperparam_rate : float, default=0.1
        Rate (b) for the Gamma(a, b) hyperprior on lambda.
        Prior mean = a/b = 10 with defaults.
    F_init : ndarray, shape (m, p), optional
        Initial F matrix. Warm-starting from an ACLS solution is recommended
        to reduce burn-in length.
    G_init : ndarray, shape (p, n), optional
        Initial G matrix.
    init_method : {'random', 'random_acol', 'svd_centroid'}, default='random'
        Initialization method when F_init/G_init are not provided and
        warm_start is False.
    warm_start : bool, default=True
        If True (and F_init/G_init are not provided), run multi-seed ACLS
        solves and select the best (lowest Q) to initialize F and G.
        The ACLS point estimate is also used as the alignment reference
        during sampling and returned as ``result.F`` / ``result.G``
        (the sharp point estimate; posterior mean is in
        ``result.F_posterior_mean`` / ``result.G_posterior_mean``).
    warm_start_seeds : int, default=30
        Number of independent ACLS runs with different random seeds.
        The run with the lowest Q is selected as the warm-start.
    warm_start_iter : int, default=1000
        Maximum iterations per ACLS warm-start run.
    store_samples : bool, default=False
        If True, store all n_samples arrays in F_samples and G_samples.
        Warning: uses O(n_samples × m × p + n_samples × p × n) memory.
    random_seed : int, optional
        Seed for reproducibility.
    sampler : {'icdf', 'scipy'}, default='icdf'
        Truncated-normal sampling method used inside each Gibbs sweep.

        'icdf'  — Inverse-CDF method: draws uniform samples from
                  numpy.random.Generator and maps them through
                  scipy.special.ndtr/ndtri.  Avoids scipy.stats
                  dispatch overhead; typically 3–5× faster per sweep.
        'scipy' — Uses scipy.stats.truncnorm.rvs; original behaviour.
    ard : bool, default=False
        Enable Automatic Relevance Determination.  When True, each factor
        gets its own exponential rate hyperparameters (lambda_G_k, lambda_F_k)
        updated independently via conjugate Gamma posteriors.  Factors that
        are not supported by the data have their rates driven large, effectively
        zeroing them out.  This allows over-specifying p and letting the model
        prune unnecessary factors automatically.

        When ard=True, ``learn_hyperparams`` is forced to True (per-factor
        updates are the mechanism that enables factor pruning).

        For aggressive pruning, set ``hyperparam_shape < 1`` (e.g., 0.5).
        The default ``hyperparam_shape=1.0`` provides moderate pruning.
    ard_threshold : float, default=0.01
        Relative contribution threshold for declaring a factor active
        under ARD.  Factor k is active if its contribution fraction
        (||F[:,k]||_1 * ||G[k,:]||_1 / total) exceeds this value.
    likelihood : {'gaussian', 'lognormal'}, default='gaussian'
        Noise model for the data.

        'gaussian'  — X[i,j] ~ N((GF)[i,j], sigma[i,j]^2).
                      Full conditionals are truncated Gaussian; sampled
                      exactly via Gibbs.
        'lognormal' — log(X[i,j]) ~ N(log((GF)[i,j]), tau[i,j]^2) where
                      tau[i,j] = sigma[i,j] / X[i,j] (coefficient of
                      variation, via delta method).  Full conditionals are
                      non-conjugate; F and G are updated via element-wise
                      Metropolis-Hastings.  Requires X > 0 everywhere.
                      Better suited for concentration data that is
                      approximately log-normally distributed.
    mh_step_size_F : float, default=0.1
        Proposal step size for F elements under log-normal likelihood.
        The actual proposal std is ``mh_step_size_F * mean(F)``
        (auto-scaled).  Ignored for Gaussian likelihood.
    mh_step_size_G : float, default=0.1
        Proposal step size for G elements under log-normal likelihood.
        The actual proposal std is ``mh_step_size_G * mean(G)``
        (auto-scaled).  Ignored for Gaussian likelihood.
    sigma_prior : {None, 'per_variable', 'per_element'}, default=None
        Hierarchical uncertainty modeling.  When set, sigma is no longer
        treated as fixed — instead, an Inverse-Gamma prior is placed on
        sigma^2 and it is sampled alongside F and G during Gibbs sweeps.

        None            — Fixed sigma (default, standard behavior).
        'per_variable'  — One sigma^2 per variable (row of X), pooled
                          across all n observations.  Each draw is informed
                          by n data points — recommended for environmental
                          PMF where measurement quality is a property of
                          the chemical species.  Adds m InvGamma draws
                          per sweep (negligible cost).
        'per_element'   — One sigma^2 per element of X.  Fully flexible
                          but each draw is informed by only 1 data point.
                          Adds m × n InvGamma draws per sweep (vectorized,
                          ~1-2 ms for typical environmental data).

    sigma_categories : ndarray, optional
        Integer array assigning each variable (or element) to an
        uncertainty quality category.  Shape (m,) for 'per_variable',
        (m, n) for 'per_element'.  Variables in the same category share
        InvGamma hyperparameters.  If None, all variables are assigned
        to a single category.

    sigma_prior_params : dict, optional
        Mapping from category ID (int) or preset name (str) to
        ``(alpha, beta)`` InvGamma hyperparameters.

        Preset names and their default alpha values:

        - ``"measured"``  — alpha=10 (tight: data strongly anchors sigma)
        - ``"mdl"``       — alpha=5  (moderate)
        - ``"analogous"`` — alpha=2  (loose: sigma can move substantially)
        - ``"guess"``     — alpha=1  (very loose: data dominates)

        When ``beta`` is None, it is auto-initialized so the prior mean
        equals the initial ``sigma^2`` for that category.  This centers
        the prior at the user's best estimate while letting the data
        adjust.

        If ``sigma_prior_params`` is None and ``sigma_prior`` is set,
        all categories default to the ``"analogous"`` preset (alpha=2).
    robust : bool, default=False
        Enable robust Student's t likelihood via a Gaussian-scale mixture.
        When True, per-element precision weights eta_ij ~ Gamma(v/2, v/2)
        are sampled alongside F and G.  The effective variance becomes
        sigma2 / eta, so outlier elements (large residuals) receive small
        eta and are automatically down-weighted.

        Compatible with both Gaussian and lognormal likelihoods, and with
        hierarchical sigma.  When both ``robust`` and ``sigma_prior`` are
        active, eta-weighted residuals are passed to the sigma sampler so
        the two mechanisms interact correctly.
    robust_df : float, default=5.0
        Degrees of freedom (v) for the Student's t distribution.  Lower
        values give heavier tails and more aggressive outlier down-weighting.
        Typical values: 3–10.  Must be positive.
    volume_alpha : float, default=0.0
        Strength of the log-determinant volume prior on F:
        p(F) ∝ det(F^T F)^(α/2).  Penalizes collinear F columns,
        encouraging geometrically separated factor profiles.  Set to 0
        to disable (default, current behavior).  Values of 1–5 are
        typical.  Implemented as a Metropolis-Hastings correction on top
        of the Gibbs proposal.  Particularly useful with warm_start=False
        to prevent factor collapse without ACLS anchoring.
    prior_F_shape : float, default=1.0
        Shape parameter for a Gamma(a, lambda_F) prior on F elements.
        When 1.0, reduces to the standard Exponential(lambda_F) prior.
        Values < 1 (e.g. 0.5) concentrate mass near zero, inducing
        sparser factor profiles.  Implemented as an MH correction.
    prior_G_shape : float, default=1.0
        Shape parameter for a Gamma(a, lambda_G) prior on G elements.
        See ``prior_F_shape``.
    verbose : bool, default=False
        Print progress every 100 iterations.

    Returns
    -------
    result : BayesNMFResult
        ``result.F`` / ``result.G`` are the ACLS point estimate (when
        ``warm_start=True``) or posterior mean (otherwise).  These are
        sharp, well-separated factor profiles suitable for interpretation.

        ``result.F_posterior_mean`` / ``result.G_posterior_mean`` are the
        Gibbs posterior means.  These may show higher inter-factor
        similarity due to residual label switching.

        ``result.F_std`` / ``result.G_std`` are posterior standard
        deviations for Bayesian uncertainty quantification.

        Call result.to_pmf_result() for compatibility with diagnostics
        and uncertainty tools.

        When ``ard=True``, the result additionally contains:

        - ``ard_lambda_F``, ``ard_lambda_G`` : per-factor rate arrays (p,)
        - ``active_factors`` : boolean mask (p,) — True for active factors
        - ``effective_p`` : int — number of active factors

    Notes
    -----
    When ``warm_start=True``, a multi-seed ACLS solve (``warm_start_seeds``
    runs, ``warm_start_iter`` iterations each) selects the best point
    estimate.  This serves as both the returned F/G and the Hungarian
    alignment reference during Gibbs sampling.

    Posterior standard deviations in F_std and G_std are proper Bayesian
    credible-interval widths, not bootstrap estimates. They reflect the
    combined effect of data uncertainty (sigma) and model non-identifiability.

    Factor columns of F are normalized to unit L1 norm after each Gibbs
    sweep (scale absorbed into G rows), and factors are aligned to the
    warm-start reference via Hungarian matching on cosine similarity.

    References
    ----------
    Schmidt, M. N., Winther, O., & Hansen, L. K. (2009).
        Bayesian non-negative matrix factorization.
        ICA, pp. 540-547.

    Cemgil, A. T. (2009).
        Bayesian inference for nonnegative matrix factorisation models.
        Computational Intelligence and Neuroscience.

    Geweke, J. (1992).
        Evaluating the accuracy of sampling-based approaches to the
        calculation of posterior moments. Bayesian Statistics 4, 169-193.
    """
    # ---- Input validation ----
    validate_data_matrix(X, "X")
    m, n = X.shape
    validate_uncertainty_matrix(sigma, X.shape)
    validate_rank(p, m, n)

    if n_samples < 1:
        raise ValueError(f"n_samples must be >= 1, got {n_samples}")
    if n_burnin < 0:
        raise ValueError(f"n_burnin must be >= 0, got {n_burnin}")
    if n_thin < 1:
        raise ValueError(f"n_thin must be >= 1, got {n_thin}")
    if lambda_F <= 0:
        raise ValueError(f"lambda_F must be > 0, got {lambda_F}")
    if lambda_G <= 0:
        raise ValueError(f"lambda_G must be > 0, got {lambda_G}")
    if hyperparam_shape <= 0:
        raise ValueError(f"hyperparam_shape must be > 0, got {hyperparam_shape}")
    if hyperparam_rate <= 0:
        raise ValueError(f"hyperparam_rate must be > 0, got {hyperparam_rate}")

    if robust and robust_df <= 0:
        raise ValueError(f"robust_df must be positive, got {robust_df}")
    if volume_alpha < 0:
        raise ValueError(f"volume_alpha must be >= 0, got {volume_alpha}")
    if prior_F_shape <= 0:
        raise ValueError(f"prior_F_shape must be > 0, got {prior_F_shape}")
    if prior_G_shape <= 0:
        raise ValueError(f"prior_G_shape must be > 0, got {prior_G_shape}")

    if likelihood not in ("gaussian", "lognormal"):
        raise ValueError(f"likelihood must be 'gaussian' or 'lognormal', got '{likelihood}'")
    if likelihood == "lognormal" and np.any(X <= 0):
        raise ValueError("likelihood='lognormal' requires X > 0 everywhere")

    sample_fn = _make_sampler(sampler)

    # ---- Hierarchical sigma setup ----
    sigma_config = _validate_sigma_prior(
        sigma_prior, sigma_categories, sigma_prior_params, m, n, sigma,
    )

    # ---- Initialization ----
    rng = np.random.default_rng(random_seed)

    # When ARD is enabled without explicit init, default to random init
    # so ARD can discover the factor count from scratch.  ACLS warm-start
    # distributes mass across all p factors, defeating ARD pruning.
    _use_warm_start = warm_start and not (ard and F_init is None and G_init is None)

    if F_init is not None or G_init is not None:
        # Explicit init provided — use it directly
        from .core import initialize_factors
        seed_for_init = int(rng.integers(0, 2**31)) if random_seed is not None else None
        F, G = initialize_factors(
            m=m, n=n, p=p, X=X,
            F_init=F_init, G_init=G_init,
            random_seed=seed_for_init,
            init_method=init_method,
        )
    elif _use_warm_start:
        # Multi-seed ACLS warm-start: run several seeds, keep the best Q.
        from .core import pmf_acls as _pmf_acls
        if verbose:
            print(f"Bayesian NMF: warm-starting from ACLS "
                  f"({warm_start_seeds} seeds, {warm_start_iter} iter)...")
        best_Q = np.inf
        best_result = None
        for _ in range(warm_start_seeds):
            seed_for_init = int(rng.integers(0, 2**31))
            try:
                acls_result = _pmf_acls(
                    X=X, sigma=sigma, p=p,
                    max_iter=warm_start_iter, conv_tol=0.005,
                    random_seed=seed_for_init,
                    verbose=False,
                )
                if acls_result.Q < best_Q:
                    best_Q = acls_result.Q
                    best_result = acls_result
            except Exception:
                continue  # skip failed seeds
        if best_result is None:
            raise RuntimeError("All ACLS warm-start seeds failed")
        if verbose:
            print(f"  Best ACLS Q={best_Q:.4e} "
                  f"(converged={best_result.converged})")
        F = best_result.F.copy()
        G = best_result.G.copy()
    else:
        from .core import initialize_factors
        seed_for_init = int(rng.integers(0, 2**31)) if random_seed is not None else None
        F, G = initialize_factors(
            m=m, n=n, p=p, X=X,
            F_init=F_init, G_init=G_init,
            random_seed=seed_for_init,
            init_method=init_method,
        )

    # Save initialization as alignment reference and point estimate.
    # ACLS warm-start and explicit init have meaningful factor separation;
    # random init does not.
    if _use_warm_start or G_init is not None:
        _F_point_est = F.copy()
        _G_point_est = G.copy()
        _G_init_ref = G.copy()
    else:
        _F_point_est = None
        _G_point_est = None
        _G_init_ref = None

    # ---- Likelihood-specific precomputation ----
    if likelihood == "lognormal":
        logX = np.log(X)
        tau2 = (sigma / X) ** 2
        GF = F @ G
        # MH acceptance tracking
        total_accepted_G = 0
        total_accepted_F = 0
        total_proposed_G = 0
        total_proposed_F = 0
        if sigma_config is not None:
            sigma2 = sigma ** 2  # maintain for hierarchical sampling
    else:
        sigma2 = sigma ** 2
        R = X - F @ G

    # ---- Volume prior MH tracking ----
    total_vol_accepted = 0
    total_vol_proposed = 0

    # ---- Scalar precision τ_scale (Schmidt et al. 2009) ----
    # The original Bayesian NMF model samples a scalar precision τ as part
    # of the Gibbs loop.  In our heteroscedastic model with per-element σ,
    # we sample a scalar scale factor τ_scale such that the effective
    # variance is σ²[i,j] / τ_scale.  This preserves the relative weighting
    # from user-provided σ while adapting the overall noise level:
    #   - When factors collapse → residuals grow → τ_scale decreases →
    #     likelihood loosens → sampler can explore better configurations
    #   - When factors fit well → residuals shrink → τ_scale increases →
    #     likelihood tightens → sampler stays near good solution
    # Uses a weak Gamma(1, 0.1) prior (mean=10, diffuse).
    tau_scale = 1.0
    _tau_alpha = 1.0
    _tau_beta = 0.1

    # ---- Lambda cap ----
    # Prevent runaway hyperparameter growth that collapses F/G to zero.
    # The exponential prior mean for each element is 1/lambda, so lambda
    # should not greatly exceed the inverse of a "typical" element scale.
    # With per-sweep normalization, F columns are unit L1 (elements ~1/m)
    # and G rows absorb the data scale.  We set initial caps from the
    # current (ACLS-init) scale; they are recomputed after the first
    # burn-in normalization step to match the post-normalization scale.
    _g_scale = max(float(F.mean()), float(np.sqrt(np.mean(X))) / p, 1e-12)
    _f_scale = max(float(G.mean()), float(np.sqrt(np.mean(X))) / p, 1e-12)
    lambda_F_max = 10.0 / _g_scale
    lambda_G_max = 10.0 / _f_scale
    _lambda_caps_recomputed = False

    # ---- Storage ----
    Q_samples = np.empty(n_samples)
    if store_samples:
        F_samples_arr: Optional[np.ndarray] = np.empty((n_samples, m, p))
        G_samples_arr: Optional[np.ndarray] = np.empty((n_samples, p, n))
    else:
        F_samples_arr = None
        G_samples_arr = None

    # Welford online accumulators for posterior mean and variance
    F_mean = np.zeros((m, p))
    G_mean = np.zeros((p, n))
    F_M2 = np.zeros((m, p))
    G_M2 = np.zeros((p, n))
    n_collected = 0

    # Welford accumulators for sigma2 (hierarchical mode only)
    if sigma_config is not None:
        if sigma_config.mode == "per_variable":
            sigma2_mean = np.zeros(m)
            sigma2_M2 = np.zeros(m)
            if store_samples:
                sigma2_samples_arr: Optional[np.ndarray] = np.empty((n_samples, m))
            else:
                sigma2_samples_arr = None
        else:
            sigma2_mean = np.zeros((m, n))
            sigma2_M2 = np.zeros((m, n))
            if store_samples:
                sigma2_samples_arr = np.empty((n_samples, m, n))
            else:
                sigma2_samples_arr = None
    else:
        sigma2_samples_arr = None

    # ---- Robust eta setup ----
    if robust:
        eta = np.ones((m, n))
        eta_mean_acc = np.zeros((m, n))
        eta_M2_acc = np.zeros((m, n))
        eta_samples_arr = np.empty((n_samples, m, n)) if store_samples else None
    else:
        eta = None

    # ---- ARD setup ----
    # When ard=True, lambda_F and lambda_G become per-factor arrays;
    # otherwise they are broadcast to uniform arrays for a consistent
    # internal representation (the _gibbs_sweep function always indexes).
    if ard:
        learn_hyperparams = True  # ARD requires hyperparameter learning
    lambda_F_cur = np.full(p, float(lambda_F))
    lambda_G_cur = np.full(p, float(lambda_G))
    lambda_F_acc = np.zeros(p)
    lambda_G_acc = np.zeros(p)

    # Per-sample factor activity tracking (ARD mode)
    if ard:
        factor_activity_arr: Optional[np.ndarray] = np.empty((n_samples, p))
    else:
        factor_activity_arr = None

    def _update_hyperparams_inplace() -> None:
        """Update lambda_F_cur and lambda_G_cur from conjugate Gamma posteriors.

        When prior_F_shape != 1 or prior_G_shape != 1, the prior on each F/G
        element is Gamma(a, lambda) instead of Exp(lambda).  The conjugate
        posterior shape for lambda becomes: hyper_shape + n_elements * a.
        """
        if ard:
            # Per-factor shared λ_k (Brouwer et al. 2017, Section 2.3):
            # A single λ_k governs both F[:,k] and G[k,:].
            # With per-sweep normalization F columns are unit L1, so F column
            # sums carry no activity information.  We use only G row sums
            # (which absorb all scale) to drive the ARD signal: inactive
            # factors have near-zero G rows → small sum → large λ_k.
            # No cap: ARD needs λ_k → ∞ to prune inactive factors;
            # the posterior is self-regularizing.
            for k in range(p):
                g_sum = G[k, :].sum()
                lam_k = float(rng.gamma(
                    shape=hyperparam_shape + n * prior_G_shape,
                    scale=1.0 / (hyperparam_rate + g_sum),
                ))
                lambda_F_cur[k] = lam_k
                lambda_G_cur[k] = lam_k
        else:
            # Shared scalar updates (broadcast to all factors).
            # Conjugate Gamma posterior: λ_F | F ~ Gamma(a + m*p*shape_F, b + sum(F))
            val_F = min(float(rng.gamma(
                shape=hyperparam_shape + m * p * prior_F_shape,
                scale=1.0 / (hyperparam_rate + F.sum()),
            )), lambda_F_max)
            val_G = min(float(rng.gamma(
                shape=hyperparam_shape + p * n * prior_G_shape,
                scale=1.0 / (hyperparam_rate + G.sum()),
            )), lambda_G_max)
            lambda_F_cur[:] = val_F
            lambda_G_cur[:] = val_G

    # ---- Burn-in ----
    # Each sweep: Gibbs update (using τ_scale-adjusted σ²) → sample τ_scale
    # → hierarchical sigma / robust eta → hyperparameter update.
    # The scalar τ_scale (Schmidt et al. 2009, Brouwer et al. 2017) adapts
    # the overall noise level, preventing factor collapse.
    if verbose:
        print(f"Bayesian NMF: burn-in ({n_burnin} sweeps)..."
              + (" [ARD enabled]" if ard else ""))

    for i in range(n_burnin):
        if likelihood == "lognormal":
            step_F = mh_step_size_F * max(float(F.mean()), 1e-6)
            step_G = mh_step_size_G * max(float(G.mean()), 1e-6)
            tau2_eff = tau2 / (eta * tau_scale) if robust else tau2 / tau_scale
            F, G, GF, _, _, _nva, _nvp = _gibbs_sweep_lognormal(
                F, G, GF, logX, tau2_eff, lambda_F_cur, lambda_G_cur,
                step_F, step_G, rng,
                volume_alpha=volume_alpha,
                prior_F_shape=prior_F_shape,
                prior_G_shape=prior_G_shape,
            )
        else:
            sigma2_eff = sigma2 / tau_scale
            if robust:
                sigma2_eff = sigma2_eff / eta
            F, G, R, _nva, _nvp = _gibbs_sweep(
                F, G, R, sigma2_eff, lambda_F_cur, lambda_G_cur, rng, sample_fn,
                volume_alpha=volume_alpha,
                prior_F_shape=prior_F_shape,
                prior_G_shape=prior_G_shape,
            )

        # Sample τ_scale from Gamma posterior.
        # Disabled when hierarchical sigma is active to avoid
        # non-identifiable parameterization (both tau_scale and sigma2
        # would modulate effective variance simultaneously).
        if sigma_config is None:
            if likelihood == "gaussian":
                weighted_ssr = float(np.sum(R ** 2 / sigma2))
            else:
                GF_safe = np.maximum(F @ G, 1e-300)
                weighted_ssr = float(np.sum((logX - np.log(GF_safe)) ** 2 / tau2))
            tau_scale = float(rng.gamma(
                shape=_tau_alpha + 0.5 * m * n,
                scale=1.0 / (_tau_beta + 0.5 * weighted_ssr),
            ))

        # Hierarchical sigma sampling (burn-in)
        if sigma_config is not None and likelihood == "gaussian":
            R_sq_for_sigma = R ** 2 * eta if robust else R ** 2
            if sigma_config.mode == "per_variable":
                R_sq_sum = np.sum(R_sq_for_sigma, axis=1)
                _sample_sigma2_per_variable(
                    R_sq_sum, sigma2, sigma_config.categories,
                    sigma_config.alpha, sigma_config.beta_init, n, rng,
                )
            else:
                _sample_sigma2_per_element(
                    R_sq_for_sigma, sigma2, sigma_config.categories,
                    sigma_config.alpha, sigma_config.beta_init, rng,
                )
        if sigma_config is not None and likelihood == "lognormal":
            GF_safe = np.maximum(GF, 1e-300)
            log_resid_sq = (logX - np.log(GF_safe)) ** 2
            eff_R_sq = log_resid_sq * (X ** 2)
            if robust:
                eff_R_sq = eff_R_sq * eta
            if sigma_config.mode == "per_variable":
                R_sq_sum = np.sum(eff_R_sq, axis=1)
                _sample_sigma2_per_variable(
                    R_sq_sum, sigma2, sigma_config.categories,
                    sigma_config.alpha, sigma_config.beta_init, n, rng,
                )
            else:
                _sample_sigma2_per_element(
                    eff_R_sq, sigma2, sigma_config.categories,
                    sigma_config.alpha, sigma_config.beta_init, rng,
                )
            tau2[:] = sigma2 / (X ** 2)

        # Robust eta sampling (burn-in)
        if robust:
            if likelihood == "gaussian":
                eta[:] = _sample_eta(R ** 2, sigma2, robust_df, rng)
            else:  # lognormal
                GF_safe = np.maximum(F @ G, 1e-300)
                log_resid_sq = (np.log(np.maximum(X, 1e-300)) - np.log(GF_safe)) ** 2
                eta[:] = _sample_eta(log_resid_sq, tau2, robust_df, rng)

        if learn_hyperparams:
            _update_hyperparams_inplace()

        # Normalize F columns to unit L1 (absorb scale into G rows) and
        # sort factors by decreasing G row mass.  This prevents scale
        # degeneracy where one factor's F column shrinks while its G row
        # grows unboundedly.  The product F @ G is preserved exactly.
        F, G, _, _ = _normalize_factors(F, G)
        if likelihood == "gaussian":
            R = X - F @ G
        elif likelihood == "lognormal":
            GF = F @ G

        # After the first normalization, F and G are on a different scale
        # than the ACLS warm-start.  Recompute lambda caps to match.
        if not _lambda_caps_recomputed:
            _g_scale = max(float(F.mean()), 1e-12)
            _f_scale = max(float(G.mean()), 1e-12)
            lambda_F_max = 10.0 / _g_scale
            lambda_G_max = 10.0 / _f_scale
            _lambda_caps_recomputed = True

        if verbose and (i + 1) % 100 == 0:
            if likelihood == "lognormal":
                Q_disp = _compute_Q_lognormal(F, G, logX, tau2)
            else:
                Q_disp = np.sum(R ** 2 / sigma2)
            print(f"  burn-in {i+1}/{n_burnin}  "
                  f"Q={Q_disp:.4e}  τ={tau_scale:.3f}  "
                  f"λ_F={lambda_F_cur.mean():.3f}  λ_G={lambda_G_cur.mean():.3f}")

    # ---- Sampling ----
    # Hungarian alignment reference: use ACLS warm-start factors (pre-burnin)
    # when available, since they have the sharpest factor separation.  For
    # random init (including ARD), fall back to end-of-burnin state with
    # adaptive updates every 50 thinned samples (posterior mean stabilizes).
    if _G_init_ref is not None:
        G_ref = _G_init_ref
        _adaptive_ref = False
    else:
        G_ref = G.copy()
        _adaptive_ref = True
    _adaptive_ref_interval = 50

    if verbose:
        print(f"Bayesian NMF: sampling ({n_samples} draws, thin={n_thin})...")

    sample_idx = 0
    min_label_gap = 1.0  # track Hungarian matching quality
    factor_contrib_traces = np.empty((n_samples, p))  # per-factor G-row sums
    for i in range(n_samples * n_thin):
        if likelihood == "lognormal":
            step_F = mh_step_size_F * max(float(F.mean()), 1e-6)
            step_G = mh_step_size_G * max(float(G.mean()), 1e-6)
            tau2_eff = tau2 / (eta * tau_scale) if robust else tau2 / tau_scale
            F, G, GF, n_acc_F, n_acc_G, _nva, _nvp = _gibbs_sweep_lognormal(
                F, G, GF, logX, tau2_eff, lambda_F_cur, lambda_G_cur,
                step_F, step_G, rng,
                volume_alpha=volume_alpha,
                prior_F_shape=prior_F_shape,
                prior_G_shape=prior_G_shape,
            )
            total_accepted_F += n_acc_F
            total_accepted_G += n_acc_G
            total_proposed_G += m * p
            total_proposed_F += n * p
            total_vol_accepted += _nva
            total_vol_proposed += _nvp
        else:
            sigma2_eff = sigma2 / tau_scale
            if robust:
                sigma2_eff = sigma2_eff / eta
            F, G, R, _nva, _nvp = _gibbs_sweep(
                F, G, R, sigma2_eff, lambda_F_cur, lambda_G_cur, rng, sample_fn,
                volume_alpha=volume_alpha,
                prior_F_shape=prior_F_shape,
                prior_G_shape=prior_G_shape,
            )
            total_vol_accepted += _nva
            total_vol_proposed += _nvp

        # Sample τ_scale from Gamma posterior (disabled when hierarchical
        # sigma active — see burn-in comment for rationale).
        if sigma_config is None:
            if likelihood == "gaussian":
                weighted_ssr = float(np.sum(R ** 2 / sigma2))
            else:
                GF_safe = np.maximum(F @ G, 1e-300)
                weighted_ssr = float(np.sum((logX - np.log(GF_safe)) ** 2 / tau2))
            tau_scale = float(rng.gamma(
                shape=_tau_alpha + 0.5 * m * n,
                scale=1.0 / (_tau_beta + 0.5 * weighted_ssr),
            ))

        # Hierarchical sigma sampling (sampling phase)
        if sigma_config is not None and likelihood == "gaussian":
            R_sq_for_sigma = R ** 2 * eta if robust else R ** 2
            if sigma_config.mode == "per_variable":
                R_sq_sum = np.sum(R_sq_for_sigma, axis=1)
                _sample_sigma2_per_variable(
                    R_sq_sum, sigma2, sigma_config.categories,
                    sigma_config.alpha, sigma_config.beta_init, n, rng,
                )
            else:
                _sample_sigma2_per_element(
                    R_sq_for_sigma, sigma2, sigma_config.categories,
                    sigma_config.alpha, sigma_config.beta_init, rng,
                )
        if sigma_config is not None and likelihood == "lognormal":
            GF_safe = np.maximum(GF, 1e-300)
            log_resid_sq = (logX - np.log(GF_safe)) ** 2
            eff_R_sq = log_resid_sq * (X ** 2)
            if robust:
                eff_R_sq = eff_R_sq * eta
            if sigma_config.mode == "per_variable":
                R_sq_sum = np.sum(eff_R_sq, axis=1)
                _sample_sigma2_per_variable(
                    R_sq_sum, sigma2, sigma_config.categories,
                    sigma_config.alpha, sigma_config.beta_init, n, rng,
                )
            else:
                _sample_sigma2_per_element(
                    eff_R_sq, sigma2, sigma_config.categories,
                    sigma_config.alpha, sigma_config.beta_init, rng,
                )
            tau2[:] = sigma2 / (X ** 2)

        # Robust eta sampling (sampling phase)
        if robust:
            if likelihood == "gaussian":
                eta[:] = _sample_eta(R ** 2, sigma2, robust_df, rng)
            else:  # lognormal
                GF_safe = np.maximum(F @ G, 1e-300)
                log_resid_sq = (np.log(np.maximum(X, 1e-300)) - np.log(GF_safe)) ** 2
                eta[:] = _sample_eta(log_resid_sq, tau2, robust_df, rng)

        if learn_hyperparams:
            _update_hyperparams_inplace()

        # Normalize F columns to unit L1, absorb scale into G rows,
        # then align factors to reference to prevent label switching.
        F, G, _, norm_order = _normalize_factors(F, G)
        sort_order, _gap = _sort_factors(F, G, G_ref=G_ref)
        min_label_gap = min(min_label_gap, _gap)
        if ard:
            # Apply both orderings to per-factor lambdas
            combined_order = norm_order[sort_order]
            lambda_F_cur[:] = lambda_F_cur[combined_order]
            lambda_G_cur[:] = lambda_G_cur[combined_order]
        if likelihood == "gaussian":
            R = X - F @ G
        elif likelihood == "lognormal":
            GF = F @ G

        if (i + 1) % n_thin == 0:
            # Adaptive relabeling: update reference from running posterior mean
            if _adaptive_ref and n_collected > 0 and n_collected % _adaptive_ref_interval == 0:
                G_ref = G_mean.copy()

            if likelihood == "lognormal":
                Q_cur = _compute_Q_lognormal(F, G, logX, tau2)
            else:
                Q_cur = float(np.sum(R ** 2 / sigma2))
            Q_samples[sample_idx] = Q_cur

            if store_samples:
                F_samples_arr[sample_idx] = F.copy()
                G_samples_arr[sample_idx] = G.copy()

            # Welford update
            n_collected += 1
            dF = F - F_mean
            F_mean += dF / n_collected
            F_M2 += dF * (F - F_mean)

            dG = G - G_mean
            G_mean += dG / n_collected
            G_M2 += dG * (G - G_mean)

            if sigma_config is not None:
                if sigma_config.mode == "per_variable":
                    # sigma2 rows are identical, take column 0
                    s2_cur = sigma2[:, 0]
                else:
                    s2_cur = sigma2.copy()

                d_s2 = s2_cur - sigma2_mean
                sigma2_mean += d_s2 / n_collected
                sigma2_M2 += d_s2 * (s2_cur - sigma2_mean)

                if store_samples:
                    sigma2_samples_arr[sample_idx] = s2_cur

            if robust:
                d_eta = eta - eta_mean_acc
                eta_mean_acc += d_eta / n_collected
                eta_M2_acc += d_eta * (eta - eta_mean_acc)
                if store_samples:
                    eta_samples_arr[sample_idx] = eta.copy()

            lambda_F_acc += lambda_F_cur
            lambda_G_acc += lambda_G_cur

            # Record per-factor activity fraction for this sample
            if factor_activity_arr is not None:
                g_row_norms = np.array([float(G[k, :].sum()) for k in range(p)])
                total_norm = g_row_norms.sum()
                if total_norm > 1e-30:
                    factor_activity_arr[sample_idx] = g_row_norms / total_norm
                else:
                    factor_activity_arr[sample_idx] = 0.0

            # Per-factor contribution trace for convergence diagnostics
            factor_contrib_traces[sample_idx] = np.array(
                [float(G[k, :].sum()) for k in range(p)]
            )

            sample_idx += 1

            if verbose and sample_idx % 100 == 0:
                print(f"  sample {sample_idx}/{n_samples}  Q={Q_cur:.4e}  "
                      f"λ_F={lambda_F_cur.mean():.3f}  λ_G={lambda_G_cur.mean():.3f}")

    # ---- Posterior summaries ----
    # Samples were normalized+sorted per sweep, so the posterior mean is
    # already approximately normalized.  Apply _normalize_factors to the
    # mean for exact unit-L1 F columns and consistent factor ordering.
    F_mean, G_mean, _, order = _normalize_factors(F_mean, G_mean)
    F_std = np.sqrt(F_M2 / max(n_collected - 1, 1))[:, order]
    G_std = np.sqrt(G_M2 / max(n_collected - 1, 1))[order, :]
    lambda_F_final_arr = lambda_F_acc / max(n_collected, 1)
    lambda_G_final_arr = lambda_G_acc / max(n_collected, 1)
    # Apply the same factor ordering to per-factor lambdas and activity samples
    lambda_F_final_arr = lambda_F_final_arr[order]
    lambda_G_final_arr = lambda_G_final_arr[order]
    if factor_activity_arr is not None:
        factor_activity_arr = factor_activity_arr[:, order]

    # Scalar summary for backward compatibility
    lambda_F_final = float(lambda_F_final_arr.mean())
    lambda_G_final = float(lambda_G_final_arr.mean())

    # ---- Hierarchical sigma posterior ----
    if sigma_config is not None:
        sigma_post_mean = sigma2_mean.copy()
        sigma_post_std = np.sqrt(sigma2_M2 / max(n_collected - 1, 1))
        sigma_post_mode = sigma_config.mode
        sigma_post_samples = sigma2_samples_arr
    else:
        sigma_post_mean = None
        sigma_post_std = None
        sigma_post_mode = None
        sigma_post_samples = None

    # ---- Robust eta posterior ----
    if robust:
        eta_post_mean = eta_mean_acc.copy()
        eta_post_std = np.sqrt(eta_M2_acc / max(n_collected - 1, 1))
        outlier_mask_arr = eta_post_mean < 0.5
    else:
        eta_post_mean = eta_post_std = outlier_mask_arr = None
        eta_samples_arr = None

    if sigma_config is not None:
        if sigma_config.mode == "per_variable":
            _sigma2_for_Q = np.broadcast_to(sigma2_mean[:, np.newaxis], (m, n))
        else:
            _sigma2_for_Q = sigma2_mean

    # Use ACLS point estimate for F/G when available (sharp, well-separated);
    # fall back to posterior mean for random init / ARD.
    F_point = _F_point_est if _F_point_est is not None else F_mean
    G_point = _G_point_est if _G_point_est is not None else G_mean

    if likelihood == "lognormal":
        if sigma_config is not None:
            Q_final = _compute_Q_lognormal(F_point, G_point, logX, _sigma2_for_Q / (X ** 2))
        else:
            Q_final = _compute_Q_lognormal(F_point, G_point, logX, tau2)
    else:
        if sigma_config is not None:
            Q_final = float(np.sum((X - F_point @ G_point) ** 2 / _sigma2_for_Q))
        else:
            Q_final = _compute_Q(F_point, G_point, X, sigma)
    residuals = X - F_point @ G_point
    SS_res = float(np.sum(residuals ** 2))
    SS_tot = float(np.sum((X - X.mean()) ** 2))
    explained_variance = 1.0 - SS_res / SS_tot if SS_tot > 1e-30 else 0.0
    dof = m * n - (m + n) * p
    chi2 = Q_final / dof if dof > 0 else float("nan")

    _geweke_signed = _geweke_z(Q_samples) if len(Q_samples) >= 10 else float("inf")
    geweke = abs(_geweke_signed)
    _geweke_ok = bool(geweke < 2.0)

    # ---- Convergence diagnostics ----
    from .bayes_diagnostics import effective_sample_size as _ess_fn
    _q_ess = _ess_fn(Q_samples) if len(Q_samples) >= 10 else 0.0
    # Apply final factor ordering to contribution traces
    factor_contrib_traces = factor_contrib_traces[:, order]
    _factor_ess = [
        float(_ess_fn(factor_contrib_traces[:, k])) for k in range(p)
    ]
    _min_factor_ess = min(_factor_ess) if _factor_ess else 0.0
    _ess_ok = _min_factor_ess >= 100
    _labels_ok = min_label_gap >= 0.1

    # Converged requires: Geweke stationarity + adequate per-factor mixing
    # + stable label assignment
    converged = _geweke_ok and _ess_ok and _labels_ok

    convergence_details = {
        "geweke_z": float(_geweke_signed),
        "geweke_z_abs": float(geweke),
        "Q_ess": float(_q_ess),
        "factor_ess": _factor_ess,
        "min_factor_ess": _min_factor_ess,
        "geweke_ok": _geweke_ok,
        "ess_ok": _ess_ok,
        "labels_ok": _labels_ok,
    }

    # Reliability warnings — fire unconditionally (not gated on verbose).
    # These are diagnostics about posterior quality, not progress messages.
    import warnings as _warn_mod
    if not _ess_ok:
        _warn_mod.warn(
            f"Low per-factor ESS (min={_min_factor_ess:.0f}). "
            "Consider increasing n_samples or n_burnin.",
            stacklevel=2,
        )

    # ---- Label-switching diagnostic ----
    if not _labels_ok:
        _warn_mod.warn(
            f"Hungarian matching gap is low ({min_label_gap:.3f}). "
            "Two or more factors may be nearly interchangeable — "
            "posterior statistics may be affected by label switching.",
            stacklevel=2,
        )

    # ---- ARD factor activity ----
    if ard:
        contrib = np.array([
            float(F_mean[:, k].sum() * G_mean[k, :].sum()) for k in range(p)
        ])
        total = contrib.sum()
        active = contrib / max(total, 1e-30) > ard_threshold
        ard_lF = lambda_F_final_arr
        ard_lG = lambda_G_final_arr
        eff_p = int(active.sum())
    else:
        active = None
        ard_lG = None
        ard_lF = None
        eff_p = None

    # ---- MH acceptance rate (lognormal only) ----
    if likelihood == "lognormal":
        total_proposed = total_proposed_G + total_proposed_F
        mh_accept = (total_accepted_G + total_accepted_F) / max(total_proposed, 1)
    else:
        mh_accept = None

    # ---- Volume prior MH acceptance rate ----
    if total_vol_proposed > 0:
        vol_accept_rate = total_vol_accepted / total_vol_proposed
    else:
        vol_accept_rate = None

    if verbose:
        _conv_detail = []
        if not _geweke_ok:
            _conv_detail.append(f"Geweke |z|={geweke:.2f}")
        if not _ess_ok:
            _conv_detail.append(f"min_factor_ESS={_min_factor_ess:.0f}")
        if not _labels_ok:
            _conv_detail.append(f"label_gap={min_label_gap:.3f}")
        _conv_why = f" ({', '.join(_conv_detail)})" if _conv_detail else ""
        msg = f"Done. Q={Q_final:.4e}  converged={converged}{_conv_why}"
        if ard:
            msg += f"  active factors={eff_p}/{p}"
        if mh_accept is not None:
            msg += f"  MH accept={mh_accept:.1%}"
        if vol_accept_rate is not None:
            msg += f"  vol MH accept={vol_accept_rate:.1%}"
            if vol_accept_rate < 0.1:
                import warnings
                warnings.warn(
                    f"Volume prior MH acceptance rate is very low "
                    f"({vol_accept_rate:.1%}). Consider reducing volume_alpha.",
                    stacklevel=2,
                )
        print(msg)

    return BayesNMFResult(
        F=F_point,
        G=G_point,
        F_posterior_mean=F_mean,
        G_posterior_mean=G_mean,
        F_std=F_std,
        G_std=G_std,
        F_samples=F_samples_arr,
        G_samples=G_samples_arr,
        Q_samples=Q_samples,
        Q=Q_final,
        n_iter=n_burnin + n_samples * n_thin,
        converged=converged,
        lambda_F=lambda_F_final,
        lambda_G=lambda_G_final,
        residuals=residuals,
        explained_variance=explained_variance,
        chi2=chi2,
        ard_lambda_F=ard_lF,
        ard_lambda_G=ard_lG,
        active_factors=active,
        effective_p=eff_p,
        likelihood=likelihood,
        mh_acceptance_rate=mh_accept,
        sigma_posterior_mean=sigma_post_mean,
        sigma_posterior_std=sigma_post_std,
        sigma_samples=sigma_post_samples,
        sigma_prior_mode=sigma_post_mode,
        eta_posterior_mean=eta_post_mean,
        eta_posterior_std=eta_post_std,
        robust_df=float(robust_df) if robust else None,
        outlier_mask=outlier_mask_arr,
        eta_samples=eta_samples_arr,
        volume_alpha=volume_alpha,
        prior_F_shape=prior_F_shape,
        prior_G_shape=prior_G_shape,
        mh_volume_acceptance_rate=vol_accept_rate,
        factor_activity_samples=factor_activity_arr,
        label_switch_gap=float(min_label_gap),
        convergence_details=convergence_details,
    )
