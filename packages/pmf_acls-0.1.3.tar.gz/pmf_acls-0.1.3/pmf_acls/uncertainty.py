"""
Bootstrap uncertainty estimation for PMF results.

This module provides tools for quantifying uncertainty in PMF factor
matrices F and G via bootstrap resampling methods.

Based on environmental PMF best practices and statistical bootstrap theory.
"""

from typing import Optional, List, Dict, Tuple
import warnings
import numpy as np
from scipy.linalg import orthogonal_procrustes

from .core import pmf
from .data_structures import PMFResult, UncertaintyResult, DisplacementResult


def bootstrap_uncertainty(
    X: np.ndarray,
    sigma: np.ndarray,
    p: int,
    base_result: Optional[PMFResult] = None,
    n_bootstrap: int = 100,
    method: str = "displacement",
    random_seed: Optional[int] = None,
    percentiles: Optional[List[int]] = None,
    align_factors: bool = True,
    verbose: bool = False,
    **pmf_kwargs,
) -> UncertaintyResult:
    """
    Estimate uncertainties in PMF solution via bootstrap resampling.

    This function generates bootstrap samples of the data, runs PMF on each,
    and aggregates the results to estimate uncertainties in F and G.

    Parameters
    ----------
    X : ndarray, shape (m, n)
        Data matrix.
    sigma : ndarray, shape (m, n)
        Uncertainties for each element of X.
    p : int
        Number of factors.
    base_result : PMFResult, optional
        Base PMF result to use as reference for alignment.
        If None, PMF will be run on original data first.
    n_bootstrap : int, default=100
        Number of bootstrap samples to generate.
    method : {'displacement', 'residual'}, default='displacement'
        Bootstrap sampling method:
        - 'displacement': Add random noise scaled by sigma
        - 'residual': Resample residuals from base fit
    random_seed : int, optional
        Random seed for reproducibility.
    percentiles : list of int, optional
        Percentiles to compute (e.g., [5, 95] for 90% CI).
        Default: [5, 25, 75, 95]
    align_factors : bool, default=True
        Whether to align bootstrap factors to base result using
        Procrustes rotation. Recommended to enable.
    verbose : bool, default=False
        Whether to print progress information.
    **pmf_kwargs : dict
        Additional parameters passed to pmf().

    Returns
    -------
    result : UncertaintyResult
        Object containing:
        - F_mean, G_mean: Mean factor matrices
        - F_std, G_std: Standard deviations
        - F_percentiles, G_percentiles: Requested percentiles
        - bootstrap_results: Individual PMFResult objects

    Notes
    -----
    Bootstrap Methods:

    1. **Displacement bootstrap** (recommended):
       Generate X_boot = X + ε, where ε ~ N(0, σ²)
       This approach is appropriate when uncertainties are well-calibrated.

    2. **Residual bootstrap**:
       Generate X_boot = F @ G + R_resampled
       where R_resampled is drawn from observed residuals.
       Appropriate when residuals are homoscedastic.

    Factor Alignment:

    Bootstrap solutions may have different factor orderings and scalings.
    When align_factors=True, each bootstrap solution is aligned to the
    base result using Procrustes rotation to minimize:
        ||F_base - F_boot @ Q||²
    where Q is an orthogonal rotation matrix.

    References
    ----------
    Efron, B., & Tibshirani, R. J. (1994). An introduction to the bootstrap.
    CRC press.

    Brown, S. G., et al. (2015). Methods for estimating uncertainty in PMF
    solutions. Atmospheric Measurement Techniques, 8(3), 1051-1061.

    Examples
    --------
    >>> import numpy as np
    >>> from pmf_acls import pmf, bootstrap_uncertainty
    >>>
    >>> # Generate synthetic data
    >>> m, n, p = 10, 20, 3
    >>> F_true = np.random.rand(m, p)
    >>> G_true = np.random.rand(p, n)
    >>> X = F_true @ G_true + 0.1 * np.random.randn(m, n)
    >>> sigma = 0.1 * np.ones_like(X)
    >>>
    >>> # Get base result
    >>> base = pmf(X, sigma, p=3)
    >>>
    >>> # Estimate uncertainties
    >>> unc = bootstrap_uncertainty(
    ...     X, sigma, p=3,
    ...     base_result=base,
    ...     n_bootstrap=100,
    ...     random_seed=42
    ... )
    >>> print(f"Mean relative uncertainty: {np.mean(unc.F_std / unc.F_mean):.2%}")
    """
    # Set default percentiles
    if percentiles is None:
        percentiles = [5, 25, 75, 95]

    # Validate inputs
    if n_bootstrap < 1:
        raise ValueError("n_bootstrap must be at least 1")
    if method not in ["displacement", "residual"]:
        raise ValueError(f"method must be 'displacement' or 'residual', got '{method}'")

    m, n = X.shape

    # Get base result if not provided
    if base_result is None:
        if verbose:
            print("Running PMF on original data to get base result...")
        base_result = pmf(X, sigma, p=p, verbose=verbose, **pmf_kwargs)

    F_base = base_result.F
    G_base = base_result.G

    # Set up random number generator
    if random_seed is not None:
        rng = np.random.RandomState(random_seed)
    else:
        rng = np.random.RandomState()

    # Storage for bootstrap results
    bootstrap_results = []
    F_samples = []
    G_samples = []

    if verbose:
        print(f"\nRunning {n_bootstrap} bootstrap samples...")
        print(f"Method: {method}")
        print(f"Factor alignment: {'enabled' if align_factors else 'disabled'}")
        print("=" * 60)

    # Run bootstrap iterations
    for i in range(n_bootstrap):
        # Generate bootstrap sample
        if method == "displacement":
            # Displacement bootstrap: X + N(0, sigma^2)
            noise = rng.randn(m, n) * sigma
            X_boot = X + noise
            sigma_boot = sigma.copy()

        elif method == "residual":
            # Residual bootstrap: GF + resampled residuals
            residuals = base_result.residuals
            # Flatten residuals and sample with replacement
            residuals_flat = residuals.flatten()
            resampled_flat = rng.choice(residuals_flat, size=m*n, replace=True)
            resampled = resampled_flat.reshape(m, n)
            X_boot = F_base @ G_base + resampled
            sigma_boot = sigma.copy()

        # Run PMF on bootstrap sample
        try:
            result_boot = pmf(
                X_boot, sigma_boot, p=p,
                verbose=False,  # Suppress individual run output
                **pmf_kwargs
            )

            F_boot = result_boot.F.copy()
            G_boot = result_boot.G.copy()

            # Align factors to base result if requested
            if align_factors:
                F_boot, G_boot = align_factors_procrustes(
                    F_base, G_base, F_boot, G_boot
                )

            F_samples.append(F_boot)
            G_samples.append(G_boot)
            bootstrap_results.append(result_boot)

            if verbose and (i + 1) % max(1, n_bootstrap // 10) == 0:
                print(f"  Completed {i + 1}/{n_bootstrap} bootstrap samples")

        except Exception as e:
            warnings.warn(
                f"Bootstrap sample {i+1}/{n_bootstrap} failed: {e}. Skipping."
            )
            continue

    if verbose:
        print("=" * 60)
        print(f"Successfully completed {len(F_samples)}/{n_bootstrap} bootstrap samples")

    if len(F_samples) == 0:
        raise RuntimeError(
            "All bootstrap samples failed. Cannot estimate uncertainties."
        )

    if len(F_samples) < n_bootstrap * 0.5:
        warnings.warn(
            f"Only {len(F_samples)}/{n_bootstrap} bootstrap samples succeeded. "
            f"Uncertainty estimates may be unreliable."
        )

    # Convert lists to arrays for easier computation
    F_samples = np.array(F_samples)  # Shape: (n_boot, m, p)
    G_samples = np.array(G_samples)  # Shape: (n_boot, p, n)

    # Compute statistics
    F_mean = np.mean(F_samples, axis=0)
    F_std = np.std(F_samples, axis=0, ddof=1)
    G_mean = np.mean(G_samples, axis=0)
    G_std = np.std(G_samples, axis=0, ddof=1)

    # Compute percentiles if requested
    G_percentiles_dict = {}
    F_percentiles_dict = {}
    if percentiles:
        for pct in percentiles:
            G_percentiles_dict[pct] = np.percentile(F_samples, pct, axis=0)
            F_percentiles_dict[pct] = np.percentile(G_samples, pct, axis=0)

    if verbose:
        avg_rel_unc_F = np.mean(F_std / (F_mean + 1e-10))
        avg_rel_unc_G = np.mean(G_std / (G_mean + 1e-10))
        print(f"\nUncertainty Summary:")
        print(f"  Average relative uncertainty (F): {avg_rel_unc_F:.2%}")
        print(f"  Average relative uncertainty (G): {avg_rel_unc_G:.2%}")

    return UncertaintyResult(
        F_mean=F_mean,
        F_std=F_std,
        G_mean=G_mean,
        G_std=G_std,
        bootstrap_results=bootstrap_results,
        F_percentiles=G_percentiles_dict,
        G_percentiles=F_percentiles_dict,
    )


def align_factors_procrustes(
    F_base: np.ndarray,
    G_base: np.ndarray,
    F_boot: np.ndarray,
    G_boot: np.ndarray,
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Align bootstrap factors to base factors using Procrustes rotation.

    The Procrustes problem finds an orthogonal matrix Q that minimizes:
        ||F_base - F_boot @ Q||²

    After finding Q, we apply:
        F_aligned = F_boot @ Q
        G_aligned = Q^T @ G_boot

    This preserves the factorization: F_aligned @ G_aligned = F_boot @ G_boot

    Parameters
    ----------
    F_base : ndarray, shape (m, p)
        Base F matrix (reference)
    G_base : ndarray, shape (p, n)
        Base G matrix (reference)
    F_boot : ndarray, shape (m, p)
        Bootstrap F matrix to align
    G_boot : ndarray, shape (p, n)
        Bootstrap G matrix to align

    Returns
    -------
    F_aligned : ndarray, shape (m, p)
        Aligned F matrix
    G_aligned : ndarray, shape (p, n)
        Aligned G matrix

    Notes
    -----
    This function uses scipy.linalg.orthogonal_procrustes to find the
    optimal rotation matrix Q.

    References
    ----------
    Schönemann, P. H. (1966). A generalized solution of the orthogonal
    Procrustes problem. Psychometrika, 31(1), 1-10.
    """
    # Find optimal rotation matrix Q
    # orthogonal_procrustes solves: min ||A - B @ Q||²
    # We want: min ||F_base - F_boot @ Q||²
    Q, _ = orthogonal_procrustes(F_boot, F_base)

    # Apply rotation
    F_aligned = F_boot @ Q
    G_aligned = Q.T @ G_boot

    return F_aligned, G_aligned


def multistart_test(
    X: np.ndarray,
    sigma: np.ndarray,
    p: int,
    base_result: Optional[PMFResult] = None,
    n_displacements: int = 20,
    displacement_factor: float = 1.0,
    random_seed: Optional[int] = None,
    verbose: bool = False,
    **pmf_kwargs,
) -> Dict:
    """
    Test solution stability via multiple random starts.

    Explores sensitivity to initial conditions by running PMF
    multiple times with different random initializations.

    Parameters
    ----------
    X : ndarray, shape (m, n)
        Data matrix.
    sigma : ndarray, shape (m, n)
        Uncertainties.
    p : int
        Number of factors.
    base_result : PMFResult, optional
        Base result for comparison.
    n_displacements : int, default=20
        Number of random starts to test.
    displacement_factor : float, default=1.0
        Scale factor for random displacement (1.0 = standard range).
    random_seed : int, optional
        Random seed for reproducibility.
    verbose : bool, default=False
        Whether to print progress.
    **pmf_kwargs : dict
        Additional parameters for pmf().

    Returns
    -------
    results : dict
        Dictionary with keys:
        - 'Q_values': list of final Q values
        - 'Q_min': minimum Q achieved
        - 'Q_max': maximum Q achieved
        - 'Q_range': max - min
        - 'all_results': list of PMFResult objects

    Notes
    -----
    A stable solution should have small Q_range, indicating that
    different initializations converge to similar solutions.

    Large Q_range suggests multiple local minima or ill-conditioned problem.
    """
    if random_seed is not None:
        rng = np.random.RandomState(random_seed)
        seeds = [rng.randint(0, 2**31 - 1) for _ in range(n_displacements)]
    else:
        seeds = [None] * n_displacements

    Q_values = []
    all_results = []

    if verbose:
        print(f"Running multistart test with {n_displacements} random starts...")

    for i, seed in enumerate(seeds):
        try:
            result = pmf(
                X, sigma, p=p,
                random_seed=seed,
                verbose=False,
                **pmf_kwargs
            )
            Q_values.append(result.Q)
            all_results.append(result)

            if verbose and (i + 1) % max(1, n_displacements // 10) == 0:
                print(f"  Completed {i + 1}/{n_displacements}")

        except Exception as e:
            warnings.warn(f"Multistart run {i+1} failed: {e}. Skipping.")
            continue

    if len(Q_values) == 0:
        raise RuntimeError("All multistart runs failed.")

    Q_min = np.min(Q_values)
    Q_max = np.max(Q_values)
    Q_range = Q_max - Q_min

    if verbose:
        print(f"\nMultistart Test Results:")
        print(f"  Q range: {Q_min:.4e} to {Q_max:.4e}")
        print(f"  Q range: {Q_range:.4e} ({Q_range/Q_min*100:.1f}% of min)")
        if Q_range / Q_min < 0.01:
            print("  -> Solution appears stable")
        elif Q_range / Q_min < 0.1:
            print("  -> Solution moderately stable")
        else:
            print("  -> Warning: Large variability in solutions")

    return {
        'Q_values': Q_values,
        'Q_min': Q_min,
        'Q_max': Q_max,
        'Q_range': Q_range,
        'all_results': all_results,
    }


def _compute_Q(
    X: np.ndarray,
    F: np.ndarray,
    G: np.ndarray,
    sigma: np.ndarray,
) -> float:
    """Compute the PMF Q objective: sum((X - F @ G)^2 / sigma^2)."""
    R = X - F @ G
    return float(np.sum((R / sigma) ** 2))


def _detect_factor_swaps(
    G_base: np.ndarray,
    F_displaced: np.ndarray,
) -> bool:
    """
    Detect if factors swapped order after re-optimization.

    Builds a p x p R^2 correlation matrix between base and displaced
    factor profiles. If any factor's best match is off-diagonal,
    a swap occurred.
    """
    p = G_base.shape[0]
    corr_matrix = np.zeros((p, p))
    for i in range(p):
        for j in range(p):
            std_i = np.std(G_base[i])
            std_j = np.std(F_displaced[j])
            if std_i > 1e-12 and std_j > 1e-12:
                corr = np.corrcoef(G_base[i], F_displaced[j])[0, 1]
                corr_matrix[i, j] = corr ** 2
            else:
                corr_matrix[i, j] = 0.0

    for i in range(p):
        if np.argmax(corr_matrix[i]) != i:
            return True
    return False


def _find_upper_bound(
    X: np.ndarray,
    F: np.ndarray,
    G_base: np.ndarray,
    sigma: np.ndarray,
    Q_base: float,
    factor_idx: int,
    feature_idx: int,
    dQ_max: float,
    max_search: int = 100,
) -> Tuple[float, bool]:
    """Find an upper-bound modifier m such that Q(G with G[i,j]*m) > Q_base + dQ_max.

    Returns (high_modifier, found).
    """
    high_modifier = 2.0
    f_ij = G_base[factor_idx, feature_idx]
    for _ in range(max_search):
        F_trial = G_base.copy()
        F_trial[factor_idx, feature_idx] = f_ij * high_modifier
        dQ = _compute_Q(X, F, F_trial, sigma) - Q_base
        if dQ >= dQ_max:
            return high_modifier, True
        high_modifier *= 2.0
    return high_modifier, False


def _binary_search_displacement_one_direction(
    X: np.ndarray,
    F: np.ndarray,
    G_base: np.ndarray,
    sigma: np.ndarray,
    Q_base: float,
    factor_idx: int,
    feature_idx: int,
    dQ_sorted: List[float],
    direction: str,
    max_bisect_iter: int = 50,
    dQ_tol: float = 0.1,
) -> Dict[float, Tuple[float, float, bool]]:
    """
    Binary search for modifiers that cause Q to increase by each dQ threshold.

    Matches ESAT's approach:
    - Q is evaluated with modified G and fixed F (no re-optimization during search)
    - dQ thresholds are searched in descending order, reusing the narrowed
      high_modifier from the previous threshold
    - Returns the displaced G[i,j] value (= base * modifier) for each dQ

    Parameters
    ----------
    dQ_sorted : list of float
        dQ thresholds sorted descending (e.g. [32, 16, 8, 4]).
    direction : str
        "increase" or "decrease".

    Returns
    -------
    results : dict
        {dQ: (displaced_value, achieved_dQ, converged)} for each threshold.
    """
    f_ij = G_base[factor_idx, feature_idx]
    results = {}

    if direction == "increase":
        # Find upper bound modifier where Q exceeds largest dQ
        high_modifier, found = _find_upper_bound(
            X, F, G_base, sigma, Q_base, factor_idx, feature_idx,
            dQ_sorted[0], max_search=100,
        )
        if not found:
            for dq in dQ_sorted:
                results[dq] = (f_ij * high_modifier, 0.0, False)
            return results

        # Search each dQ in descending order, narrowing high_modifier
        for dq in dQ_sorted:
            low_modifier = 1.0
            modifier = (high_modifier + low_modifier) / 2.0
            converged = False
            achieved_dQ = 0.0
            for _ in range(max_bisect_iter):
                F_trial = G_base.copy()
                F_trial[factor_idx, feature_idx] = f_ij * modifier
                dQ = _compute_Q(X, F, F_trial, sigma) - Q_base
                achieved_dQ = dQ
                if dQ > dq:
                    high_modifier = modifier
                    modifier = (modifier + low_modifier) / 2.0
                elif dQ < dq - dQ_tol:
                    low_modifier = modifier
                    modifier = (high_modifier + modifier) / 2.0
                else:
                    converged = True
                    break
            results[dq] = (f_ij * modifier, achieved_dQ, converged)

    else:  # decrease
        # For decrease, modifier goes from 1.0 toward 0.0
        # Find lower bound: modifier=0 gives G[i,j]=0, check if dQ > largest dQ
        F_trial = G_base.copy()
        F_trial[factor_idx, feature_idx] = 0.0
        max_dQ = _compute_Q(X, F, F_trial, sigma) - Q_base
        if max_dQ < dQ_sorted[0] - dQ_tol:
            # Even setting to 0 doesn't reach largest dQ threshold
            # Still search what we can
            pass

        low_modifier = 0.0  # maps to G[i,j]=0
        # Search each dQ in descending order
        for dq in dQ_sorted:
            high_modifier = 1.0  # maps to base value (no change)
            modifier = (high_modifier + low_modifier) / 2.0
            converged = False
            achieved_dQ = 0.0
            for _ in range(max_bisect_iter):
                F_trial = G_base.copy()
                new_val = f_ij * modifier
                if new_val < 1e-12:
                    new_val = 0.0
                F_trial[factor_idx, feature_idx] = new_val
                dQ = _compute_Q(X, F, F_trial, sigma) - Q_base
                achieved_dQ = dQ
                if dQ > dq:
                    # Too much displacement, move modifier toward 1
                    low_modifier = modifier
                    modifier = (high_modifier + modifier) / 2.0
                elif dQ < dq - dQ_tol:
                    # Not enough displacement, move modifier toward 0
                    high_modifier = modifier
                    modifier = (modifier + low_modifier) / 2.0
                else:
                    converged = True
                    break
            results[dq] = (f_ij * modifier, achieved_dQ, converged)

    return results


def displacement_test(
    X: np.ndarray,
    sigma: np.ndarray,
    p: int,
    base_result: Optional[PMFResult] = None,
    dQ_thresholds: Optional[List[float]] = None,
    features: Optional[List[int]] = None,
    feature_labels: Optional[List[str]] = None,
    max_bisect_iter: int = 50,
    dQ_tol: float = 0.1,
    verbose: bool = False,
    **pmf_kwargs,
) -> DisplacementResult:
    """
    DISP error estimation for PMF solutions.

    Matches ESAT's DISP algorithm: for each element G[i,j], binary-search
    for a multiplicative modifier m such that Q(F_base, F_modified) increases
    by dQ_max, with F held fixed during the search. After finding the
    boundary value, re-optimize the full model to detect factor swaps.

    Parameters
    ----------
    X : ndarray, shape (m, n)
        Data matrix.
    sigma : ndarray, shape (m, n)
        Uncertainty matrix.
    p : int
        Number of factors.
    base_result : PMFResult, optional
        Base PMF solution. If None, one will be computed.
    dQ_thresholds : list of float, optional
        dQ_max values to test. Default: [4, 8, 16, 32].
    features : list of int, optional
        Indices of features to test. Default: all features.
    feature_labels : list of str, optional
        Labels for features. Default: F0, F1, ...
    max_bisect_iter : int, default=50
        Maximum binary search iterations per element.
    dQ_tol : float, default=0.1
        Tolerance window for dQ matching.
    verbose : bool, default=False
        Print progress.
    **pmf_kwargs
        Additional kwargs passed to pmf() for swap-detection re-training.

    Returns
    -------
    DisplacementResult
        Contains G_min, G_max, swap_counts for each dQ threshold.
    """
    if dQ_thresholds is None:
        dQ_thresholds = [4.0, 8.0, 16.0, 32.0]

    # Get or compute base result
    if base_result is None:
        if verbose:
            print("Computing base PMF solution...")
        base_result = pmf(X, sigma, p=p, verbose=verbose, **pmf_kwargs)

    F_base = base_result.F
    G_base = base_result.G
    Q_base = base_result.Q
    n_factors, n_features = G_base.shape

    feature_indices = features if features is not None else list(range(n_features))

    # Sort thresholds descending for nested binary search (like ESAT)
    dQ_sorted = sorted(dQ_thresholds, reverse=True)

    if verbose:
        print(f"DISP: {n_factors} factors x {len(feature_indices)} features")
        print(f"Q_base = {Q_base:.4e}")
        print(f"dQ thresholds: {dQ_thresholds}")

    # Initialize result containers
    G_min = {}
    G_max = {}
    swap_counts = {}
    converged_map = {}

    for dq in dQ_thresholds:
        G_min[dq] = G_base.copy()
        G_max[dq] = G_base.copy()
        swap_counts[dq] = np.zeros((n_factors, n_features), dtype=int)
        converged_map[dq] = np.ones((n_factors, n_features), dtype=bool)

    # Main loop: for each factor and feature
    for i in range(n_factors):
        for j in feature_indices:
            if verbose:
                print(f"  Factor {i + 1}/{n_factors}, "
                      f"Feature {j + 1}/{n_features}")

            # Increase direction — all dQ thresholds in one pass
            inc_results = _binary_search_displacement_one_direction(
                X, F_base, G_base, sigma, Q_base,
                i, j, dQ_sorted, direction="increase",
                max_bisect_iter=max_bisect_iter,
                dQ_tol=dQ_tol,
            )

            # Decrease direction — all dQ thresholds in one pass
            dec_results = _binary_search_displacement_one_direction(
                X, F_base, G_base, sigma, Q_base,
                i, j, dQ_sorted, direction="decrease",
                max_bisect_iter=max_bisect_iter,
                dQ_tol=dQ_tol,
            )

            # Store results and do swap detection via re-training
            for dq in dQ_thresholds:
                val_up, _, conv_up = inc_results[dq]
                val_down, _, conv_down = dec_results[dq]

                G_max[dq][i, j] = val_up
                G_min[dq][i, j] = val_down
                converged_map[dq][i, j] = conv_up and conv_down

                # Swap detection: re-train with displaced G, compare re-trained
                # factors against base (matches ESAT's approach)
                swap_up = False
                swap_down = False
                for val, direction_label in [(val_up, "up"), (val_down, "down")]:
                    F_disp = G_base.copy()
                    F_disp[i, j] = val
                    try:
                        result = pmf(
                            X, sigma, p=p,
                            F_init=F_base.copy(),
                            G_init=F_disp,
                            verbose=False,
                            **pmf_kwargs,
                        )
                        if _detect_factor_swaps(G_base, result.G):
                            if direction_label == "up":
                                swap_up = True
                            else:
                                swap_down = True
                    except Exception:
                        pass

                swap_counts[dq][i, j] = int(swap_up) + int(swap_down)

    return DisplacementResult(
        G_base=G_base,
        G_min=G_min,
        G_max=G_max,
        dQ_thresholds=dQ_thresholds,
        swap_counts=swap_counts,
        Q_base=Q_base,
        converged=converged_map,
        feature_labels=feature_labels,
    )


# ---------------------------------------------------------------------------
# ESAT-style class wrappers
# ---------------------------------------------------------------------------

class Bootstrap:
    """
    ESAT-style Bootstrap error estimation for PMF solutions.

    Wraps :func:`bootstrap_uncertainty` with a stateful, class-based API.

    Parameters
    ----------
    base_result : PMFResult
        Base PMF solution to bootstrap around.
    X : ndarray, shape (m, n)
        Data matrix.
    sigma : ndarray, shape (m, n)
        Uncertainty matrix.
    feature_labels : list of str, optional
        Labels for features. Default: F0, F1, ...
    n_bootstrap : int, default=100
        Number of bootstrap samples.
    method : {'displacement', 'residual'}, default='displacement'
        Bootstrap sampling method.
    random_seed : int, optional
        Random seed for reproducibility.
    **pmf_kwargs
        Additional kwargs passed to pmf().
    """

    def __init__(
        self,
        base_result: PMFResult,
        X: np.ndarray,
        sigma: np.ndarray,
        feature_labels: Optional[List[str]] = None,
        n_bootstrap: int = 100,
        method: str = "displacement",
        random_seed: Optional[int] = None,
        **pmf_kwargs,
    ):
        self.base_result = base_result
        self.X = X
        self.sigma = sigma
        self.n_bootstrap = n_bootstrap
        self.method = method
        self.random_seed = random_seed
        self.pmf_kwargs = pmf_kwargs
        self.p = base_result.G.shape[0]
        n_features = X.shape[1]
        self.feature_labels = feature_labels or [f"F{j}" for j in range(n_features)]
        self.result: Optional[UncertaintyResult] = None

    def run(self, verbose: bool = False) -> "Bootstrap":
        """Execute bootstrap resampling."""
        self.result = bootstrap_uncertainty(
            self.X, self.sigma, p=self.p,
            base_result=self.base_result,
            n_bootstrap=self.n_bootstrap,
            method=self.method,
            random_seed=self.random_seed,
            verbose=verbose,
            **self.pmf_kwargs,
        )
        return self

    def summary(self) -> None:
        """Print bootstrap uncertainty summary."""
        if self.result is None:
            print("No results. Call .run() first.")
            return
        self.result.summary()

    def plot_factor(self, factor: int) -> "matplotlib.figure.Figure":
        """
        Box plot of bootstrap G profiles for a single factor.

        Parameters
        ----------
        factor : int
            Factor index (0-based).

        Returns
        -------
        fig : matplotlib Figure
        """
        import matplotlib.pyplot as plt

        if self.result is None:
            raise RuntimeError("No results. Call .run() first.")

        G_samples = np.array([r.G for r in self.result.bootstrap_results])
        factor_data = G_samples[:, factor, :]  # (n_bootstrap, n_features)

        fig, ax = plt.subplots(figsize=(max(8, len(self.feature_labels) * 0.5), 5))
        bp = ax.boxplot(factor_data, tick_labels=self.feature_labels)
        ax.plot(range(1, len(self.feature_labels) + 1),
                self.base_result.G[factor, :],
                'r^', markersize=8, label='Base')
        ax.set_title(f"Bootstrap Factor {factor + 1} Profile")
        ax.set_ylabel("Value")
        ax.legend()
        ax.tick_params(axis='x', rotation=45)
        fig.tight_layout()
        return fig

    def plot_results(self, factor: int) -> "matplotlib.figure.Figure":
        """
        Two-panel plot: profile box plots + contribution box plots.

        Parameters
        ----------
        factor : int
            Factor index (0-based).

        Returns
        -------
        fig : matplotlib Figure
        """
        import matplotlib.pyplot as plt

        if self.result is None:
            raise RuntimeError("No results. Call .run() first.")

        G_samples = np.array([r.G for r in self.result.bootstrap_results])
        F_samples = np.array([r.F for r in self.result.bootstrap_results])

        fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(max(8, len(self.feature_labels) * 0.5), 10))

        # Profile box plots
        factor_profiles = G_samples[:, factor, :]
        ax1.boxplot(factor_profiles, tick_labels=self.feature_labels)
        ax1.plot(range(1, len(self.feature_labels) + 1),
                 self.base_result.G[factor, :],
                 'r^', markersize=8, label='Base')
        ax1.set_title(f"Factor {factor + 1} Profile")
        ax1.set_ylabel("Value")
        ax1.legend()
        ax1.tick_params(axis='x', rotation=45)

        # Contribution box plots (F[:, factor] * G[factor, :] per feature)
        contributions = F_samples[:, :, factor]  # (n_bootstrap, m)
        ax2.boxplot(contributions)
        ax2.plot(range(1, self.X.shape[0] + 1),
                 self.base_result.F[:, factor],
                 'r^', markersize=8, label='Base')
        ax2.set_title(f"Factor {factor + 1} Contributions (F)")
        ax2.set_ylabel("Value")
        ax2.set_xlabel("Sample")
        ax2.legend()

        fig.tight_layout()
        return fig


class Displacement:
    """
    ESAT-style Displacement (DISP) error estimation for PMF solutions.

    Wraps :func:`displacement_test` with a stateful, class-based API.

    Parameters
    ----------
    base_result : PMFResult
        Base PMF solution.
    X : ndarray, shape (m, n)
        Data matrix.
    sigma : ndarray, shape (m, n)
        Uncertainty matrix.
    feature_labels : list of str, optional
        Labels for features. Default: F0, F1, ...
    features : list of int, optional
        Indices of features to test. Default: all.
    dQ_thresholds : list of float, optional
        dQ_max thresholds. Default: [4, 8, 16, 32].
    max_bisect_iter : int, default=50
        Maximum binary search iterations.
    dQ_tol : float, default=0.1
        Tolerance window for dQ matching.
    **pmf_kwargs
        Additional kwargs passed to pmf().
    """

    def __init__(
        self,
        base_result: PMFResult,
        X: np.ndarray,
        sigma: np.ndarray,
        feature_labels: Optional[List[str]] = None,
        features: Optional[List[int]] = None,
        dQ_thresholds: Optional[List[float]] = None,
        max_bisect_iter: int = 50,
        dQ_tol: float = 0.1,
        **pmf_kwargs,
    ):
        self.base_result = base_result
        self.X = X
        self.sigma = sigma
        n_features = X.shape[1]
        self.feature_labels = feature_labels or [f"F{j}" for j in range(n_features)]
        self.features = features
        self.dQ_thresholds = dQ_thresholds or [4.0, 8.0, 16.0, 32.0]
        self.max_bisect_iter = max_bisect_iter
        self.dQ_tol = dQ_tol
        self.pmf_kwargs = pmf_kwargs
        self.p = base_result.G.shape[0]
        self.result: Optional[DisplacementResult] = None

    def run(self, verbose: bool = False) -> "Displacement":
        """Execute DISP analysis."""
        self.result = displacement_test(
            self.X, self.sigma, p=self.p,
            base_result=self.base_result,
            dQ_thresholds=self.dQ_thresholds,
            features=self.features,
            feature_labels=self.feature_labels,
            max_bisect_iter=self.max_bisect_iter,
            dQ_tol=self.dQ_tol,
            verbose=verbose,
            **self.pmf_kwargs,
        )
        return self

    def summary(self) -> None:
        """Print DISP summary with swap table."""
        if self.result is None:
            print("No results. Call .run() first.")
            return
        self.result.summary()

    def plot_profile(self, factor: int, dQ: float = 4.0) -> "matplotlib.figure.Figure":
        """
        Bar chart of factor profile with DISP uncertainty ranges.

        Parameters
        ----------
        factor : int
            Factor index (0-based).
        dQ : float, default=4.0
            dQ threshold to plot.

        Returns
        -------
        fig : matplotlib Figure
        """
        import matplotlib.pyplot as plt

        if self.result is None:
            raise RuntimeError("No results. Call .run() first.")

        G_base = self.result.G_base[factor, :]
        F_lo = self.result.G_min[dQ][factor, :]
        F_hi = self.result.G_max[dQ][factor, :]

        x = np.arange(len(self.feature_labels))
        yerr_lo = np.maximum(G_base - F_lo, 0)
        yerr_hi = np.maximum(F_hi - G_base, 0)
        fig, ax = plt.subplots(figsize=(max(8, len(self.feature_labels) * 0.5), 5))
        ax.bar(x, G_base, color='steelblue', alpha=0.7, label='Base')
        ax.errorbar(x, G_base, yerr=[yerr_lo, yerr_hi],
                     fmt='none', ecolor='black', capsize=3, label=f'DISP dQ={dQ}')
        ax.set_xticks(x)
        ax.set_xticklabels(self.feature_labels, rotation=45, ha='right')
        ax.set_title(f"Factor {factor + 1} Profile (DISP dQ={dQ})")
        ax.set_ylabel("Value")
        ax.legend()
        fig.tight_layout()
        return fig

    def plot_contribution(self, factor: int, dQ: float = 4.0) -> "matplotlib.figure.Figure":
        """
        Bar chart of factor contribution with DISP-derived ranges.

        Contribution for feature j = sum(F[:, factor]) * G[factor, j].

        Parameters
        ----------
        factor : int
            Factor index (0-based).
        dQ : float, default=4.0
            dQ threshold.

        Returns
        -------
        fig : matplotlib Figure
        """
        import matplotlib.pyplot as plt

        if self.result is None:
            raise RuntimeError("No results. Call .run() first.")

        g_sum = np.sum(self.base_result.F[:, factor])
        conc_base = g_sum * self.result.G_base[factor, :]
        conc_lo = g_sum * self.result.G_min[dQ][factor, :]
        conc_hi = g_sum * self.result.G_max[dQ][factor, :]

        x = np.arange(len(self.feature_labels))
        yerr_lo = np.maximum(conc_base - conc_lo, 0)
        yerr_hi = np.maximum(conc_hi - conc_base, 0)
        fig, ax = plt.subplots(figsize=(max(8, len(self.feature_labels) * 0.5), 5))
        ax.bar(x, conc_base, color='darkorange', alpha=0.7, label='Base')
        ax.errorbar(x, conc_base, yerr=[yerr_lo, yerr_hi],
                     fmt='none', ecolor='black', capsize=3, label=f'DISP dQ={dQ}')
        ax.set_xticks(x)
        ax.set_xticklabels(self.feature_labels, rotation=45, ha='right')
        ax.set_title(f"Factor {factor + 1} Contribution (DISP dQ={dQ})")
        ax.set_ylabel("Concentration")
        ax.legend()
        fig.tight_layout()
        return fig

    def plot_results(self, factor: int, dQ: float = 4.0) -> "matplotlib.figure.Figure":
        """
        Two-panel plot: profile + contribution with DISP ranges.

        Parameters
        ----------
        factor : int
            Factor index (0-based).
        dQ : float, default=4.0
            dQ threshold.

        Returns
        -------
        fig : matplotlib Figure
        """
        import matplotlib.pyplot as plt

        if self.result is None:
            raise RuntimeError("No results. Call .run() first.")

        G_base = self.result.G_base[factor, :]
        F_lo = self.result.G_min[dQ][factor, :]
        F_hi = self.result.G_max[dQ][factor, :]
        g_sum = np.sum(self.base_result.F[:, factor])
        conc_base = g_sum * G_base
        conc_lo = g_sum * F_lo
        conc_hi = g_sum * F_hi

        x = np.arange(len(self.feature_labels))
        fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(max(8, len(self.feature_labels) * 0.5), 10))

        # Profile
        yerr_lo_f = np.maximum(G_base - F_lo, 0)
        yerr_hi_f = np.maximum(F_hi - G_base, 0)
        ax1.bar(x, G_base, color='steelblue', alpha=0.7, label='Base')
        ax1.errorbar(x, G_base, yerr=[yerr_lo_f, yerr_hi_f],
                      fmt='none', ecolor='black', capsize=3, label=f'DISP dQ={dQ}')
        ax1.set_xticks(x)
        ax1.set_xticklabels(self.feature_labels, rotation=45, ha='right')
        ax1.set_title(f"Factor {factor + 1} Profile (DISP dQ={dQ})")
        ax1.set_ylabel("Value")
        ax1.legend()

        # Contribution
        yerr_lo_c = np.maximum(conc_base - conc_lo, 0)
        yerr_hi_c = np.maximum(conc_hi - conc_base, 0)
        ax2.bar(x, conc_base, color='darkorange', alpha=0.7, label='Base')
        ax2.errorbar(x, conc_base, yerr=[yerr_lo_c, yerr_hi_c],
                      fmt='none', ecolor='black', capsize=3, label=f'DISP dQ={dQ}')
        ax2.set_xticks(x)
        ax2.set_xticklabels(self.feature_labels, rotation=45, ha='right')
        ax2.set_title(f"Factor {factor + 1} Contribution (DISP dQ={dQ})")
        ax2.set_ylabel("Concentration")
        ax2.legend()

        fig.tight_layout()
        return fig
