"""
Bayesian convergence diagnostics and model comparison.

Provides MCMC diagnostics (effective sample size, Gelman-Rubin Rhat)
and model comparison (WAIC) for Bayesian NMF/LDA results.

References
----------
Geyer, C. J. (1992).
    Practical Markov chain Monte Carlo. Statistical Science, 7(4), 473-483.

Gelman, A. & Rubin, D. B. (1992).
    Inference from iterative simulation using multiple sequences.
    Statistical Science, 7(4), 457-472.

Watanabe, S. (2010).
    Asymptotic equivalence of Bayes cross validation and widely applicable
    information criterion in singular learning theory.
    JMLR, 11, 3571-3594.
"""

from __future__ import annotations

import numpy as np
from scipy.special import logsumexp


# ---------------------------------------------------------------------------
# MCMC convergence diagnostics
# ---------------------------------------------------------------------------


def effective_sample_size(trace: np.ndarray) -> float:
    """
    Effective sample size via initial positive sequence estimator (Geyer 1992).

    Uses FFT-based autocorrelation and sums consecutive pairs of
    autocorrelations until the first negative pair sum.

    Parameters
    ----------
    trace : ndarray, shape (n_samples,)
        MCMC trace (e.g., Q_samples from BayesNMFResult).

    Returns
    -------
    ess : float
        Effective sample size.  Values close to len(trace) indicate
        low autocorrelation; values << len(trace) suggest thinning
        or longer chains are needed.
    """
    trace = np.asarray(trace, dtype=float).ravel()
    n = len(trace)
    if n < 4:
        return float(n)

    x = trace - trace.mean()

    # FFT-based autocorrelation (zero-padded to avoid wrap-around)
    fft_len = 2 * n
    fft_x = np.fft.fft(x, n=fft_len)
    acf = np.real(np.fft.ifft(fft_x * np.conj(fft_x)))[:n]
    if acf[0] < 1e-30:
        return float(n)  # constant trace
    acf /= acf[0]

    # Initial positive sequence estimator: sum consecutive pairs of
    # autocorrelations until a pair sums to negative.
    running_sum = 0.0
    for i in range(1, n - 1, 2):
        pair_sum = acf[i] + (acf[i + 1] if i + 1 < n else 0.0)
        if pair_sum < 0:
            break
        running_sum += pair_sum

    tau = 1.0 + 2.0 * running_sum
    return max(n / tau, 1.0)


def gelman_rubin(*chains: np.ndarray) -> float:
    """
    Gelman-Rubin potential scale reduction factor (Rhat).

    Compares between-chain and within-chain variance to assess
    convergence of multiple independent MCMC chains.

    Parameters
    ----------
    *chains : ndarray, each shape (n_samples,)
        Two or more MCMC traces from independent chains
        (e.g., Q_samples from separate pmf_bayes runs with
        different random_seed values).

    Returns
    -------
    rhat : float
        Potential scale reduction factor.  Values < 1.05 suggest
        convergence; values > 1.1 indicate the chains have not mixed.

    Raises
    ------
    ValueError
        If fewer than 2 chains are provided.
    """
    m = len(chains)
    if m < 2:
        raise ValueError("gelman_rubin requires at least 2 chains")

    n = min(len(c) for c in chains)
    if n < 2:
        return float("inf")

    chain_means = np.array([np.mean(np.asarray(c, dtype=float)[:n]) for c in chains])
    chain_vars = np.array(
        [np.var(np.asarray(c, dtype=float)[:n], ddof=1) for c in chains]
    )

    B = n * np.var(chain_means, ddof=1)  # between-chain variance
    W = float(np.mean(chain_vars))  # within-chain variance

    if W < 1e-30:
        return 1.0 if B < 1e-30 else float("inf")

    var_hat = (1.0 - 1.0 / n) * W + (1.0 / n) * B
    return float(np.sqrt(var_hat / W))


# ---------------------------------------------------------------------------
# Model comparison
# ---------------------------------------------------------------------------


def compute_waic(
    X: np.ndarray,
    sigma: np.ndarray,
    F_samples: np.ndarray,
    G_samples: np.ndarray,
    likelihood: str = "gaussian",
) -> dict:
    """
    Widely Applicable Information Criterion (Watanabe 2010).

    Computed from stored posterior samples.  Requires ``store_samples=True``
    when running :func:`pmf_bayes` or :func:`pmf_lda`.

    Lower WAIC is better (analogous to AIC/BIC).  Comparing WAIC across
    different values of *p* gives a principled Bayesian model selection
    criterion for the number of factors.

    Parameters
    ----------
    X : ndarray, shape (m, n)
        Data matrix.
    sigma : ndarray, shape (m, n)
        Per-element uncertainties.
    F_samples : ndarray, shape (S, m, p)
        Posterior samples of F.
    G_samples : ndarray, shape (S, p, n)
        Posterior samples of G.
    likelihood : {'gaussian', 'lognormal'}, default='gaussian'
        Noise model.  Must match the likelihood used when fitting.

    Returns
    -------
    dict with keys:
        ``'waic'``
            WAIC value.  Lower is better.
        ``'lppd'``
            Log pointwise predictive density.
        ``'p_waic'``
            Effective number of parameters (model complexity penalty).
        ``'se'``
            Standard error of the WAIC estimate (useful for comparing
            models: differences within 1–2 SE are not significant).
        ``'min_ess'``
            Minimum effective sample size across a subsample of pointwise
            log-likelihood traces.  Low values (< 100) indicate the
            posterior samples may not adequately represent the posterior.
        ``'warning'``
            Present only when ``min_ess < 100``.  Human-readable warning
            that the WAIC estimate may be unreliable.

    Raises
    ------
    ValueError
        If sample arrays are None (store_samples was False).

    Notes
    -----
    Memory usage is O(S × m × n) for the pointwise log-likelihood
    array.  For very large problems consider computing in chunks.
    """
    if F_samples is None or G_samples is None:
        raise ValueError(
            "compute_waic requires stored posterior samples. "
            "Re-run with store_samples=True."
        )

    S = F_samples.shape[0]
    m, n = X.shape

    log_lik = np.empty((S, m, n))

    if likelihood == "lognormal":
        # log(X) ~ N(log(GF), tau^2) where tau = sigma / X
        logX = np.log(X)
        tau = sigma / X
        log_const = -0.5 * np.log(2 * np.pi) - np.log(tau)  # (m, n)
        for s in range(S):
            mu = np.maximum(F_samples[s] @ G_samples[s], 1e-300)
            log_lik[s] = log_const - 0.5 * ((logX - np.log(mu)) / tau) ** 2
    else:
        # X ~ N(GF, sigma^2)
        log_const = -0.5 * np.log(2 * np.pi) - np.log(sigma)  # (m, n)
        for s in range(S):
            mu = F_samples[s] @ G_samples[s]  # (m, n)
            log_lik[s] = log_const - 0.5 * ((X - mu) / sigma) ** 2

    # lppd: log pointwise predictive density
    # lppd_ij = log(1/S * sum_s exp(log_lik[s,i,j]))
    #         = logsumexp(log_lik[:,i,j]) - log(S)
    lppd_pointwise = logsumexp(log_lik, axis=0) - np.log(S)  # (m, n)
    lppd = float(np.sum(lppd_pointwise))

    # p_waic: effective number of parameters (variance of log-lik)
    p_waic_pointwise = np.var(log_lik, axis=0, ddof=1)  # (m, n)
    p_waic = float(np.sum(p_waic_pointwise))

    # WAIC = -2 * (lppd - p_waic)
    waic = -2.0 * (lppd - p_waic)

    # Standard error (for model comparison)
    waic_pointwise = -2.0 * (lppd_pointwise - p_waic_pointwise)
    se = float(np.sqrt(m * n * np.var(waic_pointwise)))

    # Sample quality check: ESS on a subsample of pointwise log-lik traces.
    # Full ESS over all (m, n) elements would be expensive; sample up to 50.
    _n_probe = min(50, m * n)
    _rng = np.random.default_rng(0)
    _flat_indices = _rng.choice(m * n, size=_n_probe, replace=False)
    _ess_vals = []
    for _idx in _flat_indices:
        _i, _j = divmod(int(_idx), n)
        _ess_vals.append(effective_sample_size(log_lik[:, _i, _j]))
    min_ess = float(min(_ess_vals)) if _ess_vals else 0.0

    result = {
        "waic": waic,
        "lppd": lppd,
        "p_waic": p_waic,
        "se": se,
        "min_ess": min_ess,
    }
    if min_ess < 100:
        result["warning"] = (
            f"Low effective sample size (min ESS={min_ess:.0f} across "
            f"{_n_probe} probed elements). WAIC estimate may be unreliable. "
            "Consider increasing n_samples."
        )
    return result


# ---------------------------------------------------------------------------
# Factor count posterior (ARD)
# ---------------------------------------------------------------------------


def factor_count_posterior(
    factor_activity_samples: np.ndarray,
    threshold: float = 0.01,
) -> dict:
    """
    Posterior distribution over the number of active factors from ARD samples.

    At each posterior sample, a factor is considered "active" if its fractional
    contribution (G-row-norm / total) exceeds the threshold.  The resulting
    histogram over active-factor counts gives a full posterior PMF, enabling
    statements like "P(p_active > 5) = 0.40".

    Parameters
    ----------
    factor_activity_samples : ndarray, shape (n_samples, p)
        Per-sample fractional contribution of each factor.  Obtained from
        ``BayesNMFResult.factor_activity_samples`` (requires ``ard=True``).
    threshold : float, default=0.01
        Fractional contribution below which a factor is considered inactive.

        .. note::

           Results are sensitive to the threshold value.  Use the
           ``'threshold_sensitivity'`` key in the returned dict to assess
           how robust the median factor count is across a range of thresholds.

    Returns
    -------
    dict with keys:
        ``'pmf'``
            ndarray, shape (p+1,).  ``pmf[k]`` = P(p_active = k).
        ``'mean'``
            Posterior mean number of active factors.
        ``'median'``
            Posterior median number of active factors.
        ``'ci_90'``
            Tuple (lo, hi): 90% credible interval for the number of active
            factors (5th and 95th percentiles).
        ``'prob_gt'``
            ndarray, shape (p+1,).  ``prob_gt[k]`` = P(p_active > k).
            Convenient for statements like "40% chance that more than 5
            factors are identifiable".
        ``'threshold_sensitivity'``
            dict mapping threshold float → median active factor count,
            evaluated at [0.001, 0.005, 0.01, 0.02, 0.05].  If the
            median is stable across these thresholds, the result is
            robust; if it varies widely, interpret with caution.

    Raises
    ------
    ValueError
        If factor_activity_samples is None (ard was not enabled).

    Examples
    --------
    >>> result = pmf_bayes(X, sigma, p=8, ard=True)
    >>> from pmf_acls import factor_count_posterior
    >>> fc = factor_count_posterior(result.factor_activity_samples)
    >>> print(f"Most likely: {fc['pmf'].argmax()} factors")
    >>> print(f"P(>5 factors) = {fc['prob_gt'][5]:.1%}")
    """
    if factor_activity_samples is None:
        raise ValueError(
            "factor_count_posterior requires factor_activity_samples. "
            "Re-run pmf_bayes with ard=True."
        )

    samples = np.asarray(factor_activity_samples)
    n_samples, p = samples.shape

    # Count active factors at each sample
    active_counts = np.sum(samples > threshold, axis=1)  # (n_samples,)

    # PMF: P(p_active = k) for k in 0..p
    pmf = np.zeros(p + 1)
    for k in range(p + 1):
        pmf[k] = np.mean(active_counts == k)

    # Exceedance probabilities: P(p_active > k)
    prob_gt = np.zeros(p + 1)
    for k in range(p + 1):
        prob_gt[k] = np.mean(active_counts > k)

    mean = float(np.mean(active_counts))
    median = int(np.median(active_counts))
    lo = int(np.percentile(active_counts, 5))
    hi = int(np.percentile(active_counts, 95))

    # Threshold sensitivity: median active count at several thresholds
    _sensitivity_thresholds = [0.001, 0.005, 0.01, 0.02, 0.05]
    threshold_sensitivity = {}
    for _t in _sensitivity_thresholds:
        _counts = np.sum(samples > _t, axis=1)
        threshold_sensitivity[_t] = int(np.median(_counts))

    return {
        "pmf": pmf,
        "mean": mean,
        "median": median,
        "ci_90": (lo, hi),
        "prob_gt": prob_gt,
        "threshold_sensitivity": threshold_sensitivity,
    }
