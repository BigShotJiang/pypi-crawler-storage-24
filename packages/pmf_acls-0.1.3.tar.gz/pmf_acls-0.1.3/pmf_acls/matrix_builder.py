"""
Matrix and vector construction utilities for PMF algorithm.

This module implements the matrix/vector construction routines described
in Table I of Lu & Wu (2005). It handles the construction of the sparse
Jacobian matrix Γ (Gamma), weight matrix W, regularization matrices, and
associated vectors used in solving Equation (13) of the paper.
"""

from typing import Tuple
import numpy as np
import scipy.sparse as sp


def build_gamma_matrix(F: np.ndarray, G: np.ndarray) -> sp.csr_matrix:
    """
    Construct sparse Jacobian matrix Γ (Gamma).

    The Gamma matrix contains the partial derivatives of the residuals
    with respect to the elements of F and G. It is a sparse matrix with
    only 2×m×n×p non-zero elements.

    Parameters
    ----------
    F : ndarray, shape (m, p)
        Current factor profiles matrix
    G : ndarray, shape (p, n)
        Current factor contributions matrix

    Returns
    -------
    Gamma : csr_matrix, shape (m×n, (m+n)×p)
        Sparse Jacobian matrix in CSR format

    Notes
    -----
    According to Table I in the paper:
    - Row index: (i-1)×n + j (for observation Xᵢⱼ)
    - Column for G: (k-1)×n + j (element Gₖⱼ)
    - Column for F: n×p + (i-1)×p + k (element Fᵢₖ)
    - Values: Γ[row, col_F] = Fᵢₖ, Γ[row, col_G] = Gₖⱼ

    See Lu & Wu (2005), Equation (6) and Table I.
    """
    m, p = F.shape
    p_check, n = G.shape

    if p != p_check:
        raise ValueError(
            f"Incompatible shapes: F is ({m}, {p}), G is ({p_check}, {n})"
        )

    # Calculate matrix dimensions
    n_rows = m * n
    n_cols = (m + n) * p
    n_nonzeros = 2 * m * n * p

    # Use LIL format for efficient construction, will convert to CSR
    Gamma = sp.lil_matrix((n_rows, n_cols))

    # Populate matrix according to Table I
    for i in range(m):
        for j in range(n):
            for k in range(p):
                row = i * n + j
                col_F = k * n + j
                col_G = n * p + i * p + k

                Gamma[row, col_F] = F[i, k]
                Gamma[row, col_G] = G[k, j]

    # Convert to CSR for efficient arithmetic operations
    return Gamma.tocsr()


def build_weight_matrix(weights: np.ndarray) -> sp.dia_matrix:
    """
    Construct diagonal weight matrix W.

    Parameters
    ----------
    weights : ndarray, shape (m, n)
        Weight matrix where wᵢⱼ = 1/σᵢⱼ²

    Returns
    -------
    W : dia_matrix, shape (m×n, m×n)
        Diagonal weight matrix in DIA (diagonal) format

    Notes
    -----
    The weights are arranged in row-major (row-dominant) order:
    [w₁₁, w₁₂, ..., w₁ₙ, w₂₁, w₂₂, ..., wₘₙ]

    See Lu & Wu (2005), Table I.
    """
    m, n = weights.shape

    # Flatten in row-major order
    w_flat = weights.ravel()

    # Create diagonal matrix
    W = sp.dia_matrix((w_flat, 0), shape=(m * n, m * n))

    return W


def build_regularization_matrix(
    c: np.ndarray, d: np.ndarray, gamma: float, delta: float
) -> sp.dia_matrix:
    """
    Construct diagonal regularization matrix Λᵣ (K_r).

    Parameters
    ----------
    c : ndarray, shape (p,)
        Scaling coefficients for F (one per factor)
    d : ndarray, shape (p,)
        Scaling coefficients for G (one per factor)
    gamma : float
        Regularization strength for F
    delta : float
        Regularization strength for G

    Returns
    -------
    K_r : dia_matrix, shape ((m+n)×p, (m+n)×p)
        Diagonal regularization matrix

    Notes
    -----
    The diagonal contains γ·cᵢ for F elements and δ·dⱼ for G elements.
    See Lu & Wu (2005), Equation (13) and Table I.
    """
    p = len(c)
    m = p  # Will be set correctly when called
    n = len(d)  # Actually p, will be handled in caller

    # This function will be called with properly extracted dimensions
    # The diagonal is organized as: [G elements, F elements]
    # We need to know m and n from the context

    # This is a helper - actual construction done in build_system_matrices
    raise NotImplementedError("Use build_system_matrices instead")


def build_penalty_matrix(
    a_G: np.ndarray, a_F: np.ndarray, alpha: float, beta: float
) -> sp.dia_matrix:
    """
    Construct diagonal logarithmic penalty matrix Λₚ (K_p).

    Parameters
    ----------
    a_G : ndarray, shape (m, p)
        Quadratic approximation constants for F
    a_F : ndarray, shape (p, n)
        Quadratic approximation constants for G
    alpha : float
        Penalty strength for F
    beta : float
        Penalty strength for G

    Returns
    -------
    K_p : dia_matrix, shape ((m+n)×p, (m+n)×p)
        Diagonal penalty matrix

    Notes
    -----
    The diagonal contains -α·aᴳᵢₖ for F elements and -β·aᶠₖⱼ for G elements.
    See Lu & Wu (2005), Equation (13) and Table I.
    """
    # Similar to above - use build_system_matrices
    raise NotImplementedError("Use build_system_matrices instead")


def build_system_matrices(
    F: np.ndarray,
    G: np.ndarray,
    weights: np.ndarray,
    c: np.ndarray,
    d: np.ndarray,
    a_G: np.ndarray,
    a_F: np.ndarray,
    gamma: float,
    delta: float,
    alpha: float,
    beta: float,
) -> Tuple[sp.csr_matrix, sp.dia_matrix, sp.dia_matrix, sp.dia_matrix]:
    """
    Build all system matrices for PMF algorithm.

    This is a convenience function that builds Γ, W, Λᵣ, and Λₚ together.

    Parameters
    ----------
    F : ndarray, shape (m, p)
        Current F matrix
    G : ndarray, shape (p, n)
        Current G matrix
    weights : ndarray, shape (m, n)
        Weight matrix (wᵢⱼ = 1/σᵢⱼ²)
    c : ndarray, shape (p,)
        Scaling coefficients for F
    d : ndarray, shape (p,)
        Scaling coefficients for G
    a_G : ndarray, shape (m, p)
        Quadratic approximation constants for F
    a_F : ndarray, shape (p, n)
        Quadratic approximation constants for G
    gamma : float
        Regularization strength for F
    delta : float
        Regularization strength for G
    alpha : float
        Penalty strength for F
    beta : float
        Penalty strength for G

    Returns
    -------
    Gamma : csr_matrix
        Jacobian matrix
    W : dia_matrix
        Weight matrix
    K_r : dia_matrix
        Regularization matrix
    K_p : dia_matrix
        Penalty matrix
    """
    m, p = F.shape
    _, n = G.shape

    # Build Gamma matrix
    Gamma = build_gamma_matrix(F, G)

    # Build weight matrix
    W = build_weight_matrix(weights)

    # Build regularization matrix diagonal
    # Organized as [G elements, F elements] in row-major order
    K_r_diag = np.zeros((m + n) * p)

    # G elements: columns (k-1)×n + j, value is δ·dⱼ
    for k in range(p):
        for j in range(n):
            col = k * n + j
            K_r_diag[col] = delta * d[k]

    # F elements: columns n×p + (i-1)×p + k, value is γ·cᵢ
    for i in range(m):
        for k in range(p):
            col = n * p + i * p + k
            K_r_diag[col] = gamma * c[k]

    K_r = sp.dia_matrix((K_r_diag, 0), shape=((m + n) * p, (m + n) * p))

    # Build penalty matrix diagonal
    # The Hessian of the quadratic approximation g(θ) = a(θ-b)² is 2a
    # Lambda_p should be positive semi-definite for numerical stability
    K_p_diag = np.zeros((m + n) * p)

    # G elements: 2·β·aᶠₖⱼ (factor of 2 from Hessian of quadratic)
    for k in range(p):
        for j in range(n):
            col = k * n + j
            K_p_diag[col] = 2.0 * beta * a_F[k, j]

    # F elements: 2·α·aᴳᵢₖ (factor of 2 from Hessian of quadratic)
    for i in range(m):
        for k in range(p):
            col = n * p + i * p + k
            K_p_diag[col] = 2.0 * alpha * a_G[i, k]

    K_p = sp.dia_matrix((K_p_diag, 0), shape=((m + n) * p, (m + n) * p))

    return Gamma, W, K_r, K_p


def build_residual_vector(residuals: np.ndarray) -> np.ndarray:
    """
    Construct residual vector r from residual matrix R.

    Parameters
    ----------
    residuals : ndarray, shape (m, n)
        Residual matrix R = X - F @ G

    Returns
    -------
    r : ndarray, shape (m×n,)
        Residual vector in row-major order

    Notes
    -----
    Elements are arranged as: [R₁₁, R₁₂, ..., R₁ₙ, R₂₁, ..., Rₘₙ]
    See Lu & Wu (2005), Table I.
    """
    return residuals.ravel()


def build_theta_vector(F: np.ndarray, G: np.ndarray) -> np.ndarray:
    """
    Construct Θ (theta) vector from current F and G.

    Parameters
    ----------
    F : ndarray, shape (m, p)
        Current F matrix
    G : ndarray, shape (p, n)
        Current G matrix

    Returns
    -------
    Theta : ndarray, shape ((m+n)×p,)
        Vector of current F and G values

    Notes
    -----
    Organized as [G elements, F elements] in row-major order.
    See Lu & Wu (2005), Table I and Equation (13).
    """
    m, p = F.shape
    _, n = G.shape

    Theta = np.zeros((m + n) * p)

    # G elements
    Theta[: n * p] = G.ravel()

    # F elements
    Theta[n * p :] = F.ravel()

    return Theta


def build_theta_star_vector(b_G: np.ndarray, b_F: np.ndarray) -> np.ndarray:
    """
    Construct Θ* (theta-star) vector from b constants.

    Parameters
    ----------
    b_G : ndarray, shape (m, p)
        Quadratic approximation b constants for F
    b_F : ndarray, shape (p, n)
        Quadratic approximation b constants for G

    Returns
    -------
    Theta_star : ndarray, shape ((m+n)×p,)
        Vector of target values for logarithmic penalties

    Notes
    -----
    Organized as [G elements, F elements] in row-major order.
    See Lu & Wu (2005), Table I and Equation (13).
    """
    m, p = b_G.shape
    _, n = b_F.shape

    Theta_star = np.zeros((m + n) * p)

    # G elements
    Theta_star[: n * p] = b_F.ravel()

    # F elements
    Theta_star[n * p :] = b_G.ravel()

    return Theta_star


def extract_updates_from_phi(
    phi: np.ndarray, m: int, n: int, p: int
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Extract update matrices g and f from solution vector φ (phi).

    Parameters
    ----------
    phi : ndarray, shape ((m+n)×p,)
        Solution vector from solving LSM @ φ = RSV
    m : int
        Number of variables
    n : int
        Number of observations
    p : int
        Number of factors

    Returns
    -------
    f : ndarray, shape (p, n)
        Update matrix for G
    g : ndarray, shape (m, p)
        Update matrix for F

    Notes
    -----
    φ contains [f elements, g elements] in row-major order.
    See Lu & Wu (2005), Table I.
    """
    # G elements (first n×p elements)
    f = phi[: n * p].reshape(p, n)

    # F elements (last m×p elements)
    g = phi[n * p :].reshape(m, p)

    return f, g


def compute_scaling_coefficients(
    F: np.ndarray, G: np.ndarray
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Compute scaling coefficients c and d for regularization.

    The scaling coefficients normalize the rows of F and columns of G
    to be of comparable magnitude.

    Parameters
    ----------
    F : ndarray, shape (m, p)
        Current F matrix
    G : ndarray, shape (p, n)
        Current G matrix

    Returns
    -------
    c : ndarray, shape (p,)
        Scaling coefficients for F: cₖ = 1 / Σᵢ|Fᵢₖ|
    d : ndarray, shape (p,)
        Scaling coefficients for G: dₖ = 1 / Σⱼ|Gₖⱼ|

    Notes
    -----
    Implements Equations (15) and (16) from Lu & Wu (2005).
    The coefficients should be updated at each iteration.
    """
    p = F.shape[1]

    # c[k] = 1 / sum_i |F[i,k]|
    c = np.zeros(p)
    for k in range(p):
        sum_abs = np.sum(np.abs(F[:, k]))
        c[k] = 1.0 / sum_abs if sum_abs > 0 else 1.0

    # d[k] = 1 / sum_j |G[k,j]|
    d = np.zeros(p)
    for k in range(p):
        sum_abs = np.sum(np.abs(G[k, :]))
        d[k] = 1.0 / sum_abs if sum_abs > 0 else 1.0

    return c, d


def quadratic_log_approximation(
    theta: np.ndarray,
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Compute quadratic approximation constants for -log₁₀(θ).

    The logarithmic penalty term -log(θ) is approximated by a quadratic
    function g(θ) = a(θ - b)² around the current value θ₀.

    Parameters
    ----------
    theta : ndarray
        Current values (elements of F or G)

    Returns
    -------
    a : ndarray
        Same shape as theta. Quadratic coefficient.
    b : ndarray
        Same shape as theta. Quadratic center.

    Notes
    -----
    Implements Equations (11) and (12) from Lu & Wu (2005):
    a = 1 / (4 × ln(10) × ln(θ₀)² × θ₀)
    b = θ₀ - 2θ₀ × ln(θ₀)

    The approximation is valid around the current point θ₀.

    For numerical stability, very small theta values are clamped
    to avoid division by zero and overflow issues.
    """
    # Avoid log of very small numbers - clamp to reasonable range
    theta_safe = np.clip(theta, 1e-12, 1e12)

    # Equation (11): a = 1 / (4 * ln(10) * ln(theta_0)^2 * theta_0)
    ln_theta = np.log(theta_safe)

    # Avoid division by zero when ln(theta) is close to zero
    # This happens when theta is close to 1
    # Replace values too close to zero with a small offset
    mask = np.abs(ln_theta) < 1e-10
    ln_theta_safe = ln_theta.copy()
    ln_theta_safe[mask] = 1e-10

    a = 1.0 / (4.0 * np.log(10) * ln_theta_safe**2 * theta_safe)

    # Equation (12): b = theta_0 - 2 * theta_0 * ln(theta_0)
    b = theta_safe - 2.0 * theta_safe * ln_theta

    return a, b


def compute_objective_function(
    residuals: np.ndarray,
    sigma: np.ndarray,
    F: np.ndarray,
    G: np.ndarray,
    c: np.ndarray,
    d: np.ndarray,
    alpha: float,
    beta: float,
    gamma: float,
    delta: float,
) -> Tuple[float, float]:
    """
    Compute objective function values Q_basic and Q_enhanced.

    Parameters
    ----------
    residuals : ndarray, shape (m, n)
        Residual matrix R = X - F @ G
    sigma : ndarray, shape (m, n)
        Uncertainty matrix
    F : ndarray, shape (m, p)
        Current F matrix
    G : ndarray, shape (p, n)
        Current G matrix
    c : ndarray, shape (p,)
        Scaling coefficients for F
    d : ndarray, shape (p,)
        Scaling coefficients for G
    alpha, beta : float
        Logarithmic penalty strengths
    gamma, delta : float
        Regularization strengths

    Returns
    -------
    Q_basic : float
        Basic objective function (Equation 2 from paper)
    Q_enhanced : float
        Enhanced objective function with penalties (Equation 9)

    Notes
    -----
    Q_basic = Σᵢⱼ (Rᵢⱼ/σᵢⱼ)²

    Q_enhanced = Q_basic - α·Σᵢₖ log(Fᵢₖ) - β·Σₖⱼ log(Gₖⱼ)
                 + γ·Σᵢₖ cᵢ·F²ᵢₖ + δ·Σₖⱼ dⱼ·G²ₖⱼ
    """
    # Basic Q (Equation 2)
    Q_basic = np.sum((residuals / sigma) ** 2)

    # Logarithmic penalty terms
    G_safe = np.maximum(F, 1e-12)
    F_safe = np.maximum(G, 1e-12)
    log_penalty_G = -alpha * np.sum(np.log10(G_safe))
    log_penalty_F = -beta * np.sum(np.log10(F_safe))

    # Regularization terms
    # Note: c and d are per-factor, need to broadcast
    reg_G = gamma * np.sum(c[:, np.newaxis].T * F**2)
    reg_F = delta * np.sum(d[:, np.newaxis] * G**2)

    Q_enhanced = Q_basic + log_penalty_G + log_penalty_F + reg_G + reg_F

    return Q_basic, Q_enhanced
