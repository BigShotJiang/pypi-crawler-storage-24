"""
pmf_acls — Positive Matrix Factorization via Alternating Constrained Least Squares

A Python implementation of the PMF algorithm for environmental data analysis,
featuring ACLS (Langville et al. 2014) and Newton (Lu & Wu 2005) solver backends
with per-element uncertainty weighting.
"""

__version__ = "0.1.0"
__author__ = "Jerritt Collord"

# Core API
from .core import pmf, fpeak_sweep
from .data_structures import PMFResult, FactorSelectionResult, UncertaintyResult, DisplacementResult, FPEAKSweepResult
from .bayes import pmf_bayes, BayesNMFResult, SIGMA_CATEGORY_PRESETS
from .lda import pmf_lda, LDAResult
from .bayes_diagnostics import effective_sample_size, gelman_rubin, compute_waic, factor_count_posterior

# Diagnostics
from .diagnostics import (
    select_factors,
    compute_scaled_residuals,
    residual_statistics,
    compute_contributions,
    explained_variance_per_variable,
    print_diagnostics,
)

# Uncertainty estimation
from .uncertainty import (
    bootstrap_uncertainty,
    align_factors_procrustes,
    displacement_test,
    multistart_test,
    Bootstrap,
    Displacement,
)

# Data preparation utilities
from .utils import (
    prepare_data,
    handle_missing_values,
    handle_below_detection_limit,
    estimate_uncertainty,
    enforce_minimum_uncertainty,
    flag_outliers,
    check_data_quality,
)

__all__ = [
    "pmf",
    "fpeak_sweep",
    "pmf_bayes",
    "BayesNMFResult",
    "SIGMA_CATEGORY_PRESETS",
    "pmf_lda",
    "LDAResult",
    # Bayesian diagnostics
    "effective_sample_size",
    "gelman_rubin",
    "compute_waic",
    "factor_count_posterior",
    "PMFResult",
    "FactorSelectionResult",
    "UncertaintyResult",
    "DisplacementResult",
    "FPEAKSweepResult",
    # Diagnostics
    "select_factors",
    "compute_scaled_residuals",
    "residual_statistics",
    "compute_contributions",
    "explained_variance_per_variable",
    "print_diagnostics",
    # Uncertainty
    "bootstrap_uncertainty",
    "align_factors_procrustes",
    "displacement_test",
    "multistart_test",
    "Bootstrap",
    "Displacement",
    # Data preparation
    "prepare_data",
    "handle_missing_values",
    "handle_below_detection_limit",
    "estimate_uncertainty",
    "enforce_minimum_uncertainty",
    "flag_outliers",
    "check_data_quality",
]
