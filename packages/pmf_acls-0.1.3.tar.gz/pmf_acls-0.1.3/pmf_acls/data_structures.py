"""
Data structures for PMF results and outputs.

This module defines the container classes for PMF algorithm results,
factor selection diagnostics, and uncertainty estimates.
"""

from typing import Optional, List, Dict, Tuple
import numpy as np


class PMFResult:
    """
    Container for Positive Matrix Factorization results.

    This class holds the factor matrices, convergence information,
    diagnostics, and optional uncertainty estimates from a PMF run.

    Attributes
    ----------
    F : ndarray, shape (m, p)
        Factor profiles matrix. Each row represents a variable,
        each column represents a factor.
    G : ndarray, shape (p, n)
        Factor contributions matrix. Each row represents a factor,
        each column represents an observation.
    Q : float
        Final objective function value.
    Q_history : list of float
        Objective function value at each iteration.
    n_iter : int
        Number of iterations performed.
    converged : bool
        Whether the algorithm converged within tolerance.
    residuals : ndarray, shape (m, n)
        Final residual matrix: R = X - F @ G
    explained_variance : float
        Proportion of variance explained (R² metric).
    chi2 : float
        Normalized chi-square statistic: Q / degrees_of_freedom
    F_std : ndarray, shape (m, p), optional
        Analytical standard deviations of F from WLS covariance.
    G_std : ndarray, shape (p, n), optional
        Analytical standard deviations of G from WLS covariance.

    Notes
    -----
    The factorization quality can be assessed via:
    - explained_variance: Higher is better (close to 1.0)
    - chi2: Should be close to 1.0 for well-calibrated uncertainties
    - residuals: Should be randomly distributed around zero
    """

    def __init__(
        self,
        F: np.ndarray,
        G: np.ndarray,
        Q: float,
        Q_history: List[float],
        n_iter: int,
        converged: bool,
        residuals: np.ndarray,
        explained_variance: float,
        chi2: float,
        F_std: Optional[np.ndarray] = None,
        G_std: Optional[np.ndarray] = None,
    ):
        """
        Initialize PMFResult.

        Parameters
        ----------
        F : ndarray, shape (m, p)
            Factor profiles
        G : ndarray, shape (p, n)
            Factor contributions
        Q : float
            Final objective function value
        Q_history : list of float
            Objective values per iteration
        n_iter : int
            Number of iterations
        converged : bool
            Convergence status
        residuals : ndarray, shape (m, n)
            Final residuals
        explained_variance : float
            R² metric
        chi2 : float
            Normalized chi-square
        F_std : ndarray, optional
            Analytical standard deviations of F from WLS covariance
        G_std : ndarray, optional
            Analytical standard deviations of G from WLS covariance
        """
        self.F = F
        self.G = G
        self.Q = Q
        self.Q_history = Q_history
        self.n_iter = n_iter
        self.converged = converged
        self.residuals = residuals
        self.explained_variance = explained_variance
        self.chi2 = chi2
        self.F_std = F_std
        self.G_std = G_std

    def __repr__(self) -> str:
        """String representation of PMFResult."""
        m, p = self.F.shape
        _, n = self.G.shape
        conv_str = "Yes" if self.converged else "No"
        uncertainty_str = "Yes" if self.F_std is not None else "No"

        return (
            f"PMFResult(\n"
            f"  Shape: {m} variables × {n} observations × {p} factors\n"
            f"  Converged: {conv_str} ({self.n_iter} iterations)\n"
            f"  Q: {self.Q:.4e}\n"
            f"  Explained variance: {self.explained_variance:.2%}\n"
            f"  chi2: {self.chi2:.4f}\n"
            f"  Uncertainty estimates: {uncertainty_str}\n"
            f")"
        )

    def to_dict(self) -> Dict:
        """
        Convert result to dictionary.

        Returns
        -------
        dict
            Dictionary containing all result attributes.
            NumPy arrays are preserved (not converted to lists).
        """
        return {
            "F": self.F,
            "G": self.G,
            "Q": self.Q,
            "Q_history": self.Q_history,
            "n_iter": self.n_iter,
            "converged": self.converged,
            "residuals": self.residuals,
            "explained_variance": self.explained_variance,
            "chi2": self.chi2,
            "F_std": self.F_std,
            "G_std": self.G_std,
        }

    def summary(self) -> None:
        """Print summary statistics of the PMF result."""
        m, p = self.F.shape
        _, n = self.G.shape

        print("=" * 60)
        print("PMF Result Summary")
        print("=" * 60)
        print(f"Problem size: {m} variables × {n} observations × {p} factors")
        print(f"Converged: {'Yes' if self.converged else 'No'}")
        print(f"Iterations: {self.n_iter}")
        print(f"\nObjective Function:")
        print(f"  Final Q: {self.Q:.4e}")
        if len(self.Q_history) > 1:
            print(f"  Initial Q: {self.Q_history[0]:.4e}")
            improvement = (self.Q_history[0] - self.Q) / self.Q_history[0] * 100
            print(f"  Improvement: {improvement:.2f}%")
        print(f"\nGoodness of Fit:")
        print(f"  Explained variance (R²): {self.explained_variance:.2%}")
        print(f"  chi2 statistic: {self.chi2:.4f}")
        print(f"\nResidual Statistics:")
        print(f"  Mean: {np.mean(self.residuals):.4e}")
        print(f"  Std: {np.std(self.residuals):.4e}")
        print(f"  Min: {np.min(self.residuals):.4e}")
        print(f"  Max: {np.max(self.residuals):.4e}")

        if self.F_std is not None:
            print(f"\nUncertainty Estimates:")
            _f_mask = self.F > 1e-6 * self.F.max()
            _g_mask = self.G > 1e-6 * self.G.max()
            _f_rel = np.mean(self.F_std[_f_mask] / self.F[_f_mask]) if _f_mask.any() else 0.0
            _g_rel = np.mean(self.G_std[_g_mask] / self.G[_g_mask]) if _g_mask.any() else 0.0
            print(f"  F relative uncertainty: {_f_rel:.2%}")
            print(f"  G relative uncertainty: {_g_rel:.2%}")

        print("=" * 60)


class FactorSelectionResult:
    """
    Container for factor selection diagnostics.

    This class holds results from testing multiple values of p
    (number of factors) to determine the optimal factorization rank.

    Attributes
    ----------
    p_values : list of int
        List of p values tested.
    Q_values : dict
        Dictionary mapping p -> list of Q values from multiple runs.
    Q_robust : dict
        Dictionary mapping p -> Q_robust metric.
    best_p : int
        Recommended number of factors based on selection criterion.
    best_results : dict
        Dictionary mapping p -> best PMFResult for each p.

    Notes
    -----
    Factor selection criteria:
    - Q_robust: Q / E[Q], where E[Q] ≈ (m×n - (m+n)×p)
      Should be close to 1.0 for appropriate p
    - Elbow method: Look for "elbow" in Q vs p plot
    - Physical interpretability: Factors should be meaningful
    """

    def __init__(
        self,
        p_values: List[int],
        Q_values: Dict[int, List[float]],
        Q_robust: Dict[int, float],
        best_p: int,
        best_results: Dict[int, PMFResult],
    ):
        """
        Initialize FactorSelectionResult.

        Parameters
        ----------
        p_values : list of int
            Tested p values
        Q_values : dict
            p -> list of Q values from runs
        Q_robust : dict
            p -> Q_robust metric
        best_p : int
            Recommended p
        best_results : dict
            p -> best PMFResult for each p
        """
        self.p_values = p_values
        self.Q_values = Q_values
        self.Q_robust = Q_robust
        self.best_p = best_p
        self.best_results = best_results

    def __repr__(self) -> str:
        """String representation of FactorSelectionResult."""
        return (
            f"FactorSelectionResult(\n"
            f"  Tested p values: {self.p_values}\n"
            f"  Recommended p: {self.best_p}\n"
            f"  Q_robust at best p: {self.Q_robust[self.best_p]:.4f}\n"
            f")"
        )

    def summary(self) -> None:
        """Print summary of factor selection results."""
        print("=" * 60)
        print("Factor Selection Summary")
        print("=" * 60)
        print(f"Tested p values: {self.p_values}")
        print(f"Recommended p: {self.best_p}")
        print("\nQ_robust by number of factors:")
        for p in self.p_values:
            q_runs = self.Q_values[p]
            q_mean = np.mean(q_runs)
            q_std = np.std(q_runs)
            q_robust = self.Q_robust[p]
            marker = " <-- Best" if p == self.best_p else ""
            print(f"  p={p}: Q_robust={q_robust:.4f}, "
                  f"Q={q_mean:.4e} ± {q_std:.4e} ({len(q_runs)} runs){marker}")
        print("=" * 60)


class UncertaintyResult:
    """
    Container for bootstrap uncertainty estimates.

    This class holds uncertainty quantification results from
    bootstrap resampling of the PMF solution.

    Attributes
    ----------
    F_mean : ndarray, shape (m, p)
        Mean of F across bootstrap samples.
    F_std : ndarray, shape (m, p)
        Standard deviation of F across bootstrap samples.
    F_percentiles : dict, optional
        Percentiles of F (e.g., {5: array, 95: array}).
    G_mean : ndarray, shape (p, n)
        Mean of G across bootstrap samples.
    G_std : ndarray, shape (p, n)
        Standard deviation of G across bootstrap samples.
    G_percentiles : dict, optional
        Percentiles of G (e.g., {5: array, 95: array}).
    bootstrap_results : list of PMFResult
        Individual PMFResult objects from each bootstrap run.

    Notes
    -----
    Bootstrap uncertainty provides:
    - Standard errors for each element of F and G
    - Confidence intervals via percentiles
    - Distribution of solutions across resampled data
    """

    def __init__(
        self,
        F_mean: np.ndarray,
        F_std: np.ndarray,
        G_mean: np.ndarray,
        G_std: np.ndarray,
        bootstrap_results: List[PMFResult],
        F_percentiles: Optional[Dict[int, np.ndarray]] = None,
        G_percentiles: Optional[Dict[int, np.ndarray]] = None,
    ):
        """
        Initialize UncertaintyResult.

        Parameters
        ----------
        F_mean : ndarray, shape (m, p)
            Mean F matrix
        F_std : ndarray, shape (m, p)
            Std of F matrix
        G_mean : ndarray, shape (p, n)
            Mean G matrix
        G_std : ndarray, shape (p, n)
            Std of G matrix
        bootstrap_results : list of PMFResult
            Individual bootstrap results
        F_percentiles : dict, optional
            Percentiles of F
        G_percentiles : dict, optional
            Percentiles of G
        """
        self.F_mean = F_mean
        self.F_std = F_std
        self.G_mean = G_mean
        self.G_std = G_std
        self.bootstrap_results = bootstrap_results
        self.F_percentiles = F_percentiles or {}
        self.G_percentiles = G_percentiles or {}

    def __repr__(self) -> str:
        """String representation of UncertaintyResult."""
        m, p = self.F_mean.shape
        _, n = self.G_mean.shape
        n_bootstrap = len(self.bootstrap_results)

        avg_rel_unc_F = np.mean(self.F_std / (self.F_mean + 1e-10))
        avg_rel_unc_G = np.mean(self.G_std / (self.G_mean + 1e-10))

        return (
            f"UncertaintyResult(\n"
            f"  Shape: {m} variables × {n} observations × {p} factors\n"
            f"  Bootstrap samples: {n_bootstrap}\n"
            f"  Avg relative uncertainty (F): {avg_rel_unc_F:.2%}\n"
            f"  Avg relative uncertainty (G): {avg_rel_unc_G:.2%}\n"
            f")"
        )

    def summary(self) -> None:
        """Print summary of uncertainty estimates."""
        m, p = self.F_mean.shape
        _, n = self.G_mean.shape
        n_bootstrap = len(self.bootstrap_results)

        print("=" * 60)
        print("Bootstrap Uncertainty Summary")
        print("=" * 60)
        print(f"Problem size: {m} variables × {n} observations × {p} factors")
        print(f"Bootstrap samples: {n_bootstrap}")

        print(f"\nF Matrix Uncertainty:")
        _f_mask = self.F_mean > 1e-6 * self.F_mean.max()
        if _f_mask.any():
            rel_unc_F = self.F_std[_f_mask] / self.F_mean[_f_mask]
            print(f"  Mean relative uncertainty: {np.mean(rel_unc_F):.2%}")
            print(f"  Median relative uncertainty: {np.median(rel_unc_F):.2%}")
            print(f"  Max relative uncertainty: {np.max(rel_unc_F):.2%}")
        else:
            print(f"  (no significant elements)")

        print(f"\nG Matrix Uncertainty:")
        _g_mask = self.G_mean > 1e-6 * self.G_mean.max()
        if _g_mask.any():
            rel_unc_G = self.G_std[_g_mask] / self.G_mean[_g_mask]
            print(f"  Mean relative uncertainty: {np.mean(rel_unc_G):.2%}")
            print(f"  Median relative uncertainty: {np.median(rel_unc_G):.2%}")
            print(f"  Max relative uncertainty: {np.max(rel_unc_G):.2%}")
        else:
            print(f"  (no significant elements)")

        if self.F_percentiles:
            print(f"\nAvailable percentiles: {sorted(self.F_percentiles.keys())}")

        print("=" * 60)


class DisplacementResult:
    """
    Container for DISP (Displacement) error estimation results.

    DISP explores rotational ambiguity by systematically displacing
    individual factor profile features and measuring how much Q increases
    before factors swap or the solution degrades.

    Attributes
    ----------
    G_base : ndarray, shape (p, n)
        Base factor profiles from the reference solution.
    G_min : dict of {float: ndarray}
        Mapping from dQ_max threshold to lower bound G matrix (p, n).
    G_max : dict of {float: ndarray}
        Mapping from dQ_max threshold to upper bound G matrix (p, n).
    dQ_thresholds : list of float
        The dQ_max thresholds used (e.g. [4, 8, 16, 32]).
    swap_counts : dict of {float: ndarray}
        Mapping from dQ_max threshold to integer array of shape (p, n).
        Each element counts factor swaps detected during displacement.
    Q_base : float
        Base solution Q value.
    converged : dict of {float: ndarray}
        Mapping from dQ_max threshold to boolean array of shape (p, n).
        True if binary search converged for that element.
    """

    def __init__(
        self,
        G_base: np.ndarray,
        G_min: Dict[float, np.ndarray],
        G_max: Dict[float, np.ndarray],
        dQ_thresholds: List[float],
        swap_counts: Dict[float, np.ndarray],
        Q_base: float,
        converged: Dict[float, np.ndarray],
        feature_labels: Optional[List[str]] = None,
    ):
        self.G_base = G_base
        self.G_min = G_min
        self.G_max = G_max
        self.dQ_thresholds = dQ_thresholds
        self.swap_counts = swap_counts
        self.Q_base = Q_base
        self.converged = converged
        self.n_factors, self.n_features = G_base.shape
        self.feature_labels = feature_labels or [f"F{j}" for j in range(self.n_features)]

    def __repr__(self) -> str:
        total_swaps = sum(
            int(np.sum(v > 0)) for v in self.swap_counts.values()
        )
        return (
            f"DisplacementResult(\n"
            f"  Factors: {self.n_factors}, Features: {self.n_features}\n"
            f"  dQ thresholds: {self.dQ_thresholds}\n"
            f"  Q_base: {self.Q_base:.4e}\n"
            f"  Total swap events: {total_swaps}\n"
            f")"
        )

    def get_intervals(self, dQ_max: float) -> Tuple[np.ndarray, np.ndarray]:
        """Return (G_min, G_max) arrays for a given dQ threshold."""
        return self.G_min[dQ_max], self.G_max[dQ_max]

    def summary(self) -> None:
        """Print summary of DISP results."""
        print("=" * 60)
        print("DISP Error Estimation Summary")
        print("=" * 60)
        print(f"Factors: {self.n_factors}, Features: {self.n_features}")
        print(f"Q_base: {self.Q_base:.4e}")
        print(f"dQ thresholds: {self.dQ_thresholds}")
        for dq in self.dQ_thresholds:
            n_swaps = int(np.sum(self.swap_counts[dq] > 0))
            n_converged = int(np.sum(self.converged[dq]))
            total = self.n_factors * self.n_features
            avg_range = np.mean(self.G_max[dq] - self.G_min[dq])
            print(f"\n  dQ_max = {dq}:")
            print(f"    Converged: {n_converged}/{total} elements")
            print(f"    Swap events: {n_swaps}/{total} elements")
            print(f"    Avg G range: {avg_range:.4e}")
        print("=" * 60)


class FPEAKSweepResult:
    """Results from an FPEAK rotational sweep.

    Contains PMFResult objects for each FPEAK value tested, plus the
    Q-vs-FPEAK curve for diagnosing rotational ambiguity.

    Parameters
    ----------
    base_result : PMFResult
        The base solution at fpeak=0.
    fpeak_values : list of float
        FPEAK values tested, in sweep order.
    results : dict of {float: PMFResult}
        Converged PMFResult for each FPEAK value.
    """

    def __init__(
        self,
        base_result: "PMFResult",
        fpeak_values: List[float],
        results: Dict[float, "PMFResult"],
    ):
        self.base_result = base_result
        self.fpeak_values = sorted(fpeak_values)
        self.results = results
        self.Q_values = {fp: r.Q for fp, r in results.items()}

    def summary(self):
        """Print FPEAK sweep summary table."""
        Q_base = self.base_result.Q
        print("=" * 60)
        print("FPEAK Sweep Summary")
        print("=" * 60)
        print(f"{'FPEAK':>8}  {'Q':>12}  {'dQ':>10}  {'%dQ':>8}  {'Conv':>5}")
        print("-" * 50)
        for fp in self.fpeak_values:
            r = self.results[fp]
            dQ = r.Q - Q_base
            pct = 100 * dQ / Q_base if Q_base > 0 else 0.0
            conv = "Y" if r.converged else "N"
            print(f"{fp:>8.2f}  {r.Q:>12.2f}  {dQ:>10.2f}  {pct:>7.2f}%  {conv:>5}")
        print("=" * 60)

    def plot_Q_vs_fpeak(self, ax=None):
        """Plot Q vs FPEAK curve.

        Returns matplotlib Figure if no ax provided.
        """
        import matplotlib.pyplot as plt

        if ax is None:
            fig, ax = plt.subplots(figsize=(8, 5))
        else:
            fig = ax.get_figure()

        fps = self.fpeak_values
        qs = [self.Q_values[fp] for fp in fps]

        ax.plot(fps, qs, "o-", color="steelblue", markersize=6)
        ax.axvline(0, color="gray", linestyle="--", alpha=0.5)
        ax.set_xlabel("FPEAK")
        ax.set_ylabel("Q (main)")
        ax.set_title("Q vs FPEAK")
        ax.grid(True, alpha=0.3)

        return fig

    def plot_profiles(self, factor, ax=None):
        """Plot factor profiles at each FPEAK value.

        Parameters
        ----------
        factor : int
            Factor index (0-based).

        Returns matplotlib Figure if no ax provided.
        """
        import matplotlib.pyplot as plt

        if ax is None:
            fig, ax = plt.subplots(figsize=(10, 6))
        else:
            fig = ax.get_figure()

        cmap = plt.cm.coolwarm
        n_fp = len(self.fpeak_values)
        for idx, fp in enumerate(self.fpeak_values):
            r = self.results[fp]
            profile = r.G[factor, :]
            # Normalize to fraction
            total = profile.sum()
            if total > 0:
                profile = profile / total
            color = cmap(idx / max(n_fp - 1, 1))
            lw = 2.5 if fp == 0.0 else 1.0
            ax.plot(profile, color=color, linewidth=lw, label=f"{fp:.1f}")

        ax.set_xlabel("Feature index")
        ax.set_ylabel("Profile fraction")
        ax.set_title(f"Factor {factor + 1} profile across FPEAK values")
        ax.legend(title="FPEAK", fontsize="small", ncol=2)
        ax.grid(True, alpha=0.3)

        return fig
