"""Tests for hierarchical sigma in pmf_acls.bayes."""

import numpy as np
import pytest

from pmf_acls.bayes import pmf_bayes, BayesNMFResult, SIGMA_CATEGORY_PRESETS


@pytest.fixture
def synthetic_data():
    """Small synthetic PMF problem: m=15, n=30, p=2."""
    rng = np.random.default_rng(42)
    m, n, p = 15, 30, 2
    F_true = rng.uniform(0.1, 2.0, size=(m, p))
    G_true = rng.uniform(0.1, 2.0, size=(p, n))
    X = F_true @ G_true + 0.1 * rng.standard_normal((m, n))
    X = np.maximum(X, 0.0)
    sigma = 0.1 * np.ones((m, n))
    return X, sigma, p


# ---------------------------------------------------------------------------
# Backward compatibility
# ---------------------------------------------------------------------------

def test_default_no_hierarchical(synthetic_data):
    """sigma_prior=None returns same as before (no sigma fields populated)."""
    X, sigma, p = synthetic_data
    result = pmf_bayes(X, sigma, p, n_samples=100, n_burnin=50, random_seed=0)
    assert result.sigma_prior_mode is None
    assert result.sigma_posterior_mean is None
    assert result.sigma_posterior_std is None
    assert result.sigma_samples is None


# ---------------------------------------------------------------------------
# per_variable mode
# ---------------------------------------------------------------------------

def test_per_variable_basic(synthetic_data):
    """per_variable: result has sigma posterior fields, correct shapes."""
    X, sigma, p = synthetic_data
    m, n = X.shape
    result = pmf_bayes(
        X, sigma, p, n_samples=100, n_burnin=50, random_seed=0,
        sigma_prior="per_variable",
    )
    assert result.sigma_prior_mode == "per_variable"
    assert result.sigma_posterior_mean is not None
    assert result.sigma_posterior_mean.shape == (m,)
    assert result.sigma_posterior_std.shape == (m,)
    assert np.all(result.sigma_posterior_mean > 0)
    assert np.all(np.isfinite(result.sigma_posterior_mean))


# ---------------------------------------------------------------------------
# per_element mode
# ---------------------------------------------------------------------------

def test_per_element_basic(synthetic_data):
    """per_element: result has sigma posterior fields, correct shapes."""
    X, sigma, p = synthetic_data
    m, n = X.shape
    result = pmf_bayes(
        X, sigma, p, n_samples=100, n_burnin=50, random_seed=0,
        sigma_prior="per_element",
    )
    assert result.sigma_prior_mode == "per_element"
    assert result.sigma_posterior_mean.shape == (m, n)
    assert result.sigma_posterior_std.shape == (m, n)
    assert np.all(result.sigma_posterior_mean > 0)


# ---------------------------------------------------------------------------
# store_samples
# ---------------------------------------------------------------------------

def test_store_sigma_samples(synthetic_data):
    """store_samples populates sigma_samples with correct shape."""
    X, sigma, p = synthetic_data
    m, n = X.shape
    ns = 80
    result = pmf_bayes(
        X, sigma, p, n_samples=ns, n_burnin=50, random_seed=0,
        sigma_prior="per_variable", store_samples=True,
    )
    assert result.sigma_samples is not None
    assert result.sigma_samples.shape == (ns, m)
    assert np.all(result.sigma_samples > 0)


# ---------------------------------------------------------------------------
# Categories
# ---------------------------------------------------------------------------

def test_categories_tightness(synthetic_data):
    """'guess' vars have wider posterior than 'measured'."""
    X, sigma, p = synthetic_data
    m, n = X.shape
    cats = np.zeros(m, dtype=int)
    cats[:5] = 0   # measured
    cats[5:] = 1   # guess
    result = pmf_bayes(
        X, sigma, p, n_samples=200, n_burnin=100, random_seed=0,
        sigma_prior="per_variable",
        sigma_categories=cats,
        sigma_prior_params={0: (10.0, None), 1: (1.0, None)},
    )
    # "guess" variables (cat=1) should have wider posterior std
    measured_std = result.sigma_posterior_std[cats == 0].mean()
    guess_std = result.sigma_posterior_std[cats == 1].mean()
    assert guess_std > measured_std


def test_preset_string_keys(synthetic_data):
    """String preset keys work in sigma_prior_params."""
    X, sigma, p = synthetic_data
    m = X.shape[0]
    cats = np.zeros(m, dtype=int)
    cats[:5] = 0
    cats[5:] = 1
    result = pmf_bayes(
        X, sigma, p, n_samples=100, n_burnin=50, random_seed=0,
        sigma_prior="per_variable",
        sigma_categories=cats,
        sigma_prior_params={0: "measured", 1: "guess"},
    )
    assert result.sigma_prior_mode == "per_variable"
    assert result.sigma_posterior_mean is not None


# ---------------------------------------------------------------------------
# Recovery
# ---------------------------------------------------------------------------

def test_recovers_sigma(synthetic_data):
    """sigma_prior recovers known noise scale (within factor of 3)."""
    X, sigma, p = synthetic_data
    # sigma is 0.1 everywhere, so posterior mean of sigma2 should be near 0.01
    result = pmf_bayes(
        X, sigma, p, n_samples=300, n_burnin=200, random_seed=0,
        sigma_prior="per_variable",
    )
    # Should be in the right ballpark (within factor of 3)
    assert np.all(result.sigma_posterior_mean > 0.001)
    assert np.all(result.sigma_posterior_mean < 0.1)


# 7b. Non-contiguous category IDs (e.g., only cats 0 and 3 present)
def test_noncontiguous_categories(synthetic_data):
    X, sigma, p = synthetic_data
    m = X.shape[0]
    cats = np.zeros(m, dtype=int)
    cats[5:] = 3  # skip categories 1 and 2
    result = pmf_bayes(
        X, sigma, p, n_samples=100, n_burnin=50, random_seed=0,
        sigma_prior="per_variable",
        sigma_categories=cats,
        sigma_prior_params={0: (10.0, None), 3: (1.0, None)},
    )
    assert result.sigma_prior_mode == "per_variable"
    assert result.sigma_posterior_mean is not None
    assert result.sigma_posterior_mean.shape == (m,)


# ---------------------------------------------------------------------------
# Input validation
# ---------------------------------------------------------------------------

def test_invalid_sigma_prior(synthetic_data):
    """Invalid sigma_prior raises ValueError."""
    X, sigma, p = synthetic_data
    with pytest.raises(ValueError, match="sigma_prior"):
        pmf_bayes(X, sigma, p, n_samples=50, n_burnin=20, sigma_prior="bad")


def test_wrong_categories_shape(synthetic_data):
    """Wrong categories shape raises ValueError."""
    X, sigma, p = synthetic_data
    with pytest.raises(ValueError, match="sigma_categories"):
        pmf_bayes(
            X, sigma, p, n_samples=50, n_burnin=20,
            sigma_prior="per_variable",
            sigma_categories=np.zeros(3, dtype=int),  # wrong shape
        )


# ---------------------------------------------------------------------------
# Presets
# ---------------------------------------------------------------------------

def test_presets_exist():
    """SIGMA_CATEGORY_PRESETS is a dict with expected keys."""
    assert isinstance(SIGMA_CATEGORY_PRESETS, dict)
    for key in ["measured", "mdl", "analogous", "guess"]:
        assert key in SIGMA_CATEGORY_PRESETS
        alpha, beta = SIGMA_CATEGORY_PRESETS[key]
        assert alpha > 0
        assert beta is None  # auto-initialized


# ---------------------------------------------------------------------------
# Lognormal likelihood
# ---------------------------------------------------------------------------

def test_lognormal_hierarchical():
    """Works with lognormal likelihood."""
    rng = np.random.default_rng(99)
    m, n, p = 10, 20, 2
    F = rng.uniform(0.5, 2.0, size=(m, p))
    G = rng.uniform(0.5, 2.0, size=(p, n))
    X = F @ G * np.exp(rng.normal(0, 0.1, size=(m, n)))
    X = np.maximum(X, 1e-6)
    sigma = 0.1 * X
    result = pmf_bayes(
        X, sigma, p, n_samples=100, n_burnin=50, random_seed=0,
        likelihood="lognormal",
        sigma_prior="per_variable",
    )
    assert result.sigma_prior_mode == "per_variable"
    assert result.sigma_posterior_mean is not None


# ---------------------------------------------------------------------------
# Q and chi2 sanity
# ---------------------------------------------------------------------------

def test_q_reasonable(synthetic_data):
    """Result Q and chi2 are still reasonable with hierarchical sigma."""
    X, sigma, p = synthetic_data
    result = pmf_bayes(
        X, sigma, p, n_samples=200, n_burnin=100, random_seed=0,
        sigma_prior="per_variable",
    )
    assert result.Q > 0
    assert np.isfinite(result.Q)
    assert result.chi2 > 0
    assert result.explained_variance > 0.5
