"""Tests for solvers module."""

import pytest
import numpy as np
import scipy.sparse as sp
from pmf_acls.solvers import (
    NumPySolver,
    PyTorchSolver,
    JAXSolver,
    JAXSparseSolver,
    get_solver,
    solve_pmf_system,
    check_condition_and_warn,
)


class TestNumPySolver:
    """Tests for NumPy solver."""

    @pytest.fixture
    def solver(self):
        """Create NumPy solver instance."""
        return NumPySolver()

    def test_initialization(self, solver):
        """Test solver initialization."""
        assert solver.name == "numpy"

    def test_solve_dense(self, solver):
        """Test solving dense system."""
        # Simple 2x2 system: [2, 1; 1, 2] @ x = [1, 1]
        # Solution: x = [1/3, 1/3]
        A = np.array([[2.0, 1.0], [1.0, 2.0]])
        b = np.array([1.0, 1.0])

        x = solver.solve(A, b)

        np.testing.assert_array_almost_equal(x, [1.0 / 3.0, 1.0 / 3.0])

    def test_solve_sparse(self, solver):
        """Test solving with sparse matrix input."""
        # Same system as above, but sparse
        A = sp.csr_matrix([[2.0, 1.0], [1.0, 2.0]])
        b = np.array([1.0, 1.0])

        x = solver.solve(A, b)

        np.testing.assert_array_almost_equal(x, [1.0 / 3.0, 1.0 / 3.0])

    def test_solve_singular_raises(self, solver):
        """Test that singular matrix raises error."""
        # Singular matrix
        A = np.array([[1.0, 1.0], [1.0, 1.0]])
        b = np.array([1.0, 1.0])

        with pytest.raises(RuntimeError, match="Linear system solve failed"):
            solver.solve(A, b)

    def test_compute_condition_number(self, solver):
        """Test condition number computation."""
        # Well-conditioned matrix
        A = np.eye(3)
        rcond = solver.compute_condition_number(A)
        assert rcond == pytest.approx(1.0)

        # Poorly conditioned matrix
        A_bad = np.array([[1.0, 1.0], [1.0, 1.0 + 1e-10]])
        rcond_bad = solver.compute_condition_number(A_bad)
        assert rcond_bad < 1e-8

    def test_compute_condition_number_singular(self, solver):
        """Test condition number of singular matrix."""
        A = np.array([[1.0, 1.0], [1.0, 1.0]])
        rcond = solver.compute_condition_number(A)
        assert rcond == pytest.approx(0.0)


class TestPyTorchSolver:
    """Tests for PyTorch solver."""

    @pytest.fixture
    def solver(self):
        """Create PyTorch solver instance, skip if PyTorch not available."""
        try:
            return PyTorchSolver()
        except ImportError:
            pytest.skip("PyTorch not installed")

    def test_initialization(self, solver):
        """Test solver initialization."""
        assert solver.name == "pytorch"

    def test_solve_dense(self, solver):
        """Test solving dense system."""
        A = np.array([[2.0, 1.0], [1.0, 2.0]])
        b = np.array([1.0, 1.0])

        x = solver.solve(A, b)

        np.testing.assert_array_almost_equal(x, [1.0 / 3.0, 1.0 / 3.0])

    def test_solve_sparse_converted(self, solver):
        """Test solving with sparse matrix (converted to dense)."""
        A = sp.csr_matrix([[2.0, 1.0], [1.0, 2.0]])
        b = np.array([1.0, 1.0])

        x = solver.solve(A, b)

        np.testing.assert_array_almost_equal(x, [1.0 / 3.0, 1.0 / 3.0])

    def test_solve_larger_system(self, solver):
        """Test solving larger system."""
        n = 50
        A = np.eye(n) * 2.0 + np.ones((n, n)) * 0.1
        b = np.ones(n)

        x = solver.solve(A, b)

        # Verify solution
        np.testing.assert_array_almost_equal(A @ x, b, decimal=10)

    def test_compute_condition_number(self, solver):
        """Test condition number computation."""
        A = np.eye(3)
        rcond = solver.compute_condition_number(A)
        assert rcond == pytest.approx(1.0, rel=1e-6)

    def test_device_auto_detection(self, solver):
        """Test that device is auto-detected."""
        # Should have a device attribute
        assert hasattr(solver, 'device')
        # Device should be one of cpu, cuda, or mps
        assert str(solver.device) in ['cpu', 'cuda', 'mps', 'cuda:0']


class TestJAXSolver:
    """Tests for JAX solver."""

    @pytest.fixture
    def solver(self):
        """Create JAX solver instance, skip if JAX not available."""
        try:
            return JAXSolver()
        except ImportError:
            pytest.skip("JAX not installed")

    def test_initialization(self, solver):
        """Test solver initialization."""
        assert solver.name == "jax"

    def test_solve_dense(self, solver):
        """Test solving dense system."""
        A = np.array([[2.0, 1.0], [1.0, 2.0]])
        b = np.array([1.0, 1.0])

        x = solver.solve(A, b)

        np.testing.assert_array_almost_equal(x, [1.0 / 3.0, 1.0 / 3.0])

    def test_solve_sparse_converted(self, solver):
        """Test solving with sparse matrix (converted to dense)."""
        A = sp.csr_matrix([[2.0, 1.0], [1.0, 2.0]])
        b = np.array([1.0, 1.0])

        x = solver.solve(A, b)

        np.testing.assert_array_almost_equal(x, [1.0 / 3.0, 1.0 / 3.0])

    def test_jit_compilation(self, solver):
        """Test that JIT compilation works."""
        # First solve (may trigger compilation)
        A = np.array([[3.0, 1.0], [1.0, 3.0]])
        b = np.array([2.0, 2.0])
        x1 = solver.solve(A, b)

        # Second solve (should use compiled function)
        x2 = solver.solve(A, b)

        np.testing.assert_array_equal(x1, x2)

    def test_compute_condition_number(self, solver):
        """Test condition number computation."""
        A = np.eye(3)
        rcond = solver.compute_condition_number(A)
        assert rcond == pytest.approx(1.0, rel=1e-6)


class TestJAXSparseSolver:
    """Tests for JAX sparse solver."""

    @pytest.fixture
    def solver(self):
        """Create JAX sparse solver instance, skip if JAX not available."""
        try:
            return JAXSparseSolver()
        except ImportError:
            pytest.skip("JAX not installed")

    def test_initialization(self, solver):
        """Test solver initialization."""
        assert solver.name == "jax_sparse"

    def test_solve_sparse(self, solver):
        """Test solving sparse system."""
        A = sp.csr_matrix([[2.0, 1.0], [1.0, 2.0]])
        b = np.array([1.0, 1.0])

        # Note: Currently falls back to dense, so should still work
        with pytest.warns(UserWarning, match="falling back to dense"):
            x = solver.solve(A, b)

        np.testing.assert_array_almost_equal(x, [1.0 / 3.0, 1.0 / 3.0])


class TestGetSolver:
    """Tests for get_solver function."""

    def test_get_numpy_solver(self):
        """Test getting NumPy solver."""
        solver = get_solver("numpy")
        assert isinstance(solver, NumPySolver)
        assert solver.name == "numpy"

    def test_get_pytorch_solver(self):
        """Test getting PyTorch solver."""
        try:
            solver = get_solver("pytorch")
            assert isinstance(solver, PyTorchSolver)
            assert solver.name == "pytorch"
        except ImportError:
            pytest.skip("PyTorch not installed")

    def test_get_jax_solver(self):
        """Test getting JAX solver."""
        try:
            solver = get_solver("jax")
            assert isinstance(solver, JAXSolver)
        except ImportError:
            pytest.skip("JAX not installed")

    def test_get_jax_sparse_solver(self):
        """Test getting JAX sparse solver."""
        try:
            solver = get_solver("jax_sparse")
            assert isinstance(solver, JAXSparseSolver)
        except ImportError:
            pytest.skip("JAX not installed")

    def test_invalid_solver_name(self):
        """Test error on invalid solver name."""
        with pytest.raises(ValueError, match="Unknown solver"):
            get_solver("invalid_solver")

    def test_jax_not_installed_helpful_message(self):
        """Test helpful error message when JAX not installed."""
        # This test only makes sense if JAX is not installed
        try:
            import jax  # noqa: F401

            pytest.skip("JAX is installed")
        except ImportError:
            with pytest.raises(ImportError, match="requires JAX"):
                get_solver("jax")


class TestCheckConditionAndWarn:
    """Tests for check_condition_and_warn function."""

    def test_well_conditioned_no_warning(self):
        """Test well-conditioned matrix doesn't warn."""
        A = np.eye(3)
        solver = NumPySolver()

        rcond, is_singular = check_condition_and_warn(A, solver)

        assert rcond == pytest.approx(1.0)
        assert not is_singular

    def test_poorly_conditioned_warns(self):
        """Test poorly conditioned matrix warns."""
        # Create poorly conditioned matrix
        A = np.array([[1.0, 1.0], [1.0, 1.0 + 1e-15]])
        solver = NumPySolver()

        with pytest.warns(UserWarning, match="poorly conditioned"):
            rcond, is_singular = check_condition_and_warn(A, solver)

        assert is_singular

    def test_custom_rcond_limit(self):
        """Test custom rcond limit."""
        A = np.array([[1.0, 0.0], [0.0, 1e-6]])  # Condition number ~1e6
        solver = NumPySolver()

        # With high threshold, should warn
        with pytest.warns(UserWarning):
            rcond, is_singular = check_condition_and_warn(A, solver, rcond_limit=1e-5)

        assert is_singular

        # With low threshold, should not warn
        rcond, is_singular = check_condition_and_warn(A, solver, rcond_limit=1e-8)
        assert not is_singular


class TestSolvePMFSystem:
    """Tests for solve_pmf_system function."""

    def test_solve_with_numpy(self):
        """Test solving with NumPy backend."""
        A = np.array([[2.0, 1.0], [1.0, 2.0]])
        b = np.array([1.0, 1.0])

        phi, rcond = solve_pmf_system(A, b, solver_name="numpy")

        np.testing.assert_array_almost_equal(phi, [1.0 / 3.0, 1.0 / 3.0])
        assert rcond is not None
        assert rcond > 0

    def test_solve_with_jax(self):
        """Test solving with JAX backend."""
        try:
            A = np.array([[2.0, 1.0], [1.0, 2.0]])
            b = np.array([1.0, 1.0])

            phi, rcond = solve_pmf_system(A, b, solver_name="jax")

            np.testing.assert_array_almost_equal(phi, [1.0 / 3.0, 1.0 / 3.0])
            assert rcond is not None
        except ImportError:
            pytest.skip("JAX not installed")

    def test_solve_without_condition_check(self):
        """Test solving without condition check."""
        A = np.array([[2.0, 1.0], [1.0, 2.0]])
        b = np.array([1.0, 1.0])

        phi, rcond = solve_pmf_system(A, b, check_condition=False)

        np.testing.assert_array_almost_equal(phi, [1.0 / 3.0, 1.0 / 3.0])
        assert rcond is None

    def test_solve_sparse_matrix(self):
        """Test solving sparse system."""
        A = sp.csr_matrix([[2.0, 1.0], [1.0, 2.0]])
        b = np.array([1.0, 1.0])

        phi, rcond = solve_pmf_system(A, b, solver_name="numpy")

        np.testing.assert_array_almost_equal(phi, [1.0 / 3.0, 1.0 / 3.0])

    def test_solver_consistency(self):
        """Test that different solvers give consistent results."""
        # Create a moderately sized system
        np.random.seed(42)
        n = 10
        A = np.random.rand(n, n)
        A = A @ A.T + np.eye(n)  # Make symmetric positive definite
        b = np.random.rand(n)

        # Solve with NumPy
        phi_numpy, _ = solve_pmf_system(A, b, solver_name="numpy")

        # Solve with JAX if available
        try:
            phi_jax, _ = solve_pmf_system(A, b, solver_name="jax")
            np.testing.assert_array_almost_equal(phi_numpy, phi_jax, decimal=6)
        except ImportError:
            pytest.skip("JAX not installed for consistency check")

    def test_invalid_solver_name(self):
        """Test error on invalid solver name."""
        A = np.array([[1.0, 0.0], [0.0, 1.0]])
        b = np.array([1.0, 1.0])

        with pytest.raises(ValueError, match="Unknown solver"):
            solve_pmf_system(A, b, solver_name="invalid")

    def test_large_system_performance(self):
        """Test that solver works on moderately large system."""
        # This is more of a smoke test than performance test
        np.random.seed(42)
        n = 100
        A = np.random.rand(n, n)
        A = A @ A.T + 0.1 * np.eye(n)  # Well-conditioned
        b = np.random.rand(n)

        phi, rcond = solve_pmf_system(A, b, solver_name="numpy")

        # Check that solution satisfies A @ phi ≈ b
        residual = np.linalg.norm(A @ phi - b)
        assert residual < 1e-6


class TestSolverIntegration:
    """Integration tests for solvers."""

    def test_pmf_like_system(self):
        """Test solving a PMF-like structured system."""
        # Create a system similar to what PMF produces
        # This is Γ^T W Γ + Λr + Λp
        m, n, p = 5, 6, 2
        mn = m * n
        mnp = (m + n) * p

        # Create random Gamma matrix (sparse)
        Gamma = sp.random(mn, mnp, density=0.1, format="csr")

        # Weight matrix (diagonal)
        W = sp.dia_matrix((np.random.rand(mn), 0), shape=(mn, mn))

        # Regularization matrices (diagonal)
        Lambda_r = sp.dia_matrix((np.ones(mnp) * 0.01, 0), shape=(mnp, mnp))
        Lambda_p = sp.dia_matrix((np.ones(mnp) * 0.01, 0), shape=(mnp, mnp))

        # Form LSM = Γ^T W Γ + Λr + Λp
        LSM = Gamma.T @ W @ Gamma + Lambda_r + Lambda_p

        # Create RSV
        RSV = np.random.rand(mnp)

        # Solve with NumPy
        phi, rcond = solve_pmf_system(LSM, RSV, solver_name="numpy")

        # Check dimensions
        assert phi.shape == (mnp,)

        # Check that solution is valid
        assert np.all(np.isfinite(phi))

        # Check that rcond is reasonable
        assert rcond > 1e-10  # Should be well-conditioned with regularization
