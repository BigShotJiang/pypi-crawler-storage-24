"""Tests for full Bayesian mode: volume prior + sparse Gamma priors."""

import numpy as np
import pytest
from pmf_acls.bayes import pmf_bayes, BayesNMFResult


@pytest.fixture
def synthetic_data():
    """Small synthetic PMF problem: m=12, n=40, p=3."""
    rng = np.random.default_rng(42)
    m, n, p = 12, 40, 3
    F_true = rng.uniform(0.1, 2.0, size=(m, p))
    G_true = rng.uniform(0.1, 2.0, size=(p, n))
    X = F_true @ G_true + 0.1 * rng.standard_normal((m, n))
    X = np.maximum(X, 0.0)
    sigma = 0.1 * np.ones((m, n))
    return X, sigma, p


# --- Volume prior ---


def test_volume_prior_smoke(synthetic_data):
    """volume_alpha > 0 with warm_start=False runs without error."""
    X, sigma, p = synthetic_data
    result = pmf_bayes(
        X, sigma, p, n_samples=100, n_burnin=50, random_seed=42,
        warm_start=False, volume_alpha=2.0,
    )
    assert isinstance(result, BayesNMFResult)
    assert result.F.shape == (X.shape[0], p)
    assert result.G.shape == (p, X.shape[1])
    assert np.all(np.isfinite(result.F))
    assert np.all(np.isfinite(result.G))
    assert np.all(result.F >= 0)
    assert np.all(result.G >= 0)
    assert result.volume_alpha == 2.0


def test_volume_prior_mh_acceptance(synthetic_data):
    """MH acceptance rate is tracked and between 0 and 1."""
    X, sigma, p = synthetic_data
    result = pmf_bayes(
        X, sigma, p, n_samples=100, n_burnin=50, random_seed=42,
        warm_start=False, volume_alpha=2.0,
    )
    assert result.mh_volume_acceptance_rate is not None
    assert 0.0 <= result.mh_volume_acceptance_rate <= 1.0


def test_volume_prior_off_by_default(synthetic_data):
    """Default volume_alpha=0 gives None acceptance rate."""
    X, sigma, p = synthetic_data
    result = pmf_bayes(
        X, sigma, p, n_samples=50, n_burnin=25, random_seed=42,
    )
    assert result.volume_alpha == 0.0
    assert result.mh_volume_acceptance_rate is None


def test_volume_prior_improves_separation(synthetic_data):
    """Volume prior yields lower pairwise cosine similarity than no prior."""
    X, sigma, p = synthetic_data

    # Baseline: no volume prior, random init
    r0 = pmf_bayes(
        X, sigma, p, n_samples=200, n_burnin=100, random_seed=42,
        warm_start=False, volume_alpha=0.0,
    )
    # With volume prior
    r1 = pmf_bayes(
        X, sigma, p, n_samples=200, n_burnin=100, random_seed=42,
        warm_start=False, volume_alpha=3.0,
    )

    def max_offdiag_cosine(F):
        norms = np.linalg.norm(F, axis=0)
        sim = (F.T @ F) / np.maximum(np.outer(norms, norms), 1e-30)
        np.fill_diagonal(sim, 0)
        return sim.max()

    sim0 = max_offdiag_cosine(r0.F_posterior_mean)
    sim1 = max_offdiag_cosine(r1.F_posterior_mean)
    # Volume prior should yield better or equal separation
    assert sim1 <= sim0 + 0.1, (
        f"Volume prior didn't improve separation: sim0={sim0:.3f}, sim1={sim1:.3f}"
    )


def test_volume_alpha_zero_matches_default(synthetic_data):
    """volume_alpha=0.0 with same seed gives identical results to default."""
    X, sigma, p = synthetic_data
    r0 = pmf_bayes(X, sigma, p, n_samples=50, n_burnin=25, random_seed=99)
    r1 = pmf_bayes(X, sigma, p, n_samples=50, n_burnin=25, random_seed=99,
                    volume_alpha=0.0)
    np.testing.assert_allclose(r0.F, r1.F)
    np.testing.assert_allclose(r0.G, r1.G)
    np.testing.assert_allclose(r0.Q_samples, r1.Q_samples)


# --- Sparse Gamma prior ---


def test_sparse_gamma_smoke(synthetic_data):
    """prior_F_shape < 1 runs without error."""
    X, sigma, p = synthetic_data
    result = pmf_bayes(
        X, sigma, p, n_samples=50, n_burnin=25, random_seed=42,
        prior_F_shape=0.5,
    )
    assert isinstance(result, BayesNMFResult)
    assert result.prior_F_shape == 0.5
    assert result.prior_G_shape == 1.0
    assert np.all(np.isfinite(result.F))
    assert np.all(result.F >= 0)


def test_gamma_shape_one_matches_exponential(synthetic_data):
    """Gamma(1.0, lambda) = Exponential(lambda) — identical results."""
    X, sigma, p = synthetic_data
    r0 = pmf_bayes(X, sigma, p, n_samples=50, n_burnin=25, random_seed=99)
    r1 = pmf_bayes(X, sigma, p, n_samples=50, n_burnin=25, random_seed=99,
                    prior_F_shape=1.0, prior_G_shape=1.0)
    np.testing.assert_allclose(r0.F, r1.F)
    np.testing.assert_allclose(r0.G, r1.G)
    np.testing.assert_allclose(r0.Q_samples, r1.Q_samples)


def test_sparse_gamma_G(synthetic_data):
    """prior_G_shape < 1 runs without error."""
    X, sigma, p = synthetic_data
    result = pmf_bayes(
        X, sigma, p, n_samples=50, n_burnin=25, random_seed=42,
        prior_G_shape=0.5,
    )
    assert result.prior_G_shape == 0.5
    assert np.all(np.isfinite(result.G))
    assert np.all(result.G >= 0)


# --- Composition with other features ---


def test_volume_plus_robust(synthetic_data):
    """Volume prior + robust Student's t composes without error."""
    X, sigma, p = synthetic_data
    result = pmf_bayes(
        X, sigma, p, n_samples=50, n_burnin=25, random_seed=42,
        warm_start=False, volume_alpha=2.0, robust=True, robust_df=5.0,
    )
    assert np.all(np.isfinite(result.F))
    assert result.eta_posterior_mean is not None


def test_volume_plus_hierarchical(synthetic_data):
    """Volume prior + hierarchical sigma composes without error."""
    X, sigma, p = synthetic_data
    result = pmf_bayes(
        X, sigma, p, n_samples=50, n_burnin=25, random_seed=42,
        warm_start=False, volume_alpha=2.0,
        sigma_prior="per_variable",
    )
    assert np.all(np.isfinite(result.F))
    assert result.sigma_posterior_mean is not None


def test_volume_with_lognormal(synthetic_data):
    """Volume prior works with lognormal likelihood."""
    X, sigma, p = synthetic_data
    # Ensure X > 0 for lognormal
    X = np.maximum(X, 0.01)
    result = pmf_bayes(
        X, sigma, p, n_samples=50, n_burnin=25, random_seed=42,
        warm_start=False, volume_alpha=2.0,
        likelihood="lognormal",
    )
    assert np.all(np.isfinite(result.F))
    assert result.mh_volume_acceptance_rate is not None


def test_sparse_gamma_with_lognormal(synthetic_data):
    """Sparse Gamma prior works with lognormal likelihood."""
    X, sigma, p = synthetic_data
    X = np.maximum(X, 0.01)
    result = pmf_bayes(
        X, sigma, p, n_samples=50, n_burnin=25, random_seed=42,
        prior_F_shape=0.5, prior_G_shape=0.5,
        likelihood="lognormal",
    )
    assert np.all(np.isfinite(result.F))


# --- Validation ---


def test_volume_alpha_negative_raises():
    """Negative volume_alpha raises ValueError."""
    X = np.ones((5, 10))
    sigma = np.ones((5, 10))
    with pytest.raises(ValueError, match="volume_alpha"):
        pmf_bayes(X, sigma, 2, volume_alpha=-1.0)


def test_prior_shape_zero_raises():
    """Zero prior shape raises ValueError."""
    X = np.ones((5, 10))
    sigma = np.ones((5, 10))
    with pytest.raises(ValueError, match="prior_F_shape"):
        pmf_bayes(X, sigma, 2, prior_F_shape=0.0)
    with pytest.raises(ValueError, match="prior_G_shape"):
        pmf_bayes(X, sigma, 2, prior_G_shape=0.0)


# --- Adaptive relabeling ---


def test_adaptive_relabeling_no_warm_start(synthetic_data):
    """Without warm_start, adaptive relabeling still produces distinct factors."""
    X, sigma, p = synthetic_data
    result = pmf_bayes(
        X, sigma, p, n_samples=200, n_burnin=100, random_seed=42,
        warm_start=False, volume_alpha=2.0,
    )
    # Factors should be distinct (pairwise cosine sim < 0.95)
    F = result.F_posterior_mean
    norms = np.linalg.norm(F, axis=0)
    sim = (F.T @ F) / np.maximum(np.outer(norms, norms), 1e-30)
    np.fill_diagonal(sim, 0)
    assert sim.max() < 0.95, (
        f"Factors not sufficiently distinct: max cosine sim = {sim.max():.3f}"
    )
