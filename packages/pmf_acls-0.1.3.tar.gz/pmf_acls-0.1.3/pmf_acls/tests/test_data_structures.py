"""Tests for data structures module."""

import pytest
import numpy as np
from pmf_acls.data_structures import PMFResult, FactorSelectionResult, UncertaintyResult


class TestPMFResult:
    """Tests for PMFResult class."""

    @pytest.fixture
    def sample_result(self):
        """Create a sample PMFResult for testing."""
        m, n, p = 10, 20, 3
        F = np.random.rand(m, p)
        G = np.random.rand(p, n)
        residuals = np.random.randn(m, n) * 0.1
        Q_history = [100.0, 50.0, 25.0, 20.0, 19.5]

        return PMFResult(
            F=F,
            G=G,
            Q=19.5,
            Q_history=Q_history,
            n_iter=5,
            converged=True,
            residuals=residuals,
            explained_variance=0.95,
            chi2=1.02,
        )

    def test_initialization(self, sample_result):
        """Test PMFResult initialization."""
        assert sample_result.F.shape == (10, 3)
        assert sample_result.G.shape == (3, 20)
        assert sample_result.Q == 19.5
        assert sample_result.converged is True
        assert sample_result.explained_variance == 0.95

    def test_repr(self, sample_result):
        """Test string representation."""
        repr_str = repr(sample_result)
        assert "PMFResult" in repr_str
        assert "10 variables" in repr_str
        assert "20 observations" in repr_str
        assert "3 factors" in repr_str
        assert "Converged: Yes" in repr_str

    def test_to_dict(self, sample_result):
        """Test conversion to dictionary."""
        result_dict = sample_result.to_dict()
        assert isinstance(result_dict, dict)
        assert "F" in result_dict
        assert "G" in result_dict
        assert "Q" in result_dict
        assert np.array_equal(result_dict["F"], sample_result.F)

    def test_summary(self, sample_result, capsys):
        """Test summary output."""
        sample_result.summary()
        captured = capsys.readouterr()
        assert "PMF Result Summary" in captured.out
        assert "Converged: Yes" in captured.out
        assert "Explained variance" in captured.out

    def test_with_uncertainty(self):
        """Test PMFResult with uncertainty estimates."""
        m, n, p = 5, 10, 2
        F = np.random.rand(m, p)
        G = np.random.rand(p, n)
        F_std = np.random.rand(m, p) * 0.1
        G_std = np.random.rand(p, n) * 0.1

        result = PMFResult(
            F=F,
            G=G,
            Q=10.0,
            Q_history=[10.0],
            n_iter=1,
            converged=True,
            residuals=np.zeros((m, n)),
            explained_variance=0.99,
            chi2=1.0,
            F_std=F_std,
            G_std=G_std,
        )

        assert result.F_std is not None
        assert result.G_std is not None
        assert result.F_std.shape == (m, p)


class TestFactorSelectionResult:
    """Tests for FactorSelectionResult class."""

    @pytest.fixture
    def sample_selection(self):
        """Create a sample FactorSelectionResult."""
        p_values = [2, 3, 4, 5]
        Q_values = {
            2: [100.0, 102.0, 98.0],
            3: [50.0, 52.0, 48.0],
            4: [45.0, 47.0, 44.0],
            5: [43.0, 46.0, 42.0],
        }
        Q_robust = {2: 1.5, 3: 1.0, 4: 0.95, 5: 0.92}
        best_p = 3

        # Create dummy best results
        best_results = {}
        for p in p_values:
            m, n = 10, 20
            best_results[p] = PMFResult(
                F=np.random.rand(m, p),
                G=np.random.rand(p, n),
                Q=min(Q_values[p]),
                Q_history=[min(Q_values[p])],
                n_iter=10,
                converged=True,
                residuals=np.zeros((m, n)),
                explained_variance=0.9,
                chi2=1.0,
            )

        return FactorSelectionResult(
            p_values=p_values,
            Q_values=Q_values,
            Q_robust=Q_robust,
            best_p=best_p,
            best_results=best_results,
        )

    def test_initialization(self, sample_selection):
        """Test FactorSelectionResult initialization."""
        assert sample_selection.p_values == [2, 3, 4, 5]
        assert sample_selection.best_p == 3
        assert len(sample_selection.Q_values) == 4

    def test_repr(self, sample_selection):
        """Test string representation."""
        repr_str = repr(sample_selection)
        assert "FactorSelectionResult" in repr_str
        assert "Recommended p: 3" in repr_str

    def test_summary(self, sample_selection, capsys):
        """Test summary output."""
        sample_selection.summary()
        captured = capsys.readouterr()
        assert "Factor Selection Summary" in captured.out
        assert "Recommended p: 3" in captured.out
        assert "<-- Best" in captured.out


class TestUncertaintyResult:
    """Tests for UncertaintyResult class."""

    @pytest.fixture
    def sample_uncertainty(self):
        """Create a sample UncertaintyResult."""
        m, n, p = 10, 20, 3
        n_bootstrap = 50

        F_mean = np.random.rand(m, p)
        F_std = np.random.rand(m, p) * 0.1
        G_mean = np.random.rand(p, n)
        G_std = np.random.rand(p, n) * 0.1

        # Create dummy bootstrap results
        bootstrap_results = []
        for _ in range(n_bootstrap):
            bootstrap_results.append(
                PMFResult(
                    F=F_mean + np.random.randn(m, p) * F_std,
                    G=G_mean + np.random.randn(p, n) * G_std,
                    Q=10.0,
                    Q_history=[10.0],
                    n_iter=10,
                    converged=True,
                    residuals=np.zeros((m, n)),
                    explained_variance=0.9,
                    chi2=1.0,
                )
            )

        return UncertaintyResult(
            F_mean=F_mean,
            F_std=F_std,
            G_mean=G_mean,
            G_std=G_std,
            bootstrap_results=bootstrap_results,
        )

    def test_initialization(self, sample_uncertainty):
        """Test UncertaintyResult initialization."""
        assert sample_uncertainty.F_mean.shape == (10, 3)
        assert sample_uncertainty.G_mean.shape == (3, 20)
        assert len(sample_uncertainty.bootstrap_results) == 50

    def test_repr(self, sample_uncertainty):
        """Test string representation."""
        repr_str = repr(sample_uncertainty)
        assert "UncertaintyResult" in repr_str
        assert "Bootstrap samples: 50" in repr_str
        assert "10 variables" in repr_str

    def test_summary(self, sample_uncertainty, capsys):
        """Test summary output."""
        sample_uncertainty.summary()
        captured = capsys.readouterr()
        assert "Bootstrap Uncertainty Summary" in captured.out
        assert "Bootstrap samples: 50" in captured.out
        assert "F Matrix Uncertainty" in captured.out
        assert "G Matrix Uncertainty" in captured.out

    def test_with_percentiles(self):
        """Test UncertaintyResult with percentiles."""
        m, n, p = 5, 10, 2

        F_percentiles = {
            5: np.random.rand(m, p),
            95: np.random.rand(m, p),
        }
        G_percentiles = {
            5: np.random.rand(p, n),
            95: np.random.rand(p, n),
        }

        result = UncertaintyResult(
            F_mean=np.random.rand(m, p),
            F_std=np.random.rand(m, p) * 0.1,
            G_mean=np.random.rand(p, n),
            G_std=np.random.rand(p, n) * 0.1,
            bootstrap_results=[],
            F_percentiles=F_percentiles,
            G_percentiles=G_percentiles,
        )

        assert 5 in result.F_percentiles
        assert 95 in result.F_percentiles

        # Test summary with percentiles
        result.summary()
