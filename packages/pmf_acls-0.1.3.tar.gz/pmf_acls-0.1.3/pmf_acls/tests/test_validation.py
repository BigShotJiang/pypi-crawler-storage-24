"""Tests for validation module."""

import pytest
import numpy as np
from pmf_acls.validation import (
    validate_data_matrix,
    validate_uncertainty_matrix,
    validate_rank,
    validate_initial_matrix,
    validate_mode,
    validate_solver,
    validate_positive_scalar,
    validate_integer_range,
    validate_strength_coefficient,
    validate_boolean,
)


class TestValidateDataMatrix:
    """Tests for validate_data_matrix function."""

    def test_valid_matrix(self):
        """Test with valid matrix."""
        X = np.random.rand(10, 20)
        validate_data_matrix(X)  # Should not raise

    def test_not_numpy_array(self):
        """Test with non-numpy input."""
        with pytest.raises(ValueError, match="must be a numpy array"):
            validate_data_matrix([[1, 2], [3, 4]])

    def test_not_2d(self):
        """Test with non-2D array."""
        with pytest.raises(ValueError, match="must be 2-dimensional"):
            validate_data_matrix(np.array([1, 2, 3]))

    def test_empty_matrix(self):
        """Test with empty matrix."""
        with pytest.raises(ValueError, match="must not be empty"):
            validate_data_matrix(np.array([]).reshape(0, 0))

    def test_contains_nan(self):
        """Test with NaN values."""
        X = np.array([[1.0, 2.0], [np.nan, 4.0]])
        with pytest.raises(ValueError, match="contains non-finite values"):
            validate_data_matrix(X)

    def test_contains_inf(self):
        """Test with infinite values."""
        X = np.array([[1.0, 2.0], [np.inf, 4.0]])
        with pytest.raises(ValueError, match="contains non-finite values"):
            validate_data_matrix(X)


class TestValidateUncertaintyMatrix:
    """Tests for validate_uncertainty_matrix function."""

    def test_valid_sigma(self):
        """Test with valid uncertainty matrix."""
        sigma = np.ones((10, 20))
        validate_uncertainty_matrix(sigma, (10, 20))  # Should not raise

    def test_wrong_shape(self):
        """Test with wrong shape."""
        sigma = np.ones((10, 15))
        with pytest.raises(ValueError, match="does not match"):
            validate_uncertainty_matrix(sigma, (10, 20))

    def test_non_positive_values(self):
        """Test with non-positive values."""
        sigma = np.array([[1.0, 2.0], [0.0, 4.0]])
        with pytest.raises(ValueError, match="must contain only positive"):
            validate_uncertainty_matrix(sigma, (2, 2))

    def test_negative_values(self):
        """Test with negative values."""
        sigma = np.array([[1.0, 2.0], [-1.0, 4.0]])
        with pytest.raises(ValueError, match="must contain only positive"):
            validate_uncertainty_matrix(sigma, (2, 2))


class TestValidateRank:
    """Tests for validate_rank function."""

    def test_valid_rank(self):
        """Test with valid rank."""
        validate_rank(3, 10, 20)  # Should not raise

    def test_not_integer(self):
        """Test with non-integer rank."""
        with pytest.raises(ValueError, match="must be an integer"):
            validate_rank(3.5, 10, 20)

    def test_rank_less_than_one(self):
        """Test with p < 1."""
        with pytest.raises(ValueError, match="must be at least 1"):
            validate_rank(0, 10, 20)

    def test_rank_too_large(self):
        """Test with p > min(m, n)."""
        with pytest.raises(ValueError, match="exceeds min"):
            validate_rank(15, 10, 20)

    def test_large_rank_warning(self):
        """Test warning for large rank."""
        with pytest.warns(UserWarning, match="Large p"):
            validate_rank(8, 10, 20)


class TestValidateInitialMatrix:
    """Tests for validate_initial_matrix function."""

    def test_valid_matrix(self):
        """Test with valid initial matrix."""
        F_init = np.random.rand(10, 3)
        validate_initial_matrix(F_init, (10, 3), "F_init")

    def test_none_allowed(self):
        """Test with None when allowed."""
        validate_initial_matrix(None, (10, 3), "F_init", allow_none=True)

    def test_none_not_allowed(self):
        """Test with None when not allowed."""
        with pytest.raises(ValueError, match="cannot be None"):
            validate_initial_matrix(None, (10, 3), "F_init", allow_none=False)

    def test_wrong_shape(self):
        """Test with wrong shape."""
        F_init = np.random.rand(10, 5)
        with pytest.raises(ValueError, match="does not match expected"):
            validate_initial_matrix(F_init, (10, 3), "F_init")

    def test_negative_values(self):
        """Test with negative values."""
        F_init = np.array([[1.0, 2.0], [-1.0, 4.0]])
        with pytest.raises(ValueError, match="must be non-negative"):
            validate_initial_matrix(F_init, (2, 2), "F_init")


class TestValidateMode:
    """Tests for validate_mode function."""

    def test_valid_modes(self):
        """Test with valid modes."""
        for mode in ["basic", "regularized", "full"]:
            validate_mode(mode)  # Should not raise

    def test_invalid_mode(self):
        """Test with invalid mode."""
        with pytest.raises(ValueError, match="mode must be one of"):
            validate_mode("invalid")


class TestValidateSolver:
    """Tests for validate_solver function."""

    def test_numpy_solver(self):
        """Test numpy solver (always available)."""
        validate_solver("numpy")  # Should not raise

    def test_invalid_solver(self):
        """Test with invalid solver."""
        with pytest.raises(ValueError, match="solver must be one of"):
            validate_solver("invalid")

    def test_jax_solver_not_installed(self):
        """Test JAX solver when JAX not installed."""
        # This test will pass if JAX is installed, skip otherwise
        try:
            import jax  # noqa: F401

            validate_solver("jax")  # Should not raise if JAX available
        except ImportError:
            with pytest.raises(ValueError, match="requires JAX"):
                validate_solver("jax")


class TestValidatePositiveScalar:
    """Tests for validate_positive_scalar function."""

    def test_valid_positive(self):
        """Test with valid positive values."""
        validate_positive_scalar(1.0, "test")
        validate_positive_scalar(100, "test")
        validate_positive_scalar(1e-10, "test")

    def test_zero_not_allowed(self):
        """Test with zero when not allowed."""
        with pytest.raises(ValueError, match="must be > 0"):
            validate_positive_scalar(0, "test", allow_zero=False)

    def test_zero_allowed(self):
        """Test with zero when allowed."""
        validate_positive_scalar(0, "test", allow_zero=True)

    def test_negative(self):
        """Test with negative value."""
        with pytest.raises(ValueError, match="must be"):
            validate_positive_scalar(-1, "test")

    def test_nan(self):
        """Test with NaN."""
        with pytest.raises(ValueError, match="must be finite"):
            validate_positive_scalar(np.nan, "test")

    def test_inf(self):
        """Test with infinity."""
        with pytest.raises(ValueError, match="must be finite"):
            validate_positive_scalar(np.inf, "test")


class TestValidateIntegerRange:
    """Tests for validate_integer_range function."""

    def test_valid_in_range(self):
        """Test with valid value in range."""
        validate_integer_range(5, "test", min_val=1, max_val=10)

    def test_at_min(self):
        """Test at minimum value."""
        validate_integer_range(1, "test", min_val=1, max_val=10)

    def test_at_max(self):
        """Test at maximum value."""
        validate_integer_range(10, "test", min_val=1, max_val=10)

    def test_below_min(self):
        """Test below minimum."""
        with pytest.raises(ValueError, match="must be >= 1"):
            validate_integer_range(0, "test", min_val=1)

    def test_above_max(self):
        """Test above maximum."""
        with pytest.raises(ValueError, match="must be <= 10"):
            validate_integer_range(11, "test", max_val=10)

    def test_not_integer(self):
        """Test with non-integer."""
        with pytest.raises(ValueError, match="must be an integer"):
            validate_integer_range(5.5, "test")


class TestValidateStrengthCoefficient:
    """Tests for validate_strength_coefficient function."""

    def test_auto_string(self):
        """Test with 'auto' string."""
        result = validate_strength_coefficient("auto", "test")
        assert result == "auto"

    def test_valid_number(self):
        """Test with valid number."""
        result = validate_strength_coefficient(1.5, "test")
        assert result == 1.5

    def test_zero(self):
        """Test with zero."""
        result = validate_strength_coefficient(0.0, "test")
        assert result == 0.0

    def test_negative(self):
        """Test with negative value."""
        with pytest.raises(ValueError):
            validate_strength_coefficient(-1.0, "test")

    def test_invalid_string(self):
        """Test with invalid string."""
        with pytest.raises(ValueError, match="must be 'auto'"):
            validate_strength_coefficient("invalid", "test")


class TestValidateBoolean:
    """Tests for validate_boolean function."""

    def test_valid_bool(self):
        """Test with boolean values."""
        validate_boolean(True, "test")
        validate_boolean(False, "test")

    def test_numpy_bool(self):
        """Test with numpy boolean."""
        validate_boolean(np.bool_(True), "test")

    def test_not_bool(self):
        """Test with non-boolean."""
        with pytest.raises(ValueError, match="must be boolean"):
            validate_boolean(1, "test")

        with pytest.raises(ValueError, match="must be boolean"):
            validate_boolean("True", "test")
