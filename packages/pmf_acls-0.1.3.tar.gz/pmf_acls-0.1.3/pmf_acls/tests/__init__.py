"""Tests for PMF package."""
