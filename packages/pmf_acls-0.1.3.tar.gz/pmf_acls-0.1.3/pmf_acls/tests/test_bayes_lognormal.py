"""
Tests for Bayesian NMF with log-normal likelihood.
"""

import numpy as np
import pytest

from pmf_acls.bayes import pmf_bayes
from pmf_acls.bayes_diagnostics import compute_waic


# ---- Fixtures ----

@pytest.fixture
def rng():
    return np.random.default_rng(42)


@pytest.fixture
def lognormal_data(rng):
    """Synthetic log-normal data with 3 true factors."""
    m, n, p = 15, 25, 3
    F_true = rng.exponential(1.0, size=(m, p))
    G_true = rng.exponential(1.0, size=(p, n))
    X_true = F_true @ G_true
    # Log-normal noise: multiply by exp(noise)
    sigma = 0.1 * X_true
    noise = rng.normal(0, 0.1, size=(m, n))
    X = X_true * np.exp(noise)
    return X, sigma, p


# ============================================================================
# Basic smoke tests
# ============================================================================


class TestLognormalSmoke:
    def test_runs_and_returns(self, lognormal_data):
        """Log-normal likelihood runs without error."""
        X, sigma, p = lognormal_data
        result = pmf_bayes(
            X, sigma, p,
            n_samples=50, n_burnin=50,
            likelihood="lognormal",
            random_seed=42,
        )
        assert result.F.shape == (X.shape[0], p)
        assert result.G.shape == (p, X.shape[1])
        assert np.isfinite(result.Q)
        assert result.likelihood == "lognormal"

    def test_shapes_match_gaussian(self, lognormal_data):
        """Log-normal result has same shapes as Gaussian."""
        X, sigma, p = lognormal_data
        r_gauss = pmf_bayes(X, sigma, p, n_samples=30, n_burnin=30,
                            likelihood="gaussian", random_seed=42)
        r_logn = pmf_bayes(X, sigma, p, n_samples=30, n_burnin=30,
                           likelihood="lognormal", random_seed=42)
        assert r_gauss.F.shape == r_logn.F.shape
        assert r_gauss.G.shape == r_logn.G.shape
        assert r_gauss.Q_samples.shape == r_logn.Q_samples.shape

    def test_nonnegative_factors(self, lognormal_data):
        """F and G are non-negative under log-normal."""
        X, sigma, p = lognormal_data
        result = pmf_bayes(
            X, sigma, p,
            n_samples=50, n_burnin=50,
            likelihood="lognormal",
            random_seed=42,
        )
        assert np.all(result.F >= 0)
        assert np.all(result.G >= 0)

    def test_store_samples(self, lognormal_data):
        """store_samples works with log-normal."""
        X, sigma, p = lognormal_data
        result = pmf_bayes(
            X, sigma, p,
            n_samples=20, n_burnin=20,
            likelihood="lognormal",
            store_samples=True,
            random_seed=42,
        )
        assert result.F_samples is not None
        assert result.G_samples is not None
        assert result.F_samples.shape == (20, X.shape[0], p)
        assert result.G_samples.shape == (20, p, X.shape[1])


# ============================================================================
# MH acceptance rate
# ============================================================================


class TestMHAcceptance:
    def test_acceptance_rate_populated(self, lognormal_data):
        """Log-normal result has mh_acceptance_rate."""
        X, sigma, p = lognormal_data
        result = pmf_bayes(
            X, sigma, p,
            n_samples=50, n_burnin=50,
            likelihood="lognormal",
            random_seed=42,
        )
        assert result.mh_acceptance_rate is not None
        assert 0.0 <= result.mh_acceptance_rate <= 1.0

    def test_acceptance_rate_reasonable(self, lognormal_data):
        """Acceptance rate is in a reasonable range (not 0 or 1)."""
        X, sigma, p = lognormal_data
        result = pmf_bayes(
            X, sigma, p,
            n_samples=100, n_burnin=100,
            likelihood="lognormal",
            random_seed=42,
        )
        # Should be between 5% and 95% with default step sizes
        assert result.mh_acceptance_rate > 0.01
        assert result.mh_acceptance_rate < 0.99

    def test_gaussian_no_mh_rate(self, lognormal_data):
        """Gaussian result has mh_acceptance_rate=None."""
        X, sigma, p = lognormal_data
        result = pmf_bayes(
            X, sigma, p,
            n_samples=30, n_burnin=30,
            likelihood="gaussian",
            random_seed=42,
        )
        assert result.mh_acceptance_rate is None


# ============================================================================
# Validation
# ============================================================================


class TestLognormalValidation:
    def test_x_zero_raises(self, rng):
        """X with zeros raises ValueError for lognormal."""
        m, n, p = 10, 15, 2
        X = rng.exponential(1.0, size=(m, n))
        X[0, 0] = 0.0
        sigma = 0.1 * np.ones((m, n))
        with pytest.raises(ValueError, match="X > 0"):
            pmf_bayes(X, sigma, p, likelihood="lognormal")

    def test_x_negative_raises(self, rng):
        """X with negative values raises ValueError for lognormal."""
        m, n, p = 10, 15, 2
        X = rng.exponential(1.0, size=(m, n))
        X[1, 2] = -0.5
        sigma = 0.1 * np.ones((m, n))
        with pytest.raises(ValueError, match="X > 0"):
            pmf_bayes(X, sigma, p, likelihood="lognormal")

    def test_invalid_likelihood_raises(self, rng):
        """Invalid likelihood string raises ValueError."""
        m, n, p = 10, 15, 2
        X = rng.exponential(1.0, size=(m, n))
        sigma = 0.1 * np.ones((m, n))
        with pytest.raises(ValueError, match="likelihood"):
            pmf_bayes(X, sigma, p, likelihood="poisson")


# ============================================================================
# Convergence quality
# ============================================================================


class TestLognormalConvergence:
    def test_reconstruction_quality(self, rng):
        """Log-normal solver recovers factors on clean log-normal data."""
        m, n, p = 20, 30, 2
        F_true = rng.exponential(1.0, size=(m, p))
        G_true = rng.exponential(1.0, size=(p, n))
        X_true = F_true @ G_true
        # Small log-normal noise
        sigma = 0.05 * X_true
        X = X_true * np.exp(rng.normal(0, 0.05, size=(m, n)))

        result = pmf_bayes(
            X, sigma, p,
            n_samples=200, n_burnin=200,
            likelihood="lognormal",
            random_seed=42,
        )
        assert result.explained_variance > 0.8

    def test_q_samples_finite(self, lognormal_data):
        """All Q samples are finite."""
        X, sigma, p = lognormal_data
        result = pmf_bayes(
            X, sigma, p,
            n_samples=50, n_burnin=50,
            likelihood="lognormal",
            random_seed=42,
        )
        assert np.all(np.isfinite(result.Q_samples))


# ============================================================================
# ARD + lognormal
# ============================================================================


class TestLognormalARD:
    def test_ard_with_lognormal(self, lognormal_data):
        """ARD works with log-normal likelihood."""
        X, sigma, p = lognormal_data
        result = pmf_bayes(
            X, sigma, p,
            n_samples=50, n_burnin=50,
            likelihood="lognormal",
            ard=True,
            random_seed=42,
        )
        assert result.active_factors is not None
        assert result.effective_p is not None
        assert result.ard_lambda_F is not None


# ============================================================================
# WAIC with lognormal
# ============================================================================


class TestLognormalWAIC:
    def test_waic_lognormal(self, lognormal_data):
        """WAIC computed with lognormal likelihood."""
        X, sigma, p = lognormal_data
        result = pmf_bayes(
            X, sigma, p,
            n_samples=30, n_burnin=30,
            likelihood="lognormal",
            store_samples=True,
            random_seed=42,
        )
        waic = compute_waic(X, sigma, result.F_samples, result.G_samples,
                            likelihood="lognormal")
        assert np.isfinite(waic["waic"])
        assert np.isfinite(waic["lppd"])
        assert waic["se"] >= 0


# ============================================================================
# repr
# ============================================================================


class TestLognormalRepr:
    def test_repr_shows_likelihood(self, lognormal_data):
        """Repr includes likelihood info for lognormal."""
        X, sigma, p = lognormal_data
        result = pmf_bayes(
            X, sigma, p,
            n_samples=30, n_burnin=30,
            likelihood="lognormal",
            random_seed=42,
        )
        r = repr(result)
        assert "lognormal" in r
        assert "MH accept" in r

    def test_repr_gaussian_no_likelihood_line(self, lognormal_data):
        """Repr does not show likelihood line for gaussian (default)."""
        X, sigma, p = lognormal_data
        result = pmf_bayes(
            X, sigma, p,
            n_samples=30, n_burnin=30,
            likelihood="gaussian",
            random_seed=42,
        )
        r = repr(result)
        assert "lognormal" not in r
