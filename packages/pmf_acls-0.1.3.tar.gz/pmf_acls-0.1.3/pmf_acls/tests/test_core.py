"""Tests for core PMF algorithm."""

import pytest
import numpy as np
from pmf_acls import pmf, fpeak_sweep, PMFResult, FPEAKSweepResult


class TestPMFBasic:
    """Basic tests for PMF algorithm."""

    def test_simple_factorization(self):
        """Test PMF on simple known factorization."""
        np.random.seed(42)

        # Create simple factorization: X = F @ G + noise
        m, n, p = 10, 20, 3
        F_true = np.random.rand(m, p) + 0.5
        G_true = np.random.rand(p, n) + 0.5
        noise = np.random.randn(m, n) * 0.1

        X = F_true @ G_true + noise
        sigma = np.ones_like(X) * 0.1

        # Run PMF
        result = pmf(X, sigma, p=3, max_iter=100, random_seed=42)

        # Check result type
        assert isinstance(result, PMFResult)

        # Check dimensions
        assert result.F.shape == (m, p)
        assert result.G.shape == (p, n)

        # Check non-negativity
        assert np.all(result.F >= 0)
        assert np.all(result.G >= 0)

        # Check that result is valid (PMF may not recover exact factorization)
        # Just verify basic properties
        assert result.explained_variance > 0.0  # Should explain some variance
        assert np.all(np.isfinite(result.F))
        assert np.all(np.isfinite(result.G))

    def test_perfect_fit_no_noise(self):
        """Test PMF runs successfully on noiseless data."""
        np.random.seed(42)

        # Create data from known factorization
        m, n, p = 5, 10, 2
        F_true = np.random.rand(m, p) + 0.5
        G_true = np.random.rand(p, n) + 0.5
        X = F_true @ G_true

        sigma = np.ones_like(X) * 0.1

        # Run PMF - with weak regularization for better fit
        result = pmf(X, sigma, p=2, mode="regularized",
                     gamma=0.01, delta=0.01,  # Weak regularization
                     max_iter=100, random_seed=42)

        # PMF may not recover exact factorization (local minima, scaling ambiguity)
        # Just verify it runs successfully and produces valid results
        assert isinstance(result, PMFResult)
        assert np.all(np.isfinite(result.residuals))
        assert np.all(np.isfinite(result.F))
        assert np.all(np.isfinite(result.G))
        assert np.all(result.F >= 0)
        assert np.all(result.G >= 0)
        assert result.Q >= 0

    def test_different_modes(self):
        """Test different algorithm modes."""
        np.random.seed(42)

        m, n, p = 8, 12, 2
        F_true = np.random.rand(m, p)
        G_true = np.random.rand(p, n)
        X = F_true @ G_true + 0.05 * np.random.randn(m, n)
        sigma = np.ones_like(X) * 0.05

        # Test each mode
        for mode in ["basic", "regularized", "full"]:
            result = pmf(
                X, sigma, p=2, mode=mode,
                max_iter=100, random_seed=42
            )

            assert isinstance(result, PMFResult)
            assert result.F.shape == (m, p)
            assert np.all(result.F >= 0)
            assert np.all(result.G >= 0)


class TestPMFParameters:
    """Tests for PMF parameter handling."""

    def test_custom_initial_matrices(self):
        """Test with user-provided initial matrices."""
        np.random.seed(42)

        m, n, p = 5, 10, 2
        X = np.random.rand(m, n) + 0.5
        sigma = np.ones_like(X) * 0.1

        # Provide custom initialization
        F_init = np.random.rand(m, p)
        G_init = np.random.rand(p, n)

        result = pmf(
            X, sigma, p=2,
            F_init=F_init, G_init=G_init,
            max_iter=50, random_seed=42
        )

        assert isinstance(result, PMFResult)
        # F and G should be different from initial (algorithm ran)
        assert not np.allclose(result.F, F_init)

    def test_custom_strength_coefficients(self):
        """Test with explicit strength coefficients."""
        np.random.seed(42)

        m, n, p = 5, 10, 2
        X = np.random.rand(m, n) + 0.5
        sigma = np.ones_like(X) * 0.1

        result = pmf(
            X, sigma, p=2,
            mode="full",
            alpha=1.0, beta=1.0,
            gamma=0.1, delta=0.1,
            max_iter=50, random_seed=42
        )

        assert isinstance(result, PMFResult)
        assert result.converged or result.n_iter > 10

    def test_different_solvers(self):
        """Test with different solver backends."""
        np.random.seed(42)

        m, n, p = 5, 10, 2
        X = np.random.rand(m, n) + 0.5
        sigma = np.ones_like(X) * 0.1

        # Test NumPy solver
        result_numpy = pmf(
            X, sigma, p=2,
            solver="numpy",
            max_iter=50, random_seed=42
        )

        # Test JAX solver if available
        try:
            result_jax = pmf(
                X, sigma, p=2,
                solver="jax",
                max_iter=50, random_seed=42
            )

            # Results should be similar
            # (may not be identical due to numerical differences)
            assert result_numpy.F.shape == result_jax.F.shape
            assert result_numpy.G.shape == result_jax.G.shape

        except (ImportError, ValueError):
            # ValueError is raised by pmf() if JAX is not installed
            pytest.skip("JAX not installed")


class TestPMFConvergence:
    """Tests for convergence behavior."""

    def test_convergence_tracking(self):
        """Test that Q_history is properly tracked."""
        np.random.seed(42)

        m, n, p = 5, 10, 2
        X = np.random.rand(m, n) + 0.5
        sigma = np.ones_like(X) * 0.1

        result = pmf(X, sigma, p=2, max_iter=50, random_seed=42)

        # Q_history should have entries
        assert len(result.Q_history) > 1

        # Q should generally trend downward over multiple iterations
        # Compare first 5 and last 5 iterations
        if len(result.Q_history) >= 10:
            early_avg = np.mean(result.Q_history[:5])
            late_avg = np.mean(result.Q_history[-5:])
            # Later iterations should generally have lower Q
            assert late_avg <= early_avg * 1.5  # Allow some tolerance

    def test_max_iterations_reached(self):
        """Test behavior when max iterations is reached."""
        np.random.seed(42)

        m, n, p = 10, 20, 3
        X = np.random.rand(m, n) + 0.5
        sigma = np.ones_like(X) * 0.1

        # Run with very few iterations and strict tolerance
        # ACLS is the default algorithm
        with pytest.warns(UserWarning, match="did not converge"):
            result = pmf(
                X, sigma, p=3,
                max_iter=5,  # Very few iterations
                conv_tol=1e-10,  # Very strict
                random_seed=42
            )

        assert not result.converged
        assert result.n_iter == 5

    def test_early_convergence(self):
        """Test early convergence with relaxed tolerance."""
        np.random.seed(42)

        m, n, p = 5, 10, 2
        X = np.random.rand(m, n) + 0.5
        sigma = np.ones_like(X) * 0.1

        # Disable multiphase to test single-phase convergence behavior
        result = pmf(
            X, sigma, p=2,
            max_iter=1000,
            conv_tol=0.01,  # Relaxed tolerance
            enable_multiphase=False,  # Test single-phase behavior
            random_seed=42
        )

        # Should converge in reasonable number of iterations
        assert result.converged
        assert result.n_iter < 200


class TestPMFFeatures:
    """Tests for specific PMF features."""

    def test_reweighting(self):
        """Test reweighting for outlier handling."""
        np.random.seed(42)

        m, n, p = 10, 20, 2
        X = np.random.rand(m, n) + 0.5
        sigma = np.ones_like(X) * 0.1

        # Add some outliers
        X[0, 0] = 10.0  # Large outlier
        X[5, 10] = -2.0  # Negative outlier

        # With reweighting
        result_reweight = pmf(
            X, sigma, p=2,
            enable_reweighting=True,
            outlier_threshold=4.0,
            max_iter=50, random_seed=42
        )

        # Without reweighting
        result_no_reweight = pmf(
            X, sigma, p=2,
            enable_reweighting=False,
            max_iter=50, random_seed=42
        )

        # Both should complete
        assert isinstance(result_reweight, PMFResult)
        assert isinstance(result_no_reweight, PMFResult)

    def test_initial_acceleration(self):
        """Test initial acceleration feature."""
        np.random.seed(42)

        m, n, p = 8, 15, 2
        X = np.random.rand(m, n) + 0.5
        sigma = np.ones_like(X) * 0.1

        # With acceleration
        result_accel = pmf(
            X, sigma, p=2,
            enable_initial_accel=True,
            accel_iterations=10,
            max_iter=50, random_seed=42
        )

        # Without acceleration
        result_no_accel = pmf(
            X, sigma, p=2,
            enable_initial_accel=False,
            max_iter=50, random_seed=42
        )

        # Both should work
        assert isinstance(result_accel, PMFResult)
        assert isinstance(result_no_accel, PMFResult)

    def test_step_control(self):
        """Test step length control."""
        np.random.seed(42)

        m, n, p = 8, 15, 2
        X = np.random.rand(m, n) + 0.5
        sigma = np.ones_like(X) * 0.1

        # With step control
        result_control = pmf(
            X, sigma, p=2,
            enable_step_control=True,
            max_step_halving=3,
            max_iter=50, random_seed=42
        )

        # Without step control
        result_no_control = pmf(
            X, sigma, p=2,
            enable_step_control=False,
            max_iter=50, random_seed=42
        )

        # Both should complete
        assert isinstance(result_control, PMFResult)
        assert isinstance(result_no_control, PMFResult)

    def test_random_acol_initialization(self):
        """Test Random Acol initialization method."""
        np.random.seed(42)

        m, n, p = 10, 20, 3
        X = np.random.rand(m, n) + 0.5
        sigma = np.ones_like(X) * 0.1

        result = pmf(
            X, sigma, p=3,
            init_method="random_acol",
            max_iter=50,
            enable_multiphase=False,
            random_seed=42
        )

        # Check result
        assert isinstance(result, PMFResult)
        assert result.F.shape == (m, p)
        assert result.G.shape == (p, n)
        assert np.all(result.F >= 0)
        assert np.all(result.G >= 0)

    def test_svd_centroid_initialization(self):
        """Test SVD-Centroid initialization method."""
        np.random.seed(42)

        m, n, p = 10, 20, 3
        X = np.random.rand(m, n) + 0.5
        sigma = np.ones_like(X) * 0.1

        result = pmf(
            X, sigma, p=3,
            init_method="svd_centroid",
            max_iter=50,
            enable_multiphase=False,
            random_seed=42
        )

        # Check result
        assert isinstance(result, PMFResult)
        assert result.F.shape == (m, p)
        assert result.G.shape == (p, n)
        assert np.all(result.F >= 0)
        assert np.all(result.G >= 0)

    def test_initialization_methods_all_work(self):
        """Test that all initialization methods produce valid results."""
        np.random.seed(42)

        m, n, p = 8, 15, 2
        X = np.random.rand(m, n) + 0.5
        sigma = np.ones_like(X) * 0.1

        for init_method in ["random", "random_acol", "svd_centroid"]:
            result = pmf(
                X, sigma, p=2,
                init_method=init_method,
                max_iter=30,
                enable_multiphase=False,
                random_seed=42
            )

            assert isinstance(result, PMFResult), f"Failed for {init_method}"
            assert np.all(np.isfinite(result.F)), f"F not finite for {init_method}"
            assert np.all(np.isfinite(result.G)), f"G not finite for {init_method}"


class TestPMFDiagnostics:
    """Tests for diagnostic outputs."""

    def test_diagnostics_calculated(self):
        """Test that diagnostics are properly calculated."""
        np.random.seed(42)

        m, n, p = 5, 10, 2
        X = np.random.rand(m, n) + 0.5
        sigma = np.ones_like(X) * 0.1

        result = pmf(X, sigma, p=2, max_iter=50, random_seed=42)

        # Check all diagnostic fields exist and are reasonable
        assert 0 <= result.explained_variance <= 1
        assert result.chi2 >= 0
        assert result.residuals.shape == X.shape
        assert result.Q >= 0

    def test_explained_variance(self):
        """Test explained variance calculation on synthetic data with noise."""
        np.random.seed(42)

        # Create data with some noise
        m, n, p = 5, 10, 2
        F_true = np.random.rand(m, p)
        G_true = np.random.rand(p, n)
        X_perfect = F_true @ G_true

        # Add noise
        noise = np.random.randn(m, n) * 0.1
        X = X_perfect + noise
        sigma = np.ones_like(X) * 0.1

        # Use regularized mode with moderate regularization
        result = pmf(X, sigma, p=2, mode="regularized",
                     gamma=0.5, delta=0.5,
                     max_iter=50, random_seed=42)

        # Check that explained variance is in valid range
        assert 0.0 <= result.explained_variance <= 1.0
        # PMF may not achieve perfect fit due to noise, local minima, and regularization
        assert result.Q >= 0


class TestPMFEdgeCases:
    """Tests for edge cases and error handling."""

    def test_rank_one_factorization(self):
        """Test with p=1 (rank-1 factorization)."""
        np.random.seed(42)

        m, n = 5, 10
        X = np.random.rand(m, n) + 0.5
        sigma = np.ones_like(X) * 0.1

        result = pmf(X, sigma, p=1, max_iter=50, random_seed=42)

        assert result.F.shape == (m, 1)
        assert result.G.shape == (1, n)

    def test_small_problem(self):
        """Test on very small problem."""
        np.random.seed(42)

        m, n, p = 3, 4, 2
        X = np.random.rand(m, n) + 0.5
        sigma = np.ones_like(X) * 0.1

        result = pmf(X, sigma, p=2, max_iter=50, random_seed=42)

        assert isinstance(result, PMFResult)
        assert result.F.shape == (m, p)

    def test_reproducibility(self):
        """Test that results are reproducible with same seed."""
        m, n, p = 5, 10, 2
        X = np.random.rand(m, n) + 0.5
        sigma = np.ones_like(X) * 0.1

        result1 = pmf(X, sigma, p=2, max_iter=30, random_seed=123)
        result2 = pmf(X, sigma, p=2, max_iter=30, random_seed=123)

        # Results should be identical with same seed
        np.testing.assert_array_equal(result1.F, result2.F)
        np.testing.assert_array_equal(result1.G, result2.G)
        assert result1.Q == result2.Q


class TestPMFVerbose:
    """Tests for verbose output."""

    def test_verbose_output(self, capsys):
        """Test that verbose mode produces output."""
        np.random.seed(42)

        m, n, p = 5, 10, 2
        X = np.random.rand(m, n) + 0.5
        sigma = np.ones_like(X) * 0.1

        result = pmf(
            X, sigma, p=2,
            max_iter=20,
            verbose=True,
            random_seed=42
        )

        captured = capsys.readouterr()
        assert "PMF Algorithm" in captured.out
        assert "Converged" in captured.out or "Did not converge" in captured.out


class TestACLSAlgorithm:
    """Tests for ACLS algorithm."""

    def test_acls_basic_factorization(self):
        """Test ACLS algorithm on simple factorization."""
        np.random.seed(42)

        m, n, p = 10, 20, 3
        F_true = np.random.rand(m, p) + 0.5
        G_true = np.random.rand(p, n) + 0.5
        noise = np.random.randn(m, n) * 0.1

        X = F_true @ G_true + noise
        sigma = np.ones_like(X) * 0.1

        result = pmf(X, sigma, p=3, algorithm='acls', max_iter=100, random_seed=42)

        assert isinstance(result, PMFResult)
        assert result.F.shape == (m, p)
        assert result.G.shape == (p, n)
        assert np.all(result.F >= 0)
        assert np.all(result.G >= 0)
        assert result.explained_variance > 0.0

    def test_acls_convergence(self):
        """Test that ACLS converges on well-posed problem."""
        np.random.seed(42)

        m, n, p = 8, 15, 2
        F_true = np.random.rand(m, p) + 0.5
        G_true = np.random.rand(p, n) + 0.5
        X = F_true @ G_true + 0.05 * np.random.randn(m, n)
        sigma = np.ones_like(X) * 0.05

        result = pmf(
            X, sigma, p=2, algorithm='acls',
            max_iter=200, conv_tol=0.01, random_seed=42
        )

        # Should converge for this well-posed problem
        assert result.converged or result.n_iter < 200

    def test_acls_with_regularization(self):
        """Test ACLS with Tikhonov regularization."""
        np.random.seed(42)

        m, n, p = 10, 20, 3
        X = np.random.rand(m, n) + 0.5
        sigma = np.ones_like(X) * 0.1

        # With regularization
        result_reg = pmf(
            X, sigma, p=3, algorithm='acls',
            lambda_W=0.1, lambda_H=0.1,
            max_iter=50, random_seed=42
        )

        # Without regularization
        result_no_reg = pmf(
            X, sigma, p=3, algorithm='acls',
            lambda_W=0.0, lambda_H=0.0,
            max_iter=50, random_seed=42
        )

        # Both should work
        assert isinstance(result_reg, PMFResult)
        assert isinstance(result_no_reg, PMFResult)
        assert np.all(result_reg.F >= 0)
        assert np.all(result_no_reg.F >= 0)

    def test_acls_with_different_init_methods(self):
        """Test ACLS with different initialization methods."""
        np.random.seed(42)

        m, n, p = 8, 15, 2
        X = np.random.rand(m, n) + 0.5
        sigma = np.ones_like(X) * 0.1

        for init_method in ["random", "random_acol", "svd_centroid"]:
            result = pmf(
                X, sigma, p=2, algorithm='acls',
                init_method=init_method,
                max_iter=30, random_seed=42
            )

            assert isinstance(result, PMFResult), f"Failed for {init_method}"
            assert np.all(np.isfinite(result.F)), f"F not finite for {init_method}"
            assert np.all(np.isfinite(result.G)), f"G not finite for {init_method}"

    def test_acls_reproducibility(self):
        """Test ACLS reproducibility with same seed."""
        m, n, p = 5, 10, 2
        X = np.random.rand(m, n) + 0.5
        sigma = np.ones_like(X) * 0.1

        result1 = pmf(X, sigma, p=2, algorithm='acls', max_iter=30, random_seed=123)
        result2 = pmf(X, sigma, p=2, algorithm='acls', max_iter=30, random_seed=123)

        np.testing.assert_array_equal(result1.F, result2.F)
        np.testing.assert_array_equal(result1.G, result2.G)
        assert result1.Q == result2.Q

    def test_acls_vs_newton_both_work(self):
        """Test that both ACLS and Newton produce valid results on same data."""
        np.random.seed(42)

        m, n, p = 8, 15, 2
        F_true = np.random.rand(m, p) + 0.5
        G_true = np.random.rand(p, n) + 0.5
        X = F_true @ G_true + 0.1 * np.random.randn(m, n)
        sigma = np.ones_like(X) * 0.1

        result_acls = pmf(
            X, sigma, p=2, algorithm='acls',
            max_iter=100, random_seed=42
        )
        result_newton = pmf(
            X, sigma, p=2, algorithm='newton',
            max_iter=100, random_seed=42,
            enable_multiphase=False
        )

        # Both should produce valid results
        assert isinstance(result_acls, PMFResult)
        assert isinstance(result_newton, PMFResult)
        assert np.all(result_acls.F >= 0)
        assert np.all(result_newton.F >= 0)
        assert result_acls.explained_variance > 0
        assert result_newton.explained_variance > 0

    def test_acls_verbose_output(self, capsys):
        """Test ACLS verbose output."""
        np.random.seed(42)

        m, n, p = 5, 10, 2
        X = np.random.rand(m, n) + 0.5
        sigma = np.ones_like(X) * 0.1

        result = pmf(
            X, sigma, p=2, algorithm='acls',
            max_iter=20, verbose=True, random_seed=42
        )

        captured = capsys.readouterr()
        assert "ACLS" in captured.out
        assert "Converged" in captured.out or "did not converge" in captured.out.lower()

    def test_invalid_algorithm_raises(self):
        """Test that invalid algorithm raises ValueError."""
        np.random.seed(42)

        m, n, p = 5, 10, 2
        X = np.random.rand(m, n) + 0.5
        sigma = np.ones_like(X) * 0.1

        with pytest.raises(ValueError, match="Invalid algorithm"):
            pmf(X, sigma, p=2, algorithm='invalid_algo')

    def test_acls_small_problem(self):
        """Test ACLS on very small problem."""
        np.random.seed(42)

        m, n, p = 3, 4, 2
        X = np.random.rand(m, n) + 0.5
        sigma = np.ones_like(X) * 0.1

        result = pmf(X, sigma, p=2, algorithm='acls', max_iter=50, random_seed=42)

        assert isinstance(result, PMFResult)
        assert result.F.shape == (m, p)
        assert result.G.shape == (p, n)

    def test_acls_rank_one(self):
        """Test ACLS with p=1 (rank-1 factorization)."""
        np.random.seed(42)

        m, n = 5, 10
        X = np.random.rand(m, n) + 0.5
        sigma = np.ones_like(X) * 0.1

        result = pmf(X, sigma, p=1, algorithm='acls', max_iter=50, random_seed=42)

        assert result.F.shape == (m, 1)
        assert result.G.shape == (1, n)


class TestAnalyticalStdev:
    """Tests for analytical standard deviations from WLS covariance."""

    def test_stdev_populated(self):
        """F_std and G_std are always populated after pmf()."""
        np.random.seed(42)
        m, n, p = 10, 20, 3
        F_true = np.random.rand(m, p) + 0.5
        G_true = np.random.rand(p, n) + 0.5
        X = F_true @ G_true + 0.1 * np.random.randn(m, n)
        X = np.maximum(X, 1e-6)
        sigma = np.ones_like(X) * 0.1

        result = pmf(X, sigma, p=p, max_iter=100, random_seed=42)

        assert result.F_std is not None
        assert result.G_std is not None

    def test_stdev_shapes(self):
        """F_std and G_std have correct shapes."""
        np.random.seed(42)
        m, n, p = 10, 20, 3
        X = np.random.rand(m, n) + 0.5
        sigma = np.ones_like(X) * 0.1

        result = pmf(X, sigma, p=p, max_iter=50, random_seed=42)

        assert result.F_std.shape == (m, p)
        assert result.G_std.shape == (p, n)

    def test_stdev_nonnegative_finite(self):
        """All standard deviations are non-negative and finite."""
        np.random.seed(42)
        m, n, p = 10, 20, 3
        F_true = np.random.rand(m, p) + 0.5
        G_true = np.random.rand(p, n) + 0.5
        X = F_true @ G_true + 0.1 * np.random.randn(m, n)
        X = np.maximum(X, 1e-6)
        sigma = np.ones_like(X) * 0.1

        result = pmf(X, sigma, p=p, max_iter=100, random_seed=42)

        assert np.all(result.F_std >= 0)
        assert np.all(result.G_std >= 0)
        assert np.all(np.isfinite(result.F_std))
        assert np.all(np.isfinite(result.G_std))

    def test_stdev_zero_at_boundary(self):
        """Elements clamped to zero should have std = 0."""
        np.random.seed(42)
        m, n, p = 10, 20, 3
        X = np.random.rand(m, n) + 0.5
        sigma = np.ones_like(X) * 0.1

        result = pmf(X, sigma, p=p, max_iter=100, random_seed=42)

        # Wherever F or G is exactly 0, std should be 0
        g_zero_mask = result.F == 0
        f_zero_mask = result.G == 0
        if np.any(g_zero_mask):
            assert np.all(result.F_std[g_zero_mask] == 0)
        if np.any(f_zero_mask):
            assert np.all(result.G_std[f_zero_mask] == 0)

    def test_stdev_scales_with_sigma(self):
        """Larger sigma (more uncertainty in data) should give larger std."""
        np.random.seed(42)
        m, n, p = 10, 20, 2
        F_true = np.random.rand(m, p) + 1.0
        G_true = np.random.rand(p, n) + 1.0
        X = F_true @ G_true
        X = np.maximum(X, 1e-6)

        sigma_small = np.ones_like(X) * 0.05
        sigma_large = np.ones_like(X) * 0.5

        result_small = pmf(X, sigma_small, p=p, max_iter=100, random_seed=42)
        result_large = pmf(X, sigma_large, p=p, max_iter=100, random_seed=42)

        # Mean std should be larger with larger sigma
        assert np.mean(result_large.G_std) > np.mean(result_small.G_std)
        assert np.mean(result_large.F_std) > np.mean(result_small.F_std)

    def test_stdev_with_regularization(self):
        """Stdev should be computed correctly with regularization."""
        np.random.seed(42)
        m, n, p = 10, 20, 3
        X = np.random.rand(m, n) + 0.5
        sigma = np.ones_like(X) * 0.1

        result = pmf(X, sigma, p=p, lambda_W=0.1, lambda_H=0.1,
                     max_iter=50, random_seed=42)

        assert result.F_std is not None
        assert result.G_std is not None
        assert np.all(np.isfinite(result.F_std))
        assert np.all(np.isfinite(result.G_std))


class TestFPEAK:
    """Tests for FPEAK rotational exploration."""

    @pytest.fixture
    def synth_data(self):
        """Well-conditioned synthetic dataset for FPEAK tests."""
        np.random.seed(42)
        m, n, p = 20, 15, 3
        F_true = np.random.rand(m, p) + 0.5
        G_true = np.random.rand(p, n) + 0.5
        X = F_true @ G_true + 0.1 * np.random.randn(m, n)
        X = np.maximum(X, 1e-6)
        sigma = np.ones_like(X) * 0.1
        return X, sigma, p

    def test_fpeak_zero_matches_base(self, synth_data):
        """fpeak=0 should produce the same result as default PMF."""
        X, sigma, p = synth_data
        result_default = pmf(X, sigma, p=p, max_iter=100, random_seed=42)
        result_fp0 = pmf(X, sigma, p=p, fpeak=0.0, max_iter=100, random_seed=42)

        np.testing.assert_array_equal(result_default.F, result_fp0.F)
        np.testing.assert_array_equal(result_default.G, result_fp0.G)
        assert result_default.Q == result_fp0.Q

    def test_fpeak_positive_increases_Q(self, synth_data):
        """Positive fpeak should increase Q (penalty cost)."""
        X, sigma, p = synth_data
        result_base = pmf(X, sigma, p=p, max_iter=200, random_seed=42)
        result_pos = pmf(X, sigma, p=p, fpeak=0.5, max_iter=200, random_seed=42)

        assert result_pos.Q >= result_base.Q - 1e-6

    def test_fpeak_negative_increases_Q(self, synth_data):
        """Negative fpeak should also increase Q (penalty in other direction)."""
        X, sigma, p = synth_data
        result_base = pmf(X, sigma, p=p, max_iter=200, random_seed=42)
        result_neg = pmf(X, sigma, p=p, fpeak=-0.5, max_iter=200, random_seed=42)

        assert result_neg.Q >= result_base.Q - 1e-6

    def test_fpeak_profiles_differ(self, synth_data):
        """Different fpeak values should produce different profiles."""
        X, sigma, p = synth_data
        result_base = pmf(X, sigma, p=p, max_iter=200, random_seed=42)
        result_pos = pmf(X, sigma, p=p, fpeak=1.0, max_iter=200, random_seed=42)

        # Profiles should not be identical
        assert not np.allclose(result_base.G, result_pos.G, atol=1e-6)

    def test_fpeak_sweep_returns_result(self, synth_data):
        """fpeak_sweep() returns FPEAKSweepResult with correct structure."""
        X, sigma, p = synth_data
        sweep = fpeak_sweep(
            X, sigma, p=p,
            fpeak_values=[-0.5, 0.0, 0.5],
            max_iter=100, random_seed=42,
        )

        assert isinstance(sweep, FPEAKSweepResult)
        assert len(sweep.results) == 3
        assert 0.0 in sweep.results
        assert -0.5 in sweep.results
        assert 0.5 in sweep.results
        assert sweep.base_result is sweep.results[0.0]

    def test_fpeak_sweep_warm_start(self, synth_data):
        """Warm-start sweep produces valid results."""
        X, sigma, p = synth_data
        sweep = fpeak_sweep(
            X, sigma, p=p,
            fpeak_values=[-0.5, 0.0, 0.5],
            warm_start=True,
            max_iter=100, random_seed=42,
        )

        for fp, result in sweep.results.items():
            assert isinstance(result, PMFResult)
            assert np.all(np.isfinite(result.F))
            assert np.all(np.isfinite(result.G))
            assert np.all(result.F >= 0)
            assert np.all(result.G >= 0)

    def test_fpeak_sweep_Q_curve(self, synth_data):
        """Q-vs-FPEAK curve should be roughly U-shaped (minimum near 0)."""
        X, sigma, p = synth_data
        sweep = fpeak_sweep(
            X, sigma, p=p,
            fpeak_values=[-1.0, -0.5, 0.0, 0.5, 1.0],
            max_iter=200, random_seed=42,
        )

        Q_base = sweep.Q_values[0.0]
        # Q at non-zero fpeak should generally be >= Q_base
        for fp in [-1.0, 1.0]:
            assert sweep.Q_values[fp] >= Q_base - 1e-6
