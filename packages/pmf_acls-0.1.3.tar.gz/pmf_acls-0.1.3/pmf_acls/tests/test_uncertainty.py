"""Tests for uncertainty estimation module."""

import pytest
import numpy as np
from pmf_acls import pmf, PMFResult
from pmf_acls.uncertainty import (
    bootstrap_uncertainty,
    align_factors_procrustes,
    displacement_test,
    multistart_test,
    Bootstrap,
    Displacement,
)
from pmf_acls.data_structures import DisplacementResult


class TestBootstrapUncertainty:
    """Tests for bootstrap uncertainty estimation."""

    def test_displacement_bootstrap_basic(self):
        """Test basic displacement bootstrap."""
        np.random.seed(42)

        # Create simple problem
        m, n, p = 5, 10, 2
        F_true = np.random.rand(m, p) + 0.5
        G_true = np.random.rand(p, n) + 0.5
        X = F_true @ G_true + 0.1 * np.random.randn(m, n)
        sigma = np.ones_like(X) * 0.1

        # Get base result
        base = pmf(X, sigma, p=2, max_iter=30, random_seed=42)

        # Run bootstrap
        unc = bootstrap_uncertainty(
            X, sigma, p=2,
            base_result=base,
            n_bootstrap=5,  # Small number for speed
            method="displacement",
            random_seed=42,
            max_iter=30
        )

        # Check structure
        assert unc.F_mean.shape == (m, p)
        assert unc.F_std.shape == (m, p)
        assert unc.G_mean.shape == (p, n)
        assert unc.G_std.shape == (p, n)
        assert len(unc.bootstrap_results) <= 5

        # Uncertainties should be non-negative
        assert np.all(unc.F_std >= 0)
        assert np.all(unc.G_std >= 0)

    def test_residual_bootstrap(self):
        """Test residual bootstrap method."""
        np.random.seed(42)

        m, n, p = 5, 10, 2
        X = np.random.rand(m, n) + 0.5
        sigma = np.ones_like(X) * 0.1

        base = pmf(X, sigma, p=2, max_iter=30, random_seed=42)

        unc = bootstrap_uncertainty(
            X, sigma, p=2,
            base_result=base,
            n_bootstrap=5,
            method="residual",
            random_seed=42,
            max_iter=30
        )

        # Check that it runs successfully
        assert unc.F_mean.shape == (m, p)
        assert len(unc.bootstrap_results) <= 5

    def test_bootstrap_without_base_result(self):
        """Test bootstrap when base_result is not provided."""
        np.random.seed(42)

        m, n, p = 5, 10, 2
        X = np.random.rand(m, n) + 0.5
        sigma = np.ones_like(X) * 0.1

        # Should compute base result automatically
        unc = bootstrap_uncertainty(
            X, sigma, p=2,
            base_result=None,  # Will compute internally
            n_bootstrap=3,
            random_seed=42,
            max_iter=30
        )

        assert unc.F_mean.shape == (m, p)
        assert len(unc.bootstrap_results) <= 3

    def test_bootstrap_reproducibility(self):
        """Test that bootstrap is reproducible with same seed."""
        np.random.seed(42)

        m, n, p = 5, 10, 2
        X = np.random.rand(m, n) + 0.5
        sigma = np.ones_like(X) * 0.1

        base = pmf(X, sigma, p=2, max_iter=30, random_seed=42)

        unc1 = bootstrap_uncertainty(
            X, sigma, p=2,
            base_result=base,
            n_bootstrap=3,
            random_seed=123,
            max_iter=30,
            mode="regularized",  # Use regularized mode for more stability
            gamma=0.1, delta=0.1
        )

        unc2 = bootstrap_uncertainty(
            X, sigma, p=2,
            base_result=base,
            n_bootstrap=3,
            random_seed=123,
            max_iter=30,
            mode="regularized",
            gamma=0.1, delta=0.1
        )

        # Should get similar results (allow small numerical differences)
        # Check that the means are correlated and have similar magnitude
        assert unc1.F_mean.shape == unc2.F_mean.shape
        assert unc1.G_mean.shape == unc2.G_mean.shape

        # Check correlation is high (results are similar)
        g_corr = np.corrcoef(unc1.F_mean.flatten(), unc2.F_mean.flatten())[0, 1]
        f_corr = np.corrcoef(unc1.G_mean.flatten(), unc2.G_mean.flatten())[0, 1]

        assert g_corr > 0.9  # High correlation
        assert f_corr > 0.9

    def test_bootstrap_percentiles(self):
        """Test percentile calculation."""
        np.random.seed(42)

        m, n, p = 5, 10, 2
        X = np.random.rand(m, n) + 0.5
        sigma = np.ones_like(X) * 0.1

        unc = bootstrap_uncertainty(
            X, sigma, p=2,
            n_bootstrap=10,
            percentiles=[5, 50, 95],
            random_seed=42,
            max_iter=30
        )

        # Check percentiles are computed
        assert 5 in unc.F_percentiles
        assert 50 in unc.F_percentiles
        assert 95 in unc.F_percentiles

        # Check shapes
        assert unc.F_percentiles[5].shape == (m, p)
        assert unc.G_percentiles[95].shape == (p, n)

        # Check ordering: 5th < 50th < 95th percentile
        assert np.all(unc.F_percentiles[5] <= unc.F_percentiles[50])
        assert np.all(unc.F_percentiles[50] <= unc.F_percentiles[95])

    def test_bootstrap_without_alignment(self):
        """Test bootstrap without factor alignment."""
        np.random.seed(42)

        m, n, p = 5, 10, 2
        X = np.random.rand(m, n) + 0.5
        sigma = np.ones_like(X) * 0.1

        unc = bootstrap_uncertainty(
            X, sigma, p=2,
            n_bootstrap=5,
            align_factors=False,  # Disable alignment
            random_seed=42,
            max_iter=30
        )

        # Should still run successfully
        assert unc.F_mean.shape == (m, p)
        assert len(unc.bootstrap_results) <= 5

    def test_bootstrap_invalid_inputs(self):
        """Test error handling for invalid inputs."""
        np.random.seed(42)

        m, n, p = 5, 10, 2
        X = np.random.rand(m, n)
        sigma = np.ones_like(X) * 0.1

        # n_bootstrap < 1
        with pytest.raises(ValueError, match="n_bootstrap must be at least 1"):
            bootstrap_uncertainty(X, sigma, p=2, n_bootstrap=0)

        # Invalid method
        with pytest.raises(ValueError, match="method must be"):
            bootstrap_uncertainty(X, sigma, p=2, method="invalid")

    def test_bootstrap_verbose(self, capsys):
        """Test verbose output."""
        np.random.seed(42)

        m, n, p = 5, 10, 2
        X = np.random.rand(m, n) + 0.5
        sigma = np.ones_like(X) * 0.1

        unc = bootstrap_uncertainty(
            X, sigma, p=2,
            n_bootstrap=3,
            verbose=True,
            random_seed=42,
            max_iter=30
        )

        captured = capsys.readouterr()
        assert "bootstrap samples" in captured.out.lower()
        assert "uncertainty summary" in captured.out.lower()


class TestAlignFactorsProcrustes:
    """Tests for Procrustes factor alignment."""

    def test_align_identical_factors(self):
        """Test alignment when factors are identical."""
        np.random.seed(42)

        m, n, p = 5, 10, 2
        F = np.random.rand(m, p)
        G = np.random.rand(p, n)

        # Align to itself
        F_aligned, G_aligned = align_factors_procrustes(F, G, F, G)

        # Should get approximately the same result
        np.testing.assert_array_almost_equal(F_aligned, F)
        np.testing.assert_array_almost_equal(G_aligned, G)

    def test_align_preserves_factorization(self):
        """Test that alignment preserves GF product."""
        np.random.seed(42)

        m, n, p = 5, 10, 2
        F_base = np.random.rand(m, p)
        G_base = np.random.rand(p, n)

        # Create rotated version
        Q_random = np.linalg.qr(np.random.randn(p, p))[0]  # Random orthogonal matrix
        F_rotated = F_base @ Q_random
        G_rotated = Q_random.T @ G_base

        # Original product
        product_original = F_rotated @ G_rotated

        # Align back
        F_aligned, G_aligned = align_factors_procrustes(
            F_base, G_base, F_rotated, G_rotated
        )

        # Product should be preserved
        product_aligned = F_aligned @ G_aligned
        np.testing.assert_array_almost_equal(product_aligned, product_original)

    def test_align_improves_similarity(self):
        """Test that alignment improves similarity to base."""
        np.random.seed(42)

        m, n, p = 5, 10, 2
        F_base = np.random.rand(m, p) + 1.0
        G_base = np.random.rand(p, n) + 1.0

        # Create slightly different factors with rotation
        Q_random = np.linalg.qr(np.random.randn(p, p))[0]
        F_boot = (F_base + 0.1 * np.random.randn(m, p)) @ Q_random
        G_boot = Q_random.T @ (G_base + 0.1 * np.random.randn(p, n))

        # Distance before alignment
        dist_before = np.linalg.norm(F_base - F_boot)

        # Align
        F_aligned, G_aligned = align_factors_procrustes(
            F_base, G_base, F_boot, G_boot
        )

        # Distance after alignment
        dist_after = np.linalg.norm(F_base - F_aligned)

        # Alignment should reduce distance (or keep it similar)
        assert dist_after <= dist_before * 1.1  # Allow small numerical error


class TestMultistartTest:
    """Tests for multistart stability testing (formerly displacement_test)."""

    def test_multistart_test_basic(self):
        """Test basic multistart test."""
        np.random.seed(42)

        m, n, p = 5, 10, 2
        F_true = np.random.rand(m, p) + 0.5
        G_true = np.random.rand(p, n) + 0.5
        X = F_true @ G_true + 0.05 * np.random.randn(m, n)
        sigma = np.ones_like(X) * 0.05

        result = multistart_test(
            X, sigma, p=2,
            n_displacements=5,
            random_seed=42,
            max_iter=30
        )

        # Check structure
        assert 'Q_values' in result
        assert 'Q_min' in result
        assert 'Q_max' in result
        assert 'Q_range' in result
        assert 'all_results' in result

        # Should have Q values
        assert len(result['Q_values']) <= 5
        assert result['Q_min'] <= result['Q_max']
        assert result['Q_range'] == result['Q_max'] - result['Q_min']

    def test_multistart_test_reproducibility(self):
        """Test multistart test reproducibility."""
        np.random.seed(42)

        m, n, p = 5, 10, 2
        X = np.random.rand(m, n) + 0.5
        sigma = np.ones_like(X) * 0.1

        result1 = multistart_test(
            X, sigma, p=2,
            n_displacements=3,
            random_seed=123,
            max_iter=30
        )

        result2 = multistart_test(
            X, sigma, p=2,
            n_displacements=3,
            random_seed=123,
            max_iter=30
        )

        # Should get same Q values
        np.testing.assert_array_almost_equal(
            result1['Q_values'],
            result2['Q_values']
        )

    def test_multistart_test_verbose(self, capsys):
        """Test verbose output for multistart test."""
        np.random.seed(42)

        m, n, p = 5, 10, 2
        X = np.random.rand(m, n) + 0.5
        sigma = np.ones_like(X) * 0.1

        result = multistart_test(
            X, sigma, p=2,
            n_displacements=3,
            verbose=True,
            random_seed=42,
            max_iter=30
        )

        captured = capsys.readouterr()
        assert "multistart test" in captured.out.lower()
        assert "q range" in captured.out.lower()


class TestDisplacementTest:
    """Tests for ESAT-style DISP error estimation."""

    def test_disp_basic(self):
        """Test basic DISP runs and returns correct structure."""
        np.random.seed(42)
        m, n, p = 5, 10, 2
        F_true = np.random.rand(m, p) + 0.5
        G_true = np.random.rand(p, n) + 0.5
        X = F_true @ G_true + 0.05 * np.random.randn(m, n)
        sigma = np.ones_like(X) * 0.05

        base = pmf(X, sigma, p=2, max_iter=50, random_seed=42)
        result = displacement_test(
            X, sigma, p=2,
            base_result=base,
            dQ_thresholds=[4.0],
            max_iter=50,
        )

        assert isinstance(result, DisplacementResult)
        assert result.n_factors == 2
        assert result.n_features == n
        assert result.Q_base == base.Q
        assert 4.0 in result.G_min
        assert 4.0 in result.G_max
        assert result.G_min[4.0].shape == (p, n)
        assert result.G_max[4.0].shape == (p, n)

    def test_disp_multiple_thresholds(self):
        """Test DISP with multiple dQ thresholds."""
        np.random.seed(42)
        m, n, p = 4, 6, 2
        F_true = np.random.rand(m, p) + 0.5
        G_true = np.random.rand(p, n) + 0.5
        X = F_true @ G_true + 0.05 * np.random.randn(m, n)
        sigma = np.ones_like(X) * 0.05

        base = pmf(X, sigma, p=2, max_iter=30, random_seed=42)
        result = displacement_test(
            X, sigma, p=2,
            base_result=base,
            dQ_thresholds=[4.0, 8.0],
            max_iter=30,
        )

        assert len(result.dQ_thresholds) == 2
        # Wider threshold should give wider or equal intervals
        range_4 = np.mean(result.G_max[4.0] - result.G_min[4.0])
        range_8 = np.mean(result.G_max[8.0] - result.G_min[8.0])
        assert range_8 >= range_4 - 1e-6

    def test_disp_swap_detection(self):
        """Test that swap_counts array is populated."""
        np.random.seed(42)
        m, n, p = 4, 6, 2
        X = np.random.rand(m, n) + 0.5
        sigma = np.ones_like(X) * 0.05

        base = pmf(X, sigma, p=2, max_iter=30, random_seed=42)
        result = displacement_test(
            X, sigma, p=2,
            base_result=base,
            dQ_thresholds=[4.0],
            max_iter=30,
        )

        assert result.swap_counts[4.0].shape == (p, n)
        assert result.swap_counts[4.0].dtype == int

    def test_disp_get_intervals(self):
        """Test the get_intervals convenience method."""
        np.random.seed(42)
        m, n, p = 4, 6, 2
        X = np.random.rand(m, n) + 0.5
        sigma = np.ones_like(X) * 0.05

        base = pmf(X, sigma, p=2, max_iter=30, random_seed=42)
        result = displacement_test(
            X, sigma, p=2,
            base_result=base,
            dQ_thresholds=[4.0],
            max_iter=30,
        )

        f_lo, f_hi = result.get_intervals(4.0)
        assert f_lo.shape == (p, n)
        assert f_hi.shape == (p, n)

    def test_disp_without_base_result(self):
        """Test DISP computes base result automatically."""
        np.random.seed(42)
        m, n, p = 4, 6, 2
        X = np.random.rand(m, n) + 0.5
        sigma = np.ones_like(X) * 0.05

        result = displacement_test(
            X, sigma, p=2,
            dQ_thresholds=[4.0],
            max_iter=30,
            random_seed=42,
        )

        assert isinstance(result, DisplacementResult)
        assert result.Q_base > 0


class TestIntegration:
    """Integration tests combining uncertainty estimation with PMF."""

    def test_full_uncertainty_workflow(self):
        """Test complete uncertainty estimation workflow."""
        np.random.seed(42)

        # Create synthetic data with known factors
        m, n, p_true = 8, 15, 2
        F_true = np.random.rand(m, p_true) + 0.5
        G_true = np.random.rand(p_true, n) + 0.5
        X = F_true @ G_true + 0.1 * np.random.randn(m, n)
        sigma = np.ones_like(X) * 0.1

        # Get base PMF result
        base = pmf(X, sigma, p=2, max_iter=50, random_seed=42)

        # Estimate uncertainties
        unc = bootstrap_uncertainty(
            X, sigma, p=2,
            base_result=base,
            n_bootstrap=10,
            method="displacement",
            percentiles=[5, 95],
            random_seed=42,
            max_iter=50
        )

        # Check that uncertainties are reasonable
        assert unc.F_mean.shape == (m, p_true)
        assert unc.G_mean.shape == (p_true, n)

        # Check that standard deviations are non-negative and finite
        assert np.all(np.isfinite(unc.F_std))
        assert np.all(np.isfinite(unc.G_std))
        assert np.all(unc.F_std >= 0)
        assert np.all(unc.G_std >= 0)

    def test_bootstrap_with_different_methods(self):
        """Test both bootstrap methods produce reasonable results."""
        np.random.seed(42)

        m, n, p = 5, 10, 2
        X = np.random.rand(m, n) + 0.5
        sigma = np.ones_like(X) * 0.1

        base = pmf(X, sigma, p=2, max_iter=30, random_seed=42)

        # Displacement bootstrap
        unc_disp = bootstrap_uncertainty(
            X, sigma, p=2,
            base_result=base,
            n_bootstrap=5,
            method="displacement",
            random_seed=42,
            max_iter=30
        )

        # Residual bootstrap
        unc_resid = bootstrap_uncertainty(
            X, sigma, p=2,
            base_result=base,
            n_bootstrap=5,
            method="residual",
            random_seed=42,
            max_iter=30
        )

        # Both should produce valid results
        assert unc_disp.F_mean.shape == (m, p)
        assert unc_resid.F_mean.shape == (m, p)

        # Both should have non-negative uncertainties
        assert np.all(unc_disp.F_std >= 0)
        assert np.all(unc_resid.F_std >= 0)


class TestBootstrapClass:
    """Tests for the Bootstrap class wrapper."""

    def _make_data(self):
        np.random.seed(42)
        m, n, p = 5, 10, 2
        F_true = np.random.rand(m, p) + 0.5
        G_true = np.random.rand(p, n) + 0.5
        X = F_true @ G_true + 0.05 * np.random.randn(m, n)
        sigma = np.ones_like(X) * 0.05
        base = pmf(X, sigma, p=2, max_iter=30, random_seed=42)
        return X, sigma, base

    def test_run_returns_self(self):
        X, sigma, base = self._make_data()
        bs = Bootstrap(base, X, sigma, n_bootstrap=3, random_seed=42, max_iter=30)
        ret = bs.run()
        assert ret is bs

    def test_result_populated(self):
        X, sigma, base = self._make_data()
        bs = Bootstrap(base, X, sigma, n_bootstrap=3, random_seed=42, max_iter=30)
        bs.run()
        assert bs.result is not None
        assert bs.result.F_mean.shape == (5, 2)
        assert bs.result.G_mean.shape == (2, 10)

    def test_feature_labels_default(self):
        X, sigma, base = self._make_data()
        bs = Bootstrap(base, X, sigma, n_bootstrap=3)
        assert len(bs.feature_labels) == 10
        assert bs.feature_labels[0] == "F0"

    def test_feature_labels_custom(self):
        X, sigma, base = self._make_data()
        labels = [f"Var{j}" for j in range(10)]
        bs = Bootstrap(base, X, sigma, feature_labels=labels, n_bootstrap=3)
        assert bs.feature_labels == labels

    def test_summary_no_crash(self, capsys):
        X, sigma, base = self._make_data()
        bs = Bootstrap(base, X, sigma, n_bootstrap=3, random_seed=42, max_iter=30)
        bs.run()
        bs.summary()
        captured = capsys.readouterr()
        assert len(captured.out) > 0

    def test_summary_before_run(self, capsys):
        X, sigma, base = self._make_data()
        bs = Bootstrap(base, X, sigma, n_bootstrap=3)
        bs.summary()
        captured = capsys.readouterr()
        assert "No results" in captured.out

    def test_plot_factor_returns_figure(self):
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt

        X, sigma, base = self._make_data()
        bs = Bootstrap(base, X, sigma, n_bootstrap=3, random_seed=42, max_iter=30)
        bs.run()
        fig = bs.plot_factor(0)
        assert isinstance(fig, matplotlib.figure.Figure)
        plt.close(fig)

    def test_plot_results_returns_figure(self):
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt

        X, sigma, base = self._make_data()
        bs = Bootstrap(base, X, sigma, n_bootstrap=3, random_seed=42, max_iter=30)
        bs.run()
        fig = bs.plot_results(0)
        assert isinstance(fig, matplotlib.figure.Figure)
        plt.close(fig)

    def test_plot_before_run_raises(self):
        X, sigma, base = self._make_data()
        bs = Bootstrap(base, X, sigma, n_bootstrap=3)
        with pytest.raises(RuntimeError, match="No results"):
            bs.plot_factor(0)


class TestDisplacementClass:
    """Tests for the Displacement class wrapper."""

    def _make_data(self):
        np.random.seed(42)
        m, n, p = 4, 6, 2
        F_true = np.random.rand(m, p) + 0.5
        G_true = np.random.rand(p, n) + 0.5
        X = F_true @ G_true + 0.05 * np.random.randn(m, n)
        sigma = np.ones_like(X) * 0.05
        base = pmf(X, sigma, p=2, max_iter=50, random_seed=42)
        return X, sigma, base

    def test_run_returns_self(self):
        X, sigma, base = self._make_data()
        disp = Displacement(base, X, sigma, dQ_thresholds=[4.0], max_iter=50)
        ret = disp.run()
        assert ret is disp

    def test_result_populated(self):
        X, sigma, base = self._make_data()
        disp = Displacement(base, X, sigma, dQ_thresholds=[4.0], max_iter=50)
        disp.run()
        assert disp.result is not None
        assert isinstance(disp.result, DisplacementResult)
        assert 4.0 in disp.result.G_min

    def test_features_subset(self):
        X, sigma, base = self._make_data()
        disp = Displacement(base, X, sigma, features=[0, 2], dQ_thresholds=[4.0], max_iter=50)
        disp.run()
        assert disp.result is not None
        # Feature indices not in subset should have base values
        G_base_val = disp.result.G_base[0, 1]
        assert disp.result.G_min[4.0][0, 1] == G_base_val
        assert disp.result.G_max[4.0][0, 1] == G_base_val

    def test_feature_labels(self):
        X, sigma, base = self._make_data()
        labels = ["A", "B", "C", "D", "E", "G"]
        disp = Displacement(base, X, sigma, feature_labels=labels, dQ_thresholds=[4.0])
        assert disp.feature_labels == labels

    def test_summary_no_crash(self, capsys):
        X, sigma, base = self._make_data()
        disp = Displacement(base, X, sigma, dQ_thresholds=[4.0], max_iter=50)
        disp.run()
        disp.summary()
        captured = capsys.readouterr()
        assert len(captured.out) > 0

    def test_plot_profile_returns_figure(self):
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt

        X, sigma, base = self._make_data()
        disp = Displacement(base, X, sigma, dQ_thresholds=[4.0], max_iter=50)
        disp.run()
        fig = disp.plot_profile(0, dQ=4.0)
        assert isinstance(fig, matplotlib.figure.Figure)
        plt.close(fig)

    def test_plot_contribution_returns_figure(self):
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt

        X, sigma, base = self._make_data()
        disp = Displacement(base, X, sigma, dQ_thresholds=[4.0], max_iter=50)
        disp.run()
        fig = disp.plot_contribution(0, dQ=4.0)
        assert isinstance(fig, matplotlib.figure.Figure)
        plt.close(fig)

    def test_plot_results_returns_figure(self):
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt

        X, sigma, base = self._make_data()
        disp = Displacement(base, X, sigma, dQ_thresholds=[4.0], max_iter=50)
        disp.run()
        fig = disp.plot_results(0, dQ=4.0)
        assert isinstance(fig, matplotlib.figure.Figure)
        plt.close(fig)

    def test_plot_before_run_raises(self):
        X, sigma, base = self._make_data()
        disp = Displacement(base, X, sigma, dQ_thresholds=[4.0])
        with pytest.raises(RuntimeError, match="No results"):
            disp.plot_profile(0)
