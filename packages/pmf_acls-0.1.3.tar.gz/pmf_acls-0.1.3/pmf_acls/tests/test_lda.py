"""
Tests for pmf_acls.lda — Bayesian LDA source apportionment.
"""

import numpy as np
import pytest

from pmf_acls.lda import (
    LDAResult,
    _compute_kl,
    _mh_steps_G_col,
    _sort_factors,
    pmf_lda,
)
from pmf_acls.data_structures import PMFResult


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def synthetic_data():
    """Small synthetic LDA problem: m=20 analytes, n=30 samples, p=2 sources."""
    rng = np.random.default_rng(42)
    m, n, p = 20, 30, 2
    F_true = rng.dirichlet(np.ones(m), size=p).T   # (m, p), columns sum to 1
    G_true = rng.exponential(2.0, size=(p, n))
    X_clean = F_true @ G_true
    sigma = np.maximum(0.1 * X_clean, 1e-4)
    X = np.maximum(X_clean + rng.normal(0, sigma), 1e-6)
    return X, sigma, p, F_true, G_true


@pytest.fixture
def quick_result(synthetic_data):
    X, sigma, p, _, _ = synthetic_data
    return pmf_lda(X, sigma, p, n_samples=100, n_burnin=50, random_seed=0)


# ---------------------------------------------------------------------------
# Return type and shapes
# ---------------------------------------------------------------------------

def test_returns_lda_result(quick_result):
    assert isinstance(quick_result, LDAResult)


def test_shapes(synthetic_data, quick_result):
    X, sigma, p, _, _ = synthetic_data
    m, n = X.shape
    assert quick_result.F.shape == (m, p)
    assert quick_result.G.shape == (p, n)
    assert quick_result.F_std.shape == (m, p)
    assert quick_result.G_std.shape == (p, n)
    assert quick_result.residuals.shape == (m, n)
    assert quick_result.kl_samples.shape == (100,)
    assert quick_result.Q_samples.shape == (100,)


def test_non_negativity(quick_result):
    assert np.all(quick_result.F >= 0)
    assert np.all(quick_result.G >= 0)
    assert np.all(quick_result.F_std >= 0)
    assert np.all(quick_result.G_std >= 0)


def test_G_columns_on_simplex(quick_result):
    """Posterior mean F columns must sum to 1 (simplex constraint)."""
    col_sums = quick_result.F.sum(axis=0)   # sum over variables (axis 0 = m)
    np.testing.assert_allclose(col_sums, np.ones(quick_result.F.shape[1]), atol=1e-10)


def test_all_finite(quick_result):
    assert np.all(np.isfinite(quick_result.F))
    assert np.all(np.isfinite(quick_result.G))
    assert np.all(np.isfinite(quick_result.F_std))
    assert np.all(np.isfinite(quick_result.G_std))
    assert np.all(np.isfinite(quick_result.kl_samples))
    assert np.all(np.isfinite(quick_result.Q_samples))


# ---------------------------------------------------------------------------
# store_samples
# ---------------------------------------------------------------------------

def test_store_samples_shapes(synthetic_data):
    X, sigma, p, _, _ = synthetic_data
    m, n = X.shape
    result = pmf_lda(X, sigma, p, n_samples=20, n_burnin=10,
                     store_samples=True, random_seed=1)
    assert result.F_samples.shape == (20, m, p)
    assert result.G_samples.shape == (20, p, n)


def test_no_store_samples_is_none(quick_result):
    assert quick_result.F_samples is None
    assert quick_result.G_samples is None


def test_store_samples_non_negative(synthetic_data):
    X, sigma, p, _, _ = synthetic_data
    result = pmf_lda(X, sigma, p, n_samples=20, n_burnin=10,
                     store_samples=True, random_seed=2)
    assert np.all(result.F_samples >= 0)
    assert np.all(result.G_samples >= 0)


def test_store_samples_G_on_simplex(synthetic_data):
    """Every stored F sample must have columns summing to 1."""
    X, sigma, p, _, _ = synthetic_data
    result = pmf_lda(X, sigma, p, n_samples=20, n_burnin=10,
                     store_samples=True, random_seed=3)
    # F_samples shape: (n_samples, m, p); sum over variables (axis=1) gives (n_samples, p)
    col_sums = result.F_samples.sum(axis=1)
    np.testing.assert_allclose(col_sums, np.ones_like(col_sums), atol=1e-10)


# ---------------------------------------------------------------------------
# Reproducibility
# ---------------------------------------------------------------------------

def test_reproducibility(synthetic_data):
    X, sigma, p, _, _ = synthetic_data
    r1 = pmf_lda(X, sigma, p, n_samples=50, n_burnin=20, random_seed=7)
    r2 = pmf_lda(X, sigma, p, n_samples=50, n_burnin=20, random_seed=7)
    np.testing.assert_array_equal(r1.F, r2.F)
    np.testing.assert_array_equal(r1.G, r2.G)
    np.testing.assert_array_equal(r1.kl_samples, r2.kl_samples)


def test_different_seeds_differ(synthetic_data):
    X, sigma, p, _, _ = synthetic_data
    r1 = pmf_lda(X, sigma, p, n_samples=50, n_burnin=20, random_seed=10)
    r2 = pmf_lda(X, sigma, p, n_samples=50, n_burnin=20, random_seed=11)
    assert not np.allclose(r1.F, r2.F)


# ---------------------------------------------------------------------------
# Hyperparameter learning
# ---------------------------------------------------------------------------

def test_learn_hyperparams_true_changes_lambda(synthetic_data):
    X, sigma, p, _, _ = synthetic_data
    result = pmf_lda(X, sigma, p, n_samples=50, n_burnin=20,
                     lambda_G=1.0, learn_hyperparams=True, random_seed=4)
    assert isinstance(result.lambda_G, float)
    assert result.lambda_G > 0


def test_learn_hyperparams_false_keeps_lambda(synthetic_data):
    X, sigma, p, _, _ = synthetic_data
    result = pmf_lda(X, sigma, p, n_samples=50, n_burnin=20,
                     lambda_G=2.5, learn_hyperparams=False, random_seed=5)
    assert result.lambda_G == pytest.approx(2.5)


# ---------------------------------------------------------------------------
# MH acceptance rate
# ---------------------------------------------------------------------------

def test_mh_acceptance_rate_in_range(quick_result):
    assert 0.0 <= quick_result.mh_acceptance_rate <= 1.0


def test_mh_acceptance_rate_positive(synthetic_data):
    """With the coordinate-wise proposal some steps must be accepted."""
    X, sigma, p, _, _ = synthetic_data
    result = pmf_lda(X, sigma, p, n_samples=200, n_burnin=100, random_seed=6)
    assert result.mh_acceptance_rate > 0.0


# ---------------------------------------------------------------------------
# Convergence and traces
# ---------------------------------------------------------------------------

def test_converged_flag_is_bool(quick_result):
    assert isinstance(quick_result.converged, bool)


def test_kl_samples_non_negative(quick_result):
    assert np.all(quick_result.kl_samples >= 0)


def test_Q_samples_positive(quick_result):
    assert np.all(quick_result.Q_samples >= 0)


def test_n_iter(synthetic_data):
    X, sigma, p, _, _ = synthetic_data
    result = pmf_lda(X, sigma, p, n_samples=30, n_burnin=20, n_thin=3,
                     random_seed=8)
    assert result.n_iter == 20 + 30 * 3
    assert len(result.kl_samples) == 30
    assert len(result.Q_samples) == 30


# ---------------------------------------------------------------------------
# to_pmf_result compatibility
# ---------------------------------------------------------------------------

def test_to_pmf_result_returns_pmf_result(quick_result):
    assert isinstance(quick_result.to_pmf_result(), PMFResult)


def test_to_pmf_result_shapes(synthetic_data, quick_result):
    X, sigma, p, _, _ = synthetic_data
    m, n = X.shape
    r = quick_result.to_pmf_result()
    assert r.F.shape == (m, p)
    assert r.G.shape == (p, n)


def test_to_pmf_result_q_history_length(quick_result):
    r = quick_result.to_pmf_result()
    assert len(r.Q_history) == len(quick_result.Q_samples)


def test_to_pmf_result_G_still_on_simplex(quick_result):
    """to_pmf_result must not alter F; columns must remain on simplex."""
    r = quick_result.to_pmf_result()
    col_sums = r.F.sum(axis=0)
    np.testing.assert_allclose(col_sums, np.ones(r.F.shape[1]), atol=1e-10)


# ---------------------------------------------------------------------------
# Validation errors
# ---------------------------------------------------------------------------

def test_invalid_alpha_raises(synthetic_data):
    X, sigma, p, _, _ = synthetic_data
    with pytest.raises(ValueError, match="alpha"):
        pmf_lda(X, sigma, p, alpha=0.0)


def test_invalid_n_samples_raises(synthetic_data):
    X, sigma, p, _, _ = synthetic_data
    with pytest.raises(ValueError):
        pmf_lda(X, sigma, p, n_samples=0)


def test_invalid_mh_step_size_raises(synthetic_data):
    X, sigma, p, _, _ = synthetic_data
    with pytest.raises(ValueError, match="mh_step_size"):
        pmf_lda(X, sigma, p, mh_step_size=-1.0)


def test_invalid_lambda_F_raises(synthetic_data):
    X, sigma, p, _, _ = synthetic_data
    with pytest.raises(ValueError, match="lambda_G"):
        pmf_lda(X, sigma, p, lambda_G=-0.5)


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def test_compute_kl_zero_at_exact_reconstruction():
    """KL = 0 when F@G == X exactly."""
    rng = np.random.default_rng(0)
    F = rng.dirichlet(np.ones(5), size=3).T
    G = rng.exponential(1.0, size=(3, 7))
    X = F @ G
    assert _compute_kl(F, G, X) == pytest.approx(0.0, abs=1e-10)


def test_compute_kl_non_negative():
    rng = np.random.default_rng(1)
    F = rng.dirichlet(np.ones(6), size=2).T
    G = rng.exponential(1.0, size=(2, 8))
    X = F @ G + 0.1 * rng.uniform(size=(6, 8))
    assert _compute_kl(F, G, X) >= 0.0


def test_compute_kl_handles_zero_X():
    """Entries with X==0 must not produce NaN."""
    F = np.array([[0.6, 0.4], [0.4, 0.6]])
    G = np.array([[1.0, 2.0], [1.0, 0.5]])
    X = np.array([[0.0, 1.5], [1.0, 0.5]])
    kl = _compute_kl(F, G, X)
    assert np.isfinite(kl)
    assert kl >= 0.0


def test_mh_steps_G_col_preserves_sum():
    """Coordinate swap must preserve sum of F column exactly."""
    rng = np.random.default_rng(42)
    m, n = 10, 20
    F_col = rng.dirichlet(np.ones(m))
    G_row = rng.exponential(1.0, size=n)
    X = np.outer(F_col, G_row) + 0.01 * rng.standard_normal((m, n))
    sigma2 = (0.1 * np.abs(X) + 1e-4) ** 2
    R = X - np.outer(F_col, G_row)
    F_new, R_new, _ = _mh_steps_G_col(F_col, G_row, R, sigma2, 1.0, 0.05, rng)
    assert F_new.sum() == pytest.approx(1.0, abs=1e-12)
    assert np.all(F_new >= 0)


def test_mh_steps_G_col_R_consistent():
    """Returned R must equal X - F_new @ G (single-factor case)."""
    rng = np.random.default_rng(7)
    m, n = 8, 15
    F_col = rng.dirichlet(np.ones(m))
    G_row = rng.exponential(2.0, size=n)
    X = np.outer(F_col, G_row) * (1 + 0.05 * rng.standard_normal((m, n)))
    X = np.maximum(X, 1e-6)
    sigma2 = (0.1 * X) ** 2
    R = X - np.outer(F_col, G_row)
    F_new, R_new, _ = _mh_steps_G_col(F_col, G_row, R, sigma2, 1.0, 0.05, rng)
    R_expected = X - np.outer(F_new, G_row)
    np.testing.assert_allclose(R_new, R_expected, atol=1e-12)


def test_sort_factors_descending_mass():
    rng = np.random.default_rng(0)
    F = rng.dirichlet(np.ones(6), size=4).T
    G = rng.exponential(1.0, size=(4, 5))
    G_s, F_s = _sort_factors(F.copy(), G.copy())
    masses = F_s.sum(axis=1)
    assert np.all(masses[:-1] >= masses[1:])


def test_sort_factors_preserves_product():
    rng = np.random.default_rng(1)
    F = rng.dirichlet(np.ones(5), size=3).T
    G = rng.exponential(1.0, size=(3, 7))
    product_before = F @ G
    G_s, F_s = _sort_factors(F.copy(), G.copy())
    np.testing.assert_allclose(G_s @ F_s, product_before, rtol=1e-12)


def test_sort_factors_G_stays_on_simplex():
    rng = np.random.default_rng(2)
    F = rng.dirichlet(np.ones(8), size=3).T
    G = rng.exponential(1.0, size=(3, 6))
    G_s, _ = _sort_factors(F, G)
    np.testing.assert_allclose(G_s.sum(axis=0), np.ones(3), atol=1e-12)


# ---------------------------------------------------------------------------
# Reconstruction quality
# ---------------------------------------------------------------------------

def test_reconstruction_quality(synthetic_data):
    """Posterior mean F@G should approximate X reasonably."""
    X, sigma, p, _, _ = synthetic_data
    result = pmf_lda(X, sigma, p, n_samples=300, n_burnin=150, random_seed=99)
    rel_error = np.linalg.norm(X - result.F @ result.G) / np.linalg.norm(X)
    assert rel_error < 0.5, f"Reconstruction relative error too large: {rel_error:.3f}"


def test_explained_variance_positive(synthetic_data):
    """A run with enough samples should give positive explained variance."""
    X, sigma, p, _, _ = synthetic_data
    result = pmf_lda(X, sigma, p, n_samples=300, n_burnin=150, random_seed=0)
    assert result.explained_variance > 0.0
