"""Tests for robust Student's t likelihood in pmf_acls.bayes."""

import numpy as np
import pytest
from pmf_acls.bayes import pmf_bayes, BayesNMFResult


@pytest.fixture
def synthetic_data():
    """Small synthetic PMF problem: m=12, n=40, p=3."""
    rng = np.random.default_rng(42)
    m, n, p = 12, 40, 3
    F_true = rng.uniform(0.1, 2.0, size=(m, p))
    G_true = rng.uniform(0.1, 2.0, size=(p, n))
    X = F_true @ G_true + 0.1 * rng.standard_normal((m, n))
    X = np.maximum(X, 0.0)
    sigma = 0.1 * np.ones((m, n))
    return X, sigma, p


@pytest.fixture
def data_with_outliers():
    """Synthetic data with 5% known outliers."""
    rng = np.random.default_rng(123)
    m, n, p = 15, 50, 3
    F_true = rng.uniform(0.1, 2.0, size=(m, p))
    G_true = rng.uniform(0.1, 2.0, size=(p, n))
    X_clean = F_true @ G_true + 0.05 * rng.standard_normal((m, n))
    X_clean = np.maximum(X_clean, 0.0)
    sigma = 0.05 * np.ones((m, n))

    # Inject outliers: 5% of elements multiplied by 10x
    X = X_clean.copy()
    n_outliers = int(0.05 * m * n)
    outlier_rows = rng.choice(m, size=n_outliers)
    outlier_cols = rng.choice(n, size=n_outliers)
    outlier_positions = set(zip(outlier_rows, outlier_cols))
    for i, j in outlier_positions:
        X[i, j] *= 10.0

    outlier_mask_true = np.zeros((m, n), dtype=bool)
    for i, j in outlier_positions:
        outlier_mask_true[i, j] = True

    return X, sigma, p, outlier_mask_true


# --- Backward compatibility ---

def test_robust_false_default(synthetic_data):
    """robust=False gives None for all eta fields."""
    X, sigma, p = synthetic_data
    result = pmf_bayes(X, sigma, p, n_samples=100, n_burnin=50, random_seed=0)
    assert result.eta_posterior_mean is None
    assert result.eta_posterior_std is None
    assert result.robust_df is None
    assert result.outlier_mask is None
    assert result.eta_samples is None


# --- Basic functionality ---

def test_robust_basic(synthetic_data):
    """robust=True runs and produces valid results."""
    X, sigma, p = synthetic_data
    m, n = X.shape
    result = pmf_bayes(
        X, sigma, p, n_samples=100, n_burnin=50, random_seed=0,
        robust=True, robust_df=5.0,
    )
    assert result.robust_df == 5.0
    assert result.eta_posterior_mean is not None
    assert result.eta_posterior_mean.shape == (m, n)
    assert result.eta_posterior_std.shape == (m, n)
    assert result.outlier_mask.shape == (m, n)
    assert np.all(result.eta_posterior_mean > 0)
    assert np.all(np.isfinite(result.eta_posterior_mean))
    assert result.Q > 0
    assert result.explained_variance > 0.5


# --- Outlier detection ---

def test_outlier_detection(data_with_outliers):
    """eta is lower at known outlier positions."""
    X, sigma, p, outlier_mask_true = data_with_outliers
    result = pmf_bayes(
        X, sigma, p, n_samples=300, n_burnin=200, random_seed=0,
        robust=True, robust_df=5.0,
    )
    # Outlier positions should have lower eta than non-outlier positions
    eta_at_outliers = result.eta_posterior_mean[outlier_mask_true].mean()
    eta_at_clean = result.eta_posterior_mean[~outlier_mask_true].mean()
    assert eta_at_outliers < eta_at_clean


# --- Shape validation ---

def test_eta_shapes(synthetic_data):
    """All eta fields have correct shapes."""
    X, sigma, p = synthetic_data
    m, n = X.shape
    ns = 80
    result = pmf_bayes(
        X, sigma, p, n_samples=ns, n_burnin=50, random_seed=0,
        robust=True, store_samples=True,
    )
    assert result.eta_posterior_mean.shape == (m, n)
    assert result.eta_posterior_std.shape == (m, n)
    assert result.outlier_mask.shape == (m, n)
    assert result.eta_samples is not None
    assert result.eta_samples.shape == (ns, m, n)
    assert np.all(result.eta_samples > 0)


# --- Interaction with hierarchical sigma ---

def test_robust_with_hierarchical_sigma(synthetic_data):
    """robust=True + sigma_prior='per_variable' works together."""
    X, sigma, p = synthetic_data
    m, n = X.shape
    result = pmf_bayes(
        X, sigma, p, n_samples=100, n_burnin=50, random_seed=0,
        robust=True, sigma_prior="per_variable",
    )
    assert result.eta_posterior_mean is not None
    assert result.sigma_posterior_mean is not None
    assert result.eta_posterior_mean.shape == (m, n)
    assert result.sigma_posterior_mean.shape == (m,)


# --- Interaction with lognormal ---

def test_robust_with_lognormal(synthetic_data):
    """robust=True + likelihood='lognormal' works."""
    X, sigma, p = synthetic_data
    X = np.maximum(X, 1e-6)  # lognormal needs positive data
    sigma = 0.1 * X
    result = pmf_bayes(
        X, sigma, p, n_samples=100, n_burnin=50, random_seed=0,
        robust=True, likelihood="lognormal",
    )
    assert result.eta_posterior_mean is not None
    assert result.robust_df == 5.0


# --- Store samples ---

def test_robust_store_samples(synthetic_data):
    """store_samples=True with robust stores eta_samples."""
    X, sigma, p = synthetic_data
    ns = 60
    result = pmf_bayes(
        X, sigma, p, n_samples=ns, n_burnin=50, random_seed=0,
        robust=True, store_samples=True,
    )
    assert result.eta_samples is not None
    assert result.eta_samples.shape == (ns, X.shape[0], X.shape[1])


# --- robust_df field ---

def test_robust_df_field(synthetic_data):
    """robust_df is correctly stored."""
    X, sigma, p = synthetic_data
    result = pmf_bayes(
        X, sigma, p, n_samples=50, n_burnin=30, random_seed=0,
        robust=True, robust_df=3.0,
    )
    assert result.robust_df == 3.0


# --- Validation ---

def test_invalid_robust_df(synthetic_data):
    """Invalid robust_df raises ValueError."""
    X, sigma, p = synthetic_data
    with pytest.raises(ValueError, match="robust_df"):
        pmf_bayes(X, sigma, p, n_samples=50, n_burnin=20,
                  robust=True, robust_df=-1.0)
    with pytest.raises(ValueError, match="robust_df"):
        pmf_bayes(X, sigma, p, n_samples=50, n_burnin=20,
                  robust=True, robust_df=0.0)
