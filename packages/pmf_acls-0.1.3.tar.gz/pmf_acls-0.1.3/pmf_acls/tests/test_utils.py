"""Tests for data preparation utilities."""

import pytest
import numpy as np
from pmf_acls.utils import (
    prepare_data,
    handle_missing_values,
    handle_below_detection_limit,
    estimate_uncertainty,
    enforce_minimum_uncertainty,
    flag_outliers,
    check_data_quality,
)


class TestPrepareData:
    """Tests for prepare_data convenience function."""

    def test_prepare_clean_data(self):
        """Test with already clean data."""
        np.random.seed(42)

        X = np.random.rand(5, 10) + 0.5
        sigma = np.random.rand(5, 10) * 0.1

        X_clean, sigma_clean = prepare_data(X, sigma)

        # Should be similar to input (minimal changes)
        assert X_clean.shape == X.shape
        assert sigma_clean.shape == sigma.shape
        assert np.all(X_clean >= 0)
        assert np.all(sigma_clean > 0)

    def test_prepare_data_with_missing(self):
        """Test handling missing values."""
        X = np.array([[1.0, 2.0, np.nan],
                      [3.0, np.nan, 4.0],
                      [5.0, 6.0, 7.0]])

        X_clean, sigma_clean = prepare_data(X)

        # No NaN in output
        assert not np.any(np.isnan(X_clean))
        assert not np.any(np.isnan(sigma_clean))

        # Non-negative
        assert np.all(X_clean >= 0)
        assert np.all(sigma_clean > 0)

    def test_prepare_data_with_bdl(self):
        """Test handling below-detection-limit values."""
        X = np.array([[1.0, 2.0, 3.0],
                      [-0.1, 0.05, 1.5],  # Negative and BDL values
                      [0.8, 1.2, 2.1]])
        DL = np.array([0.1, 0.1, 0.1])

        X_clean, sigma_clean = prepare_data(X, detection_limit=DL)

        # No negative values
        assert np.all(X_clean >= 0)

        # BDL values should be replaced with DL/2
        assert X_clean[1, 0] == pytest.approx(0.05)  # -0.1 → 0.1/2

    def test_prepare_data_estimate_uncertainty(self):
        """Test automatic uncertainty estimation."""
        np.random.seed(42)

        X = np.random.rand(5, 10) * 10 + 5

        # Don't provide sigma
        X_clean, sigma_clean = prepare_data(X, sigma=None, uncertainty_method="poisson")

        # Should have positive uncertainties
        assert np.all(sigma_clean > 0)

        # Should be roughly sqrt(X) for Poisson
        expected = np.sqrt(X_clean)
        assert np.allclose(sigma_clean, expected, rtol=0.5)

    def test_prepare_data_verbose(self, capsys):
        """Test verbose output."""
        X = np.array([[1.0, 2.0, np.nan],
                      [3.0, 4.0, 5.0]])
        DL = np.array([0.1, 0.1])

        prepare_data(X, detection_limit=DL, verbose=True)

        captured = capsys.readouterr()
        assert "PMF Data Preparation" in captured.out
        assert "Missing values" in captured.out


class TestHandleMissingValues:
    """Tests for missing value handling."""

    def test_no_missing_values(self):
        """Test with no missing values."""
        X = np.array([[1.0, 2.0, 3.0],
                      [4.0, 5.0, 6.0]])
        sigma = np.ones_like(X) * 0.1

        X_filled, sigma_filled = handle_missing_values(X, sigma)

        # Should be unchanged
        np.testing.assert_array_equal(X_filled, X)
        np.testing.assert_array_equal(sigma_filled, sigma)

    def test_median_replacement(self):
        """Test median replacement for missing values."""
        X = np.array([[1.0, 2.0, np.nan, 4.0],
                      [10.0, 20.0, 30.0, np.nan]])

        X_filled, sigma_filled = handle_missing_values(X, method="median")

        # Check replacement
        assert X_filled[0, 2] == pytest.approx(2.0)  # Median of [1, 2, 4]
        assert X_filled[1, 3] == pytest.approx(20.0)  # Median of [10, 20, 30]

        # Check uncertainties are large for missing
        assert sigma_filled[0, 2] > sigma_filled[0, 0]
        assert sigma_filled[1, 3] > sigma_filled[1, 0]

    def test_mean_replacement(self):
        """Test mean replacement for missing values."""
        X = np.array([[1.0, 2.0, np.nan, 4.0]])

        X_filled, _ = handle_missing_values(X, method="mean")

        # Mean of [1, 2, 4] = 2.33...
        assert X_filled[0, 2] == pytest.approx(7.0/3.0)

    def test_zero_replacement(self):
        """Test zero replacement for missing values."""
        X = np.array([[1.0, np.nan, 3.0]])

        X_filled, _ = handle_missing_values(X, method="zero")

        assert X_filled[0, 1] == 0.0

    def test_all_missing_row(self):
        """Test handling row with all missing values."""
        X = np.array([[np.nan, np.nan, np.nan],
                      [1.0, 2.0, 3.0]])

        X_filled, _ = handle_missing_values(X)

        # Should fill with zeros
        assert np.all(X_filled[0, :] == 0.0)


class TestHandleBelowDetectionLimit:
    """Tests for BDL value handling."""

    def test_no_bdl_values(self):
        """Test with no BDL values."""
        X = np.array([[1.0, 2.0, 3.0],
                      [4.0, 5.0, 6.0]])
        sigma = np.ones_like(X) * 0.1
        DL = np.array([0.5, 0.5])

        X_clean, sigma_clean = handle_below_detection_limit(X, sigma, DL)

        # Should be unchanged
        np.testing.assert_array_equal(X_clean, X)

    def test_half_dl_replacement(self):
        """Test half-DL replacement."""
        X = np.array([[1.0, 0.05, 3.0],
                      [0.03, 5.0, 6.0]])
        DL = np.array([0.1, 0.1])

        X_clean, sigma_clean = handle_below_detection_limit(
            X, detection_limit=DL, replacement="half_dl"
        )

        # Check replacements
        assert X_clean[0, 1] == pytest.approx(0.05)  # 0.1 / 2
        assert X_clean[1, 0] == pytest.approx(0.05)

        # Check uncertainties (5·DL/6)
        expected_sigma = 5.0 / 6.0 * 0.1
        assert sigma_clean[0, 1] == pytest.approx(expected_sigma)

    def test_third_dl_replacement(self):
        """Test third-DL replacement."""
        X = np.array([[0.05, 2.0]])
        DL = 0.1

        X_clean, _ = handle_below_detection_limit(
            X, detection_limit=DL, replacement="third_dl"
        )

        assert X_clean[0, 0] == pytest.approx(0.1/3.0)

    def test_negative_values_as_bdl(self):
        """Test that negative values are treated as BDL."""
        X = np.array([[1.0, -0.5, 3.0]])
        DL = 0.1

        X_clean, _ = handle_below_detection_limit(X, detection_limit=DL)

        # Negative should be replaced
        assert X_clean[0, 1] == pytest.approx(0.05)

    def test_scalar_dl(self):
        """Test with scalar detection limit."""
        X = np.array([[1.0, 0.05],
                      [0.03, 2.0]])

        X_clean, _ = handle_below_detection_limit(X, detection_limit=0.1)

        assert X_clean[0, 1] == pytest.approx(0.05)
        assert X_clean[1, 0] == pytest.approx(0.05)


class TestEstimateUncertainty:
    """Tests for uncertainty estimation."""

    def test_poisson_uncertainty(self):
        """Test Poisson uncertainty estimation."""
        X = np.array([[1.0, 4.0, 9.0, 16.0]])

        sigma = estimate_uncertainty(X, method="poisson")

        # Should be sqrt(X)
        expected = np.array([[1.0, 2.0, 3.0, 4.0]])
        np.testing.assert_array_almost_equal(sigma, expected)

    def test_fraction_uncertainty(self):
        """Test fraction-based uncertainty."""
        X = np.array([[10.0, 20.0, 30.0]])
        min_frac = 0.1

        sigma = estimate_uncertainty(X, method="fraction", min_fraction=min_frac)

        expected = 0.1 * X
        np.testing.assert_array_almost_equal(sigma, expected)

    def test_auto_uncertainty(self):
        """Test automatic method selection."""
        # Mix of large and small values
        X = np.array([[100.0, 0.5, 50.0, 0.1]])

        sigma = estimate_uncertainty(X, method="auto", min_fraction=0.1)

        # Should use Poisson for large, fraction for small
        assert sigma[0, 0] == pytest.approx(np.sqrt(100.0))  # Poisson
        assert sigma[0, 1] >= 0.05  # Fraction for small values

    def test_minimum_uncertainty_enforced(self):
        """Test that minimum uncertainty is enforced."""
        X = np.array([[1.0, 2.0, 3.0]])

        sigma = estimate_uncertainty(X, method="poisson", min_fraction=0.2)

        # All should be >= 0.2 * X
        assert np.all(sigma >= 0.2 * X)


class TestEnforceMinimumUncertainty:
    """Tests for minimum uncertainty enforcement."""

    def test_enforce_minimum(self):
        """Test enforcing minimum uncertainty."""
        X = np.array([[10.0, 20.0, 30.0]])
        sigma = np.array([[0.5, 1.0, 2.0]])  # Some below 10%

        sigma_enforced = enforce_minimum_uncertainty(X, sigma, min_fraction=0.1)

        # Should be at least 10% of X
        expected_min = 0.1 * X
        assert np.all(sigma_enforced >= expected_min)

    def test_already_above_minimum(self):
        """Test when uncertainties already above minimum."""
        X = np.array([[10.0, 20.0]])
        sigma = np.array([[2.0, 4.0]])  # Already >= 10%

        sigma_enforced = enforce_minimum_uncertainty(X, sigma, min_fraction=0.1)

        # Should be unchanged
        np.testing.assert_array_equal(sigma_enforced, sigma)

    def test_absolute_minimum(self):
        """Test absolute minimum uncertainty."""
        X = np.array([[0.0, 1e-12]])
        sigma = np.array([[0.0, 1e-15]])

        sigma_enforced = enforce_minimum_uncertainty(X, sigma)

        # Should have at least 1e-10
        assert np.all(sigma_enforced >= 1e-10)


class TestFlagOutliers:
    """Tests for outlier detection."""

    def test_zscore_method(self):
        """Test z-score outlier detection."""
        X = np.array([[2.0, 2.0, 2.0, 2.0, 10.0]])  # 10.0 is outlier
        sigma = np.ones_like(X) * 0.5

        outlier_mask = flag_outliers(X, sigma, threshold=4.0, method="zscore")

        # Should flag the outlier
        assert outlier_mask[0, 4] == True
        # Most others should not be flagged
        assert np.sum(outlier_mask[0, :4]) <= 1

    def test_iqr_method(self):
        """Test IQR outlier detection."""
        # Normal data plus outliers
        X = np.array([[1, 2, 3, 4, 5, 6, 7, 8, 9, 100.0]])
        sigma = np.ones_like(X)

        outlier_mask = flag_outliers(X, sigma, method="iqr")

        # Should flag extreme value
        assert outlier_mask[0, -1] == True

    def test_no_outliers(self):
        """Test with no outliers."""
        np.random.seed(42)
        X = np.random.randn(3, 20) * 0.1 + 5.0  # Tight normal distribution
        sigma = np.ones_like(X) * 0.5  # Large sigma

        outlier_mask = flag_outliers(X, sigma, threshold=5.0)

        # With large sigma and tight distribution, should have very few outliers
        # At most a few statistical outliers
        assert np.sum(outlier_mask) < 10


class TestCheckDataQuality:
    """Tests for data quality checking."""

    def test_clean_data(self):
        """Test quality check on clean data."""
        np.random.seed(42)
        X = np.random.rand(5, 10) + 1.0
        sigma = np.random.rand(5, 10) * 0.1 + 0.1

        diagnostics = check_data_quality(X, sigma, verbose=False)

        assert diagnostics['n_missing'] == 0
        assert diagnostics['n_negative'] == 0
        assert diagnostics['zero_uncertainty'] == 0

    def test_data_with_issues(self):
        """Test quality check on problematic data."""
        X = np.array([[1.0, np.nan, 3.0],
                      [-1.0, 0.0, 5.0],
                      [2.0, 3.0, 4.0]])
        sigma = np.array([[0.1, 0.1, 0.0],
                          [0.1, 0.1, 0.1],
                          [0.1, 0.1, 0.1]])

        diagnostics = check_data_quality(X, sigma, verbose=False)

        assert diagnostics['n_missing'] == 1
        assert diagnostics['n_negative'] == 1
        assert diagnostics['n_zero'] == 1
        assert diagnostics['zero_uncertainty'] == 1

    def test_signal_to_noise(self):
        """Test signal-to-noise calculation."""
        X = np.array([[10.0, 20.0, 30.0]])
        sigma = np.array([[1.0, 2.0, 3.0]])

        diagnostics = check_data_quality(X, sigma, verbose=False)

        # S/N should be X/sigma
        expected_sn = np.median([10.0, 10.0, 10.0])
        assert diagnostics['signal_to_noise'] == pytest.approx(expected_sn)

    def test_verbose_output(self, capsys):
        """Test verbose output."""
        X = np.array([[1.0, 2.0]])
        sigma = np.array([[0.1, 0.2]])

        check_data_quality(X, sigma, verbose=True)

        captured = capsys.readouterr()
        assert "Data Quality Diagnostics" in captured.out
        assert "Signal-to-noise" in captured.out


class TestIntegration:
    """Integration tests for data preparation workflow."""

    def test_full_workflow(self):
        """Test complete data preparation workflow."""
        np.random.seed(42)

        # Create messy data
        X = np.random.rand(5, 20) * 10 + 5
        # Add missing values
        X[0, 5] = np.nan
        X[2, 10] = np.nan
        # Add BDL values
        X[1, 3] = -0.5
        X[3, 7] = 0.05

        DL = np.ones(5) * 0.1

        # Prepare data
        X_clean, sigma_clean = prepare_data(
            X, detection_limit=DL,
            missing_method="median",
            uncertainty_method="poisson",
            bdl_replacement="half_dl",
            verbose=False
        )

        # Verify output quality
        assert not np.any(np.isnan(X_clean))
        assert not np.any(np.isnan(sigma_clean))
        assert np.all(X_clean >= 0)
        assert np.all(sigma_clean > 0)

        # Check data quality
        diagnostics = check_data_quality(X_clean, sigma_clean, verbose=False)
        assert diagnostics['n_missing'] == 0
        assert diagnostics['n_negative'] == 0
        assert diagnostics['zero_uncertainty'] == 0

    def test_prepare_for_pmf(self):
        """Test preparing data that can be used with PMF."""
        from pmf_acls import pmf

        np.random.seed(42)

        # Create data with issues
        m, n, p_true = 5, 20, 2
        F_true = np.random.rand(m, p_true) + 0.5
        G_true = np.random.rand(p_true, n) + 0.5
        X = F_true @ G_true
        # Add noise and issues
        X += 0.1 * np.random.randn(m, n)
        X[0, 5] = np.nan  # Missing
        X[2, 10] = -0.1  # Negative

        # Prepare
        X_clean, sigma_clean = prepare_data(X, verbose=False)

        # Should be able to run PMF without errors
        result = pmf(X_clean, sigma_clean, p=2, max_iter=30, random_seed=42)

        assert result.F.shape == (m, p_true)
        assert result.G.shape == (p_true, n)
        assert np.all(result.F >= 0)
        assert np.all(result.G >= 0)
