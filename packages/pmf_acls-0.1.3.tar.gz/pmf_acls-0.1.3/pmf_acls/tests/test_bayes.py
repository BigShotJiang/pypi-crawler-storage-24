"""
Tests for pmf_acls.bayes — Bayesian NMF via Gibbs sampling.
"""

import numpy as np
import pytest

from pmf_acls.bayes import (
    BayesNMFResult,
    _compute_Q,
    _geweke_z,
    _make_sampler,
    _normalize_factors,
    pmf_bayes,
)
from pmf_acls.data_structures import PMFResult
from pmf_acls import pmf


# ---------------------------------------------------------------------------
# Shared fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def synthetic_data():
    """Small synthetic PMF problem: m=20, n=10, p=2."""
    rng = np.random.default_rng(42)
    m, n, p = 20, 10, 2
    F_true = rng.uniform(0.1, 2.0, size=(m, p))
    G_true = rng.uniform(0.1, 2.0, size=(p, n))
    X = F_true @ G_true + 0.05 * rng.standard_normal((m, n))
    X = np.maximum(X, 0.0)
    sigma = 0.1 * np.ones((m, n))
    return X, sigma, p, F_true, G_true


@pytest.fixture
def quick_result(synthetic_data):
    """BayesNMFResult with small n_samples for fast tests."""
    X, sigma, p, _, _ = synthetic_data
    return pmf_bayes(X, sigma, p, n_samples=200, n_burnin=100, random_seed=0)


# ---------------------------------------------------------------------------
# Basic shape and type tests
# ---------------------------------------------------------------------------

def test_returns_bayes_result(quick_result):
    assert isinstance(quick_result, BayesNMFResult)


def test_shapes(synthetic_data, quick_result):
    X, sigma, p, _, _ = synthetic_data
    m, n = X.shape
    assert quick_result.F.shape == (m, p)
    assert quick_result.G.shape == (p, n)
    assert quick_result.F_std.shape == (m, p)
    assert quick_result.G_std.shape == (p, n)
    assert quick_result.residuals.shape == (m, n)
    assert quick_result.Q_samples.shape == (200,)


def test_non_negativity(quick_result):
    assert np.all(quick_result.F >= 0), "F posterior mean contains negatives"
    assert np.all(quick_result.G >= 0), "G posterior mean contains negatives"
    assert np.all(quick_result.F_std >= 0), "F_std contains negatives"
    assert np.all(quick_result.G_std >= 0), "G_std contains negatives"


def test_all_finite(quick_result):
    assert np.all(np.isfinite(quick_result.F))
    assert np.all(np.isfinite(quick_result.G))
    assert np.all(np.isfinite(quick_result.F_std))
    assert np.all(np.isfinite(quick_result.G_std))
    assert np.all(np.isfinite(quick_result.Q_samples))
    assert np.isfinite(quick_result.Q)
    assert np.isfinite(quick_result.explained_variance)


# ---------------------------------------------------------------------------
# store_samples
# ---------------------------------------------------------------------------

def test_store_samples_shapes(synthetic_data):
    X, sigma, p, _, _ = synthetic_data
    m, n = X.shape
    result = pmf_bayes(X, sigma, p, n_samples=50, n_burnin=20,
                       store_samples=True, random_seed=1)
    assert result.F_samples is not None
    assert result.G_samples is not None
    assert result.F_samples.shape == (50, m, p)
    assert result.G_samples.shape == (50, p, n)


def test_no_store_samples_is_none(quick_result):
    assert quick_result.F_samples is None
    assert quick_result.G_samples is None


def test_store_samples_non_negative(synthetic_data):
    X, sigma, p, _, _ = synthetic_data
    result = pmf_bayes(X, sigma, p, n_samples=30, n_burnin=10,
                       store_samples=True, random_seed=2)
    assert np.all(result.F_samples >= 0)
    assert np.all(result.G_samples >= 0)


# ---------------------------------------------------------------------------
# Reproducibility
# ---------------------------------------------------------------------------

def test_reproducibility(synthetic_data):
    X, sigma, p, _, _ = synthetic_data
    r1 = pmf_bayes(X, sigma, p, n_samples=50, n_burnin=20, random_seed=7)
    r2 = pmf_bayes(X, sigma, p, n_samples=50, n_burnin=20, random_seed=7)
    np.testing.assert_array_equal(r1.Q_samples, r2.Q_samples)
    np.testing.assert_array_equal(r1.F, r2.F)


def test_different_seeds_differ(synthetic_data):
    X, sigma, p, _, _ = synthetic_data
    r1 = pmf_bayes(X, sigma, p, n_samples=50, n_burnin=20, random_seed=1)
    r2 = pmf_bayes(X, sigma, p, n_samples=50, n_burnin=20, random_seed=2)
    assert not np.allclose(r1.F, r2.F), "Different seeds produced identical F"


# ---------------------------------------------------------------------------
# Hyperparameter learning
# ---------------------------------------------------------------------------

def test_learn_hyperparams_false_keeps_lambda(synthetic_data):
    X, sigma, p, _, _ = synthetic_data
    result = pmf_bayes(X, sigma, p, n_samples=50, n_burnin=20,
                       lambda_F=2.5, lambda_G=3.0,
                       learn_hyperparams=False, random_seed=3)
    assert result.lambda_F == pytest.approx(2.5)
    assert result.lambda_G == pytest.approx(3.0)


def test_learn_hyperparams_true_changes_lambda(synthetic_data):
    X, sigma, p, _, _ = synthetic_data
    result = pmf_bayes(X, sigma, p, n_samples=50, n_burnin=20,
                       lambda_F=1.0, lambda_G=1.0,
                       learn_hyperparams=True, random_seed=4)
    # When learning, posterior means will generally differ from initial values
    # (not strictly guaranteed but expected for most datasets)
    assert result.lambda_F > 0
    assert result.lambda_G > 0


# ---------------------------------------------------------------------------
# Convergence diagnostics
# ---------------------------------------------------------------------------

def test_converged_flag_is_bool(quick_result):
    assert isinstance(quick_result.converged, bool)


def test_Q_trace_not_monotone(quick_result):
    """Q should fluctuate in a converged chain (not systematically increasing)."""
    trace = quick_result.Q_samples
    # A proper Gibbs chain should not be monotonically decreasing or increasing
    diffs = np.diff(trace)
    has_increase = np.any(diffs > 0)
    has_decrease = np.any(diffs < 0)
    assert has_increase and has_decrease, "Q trace appears non-stationary"


def test_geweke_z_runs(quick_result):
    z = _geweke_z(quick_result.Q_samples)
    assert np.isfinite(z)


# ---------------------------------------------------------------------------
# to_pmf_result compatibility
# ---------------------------------------------------------------------------

def test_to_pmf_result_returns_pmf_result(quick_result):
    result = quick_result.to_pmf_result()
    assert isinstance(result, PMFResult)


def test_to_pmf_result_shapes(synthetic_data, quick_result):
    X, sigma, p, _, _ = synthetic_data
    m, n = X.shape
    result = quick_result.to_pmf_result()
    assert result.F.shape == (m, p)
    assert result.G.shape == (p, n)
    assert result.F_std is not None
    assert result.G_std is not None
    assert result.F_std.shape == (m, p)


def test_to_pmf_result_q_history_length(quick_result):
    result = quick_result.to_pmf_result()
    assert len(result.Q_history) == 200


# ---------------------------------------------------------------------------
# pmf() integration via algorithm='bayes'
# ---------------------------------------------------------------------------

def test_pmf_bayes_algorithm_returns_pmf_result(synthetic_data):
    X, sigma, p, _, _ = synthetic_data
    result = pmf(X, sigma, p, algorithm="bayes", n_samples=50, n_burnin=20,
                 random_seed=5)
    assert isinstance(result, PMFResult)
    assert result.F.shape[1] == p
    assert result.G.shape[0] == p


def test_pmf_invalid_algorithm_raises():
    X = np.ones((5, 5))
    sigma = np.ones((5, 5))
    with pytest.raises(ValueError, match="Invalid algorithm"):
        pmf(X, sigma, 2, algorithm="not_an_algorithm")


# ---------------------------------------------------------------------------
# Input validation
# ---------------------------------------------------------------------------

def test_invalid_p_raises(synthetic_data):
    X, sigma, _, _, _ = synthetic_data
    with pytest.raises((ValueError, RuntimeError)):
        pmf_bayes(X, sigma, p=50)  # p too large for this dataset


def test_invalid_n_samples_raises(synthetic_data):
    X, sigma, p, _, _ = synthetic_data
    with pytest.raises(ValueError):
        pmf_bayes(X, sigma, p, n_samples=0)


def test_invalid_lambda_raises(synthetic_data):
    X, sigma, p, _, _ = synthetic_data
    with pytest.raises(ValueError):
        pmf_bayes(X, sigma, p, lambda_F=-1.0)


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def test_compute_Q_zero_residual():
    F = np.array([[1.0, 0.0], [0.0, 1.0]])
    G = np.array([[2.0, 3.0], [1.0, 4.0]])
    X = F @ G
    sigma = np.ones_like(X)
    assert _compute_Q(F, G, X, sigma) == pytest.approx(0.0)


def test_geweke_z_constant_trace():
    trace = np.ones(100)
    z = _geweke_z(trace)
    assert z == pytest.approx(0.0)


def test_normalize_factors_preserves_product():
    rng = np.random.default_rng(0)
    F = rng.uniform(0.1, 2.0, (5, 3))
    G = rng.uniform(0.1, 2.0, (3, 7))
    product_before = F @ G
    G_n, F_n, _, _ = _normalize_factors(F.copy(), G.copy())
    product_after = G_n @ F_n
    np.testing.assert_allclose(product_before, product_after, rtol=1e-12)


def test_normalize_factors_unit_l1_norm():
    rng = np.random.default_rng(1)
    F = rng.uniform(0.5, 3.0, (8, 3))
    G = rng.uniform(0.5, 3.0, (3, 6))
    G_n, _, _, _ = _normalize_factors(F.copy(), G.copy())
    col_sums = G_n.sum(axis=0)
    np.testing.assert_allclose(col_sums, np.ones(3), rtol=1e-12)


def test_normalize_factors_sorted_descending():
    rng = np.random.default_rng(2)
    F = rng.uniform(0.1, 1.0, (6, 4))
    G = rng.uniform(0.1, 1.0, (4, 5))
    _, F_n, _, _ = _normalize_factors(F.copy(), G.copy())
    masses = F_n.sum(axis=1)
    assert np.all(masses[:-1] >= masses[1:]), "Factors not sorted by decreasing mass"


# ---------------------------------------------------------------------------
# Reconstruction quality (loose tolerances — posterior uncertainty is large)
# ---------------------------------------------------------------------------

def test_reconstruction_quality(synthetic_data):
    """Posterior mean GF should approximate X reasonably well."""
    X, sigma, p, _, _ = synthetic_data
    result = pmf_bayes(X, sigma, p, n_samples=300, n_burnin=200, random_seed=99)
    X_hat = result.F @ result.G
    rel_error = np.linalg.norm(X - X_hat) / np.linalg.norm(X)
    # Loose tolerance: Bayesian posterior mean may not be MAP, but should fit
    assert rel_error < 0.5, f"Reconstruction relative error too large: {rel_error:.3f}"


def test_explained_variance_positive(quick_result):
    assert quick_result.explained_variance > 0.0


def test_n_iter(synthetic_data):
    X, sigma, p, _, _ = synthetic_data
    result = pmf_bayes(X, sigma, p, n_samples=50, n_burnin=30, n_thin=2,
                       random_seed=6)
    assert result.n_iter == 30 + 50 * 2
    assert len(result.Q_samples) == 50


# ---------------------------------------------------------------------------
# sampler parameter
# ---------------------------------------------------------------------------

def test_icdf_sampler_default(synthetic_data):
    """sampler='icdf' (default) runs without error and returns valid result."""
    X, sigma, p, _, _ = synthetic_data
    result = pmf_bayes(X, sigma, p, n_samples=50, n_burnin=20, random_seed=7)
    assert np.all(np.isfinite(result.F))
    assert np.all(np.isfinite(result.G))
    assert np.all(result.F >= 0)
    assert np.all(result.G >= 0)


def test_scipy_sampler_explicit(synthetic_data):
    """sampler='scipy' runs without error and returns valid result."""
    X, sigma, p, _, _ = synthetic_data
    result = pmf_bayes(X, sigma, p, n_samples=50, n_burnin=20,
                       random_seed=7, sampler="scipy")
    assert np.all(np.isfinite(result.F))
    assert np.all(np.isfinite(result.G))
    assert np.all(result.F >= 0)
    assert np.all(result.G >= 0)


def test_sampler_results_statistically_equivalent(synthetic_data):
    """icdf and scipy samplers should produce similar posterior means."""
    X, sigma, p, _, _ = synthetic_data
    r_icdf = pmf_bayes(X, sigma, p, n_samples=500, n_burnin=200,
                       random_seed=42, sampler="icdf")
    r_scipy = pmf_bayes(X, sigma, p, n_samples=500, n_burnin=200,
                        random_seed=42, sampler="scipy")
    # Posterior means from two valid samplers should reconstruct X similarly
    err_icdf = np.linalg.norm(X - r_icdf.F @ r_icdf.G) / np.linalg.norm(X)
    err_scipy = np.linalg.norm(X - r_scipy.F @ r_scipy.G) / np.linalg.norm(X)
    assert abs(err_icdf - err_scipy) < 0.2, (
        f"Samplers diverged: icdf err={err_icdf:.3f}, scipy err={err_scipy:.3f}"
    )


def test_invalid_sampler_raises(synthetic_data):
    X, sigma, p, _, _ = synthetic_data
    with pytest.raises(ValueError, match="sampler must be"):
        pmf_bayes(X, sigma, p, sampler="bad_sampler")


def test_make_sampler_icdf_non_negative():
    """_make_sampler('icdf') should return non-negative samples."""
    rng = np.random.default_rng(0)
    sample_fn = _make_sampler("icdf")
    mu = np.array([-2.0, -1.0, 0.0, 1.0, 2.0])
    tau = np.ones(5)
    samples = sample_fn(mu, tau, rng)
    assert np.all(samples >= 0)
    assert np.all(np.isfinite(samples))


def test_make_sampler_scipy_non_negative():
    """_make_sampler('scipy') should return non-negative samples."""
    rng = np.random.default_rng(0)
    sample_fn = _make_sampler("scipy")
    mu = np.array([-2.0, -1.0, 0.0, 1.0, 2.0])
    tau = np.ones(5)
    samples = sample_fn(mu, tau, rng)
    assert np.all(samples >= 0)
    assert np.all(np.isfinite(samples))
