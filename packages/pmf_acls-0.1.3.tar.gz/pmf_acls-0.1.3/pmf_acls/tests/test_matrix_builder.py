"""Tests for matrix_builder module."""

import pytest
import numpy as np
import scipy.sparse as sp
from pmf_acls.matrix_builder import (
    build_gamma_matrix,
    build_weight_matrix,
    build_system_matrices,
    build_residual_vector,
    build_theta_vector,
    build_theta_star_vector,
    extract_updates_from_phi,
    compute_scaling_coefficients,
    quadratic_log_approximation,
    compute_objective_function,
)


class TestBuildGammaMatrix:
    """Tests for build_gamma_matrix function."""

    def test_basic_construction(self):
        """Test basic Gamma matrix construction."""
        m, n, p = 3, 4, 2
        F = np.random.rand(m, p)
        G = np.random.rand(p, n)

        Gamma = build_gamma_matrix(F, G)

        # Check shape
        assert Gamma.shape == (m * n, (m + n) * p)

        # Check sparsity
        expected_nonzeros = 2 * m * n * p
        assert Gamma.nnz == expected_nonzeros

    def test_values_correctness(self):
        """Test that Gamma contains correct values."""
        m, n, p = 2, 3, 2
        F = np.array([[1.0, 2.0], [3.0, 4.0]])
        G = np.array([[5.0, 6.0, 7.0], [8.0, 9.0, 10.0]])

        Gamma = build_gamma_matrix(F, G)

        # Check a few specific elements according to Table I
        # For i=0, j=0, k=0:
        #   row = 0*3 + 0 = 0
        #   col_F = 0*3 + 0 = 0
        #   col_G = 3*2 + 0*2 + 0 = 6
        #   Gamma[0, 0] should be F[0,0] = 1.0
        #   Gamma[0, 6] should be G[0,0] = 5.0

        assert Gamma[0, 0] == pytest.approx(1.0)
        assert Gamma[0, 6] == pytest.approx(5.0)

    def test_incompatible_shapes(self):
        """Test error on incompatible F and G shapes."""
        F = np.random.rand(3, 2)
        G = np.random.rand(3, 4)  # p mismatch

        with pytest.raises(ValueError, match="Incompatible shapes"):
            build_gamma_matrix(F, G)

    def test_return_type(self):
        """Test that return type is CSR matrix."""
        F = np.random.rand(3, 2)
        G = np.random.rand(2, 4)

        Gamma = build_gamma_matrix(F, G)
        assert isinstance(Gamma, sp.csr_matrix)


class TestBuildWeightMatrix:
    """Tests for build_weight_matrix function."""

    def test_basic_construction(self):
        """Test weight matrix construction."""
        m, n = 3, 4
        weights = np.random.rand(m, n)

        W = build_weight_matrix(weights)

        # Check shape
        assert W.shape == (m * n, m * n)

        # Check diagonal
        w_flat = weights.ravel()
        W_dense = W.toarray()
        np.testing.assert_array_almost_equal(np.diag(W_dense), w_flat)

    def test_return_type(self):
        """Test that return type is DIA matrix."""
        weights = np.random.rand(3, 4)
        W = build_weight_matrix(weights)
        assert isinstance(W, sp.dia_matrix)


class TestBuildSystemMatrices:
    """Tests for build_system_matrices function."""

    def test_basic_construction(self):
        """Test building all system matrices."""
        m, n, p = 3, 4, 2
        F = np.random.rand(m, p)
        G = np.random.rand(p, n)
        weights = np.ones((m, n))
        c = np.ones(p)
        d = np.ones(p)
        a_G = np.ones((m, p))
        a_F = np.ones((p, n))
        gamma, delta, alpha, beta = 1.0, 1.0, 1.0, 1.0

        Gamma, W, K_r, K_p = build_system_matrices(
            F, G, weights, c, d, a_G, a_F, gamma, delta, alpha, beta
        )

        # Check shapes
        assert Gamma.shape == (m * n, (m + n) * p)
        assert W.shape == (m * n, m * n)
        assert K_r.shape == ((m + n) * p, (m + n) * p)
        assert K_p.shape == ((m + n) * p, (m + n) * p)

    def test_regularization_values(self):
        """Test that regularization matrix has correct values."""
        m, n, p = 2, 3, 2
        F = np.random.rand(m, p)
        G = np.random.rand(p, n)
        weights = np.ones((m, n))
        c = np.array([0.5, 0.6])
        d = np.array([0.7, 0.8])
        a_G = np.ones((m, p))
        a_F = np.ones((p, n))
        gamma, delta = 2.0, 3.0
        alpha, beta = 0.0, 0.0

        _, _, K_r, _ = build_system_matrices(
            F, G, weights, c, d, a_G, a_F, gamma, delta, alpha, beta
        )

        K_r_diag = K_r.diagonal()

        # Check G elements (first n*p = 6 elements)
        # Should be delta * d[k] for each k
        for k in range(p):
            for j in range(n):
                idx = k * n + j
                expected = delta * d[k]
                assert K_r_diag[idx] == pytest.approx(expected)


class TestBuildResidualVector:
    """Tests for build_residual_vector function."""

    def test_basic_construction(self):
        """Test residual vector construction."""
        residuals = np.array([[1.0, 2.0, 3.0], [4.0, 5.0, 6.0]])

        r = build_residual_vector(residuals)

        expected = np.array([1.0, 2.0, 3.0, 4.0, 5.0, 6.0])
        np.testing.assert_array_equal(r, expected)

    def test_shape(self):
        """Test output shape."""
        m, n = 3, 4
        residuals = np.random.rand(m, n)

        r = build_residual_vector(residuals)
        assert r.shape == (m * n,)


class TestBuildThetaVector:
    """Tests for build_theta_vector function."""

    def test_basic_construction(self):
        """Test theta vector construction."""
        F = np.array([[1.0, 2.0], [3.0, 4.0]])
        G = np.array([[5.0, 6.0, 7.0], [8.0, 9.0, 10.0]])

        Theta = build_theta_vector(F, G)

        # Should be [G elements, F elements] in row-major order
        # G: [5, 6, 7, 8, 9, 10], F: [1, 2, 3, 4]
        expected = np.array([5.0, 6.0, 7.0, 8.0, 9.0, 10.0, 1.0, 2.0, 3.0, 4.0])
        np.testing.assert_array_equal(Theta, expected)

    def test_shape(self):
        """Test output shape."""
        m, n, p = 3, 4, 2
        F = np.random.rand(m, p)
        G = np.random.rand(p, n)

        Theta = build_theta_vector(F, G)
        assert Theta.shape == ((m + n) * p,)


class TestBuildThetaStarVector:
    """Tests for build_theta_star_vector function."""

    def test_basic_construction(self):
        """Test theta-star vector construction."""
        b_G = np.array([[1.0, 2.0], [3.0, 4.0]])
        b_F = np.array([[5.0, 6.0, 7.0], [8.0, 9.0, 10.0]])

        Theta_star = build_theta_star_vector(b_G, b_F)

        # Should be [G elements, F elements] in row-major order
        expected = np.array([5.0, 6.0, 7.0, 8.0, 9.0, 10.0, 1.0, 2.0, 3.0, 4.0])
        np.testing.assert_array_equal(Theta_star, expected)


class TestExtractUpdatesFromPhi:
    """Tests for extract_updates_from_phi function."""

    def test_basic_extraction(self):
        """Test extracting f and g from phi."""
        m, n, p = 2, 3, 2

        # Create phi with known values
        # G elements: 6 values, F elements: 4 values
        phi = np.arange(1.0, 11.0)

        f, g = extract_updates_from_phi(phi, m, n, p)

        # f should be first n*p=6 elements reshaped to (p, n)
        expected_f = np.array([[1.0, 2.0, 3.0], [4.0, 5.0, 6.0]])
        np.testing.assert_array_equal(f, expected_f)

        # g should be last m*p=4 elements reshaped to (m, p)
        expected_g = np.array([[7.0, 8.0], [9.0, 10.0]])
        np.testing.assert_array_equal(g, expected_g)


class TestComputeScalingCoefficients:
    """Tests for compute_scaling_coefficients function."""

    def test_basic_computation(self):
        """Test scaling coefficient computation."""
        F = np.array([[1.0, 2.0], [3.0, 4.0]])  # sums: [4, 6]
        G = np.array([[1.0, 2.0], [3.0, 4.0]])  # sums: [3, 7]

        c, d = compute_scaling_coefficients(F, G)

        # c[k] = 1 / sum_i |F[i,k]|
        expected_c = np.array([1.0 / 4.0, 1.0 / 6.0])
        np.testing.assert_array_almost_equal(c, expected_c)

        # d[k] = 1 / sum_j |G[k,j]|
        expected_d = np.array([1.0 / 3.0, 1.0 / 7.0])
        np.testing.assert_array_almost_equal(d, expected_d)

    def test_zero_column(self):
        """Test handling of zero columns."""
        F = np.array([[1.0, 0.0], [2.0, 0.0]])
        G = np.array([[1.0, 2.0], [3.0, 4.0]])

        c, d = compute_scaling_coefficients(F, G)

        # Second column is zero, should get c[1] = 1.0
        assert c[0] == pytest.approx(1.0 / 3.0)
        assert c[1] == pytest.approx(1.0)


class TestQuadraticLogApproximation:
    """Tests for quadratic_log_approximation function."""

    def test_basic_computation(self):
        """Test quadratic approximation constants."""
        theta = np.array([1.0, 2.0, 3.0])

        a, b = quadratic_log_approximation(theta)

        # Check shapes
        assert a.shape == theta.shape
        assert b.shape == theta.shape

        # Check that a is positive for positive theta
        assert np.all(a > 0)

        # Note: b can be negative for theta > 1 according to Equation 12
        # b = theta - 2*theta*ln(theta), which is negative when ln(theta) > 0.5

    def test_very_small_values(self):
        """Test handling of very small values."""
        theta = np.array([1e-20, 1.0])

        a, b = quadratic_log_approximation(theta)

        # Should not produce NaN or inf
        assert np.all(np.isfinite(a))
        assert np.all(np.isfinite(b))

    def test_equation_11_12(self):
        """Test that equations 11 and 12 are implemented correctly."""
        theta_0 = 2.0
        theta = np.array([theta_0])

        a, b = quadratic_log_approximation(theta)

        # Equation (11): a = 1 / (4 * ln(10) * ln(theta_0)^2 * theta_0)
        ln_theta_0 = np.log(theta_0)
        expected_a = 1.0 / (4.0 * np.log(10) * ln_theta_0**2 * theta_0)
        assert a[0] == pytest.approx(expected_a)

        # Equation (12): b = theta_0 - 2 * theta_0 * ln(theta_0)
        expected_b = theta_0 - 2.0 * theta_0 * ln_theta_0
        assert b[0] == pytest.approx(expected_b)


class TestComputeObjectiveFunction:
    """Tests for compute_objective_function function."""

    def test_basic_computation(self):
        """Test objective function computation."""
        m, n, p = 3, 4, 2
        residuals = np.random.randn(m, n) * 0.1
        sigma = np.ones((m, n)) * 0.1
        F = np.random.rand(m, p) + 0.1
        G = np.random.rand(p, n) + 0.1
        c = np.ones(p)
        d = np.ones(p)
        alpha, beta, gamma, delta = 1.0, 1.0, 1.0, 1.0

        Q_basic, Q_enhanced = compute_objective_function(
            residuals, sigma, F, G, c, d, alpha, beta, gamma, delta
        )

        # Q_basic should be positive
        assert Q_basic >= 0

        # Q_enhanced should be different from Q_basic when penalties are active
        assert Q_enhanced != Q_basic

    def test_basic_mode(self):
        """Test with all penalties disabled (basic mode)."""
        m, n, p = 3, 4, 2
        residuals = np.random.randn(m, n) * 0.1
        sigma = np.ones((m, n)) * 0.1
        F = np.random.rand(m, p) + 0.1
        G = np.random.rand(p, n) + 0.1
        c = np.ones(p)
        d = np.ones(p)
        alpha, beta, gamma, delta = 0.0, 0.0, 0.0, 0.0

        Q_basic, Q_enhanced = compute_objective_function(
            residuals, sigma, F, G, c, d, alpha, beta, gamma, delta
        )

        # In basic mode, Q_enhanced should equal Q_basic
        assert Q_basic == pytest.approx(Q_enhanced)

    def test_perfect_fit(self):
        """Test with zero residuals."""
        m, n, p = 3, 4, 2
        residuals = np.zeros((m, n))
        sigma = np.ones((m, n))
        F = np.random.rand(m, p) + 0.1
        G = np.random.rand(p, n) + 0.1
        c = np.ones(p)
        d = np.ones(p)
        alpha, beta, gamma, delta = 0.0, 0.0, 0.0, 0.0

        Q_basic, Q_enhanced = compute_objective_function(
            residuals, sigma, F, G, c, d, alpha, beta, gamma, delta
        )

        # Q_basic should be zero
        assert Q_basic == pytest.approx(0.0)
