"""Tests for diagnostics module."""

import pytest
import numpy as np
from pmf_acls import pmf, PMFResult
from pmf_acls.diagnostics import (
    select_factors,
    compute_scaled_residuals,
    residual_statistics,
    compute_contributions,
    explained_variance_per_variable,
    print_diagnostics,
)


class TestSelectFactors:
    """Tests for factor selection function."""

    def test_select_factors_basic(self):
        """Test basic factor selection workflow."""
        np.random.seed(42)

        # Create data with known number of factors
        m, n, p_true = 8, 15, 2
        F_true = np.random.rand(m, p_true) + 0.5
        G_true = np.random.rand(p_true, n) + 0.5
        X = F_true @ G_true + 0.05 * np.random.randn(m, n)
        sigma = np.ones_like(X) * 0.05

        # Test p from 1 to 3
        result = select_factors(
            X, sigma,
            p_range=(1, 3),
            n_runs=3,
            random_seed=42,
            max_iter=50
        )

        # Check result structure
        assert result.p_values == [1, 2, 3]
        assert len(result.Q_values) == 3
        assert len(result.Q_robust) == 3
        assert len(result.best_results) == 3
        assert result.best_p in [1, 2, 3]

        # Check that each p has correct number of Q values
        for p in result.p_values:
            assert len(result.Q_values[p]) <= 3  # Some runs may fail

        # Best result should be a PMFResult
        assert isinstance(result.best_results[result.best_p], PMFResult)

    def test_select_factors_reproducibility(self):
        """Test that results are reproducible with same seed."""
        np.random.seed(42)

        m, n = 5, 10
        X = np.random.rand(m, n) + 0.5
        sigma = np.ones_like(X) * 0.1

        result1 = select_factors(
            X, sigma,
            p_range=(1, 2),
            n_runs=2,
            random_seed=123,
            max_iter=30
        )

        result2 = select_factors(
            X, sigma,
            p_range=(1, 2),
            n_runs=2,
            random_seed=123,
            max_iter=30
        )

        # Same recommended p
        assert result1.best_p == result2.best_p

        # Same Q values
        for p in result1.p_values:
            np.testing.assert_array_almost_equal(
                result1.Q_values[p],
                result2.Q_values[p]
            )

    def test_select_factors_invalid_inputs(self):
        """Test error handling for invalid inputs."""
        np.random.seed(42)

        m, n = 5, 10
        X = np.random.rand(m, n)
        sigma = np.ones_like(X) * 0.1

        # p_min < 1
        with pytest.raises(ValueError, match="p_min must be at least 1"):
            select_factors(X, sigma, p_range=(0, 2))

        # p_max > min(m, n)
        with pytest.raises(ValueError, match="p_max must be at most"):
            select_factors(X, sigma, p_range=(1, 15))

        # p_max < p_min
        with pytest.raises(ValueError, match="p_max must be >= p_min"):
            select_factors(X, sigma, p_range=(3, 2))

        # n_runs < 1
        with pytest.raises(ValueError, match="n_runs must be at least 1"):
            select_factors(X, sigma, p_range=(1, 2), n_runs=0)

    def test_select_factors_single_p(self):
        """Test with single p value (p_min = p_max)."""
        np.random.seed(42)

        m, n, p = 5, 10, 2
        X = np.random.rand(m, n) + 0.5
        sigma = np.ones_like(X) * 0.1

        result = select_factors(
            X, sigma,
            p_range=(p, p),
            n_runs=2,
            random_seed=42,
            max_iter=30
        )

        assert result.p_values == [p]
        assert result.best_p == p
        assert len(result.Q_values[p]) == 2

    def test_q_robust_calculation(self):
        """Test that Q_robust is calculated correctly."""
        np.random.seed(42)

        m, n = 5, 10
        X = np.random.rand(m, n) + 0.5
        sigma = np.ones_like(X) * 0.1

        result = select_factors(
            X, sigma,
            p_range=(1, 2),
            n_runs=2,
            random_seed=42,
            max_iter=30
        )

        for p in result.p_values:
            # Q_robust = Q / (m*n - (m+n)*p)
            dof = m * n - (m + n) * p
            Q_best = np.min(result.Q_values[p])
            expected_q_robust = Q_best / dof

            np.testing.assert_almost_equal(
                result.Q_robust[p],
                expected_q_robust
            )


class TestScaledResiduals:
    """Tests for scaled residual calculations."""

    def test_compute_scaled_residuals(self):
        """Test scaled residual computation."""
        np.random.seed(42)

        m, n, p = 5, 10, 2
        F = np.random.rand(m, p)
        G = np.random.rand(p, n)
        X = F @ G + 0.1 * np.random.randn(m, n)
        sigma = np.ones_like(X) * 0.1

        scaled_res = compute_scaled_residuals(X, F, G, sigma)

        # Check shape
        assert scaled_res.shape == (m, n)

        # Check formula: (X - GF) / sigma
        expected = (X - F @ G) / sigma
        np.testing.assert_array_almost_equal(scaled_res, expected)

    def test_residual_statistics_per_variable(self):
        """Test residual statistics per variable."""
        np.random.seed(42)

        m, n, p = 5, 10, 2
        X = np.random.rand(m, n) + 0.5
        sigma = np.ones_like(X) * 0.1

        result = pmf(X, sigma, p=2, max_iter=30, random_seed=42)

        stats = residual_statistics(result, sigma, per_variable=True)

        # Check that stats have correct shape
        assert stats['mean'].shape == (m,)
        assert stats['std'].shape == (m,)
        assert stats['min'].shape == (m,)
        assert stats['max'].shape == (m,)
        assert stats['percentile_5'].shape == (m,)
        assert stats['percentile_95'].shape == (m,)

        # Basic sanity checks
        assert np.all(stats['min'] <= stats['mean'])
        assert np.all(stats['mean'] <= stats['max'])
        assert np.all(stats['std'] >= 0)

    def test_residual_statistics_per_observation(self):
        """Test residual statistics per observation."""
        np.random.seed(42)

        m, n, p = 5, 10, 2
        X = np.random.rand(m, n) + 0.5
        sigma = np.ones_like(X) * 0.1

        result = pmf(X, sigma, p=2, max_iter=30, random_seed=42)

        stats = residual_statistics(result, sigma, per_variable=False)

        # Check that stats have correct shape (per observation)
        assert stats['mean'].shape == (n,)
        assert stats['std'].shape == (n,)


class TestContributions:
    """Tests for factor contribution calculations."""

    def test_compute_contributions(self):
        """Test contribution computation."""
        np.random.seed(42)

        m, n, p = 5, 10, 3
        F = np.random.rand(m, p)
        G = np.random.rand(p, n)

        contributions = compute_contributions(F, G)

        # Check shape
        assert contributions.shape == (p, m, n)

        # Check that sum of contributions equals GF
        total = np.sum(contributions, axis=0)
        expected = F @ G
        np.testing.assert_array_almost_equal(total, expected)

        # Check individual contributions
        for k in range(p):
            expected_k = np.outer(F[:, k], G[k, :])
            np.testing.assert_array_almost_equal(
                contributions[k, :, :],
                expected_k
            )

    def test_contributions_non_negative(self):
        """Test that contributions are non-negative for non-negative F, G."""
        np.random.seed(42)

        m, n, p = 5, 10, 2
        X = np.random.rand(m, n) + 0.5
        sigma = np.ones_like(X) * 0.1

        result = pmf(X, sigma, p=2, max_iter=30, random_seed=42)

        contributions = compute_contributions(result.F, result.G)

        # All contributions should be non-negative
        assert np.all(contributions >= 0)


class TestExplainedVariance:
    """Tests for explained variance calculations."""

    def test_explained_variance_per_variable(self):
        """Test explained variance per variable."""
        np.random.seed(42)

        m, n, p = 5, 10, 2
        F_true = np.random.rand(m, p)
        G_true = np.random.rand(p, n)
        X = F_true @ G_true + 0.01 * np.random.randn(m, n)
        sigma = np.ones_like(X) * 0.01

        # Use basic mode for simpler test (no regularization)
        result = pmf(X, sigma, p=2, mode="basic", max_iter=100, random_seed=42)

        r2_per_var = explained_variance_per_variable(X, result)

        # Check shape
        assert r2_per_var.shape == (m,)

        # R² can be negative for poor fits (worse than mean)
        # Just check that it's finite and <= 1.0
        assert np.all(np.isfinite(r2_per_var))
        assert np.all(r2_per_var <= 1.0)

    def test_explained_variance_perfect_fit(self):
        """Test R² on perfect reconstruction."""
        np.random.seed(42)

        m, n, p = 5, 10, 2
        F = np.random.rand(m, p)
        G = np.random.rand(p, n)
        X = F @ G  # Perfect fit, no noise

        # Create a mock result
        result = PMFResult(
            F=F, G=G, Q=0.0, Q_history=[0.0],
            n_iter=1, converged=True,
            residuals=np.zeros_like(X),
            explained_variance=1.0,
            chi2=0.0
        )

        r2_per_var = explained_variance_per_variable(X, result)

        # Should be 1.0 for all variables (perfect fit)
        np.testing.assert_array_almost_equal(r2_per_var, np.ones(m))


class TestPrintDiagnostics:
    """Tests for diagnostic printing."""

    def test_print_diagnostics_runs(self, capsys):
        """Test that print_diagnostics runs without errors."""
        np.random.seed(42)

        m, n, p = 5, 10, 2
        X = np.random.rand(m, n) + 0.5
        sigma = np.ones_like(X) * 0.1

        result = pmf(X, sigma, p=2, max_iter=30, random_seed=42)

        # Should not raise
        print_diagnostics(result, sigma)

        captured = capsys.readouterr()
        assert "PMF DIAGNOSTICS" in captured.out
        assert "Goodness of Fit" in captured.out
        assert "Scaled Residuals" in captured.out

    def test_print_diagnostics_warnings(self, capsys):
        """Test diagnostic warnings for poor fits."""
        np.random.seed(42)

        # Create data with p=3 true factors
        m, n, p_true = 8, 15, 3
        F_true = np.random.rand(m, p_true)
        G_true = np.random.rand(p_true, n)
        X = F_true @ G_true + 0.1 * np.random.randn(m, n)
        sigma = np.ones_like(X) * 0.1

        # Fit with only p=1 (underfitting)
        result = pmf(X, sigma, p=1, max_iter=50, random_seed=42)

        print_diagnostics(result, sigma)

        captured = capsys.readouterr()
        # Should warn about underfitting
        assert "Q_robust" in captured.out


class TestIntegration:
    """Integration tests combining multiple diagnostic tools."""

    def test_full_diagnostic_workflow(self):
        """Test complete diagnostic workflow."""
        np.random.seed(42)

        # Create synthetic data
        m, n, p_true = 10, 20, 3
        F_true = np.random.rand(m, p_true) + 0.5
        G_true = np.random.rand(p_true, n) + 0.5
        X = F_true @ G_true + 0.05 * np.random.randn(m, n)
        sigma = np.ones_like(X) * 0.05

        # Run factor selection
        selection = select_factors(
            X, sigma,
            p_range=(1, 4),
            n_runs=3,
            random_seed=42,
            max_iter=50
        )

        # Use best result
        best_result = selection.best_results[selection.best_p]

        # Compute diagnostics
        scaled_res = compute_scaled_residuals(
            X, best_result.F, best_result.G, sigma
        )
        contributions = compute_contributions(
            best_result.F, best_result.G
        )
        r2_per_var = explained_variance_per_variable(X, best_result)

        # All should run without errors
        assert scaled_res.shape == (m, n)
        assert contributions.shape == (selection.best_p, m, n)
        assert r2_per_var.shape == (m,)

    def test_factor_selection_summary(self, capsys):
        """Test factor selection summary output."""
        np.random.seed(42)

        m, n = 5, 10
        X = np.random.rand(m, n) + 0.5
        sigma = np.ones_like(X) * 0.1

        result = select_factors(
            X, sigma,
            p_range=(1, 2),
            n_runs=2,
            random_seed=42,
            max_iter=30
        )

        # Test summary method
        result.summary()

        captured = capsys.readouterr()
        assert "Factor Selection Summary" in captured.out
        assert "Recommended p" in captured.out
        assert "Q_robust" in captured.out
