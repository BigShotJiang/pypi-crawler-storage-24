"""
Tests for Bayesian diagnostics: ESS, Gelman-Rubin, WAIC, and ARD.
"""

import numpy as np
import pytest

from pmf_acls.bayes_diagnostics import (
    effective_sample_size,
    gelman_rubin,
    compute_waic,
)
from pmf_acls.bayes import pmf_bayes


# ---- Fixtures ----

@pytest.fixture
def rng():
    return np.random.default_rng(42)


@pytest.fixture
def synthetic_data(rng):
    """Clean synthetic data with 3 true factors."""
    m, n, p = 15, 25, 3
    F_true = rng.exponential(1.0, size=(m, p))
    G_true = rng.exponential(1.0, size=(p, n))
    X_true = F_true @ G_true
    sigma = 0.05 * np.ones((m, n)) + 0.1 * X_true
    noise = rng.normal(0, sigma)
    X = np.maximum(X_true + noise, 0.0)
    return X, sigma, p


# ============================================================================
# effective_sample_size
# ============================================================================


class TestEffectiveSampleSize:
    def test_white_noise_ess_near_n(self, rng):
        """White noise (no autocorrelation) → ESS ≈ n."""
        n = 2000
        trace = rng.normal(0, 1, size=n)
        ess = effective_sample_size(trace)
        # Should be close to n (within factor of ~2)
        assert ess > n * 0.5

    def test_highly_correlated_ess_low(self):
        """Highly autocorrelated trace → ESS << n."""
        n = 2000
        trace = np.cumsum(np.random.default_rng(0).normal(0, 1, size=n))
        ess = effective_sample_size(trace)
        assert ess < n * 0.2

    def test_constant_trace(self):
        """Constant trace → ESS = n (no variance means no autocorrelation issue)."""
        trace = np.ones(100)
        ess = effective_sample_size(trace)
        assert ess == 100.0

    def test_short_trace(self):
        """Very short trace returns len(trace)."""
        trace = np.array([1.0, 2.0, 3.0])
        ess = effective_sample_size(trace)
        assert ess == 3.0

    def test_returns_positive(self, rng):
        """ESS is always positive."""
        trace = rng.normal(size=500)
        ess = effective_sample_size(trace)
        assert ess >= 1.0


# ============================================================================
# gelman_rubin
# ============================================================================


class TestGelmanRubin:
    def test_converged_chains(self, rng):
        """Chains from the same distribution → Rhat ≈ 1."""
        chains = [rng.normal(0, 1, size=1000) for _ in range(4)]
        rhat = gelman_rubin(*chains)
        assert rhat < 1.1

    def test_divergent_chains(self):
        """Chains with different means → Rhat >> 1."""
        rng = np.random.default_rng(0)
        c1 = rng.normal(0, 1, size=1000)
        c2 = rng.normal(10, 1, size=1000)
        rhat = gelman_rubin(c1, c2)
        assert rhat > 2.0

    def test_requires_two_chains(self):
        """Raises ValueError with fewer than 2 chains."""
        with pytest.raises(ValueError, match="at least 2"):
            gelman_rubin(np.ones(10))

    def test_constant_chains(self):
        """Constant chains → Rhat = 1."""
        c1 = np.ones(100) * 5.0
        c2 = np.ones(100) * 5.0
        rhat = gelman_rubin(c1, c2)
        assert rhat == 1.0


# ============================================================================
# compute_waic
# ============================================================================


class TestComputeWAIC:
    def test_basic_waic(self, synthetic_data, rng):
        """WAIC returns dict with expected keys."""
        X, sigma, p = synthetic_data
        S = 20
        m, n = X.shape
        F_samples = rng.exponential(1.0, size=(S, m, p))
        G_samples = rng.exponential(1.0, size=(S, p, n))

        result = compute_waic(X, sigma, F_samples, G_samples)
        assert {"waic", "lppd", "p_waic", "se", "min_ess"} <= set(result.keys())
        assert np.isfinite(result["waic"])
        assert np.isfinite(result["lppd"])
        assert result["p_waic"] >= 0  # effective params should be non-negative
        assert result["se"] >= 0

    def test_waic_none_samples_raises(self, synthetic_data):
        """WAIC with None samples raises ValueError."""
        X, sigma, _ = synthetic_data
        with pytest.raises(ValueError, match="store_samples"):
            compute_waic(X, sigma, None, None)

    def test_better_model_lower_waic(self, rng):
        """Model closer to truth has lower WAIC."""
        m, n, p = 10, 15, 2
        F_true = rng.exponential(1.0, size=(m, p))
        G_true = rng.exponential(1.0, size=(p, n))
        X = F_true @ G_true
        sigma = 0.1 * np.ones((m, n))

        S = 50
        # Good model: samples near the truth
        G_good = np.stack([F_true + rng.normal(0, 0.05, size=(m, p)) for _ in range(S)])
        G_good = np.maximum(G_good, 1e-6)
        F_good = np.stack([G_true + rng.normal(0, 0.05, size=(p, n)) for _ in range(S)])
        F_good = np.maximum(F_good, 1e-6)

        # Bad model: random samples
        G_bad = rng.exponential(2.0, size=(S, m, p))
        F_bad = rng.exponential(2.0, size=(S, p, n))

        waic_good = compute_waic(X, sigma, G_good, F_good)
        waic_bad = compute_waic(X, sigma, G_bad, F_bad)
        assert waic_good["waic"] < waic_bad["waic"]

    def test_waic_from_pmf_bayes(self, synthetic_data):
        """Integration test: WAIC from actual pmf_bayes output."""
        X, sigma, p = synthetic_data
        result = pmf_bayes(
            X, sigma, p,
            n_samples=50, n_burnin=50,
            store_samples=True, random_seed=42,
        )
        waic = compute_waic(X, sigma, result.F_samples, result.G_samples)
        assert np.isfinite(waic["waic"])
        assert waic["p_waic"] > 0


# ============================================================================
# ARD (Automatic Relevance Determination)
# ============================================================================


class TestARD:
    def test_ard_returns_fields(self, synthetic_data):
        """ARD populates active_factors, effective_p, and per-factor lambdas."""
        X, sigma, p = synthetic_data
        result = pmf_bayes(
            X, sigma, p,
            n_samples=100, n_burnin=100,
            ard=True, random_seed=42,
        )
        assert result.active_factors is not None
        assert result.effective_p is not None
        assert result.ard_lambda_F is not None
        assert result.ard_lambda_G is not None
        assert result.ard_lambda_F.shape == (p,)
        assert result.ard_lambda_G.shape == (p,)
        assert result.active_factors.shape == (p,)
        assert result.active_factors.dtype == bool
        assert 0 <= result.effective_p <= p

    def test_ard_false_no_fields(self, synthetic_data):
        """Without ARD, ARD fields are None."""
        X, sigma, p = synthetic_data
        result = pmf_bayes(
            X, sigma, p,
            n_samples=50, n_burnin=50,
            ard=False, random_seed=42,
        )
        assert result.active_factors is None
        assert result.effective_p is None
        assert result.ard_lambda_F is None
        assert result.ard_lambda_G is None

    def test_ard_prunes_extra_factors(self, rng):
        """Over-specifying p with ARD should prune unnecessary factors."""
        # 2 true factors, ask for 5
        m, n, p_true = 20, 30, 2
        F_true = rng.exponential(1.0, size=(m, p_true))
        G_true = rng.exponential(1.0, size=(p_true, n))
        X_true = F_true @ G_true
        sigma = 0.02 * np.ones((m, n)) + 0.05 * X_true
        X = np.maximum(X_true + rng.normal(0, sigma), 0.0)

        p_over = 5
        result = pmf_bayes(
            X, sigma, p_over,
            n_samples=300, n_burnin=300,
            ard=True, hyperparam_shape=0.5,
            random_seed=42,
        )
        # Should identify that fewer than 5 factors are needed
        assert result.effective_p is not None
        assert result.effective_p < p_over
        # The true rank is 2; effective_p should be 2 or 3
        assert result.effective_p <= p_true + 1

    def test_ard_backward_compat_shapes(self, synthetic_data):
        """ARD result has same F/G shapes and valid Q as non-ARD."""
        X, sigma, p = synthetic_data
        r1 = pmf_bayes(X, sigma, p, n_samples=50, n_burnin=50,
                        ard=False, random_seed=42)
        r2 = pmf_bayes(X, sigma, p, n_samples=50, n_burnin=50,
                        ard=True, random_seed=42)
        assert r1.F.shape == r2.F.shape
        assert r1.G.shape == r2.G.shape
        assert np.isfinite(r2.Q)
        assert np.isfinite(r2.explained_variance)

    def test_ard_repr_includes_info(self, synthetic_data):
        """ARD result repr mentions active factors."""
        X, sigma, p = synthetic_data
        result = pmf_bayes(
            X, sigma, p,
            n_samples=50, n_burnin=50,
            ard=True, random_seed=42,
        )
        r = repr(result)
        assert "ARD" in r
        assert "active factors" in r

    def test_ard_forces_learn_hyperparams(self, synthetic_data):
        """ARD forces learn_hyperparams=True even if user passes False."""
        X, sigma, p = synthetic_data
        # This should not raise; learn_hyperparams is overridden internally
        result = pmf_bayes(
            X, sigma, p,
            n_samples=50, n_burnin=50,
            ard=True, learn_hyperparams=False,
            random_seed=42,
        )
        # Per-factor lambdas should vary (evidence of learning)
        assert result.ard_lambda_F is not None

    def test_ard_factor_activity_samples(self, synthetic_data):
        """ARD populates factor_activity_samples with correct shape."""
        X, sigma, p = synthetic_data
        n_samples = 100
        result = pmf_bayes(
            X, sigma, p,
            n_samples=n_samples, n_burnin=50,
            ard=True, random_seed=42,
        )
        assert result.factor_activity_samples is not None
        assert result.factor_activity_samples.shape == (n_samples, p)
        # Fractions should sum to ~1 at each sample
        row_sums = result.factor_activity_samples.sum(axis=1)
        np.testing.assert_allclose(row_sums, 1.0, atol=1e-10)
        # All values non-negative
        assert np.all(result.factor_activity_samples >= 0)

    def test_no_ard_no_activity_samples(self, synthetic_data):
        """Without ARD, factor_activity_samples is None."""
        X, sigma, p = synthetic_data
        result = pmf_bayes(
            X, sigma, p,
            n_samples=50, n_burnin=50,
            ard=False, random_seed=42,
        )
        assert result.factor_activity_samples is None


# ============================================================================
# Factor count posterior
# ============================================================================


class TestFactorCountPosterior:
    def test_basic_output(self, synthetic_data):
        """factor_count_posterior returns expected keys and shapes."""
        X, sigma, p = synthetic_data
        result = pmf_bayes(
            X, sigma, p,
            n_samples=100, n_burnin=50,
            ard=True, random_seed=42,
        )
        from pmf_acls.bayes_diagnostics import factor_count_posterior
        fc = factor_count_posterior(result.factor_activity_samples)
        assert "pmf" in fc
        assert "mean" in fc
        assert "median" in fc
        assert "ci_90" in fc
        assert "prob_gt" in fc
        assert fc["pmf"].shape == (p + 1,)
        assert fc["prob_gt"].shape == (p + 1,)
        # PMF sums to 1
        np.testing.assert_allclose(fc["pmf"].sum(), 1.0, atol=1e-10)
        # prob_gt[0] = P(active > 0) should be high (we have real factors)
        assert fc["prob_gt"][0] > 0.5
        # prob_gt[p] = P(active > p) should be 0
        assert fc["prob_gt"][p] == 0.0
        # mean and median should be positive
        assert fc["mean"] > 0
        assert fc["median"] > 0
        # CI should be a tuple of two ints
        lo, hi = fc["ci_90"]
        assert lo <= hi
        assert lo >= 0
        assert hi <= p

    def test_pruning_gives_fewer_factors(self, rng):
        """With over-specified p and ARD, posterior should concentrate below p."""
        m, n, p_true = 20, 30, 2
        F_true = rng.exponential(1.0, size=(m, p_true))
        G_true = rng.exponential(1.0, size=(p_true, n))
        X_true = F_true @ G_true
        sigma = 0.02 * np.ones((m, n)) + 0.05 * X_true
        X = np.maximum(X_true + rng.normal(0, sigma), 0.0)

        p_over = 6
        result = pmf_bayes(
            X, sigma, p_over,
            n_samples=300, n_burnin=300,
            ard=True, hyperparam_shape=0.5,
            random_seed=42,
        )
        from pmf_acls.bayes_diagnostics import factor_count_posterior
        fc = factor_count_posterior(result.factor_activity_samples)
        # Most probability should be at or below p_true + 1
        assert fc["pmf"][:p_true + 2].sum() > 0.5
        # P(active > p_true + 2) should be low
        assert fc["prob_gt"][p_true + 2] < 0.5

    def test_none_raises(self):
        """Passing None raises ValueError."""
        from pmf_acls.bayes_diagnostics import factor_count_posterior
        with pytest.raises(ValueError, match="factor_activity_samples"):
            factor_count_posterior(None)

    def test_custom_threshold(self, synthetic_data):
        """Different threshold changes the counts."""
        X, sigma, p = synthetic_data
        result = pmf_bayes(
            X, sigma, p,
            n_samples=100, n_burnin=50,
            ard=True, random_seed=42,
        )
        from pmf_acls.bayes_diagnostics import factor_count_posterior
        fc_low = factor_count_posterior(result.factor_activity_samples, threshold=0.001)
        fc_high = factor_count_posterior(result.factor_activity_samples, threshold=0.1)
        # Higher threshold → fewer active factors on average
        assert fc_high["mean"] <= fc_low["mean"]

    def test_threshold_sensitivity(self, synthetic_data):
        """threshold_sensitivity key has expected structure."""
        X, sigma, p = synthetic_data
        result = pmf_bayes(
            X, sigma, p,
            n_samples=100, n_burnin=50,
            ard=True, random_seed=42,
        )
        from pmf_acls.bayes_diagnostics import factor_count_posterior
        fc = factor_count_posterior(result.factor_activity_samples)
        assert "threshold_sensitivity" in fc
        ts = fc["threshold_sensitivity"]
        assert len(ts) == 5
        # All thresholds present
        for t in [0.001, 0.005, 0.01, 0.02, 0.05]:
            assert t in ts
            assert isinstance(ts[t], int)
            assert 0 <= ts[t] <= p
        # Monotonically non-increasing: higher threshold → fewer or equal active
        vals = [ts[t] for t in sorted(ts.keys())]
        for i in range(len(vals) - 1):
            assert vals[i] >= vals[i + 1]


# ============================================================================
# Label-switching diagnostic
# ============================================================================


class TestLabelSwitchGap:
    def test_gap_exists_and_finite(self, synthetic_data):
        """label_switch_gap is populated and finite."""
        X, sigma, p = synthetic_data
        result = pmf_bayes(
            X, sigma, p,
            n_samples=50, n_burnin=50,
            random_seed=42,
        )
        assert result.label_switch_gap is not None
        assert np.isfinite(result.label_switch_gap)
        assert 0.0 <= result.label_switch_gap <= 1.0

    def test_well_separated_factors_high_gap(self, rng):
        """Well-separated factors should have a high gap."""
        m, n, p = 20, 40, 3
        F_true = np.zeros((m, p))
        # Each factor loads on distinct variables
        F_true[:7, 0] = rng.exponential(2.0, size=7)
        F_true[7:14, 1] = rng.exponential(2.0, size=7)
        F_true[14:, 2] = rng.exponential(2.0, size=6)
        G_true = rng.exponential(5.0, size=(p, n))
        X = np.maximum(F_true @ G_true + rng.normal(0, 0.1, (m, n)), 0.0)
        sigma = 0.1 * np.ones((m, n))

        result = pmf_bayes(
            X, sigma, p,
            n_samples=50, n_burnin=50,
            random_seed=42,
        )
        assert result.label_switch_gap > 0.05


# ============================================================================
# Convergence diagnostics
# ============================================================================


class TestConvergenceDetails:
    def test_convergence_details_populated(self, synthetic_data):
        """convergence_details has expected keys."""
        X, sigma, p = synthetic_data
        result = pmf_bayes(
            X, sigma, p,
            n_samples=100, n_burnin=50,
            random_seed=42,
        )
        assert result.convergence_details is not None
        cd = result.convergence_details
        assert "geweke_z" in cd
        assert "geweke_z_abs" in cd
        assert "Q_ess" in cd
        assert "factor_ess" in cd
        assert "min_factor_ess" in cd
        assert "geweke_ok" in cd
        assert "ess_ok" in cd
        assert "labels_ok" in cd
        assert np.isfinite(cd["geweke_z"])
        assert cd["geweke_z_abs"] == abs(cd["geweke_z"])
        assert cd["Q_ess"] > 0
        assert len(cd["factor_ess"]) == p
        for ess in cd["factor_ess"]:
            assert ess > 0
        assert cd["min_factor_ess"] == min(cd["factor_ess"])
        assert isinstance(cd["geweke_ok"], bool)
        assert isinstance(cd["ess_ok"], bool)
        assert isinstance(cd["labels_ok"], bool)

    def test_converged_incorporates_all_checks(self, synthetic_data):
        """converged flag reflects Geweke + ESS + label gap."""
        X, sigma, p = synthetic_data
        result = pmf_bayes(
            X, sigma, p,
            n_samples=100, n_burnin=100,
            random_seed=42,
        )
        cd = result.convergence_details
        expected = (
            cd["geweke_ok"]
            and cd["ess_ok"]
            and cd["labels_ok"]
        )
        assert result.converged == expected
        # Signed Geweke z is stored (not abs)
        assert "geweke_z" in cd
        # geweke_z_abs is the absolute value used for threshold
        assert cd["geweke_z_abs"] == abs(cd["geweke_z"])


# ============================================================================
# tau_scale disabled with hierarchical sigma
# ============================================================================


class TestTauScaleHierSigma:
    def test_tau_scale_fixed_with_hier_sigma(self, synthetic_data):
        """With hierarchical sigma, tau_scale should remain 1.0 (not sampled)."""
        X, sigma, p = synthetic_data
        from pmf_acls import SIGMA_CATEGORY_PRESETS
        cats = np.zeros(X.shape[0], dtype=int)  # all "measured"
        params = {0: SIGMA_CATEGORY_PRESETS["measured"]}

        result = pmf_bayes(
            X, sigma, p,
            n_samples=50, n_burnin=50,
            sigma_prior="per_variable",
            sigma_categories=cats,
            sigma_prior_params=params,
            random_seed=42,
        )
        # hierarchical sigma should be populated
        assert result.sigma_posterior_mean is not None
        # Q should be finite (model ran successfully)
        assert np.isfinite(result.Q)


# ============================================================================
# WAIC ESS diagnostic
# ============================================================================


class TestWAICEssDiagnostic:
    def test_min_ess_in_waic(self, synthetic_data):
        """WAIC result includes min_ess key."""
        X, sigma, p = synthetic_data
        result = pmf_bayes(
            X, sigma, p,
            n_samples=50, n_burnin=50,
            store_samples=True,
            random_seed=42,
        )
        waic = compute_waic(X, sigma, result.F_samples, result.G_samples)
        assert "min_ess" in waic
        assert waic["min_ess"] > 0
