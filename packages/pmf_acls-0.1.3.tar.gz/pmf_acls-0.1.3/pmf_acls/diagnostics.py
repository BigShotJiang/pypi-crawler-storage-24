"""
Diagnostic utilities for PMF model selection and evaluation.

This module provides tools for:
- Factor selection (determining optimal number of factors p)
- Residual analysis
- Goodness-of-fit diagnostics
- Model comparison

Based on Lu & Wu (2005) and best practices in PMF analysis.
"""

from typing import List, Tuple, Optional, Dict
import warnings
import numpy as np

from .core import pmf
from .data_structures import PMFResult, FactorSelectionResult


def select_factors(
    X: np.ndarray,
    sigma: np.ndarray,
    p_range: Tuple[int, int],
    n_runs: int = 5,
    random_seed: Optional[int] = None,
    mode: str = "full",
    **pmf_kwargs,
) -> FactorSelectionResult:
    """
    Determine optimal number of factors via systematic exploration.

    This function runs PMF for a range of p values (number of factors),
    with multiple random initializations per p, and recommends the
    optimal p based on Q_robust and other diagnostics.

    Parameters
    ----------
    X : ndarray, shape (m, n)
        Data matrix to factorize.
    sigma : ndarray, shape (m, n)
        Uncertainties for each element of X.
    p_range : tuple of int
        (p_min, p_max) - range of factor numbers to test (inclusive).
    n_runs : int, default=5
        Number of random initializations to try for each p.
    random_seed : int, optional
        Seed for reproducibility. If provided, seeds will be
        deterministic across runs.
    mode : str, default='full'
        PMF algorithm mode to use.
    **pmf_kwargs : dict
        Additional parameters passed to pmf().

    Returns
    -------
    result : FactorSelectionResult
        Object containing:
        - p_values: list of tested p values
        - Q_values: dict mapping p -> list of Q values
        - Q_robust: dict mapping p -> Q_robust metric
        - best_p: recommended number of factors
        - best_results: dict mapping p -> best PMFResult

    Notes
    -----
    The Q_robust metric is defined as:
        Q_robust = Q / E[Q]
    where E[Q] ≈ (m×n - (m+n)×p) is the expected Q for a well-fitting model.

    A Q_robust value close to 1.0 indicates a good fit. Values significantly
    above 1.0 suggest underfitting (too few factors), while values below 1.0
    may suggest overfitting (too many factors) or an exceptionally good fit.

    The "best" p is chosen as the smallest p where Q_robust is closest to 1.0,
    representing a balance between model complexity and fit quality.

    References
    ----------
    Lu, J., & Wu, L. (2005). Technical details and programming guide for a
    general two-way positive matrix factorization algorithm.
    Journal of Chemometrics, 18(12), 519-525.

    Examples
    --------
    >>> import numpy as np
    >>> from pmf_acls import select_factors
    >>>
    >>> # Generate synthetic data with 3 true factors
    >>> m, n, p_true = 10, 20, 3
    >>> F_true = np.random.rand(m, p_true)
    >>> G_true = np.random.rand(p_true, n)
    >>> X = F_true @ G_true + 0.1 * np.random.randn(m, n)
    >>> sigma = 0.1 * np.ones_like(X)
    >>>
    >>> # Test p from 1 to 5
    >>> result = select_factors(X, sigma, p_range=(1, 5), n_runs=5)
    >>> print(f"Recommended p: {result.best_p}")
    >>> result.summary()
    """
    m, n = X.shape
    p_min, p_max = p_range

    # Validate inputs
    if p_min < 1:
        raise ValueError("p_min must be at least 1")
    if p_max > min(m, n):
        raise ValueError(f"p_max must be at most min(m, n) = {min(m, n)}")
    if p_max < p_min:
        raise ValueError("p_max must be >= p_min")
    if n_runs < 1:
        raise ValueError("n_runs must be at least 1")

    p_values = list(range(p_min, p_max + 1))
    Q_values = {}
    best_results = {}

    # Set up random seeds for reproducibility
    if random_seed is not None:
        rng = np.random.RandomState(random_seed)
        seeds = [rng.randint(0, 2**31 - 1) for _ in range(len(p_values) * n_runs)]
    else:
        seeds = [None] * (len(p_values) * n_runs)

    print(f"Testing p from {p_min} to {p_max} with {n_runs} runs each...")
    print("=" * 60)

    seed_idx = 0
    for p in p_values:
        print(f"\nTesting p = {p}...")
        Q_list = []
        results_list = []

        for run in range(n_runs):
            # Get seed for this run
            seed = seeds[seed_idx]
            seed_idx += 1

            # Run PMF with current seed
            try:
                result = pmf(
                    X, sigma, p=p,
                    mode=mode,
                    random_seed=seed,
                    verbose=False,  # Suppress per-run output
                    **pmf_kwargs
                )

                Q_list.append(result.Q)
                results_list.append(result)

            except Exception as e:
                warnings.warn(
                    f"PMF failed for p={p}, run {run+1}/{n_runs}: {e}. Skipping."
                )
                continue

        if len(Q_list) == 0:
            raise RuntimeError(
                f"All runs failed for p={p}. Cannot proceed with factor selection."
            )

        # Store Q values and best result for this p
        Q_values[p] = Q_list
        best_idx = np.argmin(Q_list)
        best_results[p] = results_list[best_idx]

        # Report statistics for this p
        q_mean = np.mean(Q_list)
        q_std = np.std(Q_list)
        q_min = np.min(Q_list)
        print(f"  Q: {q_mean:.4e} ± {q_std:.4e} (min: {q_min:.4e}, n={len(Q_list)})")

    print("\n" + "=" * 60)

    # Calculate Q_robust for each p
    Q_robust = {}
    for p in p_values:
        # Best Q for this p
        Q_best = np.min(Q_values[p])

        # Expected Q for a well-fitting model
        # E[Q] ≈ degrees of freedom = m*n - (m+n)*p
        dof = m * n - (m + n) * p
        if dof <= 0:
            # Saturated or overparameterized model
            Q_robust[p] = np.inf
        else:
            Q_robust[p] = Q_best / dof

    # Select best p: smallest p where Q_robust is closest to 1.0
    # This balances fit quality with model simplicity
    best_p = _select_best_p(p_values, Q_robust)

    print(f"\nRecommended number of factors: p = {best_p}")
    print(f"Q_robust at recommended p: {Q_robust[best_p]:.4f}")

    return FactorSelectionResult(
        p_values=p_values,
        Q_values=Q_values,
        Q_robust=Q_robust,
        best_p=best_p,
        best_results=best_results,
    )


def _select_best_p(p_values: List[int], Q_robust: Dict[int, float]) -> int:
    """
    Select best p from Q_robust values.

    Strategy: Choose smallest p where Q_robust is closest to 1.0.
    This represents parsimony principle (Occam's razor).

    Parameters
    ----------
    p_values : list of int
        Tested p values
    Q_robust : dict
        p -> Q_robust metric

    Returns
    -------
    best_p : int
        Recommended p value
    """
    # Calculate distance from 1.0 for each p
    distances = {p: abs(Q_robust[p] - 1.0) for p in p_values}

    # Find minimum distance
    min_distance = min(distances.values())

    # Among p values with similar distances (within 10% of min),
    # choose the smallest p (parsimony)
    tolerance = 0.1 * (1.0 + min_distance)  # 10% tolerance
    candidates = [
        p for p in p_values
        if distances[p] <= min_distance + tolerance
    ]

    return min(candidates)


def compute_scaled_residuals(
    X: np.ndarray,
    F: np.ndarray,
    G: np.ndarray,
    sigma: np.ndarray,
) -> np.ndarray:
    """
    Compute scaled residuals: (X - GF) / σ.

    Scaled residuals should follow a standard normal distribution
    if the model is appropriate and uncertainties are well-calibrated.

    Parameters
    ----------
    X : ndarray, shape (m, n)
        Data matrix
    F : ndarray, shape (m, p)
        Factor profiles
    G : ndarray, shape (p, n)
        Factor contributions
    sigma : ndarray, shape (m, n)
        Uncertainties

    Returns
    -------
    scaled_residuals : ndarray, shape (m, n)
        Scaled residuals (X - GF) / σ
    """
    residuals = X - F @ G
    scaled_residuals = residuals / sigma
    return scaled_residuals


def residual_statistics(
    result: PMFResult,
    sigma: np.ndarray,
    per_variable: bool = True,
) -> Dict:
    """
    Compute residual statistics for PMF result.

    Parameters
    ----------
    result : PMFResult
        PMF result object
    sigma : ndarray, shape (m, n)
        Uncertainties used in PMF
    per_variable : bool, default=True
        If True, compute statistics per variable (row).
        If False, compute statistics per observation (column).

    Returns
    -------
    stats : dict
        Dictionary with keys:
        - 'mean': mean of scaled residuals
        - 'std': standard deviation of scaled residuals
        - 'min': minimum scaled residual
        - 'max': maximum scaled residual
        - 'percentile_5': 5th percentile
        - 'percentile_95': 95th percentile
    """
    scaled_res = compute_scaled_residuals(
        result.F @ result.G + result.residuals,  # Reconstruct X
        result.F,
        result.G,
        sigma
    )

    # Compute along appropriate axis
    axis = 1 if per_variable else 0

    stats = {
        'mean': np.mean(scaled_res, axis=axis),
        'std': np.std(scaled_res, axis=axis),
        'min': np.min(scaled_res, axis=axis),
        'max': np.max(scaled_res, axis=axis),
        'percentile_5': np.percentile(scaled_res, 5, axis=axis),
        'percentile_95': np.percentile(scaled_res, 95, axis=axis),
    }

    return stats


def compute_contributions(
    F: np.ndarray,
    G: np.ndarray,
) -> np.ndarray:
    """
    Compute factor contributions to reconstructed data.

    For each factor k, computes F[:, k:k+1] @ G[k:k+1, :]
    which gives the contribution of factor k to the total X.

    Parameters
    ----------
    F : ndarray, shape (m, p)
        Factor profiles
    G : ndarray, shape (p, n)
        Factor contributions

    Returns
    -------
    contributions : ndarray, shape (p, m, n)
        contributions[k, :, :] is the contribution of factor k
    """
    m, p = F.shape
    _, n = G.shape

    contributions = np.zeros((p, m, n))

    for k in range(p):
        # Contribution of factor k
        contributions[k, :, :] = np.outer(F[:, k], G[k, :])

    return contributions


def explained_variance_per_variable(
    X: np.ndarray,
    result: PMFResult,
) -> np.ndarray:
    """
    Compute explained variance (R²) for each variable.

    Parameters
    ----------
    X : ndarray, shape (m, n)
        Original data matrix
    result : PMFResult
        PMF result

    Returns
    -------
    r2_per_variable : ndarray, shape (m,)
        Explained variance for each variable (row)
    """
    m, n = X.shape
    X_reconstructed = result.F @ result.G

    r2 = np.zeros(m)
    for i in range(m):
        # Total sum of squares
        ss_tot = np.sum((X[i, :] - np.mean(X[i, :]))**2)

        # Residual sum of squares
        ss_res = np.sum((X[i, :] - X_reconstructed[i, :])**2)

        # R² = 1 - SS_res / SS_tot
        if ss_tot > 0:
            r2[i] = 1.0 - ss_res / ss_tot
        else:
            r2[i] = 0.0

    return r2


def print_diagnostics(result: PMFResult, sigma: np.ndarray) -> None:
    """
    Print comprehensive diagnostics for a PMF result.

    Parameters
    ----------
    result : PMFResult
        PMF result to diagnose
    sigma : ndarray, shape (m, n)
        Uncertainties used in PMF
    """
    m, p = result.F.shape
    _, n = result.G.shape

    print("=" * 70)
    print("PMF DIAGNOSTICS")
    print("=" * 70)

    # Basic info
    print(f"\nProblem Size: {m} variables × {n} observations × {p} factors")
    print(f"Convergence: {'Yes' if result.converged else 'No'} ({result.n_iter} iterations)")

    # Objective function
    print(f"\nObjective Function:")
    print(f"  Final Q: {result.Q:.4e}")
    if len(result.Q_history) > 1:
        improvement = (result.Q_history[0] - result.Q) / result.Q_history[0] * 100
        print(f"  Initial Q: {result.Q_history[0]:.4e}")
        print(f"  Improvement: {improvement:.2f}%")

    # Goodness of fit
    print(f"\nGoodness of Fit:")
    print(f"  Explained variance: {result.explained_variance:.2%}")
    print(f"  χ² statistic: {result.chi2:.4f}")

    dof = m * n - (m + n) * p
    if dof > 0:
        q_robust = result.Q / dof
        print(f"  Q_robust: {q_robust:.4f}")
        if q_robust < 0.8:
            print("    → Possibly overfitting (Q_robust < 0.8)")
        elif q_robust > 1.2:
            print("    → Possibly underfitting (Q_robust > 1.2)")
        else:
            print("    → Good fit (Q_robust ≈ 1.0)")

    # Scaled residuals
    X = result.F @ result.G + result.residuals
    scaled_res = compute_scaled_residuals(X, result.F, result.G, sigma)

    print(f"\nScaled Residuals (should be ~ N(0,1)):")
    print(f"  Mean: {np.mean(scaled_res):.4f}")
    print(f"  Std: {np.std(scaled_res):.4f}")
    print(f"  Min: {np.min(scaled_res):.4f}")
    print(f"  Max: {np.max(scaled_res):.4f}")

    # Check for systematic patterns
    per_var_mean = np.mean(scaled_res, axis=1)
    if np.max(np.abs(per_var_mean)) > 2.0:
        print(f"  ⚠ Warning: Some variables have large mean residuals (max: {np.max(np.abs(per_var_mean)):.2f})")

    print("=" * 70)
