"""
Core PMF algorithm implementation.

This module implements the main Positive Matrix Factorization algorithm
as described in Lu & Wu (2005), Section 3.

The algorithm iteratively minimizes the weighted squared residuals
subject to non-negativity constraints on F and G.
"""

from typing import Optional, Union, Tuple, List
import numpy as np
import warnings

from .data_structures import PMFResult
from .validation import (
    validate_data_matrix,
    validate_uncertainty_matrix,
    validate_rank,
    validate_initial_matrix,
    validate_mode,
    validate_solver,
    validate_positive_scalar,
    validate_integer_range,
    validate_strength_coefficient,
    validate_boolean,
    check_data_quality,
)
from .matrix_builder import (
    build_system_matrices,
    build_residual_vector,
    build_theta_vector,
    build_theta_star_vector,
    extract_updates_from_phi,
    compute_scaling_coefficients,
    quadratic_log_approximation,
    compute_objective_function,
)
from .solvers import solve_pmf_system


def acls_update_H(
    W: np.ndarray,
    A: np.ndarray,
    sigma: np.ndarray,
    lambda_H: float = 0.0,
    fpeak: float = 0.0,
) -> np.ndarray:
    """
    ACLS update for H (coefficient matrix) with uncertainty weighting.

    For each column j, solves the weighted least squares problem:
        min_h  Σ_i (w_ij * (A_ij - W_i @ h))^2 + λ_H ||h||^2
    where w_ij = 1/σ_ij^2

    This is equivalent to solving:
        (W^T Ω_j W + λ_H I) h_j = W^T Ω_j A_j - (fpeak/2) * col_sums(W)
    where Ω_j = diag(w_1j^2, w_2j^2, ..., w_mj^2)

    Parameters
    ----------
    W : ndarray, shape (m, k)
        Current W matrix (basis vectors), corresponds to F in PMF notation
    A : ndarray, shape (m, n)
        Data matrix
    sigma : ndarray, shape (m, n)
        Uncertainty matrix
    lambda_H : float, default=0.0
        Tikhonov regularization parameter for H
    fpeak : float, default=0.0
        FPEAK rotation parameter.  Positive values bias toward peaked
        (sparse) profiles; negative toward diffuse profiles.

    Returns
    -------
    H : ndarray, shape (k, n)
        Updated H matrix with non-negativity enforced

    Notes
    -----
    This implements weighted alternating least squares, which properly accounts
    for measurement uncertainties during optimization (not just in the final Q).
    """
    m, k = W.shape
    _, n = A.shape
    H = np.zeros((k, n))

    # FPEAK penalty gradient: precompute once outside column loop
    fpeak_penalty = (fpeak / 2.0) * np.sum(W, axis=0) if fpeak != 0.0 else None

    # Solve for each column independently
    for j in range(n):
        # Weights for this column
        weights_j = 1.0 / sigma[:, j]**2  # m-dimensional

        # Weighted system: (W^T Ω W + λ I) h = W^T Ω A
        Omega_j = np.diag(weights_j)
        lhs = W.T @ Omega_j @ W  # k × k
        rhs = W.T @ Omega_j @ A[:, j]  # k-dimensional

        # Add regularization
        if lambda_H > 0:
            lhs += lambda_H * np.eye(k)

        # Add FPEAK penalty to RHS
        if fpeak_penalty is not None:
            rhs = rhs - fpeak_penalty

        # Solve and enforce non-negativity
        try:
            h_j = np.linalg.solve(lhs, rhs)
        except np.linalg.LinAlgError:
            # Fallback to lstsq if singular
            h_j, _, _, _ = np.linalg.lstsq(lhs, rhs, rcond=None)

        H[:, j] = np.maximum(h_j, 0)

    return H


def acls_update_W(
    H: np.ndarray,
    A: np.ndarray,
    sigma: np.ndarray,
    lambda_W: float = 0.0,
    fpeak: float = 0.0,
) -> np.ndarray:
    """
    ACLS update for W (basis matrix) with uncertainty weighting.

    For each row i, solves the weighted least squares problem:
        min_w  Σ_j (w_ij * (A_ij - w @ H_j))^2 + λ_W ||w||^2
    where w_ij = 1/σ_ij^2

    This is equivalent to solving:
        (H Ω_i H^T + λ_W I) w_i = H Ω_i A_i^T - (fpeak/2) * row_sums(H)
    where Ω_i = diag(w_i1^2, w_i2^2, ..., w_in^2)

    Parameters
    ----------
    H : ndarray, shape (k, n)
        Current H matrix (coefficients), corresponds to G in PMF notation
    A : ndarray, shape (m, n)
        Data matrix
    sigma : ndarray, shape (m, n)
        Uncertainty matrix
    lambda_W : float, default=0.0
        Tikhonov regularization parameter for W
    fpeak : float, default=0.0
        FPEAK rotation parameter.  Positive values bias toward peaked
        (sparse) profiles; negative toward diffuse profiles.

    Returns
    -------
    W : ndarray, shape (m, k)
        Updated W matrix with non-negativity enforced

    Notes
    -----
    This implements weighted alternating least squares, which properly accounts
    for measurement uncertainties during optimization (not just in the final Q).
    """
    k, n = H.shape
    m = A.shape[0]
    W = np.zeros((m, k))

    # FPEAK penalty gradient: precompute once outside row loop
    fpeak_penalty = (fpeak / 2.0) * np.sum(H, axis=1) if fpeak != 0.0 else None

    # Solve for each row independently
    for i in range(m):
        # Weights for this row
        weights_i = 1.0 / sigma[i, :]**2  # n-dimensional

        # Weighted system: (H Ω H^T + λ I) w = H Ω A^T
        Omega_i = np.diag(weights_i)
        lhs = H @ Omega_i @ H.T  # k × k
        rhs = H @ Omega_i @ A[i, :]  # k-dimensional

        # Add regularization
        if lambda_W > 0:
            lhs += lambda_W * np.eye(k)

        # Add FPEAK penalty to RHS
        if fpeak_penalty is not None:
            rhs = rhs - fpeak_penalty

        # Solve and enforce non-negativity
        try:
            w_i = np.linalg.solve(lhs, rhs)
        except np.linalg.LinAlgError:
            # Fallback to lstsq if singular
            w_i, _, _, _ = np.linalg.lstsq(lhs, rhs, rcond=None)

        W[i, :] = np.maximum(w_i, 0)

    return W


def normalize_factors(
    W: np.ndarray,
    H: np.ndarray,
    min_value: float = 1e-12,
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Normalize W columns to unit L2 norm, transferring scale to H rows.

    This prevents scaling degeneracy where one factor's W column shrinks
    toward zero while the corresponding H row grows unboundedly (or vice
    versa). The product W @ H is preserved.

    Parameters
    ----------
    W : ndarray, shape (m, k)
        Basis matrix (F in PMF notation)
    H : ndarray, shape (k, n)
        Coefficient matrix (G in PMF notation)
    min_value : float, default=1e-12
        Minimum norm to avoid division by zero

    Returns
    -------
    W_norm : ndarray, shape (m, k)
        Normalized W (each column has unit L2 norm)
    H_scaled : ndarray, shape (k, n)
        Scaled H (absorbs the column norms from W)
    """
    norms = np.linalg.norm(W, axis=0)  # k-dimensional
    norms = np.maximum(norms, min_value)
    W_norm = W / norms[np.newaxis, :]
    H_scaled = H * norms[:, np.newaxis]
    return W_norm, H_scaled


def compute_factor_std(
    F: np.ndarray,
    G: np.ndarray,
    sigma: np.ndarray,
    lambda_W: float = 0.0,
    lambda_H: float = 0.0,
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Analytical standard deviations for F and G from WLS covariance.

    At the converged solution, each column j of G was obtained by solving
    the weighted normal equations (F^T Ω_j F + λI) f_j = F^T Ω_j X_j
    where Ω_j = diag(1/σ²_{1j}, ..., 1/σ²_{mj}).  The covariance of f_j
    is inv(F^T Ω_j F + λI), and similarly for each row of F.

    Elements pinned to zero by the non-negativity constraint get std = 0.

    Parameters
    ----------
    F : ndarray, shape (m, p)
        Converged factor contribution matrix.
    G : ndarray, shape (p, n)
        Converged factor profile matrix.
    sigma : ndarray, shape (m, n)
        Uncertainty matrix.
    lambda_W : float, default=0.0
        Tikhonov regularization used for F.
    lambda_H : float, default=0.0
        Tikhonov regularization used for G.

    Returns
    -------
    F_std : ndarray, shape (m, p)
        Analytical standard deviations of F.
    G_std : ndarray, shape (p, n)
        Analytical standard deviations of G.
    """
    m, p = F.shape
    _, n = G.shape

    # G_std: for each column j, invert the p×p normal equation matrix
    G_std = np.zeros((p, n))
    for j in range(n):
        w_j = 1.0 / sigma[:, j] ** 2
        lhs = (F.T * w_j) @ F  # p×p, avoids building m×m diagonal
        if lambda_H > 0:
            lhs += lambda_H * np.eye(p)
        try:
            cov_j = np.linalg.inv(lhs)
            se = np.sqrt(np.maximum(np.diag(cov_j), 0.0))
        except np.linalg.LinAlgError:
            se = np.full(p, np.nan)
        se[G[:, j] == 0] = 0.0  # pinned by non-negativity
        G_std[:, j] = se

    # F_std: for each row i, invert the p×p normal equation matrix
    F_std = np.zeros((m, p))
    for i in range(m):
        w_i = 1.0 / sigma[i, :] ** 2
        lhs = (G * w_i) @ G.T  # p×p
        if lambda_W > 0:
            lhs += lambda_W * np.eye(p)
        try:
            cov_i = np.linalg.inv(lhs)
            se = np.sqrt(np.maximum(np.diag(cov_i), 0.0))
        except np.linalg.LinAlgError:
            se = np.full(p, np.nan)
        se[F[i, :] == 0] = 0.0
        F_std[i, :] = se

    return F_std, G_std


def acls_iteration(
    W: np.ndarray,
    H: np.ndarray,
    A: np.ndarray,
    sigma: np.ndarray,
    lambda_W: float = 0.0,
    lambda_H: float = 0.0,
    fpeak: float = 0.0,
) -> Tuple[np.ndarray, np.ndarray, float]:
    """
    Perform one weighted ACLS iteration.

    Updates H then W using weighted alternating constrained least squares,
    with optional Tikhonov regularization and FPEAK rotation penalty.

    Parameters
    ----------
    W : ndarray, shape (m, k)
        Current W matrix (basis vectors), corresponds to F in PMF notation
    H : ndarray, shape (k, n)
        Current H matrix (coefficients), corresponds to G in PMF notation
    A : ndarray, shape (m, n)
        Data matrix
    sigma : ndarray, shape (m, n)
        Uncertainty matrix
    lambda_W : float, default=0.0
        Tikhonov regularization parameter for W
    lambda_H : float, default=0.0
        Tikhonov regularization parameter for H
    fpeak : float, default=0.0
        FPEAK rotation parameter.  Positive biases toward peaked profiles.

    Returns
    -------
    W_new : ndarray, shape (m, k)
        Updated W matrix
    H_new : ndarray, shape (k, n)
        Updated H matrix
    Q : float
        Objective function value (weighted sum of squared residuals, without
        FPEAK penalty — Q_main only, matching PMF2 convention)
    """
    # Update H first, then W (as in Algorithm 2)
    H_new = acls_update_H(W, A, sigma, lambda_H, fpeak)
    W_new = acls_update_W(H_new, A, sigma, lambda_W, fpeak)

    # Compute objective function (weighted Frobenius norm) — Q_main only
    R = A - W_new @ H_new
    Q = np.sum((R / sigma) ** 2)

    return W_new, H_new, Q


def pmf_acls(
    X: np.ndarray,
    sigma: np.ndarray,
    p: int,
    F_init: Optional[np.ndarray] = None,
    G_init: Optional[np.ndarray] = None,
    max_iter: int = 1000,
    conv_tol: float = 0.005,
    verbose: Union[bool, int] = False,
    init_method: str = "random",
    lambda_W: float = 0.0,
    lambda_H: float = 0.0,
    fpeak: float = 0.0,
    min_value: float = 1e-12,
    random_seed: Optional[int] = None,
) -> "PMFResult":
    """
    Perform PMF using weighted ACLS (Alternating Constrained Least Squares).

    Implements a weighted version of Algorithm 2 from Langville et al. (2014)
    that properly incorporates measurement uncertainties during optimization.
    This is a simpler and more robust alternative to the Newton-based method,
    solving smaller k×k systems instead of large (mp+np)×(mp+np) systems.

    Parameters
    ----------
    X : ndarray, shape (m, n)
        Data matrix to factorize
    sigma : ndarray, shape (m, n)
        Standard deviations (uncertainties) for each element
    p : int
        Number of factors (rank)
    F_init, G_init : ndarray, optional
        Initial factor matrices
    max_iter : int, default=1000
        Maximum iterations
    conv_tol : float, default=0.005
        Convergence tolerance (relative change in Q)
    verbose : bool or int, default=False
        Verbosity level
    init_method : {'random', 'random_acol', 'svd_centroid'}, default='random'
        Initialization method
    lambda_W : float, default=0.0
        Tikhonov regularization for W (F) matrix
    lambda_H : float, default=0.0
        Tikhonov regularization for H (G) matrix
    min_value : float, default=1e-12
        Floor value for numerical stability
    random_seed : int, optional
        Random seed for reproducibility

    Returns
    -------
    result : PMFResult
        Results object containing F, G, diagnostics, and convergence info

    References
    ----------
    Langville, A. N., Meyer, C. D., Albright, R., Cox, J., & Duling, D. (2014).
    Algorithms, Initializations, and Convergence for the Nonnegative Matrix
    Factorization. arXiv:1407.7299.
    """
    # Input validation
    validate_data_matrix(X, "X")
    m, n = X.shape
    validate_uncertainty_matrix(sigma, X.shape)
    validate_rank(p, m, n)

    if verbose:
        print("=" * 60)
        print("PMF Algorithm (ACLS)")
        print("=" * 60)
        print(f"Data: {m} variables × {n} observations")
        print(f"Factors: {p}")
        print(f"Regularization: lambda_W={lambda_W}, lambda_H={lambda_H}")
        print("=" * 60)

    # Initialize factors (F=W, G=H in NMF notation)
    F, G = initialize_factors(m, n, p, X, F_init, G_init, random_seed, init_method)

    # Ensure positive values
    F = np.maximum(F, min_value)
    G = np.maximum(G, min_value)

    # Calculate initial objective
    R = X - F @ G
    Q = np.sum((R / sigma) ** 2)
    Q_history = [Q]
    Q_old = Q

    if verbose:
        print(f"Initial Q: {Q:.4e}")
        print("=" * 60)

    converged = False
    rel_change = 1.0

    for iteration in range(1, max_iter + 1):
        # Perform ACLS iteration
        F_new, G_new, Q_new = acls_iteration(
            F, G, X, sigma, lambda_W, lambda_H, fpeak
        )

        # Ensure numerical stability
        F_new = np.maximum(F_new, min_value)
        G_new = np.maximum(G_new, min_value)

        # Normalize: unit L2 norm on F columns, transfer scale to G rows.
        # Prevents scaling degeneracy (one factor's F→0 while G→∞).
        F_new, G_new = normalize_factors(F_new, G_new, min_value)

        # Update matrices
        F = F_new
        G = G_new
        Q_history.append(Q_new)

        # Check convergence
        rel_change = abs(Q_new - Q_old) / max(Q_old, 1e-12)

        if verbose >= 2:
            direction = "v" if Q_new <= Q_old else "^"
            print(f"  Iter {iteration}: Q={Q_new:.4e}, change={rel_change:.4e} {direction}")
        elif verbose == 1 and iteration % 10 == 0:
            print(f"  Iter {iteration}: Q={Q_new:.4e}, change={rel_change:.4e}")

        if rel_change < conv_tol and Q_new <= Q_old:
            converged = True
            if verbose:
                print(f"\nConverged at iteration {iteration}")
            break

        Q_old = Q_new

    if not converged:
        warnings.warn(
            f"ACLS did not converge within {max_iter} iterations. "
            f"Final relative change: {rel_change:.4e}",
            UserWarning
        )

    # Calculate final diagnostics
    R_final = X - F @ G

    # Explained variance
    var_total = np.var(X)
    var_resid = np.var(R_final)
    explained_variance = 1.0 - (var_resid / var_total) if var_total > 0 else 0.0

    # Chi-square statistic
    degrees_of_freedom = m * n - (m + n) * p
    chi2 = Q_history[-1] / degrees_of_freedom if degrees_of_freedom > 0 else 0.0

    # Analytical standard deviations from WLS covariance
    F_std, G_std = compute_factor_std(F, G, sigma, lambda_W, lambda_H)

    # Create result object
    result = PMFResult(
        F=F,
        G=G,
        Q=Q_history[-1],
        Q_history=Q_history,
        n_iter=iteration if converged else max_iter,
        converged=converged,
        residuals=R_final,
        explained_variance=explained_variance,
        chi2=chi2,
        F_std=F_std,
        G_std=G_std,
    )

    if verbose:
        print("=" * 60)
        result.summary()

    return result


def ls_nmf_update(
    V: np.ndarray,
    We: np.ndarray,
    W: np.ndarray,
    H: np.ndarray,
    hold_h: bool = False,
) -> Tuple[np.ndarray, np.ndarray]:
    """
    LS-NMF multiplicative update step.

    Implements the weighted multiplicative update rules from:
    Wang, F. et al. (2006) "LS-NMF: A modified non-negative matrix
    factorization algorithm utilizing uncertainty estimates."
    BMC Bioinformatics 7:175. https://doi.org/10.1186/1471-2105-7-175

    This is the same algorithm used by ESAT (EPA's source apportionment tool).

    Parameters
    ----------
    V : ndarray, shape (m, n)
        Data matrix
    We : ndarray, shape (m, n)
        Weight matrix (1/sigma^2)
    W : ndarray, shape (m, k)
        Contribution matrix (F in PMF notation)
    H : ndarray, shape (k, n)
        Profile matrix (G in PMF notation)
    hold_h : bool, default=False
        If True, H is not updated (used during DISP)

    Returns
    -------
    W_new : ndarray, shape (m, k)
        Updated W matrix
    H_new : ndarray, shape (k, n)
        Updated H matrix
    """
    EPSILON = 1e-12
    WeV = np.multiply(We, V)

    if not hold_h:
        WH = np.matmul(W, H)
        H_num = np.matmul(W.T, WeV)
        H_den = np.matmul(W.T, np.multiply(We, WH))
        H_den = np.maximum(H_den, EPSILON)
        H = np.multiply(H, np.divide(H_num, H_den))

    WH = np.matmul(W, H)
    W_num = np.matmul(WeV, H.T)
    W_den = np.matmul(np.multiply(We, WH), H.T)
    W_den = np.maximum(W_den, EPSILON)
    W = np.multiply(W, np.divide(W_num, W_den))

    return W, H


def pmf_ls_nmf(
    X: np.ndarray,
    sigma: np.ndarray,
    p: int,
    F_init: Optional[np.ndarray] = None,
    G_init: Optional[np.ndarray] = None,
    max_iter: int = 1000,
    conv_tol: float = 0.005,
    verbose: Union[bool, int] = False,
    init_method: str = "random",
    min_value: float = 1e-12,
    random_seed: Optional[int] = None,
) -> "PMFResult":
    """
    Perform PMF using LS-NMF (Least-Squares Non-negative Matrix Factorization).

    Implements weighted multiplicative update rules that match ESAT's LS-NMF
    algorithm. This allows direct comparison of error estimation results
    between pmf_acls and ESAT when using the same solver.

    Parameters
    ----------
    X : ndarray, shape (m, n)
        Data matrix to factorize
    sigma : ndarray, shape (m, n)
        Standard deviations (uncertainties) for each element
    p : int
        Number of factors (rank)
    F_init, G_init : ndarray, optional
        Initial factor matrices
    max_iter : int, default=1000
        Maximum iterations
    conv_tol : float, default=0.005
        Convergence tolerance (relative change in Q)
    verbose : bool or int, default=False
        Verbosity level
    init_method : {'random', 'random_acol', 'svd_centroid'}, default='random'
        Initialization method
    min_value : float, default=1e-12
        Floor value for numerical stability
    random_seed : int, optional
        Random seed for reproducibility

    Returns
    -------
    result : PMFResult
        Results object containing F, G, diagnostics, and convergence info

    References
    ----------
    Wang, F., Kossenkov, A. V., & Bhagwat, A. A. (2006). LS-NMF: A modified
    non-negative matrix factorization algorithm utilizing uncertainty estimates.
    BMC Bioinformatics, 7, 175.
    """
    validate_data_matrix(X, "X")
    m, n = X.shape
    validate_uncertainty_matrix(sigma, X.shape)
    validate_rank(p, m, n)

    if verbose:
        print("=" * 60)
        print("PMF Algorithm (LS-NMF)")
        print("=" * 60)
        print(f"Data: {m} samples × {n} features")
        print(f"Factors: {p}")
        print("=" * 60)

    # Initialize factors
    F, G = initialize_factors(m, n, p, X, F_init, G_init, random_seed, init_method)
    F = np.maximum(F, min_value)
    G = np.maximum(G, min_value)

    # Weight matrix: 1/sigma^2
    We = 1.0 / (sigma ** 2)

    # Initial Q
    R = X - F @ G
    Q = np.sum((R / sigma) ** 2)
    Q_history = [Q]
    Q_old = Q

    if verbose:
        print(f"Initial Q: {Q:.4e}")
        print("=" * 60)

    converged = False
    rel_change = 1.0

    for iteration in range(1, max_iter + 1):
        F, G = ls_nmf_update(X, We, F, G)

        # Floor small values
        F = np.maximum(F, min_value)
        G = np.maximum(G, min_value)

        # Compute Q
        R = X - F @ G
        Q_new = np.sum((R / sigma) ** 2)
        Q_history.append(Q_new)

        rel_change = abs(Q_new - Q_old) / max(Q_old, 1e-12)

        if verbose >= 2:
            direction = "v" if Q_new <= Q_old else "^"
            print(f"  Iter {iteration}: Q={Q_new:.4e}, change={rel_change:.4e} {direction}")
        elif verbose == 1 and iteration % 10 == 0:
            print(f"  Iter {iteration}: Q={Q_new:.4e}, change={rel_change:.4e}")

        if rel_change < conv_tol and Q_new <= Q_old:
            converged = True
            if verbose:
                print(f"\nConverged at iteration {iteration}")
            break

        Q_old = Q_new

    if not converged:
        warnings.warn(
            f"LS-NMF did not converge within {max_iter} iterations. "
            f"Final relative change: {rel_change:.4e}",
            UserWarning
        )

    R_final = X - F @ G
    var_total = np.var(X)
    var_resid = np.var(R_final)
    explained_variance = 1.0 - (var_resid / var_total) if var_total > 0 else 0.0

    degrees_of_freedom = m * n - (m + n) * p
    chi2 = Q_history[-1] / degrees_of_freedom if degrees_of_freedom > 0 else 0.0

    result = PMFResult(
        F=F,
        G=G,
        Q=Q_history[-1],
        Q_history=Q_history,
        n_iter=iteration if converged else max_iter,
        converged=converged,
        residuals=R_final,
        explained_variance=explained_variance,
        chi2=chi2,
    )

    if verbose:
        print("=" * 60)
        result.summary()

    return result


def random_acol_init(
    X: np.ndarray,
    p: int,
    num_cols: int = 5,
    random_seed: Optional[int] = None,
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Random Acol initialization (Langville et al. 2014).

    Forms each basis vector by averaging a random subset of columns of X.
    This provides a data-aware initialization that captures the scale and
    structure of the data better than pure random initialization.

    Parameters
    ----------
    X : ndarray, shape (m, n)
        Data matrix (non-negative)
    p : int
        Number of factors
    num_cols : int, default=5
        Number of columns to average for each basis vector.
        Paper recommends ~5 for sparse data, more for dense.
    random_seed : int, optional
        Random seed for reproducibility

    Returns
    -------
    F : ndarray, shape (m, p)
        Initial F matrix (basis vectors)
    G : ndarray, shape (p, n)
        Initial G matrix (computed via NNLS)

    References
    ----------
    Langville, A. N., Meyer, C. D., Albright, R., Cox, J., & Duling, D. (2014).
    Algorithms, Initializations, and Convergence for the Nonnegative Matrix
    Factorization. arXiv:1407.7299.
    """
    if random_seed is not None:
        np.random.seed(random_seed)

    m, n = X.shape
    X_pos = np.maximum(X, 1e-12)  # Ensure non-negative

    # Build F by averaging random column subsets
    F = np.zeros((m, p))
    actual_num_cols = min(num_cols, n)

    for j in range(p):
        # Select random columns
        idx = np.random.choice(n, size=actual_num_cols, replace=False)
        # Average them to form basis vector
        F[:, j] = X_pos[:, idx].mean(axis=1)

    # Ensure F is positive
    F = np.maximum(F, 1e-12)

    # Initialize G via NNLS: solve X ≈ F @ G for G
    from scipy.optimize import nnls

    G = np.zeros((p, n))
    for j in range(n):
        result, _ = nnls(F, X_pos[:, j])
        G[:, j] = result

    G = np.maximum(G, 1e-12)

    return F, G


def svd_centroid_init(
    X: np.ndarray,
    p: int,
) -> Tuple[np.ndarray, np.ndarray]:
    """
    SVD-Centroid initialization (Langville et al. 2014).

    Uses truncated SVD followed by centroid decomposition to produce
    non-negative initial factors. This method tends to produce good
    starting points that capture the main structure of the data.

    Parameters
    ----------
    X : ndarray, shape (m, n)
        Data matrix (non-negative)
    p : int
        Number of factors

    Returns
    -------
    F : ndarray, shape (m, p)
        Initial F matrix
    G : ndarray, shape (p, n)
        Initial G matrix

    References
    ----------
    Langville, A. N., Meyer, C. D., Albright, R., Cox, J., & Duling, D. (2014).
    Algorithms, Initializations, and Convergence for the Nonnegative Matrix
    Factorization. arXiv:1407.7299.
    """
    m, n = X.shape
    X_pos = np.maximum(X, 1e-12)

    # Compute truncated SVD: X ≈ U @ S @ Vt
    from scipy.linalg import svd

    # Limit p to valid range for SVD
    k = min(p, m, n)

    U, s, Vt = svd(X_pos, full_matrices=False)

    # Take first k components
    U_k = U[:, :k]
    S_k = np.diag(s[:k])
    V_k = Vt[:k, :].T  # Shape (n, k)

    # Centroid decomposition: split U*sqrt(S) and sqrt(S)*V
    # into positive and negative parts
    sqrt_S = np.sqrt(S_k)

    W = U_k @ sqrt_S  # Shape (m, k)
    H = sqrt_S @ Vt[:k, :]  # Shape (k, n)

    # Apply centroid decomposition to get non-negative factors
    # For W: split into positive and negative parts
    W_pos = np.maximum(W, 0)
    W_neg = np.maximum(-W, 0)

    # For H: split into positive and negative parts
    H_pos = np.maximum(H, 0)
    H_neg = np.maximum(-H, 0)

    # Combine: F = [W+, W-], G = [H+; H-]
    # This doubles the rank, so we need to reduce back to p
    if 2 * k <= p:
        # If we have room, use both positive and negative parts
        F = np.hstack([W_pos, W_neg])[:, :p]
        G = np.vstack([H_pos, H_neg])[:p, :]
    else:
        # Otherwise just use positive parts and scale
        F = W_pos
        G = H_pos

    # Pad with random values if needed
    if F.shape[1] < p:
        mean_X = np.maximum(X_pos.mean(), 1e-10)
        scale = np.sqrt(mean_X / p)
        extra_cols = p - F.shape[1]
        F = np.hstack([F, np.random.rand(m, extra_cols) * scale])
        G = np.vstack([G, np.random.rand(extra_cols, n) * scale])

    # Ensure non-negativity
    F = np.maximum(F, 1e-12)
    G = np.maximum(G, 1e-12)

    return F, G


def initialize_factors(
    m: int,
    n: int,
    p: int,
    X: Optional[np.ndarray] = None,
    F_init: Optional[np.ndarray] = None,
    G_init: Optional[np.ndarray] = None,
    random_seed: Optional[int] = None,
    init_method: str = "random",
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Initialize F and G matrices.

    Parameters
    ----------
    m : int
        Number of variables
    n : int
        Number of observations
    p : int
        Number of factors
    X : ndarray, optional
        Data matrix for scale-aware initialization
    F_init : ndarray, optional
        Initial F matrix. If None, use init_method.
    G_init : ndarray, optional
        Initial G matrix. If None, use init_method.
    random_seed : int, optional
        Random seed for reproducibility
    init_method : {'random', 'random_acol', 'svd_centroid'}, default='random'
        Initialization method:
        - 'random': Scale-aware random initialization
        - 'random_acol': Random Acol (average columns) - Langville et al. 2014
        - 'svd_centroid': SVD-based centroid decomposition - Langville et al. 2014

    Returns
    -------
    F : ndarray, shape (m, p)
        Initial F matrix
    G : ndarray, shape (p, n)
        Initial G matrix
    """
    if random_seed is not None:
        np.random.seed(random_seed)

    # If both F_init and G_init provided, use them directly
    if F_init is not None and G_init is not None:
        return F_init.copy(), G_init.copy()

    # If only one is provided, we need to compute the other
    if F_init is not None:
        F = F_init.copy()
        # Compute G via NNLS
        if X is not None:
            from scipy.optimize import nnls
            G = np.zeros((p, n))
            X_pos = np.maximum(X, 1e-12)
            for j in range(n):
                result, _ = nnls(F, X_pos[:, j])
                G[:, j] = result
            G = np.maximum(G, 1e-12)
        else:
            mean_scale = np.sqrt(np.abs(F).mean() / p) if F.mean() > 0 else 1.0
            G = (np.random.rand(p, n) * 0.5 + 0.5) * mean_scale
        return F, G

    if G_init is not None:
        G = G_init.copy()
        # Compute F via NNLS
        if X is not None:
            from scipy.optimize import nnls
            F = np.zeros((m, p))
            X_pos = np.maximum(X, 1e-12)
            for i in range(m):
                result, _ = nnls(G.T, X_pos[i, :])
                F[i, :] = result
            F = np.maximum(F, 1e-12)
        else:
            mean_scale = np.sqrt(np.abs(G).mean() / p) if G.mean() > 0 else 1.0
            F = (np.random.rand(m, p) * 0.5 + 0.5) * mean_scale
        return F, G

    # Neither provided - use init_method
    if X is None:
        # Fallback to basic random if no data provided
        F = np.random.rand(m, p) * 0.5 + 0.5
        G = np.random.rand(p, n) * 0.5 + 0.5
        return F, G

    if init_method == "random_acol":
        return random_acol_init(X, p, num_cols=5, random_seed=random_seed)

    elif init_method == "svd_centroid":
        return svd_centroid_init(X, p)

    else:  # init_method == "random" or default
        # Scale-aware random initialization
        # We want F @ G to roughly match the scale of X
        # For random matrices with values in [0.5, 1.5], E[F@G]_ij ~ p * 1.0
        # So we need to scale by sqrt(mean(X) / p)
        mean_X = np.maximum(np.abs(X).mean(), 1e-10)
        scale = np.sqrt(mean_X / p)

        F = (np.random.rand(m, p) * 0.5 + 0.5) * scale
        G = (np.random.rand(p, n) * 0.5 + 0.5) * scale

        return F, G


def initialize_strength_coefficients(
    X: np.ndarray,
    sigma: np.ndarray,
    F: np.ndarray,
    G: np.ndarray,
    mode: str,
    alpha: Union[str, float],
    beta: Union[str, float],
    gamma: Union[str, float],
    delta: Union[str, float],
) -> Tuple[float, float, float, float]:
    """
    Initialize strength coefficients based on mode and user input.

    Parameters
    ----------
    X : ndarray
        Data matrix
    sigma : ndarray
        Uncertainty matrix
    F, G : ndarray
        Initial factor matrices
    mode : str
        Algorithm mode
    alpha, beta, gamma, delta : str or float
        Strength coefficients or 'auto'

    Returns
    -------
    alpha, beta, gamma, delta : float
        Initialized strength coefficients
    """
    m, p = F.shape
    _, n = G.shape

    # Calculate initial residuals
    R = X - F @ G

    # Basic Q (Equation 2)
    Q_basic = np.sum((R / sigma) ** 2)

    # Compute scaling coefficients
    c, d = compute_scaling_coefficients(F, G)

    # Cap for auto-initialized strength coefficients.  Equation 17 of
    # Lu & Wu (2005) balances regularisation against Q_basic, but when F/G
    # are randomly initialised far from the solution, Q_basic is enormous
    # and the resulting gamma/delta can be so large that the solver converges
    # to the regularisation minimum rather than the data-fitting minimum.
    # We cap so that the total penalty contribution at initialisation is at
    # most equal to the *expected* converged Q (≈ m*n for chi² ≈ 1), not
    # the inflated initial Q.  In practice this means gamma * sum(c*F²) ≤
    # m*n, i.e. gamma ≤ m*n / sum(c*F²).  A simpler universal cap: use a
    # moderate constant that works across problem scales.
    _denom_g = np.sum(c[:, np.newaxis].T * F**2)
    _denom_f = np.sum(d[:, np.newaxis] * G**2)
    _target_Q = float(m * n)  # expected Q at convergence (chi² ≈ 1)
    _cap_gamma = _target_Q / _denom_g if _denom_g > 0 else 1.0
    _cap_delta = _target_Q / _denom_f if _denom_f > 0 else 1.0

    # Initialize based on mode
    if mode == "basic":
        # All penalties disabled
        alpha_val = 0.0
        beta_val = 0.0
        gamma_val = 0.0
        delta_val = 0.0

    elif mode == "regularized":
        # Only regularization enabled
        alpha_val = 0.0
        beta_val = 0.0

        # Auto-initialize gamma using Equation 17, capped at target Q level
        if gamma == "auto":
            gamma_val = min(Q_basic, _target_Q) / _denom_g if _denom_g > 0 else 1.0
        else:
            gamma_val = float(gamma)

        # Auto-initialize delta similarly, capped at target Q level
        if delta == "auto":
            delta_val = min(Q_basic, _target_Q) / _denom_f if _denom_f > 0 else 1.0
        else:
            delta_val = float(delta)

    else:  # mode == "full"
        # All terms enabled

        # Auto-initialize alpha, capped at target Q level
        if alpha == "auto":
            log_sum_G = -np.sum(np.log10(np.maximum(F, 1e-12)))
            alpha_val = min(Q_basic, _target_Q) / log_sum_G if log_sum_G > 0 else 1.0
        else:
            alpha_val = float(alpha)

        # Auto-initialize beta, capped at target Q level
        if beta == "auto":
            log_sum_F = -np.sum(np.log10(np.maximum(G, 1e-12)))
            beta_val = min(Q_basic, _target_Q) / log_sum_F if log_sum_F > 0 else 1.0
        else:
            beta_val = float(beta)

        # Auto-initialize gamma, capped at target Q level
        if gamma == "auto":
            gamma_val = min(Q_basic, _target_Q) / _denom_g if _denom_g > 0 else 1.0
        else:
            gamma_val = float(gamma)

        # Auto-initialize delta, capped at target Q level
        if delta == "auto":
            delta_val = min(Q_basic, _target_Q) / _denom_f if _denom_f > 0 else 1.0
        else:
            delta_val = float(delta)

    return alpha_val, beta_val, gamma_val, delta_val


def perform_nnls_update(
    X: np.ndarray,
    F: np.ndarray,
    G: np.ndarray,
    update_G: bool = True,
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Perform non-negative least squares update for initial iterations.

    Parameters
    ----------
    X : ndarray, shape (m, n)
        Data matrix
    F : ndarray, shape (m, p)
        Current F matrix
    G : ndarray, shape (p, n)
        Current G matrix
    update_G : bool, default=True
        If True, update F. If False, update G.

    Returns
    -------
    F : ndarray
        Updated F matrix
    G : ndarray
        Updated G matrix

    Notes
    -----
    Implements Section 3.8 of Lu & Wu (2005) for acceleration
    of initial iterations.
    """
    from scipy.optimize import nnls

    F_new = F.copy()
    G_new = G.copy()

    if update_G:
        # Update F via NNLS: X ≈ F @ G, solve for F
        # For each variable i: X[i, :] ≈ F[i, :] @ G
        for i in range(F.shape[0]):
            # Solve: G.T @ x ≈ X[i, :]
            result, _ = nnls(G.T, X[i, :])
            F_new[i, :] = result
    else:
        # Update G via NNLS: X ≈ F @ G, solve for G
        # For each observation j: X[:, j] ≈ F @ G[:, j]
        for j in range(G.shape[1]):
            # Solve: F @ x ≈ X[:, j]
            result, _ = nnls(F, X[:, j])
            G_new[:, j] = result

    return F_new, G_new


def control_step_length(
    X: np.ndarray,
    sigma: np.ndarray,
    G_old: np.ndarray,
    F_old: np.ndarray,
    g: np.ndarray,
    f: np.ndarray,
    Q_old: float,
    c: np.ndarray,
    d: np.ndarray,
    alpha: float,
    beta: float,
    gamma: float,
    delta: float,
    max_step_halving: int = 3,
) -> Tuple[np.ndarray, np.ndarray, float, bool]:
    """
    Control step length to ensure Q decreases.

    Parameters
    ----------
    X, sigma : ndarray
        Data and uncertainty matrices
    G_old, F_old : ndarray
        Current F and G matrices
    g, f : ndarray
        Computed updates
    Q_old : float
        Previous objective function value
    c, d : ndarray
        Scaling coefficients
    alpha, beta, gamma, delta : float
        Strength coefficients
    max_step_halving : int, default=3
        Maximum number of step halving attempts

    Returns
    -------
    F_new : ndarray
        Updated F matrix
    G_new : ndarray
        Updated G matrix
    Q_new : float
        New objective function value
    step_shortened : bool
        Whether step was shortened

    Notes
    -----
    Implements Section 3.7 of Lu & Wu (2005).
    """
    step_shortened = False
    best_Q = np.inf
    best_G = G_old
    best_F = F_old
    best_fraction = 1.0

    for attempt in range(max_step_halving + 1):
        fraction = 0.5 ** attempt

        # Try step with this fraction
        F_try = G_old + fraction * g
        G_try = F_old + fraction * f

        # Enforce non-negativity
        F_try = np.maximum(F_try, 1e-12)
        G_try = np.maximum(G_try, 1e-12)

        # Compute objective function
        R_try = X - F_try @ G_try
        Q_basic_try, _ = compute_objective_function(
            R_try, sigma, F_try, G_try, c, d,
            alpha, beta, gamma, delta
        )

        if Q_basic_try < best_Q:
            best_Q = Q_basic_try
            best_G = F_try
            best_F = G_try
            best_fraction = fraction

        # If basic Q is decreasing, accept this step
        if Q_basic_try < Q_old:
            if attempt > 0:
                step_shortened = True
            return F_try, G_try, Q_basic_try, step_shortened

    # If no decreasing step found, return best attempt
    if best_fraction < 1.0:
        step_shortened = True

    return best_G, best_F, best_Q, step_shortened


def pmf(
    X: np.ndarray,
    sigma: np.ndarray,
    p: int,
    mode: str = "full",
    algorithm: str = "acls",
    F_init: Optional[np.ndarray] = None,
    G_init: Optional[np.ndarray] = None,
    max_iter: int = 1000,
    conv_tol: float = 0.005,
    solver: str = "numpy",
    condition_check_interval: Optional[int] = None,
    verbose: Union[bool, int] = False,
    # Initialization
    init_method: str = "random",
    # Strength coefficients (Newton algorithm)
    alpha: Union[str, float] = "auto",
    beta: Union[str, float] = "auto",
    gamma: Union[str, float] = "auto",
    delta: Union[str, float] = "auto",
    # ACLS regularization parameters
    lambda_W: float = 0.0,
    lambda_H: float = 0.0,
    fpeak: float = 0.0,
    # Bayesian algorithm parameters
    n_samples: int = 1000,
    n_burnin: int = 500,
    n_thin: int = 1,
    lambda_F: float = 1.0,
    lambda_G: float = 1.0,
    learn_hyperparams: bool = True,
    hyperparam_shape: float = 1.0,
    hyperparam_rate: float = 0.1,
    warm_start: bool = True,
    store_samples: bool = False,
    ard: bool = False,
    ard_threshold: float = 0.01,
    likelihood: str = "gaussian",
    mh_step_size_G: float = 0.1,
    mh_step_size_F: float = 0.1,
    volume_alpha: float = 0.0,
    prior_F_shape: float = 1.0,
    prior_G_shape: float = 1.0,
    # Reweighting (Newton algorithm)
    enable_reweighting: bool = True,
    outlier_threshold: float = 4.0,
    # Step control (Newton algorithm)
    enable_step_control: bool = True,
    max_step_halving: int = 3,
    # Initial acceleration (Newton algorithm)
    enable_initial_accel: bool = True,
    accel_iterations: int = 10,
    # Multi-phase iteration control (PMF2-style, Newton algorithm)
    enable_multiphase: bool = True,
    phase_config: Optional[list] = None,
    # Numerical stability
    min_value: float = 1e-12,
    rcond_limit: float = 1e-12,
    # Random seed
    random_seed: Optional[int] = None,
) -> PMFResult:
    """
    Perform Positive Matrix Factorization.

    Implements the PMF algorithm from Lu & Wu (2005), solving:
        min_{F,G} Σᵢⱼ (wᵢⱼ · Rᵢⱼ)²
        subject to F ≥ 0, G ≥ 0
        where R = X - GF and wᵢⱼ = 1/σᵢⱼ²

    Parameters
    ----------
    X : ndarray, shape (m, n)
        Data matrix to factorize
    sigma : ndarray, shape (m, n)
        Standard deviations (uncertainties) for each element
    p : int
        Number of factors (rank)
    mode : {'basic', 'regularized', 'full'}, default='full'
        Algorithm mode (Newton algorithm only)
    algorithm : {'acls', 'ls-nmf', 'newton', 'bayes'}, default='acls'
        Algorithm to use:
        - 'acls': Alternating Constrained Least Squares from Langville et al.
          (2014). Solves smaller k×k systems, simpler and much faster (default).
        - 'ls-nmf': Weighted multiplicative updates from Wang et al. (2006).
          Same algorithm as ESAT's LS-NMF. Good for direct comparison with ESAT.
        - 'newton': Newton-based method from Lu & Wu (2005). Solves large
          (mp+np)×(mp+np) systems but handles uncertainties naturally.
        - 'bayes': Bayesian NMF via Gibbs sampling (Schmidt et al. 2009).
          Returns posterior mean F/G with full uncertainty quantification.
          See n_samples, n_burnin, lambda_F, lambda_G, and related kwargs.
    F_init, G_init : ndarray, optional
        Initial factor matrices
    max_iter : int, default=1000
        Maximum iterations
    conv_tol : float, default=0.005
        Convergence tolerance (relative change in Q)
    solver : str, default='numpy'
        Solver backend: 'numpy', 'jax', or 'jax_sparse'
    condition_check_interval : int or None, default=None
        How often to compute the condition number for the system matrix.
        None chooses a solver-aware default (1 for NumPy, 5 for JAX backends)
        to reduce JAX compilation overhead.
    verbose : bool or int, default=False
        Verbosity level (0=quiet, 1=basic, 2=detailed)
    init_method : {'random', 'random_acol', 'svd_centroid'}, default='random'
        Initialization method for F and G matrices:
        - 'random': Scale-aware random initialization
        - 'random_acol': Random Acol - average random columns (Langville et al. 2014)
        - 'svd_centroid': SVD-based centroid decomposition (Langville et al. 2014)
    alpha, beta, gamma, delta : str or float, default='auto'
        Strength coefficients for penalties and regularization (Newton only)
    lambda_W : float, default=0.0
        Tikhonov regularization for W (F) matrix (ACLS only)
    lambda_H : float, default=0.0
        Tikhonov regularization for H (G) matrix (ACLS only)
    n_samples : int, default=1000
        Number of posterior samples to collect (Bayesian only)
    n_burnin : int, default=500
        Number of burn-in sweeps to discard (Bayesian only)
    n_thin : int, default=1
        Thinning factor for sample collection (Bayesian only)
    lambda_F : float, default=1.0
        Exponential rate prior on F elements (Bayesian only)
    lambda_G : float, default=1.0
        Exponential rate prior on G elements (Bayesian only)
    learn_hyperparams : bool, default=True
        Update lambda_F/lambda_G via conjugate Gamma hyperprior (Bayesian only)
    hyperparam_shape : float, default=1.0
        Shape parameter a for Gamma(a, b) hyperprior on lambda (Bayesian only)
    hyperparam_rate : float, default=0.1
        Rate parameter b for Gamma(a, b) hyperprior on lambda (Bayesian only)
    store_samples : bool, default=False
        Store full F/G sample arrays in result (Bayesian only)
    ard : bool, default=False
        Enable Automatic Relevance Determination for factor pruning (Bayesian only).
        Over-specify p and let the model zero out unnecessary factors.
    ard_threshold : float, default=0.01
        Relative contribution threshold for active factor detection (Bayesian only)
    enable_reweighting : bool, default=True
        Enable iterative reweighting for outliers (Newton only)
    outlier_threshold : float, default=4.0
        Threshold for outlier detection (multiples of sigma) (Newton only)
    enable_step_control : bool, default=True
        Enable step length control (Newton only)
    max_step_halving : int, default=3
        Maximum step halving attempts (Newton only)
    enable_initial_accel : bool, default=True
        Enable initial acceleration via NNLS (Newton only)
    accel_iterations : int, default=10
        Number of iterations to use acceleration (Newton only)
    enable_multiphase : bool, default=True
        Enable PMF2-style multi-phase iteration control (Newton only)
    phase_config : list of dict, optional
        Custom phase configuration (Newton only). Each dict should have:
        - 'conv_tol': convergence tolerance for this phase
        - 'max_iter': maximum iterations for this phase
        - 'min_steps': minimum iterations before checking convergence
        Default uses PMF2-style 3-phase configuration.
    min_value : float, default=1e-12
        Floor value for truncating negatives
    rcond_limit : float, default=1e-12
        Reciprocal condition number warning threshold (Newton only)
    random_seed : int, optional
        Random seed for reproducibility

    Returns
    -------
    result : PMFResult
        Results object containing F, G, diagnostics, and convergence info

    Raises
    ------
    ValueError
        If inputs are invalid
    RuntimeError
        If algorithm fails to converge or encounters numerical issues

    References
    ----------
    Lu, J., & Wu, L. (2005). Technical details and programming guide for
    a general two-way positive matrix factorization algorithm.

    Langville, A. N., Meyer, C. D., Albright, R., Cox, J., & Duling, D. (2014).
    Algorithms, Initializations, and Convergence for the Nonnegative Matrix
    Factorization. arXiv:1407.7299.

    Examples
    --------
    >>> import numpy as np
    >>> from pmf_acls import pmf
    >>>
    >>> # Generate synthetic data
    >>> m, n, p = 10, 20, 3
    >>> F_true = np.random.rand(m, p)
    >>> G_true = np.random.rand(p, n)
    >>> X = F_true @ G_true + 0.1 * np.random.randn(m, n)
    >>> sigma = 0.1 * np.ones_like(X)
    >>>
    >>> # Run PMF with ACLS algorithm (default)
    >>> result = pmf(X, sigma, p=3)
    >>> print(f"Converged: {result.converged}")
    >>> print(f"Final Q: {result.Q:.4f}")
    >>>
    >>> # Run PMF with Newton algorithm
    >>> result_newton = pmf(X, sigma, p=3, algorithm='newton')
    >>> print(f"Newton Q: {result_newton.Q:.4f}")
    """
    # ========== ALGORITHM SELECTION ==========
    # Validate algorithm parameter
    valid_algorithms = {"newton", "acls", "ls-nmf", "bayes"}
    if algorithm not in valid_algorithms:
        raise ValueError(
            f"Invalid algorithm '{algorithm}'. "
            f"Valid options: {sorted(valid_algorithms)}"
        )

    # Route to Bayesian implementation if selected
    if algorithm == "bayes":
        from .bayes import pmf_bayes
        bayes_result = pmf_bayes(
            X=X,
            sigma=sigma,
            p=p,
            n_samples=n_samples,
            n_burnin=n_burnin,
            n_thin=n_thin,
            lambda_F=lambda_F,
            lambda_G=lambda_G,
            learn_hyperparams=learn_hyperparams,
            hyperparam_shape=hyperparam_shape,
            hyperparam_rate=hyperparam_rate,
            F_init=F_init,
            G_init=G_init,
            init_method=init_method,
            warm_start=warm_start,
            store_samples=store_samples,
            random_seed=random_seed,
            ard=ard,
            ard_threshold=ard_threshold,
            likelihood=likelihood,
            mh_step_size_G=mh_step_size_G,
            mh_step_size_F=mh_step_size_F,
            volume_alpha=volume_alpha,
            prior_F_shape=prior_F_shape,
            prior_G_shape=prior_G_shape,
            verbose=bool(verbose),
        )
        return bayes_result.to_pmf_result()

    # Route to ACLS implementation if selected
    if algorithm == "acls":
        return pmf_acls(
            X=X,
            sigma=sigma,
            p=p,
            F_init=F_init,
            G_init=G_init,
            max_iter=max_iter,
            conv_tol=conv_tol,
            verbose=verbose,
            init_method=init_method,
            lambda_W=lambda_W,
            lambda_H=lambda_H,
            fpeak=fpeak,
            min_value=min_value,
            random_seed=random_seed,
        )

    # Route to LS-NMF implementation if selected
    if algorithm == "ls-nmf":
        return pmf_ls_nmf(
            X=X,
            sigma=sigma,
            p=p,
            F_init=F_init,
            G_init=G_init,
            max_iter=max_iter,
            conv_tol=conv_tol,
            verbose=verbose,
            init_method=init_method,
            min_value=min_value,
            random_seed=random_seed,
        )

    # ========== NEWTON ALGORITHM ==========
    # ========== INPUT VALIDATION ==========
    validate_data_matrix(X, "X")
    m, n = X.shape

    validate_uncertainty_matrix(sigma, X.shape)
    validate_rank(p, m, n)
    validate_mode(mode)
    validate_solver(solver)

    validate_initial_matrix(F_init, (m, p), "F_init", allow_none=True)
    validate_initial_matrix(G_init, (p, n), "G_init", allow_none=True)

    validate_integer_range(max_iter, "max_iter", min_val=1)
    validate_positive_scalar(conv_tol, "conv_tol")
    if condition_check_interval is not None:
        validate_integer_range(
            condition_check_interval, "condition_check_interval", min_val=1
        )
    validate_boolean(enable_reweighting, "enable_reweighting")
    validate_positive_scalar(outlier_threshold, "outlier_threshold")
    validate_boolean(enable_step_control, "enable_step_control")
    validate_integer_range(max_step_halving, "max_step_halving", min_val=0)
    validate_boolean(enable_initial_accel, "enable_initial_accel")
    validate_integer_range(accel_iterations, "accel_iterations", min_val=0)
    validate_positive_scalar(min_value, "min_value")
    validate_positive_scalar(rcond_limit, "rcond_limit")

    alpha = validate_strength_coefficient(alpha, "alpha")
    beta = validate_strength_coefficient(beta, "beta")
    gamma = validate_strength_coefficient(gamma, "gamma")
    delta = validate_strength_coefficient(delta, "delta")

    # Check data quality
    check_data_quality(X, sigma)

    if verbose:
        print("=" * 60)
        print("PMF Algorithm (Newton)")
        print("=" * 60)
        print(f"Data: {m} variables × {n} observations")
        print(f"Factors: {p}")
        print(f"Mode: {mode}")
        print(f"Solver: {solver}")
        print("=" * 60)

    # ========== INITIALIZATION ==========
    # Warm-start from a quick ACLS solve when no explicit initialisation is
    # provided.  The Newton solver's auto-scaled regularisation (Eq. 17 of
    # Lu & Wu 2005) assumes the starting point is already in the basin of
    # the data-fitting minimum; random initialisation violates that
    # assumption and produces over-regularised solutions.
    if F_init is None and G_init is None and warm_start:
        if verbose:
            print("Warm-starting from ACLS solve ...")
        _acls = pmf_acls(X, sigma, p,
                         init_method=init_method, random_seed=random_seed,
                         max_iter=200, conv_tol=0.01, verbose=False)
        F_init = _acls.F
        G_init = _acls.G

    F, G = initialize_factors(m, n, p, X, F_init, G_init, random_seed, init_method)

    # Initialize weights
    weights = 1.0 / sigma**2

    # Solver-aware condition check cadence (JAX condition checks are expensive)
    if condition_check_interval is None:
        condition_check_interval_val = 5 if "jax" in solver else 1
    else:
        condition_check_interval_val = condition_check_interval

    # Initialize strength coefficients
    alpha, beta, gamma, delta = initialize_strength_coefficients(
        X, sigma, F, G, mode, alpha, beta, gamma, delta
    )

    if verbose:
        print(f"Initial strength coefficients:")
        print(f"  alpha={alpha:.4e}, beta={beta:.4e}, gamma={gamma:.4e}, delta={delta:.4e}")

    # Calculate initial objective function
    R = X - F @ G
    Q_basic, Q_enhanced = compute_objective_function(
        R, sigma, F, G,
        *compute_scaling_coefficients(F, G),
        alpha, beta, gamma, delta
    )

    Q_history = [Q_basic]
    Q_old = Q_basic

    if verbose:
        print(f"Initial Q: {Q_basic:.4e}")
        print("=" * 60)

    converged = False
    rel_change = np.inf

    # ========== MULTI-PHASE CONFIGURATION ==========
    # PMF2-style iteration control: multiple phases with progressively
    # tightening convergence criteria
    if enable_multiphase:
        if phase_config is None:
            # Default PMF2-style 3-phase configuration
            # Based on PMF2's iteration control table:
            # Phase 1: Fast initial progress, run until Q stabilizes at ~50% change
            # Phase 2: Medium refinement, ~10% change threshold
            # Phase 3: Fine convergence, user-specified tolerance
            # Note: min_steps ensures we don't exit phases too early
            phases = [
                {'conv_tol': 0.5, 'max_iter': 100, 'min_steps': 10, 'name': 'Phase 1 (coarse)'},
                {'conv_tol': 0.1, 'max_iter': 150, 'min_steps': 10, 'name': 'Phase 2 (medium)'},
                {'conv_tol': conv_tol, 'max_iter': max(max_iter - 250, 100), 'min_steps': 4, 'name': 'Phase 3 (fine)'},
            ]
        else:
            phases = phase_config
    else:
        # Single phase with user-specified parameters
        phases = [{'conv_tol': conv_tol, 'max_iter': max_iter, 'min_steps': 1, 'name': 'Single phase'}]

    total_iterations = 0
    rel_change = 1.0  # Initialize for final reporting

    # ========== MULTI-PHASE ITERATION LOOP ==========
    for phase_idx, phase in enumerate(phases):
        phase_conv_tol = phase['conv_tol']
        phase_max_iter = phase['max_iter']
        phase_min_steps = phase.get('min_steps', 1)
        phase_name = phase.get('name', f'Phase {phase_idx + 1}')

        if verbose:
            print(f"\n{phase_name}: conv_tol={phase_conv_tol:.4f}, max_iter={phase_max_iter}")

        phase_iterations = 0
        phase_converged = False

        for iteration in range(phase_max_iter):
            total_iterations += 1
            phase_iterations += 1

            if verbose >= 2:
                print(f"\n[{phase_name}] Iteration {phase_iterations}/{phase_max_iter} (total: {total_iterations})")

            # Step 4: Reweighting (if enabled and not first few iterations)
            # Always reset to base uncertainty weights before reweighting
            weights = 1.0 / sigma**2

            if enable_reweighting and total_iterations > 5:
                abs_R = np.abs(R)
                outliers = abs_R > outlier_threshold * sigma
                if np.any(outliers):
                    # Down-weight outliers (residuals > outlier_threshold * sigma)
                    weights[outliers] = 1.0 / (abs_R[outliers] / outlier_threshold) ** 2

            # Step 5: Calculate scaling coefficients
            c, d = compute_scaling_coefficients(F, G)

            # Step 6: Calculate logarithmic penalty constants
            a_G, b_G = quadratic_log_approximation(F)
            a_F, b_F = quadratic_log_approximation(G)

            # Steps 7-9: Build and solve system
            Gamma, W, K_r, K_p = build_system_matrices(
                F, G, weights, c, d, a_G, a_F, gamma, delta, alpha, beta
            )

            r = build_residual_vector(R)
            Theta = build_theta_vector(F, G)
            Theta_star = build_theta_star_vector(b_G, b_F)

            # Create LSM and RSV
            LSM = Gamma.T @ W @ Gamma + K_r + K_p
            RSV = Gamma.T @ W @ r - K_r @ Theta + K_p @ (Theta_star - Theta)

            # Step 10: Solve equation
            check_condition = (total_iterations % condition_check_interval_val) == 0
            try:
                phi, rcond = solve_pmf_system(
                    LSM, RSV, solver_name=solver,
                    check_condition=check_condition, rcond_limit=rcond_limit
                )
            except RuntimeError as e:
                warnings.warn(
                    f"Solve failed at iteration {total_iterations}: {e}. "
                    f"Trying to continue...",
                    RuntimeWarning
                )
                # Try increasing regularization
                gamma *= 2.0
                delta *= 2.0
                continue

            # Step 11: Extract updates
            f, g = extract_updates_from_phi(phi, m, n, p)

            # Step 12: Update F and G
            F_new = F + g
            G_new = G + f

            # CRITICAL: Enforce non-negativity constraint
            # Truncate any negative values to min_value
            F_new = np.maximum(F_new, min_value)
            G_new = np.maximum(G_new, min_value)

            # Step 13: Initial acceleration (for early iterations of first phase)
            if enable_initial_accel and total_iterations <= accel_iterations:
                # Perform NNLS update for better initial estimates
                F_new, G_new = perform_nnls_update(X, F_new, G_new, update_G=True)
                F_new, G_new = perform_nnls_update(X, F_new, G_new, update_G=False)

            # Step 14: Step length control
            if enable_step_control:
                F_new, G_new, Q_new, step_shortened = control_step_length(
                    X, sigma, F, G, g, f, Q_old, c, d,
                    alpha, beta, gamma, delta, max_step_halving
                )

                if step_shortened and verbose >= 2:
                    print(f"  Step shortened")
            else:
                R_new = X - F_new @ G_new
                Q_new, _ = compute_objective_function(
                    R_new, sigma, F_new, G_new, c, d,
                    alpha, beta, gamma, delta
                )

            # Update matrices
            F = F_new
            G = G_new
            R = X - F @ G
            Q_history.append(Q_new)

            # Step 15: Test convergence (within current phase)
            if phase_iterations > phase_min_steps:
                rel_change = abs(Q_new - Q_old) / max(Q_old, 1e-12)
                q_decreased = Q_new <= Q_old

                if verbose >= 2:
                    direction = "v" if q_decreased else "^"
                    print(f"  Q: {Q_new:.4e} (change: {rel_change:.4e} {direction})")
                elif verbose == 1 and phase_iterations % 10 == 0:
                    print(f"  Iter {phase_iterations}: Q={Q_new:.4e}, change={rel_change:.4e}")

                # Check phase convergence criteria
                if q_decreased and rel_change < phase_conv_tol:
                    phase_converged = True
                    if verbose:
                        print(f"  {phase_name} converged at iteration {phase_iterations}")
                        print(f"  Q: {Q_new:.4e}")
                    break

            Q_old = Q_new

        # End of phase
        if verbose and not phase_converged:
            print(f"  {phase_name} reached max iterations ({phase_iterations})")
            print(f"  Q: {Q_history[-1]:.4e}")

        # Check if we've achieved final convergence (in last phase)
        if phase_idx == len(phases) - 1 and phase_converged:
            converged = True

    # ========== FINALIZE ==========
    if not converged:
        warnings.warn(
            f"Did not converge within {total_iterations} iterations. "
            f"Final relative change: {rel_change:.4e}",
            UserWarning
        )

    # Calculate final diagnostics
    R_final = X - F @ G

    # Explained variance
    var_total = np.var(X)
    var_resid = np.var(R_final)
    explained_variance = 1.0 - (var_resid / var_total) if var_total > 0 else 0.0

    # Chi-square statistic
    degrees_of_freedom = m * n - (m + n) * p
    chi2 = Q_history[-1] / degrees_of_freedom if degrees_of_freedom > 0 else 0.0

    # Create result object
    result = PMFResult(
        F=F,
        G=G,
        Q=Q_history[-1],
        Q_history=Q_history,
        n_iter=total_iterations,
        converged=converged,
        residuals=R_final,
        explained_variance=explained_variance,
        chi2=chi2,
    )

    if verbose:
        print("=" * 60)
        result.summary()

    return result


# ============================================================================
# FPEAK Sweep
# ============================================================================

def fpeak_sweep(
    X: np.ndarray,
    sigma: np.ndarray,
    p: int,
    fpeak_values: Optional[List[float]] = None,
    base_result: Optional["PMFResult"] = None,
    warm_start: bool = True,
    verbose: Union[bool, int] = False,
    **pmf_kwargs,
) -> "FPEAKSweepResult":
    """
    Sweep FPEAK values to explore rotational ambiguity.

    Runs PMF at each FPEAK value and collects the Q-vs-FPEAK curve.
    A flat curve indicates large rotational ambiguity; a steep curve
    indicates a well-determined rotation.

    Parameters
    ----------
    X : ndarray, shape (m, n)
        Data matrix.
    sigma : ndarray, shape (m, n)
        Uncertainty matrix.
    p : int
        Number of factors.
    fpeak_values : list of float, optional
        FPEAK values to test.  Default: [-1.5, -1.0, -0.5, -0.2, 0, 0.2, 0.5, 1.0, 1.5].
    base_result : PMFResult, optional
        Pre-computed base solution at fpeak=0.  If None, one is computed.
    warm_start : bool, default=True
        Use previous FPEAK solution as initialization for the next value.
    verbose : bool or int, default=False
        Print progress.
    **pmf_kwargs
        Additional keyword arguments passed to :func:`pmf` (e.g. max_iter,
        conv_tol, random_seed, lambda_W, lambda_H).

    Returns
    -------
    FPEAKSweepResult
        Container with results for each FPEAK value and the Q-vs-FPEAK curve.
    """
    from .data_structures import FPEAKSweepResult

    if fpeak_values is None:
        fpeak_values = [-1.5, -1.0, -0.5, -0.2, 0.0, 0.2, 0.5, 1.0, 1.5]

    # Ensure 0.0 is in the list
    if 0.0 not in fpeak_values:
        fpeak_values = sorted(set(fpeak_values) | {0.0})
    else:
        fpeak_values = sorted(set(fpeak_values))

    # Strip fpeak from kwargs so we control it
    pmf_kwargs.pop("fpeak", None)

    # Base solution at fpeak=0
    if base_result is None:
        if verbose:
            print("Running base PMF (fpeak=0)...")
        base_result = pmf(X, sigma, p=p, fpeak=0.0, verbose=verbose, **pmf_kwargs)

    results = {0.0: base_result}

    # Sweep order: start from 0 and go outward for better warm-starting
    positives = sorted(fp for fp in fpeak_values if fp > 0)
    negatives = sorted((fp for fp in fpeak_values if fp < 0), reverse=True)

    # Sweep positive direction
    prev_result = base_result
    for fp in positives:
        if verbose:
            print(f"Running fpeak={fp:.2f}...")
        kwargs = dict(pmf_kwargs)
        if warm_start:
            kwargs["F_init"] = prev_result.F.copy()
            kwargs["G_init"] = prev_result.G.copy()
        result = pmf(X, sigma, p=p, fpeak=fp, verbose=False, **kwargs)
        results[fp] = result
        prev_result = result
        if verbose:
            dQ = result.Q - base_result.Q
            print(f"  Q={result.Q:.2f}  dQ={dQ:+.2f}  converged={result.converged}")

    # Sweep negative direction
    prev_result = base_result
    for fp in negatives:
        if verbose:
            print(f"Running fpeak={fp:.2f}...")
        kwargs = dict(pmf_kwargs)
        if warm_start:
            kwargs["F_init"] = prev_result.F.copy()
            kwargs["G_init"] = prev_result.G.copy()
        result = pmf(X, sigma, p=p, fpeak=fp, verbose=False, **kwargs)
        results[fp] = result
        prev_result = result
        if verbose:
            dQ = result.Q - base_result.Q
            print(f"  Q={result.Q:.2f}  dQ={dQ:+.2f}  converged={result.converged}")

    return FPEAKSweepResult(
        base_result=base_result,
        fpeak_values=fpeak_values,
        results=results,
    )
