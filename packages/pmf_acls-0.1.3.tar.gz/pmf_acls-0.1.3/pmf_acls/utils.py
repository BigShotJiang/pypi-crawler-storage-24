"""
Data preparation utilities for PMF analysis.

This module provides helper functions for preparing environmental data
for PMF analysis, including:
- Handling missing data (NaN values)
- Handling below-detection-limit (BDL) values
- Estimating uncertainties from data
- General data cleaning and validation

Best practices based on EPA PMF guidelines and environmental data analysis.
"""

from typing import Optional, Tuple, Union
import warnings
import numpy as np


def prepare_data(
    X: np.ndarray,
    sigma: Optional[np.ndarray] = None,
    detection_limit: Optional[np.ndarray] = None,
    missing_method: str = "median",
    uncertainty_method: str = "auto",
    bdl_replacement: str = "half_dl",
    min_uncertainty_fraction: float = 0.1,
    verbose: bool = False,
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Prepare data for PMF analysis by handling missing values, detection
    limits, and uncertainty estimation.

    This is a convenience function that applies standard data preparation
    steps commonly used in environmental PMF analysis.

    Parameters
    ----------
    X : ndarray, shape (m, n)
        Data matrix. May contain NaN or negative values.
    sigma : ndarray, shape (m, n), optional
        Uncertainties. If None, will be estimated.
    detection_limit : ndarray, shape (m,) or (m, n), optional
        Detection limits for each variable (or each measurement).
        Values below DL will be flagged and handled appropriately.
    missing_method : {'median', 'mean', 'zero'}, default='median'
        How to replace missing (NaN) values:
        - 'median': Use median of non-missing values per variable
        - 'mean': Use mean of non-missing values per variable
        - 'zero': Replace with zero
    uncertainty_method : {'auto', 'poisson', 'fraction'}, default='auto'
        How to estimate uncertainties if sigma is not provided:
        - 'auto': Poisson for positive data, fraction for negative/zero
        - 'poisson': σ = √X (appropriate for count data)
        - 'fraction': σ = fraction * X
    bdl_replacement : {'half_dl', 'third_dl', 'zero'}, default='half_dl'
        How to replace below-detection-limit values:
        - 'half_dl': Replace with DL/2 (EPA recommendation)
        - 'third_dl': Replace with DL/3
        - 'zero': Replace with zero
    min_uncertainty_fraction : float, default=0.1
        Minimum uncertainty as fraction of value (prevents zero uncertainty).
    verbose : bool, default=False
        Whether to print diagnostic information.

    Returns
    -------
    X_clean : ndarray, shape (m, n)
        Cleaned data matrix with no NaN or negative values.
    sigma_clean : ndarray, shape (m, n)
        Uncertainty matrix with appropriate values for missing/BDL data.

    Notes
    -----
    Processing steps applied in order:
    1. Handle missing (NaN) values
    2. Handle below-detection-limit values
    3. Estimate or validate uncertainties
    4. Enforce minimum uncertainties
    5. Ensure non-negativity

    Missing Data:
    Missing values are replaced and assigned large uncertainties (3x typical)
    to downweight their influence on the solution.

    Below Detection Limit (BDL):
    Values below DL are replaced with DL/2 (or other fraction) and assigned
    uncertainty of 5·DL/6 following EPA PMF guidelines.

    Uncertainty Estimation:
    - Poisson model: σ = √X (for count data like particle counts)
    - Fraction model: σ = 0.1 * |X| (for concentration data)
    - Minimum: σ ≥ min_uncertainty_fraction * X (prevents division by zero)

    References
    ----------
    EPA (2014). EPA Positive Matrix Factorization (PMF) 5.0 Fundamentals
    and User Guide. EPA/600/R-14/108.

    Examples
    --------
    >>> import numpy as np
    >>> from pmf_acls import prepare_data
    >>>
    >>> # Data with missing values and BDL
    >>> X = np.array([[1.5, 2.3, np.nan],
    ...               [0.05, 3.1, 2.8],
    ...               [-0.1, 1.9, 2.2]])  # -0.1 is BDL
    >>> DL = np.array([0.1, 0.1, 0.1])
    >>>
    >>> X_clean, sigma = prepare_data(X, detection_limit=DL)
    >>> print(X_clean)  # No NaN or negatives
    >>> print(sigma)    # Uncertainties assigned
    """
    m, n = X.shape

    if verbose:
        print("=" * 60)
        print("PMF Data Preparation")
        print("=" * 60)
        print(f"Data shape: {m} variables × {n} observations")

    # Make copies to avoid modifying input
    X_clean = X.copy()
    if sigma is not None:
        sigma_clean = sigma.copy()
    else:
        sigma_clean = None

    # Step 1: Handle missing values
    n_missing = np.sum(np.isnan(X_clean))
    if n_missing > 0:
        if verbose:
            print(f"\nMissing values: {n_missing} ({n_missing/(m*n)*100:.1f}%)")
        X_clean, sigma_clean = handle_missing_values(
            X_clean, sigma_clean, method=missing_method
        )

    # Step 2: Handle below-detection-limit values
    if detection_limit is not None:
        X_clean, sigma_clean = handle_below_detection_limit(
            X_clean, sigma_clean, detection_limit,
            replacement=bdl_replacement, verbose=verbose
        )

    # Step 3: Estimate uncertainties if not provided
    if sigma_clean is None:
        if verbose:
            print(f"\nEstimating uncertainties using method: {uncertainty_method}")
        sigma_clean = estimate_uncertainty(
            X_clean, method=uncertainty_method,
            min_fraction=min_uncertainty_fraction
        )
    else:
        # Ensure minimum uncertainty
        sigma_clean = enforce_minimum_uncertainty(
            X_clean, sigma_clean, min_fraction=min_uncertainty_fraction
        )

    # Step 4: Final cleanup - ensure all values are non-negative
    X_clean = np.maximum(X_clean, 0.0)
    sigma_clean = np.maximum(sigma_clean, min_uncertainty_fraction * np.abs(X_clean))

    # Validation
    assert not np.any(np.isnan(X_clean)), "X_clean contains NaN"
    assert not np.any(np.isnan(sigma_clean)), "sigma_clean contains NaN"
    assert np.all(X_clean >= 0), "X_clean contains negative values"
    assert np.all(sigma_clean > 0), "sigma_clean contains non-positive values"

    if verbose:
        print(f"\nData preparation complete")
        print(f"  X range: [{np.min(X_clean):.3f}, {np.max(X_clean):.3f}]")
        print(f"  σ range: [{np.min(sigma_clean):.3f}, {np.max(sigma_clean):.3f}]")
        print(f"  Median σ/X: {np.median(sigma_clean/np.maximum(X_clean, 1e-10)):.3f}")
        print("=" * 60)

    return X_clean, sigma_clean


def handle_missing_values(
    X: np.ndarray,
    sigma: Optional[np.ndarray] = None,
    method: str = "median",
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Replace missing (NaN) values with estimates and assign large uncertainties.

    Parameters
    ----------
    X : ndarray, shape (m, n)
        Data matrix possibly containing NaN.
    sigma : ndarray, shape (m, n), optional
        Uncertainty matrix.
    method : {'median', 'mean', 'zero'}, default='median'
        Replacement method for missing values.

    Returns
    -------
    X_filled : ndarray, shape (m, n)
        Data with NaN replaced.
    sigma_filled : ndarray, shape (m, n)
        Uncertainties with large values for missing data.
    """
    m, n = X.shape
    X_filled = X.copy()
    if sigma is None:
        sigma_filled = np.ones_like(X)
    else:
        sigma_filled = sigma.copy()

    # Find missing values
    missing_mask = np.isnan(X)

    if not np.any(missing_mask):
        return X_filled, sigma_filled

    # Replace missing values per variable (row)
    for i in range(m):
        row_missing = missing_mask[i, :]
        if not np.any(row_missing):
            continue

        # Get non-missing values for this variable
        valid_values = X[i, ~row_missing]

        if len(valid_values) == 0:
            # All values missing for this variable - use zero
            replacement = 0.0
        elif method == "median":
            replacement = np.median(valid_values)
        elif method == "mean":
            replacement = np.mean(valid_values)
        elif method == "zero":
            replacement = 0.0
        else:
            raise ValueError(f"Unknown method: {method}")

        # Replace missing values
        X_filled[i, row_missing] = replacement

        # Assign large uncertainty (3x typical uncertainty for this variable)
        if len(valid_values) > 0:
            typical_sigma = np.median(sigma_filled[i, ~row_missing]) if sigma is not None else 0.3 * replacement
            sigma_filled[i, row_missing] = 3.0 * max(typical_sigma, 0.1 * replacement)
        else:
            sigma_filled[i, row_missing] = 1.0  # Default large uncertainty

    return X_filled, sigma_filled


def handle_below_detection_limit(
    X: np.ndarray,
    sigma: Optional[np.ndarray] = None,
    detection_limit: Union[np.ndarray, float] = None,
    replacement: str = "half_dl",
    verbose: bool = False,
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Handle below-detection-limit (BDL) values.

    Parameters
    ----------
    X : ndarray, shape (m, n)
        Data matrix.
    sigma : ndarray, shape (m, n), optional
        Uncertainty matrix.
    detection_limit : ndarray or float
        Detection limits. Can be:
        - shape (m,): one DL per variable
        - shape (m, n): DL for each measurement
        - float: same DL for all measurements
    replacement : {'half_dl', 'third_dl', 'zero'}, default='half_dl'
        How to replace BDL values.
    verbose : bool, default=False
        Whether to print information.

    Returns
    -------
    X_clean : ndarray, shape (m, n)
        Data with BDL values replaced.
    sigma_clean : ndarray, shape (m, n)
        Uncertainties with appropriate values for BDL.
    """
    m, n = X.shape
    X_clean = X.copy()
    if sigma is None:
        sigma_clean = np.ones_like(X) * 0.1
    else:
        sigma_clean = sigma.copy()

    # Broadcast detection_limit to shape (m, n)
    if np.isscalar(detection_limit):
        DL = np.ones((m, n)) * detection_limit
    elif detection_limit.shape == (m,):
        DL = np.tile(detection_limit[:, np.newaxis], (1, n))
    else:
        DL = detection_limit

    # Find BDL values (negative or below DL)
    bdl_mask = (X < DL) | (X < 0)
    n_bdl = np.sum(bdl_mask)

    if n_bdl == 0:
        return X_clean, sigma_clean

    if verbose:
        print(f"Below-detection-limit values: {n_bdl} ({n_bdl/(m*n)*100:.1f}%)")

    # Replace BDL values
    if replacement == "half_dl":
        X_clean[bdl_mask] = DL[bdl_mask] / 2.0
    elif replacement == "third_dl":
        X_clean[bdl_mask] = DL[bdl_mask] / 3.0
    elif replacement == "zero":
        X_clean[bdl_mask] = 0.0
    else:
        raise ValueError(f"Unknown replacement method: {replacement}")

    # Assign uncertainty: 5·DL/6 following EPA guidelines
    sigma_clean[bdl_mask] = (5.0 / 6.0) * DL[bdl_mask]

    return X_clean, sigma_clean


def estimate_uncertainty(
    X: np.ndarray,
    method: str = "auto",
    min_fraction: float = 0.1,
) -> np.ndarray:
    """
    Estimate uncertainties from data values.

    Parameters
    ----------
    X : ndarray, shape (m, n)
        Data matrix.
    method : {'auto', 'poisson', 'fraction'}, default='auto'
        Estimation method:
        - 'auto': Use Poisson for positive data, fraction otherwise
        - 'poisson': σ = √X (for count data)
        - 'fraction': σ = min_fraction * |X|
    min_fraction : float, default=0.1
        Minimum uncertainty as fraction of value.

    Returns
    -------
    sigma : ndarray, shape (m, n)
        Estimated uncertainties.
    """
    if method == "auto":
        # Use Poisson for positive data
        sigma = np.sqrt(np.maximum(X, 0))
        # For very small or negative values, use fraction
        small_mask = X < 1.0
        sigma[small_mask] = min_fraction * np.abs(X[small_mask])
    elif method == "poisson":
        sigma = np.sqrt(np.maximum(X, 0))
    elif method == "fraction":
        sigma = min_fraction * np.abs(X)
    else:
        raise ValueError(f"Unknown method: {method}")

    # Enforce minimum uncertainty
    sigma = np.maximum(sigma, min_fraction * np.abs(X))

    # Ensure no zero uncertainties
    sigma = np.maximum(sigma, 1e-10)

    return sigma


def enforce_minimum_uncertainty(
    X: np.ndarray,
    sigma: np.ndarray,
    min_fraction: float = 0.1,
) -> np.ndarray:
    """
    Enforce minimum uncertainty to prevent division by zero.

    Parameters
    ----------
    X : ndarray, shape (m, n)
        Data matrix.
    sigma : ndarray, shape (m, n)
        Uncertainty matrix.
    min_fraction : float, default=0.1
        Minimum uncertainty as fraction of value.

    Returns
    -------
    sigma_enforced : ndarray, shape (m, n)
        Uncertainties with minimum enforced.
    """
    sigma_enforced = sigma.copy()

    # Minimum based on data value
    min_sigma = min_fraction * np.abs(X)

    # Also ensure absolute minimum
    min_sigma = np.maximum(min_sigma, 1e-10)

    # Enforce
    sigma_enforced = np.maximum(sigma_enforced, min_sigma)

    return sigma_enforced


def flag_outliers(
    X: np.ndarray,
    sigma: np.ndarray,
    threshold: float = 4.0,
    method: str = "zscore",
) -> np.ndarray:
    """
    Flag potential outliers in the data.

    Parameters
    ----------
    X : ndarray, shape (m, n)
        Data matrix.
    sigma : ndarray, shape (m, n)
        Uncertainty matrix.
    threshold : float, default=4.0
        Threshold for flagging outliers.
    method : {'zscore', 'iqr'}, default='zscore'
        Outlier detection method:
        - 'zscore': Flag if |X - median| / σ > threshold
        - 'iqr': Flag if X outside [Q1 - 1.5*IQR, Q3 + 1.5*IQR]

    Returns
    -------
    outlier_mask : ndarray, shape (m, n), dtype=bool
        True for potential outliers.
    """
    m, n = X.shape
    outlier_mask = np.zeros((m, n), dtype=bool)

    if method == "zscore":
        # Z-score based on median and sigma
        for i in range(m):
            median_val = np.median(X[i, :])
            z_scores = np.abs(X[i, :] - median_val) / sigma[i, :]
            outlier_mask[i, :] = z_scores > threshold

    elif method == "iqr":
        # Interquartile range method
        for i in range(m):
            Q1 = np.percentile(X[i, :], 25)
            Q3 = np.percentile(X[i, :], 75)
            IQR = Q3 - Q1
            lower_bound = Q1 - 1.5 * IQR
            upper_bound = Q3 + 1.5 * IQR
            outlier_mask[i, :] = (X[i, :] < lower_bound) | (X[i, :] > upper_bound)

    else:
        raise ValueError(f"Unknown method: {method}")

    return outlier_mask


def check_data_quality(
    X: np.ndarray,
    sigma: np.ndarray,
    verbose: bool = True,
) -> dict:
    """
    Check data quality and provide diagnostic information.

    Parameters
    ----------
    X : ndarray, shape (m, n)
        Data matrix.
    sigma : ndarray, shape (m, n)
        Uncertainty matrix.
    verbose : bool, default=True
        Whether to print diagnostics.

    Returns
    -------
    diagnostics : dict
        Dictionary with quality metrics:
        - 'n_missing': Number of NaN values
        - 'n_negative': Number of negative values
        - 'n_zero': Number of zero values
        - 'signal_to_noise': Median S/N ratio
        - 'zero_uncertainty': Number of zero uncertainties
        - 'high_uncertainty': Fraction with σ/X > 1.0
    """
    m, n = X.shape

    diagnostics = {
        'n_missing': np.sum(np.isnan(X)),
        'n_negative': np.sum(X < 0),
        'n_zero': np.sum(X == 0),
        'signal_to_noise': np.median(X / np.maximum(sigma, 1e-10)),
        'zero_uncertainty': np.sum(sigma == 0),
        'high_uncertainty': np.sum(sigma > np.abs(X)) / (m * n),
        'min_value': np.nanmin(X),
        'max_value': np.nanmax(X),
        'min_uncertainty': np.nanmin(sigma),
        'max_uncertainty': np.nanmax(sigma),
    }

    if verbose:
        print("=" * 60)
        print("Data Quality Diagnostics")
        print("=" * 60)
        print(f"Shape: {m} variables × {n} observations")
        print(f"\nData values:")
        print(f"  Missing (NaN): {diagnostics['n_missing']}")
        print(f"  Negative: {diagnostics['n_negative']}")
        print(f"  Zero: {diagnostics['n_zero']}")
        print(f"  Range: [{diagnostics['min_value']:.3e}, {diagnostics['max_value']:.3e}]")
        print(f"\nUncertainties:")
        print(f"  Zero sigma: {diagnostics['zero_uncertainty']}")
        print(f"  High sigma (sigma > X): {diagnostics['high_uncertainty']*100:.1f}%")
        print(f"  Range: [{diagnostics['min_uncertainty']:.3e}, {diagnostics['max_uncertainty']:.3e}]")
        print(f"\nSignal-to-noise:")
        print(f"  Median S/N: {diagnostics['signal_to_noise']:.2f}")

        # Warnings
        if diagnostics['n_missing'] > 0:
            print(f"\n⚠ Warning: {diagnostics['n_missing']} missing values")
        if diagnostics['n_negative'] > 0:
            print(f"⚠ Warning: {diagnostics['n_negative']} negative values")
        if diagnostics['zero_uncertainty'] > 0:
            print(f"⚠ Warning: {diagnostics['zero_uncertainty']} zero uncertainties")
        if diagnostics['signal_to_noise'] < 3.0:
            print(f"⚠ Warning: Low S/N ratio (< 3.0)")

        print("=" * 60)

    return diagnostics
