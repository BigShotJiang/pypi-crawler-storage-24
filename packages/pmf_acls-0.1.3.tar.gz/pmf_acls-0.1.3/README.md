# PMF Monorepo

Two projects in one repo:

- **pmf_acls/** — A Python Positive Matrix Factorization solver with multiple algorithm backends and per-element uncertainty weighting. See [pmf_acls/README.md](pmf_acls/README.md).
- **nmf_compare/** — Benchmark harness comparing NMF/PMF solvers on synthetic data. See [nmf_compare/README.md](nmf_compare/README.md).

## Notes
to push to pypi:
uv run python -m build
uv run twine upload dist/*

## Layout

```
pmf_acls/          # Solver package (installable)
nmf_compare/       # Benchmarking scripts and results
scripts/           # Ad-hoc / one-off analysis scripts
examples/          # Usage examples for pmf_acls
docs/              # Literature reviews, specs, notes
reference/         # PMF2/ME2 reference binaries
```

## Running Tests

```bash
pytest pmf_acls/tests/ -v
```
