from datetime import datetime
from unittest import TestCase
from portal_facil_sdk.entities.boleto import Boleto
from portal_facil_sdk.factories.boleto_factory import criar_boleto
from .constants import DADOS_BOLETO


class BoletoTestCase(TestCase):

    def test_boleto_entity(self):

        boleto = Boleto(
            id=123,
            numero="001/2023",
            dias_atraso=5,
            valor=150.00,
            emissao="2023-10-01T10:00:00",
            vencimento_original="2023-10-10T00:00:00",
            vencimento_atualizado="2023-10-15T00:00:00",
            valor_liquido=155.50,
            situacao="Aberto"
        )

        self.assertEqual(boleto.id, 123)
        self.assertEqual(boleto.numero, "001/2023")
        self.assertEqual(boleto.dias_atraso, 5)
        self.assertEqual(boleto.valor, 150.00)
        self.assertEqual(boleto.emissao, "2023-10-01T10:00:00")
        self.assertIsInstance(boleto.vencimento_original, datetime)
        self.assertEqual(boleto.vencimento_original.day, 10)
        self.assertEqual(boleto.valor_liquido, 155.50)
        self.assertEqual(boleto.situacao, "Aberto")

    def test_criar_boleto_factory(self):
        received_data = DADOS_BOLETO
        boletos = criar_boleto(received_data)
        self.assertIsInstance(boletos, list)
        self.assertIsInstance(boletos[0], Boleto)