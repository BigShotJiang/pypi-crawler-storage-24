from datetime import datetime


class Boleto:

    def __init__(
        self, 
        id: int, 
        numero: str, 
        dias_atraso: int, 
        valor: float, 
        emissao: str, 
        vencimento_original: str, 
        vencimento_atualizado: str,
        valor_liquido: float, 
        situacao: str
    ):
        self.id = id
        self.numero = numero
        self.dias_atraso = dias_atraso
        self.valor = valor
        self.emissao = emissao
        self.vencimento_original = self._conveter_str_para_data(vencimento_original)
        self.vencimento_atualizado = self._conveter_str_para_data(vencimento_atualizado)
        self.valor_liquido = valor_liquido
        self.situacao = situacao
    
    def _conveter_str_para_data(self, data: str) -> datetime:
        return datetime.fromisoformat(data)