from typing import List
from portal_facil_sdk.entities.boleto import Boleto


def criar_boleto(data) -> List[Boleto]:
    
    if type(data) != list:
        data = [data]
    
    return [
        Boleto(
            id=dado.get('id'),
            numero=dado.get('numeroBoleto'),
            dias_atraso=dado.get('diasAtraso'),
            valor=dado.get('valor'),
            emissao=dado.get('emissao'),
            vencimento_original=dado.get('dataVencimentoOriginal'),
            vencimento_atualizado=dado.get('dataVencimentoAlterada'),
            valor_liquido=dado.get('valorLiquido'),
            situacao=dado.get('situacao')
        )
        for dado in data
    ]