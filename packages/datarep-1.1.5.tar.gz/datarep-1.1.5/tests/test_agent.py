"""Tests for the retrieval agent — integration tests against real local SQLite DBs."""

import asyncio
import json
import os
import sqlite3
import tempfile
from pathlib import Path
from unittest.mock import MagicMock, patch, AsyncMock

from datarep.db import get_connection
from datarep.agent import RetrievalAgent, _copy_db_to_temp
from datarep.credentials import CredentialStore
from datarep.recipes import RecipeStore
from datarep.registry import SourceRegistry
from datarep.sync_state import SyncStateManager


def _setup(tmp_path: Path):
    """Set up a datarep environment with a test source DB."""
    os.environ["DATAREP_HOME"] = str(tmp_path)
    os.environ["ANTHROPIC_API_KEY"] = "test-key"

    db_path = tmp_path / "datarep.db"
    conn = get_connection(db_path)
    registry = SourceRegistry(conn)
    cred_store = CredentialStore(conn, key_path=tmp_path / "test.key")
    recipe_store = RecipeStore(conn)
    sync_state = SyncStateManager(conn)

    source_db_path = tmp_path / "source.db"
    source_conn = sqlite3.connect(str(source_db_path))
    source_conn.execute("CREATE TABLE messages (id INTEGER PRIMARY KEY, text TEXT, sender TEXT, ts TEXT)")
    source_conn.execute("INSERT INTO messages VALUES (1, 'Hello', 'Alice', '2024-01-01')")
    source_conn.execute("INSERT INTO messages VALUES (2, 'Hi there', 'Bob', '2024-01-02')")
    source_conn.execute("INSERT INTO messages VALUES (3, 'Bye', 'Alice', '2024-01-03')")
    source_conn.commit()
    source_conn.close()

    registry.add("test_db", "local_db", {"path": str(source_db_path)})

    return conn, registry, cred_store, recipe_store, sync_state


def test_copy_db_to_temp(tmp_path):
    db_path = tmp_path / "test.db"
    conn = sqlite3.connect(str(db_path))
    conn.execute("CREATE TABLE t (id INTEGER)")
    conn.execute("INSERT INTO t VALUES (1)")
    conn.commit()
    conn.close()

    tmp_copy = _copy_db_to_temp(str(db_path))
    assert os.path.exists(tmp_copy)
    copy_conn = sqlite3.connect(tmp_copy)
    rows = copy_conn.execute("SELECT * FROM t").fetchall()
    assert len(rows) == 1
    copy_conn.close()
    os.unlink(tmp_copy)


def test_tool_query_source_db(tmp_path):
    conn, registry, cred_store, recipe_store, sync_state = _setup(tmp_path)

    source = registry.get("test_db")
    db_path = source["config"]["path"]

    with patch("datarep.agent.anthropic"):
        agent = RetrievalAgent.__new__(RetrievalAgent)
        agent._conn = conn
        agent._registry = registry
        agent._creds = cred_store
        agent._recipes = recipe_store
        agent._sync_state = sync_state
        agent._sessions = {}

    result = asyncio.run(agent._tool_query_source_db({
        "db_path": db_path,
        "sql": "SELECT * FROM messages WHERE sender = 'Alice'",
    }))
    assert "rows" in result
    assert len(result["rows"]) == 2
    assert result["rows"][0]["text"] == "Hello"


def test_tool_query_source_db_rejects_write(tmp_path):
    conn, registry, cred_store, recipe_store, sync_state = _setup(tmp_path)

    source = registry.get("test_db")
    db_path = source["config"]["path"]

    with patch("datarep.agent.anthropic"):
        agent = RetrievalAgent.__new__(RetrievalAgent)
        agent._conn = conn
        agent._registry = registry
        agent._creds = cred_store
        agent._recipes = recipe_store
        agent._sync_state = sync_state
        agent._sessions = {}

    result = asyncio.run(agent._tool_query_source_db({
        "db_path": db_path,
        "sql": "DELETE FROM messages",
    }))
    assert "error" in result


def test_tool_run_code(tmp_path):
    conn, registry, cred_store, recipe_store, sync_state = _setup(tmp_path)

    with patch("datarep.agent.anthropic"):
        agent = RetrievalAgent.__new__(RetrievalAgent)
        agent._conn = conn
        agent._registry = registry
        agent._creds = cred_store
        agent._recipes = recipe_store
        agent._sync_state = sync_state
        agent._sessions = {}

    result = asyncio.run(agent._tool_run_code({
        "code": "import json; print(json.dumps({'result': 'ok'}))",
    }))
    assert result["success"] is True
    assert "ok" in result["stdout"]
    assert "review" in result
    assert "verify" in result["review"].lower()


def test_run_code_no_review_on_failure(tmp_path):
    conn, registry, cred_store, recipe_store, sync_state = _setup(tmp_path)

    with patch("datarep.agent.anthropic"):
        agent = RetrievalAgent.__new__(RetrievalAgent)
        agent._conn = conn
        agent._registry = registry
        agent._creds = cred_store
        agent._recipes = recipe_store
        agent._sync_state = sync_state
        agent._sessions = {}

    result = asyncio.run(agent._tool_run_code({
        "code": "raise ValueError('intentional failure')",
    }))
    assert result["success"] is False
    assert "review" not in result


def test_run_code_no_review_on_empty_output(tmp_path):
    conn, registry, cred_store, recipe_store, sync_state = _setup(tmp_path)

    with patch("datarep.agent.anthropic"):
        agent = RetrievalAgent.__new__(RetrievalAgent)
        agent._conn = conn
        agent._registry = registry
        agent._creds = cred_store
        agent._recipes = recipe_store
        agent._sync_state = sync_state
        agent._sessions = {}

    result = asyncio.run(agent._tool_run_code({
        "code": "pass",
    }))
    assert result["success"] is True
    assert "review" not in result


def test_recipe_save_and_load(tmp_path):
    conn, registry, cred_store, recipe_store, sync_state = _setup(tmp_path)

    with patch("datarep.agent.anthropic"):
        agent = RetrievalAgent.__new__(RetrievalAgent)
        agent._conn = conn
        agent._registry = registry
        agent._creds = cred_store
        agent._recipes = recipe_store
        agent._sync_state = sync_state
        agent._sessions = {}

    asyncio.run(agent._tool_save_recipe({
        "recipe_id": "test_recipe_v1",
        "source_name": "test_db",
        "code": "print('recipe output')",
        "description": "Test recipe",
    }))

    recipe = asyncio.run(agent._tool_load_recipe({"recipe_id": "test_recipe_v1"}))
    assert recipe["code"] == "print('recipe output')"
    assert recipe["source_name"] == "test_db"


def test_run_recipe(tmp_path):
    conn, registry, cred_store, recipe_store, sync_state = _setup(tmp_path)

    with patch("datarep.agent.anthropic"):
        agent = RetrievalAgent.__new__(RetrievalAgent)
        agent._conn = conn
        agent._registry = registry
        agent._creds = cred_store
        agent._recipes = recipe_store
        agent._sync_state = sync_state
        agent._sessions = {}

    recipe_store.save("run_test", "test_db", "import json; print(json.dumps({'count': 3}))", "Runnable recipe")
    result = asyncio.run(agent.run_recipe("run_test"))
    assert result["status"] == "success"
    assert "3" in result["stdout"]


def test_initial_message_includes_version(tmp_path):
    conn, registry, cred_store, recipe_store, sync_state = _setup(tmp_path)

    with patch("datarep.agent.anthropic"):
        agent = RetrievalAgent.__new__(RetrievalAgent)
        agent._conn = conn
        agent._registry = registry
        agent._creds = cred_store
        agent._recipes = recipe_store
        agent._sync_state = sync_state
        agent._sessions = {}

    recipe_store.save("test_db_messages", "test_db", "print('v1')", "Get messages")
    recipe_store.save("test_db_messages", "test_db", "print('v2')", "Get messages v2")
    recipe_store.record_use("test_db_messages")

    messages = agent._build_initial_messages("get messages", "test_db")
    message = messages[0]["content"]

    assert "v2" in message
    assert "used 1 times" in message
    assert "don't rewrite from scratch" in message


def test_auto_share_recipe_on_save(tmp_path):
    conn, registry, cred_store, recipe_store, sync_state = _setup(tmp_path)

    with patch("datarep.agent.anthropic"):
        agent = RetrievalAgent.__new__(RetrievalAgent)
        agent._conn = conn
        agent._registry = registry
        agent._creds = cred_store
        agent._recipes = recipe_store
        agent._sync_state = sync_state
        agent._sessions = {}

    with patch("datarep.feedback.GitHubFeedback") as MockFeedback:
        mock_fb = MockFeedback.return_value
        mock_fb.share_recipe.return_value = {"success": True, "issueNumber": 1}

        asyncio.run(agent._tool_save_recipe({
            "recipe_id": "auto_share_test",
            "source_name": "test_db",
            "code": "print('hello')",
            "description": "Auto-shared recipe",
        }))

        MockFeedback.assert_called_once_with()
        mock_fb.share_recipe.assert_called_once()
        shared = mock_fb.share_recipe.call_args[0][0]
        assert shared["id"] == "auto_share_test"
        assert shared["code"] == "print('hello')"


def test_auto_share_survives_worker_failure(tmp_path):
    conn, registry, cred_store, recipe_store, sync_state = _setup(tmp_path)

    with patch("datarep.agent.anthropic"):
        agent = RetrievalAgent.__new__(RetrievalAgent)
        agent._conn = conn
        agent._registry = registry
        agent._creds = cred_store
        agent._recipes = recipe_store
        agent._sync_state = sync_state
        agent._sessions = {}

    with patch("datarep.feedback.GitHubFeedback") as MockFeedback:
        MockFeedback.return_value.share_recipe.side_effect = Exception("network error")

        result = asyncio.run(agent._tool_save_recipe({
            "recipe_id": "resilient_test",
            "source_name": "test_db",
            "code": "print('hello')",
        }))

        assert result["id"] == "resilient_test"
        assert recipe_store.get("resilient_test") is not None


def test_auto_report_failure(tmp_path):
    conn, registry, cred_store, recipe_store, sync_state = _setup(tmp_path)

    with patch("datarep.agent.anthropic"):
        agent = RetrievalAgent.__new__(RetrievalAgent)
        agent._conn = conn
        agent._registry = registry
        agent._creds = cred_store
        agent._recipes = recipe_store
        agent._sync_state = sync_state
        agent._sessions = {}

    with patch("datarep.feedback.GitHubFeedback") as MockFeedback:
        mock_fb = MockFeedback.return_value
        mock_fb.report_bug.return_value = {"success": True, "issueNumber": 2}

        agent._auto_report_failure("test_db", "Something broke", None)

        MockFeedback.assert_called_once_with()
        mock_fb.report_bug.assert_called_once()
        call_kwargs = mock_fb.report_bug.call_args[1]
        assert call_kwargs["title"] == "Extraction failed: test_db"
        assert call_kwargs["error"] == "Something broke"
