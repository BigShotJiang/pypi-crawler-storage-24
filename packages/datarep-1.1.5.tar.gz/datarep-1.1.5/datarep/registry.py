"""Source registry — what data sources exist, their types, and access info."""

from __future__ import annotations

import json
import sqlite3
from datetime import datetime, timezone
from typing import Any


class SourceRegistry:
    """Manages the registry of data sources."""

    VALID_TYPES = ("local_db", "rest_api", "local_files", "discovered")

    def __init__(self, conn: sqlite3.Connection):
        self._conn = conn

    def add(
        self,
        name: str,
        source_type: str,
        config: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        if source_type not in self.VALID_TYPES:
            raise ValueError(
                f"Invalid source_type '{source_type}'. Must be one of: {', '.join(self.VALID_TYPES)}"
            )
        config = config or {}
        now = datetime.now(timezone.utc).isoformat()
        self._conn.execute(
            "INSERT INTO sources (name, source_type, config, created_at) VALUES (?, ?, ?, ?)",
            (name, source_type, json.dumps(config), now),
        )
        self._conn.commit()
        return {"name": name, "source_type": source_type, "config": config, "created_at": now}

    def get(self, name: str) -> dict[str, Any] | None:
        row = self._conn.execute(
            "SELECT name, source_type, config, created_at FROM sources WHERE name = ?",
            (name,),
        ).fetchone()
        if row is None:
            return None
        return {
            "name": row["name"],
            "source_type": row["source_type"],
            "config": json.loads(row["config"]),
            "created_at": row["created_at"],
        }

    def list(self, names: list[str] | None = None) -> list[dict[str, Any]]:
        """List sources, optionally filtered to specific names."""
        if names is not None:
            placeholders = ",".join("?" for _ in names)
            rows = self._conn.execute(
                f"SELECT name, source_type, config, created_at FROM sources WHERE name IN ({placeholders})",
                names,
            ).fetchall()
        else:
            rows = self._conn.execute(
                "SELECT name, source_type, config, created_at FROM sources"
            ).fetchall()
        return [
            {
                "name": r["name"],
                "source_type": r["source_type"],
                "config": json.loads(r["config"]),
                "created_at": r["created_at"],
            }
            for r in rows
        ]

    def remove(self, name: str) -> bool:
        cursor = self._conn.execute("DELETE FROM sources WHERE name = ?", (name,))
        self._conn.commit()
        return cursor.rowcount > 0

    def update_config(self, name: str, config: dict[str, Any]) -> bool:
        cursor = self._conn.execute(
            "UPDATE sources SET config = ? WHERE name = ?",
            (json.dumps(config), name),
        )
        self._conn.commit()
        return cursor.rowcount > 0

    def get_allowed_domains(self, name: str) -> list[str]:
        """Extract allowed network domains from a source's config for sandbox restrictions."""
        source = self.get(name)
        if source is None:
            return []
        config = source["config"]
        domains: list[str] = []
        if source["source_type"] == "rest_api":
            base_url = config.get("base_url", "")
            if base_url:
                from urllib.parse import urlparse
                parsed = urlparse(base_url)
                if parsed.hostname:
                    domains.append(parsed.hostname)
            token_url = config.get("token_url", "")
            if token_url:
                from urllib.parse import urlparse
                parsed = urlparse(token_url)
                if parsed.hostname:
                    domains.append(parsed.hostname)
            for url in config.get("additional_domains", []):
                domains.append(url)
        return list(set(domains))
