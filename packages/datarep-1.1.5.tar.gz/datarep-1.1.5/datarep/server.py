"""FastAPI local HTTP API for datarep — the primary interface for consuming apps."""

from __future__ import annotations

import asyncio
import json
import traceback
from typing import Any

from fastapi import FastAPI, Header, HTTPException, Request, Query
from fastapi.responses import StreamingResponse, JSONResponse
from pydantic import BaseModel

from datarep.db import get_connection
from datarep.config import ensure_home
from datarep.app_auth import AppAuthManager
from datarep.agent import RetrievalAgent
from datarep.credentials import CredentialStore, OAuthFlow
from datarep.recipes import RecipeStore
from datarep.registry import SourceRegistry
from datarep.sync_state import SyncStateManager
from datarep.webhooks import handle_webhook


app = FastAPI(title="datarep", version="1.0.0")

_conn = None
_registry = None
_cred_store = None
_recipe_store = None
_sync_state = None
_app_auth = None
_agent = None


def _init():
    global _conn, _registry, _cred_store, _recipe_store, _sync_state, _app_auth, _agent
    if _conn is not None:
        return
    ensure_home()
    _conn = get_connection()
    _registry = SourceRegistry(_conn)
    _cred_store = CredentialStore(_conn)
    _recipe_store = RecipeStore(_conn)
    _sync_state = SyncStateManager(_conn)
    _app_auth = AppAuthManager(_conn)
    try:
        _agent = RetrievalAgent(
            _conn,
            registry=_registry,
            cred_store=_cred_store,
            recipe_store=_recipe_store,
            sync_state=_sync_state,
        )
    except ValueError:
        _agent = None


@app.on_event("startup")
async def startup():
    _init()


def _authenticate(authorization: str | None) -> dict[str, Any]:
    """Verify API key from Authorization header."""
    _init()
    if authorization is None:
        raise HTTPException(status_code=401, detail="Missing Authorization header.")
    parts = authorization.split(" ", 1)
    if len(parts) != 2 or parts[0].lower() != "bearer":
        raise HTTPException(status_code=401, detail="Invalid Authorization header format. Use: Bearer <api_key>")
    app_info = _app_auth.verify_key(parts[1])
    if app_info is None:
        raise HTTPException(status_code=401, detail="Invalid or revoked API key.")
    return app_info


def _check_source_access(app_info: dict, source_name: str):
    if not _app_auth.check_source_access(app_info, source_name):
        raise HTTPException(status_code=403, detail=f"App '{app_info['name']}' does not have access to source '{source_name}'.")


# --- Models ---

class GetRequest(BaseModel):
    query: str
    source: str | None = None
    stream: bool = False

class ReplyRequest(BaseModel):
    answer: str
    stream: bool = False

class SyncRequest(BaseModel):
    source: str
    query: str = ""
    stream: bool = False

class RecipeRunRequest(BaseModel):
    recipe_id: str

class SourceAddRequest(BaseModel):
    name: str
    source_type: str
    config: dict[str, Any] = {}

class CredentialStoreRequest(BaseModel):
    source: str
    cred_type: str
    data: dict[str, Any]
    expires_at: str | None = None

class OAuthInitRequest(BaseModel):
    source: str


# --- Endpoints ---

@app.get("/health")
async def health():
    return {"status": "ok", "service": "datarep", "version": "1.0.0"}


async def _run_agent_streaming(agent, query: str, source: str | None, app_id: str, method: str = "run", session_id: str | None = None, answer: str | None = None):
    """Run or resume the agent and yield SSE events in real-time."""
    queue: asyncio.Queue[dict[str, Any] | None] = asyncio.Queue()
    final_result: dict[str, Any] = {}

    async def on_event(event_type: str, data: dict[str, Any]) -> None:
        await queue.put({"event": event_type, "data": data})

    async def run_agent():
        nonlocal final_result
        try:
            if method == "resume":
                final_result = await agent.resume(session_id, answer, on_event=on_event)
            else:
                final_result = await agent.run(query, source_name=source, on_event=on_event)
        except Exception as e:
            tb = traceback.format_exc()
            final_result = {"status": "error", "error": str(e), "traceback": tb}
            await queue.put({"event": "error", "data": {"error": str(e)}})
        finally:
            await queue.put(None)

    task = asyncio.create_task(run_agent())

    async def event_generator():
        while True:
            try:
                item = await asyncio.wait_for(queue.get(), timeout=15.0)
            except asyncio.TimeoutError:
                yield ": keepalive\n\n"
                continue
            if item is None:
                yield f"event: result\ndata: {json.dumps(final_result, default=str)}\n\n"
                break
            yield f"event: {item['event']}\ndata: {json.dumps(item['data'], default=str)}\n\n"
        await task

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",
        },
    )


@app.post("/get")
async def get_data(req: GetRequest, authorization: str = Header(None)):
    app_info = _authenticate(authorization)
    if req.source:
        _check_source_access(app_info, req.source)

    if _agent is None:
        raise HTTPException(status_code=503, detail="Agent not available. Check ANTHROPIC_API_KEY.")

    _app_auth.log(app_info["app_id"], "get", req.source or "unspecified", "started")

    if req.stream:
        return await _run_agent_streaming(_agent, req.query, req.source, app_info["app_id"])

    try:
        result = await _agent.run(req.query, source_name=req.source)
    except Exception as e:
        tb = traceback.format_exc()
        _app_auth.log(app_info["app_id"], "get", req.source or "unspecified", "failed", details={"error": str(e)})
        return {"status": "error", "error": str(e), "traceback": tb}

    status = result.get("status", "error")
    _app_auth.log(app_info["app_id"], "get", req.source or "unspecified", status, details={"query": req.query})
    return result


@app.post("/sessions/{session_id}/reply")
async def reply_to_session(session_id: str, req: ReplyRequest, authorization: str = Header(None)):
    """Reply to an agent question, continuing the session."""
    app_info = _authenticate(authorization)

    if _agent is None:
        raise HTTPException(status_code=503, detail="Agent not available. Check ANTHROPIC_API_KEY.")

    _app_auth.log(app_info["app_id"], "reply", session_id, "started")

    if req.stream:
        return await _run_agent_streaming(
            _agent, "", None, app_info["app_id"],
            method="resume", session_id=session_id, answer=req.answer,
        )

    try:
        result = await _agent.resume(session_id, req.answer)
    except Exception as e:
        tb = traceback.format_exc()
        _app_auth.log(app_info["app_id"], "reply", session_id, "failed", details={"error": str(e)})
        return {"status": "error", "error": str(e), "traceback": tb}

    status = result.get("status", "error")
    _app_auth.log(app_info["app_id"], "reply", session_id, status)
    return result


@app.post("/sync")
async def sync_data(req: SyncRequest, authorization: str = Header(None)):
    app_info = _authenticate(authorization)
    _check_source_access(app_info, req.source)

    if _agent is None:
        raise HTTPException(status_code=503, detail="Agent not available. Check ANTHROPIC_API_KEY.")

    _app_auth.log(app_info["app_id"], "sync", req.source, "started")
    query = req.query or f"Incremental sync for {req.source}"

    if req.stream:
        return await _run_agent_streaming(_agent, query, req.source, app_info["app_id"])

    try:
        result = await _agent.run(query, source_name=req.source)
    except Exception as e:
        tb = traceback.format_exc()
        _app_auth.log(app_info["app_id"], "sync", req.source, "failed", details={"error": str(e)})
        return {"status": "error", "error": str(e), "traceback": tb}

    status = result.get("status", "error")
    _app_auth.log(app_info["app_id"], "sync", req.source, status)
    return result


@app.post("/recipe/run")
async def run_recipe(req: RecipeRunRequest, authorization: str = Header(None)):
    app_info = _authenticate(authorization)

    recipe = _recipe_store.get(req.recipe_id)
    if recipe is None:
        raise HTTPException(status_code=404, detail=f"Recipe '{req.recipe_id}' not found.")

    _check_source_access(app_info, recipe["source_name"])
    _app_auth.log(app_info["app_id"], "recipe_run", recipe["source_name"], "started",
                  details={"recipe_id": req.recipe_id})

    if _agent is None:
        raise HTTPException(status_code=503, detail="Agent not available. Check ANTHROPIC_API_KEY.")

    result = await _agent.run_recipe(req.recipe_id)
    status = result.get("status", "error")
    _app_auth.log(app_info["app_id"], "recipe_run", recipe["source_name"], status,
                  details={"recipe_id": req.recipe_id})
    return result


@app.get("/sources")
async def list_sources(authorization: str = Header(None)):
    app_info = _authenticate(authorization)
    allowed = app_info.get("allowed_sources")
    sources = _registry.list(names=allowed)

    for source in sources:
        state = _sync_state.get(source["name"])
        source["sync_state"] = state
    return {"sources": sources}


@app.post("/sources")
async def add_source(req: SourceAddRequest, authorization: str = Header(None)):
    app_info = _authenticate(authorization)
    try:
        source = _registry.add(req.name, req.source_type, req.config)
        _app_auth.log(app_info["app_id"], "source_add", req.name, "success")
        return source
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.delete("/sources/{name}")
async def remove_source(name: str, authorization: str = Header(None)):
    app_info = _authenticate(authorization)
    if _registry.remove(name):
        _app_auth.log(app_info["app_id"], "source_remove", name, "success")
        return {"message": f"Source '{name}' removed."}
    raise HTTPException(status_code=404, detail=f"Source '{name}' not found.")


@app.post("/auth/credentials")
async def store_credentials(req: CredentialStoreRequest, authorization: str = Header(None)):
    app_info = _authenticate(authorization)
    _cred_store.store(req.source, req.cred_type, req.data, req.expires_at)
    _app_auth.log(app_info["app_id"], "auth_store", req.source, "success")
    return {"message": f"Credentials stored for '{req.source}'."}


@app.post("/auth/oauth")
async def initiate_oauth(req: OAuthInitRequest, authorization: str = Header(None)):
    app_info = _authenticate(authorization)
    source = _registry.get(req.source)
    if source is None:
        raise HTTPException(status_code=404, detail=f"Source '{req.source}' not found.")

    config = source["config"]
    required = ["auth_url", "token_url", "client_id", "client_secret"]
    missing = [k for k in required if k not in config]
    if missing:
        raise HTTPException(status_code=400, detail=f"Source config missing: {', '.join(missing)}")

    flow = OAuthFlow(
        auth_url=config["auth_url"],
        token_url=config["token_url"],
        client_id=config["client_id"],
        client_secret=config["client_secret"],
        scopes=config.get("scopes", []),
    )
    try:
        tokens = flow.run()
        _cred_store.store(req.source, "oauth2", {
            **tokens,
            "client_id": config["client_id"],
            "client_secret": config["client_secret"],
            "token_url": config["token_url"],
        })
        _app_auth.log(app_info["app_id"], "oauth", req.source, "success")
        return {"message": f"OAuth flow completed for '{req.source}'."}
    except Exception as e:
        _app_auth.log(app_info["app_id"], "oauth", req.source, "failed", details={"error": str(e)})
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/recipes")
async def list_recipes(source: str | None = None, authorization: str = Header(None)):
    app_info = _authenticate(authorization)
    recipes = _recipe_store.list(source_name=source)
    return {"recipes": recipes}


@app.get("/recipes/{recipe_id}")
async def get_recipe(recipe_id: str, authorization: str = Header(None)):
    app_info = _authenticate(authorization)
    recipe = _recipe_store.get(recipe_id)
    if recipe is None:
        raise HTTPException(status_code=404, detail=f"Recipe '{recipe_id}' not found.")
    return recipe


@app.post("/webhooks/{source}")
async def receive_webhook(source: str, request: Request):
    body = await request.body()
    headers = dict(request.headers)
    _init()
    result = await handle_webhook(source, body, headers, _registry, _agent, _app_auth)
    return result


def create_app() -> FastAPI:
    """Factory for creating the app (useful for testing)."""
    _init()
    return app
