# -*- coding: utf-8 -*-
"""Request and response models for the AtendentePro service API."""

from __future__ import annotations

from typing import Dict, List, Optional

from pydantic import BaseModel, Field


class SetupRequest(BaseModel):
    """Payload for POST /setup — registers or updates a clinic's agent network."""

    clinic_id: str = Field(..., min_length=1)
    yamls: Dict[str, str] = Field(
        ...,
        description="Map of config name to YAML content, e.g. {'flow_config': '...', 'triage_config': '...'}",
    )


class ChatRequest(BaseModel):
    """Payload for POST /chat — sends a message to a clinic's agent network."""

    clinic_id: str = Field(..., min_length=1)
    session_id: str = Field(..., min_length=1)
    message: str = Field(..., min_length=1)
    patient_phone: Optional[str] = None


class ChatResponse(BaseModel):
    """Response from POST /chat."""

    response: str
    agent_name: Optional[str] = None
    handoff_to: Optional[str] = None


class HealthResponse(BaseModel):
    """Response from GET /health."""

    status: str = "ok"
    version: str
    clinics_loaded: List[str] = Field(default_factory=list)
