# -*- coding: utf-8 -*-
"""
Clinic manager for the AtendentePro multi-tenant service.

Handles per-clinic AgentNetwork lifecycle and per-session conversation history.
"""

from __future__ import annotations

import asyncio
import logging
import os
import tempfile
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

SESSION_TTL_SECONDS = int(os.environ.get("ATENDENTEPRO_SESSION_TTL", "3600"))
CLEANUP_INTERVAL_SECONDS = 300


@dataclass
class _Session:
    messages: List[Dict[str, str]] = field(default_factory=list)
    last_active: float = field(default_factory=time.time)


@dataclass
class _ClinicState:
    network: Any  # AgentNetwork
    sessions: Dict[str, _Session] = field(default_factory=dict)
    lock: asyncio.Lock = field(default_factory=asyncio.Lock)


class ClinicManager:
    """Manages AgentNetwork instances per clinic and conversation histories per session."""

    def __init__(self, templates_dir: Optional[Path] = None) -> None:
        self._clinics: Dict[str, _ClinicState] = {}
        self._templates_dir = templates_dir or Path(tempfile.mkdtemp(prefix="atendentepro_"))
        self._cleanup_task: Optional[asyncio.Task[None]] = None

    # ------------------------------------------------------------------
    # Setup
    # ------------------------------------------------------------------

    def setup_clinic(self, clinic_id: str, yamls: Dict[str, str]) -> None:
        """Write YAML configs to disk and create an AgentNetwork for *clinic_id*."""
        from atendentepro.network import create_standard_network
        from atendentepro.templates.manager import get_template_manager

        clinic_dir = self._templates_dir / clinic_id
        clinic_dir.mkdir(parents=True, exist_ok=True)

        for config_name, content in yamls.items():
            filename = f"{config_name}.yaml" if not config_name.endswith(".yaml") else config_name
            (clinic_dir / filename).write_text(content, encoding="utf-8")

        get_template_manager().clear_caches()

        network = create_standard_network(
            templates_root=self._templates_dir,
            client=clinic_id,
        )

        if clinic_id in self._clinics:
            self._clinics[clinic_id].network = network
        else:
            self._clinics[clinic_id] = _ClinicState(network=network)

        logger.info("Clinic %s configured (%d yamls)", clinic_id, len(yamls))

    # ------------------------------------------------------------------
    # Chat
    # ------------------------------------------------------------------

    async def chat(
        self,
        clinic_id: str,
        session_id: str,
        message: str,
        patient_phone: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Run a message through the clinic's triage agent and return the result."""
        from agents import Runner

        state = self._clinics.get(clinic_id)
        if state is None:
            raise KeyError(f"Clinic '{clinic_id}' not configured. Call POST /setup first.")

        async with state.lock:
            session = state.sessions.setdefault(session_id, _Session())
            session.last_active = time.time()

            session.messages.append({"role": "user", "content": message})

            result = await Runner.run(state.network.triage, list(session.messages))

            assistant_text = str(result.final_output) if result.final_output else ""
            session.messages.append({"role": "assistant", "content": assistant_text})

            last_agent = getattr(result, "last_agent", None)
            agent_name = getattr(last_agent, "name", None) if last_agent else None

        return {
            "response": assistant_text,
            "agent_name": agent_name,
        }

    # ------------------------------------------------------------------
    # Queries
    # ------------------------------------------------------------------

    def get_loaded_clinics(self) -> List[str]:
        return list(self._clinics.keys())

    def remove_clinic(self, clinic_id: str) -> bool:
        return self._clinics.pop(clinic_id, None) is not None

    # ------------------------------------------------------------------
    # Session cleanup
    # ------------------------------------------------------------------

    def start_cleanup_loop(self) -> None:
        if self._cleanup_task is None or self._cleanup_task.done():
            self._cleanup_task = asyncio.create_task(self._cleanup_loop())

    def stop_cleanup_loop(self) -> None:
        if self._cleanup_task and not self._cleanup_task.done():
            self._cleanup_task.cancel()

    async def _cleanup_loop(self) -> None:
        while True:
            await asyncio.sleep(CLEANUP_INTERVAL_SECONDS)
            self._purge_expired_sessions()

    def _purge_expired_sessions(self) -> None:
        now = time.time()
        purged = 0
        for state in self._clinics.values():
            expired = [
                sid
                for sid, sess in state.sessions.items()
                if now - sess.last_active > SESSION_TTL_SECONDS
            ]
            for sid in expired:
                del state.sessions[sid]
                purged += 1
        if purged:
            logger.info("Purged %d expired sessions", purged)
