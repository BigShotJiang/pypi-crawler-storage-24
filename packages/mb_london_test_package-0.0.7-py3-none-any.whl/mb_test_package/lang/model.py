## file for langgraph model + llm module

import json
from typing import TypedDict, Optional, List, Dict, Any
from mb.lang.basic import ModelFactory
from .prompts import PromptTemplate, safe_format
from langgraph.graph import START, END, StateGraph

Prompts = PromptTemplate()
CAPTION_PROMPT = Prompts.prompt_caption
VALIDATION_PROMPT = Prompts.prompt_validation
REFINEMENT_PROMPT = Prompts.prompt_refinement

class MainModel:
    def __init__(self, 
                model_type='google',
                model_name='gemini-3.0-flash',
                **kwargs):
        self.model_name = model_name
        self.model_type = model_type
        self.llm = ModelFactory(self.model_type,self.model_name, **kwargs)

    def  __repr__(self):    
        return f"MainModel(model_type={self.model_type}, model_name={self.model_name})"


class ValidationModel(ModelFactory):
    def __init__(self, 
                model_type='google',
                model_name='gemini-2.5-flash-lite',
                **kwargs):
        self.model_name = model_name
        self.model_type = model_type
        self.llm = ModelFactory(self.model_type,self.model_name, **kwargs)

    def  __repr__(self):
        return f"ValidationModel(model_type={self.model_type}, model_name={self.model_name})"   


class CaptionState(TypedDict):
    """
    State for the caption generation pipeline.
    """
    image: str
    labels: List[str]
    bboxes: List[Any]
    bboxes_labels: List[str]
    cordinates: List[Any]
    timestamp : str
    caption_prompt: str
    validation_prompt: str
    generated_caption: Optional[str]
    validation_result: Optional[str]
    is_valid: Optional[bool]
    messages: List[Dict[str, Any]]


class LangGraphModel:
    """
    Straight-line LangGraph caption agent:
    START -> load_data -> generate_caption -> validate_caption -> END

    Args:
        llm_main_model: LLM for caption generation (default: Gemini 3.0 Flash)
        llm_validation_model: LLM for caption validation (default: Gemini 2.5 Flash Lite)
        logger: Optional logger for debugging and analysis
    """
    def __init__(self, 
                llm_main_model=None,
                llm_validation_model=None,
                logger=None):
        self.llm_main_model = llm_main_model or MainModel()
        self.llm_validation_model = llm_validation_model or ValidationModel()
        self.prompt_caption = CAPTION_PROMPT
        self.prompt_validation = VALIDATION_PROMPT
        self.prompt_refinement = REFINEMENT_PROMPT
        self.logger = logger
        self.workflow = self._build_graph()

    def __repr__(self):
        return f"LangGraphModel(llm_main_model={self.llm_main_model}, llm_validation_model={self.llm_validation_model})"

    def _state_fields(self, state: CaptionState) -> dict:
        """
        Extract the metadata fields from state for prompt formatting.
        """
        return {
            "image": state.get("image"),
            "labels": state.get("labels"),
            "bboxes": state.get("bboxes"),
            "bboxes_labels": state.get("bboxes_labels"),
            "cordinates": state.get("cordinates"),
            "timestamp": state.get("timestamp"),
        }

    def node_load_data(self, state: CaptionState) -> dict:
        """
        Load and prepare caption data for the pipeline.
        """
        prompt = safe_format(state["caption_prompt"], **self._state_fields(state))
        return {
            **state,
            "caption_prompt": prompt,
            "messages": [{"role": "user", "content": prompt}]
        }

    def node_generate_caption(self, state: CaptionState) -> dict:
        """
        Generate caption using the main model.
        """
        messages = state["messages"]
        response = self.llm_main_model.llm.invoke_query(messages)
        generated = response.content if hasattr(response, 'content') else str(response)
        return {
            **state,
            "generated_caption": generated,
            "messages": state["messages"] + [{"role": "assistant", "content": generated}]
        }

    def node_validate_caption(self, state: CaptionState) -> dict:
        """
        Validate the generated caption using the validation LLM model.
        """
        validation_prompt = safe_format(
            state["validation_prompt"],
            caption=state["generated_caption"],
            **self._state_fields(state)
        )
        messages = [{"role": "user", "content": validation_prompt}]
        response = self.llm_validation_model.llm.invoke_query(messages)
        result = response.content if hasattr(response, 'content') else str(response)

        is_valid = False
        try:
            parsed = json.loads(result)
            print(f"Parsed validation result: {parsed}")
            is_valid = parsed.get("valid", parsed.get("is_valid", False))
        except (json.JSONDecodeError, AttributeError):
            is_valid = False

        return {
            **state,
            "validation_result": result,
            "is_valid": is_valid,
            "messages": state["messages"] + [
                {"role": "user", "content": validation_prompt},
                {"role": "assistant", "content": result}
            ]
        }

    def _build_graph(self) -> StateGraph:
        """
        Build the straight-line graph: data -> generate -> validate -> END
        """
        graph = StateGraph(CaptionState)

        graph.add_node("load_data", self.node_load_data)
        graph.add_node("generate_caption", self.node_generate_caption)
        graph.add_node("validate_caption", self.node_validate_caption)

        graph.add_edge(START, "load_data")
        graph.add_edge("load_data", "generate_caption")
        graph.add_edge("generate_caption", "validate_caption")
        graph.add_edge("validate_caption", END)

        return graph.compile()

    def run(self, caption_data: dict) -> dict:
        """
        Execute the caption pipeline: data -> generate -> validate -> end.

        Args:
            caption_data: Dict with CaptionState fields. Only 'labels' is required;
                all other metadata fields are optional and will show as N/A in prompts.

        Returns:
            Final CaptionState dict with generated_caption, validation_result, and is_valid.
        """
        return self.workflow.invoke({
            "image": caption_data.get("image", ""),
            "labels": caption_data.get("labels", []),
            "bboxes": caption_data.get("bboxes", []),
            "bboxes_labels": caption_data.get("bboxes_labels", []),
            "cordinates": caption_data.get("cordinates", []),
            "timestamp": caption_data.get("timestamp", ""),
            "caption_prompt": caption_data.get("caption_prompt", self.prompt_caption),
            "validation_prompt": caption_data.get("validation_prompt", self.prompt_validation),
            "generated_caption": None,
            "validation_result": None,
            "is_valid": None,
            "messages": []
        })
