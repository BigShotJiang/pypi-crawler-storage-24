## file for prompts

from dataclasses import dataclass

__all__ = ['PromptTemplate', 'safe_format']


def safe_format(template: str, **kwargs) -> str:
    """
    Format a prompt template, substituting 'N/A' for any missing keys.
    """
    class SafeDict(dict):
        def __missing__(self, key):
            return "N/A"
    return template.format_map(SafeDict(**kwargs))


@dataclass
class PromptData:
    """
    Data class to hold prompt templates for different stages of caption generation.
    """
    prompt_caption: str
    prompt_validation: str
    prompt_refinement: str

PROMPTCAPTION = """Generate a descriptive caption for an image based on the following metadata:

Image: {image}
Labels: {labels}
Bounding Boxes: {bboxes}
Bounding Box Labels: {bboxes_labels}
Coordinates: {cordinates}
Timestamp: {timestamp}

Use all available information to create a rich, descriptive caption.
If some fields show N/A, focus on the available data."""

PROMPTVALIDATION = """Validate the generated caption against the following image metadata:

Image: {image}
Labels: {labels}
Bounding Boxes: {bboxes}
Bounding Box Labels: {bboxes_labels}
Coordinates: {cordinates}
Timestamp: {timestamp}

Generated Caption: {caption}

Check if the caption accurately reflects the provided metadata.
Return JSON with keys "is_valid" (bool) and "reason" (str)."""

PROMPTREFINEMENT = """Refine the generated caption based on the following:

Feedback: {feedback}
Original Caption: {caption}

Image: {image}
Labels: {labels}
Bounding Boxes: {bboxes}
Bounding Box Labels: {bboxes_labels}
Coordinates: {cordinates}
Timestamp: {timestamp}

Produce an improved caption addressing the feedback while staying true to the metadata."""

def get_default_prompts():
    return PromptData(
        prompt_caption=PROMPTCAPTION,
        prompt_validation=PROMPTVALIDATION,
        prompt_refinement=PROMPTREFINEMENT
    )

class PromptTemplate:
    """
    Prompt DB:
    prompt_caption : Prompt template for generating captions from all available image metadata.
    prompt_validation : Prompt template for validating captions against image metadata.
    prompt_refinement : Prompt template for refining captions based on feedback and metadata.

    All prompts accept the full CaptionState fields (image, labels, bboxes, bboxes_labels,
    cordinates, timestamp) plus task-specific fields (caption, feedback).
    Missing fields are safely replaced with 'N/A' when using safe_format().
    """
    def __init__(self, prompts: PromptData = None):
        if prompts is None:
            prompts = get_default_prompts()
        self.prompt_caption = prompts.prompt_caption
        self.prompt_validation = prompts.prompt_validation
        self.prompt_refinement = prompts.prompt_refinement

    def format_caption(self, **kwargs) -> str:
        """
        Format the caption prompt with available state data.
        """
        return safe_format(self.prompt_caption, **kwargs)

    def format_validation(self, **kwargs) -> str:
        """
        Format the validation prompt with available state data.
        """
        return safe_format(self.prompt_validation, **kwargs)

    def format_refinement(self, **kwargs) -> str:
        """
        Format the refinement prompt with available state data.
        """
        return safe_format(self.prompt_refinement, **kwargs)

    def __repr__(self):
        return f"""PROMPT_TEMPLATE(prompt_caption={self.prompt_caption}, 
        prompt_validation={self.prompt_validation}, 
        prompt_refinement={self.prompt_refinement})"""