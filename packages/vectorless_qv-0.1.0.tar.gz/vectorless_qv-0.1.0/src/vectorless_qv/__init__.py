"""
Vectorless — Reasoning-based RAG for Excel financial models.

No vector databases. No chunking. Just hierarchical tree indexing
and LLM-driven reasoning, inspired by the PageIndex architecture.
"""

__version__ = "0.1.0"

from vectorless_qv.parser import parse_workbook
from vectorless_qv.indexer import build_tree, tree_to_json, get_top_level_summary
from vectorless_qv.agent import BedrockAgent
from vectorless_qv.engine import ExcelExecutionEngine

__all__ = [
    "parse_workbook",
    "build_tree",
    "tree_to_json",
    "get_top_level_summary",
    "BedrockAgent",
    "ExcelExecutionEngine",
]
