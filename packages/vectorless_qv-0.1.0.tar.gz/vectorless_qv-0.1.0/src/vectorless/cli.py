"""
main.py — CLI entrypoint for the Vectorless RAG system for Excel financial models.

Usage:
    # Index a workbook (generates tree JSON)
    python main.py index --file model.xlsx

    # Query the workbook interactively
    python main.py query --file model.xlsx

    # Ask a single question
    python main.py query --file model.xlsx --question "What drives Net Income?"
"""

import argparse
import json
import sys
from pathlib import Path

from vectorless.parser import parse_workbook
from vectorless.indexer import build_tree, tree_to_json, get_top_level_summary


def cmd_index(args):
    """Index an Excel workbook: parse → build tree → save JSON."""
    file_path = args.file
    print(f"📂 Parsing workbook: {file_path}")
    workbook_data = parse_workbook(file_path)

    print(f"   Found {len(workbook_data['sheet_names'])} sheets: {', '.join(workbook_data['sheet_names'])}")
    print(f"   Named ranges: {len(workbook_data['named_ranges'])}")

    # Build tree (without LLM summaries for indexing — use --with-llm for Bedrock summaries)
    summarizer = None
    if args.with_llm:
        summarizer = _create_bedrock_summarizer(args)

    print("🌲 Building hierarchical tree index...")
    tree = build_tree(workbook_data, summarizer=summarizer)

    # Save tree to JSON
    out_path = Path(file_path).with_suffix(".tree.json")
    out_path.write_text(tree_to_json(tree))
    print(f"✅ Tree index saved to: {out_path}")

    # Also save parsed data for query-time cell lookups
    data_path = Path(file_path).with_suffix(".parsed.json")
    data_path.write_text(json.dumps(workbook_data, indent=2, default=str))
    print(f"✅ Parsed data saved to: {data_path}")

    # Print overview
    print("\n📋 Tree Overview:")
    print(get_top_level_summary(tree))


def cmd_query(args):
    """Query an indexed workbook using the Bedrock agent."""
    file_path = args.file
    tree_path = Path(file_path).with_suffix(".tree.json")
    data_path = Path(file_path).with_suffix(".parsed.json")

    # Check if index exists
    if not tree_path.exists() or not data_path.exists():
        print("⚠️  No index found. Running indexing first...")
        index_args = argparse.Namespace(file=file_path, with_llm=False)
        cmd_index(index_args)

    print(f"📂 Loading tree index from: {tree_path}")
    tree = json.loads(tree_path.read_text())
    workbook_data = json.loads(data_path.read_text())

    # Import agent here to avoid boto3 import on index-only runs
    from vectorless.agent import BedrockAgent

    agent = BedrockAgent(
        tree=tree,
        workbook_data=workbook_data,
        excel_path=file_path,
        model_id=args.model,
        region=args.region,
    )

    if args.question:
        _ask(agent, args.question, verbose=args.verbose)
    else:
        # Interactive mode
        print("\n💬 Interactive mode. Type 'quit' to exit.\n")
        while True:
            try:
                question = input("You: ").strip()
            except (EOFError, KeyboardInterrupt):
                print("\nBye!")
                break
            if not question or question.lower() in ("quit", "exit", "q"):
                print("Bye!")
                break
            _ask(agent, question, verbose=args.verbose)


def cmd_inspect(args):
    """Inspect the tree index without querying Bedrock."""
    file_path = args.file
    tree_path = Path(file_path).with_suffix(".tree.json")

    if not tree_path.exists():
        print("⚠️  No index found. Run: python main.py index --file <your.xlsx>")
        sys.exit(1)

    tree = json.loads(tree_path.read_text())

    if args.node:
        from vectorless.indexer import get_node_detail
        print(get_node_detail(tree, args.node))
    else:
        print(get_top_level_summary(tree))


def _ask(agent, question: str, verbose: bool = False):
    """Ask the agent a question and print the result."""
    print(f"\n🔍 Processing: {question}\n")
    result = agent.query(question)

    print("=" * 60)
    print("📝 Answer:")
    print(result["answer"])

    if result.get("citations"):
        print("\n📎 Citations:")
        for c in result["citations"]:
            parts = [f"  Sheet: {c.get('sheet', '?')}"]
            if c.get("cell"):
                parts.append(f"Cell: {c['cell']}")
            if c.get("formula"):
                parts.append(f"Formula: {c['formula']}")
            print(", ".join(parts))

    if verbose and result.get("reasoning_trace"):
        print("\n🧠 Reasoning Trace:")
        for step in result["reasoning_trace"]:
            print(f"  {step[:200]}...")
    print("=" * 60 + "\n")


def _create_bedrock_summarizer(args):
    """Create a summarizer function backed by AWS Bedrock."""
    import boto3
    client = boto3.client("bedrock-runtime",
                          region_name=getattr(args, "region", None) or "us-east-1")
    model_id = getattr(args, "model", None) or "anthropic.claude-3-5-sonnet-20241022-v2:0"

    def summarize(prompt: str) -> str:
        body = {
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": 200,
            "messages": [{"role": "user", "content": prompt}],
        }
        response = client.invoke_model(
            modelId=model_id,
            body=json.dumps(body),
            contentType="application/json",
            accept="application/json",
        )
        result = json.loads(response["body"].read())
        return result["content"][0]["text"]

    return summarize


def main():
    parser = argparse.ArgumentParser(
        description="Vectorless RAG for Excel Financial Models (PageIndex Architecture)"
    )
    sub = parser.add_subparsers(dest="command", required=True)

    # index command
    p_index = sub.add_parser("index", help="Index an Excel workbook into a tree")
    p_index.add_argument("--file", "-f", required=True, help="Path to .xlsx file")
    p_index.add_argument("--with-llm", action="store_true",
                         help="Use Bedrock LLM to generate node summaries")
    p_index.add_argument("--model", default=None, help="Bedrock model ID")
    p_index.add_argument("--region", default=None, help="AWS region")

    # query command
    p_query = sub.add_parser("query", help="Query a workbook using the reasoning agent")
    p_query.add_argument("--file", "-f", required=True, help="Path to .xlsx file")
    p_query.add_argument("--question", "-q", default=None, help="Single question (or interactive)")
    p_query.add_argument("--model", default=None, help="Bedrock model ID")
    p_query.add_argument("--region", default=None, help="AWS region")
    p_query.add_argument("--verbose", "-v", action="store_true", help="Show reasoning trace")

    # inspect command
    p_inspect = sub.add_parser("inspect", help="Inspect the tree index without LLM")
    p_inspect.add_argument("--file", "-f", required=True, help="Path to .xlsx file")
    p_inspect.add_argument("--node", "-n", default=None, help="Node ID to inspect")

    args = parser.parse_args()

    if args.command == "index":
        cmd_index(args)
    elif args.command == "query":
        cmd_query(args)
    elif args.command == "inspect":
        cmd_inspect(args)


if __name__ == "__main__":
    main()
