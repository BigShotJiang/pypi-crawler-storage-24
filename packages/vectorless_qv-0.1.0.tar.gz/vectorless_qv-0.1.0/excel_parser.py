"""
excel_parser.py — Extracts sheets, tables, formulas, values, and named ranges from .xlsx files.

Uses openpyxl (two-pass: formulas + cached values) and pandas (table boundary detection).
"""

import re
from pathlib import Path
from typing import Any

import openpyxl
import pandas as pd


def parse_workbook(file_path: str) -> dict:
    """
    Parse an Excel workbook and return a structured dictionary containing
    all sheets, their cells (values + formulas), merged ranges, and named ranges.
    """
    path = Path(file_path)
    if not path.exists():
        raise FileNotFoundError(f"File not found: {file_path}")

    # Pass 1: formulas
    wb_formulas = openpyxl.load_workbook(path, data_only=False)
    # Pass 2: cached/computed values
    wb_values = openpyxl.load_workbook(path, data_only=True)

    workbook_data = {
        "file_name": path.name,
        "file_path": str(path.resolve()),
        "sheet_names": wb_formulas.sheetnames,
        "named_ranges": _extract_named_ranges(wb_formulas),
        "sheets": {},
    }

    for sheet_name in wb_formulas.sheetnames:
        ws_formula = wb_formulas[sheet_name]
        ws_value = wb_values[sheet_name]
        workbook_data["sheets"][sheet_name] = _parse_sheet(ws_formula, ws_value)

    wb_formulas.close()
    wb_values.close()

    return workbook_data


def _extract_named_ranges(wb: openpyxl.Workbook) -> list[dict]:
    """Extract workbook-level named ranges, filtering out IQ_/CIQ_ Capital IQ noise."""
    named = []
    # openpyxl >=3.1 uses .definedName list; handle both old and new API
    try:
        dn_list = list(wb.defined_names.definedName)
    except AttributeError:
        dn_list = list(wb.defined_names.values())

    for dn in dn_list:
        name = dn.name if hasattr(dn, "name") else str(dn)
        # Skip auto-generated / noise names: Capital IQ, Excel internals, etc.
        if (name.startswith("IQ_") or name.startswith("CIQ_")
                or name.startswith("_xlnm") or name.startswith("\\")
                or "xlfn." in name or name.startswith("_")):
            continue
        destinations = []
        try:
            for sheet_title, cell_ref in dn.destinations:
                destinations.append({"sheet": sheet_title, "range": cell_ref})
        except Exception:
            pass
        attr_text = getattr(dn, "attr_text", getattr(dn, "value", str(dn)))
        entry = {
            "name": name,
            "value": attr_text,
            "destinations": destinations,
        }
        # Only keep named ranges that resolve to actual sheet cell references
        if destinations:
            named.append(entry)
    return named


def _parse_sheet(ws_formula, ws_value) -> dict:
    """Parse a single sheet, extracting cell data, merged regions, and table boundaries."""
    sheet_data: dict[str, Any] = {
        "dimensions": ws_formula.dimensions,
        "max_row": ws_formula.max_row,
        "max_col": ws_formula.max_column,
        "merged_ranges": [str(r) for r in ws_formula.merged_cells.ranges],
        "cells": {},
        "tables": [],
    }

    for row in ws_formula.iter_rows(min_row=1, max_row=ws_formula.max_row,
                                     min_col=1, max_col=ws_formula.max_column):
        for cell in row:
            if cell.value is None:
                continue

            coord = cell.coordinate
            val_cell = ws_value[coord]

            cell_info: dict[str, Any] = {
                "coordinate": coord,
                "row": cell.row,
                "col": cell.column,
            }

            # Determine if the cell contains a formula
            raw = cell.value
            if isinstance(raw, str) and raw.startswith("="):
                cell_info["formula"] = raw
                cell_info["cached_value"] = val_cell.value
                cell_info["dependencies"] = _extract_references(raw)
            else:
                cell_info["value"] = raw

            cell_info["number_format"] = cell.number_format
            sheet_data["cells"][coord] = cell_info

    # Detect table-like blocks using pandas
    sheet_data["tables"] = _detect_tables(ws_value)

    return sheet_data


# Pattern to find cell/range references like A1, Sheet2!B4, B2:B10
_REF_PATTERN = re.compile(
    r"(?:(?:'?([^'!]+)'?|([A-Za-z_]\w*))!)?"   # optional sheet prefix
    r"(\$?[A-Z]{1,3}\$?\d+)"                     # cell ref like B4
    r"(?::(\$?[A-Z]{1,3}\$?\d+))?"               # optional range end like :B10
)


def _col_letter(col_num: int) -> str:
    """Convert a 1-based column number to Excel column letters (1=A, 27=AA, etc.)."""
    result = ""
    while col_num > 0:
        col_num, rem = divmod(col_num - 1, 26)
        result = chr(65 + rem) + result
    return result or "A"


def _extract_references(formula: str) -> list[str]:
    """Extract cell/range references from a formula string."""
    refs = []
    for match in _REF_PATTERN.finditer(formula):
        sheet_part = match.group(1) or match.group(2) or ""
        start_cell = match.group(3)
        end_cell = match.group(4)

        if sheet_part:
            ref = f"{sheet_part}!{start_cell}"
            if end_cell:
                ref += f":{end_cell}"
        else:
            ref = start_cell
            if end_cell:
                ref += f":{end_cell}"
        refs.append(ref)
    return refs


def _detect_tables(ws_value) -> list[dict]:
    """
    Detect contiguous table-like blocks in a sheet.
    Returns list of dicts with header_row, start_row, end_row, columns.
    """
    tables = []
    try:
        data = []
        for row in ws_value.iter_rows(min_row=1, max_row=ws_value.max_row,
                                       min_col=1, max_col=ws_value.max_column,
                                       values_only=False):
            data.append(row)

        if not data:
            return tables

        # Simple heuristic: find rows where most cells are populated strings (headers)
        # followed by rows of numeric/mixed data
        for i, row in enumerate(data):
            values = [c.value for c in row]
            non_none = [v for v in values if v is not None]
            str_count = sum(1 for v in non_none if isinstance(v, str))

            # If >=2 string cells and >50% strings, consider it a header row
            if len(non_none) >= 2 and str_count / max(len(non_none), 1) > 0.5:
                # Find how far the table extends below
                end_row = i + 1
                for j in range(i + 1, len(data)):
                    row_vals = [c.value for c in data[j]]
                    if all(v is None for v in row_vals):
                        break
                    end_row = j + 1

                if end_row > i + 1:  # at least 1 data row
                    headers = [str(v) if v else f"Col{idx+1}"
                               for idx, v in enumerate(values)]
                    tables.append({
                        "header_row": i + 1,
                        "start_row": i + 2,
                        "end_row": end_row,
                        "columns": headers,
                        "cell_range": f"A{i+1}:{_col_letter(len(values))}{end_row}",
                    })

    except Exception:
        pass  # Graceful fallback if detection fails

    return tables
