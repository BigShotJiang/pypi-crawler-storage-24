"""
bedrock_agent.py — AWS Bedrock LLM integration and reasoning-based tree search loop.

Implements the PageIndex-style agentic retrieval: the LLM reads the tree index,
decides which branch to drill into, traces formula chains, and synthesizes answers.
"""

import json
import os
from typing import Any

import boto3

from tree_indexer import get_top_level_summary, get_node_detail, get_node_by_id
from execution_engine import ExcelExecutionEngine

# Default Bedrock model — Claude Sonnet 4.6 via cross-region inference profile
DEFAULT_MODEL_ID = "global.anthropic.claude-sonnet-4-6"
MAX_ITERATIONS = 15

SYSTEM_PROMPT = """\
You are a senior financial analyst agent. You have access to a hierarchical tree \
index of an Excel workbook — structured like a table of contents. Your job is to \
answer user questions by REASONING through this index step by step, exactly like \
a human analyst would navigate a complex spreadsheet.

## How you work
1. You receive the top-level tree overview (sheets and their summaries).
2. You decide which branch to drill into by issuing a TOOL CALL.
3. You inspect the details of that node (its formulas, values, child nodes).
4. You follow formula dependencies across sheets if needed.
5. Once you have enough information, you synthesize a traceable answer.

## Available tool calls (respond with JSON)
You may issue MULTIPLE tool calls in a single response to gather data in parallel.
Return them as a JSON array: [{"action": ...}, {"action": ...}]
Or a single tool call as a plain object: {"action": ...}

- {"action": "drill_down", "node_id": "<id>"} — Inspect a node in detail.
- {"action": "get_cells", "sheet": "<name>", "cells": ["A1","B2"]} — Get raw cell values/formulas.
- {"action": "get_row", "sheet": "<name>", "row": 11} — Get ALL non-empty cells in a full row.
- {"action": "search_rows", "sheet": "<name>", "keyword": "total"} — Find rows whose label (col A or B) contains the keyword. Returns matching row numbers and labels. Use this to locate summary/total rows instead of scanning one row at a time.
- {"action": "what_if", "overrides": {"'Sheet'!Cell": value}, "observe": ["'Sheet'!Cell"]} — Run a what-if scenario.
- {"action": "answer", "response": "<your final answer>", "citations": [{"sheet": "...", "cell": "...", "formula": "..."}]} — Final answer with citations.

## Rules
- ALWAYS trace formulas to their source before answering.
- ALWAYS cite exact sheet names, cell coordinates, and formulas.
- If a formula references another sheet, follow it.
- Never guess numeric values — use the actual data from the index.
- Keep your reasoning visible in your thoughts before each tool call.
- Be EFFICIENT: use get_row to fetch an entire row at once instead of guessing individual cells.
- Use search_rows to find summary/total rows by keyword instead of scanning rows one by one.
- Issue MULTIPLE tool calls in one response to gather data from different sheets in parallel.
- For multi-sheet questions, plan ahead — gather data from ALL relevant sheets in your first few moves.
- The tree overview includes column_headers and row_labels for each sheet. USE THEM to know which columns/rows hold which data — do NOT waste iterations discovering headers manually.
"""


class BedrockAgent:
    """Reasoning-based agent that navigates the tree index via AWS Bedrock."""

    def __init__(self, tree: dict, workbook_data: dict,
                 excel_path: str, model_id: str | None = None,
                 region: str | None = None):
        self.tree = tree
        self.workbook_data = workbook_data
        self.model_id = model_id or DEFAULT_MODEL_ID
        self.region = region or os.environ.get("AWS_DEFAULT_REGION", "us-east-1")
        self.execution_engine = ExcelExecutionEngine(excel_path)

        self.client = boto3.client(
            "bedrock-runtime",
            region_name=self.region,
        )

    def query(self, user_question: str) -> dict:
        """
        Run the full agentic retrieval loop for a user question.

        Returns dict with 'answer', 'citations', and 'reasoning_trace'.
        """
        messages = []
        reasoning_trace = []

        # Step 1: Provide the top-level tree overview
        tree_overview = get_top_level_summary(self.tree)
        initial_context = (
            f"## Workbook Tree Index\n{tree_overview}\n\n"
            f"## User Question\n{user_question}\n\n"
            "Think step by step about which part of the workbook to investigate. "
            "Then issue a tool call."
        )
        messages.append({"role": "user", "content": initial_context})

        for iteration in range(MAX_ITERATIONS):
            response_text = self._invoke_llm(messages)
            reasoning_trace.append(f"[Iteration {iteration + 1}] LLM: {response_text}")

            # Parse tool calls — may be one or many
            tool_calls = self._extract_tool_calls(response_text)
            if not tool_calls:
                # No parseable tool call — treat as final answer
                return {
                    "answer": response_text,
                    "citations": [],
                    "reasoning_trace": reasoning_trace,
                }

            # Check if any is an "answer" action
            for tc in tool_calls:
                if tc.get("action") == "answer":
                    return {
                        "answer": tc.get("response", response_text),
                        "citations": tc.get("citations", []),
                        "reasoning_trace": reasoning_trace,
                    }

            # Execute ALL tool calls and collect results
            all_results = []
            for tc in tool_calls:
                tool_result = self._execute_tool(tc)
                result_summary = tool_result[:500]
                reasoning_trace.append(f"  [Tool: {tc.get('action')}] {result_summary}")
                all_results.append(f"### Tool: {tc.get('action')} {json.dumps({k:v for k,v in tc.items() if k != 'action'})}\n{tool_result}")

            combined_result = "\n\n".join(all_results)

            messages.append({"role": "assistant", "content": response_text})
            messages.append({
                "role": "user",
                "content": f"## Tool Results ({len(all_results)} calls)\n{combined_result}\n\n"
                           "Continue your analysis. Issue more tool calls or provide your final answer."
            })

        # Max iterations reached
        return {
            "answer": "Reached maximum reasoning depth. Partial analysis in trace.",
            "citations": [],
            "reasoning_trace": reasoning_trace,
        }

    def _invoke_llm(self, messages: list[dict]) -> str:
        """Call AWS Bedrock with the conversation so far."""
        body = {
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": 4096,
            "system": SYSTEM_PROMPT,
            "messages": messages,
        }
        response = self.client.invoke_model(
            modelId=self.model_id,
            body=json.dumps(body),
            contentType="application/json",
            accept="application/json",
        )
        result = json.loads(response["body"].read())
        return result["content"][0]["text"]

    def _extract_tool_calls(self, text: str) -> list[dict]:
        """Extract one or more JSON tool calls from the LLM's response text."""
        import re
        results = []

        # Try to find ```json ... ``` blocks first
        json_blocks = re.findall(r'```(?:json)?\s*(\[.*?\]|\{.*?\})\s*```', text, re.DOTALL)
        for block in json_blocks:
            try:
                parsed = json.loads(block)
                if isinstance(parsed, list):
                    results.extend(p for p in parsed if isinstance(p, dict) and "action" in p)
                    if results:
                        return results
                elif isinstance(parsed, dict) and "action" in parsed:
                    results.append(parsed)
                    return results
            except json.JSONDecodeError:
                continue

        # Try to find a bare JSON array with action objects
        array_matches = re.findall(r'\[[\s\S]*?\{[^{}]*"action"[^{}]*\}[\s\S]*?\]', text)
        for arr_str in array_matches:
            try:
                parsed = json.loads(arr_str)
                if isinstance(parsed, list):
                    items = [p for p in parsed if isinstance(p, dict) and "action" in p]
                    if items:
                        return items
            except json.JSONDecodeError:
                continue

        # Try to find bare JSON objects with "action" key
        json_objects = re.findall(r'\{[^{}]*"action"[^{}]*\}', text, re.DOTALL)
        for obj_str in json_objects:
            try:
                parsed = json.loads(obj_str)
                if "action" in parsed:
                    results.append(parsed)
            except json.JSONDecodeError:
                continue

        return results

    def _execute_tool(self, tool_call: dict) -> str:
        """Execute a tool call and return the result as text."""
        action = tool_call.get("action")

        if action == "drill_down":
            node_id = tool_call.get("node_id", "")
            detail = get_node_detail(self.tree, node_id)
            return detail

        elif action == "get_cells":
            sheet = tool_call.get("sheet", "")
            cells = tool_call.get("cells", [])
            return self._get_cell_data(sheet, cells)

        elif action == "get_row":
            sheet = tool_call.get("sheet", "")
            row_num = tool_call.get("row", 1)
            return self._get_row_data(sheet, row_num)

        elif action == "search_rows":
            sheet = tool_call.get("sheet", "")
            keyword = tool_call.get("keyword", "")
            return self._search_rows(sheet, keyword)

        elif action == "what_if":
            overrides = tool_call.get("overrides", {})
            observe = tool_call.get("observe", [])
            try:
                result = self.execution_engine.what_if(overrides, observe or None)
                return json.dumps(result, default=str, indent=2)
            except Exception as e:
                return f"What-If execution error: {e}"

        return f"Unknown action: {action}"

    def _get_cell_data(self, sheet_name: str, cell_refs: list[str]) -> str:
        """Retrieve raw cell data from the parsed workbook."""
        if sheet_name not in self.workbook_data["sheets"]:
            return f"Sheet '{sheet_name}' not found. Available: {', '.join(self.workbook_data['sheet_names'])}"

        cells = self.workbook_data["sheets"][sheet_name]["cells"]
        lines = [f"Cell data from sheet '{sheet_name}':"]
        for ref in cell_refs:
            ref_upper = ref.upper()
            if ref_upper in cells:
                info = cells[ref_upper]
                if "formula" in info:
                    lines.append(
                        f"  {ref_upper}: formula={info['formula']}, "
                        f"cached_value={info.get('cached_value', 'N/A')}, "
                        f"deps={info.get('dependencies', [])}"
                    )
                else:
                    lines.append(f"  {ref_upper}: value={info.get('value', 'N/A')}")
            else:
                lines.append(f"  {ref_upper}: (empty)")
        return "\n".join(lines)

    def _get_row_data(self, sheet_name: str, row_num: int) -> str:
        """Retrieve all non-empty cells in a given row."""
        if sheet_name not in self.workbook_data["sheets"]:
            return f"Sheet '{sheet_name}' not found. Available: {', '.join(self.workbook_data['sheet_names'])}"

        cells = self.workbook_data["sheets"][sheet_name]["cells"]
        row_cells = {k: v for k, v in cells.items() if v["row"] == row_num}
        if not row_cells:
            return f"Row {row_num} in '{sheet_name}' is empty."

        # Sort by column number
        sorted_cells = sorted(row_cells.items(), key=lambda x: x[1]["col"])
        lines = [f"Row {row_num} in '{sheet_name}' ({len(sorted_cells)} cells):"]
        for coord, info in sorted_cells:
            if "formula" in info:
                lines.append(f"  {coord}: formula={info['formula']}, cached_value={info.get('cached_value', 'N/A')}")
            else:
                lines.append(f"  {coord}: value={info.get('value', 'N/A')}")
        return "\n".join(lines)

    def _search_rows(self, sheet_name: str, keyword: str) -> str:
        """Find rows whose label (col A or B) contains the keyword (case-insensitive)."""
        if sheet_name not in self.workbook_data["sheets"]:
            return f"Sheet '{sheet_name}' not found. Available: {', '.join(self.workbook_data['sheet_names'])}"

        cells = self.workbook_data["sheets"][sheet_name]["cells"]
        keyword_lower = keyword.lower()

        # Build row -> label mapping from columns A and B
        row_labels: dict[int, str] = {}
        for coord, info in cells.items():
            if info["col"] <= 2 and "value" in info and isinstance(info["value"], str):
                row_num = info["row"]
                if row_num not in row_labels:
                    row_labels[row_num] = info["value"].strip()

        matches = []
        for row_num in sorted(row_labels.keys()):
            label = row_labels[row_num]
            if keyword_lower in label.lower():
                matches.append(f"  Row {row_num}: {label}")

        if not matches:
            return f"No rows matching '{keyword}' in '{sheet_name}'."
        return f"Rows matching '{keyword}' in '{sheet_name}' ({len(matches)} matches):\n" + "\n".join(matches)