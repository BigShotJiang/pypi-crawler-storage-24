"""
tree_indexer.py — Builds the hierarchical JSON tree index from parsed Excel data.

Generates LLM-friendly node summaries via AWS Bedrock during indexing.
This is the "Table of Contents" tree that the agent will navigate at query time.
"""

import json
from typing import Any

from excel_parser import parse_workbook


def build_tree(workbook_data: dict, summarizer=None) -> dict:
    """
    Build the PageIndex-style hierarchical tree from parsed workbook data.

    Args:
        workbook_data: Output of excel_parser.parse_workbook()
        summarizer: Optional callable(text) -> str that generates a summary.
                    If None, summaries are built from raw metadata only.
    """
    root = {
        "node_id": "root",
        "title": workbook_data["file_name"],
        "type": "workbook",
        "summary": "",
        "sheet_count": len(workbook_data["sheet_names"]),
        "named_ranges": workbook_data["named_ranges"],
        "nodes": [],
    }

    for idx, sheet_name in enumerate(workbook_data["sheet_names"]):
        sheet_data = workbook_data["sheets"][sheet_name]
        sheet_node = _build_sheet_node(
            sheet_name, sheet_data, node_id_prefix=f"s{idx}",
            summarizer=summarizer,
        )
        root["nodes"].append(sheet_node)

    # Generate root-level summary
    sheet_summaries = [n["title"] + ": " + n["summary"] for n in root["nodes"]]
    root_context = (
        f"Workbook '{root['title']}' contains {root['sheet_count']} sheets: "
        + "; ".join(sheet_summaries)
    )
    root["summary"] = _summarize(root_context, summarizer,
                                  fallback=f"Workbook with {root['sheet_count']} sheets: "
                                  + ", ".join(workbook_data["sheet_names"]))
    return root


def _build_sheet_node(sheet_name: str, sheet_data: dict,
                      node_id_prefix: str, summarizer) -> dict:
    """Build a tree node for a single sheet."""
    cells = sheet_data["cells"]
    tables = sheet_data["tables"]

    # Collect key formulas in this sheet
    formula_cells = {k: v for k, v in cells.items() if "formula" in v}
    key_formulas = _get_key_formulas(formula_cells, limit=10)

    # Collect cross-sheet dependencies
    cross_deps = set()
    for cell_info in formula_cells.values():
        for dep in cell_info.get("dependencies", []):
            if "!" in dep:
                cross_deps.add(dep.split("!")[0])

    # Extract column & row headers to save LLM iterations
    header_info = _extract_headers(cells, sheet_data)

    sheet_node: dict[str, Any] = {
        "node_id": node_id_prefix,
        "title": sheet_name,
        "type": "sheet",
        "location": f"Sheet: {sheet_name}",
        "dimensions": sheet_data["dimensions"],
        "cell_count": len(cells),
        "formula_count": len(formula_cells),
        "cross_sheet_deps": sorted(cross_deps),
        "key_formulas": key_formulas,
        "column_headers": header_info["column_headers"],
        "row_labels": header_info["row_labels"],
        "summary": "",
        "nodes": [],
    }

    # Build child nodes for detected tables
    for t_idx, table in enumerate(tables):
        table_node = _build_table_node(
            table, cells, sheet_name,
            node_id_prefix=f"{node_id_prefix}_t{t_idx}",
            summarizer=summarizer,
        )
        sheet_node["nodes"].append(table_node)

    # Build child nodes for "loose" formula cells not in any table
    table_rows = set()
    for table in tables:
        for r in range(table["header_row"], table["end_row"] + 1):
            table_rows.add(r)

    loose_formulas = {
        k: v for k, v in formula_cells.items()
        if v["row"] not in table_rows
    }
    if loose_formulas:
        loose_node = _build_loose_formulas_node(
            loose_formulas, sheet_name,
            node_id_prefix=f"{node_id_prefix}_f",
            summarizer=summarizer,
        )
        sheet_node["nodes"].append(loose_node)

    # Generate sheet summary
    context = _sheet_context_text(sheet_name, sheet_data, key_formulas, cross_deps)
    sheet_node["summary"] = _summarize(
        context, summarizer,
        fallback=f"{len(cells)} cells, {len(formula_cells)} formulas. "
                 + (f"Depends on: {', '.join(sorted(cross_deps))}. " if cross_deps else "")
                 + (f"Tables: {len(tables)}." if tables else "No tables detected.")
    )

    return sheet_node


def _build_table_node(table: dict, cells: dict, sheet_name: str,
                      node_id_prefix: str, summarizer) -> dict:
    """Build a tree node for a detected table block."""
    # Gather cells within the table range
    table_cells = {}
    table_formulas = []
    for coord, info in cells.items():
        if table["header_row"] <= info["row"] <= table["end_row"]:
            table_cells[coord] = info
            if "formula" in info:
                table_formulas.append(f"{coord}: {info['formula']}")

    node = {
        "node_id": node_id_prefix,
        "title": f"Table ({', '.join(table['columns'][:5])}{'...' if len(table['columns']) > 5 else ''})",
        "type": "table",
        "location": f"Sheet: {sheet_name}, Rows {table['header_row']}-{table['end_row']}",
        "cell_range": table.get("cell_range", ""),
        "columns": table["columns"],
        "row_count": table["end_row"] - table["header_row"],
        "formula_count": len(table_formulas),
        "key_formulas": table_formulas[:8],
        "summary": "",
        "nodes": [],
    }

    context = (
        f"Table in sheet '{sheet_name}', rows {table['header_row']}-{table['end_row']}. "
        f"Columns: {', '.join(table['columns'])}. "
        f"Contains {len(table_formulas)} formulas. "
        + (f"Sample formulas: {'; '.join(table_formulas[:3])}" if table_formulas else "")
    )
    node["summary"] = _summarize(context, summarizer,
                                  fallback=f"Table with columns: {', '.join(table['columns'][:5])}. "
                                  f"{len(table_formulas)} formulas.")
    return node


def _build_loose_formulas_node(formulas: dict, sheet_name: str,
                               node_id_prefix: str, summarizer) -> dict:
    """Build a node for formula cells not part of any detected table."""
    sample = [f"{k}: {v['formula']}" for k, v in list(formulas.items())[:8]]
    node = {
        "node_id": node_id_prefix,
        "title": "Standalone Formulas",
        "type": "range",
        "location": f"Sheet: {sheet_name}",
        "formula_count": len(formulas),
        "key_formulas": sample,
        "summary": "",
        "nodes": [],
    }
    context = (
        f"{len(formulas)} standalone formula cells in '{sheet_name}'. "
        f"Sample: {'; '.join(sample[:3])}"
    )
    node["summary"] = _summarize(context, summarizer,
                                  fallback=f"{len(formulas)} standalone formulas.")
    return node


def _extract_headers(cells: dict, sheet_data: dict) -> dict:
    """Extract column headers and row labels from the first few rows/cols.

    This gives the LLM structural context (e.g., 'C=FY22, D=FY23') so it
    doesn't need to spend iterations probing for header rows.
    """
    max_col = sheet_data.get("max_col", 0)
    max_row = sheet_data.get("max_row", 0)

    # Scan first 10 rows to find the best "header row" (row with most text values)
    best_row, best_count = 1, 0
    for r in range(1, min(11, max_row + 1)):
        count = 0
        for c in range(1, min(max_col + 1, 60)):
            coord = f"{_col_letter_idx(c)}{r}"
            info = cells.get(coord)
            if info and "value" in info and isinstance(info["value"], str) and info["value"].strip():
                count += 1
        if count > best_count:
            best_count = count
            best_row = r

    # Collect column headers from the best row
    col_headers = {}
    for c in range(1, min(max_col + 1, 60)):
        coord = f"{_col_letter_idx(c)}{best_row}"
        info = cells.get(coord)
        if info:
            val = info.get("value", info.get("cached_value"))
            if val is not None and str(val).strip():
                col_headers[_col_letter_idx(c)] = str(val).strip()

    # Collect row labels from column A and B (first 70 rows)
    row_labels = {}
    for r in range(1, min(71, max_row + 1)):
        for col_letter in ("A", "B"):
            coord = f"{col_letter}{r}"
            info = cells.get(coord)
            if info and "value" in info and isinstance(info["value"], str) and info["value"].strip():
                row_labels[str(r)] = info["value"].strip()
                break

    return {"column_headers": col_headers, "row_labels": row_labels}


def _col_letter_idx(col_num: int) -> str:
    """Convert 1-based column number to Excel letters (1=A, 27=AA)."""
    result = ""
    while col_num > 0:
        col_num, rem = divmod(col_num - 1, 26)
        result = chr(65 + rem) + result
    return result or "A"


def _get_key_formulas(formula_cells: dict, limit: int = 10) -> list[str]:
    """Pick the most 'interesting' formulas (those referencing other sheets first)."""
    cross_sheet = []
    local = []
    for coord, info in formula_cells.items():
        entry = f"{coord}: {info['formula']}"
        if any("!" in d for d in info.get("dependencies", [])):
            cross_sheet.append(entry)
        else:
            local.append(entry)
    return (cross_sheet + local)[:limit]


def _sheet_context_text(sheet_name, sheet_data, key_formulas, cross_deps) -> str:
    """Build context text for LLM summarization of a sheet."""
    parts = [
        f"Sheet '{sheet_name}' with dimensions {sheet_data['dimensions']}.",
        f"Contains {len(sheet_data['cells'])} cells, of which "
        f"{sum(1 for c in sheet_data['cells'].values() if 'formula' in c)} are formulas.",
    ]
    if cross_deps:
        parts.append(f"References other sheets: {', '.join(sorted(cross_deps))}.")
    if sheet_data["tables"]:
        parts.append(f"Contains {len(sheet_data['tables'])} detected table(s).")
    if key_formulas:
        parts.append(f"Key formulas: {'; '.join(key_formulas[:5])}")
    return " ".join(parts)


def _summarize(context: str, summarizer, fallback: str) -> str:
    """Generate a summary using the LLM summarizer, or fall back to raw text."""
    if summarizer:
        try:
            prompt = (
                "You are a financial analyst. Summarize the following Excel section "
                "in 1-2 concise sentences. Focus on what financial purpose it serves, "
                "what its key inputs/outputs are, and any important formulas.\n\n"
                f"{context}"
            )
            return summarizer(prompt)
        except Exception:
            return fallback
    return fallback


# ── Serialization helpers ──

def tree_to_json(tree: dict, indent: int = 2) -> str:
    """Serialize the tree to a pretty JSON string."""
    return json.dumps(tree, indent=indent, default=str)


def get_node_by_id(tree: dict, node_id: str) -> dict | None:
    """Find a node in the tree by its node_id (depth-first)."""
    if tree.get("node_id") == node_id:
        return tree
    for child in tree.get("nodes", []):
        result = get_node_by_id(child, node_id)
        if result:
            return result
    return None


def get_top_level_summary(tree: dict) -> str:
    """Return a compact text listing of the tree's top-level nodes for the LLM."""
    lines = [f"Workbook: {tree['title']}", f"Summary: {tree['summary']}", ""]
    for node in tree.get("nodes", []):
        lines.append(f"  [{node['node_id']}] {node['title']} — {node['summary']}")
        # Include column headers if present (saves LLM iterations)
        if node.get("column_headers"):
            hdr_sample = {k: v for i, (k, v) in enumerate(node["column_headers"].items()) if i < 20}
            lines.append(f"    Column headers: {hdr_sample}")
        if node.get("row_labels"):
            lbl_sample = {k: v for i, (k, v) in enumerate(node["row_labels"].items()) if i < 20}
            lines.append(f"    Row labels: {lbl_sample}")
        for child in node.get("nodes", []):
            lines.append(f"    [{child['node_id']}] {child['title']} — {child['summary']}")
    return "\n".join(lines)


def get_node_detail(tree: dict, node_id: str) -> str:
    """Return detailed text about a specific node for the LLM to inspect."""
    node = get_node_by_id(tree, node_id)
    if not node:
        return f"Node '{node_id}' not found."

    lines = [
        f"Node: {node['title']} (type: {node['type']})",
        f"Location: {node.get('location', 'N/A')}",
        f"Summary: {node['summary']}",
    ]
    if node.get("column_headers"):
        lines.append(f"Column headers: {node['column_headers']}")
    if node.get("row_labels"):
        lines.append(f"Row labels: {node['row_labels']}")
    if node.get("columns"):
        lines.append(f"Columns: {', '.join(node['columns'])}")
    if node.get("key_formulas"):
        lines.append("Key Formulas:")
        for f in node["key_formulas"]:
            lines.append(f"  {f}")
    if node.get("cross_sheet_deps"):
        lines.append(f"Cross-sheet dependencies: {', '.join(node['cross_sheet_deps'])}")
    if node.get("nodes"):
        lines.append("Child nodes:")
        for child in node["nodes"]:
            lines.append(f"  [{child['node_id']}] {child['title']} — {child['summary']}")
    return "\n".join(lines)
