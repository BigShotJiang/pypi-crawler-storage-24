# Vectorless-QV

**Reasoning-based RAG for Excel financial models — no vectors, no chunking.**

Inspired by the [PageIndex](https://github.com/VectifyAI/PageIndex) architecture, Vectorless builds a hierarchical tree index of an Excel workbook and uses an LLM reasoning loop (via AWS Bedrock) to navigate it — just like a financial analyst would.

## Features

- **No vector database** — no embeddings, no similarity search
- **No chunking** — formulas and cell relationships stay intact
- **Hierarchical tree index** — sheets → tables → formulas → cells
- **LLM-driven reasoning** — parallel tool calls, search, drill-down
- **Formula tracing** — follows `=+PL!X118` across sheets
- **What-if analysis** — override cells and recalculate formulas
- **100% traceable** — every answer cites exact sheet, cell, and formula

## Installation

```bash
pip install -e .
```

Or from a built wheel:

```bash
pip install vectorless-qv
```

## Quick Start

### 1. Index a workbook

```bash
vectorless-qv index --file financials.xlsx
```

This creates two files:
- `financials.tree.json` — the hierarchical tree index
- `financials.parsed.json` — raw cell data for query-time lookups

### 2. Ask questions

```bash
# Single question
vectorless-qv query --file financials.xlsx -q "What is the gross margin?"

# Interactive mode
vectorless-qv query --file financials.xlsx

# With reasoning trace
vectorless-qv query --file financials.xlsx -q "How is EBITDA calculated?" -v
```

### 3. Inspect the tree

```bash
# Full overview
vectorless-qv inspect --file financials.xlsx

# Specific node
vectorless-qv inspect --file financials.xlsx --node s1_t0
```

## Python API

```python
from vectorless_qv import parse_workbook, build_tree, BedrockAgent
import json

# Parse and index
data = parse_workbook("financials.xlsx")
tree = build_tree(data)

# Query
agent = BedrockAgent(tree=tree, workbook_data=data, excel_path="financials.xlsx")
result = agent.query("What drives net income?")
print(result["answer"])
print(result["citations"])
```

## Configuration

| Env Variable | Default | Description |
|-------------|---------|-------------|
| `AWS_DEFAULT_REGION` | `us-east-1` | AWS region for Bedrock |
| `AWS_ACCESS_KEY_ID` | — | AWS credentials |
| `AWS_SECRET_ACCESS_KEY` | — | AWS credentials |

Override the model via CLI:

```bash
vectorless-qv query --file f.xlsx --model us.anthropic.claude-sonnet-4-5-20250929-v1:0 -q "..."
```

## Architecture

```
Excel File
    │
    ▼
┌──────────┐     ┌──────────┐     ┌──────────┐
│  Parser  │────▶│ Indexer   │────▶│ Tree JSON│
│(openpyxl)│     │(hierarchy)│     │  (ToC)   │
└──────────┘     └──────────┘     └──────────┘
                                       │
                                       ▼
                               ┌──────────────┐
                               │ Bedrock Agent │◀── User Question
                               │ (Claude LLM)  │
                               └──────┬───────┘
                                      │
                          ┌───────────┼───────────┐
                          ▼           ▼           ▼
                    drill_down   get_cells    search_rows
                    get_row      what_if      answer
```

## License

MIT
