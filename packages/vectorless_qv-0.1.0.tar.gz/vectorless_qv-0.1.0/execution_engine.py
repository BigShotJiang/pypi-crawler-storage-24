"""
execution_engine.py — Python-native Excel formula execution for What-If analysis.

Uses the `formulas` library to load a workbook, override cell values,
and recalculate dependent formulas without requiring desktop Excel.
"""

from pathlib import Path
from typing import Any

import formulas


class ExcelExecutionEngine:
    """Load an Excel workbook and support dynamic recalculation."""

    def __init__(self, file_path: str):
        self.file_path = Path(file_path).resolve()
        if not self.file_path.exists():
            raise FileNotFoundError(f"File not found: {file_path}")
        self._model = None

    def _load(self):
        """Lazy-load the formulas model (can be slow for large files)."""
        if self._model is None:
            self._model = formulas.ExcelModel().loads(str(self.file_path)).finish()

    def calculate(self, overrides: dict[str, Any] | None = None) -> dict:
        """
        Calculate the workbook, optionally overriding input cells first.

        Args:
            overrides: Dict mapping cell references to new values.
                       Keys should be in the format "'SheetName'!CellRef",
                       e.g. {"'Assumptions'!B3": 0.13}

        Returns:
            Dict mapping cell references to their (re)calculated values.
        """
        self._load()

        inputs = {}
        if overrides:
            for ref, value in overrides.items():
                # formulas expects uppercase references
                clean_ref = ref.upper()
                inputs[clean_ref] = value

        try:
            solution = self._model.calculate(inputs=inputs or None)
        except Exception as e:
            return {"error": str(e)}

        # Convert solution to a readable dict
        results = {}
        for key, value in solution.items():
            str_key = str(key)
            try:
                # numpy arrays → Python native
                import numpy as np
                if isinstance(value, np.ndarray):
                    value = value.tolist()
                elif isinstance(value, (np.integer, np.floating)):
                    value = value.item()
            except ImportError:
                pass
            results[str_key] = value

        return results

    def what_if(self, overrides: dict[str, Any],
                observe: list[str] | None = None) -> dict:
        """
        Run a What-If scenario: override inputs, recalculate, return observed cells.

        Args:
            overrides: Cells to override, e.g. {"'Assumptions'!B3": 0.13}
            observe:   List of cell refs to return. If None, returns all calculated cells.

        Returns:
            Dict with 'overrides_applied', 'results' (observed cell values).
        """
        all_results = self.calculate(overrides=overrides)

        if "error" in all_results:
            return {"overrides_applied": overrides, "error": all_results["error"]}

        if observe:
            observed = {}
            for ref in observe:
                clean = ref.upper()
                # Try to find the key in results (formulas uses its own key format)
                for k, v in all_results.items():
                    if clean in k.upper():
                        observed[ref] = v
                        break
                else:
                    observed[ref] = "NOT_FOUND"
            return {"overrides_applied": overrides, "results": observed}

        return {"overrides_applied": overrides, "results": all_results}
