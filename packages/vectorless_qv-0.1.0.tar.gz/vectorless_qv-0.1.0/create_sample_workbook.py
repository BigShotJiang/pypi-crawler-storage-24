"""
create_sample_workbook.py — Generate a sample multi-sheet financial model for testing.

Creates a workbook with: Assumptions, Income Statement, Balance Sheet, DCF sheets
with cross-sheet formulas and financial logic.
"""

import openpyxl
from openpyxl.utils import get_column_letter


def create_sample():
    wb = openpyxl.Workbook()

    # ── Sheet 1: Assumptions ──
    ws = wb.active
    ws.title = "Assumptions"
    ws["A1"] = "Assumptions"
    ws["A3"] = "Revenue Growth Rate"
    ws["B3"] = 0.08
    ws["B3"].number_format = "0.0%"
    ws["A4"] = "COGS % of Revenue"
    ws["B4"] = 0.60
    ws["B4"].number_format = "0.0%"
    ws["A5"] = "OpEx % of Revenue"
    ws["B5"] = 0.15
    ws["B5"].number_format = "0.0%"
    ws["A6"] = "Tax Rate"
    ws["B6"] = 0.25
    ws["B6"].number_format = "0.0%"
    ws["A7"] = "Depreciation Rate"
    ws["B7"] = 0.05
    ws["B7"].number_format = "0.0%"
    ws["A8"] = "WACC"
    ws["B8"] = 0.10
    ws["B8"].number_format = "0.0%"
    ws["A9"] = "Terminal Growth Rate"
    ws["B9"] = 0.03
    ws["B9"].number_format = "0.0%"
    ws["A10"] = "Base Year Revenue"
    ws["B10"] = 1000000
    ws["B10"].number_format = "#,##0"

    # ── Sheet 2: Income Statement ──
    ws_is = wb.create_sheet("Income Statement")
    ws_is["A1"] = "Income Statement"
    headers = ["", "FY2024", "FY2025", "FY2026", "FY2027", "FY2028"]
    for i, h in enumerate(headers, 1):
        ws_is.cell(row=3, column=i, value=h)

    # Row labels
    labels = {
        4: "Revenue",
        5: "COGS",
        6: "Gross Profit",
        7: "Operating Expenses",
        8: "EBITDA",
        9: "Depreciation",
        10: "EBIT",
        11: "Tax",
        12: "Net Income",
    }
    for row, label in labels.items():
        ws_is.cell(row=row, column=1, value=label)

    # FY2024 (base year) — Revenue from Assumptions
    ws_is["B4"] = "=Assumptions!B10"
    # FY2025-2028 — Revenue grows by growth rate
    for col in range(3, 7):  # C, D, E, F
        prev = get_column_letter(col - 1)
        cur = get_column_letter(col)
        ws_is[f"{cur}4"] = f"={prev}4*(1+Assumptions!B3)"

    # COGS = Revenue * COGS%
    for col in range(2, 7):
        c = get_column_letter(col)
        ws_is[f"{c}5"] = f"={c}4*Assumptions!B4"

    # Gross Profit = Revenue - COGS
    for col in range(2, 7):
        c = get_column_letter(col)
        ws_is[f"{c}6"] = f"={c}4-{c}5"

    # OpEx = Revenue * OpEx%
    for col in range(2, 7):
        c = get_column_letter(col)
        ws_is[f"{c}7"] = f"={c}4*Assumptions!B5"

    # EBITDA = Gross Profit - OpEx
    for col in range(2, 7):
        c = get_column_letter(col)
        ws_is[f"{c}8"] = f"={c}6-{c}7"

    # Depreciation = Revenue * Depreciation Rate
    for col in range(2, 7):
        c = get_column_letter(col)
        ws_is[f"{c}9"] = f"={c}4*Assumptions!B7"

    # EBIT = EBITDA - Depreciation
    for col in range(2, 7):
        c = get_column_letter(col)
        ws_is[f"{c}10"] = f"={c}8-{c}9"

    # Tax = EBIT * Tax Rate
    for col in range(2, 7):
        c = get_column_letter(col)
        ws_is[f"{c}11"] = f"={c}10*Assumptions!B6"

    # Net Income = EBIT - Tax
    for col in range(2, 7):
        c = get_column_letter(col)
        ws_is[f"{c}12"] = f"={c}10-{c}11"

    # Format numbers
    for row in range(4, 13):
        for col in range(2, 7):
            ws_is.cell(row=row, column=col).number_format = "#,##0"

    # ── Sheet 3: Balance Sheet (simplified) ──
    ws_bs = wb.create_sheet("Balance Sheet")
    ws_bs["A1"] = "Balance Sheet (Simplified)"
    for i, h in enumerate(headers, 1):
        ws_bs.cell(row=3, column=i, value=h)

    bs_labels = {
        4: "Cash",
        5: "Accounts Receivable",
        6: "Total Current Assets",
        7: "Fixed Assets (net)",
        8: "Total Assets",
        10: "Accounts Payable",
        11: "Total Current Liabilities",
        12: "Long-term Debt",
        13: "Total Liabilities",
        15: "Retained Earnings",
        16: "Total Equity",
        17: "Total Liabilities & Equity",
    }
    for row, label in bs_labels.items():
        ws_bs.cell(row=row, column=1, value=label)

    for col in range(2, 7):
        c = get_column_letter(col)
        # Cash = 20% of Revenue
        ws_bs[f"{c}4"] = f"='Income Statement'!{c}4*0.2"
        # AR = 15% of Revenue
        ws_bs[f"{c}5"] = f"='Income Statement'!{c}4*0.15"
        # Total Current Assets
        ws_bs[f"{c}6"] = f"={c}4+{c}5"
        # Fixed Assets = 50% of Revenue
        ws_bs[f"{c}7"] = f"='Income Statement'!{c}4*0.5"
        # Total Assets
        ws_bs[f"{c}8"] = f"={c}6+{c}7"
        # AP = 10% of COGS
        ws_bs[f"{c}10"] = f"='Income Statement'!{c}5*0.1"
        # Total Current Liabilities
        ws_bs[f"{c}11"] = f"={c}10"
        # Long-term Debt = 30% of Total Assets
        ws_bs[f"{c}12"] = f"={c}8*0.3"
        # Total Liabilities
        ws_bs[f"{c}13"] = f"={c}11+{c}12"
        # Retained Earnings = Total Assets - Total Liabilities
        ws_bs[f"{c}15"] = f"={c}8-{c}13"
        # Total Equity
        ws_bs[f"{c}16"] = f"={c}15"
        # Check: Total L&E
        ws_bs[f"{c}17"] = f"={c}13+{c}16"

    for row in list(bs_labels.keys()):
        for col in range(2, 7):
            ws_bs.cell(row=row, column=col).number_format = "#,##0"

    # ── Sheet 4: DCF ──
    ws_dcf = wb.create_sheet("DCF")
    ws_dcf["A1"] = "Discounted Cash Flow Valuation"
    for i, h in enumerate(headers, 1):
        ws_dcf.cell(row=3, column=i, value=h)

    dcf_labels = {
        4: "EBIT",
        5: "Tax on EBIT",
        6: "NOPAT",
        7: "Depreciation (add-back)",
        8: "CapEx (est.)",
        9: "Free Cash Flow",
        10: "Discount Factor",
        11: "PV of FCF",
    }
    for row, label in dcf_labels.items():
        ws_dcf.cell(row=row, column=1, value=label)

    for col in range(2, 7):
        c = get_column_letter(col)
        yr = col - 1  # year 1..5
        # EBIT from Income Statement
        ws_dcf[f"{c}4"] = f"='Income Statement'!{c}10"
        # Tax on EBIT
        ws_dcf[f"{c}5"] = f"={c}4*Assumptions!B6"
        # NOPAT
        ws_dcf[f"{c}6"] = f"={c}4-{c}5"
        # Depreciation add-back
        ws_dcf[f"{c}7"] = f"='Income Statement'!{c}9"
        # CapEx estimate = Depreciation * 1.2
        ws_dcf[f"{c}8"] = f"={c}7*1.2"
        # Free Cash Flow = NOPAT + Depreciation - CapEx
        ws_dcf[f"{c}9"] = f"={c}6+{c}7-{c}8"
        # Discount Factor = 1/(1+WACC)^year
        ws_dcf[f"{c}10"] = f"=1/(1+Assumptions!B8)^{yr}"
        # PV of FCF
        ws_dcf[f"{c}11"] = f"={c}9*{c}10"

    for row in range(4, 12):
        for col in range(2, 7):
            ws_dcf.cell(row=row, column=col).number_format = "#,##0"

    # Terminal Value & Enterprise Value
    ws_dcf["A13"] = "Terminal Value"
    ws_dcf["B13"] = "=F9*(1+Assumptions!B9)/(Assumptions!B8-Assumptions!B9)"
    ws_dcf["B13"].number_format = "#,##0"

    ws_dcf["A14"] = "PV of Terminal Value"
    ws_dcf["B14"] = "=B13/(1+Assumptions!B8)^5"
    ws_dcf["B14"].number_format = "#,##0"

    ws_dcf["A16"] = "Sum of PV of FCFs"
    ws_dcf["B16"] = "=SUM(B11:F11)"
    ws_dcf["B16"].number_format = "#,##0"

    ws_dcf["A17"] = "Enterprise Value"
    ws_dcf["B17"] = "=B16+B14"
    ws_dcf["B17"].number_format = "#,##0"

    # Save
    out = "sample_financial_model.xlsx"
    wb.save(out)
    print(f"✅ Sample workbook saved to: {out}")
    return out


if __name__ == "__main__":
    create_sample()
