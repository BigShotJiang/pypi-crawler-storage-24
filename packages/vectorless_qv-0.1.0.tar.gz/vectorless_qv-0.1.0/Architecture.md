# 📄 Vectorless RAG for Complex Financial Excel Models

> Applying **PageIndex** principles to multi-sheet `.xlsx` workbooks with financial formulas

---

## 📌 Executive Summary

Traditional RAG systems chunk text and embed it into Vector Databases, retrieving by **semantic similarity**. This fundamentally fails for complex Excel financial models because:

- **Similarity ≠ Relevance:** A cell containing `=SUM(B2:B10)` is mathematically related to cells B2–B10, but has zero semantic similarity to them.
- **Chunking destroys structure:** Splitting a multi-sheet workbook into flat text fragments obliterates formulas, cross-sheet references, and the logical flow of a financial model.

**PageIndex** (by VectifyAI) demonstrated that the solution is to replace vector search with **reasoning-based tree search** — inspired by how AlphaGo uses Monte Carlo Tree Search (MCTS) to evaluate moves. Instead of searching by "vibes," an LLM agent navigates a hierarchical index of the document, reasoning its way to the exact relevant section.

This architecture adapts the PageIndex principles specifically for `.xlsx` Excel files containing complex, multi-sheet financial models with formulas, named ranges, and cross-sheet dependencies.

---

## 🏗️ Core PageIndex Principles (Adapted for Excel)

### Principle 1: No Vector DBs, No Chunking
Cells, formulas, and sheet relationships are **never** flattened into text chunks or embedded as vectors. The mathematical and spatial structure of the workbook is preserved exactly as-is.

### Principle 2: Hierarchical Tree Index
PageIndex builds a "Table of Contents" tree from documents. For Excel, we map this as:

| PageIndex Concept | Excel Equivalent |
|---|---|
| Document | Workbook (`.xlsx` file) |
| Chapter | Sheet / Tab |
| Section | Table / Named Range / Data Block |
| Paragraph | Row group or individual cell |
| Cross-reference | Cross-sheet formula (e.g., `=Sheet2!B4`) |

### Principle 3: LLM-Generated Node Summaries
During indexing, PageIndex uses the LLM to generate a **natural-language summary** for every node in the tree. This is critical — when the agent later searches the tree, it reads these summaries to decide which branch to explore, exactly like a human scanning a table of contents.

**Example:** For a sheet named `DCF`, the summary might be:
> *"Discounted Cash Flow model projecting free cash flows for FY2024–FY2028. Key inputs: Revenue Growth (B3), WACC (B15). Key output: Enterprise Value (B22, formula: =NPV(B15, C18:G18))."*

### Principle 4: Reasoning-Based Tree Search (Inspired by AlphaGo)
Retrieval is not a single-shot similarity lookup. The LLM **iteratively navigates** the tree:
1. Read top-level node summaries → decide which sheet to enter.
2. Read section summaries within that sheet → decide which table/range to inspect.
3. Read actual cell values and formulas → trace dependencies to source cells.
4. If a formula references another sheet, follow the cross-reference and repeat.

This mirrors how a human financial analyst would work: open the workbook, scan the tabs, find the relevant model, and trace the formula chain.

### Principle 5: 100% Traceability
Every answer cites **exact coordinates**: sheet name, cell address, and the raw formula. No opaque "vibe retrieval." The user can verify every claim by opening the Excel file and navigating to the cited cell.

---

## 🌲 Excel Tree Node Structure

Each node in the tree follows a structure inspired by PageIndex's JSON format:

```jsonc
{
  "node_id": "003",
  "title": "DCF Model",
  "type": "sheet",                          // "workbook" | "sheet" | "table" | "range" | "cell"
  "location": "Sheet: DCF",
  "cell_range": "A1:G30",
  "summary": "Discounted Cash Flow model ...",  // LLM-generated during indexing
  "formulas": ["B22: =NPV(B15, C18:G18)"],     // Key formulas in this node
  "dependencies": ["Sheet: Assumptions!B3"],    // Cross-sheet references
  "nodes": [                                    // Child nodes (sub-tables, key ranges)
    {
      "node_id": "003a",
      "title": "Revenue Projections",
      "type": "range",
      "cell_range": "A2:G8",
      "summary": "Revenue forecast using growth rate from Assumptions!B3 ...",
      "formulas": ["C3: =B3*(1+Assumptions!B3)"],
      "nodes": []
    }
  ]
}
```

---

## ⚙️ Architecture & Data Flow

### Step 1: Tree Index Generation (Offline / On Upload)

This is the **indexing step** — runs once per workbook.

1. **Parse Structure (`openpyxl`):** Open the `.xlsx` file twice:
   - `data_only=False` → extract raw formulas (e.g., `=SUM(B2:B10)`)
   - `data_only=True` → extract last-computed values (e.g., `150000`)
2. **Detect Boundaries (`pandas`):** Identify distinct tables, header rows, and data blocks within each sheet automatically.
3. **Map Dependencies:** Trace cross-sheet formula references (e.g., `=Sheet2!B4`) to build the dependency graph across nodes.
4. **Generate Node Summaries (AWS Bedrock):** For each node in the tree, send its contents to the LLM and ask it to produce a concise natural-language summary describing what the section represents financially.
5. **Output:** A complete JSON tree index of the workbook, stored locally.

### Step 2: Reasoning-Based Tree Search (Per Query)

This is the **retrieval step** — runs for every user question.

1. **Present Top-Level Tree:** Show the LLM the root node and its immediate children (sheet summaries).
2. **Agent Decides:** The LLM reads the summaries and selects which sheet(s) to drill into based on the query.
3. **Drill Down:** Reveal the child nodes (tables, ranges) of the selected sheet. The LLM picks the relevant sub-section.
4. **Inspect Cells:** Show the actual cell values and formulas for the selected range.
5. **Trace Formula Chain:** If the formula references other cells/sheets, the agent follows the dependency links in the tree — repeating the drill-down on the referenced node.
6. **What-If Execution (optional):** If the user asks a scenario question (e.g., *"What if growth = 5%?"*), the agent passes the override to the `formulas` execution engine, which recalculates dependent cells in pure Python.
7. **Synthesize Answer:** The LLM composes the final response with full cell-level citations.

---

## 🔍 Example Query Flow

**User:** *"What drives Net Income in Q3, and what happens if Revenue grows 5% faster?"*

| Step | Agent Action | Detail |
|------|-------------|--------|
| 1 | Reads tree root | Sees sheets: `Assumptions`, `Income Statement`, `Balance Sheet`, `DCF` |
| 2 | Enters `Income Statement` | Summary mentions "Net Income in row 25, quarterly columns C–F" |
| 3 | Inspects row 25 | `F25: =F10 - F15 - F20` (Revenue − COGS − OpEx) |
| 4 | Traces `F10` (Revenue) | References `Assumptions!B3` (Revenue Growth Rate = 8%) |
| 5 | What-If override | Sets `Assumptions!B3 = 13%` (+5%), recalculates via engine |
| 6 | Reads new `F25` | Net Income changes from $2.1M → $2.4M |
| 7 | Returns answer | *"Net Income (Income Statement!F25) is driven by Revenue (F10 = Assumptions!B3 × prior quarter). Increasing growth from 8% to 13% raises Q3 Net Income from $2.1M to $2.4M."* |

---

## 🛠️ Tech Stack & Dependencies

| Component | Technology | Role |
|-----------|-----------|------|
| LLM Provider | AWS Bedrock (`boto3`) | Hosts the reasoning model |
| Reasoning Model | Anthropic Claude 3.5 Sonnet | Tree navigation & synthesis |
| Excel Parsing | `openpyxl`, `pandas` | Structure, formula & value extraction |
| Formula Execution | `formulas` | Python-native What-If recalculation |
| Language | Python 3.10+ | Runtime |

---

## 📁 Project Structure

```
vectorless/
├── Architecture.md          # This document
├── excel_parser.py          # Extracts sheets, tables, formulas, values from .xlsx
├── tree_indexer.py          # Builds the hierarchical JSON tree + LLM summaries
├── bedrock_agent.py         # AWS Bedrock integration & reasoning loop
├── execution_engine.py      # formulas-based What-If recalculation
├── main.py                  # CLI entrypoint: upload workbook, ask questions
└── requirements.txt         # Python dependencies
```

---

## 📎 Key Differences from Standard PageIndex

| Aspect | PageIndex (PDF/Docs) | This System (Excel/XLSX) |
|--------|---------------------|--------------------------|
| Source format | PDF, Markdown | `.xlsx` workbooks |
| Natural structure | Headings, paragraphs | Sheets, tables, named ranges |
| Content type | Text | Values + formulas + cell references |
| Cross-references | Hyperlinks, citations | Cross-sheet formulas (`=Sheet2!B4`) |
| Extra capability | — | What-If formula recalculation |
| Retrieval target | Text passages with page refs | Cell values with sheet/cell citations |
