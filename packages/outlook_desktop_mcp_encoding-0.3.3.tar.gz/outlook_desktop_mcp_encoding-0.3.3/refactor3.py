import os

server_path = r'e:\Git\antigravity-expleration\outlook-desktop-mcp\src\outlook_desktop_mcp\server.py'

with open(server_path, 'r', encoding='utf-8') as f:
    text = f.read()

# Replace _resolve_folder
old_resolve = """def _resolve_folder(namespace, folder_name: str):
    \"\"\"Resolve a folder name to an Outlook MAPIFolder object.\"\"\"
    folder_lower = folder_name.lower().strip()

    if folder_lower in FOLDER_NAME_TO_ENUM:
        return namespace.GetDefaultFolder(FOLDER_NAME_TO_ENUM[folder_lower])

    # Search root folders by name (handles Archive, custom folders)
    root = namespace.DefaultStore.GetRootFolder()
    for i in range(root.Folders.Count):
        f = root.Folders.Item(i + 1)
        if f.Name.lower() == folder_lower:
            return f

    return None"""

new_resolve = """def _resolve_folder(namespace, folder_name: str, max_depth: int = 4):
    \"\"\"Resolve a folder name to an Outlook MAPIFolder object. Recursively searches up to `max_depth`.\"\"\"
    folder_lower = folder_name.lower().strip()

    if folder_lower in FOLDER_NAME_TO_ENUM:
        return namespace.GetDefaultFolder(FOLDER_NAME_TO_ENUM[folder_lower])

    def search_folder(f, current_depth):
        if f.Name.lower() == folder_lower:
            return f
        if current_depth < max_depth:
            for i in range(f.Folders.Count):
                try:
                    child = f.Folders.Item(i + 1)
                    found = search_folder(child, current_depth + 1)
                    if found:
                        return found
                except Exception:
                    continue
        return None

    root = namespace.DefaultStore.GetRootFolder()
    for i in range(root.Folders.Count):
        try:
            f = root.Folders.Item(i + 1)
            found = search_folder(f, 1)
            if found:
                return found
        except Exception:
            continue

    return None"""

text = text.replace(old_resolve, new_resolve)

# Ensure _resolve_folder callers pass folder_depth
text = text.replace('target = _resolve_folder(namespace, folder)', 'target = _resolve_folder(namespace, folder, folder_depth)')
text = text.replace('dest = _resolve_folder(namespace, target_folder)', 'dest = _resolve_folder(namespace, target_folder, folder_depth)')


replacements = [
    # list_emails
    (
        '    unread_only: bool = False,\n    encoding: str = "utf-8",\n) -> str:', 
        '    unread_only: bool = False,\n    encoding: str = "utf-8",\n    folder_depth: int = 4,\n) -> str:'
    ),
    (
        'def _list(outlook, namespace, folder, count, unread_only, encoding):', 
        'def _list(outlook, namespace, folder, count, unread_only, encoding, folder_depth):'
    ),
    (
        'return await bridge.call(_list, folder, count, unread_only, encoding)', 
        'return await bridge.call(_list, folder, count, unread_only, encoding, folder_depth)'
    ),
    
    # read_email
    (
        '    folder: str = "inbox",\n    encoding: str = "utf-8",\n) -> str:', 
        '    folder: str = "inbox",\n    encoding: str = "utf-8",\n    folder_depth: int = 4,\n) -> str:'
    ),
    (
        'def _read(outlook, namespace, entry_id, subject_search, folder, encoding):', 
        'def _read(outlook, namespace, entry_id, subject_search, folder, encoding, folder_depth):'
    ),
    (
        'return await bridge.call(_read, entry_id, subject_search, folder, encoding)', 
        'return await bridge.call(_read, entry_id, subject_search, folder, encoding, folder_depth)'
    ),

    # search_emails (mail)
    (
        '    count: int = 10,\n    encoding: str = "utf-8",\n) -> str:', 
        '    count: int = 10,\n    encoding: str = "utf-8",\n    folder_depth: int = 4,\n) -> str:'
    ),
    (
        'def _search(outlook, namespace, query, folder, count, encoding):', 
        'def _search(outlook, namespace, query, folder, count, encoding, folder_depth):'
    ),
    (
        'return await bridge.call(_search, query, folder, count, encoding)', 
        'return await bridge.call(_search, query, folder, count, encoding, folder_depth)'
    ),

    # move_email
    (
        '    target_folder: str = "archive",\n) -> str:', 
        '    target_folder: str = "archive",\n    folder_depth: int = 4,\n) -> str:'
    ),
    (
        'def _move(outlook, namespace, entry_id, target_folder):', 
        'def _move(outlook, namespace, entry_id, target_folder, folder_depth):'
    ),
    (
        'return await bridge.call(_move, entry_id, target_folder)', 
        'return await bridge.call(_move, entry_id, target_folder, folder_depth)'
    ),
]

for old, new in replacements:
    if old in text:
        text = text.replace(old, new)
    else:
        print(f"Failed to find:\n{old}\n")

with open(server_path, 'w', encoding='utf-8') as f:
    f.write(text)

print("Done Refactoring Depth!")
