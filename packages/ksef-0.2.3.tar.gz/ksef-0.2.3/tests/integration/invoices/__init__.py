"""Invoices-related integration tests."""
