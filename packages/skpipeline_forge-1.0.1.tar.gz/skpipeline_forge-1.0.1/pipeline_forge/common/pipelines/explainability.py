from abc import ABC
from typing import Optional

from pipeline_forge.common.transformers import ExplainabilityReporterTransformer


class ExplainabilityPipeline(ABC):
    """
    Pipeline layer for explainability-focused reporting steps.
    """

    def _ensure_explainability_steps(self):
        if not hasattr(self, "explainability_steps"):
            self.explainability_steps = []

    def explain_with_permutation_importance(
            self,
            model,
            scoring: Optional[str] = None,
            n_repeats: int = 5,
    ):
        self._ensure_explainability_steps()
        self.explainability_steps.append(
            (
                "permutation_importance",
                ExplainabilityReporterTransformer(
                    model=model,
                    scoring=scoring,
                    n_repeats=n_repeats,
                    random_seed=getattr(self, "random_seed", 1995),
                ),
            )
        )
        return self
