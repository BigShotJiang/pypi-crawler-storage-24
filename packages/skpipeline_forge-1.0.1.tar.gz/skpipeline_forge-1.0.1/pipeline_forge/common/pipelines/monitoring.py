from abc import ABC
from typing import List, Optional

from pipeline_forge.common.transformers import DriftStatsTransformer


class MonitoringPipeline(ABC):
    """
    Pipeline layer for non-destructive monitoring steps.
    """

    def _ensure_monitoring_steps(self):
        if not hasattr(self, "monitoring_steps"):
            self.monitoring_steps = []

    def monitor_drift(self, numeric_cols: Optional[List[str]] = None):
        self._ensure_monitoring_steps()
        self.monitoring_steps.append(
            (
                "drift_stats",
                DriftStatsTransformer(numeric_cols=numeric_cols),
            )
        )
        return self
