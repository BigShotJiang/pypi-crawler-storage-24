from abc import ABC
from typing import List, Optional

from pipeline_forge.common.transformers import (
    LogYeoJohnsonTransformer,
    OutlierClipper,
    WinsorizerTransformer,
)


class PostProcessingPipeline(ABC):
    """
    Pipeline layer for post-engineering feature shaping.
    """

    def _ensure_postprocessing_steps(self):
        if not hasattr(self, "postprocessing_steps"):
            self.postprocessing_steps = []

    def clip_outliers(
            self,
            numeric_cols: Optional[List[str]] = None,
            lower_quantile: float = 0.01,
            upper_quantile: float = 0.99,
    ):
        self._ensure_postprocessing_steps()
        self.postprocessing_steps.append(
            (
                "outlier_clipper",
                OutlierClipper(
                    numeric_cols=numeric_cols,
                    lower_quantile=lower_quantile,
                    upper_quantile=upper_quantile,
                ),
            )
        )
        return self

    def winsorize(
            self,
            numeric_cols: Optional[List[str]] = None,
            lower_tail: float = 0.01,
            upper_tail: float = 0.99,
    ):
        self._ensure_postprocessing_steps()
        self.postprocessing_steps.append(
            (
                "winsorizer",
                WinsorizerTransformer(
                    numeric_cols=numeric_cols,
                    lower_tail=lower_tail,
                    upper_tail=upper_tail,
                ),
            )
        )
        return self

    def transform_distribution(
            self,
            numeric_cols: Optional[List[str]] = None,
            method: str = "yeo-johnson",
            standardize: bool = False,
    ):
        self._ensure_postprocessing_steps()
        self.postprocessing_steps.append(
            (
                "log_yeojohnson",
                LogYeoJohnsonTransformer(
                    numeric_cols=numeric_cols,
                    method=method,
                    standardize=standardize,
                ),
            )
        )
        return self
