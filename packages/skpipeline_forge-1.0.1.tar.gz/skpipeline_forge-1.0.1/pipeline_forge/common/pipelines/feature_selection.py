from abc import ABC

from pipeline_forge.common.transformers import (
    CorrelationFeatureDrop,
    DecisionTreesFeatureSelector,
    RandomForestFeatureSelector,
)


class FeatureSelectionPipeline(ABC):
    """
    Pipeline layer for feature selection-specific steps.
    """

    def _ensure_selection_steps(self):
        if not hasattr(self, "selection_steps"):
            self.selection_steps = []

    def select_by_correlation(self, drop_thresh: float):
        self._ensure_selection_steps()
        self.selection_steps.append(
            ("selection_correlation_drop", CorrelationFeatureDrop(correlation_drop_th=drop_thresh))
        )
        return self

    def select_by_decision_tree(self, importance_thresh: float):
        self._ensure_selection_steps()
        self.selection_steps.append(
            (
                "selection_dt_importance",
                DecisionTreesFeatureSelector(
                    importance_th=importance_thresh,
                    random_seed=getattr(self, "random_seed", None),
                ),
            )
        )
        return self

    def select_by_random_forest(self, importance_thresh: float):
        self._ensure_selection_steps()
        self.selection_steps.append(
            (
                "selection_rf_importance",
                RandomForestFeatureSelector(
                    importance_th=importance_thresh,
                    random_seed=getattr(self, "random_seed", None),
                ),
            )
        )
        return self
