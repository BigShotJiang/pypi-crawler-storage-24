from abc import ABC
from typing import List

from pipeline_forge.common.transformers import SchemaValidatorTransformer


class ValidationPipeline(ABC):
    """
    Pipeline layer for data schema and input validation steps.
    """

    def _ensure_validation_steps(self):
        if not hasattr(self, "validation_steps"):
            self.validation_steps = []

    def validate_schema(self, required_cols: List[str], expected_dtypes: dict = None, strict: bool = True):
        self._ensure_validation_steps()
        self.validation_steps.append(
            (
                "schema_validation",
                SchemaValidatorTransformer(
                    required_cols=required_cols,
                    expected_dtypes=expected_dtypes,
                    strict=strict,
                ),
            )
        )
        return self
