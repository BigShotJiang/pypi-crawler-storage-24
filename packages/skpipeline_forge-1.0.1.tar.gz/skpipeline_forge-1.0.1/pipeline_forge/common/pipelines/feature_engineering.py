from abc import ABC
from typing import Any, Dict, List, Optional, Tuple, Union

import mlflow
from sklearn.pipeline import Pipeline

from pipeline_forge.common.transformers import (
    CategoricalNonOrdinalTransformer,
    CategoricalNormTransformer,
    CyclicalTimeEncoder,
    ColumnDropTransformer,
    CorrelationFeatureDrop,
    DataframeMemoryReducer,
    DateTimeEncoder,
    DecisionTreesFeatureSelector,
    FeatureInteractionTransformer,
    FeatureScalerTransformer,
    FeatureSelector,
    FillNullsTransformer,
    LogYeoJohnsonTransformer,
    OutlierClipper,
    ProphetFeatureGenerator,
    RareCategoryGrouper,
    RandomForestFeatureSelector,
    TargetEncodingTransformer,
    TextVectorizerTransformer,
    WinsorizerTransformer,
    SimpleImputerTransformer,
    WoETransformer,
)


class FeatureEngineeringPipeline(ABC):
    """
    A pipeline for feature engineering in machine learning tasks.

    This class provides methods to build a feature engineering pipeline for preprocessing
    and feature selection tasks. It allows you to add various data transformation steps
    to preprocess your data before training machine learning models.

    Args:
        target_col (str): The name of the target column.
        random_seed (int, optional): Random seed for reproducibility. Defaults to 1995.
    """

    def __init__(self, target_col: str, random_seed: Optional[int] = 1995):
        """
        Initialize the FeatureEngineeringPipeline.

        Args:
            target_col (str): The name of the target column.
            random_seed (int, optional): Random seed for reproducibility. Defaults to 1995.
        """
        super().__init__()
        self.target_col = target_col
        self.random_seed = random_seed
        self.engineering_steps: List[Tuple[str, Any]] = []

    def drop_columns(self, drop_cols: List[str]) -> 'FeatureEngineeringPipeline':
        """
        Add a step to drop specified columns.

        Args:
            drop_cols (List[str]): List of column names to be dropped.

        Returns:
            FeatureEngineeringPipeline: Updated pipeline instance.
        """
        self.engineering_steps.append(("drop_columns", ColumnDropTransformer(drop_cols=drop_cols)))
        return self

    def select_columns(self, select_cols: List[str]) -> 'FeatureEngineeringPipeline':
        """
        Add a step to select specified columns.

        Args:
            select_cols (List[str]): List of column names to be selected.

        Returns:
            FeatureEngineeringPipeline: Updated pipeline instance.
        """
        self.engineering_steps.append(("select_columns", FeatureSelector(select_cols=select_cols)))
        return self

    def fill_na(self, fill_na_dict: Dict[str, Union[int, str, float]]) -> 'FeatureEngineeringPipeline':
        """
        Add a step to fill missing values in specified columns.

        Args:
            fill_na_dict (Dict[str, Union[int, str, float]]): A dictionary where keys are column names
                and values are fill values.

        Returns:
            FeatureEngineeringPipeline: Updated pipeline instance.
        """
        self.engineering_steps.append(
            ("fill_na", FillNullsTransformer(fill_na_dict=fill_na_dict))
        )
        return self

    def mean_imputation_na_list(self, fill_na_mean: List[str], strategy: str) -> 'FeatureEngineeringPipeline':
        """
        Add a step to perform mean imputation for specified columns.

        Args:
            fill_na_mean (List[str]): List of column names for mean imputation.
            strategy (str): Imputation strategy, one of 'mean', 'median', 'most_frequent', or 'constant'.

        Returns:
            FeatureEngineeringPipeline: Updated pipeline instance.
        """
        self.engineering_steps.append(
            ("fill_na_mean", SimpleImputerTransformer(
                columns=fill_na_mean,
                imputer_strategy=strategy
            ))
        )
        return self

    def woe_categorical_imputer(self, categorical_cols: List[str]) -> 'FeatureEngineeringPipeline':
        """
        Add a step to perform Weight of Evidence (WoE) transformation for specified categorical columns.

        Args:
            categorical_cols (List[str]): List of column names for WoE transformation.

        Returns:
            FeatureEngineeringPipeline: Updated pipeline instance.
        """
        self.engineering_steps.append(
            ("woe_categorical_imputer", WoETransformer(
                categorical_cols=categorical_cols,
                target_col=self.target_col))
        )
        return self

    def cat_norm_cat_features(
            self, categorical_variables: List[str],
            numerical_variables: List[str],
            categorical_alias: Union[str, List[str]],
    ) -> 'FeatureEngineeringPipeline':
        """
        Add a step to normalize specified categorical features.

        Args:
            categorical_variables (List[str]): List of categorical variable names.
            numerical_variables (List[int]): List of numerical variable indices.
            categorical_alias (str): Alias for the categorical features.

        Returns:
            FeatureEngineeringPipeline: Updated pipeline instance.
        """
        self.engineering_steps.append(
            ("cat_norm_cat_features", CategoricalNormTransformer(
                categorical_variables=categorical_variables,
                numerical_variables=numerical_variables,
                categorical_alias=categorical_alias))
        )
        return self

    def one_hot_encode(self, non_ordinal_categorical_cols: List[str]) -> 'FeatureEngineeringPipeline':
        """
        Add a step to perform one-hot encoding for specified non-ordinal categorical columns.

        Args:
            non_ordinal_categorical_cols (List[str]): List of non-ordinal categorical column names.

        Returns:
            FeatureEngineeringPipeline: Updated pipeline instance.
        """
        self.engineering_steps.append(
            ("one_hot_encode", CategoricalNonOrdinalTransformer(
                non_ordinal_categorical_cols=non_ordinal_categorical_cols))
        )
        return self

    def encode_date_col(self, date_col: str, time_col: Optional[str] = None) -> 'FeatureEngineeringPipeline':
        """
        Add a step to encode date columns.

        Returns:
            FeatureEngineeringPipeline: Updated pipeline instance.
        """
        self.engineering_steps.append(
            ("date_encoder", DateTimeEncoder(date_col=date_col, time_col=time_col))
        )
        return self

    def add_prophet_features(
            self,
            date_col: str,
            time_col: Optional[str] = None,
            y_col: str = "close"
    ) -> 'FeatureEngineeringPipeline':
        """
        Add a step to generate features using Prophet.

        Returns:
            FeatureEngineeringPipeline: Updated pipeline instance.
        """
        self.engineering_steps.append(
            ("prophet", ProphetFeatureGenerator(date_col=date_col, time_col=time_col, y_col=y_col))
        )
        return self

    def reduce_mem_load(self) -> 'FeatureEngineeringPipeline':
        """
        Add a step to reduce memory usage of the DataFrame.

        Returns:
            FeatureEngineeringPipeline: Updated pipeline instance.
        """
        self.engineering_steps.append(
            ("reduce_mem", DataframeMemoryReducer())
        )
        return self

    def target_encode(
            self,
            categorical_cols: List[str],
            smoothing: float = 10.0,
            suffix: str = "_TE",
            drop_original: bool = False,
    ) -> 'FeatureEngineeringPipeline':
        self.engineering_steps.append(
            (
                "target_encode",
                TargetEncodingTransformer(
                    categorical_cols=categorical_cols,
                    smoothing=smoothing,
                    suffix=suffix,
                    drop_original=drop_original,
                ),
            )
        )
        return self

    def group_rare_categories(
            self,
            categorical_cols: List[str],
            min_freq: float = 0.01,
            other_label: str = "__OTHER__",
    ) -> 'FeatureEngineeringPipeline':
        self.engineering_steps.append(
            (
                "rare_category_grouping",
                RareCategoryGrouper(
                    categorical_cols=categorical_cols,
                    min_freq=min_freq,
                    other_label=other_label,
                ),
            )
        )
        return self

    def add_interaction_features(
            self,
            numeric_cols: Optional[List[str]] = None,
            include_self_interactions: bool = False,
    ) -> 'FeatureEngineeringPipeline':
        self.engineering_steps.append(
            (
                "feature_interactions",
                FeatureInteractionTransformer(
                    numeric_cols=numeric_cols,
                    include_self_interactions=include_self_interactions,
                ),
            )
        )
        return self

    def encode_cyclical_time(
            self,
            period_map: Dict[str, float],
            drop_original: bool = False,
    ) -> 'FeatureEngineeringPipeline':
        self.engineering_steps.append(
            (
                "cyclical_time",
                CyclicalTimeEncoder(period_map=period_map, drop_original=drop_original),
            )
        )
        return self

    def vectorize_text(
            self,
            text_col: str,
            max_features: int = 200,
            prefix: str = "TFIDF",
            drop_original: bool = True,
    ) -> 'FeatureEngineeringPipeline':
        self.engineering_steps.append(
            (
                "text_vectorize",
                TextVectorizerTransformer(
                    text_col=text_col,
                    max_features=max_features,
                    prefix=prefix,
                    drop_original=drop_original,
                ),
            )
        )
        return self

    def clip_feature_outliers(
            self,
            numeric_cols: Optional[List[str]] = None,
            lower_quantile: float = 0.01,
            upper_quantile: float = 0.99,
    ) -> 'FeatureEngineeringPipeline':
        self.engineering_steps.append(
            (
                "outlier_clip",
                OutlierClipper(
                    numeric_cols=numeric_cols,
                    lower_quantile=lower_quantile,
                    upper_quantile=upper_quantile,
                ),
            )
        )
        return self

    def winsorize_features(
            self,
            numeric_cols: Optional[List[str]] = None,
            lower_tail: float = 0.01,
            upper_tail: float = 0.99,
    ) -> 'FeatureEngineeringPipeline':
        self.engineering_steps.append(
            (
                "winsorize",
                WinsorizerTransformer(
                    numeric_cols=numeric_cols,
                    lower_tail=lower_tail,
                    upper_tail=upper_tail,
                ),
            )
        )
        return self

    def transform_skewed_features(
            self,
            numeric_cols: Optional[List[str]] = None,
            method: str = "yeo-johnson",
            standardize: bool = False,
    ) -> 'FeatureEngineeringPipeline':
        self.engineering_steps.append(
            (
                "log_yeojohnson",
                LogYeoJohnsonTransformer(
                    numeric_cols=numeric_cols,
                    method=method,
                    standardize=standardize,
                ),
            )
        )
        return self

    def scaler(self, scaler_type: str) -> 'FeatureEngineeringPipeline':
        """
        Add a step to scale features using the specified scaler.

        Args:
            scaler_type (str): The type of scaler to use, one of 'standard', 'min_max', 'robust', or 'max_absolute'.

        Returns:
            FeatureEngineeringPipeline: Updated pipeline instance.
        """
        self.engineering_steps.append(
            ("scaler", FeatureScalerTransformer(scaler_type=scaler_type))
        )
        if mlflow.active_run():
            mlflow.set_tag("scaler", scaler_type)
        return self

    def drop_correlated_features(self, drop_thresh: float) -> 'FeatureEngineeringPipeline':
        """
        Add a step to drop correlated features based on the specified threshold.

        Args:
            drop_thresh (float): The correlation threshold used to drop features.

        Returns:
            FeatureEngineeringPipeline: Updated pipeline instance.
        """
        self.engineering_steps.append(
            ("feature_correlation_drop", CorrelationFeatureDrop(correlation_drop_th=drop_thresh))
        )
        if mlflow.active_run():
            mlflow.set_tag("correlated_feature_thresh", drop_thresh)
        return self

    def decision_tree_feat_select(self, importance_thresh: float) -> 'FeatureEngineeringPipeline':
        """
        Add a step to perform feature selection using decision trees.

        Args:
            importance_thresh (float): The importance threshold for feature selection.

        Returns:
            FeatureEngineeringPipeline: Updated pipeline instance.
        """
        self.engineering_steps.append(
            ("dt_importance_th", DecisionTreesFeatureSelector(
                importance_th=importance_thresh,
                random_seed=self.random_seed,
            ))
        )
        if mlflow.active_run():
            mlflow.set_tag("dt_importance_th", importance_thresh)
        return self

    def random_forest_feat_select(self, importance_thresh: float) -> 'FeatureEngineeringPipeline':
        """
        Add a step to perform feature selection using random forests.

        Args:
            importance_thresh (float): The importance threshold for feature selection.

        Returns:
            FeatureEngineeringPipeline: Updated pipeline instance.
        """
        self.engineering_steps.append(
            ("rf_importance_th", RandomForestFeatureSelector(
                importance_th=importance_thresh,
                random_seed=self.random_seed,
            ))
        )
        if mlflow.active_run():
            mlflow.set_tag("rf_importance_th", importance_thresh)
        return self

    def build_feature_engineering_steps(self) -> Pipeline:
        """
        Build the preconfigured Pipeline based on the added steps.

        Returns:
            Pipeline: Constructed Pipeline instance.
        """
        return Pipeline(self.engineering_steps)
