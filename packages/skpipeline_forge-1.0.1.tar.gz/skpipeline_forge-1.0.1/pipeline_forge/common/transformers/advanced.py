import itertools
from typing import Dict, List, Optional, Sequence

import numpy as np
import pandas as pd
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.preprocessing import PowerTransformer


class TargetEncodingTransformer(BaseEstimator, TransformerMixin):
    """
    Target encoding for categorical columns with additive smoothing.
    """

    def __init__(
            self,
            categorical_cols: List[str],
            smoothing: float = 10.0,
            suffix: str = "_TE",
            drop_original: bool = False,
    ):
        self.categorical_cols = categorical_cols
        self.smoothing = smoothing
        self.suffix = suffix
        self.drop_original = drop_original
        self.global_mean_ = None
        self.mapping_: Dict[str, pd.Series] = {}

    def fit(self, X: pd.DataFrame, y=None):
        if y is None:
            raise ValueError("TargetEncodingTransformer requires y during fit.")
        y_series = pd.Series(y, index=X.index)
        self.global_mean_ = y_series.mean()

        for col in self.categorical_cols:
            grouped = pd.DataFrame({col: X[col], "__target__": y_series}).groupby(col)["__target__"]
            means = grouped.mean()
            counts = grouped.count()
            smooth = (means * counts + self.global_mean_ * self.smoothing) / (counts + self.smoothing)
            self.mapping_[col] = smooth
        return self

    def transform(self, X: pd.DataFrame, y=None) -> pd.DataFrame:
        X_ = X.copy()
        for col in self.categorical_cols:
            new_col = f"{col}{self.suffix}"
            X_[new_col] = X_[col].map(self.mapping_[col]).fillna(self.global_mean_)
        if self.drop_original:
            X_ = X_.drop(columns=self.categorical_cols)
        return X_


class RareCategoryGrouper(BaseEstimator, TransformerMixin):
    """
    Groups infrequent categorical labels under a shared token.
    """

    def __init__(
            self,
            categorical_cols: List[str],
            min_freq: float = 0.01,
            other_label: str = "__OTHER__",
    ):
        self.categorical_cols = categorical_cols
        self.min_freq = min_freq
        self.other_label = other_label
        self.frequent_categories_: Dict[str, set] = {}

    def fit(self, X: pd.DataFrame, y=None):
        n_rows = len(X)
        for col in self.categorical_cols:
            value_counts = X[col].value_counts(dropna=False)
            if self.min_freq < 1:
                threshold = int(np.ceil(self.min_freq * n_rows))
            else:
                threshold = int(self.min_freq)
            frequent = value_counts[value_counts >= max(1, threshold)].index
            self.frequent_categories_[col] = set(frequent)
        return self

    def transform(self, X: pd.DataFrame, y=None) -> pd.DataFrame:
        X_ = X.copy()
        for col in self.categorical_cols:
            X_[col] = X_[col].where(X_[col].isin(self.frequent_categories_[col]), other=self.other_label)
        return X_


class OutlierClipper(BaseEstimator, TransformerMixin):
    """
    Clips numerical columns based on learned quantile bounds.
    """

    def __init__(
            self,
            numeric_cols: Optional[List[str]] = None,
            lower_quantile: float = 0.01,
            upper_quantile: float = 0.99,
    ):
        self.numeric_cols = numeric_cols
        self.lower_quantile = lower_quantile
        self.upper_quantile = upper_quantile
        self.bounds_: Dict[str, tuple] = {}

    def fit(self, X: pd.DataFrame, y=None):
        cols = self.numeric_cols or X.select_dtypes(include=["number"]).columns.tolist()
        for col in cols:
            low = X[col].quantile(self.lower_quantile)
            high = X[col].quantile(self.upper_quantile)
            self.bounds_[col] = (low, high)
        return self

    def transform(self, X: pd.DataFrame, y=None) -> pd.DataFrame:
        X_ = X.copy()
        for col, (low, high) in self.bounds_.items():
            X_[col] = X_[col].clip(lower=low, upper=high)
        return X_


class WinsorizerTransformer(OutlierClipper):
    """
    Alias-style transformer for winsorization by tail limits.
    """

    def __init__(
            self,
            numeric_cols: Optional[List[str]] = None,
            lower_tail: float = 0.01,
            upper_tail: float = 0.99,
    ):
        super().__init__(
            numeric_cols=numeric_cols,
            lower_quantile=lower_tail,
            upper_quantile=upper_tail,
        )


class LogYeoJohnsonTransformer(BaseEstimator, TransformerMixin):
    """
    Applies Yeo-Johnson (or log1p on positive values) to selected numeric columns.
    """

    def __init__(
            self,
            numeric_cols: Optional[List[str]] = None,
            method: str = "yeo-johnson",
            standardize: bool = False,
    ):
        if method not in {"yeo-johnson", "log1p"}:
            raise ValueError("method must be one of {'yeo-johnson', 'log1p'}")
        self.numeric_cols = numeric_cols
        self.method = method
        self.standardize = standardize
        self.transformers_: Dict[str, PowerTransformer] = {}

    def fit(self, X: pd.DataFrame, y=None):
        cols = self.numeric_cols or X.select_dtypes(include=["number"]).columns.tolist()
        self.numeric_cols_ = cols
        if self.method == "yeo-johnson":
            for col in cols:
                pt = PowerTransformer(method="yeo-johnson", standardize=self.standardize)
                pt.fit(X[[col]])
                self.transformers_[col] = pt
        return self

    def transform(self, X: pd.DataFrame, y=None) -> pd.DataFrame:
        X_ = X.copy()
        for col in self.numeric_cols_:
            if self.method == "yeo-johnson":
                X_[col] = self.transformers_[col].transform(X_[[col]]).reshape(-1)
            else:
                min_val = X_[col].min()
                offset = abs(min_val) + 1 if min_val <= -1 else 0
                X_[col] = np.log1p(X_[col] + offset)
        return X_


class FeatureInteractionTransformer(BaseEstimator, TransformerMixin):
    """
    Creates pairwise interaction features for selected numerical columns.
    """

    def __init__(
            self,
            numeric_cols: Optional[List[str]] = None,
            include_self_interactions: bool = False,
    ):
        self.numeric_cols = numeric_cols
        self.include_self_interactions = include_self_interactions

    def fit(self, X: pd.DataFrame, y=None):
        cols = self.numeric_cols or X.select_dtypes(include=["number"]).columns.tolist()
        self.numeric_cols_ = cols
        return self

    def transform(self, X: pd.DataFrame, y=None) -> pd.DataFrame:
        X_ = X.copy()
        pairs = itertools.combinations_with_replacement(self.numeric_cols_, 2) \
            if self.include_self_interactions else itertools.combinations(self.numeric_cols_, 2)
        for col_a, col_b in pairs:
            X_[f"{col_a}__x__{col_b}"] = X_[col_a] * X_[col_b]
        return X_


class CyclicalTimeEncoder(BaseEstimator, TransformerMixin):
    """
    Encodes periodic numeric columns with sin/cos projections.
    """

    def __init__(
            self,
            period_map: Dict[str, float],
            drop_original: bool = False,
    ):
        self.period_map = period_map
        self.drop_original = drop_original

    def fit(self, X: pd.DataFrame, y=None):
        for col in self.period_map:
            if col not in X.columns:
                raise ValueError(f"{col} not found in input DataFrame")
        return self

    def transform(self, X: pd.DataFrame, y=None) -> pd.DataFrame:
        X_ = X.copy()
        for col, period in self.period_map.items():
            angle = 2 * np.pi * X_[col] / period
            X_[f"{col}_SIN"] = np.sin(angle)
            X_[f"{col}_COS"] = np.cos(angle)
        if self.drop_original:
            X_ = X_.drop(columns=list(self.period_map.keys()))
        return X_


class TextVectorizerTransformer(BaseEstimator, TransformerMixin):
    """
    TF-IDF vectorization for a single text column with DataFrame output.
    """

    def __init__(
            self,
            text_col: str,
            max_features: int = 200,
            prefix: str = "TFIDF",
            drop_original: bool = True,
    ):
        self.text_col = text_col
        self.max_features = max_features
        self.prefix = prefix
        self.drop_original = drop_original
        self.vectorizer_ = TfidfVectorizer(max_features=max_features)
        self.feature_names_: List[str] = []

    def fit(self, X: pd.DataFrame, y=None):
        text_values = X[self.text_col].fillna("").astype(str).tolist()
        self.vectorizer_.fit(text_values)
        self.feature_names_ = [
            f"{self.prefix}_{name}" for name in self.vectorizer_.get_feature_names_out()
        ]
        return self

    def transform(self, X: pd.DataFrame, y=None) -> pd.DataFrame:
        X_ = X.copy()
        matrix = self.vectorizer_.transform(X_[self.text_col].fillna("").astype(str).tolist())
        tfidf_df = pd.DataFrame(matrix.toarray(), index=X_.index, columns=self.feature_names_)
        if self.drop_original:
            X_ = X_.drop(columns=[self.text_col])
        return pd.concat([X_, tfidf_df], axis=1)


class SchemaValidatorTransformer(BaseEstimator, TransformerMixin):
    """
    Validates required columns and optional expected dtypes.
    """

    def __init__(
            self,
            required_cols: Sequence[str],
            expected_dtypes: Optional[Dict[str, str]] = None,
            strict: bool = True,
    ):
        self.required_cols = list(required_cols)
        self.expected_dtypes = expected_dtypes or {}
        self.strict = strict

    def fit(self, X: pd.DataFrame, y=None):
        self._validate(X)
        return self

    def transform(self, X: pd.DataFrame, y=None) -> pd.DataFrame:
        self._validate(X)
        return X.copy()

    def _validate(self, X: pd.DataFrame):
        missing = [col for col in self.required_cols if col not in X.columns]
        if missing:
            raise ValueError(f"Missing required columns: {missing}")
        if self.strict:
            for col, dtype in self.expected_dtypes.items():
                if col in X.columns and str(X[col].dtype) != dtype:
                    raise ValueError(f"Column {col} has dtype {X[col].dtype}, expected {dtype}")


class DriftStatsTransformer(BaseEstimator, TransformerMixin):
    """
    Computes lightweight drift statistics against training baseline and passes data through.
    """

    def __init__(self, numeric_cols: Optional[List[str]] = None):
        self.numeric_cols = numeric_cols
        self.baseline_stats_: Dict[str, Dict[str, float]] = {}
        self.last_drift_report_: Dict[str, Dict[str, float]] = {}

    def fit(self, X: pd.DataFrame, y=None):
        cols = self.numeric_cols or X.select_dtypes(include=["number"]).columns.tolist()
        self.numeric_cols_ = cols
        for col in cols:
            self.baseline_stats_[col] = {
                "mean": float(X[col].mean()),
                "std": float(X[col].std(ddof=0) or 0.0),
            }
        return self

    def transform(self, X: pd.DataFrame, y=None) -> pd.DataFrame:
        report = {}
        for col in self.numeric_cols_:
            baseline = self.baseline_stats_[col]
            current_mean = float(X[col].mean())
            current_std = float(X[col].std(ddof=0) or 0.0)
            report[col] = {
                "mean_shift": current_mean - baseline["mean"],
                "std_ratio": (current_std / baseline["std"]) if baseline["std"] > 0 else np.nan,
            }
        self.last_drift_report_ = report
        return X.copy()


class ExplainabilityReporterTransformer(BaseEstimator, TransformerMixin):
    """
    Computes permutation-based feature importance with a provided fitted model.
    """

    def __init__(self, model, scoring: Optional[str] = None, n_repeats: int = 5, random_seed: int = 1995):
        self.model = model
        self.scoring = scoring
        self.n_repeats = n_repeats
        self.random_seed = random_seed
        self.feature_importances_: Optional[pd.DataFrame] = None

    def fit(self, X: pd.DataFrame, y=None):
        if y is None:
            return self
        from sklearn.inspection import permutation_importance

        result = permutation_importance(
            self.model,
            X,
            y,
            scoring=self.scoring,
            n_repeats=self.n_repeats,
            random_state=self.random_seed,
        )
        self.feature_importances_ = pd.DataFrame(
            {
                "feature": X.columns.tolist(),
                "importance_mean": result.importances_mean,
                "importance_std": result.importances_std,
            }
        ).sort_values("importance_mean", ascending=False)
        return self

    def transform(self, X: pd.DataFrame, y=None) -> pd.DataFrame:
        return X.copy()
