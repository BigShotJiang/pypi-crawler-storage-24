from .pipeline_builder import FeaturePipelineBuilder
from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("skpipeline-forge")
except PackageNotFoundError:
    __version__ = "0.0.0"

__all__ = [
    "FeaturePipelineBuilder",
    "__version__",
]
