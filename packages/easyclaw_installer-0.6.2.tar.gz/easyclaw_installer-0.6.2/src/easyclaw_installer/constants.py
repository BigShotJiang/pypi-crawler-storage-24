"""Shared constants for the EasyClaw installer."""

# OpenRouter API
OPENROUTER_BASE = "https://openrouter.ai/api/v1/chat/completions"
OPENROUTER_MODEL = "moonshotai/kimi-k2.5"

# Free/default agent — zero-budget key + free model for out-of-box experience
FREE_API_KEY = "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"
FREE_MODEL = "arcee-ai/trinity-large-preview:free"

# Rolling log buffer size (agent context window)
LOG_DEQUE_SIZE = 100

# Agent limits
MAX_TOOL_ITERATIONS = 10   # prevent infinite tool-call loops
AGENT_HTTP_TIMEOUT = 120   # seconds for streaming response

# Conversation history cap (keep recent, always regenerate system prompt)
MAX_CONVERSATION_MESSAGES = 30

# MCP Knowledge Base
DEFAULT_MCP_URL = "https://mcp.easyclaw.help"
MCP_HTTP_TIMEOUT = 30  # seconds for MCP JSON-RPC calls
