from functools import wraps
from typing import Any, cast, override
from pandas import DataFrame


from pynomad.cache.core.meta import MetaInfo
from pynomad.cache.core.types import DecoratorTarget, EvictionPolicy, KeyGenerator
from pynomad.cache.dataframe.df_cache_types import (
    DataFrameValueLoader,
    DefaultDataFrameValueLoader,
    DataFrameLoaderContext,
)
from pynomad.cache.dataframe.utils import parse_cache_dataframe
from pynomad.cache.decorator.base_decorator import BaseCacheDecorator
from pynomad.cache.decorator.keygenerator import module_function_key_generator
from pynomad.result.result import Result, ResultAny


# parse_cache_dataframe 已移动到 utils.py 以避免循环导入


def merge_extra_params(
    decorator_extra_params: dict[str, Any] | None,
    meta_info: MetaInfo | None,
) -> dict[str, Any]:
    """合并所有参数到字典中

    将装饰器传递的额外参数、MetaInfo 的所有元信息字段以及
    meta_info.extra_params 全部展开到一个字典中。

    Args:
        decorator_extra_params: 装饰器传递的额外参数
        meta_info: 缓存的元信息

    Returns:
        合并后的字典，包含所有参数和元信息
    """
    result: dict[str, Any] = {}

    # 如果 meta_info 不为 None，添加其元信息字段
    if meta_info is not None:
        result["create_at"] = meta_info.create_at
        result["last_update_at"] = meta_info.last_update_at
        result["last_accessed_at"] = meta_info.last_accessed_at
        result["access_count"] = meta_info.access_count
        result["time_to_live"] = meta_info.time_to_live

        # 展开 meta_info.extra_params 中的所有键值对
        if meta_info.extra_params:
            result.update(meta_info.extra_params)

    # 添加 decorator_extra_params（装饰器参数优先）
    if decorator_extra_params:
        result.update(decorator_extra_params)

    return result


def merge_put_extra_params(
    decorator_extra_params: dict[str, Any] | None,
    args: tuple[Any, ...],
    kwargs: dict[str, Any],
) -> dict[str, Any]:
    """合并装饰器参数和用户传入的参数

    将装饰器传递的额外参数、当前调用的 args 和 kwargs 合并到一个字典中。
    用于 PUT 阶段的额外参数传递。

    Args:
        decorator_extra_params: 装饰器传递的额外参数
        args: 函数调用的位置参数
        kwargs: 函数调用的关键字参数

    Returns:
        合并后的额外参数字典
    """
    result: dict[str, Any] = {}

    # 添加装饰器传递的额外参数
    if decorator_extra_params:
        result.update(decorator_extra_params)

    # 添加用户传入的参数（注意：args 可能是 list 或 tuple，直接存储）
    result["args"] = args
    result["kwargs"] = kwargs

    return result


def parse_reflash_params(
    get_result: Result[Any],
) -> tuple[tuple[Any, ...], dict[str, Any]]:
    """从 client_error 的 data 中解析刷新参数

    Args:
        get_result: value_loader.get 返回的 Result 对象

    Returns:
        (args, kwargs) 元组，用于重新调用函数

    Raises:
        ValueError: 如果 get_result 不是 client_error 或 data 格式不正确
    """
    if get_result.is_success():
        raise ValueError("get_result 是 success 状态，无法解析刷新参数")

    data = get_result.data
    if not isinstance(data, dict):
        raise ValueError(f"get_result.data 必须是 dict 类型，实际类型: {type(data)}")

    if "args" not in data or "kwargs" not in data:
        raise ValueError("get_result.data 必须包含 args 和 kwargs 字段")

    refresh_args: Any = data.get("args") # type: ignore
    refresh_kwargs: Any = data.get("kwargs") # type: ignore

    # 确保 args 是 tuple 类型（处理可能的 list 类型）
    if isinstance(refresh_args, list):
        refresh_args = tuple(refresh_args) # type: ignore
    elif not isinstance(refresh_args, tuple):
        refresh_args = ()

    # 确保 kwargs 是 dict 类型
    if not isinstance(refresh_kwargs, dict):
        refresh_kwargs = {}

    return cast(tuple[tuple[Any, ...], dict[str, Any]], (refresh_args, refresh_kwargs))

class BaseDataFrameDecorator(BaseCacheDecorator):
    def __init__(
        self,
        name: str | None = None,
        maxsize: int = 0,
        eviction_policy: EvictionPolicy | None = None,
        keygenerator: KeyGenerator = module_function_key_generator,
        value_loader: DataFrameValueLoader | None = None,
        ttl: int = 0,
        **extra_params: Any,  # 用户传递的额外参数,延迟初始化时使用
    ):
        # 初始化父类
        super().__init__(
            name=name,
            maxsize=maxsize,
            eviction_policy=eviction_policy,
            keygenerator=keygenerator,
            ttl=ttl,
            **extra_params,
        )
        # 获取到valueloader
        self._value_loader: DataFrameValueLoader = (
            value_loader or DefaultDataFrameValueLoader()
        )
        self._func = None
        # 保存装饰器传递的额外参数,在 _create_cache 延迟初始化时使用
        self._extra_params = extra_params

        # 保存最后一次调用的参数和 context
        self._last_context: DataFrameLoaderContext | None = None

    @override
    def __call__(self, func: DecoratorTarget) -> DecoratorTarget:
        # 保存函数引用用于延迟初始化
        self._func = func

        @wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            cache_instance = self.get_cache()

            # 构建装饰器额外参数,包含当前装饰器的配置值
            decorator_extra_params: dict[str, Any] = {
                **self._extra_params,  # 子类特有参数
                "name": self._name,
                "maxsize": self._maxsize,
                "ttl": self._ttl,
                "eviction_policy": str(self._eviction_policy) if self._eviction_policy else None,
            }

            # 创建上下文对象
            context = DataFrameLoaderContext(
                func=func,
                args=args,
                kwargs=kwargs,
                cache_name=self._name,
                maxsize=self._maxsize,
                keygenerator=self._keygenerator,
                ttl=self._ttl,
                eviction_policy=self._eviction_policy,
                decorator_extra_params=decorator_extra_params,
            )

            # 保存 context 供后续 get_context() 使用
            self._last_context = context

            # 生成缓存键
            cache_key = context.cache_key
            if cache_key is None:
                raise ValueError("无法生成缓存键")

            # 缓存结果
            cached_result: ResultAny[Any] = cache_instance.get(cache_key)

            # 解析缓存的 DataFrame
            cached_dataframe = parse_cache_dataframe(cached_result)

            # 缓存未命中：调用函数并判断返回类型
            if cached_dataframe is None:
                # 尝试调用函数
                request_data = func(*args, **kwargs)
                context.set_is_call_function_succeed(True)
                request_dataframe = parse_cache_dataframe(request_data)

                if request_dataframe is None:
                    # 不是 DataFrame，直接返回
                    return request_data

                # 是 DataFrame，走缓存逻辑（未命中路径）
                context.set_is_hit(False)

                # PUT 阶段：直接缓存新数据（无旧缓存）
                from pynomad.cache.dataframe.df_cache_types import CacheStage
                context.set_cache_stage(CacheStage.PUT)
                put_result = self._value_loader.put(
                    context=context,
                    cache_data=request_dataframe,  # 无旧缓存时，传入新数据作为 cache_data
                    new_data=request_dataframe,
                )
                put_dataframe = parse_cache_dataframe(put_result)

                if put_dataframe is None:
                    raise ValueError("put 阶段必须返回 DataFrame")

                context.set_is_put_succeed(True)

                # 合并参数并存储
                put_extra_params = merge_put_extra_params(
                    decorator_extra_params=self._extra_params,
                    args=context.args,
                    kwargs=context.kwargs,
                )
                cache_instance.put(
                    key=cache_key,
                    value=put_dataframe,
                    ttl=self._ttl,
                    only_absent=False,
                    extra_params=put_extra_params,
                )

                # 设置 cached_data 为实际的 DataFrame
                context.set_cached_data(put_result)

                # EXTRACT 阶段：提取返回数据
                context.set_cache_stage(CacheStage.EXTRACT)
                extract_result: ResultAny[DataFrame] = self._value_loader.extract(
                    context=context,
                    merged_data=put_dataframe,
                )
                if extract_result.is_error():
                    exception = extract_result.exception if extract_result.exception else Exception("EXTRACT 阶段失败")
                    raise exception
                if extract_result.data is None:
                    raise ValueError("EXTRACT 阶段返回的 data 为 None")

                return context.wrap_result(data_frame=extract_result.data)

            # 缓存命中：走 DataFrame 缓存逻辑
            meta_info = cache_instance.get_meta(key=cache_key)
            if meta_info is not None:
                context.set_meta_info(meta_info)
            context.set_is_hit(True)

            # GET 阶段
            from pynomad.cache.dataframe.df_cache_types import CacheStage
            context.set_cache_stage(CacheStage.GET)
            get_result = self._value_loader.get(
                context=context,
                cache_data=cached_dataframe,
            )
            # 获取成功
            if get_result.is_success():
                context.set_is_call_function_succeed(True)
                context.set_is_put_succeed(True)
                if not isinstance(get_result.data, DataFrame):
                    raise ValueError(f"get 返回的 data 必须是 DataFrame 类型，实际类型: {type(get_result.data)}")

                # 设置 cached_data
                context.set_cached_data(get_result)

                # 更新缓存的访问元信息（refresh_ttl 更新 last_accessed_at 和 access_count）
                cache_instance.refresh_ttl(key=cache_key, ttl=self._ttl)

                return context.wrap_result(data_frame=get_result.data)

            # 获取到刷新参数
            # 获取失败,需要请求方法
            reflash_args,reflash_kwargs=parse_reflash_params(get_result=get_result)
            request_data=func(*reflash_args, **reflash_kwargs)
            context.set_is_call_function_succeed(True)
            request_dataframe=parse_cache_dataframe(request_data)

            if request_dataframe is None:
                raise ValueError("函数必须返回 DataFrame 或 Result[DataFrame]")

            # PUT 阶段
            context.set_cache_stage(CacheStage.PUT)
            put_result=self._value_loader.put(context=context,
                                   cache_data=cached_dataframe,
                                   new_data=request_dataframe)
            put_dataframe=parse_cache_dataframe(put_result)

            if put_dataframe is None:
                raise ValueError("put 阶段必须返回 DataFrame")

            context.set_is_put_succeed(True)

            put_extra_params=merge_put_extra_params(decorator_extra_params=self._extra_params,
                                                     args=context.args,
                                                     kwargs=context.kwargs)
            # 调用缓存实例将数据进行存储
            cache_instance.put(key=cache_key,
                               value=put_dataframe,
                               ttl=self._ttl,
                               only_absent=False,
                               extra_params=put_extra_params)

            # 设置 cached_data
            context.set_cached_data(put_result)

            # EXTRACT 阶段：提取返回数据
            context.set_cache_stage(CacheStage.EXTRACT)
            extract_result: ResultAny[DataFrame] = self._value_loader.extract(
                context=context,
                merged_data=put_dataframe,
            )
            if extract_result.is_error():
                # 获取异常信息并抛出
                exception = extract_result.exception if extract_result.exception else Exception("EXTRACT 阶段失败")
                raise exception
            if extract_result.data is None:
                raise ValueError("EXTRACT 阶段返回的 data 为 None")

            return context.wrap_result(
                    data_frame=extract_result.data
            )

        # 调用父类方法设置 wrapper 属性（添加 clear 和 cache_info）
        deal_wrapper = super().wrapper_setting(func, wrapper)

        # 添加 DataFrame 特有的 get_context() 方法
        deal_wrapper.get_context = self.get_context  # type: ignore[attr-defined]

        return deal_wrapper

    def get_context(self) -> DataFrameLoaderContext | None:
        """获取最后一次调用的上下文

        Returns:
            DataFrameLoaderContext 实例，如果没有调用过则返回 None
        """
        return self._last_context

    def get_context_info(self) -> dict[str, Any]:
        """获取缓存的上下文信息

        返回比基础 cache_info() 更详细的信息，包括 DataFrame 特有的元数据。

        Returns:
            详细的缓存信息字典
        """
        cache_instance = self.get_cache()
        stats: dict[str, Any] = {
            "size": cache_instance.size(),
            "cache_name": self._name,
            "maxsize": self._maxsize,
            "ttl": self._ttl,
            "eviction_policy": str(self._eviction_policy) if self._eviction_policy else None,
        }

        # 添加最后一次调用的上下文信息
        if self._last_context is not None:
            stats["last_context"] = self._last_context.to_dict()

        return stats
