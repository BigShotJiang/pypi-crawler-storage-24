from enum import Enum, auto
from functools import cached_property
from inspect import Parameter, signature
from typing import Any, Protocol, get_args, get_origin

from pandas import DataFrame

from pynomad.cache.core.meta import MetaInfo
from pynomad.cache.core.types import DecoratorTarget, EvictionPolicy, KeyGenerator
from pynomad.cache.dataframe.utils import parse_cache_dataframe
from pynomad.common.exceptions import NeedsRefreshException
from pynomad.common.pys import MethodType, get_method_type
from pynomad.result.result import Result, ResultAny


class CacheStage(Enum):
    """缓存阶段枚举

    定义 DataFrame 缓存装饰器的三个处理阶段：
    - GET: 从缓存提取数据
    - PUT: 合并数据并缓存
    - EXTRACT: 提取返回数据
    """

    GET = auto()  # 从缓存提取
    PUT = auto()  # 合并数据并缓存
    EXTRACT = auto()  # 提取返回数据


class DataFrameLoaderContext:
    """DataFrame 缓存加载器上下文

    统一的数据结构，用于：
    1. 存储装饰器解析后的所有信息（替代 CacheWrapperInfo 和 FunctionReturn）
    2. 作为三阶段（GET/PUT/EXTRACT）的参数传递对象

    设计原则：
    - 必要的参数通过 __init__ 传入
    - 可推导的属性通过 @property 动态计算
    - 支持通过 set 方法动态设置属性
    """

    def __init__(
        self,
        func: DecoratorTarget,
        args: tuple[Any, ...] = (),
        kwargs: dict[str, Any] | None = None,
        cache_stage: CacheStage | None = None,
        cache_name: str | None = None,
        maxsize: int | None = None,
        keygenerator: KeyGenerator | None = None,
        ttl: int | None = None,
        eviction_policy: EvictionPolicy | None = None,
        decorator_extra_params: dict[str, Any] | None = None,
        meta_info: MetaInfo | None = None,
    ):
        """初始化上下文对象

        Args:
            func: 被装饰的函数
            args: 函数的位置参数
            kwargs: 函数的关键字参数
            cache_stage: 缓存阶段
            cache_name: 缓存名称
            maxsize: 缓存容量
            keygenerator: 键生成器
            ttl: 生存时间
            eviction_policy: 淘汰策略
            decorator_extra_params: 装饰器额外参数
            meta_info: 缓存元信息
        """
        # 必要的初始化参数
        self._func: DecoratorTarget = func
        self._args: tuple[Any, ...] = args
        self._kwargs: dict[str, Any] = kwargs or {}
        self._method_type: MethodType = get_method_type(func)

        # 装饰器参数
        self._cache_stage: CacheStage | None = cache_stage
        self._cache_name: str | None = cache_name
        self._maxsize: int | None = maxsize
        self._keygenerator: KeyGenerator | None = keygenerator
        self._ttl: int | None = ttl
        self._eviction_policy: EvictionPolicy | None = eviction_policy
        self._decorator_extra_params: dict[str, Any] = decorator_extra_params or {}

        # 元数据相关
        self._meta_info: MetaInfo | None = meta_info

        # 动态信息（可通过 set 方法设置）
        self._is_hit: bool | None = None
        self._cache_key: str | None = None
        self._is_call_function_succeed: bool | None = None
        self._is_put_succeed: bool | None = None

        # 返回值类型分析（懒加载）
        self._return_type: type[Any] | None = None
        self._is_dataframe: bool | None = None
        self._is_defined_returntype: bool | None = None

        # 缓存数据（用于判断是否是 DataFrame 类型）
        self._cached_data: Result[Any] | None = None

    # =============动态信息（可设置）================

    @property
    def cache_stage(self) -> CacheStage | None:
        return self._cache_stage

    def set_cache_stage(self, value: CacheStage) -> None:
        self._cache_stage = value

    @property
    def is_hit(self) -> bool | None:
        return self._is_hit

    def set_is_hit(self, value: bool) -> None:
        self._is_hit = value

    @property
    def cache_key(self) -> str | None:
        """缓存键，可通过 keygenerator 生成"""
        if self._cache_key is not None:
            return self._cache_key

        # 如果设置了 keygenerator，则生成缓存键
        if self._keygenerator is not None:
            self._cache_key = self._keygenerator(
                self.func,
                self.func_owner,
                self.args,
                self.kwargs,
            )
        return self._cache_key

    def set_cache_key(self, value: str) -> None:
        self._cache_key = value

    @property
    def is_call_function_succeed(self) -> bool | None:
        return self._is_call_function_succeed

    def set_is_call_function_succeed(self, value: bool) -> None:
        self._is_call_function_succeed = value

    @property
    def is_put_succeed(self) -> bool | None:
        return self._is_put_succeed

    def set_is_put_succeed(self, value: bool) -> None:
        self._is_put_succeed = value

    @property
    def cached_data(self) -> Result[Any] | None:
        """缓存数据，用于在没有返回类型注解时判断是否为 DataFrame"""
        return self._cached_data

    def set_cached_data(self, value: Result[Any]) -> None:
        """设置缓存数据"""
        self._cached_data = value
        # 清除缓存的 is_dataframe 状态，以便重新计算
        self._is_dataframe = None

    # =============装饰器参数================

    @property
    def cache_name(self) -> str | None:
        return self._cache_name

    def set_cache_name(self, value: str) -> None:
        self._cache_name = value

    @property
    def maxsize(self) -> int | None:
        return self._maxsize

    def set_maxsize(self, value: int) -> None:
        self._maxsize = value

    @property
    def keygenerator(self) -> KeyGenerator | None:
        return self._keygenerator

    def set_keygenerator(self, value: KeyGenerator) -> None:
        self._keygenerator = value

    @property
    def ttl(self) -> int | None:
        return self._ttl

    def set_ttl(self, value: int) -> None:
        self._ttl = value

    @property
    def eviction_policy(self) -> EvictionPolicy | None:
        return self._eviction_policy

    def set_eviction_policy(self, value: EvictionPolicy) -> None:
        self._eviction_policy = value

    @property
    def decorator_extra_params(self) -> dict[str, Any]:
        return self._decorator_extra_params

    def set_decorator_extra_params(self, value: dict[str, Any]) -> None:
        self._decorator_extra_params = value

    # =============元数据相关================

    @property
    def meta_info(self) -> MetaInfo | None:
        return self._meta_info

    def set_meta_info(self, value: MetaInfo) -> None:
        self._meta_info = value

    @property
    def last_visit_args(self) -> tuple[Any, ...]:
        """从元数据的 extra_params 中提取上次访问的 args"""
        if (
            self._meta_info
            and self._meta_info.extra_params
            and "args" in self._meta_info.extra_params
        ):
            args_data: Any = self._meta_info.extra_params["args"]
            if isinstance(args_data, list):
                return tuple(args_data)  # type: ignore[arg-type]
            if isinstance(args_data, tuple):
                return args_data  # type: ignore
        return ()

    @property
    def last_visit_kwargs(self) -> dict[str, Any]:
        """从元数据的 extra_params 中提取上次访问的 kwargs"""
        if (
            self._meta_info
            and self._meta_info.extra_params
            and "kwargs" in self._meta_info.extra_params
        ):
            kwargs_data = self._meta_info.extra_params["kwargs"]
            if isinstance(kwargs_data, dict):
                return kwargs_data  # type: ignore
        return {}

    @property
    def last_visit_full_kwargs(self) -> dict[str, Any]:
        """从元数据的 extra_params 中提取上次访问的 full_kwargs（如果有）"""
        if (
            self._meta_info
            and self._meta_info.extra_params
            and "full_kwargs" in self._meta_info.extra_params
        ):
            full_kwargs = self._meta_info.extra_params["full_kwargs"]
            if isinstance(full_kwargs, dict):
                return full_kwargs  # type: ignore
        # 如果没有 full_kwargs，尝试从 args 和 kwargs 构造
        result: dict[str, Any] = {}
        args = self.last_visit_args
        if args:
            result["args"] = args
        kwargs = self.last_visit_kwargs
        if kwargs:
            result.update(kwargs)
        return result

    # =============被装饰方法相关================

    @cached_property
    def method_type(self) -> MethodType:
        return self._method_type

    @property
    def func(self) -> DecoratorTarget:
        return self._func

    @property
    def args(self) -> tuple[Any, ...]:
        """返回位置参数，排除实例方法和类方法的第一个参数（self/cls）"""
        if self.method_type in (
            MethodType.INSTANCE_FUNCTION,
            MethodType.CLASS_FUNCTION,
        ):
            return self._args[1:] if len(self._args) > 1 else ()
        return self._args

    @property
    def kwargs(self) -> dict[str, Any]:
        return self._kwargs

    @cached_property
    def full_kwargs(self) -> dict[str, Any]:
        """将所有参数合并为字典（位置参数转换为字典）"""
        result: dict[str, Any] = {}

        # 获取函数签名信息
        sig = signature(self._func)
        parameters = sig.parameters

        # 处理位置参数
        if self.method_type in (
            MethodType.INSTANCE_FUNCTION,
            MethodType.CLASS_FUNCTION,
        ):
            # 跳过第一个参数（self/cls）
            param_list = list(parameters.items())[1:]
        else:
            param_list = list(parameters.items())

        for idx, (param_name, param) in enumerate(param_list):
            if idx < len(self.args):
                # 位置参数
                result[param_name] = self.args[idx]
            elif param.default != Parameter.empty:
                # 默认值
                result[param_name] = param.default

        # 添加关键字参数
        result.update(self._kwargs)

        return result

    @property
    def func_owner(self) -> Any:
        """获取方法所属的实例或类对象"""
        if self.method_type in (
            MethodType.INSTANCE_FUNCTION,
            MethodType.CLASS_FUNCTION,
        ):
            if self._args:
                return self._args[0]
        return None

    # =============返回值类型分析================

    @property
    def return_type(self) -> type[Any] | None:
        """函数的返回类型注解"""
        if self._return_type is None:
            return_annotation = signature(self._func).return_annotation
            self._return_type = (
                return_annotation if return_annotation is not Parameter.empty else None
            )
        return self._return_type

    @property
    def is_defined_returntype(self) -> bool:
        """检查函数是否定义了返回类型注解"""
        if self._is_defined_returntype is None:
            self._is_defined_returntype = self.return_type is not None
        return self._is_defined_returntype

    @property
    def is_dataframe(self) -> bool:
        """判断函数返回值是否为 DataFrame 类型"""
        if self._is_dataframe is None:
            from pandas import DataFrame as DF

            self._is_dataframe = self._check_is_dataframe(DF)

        return self._is_dataframe

    def _check_is_dataframe(self, dataframe_class: type) -> bool:
        """内部方法：检查返回值是否为 DataFrame 类型"""
        # 情况1: 有返回值签名，检测返回值签名
        if self.is_defined_returntype:
            return_annotation = self.return_type

            if return_annotation is None:
                return False

            # 1.1 如果返回值签名是 DataFrame，返回 True
            if return_annotation is dataframe_class:
                return True

            # 1.2 如果返回值类型是 Result，且为泛型，检测泛型是否为 DataFrame
            origin = get_origin(return_annotation)
            if origin is Result:
                type_args = get_args(return_annotation)
                if type_args and len(type_args) > 0:
                    if type_args[0] is dataframe_class:
                        return True

        # 情况2: 无返回值签名，通过 cached_data 判断
        # 防御性检查: 确保 cached_data 不为 None
        if self._cached_data is None:
            return False

        # 检查 cached_data.data 是否存在
        if self._cached_data.data is None:
            return False

        data = self._cached_data.data

        # 2.1 查看 cached_data.data 是否为 DataFrame 类型
        if isinstance(data, dataframe_class):
            return True

        # 2.2 查看 cached_data.data 是否为 Result 类型，进行二次解包
        if isinstance(data, Result):
            # 二次解包: 获取 result.data
            result_data = cast(object, data.data)  # type: ignore
            # 防御性检查: 确保 result.data 不为 None
            if result_data is not None:
                # 检查二次解包后的数据是否为 DataFrame
                if isinstance(result_data, dataframe_class):
                    return True

        return False

    def should_wrapper(self) -> bool:
        """判断是否需要对返回值进行包装为 Result[DataFrame]

        检查逻辑：
        1. 如果返回值注解是 Result 类型，返回 True

        Returns:
            True: 需要对返回值进行包装
            False: 不需要对返回值进行包装
        """
        if self.is_defined_returntype:
            return_annotation = self.return_type

            if return_annotation is not None:
                if return_annotation is Result:
                    return True

                origin = get_origin(return_annotation)
                if origin is Result:
                    return True

        return False

    def wrap_result(self, data_frame: DataFrame) -> DataFrame | Result[DataFrame]:
        """根据函数的返回类型决定是否包装 DataFrame

        Args:
            data_frame: 要返回的 DataFrame

        Returns:
            如果函数返回类型是 Result，则返回 Result[DataFrame]
            否则直接返回 DataFrame
        """
        if self.should_wrapper():
            return Result[DataFrame].success(data=data_frame)
        return data_frame

    def to_dict(self) -> dict[str, Any]:
        """转换为 JSON 字符串

        Returns:
            包含上下文所有信息的 JSON 字符串
        """
        result: dict[str, Any] = {
            "func_name": getattr(self._func, "__name__", None),
            "func_module": getattr(self._func, "__module__", None),
            "cache_stage": self._cache_stage.name if self._cache_stage else None,  # type: ignore[reportUnnecessaryComparison]
            "cache_name": self._cache_name,
            "cache_key": self._cache_key,
            "maxsize": self._maxsize,
            "ttl": self._ttl,
            "eviction_policy": self._eviction_policy,
            "is_hit": self._is_hit,
            "is_dataframe": self.is_dataframe,
            "is_defined_returntype": self.is_defined_returntype,
            "is_call_function_succeed": self._is_call_function_succeed,
            "is_put_succeed": self._is_put_succeed,
            "method_type": self._method_type.name if self._method_type else None,
            "args": self._args,
            "kwargs": self._kwargs,
            "decorator_extra_params": self._decorator_extra_params,
        }

        # 添加 meta_info 信息
        if self._meta_info is not None:
            result["meta_info"] = self._meta_info.to_dict()
        else:
            result["meta_info"] = None

        # 添加可计算的属性
        result["full_kwargs"] = self.full_kwargs
        result["last_visit_args"] = self.last_visit_args
        result["last_visit_kwargs"] = self.last_visit_kwargs
        result["last_visit_full_kwargs"] = self.last_visit_full_kwargs
        result["func_owner"] = self.func_owner
        return result

    def __repr__(self) -> str:
        """返回对象表示


        Returns:
            包含类名和关键信息的字符串
        """
        return f"DataFrameLoaderContext(func={getattr(self._func, '__name__', None)}, cache_key={self._cache_key}, cache_stage={self._cache_stage})"  # type: ignore[reportUnnecessaryComparison]

    def __call__(
        self, *call_args: Any, **call_kwargs: Any
    ) -> DataFrame | Result[DataFrame]:
        """调用原始函数并返回结果

        此方法让 DataFrameLoaderContext 成为可调用对象，方便在各个缓存阶段中调用原始函数。

        Args:
            *call_args: 调用时的位置参数（如果提供，则覆盖 context 中的 args）
            **call_kwargs: 调用时的关键字参数（如果提供，则覆盖 context 中的 kwargs）

        Returns:
            根据 should_wrapper() 决定返回 DataFrame 或 Result[DataFrame]
        """
        # 使用传入的参数，如果没有则使用 context 中的参数
        args = call_args if call_args else self._args
        kwargs = call_kwargs if call_kwargs else self._kwargs

        # 调用原始函数
        result = self._func(*args, **kwargs)

        # 解析 DataFrame
        dataframe = parse_cache_dataframe(result)

        if dataframe is None:
            raise ValueError(
                f"函数 {getattr(self._func, '__name__', 'unknown')} 必须返回 DataFrame 或 Result[DataFrame]"
            )

        # 根据 should_wrapper 决定是否包装
        return self.wrap_result(data_frame=dataframe)

    def is_hit_cache(self, cache_data: Result[Any]) -> bool:
        """判断缓存是否命中

        Args:
            cache_data: 从缓存获取的数据

        Returns:
            True: 缓存命中
            False: 缓存未命中
        """
        if cache_data is None:  # type: ignore
            return False

        if not cache_data.is_success():
            return False

        if cache_data.data is None:
            return False

        return True


class DataFrameValueLoader(Protocol):
    """DataFrame 值加载器协议

    用于 DataFrame 缓存装饰器的三阶段数据处理：
    1. GET: 从缓存中提取数据，失败时抛出 NeedsRefreshException
    2. PUT: 合并缓存数据和新数据
    3. EXTRACT: 从合并后的数据中提取最终返回数据

    注意：缓存的数据和返回的数据可能不同
    """

    def get(
        self,
        context: DataFrameLoaderContext,
        cache_data: DataFrame,
    ) -> Result[DataFrame | dict[str, Any]]:
        """GET 阶段：从缓存提取数据
        Args:
            context: DataFrame 加载器上下文，包含所有必要信息
            cache_data: 从缓存获取的 DataFrame

        Returns:
            缓存可用返回 success（携带 DataFrame）,已经处理好的DataFrame
            缓存不可用返回 client_error（携带 NeedsRefreshException 和刷新参数 dict）
        """
        ...

    def put(
        self,
        context: DataFrameLoaderContext,
        cache_data: DataFrame,
        new_data: DataFrame,
    ) -> ResultAny[DataFrame]:
        """PUT 阶段：合并缓存数据和新数据

        Args:
            context: DataFrame 加载器上下文，包含所有必要信息
            cache_data: 原缓存中的 DataFrame
            new_data: 新获取的 DataFrame

        Returns:
            合并后的需要缓存的 DataFrame
        """
        ...

    def extract(
        self,
        context: DataFrameLoaderContext,
        merged_data: DataFrame,
    ) -> ResultAny[DataFrame]:
        """EXTRACT 阶段：从合并数据中提取返回数据

        Args:
            context: DataFrame 加载器上下文，包含所有必要信息
            merged_data: 合并后的 DataFrame（将被缓存）

        Returns:
            最终返回给调用方的 DataFrame（可能与 merged_data 不同）
        """
        ...


class DefaultDataFrameValueLoader:
    """默认的 DataFrame 值加载器

    提供最简单的缓存逻辑：
    - GET: 参数相同返回缓存，不同抛出 NeedsRefreshException
    - PUT: 直接返回新数据（不合并）
    - EXTRACT: 直接返回传入数据

    适用于不需要复杂合并逻辑的场景。
    """

    def get(
        self,
        context: DataFrameLoaderContext,
        cache_data: DataFrame,
    ) -> Result[DataFrame | dict[str, Any]]:
        """GET 阶段：比较参数，相同则返回缓存

        Args:
            context: DataFrame 加载器上下文
            cache_data: 从缓存获取的 DataFrame

        Returns:
            参数相同返回 success（携带 DataFrame）
            参数不同返回 client_error（携带 NeedsRefreshException 和刷新参数 dict）,通常包含args和kwargs这两个key
        """
        # 获取上次缓存的参数
        last_args = context.last_visit_args
        last_kwargs = context.last_visit_kwargs

        # 比较参数是否相同
        if last_args == context.args and last_kwargs == context.kwargs:
            # 参数相同，返回缓存数据
            return Result[DataFrame | dict[str, Any]].success(data=cache_data)

        # 参数不同，返回客户端错误
        return Result[DataFrame | dict[str, Any]].client_error(
            exception=NeedsRefreshException(message="参数已变化，需要刷新数据"),
            data={"args": context.args, "kwargs": context.kwargs},
        )

    def put(
        self,
        context: DataFrameLoaderContext,
        cache_data: DataFrame,
        new_data: DataFrame,
    ) -> ResultAny[DataFrame]:
        """PUT 阶段：直接返回新数据

        Args:
            context: DataFrame 加载器上下文
            cache_data: 原缓存中的 DataFrame（未使用）
            new_data: 新获取的 DataFrame

        Returns:
            新获取的 DataFrame（直接覆盖缓存）
        """
        _ = context
        _ = cache_data
        return Result[DataFrame].success(data=new_data)

    def extract(
        self,
        context: DataFrameLoaderContext,
        merged_data: DataFrame,
    ) -> ResultAny[DataFrame]:
        """EXTRACT 阶段：直接返回传入数据

        Args:
            context: DataFrame 加载器上下文
            merged_data: 合并后的 DataFrame（将被缓存）

        Returns:
            直接返回传入的 DataFrame
        """
        _ = context
        return Result[DataFrame].success(data=merged_data)
