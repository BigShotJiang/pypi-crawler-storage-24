# import warnings

__version__ = "0.1.7"

import pynomad.common.datetime_util as dt
import pynomad.cache.properties as cp
import pynomad.common.exceptions as ex
import pynomad.naming.exceptions as nex
import pynomad.naming.naming as naming
from pynomad.naming.naming_types import NameStyle
from pynomad.common.network import check_network, stop_check_network
from pynomad.common.decorator import singleton, retry, thread_safe
from pynomad.common.environment import environ
from pynomad.common.enhandce_dict import EnhancedDict
from pynomad.common.environment import get_project_dir, get_project_name
from pynomad.common.pys import get_method_type,get_method_info
from pynomad.common import strings
from pynomad.common.types import Level, OutputTarget
from pynomad.result import Result, ResultAny,ResultHandler,HandleResult
from pynomad.result.decorator import (
    result,
    ignore_result,
    client_result,
    network_result,
    server_result,
    third_party_result,
    json_result,
    dict_result,
)
from pynomad.logsystem.manager import get_logger
from pynomad.config.loader.manager import get_config
from pynomad.config.auto.properties import BuiltinProperties
from pynomad.config.auto.field_info import field
from pynomad.config.auto.autoconfig import (
    inject,
    alias,
    clear_config_cache,
    set_active_environment,
)
from pynomad.config.auto.generate.generator import ConfigGenerator
from pynomad.config import add_loader, add_file_loader, remove_loader
from pynomad.cache.dataframe.df_cache_types import DataFrameValueLoader
__all__ = [
    # 模块导入
    "dt",
    "ex",
    "nex",
    "cp",
    "strings",
    "naming",
    # 通用装饰器导入
    "singleton",
    "retry",
    "thread_safe",
    # 通用方法导入
    "get_logger",
    "check_network",
    "stop_check_network",
    "get_project_dir",
    "get_project_name",
    "get_method_type",
    "get_method_info",
    # 返回类导入
    "Result",
    "ResultAny",
    # Result 装饰器导入
    "result",
    "ignore_result",
    "client_result",
    "network_result",
    "server_result",
    "third_party_result",
    "json_result",
    "dict_result",
    "ResultHandler",
    "HandleResult",
    # 属性类注入
    "BuiltinProperties",
    # 属性注入
    "environ",
    # 类导出
    "EnhancedDict",
    # 类型导出
    "Level",
    "OutputTarget",
    "NameStyle",
    "DataFrameValueLoader",
    # 配置导出
    "field",
    "inject",
    "alias",
    "ConfigGenerator",
    "clear_config_cache",
    "add_loader",
    "add_file_loader",
    "remove_loader",
    "get_config",
    "set_active_environment",
]

# 动态导入基础缓存装饰器
from pynomad.cache.decorator.memory_decorator import memcached
from pynomad.cache.decorator.pickle_decorator import pickled
from pynomad.cache.decorator.multi_cached import multi_cached

__all__.extend(["memcached", "pickled", "multi_cached"])

# 动态添加可选依赖的导入
try:
    from pynomad.cache.decorator.redis_decorator import rediscached  # type: ignore

    __all__.append("rediscached")
except ImportError as e:
    # warnings.warn(f"无法导入 redis 缓存装饰器: {e}。如需使用，请安装 redis 依赖")
    pass
try:
    from pynomad.cache.dataframe.df_redis_decorator import df_rediscached  # type: ignore

    __all__.append("df_rediscached")
except ImportError as e:
    # warnings.warn(
    #     f"无法导入 df_rediscached 缓存装饰器: {e}。如需使用，请安装 redis和pandas 依赖"
    # )
    pass
try:
    import sqlalchemy  # type: ignore # 检查 sqlalchemy 是否安装
    from pynomad.cache.decorator.sql_decorator import sqlcached
    from pynomad.cache.impl.sql_cache import SQLCache  # type: ignore # 添加导入

    __all__.append("sqlcached")
except ImportError as e:
    # warnings.warn(f"无法导入 SQL 缓存装饰器: {e}。如需使用，请安装 sqlalchemy 依赖")
    pass

try:

    from pynomad.cache.dataframe.df_memory_decorator import df_memcached
    from pynomad.cache.dataframe.df_pickle_decorator import df_pickled

    __all__.extend(["df_memcached", "df_pickled"])
except ImportError as e:
    # warnings.warn(f"无法导入 DataFrame 缓存装饰器: {e}。如需使用，请安装 pandas 依赖")
    pass
