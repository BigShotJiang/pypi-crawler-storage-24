#!/usr/bin/env python
# encoding: utf-8
#
#  ------------------------------------------------------------------------------
#  Name: exceptions.py
#  Version: 0.0.1
#  Summary: Bacen IF.data AutoScraper & Data Manager
#           Este sistema foi projetado para automatizar o download dos
#           relatórios da ferramenta IF.data do Banco Central do Brasil.
#           Criado para facilitar a integração com ferramentas automatizadas de
#           análise e visualização de dados, garantido acesso fácil e oportuno
#           aos dados.
#
#  Author: Alexsander Lopes Camargos
#  Author-email: alcamargos@vivaldi.net
#
#  License: MIT
#  ------------------------------------------------------------------------------

"""Exceptions for Bacen IF.data AutoScraper & Data Manager"""


class IfDataScraperException(Exception):
    """Base class for exceptions in this module."""

    def __init__(self, message: str = '') -> None:
        """Initialize the IfDataScraperException with an optional message.

        Args:
            message (str): The error message.
        """

        self.message = f'An error occurred: {message}'
        # Call the base class constructor with the parameters it needs.
        super().__init__(self.message)
