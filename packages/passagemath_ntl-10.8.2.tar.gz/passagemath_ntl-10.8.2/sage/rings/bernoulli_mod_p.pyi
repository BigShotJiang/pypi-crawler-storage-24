# sage_setup: distribution = sagemath-ntl

def verify_bernoulli_mod_p(data: list[int]) -> bool:
    ...

def bernoulli_mod_p(p: int) -> list[int]:
    ...

def bernoulli_mod_p_single(p: int, k: int) -> int:
    ...
