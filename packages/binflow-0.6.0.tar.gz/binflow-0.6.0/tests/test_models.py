"""Tests unitarios para modelos de datos y configuracion."""

from market_streaming.config import MARKET_URLS, Market, Config
from market_streaming.models import (
    AggTrade,
    BookTicker,
    Kline,
    Liquidation,
    MarkPrice,
    MiniTicker,
    OrderBookLevel,
    OrderBookSnapshot,
    StreamState,
    StreamStatus,
    StreamType,
    Ticker,
    Trade,
)


class TestTrade:
    def test_trade_is_frozen(self) -> None:
        trade = Trade(
            symbol="BTCUSDT",
            trade_id=1,
            price=50000.0,
            quantity=0.1,
            quote_quantity=5000.0,
            buyer_maker=False,
            timestamp_ms=1000,
        )
        try:
            trade.price = 99999.0  # type: ignore[misc]
            assert False, "Trade deberia ser inmutable"
        except AttributeError:
            pass

    def test_trade_fields(self) -> None:
        trade = Trade(
            symbol="ETHUSDT",
            trade_id=42,
            price=3000.0,
            quantity=1.5,
            quote_quantity=4500.0,
            buyer_maker=True,
            timestamp_ms=1234567890,
            price_str="3000.00000000",
            quantity_str="1.50000000",
            quote_quantity_str="4500.00000000",
            is_best_match=True,
            event_time_ms=1234567891,
        )
        assert trade.symbol == "ETHUSDT"
        assert trade.trade_id == 42
        assert trade.buyer_maker is True
        assert trade.quote_quantity == 4500.0
        assert trade.is_best_match is True
        assert trade.price_str == "3000.00000000"

    def test_trade_to_rest_format(self) -> None:
        trade = Trade(
            symbol="BTCUSDT",
            trade_id=100,
            price=68332.01,
            quantity=0.00016,
            quote_quantity=10.933122,
            buyer_maker=False,
            timestamp_ms=1499865549590,
            price_str="68332.01000000",
            quantity_str="0.00016000",
            quote_quantity_str="10.93312160",
        )
        rest = trade.to_rest_format()
        assert rest == {
            "id": 100,
            "price": "68332.01000000",
            "qty": "0.00016000",
            "quoteQty": "10.93312160",
            "time": 1499865549590,
            "isBuyerMaker": False,
            "isBestMatch": True,
        }

    def test_trade_defaults(self) -> None:
        trade = Trade(
            symbol="BTCUSDT",
            trade_id=1,
            price=100.0,
            quantity=1.0,
            quote_quantity=100.0,
            buyer_maker=False,
            timestamp_ms=1000,
        )
        assert trade.is_best_match is True
        assert trade.event_time_ms == 0
        assert trade.price_str == ""
        assert trade.quantity_str == ""


class TestOrderBookLevel:
    def test_level_is_frozen(self) -> None:
        level = OrderBookLevel(price=100.0, quantity=1.0)
        try:
            level.price = 200.0  # type: ignore[misc]
            assert False, "OrderBookLevel deberia ser inmutable"
        except AttributeError:
            pass

    def test_level_with_strings(self) -> None:
        level = OrderBookLevel(
            price=50000.0, quantity=1.5,
            price_str="50000.00000000", quantity_str="1.50000000",
        )
        assert level.price_str == "50000.00000000"
        assert level.to_rest_format() == ["50000.00000000", "1.50000000"]

    def test_level_to_rest_fallback(self) -> None:
        level = OrderBookLevel(price=100.0, quantity=2.0)
        rest = level.to_rest_format()
        assert len(rest) == 2
        assert float(rest[0]) == 100.0


class TestOrderBookSnapshot:
    def test_default_values(self) -> None:
        snap = OrderBookSnapshot(symbol="BTCUSDT")
        assert snap.bids == []
        assert snap.asks == []
        assert snap.last_update_id == 0
        assert snap.timestamp > 0
        assert snap.event_time_ms == 0
        assert snap.transaction_time_ms == 0

    def test_to_rest_format(self) -> None:
        snap = OrderBookSnapshot(
            symbol="BTCUSDT",
            bids=[OrderBookLevel(50000.0, 1.0, "50000.00", "1.00")],
            asks=[OrderBookLevel(50001.0, 0.5, "50001.00", "0.50")],
            last_update_id=12345,
        )
        rest = snap.to_rest_format()
        assert rest == {
            "lastUpdateId": 12345,
            "bids": [["50000.00", "1.00"]],
            "asks": [["50001.00", "0.50"]],
        }


class TestOrderBookSnapshotSync:
    def test_is_synced_default_false(self) -> None:
        snap = OrderBookSnapshot(symbol="BTCUSDT")
        assert snap.is_synced is False

    def test_is_synced_explicit_true(self) -> None:
        snap = OrderBookSnapshot(symbol="BTCUSDT", is_synced=True)
        assert snap.is_synced is True

    def test_to_rest_format_excludes_is_synced(self) -> None:
        snap = OrderBookSnapshot(
            symbol="BTCUSDT", is_synced=True, last_update_id=1,
        )
        rest = snap.to_rest_format()
        assert "is_synced" not in rest


class TestStreamStatus:
    def test_default_state(self) -> None:
        status = StreamStatus(
            stream_id="test",
            stream_type=StreamType.TRADE,
            symbol="BTCUSDT",
        )
        assert status.state == StreamState.STARTING
        assert status.message_count == 0
        assert status.error_count == 0
        assert status.reconnect_count == 0


class TestStreamState:
    def test_string_values(self) -> None:
        assert StreamState.RUNNING == "running"
        assert StreamState.STALE == "stale"
        assert StreamState.RECONNECTING == "reconnecting"


class TestMarket:
    def test_market_values(self) -> None:
        assert Market.SPOT == "spot"
        assert Market.FUTURES_USD == "futures_usd"
        assert Market.FUTURES_COIN == "futures_coin"

    def test_all_markets_have_urls(self) -> None:
        for market in Market:
            assert market in MARKET_URLS


class TestConfig:
    def test_default_is_spot(self) -> None:
        config = Config(stream_type="ticker")
        assert config.market == Market.SPOT
        assert "stream.binance.com" in config.base_url

    def test_futures_usd(self) -> None:
        config = Config(market=Market.FUTURES_USD, stream_type="ticker")
        assert "fstream.binance.com" in config.base_url

    def test_futures_coin(self) -> None:
        config = Config(market=Market.FUTURES_COIN, stream_type="ticker")
        assert "dstream.binance.com" in config.base_url

    def test_custom_url_overrides_market(self) -> None:
        config = Config(
            market=Market.SPOT,
            stream_type="ticker",
            base_url="wss://custom.example.com/ws",
        )
        assert config.base_url == "wss://custom.example.com/ws"

    def test_rest_depth_url_spot(self) -> None:
        config = Config(market=Market.SPOT, stream_type="ticker")
        url = config.rest_depth_url("BTCUSDT", 1000)
        assert url == "https://api.binance.com/api/v3/depth?symbol=BTCUSDT&limit=1000"

    def test_rest_depth_url_futures_usd(self) -> None:
        config = Config(market=Market.FUTURES_USD, stream_type="ticker")
        url = config.rest_depth_url("BTCUSDT", 500)
        assert url == "https://fapi.binance.com/fapi/v1/depth?symbol=BTCUSDT&limit=500"

    def test_rest_depth_url_futures_coin(self) -> None:
        config = Config(market=Market.FUTURES_COIN, stream_type="ticker")
        url = config.rest_depth_url("BTCUSD_PERP", 100)
        assert url == "https://dapi.binance.com/dapi/v1/depth?symbol=BTCUSD_PERP&limit=100"

    def test_market_accepts_string(self) -> None:
        config = Config(market="futures_usd", stream_type="ticker")
        assert config.market == Market.FUTURES_USD

    def test_stream_type_accepts_string(self) -> None:
        config = Config(stream_type="order_book", depth=10)
        assert config.stream_type == StreamType.DEPTH

    def test_log_level_accepts_string(self) -> None:
        config = Config(stream_type="ticker", log_level="warning")
        import logging
        assert config.log_level == logging.WARNING

    def test_symbols_normalized_uppercase(self) -> None:
        config = Config(stream_type="ticker", symbols=["btcusdt", "ethUSDT"])
        assert config.symbols == ["BTCUSDT", "ETHUSDT"]


class TestAggTrade:
    def test_agg_trade_is_frozen(self) -> None:
        agg = AggTrade(
            symbol="BTCUSDT",
            agg_trade_id=12345,
            price=50000.0,
            quantity=0.001,
            first_trade_id=100,
            last_trade_id=105,
            timestamp_ms=1672515782136,
            buyer_maker=False,
        )
        try:
            agg.price = 99999.0  # type: ignore[misc]
            assert False, "AggTrade deberia ser inmutable"
        except AttributeError:
            pass

    def test_agg_trade_fields(self) -> None:
        agg = AggTrade(
            symbol="BTCUSDT",
            agg_trade_id=12345,
            price=50000.0,
            quantity=0.001,
            first_trade_id=100,
            last_trade_id=105,
            timestamp_ms=1672515782136,
            buyer_maker=False,
            price_str="50000.00",
            quantity_str="0.001",
            event_time_ms=1672515782136,
        )
        assert agg.symbol == "BTCUSDT"
        assert agg.agg_trade_id == 12345
        assert agg.price == 50000.0
        assert agg.quantity == 0.001
        assert agg.first_trade_id == 100
        assert agg.last_trade_id == 105
        assert agg.timestamp_ms == 1672515782136
        assert agg.buyer_maker is False
        assert agg.price_str == "50000.00"
        assert agg.quantity_str == "0.001"
        assert agg.event_time_ms == 1672515782136

    def test_agg_trade_to_rest_format(self) -> None:
        agg = AggTrade(
            symbol="BTCUSDT",
            agg_trade_id=12345,
            price=50000.0,
            quantity=0.001,
            first_trade_id=100,
            last_trade_id=105,
            timestamp_ms=1672515782136,
            buyer_maker=False,
            price_str="50000.00",
            quantity_str="0.001",
        )
        rest = agg.to_rest_format()
        assert rest["a"] == 12345
        assert rest["p"] == "50000.00"
        assert rest["q"] == "0.001"
        assert rest["f"] == 100
        assert rest["l"] == 105
        assert rest["T"] == 1672515782136
        assert rest["m"] is False
        assert rest["M"] is True


class TestKline:
    def test_kline_is_frozen(self) -> None:
        kline = Kline(
            symbol="BTCUSDT",
            interval="1m",
            open_time_ms=1672515780000,
            close_time_ms=1672515839999,
            open=50000.0,
            close=50100.0,
            high=50200.0,
            low=49900.0,
            volume=100.0,
            quote_volume=5000000.0,
            trades=150,
            taker_buy_volume=60.0,
            taker_buy_quote_volume=3000000.0,
            is_closed=False,
        )
        try:
            kline.close = 99999.0  # type: ignore[misc]
            assert False, "Kline deberia ser inmutable"
        except AttributeError:
            pass

    def test_kline_fields(self) -> None:
        kline = Kline(
            symbol="BTCUSDT",
            interval="1m",
            open_time_ms=1672515780000,
            close_time_ms=1672515839999,
            open=50000.0,
            close=50100.0,
            high=50200.0,
            low=49900.0,
            volume=100.0,
            quote_volume=5000000.0,
            trades=150,
            taker_buy_volume=60.0,
            taker_buy_quote_volume=3000000.0,
            is_closed=False,
        )
        assert kline.symbol == "BTCUSDT"
        assert kline.interval == "1m"
        assert kline.open == 50000.0
        assert kline.close == 50100.0
        assert kline.high == 50200.0
        assert kline.low == 49900.0
        assert kline.volume == 100.0
        assert kline.trades == 150
        assert kline.is_closed is False

    def test_kline_to_rest_format(self) -> None:
        kline = Kline(
            symbol="BTCUSDT",
            interval="1m",
            open_time_ms=1672515780000,
            close_time_ms=1672515839999,
            open=50000.0,
            close=50100.0,
            high=50200.0,
            low=49900.0,
            volume=100.0,
            quote_volume=5000000.0,
            trades=150,
            taker_buy_volume=60.0,
            taker_buy_quote_volume=3000000.0,
            is_closed=False,
            open_str="50000.00",
            close_str="50100.00",
            high_str="50200.00",
            low_str="49900.00",
            volume_str="100.00",
            quote_volume_str="5000000.00",
            taker_buy_volume_str="60.00",
            taker_buy_quote_volume_str="3000000.00",
        )
        rest = kline.to_rest_format()
        assert isinstance(rest, list)
        assert len(rest) == 12
        assert rest[0] == 1672515780000  # open_time
        assert rest[1] == "50000.00"     # open
        assert rest[2] == "50200.00"     # high
        assert rest[3] == "49900.00"     # low
        assert rest[4] == "50100.00"     # close
        assert rest[5] == "100.00"       # volume
        assert rest[6] == 1672515839999  # close_time
        assert rest[7] == "5000000.00"   # quote_volume
        assert rest[8] == 150            # trades
        assert rest[9] == "60.00"        # taker_buy_volume
        assert rest[10] == "3000000.00"  # taker_buy_quote_volume
        assert rest[11] == "0"           # ignore


class TestTicker:
    def test_ticker_is_frozen(self) -> None:
        ticker = Ticker(
            symbol="BTCUSDT",
            price_change=500.0,
            price_change_pct=1.0,
            weighted_avg_price=50000.0,
            prev_close_price=49500.0,
            last_price=50000.0,
            last_quantity=0.1,
            best_bid_price=49999.0,
            best_bid_quantity=1.0,
            best_ask_price=50001.0,
            best_ask_quantity=0.5,
            open_price=49500.0,
            high_price=50500.0,
            low_price=49000.0,
            volume=1000.0,
            quote_volume=50000000.0,
            open_time_ms=0,
            close_time_ms=86400000,
            first_trade_id=1,
            last_trade_id=18150,
            trade_count=18151,
        )
        try:
            ticker.last_price = 99999.0  # type: ignore[misc]
            assert False, "Ticker deberia ser inmutable"
        except AttributeError:
            pass

    def test_ticker_to_rest_format(self) -> None:
        ticker = Ticker(
            symbol="BTCUSDT",
            price_change=500.0,
            price_change_pct=1.0,
            weighted_avg_price=50000.0,
            prev_close_price=49500.0,
            last_price=50000.0,
            last_quantity=0.1,
            best_bid_price=49999.0,
            best_bid_quantity=1.0,
            best_ask_price=50001.0,
            best_ask_quantity=0.5,
            open_price=49500.0,
            high_price=50500.0,
            low_price=49000.0,
            volume=1000.0,
            quote_volume=50000000.0,
            open_time_ms=0,
            close_time_ms=86400000,
            first_trade_id=1,
            last_trade_id=18150,
            trade_count=18151,
            price_change_str="500.00",
            last_price_str="50000.00",
        )
        rest = ticker.to_rest_format()
        expected_keys = {
            "symbol", "priceChange", "priceChangePercent", "weightedAvgPrice",
            "prevClosePrice", "lastPrice", "lastQty", "bidPrice", "bidQty",
            "askPrice", "askQty", "openPrice", "highPrice", "lowPrice",
            "volume", "quoteVolume", "openTime", "closeTime", "firstId",
            "lastId", "count",
        }
        assert set(rest.keys()) == expected_keys
        assert rest["symbol"] == "BTCUSDT"
        assert rest["priceChange"] == "500.00"
        assert rest["lastPrice"] == "50000.00"
        assert rest["openTime"] == 0
        assert rest["closeTime"] == 86400000
        assert rest["count"] == 18151


class TestMiniTicker:
    def test_mini_ticker_is_frozen(self) -> None:
        mt = MiniTicker(
            symbol="BTCUSDT",
            close_price=50000.0,
            open_price=49500.0,
            high_price=50500.0,
            low_price=49000.0,
            volume=1000.0,
            quote_volume=50000000.0,
        )
        try:
            mt.close_price = 99999.0  # type: ignore[misc]
            assert False, "MiniTicker deberia ser inmutable"
        except AttributeError:
            pass

    def test_mini_ticker_to_rest_format(self) -> None:
        mt = MiniTicker(
            symbol="BTCUSDT",
            close_price=50000.0,
            open_price=49500.0,
            high_price=50500.0,
            low_price=49000.0,
            volume=1000.0,
            quote_volume=50000000.0,
            close_price_str="50000.00",
            open_price_str="49500.00",
            high_price_str="50500.00",
            low_price_str="49000.00",
            volume_str="1000.00",
            quote_volume_str="50000000.00",
        )
        rest = mt.to_rest_format()
        expected_keys = {
            "symbol", "closePrice", "openPrice", "highPrice",
            "lowPrice", "volume", "quoteVolume",
        }
        assert set(rest.keys()) == expected_keys
        assert rest["symbol"] == "BTCUSDT"
        assert rest["closePrice"] == "50000.00"
        assert rest["openPrice"] == "49500.00"


class TestBookTicker:
    def test_book_ticker_is_frozen(self) -> None:
        bt = BookTicker(
            symbol="BTCUSDT",
            update_id=400900217,
            best_bid_price=49999.0,
            best_bid_quantity=1.0,
            best_ask_price=50001.0,
            best_ask_quantity=0.5,
        )
        try:
            bt.best_bid_price = 99999.0  # type: ignore[misc]
            assert False, "BookTicker deberia ser inmutable"
        except AttributeError:
            pass

    def test_book_ticker_to_rest_format(self) -> None:
        bt = BookTicker(
            symbol="BTCUSDT",
            update_id=400900217,
            best_bid_price=49999.0,
            best_bid_quantity=1.0,
            best_ask_price=50001.0,
            best_ask_quantity=0.5,
            best_bid_price_str="49999.00",
            best_bid_quantity_str="1.0",
            best_ask_price_str="50001.00",
            best_ask_quantity_str="0.5",
        )
        rest = bt.to_rest_format()
        expected_keys = {"symbol", "bidPrice", "bidQty", "askPrice", "askQty"}
        assert set(rest.keys()) == expected_keys
        assert rest["symbol"] == "BTCUSDT"
        assert rest["bidPrice"] == "49999.00"
        assert rest["bidQty"] == "1.0"
        assert rest["askPrice"] == "50001.00"
        assert rest["askQty"] == "0.5"


class TestLiquidation:
    def test_liquidation_is_frozen(self) -> None:
        liq = Liquidation(
            symbol="BTCUSDT",
            side="SELL",
            order_type="LIMIT",
            time_in_force="IOC",
            original_qty=0.014,
            price=9910.0,
            average_price=9910.0,
            status="FILLED",
            last_filled_qty=0.014,
            filled_qty=0.014,
            trade_time_ms=1568014460893,
        )
        try:
            liq.price = 99999.0  # type: ignore[misc]
            assert False, "Liquidation deberia ser inmutable"
        except AttributeError:
            pass

    def test_liquidation_fields(self) -> None:
        liq = Liquidation(
            symbol="BTCUSDT",
            side="SELL",
            order_type="LIMIT",
            time_in_force="IOC",
            original_qty=0.014,
            price=9910.0,
            average_price=9910.0,
            status="FILLED",
            last_filled_qty=0.014,
            filled_qty=0.014,
            trade_time_ms=1568014460893,
            event_time_ms=1568014460893,
            original_qty_str="0.014",
            price_str="9910",
            average_price_str="9910",
            last_filled_qty_str="0.014",
            filled_qty_str="0.014",
        )
        assert liq.symbol == "BTCUSDT"
        assert liq.side == "SELL"
        assert liq.order_type == "LIMIT"
        assert liq.time_in_force == "IOC"
        assert liq.original_qty == 0.014
        assert liq.price == 9910.0
        assert liq.average_price == 9910.0
        assert liq.status == "FILLED"
        assert liq.last_filled_qty == 0.014
        assert liq.filled_qty == 0.014
        assert liq.trade_time_ms == 1568014460893
        assert liq.event_time_ms == 1568014460893
        assert liq.price_str == "9910"

    def test_liquidation_defaults(self) -> None:
        liq = Liquidation(
            symbol="BTCUSDT",
            side="BUY",
            order_type="LIMIT",
            time_in_force="IOC",
            original_qty=1.0,
            price=50000.0,
            average_price=50000.0,
            status="FILLED",
            last_filled_qty=1.0,
            filled_qty=1.0,
            trade_time_ms=1000,
        )
        assert liq.event_time_ms == 0
        assert liq.price_str == ""
        assert liq.original_qty_str == ""

    def test_liquidation_to_rest_format(self) -> None:
        liq = Liquidation(
            symbol="BTCUSDT",
            side="SELL",
            order_type="LIMIT",
            time_in_force="IOC",
            original_qty=0.014,
            price=7918.33,
            average_price=7918.33,
            status="FILLED",
            last_filled_qty=0.014,
            filled_qty=0.014,
            trade_time_ms=1568014460893,
            price_str="7918.33",
            original_qty_str="0.014",
            average_price_str="7918.33",
            filled_qty_str="0.014",
            last_filled_qty_str="0.014",
        )
        rest = liq.to_rest_format()
        assert rest == {
            "symbol": "BTCUSDT",
            "price": "7918.33",
            "origQty": "0.014",
            "executedQty": "0.014",
            "averagePrice": "7918.33",
            "status": "FILLED",
            "timeInForce": "IOC",
            "type": "LIMIT",
            "side": "SELL",
            "time": 1568014460893,
        }


class TestMarkPrice:
    def test_mark_price_is_frozen(self) -> None:
        mp = MarkPrice(
            symbol="BTCUSDT",
            mark_price=68500.0,
            index_price=68490.0,
            estimated_settle_price=0.0,
            funding_rate=0.00010000,
            next_funding_time_ms=1562306400000,
        )
        try:
            mp.mark_price = 99999.0  # type: ignore[misc]
            assert False, "MarkPrice deberia ser inmutable"
        except AttributeError:
            pass

    def test_mark_price_fields(self) -> None:
        mp = MarkPrice(
            symbol="BTCUSDT",
            mark_price=68500.0,
            index_price=68490.0,
            estimated_settle_price=68480.0,
            funding_rate=0.00010000,
            next_funding_time_ms=1562306400000,
            event_time_ms=1562305380000,
            mark_price_str="68500.00000000",
            index_price_str="68490.00000000",
            estimated_settle_price_str="68480.00000000",
            funding_rate_str="0.00010000",
        )
        assert mp.symbol == "BTCUSDT"
        assert mp.mark_price == 68500.0
        assert mp.index_price == 68490.0
        assert mp.estimated_settle_price == 68480.0
        assert mp.funding_rate == 0.00010000
        assert mp.next_funding_time_ms == 1562306400000
        assert mp.event_time_ms == 1562305380000
        assert mp.mark_price_str == "68500.00000000"

    def test_mark_price_defaults(self) -> None:
        mp = MarkPrice(
            symbol="BTCUSDT",
            mark_price=68500.0,
            index_price=68490.0,
            estimated_settle_price=0.0,
            funding_rate=0.0001,
            next_funding_time_ms=1562306400000,
        )
        assert mp.event_time_ms == 0
        assert mp.mark_price_str == ""
        assert mp.index_price_str == ""
        assert mp.estimated_settle_price_str == ""
        assert mp.funding_rate_str == ""

    def test_mark_price_to_rest_format(self) -> None:
        mp = MarkPrice(
            symbol="BTCUSDT",
            mark_price=68500.0,
            index_price=68490.0,
            estimated_settle_price=68480.0,
            funding_rate=0.00010000,
            next_funding_time_ms=1562306400000,
            event_time_ms=1562305380000,
            mark_price_str="68500.00000000",
            index_price_str="68490.00000000",
            estimated_settle_price_str="68480.00000000",
            funding_rate_str="0.00010000",
        )
        rest = mp.to_rest_format()
        assert rest == {
            "symbol": "BTCUSDT",
            "markPrice": "68500.00000000",
            "indexPrice": "68490.00000000",
            "estimatedSettlePrice": "68480.00000000",
            "lastFundingRate": "0.00010000",
            "nextFundingTime": 1562306400000,
            "time": 1562305380000,
        }


class TestStreamTypeNew:
    def test_new_stream_type_values(self) -> None:
        assert StreamType.AGG_TRADE == "aggTrade"
        assert StreamType.KLINE == "kline"
        assert StreamType.TICKER == "ticker"
        assert StreamType.MINI_TICKER == "miniTicker"
        assert StreamType.BOOK_TICKER == "bookTicker"
        assert StreamType.FORCE_ORDER == "forceOrder"
        assert StreamType.MARK_PRICE == "markPrice"
