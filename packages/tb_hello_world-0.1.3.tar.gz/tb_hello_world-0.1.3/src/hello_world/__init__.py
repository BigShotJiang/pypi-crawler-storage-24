"""A minimal hello world package."""

__version__ = "0.1.3"


def hello() -> str:
    """Return a greeting."""
    return "Hello, World! " + __version__
