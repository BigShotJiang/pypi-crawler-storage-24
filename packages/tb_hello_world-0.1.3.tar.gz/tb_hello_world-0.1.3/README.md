# tb-hello-world

A minimal hello world Python package.

## Installation

```bash
pip install tb-hello-world
```

## Usage

```python
from hello_world import hello

print(hello())  # Hello, World!
```

## Build status
```bash
rm -rf dist/
python -m build
twine check dist/*
```

## Publishing to PyPI
**Upload** (from the project directory with `.venv` activated):
```bash
source .venv/bin/activate
python -m twine upload dist/* --verbose
```

When prompted, use `__token__` as the username and your API token as the password.

To test first on TestPyPI:

```bash
python -m twine upload --repository testpypi dist/*
```
