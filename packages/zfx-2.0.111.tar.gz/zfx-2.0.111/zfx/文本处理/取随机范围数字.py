from __future__ import annotations
import random
from typing import Optional


def 取随机范围数字(起始数: int, 结束数: int) -> Optional[int]:
    """
    在指定整数区间内生成一个随机整数（包含边界）。

    本函数基于 `random.randint` 实现，用于生成一个
    位于 [起始数, 结束数] 闭区间范围内的随机整数。

    安全设计说明：
        - 若参数类型不正确，返回 None
        - 若起始数大于结束数，自动交换顺序后再生成
        - 任意异常情况下均返回 None
        - 函数内部不抛出异常

    Args:
        起始数 (int): 随机数范围的下限值（闭区间）。
        结束数 (int): 随机数范围的上限值（闭区间）。

    Returns:
        Optional[int]:
            成功时返回随机整数；
            若参数非法或发生异常，返回 None。

    示例:
        随机数 = 取随机范围数字(1, 100)
    """
    try:
        if not isinstance(起始数, int) or not isinstance(结束数, int):
            return None

        if 起始数 > 结束数:
            起始数, 结束数 = 结束数, 起始数

        return random.randint(起始数, 结束数)

    except Exception:
        return None