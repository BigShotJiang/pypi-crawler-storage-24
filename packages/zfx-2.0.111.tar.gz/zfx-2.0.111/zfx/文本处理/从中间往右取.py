from typing import Optional


def 从中间往右取(
    字符串: str,
    开始位置: int,
    字符数量: int
) -> Optional[str]:
    """
    从指定起始位置向右提取固定数量的字符。

    本函数采用“安全返回”设计原则：
        - 参数合法时返回字符串结果
        - 参数非法时返回 None
        - 函数内部绝不抛出异常

    Args:
        字符串 (str): 输入字符串。
        开始位置 (int): 起始索引（从 0 开始）。
        字符数量 (int): 需要提取的字符长度。

    Returns:
        Optional[str]:
            - 成功时返回截取后的字符串（可能为空字符串）
            - 参数非法时返回 None

    规则说明:
        - 不支持负数索引
        - 若 开始位置 等于字符串长度，将返回空字符串
        - 若 字符数量 为 0，将返回空字符串
        - 若 截取范围超出长度，自动截断
    """

    # 类型校验
    if not isinstance(字符串, str):
        return None
    if not isinstance(开始位置, int):
        return None
    if not isinstance(字符数量, int):
        return None

    # 数值校验
    if 开始位置 < 0 or 字符数量 < 0:
        return None
    if 开始位置 > len(字符串):
        return None

    return 字符串[开始位置:开始位置 + 字符数量]