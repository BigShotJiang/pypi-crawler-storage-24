from __future__ import annotations
import random
from typing import Optional


def 取随机范围小数(
    起始数: float,
    结束数: float,
    小数位数: int = 2
) -> Optional[float]:
    """
    在指定浮点区间内生成一个指定小数位数的随机数（包含边界）。

    本函数通过“整数放大法”保证小数精度稳定，
    适用于金额、比例、概率等对精度有要求的场景。

    安全设计说明：
        - 若参数类型不正确，返回 None
        - 若小数位数为负数，返回 None
        - 若起始数大于结束数，自动交换
        - 任意异常情况下返回 None
        - 函数内部不抛出异常

    Args:
        起始数 (float): 随机数范围下限（闭区间）
        结束数 (float): 随机数范围上限（闭区间）
        小数位数 (int): 保留的小数位数，默认 2

    Returns:
        Optional[float]: 成功返回随机浮点数，失败返回 None
    """
    try:
        if not isinstance(小数位数, int) or 小数位数 < 0:
            return None

        if 起始数 > 结束数:
            起始数, 结束数 = 结束数, 起始数

        倍数 = 10 ** 小数位数
        最小整数 = int(round(起始数 * 倍数))
        最大整数 = int(round(结束数 * 倍数))

        随机整数 = random.randint(最小整数, 最大整数)
        return 随机整数 / 倍数

    except Exception:
        return None