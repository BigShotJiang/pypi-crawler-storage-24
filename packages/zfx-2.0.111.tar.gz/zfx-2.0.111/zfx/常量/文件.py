字节 = 1

KB = 1024
MB = 1024 * 1024
GB = 1024 * 1024 * 1024
TB = 1024 * 1024 * 1024 * 1024

千字节 = 1000
兆字节 = 1000 * 1000
吉字节 = 1000 * 1000 * 1000
太字节 = 1000 * 1000 * 1000 * 1000

扩展名_TXT = ".txt"
扩展名_JSON = ".json"
扩展名_CSV = ".csv"
扩展名_XML = ".xml"
扩展名_HTML = ".html"
扩展名_PDF = ".pdf"
扩展名_ZIP = ".zip"
扩展名_RAR = ".rar"
扩展名_PNG = ".png"
扩展名_JPG = ".jpg"
扩展名_JPEG = ".jpeg"
扩展名_GIF = ".gif"
扩展名_MP3 = ".mp3"
扩展名_MP4 = ".mp4"
扩展名_EXE = ".exe"
扩展名_XLSX = ".xlsx"
扩展名_DOCX = ".docx"
扩展名_PY = ".py"
扩展名_JS = ".js"

编码_UTF8 = "utf-8"
编码_GBK = "gbk"
编码_GB2312 = "gb2312"
编码_UTF16 = "utf-16"
编码_ASCII = "ascii"
编码_ISO88591 = "iso-8859-1"

换行符_Windows = "\r\n"
换行符_Linux = "\n"
换行符_Mac经典 = "\r"

路径分隔符_Windows = "\\"
路径分隔符_Linux = "/"
当前目录 = "."
上级目录 = ".."
