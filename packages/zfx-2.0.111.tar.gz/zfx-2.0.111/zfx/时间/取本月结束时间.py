﻿from datetime import datetime, timedelta


def 取本月结束时间(时间字符串: str | None = None) -> str | None:
    """
    获取指定日期所在月的结束时间，统一返回当月最后一天的 "23:59:59"。

    功能说明：
        - 支持传入 "YYYY-MM-DD" 或 "YYYY-MM-DD HH:MM:SS" 格式。
        - 未传入参数时，默认取今天所在月的结束时间。
        - 若输入格式无效或解析失败，则返回 None。

    Args:
        时间字符串 (str | None): 可选，指定日期或时间字符串。

    Returns:
        str | None: 成功返回本月月末的 "YYYY-MM-DD 23:59:59"；失败返回 None。
    """
    try:
        if 时间字符串 is None:
            日期对象 = datetime.now().date()
        else:
            时间字符串 = 时间字符串.strip()
            if len(时间字符串) == 10:
                日期对象 = datetime.strptime(时间字符串, "%Y-%m-%d").date()
            else:
                日期对象 = datetime.strptime(时间字符串, "%Y-%m-%d %H:%M:%S").date()

        if 日期对象.month == 12:
            下月月初 = 日期对象.replace(year=日期对象.year + 1, month=1, day=1)
        else:
            下月月初 = 日期对象.replace(month=日期对象.month + 1, day=1)

        月结束日期 = 下月月初 - timedelta(days=1)
        return f"{月结束日期} 23:59:59"
    except Exception:
        return None