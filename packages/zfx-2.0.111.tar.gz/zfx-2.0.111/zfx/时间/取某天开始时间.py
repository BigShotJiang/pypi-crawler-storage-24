﻿from datetime import datetime


def 取某天开始时间(时间字符串: str | None = None) -> str | None:
    """
    获取指定日期的开始时间，统一返回当天的 "00:00:00"。

    功能说明：
        - 支持传入 "YYYY-MM-DD" 或 "YYYY-MM-DD HH:MM:SS" 格式。
        - 未传入参数时，默认取今天的开始时间。
        - 若输入格式无效或解析失败，则返回 None。

    Args:
        时间字符串 (str | None): 可选，指定日期或时间字符串。

    Returns:
        str | None: 成功返回 "YYYY-MM-DD 00:00:00"；失败返回 None。
    """
    try:
        if 时间字符串 is None:
            日期对象 = datetime.now().date()
        else:
            时间字符串 = 时间字符串.strip()
            if len(时间字符串) == 10:
                日期对象 = datetime.strptime(时间字符串, "%Y-%m-%d").date()
            else:
                日期对象 = datetime.strptime(时间字符串, "%Y-%m-%d %H:%M:%S").date()

        return f"{日期对象} 00:00:00"
    except Exception:
        return None