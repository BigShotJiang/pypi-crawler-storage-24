from __future__ import annotations

from typing import Dict, Optional, Union

import requests


def DELETE(
    url: str,
    headers: Optional[Dict[str, str]] = None,
    cookies: Optional[Dict[str, str]] = None,
    timeout: Union[int, float] = 10,
    allow_redirects: bool = True,
    verify: bool = True,
    proxies: Optional[Dict[str, str]] = None,
) -> Optional[requests.Response]:
    """
    发送 HTTP DELETE 请求并返回响应对象（requests.Response）。

    本函数用于删除服务器端资源，设计目标与 GET / POST 保持一致：
        - 成功返回 requests.Response
        - 任意异常（网络错误/超时/参数错误等）返回 None
        - 函数内部不抛出异常

    使用说明:
        - DELETE 请求通常不包含请求体（payload）
        - 若后端需要鉴权或额外信息，可通过 headers / cookies 传递

    Args:
        url (str): 目标 URL，例如 "https://example.com/api/resource/123".
        headers (Optional[Dict[str, str]]): 请求头字典。
        cookies (Optional[Dict[str, str]]): Cookie 字典。
        timeout (Union[int, float]): 超时时间（秒）。
        allow_redirects (bool): 是否允许自动跟随重定向。
        verify (bool): 是否验证 HTTPS 证书。
        proxies (Optional[Dict[str, str]]): 代理配置。

    Returns:
        Optional[requests.Response]:
            - 成功：返回 响应对象（requests.Response）
            - 失败：返回 None
    """
    if not isinstance(url, str) or not url.strip():
        return None

    try:
        响应 = requests.delete(
            url=url,
            headers=headers,
            cookies=cookies,
            timeout=timeout,
            allow_redirects=allow_redirects,
            verify=verify,
            proxies=proxies,
        )
        return 响应
    except Exception:
        return None