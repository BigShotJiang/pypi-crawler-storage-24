from __future__ import annotations
import random


def 生成随机UA(
    浏览器: str | None = None,
    系统: str | None = None
) -> str:
    """
    生成一个常见且合理的 User-Agent 字符串。

    本函数用于 HTTP 请求场景，减少被简单反爬或风控系统识别的概率。
    生成的 UA 偏向主流浏览器与操作系统组合，不追求高度拟真，
    但保证格式正确、语义合理。

    参数说明：
        - 浏览器：限制生成的浏览器类型
        - 系统：限制生成的操作系统类型
        - 当参数为 None 时，将在常见选项中随机选择

    常见浏览器值：
        - "Chrome"
        - "Firefox"
        - "Edge"
        - "Safari"

    常见系统值：
        - "Windows"
        - "macOS"
        - "Linux"
        - "Android"
        - "iOS"

    Args:
        浏览器 (str | None): 指定浏览器类型。
        系统 (str | None): 指定操作系统类型。

    Returns:
        str: User-Agent 字符串。
    """

    浏览器列表 = ["Chrome", "Firefox", "Edge", "Safari"]
    系统列表 = ["Windows", "macOS", "Linux", "Android", "iOS"]

    浏览器 = 浏览器 if 浏览器 in 浏览器列表 else random.choice(浏览器列表)
    系统 = 系统 if 系统 in 系统列表 else random.choice(系统列表)

    if 浏览器 == "Chrome":
        版本 = f"{random.randint(110, 123)}.0.{random.randint(1000, 5000)}.{random.randint(10, 150)}"
        if 系统 == "Windows":
            return f"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{版本} Safari/537.36"
        if 系统 == "macOS":
            return f"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{版本} Safari/537.36"
        if 系统 == "Linux":
            return f"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{版本} Safari/537.36"
        if 系统 == "Android":
            return f"Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{版本} Mobile Safari/537.36"

    if 浏览器 == "Firefox":
        版本 = f"{random.randint(100, 125)}.0"
        if 系统 == "Windows":
            return f"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:{版本}) Gecko/20100101 Firefox/{版本}"
        if 系统 == "macOS":
            return f"Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:{版本}) Gecko/20100101 Firefox/{版本}"
        if 系统 == "Linux":
            return f"Mozilla/5.0 (X11; Linux x86_64; rv:{版本}) Gecko/20100101 Firefox/{版本}"

    if 浏览器 == "Edge":
        版本 = f"{random.randint(110, 123)}.0.{random.randint(1000, 5000)}.{random.randint(10, 150)}"
        return f"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{版本} Safari/537.36 Edg/{版本}"

    # Safari（主要用于 macOS / iOS）
    版本 = f"{random.randint(14, 17)}.0"
    if 系统 == "iOS":
        return f"Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/{版本} Mobile/15E148 Safari/604.1"

    return f"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/{版本} Safari/605.1.15"