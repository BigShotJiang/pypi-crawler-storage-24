﻿import shutil
from pathlib import Path


def 清空目录(目录路径: str) -> bool:
    """
    清空指定目录下的全部内容，但保留目录本身。

    功能说明：
        - 会删除目录内的文件、子目录及其内容。
        - 仅当目标路径存在且为目录时执行清空。
        - 清空成功返回 True；目录不存在、不是目录或清空失败返回 False。

    Args:
        目录路径 (str): 要清空的目录路径。

    Returns:
        bool: 清空成功返回 True；失败返回 False。
    """
    try:
        目录对象 = Path(目录路径)
        if not 目录对象.exists() or not 目录对象.is_dir():
            return False

        for 子项 in 目录对象.iterdir():
            try:
                if 子项.is_dir():
                    shutil.rmtree(子项)
                else:
                    子项.unlink()
            except Exception:
                return False

        return True
    except Exception:
        return False