﻿from pathlib import Path


def 判断目录是否存在(目录路径: str) -> bool:
    """
    判断指定路径是否存在且为目录。

    功能说明：
        - 仅当路径存在并且类型为目录时返回 True。
        - 路径不存在、路径为文件或发生异常时返回 False。

    Args:
        目录路径 (str): 要判断的目录路径。

    Returns:
        bool: 路径存在且为目录返回 True；否则返回 False。
    """
    try:
        return Path(目录路径).is_dir()
    except Exception:
        return False