﻿from pathlib import Path
import os


def 取系统桌面目录() -> str | None:
    """
    获取当前系统用户的桌面目录路径。

    功能说明：
        - Windows 系统优先使用 USERPROFILE 组合桌面路径。
        - 其他系统使用当前用户主目录下的 Desktop 目录。
        - 当桌面目录不存在或获取失败时，返回 None。

    Returns:
        str | None: 成功返回桌面目录绝对路径；失败返回 None。
    """
    try:
        if os.name == 'nt':
            用户目录 = os.environ.get('USERPROFILE')
            if not 用户目录:
                return None
            桌面目录 = Path(用户目录) / 'Desktop'
        else:
            桌面目录 = Path.home() / 'Desktop'

        if 桌面目录.exists() and 桌面目录.is_dir():
            return str(桌面目录)
        return None
    except Exception:
        return None
