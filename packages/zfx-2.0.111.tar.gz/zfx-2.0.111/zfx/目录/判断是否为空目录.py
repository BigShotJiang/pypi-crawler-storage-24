﻿from pathlib import Path


def 判断是否为空目录(目录路径: str) -> bool:
    """
    判断指定目录是否为空目录。

    功能说明：
        - 仅当路径存在且为目录时才进行判断。
        - 目录中不存在任何文件或子目录时返回 True。
        - 路径不存在、不是目录或判断失败时返回 False。

    Args:
        目录路径 (str): 要判断的目录路径。

    Returns:
        bool: 空目录返回 True；否则返回 False。
    """
    try:
        目录对象 = Path(目录路径)
        if not 目录对象.exists() or not 目录对象.is_dir():
            return False

        return next(目录对象.iterdir(), None) is None
    except Exception:
        return False
