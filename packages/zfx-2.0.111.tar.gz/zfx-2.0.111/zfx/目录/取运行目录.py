﻿import os
from pathlib import Path


def 取运行目录(是否添加末尾斜杠: bool = False) -> str | None:
    """
    获取当前程序运行时的工作目录。

    功能说明：
        - 返回当前进程的工作目录绝对路径。
        - 当“是否添加末尾斜杠”为 True 时，会在路径末尾补上系统分隔符。
        - 获取失败时返回 None。

    Args:
        是否添加末尾斜杠 (bool): 是否在结果末尾补上路径分隔符，默认为 False。

    Returns:
        str | None: 成功返回运行目录绝对路径；失败返回 None。
    """
    try:
        运行目录 = str(Path.cwd())
        if 是否添加末尾斜杠 and not 运行目录.endswith(os.sep):
            return 运行目录 + os.sep
        return 运行目录
    except Exception:
        return None
