﻿import shutil
from pathlib import Path


def 复制目录(源目录路径: str, 目标目录路径: str) -> bool:
    """
    复制整个目录到指定目标路径。

    功能说明：
        - 会递归复制源目录中的全部文件和子目录。
        - 当源目录不存在或不是目录时返回 False。
        - 当目标路径已存在时返回 False，避免覆盖已有目录。
        - 复制成功返回 True。

    Args:
        源目录路径 (str): 要复制的源目录路径。
        目标目录路径 (str): 复制后的目标目录路径。

    Returns:
        bool: 复制成功返回 True；失败返回 False。
    """
    try:
        源目录 = Path(源目录路径)
        目标目录 = Path(目标目录路径)

        if not 源目录.exists() or not 源目录.is_dir():
            return False
        if 目标目录.exists():
            return False

        shutil.copytree(源目录, 目标目录)
        return True
    except Exception:
        return False
