﻿from pathlib import Path


def 创建目录(目录路径: str, 是否递归: bool = False) -> bool:
    """
    创建指定路径的目录。

    功能说明：
        - 当目标目录已存在时，视为成功，直接返回 True。
        - 当“是否递归”为 True 时，支持自动创建多级父目录。
        - 当“是否递归”为 False 时，仅创建单级目录。
        - 发生异常时不抛出错误，统一返回 False。

    Args:
        目录路径 (str): 要创建的目录路径。
        是否递归 (bool): 是否递归创建多级目录，默认为 False。

    Returns:
        bool: 创建成功或目录已存在返回 True；失败返回 False。
    """
    try:
        目录对象 = Path(目录路径)

        if 目录对象.exists():
            return 目录对象.is_dir()

        if 是否递归:
            目录对象.mkdir(parents=True, exist_ok=True)
        else:
            目录对象.mkdir()

        return True
    except Exception:
        return False
