﻿from pathlib import Path


def 重命名目录(目录路径: str, 新目录名称: str) -> bool:
    """
    重命名指定目录，但保持其父目录位置不变。

    功能说明：
        - 仅修改目录名称，不改变目录所在层级。
        - 当源目录不存在、不是目录或新名称无效时返回 False。
        - 当同级目录下已存在同名目录时返回 False。
        - 重命名成功返回 True。

    Args:
        目录路径 (str): 要重命名的目录路径。
        新目录名称 (str): 新的目录名称，不应包含路径。

    Returns:
        bool: 重命名成功返回 True；失败返回 False。
    """
    try:
        目录对象 = Path(目录路径)
        if not 目录对象.exists() or not 目录对象.is_dir():
            return False

        新目录名称 = 新目录名称.strip()
        if not 新目录名称:
            return False
        if Path(新目录名称).name != 新目录名称:
            return False

        新目录路径 = 目录对象.parent / 新目录名称
        if 新目录路径.exists():
            return False

        目录对象.rename(新目录路径)
        return True
    except Exception:
        return False
