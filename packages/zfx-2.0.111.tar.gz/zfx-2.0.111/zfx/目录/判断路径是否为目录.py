﻿from pathlib import Path


def 判断路径是否为目录(路径: str) -> bool:
    """
    判断指定路径是否为目录。

    功能说明：
        - 等价于判断路径存在且类型为目录。
        - 路径为文件、路径不存在或发生异常时返回 False。

    Args:
        路径 (str): 要判断的路径。

    Returns:
        bool: 路径为目录返回 True；否则返回 False。
    """
    try:
        return Path(路径).is_dir()
    except Exception:
        return False
