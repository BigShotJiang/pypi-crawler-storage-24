﻿from pathlib import Path


def 取目录大小(目录路径: str) -> int:
    """
    计算指定目录的总大小，单位为字节。

    功能说明：
        - 会递归统计目录下所有文件的大小总和。
        - 默认忽略遍历过程中无法访问或已失效的单个文件。
        - 当路径不存在、不是目录或整体计算失败时，返回 0。

    Args:
        目录路径 (str): 要计算大小的目录路径。

    Returns:
        int: 目录总大小（字节）；失败返回 0。
    """
    try:
        目录对象 = Path(目录路径)
        if not 目录对象.exists() or not 目录对象.is_dir():
            return 0

        总大小 = 0
        for 子项 in 目录对象.rglob('*'):
            if 子项.is_file():
                try:
                    总大小 += 子项.stat().st_size
                except Exception:
                    continue

        return 总大小
    except Exception:
        return 0
