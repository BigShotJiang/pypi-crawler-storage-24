﻿import shutil
from pathlib import Path


def 移动目录(源目录路径: str, 目标目录路径: str) -> bool:
    """
    将指定目录移动到目标路径。

    功能说明：
        - 会将源目录整体移动到目标路径。
        - 当源目录不存在或不是目录时返回 False。
        - 当目标路径已存在时返回 False，避免覆盖已有内容。
        - 移动成功返回 True。

    Args:
        源目录路径 (str): 要移动的源目录路径。
        目标目录路径 (str): 移动后的目标目录路径。

    Returns:
        bool: 移动成功返回 True；失败返回 False。
    """
    try:
        源目录 = Path(源目录路径)
        目标目录 = Path(目标目录路径)

        if not 源目录.exists() or not 源目录.is_dir():
            return False
        if 目标目录.exists():
            return False

        shutil.move(str(源目录), str(目标目录))
        return True
    except Exception:
        return False
