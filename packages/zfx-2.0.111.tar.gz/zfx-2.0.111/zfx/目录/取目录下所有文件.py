﻿from pathlib import Path


def 取目录下所有文件(目录路径: str, 是否递归: bool = False) -> list[str] | None:
    """
    获取指定目录下的全部文件路径列表。

    功能说明：
        - 当“是否递归”为 False 时，仅返回第一层文件。
        - 当“是否递归”为 True 时，递归返回所有层级的文件。
        - 返回结果为字符串列表，内容为文件绝对路径。
        - 路径不存在、不是目录或读取失败时返回 None。

    Args:
        目录路径 (str): 要读取的目录路径。
        是否递归 (bool): 是否递归读取全部文件，默认为 False。

    Returns:
        list[str] | None: 成功返回文件路径列表；失败返回 None。
    """
    try:
        目录对象 = Path(目录路径)
        if not 目录对象.exists() or not 目录对象.is_dir():
            return None

        if 是否递归:
            return [str(子项.resolve()) for 子项 in 目录对象.rglob('*') if 子项.is_file()]
        return [str(子项.resolve()) for 子项 in 目录对象.iterdir() if 子项.is_file()]
    except Exception:
        return None
