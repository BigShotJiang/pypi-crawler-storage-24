﻿import shutil
from pathlib import Path


def 删除目录(目录路径: str) -> bool:
    """
    删除指定目录及其全部内容。

    功能说明：
        - 仅当目标路径存在且为目录时才执行删除。
        - 目录不存在、路径不是目录或删除失败时，返回 False。
        - 删除成功后返回 True。

    Args:
        目录路径 (str): 要删除的目录路径。

    Returns:
        bool: 删除成功返回 True；失败返回 False。
    """
    try:
        目录对象 = Path(目录路径)
        if not 目录对象.exists() or not 目录对象.is_dir():
            return False

        shutil.rmtree(目录对象)
        return True
    except Exception:
        return False
