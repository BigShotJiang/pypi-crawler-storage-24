﻿from pathlib import Path


def 取子目录数量(目录路径: str) -> int:
    """
    获取指定目录下的直接子目录数量。

    功能说明：
        - 仅统计当前目录下的第一层子目录，不递归统计更深层级。
        - 隐藏目录若实际存在，也会被计入结果。
        - 当路径不存在、不是目录或读取失败时，返回 -1。

    Args:
        目录路径 (str): 要统计的目录路径。

    Returns:
        int: 成功返回子目录数量；失败返回 -1。
    """
    try:
        目录对象 = Path(目录路径)
        if not 目录对象.exists() or not 目录对象.is_dir():
            return -1

        return sum(1 for 子项 in 目录对象.iterdir() if 子项.is_dir())
    except Exception:
        return -1
