﻿import os
from pathlib import Path


def 判断目录是否可读(目录路径: str) -> bool:
    """
    判断指定目录是否具有读取权限。

    功能说明：
        - 仅当路径存在且为目录时才进行判断。
        - 内部使用系统权限检测方式判断当前进程是否可读。
        - 路径不存在、不是目录或判断失败时返回 False。

    Args:
        目录路径 (str): 要判断的目录路径。

    Returns:
        bool: 当前目录可读返回 True；否则返回 False。
    """
    try:
        目录对象 = Path(目录路径)
        if not 目录对象.exists() or not 目录对象.is_dir():
            return False

        return os.access(目录对象, os.R_OK)
    except Exception:
        return False
