﻿from datetime import datetime
from pathlib import Path


def 取目录最后修改时间(目录路径: str) -> str | None:
    """
    获取指定目录的最后修改时间。

    功能说明：
        - 返回结果格式固定为 "YYYY-MM-DD HH:MM:SS"。
        - 当路径不存在、不是目录或读取失败时，返回 None。

    Args:
        目录路径 (str): 要读取的目录路径。

    Returns:
        str | None: 成功返回目录最后修改时间；失败返回 None。
    """
    try:
        目录对象 = Path(目录路径)
        if not 目录对象.exists() or not 目录对象.is_dir():
            return None

        时间戳 = 目录对象.stat().st_mtime
        return datetime.fromtimestamp(时间戳).strftime('%Y-%m-%d %H:%M:%S')
    except Exception:
        return None
