﻿from pathlib import Path


def 取目录总项目数量(目录路径: str) -> int:
    """
    获取指定目录下的直接项目总数量。

    功能说明：
        - 统计当前目录第一层中的全部文件和子目录数量。
        - 不递归统计更深层级内容。
        - 当路径不存在、不是目录或读取失败时，返回 -1。

    Args:
        目录路径 (str): 要统计的目录路径。

    Returns:
        int: 成功返回当前目录第一层项目总数量；失败返回 -1。
    """
    try:
        目录对象 = Path(目录路径)
        if not 目录对象.exists() or not 目录对象.is_dir():
            return -1

        return sum(1 for _ in 目录对象.iterdir())
    except Exception:
        return -1
