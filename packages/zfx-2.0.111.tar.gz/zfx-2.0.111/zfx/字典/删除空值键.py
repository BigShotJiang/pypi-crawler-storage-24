from typing import Any, Dict


def 删除空值键(数据: Dict[str, Any]) -> int:
    """
    删除字典中值为空的键，并返回删除数量。

    本函数用于清理字典中的“空值项”，默认将以下值视为可删除对象：
        - None
        - ""
        - []
        - {}

    设计特性：
        - 若传入对象不是字典类型，直接返回 0；
        - 操作为原地删除，不创建新的字典对象；
        - 仅删除最外层符合条件的键，不递归深入嵌套结构；
        - 键在删除时统一按当前字典实际键处理，不额外改写值内容；
        - 不抛出任何异常，适合作为底层清洗工具函数使用。

    行为说明：
        - 数据为 dict                → 删除所有空值键并返回删除数量；
        - 数据不是 dict              → 返回 0；
        - 无任何空值键               → 返回 0。

    Args:
        数据 (dict): 需要清理的字典对象。

    Returns:
        int:
            - 成功：返回实际删除的键数量；
            - 失败：返回 0。
    """
    try:
        if not isinstance(数据, dict):
            return 0

        待删除键列表 = [
            键
            for 键, 值 in 数据.items()
            if 值 is None or 值 == "" or 值 == [] or 值 == {}
        ]

        for 键 in 待删除键列表:
            del 数据[键]

        return len(待删除键列表)
    except Exception:
        return 0
