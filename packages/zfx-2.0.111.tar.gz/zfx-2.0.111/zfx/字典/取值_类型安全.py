from typing import Any, Dict, Tuple, Type, Union


_期望类型 = Union[Type[Any], Tuple[Type[Any], ...]]


def 取值_类型安全(
    数据: Dict[str, Any],
    键: Any,
    期望类型: _期望类型,
    默认值: Any = None
) -> Any:
    """
    安全取值，并校验结果是否符合期望类型；不符合则返回默认值。

    本函数适用于接口响应、配置读取、外部数据清洗等场景，
    可避免“字段虽然存在，但类型不符合预期”导致的后续逻辑错误。

    设计特性：
        - 若传入对象不是字典类型，直接返回默认值；
        - 键会被统一转换为字符串，以保持与本模块其他函数行为一致；
        - 仅当键存在且值符合期望类型时才返回原值；
        - 支持单个类型或类型元组；
        - 不抛出任何异常，适合作为防御性数据读取工具函数使用。

    行为说明：
        - 键存在且值类型符合预期    → 返回原值；
        - 键存在但值类型不符        → 返回默认值；
        - 键不存在                  → 返回默认值；
        - 数据不是 dict             → 返回默认值。

    Args:
        数据 (dict): 用于取值的字典对象。
        键: 要读取的键，内部将转换为字符串。
        期望类型 (type | tuple[type, ...]): 允许的目标类型。
            - 单类型示例： str
            - 多类型示例： (int, float)
        默认值: 当键不存在或类型不匹配时返回的值，默认为 None。

    Returns:
        Any:
            - 成功：返回符合期望类型的原始值；
            - 失败：返回默认值。
    """
    try:
        if not isinstance(数据, dict):
            return 默认值

        键名 = str(键)
        if 键名 not in 数据:
            return 默认值

        值 = 数据[键名]
        if isinstance(值, 期望类型):
            return 值

        return 默认值
    except Exception:
        return 默认值