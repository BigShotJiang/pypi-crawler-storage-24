from typing import Any, Callable, Dict


def 值映射(
    数据: Dict[str, Any],
    处理函数: Callable[[Any], Any]
) -> Dict[str, Any]:
    """
    对字典中的所有值应用同一个转换函数，并返回新字典。

    本函数用于批量处理字典值，
    适合统一格式化、字符串清洗、数值计算、类型转换等场景。

    设计特性：
        - 若传入对象不是字典类型，返回空字典；
        - 若处理函数不可调用，返回空字典；
        - 不修改原始字典，返回新的转换结果字典；
        - 键在结果中统一转换为字符串；
        - 每个值都会传入处理函数一次，返回值作为新值写入结果字典；
        - 不抛出任何异常，适合作为批量值处理工具函数使用。

    行为说明：
        - 数据为 dict 且函数可调用     → 返回映射后的新字典；
        - 数据不是 dict               → 返回 {}；
        - 处理函数不可调用            → 返回 {}。

    Args:
        数据 (dict): 原始字典对象。
        处理函数 (Callable[[Any], Any]): 值转换函数。
            - 示例： str
            - 示例： lambda 值: 值 * 2

    Returns:
        dict[str, Any]:
            - 成功：返回值处理后的新字典；
            - 失败：返回空字典 {}。
    """
    try:
        if not isinstance(数据, dict):
            return {}

        if not callable(处理函数):
            return {}

        return {
            str(键): 处理函数(值)
            for 键, 值 in 数据.items()
        }
    except Exception:
        return {}