from typing import Any, Dict


def 重命名键(
    数据: Dict[str, Any],
    旧键: Any,
    新键: Any
) -> bool:
    """
    将字典中的旧键重命名为新键。

    本函数用于安全地执行单个键的重命名操作，
    可视为“读取旧值 + 写入新键 + 删除旧键”的组合封装。

    设计特性：
        - 若传入对象不是字典类型，不执行任何操作；
        - 旧键与新键都会统一转换为字符串；
        - 若旧键不存在，直接返回 False；
        - 若新键已存在，将被旧键对应的值覆盖；
        - 不抛出任何异常，适合作为底层结构调整工具函数使用。

    行为说明：
        - 旧键存在                 → 重命名成功并返回 True；
        - 旧键不存在               → 返回 False；
        - 旧键与新键相同且键存在    → 视为成功，返回 True；
        - 数据不是 dict            → 返回 False。

    Args:
        数据 (dict): 需要处理的字典对象。
        旧键: 需要被重命名的键。
        新键: 新的键名。

    Returns:
        bool:
            True  - 重命名成功；
            False - 重命名失败。
    """
    try:
        if not isinstance(数据, dict):
            return False

        旧键名 = str(旧键)
        新键名 = str(新键)

        if 旧键名 not in 数据:
            return False

        if 旧键名 == 新键名:
            return True

        数据[新键名] = 数据[旧键名]
        del 数据[旧键名]
        return True
    except Exception:
        return False
