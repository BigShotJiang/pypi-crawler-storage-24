from __future__ import annotations

from typing import Any, List, Sequence, Union


_路径类型 = Union[str, Sequence[Any]]


def _归一化路径(键路径: _路径类型, 分隔符: str) -> List[Any] | None:
    try:
        if isinstance(键路径, str):
            if 键路径 == "":
                return None
            return 键路径.split(分隔符)

        if isinstance(键路径, (list, tuple)):
            if len(键路径) == 0:
                return None
            return list(键路径)

        return None
    except Exception:
        return None


def _是否应创建列表(路径段: Any) -> bool:
    try:
        if isinstance(路径段, bool):
            return False

        索引 = 路径段 if isinstance(路径段, int) else int(str(路径段))
        return 索引 >= 0
    except Exception:
        return False


def 设置值_路径(
    数据: Any,
    键路径: _路径类型,
    值: Any,
    分隔符: str = ".",
    键转字符串: bool = True,
) -> bool:
    """
    根据“键路径”向嵌套结构中安全写入值，支持 dict/list 混合结构。

    本函数可视为 `取值_路径` 的写入版，支持：
        - 字符串路径：如 "a.b.0.c"
        - 序列路径：如 ["a", "b", 0, "c"]

    设计特性：
        - 支持在写入过程中自动补齐缺失的中间层结构；
        - 补齐时会根据下一段路径自动选择创建 dict 或 list；
        - 当遇到不可继续下钻的非容器对象时，返回 False；
        - 原地修改传入对象，不创建新的根对象；
        - 不抛出任何异常，适合作为底层基础工具函数使用。

    行为说明：
        - 路径合法且写入成功        → 返回 True；
        - 路径非法或结构冲突        → 返回 False；
        - 数据不是 dict/list        → 返回 False。

    Args:
        数据 (Any): 通常为 dict 或 list 的嵌套结构。
        键路径 (str | Sequence[Any]): 路径字符串或路径序列。
            - 字符串示例： "a.b.0.c"
            - 列表示例： ["a", "b", 0, "c"]
        值 (Any): 需要写入目标路径的值。
        分隔符 (str): 字符串路径的分隔符，默认 "."。
        键转字符串 (bool): 当走 dict 写入时，是否将键统一转为 str。默认 True。

    Returns:
        bool:
            True  - 写入成功；
            False - 写入失败。
    """
    try:
        路径列表 = _归一化路径(键路径, 分隔符)
        if not 路径列表:
            return False

        if not isinstance(数据, (dict, list)):
            return False

        当前 = 数据

        for 索引位置, 段 in enumerate(路径列表):
            是否最后一段 = 索引位置 == len(路径列表) - 1
            下一段 = None if 是否最后一段 else 路径列表[索引位置 + 1]

            if isinstance(当前, dict):
                键名 = str(段) if 键转字符串 else 段

                if 是否最后一段:
                    当前[键名] = 值
                    return True

                if 键名 not in 当前:
                    当前[键名] = [] if _是否应创建列表(下一段) else {}

                if not isinstance(当前[键名], (dict, list)):
                    return False

                当前 = 当前[键名]
                continue

            if isinstance(当前, list):
                try:
                    目标索引 = 段 if isinstance(段, int) else int(str(段))
                except Exception:
                    return False

                if 目标索引 < 0:
                    return False

                while len(当前) <= 目标索引:
                    当前.append(None)

                if 是否最后一段:
                    当前[目标索引] = 值
                    return True

                if 当前[目标索引] is None:
                    当前[目标索引] = [] if _是否应创建列表(下一段) else {}

                if not isinstance(当前[目标索引], (dict, list)):
                    return False

                当前 = 当前[目标索引]
                continue

            return False

        return False
    except Exception:
        return False