from typing import Any, Dict


def 是否包含子集(
    主字典: Dict[str, Any],
    子集字典: Dict[str, Any]
) -> bool:
    """
    判断主字典是否包含子集字典中的全部键值对。

    本函数适用于权限校验、配置匹配、条件判断、局部结构验证等场景。
    只有当子集字典中的每个键都存在于主字典中，且对应值完全相等时，
    才视为主字典包含该子集。

    设计特性：
        - 若任一参数不是字典类型，直接返回 False；
        - 键会统一转换为字符串后进行比较；
        - 仅比较最外层键值对，不递归深入嵌套结构内部；
        - 空子集字典视为被任意合法主字典包含；
        - 不抛出任何异常，适合作为结构验证工具函数使用。

    行为说明：
        - 子集中的键值对全部命中主字典   → 返回 True；
        - 任意一个键不存在或值不相等     → 返回 False；
        - 主字典不是 dict               → 返回 False；
        - 子集字典不是 dict             → 返回 False。

    Args:
        主字典 (dict): 用于包含判断的主字典。
        子集字典 (dict): 需要被验证是否包含的子集字典。

    Returns:
        bool:
            True  - 主字典包含子集字典；
            False - 不包含或参数非法。
    """
    try:
        if not isinstance(主字典, dict):
            return False

        if not isinstance(子集字典, dict):
            return False

        主值映射 = {str(键): 值 for 键, 值 in 主字典.items()}

        for 键, 值 in 子集字典.items():
            键名 = str(键)
            if 键名 not in 主值映射:
                return False
            if 主值映射[键名] != 值:
                return False

        return True
    except Exception:
        return False
