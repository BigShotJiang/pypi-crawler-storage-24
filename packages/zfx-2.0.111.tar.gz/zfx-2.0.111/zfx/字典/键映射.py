from typing import Any, Dict


def 键映射(
    数据: Dict[str, Any],
    键映射表: Dict[Any, Any]
) -> Dict[str, Any]:
    """
    根据给定映射表批量重命名字典中的键，并返回新字典。

    本函数用于对字典键名进行批量转换，
    适合字段标准化、旧版字段迁移、对外统一输出等场景。

    设计特性：
        - 若传入对象不是字典类型，返回空字典；
        - 若映射表不是字典类型，返回空字典；
        - 不修改原始字典，返回新的转换结果字典；
        - 映射表中的旧键、新键都会统一转换为字符串；
        - 不在映射表中的键会保持原样；
        - 不抛出任何异常，适合作为结构转换工具函数使用。

    行为说明：
        - 数据与映射表均为 dict      → 返回映射后的新字典；
        - 数据不是 dict              → 返回 {}；
        - 映射表不是 dict            → 返回 {}。

    Args:
        数据 (dict): 原始字典对象。
        键映射表 (dict): 键名映射关系表。
            - 示例： {"name": "名称", "age": "年龄"}

    Returns:
        dict[str, Any]:
            - 成功：返回批量重命名后的新字典；
            - 失败：返回空字典 {}。
    """
    try:
        if not isinstance(数据, dict):
            return {}

        if not isinstance(键映射表, dict):
            return {}

        标准映射表 = {
            str(旧键): str(新键)
            for 旧键, 新键 in 键映射表.items()
        }

        结果字典: Dict[str, Any] = {}
        for 键, 值 in 数据.items():
            原键名 = str(键)
            新键名 = 标准映射表.get(原键名, 原键名)
            结果字典[新键名] = 值

        return 结果字典
    except Exception:
        return {}
