from typing import Any, Dict, Iterable


def 合并_仅白名单键(
    目标字典: Dict[str, Any],
    来源字典: Dict[str, Any],
    白名单键列表: Iterable[Any]
) -> bool:
    """
    仅允许来源字典中的白名单键被合并到目标字典中。

    本函数适用于“允许更新部分字段、禁止写入其他字段”的场景，
    可用于接口入参过滤、配置白名单覆盖、受控字段同步等。

    设计特性：
        - 若目标对象不是字典类型，不执行任何操作；
        - 若来源对象不是字典类型，不执行任何操作；
        - 若白名单键列表为空，不执行任何写入；
        - 白名单键会统一转换为字符串后再参与匹配；
        - 合并操作为原地修改，不创建新的字典对象；
        - 不抛出任何异常，适合作为底层受控合并工具函数使用。

    行为说明：
        - 参数合法                     → 仅合并白名单内键并返回 True；
        - 任一关键参数非法             → 返回 False；
        - 白名单为空                   → 不修改目标字典，返回 True。

    Args:
        目标字典 (dict): 接收合并结果的目标字典。
        来源字典 (dict): 提供候选写入内容的来源字典。
        白名单键列表 (Iterable[Any]): 允许被合并的键集合。
            - 列表示例： ["名称", "城市"]
            - 元组示例： ("age", "email")

    Returns:
        bool:
            True  - 合并操作已成功执行；
            False - 参数非法或发生异常。
    """
    try:
        if not isinstance(目标字典, dict):
            return False

        if not isinstance(来源字典, dict):
            return False

        if isinstance(白名单键列表, str):
            白名单集合 = {白名单键列表}
        else:
            白名单集合 = {str(键) for 键 in 白名单键列表}

        for 键, 值 in 来源字典.items():
            if str(键) in 白名单集合:
                目标字典[键] = 值

        return True
    except Exception:
        return False
