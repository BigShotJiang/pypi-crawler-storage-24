from typing import Any, Callable, Dict


def 筛选键值对(
    数据: Dict[str, Any],
    条件函数: Callable[[str, Any], bool]
) -> Dict[str, Any]:
    """
    按条件函数筛选字典中的键值对，并返回新字典。

    本函数用于自定义过滤逻辑，
    适合复杂保留规则、按键名筛选、按值类型筛选等场景。

    设计特性：
        - 若传入对象不是字典类型，返回空字典；
        - 若条件函数不可调用，返回空字典；
        - 不修改原始字典，返回新的筛选结果字典；
        - 条件函数会接收两个参数：字符串键、原始值；
        - 当条件函数返回 True 时保留该键值对；
        - 不抛出任何异常，适合作为自定义筛选工具函数使用。

    行为说明：
        - 数据为 dict 且函数可调用     → 返回筛选后的新字典；
        - 数据不是 dict               → 返回 {}；
        - 条件函数不可调用            → 返回 {}。

    Args:
        数据 (dict): 原始字典对象。
        条件函数 (Callable[[str, Any], bool]): 筛选判断函数。
            - 示例： lambda 键, 值: 键.startswith("user_")
            - 示例： lambda 键, 值: isinstance(值, int)

    Returns:
        dict[str, Any]:
            - 成功：返回筛选后的新字典；
            - 失败：返回空字典 {}。
    """
    try:
        if not isinstance(数据, dict):
            return {}

        if not callable(条件函数):
            return {}

        return {
            str(键): 值
            for 键, 值 in 数据.items()
            if 条件函数(str(键), 值)
        }
    except Exception:
        return {}
