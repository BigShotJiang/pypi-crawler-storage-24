from typing import Any, Dict


def 是否相等_忽略键顺序(
    字典1: Dict[str, Any],
    字典2: Dict[str, Any]
) -> bool:
    """
    判断两个字典在忽略键顺序的前提下是否结构相等。

    本函数适用于配置比较、缓存命中判断、结构一致性校验等场景。
    由于 Python 原生字典比较本身就不受键顺序影响，
    本函数主要提供一个语义更明确、风格统一的封装入口。

    设计特性：
        - 若任一参数不是字典类型，直接返回 False；
        - 仅当两个字典的键和值完全一致时返回 True；
        - 比较遵循 Python 原生字典相等语义；
        - 不修改原始数据；
        - 不抛出任何异常，适合作为条件判断工具函数使用。

    行为说明：
        - 两个字典结构和值完全相同     → 返回 True；
        - 任意键或值不同              → 返回 False；
        - 任一参数不是 dict           → 返回 False。

    Args:
        字典1 (dict): 第一个待比较字典。
        字典2 (dict): 第二个待比较字典。

    Returns:
        bool:
            True  - 两个字典结构相等；
            False - 不相等或参数非法。
    """
    try:
        if not isinstance(字典1, dict):
            return False

        if not isinstance(字典2, dict):
            return False

        return 字典1 == 字典2
    except Exception:
        return False
