from typing import Any, Dict


def 合并_不覆盖(
    目标字典: Dict[str, Any],
    来源字典: Dict[str, Any]
) -> bool:
    """
    将来源字典中的键值对补充到目标字典中，但不覆盖目标中已存在的键。

    本函数适用于“以目标字典为主，只补默认项或缺失项”的场景，
    可理解为对普通合并的“只补缺，不覆盖”版本。

    设计特性：
        - 若目标对象不是字典类型，不执行任何操作；
        - 若来源对象不是字典类型，不执行任何操作；
        - 合并操作为原地修改，不创建新的字典对象；
        - 当键已存在于目标字典中时，保持原值不变；
        - 不抛出任何异常，适合作为底层基础工具函数使用。

    行为说明：
        - 目标字典与来源字典均为 dict → 仅补缺失键并返回 True；
        - 任一参数不是 dict              → 不执行合并，返回 False；
        - 来源字典为空                  → 不修改目标字典，返回 True。

    Args:
        目标字典 (dict): 接收补充结果的目标字典。
        来源字典 (dict): 提供候选键值对的来源字典。

    Returns:
        bool:
            True  - 合并操作已成功执行；
            False - 参数非法或发生异常。
    """
    try:
        if not isinstance(目标字典, dict):
            return False

        if not isinstance(来源字典, dict):
            return False

        for 键, 值 in 来源字典.items():
            if 键 not in 目标字典:
                目标字典[键] = 值

        return True
    except Exception:
        return False
