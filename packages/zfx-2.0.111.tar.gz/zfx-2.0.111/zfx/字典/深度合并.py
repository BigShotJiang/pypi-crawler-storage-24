from typing import Any, Dict


def 深度合并(
    目标字典: Dict[str, Any],
    来源字典: Dict[str, Any]
) -> bool:
    """
    递归合并来源字典到目标字典中，支持嵌套字典结构。

    本函数适用于配置合并、多层结构补丁、分层参数覆盖等场景。
    当同名键对应的值在目标与来源中都为字典时，会递归向下合并；
    其他情况下，来源值会覆盖目标值。

    设计特性：
        - 若目标对象不是字典类型，不执行任何操作；
        - 若来源对象不是字典类型，不执行任何操作；
        - 合并操作为原地修改，不创建新的根字典对象；
        - 仅对“双方值都为 dict”的节点执行递归合并；
        - 其余类型冲突场景按来源值覆盖目标值；
        - 不抛出任何异常，适合作为底层结构合并工具函数使用。

    行为说明：
        - 目标与来源均为 dict        → 执行递归合并并返回 True；
        - 任一参数不是 dict          → 不执行合并，返回 False；
        - 来源字典为空               → 不修改目标字典，返回 True。

    Args:
        目标字典 (dict): 接收合并结果的目标字典。
        来源字典 (dict): 提供合并内容的来源字典。

    Returns:
        bool:
            True  - 深度合并已成功执行；
            False - 参数非法或发生异常。
    """
    try:
        if not isinstance(目标字典, dict):
            return False

        if not isinstance(来源字典, dict):
            return False

        for 键, 来源值 in 来源字典.items():
            if 键 in 目标字典 and isinstance(目标字典[键], dict) and isinstance(来源值, dict):
                if not 深度合并(目标字典[键], 来源值):
                    return False
            else:
                目标字典[键] = 来源值

        return True
    except Exception:
        return False
