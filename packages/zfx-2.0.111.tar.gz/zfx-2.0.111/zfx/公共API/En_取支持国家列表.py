import requests
import base64
from typing import Any, Dict, Optional


def En_取支持国家列表(slug: str) -> Optional[Dict[str, Any]]:
    """
    请求商品国家支持信息接口（GraphQL · persistedQuery 模式）。

    功能说明：
        - 使用固定 persistedQuery（SHA256 哈希）调用后端 GraphQL 接口
        - 根据商品 slug 获取可支持的国家 / 地区数据
        - 接口返回结构为标准 GraphQL JSON 数据
        - 采用“安全返回”机制：
            - 请求成功（HTTP 200 + JSON 解析成功）→ 返回 dict
            - 任意异常 / 非 200 状态码 / 解析失败 → 返回 None
        - 函数内部不抛出异常

    Args:
        slug (str): 商品唯一标识字符串（slug）

    Returns:
        dict | None:
            - 成功返回接口 JSON 数据（dict）
            - 失败返回 None
    """

    # 固定 persistedQuery SHA256 哈希
    SHA256_HASH = (
        "5e0544d49220e0245fe24818b17574b57c7627e9f58bbae4b0962a631534dda1_"
        "b8b08c07c3544960f6717c49c685309026085621f993b299bf7a36f6015a1189c"
        "d196fce772564d063b88a6f0fa8ab8e1984c72aa6f2fed28aed96270abf7a01"
    )

    # Base64 编码后的 GraphQL 接口地址
    _url_b64 = "aHR0cHM6Ly93d3cuZW5lYmEuY29tL2dyYXBocWwv"
    url = base64.b64decode(_url_b64).decode("utf-8")

    payload = {
        "operationName": "ProductPageAuctionCountries",
        "extensions": {
            "persistedQuery": {
                "version": 1,
                "sha256Hash": SHA256_HASH,
            }
        },
        "variables": {
            "slug": slug,
        },
    }

    try:
        resp = requests.post(url, json=payload, timeout=15)
        if resp.status_code == 200:
            return resp.json()
        return None
    except Exception:
        return None