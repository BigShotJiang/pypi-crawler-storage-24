from __future__ import annotations

import json
import mimetypes
import os
import sys
import time
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any, TextIO
from urllib import error as urllib_error
from urllib import request as urllib_request
from urllib.parse import urlparse

from .errors import (
    HardsimAuthenticationError,
    HardsimConfigurationError,
    HardsimNotFoundError,
    HardsimRateLimitError,
    HardsimRequestError,
    HardsimServerError,
    HardsimTransportError,
)
from .job import Job

DEFAULT_API_URL = "http://localhost:8000"
DEFAULT_TIMEOUT_S = 30.0
DEFAULT_MAX_RETRIES = 3
DEFAULT_RETRY_BACKOFF_S = 0.5
RETRYABLE_STATUS_CODES = {429, 500, 502, 503, 504}
RETRYABLE_METHODS = {"GET"}
USD_SUFFIXES = {".usd", ".usda", ".usdc"}
URDF_SUFFIXES = {".urdf"}
URDF_BUNDLE_SUFFIXES = {".zip"}


@dataclass
class _SimpleResponse:
    status_code: int
    content: bytes
    headers: dict[str, str]

    @property
    def text(self) -> str:
        return self.content.decode("utf-8", errors="replace")

    def json(self) -> Any:
        return json.loads(self.text)


class _UrlLibSession:
    def __init__(self) -> None:
        self.headers: dict[str, str] = {}

    def request(
        self,
        *,
        method: str,
        url: str,
        json: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
        include_default_headers: bool = True,
        timeout: float | None = None,
    ) -> _SimpleResponse:
        merged_headers = dict(self.headers) if include_default_headers else {}
        if headers:
            merged_headers.update(headers)

        payload: bytes | None = None
        if json is not None:
            payload = json_module_dumps(json).encode("utf-8")
            merged_headers.setdefault("Content-Type", "application/json")

        request = urllib_request.Request(
            url=url,
            method=method.upper(),
            headers=merged_headers,
            data=payload,
        )
        request_timeout = 30.0 if timeout is None else float(timeout)
        with urllib_request.urlopen(request, timeout=request_timeout) as response:
            status_code = getattr(response, "status", None) or response.getcode()
            raw_headers = response.headers
            normalized_headers = {str(k): str(v) for k, v in raw_headers.items()}
            body = response.read()
            return _SimpleResponse(
                status_code=int(status_code),
                content=body,
                headers=normalized_headers,
            )


def json_module_dumps(payload: Any) -> str:
    return json.dumps(payload, ensure_ascii=True, separators=(",", ":"))


def _to_response_from_http_error(exc: urllib_error.HTTPError) -> _SimpleResponse:
    body = b""
    try:
        body = exc.read() or b""
    except Exception:
        body = b""
    return _SimpleResponse(status_code=int(exc.code), content=body, headers={})


def _error_detail(response: Any) -> str:
    try:
        payload = response.json()
    except ValueError:
        text = response.text.strip()
        return text or "request failed"

    if isinstance(payload, dict) and "detail" in payload:
        detail = payload.get("detail")
        if isinstance(detail, str):
            return detail
        return json.dumps(detail, ensure_ascii=True)
    return json.dumps(payload, ensure_ascii=True)


def _raise_http_error(response: Any) -> None:
    status = response.status_code
    detail = _error_detail(response)
    if status in {401, 403}:
        raise HardsimAuthenticationError(status_code=status, detail=detail)
    if status == 404:
        raise HardsimNotFoundError(status_code=status, detail=detail)
    if status == 429:
        raise HardsimRateLimitError(status_code=status, detail=detail)
    if status >= 500:
        raise HardsimServerError(status_code=status, detail=detail)
    raise HardsimRequestError(status_code=status, detail=detail)


def _is_absolute_url(value: str) -> bool:
    parsed = urlparse(value)
    return bool(parsed.scheme and parsed.netloc)


def _normalize_optional_idempotency_key(idempotency_key: str | None) -> str | None:
    if idempotency_key is None:
        return None
    key = idempotency_key.strip()
    if not key:
        raise HardsimConfigurationError("idempotency_key must be non-empty when provided")
    if len(key) > 256:
        raise HardsimConfigurationError("idempotency_key must be <= 256 characters")
    return key


def _parse_s3_uri(uri: str) -> tuple[str, str]:
    parsed = urlparse(uri)
    if parsed.scheme != "s3" or not parsed.netloc:
        raise HardsimConfigurationError(f"invalid S3 URI: {uri}")
    key = parsed.path.lstrip("/")
    if not key:
        raise HardsimConfigurationError(f"S3 URI missing key: {uri}")
    return parsed.netloc, key


def _safe_filename(value: str) -> str:
    name = Path(value).name.strip()
    if not name:
        raise HardsimConfigurationError("input file name cannot be empty")
    return name


def _path_suffix(value: str) -> str:
    parsed = urlparse(value)
    candidate = parsed.path if parsed.scheme else value
    return Path(candidate).suffix.lower().strip()


def _emit_watch_line(stream: TextIO, line: str) -> None:
    stream.write(f"{line}\n")
    stream.flush()


class HardsimClient:
    def __init__(
        self,
        api_key: str,
        base_url: str = DEFAULT_API_URL,
        timeout_s: float = DEFAULT_TIMEOUT_S,
        max_retries: int = DEFAULT_MAX_RETRIES,
        retry_backoff_s: float = DEFAULT_RETRY_BACKOFF_S,
    ) -> None:
        api_key = api_key.strip()
        if not api_key:
            raise HardsimConfigurationError("api_key is required")
        if timeout_s <= 0:
            raise HardsimConfigurationError("timeout_s must be > 0")
        if max_retries < 0:
            raise HardsimConfigurationError("max_retries must be >= 0")
        if retry_backoff_s < 0:
            raise HardsimConfigurationError("retry_backoff_s must be >= 0")

        self.base_url = base_url.rstrip("/")
        self.timeout_s = float(timeout_s)
        self.max_retries = int(max_retries)
        self.retry_backoff_s = float(retry_backoff_s)
        self.session = _UrlLibSession()
        self.session.headers.update(
            {
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            }
        )

    def _create_s3_client(self):
        try:
            import boto3  # type: ignore
        except ImportError as exc:
            raise HardsimConfigurationError(
                "boto3 is required for upload_input(). install with: pip install boto3"
            ) from exc

        kwargs: dict[str, str] = {}
        region = os.getenv("HARDSIM_INPUT_S3_REGION", "").strip()
        endpoint_url = os.getenv("HARDSIM_INPUT_S3_ENDPOINT_URL", "").strip()
        if region:
            kwargs["region_name"] = region
        if endpoint_url:
            kwargs["endpoint_url"] = endpoint_url
        return boto3.client("s3", **kwargs)

    @classmethod
    def from_env(cls) -> "HardsimClient":
        api_key = os.getenv("HARDSIM_API_KEY", "").strip()
        if not api_key:
            raise HardsimConfigurationError("HARDSIM_API_KEY is required")

        base_url = os.getenv("HARDSIM_API_URL", DEFAULT_API_URL).strip() or DEFAULT_API_URL
        timeout_s = float(os.getenv("HARDSIM_HTTP_TIMEOUT_S", str(DEFAULT_TIMEOUT_S)))
        max_retries = int(os.getenv("HARDSIM_HTTP_RETRIES", str(DEFAULT_MAX_RETRIES)))
        retry_backoff_s = float(os.getenv("HARDSIM_HTTP_BACKOFF_S", str(DEFAULT_RETRY_BACKOFF_S)))
        return cls(
            api_key=api_key,
            base_url=base_url,
            timeout_s=timeout_s,
            max_retries=max_retries,
            retry_backoff_s=retry_backoff_s,
        )

    def _request(
        self,
        method: str,
        path_or_url: str,
        *,
        json_body: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
        timeout_s: float | None = None,
        retryable: bool | None = None,
        include_auth_header: bool = True,
    ) -> _SimpleResponse:
        method = method.upper()
        url = path_or_url if _is_absolute_url(path_or_url) else f"{self.base_url}{path_or_url}"
        request_timeout = self.timeout_s if timeout_s is None else float(timeout_s)
        is_retryable = method in RETRYABLE_METHODS if retryable is None else retryable

        for attempt in range(self.max_retries + 1):
            try:
                response = self.session.request(
                    method=method,
                    url=url,
                    json=json_body,
                    headers=headers,
                    include_default_headers=include_auth_header,
                    timeout=request_timeout,
                )
            except urllib_error.HTTPError as exc:
                response = _to_response_from_http_error(exc)
            except Exception as exc:
                if is_retryable and attempt < self.max_retries:
                    sleep_s = self.retry_backoff_s * (2**attempt)
                    if sleep_s > 0:
                        time.sleep(sleep_s)
                    continue
                raise HardsimTransportError(str(exc)) from exc

            if response.status_code >= 400:
                if (
                    is_retryable
                    and response.status_code in RETRYABLE_STATUS_CODES
                    and attempt < self.max_retries
                ):
                    sleep_s = self.retry_backoff_s * (2**attempt)
                    if sleep_s > 0:
                        time.sleep(sleep_s)
                    continue
                _raise_http_error(response)

            return response

        raise HardsimTransportError("request retry loop exhausted")

    def run(
        self,
        robot: str,
        scene: str,
        num_envs: int,
        steps: int,
        physics_dt: float = 0.005,
        substeps: int = 2,
        seed: int = 42,
        video: bool = True,
        log_format: str = "zarr",
        control: dict[str, Any] | None = None,
        idempotency_key: str | None = None,
    ) -> Job:
        payload: dict[str, Any] = {
            "job_type": "rollout",
            "robot": {"urdf_uri": robot},
            "scene": {"scene_id": scene},
            "physics": {"dt": physics_dt, "substeps": substeps},
            "execution": {"num_envs": num_envs, "steps": steps, "seed": seed},
            "outputs": {"video": video, "log_format": log_format},
        }
        if control:
            payload["control"] = dict(control)
        key = _normalize_optional_idempotency_key(idempotency_key) or f"auto-{uuid.uuid4().hex}"
        headers = {"Idempotency-Key": key} if key is not None else None
        response = self._request(
            "POST",
            "/v0/jobs",
            json_body=payload,
            headers=headers,
            retryable=True,
        )
        data = response.json()
        return Job(client=self, job_id=data["job_id"])

    def _resolve_uploaded_asset_uri(self, reference: str, *, role: str, auto_upload_inputs: bool) -> str:
        ref = reference.strip()
        if not ref:
            raise HardsimConfigurationError(f"{role} reference is required")

        parsed = urlparse(ref)
        scheme = parsed.scheme.lower()
        if scheme in {"s3", "http", "https"}:
            return ref

        if scheme == "file":
            local_path = parsed.path
        elif scheme == "":
            local_path = ref
        else:
            raise HardsimConfigurationError(
                f"{role} must be an s3/http(s) URI or local file path; got unsupported scheme in: {reference}"
            )

        if not auto_upload_inputs:
            raise HardsimConfigurationError(
                f"{role} local path requires auto_upload_inputs=True; got: {reference}"
            )
        return self.upload_input(local_path)

    def submit_assets(
        self,
        *,
        robot_asset: str | None = None,
        scene_usd: str | None = None,
        robot_asset_id: str | None = None,
        scene_asset_id: str | None = None,
        num_envs: int,
        steps: int,
        physics_dt: float = 0.005,
        substeps: int = 2,
        seed: int = 42,
        video: bool = True,
        log_format: str = "zarr",
        control: dict[str, Any] | None = None,
        idempotency_key: str | None = None,
        robot_asset_type: str = "auto",
        auto_upload_inputs: bool = True,
        scene_id: str | None = None,
    ) -> Job:
        robot_type = robot_asset_type.strip().lower()
        if robot_type not in {"auto", "urdf", "usd"}:
            raise HardsimConfigurationError("robot_asset_type must be one of: auto, urdf, usd")

        scene_payload: dict[str, Any]
        if scene_asset_id is not None and scene_asset_id.strip():
            scene_payload = {"usd_asset_id": scene_asset_id.strip()}
        else:
            if not scene_usd or not scene_usd.strip():
                raise HardsimConfigurationError("scene_usd or scene_asset_id is required")
            scene_uri = self._resolve_uploaded_asset_uri(
                scene_usd,
                role="scene_usd",
                auto_upload_inputs=auto_upload_inputs,
            )
            scene_suffix = _path_suffix(scene_uri)
            if scene_suffix not in USD_SUFFIXES:
                raise HardsimConfigurationError(
                    f"scene_usd must reference a USD file ({', '.join(sorted(USD_SUFFIXES))}); got: {scene_uri}"
                )
            scene_payload = {"usd_uri": scene_uri}

        if robot_asset_id is not None and robot_asset_id.strip():
            normalized_robot_asset_id = robot_asset_id.strip()
            if robot_type == "auto":
                raise HardsimConfigurationError(
                    "robot_asset_type must be set to 'urdf' or 'usd' when robot_asset_id is provided"
                )
            robot_payload = (
                {"urdf_asset_id": normalized_robot_asset_id}
                if robot_type == "urdf"
                else {"usd_asset_id": normalized_robot_asset_id}
            )
        else:
            if not robot_asset or not robot_asset.strip():
                raise HardsimConfigurationError("robot_asset or robot_asset_id is required")
            robot_uri = self._resolve_uploaded_asset_uri(
                robot_asset,
                role="robot_asset",
                auto_upload_inputs=auto_upload_inputs,
            )
            robot_suffix = _path_suffix(robot_uri)
            if robot_type == "auto":
                if robot_suffix in URDF_SUFFIXES or robot_suffix in URDF_BUNDLE_SUFFIXES:
                    robot_type = "urdf"
                elif robot_suffix in USD_SUFFIXES:
                    robot_type = "usd"
                else:
                    raise HardsimConfigurationError(
                        "unable to infer robot_asset_type from suffix; set robot_asset_type to 'urdf' or 'usd'"
                    )
            elif robot_type == "urdf" and robot_suffix not in URDF_SUFFIXES and robot_suffix not in URDF_BUNDLE_SUFFIXES:
                raise HardsimConfigurationError(
                    f"robot_asset_type=urdf requires .urdf or .zip asset bundle; got: {robot_uri}"
                )
            elif robot_type == "usd" and robot_suffix not in USD_SUFFIXES:
                raise HardsimConfigurationError(
                    f"robot_asset_type=usd requires USD asset ({', '.join(sorted(USD_SUFFIXES))}); got: {robot_uri}"
                )
            robot_payload = {"urdf_uri": robot_uri} if robot_type == "urdf" else {"usd_uri": robot_uri}

        if scene_id:
            normalized_scene_id = scene_id.strip()
            if normalized_scene_id:
                scene_payload["scene_id"] = normalized_scene_id

        payload: dict[str, Any] = {
            "job_type": "rollout",
            "robot": robot_payload,
            "scene": scene_payload,
            "physics": {"dt": physics_dt, "substeps": substeps},
            "execution": {"num_envs": num_envs, "steps": steps, "seed": seed},
            "outputs": {"video": video, "log_format": log_format},
        }
        if control:
            payload["control"] = dict(control)
        key = _normalize_optional_idempotency_key(idempotency_key) or f"auto-{uuid.uuid4().hex}"
        headers = {"Idempotency-Key": key} if key is not None else None
        response = self._request(
            "POST",
            "/v0/jobs",
            json_body=payload,
            headers=headers,
            retryable=True,
        )
        data = response.json()
        return Job(client=self, job_id=data["job_id"])

    def submit(
        self,
        robot: str,
        scene: str,
        num_envs: int,
        steps: int,
        physics_dt: float = 0.005,
        substeps: int = 2,
        seed: int = 42,
        video: bool = True,
        log_format: str = "zarr",
        control: dict[str, Any] | None = None,
        idempotency_key: str | None = None,
    ) -> Job:
        return self.run(
            robot=robot,
            scene=scene,
            num_envs=num_envs,
            steps=steps,
            physics_dt=physics_dt,
            substeps=substeps,
            seed=seed,
            video=video,
            log_format=log_format,
            control=control,
            idempotency_key=idempotency_key,
        )

    def step(
        self,
        robot: str,
        scene: str,
        num_envs: int,
        steps: int,
        physics_dt: float = 0.005,
        substeps: int = 2,
        seed: int = 42,
        video: bool = True,
        log_format: str = "zarr",
        control: dict[str, Any] | None = None,
        idempotency_key: str | None = None,
    ) -> Job:
        """Alias for run(...), matching the intended cloud-routed step UX."""
        return self.run(
            robot=robot,
            scene=scene,
            num_envs=num_envs,
            steps=steps,
            physics_dt=physics_dt,
            substeps=substeps,
            seed=seed,
            video=video,
            log_format=log_format,
            control=control,
            idempotency_key=idempotency_key,
        )

    def status(self, job_id: str) -> dict[str, Any]:
        response = self._request("GET", f"/v0/jobs/{job_id}")
        return response.json()

    def wait(
        self,
        job_id: str,
        poll_interval_s: float = 2.0,
        timeout_s: float = 1800.0,
        raise_on_error: bool = True,
    ) -> dict[str, Any]:
        return Job(client=self, job_id=job_id).wait(
            poll_interval_s=poll_interval_s,
            timeout_s=timeout_s,
            raise_on_error=raise_on_error,
        )

    def watch_job(
        self,
        job_id: str,
        *,
        poll_interval_s: float = 2.0,
        timeout_s: float = 1800.0,
        raise_on_error: bool = True,
        stream: TextIO | None = None,
    ) -> dict[str, Any]:
        if poll_interval_s <= 0:
            raise HardsimConfigurationError("poll_interval_s must be > 0")
        if timeout_s <= 0:
            raise HardsimConfigurationError("timeout_s must be > 0")

        output = stream or sys.stdout
        deadline = time.monotonic() + timeout_s
        last_status: str | None = None

        while True:
            data = self.status(job_id)
            status = str(data.get("status", "")).strip().lower()
            if status != last_status:
                line = f"job {job_id} status={status or 'unknown'}"
                attempt_count = data.get("attempt_count")
                if isinstance(attempt_count, int) and attempt_count > 0:
                    line += f" attempt={attempt_count}"
                error_text = data.get("error")
                if isinstance(error_text, str) and error_text.strip():
                    line += f" error={error_text.strip()}"
                _emit_watch_line(output, line)
                last_status = status

            if status in {"succeeded", "failed", "canceled"}:
                if raise_on_error and status == "failed":
                    raise HardsimRequestError(
                        status_code=409,
                        detail=f"job {job_id} ended with status=failed: {json_module_dumps(data)}",
                    )
                if raise_on_error and status == "canceled":
                    raise HardsimRequestError(
                        status_code=409,
                        detail=f"job {job_id} ended with status=canceled: {json_module_dumps(data)}",
                    )
                return data

            if time.monotonic() >= deadline:
                raise HardsimRequestError(
                    status_code=408,
                    detail=f"timed out waiting for job {job_id}",
                )
            time.sleep(poll_interval_s)

    def cancel(self, job_id: str) -> dict[str, Any]:
        response = self._request("POST", f"/v0/jobs/{job_id}/cancel", retryable=True)
        return response.json()

    def create_training_run(
        self,
        *,
        project_id: str,
        name: str,
        rollout_template: dict[str, Any],
        trainer_spec: dict[str, Any],
        checkpoint_init_uri: str | None = None,
        checkpoint_init_asset_id: str | None = None,
        loop_policy: dict[str, Any] | None = None,
        success_criteria: dict[str, Any] | None = None,
        budget_policy: dict[str, Any] | None = None,
        idempotency_key: str | None = None,
    ) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "project_id": project_id,
            "name": name,
            "rollout_template": dict(rollout_template),
            "trainer_spec": dict(trainer_spec),
            "loop_policy": dict(loop_policy or {}),
            "success_criteria": dict(success_criteria or {}),
            "budget_policy": dict(budget_policy or {}),
        }
        if checkpoint_init_uri is not None:
            payload["checkpoint_init_uri"] = checkpoint_init_uri
        if checkpoint_init_asset_id is not None:
            payload["checkpoint_init_asset_id"] = checkpoint_init_asset_id
        headers = {}
        normalized_key = _normalize_optional_idempotency_key(idempotency_key)
        if normalized_key is not None:
            headers["Idempotency-Key"] = normalized_key
        response = self._request(
            "POST",
            "/v1/training-runs",
            json_body=payload,
            headers=headers or None,
            retryable=True,
        )
        return response.json()

    def list_training_runs(self, limit: int = 30) -> list[dict[str, Any]]:
        response = self._request("GET", f"/v1/training-runs?limit={max(1, int(limit))}")
        payload = response.json()
        runs = payload.get("runs")
        return list(runs) if isinstance(runs, list) else []

    def get_training_run(self, run_id: str) -> dict[str, Any]:
        response = self._request("GET", f"/v1/training-runs/{run_id}")
        return response.json()

    def wait_training_run(
        self,
        run_id: str,
        *,
        poll_interval_s: float = 5.0,
        timeout_s: float = 24 * 3600.0,
        raise_on_error: bool = True,
    ) -> dict[str, Any]:
        if poll_interval_s <= 0:
            raise HardsimConfigurationError("poll_interval_s must be > 0")
        if timeout_s <= 0:
            raise HardsimConfigurationError("timeout_s must be > 0")

        deadline = time.monotonic() + timeout_s
        while True:
            run = self.get_training_run(run_id)
            status = str(run.get("status", "")).strip().lower()
            if status in {"succeeded", "failed", "canceled"}:
                if raise_on_error and status != "succeeded":
                    detail = json_module_dumps(run)
                    raise HardsimRequestError(status_code=409, detail=f"training run ended with status={status}: {detail}")
                return run
            if time.monotonic() >= deadline:
                raise HardsimRequestError(
                    status_code=408,
                    detail=f"timed out waiting for training run {run_id}",
                )
            time.sleep(poll_interval_s)

    def watch_training_run(
        self,
        run_id: str,
        *,
        poll_interval_s: float = 5.0,
        timeout_s: float = 24 * 3600.0,
        raise_on_error: bool = True,
        stream: TextIO | None = None,
        event_limit: int = 200,
    ) -> dict[str, Any]:
        if poll_interval_s <= 0:
            raise HardsimConfigurationError("poll_interval_s must be > 0")
        if timeout_s <= 0:
            raise HardsimConfigurationError("timeout_s must be > 0")
        if event_limit <= 0:
            raise HardsimConfigurationError("event_limit must be > 0")

        output = stream or sys.stdout
        deadline = time.monotonic() + timeout_s
        seen_event_keys: set[str] = set()
        last_status: str | None = None
        last_stage: str | None = None
        last_iteration: int | None = None

        while True:
            run = self.get_training_run(run_id)
            status = str(run.get("status", "")).strip().lower()
            stage_value = run.get("stage")
            stage = str(stage_value).strip() if isinstance(stage_value, str) else ""
            current_iteration = run.get("current_iteration")
            iteration_int = current_iteration if isinstance(current_iteration, int) else None

            if status != last_status or stage != (last_stage or "") or iteration_int != last_iteration:
                line = f"training_run {run_id} status={status or 'unknown'}"
                if stage:
                    line += f" stage={stage}"
                if iteration_int is not None:
                    line += f" iteration={iteration_int}"
                error_text = run.get("error")
                if isinstance(error_text, str) and error_text.strip():
                    line += f" error={error_text.strip()}"
                _emit_watch_line(output, line)
                last_status = status
                last_stage = stage
                last_iteration = iteration_int

            events = self.list_training_events(run_id, limit=event_limit)
            events_sorted = sorted(
                events,
                key=lambda item: (
                    str(item.get("created_at", "")),
                    str(item.get("event_id", "")),
                ),
            )
            for event in events_sorted:
                event_id = str(event.get("event_id", "")).strip()
                event_type = str(event.get("event_type", "")).strip() or "event"
                created_at = str(event.get("created_at", "")).strip()
                message = str(event.get("message", "")).strip()
                fallback_key = f"{created_at}|{event_type}|{message}"
                dedupe_key = event_id or fallback_key
                if not dedupe_key or dedupe_key in seen_event_keys:
                    continue
                seen_event_keys.add(dedupe_key)
                prefix = f"[{created_at}] " if created_at else ""
                _emit_watch_line(output, f"{prefix}{event_type}: {message or '-'}")

            if status in {"succeeded", "failed", "canceled"}:
                if raise_on_error and status != "succeeded":
                    detail = json_module_dumps(run)
                    raise HardsimRequestError(status_code=409, detail=f"training run ended with status={status}: {detail}")
                return run

            if time.monotonic() >= deadline:
                raise HardsimRequestError(
                    status_code=408,
                    detail=f"timed out waiting for training run {run_id}",
                )
            time.sleep(poll_interval_s)

    def pause_training_run(self, run_id: str) -> dict[str, Any]:
        response = self._request("POST", f"/v1/training-runs/{run_id}/pause", retryable=True)
        return response.json()

    def resume_training_run(self, run_id: str) -> dict[str, Any]:
        response = self._request("POST", f"/v1/training-runs/{run_id}/resume", retryable=True)
        return response.json()

    def cancel_training_run(self, run_id: str) -> dict[str, Any]:
        response = self._request("POST", f"/v1/training-runs/{run_id}/cancel", retryable=True)
        return response.json()

    def list_training_iterations(self, run_id: str, *, limit: int = 200) -> list[dict[str, Any]]:
        response = self._request("GET", f"/v1/training-runs/{run_id}/iterations?limit={max(1, int(limit))}")
        payload = response.json()
        items = payload.get("iterations")
        return list(items) if isinstance(items, list) else []

    def list_run_checkpoints(self, run_id: str, *, limit: int = 200) -> list[dict[str, Any]]:
        response = self._request("GET", f"/v1/training-runs/{run_id}/checkpoints?limit={max(1, int(limit))}")
        payload = response.json()
        checkpoints = payload.get("checkpoints")
        return list(checkpoints) if isinstance(checkpoints, list) else []

    def get_latest_checkpoint(self, run_id: str) -> dict[str, Any] | None:
        checkpoints = self.list_run_checkpoints(run_id, limit=1)
        if not checkpoints:
            return None
        return checkpoints[0]

    def list_training_events(self, run_id: str, *, limit: int = 500) -> list[dict[str, Any]]:
        response = self._request("GET", f"/v1/training-runs/{run_id}/events?limit={max(1, int(limit))}")
        payload = response.json()
        events = payload.get("events")
        return list(events) if isinstance(events, list) else []

    def get_download_url(self, job_id: str, artifact_name: str) -> str:
        response = self._request(
            "GET",
            f"/v0/jobs/{job_id}/artifacts/{artifact_name}/download-url",
        )
        return response.json()["url"]

    def download_artifact(self, job_id: str, artifact_name: str, timeout_s: float = 120.0) -> bytes:
        url = self.get_download_url(job_id=job_id, artifact_name=artifact_name)
        response = self._request(
            "GET",
            url,
            timeout_s=timeout_s,
            retryable=True,
            include_auth_header=False,
        )
        return response.content

    def download(self, job_id: str, output_dir: str) -> list[str]:
        return Job(client=self, job_id=job_id).download(output_dir=output_dir)

    def upload_input(
        self,
        local_path: str,
        *,
        destination_uri: str | None = None,
        bucket: str | None = None,
        key_prefix: str | None = None,
        object_name: str | None = None,
        prefer_presigned: bool = True,
        register_asset: bool = False,
        asset_kind: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> str:
        source_path = Path(local_path).expanduser().resolve()
        if not source_path.is_file():
            raise HardsimConfigurationError(f"local input file not found: {source_path}")

        resolved_bucket = (bucket or os.getenv("HARDSIM_INPUT_S3_BUCKET", "")).strip()
        if prefer_presigned and destination_uri is None and bucket is None:
            try:
                upload_result = self._upload_input_via_presigned(
                    source_path=source_path,
                    object_name=object_name,
                    register_asset=register_asset,
                    asset_kind=asset_kind,
                    metadata=metadata,
                )
                return str(upload_result["input_uri"])
            except (HardsimNotFoundError, HardsimRequestError, HardsimServerError, HardsimTransportError):
                if not resolved_bucket:
                    raise

        if destination_uri:
            target_bucket, target_key = _parse_s3_uri(destination_uri)
        else:
            target_bucket = resolved_bucket
            if not target_bucket:
                raise HardsimConfigurationError(
                    "bucket is required (or set HARDSIM_INPUT_S3_BUCKET) when destination_uri is not provided"
                )
            effective_prefix = (key_prefix or os.getenv("HARDSIM_INPUT_S3_PREFIX", "hardsim/inputs")).strip().strip("/")
            file_name = _safe_filename(object_name or source_path.name)
            unique_name = f"{uuid.uuid4().hex}_{file_name}"
            target_key = "/".join(part for part in (effective_prefix, unique_name) if part)

        content_type = mimetypes.guess_type(source_path.name)[0] or "application/octet-stream"
        s3_client = self._create_s3_client()
        try:
            s3_client.upload_file(
                str(source_path),
                target_bucket,
                target_key,
                ExtraArgs={"ContentType": content_type},
            )
        except Exception as exc:
            raise HardsimTransportError(f"failed to upload input asset to s3://{target_bucket}/{target_key}: {exc}") from exc

        input_uri = f"s3://{target_bucket}/{target_key}"
        if register_asset:
            self.register_input_asset(
                input_uri=input_uri,
                filename=_safe_filename(object_name or source_path.name),
                content_type=content_type,
                size_bytes=source_path.stat().st_size,
                kind=asset_kind,
                metadata=metadata,
            )
        return input_uri

    def _upload_input_via_presigned(
        self,
        *,
        source_path: Path,
        object_name: str | None = None,
        register_asset: bool = False,
        asset_kind: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        content_type = mimetypes.guess_type(source_path.name)[0] or "application/octet-stream"
        request_payload = {
            "filename": _safe_filename(object_name or source_path.name),
            "content_type": content_type,
            "size_bytes": source_path.stat().st_size,
            "register_asset": bool(register_asset),
            "asset_kind": asset_kind,
            "metadata": dict(metadata or {}),
        }
        response = self._request(
            "POST",
            "/v0/inputs/presign-upload",
            json_body=request_payload,
            retryable=True,
        )
        payload = response.json()
        upload_url = str(payload["upload_url"])
        upload_method = str(payload.get("upload_method") or "PUT").upper()
        upload_headers = payload.get("upload_headers") or {}
        if not isinstance(upload_headers, dict):
            raise HardsimTransportError("invalid upload_headers from presign endpoint")

        normalized_headers = {str(key): str(value) for key, value in upload_headers.items()}
        file_bytes = source_path.read_bytes()
        request_obj = urllib_request.Request(
            upload_url,
            method=upload_method,
            headers=normalized_headers,
            data=file_bytes,
        )
        request_timeout = float(self.timeout_s)
        try:
            with urllib_request.urlopen(request_obj, timeout=request_timeout) as upload_response:
                status_code = getattr(upload_response, "status", None) or upload_response.getcode()
                if int(status_code) >= 400:
                    raise HardsimTransportError(
                        f"presigned upload failed with status {int(status_code)}"
                    )
        except urllib_error.HTTPError as exc:
            detail = ""
            try:
                detail = exc.read().decode("utf-8", errors="replace").strip()
            except Exception:
                detail = ""
            raise HardsimTransportError(
                f"presigned upload failed status={int(exc.code)} detail={detail or 'n/a'}"
            ) from exc
        except Exception as exc:
            raise HardsimTransportError(f"presigned upload failed: {exc}") from exc

        input_uri = payload.get("input_uri")
        if not isinstance(input_uri, str) or not input_uri.strip():
            raise HardsimTransportError("presign endpoint did not return input_uri")
        return payload

    def register_input_asset(
        self,
        *,
        input_uri: str,
        filename: str | None = None,
        content_type: str | None = None,
        size_bytes: int | None = None,
        kind: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        payload: dict[str, Any] = {"input_uri": input_uri}
        if filename is not None:
            payload["filename"] = filename
        if content_type is not None:
            payload["content_type"] = content_type
        if size_bytes is not None:
            payload["size_bytes"] = int(size_bytes)
        if kind is not None:
            payload["kind"] = kind
        if metadata is not None:
            payload["metadata"] = dict(metadata)
        response = self._request(
            "POST",
            "/v0/assets/register",
            json_body=payload,
            retryable=True,
        )
        return response.json()

    def get_input_asset(self, asset_id: str) -> dict[str, Any]:
        response = self._request(
            "GET",
            f"/v0/assets/{asset_id}",
            retryable=True,
        )
        return response.json()

    def list_input_assets(self, *, limit: int = 100) -> list[dict[str, Any]]:
        response = self._request(
            "GET",
            f"/v0/assets?limit={max(1, int(limit))}",
            retryable=True,
        )
        payload = response.json()
        assets = payload.get("assets")
        return list(assets) if isinstance(assets, list) else []

    def upload_input_asset(
        self,
        local_path: str,
        *,
        destination_uri: str | None = None,
        bucket: str | None = None,
        key_prefix: str | None = None,
        object_name: str | None = None,
        prefer_presigned: bool = True,
        asset_kind: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> str:
        source_path = Path(local_path).expanduser().resolve()
        if not source_path.is_file():
            raise HardsimConfigurationError(f"local input file not found: {source_path}")

        if prefer_presigned and destination_uri is None and bucket is None:
            try:
                payload = self._upload_input_via_presigned(
                    source_path=source_path,
                    object_name=object_name,
                    register_asset=True,
                    asset_kind=asset_kind,
                    metadata=metadata,
                )
                asset_id = payload.get("asset_id")
                if isinstance(asset_id, str) and asset_id.strip():
                    return asset_id
                input_uri = payload.get("input_uri")
                if not isinstance(input_uri, str) or not input_uri.strip():
                    raise HardsimTransportError("presign endpoint did not return input_uri for asset registration")
                registered = self.register_input_asset(
                    input_uri=input_uri,
                    filename=_safe_filename(object_name or source_path.name),
                    content_type=mimetypes.guess_type(source_path.name)[0] or "application/octet-stream",
                    size_bytes=source_path.stat().st_size,
                    kind=asset_kind,
                    metadata=metadata,
                )
                registered_id = registered.get("asset_id")
                if not isinstance(registered_id, str) or not registered_id.strip():
                    raise HardsimTransportError("asset registration response did not include asset_id")
                return registered_id
            except (HardsimNotFoundError, HardsimRequestError, HardsimServerError, HardsimTransportError):
                if not (bucket or os.getenv("HARDSIM_INPUT_S3_BUCKET", "")).strip():
                    raise

        input_uri = self.upload_input(
            local_path=local_path,
            destination_uri=destination_uri,
            bucket=bucket,
            key_prefix=key_prefix,
            object_name=object_name,
            prefer_presigned=prefer_presigned,
            register_asset=False,
        )
        registered = self.register_input_asset(
            input_uri=input_uri,
            filename=_safe_filename(object_name or source_path.name),
            content_type=mimetypes.guess_type(source_path.name)[0] or "application/octet-stream",
            size_bytes=source_path.stat().st_size,
            kind=asset_kind,
            metadata=metadata,
        )
        asset_id = registered.get("asset_id")
        if not isinstance(asset_id, str) or not asset_id.strip():
            raise HardsimTransportError("asset registration response did not include asset_id")
        return asset_id


def run(
    robot: str,
    scene: str,
    num_envs: int,
    steps: int,
    physics_dt: float = 0.005,
    substeps: int = 2,
    seed: int = 42,
    video: bool = True,
    log_format: str = "zarr",
    control: dict[str, Any] | None = None,
    idempotency_key: str | None = None,
) -> Job:
    client = HardsimClient.from_env()
    return client.run(
        robot=robot,
        scene=scene,
        num_envs=num_envs,
        steps=steps,
        physics_dt=physics_dt,
        substeps=substeps,
        seed=seed,
        video=video,
        log_format=log_format,
        control=control,
        idempotency_key=idempotency_key,
    )


def submit(
    robot: str,
    scene: str,
    num_envs: int,
    steps: int,
    physics_dt: float = 0.005,
    substeps: int = 2,
    seed: int = 42,
    video: bool = True,
    log_format: str = "zarr",
    control: dict[str, Any] | None = None,
    idempotency_key: str | None = None,
) -> Job:
    client = HardsimClient.from_env()
    return client.submit(
        robot=robot,
        scene=scene,
        num_envs=num_envs,
        steps=steps,
        physics_dt=physics_dt,
        substeps=substeps,
        seed=seed,
        video=video,
        log_format=log_format,
        control=control,
        idempotency_key=idempotency_key,
    )


def step(
    robot: str,
    scene: str,
    num_envs: int,
    steps: int,
    physics_dt: float = 0.005,
    substeps: int = 2,
    seed: int = 42,
    video: bool = True,
    log_format: str = "zarr",
    control: dict[str, Any] | None = None,
    idempotency_key: str | None = None,
) -> Job:
    client = HardsimClient.from_env()
    return client.step(
        robot=robot,
        scene=scene,
        num_envs=num_envs,
        steps=steps,
        physics_dt=physics_dt,
        substeps=substeps,
        seed=seed,
        video=video,
        log_format=log_format,
        control=control,
        idempotency_key=idempotency_key,
    )


def wait(
    job_id: str,
    poll_interval_s: float = 2.0,
    timeout_s: float = 1800.0,
    raise_on_error: bool = True,
) -> dict[str, Any]:
    client = HardsimClient.from_env()
    return client.wait(
        job_id=job_id,
        poll_interval_s=poll_interval_s,
        timeout_s=timeout_s,
        raise_on_error=raise_on_error,
    )


def watch(
    job_id: str,
    *,
    poll_interval_s: float = 2.0,
    timeout_s: float = 1800.0,
    raise_on_error: bool = True,
    stream: TextIO | None = None,
) -> dict[str, Any]:
    client = HardsimClient.from_env()
    return client.watch_job(
        job_id=job_id,
        poll_interval_s=poll_interval_s,
        timeout_s=timeout_s,
        raise_on_error=raise_on_error,
        stream=stream,
    )


def download(job_id: str, output_dir: str) -> list[str]:
    client = HardsimClient.from_env()
    return client.download(job_id=job_id, output_dir=output_dir)


def upload_input(
    local_path: str,
    *,
    destination_uri: str | None = None,
    bucket: str | None = None,
    key_prefix: str | None = None,
    object_name: str | None = None,
    prefer_presigned: bool = True,
    register_asset: bool = False,
    asset_kind: str | None = None,
    metadata: dict[str, Any] | None = None,
) -> str:
    client = HardsimClient.from_env()
    return client.upload_input(
        local_path=local_path,
        destination_uri=destination_uri,
        bucket=bucket,
        key_prefix=key_prefix,
        object_name=object_name,
        prefer_presigned=prefer_presigned,
        register_asset=register_asset,
        asset_kind=asset_kind,
        metadata=metadata,
    )


def upload_input_asset(
    local_path: str,
    *,
    destination_uri: str | None = None,
    bucket: str | None = None,
    key_prefix: str | None = None,
    object_name: str | None = None,
    prefer_presigned: bool = True,
    asset_kind: str | None = None,
    metadata: dict[str, Any] | None = None,
) -> str:
    client = HardsimClient.from_env()
    return client.upload_input_asset(
        local_path=local_path,
        destination_uri=destination_uri,
        bucket=bucket,
        key_prefix=key_prefix,
        object_name=object_name,
        prefer_presigned=prefer_presigned,
        asset_kind=asset_kind,
        metadata=metadata,
    )


def register_input_asset(
    *,
    input_uri: str,
    filename: str | None = None,
    content_type: str | None = None,
    size_bytes: int | None = None,
    kind: str | None = None,
    metadata: dict[str, Any] | None = None,
) -> dict[str, Any]:
    client = HardsimClient.from_env()
    return client.register_input_asset(
        input_uri=input_uri,
        filename=filename,
        content_type=content_type,
        size_bytes=size_bytes,
        kind=kind,
        metadata=metadata,
    )


def get_input_asset(asset_id: str) -> dict[str, Any]:
    client = HardsimClient.from_env()
    return client.get_input_asset(asset_id)


def list_input_assets(*, limit: int = 100) -> list[dict[str, Any]]:
    client = HardsimClient.from_env()
    return client.list_input_assets(limit=limit)


def create_training_run(
    *,
    project_id: str,
    name: str,
    rollout_template: dict[str, Any],
    trainer_spec: dict[str, Any],
    checkpoint_init_uri: str | None = None,
    checkpoint_init_asset_id: str | None = None,
    loop_policy: dict[str, Any] | None = None,
    success_criteria: dict[str, Any] | None = None,
    budget_policy: dict[str, Any] | None = None,
    idempotency_key: str | None = None,
) -> dict[str, Any]:
    client = HardsimClient.from_env()
    return client.create_training_run(
        project_id=project_id,
        name=name,
        rollout_template=rollout_template,
        trainer_spec=trainer_spec,
        checkpoint_init_uri=checkpoint_init_uri,
        checkpoint_init_asset_id=checkpoint_init_asset_id,
        loop_policy=loop_policy,
        success_criteria=success_criteria,
        budget_policy=budget_policy,
        idempotency_key=idempotency_key,
    )


def get_training_run(run_id: str) -> dict[str, Any]:
    client = HardsimClient.from_env()
    return client.get_training_run(run_id)


def wait_training_run(
    run_id: str,
    *,
    poll_interval_s: float = 5.0,
    timeout_s: float = 24 * 3600.0,
    raise_on_error: bool = True,
) -> dict[str, Any]:
    client = HardsimClient.from_env()
    return client.wait_training_run(
        run_id,
        poll_interval_s=poll_interval_s,
        timeout_s=timeout_s,
        raise_on_error=raise_on_error,
    )


def watch_training_run(
    run_id: str,
    *,
    poll_interval_s: float = 5.0,
    timeout_s: float = 24 * 3600.0,
    raise_on_error: bool = True,
    stream: TextIO | None = None,
    event_limit: int = 200,
) -> dict[str, Any]:
    client = HardsimClient.from_env()
    return client.watch_training_run(
        run_id,
        poll_interval_s=poll_interval_s,
        timeout_s=timeout_s,
        raise_on_error=raise_on_error,
        stream=stream,
        event_limit=event_limit,
    )


def pause_training_run(run_id: str) -> dict[str, Any]:
    client = HardsimClient.from_env()
    return client.pause_training_run(run_id)


def resume_training_run(run_id: str) -> dict[str, Any]:
    client = HardsimClient.from_env()
    return client.resume_training_run(run_id)


def cancel_training_run(run_id: str) -> dict[str, Any]:
    client = HardsimClient.from_env()
    return client.cancel_training_run(run_id)


def list_run_checkpoints(run_id: str, *, limit: int = 200) -> list[dict[str, Any]]:
    client = HardsimClient.from_env()
    return client.list_run_checkpoints(run_id, limit=limit)


def get_latest_checkpoint(run_id: str) -> dict[str, Any] | None:
    client = HardsimClient.from_env()
    return client.get_latest_checkpoint(run_id)


def submit_assets(
    *,
    robot_asset: str | None = None,
    scene_usd: str | None = None,
    robot_asset_id: str | None = None,
    scene_asset_id: str | None = None,
    num_envs: int,
    steps: int,
    physics_dt: float = 0.005,
    substeps: int = 2,
    seed: int = 42,
    video: bool = True,
    log_format: str = "zarr",
    control: dict[str, Any] | None = None,
    idempotency_key: str | None = None,
    robot_asset_type: str = "auto",
    auto_upload_inputs: bool = True,
    scene_id: str | None = None,
) -> Job:
    client = HardsimClient.from_env()
    return client.submit_assets(
        robot_asset=robot_asset,
        scene_usd=scene_usd,
        robot_asset_id=robot_asset_id,
        scene_asset_id=scene_asset_id,
        num_envs=num_envs,
        steps=steps,
        physics_dt=physics_dt,
        substeps=substeps,
        seed=seed,
        video=video,
        log_format=log_format,
        control=control,
        idempotency_key=idempotency_key,
        robot_asset_type=robot_asset_type,
        auto_upload_inputs=auto_upload_inputs,
        scene_id=scene_id,
    )
