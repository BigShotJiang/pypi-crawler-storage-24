"""LangChain tools for DocAPI — generate PDFs, screenshots, and invoices."""

from typing import List, Optional, Type

from langchain_core.tools import BaseTool
from pydantic import BaseModel, Field


class PDFInput(BaseModel):
    """Input schema for DocAPIPDFTool."""

    html: str = Field(description="HTML content to render as PDF.")
    output_path: str = Field(
        default="output.pdf", description="File path to save the generated PDF."
    )
    format: str = Field(default="A4", description="Page format (e.g. A4, Letter).")
    landscape: bool = Field(default=False, description="Use landscape orientation.")


class ScreenshotInput(BaseModel):
    """Input schema for DocAPIScreenshotTool."""

    url: Optional[str] = Field(default=None, description="URL to capture.")
    html: Optional[str] = Field(
        default=None, description="HTML content to render and capture."
    )
    output_path: str = Field(
        default="screenshot.png",
        description="File path to save the captured screenshot.",
    )
    width: int = Field(default=1280, description="Viewport width in pixels.")
    height: int = Field(default=800, description="Viewport height in pixels.")


class InvoiceLineItem(BaseModel):
    """A single line item on an invoice."""

    description: str = Field(description="Description of the item.")
    quantity: int = Field(description="Quantity of the item.")
    unit_price: float = Field(description="Unit price of the item.")


class InvoiceInput(BaseModel):
    """Input schema for DocAPIInvoiceTool."""

    from_name: str = Field(description="Seller / sender name.")
    to_name: str = Field(description="Buyer / recipient name.")
    line_items: List[dict] = Field(
        description="List of line items, each with description, quantity, and unit_price."
    )
    output_path: str = Field(
        default="invoice.pdf", description="File path to save the generated invoice."
    )
    from_email: Optional[str] = Field(
        default=None, description="Seller email address."
    )
    to_email: Optional[str] = Field(
        default=None, description="Buyer email address."
    )
    invoice_number: Optional[str] = Field(
        default=None, description="Invoice number."
    )
    date: Optional[str] = Field(default=None, description="Invoice date.")
    due_date: Optional[str] = Field(default=None, description="Payment due date.")
    currency_symbol: str = Field(
        default="$", description="Currency symbol to display."
    )
    tax_percent: Optional[float] = Field(
        default=None, description="Tax percentage to apply."
    )
    notes: Optional[str] = Field(
        default=None, description="Additional notes on the invoice."
    )


class DocAPIPDFTool(BaseTool):
    """Generate a PDF from HTML content using DocAPI."""

    name: str = "docapi_pdf"
    description: str = (
        "Generate a PDF from HTML content. Supports full CSS "
        "(Flexbox, Grid, Google Fonts). Returns the PDF as bytes "
        "saved to the specified output path."
    )
    args_schema: Type[BaseModel] = PDFInput
    api_key: str

    def _run(
        self,
        html: str,
        output_path: str = "output.pdf",
        format: str = "A4",
        landscape: bool = False,
    ) -> str:
        try:
            from docapi import DocAPI

            client = DocAPI(self.api_key)
            pdf_bytes = client.pdf(html, format=format, landscape=landscape)
            with open(output_path, "wb") as f:
                f.write(pdf_bytes)
            return f"PDF saved to {output_path} ({len(pdf_bytes)} bytes)"
        except Exception as e:
            return f"Error generating PDF: {e}"


class DocAPIScreenshotTool(BaseTool):
    """Capture a screenshot of a URL or HTML content using DocAPI."""

    name: str = "docapi_screenshot"
    description: str = (
        "Capture a screenshot of a URL or HTML content as PNG/JPEG. "
        "Returns the image saved to the specified output path."
    )
    args_schema: Type[BaseModel] = ScreenshotInput
    api_key: str

    def _run(
        self,
        url: Optional[str] = None,
        html: Optional[str] = None,
        output_path: str = "screenshot.png",
        width: int = 1280,
        height: int = 800,
    ) -> str:
        try:
            from docapi import DocAPI

            client = DocAPI(self.api_key)
            image_bytes = client.screenshot(
                url=url, html=html, width=width, height=height
            )
            with open(output_path, "wb") as f:
                f.write(image_bytes)
            return f"Screenshot saved to {output_path} ({len(image_bytes)} bytes)"
        except Exception as e:
            return f"Error capturing screenshot: {e}"


class DocAPIInvoiceTool(BaseTool):
    """Generate a professional invoice PDF from structured data using DocAPI."""

    name: str = "docapi_invoice"
    description: str = (
        "Generate a professional invoice PDF from structured data. "
        "Accepts seller info, buyer info, and line items. Returns "
        "the invoice PDF saved to the specified output path."
    )
    args_schema: Type[BaseModel] = InvoiceInput
    api_key: str

    def _run(
        self,
        from_name: str,
        to_name: str,
        line_items: List[dict],
        output_path: str = "invoice.pdf",
        from_email: Optional[str] = None,
        to_email: Optional[str] = None,
        invoice_number: Optional[str] = None,
        date: Optional[str] = None,
        due_date: Optional[str] = None,
        currency_symbol: str = "$",
        tax_percent: Optional[float] = None,
        notes: Optional[str] = None,
    ) -> str:
        try:
            from docapi import DocAPI

            client = DocAPI(self.api_key)

            from_info: dict = {"name": from_name}
            if from_email:
                from_info["email"] = from_email

            to_info: dict = {"name": to_name}
            if to_email:
                to_info["email"] = to_email

            kwargs: dict = {
                "from_": from_info,
                "to": to_info,
                "line_items": line_items,
                "currency_symbol": currency_symbol,
            }
            if invoice_number is not None:
                kwargs["invoice_number"] = invoice_number
            if date is not None:
                kwargs["date"] = date
            if due_date is not None:
                kwargs["due_date"] = due_date
            if tax_percent is not None:
                kwargs["tax_percent"] = tax_percent
            if notes is not None:
                kwargs["notes"] = notes

            pdf_bytes = client.invoice(**kwargs)
            with open(output_path, "wb") as f:
                f.write(pdf_bytes)
            return f"Invoice saved to {output_path} ({len(pdf_bytes)} bytes)"
        except Exception as e:
            return f"Error generating invoice: {e}"
