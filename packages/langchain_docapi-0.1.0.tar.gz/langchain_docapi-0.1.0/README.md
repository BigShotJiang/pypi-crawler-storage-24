# langchain-docapi

LangChain tools for [DocAPI](https://docapi.com) — generate PDFs, screenshots, and invoices via API.

## Installation

```bash
pip install langchain-docapi
```

## Quick Start

```python
from langchain_docapi import DocAPIPDFTool, DocAPIScreenshotTool, DocAPIInvoiceTool
from langchain.agents import AgentExecutor, create_tool_calling_agent
from langchain_openai import ChatOpenAI

tools = [
    DocAPIPDFTool(api_key="your-docapi-key"),
    DocAPIScreenshotTool(api_key="your-docapi-key"),
    DocAPIInvoiceTool(api_key="your-docapi-key"),
]

llm = ChatOpenAI(model="gpt-4o")
agent = create_tool_calling_agent(llm, tools, prompt)
agent_executor = AgentExecutor(agent=agent, tools=tools)

agent_executor.invoke({"input": "Generate a PDF from <h1>Hello World</h1>"})
```

## Documentation

See the [DocAPI docs](https://docapi.com/docs) for full API reference.
