# deepbach_pytorch/__init__.py

import os
import sys
import shutil

PACKAGE_ROOT = os.path.dirname(os.path.abspath(__file__))
if PACKAGE_ROOT not in sys.path:
    sys.path.insert(0, PACKAGE_ROOT)

import torch
import music21
from tqdm import tqdm

from .DeepBach.model_manager import DeepBach
from .DatasetManager.dataset_manager import DatasetManager
from .DatasetManager.metadata import FermataMetadata, TickMetadata, KeyMetadata


def _get_default_dataset():
    dataset_manager = DatasetManager()
    metadatas = [
        FermataMetadata(),
        TickMetadata(subdivision=4),
        KeyMetadata()
    ]
    
    dataset = dataset_manager.get_dataset(
        name='bach_chorales',
        voice_ids=[0, 1, 2, 3],
        metadatas=metadatas,
        sequences_size=8,
        subdivision=4
    )
    return dataset


def _get_default_model(dataset=None):
    if dataset is None:
        dataset = _get_default_dataset()
    
    model = DeepBach(
        dataset=dataset,
        note_embedding_dim=20,
        meta_embedding_dim=20,
        num_layers=2,
        lstm_hidden_size=256,
        dropout_lstm=0.5,
        linear_hidden_size=256
    )
    return model


def _ensure_models_dir(models_dir=None):
    if models_dir is None:
        models_dir = os.path.join(PACKAGE_ROOT, 'models')
    else:
        models_dir = os.path.abspath(models_dir)

    if not os.path.exists(models_dir):
        raise FileNotFoundError(
            f"Model directory not found: {models_dir}\n"
            f"Please ensure pretrained weights are downloaded to this directory.\n"
        )
    return models_dir


def _load_pretrained_weights(model, models_dir=None):
    """Improved weight loading: handles Embedding layer size mismatch"""
    models_dir = _ensure_models_dir(models_dir)
    
    print(f">>> Loading pretrained weights from {models_dir}...")
    
    device_map = 'cuda' if torch.cuda.is_available() else 'cpu'
    
    for i in range(4):
        found = False
        target_suffix = f",{i},20,20,2,256,0.5,256)"
        
        for fname in os.listdir(models_dir):
            if fname.endswith(target_suffix):
                model_path = os.path.join(models_dir, fname)
                
                print(f"\n  Loading voice {i}...")
                
                try:
                    # Load complete weight dictionary
                    loaded_state = torch.load(model_path, map_location=device_map)
                    current_state = model.voice_models[i].state_dict()
                    
                    # Track if we had to fix any embeddings
                    had_mismatch = False
                    
                    # Key fix: handle note_embeddings size mismatch
                    for key in list(loaded_state.keys()):
                        if 'note_embeddings' in key:
                            loaded_weight = loaded_state[key]
                            
                            if key in current_state:
                                current_weight = current_state[key]
                                
                                # Check if dimensions match
                                if loaded_weight.shape != current_weight.shape:
                                    had_mismatch = True
                                    print(f"    WARNING: {key} size mismatch")
                                    print(f"       Pretrained: {loaded_weight.shape}")
                                    print(f"       Current:    {current_weight.shape}")
                                    
                                    loaded_vocab_size = loaded_weight.shape[0]
                                    current_vocab_size = current_weight.shape[0]
                                    embed_dim = loaded_weight.shape[1]
                                    
                                    if current_vocab_size >= loaded_vocab_size:
                                        # New vocabulary is larger: keep pretrained, randomly initialize new tokens
                                        print(f"       Strategy: Partial load + random init for new vocab")
                                        print(f"       Keep [0:{loaded_vocab_size}], Random [{loaded_vocab_size}:{current_vocab_size}]")
                                        
                                        # Create a properly sized weight tensor
                                        new_weight = torch.zeros(current_vocab_size, embed_dim, device=loaded_weight.device, dtype=loaded_weight.dtype)
                                        new_weight[:loaded_vocab_size, :] = loaded_weight
                                        
                                        # Replace the loaded weight with the resized one
                                        loaded_state[key] = new_weight
                                        
                                    else:
                                        # New vocabulary is smaller (rare): skip loading
                                        print(f"       Strategy: Skip (vocabulary shrunk)")
                                        del loaded_state[key]
                    
                    # Use strict=False to allow partial loading
                    model.voice_models[i].load_state_dict(loaded_state, strict=False)
                    
                    if had_mismatch:
                        print(f"  OK: Voice {i} weights loaded successfully (with mismatch handling)")
                    else:
                        print(f"  OK: Voice {i} weights loaded successfully")
                    
                    found = True
                    
                except RuntimeError as e:
                    print(f"  ERROR: Voice {i} weight loading failed")
                    print(f"     Error: {e}")
                    import traceback
                    traceback.print_exc()
                    raise
                
                break
        
        if not found:
            raise FileNotFoundError(
                f"Weights for voice {i} not found.\n"
                f"Expected file ending with: {target_suffix}\n"
                f"Search directory: {models_dir}"
            )
    
    print("\nOK: All weights loaded successfully\n")


def _to_cuda_if_available(model):
    if torch.cuda.is_available():
        model.cuda()
        print(f"OK: Model moved to GPU: {torch.cuda.get_device_name(0)}")
    else:
        print("WARNING: GPU not detected, using CPU mode (slower)")
    return model


def harmonize(input_file, output_path="output.xml", num_iterations=500, 
              temperature=1.0, batch_size_per_voice=8, voice_index_range=None, random_init=None,
              melody_voice=0, keep_melody=True, models_dir=None):
    
    print("\n" + "="*70)
    print("DeepBach Harmony Generation")
    print("="*70)
    
    input_file = os.path.abspath(input_file)
    output_path = os.path.abspath(output_path)
    
    print("\n>>> Initializing model...")
    dataset = _get_default_dataset()
    model = _get_default_model(dataset)
    
    _load_pretrained_weights(model, models_dir)
    
    _to_cuda_if_available(model)
    model.eval_phase()
    
    print(f"\n>>> Reading input melody: {input_file}")
    if not os.path.exists(input_file):
        raise FileNotFoundError(f"Input file does not exist: {input_file}")
    
    try:
        user_score = music21.converter.parse(input_file)
    except Exception as e:
        raise ValueError(
            f"Failed to parse input file: {input_file}\n"
            f"Supported formats: .mid, .midi, .xml, .mxl\n"
            f"Error details: {e}"
        )
    
    print(">>> Converting melody to tensor...")
    try:
        score_tensor = dataset.get_score_tensor(
            user_score,
            offsetStart=0.,
            offsetEnd=user_score.flat.highestTime
        )
    except Exception as e:
        raise ValueError(
            f"Failed to convert melody to tensor: {e}\n"
            f"Ensure the input file contains valid note information."
        )
    
    metadata_tensor = dataset.get_metadata_tensor(user_score)
    sequence_length_ticks = score_tensor.shape[1]
    
    print(f"  Melody length: {sequence_length_ticks} ticks "
          f"({sequence_length_ticks / 16:.1f} measures)")
    
    if melody_voice not in [0, 1, 2, 3]:
        raise ValueError(
            f"melody_voice must be an integer between 0-3, received: {melody_voice}"
        )
    
    actual_voice_index_range = voice_index_range
    if actual_voice_index_range is None:
        if keep_melody:
            other_voices = [i for i in range(4) if i != melody_voice]
            actual_voice_index_range = [min(other_voices), max(other_voices) + 1]
        else:
            actual_voice_index_range = [0, 4]
            
    actual_random_init = random_init
    if actual_random_init is None:
        actual_random_init = True
    
    print(f"\n>>> Generation Parameters:")
    print(f"  Iterations: {num_iterations}")
    print(f"  Temperature: {temperature}")
    print(f"  Batch Size: {batch_size_per_voice}")
    print(f"  Keep Melody: {keep_melody} (Voice Index Range: {actual_voice_index_range})")
    print(f"  Random Initialization: {actual_random_init}")
    if keep_melody:
        print(f"  Melody Voice: {melody_voice} (0=Soprano, 1=Alto, 2=Tenor, 3=Bass)")
    
    print(f"\n>>> Generating harmony (this may take a while)...")
    try:
        final_score, _, _ = model.generation(
            num_iterations=num_iterations,
            sequence_length_ticks=sequence_length_ticks,
            tensor_chorale=score_tensor,
            tensor_metadata=metadata_tensor,
            time_index_range_ticks=None,
            voice_index_range=actual_voice_index_range,
            random_init=actual_random_init,
            temperature=temperature,
            batch_size_per_voice=batch_size_per_voice
        )
    except Exception as e:
        raise RuntimeError(f"Error during generation: {e}")
    
    print(f"\n>>> Saving results...")
    output_dir = os.path.dirname(output_path)
    if output_dir and not os.path.exists(output_dir):
        os.makedirs(output_dir, exist_ok=True)
    
    try:
        final_score.write('musicxml', fp=output_path)
    except Exception as e:
        raise RuntimeError(f"Could not save output file: {e}")
    
    print("="*70)
    print(f"OK: Success! File saved to: {output_path}")
    print("="*70 + "\n")
    
    return final_score


def generate_from_scratch(sequence_length_ticks=64, num_iterations=500, 
                          temperature=1.0, batch_size_per_voice=8, 
                          voice_index_range=None, random_init=True, models_dir=None):
    
    print("\n" + "="*70)
    print("DeepBach Free Composition - Generating from scratch")
    print("="*70)
    
    print("\n>>> Initializing model...")
    dataset = _get_default_dataset()
    model = _get_default_model(dataset)
    
    _load_pretrained_weights(model, models_dir)
    _to_cuda_if_available(model)
    model.eval_phase()
    
    actual_voice_index_range = voice_index_range if voice_index_range is not None else [0, 4]
    
    print(f"\n>>> Generation Parameters:")
    print(f"  Length: {sequence_length_ticks} ticks ({sequence_length_ticks / 16:.1f} measures)")
    print(f"  Iterations: {num_iterations}")
    print(f"  Temperature: {temperature}")
    print(f"  Batch Size: {batch_size_per_voice}")
    print(f"  Voice Index Range: {actual_voice_index_range}")
    
    print(f"\n>>> Generating composition...")
    try:
        score, _, _ = model.generation(
            num_iterations=num_iterations,
            sequence_length_ticks=sequence_length_ticks,
            tensor_chorale=None,
            tensor_metadata=None,
            time_index_range_ticks=None,
            voice_index_range=actual_voice_index_range,
            random_init=random_init,
            temperature=temperature,
            batch_size_per_voice=batch_size_per_voice
        )
    except Exception as e:
        raise RuntimeError(f"Error during generation: {e}")
    
    print("="*70)
    print("OK: Generation complete!")
    print("="*70 + "\n")
    
    return score


def train_from_scratch(num_epochs=50, batch_size=16, models_dir=None,
                       patience=5, weight_decay=1e-4):
    """
    Train the Transformer VoiceModel from random initialisation on the full
    Bach chorale corpus (~371 pieces, ~1M training samples after augmentation).

    :param num_epochs:    maximum epochs per voice model; early stopping will
                          typically fire well before this ceiling
    :param batch_size:    mini-batch size — 16 is safe on a 4 GB GPU; use 32
                          on an 8 GB+ GPU for faster iteration
    :param models_dir:    where to save checkpoints; defaults to
                          <package_root>/models so VoiceModel.save() and
                          _load_pretrained_weights() can find them
    :param patience:      early-stopping patience (epochs without val improvement)
    :param weight_decay:  L2 regularisation for Adam — reduces Transformer
                          overfitting on the small dataset
    """
    print("\n" + "="*70)
    print("DeepBach Training from Scratch (Transformer)")
    print("="*70)

    # Use PACKAGE_ROOT/models so VoiceModel.save() (which writes to
    # 'models/' relative to cwd) and _load_pretrained_weights() agree on
    # the same directory.  We temporarily change cwd for the duration of
    # training so the relative path inside save() resolves correctly.
    if models_dir is None:
        models_dir = os.path.join(PACKAGE_ROOT, 'models')
    else:
        models_dir = os.path.abspath(models_dir)

    os.makedirs(models_dir, exist_ok=True)
    if os.listdir(models_dir):
        print(f"\n>>> WARNING: {models_dir} already contains files. "
              f"Training will overwrite existing checkpoints.")

    print("\n>>> Initializing dataset and model...")
    dataset = _get_default_dataset()
    model   = _get_default_model(dataset)
    _to_cuda_if_available(model)

    # Change working directory so VoiceModel.save() writes to the right place
    original_cwd = os.getcwd()
    os.chdir(PACKAGE_ROOT)

    try:
        print(f"\n{'='*70}")
        print("Starting Training")
        print(f"{'='*70}")
        print(f"Max epochs per voice : {num_epochs}")
        print(f"Early-stop patience  : {patience}")
        print(f"Batch size           : {batch_size}")
        print(f"Weight decay         : {weight_decay}")
        print(f"Dataset              : Bach Chorales (~371 pieces)")
        print(f"Checkpoint directory : {models_dir}")
        print(f"{'='*70}\n")

        model.train(
            batch_size=batch_size,
            num_epochs=num_epochs,
            patience=patience,
            weight_decay=weight_decay,
        )

        print(f"\n{'='*70}")
        print("OK: Training complete!")
        print(f"Checkpoints saved to : {models_dir}")
        print(f"{'='*70}\n")
        return model

    except Exception as e:
        print(f"\n{'='*70}")
        print(f"ERROR: Training failed: {e}")
        print(f"{'='*70}\n")
        import traceback
        traceback.print_exc()
        raise RuntimeError(f"Error during training: {e}")

    finally:
        # Always restore cwd even if training crashes mid-way
        os.chdir(original_cwd)


def finetune(num_epochs=5, batch_size=32, voice_indices=None, models_dir=None):
    print("\n" + "="*70)
    print("DeepBach Fine-tuning")
    print("="*70)
    
    if models_dir is None:
        models_dir = os.path.join(PACKAGE_ROOT, 'models')
    
    print("\n>>> Initializing model...")
    dataset = _get_default_dataset()
    model = _get_default_model(dataset)
    
    _load_pretrained_weights(model, models_dir)
    
    print()
    _to_cuda_if_available(model)
    
    if voice_indices is None:
        voices_to_finetune = [0, 1, 2, 3]
    else:
        voices_to_finetune = voice_indices
        for idx in voices_to_finetune:
            if idx not in [0, 1, 2, 3]:
                raise ValueError(f"Invalid voice index in voice_indices: {idx}")
    
    try:
        print(f"\n{'='*70}")
        print("Starting Fine-tuning on Pretrained Model")
        print(f"{'='*70}")
        print(f"Epochs: {num_epochs}")
        print(f"Batch Size: {batch_size}")
        print(f"Voices to fine-tune: {voices_to_finetune}")
        print(f"{'='*70}\n")
        
        for voice_idx in voices_to_finetune:
            print(f"\n>>> Fine-tuning voice {voice_idx} ...")
            model.train(
                main_voice_index=voice_idx,
                batch_size=batch_size,
                num_epochs=num_epochs
            )
        
        print(f"\n{'='*70}")
        print("OK: Fine-tuning complete! Weights saved.")
        print(f"Model Save Path: {models_dir}")
        print(f"{'='*70}\n")
        
        return model
        
    except Exception as e:
        print(f"\n{'='*70}")
        print(f"ERROR: Fine-tuning failed: {e}")
        print(f"{'='*70}\n")
        raise RuntimeError(f"Error during fine-tuning: {e}")


def create_model(dataset=None):
    return _get_default_model(dataset)


def load_model(dataset=None, models_dir=None):
    model = _get_default_model(dataset)
    _load_pretrained_weights(model, models_dir)
    return model


def check_pretrained_weights(models_dir=None):
    if models_dir is None:
        models_dir = os.path.join(PACKAGE_ROOT, 'models')
        
    if not os.path.exists(models_dir):
        return {
            'complete': False,
            'models_dir': models_dir,
            'found_weights': 0,
            'required_weights': 4,
            'missing_voices': [0, 1, 2, 3],
            'error': f'Model directory does not exist: {models_dir}'
        }
    
    found_weights = 0
    missing_voices = []
    
    for i in range(4):
        target_suffix = f",{i},20,20,2,256,0.5,256)"
        found = False
        for fname in os.listdir(models_dir):
            if fname.endswith(target_suffix):
                found = True
                found_weights += 1
                break
        if not found:
            missing_voices.append(i)
    
    return {
        'complete': found_weights == 4,
        'models_dir': models_dir,
        'found_weights': found_weights,
        'required_weights': 4,
        'missing_voices': missing_voices
    }


def get_device_info():
    if torch.cuda.is_available():
        return {
            'device_type': 'cuda',
            'device_name': torch.cuda.get_device_name(0),
            'cuda_available': True
        }
    else:
        return {
            'device_type': 'cpu',
            'device_name': 'CPU',
            'cuda_available': False
        }


__all__ = [
    'harmonize',
    'generate_from_scratch',
    'train_from_scratch',
    'finetune',
    'create_model',
    'load_model',
    'check_pretrained_weights',
    'get_device_info',
    'DeepBach',
    'DatasetManager',
    'FermataMetadata',
    'TickMetadata',
    'KeyMetadata',
]


if __name__ == "__main__":
    print(f"DeepBach PyTorch loaded")
    print(f"Package root directory: {PACKAGE_ROOT}")
    device_info = get_device_info()
    print(f"Device: {device_info['device_name']}")
    weights_status = check_pretrained_weights()
    if weights_status['complete']:
        print(f"OK: The pretrained model is complete")
    else:
        print(f"WARNING: The pretrained model is incomplete (Missing voices: {weights_status['missing_voices']})")