"""SQLModel GraphQL Demo application."""
