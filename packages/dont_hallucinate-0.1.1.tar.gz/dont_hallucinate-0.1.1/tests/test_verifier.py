from dont_hallucinate.verifier import corrected_command, parse_flags_from_text, suggest_flag


def test_parse_flags_from_text() -> None:
    text = "Usage: tar [OPTION...]\\n  -c --create\\n  -x --extract\\n      --file=ARCHIVE"
    flags = parse_flags_from_text(text)
    assert "--create" in flags
    assert "--extract" in flags
    assert "--file" in flags
    assert "-c" in flags
    assert "-x" in flags


def test_suggest_flag() -> None:
    flags = ["--create", "--extract", "--verbose", "--file"]
    assert suggest_flag("--exract", flags) == "--extract"


def test_suggest_flag_rejects_weak_long_match() -> None:
    flags = ["--exclude", "--format", "--lzma", "-c", "-f", "-x"]
    assert suggest_flag("--exract", flags) is None


def test_corrected_command() -> None:
    fixed = corrected_command("tar --exract -f out.tar src", "--exract", "--extract")
    assert fixed is not None
    assert "--extract" in fixed
