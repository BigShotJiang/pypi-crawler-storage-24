﻿# ===== THIS FILE IS GENERATED FROM A TEMPLATE ===== #
# ============== DO NOT EDIT DIRECTLY ============== #

from .motion_lib_exception import MotionLibException


class Ge1GripperMovementFailedException(MotionLibException):
    """
    Thrown when a movement command for a GE1 series gripper fails.
    """
