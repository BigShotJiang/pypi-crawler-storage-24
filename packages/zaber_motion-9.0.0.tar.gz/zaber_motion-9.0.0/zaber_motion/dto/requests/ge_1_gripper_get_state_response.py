# This file is generated. Do not modify by hand.
# pylint: disable=line-too-long, unused-argument, f-string-without-interpolation, too-many-branches, too-many-statements, unnecessary-pass, unused-variable
from dataclasses import dataclass
from typing import Any, Dict
import zaber_bson
from ..product.ge_1_gripper_state import Ge1GripperState


@dataclass
class Ge1GripperGetStateResponse:

    value: Ge1GripperState = next(first for first in Ge1GripperState)

    @staticmethod
    def zero_values() -> 'Ge1GripperGetStateResponse':
        return Ge1GripperGetStateResponse(
            value=next(first for first in Ge1GripperState),
        )

    @staticmethod
    def from_binary(data_bytes: bytes) -> 'Ge1GripperGetStateResponse':
        """" Deserialize a binary representation of this class. """
        data = zaber_bson.loads(data_bytes)  # type: Dict[str, Any]
        return Ge1GripperGetStateResponse.from_dict(data)

    def to_binary(self) -> bytes:
        """" Serialize this class to a binary representation. """
        self.validate()
        return zaber_bson.dumps(self.to_dict())  # type: ignore

    def to_dict(self) -> Dict[str, Any]:
        return {
            'value': self.value.value,
        }

    @staticmethod
    def from_dict(data: Dict[str, Any]) -> 'Ge1GripperGetStateResponse':
        return Ge1GripperGetStateResponse(
            value=Ge1GripperState(data.get('value')),  # type: ignore
        )

    def validate(self) -> None:
        """" Validates the properties of the instance. """
        if self.value is None:
            raise ValueError(f'Property "Value" of "Ge1GripperGetStateResponse" is None.')

        if not isinstance(self.value, Ge1GripperState):
            raise ValueError(f'Property "Value" of "Ge1GripperGetStateResponse" is not an instance of "Ge1GripperState".')
