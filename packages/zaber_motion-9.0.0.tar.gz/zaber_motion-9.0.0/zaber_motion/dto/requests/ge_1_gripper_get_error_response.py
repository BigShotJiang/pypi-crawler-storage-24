# This file is generated. Do not modify by hand.
# pylint: disable=line-too-long, unused-argument, f-string-without-interpolation, too-many-branches, too-many-statements, unnecessary-pass, unused-variable
from dataclasses import dataclass
from typing import Any, Dict
import zaber_bson
from ..product.ge_1_gripper_error import Ge1GripperError


@dataclass
class Ge1GripperGetErrorResponse:

    value: Ge1GripperError = next(first for first in Ge1GripperError)

    @staticmethod
    def zero_values() -> 'Ge1GripperGetErrorResponse':
        return Ge1GripperGetErrorResponse(
            value=next(first for first in Ge1GripperError),
        )

    @staticmethod
    def from_binary(data_bytes: bytes) -> 'Ge1GripperGetErrorResponse':
        """" Deserialize a binary representation of this class. """
        data = zaber_bson.loads(data_bytes)  # type: Dict[str, Any]
        return Ge1GripperGetErrorResponse.from_dict(data)

    def to_binary(self) -> bytes:
        """" Serialize this class to a binary representation. """
        self.validate()
        return zaber_bson.dumps(self.to_dict())  # type: ignore

    def to_dict(self) -> Dict[str, Any]:
        return {
            'value': self.value.value,
        }

    @staticmethod
    def from_dict(data: Dict[str, Any]) -> 'Ge1GripperGetErrorResponse':
        return Ge1GripperGetErrorResponse(
            value=Ge1GripperError(data.get('value')),  # type: ignore
        )

    def validate(self) -> None:
        """" Validates the properties of the instance. """
        if self.value is None:
            raise ValueError(f'Property "Value" of "Ge1GripperGetErrorResponse" is None.')

        if not isinstance(self.value, Ge1GripperError):
            raise ValueError(f'Property "Value" of "Ge1GripperGetErrorResponse" is not an instance of "Ge1GripperError".')
