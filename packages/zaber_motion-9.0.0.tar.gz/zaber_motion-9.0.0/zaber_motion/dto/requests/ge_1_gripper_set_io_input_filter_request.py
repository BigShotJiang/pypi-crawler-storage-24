# This file is generated. Do not modify by hand.
# pylint: disable=line-too-long, unused-argument, f-string-without-interpolation, too-many-branches, too-many-statements, unnecessary-pass, unused-variable
from dataclasses import dataclass
from typing import Any, Dict
import decimal
import zaber_bson


@dataclass
class Ge1GripperSetIoInputFilterRequest:

    connection_id: int = 0

    duration: int = 0

    save_to_flash: bool = False

    @staticmethod
    def zero_values() -> 'Ge1GripperSetIoInputFilterRequest':
        return Ge1GripperSetIoInputFilterRequest(
            connection_id=0,
            duration=0,
            save_to_flash=False,
        )

    @staticmethod
    def from_binary(data_bytes: bytes) -> 'Ge1GripperSetIoInputFilterRequest':
        """" Deserialize a binary representation of this class. """
        data = zaber_bson.loads(data_bytes)  # type: Dict[str, Any]
        return Ge1GripperSetIoInputFilterRequest.from_dict(data)

    def to_binary(self) -> bytes:
        """" Serialize this class to a binary representation. """
        self.validate()
        return zaber_bson.dumps(self.to_dict())  # type: ignore

    def to_dict(self) -> Dict[str, Any]:
        return {
            'connectionId': int(self.connection_id),
            'duration': int(self.duration),
            'saveToFlash': bool(self.save_to_flash),
        }

    @staticmethod
    def from_dict(data: Dict[str, Any]) -> 'Ge1GripperSetIoInputFilterRequest':
        return Ge1GripperSetIoInputFilterRequest(
            connection_id=data.get('connectionId'),  # type: ignore
            duration=data.get('duration'),  # type: ignore
            save_to_flash=data.get('saveToFlash'),  # type: ignore
        )

    def validate(self) -> None:
        """" Validates the properties of the instance. """
        if self.connection_id is None:
            raise ValueError(f'Property "ConnectionId" of "Ge1GripperSetIoInputFilterRequest" is None.')

        if not isinstance(self.connection_id, (int, float, decimal.Decimal)):
            raise ValueError(f'Property "ConnectionId" of "Ge1GripperSetIoInputFilterRequest" is not a number.')

        if int(self.connection_id) != self.connection_id:
            raise ValueError(f'Property "ConnectionId" of "Ge1GripperSetIoInputFilterRequest" is not integer value.')

        if self.duration is None:
            raise ValueError(f'Property "Duration" of "Ge1GripperSetIoInputFilterRequest" is None.')

        if not isinstance(self.duration, (int, float, decimal.Decimal)):
            raise ValueError(f'Property "Duration" of "Ge1GripperSetIoInputFilterRequest" is not a number.')

        if int(self.duration) != self.duration:
            raise ValueError(f'Property "Duration" of "Ge1GripperSetIoInputFilterRequest" is not integer value.')
