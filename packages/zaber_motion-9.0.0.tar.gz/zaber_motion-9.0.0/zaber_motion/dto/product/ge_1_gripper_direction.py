# This file is generated. Do not modify by hand.
from enum import Enum


class Ge1GripperDirection(Enum):
    """
    Direction for a GE1 series gripper.
    """

    OPEN = 0

    CLOSE = 1
