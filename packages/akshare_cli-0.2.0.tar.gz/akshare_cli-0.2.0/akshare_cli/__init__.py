"""AKShare CLI Harness - Sub-package"""

__version__ = "0.1.0"
