"use strict";
(self["webpackChunkjupyterlab_duckling_syntax_highlighting"] = self["webpackChunkjupyterlab_duckling_syntax_highlighting"] || []).push([["lib_index_js"],{

/***/ "./lib/index.js"
/*!**********************!*\
  !*** ./lib/index.js ***!
  \**********************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   ducklingLanguage: () => (/* binding */ ducklingLanguage)
/* harmony export */ });
/* harmony import */ var _jupyterlab_codemirror__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/codemirror */ "webpack/sharing/consume/default/@jupyterlab/codemirror");
/* harmony import */ var _jupyterlab_codemirror__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_codemirror__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _codemirror_language__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @codemirror/language */ "webpack/sharing/consume/default/@codemirror/language");
/* harmony import */ var _codemirror_language__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_codemirror_language__WEBPACK_IMPORTED_MODULE_1__);


const DucklingLanguageParser = {
    startState: () => ({ inString: false }),
    token: (stream, state) => {
        if (stream.eatSpace())
            return null;
        if (stream.match(/^#.*/))
            return "comment";
        if (stream.match(/^(?:alias|and|as|assert|block|box|break|case|catch|class|compile_assert|const|continue|copy|debug|defer|dict|else|expand|extends|extern|false|for|fun|fundecl|if|implements|import|in|lambda|let|loop|match|move|namespace|none|not|or|pattern|private|protected|public|redo|ref|refof|restart|return|set|sizeof|static|str|switch|test|then|this|throw|true|try|type|using|var|vec|while|with|xor)\b/)) {
            return "keyword";
        }
        if (stream.match(/^(?:i8|i16|i32|i64|i128|u8|u16|u32|u64|u128|f16|f32|f64|f80|f128|char|bool|str|type|vec|set|dict|array)\b/)) {
            return "typeName";
        }
        if (stream.match(/^[0-9]+(?:\.[0-9]+)?/))
            return "number";
        if (stream.match(/^"[^"]*"/))
            return "string";
        if (stream.match(/^(?:\+|\-|\*|\/|==|=|!=|>|<)/))
            return "operator";
        stream.next();
        return null;
    }
};
const ducklingLanguage = _codemirror_language__WEBPACK_IMPORTED_MODULE_1__.StreamLanguage.define(DucklingLanguageParser);
const plugin = {
    id: 'duckling-syntax-highlighting:plugin',
    autoStart: true,
    requires: [_jupyterlab_codemirror__WEBPACK_IMPORTED_MODULE_0__.IEditorLanguageRegistry],
    activate: (app, languages) => {
        console.log('Duckling syntax highlighting is activated!');
        languages.addLanguage({
            name: 'duckling',
            mime: 'text/x-duckling',
            extensions: ['duckling'],
            load: async () => {
                return new _codemirror_language__WEBPACK_IMPORTED_MODULE_1__.LanguageSupport(ducklingLanguage);
            }
        });
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (plugin);


/***/ }

}]);
//# sourceMappingURL=lib_index_js.829ded4676b2233759c8.js.map