We encounterd inotify limit on Synology NAS. (see ./feed.csv)

The environment:
- Running in Docker Container on Synology NAS, watching bind mount volume
- Linux kernel 5.10.55+
- 4GB ram
- btrfs
- /proc/sys/fs/inotify/max_user_watches -> 8192 (I have permission to change this)

Non-functional requirements:
- Watched directories/files can be over 100k.
- Change rate is expected to be low (at most 1000 per day, burst at most 100, idle most time).
- Whenever a change happens, the change should be detected within 0~5 seconds window.

Available options:
- increase inotify limit, but how many memory will be consumed?
- btrfs subvolume
- fanotify, cffi or c extension is acceptable, add permission to the container is acceptable
- full scan, but can be slow as the volume is not on SSD

Witch one is better?
Whatever we choose, I need an abstract layer for the watch backend, so we can switch from different approach.
