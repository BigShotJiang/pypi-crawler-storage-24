from rich.text import Text
from textual.app import ComposeResult
from textual.widgets import Static


class AengusFooter(Static):
    def compose(self) -> ComposeResult:
        yield Static(self.footer_text)

    @property
    def commands(self) -> list[tuple[str, str]]:
        return [
            ("^q", "Quit"),
            ("^s", "Save"),
            ("^t", "Close"),
            ("^o", "Open Finder"),
            ("^n", "New File"),
            ("^b", "Back"),
            ("^k", "Delete File"),
            ("^l", "Statistics"),
            ("^g", "Open Mention"),
            ("alt+left/right", "Switch Editor"),
        ]

    @property
    def footer_text(self) -> Text:
        t = Text()
        for keys, label in self.commands:
            t.append(f"{keys} ", style=self.highlight_color)
            t.append(f"{label} ", style="white")
        return t

    @property
    def highlight_color(self) -> str:
        return self.app.get_css_variables().get("accent_color", "#e9cb25")
