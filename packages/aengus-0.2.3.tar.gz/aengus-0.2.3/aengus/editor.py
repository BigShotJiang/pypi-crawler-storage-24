import re
import unicodedata
from dataclasses import dataclass
from typing import ClassVar

from rich.segment import Segment
from rich.style import Style
from rich.text import Text
from textual import events
from textual.binding import Binding
from textual.geometry import Size
from textual.message import Message
from textual.reactive import reactive
from textual.scroll_view import ScrollView
from textual.strip import Strip

from aengus.swatch import Mention

# TODO: get this into the css file
# Cursor highlight – a fixed indigo that works across light/dark backgrounds.
CURSOR_STYLE = Style(color="white", bgcolor="#5C6BC0", bold=True)
FALLBACK_STYLE = Style(color="#DDA0DD", bold=True)
DIALOGUE_COLOR = "#16B96D"

GUTTER_WIDTH = 2
GUTTER_DOT = "\u00b7 "
GUTTER_BLANK = "  "
SCROLLOFF = 4  # lines of context kept visible above/below the cursor


@dataclass
class VisualRow:
    logical: int  # index into self._lines
    start: int  # char offset within that line where this row starts
    # NOTE: for word-wrapped rows end points AT the space that
    # caused the break; that space is not rendered and the next
    # row starts at end+1.
    end: int  # char offset where this row ends (exclusive)


def build_visual_rows(lines: list[str], width: int) -> list[VisualRow]:
    """Wrap each logical line into VisualRows of at most `width` chars.

    Breaks are made on word boundaries (last space within `width`) so that
    whole words are kept together.  Falls back to a hard break only when no
    space exists in the segment.  An empty line produces exactly one row.
    """
    rows: list[VisualRow] = []
    for li, line in enumerate(lines):
        if not line:
            rows.append(VisualRow(li, 0, 0))
            continue
        start = 0
        while start < len(line):
            if len(line) - start <= width:
                # Remainder fits – no wrap needed.
                rows.append(VisualRow(li, start, len(line)))
                break
            segment = line[start : start + width]
            space = segment.rfind(" ")
            if space > 0:
                # Break before the space; the space itself is consumed (not
                # rendered) and the next row starts after it.
                end = start + space  # points AT the space
                rows.append(VisualRow(li, start, end))
                start = end + 1  # skip the space
            else:
                # No space in segment – hard break at width.
                end = start + width
                rows.append(VisualRow(li, start, end))
                start = end
    return rows


class AengusEditor(ScrollView, can_focus=True):
    # Keys listed here are fully consumed by the editor (event.stop() is
    # called).  Every other key – including all app-level bindings such as
    # ctrl+q, ctrl+s, ctrl+o, ctrl+n, ctrl+b, ctrl+k, ctrl+l, escape – is
    # left alone so it bubbles up and triggers the app action regardless of
    # which widget has focus.
    #
    # To add a new editor-only shortcut:
    #   1. Add its key string here.
    #   2. Add a Binding entry in BINDINGS below.
    #   3. Add an action_* method (or handle it in on_key).
    _EDITOR_KEYS: ClassVar[frozenset[str]] = frozenset(
        {
            "left",
            "right",
            "up",
            "down",
            "home",
            "end",
            "pageup",
            "pagedown",
            "enter",
            "backspace",
            "delete",
            "ctrl+left",
            "ctrl+right",
        }
    )

    BINDINGS: ClassVar = [
        Binding("ctrl+left", "word_left", "Word left", show=False),
        Binding("ctrl+right", "word_right", "Word right", show=False),
        Binding("ctrl+g", "open_mention", "Open Mention", show=False),
    ]

    _revision: reactive[int] = reactive(0, layout=True)

    class Changed(Message):
        """Posted after every user edit (not when .text is set programmatically)."""

        def __init__(self, editor: "AengusEditor") -> None:
            super().__init__()
            self.editor = editor

    class Focused(Message):
        """Posted when this editor receives focus."""

        def __init__(self, editor: "AengusEditor") -> None:
            super().__init__()
            self.editor = editor

    class OpenMention(Message):
        """Posted when the user wants to open the mention under the cursor."""

        def __init__(self, folder: str, name: str) -> None:
            super().__init__()
            self.folder = folder
            self.name = name

    def __init__(self, id: str) -> None:
        super().__init__(id=id)
        self._lines: list[str] = [""]
        self._vrows: list[VisualRow] = [VisualRow(0, 0, 0)]
        self._cur_row: int = 0
        self._cur_col: int = 0
        self._name_highlights: dict[str, Style] = {}
        self._mention_paths: dict[str, tuple[str, str]] = {}
        self._logical_to_first_vrow: dict[int, int] = {0: 0}
        self._strip_cache: dict[int, Strip] = {}

        # these styles will be set in on_mount from the css
        self._style_normal: Style = None
        self._style_cur_line: Style = None
        self._style_gutter: Style = None

    def on_mount(self) -> None:
        self._rebuild_styles()
        self._rebuild()

    def on_focus(self) -> None:
        self.post_message(self.Focused(self))

    def on_resize(self) -> None:
        self._rebuild_styles()
        self._rebuild()

    def _rebuild_styles(self) -> None:
        bg = self.styles.background
        self._style_normal = Style(bgcolor=bg.rich_color)
        # Lighten the background by ~10 % for the active line.
        self._style_cur_line = Style(bgcolor=bg.lighten(0.10).rich_color)
        self._style_gutter = Style(color="#6272a4", bgcolor=bg.rich_color)
        self._strip_cache.clear()

    def _rebuild(self) -> None:
        cw = self._content_width()
        # subtract one from width for the scrollbar
        self._vrows = build_visual_rows(lines=self._lines, width=cw - 1)
        self._logical_to_first_vrow = {}
        for vi, vr in enumerate(self._vrows):
            if vr.logical not in self._logical_to_first_vrow:
                self._logical_to_first_vrow[vr.logical] = vi
        # Pin virtual width to content width so a horizontal scrollbar can never appear.
        self.virtual_size = Size(cw, len(self._vrows))
        self._strip_cache.clear()
        self._revision += 1

    @property
    def text(self) -> str:
        return "\n".join(self._lines)

    @text.setter
    def text(self, value: str) -> None:
        # Setting .text is intentionally silent (no Changed posted) so that
        # loading a file doesn't trigger spurious word-count updates.
        self._lines = value.split("\n") if value else [""]
        self._cur_row = 0
        self._cur_col = 0
        self._rebuild()

    def highlight_mentions(self, mentions: list[Mention]) -> None:
        mapping: dict[str, Style] = {}
        mention_paths: dict[str, tuple[str, str]] = {}  # UPPER -> (folder, canonical_name)
        for mention in mentions:
            style = mention.style or FALLBACK_STYLE
            for name in [mention.name] + mention.aliases:
                key = name.upper()
                mapping[key] = style
                mention_paths[key] = (mention.folder, mention.name)
        self._name_highlights = mapping
        self._mention_paths = mention_paths
        self._rebuild()

    def _highlight_text(self, raw: str, bg: Style) -> Text:
        text = Text(raw, style=bg, end="")
        # Highlight dialogue between " pairs
        for dialogue in re.finditer(r'"[^"]*"', raw):
            text.stylize(
                Style(color=DIALOGUE_COLOR, bgcolor=bg.bgcolor), dialogue.start(), dialogue.end()
            )
        if not self._name_highlights:
            return text
        upper = raw.upper()
        for name, style in self._name_highlights.items():
            start = 0
            while (pos := upper.find(name, start)) != -1:
                end = pos + len(name)
                before_ok = pos == 0 or not upper[pos - 1].isalpha()
                after_ok = end == len(upper) or not upper[end].isalpha()
                if before_ok and after_ok:
                    text.stylize(
                        Style(color=style.color, bold=style.bold, bgcolor=bg.bgcolor), pos, end
                    )
                start = pos + 1
        return text

    def _content_width(self) -> int:
        """Usable character columns in the scrollable content area.

        Uses content_size (which Textual computes as size minus border and
        CSS padding) and subtracts 1 column reserved for the vertical scrollbar
        so wrapping width never jumps when the bar appears.
        """
        w = self.content_size.width
        if w < 2:
            # Layout not yet computed – fall back so that the initial
            # _rebuild() produces a reasonable row count.
            w = self.size.width
        return max(1, w - 1 - GUTTER_WIDTH)

    def _visual_row_for(self, logical: int, col: int) -> int:
        """Return the visual row index that owns (logical, col).

        Handles the edge case where col points at a space consumed by
        word-wrap (sits between vr.end and the next vr.start): that position
        is assigned to the row that ends there.
        """
        first = self._logical_to_first_vrow.get(logical, 0)
        best = first
        for vi in range(first, len(self._vrows)):
            vr = self._vrows[vi]
            if vr.logical != logical:
                break
            best = vi
            is_last = vi == len(self._vrows) - 1 or self._vrows[vi + 1].logical != logical
            # Normal: col inside or at the boundary of this visual row.
            if vr.start <= col <= vr.end:
                return vi
            # Last row of this logical line: cursor may sit beyond end.
            if is_last and col > vr.end:
                return vi
            # Consumed-space gap between this row's end and the next row's start.
            if not is_last and vr.end < col < self._vrows[vi + 1].start:
                return vi
        return best

    def _ensure_cursor_visible(self) -> None:
        vi = self._visual_row_for(self._cur_row, self._cur_col)
        sy = int(self.scroll_offset.y)
        h = self.content_size.height or self.size.height
        # Clamp margin so it stays proportional in small viewports.
        margin = min(SCROLLOFF, max(1, h // 5))
        if vi < sy + margin:
            self.scroll_to(y=max(0, vi - margin), animate=False)
        elif vi > sy + h - 1 - margin:
            self.scroll_to(y=vi - h + 1 + margin, animate=False)

    def render_line(self, y: int) -> Strip:
        """Render one visible content line.

        `y` is in content coordinates (0 = first content row; Textual's
        compositor has already handled CSS border and padding).  The returned
        strip must be exactly content_size.width characters wide.
        """
        scroll_y = int(self.scroll_offset.y)
        total_width = self.content_size.width or self.size.width
        content_width = max(1, total_width - GUTTER_WIDTH)

        vi = y + scroll_y
        if vi >= len(self._vrows):
            return Strip(
                [
                    Segment(GUTTER_BLANK, self._style_gutter),
                    Segment(" " * content_width, self._style_normal),
                ]
            )

        vr = self._vrows[vi]
        is_cur_line = vr.logical == self._cur_row

        # Serve non-cursor lines from cache when available.
        if not is_cur_line and vi in self._strip_cache:
            return self._strip_cache[vi]

        gutter_seg = Segment(GUTTER_DOT, self._style_gutter)
        chunk = self._lines[vr.logical][vr.start : vr.end]

        # Active line gets a lighter background; all others use normal bg.
        bg = self._style_cur_line if is_cur_line else self._style_normal

        col = self._cur_col
        cursor_here = is_cur_line and vr.start <= col <= vr.end

        if cursor_here:
            local = col - vr.start
            before = self._highlight_text(chunk[:local], bg)
            cursor_ch = chunk[local] if local < len(chunk) else " "
            after_src = chunk[local + 1 :] if local < len(chunk) - 1 else ""
            after = self._highlight_text(after_src, bg)

            rich_line = Text(style=bg, end="")
            rich_line.append_text(before)
            rich_line.append(cursor_ch, style=CURSOR_STYLE)
            rich_line.append_text(after)
        else:
            rich_line = self._highlight_text(chunk, bg)

        console = self.app.console
        opts = console.options.update_width(content_width)
        segments = list(console.render(rich_line, opts))
        content_strip = Strip(segments).extend_cell_length(content_width, bg).simplify()

        strip = Strip([gutter_seg, *content_strip])

        if not is_cur_line:
            self._strip_cache[vi] = strip

        return strip

    def _post_changed(self) -> None:
        self.post_message(self.Changed(self))

    def _word_start_left(self, row: int, col: int) -> tuple[int, int]:
        if col == 0:
            if row == 0:
                return row, col
            row -= 1
            col = len(self._lines[row])
        line = self._lines[row]
        while col > 0 and not line[col - 1].isalnum():
            col -= 1
        while col > 0 and line[col - 1].isalnum():
            col -= 1
        return row, col

    def _word_end_right(self, row: int, col: int) -> tuple[int, int]:
        line = self._lines[row]
        if col == len(line):
            if row == len(self._lines) - 1:
                return row, col
            return row + 1, 0
        while col < len(line) and not line[col].isalnum():
            col += 1
        while col < len(line) and line[col].isalnum():
            col += 1
        return row, col

    def action_word_left(self) -> None:
        self._cur_row, self._cur_col = self._word_start_left(self._cur_row, self._cur_col)
        self._ensure_cursor_visible()
        self.refresh()

    def action_word_right(self) -> None:
        self._cur_row, self._cur_col = self._word_end_right(self._cur_row, self._cur_col)
        self._ensure_cursor_visible()
        self.refresh()

    def _mention_under_cursor(self) -> str:
        """Return the mention surrounding the cursor"""
        line = self._lines[self._cur_row]
        if not line:
            return ""
        for mention in self._mention_paths:
            sample_line = line
            # this offset gives the correct position in the original line
            offset = 0
            while True:
                mention_match = re.search(mention, sample_line, re.IGNORECASE)
                if mention_match is None:
                    break
                start, end = mention_match.span()
                if self._cur_col >= start + offset and self._cur_col <= end + offset:
                    return mention
                sample_line = sample_line[end:]
                offset += end
        return ""

    def action_open_mention(self) -> None:
        mention = self._mention_under_cursor()
        if not mention:
            return
        key = mention.upper()
        if key in self._mention_paths:
            folder, name = self._mention_paths[key]
            self.post_message(self.OpenMention(folder, name))

    def _invalidate_logical_line(self, logical: int) -> None:
        """Evict cached strips for every visual row of *logical*."""
        first = self._logical_to_first_vrow.get(logical)
        if first is None:
            return
        for vi in range(first, len(self._vrows)):
            if self._vrows[vi].logical != logical:
                break
            self._strip_cache.pop(vi, None)

    def on_key(self, event: events.Key) -> None:  # noqa: C901
        key = event.key
        lines = self._lines
        r, c = self._cur_row, self._cur_col

        if key not in self._EDITOR_KEYS:
            # Printable characters are consumed by the editor.
            if event.character and unicodedata.category(event.character) != "Cc":
                event.stop()
                lines[r] = lines[r][:c] + event.character + lines[r][c:]
                self._cur_col += 1
                self._rebuild()
                self._ensure_cursor_visible()
                self.refresh()
                self._post_changed()
            # All other keys (app bindings) bubble through untouched.
            return

        event.stop()
        mutated = False

        if key == "left":
            if c > 0:
                self._cur_col -= 1
            elif r > 0:
                self._cur_row -= 1
                self._cur_col = len(lines[self._cur_row])

        elif key == "right":
            if c < len(lines[r]):
                self._cur_col += 1
            elif r < len(lines) - 1:
                self._cur_row += 1
                self._cur_col = 0

        elif key == "up":
            vi = self._visual_row_for(r, c)
            if vi > 0:
                prev = self._vrows[vi - 1]
                local = c - self._vrows[vi].start
                self._cur_row = prev.logical
                self._cur_col = min(prev.start + local, len(lines[prev.logical]))
            else:
                # Already on the very first visual row – jump to column 0.
                self._cur_col = 0

        elif key == "down":
            vi = self._visual_row_for(r, c)
            if vi < len(self._vrows) - 1:
                nxt = self._vrows[vi + 1]
                local = c - self._vrows[vi].start
                self._cur_row = nxt.logical
                self._cur_col = min(nxt.start + local, len(lines[nxt.logical]))
            else:
                # Already on the very last visual row – jump to end of line.
                self._cur_col = len(lines[r])

        elif key == "ctrl+left":
            self._cur_row, self._cur_col = self._word_start_left(r, c)

        elif key == "ctrl+right":
            self._cur_row, self._cur_col = self._word_end_right(r, c)

        elif key == "home":
            vi = self._visual_row_for(r, c)
            self._cur_col = self._vrows[vi].start

        elif key == "end":
            vi = self._visual_row_for(r, c)
            self._cur_col = self._vrows[vi].end

        elif key == "pageup":
            vi = self._visual_row_for(r, c)
            h = self.content_size.height or self.size.height
            tgt_vi = max(0, vi - h)
            tgt = self._vrows[tgt_vi]
            self._cur_row = tgt.logical
            self._cur_col = tgt.start

        elif key == "pagedown":
            vi = self._visual_row_for(r, c)
            h = self.content_size.height or self.size.height
            tgt_vi = min(len(self._vrows) - 1, vi + h)
            tgt = self._vrows[tgt_vi]
            self._cur_row = tgt.logical
            self._cur_col = tgt.start

        elif key == "enter":
            rest = lines[r][c:]
            lines[r] = lines[r][:c]
            lines.insert(r + 1, rest)
            self._cur_row += 1
            self._cur_col = 0
            self._rebuild()
            mutated = True

        elif key == "backspace":
            if c > 0:
                lines[r] = lines[r][: c - 1] + lines[r][c:]
                self._cur_col -= 1
                self._rebuild()
                mutated = True
            elif r > 0:
                prev_len = len(lines[r - 1])
                lines[r - 1] += lines[r]
                lines.pop(r)
                self._cur_row -= 1
                self._cur_col = prev_len
                self._rebuild()
                mutated = True

        elif key == "delete":
            if c < len(lines[r]):
                lines[r] = lines[r][:c] + lines[r][c + 1 :]
                self._rebuild()
                mutated = True
            elif r < len(lines) - 1:
                lines[r] += lines[r + 1]
                lines.pop(r + 1)
                self._rebuild()
                mutated = True

        # Invalidate old cursor line so it redraws with normal styling.
        if self._cur_row != r:
            self._invalidate_logical_line(r)

        self._ensure_cursor_visible()
        self.refresh()
        if mutated:
            self._post_changed()
