from pathlib import Path

pkg = Path("aengus")
total = 0

for f in sorted(pkg.glob("*.py")):
    count = 0
    for line in f.read_text(encoding="utf-8").splitlines():
        stripped = line.strip()
        if not stripped:
            continue
        if stripped.startswith("#"):
            continue
        if stripped.startswith(("import ", "from ")):
            continue
        count += 1
    total += count
    print(f"  {f.name:<25} {count:>5}")

print(f"  {'TOTAL':<25} {total:>5}")
