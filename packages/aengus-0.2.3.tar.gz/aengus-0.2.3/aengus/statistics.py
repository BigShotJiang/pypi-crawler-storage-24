import csv
from dataclasses import dataclass
from datetime import date, datetime, timedelta
from pathlib import Path

from rich.text import Text
from textual.app import ComposeResult
from textual.containers import Container, Horizontal, VerticalScroll
from textual.widgets import Static


@dataclass
class DailyStats:
    date: date
    minutes: int
    total_words: int
    words_added: int = 0


def _streak(days: list[DailyStats], ref: date) -> int:
    if not days:
        return 0
    dates = {d.date for d in days}
    cur = ref
    if cur not in dates:
        cur = ref - timedelta(days=1)
    n = 0
    while cur in dates:
        n += 1
        cur -= timedelta(days=1)
    return n


def _longest_streak(days: list[DailyStats]) -> int:
    if not days:
        return 0
    dates = sorted(d.date for d in days)
    best = cur = 1
    for i in range(1, len(dates)):
        cur = cur + 1 if (dates[i] - dates[i - 1]).days == 1 else 1
        best = max(best, cur)
    return best


def _fmt(n: int) -> str:
    return f"{n:,}"


def _dur(minutes: int) -> str:
    if minutes < 60:
        return f"{minutes}m"
    h, m = divmod(minutes, 60)
    return f"{h}h {m:02}m"


class Statistics(VerticalScroll):
    def __init__(self, id: str):
        super().__init__(id=id)
        self._accent_color = self.app.get_css_variables().get("accent_color", "#e9cb25")
        self._main_color = self.app.get_css_variables().get("main_color", "#2ec4b6")
        self._dim_color = self.app.get_css_variables().get("dim_color", "#555555")
        self._data = None

    def compose(self) -> ComposeResult:
        with Horizontal(id="kpi-row"):
            yield Static(id="kpi-words", classes="kpi-card")
            yield Static(id="kpi-time", classes="kpi-card")
            yield Static(id="kpi-streak", classes="kpi-card")
            yield Static(id="kpi-maxstreak", classes="kpi-card")
            yield Static(id="kpi-consistency", classes="kpi-card")
            yield Static(id="kpi-sessions", classes="kpi-card")
            yield Static(id="kpi-best", classes="kpi-card")
            yield Static(id="kpi-avg", classes="kpi-card")
        with Container(id="heat-container"):
            yield Static(id="sec-heat", classes="stats-plot")
        with Container(id="bars-container"):
            yield Static(id="sec-bars", classes="stats-plot")

    def show(self) -> None:
        path = self.app.file_manager._stats_path
        # TODO: add an empty stats page if the loading fails or there is no stats file yet
        self._load_stats_file(path)
        today = date.today()

        total_w = self._data[-1].total_words
        n_sess = len(self._data)
        total_m = sum(d.minutes for d in self._data)
        cur_streak = _streak(self._data, today)
        max_streak = _longest_streak(self._data)
        total_added = sum(d.words_added for d in self._data)
        avg_per_sess = total_added // n_sess if n_sess else 0
        best = max(self._data, key=lambda d: d.words_added)

        total_span = max(1, (self._data[-1].date - self._data[0].date).days + 1)
        consistency = round(n_sess / total_span * 100)

        self._kpi("kpi-words", "TOTAL WORDS", _fmt(total_w))
        self._kpi("kpi-streak", "CURRENT STREAK", f"{cur_streak} day(s)")
        self._kpi(
            "kpi-consistency", "Consistency", f"{_fmt(consistency)}%" if consistency else "—"
        )
        self._kpi("kpi-sessions", "SESSIONS", str(n_sess))
        self._kpi("kpi-time", "WRITING TIME", _dur(total_m))
        self._kpi(
            "kpi-best",
            f"BEST DAY · {best.date.strftime('%b %d')}",
            f"+{_fmt(best.words_added)} words",
        )
        self._kpi("kpi-avg", "AVG / SESSION", f"{_fmt(avg_per_sess)} words")
        self._kpi("kpi-maxstreak", "LONGEST STREAK", f"{max_streak} day(s)")

        self._render_heat(self._data, today)
        self._render_bars(self._data)

    def _kpi(self, wid: str, label: str, value: str) -> None:
        t = Text(justify="center")
        t.append(f"{value}\n", style=f"bold {self._accent_color}")
        t.append(label, style=self._main_color)
        self.query_one(f"#{wid}", Static).update(t)

    def _render_heat(self, days: list[DailyStats], today: date) -> None:
        t = Text()
        t.append(f"  WRITING ACTIVITY {today.year}\n\n", style=f"bold {self._main_color}")

        activity = {d.date: d.words_added for d in days}
        year_start = date(today.year, 1, 1)
        year_end = date(today.year, 12, 31)

        grid_start = year_start - timedelta(days=year_start.weekday())

        labels = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
        for dow in range(7):
            t.append(f"  {labels[dow]} ", style=self._dim_color)
            cur = grid_start + timedelta(days=dow)
            while cur <= year_end:
                if cur < year_start:
                    t.append("  ")
                else:
                    w = activity.get(cur, 0)
                    if cur > today or w == 0:
                        t.append("■ ", style=f"dim {self._main_color}")
                    else:
                        t.append("■ ", style=self._accent_color)
                cur += timedelta(weeks=1)
            if dow < 6:
                t.append("\n")

        # TODO: add months on the x-axis
        self.query_one("#sec-heat", Static).update(t)

    def _render_bars(self, days: list[DailyStats]) -> None:
        wc_goal = self.app.word_counter._goal or 50_000
        y_axis_width = len(f"{wc_goal:,}") + 2
        padding = 10
        num_bars = max(1, self.app.size.width - y_axis_width - padding)
        recent = days[-num_bars:]
        # Pad with zeros on the right if fewer sessions than available width
        words = [d.total_words for d in recent] + [0] * (num_bars - len(recent))

        chart_height = 16
        blocks = " ▁▂▃▄▅▆▇█"

        t = Text()
        t.append(f"  RECENT SESSIONS (last {len(recent)})\n\n", style=f"bold {self._main_color}")

        for row in range(chart_height, 0, -1):
            threshold = wc_goal * row / chart_height
            if row == 1:
                label = "0"
            elif row == chart_height or row == chart_height // 2 + 1:
                label = _fmt(int(threshold))
            else:
                label = ""
            t.append(f"{label:>{y_axis_width}}", style=self._dim_color)
            t.append(" ", style=self._dim_color)

            chart_row = []
            for w in words:
                ratio = min(w / wc_goal, 1.0) if wc_goal else 0
                bar_height = ratio * chart_height

                if bar_height >= row:
                    chart_row.append("█")
                elif bar_height > row - 1:
                    frac = bar_height - (row - 1)
                    idx = max(1, int(frac * 8))
                    chart_row.append(blocks[idx])
                else:
                    chart_row.append(" ")
            t.append("".join(chart_row), style=self._accent_color)
            t.append("\n")

        t.append(" " * (y_axis_width + 1))
        t.append("─" * num_bars, style=self._dim_color)
        self.query_one("#sec-bars", Static).update(t)

    def _load_stats_file(self, path: Path) -> None:
        if self._data or not path.exists():
            return

        daily: dict[date, list[int]] = {}
        with path.open("r", encoding="utf-8", newline="") as fh:
            for row in csv.DictReader(fh):
                try:
                    d = datetime.strptime(row["date"], "%Y-%m-%d %H:%M").date()
                    m = int(row.get("minutes", 0))
                    w = int(row.get("total_words", 0))
                except (ValueError, KeyError):
                    continue
                if d in daily:
                    daily[d][0] += m
                    daily[d][1] = max(daily[d][1], w)
                else:
                    daily[d] = [m, w]

        prev = 0
        out: list[DailyStats] = []
        for d in sorted(daily):
            mins, total = daily[d]
            added = max(0, total - prev)
            out.append(DailyStats(d, mins, total, added))
            prev = total
        self._data = out
