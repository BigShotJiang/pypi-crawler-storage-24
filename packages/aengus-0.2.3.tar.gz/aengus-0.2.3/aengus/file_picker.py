from enum import Enum
from pathlib import Path

from textual import on
from textual.app import ComposeResult
from textual.containers import Vertical
from textual.message import Message
from textual.widgets import Input, Label, ListItem, ListView


class PickerMode(Enum):
    OPEN = 1
    NEW = 3
    DELETE = 4


class FilePicker(Vertical):
    def compose(self) -> ComposeResult:
        yield Input(placeholder="Type to search files…", id="file-search-input")
        yield ListView(id="file-search-results")
        yield Label("No files found", id="no-results")

    def on_mount(self) -> None:
        self._search_input = self.query_one("#file-search-input", Input)
        self._results = self.query_one("#file-search-results", ListView)
        self._info_label = self.query_one("#no-results", Label)
        self.mode = None
        self._search_timer = None
        self._all_files: list[Path] = []
        self._project_root: Path | None = None

    def open(self, all_files: list[Path], project_root: Path) -> None:
        self.mode = PickerMode.OPEN
        self._all_files = all_files
        self._project_root = project_root
        self.display = True
        self._search_input.placeholder = "Type to search files\u2026"
        self._search_input.value = ""
        self._populate_list("")
        self.set_timer(0.05, lambda: self._search_input.focus())

    def open_new(self, project_root: Path) -> None:
        self.mode = PickerMode.NEW
        self._project_root = project_root
        self.display = True
        self._search_input.placeholder = "Enter new file path\u2026"
        self._search_input.value = ""
        self._results.clear()
        self._info_label.display = False
        self.set_timer(0.05, lambda: self._search_input.focus())

    def open_delete(self, all_files: list[Path], project_root: Path) -> None:
        self.mode = PickerMode.DELETE
        self._all_files = all_files
        self._project_root = project_root
        self.display = True
        self._search_input.placeholder = "Type to search files to delete\u2026"
        self._search_input.value = ""
        self._populate_list("")
        self.set_timer(0.05, lambda: self._search_input.focus())

    def close(self) -> None:
        self.display = False

    def _build_tree(self, files: list[Path]) -> dict:
        """Build a nested dict: folder names map to dicts, file names map to Path."""
        tree: dict = {}
        for f in files:
            try:
                rel = f.relative_to(self._project_root)
            except ValueError:
                rel = Path(f.name)
            parts = rel.parts
            node = tree
            for part in parts[:-1]:
                node = node.setdefault(part, {})
            node[parts[-1]] = f
        return tree

    def _render_tree(self, tree: dict, prefix: str = "") -> list[tuple[str, Path | None]]:
        result: list[tuple[str, Path | None]] = []
        folders = sorted((k, v) for k, v in tree.items() if isinstance(v, dict))
        files = sorted((k, v) for k, v in tree.items() if not isinstance(v, dict))
        entries = folders + files

        for i, (name, value) in enumerate(entries):
            is_last = i == len(entries) - 1
            connector = "\u2514\u2500\u2500" if is_last else "\u251c\u2500\u2500"

            if isinstance(value, dict):
                result.append((f"{prefix}{connector} {name}", None))
                child_prefix = prefix + ("    " if is_last else "\u2502   ")
                result.extend(self._render_tree(value, child_prefix))
            else:
                result.append((f"{prefix}{connector}{name}", value))

        return result

    def _populate_list(self, query: str) -> None:
        if self.mode not in (PickerMode.OPEN, PickerMode.DELETE):
            return

        self._results.clear()
        lower_query = query.lower()
        matches = (
            [f for f in self._all_files if lower_query in f.name.lower()]
            if query
            else self._all_files
        )

        tree = self._build_tree(matches)
        items = self._render_tree(tree)

        for label, path in items:
            if path is None:
                item = ListItem(Label(label), name="__folder__", classes="folder-header")
            else:
                item = ListItem(Label(label), name=str(path))
            self._results.append(item)

        self._info_label.display = not bool(matches)

    @on(Input.Changed, "#file-search-input")
    def on_input_changed(self, event: Input.Changed) -> None:
        if self._search_timer is not None:
            self._search_timer.stop()
        value = event.value
        self._search_timer = self.set_timer(0.05, lambda: self._populate_list(value))

    @on(Input.Submitted, "#file-search-input")
    def on_input_submitted(self, event: Input.Submitted) -> None:
        if self.mode in (PickerMode.OPEN, PickerMode.DELETE):
            if self._results.children:
                self._results.focus()
                self._results.index = 0
        elif self.mode == PickerMode.NEW:
            path = (self._project_root / event.value).resolve()
            self.post_message(self.NewFileRequested(path))

    class NewFileRequested(Message):
        def __init__(self, path: Path):
            self.path = path
            super().__init__()

    class DeleteFileRequested(Message):
        def __init__(self, path: Path):
            self.path = path
            super().__init__()
