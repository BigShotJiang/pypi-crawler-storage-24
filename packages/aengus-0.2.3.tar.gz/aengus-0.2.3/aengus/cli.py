import argparse
import sys
from pathlib import Path


def main() -> None:
    desc = "Aengus - your writing space"
    parser = argparse.ArgumentParser(description=desc, usage=argparse.SUPPRESS)
    subparsers = parser.add_subparsers(dest="command", metavar="")

    open_parser = subparsers.add_parser("open", help="Open a project")
    open_parser.add_argument("project_root", help="Path to the project root")

    subparsers.add_parser("init", help="Initialise a new project")

    new_parser = subparsers.add_parser("new", help="Create a new folder in the project")
    new_parser.add_argument("folder_name", help="Name of the folder to create")

    args = parser.parse_args()

    if args.command == "init":
        from aengus.init_project import init_existing_project

        init_existing_project(folder=".")
        print(f"Project initialised in {Path.cwd()}")

    elif args.command == "new":
        from aengus.init_project import init_empty_project

        init_empty_project(folder=args.folder_name)
        print(f"Project created: {Path(args.folder_name).resolve()}")

    elif args.command == "open":
        import tomllib

        from aengus.app import Aengus

        project_root = Path(args.project_root)
        if not project_root.exists():
            print("Project root does not exist.")
            sys.exit(1)

        conf_path = project_root / "aengus.toml"
        conf = tomllib.loads(conf_path.read_text(encoding="utf-8")) if conf_path.exists() else {}

        app = Aengus(project_root, config=conf)
        app.run()
        print("bye wanderer, may your path be ever light")

    else:
        parser.print_help()
        sys.exit(1)
