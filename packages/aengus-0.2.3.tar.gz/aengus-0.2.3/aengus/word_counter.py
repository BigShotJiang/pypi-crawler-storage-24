import re
from pathlib import Path

from rich.text import Text


class WordCounter:
    _WORD_PATTERN = re.compile(r"\b\w+\b")

    def __init__(
        self,
        project_root: Path,
        tracked_folders: list[str],
        goal: int | None = None,
    ) -> None:
        self._project_root = project_root.resolve()
        self._tracked_folders = tracked_folders
        self._goal = goal
        # Tracked files – contribute to the project total.
        self._baseline: dict[Path, int] = {}
        self._current: dict[Path, int] = {}
        # Untracked .md files – per-file display only.
        self._untracked_baseline: dict[Path, int] = {}
        self._untracked_current: dict[Path, int] = {}
        self._index()

    def _index(self) -> None:
        for folder in self._tracked_folders:
            folder_path = self._project_root / folder
            if not folder_path.exists():
                continue
            for path in folder_path.rglob("*.md"):
                if not path.is_file():
                    continue
                count = self._count_words(path.read_text(encoding="utf-8"))
                self._baseline[path] = count
                self._current[path] = count

    def reindex(self) -> None:
        known = set(self._current)
        for folder in self._tracked_folders:
            folder_path = self._project_root / folder
            if not folder_path.exists():
                continue
            for path in folder_path.rglob("*.md"):
                if not path.is_file():
                    continue
                if path in known:
                    known.discard(path)
                    continue
                count = self._count_words(path.read_text(encoding="utf-8"))
                self._current[path] = count
                if path not in self._baseline:
                    self._baseline[path] = count
        # Remove entries for files that no longer exist on disk.
        for path in known:
            self._baseline.pop(path, None)
            self._current.pop(path, None)

    def is_tracked(self, path: Path | None) -> bool:
        if path is None or path.suffix.lower() != ".md":
            return False
        for folder in self._tracked_folders:
            try:
                path.relative_to(self._project_root / folder)
                return True
            except ValueError:
                continue
        return False

    @property
    def total(self) -> int:
        return sum(self._current.values())

    @property
    def baseline_total(self) -> int:
        return sum(self._baseline.values())

    @property
    def session_diff(self) -> int:
        return self.total - self.baseline_total

    def file_count(self, path: Path) -> int:
        if path in self._current:
            return self._current[path]
        return self._untracked_current.get(path, 0)

    def file_session_diff(self, path: Path) -> int:
        if path in self._current:
            return self._current[path] - self._baseline.get(path, 0)
        return self._untracked_current.get(path, 0) - self._untracked_baseline.get(path, 0)

    def update(self, path: Path, text: str) -> None:
        if path is None or path.suffix.lower() != ".md":
            return
        count = self._count_words(text)
        if self.is_tracked(path):
            self._current[path] = count
            if path not in self._baseline:
                self._baseline[path] = 0
        else:
            self._untracked_current[path] = count
            if path not in self._untracked_baseline:
                self._untracked_baseline[path] = count

    def remove(self, path: Path) -> None:
        self._baseline.pop(path, None)
        self._current.pop(path, None)
        self._untracked_baseline.pop(path, None)
        self._untracked_current.pop(path, None)

    def _format_diff(self, diff: int) -> str:
        sign = "+" if diff >= 0 else "-"
        return f"{sign}{abs(diff):,}"

    def format_wordcount(self, current_file: Path | None = None) -> Text:
        if current_file is not None and current_file.suffix.lower() == ".md":
            fcount = self.file_count(current_file)
            fdiff = self.file_session_diff(current_file)
            c = "green" if fdiff >= 0 else "red"
            file_diff = f"[{c}]{self._format_diff(fdiff)}[/{c}]"
            return Text.from_markup(f"Wordcount: {fcount:,} | {file_diff}")

        c = "green" if self.session_diff >= 0 else "red"
        session = f"[{c}]{self._format_diff(self.session_diff)}[/{c}]"
        if self._goal is not None:
            total = f"Total Wordcount: {self.total:,} / {self._goal:,}"
            return Text.from_markup(f"{total} | {session}")
        return Text.from_markup(f"Total Wordcount: {self.total:,} | {session}")

    def _count_words(self, text: str) -> int:
        return len(self._WORD_PATTERN.findall(text))
