# Aengus - A TUI Writing App

![image](https://codeberg.org/attachments/9aa88f10-954e-41e4-a5e6-5c286224aa03)
![image](https://codeberg.org/attachments/fe532e3e-310c-476f-832c-ac17cc05fb17)

### Installation

Install with `pip install aengus`.

Then create a project with `aengus new <PROJECT_NAME>` and open with `aengus open <PROJECT_NAME>`.

Or get help with `aengus -h`.

### Setup Environment

This repository uses uv. Run `uv sync` to create the virtual environment.

Install with `pip install -e .` to get instant feedback while editing.

On windows add the `Scripts` folder to `PATH` if you have not already.

### Planned Features

 - Undo + Redo for the editor
 - Copy + Paste with text selection
 - Find and Replace for the current editor
 - Session Word Count goal with a little progress bar
 - novel exporter into single markdown/pdf/whatever (needs a chapter ordering system)
 - highlighting based on noun, adjective, verb (toggle between current system)
 - highlight fill words in "Edit Mode"
