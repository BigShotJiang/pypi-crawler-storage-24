from yta_constants.enum import YTAEnum as Enum


class VideoFrameMetadataField(Enum):
    """
    Metadata fields of a video `Frame` instance.
    """

    HAS_ALPHA_PIXELS = 'has_alpha_pixels'
    """
    Boolean field to indicate if the video `Frame`
    has transparent pixels or not, which means that
    include alpha channel.
    """
    IS_FULLY_OPAQUE = 'is_fully_opaque'
    """
    Boolean field to indicate if all the pixels of
    the video `Frame` are opaque (don't have alpha
    channel or have alpha channel as non-transparent).

    This field is useful when we are combining frames
    and we find one like this, so we can stop
    combining the next one because this one, being
    completely opaque, will cover the following ones.
    """
    IS_FULLY_TRANSPARENT = 'is_fully_transparent'
    """
    Boolean field to indicate if all the pixels of
    the video `Frame` are transparent (have alpha
    channel and are completely transparent).)

    This field is useful when we are combining frames
    and we find one like this, so we can directly omit
    it and go to the next one because this one, being
    completely transparent, will let the following one
    be seen.
    """
    IS_FROM_GAP = 'is_from_gap'
    """
    Boolean field to identify a frame that comes from
    a gap track item, which means that there is nothing
    placed in that position and it must be completely
    black or transparent (depending on the other
    elements in the timeline for that same exact moment).
    """

class AudioFrameMetadataField(Enum):
    """
    Metadata fields of an audio `Frame` instance.
    """

    IS_SILENT = 'is_silent'
    """
    Boolean field to indicate if the audio frame is
    silent, which means that there is no audio to
    play and can be omitted.
    """