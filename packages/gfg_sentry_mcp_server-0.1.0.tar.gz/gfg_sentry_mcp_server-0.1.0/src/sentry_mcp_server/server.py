import os
from typing import Any

import requests
from mcp.server.fastmcp import FastMCP


mcp = FastMCP("sentry-mcp-server")


class SentryClient:
    def __init__(self) -> None:
        self.base_url = os.getenv("SENTRY_BASE_URL", "https://sentry.io/api/0").rstrip("/")
        self.token = os.getenv("SENTRY_AUTH_TOKEN")
        if not self.token:
            raise ValueError("Missing SENTRY_AUTH_TOKEN environment variable.")

    def _headers(self) -> dict[str, str]:
        return {
            "Authorization": f"Bearer {self.token}",
            "Accept": "application/json",
            "Content-Type": "application/json",
        }

    def get(self, path: str, params: dict[str, Any] | None = None) -> Any:
        url = f"{self.base_url}/{path.lstrip('/')}"
        response = requests.get(url, headers=self._headers(), params=params, timeout=30)
        response.raise_for_status()
        return response.json()


def _default_org(org_slug: str | None) -> str:
    org = org_slug or os.getenv("SENTRY_ORG_SLUG")
    if not org:
        raise ValueError("org_slug is required (or set SENTRY_ORG_SLUG).")
    return org


@mcp.tool(name="sentry_list_alert_rules")
def list_alert_rules(
    org_slug: str | None = None,
    include_metric_alert_rules: bool = True,
) -> dict[str, Any]:
    """
    List alerts from Sentry.

    - Issue alert rules come from /projects/{org}/{project}/rules/ (project is required).
    - Metric alert rules come from /organizations/{org}/alert-rules/.
    """
    org = _default_org(org_slug)
    client = SentryClient()
    result: dict[str, Any] = {"organization": org, "issue_alert_rules": [], "metric_alert_rules": []}

    if include_metric_alert_rules:
        result["metric_alert_rules"] = client.get(f"/organizations/{org}/alert-rules/")

    return result


@mcp.tool(name="sentry_retrieve_alert_rule_detail")
def retrieve_alert_rule_detail(
    alert_id: str,
    org_slug: str | None = None,
    project_slug: str | None = None,
    alert_type: str = "metric",
    include_rule: bool = True,
) -> dict[str, Any]:
    """
    Retrieve one alert detail, including rule payload.

    alert_type:
      - "metric": use org-level metric alert rule endpoint
      - "issue": use project-level issue alert rule endpoint (requires project_slug)
    """
    org = _default_org(org_slug)
    client = SentryClient()

    if alert_type == "metric":
        detail = client.get(f"/organizations/{org}/alert-rules/{alert_id}/")
    elif alert_type == "issue":
        if not project_slug:
            raise ValueError("project_slug is required for issue alert rule retrieval.")
        detail = client.get(f"/projects/{org}/{project_slug}/rules/{alert_id}/")
    else:
        raise ValueError("alert_type must be either 'metric' or 'issue'.")

    return {"organization": org, "alert_type": alert_type, "alert": detail if include_rule else {"id": alert_id}}


@mcp.tool(name="sentry_search_issues")
def search_issues(
    query: str,
    org_slug: str | None = None,
    limit: int = 25,
    start: str | None = None,
    end: str | None = None,
    group_stats_period: str | None = None,
    sort: str | None = None,
) -> dict[str, Any]:
    """
    Search Sentry issues using Sentry's issue search syntax.

    Args:
        query: Sentry issue query string.
            Examples:
              - "is:unresolved level:error"
              - "project:backend environment:production"
              - "user.email:alice@example.com"
              - "transaction:/api/orders has:stacktrace"
              - "event.type:error is:unresolved !http.url:*user/personalization !http.url:*/me level:error"
        org_slug: Optional organization slug. If omitted, uses SENTRY_ORG_SLUG.
        limit: Max number of issues to return in one request (clamped to 1..100).
        start: ISO-8601 start timestamp (example: "2026-03-10T22:30:00Z").
        end: ISO-8601 end timestamp (example: "2026-03-10T22:50:00Z").
        group_stats_period: Optional group stats period (example: "auto"), sent as `groupStatsPeriod`.
        sort: Optional sort mode (example: "freq"), sent as `sort`.

    Returns:
        A dict with:
          - organization: Resolved organization slug used for the query.
          - query: The original query string.
          - count: Number of issues returned in this response.
          - issues: Raw Sentry issue objects from the API.

    Notes:
        - This tool performs a single-page fetch and does not follow pagination links.
        - For broad searches, increase limit or add filters (project/environment/level/status).
    """
    org = _default_org(org_slug)
    client = SentryClient()
    params: dict[str, Any] = {"query": query, "limit": max(1, min(limit, 100))}
    if start:
        params["start"] = start
    if end:
        params["end"] = end
    if group_stats_period:
        params["groupStatsPeriod"] = group_stats_period
    if sort:
        params["sort"] = sort
    issues = client.get(f"/organizations/{org}/issues/", params=params)
    return {"organization": org, "query": query, "count": len(issues), "issues": issues}


@mcp.tool(name="sentry_retrieve_issue")
def retrieve_issue(issue_id: str) -> dict[str, Any]:
    """
    Retrieve one Sentry issue detail by global issue ID.
    """
    client = SentryClient()
    issue = client.get(f"/issues/{issue_id}/")
    return {"issue": issue}


@mcp.tool(name="sentry_list_issue_events")
def list_issue_events(
    issue_id: str,
    org_slug: str | None = None,
    start: str | None = None,
    end: str | None = None,
    stats_period: str | None = None,
    environment: list[str] | None = None,
    full: bool | None = None,
    sample: bool | None = None,
    query: str | None = None,
    cursor: str | None = None,
) -> dict[str, Any]:
    """
    List error events for a Sentry issue.

    API:
      GET /organizations/{org}/issues/{issue_id}/events/

    Args:
      issue_id: Global Sentry issue ID (example: "1059665").
      org_slug: Organization slug. If omitted, uses SENTRY_ORG_SLUG.
      start: ISO-8601 start timestamp (example: "2026-03-10T22:30:00Z").
      end: ISO-8601 end timestamp (example: "2026-03-10T22:50:00Z").
      stats_period: Relative time window like "24h", "7d", "30m" (overrides start/end).
      environment: Environment filters (example: ["production", "staging"]).
      full: Include full event body/stacktrace (example: true).
      sample: Return deterministic pseudo-random order (example: false).
      query: Event search query string (example: "level:error environment:production").
      cursor: Pagination cursor from Sentry Link headers.

    Example payload:
      {"issue_id":"1059665","start":"2026-03-10T22:30:00Z","end":"2026-03-10T22:50:00Z","full":"true","sample":"false"}
    """
    org = _default_org(org_slug)
    client = SentryClient()

    params: dict[str, Any] = {}
    if start:
        params["start"] = start
    if end:
        params["end"] = end
    if stats_period:
        params["statsPeriod"] = stats_period
    if environment:
        params["environment"] = environment
    if full is not None:
        params["full"] = full
    if sample is not None:
        params["sample"] = sample
    if query:
        params["query"] = query
    if cursor:
        params["cursor"] = cursor

    events = client.get(f"/organizations/{org}/issues/{issue_id}/events/", params=params)
    return {"organization": org, "issue_id": issue_id, "count": len(events), "events": events}


@mcp.tool(name="sentry_retrieve_issue_event")
def retrieve_issue_event(
    issue_id: str,
    event_id: str,
    org_slug: str | None = None,
    environment: list[str] | None = None,
) -> dict[str, Any]:
    """
    Retrieve one event for a Sentry issue.

    API:
      GET /organizations/{org}/issues/{issue_id}/events/{event_id}/

    event_id can be a concrete event ID or one of:
      - latest
      - oldest
      - recommended
    """
    org = _default_org(org_slug)
    client = SentryClient()
    params: dict[str, Any] = {}
    if environment:
        params["environment"] = environment
    event = client.get(f"/organizations/{org}/issues/{issue_id}/events/{event_id}/", params=params)
    return {"organization": org, "issue_id": issue_id, "event_id": event_id, "event": event}


def main() -> None:
    mcp.run()


if __name__ == "__main__":
    main()
