# eu-compliance-certificate-generator

A standalone CLI tool that generates official-looking EU AI Act compliance certificates (PDF + blockchain-anchored proof) for AI systems. Addresses the "Delve fake compliance" market gap legitimately — produces verifiable certificates with cryptographic attestations, not fake paperwork. Targets solo developers and small teams (1-10 people) who need quick compliance documentation before the Sept 2026 deadline but can't afford $99/month SaaS subscriptions.
