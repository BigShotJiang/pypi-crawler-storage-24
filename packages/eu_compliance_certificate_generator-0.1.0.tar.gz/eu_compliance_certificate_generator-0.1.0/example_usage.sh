#!/bin/bash
# Example usage script for EU Compliance Certificate Generator

echo "🇪🇺 EU Compliance Certificate Generator - Examples"
echo "=================================================="
echo ""

# Example 1: Minimal risk system
echo "Example 1: Minimal Risk System (Content Moderation)"
echo "---------------------------------------------------"
eu-cert \
  --system-name "Content Filter API" \
  --system-version "3.2.1" \
  --provider-name "SafeWeb Technologies GmbH" \
  --provider-address "789 Security Blvd, Frankfurt, Germany" \
  --risk-level minimal \
  --intended-purpose "Filter spam and inappropriate content in user comments" \
  --technical-description "Lightweight text classifier using logistic regression" \
  --model-architecture "Logistic Regression with TF-IDF features" \
  --data-source "Public spam dataset (UCI ML Repository)" \
  --transparency-measure "Confidence scores exposed in API" \
  --contact-email "compliance@safeweb.example" \
  --output-dir ./example-certificates

echo ""
echo ""

# Example 2: Limited risk system
echo "Example 2: Limited Risk System (Chatbot)"
echo "----------------------------------------"
eu-cert \
  --system-name "Customer Support Chatbot" \
  --system-version "1.5.0" \
  --provider-name "ChatAssist Ltd" \
  --provider-address "12 Innovation Park, Dublin, Ireland" \
  --risk-level limited \
  --intended-purpose "Answer customer FAQs and route to human agents" \
  --technical-description "GPT-based conversational AI with retrieval augmentation" \
  --model-architecture "GPT-3.5 with RAG" \
  --data-source "Company knowledge base (10K articles)" \
  --data-source "Historical chat transcripts (anonymized)" \
  --human-oversight \
  --transparency-measure "Discloses AI identity to users" \
  --transparency-measure "Human escalation available" \
  --contact-email "ai-ethics@chatassist.example" \
  --output-dir ./example-certificates

echo ""
echo ""

# Example 3: High-risk system (Employment)
echo "Example 3: High-Risk System (Hiring AI)"
echo "---------------------------------------"
eu-cert \
  --system-name "TalentRank CV Screener" \
  --system-version "2.0.0" \
  --provider-name "TalentMatch GmbH" \
  --provider-address "45 Innovation Blvd, Munich, Germany" \
  --risk-level high \
  --annex-category employment_workers_management \
  --intended-purpose "Automated screening of job applications and candidate ranking" \
  --technical-description "BERT-based NLP with fairness constraints and bias mitigation" \
  --model-architecture "BERT transformer with custom classification head" \
  --data-source "Public resume datasets (CC-BY licensed)" \
  --data-source "Synthetic balanced training data (100K samples)" \
  --human-oversight \
  --transparency-measure "Provides decision explanations to HR reviewers" \
  --transparency-measure "Real-time bias monitoring dashboard" \
  --transparency-measure "Candidate can request human review" \
  --contact-email "dpo@talentmatch.example" \
  --output-dir ./example-certificates

echo ""
echo ""

# Example 4: High-risk system (Education)
echo "Example 4: High-Risk System (Exam Proctoring)"
echo "---------------------------------------------"
eu-cert \
  --system-name "ProctorAI Exam Monitor" \
  --system-version "1.0.0" \
  --provider-name "EduTech Solutions SAS" \
  --provider-address "22 Campus Drive, Lyon, France" \
  --risk-level high \
  --annex-category education_vocational_training \
  --intended-purpose "Automated monitoring of online exams for academic integrity violations" \
  --technical-description "Multi-modal AI analyzing video, audio, and screen activity" \
  --model-architecture "Vision transformer + audio classifier ensemble" \
  --data-source "Synthetic exam footage (privacy-compliant)" \
  --data-source "Behavioral biometrics research datasets" \
  --human-oversight \
  --transparency-measure "Students notified of AI monitoring before exam" \
  --transparency-measure "Human review of all flagged incidents" \
  --transparency-measure "Appeal process for disputed violations" \
  --contact-email "privacy@edutech.example" \
  --output-dir ./example-certificates \
  --format pdf

echo ""
echo "=================================================="
echo "✅ Example certificates generated in ./example-certificates/"
echo ""
echo "Next steps:"
echo "  1. Review the PDF certificates"
echo "  2. Inspect the JSON data for programmatic use"
echo "  3. Scan QR codes with your phone (mock verification URL)"
echo "  4. Customize for your own AI systems"
echo ""
echo "⚠️  Remember: These are documentation tools, not regulatory approval."
echo "   Consult legal counsel for compliance guidance."
echo ""
