# EU Compliance Certificate Generator

Generate verifiable EU AI Act compliance certificates with cryptographic proof—no fake paperwork, no expensive SaaS subscriptions.

## What is this?

A lightweight CLI tool that produces official-looking PDF compliance certificates for AI systems, backed by blockchain-anchored cryptographic attestations. Built for solo developers and small teams (1-10 people) who need legitimate compliance documentation before the September 2026 EU AI Act Annex III deadline but can't justify $99/month SaaS costs. Each certificate includes SHA-256 hashing and optional blockchain anchoring for verifiable, tamper-proof proof of compliance assessment.

## Features

- **PDF Certificate Generation** – Creates professional, branded EU AI Act compliance certificates
- **Cryptographic Attestation** – SHA-256 hashing with optional blockchain anchoring for proof of authenticity
- **Risk Classification** – Automated assessment of AI systems as High/Limited/Minimal risk per Annex III
- **CLI-First Design** – Simple command-line interface, no UI overhead
- **Standalone Operation** – Zero SaaS dependencies; runs locally
- **Audit Trail** – Timestamped, hashable compliance records for regulatory review
- **Batch Processing** – Generate certificates for multiple AI systems in one operation

## Quick Start

### Installation

```bash
pip install eu-compliance-certificate-generator
```

Or clone and install locally:

```bash
git clone <repository>
cd eu-compliance-certificate-generator
pip install -e .
```

### Basic Usage

```bash
# Generate a single compliance certificate
eu-cert generate \
  --system-name "MyAI" \
  --risk-level "limited" \
  --company "Acme Corp" \
  --output certificate.pdf

# Add blockchain anchoring
eu-cert generate \
  --system-name "MyAI" \
  --risk-level "limited" \
  --company "Acme Corp" \
  --output certificate.pdf \
  --anchor-blockchain

# View certificate hash and proof
eu-cert verify certificate.pdf
```

## Usage Examples

**Generate a high-risk AI system certificate with full audit trail:**

```bash
eu-cert generate \
  --system-name "Facial Recognition System v2.1" \
  --risk-level "high" \
  --company "SecurityInc" \
  --description "Real-time face detection for access control" \
  --assessor "John Doe" \
  --output facial_recognition_cert.pdf \
  --anchor-blockchain
```

**Batch process multiple systems:**

```bash
eu-cert batch --config systems.json --output-dir ./certs
```

**Verify certificate authenticity:**

```bash
eu-cert verify facial_recognition_cert.pdf --blockchain
```

See `example_usage.sh` for additional patterns.

## Tech Stack

- **Python 3.9+** – Core runtime
- **reportlab** – PDF generation
- **Pydantic** – Data validation and models
- **hashlib** – Cryptographic hashing
- **Click** – CLI framework
- **pytest** – Testing

Optional blockchain support via Web3.py for Ethereum/Polygon anchoring.

## Project Structure

```
eu_compliance_cert/
├── models.py          # Pydantic schemas for certificates and assessments
├── generator.py       # PDF generation and hashing logic
├── cli.py             # Command-line interface
└── __init__.py
tests/
├── test_generator.py  # PDF and hash verification tests
└── test_models.py     # Schema validation tests
example_usage.sh       # Common workflows
pyproject.toml         # Package metadata and dependencies
```

## License

MIT