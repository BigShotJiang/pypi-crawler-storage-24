"""Certificate generation and cryptographic operations"""

import hashlib
import secrets
import json
from datetime import datetime, timedelta
from typing import Optional
from pathlib import Path

from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_CENTER, TA_LEFT
import qrcode
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import padding, rsa
from cryptography.hazmat.primitives import serialization

from eu_compliance_cert.models import AISystemInfo, ComplianceCertificate, RiskLevel


class CertificateGenerator:
    """Generates EU AI Act compliance certificates with cryptographic proof"""
    
    def __init__(self, output_dir: Path = Path("./certificates")):
        self.output_dir = output_dir
        self.output_dir.mkdir(exist_ok=True)
        
        # Generate RSA key pair for signing (in production, load from secure storage)
        self.private_key = rsa.generate_private_key(
            public_exponent=65537,
            key_size=2048
        )
        self.public_key = self.private_key.public_key()
    
    def generate_certificate_id(self) -> str:
        """Generate unique certificate ID"""
        return f"EU-CERT-{secrets.token_hex(8).upper()}"
    
    def compute_compliance_hash(self, system_info: AISystemInfo, cert_id: str) -> str:
        """Compute SHA-256 hash of certificate data"""
        data = {
            "certificate_id": cert_id,
            "system_name": system_info.system_name,
            "system_version": system_info.system_version,
            "provider_name": system_info.provider_name,
            "risk_level": system_info.risk_level.value,
            "timestamp": datetime.utcnow().isoformat()
        }
        
        data_bytes = json.dumps(data, sort_keys=True).encode('utf-8')
        return hashlib.sha256(data_bytes).hexdigest()
    
    def sign_certificate(self, compliance_hash: str) -> bytes:
        """Create digital signature for certificate"""
        signature = self.private_key.sign(
            compliance_hash.encode('utf-8'),
            padding.PSS(
                mgf=padding.MGF1(hashes.SHA256()),
                salt_length=padding.PSS.MAX_LENGTH
            ),
            hashes.SHA256()
        )
        return signature
    
    def anchor_to_blockchain(self, compliance_hash: str) -> Optional[str]:
        """
        Anchor certificate hash to blockchain (mock implementation)
        
        In production, this would:
        1. Connect to Ethereum/Polygon/Bitcoin
        2. Create transaction with OP_RETURN containing hash
        3. Return transaction ID
        
        For now, returns mock transaction ID
        """
        # Mock blockchain anchoring - in production, use web3.py or similar
        mock_tx_id = f"0x{secrets.token_hex(32)}"
        print(f"[MOCK] Anchoring hash {compliance_hash[:16]}... to blockchain")
        print(f"[MOCK] Transaction ID: {mock_tx_id}")
        return mock_tx_id
    
    def get_attestations(self, system_info: AISystemInfo) -> list[str]:
        """Generate compliance checklist attestations based on risk level"""
        attestations = [
            "System documentation meets Article 11 technical documentation requirements",
            "Risk management system implemented per Article 9",
            "Data governance practices comply with Article 10",
        ]
        
        if system_info.risk_level == RiskLevel.HIGH:
            attestations.extend([
                "Annex III high-risk classification properly documented",
                "Conformity assessment procedures initiated",
                "Human oversight measures implemented per Article 14",
                "Accuracy, robustness, and cybersecurity measures per Article 15",
            ])
        
        if system_info.human_oversight:
            attestations.append("Human-in-the-loop oversight verified")
        
        if system_info.transparency_measures:
            attestations.append(f"Transparency measures implemented: {', '.join(system_info.transparency_measures)}")
        
        return attestations
    
    def create_certificate(self, system_info: AISystemInfo) -> ComplianceCertificate:
        """Create compliance certificate with all metadata"""
        cert_id = self.generate_certificate_id()
        compliance_hash = self.compute_compliance_hash(system_info, cert_id)
        
        # Sign certificate
        signature = self.sign_certificate(compliance_hash)
        
        # Anchor to blockchain (optional, mock implementation)
        blockchain_anchor = self.anchor_to_blockchain(compliance_hash)
        
        # Generate verification URL
        verification_url = f"https://verify.euaicert.example/{cert_id}"
        
        # Create certificate object
        certificate = ComplianceCertificate(
            certificate_id=cert_id,
            system_info=system_info,
            valid_until=datetime.utcnow() + timedelta(days=365),
            compliance_hash=compliance_hash,
            blockchain_anchor=blockchain_anchor,
            qr_verification_url=verification_url,
            attestations=self.get_attestations(system_info)
        )
        
        return certificate
    
    def generate_qr_code(self, url: str) -> Path:
        """Generate QR code for certificate verification"""
        qr = qrcode.QRCode(version=1, box_size=10, border=2)
        qr.add_data(url)
        qr.make(fit=True)
        
        img = qr.make_image(fill_color="black", back_color="white")
        qr_path = self.output_dir / "temp_qr.png"
        img.save(qr_path)
        return qr_path
    
    def generate_pdf(self, certificate: ComplianceCertificate, output_path: Path):
        """Generate PDF certificate document"""
        doc = SimpleDocTemplate(str(output_path), pagesize=A4)
        story = []
        styles = getSampleStyleSheet()
        
        # Custom styles
        title_style = ParagraphStyle(
            'CustomTitle',
            parent=styles['Heading1'],
            fontSize=24,
            textColor=colors.HexColor('#003399'),
            alignment=TA_CENTER,
            spaceAfter=20
        )
        
        header_style = ParagraphStyle(
            'CustomHeader',
            parent=styles['Heading2'],
            fontSize=14,
            textColor=colors.HexColor('#003399'),
            spaceAfter=10
        )
        
        # Title
        story.append(Paragraph("EU AI ACT COMPLIANCE CERTIFICATE", title_style))
        story.append(Spacer(1, 10*mm))
        
        # Certificate info box
        cert_info = [
            ["Certificate ID:", certificate.certificate_id],
            ["Issue Date:", certificate.issue_date.strftime("%Y-%m-%d %H:%M UTC")],
            ["Valid Until:", certificate.valid_until.strftime("%Y-%m-%d")],
            ["Compliance Hash:", certificate.compliance_hash[:32] + "..."]
        ]
        
        if certificate.blockchain_anchor:
            cert_info.append(["Blockchain TX:", certificate.blockchain_anchor[:32] + "..."])
        
        cert_table = Table(cert_info, colWidths=[50*mm, 120*mm])
        cert_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (0, -1), colors.HexColor('#E6F2FF')),
            ('TEXTCOLOR', (0, 0), (-1, -1), colors.black),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 9),
            ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
            ('ROWBACKGROUNDS', (0, 0), (-1, -1), [colors.white, colors.HexColor('#F5F5F5')])
        ]))
        story.append(cert_table)
        story.append(Spacer(1, 10*mm))
        
        # System information
        story.append(Paragraph("AI SYSTEM INFORMATION", header_style))
        
        system_info = [
            ["System Name:", certificate.system_info.system_name],
            ["Version:", certificate.system_info.system_version],
            ["Provider:", certificate.system_info.provider_name],
            ["Risk Level:", certificate.system_info.risk_level.value.upper()],
        ]
        
        if certificate.system_info.annex_category:
            system_info.append(["Annex Category:", certificate.system_info.annex_category.value])
        
        system_info.extend([
            ["Intended Purpose:", certificate.system_info.intended_purpose],
            ["Model Type:", certificate.system_info.model_architecture],
            ["Human Oversight:", "YES" if certificate.system_info.human_oversight else "NO"]
        ])
        
        system_table = Table(system_info, colWidths=[50*mm, 120*mm])
        system_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (0, -1), colors.HexColor('#E6F2FF')),
            ('TEXTCOLOR', (0, 0), (-1, -1), colors.black),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 9),
            ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
            ('VALIGN', (0, 0), (-1, -1), 'TOP'),
        ]))
        story.append(system_table)
        story.append(Spacer(1, 10*mm))
        
        # Attestations
        story.append(Paragraph("COMPLIANCE ATTESTATIONS", header_style))
        
        attestation_data = [[f"✓ {att}"] for att in certificate.attestations]
        attestation_table = Table(attestation_data, colWidths=[170*mm])
        attestation_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, -1), colors.HexColor('#F0FFF0')),
            ('TEXTCOLOR', (0, 0), (-1, -1), colors.black),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTSIZE', (0, 0), (-1, -1), 9),
            ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
            ('LEFTPADDING', (0, 0), (-1, -1), 10),
            ('RIGHTPADDING', (0, 0), (-1, -1), 10),
        ]))
        story.append(attestation_table)
        story.append(Spacer(1, 10*mm))
        
        # QR code for verification
        qr_path = self.generate_qr_code(certificate.qr_verification_url)
        qr_img = Image(str(qr_path), width=40*mm, height=40*mm)
        
        qr_data = [
            [qr_img, Paragraph(
                f"<b>Verify this certificate:</b><br/>{certificate.qr_verification_url}<br/><br/>"
                f"<i>This certificate is cryptographically signed and blockchain-anchored. "
                f"Scan the QR code or visit the URL to verify authenticity.</i>",
                styles['Normal']
            )]
        ]
        
        qr_table = Table(qr_data, colWidths=[45*mm, 125*mm])
        qr_table.setStyle(TableStyle([
            ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
            ('ALIGN', (0, 0), (0, 0), 'CENTER'),
        ]))
        story.append(qr_table)
        story.append(Spacer(1, 15*mm))
        
        # Footer
        footer = Paragraph(
            "<i>This compliance certificate is generated for documentation purposes under the EU AI Act (Regulation 2024/1689). "
            "It does not constitute legal advice or guarantee regulatory approval. "
            "Provider is responsible for maintaining ongoing compliance with all applicable requirements.</i>",
            ParagraphStyle('Footer', parent=styles['Normal'], fontSize=7, textColor=colors.grey)
        )
        story.append(footer)
        
        # Build PDF
        doc.build(story)
        
        # Clean up temp QR code
        qr_path.unlink()
    
    def save_certificate_json(self, certificate: ComplianceCertificate, output_path: Path):
        """Save certificate data as JSON"""
        with open(output_path, 'w') as f:
            f.write(certificate.model_dump_json(indent=2))
    
    def generate(self, system_info: AISystemInfo, format: str = "both") -> tuple[Path, Path]:
        """
        Generate compliance certificate
        
        Args:
            system_info: AI system information
            format: "pdf", "json", or "both"
        
        Returns:
            Tuple of (pdf_path, json_path)
        """
        certificate = self.create_certificate(system_info)
        
        base_name = f"{certificate.certificate_id}_{certificate.system_info.system_name.replace(' ', '_')}"
        pdf_path = self.output_dir / f"{base_name}.pdf"
        json_path = self.output_dir / f"{base_name}.json"
        
        if format in ["pdf", "both"]:
            self.generate_pdf(certificate, pdf_path)
            print(f"✓ PDF certificate generated: {pdf_path}")
        
        if format in ["json", "both"]:
            self.save_certificate_json(certificate, json_path)
            print(f"✓ JSON certificate data saved: {json_path}")
        
        return pdf_path, json_path
