"""Command-line interface for certificate generation"""

import click
from pathlib import Path
from typing import List

from eu_compliance_cert.models import AISystemInfo, RiskLevel, AnnexCategory
from eu_compliance_cert.generator import CertificateGenerator


@click.command()
@click.option('--system-name', required=True, help='Name of the AI system')
@click.option('--system-version', required=True, help='Version identifier')
@click.option('--provider-name', required=True, help='Company/individual providing the system')
@click.option('--provider-address', required=True, help='Physical address of provider')
@click.option('--risk-level', 
              type=click.Choice(['high', 'limited', 'minimal'], case_sensitive=False),
              required=True,
              help='EU AI Act risk classification')
@click.option('--annex-category',
              type=click.Choice([c.value for c in AnnexCategory], case_sensitive=False),
              help='Annex III category (required for high-risk systems)')
@click.option('--intended-purpose', required=True, help='Primary intended use case')
@click.option('--technical-description', required=True, help='Brief technical overview')
@click.option('--data-source', multiple=True, help='Training data source (can specify multiple)')
@click.option('--model-architecture', required=True, help='Model type (e.g., transformer, CNN)')
@click.option('--human-oversight/--no-human-oversight', default=True, 
              help='Whether human-in-the-loop oversight is implemented')
@click.option('--transparency-measure', multiple=True, 
              help='Transparency/explainability feature (can specify multiple)')
@click.option('--contact-email', required=True, help='Contact email for compliance inquiries')
@click.option('--output-dir', default='./certificates', 
              type=click.Path(path_type=Path),
              help='Output directory for certificates')
@click.option('--format', 
              type=click.Choice(['pdf', 'json', 'both'], case_sensitive=False),
              default='both',
              help='Output format')
def main(
    system_name: str,
    system_version: str,
    provider_name: str,
    provider_address: str,
    risk_level: str,
    annex_category: str,
    intended_purpose: str,
    technical_description: str,
    data_source: tuple,
    model_architecture: str,
    human_oversight: bool,
    transparency_measure: tuple,
    contact_email: str,
    output_dir: Path,
    format: str
):
    """Generate EU AI Act compliance certificates with cryptographic verification"""
    
    click.echo("🇪🇺 EU AI Act Compliance Certificate Generator\n")
    
    # Validate high-risk systems must specify annex category
    if risk_level.lower() == 'high' and not annex_category:
        click.echo("❌ Error: High-risk systems must specify --annex-category", err=True)
        raise click.Abort()
    
    # Build system info
    try:
        system_info = AISystemInfo(
            system_name=system_name,
            system_version=system_version,
            provider_name=provider_name,
            provider_address=provider_address,
            risk_level=RiskLevel(risk_level.lower()),
            annex_category=AnnexCategory(annex_category) if annex_category else None,
            intended_purpose=intended_purpose,
            technical_description=technical_description,
            data_sources=list(data_source),
            model_architecture=model_architecture,
            human_oversight=human_oversight,
            transparency_measures=list(transparency_measure),
            contact_email=contact_email
        )
    except ValueError as e:
        click.echo(f"❌ Validation error: {e}", err=True)
        raise click.Abort()
    
    # Generate certificate
    click.echo("Generating certificate...")
    click.echo(f"  System: {system_name} v{system_version}")
    click.echo(f"  Provider: {provider_name}")
    click.echo(f"  Risk Level: {risk_level.upper()}")
    
    generator = CertificateGenerator(output_dir=output_dir)
    
    try:
        pdf_path, json_path = generator.generate(system_info, format=format.lower())
        
        click.echo("\n✅ Certificate generation complete!")
        
        if format.lower() in ['pdf', 'both']:
            click.echo(f"\n📄 PDF Certificate: {pdf_path}")
        
        if format.lower() in ['json', 'both']:
            click.echo(f"📋 JSON Data: {json_path}")
        
        click.echo("\n⚠️  Important: This certificate is for documentation purposes.")
        click.echo("   You remain responsible for ongoing EU AI Act compliance.")
        click.echo("   Consult legal counsel for regulatory guidance.\n")
        
    except Exception as e:
        click.echo(f"\n❌ Error generating certificate: {e}", err=True)
        raise click.Abort()


if __name__ == '__main__':
    main()
