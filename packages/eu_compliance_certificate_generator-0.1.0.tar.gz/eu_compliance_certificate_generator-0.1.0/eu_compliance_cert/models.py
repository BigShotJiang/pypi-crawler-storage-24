"""Data models for compliance certificates"""

from datetime import datetime
from enum import Enum
from typing import Optional, List
from pydantic import BaseModel, Field, field_validator


class RiskLevel(str, Enum):
    """EU AI Act risk classification levels"""
    UNACCEPTABLE = "unacceptable"
    HIGH = "high"
    LIMITED = "limited"
    MINIMAL = "minimal"


class AnnexCategory(str, Enum):
    """Annex III high-risk AI system categories"""
    BIOMETRIC = "biometric_identification"
    CRITICAL_INFRASTRUCTURE = "critical_infrastructure"
    EDUCATION_VOCATIONAL = "education_vocational_training"
    EMPLOYMENT = "employment_workers_management"
    ESSENTIAL_SERVICES = "essential_private_public_services"
    LAW_ENFORCEMENT = "law_enforcement"
    MIGRATION_ASYLUM = "migration_asylum_border"
    JUSTICE = "administration_of_justice"


class AISystemInfo(BaseModel):
    """Information about the AI system being certified"""
    
    system_name: str = Field(..., description="Name of the AI system")
    system_version: str = Field(..., description="Version identifier")
    provider_name: str = Field(..., description="Company/individual providing the system")
    provider_address: str = Field(..., description="Physical address of provider")
    
    risk_level: RiskLevel = Field(..., description="EU AI Act risk classification")
    annex_category: Optional[AnnexCategory] = Field(None, description="Annex III category if high-risk")
    
    intended_purpose: str = Field(..., description="Primary intended use case")
    technical_description: str = Field(..., description="Brief technical overview")
    
    data_sources: List[str] = Field(default_factory=list, description="Training data sources")
    model_architecture: str = Field(..., description="Model type (e.g., transformer, CNN)")
    
    human_oversight: bool = Field(True, description="Human-in-the-loop oversight implemented")
    transparency_measures: List[str] = Field(default_factory=list, description="Transparency/explainability features")
    
    contact_email: str = Field(..., description="Contact for compliance inquiries")
    
    @field_validator('risk_level')
    @classmethod
    def validate_risk_level(cls, v: RiskLevel, info) -> RiskLevel:
        if v == RiskLevel.UNACCEPTABLE:
            raise ValueError("Unacceptable risk systems cannot be certified under EU AI Act")
        return v


class ComplianceCertificate(BaseModel):
    """Generated compliance certificate with cryptographic proof"""
    
    certificate_id: str = Field(..., description="Unique certificate identifier")
    system_info: AISystemInfo
    
    issue_date: datetime = Field(default_factory=datetime.utcnow)
    valid_until: datetime = Field(..., description="Certificate expiration date")
    
    compliance_hash: str = Field(..., description="SHA-256 hash of certificate data")
    blockchain_anchor: Optional[str] = Field(None, description="Blockchain transaction ID")
    
    qr_verification_url: str = Field(..., description="URL for certificate verification")
    
    attestations: List[str] = Field(default_factory=list, description="Compliance checklist items attested")
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat()
        }
