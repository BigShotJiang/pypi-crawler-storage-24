"""Tests for certificate generator"""

import pytest
from pathlib import Path
from datetime import datetime, timedelta

from eu_compliance_cert.models import AISystemInfo, RiskLevel, AnnexCategory
from eu_compliance_cert.generator import CertificateGenerator


@pytest.fixture
def minimal_system_info():
    """Minimal valid AI system info"""
    return AISystemInfo(
        system_name="Test System",
        system_version="1.0.0",
        provider_name="Test Provider",
        provider_address="123 Test St",
        risk_level=RiskLevel.MINIMAL,
        intended_purpose="Testing",
        technical_description="Test model",
        model_architecture="Test arch",
        contact_email="test@example.com"
    )


@pytest.fixture
def high_risk_system_info():
    """High-risk AI system info"""
    return AISystemInfo(
        system_name="Hiring AI",
        system_version="2.0.0",
        provider_name="TalentMatch",
        provider_address="456 Business Ave",
        risk_level=RiskLevel.HIGH,
        annex_category=AnnexCategory.EMPLOYMENT,
        intended_purpose="Resume screening",
        technical_description="BERT-based NLP",
        model_architecture="BERT",
        data_sources=["Public datasets", "Synthetic data"],
        human_oversight=True,
        transparency_measures=["Explanations", "Bias monitoring"],
        contact_email="compliance@example.com"
    )


def test_certificate_id_generation():
    """Test certificate ID format"""
    generator = CertificateGenerator()
    cert_id = generator.generate_certificate_id()
    
    assert cert_id.startswith("EU-CERT-")
    assert len(cert_id) == 24  # EU-CERT- + 16 hex chars


def test_compliance_hash_generation(minimal_system_info):
    """Test compliance hash computation"""
    generator = CertificateGenerator()
    cert_id = "EU-CERT-TEST1234"
    
    hash1 = generator.compute_compliance_hash(minimal_system_info, cert_id)
    hash2 = generator.compute_compliance_hash(minimal_system_info, cert_id)
    
    assert len(hash1) == 64  # SHA-256 hex length
    # Hashes should differ due to timestamp
    # (Unless run in same millisecond, which is unlikely)


def test_certificate_creation(minimal_system_info):
    """Test certificate object creation"""
    generator = CertificateGenerator()
    certificate = generator.create_certificate(minimal_system_info)
    
    assert certificate.certificate_id.startswith("EU-CERT-")
    assert certificate.system_info == minimal_system_info
    assert len(certificate.compliance_hash) == 64
    assert certificate.blockchain_anchor.startswith("0x")
    assert certificate.valid_until > datetime.utcnow()


def test_attestations_minimal_risk(minimal_system_info):
    """Test attestations for minimal-risk system"""
    generator = CertificateGenerator()
    attestations = generator.get_attestations(minimal_system_info)
    
    assert len(attestations) >= 3
    assert any("Article 11" in att for att in attestations)
    assert any("human oversight" in att.lower() for att in attestations)


def test_attestations_high_risk(high_risk_system_info):
    """Test attestations for high-risk system"""
    generator = CertificateGenerator()
    attestations = generator.get_attestations(high_risk_system_info)
    
    # High-risk should have more attestations
    assert len(attestations) > 5
    assert any("Annex III" in att for att in attestations)
    assert any("conformity assessment" in att.lower() for att in attestations)
    assert any("Article 14" in att for att in attestations)


def test_pdf_generation(minimal_system_info, tmp_path):
    """Test PDF certificate generation"""
    generator = CertificateGenerator(output_dir=tmp_path)
    certificate = generator.create_certificate(minimal_system_info)
    
    pdf_path = tmp_path / "test_cert.pdf"
    generator.generate_pdf(certificate, pdf_path)
    
    assert pdf_path.exists()
    assert pdf_path.stat().st_size > 10000  # PDF should be >10KB


def test_json_generation(minimal_system_info, tmp_path):
    """Test JSON certificate generation"""
    generator = CertificateGenerator(output_dir=tmp_path)
    certificate = generator.create_certificate(minimal_system_info)
    
    json_path = tmp_path / "test_cert.json"
    generator.save_certificate_json(certificate, json_path)
    
    assert json_path.exists()
    
    # Verify JSON is valid
    import json
    with open(json_path) as f:
        data = json.load(f)
    
    assert data["certificate_id"] == certificate.certificate_id
    assert data["system_info"]["system_name"] == "Test System"


def test_full_generation_workflow(high_risk_system_info, tmp_path):
    """Test complete certificate generation workflow"""
    generator = CertificateGenerator(output_dir=tmp_path)
    
    pdf_path, json_path = generator.generate(high_risk_system_info, format="both")
    
    assert pdf_path.exists()
    assert json_path.exists()
    assert pdf_path.suffix == ".pdf"
    assert json_path.suffix == ".json"


def test_unacceptable_risk_validation():
    """Test that unacceptable risk systems are rejected"""
    with pytest.raises(ValueError, match="Unacceptable risk"):
        AISystemInfo(
            system_name="Bad System",
            system_version="1.0.0",
            provider_name="Bad Provider",
            provider_address="123 Bad St",
            risk_level=RiskLevel.UNACCEPTABLE,
            intended_purpose="Social scoring",
            technical_description="Dystopian AI",
            model_architecture="Evil",
            contact_email="bad@example.com"
        )


def test_certificate_validity_period(minimal_system_info):
    """Test certificate has 1-year validity"""
    generator = CertificateGenerator()
    certificate = generator.create_certificate(minimal_system_info)
    
    validity_period = certificate.valid_until - certificate.issue_date
    
    # Should be approximately 365 days
    assert 364 <= validity_period.days <= 366
