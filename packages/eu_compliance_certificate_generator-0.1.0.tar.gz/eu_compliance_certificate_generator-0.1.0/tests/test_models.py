"""Tests for data models"""

import pytest
from datetime import datetime

from eu_compliance_cert.models import (
    AISystemInfo,
    ComplianceCertificate,
    RiskLevel,
    AnnexCategory
)


def test_risk_level_enum():
    """Test risk level enum values"""
    assert RiskLevel.HIGH.value == "high"
    assert RiskLevel.LIMITED.value == "limited"
    assert RiskLevel.MINIMAL.value == "minimal"
    assert RiskLevel.UNACCEPTABLE.value == "unacceptable"


def test_annex_category_enum():
    """Test annex category enum values"""
    assert AnnexCategory.BIOMETRIC.value == "biometric_identification"
    assert AnnexCategory.EMPLOYMENT.value == "employment_workers_management"


def test_minimal_system_info():
    """Test creating minimal valid system info"""
    info = AISystemInfo(
        system_name="Test System",
        system_version="1.0.0",
        provider_name="Test Provider",
        provider_address="123 Test St",
        risk_level=RiskLevel.MINIMAL,
        intended_purpose="Testing",
        technical_description="Test description",
        model_architecture="Test arch",
        contact_email="test@example.com"
    )
    
    assert info.system_name == "Test System"
    assert info.risk_level == RiskLevel.MINIMAL
    assert info.human_oversight is True  # Default value
    assert info.data_sources == []  # Default empty list


def test_high_risk_with_annex_category():
    """Test high-risk system with annex category"""
    info = AISystemInfo(
        system_name="Hiring AI",
        system_version="1.0.0",
        provider_name="Provider",
        provider_address="Address",
        risk_level=RiskLevel.HIGH,
        annex_category=AnnexCategory.EMPLOYMENT,
        intended_purpose="Hiring",
        technical_description="AI for hiring",
        model_architecture="Transformer",
        contact_email="test@example.com"
    )
    
    assert info.risk_level == RiskLevel.HIGH
    assert info.annex_category == AnnexCategory.EMPLOYMENT


def test_unacceptable_risk_rejected():
    """Test that unacceptable risk systems cannot be created"""
    with pytest.raises(ValueError, match="Unacceptable risk"):
        AISystemInfo(
            system_name="Bad System",
            system_version="1.0.0",
            provider_name="Provider",
            provider_address="Address",
            risk_level=RiskLevel.UNACCEPTABLE,
            intended_purpose="Bad purpose",
            technical_description="Bad tech",
            model_architecture="Bad arch",
            contact_email="test@example.com"
        )


def test_compliance_certificate_creation():
    """Test compliance certificate model"""
    system_info = AISystemInfo(
        system_name="Test",
        system_version="1.0.0",
        provider_name="Provider",
        provider_address="Address",
        risk_level=RiskLevel.LIMITED,
        intended_purpose="Purpose",
        technical_description="Tech",
        model_architecture="Arch",
        contact_email="test@example.com"
    )
    
    now = datetime.utcnow()
    cert = ComplianceCertificate(
        certificate_id="EU-CERT-TEST123",
        system_info=system_info,
        valid_until=now,
        compliance_hash="abc123",
        qr_verification_url="https://example.com/verify/TEST123"
    )
    
    assert cert.certificate_id == "EU-CERT-TEST123"
    assert cert.system_info == system_info
    assert cert.compliance_hash == "abc123"


def test_certificate_json_serialization():
    """Test certificate can be serialized to JSON"""
    system_info = AISystemInfo(
        system_name="Test",
        system_version="1.0.0",
        provider_name="Provider",
        provider_address="Address",
        risk_level=RiskLevel.LIMITED,
        intended_purpose="Purpose",
        technical_description="Tech",
        model_architecture="Arch",
        contact_email="test@example.com"
    )
    
    cert = ComplianceCertificate(
        certificate_id="EU-CERT-TEST123",
        system_info=system_info,
        valid_until=datetime.utcnow(),
        compliance_hash="abc123",
        qr_verification_url="https://example.com"
    )
    
    json_str = cert.model_dump_json()
    assert "EU-CERT-TEST123" in json_str
    assert "Test" in json_str
    assert "limited" in json_str
