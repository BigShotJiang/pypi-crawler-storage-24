import argparse
from .core import encode_image, decode_image

def main():
    parser = argparse.ArgumentParser(description="Stegabot: Hide secrets in pixels.")
    subparsers = parser.add_subparsers(dest="command")

    enc = subparsers.add_parser("encode")
    enc.add_argument("input", help="Source image")
    enc.add_argument("message", help="Secret message")
    enc.add_argument("output", help="Output PNG path")

    dec = subparsers.add_parser("decode")
    dec.add_argument("input", help="Encoded image")

    args = parser.parse_args()
    if args.command == "encode":
        if encode_image(args.input, args.message, args.output):
            print(f"Success! Saved to {args.output}")
    elif args.command == "decode":
        print(f"Hidden Message: {decode_image(args.input)}")

if __name__ == "__main__":
    main()
