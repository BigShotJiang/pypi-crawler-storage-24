import os
import pytest
from PIL import Image
from stegabot.core import encode_image, decode_image

# This "fixture" creates a fresh image for every test automatically
@pytest.fixture
def temp_image(tmp_path):
    img_path = tmp_path / "test_input.png"
    img = Image.new('RGB', (100, 100), color='red')
    img.save(img_path)
    return str(img_path)

def test_basic_encoding_decoding(temp_image):
    """Test if a standard message is hidden and retrieved correctly."""
    output_path = "test_output.png"
    msg = "Hello World"
    
    encode_image(temp_image, msg, output_path)
    decoded = decode_image(output_path)
    
    os.remove(output_path)
    assert decoded == msg

def test_empty_message(temp_image):
    """Test if the script handles an empty string."""
    output_path = "test_empty.png"
    msg = ""
    
    encode_image(temp_image, msg, output_path)
    decoded = decode_image(output_path)
    
    os.remove(output_path)
    assert decoded == ""

def test_message_too_long(temp_image):
    """Test if the script returns False when message exceeds pixel capacity."""
    # A 100x100 image has 10,000 pixels (30,000 bits). 
    # We try to hide a massive message.
    huge_msg = "A" * 5000 
    output_path = "test_huge.png"
    
    result = encode_image(temp_image, huge_msg, output_path)
    
    # Based on our core.py logic, it should return False if it can't fit
    assert result is False
