# Stegabot

[![PyPI version](https://badge.fury.io/py/stegabot.svg)](https://badge.fury.io/py/stegabot)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)

**Stegabot** is a lightweight Python CLI tool and library for **LSB (Least Significant Bit) Image Steganography**. It allows you to hide secret text messages inside digital images without altering their visual appearance.

---

## Features

- **Invisible Data Hiding**: Uses LSB encoding to ensure the message is undetectable to the human eye.
- **CLI Support**: Run encoding and decoding directly from your terminal.
- **Developer Friendly**: Simple API for integration into other Python projects.
- **Lossless Support**: Optimized for `.png` and `.bmp` formats.

---

## Installation

Install Stegabot directly from PyPI:

```bash
pip install stegabot

```

## UsageCommand Line Interface (CLI)

Once installed, you can use the `stegabot` command anywhere in your terminal.

1. Encoding (Hiding a message)

```bash
stegabot encode input_image.png "Your secret message here" encoded_output.png
```

2. Decoding (Extracting a message)
```bash
stegabot decode encoded_output.png
```

3. Using as a Python Library

You can also import Stegabot into your own Python scripts:

```bash
from stegabot import encode_image, decode_image

# Hide a message
success = encode_image("photo.png", "Meet me at midnight", "secret.png")
if success:
    print("Message hidden successfully!")

# Extract a message
message = decode_image("secret.png")
print(f"The hidden message is: {message}")
```

## How it Works

Stegabot uses the **Least Significant Bit (LSB)** method. 
It modifies the last bit of the `Red`, `Green`, and `Blue` color 
channels for each pixel. Since the change only alters 
the color value by `1/255th`, the difference is mathematically 
present but visually invisible.

## Important Considerations

- **Image Format**: Always use PNG or BMP. JPEG uses lossy compression which will "smear" the pixels and destroy the hidden data bits.

- **Message Size**: The maximum message length depends on the total number of pixels in your image *(`Width` * `Height`)*.

- **Security**: This tool provides steganography (hiding), not encryption. For high-security needs, encrypt your text before encoding it with Stegabot.


## Contributing

Contributions are welcome! If you have suggestions for improvements or find bugs, please open an issue or submit a pull request on GitHub.

1. Fork the Project

2. Create your Feature Branch (git checkout -b feature/NewFeature)

3. Commit your Changes (git commit -m 'Add some NewFeature')

4. Push to the Branch (git push origin feature/NewFeature)

5. Open a Pull Request


## License

This project is licensed under the MIT License - see the [LICENSE](./LICENSE) file for details.
