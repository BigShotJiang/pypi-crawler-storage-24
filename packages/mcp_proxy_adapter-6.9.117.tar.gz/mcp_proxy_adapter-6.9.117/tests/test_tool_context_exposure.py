"""
Unit tests for orchestration.tool_context_exposure (Step 16, FR-8).

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

from mcp_proxy_adapter.core.orchestration.catalog_snapshot import CatalogSnapshot
from mcp_proxy_adapter.core.orchestration.command_record import CommandRecord
from mcp_proxy_adapter.core.orchestration.server_record import ServerRecord
from mcp_proxy_adapter.core.orchestration.snapshot_holder import SnapshotHolder
from mcp_proxy_adapter.core.orchestration.tool_context_exposure import get_tool_descriptors
from mcp_proxy_adapter.core.orchestration.tool_context_snapshot import (
    ToolContextSnapshot,
)


class TestGetToolDescriptors:
    """Tests for get_tool_descriptors."""

    def test_none_snapshot_returns_empty_list(self) -> None:
        """When holder has no tool context, returns empty list."""
        holder = SnapshotHolder()
        assert get_tool_descriptors(holder) == []

    def test_snapshot_with_one_tool_returns_one_descriptor(self) -> None:
        """When holder has one tool in snapshot, returns one descriptor dict."""
        server = ServerRecord(
            server_id="a1b2c3d4-0000-4000-8000-000000000001",
            host="localhost",
            port=8080,
        )
        command = CommandRecord(
            command_name="echo",
            summary="Echo a message",
            parameter_definitions={"message": {"type": "string"}},
            metadata={"category": "test"},
            schema={
                "type": "object",
                "properties": {"message": {"type": "string"}},
                "required": ["message"],
            },
            required_parameters=("message",),
        )
        catalog = CatalogSnapshot.create(
            version=1,
            servers={server.server_id: server},
            commands_by_server={server.server_id: {command.command_name: command}},
        )
        tool_snapshot = ToolContextSnapshot.from_catalog(catalog)
        holder = SnapshotHolder()
        holder.swap(catalog, tool_snapshot)

        result = get_tool_descriptors(holder)

        assert len(result) == 1
        d = result[0]
        assert d["name"] == f"{server.server_id}:{command.command_name}"
        assert d["description"] == "Echo a message"
        assert d["command_name"] == "echo"
        assert d["server_binding"]["server_id"] == server.server_id
        assert d["server_binding"]["host"] == "localhost"
        assert d["server_binding"]["port"] == 8080
        assert d["parameters"] == command.schema
        assert d["required_parameters"] == ["message"]

    def test_snapshot_with_no_tools_returns_empty_list(self) -> None:
        """When snapshot has no tools (empty catalog), returns empty list."""
        catalog = CatalogSnapshot.create(
            version=1,
            servers={},
            commands_by_server={},
        )
        tool_snapshot = ToolContextSnapshot.from_catalog(catalog)
        holder = SnapshotHolder()
        holder.swap(catalog, tool_snapshot)

        result = get_tool_descriptors(holder)

        assert result == []
