"""
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

Unit tests for orchestration_config: OrchestrationConfig, StaticServerEntry, validate_static_servers.
"""

from __future__ import annotations

import uuid

from mcp_proxy_adapter.core.errors import ValidationError
from mcp_proxy_adapter.core.orchestration.orchestration_config import (
    OrchestrationConfig,
    StaticServerEntry,
    validate_static_servers,
)


def test_static_server_entry_dataclass() -> None:
    """StaticServerEntry accepts host, port, id."""
    entry = StaticServerEntry(host="localhost", port=8080, id=str(uuid.uuid4()))
    assert entry.host == "localhost"
    assert entry.port == 8080
    assert len(entry.id) == 36


def test_orchestration_config_dataclass() -> None:
    """OrchestrationConfig accepts all required fields and optional static_servers."""
    config = OrchestrationConfig(
        discovery_enabled=True,
        polling_interval=30.0,
        initial_poll_timeout=10,
        stale_snapshot_behavior="use_stale",
        mutex_lock_timeout=5.0,
        static_servers=None,
    )
    assert config.discovery_enabled is True
    assert config.static_servers is None

    config_with_servers = OrchestrationConfig(
        discovery_enabled=False,
        polling_interval=60,
        initial_poll_timeout=15.0,
        stale_snapshot_behavior="fail",
        mutex_lock_timeout=2.0,
        static_servers=[
            StaticServerEntry(host="host1", port=9000, id=str(uuid.uuid4())),
        ],
    )
    assert len(config_with_servers.static_servers or []) == 1


def test_validate_static_servers_none_empty() -> None:
    """None or empty list returns no errors."""
    assert validate_static_servers(None) == []
    assert validate_static_servers([]) == []


def test_validate_static_servers_valid_uuid4() -> None:
    """Entries with valid UUID4 id pass validation."""
    valid_uuid = str(uuid.uuid4())
    entries = [
        StaticServerEntry(host="a", port=1, id=valid_uuid),
    ]
    assert validate_static_servers(entries) == []


def test_validate_static_servers_invalid_uuid4() -> None:
    """Entry with invalid UUID4 returns error (fail-fast)."""
    entries = [
        StaticServerEntry(host="a", port=1, id="not-a-uuid"),
    ]
    errors = validate_static_servers(entries)
    assert len(errors) == 1
    assert isinstance(errors[0], ValidationError)
    assert "UUID4" in errors[0].message


def test_validate_static_servers_empty_id() -> None:
    """Entry with empty id returns error."""
    entries = [
        StaticServerEntry(host="a", port=1, id="   "),
    ]
    errors = validate_static_servers(entries)
    assert len(errors) == 1
    assert "empty" in errors[0].message


def test_validate_static_servers_multiple_errors() -> None:
    """Multiple invalid entries produce multiple errors."""
    valid_uuid = str(uuid.uuid4())
    entries = [
        StaticServerEntry(host="a", port=1, id="bad"),
        StaticServerEntry(host="b", port=2, id=valid_uuid),
        StaticServerEntry(host="c", port=3, id=""),
    ]
    errors = validate_static_servers(entries)
    assert len(errors) == 2
