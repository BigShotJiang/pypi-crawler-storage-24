#!/usr/bin/env python3
"""
Comprehensive all-modes pipeline is a standalone script, not a pytest test.

Run from project root:
  python scripts/run_all_modes_pipeline.py

This file exists so pytest does not collect the old heavy pipeline (which used
to consume too much memory). The real pipeline lives in scripts/run_all_modes_pipeline.py.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

import pytest


def test_all_modes_pipeline_run_standalone_script() -> None:
    """Reminder: run scripts/run_all_modes_pipeline.py for full pipeline."""
    pytest.skip(
        "Comprehensive pipeline is a standalone script. "
        "Run: python scripts/run_all_modes_pipeline.py"
    )
