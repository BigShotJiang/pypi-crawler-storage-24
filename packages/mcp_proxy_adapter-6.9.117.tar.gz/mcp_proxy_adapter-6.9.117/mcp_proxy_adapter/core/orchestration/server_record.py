"""
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

ServerRecord dataclass for orchestration catalog: server identity, endpoint
metadata, and health/status metadata (TZ section 7). Used as an immutable
in-memory entity; server_id must satisfy UUID4 (TZ section 10).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional


@dataclass(frozen=True)
class ServerRecord:
    """
    Immutable record for a single server in the orchestration catalog.

    Holds server identity (UUID4), endpoint (host, port), and optional
    endpoint/health/status metadata. No mutable containers; all fields
    are immutable after construction.

    Attributes:
        server_id: Server identifier (must be valid UUID4 string).
        host: Server host (e.g. hostname or IP).
        port: Server port number.
        base_url: Optional full base URL for the server endpoint.
        status: Optional health/status label (e.g. "ok", "unavailable").
    """

    server_id: str
    host: str
    port: int
    base_url: Optional[str] = None
    status: Optional[str] = None
