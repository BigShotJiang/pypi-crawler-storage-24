from sqlalchemy import create_engine
from sqlalchemy.engine import URL

from config import db_config

def get_connection():
    url = URL.create(
        drivername="hana",
        host=db_config.sap_hana_url,
        port=db_config.sap_hana_port,
        username=db_config.sap_hana_username,
        password=db_config.sap_hana_password
    )

    engine = create_engine(url)

    _ = engine.connect().execution_options(stream_results=True)

    return engine
