echo "All tests passed"
