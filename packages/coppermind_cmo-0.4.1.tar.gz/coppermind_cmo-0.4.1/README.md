# Coppermind CMO

AI-powered memory for fractional CMOs. Never forget a client detail, never leak data between clients, always prep well for meetings.

Coppermind CMO is an [MCP server](https://modelcontextprotocol.io/) that gives Claude persistent, client-scoped memory across conversations. Store meeting notes, brand voice, campaign outcomes, and decisions — then search, prep, and recall instantly.

## Installation

```bash
pip install coppermind-cmo
```

## Setup

Add to your Claude Code settings (`~/.claude/settings.json`):

```json
{
  "mcpServers": {
    "coppermind-cmo": {
      "command": "python",
      "args": ["-m", "coppermind_cmo"],
      "env": {
        "COPPERMIND_API_KEY": "your-key-here"
      }
    }
  }
}
```

> **Note:** Use `python3` instead of `python` on Mac/Linux if `python` is not aliased to Python 3.

That's it. The API key handles everything — database access, embeddings, and extraction services are all managed for you.

## What it does

**13 tools for CMO workflows:**

| Tool | Purpose |
|------|---------|
| `switch_client` | Set the active client mind |
| `list_minds` | List all client minds |
| `configure_mind` | Set cadence and company context for the active client |
| `store_memory` | Store a piece of client knowledge |
| `search_memory` | Semantic search across memories |
| `quick_note` | Fast capture, no AI classification |
| `hide_memory` | Soft-delete a memory |
| `get_brand_voice` | Read brand DNA |
| `set_brand_voice` | Update brand voice, positioning, stakeholders |
| `prep_meeting` | Generate a pre-meeting brief |
| `get_last_brief` | Retrieve the most recently saved meeting brief |
| `get_campaign_history` | Review campaign results |
| `list_documents` | List stored raw documents for the active client |

**Key properties:**

- **Client isolation** — every query is scoped to the active client. Zero cross-client data leakage.
- **Brand DNA** — store and retrieve brand voice, positioning, stakeholders, and content themes per client.
- **Meeting prep** — topic-aware retrieval across memories, commitments, and brand DNA, returned as a structured brief.
- **Graceful degradation** — if AI services are temporarily unavailable, storage still works. Nothing is lost.

## Daily workflow

```
# Before a call — get briefed
"Switch to Acme Corp and prep me for our meeting about Q2 planning"

# During/after a call — capture what happened
"Remember that Acme decided to pause LinkedIn ads through Q2"
"Quick note: Sarah mentioned the April budget review might affect Q3"

# Switching clients — change context
"Switch to Bluebell"
"What do we know about Bluebell's campaign performance?"
```

## Optional Extras

For local embedding or related infrastructure dependencies:

```bash
pip install coppermind-cmo[self-hosted]
```

See [full documentation](https://github.com/benfinklea/coppermind-cmo/blob/main/docs/QUICKSTART.md) for current setup details.

## Support

Contact Ben directly at ben@volacci.com.
