"""Intelligence tools: prep_meeting, get_campaign_history.

Reference: docs/MCP_TOOLS.md -- prep_meeting (type-balanced retrieval, synthesis),
get_campaign_history (filtered by campaign_outcome type).
"""

import json
from datetime import datetime
from typing import Any, NamedTuple

from coppermind_cmo.config import Config
from coppermind_cmo.db import Database
from coppermind_cmo.embedding_client import get_embedding
# LLM synthesis removed -- see llm_client.py for future re-enablement
from coppermind_cmo.errors import NO_ACTIVE_MIND, tool_error
from coppermind_cmo.log import ToolLogger
from coppermind_cmo.utils import parse_jsonb, get_mind_cadence, touch_memories

logger = ToolLogger("intelligence")

# Default token budget for self-hosted (gemma3:12b, ~3.25 chars/token, 4000 token limit).
# Overridden by config.max_prompt_chars at runtime.
MAX_PROMPT_CHARS = 13000
RECENCY_WEIGHT = 0.6
SIMILARITY_WEIGHT = 0.4
MIN_MEMORIES_FOR_SYNTHESIS = 3
SIMILARITY_THRESHOLD = 0.3
MAX_LIMIT = 200

PERMANENT_TYPES = {"stakeholder", "preference", "fact"}
TEMPORAL_TYPES = {"decision", "commitment", "campaign_outcome", "question"}

QUARTER_WEIGHTS = {0: 1.0, 1: 0.7, 2: 0.4, 3: 0.2}  # distance -> weight
DEFAULT_QUARTER_WEIGHT = 0.1  # 4+ quarters ago
UNTAGGED_QUARTER_WEIGHT = 0.5


class MemoryRow(NamedTuple):
    """Typed representation of a memory row returned by collection functions.

    Replaces bare tuples with 7-10 positional fields so consumers can use
    named access (e.g. ``row.memory_type``) instead of magic indexes.
    Backward-compatible: positional indexing (row[3]) still works.
    """

    id: str
    content: str
    summary: str | None
    memory_type: str
    created_at: datetime | None
    tag: str  # e.g. 'type_balanced', 'fill', 'agenda', 'topic', etc.
    embedding: Any | None = None
    quarter_year: int | None = None
    quarter: int | None = None
    sprint: int | None = None
    is_completed: bool = False


def _quarter_weight(memory_year, memory_quarter, current_year, current_quarter):
    """Weight temporal memories by distance from current quarter."""
    if memory_year is None or memory_quarter is None:
        return UNTAGGED_QUARTER_WEIGHT
    distance = (current_year * 4 + current_quarter) - (memory_year * 4 + memory_quarter)
    if distance < 0:
        distance = 0  # future quarter treated as current
    return QUARTER_WEIGHTS.get(distance, DEFAULT_QUARTER_WEIGHT)


def _get_campaign_history(
    limit: int,
    offset: int,
    db: Database,
    active_mind: tuple[str, str] | None,
) -> dict | list:
    if active_mind is None:
        return NO_ACTIVE_MIND()

    mind_id, _ = active_mind
    limit = min(max(1, limit), MAX_LIMIT)
    offset = max(0, offset)

    rows = db.fetch_all(
        "SELECT id, content, summary, tags, created_at "
        "FROM memories "
        "WHERE mind_id = %s AND memory_type = 'campaign_outcome' AND is_current = true "
        "ORDER BY created_at DESC LIMIT %s OFFSET %s",
        [mind_id, limit, offset],
    )

    if rows:
        touch_memories(db, [str(r[0]) for r in rows])

    return [
        {
            "memory_id": str(r[0]),
            "content": r[1],
            "summary": r[2],
            "tags": r[3] if r[3] else [],
            "created_at": r[4].isoformat() if r[4] else None,
        }
        for r in rows
    ]


def _collect_type_balanced(mind_id: str, limit: int, db: Database) -> list[MemoryRow]:
    """Type-balanced retrieval per MCP_TOOLS.md prep_meeting spec.

    Returns list of MemoryRow. Tag is 'type_balanced' or 'fill'.
    """
    type_balanced: list[MemoryRow] = []
    fill_memories: list[MemoryRow] = []
    seen_ids: set[str] = set()

    # Get populated types
    type_rows = db.fetch_all(
        "SELECT DISTINCT memory_type FROM memories "
        "WHERE mind_id = %s AND is_current = true",
        [mind_id],
    )
    populated_types = [r[0] for r in type_rows]

    if not populated_types:
        return []

    # Per-type allocation: floor(limit / populated_types), can be 0
    per_type = limit // len(populated_types)

    for mem_type in populated_types:
        rows = db.fetch_all(
            "SELECT id, content, summary, memory_type, created_at, embedding "
            "FROM memories "
            "WHERE mind_id = %s AND memory_type = %s AND is_current = true "
            "ORDER BY created_at DESC LIMIT %s",
            [mind_id, mem_type, per_type],
        )
        for r in rows:
            rid = str(r[0])
            if rid not in seen_ids:
                seen_ids.add(rid)
                type_balanced.append(MemoryRow(
                    id=rid, content=r[1], summary=r[2],
                    memory_type=r[3], created_at=r[4],
                    tag="type_balanced", embedding=r[5],
                ))

    # Fill remaining slots
    remaining = limit - len(type_balanced)
    if remaining > 0:
        fill = db.fetch_all(
            "SELECT id, content, summary, memory_type, created_at, embedding "
            "FROM memories "
            "WHERE mind_id = %s AND is_current = true AND id != ALL(%s::uuid[]) "
            "ORDER BY created_at DESC LIMIT %s",
            [mind_id, list(seen_ids), remaining],
        )
        for r in fill:
            fill_memories.append(MemoryRow(
                id=str(r[0]), content=r[1], summary=r[2],
                memory_type=r[3], created_at=r[4],
                tag="fill", embedding=r[5],
            ))

    return type_balanced + fill_memories


def _collect_meeting_memories(
    mind_id: str,
    topics: list[str] | None,
    limit: int,
    db: Database,
    config: Config,
) -> list[MemoryRow]:
    """Smart retrieval for meeting prep: agenda items + topic search + commitments + permanent knowledge + backfill.

    Returns list of MemoryRow. Tag is 'agenda', 'topic', 'commitment', 'permanent', or 'backfill'.
    """
    memories: list[MemoryRow] = []
    seen_ids: set[str] = set()

    cadence = get_mind_cadence(mind_id, db)
    current_year = cadence.get("year")
    current_quarter = cadence.get("quarter")

    def _row_to_memory(r, tag: str, is_completed: bool = False) -> MemoryRow:
        return MemoryRow(
            id=str(r[0]), content=r[1], summary=r[2],
            memory_type=r[3], created_at=r[4],
            tag=tag, embedding=r[5],
            quarter_year=r[6], quarter=r[7], sprint=r[8],
            is_completed=is_completed,
        )

    # --- Step 1: Agenda items (all memories tagged 'agenda') ---
    agenda_rows = db.fetch_all(
        "SELECT id, content, summary, memory_type, created_at, embedding, "
        "quarter_year, quarter, sprint "
        "FROM memories "
        "WHERE mind_id = %s AND is_current = true AND 'agenda' = ANY(tags) "
        "ORDER BY created_at DESC",
        [mind_id],
    )
    for r in agenda_rows:
        rid = str(r[0])
        if rid not in seen_ids:
            seen_ids.add(rid)
            memories.append(_row_to_memory(r, "agenda"))

    # --- Step 2: Topic-driven semantic search ---
    if topics:
        for topic_text in topics[:5]:  # max 5 topics to limit embedding calls
            topic_emb = get_embedding(topic_text, config)
            if topic_emb is None:
                continue
            emb_str = "[" + ",".join(str(x) for x in topic_emb) + "]"
            rows = db.fetch_all(
                "SELECT id, content, summary, memory_type, created_at, embedding, "
                "quarter_year, quarter, sprint, "
                "1 - (embedding <=> %s::vector) as similarity "
                "FROM memories "
                "WHERE mind_id = %s AND is_current = true "
                "AND embedding IS NOT NULL "
                "AND 1 - (embedding <=> %s::vector) > %s "
                "ORDER BY similarity DESC LIMIT 5",
                [emb_str, mind_id, emb_str, SIMILARITY_THRESHOLD],
            )
            for r in rows:
                rid = str(r[0])
                if rid not in seen_ids:
                    seen_ids.add(rid)
                    memories.append(_row_to_memory(r, "topic"))

    # --- Step 3: Recent commitments (current + previous quarter) ---
    from coppermind_cmo.tools.memories import _has_is_completed
    has_completed_col = _has_is_completed(db)
    commitment_cols = (
        "SELECT id, content, summary, memory_type, created_at, embedding, "
        "quarter_year, quarter, sprint"
        + (", is_completed " if has_completed_col else " ")
    )
    if current_year is not None and current_quarter is not None:
        prev_quarter = current_quarter - 1 if current_quarter > 1 else 4
        prev_year = current_year if current_quarter > 1 else current_year - 1
        commitment_rows = db.fetch_all(
            commitment_cols +
            "FROM memories "
            "WHERE mind_id = %s AND is_current = true "
            "AND memory_type = 'commitment' "
            "AND ((quarter_year = %s AND quarter = %s) OR (quarter_year = %s AND quarter = %s)) "
            "ORDER BY created_at DESC LIMIT 10",
            [mind_id, current_year, current_quarter, prev_year, prev_quarter],
        )
    else:
        # No cadence set -- fall back to most recent commitments
        commitment_rows = db.fetch_all(
            commitment_cols +
            "FROM memories "
            "WHERE mind_id = %s AND is_current = true AND memory_type = 'commitment' "
            "ORDER BY created_at DESC LIMIT 10",
            [mind_id],
        )
    for r in commitment_rows:
        rid = str(r[0])
        if rid not in seen_ids:
            seen_ids.add(rid)
            is_completed = bool(r[9]) if has_completed_col and len(r) > 9 else False
            memories.append(_row_to_memory(r, "commitment", is_completed=is_completed))

    # --- Step 3.5: Recent unresolved questions ---
    question_rows = db.fetch_all(
        "SELECT id, content, summary, memory_type, created_at, embedding, "
        "quarter_year, quarter, sprint "
        "FROM memories "
        "WHERE mind_id = %s AND is_current = true "
        "AND memory_type = 'question' "
        "ORDER BY created_at DESC LIMIT 5",
        [mind_id],
    )
    for r in question_rows:
        rid = str(r[0])
        if rid not in seen_ids:
            seen_ids.add(rid)
            memories.append(_row_to_memory(r, "question"))

    # --- Step 4: Permanent knowledge (stakeholder, preference, fact) ---
    permanent_rows = db.fetch_all(
        "SELECT id, content, summary, memory_type, created_at, embedding, "
        "quarter_year, quarter, sprint "
        "FROM memories "
        "WHERE mind_id = %s AND is_current = true "
        "AND memory_type IN ('stakeholder', 'preference', 'fact') "
        "ORDER BY created_at DESC LIMIT 15",
        [mind_id],
    )
    for r in permanent_rows:
        rid = str(r[0])
        if rid not in seen_ids:
            seen_ids.add(rid)
            memories.append(_row_to_memory(r, "permanent"))

    # --- Step 5: Type-balanced backfill ---
    remaining = limit - len(memories)
    if remaining > 0:
        exclude_list = list(seen_ids)
        backfill = db.fetch_all(
            "SELECT id, content, summary, memory_type, created_at, embedding, "
            "quarter_year, quarter, sprint "
            "FROM memories "
            "WHERE mind_id = %s AND is_current = true AND id != ALL(%s::uuid[]) "
            "ORDER BY created_at DESC LIMIT %s",
            [mind_id, exclude_list, remaining],
        )
        for r in backfill:
            memories.append(_row_to_memory(r, "backfill"))

    # --- Step 6: Apply quarter weighting to temporal memories ---
    if current_year is not None and current_quarter is not None:
        weighted: list[tuple[float, MemoryRow]] = []
        for m in memories:
            if m.tag == "agenda":
                weight = 1.0  # agenda items always top priority
            elif m.memory_type in PERMANENT_TYPES:
                weight = 1.0  # permanent knowledge never decays
            else:
                weight = _quarter_weight(m.quarter_year, m.quarter, current_year, current_quarter)

            weighted.append((weight, m))

        # Sort: agenda first, then by weight descending, then by created_at descending
        weighted.sort(key=lambda x: (
            x[1].tag == "agenda",  # agenda items first (True > False)
            x[0],                  # weight
            x[1].created_at.timestamp() if x[1].created_at and hasattr(x[1].created_at, 'timestamp') else 0,
        ), reverse=True)

        memories = [m for _, m in weighted]

    return memories


def _rerank_by_topic(
    memories: list[MemoryRow],
    topic: str,
    config: Config,
) -> list[MemoryRow]:
    """Re-rank memories by blended recency + topic similarity score.

    Per spec: 0.6 * recency_score + 0.4 * cosine_similarity.
    Type-balanced memories are preserved in order; only fill slots are re-ranked.
    Uses stored embedding vectors from DB -- only calls get_embedding once for the topic.
    """
    topic_embedding = get_embedding(topic, config)
    if topic_embedding is None:
        logger.warn("Embedding service unreachable for topic re-ranking, using recency only")
        return memories

    # Separate type-balanced from fill
    type_balanced = [m for m in memories if m.tag == "type_balanced"]
    fill = [m for m in memories if m.tag == "fill"]

    if not fill:
        return memories

    # Compute recency scores for fill memories
    timestamps = []
    for m in fill:
        if m.created_at is not None and hasattr(m.created_at, 'timestamp'):
            timestamps.append(m.created_at.timestamp())
        else:
            timestamps.append(0.0)

    # timestamps is always non-empty here (fill is non-empty, checked above)
    min_ts = min(timestamps)
    max_ts = max(timestamps)
    ts_range = max_ts - min_ts if max_ts != min_ts else 1.0

    # Score and sort fill memories using stored embeddings
    scored_fill = []
    for i, m in enumerate(fill):
        recency = (timestamps[i] - min_ts) / ts_range if ts_range > 0 else 1.0

        # Use stored embedding from DB
        mem_embedding = None
        if m.embedding is not None:
            mem_embedding = json.loads(m.embedding) if isinstance(m.embedding, str) else m.embedding

        if mem_embedding is not None and topic_embedding is not None:
            dot = sum(a * b for a, b in zip(topic_embedding, mem_embedding))
            norm_a = sum(a * a for a in topic_embedding) ** 0.5
            norm_b = sum(b * b for b in mem_embedding) ** 0.5
            similarity = dot / (norm_a * norm_b) if norm_a > 0 and norm_b > 0 else 0.0
        else:
            similarity = 0.0

        blended = RECENCY_WEIGHT * recency + SIMILARITY_WEIGHT * similarity
        scored_fill.append((blended, m))

    scored_fill.sort(key=lambda x: x[0], reverse=True)
    return type_balanced + [m for _, m in scored_fill]


def _build_structured_brief(
    memories: list[MemoryRow],
    brand_dna: dict,
    mind_name: str,
    cadence: dict | None = None,
    company_info: dict | None = None,
) -> str:
    """Build a structured brief from memories and brand DNA for Claude Code to polish."""
    lines = [f"# Meeting Brief: {mind_name}", ""]

    # Position header
    if cadence and cadence.get("type") == "eos":
        pos = f"**EOS Position:** {cadence.get('year', '?')} Q{cadence.get('quarter', '?')}"
        if cadence.get("sprint") is not None and cadence.get("sprints_per_quarter") is not None:
            pos += f", Sprint {cadence['sprint']} of {cadence['sprints_per_quarter']}"
        lines.append(pos)
        lines.append("")

    # Group memories by type, storing (summary, is_completed) tuples
    by_type: dict[str, list[tuple[str, bool]]] = {}
    for m in memories:
        summary = m.summary or (m.content[:150] if m.content else "")
        if m.memory_type not in by_type:
            by_type[m.memory_type] = []
        is_completed = getattr(m, "is_completed", False)
        by_type[m.memory_type].append((summary, is_completed))

    # Section order validated by 7-CMO beta tester survey:
    # 1. Last meeting takeaways  2. Action items
    # 3. Client priorities/concerns  4. Campaign snapshot
    # 5. Unresolved questions  6. Stakeholders  7. Key context

    # 1. Last Meeting Takeaways (decisions)
    if "decision" in by_type:
        lines.append("## Last Meeting Takeaways")
        for summary, _ in by_type["decision"]:
            lines.append(f"- {summary}")
        lines.append("")

    # 2. Action Items (commitments — open first, then completed)
    if "commitment" in by_type:
        lines.append("## Action Items")
        items = sorted(by_type["commitment"], key=lambda x: x[1])
        for summary, is_completed in items:
            checkbox = "[x]" if is_completed else "[ ]"
            lines.append(f"- {checkbox} {summary}")
        lines.append("")

    # 3. Client Pulse (preferences = priorities and concerns)
    if "preference" in by_type:
        lines.append("## Client Pulse")
        for summary, _ in by_type["preference"]:
            lines.append(f"- {summary}")
        lines.append("")

    # 4. Campaign Snapshot (campaign outcomes)
    if "campaign_outcome" in by_type:
        lines.append("## Campaign Snapshot")
        for summary, _ in by_type["campaign_outcome"]:
            lines.append(f"- {summary}")
        lines.append("")

    # 5. Unresolved Questions
    if "question" in by_type:
        lines.append("## Unresolved Questions")
        for summary, _ in by_type["question"]:
            lines.append(f"- {summary}")
        lines.append("")

    # 6. Key Stakeholders from brand DNA
    stakeholders = brand_dna.get("stakeholders", [])
    if stakeholders:
        lines.append("## Key Stakeholders")
        for s in stakeholders:
            name = s.get("name", "Unknown")
            title = s.get("title", "")
            role = s.get("role", "")
            entry = f"- **{name}**"
            if title:
                entry += f", {title}"
            if role:
                entry += f" ({role})"
            lines.append(entry)
        lines.append("")

    # 7. Key Context (facts)
    if "fact" in by_type:
        lines.append("## Key Context")
        for summary, _ in by_type["fact"]:
            lines.append(f"- {summary}")
        lines.append("")

    # Stakeholder memories (different from brand DNA stakeholders)
    if "stakeholder" in by_type:
        lines.append("## Stakeholder Notes")
        for summary, _ in by_type["stakeholder"]:
            lines.append(f"- {summary}")
        lines.append("")

    if not by_type:
        lines.append("*No memories available for this client.*")
        lines.append("")

    lines.append("---")

    return "\n".join(lines)


def _prep_meeting(
    topics: list[str] | None,
    meeting_type: str | None,
    limit: int,
    db: Database,
    config: Config,
    active_mind: tuple[str, str] | None,
    save: bool = False,
) -> dict[str, Any]:
    if active_mind is None:
        return NO_ACTIVE_MIND()

    mind_id, mind_name = active_mind
    limit = min(max(1, limit), MAX_LIMIT)

    # Validate meeting_type if provided
    valid_meeting_types = {"review", "catchup", "planning", "topic"}
    if meeting_type and meeting_type not in valid_meeting_types:
        return tool_error("INVALID_INPUT", f"meeting_type must be one of: {', '.join(valid_meeting_types)}")

    # Fetch cadence and company info
    context_row = db.fetch_one(
        "SELECT name, brand_voice, brand_positioning, approved_messaging, "
        "stakeholders, content_themes, cadence, company_info "
        "FROM client_minds WHERE id = %s",
        [mind_id],
    )
    if not context_row:
        return tool_error("INTERNAL_ERROR", "Active mind not found in database")

    brand_dna = {
        "brand_voice": parse_jsonb(context_row[1]),
        "brand_positioning": parse_jsonb(context_row[2]),
        "approved_messaging": parse_jsonb(context_row[3]),
        "stakeholders": parse_jsonb(context_row[4]) if context_row[4] else [],
        "content_themes": context_row[5] if context_row[5] else [],
    }
    cadence = parse_jsonb(context_row[6]) if context_row[6] else {}
    company_info = parse_jsonb(context_row[7]) if context_row[7] else {}

    # Smart retrieval (replaces type-balanced for prep_meeting)
    memories = _collect_meeting_memories(mind_id, topics, limit, db, config)

    # Group memories by type for structured return
    memories_by_type: dict[str, list] = {}
    for m in memories:
        if m.memory_type not in memories_by_type:
            memories_by_type[m.memory_type] = []
        entry = {
            "summary": m.summary or (m.content[:150] if m.content else ""),
            "created_at": m.created_at.isoformat() if m.created_at else None,
        }
        if m.memory_type == "commitment":
            entry["is_completed"] = getattr(m, "is_completed", False)
        memories_by_type[m.memory_type].append(entry)

    # Update last_accessed_at
    if memories:
        touch_memories(db, [m.id for m in memories])

    base_response = {
        "client_name": mind_name,
        "memories_by_type": memories_by_type,
        "stakeholders": brand_dna["stakeholders"],
        "brand_voice": brand_dna["brand_voice"],
        "memory_count": len(memories),
        "cadence": cadence,
    }

    if len(memories) < MIN_MEMORIES_FOR_SYNTHESIS:
        raw_response = {
            **base_response,
            "mode": "raw",
            "reason": "insufficient_data",
            "brief_markdown": None,
            "message": f"Only {len(memories)} memories found (minimum {MIN_MEMORIES_FOR_SYNTHESIS} needed for synthesis). "
                       "Store more memories to enable meeting briefs.",
        }
        if save:
            raw_response["saved"] = False
        return raw_response

    # Build structured brief -- Claude Code writes the polished version
    structured_brief = _build_structured_brief(
        memories, brand_dna, mind_name, cadence=cadence, company_info=company_info,
    )

    response = {
        **base_response,
        "mode": "structured",
        "reason": None,
        "brief_markdown": structured_brief,
    }

    if save:
        row = db.execute_returning(
            "INSERT INTO meeting_briefs (mind_id, brief_markdown, meeting_type, topics, memory_count) "
            "VALUES (%s, %s, %s, %s, %s) RETURNING id",
            [mind_id, structured_brief, meeting_type, topics or [], len(memories)],
        )
        if row:
            response["brief_id"] = str(row[0])
            response["saved"] = True
            logger.info("Saved meeting brief", mind_id=mind_id, brief_id=str(row[0]))
        else:
            response["saved"] = False
            logger.error("Failed to save meeting brief", mind_id=mind_id)

    return response


def _get_last_brief(
    db: Database,
    active_mind: tuple[str, str] | None,
) -> dict[str, Any]:
    if active_mind is None:
        return NO_ACTIVE_MIND()

    mind_id, mind_name = active_mind

    row = db.fetch_one(
        "SELECT id, brief_markdown, meeting_type, topics, memory_count, created_at "
        "FROM meeting_briefs "
        "WHERE mind_id = %s "
        "ORDER BY created_at DESC LIMIT 1",
        [mind_id],
    )

    if not row:
        return {
            "client_name": mind_name,
            "brief_markdown": None,
            "message": "No saved briefs found. Use prep_meeting with save=true to save a brief.",
        }

    result = {
        "brief_id": str(row[0]),
        "client_name": mind_name,
        "brief_markdown": row[1],
        "meeting_type": row[2],
        "topics": row[3] if row[3] else [],
        "memory_count": row[4],
        "created_at": row[5].isoformat() if row[5] else None,
    }

    if row[5] is not None:
        from datetime import timezone
        age_days = (datetime.now(timezone.utc) - row[5]).days
        if age_days > 7:
            result["age_warning"] = (
                f"This brief is {age_days} days old. "
                "Run prep_meeting with save=true for a fresh brief."
            )

    return result


def register(mcp_server):
    """Register intelligence tools on the MCP server."""
    from coppermind_cmo.server import get_db, get_config, get_active_mind, set_last_tool_call, get_customer_id
    from coppermind_cmo.background import attach_notifications
    from coppermind_cmo.tools.minds import _verify_mind_access
    from coppermind_cmo.errors import ACCESS_DENIED

    @mcp_server.tool()
    def prep_meeting(
        topics: list[str] | None = None,
        meeting_type: str | None = None,
        limit: int = 50,
        save: bool = False,
    ) -> dict:
        """Retrieve structured client data for meeting prep. You write the polished brief.

        For best results, provide topics and meeting_type. If not specified,
        all client memories are returned unfiltered.

        You receive structured data (memories by type, stakeholders, brand voice, cadence).
        Write a polished, conversational brief from it.

        Parameters:
        - topics: List of discussion topics (recommended for best results)
        - meeting_type: review, catchup, planning, or topic (optional)
        - limit: Maximum memories to consider, default 50 (optional)
        - save: If true, persist the brief for later retrieval via get_last_brief (default false)
        """
        set_last_tool_call("prep_meeting")
        active_mind = get_active_mind()
        if active_mind and not _verify_mind_access(active_mind[0], get_customer_id(), get_db()):
            return ACCESS_DENIED()
        result = _prep_meeting(topics, meeting_type, limit, get_db(), get_config(), active_mind, save=save)
        return attach_notifications(result)

    @mcp_server.tool()
    def get_campaign_history(limit: int = 10, offset: int = 0) -> list | dict:
        """Review campaign results and learnings for the active client."""
        set_last_tool_call("get_campaign_history")
        active_mind = get_active_mind()
        if active_mind and not _verify_mind_access(active_mind[0], get_customer_id(), get_db()):
            return ACCESS_DENIED()
        return _get_campaign_history(limit, offset, get_db(), active_mind)

    @mcp_server.tool()
    def get_last_brief() -> dict:
        """Retrieve the most recently saved meeting brief for the active client."""
        set_last_tool_call("get_last_brief")
        active_mind = get_active_mind()
        if active_mind and not _verify_mind_access(active_mind[0], get_customer_id(), get_db()):
            return ACCESS_DENIED()
        result = _get_last_brief(get_db(), active_mind)
        return attach_notifications(result)
