"""Session auto-parser daemon for Coppermind CMO.

Watches Claude Code JSONL conversation logs and extracts memories
automatically, attributed via switch_client markers.

Usage: python -m coppermind_cmo.watch
"""

from __future__ import annotations

import json
from typing import Any

from coppermind_cmo.log import ToolLogger

logger = ToolLogger("watcher")


def parse_session_segments(lines: list[str]) -> list[dict]:
    """Parse JSONL lines into client-attributed conversation segments.

    Scans for switch_client tool calls. Each segment contains messages
    between consecutive switches. Messages before the first switch are skipped.

    Returns list of {client_name: str, messages: list[str]}.
    """
    segments: list[dict] = []
    current_client: str | None = None
    current_messages: list[str] = []

    for line in lines:
        line = line.strip()
        if not line:
            continue
        try:
            obj = json.loads(line)
        except json.JSONDecodeError:
            continue

        msg = obj.get("message", {})
        content_blocks = msg.get("content", [])
        if isinstance(content_blocks, str):
            content_blocks = [{"type": "text", "text": content_blocks}]

        # Check for switch_client tool call
        for block in content_blocks:
            if (
                block.get("type") == "tool_use"
                and block.get("name") == "switch_client"
            ):
                # Save previous segment
                if current_client and current_messages:
                    segments.append({
                        "client_name": current_client,
                        "messages": current_messages,
                    })
                current_client = block.get("input", {}).get("client_name", "")
                current_messages = []
                break
        else:
            # Not a switch -- collect text content
            if current_client is not None:
                for block in content_blocks:
                    if block.get("type") == "text" and block.get("text", "").strip():
                        current_messages.append(block["text"])

    # Don't forget the last segment
    if current_client and current_messages:
        segments.append({
            "client_name": current_client,
            "messages": current_messages,
        })

    return segments


import os
import sys
import time
import glob

from coppermind_cmo.config import Config
from coppermind_cmo.db import Database
from coppermind_cmo.ingest import IngestEngine

# Maximum retries for a failing segment before skipping it
_MAX_SEGMENT_RETRIES = 3


def _encode_project_path(path: str) -> str:
    """Encode a filesystem path the way Claude Code does for project directories.

    Claude Code replaces path separators with ``-``.  For example
    ``/Volumes/Development/coppermind-cmo`` becomes
    ``-Volumes-Development-coppermind-cmo``.
    """
    path = os.path.realpath(path).rstrip("/").rstrip("\\")
    return path.replace("/", "-").replace("\\", "-")


def _build_allowed_prefixes(project_paths: list[str] | None = None) -> set[str]:
    """Build the set of encoded project-directory prefixes the watcher may scan.

    Resolution order:
    1. Explicit *project_paths* argument
    2. ``COPPERMIND_WATCH_PATHS`` env var (colon-separated filesystem paths)
    3. ``COPPERMIND_PROJECT_ROOT`` env var (single path)
    4. Current working directory

    Returns an empty set only if every source above is missing — callers
    should treat an empty set as "watch nothing" (fail closed).
    """
    paths: list[str] = []

    if project_paths:
        paths = list(project_paths)
    else:
        env_paths = os.environ.get("COPPERMIND_WATCH_PATHS", "")
        if env_paths:
            paths = [p.strip() for p in env_paths.split(":") if p.strip()]
        else:
            root = os.environ.get("COPPERMIND_PROJECT_ROOT", "")
            if root:
                paths = [root]
            else:
                cwd = os.getcwd()
                if cwd and cwd != "/":
                    paths = [cwd]

    return {_encode_project_path(p) for p in paths if p}


class SessionWatcher:
    """Watches Claude Code JSONL files and extracts memories."""

    def __init__(
        self,
        db: Database,
        config: Config,
        watch_dir: str | None = None,
        customer_id: str | None = None,
        project_paths: list[str] | None = None,
    ):
        self.db = db
        self.config = config
        self.customer_id = customer_id
        if watch_dir:
            self.watch_dir = watch_dir
        elif sys.platform == "win32":
            self.watch_dir = os.path.join(os.environ.get("APPDATA", os.path.expanduser("~")), "Claude", "projects")
        else:
            self.watch_dir = os.path.expanduser("~/.claude/projects")

        self._allowed_prefixes = _build_allowed_prefixes(project_paths)
        if self._allowed_prefixes:
            logger.info(
                "Session watcher scoped to project prefixes",
                prefixes=sorted(self._allowed_prefixes),
            )
        else:
            logger.warn(
                "No project paths configured — session watcher will not scan any files. "
                "Set COPPERMIND_WATCH_PATHS or COPPERMIND_PROJECT_ROOT to enable.",
            )

        self._offsets: dict[str, int] = {}  # in-memory cache
        self._segment_retries: dict[str, int] = {}  # track retries per segment key
        self._load_offsets_from_db()

    def _load_offsets_from_db(self):
        """Load persisted offsets from ingest_sources on startup."""
        try:
            rows = self.db.fetch_all(
                "SELECT config->>'source_ref', (config->>'last_offset')::int "
                "FROM ingest_sources WHERE source_type = 'session_extract' "
                "AND config->>'last_offset' IS NOT NULL",
                [],
            )
            for row in (rows or []):
                self._offsets[row[0]] = row[1]
        except Exception as e:
            logger.warn(f"Could not load offsets from DB: {e}")

    def _get_offset(self, file_path: str) -> int:
        return self._offsets.get(file_path, 0)

    def _set_offset(self, file_path: str, offset: int):
        """Update offset in memory and persist to DB."""
        self._offsets[file_path] = offset
        try:
            self.db.execute(
                "UPDATE ingest_sources SET config = config || %s "
                "WHERE source_type = 'session_extract' AND config->>'source_ref' = %s",
                [json.dumps({"last_offset": offset}), file_path],
            )
        except Exception as e:
            logger.warn(f"Could not persist offset to DB: {e}")

    def _resolve_mind(self, client_name: str, customer_id: str | None = None) -> tuple[str, str] | None:
        """Look up a client mind by name. Returns (mind_id, name) or None.

        When customer_id is provided, the query is scoped to that customer
        to prevent cross-tenant data access (Issue 13).
        """
        cid = customer_id or self.customer_id
        if cid:
            row = self.db.fetch_one(
                "SELECT id, name FROM client_minds "
                "WHERE lower(name) = lower(%s) AND archived_at IS NULL "
                "AND customer_id = %s",
                [client_name, cid],
            )
        else:
            # In hosted mode (api_key set), an unscoped query is a security
            # risk — refuse to resolve rather than leak cross-tenant data.
            if self.config.api_key:
                logger.error(
                    "Watcher running in hosted mode without customer_id -- "
                    "refusing unscoped mind resolution",
                    client_name=client_name,
                )
                return None
            logger.warn(
                "Watcher has no customer_id -- mind resolution is unscoped",
                client_name=client_name,
            )
            row = self.db.fetch_one(
                "SELECT id, name FROM client_minds "
                "WHERE lower(name) = lower(%s) AND archived_at IS NULL",
                [client_name],
            )
        if row:
            return (str(row[0]), row[1])
        return None

    def process_file(self, file_path: str):
        """Process new content in a JSONL file since last offset.

        Advances the offset per-segment so that a failure in one segment
        does not cause already-processed segments to replay (Issue 9).
        Segments that fail repeatedly (>_MAX_SEGMENT_RETRIES) are skipped.
        """
        offset = self._get_offset(file_path)
        try:
            with open(file_path, "r") as f:
                f.seek(offset)
                new_content = f.read()
                new_offset = f.tell()
        except (IOError, OSError) as e:
            logger.warn(f"Cannot read {file_path}: {e}")
            return

        if not new_content.strip():
            return

        lines = new_content.strip().split("\n")
        segments = parse_session_segments(lines)

        if not segments:
            # CRITICAL WARNING: If we found content but no switch_client markers,
            # the user likely forgot to use switch_client. All their conversation
            # data is being silently skipped. Warn loudly.
            if lines:
                logger.warn(
                    "Session file has content but NO switch_client markers -- "
                    "all data is being skipped. Use switch_client in your "
                    "conversations to enable auto-extraction.",
                    file=file_path, line_count=len(lines),
                )
            self._set_offset(file_path, new_offset)
            return

        for segment in segments:
            segment_key = f"{file_path}:{segment['client_name']}:{offset}"

            mind = self._resolve_mind(segment["client_name"])
            if mind is None:
                logger.info(
                    f"Skipping segment for unknown client: {segment['client_name']}"
                )
                continue

            try:
                engine = IngestEngine(self.db, self.config, mind, auto_ingest=True)
                combined_text = "\n\n".join(segment["messages"])
                result = engine.process_source(
                    source_type="session_extract",
                    source_ref=file_path,
                    content=combined_text,
                )
                logger.info(
                    f"Processed session for {segment['client_name']}: "
                    f"{result['new']} new, {result['updated']} updated, {result['skipped']} skipped"
                )
                # Clear retry counter on success
                self._segment_retries.pop(segment_key, None)
            except Exception as e:
                retries = self._segment_retries.get(segment_key, 0) + 1
                self._segment_retries[segment_key] = retries
                if retries >= _MAX_SEGMENT_RETRIES:
                    logger.error(
                        f"Skipping segment after {retries} failures: {segment['client_name']}",
                        file=file_path,
                        error=str(e),
                    )
                    self._segment_retries.pop(segment_key, None)
                else:
                    logger.warn(
                        f"Segment processing failed (attempt {retries}/{_MAX_SEGMENT_RETRIES}): "
                        f"{segment['client_name']}",
                        file=file_path,
                        error=str(e),
                    )

        # Advance offset to end of new content -- per-segment offset tracking
        # ensures we don't replay the whole file, and the retry mechanism
        # handles individual segment failures.
        self._set_offset(file_path, new_offset)

    def _is_allowed_path(self, file_path: str) -> bool:
        """Check whether *file_path* belongs to an allowed project directory.

        The first path component relative to ``watch_dir`` is the encoded
        project path.  We accept it if it starts with any allowed prefix.
        An empty ``_allowed_prefixes`` set means nothing is allowed (fail closed).
        """
        if not self._allowed_prefixes:
            return False
        try:
            rel = os.path.relpath(file_path, self.watch_dir)
        except ValueError:
            # On Windows, relpath raises ValueError for paths on different drives
            return False
        project_dir = rel.split(os.sep)[0]
        for prefix in self._allowed_prefixes:
            if project_dir == prefix or project_dir.startswith(prefix + "-"):
                return True
        return False

    def scan_once(self):
        """Scan JSONL files in watch_dir for new content.

        Only files inside project directories matching the allowed prefixes
        are considered.  Files from unrelated Claude Code sessions are skipped.
        """
        pattern = os.path.join(self.watch_dir, "**", "*.jsonl")
        for file_path in glob.glob(pattern, recursive=True):
            if not self._is_allowed_path(file_path):
                continue
            try:
                file_size = os.path.getsize(file_path)
            except OSError:
                continue
            if file_size > self._get_offset(file_path):
                self.process_file(file_path)

    def run(self, poll_interval: int = 60):
        """Run the watcher loop, scanning every poll_interval seconds."""
        logger.info(f"Session watcher started, watching {self.watch_dir}")
        while True:
            try:
                self.scan_once()
            except Exception as e:
                logger.error(f"Watcher scan failed: {e}")
            time.sleep(poll_interval)


def main():
    """Entry point for the session watcher daemon."""
    import argparse
    import logging
    logging.basicConfig(
        level=logging.INFO,
        format="COPPERMIND-CMO: %(asctime)s %(name)s %(levelname)s %(message)s",
    )

    parser = argparse.ArgumentParser(description="Coppermind session watcher")
    parser.add_argument(
        "--status", action="store_true",
        help="Show watcher status (watched files, offsets, last processed) and exit",
    )
    parser.add_argument(
        "--scan-once", action="store_true",
        help="Process all files once and exit (useful for cron/debugging)",
    )
    parser.add_argument(
        "--interval", type=int, default=60,
        help="Poll interval in seconds (default: 60)",
    )
    args = parser.parse_args()

    config = Config()

    # Hosted mode: provision from gateway
    if config.api_key:
        from coppermind_cmo.server import _provision_from_gateway
        _provision_from_gateway(config)

    db = Database(config)

    # Verify DB connection
    try:
        db.fetch_one("SELECT 1")
    except Exception as e:
        logger.error(f"Cannot connect to database: {e}")
        raise SystemExit(1)

    watcher = SessionWatcher(db, config, customer_id=config.customer_id or None)

    if args.status:
        print(f"COPPERMIND-CMO: Watch directory: {watcher.watch_dir}")
        print(f"COPPERMIND-CMO: Tracked files: {len(watcher._offsets)}")
        for path, offset in sorted(watcher._offsets.items()):
            print(f"COPPERMIND-CMO:   {path}: offset {offset}")
        raise SystemExit(0)

    if args.scan_once:
        logger.info("Running single scan")
        watcher.scan_once()
        logger.info("Scan complete")
        raise SystemExit(0)

    logger.info("Starting session watcher daemon")
    watcher.run(poll_interval=args.interval)


if __name__ == "__main__":
    main()
