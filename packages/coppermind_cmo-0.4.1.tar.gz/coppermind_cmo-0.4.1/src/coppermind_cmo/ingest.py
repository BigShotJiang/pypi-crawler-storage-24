"""Shared ingestion engine for Coppermind CMO.

Handles: text chunking, LLM extraction, dedup via ingest_log,
reconsolidation via store_memory, and source tracking.
"""

from __future__ import annotations

import hashlib
import json
import re
from typing import Any

from coppermind_cmo.config import Config, get_server_config
from coppermind_cmo.db import Database
from coppermind_cmo.llm_client import call_llm, VALID_MEMORY_TYPES
from coppermind_cmo.log import ToolLogger

logger = ToolLogger("ingest")

MIN_CHUNK_CHARS = 10
SECONDS_PER_CHUNK = 3  # ~3 seconds per chunk (LLM extraction call)

# Default threshold for direct calls (user-initiated via /cm-connect)
MIN_CONFIDENCE = 0.3
# Higher threshold for auto-ingested content (session watcher) —
# unsupervised extraction needs stricter filtering
MIN_CONFIDENCE_AUTO = 0.6

# Sentence boundary pattern — split on ". ", "! ", "? " followed by uppercase or EOL
_SENTENCE_END = re.compile(r'(?<=[.!?])\s+(?=[A-Z]|\Z)')


def estimate_ingestion_time(text: str, chunk_size: int = 2000) -> dict:
    """Estimate ingestion time based on text length."""
    word_count = len(text.split())
    char_count = len(text)
    num_chunks = max(1, char_count // chunk_size)
    estimated_seconds = num_chunks * SECONDS_PER_CHUNK
    return {
        "word_count": word_count,
        "chunks": num_chunks,
        "estimated_seconds": estimated_seconds,
    }


class IngestProgress:
    """Tracks ingestion progress for UI feedback."""

    def __init__(self, total_chunks: int, estimate: dict):
        self.total_chunks = total_chunks
        self.completed_chunks = 0
        self.memories_found = 0
        self.by_type: dict[str, int] = {}
        self.estimate = estimate

    def update(self, chunk_num: int, new_memories: list[dict]):
        self.completed_chunks = chunk_num
        self.memories_found += len(new_memories)
        for m in new_memories:
            mt = m.get("memory_type", "fact")
            self.by_type[mt] = self.by_type.get(mt, 0) + 1

    @property
    def summary(self) -> str:
        parts = [f"Processed {self.completed_chunks}/{self.total_chunks} sections"]
        if self.memories_found:
            type_str = ", ".join(f"{v} {k}s" for k, v in sorted(self.by_type.items()))
            parts.append(f"Found {self.memories_found} memories so far ({type_str})")
        return ". ".join(parts)

    @property
    def as_dict(self) -> dict:
        return {
            "completed": self.completed_chunks,
            "total": self.total_chunks,
            "memories_found": self.memories_found,
            "by_type": dict(self.by_type),
        }



def chunk_text(
    text: str,
    chunk_size: int = 2000,
    overlap: int = 200,
) -> list[str]:
    """Split text into overlapping chunks, preferring sentence boundaries.

    Tries to break at the last sentence boundary before chunk_size.
    Falls back to hard split at chunk_size if no sentence boundary found.
    Skips chunks shorter than MIN_CHUNK_CHARS.
    """
    text = text.strip()
    if not text:
        return []
    if len(text) <= chunk_size:
        return [text]

    chunks = []
    start = 0
    while start < len(text):
        end = min(start + chunk_size, len(text))
        window = text[start:end]

        # If we're not at the end, try to break at sentence boundary
        if end < len(text):
            # Search for the last sentence boundary in the window
            matches = list(_SENTENCE_END.finditer(window))
            if matches:
                # Break after the last sentence that fits
                split_pos = matches[-1].start()
                if split_pos > chunk_size // 2:  # Don't split too early
                    window = text[start:start + split_pos]
                    end = start + split_pos

        chunk = window.strip()
        if len(chunk) >= MIN_CHUNK_CHARS:
            chunks.append(chunk)
        # Stop if we've reached the end of text
        if end >= len(text):
            break
        # Overlap from where we actually split, not the full chunk_size.
        # Use MIN_CHUNK_CHARS as minimum advance to avoid O(chunk_size)
        # near-duplicate chunks when sentence-split produces short chunks.
        start = max(start + MIN_CHUNK_CHARS, end - overlap)

    return chunks


# FALLBACK ONLY — the canonical extraction prompt lives in gateway/src/config.ts
# and is served to the client via the /v1/config endpoint. This local version is
# simpler and only used when the gateway is unreachable (offline/dev mode).
# See _build_extraction_prompt() below which prefers the server-served version.
_LOCAL_EXTRACTION_PROMPT = (
    "You are extracting structured knowledge from a conversation or document "
    "for a client named {client_name}.\n\n"
    "Read the text below and extract any of the following:\n"
    "- **decision**: A choice that was made (\"We're pausing LinkedIn ads through Q2\")\n"
    "- **commitment**: An action item someone committed to (\"Ben will send revised messaging by Friday\")\n"
    "- **preference**: A stated or implied preference (\"That's too corporate-sounding\")\n"
    "- **campaign_outcome**: Results or metrics from a campaign (\"Email open rate was 34%\")\n"
    "- **stakeholder**: New information about a key person (\"VP Sales departed\", \"Sarah owns the rebrand brief\")\n"
    "- **fact**: Any other noteworthy fact about the client or their business\n\n"
    "If the text contains no extractable knowledge, return an empty array.\n\n"
    "Return ONLY valid JSON in this format:\n"
    '[{{"content": "The extracted statement", "memory_type": "decision|commitment|preference|campaign_outcome|stakeholder|fact", "confidence": 0.0-1.0}}]\n\n'
    "Examples:\n\n"
    'Input: "So we\'ve decided to pause all LinkedIn advertising through Q2."\n'
    'Output: [{{"content": "Pausing all LinkedIn advertising through Q2, reallocating budget to content marketing per board direction.", "memory_type": "decision", "confidence": 0.95}}]\n\n'
    'Input: "If the board approves the new budget, we might consider pausing LinkedIn ads."\n'
    "Output: []\n"
    "(A hypothetical/conditional statement is not a decision.)\n\n"
    'Input: "Sarah thinks we should go casual. James disagrees."\n'
    'Output: [{{"content": "Sarah advocates for casual brand voice; James prefers professional. No decision reached.", "memory_type": "fact", "confidence": 0.75}}]\n'
    "(Disagreement without resolution is a fact, not a decision.)\n\n"
    "Text:\n<transcript>\n{chunk}\n</transcript>\n\n"
    "JSON:"
)

EXTRACTION_PROMPT = _LOCAL_EXTRACTION_PROMPT  # backward compat


def _build_extraction_prompt(client_name: str, chunk_text: str) -> str:
    """Build extraction prompt, preferring server-side template if available."""
    server_cfg = get_server_config()
    if server_cfg.fetched and server_cfg.prompts.get("extraction"):
        template = server_cfg.prompts["extraction"]
        import re
        safe_name = client_name.replace("$", "").strip()[:100]
        subs = {"$client_name$": safe_name, "$chunk_text$": chunk_text}
        pattern = "|".join(re.escape(k) for k in subs)
        return re.sub(pattern, lambda m: subs[m.group()], template)
    # Fallback: local hardcoded prompt
    return _LOCAL_EXTRACTION_PROMPT.format(chunk=chunk_text, client_name=client_name)


def extract_memories_from_chunk(
    chunk: str,
    config: Config,
    client_name: str = "the client",
    min_confidence: float = MIN_CONFIDENCE,
) -> list[dict] | None:
    """Extract structured memories from a text chunk via LLM.

    Returns list of {content, memory_type, confidence} dicts that pass quality gates.
    Returns None if the LLM is unavailable (distinct from [] meaning no memories found).
    Use min_confidence=MIN_CONFIDENCE_AUTO (0.6) for unsupervised auto-ingestion.
    """
    # Sanitize client_name to prevent prompt injection
    safe_name = client_name.replace("\n", " ").replace("\r", " ")[:100]
    # Sanitize chunk — escape closing XML tags to prevent prompt injection
    # from user-generated conversation content in JSONL logs
    safe_chunk = chunk.replace("</transcript>", "&lt;/transcript&gt;")
    prompt = _build_extraction_prompt(safe_name, safe_chunk)
    response = call_llm(prompt, config, use_synthesis_model=False)

    if response is None:
        return None

    # Robust JSON parsing — handle markdown fences, preamble text, bare objects
    text = response.strip()

    # Try 1: Find JSON array in response ([...])
    start_bracket = text.find("[")
    end_bracket = text.rfind("]")
    if start_bracket != -1 and end_bracket > start_bracket:
        try:
            items = json.loads(text[start_bracket:end_bracket + 1])
            if isinstance(items, list):
                pass  # success — fall through to quality gates
            else:
                items = None
        except json.JSONDecodeError:
            items = None
    else:
        items = None

    # Try 2: Find bare JSON object ({...}) — wrap in array
    if items is None:
        start_brace = text.find("{")
        end_brace = text.rfind("}")
        if start_brace != -1 and end_brace > start_brace:
            try:
                obj = json.loads(text[start_brace:end_brace + 1])
                items = [obj] if isinstance(obj, dict) else None
            except json.JSONDecodeError:
                items = None

    if items is None:
        logger.warn(f"Failed to parse LLM extraction response as JSON: {text[:200]}")
        return []

    if not isinstance(items, list):
        return []

    results = []
    for item in items:
        if not isinstance(item, dict):
            continue
        content = item.get("content", "").strip()
        memory_type = item.get("memory_type", "").strip().lower().replace(" ", "_")
        confidence = item.get("confidence", 0.0)

        # Quality gates
        if len(content) < MIN_CHUNK_CHARS:
            continue
        if memory_type not in VALID_MEMORY_TYPES:
            continue
        if confidence < min_confidence:
            continue

        results.append({
            "content": content,
            "memory_type": memory_type,
            "confidence": float(confidence),
        })

    return results


# Imported here (not at top) to avoid circular import with memories.py
from coppermind_cmo.tools.memories import store_memory_core

# Cached check for raw_documents table existence.
# Only True is cached permanently (table won't disappear). False is re-checked
# so that applying migration 011 mid-process takes effect without restart.
_has_raw_docs_table: bool | None = None


def _has_raw_documents_table(db: Database) -> bool:
    """Check if raw_documents table exists (migration 011). Only caches True."""
    global _has_raw_docs_table
    if _has_raw_docs_table is True:
        return True
    try:
        row = db.fetch_one(
            "SELECT 1 FROM information_schema.tables WHERE table_name = 'raw_documents'"
        )
        _has_raw_docs_table = row is not None
    except Exception:
        _has_raw_docs_table = False
    return _has_raw_docs_table


def _store_raw_document(
    text: str,
    mind_id: str,
    db: Database,
    source_type: str = "meeting",
    source_ref: str | None = None,
) -> str | None:
    """Store the full original document. Returns doc ID, or None if already stored or table missing."""
    if not _has_raw_documents_table(db):
        return None

    content_hash = hashlib.sha256(text.encode()).hexdigest()
    word_count = len(text.split())

    # Check if already stored (idempotent)
    existing = db.fetch_one(
        "SELECT id FROM raw_documents WHERE mind_id = %s AND content_hash = %s",
        [mind_id, content_hash],
    )
    if existing:
        logger.info("Raw document already stored (dedup)", mind_id=mind_id,
                     doc_id=str(existing[0]), content_hash=content_hash[:16])
        return str(existing[0])

    row = db.execute_returning(
        "INSERT INTO raw_documents (mind_id, content, content_hash, source_type, "
        "source_ref, word_count, extraction_passes) "
        "VALUES (%s, %s, %s, %s, %s, %s, 0) RETURNING id",
        [mind_id, text, content_hash, source_type, source_ref, word_count],
    )
    logger.info("Stored raw document", mind_id=mind_id, word_count=word_count)
    return str(row[0]) if row else None


class IngestEngine:
    """Shared ingestion engine: chunk -> dedup -> extract -> store.

    Uses structured JSON logging matching server.py patterns.
    """

    def __init__(
        self,
        db: Database,
        config: Config,
        active_mind: tuple[str, str],
        auto_ingest: bool = False,
        memory_source_type: str = "session_extract",
    ):
        self.db = db
        self.config = config
        self.active_mind = active_mind
        self.mind_id = active_mind[0]
        self.mind_name = active_mind[1]
        # auto_ingest=True raises confidence threshold to 0.6 (session watcher)
        self.min_confidence = MIN_CONFIDENCE_AUTO if auto_ingest else MIN_CONFIDENCE
        self.memory_source_type = memory_source_type

    def _get_or_create_source(self, source_type: str, source_ref: str) -> str:
        """Get or create an ingest_sources row. Returns source_id."""
        row = self.db.fetch_one(
            "SELECT id FROM ingest_sources "
            "WHERE mind_id = %s AND source_type = %s AND config->>'source_ref' = %s",
            [self.mind_id, source_type, source_ref],
        )
        if row:
            return str(row[0])

        row = self.db.execute_returning(
            "INSERT INTO ingest_sources (mind_id, source_type, config) "
            "VALUES (%s, %s, %s) RETURNING id",
            [self.mind_id, source_type, json.dumps({"source_ref": source_ref})],
        )
        return str(row[0])

    def _check_hash(self, content_hash: str) -> bool:
        """Check if a content hash already exists in ingest_log for this mind.

        Matches the ON CONFLICT (mind_id, content_hash) scope in _log_chunk —
        dedup is per-mind, not per-source, to avoid redundant LLM extraction
        when the same chunk appears in multiple sources.
        """
        row = self.db.fetch_one(
            "SELECT id FROM ingest_log "
            "WHERE mind_id = %s AND content_hash = %s",
            [self.mind_id, content_hash],
        )
        return row is not None

    def _log_chunk(
        self, source_id: str, content_hash: str, raw_content: str, memories_extracted: int,
    ):
        """Record a processed chunk in ingest_log."""
        self.db.execute(
            "INSERT INTO ingest_log (source_id, mind_id, raw_content, content_hash, "
            "processed, memories_extracted) "
            "VALUES (%s, %s, %s, %s, true, %s) "
            "ON CONFLICT (mind_id, content_hash) DO UPDATE SET "
            "processed = true, memories_extracted = %s, refreshed_at = now()",
            [source_id, self.mind_id, raw_content, content_hash,
             memories_extracted, memories_extracted],
        )

    def process_source(
        self,
        source_type: str,
        source_ref: str,
        content: str,
        refresh: bool = False,
        cancel_event: Any = None,
    ) -> dict[str, int]:
        """Process content from a source. Returns {new, updated, skipped, estimate}.

        If cancel_event (threading.Event) is provided and set, the chunk loop
        stops early and returns partial results.  Used by background ingestion
        for cooperative cancellation on timeout (Issue 7).
        """
        # Store full document for future re-extraction (non-fatal if it fails)
        try:
            doc_id = _store_raw_document(
                content, self.mind_id, self.db,
                source_type=source_type, source_ref=source_ref,
            )
        except Exception as e:
            logger.warn(f"Failed to store raw document, continuing extraction: {e}",
                        mind_id=self.mind_id)
            doc_id = None

        source_id = self._get_or_create_source(source_type, source_ref)
        chunks = chunk_text(content)
        estimate = estimate_ingestion_time(content)
        logger.info(
            "Processing source",
            mind_id=self.mind_id,
            source_type=source_type,
            source_ref=source_ref,
            chunk_count=len(chunks),
            refresh=refresh,
            min_confidence=self.min_confidence,
            estimated_seconds=estimate["estimated_seconds"],
        )

        progress = IngestProgress(total_chunks=len(chunks), estimate=estimate)

        counts: dict[str, int] = {"new": 0, "updated": 0, "skipped": 0}

        for chunk_num, chunk in enumerate(chunks, 1):
            # Cooperative cancellation -- check between chunks
            if cancel_event is not None and cancel_event.is_set():
                logger.info(
                    "Ingestion cancelled between chunks",
                    mind_id=self.mind_id,
                    source_ref=source_ref,
                    completed_chunks=chunk_num - 1,
                    total_chunks=len(chunks),
                )
                break

            content_hash = hashlib.sha256(chunk.encode()).hexdigest()

            # Dedup check (mind-scoped, not source-scoped)
            if not refresh and self._check_hash(content_hash):
                counts["skipped"] += 1
                continue

            # Extract memories from chunk (uses self.min_confidence)
            # Retry once with backoff on LLM failure (None = LLM unavailable)
            extracted = None
            for llm_attempt in range(2):
                extracted = extract_memories_from_chunk(
                    chunk, self.config,
                    client_name=self.mind_name,
                    min_confidence=self.min_confidence,
                )
                if extracted is not None:
                    break
                if llm_attempt == 0:
                    import time
                    time.sleep(2)

            # If LLM extraction failed (returned None/[]), don't log as processed —
            # allows retry on next run. Only log when extraction genuinely succeeded.
            if not extracted:
                counts["skipped"] += 1
                progress.update(chunk_num, [])
                continue

            # Update progress with extracted memories
            progress.update(chunk_num, extracted)

            # Store each extracted memory
            for mem in extracted:
                result = store_memory_core(
                    content=mem["content"],
                    memory_type=mem["memory_type"],
                    tags=[],
                    db=self.db,
                    config=self.config,
                    active_mind=self.active_mind,
                    source_type=self.memory_source_type,
                )
                if isinstance(result, dict) and result.get("reconsolidated"):
                    counts["updated"] += 1
                elif isinstance(result, dict) and "memory_id" in result:
                    counts["new"] += 1

            # Log the chunk as processed
            self._log_chunk(source_id, content_hash, chunk, len(extracted))

        # Mark extraction pass complete on raw document
        if doc_id and (counts["new"] > 0 or counts["updated"] > 0):
            self.db.execute(
                "UPDATE raw_documents SET extraction_passes = extraction_passes + 1, "
                "last_extracted_at = now() WHERE id = %s::uuid",
                [doc_id],
            )

        # Update source sync timestamp
        self.db.execute(
            "UPDATE ingest_sources SET last_synced_at = now() WHERE id = %s",
            [source_id],
        )

        logger.info(
            "Source processing complete",
            mind_id=self.mind_id,
            source_ref=source_ref,
            new_count=counts["new"],
            updated_count=counts["updated"],
            skipped_count=counts["skipped"],
        )

        counts["estimate"] = estimate
        counts["by_type"] = dict(progress.by_type)
        return counts
