"""Shared utility functions."""

import json
import os
from pathlib import Path
from typing import Any, TYPE_CHECKING

if TYPE_CHECKING:
    from coppermind_cmo.db import Database


def secure_write(path: Path, content: str) -> None:
    """Write content to *path* with 0600 permissions; ensure parent dir is 0700.

    Use this for any file under ~/.coppermind/ that may contain sensitive state
    (active client, background jobs, PID files, hook state, etc.).
    """
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        os.chmod(path.parent, 0o700)
    except OSError:
        pass
    path.write_text(content)
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass


def secure_mkdir(dir_path: Path) -> None:
    """Create directory with 0700 permissions."""
    dir_path = Path(dir_path)
    dir_path.mkdir(parents=True, exist_ok=True)
    try:
        os.chmod(dir_path, 0o700)
    except OSError:
        pass


def parse_jsonb(val) -> Any:
    """Parse jsonb value from DB — may be str, dict, or list."""
    if val is None:
        return {}
    if isinstance(val, str):
        try:
            return json.loads(val)
        except (json.JSONDecodeError, ValueError):
            return {}
    return val


def get_mind_cadence(mind_id: str, db: "Database") -> dict:
    """Fetch a mind's cadence JSONB. Returns {} if not set."""
    row = db.fetch_one(
        "SELECT cadence FROM client_minds WHERE id = %s",
        [mind_id],
    )
    if row and row[0]:
        return row[0] if isinstance(row[0], dict) else {}
    return {}


def touch_memories(db: "Database", ids: list[str]) -> None:
    """Update last_accessed_at for a list of memory UUIDs."""
    if not ids:
        return
    placeholders = ",".join(["%s::uuid"] * len(ids))
    db.execute(
        f"UPDATE memories SET last_accessed_at = now() WHERE id IN ({placeholders})",
        ids,
    )
