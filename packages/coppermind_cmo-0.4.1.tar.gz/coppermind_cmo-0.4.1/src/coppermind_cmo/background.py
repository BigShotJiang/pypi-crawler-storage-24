"""Background ingestion system for long transcripts.

Allows store_memory to return immediately with a time estimate while
processing happens in a background thread. Completed results are attached
as notifications to the next tool call response.
"""

from __future__ import annotations

import json as _json
import threading
import uuid as _uuid
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Callable

from coppermind_cmo.log import ToolLogger
from coppermind_cmo.utils import secure_write

logger = ToolLogger("background")

# Limit concurrent background ingestion jobs
_background_semaphore = threading.Semaphore(2)

# Wall-clock timeout for background ingestion (10 minutes)
BACKGROUND_TIMEOUT_SECONDS = 600

# Persistent job file for durability across restarts (Issue 8)
_JOBS_FILE = Path.home() / ".coppermind" / "background_jobs.json"


@dataclass
class BackgroundResult:
    """Result from a completed background ingestion."""

    task_id: str
    mind_name: str
    started_at: datetime
    session_id: str = ""
    completed_at: datetime | None = None
    memories_created: int = 0
    by_type: dict = field(default_factory=dict)
    error: str | None = None
    shown_to_user: bool = False


# Module-level storage for background results
_background_results: list[BackgroundResult] = []
_background_lock = threading.Lock()


def _get_session_id() -> str:
    """Get the current session ID from the server module (lazy import to avoid cycles)."""
    try:
        from coppermind_cmo.server import get_session_id
        return get_session_id()
    except Exception:
        return ""


# ---------------------------------------------------------------------------
# Durable job persistence (Issue 8)
# ---------------------------------------------------------------------------

def _persist_job(task_id: str, mind_name: str, status: str, error: str | None = None):
    """Write/update a job record to the persistent JSON file."""
    with _background_lock:
        try:
            jobs = _load_jobs_file()
            jobs[task_id] = {
                "task_id": task_id,
                "mind_name": mind_name,
                "status": status,
                "error": error,
                "updated_at": datetime.now().isoformat(),
            }
            secure_write(_JOBS_FILE, _json.dumps(jobs, indent=2))
        except Exception as e:
            logger.warn(f"Could not persist background job: {e}")


def _load_jobs_file() -> dict:
    """Load the jobs file. Returns empty dict on any error."""
    try:
        if _JOBS_FILE.exists():
            return _json.loads(_JOBS_FILE.read_text())
    except Exception:
        pass
    return {}


def recover_orphaned_jobs():
    """On startup, mark any 'in_progress' jobs as failed (server restarted).

    Call this once during server initialization.
    """
    with _background_lock:
        try:
            jobs = _load_jobs_file()
            changed = False
            for task_id, job in jobs.items():
                if job.get("status") == "in_progress":
                    job["status"] = "failed"
                    job["error"] = "Server restarted before job completed"
                    job["updated_at"] = datetime.now().isoformat()
                    changed = True
                    logger.warn(
                        "Marked orphaned background job as failed",
                        task_id=task_id,
                        mind_name=job.get("mind_name"),
                    )
            if changed:
                secure_write(_JOBS_FILE, _json.dumps(jobs, indent=2))
        except Exception as e:
            logger.warn(f"Could not recover orphaned jobs: {e}")


def attach_notifications(result: dict | list, session_id: str | None = None) -> dict | list:
    """Attach any pending background ingestion notifications to a dict result.

    Call this from any tool's registered function before returning.
    List results are returned unchanged (notifications only attach to dicts).
    """
    if isinstance(result, dict):
        sid = session_id or _get_session_id()
        notifications = get_completed_notifications(sid)
        if notifications:
            result["notifications"] = notifications
    return result


def _classify_ingest_error(exc: Exception, task_id: str) -> str:
    """Return a user-friendly error description with an actionable hint."""
    exc_type = type(exc).__name__.lower()
    exc_str = str(exc).lower()

    if "timeout" in exc_type or "timeout" in exc_str:
        return (
            "The AI service timed out while extracting memories. "
            "Try again with a shorter transcript (under 2,000 words works best), "
            "or paste it in sections."
        )

    if "httpstatuserror" in exc_type or "statuserror" in exc_type:
        if "401" in exc_str or "403" in exc_str:
            return (
                "Authentication failed with the AI service. "
                "Your API key may have expired -- restart Claude to refresh your connection."
            )
        if "429" in exc_str:
            return (
                "The AI service is rate-limited right now. "
                "Wait a minute and try again."
            )
        if any(c in exc_str for c in ("500", "502", "503", "504")):
            return (
                "The AI service returned a server error. "
                "Try again in a few minutes."
            )

    if "operationalerror" in exc_type or (
        "connection" in exc_str and "postgres" not in exc_str
    ):
        return (
            "Lost the database connection during processing -- usually temporary. "
            "Try again."
        )

    if "integrityerror" in exc_type or "checkviolation" in exc_type or "constraint" in exc_str:
        return (
            "A database validation error occurred. "
            "Try upgrading: pip install --upgrade coppermind-cmo"
        )

    return (
        f"An unexpected error occurred ({type(exc).__name__}). "
        f"Try again. If the problem persists, contact coppermind@volacci.com "
        f"with task ID: {task_id}"
    )


def start_background_ingestion(
    text: str,
    mind_id: str,
    mind_name: str,
    db_factory: Callable,
    config: Any,
    source_type: str = "meeting",
    source_ref: str | None = None,
    session_id: str | None = None,
) -> dict:
    """Start ingestion in a background thread. Returns immediately with estimate."""
    from coppermind_cmo.ingest import estimate_ingestion_time

    task_id = str(_uuid.uuid4())[:8]
    estimate = estimate_ingestion_time(text)
    sid = session_id or _get_session_id()

    # Cooperative cancellation event -- set on timeout so the ingestion loop
    # can check between chunks and stop early instead of consuming resources.
    cancel_event = threading.Event()

    def _do_ingest():
        """Actual ingestion work -- runs inside semaphore with cancellation support."""
        from coppermind_cmo.ingest import IngestEngine

        db = db_factory()
        engine = IngestEngine(
            db, config,
            active_mind=(mind_id, mind_name),
            memory_source_type="meeting",
        )
        ref = source_ref or f"background-{task_id}"
        return engine.process_source(
            source_type=source_type,
            source_ref=ref,
            content=text,
            cancel_event=cancel_event,
        )

    def _run():
        result = BackgroundResult(
            task_id=task_id,
            mind_name=mind_name,
            started_at=datetime.now(),
            session_id=sid,
        )
        # Persist job start for durability across restarts
        _persist_job(task_id, mind_name, "in_progress")

        acquired = _background_semaphore.acquire(timeout=30)
        if not acquired:
            result.error = (
                "Too many background ingestion jobs running. "
                "Wait for a current job to finish and try again."
            )
            result.completed_at = datetime.now()
            _persist_job(task_id, mind_name, "failed", result.error)
            with _background_lock:
                if len(_background_results) > 50:
                    _background_results[:] = _background_results[-50:]
                _background_results.append(result)
            return
        try:
            # Run ingestion in a worker thread with cooperative cancellation
            worker_result: dict = {}
            worker_error: list = []

            def _worker():
                try:
                    worker_result.update(_do_ingest())
                except Exception as e:
                    worker_error.append(e)

            worker = threading.Thread(target=_worker, daemon=True)
            worker.start()
            worker.join(timeout=BACKGROUND_TIMEOUT_SECONDS)

            if worker.is_alive():
                # Timeout -- signal cancellation and log
                cancel_event.set()
                logger.error(
                    "Background ingestion timed out -- cancellation signalled",
                    task_id=task_id,
                    mind_name=mind_name,
                )
                # Give worker a moment to notice the event and exit
                worker.join(timeout=5)
                result.error = (
                    "Background ingestion timed out after 10 minutes. "
                    "Try a shorter transcript (under 5,000 words)."
                )
                result.completed_at = datetime.now()
                _persist_job(task_id, mind_name, "failed", result.error)
                with _background_lock:
                    if len(_background_results) > 50:
                        _background_results[:] = _background_results[-50:]
                    _background_results.append(result)
                return

            if worker_error:
                raise worker_error[0]

            ingest_result = worker_result
            result.memories_created = ingest_result.get("new", 0) + ingest_result.get("updated", 0)
            result.by_type = ingest_result.get("by_type", {})
            result.completed_at = datetime.now()
            elapsed_ms = int((result.completed_at - result.started_at).total_seconds() * 1000)
            _persist_job(task_id, mind_name, "complete")
            logger.info(
                "Background ingestion complete",
                task_id=task_id,
                mind_name=mind_name,
                memories_created=result.memories_created,
                duration_ms=elapsed_ms,
            )
        except Exception as e:
            result.error = _classify_ingest_error(e, task_id)
            result.completed_at = datetime.now()
            elapsed_ms = int((result.completed_at - result.started_at).total_seconds() * 1000)
            _persist_job(task_id, mind_name, "failed", result.error)
            logger.error(
                "Background ingestion failed",
                task_id=task_id,
                mind_name=mind_name,
                error_type=type(e).__name__,
                error=str(e),
                duration_ms=elapsed_ms,
            )
        finally:
            _background_semaphore.release()

        with _background_lock:
            if len(_background_results) > 50:
                _background_results[:] = _background_results[-50:]
            _background_results.append(result)

    thread = threading.Thread(target=_run, daemon=True)
    thread.start()

    return {
        "status": "processing",
        "task_id": task_id,
        "estimate": estimate,
        "message": (
            f"Meeting saved. Extracting memories in the background "
            f"(~{estimate['word_count']} words, ~{estimate['estimated_seconds']}s). "
            "IMPORTANT: Do NOT run list_minds or check memory counts now -- the count "
            "will be wrong until extraction finishes. Tell the user their meeting was "
            "saved and you'll notify them automatically when memories are ready."
        ),
    }


def get_completed_notifications(session_id: str | None = None) -> list[dict]:
    """Get any completed background ingestion results not yet shown to the user.

    When session_id is provided, only returns results for that session.
    This prevents notifications from leaking across sessions (Issue 11).
    """
    with _background_lock:
        results = []
        for r in _background_results:
            if r.completed_at and not r.shown_to_user:
                # Filter by session if provided (empty string matches all for
                # backward compatibility with results created before session
                # tracking was added)
                if session_id and r.session_id and r.session_id != session_id:
                    continue
                r.shown_to_user = True
                if r.error:
                    results.append({
                        "type": "ingestion_error",
                        "mind_name": r.mind_name,
                        "error": r.error,
                        "message": (
                            f"Warning: Meeting ingestion failed for {r.mind_name}. "
                            f"{r.error} "
                            "IMPORTANT: Tell the user this NOW -- their meeting data was NOT saved."
                        ),
                    })
                else:
                    elapsed = int((r.completed_at - r.started_at).total_seconds())
                    type_str = (
                        ", ".join(f"{v} {k}s" for k, v in sorted(r.by_type.items()))
                        if r.by_type else ""
                    )
                    if r.memories_created == 0:
                        message = (
                            f"Warning: Transcript processed for {r.mind_name} but no memories were "
                            "extracted. The content may not contain clear decisions, commitments, "
                            "or facts -- or it may have been a duplicate. "
                            "IMPORTANT: Tell the user this now so they know ingestion ran but "
                            "found nothing to save."
                        )
                    else:
                        message = (
                            f"Done: Meeting saved -- {r.memories_created} new memories extracted "
                            f"for {r.mind_name}"
                            f"{' (' + type_str + ')' if type_str else ''}. "
                            "IMPORTANT: Tell the user this NOW before doing anything else."
                        )
                    results.append({
                        "type": "ingestion_complete",
                        "mind_name": r.mind_name,
                        "memories_created": r.memories_created,
                        "by_type": r.by_type,
                        "elapsed_seconds": elapsed,
                        "message": message,
                    })
        # Clean up: keep all in-progress/unshown items, cap shown history at 10
        _background_results[:] = (
            [r for r in _background_results if not r.shown_to_user]
            + [r for r in _background_results if r.shown_to_user][-10:]
        )
        return results
