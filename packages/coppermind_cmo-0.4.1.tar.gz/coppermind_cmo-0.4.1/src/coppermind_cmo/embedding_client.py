"""HTTP client for the embedding gateway.

Routes through the Coppermind gateway -> Voyage AI (512 dims).
Returns None on any failure -- callers handle degraded mode.
"""

from coppermind_cmo.config import Config
from coppermind_cmo.gateway_http import gateway_post, gateway_get
from coppermind_cmo.log import ToolLogger

logger = ToolLogger("embedding")


def _get_embedding_gateway(text: str, config: Config, timeout: float = 10) -> list[float] | None:
    """Get embedding from the Coppermind gateway -> Voyage AI."""
    data = gateway_post("embed", {"text": text}, config, timeout=timeout)
    if data is None:
        return None

    embedding = data.get("embedding")
    if not isinstance(embedding, list) or len(embedding) == 0:
        logger.warn("Invalid gateway embedding shape: expected non-empty list")
        return None
    if not all(isinstance(x, (int, float)) for x in embedding):
        logger.warn("Invalid gateway embedding: contains non-numeric elements")
        return None
    expected = data.get("dimensions", config.embedding_dims)
    if len(embedding) != expected:
        logger.warn(f"Gateway embedding dimension mismatch: got {len(embedding)}, expected {expected}")
        return None

    return embedding


def get_embedding(text: str, config: Config, timeout: float = 10) -> list[float] | None:
    """Get embedding vector for text via the gateway."""
    return _get_embedding_gateway(text, config, timeout)


def check_health(config: Config, timeout: float = 5) -> bool:
    """Check if the embedding gateway is healthy."""
    resp = gateway_get("health", config, timeout=timeout)
    if resp is not None:
        return resp.status_code == 200
    return False
