"""Shared HTTP client for the Coppermind gateway.

Both llm_client.py and embedding_client.py need to make authenticated
HTTP requests to the gateway with session tracking.  This module
consolidates the duplicated header-building and request logic.
"""

import httpx

from coppermind_cmo.config import Config
from coppermind_cmo.log import ToolLogger

logger = ToolLogger("gateway_http")


def gateway_headers(config: Config) -> dict:
    """Build headers for gateway requests including auth and session tracking."""
    from coppermind_cmo.server import get_session_id
    return {
        "Authorization": f"Bearer {config.api_key}",
        "X-Session-Id": get_session_id(),
    }


def gateway_post(
    endpoint: str,
    body: dict,
    config: Config,
    timeout: float = 30,
) -> dict | None:
    """POST to a gateway endpoint. Returns parsed JSON or None on failure.

    Args:
        endpoint: Path segment after /v1/ (e.g. "embed", "synthesize", "classify").
        body: JSON request body.
        config: Server config with gateway_url and api_key.
        timeout: Request timeout in seconds.
    """
    url = f"{config.gateway_url.rstrip('/')}/v1/{endpoint}"
    try:
        resp = httpx.post(
            url,
            json=body,
            headers=gateway_headers(config),
            timeout=timeout,
        )
        resp.raise_for_status()
        return resp.json()
    except Exception as e:
        logger.warn(f"Gateway request failed ({endpoint}): {e}")
        return None


def gateway_get(
    endpoint: str,
    config: Config,
    timeout: float = 5,
) -> httpx.Response | None:
    """GET from a gateway endpoint. Returns the raw Response or None on failure."""
    url = f"{config.gateway_url.rstrip('/')}/v1/{endpoint}"
    try:
        resp = httpx.get(
            url,
            headers=gateway_headers(config),
            timeout=timeout,
        )
        return resp
    except Exception:
        return None
