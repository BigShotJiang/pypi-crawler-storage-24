"""Structured JSON logging to stderr per SERVER_SPEC.md."""

import json
import sys
from datetime import datetime, timezone


class ToolLogger:
    """Emits structured JSON log entries to stderr."""

    def __init__(self, tool: str):
        self._tool = tool

    def _emit(self, level: str, message: str, *, mind_id: str | None = None,
              duration_ms: float | None = None, **extra):
        entry = {"timestamp": datetime.now(timezone.utc).isoformat()}
        entry.update(extra)
        entry["level"] = level
        entry["tool"] = self._tool
        entry["message"] = message
        entry["mind_id"] = mind_id
        entry["duration_ms"] = duration_ms
        print("COPPERMIND-CMO: " + json.dumps(entry), file=sys.stderr, flush=True)

    # Reserved field names that callers must not override via extra kwargs.
    _RESERVED = frozenset({"timestamp", "level", "tool", "message", "mind_id", "duration_ms"})

    def _sanitize_extra(self, kwargs: dict) -> dict:
        """Strip keys that map to base log fields so they cannot be overridden."""
        return {k: v for k, v in kwargs.items() if k not in self._RESERVED}

    def info(self, message: str, **kwargs):
        extra = self._sanitize_extra(kwargs)
        self._emit("info", message,
                   mind_id=kwargs.get("mind_id"),
                   duration_ms=kwargs.get("duration_ms"),
                   **extra)

    def warn(self, message: str, **kwargs):
        extra = self._sanitize_extra(kwargs)
        self._emit("warn", message,
                   mind_id=kwargs.get("mind_id"),
                   duration_ms=kwargs.get("duration_ms"),
                   **extra)

    def error(self, message: str, **kwargs):
        extra = self._sanitize_extra(kwargs)
        self._emit("error", message,
                   mind_id=kwargs.get("mind_id"),
                   duration_ms=kwargs.get("duration_ms"),
                   **extra)

    def debug(self, message: str, **kwargs):
        extra = self._sanitize_extra(kwargs)
        self._emit("debug", message,
                   mind_id=kwargs.get("mind_id"),
                   duration_ms=kwargs.get("duration_ms"),
                   **extra)
