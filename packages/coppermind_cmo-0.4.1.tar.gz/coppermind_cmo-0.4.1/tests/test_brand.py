"""Tests for get_brand_voice and set_brand_voice tools."""

import json
import pytest
from unittest.mock import MagicMock
from coppermind_cmo.tools.brand import _get_brand_voice, _set_brand_voice
from coppermind_cmo.utils import parse_jsonb


class TestGetBrandVoice:
    def test_requires_active_mind(self):
        db = MagicMock()
        result = _get_brand_voice(db, None)
        assert result["code"] == "NO_ACTIVE_MIND"

    def test_returns_brand_dna(self):
        db = MagicMock()
        db.fetch_one.return_value = (
            "Acme Corp",
            json.dumps({"tone": ["casual"]}),
            json.dumps({"category": "API platform"}),
            json.dumps({"elevator_pitch": "We do things"}),
            json.dumps([{"name": "Sarah", "title": "VP"}]),
            ["dev education", "tutorials"],
        )
        mind = ("mind-1", "Acme Corp")
        result = _get_brand_voice(db, mind)
        assert result["name"] == "Acme Corp"
        assert result["brand_voice"]["tone"] == ["casual"]
        assert result["stakeholders"][0]["name"] == "Sarah"
        assert result["content_themes"] == ["dev education", "tutorials"]

    def test_returns_defaults_when_empty(self):
        db = MagicMock()
        db.fetch_one.return_value = ("New Client", "{}", "{}", "{}", "[]", None)
        mind = ("mind-1", "New Client")
        result = _get_brand_voice(db, mind)
        assert result["brand_voice"] == {}
        assert result["stakeholders"] == []
        assert result["content_themes"] == []


class TestSetBrandVoice:
    def test_requires_active_mind(self):
        db = MagicMock()
        result = _set_brand_voice({"brand_voice": {"tone": ["casual"]}}, db, None)
        assert result["code"] == "NO_ACTIVE_MIND"

    def test_requires_at_least_one_field(self):
        db = MagicMock()
        result = _set_brand_voice({}, db, ("m", "n"))
        assert result["code"] == "INVALID_INPUT"

    def test_validates_brand_voice_requires_tone(self):
        db = MagicMock()
        result = _set_brand_voice(
            {"brand_voice": {"avoid": ["jargon"]}},
            db, ("m", "n"),
        )
        assert result["code"] == "INVALID_BRAND_DNA"

    def test_validates_brand_positioning_requires_category(self):
        db = MagicMock()
        result = _set_brand_voice(
            {"brand_positioning": {"target_market": "SaaS"}},
            db, ("m", "n"),
        )
        assert result["code"] == "INVALID_BRAND_DNA"

    def test_validates_stakeholders_max_50(self):
        db = MagicMock()
        stakeholders = [{"name": f"Person {i}"} for i in range(51)]
        result = _set_brand_voice(
            {"stakeholders": stakeholders},
            db, ("m", "n"),
        )
        assert result["code"] == "INVALID_BRAND_DNA"

    def test_validates_stakeholder_requires_name(self):
        db = MagicMock()
        result = _set_brand_voice(
            {"stakeholders": [{"title": "VP"}]},
            db, ("m", "n"),
        )
        assert result["code"] == "INVALID_BRAND_DNA"

    def test_updates_and_returns_previous(self):
        db = MagicMock()
        # Mock connection context manager for the cursor
        mock_conn = MagicMock()
        mock_cursor = MagicMock()
        mock_conn.cursor.return_value.__enter__ = MagicMock(return_value=mock_cursor)
        mock_conn.cursor.return_value.__exit__ = MagicMock(return_value=False)
        db.connection.return_value.__enter__ = MagicMock(return_value=mock_conn)
        db.connection.return_value.__exit__ = MagicMock(return_value=False)
        # Current values read via cursor inside transaction
        mock_cursor.fetchone.return_value = (
            "Acme Corp",
            json.dumps({"tone": ["formal"]}),
            json.dumps({}),
            json.dumps({}),
            json.dumps([]),
            [],
        )
        # After update, read new values via db.fetch_one
        db.fetch_one.return_value = (
            "Acme Corp",
            json.dumps({"tone": ["casual", "direct"]}),
            json.dumps({}),
            json.dumps({}),
            json.dumps([]),
            [],
        )
        mind = ("mind-1", "Acme Corp")
        result = _set_brand_voice(
            {"brand_voice": {"tone": ["casual", "direct"]}},
            db, mind,
        )
        assert "previous" in result
        assert result["previous"]["brand_voice"]["tone"] == ["formal"]


# ---------------------------------------------------------------------------
# Additional TestGetBrandVoice cases
# ---------------------------------------------------------------------------

class TestGetBrandVoiceExtended:
    def test_returns_error_when_row_is_none(self):
        """Mock db.fetch_one to return None. Should return error with code INTERNAL_ERROR."""
        db = MagicMock()
        db.fetch_one.return_value = None
        mind = ("mind-1", "Phantom")
        result = _get_brand_voice(db, mind)
        assert result["error"] is True
        assert result["code"] == "INTERNAL_ERROR"


# ---------------------------------------------------------------------------
# Additional TestSetBrandVoice cases
# ---------------------------------------------------------------------------

class TestSetBrandVoiceExtended:
    def _make_mind(self):
        return ("mind-1", "Acme Corp")

    def _make_current_row(self):
        """Standard current row for fetch_one side effects."""
        return (
            "Acme Corp",
            json.dumps({"tone": ["formal"]}),
            json.dumps({"category": "API platform"}),
            json.dumps({}),
            json.dumps([{"name": "Sarah", "title": "VP"}]),
            ["blog"],
        )

    def _make_updated_row(self, **overrides):
        """Build an updated row, overriding specific fields."""
        defaults = {
            "name": "Acme Corp",
            "brand_voice": json.dumps({"tone": ["formal"]}),
            "brand_positioning": json.dumps({"category": "API platform"}),
            "approved_messaging": json.dumps({}),
            "stakeholders": json.dumps([{"name": "Sarah", "title": "VP"}]),
            "content_themes": ["blog"],
        }
        defaults.update(overrides)
        return (
            defaults["name"],
            defaults["brand_voice"],
            defaults["brand_positioning"],
            defaults["approved_messaging"],
            defaults["stakeholders"],
            defaults["content_themes"],
        )

    def test_content_themes_update(self):
        """Pass content_themes: ['blog', 'video']. Verify the update goes through."""
        db = MagicMock()
        mind = self._make_mind()
        # Mock connection context manager for the cursor
        mock_conn = MagicMock()
        mock_cursor = MagicMock()
        mock_conn.cursor.return_value.__enter__ = MagicMock(return_value=mock_cursor)
        mock_conn.cursor.return_value.__exit__ = MagicMock(return_value=False)
        db.connection.return_value.__enter__ = MagicMock(return_value=mock_conn)
        db.connection.return_value.__exit__ = MagicMock(return_value=False)
        # Current values read via cursor inside transaction
        mock_cursor.fetchone.return_value = self._make_current_row()
        # After update, read new values via db.fetch_one
        db.fetch_one.return_value = self._make_updated_row(content_themes=["blog", "video"])

        result = _set_brand_voice({"content_themes": ["blog", "video"]}, db, mind)
        assert result["content_themes"] == ["blog", "video"]
        assert "error" not in result

    def test_multiple_fields_update(self):
        """Pass both brand_voice and stakeholders. Verify both are in result['previous']."""
        db = MagicMock()
        mind = self._make_mind()
        mock_conn = MagicMock()
        mock_cursor = MagicMock()
        mock_conn.cursor.return_value.__enter__ = MagicMock(return_value=mock_cursor)
        mock_conn.cursor.return_value.__exit__ = MagicMock(return_value=False)
        db.connection.return_value.__enter__ = MagicMock(return_value=mock_conn)
        db.connection.return_value.__exit__ = MagicMock(return_value=False)
        # Current values read via cursor inside transaction
        mock_cursor.fetchone.return_value = self._make_current_row()
        # After update, read new values via db.fetch_one
        db.fetch_one.return_value = self._make_updated_row(
            brand_voice=json.dumps({"tone": ["casual"]}),
            stakeholders=json.dumps([{"name": "Bob"}]),
        )

        result = _set_brand_voice(
            {
                "brand_voice": {"tone": ["casual"]},
                "stakeholders": [{"name": "Bob"}],
            },
            db, mind,
        )
        assert "brand_voice" in result["previous"]
        assert "stakeholders" in result["previous"]

    def test_unknown_fields_filtered(self):
        """Pass {'unknown_key': 'value'}. Should return INVALID_INPUT (no valid fields)."""
        db = MagicMock()
        mind = self._make_mind()
        result = _set_brand_voice({"unknown_key": "value"}, db, mind)
        assert result["code"] == "INVALID_INPUT"

    def test_brand_voice_tone_not_list(self):
        """Pass brand_voice with tone as string instead of list. Should return INVALID_BRAND_DNA."""
        db = MagicMock()
        mind = self._make_mind()
        result = _set_brand_voice({"brand_voice": {"tone": "casual"}}, db, mind)
        assert result["code"] == "INVALID_BRAND_DNA"

    def test_brand_positioning_category_not_string(self):
        """Pass brand_positioning with category as int. Should return INVALID_BRAND_DNA."""
        db = MagicMock()
        mind = self._make_mind()
        result = _set_brand_voice({"brand_positioning": {"category": 123}}, db, mind)
        assert result["code"] == "INVALID_BRAND_DNA"


# ---------------------------------------------------------------------------
# TestParseJsonb
# ---------------------------------------------------------------------------

class TestParseJsonb:
    def test_none_returns_empty_dict(self):
        assert parse_jsonb(None) == {}

    def test_string_is_parsed(self):
        assert parse_jsonb('{"a": 1}') == {"a": 1}

    def test_dict_passed_through(self):
        original = {"a": 1}
        result = parse_jsonb(original)
        assert result == {"a": 1}
        assert result is original  # same object, not a copy

    def test_list_passed_through(self):
        original = [1, 2]
        result = parse_jsonb(original)
        assert result == [1, 2]
        assert result is original  # same object, not a copy

    def test_invalid_json_returns_empty_dict(self):
        assert parse_jsonb("{corrupt") == {}

    def test_empty_string_returns_empty_dict(self):
        assert parse_jsonb("") == {}

    def test_bare_string_returns_string(self):
        assert parse_jsonb('"hello"') == "hello"

    def test_null_string_returns_none(self):
        assert parse_jsonb("null") is None


# ---------------------------------------------------------------------------
# TestContentThemesBounds
# ---------------------------------------------------------------------------

class TestContentThemesBounds:
    def test_set_brand_voice_rejects_too_many_content_themes(self, mock_db, active_mind):
        from coppermind_cmo.tools.brand import _set_brand_voice
        themes = [f"theme{i}" for i in range(21)]
        result = _set_brand_voice({"content_themes": themes}, mock_db, active_mind)
        assert result["error"] is True
        assert result["code"] == "INVALID_INPUT"

    def test_set_brand_voice_rejects_long_content_theme(self, mock_db, active_mind):
        from coppermind_cmo.tools.brand import _set_brand_voice
        themes = ["a" * 101]
        result = _set_brand_voice({"content_themes": themes}, mock_db, active_mind)
        assert result["error"] is True
        assert result["code"] == "INVALID_INPUT"


# ---------------------------------------------------------------------------
# Validation function edge cases (lines 25-47)
# ---------------------------------------------------------------------------

class TestValidationEdgeCases:
    """Exercise individual validation functions with wrong types."""

    def test_validate_brand_voice_not_dict(self):
        """Pass a string instead of dict to _validate_brand_voice."""
        from coppermind_cmo.tools.brand import _validate_brand_voice
        err = _validate_brand_voice("not a dict")
        assert err is not None
        assert "must be an object" in err

    def test_validate_brand_voice_missing_tone(self):
        """Dict without 'tone' key."""
        from coppermind_cmo.tools.brand import _validate_brand_voice
        err = _validate_brand_voice({"avoid": ["jargon"]})
        assert err is not None
        assert "tone" in err

    def test_validate_brand_positioning_not_dict(self):
        """Pass a string instead of dict."""
        from coppermind_cmo.tools.brand import _validate_brand_positioning
        err = _validate_brand_positioning("string value")
        assert err is not None
        assert "must be an object" in err

    def test_validate_brand_positioning_missing_category(self):
        """Dict without 'category' key."""
        from coppermind_cmo.tools.brand import _validate_brand_positioning
        err = _validate_brand_positioning({"target_market": "SaaS"})
        assert err is not None
        assert "category" in err

    def test_validate_stakeholders_not_list(self):
        """Pass a dict instead of list."""
        from coppermind_cmo.tools.brand import _validate_stakeholders
        err = _validate_stakeholders({"name": "Sarah"})
        assert err is not None
        assert "must be an array" in err

    def test_validate_stakeholders_missing_name(self):
        """Entry without 'name' field."""
        from coppermind_cmo.tools.brand import _validate_stakeholders
        err = _validate_stakeholders([{"title": "VP"}])
        assert err is not None
        assert "requires 'name'" in err

    def test_validate_stakeholders_too_many(self):
        """51 entries should exceed limit."""
        from coppermind_cmo.tools.brand import _validate_stakeholders
        entries = [{"name": f"Person {i}"} for i in range(51)]
        err = _validate_stakeholders(entries)
        assert err is not None
        assert "limited to 50" in err

    def test_validate_stakeholders_valid(self):
        """Valid list returns None."""
        from coppermind_cmo.tools.brand import _validate_stakeholders
        err = _validate_stakeholders([{"name": "Alice"}, {"name": "Bob"}])
        assert err is None


# ---------------------------------------------------------------------------
# set_brand_voice DB error path (lines 173-175)
# ---------------------------------------------------------------------------

class TestSetBrandVoiceDbError:
    def test_set_brand_voice_db_error(self):
        """Mock db.connection to raise. Verify tool_error returned."""
        db = MagicMock()
        mind = ("mind-1", "Acme Corp")

        # First fetch_one for reading current values succeeds
        db.fetch_one.return_value = (
            "Acme Corp",
            json.dumps({"tone": ["formal"]}),
            json.dumps({}),
            json.dumps({}),
            json.dumps([]),
            [],
        )
        # But connection() raises
        db.connection.side_effect = Exception("DB connection lost")

        result = _set_brand_voice(
            {"brand_voice": {"tone": ["casual"]}},
            db, mind,
        )
        assert result["error"] is True
        assert result["code"] == "DB_ERROR"

    def test_set_brand_voice_current_row_missing(self):
        """When cursor.fetchone returns None for current values, return INTERNAL_ERROR."""
        db = MagicMock()
        mind = ("mind-1", "Acme Corp")
        # Mock connection context manager for the cursor
        mock_conn = MagicMock()
        mock_cursor = MagicMock()
        mock_conn.cursor.return_value.__enter__ = MagicMock(return_value=mock_cursor)
        mock_conn.cursor.return_value.__exit__ = MagicMock(return_value=False)
        db.connection.return_value.__enter__ = MagicMock(return_value=mock_conn)
        db.connection.return_value.__exit__ = MagicMock(return_value=False)
        # Cursor read returns None (row missing)
        mock_cursor.fetchone.return_value = None

        result = _set_brand_voice(
            {"brand_voice": {"tone": ["casual"]}},
            db, mind,
        )
        assert result["error"] is True
        assert result["code"] == "INTERNAL_ERROR"


# ---------------------------------------------------------------------------
# set_brand_voice via register() wrapper (lines 204, 215-226)
# ---------------------------------------------------------------------------

class TestSetBrandVoiceRegisterWrapper:
    """Exercise the register() wrapper to cover lines 215-226."""

    def test_register_wrapper_passes_non_none_fields(self):
        """Calling set_brand_voice with brand_voice + stakeholders, others None."""
        from coppermind_cmo.tools.brand import _set_brand_voice

        db = MagicMock()
        mind = ("mind-1", "Acme")

        mock_conn = MagicMock()
        mock_cursor = MagicMock()
        mock_conn.cursor.return_value.__enter__ = MagicMock(return_value=mock_cursor)
        mock_conn.cursor.return_value.__exit__ = MagicMock(return_value=False)
        db.connection.return_value.__enter__ = MagicMock(return_value=mock_conn)
        db.connection.return_value.__exit__ = MagicMock(return_value=False)
        # Current values read via cursor inside transaction
        mock_cursor.fetchone.return_value = ("Acme", "{}", "{}", "{}", "[]", [])
        # After update, read new values via db.fetch_one
        db.fetch_one.return_value = (
            "Acme", json.dumps({"tone": ["casual"]}), "{}", "{}", json.dumps([{"name": "Bob"}]), [],
        )

        # Build fields dict like the register wrapper does
        fields = {}
        fields["brand_voice"] = {"tone": ["casual"]}
        fields["stakeholders"] = [{"name": "Bob"}]

        result = _set_brand_voice(fields, db, mind)
        assert "error" not in result
        assert result["brand_voice"]["tone"] == ["casual"]

    def test_content_themes_not_list_returns_error(self):
        """content_themes must be a list."""
        db = MagicMock()
        mind = ("mind-1", "Acme")
        result = _set_brand_voice({"content_themes": "not-a-list"}, db, mind)
        assert result["error"] is True
        assert result["code"] == "INVALID_INPUT"


# ---------------------------------------------------------------------------
# Brand voice wipe guard tests
# ---------------------------------------------------------------------------

class TestBrandVoiceWipeGuard:
    """Tests for the wipe detection caution on set_brand_voice."""

    def _setup_db(self, cursor_row, fetch_one_row):
        """Wire up a mock db with connection/cursor context managers."""
        db = MagicMock()
        mock_conn = MagicMock()
        mock_cursor = MagicMock()
        mock_conn.cursor.return_value.__enter__ = MagicMock(return_value=mock_cursor)
        mock_conn.cursor.return_value.__exit__ = MagicMock(return_value=False)
        db.connection.return_value.__enter__ = MagicMock(return_value=mock_conn)
        db.connection.return_value.__exit__ = MagicMock(return_value=False)
        mock_cursor.fetchone.return_value = cursor_row
        db.fetch_one.return_value = fetch_one_row
        return db

    def test_set_brand_voice_wipe_guard_caution(self):
        """Clearing stakeholders when current has entries should produce a caution."""
        current_row = (
            "Acme Corp",
            json.dumps({"tone": ["formal"]}),
            json.dumps({"category": "API platform"}),
            json.dumps({}),
            json.dumps([{"name": "Sarah", "title": "VP"}, {"name": "Bob", "title": "CTO"}]),
            ["blog"],
        )
        updated_row = (
            "Acme Corp",
            json.dumps({"tone": ["formal"]}),
            json.dumps({"category": "API platform"}),
            json.dumps({}),
            json.dumps([]),
            ["blog"],
        )
        db = self._setup_db(current_row, updated_row)
        mind = ("mind-1", "Acme Corp")

        result = _set_brand_voice({"stakeholders": []}, db, mind)
        assert "caution" in result
        assert len(result["caution"]) == 1
        assert "stakeholders was cleared" in result["caution"][0]
        assert "2 entries" in result["caution"][0]

    def test_set_brand_voice_no_caution_on_normal_update(self):
        """A normal update (non-empty new value) should not produce a caution."""
        current_row = (
            "Acme Corp",
            json.dumps({"tone": ["formal"]}),
            json.dumps({"category": "API platform"}),
            json.dumps({}),
            json.dumps([{"name": "Sarah"}]),
            ["blog"],
        )
        updated_row = (
            "Acme Corp",
            json.dumps({"tone": ["casual", "direct"]}),
            json.dumps({"category": "API platform"}),
            json.dumps({}),
            json.dumps([{"name": "Sarah"}]),
            ["blog"],
        )
        db = self._setup_db(current_row, updated_row)
        mind = ("mind-1", "Acme Corp")

        result = _set_brand_voice({"brand_voice": {"tone": ["casual", "direct"]}}, db, mind)
        assert "caution" not in result

    def test_set_brand_voice_no_caution_when_already_empty(self):
        """Setting stakeholders=[] when already empty should not produce a caution."""
        current_row = (
            "Acme Corp",
            json.dumps({"tone": ["formal"]}),
            json.dumps({"category": "API platform"}),
            json.dumps({}),
            json.dumps([]),
            ["blog"],
        )
        updated_row = (
            "Acme Corp",
            json.dumps({"tone": ["formal"]}),
            json.dumps({"category": "API platform"}),
            json.dumps({}),
            json.dumps([]),
            ["blog"],
        )
        db = self._setup_db(current_row, updated_row)
        mind = ("mind-1", "Acme Corp")

        result = _set_brand_voice({"stakeholders": []}, db, mind)
        assert "caution" not in result
