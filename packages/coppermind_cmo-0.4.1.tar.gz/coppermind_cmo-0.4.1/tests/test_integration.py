"""Integration tests -- cross-module workflows with mocked external services.

These tests call real tool functions through the actual code path,
mocking only at the external boundary (database, embedding, LLM).
"""

import json
from datetime import datetime, timezone
from unittest.mock import MagicMock, patch

from coppermind_cmo.tools.minds import _switch_client, _list_minds
from coppermind_cmo.tools.memories import store_memory_core as _store_memory, _search_memory, _quick_note, _hide_memory
from coppermind_cmo.tools.brand import _get_brand_voice, _set_brand_voice
from coppermind_cmo.tools.intelligence import _prep_meeting, _get_campaign_history


def _dt(day):
    return datetime(2026, 3, day, 10, 0, 0, tzinfo=timezone.utc)


def _make_config():
    config = MagicMock()
    config.embedding_url = "http://localhost:8400"
    config.embedding_provider = "local"
    config.embedding_dims = 384
    config.ollama_url = "http://localhost:11434"
    config.ollama_model = "gemma3:12b"
    config.llm_provider = "ollama"
    config.max_prompt_chars = 13000
    return config


def _mock_db_connection(db):
    """Set up db.connection() to return a usable context manager with cursor."""
    mock_conn = MagicMock()
    mock_cursor = MagicMock()
    mock_conn.cursor.return_value.__enter__ = MagicMock(return_value=mock_cursor)
    mock_conn.cursor.return_value.__exit__ = MagicMock(return_value=False)
    db.connection.return_value.__enter__ = MagicMock(return_value=mock_conn)
    db.connection.return_value.__exit__ = MagicMock(return_value=False)
    return mock_conn, mock_cursor


class TestSwitchThenStore:
    """Verify switch_client output feeds correctly into store_memory."""

    @patch("coppermind_cmo.tools.memories.get_embedding", return_value=[0.1, 0.2, 0.3])
    def test_switch_then_store(self, mock_emb):
        db = MagicMock()
        config = _make_config()
        mind_state = {}

        def set_mind(mid, mname):
            mind_state["id"] = mid
            mind_state["name"] = mname

        # Step 1: switch_client creates new mind
        db.fetch_one.side_effect = [
            None,  # no existing mind found
            None,  # slug not taken
            None,  # _get_tip_for_switch: company_info lookup
            (None,),  # cadence lookup (no cadence set) — for store_memory
        ]
        db.execute_returning.return_value = ("uuid-acme", "Acme Corp", "acme-corp")
        switch_result = _switch_client("Acme Corp", True, db, set_mind, customer_id="test-customer")
        assert switch_result["is_new"] is True
        assert mind_state["id"] == "uuid-acme"

        # Step 2: store_memory using the active mind from switch
        db.execute_returning.return_value = ("mem-uuid-1",)
        active_mind = (mind_state["id"], mind_state["name"])
        store_result = _store_memory(
            "We decided to pause LinkedIn ads through Q2",
            None, ["q2", "ads"], db, config, active_mind,
        )
        assert store_result["memory_id"] == "mem-uuid-1"
        assert store_result["memory_type"] == "fact"
        assert store_result["mind_id"] == "uuid-acme"


class TestStoreSearchRoundtrip:
    """Verify stored memory data flows correctly through search."""

    @patch("coppermind_cmo.tools.memories.get_embedding", return_value=[0.5, 0.5, 0.5])
    def test_store_then_search(self, mock_emb):
        db = MagicMock()
        config = _make_config()
        mind = ("mind-1", "Acme")

        # Store
        db.execute_returning.return_value = ("mem-1",)
        store_result = _store_memory("Series B, 45 employees", None, [], db, config, mind)
        assert store_result["memory_id"] == "mem-1"

        # Search -- mock DB to return what was "stored"
        db.fetch_all.return_value = [
            ("mem-1", "Series B, 45 employees", "Team is 45 people", "fact",
             1.0, 0.92, [], "manual", _dt(5)),
        ]
        search_result = _search_memory("team size", None, 10, 0, db, config, mind)
        assert len(search_result) == 1
        assert search_result[0]["memory_id"] == "mem-1"
        assert search_result[0]["similarity"] == 0.92


class TestQuickNoteThenHide:
    """Verify quick_note creates a memory that can be hidden."""

    @patch("coppermind_cmo.tools.memories.get_embedding", return_value=[0.3, 0.3])
    def test_note_then_hide(self, mock_emb):
        db = MagicMock()
        config = _make_config()
        mind = ("mind-1", "Acme")

        # Quick note
        valid_uuid = "a1b2c3d4-e5f6-7890-abcd-ef1234567890"
        db.execute_returning.return_value = (valid_uuid,)
        note_result = _quick_note("Call Sarah about rebrand next week", db, config, mind)
        assert note_result["memory_id"] == valid_uuid

        # Hide that note
        db.fetch_one.return_value = (valid_uuid, "Call Sarah about rebrand next week")
        hide_result = _hide_memory(valid_uuid, db, mind)
        assert hide_result["hidden"] is True
        assert hide_result["memory_id"] == valid_uuid


class TestBrandDNAWorkflow:
    """Verify get->set->get brand DNA round-trip."""

    def test_get_set_get_brand_voice(self):
        db = MagicMock()
        mind = ("mind-1", "Acme")

        # Initial get -- empty brand DNA
        db.fetch_one.return_value = ("Acme", "{}", "{}", "{}", "[]", [])
        get_result = _get_brand_voice(db, mind)
        assert get_result["brand_voice"] == {}
        assert get_result["content_themes"] == []

        # Set brand voice -- needs connection context manager mocking
        mock_conn, mock_cursor = _mock_db_connection(db)
        # Current values read via cursor inside transaction
        mock_cursor.fetchone.return_value = ("Acme", "{}", "{}", "{}", "[]", [])
        # After update, read new values via db.fetch_one
        db.fetch_one.side_effect = [
            ("Acme", json.dumps({"tone": ["casual", "direct"], "avoid": ["jargon"]}),
             "{}", "{}", "[]", []),
        ]
        set_result = _set_brand_voice(
            {"brand_voice": {"tone": ["casual", "direct"], "avoid": ["jargon"]}},
            db, mind,
        )
        assert set_result["brand_voice"]["tone"] == ["casual", "direct"]
        assert set_result["previous"]["brand_voice"] == {}

        # Second get should show new values
        db.fetch_one.side_effect = None
        db.fetch_one.return_value = (
            "Acme",
            json.dumps({"tone": ["casual", "direct"], "avoid": ["jargon"]}),
            "{}", "{}", "[]", [],
        )
        get_result2 = _get_brand_voice(db, mind)
        assert get_result2["brand_voice"]["tone"] == ["casual", "direct"]


class TestPrepMeetingWithBrandDNA:
    """Verify prep_meeting reads brand DNA and memories together."""

    def test_prep_meeting_uses_brand_dna(self):
        db = MagicMock()
        config = _make_config()
        mind = ("mind-1", "Acme")

        # fetch_one calls: context_row (8 cols), then cadence from _get_mind_cadence (1 col)
        db.fetch_one.side_effect = [
            (
                "Acme",
                json.dumps({"tone": ["casual", "direct"]}),
                json.dumps({"category": "API platform"}),
                json.dumps({}),
                json.dumps([{"name": "Sarah Chen", "title": "VP Marketing"}]),
                ["dev education"],
                None,  # cadence
                None,  # company_info
            ),
            (None,),  # cadence lookup from _get_mind_cadence
        ]

        # fetch_all calls from _collect_meeting_memories:
        # 1. agenda items, 2. commitments, 3. questions, 4. permanent knowledge, 5. backfill
        db.fetch_all.side_effect = [
            [],  # agenda items
            [    # commitments
                ("m3", "Ben sends messaging Friday", "Ben messaging", "commitment", _dt(3), None, None, None, None),
            ],
            [],  # questions
            [    # permanent knowledge
                ("m1", "Pausing LinkedIn ads", "Pause ads", "fact", _dt(1), None, None, None, None),
                ("m2", "Focus on content marketing", "Content focus", "fact", _dt(2), None, None, None, None),
            ],
            [],  # backfill
        ]

        result = _prep_meeting(None, None, 50, db, config, mind)
        assert result["mode"] == "structured"
        assert result["client_name"] == "Acme"
        assert result["stakeholders"] == [{"name": "Sarah Chen", "title": "VP Marketing"}]
        assert result["brand_voice"]["tone"] == ["casual", "direct"]
        assert result["memory_count"] == 3
        assert "# Meeting Brief" in result["brief_markdown"]


class TestCampaignHistoryFlow:
    """Verify campaign history returns only campaign_outcome type memories."""

    def test_campaign_history_after_storing_mixed_types(self):
        db = MagicMock()
        mind = ("mind-1", "Acme")

        # get_campaign_history should only return campaign_outcomes
        db.fetch_all.return_value = [
            ("mem-c1", "Q1 email: 34% open rate", "Q1 email results",
             ["email", "Q1"], _dt(5)),
            ("mem-c2", "LinkedIn ads: $4.20 CPC, 2.1% CTR", "LinkedIn ad results",
             ["linkedin", "paid"], _dt(3)),
        ]

        result = _get_campaign_history(10, 0, db, mind)
        assert len(result) == 2
        assert result[0]["memory_id"] == "mem-c1"
        assert result[0]["tags"] == ["email", "Q1"]
        assert result[1]["summary"] == "LinkedIn ad results"

        # Verify last_accessed_at was updated
        db.execute.assert_called_once()
        update_call = db.execute.call_args
        assert "last_accessed_at" in update_call[0][0]


class TestDegradedModeWorkflow:
    """Verify the system works end-to-end when external services are down."""

    @patch("coppermind_cmo.tools.memories.get_embedding", return_value=None)
    def test_store_works_without_embedding_or_llm(self, mock_emb):
        """Both embedding and Ollama are down. Store should still succeed."""
        db = MagicMock()
        config = _make_config()
        mind = ("mind-1", "Acme")

        db.execute_returning.return_value = ("mem-degraded",)
        result = _store_memory("Important client fact", None, [], db, config, mind)

        assert result["memory_id"] == "mem-degraded"
        assert result["has_embedding"] is False
        assert result["classified_by"] == "default"
        assert result["memory_type"] == "fact"

    @patch("coppermind_cmo.tools.memories.get_embedding", return_value=None)
    def test_search_returns_service_unavailable_when_embedding_down(self, mock_emb):
        """Search with embedding service down returns SERVICE_UNAVAILABLE error."""
        db = MagicMock()
        config = _make_config()
        mind = ("mind-1", "Acme")

        result = _search_memory("anything", None, 10, 0, db, config, mind)
        assert isinstance(result, dict)
        assert result["error"] is True
        assert result["code"] == "SERVICE_UNAVAILABLE"

    def test_prep_meeting_raw_when_llm_down(self):
        """prep_meeting returns raw data when Ollama is unavailable."""
        db = MagicMock()
        config = _make_config()
        mind = ("mind-1", "Acme")

        # fetch_one calls: context_row (8 cols), then cadence from _get_mind_cadence (1 col)
        db.fetch_one.side_effect = [
            ("Acme", "{}", "{}", "{}", "[]", [], None, None),  # context_row
            (None,),  # cadence lookup
        ]

        # fetch_all calls from _collect_meeting_memories:
        # 1. agenda, 2. commitments, 3. questions, 4. permanent knowledge, 5. backfill
        db.fetch_all.side_effect = [
            [],  # agenda items
            [],  # commitments
            [],  # questions
            [    # permanent knowledge -- 4 memories to exceed synthesis threshold
                ("m1", "c1", "s1", "fact", _dt(1), None, None, None, None),
                ("m2", "c2", "s2", "fact", _dt(2), None, None, None, None),
                ("m3", "c3", "s3", "preference", _dt(3), None, None, None, None),
                ("m4", "c4", "s4", "stakeholder", _dt(4), None, None, None, None),
            ],
            [],  # backfill
        ]

        result = _prep_meeting(None, None, 50, db, config, mind)
        assert result["mode"] == "structured"
        assert result["reason"] is None
        assert result["brief_markdown"] is not None
        assert "# Meeting Brief" in result["brief_markdown"]
        assert result["memory_count"] == 4


class TestClientIsolation:
    """Verify that tool functions enforce mind_id scoping."""

    def test_all_tools_reject_no_active_mind(self):
        """Every tool that requires active mind returns NO_ACTIVE_MIND."""
        db = MagicMock()
        config = _make_config()

        results = [
            _store_memory("content", None, [], db, config, None),
            _search_memory("query", None, 10, 0, db, config, None),
            _quick_note("note", db, config, None),
            _hide_memory("mem-1", db, None),
            _get_brand_voice(db, None),
            _set_brand_voice({"brand_voice": {"tone": ["casual"]}}, db, None),
            _prep_meeting(None, None, 50, db, config, None),
            _get_campaign_history(10, 0, db, None),
        ]

        for result in results:
            assert result["error"] is True
            assert result["code"] == "NO_ACTIVE_MIND"

    @patch("coppermind_cmo.tools.memories.get_embedding", return_value=[0.1])
    def test_store_uses_active_mind_id(self, mock_emb):
        """Verify store_memory passes the active mind_id to the INSERT."""
        db = MagicMock()
        config = _make_config()
        mind = ("specific-mind-uuid", "Client X")

        db.execute_returning.return_value = ("mem-1",)
        _store_memory("content here", None, [], db, config, mind)

        # The first arg to execute_returning should be the INSERT SQL,
        # and the params should include the mind_id
        call_args = db.execute_returning.call_args[0]
        params = call_args[1]
        assert params[0] == "specific-mind-uuid"


class TestToolRegistration:
    """Verify all tools register on the MCP server without errors."""

    def test_register_all_tools(self):
        from mcp.server.fastmcp import FastMCP
        from coppermind_cmo.tools import minds, memories, brand, intelligence

        server = FastMCP("test-server")
        minds.register(server)
        memories.register(server)
        brand.register(server)
        intelligence.register(server)

        # Verify we have 14 tools registered
        tool_names = set(server._tool_manager._tools.keys())
        expected = {
            "switch_client", "list_minds", "configure_mind", "list_documents",
            "store_memory", "search_memory", "quick_note", "hide_memory", "done",
            "get_brand_voice", "set_brand_voice",
            "prep_meeting", "get_campaign_history", "get_last_brief",
        }
        assert tool_names == expected
