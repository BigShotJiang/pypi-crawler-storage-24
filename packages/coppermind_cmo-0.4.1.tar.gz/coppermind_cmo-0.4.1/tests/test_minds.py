"""Tests for switch_client, list_minds, and configure_mind tools."""

from datetime import datetime, timezone
from unittest.mock import MagicMock, patch
from coppermind_cmo.tools.minds import _switch_client, _list_minds, _make_slug, _configure_mind


class TestSwitchClient:
    def test_finds_existing_mind_by_name(self):
        db = MagicMock()
        db.fetch_one.side_effect = [
            ("uuid-1", "Acme Corp", "acme-corp", None, False, None, None),  # includes cadence + company_info
            (47,),
        ]
        set_mind = MagicMock()
        result = _switch_client("Acme Corp", False, db, set_mind, customer_id="test-customer")
        assert result["name"] == "Acme Corp"
        assert result["mind_id"] == "uuid-1"
        assert result["is_new"] is False
        assert result["memory_count"] == 47
        set_mind.assert_called_once_with("uuid-1", "Acme Corp")

    def test_creates_new_mind(self):
        db = MagicMock()
        db.fetch_one.side_effect = [None, None]
        db.execute_returning.return_value = ("uuid-new", "NewClient", "newclient")
        set_mind = MagicMock()
        result = _switch_client("NewClient", True, db, set_mind, customer_id="test-customer")
        assert result["is_new"] is True
        set_mind.assert_called_once()

    def test_not_found_and_no_create(self):
        db = MagicMock()
        db.fetch_one.return_value = None
        db.fetch_all.return_value = [("Acme Corp",), ("Bluebell",)]
        set_mind = MagicMock()
        result = _switch_client("Typo", False, db, set_mind, customer_id="test-customer")
        assert result["error"] is True
        assert result["code"] == "MIND_NOT_FOUND"
        set_mind.assert_not_called()

    def test_archived_mind_returns_error(self):
        db = MagicMock()
        db.fetch_one.return_value = (
            "uuid-1", "Old Client", "old-client", "2026-01-01T00:00:00Z", False, None, None,
        )
        set_mind = MagicMock()
        result = _switch_client("Old Client", False, db, set_mind, customer_id="test-customer")
        assert result["code"] == "MIND_ARCHIVED"

    def test_empty_name_returns_error(self):
        db = MagicMock()
        set_mind = MagicMock()
        result = _switch_client("", False, db, set_mind, customer_id="test-customer")
        assert result["code"] == "INVALID_INPUT"

    def test_whitespace_name_returns_error(self):
        db = MagicMock()
        set_mind = MagicMock()
        result = _switch_client("   ", False, db, set_mind, customer_id="test-customer")
        assert result["code"] == "INVALID_INPUT"

    def test_no_customer_id_returns_provisioning_error(self):
        db = MagicMock()
        set_mind = MagicMock()
        result = _switch_client("Acme", False, db, set_mind, customer_id=None)
        assert result["code"] == "PROVISIONING_ERROR"
        set_mind.assert_not_called()


class TestMakeSlug:
    def test_basic_slug(self):
        assert _make_slug("Acme Corp") == "acme-corp"

    def test_multiple_spaces(self):
        assert _make_slug("Hello   World") == "hello-world"

    def test_leading_trailing_hyphens(self):
        assert _make_slug("--leading--") == "leading"

    def test_special_chars(self):
        assert _make_slug("Special!@#Chars") == "special-chars"


class TestListMinds:
    def test_returns_all_minds(self):
        db = MagicMock()
        created = datetime(2026, 3, 1, 9, 0, 0, tzinfo=timezone.utc)
        updated = datetime(2026, 3, 8, 16, 0, 0, tzinfo=timezone.utc)
        db.fetch_all.return_value = [
            ("uuid-1", "Acme Corp", "acme-corp", None, 47, created, updated),
        ]
        result = _list_minds(50, 0, db, customer_id="test-customer")
        assert len(result) == 1
        assert result[0]["name"] == "Acme Corp"
        assert result[0]["memory_count"] == 47

    def test_no_customer_id_returns_empty(self):
        db = MagicMock()
        result = _list_minds(50, 0, db, customer_id=None)
        assert result == []
        db.fetch_all.assert_not_called()


class TestConfigureMind:
    def test_configure_mind_cadence(self):
        """Sets cadence JSONB correctly."""
        db = MagicMock()
        cadence = {"type": "eos", "year": 2026, "quarter": 1, "sprint": 4, "sprints_per_quarter": 6}
        db.execute_returning.return_value = (cadence, {})
        mind = ("mind-1", "Acme")

        result = _configure_mind(cadence, None, db, mind)
        assert result["mind_id"] == "mind-1"
        assert result["name"] == "Acme"
        assert result["cadence"] == cadence
        assert "cadence" in result["updated_fields"]
        assert "company_info" not in result["updated_fields"]

    def test_configure_mind_company_info(self):
        """Sets company_info JSONB correctly."""
        db = MagicMock()
        company_info = {"url": "https://acme.com", "industry": "SaaS"}
        db.execute_returning.return_value = ({}, company_info)
        mind = ("mind-1", "Acme")

        result = _configure_mind(None, company_info, db, mind)
        assert result["company_info"] == company_info
        assert "company_info" in result["updated_fields"]
        assert "cadence" not in result["updated_fields"]

    def test_configure_mind_merge(self):
        """Calling twice merges (doesn't replace) — verified by checking SQL uses || operator."""
        db = MagicMock()
        cadence1 = {"type": "eos", "year": 2026}
        db.execute_returning.return_value = ({"type": "eos", "year": 2026, "quarter": 1}, {})
        mind = ("mind-1", "Acme")

        _configure_mind(cadence1, None, db, mind)

        # Verify SQL uses JSONB merge operator
        call_args = db.execute_returning.call_args[0]
        sql = call_args[0]
        assert "||" in sql, "SQL should use || for JSONB merge"
        assert "COALESCE" in sql, "SQL should use COALESCE for NULL handling"

    def test_configure_mind_validation_quarter(self):
        """Quarter outside 1-4 returns error."""
        db = MagicMock()
        mind = ("mind-1", "Acme")
        result = _configure_mind({"quarter": 5}, None, db, mind)
        assert result["error"] is True
        assert result["code"] == "INVALID_INPUT"
        assert "quarter" in result["message"]

    def test_configure_mind_validation_year(self):
        """Year outside 2020-2100 returns error."""
        db = MagicMock()
        mind = ("mind-1", "Acme")
        result = _configure_mind({"year": 2019}, None, db, mind)
        assert result["error"] is True
        assert result["code"] == "INVALID_INPUT"
        assert "year" in result["message"]

    def test_configure_mind_no_active_mind(self):
        """Returns NO_ACTIVE_MIND."""
        db = MagicMock()
        result = _configure_mind({"type": "eos"}, None, db, None)
        assert result["code"] == "NO_ACTIVE_MIND"

    def test_configure_mind_nothing_provided(self):
        """Returns INVALID_INPUT when both None."""
        db = MagicMock()
        mind = ("mind-1", "Acme")
        result = _configure_mind(None, None, db, mind)
        assert result["code"] == "INVALID_INPUT"
        assert "Provide" in result["message"]


class TestInternalMinds:
    """Fix #6: Internal minds for non-client notes."""

    def test_create_internal_mind(self):
        """switch_client with is_internal=True creates mind with is_internal flag."""
        db = MagicMock()
        db.fetch_one.side_effect = [None, None]  # not found, no slug conflict
        db.execute_returning.return_value = ("uuid-internal", "Product Feedback", "product-feedback")
        set_mind = MagicMock()
        result = _switch_client("Product Feedback", True, db, set_mind,
                                is_internal=True, customer_id="test-customer")
        assert result["is_new"] is True
        assert result.get("is_internal") is True
        # Verify INSERT includes is_internal
        insert_sql = db.execute_returning.call_args[0][0]
        assert "is_internal" in insert_sql

    def test_create_normal_mind_not_internal(self):
        """Normal mind creation should not set is_internal."""
        db = MagicMock()
        db.fetch_one.side_effect = [None, None]
        db.execute_returning.return_value = ("uuid-normal", "Acme", "acme")
        set_mind = MagicMock()
        result = _switch_client("Acme", True, db, set_mind, customer_id="test-customer")
        assert result["is_new"] is True
        assert result.get("is_internal") is not True

    def test_list_minds_excludes_internal_by_default(self):
        """list_minds should exclude internal minds by default."""
        db = MagicMock()
        created = datetime(2026, 3, 1, 9, 0, 0, tzinfo=timezone.utc)
        updated = datetime(2026, 3, 8, 16, 0, 0, tzinfo=timezone.utc)
        db.fetch_all.return_value = [
            ("uuid-1", "Acme Corp", "acme-corp", None, 47, created, updated),
        ]
        result = _list_minds(50, 0, db, customer_id="test-customer")
        # Verify SQL includes is_internal filter
        sql = db.fetch_all.call_args[0][0]
        assert "is_internal" in sql

    def test_list_minds_includes_internal_when_requested(self):
        """list_minds with include_internal=True should not filter."""
        db = MagicMock()
        created = datetime(2026, 3, 1, 9, 0, 0, tzinfo=timezone.utc)
        updated = datetime(2026, 3, 8, 16, 0, 0, tzinfo=timezone.utc)
        db.fetch_all.return_value = [
            ("uuid-1", "Acme Corp", "acme-corp", None, 47, created, updated),
            ("uuid-2", "Product Notes", "product-notes", None, 10, created, updated),
        ]
        result = _list_minds(50, 0, db, include_internal=True, customer_id="test-customer")
        assert len(result) == 2
        # Verify SQL does NOT filter by is_internal
        sql = db.fetch_all.call_args[0][0]
        assert "is_internal = false" not in sql

    def test_switch_to_existing_internal_mind(self):
        """switch_client to an existing internal mind should work and return is_internal."""
        db = MagicMock()
        # Row returns: id, name, slug, archived_at, is_internal, cadence
        db.fetch_one.side_effect = [
            ("uuid-int", "Product Feedback", "product-feedback", None, True, None, None),
            (5,),  # memory count
        ]
        set_mind = MagicMock()
        result = _switch_client("Product Feedback", False, db, set_mind,
                                customer_id="test-customer")
        assert result["mind_id"] == "uuid-int"
        assert result["is_internal"] is True


class TestSchemaDegradation:
    """Graceful degradation when migration 007 (is_internal column) hasn't been run."""

    @patch("coppermind_cmo.tools.minds._has_is_internal", return_value=False)
    def test_switch_client_works_without_is_internal_column(self, mock_check):
        db = MagicMock()
        db.fetch_one.side_effect = [
            ("uuid-1", "Acme", "acme", None, None, None),  # 6 columns (no is_internal, has cadence + company_info)
            (10,),
        ]
        set_mind = MagicMock()
        result = _switch_client("Acme", False, db, set_mind, customer_id="test-customer")
        assert result["mind_id"] == "uuid-1"
        assert result.get("is_internal") is None  # not present

    @patch("coppermind_cmo.tools.minds._has_is_internal", return_value=False)
    def test_list_minds_works_without_is_internal_column(self, mock_check):
        db = MagicMock()
        created = datetime(2026, 3, 1, 9, 0, 0, tzinfo=timezone.utc)
        updated = datetime(2026, 3, 8, 16, 0, 0, tzinfo=timezone.utc)
        db.fetch_all.return_value = [
            ("uuid-1", "Acme", "acme", None, 5, created, updated),
        ]
        result = _list_minds(50, 0, db, customer_id="test-customer")
        assert len(result) == 1
        sql = db.fetch_all.call_args[0][0]
        assert "is_internal" not in sql

    @patch("coppermind_cmo.tools.minds._has_is_internal", return_value=False)
    def test_create_mind_works_without_is_internal_column(self, mock_check):
        db = MagicMock()
        db.fetch_one.side_effect = [None, None]  # not found, no slug conflict
        db.execute_returning.return_value = ("uuid-new", "New", "new")
        set_mind = MagicMock()
        result = _switch_client("New", True, db, set_mind, customer_id="test-customer")
        assert result["is_new"] is True
        insert_sql = db.execute_returning.call_args[0][0]
        assert "is_internal" not in insert_sql
