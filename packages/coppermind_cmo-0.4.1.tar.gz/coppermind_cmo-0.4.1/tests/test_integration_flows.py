"""Integration flow tests for beta launch readiness.

End-to-end flows through multiple tool functions with mocked DB and
external services. Validates the critical user journeys work correctly.
"""

import json
from datetime import datetime, timezone
from unittest.mock import MagicMock, patch

from coppermind_cmo.tools.minds import _switch_client, _configure_mind
from coppermind_cmo.tools.memories import store_memory_core as _store_memory, _search_memory
from coppermind_cmo.tools.intelligence import _prep_meeting


def _make_config():
    config = MagicMock()
    config.llm_provider = "ollama"
    config.ollama_url = "http://localhost:11434"
    config.ollama_model = "gemma3:12b"
    config.embedding_provider = "local"
    config.embedding_url = "http://localhost:8400"
    config.embedding_dims = 384
    config.max_prompt_chars = 13000
    return config


def _dt(day):
    return datetime(2026, 3, day, 10, 0, 0, tzinfo=timezone.utc)


class TestOnboardingFlow:
    """Test 20: Full onboarding flow -- switch_client -> configure_mind -> store 3 memories -> prep_meeting."""

    @patch("coppermind_cmo.tools.memories.get_embedding", return_value=[0.1, 0.2, 0.3])
    def test_onboarding_flow(self, mock_emb):
        db = MagicMock()
        config = _make_config()
        mind_state = {}

        def set_mind(mid, mname):
            mind_state["id"] = mid
            mind_state["name"] = mname

        # --- Step 1: switch_client (create_new=True) ---
        db.fetch_one.side_effect = [
            None,   # _has_is_internal check
            None,   # no existing mind found
            None,   # slug not taken
        ]
        db.execute_returning.return_value = ("uuid-acme", "Acme Corp", "acme-corp")
        switch_result = _switch_client("Acme Corp", True, db, set_mind, customer_id="test-customer")
        assert switch_result["is_new"] is True
        assert switch_result["mind_id"] == "uuid-acme"
        assert mind_state["id"] == "uuid-acme"

        # --- Step 2: configure_mind with cadence ---
        active_mind = (mind_state["id"], mind_state["name"])
        cadence = {"type": "eos", "year": 2026, "quarter": 1, "sprint": 4, "sprints_per_quarter": 6}
        db.fetch_one.side_effect = None
        db.execute_returning.return_value = (
            json.dumps(cadence),   # returned cadence
            json.dumps({}),        # returned company_info
        )
        configure_result = _configure_mind(cadence, None, db, active_mind)
        assert configure_result["cadence"]["type"] == "eos"
        assert "cadence" in configure_result["updated_fields"]

        # --- Step 3: store 3 memories ---
        memory_contents = [
            "Acme Corp has 45 employees and Series B funding",
            "CEO Sarah Chen prefers direct communication",
            "Q1 focus is developer education content",
        ]
        memory_ids = []
        for i, content in enumerate(memory_contents):
            # For each store_memory call, fetch_one returns the cadence
            db.fetch_one.side_effect = None
            db.fetch_one.return_value = (cadence,)
            db.execute_returning.return_value = (f"mem-{i}",)
            result = _store_memory(content, None, [], db, config, active_mind)
            assert "error" not in result
            memory_ids.append(result["memory_id"])

            # Verify quarter fields in INSERT params
            call_args = db.execute_returning.call_args[0]
            params = call_args[1]
            assert 2026 in params     # quarter_year
            assert 1 in params        # quarter
            assert 4 in params        # sprint

        assert len(memory_ids) == 3

        # --- Step 4: prep_meeting ---
        db.fetch_one.side_effect = [
            # context_row (8 cols)
            (
                "Acme Corp",
                json.dumps({}),    # brand_voice
                json.dumps({}),    # brand_positioning
                json.dumps({}),    # approved_messaging
                json.dumps([]),    # stakeholders
                [],                # content_themes
                json.dumps(cadence),  # cadence
                json.dumps({}),       # company_info
            ),
            (json.dumps(cadence),),  # _get_mind_cadence
        ]
        # fetch_all calls: agenda, commitments, questions, permanent knowledge, backfill
        db.fetch_all.side_effect = [
            [],  # agenda
            [],  # commitments
            [],  # questions
            [    # permanent knowledge
                ("m1", "c1", "s1", "fact", _dt(1), None, None, None, None),
                ("m2", "c2", "s2", "fact", _dt(2), None, None, None, None),
                ("m3", "c3", "s3", "fact", _dt(3), None, None, None, None),
            ],
            [],  # backfill
        ]

        prep_result = _prep_meeting(None, None, 50, db, config, active_mind)
        assert prep_result["mode"] == "structured"
        assert prep_result["client_name"] == "Acme Corp"
        assert prep_result["memory_count"] == 3


class TestOnboardingNoCadence:
    """Test 21: switch_client -> store_memory without configure_mind. NULL quarter fields."""

    @patch("coppermind_cmo.tools.memories.get_embedding", return_value=[0.1, 0.2])
    def test_onboarding_no_cadence(self, mock_emb):
        db = MagicMock()
        config = _make_config()

        # switch_client
        mind_state = {}
        def set_mind(mid, mname):
            mind_state["id"] = mid
            mind_state["name"] = mname

        db.fetch_one.side_effect = [
            None,  # _has_is_internal check
            None,  # no existing mind
            None,  # slug not taken
        ]
        db.execute_returning.return_value = ("uuid-beta", "Beta Co", "beta-co")
        switch_result = _switch_client("Beta Co", True, db, set_mind, customer_id="test-customer")
        assert switch_result["is_new"] is True

        active_mind = (mind_state["id"], mind_state["name"])

        # store_memory without cadence (no configure_mind called)
        db.fetch_one.side_effect = None
        db.fetch_one.return_value = (None,)  # _get_mind_cadence returns empty
        db.execute_returning.return_value = ("mem-nc-1",)

        result = _store_memory("We decided to pause LinkedIn ads", None, [], db, config, active_mind)
        assert result["memory_id"] == "mem-nc-1"

        # Verify NULL quarter fields in INSERT params
        call_args = db.execute_returning.call_args[0]
        params = call_args[1]
        # Last 3 params should be None
        assert params[-3] is None  # quarter_year
        assert params[-2] is None  # quarter
        assert params[-1] is None  # sprint

        # Store 2 more memories so prep_meeting can synthesize
        for i in range(2):
            db.fetch_one.return_value = (None,)
            db.execute_returning.return_value = (f"mem-nc-{i+2}",)
            _store_memory(f"Memory content {i}", None, [], db, config, active_mind)

        # prep_meeting should still work
        db.fetch_one.side_effect = [
            ("Beta Co", "{}", "{}", "{}", "[]", [], None, None),  # context_row
            (None,),  # cadence lookup
        ]
        db.fetch_all.side_effect = [
            [],  # agenda
            [],  # commitments
            [],  # questions
            [
                ("m1", "c1", "s1", "fact", _dt(1), None, None, None, None),
                ("m2", "c2", "s2", "decision", _dt(2), None, None, None, None),
                ("m3", "c3", "s3", "fact", _dt(3), None, None, None, None),
            ],
            [],  # backfill
        ]

        prep_result = _prep_meeting(None, None, 50, db, config, active_mind)
        assert prep_result["mode"] == "structured"
        assert prep_result["memory_count"] == 3


class TestMultiClientIsolation:
    """Test 22: Two minds -- verify search SQL includes correct mind_id."""

    @patch("coppermind_cmo.tools.memories.get_embedding", return_value=[0.5, 0.5])
    def test_multi_client_isolation(self, mock_emb):
        db = MagicMock()
        config = _make_config()

        mind_1 = ("mind-1-uuid", "Client Alpha")
        mind_2 = ("mind-2-uuid", "Client Beta")

        # Store a memory into mind_1
        db.fetch_one.return_value = (None,)  # no cadence
        db.execute_returning.return_value = ("mem-alpha-1",)
        _store_memory("Alpha-specific secret info", None, [], db, config, mind_1)

        # Verify INSERT used mind_1's ID
        store_call = db.execute_returning.call_args[0]
        store_params = store_call[1]
        assert store_params[0] == "mind-1-uuid"

        # Search in mind_2
        db.fetch_all.return_value = []
        _search_memory("secret info", None, 10, 0, db, config, mind_2)

        # Verify the search SQL WHERE clause references mind_2's ID
        search_call = db.fetch_all.call_args[0]
        search_params = search_call[1]
        assert "mind-2-uuid" in search_params
        assert "mind-1-uuid" not in search_params


class TestConfigureMindThenStore:
    """Test 23: configure_mind with EOS cadence, then store 3 memories. Verify quarter params."""

    @patch("coppermind_cmo.tools.memories.get_embedding", return_value=[0.3, 0.4])
    def test_configure_mind_then_store(self, mock_emb):
        db = MagicMock()
        config = _make_config()
        active_mind = ("mind-eos", "EOS Client")

        # configure_mind sets EOS cadence
        cadence = {"type": "eos", "year": 2026, "quarter": 1, "sprint": 4}
        db.execute_returning.return_value = (
            json.dumps(cadence),
            json.dumps({}),
        )
        cfg_result = _configure_mind(cadence, None, db, active_mind)
        assert cfg_result["cadence"]["year"] == 2026
        assert cfg_result["cadence"]["quarter"] == 1
        assert cfg_result["cadence"]["sprint"] == 4

        # Store 3 memories -- each should pick up the cadence
        store_calls = []
        for i in range(3):
            db.fetch_one.return_value = (cadence,)  # _get_mind_cadence
            db.execute_returning.return_value = (f"mem-eos-{i}",)
            _store_memory(f"EOS memory content {i}", None, [], db, config, active_mind)
            store_calls.append(db.execute_returning.call_args[0][1])

        # All 3 INSERT calls should have quarter_year=2026, quarter=1, sprint=4
        for params in store_calls:
            assert 2026 in params, f"quarter_year missing from params: {params}"
            assert 1 in params, f"quarter missing from params: {params}"
            assert 4 in params, f"sprint missing from params: {params}"
