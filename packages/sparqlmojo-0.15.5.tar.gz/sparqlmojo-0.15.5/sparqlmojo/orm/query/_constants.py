"""Shared constants for query subpackage."""

# SPARQL variable name for subject (used in VALUES clause and elsewhere)
SUBJECT_VARIABLE_NAME: str = "s"
