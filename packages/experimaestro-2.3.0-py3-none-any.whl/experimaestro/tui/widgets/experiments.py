"""Experiments list widget for the TUI"""

from datetime import datetime
from typing import Optional
from textual import work
from textual.app import ComposeResult
from textual.containers import Container, Horizontal
from textual.widgets import DataTable, Label, Static
from textual.widget import Widget
from textual.reactive import reactive
from textual.binding import Binding

from experimaestro.scheduler.interfaces import ExperimentStatus
from experimaestro.scheduler.state_provider import StateProvider
from experimaestro.tui.utils import format_duration
from experimaestro.tui.messages import (
    ExperimentSelected,
    ExperimentDeselected,
    DeleteExperimentRequest,
    KillExperimentRequest,
    ShowRunsRequest,
)
from experimaestro.carbon.utils import format_co2_kg


class ExperimentsList(Widget):
    """Widget displaying list of experiments"""

    BINDINGS = [
        Binding("d", "show_runs", "Runs"),
        Binding("ctrl+d", "delete_experiment", "Delete", show=False),
        Binding("ctrl+k", "kill_experiment", "Kill", show=False),
        Binding("S", "sort_by_status", "Sort ⚑", show=False),
        Binding("D", "sort_by_date", "Sort Date", show=False),
    ]

    current_experiment: reactive[Optional[str]] = reactive(None)
    collapsed: reactive[bool] = reactive(False)

    # Track current sort state
    _sort_column: Optional[str] = "status"
    _sort_reverse: bool = False

    # Status sort order (for sorting by status)
    STATUS_ORDER = {
        "running": 0,  # Running experiments first
        "failed": 1,  # Failed experiments (need attention)
        "done": 2,  # Completed experiments
        "empty": 3,  # Empty experiments last
    }

    # Column key to display name mapping
    COLUMN_LABELS = {
        "id": "ID",
        "run": "Run",
        "runs": "#",
        "host": "Host",
        "jobs": "Jobs",
        "status": "Status",
        "started": "Started",
        "duration": "Duration",
        "co2": "CO2",
    }

    # Columns that support sorting (column key -> sort column name)
    SORTABLE_COLUMNS = {
        "status": "status",
        "started": "started",
    }

    def __init__(self, state_provider: StateProvider) -> None:
        super().__init__()
        self.state_provider = state_provider
        self.experiments = []

    def _get_selected_experiment_id(self) -> Optional[str]:
        """Get the experiment ID from the currently selected row"""
        table = self.query_one("#experiments-table", DataTable)
        if table.cursor_row is None:
            return None
        row_key = list(table.rows.keys())[table.cursor_row]
        if row_key:
            return str(row_key.value)
        return None

    def action_delete_experiment(self) -> None:
        """Request to delete the selected experiment"""
        exp_id = self._get_selected_experiment_id()
        if exp_id:
            self.post_message(DeleteExperimentRequest(exp_id))

    def action_kill_experiment(self) -> None:
        """Request to kill all running jobs in the selected experiment"""
        exp_id = self._get_selected_experiment_id()
        if exp_id:
            self.post_message(KillExperimentRequest(exp_id))

    def action_show_runs(self) -> None:
        """Show runs for the selected experiment"""
        exp_id = self._get_selected_experiment_id()
        if exp_id:
            # Get current run_id for this experiment
            exp_info = next(
                (exp for exp in self.experiments if exp.experiment_id == exp_id),
                None,
            )
            current_run_id = (
                getattr(exp_info, "current_run_id", None) if exp_info else None
            )
            self.post_message(ShowRunsRequest(exp_id, current_run_id))

    def action_sort_by_status(self) -> None:
        """Sort experiments by status"""
        if self._sort_column == "status":
            self._sort_reverse = not self._sort_reverse
        else:
            self._sort_column = "status"
            self._sort_reverse = False
        self._update_column_headers()
        self.refresh_experiments()
        order = "desc" if self._sort_reverse else "asc"
        self.notify(f"Sorted by status ({order})", severity="information")

    def action_sort_by_date(self) -> None:
        """Sort experiments by start date"""
        if self._sort_column == "started":
            self._sort_reverse = not self._sort_reverse
        else:
            self._sort_column = "started"
            self._sort_reverse = True  # Default to newest first for date
        self._update_column_headers()
        self.refresh_experiments()
        order = "newest first" if self._sort_reverse else "oldest first"
        self.notify(f"Sorted by date ({order})", severity="information")

    @staticmethod
    def _format_experiment_status(exp) -> str:
        """Format experiment status for display.

        Uses exp.status (ExperimentStatus enum) to determine whether the
        experiment is truly running, rather than inferring from job counts.
        """
        failed = exp.failed_jobs
        total = exp.total_jobs
        finished = exp.finished_jobs

        if failed > 0:
            return f"❌ {failed} failed"
        if total == 0:
            return "Empty"

        try:
            exp_status = exp.status
        except (NotImplementedError, AttributeError):
            exp_status = None

        if exp_status == ExperimentStatus.RUNNING:
            return f"🏃 {finished}/{total}"
        # Experiment is not running (done/failed status)
        if finished == total:
            return "✓ Done"
        return f"⏹ {finished}/{total}"

    def _get_status_category(self, exp) -> str:
        """Get status category for an experiment (for sorting)"""
        failed = exp.failed_jobs
        total = exp.total_jobs
        finished = exp.finished_jobs

        try:
            exp_status = exp.status
        except (NotImplementedError, AttributeError):
            exp_status = None

        if failed > 0:
            return "failed"
        elif exp_status == ExperimentStatus.RUNNING:
            return "running"
        elif finished == total and total > 0:
            return "done"
        elif total > 0:
            return "done"  # Not running, has jobs, but not all finished
        else:
            return "empty"

    def _get_status_sort_key(self, exp):
        """Get sort key for an experiment based on status

        Primary: status order (running, failed, done, empty)
        Secondary: started_at descending (newest first)
        """
        status_category = self._get_status_category(exp)
        status_order = self.STATUS_ORDER.get(status_category, 99)
        # Secondary sort by start time (newest first via negative timestamp)
        started = exp.started_at
        started_ts = started.timestamp() if started else 0
        return (status_order, -started_ts)

    def _update_column_headers(self) -> None:
        """Update column headers with sort indicators"""
        table = self.query_one("#experiments-table", DataTable)
        for column in table.columns.values():
            col_key = str(column.key.value) if column.key else None
            if col_key and col_key in self.COLUMN_LABELS:
                label = self.COLUMN_LABELS[col_key]
                sort_col = self.SORTABLE_COLUMNS.get(col_key)
                if sort_col and self._sort_column == sort_col:
                    # Add sort indicator
                    indicator = "▼" if self._sort_reverse else "▲"
                    new_label = f"{label} {indicator}"
                else:
                    new_label = label
                column.label = new_label

    def on_data_table_header_selected(self, event: DataTable.HeaderSelected) -> None:
        """Handle column header click for sorting"""
        col_key = str(event.column_key.value) if event.column_key else None
        if col_key and col_key in self.SORTABLE_COLUMNS:
            sort_col = self.SORTABLE_COLUMNS[col_key]
            if self._sort_column == sort_col:
                self._sort_reverse = not self._sort_reverse
            else:
                self._sort_column = sort_col
                # Default to reverse for date (newest first)
                self._sort_reverse = sort_col == "started"
            self._update_column_headers()
            self.refresh_experiments()

    def compose(self) -> ComposeResult:
        # Collapsed header (hidden initially)
        with Horizontal(id="collapsed-header", classes="hidden"):
            yield Label("", id="collapsed-experiment-info")

        # Full experiments table
        with Container(id="experiments-table-container"):
            yield Label("Experiments", classes="section-title")
            yield Static("Loading experiments...", id="experiments-loading")
            yield DataTable(id="experiments-table", cursor_type="row")

    def on_mount(self) -> None:
        """Initialize the experiments table"""
        # Start expanded
        self.add_class("expanded")
        self._initial_load = True

        table = self.query_one("#experiments-table", DataTable)
        table.add_column("ID", key="id")
        table.add_column("Run", key="run")
        table.add_column("#", key="runs", width=3)
        table.add_column("Host", key="host")
        table.add_column("Status", key="status")
        table.add_column("Started", key="started")
        table.add_column("Duration", key="duration")
        table.add_column("CO2", key="co2", width=8)
        self._update_column_headers()
        self.refresh_experiments()

    def refresh_experiments(self) -> None:
        """Refresh the experiments list from state provider (background)"""
        # Guard: ensure the table is mounted before querying
        try:
            self.query_one("#experiments-table", DataTable)
        except Exception:
            return
        # Show loading indicator
        try:
            self.query_one("#experiments-loading", Static).remove_class("hidden")
        except Exception:
            pass
        self._load_experiments()

    @work(thread=True, exclusive=True, group="experiments_load")
    def _load_experiments(self) -> None:
        """Load experiments in background thread"""
        try:
            experiments = self.state_provider.get_experiments()
            self.log.debug(
                f"Refreshing experiments: found {len(experiments)} experiments"
            )
        except Exception as e:
            self.log.error(f"ERROR refreshing experiments: {e}")
            import traceback

            self.log.error(traceback.format_exc())
            experiments = []

        # Fetch runs counts in background too (only for offline monitoring)
        runs_counts: dict[str, str] = {}
        if not self.state_provider.is_live:
            for exp in experiments:
                try:
                    runs = self.state_provider.get_experiment_runs(exp.experiment_id)
                    runs_counts[exp.experiment_id] = str(len(runs))
                except Exception as e:
                    self.log.error(f"Error getting runs for {exp.experiment_id}: {e}")
                    runs_counts[exp.experiment_id] = "-"

        self.app.call_from_thread(self._on_experiments_loaded, experiments, runs_counts)

    def _on_experiments_loaded(  # noqa: C901
        self, experiments: list, runs_counts: dict[str, str]
    ) -> None:
        """Handle loaded experiments on main thread"""
        # Hide loading indicator
        try:
            self.query_one("#experiments-loading", Static).add_class("hidden")
        except Exception:
            pass

        self.experiments = experiments

        try:
            table = self.query_one("#experiments-table", DataTable)
        except Exception:
            return

        # Guard: ensure columns have been added (on_mount may not have run yet)
        if len(table.columns) == 0:
            return

        # Sort experiments based on selected column
        experiments_sorted = list(self.experiments)
        if self._sort_column == "status":
            experiments_sorted.sort(
                key=self._get_status_sort_key,
                reverse=self._sort_reverse,
            )
        elif self._sort_column == "started":
            # Sort by started time (experiments without start time go to end)
            experiments_sorted.sort(
                key=lambda e: e.started_at or datetime.min,
                reverse=self._sort_reverse,
            )
        # Default: no sorting, use order from state provider

        # Get existing row keys
        existing_keys = set(table.rows.keys())
        current_exp_ids = set()

        # Check if we need to rebuild (sort order may have changed)
        current_order = [e.experiment_id for e in experiments_sorted]
        existing_order = [str(k.value) for k in table.rows.keys()]
        needs_rebuild = current_order != existing_order

        # Build row data for all experiments
        rows_data = {}
        for exp in experiments_sorted:
            exp_id = exp.experiment_id
            current_exp_ids.add(exp_id)

            status = self._format_experiment_status(exp)

            # Format started time
            if exp.started_at:
                started = exp.started_at.strftime("%Y-%m-%d %H:%M")
            else:
                started = "-"

            # Calculate duration
            duration = "-"
            if exp.started_at:
                if exp.ended_at:
                    elapsed = (exp.ended_at - exp.started_at).total_seconds()
                else:
                    # Still running - show elapsed time
                    elapsed = (datetime.now() - exp.started_at).total_seconds()
                # Format duration
                duration = format_duration(elapsed)

            # Get hostname (may be None for older experiments)
            hostname = getattr(exp, "hostname", None) or "-"

            # Get run_id
            run_id = getattr(exp, "current_run_id", None) or "-"

            # Get runs count (already fetched in background)
            runs_count = runs_counts.get(exp_id, "-")

            # Get CO2 impact (use 'latest' aggregation if available)
            co2_text = "-"
            carbon_impact = getattr(exp, "carbon_impact", None)
            if carbon_impact:
                # Handle both CarbonImpactData object and dict
                if hasattr(carbon_impact, "latest"):
                    latest = carbon_impact.latest
                    co2_kg = latest.co2_kg if latest else 0
                else:
                    latest = carbon_impact.get("latest", {})
                    co2_kg = latest.get("co2_kg", 0) if latest else 0
                if co2_kg > 0:
                    co2_text = format_co2_kg(co2_kg)

            rows_data[exp_id] = (
                exp_id,
                run_id,
                runs_count,
                hostname,
                status,
                started,
                duration,
                co2_text,
            )

        if needs_rebuild:
            # Full rebuild needed - save selection, clear, rebuild
            selected_key = None
            if table.cursor_row is not None and table.row_count > 0:
                try:
                    row_keys = list(table.rows.keys())
                    if table.cursor_row < len(row_keys):
                        selected_key = str(row_keys[table.cursor_row].value)
                except (IndexError, KeyError):
                    pass

            table.clear()
            new_cursor_row = None
            for idx, exp in enumerate(experiments_sorted):
                exp_id = exp.experiment_id
                table.add_row(*rows_data[exp_id], key=exp_id)
                if selected_key == exp_id:
                    new_cursor_row = idx

            if new_cursor_row is not None and table.row_count > 0:
                table.move_cursor(row=new_cursor_row)
        else:
            # Update cells in place (no reordering needed)
            for exp_id, row_data in rows_data.items():
                if exp_id in existing_keys:
                    (
                        _,
                        run_id,
                        runs_count,
                        hostname,
                        status,
                        started,
                        duration,
                        co2_text,
                    ) = row_data
                    table.update_cell(exp_id, "id", exp_id, update_width=True)
                    table.update_cell(exp_id, "run", run_id, update_width=True)
                    table.update_cell(exp_id, "runs", runs_count, update_width=True)
                    table.update_cell(exp_id, "host", hostname, update_width=True)
                    table.update_cell(exp_id, "status", status, update_width=True)
                    table.update_cell(exp_id, "started", started, update_width=True)
                    table.update_cell(exp_id, "duration", duration, update_width=True)
                    table.update_cell(exp_id, "co2", co2_text, update_width=True)
                else:
                    table.add_row(*row_data, key=exp_id)

            # Remove rows for experiments that no longer exist
            for old_exp_id in existing_keys - current_exp_ids:
                table.remove_row(old_exp_id)

        # Update collapsed header if viewing an experiment
        if self.collapsed and self.current_experiment:
            self._update_collapsed_header(self.current_experiment)

        # Auto-select if there's only one experiment on initial load
        if getattr(self, "_initial_load", False) and len(self.experiments) == 1:
            self._initial_load = False
            exp = self.experiments[0]
            exp_id = exp.experiment_id
            run_id = getattr(exp, "current_run_id", None)
            self.current_experiment = exp_id
            self.collapse_to_experiment(exp_id)
            self.post_message(ExperimentSelected(exp_id, run_id))

    def update_experiment_stats(self, experiment_id: str) -> None:
        """Update stats for a single experiment without full list refresh.

        Reloads just one experiment from the state provider and updates
        its row in the DataTable in-place. Falls back to full refresh
        if the experiment is not found in the table.
        """
        try:
            table = self.query_one("#experiments-table", DataTable)
        except Exception:
            return

        # Check if this experiment has a row in the table
        existing_keys = {str(k.value) for k in table.rows.keys()}
        if experiment_id not in existing_keys:
            # Experiment not in table yet — need full refresh
            self.refresh_experiments()
            return

        # Load single experiment
        exp = self.state_provider.get_experiment(experiment_id)
        if exp is None:
            return

        # Update the cached experiments list in-place
        for i, cached_exp in enumerate(self.experiments):
            if cached_exp.experiment_id == experiment_id:
                self.experiments[i] = exp
                break

        status = self._format_experiment_status(exp)

        if exp.started_at:
            started = exp.started_at.strftime("%Y-%m-%d %H:%M")
        else:
            started = "-"

        duration = "-"
        if exp.started_at:
            if exp.ended_at:
                elapsed = (exp.ended_at - exp.started_at).total_seconds()
            else:
                elapsed = (datetime.now() - exp.started_at).total_seconds()
            duration = format_duration(elapsed)

        hostname = getattr(exp, "hostname", None) or "-"
        run_id = getattr(exp, "current_run_id", None) or "-"

        co2_text = "-"
        carbon_impact = getattr(exp, "carbon_impact", None)
        if carbon_impact:
            if hasattr(carbon_impact, "latest"):
                latest = carbon_impact.latest
                co2_kg = latest.co2_kg if latest else 0
            else:
                latest = carbon_impact.get("latest", {})
                co2_kg = latest.get("co2_kg", 0) if latest else 0
            if co2_kg > 0:
                co2_text = format_co2_kg(co2_kg)

        # Update cells in place
        table.update_cell(experiment_id, "id", experiment_id, update_width=True)
        table.update_cell(experiment_id, "run", run_id, update_width=True)
        table.update_cell(experiment_id, "host", hostname, update_width=True)
        table.update_cell(experiment_id, "status", status, update_width=True)
        table.update_cell(experiment_id, "started", started, update_width=True)
        table.update_cell(experiment_id, "duration", duration, update_width=True)
        table.update_cell(experiment_id, "co2", co2_text, update_width=True)

        # Update collapsed header if viewing this experiment
        if self.collapsed and self.current_experiment == experiment_id:
            self._update_collapsed_header(experiment_id)

    def on_data_table_row_selected(self, event: DataTable.RowSelected) -> None:
        """Handle experiment selection"""
        if event.row_key:
            exp_id = str(event.row_key.value)
            self.current_experiment = exp_id
            self.collapse_to_experiment(self.current_experiment)
            # Find run_id from experiments list
            exp_info = next(
                (exp for exp in self.experiments if exp.experiment_id == exp_id),
                None,
            )
            run_id = getattr(exp_info, "current_run_id", None) if exp_info else None
            self.post_message(ExperimentSelected(exp_id, run_id))

    def _update_collapsed_header(self, experiment_id: str) -> None:
        """Update the collapsed experiment header with current stats"""
        exp_info = next(
            (exp for exp in self.experiments if exp.experiment_id == experiment_id),
            None,
        )
        if not exp_info:
            return

        run_id = getattr(exp_info, "current_run_id", None)
        status = self._format_experiment_status(exp_info)

        collapsed_label = self.query_one("#collapsed-experiment-info", Label)
        run_text = f" [{run_id}]" if run_id else ""
        collapsed_label.update(
            f"📊 {experiment_id}{run_text} - {status} (click to go back)"
        )

    def collapse_to_experiment(self, experiment_id: str) -> None:
        """Collapse the experiments list to show only the selected experiment"""
        self._update_collapsed_header(experiment_id)

        # Hide table, show collapsed header
        self.query_one("#experiments-table-container").add_class("hidden")
        self.query_one("#collapsed-header").remove_class("hidden")
        self.collapsed = True
        self.remove_class("expanded")

    def expand_experiments(self) -> None:
        """Expand back to full experiments list"""
        # Show table, hide collapsed header
        self.query_one("#collapsed-header").add_class("hidden")
        self.query_one("#experiments-table-container").remove_class("hidden")
        self.collapsed = False
        self.current_experiment = None
        self.add_class("expanded")

        # Focus the experiments table
        table = self.query_one("#experiments-table", DataTable)
        table.focus()

    def on_click(self) -> None:
        """Handle clicks on the widget"""
        if self.collapsed:
            self.expand_experiments()
            self.post_message(ExperimentDeselected())
