#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
File: lib_grad_solve.py
Project: elra-optimizer
Author: Alexander Kleinsorge; Alexander Fauck
Contributor(s): Felix Rothe; Stefan Kupper; Richard Fiebelkorn
Created: 27.02.23
Organization: Technische Hochschule Wildau (TH Wildau)
Description: ELRA (Efficient Loss-Range-Aware) optimizer for PyTorch, based on the original implementation by
Alexander Kleinsorge. This file contains internal math of ELRA optimizer algorithm, which handles everything as a single tensor/vector.
(key subroutines for the application of the gradient descent algo)

Copyright (c) 2026 TH Wildau. All rights reserved.

See the LICENSE file in the project root for full license information.
"""
__version__ = '2026.03.07'

# from _optim.lib import c_alpha_fac, c_InitOptimP2M, c_InitOptimC2M, c_UpdateBeta, c_growth_func, c_UpdateErrorDamper, c_CalcErrorTolerance
import torch as tt
from torch import add as tt_add
from torch import tensor, float32, dot, std_mean
from math import sqrt, log2, isnan, isinf, log, inf
# from statistic_helper import GlobalStatist as gstat

class SelfConstOptim:

    def __init__(self, dim: int, bs: int, cls: int, lr: float=1e-5, momentum: float=None, wd: float=0.0, warmup: int=1):
        """
        :param dim: Model parameters count = dimension (debug).
        :param bs: batch_size (tbd)
        :param cls: classes or class_count = len of output layer (deprecated)
        :param lr: learning_rate (see other torch-Optimizers)
        :param momentum: Momentum factor (beta). Default: 0.0
        :param wd: weight_decay (see other torch-Optimizers)
        :param warmup: warmup steps, e.g. 1000 for DNN, or 1 for (noise free) math tests
        :return: Nothing
        :rtype: -
        """
        # self.decay_perm: bool = False # 1= dauerdecay, 0= wechseldecay
        self.__init: bool = True
        self.WD_groups: tuple|None = None
        # self.__best_fkt: float = 99.0e99  # best f(x) this far
        self.__initfkt: float = 0.0  # initial function value (only p2m)
        self.alpha: float = lr if (lr > 0.0) else 0.00001  # LR = initial alpha (default=1e-5)
        #self.alphaRed: float = 1.0  # reduces max alpha, if to many retraces
        self.meanAngle: float = 0.0 # mean scalarproduct between yg and yg_old
        self.meanAngleMax: float = 0.0
        self.learningRateSchedule: float = 1.0
        self.S: float = 0.0  # last dot(grad, step_vector)
        self.lr: float = 0.1  # learningRate
        self.lrOld: float = 1.0  # LR damper after Retrace
        # self.g_x: float = 0.0
        self.lastFmean: float = 0.0
        self.lastDev: float = 0.0
        self.DevCorrection: float = 1.0
        # self.lastMean: float = 0.0
        self.lastlastDev: float = 0.0
        self.g_col: float = 0.0
        self.Increase: bool = False  # True if collect increased within last epoch
        self.Increase3: int = 0  # important (>0) within 2 epochs after collect increase
        # self.overestH: float = 0.0
        # self.upperBs: int = 2  # variable for cascading bs
        # self.lowerBs: int = 1  # variable for cascading bs
        # hint: statlength*BatchSizeExt = epoch_samples
        self.statlength: int = 768  #768*4 for Llama # statlength/self.collects*100=number of steps taken for average f
        self.BatchSizeExt: int = bs  # should match DataLoader (was 8 now 32)
        self.lastRed: int = 0  # cycles without better results
        self.sumFvalue: float = 0.0
        # self.sumSquareFvalue: float = 0.0
        self.sumVar: float = 0.0 # recursive variance
        self.MinOfF: float = 0.0 # only for print(best loss of epoch)
        # self.MinOfF2: float = 0.0
        # self.__xoldnorm: float = 0.0
        # self.__noise_avg: float = 0.0
        # self.__alpha_noise: float = 0.0
        self.beta: float = momentum if momentum else None
        # if self.beta == 0.0: self.beta = None
        self.warmup_factor: float = 1.0 if warmup<=1 else 1.0/warmup
        self.WD: float = 1.0
        # self.__weight_decay: float = 0.0 #1.0 if (wd <= 0.0) else wd  # 1.0=off, 0.9999 .. 0.9998
        self.__weight_decay_backup: float = wd # 1.0 if (wd <= 0.0) else wd
        # self.__weight_decay_on = None #True if (self.__weight_decay < 1.0) else None
        # if (not self.__weight_decay_on): self.__weight_decay_backup = None
        # self.__path = 0.0
        self.coll_inc: int = 0 # only for print
        self.coll_cnt: int = 0 # only for print
        self.step_cnt: int = 0  # counts actual steps (ignoring retraces)
        self.step_cnt2: int = 0  # counts steps (without retraces)
        self.__last_fkt: float = 0.0
        self.__clipping: float = 10.0 #2.0 or 10.0 # step clipping
        # DynamicBatchSize (Nov.2023)
        self.collects: int | None = None  # target=const, <2 off
        self.coll_fxl: list[float] = []  # list of f(x) for combined steps
        self.xaverList: tt.Tensor = tt.zeros(6, dtype=tt.float32, device='cpu') # last 6 loss values
        # self.coll_ggl: list[float] = []  # test
        self.coll_ggc: float = 0.0
        self.coll_GradFails: int = 0 # print only
        self.coll_grad: tt.Tensor = None
        # self.RandScaler: tt.Tensor = None # weight_decay + f16
        # self.ScalerRuns: int = 0
        # self.solversteps: int = 0
        self.__yg_old: tt.Tensor = None # (today) same as momentum
        self.__mom: tt.Tensor = None # momentum
        self.x_lastgood: tt.Tensor = None  # recovery point for retrace
        self.__norm_yg_old: float = 0.0 # norm(old_grad)
        self.__retrace: bool = False  # retrace last step
        self.__retrace2: int = 0  # retrace in last 100 steps
        self.__retrace3: int = 0  # retrace in last epoch
        self.__classes: int = cls # default=0
        self.__no_noise: bool = False  # DNN=False, Math=True
        self.__growthdamper = 855000.0  # dampens growthrate if to many backsteps (2D only)
        # self.__errordamper = 500000.0  # dampens the possible worsening of function (P2M,CFFI)
        # self.__truebestfkt: float = 0.0  # perhaps same: __best_fkt
        self.coller: bool = True  # collector still empty
        self.BestCol: float = 0.0  # min(merged losses)
        # gstat.statist_Init()
        self.history_fx_boost: tt.Tensor = None
        self.history_btl_cnt: int = 0

        self.MinCollect: int = 2 # how many micro-batches are always combined, to be removed
        # Loss History (P2M)
        self.history_fx: tt.Tensor = None
        self.history_pos: int = 0 # if not in retrace
        # self.history_sum: float = 0.0
        # self.history_ssum: float = 0.0 # squares
        # self.history_covar: float = 0.0 # sum x*y for covariance
        # self.history_covar2: float = 0.0
        self.valid_loss: float = None
        self.valid_boost: float = None
        self.train_loss: float = None
        self.train_boost: float = None
        # self.log_valid_loss_train_loss: float = None  # log(self.valid_loss / self.train_loss)
        # self.lastBest: float = inf
        # self.epoch_calls_tmp: int = 0
        # self.epoch_calls_last: int = 0
        #self.vec: float = 0.0
        self.LGS_SetClasses(cls, bs)  # TODO: think about
        # self.SetupCollects(dim)  # needs self.BatchSizeExt

    def add_param(self, dim: int, wdv: tuple=None) -> None:
        "add_param_group() -> increase"
        assert self.__init, "only allowed before first step"
        assert dim > 0, "empty dim"
        self.WD_groups = None
        if wdv is None or not wdv: return
        ld = tuple([d for d,w in wdv])  # [dims]
        lw = tuple([w if (w is None or w > 0.5) else (1.0 - w) for d,w in wdv])
        pw = tuple([w for d,w in wdv if w is not None])
        min_pw, max_pw = min(pw), max(pw)
        print("add_param(%d,[%d], %.6f<%.6f)" % (dim, len(wdv), min_pw, max_pw))
        assert sum(ld) == dim, "param count issue"
        assert min_pw >= 0.9 and max_pw <= 1.0, "strange WD range"
        wd_blks: int = len([None for w in lw if w is not None])
        if not wd_blks or min_pw == 1.0: return
        self.WD_groups = (ld, lw)
        return

    def _grad_WD(self, yg: tt.Tensor, x: tt.Tensor, alpha:float) -> None:
        """internal: apply weight_decay in-place (2025)"""
        # x -= tt_add(x * (1.0 - self.__weight_decay), yg, alpha=self.HH) prev
        # tt_add(yg, x, alpha=a, out=yg)
        ld, lw = self.WD_groups
        for gg, xx, ww in zip(list(yg.split(ld)), x.split(ld), lw):
            if ww is not None:  # or 1.0
                tt_add(gg, xx, alpha=alpha, out=gg)
        return

    def load_state_dict(self, state_dict:dict) -> None:
        """get state_dict"""
        assert state_dict, "need full dict"
        raise NotImplementedError()  # "TODO implement for compatibility"
        for k in state_dict():
            todo = 1
        # return vars(self)

    def LGS_SoftReset(self) -> None:
        """debug only"""
        print("LGS_SoftReset, sc=%d" % self.step_cnt2)
        self.coll_grad, self.coll_fxl = None, []
        self.sumFvalue = self.sumSquareFvalue = 0.0
        self.step_cnt -= self.step_cnt2
        assert not (self.step_cnt % 100), "LGS_SoftReset"
        self.step_cnt2 = 0
        return

    def LGS_SetClasses(self, classes: int, gpubatchsize: int) -> None:
        "tell solver class-count and external batchsize, helpful for dynamic batchsize and noise estim."
        assert self.__classes == classes, "already in init()"
        assert self.BatchSizeExt == gpubatchsize, "already in init()"
        if (classes <= 1):
            self.collects = 1  # 1 = math
            self.__no_noise = True  # is math (low dim)
        print("LGS_SetClasses(cls=%d, ebs=%d, init=%s)" % (classes, gpubatchsize, str(self.__init)))
        return

    def LGS_SetDevice(self, dev: tt.device) -> None:
        "move Tensors to device to free GPU ram during fullbatch (end of epoch), PCIe4x16=32GB/s"
        if self.__init: return
        from time import time as time_time
        byte: int = 0
        cnt: int = 0
        if dev is None: dev = tt.device('cpu')
        dt: float = time_time()
        coll_grad, __yg_old = self.coll_grad, self.__yg_old

        if (coll_grad is not None) and (coll_grad.device != dev):
            byte += coll_grad.numel() * coll_grad.element_size()
            self.coll_grad = coll_grad.to(dev)
            cnt += 1
        if (__yg_old is not None) and (__yg_old.device != dev):
            byte += __yg_old.numel() * __yg_old.element_size()
            self.__yg_old = __yg_old.to(dev)
            cnt += 1

        if byte > 0:
            print("LGS: moved %d Tensors to dev=%s, %d KB / %.3f sec" % (cnt, str(dev), byte>>10, time_time() - dt))
        return

    def GetLossLimit(self) -> float:
        "worst loss before retrace (seldom update)"
        return log(self.__classes) if self.__init else self.__initfkt

    def SetValidLoss(self, loss: float, boost: float = None) -> None:
        "usually once per epoch (for overestim.), controls weight_decay"
        self.valid_loss, self.valid_boost = loss, boost
        # self.log_valid_loss_train_loss = None if self.valid_loss is None or self.train_loss is None \
        #    else log(self.valid_loss / self.train_loss)
        return

    def SetTrainLoss(self, loss: float, boost: float = None) -> None:
        "usually once per epoch (for overestim.)"
        self.train_loss, self.train_boost = loss, boost
        #self.log_valid_loss_train_loss = None if self.valid_loss is None or self.train_loss is None \
        #    else log(self.valid_loss / self.train_loss)
        return

    def LGS_TellTrainBoostLoss(self, train_loss: float) -> None:
        "get train_loss of boost-params (if avail)"
        #if self.epoch_calls_tmp:
        #    self.epoch_calls_last, self.epoch_calls_tmp = self.epoch_calls_tmp, 0
        if (self.history_fx_boost is None):
            self.history_fx_boost = tt.zeros(10, dtype=float32, device='cpu')
            self.history_fx_boost[0] = train_loss
            self.history_btl_cnt = 1
        else:
            new_list = tt.roll(self.history_fx_boost, 1)
            new_list[0] = train_loss
            self.history_btl_cnt += 1
            if (self.history_btl_cnt >= 10):
                dv = self.history_fx_boost + new_list
                dv = (dv - tt.roll(dv, -1)) * 0.5
                n, a = dv[:3].mean().item(), dv[3:8].mean().item()
                r = n/a if (a*a > 1e-6**2) else (0.0 if (n<a) else 1e9)
                # r = n/a if (abs(a) > 1e-6) else (0.0 if (n<a) else 1e9) # slow abs()
                print("LGS_TellTrainBoostLoss(%d, %.3g/%.3g = %.3g)" % (self.history_btl_cnt, n, a, r))
            self.history_fx_boost = new_list
        return

    def LGS_CheckNextStep(self) -> tuple[bool, int]:
        "internal: only for MultiGpu SMP/DDP"
        if (self.collects is None): return True, 0
        return (len(self.coll_fxl) + 1) >= self.collects, self.collects

    def InternalsSave(self, fn: str = "state_lgs.txt") -> None:
        "save internal state: TODO update parameter list"
        if (len(fn) < 2) or (self.__init): return
        f = open(fn, "wt")
        if (f.closed):
            print("lib_grad_solve/InternalsSave(%s)=failed." % fn)
            return
        scol: int = 0 if (self.collects is None) else self.collects
        __fkt_avg = __beta = __alpha_noise = __noise_avg = __best_fkt = 0.0  # only C2M
        f.write('LGS,%.4g,%.4g,%d,%.4g,%.4g,%.4g,%.4g,%.4g,%d\n' % (self.alpha, __beta, scol, __best_fkt,
               self.__initfkt, __noise_avg, __alpha_noise, __fkt_avg, self.MinCollect))
        f.close()
        # tt.save(tensor(lst, dtype=float32), fn)
        return

    def InternalsLoad(self, fn: str = "start_lgs.txt", silent:bool=True) -> None:
        "continiue training: TODO update parameter list"
        if (len(fn) < 2): return
        from os import path

        f = open(fn, "rt") if (path.isfile(fn)) else None
        if (f is None) or (f.closed):
            if (not silent): print("lib_grad_solve/InternalsLoad(%s)=failed." % fn)
            return
        print("lib_grad_solve/InternalsLoad(%s)" % fn)
        # lst = tt.load(fn, weights_only=True).tolist()
        s: str = f.read(4)
        assert "LGS," == s, "wrong header"
        s = f.readline()
        f.close()
        assert len(s) > 20, "short string"
        lst = s.split(',')
        scol: int = 0
        __fkt_avg = __beta = __alpha_noise = __noise_avg = 0.0  # only C2M
        self.alpha, __beta, scol, __best_fkt, \
            self.__initfkt, __noise_avg, __alpha_noise, __fkt_avg, self.MinCollect = tuple(lst)
        self.collects = None if (scol < 2) else int(scol)
        assert (self.alpha > 0.0), "positive learning-rate"
        self.__init = False
        return

    def SetupCollects(self, dim:int) -> None:
        "decide collect feature (ImgNet-detection) - TODO: cleanup this"
        if self.__no_noise:  # (1 == self.__classes):  # 1 = math
            self.MinCollect = self.collects = 1
            # self.upperBs = self.lowerBs = 1
            return
        if (dim == 25549352): # ResNet50-1000 ImageNet1k
            self.MinCollect = max(2, int(128.0/self.BatchSizeExt + 0.9))
            self.statlength = 768*4
        #elif (dim == 23910152 or dim == 11271432): # ResNet50-200 or ResNet18-200 TinyImageNet
        #    self.MinCollect = 1 #max(2, int(96.0/self.BatchSizeExt + 0.9))
        else:
            self.MinCollect = 1  # 2
        self.collects = self.MinCollect #4 * self.MinCollect

        # self.lowerBs = self.MinCollect
        # self.upperBs = max(int(1.5 * self.MinCollect), 2)
        # self.upperBs = max(int(2.0 * self.MinCollect), 2)
        print("Enable Collect/Averaging, %d (x%d) step." % (self.collects, self.BatchSizeExt), flush=True)
        return

    def FirstFnktVal(self, f: float, dim: int, unused_c2m: bool) -> None:
        """
        save initial f(x)
        :param f:
        :param dim:
        :param solver: True = c2m, False = p2m, unused
        :return:
        """
        self.__last_fkt = f
        assert (f > 0.0), "loss < 0"
        if not self.__no_noise:  # (self.__classes >= 1):
            log_classes: float = log(self.__classes)
            self.__initfkt = max(f, log_classes)  # = curr_fkt # only-p2m
        else:
            log_2: float = 0.6931471805599453
            self.__initfkt = max(f, log_2) # min=2
        print("Initial function value:", self.__initfkt)
        print("*fa, 0, %.4e, %.4e" % (self.__initfkt, self.alpha))

        self.SetupCollects(dim)  # needs self.BatchSizeExt

        hlen: int = 1<<9 # len=2^int (256 or 512)
        f11: float = f * 1.1
        self.history_fx = tt.ones(hlen, dtype=float32, device='cpu') * f11
        self.history_pos = 0
        self.lastFmean = f11
        self.lastDev = 0.3 * f11
        # self.history_sum, self.history_ssum = f11 * hlen, f11 * f11 * hlen
        self.__init = False
        # self.InternalsLoad()  # auto-continue from file
        return

    @staticmethod
    def LoadSavedX(n: int) -> tt.Tensor:
        "load x vector from disk (unused)"
        assert (n >= 1), "LoadSavedX: empty dimension"
        fn: str = "lastx_" + str(int(n)) + ".pt"
        # assert(path.isfile(fn))
        return tt.load(fn, weights_only=True)

    @staticmethod
    def StdDev(lst: list[float]):
        if len(lst) <= 1:
            from math import nan
            if len(lst) < 1: return nan, nan
            return nan, float(lst[0])
        if isinstance(lst, list):
            lst = tensor(lst, dtype=float32)
        dev, avg = std_mean(lst)
        return dev.item(), avg.item()

    def GradientMerge(self, fkt: float, grad_fkt: tt.Tensor, x: tt.Tensor):
        "MicroBatchMerge: average gradients (micro-batch to dynamic mini-batch)"  # ResNet50+, LLM

        if (grad_fkt is None):
            self.coll_grad, self.coll_fxl = None, []
            self.step_cnt2 += 1  # optimizer makes an alpha update
            return fkt, 0.0, None # inf = force retrace

        self.coll_cnt += 1

        # assert (fkt < 1e38), "isnan(fkt), Function value maybe nan, checked before"

        grad_nrm: float = grad_fkt.norm().item()
        if not ((grad_nrm < 65e3)  or (grad_fkt.element_size() > 2)):  # float16 + big-alpha = nan-gradient
            self.coll_GradFails += 1
            print("Warn: Large Gradient, n=%.3g, cnt=%d, f=%.3g, a=%.3g, SKIP!" %
                  (grad_nrm, self.coll_GradFails, fkt, self.alpha))
            self.step_cnt2 += 1 # optimizer makes an alpha update
            return inf, 0.0, None  # force retrace

        hlen: int = len(self.coll_fxl)

        factor: float = 1.0 / self.collects

        if not hlen:
            self.coll_grad = grad_fkt.mul(factor)
        else:
            tt_add(self.coll_grad, grad_fkt, alpha=factor, out=self.coll_grad)

        self.coll_fxl.append(fkt)

        if (1 + hlen) < self.collects:
            return fkt, None, None  # continue collecting (leave here)

        # update_control_parameters(), was here


        # self.coll_grad /= self.collects
        self.coll_grad, rv = None, self.coll_grad # todo: create rv in-place (save memory)

        fc_dev, fkt = self.StdDev(self.coll_fxl)
        self.coll_fxl = []  # reset lists (self.coll_ggl)
        return fkt, fc_dev, rv

    # def c2min_pv_step(self, x: tt.Tensor, fkt: float, grad_fkt: tt.Tensor, fkt_alpha: float = None, combi_step: bool = False):

    # @jit(nopython=True, nogil=True)
    def growth_func(self) -> float:  # CFFI
        """
        defines the growth function for the parabola-fitting algo
        :return: gives the growth value
        """
        # A1 = 1000000.0, A2 = 855000
        damp: float = self.__growthdamper
        if (self.__retrace):
            if (damp > 1.0):
                if (damp < (1000000.0 / 16.0)):
                    damp *= 16.0
                else:
                    damp = 855000.0
            else:
                damp += 16.0
        else:
            damp *= (1.0 / 3.9)
        self.__growthdamper = damp
        return 1000000.0 / (1.0 + damp)

    # @jit(nopython=True, nogil=False)
    def __alpha_opt_version(self, alpha: float, f: float, fold: float, yg, yg_old) -> float:
        """
        sets the adaptive stepwidth by fitting a parabola to the function choosing
        the minimum value and extrapolating on the basis of this minimum
        :param alpha:
        :param f:
        :param fold:
        :param yg_old:
        :return:
        """

        Ga: float = self.__norm_yg_old * self.__norm_yg_old  # tt.dot(yg_old, yg_old).item()
        g: float = self.growth_func()  # also internal update of the growthdamper
        if (self.__retrace):
            # limit LR_schedule < 28.39 = 5*log(10)/log(1.5), ensures that lr > 1.0e-5)
            self.learningRateSchedule = min(self.learningRateSchedule+0.4, 28.3943679363)
            self.lrOld = max(1.0e-3, self.lrOld * 0.5)
            self.lr = max(1.0e-5, self.lr * 0.5)
            if self.__no_noise:
                d: float = (f - fold) + alpha * Ga
                m: float = (0.5 * alpha * Ga) / d # crash DIV/0
                if (m < inf): # isnan(m) or isinf(m), 1e999==inf (fastest)
                    alpha *= m
                else:
                    alpha *= 0.01
            return max(min(alpha, 1.0e6), 1.0e-12)  # return alpha
        else:
            # assert Ga > 0.0, "gradient vanished, lenght^2 is zero, i.e. optimizer is at critical point"
            S: float = dot(yg, yg_old).item()  # here Skalarprodukt
            self.S = S_Ga = S / Ga; "DIV/0: gradient vanished, lenght^2 is zero, i.e. optimizer is at critical point"
            #/ yg_old.norm().item() / yg_old.norm().item()
            self.lrOld = sqrt(self.lrOld)
            h: float = 1.0 - S_Ga  # (Ga - S) / Ga
            # NormNorm: float = self.__norm_yg_old
            self.__norm_yg_old = yg.norm().item()
            if (g * h < 1.0):
                alpha *= g
            #if h < 0.001:
            #    alpha *= 1000
            else:
                alpha = self.lr / h if not self.__no_noise else alpha / h
                #if yg.numel() <= 20:
                #    alpha /= h
                #else:
                    #alpha = sqrt(self.lr*self.lr + alpha*alpha) / h
                #    alpha = self.lr / h
        self.lr = min(self.lrOld * (2.0/3.0) ** (self.learningRateSchedule + self.Increase), self.lrOld * self.warmup_factor * self.step_cnt)
        self.lr = max(1.0e-5, self.lr)

        # clipping of the actual step, not the gradient
        N: float = self.lr * self.__norm_yg_old
        if (self.__clipping < N):  # hier evtl auf float32 testen
            # alpha *= self.__clipping / N
            self.lr *= self.__clipping / N
        # following not used for math
        if self.S > 0.0 and not self.__no_noise: #not self.S == 0.0:
            alpha = min(alpha, self.lr / abs(self.S))  #
        self.meanAngle += min(0.0, alpha * self.S)
        self.meanAngleMax = min(self.meanAngleMax, alpha * self.S)
        if alpha*self.S < -0.1:
            alpha = -0.1 / self.S
        return max(min(alpha, 1.0e6), 1.0e-8)  # restricts alpha to 1e-8...1e+6

    #def UpdateErrorDamper(self, currfktlesslastfkt: bool) -> None:  # todo: cffi
    #    "unused"
    #    error: float = self.__errordamper
    #    if currfktlesslastfkt:  # update of the errordamper depending on worsening of result without retrace
    #        self.__errordamper = error * (1.0 / 1.69)
    #    else:
    #        if (error < 1.0):
    #            self.__errordamper =  error + 16.0
    #        else:
    #            self.__errordamper = (error * 16.0) if (error < 500000.0) else 500000.0 # why not max() ?
    #    return

    #def CalcErrorTolerance(self, truebestfkt: float) -> float:  # CFFI
    #    # self.__truebestfkt = truebestfkt
    #    return 25.0 + (2500.0 + 71.0 * sqrt(truebestfkt)) / (1.0 + sqrt(self.__errordamper))

    def _determine_increase(self, xaver: float) -> None:
        "determine increase event"
        lastRed: int = self.lastRed
        # if 6 times no progress, then increase collect
        # if (lastRed >= 3):
        if lastRed >= 6:
            self.xaverList[0] = self.lastFmean = xaver
            self.Increase = True
            self.Increase3 = 1
            self.lastRed = 0
            return

        self.xaverList[lastRed] = xaver
        # after 5 cycles with no progress, check if progress could be seen then averaging
        if (lastRed == 5):
            xal = self.xaverList
            a1 = xal[0] + xal[1]
            a2 = xal[4] + xal[5]
            b1 = xal[0] + xal[1] + xal[2]
            b2 = xal[3] + xal[4] + xal[5]
            if (a1 > a2) or (b1 > b2):
                self.lastRed = 0
                self.xaverList[0] = self.lastFmean = min(a2*0.5, b2*(1/3.0)).item()
                # self.xaverList[0] = self.lastFmean

    def update_control_parameters(self, x: tt.Tensor, x_norm: float) -> None:
        "update control cycle parameters, 1/100 steps"
        self.step_cnt += 1  # should happen here (do not count retrace steps)
        self.step_cnt2 += 1  # should happen here (do not count retrace steps)
        step_cnt: int = self.step_cnt

        if not (step_cnt & 3) and (step_cnt >= 100): # once per 100 moving steps
            #if (self.__weight_decay_backup is not None): # < 1.0):
            #    if (self.decay_perm): # 1
            #        if not (step_cnt % 100): #3500):
            #            self.SwitchWeightDecay( x_norm )
            #    else:
            #        if not (step_cnt % 3500):
            #            self.SwitchWeightDecay( x_norm )

            if not (step_cnt % 100):  # Tune-Here around 0.01
                modo:int = max(1, int(self.statlength/(self.collects*self.BatchSizeExt)))*100 # number of steps used for the average
                if (self.step_cnt2 >= modo): # update control parameteers roughly every epoch
                    dsr: float = 1.0 / (self.step_cnt2 - self.__retrace2)  # only divide by actual step, without retrace-steps
                    xaver2 = sqrt(self.sumVar * dsr)   # standard deviation over last 100 steps
                    xaver:  float = self.sumFvalue * dsr   # loss-mean over last 100 steps
                    self.sumFvalue = self.sumSquareFvalue = 0.0
                    self.sumVar = 0.0
                    self.step_cnt2 = 0
                    self.__retrace2 = 0
                    # assert xaver > 0.0, "this optimizer needs loss > 0"
                    print('xaver: %.6f ± %.6f, min: %.6f' % (xaver, xaver2, self.MinOfF))

                    # counting number of cycles with no progress
                    if (xaver > self.lastFmean):
                        self.lastRed += 1
                    else:
                        self.lastRed = 0
                        # if xaver < self.lastFmean:
                        self.lastFmean = xaver # lastFMean=min(xaver, lastFMean)

                    # after increasing collector, update mean later
                    if self.Increase3 == 2:
                        self.lastFmean = xaver
                        self.Increase3 = 0
                    elif self.Increase3 == 1:
                        self.Increase3 += 1
                    self.Increase = False
                    # self.Increase2 = False

                    # after 5 cycles with no progress, check if progress could be seen then averaging
                    self._determine_increase(xaver)

                    self.train_loss_mean = 0.0
                    self.lastDev = xaver2
                    self.DevCorrection = 1.0
                    self.MinOfF = xaver # statistics, best loss value in last 100 steps
                    scol: int = self.collects
                    if (self.Increase): #(step_cnt == self.cool):
                        scol = max(int(scol * 2), 2)
                        # self.lastMean = self.lastFmean
                        self.lastlastDev = self.lastDev
                    if not self.__no_noise:  # 1 = math
                        self.collects = max(self.MinCollect, min(scol, 6250)) # effective bs<=2000
                g_col: float = self.coll_ggc * 0.01
                self.g_col = g_col
                # self.g_x = 0.0

                # adjusting weight_decay based on discrepancy between train and validation
                if self.valid_loss is not None and self.train_loss is not None and self.valid_loss > 0.0 and self.train_loss > 0.0:
                    b = 1.0 if (self.valid_loss <= self.train_loss) else\
                        sqrt(2.0 * self.valid_loss/self.train_loss - 1.0)
                    #b = max(0.0, sqrt(max(0.0, 2.0*max(1.0, self.valid_loss/self.train_loss) - 1.0)))
                    self.WD = min(3.0*(self.collects**0.666), b)
                else:
                    self.WD = self.__weight_decay_backup  # external constant value

                # adjusting learning rate (via learning rate scheduler), depending on worst estimated correction step over last 100 steps
                inv_log_15: float = 2.4663034623764317  # 1.0 / log(1.5)
                limit: float = log(g_col / self.__clipping) * inv_log_15  #upper limit for learning rate, such that average gradient times lr <= clipping
                if (self.meanAngle > -1.0 and self.__retrace3 > 0):
                    self.learningRateSchedule = max(limit, self.learningRateSchedule - 1.0)
                if self.meanAngleMax < -0.2:   #or -0.05 for FMnist or -0.8 for Llama, TODO: find better control
                    self.learningRateSchedule += 1.0
                else:
                    self.learningRateSchedule = max(limit, self.learningRateSchedule - 0.33)

                self.__retrace3 = 0
                mom_str:str = '' if (self.beta is None) else str('Mom=%.3g,' % self.__mom.norm().item())
                # print norm of momentum only if momentum is used
                x_maxnorm: float = x.norm(p=inf).item()
                print(
                    "# Increase collects=%d, steps=%d+%d+%d, G=%.3g, %s a=%.3g, CummScalarProd=%.3g, MinScalarProd=%.3g, lr = %.3g, xNorm =%.3g, xMax = %.3g." %
                    (self.collects, self.coll_cnt, self.step_cnt, self.coll_inc, g_col, mom_str,
                     self.alpha,
                     self.meanAngle, self.meanAngleMax, (2.0/3.0) ** self.learningRateSchedule,
                     x_norm, x_maxnorm), flush=True)
                self.__retrace2 = 0
                self.meanAngle = 0.0
                self.meanAngleMax = 0.0
                self.coll_cnt = 0  # self.step_cnt
                self.coll_inc += 1
                # self.step_cnt += 1  # prevent increase loop
                # self.step_cnt2 += 1  # prevent increase loop
                self.coll_ggc = 0.0
                self.__retrace = False
                self.InternalsSave()
        return

    # was: p2min_step
    def step(self, x: tt.Tensor, curr_fkt: float, yg):
        """
        performs a single self-consistent gradient descent step updating the global
        storage accordingly for the next step
        :param x: Tensor
        :param curr_fkt: f(x) function-value = e.g. loss
        :param yg gradient
        :combi_step: averaged x for combi_step (once per epoch, if benefitial only)
        :return: tuple(x,_,_) | bool
        """

        curr_fkt = float(curr_fkt)

        # determine best loss among the collected losses
        if self.coller:
            self.BestCol = curr_fkt
            self.coller = False
        else:
            self.BestCol = min(curr_fkt, self.BestCol)
        # self.epoch_calls_tmp += 1

        # collecting self.collects number of gradients
        if (self.collects is not None):  # <2=off
            fkt, fc_dev, yg = self.GradientMerge(curr_fkt, yg, x)
            if (fc_dev is None):
                return None, None, False

        # here actual step happens
        # enable collect happens below in first (non-collect) step !
        self.coller = True
        x0_norm: float = x.norm().item()
        self.update_control_parameters(x, x0_norm)

        # gradient clipping for Llama
        #g_norm: float = gyg.norm()
        #if g_norm > 1.5: yg *=1.5/g_norm


        if self.collects is not None and yg is not None:
        # set weight decay (in gradient only, not loss!
            if self.WD:  # avoid crash DIV0 for math problems
                kappa: float = (1.0*0.005) / x0_norm    # portion of the gradient that is weight decay
                kappa *= self.g_col if (self.g_col > 0.0) else yg.norm().item()
                a: float = (self.WD * kappa) * (4.0 if self.Increase else 2.0)
                if self.WD_groups is None:  # single group (usually)
                    tt_add(yg, x, alpha=a, out=yg)  # new WD here
                else:
                    self._grad_WD(yg, x, a)  # was xstep()

        # self.solversteps += 1
        # tiny_x: bool = False  # x.numel() <= 20  # len(x)

        # self.__xoldnorm = x0_norm  # x.norm().item()
        if (self.__init):
            self.sumFvalue = curr_fkt
            self.sumSquareFvalue = curr_fkt * curr_fkt
            self.MinOfF = curr_fkt # self.MinOfF2 = curr_fkt
            # self.alpha = 0.00001  # not important
            self.FirstFnktVal(curr_fkt, x.numel(), False)
            self.__yg_old = yg
            if self.beta is not None:
                self.__mom = yg
            # self.g_x += dot(x, yg) / self.__xoldnorm
            self.__norm_yg_old = yg.norm().item()
            self.g_col = self.__norm_yg_old
            # c_InitOptimP2M(0.0, 0.0); # CFFI

            tt_add(x, yg, alpha=-self.alpha, out=x)
            return x, None, False
        else:
            # if (curr_fkt < self.__best_fkt): self.__best_fkt = curr_fkt
            start: bool = curr_fkt < (1.1 * self.__initfkt) if not self.__no_noise else True
            # self.CalcErrorTolerance(self.__truebestfkt)
            #errorTolerance: float = 25.0 + (2500.0 + 71.0 * sqrt(self.__truebestfkt)) / (1.0 + sqrt(self.__errordamper))
            #if start and (curr_fkt < self.lastFmean + 5.0 * self.lastDev * self.DevCorrection) and yg is not None:
            if start and (self.BestCol < self.lastFmean + 5.0 * self.lastDev * self.DevCorrection) and yg is not None:
                self.DevCorrection = max(1.0, self.DevCorrection*(1.0/1.05))
                step_cnt2: int = self.step_cnt2  # faster (avoid self.)
                # computing function mean and std-deviation recursively here
                if (step_cnt2): # (step_cnt2>0)
                    self.sumFvalue += curr_fkt
                    dsr: int = (step_cnt2 - self.__retrace2 + 1)
                    helper: float = self.sumFvalue - (dsr * curr_fkt)
                    self.sumVar += (helper * helper) / (step_cnt2 * step_cnt2)  # (step_cnt2 * dsr)
                else:
                    self.sumFvalue += curr_fkt
                    self.sumVar = 0.0
                if (self.step_cnt <= step_cnt2): #update mean and std-dev in beginning always
                    dsf:float = 1.0 / (step_cnt2 - self.__retrace2 + 1)
                    self.lastFmean = self.sumFvalue * dsf
                    self.lastDev = sqrt(self.sumVar * dsf) * (1.05 ** self.__retrace2)
                self.sumSquareFvalue += curr_fkt * curr_fkt
                if (curr_fkt < self.MinOfF): self.MinOfF = curr_fkt # avoid call min(,)
                self.x_lastgood = x.clone() # perhaps only for float16

                # simple step based on learning rate lr
                self.__last_fkt = curr_fkt
                self.__retrace = False
                self.alpha = self.__alpha_opt_version(self.alpha, curr_fkt, curr_fkt, yg, self.__yg_old)
                beta = self.beta
                lr= self.lr if not self.__no_noise else self.alpha
                if beta is None:  # step without momentum
                    tt_add(x, yg, alpha=-lr, out=x)
                    # update of old gradient
                    self.__yg_old = yg
                else: # step with momentum
                    mom = self.__mom
                    tt_add(x, yg, alpha=-(1.0 - beta) * lr, out=x)
                    tt_add(x, mom, alpha=-beta * lr, out=x)

                    # update of old gradient and momentum
                    tt_add(beta * mom, yg, alpha=(1.0 - beta), out=self.__mom)
                    leng = dot(yg, mom) / (mom.norm().item() ** 2.0)
                    self.__yg_old = mom * leng
                self.__norm_yg_old = self.__yg_old.norm().item()
                #if (self.__weight_decay_on is not None):  # decays the parameters, optional
                #    # x -= tt_add(x * (1.0 - self.__weight_decay), yg, alpha=self.alpha)
                #    #tt_add(x, self.__yg_old, alpha=min(self.alpha * self.S, 0.0) - self.HH, out=x)
                #    tt_add(x, self.__yg_old, alpha=self.alpha * self.S - self.lr, out=x)
                #    x -= tt_add(x * (1.0 - self.__weight_decay), yg, alpha=self.lr)
                #    # x *= 2.577/x.norm()
                #    # if (x.element_size() >= 4): # float32
                #else:
                #   #tt_add(x, self.__yg_old, alpha=self.alpha * self.S - self.HH, out=x)
                #    tt_add(x, self.__yg_old, alpha=(self.alpha -self.lr)*self.S, out=x)
                #    tt_add(x , yg, alpha=-self.lr, out=x)
                #    #tt_add(x, yg, alpha=-self.alpha, out=x)  # in-place (out=x was crash)
                # self.UpdateHistoryFx(curr_fkt)
                #self.__yg_old = yg

            # retrace case, retracing step in case the step implied a function value growing too much
            else:
                self.DevCorrection *= 1.05
                old_retrace: bool = self.__retrace
                self.__retrace = True
                self.__retrace2 += 1
                self.__retrace3 += 1

                # increase self.collects if too many retraces
                #if ((self.__retrace2 % 26) == 25):
                if not self.__no_noise and ((self.__retrace3 % 26) == 25):
                    self.lastRed = 0
                    self.collects = max(int(self.collects * 2), 2)
                    #if (self.collects >= self.upperBs):
                    #    self.upperBs = max(int(self.upperBs * 1.5), 2)
                    #    self.lowerBs = max(int(self.lowerBs * 1.5), 2)
                    # self.__retrace2 = 0
                __last_fkt: float = self.__last_fkt  # constant
                # if (__last_fkt <= self.__truebestfkt):
                #     self.__truebestfkt *= 10.0
                # else:
                #     self.__truebestfkt *= (__last_fkt / self.__truebestfkt) ** 0.125
                # if (self.__retrace2 == 2) and (self.collects is not None):
                #    self.collects += 2
                # retracing to the previous x
                old_alpha: float = self.alpha
                # computation of new alpha
                self.alpha = self.__alpha_opt_version(old_alpha, curr_fkt, __last_fkt, yg, self.__yg_old)
                __yg_old: tt.Tensor = self.__yg_old  # constant below
                print("Retrace(%d): f=%.3g(%.3g), a=%.3g, gn=%.3g, or=%d" %
                      (self.__retrace3, curr_fkt, __last_fkt, old_alpha, __yg_old.norm().item(), int(old_retrace)))
                if (self.x_lastgood is not None):
                    axn: float = x.norm().item()
                    # x = self.x_lastgood - tt_add(self.x_lastgood * (1.0 - self.__weight_decay), __yg_old, alpha=self.alpha)
                    tt_add(self.x_lastgood, __yg_old, alpha=-self.lr, out=x)
                    print("RX = %.6g, %.6g, %.6g" % (self.x_lastgood.norm().item(), x.norm().item(), axn))  # debug (3x norm() = slow!)
                else:
                    tt_add(x, __yg_old, alpha=old_alpha - self.alpha, out=x)

                    t1, t2 = tensor(old_alpha), tensor(self.alpha) # old_alpha>self.alpha
                    # x = SelfConstOptim.single_gradient_descent_step(x, -self.alpha, __yg_old)
                    if 0.0 == float((t2 - t1) - t2):  # <(1e-4 or 1e-8)
                    # 2nd computation of new x with new alpha (in round=0 case, float16)
                        tt_add(x, __yg_old, alpha=-self.alpha, out=x) # in-place (combined with last add)
                # x = SelfConstOptim.single_gradient_descent_step(x, self.alpha, __yg_old)

            # self.UpdateErrorDamper(currfktlesslastfkt)  # self (CFFI)

            # statistic
            col: int = 0 if (self.collects is None) else self.collects
            # gstat.statist_AddNumbers([self.__norm_yg_old**0.5, self.alpha, self.__weight_decay, self.__growthdamper, 500000.0, col])
            self.coll_ggc += self.__norm_yg_old

            return x, None, self.__retrace

# EoF.
