#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
File: lib_grad_solve.py
Project: elra-optimizer
Author: Alexander Kleinsorge; Alexander Fauck
Contributor(s): Felix Rothe; Stefan Kupper; Richard Fiebelkorn
Created: 27.02.23
Organization: Technische Hochschule Wildau (TH Wildau)
Description: ELRA (Efficient Loss-Range-Aware) optimizer for PyTorch, based on the original implementation by
Alexander Kleinsorge. This file contains internal math of ELRA optimizer algorithm, which handles everything as a single tensor/vector.
(key subroutines for the application of the gradient descent algo)

Copyright (c) 2026 TH Wildau. All rights reserved.

See the LICENSE file in the project root for full license information.
"""
__version__ = '2026.02.18'

# from _optim.lib import c_alpha_fac, c_InitOptimP2M, c_InitOptimC2M, c_UpdateBeta, c_growth_func, c_UpdateErrorDamper, c_CalcErrorTolerance
import torch as tt
from torch import add as tt_add
from torch import tensor, float32, dot, std_mean
from math import sqrt, log2, isnan, isinf, log, inf
# from statistic_helper import GlobalStatist as gstat

class SelfConstOptim:

    def __init__(self, dim: int, bs: int, cls: int, lr: float=1e-5, momentum: float=None, wd: float=0.0, warmup: int=1):
        """
        :param dim: Model parameters count = dimension (debug).
        :param bs: batch_size (tbd)
        :param cls: classes or class_count = len of output layer (deprecated)
        :param lr: learning_rate (see other torch-Optimizers)
        :param momentum: Momentum factor (beta). Default: 0.0
        :param wd: weight_decay (see other torch-Optimizers)
        :param warmup: warmup steps, e.g. 1000 for DNN, or 1 for (noise free) math tests
        :return: Nothing
        :rtype: -
        """
        # self.decay_perm: bool = False # 1= dauerdecay, 0= wechseldecay
        self.__init: bool = True
        self.WD_groups: tuple|None = None
        self.__best_fkt: float = 99.0e99  # best f(x) this far
        self.__initfkt: float = 0.0  # initial function value (only p2m)
        self.alpha: float = lr if (lr > 0.0) else 0.00001  # LR = initial alpha (default=1e-5)
        # self.alphaRed: float = 1.0  # reduces max alpha, if to many retraces
        self.meanAngle: float = 0.0  # mean scalarproduct between yg and yg_old
        self.learningRateSchedule: float = 1.0
        self.S: float = 0.0
        self.lr: float = 0.1  # learningRate
        self.lrOld: float = 1.0
        # self.g_x: float = 0.0
        self.lastFmean: float = 0.0
        self.lastDev: float = 0.0
        self.DevCorrection: float = 1.0
        self.lastMean: float = 0.0
        self.lastlastDev: float = 0.0
        self.g_col: float = 0.0
        self.Increase: bool = False
        self.overestH: float = 0.0
        self.upperBs: int = 2  # variable for cascading bs
        self.lowerBs: int = 1  # variable for cascading bs
        self.statlength: int = 768  # statlength/self.collects*100=number of steps taken for average f
        self.lastRed: int = 0  # cycles without better results
        self.sumFvalue: float = 0.0
        # self.sumSquareFvalue: float = 0.0
        self.sumVar: float = 0.0  # recursive variance
        self.MinOfF: float = 0.0
        # self.MinOfF2: float = 0.0
        self.__xoldnorm: float = 0.0
        # self.__noise_avg: float = 0.0
        # self.__alpha_noise: float = 0.0
        self.beta: float = momentum
        self.warmup_factor: float = 1.0 if warmup <= 1 else 1.0 / warmup
        self.WD: float = 1.0
        self.__weight_decay: float = 0.0  # 1.0 if (wd <= 0.0) else wd  # 1.0=off, 0.9999 .. 0.9998
        self.__weight_decay_backup: float = wd  # 1.0 if (wd <= 0.0) else wd
        self.__weight_decay_on = None  # True if (self.__weight_decay < 1.0) else None
        # if (not self.__weight_decay_on): self.__weight_decay_backup = None
        # self.__ndim: int = 0 # dimension
        # self.__path = 0.0
        self.coll_inc: int = 0 # only for print
        self.coll_cnt: int = 0 # only for print
        self.step_cnt: int = 0  # counts actual steps (ignoring retraces)
        self.step_cnt2: int = 0  # counts alpha updates (including retraces)
        self.__last_fkt: float = 0.0
        self.__clipping: float = 2.0  # 10.0 #1.0e10 # or inf for float 32
        # if self.trackHistory: self.xhist, self.ahist, self.fhist = [], [], []
        # self.FktLimit: float = 1e99 # future: skip-gradient-calc
        # DynamicBatchSize (Nov.2023)
        self.collects: int | None = None  # target=const, <2 off
        self.coll_fxl: list[float] = []  # list of f(x) for combined steps
        # self.coll_ggl: list[float] = []  # test
        self.coll_ggc: float = 0.0
        # self.coll_cos: tt.Tensor = tt.ones(100, dtype=float32, device='cpu')  # [1.0] * 100 # test (RC1)
        # self.coll_LastGrd: tt.Tensor = None # test
        self.coll_GradFails: int = 0
        self.coll_grad: tt.Tensor = None
        # self.RandScaler: tt.Tensor = None # weight_decay + f16
        # self.ScalerRuns: int = 0
        self.solversteps: int = 0
        self.__yg_old: tt.Tensor = None  # tensor([])
        self.__norm_yg_old: float = 0.0
        self.__retrace: bool = False  # (CFFI)
        self.__retrace2: int = 0
        self.x_lastgood: tt.Tensor = None
        # self.__maxgrowth = 25.0 # unused
        # self.__growth = 1
        self.__classes: int = cls  # default=0
        # self.hlp_log_cls: float = 1.0 if (cls < 1) else 2.35 / log(cls) # log(0), overwritten later
        # self.hlp_log_cls1: float = 1.0 if (cls < 1) else log(cls) / log(10.0) # ln(cls)/ln(10), ln(10)=2.30
        self.__growthdamper = 855000.0  # dampens growthrate if to many backsteps (P2M,CFFI)
        # self.__errordamper = 500000.0  # dampens the possible worsening of function (P2M,CFFI)
        self.__truebestfkt: float = 0.0  # perhaps same: __best_fkt
        # gstat.statist_Init()
        self.history_fx_boost: tt.Tensor = None
        self.history_btl_cnt: int = 0
        # Test
        # self.TestGrads = [None] * 4
        # self.TestCount = [0] * 4
        # self.TestFktx = [0.0] * 4
        # self.TestCountAll: int = 0
        self.BatchSizeExt: int = bs  # should match DataLoader (was 8 now 32)
        self.MinCollect: int = 2  # how many micro-batches are always combined
        # Loss History (P2M)
        self.history_fx: tt.Tensor = None
        self.history_pos: int = 0  # if not in retrace
        self.history_sum: float = 0.0
        self.history_ssum: float = 0.0  # squares
        self.history_covar: float = 0.0  # sum x*y for covariance
        self.history_covar2: float = 0.0
        self.valid_loss: float = None
        self.valid_boost: float = None
        self.train_loss: float = None
        self.train_boost: float = None
        self.log_valid_loss_train_loss: float = None  # log(self.valid_loss / self.train_loss)
        self.lastBest: float = inf
        self.epoch_calls_tmp: int = 0
        self.epoch_calls_last: int = 0
        # self.vec: float = 0.0
        self.LGS_SetClasses(cls, bs)
        # self.SetupCollects(dim)  # needs self.BatchSizeExt

    # Todo: scaling factor routine that operates safely with magnitude value of gradients

    def add_param(self, dim:int, wdv:tuple=None) -> None:
        "add_param_group() -> increase"
        assert self.__init, "only allowed before first step"
        assert dim > 0, "empty dim"
        self.WD_groups = None
        if wdv is None or not wdv: return
        ld = tuple([d for d, w in wdv])  # [dims]
        lw = tuple([w if (w is None or w > 0.5) else (1.0 - w) for d, w in wdv])
        pw = tuple([w for d, w in wdv if w is not None])
        min_pw, max_pw = min(pw), max(pw)
        print("add_param(%d,[%d], %.6f<%.6f)" % (dim, len(wdv), min_pw, max_pw))
        assert sum(ld) == dim, "param count issue"
        assert min_pw >= 0.9 and max_pw <= 1.0, "strange WD range"
        wd_blks: int = len([None for w in lw if w is not None])
        if not wd_blks or min_pw == 1.0: return
        self.WD_groups = (ld, lw)
        return

    def grad_WD(self, yg: tt.Tensor, x: tt.Tensor, alpha: float) -> None:
        "apply weight_decay in-place (2025)"
        # x -= tt_add(x * (1.0 - self.__weight_decay), yg, alpha=self.HH) prev
        # tt_add(yg, x, alpha=a, out=yg)
        ld, lw = self.WD_groups
        for gg, xx, ww in zip(list(yg.split(ld)), x.split(ld), lw):
            if ww is not None:  # or 1.0
                tt_add(gg, xx, alpha=alpha, out=gg)
        return

    def LGS_SoftReset(self) -> None:
        "debug only"
        print("LGS_SoftReset, sc=%d" % self.step_cnt2)
        self.coll_grad, self.coll_fxl = None, []
        self.sumFvalue = self.sumSquareFvalue = 0.0
        self.step_cnt -= self.step_cnt2
        assert not (self.step_cnt % 100), "LGS_SoftReset"
        self.step_cnt2 = 0
        return

    def LGS_SetClasses(self, classes: int, gpubatchsize: int) -> None:
        "tell solver class-count and external batchsize, helpful for dynamic batchsize and noise estim."
        assert self.__classes == classes, "already in init()"
        assert self.BatchSizeExt == gpubatchsize, "already in init()"
        if (classes <= 1): self.collects = 1  # 1 = math
        print("LGS_SetClasses(cls=%d, ebs=%d, init=%s)" % (classes, gpubatchsize, str(self.__init)))
        return

    def LGS_SetDevice(self, dev: tt.device) -> None:
        "move Tensors to device to free GPU ram during fullbatch (end of epoch), PCIe4x16=32GB/s"
        if self.__init: return
        from time import time as time_time
        byte: int = 0
        cnt: int = 0
        if dev is None: dev = tt.device('cpu')
        dt: float = time_time()
        coll_grad, __yg_old = self.coll_grad, self.__yg_old

        if (coll_grad is not None) and (coll_grad.device != dev):
            byte += coll_grad.numel() * coll_grad.element_size()
            self.coll_grad = coll_grad.to(dev)
            cnt += 1
        if (__yg_old is not None) and (__yg_old.device != dev):
            byte += __yg_old.numel() * __yg_old.element_size()
            self.__yg_old = __yg_old.to(dev)
            cnt += 1

        if byte > 0:
            print("LGS: moved %d Tensors to dev=%s, %d KB / %.3f sec" % (cnt, str(dev), byte>>10, time_time() - dt))
        return

    def GetLossLimit(self) -> float:
        "worst loss before retrace (seldom update)"
        return log(self.__classes) if self.__init else self.__initfkt

    def SetValidLoss(self, loss: float, boost: float = None) -> None:
        "usually once per epoch (for overestim.)"
        if self.epoch_calls_tmp:
            self.epoch_calls_last, self.epoch_calls_tmp = self.epoch_calls_tmp, 0
        self.valid_loss, self.valid_boost = loss, boost
        self.log_valid_loss_train_loss = None if self.valid_loss is None or self.train_loss is None \
            else log(self.valid_loss / self.train_loss)
        return

    def SetTrainLoss(self, loss: float, boost: float = None) -> None:
        "usually once per epoch (for overestim.)"
        if self.epoch_calls_tmp:
            self.epoch_calls_last, self.epoch_calls_tmp = self.epoch_calls_tmp, 0
        self.train_loss, self.train_boost = loss, boost
        self.log_valid_loss_train_loss = None if self.valid_loss is None or self.train_loss is None \
            else log(self.valid_loss / self.train_loss)
        return

    def LGS_TellTrainBoostLoss(self, train_loss: float) -> None:
        "get train_loss of boost-params (if avail)"
        if self.epoch_calls_tmp:
            self.epoch_calls_last, self.epoch_calls_tmp = self.epoch_calls_tmp, 0
        if (self.history_fx_boost is None):
            self.history_fx_boost = tt.zeros(10, dtype=float32, device='cpu')
            self.history_fx_boost[0] = train_loss
            self.history_btl_cnt = 1
        else:
            new_list = tt.roll(self.history_fx_boost, 1)
            new_list[0] = train_loss
            self.history_btl_cnt += 1
            if (self.history_btl_cnt >= 10):
                dv = self.history_fx_boost + new_list
                dv = (dv - tt.roll(dv, -1)) * 0.5
                n, a = dv[:3].mean().item(), dv[3:8].mean().item()
                r = n / a if (a * a > 1e-6 ** 2) else (0.0 if (n < a) else 1e9)
                # r = n/a if (abs(a) > 1e-6) else (0.0 if (n<a) else 1e9) # slow abs()
                print("LGS_TellTrainBoostLoss(%d, %.3g/%.3g = %.3g)" % (self.history_btl_cnt, n, a, r))
            self.history_fx_boost = new_list
        return

    def LGS_CheckNextStep(self) -> tuple[bool, int]:
        "internal: only for MultiGpu SMP/DDP"
        if (self.collects is None): return True, 0
        return (len(self.coll_fxl) + 1) >= self.collects, self.collects

    def InternalsSave(self, fn: str = "state_lgs.txt") -> None:
        if (len(fn) < 2) or (self.__init): return
        f = open(fn, "wt")
        if (f.closed):
            print("lib_grad_solve/InternalsSave(%s)=failed." % fn)
            return
        scol: int = 0 if (self.collects is None) else self.collects
        __fkt_avg = __beta = __alpha_noise = __noise_avg = 0.0  # only C2M
        f.write('LGS,%.4g,%.4g,%d,%.4g,%.4g,%.4g,%.4g,%.4g,%d\n' % (self.alpha, __beta, scol, self.__best_fkt,
                                                                    self.__initfkt, __noise_avg, __alpha_noise,
                                                                    __fkt_avg, self.MinCollect))
        f.close()
        # tt.save(tensor(lst, dtype=float32), fn)
        return

    def InternalsLoad(self, fn: str = "start_lgs.txt", silent: bool=True) -> None:
        if (len(fn) < 2): return
        from os import path

        f = open(fn, "rt") if (path.isfile(fn)) else None
        if (f is None) or (f.closed):
            if (not silent): print("lib_grad_solve/InternalsLoad(%s)=failed." % fn)
            return
        print("lib_grad_solve/InternalsLoad(%s)" % fn)
        # lst = tt.load(fn, weights_only=True).tolist()
        s: str = f.read(4)
        assert "LGS," == s, "wrong header"
        s = f.readline()
        f.close()
        assert len(s) > 20, "short string"
        lst = s.split(',')
        scol: int = 0
        __fkt_avg = __beta = __alpha_noise = __noise_avg = 0.0  # only C2M
        self.alpha, __beta, scol, self.__best_fkt, \
            self.__initfkt, __noise_avg, __alpha_noise, __fkt_avg, self.MinCollect = tuple(lst)
        self.collects = None if (scol < 2) else int(scol)
        assert (self.alpha > 0.0), "positive learning-rate"
        self.__init = False
        return

    def UpdateHistoryFx(self, fx: float) -> None:
        "new loss history ring-buffer [256*2] - unused"
        hpos: int = self.history_pos & 511  # %(1<<8) # mod len()
        last_hist: tt.Tensor = self.history_fx[hpos]
        # fxt: tt.Tensor = tensor(fx, device='cpu', dtype=float32)
        self.history_pos += 1
        if (last_hist != tensor(fx, device='cpu', dtype=float32)):
            last_item = last_hist.item()
            self.history_fx[hpos] = fx
            history_covar = 0.0
            history_fx = self.history_fx
            for i in range(1, 513):
                history_covar += (-256.5 + i) * history_fx[(hpos + i) & 511].item()
            self.history_covar = history_covar
            self.history_sum += fx - last_item
            self.history_ssum += fx*fx - last_item*last_item
        return

    def SetupCollects(self, dim: int) -> None:
        "decide collect feature - TODO: cleanup this"
        if (1 == self.__classes):  # 1 = math
            self.MinCollect = self.collects = 1
            self.upperBs = self.lowerBs = 1
            return
        # self.collects = 8  # 128 // self.BatchSizeExt # 16, under test: 32x8=256 (256 little better than 512)
        # self.MinCollect = 128 if (dim == 23910152) else 2 # ResNet50(24mio)
        # if False: #variant for c2min, distinction between RestNet50 and rest
        #    self.MinCollect = 64 if (dim == 23910152) else 2  # ResNet50(24mio) oder MinCollect = 64
        #    self.collects = 256 if (dim == 23910152) else 8  # 128 // self.BatchSizeExt # 16, under test: 32x8=256 (256 little better than 512)
        # else: # P2M: MC = 24 or 32 ==== DEFAULT (2024)
        # automatic calculation of the collection constant based on the batchsize used by the gpu and the target collector batchsize
        if (dim == 25549352):  # ResNet50-1000 ImageNet1k
            self.MinCollect = max(2, int(128.0 / self.BatchSizeExt + 0.9))
            self.statlength = 768 * 4
        elif (dim == 23910152 or dim == 11271432):  # ResNet50-200 or ResNet18-200 TinyImageNet
            self.MinCollect = 1  # max(2, int(96.0/self.BatchSizeExt + 0.9))
        else:
            self.MinCollect = 1  # 2
        self.collects = self.MinCollect  # 4 * self.MinCollect

        self.lowerBs = self.MinCollect
        self.upperBs = max(int(1.5 * self.MinCollect), 2)
        # self.upperBs = max(int(2.0 * self.MinCollect), 2)
        print("Enable Collect/Averaging, %d (x%d) step." % (self.collects, self.BatchSizeExt), flush=True)
        return

    def FirstFnktVal(self, f: float, dim: int, unused_c2m: bool) -> None:
        """
        save initial f(x)
        :param f:
        :param dim:
        :param solver: True = c2m, False = p2m, unused
        :return:
        """
        self.__best_fkt = f
        self.__last_fkt = f
        self.__truebestfkt = f
        assert (f > 0.0), "loss < 0"
        if (self.__classes >= 1):
            log_classes: float = log(self.__classes)
            self.__initfkt = max(f, log_classes)  # = curr_fkt # only-p2m
            # self.hlp_log_cls1 = log_classes / log(10)
        else:
            self.__initfkt = max(f, log(2.0))  # min=2
            # self.hlp_log_cls = (2.35 / f) if (f > 0.0) else 1.0
            # self.hlp_log_cls1 = 1.0 # todo
        print("Initial function value:", self.__initfkt)
        print("*fa, 0, %.4e, %.4e" % (self.__initfkt, self.alpha))

        if (self.__weight_decay_on is not None):  # < 1.0
            assert (self.__weight_decay <= 1.0) and (self.__weight_decay >= 0.9), "0.9<weight_decay<1.0"
            # if (str(get_default_dtype()).find('float16') > 0) and (self.__weight_decay >= 0.9990):
            # self.RandScaler = self.PrepareFuzzyScaler(self.__weight_decay)
            #    self.__weight_decay = 0.9995 # 0.99951172 = largest number less than one
            print("LGS: weight_decay = %.6f = 1 - %.2e = ON" % (self.__weight_decay, 1.0 - self.__weight_decay))

        
        self.SetupCollects(dim)  # needs self.BatchSizeExt

        hlen: int = 1 << 9  # len=2^int (256 or 512)
        f11: float = f * 1.1
        self.history_fx = tt.ones(hlen, dtype=float32, device='cpu') * f11
        self.history_pos = 0
        self.lastFmean = f11
        self.lastDev = 0.3 * f11
        self.history_sum, self.history_ssum = f11 * hlen, f11 * f11 * hlen
        self.__init = False
        self.InternalsLoad()
        return

    @staticmethod
    def LoadSavedX(n: int) -> tt.Tensor:
        "load x vector from disk (unused)"
        assert (n >= 1), "LoadSavedX: empty dimension"
        fn: str = "lastx_" + str(int(n)) + ".pt"
        # assert(path.isfile(fn))
        return tt.load(fn, weights_only=True)

    @staticmethod
    def StdDev(lst: list[float]):
        if len(lst) <= 1:
            from math import nan
            if len(lst) < 1: return nan, nan
            return nan, float(lst[0])
        if isinstance(lst, list):
            lst = tensor(lst, dtype=float32)
        dev, avg = std_mean(lst)
        return dev.item(), avg.item()

    def SwitchWeightDecay(self, x_norm: float) -> None:
        "toggle WD periods (3500 steps)"
        if False:  # 1= dauerdecay, 0= wechseldecay(default)
            if (self.collects <= 4 or self.step_cnt > 85000):  # cooldown or not
                self.__weight_decay = min(1.0, (
                            self.__xoldnorm / x_norm) ** 0.00057)  # 0.00057=2/3500, this exponent is needed to decay in 3500 steps an increase over 7000 steps #self.__weight_decay_backup
                # assert(self.__weight_decay <= 1.0), "possible?"
                print('*decay with %.6f = 1 - %.3e' % (self.__weight_decay,
                                                       1.0 - self.__weight_decay))  # self.__weight_decay_backup)
                self.__weight_decay_on = True if (self.__weight_decay < 1.0) else None
        else:  # 0=default
            if (self.__weight_decay == 1.0):  # cooldown or not
                self.__weight_decay = min(1.0, (
                            self.__xoldnorm / x_norm) ** 0.00057)  # 0.00057=2/3500, this exponent is needed to decay in 3500 steps an increase over 7000 steps #self.__weight_decay_backup
                # assert(self.__weight_decay <= 1.0), "possible?"
                print('*decay with %.6f = 1 - %.3e' % (self.__weight_decay,
                                                       1.0 - self.__weight_decay))  # self.__weight_decay_backup)
                self.__weight_decay_on = True if (self.__weight_decay < 1.0) else None
            else:
                # if (self.collects >= 5):
                #    self.__weight_decay = sqrt(self.__weight_decay)
                #    print('*decay with %.6f = 1 - %.3e' % (self.__weight_decay, 1.0 - self.__weight_decay))
                # else:
                self.__weight_decay = 1.0
                self.__weight_decay_on = None
                print('*nodecay')
        return

    def GradientMerge(self, fkt: float, grad_fkt: tt.Tensor, x: tt.Tensor):
        "MicroBatchMerge: average gradients (micro-batch to dynamic mini-batch)"  # ResNet50+, LLM

        if (grad_fkt is None):
            self.coll_grad, self.coll_fxl = None, []
            self.step_cnt2 += 1  # optimizer makes an alpha update
            return fkt, 0.0, None  # inf = force retrace

        self.coll_cnt += 1

        assert (fkt < 1e38), "Function value maybe nan?"
        # if not (fkt < 1e38): # isnan(fkt), float32max = 3e38
        # self.coll_cnt -= 1
        #    return fkt, None, None  # skip this one (leave here)

        grad_nrm: float = grad_fkt.norm().item()
        if not ((grad_nrm < 65e3) or (grad_fkt.element_size() > 2)):  # float16 + big-alpha = nan-gradient
            self.coll_GradFails += 1
            print("Warn: Large Gradient, n=%.3g, cnt=%d, f=%.3g, a=%.3g, SKIP!" %
                  (grad_nrm, self.coll_GradFails, fkt, self.alpha))
            self.step_cnt2 += 1  # optimizer makes an alpha update
            return inf, 0.0, None  # force retrace

        hlen: int = len(self.coll_fxl)

        factor: float = 1.0 / self.collects

        if not hlen:
            self.coll_grad = grad_fkt.mul(factor)
        else:
            tt_add(self.coll_grad, grad_fkt, alpha=factor, out=self.coll_grad)

        self.coll_fxl.append(fkt)

        if (1 + hlen) < self.collects:
            return fkt, None, None  # continue collecting (leave here)

        # from here on, an actual step happens
        self.step_cnt += 1  # should happen here (do not count retrace steps)
        self.step_cnt2 += 1  # should happen here (do not count retrace steps)
        step_cnt: int = self.step_cnt

        if not (step_cnt & 3) and (step_cnt >= 100):  # once per 100 moving steps
            # if (self.__weight_decay_backup is not None): # < 1.0):
            #    if (self.decay_perm): # 1
            #        if not (step_cnt % 100): #3500):
            #            self.SwitchWeightDecay( x.norm().item() )
            #    else:
            #        if not (step_cnt % 3500):
            #            self.SwitchWeightDecay( x.norm().item() )
            # self.TestCollect(-1.1, grad_fkt)
            if not (step_cnt % 100):  # Tune-Here around 0.01
                modo: int = max(1, int(self.statlength / (
                            self.collects * self.BatchSizeExt))) * 100  # number of steps used for the average

                self.__retrace2 = 0
                if (self.step_cnt2 >= modo):  # Tune-Here around 0.01
                    dsr: float = 1.0 / (self.step_cnt2 - self.__retrace2)
                    xaver2 = sqrt(self.sumVar * dsr)
                    xaver: float = self.sumFvalue * dsr
                    # xaver2: float = sqrt(abs(self.sumSquareFvalue-self.sumFvalue*xaver) /(self.step_cnt2-self.__retrace2))
                    self.sumFvalue = self.sumSquareFvalue = 0.0
                    self.sumVar = 0.0
                    self.step_cnt2 = 0
                    # self.__retrace2 = 0
                    # assert xaver > 0.0, "this optimizer needs loss > 0"
                    print('xaver: %.6f ± %.6f, min: %.6f' % (xaver, xaver2, self.MinOfF))

                    # counting number of cycles with no progress
                    if (xaver > self.lastFmean):
                        self.lastRed += 1
                    else:
                        self.lastRed = 0
                    if xaver < self.lastFmean: self.lastFmean = xaver  # no min()
                    self.Increase = False
                    # if (self.lastRed >= 2):
                    if (self.lastRed >= 3):
                        self.Increase = True
                        # self.Increase3 = 1
                        self.lastFmean = xaver
                        self.lastRed = 0
                    self.train_loss_mean = 0.0
                    self.lastDev = xaver2
                    self.DevCorrection = 1.0
                    self.MinOfF = xaver # statistics, best loss value in last 100 steps
                    scol: int = self.collects
                    if (self.Increase):  # (step_cnt == self.cool):
                        scol = max(int(scol * 1.5), 2)
                        if (scol > self.upperBs):
                            self.Increase = False
                            # self.Increase = True
                            scol = self.lowerBs
                            self.upperBs = max(int(self.upperBs * 1.5), 2)
                            self.lowerBs = max(int(self.lowerBs * 1.5), 2)
                            self.lastFmean = self.lastMean
                            self.lastDev = self.lastlastDev
                        else:
                            self.lastMean = self.lastFmean
                            self.lastlastDev = self.lastDev
                    if (self.__classes != 1):  # 1 = math
                        self.collects = max(self.MinCollect, min(scol,
                                                                 6250))  # max(2, min(self.collects, 4000 // self.BatchSizeExt))  # effective bs<=2000
                g_col: float = self.coll_ggc * 0.01
                self.g_col = g_col
                # g_x = self.g_x * 0.01
                # self.g_x = 0.0

                # adjusting weight_decay based on discrepancy between train and validation
                if self.valid_loss is not None and self.train_loss is not None and self.valid_loss > 0.0 and self.train_loss > 0.0:
                    b = max(0.0, sqrt(max(0.0, 2.0 * max(1.0, self.valid_loss / self.train_loss) - 1.0)))
                    self.WD = min(3.0 * (self.collects ** 0.666), b)
                else:
                    self.WD = self.__weight_decay_backup  # external constant value

                if self.meanAngle < -2.0:
                    self.learningRateSchedule += 1.0
                else:
                    self.learningRateSchedule = max(0.0, self.learningRateSchedule - 1.0)

                print(
                    "# Increase collects=%d, steps=%d+%d+%d, G=%.3g, a=%.3g, CummScalarProd=%.3g, lr = %.3g." %
                    (self.collects, self.coll_cnt, self.step_cnt, self.coll_inc, g_col, self.alpha,
                     self.meanAngle, 1.0 / (1.5 ** self.learningRateSchedule)), flush=True)
                self.meanAngle = 0.0
                self.coll_cnt = 0  # self.step_cnt
                self.coll_inc += 1
                # self.step_cnt += 1  # prevent increase loop
                # self.step_cnt2 += 1  # prevent increase loop
                self.coll_ggc = 0.0
                self.__retrace = False
                self.InternalsSave()

        # self.coll_grad /= self.collects

        self.coll_grad, rv = None, self.coll_grad  # todo: create rv in-place (save memory)

        fc_dev, fkt = self.StdDev(self.coll_fxl)
        self.coll_fxl = []  # reset lists (self.coll_ggl)
        return fkt, fc_dev, rv

    # def c2min_pv_step(self, x: tt.Tensor, fkt: float, grad_fkt: tt.Tensor, fkt_alpha: float = None, combi_step: bool = False):

    # @jit(nopython=True, nogil=True)
    def growth_func(self) -> float:  # CFFI
        """
        defines the growth function for the parabola-fitting algo
        :return: gives the growth value
        """
        # A1 = 1000000.0, A2 = 855000
        damp: float = self.__growthdamper
        if (self.__retrace):
            if (damp > 1.0):
                if (damp < (1000000.0 / 16.0)):
                    damp *= 16.0
                else:
                    damp = 855000.0
            else:
                damp += 16.0
        else:
            damp *= (1.0 / 3.9)
        self.__growthdamper = damp
        return 1000000.0 / (1.0 + damp)

    # @jit(nopython=True, nogil=False)
    def __alpha_opt_version(self, alpha: float, f: float, fold: float, yg, yg_old) -> float:
        """
        sets the adaptive stepwidth by fitting a parabola to the function choosing
        the minimum value and extrapolating on the basis of this minimum
        :param alpha:
        :param f:
        :param fold:
        :param yg_old:
        :return:
        """

        Ga: float = self.__norm_yg_old * self.__norm_yg_old  # tt.dot(yg_old, yg_old).item()
        g: float = self.growth_func()  # also internal update of the growthdamper
        if (self.__retrace):
            self.meanAngle -= 0.4
            if (self.upperBs <= 6):
                self.overestH = max(0.1, self.overestH - 0.01)
            d: float = (f - fold) + alpha * Ga
            m: float = (0.5 * alpha * Ga) / d  # crash DIV/0
            if (m < inf):  # isnan(m) or isinf(m), 1e999==inf (fastest)
                self.lr *= m
                # alpha *= m
                self.lrOld = m
            else:
                alpha *= 1.0 / 100.0
            return max(min(alpha, 1.0e6), 1.0e-12)  # return alpha
        else:
            S: float = dot(yg, yg_old).item()  # here Skalarprodukt
            self.S = S / Ga  # / yg_old.norm().item() / yg_old.norm().item()
            self.lrOld = sqrt(self.lrOld)
            h: float = 1.0 - (S / Ga)  # (Ga - S) / Ga
            NormNorm: float = self.__norm_yg_old
            self.__norm_yg_old = yg.norm().item()
            if (g * h < 1.0):
                alpha *= g
            else:
                if yg.numel() <= 20:
                    alpha /= h
                else:
                    alpha = sqrt(self.lr * self.lr + alpha * alpha) / h
                    # alpha /= h * (1.0 - self.overestH / (1.0 + 0.5 * self.alpha * self.alpha))

        # clipping of the actual step, not the gradient
        self.lr = min(self.lrOld * 1.0 / 1.5 ** (self.learningRateSchedule + self.Increase),
                      self.lrOld * 0.0001 * self.step_cnt)
        N: float = self.lr * self.__norm_yg_old
        if (self.__clipping < N):  # hier evtl auf float32 testen
            # alpha *= self.__clipping / N
            self.lr *= self.__clipping / N
        # if(self.collects <= 4):
        #    return max(min(alpha, 1.0e6), 0.01/self.__norm_yg_old)  # restricts alpha to 1e-8...1e+6
        if self.S > 0.0:  # not self.S == 0.0:
            alpha = min(alpha, self.lr / abs(self.S))  #
        self.meanAngle += alpha * self.S
        return max(min(alpha, 1.0e6), 1.0e-8)  # restricts alpha to 1e-8...1e+6

    # def UpdateErrorDamper(self, currfktlesslastfkt: bool) -> None:  # todo: cffi
    #    "unused"
    #    error: float = self.__errordamper
    #    if currfktlesslastfkt:  # update of the errordamper depending on worsening of result without retrace
    #        self.__errordamper = error * (1.0 / 1.69)
    #    else:
    #        if (error < 1.0):
    #            self.__errordamper =  error + 16.0
    #        else:
    #            self.__errordamper = (error * 16.0) if (error < 500000.0) else 500000.0 # why not max() ?
    #    return

    # def CalcErrorTolerance(self, truebestfkt: float) -> float:  # CFFI
    #    # self.__truebestfkt = truebestfkt
    #    return 25.0 + (2500.0 + 71.0 * sqrt(truebestfkt)) / (1.0 + sqrt(self.__errordamper))

    # was: p2min_step
    def step(self, x: tt.Tensor, fkt: float, grad_fkt):
        """
        performs a single self-consistent gradient descent step updating the global
        storage accordingly for the next step
        :param x: Tensor
        :param fkt: f(x) function-value = e.g. loss
        :param grad_fkt: gradient = yg
        :combi_step: averaged x for combi_step (once per epoch, if benefitial only)
        :return: tuple(x,_,_) | bool
        """

        fkt = float(fkt)
        self.epoch_calls_tmp += 1

        if (self.collects is not None):  # <2=off
            fkt, fc_dev, grad_fkt = self.GradientMerge(fkt, grad_fkt, None)  # x unused
            if (fc_dev is None):
                return None, None, False
        # enable collect happens below in first (non-collect) step !

        # self.step_cnt += 1

        # load function values
        x0_norm: float = x.norm().item()

        if self.collects is None or grad_fkt is None:
            # curr_fkt: float = fkt + 0.005 * (x0.norm().item()**2)
            curr_fkt: float = fkt
        else:
            if self.WD:  # avoid crash DIV0 for math problems
                kappa: float = (1.0 * 0.005) / x0_norm
                kappa *= self.g_col if (self.g_col > 0.0) else grad_fkt.norm().item()
            # if self.g_col > 0.0:
            #    kappa: float = 1.0*0.005*self.g_col / x0_norm
            # else:
            #    kappa: float = 1.0*0.005*grad_fkt.norm().item() / x0_norm
            curr_fkt: float = fkt

        if grad_fkt is not None and self.collects is not None:
            if self.WD:  # skip if WD=off
                # a: float = (self.WD * kappa) * (4.0 if self.collects >= self.upperBs else 2.0)
                a: float = (self.WD * kappa) * (4.0 if self.Increase else 2.0)
                if self.WD_groups is None:  # single group (usually)
                    tt_add(grad_fkt, x, alpha=a, out=grad_fkt)  # new WD here
                else:
                    self.grad_WD(grad_fkt, x, a)  # was xstep()
        yg = grad_fkt

        self.solversteps += 1
        # tiny_x: bool = False  # x.numel() <= 20  # len(x)

        self.__xoldnorm = x0_norm  # x.norm().item()
        if (self.__init):
            self.sumFvalue = curr_fkt
            self.sumSquareFvalue = curr_fkt * curr_fkt
            self.MinOfF = curr_fkt  # self.MinOfF2 = curr_fkt
            # self.alpha = 0.00001  # not important
            self.FirstFnktVal(curr_fkt, x.numel(), False)
            self.__yg_old = yg
            # self.g_x += dot(x, yg) / self.__xoldnorm
            self.__norm_yg_old = yg.norm().item()
            self.g_col = self.__norm_yg_old
            # c_InitOptimP2M(0.0, 0.0); # CFFI

            tt_add(x, yg, alpha=-self.alpha, out=x)
            return x, None, False
        else:
            if (curr_fkt < self.__best_fkt): self.__best_fkt = curr_fkt
            start: bool = curr_fkt < (1.1 * self.__initfkt)
            # self.CalcErrorTolerance(self.__truebestfkt)
            # errorTolerance: float = 25.0 + (2500.0 + 71.0 * sqrt(self.__truebestfkt)) / (1.0 + sqrt(self.__errordamper))
            # if start and (curr_fkt < errorTolerance * 1.1 * self.__truebestfkt):
            # if start and (curr_fkt < self.lastFmean + 5.0 * self.lastDev) and yg is not None:
            if start and (curr_fkt < self.lastFmean + 5.0 * self.lastDev * self.DevCorrection) and yg is not None:
                self.DevCorrection = max(1.0, self.DevCorrection / 1.05)
                step_cnt2: int = self.step_cnt2  # faster (avoid self.)
                if (step_cnt2 > 0):  # computing function mean and std-deviation recursively here
                    self.sumFvalue += curr_fkt
                    dsr: int = (step_cnt2 - self.__retrace2 + 1)
                    helper: float = self.sumFvalue - (dsr * curr_fkt)
                    self.sumVar += (helper * helper) / (step_cnt2 * step_cnt2)  # (step_cnt2 * dsr)
                else:
                    self.sumFvalue += curr_fkt
                    self.sumVar = 0.0
                if (self.step_cnt <= step_cnt2):  # update mean and std-dev in beginning always
                    dsf: float = 1.0 / (step_cnt2 - self.__retrace2 + 1)
                    self.lastFmean = self.sumFvalue * dsf
                    self.lastDev = sqrt(self.sumVar * dsf) * (1.05 ** self.__retrace2)
                self.sumSquareFvalue += curr_fkt * curr_fkt
                if (curr_fkt < self.MinOfF): self.MinOfF = curr_fkt # avoid call min(,)
                self.x_lastgood = x.clone() # perhaps only for float16

                # simple step based on learning rate lr
                self.__last_fkt = curr_fkt
                self.__retrace = False
                self.alpha = self.__alpha_opt_version(self.alpha, curr_fkt, curr_fkt, yg, self.__yg_old)
                # self.__yg_old = yg
                if (self.__weight_decay_on is not None):  # decays the parameters, optional
                    # x -= tt_add(x * (1.0 - self.__weight_decay), yg, alpha=self.alpha)
                    # tt_add(x, self.__yg_old, alpha=min(self.alpha * self.S, 0.0) - self.HH, out=x)
                    tt_add(x, self.__yg_old, alpha=self.alpha * self.S - self.lr, out=x)
                    x -= tt_add(x * (1.0 - self.__weight_decay), yg, alpha=self.lr)
                    # x *= 2.577/x.norm()
                    # if (x.element_size() >= 4): # float32
                else:
                    # tt_add(x, self.__yg_old, alpha=self.alpha * self.S - self.HH, out=x)
                    tt_add(x, self.__yg_old, alpha=(self.alpha - self.lr) * self.S, out=x)
                    tt_add(x, yg, alpha=-self.lr, out=x)
                    # tt_add(x, yg, alpha=-self.alpha, out=x)  # in-place (out=x was crash)
                # self.UpdateHistoryFx(curr_fkt)
                self.__yg_old = yg
            else:
                self.DevCorrection *= 1.05
                old_retrace: bool = self.__retrace
                self.__retrace = True
                self.__retrace2 += 1
                
                # increase self.collects if too many retraces
                # if (self.__retrace2 > 25):
                if ((self.__retrace2 % 26) == 25):
                    self.lastRed = 0
                    self.collects = max(int(self.collects * 1.5), 2)
                    if (self.collects >= self.upperBs):
                        self.upperBs = max(int(self.upperBs * 1.5), 2)
                        self.lowerBs = max(int(self.lowerBs * 1.5), 2)
                    # self.__retrace2 = 0
                # self.alphaRed *= 1.1
                __last_fkt: float = self.__last_fkt  # constant
                if (__last_fkt <= self.__truebestfkt):
                    self.__truebestfkt *= 10.0
                else:
                    self.__truebestfkt *= (__last_fkt / self.__truebestfkt) ** 0.125
                # if (self.__retrace2 == 2) and (self.collects is not None):
                #    self.collects += 2
                # retracing to the previous x
                old_alpha: float = self.alpha
                # computation of new alpha
                self.alpha = self.__alpha_opt_version(old_alpha, curr_fkt, __last_fkt, yg, self.__yg_old)
                __yg_old: tt.Tensor = self.__yg_old  # constant below
                print("Retrace(%d): f=%.3g(%.3g), a=%.3g, gn=%.3g, or=%d" %
                      (self.__retrace2, curr_fkt, __last_fkt, old_alpha, __yg_old.norm().item(), int(old_retrace)))
                if (self.x_lastgood is not None):
                    axn: float = x.norm().item()
                    # x = self.x_lastgood - tt_add(self.x_lastgood * (1.0 - self.__weight_decay), __yg_old, alpha=self.alpha)
                    # tt_add(self.x_lastgood, __yg_old, alpha=-self.alpha, out=x)
                    tt_add(self.x_lastgood, __yg_old, alpha=-self.lr, out=x)
                    print("RX = %.6g, %.6g, %.6g" % (self.x_lastgood.norm().item(), x.norm().item(),
                                                     axn))  # debug (3x norm() = slow!)
                else:
                    if (self.__weight_decay_on is not None) and (not old_retrace):
                        decay_inv: float = 1.0 / self.__weight_decay  # >1
                        x += tt_add(x * (decay_inv - 1.0), __yg_old, alpha=old_alpha * decay_inv - self.alpha)
                    else:
                        tt_add(x, __yg_old, alpha=old_alpha - self.alpha, out=x)

                    t1, t2 = tensor(old_alpha), tensor(self.alpha)  # old_alpha>self.alpha
                    # x = SelfConstOptim.single_gradient_descent_step(x, -self.alpha, __yg_old)
                    if 0.0 == float((t2 - t1) - t2):  # <(1e-4 or 1e-8)
                        # 2nd computation of new x with new alpha (in round=0 case, float16)
                        tt_add(x, __yg_old, alpha=-self.alpha, out=x)  # in-place (combined with last add)
                # x = SelfConstOptim.single_gradient_descent_step(x, self.alpha, __yg_old)

            # if (curr_fkt < self.__truebestfkt):  # setting new best function, if actual better
            #    self.__truebestfkt = curr_fkt
            # else:
            #    self.__truebestfkt *= 1.1
            # self.UpdateErrorDamper(currfktlesslastfkt)  # self (CFFI)

            # statistic
            col: int = 0 if (self.collects is None) else self.collects
            # gstat.statist_AddNumbers([self.__norm_yg_old**0.5, self.alpha, self.__weight_decay, self.__growthdamper, 500000.0, col])
            self.coll_ggc += self.__norm_yg_old

            # f: compute the function value (for output-purposes only)
            if (curr_fkt < self.__best_fkt): self.__best_fkt = curr_fkt  # update_best_values()
            return x, None, self.__retrace

# EoF.
