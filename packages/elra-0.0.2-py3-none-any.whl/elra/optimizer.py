#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
File: elra_optimizer.py
Project: elra-optimizer
Author: Alexander Kleinsorge; Alexander Fauck
Contributor(s): Felix Rothe; Stefan Kupper; Richard Fiebelkorn
Created: 27.02.23
Organization: Technische Hochschule Wildau (TH Wildau)
Description: ELRA (Efficient Loss-Range-Aware) optimizer for PyTorch, based on the original C++ implementation by
Alexander Kleinsorge. This optimizer implements the Cosine to Minimum (C2M) and Power to Minimum (P2M) algorithms for
efficient optimization in deep learning. The optimizer is designed to be compatible with PyTorch's optimization framework
and can be used as a drop-in replacement for standard optimizers like Adam or SGD.

Copyright (c) 2026 TH Wildau. All rights reserved.

See the LICENSE file in the project root for full license information.
"""

# rename: Cos2MinTorchFunctionOptimizer -> ELRA_class.py (tbd 2024)

__version__ = '2026.02.24'

import torch
from torch import cat as torch_cat
from torch.nn import Module

from . import lib_grad_solve

_device_cpu: torch.device = torch.device('cpu')
# compile_cnt: int = 0


# ToDo: can't this be a static member of the class?
def _set_model_parameter(theta: torch.Tensor, SetModelCfg: tuple) -> None:
    """
    Set the model parameters back from a flat tensor. This function takes a flat tensor `theta` and a configuration
    tuple `SetModelCfg` that contains the model parameters, their split sizes, and their original shapes. It reshapes
    the corresponding segments of `theta` back to their original shapes and updates the model parameters in-place.

    :param theta: Tensor holding all model parameters.
    :type theta: torch.Tensor
    :param SetModelCfg: Configuration tuple containing the model parameters, their split sizes, and their original shapes.
    :type SetModelCfg: Tuple[List[torch.Tensor], str, List[int]] TODO: check the type
    :return: Nothing
    :rtype: -
    """

    "set model param(theta) - RF (allow freezed Layers)"
    params, split, sizes = SetModelCfg

    for p, t, s in zip(params, theta.split(split), sizes):
        p.data = t.reshape(s)
        # d = t.reshape(s)
    return


# was: SelfConstOptimTorch
class ElraOptimizer(torch.optim.Optimizer):

    from enum import Enum
    class Mode(Enum):
        c2min = 1
        # c2min_check = 2
        p2min = 3 # default

    def __init__(self, params, model=None, batch_size: int=8, classes: int=0,
                 lr: float=1e-5, mode:Mode = Mode.p2min, dummy=None, momentum: float=None,
                 weight_decay: float=1.0, warmup: int=1) -> None:
        """
        Gradient descent optimizer, similar to torch.optim.Optimizer,
        but internal adjusted hyper-parameters.
        
        :param params: Model parameters to optimize.
        :param model: The Model to optimize. - Not used for the algorithm but ... TODO: check if we can remove this parameter
        :param batch_size: TODO: check if we can remove this parameter
        :param classes: TODO: remoe this parameter
        :param lr: Learning rate. Elra likes tiny initial learning rates.Default: 1e-5
        :param mode: Operating mode. Default: Mode.p2min (Power to Minimum). Mode.c2min (Cosine to Minimum) is also available.
        :param momentum: Momentum factor (beta). Default: 0.0
        :param weight_decay: Weight decay factor. Default: 1.0
        :param warmup: Warmup steps (0..1000), similar to torch.optim.lr_scheduler.LRScheduler. Default: 1
        """

        # assert model is not None, "need torch model"
        assert batch_size >= 1, "positive number (seen by GPU)"
        assert classes >= 0, "labels"  # 0..1 = math
        assert lr > 0.0, "negative learning rate"
        # assert momentum >= 0.0, "positive momentum (beta)"

        self._ModelParaSet: tuple | None = None
        self._SetModelCfg: tuple | None = None  # (model, SplitList, ParSizes)
        self._ParamGroupSet: tuple | None = None
        self.__optim_instance = None
        self.elra_TFO_dim: int|None = None
        self.param_bak: torch.Tensor|None = None  # backup (cache)

        paralist: tuple = tuple([ p for p in params ])
        defaults: dict = {}
        super().__init__(paralist, defaults)

        # if (mode != ElraOptimizer.Mode.c2min):
        #     from . import lib_grad_solve  # P2M (default)
        # else:
        #     from . import lib_grad_solve_c2m as lib_grad_solve  # C2M
        # __optim_step = lib_grad_solve.SelfConstOptim.step  # c2min_pv_step, p2min_step


        if (lr >= 1e-3): print("#WARN: ELRA optimizer likes tiny initial LR (1e-6..1e-4)", lr)
        if model is not None:
            print("#HINT: model arg unused (historic)")
            self.print_model_stat(model)  # debug help

        if weight_decay >= 0.0 and weight_decay < 0.5:
            print('# change weight_decay=%.6f ==> %.6f !' % (weight_decay, 1.0 - weight_decay))
            weight_decay = 1.0 - weight_decay  # should be 0.999 .. 1.000

        # self.batch_size: int = batch_size  # 8, 32, .. TODO: transfer into LGS
        # print(params) # generator object Module.parameters
        # ToDo: rename and set '_'-prefix
        self.CalcParaAvg: bool|None = None # Booster on/off (False=None)
        self.BoosterTarget: int = 240 # 0 = off (even)
        self.BoostModel = None
        self.ParaLossSum: float = 0.0
        self.ParaAvgCount: int = 0
        self.ParaLossCount: int = 0
        self.ParaAvgTensor: torch.Tensor|None = None
        self.FullBoostTensor: torch.Tensor|None = None # last complete
        self.LastBoostTensor = None  # debug: print progress(x)
        self.BoostEpoch: bool = False
        self.FullBoostLoss: float = 0.0
        self.BoostCount: int = 0
        self.LastEpochSteps: int = 0
        self.EpochSteps: int = 0  # since last Booster
        self.RetraceCount: int = 0
        # self.ChangedParam: torch.Tensor = None
        self.ChangedParam: bool = False
        # self.BatchNormBak = None

        # self.InitialParam(paralist)
        # self.SetClasses(classes, batch_size)

        dim: int = sum(p.numel() for p in self._ModelParaSet)  # model.parameters()
        assert dim > 0, "model dim count"

        self.__optim_instance = lib_grad_solve.SelfConstOptim(dim, batch_size, classes, lr=lr, momentum=momentum, wd=weight_decay, warmup=warmup)

        self.step_call = self.__optim_instance.step  # getattr(self.__optim_instance, 'step')
        assert callable(self.step_call), "function needed: step()"

    def state_dict(self) -> dict:
        """get state_dict"""
        sd = vars(self.__optim_instance)
        for e in sd:
            v = sd[e]
            if type(v) is (torch.Tensor):
                sd[e] = None
        return sd

    def load_state_dict(self, state_dict:dict) -> None:
        """see torch.optim.Optimizer.load_state_dict() - NotImplementedError"""
        self.__optim_instance.load_state_dict( state_dict )

    @staticmethod
    def copy_model(model: Module, mode: str='default', device: object=None) -> Module:
        """
        create a 2nd model, for booster

        :param model: the original model
        :type model: torch.nn.Module
        :param mode: 'default' or 'off'
        :type mode: str
        :param device: the device to move the model to
        :type device: object TODO: is this not a torch.device?
        :return: the copied model
        :rtype: torch.nn.Module

        """
        from copy import deepcopy
        from pathlib import Path
        import torch._dynamo
        from torch._dynamo.testing import CompileCounter
        assert model is not None, "needs model"
        fn: str = "compile_skip"

        model_boost = deepcopy(model) # ELRA-Booster
        device1 = next(model.parameters()).device
        if (device is not None):
            print("model.device =", str(device1), ", boost =", str(device))
            model_boost.to(device)

        if (mode == 'off'):
            print("deepcopy(model), no compile(), mode =", mode)
            return model_boost

        # TODO: check status of this bug!
        cc_fc: int = CompileCounter().frame_count
        #if (cc_fc < 1): # 0 even for compiled models ?
        #    print("deepcopy(model), no compile(),", mode, cc_fc)
        #    return model_boost

        if Path(fn).is_file():
            # https://github.com/pytorch/pytorch/issues/128121
            # 2nd compile of deepcopy(model) fails on multiple ubuntu-pc (fatal error: Python.h: file not found)
            print("Detected Compile Blocker (for issue #128121) !", fn)
            return model_boost

        assert hasattr(torch, 'compile'), "requires PyTorch 2.x (2024)"

        return model_boost

    def set_param(self, x: torch.Tensor) -> None:
        """
        debug: set x (jump)

        :param x: the new parameter values
        :type x: torch.Tensor
        """
        if x is None: return
        assert x.numel() == self.elra_TFO_dim, "Tensor size conflict"
        assert self.param_bak.device == x.device, "Tensor device conflict"

        y = x.clone()
        self.param_bak = y
        _set_model_parameter(y, self._SetModelCfg)
        self.__optim_instance.LGS_SoftReset()
        return

    def get_param(self, only_new: bool, device: torch.device) -> torch.Tensor | None:
        """
        get param x (used for MultiGpu only)

        :param only_new: only return new values (True) or all (False)
        :type only_new: bool
        :param device: the device to move the returned tensor to
        :type device: torch.device
        """
        param_bak = self.param_bak

        # if param_bak is None: self.InitialParam()  # only SMP
        assert self.elra_TFO_dim is not None, "model w/o param"

        if only_new and not self.ChangedParam: return None
        self.ChangedParam = False

        if device == _device_cpu:
            return param_bak.to(_device_cpu, copy=True).pin_memory()
        return param_bak.to(device, non_blocking=True, copy=True)

    def set_valid_loss(self, loss: float, boost: float=None) -> None:
        """
        set validation loss (optional), controls only weight_decay.

        :param loss: Loss value to set for validation # ToDo: is that correct?
        :type loss: float
        :param boost: Loss value of booster position. See get_boost_model()
        :type boost: float
        :return:
        :rtype:
        """
        self.__optim_instance.SetValidLoss(loss, boost)
        return

    def set_train_loss(self, loss: float, boost: float=None) -> None:
        """
        set valid_loss (optional)

        :param loss: Loss value from full-batch training data.
        :type loss: float
        :param boost: Loss of from training data with booster. See get_boost_model()
        :type boost: float
        :return:
        :rtype:
        """
        self.__optim_instance.SetTrainLoss(loss, boost)
        self.__optim_instance.LGS_TellTrainBoostLoss(boost)  # why another call?
        return

    #def tell_train_boost_loss(self, train_loss: float) -> None:
    #    """
    #    debug: tell train_loss of boost-params (if avail) - moved to set_train_loss()
    #
    #    :param train_loss: Loss of from training data with booster. See get_boost_model()
    #    :type train_loss: float
    #    :return:
    #    :rtype:
    #    """
    #    self.__optim_instance.LGS_TellTrainBoostLoss(train_loss)
    #    return

    def set_classes(self, classes: int, gpubatchsize: int) -> None:
        """
        inform the solver about class-count (helpful for noise estimation.)
        :param classes: TODO not used - so remove it?
        :type classes:
        :param gpubatchsize: TODO: not used - so remove it?
        :type gpubatchsize:
        :return:
        :rtype:
        """
        assert type(self.__optim_instance).__name__ == "SelfConstOptim", "ELRA-LGS only"
        print("(SetClasses already in init)")  # will be removed soon
        # assert self.elra_TFO_dim is None, "set before first solver.step()"
        # self.__optim_instance.LGS_SetClasses (classes, gpubatchsize)


    def check_next_step(self) -> tuple[bool, int]:
        """
        check if next step is real vs. collect-only (only for MultiGpu SMP/DDP)
        :return:
        :rtype:
        """
        return self.__optim_instance.LGS_CheckNextStep()

    def set_lgs_device(self, dev: torch.device=None) -> None:
        """
        Move LGS-Tensors to device to free GPU ram during fullbatch (end of epoch).
        This reduces GPU-memory usage during full-batch operations (no steps there).
        
        :param dev:
        :type dev:
        :return:
        :rtype:
        """
        assert type(self.__optim_instance).__name__ == "SelfConstOptim", "ELRA-LGS only"
        if self.elra_TFO_dim is None: return
        if self.elra_TFO_dim > (20 << 20):  # RN34 = 21mio
            self.__optim_instance.LGS_SetDevice (dev)
        return

    def _calc_boost_tensor(self) -> None:
        """
        epoch x average (internal)
        """
        if self.ParaAvgCount < 2:  # reset: should never happen
            print("CalcBoostTensor:reset", self.ParaAvgCount)
            self.ParaAvgTensor, self.ParaAvgCount = None, 0
            self.FullBoostTensor = None
            return

        self.FullBoostLoss = 0.0 if (self.ParaLossCount < 1) else \
            (self.ParaLossSum / self.ParaLossCount)

        self.ParaAvgTensor *= 1.0 / self.ParaAvgCount  # in-place average
        self.BoostEpoch = True
        if True:  # debug: print progress(x)
            pat, lbt = self.ParaAvgTensor, self.LastBoostTensor
            self.BoostCount += 1
            if self.BoostCount < 10:
                fn:str = str('boost_%02d.pt' % self.BoostCount)
                # pat.save(fn) # debug
            if lbt is not None:
                d = pat.dist(lbt).item()
                e = pat.dist(self.param_bak).item()  # x(now) <> boost(now)
                print("BoostDistX = %.3E / %d, bc=%d, dxb=%.3E" % (d, self.ParaAvgCount, self.BoostCount, e))
            self.LastBoostTensor = self.FullBoostTensor

        self.ParaAvgTensor, self.FullBoostTensor = None, self.ParaAvgTensor
        self.ParaLossCount, self.ParaLossSum = 0, 0.0
        # print("BoostCalc:", self.ParaAvgCount, self.LastEpochSteps) # debug
        self.ParaAvgCount = 0
        return

    def get_boost_future(self, t: float) -> torch.Tensor:
        """
        debug: try boosted prediction (future), 0 < t < 2?
        TODO: does debug means it is only used for debug purpose?
        :param t:
        :type t:
        :return:
        :rtype:
        """
        if not (t > 0.0):
            # print("+++ GetBoostFuture1 +++", type(self.FullBoostTensor), t)
            assert 0.0 == t, "positive prediction point (future)"
            return self.FullBoostTensor
        # print("+++ GetBoostFuture2 +++", type(self.LastBoostTensor), t)
        if self.LastBoostTensor is None: return None
        # pred = now + t*(now - last)
        return (self.FullBoostTensor * (1.0 + t)) - (self.LastBoostTensor * t)

    def _get_param_avg(self, enable: bool):
        """
        internal: control local param averaging + reset avg. + return vector (for booster)
        :param enable: enable (True) or disable (False) param averaging
        :type enable: bool
        :return: count of steps, average loss, boost tensor (or None)
        :rtype: tuple[int, float, torch.Tensor|None]
        """
        assert type (self.__optim_instance).__name__ == "SelfConstOptim", "ELRA only"
        loss: float = self.FullBoostLoss
        count: int = self.EpochSteps
        self.CalcParaAvg = True if enable else None
        if enable:
            assert(self.BoosterTarget >= 2), "averaged step count"

        if count > 0: # once per epoch
            print("GetParamAvg: c=%d+%d, l=%.6f, r=%d" % (count, self.ParaAvgCount, loss, self.RetraceCount))
            self.EpochSteps, self.LastEpochSteps = 0, count

        if (not enable) or (count < 4): # <4 steps/epoch
            if enable and count: print("GetParamAvg.count=", count)
            self.FullBoostTensor = None  # avoid double boost usage (valley-cut)
            return 0, loss, None

        para_avg_count: int = self.ParaAvgCount
        if (not self.BoostEpoch) and (para_avg_count > 0): # not enough real steps
            if (self.BoosterTarget < 999999999):
                print("GetParamAvg:BoostEpochSwitch(%d<%d,rm=%d)" %
                    (count, self.BoosterTarget, para_avg_count))
                self.BoosterTarget = 999999999 # never within epoch (internal constant, e.g. INT_MAX)
                # self.ParaAvgTensor, para_avg_count = None, 0 # forget incomplete sum
                # return count, loss, None # this epoch w/o boost
            if para_avg_count >= 2: # minimum guess (only for very few steps/epoch)
                self._calc_boost_tensor() # create FullBoostTensor if possible
            else:
                print("Warn:SkipLowBoost(pac=%d, epoS=%d)" % (para_avg_count, count))

        if self.FullBoostTensor is not None:
            print("self.FullBoostTensor=", self.FullBoostTensor.norm(), count) # debug
        ret, self.FullBoostTensor = self.FullBoostTensor, None
        self.ParaAvgTensor, self.ParaAvgCount = None, 0
        self.ParaLossSum, self.ParaLossCount = 0.0, 0
        self.BoostEpoch = False
        return count, loss, ret
        # ret_vect, self.FullBoostTensor = self.FullBoostTensor, None
        # return count, loss, ret_vect  #.to(self.param_bak.device),  None = NoNewBoostAvail


    @staticmethod
    def vec_stat(par: torch.Tensor) -> None:
        """
        Print Tensor statistic
        
        :param par: parameter tensor
        :type par: torch.Tensor
        :return:
        :rtype:
        """
        mi, ma = par.min(), par.max()
        if mi == ma:
            print("VecStat[%d], const = %.3e" % (par.numel(), mi))
            return
        me, sd = par.mean(), par.std()
        print("VecStat[%d], %.3e < %.3e ± %.3e < %.3e" % (par.numel(), mi, me, sd, ma))


    @staticmethod
    def print_model_stat(model: Module) -> None:
        """
        Print model details for each layer. Debug information.
        
        :param model:
        :type model:
        :return:
        :rtype:
        """
        if model is None: return
        sd: dict = model.state_dict()
        print("PrintModelStat[%d]:" % len(sd))
        for p in sd:
            print(p, end=": ")
            ElraOptimizer.vec_stat(sd[p])
        return

    def get_gradient(self) -> torch.Tensor:
        """
        optional helper for easy usage: extract gradient from model (same order as in solver)
        
        :return: gradient tensor
        :rtype:  torch.Tensor
        """
        # assert hasattr(params[0], 'grad')
        return torch_cat([par.grad.data.flatten() for par in self._ModelParaSet])

    def get_boost_model_prev(self) -> None | Module:
        """
        optional: get last used boost params Tensor (see boost_model)
        
        :return:
        :rtype:
        """
        return self.BoostModel
        # if self.BoostModel is None:  return None
        # return torch_cat([ p.data.flatten() for p in self.BstModelCfg[0] ])

    def get_boost_model(self, enable: bool, model=None, device=None) \
            -> tuple[int,float,Module]|tuple[int,float,None]:
        """
        get a 2nd model at boost x-position for full-batch score calculation.
        ELRA-Boosting is a cyclic equal averaging of model weights (usualy represented by x Tensor).
        This is similar to Stochastic Weight Averaging (SWA) or sometimes referred to as Polyak-Ruppert averaging,
        or averaged SGD (but there as exponential moving average EMA).
        This is helpful after warmup (first few epochs) and before reaching final convergence (normal loss reaching boosted loss).
        Gradient descent with huge learning rates (ELRA >1, in contrast to tiny values for Adam/SGD) shows significant advantage
        for loss and accuracy, which allows an early visible indication of later/final results reached.
        
        'Acceleration of stochastic approximation by averaging'. Boris T Polyak and Anatoli B Juditsky;
        SIAM Journal on Control and Optimization, 30(4):838–855, 1992.
        
        Similar to torch/SWALR, but for now separated.
        torch.optim.swa_utils.SWALR(opt, anneal_strategy="linear", anneal_epochs=1, )
        https://pytorch.org/blog/pytorch-1-6-now-includes-stochastic-weight-averaging/
        
        :param enable:
        :type enable: bool
        :param model:
        :type model: torch.nn.Module | None
        :param device: Device to copy the model to.
        :type device: torch.device | None
        :return:
        :rtype: tuple[int, float, torch.nn.Module] | tuple[int, float, None]
        """
        if enable:
            if self.BoostModel is None:
                assert model is not None, "need model for first activation"
                assert self._SetModelCfg is not None, "no optimizer init"
                print("deepcopy(model) for Boost ..")
                t3 = list(self._SetModelCfg)
                self.BoostModel = self.copy_model(model, device=device)
                t3[0] = tuple([ p for p in self.BoostModel.parameters() if p.requires_grad]) # !! TODO: group['params']
                # param_groups = self.GetParamsGroup(self.BoostModel)
                # t3[0] = tuple([ p for group in param_groups for p in group['params'] ])
                assert self.elra_TFO_dim == sum([ p.numel() for p in t3[0] ]), "param count diff"
                self.BstModelCfg, t3 = tuple(t3), None
            cnt, loss, xb = self._get_param_avg(True)
            if (not cnt) or (xb is None): return 0, 0.0, None
            _set_model_parameter(xb, self.BstModelCfg)
            return cnt, loss, self.BoostModel
        else:
            self.BoostModel = None
            self._get_param_avg(False)
            return 0, 0.0, None

    def extra_param(self, params: tuple | list, wd=None) -> None:
        """
        internal: initial export from model to this class
        :param params:
        :type params: tuple | list  TODO: why tuple or list?
        :param wd:
        :type wd: None TODO: only None or float allowed?
        :return:
        :rtype:
        """
        dim0, lay0 = sum([p.numel() for p in params]), len(params)
        # !!! select strategy !!!
        # mpl = tuple([ p for p in params ])  # old way (works for many nets)
        mpl = tuple([ p for p in params if p.requires_grad ])  # best way?
        # mpl = tuple([ p for group in self.param_groups for p in group['params'] ])  # frozen layers (R.F.)
        dim, lay = sum([p.numel() for p in mpl]), len(mpl)
        self.vec_stat(torch_cat([p.data.flatten() for p in mpl]))
        if wd is not None:
            if wd <= 0.0 or wd >= 1.0: wd = None
        if self._ModelParaSet is None:
            print("InitialParam: layers %d<%d, params %d<%d, pgs=%d" % (lay, lay0, dim, dim0, len(self.param_groups)))
            self._ParamGroupSet = ((dim, wd),)
        else:
            print("ExtraParam: layers %d<%d, params %d<%d, pgs=%d" % (lay, lay0, dim, dim0, len(self.param_groups)))
            self._ParamGroupSet += ((dim, wd),)
            mpl = self._ModelParaSet + mpl
        ParSizes  = tuple( [p.shape for p in mpl] )
        SplitList = tuple( [p.numel() for p in mpl] )
        # assert 1 == len(self.param_groups), "R.F. single group"
        assert 1 == len(set( [p.data.device.index for p in mpl] )), "many devices"
        self._ModelParaSet = mpl
        self._SetModelCfg = (mpl, SplitList, ParSizes)
        params_n = torch_cat([ par.data.flatten() for par in mpl ])
        self.elra_TFO_dim = params_n.numel()
        print("ParamCount = %d, norm = %.4g, lay=%d/2, dev=%s" % (self.elra_TFO_dim, params_n.norm().item(), len(SplitList), str(params_n.device)))  # device=CPU
        self.param_bak = params_n
        assert params_n.numel(), "debug"
        self.ChangedParam = True


    def add_param_group(self, param_group: dict) -> None:
        """
        Some DNN use parameter-groups (different hyper param in groups), which is provided here.
        As ELRA controls hyper-parameters by itself, only weight-decay ratios are considerd internaly (by design).
        super-class: optimizer.add_param_group({'params': pg}), e.g. for YOLO5
        
        :param param_group:
        :type param_group:
        :return:
        :rtype:
        """
        # https://github.com/pytorch/pytorch/blob/v2.9.0/torch/optim/optimizer.py#L1069
        # print("add_param_group, len=", len(param_group))
        assert len(param_group) > 0, "empty param_group"
        assert isinstance(param_group, dict), "see super()"
        super().add_param_group(param_group)
        params = param_group["params"]
        dim: int = sum([ p.numel() for p in params ])
        print("add_param_group:", type(params[0]), len( params ), dim)
        wd: float|None = param_group.get("weight_decay")
        self.extra_param(params, wd)
        gs: str = ''
        for g in param_group:
            p = param_group[g]
            gs += '+' + g + '(' + type(p).__name__ + ')'
            if g == 'weight_decay':
                print("  weight_decay =", str(p), type(p))  # TODO !
        if len(param_group) > 1: print("  " + gs)
        if self.__optim_instance is not None:  # for: super().__init__()
            assert self.elra_TFO_dim > 0, "empty optimizer ELRA"
            self.__optim_instance.add_param (dim, self._ParamGroupSet)


    def _booster_update(self, param: torch.Tensor) -> None:
        """
        internal: average x-param (each real step)
        :param param:
        :type param:
        :return:
        :rtype:
        """
        if (self.ParaAvgTensor is not None): # (self.ParaAvgCount >= 1):
            self.ParaAvgTensor += param
            self.ParaAvgCount += 1
        else:
            self.ParaAvgTensor = param.clone()  # clone needed
            self.ParaAvgCount = 1

        if (self.ParaAvgCount >= self.BoosterTarget):  # > 3 and even
            self._calc_boost_tensor()
        return

    # def zero_grad(self, set_to_none: bool=True) -> None:
    #    "model.zero_grad() = clear gradients : see super-class"
    #    self.__model.zero_grad(set_to_none)
    #    return

    # TODO: the signature of the step method does not match the signature of the optimizer class it inherits from.
    #  Consider replacing step with step_with_loss()?.
    def step(self, loss: float, scale: float|None=None) -> None:
        "ELRA (C2M + P2M) step (usualy float16)"
        # get X (params) and G (grads)
        param_bak = self.param_bak

        if not (loss < 1e999):  # 1e999=inf, check outside
            print("NoGrad: loss=%.3e, x.norm=%.3g !" % (loss, param_bak.norm()))
            params_n, _, retrace = self.step_call(  # getattr(..) (
                param_bak, loss, None )
        else:
            grads:list = [par.grad.data.flatten() for par in self._ModelParaSet]
            if (scale is not None):  # (scale != 1.0):
                params_n, _, retrace = self.step_call( # self.__optim_instance.p2min_step(
                    param_bak, loss, torch_cat(grads) * scale)
            else:
                params_n, _, retrace = self.step_call(
                    param_bak, loss, torch_cat(grads) )
            grads = None

        self.ParaLossSum += loss
        self.ParaLossCount += 1

        if params_n is None: return

        # no update step (collect average)
        _set_model_parameter(params_n, self._SetModelCfg)
        self.ChangedParam = True
        self.EpochSteps += 1  # moving steps

        if retrace:
            self.RetraceCount += 1
            self.param_bak = params_n
            # ImportBatchNorm(self.__model, self.BatchNormBak)
            return

        # self.BatchNormBak = ExportBatchNorm(self.__model)  # new 25.02.2025

        # (not retrace)
        if self.CalcParaAvg is not None: # and (self.param_bak is not None): # Booster
            self._booster_update(param_bak)

        self.param_bak = params_n

        return  # self.ParaAvgCount # BoosterFill

    def step_retrace(self, loss: float) -> None:
        "ELRA (C2min + P2min) retrace step (no gradient)"
        # return self.step(loss, None)

        param_bak = self.param_bak
        assert param_bak is not None, "normal cycle (not first)"

        print("NoGrad: loss=%.3e, x.norm=%.3g !" % (loss, param_bak.norm()))
        params_n, _, retrace = self.step_call( param_bak, loss, None )

        assert params_n is not None, "retrace is not coolect-only"
        _set_model_parameter(params_n, self._SetModelCfg)
        self.EpochSteps += 1  # moving steps

        assert retrace, "retrace = retrace"
        self.RetraceCount += 1
        self.param_bak = params_n
        self.ChangedParam = True
        # ImportBatchNorm(self.__model, self.BatchNormBak)
        return

    def step_noscale(self, loss: float, grad: torch.Tensor=None) -> None:
        "ELRA (C2min + P2min) normal step (no GradScaler, scale=1, mainly float32)"
        # return self.step(loss, 1.0)

        retrace: bool = False
        param_bak = self.param_bak

        if not (loss < 1e999):  # 1e999=inf
            return self.step_retrace(loss)

        if grad is None:
            # for param in self.__model.parameters():
            #     grads.append(param.grad.data.view(-1))
            params_n, _, retrace = self.step_call(  # self.__optim_instance.p2min_step(
                param_bak, loss, torch_cat([par.grad.data.flatten() for par in self._ModelParaSet]) )
        else:  # MultiGpu SMP only
            params_n, _, retrace = self.step_call(param_bak, loss, grad)

        self.ParaLossSum += loss
        self.ParaLossCount += 1

        if params_n is None: return

        # update step (no collect average)
        _set_model_parameter(params_n, self._SetModelCfg)
        self.ChangedParam = True
        self.EpochSteps += 1  # moving steps
        self.param_bak = params_n

        if retrace:
            self.RetraceCount += 1
            # ImportBatchNorm(self.__model, self.BatchNormBak)
            return

        # self.BatchNormBak = ExportBatchNorm(self.__model)  # new 25.02.2025

        # (not retrace)
        if self.CalcParaAvg is not None: # and (param_bak is not None): # Booster
            self._booster_update(param_bak)

        return

    def step_allinone(self, loss: float, grad: torch.Tensor=None) -> None:
        "make ELRA compatible to torch.optim.Optimizer (extra scaling costs)"
        assert 0, "TODO"
        if not (loss < 999.9):
            step_retrace(loss)
        else:
            # check grad ?
            step_noscale(loss, grad)
        return

# class ElraOptimizer
