"""DataFlow -- zero-config database framework (top-level package).

Provides a backwards-compatible ``DataFlow`` class with ``@db.model``
decorator and ``create_tables_sync()`` method::

    from dataflow import DataFlow

    db = DataFlow("sqlite:myapp.db?mode=rwc")

    @db.model
    class User:
        id: int
        name: str
        email: str = ""

    db.create_tables_sync()

All types are backed by the ``kailash-dataflow`` Rust crate via PyO3.
"""

from kailash._kailash import (
    DataFlow as _RustDataFlow,
    DataFlowConfig,
    DataFlowTransaction,
    FieldDef,
    FieldType,
    FilterCondition,
    ModelDefinition,
    QueryInterceptor,
    TenantContext,
)

from kailash.dataflow.filter import F
from kailash.dataflow.model import _DbNamespace
from kailash.dataflow.tenancy import with_tenant


# Global registry of active DataFlow instances for auto-registration
import weakref
_active_dataflow_instances: list[weakref.ref] = []


class DataFlow:
    """Database connection with ``@model`` decorator and table management.

    Wraps the Rust-backed DataFlow, adding the ``@model`` decorator
    and ``create_tables_sync()`` from the old Python DataFlow API.

    Args:
        database_url: The database connection URL.
        config: Optional ``DataFlowConfig`` for connection pool tuning.
    """

    def __init__(self, database_url: str, config: DataFlowConfig | None = None):
        # Ensure SQLite URLs have ?mode=rwc for file creation
        url = database_url
        if url.startswith("sqlite:") and "?" not in url:
            url = f"{url}?mode=rwc"
        self._inner = _RustDataFlow(url, config)
        self._model_decorator = _DbNamespace()
        self._registered_models: list[ModelDefinition] = []
        _active_dataflow_instances.append(weakref.ref(self))

    def model(self, cls):
        """Decorator to define a DataFlow model from class annotations.

        Inspects ``__annotations__`` and builds a ``ModelDefinition``,
        attaching it as ``cls._model_definition``. Also sets
        ``cls._dataflow_meta`` and ``cls._dataflow`` for backwards
        compatibility with old DataFlow SDK tests.

        Then registers the model with the underlying Rust DataFlow.
        """
        cls = self._model_decorator.model(cls)
        model_def = cls._model_definition
        # Backwards compat: old DataFlow set these internal attributes
        cls._dataflow_meta = {"registered": True, "model": model_def}
        cls._dataflow = self
        self._inner.register_model(model_def)
        self._registered_models.append(model_def)
        return cls

    def create_tables_sync(self) -> None:
        """Create database tables for all registered models (synchronous)."""
        self._inner.create_tables()

    def create_tables(self) -> None:
        """Create database tables for all registered models."""
        self._inner.create_tables()

    def register_model(self, model: ModelDefinition) -> None:
        """Register a ModelDefinition directly."""
        self._inner.register_model(model)
        self._registered_models.append(model)

    def register_nodes(self, registry) -> None:
        """Register DataFlow-generated CRUD nodes into a NodeRegistry."""
        self._inner.register_nodes(registry)

    def execute_raw(self, sql: str, params: list | None = None) -> None:
        """Execute a raw SQL statement (e.g. INSERT, UPDATE, DELETE).

        Note: ``params`` is accepted for API compatibility but the current
        Rust binding does not support parameterized raw queries.
        """
        self._inner.execute_raw(sql)

    def transaction(self):
        """Start a database transaction (context manager)."""
        return self._inner.transaction()

    def health_check(self) -> dict:
        """Check database connectivity."""
        return self._inner.health_check()

    def get_available_nodes(self) -> dict[str, list[str]]:
        """Return the CRUD node actions for each registered model.

        Returns a dict keyed by model name, with a list of available CRUD
        action names as value::

            {"Workspace": ["Create", "Read", ...], "AgentDefinition": [...]}
        """
        actions = [
            "Create", "Read", "Update", "Delete", "List",
            "Count", "Upsert", "BulkCreate", "BulkUpdate",
            "BulkDelete", "BulkUpsert",
        ]
        return {model_def.name: list(actions) for model_def in self._registered_models}

    def close(self) -> None:
        """Close the connection pool."""
        self._inner.close()

    @property
    def models(self) -> list:
        """List of registered model definitions."""
        return self._inner.models

    def __repr__(self) -> str:
        return f"DataFlow(models={len(self._registered_models)})"


# Provide a standalone db namespace for `from dataflow import db`
db = _DbNamespace()

__all__ = [
    "DataFlow",
    "DataFlowConfig",
    "DataFlowTransaction",
    "ModelDefinition",
    "FieldType",
    "FieldDef",
    "FilterCondition",
    "TenantContext",
    "QueryInterceptor",
    "db",
    "F",
    "with_tenant",
]
