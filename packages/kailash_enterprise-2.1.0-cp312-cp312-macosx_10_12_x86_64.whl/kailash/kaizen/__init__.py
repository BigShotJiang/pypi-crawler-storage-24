"""Kailash Kaizen — AI agent framework.

Re-exports Rust-backed AI agent types and Python compat helpers::

    # Rust-backed types
    from kailash.kaizen import Agent, AgentConfig, LlmClient
    from kailash.kaizen import CostTracker, OrchestrationRuntime
    from kailash.kaizen import ToolParam, ToolDef, ToolRegistry
    from kailash.kaizen import SessionMemory, SharedMemory
    from kailash.kaizen import AgentCheckpoint, InMemoryCheckpointStorage
    from kailash.kaizen import AgentCard, AgentRegistry, A2AProtocol
    from kailash.kaizen import TrustLevel, TrustPosture

    # Python compat helpers
    from kailash.kaizen import BaseAgent, HookManager
    from kailash.kaizen import InputField, OutputField, Signature
    from kailash.kaizen import InterruptManager, ControlProtocol
    from kailash.kaizen.agents import SimpleQAAgent, ReActAgent, RAGAgent
    from kailash.kaizen.pipelines import SequentialPipeline, ParallelPipeline

All Rust classes are backed by the ``kailash-kaizen`` crate via PyO3.
Python compat helpers provide higher-level patterns on top.
"""

from kailash._kailash import (
    # Core agent types
    Agent,
    AgentConfig,
    CostTracker,
    LlmClient,
    OrchestrationRuntime,
    # Tool system
    ToolParam,
    ToolDef,
    ToolRegistry,
    # Memory system
    SessionMemory,
    SharedMemory,
    # Checkpoint system
    AgentCheckpoint,
    InMemoryCheckpointStorage,
    FileCheckpointStorage,
    # A2A protocol
    AgentCard,
    AgentRegistry,
    InMemoryMessageBus,
    A2AProtocol,
    # EATP Trust framework
    TrustLevel,
    TrustPosture,
)

# Python compat: BaseAgent and hooks
from kailash.kaizen.agent import BaseAgent
from kailash.kaizen.hooks import HookManager
from kailash.kaizen.signature import InputField, OutputField, Signature
from kailash.kaizen.control import ControlProtocol, InterruptManager

__all__ = [
    # Core agent types (Rust)
    "Agent",
    "AgentConfig",
    "LlmClient",
    "CostTracker",
    "OrchestrationRuntime",
    # Tool system (Rust)
    "ToolParam",
    "ToolDef",
    "ToolRegistry",
    # Memory system (Rust)
    "SessionMemory",
    "SharedMemory",
    # Checkpoint system (Rust)
    "AgentCheckpoint",
    "InMemoryCheckpointStorage",
    "FileCheckpointStorage",
    # A2A protocol (Rust)
    "AgentCard",
    "AgentRegistry",
    "InMemoryMessageBus",
    "A2AProtocol",
    # EATP Trust framework (Rust)
    "TrustLevel",
    "TrustPosture",
    # Python compat: BaseAgent
    "BaseAgent",
    # Python compat: Hooks
    "HookManager",
    # Python compat: Signature
    "InputField",
    "OutputField",
    "Signature",
    # Python compat: Control
    "InterruptManager",
    "ControlProtocol",
]
