"""Pipeline patterns for multi-agent orchestration.

Pre-built pipeline patterns for composing agents::

    from kailash.kaizen.pipelines import SequentialPipeline, ParallelPipeline

    pipeline = SequentialPipeline([agent1, agent2])
    result = pipeline.run("Process this")
"""

from kailash.kaizen.pipelines.ensemble import EnsemblePipeline
from kailash.kaizen.pipelines.parallel import ParallelPipeline
from kailash.kaizen.pipelines.router import RouterPipeline
from kailash.kaizen.pipelines.sequential import SequentialPipeline
from kailash.kaizen.pipelines.supervisor import SupervisorPipeline

__all__ = [
    "SequentialPipeline",
    "ParallelPipeline",
    "RouterPipeline",
    "EnsemblePipeline",
    "SupervisorPipeline",
]
