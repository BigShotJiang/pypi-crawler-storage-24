"""Pythonic BaseAgent wrapping Rust Agent types.

Provides a subclass-friendly interface for building AI agents::

    class MyAgent(BaseAgent):
        name = "my-agent"
        system_prompt = "You are helpful."

        def execute(self, input_text: str) -> dict:
            return {"response": f"Echo: {input_text}"}
"""

from __future__ import annotations

from typing import Any, Callable, Optional

from kailash._kailash import (
    AgentConfig,
    SessionMemory,
    SharedMemory,
    ToolDef,
    ToolParam,
    ToolRegistry,
)


class BaseAgent:
    """Subclass-friendly Python agent wrapping Rust Agent types.

    Class-level attributes can be overridden by subclasses or keyword arguments
    passed to ``__init__``.

    Attributes:
        name: Agent name.
        description: Agent description.
        system_prompt: System prompt for the agent.
        model: LLM model name (None = use default from env).
        max_iterations: Maximum TAOD loop iterations.
        temperature: Sampling temperature (None = provider default).
        max_tokens: Maximum response tokens (None = no limit).
    """

    name: str = "BaseAgent"
    description: str = ""
    system_prompt: str = ""
    model: Optional[str] = None
    max_iterations: int = 10
    temperature: Optional[float] = None
    max_tokens: Optional[int] = None

    def __init__(self, **kwargs: Any) -> None:
        for key in ("name", "description", "system_prompt", "model",
                     "max_iterations", "temperature", "max_tokens"):
            if key in kwargs:
                setattr(self, key, kwargs[key])

        self._config = AgentConfig(
            model=self.model,
            system_prompt=self.system_prompt or None,
            max_iterations=self.max_iterations,
            temperature=self.temperature,
            max_tokens=self.max_tokens,
        )

        self._tool_registry = ToolRegistry()
        self._memory: Optional[Any] = None
        self._hooks: dict[str, list[Callable[..., Any]]] = {}

    @property
    def config(self) -> AgentConfig:
        """The underlying Rust AgentConfig."""
        return self._config

    @property
    def tool_registry(self) -> ToolRegistry:
        """The tool registry for this agent."""
        return self._tool_registry

    @property
    def memory(self) -> Optional[Any]:
        """The attached memory instance (SessionMemory or SharedMemory)."""
        return self._memory

    def execute(self, input_text: str) -> dict:
        """Override point for subclasses.

        Args:
            input_text: The user input to process.

        Returns:
            A dict with at least a ``"response"`` key.

        Raises:
            NotImplementedError: If subclass does not implement this method.
        """
        raise NotImplementedError("Subclass must implement execute()")

    def register_tool(
        self,
        name: str,
        func: Callable[..., Any],
        description: str = "",
        params: Optional[list[dict[str, Any]]] = None,
    ) -> None:
        """Register a Python callable as a tool.

        Args:
            name: Unique tool name.
            func: Python callable that receives a dict of arguments.
            description: Description of the tool.
            params: Optional list of parameter dicts with keys:
                ``name``, ``param_type`` (default "string"),
                ``description``, ``required`` (default False).
        """
        tool_params = []
        if params:
            for p in params:
                tool_params.append(ToolParam(
                    name=p["name"],
                    param_type=p.get("param_type", "string"),
                    description=p.get("description"),
                    required=p.get("required", False),
                ))

        tool_def = ToolDef(name, description, func, tool_params or None)
        self._tool_registry.register(tool_def)

    def set_memory(self, memory: Any) -> None:
        """Attach a SessionMemory or SharedMemory instance.

        Args:
            memory: A SessionMemory or SharedMemory instance.

        Raises:
            TypeError: If the memory is not a supported type.
        """
        if not isinstance(memory, (SessionMemory, SharedMemory)):
            raise TypeError(
                f"Expected SessionMemory or SharedMemory, got {type(memory).__name__}"
            )
        self._memory = memory

    def __repr__(self) -> str:
        return f"{type(self).__name__}(name={self.name!r}, model={self.model!r})"
