"""Kailash Enterprise — high-performance Rust-powered workflow engine.

Drop-in replacement for the ``kailash`` Python SDK. Install with::

    pip install kailash-enterprise

This package uses the same ``import kailash`` namespace as the open-source
Python SDK, so existing code works without any import changes.

**New API (v2)** -- direct access to Rust-backed types::

    import kailash

    reg = kailash.NodeRegistry()
    builder = kailash.WorkflowBuilder()
    builder.add_node("NoOpNode", "n1")
    wf = builder.build(reg)
    rt = kailash.Runtime(reg)
    result = rt.execute(wf)
    # result is a dict: {"results": ..., "run_id": ..., "metadata": ...}

**Framework bindings** -- DataFlow, Enterprise, Kaizen, Nexus::

    from kailash._kailash import DataFlow, ModelDefinition, FieldType
    from kailash._kailash import RbacEvaluator, Role, User, Permission
    from kailash._kailash import Agent, AgentConfig, LlmClient, CostTracker
    from kailash._kailash import Nexus, NexusConfig, Preset

**Legacy API (v0.12 compatible)** -- drop-in replacement for the Python SDK::

    from kailash.runtime import LocalRuntime
    from kailash.workflow.builder import WorkflowBuilder

    builder = WorkflowBuilder()
    builder.add_node("NoOpNode", "n1")
    wf = builder.build()          # no registry arg needed
    runtime = LocalRuntime()
    results, run_id = runtime.execute(wf)  # returns (dict, str) tuple

Both APIs work simultaneously. The legacy API emits deprecation warnings
to guide migration to the new API.
"""

from kailash._kailash import (
    # Core
    NodeRegistry,
    RuntimeConfig,
    Runtime,
    Workflow,
    WorkflowBuilder,
    # DataFlow
    DataFlow,
    DataFlowConfig,
    DataFlowTransaction,
    ModelDefinition,
    FieldType,
    FieldDef,
    FilterCondition,
    TenantContext,
    QueryInterceptor,
    # Enterprise
    Permission,
    Role,
    User,
    RbacEvaluator,
    AbacPolicy,
    AbacEvaluator,
    AuditLogger,
    AuditFilter,
    AccessDecision,
    TenantStatus,
    TenantInfo,
    EnterpriseTenantContext,
    TenantRegistry,
    RbacPolicy,
    RbacPolicyBuilder,
    RoleBuilder,
    SecurityClassification,
    EnterpriseContext,
    # Kaizen
    AgentConfig,
    LlmClient,
    Agent,
    CostTracker,
    OrchestrationRuntime,
    # Kaizen - Tools
    ToolParam,
    ToolDef,
    ToolRegistry,
    # Kaizen - Memory
    SessionMemory,
    SharedMemory,
    # Kaizen - Checkpoint
    AgentCheckpoint,
    InMemoryCheckpointStorage,
    FileCheckpointStorage,
    # Kaizen - A2A
    AgentCard,
    AgentRegistry,
    InMemoryMessageBus,
    A2AProtocol,
    # Kaizen - Trust
    TrustLevel,
    TrustPosture,
    EatpPosture,
    VerificationConfig,
    VerificationResult,
    ResourceUsageSnapshot,
    HumanCompetency,
    CompetencyRequirement,
    ComplianceStatus,
    ComplianceReport,
    # Nexus
    Nexus,
    NexusConfig,
    HandlerParam,
    Preset,
    JwtConfig,
    JwtClaims,
    RbacConfig,
    AuthRateLimitConfig,
    MiddlewareConfig,
    McpServer,
)

__version__ = "2.0.0-enterprise"

__all__ = [
    # Core
    "NodeRegistry",
    "RuntimeConfig",
    "Runtime",
    "Workflow",
    "WorkflowBuilder",
    # DataFlow
    "DataFlow",
    "DataFlowConfig",
    "DataFlowTransaction",
    "ModelDefinition",
    "FieldType",
    "FieldDef",
    "FilterCondition",
    "TenantContext",
    "QueryInterceptor",
    # Enterprise
    "Permission",
    "Role",
    "User",
    "RbacEvaluator",
    "AbacPolicy",
    "AbacEvaluator",
    "AuditLogger",
    "AuditFilter",
    "AccessDecision",
    "TenantStatus",
    "TenantInfo",
    "EnterpriseTenantContext",
    "TenantRegistry",
    "RbacPolicy",
    "RbacPolicyBuilder",
    "RoleBuilder",
    "SecurityClassification",
    "EnterpriseContext",
    # Kaizen
    "AgentConfig",
    "LlmClient",
    "Agent",
    "CostTracker",
    "OrchestrationRuntime",
    # Kaizen - Tools
    "ToolParam",
    "ToolDef",
    "ToolRegistry",
    # Kaizen - Memory
    "SessionMemory",
    "SharedMemory",
    # Kaizen - Checkpoint
    "AgentCheckpoint",
    "InMemoryCheckpointStorage",
    "FileCheckpointStorage",
    # Kaizen - A2A
    "AgentCard",
    "AgentRegistry",
    "InMemoryMessageBus",
    "A2AProtocol",
    # Kaizen - Trust
    "TrustLevel",
    "TrustPosture",
    "EatpPosture",
    "VerificationConfig",
    "VerificationResult",
    "ResourceUsageSnapshot",
    "HumanCompetency",
    "CompetencyRequirement",
    "ComplianceStatus",
    "ComplianceReport",
    # Nexus
    "Nexus",
    "NexusConfig",
    "HandlerParam",
    "Preset",
    "JwtConfig",
    "JwtClaims",
    "RbacConfig",
    "AuthRateLimitConfig",
    "MiddlewareConfig",
    "McpServer",
    # Meta
    "__version__",
]
