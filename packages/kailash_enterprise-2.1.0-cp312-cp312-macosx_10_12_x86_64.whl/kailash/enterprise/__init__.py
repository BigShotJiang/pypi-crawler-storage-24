"""Kailash Enterprise -- RBAC, ABAC, audit trail, multi-tenancy, and context framework.

Re-exports Rust-backed enterprise types and Python compat utilities::

    # Rust-backed types
    from kailash.enterprise import RbacEvaluator, Role, Permission, User
    from kailash.enterprise import AbacPolicy, AbacEvaluator
    from kailash.enterprise import AuditLogger, AuditFilter
    from kailash.enterprise import TenantStatus, TenantInfo, EnterpriseTenantContext, TenantRegistry
    from kailash.enterprise import AccessDecision, RbacPolicy, SecurityClassification
    from kailash.enterprise import EnterpriseContext

    # Python compat layer
    from kailash.enterprise import CombinedEvaluator
    from kailash.enterprise import requires_permission, audit_action, tenant_scoped
    from kailash.enterprise import set_current_user, get_current_user
    from kailash.enterprise import set_current_tenant, get_current_tenant, clear_context
"""

from kailash._kailash import (
    AbacEvaluator,
    AbacPolicy,
    AccessDecision,
    AuditFilter,
    AuditLogger,
    EnterpriseContext,
    EnterpriseTenantContext,
    Permission,
    RbacEvaluator,
    RbacPolicy,
    RbacPolicyBuilder,
    Role,
    RoleBuilder,
    SecurityClassification,
    TenantInfo,
    TenantRegistry,
    TenantStatus,
    User,
)

from kailash.enterprise.combined import CombinedEvaluator
from kailash.enterprise.context import (
    clear_context,
    get_current_tenant,
    get_current_user,
    set_current_tenant,
    set_current_user,
)
from kailash.enterprise.decorators import (
    audit_action,
    get_audit_logger,
    get_evaluator,
    requires_permission,
    set_audit_logger,
    set_evaluator,
    tenant_scoped,
)

__all__ = [
    # Rust-backed types
    "Permission",
    "Role",
    "User",
    "RbacEvaluator",
    "AbacPolicy",
    "AbacEvaluator",
    "AuditLogger",
    "AuditFilter",
    "AccessDecision",
    "TenantStatus",
    "TenantInfo",
    "EnterpriseTenantContext",
    "TenantRegistry",
    "RbacPolicy",
    "RbacPolicyBuilder",
    "RoleBuilder",
    "SecurityClassification",
    "EnterpriseContext",
    # Python compat: combined evaluator
    "CombinedEvaluator",
    # Python compat: decorators
    "requires_permission",
    "audit_action",
    "tenant_scoped",
    "set_evaluator",
    "get_evaluator",
    "set_audit_logger",
    "get_audit_logger",
    # Python compat: context
    "set_current_user",
    "get_current_user",
    "set_current_tenant",
    "get_current_tenant",
    "clear_context",
]
