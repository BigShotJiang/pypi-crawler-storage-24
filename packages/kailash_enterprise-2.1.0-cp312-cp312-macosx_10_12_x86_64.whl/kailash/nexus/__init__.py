"""Kailash Nexus -- multi-channel deployment platform.

Re-exports Rust-backed Nexus types and Python compat helpers::

    # Rust-backed types
    from kailash.nexus import Nexus, NexusConfig, HandlerParam, Preset
    from kailash.nexus import JwtConfig, JwtClaims, RbacConfig
    from kailash.nexus import AuthRateLimitConfig, MiddlewareConfig, McpServer

    # Python compat layer
    from kailash.nexus import NexusApp
    from kailash.nexus import NexusAuthPlugin, SessionInfo, SessionStore
    from kailash.nexus import preset_to_middleware, cors, rate_limit
"""

from kailash._kailash import (
    AuthRateLimitConfig,
    HandlerParam,
    JwtClaims,
    JwtConfig,
    McpServer,
    MiddlewareConfig,
    Nexus,
    NexusConfig,
    Preset,
    RbacConfig,
)

from kailash.nexus.app import NexusApp, _extract_params_from_signature
from kailash.nexus.auth import NexusAuthPlugin, SessionInfo, SessionStore
from kailash.nexus.middleware import cors, preset_to_middleware, rate_limit

__all__ = [
    # Rust-backed types
    "Nexus",
    "NexusConfig",
    "HandlerParam",
    "Preset",
    "JwtConfig",
    "JwtClaims",
    "RbacConfig",
    "AuthRateLimitConfig",
    "MiddlewareConfig",
    "McpServer",
    # Python compat: app
    "NexusApp",
    "_extract_params_from_signature",
    # Python compat: auth
    "NexusAuthPlugin",
    "SessionInfo",
    "SessionStore",
    # Python compat: middleware helpers
    "preset_to_middleware",
    "cors",
    "rate_limit",
]
