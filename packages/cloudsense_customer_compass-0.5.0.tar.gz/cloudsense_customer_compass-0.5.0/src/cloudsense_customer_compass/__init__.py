"""CloudSense Customer Compass - MCP server for upgrade assessment and analysis."""

__version__ = "0.5.0"
