"""get_portfolio_data -- Bulk portfolio snapshot from the LMA.

Runs two SOQL queries:
  1. All active/trial production licenses (with seat utilization)
  2. Latest released version per package (for version currency)

Groups by customer and returns a compact per-customer summary with
health-scoring data. Writes full data to portfolio/portfolio-data.json.

The AI interprets the data for scoring, prioritisation, and insights
using the scoring rules file (portfolio/scoring-rules.md), which is
auto-created with sensible defaults on first run and fully editable
by the user.
"""

import json
import logging
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from ..utils import sf_cli, state

logger = logging.getLogger(__name__)

DEFAULT_SCORING_RULES = """\
# Portfolio Health Scoring Rules

> Edit this file to customise thresholds, weights, and core packages.
> Changes take effect on the next `get_portfolio_data` call.
> You can also override any rule conversationally during analysis
> (e.g. "for this analysis, treat csbb as critical").

## Dimension Weights

| Dimension          | Weight |
|--------------------|--------|
| Renewal Risk       | 0.30   |
| Version Currency   | 0.30   |
| Seat Utilization   | 0.20   |
| Product Breadth    | 0.20   |

## Core Packages

These packages carry **2x weight** in seat utilization scoring.
Add or remove packages as needed.

- CSPOFA (Process Orchestration)
- cscfga (Configurator)
- csord (Order Management)
- csbb (Broadband)

## 1. Renewal Risk

Renewal discussions typically take 2-3 months (legal, procurement,
sign-off). Thresholds reflect this lead time.

| Window                     | Label    | Score |
|----------------------------|----------|-------|
| < 90 days                  | CRITICAL | 0     |
| 90 - 180 days              | URGENT   | 25    |
| 180 - 365 days             | WATCH    | 50    |
| 1 - 2 years                | HEALTHY  | 75    |
| > 2 years or non-expiring  | SAFE     | 100   |

## 2. Version Currency

CloudSense release numbering (R33+): the major version in the
package version string IS the release number (e.g. 38.0.4 = R38).
Versions with major < 33 (e.g. 1.484.6) are pre-R33 LEGACY (1GP era).

- **R37** is the current stable release.
- **R38** is the latest release (2GP baseline, desired for new projects).

Scoring uses the customer's **oldest release** across their packages:

| Release      | Label        | Score |
|--------------|--------------|-------|
| R38          | LEADING EDGE | 100   |
| R37          | CURRENT      | 90    |
| R36          | ONE BEHIND   | 65    |
| R35          | TWO BEHIND   | 40    |
| R34 or older | OUTDATED     | 15    |
| Pre-R33      | LEGACY       | 0     |

## 3. Seat Utilization

Scoring is non-linear -- both extremes are signals.

| Utilization   | Label     | Score | Signal             |
|---------------|-----------|-------|--------------------|
| 50 - 80%      | HEALTHY   | 100   | sweet spot         |
| 80 - 90%      | GROWING   | 75    | potential upsell   |
| > 90%         | CAPACITY  | 50    | upsell urgently    |
| 30 - 50%      | LOW       | 50    | some concern       |
| < 30%         | UNDERUSED | 25    | churn risk         |
| < 10%         | DORMANT   | 0     | high churn risk    |
| Site License  | NEUTRAL   | 80    | no signal          |

For overall customer seat score: weighted average across packages,
with core packages at 2x weight (see Core Packages above).

## 4. Product Breadth

CloudSense has 50+ packages. More packages = deeper integration =
stickier customer.

| Count       | Label      | Score |
|-------------|------------|-------|
| > 20        | ENTERPRISE | 100   |
| 15 - 20     | DEEP       | 80    |
| 10 - 14     | MODERATE   | 60    |
| 5 - 9       | LIGHT      | 40    |
| 1 - 4       | MINIMAL    | 20    |

## Composite Health Score

```
overall = (renewal × 0.30) + (currency × 0.30) +
          (utilization × 0.20) + (breadth × 0.20)
```

| Score  | Tier      |
|--------|-----------|
| > 80   | HEALTHY   |
| 60 - 80| ATTENTION |
| 40 - 60| AT RISK   |
| < 40   | CRITICAL  |

## Opportunity Detection

Flag these automatically when presenting portfolio analysis:

| Signal     | Trigger                                                     |
|------------|-------------------------------------------------------------|
| UPSELL     | Seat utilization > 90% on any core package                  |
| CROSS-SELL | Missing companion packages (e.g. has cscfga but not CSPOFA) |
| UPGRADE    | Oldest release <= R35 (two or more behind)                  |
| AT-RISK    | Utilization < 30% + expiry < 180 days                       |
| STRATEGIC  | Large customer (>10 packages) + composite < 60              |

## License Status Nuance

A customer may have both "Active" and "Trial" licenses across
different orgs. "Trial" does NOT always mean prospect -- a customer
may have converted to Active in one production org while a legacy
Trial license remains on another. Only flag as a conversion
opportunity if ALL their licenses are Trial with no Active licenses.
"""

LICENSE_FIELDS = (
    "sfLma__Account__r.Name, "
    "sfLma__Account__r.Id, "
    "Package_Name__c, "
    "Package_Version_Number__c, "
    "sfLma__License_Status__c, "
    "sfLma__Licensed_Seats__c, "
    "sfLma__Used_Licenses__c, "
    "sfLma__Expiration_Date__c, "
    "Days_To_Expire__c, "
    "sfLma__Package_Version__r.sfLma__Package__c"
)

TOOL_DEFINITION = {
    "name": "get_portfolio_data",
    "description": (
        "Fetch a snapshot of ALL active/trial production licenses from the "
        "CloudSense License Management Portal, enriched with seat utilization "
        "and version currency data. Groups results by customer and returns a "
        "compact summary with health-scoring inputs. Writes full data to "
        "portfolio/portfolio-data.json. Use this for cross-customer analysis: "
        "renewal risks, upgrade opportunities, upsell signals, portfolio "
        "health scoring. Requires connect_lma first."
    ),
    "inputSchema": {
        "type": "object",
        "properties": {
            "working_directory": {
                "type": "string",
                "description": "Workspace directory. The AI passes this automatically.",
            },
        },
        "required": [],
    },
}


def _extract_release(version_str: str | None) -> int | None:
    """Extract the CloudSense release number from a version string.

    R33+ use major version as release number (e.g. 38.0.4 -> R38).
    Pre-R33 packages (major < 33, e.g. 1.484.6) return None (LEGACY).
    """
    if not version_str:
        return None
    try:
        major = int(version_str.split(".")[0])
        return major if major >= 33 else None
    except (ValueError, IndexError):
        return None


def _parse_seats(licensed: Any, used: Any) -> dict[str, Any]:
    """Parse seat utilization into a compact structure."""
    if licensed is None and used is None:
        return {"type": "unknown"}
    if isinstance(licensed, str) and licensed.lower() == "site license":
        return {"type": "site"}
    try:
        total = int(licensed) if licensed is not None else None
        active = int(used) if used is not None else 0
        if total and total > 0:
            pct = round((active / total) * 100)
            return {"type": "numeric", "licensed": total, "used": active, "pct": pct}
        return {"type": "numeric", "licensed": total, "used": active, "pct": 0}
    except (ValueError, TypeError):
        return {"type": "other", "raw_licensed": str(licensed)}


def _query_all_active_licenses(lma_alias: str) -> list[dict[str, Any]]:
    query = (
        f"SELECT {LICENSE_FIELDS} "
        f"FROM sfLma__License__c "
        f"WHERE sfLma__Is_Sandbox__c = false "
        f"AND sfLma__License_Status__c IN ('Active', 'Trial') "
        f"AND sfLma__Account__r.Name != null "
        f"ORDER BY sfLma__Account__r.Name"
    )
    return sf_cli.lma_query(query, lma_alias)


def _query_latest_versions(
    package_ids: set[str], lma_alias: str,
) -> dict[str, dict[str, Any]]:
    """Query the latest released version for each package ID.

    Returns {package_id: {"version": "38.0.4", "release_date": "2026-02-17", "release": 38}}.
    """
    if not package_ids:
        return {}

    id_list = ", ".join(f"'{pid}'" for pid in sorted(package_ids))
    query = (
        f"SELECT sfLma__Package__c, sfLma__Version_Number__c, sfLma__Release_Date__c "
        f"FROM sfLma__Package_Version__c "
        f"WHERE sfLma__Package__c IN ({id_list}) "
        f"ORDER BY sfLma__Release_Date__c DESC"
    )
    records = sf_cli.lma_query(query, lma_alias)

    latest: dict[str, dict[str, Any]] = {}
    for rec in records:
        pid = rec.get("sfLma__Package__c")
        if pid and pid not in latest:
            ver = rec.get("sfLma__Version_Number__c") or "?"
            latest[pid] = {
                "version": ver,
                "release_date": rec.get("sfLma__Release_Date__c"),
                "release": _extract_release(ver),
            }
    return latest


def _group_by_customer(
    licenses: list[dict[str, Any]],
    latest_versions: dict[str, dict[str, Any]],
) -> dict[str, dict[str, Any]]:
    """Group licenses by customer account, compute per-customer metrics."""
    customers: dict[str, dict[str, Any]] = {}

    for lic in licenses:
        acct_ref = lic.get("sfLma__Account__r")
        if not isinstance(acct_ref, dict):
            continue
        acct_name = acct_ref.get("Name", "Unknown")
        acct_id = acct_ref.get("Id", "")

        if acct_name not in customers:
            customers[acct_name] = {
                "account_id": acct_id,
                "packages": defaultdict(lambda: {
                    "versions": [], "seats": [], "package_id": None,
                }),
                "statuses": set(),
                "nearest_expiry_days": None,
                "license_count": 0,
            }

        cust = customers[acct_name]
        cust["license_count"] += 1

        status = lic.get("sfLma__License_Status__c") or "Unknown"
        cust["statuses"].add(status)

        pkg_name = lic.get("Package_Name__c") or "Unknown"
        pkg_data = cust["packages"][pkg_name]
        pkg_data["versions"].append(
            lic.get("Package_Version_Number__c") or "?"
        )

        pkg_ver_ref = lic.get("sfLma__Package_Version__r")
        if isinstance(pkg_ver_ref, dict):
            pid = pkg_ver_ref.get("sfLma__Package__c")
            if pid:
                pkg_data["package_id"] = pid

        seat_info = _parse_seats(
            lic.get("sfLma__Licensed_Seats__c"),
            lic.get("sfLma__Used_Licenses__c"),
        )
        pkg_data["seats"].append(seat_info)

        days = lic.get("Days_To_Expire__c")
        if days is not None:
            try:
                d = float(days)
                if cust["nearest_expiry_days"] is None or d < cust["nearest_expiry_days"]:
                    cust["nearest_expiry_days"] = d
            except (ValueError, TypeError):
                pass

    result = {}
    for name, cust in customers.items():
        pkg_summaries = {}
        oldest_release: int | None = None

        for pkg_name, pkg_data in cust["packages"].items():
            versions = sorted(set(pkg_data["versions"]))
            customer_release = max(
                (_extract_release(v) for v in versions),
                default=None,
                key=lambda r: r if r is not None else -1,
            )

            pkg_id = pkg_data["package_id"]
            latest_info = latest_versions.get(pkg_id, {}) if pkg_id else {}
            latest_ver = latest_info.get("version")
            latest_rel = latest_info.get("release")

            on_latest = False
            if latest_ver and versions:
                on_latest = latest_ver in versions

            seat_summary = _summarise_seats(pkg_data["seats"])

            pkg_summaries[pkg_name] = {
                "versions": versions,
                "customer_release": customer_release,
                "latest_version": latest_ver,
                "latest_release": latest_rel,
                "on_latest": on_latest,
                "seats": seat_summary,
            }

            if customer_release is not None:
                if oldest_release is None or customer_release < oldest_release:
                    oldest_release = customer_release

        result[name] = {
            "account_id": cust["account_id"],
            "license_count": cust["license_count"],
            "package_count": len(cust["packages"]),
            "statuses": sorted(cust["statuses"]),
            "packages": pkg_summaries,
            "nearest_expiry_days": cust["nearest_expiry_days"],
            "oldest_release": oldest_release,
        }
    return result


def _summarise_seats(seat_entries: list[dict[str, Any]]) -> dict[str, Any]:
    """Aggregate seat data across multiple licenses for the same package."""
    numeric = [s for s in seat_entries if s["type"] == "numeric"]
    if numeric:
        total_licensed = sum(s.get("licensed") or 0 for s in numeric)
        total_used = sum(s.get("used") or 0 for s in numeric)
        pct = round((total_used / total_licensed) * 100) if total_licensed > 0 else 0
        return {"type": "numeric", "licensed": total_licensed, "used": total_used, "pct": pct}
    site = [s for s in seat_entries if s["type"] == "site"]
    if site:
        return {"type": "site"}
    return {"type": "unknown"}


def _ensure_scoring_rules(working_dir: Path) -> Path:
    """Create scoring-rules.md with defaults if it doesn't exist. Returns the path."""
    portfolio_dir = working_dir / "portfolio"
    portfolio_dir.mkdir(parents=True, exist_ok=True)
    rules_path = portfolio_dir / "scoring-rules.md"
    if not rules_path.exists():
        rules_path.write_text(DEFAULT_SCORING_RULES)
        logger.info("Created default scoring rules at %s", rules_path)
    return rules_path


def _read_scoring_rules(rules_path: Path) -> str:
    """Read the scoring rules file content."""
    try:
        return rules_path.read_text()
    except OSError:
        logger.warning("Could not read scoring rules at %s, using defaults", rules_path)
        return DEFAULT_SCORING_RULES


def _write_portfolio_json(
    working_dir: Path,
    customers: dict[str, dict[str, Any]],
    total_licenses: int,
) -> Path:
    portfolio_dir = working_dir / "portfolio"
    portfolio_dir.mkdir(parents=True, exist_ok=True)
    out_path = portfolio_dir / "portfolio-data.json"
    out_path.write_text(json.dumps({
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "total_licenses": total_licenses,
        "customer_count": len(customers),
        "customers": customers,
    }, indent=2, default=str))
    return out_path


async def run(arguments: dict[str, Any]) -> str:
    """Execute the get_portfolio_data tool."""
    state.set_working_dir(arguments.get("working_directory"))
    current_state = state.load()
    lma_alias = current_state.get("lma_org_alias") or "cs-lma"

    licenses = _query_all_active_licenses(lma_alias)

    if not licenses:
        return (
            "STATUS: NO_DATA\n\n"
            "No active production licenses found in the LMA. "
            "Verify connect_lma was called and the LMA org has license data."
        )

    all_package_ids: set[str] = set()
    for lic in licenses:
        ref = lic.get("sfLma__Package_Version__r")
        if isinstance(ref, dict):
            pid = ref.get("sfLma__Package__c")
            if pid:
                all_package_ids.add(pid)

    latest_versions = _query_latest_versions(all_package_ids, lma_alias)

    working_dir = state.get_working_dir()
    rules_path = _ensure_scoring_rules(working_dir)
    scoring_rules = _read_scoring_rules(rules_path)

    customers = _group_by_customer(licenses, latest_versions)
    artifact_path = _write_portfolio_json(
        working_dir, customers, len(licenses),
    )

    sorted_customers = sorted(
        customers.items(),
        key=lambda x: (
            x[1]["nearest_expiry_days"]
            if x[1]["nearest_expiry_days"] is not None
            else 99999
        ),
    )

    lines = [
        "STATUS: READY\n",
        f"## Portfolio Snapshot\n",
        f"- **Customers:** {len(customers)}",
        f"- **Total active production licenses:** {len(licenses)}",
        f"- **Distinct packages:** {len(all_package_ids)}",
        f"- **Data:** `{artifact_path}`\n",
    ]

    lines.append("### All Customers\n")
    lines.append(
        "| Customer | Pkgs | Licenses | Status | "
        "Oldest Rel | Expiry (days) | Seat Flags |"
    )
    lines.append(
        "|----------|------|----------|--------|"
        "-----------|---------------|------------|"
    )
    for name, cust in sorted_customers:
        days = cust["nearest_expiry_days"]
        days_str = str(int(days)) if days is not None else "n/a"
        status = ", ".join(cust["statuses"])
        oldest = cust.get("oldest_release")
        rel_str = f"R{oldest}" if oldest else "LEGACY"

        seat_flags = _seat_flags(cust["packages"])

        lines.append(
            f"| {name} | {cust['package_count']} | "
            f"{cust['license_count']} | {status} | "
            f"{rel_str} | {days_str} | {seat_flags} |"
        )

    lines.append(
        f"\n\n**Scoring rules:** `{rules_path}`\n"
        "Apply the scoring rules below to compute health scores per customer "
        "(renewal risk, version currency, seat utilization, product breadth). "
        "Present a ranked portfolio view with composite health scores and "
        "flag opportunities (upsell, upgrade, at-risk, cross-sell). "
        "The user can edit the scoring rules file to change thresholds, "
        "or override any rule conversationally. Offer to:\n"
        "- Dive deeper into any specific customer (use find_customer)\n"
        "- Save findings as a shareable report (use save_report)\n"
    )

    lines.append("\n---\n\n<SCORING_RULES>\n")
    lines.append(scoring_rules)
    lines.append("</SCORING_RULES>")

    return "\n".join(lines)


def _seat_flags(packages: dict[str, dict[str, Any]]) -> str:
    """Generate compact seat utilization flags for a customer."""
    flags = []
    for pkg_name, pkg in packages.items():
        seats = pkg.get("seats", {})
        if seats.get("type") == "numeric":
            pct = seats.get("pct", 0)
            if pct >= 90:
                flags.append(f"{pkg_name[:12]}:{pct}%!")
            elif pct < 30 and seats.get("licensed", 0) > 0:
                flags.append(f"{pkg_name[:12]}:{pct}%?")
    if not flags:
        return "-"
    return "; ".join(flags[:3])
