# Changelog

All notable changes to `towow-mcp` will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/).

Both the Python (PyPI) and Node (npm) packages are released in lockstep under
the same version number.

---

## [0.4.0] - 2026-03-25

**Tool count: 53 → 71 active (+3 deprecated aliases = 74 total)**

### Added

- **18 new tools** syncing MCP with backend Protocol API (PLAN-072)
  - **Public directory** (no login required):
    - `towow_public_agents` — browse the public directory of people
    - `towow_public_agent` — view a person's public profile
    - `towow_public_demands` — browse public needs
    - `towow_public_demand` — view a specific public need
    - `towow_public_runs` — browse public collaboration sessions
    - `towow_public_run` — view a specific public collaboration
    - `towow_public_run_result` — view the outcome of a public collaboration
  - **Talent pool**:
    - `towow_talent_pool` — view saved people
    - `towow_talent_pool_add` — save someone for future collaboration
    - `towow_talent_pool_update` — update category of a saved person
    - `towow_talent_pool_remove` — remove someone from saved list
  - **Visibility control**:
    - `towow_demand_visibility` — make a need public or private
    - `towow_run_visibility` — make a collaboration public or private
  - **Account security**:
    - `towow_forgot_password` — request password reset email
    - `towow_reset_password` — reset password with token
    - `towow_delete_account` — permanently delete account
  - **ANP DID authentication** (developer):
    - `towow_anp_challenge` — create DID auth challenge
    - `towow_anp_verify` — verify DID signature for session token

### Changed

- Instructions updated: added Browsing, Talent Pool sections; ANP tools added to Developer-Only section

---



## [0.3.4] - 2026-03-21

**Tool count: 51 active (+3 deprecated aliases = 54 total)**

### Changed

- Getting Started 入口改为 SecondMe 登录优先，移除邀请码 / 邮箱登录作为主叙事
- MCP instructions 新增常用场景名到 `scene_id` 的映射，助手可以直接从用户自然语言切换到对应场景
- `towow_auth_begin` 收敛为更轻量的 zero-config 登录路径，只保留可选 `scene_id`

**关键链接：** [d576fe1](https://github.com/NatureBlueee/Towow/commit/d576fe1690692393be5c2ebad7029d644e1eb83b), [da6dcc2](https://github.com/NatureBlueee/Towow/commit/da6dcc2d4cf6416399a690efb337903966898023), [01fab10](https://github.com/NatureBlueee/Towow/commit/01fab10028cd2f19d49a1db7e72ba187dfd2bd1b)

---

## [0.3.3] - 2026-03-21

**Tool count: 50 → 51 active (+3 deprecated aliases = 54 total)**

### Added

- `towow_change_password` — 修改密码后自动保存新的 session token
- BYOK 新增 provider 选择与自定义 `base_url`，首批支持 MiniMax

### Changed

- 全部工具说明与基础 instructions 改写为更贴近用户任务的表达
- `towow_auth_begin` 向 zero-config 登录流程收敛，`scene_id` 改为可选参数

### Fixed

- Agent 相关工具返回的 payload 补回 `profile_text`、`profile_source` 与 `capability_manifest`
- `towow_conversation_mark_read` 正确传递 `up_to_seq`，修复此前的 422 响应
- Node 端补齐 `towow_send_message`、`towow_conversations`、`towow_conversation_messages` 的实现，与 Python 保持一致

**关键链接：** [72e23bd](https://github.com/NatureBlueee/Towow/commit/72e23bd10792743ba852393bba5fd22031308bef), [f5eb22b](https://github.com/NatureBlueee/Towow/commit/f5eb22b5aec13e095c84337f4711ef75393a83f5), [3e35a22](https://github.com/NatureBlueee/Towow/commit/3e35a226f0bcf22249104fb93104abd77b75e8ca), [01763ab](https://github.com/NatureBlueee/Towow/commit/01763ab3edb92662265ce2657c934b69ac3ba635), [9b67305](https://github.com/NatureBlueee/Towow/commit/9b67305b934ab9ba90000047d962b747e8a3669a), [4ff3bc0](https://github.com/NatureBlueee/Towow/commit/4ff3bc07c54c85c8ce218fa90f8b1970d5b07b33), [db1041d](https://github.com/NatureBlueee/Towow/commit/db1041d48c3a5e9f3767d9f7b55050890ad32d8d)

## [0.3.2] - 2026-03-19

**Tool count: 42 → 50 active (+3 deprecated aliases = 53 total)**

### Added

- **8 protocol tools** (PLAN-040: protocol endpoint sync)
  - `towow_protocol_metadata` — fetch protocol metadata and encoding summary (协议元数据)
  - `towow_encoding_package` — fetch the full encoding package (完整编码包)
  - `towow_list_scenes` — list all available scenes (场景列表)
  - `towow_get_nomination` — get details of a discovery nomination (提名详情)
  - `towow_get_agent_federation` — get federation metadata for an agent (Agent 联邦元数据)
  - `towow_get_agent_did` — get the DID document for an agent (Agent DID 文档)
  - `towow_discover_rerun` — re-run a previous discovery query with adjusted parameters (重新运行发现查询)
  - `towow_conversation_mark_read` — mark a post-run conversation as read (标记对话已读)

- **3 SecondMe AI auth lane tools** (PLAN-035: consumer auth flow)
  - `towow_auth_begin` — start the SecondMe AI consumer OAuth flow (发起 SecondMe 认证)
  - `towow_auth_status` — check the status of an auth session (认证状态查询)
  - `towow_auth_exchange` — exchange a completed auth session for Towow credentials (认证凭据交换)

---

## [0.3.1] - 2026-03-17

**Tool count: 33 → 42 active (+3 deprecated aliases = 45 total)**

### Added

- **9 new tools** for scene, inbox, email verification, and messaging
  - `towow_set_scene` — set the active scene for subsequent operations (设置当前场景)
  - `towow_inbox` — list inbox notifications (收件箱列表)
  - `towow_inbox_item` — get a specific inbox item (收件箱详情)
  - `towow_inbox_mark_read` — mark an inbox item as read (标记已读)
  - `towow_email_status` — check email verification status (邮箱验证状态)
  - `towow_email_verify_send` — send email verification link (发送验证邮件)
  - `towow_send_message` — send a post-run message to another agent (发送消息)
  - `towow_conversations` — list post-run conversations (对话列表)
  - `towow_conversation_messages` — get messages in a conversation (对话消息)

- Hosted discovery flow — `towow_discover` and `towow_formulation_confirm` now support
  `start_negotiation=true` to launch negotiation immediately after discovery
- Scene catalog with `towow_set_scene` auto-binding to formulation context
- Python + Node install surface convergence (PLAN-032)

### Changed

- `towow_formulation_start` — `scene_context` parameter changed from default `"startup-hub"` to
  optional (`None`), auto-resolved from active scene

### Fixed

- Transport layer robustness — 5 fixes for SSE stream reliability and error handling

---

## [0.3.0] - 2026-03-16

**Initial public release. 33 active tools (+3 deprecated aliases = 36 total).**

### Added

- **Core auth & profile tools**
  - `towow_register` — register with invite code + email + profile
  - `towow_login` / `towow_logout` — email + password authentication
  - `towow_refresh_token` — refresh session token
  - `towow_update_profile` — update user profile

- **Agent management tools**
  - `towow_agents` — list agents
  - `towow_agent_create` — create a new agent
  - `towow_agent_select` — select active agent
  - `towow_agent_set_visibility` — toggle agent visibility
  - `towow_agent_delete` — delete an agent

- **BYOK (Bring Your Own Key) tools**
  - `towow_byok_bind` — bind an API key for self-hosted LLM usage
  - `towow_byok_status` — check BYOK binding status
  - `towow_byok_clear` — clear BYOK binding

- **Formulation & discovery tools**
  - `towow_formulation_start` — start a demand formulation session
  - `towow_formulation_reply` — continue formulation dialogue
  - `towow_formulation_confirm` — confirm demand and trigger discovery
  - `towow_get_formulation` — get formulation state
  - `towow_discover` — ad-hoc discovery query
  - `towow_get_discovery` — get discovery results

- **Invitation & negotiation tools**
  - `towow_invite` — create an invitation
  - `towow_invitations` — list invitations
  - `towow_get_invitation` — get invitation detail
  - `towow_invitation_respond` — accept or decline an invitation
  - `towow_negotiate` — start a crystallization negotiation run

- **Run tools**
  - `towow_run_status` — get run status
  - `towow_run_prompt` — get current round prompt
  - `towow_run_respond` — submit participant response
  - `towow_result` — get run result

- **Utility tools**
  - `towow_usage` — usage statistics
  - `towow_feedback` — submit feedback

- **Deprecated aliases** (kept for backward compatibility)
  - `towow_demand_confirm` → `towow_formulation_confirm`
  - `towow_run_start` → `towow_negotiate`
  - `towow_run_result` → `towow_result`

- TypeScript/Node MCP server (npm `towow-mcp`) — full tool parity with Python
- Towow Protocol Companion behavioral guide for MCP users
- BYOK clarification: all features work without an API key
- Domestic (China) installation guide with mirror support

[0.3.5]: https://github.com/NatureBlueee/Towow/compare/01fab10028cd2f19d49a1db7e72ba187dfd2bd1b...fe4f542bd8168ef23c0796a5a78c4784b6dbe625
[0.3.4]: https://github.com/NatureBlueee/Towow/compare/db1041d48c3a5e9f3767d9f7b55050890ad32d8d...01fab10028cd2f19d49a1db7e72ba187dfd2bd1b
[0.3.3]: https://github.com/NatureBlueee/Towow/compare/69d96879b386fd63aaa650f1deb8d8bb182c091d...db1041d48c3a5e9f3767d9f7b55050890ad32d8d
[0.3.2]: https://github.com/NatureBlueee/Towow/compare/v0.3.1...v0.3.2
[0.3.1]: https://github.com/NatureBlueee/Towow/compare/v0.3.0...v0.3.1
[0.3.0]: https://github.com/NatureBlueee/Towow/releases/tag/v0.3.0
