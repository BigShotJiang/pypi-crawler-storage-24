"""Local configuration management for ~/.towow/config.json."""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

CONFIG_DIR = Path.home() / ".towow"
CONFIG_FILE = CONFIG_DIR / "config.json"

DEFAULT_BACKEND_URL = "https://auth.towow.net/api"

# MCP session TTL (configurable via MCP_SESSION_TTL_DAYS, default 7 days)
MCP_SESSION_TTL_SECONDS = int(os.getenv("MCP_SESSION_TTL_DAYS", "7")) * 86400


def _read_config(path: Path | None = None) -> dict[str, Any]:
    target = path or CONFIG_FILE
    if not target.exists():
        return {}
    try:
        return json.loads(target.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return {}


def _write_config(data: dict[str, Any], path: Path | None = None) -> None:
    target = path or CONFIG_FILE
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(
        json.dumps(data, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    target.chmod(0o600)


def get_backend_url() -> str:
    env_url = os.environ.get("TOWOW_BACKEND_URL")
    if env_url:
        return env_url.rstrip("/")
    config = _read_config()
    return config.get("backend_url", DEFAULT_BACKEND_URL).rstrip("/")


def get_session_token(path: Path | None = None) -> str | None:
    """Get stored session token, or None if not logged in."""
    return _read_config(path).get("session_token")


def get_auth_lane(path: Path | None = None) -> str | None:
    return _read_config(path).get("auth_lane")


def get_entry_surface(path: Path | None = None) -> str | None:
    return _read_config(path).get("entry_surface")


def get_consumer_kind(path: Path | None = None) -> str | None:
    value = _read_config(path).get("consumer_kind")
    if value:
        return str(value)
    env_value = os.environ.get("TOWOW_CONSUMER_KIND")
    if env_value:
        return env_value.strip()
    return "codex"


def save_session_token(token: str, path: Path | None = None) -> None:
    """Save session token after login/register."""
    config = _read_config(path)
    config["session_token"] = token
    _write_config(config, path)


def clear_session_token(path: Path | None = None) -> None:
    """Remove session token (logout)."""
    config = _read_config(path)
    config.pop("session_token", None)
    _write_config(config, path)


# --- V1 compat stubs (removed in B04 when server.py is rewritten) ---


def get_agent_id() -> str | None:
    return _read_config().get("agent_id")


def get_display_name(path: Path | None = None) -> str | None:
    return _read_config(path).get("display_name")


def get_last_negotiation_id() -> str | None:
    return _read_config().get("last_negotiation_id")


def save_agent(agent_id: str, display_name: str | None = None, path: Path | None = None) -> None:
    config = _read_config(path)
    config["agent_id"] = agent_id
    if display_name is not None:
        config["display_name"] = display_name
    _write_config(config, path)


def clear_agent(path: Path | None = None) -> None:
    config = _read_config(path)
    config.pop("agent_id", None)
    config.pop("display_name", None)
    _write_config(config, path)


def get_scene_id(path: Path | None = None) -> str | None:
    return _read_config(path).get("scene_id")


def get_scene_display_name(path: Path | None = None) -> str | None:
    return _read_config(path).get("scene_display_name")


def save_scene(scene_id: str, display_name: str | None = None, path: Path | None = None) -> None:
    config = _read_config(path)
    config["scene_id"] = scene_id
    if display_name is None:
        config.pop("scene_display_name", None)
    else:
        config["scene_display_name"] = display_name
    _write_config(config, path)


def clear_scene(path: Path | None = None) -> None:
    config = _read_config(path)
    config.pop("scene_id", None)
    config.pop("scene_display_name", None)
    _write_config(config, path)


def save_last_negotiation(negotiation_id: str) -> None:
    config = _read_config()
    config["last_negotiation_id"] = negotiation_id
    _write_config(config)
