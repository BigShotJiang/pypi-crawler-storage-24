"""Towow MCP Server — canonical workflow adapter over /protocol APIs."""

from __future__ import annotations

import json
import logging
from collections.abc import Awaitable, Callable
from functools import wraps
from typing import Any, ParamSpec

from mcp.server.fastmcp import FastMCP
from mcp.server.fastmcp.exceptions import ToolError

from .client import APIError, AuthError, TowowClient
from .config import (
    clear_agent,
    get_auth_lane,
    get_consumer_kind,
    get_entry_surface,
    get_scene_display_name,
    get_scene_id,
    clear_session_token,
    get_agent_id,
    get_display_name,
    get_session_token,
    save_agent,
    save_scene,
    save_session_token,
)
from .lanes.secondme_ai import LANE_NAME as SECONDME_AI_LANE
from .lanes.secondme_ai import SCENE_ID_TO_ENTRY_SURFACE
from .sse_consumer import AuthError as SSEAuthError
from .sse_consumer import SSEError, consume_sse_stream

logger = logging.getLogger(__name__)
P = ParamSpec("P")

_BASE_INSTRUCTIONS = """\
Towow (通爻) helps people find the right collaborators and run structured \
multi-party collaboration sessions. Not a search engine — people who can help \
you are discovered by mutual fit, and real collaboration happens through guided \
multi-party sessions where multiple perspectives produce better outcomes than \
any individual could.

## Your Role

You are the user's guide to Towow. Think of yourself as a bilingual concierge: \
you understand the platform's internal protocol perfectly (so you can choose the \
right tool), but you speak to users only in terms they already know. A guest says \
"Can I get a late checkout?" — you say "Done, you're all set." You never say \
"I've submitted a PMS departure timestamp modification work order."

## How You Communicate

**Users are primarily Chinese-speaking.** Default to Chinese (简体中文) in all \
user-facing communication. Switch to English only when the user writes in English.

**Never use protocol terminology with users.** This is the golden rule.

Three failure modes to watch for:
- **Protocol Leak**: saying "formulation session", "nomination", "crystallization", \
"canonical", "ad-hoc discovery query" to a user who has no idea what these mean.
- **Jargon Autopilot**: explaining your actions by tool name — "I'll call \
towow_formulation_start to create a formulation." The user didn't ask for a protocol \
lecture. Just say what's happening in their terms.
- **Context Amnesia**: giving vague "I'll help you find people" guidance because you \
forgot that Towow does structured multi-party collaboration, not just search.

### Terminology Guide (for your internal translation — never show this table to users)

| Protocol concept | Say this to users |
|---|---|
| formulation | "let's clarify what you need" / "describe what you're looking for" |
| nomination | "recommended match" / "someone who could be a good fit" |
| discovery | "finding the right people" / "matching" |
| negotiation / crystallization / run | "collaboration session" / "working together" |
| hosted run (worker_distributed) | "the system handles it — just wait for results" |
| participant-distributed run | "you'll need to respond when prompted" |
| agent | "identity" / "profile" (one account can have several for different contexts) |
| scene | "scenario" / "context" |
| BYOK | "using your own API key" (supports Anthropic and compatible providers like MiniMax) |
| inbox item | "result notification" |
| encoding package / federation / DID | developer concepts — never mention to regular users |

## Getting Started

1. **Log in via SecondMe**: Call `towow_auth_begin()`. A browser opens for \
SecondMe login — no invite code needed. New users get an account automatically.
2. **Pick a scenario** (if the user mentions one): Call `towow_set_scene()`. \
Recognize these names:
   - 一虾公司 / CrawOPC / 虾力资源 → `towow_set_scene("craw-opc")`
   - 黑客松观猹员 / Hackathon Observer / 逛黑客松 → `towow_set_scene("hackathon-observer")`
   - 虾客松 / Shrimp Hackathon / 虾客松组队 → `towow_set_scene("shrimp-hackathon")`
   - AI零工集市 / AI Gig Market / 接活/发活 → `towow_set_scene("ai-gig-market")`
   - AI创业组队 / Startup Hub → `towow_set_scene("startup-hub")`
3. **Write a strong profile** (`towow_update_profile`) — this is how the system \
matches you. 3-5 paragraphs: who you are, what you do, what you need, what you offer.
4. **Describe what you need**: If it's vague, start a guided conversation \
(`towow_formulation_start`). If it's already clear, go straight to matching \
(`towow_discover`).
5. **Let the system find matches and start collaboration**: Pass \
`start_negotiation=true` and `k=3` — the system finds the best people and \
runs the collaboration automatically. No further action needed.
6. **Get results**: Check `towow_inbox` or `towow_result`.

## Typical Flow

```
Login (SecondMe) → Pick Scenario → Profile → Describe Need
    → System Finds Matches → Automatic Collaboration → Results
```

### When the need is vague
Start a guided conversation — the system asks clarifying questions, then \
finds matching people and starts collaboration automatically.

### When the need is clear
Go directly to matching. The system finds the right people and can start \
collaboration immediately.

### After collaboration finishes
Check results. Send follow-up messages to collaborators. Rate the experience.

## About API Keys

Everything works without an API key — the platform handles all the heavy \
lifting. If you hit a usage limit, you can optionally connect your own \
API key with `towow_byok_bind` (Anthropic or compatible providers such as \
MiniMax). Most users never need this.

## Browsing
Browse people, needs, and collaboration outcomes without logging in: \
`towow_public_agents`, `towow_public_demands`, `towow_public_runs`. \
Use these when the user wants to explore what's on the platform.

## Talent Pool
Save interesting people for later with `towow_talent_pool_add`. \
View saved people with `towow_talent_pool`. Think of it as bookmarks \
for people you might want to collaborate with.

## Tips
- One account can have multiple identities for different contexts.
- Better profiles get better matches — update yours often.
- Verify email to receive result notifications.
- After collaboration, rate the experience to help improve the system.
- The invitation-based tools (`towow_invite`, `towow_invitations`, etc.) are \
an advanced flow. Most users should use the automatic path instead.
- Forgot your password? Use `towow_forgot_password` to get a reset link.

## Developer-Only Tools
For technical integration and cross-platform interoperability: \
`towow_protocol_metadata`, `towow_encoding_package`, \
`towow_get_agent_federation`, `towow_get_agent_did`, \
`towow_anp_challenge`, `towow_anp_verify`. \
Regular users don't need these — don't offer them unless the user is clearly \
doing developer work.
"""


def _build_instructions() -> str:
    scene_id = get_scene_id()
    sections = [_BASE_INSTRUCTIONS]
    sections.append(
        "## Authentication\n\n"
        "- Use `towow_auth_begin()` to log in via SecondMe (zero-config, no setup needed).\n"
        "- Email/password login is available via `towow_login`. SecondMe login is also supported via `towow_auth_begin`.\n"
    )
    if scene_id:
        scene_display_name = get_scene_display_name()
        scene_label = f"{scene_display_name} ({scene_id})" if scene_display_name else scene_id
        sections.append(
            "## Current Scenario\n\n"
            f"- Active scenario: {scene_label}\n"
            "- All matching and collaboration will use this scenario by default.\n"
        )
    return "\n\n".join(sections)


import os as _os

_allowed_hosts = [
    h.strip()
    for h in _os.environ.get("TOWOW_MCP_ALLOWED_HOSTS", "").split(",")
    if h.strip()
]

_transport_security = None
if _allowed_hosts:
    from mcp.server.fastmcp.server import TransportSecuritySettings

    _transport_security = TransportSecuritySettings(allowed_hosts=_allowed_hosts)

mcp = FastMCP(
    "towow",
    instructions=_build_instructions(),
    host=_os.environ.get("TOWOW_MCP_HOST", "127.0.0.1"),
    port=int(_os.environ.get("TOWOW_MCP_PORT", "8811")),
    transport_security=_transport_security,
)


def _get_client() -> TowowClient:
    return TowowClient()


def _require_auth() -> None:
    if not get_session_token():
        raise ToolError("Not logged in. Call towow_login or towow_register first.")


def _require_agent_id() -> str:
    agent_id = get_agent_id()
    if not agent_id:
        raise ToolError("No current agent selected. Call towow_agents or towow_agent_select first.")
    return agent_id


def _json(payload: dict[str, Any]) -> str:
    return json.dumps(payload, ensure_ascii=False, default=str)


def _assemble_profile_text(
    base: str,
    *,
    tagline: str | None = None,
    skills: str | None = None,
    offerings: str | None = None,
    seeking: str | None = None,
) -> str:
    """Append optional structured fields to base profile_text (P1-2 contract)."""
    parts = [base.strip()]
    if tagline:
        parts.append(f"\n## 一句话介绍\n{tagline}")
    if skills:
        parts.append(f"\n## 技能\n{skills}")
    if offerings:
        parts.append(f"\n## 我能提供\n{offerings}")
    if seeking:
        parts.append(f"\n## 我在找\n{seeking}")
    return "\n".join(parts) if len(parts) > 1 else parts[0]


def _selected_agent_payload() -> dict[str, Any]:
    return {
        "agent_id": get_agent_id(),
        "display_name": get_display_name(),
    }


def _pick_agent_payload(agent: dict[str, Any]) -> dict[str, Any]:
    return {
        "agent_id": agent.get("agent_id"),
        "display_name": agent.get("display_name"),
        "profile_text": agent.get("profile_text"),
        "profile_source": agent.get("profile_source"),
        "visibility": agent.get("visibility"),
        "scoped_tags": agent.get("scoped_tags", []),
        "capability_manifest": agent.get("capability_manifest"),
    }


def _resolve_scene_context(scene_context: str | None) -> str:
    return (scene_context or get_scene_id() or "startup-hub").strip()


async def _begin_secondme_ai_auth(
    *,
    scene_id: str | None = None,
) -> dict[str, Any]:
    # Resolve defaults from config when not explicitly passed.
    resolved_scene = scene_id or get_scene_id()
    resolved_surface = (
        get_entry_surface()
        or (SCENE_ID_TO_ENTRY_SURFACE.get(resolved_scene) if resolved_scene else None)
    )
    client = _get_client()
    try:
        return await client.create_consumer_auth_session(
            lane=SECONDME_AI_LANE,
            scene_id=resolved_scene,
            entry_surface=resolved_surface,
            consumer_kind=get_consumer_kind(),
        )
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()


def _with_auth_status_next_tool(payload: dict[str, Any]) -> dict[str, Any]:
    body = dict(payload)
    if body.get("status") == "completed":
        body["next_tool"] = "towow_auth_exchange"
    return body


def _protect_auth_tool(func: Callable[P, Awaitable[str]]) -> Callable[P, Awaitable[str]]:
    @wraps(func)
    async def wrapper(*args: P.args, **kwargs: P.kwargs) -> str:
        if not get_session_token():
            lane = get_auth_lane()
            if lane:
                # Lane-enabled: initiate auth challenge automatically.
                payload = await _begin_secondme_ai_auth()
                payload["next_tool"] = "towow_auth_status"
                return _json(payload)
            # Legacy: no lane configured — hard error.
            raise ToolError("Not logged in. Call towow_login or towow_register first.")
        return await func(*args, **kwargs)

    return wrapper


async def _canonical_formulation_confirm(
    *,
    session_id: str,
    scope_tags: list[str] | None,
    max_candidates: int,
    start_negotiation: bool,
    k: int | None,
) -> dict[str, Any]:
    _require_auth()
    client = _get_client()
    try:
        confirmed = await client.confirm_formulation(
            session_id=session_id,
            scope_tags=scope_tags,
            max_candidates=max_candidates,
            start_negotiation=start_negotiation,
            k=k,
        )
        query_id = confirmed["query_id"]
        query = await client.get_discovery_query(query_id)
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        if exc.status_code == 403:
            raise ToolError(
                "Profile 质量不足，请先完善 Profile。使用 towow_quality_score 查看当前评分和改进建议。"
            ) from exc
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return {
        "session_id": session_id,
        "demand_id": confirmed.get("demand_id"),
        "query_id": query_id,
        "session": confirmed.get("session"),
        "query": query,
        "run": confirmed.get("run"),
        "selected_agent": _selected_agent_payload(),
    }


@mcp.tool()
async def towow_register(
    invite_code: str,
    email: str,
    password: str,
    name: str,
    profile_text: str,
    tagline: str | None = None,
    skills: str | None = None,
    offerings: str | None = None,
    seeking: str | None = None,
) -> str:
    """Register a new account with invite code + email/password. Returns session token on success.

    Optional structured fields (tagline, skills, offerings, seeking) are appended to profile_text
    to improve profile quality and matching. Use comma-separated values for skills.
    """
    full_text = _assemble_profile_text(profile_text, tagline=tagline, skills=skills, offerings=offerings, seeking=seeking)
    client = _get_client()
    try:
        result = await client.register(invite_code, email, password, name, full_text)
    except APIError as exc:
        raise ToolError(f"Registration failed: {exc.detail}") from exc
    finally:
        await client.close()
    token = result.get("session_token")
    if token:
        save_session_token(token)
    return _json(result)


@mcp.tool()
async def towow_login(email: str, password: str) -> str:
    """Log in with email and password. Returns session token on success."""
    client = _get_client()
    try:
        result = await client.login(email, password)
    except APIError as exc:
        raise ToolError(f"Login failed: {exc.detail}") from exc
    finally:
        await client.close()
    token = result.get("session_token")
    if token:
        save_session_token(token)
    return _json(result)


@mcp.tool()
async def towow_auth_begin(scene_id: str | None = None) -> str:
    """Start login via SecondMe — opens a browser challenge for authentication.

    Call with no arguments for a generic login.
    Pass scene_id to auto-bind to a scene after login.
    """
    return _json(await _begin_secondme_ai_auth(scene_id=scene_id))


@mcp.tool()
async def towow_auth_status(auth_session_id: str) -> str:
    """Check if the SecondMe AI login has been completed in the browser."""
    client = _get_client()
    try:
        result = await client.get_consumer_auth_session_status(auth_session_id)
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(_with_auth_status_next_tool(result))


@mcp.tool()
async def towow_auth_exchange(auth_session_id: str) -> str:
    """Complete the SecondMe AI login and activate your Towow session."""
    client = _get_client()
    try:
        result = await client.exchange_consumer_auth_session(auth_session_id)
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    session_token = result.pop("session_token", None)
    if not session_token:
        raise ToolError("Consumer auth exchange did not return a session_token.")

    save_session_token(session_token)
    default_agent_id = result.get("default_agent_id")
    if default_agent_id:
        save_agent(default_agent_id, result.get("name"))
    scene_id = result.get("scene_id")
    if scene_id:
        save_scene(scene_id, display_name=None)

    result["selected_agent"] = _selected_agent_payload()
    return _json(result)


@mcp.tool()
@_protect_auth_tool
async def towow_agents() -> str:
    """Show all your identities (profiles) and which one is currently active."""
    _require_auth()
    client = _get_client()
    try:
        result = await client.list_agents()
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(
        {
            "selected_agent": _selected_agent_payload(),
            "agents": [_pick_agent_payload(agent) for agent in result.get("agents", [])],
        }
    )


@mcp.tool()
@_protect_auth_tool
async def towow_agent_create(
    display_name: str,
    profile_text: str,
    visibility: str = "scoped",
    scoped_tags: list[str] | None = None,
) -> str:
    """Create a new identity for a different context (e.g., a separate profile for a specific project or role)."""
    _require_auth()
    client = _get_client()
    try:
        agent = await client.create_agent(
            display_name=display_name,
            profile_text=profile_text,
            visibility=visibility,
            scoped_tags=scoped_tags,
        )
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(
        {
            "agent": _pick_agent_payload(agent),
            "selected_agent": _selected_agent_payload(),
        }
    )


@mcp.tool()
@_protect_auth_tool
async def towow_agent_select(agent_id: str) -> str:
    """Switch to a different identity for subsequent actions."""
    _require_auth()
    client = _get_client()
    try:
        agent = await client.get_agent(agent_id)
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    save_agent(agent["agent_id"], agent.get("display_name"))
    return _json(
        {
            "selected_agent": _selected_agent_payload(),
            "agent": _pick_agent_payload(agent),
        }
    )


@mcp.tool()
@_protect_auth_tool
async def towow_agent_set_visibility(visibility: str, agent_id: str | None = None) -> str:
    """Control who can discover this identity — public, scoped (same scenario only), or private."""
    _require_auth()
    selected_agent_id = agent_id or _require_agent_id()
    client = _get_client()
    try:
        updated = await client.set_agent_visibility(selected_agent_id, visibility)
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    if selected_agent_id == get_agent_id():
        save_agent(updated["agent_id"], updated.get("display_name"))
    return _json(
        {
            "agent": _pick_agent_payload(updated),
            "selected_agent": _selected_agent_payload(),
        }
    )


@mcp.tool()
async def towow_set_scene(scene_id: str) -> str:
    """Set the scenario/context for your activities (e.g., startup collaboration, hackathon, AI gig market)."""
    client = _get_client()
    try:
        scene = await client.get_scene(scene_id)
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    save_scene(scene["scene_id"], scene.get("display_name"))
    return _json(
        {
            "scene": scene,
            "selected_scene": {
                "scene_id": scene["scene_id"],
                "display_name": scene.get("display_name"),
            },
        }
    )


@mcp.tool()
@_protect_auth_tool
async def towow_formulation_start(raw_intent: str, scene_context: str | None = None) -> str:
    """Start a guided conversation to clarify what you need. The system asks questions to understand your requirement, then finds the right people. (Protocol: formulation session)"""
    _require_auth()
    agent_id = _require_agent_id()
    client = _get_client()

    try:
        result = await client.create_formulation(
            agent_id=agent_id,
            raw_intent=raw_intent,
            scene_context=_resolve_scene_context(scene_context),
        )
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(
        {
            "session_id": result["session"]["session_id"],
            "agent_id": result["session"]["agent_id"],
            "reply": result["assistant_reply"],
            "document": result["session"]["formulated_demand"],
            "updates": result["updates"],
            "selected_agent": _selected_agent_payload(),
        }
    )


@mcp.tool()
@_protect_auth_tool
async def towow_formulation_reply(session_id: str, user_message: str) -> str:
    """Continue the guided conversation about what you need — keep refining until it's clear."""
    _require_auth()
    client = _get_client()
    try:
        resp = await client.formulation_reply_stream(session_id, user_message)
        full_text, updates = await consume_sse_stream(resp)
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except (SSEError, SSEAuthError) as exc:
        raise ToolError(f"Formulation error: {exc}") from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    client = _get_client()
    try:
        updated_session = await client.get_formulation(session_id)
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(
        {
            "session_id": session_id,
            "reply": full_text,
            "document": updated_session.get("formulated_demand", ""),
            "updates": updates,
            "selected_agent": _selected_agent_payload(),
        }
    )


@mcp.tool()
@_protect_auth_tool
async def towow_formulation_confirm(
    session_id: str,
    scope_tags: list[str] | None = None,
    max_candidates: int = 10,
    start_negotiation: bool = False,
    k: int | None = None,
) -> str:
    """Confirm your need, find matching people, and optionally start collaboration automatically. Set start_negotiation=true and k=3 for the recommended path. (Protocol: confirm → discovery → optional hosted negotiation)"""
    return _json(
        await _canonical_formulation_confirm(
            session_id=session_id,
            scope_tags=scope_tags,
            max_candidates=max_candidates,
            start_negotiation=start_negotiation,
            k=k,
        )
    )


@mcp.tool()
@_protect_auth_tool
async def towow_discover(
    demand_text: str,
    scope_tags: list[str] | None = None,
    scene_context: str | None = None,
    max_candidates: int = 10,
    start_negotiation: bool = False,
    k: int | None = None,
) -> str:
    """Directly find matching people for a clear, specific need. Set start_negotiation=true and k=3 to start collaboration automatically. (Protocol: discovery + optional hosted negotiation)"""
    _require_auth()
    requester = _require_agent_id()
    client = _get_client()
    try:
        result = await client.discover(
            requester=requester,
            demand_text=demand_text,
            scope_tags=scope_tags,
            scene_context=_resolve_scene_context(scene_context),
            max_candidates=max_candidates,
            start_negotiation=start_negotiation,
            k=k,
        )
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        if exc.status_code == 403:
            raise ToolError(
                "Profile 质量不足，请先完善 Profile。使用 towow_quality_score 查看当前评分和改进建议。"
            ) from exc
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(result)


@mcp.tool()
@_protect_auth_tool
async def towow_invite(nomination_id: str, expires_in_hours: int = 24) -> str:
    """Send a collaboration invitation to a specific recommended person. (Advanced flow — most users should use start_negotiation=true instead.)"""
    _require_auth()
    inviter = _require_agent_id()
    client = _get_client()
    try:
        invitation = await client.create_invitation(
            inviter=inviter,
            nomination_id=nomination_id,
            expires_in_hours=expires_in_hours,
        )
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(invitation)


@mcp.tool()
@_protect_auth_tool
async def towow_invitations(agent_id: str | None = None) -> str:
    """List collaboration invitations you've sent or received. (Advanced flow)"""
    _require_auth()
    current_agent_id = agent_id or _require_agent_id()
    client = _get_client()
    try:
        result = await client.list_invitations(agent_id=current_agent_id)
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(result)


@mcp.tool()
@_protect_auth_tool
async def towow_invitation_respond(invitation_id: str, action: str) -> str:
    """Accept or decline a collaboration invitation. (Advanced flow)"""
    _require_auth()
    agent_id = _require_agent_id()
    client = _get_client()
    try:
        invitation = await client.respond_invitation(invitation_id, agent_id=agent_id, action=action)
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(invitation)


@mcp.tool()
@_protect_auth_tool
async def towow_negotiate(invitation_ids: list[str], max_rounds: int = 4) -> str:
    """Start a collaboration session from accepted invitations. (Advanced flow — the automatic path handles this for you.)"""
    _require_auth()
    initiator = _require_agent_id()
    client = _get_client()
    try:
        result = await client.create_run(
            initiator=initiator,
            invitation_ids=invitation_ids,
            max_rounds=max_rounds,
        )
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(result)


@mcp.tool()
@_protect_auth_tool
async def towow_run_status(run_id: str) -> str:
    """Check the progress of an ongoing collaboration session."""
    _require_auth()
    client = _get_client()
    try:
        data = await client.get_run(run_id)
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(data)


@mcp.tool()
@_protect_auth_tool
async def towow_run_prompt(run_id: str) -> str:
    """Get the current discussion prompt if you need to participate manually in a collaboration session."""
    _require_auth()
    agent_id = _require_agent_id()
    client = _get_client()
    try:
        data = await client.get_run_prompt(run_id, agent_id=agent_id)
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(data)


@mcp.tool()
@_protect_auth_tool
async def towow_run_respond(
    run_id: str,
    round_number: int,
    content: str,
    metadata: dict[str, Any] | None = None,
) -> str:
    """Submit your response in a collaboration session that requires your manual participation."""
    _require_auth()
    agent_id = _require_agent_id()
    client = _get_client()
    try:
        data = await client.respond_run(
            run_id,
            agent_id=agent_id,
            round_number=round_number,
            content=content,
            metadata=metadata,
        )
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(data)


@mcp.tool()
@_protect_auth_tool
async def towow_result(run_id: str) -> str:
    """Get the final outcome of a completed collaboration session."""
    _require_auth()
    agent_id = _require_agent_id()
    client = _get_client()
    try:
        data = await client.get_run_result(run_id, agent_id=agent_id)
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(data)


@mcp.tool()
@_protect_auth_tool
async def towow_inbox() -> str:
    """Check your result notifications — see completed collaborations and their outcomes."""
    _require_auth()
    client = _get_client()
    try:
        data = await client.list_inbox()
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(data)


@mcp.tool()
@_protect_auth_tool
async def towow_inbox_item(item_id: str) -> str:
    """Open a specific result notification to see full details."""
    _require_auth()
    client = _get_client()
    try:
        data = await client.get_inbox_item(item_id)
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(data)


@mcp.tool()
@_protect_auth_tool
async def towow_inbox_mark_read(item_id: str) -> str:
    """Mark a result notification as read."""
    _require_auth()
    client = _get_client()
    try:
        data = await client.mark_inbox_item_read(item_id)
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(data)


@mcp.tool()
@_protect_auth_tool
async def towow_email_status() -> str:
    """Check if your email is verified for receiving result notifications."""
    _require_auth()
    client = _get_client()
    try:
        data = await client.get_account()
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    data["selected_agent"] = _selected_agent_payload()
    return _json(data)


@mcp.tool()
@_protect_auth_tool
async def towow_email_verify_send() -> str:
    """Send a verification link to your email so you can receive result notifications."""
    _require_auth()
    client = _get_client()
    try:
        data = await client.request_email_verification()
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    data["selected_agent"] = _selected_agent_payload()
    return _json(data)


@mcp.tool()
@_protect_auth_tool
async def towow_send_message(receiver_agent_id: str, source_run_id: str, content: str) -> str:
    """Send a follow-up message to someone you collaborated with."""
    _require_auth()
    sender_agent_id = _require_agent_id()
    client = _get_client()
    try:
        data = await client.send_message(
            sender_agent_id=sender_agent_id,
            receiver_agent_id=receiver_agent_id,
            source_run_id=source_run_id,
            content=content,
        )
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(data)


@mcp.tool()
@_protect_auth_tool
async def towow_conversations(limit: int = 20) -> str:
    """List your conversations with past collaborators."""
    _require_auth()
    client = _get_client()
    try:
        data = await client.list_conversations(limit=limit)
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(data)


@mcp.tool()
@_protect_auth_tool
async def towow_conversation_messages(conversation_id: str, since_seq: int = 0) -> str:
    """Read messages in a conversation with a collaborator."""
    _require_auth()
    client = _get_client()
    try:
        data = await client.get_conversation_messages(conversation_id, since_seq=since_seq)
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(data)


@mcp.tool()
@_protect_auth_tool
async def towow_feedback(
    target_type: str,
    target_id: str,
    exposure_event_id: str,
    rating: int,
    comment: str | None = None,
) -> str:
    """Rate and comment on a collaboration experience."""
    _require_auth()
    agent_id = _require_agent_id()
    client = _get_client()
    try:
        data = await client.submit_feedback(
            agent_id=agent_id,
            target_type=target_type,
            target_id=target_id,
            exposure_event_id=exposure_event_id,
            rating=rating,
            comment=comment,
        )
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(data)


@mcp.tool()
@_protect_auth_tool
async def towow_usage(period: str = "month") -> str:
    """Check your platform usage for the current period."""
    _require_auth()
    agent_id = _require_agent_id()
    client = _get_client()
    try:
        data = await client.get_usage(period=period, agent_id=agent_id)
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(data)


@mcp.tool()
@_protect_auth_tool
async def towow_update_profile(
    profile_text: str | None = None,
    display_name: str | None = None,
    scoped_tags: list[str] | None = None,
    capability_manifest: dict | None = None,
) -> str:
    """Update your profile — what you do, what you're looking for, what you can offer. Better profiles get better matches."""
    _require_auth()
    agent_id = _require_agent_id()
    client = _get_client()
    try:
        data = await client.update_agent(
            agent_id,
            display_name=display_name,
            profile_text=profile_text,
            scoped_tags=scoped_tags,
            capability_manifest=capability_manifest,
        )
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    if agent_id == get_agent_id():
        save_agent(agent_id, data.get("display_name"))
    return _json({"agent": _pick_agent_payload(data), "selected_agent": _selected_agent_payload()})


@mcp.tool()
@_protect_auth_tool
async def towow_agent_delete(agent_id: str) -> str:
    """Delete an identity you no longer need."""
    _require_auth()
    client = _get_client()
    try:
        await client.delete_agent(agent_id)
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    if agent_id == get_agent_id():
        clear_agent()
    return _json({"ok": True, "deleted_agent_id": agent_id})


@mcp.tool()
@_protect_auth_tool
async def towow_refresh_token() -> str:
    """Extend your login session before it expires."""
    _require_auth()
    client = _get_client()
    try:
        result = await client.refresh_token()
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    new_token = result.get("session_token")
    if new_token:
        save_session_token(new_token)
    return _json({"ok": True, "expires_at": result.get("expires_at")})


@mcp.tool()
@_protect_auth_tool
async def towow_byok_bind(api_key: str, provider: str = "anthropic", base_url: str | None = None) -> str:
    """Connect your own API key to bypass free usage limits. Supports Anthropic and compatible providers (e.g. MiniMax). Optional — everything works without this."""
    _require_auth()
    client = _get_client()
    try:
        result = await client.bind_byok(api_key, provider, base_url=base_url)
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(result)


@mcp.tool()
@_protect_auth_tool
async def towow_byok_status() -> str:
    """Check if your own API key is currently connected."""
    _require_auth()
    client = _get_client()
    try:
        result = await client.get_byok()
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(result)


@mcp.tool()
@_protect_auth_tool
async def towow_byok_clear() -> str:
    """Disconnect your API key."""
    _require_auth()
    client = _get_client()
    try:
        result = await client.clear_byok()
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(result)


@mcp.tool()
@_protect_auth_tool
async def towow_get_formulation(session_id: str) -> str:
    """Check the state of an ongoing need-description conversation without sending a new message."""
    _require_auth()
    client = _get_client()
    try:
        data = await client.get_formulation(session_id)
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(data)


@mcp.tool()
@_protect_auth_tool
async def towow_get_invitation(invitation_id: str) -> str:
    """Get details of a specific collaboration invitation. (Advanced flow)"""
    _require_auth()
    client = _get_client()
    try:
        data = await client.get_invitation(invitation_id)
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(data)


@mcp.tool()
@_protect_auth_tool
async def towow_get_discovery(query_id: str) -> str:
    """Review match results from a previous people search."""
    _require_auth()
    client = _get_client()
    try:
        data = await client.get_discovery_query(query_id)
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(data)


@mcp.tool()
@_protect_auth_tool
async def towow_demand_confirm(
    session_id: str,
    scope_tags: list[str] | None = None,
    max_candidates: int = 10,
    start_negotiation: bool = False,
    k: int | None = None,
) -> str:
    """Deprecated — use towow_formulation_confirm instead."""
    payload = await _canonical_formulation_confirm(
        session_id=session_id,
        scope_tags=scope_tags,
        max_candidates=max_candidates,
        start_negotiation=start_negotiation,
        k=k,
    )
    payload["deprecated_tool"] = "towow_demand_confirm"
    payload["replacement"] = "towow_formulation_confirm"
    return _json(payload)


@mcp.tool()
@_protect_auth_tool
async def towow_run_start(invitation_ids: list[str], max_rounds: int = 4) -> str:
    """Deprecated — use towow_negotiate instead."""
    data = json.loads(await towow_negotiate(invitation_ids=invitation_ids, max_rounds=max_rounds))
    data["deprecated_tool"] = "towow_run_start"
    data["replacement"] = "towow_negotiate"
    return _json(data)


@mcp.tool()
@_protect_auth_tool
async def towow_run_result(run_id: str) -> str:
    """Deprecated — use towow_result instead."""
    data = json.loads(await towow_result(run_id))
    data["deprecated_tool"] = "towow_run_result"
    data["replacement"] = "towow_result"
    return _json(data)


@mcp.tool()
async def towow_protocol_metadata() -> str:
    """Get technical metadata about the Towow protocol. (Developer tool — most users don't need this.)"""
    client = _get_client()
    try:
        data = await client.get_protocol_metadata()
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(data)


@mcp.tool()
async def towow_encoding_package() -> str:
    """Get the encoding configuration used by the matching system. (Developer tool)"""
    client = _get_client()
    try:
        data = await client.get_encoding_package()
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(data)


@mcp.tool()
async def towow_list_scenes() -> str:
    """Show all available scenarios/contexts you can participate in."""
    client = _get_client()
    try:
        data = await client.list_scenes()
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(data)


@mcp.tool()
@_protect_auth_tool
async def towow_get_nomination(nomination_id: str) -> str:
    """See why a specific person was recommended — match score, reasoning, and profile summary."""
    _require_auth()
    client = _get_client()
    try:
        data = await client.get_nomination(nomination_id)
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(data)


@mcp.tool()
async def towow_get_agent_federation(agent_id: str) -> str:
    """Get cross-platform identity and interoperability information. (Developer tool)"""
    client = _get_client()
    try:
        data = await client.get_agent_federation(agent_id)
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(data)


@mcp.tool()
async def towow_get_agent_did(agent_id: str) -> str:
    """Get the decentralized identity document for a person. (Developer tool)"""
    client = _get_client()
    try:
        data = await client.get_agent_did(agent_id)
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(data)


@mcp.tool()
@_protect_auth_tool
async def towow_discover_rerun(
    query_id: str,
    scope_tags: list[str] | None = None,
    max_candidates: int = 10,
    start_negotiation: bool = False,
    k: int | None = None,
) -> str:
    """Re-run a previous people search with different parameters (e.g., more or fewer matches)."""
    _require_auth()
    client = _get_client()
    try:
        data = await client.rerun_discovery(
            query_id,
            scope_tags=scope_tags,
            max_candidates=max_candidates,
            start_negotiation=start_negotiation,
            k=k,
        )
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(data)


@mcp.tool()
@_protect_auth_tool
async def towow_conversation_mark_read(conversation_id: str, up_to_seq: int = 0) -> str:
    """Mark messages in a conversation as read up to a specific point."""
    _require_auth()
    client = _get_client()
    try:
        data = await client.mark_conversation_read(conversation_id, up_to_seq)
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(data)


@mcp.tool()
@_protect_auth_tool
async def towow_quality_score() -> str:
    """Check your profile quality score. Returns total score, grade (A/B/C), dimension breakdown, and improvement suggestions."""
    _require_auth()
    agent_id = _require_agent_id()
    client = _get_client()
    try:
        data = await client.get_agent_quality(agent_id)
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(data)


@mcp.tool()
@_protect_auth_tool
async def towow_invite_codes() -> str:
    """View your invite codes — share them with others to join the platform. Shows code list, availability, and next replenishment date."""
    _require_auth()
    client = _get_client()
    try:
        data = await client.get_invite_codes()
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(data)


@mcp.tool()
@_protect_auth_tool
async def towow_change_password(current_password: str, new_password: str) -> str:
    """Change your account password. Requires current password for verification. New password must be at least 8 characters with both letters and digits. All existing sessions are invalidated and a new session token is returned."""
    _require_auth()
    client = _get_client()
    try:
        data = await client.change_password(current_password, new_password)
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    # Update local session with new token
    new_token = data.get("session_token")
    if new_token:
        save_session_token(new_token)

    return _json(data)


# --- Public directory (no auth) ---


@mcp.tool()
async def towow_public_agents(
    scope_tags: list[str] | None = None,
    offset: int = 0,
    limit: int = 20,
) -> str:
    """Browse the public directory of people and their profiles — no login required."""
    client = _get_client()
    try:
        data = await client.list_public_agents(
            scope_tags=scope_tags, offset=offset, limit=limit,
        )
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()
    return _json(data)


@mcp.tool()
async def towow_public_agent(agent_id: str) -> str:
    """View a specific person's public profile — no login required."""
    client = _get_client()
    try:
        data = await client.get_public_agent(agent_id)
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()
    return _json(data)


@mcp.tool()
async def towow_public_demands(offset: int = 0, limit: int = 20) -> str:
    """Browse public needs posted by others — no login required."""
    client = _get_client()
    try:
        data = await client.list_public_demands(offset=offset, limit=limit)
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()
    return _json(data)


@mcp.tool()
async def towow_public_demand(demand_id: str) -> str:
    """View details of a specific public need — no login required."""
    client = _get_client()
    try:
        data = await client.get_public_demand(demand_id)
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()
    return _json(data)


@mcp.tool()
async def towow_public_runs(
    status: str | None = None,
    offset: int = 0,
    limit: int = 20,
) -> str:
    """Browse completed public collaboration sessions — no login required."""
    client = _get_client()
    try:
        data = await client.list_public_runs(
            status=status, offset=offset, limit=limit,
        )
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()
    return _json(data)


@mcp.tool()
async def towow_public_run(run_id: str) -> str:
    """View details of a specific public collaboration — no login required."""
    client = _get_client()
    try:
        data = await client.get_public_run(run_id)
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()
    return _json(data)


@mcp.tool()
async def towow_public_run_result(run_id: str) -> str:
    """View the outcome of a public collaboration — no login required."""
    client = _get_client()
    try:
        data = await client.get_public_run_result(run_id)
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()
    return _json(data)


# --- Talent pool (auth required) ---


@mcp.tool()
@_protect_auth_tool
async def towow_talent_pool() -> str:
    """View your saved list of interesting people for future collaboration."""
    _require_auth()
    client = _get_client()
    try:
        data = await client.list_talent_pool()
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()
    return _json(data)


@mcp.tool()
@_protect_auth_tool
async def towow_talent_pool_add(agent_id: str, category: str | None = None) -> str:
    """Save someone to your talent pool for future reference."""
    _require_auth()
    client = _get_client()
    try:
        data = await client.add_to_talent_pool(agent_id, category=category)
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()
    return _json(data)


@mcp.tool()
@_protect_auth_tool
async def towow_talent_pool_update(agent_id: str, category: str) -> str:
    """Update the category of someone in your talent pool."""
    _require_auth()
    client = _get_client()
    try:
        data = await client.update_talent_pool_entry(agent_id, category=category)
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()
    return _json(data)


@mcp.tool()
@_protect_auth_tool
async def towow_talent_pool_remove(agent_id: str) -> str:
    """Remove someone from your talent pool."""
    _require_auth()
    client = _get_client()
    try:
        await client.remove_from_talent_pool(agent_id)
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()
    return _json({"ok": True, "removed_agent_id": agent_id})


# --- Visibility control (auth required) ---


@mcp.tool()
@_protect_auth_tool
async def towow_demand_visibility(demand_id: str, visibility: str) -> str:
    """Make your need public (visible to everyone) or private."""
    _require_auth()
    client = _get_client()
    try:
        data = await client.set_demand_visibility(demand_id, visibility=visibility)
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()
    return _json(data)


@mcp.tool()
@_protect_auth_tool
async def towow_run_visibility(run_id: str, public_visibility: bool) -> str:
    """Make a collaboration session public (visible to everyone) or private."""
    _require_auth()
    client = _get_client()
    try:
        data = await client.set_run_visibility(run_id, public_visibility=public_visibility)
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()
    return _json(data)


# --- Account security ---


@mcp.tool()
async def towow_forgot_password(email: str) -> str:
    """Request a password reset link sent to your email."""
    client = _get_client()
    try:
        data = await client.forgot_password(email)
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()
    return _json(data)


@mcp.tool()
async def towow_reset_password(token: str, new_password: str) -> str:
    """Reset your password using the token from the reset email."""
    client = _get_client()
    try:
        data = await client.reset_password(token, new_password)
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()
    return _json(data)


@mcp.tool()
@_protect_auth_tool
async def towow_delete_account(password: str, confirmation: str) -> str:
    """Permanently delete your account and all associated data. This action cannot be undone. Requires your password and the word DELETE as confirmation."""
    _require_auth()
    client = _get_client()
    try:
        await client.delete_account(password=password, confirmation=confirmation)
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()
    return _json({"ok": True, "account_deleted": True})


# --- ANP DID authentication (developer-level) ---


@mcp.tool()
async def towow_anp_challenge(did: str) -> str:
    """[Developer] Create a DID authentication challenge for cross-platform identity verification."""
    client = _get_client()
    try:
        data = await client.anp_challenge(did)
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()
    return _json(data)


@mcp.tool()
async def towow_anp_verify(did: str, challenge: str, signature: str) -> str:
    """[Developer] Verify a DID signature and get a session token."""
    client = _get_client()
    try:
        data = await client.anp_verify(did, challenge, signature)
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()
    return _json(data)


@mcp.tool()
async def towow_logout() -> str:
    """Log out of your account and clear the session."""
    token = get_session_token()
    if token:
        client = _get_client()
        try:
            await client.logout()
        except (AuthError, APIError):
            logger.debug("Ignoring remote logout failure during MCP local logout.", exc_info=True)
        finally:
            await client.close()
    clear_session_token()
    clear_agent()
    return _json({"ok": True})


def main() -> None:
    import argparse

    parser = argparse.ArgumentParser(description="Towow MCP Server")
    parser.add_argument(
        "--transport",
        choices=["stdio", "sse", "streamable-http"],
        default="stdio",
        help="Transport mode (default: stdio)",
    )
    parser.add_argument(
        "--host", default="0.0.0.0", help="Host for HTTP transports (default: 0.0.0.0)"
    )
    parser.add_argument(
        "--port", type=int, default=8811, help="Port for HTTP transports (default: 8811)"
    )
    args = parser.parse_args()

    if args.transport != "stdio":
        _os.environ["TOWOW_MCP_HOST"] = args.host
        _os.environ["TOWOW_MCP_PORT"] = str(args.port)
        mcp.settings.host = args.host
        mcp.settings.port = args.port

    mcp.run(transport=args.transport)


if __name__ == "__main__":
    main()
