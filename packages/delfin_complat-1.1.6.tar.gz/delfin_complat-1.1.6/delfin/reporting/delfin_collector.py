"""
DELFIN Data Collector - Collects all data from DELFIN calculations into JSON format.

This module parses:
- initial.inp (metadata, molecule info)
- initial.out (initial S0 optimization)
- ox_step_1.out, red_step_1.out (oxidized/reduced states)
- OCCUPIER/ folder (charge transfer analysis, if exists)
- ESD/ folder (all excited states, ISC, IC)
- All .xyz geometries
- All thermochemistry data (Gibbs, ZPE, etc.)
- All spectroscopic data (absorption, emission)
- All rate constants (ISC, IC, radiative)
"""

from __future__ import annotations

import io
import json
import re
from pathlib import Path
from typing import Any, Dict, Optional

from delfin.common.logging import get_logger
from delfin.uv_vis_spectrum import parse_absorption_spectrum
from delfin.utils import get_git_commit_info
from delfin.config import read_control_file, _parse_control_file, get_E_ref
from delfin.energies import find_gibbs_energy
from delfin.cli_calculations import calculate_redox_potentials, select_final_potentials
from delfin.ir_spectrum import parse_ir_spectrum

logger = get_logger(__name__)

HARTREE_TO_EV = 27.211386245988
HARTREE_TO_KJ_MOL = 2625.499639
_ORCA_JOB_MARKER_RE = re.compile(
    r"^\s*\$+\s+JOB\s+NUMBER\s+(\d+)\s+\$+\s*$",
    flags=re.IGNORECASE | re.MULTILINE,
)
_ORCA_NEW_JOB_RE = re.compile(r"^\s*\$new_job\s*$", flags=re.IGNORECASE | re.MULTILINE)
_ORCA_BASE_RE = re.compile(r'^\s*%base\s+"?([^"\n]+)"?\s*$', flags=re.IGNORECASE | re.MULTILINE)
_ORCA_COORD_RE = re.compile(r"\*\s+xyz(?:file)?\s+(-?\d+)\s+(\d+)", flags=re.IGNORECASE)


def _energy_payload(energy_hartree: float) -> Dict[str, float]:
    return {
        "hartree": energy_hartree,
        "eV": energy_hartree * HARTREE_TO_EV,
        "kJ_mol": energy_hartree * HARTREE_TO_KJ_MOL,
    }


def _scf_energies_from_job_content(content: str) -> list[float]:
    opt_done_match = re.search(r'\*\*\* OPTIMIZATION RUN DONE \*\*\*', content)
    search_content = content[:opt_done_match.start()] if opt_done_match else content
    return [float(match) for match in re.findall(r'FINAL SINGLE POINT ENERGY\s+([-\d.]+)', search_content)]


def _read_text_file(path: Path) -> Optional[str]:
    try:
        return path.read_text(encoding="utf-8", errors="ignore")
    except Exception as exc:  # noqa: BLE001
        logger.warning("Failed to read %s: %s", path, exc)
        return None


def _split_orca_output_jobs(content: str) -> dict[int, str]:
    markers = list(_ORCA_JOB_MARKER_RE.finditer(content))
    if not markers:
        return {1: content}

    jobs: dict[int, str] = {}
    first_marker = markers[0]
    first_job_number = int(first_marker.group(1))
    if first_job_number != 1 and first_marker.start() > 0:
        jobs[1] = content[:first_marker.start()]

    for idx, marker in enumerate(markers):
        job_number = int(marker.group(1))
        start = 0 if idx == 0 and job_number == 1 else marker.start()
        end = markers[idx + 1].start() if idx + 1 < len(markers) else len(content)
        jobs[job_number] = content[start:end]

    return jobs


def _split_orca_input_jobs(content: str) -> dict[int, str]:
    blocks = _ORCA_NEW_JOB_RE.split(content)
    return {idx + 1: block for idx, block in enumerate(blocks) if block.strip()}


def _parse_orca_input_job_bases(inp_file: Path) -> dict[int, str]:
    content = _read_text_file(inp_file)
    if content is None:
        return {}

    bases: dict[int, str] = {}
    for job_number, block in _split_orca_input_jobs(content).items():
        match = _ORCA_BASE_RE.search(block)
        if match:
            bases[job_number] = match.group(1).strip()
        elif job_number == 1:
            bases[job_number] = inp_file.stem
    return bases


def _resolve_orca_job_number(
    *,
    inp_file: Optional[Path] = None,
    job_base: Optional[str] = None,
    job_number: Optional[int] = None,
) -> Optional[int]:
    if job_number is not None:
        return job_number
    if not job_base:
        return None
    if inp_file is None or not inp_file.exists():
        return None

    for current_job, base_name in _parse_orca_input_job_bases(inp_file).items():
        if base_name.casefold() == job_base.casefold():
            return current_job
    return None


def _extract_orca_output_job_text(
    output_file: Path,
    *,
    inp_file: Optional[Path] = None,
    job_base: Optional[str] = None,
    job_number: Optional[int] = None,
) -> tuple[Optional[str], Optional[int]]:
    content = _read_text_file(output_file)
    if content is None:
        return None, None

    if job_number is None and job_base is None:
        return content, None

    resolved_job = _resolve_orca_job_number(
        inp_file=inp_file,
        job_base=job_base,
        job_number=job_number,
    )
    if resolved_job is None:
        return None, None

    return _split_orca_output_jobs(content).get(resolved_job), resolved_job


def _extract_orca_input_job_text(
    inp_file: Path,
    *,
    job_base: Optional[str] = None,
    job_number: Optional[int] = None,
) -> tuple[Optional[str], Optional[int]]:
    content = _read_text_file(inp_file)
    if content is None:
        return None, None

    if job_number is None and job_base is None:
        return content, None

    resolved_job = _resolve_orca_job_number(
        inp_file=inp_file,
        job_base=job_base,
        job_number=job_number,
    )
    if resolved_job is None:
        return None, None

    return _split_orca_input_jobs(content).get(resolved_job), resolved_job


def parse_delfin_txt(project_dir: Path) -> Dict[str, Any]:
    """Parse DELFIN.txt summary file for redox potentials and other info."""
    delfin_txt = project_dir / "DELFIN.txt"
    if not delfin_txt.exists():
        return {}

    data = {
        "redox_potentials_vs_fc": {},
        "total_run_time": None,
    }

    try:
        with open(delfin_txt, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()

        # Parse redox potentials (V vs. Fc+/Fc)
        redox_patterns = [
            (r'E_red\s*=\s*([-\d.]+)', 'E_red'),
            (r'E_red_2\s*=\s*([-\d.]+)', 'E_red_2'),
            (r'E_red_3\s*=\s*([-\d.]+)', 'E_red_3'),
            (r'E_ox\s*=\s*([-\d.]+)', 'E_ox'),
            (r'E_ox_2\s*=\s*([-\d.]+)', 'E_ox_2'),
            (r'E_ox_3\s*=\s*([-\d.]+)', 'E_ox_3'),
            (r'E_ref\s*=\s*([-\d.]+)', 'E_ref'),
        ]

        for pattern, key in redox_patterns:
            match = re.search(pattern, content)
            if match:
                try:
                    data["redox_potentials_vs_fc"][key] = float(match.group(1))
                except ValueError:
                    pass

        # Parse total run time
        time_match = re.search(r'TOTAL RUN TIME:\s*(\d+)\s*hours?\s*(\d+)\s*minutes?\s*([\d.]+)\s*seconds?', content, re.IGNORECASE)
        if time_match:
            hours = int(time_match.group(1))
            minutes = int(time_match.group(2))
            seconds = float(time_match.group(3))
            data["total_run_time"] = {
                "hours": hours,
                "minutes": minutes,
                "seconds": seconds,
                "total_seconds": hours * 3600 + minutes * 60 + seconds
            }

    except Exception as e:
        logger.error(f"Error parsing DELFIN.txt: {e}")

    return data


def parse_control_flags(project_dir: Path) -> Dict[str, Any]:
    """Parse CONTROL.txt for simple flags (e.g., IMAG=yes)."""
    control = project_dir / "CONTROL.txt"
    flags: Dict[str, Any] = {}
    if not control.exists():
        return flags

    try:
        content = control.read_text(encoding="utf-8", errors="ignore")
        imag_match = re.search(r'^\s*IMAG\s*=\s*(\w+)', content, flags=re.IGNORECASE | re.MULTILINE)
        if imag_match:
            flags["imag"] = imag_match.group(1).strip().lower() == "yes"
    except Exception as exc:  # noqa: BLE001
        logger.warning("Failed to parse CONTROL.txt for flags: %s", exc)

    return flags


def parse_control_config(project_dir: Path) -> Dict[str, Any]:
    """Parse CONTROL.txt and return parsed values and validated config."""
    control = project_dir / "CONTROL.txt"
    if not control.exists():
        return {}

    data: Dict[str, Any] = {"parsed": {}, "validated": {}}
    try:
        content = control.read_text(encoding="utf-8", errors="ignore")
    except Exception as exc:  # noqa: BLE001
        logger.warning("Failed to read CONTROL.txt: %s", exc)
        content = ""

    if content:
        try:
            data["parsed"] = _parse_control_file(
                str(control),
                keep_steps_literal=True,
                content=content,
            )
        except Exception as exc:  # noqa: BLE001
            logger.warning("Failed to parse CONTROL.txt (raw): %s", exc)
            data["parsed"] = {}

    try:
        data["validated"] = read_control_file(str(control))
    except Exception as exc:  # noqa: BLE001
        logger.warning("Failed to parse CONTROL.txt (validated): %s", exc)
        data["validated"] = {}

    return data


def parse_ir_spectrum_data(project_dir: Path) -> Optional[Dict[str, Any]]:
    """Parse IR spectrum data from the first available frequency output."""
    candidates = [
        project_dir / "ESD" / "S0.out",
        project_dir / "S0.out",
        project_dir / "initial.out",
    ]
    output_file = next((path for path in candidates if path.exists()), None)
    if not output_file:
        return None

    modes = parse_ir_spectrum(output_file)
    if not modes:
        return None

    return {
        "source_file": output_file.name,
        "modes": [
            {
                "mode_number": m.mode_number,
                "frequency_cm1": m.frequency_cm1,
                "epsilon": m.epsilon,
                "intensity_km_mol": m.intensity_km_mol,
                "t_squared": m.t_squared,
                "tx": m.tx,
                "ty": m.ty,
                "tz": m.tz,
            }
            for m in modes
        ],
    }


def parse_goat_conformer_count(project_dir: Path) -> Optional[int]:
    """Parse 'Conformers below 3 kcal/mol: X' from XTB_GOAT output."""
    goat_candidates = [
        project_dir / "XTB_GOAT" / "output_XTB_GOAT.out",
        project_dir / "XTB2_GOAT" / "output_XTB_GOAT.out",
        project_dir / "output_XTB_GOAT.out",
    ]

    for goat_file in goat_candidates:
        if not goat_file.exists():
            continue
        try:
            content = goat_file.read_text(encoding="utf-8", errors="ignore")
            match = re.search(r'Conformers below 3 kcal/mol:\s*(\d+)', content)
            if match:
                return int(match.group(1))
        except Exception as exc:  # noqa: BLE001
            logger.warning("Failed to parse GOAT conformer count from %s: %s", goat_file, exc)
    return None


def parse_input_data(project_dir: Path, control_config: Dict[str, Any]) -> Dict[str, Any]:
    """Parse input file for SMILES or XYZ body and store minimal data for reporting."""
    validated = control_config.get("validated", {}) if control_config else {}
    input_entry = (validated.get("input_file") or "input.txt").strip() or "input.txt"
    input_path = Path(input_entry)
    if not input_path.is_absolute():
        input_path = project_dir / input_path

    data: Dict[str, Any] = {"source_file": input_path.name}
    if not input_path.exists():
        return data

    try:
        lines = [line.strip() for line in input_path.read_text(encoding="utf-8", errors="ignore").splitlines()]
    except Exception as exc:  # noqa: BLE001
        logger.warning("Failed to read input file %s: %s", input_path, exc)
        return data

    content = [ln for ln in lines if ln and not ln.startswith("#")]
    if content and all(len(ln.split()) >= 4 and ln.split()[0][0].isalpha() for ln in content):
        data["xyz_body"] = content
        return data

    if content:
        data["smiles"] = content[0]
    return data


def collect_gibbs_energies(project_dir: Path) -> Dict[str, Optional[float]]:
    """Collect Gibbs free energies for ground/charged states."""
    state_files = {
        "0": project_dir / "initial.out",
        "+1": project_dir / "ox_step_1.out",
        "+2": project_dir / "ox_step_2.out",
        "+3": project_dir / "ox_step_3.out",
        "-1": project_dir / "red_step_1.out",
        "-2": project_dir / "red_step_2.out",
        "-3": project_dir / "red_step_3.out",
    }

    energies: Dict[str, Optional[float]] = {}
    for key, path in state_files.items():
        if not path.exists():
            energies[key] = None
            continue
        energies[key] = find_gibbs_energy(str(path))

    # Fallback: try ESD/S0.out for the neutral state if initial.out is missing
    if energies.get("0") is None:
        esd_s0 = project_dir / "ESD" / "S0.out"
        if esd_s0.exists():
            energies["0"] = find_gibbs_energy(str(esd_s0))

    return energies


def serialize_esd_summary(summary: Any) -> Dict[str, Any]:
    """Serialize ESDSummary dataclasses to JSON-friendly dicts."""
    if summary is None:
        return {}

    states = {}
    for key, result in summary.states.items():
        states[key] = {
            "fspe_hartree": result.fspe,
            "zpe_hartree": result.zpe,
            "gibbs_hartree": result.gibbs,
            "source_file": str(result.source),
        }

    isc = {}
    for key, result in summary.isc.items():
        isc[key] = {
            "rate_s1": result.rate,
            "temperature_K": result.temperature,
            "delta_E_cm1": result.delta_cm1,
            "soc_re_cm1": result.soc[0] if result.soc else None,
            "soc_im_cm1": result.soc[1] if result.soc else None,
            "fc_percent": result.fc_percent,
            "ht_percent": result.ht_percent,
            "source_file": str(result.source),
        }

    ic = {}
    for key, result in summary.ic.items():
        ic[key] = {
            "rate_s1": result.rate,
            "temperature_K": result.temperature,
            "delta_E_cm1": result.delta_cm1,
            "source_file": str(result.source),
        }

    fluor = {}
    for key, result in summary.fluor.items():
        fluor[key] = {
            "rate_s1": result.rate,
            "temperature_K": result.temperature,
            "delta_E_cm1": result.delta_cm1,
            "source_file": str(result.source),
        }

    phosp = {}
    for key, result in summary.phosp.items():
        phosp[key] = {
            "sublevel_rates_s1": list(result.sublevel_rates),
            "rate_mean_s1": result.rate_mean,
            "temperature_K": result.temperature,
            "delta_E_cm1": result.delta_cm1,
            "source_file": str(result.source),
        }

    return {
        "states": states,
        "isc": isc,
        "ic": ic,
        "fluorescence": fluor,
        "phosphorescence": phosp,
    }

def parse_initial_inp(project_dir: Path) -> Dict[str, Any]:
    """Parse initial.inp (or fallback S0.inp) file for metadata."""
    initial_inp = project_dir / "initial.inp"
    # Fallback: use S0.inp inside ESD if initial.inp is missing
    if not initial_inp.exists():
        s0_inp = project_dir / "ESD" / "S0.inp"
        if s0_inp.exists():
            initial_inp = s0_inp
            logger.info(f"initial.inp not found, using fallback {s0_inp}")
        else:
            logger.warning(f"initial.inp not found in {project_dir} and no fallback S0.inp")
            return {}

    metadata = {
        "functional": None,
        "basis_set": None,
        "auxiliary_basis": None,
        "ri_method": None,
        "dispersion_correction": None,
        "implicit_solvation": None,
        "solvent": None,
        "charge": 0,
        "multiplicity": 1
    }

    try:
        with open(initial_inp, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()

        # Extract from ! line
        keyword_match = re.search(r'!\s+(.+)', content)
        if keyword_match:
            keywords = keyword_match.group(1).split()
            for kw in keywords:
                kw_upper = kw.upper()
                if any(func in kw_upper for func in ['PBE0', 'PBE', 'B3LYP', 'WB97', 'CAM-B3LYP', 'M062X', 'TPSS']):
                    if not metadata['functional']:  # Don't overwrite
                        metadata['functional'] = kw
                elif any(basis in kw_upper for basis in ['DEF2-SVP', 'DEF2-TZVP', 'DEF2-TZVPP', '6-31G', 'CC-PVDZ']):
                    metadata['basis_set'] = kw
                elif '/J' in kw or '-J' in kw or 'JKFIT' in kw_upper or 'AUX' in kw_upper:
                    metadata['auxiliary_basis'] = kw
                elif any(token in kw_upper for token in ['RIJCOSX', 'RICOSX', 'RIJONX', 'RI']):
                    metadata['ri_method'] = kw
                elif 'D3' in kw_upper or 'D4' in kw_upper:
                    metadata['dispersion_correction'] = kw
                elif 'CPCM' in kw_upper:
                    metadata['implicit_solvation'] = 'CPCM'
                elif 'SMD' in kw_upper:
                    metadata['implicit_solvation'] = 'SMD'

        # Extract solvent
        solvent_match = re.search(r'(CPCM|SMD)\((\w+)\)', content, re.IGNORECASE)
        if solvent_match:
            metadata['solvent'] = solvent_match.group(2)

        # Extract charge and multiplicity from coordinate block
        coord_match = re.search(r'\*\s+xyz\s+(-?\d+)\s+(\d+)', content)
        if coord_match:
            metadata['charge'] = int(coord_match.group(1))
            metadata['multiplicity'] = int(coord_match.group(2))

    except Exception as e:
        logger.error(f"Error parsing initial.inp: {e}")

    return metadata


def parse_tddft_settings(inp_file: Path) -> Dict[str, Any]:
    """Extract key TDDFT keywords (e.g., NROOTS, MAXDIM, FOLLOWIROOT) from an ORCA input."""
    settings: Dict[str, Any] = {}
    if not inp_file.exists():
        return settings

    try:
        content = inp_file.read_text(encoding="utf-8", errors="ignore")
    except Exception as exc:  # noqa: BLE001
        logger.warning("Failed to read %s for TDDFT settings: %s", inp_file, exc)
        return settings

    # Only scan the TDDFT block to avoid false positives elsewhere
    tddft_blocks = re.findall(r"%\s*TDDFT(.*?)(?:\n\s*end|\Z)", content, flags=re.IGNORECASE | re.DOTALL)
    block_text = "\n".join(tddft_blocks) if tddft_blocks else content

    def _extract_int(keyword: str) -> Optional[int]:
        match = re.search(rf"{keyword}\s*=?\s*([-\d]+)", block_text, flags=re.IGNORECASE)
        if match:
            try:
                return int(match.group(1))
            except Exception:
                return match.group(1)
        return None

    for key in ["NROOTS", "MAXDIM", "FOLLOWIROOT"]:
        val = _extract_int(key)
        if val is not None:
            settings[key.lower()] = val

    return settings


def parse_charge_multiplicity(
    inp_file: Path,
    *,
    job_base: Optional[str] = None,
    job_number: Optional[int] = None,
) -> Optional[Dict[str, int]]:
    """Parse charge and multiplicity from an ORCA input file."""
    if not inp_file.exists():
        return None

    try:
        content, _ = _extract_orca_input_job_text(
            inp_file,
            job_base=job_base,
            job_number=job_number,
        )
        if content is None:
            return None

        coord_match = _ORCA_COORD_RE.search(content)
        if coord_match:
            return {
                "charge": int(coord_match.group(1)),
                "multiplicity": int(coord_match.group(2))
            }
    except Exception as e:
        logger.error(f"Error parsing charge/multiplicity from {inp_file}: {e}")

    return None


def parse_orbitals_from_occuper(out_file: Path) -> Optional[Dict[str, Any]]:
    """Parse orbitals from the matched OCCUPIER .out file if present (last block)."""
    return parse_orbitals(out_file) if out_file.exists() else None


def parse_scf_energy(
    output_file: Path,
    *,
    inp_file: Optional[Path] = None,
    job_base: Optional[str] = None,
    job_number: Optional[int] = None,
) -> Optional[Dict[str, Any]]:
    """Parse SCF energy from ORCA output file.

    Uses the last FINAL SINGLE POINT ENERGY before 'OPTIMIZATION RUN DONE'.
    This excludes subsequent single-point calculations (e.g., TDDFT at optimized geometry).
    """
    if not output_file.exists():
        return None

    try:
        content, _ = _extract_orca_output_job_text(
            output_file,
            inp_file=inp_file,
            job_base=job_base,
            job_number=job_number,
        )
        if content is None:
            return None

        energy_matches = _scf_energies_from_job_content(content)
        if energy_matches:
            return _energy_payload(energy_matches[-1])
    except Exception as e:
        logger.error(f"Error parsing SCF energy from {output_file}: {e}")

    return None


def parse_first_scf_energy(
    output_file: Path,
    *,
    inp_file: Optional[Path] = None,
    job_base: Optional[str] = None,
    job_number: Optional[int] = None,
) -> Optional[Dict[str, Any]]:
    """Parse the first FINAL SINGLE POINT ENERGY of an ORCA job."""
    if not output_file.exists():
        return None

    try:
        content, _ = _extract_orca_output_job_text(
            output_file,
            inp_file=inp_file,
            job_base=job_base,
            job_number=job_number,
        )
        if content is None:
            return None

        energy_matches = _scf_energies_from_job_content(content)
        if energy_matches:
            return _energy_payload(energy_matches[0])
    except Exception as e:
        logger.error(f"Error parsing first SCF energy from {output_file}: {e}")

    return None


def parse_thermochemistry(
    output_file: Path,
    *,
    inp_file: Optional[Path] = None,
    job_base: Optional[str] = None,
    job_number: Optional[int] = None,
) -> Optional[Dict[str, Any]]:
    """Parse thermochemistry data from frequency calculation."""
    if not output_file.exists():
        return None

    try:
        content, _ = _extract_orca_output_job_text(
            output_file,
            inp_file=inp_file,
            job_base=job_base,
            job_number=job_number,
        )
        if content is None:
            return None

        thermo = {}

        # Temperature and pressure
        temp_match = re.search(r'Temperature\s+\.\.\.\s+([\d.]+)\s+K', content)
        press_match = re.search(r'Pressure\s+\.\.\.\s+([\d.]+)\s+atm', content)

        if temp_match:
            thermo['temperature_K'] = float(temp_match.group(1))
        if press_match:
            thermo['pressure_atm'] = float(press_match.group(1))

        # Zero-point energy
        zpe_match = re.search(r'Zero point energy\s+\.\.\.\s+([\d.]+)\s+Eh', content)
        if zpe_match:
            zpe_hartree = float(zpe_match.group(1))
            thermo['zero_point_energy_hartree'] = zpe_hartree
            thermo['zero_point_energy_eV'] = zpe_hartree * HARTREE_TO_EV
            thermo['zero_point_energy_kJ_mol'] = zpe_hartree * HARTREE_TO_KJ_MOL

        # Thermal corrections / thermodynamic totals
        thermal_energy_match = re.search(r'Total thermal energy\s+([-\d.]+)\s+Eh', content)
        thermal_enthalpy_match = re.search(r'Total enthalpy\s+([-\d.]+)\s+Eh', content)
        thermal_gibbs_match = re.search(r'Final Gibbs free energy\s+\.\.\.\s+([-\d.]+)\s+Eh', content)

        if thermal_energy_match:
            thermo["total_thermal_energy_hartree"] = float(thermal_energy_match.group(1))
            thermo["total_thermal_energy_eV"] = thermo["total_thermal_energy_hartree"] * HARTREE_TO_EV

        if thermal_enthalpy_match:
            thermo["total_enthalpy_hartree"] = float(thermal_enthalpy_match.group(1))
            thermo["total_enthalpy_eV"] = thermo["total_enthalpy_hartree"] * HARTREE_TO_EV

        if thermal_gibbs_match:
            gibbs_hartree = float(thermal_gibbs_match.group(1))
            thermo['total_gibbs_free_energy_hartree'] = gibbs_hartree
            thermo['total_gibbs_free_energy_eV'] = gibbs_hartree * HARTREE_TO_EV

        # Entropy
        entropy_match = re.search(r'Total entropy correction\s+([-\d.]+)\s+Eh', content)
        if entropy_match:
            thermo['entropy_correction_hartree'] = float(entropy_match.group(1))

        return thermo if thermo else None

    except Exception as e:
        logger.error(f"Error parsing thermochemistry from {output_file}: {e}")

    return None


def parse_dipole_moment(
    output_file: Path,
    *,
    inp_file: Optional[Path] = None,
    job_base: Optional[str] = None,
    job_number: Optional[int] = None,
) -> Optional[Dict[str, Any]]:
    """Parse permanent dipole moment from ORCA output."""
    if not output_file.exists():
        return None

    try:
        content, _ = _extract_orca_output_job_text(
            output_file,
            inp_file=inp_file,
            job_base=job_base,
            job_number=job_number,
        )
        if content is None:
            return None

        # Find the LAST dipole moment (after optimization)
        # Pattern matches:
        # Total Dipole Moment    :     -0.286613982       1.115620361       0.186158294
        #                         -----------------------------------------
        # Magnitude (a.u.)       :      1.166795301
        # Magnitude (Debye)      :      2.965757963
        dipole_matches = re.findall(
            r'Total Dipole Moment\s+:\s+([-\d.]+)\s+([-\d.]+)\s+([-\d.]+).*?'
            r'Magnitude \(a\.u\.\)\s+:\s+([-\d.]+).*?'
            r'Magnitude \(Debye\)\s+:\s+([-\d.]+)',
            content,
            re.DOTALL
        )

        if dipole_matches:
            # Take the last match
            x_au, y_au, z_au, mag_au, mag_debye = dipole_matches[-1]
            return {
                "x_au": float(x_au),
                "y_au": float(y_au),
                "z_au": float(z_au),
                "magnitude_au": float(mag_au),
                "magnitude_debye": float(mag_debye),
                "vector_debye": [float(x_au), float(y_au), float(z_au)]  # Actually in a.u. but kept for compatibility
            }
    except Exception as e:
        logger.error(f"Error parsing dipole moment from {output_file}: {e}")

    return None


def parse_orbitals(
    output_file: Path,
    *,
    inp_file: Optional[Path] = None,
    job_base: Optional[str] = None,
    job_number: Optional[int] = None,
) -> Optional[Dict[str, Any]]:
    """Parse HOMO/LUMO energies from ORCA output (uses last orbital block)."""
    if not output_file.exists():
        return None

    try:
        content, _ = _extract_orca_output_job_text(
            output_file,
            inp_file=inp_file,
            job_base=job_base,
            job_number=job_number,
        )
        if content is None:
            return None

        lines = content.splitlines(keepends=True)

        orbital_line_re = re.compile(
            r'^\s*(\d+)\s+([\d.]+)\s+([+\-]?\d*\.?\d+(?:[Ee][+\-]?\d+)?)\s+([+\-]?\d*\.?\d+(?:[Ee][+\-]?\d+)?)'
        )
        header_re = re.compile(r'^\s*NO\s+OCC\s+E\(Eh\)\s+E\(eV\)', re.IGNORECASE)

        blocks: list[list[Dict[str, Any]]] = []
        current_block: list[Dict[str, Any]] = []
        in_block = False
        current_spin: Optional[str] = None

        for line in lines:
            stripped = line.strip()

            if stripped.startswith("ORBITAL ENERGIES"):
                # Start new block
                in_block = True
                current_block = []
                current_spin = None
                continue

            if not in_block:
                continue

            # Track spin information if present (open-shell cases)
            upper_line = stripped.upper()
            if "SPIN UP" in upper_line:
                current_spin = "alpha"
                continue
            if "SPIN DOWN" in upper_line:
                current_spin = "beta"
                continue

            # Skip header/separator lines inside a block
            if header_re.match(line) or set(stripped) == {"-"} or stripped == "":
                continue

            match = orbital_line_re.match(line)
            if match:
                idx = int(match.group(1))
                occ = float(match.group(2))
                energy_eh = float(match.group(3))
                energy_ev = float(match.group(4))

                orbital_entry = {
                    "index": idx,
                    "occupancy": occ,
                    "energy_hartree": energy_eh,
                    "energy_eV": energy_ev
                }
                if current_spin:
                    orbital_entry["spin"] = current_spin

                current_block.append(orbital_entry)
                continue

            # End of current block detected
            if stripped.startswith("*Only") or stripped.startswith("MOLECULAR ORBITALS"):
                if current_block:
                    blocks.append(current_block)
                in_block = False
                current_block = []
                continue

            # Any other content ends the block once we have data
            if current_block:
                blocks.append(current_block)
            in_block = False
            current_block = []

        # Catch a trailing block if file ended right after data
        if in_block and current_block:
            blocks.append(current_block)

        if not blocks:
            return None

        orbital_list = blocks[-1]
        orbitals = []
        homo_energy = None
        lumo_energy = None
        homo_index = None
        somo_index = None
        spin_polarized = any("spin" in entry for entry in orbital_list)
        occupation_scheme = "RKS"

        for entry in orbital_list:
            orbitals.append(entry)
            occ = entry["occupancy"]
            energy_ev = entry["energy_eV"]
            idx = entry["index"]

            if occ > 1e-3:
                homo_energy = energy_ev
                homo_index = idx
                if occ <= 1.5:
                    somo_index = idx
            elif lumo_energy is None:
                lumo_energy = energy_ev
            if not spin_polarized and 0.25 < occ < 1.75:
                occupation_scheme = "UKS"

        if spin_polarized:
            occupation_scheme = "UKS"

        center_index = somo_index if (spin_polarized and somo_index is not None) else homo_index
        mo_window = []
        if center_index is not None:
            for rel in range(-5, 6):
                idx = center_index + rel
                if spin_polarized:
                    for spin in ("alpha", "beta"):
                        match = next(
                            (o for o in orbitals if o.get("index") == idx and o.get("spin") == spin),
                            None,
                        )
                        if match:
                            mo_window.append(
                                {
                                    "index": idx,
                                    "spin": spin,
                                    "occupancy": match.get("occupancy"),
                                    "energy_eV": match.get("energy_eV"),
                                }
                            )
                else:
                    match = next((o for o in orbitals if o.get("index") == idx), None)
                    if match:
                        label = None
                        if homo_index is not None:
                            offset = idx - homo_index
                            if offset == 0:
                                label = "HOMO"
                            elif offset < 0:
                                label = f"HOMO{offset}"
                            elif offset == 1:
                                label = "LUMO"
                            else:
                                label = f"LUMO+{offset-1}"
                        mo_window.append(
                            {
                                "index": idx,
                                "spin": None,
                                "label": label,
                                "occupancy": match.get("occupancy"),
                                "energy_eV": match.get("energy_eV"),
                            }
                        )

        if homo_energy is not None and lumo_energy is not None:
            return {
                "homo_eV": homo_energy,
                "lumo_eV": lumo_energy,
                "gap_eV": lumo_energy - homo_energy,
                "orbital_list": orbitals,
                "spin_polarized": spin_polarized,
                "occupation_scheme": occupation_scheme,
                "homo_index": homo_index,
                "somo_index": somo_index,
                "mo_window": mo_window,
            }

    except Exception as e:
        logger.error(f"Error parsing orbitals from {output_file}: {e}")

    return None


def parse_properties_of_interest_jobs(
    output_file: Path,
    inp_file: Path,
    *,
    reference_energy_hartree: Optional[float] = None,
) -> Dict[str, Any]:
    """Parse IP/EA jobs appended to an ORCA input/output via ``$new_job``."""
    if not output_file.exists() or not inp_file.exists():
        return {}

    properties: Dict[str, Any] = {}
    for job_number, base_name in sorted(_parse_orca_input_job_bases(inp_file).items()):
        base_upper = base_name.upper()
        if base_upper.endswith("_IP"):
            prop_name = "IP"
        elif base_upper.endswith("_EA"):
            prop_name = "EA"
        else:
            continue

        entry: Dict[str, Any] = {
            "job_number": job_number,
            "base_name": base_name,
            "source_output_file": output_file.name,
            "source_input_file": inp_file.name,
        }

        cm_data = parse_charge_multiplicity(inp_file, job_number=job_number)
        if cm_data:
            entry["charge_multiplicity"] = cm_data

        scf_data = parse_scf_energy(output_file, job_number=job_number)
        if scf_data:
            entry["scf_energy"] = scf_data

        dipole = parse_dipole_moment(output_file, job_number=job_number)
        if dipole:
            entry["dipole_moment"] = dipole

        orbitals = parse_orbitals(output_file, job_number=job_number)
        if orbitals:
            entry["orbitals"] = orbitals

        if reference_energy_hartree is not None and scf_data:
            if prop_name == "IP":
                delta = scf_data["hartree"] - reference_energy_hartree
                properties["IP_hartree"] = delta
                properties["IP_eV"] = delta * HARTREE_TO_EV
                entry["vertical_ionization_potential"] = {
                    "hartree": delta,
                    "eV": delta * HARTREE_TO_EV,
                    "kJ_mol": delta * HARTREE_TO_KJ_MOL,
                }
            else:
                delta = reference_energy_hartree - scf_data["hartree"]
                properties["EA_hartree"] = delta
                properties["EA_eV"] = delta * HARTREE_TO_EV
                entry["vertical_electron_affinity"] = {
                    "hartree": delta,
                    "eV": delta * HARTREE_TO_EV,
                    "kJ_mol": delta * HARTREE_TO_KJ_MOL,
                }

        properties[prop_name] = entry

    return properties


def parse_reorganisation_energy_jobs(
    output_file: Path,
    inp_file: Path,
    *,
    neutral_reference_energy_hartree: Optional[float] = None,
    neutral_reference_output_file: Optional[str] = None,
    neutral_reference_input_file: Optional[str] = None,
) -> Dict[str, Any]:
    """Parse lambda_p/lambda_m jobs appended to red_step_1/ox_step_1 inputs."""
    if not output_file.exists() or not inp_file.exists():
        return {}

    modes = {
        "E_N_CATION": ("lambda_p", "cation"),
        "E_N_ANION": ("lambda_m", "anion"),
    }

    reorganisation: Dict[str, Any] = {}
    for job_number, base_name in sorted(_parse_orca_input_job_bases(inp_file).items()):
        mode_info = modes.get(base_name.upper())
        if mode_info is None:
            continue

        lambda_key, charged_label = mode_info
        charged_at_neutral = parse_first_scf_energy(output_file, job_number=1)
        charged_optimized = parse_scf_energy(output_file, job_number=1)
        neutral_at_charged = parse_scf_energy(output_file, job_number=job_number)

        entry: Dict[str, Any] = {
            "job_number": job_number,
            "base_name": base_name,
            "source_output_file": output_file.name,
            "source_input_file": inp_file.name,
            "charged_geometry_file": f"{inp_file.stem}.xyz",
        }

        cm_data = parse_charge_multiplicity(inp_file, job_number=job_number)
        if cm_data:
            entry["charge_multiplicity"] = cm_data

        if neutral_reference_output_file:
            entry["neutral_reference_output_file"] = neutral_reference_output_file
        if neutral_reference_input_file:
            entry["neutral_reference_input_file"] = neutral_reference_input_file

        if charged_at_neutral:
            entry[f"{charged_label}_at_neutral_geometry"] = charged_at_neutral
        if charged_optimized:
            entry[f"{charged_label}_optimized"] = charged_optimized
        if neutral_at_charged:
            entry[f"neutral_at_{charged_label}_geometry"] = neutral_at_charged
        if neutral_reference_energy_hartree is not None:
            entry["neutral_optimized"] = _energy_payload(neutral_reference_energy_hartree)

        charged_term = None
        if charged_at_neutral and charged_optimized:
            charged_term = charged_at_neutral["hartree"] - charged_optimized["hartree"]
            entry["charged_relaxation_term"] = _energy_payload(charged_term)

        neutral_term = None
        if neutral_at_charged and neutral_reference_energy_hartree is not None:
            neutral_term = neutral_at_charged["hartree"] - neutral_reference_energy_hartree
            entry["neutral_relaxation_term"] = _energy_payload(neutral_term)

        if charged_term is not None and neutral_term is not None:
            total = charged_term + neutral_term
            reorganisation[f"{lambda_key}_hartree"] = total
            reorganisation[f"{lambda_key}_eV"] = total * HARTREE_TO_EV
            entry["total"] = _energy_payload(total)

        reorganisation[lambda_key] = entry

    return reorganisation


def parse_occupier_folder(folder: Path) -> Optional[Dict[str, Any]]:
    """Parse a single OCCUPIER folder (multiplicity scans etc.)."""
    txt = folder / "OCCUPIER.txt"
    if not txt.exists():
        return None

    try:
        with open(txt, "r", encoding="utf-8", errors="ignore") as f:
            lines = f.readlines()

        data: Dict[str, Any] = {
            "source_folder": folder.name,
            "method": None,
            "charge": None,
            "preferred_index": None,
            "electron_number": None,
            "lowest_energy_hartree": None,
            "entries": []
        }

        method_match = next((re.search(r"^Method:\s*(.+)", ln) for ln in lines if ln.strip().startswith("Method:")), None)
        if method_match:
            data["method"] = method_match.group(1).strip()

        for ln in lines:
            if "Charge:" in ln:
                m = re.search(r"Charge:\s*([-]?\d+)", ln)
                if m:
                    data["charge"] = int(m.group(1))
            if "Electron number" in ln:
                m = re.search(r"Electron number:\s*([^\s)]+)", ln)
                if m:
                    data["electron_number"] = m.group(1).rstrip(')')
            if "Preferred Index" in ln:
                m = re.search(r"Preferred Index:\s*(\d+)", ln)
                if m:
                    data["preferred_index"] = int(m.group(1))
            if "LOWEST FINAL SINGLE POINT ENERGY" in ln:
                m = re.search(r'LOWEST FINAL SINGLE POINT ENERGY:\s*([-\d.]+)', ln)
                if m:
                    data["lowest_energy_hartree"] = float(m.group(1))

        block: Dict[str, Any] = {}
        for ln in lines:
            energy_match = re.search(r"FINAL SINGLE POINT ENERGY \((\d+)\)\s*=\s*([-\d.]+)\s*\(H\)(.*)", ln)
            if energy_match:
                if block:
                    data["entries"].append(block)
                    block = {}
                idx = int(energy_match.group(1))
                energy = float(energy_match.group(2))
                tail = energy_match.group(3) or ""
                block = {
                    "index": idx,
                    "energy_hartree": energy,
                    "preferred": "<--" in tail,
                }
                continue

            mult_match = re.search(r"multiplicity\s+(\d+)", ln, re.IGNORECASE)
            if mult_match and block:
                block["multiplicity"] = int(mult_match.group(1))
                bs_match = re.search(r"BrokenSym\s+([-\d\s,]+)", ln, re.IGNORECASE)
                if bs_match:
                    bs_raw = bs_match.group(1).strip().replace(" ", "")
                    block["BS"] = bs_raw
                continue

            spin_match = re.search(r"Spin Contamination.*?:\s*([-\d.]+|N/A)", ln, re.IGNORECASE)
            if spin_match and block:
                val = spin_match.group(1)
                block["spin_contamination"] = None if val.upper() == "N/A" else float(val)
                continue

            unpaired_match = re.search(r"Unpaired e.*?:\s*([-\d]+)\s*\|\s*([-\d]+)", ln)
            if unpaired_match and block:
                block["unpaired_alpha"] = int(unpaired_match.group(1))
                block["unpaired_beta"] = int(unpaired_match.group(2))
                continue

        if block:
            data["entries"].append(block)

        if data["entries"] and data["preferred_index"] is None:
            # Fallback: mark first preferred flag
            for entry in data["entries"]:
                if entry.get("preferred"):
                    data["preferred_index"] = entry["index"]
                    break

        return data
    except Exception as e:
        logger.error(f"Error parsing OCCUPIER folder {folder}: {e}")
        return None


def _calculate_total_isc_rate(ms_components: Dict[str, Dict[str, Any]]) -> float:
    """Calculate total ISC rate from Ms components with symmetry approximation.

    - 3 components (Ms=-1,0,+1): sum all three
    - 2 components (Ms=0,±1): rate(Ms=0) + 2×rate(Ms=±1)
    - 1 component (Ms=0 only): 3×rate(Ms=0)

    Args:
        ms_components: Dictionary of Ms component data (ms_0, ms_p1, ms_m1)

    Returns:
        Total ISC rate (s^-1)
    """
    # Get rates for each Ms component
    rate_ms0 = ms_components.get("ms_0", {}).get("rate_s1") or 0
    rate_msp1 = ms_components.get("ms_p1", {}).get("rate_s1") or 0
    rate_msm1 = ms_components.get("ms_m1", {}).get("rate_s1") or 0

    # Check which components are present
    has_ms0 = "ms_0" in ms_components
    has_msp1 = "ms_p1" in ms_components
    has_msm1 = "ms_m1" in ms_components
    num_components = sum([has_ms0, has_msp1, has_msm1])

    if num_components == 1:
        # Only 1 component: use 3× that value (approximates all 3 Ms components)
        if has_ms0:
            return 3 * rate_ms0
        elif has_msp1:
            return 3 * rate_msp1
        else:  # has_msm1
            return 3 * rate_msm1
    elif num_components == 2:
        # 2 components: use symmetry approximation
        if has_msp1 and not has_msm1:
            # Missing Ms=-1, use 2× Ms=+1
            return rate_ms0 + 2 * rate_msp1
        elif has_msm1 and not has_msp1:
            # Missing Ms=+1, use 2× Ms=-1
            return rate_ms0 + 2 * rate_msm1
        else:
            # Has both Ms=±1 but no Ms=0 (unusual), just sum
            return rate_ms0 + rate_msp1 + rate_msm1
    else:
        # All 3 present: simple sum
        return rate_ms0 + rate_msp1 + rate_msm1


def parse_isc_data(esd_dir: Path, state1: str, state2: str) -> Optional[Dict[str, Any]]:
    """Parse ISC data from ISC output files."""
    isc_data = {"ms_components": {}}

    # Parse all ms components
    for ms in ["ms0", "msp1", "msm1"]:
        isc_file = esd_dir / f"{state1}_{state2}_ISC_{ms}.out"
        if not isc_file.exists():
            continue

        try:
            with open(isc_file, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()

            # Extract SOC (complex), rate, and FC/HT percentages
            soc_match = re.search(
                r'Reference SOC \(Re and Im\):\s*([-\d.eE+]+),\s*([-\d.eE+]+)',
                content
            )
            rate_match = re.search(
                r'(?:k_ISC|ISC rate constant is)\s*=?\s*([\d.eE+-]+)\s*s-?1',
                content
            )
            fc_ht_match = re.search(
                r'with\s+([\d.]+)\s+from\s+FC\s+and\s+([\d.]+)\s+from\s+HT',
                content,
                re.IGNORECASE
            )
            delta_match = re.search(
                r'0-0 energy difference:\s*([-\d.]+)\s*cm-1',
                content
            )
            temp_match = re.search(r'Temperature used:\s*([-\d.]+)\s*K', content)

            ms_key = ms.replace("ms", "ms_")
            soc_re = float(soc_match.group(1)) if soc_match else None
            soc_im = float(soc_match.group(2)) if soc_match else None
            soc_abs = None
            if soc_re is not None and soc_im is not None:
                soc_abs = (soc_re ** 2 + soc_im ** 2) ** 0.5
            isc_data["ms_components"][ms_key] = {
                "soc_re_cm1": soc_re,
                "soc_im_cm1": soc_im,
                "soc_abs_cm1": soc_abs,
                "rate_s1": float(rate_match.group(1)) if rate_match else None,
                "delta_E_cm1": float(delta_match.group(1)) if delta_match else None,
                "temperature_K": float(temp_match.group(1)) if temp_match else None,
                "fc_percent": float(fc_ht_match.group(1)) if fc_ht_match else None,
                "ht_percent": float(fc_ht_match.group(2)) if fc_ht_match else None,
                "source_file": isc_file.name
            }

        except Exception as e:
            logger.error(f"Error parsing ISC file {isc_file}: {e}")

    # Calculate total rate
    if isc_data["ms_components"]:
        isc_data["total_rate_s1"] = _calculate_total_isc_rate(isc_data["ms_components"])
        return isc_data

    return None


def parse_ic_data(esd_dir: Path, state1: str, state2: str) -> Optional[Dict[str, Any]]:
    """Parse IC data from IC output files."""
    ic_file = esd_dir / f"{state1}_{state2}_IC.out"

    if not ic_file.exists():
        return None

    try:
        with open(ic_file, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()

        # Extract IC rate
        rate_match = re.search(
            r'(?:k_IC|internal conversion rate constant is)\s*=?\s*([\d.eE+-]+)\s*s-?1',
            content
        )
        delta_e_match = re.search(r'0-0 energy difference:\s*([-\d.]+)\s*cm-1', content)
        temp_match = re.search(r'Temperature used:\s*([-\d.]+)\s*K', content)

        return {
            "rate_s1": float(rate_match.group(1)) if rate_match else None,
            "delta_E_cm1": float(delta_e_match.group(1)) if delta_e_match else None,
            "temperature_K": float(temp_match.group(1)) if temp_match else None,
            "source_file": ic_file.name
        }

    except Exception as e:
        logger.error(f"Error parsing IC file {ic_file}: {e}")

    return None


def parse_fluor_data(esd_dir: Path, state1: str = "S1", state2: str = "S0") -> Optional[Dict[str, Any]]:
    """Parse fluorescence rate data from ESD(FLUOR) output."""
    fluor_file = esd_dir / f"{state1}_{state2}_FLUOR.out"
    if not fluor_file.exists():
        return None
    try:
        with fluor_file.open("r", encoding="utf-8", errors="ignore") as f:
            content = f.read()

        rate_match = re.search(
            r'(?:k[_\s-]*f|k[_\s-]*fluor|fluorescence\s+rate\s+constant\s+(?:is)?|calculated\s+fluorescence\s+rate\s+constant\s+is)\s*=?\s*([\d.eE+-]+)\s*s-?1',
            content,
            flags=re.IGNORECASE,
        )
        temp_match = re.search(r'Temperature used:\s*([-\d.]+)\s*K', content)
        delta_e_match = re.search(r'0-0 energy difference:\s*([-\d.]+)\s*cm-1', content)

        return {
            "rate_s1": float(rate_match.group(1)) if rate_match else None,
            "temperature_K": float(temp_match.group(1)) if temp_match else None,
            "delta_E_cm1": float(delta_e_match.group(1)) if delta_e_match else None,
            "source_file": fluor_file.name,
        }
    except Exception as e:
        logger.error(f"Error parsing FLUOR file {fluor_file}: {e}")
        return None


def parse_phosp_data(esd_dir: Path, state1: str = "T1", state2: str = "S0") -> Optional[Dict[str, Any]]:
    """Parse phosphorescence rates from ESD(PHOSP) output.

    The PHOSP workflow may run multiple IROOT subjobs in a single output via $new_job.
    We parse all phosphorescence rate constants and return k1/k2/k3 plus arithmetic mean.
    """
    phosp_file = esd_dir / f"{state1}_{state2}_PHOSP.out"
    if not phosp_file.exists():
        return None
    try:
        with phosp_file.open("r", encoding="utf-8", errors="ignore") as f:
            content = f.read()

        # Determine expected IROOTs from the corresponding input (if present)
        expected_iroots: list[str] = []
        inp_file = esd_dir / f"{state1}_{state2}_PHOSP.inp"
        if inp_file.exists():
            try:
                inp_text = inp_file.read_text(encoding="utf-8", errors="ignore")
                expected_iroots = re.findall(r"^\s*IROOT\s+(\d+)\s*$", inp_text, flags=re.IGNORECASE | re.MULTILINE)
            except Exception:
                expected_iroots = []

        # Collect all occurrences (often one per subjob / IROOT)
        matches = re.findall(
            r'(?:k[_\s-]*p|k[_\s-]*phosp|phosphorescence\s+rate\s+constant\s+(?:is)?|calculated\s+phosphorescence\s+rate\s+constant\s+is)\s*=?\s*([\d.eE+-]+)\s*s-?1',
            content,
            flags=re.IGNORECASE,
        )
        rates = [float(x) for x in matches] if matches else []

        temp_match = re.search(r'Temperature used:\s*([-\d.]+)\s*K', content)
        delta_e_match = re.search(r'0-0 energy difference:\s*([-\d.]+)\s*cm-1', content)

        # Map in order of appearance onto expected IROOTs if we know them,
        # otherwise default to 1..N.
        if expected_iroots:
            iroot_rates = {iroot: None for iroot in expected_iroots}
            for idx, rate in enumerate(rates):
                if idx >= len(expected_iroots):
                    break
                iroot_rates[expected_iroots[idx]] = rate
        else:
            iroot_rates = {str(i + 1): rates[i] for i in range(len(rates))}
        mean_rate = sum(rates) / len(rates) if rates else None

        return {
            "iroot_rates_s1": iroot_rates,
            "rate_mean_s1": mean_rate,
            "temperature_K": float(temp_match.group(1)) if temp_match else None,
            "delta_E_cm1": float(delta_e_match.group(1)) if delta_e_match else None,
            "source_file": phosp_file.name,
        }
    except Exception as e:
        logger.error(f"Error parsing PHOSP file {phosp_file}: {e}")
        return None


def parse_esd_summary(project_dir: Path) -> Dict[str, Any]:
    """Parse summary data from ESD.txt if present (rates, SOC, FC/HT)."""
    esd_txt = project_dir / "ESD.txt"
    if not esd_txt.exists():
        return {}

    summary_data: Dict[str, Any] = {"isc": {}, "ic": {}}

    try:
        with open(esd_txt, 'r', encoding='utf-8', errors='ignore') as f:
            lines = f.readlines()

        for line in lines:
            ms_match = re.match(r'^\s*([ST]\d)>([ST]\d)\(Ms=([+\-]?\d)\):\s*([-\deE+.]+)', line)
            if ms_match:
                s1, s2, ms_val, rate = ms_match.groups()
                temp = re.search(r'T=([-\d.]+)\s*K', line)
                delta = re.search(r'0-0=([-\d.]+)', line)
                soc = re.search(r'SOC=([^\s,]+)\+i([^\s,]+)', line)
                fc_ht = re.search(r'FC=([-\d.]+)%,\s*HT=([-\d.]+)%', line)
                key = f"{s1}_{s2}"
                ms_key = {"0": "ms_0", "+1": "ms_p1", "-1": "ms_m1"}.get(ms_val, f"ms_{ms_val}")
                entry = summary_data["isc"].setdefault(key, {"ms_components": {}})
                soc_re_f = float(soc.group(1)) if soc else None
                soc_im_f = float(soc.group(2)) if soc else None
                soc_abs = None
                if soc_re_f is not None and soc_im_f is not None:
                    soc_abs = (soc_re_f ** 2 + soc_im_f ** 2) ** 0.5
                entry["ms_components"][ms_key] = {
                    "soc_re_cm1": soc_re_f,
                    "soc_im_cm1": soc_im_f,
                    "soc_abs_cm1": soc_abs,
                    "rate_s1": float(rate),
                    "delta_E_cm1": float(delta.group(1)) if delta else None,
                    "temperature_K": float(temp.group(1)) if temp else None,
                    "fc_percent": float(fc_ht.group(1)) if fc_ht else None,
                    "ht_percent": float(fc_ht.group(2)) if fc_ht else None,
                    "source_file": "ESD.txt"
                }
                continue

            total_match = re.match(r'^\s*([ST]\d)>([ST]\d)\s*\(total\):\s*([-\deE+.]+)\s*s\^-?1', line)
            if total_match:
                s1, s2, rate = total_match.groups()
                key = f"{s1}_{s2}"
                entry = summary_data["isc"].setdefault(key, {"ms_components": {}})
                entry["total_rate_s1"] = float(rate)
                entry["source_file"] = "ESD.txt"
                continue

            ic_match = re.match(
                r'^\s*([ST]\d)>([ST]\d):\s*([-\deE+.]+)\s*s\^-?1\s*\(T=([-\d.]+)\s*K,\s*.*?0-0=([-\d.]+)',
                line
            )
            if ic_match:
                s1, s2, rate, temp, delta = ic_match.groups()
                key = f"{s1}_{s2}"
                summary_data["ic"][key] = {
                    "rate_s1": float(rate),
                    "temperature_K": float(temp),
                    "delta_E_cm1": float(delta),
                    "source_file": "ESD.txt"
                }

    except Exception as e:
        logger.error(f"Error parsing ESD.txt summary: {e}")

    return summary_data


def collect_esd_data(project_dir: Path) -> Dict[str, Any]:
    """
    Collect all ESD calculation data from a project directory.

    Args:
        project_dir: Path to project directory containing initial.inp, ESD/, OCCUPIER/, etc.

    Returns:
        Complete data structure as dictionary (ready for JSON)
    """
    from delfin.esd_input_generator import _resolve_state_filename

    logger.info(f"Collecting ESD data from {project_dir}")

    esd_dir = project_dir / "ESD"
    occupier_dir = project_dir / "OCCUPIER"
    summary_data = parse_esd_summary(project_dir)
    control_flags = parse_control_flags(project_dir)
    control_config = parse_control_config(project_dir)

    # Read ESD_modus from CONTROL.txt to determine correct filenames for hybrid1 mode
    esd_mode = 'tddft'  # default
    control_path = project_dir / "CONTROL.txt"
    if control_path.exists():
        try:
            content = control_path.read_text(encoding="utf-8", errors="ignore")
            mode_match = re.search(r'^\s*ESD_modus\s*=\s*(.+)', content, flags=re.IGNORECASE | re.MULTILINE)
            if mode_match:
                esd_mode = mode_match.group(1).strip().lower()
                if "|" in esd_mode:
                    esd_mode = esd_mode.split("|")[0].strip()
        except Exception as exc:  # noqa: BLE001
            logger.warning("Failed to parse ESD_modus from CONTROL.txt: %s", exc)

    # Parse DELFIN.txt for redox potentials and summary info
    delfin_summary = parse_delfin_txt(project_dir)

    # Get git commit info for reproducibility tracking
    git_commit = get_git_commit_info()

    # Use validated config if available for computed values
    validated_config = control_config.get("validated", {}) if control_config else {}
    data = {
        "git_commit": git_commit,
        "metadata": parse_initial_inp(project_dir),
        "input": {},
        "ground_state_S0": {},
        "excited_states": {},
        "oxidized_state": {},
        "oxidized_states": {},
        "reduced_state": {},
        "reduced_states": {},
        "vibrational_frequencies": {},
        "emission": {},
        "intersystem_crossing": {},
        "internal_conversion": {},
        "fluorescence_rates": {},
        "phosphorescence_rates": {},
        "properties_of_interest": {},
        "reorganisation_energy": {},
        "occupier": {},
        "photophysical_rates": {},
        "delfin_summary": delfin_summary,
        "control_flags": control_flags,
        "control": control_config,
        "computed": {},
        "esd_results": {},
    }

    goat_conformer_count = parse_goat_conformer_count(project_dir)
    if goat_conformer_count is not None:
        data["metadata"]["goat_conformer_count"] = goat_conformer_count

    data["input"] = parse_input_data(project_dir, control_config)

    ir_data = parse_ir_spectrum_data(project_dir)
    if ir_data:
        data["vibrational_frequencies"] = ir_data

    neutral_reference_energy_hartree: Optional[float] = None
    neutral_reference_output_file: Optional[str] = None
    neutral_reference_input_file: Optional[str] = None

    # Parse S0 (fallback to initial.out if S0.out is missing)
    s0_candidates = [
        esd_dir / "S0.out",
        project_dir / "S0.out",
        project_dir / "initial.out",
        esd_dir / "initial.out",
    ]
    s0_out = next((path for path in s0_candidates if path.exists()), None)
    if s0_out:
        logger.info("Parsing S0 ground state from %s", s0_out.name)
        if s0_out.name.startswith("initial"):
            geometry_file = "initial.xyz"
            s0_inp = project_dir / "initial.inp"
        else:
            geometry_file = "S0.xyz"
            s0_inp = s0_out.parent / "S0.inp"

        data["ground_state_S0"]["optimization"] = {
            "converged": True,
            "geometry_file": geometry_file,
        }

        cm_data = parse_charge_multiplicity(s0_inp, job_number=1)
        if cm_data:
            data["ground_state_S0"]["optimization"].update(cm_data)

        scf_data = parse_scf_energy(s0_out, job_number=1)
        if scf_data:
            data["ground_state_S0"]["optimization"].update(scf_data)
            neutral_reference_energy_hartree = scf_data.get("hartree")
            neutral_reference_output_file = s0_out.name
            neutral_reference_input_file = s0_inp.name

        data["ground_state_S0"]["thermochemistry"] = parse_thermochemistry(s0_out, job_number=1)
        data["ground_state_S0"]["orbitals"] = parse_orbitals(s0_out, job_number=1)
        data["ground_state_S0"]["dipole_moment"] = parse_dipole_moment(s0_out, job_number=1)

        properties = parse_properties_of_interest_jobs(
            s0_out,
            s0_inp,
            reference_energy_hartree=scf_data.get("hartree") if scf_data else None,
        )
        if properties:
            data["properties_of_interest"]["S0"] = properties

        # Parse polarizability if available
        from delfin.parser import parse_polarizability
        s0_job_text, _ = _extract_orca_output_job_text(s0_out, job_number=1)
        polarizability = None
        if s0_job_text is not None:
            polarizability = parse_polarizability(io.StringIO(s0_job_text))
        if polarizability:
            data["ground_state_S0"]["polarizability"] = polarizability

        # Parse hyperpolarizability if available
        from delfin.parser import parse_hyperpolarizability, calculate_beta_properties
        beta_tensor = None
        if s0_job_text is not None:
            beta_tensor = parse_hyperpolarizability(io.StringIO(s0_job_text))
        if beta_tensor:
            dipole = data["ground_state_S0"]["dipole_moment"] or {}
            dipole_x = dipole.get("x_au", 0.0)
            dipole_y = dipole.get("y_au", 0.0)
            dipole_z = dipole.get("z_au", 0.0)
            beta_props = calculate_beta_properties(beta_tensor, dipole_x, dipole_y, dipole_z)
            data["ground_state_S0"]["hyperpolarizability"] = {
                "tensor_au": beta_tensor,
                **beta_props
            }

        # Parse absorption spectrum from S0
        # Try S0_TDDFT.out first, fall back to S0.out if it doesn't exist
        s0_tddft = esd_dir / "S0_TDDFT.out"
        if not s0_tddft.exists():
            s0_tddft = s0_out if s0_out.exists() else None

        if s0_tddft and s0_tddft.exists():
            transitions = parse_absorption_spectrum(s0_tddft)
            data["ground_state_S0"]["tddft_absorption"] = {
                "comment": f"Parsed from {s0_tddft.name}",
                "transitions": [
                    {
                        "from_state": t.from_state,
                        "to_state": t.to_state,
                        "energy_eV": t.energy_ev,
                        "wavelength_nm": t.wavelength_nm,
                        "oscillator_strength": t.fosc,
                        "excitations": t.excitations if t.excitations else [],
                        "homo_number": t.homo_number
                    }
                    for t in transitions
                ]
            }

    # Parse oxidized and reduced states
    def parse_charged_series(prefix: str, target_states: Dict[str, Any], legacy_key: str):
        # Parse up to three steps (1, 2, 3) if they exist
        for step in [1, 2, 3]:
            base = f"{prefix}_step_{step}"
            out_file = project_dir / f"{base}.out"
            if not out_file.exists():
                continue

            logger.info(f"Parsing {prefix} state step {step}")
            inp_file = project_dir / f"{base}.inp"
            entry = {
                "optimization": {
                    "converged": True,
                    "geometry_file": f"{base}.xyz"
                },
                "thermochemistry": parse_thermochemistry(out_file, job_number=1),
                "orbitals": parse_orbitals(out_file, job_number=1),
                "dipole_moment": parse_dipole_moment(out_file, job_number=1)
            }

            cm_data = parse_charge_multiplicity(inp_file, job_number=1)
            if cm_data:
                entry["optimization"].update(cm_data)

            scf_data = parse_scf_energy(out_file, job_number=1)
            if scf_data:
                entry["optimization"].update(scf_data)

            target_states[base] = entry

            properties = parse_properties_of_interest_jobs(
                out_file,
                inp_file,
                reference_energy_hartree=scf_data.get("hartree") if scf_data else None,
            )
            if properties:
                data["properties_of_interest"][base] = properties

        # Legacy single-key exposure for step 1
        step1_key = f"{prefix}_step_1"
        if step1_key in target_states:
            data[legacy_key] = target_states[step1_key]

    parse_charged_series("ox", data["oxidized_states"], "oxidized_state")
    parse_charged_series("red", data["reduced_states"], "reduced_state")

    for step1_base in ("ox_step_1", "red_step_1"):
        out_file = project_dir / f"{step1_base}.out"
        inp_file = project_dir / f"{step1_base}.inp"
        reorganisation = parse_reorganisation_energy_jobs(
            out_file,
            inp_file,
            neutral_reference_energy_hartree=neutral_reference_energy_hartree,
            neutral_reference_output_file=neutral_reference_output_file,
            neutral_reference_input_file=neutral_reference_input_file,
        )
        if reorganisation:
            data["reorganisation_energy"].update(reorganisation)

    # Compute redox potentials from Gibbs energies (if possible)
    gibbs_energies = collect_gibbs_energies(project_dir)
    if any(val is not None for val in gibbs_energies.values()):
        E_ref = get_E_ref(validated_config) if validated_config else None
        if E_ref is not None:
            m1_avg, m2_step, m3_mix, use_flags = calculate_redox_potentials(
                validated_config,
                gibbs_energies,
                E_ref,
            )
            E_ox, E_ox_2, E_ox_3, E_red, E_red_2, E_red_3 = select_final_potentials(
                m1_avg,
                m2_step,
                m3_mix,
                use_flags,
            )
            data["computed"]["redox_potentials"] = {
                "gibbs_energies_hartree": gibbs_energies,
                "E_ref": E_ref,
                "method_flags": use_flags,
                "m1_avg": m1_avg,
                "m2_step": m2_step,
                "m3_mix": m3_mix,
                "final": {
                    "E_ox": E_ox,
                    "E_ox_2": E_ox_2,
                    "E_ox_3": E_ox_3,
                    "E_red": E_red,
                    "E_red_2": E_red_2,
                    "E_red_3": E_red_3,
                },
            }

    # Parse excited states (S1-S6, T1-T6)
    for state in ["S1", "S2", "S3", "S4", "S5", "S6", "T1", "T2", "T3", "T4", "T5", "T6"]:
        # Resolve filename for hybrid1 mode: S1_second.out, T2_second.out, etc.
        state_out_filename = _resolve_state_filename(state, 'out', esd_mode)
        state_out = esd_dir / state_out_filename
        if not state_out.exists():
            continue

        logger.info(f"Parsing excited state {state} (from {state_out_filename})")

        # Geometry file also uses _second_deltaSCF suffix in hybrid1
        state_xyz_filename = _resolve_state_filename(state, 'xyz', esd_mode)

        state_data = {
            "optimization": {
                "converged": True,
                "geometry_file": state_xyz_filename
            },
            "thermochemistry": parse_thermochemistry(state_out),
            "dipole_moment": parse_dipole_moment(state_out),
            "orbitals": parse_orbitals(state_out)
        }

        # Parse charge and multiplicity from input file
        state_inp = esd_dir / f"{state}.inp"
        cm_data = parse_charge_multiplicity(state_inp)
        if cm_data:
            state_data["optimization"].update(cm_data)

        # Parse TDDFT keywords from the corresponding input, if available
        tddft_inp = esd_dir / f"{state}_TDDFT.inp"
        tddft_settings = parse_tddft_settings(tddft_inp if tddft_inp.exists() else state_inp)
        if tddft_settings:
            state_data["tddft_settings"] = tddft_settings

        scf_data = parse_scf_energy(state_out)
        if scf_data:
            state_data["optimization"].update(scf_data)

        # Parse emission spectrum (transitions FROM this state)
        # For hybrid1 mode: TDDFT excitations come from first_TDDFT (step 1)
        # For deltaSCF mode: TDDFT excitations come from separate _TDDFT job
        # Priority: first_TDDFT.out > _TDDFT.out > state.out
        tddft_first_out = esd_dir / f"{state}_first_TDDFT.out"
        tddft_out = esd_dir / f"{state}_TDDFT.out"
        if tddft_first_out.exists():
            tddft_source = tddft_first_out
        elif tddft_out.exists():
            tddft_source = tddft_out
        else:
            tddft_source = state_out
        transitions = parse_absorption_spectrum(tddft_source)
        if transitions:
            state_data["tddft_from_geometry"] = {
                "comment": f"Vertical transitions FROM {state} geometry (parsed from {tddft_source.name})",
                "transitions": [
                    {
                        "from_state": t.from_state,
                        "to_state": t.to_state,
                        "energy_eV": t.energy_ev,
                        "wavelength_nm": t.wavelength_nm,
                        "oscillator_strength": t.fosc,
                        "excitations": t.excitations if t.excitations else [],
                        "homo_number": t.homo_number
                    }
                    for t in transitions
                ]
            }

        data["excited_states"][state] = state_data

    # Parse OCCUPIER data for all *_OCCUPIER folders
    occupier_results: Dict[str, Any] = {}
    for folder in sorted(project_dir.glob("*_OCCUPIER")):
        parsed = parse_occupier_folder(folder)
        if parsed:
            key = folder.name.replace("_OCCUPIER", "")
            # try to attach orbitals from the matching parent out (if exists)
            parent_out = project_dir / f"{key}.out"
            parsed["orbitals"] = parse_orbitals_from_occuper(parent_out)
            occupier_results[key] = parsed
    if occupier_results:
        data["occupier"] = occupier_results

    # Collect ESD summary data from ESD outputs
    try:
        from delfin.esd_results import collect_esd_results
        from delfin.esd_module import parse_esd_config

        esd_enabled, esd_states, esd_iscs, esd_ics = parse_esd_config(validated_config)
        if esd_enabled:
            esd_summary = collect_esd_results(esd_dir, esd_states, esd_iscs, esd_ics, config=validated_config)
            data["esd_results"] = serialize_esd_summary(esd_summary)

            # Compute E_00 values if possible
            states = esd_summary.states
            s0_data = states.get("S0")
            if s0_data and s0_data.fspe is not None and s0_data.zpe is not None:
                e00: Dict[str, float] = {}
                for key in ["S1", "S2", "T1", "T2"]:
                    state_data = states.get(key)
                    if state_data and state_data.fspe is not None and state_data.zpe is not None:
                        val = ((state_data.fspe - s0_data.fspe) + (state_data.zpe - s0_data.zpe)) * HARTREE_TO_EV
                        e00[key] = val
                if e00:
                    data["computed"]["E_00_eV"] = e00

            redox = data["computed"].get("redox_potentials", {}).get("final", {})
            if redox and data["computed"].get("E_00_eV"):
                e00 = data["computed"]["E_00_eV"]
                e_red = redox.get("E_red")
                e_ox = redox.get("E_ox")
                derived = {}
                if e_red is not None and e00.get("S1") is not None:
                    derived["E_red_star_S1"] = e_red + e00["S1"]
                if e_red is not None and e00.get("T1") is not None:
                    derived["E_red_star_T1"] = e_red + e00["T1"]
                if e_ox is not None and e00.get("S1") is not None:
                    derived["E_ox_star_S1"] = e_ox - e00["S1"]
                if e_ox is not None and e00.get("T1") is not None:
                    derived["E_ox_star_T1"] = e_ox - e00["T1"]
                if derived:
                    data["computed"]["redox_excited_state"] = derived
    except Exception as exc:  # noqa: BLE001
        logger.warning("Failed to collect ESD summary data: %s", exc)

    # Parse ISC data
    isc_pairs = [("S1", "T1"), ("S1", "T2"), ("S2", "T1")]
    for state1, state2 in isc_pairs:
        isc_data = parse_isc_data(esd_dir, state1, state2)
        key = f"{state1}_{state2}"
        summary_isc = summary_data.get("isc", {}).get(key)
        if summary_isc:
            # Ensure total rate present
            if "total_rate_s1" not in summary_isc and summary_isc.get("ms_components"):
                summary_isc["total_rate_s1"] = _calculate_total_isc_rate(summary_isc["ms_components"])
            data["intersystem_crossing"][key] = summary_isc
        elif isc_data:
            data["intersystem_crossing"][key] = isc_data

    # Add any additional ISC entries from ESD.txt not covered above
    for key, entry in summary_data.get("isc", {}).items():
        if key not in data["intersystem_crossing"]:
            if "total_rate_s1" not in entry and entry.get("ms_components"):
                entry["total_rate_s1"] = _calculate_total_isc_rate(entry["ms_components"])
            data["intersystem_crossing"][key] = entry

    # Parse IC data
    ic_pairs = [("S1", "S0"), ("S2", "S1"), ("T2", "T1")]
    for state1, state2 in ic_pairs:
        ic_data = parse_ic_data(esd_dir, state1, state2)
        key = f"{state1}_{state2}"
        summary_ic = summary_data.get("ic", {}).get(key)
        if summary_ic:
            data["internal_conversion"][key] = summary_ic
        elif ic_data:
            data["internal_conversion"][key] = ic_data

    # Add any additional IC entries from ESD.txt not covered above
    for key, entry in summary_data.get("ic", {}).items():
        if key not in data["internal_conversion"]:
            data["internal_conversion"][key] = entry

    # Parse fluorescence/phosphorescence rates if present
    fluor = parse_fluor_data(esd_dir, "S1", "S0")
    if fluor:
        data["fluorescence_rates"]["S1_S0"] = fluor

    phosp = parse_phosp_data(esd_dir, "T1", "S0")
    if phosp:
        data["phosphorescence_rates"]["T1_S0"] = phosp

    logger.info("ESD data collection complete")
    return data


def save_esd_data_json(project_dir: Path, output_json: Optional[Path] = None) -> Path:
    """
    Collect all ESD data and save to JSON file.

    Args:
        project_dir: Path to project directory
        output_json: Optional output JSON path (default: project_dir/DELFIN_Data.json)

    Returns:
        Path to saved JSON file
    """
    data = collect_esd_data(project_dir)

    if output_json is None:
        output_json = project_dir / "DELFIN_Data.json"

    with open(output_json, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

    logger.info(f"Saved DELFIN data to {output_json}")
    return output_json
