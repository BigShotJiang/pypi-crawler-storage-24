# src/iints/__init__.py

import pandas as pd # Required for type hints like pd.DataFrame
from typing import Optional

try:
    from importlib.metadata import PackageNotFoundError, version
except ImportError:  # pragma: no cover - Python < 3.8 fallback
    from importlib_metadata import PackageNotFoundError, version  # type: ignore

try:
    __version__ = version("iints-sdk-python35")
except PackageNotFoundError:  # pragma: no cover - source tree fallback
    __version__ = "1.3.1"

# Note to developers: this SDK is currently maintained by a single author.
# Please report bugs via GitHub issues and feel free to contribute fixes via PRs.

# API Components for Algorithm Development
from .api.base_algorithm import (
    InsulinAlgorithm,
    AlgorithmInput,
    AlgorithmResult,
    AlgorithmMetadata,
    WhyLogEntry,
)

# Core Simulation Components
from .core.simulator import Simulator, StressEvent, SimulationLimitError
from .core.patient.models import PatientModel
from .core.patient.patient_factory import PatientFactory
from .core.patient.profile import PatientProfile
try:
    from .core.device_manager import DeviceManager
except Exception:  # pragma: no cover - fallback if torch/device manager import fails
    class DeviceManager:  # type: ignore
        def __init__(self):
            self._device = "cpu"

        def get_device(self):
            return self._device
from .core.safety import SafetyConfig, SafetySupervisor
from .core.devices.models import SensorModel, PumpModel
from .core.algorithms.standard_pump_algo import StandardPumpAlgorithm
from .core.algorithms.mock_algorithms import (
    ConstantDoseAlgorithm,
    RandomDoseAlgorithm,
    RunawayAIAlgorithm,
    StackingAIAlgorithm,
)

# Data Handling
from .data.ingestor import DataIngestor
from .data.importer import (
    ImportResult,
    export_demo_csv,
    export_standard_csv,
    guess_column_mapping,
    import_carelink_csv,
    import_carelink_timeline,
    import_cgm_csv,
    import_cgm_dataframe,
    load_carelink_event_log,
    load_demo_dataframe,
    scenario_from_csv,
    scenario_from_dataframe,
    summarize_carelink_csv,
)
from .data.nightscout import NightscoutConfig, import_nightscout
from .data.tidepool import TidepoolClient, load_openapi_spec
from .data.guardians import mdmp_gate, MDMPGateError
from .data.synthetic_mirror import generate_synthetic_mirror, SyntheticMirrorArtifact
from .analysis.metrics import generate_benchmark_metrics # Added for benchmark
from .analysis.booth_demo import build_booth_demo
from .analysis.carelink_workbench import build_carelink_workbench
from .analysis.poster import generate_results_poster
from .analysis.reporting import ClinicalReportGenerator
from .analysis.edge_efficiency import EnergyEstimate, estimate_energy_per_decision
from .ai import AIResponse, IINTSAssistant, MDMPGuard
from .highlevel import run_simulation, run_full, run_population
from .scenarios import ScenarioGeneratorConfig, generate_random_scenario

# Population testing
from .population import (
    PopulationGenerator,
    PopulationConfig,
    ParameterDistribution,
    PopulationRunner,
    PopulationResult,
    PatientResult,
)

# Bergman Minimal Model (ODE-based patient)
try:
    from .core.patient.bergman_model import BergmanPatientModel
except ImportError:  # pragma: no cover - scipy may not be installed
    BergmanPatientModel = None  # type: ignore[assignment,misc]

# Placeholder for Reporting/Analysis
# This will be further developed in a dedicated module (e.g., iints.analysis.reporting)
def generate_report(simulation_results: 'pd.DataFrame', output_path: Optional[str] = None, safety_report: Optional[dict] = None) -> Optional[str]:
    """
    Generate a clinical PDF report from simulation results.
    """
    if output_path is None:
        return None
    generator = ClinicalReportGenerator()
    return generator.generate_pdf(simulation_results, safety_report or {}, output_path)

def generate_quickstart_report(
    simulation_results: 'pd.DataFrame',
    output_path: Optional[str] = None,
    safety_report: Optional[dict] = None,
) -> Optional[str]:
    """
    Generate a concise Quickstart PDF report from simulation results.
    """
    if output_path is None:
        return None
    generator = ClinicalReportGenerator()
    return generator.generate_pdf(
        simulation_results,
        safety_report or {},
        output_path,
        title="IINTS-AF Quickstart Report",
    )

def generate_demo_report(
    simulation_results: 'pd.DataFrame',
    output_path: Optional[str] = None,
    safety_report: Optional[dict] = None,
) -> Optional[str]:
    """
    Generate a demo-friendly PDF with big visuals (Maker Faire style).
    """
    if output_path is None:
        return None
    generator = ClinicalReportGenerator()
    return generator.generate_demo_pdf(
        simulation_results,
        safety_report or {},
        output_path,
        title="IINTS-AF Demo Report",
    )

# You can also define __all__ to explicitly control what gets imported with `from iints import *`
__all__ = [
    # API
    "InsulinAlgorithm", "AlgorithmInput", "AlgorithmResult", "AlgorithmMetadata", "WhyLogEntry",
    # Core
    "Simulator", "StressEvent", "PatientModel", "DeviceManager",
    "PatientFactory",
    "PatientProfile",
    "SimulationLimitError",
    "SafetySupervisor",
    "SafetyConfig",
    "SensorModel",
    "PumpModel",
    "StandardPumpAlgorithm",
    "ConstantDoseAlgorithm",
    "RandomDoseAlgorithm",
    "RunawayAIAlgorithm",
    "StackingAIAlgorithm",
    # Data
    "DataIngestor",
    "ImportResult",
    "export_demo_csv",
    "export_standard_csv",
    "guess_column_mapping",
    "import_carelink_csv",
    "import_carelink_timeline",
    "import_cgm_csv",
    "import_cgm_dataframe",
    "load_carelink_event_log",
    "load_demo_dataframe",
    "scenario_from_csv",
    "scenario_from_dataframe",
    "summarize_carelink_csv",
    "NightscoutConfig",
    "import_nightscout",
    "TidepoolClient",
    "load_openapi_spec",
    "mdmp_gate",
    "MDMPGateError",
    "generate_synthetic_mirror",
    "SyntheticMirrorArtifact",
    # Analysis Metrics
    "generate_benchmark_metrics",
    "build_booth_demo",
    "build_carelink_workbench",
    "ClinicalReportGenerator",
    "EnergyEstimate",
    "estimate_energy_per_decision",
    "AIResponse",
    "IINTSAssistant",
    "MDMPGuard",
    # Reporting
    "generate_report",
    "generate_quickstart_report",
    "generate_demo_report",
    "generate_results_poster",
    # High-level API
    "run_simulation",
    "run_full",
    "run_population",
    "ScenarioGeneratorConfig",
    "generate_random_scenario",
    # Population testing
    "PopulationGenerator",
    "PopulationConfig",
    "ParameterDistribution",
    "PopulationRunner",
    "PopulationResult",
    "PatientResult",
    # Bergman model
    "BergmanPatientModel",
]
