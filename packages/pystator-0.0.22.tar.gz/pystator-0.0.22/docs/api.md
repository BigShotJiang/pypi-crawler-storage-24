# API Reference

Condensed reference for PyStator’s main public API. For full signatures and implementation details, see the source and docstrings.

## StateMachine

**Creation**

- `StateMachine.from_yaml(path: str | Path) -> StateMachine`
- `StateMachine.from_dict(config: dict) -> StateMachine`
- `StateMachine.validate_config(config: dict) -> list[str]` — schema + semantic validation without building a machine; empty list means valid

**Config validation (module-level)**

- `validate_config(config: dict, strict: bool = True) -> list[str]` — same rules as `StateMachine.validate_config` when `strict=False`; if `strict=True`, raises `ConfigurationError` on failure (returns `[]` on success)
- `validate_machine_config` — alias of `validate_config`
- `ConfigValidator` — `ConfigValidator().validate(config) -> list[str]`

**Sync processing**

- `process(current_state: str, trigger: str, context: dict) -> TransitionResult`

**Async processing** (for async guards)

- `aprocess(current_state: str, trigger: str, context: dict) -> TransitionResult` — async (for async guards)

**Parallel states**

- `enter_parallel_state(parallel_state_name: str) -> ParallelStateConfig`
- `process_parallel(config: ParallelStateConfig, trigger: str, context: dict) -> tuple[ParallelStateConfig, list[TransitionResult]]`
- `aprocess_parallel(config, trigger, context)` — async variant
- `get_parallel_exit_actions(config: ParallelStateConfig)` — exit actions when leaving parallel state

**Queries**

- `get_initial_state() -> State`
- `get_state(name: str) -> State | None`
- `get_available_transitions(state_name: str) -> list[Transition]`
- `evaluate_destination(current_state: str, destination_state: str, context: dict | None) -> DestinationCheckResult` — when you only know a **target state** (e.g. external status), not a trigger; see docstring for semantics and `metadata["ambiguous"]` when multiple paths apply
- `can_transition_to(current_state: str, destination_state: str, context: dict | None) -> bool` — `evaluate_destination(...).allowed`
- `is_parallel_state(name: str) -> bool`
- `validate_parallel_config(config: ParallelStateConfig) -> None` (raises if invalid)

**Properties**

- `name`, `version` (from meta)
- `state_names`, `states`, `transitions`

## TransitionResult

- `success: bool`
- `source_state: str`
- `target_state: str | None`
- `trigger: str`
- `all_actions: tuple[str, ...]` — ordered exit + transition + enter action names
- `error: FSMError | None`

## DestinationCheckResult

Structured result from `StateMachine.evaluate_destination` / `EntitySession.evaluate_destination`:

- `allowed: bool`
- `source_state: str`, `destination_state: str`
- `candidate_count: int`, `passing_count: int`
- `candidates: tuple[DestinationCandidate, ...]` — per matching transition (`trigger`, `executable`, `transition_result`, `reason`)
- `metadata: dict` — e.g. `reason` when no path exists or destination undefined; `ambiguous: True` when more than one path reaches the destination
- `is_ambiguous: bool` — `passing_count > 1`

## GuardRegistry

- `register(name: str, fn: Callable[[dict], bool]) -> None`
- `decorator(name: str)` — decorator to register a function as a guard
- Supports async callables when using `aprocess` / `aprocess_parallel`

**Binding to machine:** `machine.bind_guards(guards)`

## ActionRegistry

- `register(name: str, fn: Callable[[dict], None]) -> None`
- `decorator()` — decorator to register a function as an action
- Supports async callables; run with `executor.async_execute_*`

## ActionExecutor

- `ActionExecutor(registry: ActionRegistry, default_mode: ExecutionMode = ..., log_execution: bool = ...)`
- `execute(result: TransitionResult, context: dict) -> ExecutionResult` — sync, sequential or phased by default mode
- `async_execute_parallel(result, context)` — run all actions concurrently (async)
- `async_execute_phased(result, context)` — exit → transition → enter in phases (async)
- `async_execute_with_mode(result, context, mode)` — run with specified mode

**ExecutionMode:** `SEQUENTIAL`, `PARALLEL`, `PHASED`

## ParallelStateConfig

- `parallel_state: str`
- `region_states: dict[str, str]` — region name → current state name
- `get_region_state(region: str) -> str | None`
- `is_in_state(state_name: str) -> bool`
- `get_all_active() -> list[str]` — all active leaf state names
- `to_string() -> str` — compact representation

## Orchestrator (optional)

For delayed transitions and (optionally) invoke/long-lived services:

- `Orchestrator(machine, state_store, guards, actions, scheduler=..., context_validator=...)`
- `async_process_event(entity_id, trigger, context)` — load state from store, process, persist, schedule delayed transitions, run actions

Requires a **StateStore** (e.g. `InMemoryStateStore`) and a **SchedulerAdapter** (e.g. `AsyncioScheduler`, `RedisScheduler`, `CeleryScheduler`).

## Scheduler adapters (delayed transitions)

- **AsyncioScheduler** — in-memory, no extra infra
- **RedisScheduler** — requires Redis; `await scheduler.start()` to start polling
- **CeleryScheduler** — requires Celery app; `scheduler.register_task()` to register the task

## Worker (event-processing service)

The Worker is a long-running process that polls the `worker_events` table, claims events, and processes them through the Orchestrator. See [Worker guide](guides/worker.md).

**CLI:** `pystator worker` — optional `--concurrency`, `--poll-interval`, `--app MODULE:FACTORY`.

**Worker**

- `Worker(config: WorkerConfig | None = None, guards=..., actions=..., event_source=...)` — build a worker (default: database event source).
- `await worker.start()` — connect, load machines, create processor and state store.
- `await worker.run()` — block until shutdown (SIGTERM/SIGINT); drains in-flight events.
- `await worker.shutdown()` — programmatic shutdown.

**WorkerConfig**

- `db_url`, `poll_interval_ms`, `concurrency`, `drain_timeout_s`, `max_attempts`, `machine_source` (`"db"` or `"yaml"`), `machine_dir`, `worker_id`. All have defaults; overridable via `PYSTATOR_WORKER_*` env or `pystator.cfg` `[worker]`.

**Submitting events**

- `submit_event(machine_name, entity_id, trigger, *, context=..., fires_at=..., idempotency_key=..., max_attempts=..., db_url=...) -> str` — enqueue one event (async). Returns `event_id`. Writes to `worker_events` table.
- `submit_event_sync(...)` — same, for synchronous callers (e.g. scripts, Django/Flask).

**Models**

- `WorkerEvent` — machine_name, entity_id, trigger, context, fires_at, idempotency_key, max_attempts.
- `ClaimedEvent` — event_id, machine_name, entity_id, trigger, context (from event source).
- `EventStatus` — enum for event lifecycle (e.g. pending, claimed, completed, failed).

## REST API transition outcomes

When using the optional HTTP layer (`pip install pystator[api]`):

- **`POST /process`** (stateless) returns **HTTP 200** with a body where `success` is `true` or `false`. A failed transition is **not** a 4xx; **400** is reserved for cases where the request cannot be processed (e.g. invalid config when building the machine).
- **`POST /entities/{entity_id}/events`** returns **200** with `success`, `error_detail` (structured), and legacy **`error`** (string, same as `error_detail.message` when failed).

Structured failure object (`error` on `/process`, `error_detail` on entity events):

- `code` — machine-readable string (see `ErrorCode` in `pystator.errors`)
- `type` — exception class name
- `message` — human-readable text
- `details` — optional dict (engine `metadata`, e.g. guard traces, plus `error_context` when present)

In Python, the core library still returns **`TransitionResult`**; **`UndefinedStateError`** is raised for an undefined **current** state name (not a JSON body).

## Errors

Machine-readable codes are defined in **`ErrorCode`** (`pystator.errors`), e.g. `guard_rejected`, `invalid_trigger`, `terminal_state`, `undefined_state`.

- **FSMError** — base
- **ConfigurationError** — invalid config / schema
- **InvalidTransitionError** — no matching transition
- **GuardRejectedError** — guard returned false or raised
- **UndefinedStateError** / **UndefinedTriggerError**
- **TimeoutExpiredError**
- **GuardNotFoundError** / **ActionNotFoundError**

Catch `FSMError` to handle any of these in one place.
