"""SQLite discovery store."""

from __future__ import annotations

from pathlib import Path

from pystator.discovery.stores._sql import _SQLDiscoveryStoreBase


class SQLiteDiscoveryStore(_SQLDiscoveryStoreBase):
    def __init__(self, connection_string: str) -> None:
        if not connection_string.startswith("sqlite://"):
            raise ValueError(
                f"SQLiteDiscoveryStore requires a sqlite:// URL, got: {connection_string!r}"
            )
        if connection_string != "sqlite:///:memory:" and connection_string.startswith(
            "sqlite:///"
        ):
            db_path = Path(connection_string[len("sqlite:///") :])
            db_path.parent.mkdir(parents=True, exist_ok=True)
        super().__init__(connection_string)
