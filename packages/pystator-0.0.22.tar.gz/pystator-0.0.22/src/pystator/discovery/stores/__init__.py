"""Discovery store implementations and factory."""

from __future__ import annotations

from pystator.discovery.stores.factory import create_discovery_store
from pystator.discovery.stores.in_memory import InMemoryDiscoveryStore

try:
    from pystator.discovery.stores.sqlite import SQLiteDiscoveryStore
except ImportError:
    SQLiteDiscoveryStore = None  # type: ignore[assignment,misc]

try:
    from pystator.discovery.stores.postgres import PostgresDiscoveryStore
except ImportError:
    PostgresDiscoveryStore = None  # type: ignore[assignment,misc]

try:
    from pystator.discovery.stores.mongodb import MongoDBDiscoveryStore
except ImportError:
    MongoDBDiscoveryStore = None  # type: ignore[assignment,misc]

try:
    from pystator.discovery.stores.redis import RedisDiscoveryStore
except ImportError:
    RedisDiscoveryStore = None  # type: ignore[assignment,misc]

__all__ = [
    "create_discovery_store",
    "InMemoryDiscoveryStore",
    "SQLiteDiscoveryStore",
    "PostgresDiscoveryStore",
    "MongoDBDiscoveryStore",
    "RedisDiscoveryStore",
]
