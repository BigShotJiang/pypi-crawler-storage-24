"""MongoDB discovery store."""

from __future__ import annotations

from datetime import datetime

from pystator.discovery.models import (
    CandidateMachineVersion,
    InferredEdge,
    ObservedStateEvent,
    ShadowDiff,
)

try:
    import pymongo  # type: ignore[import-not-found,import-untyped]

    MONGO_AVAILABLE = True
except ImportError:
    MONGO_AVAILABLE = False
    pymongo = None  # type: ignore[assignment]


class MongoDBDiscoveryStore:
    def __init__(self, connection_string: str, database_name: str = "pystator") -> None:
        if not MONGO_AVAILABLE:
            raise ImportError(
                "pymongo is required for MongoDBDiscoveryStore. Install with: pip install pymongo"
            )
        if not connection_string.startswith(("mongodb://", "mongodb+srv://")):
            raise ValueError(
                f"MongoDBDiscoveryStore requires a mongodb:// URL, got: {connection_string!r}"
            )
        self.connection_string = connection_string
        self.database_name = database_name
        self._client = None
        self._db = None

    def connect(self) -> None:
        self._client = pymongo.MongoClient(self.connection_string)
        self._db = self._client[self.database_name]
        self._db["discovery_observations"].create_index(
            [
                ("machine_name", 1),
                ("entity_id", 1),
                ("state", 1),
                ("observed_at", 1),
                ("source", 1),
                ("source_event_id", 1),
            ],
            unique=True,
        )
        self._db["discovery_candidates"].create_index(
            [("machine_name", 1), ("version", 1)], unique=True
        )

    def disconnect(self) -> None:
        if self._client is not None:
            self._client.close()
        self._client = None
        self._db = None

    def _require_db(self):
        if self._db is None:
            raise RuntimeError("Not connected. Call connect() first.")
        return self._db

    def add_observation(self, event: ObservedStateEvent) -> bool:
        db = self._require_db()
        doc = {
            "machine_name": str(event.metadata.get("machine_name", "default")),
            "entity_id": event.entity_id,
            "state": event.state,
            "observed_at": event.observed_at,
            "source": event.source,
            "source_event_id": event.source_event_id,
            "metadata": event.metadata,
            "ingested_at": event.ingested_at,
            "ingest_seq": event.ingest_seq,
        }
        try:
            db["discovery_observations"].insert_one(doc)
            return True
        except Exception:
            return False

    def list_observations(
        self, machine_name: str, entity_id: str | None = None
    ) -> list[ObservedStateEvent]:
        db = self._require_db()
        query = {"machine_name": machine_name}
        if entity_id:
            query["entity_id"] = entity_id
        rows = (
            db["discovery_observations"]
            .find(query)
            .sort(
                [
                    ("entity_id", 1),
                    ("observed_at", 1),
                    ("ingest_seq", 1),
                    ("ingested_at", 1),
                ]
            )
        )
        return [
            ObservedStateEvent(
                entity_id=row["entity_id"],
                state=row["state"],
                observed_at=row["observed_at"],
                source=row["source"],
                source_event_id=row.get("source_event_id"),
                metadata=dict(row.get("metadata") or {}),
                ingested_at=row["ingested_at"],
                ingest_seq=int(row.get("ingest_seq") or 0),
            )
            for row in rows
        ]

    def upsert_edges(self, machine_name: str, edges: list[InferredEdge]) -> None:
        db = self._require_db()
        db["discovery_edges"].delete_many({"machine_name": machine_name})
        if not edges:
            return
        db["discovery_edges"].insert_many(
            [
                {
                    "machine_name": machine_name,
                    "source_state": e.source_state,
                    "destination_state": e.destination_state,
                    "count": e.count,
                    "unique_entities": e.unique_entities,
                    "unique_sources": e.unique_sources,
                    "confidence": e.confidence,
                    "last_seen_at": e.last_seen_at,
                }
                for e in edges
            ]
        )

    def list_edges(self, machine_name: str) -> list[InferredEdge]:
        db = self._require_db()
        rows = (
            db["discovery_edges"]
            .find({"machine_name": machine_name})
            .sort([("source_state", 1), ("destination_state", 1)])
        )
        return [
            InferredEdge(
                source_state=row["source_state"],
                destination_state=row["destination_state"],
                count=int(row["count"]),
                unique_entities=int(row["unique_entities"]),
                unique_sources=int(row["unique_sources"]),
                confidence=float(row["confidence"]),
                last_seen_at=row.get("last_seen_at"),
            )
            for row in rows
        ]

    def save_candidate(
        self, candidate: CandidateMachineVersion
    ) -> CandidateMachineVersion:
        db = self._require_db()
        db["discovery_candidates"].replace_one(
            {"machine_name": candidate.machine_name, "version": candidate.version},
            {
                "machine_name": candidate.machine_name,
                "version": candidate.version,
                "status": candidate.status,
                "config": candidate.config,
                "metadata": candidate.metadata,
                "created_at": candidate.created_at,
            },
            upsert=True,
        )
        return candidate

    def get_candidate(
        self, machine_name: str, version: str
    ) -> CandidateMachineVersion | None:
        db = self._require_db()
        row = db["discovery_candidates"].find_one(
            {"machine_name": machine_name, "version": version}
        )
        if not row:
            return None
        return CandidateMachineVersion(
            machine_name=row["machine_name"],
            version=row["version"],
            status=row["status"],
            config=dict(row["config"]),
            metadata=dict(row.get("metadata") or {}),
            created_at=row.get("created_at") or datetime.utcnow(),
        )

    def get_latest_candidate(self, machine_name: str) -> CandidateMachineVersion | None:
        db = self._require_db()
        row = db["discovery_candidates"].find_one(
            {"machine_name": machine_name}, sort=[("created_at", -1)]
        )
        if not row:
            return None
        return CandidateMachineVersion(
            machine_name=row["machine_name"],
            version=row["version"],
            status=row["status"],
            config=dict(row["config"]),
            metadata=dict(row.get("metadata") or {}),
            created_at=row.get("created_at") or datetime.utcnow(),
        )

    def list_candidates(self, machine_name: str) -> list[CandidateMachineVersion]:
        db = self._require_db()
        rows = (
            db["discovery_candidates"]
            .find({"machine_name": machine_name})
            .sort([("created_at", -1)])
        )
        return [
            CandidateMachineVersion(
                machine_name=row["machine_name"],
                version=row["version"],
                status=row["status"],
                config=dict(row["config"]),
                metadata=dict(row.get("metadata") or {}),
                created_at=row.get("created_at") or datetime.utcnow(),
            )
            for row in rows
        ]

    def record_shadow_diff(self, diff: ShadowDiff) -> None:
        db = self._require_db()
        db["discovery_shadow_diffs"].insert_one(
            {
                "machine_name": diff.machine_name,
                "source_state": diff.source_state,
                "trigger": diff.trigger,
                "active_success": diff.active_success,
                "active_target_state": diff.active_target_state,
                "candidate_success": diff.candidate_success,
                "candidate_target_state": diff.candidate_target_state,
                "differs": diff.differs,
                "reason": diff.reason,
                "recorded_at": diff.recorded_at,
                "metadata": diff.metadata,
            }
        )

    def list_shadow_diffs(
        self, machine_name: str, limit: int = 100
    ) -> list[ShadowDiff]:
        db = self._require_db()
        rows = (
            db["discovery_shadow_diffs"]
            .find({"machine_name": machine_name})
            .sort([("recorded_at", -1)])
            .limit(max(0, limit))
        )
        return [
            ShadowDiff(
                machine_name=row["machine_name"],
                source_state=row["source_state"],
                trigger=row["trigger"],
                active_success=bool(row["active_success"]),
                active_target_state=row.get("active_target_state"),
                candidate_success=bool(row["candidate_success"]),
                candidate_target_state=row.get("candidate_target_state"),
                differs=bool(row["differs"]),
                reason=row.get("reason"),
                recorded_at=row["recorded_at"],
                metadata=dict(row.get("metadata") or {}),
            )
            for row in rows
        ]
