"""Redis discovery store."""

from __future__ import annotations

import json
from datetime import datetime
from typing import Any

from pystator.discovery.models import (
    CandidateMachineVersion,
    InferredEdge,
    ObservedStateEvent,
    ShadowDiff,
)

try:
    import redis as _redis_lib  # type: ignore[import-not-found,import-untyped]

    REDIS_AVAILABLE = True
except ImportError:
    REDIS_AVAILABLE = False
    _redis_lib = None  # type: ignore[assignment]


class RedisDiscoveryStore:
    def __init__(
        self, connection_string: str, key_prefix: str = "pystator:discovery"
    ) -> None:
        if not REDIS_AVAILABLE:
            raise ImportError(
                "redis is required for RedisDiscoveryStore. Install with: pip install redis"
            )
        self.connection_string = connection_string
        self.key_prefix = key_prefix
        self._client: Any = None

    def connect(self) -> None:
        self._client = _redis_lib.from_url(
            self.connection_string, decode_responses=True
        )
        self._client.ping()

    def disconnect(self) -> None:
        if self._client is not None:
            self._client.close()
            self._client = None

    def _require_client(self):
        if self._client is None:
            raise RuntimeError("Not connected. Call connect() first.")
        return self._client

    def _key(self, *parts: str) -> str:
        return f"{self.key_prefix}:{':'.join(parts)}"

    def _json(self, value: Any) -> str:
        return json.dumps(value, default=str)

    def add_observation(self, event: ObservedStateEvent) -> bool:
        client = self._require_client()
        machine_name = str(event.metadata.get("machine_name", "default"))
        dedupe_key = self._key(
            "obs",
            machine_name,
            event.entity_id,
            event.state,
            event.observed_at.isoformat(),
            event.source,
            event.source_event_id or "",
        )
        if not client.set(dedupe_key, "1", nx=True):
            return False
        payload = self._json(
            {
                "entity_id": event.entity_id,
                "state": event.state,
                "observed_at": event.observed_at.isoformat(),
                "source": event.source,
                "source_event_id": event.source_event_id,
                "metadata": event.metadata,
                "ingested_at": event.ingested_at.isoformat(),
                "ingest_seq": event.ingest_seq,
            }
        )
        client.rpush(self._key("obslist", machine_name), payload)
        return True

    def list_observations(
        self, machine_name: str, entity_id: str | None = None
    ) -> list[ObservedStateEvent]:
        client = self._require_client()
        rows = client.lrange(self._key("obslist", machine_name), 0, -1)
        out: list[ObservedStateEvent] = []
        for row in rows:
            doc = json.loads(row)
            if entity_id and doc["entity_id"] != entity_id:
                continue
            out.append(
                ObservedStateEvent(
                    entity_id=doc["entity_id"],
                    state=doc["state"],
                    observed_at=datetime.fromisoformat(doc["observed_at"]),
                    source=doc["source"],
                    source_event_id=doc.get("source_event_id"),
                    metadata=dict(doc.get("metadata") or {}),
                    ingested_at=datetime.fromisoformat(doc["ingested_at"]),
                    ingest_seq=int(doc.get("ingest_seq") or 0),
                )
            )
        out.sort(
            key=lambda e: (e.entity_id, e.observed_at, e.ingest_seq, e.ingested_at)
        )
        return out

    def upsert_edges(self, machine_name: str, edges: list[InferredEdge]) -> None:
        client = self._require_client()
        client.set(
            self._key("edges", machine_name),
            self._json(
                [
                    {
                        "source_state": e.source_state,
                        "destination_state": e.destination_state,
                        "count": e.count,
                        "unique_entities": e.unique_entities,
                        "unique_sources": e.unique_sources,
                        "confidence": e.confidence,
                        "last_seen_at": e.last_seen_at.isoformat()
                        if e.last_seen_at
                        else None,
                    }
                    for e in edges
                ]
            ),
        )

    def list_edges(self, machine_name: str) -> list[InferredEdge]:
        client = self._require_client()
        raw = client.get(self._key("edges", machine_name))
        if not raw:
            return []
        data = json.loads(raw)
        return [
            InferredEdge(
                source_state=item["source_state"],
                destination_state=item["destination_state"],
                count=int(item["count"]),
                unique_entities=int(item["unique_entities"]),
                unique_sources=int(item["unique_sources"]),
                confidence=float(item["confidence"]),
                last_seen_at=datetime.fromisoformat(item["last_seen_at"])
                if item.get("last_seen_at")
                else None,
            )
            for item in data
        ]

    def save_candidate(
        self, candidate: CandidateMachineVersion
    ) -> CandidateMachineVersion:
        client = self._require_client()
        key = self._key("candidate", candidate.machine_name, candidate.version)
        client.set(
            key,
            self._json(
                {
                    "machine_name": candidate.machine_name,
                    "version": candidate.version,
                    "status": candidate.status,
                    "config": candidate.config,
                    "metadata": candidate.metadata,
                    "created_at": candidate.created_at.isoformat(),
                }
            ),
        )
        client.zadd(
            self._key("candidate_index", candidate.machine_name),
            {candidate.version: candidate.created_at.timestamp()},
        )
        return candidate

    def get_candidate(
        self, machine_name: str, version: str
    ) -> CandidateMachineVersion | None:
        client = self._require_client()
        raw = client.get(self._key("candidate", machine_name, version))
        if not raw:
            return None
        item = json.loads(raw)
        return CandidateMachineVersion(
            machine_name=item["machine_name"],
            version=item["version"],
            status=item["status"],
            config=dict(item["config"]),
            metadata=dict(item.get("metadata") or {}),
            created_at=datetime.fromisoformat(item["created_at"]),
        )

    def get_latest_candidate(self, machine_name: str) -> CandidateMachineVersion | None:
        client = self._require_client()
        versions = client.zrevrange(self._key("candidate_index", machine_name), 0, 0)
        if not versions:
            return None
        return self.get_candidate(machine_name, versions[0])

    def list_candidates(self, machine_name: str) -> list[CandidateMachineVersion]:
        client = self._require_client()
        versions = client.zrevrange(self._key("candidate_index", machine_name), 0, -1)
        out: list[CandidateMachineVersion] = []
        for version in versions:
            item = self.get_candidate(machine_name, version)
            if item is not None:
                out.append(item)
        return out

    def record_shadow_diff(self, diff: ShadowDiff) -> None:
        client = self._require_client()
        payload = self._json(
            {
                "machine_name": diff.machine_name,
                "source_state": diff.source_state,
                "trigger": diff.trigger,
                "active_success": diff.active_success,
                "active_target_state": diff.active_target_state,
                "candidate_success": diff.candidate_success,
                "candidate_target_state": diff.candidate_target_state,
                "differs": diff.differs,
                "reason": diff.reason,
                "recorded_at": diff.recorded_at.isoformat(),
                "metadata": diff.metadata,
            }
        )
        client.lpush(self._key("shadow", diff.machine_name), payload)

    def list_shadow_diffs(
        self, machine_name: str, limit: int = 100
    ) -> list[ShadowDiff]:
        client = self._require_client()
        rows = client.lrange(self._key("shadow", machine_name), 0, max(0, limit) - 1)
        out: list[ShadowDiff] = []
        for row in rows:
            item = json.loads(row)
            out.append(
                ShadowDiff(
                    machine_name=item["machine_name"],
                    source_state=item["source_state"],
                    trigger=item["trigger"],
                    active_success=bool(item["active_success"]),
                    active_target_state=item.get("active_target_state"),
                    candidate_success=bool(item["candidate_success"]),
                    candidate_target_state=item.get("candidate_target_state"),
                    differs=bool(item["differs"]),
                    reason=item.get("reason"),
                    recorded_at=datetime.fromisoformat(item["recorded_at"]),
                    metadata=dict(item.get("metadata") or {}),
                )
            )
        return out
