"""PostgreSQL discovery store."""

from __future__ import annotations

from pystator.discovery.stores._sql import _SQLDiscoveryStoreBase


class PostgresDiscoveryStore(_SQLDiscoveryStoreBase):
    def __init__(self, connection_string: str) -> None:
        if not connection_string.startswith(("postgresql://", "postgres://")):
            raise ValueError(
                f"PostgresDiscoveryStore requires a postgresql:// URL, got: {connection_string!r}"
            )
        super().__init__(connection_string)
