"""Private SQL-backed discovery store shared by SQLite and PostgreSQL."""

from __future__ import annotations

import json
from datetime import datetime
from typing import Any

from sqlalchemy import create_engine, text
from sqlalchemy.engine import Engine

from pystator.discovery.models import (
    CandidateMachineVersion,
    InferredEdge,
    ObservedStateEvent,
    ShadowDiff,
)


def _dt_parse(value: Any) -> datetime:
    if isinstance(value, datetime):
        return value
    if isinstance(value, str):
        return datetime.fromisoformat(value)
    raise ValueError(f"Cannot parse datetime value: {value!r}")


class _SQLDiscoveryStoreBase:
    def __init__(self, connection_string: str) -> None:
        self.connection_string = connection_string
        self._engine: Engine | None = None

    def connect(self) -> None:
        self._engine = create_engine(self.connection_string, future=True)
        self._initialize_schema()

    def disconnect(self) -> None:
        if self._engine is not None:
            self._engine.dispose()
            self._engine = None

    def _require_engine(self) -> Engine:
        if self._engine is None:
            raise RuntimeError("Not connected. Call connect() first.")
        return self._engine

    def _initialize_schema(self) -> None:
        engine = self._require_engine()
        with engine.begin() as conn:
            conn.execute(
                text(
                    """
                    CREATE TABLE IF NOT EXISTS discovery_observations (
                      machine_name TEXT NOT NULL,
                      entity_id TEXT NOT NULL,
                      state TEXT NOT NULL,
                      observed_at TEXT NOT NULL,
                      source TEXT NOT NULL,
                      source_event_id TEXT,
                      metadata_json TEXT NOT NULL,
                      ingested_at TEXT NOT NULL,
                      ingest_seq INTEGER NOT NULL DEFAULT 0,
                      UNIQUE(machine_name, entity_id, state, observed_at, source, source_event_id)
                    )
                    """
                )
            )
            conn.execute(
                text(
                    """
                    CREATE TABLE IF NOT EXISTS discovery_edges (
                      machine_name TEXT NOT NULL,
                      source_state TEXT NOT NULL,
                      destination_state TEXT NOT NULL,
                      count INTEGER NOT NULL,
                      unique_entities INTEGER NOT NULL,
                      unique_sources INTEGER NOT NULL,
                      confidence REAL NOT NULL,
                      last_seen_at TEXT,
                      UNIQUE(machine_name, source_state, destination_state)
                    )
                    """
                )
            )
            conn.execute(
                text(
                    """
                    CREATE TABLE IF NOT EXISTS discovery_candidates (
                      machine_name TEXT NOT NULL,
                      version TEXT NOT NULL,
                      status TEXT NOT NULL,
                      config_json TEXT NOT NULL,
                      metadata_json TEXT NOT NULL,
                      created_at TEXT NOT NULL,
                      UNIQUE(machine_name, version)
                    )
                    """
                )
            )
            conn.execute(
                text(
                    """
                    CREATE TABLE IF NOT EXISTS discovery_shadow_diffs (
                      machine_name TEXT NOT NULL,
                      source_state TEXT NOT NULL,
                      trigger TEXT NOT NULL,
                      active_success INTEGER NOT NULL,
                      active_target_state TEXT,
                      candidate_success INTEGER NOT NULL,
                      candidate_target_state TEXT,
                      differs INTEGER NOT NULL,
                      reason TEXT,
                      metadata_json TEXT NOT NULL,
                      recorded_at TEXT NOT NULL
                    )
                    """
                )
            )

    def add_observation(self, event: ObservedStateEvent) -> bool:
        engine = self._require_engine()
        machine_name = str(event.metadata.get("machine_name", "default"))
        with engine.begin() as conn:
            result = conn.execute(
                text(
                    """
                    INSERT INTO discovery_observations (
                      machine_name, entity_id, state, observed_at, source, source_event_id,
                      metadata_json, ingested_at, ingest_seq
                    ) VALUES (
                      :machine_name, :entity_id, :state, :observed_at, :source, :source_event_id,
                      :metadata_json, :ingested_at, :ingest_seq
                    )
                    ON CONFLICT(machine_name, entity_id, state, observed_at, source, source_event_id)
                    DO NOTHING
                    """
                ),
                {
                    "machine_name": machine_name,
                    "entity_id": event.entity_id,
                    "state": event.state,
                    "observed_at": event.observed_at.isoformat(),
                    "source": event.source,
                    "source_event_id": event.source_event_id,
                    "metadata_json": json.dumps(event.metadata),
                    "ingested_at": event.ingested_at.isoformat(),
                    "ingest_seq": event.ingest_seq,
                },
            )
        return bool(result.rowcount and result.rowcount > 0)

    def list_observations(
        self, machine_name: str, entity_id: str | None = None
    ) -> list[ObservedStateEvent]:
        engine = self._require_engine()
        sql = """
            SELECT entity_id, state, observed_at, source, source_event_id, metadata_json, ingested_at, ingest_seq
            FROM discovery_observations
            WHERE machine_name = :machine_name
        """
        params: dict[str, Any] = {"machine_name": machine_name}
        if entity_id:
            sql += " AND entity_id = :entity_id"
            params["entity_id"] = entity_id
        sql += " ORDER BY entity_id, observed_at, ingest_seq, ingested_at"
        with engine.begin() as conn:
            rows = conn.execute(text(sql), params).mappings().all()
        return [
            ObservedStateEvent(
                entity_id=row["entity_id"],
                state=row["state"],
                observed_at=_dt_parse(row["observed_at"]),
                source=row["source"],
                source_event_id=row["source_event_id"],
                metadata=json.loads(row["metadata_json"] or "{}"),
                ingested_at=_dt_parse(row["ingested_at"]),
                ingest_seq=int(row["ingest_seq"] or 0),
            )
            for row in rows
        ]

    def upsert_edges(self, machine_name: str, edges: list[InferredEdge]) -> None:
        engine = self._require_engine()
        with engine.begin() as conn:
            conn.execute(
                text("DELETE FROM discovery_edges WHERE machine_name = :machine_name"),
                {"machine_name": machine_name},
            )
            for edge in edges:
                conn.execute(
                    text(
                        """
                        INSERT INTO discovery_edges (
                          machine_name, source_state, destination_state, count,
                          unique_entities, unique_sources, confidence, last_seen_at
                        ) VALUES (
                          :machine_name, :source_state, :destination_state, :count,
                          :unique_entities, :unique_sources, :confidence, :last_seen_at
                        )
                        """
                    ),
                    {
                        "machine_name": machine_name,
                        "source_state": edge.source_state,
                        "destination_state": edge.destination_state,
                        "count": edge.count,
                        "unique_entities": edge.unique_entities,
                        "unique_sources": edge.unique_sources,
                        "confidence": edge.confidence,
                        "last_seen_at": edge.last_seen_at.isoformat()
                        if edge.last_seen_at
                        else None,
                    },
                )

    def list_edges(self, machine_name: str) -> list[InferredEdge]:
        engine = self._require_engine()
        with engine.begin() as conn:
            rows = conn.execute(
                text(
                    """
                    SELECT source_state, destination_state, count, unique_entities, unique_sources,
                           confidence, last_seen_at
                    FROM discovery_edges
                    WHERE machine_name = :machine_name
                    ORDER BY source_state, destination_state
                    """
                ),
                {"machine_name": machine_name},
            ).mappings()
            result = rows.all()
        return [
            InferredEdge(
                source_state=row["source_state"],
                destination_state=row["destination_state"],
                count=int(row["count"]),
                unique_entities=int(row["unique_entities"]),
                unique_sources=int(row["unique_sources"]),
                confidence=float(row["confidence"]),
                last_seen_at=_dt_parse(row["last_seen_at"])
                if row["last_seen_at"]
                else None,
            )
            for row in result
        ]

    def save_candidate(
        self, candidate: CandidateMachineVersion
    ) -> CandidateMachineVersion:
        engine = self._require_engine()
        with engine.begin() as conn:
            conn.execute(
                text(
                    """
                    INSERT INTO discovery_candidates (
                      machine_name, version, status, config_json, metadata_json, created_at
                    ) VALUES (
                      :machine_name, :version, :status, :config_json, :metadata_json, :created_at
                    )
                    ON CONFLICT(machine_name, version)
                    DO UPDATE SET
                      status = excluded.status,
                      config_json = excluded.config_json,
                      metadata_json = excluded.metadata_json,
                      created_at = excluded.created_at
                    """
                ),
                {
                    "machine_name": candidate.machine_name,
                    "version": candidate.version,
                    "status": candidate.status,
                    "config_json": json.dumps(candidate.config),
                    "metadata_json": json.dumps(candidate.metadata),
                    "created_at": candidate.created_at.isoformat(),
                },
            )
        return candidate

    def get_candidate(
        self, machine_name: str, version: str
    ) -> CandidateMachineVersion | None:
        engine = self._require_engine()
        with engine.begin() as conn:
            row = (
                conn.execute(
                    text(
                        """
                    SELECT machine_name, version, status, config_json, metadata_json, created_at
                    FROM discovery_candidates
                    WHERE machine_name = :machine_name AND version = :version
                    """
                    ),
                    {"machine_name": machine_name, "version": version},
                )
                .mappings()
                .first()
            )
        if row is None:
            return None
        return CandidateMachineVersion(
            machine_name=row["machine_name"],
            version=row["version"],
            status=row["status"],
            config=json.loads(row["config_json"]),
            metadata=json.loads(row["metadata_json"] or "{}"),
            created_at=_dt_parse(row["created_at"]),
        )

    def get_latest_candidate(self, machine_name: str) -> CandidateMachineVersion | None:
        engine = self._require_engine()
        with engine.begin() as conn:
            row = (
                conn.execute(
                    text(
                        """
                    SELECT machine_name, version, status, config_json, metadata_json, created_at
                    FROM discovery_candidates
                    WHERE machine_name = :machine_name
                    ORDER BY created_at DESC
                    LIMIT 1
                    """
                    ),
                    {"machine_name": machine_name},
                )
                .mappings()
                .first()
            )
        if row is None:
            return None
        return CandidateMachineVersion(
            machine_name=row["machine_name"],
            version=row["version"],
            status=row["status"],
            config=json.loads(row["config_json"]),
            metadata=json.loads(row["metadata_json"] or "{}"),
            created_at=_dt_parse(row["created_at"]),
        )

    def list_candidates(self, machine_name: str) -> list[CandidateMachineVersion]:
        engine = self._require_engine()
        with engine.begin() as conn:
            rows = conn.execute(
                text(
                    """
                    SELECT machine_name, version, status, config_json, metadata_json, created_at
                    FROM discovery_candidates
                    WHERE machine_name = :machine_name
                    ORDER BY created_at DESC
                    """
                ),
                {"machine_name": machine_name},
            ).mappings()
            result = rows.all()
        return [
            CandidateMachineVersion(
                machine_name=row["machine_name"],
                version=row["version"],
                status=row["status"],
                config=json.loads(row["config_json"]),
                metadata=json.loads(row["metadata_json"] or "{}"),
                created_at=_dt_parse(row["created_at"]),
            )
            for row in result
        ]

    def record_shadow_diff(self, diff: ShadowDiff) -> None:
        engine = self._require_engine()
        with engine.begin() as conn:
            conn.execute(
                text(
                    """
                    INSERT INTO discovery_shadow_diffs (
                      machine_name, source_state, trigger, active_success, active_target_state,
                      candidate_success, candidate_target_state, differs, reason, metadata_json, recorded_at
                    ) VALUES (
                      :machine_name, :source_state, :trigger, :active_success, :active_target_state,
                      :candidate_success, :candidate_target_state, :differs, :reason, :metadata_json, :recorded_at
                    )
                    """
                ),
                {
                    "machine_name": diff.machine_name,
                    "source_state": diff.source_state,
                    "trigger": diff.trigger,
                    "active_success": 1 if diff.active_success else 0,
                    "active_target_state": diff.active_target_state,
                    "candidate_success": 1 if diff.candidate_success else 0,
                    "candidate_target_state": diff.candidate_target_state,
                    "differs": 1 if diff.differs else 0,
                    "reason": diff.reason,
                    "metadata_json": json.dumps(diff.metadata),
                    "recorded_at": diff.recorded_at.isoformat(),
                },
            )

    def list_shadow_diffs(
        self, machine_name: str, limit: int = 100
    ) -> list[ShadowDiff]:
        engine = self._require_engine()
        with engine.begin() as conn:
            rows = conn.execute(
                text(
                    """
                    SELECT machine_name, source_state, trigger, active_success, active_target_state,
                           candidate_success, candidate_target_state, differs, reason, metadata_json, recorded_at
                    FROM discovery_shadow_diffs
                    WHERE machine_name = :machine_name
                    ORDER BY recorded_at DESC
                    LIMIT :limit
                    """
                ),
                {"machine_name": machine_name, "limit": max(0, limit)},
            ).mappings()
            result = rows.all()
        return [
            ShadowDiff(
                machine_name=row["machine_name"],
                source_state=row["source_state"],
                trigger=row["trigger"],
                active_success=bool(row["active_success"]),
                active_target_state=row["active_target_state"],
                candidate_success=bool(row["candidate_success"]),
                candidate_target_state=row["candidate_target_state"],
                differs=bool(row["differs"]),
                reason=row["reason"],
                metadata=json.loads(row["metadata_json"] or "{}"),
                recorded_at=_dt_parse(row["recorded_at"]),
            )
            for row in result
        ]
