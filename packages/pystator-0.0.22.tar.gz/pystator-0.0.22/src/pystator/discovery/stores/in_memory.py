"""In-memory discovery store implementation."""

from __future__ import annotations

from collections import defaultdict
from typing import Any

from pystator.discovery.models import (
    CandidateMachineVersion,
    InferredEdge,
    ObservedStateEvent,
    ShadowDiff,
)


class InMemoryDiscoveryStore:
    """Single in-memory store implementing all discovery protocols."""

    def __init__(self) -> None:
        self._observations: dict[str, list[ObservedStateEvent]] = defaultdict(list)
        self._dedupe: set[tuple[str, str, str, str | None, str]] = set()
        self._edges: dict[str, list[InferredEdge]] = defaultdict(list)
        self._candidates: dict[str, list[CandidateMachineVersion]] = defaultdict(list)
        self._shadow: dict[str, list[ShadowDiff]] = defaultdict(list)

    def add_observation(self, event: ObservedStateEvent) -> bool:
        key = (
            event.entity_id,
            event.state,
            event.observed_at.isoformat(),
            event.source_event_id,
            event.source,
        )
        if key in self._dedupe:
            return False
        self._dedupe.add(key)
        machine_name = str(event.metadata.get("machine_name", "default"))
        self._observations[machine_name].append(event)
        return True

    def list_observations(
        self, machine_name: str, entity_id: str | None = None
    ) -> list[ObservedStateEvent]:
        items = self._observations.get(machine_name, [])
        if entity_id is None:
            return list(items)
        return [ev for ev in items if ev.entity_id == entity_id]

    def upsert_edges(self, machine_name: str, edges: list[InferredEdge]) -> None:
        self._edges[machine_name] = list(edges)

    def list_edges(self, machine_name: str) -> list[InferredEdge]:
        return list(self._edges.get(machine_name, []))

    def save_candidate(
        self, candidate: CandidateMachineVersion
    ) -> CandidateMachineVersion:
        existing = self._candidates[candidate.machine_name]
        for idx, item in enumerate(existing):
            if item.version == candidate.version:
                existing[idx] = candidate
                return candidate
        existing.append(candidate)
        existing.sort(key=lambda c: c.created_at)
        return candidate

    def get_candidate(
        self, machine_name: str, version: str
    ) -> CandidateMachineVersion | None:
        for c in self._candidates.get(machine_name, []):
            if c.version == version:
                return c
        return None

    def get_latest_candidate(self, machine_name: str) -> CandidateMachineVersion | None:
        items = self._candidates.get(machine_name, [])
        return items[-1] if items else None

    def list_candidates(self, machine_name: str) -> list[CandidateMachineVersion]:
        return list(self._candidates.get(machine_name, []))

    def record_shadow_diff(self, diff: ShadowDiff) -> None:
        self._shadow[diff.machine_name].append(diff)

    def list_shadow_diffs(
        self, machine_name: str, limit: int = 100
    ) -> list[ShadowDiff]:
        items = self._shadow.get(machine_name, [])
        if limit <= 0:
            return []
        return list(items[-limit:])

    def as_dict(self) -> dict[str, Any]:
        return {
            "observations": {k: len(v) for k, v in self._observations.items()},
            "edges": {k: len(v) for k, v in self._edges.items()},
            "candidates": {k: len(v) for k, v in self._candidates.items()},
            "shadow": {k: len(v) for k, v in self._shadow.items()},
        }
