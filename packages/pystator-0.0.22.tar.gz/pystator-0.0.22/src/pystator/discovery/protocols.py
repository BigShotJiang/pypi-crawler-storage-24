"""Protocols for discovery persistence and querying."""

from __future__ import annotations

from typing import Protocol, runtime_checkable

from pystator.discovery.models import (
    CandidateMachineVersion,
    InferredEdge,
    ObservedStateEvent,
    ShadowDiff,
)


@runtime_checkable
class ObservationStore(Protocol):
    def add_observation(self, event: ObservedStateEvent) -> bool: ...

    def list_observations(
        self, machine_name: str, entity_id: str | None = None
    ) -> list[ObservedStateEvent]: ...


@runtime_checkable
class InferenceStore(Protocol):
    def upsert_edges(self, machine_name: str, edges: list[InferredEdge]) -> None: ...

    def list_edges(self, machine_name: str) -> list[InferredEdge]: ...


@runtime_checkable
class CandidateStore(Protocol):
    def save_candidate(
        self, candidate: CandidateMachineVersion
    ) -> CandidateMachineVersion: ...

    def get_candidate(
        self, machine_name: str, version: str
    ) -> CandidateMachineVersion | None: ...

    def get_latest_candidate(
        self, machine_name: str
    ) -> CandidateMachineVersion | None: ...

    def list_candidates(self, machine_name: str) -> list[CandidateMachineVersion]: ...


@runtime_checkable
class ShadowResultStore(Protocol):
    def record_shadow_diff(self, diff: ShadowDiff) -> None: ...

    def list_shadow_diffs(
        self, machine_name: str, limit: int = 100
    ) -> list[ShadowDiff]: ...
