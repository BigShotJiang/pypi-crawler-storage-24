"""Stateless inference engine for observed-state machine discovery."""

from __future__ import annotations

import re
from collections import defaultdict
from dataclasses import dataclass
from datetime import datetime
from typing import Any

from pystator.discovery.models import (
    CandidateMachineVersion,
    InferredEdge,
    ObservedStateEvent,
    ShadowDiff,
)
from pystator.discovery.protocols import (
    CandidateStore,
    InferenceStore,
    ObservationStore,
    ShadowResultStore,
)
from pystator.machine import StateMachine


@dataclass(frozen=True, slots=True)
class InferenceThresholds:
    min_edge_count: int = 2
    min_confidence: float = 0.5


class InferenceEngine:
    """Primary discovery API: ingest, infer, and shadow-compare."""

    def __init__(
        self,
        observation_store: ObservationStore,
        inference_store: InferenceStore,
        candidate_store: CandidateStore,
        shadow_store: ShadowResultStore,
        thresholds: InferenceThresholds | None = None,
    ) -> None:
        self._observations = observation_store
        self._inference = inference_store
        self._candidates = candidate_store
        self._shadow = shadow_store
        self._thresholds = thresholds or InferenceThresholds()

    def record_observation(self, machine_name: str, event: ObservedStateEvent) -> bool:
        _ = machine_name
        return self._observations.add_observation(event)

    def build_candidate(
        self, machine_name: str, version: str | None = None
    ) -> CandidateMachineVersion:
        observations = self._observations.list_observations(machine_name)
        edges = self._infer_edges(observations)
        self._inference.upsert_edges(machine_name, edges)
        selected = [
            e
            for e in edges
            if e.count >= self._thresholds.min_edge_count
            and e.confidence >= self._thresholds.min_confidence
        ]
        config = self._build_machine_config(machine_name, selected)
        candidate = CandidateMachineVersion(
            machine_name=machine_name,
            version=version or self._next_version(machine_name),
            status="candidate",
            config=config,
            metadata={
                "edge_count": len(edges),
                "selected_edge_count": len(selected),
                "thresholds": {
                    "min_edge_count": self._thresholds.min_edge_count,
                    "min_confidence": self._thresholds.min_confidence,
                },
            },
        )
        return self._candidates.save_candidate(candidate)

    def run_shadow_compare(
        self,
        *,
        machine_name: str,
        active_config: dict[str, Any],
        source_state: str,
        trigger: str,
        context: dict[str, Any] | None = None,
        candidate_version: str | None = None,
    ) -> ShadowDiff | None:
        candidate = (
            self._candidates.get_candidate(machine_name, candidate_version)
            if candidate_version
            else self._candidates.get_latest_candidate(machine_name)
        )
        if candidate is None:
            return None
        active_result = StateMachine.from_dict(active_config).process(
            source_state, trigger, context or {}
        )
        candidate_result = StateMachine.from_dict(candidate.config).process(
            source_state, trigger, context or {}
        )
        differs = (active_result.success != candidate_result.success) or (
            active_result.target_state != candidate_result.target_state
        )
        reason: str | None = None
        if differs:
            if active_result.success != candidate_result.success:
                reason = "success_mismatch"
            else:
                reason = "target_state_mismatch"
        diff = ShadowDiff(
            machine_name=machine_name,
            source_state=source_state,
            trigger=trigger,
            active_success=active_result.success,
            active_target_state=active_result.target_state,
            candidate_success=candidate_result.success,
            candidate_target_state=candidate_result.target_state,
            differs=differs,
            reason=reason,
            metadata={"candidate_version": candidate.version},
        )
        self._shadow.record_shadow_diff(diff)
        return diff

    def get_latest_candidate(self, machine_name: str) -> CandidateMachineVersion | None:
        return self._candidates.get_latest_candidate(machine_name)

    def list_candidates(self, machine_name: str) -> list[CandidateMachineVersion]:
        """Return all saved candidates for *machine_name*, store-defined order."""
        return self._candidates.list_candidates(machine_name)

    def get_candidate(
        self, machine_name: str, version: str
    ) -> CandidateMachineVersion | None:
        """Return a specific candidate version, if present."""
        return self._candidates.get_candidate(machine_name, version)

    def list_edges(self, machine_name: str) -> list[InferredEdge]:
        return self._inference.list_edges(machine_name)

    def list_shadow_diffs(
        self, machine_name: str, limit: int = 100
    ) -> list[ShadowDiff]:
        return self._shadow.list_shadow_diffs(machine_name, limit=limit)

    @staticmethod
    def _infer_edges(observations: list[ObservedStateEvent]) -> list[InferredEdge]:
        by_entity: dict[str, list[ObservedStateEvent]] = defaultdict(list)
        for ev in observations:
            by_entity[ev.entity_id].append(ev)

        edge_counts: dict[tuple[str, str], int] = defaultdict(int)
        edge_entities: dict[tuple[str, str], set[str]] = defaultdict(set)
        edge_sources: dict[tuple[str, str], set[str]] = defaultdict(set)
        edge_last_seen: dict[tuple[str, str], datetime] = {}

        for entity_events in by_entity.values():
            ordered = sorted(
                entity_events,
                key=lambda x: (x.observed_at, x.ingest_seq, x.ingested_at),
            )
            for idx in range(len(ordered) - 1):
                src = ordered[idx]
                dst = ordered[idx + 1]
                key = (src.state, dst.state)
                edge_counts[key] += 1
                edge_entities[key].add(src.entity_id)
                edge_sources[key].add(src.source)
                edge_last_seen[key] = max(
                    edge_last_seen.get(key, src.observed_at), dst.observed_at
                )

        outgoing_totals: dict[str, int] = defaultdict(int)
        for (src, _), count in edge_counts.items():
            outgoing_totals[src] += count

        edges: list[InferredEdge] = []
        for (src, dst), count in edge_counts.items():
            total = outgoing_totals[src]
            confidence = (count / total) if total > 0 else 0.0
            edges.append(
                InferredEdge(
                    source_state=src,
                    destination_state=dst,
                    count=count,
                    unique_entities=len(edge_entities[(src, dst)]),
                    unique_sources=len(edge_sources[(src, dst)]),
                    confidence=confidence,
                    last_seen_at=edge_last_seen.get((src, dst)),
                )
            )
        edges.sort(key=lambda e: (e.source_state, e.destination_state))
        return edges

    @staticmethod
    def _build_machine_config(
        machine_name: str, edges: list[InferredEdge]
    ) -> dict[str, Any]:
        def normalize(name: str) -> str:
            return re.sub(r"[^a-z0-9_]+", "_", name.strip().lower()).strip("_")

        states = set()
        transitions: list[dict[str, Any]] = []
        for edge in edges:
            src = normalize(edge.source_state)
            dst = normalize(edge.destination_state)
            if not src or not dst:
                continue
            states.add(src)
            states.add(dst)
            trigger = f"to_{dst}"
            transitions.append(
                {
                    "trigger": trigger,
                    "source": src,
                    "dest": dst,
                    "meta": {
                        "inferred": True,
                        "count": edge.count,
                        "confidence": edge.confidence,
                    },
                }
            )
        sorted_states = sorted(states)
        initial_state = sorted_states[0] if sorted_states else "unknown"
        state_defs = [
            {
                "name": name,
                "type": "initial" if name == initial_state else "stable",
            }
            for name in sorted_states
        ]
        return {
            "meta": {
                "machine_name": machine_name,
                "version": "0.1.0",
                "source": "pystator.discovery",
            },
            "states": state_defs,
            "transitions": transitions,
        }

    def _next_version(self, machine_name: str) -> str:
        latest = self._candidates.get_latest_candidate(machine_name)
        if latest is None:
            return "0.1.0"
        parts = latest.version.split(".")
        if len(parts) != 3 or not all(part.isdigit() for part in parts):
            return "0.1.0"
        major, minor, patch = (int(p) for p in parts)
        return f"{major}.{minor}.{patch + 1}"
