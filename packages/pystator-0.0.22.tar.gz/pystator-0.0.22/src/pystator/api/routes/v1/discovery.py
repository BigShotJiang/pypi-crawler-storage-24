"""Routes for inferred FSM discovery (shadow mode)."""

from __future__ import annotations

from datetime import datetime
from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session

from pystator.api.dependencies import get_db_session, get_fsm_service
from pystator.api.models.requests import (
    DiscoveryBuildCandidateRequest,
    DiscoveryObserveRequest,
)
from pystator.api.models.responses import (
    DiscoveryCandidateListResponse,
    DiscoveryCandidateResponse,
    DiscoveryCandidateSummaryItem,
    DiscoveryObserveResponse,
    DiscoveryShadowDiffResponse,
    MachineResponse,
)
from pystator.api.services.discovery_promotion import promote_discovery_candidate
from pystator.api.services.discovery_service import DiscoveryService
from pystator.api.services.fsm_service import FSMService

router = APIRouter(prefix="/discovery")


@router.post(
    "/observations",
    response_model=DiscoveryObserveResponse,
    status_code=status.HTTP_200_OK,
    summary="Record observed state",
)
async def record_observation(
    request: DiscoveryObserveRequest,
) -> DiscoveryObserveResponse:
    observed_at = None
    if request.observed_at:
        try:
            observed_at = datetime.fromisoformat(request.observed_at)
        except ValueError as exc:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Invalid observed_at: {request.observed_at}",
            ) from exc
    service = DiscoveryService()
    accepted = service.record_observation(
        machine_name=request.machine_name,
        entity_id=request.entity_id,
        state=request.state,
        observed_at=observed_at,
        source=request.source,
        source_event_id=request.source_event_id,
        ingest_seq=request.ingest_seq,
        metadata=request.metadata,
    )
    return DiscoveryObserveResponse(accepted=accepted)


@router.post(
    "/candidates/build",
    response_model=DiscoveryCandidateResponse,
    status_code=status.HTTP_200_OK,
    summary="Build inferred candidate machine",
)
async def build_candidate(
    request: DiscoveryBuildCandidateRequest,
) -> DiscoveryCandidateResponse:
    service = DiscoveryService()
    payload = service.build_candidate(request.machine_name, version=request.version)
    return DiscoveryCandidateResponse.model_validate(payload)


@router.get(
    "/candidates/{machine_name}/latest",
    response_model=DiscoveryCandidateResponse,
    status_code=status.HTTP_200_OK,
    summary="Get latest inferred candidate machine",
)
async def get_latest_candidate(machine_name: str) -> DiscoveryCandidateResponse:
    service = DiscoveryService()
    payload = service.get_latest_candidate(machine_name)
    if payload is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"No candidate found for machine: {machine_name}",
        )
    if "edges" not in payload:
        payload["edges"] = []
    return DiscoveryCandidateResponse.model_validate(payload)


@router.get(
    "/candidates/{machine_name}",
    response_model=DiscoveryCandidateListResponse,
    status_code=status.HTTP_200_OK,
    summary="List inferred candidate versions",
)
async def list_candidates(machine_name: str) -> DiscoveryCandidateListResponse:
    service = DiscoveryService()
    rows = service.list_candidate_summaries(machine_name)
    return DiscoveryCandidateListResponse(
        machine_name=machine_name,
        candidates=[
            DiscoveryCandidateSummaryItem(
                machine_name=r["machine_name"],
                version=r["version"],
                status=r["status"],
                created_at=r["created_at"],
                metadata=r["metadata"],
            )
            for r in rows
        ],
    )


@router.get(
    "/candidates/{machine_name}/{candidate_version}",
    response_model=DiscoveryCandidateResponse,
    status_code=status.HTTP_200_OK,
    summary="Get inferred candidate by version",
)
async def get_candidate_by_version(
    machine_name: str, candidate_version: str
) -> DiscoveryCandidateResponse:
    service = DiscoveryService()
    payload = service.get_candidate_detail(machine_name, candidate_version)
    if payload is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=(f"No candidate {machine_name!r} version {candidate_version!r}"),
        )
    return DiscoveryCandidateResponse.model_validate(payload)


@router.post(
    "/candidates/{machine_name}/{candidate_version}/promote",
    response_model=MachineResponse,
    status_code=status.HTTP_200_OK,
    summary="Promote candidate to stored FSM machine",
    description=(
        "Validate candidate config and upsert a row in the machines table "
        "for the same name and version as in the candidate meta."
    ),
)
async def promote_candidate(
    machine_name: str,
    candidate_version: str,
    db: Session = Depends(get_db_session),
    fsm: Annotated[FSMService, Depends(get_fsm_service)] = None,
) -> MachineResponse:
    svc = fsm if fsm is not None else FSMService()
    discovery = DiscoveryService()
    return promote_discovery_candidate(
        db, discovery, svc, machine_name, candidate_version
    )


@router.get(
    "/shadow/{machine_name}",
    response_model=list[DiscoveryShadowDiffResponse],
    status_code=status.HTTP_200_OK,
    summary="List shadow-mode diffs",
)
async def list_shadow_diffs(
    machine_name: str,
    limit: int = Query(default=100, ge=1, le=500),
) -> list[DiscoveryShadowDiffResponse]:
    service = DiscoveryService()
    rows = service.list_shadow_diffs(machine_name, limit=limit)
    return [DiscoveryShadowDiffResponse.model_validate(item) for item in rows]
