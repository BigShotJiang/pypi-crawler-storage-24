"""DLQ connection test and statistics (PyCharter-aligned)."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from sqlalchemy import create_engine, text
from sqlalchemy.exc import SQLAlchemyError

from pystator.worker.dlq_postgres import validate_table_name


@dataclass(frozen=True, slots=True)
class DlqStats:
    """DLQ table statistics."""

    total_messages: int
    by_reason: dict[str, int | None] = field(default_factory=dict)
    by_stage: dict[str, int | None] = field(default_factory=dict)
    by_status: dict[str, int | None] = field(default_factory=dict)


def verify_dlq_connection(connection_string: str, table_name: str) -> tuple[bool, str]:
    """Verify database connectivity and that *table_name* exists."""
    try:
        validate_table_name(table_name)
    except ValueError as exc:
        return False, str(exc)
    try:
        engine = create_engine(connection_string, pool_pre_ping=True)
        with engine.connect() as conn:
            if engine.dialect.name == "postgresql":
                result = conn.execute(
                    text(
                        "SELECT EXISTS (SELECT FROM information_schema.tables "
                        "WHERE table_schema = 'public' AND table_name = :table_name)"
                    ),
                    {"table_name": table_name},
                )
                exists = result.scalar()
                if not exists:
                    return (
                        False,
                        f"Table '{table_name}' does not exist",
                    )
            elif engine.dialect.name == "sqlite":
                r = conn.execute(
                    text(
                        "SELECT name FROM sqlite_master "
                        "WHERE type='table' AND name=:table_name"
                    ),
                    {"table_name": table_name},
                )
                if r.first() is None:
                    return False, f"Table '{table_name}' does not exist"
            else:
                tq = f'"{table_name}"'
                conn.execute(text(f"SELECT 1 FROM {tq} LIMIT 1"))

        return (
            True,
            f"DLQ connection successful. Table '{table_name}' exists.",
        )
    except SQLAlchemyError as exc:
        return False, f"DLQ connection failed: {exc}"
    except Exception as exc:
        return False, f"Unexpected error: {exc}"


def _group_count(conn: Any, table_name: str, column: str) -> dict[str, int | None]:
    try:
        tq = f'"{table_name}"'
        result = conn.execute(
            text(f'SELECT "{column}", COUNT(*) AS c FROM {tq} GROUP BY "{column}"')
        )
        return {
            (str(row[0]) if row[0] is not None else "unknown"): row[1] for row in result
        }
    except Exception:
        return {}


def get_dlq_stats(connection_string: str, table_name: str) -> DlqStats:
    """Aggregate counts from a PyStator DLQ table (reason, stage, status columns)."""
    validate_table_name(table_name)  # raises ValueError if invalid
    engine = create_engine(connection_string, pool_pre_ping=True)
    tq = f'"{table_name}"'
    with engine.connect() as conn:
        total_result = conn.execute(text(f"SELECT COUNT(*) FROM {tq}"))
        total_messages = total_result.scalar() or 0
        by_reason = _group_count(conn, table_name, "reason")
        by_stage = _group_count(conn, table_name, "stage")
        by_status = _group_count(conn, table_name, "status")

    return DlqStats(
        total_messages=int(total_messages),
        by_reason=by_reason,
        by_stage=by_stage,
        by_status=by_status,
    )
