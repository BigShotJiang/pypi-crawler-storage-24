"""
FSM service for PyStator API.

Builds machines from config and processes events. Uses pass-through guards
so any config works without requiring guard implementations.
"""

from __future__ import annotations

from typing import Any

from pystator import GuardRegistry, StateMachine
from pystator.api.services.transition_outcome import outcome_from_transition_result
from pystator.errors import ConfigurationError


def _collect_guard_names(config: dict[str, Any]) -> set[str]:
    """Collect all named guard names referenced in transitions.

    Only string guard names are collected; dict guards (inline expr or
    declarative check) are handled by the evaluator and must not be
    added to the set (dicts are unhashable).
    """
    names: set[str] = set()
    for trans in config.get("transitions", []):
        guards = trans.get("guards", [])
        if isinstance(guards, str):
            names.add(guards)
        else:
            for g in guards if isinstance(guards, list) else []:
                if isinstance(g, str):
                    names.add(g)
    return names


def _build_pass_through_guards(guard_names: set[str]) -> GuardRegistry:
    """Build a registry that passes all listed guard names (no-op for API)."""
    registry = GuardRegistry()
    for name in guard_names:
        registry.register(name, lambda ctx: True)
    return registry


def build_machine_from_config(config: dict[str, Any]) -> StateMachine:
    """
    Build a StateMachine from config with pass-through guards.

    All guards referenced in transitions are registered as no-op (always pass)
    so the API can compute transitions without requiring guard implementations.
    """
    guard_names = _collect_guard_names(config)
    guards = _build_pass_through_guards(guard_names)
    machine = StateMachine.from_dict(config)
    machine.bind_guards(guards)
    return machine


def validate_config(
    config: dict[str, Any],
) -> tuple[bool, list[str], dict[str, Any] | None]:
    """
    Validate FSM config. Returns (valid, errors, info).

    If valid, info contains machine_name, version, state_names, trigger_names.
    """
    errors: list[str] = []
    try:
        machine = StateMachine.from_dict(config)
        info = {
            "machine_name": machine.name,
            "version": machine.version,
            "state_names": machine.state_names,
            "trigger_names": machine.trigger_names,
            "terminal_states": machine.terminal_states,
        }
        return True, [], info
    except ConfigurationError as e:
        errors.append(str(e))
        if e.context:
            for k, v in e.context.items():
                errors.append(f"  {k}: {v}")
        return False, errors, None
    except Exception as e:
        errors.append(str(e))
        return False, errors, None


class FSMService:
    """Service for building machines and processing events."""

    def process(
        self,
        config: dict[str, Any],
        current_state: str,
        trigger: str,
        context: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """
        Build machine from config and process one event.

        Returns a dict suitable for JSON: success, source_state, target_state,
        trigger, actions, error (:class:`FsmOutcomeError` shape), error_message,
        metadata.
        """
        machine = build_machine_from_config(config)
        ctx = context or {}
        result = machine.process(current_state, trigger, ctx)
        return outcome_from_transition_result(result)

    def validate(
        self, config: dict[str, Any]
    ) -> tuple[bool, list[str], dict[str, Any] | None]:
        """Validate config. Returns (valid, errors, info)."""
        return validate_config(config)
