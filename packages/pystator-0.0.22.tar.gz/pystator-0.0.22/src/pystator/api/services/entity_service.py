"""Entity persistence helpers for the full-service API (DB + transition history)."""

from __future__ import annotations

import base64
import json
import re
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any

from sqlalchemy import case, func
from sqlalchemy.orm import Session

from pystator.api.constants import (
    ENTITY_CREATED_TRIGGER,
    ENTITY_STATUS_ACTIVE,
    ENTITY_STATUS_ARCHIVED,
    ENTITY_STATUS_DELETED,
)
from pystator.db.models import EntityStateModel, TransitionHistoryModel

# ---------------------------------------------------------------------------
# Label validation constants
# ---------------------------------------------------------------------------

LABEL_KEY_PATTERN = re.compile(r"^[a-z0-9][a-z0-9_.]{0,62}$")
LABEL_VALUE_MAX_LENGTH = 255

# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------


class EntityAlreadyExistsError(Exception):
    """Raised when entity_id already has a row in entity_states."""

    def __init__(self, entity_id: str) -> None:
        self.entity_id = entity_id
        super().__init__(entity_id)


class NoInitialStateForMachineError(Exception):
    """Raised when machine config has no state with type initial."""

    def __init__(self, machine_name: str) -> None:
        self.machine_name = machine_name
        super().__init__(machine_name)


class EntityNotFoundError(Exception):
    """Raised when entity_id does not exist in entity_states."""

    def __init__(self, entity_id: str) -> None:
        self.entity_id = entity_id
        super().__init__(entity_id)


class EntityNotActiveError(Exception):
    """Raised when operation requires active entity but entity is archived/deleted."""

    def __init__(self, entity_id: str, status: str) -> None:
        self.entity_id = entity_id
        self.status = status
        super().__init__(f"{entity_id} is {status}")


def initial_state_from_config(machine_config: dict[str, Any]) -> str | None:
    """Return the name of the state marked ``type: initial`` in config, if any."""
    for state in machine_config.get("states", []):
        if state.get("type") == "initial":
            return state.get("name")
    return None


def record_transition(
    session: Session,
    entity_id: str,
    machine_name: str | None,
    source_state: str,
    target_state: str | None,
    trigger: str,
    success: bool,
    actions: list[str],
    error_message: str | None = None,
    context: dict | None = None,
    duration_ms: int | None = None,
) -> TransitionHistoryModel:
    """Append a transition history row (caller commits)."""
    history = TransitionHistoryModel(
        entity_id=entity_id,
        machine_name=machine_name,
        source_state=source_state,
        target_state=target_state,
        trigger=trigger,
        success=success,
        actions_executed=actions if actions else None,
        error_message=error_message,
        context_snapshot=context,
        duration_ms=duration_ms,
    )
    session.add(history)
    session.flush()
    return history


def create_entity_at_initial(
    session: Session,
    *,
    entity_id: str,
    machine_name: str,
    machine_config: dict[str, Any],
    context: dict[str, Any] | None = None,
    duration_ms: int | None = None,
) -> tuple[EntityStateModel, TransitionHistoryModel]:
    """Insert entity_states row at initial state and record bootstrap history.

    Raises:
        EntityAlreadyExistsError: If *entity_id* already exists.
        NoInitialStateForMachineError: If config has no initial state.
    """
    existing = (
        session.query(EntityStateModel)
        .filter(EntityStateModel.entity_id == entity_id)
        .first()
    )
    if existing is not None:
        raise EntityAlreadyExistsError(entity_id)

    initial = initial_state_from_config(machine_config)
    if not initial:
        raise NoInitialStateForMachineError(machine_name)

    ctx = dict(context or {})
    entity = EntityStateModel(
        entity_id=entity_id,
        machine_name=machine_name,
        current_state=initial,
        context_json=ctx if ctx else None,
    )
    session.add(entity)

    history = record_transition(
        session=session,
        entity_id=entity_id,
        machine_name=machine_name,
        source_state=initial,
        target_state=initial,
        trigger=ENTITY_CREATED_TRIGGER,
        success=True,
        actions=[],
        error_message=None,
        context=ctx if ctx else None,
        duration_ms=duration_ms,
    )
    return entity, history


# ---------------------------------------------------------------------------
# Entity lifecycle (soft delete, archive, restore, purge)
# ---------------------------------------------------------------------------


def _load_entity(session: Session, entity_id: str) -> EntityStateModel:
    """Load entity or raise EntityNotFoundError."""
    entity = (
        session.query(EntityStateModel)
        .filter(EntityStateModel.entity_id == entity_id)
        .first()
    )
    if entity is None:
        raise EntityNotFoundError(entity_id)
    return entity


def get_active_entity(session: Session, entity_id: str) -> EntityStateModel:
    """Load entity that is in 'active' status.

    Raises:
        EntityNotFoundError: If entity does not exist.
        EntityNotActiveError: If entity is archived or deleted.
    """
    entity = _load_entity(session, entity_id)
    if entity.status != ENTITY_STATUS_ACTIVE:
        raise EntityNotActiveError(entity_id, entity.status)
    return entity


def soft_delete_entity(session: Session, entity_id: str) -> EntityStateModel:
    """Set entity status to deleted with deleted_at timestamp (caller commits).

    Raises:
        EntityNotFoundError: If entity does not exist.
    """
    entity = _load_entity(session, entity_id)
    entity.status = ENTITY_STATUS_DELETED
    entity.deleted_at = datetime.now(UTC)
    session.flush()
    return entity


def archive_entity(session: Session, entity_id: str) -> EntityStateModel:
    """Set entity status to archived with archived_at timestamp (caller commits).

    Raises:
        EntityNotFoundError: If entity does not exist.
        EntityNotActiveError: If entity is already deleted.
    """
    entity = _load_entity(session, entity_id)
    if entity.status == ENTITY_STATUS_DELETED:
        raise EntityNotActiveError(entity_id, entity.status)
    entity.status = ENTITY_STATUS_ARCHIVED
    entity.archived_at = datetime.now(UTC)
    session.flush()
    return entity


def restore_entity(session: Session, entity_id: str) -> EntityStateModel:
    """Restore entity to active status, clearing deleted_at/archived_at (caller commits).

    Raises:
        EntityNotFoundError: If entity does not exist.
    """
    entity = _load_entity(session, entity_id)
    entity.status = ENTITY_STATUS_ACTIVE
    entity.deleted_at = None
    entity.archived_at = None
    session.flush()
    return entity


def purge_entity(session: Session, entity_id: str) -> None:
    """Hard-delete entity from database (caller commits).

    Raises:
        EntityNotFoundError: If entity does not exist.
    """
    entity = _load_entity(session, entity_id)
    session.delete(entity)
    session.flush()


# ---------------------------------------------------------------------------
# Labels
# ---------------------------------------------------------------------------


def validate_labels(labels: dict[str, str]) -> None:
    """Validate label keys and values.

    Raises:
        ValueError: If any key or value violates constraints.
    """
    for key, value in labels.items():
        if not LABEL_KEY_PATTERN.match(key):
            raise ValueError(
                f"Label key '{key}' must be lowercase alphanumeric + dots/underscores, "
                f"start with alphanumeric, max 63 chars."
            )
        if len(value) > LABEL_VALUE_MAX_LENGTH:
            raise ValueError(
                f"Label value for key '{key}' exceeds {LABEL_VALUE_MAX_LENGTH} chars."
            )


def get_entity_labels(session: Session, entity_id: str) -> dict[str, str]:
    """Get all labels for an entity."""
    entity = _load_entity(session, entity_id)
    return dict(entity.labels_json or {})


def set_entity_labels(
    session: Session, entity_id: str, labels: dict[str, str]
) -> EntityStateModel:
    """Replace all labels (caller commits)."""
    validate_labels(labels)
    entity = _load_entity(session, entity_id)
    entity.labels_json = dict(labels)
    session.flush()
    return entity


def merge_entity_labels(
    session: Session, entity_id: str, labels: dict[str, str]
) -> EntityStateModel:
    """Merge labels without removing existing (caller commits)."""
    validate_labels(labels)
    entity = _load_entity(session, entity_id)
    existing = dict(entity.labels_json or {})
    existing.update(labels)
    entity.labels_json = existing
    session.flush()
    return entity


def delete_entity_label(session: Session, entity_id: str, key: str) -> EntityStateModel:
    """Remove a single label by key (caller commits)."""
    entity = _load_entity(session, entity_id)
    existing = dict(entity.labels_json or {})
    existing.pop(key, None)
    entity.labels_json = existing
    session.flush()
    return entity


# ---------------------------------------------------------------------------
# Enhanced querying
# ---------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class EntityQueryFilters:
    """Aggregated entity query filters."""

    machine_name: str | None = None
    state: str | None = None
    is_terminal: bool | None = None
    status: str = "active"
    include_archived: bool = False
    include_deleted: bool = False
    created_after: datetime | None = None
    created_before: datetime | None = None
    updated_after: datetime | None = None
    updated_before: datetime | None = None
    labels: dict[str, str] | None = None
    sort_by: str = "created_at"
    sort_order: str = "desc"
    limit: int = 50
    offset: int = 0
    cursor: str | None = None
    page_size: int | None = None


def query_entities(
    session: Session,
    filters: EntityQueryFilters,
) -> tuple[list[EntityStateModel], int]:
    """Query entities with dynamic filtering.

    Returns:
        Tuple of (entities list, total count matching filters).
    """
    query = session.query(EntityStateModel)

    # Status filtering
    status_filter = [ENTITY_STATUS_ACTIVE]
    if filters.include_archived:
        status_filter.append(ENTITY_STATUS_ARCHIVED)
    if filters.include_deleted:
        status_filter.append(ENTITY_STATUS_DELETED)

    if filters.status and filters.status != ENTITY_STATUS_ACTIVE:
        query = query.filter(EntityStateModel.status == filters.status)
    else:
        query = query.filter(EntityStateModel.status.in_(status_filter))

    if filters.machine_name:
        query = query.filter(EntityStateModel.machine_name == filters.machine_name)
    if filters.state:
        query = query.filter(
            func.lower(EntityStateModel.current_state) == filters.state.lower()
        )
    if filters.is_terminal is not None:
        if filters.is_terminal:
            query = query.filter(EntityStateModel.is_terminal.is_(True))
        else:
            # NULL is treated as non-terminal (default when not explicitly set)
            query = query.filter(
                EntityStateModel.is_terminal.isnot(True),
            )
    if filters.created_after:
        query = query.filter(EntityStateModel.created_at >= filters.created_after)
    if filters.created_before:
        query = query.filter(EntityStateModel.created_at <= filters.created_before)
    if filters.updated_after:
        query = query.filter(EntityStateModel.updated_at >= filters.updated_after)
    if filters.updated_before:
        query = query.filter(EntityStateModel.updated_at <= filters.updated_before)

    # Labels filtering (Python-side for SQLite compatibility)
    if filters.labels:
        for key, value in filters.labels.items():
            query = query.filter(
                EntityStateModel.labels_json.isnot(None),
            )
            break  # At least one label filter — fetch and filter in Python below

    total = query.count()

    # Sorting
    sort_column = getattr(
        EntityStateModel, filters.sort_by, EntityStateModel.created_at
    )
    if filters.sort_order == "asc":
        query = query.order_by(sort_column.asc(), EntityStateModel.entity_id.asc())
    else:
        query = query.order_by(sort_column.desc(), EntityStateModel.entity_id.asc())

    # Cursor-based pagination
    effective_limit = filters.page_size or filters.limit
    if filters.cursor:
        decoded = decode_cursor(filters.cursor)
        cursor_ts = datetime.fromisoformat(decoded["created_at"])
        cursor_id = decoded.get("id", "")
        # Composite keyset: (created_at, entity_id) for stable ordering
        from sqlalchemy import and_, or_

        query = query.filter(
            or_(
                EntityStateModel.created_at < cursor_ts,
                and_(
                    EntityStateModel.created_at == cursor_ts,
                    EntityStateModel.entity_id > cursor_id,
                ),
            )
        )
        entities = query.limit(effective_limit + 1).all()
    elif filters.page_size:
        # Fetch one extra to detect next page
        entities = query.offset(filters.offset).limit(effective_limit + 1).all()
    else:
        entities = query.offset(filters.offset).limit(effective_limit).all()

    # Python-side label filtering (for cross-DB compatibility)
    if filters.labels:
        filtered = []
        for ent in entities:
            ent_labels = ent.labels_json or {}
            if all(ent_labels.get(k) == v for k, v in filters.labels.items()):
                filtered.append(ent)
        entities = filtered

    return entities, total


# ---------------------------------------------------------------------------
# History management
# ---------------------------------------------------------------------------


def get_history_stats(session: Session, entity_id: str) -> dict[str, Any]:
    """Compute history statistics for an entity."""
    row = (
        session.query(
            func.count(TransitionHistoryModel.id).label("total"),
            func.min(TransitionHistoryModel.created_at).label("first_at"),
            func.max(TransitionHistoryModel.created_at).label("last_at"),
            func.sum(
                case(
                    (TransitionHistoryModel.success.is_(True), 1),
                    else_=0,
                )
            ).label("success_count"),
            func.sum(
                case(
                    (TransitionHistoryModel.success.is_(False), 1),
                    else_=0,
                )
            ).label("failure_count"),
        )
        .filter(TransitionHistoryModel.entity_id == entity_id)
        .first()
    )
    return {
        "total_transitions": row.total or 0,
        "first_at": row.first_at,
        "last_at": row.last_at,
        "success_count": row.success_count or 0,
        "failure_count": row.failure_count or 0,
    }


def purge_history_before(
    session: Session, entity_id: str, before: datetime
) -> tuple[int, int]:
    """Delete history records older than *before*. Returns (deleted_count, remaining)."""
    deleted = (
        session.query(TransitionHistoryModel)
        .filter(
            TransitionHistoryModel.entity_id == entity_id,
            TransitionHistoryModel.created_at < before,
        )
        .delete(synchronize_session="fetch")
    )
    remaining = (
        session.query(TransitionHistoryModel)
        .filter(TransitionHistoryModel.entity_id == entity_id)
        .count()
    )
    session.flush()
    return deleted, remaining


# ---------------------------------------------------------------------------
# Export / Import (snapshot)
# ---------------------------------------------------------------------------


def export_entity_snapshot(session: Session, entity_id: str) -> dict[str, Any]:
    """Build full entity snapshot including state and history."""
    entity = _load_entity(session, entity_id)
    history_rows = (
        session.query(TransitionHistoryModel)
        .filter(TransitionHistoryModel.entity_id == entity_id)
        .order_by(TransitionHistoryModel.created_at.asc())
        .all()
    )
    history = [
        {
            "source_state": h.source_state,
            "target_state": h.target_state,
            "trigger": h.trigger,
            "success": h.success,
            "error_message": h.error_message,
            "actions_executed": h.actions_executed,
            "created_at": h.created_at.isoformat() if h.created_at else None,
            "duration_ms": h.duration_ms,
        }
        for h in history_rows
    ]
    return {
        "entity_id": entity.entity_id,
        "machine_name": entity.machine_name,
        "current_state": entity.current_state,
        "context": entity.context_json or {},
        "status": entity.status or ENTITY_STATUS_ACTIVE,
        "labels": entity.labels_json or {},
        "history": history,
        "exported_at": datetime.now(UTC).isoformat(),
    }


def import_entity_from_snapshot(
    session: Session,
    snapshot: dict[str, Any],
    *,
    overwrite: bool = False,
) -> tuple[EntityStateModel, int]:
    """Import entity + history from snapshot. Returns (entity, history_count).

    Raises:
        EntityAlreadyExistsError: If entity exists and overwrite is False.
    """
    entity_id = snapshot["entity_id"]
    existing = (
        session.query(EntityStateModel)
        .filter(EntityStateModel.entity_id == entity_id)
        .first()
    )
    if existing is not None:
        if not overwrite:
            raise EntityAlreadyExistsError(entity_id)
        # Remove existing entity + history
        session.query(TransitionHistoryModel).filter(
            TransitionHistoryModel.entity_id == entity_id,
        ).delete(synchronize_session="fetch")
        session.delete(existing)
        session.flush()

    entity = EntityStateModel(
        entity_id=entity_id,
        machine_name=snapshot.get("machine_name"),
        current_state=snapshot["current_state"],
        context_json=snapshot.get("context") or None,
        status=snapshot.get("status", ENTITY_STATUS_ACTIVE),
        labels_json=snapshot.get("labels") or None,
    )
    session.add(entity)

    history_count = 0
    for item in snapshot.get("history", []):
        created_at = item.get("created_at")
        if isinstance(created_at, str):
            created_at = datetime.fromisoformat(created_at)
        history_row = TransitionHistoryModel(
            entity_id=entity_id,
            machine_name=snapshot.get("machine_name"),
            source_state=item.get("source_state", ""),
            target_state=item.get("target_state"),
            trigger=item.get("trigger", ""),
            success=item.get("success", True),
            error_message=item.get("error_message"),
            actions_executed=item.get("actions_executed"),
            created_at=created_at,
            duration_ms=item.get("duration_ms"),
        )
        session.add(history_row)
        history_count += 1

    session.flush()
    return entity, history_count


# ---------------------------------------------------------------------------
# Cursor-based pagination
# ---------------------------------------------------------------------------


def encode_cursor(entity_id: str, created_at: datetime) -> str:
    """Encode cursor as base64 JSON."""
    payload = {"id": entity_id, "created_at": created_at.isoformat()}
    return base64.urlsafe_b64encode(json.dumps(payload).encode()).decode()


def decode_cursor(cursor: str) -> dict[str, Any]:
    """Decode cursor from base64 JSON."""
    return json.loads(base64.urlsafe_b64decode(cursor.encode()).decode())


__all__ = [
    "EntityAlreadyExistsError",
    "EntityNotActiveError",
    "EntityNotFoundError",
    "EntityQueryFilters",
    "NoInitialStateForMachineError",
    "archive_entity",
    "create_entity_at_initial",
    "decode_cursor",
    "delete_entity_label",
    "encode_cursor",
    "export_entity_snapshot",
    "get_active_entity",
    "get_entity_labels",
    "get_history_stats",
    "import_entity_from_snapshot",
    "initial_state_from_config",
    "merge_entity_labels",
    "purge_entity",
    "purge_history_before",
    "query_entities",
    "record_transition",
    "restore_entity",
    "set_entity_labels",
    "soft_delete_entity",
    "validate_labels",
]
