"""Per-entity metrics computation for health, errors, performance, and behavior."""

from __future__ import annotations

import logging
from collections import Counter, defaultdict
from datetime import UTC, datetime, timedelta
from typing import Any

from sqlalchemy import case, func
from sqlalchemy.orm import Session

from pystator.api.services.analytics_service import _compute_percentiles
from pystator.db.models import EntityStateModel, TransitionHistoryModel

logger = logging.getLogger(__name__)

_RECENT_WINDOW = 20  # number of recent transitions for failure rate
_TOP_ERROR_PATTERNS = 5
_VELOCITY_POINTS = 12
_STUCK_MULTIPLIER = 3.0  # current dwell > Nx avg → stuck


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _format_staleness(seconds: int | None) -> str:
    """Format seconds into human-readable staleness label.

    Args:
        seconds: Seconds since last transition, or None if no activity.

    Returns:
        Human-readable label such as "just now", "5m ago", "2h ago".
    """
    if seconds is None:
        return "No activity"
    if seconds < 60:
        return "just now"
    if seconds < 3600:
        return f"{seconds // 60}m ago"
    if seconds < 86400:
        return f"{seconds // 3600}h ago"
    return f"{seconds // 86400}d ago"


def _compute_health_score(
    recent_failure_rate: float,
    is_terminal: bool,
    staleness_seconds: int | None,
    avg_transition_interval_s: float | None,
) -> tuple[int, str]:
    """Compute composite health score 0-100 and status label.

    Args:
        recent_failure_rate: Failure rate of last N transitions (0.0-1.0).
        is_terminal: Whether entity is in a terminal state.
        staleness_seconds: Seconds since last transition.
        avg_transition_interval_s: Average seconds between transitions.

    Returns:
        Tuple of (score, status) where status is "healthy"/"warning"/"critical".
    """
    score = 0

    # Failure component (0-40 points): lower failure rate = more points
    failure_points = max(0, 40 - int(recent_failure_rate * 80))
    score += failure_points

    # Activity component (0-40 points)
    if is_terminal:
        # Terminal entities are "done" — full activity credit
        score += 40
    elif staleness_seconds is None:
        # No transitions at all — neutral
        score += 20
    elif avg_transition_interval_s and avg_transition_interval_s > 0:
        if staleness_seconds <= avg_transition_interval_s * 2:
            score += 40  # Active
        elif staleness_seconds <= avg_transition_interval_s * 5:
            score += 20  # Somewhat stale
        # else: 0 points — very stale
    else:
        score += 20  # Can't determine, neutral

    # Completion component (0-20 points)
    if is_terminal:
        score += 20  # Job done
    elif staleness_seconds is not None and staleness_seconds < 300:
        score += 20  # Recently active
    elif staleness_seconds is not None and staleness_seconds < 3600:
        score += 10  # Active within the hour
    # else: 0 points

    score = max(0, min(100, score))

    if score >= 80:
        status = "healthy"
    elif score >= 50:
        status = "warning"
    else:
        status = "critical"

    return score, status


# ---------------------------------------------------------------------------
# Main computation
# ---------------------------------------------------------------------------


def compute_entity_metrics(
    session: Session,
    entity_id: str,
    window_hours: int = 24,
) -> dict[str, Any]:
    """Compute comprehensive per-entity metrics.

    Args:
        session: SQLAlchemy session.
        entity_id: Entity identifier.
        window_hours: Trailing window for fleet comparison.

    Returns:
        Dict matching EntityMetricsResponse fields.
    """
    now = datetime.now(UTC)

    # Query 1: Entity state
    entity = (
        session.query(EntityStateModel)
        .filter(EntityStateModel.entity_id == entity_id)
        .first()
    )
    machine_name = entity.machine_name if entity else None
    is_terminal = bool(entity.is_terminal) if entity else False

    # Query 2: Full transition history (ordered chronologically)
    history = (
        session.query(TransitionHistoryModel)
        .filter(TransitionHistoryModel.entity_id == entity_id)
        .order_by(TransitionHistoryModel.created_at.asc())
        .all()
    )

    # --- P0: Recent failure rate ---
    recent = history[-_RECENT_WINDOW:] if history else []
    recent_failures = sum(1 for h in recent if not h.success)
    recent_failure_rate = recent_failures / len(recent) if recent else 0.0

    # --- P0: Error patterns ---
    error_counter: Counter[tuple[str | None, str, str]] = Counter()
    error_last: dict[tuple[str | None, str, str], datetime] = {}
    for h in history:
        if not h.success:
            key = (h.error_type, h.trigger, h.source_state)
            error_counter[key] += 1
            if h.created_at:
                existing = error_last.get(key)
                ts = _ensure_aware(h.created_at)
                if existing is None or ts > existing:
                    error_last[key] = ts

    top_patterns = error_counter.most_common(_TOP_ERROR_PATTERNS)
    error_patterns = [
        {
            "error_type": key[0],
            "trigger": key[1],
            "source_state": key[2],
            "count": count,
            "last_occurred": error_last[key].isoformat() if key in error_last else "",
        }
        for key, count in top_patterns
    ]

    # --- P0: Staleness ---
    staleness_seconds: int | None = None
    if history:
        last_ts = _ensure_aware(history[-1].created_at)
        staleness_seconds = int((now - last_ts).total_seconds())

    staleness_label = _format_staleness(staleness_seconds)

    # --- P1: Latency percentiles ---
    durations = [h.duration_ms for h in history if h.duration_ms is not None]
    percentiles = _compute_percentiles(durations, [50, 75, 95, 99])

    # --- P1: Dwell by state ---
    dwell_by_state = _compute_dwell_by_state(history, now)

    # --- P1: Stuck detection ---
    is_stuck = False
    stuck_state: str | None = None
    stuck_current_ms: int | None = None
    stuck_avg_ms: int | None = None

    if entity and not is_terminal and history:
        current_state = entity.current_state
        last_ts = _ensure_aware(history[-1].created_at)
        current_dwell_ms = int((now - last_ts).total_seconds() * 1000)

        # Find avg dwell for current state
        for item in dwell_by_state:
            if item["state"] == current_state and item["avg_ms"] > 0:
                if current_dwell_ms > item["avg_ms"] * _STUCK_MULTIPLIER:
                    is_stuck = True
                    stuck_state = current_state
                    stuck_current_ms = current_dwell_ms
                    stuck_avg_ms = item["avg_ms"]
                break

    # --- P0: Health score ---
    avg_interval_s: float | None = None
    if len(history) >= 2:
        first_ts = _ensure_aware(history[0].created_at)
        last_ts = _ensure_aware(history[-1].created_at)
        span = (last_ts - first_ts).total_seconds()
        avg_interval_s = span / (len(history) - 1) if span > 0 else None

    health_score, health_status = _compute_health_score(
        recent_failure_rate, is_terminal, staleness_seconds, avg_interval_s
    )

    # --- P2: State revisits ---
    state_visits: Counter[str] = Counter()
    for h in history:
        if h.success and h.target_state:
            state_visits[h.target_state] += 1
    state_revisits = {s: c for s, c in state_visits.items() if c > 1}
    has_cycles = bool(state_revisits)

    # --- P2: Fleet comparison ---
    fleet_comparison = _compute_fleet_comparison(
        session,
        entity_id,
        machine_name,
        recent_failure_rate,
        durations,
        window_hours,
        now,
    )

    # --- P3: Velocity sparkline ---
    velocity_points = [
        {
            "timestamp": _ensure_aware(h.created_at).isoformat(),
            "duration_ms": h.duration_ms,
        }
        for h in history[-_VELOCITY_POINTS:]
        if h.success and h.duration_ms is not None
    ]

    return {
        "entity_id": entity_id,
        "machine_name": machine_name,
        "health_score": health_score,
        "health_status": health_status,
        "staleness_seconds": staleness_seconds,
        "staleness_label": staleness_label,
        "error_patterns": error_patterns,
        "recent_failure_rate": round(recent_failure_rate, 4),
        "latency_percentiles": percentiles,
        "dwell_by_state": dwell_by_state,
        "is_potentially_stuck": is_stuck,
        "stuck_state": stuck_state,
        "stuck_current_dwell_ms": stuck_current_ms,
        "stuck_avg_dwell_ms": stuck_avg_ms,
        "state_revisits": state_revisits,
        "has_cycles": has_cycles,
        "fleet_comparison": fleet_comparison,
        "velocity_points": velocity_points,
    }


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _ensure_aware(dt: datetime | None) -> datetime:
    """Ensure a datetime is timezone-aware (UTC)."""
    if dt is None:
        return datetime.now(UTC)
    if dt.tzinfo is None:
        return dt.replace(tzinfo=UTC)
    return dt


def _compute_dwell_by_state(
    history: list[TransitionHistoryModel],
    now: datetime,
) -> list[dict[str, Any]]:
    """Compute dwell time statistics per state from transition history."""
    dwells: defaultdict[str, list[int]] = defaultdict(list)
    prev_state: str | None = None
    prev_ts: datetime | None = None

    for h in history:
        ts = _ensure_aware(h.created_at)
        if h.success and h.target_state:
            if prev_state and prev_ts:
                dwell_ms = int((ts - prev_ts).total_seconds() * 1000)
                if dwell_ms >= 0:
                    dwells[prev_state].append(dwell_ms)
            prev_state = h.target_state
            prev_ts = ts

    # Add current state dwell
    if prev_state and prev_ts:
        current_dwell = int((now - prev_ts).total_seconds() * 1000)
        if current_dwell >= 0:
            dwells[prev_state].append(current_dwell)

    result = []
    for state, values in sorted(dwells.items()):
        if values:
            result.append(
                {
                    "state": state,
                    "avg_ms": sum(values) // len(values),
                    "min_ms": min(values),
                    "max_ms": max(values),
                    "visit_count": len(values),
                }
            )
    return result


def _compute_fleet_comparison(
    session: Session,
    entity_id: str,
    machine_name: str | None,
    entity_failure_rate: float,
    entity_durations: list[int],
    window_hours: int,
    now: datetime,
) -> dict[str, Any] | None:
    """Compute fleet comparison metrics for the entity's machine."""
    if not machine_name:
        return None

    window_start = now - timedelta(hours=window_hours)

    # Fleet aggregate within window
    fleet_row = (
        session.query(
            func.count(TransitionHistoryModel.id).label("total"),
            func.sum(
                case(
                    (TransitionHistoryModel.success.is_(False), 1),
                    else_=0,
                )
            ).label("failed"),
            func.avg(TransitionHistoryModel.duration_ms).label("avg_dur"),
        )
        .filter(
            TransitionHistoryModel.machine_name == machine_name,
            TransitionHistoryModel.created_at >= window_start,
        )
        .first()
    )

    if not fleet_row or not fleet_row.total:
        return None

    fleet_total = fleet_row.total or 1
    fleet_failed = fleet_row.failed or 0
    fleet_failure_rate = fleet_failed / fleet_total
    fleet_avg_latency = int(fleet_row.avg_dur) if fleet_row.avg_dur else None

    entity_avg_latency = (
        sum(entity_durations) // len(entity_durations) if entity_durations else None
    )

    # Percentile rank: count entities with higher avg latency
    percentile_rank: float | None = None
    if entity_avg_latency is not None:
        try:
            # Sub-query: avg latency per entity in the fleet
            sub = (
                session.query(
                    TransitionHistoryModel.entity_id,
                    func.avg(TransitionHistoryModel.duration_ms).label("avg_lat"),
                )
                .filter(
                    TransitionHistoryModel.machine_name == machine_name,
                    TransitionHistoryModel.created_at >= window_start,
                    TransitionHistoryModel.duration_ms.isnot(None),
                )
                .group_by(TransitionHistoryModel.entity_id)
                .subquery()
            )

            total_entities = session.query(func.count()).select_from(sub).scalar() or 1
            slower_count = (
                session.query(func.count())
                .select_from(sub)
                .filter(sub.c.avg_lat > entity_avg_latency)
                .scalar()
                or 0
            )
            percentile_rank = round((slower_count / total_entities) * 100, 1)
        except Exception:
            logger.debug("Failed to compute percentile rank", exc_info=True)

    return {
        "entity_failure_rate": round(entity_failure_rate, 4),
        "fleet_failure_rate": round(fleet_failure_rate, 4),
        "entity_avg_latency_ms": entity_avg_latency,
        "fleet_avg_latency_ms": fleet_avg_latency,
        "latency_percentile_rank": percentile_rank,
    }


__all__ = [
    "compute_entity_metrics",
]
