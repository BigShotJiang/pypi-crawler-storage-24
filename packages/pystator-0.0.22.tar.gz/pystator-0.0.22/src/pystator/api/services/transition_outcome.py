"""Map TransitionResult to canonical API payloads (HTTP / JSON)."""

from __future__ import annotations

import re
from typing import Any

from pystator._types import ActionSpec, TransitionResult
from pystator.errors import FSMError


def _camel_to_snake(name: str) -> str:
    s = re.sub(r"(?<!^)(?=[A-Z])", "_", name).lower()
    return s.removesuffix("_error") if s.endswith("_error") else s


def _fallback_error_code(err: BaseException) -> str:
    return _camel_to_snake(type(err).__name__)


def _error_detail_dict(err: FSMError, metadata: dict[str, Any]) -> dict[str, Any]:
    code = err.code.value if err.code else _fallback_error_code(err)
    details: dict[str, Any] = dict(metadata) if metadata else {}
    if err.context:
        details.setdefault("error_context", dict(err.context))
    return {
        "code": code,
        "type": type(err).__name__,
        "message": str(err),
        "details": details if details else None,
    }


def _action_specs_to_list(specs: tuple[ActionSpec, ...]) -> list[dict[str, Any]]:
    return [
        {"name": s.name, **({"params": s.params} if s.params else {})} for s in specs
    ]


def action_names_from_payload(actions: list[dict[str, Any]] | list[str]) -> list[str]:
    """Extract action names for entity responses and history."""
    out: list[str] = []
    for a in actions:
        if isinstance(a, dict):
            n = a.get("name")
            if n:
                out.append(str(n))
        elif isinstance(a, str) and a:
            out.append(a)
    return out


def outcome_from_transition_result(result: TransitionResult) -> dict[str, Any]:
    """Build a JSON-serializable dict for FSMService and route handlers.

    Keys:
        success, source_state, target_state, trigger,
        actions_to_execute, on_exit_actions, on_enter_actions,
        metadata, error (FsmOutcomeError-shaped dict or None),
        error_message (str for DB / legacy entity ``error`` field).
    """
    out: dict[str, Any] = {
        "success": result.success,
        "source_state": result.source_state,
        "target_state": result.target_state,
        "trigger": result.trigger,
        "actions_to_execute": _action_specs_to_list(result.actions_to_execute),
        "on_exit_actions": _action_specs_to_list(result.on_exit_actions),
        "on_enter_actions": _action_specs_to_list(result.on_enter_actions),
        "metadata": dict(result.metadata),
    }
    if result.error is not None:
        if not isinstance(result.error, FSMError):
            raise TypeError("TransitionResult.error must be an FSMError")
        err_dict = _error_detail_dict(result.error, dict(result.metadata))
        out["error"] = err_dict
        out["error_message"] = err_dict["message"]
    else:
        out["error"] = None
        out["error_message"] = None
    return out
