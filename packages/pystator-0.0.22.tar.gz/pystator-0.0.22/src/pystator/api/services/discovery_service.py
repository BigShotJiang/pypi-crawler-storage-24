"""Service facade for inferred FSM discovery APIs."""

from __future__ import annotations

from datetime import datetime
from threading import Lock
from typing import Any

from pystator.config import (
    get_discovery_backend,
    get_discovery_database_url,
    get_discovery_min_confidence,
    get_discovery_min_edge_count,
)
from pystator.discovery import InferenceEngine, InferenceThresholds, ObservedStateEvent
from pystator.discovery.models import CandidateMachineVersion, ShadowDiff
from pystator.discovery.stores import create_discovery_store

_ENGINE_LOCK = Lock()
_ENGINE: InferenceEngine | None = None
_STORE: Any = None


def get_discovery_engine() -> InferenceEngine:
    global _ENGINE, _STORE
    if _ENGINE is not None:
        return _ENGINE
    with _ENGINE_LOCK:
        if _ENGINE is not None:
            return _ENGINE
        backend = get_discovery_backend()
        db_url = get_discovery_database_url()
        store = create_discovery_store(
            backend,
            connection_string=db_url,
            options={"database_name": "pystator"},
        )
        connect = getattr(store, "connect", None)
        if callable(connect):
            connect()
        thresholds = InferenceThresholds(
            min_edge_count=get_discovery_min_edge_count(),
            min_confidence=get_discovery_min_confidence(),
        )
        _ENGINE = InferenceEngine(
            observation_store=store,
            inference_store=store,
            candidate_store=store,
            shadow_store=store,
            thresholds=thresholds,
        )
        _STORE = store
        return _ENGINE


class DiscoveryService:
    def __init__(self, engine: InferenceEngine | None = None) -> None:
        self._engine = engine or get_discovery_engine()

    def record_observation(
        self,
        *,
        machine_name: str,
        entity_id: str,
        state: str,
        observed_at: datetime | None,
        source: str,
        source_event_id: str | None,
        ingest_seq: int,
        metadata: dict[str, Any] | None = None,
    ) -> bool:
        payload = dict(metadata or {})
        payload["machine_name"] = machine_name
        event = ObservedStateEvent(
            entity_id=entity_id,
            state=state,
            observed_at=observed_at or datetime.utcnow(),
            source=source,
            source_event_id=source_event_id,
            ingest_seq=ingest_seq,
            metadata=payload,
        )
        return self._engine.record_observation(machine_name, event)

    def build_candidate(
        self, machine_name: str, version: str | None = None
    ) -> dict[str, Any]:
        candidate = self._engine.build_candidate(machine_name, version=version)
        edges = self._engine.list_edges(machine_name)
        return {
            "machine_name": candidate.machine_name,
            "version": candidate.version,
            "status": candidate.status,
            "config": candidate.config,
            "metadata": candidate.metadata,
            "edges": [
                {
                    "source_state": e.source_state,
                    "destination_state": e.destination_state,
                    "count": e.count,
                    "unique_entities": e.unique_entities,
                    "unique_sources": e.unique_sources,
                    "confidence": e.confidence,
                }
                for e in edges
            ],
        }

    def get_latest_candidate(self, machine_name: str) -> dict[str, Any] | None:
        candidate = self._engine.get_latest_candidate(machine_name)
        if candidate is None:
            return None
        return {
            "machine_name": candidate.machine_name,
            "version": candidate.version,
            "status": candidate.status,
            "config": candidate.config,
            "metadata": candidate.metadata,
        }

    def list_candidate_summaries(self, machine_name: str) -> list[dict[str, Any]]:
        """Lightweight rows for candidate version listing (no full config)."""
        candidates = self._engine.list_candidates(machine_name)
        candidates = sorted(
            candidates,
            key=lambda c: c.created_at,
            reverse=True,
        )
        out: list[dict[str, Any]] = []
        for c in candidates:
            out.append(
                {
                    "machine_name": c.machine_name,
                    "version": c.version,
                    "status": c.status,
                    "created_at": c.created_at,
                    "metadata": c.metadata,
                }
            )
        return out

    def get_candidate_version(
        self, machine_name: str, version: str
    ) -> CandidateMachineVersion | None:
        """Return the stored candidate domain object, if any."""
        return self._engine.get_candidate(machine_name, version)

    def get_candidate_detail(
        self, machine_name: str, version: str
    ) -> dict[str, Any] | None:
        """Full candidate payload including edge diagnostics (same shape as build)."""
        candidate = self._engine.get_candidate(machine_name, version)
        if candidate is None:
            return None
        edges = self._engine.list_edges(machine_name)
        return {
            "machine_name": candidate.machine_name,
            "version": candidate.version,
            "status": candidate.status,
            "config": candidate.config,
            "metadata": candidate.metadata,
            "edges": [
                {
                    "source_state": e.source_state,
                    "destination_state": e.destination_state,
                    "count": e.count,
                    "unique_entities": e.unique_entities,
                    "unique_sources": e.unique_sources,
                    "confidence": e.confidence,
                }
                for e in edges
            ],
        }

    def list_shadow_diffs(
        self, machine_name: str, limit: int = 100
    ) -> list[dict[str, Any]]:
        diffs = self._engine.list_shadow_diffs(machine_name, limit=limit)
        return [
            {
                "machine_name": d.machine_name,
                "source_state": d.source_state,
                "trigger": d.trigger,
                "active_success": d.active_success,
                "active_target_state": d.active_target_state,
                "candidate_success": d.candidate_success,
                "candidate_target_state": d.candidate_target_state,
                "differs": d.differs,
                "reason": d.reason,
                "metadata": d.metadata,
            }
            for d in diffs
        ]

    def run_shadow_compare(
        self,
        *,
        machine_name: str,
        active_config: dict[str, Any],
        source_state: str,
        trigger: str,
        context: dict[str, Any] | None = None,
    ) -> ShadowDiff | None:
        return self._engine.run_shadow_compare(
            machine_name=machine_name,
            active_config=active_config,
            source_state=source_state,
            trigger=trigger,
            context=context,
        )
