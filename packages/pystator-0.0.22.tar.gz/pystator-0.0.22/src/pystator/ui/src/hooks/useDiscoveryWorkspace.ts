'use client'

import { useCallback, useState } from 'react'
import {
  buildDiscoveryCandidate,
  getApiErrorMessage,
  getDiscoveryCandidate,
  listDiscoveryCandidates,
  listDiscoveryShadowDiffs,
  promoteDiscoveryCandidate,
  recordDiscoveryObservation,
  type DiscoveryCandidateResponse,
  type DiscoveryCandidateSummaryItem,
  type DiscoveryShadowDiffResponse,
  type MachineResponse,
} from '@/lib/api'

export interface UseDiscoveryWorkspaceResult {
  machineName: string
  setMachineName: (v: string) => void
  candidates: DiscoveryCandidateSummaryItem[]
  selectedVersion: string | null
  selectVersion: (v: string | null) => void
  detail: DiscoveryCandidateResponse | null
  shadowDiffs: DiscoveryShadowDiffResponse[]
  promoted: MachineResponse | null
  error: string | null
  clearError: () => void
  loadingList: boolean
  loadingDetail: boolean
  loadingShadow: boolean
  building: boolean
  observing: boolean
  promoting: boolean
  loadCandidates: () => Promise<void>
  loadDetailFor: (version: string) => Promise<void>
  loadShadow: () => Promise<void>
  build: () => Promise<void>
  promote: (version: string) => Promise<MachineResponse>
  /** Demo: record one observation (entity + state). */
  observe: (entityId: string, state: string) => Promise<void>
}

export function useDiscoveryWorkspace(): UseDiscoveryWorkspaceResult {
  const [machineName, setMachineName] = useState('')
  const [candidates, setCandidates] = useState<DiscoveryCandidateSummaryItem[]>([])
  const [selectedVersion, setSelectedVersion] = useState<string | null>(null)
  const [detail, setDetail] = useState<DiscoveryCandidateResponse | null>(null)
  const [shadowDiffs, setShadowDiffs] = useState<DiscoveryShadowDiffResponse[]>([])
  const [promoted, setPromoted] = useState<MachineResponse | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [loadingList, setLoadingList] = useState(false)
  const [loadingDetail, setLoadingDetail] = useState(false)
  const [loadingShadow, setLoadingShadow] = useState(false)
  const [building, setBuilding] = useState(false)
  const [observing, setObserving] = useState(false)
  const [promoting, setPromoting] = useState(false)

  const clearError = useCallback(() => setError(null), [])

  const loadCandidates = useCallback(async () => {
    const name = machineName.trim()
    if (!name) {
      setError('Enter a machine name first.')
      return
    }
    setLoadingList(true)
    setError(null)
    try {
      const res = await listDiscoveryCandidates(name)
      setCandidates(res.candidates)
      setPromoted(null)
    } catch (e) {
      setError(getApiErrorMessage(e, 'Failed to load candidates'))
    } finally {
      setLoadingList(false)
    }
  }, [machineName])

  const loadDetailFor = useCallback(
    async (version: string) => {
      const name = machineName.trim()
      if (!name) return
      setLoadingDetail(true)
      setError(null)
      try {
        const d = await getDiscoveryCandidate(name, version)
        setDetail(d)
        setSelectedVersion(version)
      } catch (e) {
        setError(getApiErrorMessage(e, 'Failed to load candidate'))
        setDetail(null)
      } finally {
        setLoadingDetail(false)
      }
    },
    [machineName]
  )

  const loadShadow = useCallback(async () => {
    const name = machineName.trim()
    if (!name) return
    setLoadingShadow(true)
    setError(null)
    try {
      const rows = await listDiscoveryShadowDiffs(name, 200)
      setShadowDiffs(rows)
    } catch (e) {
      setError(getApiErrorMessage(e, 'Failed to load shadow diffs'))
      setShadowDiffs([])
    } finally {
      setLoadingShadow(false)
    }
  }, [machineName])

  const selectVersion = useCallback(
    (v: string | null) => {
      setSelectedVersion(v)
      if (v) {
        void loadDetailFor(v)
      } else {
        setDetail(null)
      }
    },
    [loadDetailFor]
  )

  const build = useCallback(async () => {
    const name = machineName.trim()
    if (!name) {
      setError('Enter a machine name first.')
      return
    }
    setBuilding(true)
    setError(null)
    try {
      await buildDiscoveryCandidate({ machine_name: name })
      await loadCandidates()
    } catch (e) {
      setError(getApiErrorMessage(e, 'Build failed'))
    } finally {
      setBuilding(false)
    }
  }, [machineName, loadCandidates])

  const observe = useCallback(
    async (entityId: string, state: string) => {
      const name = machineName.trim()
      if (!name) {
        setError('Enter a machine name first.')
        return
      }
      if (!entityId.trim() || !state.trim()) {
        setError('Entity ID and state are required.')
        return
      }
      setObserving(true)
      setError(null)
      try {
        await recordDiscoveryObservation({
          machine_name: name,
          entity_id: entityId.trim(),
          state: state.trim(),
          source: 'ui',
        })
      } catch (e) {
        setError(getApiErrorMessage(e, 'Observation failed'))
      } finally {
        setObserving(false)
      }
    },
    [machineName]
  )

  const promote = useCallback(
    async (version: string) => {
      const name = machineName.trim()
      if (!name) throw new Error('Machine name required')
      setPromoting(true)
      setError(null)
      try {
        const m = await promoteDiscoveryCandidate(name, version)
        setPromoted(m)
        return m
      } catch (e) {
        const msg = getApiErrorMessage(e, 'Promote failed')
        setError(msg)
        throw e
      } finally {
        setPromoting(false)
      }
    },
    [machineName]
  )

  return {
    machineName,
    setMachineName,
    candidates,
    selectedVersion,
    selectVersion,
    detail,
    shadowDiffs,
    promoted,
    error,
    clearError,
    loadingList,
    loadingDetail,
    loadingShadow,
    building,
    observing,
    promoting,
    loadCandidates,
    loadDetailFor,
    loadShadow,
    build,
    promote,
    observe,
  }
}
