'use client'

import { useCallback, useEffect, useState } from 'react'
import { getDiscoveryConfig, testDiscoveryDatabase } from '@/lib/api'
import type {
  DiscoveryConfigResponse,
  DiscoveryDatabaseTestRequest,
  DiscoveryDatabaseTestResponse,
} from '@/lib/api'

export type DiscoveryConfigState = DiscoveryConfigResponse | null

export function useDiscoveryConfig() {
  const [config, setConfig] = useState<DiscoveryConfigState>(null)
  const [testing, setTesting] = useState(false)
  const [testResult, setTestResult] = useState<DiscoveryDatabaseTestResponse | null>(null)

  const fetchConfig = useCallback(async () => {
    try {
      const r = await getDiscoveryConfig()
      setConfig(r)
    } catch {
      setConfig(null)
    }
  }, [])

  useEffect(() => {
    fetchConfig()
  }, [fetchConfig])

  const test = useCallback(async (body: DiscoveryDatabaseTestRequest) => {
    setTesting(true)
    setTestResult(null)
    try {
      const result = await testDiscoveryDatabase(body)
      setTestResult(result)
    } catch (err: unknown) {
      const detail =
        err && typeof err === 'object' && 'response' in err && err.response && typeof (err.response as object) === 'object' && 'detail' in (err.response as object)
          ? String((err.response as { detail?: string }).detail)
          : err instanceof Error
            ? err.message
            : 'Failed to test discovery backend connection'
      setTestResult({ success: false, message: detail })
    } finally {
      setTesting(false)
    }
  }, [])

  return { config, fetchConfig, testing, testResult, test }
}
