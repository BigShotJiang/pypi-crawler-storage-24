'use client'

import { useEffect } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import { ROUTES } from '@/lib/constants'

/**
 * Legacy route: `/observability/` redirects to the entities workspace observability section.
 * Preserves existing query params and sets `section=observability` when missing.
 */
export default function ObservabilityRedirectPage() {
  const router = useRouter()
  const searchParams = useSearchParams()

  useEffect(() => {
    const next = new URLSearchParams(searchParams.toString())
    if (!next.has('section')) {
      next.set('section', 'observability')
    }
    const q = next.toString()
    router.replace(`${ROUTES.ENTITIES}?${q}`)
  }, [router, searchParams])

  return null
}
