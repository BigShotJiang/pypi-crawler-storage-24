'use client'

import { PageHeader } from '@/components/common'
import { PageContainer } from '@/components/layout'
import { DiscoveryWorkspace } from '@/components/discovery/DiscoveryWorkspace'
import { useAppConfigStore, selectAppName, selectVersion } from '@/stores/app-config'

export default function DiscoveryPage() {
  const appName = useAppConfigStore(selectAppName)
  const version = useAppConfigStore(selectVersion)

  return (
    <PageContainer>
      <PageHeader
        title="Discovery"
        description={
          version
            ? `${appName}: infer candidate machines from observations, compare in shadow mode, and promote to Machines (${version})`
            : `${appName}: infer candidate machines from observations, compare in shadow mode, and promote to Machines`
        }
      />
      <DiscoveryWorkspace />
    </PageContainer>
  )
}
