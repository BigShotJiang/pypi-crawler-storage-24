'use client'

import { useEffect } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import { ROUTES } from '@/lib/constants'

/**
 * Legacy route: `/entities_2/` redirects to `/entities/` with the same query string
 * (static export cannot use next.config redirects).
 */
export default function EntitiesLegacyRouteRedirect() {
  const router = useRouter()
  const searchParams = useSearchParams()

  useEffect(() => {
    const q = searchParams.toString()
    router.replace(q ? `${ROUTES.ENTITIES}?${q}` : ROUTES.ENTITIES)
  }, [router, searchParams])

  return null
}
