'use client'

import { useCallback, useState } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import { PageHeader } from '@/components/common'
import { ResizableWorkspaceLayout } from '@/components/layout'
import { EntitiesWorkspaceSidebar } from '@/components/entities/EntitiesWorkspaceSidebar'
import EntityDetailView from '@/components/entities/EntityDetailView'
import { EntitiesListView } from '@/components/entities/EntitiesListView'
import { EntitiesListToolbar } from '@/components/entities/EntitiesListToolbar'
import { EntityMetricsInspectorOverlay } from '@/components/entities/EntityMetricsInspectorOverlay'
import { ObservabilityDashboard } from '@/components/observability/ObservabilityDashboard'
import {
  ROUTES,
  entitiesWorkspaceUrl,
  entityDetailUrl,
  parseEntitiesWorkspaceSection,
  type EntitiesWorkspaceSection,
} from '@/lib/constants'

export default function EntitiesPage() {
  const router = useRouter()
  const searchParams = useSearchParams()

  const entityIdFromQuery = searchParams.get('entityId')
  const showDetail = Boolean(entityIdFromQuery?.trim())
  const entityId = (entityIdFromQuery ?? '').trim()

  const section = parseEntitiesWorkspaceSection(searchParams.get('section'))

  /** Overlay panel: opened only by clicking a table row (local state; not URL-driven). */
  const [panelEntityId, setPanelEntityId] = useState<string | null>(null)
  const [metricsRefreshKey, setMetricsRefreshKey] = useState(0)
  const [createModalOpen, setCreateModalOpen] = useState(false)

  const handleBackFromDetail = useCallback(() => {
    router.push(ROUTES.ENTITIES)
  }, [router])

  const setUrl = useCallback(
    (next: { section: EntitiesWorkspaceSection }) => {
      router.replace(entitiesWorkspaceUrl(next), { scroll: false })
    },
    [router]
  )

  const handleSectionChange = useCallback(
    (next: EntitiesWorkspaceSection) => {
      setPanelEntityId(null)
      setUrl({ section: next })
    },
    [setUrl]
  )

  const handleEntityOpen = useCallback((entity: { entity_id: string }) => {
    setPanelEntityId(entity.entity_id)
  }, [])

  const handleEntityViewDetail = useCallback(
    (entity: { entity_id: string }) => {
      router.push(entityDetailUrl(entity.entity_id))
    },
    [router]
  )

  const handleCloseMetrics = useCallback(() => {
    setPanelEntityId(null)
  }, [])

  const handleEntityCreated = useCallback(
    (createdEntityId: string) => {
      router.push(entityDetailUrl(createdEntityId))
    },
    [router]
  )

  const handleObservabilityEntityClick = useCallback(
    (id: string) => {
      router.push(entityDetailUrl(id))
    },
    [router]
  )

  if (showDetail && entityId) {
    return <EntityDetailView entityId={entityId} onBack={handleBackFromDetail} />
  }

  return (
    <ResizableWorkspaceLayout
      groupId="entities-workspace"
      mainClassName="min-h-0 bg-background"
      sidebarResizable={false}
      renderSidebar={(api) => (
        <EntitiesWorkspaceSidebar api={api} activeSection={section} onSectionChange={handleSectionChange} />
      )}
    >
      <div className="flex h-full min-h-0 flex-col overflow-hidden">
        {section === 'observability' ? (
          <div className="min-h-0 flex-1 overflow-y-auto px-4 pb-4 pt-4 sm:px-6 lg:px-8">
            <ObservabilityDashboard onEntityClick={handleObservabilityEntityClick} />
          </div>
        ) : (
          <div className="relative flex min-h-0 flex-1 flex-col overflow-hidden">
            <div className="min-h-0 flex-1 overflow-y-auto px-4 pb-4 pt-4 sm:px-6 lg:px-8">
              <PageHeader
                title="Entities"
                description="Runtime entity state and transition history"
                actions={
                  <EntitiesListToolbar
                    onCreateClick={() => setCreateModalOpen(true)}
                    onAfterManualRefresh={
                      panelEntityId ? () => setMetricsRefreshKey((k) => k + 1) : undefined
                    }
                  />
                }
              />
              <EntitiesListView
                pauseAutoRefresh={Boolean(panelEntityId)}
                onEntityOpen={handleEntityOpen}
                onEntityViewDetail={handleEntityViewDetail}
                onEntityCreated={handleEntityCreated}
                overviewDefaultExpanded
                showToolbar={false}
                createModalOpen={createModalOpen}
                onCreateModalOpenChange={setCreateModalOpen}
              />
            </div>
            <EntityMetricsInspectorOverlay
              entityId={panelEntityId}
              onClose={handleCloseMetrics}
              refreshToken={metricsRefreshKey}
              onRequestMetricsRefresh={() => setMetricsRefreshKey((k) => k + 1)}
            />
          </div>
        )}
      </div>
    </ResizableWorkspaceLayout>
  )
}
