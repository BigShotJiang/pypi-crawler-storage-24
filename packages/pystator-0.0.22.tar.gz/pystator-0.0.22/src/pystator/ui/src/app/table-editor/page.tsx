import { redirect } from 'next/navigation'

/**
 * The table editor has been absorbed into the workspace.
 * This page redirects to the workspace for backwards compatibility
 * with bookmarks and external links.
 */
export default function TableEditorPage() {
  redirect('/workspace/')
}
