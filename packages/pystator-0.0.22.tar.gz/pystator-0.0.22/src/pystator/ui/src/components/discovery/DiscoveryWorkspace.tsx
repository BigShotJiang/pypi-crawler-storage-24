'use client'

import { useState } from 'react'
import Link from 'next/link'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { PromoteCandidateDialog } from '@/components/discovery/PromoteCandidateDialog'
import { useDiscoveryWorkspace } from '@/hooks/useDiscoveryWorkspace'
import { useDiscoveryConfig } from '@/hooks/useDiscoveryConfig'
import { ROUTES } from '@/lib/constants'
import { CheckCircle2, Loader2, RefreshCw } from 'lucide-react'

function JsonPreview({ value }: { value: unknown }) {
  return (
    <pre className="text-xs whitespace-pre-wrap break-words rounded-md bg-muted/50 p-3 max-h-64 overflow-auto border">
      {JSON.stringify(value, null, 2)}
    </pre>
  )
}

export function DiscoveryWorkspace() {
  const d = useDiscoveryWorkspace()
  const { config: discoveryConfig } = useDiscoveryConfig()
  const [entityId, setEntityId] = useState('demo-entity-1')
  const [stateObs, setStateObs] = useState('observed_state')
  const [promoteOpen, setPromoteOpen] = useState(false)
  const [promoteTarget, setPromoteTarget] = useState<string | null>(null)

  const nameOk = d.machineName.trim().length > 0

  return (
    <div className="space-y-6">
      {d.error && (
        <Alert variant="destructive">
          <AlertDescription>{d.error}</AlertDescription>
        </Alert>
      )}

      {d.promoted && (
        <Alert className="bg-green-50 border-green-200">
          <CheckCircle2 className="h-4 w-4 text-green-600" />
          <AlertDescription className="text-green-800">
            Saved machine <span className="font-medium">{d.promoted.name}</span> v{d.promoted.version}{' '}
            <Link href={ROUTES.MACHINES} className="underline font-medium">
              Open Machines
            </Link>
          </AlertDescription>
        </Alert>
      )}

      <Card>
        <CardHeader>
          <CardTitle>Discovery backend</CardTitle>
          <CardDescription>
            Server-side settings (configure persistence in <Link href={ROUTES.SETTINGS}
className="underline">Settings</Link>).
          </CardDescription>
        </CardHeader>
        <CardContent>
          {discoveryConfig ? (
            <p className="text-sm text-muted-foreground">
              Backend: <span className="font-medium text-foreground">{discoveryConfig.backend}</span>
              {' · '}
              Shadow: {discoveryConfig.shadow_enabled ? 'on' : 'off'}
              {' · '}
              Min edges: {discoveryConfig.min_edge_count} · Min confidence: {discoveryConfig.min_confidence}
            </p>
          ) : (
            <p className="text-sm text-muted-foreground">Loading discovery settings…</p>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>1. Machine name</CardTitle>
          <CardDescription>
            Use the same logical name you use for observations and candidate builds (e.g.{' '}
            <code className="text-xs">order_flow</code>).
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="dm-machine">Machine name</Label>
            <Input
              id="dm-machine"
              value={d.machineName}
              onChange={(e) => {
                d.setMachineName(e.target.value)
                d.clearError()
              }}
              placeholder="order_flow"
            />
          </div>
          <div className="flex flex-wrap gap-2">
            <Button
              type="button"
              variant="outline"
              onClick={() => void d.loadCandidates()}
              disabled={!nameOk || d.loadingList}
            >
              {d.loadingList ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                <RefreshCw className="mr-2 h-4 w-4" />
              )}
              Load candidates
            </Button>
            <Button type="button" onClick={() => void d.build()} disabled={!nameOk || d.building}>
              {d.building ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
              Build candidate
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>2. Record observations (optional)</CardTitle>
          <CardDescription>
            Append observed states for entities. Build candidate after you have enough transitions
            (thresholds apply on the server).
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="dm-entity">Entity ID</Label>
              <Input
                id="dm-entity"
                value={entityId}
                onChange={(e) => setEntityId(e.target.value)}
                placeholder="entity-123"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="dm-state">Observed state</Label>
              <Input
                id="dm-state"
                value={stateObs}
                onChange={(e) => setStateObs(e.target.value)}
                placeholder="pending"
              />
            </div>
          </div>
          <Button
            type="button"
            variant="secondary"
            onClick={() => void d.observe(entityId, stateObs)}
            disabled={!nameOk || d.observing}
          >
            {d.observing ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
            Record observation
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>3. Candidate versions</CardTitle>
          <CardDescription>Newest first. Select a row to inspect config and edges.</CardDescription>
        </CardHeader>
        <CardContent>
          {d.candidates.length === 0 ? (
            <p className="text-sm text-muted-foreground">
              No candidates yet. Record observations or build a candidate.
            </p>
          ) : (
            <div className="rounded-md border overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b bg-muted/40 text-left">
                    <th className="p-2 font-medium">Version</th>
                    <th className="p-2 font-medium">Status</th>
                    <th className="p-2 font-medium">Created</th>
                    <th className="p-2 font-medium">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {d.candidates.map((c) => {
                    const active = d.selectedVersion === c.version
                    return (
                      <tr
                        key={c.version}
                        className={`border-b cursor-pointer hover:bg-muted/50 ${active ? 'bg-primary/5' : ''}`}
                        onClick={() => d.selectVersion(c.version)}
                      >
                        <td className="p-2 font-mono">{c.version}</td>
                        <td className="p-2">{c.status}</td>
                        <td className="p-2 text-muted-foreground">
                          {new Date(c.created_at).toLocaleString()}
                        </td>
                        <td className="p-2">
                          <Button
                            type="button"
                            size="sm"
                            variant="outline"
                            onClick={(e) => {
                              e.stopPropagation()
                              d.selectVersion(c.version)
                              setPromoteTarget(c.version)
                              setPromoteOpen(true)
                            }}
                          >
                            Promote…
                          </Button>
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Candidate detail</CardTitle>
            <CardDescription>
              {d.selectedVersion
                ? `Version ${d.selectedVersion}`
                : 'Select a candidate from the table.'}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {d.loadingDetail ? (
              <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
            ) : d.detail ? (
              <div className="space-y-3">
                <p className="text-sm text-muted-foreground">
                  Inferred edges: {d.detail.edges?.length ?? 0}
                </p>
                <JsonPreview value={d.detail.config} />
              </div>
            ) : (
              <p className="text-sm text-muted-foreground">No candidate selected.</p>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Shadow diff log</CardTitle>
            <CardDescription>
              Compares active vs candidate transitions at runtime (populated when shadow mode is on).
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => void d.loadShadow()}
              disabled={!nameOk || d.loadingShadow}
            >
              {d.loadingShadow ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
              Refresh shadow diffs
            </Button>
            {d.shadowDiffs.length === 0 ? (
              <p className="text-sm text-muted-foreground">No shadow diffs yet.</p>
            ) : (
              <div className="rounded-md border max-h-72 overflow-auto text-xs">
                <table className="w-full">
                  <thead>
                    <tr className="border-b bg-muted/40 text-left">
                      <th className="p-2">Source</th>
                      <th className="p-2">Trigger</th>
                      <th className="p-2">Differs</th>
                    </tr>
                  </thead>
                  <tbody>
                    {d.shadowDiffs.slice(0, 50).map((row, i) => (
                      <tr key={`${row.source_state}-${row.trigger}-${i}`} className="border-b">
                        <td className="p-2 font-mono">{row.source_state}</td>
                        <td className="p-2 font-mono">{row.trigger}</td>
                        <td className="p-2">{row.differs ? 'yes' : 'no'}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <PromoteCandidateDialog
        open={promoteOpen}
        onOpenChange={(open) => {
          setPromoteOpen(open)
          if (!open) setPromoteTarget(null)
        }}
        machineName={d.machineName.trim()}
        version={promoteTarget}
        loading={d.promoting}
        onConfirm={async () => {
          if (!promoteTarget) return
          try {
            await d.promote(promoteTarget)
            setPromoteOpen(false)
            setPromoteTarget(null)
          } catch {
            /* error surfaced in workspace */
          }
        }}
      />
    </div>
  )
}
