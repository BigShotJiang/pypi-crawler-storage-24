'use client'

/**
 * Shared state / lifecycle badges for entity rows and overview panels.
 */

export function StateBadge({ state }: { state: string }) {
  const lower = state.toLowerCase()
  let colorClass = 'bg-primary/10 text-primary'
  if (lower.includes('error') || lower.includes('fail') || lower.includes('reject')) {
    colorClass = 'bg-destructive/10 text-destructive'
  } else if (
    lower.includes('complete') ||
    lower.includes('done') ||
    lower.includes('success') ||
    lower.includes('approved')
  ) {
    colorClass = 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400'
  } else if (lower === 'initial' || lower === 'start' || lower === 'idle') {
    colorClass = 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400'
  }

  return (
    <span
      className={`inline-flex items-center px-2.5 py-1 rounded-md text-sm font-medium ${colorClass}`}
    >
      {state}
    </span>
  )
}

export function StatusBadge({ status }: { status: string }) {
  let colorClass = 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400'
  if (status === 'archived') {
    colorClass = 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400'
  } else if (status === 'deleted') {
    colorClass = 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400'
  }

  return (
    <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${colorClass}`}>
      {status}
    </span>
  )
}
