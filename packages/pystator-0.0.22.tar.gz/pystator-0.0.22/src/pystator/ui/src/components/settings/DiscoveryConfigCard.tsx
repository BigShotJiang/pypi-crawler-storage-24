'use client'

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { useDiscoveryConfig } from '@/hooks'
import type { DiscoveryDatabaseTestRequest } from '@/lib/api'
import { Loader2, CheckCircle2, XCircle } from 'lucide-react'

interface DiscoveryConfigCardProps {
  backend: 'memory' | 'sqlite' | 'postgresql' | 'mongodb' | 'redis'
  connectionString: string
  shadowEnabled: boolean
  minEdgeCount: string
  minConfidence: string
  onBackendChange: (v: DiscoveryConfigCardProps['backend']) => void
  onConnectionStringChange: (v: string) => void
  onShadowEnabledChange: (v: boolean) => void
  onMinEdgeCountChange: (v: string) => void
  onMinConfidenceChange: (v: string) => void
}

export function DiscoveryConfigCard({
  backend,
  connectionString,
  shadowEnabled,
  minEdgeCount,
  minConfidence,
  onBackendChange,
  onConnectionStringChange,
  onShadowEnabledChange,
  onMinEdgeCountChange,
  onMinConfidenceChange,
}: DiscoveryConfigCardProps) {
  const { config, testing, testResult, test } = useDiscoveryConfig()

  const handleTest = () => {
    const body: DiscoveryDatabaseTestRequest = {
      backend,
      connection_string: connectionString || undefined,
    }
    test(body)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Discovery Configuration</CardTitle>
        <CardDescription>
          Configure inferred-state-machine discovery backend and shadow comparison behavior.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {config && (
          <div className="rounded-md bg-muted/50 px-3 py-2 text-sm text-muted-foreground">
            Backend: {config.backend} • Shadow mode: {config.shadow_enabled ? 'on' : 'off'} •
            {' '}Min edge count: {config.min_edge_count} • Min confidence: {config.min_confidence}
          </div>
        )}

        <div className="space-y-2">
          <Label htmlFor="discovery-backend">Backend</Label>
          <select
            id="discovery-backend"
            className="h-10 w-full rounded-md border border-input bg-background px-3 text-sm"
            value={backend}
            onChange={(e) => onBackendChange(e.target.value as DiscoveryConfigCardProps['backend'])}
          >
            <option value="memory">memory</option>
            <option value="sqlite">sqlite</option>
            <option value="postgresql">postgresql</option>
            <option value="mongodb">mongodb</option>
            <option value="redis">redis</option>
          </select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="discovery-connection-string">Connection string (optional for memory)</Label>
          <Input
            id="discovery-connection-string"
            type="text"
            value={connectionString}
            onChange={(e) => onConnectionStringChange(e.target.value)}
            placeholder="sqlite:///pystator_discovery.db"
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="discovery-min-edge-count">Min edge count</Label>
            <Input
              id="discovery-min-edge-count"
              type="number"
              min={1}
              value={minEdgeCount}
              onChange={(e) => onMinEdgeCountChange(e.target.value)}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="discovery-min-confidence">Min confidence (0-1)</Label>
            <Input
              id="discovery-min-confidence"
              type="number"
              min={0}
              max={1}
              step={0.01}
              value={minConfidence}
              onChange={(e) => onMinConfidenceChange(e.target.value)}
            />
          </div>
        </div>

        <div className="flex items-center justify-between rounded-md border px-3 py-2">
          <div>
            <p className="text-sm font-medium">Shadow mode</p>
            <p className="text-xs text-muted-foreground">
              Compare inferred candidates without affecting active runtime decisions.
            </p>
          </div>
          <Switch checked={shadowEnabled} onCheckedChange={onShadowEnabledChange} />
        </div>

        <div className="flex items-center gap-2">
          <Button type="button" variant="outline" onClick={handleTest} disabled={testing}>
            {testing ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Testing...
              </>
            ) : (
              'Test discovery backend'
            )}
          </Button>
          {testResult && (
            <span className="inline-flex items-center gap-1 text-sm">
              {testResult.success ? (
                <CheckCircle2 className="h-4 w-4 text-green-600" />
              ) : (
                <XCircle className="h-4 w-4 text-red-600" />
              )}
              {testResult.message}
            </span>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
