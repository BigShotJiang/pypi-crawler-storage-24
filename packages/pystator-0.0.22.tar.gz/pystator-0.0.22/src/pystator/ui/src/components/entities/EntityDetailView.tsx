'use client'

import { useCallback, useEffect, useState } from 'react'
import { PageHeader } from '@/components/common'
import { PageContainer } from '@/components/layout'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import ErrorDisplay from '@/components/ErrorDisplay'
import LoadingSpinner from '@/components/LoadingSpinner'
import FsmFlowDiagram from '@/components/fsm-flow/FsmFlowDiagram'
import SendEventForm from '@/components/entities/SendEventForm'
import TransitionHistory from '@/components/entities/TransitionHistory'
import EntityLabelEditor from '@/components/entities/EntityLabelEditor'
import AvailableTriggers from '@/components/entities/AvailableTriggers'
import EntityTimeline from '@/components/entities/EntityTimeline'
import EntityMetricsPanel from '@/components/entities/EntityMetricsPanel'
import { EntityStateOverview } from '@/components/entities/EntityStateOverview'
import {
  getEntityState,
  getEntityHistory,
  deleteEntity,
  archiveEntity,
  restoreEntity,
  purgeEntity,
  getEntitySnapshot,
} from '@/lib/api'
import type { EntityState, TransitionHistoryEntry } from '@/lib/api'
import { useMachineConfigByName } from '@/hooks/useMachineConfigByName'
import { getTriggersFromState } from '@/lib/fsmConfigUtils'
import { ArrowLeft, Trash2, RefreshCw, Download, Archive, RotateCcw, AlertTriangle } from 'lucide-react'

export interface EntityDetailViewProps {
  entityId: string
  onBack: () => void
}

export default function EntityDetailView({ entityId, onBack }: EntityDetailViewProps) {
  const [entity, setEntity] = useState<EntityState | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<Error | null>(null)
  const [refreshKey, setRefreshKey] = useState(0)
  const [lastTransition, setLastTransition] = useState<TransitionHistoryEntry | null>(null)

  const { config: machineConfig, loading: configLoading, error: configError } =
    useMachineConfigByName(entity?.machine_name ?? null)

  const fetchEntity = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      const data = await getEntityState(entityId)
      setEntity(data)
    } catch (e) {
      setError(e instanceof Error ? e : new Error(String(e)))
    } finally {
      setLoading(false)
    }
  }, [entityId])

  useEffect(() => {
    fetchEntity()
  }, [fetchEntity])

  useEffect(() => {
    if (!entityId || !entity) return
    getEntityHistory(entityId, 1, 0)
      .then((entries) => setLastTransition(entries[0] ?? null))
      .catch(() => setLastTransition(null))
  }, [entityId, entity, refreshKey])

  const handleEventSuccess = () => {
    fetchEntity()
    setRefreshKey((k) => k + 1)
  }

  const handleDelete = async () => {
    const confirmed = window.confirm(
      `Delete entity "${entityId}"? This will remove its state and all transition history.`
    )
    if (!confirmed) return
    try {
      await deleteEntity(entityId)
      onBack()
    } catch (e) {
      setError(e instanceof Error ? e : new Error(String(e)))
    }
  }

  const handleArchive = async () => {
    try {
      await archiveEntity(entityId)
      await fetchEntity()
    } catch (e) {
      setError(e instanceof Error ? e : new Error(String(e)))
    }
  }

  const handleRestore = async () => {
    try {
      await restoreEntity(entityId)
      await fetchEntity()
    } catch (e) {
      setError(e instanceof Error ? e : new Error(String(e)))
    }
  }

  const handlePurge = async () => {
    const confirmed = window.confirm(
      `Permanently purge entity "${entityId}"? This action cannot be undone.`
    )
    if (!confirmed) return
    try {
      await purgeEntity(entityId)
      onBack()
    } catch (e) {
      setError(e instanceof Error ? e : new Error(String(e)))
    }
  }

  const handleExportSnapshot = async () => {
    try {
      const snapshot = await getEntitySnapshot(entityId)
      const blob = new Blob([JSON.stringify(snapshot, null, 2)], { type: 'application/json' })
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = `entity-${entityId}-snapshot.json`
      document.body.appendChild(a)
      a.click()
      document.body.removeChild(a)
      URL.revokeObjectURL(url)
    } catch (e) {
      setError(e instanceof Error ? e : new Error(String(e)))
    }
  }

  const handleTriggerSelect = (trigger: string) => {
    // Scroll to send event form and pre-fill trigger
    const formEl = document.getElementById('send-event-form')
    if (formEl) {
      formEl.scrollIntoView({ behavior: 'smooth' })
    }
  }

  if (loading && !entity) {
    return (
      <PageContainer>
        <div className="flex justify-center py-20">
          <LoadingSpinner />
        </div>
      </PageContainer>
    )
  }

  return (
    <PageContainer>
      <PageHeader
        title={`Entity: ${entityId}`}
        description={entity ? `Machine: ${entity.machine_name ?? 'unknown'}` : ''}
        actions={
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={onBack} className="gap-1.5">
              <ArrowLeft className="h-4 w-4" /> Back
            </Button>
            <Button variant="outline" size="sm" onClick={fetchEntity} className="gap-1.5">
              <RefreshCw className="h-4 w-4" /> Refresh
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={handleDelete}
              className="text-destructive hover:text-destructive hover:bg-destructive/10 gap-1.5"
            >
              <Trash2 className="h-4 w-4" /> Delete
            </Button>
          </div>
        }
      />

      {error && <ErrorDisplay error={error} className="mt-4" />}

      {entity && (
        <div className="space-y-6 mt-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">State Overview</CardTitle>
            </CardHeader>
            <CardContent>
              <EntityStateOverview entity={entity} />

              {/* Label editor */}
              <EntityLabelEditor
                entityId={entityId}
                labels={entity.labels ?? {}}
                onLabelsChanged={fetchEntity}
              />

              {/* Action bar */}
              <div className="mt-4 border-t pt-4 flex flex-wrap gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleExportSnapshot}
                  className="gap-1.5"
                >
                  <Download className="h-3.5 w-3.5" />
                  Export Snapshot
                </Button>

                {entity.status === 'active' && (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleArchive}
                    className="gap-1.5"
                  >
                    <Archive className="h-3.5 w-3.5" />
                    Archive
                  </Button>
                )}

                {(entity.status === 'archived' || entity.status === 'deleted') && (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleRestore}
                    className="gap-1.5"
                  >
                    <RotateCcw className="h-3.5 w-3.5" />
                    Restore
                  </Button>
                )}

                {entity.status === 'deleted' && (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handlePurge}
                    className="gap-1.5 text-destructive hover:text-destructive hover:bg-destructive/10"
                  >
                    <AlertTriangle className="h-3.5 w-3.5" />
                    Purge
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Entity Metrics */}
          <EntityMetricsPanel entityId={entityId} refreshToken={refreshKey} />

          {entity.machine_name && (
            <Card>
              <CardHeader>
                <CardTitle className="text-base">State diagram</CardTitle>
                <CardDescription>
                  Current state is highlighted with a ring. Last transition edge is animated.
                </CardDescription>
              </CardHeader>
              <CardContent>
                {configLoading && !machineConfig && (
                  <div
                    className="flex items-center justify-center rounded border bg-muted/30"
                    style={{ minHeight: 320 }}
                  >
                    <LoadingSpinner />
                  </div>
                )}
                {configError && !machineConfig && (
                  <p className="text-sm text-muted-foreground py-4">
                    Machine &quot;{entity.machine_name}&quot; not found. Diagram unavailable.
                  </p>
                )}
                {machineConfig && (
                  <>
                    {lastTransition && (
                      <p className="text-sm text-muted-foreground mb-3">
                        Last transition:{' '}
                        <span className="font-medium text-foreground">
                          {lastTransition.source_state} &rarr; {lastTransition.target_state}
                        </span>{' '}
                        (trigger:{' '}
                        <code className="text-xs bg-muted px-1 rounded">
                          {lastTransition.trigger}
                        </code>
                        )
                      </p>
                    )}
                    <FsmFlowDiagram
                      config={machineConfig}
                      minHeight={400}
                      showGuards
                      showActions={false}
                      highlightState={entity.current_state}
                      highlightTransition={
                        lastTransition?.source_state &&
                        lastTransition?.target_state &&
                        lastTransition?.trigger
                          ? {
                              source: lastTransition.source_state,
                              target: lastTransition.target_state,
                              trigger: lastTransition.trigger,
                            }
                          : null
                      }
                    />
                  </>
                )}
              </CardContent>
            </Card>
          )}

          {/* Journey timeline */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Journey Timeline</CardTitle>
            </CardHeader>
            <CardContent>
              <EntityTimeline entityId={entityId} />
            </CardContent>
          </Card>

          {/* Available triggers */}
          {entity.machine_name && (
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Triggers</CardTitle>
              </CardHeader>
              <CardContent>
                <AvailableTriggers
                  entityId={entityId}
                  currentState={entity.current_state}
                  onTriggerSelect={handleTriggerSelect}
                />
              </CardContent>
            </Card>
          )}

          <div id="send-event-form">
            <SendEventForm
              entityId={entityId}
              defaultMachineName={entity.machine_name}
              availableTriggers={
                machineConfig && entity.current_state
                  ? getTriggersFromState(machineConfig, entity.current_state)
                  : undefined
              }
              stateVariables={machineConfig?.state_variables ?? []}
              onSuccess={handleEventSuccess}
            />
          </div>

          <TransitionHistory entityId={entityId} refreshKey={refreshKey} />
        </div>
      )}
    </PageContainer>
  )
}
