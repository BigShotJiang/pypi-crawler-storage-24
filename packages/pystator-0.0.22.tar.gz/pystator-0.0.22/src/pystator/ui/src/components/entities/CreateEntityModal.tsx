'use client'

import { useCallback, useEffect, useState } from 'react'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { listMachines, createEntity } from '@/lib/api'
import type { MachineListItem } from '@/lib/api'
import LoadingSpinner from '@/components/LoadingSpinner'

export interface CreateEntityModalProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  onSuccess: (entityId: string) => void
}

export default function CreateEntityModal({ open, onOpenChange, onSuccess }: CreateEntityModalProps) {
  const [entityId, setEntityId] = useState('')
  const [machines, setMachines] = useState<MachineListItem[]>([])
  const [selectedMachineId, setSelectedMachineId] = useState('')
  const [loadingMachines, setLoadingMachines] = useState(false)
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if (!open) return
    setLoadingMachines(true)
    listMachines()
      .then((res) => setMachines(res.machines))
      .catch(() => setMachines([]))
      .finally(() => setLoadingMachines(false))
  }, [open])

  const selectedMachine = machines.find((m) => m.id === selectedMachineId)
  const canSubmit = entityId.trim() !== '' && selectedMachineId !== '' && !submitting

  const handleSubmit = useCallback(
    async (e: React.FormEvent) => {
      e.preventDefault()
      if (!canSubmit || !selectedMachine) return
      setError(null)
      setSubmitting(true)
      try {
        await createEntity(entityId.trim(), {
          machine_name: selectedMachine.name,
          context: {},
        })
        onOpenChange(false)
        setEntityId('')
        setSelectedMachineId('')
        onSuccess(entityId.trim())
      } catch (err) {
        setError(err instanceof Error ? err.message : String(err))
      } finally {
        setSubmitting(false)
      }
    },
    [canSubmit, entityId, selectedMachine, onOpenChange, onSuccess]
  )

  const handleOpenChange = useCallback(
    (next: boolean) => {
      if (!next) {
        setEntityId('')
        setSelectedMachineId('')
        setError(null)
      }
      onOpenChange(next)
    },
    [onOpenChange]
  )

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent showClose>
        <DialogHeader>
          <DialogTitle>Create entity</DialogTitle>
          <DialogDescription>
            Creates a new entity in the database at the machine&apos;s initial state. No FSM event is processed; you can
            send events afterward from the entity detail view.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="create-entity-id">Entity ID</Label>
            <Input
              id="create-entity-id"
              value={entityId}
              onChange={(e) => setEntityId(e.target.value)}
              placeholder="e.g. order-001"
              disabled={submitting}
              autoFocus
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="create-entity-machine">Machine</Label>
            <select
              id="create-entity-machine"
              className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
              value={selectedMachineId}
              onChange={(e) => setSelectedMachineId(e.target.value)}
              disabled={loadingMachines || submitting}
            >
              <option value="">Select a machine</option>
              {machines.map((m) => (
                <option key={m.id} value={m.id}>
                  {m.name} (v{m.version})
                </option>
              ))}
            </select>
          </div>
          {error && (
            <div className="rounded-md bg-destructive/10 border border-destructive/20 px-3 py-2 text-sm text-destructive">
              {error}
            </div>
          )}
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => handleOpenChange(false)} disabled={submitting}>
              Cancel
            </Button>
            <Button type="submit" disabled={!canSubmit}>
              {submitting ? <LoadingSpinner size="sm" /> : 'Create'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
