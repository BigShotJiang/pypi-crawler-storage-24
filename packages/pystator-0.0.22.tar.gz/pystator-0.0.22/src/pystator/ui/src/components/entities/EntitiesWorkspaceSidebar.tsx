'use client'

import { Activity, Box, ChevronLeft, ChevronRight } from 'lucide-react'
import { cn } from '@/lib/utils'
import type { SidebarLayoutApi } from '@/components/layout'
import type { EntitiesWorkspaceSection } from '@/lib/constants'

export interface EntitiesWorkspaceSidebarProps {
  api: SidebarLayoutApi
  activeSection: EntitiesWorkspaceSection
  onSectionChange: (section: EntitiesWorkspaceSection) => void
}

const SECTIONS: { id: EntitiesWorkspaceSection; label: string; icon: typeof Box }[] = [
  { id: 'entities', label: 'Entities', icon: Box },
  { id: 'observability', label: 'Observability', icon: Activity },
]

/**
 * Left rail for `/entities/`: section switch (Entities vs Observability) plus collapse control
 * aligned with {@link ResizableWorkspaceLayout} / workspace sidebar patterns.
 */
export function EntitiesWorkspaceSidebar({
  api,
  activeSection,
  onSectionChange,
}: EntitiesWorkspaceSidebarProps) {
  const { isPanelCollapsed, sidebarDisplayMode, onCollapseRequested, onExpandRequested } = api
  const isCompact = sidebarDisplayMode === 'compact'

  const showLabels = !isPanelCollapsed && !isCompact

  return (
    <div className="flex h-full min-h-0 flex-col border-r border-border/50 bg-muted/20">
      <div
        className={cn(
          // Match WorkspaceConfigSidebar title row: px-4 py-3, bg-muted/30
          'flex shrink-0 items-center gap-2 border-b border-border/50 bg-muted/30 px-4 py-3',
          isPanelCollapsed ? 'justify-center' : 'justify-between'
        )}
      >
        {showLabels && (
          <span className="truncate px-1 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
            Views
          </span>
        )}
        <button
          type="button"
          onClick={() => {
            if (isPanelCollapsed) {
              onExpandRequested()
            } else {
              onCollapseRequested()
            }
          }}
          className="shrink-0 rounded-md p-1.5 transition-colors hover:bg-muted"
          aria-label={isPanelCollapsed ? 'Expand sidebar' : 'Collapse sidebar'}
        >
          {isPanelCollapsed ? (
            <ChevronRight className="h-4 w-4 text-muted-foreground" />
          ) : (
            <ChevronLeft className="h-4 w-4 text-muted-foreground" />
          )}
        </button>
      </div>

      <nav className="flex min-h-0 flex-1 flex-col gap-1 overflow-y-auto p-2" aria-label="Entities workspace sections">
        {SECTIONS.map(({ id, label, icon: Icon }) => {
          const active = activeSection === id
          return (
            <button
              key={id}
              type="button"
              onClick={() => onSectionChange(id)}
              title={!showLabels ? label : undefined}
              className={cn(
                'flex w-full items-center gap-2 rounded-lg px-2 py-2.5 text-left text-sm font-medium transition-colors',
                active
                  ? 'bg-primary text-primary-foreground shadow-sm'
                  : 'text-muted-foreground hover:bg-muted hover:text-foreground',
                isPanelCollapsed && 'justify-center px-0'
              )}
            >
              <Icon className="h-4 w-4 shrink-0" />
              {showLabels && <span className="truncate">{label}</span>}
            </button>
          )
        })}
      </nav>
    </div>
  )
}
