'use client'

import { useEffect, useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import {
  getApiErrorMessage,
  getDlqStats,
  getWorkerDlqConfig,
  testDlq,
  type DlqStatsResponse,
  type DlqTestRequest,
} from '@/lib/api'
import { Loader2, CheckCircle2, XCircle } from 'lucide-react'

interface DlqConfigCardProps {
  enabled: boolean
  connectionString: string
  host: string
  port: string
  database: string
  username: string
  password: string
  tableName: string
  onEnabledChange: (v: boolean) => void
  onConnectionStringChange: (v: string) => void
  onHostChange: (v: string) => void
  onPortChange: (v: string) => void
  onDatabaseChange: (v: string) => void
  onUsernameChange: (v: string) => void
  onPasswordChange: (v: string) => void
  onTableNameChange: (v: string) => void
}

function buildDlqBody(
  connectionString: string,
  host: string,
  port: string,
  database: string,
  username: string,
  password: string,
  tableName: string
): DlqTestRequest {
  return {
    connection_string: connectionString || undefined,
    host: host || undefined,
    port: port ? parseInt(port, 10) : undefined,
    database: database || undefined,
    username: username || undefined,
    password: password || undefined,
    table_name: tableName || undefined,
  }
}

export function DlqConfigCard({
  enabled,
  connectionString,
  host,
  port,
  database,
  username,
  password,
  tableName,
  onEnabledChange,
  onConnectionStringChange,
  onHostChange,
  onPortChange,
  onDatabaseChange,
  onUsernameChange,
  onPasswordChange,
  onTableNameChange,
}: DlqConfigCardProps) {
  const [serverHint, setServerHint] = useState<string | null>(null)
  const [testing, setTesting] = useState(false)
  const [testResult, setTestResult] = useState<{ success: boolean; message: string } | null>(null)
  const [loadingStats, setLoadingStats] = useState(false)
  const [dlqStats, setDlqStats] = useState<DlqStatsResponse | null>(null)
  const [statsError, setStatsError] = useState<string | null>(null)

  useEffect(() => {
    let cancelled = false
    getWorkerDlqConfig()
      .then((c) => {
        if (cancelled) return
        const bits = [
          c.persistence !== 'disabled' &&
            `Server worker DLQ: ${c.persistence} (table ${c.dlq_table_name})`,
        ].filter(Boolean)
        setServerHint(bits.length ? bits.join(' · ') : null)
      })
      .catch(() => {
        if (!cancelled) setServerHint(null)
      })
    return () => {
      cancelled = true
    }
  }, [])

  const handleTest = async () => {
    setTesting(true)
    setTestResult(null)
    try {
      const result = await testDlq(
        buildDlqBody(connectionString, host, port, database, username, password, tableName)
      )
      setTestResult(result)
    } catch (e) {
      setTestResult({
        success: false,
        message: getApiErrorMessage(e, 'Failed to test DLQ connection'),
      })
    } finally {
      setTesting(false)
    }
  }

  const handleStats = async () => {
    setLoadingStats(true)
    setDlqStats(null)
    setStatsError(null)
    try {
      const stats = await getDlqStats(
        buildDlqBody(connectionString, host, port, database, username, password, tableName)
      )
      setDlqStats(stats)
    } catch (e) {
      setStatsError(getApiErrorMessage(e, 'Failed to load DLQ statistics'))
    } finally {
      setLoadingStats(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Dead Letter Queue (DLQ)</CardTitle>
        <CardDescription>
          Configure the same database and table the worker uses for DLQ persistence (PostgreSQL
          recommended).
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {serverHint && (
          <div className="rounded-md bg-muted/50 px-3 py-2 text-sm text-muted-foreground">
            {serverHint}
          </div>
        )}
        <div className="flex items-center justify-between">
          <div className="space-y-0.5">
            <Label>Enable DLQ</Label>
            <p className="text-sm text-muted-foreground">
              Show connection fields for testing and statistics (same credentials as the worker
              process)
            </p>
          </div>
          <Switch checked={enabled} onCheckedChange={onEnabledChange} />
        </div>

        {enabled && (
          <div className="space-y-4 pt-4 border-t">
            <div className="space-y-2">
              <Label htmlFor="dlq-connection-string">Connection string (optional)</Label>
              <Input
                id="dlq-connection-string"
                type="text"
                value={connectionString}
                onChange={(e) => onConnectionStringChange(e.target.value)}
                placeholder="postgresql://user:password@host:5432/dbname"
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="dlq-host">Host</Label>
                <Input
                  id="dlq-host"
                  type="text"
                  value={host}
                  onChange={(e) => onHostChange(e.target.value)}
                  placeholder="localhost"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="dlq-port">Port</Label>
                <Input
                  id="dlq-port"
                  type="number"
                  value={port}
                  onChange={(e) => onPortChange(e.target.value)}
                  placeholder="5432"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="dlq-database">Database</Label>
              <Input
                id="dlq-database"
                type="text"
                value={database}
                onChange={(e) => onDatabaseChange(e.target.value)}
                placeholder="pystator"
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="dlq-username">Username</Label>
                <Input
                  id="dlq-username"
                  type="text"
                  value={username}
                  onChange={(e) => onUsernameChange(e.target.value)}
                  placeholder="user"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="dlq-password">Password</Label>
                <Input
                  id="dlq-password"
                  type="password"
                  value={password}
                  onChange={(e) => onPasswordChange(e.target.value)}
                  placeholder="••••••••"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="dlq-table">Table name</Label>
              <Input
                id="dlq-table"
                type="text"
                value={tableName}
                onChange={(e) => onTableNameChange(e.target.value)}
                placeholder="pystator_dead_letter_queue"
              />
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <Button type="button" variant="outline" onClick={handleTest} disabled={testing}>
                {testing ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Testing...
                  </>
                ) : (
                  'Test connection'
                )}
              </Button>
              <Button type="button" variant="outline" onClick={handleStats} disabled={loadingStats}>
                {loadingStats ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Loading...
                  </>
                ) : (
                  'Load statistics'
                )}
              </Button>
              {testResult && (
                <span className="inline-flex items-center gap-1 text-sm">
                  {testResult.success ? (
                    <CheckCircle2 className="h-4 w-4 text-green-600" />
                  ) : (
                    <XCircle className="h-4 w-4 text-red-600" />
                  )}
                  {testResult.message}
                </span>
              )}
            </div>
            {statsError && (
              <p className="text-sm text-red-600">{statsError}</p>
            )}
            {dlqStats && (
              <div className="rounded-md border p-3 text-sm space-y-2">
                <p className="font-medium">Total messages: {dlqStats.total_messages}</p>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                  <div>
                    <p className="text-muted-foreground">By reason</p>
                    <pre className="text-xs whitespace-pre-wrap">
                      {JSON.stringify(dlqStats.by_reason, null, 2)}
                    </pre>
                  </div>
                  <div>
                    <p className="text-muted-foreground">By stage</p>
                    <pre className="text-xs whitespace-pre-wrap">
                      {JSON.stringify(dlqStats.by_stage, null, 2)}
                    </pre>
                  </div>
                  <div>
                    <p className="text-muted-foreground">By status</p>
                    <pre className="text-xs whitespace-pre-wrap">
                      {JSON.stringify(dlqStats.by_status, null, 2)}
                    </pre>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
