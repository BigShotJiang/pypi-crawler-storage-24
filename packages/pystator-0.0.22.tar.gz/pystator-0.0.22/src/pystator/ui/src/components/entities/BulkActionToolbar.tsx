'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { bulkProcessEvents, archiveEntity, deleteEntity } from '@/lib/api'
import { useToastStore } from '@/stores/toast'
import { Send, Archive, Trash2, X } from 'lucide-react'

interface BulkActionToolbarProps {
  selectedCount: number
  selectedIds: Set<string>
  onClearSelection: () => void
  onRefresh: () => void
}

export default function BulkActionToolbar({
  selectedCount,
  selectedIds,
  onClearSelection,
  onRefresh,
}: BulkActionToolbarProps) {
  const [sendDialogOpen, setSendDialogOpen] = useState(false)
  const [trigger, setTrigger] = useState('')
  const [contextJson, setContextJson] = useState('{}')
  const [sending, setSending] = useState(false)
  const [archiving, setArchiving] = useState(false)
  const [deleting, setDeleting] = useState(false)

  const toast = useToastStore()

  const handleSendEvent = async () => {
    if (!trigger.trim()) return

    let parsedContext: Record<string, unknown> = {}
    try {
      parsedContext = JSON.parse(contextJson)
    } catch {
      toast.error('Invalid JSON in context field')
      return
    }

    setSending(true)
    try {
      const res = await bulkProcessEvents({
        trigger: trigger.trim(),
        entity_ids: Array.from(selectedIds),
        context: parsedContext,
      })
      toast.success(
        `Bulk event: ${res.succeeded} succeeded, ${res.failed} failed out of ${res.total}`
      )
      setSendDialogOpen(false)
      setTrigger('')
      setContextJson('{}')
      onClearSelection()
      onRefresh()
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e)
      toast.error(`Bulk event failed: ${msg}`)
    } finally {
      setSending(false)
    }
  }

  const handleArchive = async () => {
    setArchiving(true)
    const ids = Array.from(selectedIds)
    const results = await Promise.allSettled(ids.map((id) => archiveEntity(id)))
    const succeeded = results.filter((r) => r.status === 'fulfilled').length
    const failed = results.filter((r) => r.status === 'rejected').length
    if (failed > 0) {
      toast.error(`Archived ${succeeded}, failed ${failed} of ${ids.length}`)
    } else {
      toast.success(`Archived ${succeeded} entities`)
    }
    setArchiving(false)
    onClearSelection()
    onRefresh()
  }

  const handleDelete = async () => {
    const confirmed = window.confirm(
      `Delete ${selectedCount} selected entities? This will soft-delete their state and history.`
    )
    if (!confirmed) return

    setDeleting(true)
    const ids = Array.from(selectedIds)
    const results = await Promise.allSettled(ids.map((id) => deleteEntity(id)))
    const succeeded = results.filter((r) => r.status === 'fulfilled').length
    const failed = results.filter((r) => r.status === 'rejected').length
    if (failed > 0) {
      toast.error(`Deleted ${succeeded}, failed ${failed} of ${ids.length}`)
    } else {
      toast.success(`Deleted ${succeeded} entities`)
    }
    setDeleting(false)
    onClearSelection()
    onRefresh()
  }

  return (
    <>
      <div className="flex items-center gap-2 rounded-lg border bg-muted/30 px-3 py-2">
        <button
          type="button"
          onClick={onClearSelection}
          className="flex items-center gap-1 text-sm font-medium text-foreground hover:text-destructive transition-colors"
        >
          <X className="h-3.5 w-3.5" />
          {selectedCount} selected
        </button>

        <span className="text-muted-foreground">|</span>

        <Button
          variant="outline"
          size="sm"
          onClick={() => setSendDialogOpen(true)}
          disabled={sending}
          className="gap-1.5"
        >
          <Send className="h-3.5 w-3.5" />
          Send Event
        </Button>

        <Button
          variant="outline"
          size="sm"
          onClick={handleArchive}
          disabled={archiving}
          className="gap-1.5"
        >
          <Archive className="h-3.5 w-3.5" />
          {archiving ? 'Archiving...' : 'Archive'}
        </Button>

        <Button
          variant="outline"
          size="sm"
          onClick={handleDelete}
          disabled={deleting}
          className="gap-1.5 text-destructive hover:text-destructive hover:bg-destructive/10"
        >
          <Trash2 className="h-3.5 w-3.5" />
          {deleting ? 'Deleting...' : 'Delete'}
        </Button>

        <span className="text-muted-foreground">|</span>

        <Button variant="ghost" size="sm" onClick={onClearSelection}>
          Clear
        </Button>
      </div>

      {/* Send Event Dialog */}
      <Dialog open={sendDialogOpen} onOpenChange={setSendDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Send Event to {selectedCount} Entities</DialogTitle>
            <DialogDescription>
              This will send the same trigger to all selected entities.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-1.5">
              <Label htmlFor="bulk-trigger" className="text-sm">
                Trigger *
              </Label>
              <Input
                id="bulk-trigger"
                placeholder="e.g. approve, cancel"
                value={trigger}
                onChange={(e) => setTrigger(e.target.value)}
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="bulk-context" className="text-sm">
                Context (JSON)
              </Label>
              <textarea
                id="bulk-context"
                rows={3}
                className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm font-mono"
                value={contextJson}
                onChange={(e) => setContextJson(e.target.value)}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setSendDialogOpen(false)}>
              Cancel
            </Button>
            <Button
              onClick={handleSendEvent}
              disabled={sending || !trigger.trim()}
              className="gap-1.5"
            >
              <Send className="h-4 w-4" />
              {sending ? 'Sending...' : 'Send'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  )
}
