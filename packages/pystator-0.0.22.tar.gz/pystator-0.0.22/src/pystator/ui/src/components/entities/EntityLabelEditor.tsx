'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { mergeEntityLabels, deleteEntityLabel } from '@/lib/api'
import { Plus, X } from 'lucide-react'

interface EntityLabelEditorProps {
  entityId: string
  labels: Record<string, string>
  onLabelsChanged: () => void
}

export default function EntityLabelEditor({
  entityId,
  labels,
  onLabelsChanged,
}: EntityLabelEditorProps) {
  const [showAdd, setShowAdd] = useState(false)
  const [newKey, setNewKey] = useState('')
  const [newValue, setNewValue] = useState('')
  const [busy, setBusy] = useState(false)

  const entries = Object.entries(labels)

  const handleRemoveLabel = async (key: string) => {
    setBusy(true)
    try {
      await deleteEntityLabel(entityId, key)
      onLabelsChanged()
    } catch {
      // parent handles errors
    } finally {
      setBusy(false)
    }
  }

  const handleAddLabel = async () => {
    const trimmedKey = newKey.trim()
    const trimmedValue = newValue.trim()
    if (!trimmedKey) return

    setBusy(true)
    try {
      await mergeEntityLabels(entityId, { [trimmedKey]: trimmedValue })
      setNewKey('')
      setNewValue('')
      setShowAdd(false)
      onLabelsChanged()
    } catch {
      // parent handles errors
    } finally {
      setBusy(false)
    }
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      e.preventDefault()
      handleAddLabel()
    } else if (e.key === 'Escape') {
      setShowAdd(false)
      setNewKey('')
      setNewValue('')
    }
  }

  return (
    <div className="mt-3">
      <p className="text-xs text-muted-foreground uppercase tracking-wider mb-2">Labels</p>
      <div className="flex flex-wrap items-center gap-1.5">
        {entries.map(([key, value]) => (
          <span
            key={key}
            className="inline-flex items-center gap-1 rounded-md bg-muted px-2 py-0.5 text-xs font-mono"
          >
            <span className="text-muted-foreground">{key}</span>
            <span>=</span>
            <span>{value}</span>
            <button
              type="button"
              onClick={() => handleRemoveLabel(key)}
              disabled={busy}
              className="ml-0.5 text-muted-foreground hover:text-destructive transition-colors"
              aria-label={`Remove label ${key}`}
            >
              <X className="h-3 w-3" />
            </button>
          </span>
        ))}

        {entries.length === 0 && !showAdd && (
          <span className="text-xs text-muted-foreground">No labels</span>
        )}

        {showAdd ? (
          <div className="flex items-center gap-1.5">
            <input
              type="text"
              placeholder="key"
              className="w-20 rounded border border-input bg-background px-1.5 py-0.5 text-xs font-mono"
              value={newKey}
              onChange={(e) => setNewKey(e.target.value)}
              onKeyDown={handleKeyDown}
              autoFocus
            />
            <span className="text-xs">=</span>
            <input
              type="text"
              placeholder="value"
              className="w-24 rounded border border-input bg-background px-1.5 py-0.5 text-xs font-mono"
              value={newValue}
              onChange={(e) => setNewValue(e.target.value)}
              onKeyDown={handleKeyDown}
            />
            <Button
              variant="ghost"
              size="sm"
              onClick={handleAddLabel}
              disabled={busy || !newKey.trim()}
              className="h-6 px-1.5 text-xs"
            >
              Add
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => {
                setShowAdd(false)
                setNewKey('')
                setNewValue('')
              }}
              className="h-6 px-1.5 text-xs"
            >
              <X className="h-3 w-3" />
            </Button>
          </div>
        ) : (
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setShowAdd(true)}
            className="h-6 px-1.5 text-xs gap-1"
          >
            <Plus className="h-3 w-3" />
            Add
          </Button>
        )}
      </div>
    </div>
  )
}
