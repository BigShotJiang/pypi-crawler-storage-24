/**
 * HTML5 drag payload for palette blocks → FsmFlowDiagram (Pycharter-style MIME).
 */

import type { DragEvent } from 'react'

export const PALETTE_DND_MIME = 'application/reactflow'

const PAYLOAD_RE = /^pystator-(state|transition|template)-(.+)$/

export type PaletteDragKind = 'state' | 'transition' | 'template'

export interface PaletteDragPayload {
  kind: PaletteDragKind
  id: string
}

export function encodePaletteDrag(kind: PaletteDragKind, id: string): string {
  return `pystator-${kind}-${id}`
}

export function parsePaletteDrag(raw: string): PaletteDragPayload | null {
  const m = raw.match(PAYLOAD_RE)
  if (!m) return null
  const kind = m[1] as PaletteDragKind
  if (kind !== 'state' && kind !== 'transition' && kind !== 'template') return null
  return { kind, id: m[2] }
}

export function setPaletteDragData(event: DragEvent, kind: PaletteDragKind, id: string): void {
  event.dataTransfer.setData(PALETTE_DND_MIME, encodePaletteDrag(kind, id))
  event.dataTransfer.effectAllowed = 'move'
}

export function getPaletteDragPayload(event: DragEvent): PaletteDragPayload | null {
  const raw = event.dataTransfer.getData(PALETTE_DND_MIME)
  if (!raw) return null
  return parsePaletteDrag(raw)
}
