'use client'

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { Loader2 } from 'lucide-react'

interface PromoteCandidateDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  machineName: string
  version: string | null
  loading: boolean
  onConfirm: () => void
}

export function PromoteCandidateDialog({
  open,
  onOpenChange,
  machineName,
  version,
  loading,
  onConfirm,
}: PromoteCandidateDialogProps) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md" showClose>
        <DialogHeader>
          <DialogTitle>Promote candidate to machine</DialogTitle>
          <DialogDescription>
            This validates the inferred config and saves it to the Machines catalog as{' '}
            <span className="font-medium text-foreground">
              {machineName || '—'} v{version || '—'}
            </span>
            . If that name and version already exist, the stored config is replaced.
          </DialogDescription>
        </DialogHeader>
        <DialogFooter className="gap-2 sm:gap-0">
          <Button type="button" variant="outline" onClick={() => onOpenChange(false)} disabled={loading}>
            Cancel
          </Button>
          <Button type="button" onClick={onConfirm} disabled={loading || !version}>
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Promoting…
              </>
            ) : (
              'Promote'
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
