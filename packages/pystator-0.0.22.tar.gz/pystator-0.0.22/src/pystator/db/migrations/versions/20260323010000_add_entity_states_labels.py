"""Add labels column to entity_states.

Revision ID: 20260323010000
Revises: 20260323000000
Create Date: 2026-03-23
"""

from __future__ import annotations

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "20260323010000"
down_revision: str | None = "20260323000000"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def _schema() -> str | None:
    connection = op.get_bind()
    return None if connection.dialect.name == "sqlite" else "pystator"


def upgrade() -> None:
    schema_name = _schema()
    op.add_column(
        "entity_states",
        sa.Column("labels_json", sa.JSON(), nullable=True),
        schema=schema_name,
    )


def downgrade() -> None:
    schema_name = _schema()
    op.drop_column("entity_states", "labels_json", schema=schema_name)
