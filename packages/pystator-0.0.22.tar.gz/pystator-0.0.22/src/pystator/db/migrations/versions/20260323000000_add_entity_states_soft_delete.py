"""Add soft delete and archival columns to entity_states.

Revision ID: 20260323000000
Revises: 20260319000000
Create Date: 2026-03-23
"""

from __future__ import annotations

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "20260323000000"
down_revision: str | None = "20260319000000"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def _schema() -> str | None:
    connection = op.get_bind()
    return None if connection.dialect.name == "sqlite" else "pystator"


def upgrade() -> None:
    schema_name = _schema()
    op.add_column(
        "entity_states",
        sa.Column(
            "status",
            sa.String(20),
            nullable=False,
            server_default=sa.text("'active'"),
        ),
        schema=schema_name,
    )
    op.add_column(
        "entity_states",
        sa.Column("deleted_at", sa.DateTime(timezone=True), nullable=True),
        schema=schema_name,
    )
    op.add_column(
        "entity_states",
        sa.Column("archived_at", sa.DateTime(timezone=True), nullable=True),
        schema=schema_name,
    )
    op.create_index(
        "ix_entity_states_status",
        "entity_states",
        ["status"],
        schema=schema_name,
    )


def downgrade() -> None:
    schema_name = _schema()
    op.drop_index(
        "ix_entity_states_status",
        table_name="entity_states",
        schema=schema_name,
    )
    op.drop_column("entity_states", "archived_at", schema=schema_name)
    op.drop_column("entity_states", "deleted_at", schema=schema_name)
    op.drop_column("entity_states", "status", schema=schema_name)
