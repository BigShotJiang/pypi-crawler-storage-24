"""Discovery configuration (env + pystator.cfg)."""

from __future__ import annotations

import os
from configparser import ConfigParser

from pystator.config.paths import find_config_file

_SECTION = "discovery"


def _cfg(key: str) -> str | None:
    cfg_path = find_config_file("pystator.cfg")
    if not cfg_path:
        return None
    cfg = ConfigParser()
    cfg.read(cfg_path)
    if not cfg.has_section(_SECTION):
        return None
    return cfg.get(_SECTION, key, fallback=None)


def get_discovery_backend() -> str:
    return (
        (
            os.getenv("PYSTATOR_DISCOVERY_BACKEND")
            or _cfg("PYSTATOR_DISCOVERY_BACKEND")
            or "memory"
        )
        .strip()
        .lower()
    )


def get_discovery_database_url() -> str | None:
    return os.getenv("PYSTATOR_DISCOVERY_DATABASE_URL") or _cfg(
        "PYSTATOR_DISCOVERY_DATABASE_URL"
    )


def is_discovery_shadow_enabled() -> bool:
    raw = (
        os.getenv("PYSTATOR_DISCOVERY_SHADOW_ENABLED")
        or _cfg("PYSTATOR_DISCOVERY_SHADOW_ENABLED")
        or "1"
    )
    return str(raw).strip().lower() in {"1", "true", "yes", "on"}


def get_discovery_min_edge_count() -> int:
    raw = (
        os.getenv("PYSTATOR_DISCOVERY_MIN_EDGE_COUNT")
        or _cfg("PYSTATOR_DISCOVERY_MIN_EDGE_COUNT")
        or "2"
    )
    try:
        return max(1, int(raw))
    except ValueError:
        return 2


def get_discovery_min_confidence() -> float:
    raw = (
        os.getenv("PYSTATOR_DISCOVERY_MIN_CONFIDENCE")
        or _cfg("PYSTATOR_DISCOVERY_MIN_CONFIDENCE")
        or "0.5"
    )
    try:
        val = float(raw)
    except ValueError:
        return 0.5
    return min(1.0, max(0.0, val))
