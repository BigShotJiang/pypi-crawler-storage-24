"""Tests for peasy-convert CLI."""

from __future__ import annotations

from typer.testing import CliRunner

from peasy_convert.cli import app

runner = CliRunner()


class TestMain:
    def test_version(self) -> None:
        result = runner.invoke(app, ["--version"])
        assert result.exit_code == 0
        assert "peasy-convert" in result.output

    def test_no_args_shows_help(self) -> None:
        result = runner.invoke(app, [])
        assert "Peasy" in result.output or "Usage" in result.output

    def test_info(self) -> None:
        result = runner.invoke(app, ["info"])
        assert result.exit_code == 0
        assert "peasy-convert" in result.output

    def test_info_shows_packages(self) -> None:
        result = runner.invoke(app, ["info"])
        assert result.exit_code == 0
        # Should list all 4 package names
        assert "peasy-pdf" in result.output
        assert "peasy-image" in result.output
        assert "peasytext" in result.output
        assert "peasy-css" in result.output


class TestSubCommands:
    def test_css_subcommand_registered(self) -> None:
        result = runner.invoke(app, ["css", "--help"])
        # If peasy-css is installed, this should work
        assert result.exit_code == 0

    def test_pdf_subcommand_registered(self) -> None:
        result = runner.invoke(app, ["pdf", "--help"])
        assert result.exit_code == 0

    def test_text_subcommand_registered(self) -> None:
        result = runner.invoke(app, ["text", "--help"])
        assert result.exit_code == 0

    def test_image_subcommand_registered(self) -> None:
        result = runner.invoke(app, ["image", "--help"])
        assert result.exit_code == 0
