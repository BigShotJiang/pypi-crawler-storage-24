# peasy-convert

[![PyPI](https://img.shields.io/pypi/v/peasy-convert)](https://pypi.org/project/peasy-convert/)
[![Python](https://img.shields.io/pypi/pyversions/peasy-convert)](https://pypi.org/project/peasy-convert/)
[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](https://opensource.org/licenses/MIT)

Unified CLI for all Peasy tools — PDF, image, text, and CSS utilities in one `peasy` command. Install only what you need with optional extras.

Built from [Peasy Tools](https://peasytools.com), the platform with 255 free browser-based developer tools across 15 categories.

> **Try the interactive tools at [peasytools.com](https://peasytools.com)** — [PDF Tools](https://peasypdf.com), [Image Tools](https://peasyimage.com), [Text Tools](https://peasytext.com), [CSS Tools](https://peasycss.com)

## Table of Contents

- [Install](#install)
- [Quick Start](#quick-start)
- [Available Tool Suites](#available-tool-suites)
  - [PDF Tools](#pdf-tools)
  - [Image Tools](#image-tools)
  - [Text Tools](#text-tools)
  - [CSS Tools](#css-tools)
- [Info Command](#info-command)
- [Peasy Developer Tools](#peasy-developer-tools)
- [License](#license)

## Install

```bash
# Install with all tools
pip install "peasy-convert[all]"

# Install specific tool suites only
pip install "peasy-convert[pdf]"        # PDF tools
pip install "peasy-convert[image]"      # Image tools
pip install "peasy-convert[text]"       # Text tools
pip install "peasy-convert[css]"        # CSS tools

# Mix and match
pip install "peasy-convert[pdf,image]"
```

## Quick Start

```bash
# PDF operations
peasy pdf merge file1.pdf file2.pdf -o combined.pdf
peasy pdf split document.pdf --pages 1-5 -o section.pdf
peasy pdf compress large.pdf -o smaller.pdf

# Image operations
peasy image resize photo.png --width 800 -o thumb.png
peasy image convert photo.png --format webp -o photo.webp
peasy image grayscale color.jpg -o bw.jpg

# Text operations
peasy text reverse "Hello World"
peasy text hash "password123" --algorithm sha256

# CSS generation
peasy css gradient --colors "#ff6b35" "#f7c948" "#2ec4b6"
peasy css shadow --y 4px --blur 12px --color "rgba(0,0,0,0.15)"
peasy css flexbox --justify center --align center --gap 1rem
```

## Available Tool Suites

### PDF Tools

Install: `pip install "peasy-convert[pdf]"`

Powered by [peasy-pdf](https://pypi.org/project/peasy-pdf/) — PDF manipulation with pypdf.

```bash
peasy pdf merge a.pdf b.pdf -o merged.pdf     # Merge multiple PDFs
peasy pdf split doc.pdf --pages 1-5 -o out.pdf # Extract page range
peasy pdf compress big.pdf -o small.pdf        # Reduce file size
peasy pdf rotate doc.pdf --degrees 90 -o r.pdf # Rotate pages
peasy pdf info document.pdf                    # Show PDF metadata
peasy pdf text document.pdf                    # Extract text content
```

Learn more: [PeasyPDF](https://peasypdf.com) · [peasy-pdf on PyPI](https://pypi.org/project/peasy-pdf/)

### Image Tools

Install: `pip install "peasy-convert[image]"`

Powered by [peasy-image](https://pypi.org/project/peasy-image/) — image processing with Pillow.

```bash
peasy image resize photo.png --width 800           # Resize by width
peasy image crop img.png --left 10 --top 10 ...    # Crop region
peasy image convert photo.png --format webp        # Format conversion
peasy image compress photo.jpg --quality 75        # JPEG compression
peasy image grayscale color.jpg -o bw.jpg          # Convert to grayscale
peasy image blur photo.png --radius 5 -o blur.png  # Apply Gaussian blur
peasy image info photo.jpg                         # Show image metadata
```

Learn more: [PeasyImage](https://peasyimage.com) · [peasy-image on PyPI](https://pypi.org/project/peasy-image/)

### Text Tools

Install: `pip install "peasy-convert[text]"`

Powered by [peasytext](https://pypi.org/project/peasytext/) — text analysis and transformation.

```bash
peasy text case "hello world" --to upper        # Case conversion
peasy text slug "Hello World! 2024"             # URL slug generation
peasy text count "Lorem ipsum dolor sit amet"   # Word/char/sentence count
peasy text hash "input" --algorithm sha256      # Cryptographic hashing
peasy text reverse "Hello World"                # Reverse text
peasy text base64-encode "Hello World"          # Base64 encoding
```

Learn more: [PeasyText](https://peasytext.com) · [peasytext on PyPI](https://pypi.org/project/peasytext/)

### CSS Tools

Install: `pip install "peasy-convert[css]"`

Powered by [peasy-css](https://pypi.org/project/peasy-css/) — CSS code generation (zero dependencies).

```bash
peasy css gradient --colors "#ff6b35" "#f7c948"          # Linear gradient
peasy css shadow --y 4px --blur 12px                     # Box shadow
peasy css flexbox --justify center --align center        # Flexbox layout
peasy css grid --columns "repeat(3, 1fr)" --gap 2rem    # CSS Grid
peasy css glass --blur 20px                              # Glassmorphism
peasy css border-radius --all 8px                        # Border radius
peasy css clamp --min 1rem --preferred 2.5vw --max 3rem  # Fluid sizing
```

Learn more: [PeasyCSS](https://peasycss.com) · [peasy-css on PyPI](https://pypi.org/project/peasy-css/)

## Info Command

Check which tool suites are installed:

```bash
peasy info
```

Output:
```
Peasy Convert — Installed packages:

  peasy-convert  0.1.0
  peasy-pdf      0.1.0
  peasy-image    0.1.0
  peasytext      0.1.0
  peasy-css      0.1.0

Install extras: pip install 'peasy-convert[all]'
```

## Peasy Developer Tools

| Package | PyPI | npm | Description |
|---------|------|-----|-------------|
| peasytext | [PyPI](https://pypi.org/project/peasytext/) | [npm](https://www.npmjs.com/package/peasytext) | Text analysis — case, encoding, hashing, diff |
| peasy-pdf | [PyPI](https://pypi.org/project/peasy-pdf/) | — | PDF processing — merge, split, compress, rotate |
| peasy-image | [PyPI](https://pypi.org/project/peasy-image/) | — | Image ops — resize, crop, convert, filter |
| peasy-css | [PyPI](https://pypi.org/project/peasy-css/) | [npm](https://www.npmjs.com/package/peasy-css) | CSS generation — gradients, shadows, flexbox, grid |
| **peasy-convert** | **[PyPI](https://pypi.org/project/peasy-convert/)** | — | **Unified CLI — all tools in one command** |

Part of the [Peasy](https://peasytools.com) developer tools ecosystem — 255 free tools across 15 categories.

## License

MIT
