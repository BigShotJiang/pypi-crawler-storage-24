# CodeAOIS

### Advanced AI Developer Operating System

CodeAOIS is an experimental **AI-powered developer operating system** that allows developers to interact with an AI coding system directly from the terminal.

Instead of simple autocomplete tools, CodeAOIS acts like an **AI developer partner** capable of understanding instructions, generating code, and managing development workflows.

The system is designed around a **multi-agent architecture** where specialized agents collaborate to perform tasks such as coding, testing, and project management.

---

# ✨ Features

• Natural language coding from terminal
• Multi-agent AI architecture
• Automatic code generation
• Project context scanning
• Agent marketplace system
• AI memory and context tracking
• Modular and extensible design

---

# 🧠 How CodeAOIS Works

CodeAOIS works like an **AI operating system for developers**.

You simply describe what you want to build, and the system:

1. Understands your request
2. Scans the project context
3. Activates the appropriate AI agent
4. Generates code
5. Shows the preview before applying changes

---

# Demo

## CodeAOIS Terminal

![CodeAOIS Terminal](screenshots/codeaois_terminal.png)

## AI Code Generation

![Code Generation](screenshots/code_generation.png)

## Generated Login Page

![Login Page](screenshots/login_page_result.png)

---

# 💻 Example

Start CodeAOIS:

```
python app.py
```

Then type instructions like:

```
in file named index1.html you just make a colorful page and login page with css
```

CodeAOIS will:

• Analyze your intent
• Activate the coder agent
• Generate code
• Display the preview

Example output:

```
[System] Analyzing intent...
[Code Mode] Engaging Coder agent...

Target file locked: index1.html
Scanning project context...
Generating code...

PROPOSED CODE GENERATION PREVIEW:
<!DOCTYPE html>
<html>
...
```

---

# 🧾 Available Commands

```
/help            show command list
/marketplace     view specialized AI agents
/install <x>     install agent
/status          show system status
/clear           clear terminal
/clear_history   reset conversation memory
/clear_user      reset user profile
/exit            exit CodeAOIS
```

---

# 🧩 Project Structure

```
codeaois_project
│
├── codeaois
│   ├── brain
│   │   ├── embeddings.py
│   │   ├── memory.py
│   │   └── scanner.py
│   │
│   ├── cli
│   │   └── main.py
│   │
│   ├── config
│   │   └── settings.py
│   │
│   ├── core
│   │   ├── context.py
│   │   ├── marketplace.py
│   │   ├── memory.py
│   │   ├── orchestrator.py
│   │   ├── planner.py
│   │   └── router.py
│   │
│   ├── models
│   │   └── llm_interface.py
│   │
│   └── utils
│       ├── file_writer.py
│       └── logger.py
│
├── app.py
├── requirements.txt
├── setup.py
└── pyproject.toml
```

---

# ⚙️ Installation

Clone repository:

```
git clone https://github.com/C0de-With-Nikhil/CODEAOIS_PROJECT.git
```

Go to project folder:

```
cd CODEAOIS_PROJECT
```

Create virtual environment:

```
python3 -m venv venv
source venv/bin/activate
```

Install dependencies:

```
pip install -r requirements.txt
```

Run CodeAOIS:

```
python app.py
```

---

# 🎯 Vision

The goal of CodeAOIS is to create a **true AI development operating system** capable of:

• autonomous coding
• project reasoning
• multi-agent collaboration
• automated debugging
• AI-driven software architecture

---

# ⚠️ Status

CodeAOIS is currently an **experimental research project** and under active development.

---

# Installation
```bash
pip install codeaois
```

# Usage 
```bash
codeaois
```
### 2. The Master Blueprint (`setup.py`)
Now we need the configuration file. You might already have a basic one from earlier, but we need the production-ready version. 

Create or overwrite the `setup.py` file in your root `~/codeaois_project/` folder with this exact code:

```python

# 👨‍💻 Author

Created by **Nikhil Nagar**
