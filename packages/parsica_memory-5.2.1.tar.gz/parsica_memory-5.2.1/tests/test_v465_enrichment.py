"""v4.6.5 — LLM-Enriched Indexing Tests

Tests the optional enricher hook on MemorySystem:
- Enricher is called on ingest
- Tags merged with auto-extracted tags
- Enriched summary and keywords are searchable via BM25
- Vocabulary gap queries resolved via enrichment
- No enricher = current behaviour (backward compat)
- Enricher exception is non-fatal (graceful degradation)
- Serialisation round-trip (to_dict/from_dict preserves enrichment)
- Co-occurrence index receives enrichment-derived word pairs
- re_enrich() processes existing memories, idempotent, feeds co-occurrence
- TopK recall improvement with mock enricher
"""
import os
import sys
import tempfile
import json

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from parsica_memory import MemorySystem, EnrichmentResult
from parsica_memory.entry import MemoryEntry


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_enricher(mapping: dict):
    """Build a deterministic mock enricher from a dict of {text_fragment: result}."""
    def enricher(text: str) -> EnrichmentResult:
        for fragment, result in mapping.items():
            if fragment.lower() in text.lower():
                return result
        return {}
    return enricher


def _mem(workspace, enricher=None):
    """Create a fresh MemorySystem with warning suppressed."""
    import warnings
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        m = MemorySystem(workspace, agent_name="test_agent", enricher=enricher)
    m.load()
    return m


# ---------------------------------------------------------------------------
# 1. Enricher is called on ingest
# ---------------------------------------------------------------------------

def test_enricher_called_on_ingest():
    called_with = []

    def enricher(text: str) -> EnrichmentResult:
        called_with.append(text)
        return {"tags": ["test_tag"], "summary": "Test summary", "keywords": ["kw1"]}

    with tempfile.TemporaryDirectory() as d:
        m = _mem(d, enricher=enricher)
        m.ingest("We use FastAPI for the backend service", source="chat")
        assert len(called_with) == 1
        assert "FastAPI" in called_with[0]


# ---------------------------------------------------------------------------
# 2. Enriched tags merge with auto-extracted tags
# ---------------------------------------------------------------------------

def test_enriched_tags_merge_with_auto_tags():
    enricher = _make_enricher({
        "fastapi": {"tags": ["web_framework", "python", "rest_api"], "summary": "", "keywords": []}
    })

    with tempfile.TemporaryDirectory() as d:
        m = _mem(d, enricher=enricher)
        m.ingest("We use FastAPI for the backend service", source="chat")
        assert len(m.memories) == 1
        entry = m.memories[0]
        # Enrichment tags must be present
        assert "web_framework" in entry.tags
        assert "python" in entry.tags
        assert "rest_api" in entry.tags


# ---------------------------------------------------------------------------
# 3. Enriched summary is searchable via BM25
# ---------------------------------------------------------------------------

def test_enriched_summary_searchable():
    enricher = _make_enricher({
        "fastapi": {
            "tags": ["web_framework"],
            "summary": "The team uses FastAPI as their web framework for Python backend",
            "keywords": ["framework", "http"],
        }
    })

    with tempfile.TemporaryDirectory() as d:
        m = _mem(d, enricher=enricher)
        m.ingest("We use FastAPI for the backend service", source="chat")

        # Query that has zero overlap with original text ("web framework" not in "FastAPI backend service")
        # but overlaps with the enriched summary
        results = m.search("web framework", limit=5)
        assert len(results) > 0, "Enriched summary should make memory findable via 'web framework'"
        assert any("FastAPI" in r.content for r in results)


# ---------------------------------------------------------------------------
# 4. Search keywords boost relevance (vocabulary gap query)
# ---------------------------------------------------------------------------

def test_search_keywords_close_vocabulary_gap():
    enricher = _make_enricher({
        "fastapi": {
            "tags": ["web_framework"],
            "summary": "Backend uses FastAPI",
            "keywords": ["framework", "api_server", "asgi", "http_server"],
        }
    })

    with tempfile.TemporaryDirectory() as d:
        m = _mem(d, enricher=enricher)
        m.ingest("We use FastAPI for the backend service", source="chat")
        # "api_server" is a keyword that doesn't appear in original text OR summary
        results = m.search("api_server", limit=5)
        assert len(results) > 0, "search_keywords should make memory findable via keyword terms"


# ---------------------------------------------------------------------------
# 5. No enricher = current behaviour (backward compat)
# ---------------------------------------------------------------------------

def test_no_enricher_backward_compat():
    with tempfile.TemporaryDirectory() as d:
        m = _mem(d, enricher=None)  # No enricher
        m.ingest("We use FastAPI for the backend service", source="chat")
        assert len(m.memories) == 1
        entry = m.memories[0]
        # Fields should be empty defaults
        assert entry.enriched_summary == ""
        assert entry.search_keywords == []

        # Normal BM25 search still works
        results = m.search("FastAPI", limit=5)
        assert len(results) > 0


# ---------------------------------------------------------------------------
# 6. Enricher exception is non-fatal (graceful degradation)
# ---------------------------------------------------------------------------

def test_enricher_exception_is_non_fatal():
    def broken_enricher(text: str) -> EnrichmentResult:
        raise RuntimeError("LLM unavailable")

    with tempfile.TemporaryDirectory() as d:
        m = _mem(d, enricher=broken_enricher)
        # Should not raise — ingest should succeed despite enricher failure
        count = m.ingest("We use FastAPI for the backend service", source="chat")
        assert count == 1
        entry = m.memories[0]
        # Enrichment fields should be empty (fallback to raw text)
        assert entry.enriched_summary == ""
        assert entry.search_keywords == []
        # Basic search still works
        results = m.search("FastAPI", limit=5)
        assert len(results) > 0


# ---------------------------------------------------------------------------
# 7. Enricher returning None / empty dict is handled gracefully
# ---------------------------------------------------------------------------

def test_enricher_returning_none_or_empty():
    def null_enricher(text: str) -> EnrichmentResult:
        return {}

    with tempfile.TemporaryDirectory() as d:
        m = _mem(d, enricher=null_enricher)
        count = m.ingest("We use FastAPI for the backend service", source="chat")
        assert count == 1
        entry = m.memories[0]
        assert entry.enriched_summary == ""
        assert entry.search_keywords == []


# ---------------------------------------------------------------------------
# 8. Serialisation round-trip preserves enrichment fields
# ---------------------------------------------------------------------------

def test_serialisation_roundtrip():
    enricher = _make_enricher({
        "fastapi": {
            "tags": ["web_framework", "python"],
            "summary": "Backend uses FastAPI web framework",
            "keywords": ["framework", "http"],
        }
    })

    with tempfile.TemporaryDirectory() as d:
        m = _mem(d, enricher=enricher)
        m.ingest("We use FastAPI for the backend service", source="chat")
        entry = m.memories[0]

        # Serialise to dict
        d_dict = entry.to_dict()
        assert "enriched_summary" in d_dict
        assert d_dict["enriched_summary"] == "Backend uses FastAPI web framework"
        assert "search_keywords" in d_dict
        assert "framework" in d_dict["search_keywords"]

        # Deserialise from dict
        entry2 = MemoryEntry.from_dict(d_dict)
        assert entry2.enriched_summary == "Backend uses FastAPI web framework"
        assert "framework" in entry2.search_keywords
        assert "web_framework" in entry2.tags


# ---------------------------------------------------------------------------
# 9. Non-enriched entries deserialise cleanly (missing fields default)
# ---------------------------------------------------------------------------

def test_old_entry_deserialise_no_enrichment_fields():
    """Entries without enrichment fields load cleanly — backward compat for existing stores."""
    old_dict = {
        "content": "PostgreSQL is the primary database",
        "source": "chat",
        "line": 1,
        "category": "general",
        "created": "2026-01-01T00:00:00",
        "importance": 1.0,
        "confidence": 0.5,
        "sentiment": {},
        "tags": ["database"],
        "related": [],
        "hash": "abc123def456",
    }
    entry = MemoryEntry.from_dict(old_dict)
    assert entry.enriched_summary == ""
    assert entry.search_keywords == []


# ---------------------------------------------------------------------------
# 10. Co-occurrence index receives enrichment-derived word pairs
# ---------------------------------------------------------------------------

def test_cooccurrence_fed_from_enrichment():
    enricher = _make_enricher({
        "fastapi": {
            "tags": ["web_framework", "python", "rest_api"],
            "summary": "FastAPI web framework for Python",
            "keywords": ["framework", "http"],
        }
    })

    with tempfile.TemporaryDirectory() as d:
        m = _mem(d, enricher=enricher)
        m.ingest("We use FastAPI for the backend service", source="chat")

        # Co-occurrence index should have entries related to "web_framework" or "python"
        # (because the enrichment virtual sentence included these terms)
        cooc = m._cooccurrence
        related = cooc.similar_words("python", top_k=10)
        # "framework" and "web" should co-occur with "python" via enrichment
        assert len(related) > 0, "Co-occurrence index should be populated from enrichment"


# ---------------------------------------------------------------------------
# 11. re_enrich() processes existing memories
# ---------------------------------------------------------------------------

def test_re_enrich_processes_existing_memories():
    with tempfile.TemporaryDirectory() as d:
        # First: ingest without enricher
        m1 = _mem(d, enricher=None)
        m1.ingest("We use FastAPI for the backend service", source="chat")
        m1.ingest("PostgreSQL is the primary database", source="chat")
        m1.save()

        # Verify no enrichment yet
        for entry in m1.memories:
            assert entry.enriched_summary == ""

        # Now add enricher and re_enrich
        enricher = _make_enricher({
            "fastapi": {
                "tags": ["web_framework"],
                "summary": "FastAPI web framework",
                "keywords": ["framework"],
            },
            "postgresql": {
                "tags": ["database", "sql"],
                "summary": "PostgreSQL relational database",
                "keywords": ["sql", "rdbms"],
            },
        })
        m1._enricher = enricher
        count = m1.re_enrich()
        assert count == 2

        # Both entries should now be enriched
        fastapi_entry = next(e for e in m1.memories if "FastAPI" in e.content)
        pg_entry = next(e for e in m1.memories if "PostgreSQL" in e.content)
        assert fastapi_entry.enriched_summary != ""
        assert pg_entry.enriched_summary != ""


# ---------------------------------------------------------------------------
# 12. re_enrich() is idempotent (skips already-enriched entries)
# ---------------------------------------------------------------------------

def test_re_enrich_idempotent():
    enricher = _make_enricher({
        "fastapi": {
            "tags": ["web_framework"],
            "summary": "FastAPI web framework",
            "keywords": ["framework"],
        }
    })
    call_count = [0]

    def counting_enricher(text: str) -> EnrichmentResult:
        call_count[0] += 1
        return enricher(text)

    with tempfile.TemporaryDirectory() as d:
        m = _mem(d, enricher=counting_enricher)
        m.ingest("We use FastAPI for the backend service", source="chat")
        # At this point enricher was called once during ingest
        assert call_count[0] == 1

        # re_enrich should skip already-enriched entries
        count = m.re_enrich()
        assert count == 0  # Nothing to re-enrich
        assert call_count[0] == 1  # Enricher not called again


# ---------------------------------------------------------------------------
# 13. re_enrich() with overwrite=True re-enriches all entries
# ---------------------------------------------------------------------------

def test_re_enrich_overwrite():
    enricher = _make_enricher({
        "fastapi": {
            "tags": ["web_framework"],
            "summary": "FastAPI web framework v2",  # Different summary
            "keywords": ["framework"],
        }
    })

    with tempfile.TemporaryDirectory() as d:
        m = _mem(d, enricher=enricher)
        m.ingest("We use FastAPI for the backend service", source="chat")
        entry = m.memories[0]
        original_summary = entry.enriched_summary

        # Re-enrich with overwrite
        count = m.re_enrich(overwrite=True)
        assert count == 1
        assert entry.enriched_summary == "FastAPI web framework v2"


# ---------------------------------------------------------------------------
# 14. re_enrich() with no enricher returns 0
# ---------------------------------------------------------------------------

def test_re_enrich_no_enricher_returns_zero():
    with tempfile.TemporaryDirectory() as d:
        m = _mem(d, enricher=None)
        m.ingest("We use FastAPI for the backend service", source="chat")
        result = m.re_enrich()
        assert result == 0


# ---------------------------------------------------------------------------
# 15. TopK recall improvement with mock enricher (vocabulary gap queries)
# ---------------------------------------------------------------------------

def test_topk_recall_vocabulary_gap():
    """Demonstrates that enrichment fixes vocabulary-gap K=1 misses.

    Seeds memories where queries have zero keyword overlap with answers.
    Without enrichment: miss. With enrichment: hit.
    """
    gap_pairs = [
        {
            "memory": "We use FastAPI for the backend service.",
            "query": "which web framework do we use",
            "tags": ["web_framework", "python"],
            "summary": "Team uses FastAPI as their Python web framework REST API server",
            "keywords": ["framework", "api_server", "http"],
        },
        {
            "memory": "PostgreSQL is the primary database running on RDS.",
            "query": "what is the data store",
            "tags": ["database", "sql", "rdbms"],
            "summary": "PostgreSQL relational database is the primary data store running on RDS",
            "keywords": ["sql", "rdbms", "storage", "data_store"],
        },
        {
            "memory": "Monthly LLM spend is approximately $120.",
            "query": "what is the AI cost budget",
            "tags": ["cost", "budget", "llm", "spending"],
            "summary": "Monthly AI cost and LLM budget is approximately $120",
            "keywords": ["budget", "cost", "spending", "ai_cost"],
        },
    ]

    def gap_enricher(text: str) -> EnrichmentResult:
        for pair in gap_pairs:
            if pair["memory"][:20].lower() in text.lower():
                return {
                    "tags": pair["tags"],
                    "summary": pair["summary"],
                    "keywords": pair["keywords"],
                }
        return {}

    with tempfile.TemporaryDirectory() as d:
        m = _mem(d, enricher=gap_enricher)
        for pair in gap_pairs:
            m.ingest(pair["memory"], source="chat")

        hits_at_1 = 0
        for pair in gap_pairs:
            results = m.search(pair["query"], limit=5)
            if results and pair["memory"][:15].lower() in results[0].content.lower():
                hits_at_1 += 1

        # With enrichment, all 3 vocabulary-gap queries should hit at K=1
        assert hits_at_1 == 3, (
            f"Expected 3/3 vocabulary-gap queries to hit at K=1, got {hits_at_1}/3. "
            "Enrichment should bridge vocabulary mismatches."
        )


# ---------------------------------------------------------------------------
# 16. EnrichmentResult type is exported from package
# ---------------------------------------------------------------------------

def test_enrichment_result_exported():
    from parsica_memory import EnrichmentResult
    # TypedDict — check it's usable
    result: EnrichmentResult = {
        "tags": ["web_framework"],
        "summary": "FastAPI web framework",
        "keywords": ["framework"],
    }
    assert result["tags"] == ["web_framework"]


if __name__ == "__main__":
    import traceback

    tests = [
        test_enricher_called_on_ingest,
        test_enriched_tags_merge_with_auto_tags,
        test_enriched_summary_searchable,
        test_search_keywords_close_vocabulary_gap,
        test_no_enricher_backward_compat,
        test_enricher_exception_is_non_fatal,
        test_enricher_returning_none_or_empty,
        test_serialisation_roundtrip,
        test_old_entry_deserialise_no_enrichment_fields,
        test_cooccurrence_fed_from_enrichment,
        test_re_enrich_processes_existing_memories,
        test_re_enrich_idempotent,
        test_re_enrich_overwrite,
        test_re_enrich_no_enricher_returns_zero,
        test_topk_recall_vocabulary_gap,
        test_enrichment_result_exported,
    ]

    passed = failed = 0
    for t in tests:
        try:
            t()
            print(f"  ✓ {t.__name__}")
            passed += 1
        except Exception as e:
            print(f"  ✗ {t.__name__}: {e}")
            traceback.print_exc()
            failed += 1

    print(f"\n{'='*60}")
    print(f"v4.6.5 Enrichment Tests: {passed}/{passed+failed} passed")
    if failed:
        sys.exit(1)
