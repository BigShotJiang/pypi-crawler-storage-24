"""Tests for v4.7.0 Knowledge Ingestion feature (~30 tests)."""

import csv
import json
import os
import sqlite3
import tempfile
import time
import unittest
from unittest.mock import MagicMock, patch

from parsica_memory.ingest_web import WebCrawler, _HTMLTextExtractor, _content_hash
from parsica_memory.ingest_structured import StructuredIngester
from parsica_memory.ingest_manifest import IngestManifest


# ── WebCrawler tests ──────────────────────────────────────────────────────

class TestHTMLTextExtractor(unittest.TestCase):

    def test_basic_paragraph_extraction(self):
        html = "<html><body><p>This is a paragraph with enough characters to pass the minimum length filter.</p></body></html>"
        parser = _HTMLTextExtractor()
        parser.feed(html)
        chunks = parser.get_chunks()
        self.assertEqual(len(chunks), 1)
        self.assertIn("paragraph", chunks[0])

    def test_script_style_stripped(self):
        html = "<html><head><style>body{}</style></head><body><script>alert(1)</script><p>This is real content that should be extracted from the page.</p></body></html>"
        parser = _HTMLTextExtractor()
        parser.feed(html)
        chunks = parser.get_chunks()
        self.assertEqual(len(chunks), 1)
        self.assertNotIn("alert", chunks[0])
        self.assertNotIn("body{}", chunks[0])

    def test_multiple_paragraphs(self):
        html = "<p>First paragraph with enough text to pass the minimum filter easily.</p><p>Second paragraph also with enough text to pass the minimum filter.</p>"
        parser = _HTMLTextExtractor()
        parser.feed(html)
        chunks = parser.get_chunks()
        self.assertEqual(len(chunks), 2)

    def test_short_text_filtered(self):
        html = "<p>Short</p><p>This paragraph is long enough to pass the fifty character minimum length requirement.</p>"
        parser = _HTMLTextExtractor()
        parser.feed(html)
        chunks = parser.get_chunks()
        self.assertEqual(len(chunks), 1)


class TestContentHash(unittest.TestCase):

    def test_deterministic(self):
        h1 = _content_hash("hello world")
        h2 = _content_hash("hello world")
        self.assertEqual(h1, h2)

    def test_length_16(self):
        h = _content_hash("test content")
        self.assertEqual(len(h), 16)

    def test_different_input(self):
        h1 = _content_hash("aaa")
        h2 = _content_hash("bbb")
        self.assertNotEqual(h1, h2)


class TestWebCrawler(unittest.TestCase):

    @patch("parsica_memory.ingest_web.urllib.request.urlopen")
    @patch("parsica_memory.ingest_web.urllib.robotparser.RobotFileParser")
    def test_crawl_basic(self, mock_rp_cls, mock_urlopen):
        # Mock robots.txt
        mock_rp = MagicMock()
        mock_rp.can_fetch.return_value = True
        mock_rp_cls.return_value = mock_rp

        # Mock HTTP response
        html = b"<html><body><p>This is a test paragraph with enough text to exceed the minimum character limit.</p></body></html>"
        mock_resp = MagicMock()
        mock_resp.read.return_value = html
        mock_resp.headers.get_content_charset.return_value = "utf-8"
        mock_resp.__enter__ = lambda s: s
        mock_resp.__exit__ = MagicMock(return_value=False)
        mock_urlopen.return_value = mock_resp

        crawler = WebCrawler()
        results = crawler.crawl("http://example.com", depth=1)
        self.assertGreaterEqual(len(results), 1)
        self.assertIn("text", results[0])
        self.assertIn("content_hash", results[0])
        self.assertIn("source_url", results[0])

    @patch("parsica_memory.ingest_web.urllib.robotparser.RobotFileParser")
    def test_robots_blocked(self, mock_rp_cls):
        mock_rp = MagicMock()
        mock_rp.can_fetch.return_value = False
        mock_rp_cls.return_value = mock_rp

        crawler = WebCrawler()
        results = crawler.crawl("http://blocked.example.com")
        self.assertEqual(len(results), 0)

    @patch("parsica_memory.ingest_web.urllib.request.urlopen")
    @patch("parsica_memory.ingest_web.urllib.robotparser.RobotFileParser")
    def test_hash_dedup_within_crawl(self, mock_rp_cls, mock_urlopen):
        mock_rp = MagicMock()
        mock_rp.can_fetch.return_value = True
        mock_rp_cls.return_value = mock_rp

        html = b"<p>Duplicate paragraph content that is long enough to pass the filter check.</p><p>Duplicate paragraph content that is long enough to pass the filter check.</p>"
        mock_resp = MagicMock()
        mock_resp.read.return_value = html
        mock_resp.headers.get_content_charset.return_value = "utf-8"
        mock_resp.__enter__ = lambda s: s
        mock_resp.__exit__ = MagicMock(return_value=False)
        mock_urlopen.return_value = mock_resp

        crawler = WebCrawler()
        results = crawler.crawl("http://example.com")
        # Should deduplicate identical chunks
        hashes = [r["content_hash"] for r in results]
        self.assertEqual(len(hashes), len(set(hashes)))

    @patch("parsica_memory.ingest_web.urllib.request.urlopen")
    def test_fetch_timeout_nonfatal(self, mock_urlopen):
        mock_urlopen.side_effect = TimeoutError("timed out")
        crawler = WebCrawler()
        results = crawler.crawl("http://timeout.example.com")
        self.assertEqual(len(results), 0)

    @patch("parsica_memory.ingest_web.urllib.request.urlopen")
    @patch("parsica_memory.ingest_web.urllib.robotparser.RobotFileParser")
    def test_crawl_sitemap(self, mock_rp_cls, mock_urlopen):
        mock_rp = MagicMock()
        mock_rp.can_fetch.return_value = True
        mock_rp_cls.return_value = mock_rp

        sitemap_xml = b"""<?xml version="1.0"?>
        <urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
            <url><loc>http://example.com/page1</loc></url>
        </urlset>"""

        page_html = b"<p>Page content that is definitely long enough to pass the minimum character threshold.</p>"

        def side_effect(req, timeout=10):
            resp = MagicMock()
            resp.headers.get_content_charset.return_value = "utf-8"
            resp.__enter__ = lambda s: s
            resp.__exit__ = MagicMock(return_value=False)
            url = req.full_url if hasattr(req, 'full_url') else str(req)
            if "sitemap" in url or url.endswith(".xml"):
                resp.read.return_value = sitemap_xml
            else:
                resp.read.return_value = page_html
            return resp

        mock_urlopen.side_effect = side_effect
        crawler = WebCrawler()
        results = crawler.crawl_sitemap("http://example.com/sitemap.xml")
        self.assertGreaterEqual(len(results), 1)


# ── StructuredIngester tests ──────────────────────────────────────────────

class TestStructuredIngester(unittest.TestCase):

    def setUp(self):
        self.ingester = StructuredIngester()
        self.tmpdir = tempfile.mkdtemp()

    def test_csv_basic(self):
        path = os.path.join(self.tmpdir, "test.csv")
        with open(path, "w", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(["name", "value"])
            writer.writerow(["alpha", "100"])
            writer.writerow(["beta", "200"])
        results = self.ingester.from_csv(path)
        self.assertEqual(len(results), 2)
        self.assertIn("source_url", results[0])
        self.assertTrue(results[0]["source_url"].startswith("file://"))

    def test_csv_column_selection(self):
        path = os.path.join(self.tmpdir, "test.csv")
        with open(path, "w", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(["name", "value", "ignore"])
            writer.writerow(["alpha", "100", "junk"])
        results = self.ingester.from_csv(path, text_columns=["name", "value"])
        self.assertEqual(len(results), 1)
        self.assertNotIn("junk", results[0]["text"])

    def test_csv_empty(self):
        path = os.path.join(self.tmpdir, "empty.csv")
        with open(path, "w") as f:
            f.write("col1,col2\n")
        results = self.ingester.from_csv(path)
        self.assertEqual(len(results), 0)

    def test_json_list_of_dicts(self):
        path = os.path.join(self.tmpdir, "test.json")
        with open(path, "w") as f:
            json.dump([{"a": "hello"}, {"a": "world"}], f)
        results = self.ingester.from_json(path)
        self.assertEqual(len(results), 2)

    def test_json_flat_dict(self):
        path = os.path.join(self.tmpdir, "flat.json")
        with open(path, "w") as f:
            json.dump({"key": "value", "num": 42}, f)
        results = self.ingester.from_json(path)
        self.assertEqual(len(results), 1)

    def test_json_empty_list(self):
        path = os.path.join(self.tmpdir, "empty.json")
        with open(path, "w") as f:
            json.dump([], f)
        results = self.ingester.from_json(path)
        self.assertEqual(len(results), 0)

    def test_sqlite_basic(self):
        path = os.path.join(self.tmpdir, "test.db")
        conn = sqlite3.connect(path)
        conn.execute("CREATE TABLE items (name TEXT, value INTEGER)")
        conn.execute("INSERT INTO items VALUES ('alpha', 100)")
        conn.execute("INSERT INTO items VALUES ('beta', 200)")
        conn.commit()
        conn.close()

        results = self.ingester.from_sqlite(path, "SELECT * FROM items")
        self.assertEqual(len(results), 2)

    def test_sqlite_bad_query(self):
        path = os.path.join(self.tmpdir, "test.db")
        conn = sqlite3.connect(path)
        conn.execute("CREATE TABLE items (name TEXT)")
        conn.commit()
        conn.close()
        results = self.ingester.from_sqlite(path, "SELECT * FROM nonexistent")
        self.assertEqual(len(results), 0)

    def test_csv_nonexistent_file(self):
        results = self.ingester.from_csv("/nonexistent/path.csv")
        self.assertEqual(len(results), 0)

    def test_content_hash_present(self):
        path = os.path.join(self.tmpdir, "test.json")
        with open(path, "w") as f:
            json.dump([{"text": "some content"}], f)
        results = self.ingester.from_json(path)
        self.assertIn("content_hash", results[0])
        self.assertEqual(len(results[0]["content_hash"]), 16)


# ── IngestManifest tests ──────────────────────────────────────────────────

class TestIngestManifest(unittest.TestCase):

    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()

    def test_write_read_roundtrip(self):
        m = IngestManifest(self.tmpdir)
        m.update("http://example.com", "abc123", ["id1", "id2"])
        m.save()

        m2 = IngestManifest(self.tmpdir)
        entry = m2.get("http://example.com")
        self.assertIsNotNone(entry)
        self.assertEqual(entry["last_hash"], "abc123")
        self.assertIn("id1", entry["entry_ids"])

    def test_get_nonexistent(self):
        m = IngestManifest(self.tmpdir)
        self.assertIsNone(m.get("http://nope.com"))

    def test_update_upsert(self):
        m = IngestManifest(self.tmpdir)
        m.update("http://example.com", "hash1", ["id1"])
        m.update("http://example.com", "hash2", ["id2"])
        m.save()

        m2 = IngestManifest(self.tmpdir)
        entry = m2.get("http://example.com")
        self.assertIn("id1", entry["entry_ids"])
        self.assertIn("id2", entry["entry_ids"])

    def test_remove(self):
        m = IngestManifest(self.tmpdir)
        m.update("http://example.com", "hash1", ["id1"])
        m.remove("http://example.com")
        m.save()

        m2 = IngestManifest(self.tmpdir)
        self.assertIsNone(m2.get("http://example.com"))

    def test_known_hashes(self):
        m = IngestManifest(self.tmpdir)
        m.update("http://example.com", "hash1", ["id1"])
        m.update("http://example.com", "hash2", ["id2"])
        hashes = m.get_known_hashes("http://example.com")
        self.assertIn("hash1", hashes)
        self.assertIn("hash2", hashes)

    def test_known_hashes_empty(self):
        m = IngestManifest(self.tmpdir)
        hashes = m.get_known_hashes("http://nope.com")
        self.assertEqual(len(hashes), 0)

    def test_corrupt_recovery(self):
        # Write corrupt JSON
        path = os.path.join(self.tmpdir, "ingest_manifest.json")
        with open(path, "w") as f:
            f.write("{corrupted json!!!")

        # Should recover gracefully
        m = IngestManifest(self.tmpdir)
        self.assertIsNone(m.get("anything"))

    def test_corrupt_recovery_from_backup(self):
        # Write valid backup
        backup_path = os.path.join(self.tmpdir, "ingest_manifest.json.bak")
        with open(backup_path, "w") as f:
            json.dump({"sources": {"http://x.com": {"last_crawl_ts": 1, "last_hash": "h", "entry_ids": ["a"], "content_hashes": ["h"]}}}, f)

        # Write corrupt main
        path = os.path.join(self.tmpdir, "ingest_manifest.json")
        with open(path, "w") as f:
            f.write("NOT JSON")

        m = IngestManifest(self.tmpdir)
        entry = m.get("http://x.com")
        self.assertIsNotNone(entry)


# ── Core V4 integration tests ────────────────────────────────────────────

class TestCoreV4Integration(unittest.TestCase):

    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()

    def _make_system(self):
        import warnings
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            from parsica_memory.core_v4 import MemorySystemV4
            return MemorySystemV4(
                workspace=self.tmpdir,
                use_sharding=False,
                use_indexing=False,
                sharding=False,
                agent_name="test",
            )

    @patch("parsica_memory.ingest_web.urllib.request.urlopen")
    @patch("parsica_memory.ingest_web.urllib.robotparser.RobotFileParser")
    def test_ingest_url(self, mock_rp_cls, mock_urlopen):
        mock_rp = MagicMock()
        mock_rp.can_fetch.return_value = True
        mock_rp_cls.return_value = mock_rp

        html = b"<p>Knowledge base article with enough content to pass all the filtering requirements in the system.</p>"
        mock_resp = MagicMock()
        mock_resp.read.return_value = html
        mock_resp.headers.get_content_charset.return_value = "utf-8"
        mock_resp.__enter__ = lambda s: s
        mock_resp.__exit__ = MagicMock(return_value=False)
        mock_urlopen.return_value = mock_resp

        mem = self._make_system()
        result = mem.ingest_url("http://example.com/article")
        self.assertGreaterEqual(result["ingested"], 0)
        self.assertIn("source_url", result)

    def test_ingest_data_file_csv(self):
        path = os.path.join(self.tmpdir, "data.csv")
        with open(path, "w", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(["title", "body"])
            writer.writerow(["Article One", "This is the body of article one with enough text to pass"])
            writer.writerow(["Article Two", "This is the body of article two with enough text to pass"])

        mem = self._make_system()
        result = mem.ingest_data_file(path, format="csv")
        self.assertGreaterEqual(result["ingested"], 0)

    def test_ingest_sql(self):
        db_path = os.path.join(self.tmpdir, "test.db")
        conn = sqlite3.connect(db_path)
        conn.execute("CREATE TABLE docs (title TEXT, content TEXT)")
        conn.execute("INSERT INTO docs VALUES ('Doc1', 'Content of document one which is long enough to matter')")
        conn.commit()
        conn.close()

        mem = self._make_system()
        result = mem.ingest_sql(db_path, "SELECT * FROM docs")
        self.assertIn("ingested", result)

    def test_delete_source(self):
        mem = self._make_system()
        # Ingest with source_url
        mem.ingest("This is a test memory with enough content to pass the minimum length filter.",
                    source="test", source_url="http://example.com/page")
        self.assertTrue(any(getattr(m, "source_url", None) == "http://example.com/page"
                            for m in mem.memories))

        result = mem.delete_source("http://example.com/page")
        self.assertGreaterEqual(result["deleted"], 0)
        self.assertFalse(any(getattr(m, "source_url", None) == "http://example.com/page"
                             for m in mem.memories))

    def test_ingest_stamps_source_url(self):
        mem = self._make_system()
        mem.ingest("Memory content that is long enough to get past the fifteen character minimum.",
                    source="test", source_url="http://src.com", content_hash="abc123")
        tagged = [m for m in mem.memories if getattr(m, "source_url", None) == "http://src.com"]
        self.assertGreater(len(tagged), 0)
        self.assertEqual(tagged[0].content_hash, "abc123")

    @patch("parsica_memory.ingest_web.urllib.request.urlopen")
    @patch("parsica_memory.ingest_web.urllib.robotparser.RobotFileParser")
    def test_incremental_skip(self, mock_rp_cls, mock_urlopen):
        mock_rp = MagicMock()
        mock_rp.can_fetch.return_value = True
        mock_rp_cls.return_value = mock_rp

        html = b"<p>Repeated knowledge article content long enough to meet all minimum length requirements.</p>"
        mock_resp = MagicMock()
        mock_resp.read.return_value = html
        mock_resp.headers.get_content_charset.return_value = "utf-8"
        mock_resp.__enter__ = lambda s: s
        mock_resp.__exit__ = MagicMock(return_value=False)
        mock_urlopen.return_value = mock_resp

        mem = self._make_system()
        r1 = mem.ingest_url("http://example.com/article")
        r2 = mem.ingest_url("http://example.com/article")
        # Second run should skip duplicates
        self.assertGreaterEqual(r2["skipped_duplicates"], r1["ingested"])


if __name__ == "__main__":
    unittest.main()
