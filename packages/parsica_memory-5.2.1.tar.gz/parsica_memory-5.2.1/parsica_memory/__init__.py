"""
Antaris Memory — File-based persistent memory for AI agents.

Store, search, decay, and consolidate agent memories using only the
Python standard library. Zero dependencies, deterministic operations,
transparent JSON storage.

Usage:
    from parsica_memory import MemorySystem

    mem = MemorySystem("./workspace")
    mem.load()
    mem.ingest("Key decision made", source="meeting", category="strategic")
    results = mem.search("decision")
    mem.save()
"""

__version__ = "5.2.1"

from typing import TypedDict, List, Optional

class EnrichmentResult(TypedDict, total=False):
    """Return type for LLM enrichment callables passed to MemorySystem.

    All fields are optional. Missing fields are silently ignored.

    Example enricher::

        def my_enricher(text: str) -> EnrichmentResult:
            # Call your LLM here
            return {
                "tags": ["web_framework", "python", "backend"],
                "summary": "Team uses FastAPI as their Python web framework",
                "keywords": ["framework", "http", "api_server", "asgi"],
            }

        mem = MemorySystem("./store", enricher=my_enricher)
    """
    tags: List[str]        # Semantic concept tags (lowercase)
    summary: str           # Enriched, search-optimised restatement of the memory
    keywords: List[str]    # Additional search terms not in original text

# Core
from parsica_memory.core_v4 import MemorySystemV4 as MemorySystem
from parsica_memory.core_v4 import SemanticExpander
from parsica_memory.entry import MemoryEntry
from parsica_memory.decay import DecayEngine
from parsica_memory.sentiment import SentimentTagger
from parsica_memory.temporal import TemporalEngine
from parsica_memory.confidence import ConfidenceEngine
from parsica_memory.compression import CompressionEngine
from parsica_memory.forgetting import ForgettingEngine
from parsica_memory.consolidation import ConsolidationEngine
from parsica_memory.gating import InputGate
from parsica_memory.synthesis import KnowledgeSynthesizer

# Multi-agent
from parsica_memory.shared import SharedMemoryPool, AgentPermission

# Storage
from parsica_memory.sharding import ShardManager, ShardKey
from parsica_memory.migration import MigrationManager, Migration
from parsica_memory.indexing import IndexManager, SearchIndex, TagIndex, DateIndex

# Concurrency
from parsica_memory.locking import FileLock, LockTimeout
from parsica_memory.versioning import VersionTracker, ConflictError

# Search
from parsica_memory.search import SearchEngine, SearchResult, IntentReranker, QualifierAnalyzer
from parsica_memory.clustering import MemoryClusterer, ClusterIndex
from parsica_memory.calibration import LayerCalibrator, LayerWeights

# Context Packets (v1.1)
from parsica_memory.context_packet import ContextPacket, ContextPacketBuilder

# Recovery (v3.3.1)
from parsica_memory.recovery import RecoveryConfig, RecoveryManager

# Memory Types + Namespace Isolation (Sprint 2 + Sprint 8)
from parsica_memory.memory_types import MEMORY_TYPE_CONFIGS, get_type_config
from parsica_memory.namespace import NamespacedMemory, NamespaceManager

# Sprint 3 — Semantic utilities
from parsica_memory.utils import cosine_similarity

# v3.2 — Instrumentation + Co-occurrence (Tier 1 Semantic)
from parsica_memory.instrumentation import (
    SearchContext,
    extract_memory_references,
    anonymize_query,
    build_usage_signal,
)
from parsica_memory.cooccurrence import CooccurrenceIndex

# v4.5 — Semantic stack (Layers 1-6)
from parsica_memory.query_expansion import QueryExpander
from parsica_memory.category_tagger import CategoryTagger
from parsica_memory.windowing import WindowIndexer
from parsica_memory.ppmi_bootstrap import PPMIBootstrap

# v4.7 — Tiered Storage + Knowledge Ingestion
from parsica_memory.tiers import TierManager
from parsica_memory.ingest_web import WebCrawler
from parsica_memory.ingest_structured import StructuredIngester
from parsica_memory.ingest_manifest import IngestManifest

# v4.8 — Graph Intelligence + Consolidation + Team Memory
from parsica_memory.entity_extractor import EntityExtractor, Entity
from parsica_memory.graph import MemoryGraph, GraphNode, GraphEdge
from parsica_memory.consolidation_runner import ConsolidationRunner, ConsolidationReport
from parsica_memory.team_memory import SharedPool, AgentRole, AgentConfig

# v4.9 — Quality Routing + MCP Server + CLI
from parsica_memory.quality_router import QualityRouter, OutcomeTracker, QualitySignal
from parsica_memory.mcp_server import AntarisMCPServer

# v5.3 — MemoryManager + Provider Enrichers
from parsica_memory.manager import MemoryManager
from parsica_memory.enrichers import (
    anthropic_enricher,
    openai_enricher,
    gemini_enricher,
    local_enricher,
    auto_enricher,
)

# Backends (v4.2)
from parsica_memory.backends.gcs import GCSMemoryBackend

# Backward compatibility - import legacy core if needed
try:
    from parsica_memory.core import MemorySystem as LegacyMemorySystem
except ImportError:
    LegacyMemorySystem = None

# MCP Server (optional — requires 'mcp' package)
try:
    from parsica_memory.mcp_server import create_server as create_mcp_server
    MCP_AVAILABLE = True
except ImportError:
    # mcp package not installed — provide a helpful stub
    MCP_AVAILABLE = False

    def create_mcp_server(*args, **kwargs):  # type: ignore[misc]
        """Stub: install 'mcp' to use the MCP server. ``pip install mcp``"""
        raise ImportError(
            "The 'mcp' package is required. Install with: pip install mcp"
        )

__all__ = [
    "MemorySystem",
    "MemoryEntry",
    "SemanticExpander",
    
    # Core engines
    "DecayEngine",
    "SentimentTagger", 
    "TemporalEngine",
    "ConfidenceEngine",
    "CompressionEngine",
    "ForgettingEngine",
    "ConsolidationEngine",
    "InputGate",
    "KnowledgeSynthesizer",
    
    # Multi-agent (v0.3)
    "SharedMemoryPool",
    "AgentPermission",
    
    # Production features (v0.4)
    "ShardManager",
    "ShardKey", 
    "MigrationManager",
    "Migration",
    "IndexManager",
    "SearchIndex",
    "TagIndex",
    "DateIndex",
    
    # Concurrency (v0.5)
    "FileLock",
    "LockTimeout",
    "VersionTracker",
    "ConflictError",
    
    # Search (v1.0)
    "SearchEngine",
    "SearchResult",
    
    # Context Packets (v1.1)
    "ContextPacket",
    "ContextPacketBuilder",

    # Sprint 2 — Memory Types
    "MEMORY_TYPE_CONFIGS",
    "get_type_config",

    # Sprint 8 — Namespace Isolation
    "NamespacedMemory",
    "NamespaceManager",

    # Sprint 3 — Hybrid Semantic Search
    "cosine_similarity",   # pure-stdlib cosine similarity utility
    # MemorySystem.set_embedding_fn(fn)  — plug in an embedding callable
    # MemorySystem.search(...)           — uses hybrid BM25+cosine when fn is set

    # Sprint 5 — MCP Server
    "create_mcp_server",
    "MCP_AVAILABLE",

    # v3.2 — Instrumentation + Co-occurrence (Tier 1 Semantic)
    "SearchContext",
    "extract_memory_references",
    "anonymize_query",
    "build_usage_signal",
    "CooccurrenceIndex",

    # v4.2 — Backends
    "GCSMemoryBackend",

    # v4.5 — Semantic stack (Layers 1-6)
    "QueryExpander",     # Layer 1: synonym-based query expansion
    "CategoryTagger",    # Layer 2: auto-category detection on ingest + score boost
    "WindowIndexer",     # Layer 5: sliding window context grouping
    "PPMIBootstrap",     # Layer 6: static PPMI domain dictionary

    # v4.6.5 — LLM-enriched indexing
    "EnrichmentResult",  # TypedDict for enricher return values

    # v4.7 — Tiered Storage + Knowledge Ingestion
    "TierManager",         # Hot/warm/cold shard classification
    "WebCrawler",          # URL → memory ingestion
    "StructuredIngester",  # CSV/JSON/SQLite → memory ingestion
    "IngestManifest",      # Batch ingestion from manifest files

    # v4.8 — Graph Intelligence
    "EntityExtractor",     # Zero-dep named entity extraction
    "Entity",              # Entity dataclass
    "MemoryGraph",         # Knowledge graph with relationship-aware search
    "GraphNode",           # Graph node dataclass
    "GraphEdge",           # Graph edge dataclass

    # v4.8 — Nightly Consolidation
    "ConsolidationRunner", # TF-IDF extractive summarization + cold-tier reduction
    "ConsolidationReport", # Report dataclass from consolidation runs

    # v4.8 — Team Memory
    "SharedPool",          # Multi-agent shared memory with RBAC
    "AgentRole",           # Reader / Writer / Coordinator roles
    "AgentConfig",         # Per-agent role and trust config

    # v4.9 — Quality Routing + MCP Server + CLI
    "QualityRouter",       # Follow-up pattern detection → quality signals
    "OutcomeTracker",      # Persistent quality signal ledger
    "QualitySignal",       # Signal dataclass (useful / stale)
    "AntarisMCPServer",    # MCP server (stdlib JSON-RPC, stdio transport)

    # v5.3 — MemoryManager + Provider Enrichers
    "MemoryManager",       # Batteries-included wrapper with per-user isolation
    "anthropic_enricher",  # Anthropic Claude enricher factory
    "openai_enricher",     # OpenAI GPT enricher factory
    "gemini_enricher",     # Google Gemini enricher factory
    "local_enricher",      # Ollama / LM Studio / vLLM enricher factory
    "auto_enricher",       # Auto-detect best available enricher
]
