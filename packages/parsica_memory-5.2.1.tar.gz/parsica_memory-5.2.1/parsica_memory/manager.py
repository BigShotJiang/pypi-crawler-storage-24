"""
MemoryManager - batteries-included convenience layer for Parsica-Memory.

Provides per-user memory isolation, automatic noise filtering, sensible
cross-session defaults, and optional LLM enrichment out of the box.

Usage::

    from parsica_memory import MemoryManager

    # Basic - no enrichment (BM25-only, still good)
    mm = MemoryManager("./store")

    # With enrichment - pass any API key
    mm = MemoryManager("./store", api_key="sk-ant-...", provider="anthropic")

    # Auto-detect provider from env vars
    mm = MemoryManager("./store", auto_enrich=True)

    # Ingest a conversation turn
    mm.ingest("user123", "What's the weather?", "It's sunny in LA.")

    # Recall relevant memories
    results = mm.recall("user123", "weather")

    # Enrich all existing memories (backfill)
    mm.enrich_all("user123")

    # Export user memories to JSON
    mm.export("user123", "./export.json")

    # Stats
    mm.stats("user123")
"""

from __future__ import annotations

import json
import logging
import os
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional

try:
    from .core_v4 import MemorySystemV4 as MemorySystem
except ImportError:
    from parsica_memory.core_v4 import MemorySystemV4 as MemorySystem

logger = logging.getLogger(__name__)


class MemoryManager:
    """Batteries-included memory manager with per-user isolation.

    Each user gets their own ``MemorySystem`` backed by a sub-directory,
    keeping memories fully isolated.

    Args:
        store_path: Root directory for all user memory stores.
        search_limit: Max results per recall/search (default 10).
        min_relevance: Minimum relevance score 0-1 (default 0.3).
        api_key: Optional LLM API key for enrichment.
        provider: LLM provider - "anthropic", "openai", "gemini", "local", or "auto".
        model: Model override (uses sensible defaults per provider if omitted).
        auto_enrich: If True and no api_key given, auto-detect from env vars.
        agent_name: Name used in memory provenance (default "parsica").
    """

    def __init__(
        self,
        store_path: str,
        search_limit: int = 10,
        min_relevance: float = 0.3,
        api_key: Optional[str] = None,
        provider: Optional[str] = None,
        model: Optional[str] = None,
        auto_enrich: bool = False,
        agent_name: str = "parsica",
    ):
        self.store_path = Path(store_path)
        self.store_path.mkdir(parents=True, exist_ok=True)
        self.search_limit = search_limit
        self.min_relevance = min_relevance
        self.agent_name = agent_name
        self._stores: Dict[str, MemorySystem] = {}
        self._enricher = self._build_enricher(api_key, provider, model, auto_enrich)

    # ------------------------------------------------------------------
    # Enricher setup
    # ------------------------------------------------------------------

    def _build_enricher(self, api_key, provider, model, auto_enrich):
        """Build the enricher callable from the given config."""
        from .enrichers import (
            anthropic_enricher,
            openai_enricher,
            gemini_enricher,
            local_enricher,
            auto_enricher,
        )

        if api_key and provider:
            factories = {
                "anthropic": anthropic_enricher,
                "openai": openai_enricher,
                "gemini": gemini_enricher,
            }
            factory = factories.get(provider)
            if factory:
                kwargs = {"api_key": api_key}
                if model:
                    kwargs["model"] = model
                return factory(**kwargs)

        if api_key and not provider:
            # Guess provider from key format
            if api_key.startswith("sk-ant-"):
                return anthropic_enricher(api_key=api_key, model=model or "claude-sonnet-4-6")
            elif api_key.startswith("sk-"):
                return openai_enricher(api_key=api_key, model=model or "gpt-4o-mini")
            elif api_key.startswith("AI"):
                return gemini_enricher(api_key=api_key, model=model or "gemini-2.0-flash")

        if provider == "local":
            return local_enricher(model=model or "llama3.2")

        if provider == "auto" or auto_enrich:
            return auto_enricher()

        return None

    # ------------------------------------------------------------------
    # Store management
    # ------------------------------------------------------------------

    def _get_store(self, user_id: str) -> MemorySystem:
        """Get or create a MemorySystem for a specific user."""
        if user_id not in self._stores:
            user_path = self.store_path / user_id
            user_path.mkdir(parents=True, exist_ok=True)
            store = MemorySystem(
                workspace=str(user_path),
                agent_name=self.agent_name,
                enricher=self._enricher,
            )
            try:
                store.load()
            except Exception:
                pass  # First use - no data yet
            self._stores[user_id] = store
        return self._stores[user_id]

    # ------------------------------------------------------------------
    # Noise filter
    # ------------------------------------------------------------------

    @staticmethod
    def _should_skip(text: str) -> bool:
        """Return True if text is noise that shouldn't be stored."""
        if not text or not text.strip():
            return True
        stripped = text.strip()
        if len(stripped) < 20:
            return True
        if not re.search(r"[a-zA-Z0-9]", stripped):
            return True
        # Common framework noise
        noise_prefixes = (
            "## Context Packet",
            "### Relevant Context",
            "*Packet built",
            "[Queued messages",
            "<ContextPacket",
            "[System Message]",
            "HEARTBEAT_OK",
        )
        for prefix in noise_prefixes:
            if stripped.startswith(prefix):
                return True
        return False

    # ------------------------------------------------------------------
    # Core API
    # ------------------------------------------------------------------

    def ingest(
        self,
        user_id: str,
        user_message: str,
        bot_response: str,
        session_id: str = "",
        channel_id: str = "",
        source: str = "conversation",
    ) -> bool:
        """Store a conversation turn in memory.

        Skips noise automatically. Enriches at ingest time if an enricher
        is configured. Saves to disk immediately.

        Returns True if ingested, False if skipped.
        """
        if self._should_skip(user_message) or self._should_skip(bot_response):
            return False
        try:
            store = self._get_store(user_id)
            content = f"User: {user_message}\nAssistant: {bot_response}"
            kwargs = {"source": source, "category": "chat"}
            if session_id:
                kwargs["session_id"] = session_id
            if channel_id:
                kwargs["channel_id"] = channel_id
            store.ingest(content, **kwargs)
            store.save()
            return True
        except Exception as e:
            logger.warning("Memory ingest failed: %s", e)
            return False

    def ingest_raw(
        self,
        user_id: str,
        content: str,
        source: str = "manual",
        category: str = "note",
        session_id: str = "",
        **kwargs,
    ) -> bool:
        """Ingest arbitrary content (not a conversation turn).

        Use for documents, notes, facts, or anything that isn't a
        user/bot exchange.
        """
        if self._should_skip(content):
            return False
        try:
            store = self._get_store(user_id)
            ingest_kwargs = {"source": source, "category": category}
            if session_id:
                ingest_kwargs["session_id"] = session_id
            ingest_kwargs.update(kwargs)
            store.ingest(content, **ingest_kwargs)
            store.save()
            return True
        except Exception as e:
            logger.warning("Raw ingest failed: %s", e)
            return False

    def recall(
        self,
        user_id: str,
        query: str,
        session_id: str = "",
        limit: Optional[int] = None,
    ) -> List[str]:
        """Recall relevant memories as a list of content strings.

        Uses cross-session semantic recall by default - facts and decisions
        cross session boundaries, episodic chatter stays scoped.
        """
        try:
            store = self._get_store(user_id)
            search_kwargs = {
                "limit": limit or self.search_limit,
                "use_decay": True,
                "cross_session_recall": "semantic",
            }
            if session_id:
                search_kwargs["session_id"] = session_id
            results = store.search(query, **search_kwargs)
            return [
                r.content
                for r in results
                if self._get_score(r) >= self.min_relevance
            ]
        except Exception as e:
            logger.warning("Memory recall failed: %s", e)
            return []

    def search(
        self,
        user_id: str,
        query: str,
        session_id: str = "",
        limit: Optional[int] = None,
        explain: bool = False,
    ) -> List[dict]:
        """Search memories with full metadata.

        Returns list of dicts with content, relevance, source, category,
        matched_terms, and optionally explanation.
        """
        try:
            store = self._get_store(user_id)
            search_kwargs = {
                "limit": limit or self.search_limit,
                "use_decay": True,
                "explain": explain,
                "cross_session_recall": "semantic",
            }
            if session_id:
                search_kwargs["session_id"] = session_id
            results = store.search(query, **search_kwargs)
            return [
                {
                    "content": r.content,
                    "relevance": self._get_score(r),
                    "source": getattr(r, "source", ""),
                    "category": getattr(r, "category", ""),
                    "matched_terms": getattr(r, "matched_terms", []),
                    "explanation": getattr(r, "explanation", "") if explain else "",
                }
                for r in results
            ]
        except Exception as e:
            logger.warning("Memory search failed: %s", e)
            return []

    # ------------------------------------------------------------------
    # Enrichment
    # ------------------------------------------------------------------

    def enrich_all(
        self,
        user_id: str,
        overwrite: bool = False,
        progress_fn=None,
    ) -> int:
        """Batch-enrich all existing memories for a user.

        Requires an enricher to be configured. Skips already-enriched
        entries unless overwrite=True.

        Returns count of entries enriched.
        """
        if self._enricher is None:
            logger.warning("No enricher configured - call with api_key or auto_enrich=True")
            return 0
        try:
            store = self._get_store(user_id)
            return store.re_enrich(overwrite=overwrite, progress_fn=progress_fn)
        except Exception as e:
            logger.warning("Batch enrichment failed: %s", e)
            return 0

    # ------------------------------------------------------------------
    # Utility
    # ------------------------------------------------------------------

    def stats(self, user_id: Optional[str] = None) -> dict:
        """Memory stats for a user or aggregate across all users."""
        if user_id is not None:
            try:
                store = self._get_store(user_id)
                s = store.stats()
                user_path = self.store_path / user_id
                size = sum(f.stat().st_size for f in user_path.rglob("*") if f.is_file())
                files = [f for f in user_path.rglob("*") if f.is_file()]
                oldest = newest = None
                if files:
                    mtimes = sorted(f.stat().st_mtime for f in files)
                    oldest = datetime.fromtimestamp(mtimes[0], tz=timezone.utc).isoformat()
                    newest = datetime.fromtimestamp(mtimes[-1], tz=timezone.utc).isoformat()
                return {
                    "user_id": user_id,
                    "entry_count": s.get("total", 0),
                    "store_size_bytes": size,
                    "oldest_entry": oldest,
                    "newest_entry": newest,
                    "enricher_active": self._enricher is not None,
                }
            except Exception as e:
                return {"user_id": user_id, "error": str(e)}

        total = 0
        per_user = {}
        for uid in self._stores:
            try:
                s = self._stores[uid].stats()
                c = s.get("total", 0)
                per_user[uid] = c
                total += c
            except Exception:
                per_user[uid] = 0
        return {
            "user_count": len(self._stores),
            "total_entries": total,
            "per_user": per_user,
            "enricher_active": self._enricher is not None,
        }

    def export(self, user_id: str, output_path: str) -> int:
        """Export all memories for a user to a JSON file.

        Returns count of exported entries.
        """
        try:
            store = self._get_store(user_id)
            results = store.search("", limit=10_000)
            entries = [
                {
                    "content": getattr(r, "content", ""),
                    "score": self._get_score(r),
                    "timestamp": getattr(r, "timestamp", None),
                    "source": getattr(r, "source", ""),
                    "category": getattr(r, "category", ""),
                }
                for r in results
            ]
            data = {
                "user_id": user_id,
                "exported_at": datetime.now(tz=timezone.utc).isoformat(),
                "entry_count": len(entries),
                "entries": entries,
            }
            out = Path(output_path)
            out.parent.mkdir(parents=True, exist_ok=True)
            out.write_text(json.dumps(data, indent=2, default=str))
            return len(entries)
        except Exception as e:
            logger.warning("Export failed: %s", e)
            return 0

    def clear(self, user_id: str) -> int:
        """Delete all memory files for a user. Returns count of deleted files."""
        try:
            user_path = self.store_path / user_id
            if not user_path.exists():
                return 0
            files = [f for f in user_path.rglob("*") if f.is_file()]
            count = len(files)
            for f in files:
                f.unlink()
            for d in sorted(user_path.rglob("*"), reverse=True):
                if d.is_dir() and d != user_path:
                    try:
                        d.rmdir()
                    except OSError:
                        pass
            self._stores.pop(user_id, None)
            return count
        except Exception as e:
            logger.warning("Clear failed: %s", e)
            return 0

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _get_score(result) -> float:
        """Extract relevance score from a search result."""
        for attr in ("relevance", "score", "confidence"):
            val = getattr(result, attr, None)
            if val is not None:
                return float(val)
        return 1.0
