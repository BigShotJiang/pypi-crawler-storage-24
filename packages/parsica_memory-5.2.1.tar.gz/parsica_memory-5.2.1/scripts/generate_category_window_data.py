#!/usr/bin/env python3
"""
Generate auto_categories.json and topic_windows.json from embedding data.

Part A: Cluster memories by embedding, extract keywords, assign category labels.
Part B: Detect topic boundaries via cosine similarity drops between consecutive memories.

Usage:
    python3 scripts/generate_category_window_data.py
"""

import json
import os
import re
import sys
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np

# Paths
REPO = Path(__file__).resolve().parent.parent
STORE = Path(os.environ.get(
    "ANTARIS_MEMORY_STORE",
    str(REPO.parent.parent / "parsica_memory_store"),
))
EMBEDDINGS_PATH = STORE / ".enrichment_cache" / "embeddings.npy"
HASHES_PATH = STORE / ".enrichment_cache" / "hashes.txt"
SHARDS_DIR = STORE / "shards"
CLUSTERS_PATH = REPO / "parsica_memory" / "data" / "embedding_clusters.json"
DATA_DIR = REPO / "parsica_memory" / "data"

# Stop words for keyword extraction
STOP_WORDS = frozenset(
    "the a an is are was were be been being have has had do does did will would "
    "shall should may might can could of in to for on with at by from as into "
    "through during before after above below between under over again further "
    "then once here there when where why how all both each few more most other "
    "some such no nor not only own same so than too very just about also back "
    "but if or because until while that this these those it its he she they them "
    "his her their my your we our what which who whom and i you me us him don "
    "doesn didn isn wasn weren hasn hadn wouldn couldn shouldn ve ll re d s t m "
    "get got like really still even much thing things one two way make sure need "
    "want going go know think said says let try tried use used using something "
    "anything everything nothing well good new first last long right now already "
    "yes yeah no ok okay hey hi hello thanks thank please sorry actually "
    "message memory search query".split()
)


def load_shards():
    """Load all memory shards, return dict of hash -> shard data."""
    memories = {}
    for shard_file in sorted(SHARDS_DIR.glob("*.json")):
        with open(shard_file) as f:
            try:
                data = json.load(f)
            except json.JSONDecodeError:
                continue
        entries = data.get("memories", [])
        for entry in entries:
            h = entry.get("hash") or entry.get("id")
            if h:
                memories[h] = entry
    return memories


def extract_keywords(texts, top_n=10):
    """Extract top meaningful words from a list of texts."""
    word_counts = Counter()
    for text in texts:
        words = re.findall(r"[a-z][a-z_\-]{2,}", text.lower())
        for w in words:
            if w not in STOP_WORDS and len(w) > 2:
                word_counts[w] += 1
    return [w for w, _ in word_counts.most_common(top_n)]


def assign_category_label(keywords):
    """Heuristic: assign a snake_case category label from top keywords."""
    # Map keyword patterns to category names
    label_hints = {
        "python_development": ["python", "pip", "pypi", "pytest", "django", "flask"],
        "javascript_web": ["javascript", "react", "node", "npm", "typescript", "html", "css", "webpack"],
        "devops_infrastructure": ["docker", "kubernetes", "deploy", "nginx", "server", "terraform", "ansible", "ci/cd", "pipeline"],
        "database_storage": ["database", "postgres", "mysql", "redis", "mongo", "sql", "migration", "schema"],
        "ai_ml": ["model", "training", "embedding", "neural", "transformer", "llm", "gpt", "claude", "openai", "anthropic", "inference"],
        "financial": ["cost", "price", "budget", "expense", "bill", "payment", "subscription", "revenue"],
        "security_auth": ["security", "auth", "token", "password", "credential", "vulnerability", "encryption"],
        "project_management": ["sprint", "roadmap", "milestone", "release", "ship", "deadline", "task", "project", "plan"],
        "communication": ["discord", "slack", "email", "message", "chat", "notification", "channel"],
        "personal": ["gym", "workout", "health", "food", "recipe", "movie", "music", "game", "travel"],
        "api_integration": ["api", "endpoint", "webhook", "rest", "graphql", "request", "response"],
        "testing_qa": ["test", "testing", "pytest", "unittest", "coverage", "bug", "fix", "debug"],
        "documentation": ["docs", "documentation", "readme", "guide", "tutorial", "wiki"],
        "data_analysis": ["data", "analysis", "chart", "graph", "metric", "dashboard", "report", "analytics"],
        "networking": ["network", "dns", "http", "tcp", "proxy", "vpn", "tailscale", "ssh"],
        "memory_system": ["memory", "shard", "search", "recall", "antaris", "enrichment", "embedding", "consolidation"],
        "configuration": ["config", "setting", "environment", "variable", "yaml", "json", "toml"],
        "git_version_control": ["git", "commit", "branch", "merge", "pull", "push", "repo", "github"],
    }
    
    kw_set = set(keywords)
    scores = {}
    for label, hints in label_hints.items():
        score = sum(1 for h in hints if h in kw_set or any(h in k for k in kw_set))
        if score > 0:
            scores[label] = score
    
    if scores:
        return max(scores, key=scores.get)
    # Fallback: use top two keywords
    if len(keywords) >= 2:
        return f"{keywords[0]}_{keywords[1]}"
    elif keywords:
        return keywords[0]
    return "uncategorized"


def generate_auto_categories(memories, clusters_data):
    """Part A: Generate auto_categories.json."""
    print("Generating auto_categories.json...")
    
    h2c = clusters_data["hash_to_cluster"]
    
    # Group hashes by cluster
    cluster_hashes = defaultdict(list)
    for h, cid in h2c.items():
        cluster_hashes[cid].append(h)
    
    # For each cluster, extract keywords from memory content
    cluster_keywords = {}
    for cid, hashes in cluster_hashes.items():
        texts = []
        for h in hashes:
            mem = memories.get(h)
            if not mem:
                continue
            content = mem.get("content", "") or mem.get("text", "") or ""
            texts.append(content)
            kws = mem.get("search_keywords")
            if kws:
                if isinstance(kws, list):
                    texts.append(" ".join(kws))
                else:
                    texts.append(str(kws))
        cluster_keywords[cid] = extract_keywords(texts, top_n=15)
    
    # Assign labels and group clusters into categories
    cluster_labels = {}
    for cid, kws in cluster_keywords.items():
        cluster_labels[cid] = assign_category_label(kws)
    
    # Group clusters by label
    label_clusters = defaultdict(list)
    for cid, label in cluster_labels.items():
        label_clusters[label].append(cid)
    
    # Build categories dict
    categories = {}
    for label, cids in sorted(label_clusters.items()):
        # Merge keywords from all clusters in this category
        all_kws = Counter()
        for cid in cids:
            for w in cluster_keywords.get(cid, []):
                all_kws[w] += 1
        top_kws = [w for w, _ in all_kws.most_common(10)]
        
        total_size = sum(clusters_data["clusters"].get(str(cid), {}).get("size", 0) for cid in cids)
        categories[label] = {
            "cluster_ids": sorted(cids),
            "keywords": top_kws,
            "description": f"Auto-discovered: {label.replace('_', ' ')} ({total_size} memories across {len(cids)} clusters)",
        }
    
    # Build hash_to_categories
    hash_to_categories = defaultdict(list)
    for h, cid in h2c.items():
        label = cluster_labels.get(cid, "uncategorized")
        hash_to_categories[h].append(label)
    
    result = {
        "description": "Auto-discovered categories from embedding clusters. Supplements regex categories.",
        "model": "google/embeddinggemma-300m",
        "n_categories": len(categories),
        "n_memories": len(hash_to_categories),
        "categories": categories,
        "hash_to_categories": dict(hash_to_categories),
    }
    
    out_path = DATA_DIR / "auto_categories.json"
    with open(out_path, "w") as f:
        json.dump(result, f, indent=2)
    print(f"  Written {out_path} ({len(categories)} categories, {len(hash_to_categories)} memories)")
    return result


def generate_topic_windows(memories, embeddings, hashes):
    """Part B: Generate topic_windows.json."""
    print("Generating topic_windows.json...")
    
    # Build hash -> embedding index
    hash_to_idx = {h: i for i, h in enumerate(hashes)}
    
    # Sort memories by timestamp
    timed = []
    for h, mem in memories.items():
        ts = mem.get("created_at") or mem.get("timestamp") or mem.get("created") or ""
        if ts and h in hash_to_idx:
            timed.append((ts, h))
    timed.sort(key=lambda x: x[0])
    
    if not timed:
        print("  ERROR: No timestamped memories found!")
        return
    
    print(f"  {len(timed)} memories with timestamps and embeddings")
    
    # Compute cosine similarities between consecutive memories
    sims = []
    for i in range(1, len(timed)):
        idx_prev = hash_to_idx[timed[i - 1][1]]
        idx_curr = hash_to_idx[timed[i][1]]
        e_prev = embeddings[idx_prev]
        e_curr = embeddings[idx_curr]
        norm_prev = np.linalg.norm(e_prev)
        norm_curr = np.linalg.norm(e_curr)
        if norm_prev > 0 and norm_curr > 0:
            sims.append(float(np.dot(e_prev, e_curr) / (norm_prev * norm_curr)))
        else:
            sims.append(0.0)
    
    # Use adaptive threshold: 5th percentile of similarities
    # This gives ~500 windows with meaningful topic coherence
    sims_arr = np.array(sims)
    threshold = round(float(np.percentile(sims_arr, 5)), 4)
    print(f"  Adaptive threshold (p5): {threshold}")
    
    windows = []
    window_hashes = [timed[0][1]]
    
    for i, sim in enumerate(sims):
        if sim < threshold:
            windows.append(window_hashes)
            window_hashes = [timed[i + 1][1]]
        else:
            window_hashes.append(timed[i + 1][1])
    
    # Close last window
    if window_hashes:
        windows.append(window_hashes)
    
    print(f"  Detected {len(windows)} topic windows")
    
    # Build output
    hash_to_window = {}
    window_entries = []
    
    for wid, w_hashes in enumerate(windows):
        for h in w_hashes:
            hash_to_window[h] = wid
        
        # Extract keywords
        texts = []
        for h in w_hashes:
            mem = memories.get(h)
            if mem:
                content = mem.get("content", "") or mem.get("text", "") or ""
                texts.append(content)
                kws = mem.get("search_keywords")
                if kws:
                    texts.append(" ".join(kws) if isinstance(kws, list) else str(kws))
        
        # Compute avg internal similarity
        if len(w_hashes) > 1:
            sims = []
            for j in range(len(w_hashes) - 1):
                idx_a = hash_to_idx[w_hashes[j]]
                idx_b = hash_to_idx[w_hashes[j + 1]]
                ea, eb = embeddings[idx_a], embeddings[idx_b]
                na, nb = np.linalg.norm(ea), np.linalg.norm(eb)
                if na > 0 and nb > 0:
                    sims.append(float(np.dot(ea, eb) / (na * nb)))
            avg_sim = round(sum(sims) / len(sims), 4) if sims else 0.0
        else:
            avg_sim = 1.0
        
        window_entries.append({
            "id": wid,
            "start_hash": w_hashes[0],
            "end_hash": w_hashes[-1],
            "size": len(w_hashes),
            "top_keywords": extract_keywords(texts, top_n=5),
            "avg_internal_similarity": avg_sim,
        })
    
    result = {
        "description": "Topic-coherent windows detected by embedding similarity drops between consecutive memories",
        "method": "cosine_drop_threshold",
        "threshold": threshold,
        "n_windows": len(windows),
        "n_memories": len(hash_to_window),
        "windows": window_entries,
        "hash_to_window": hash_to_window,
    }
    
    out_path = DATA_DIR / "topic_windows.json"
    with open(out_path, "w") as f:
        json.dump(result, f, indent=2)
    print(f"  Written {out_path} ({len(windows)} windows, {len(hash_to_window)} memories)")
    return result


def main():
    print("Loading data...")
    
    # Load clusters
    with open(CLUSTERS_PATH) as f:
        clusters_data = json.load(f)
    print(f"  Clusters: {clusters_data['n_clusters']}")
    
    # Load embeddings
    embeddings = np.load(EMBEDDINGS_PATH)
    print(f"  Embeddings: {embeddings.shape}")
    
    # Load hashes
    with open(HASHES_PATH) as f:
        hashes = [line.strip() for line in f if line.strip()]
    print(f"  Hashes: {len(hashes)}")
    
    # Load memory shards
    memories = load_shards()
    print(f"  Memories: {len(memories)}")
    
    # Part A
    generate_auto_categories(memories, clusters_data)
    
    # Part B
    generate_topic_windows(memories, embeddings, hashes)
    
    print("\nDone!")


if __name__ == "__main__":
    main()
