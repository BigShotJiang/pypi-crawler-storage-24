#!/usr/bin/env python3.14
"""
Generate expanded semantic_expansion.json from cached embeddings + memory corpus.

Algorithm:
1. Load all memory content from shards
2. Build word→memory_indices mapping (words appearing in 3+ memories)
3. Load cached embeddings (aligned with hashes.txt)
4. Build hash→embedding_index mapping
5. For each word, average the embeddings of memories containing it → "word embedding"
6. Compute cosine similarity between all word embeddings
7. For each word, pick top-8 most similar words (cosine > 0.7) as expansions
"""

import json
import re
import sys
import os
import numpy as np
from pathlib import Path
from collections import Counter, defaultdict
from datetime import datetime

# Paths
STORE = Path(os.getenv("ANTARIS_MEMORY_STORE", Path.home() / ".openclaw/workspace/parsica_memory_store"))
REPO = Path(__file__).parent.parent
SHARDS_DIR = STORE / "shards"
EMBEDDINGS_PATH = STORE / ".enrichment_cache" / "embeddings.npy"
HASHES_PATH = STORE / ".enrichment_cache" / "hashes.txt"
OUTPUT_PATH = REPO / "parsica_memory" / "data" / "semantic_expansion.json"
META_PATH = REPO / "parsica_memory" / "data" / "enrichment_meta.json"

# Stopwords - common English words that shouldn't be expansion terms
STOPWORDS = {
    'the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for',
    'of', 'with', 'by', 'from', 'is', 'was', 'are', 'were', 'be', 'been',
    'being', 'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would',
    'could', 'should', 'may', 'might', 'shall', 'can', 'need', 'must',
    'it', 'its', 'this', 'that', 'these', 'those', 'i', 'me', 'my', 'we',
    'our', 'you', 'your', 'he', 'him', 'his', 'she', 'her', 'they', 'them',
    'their', 'what', 'which', 'who', 'whom', 'where', 'when', 'why', 'how',
    'all', 'each', 'every', 'both', 'few', 'more', 'most', 'other', 'some',
    'such', 'no', 'not', 'only', 'own', 'same', 'so', 'than', 'too', 'very',
    'just', 'because', 'as', 'until', 'while', 'about', 'between', 'through',
    'during', 'before', 'after', 'above', 'below', 'up', 'down', 'out', 'off',
    'over', 'under', 'again', 'further', 'then', 'once', 'here', 'there',
    'also', 'if', 'into', 'like', 'get', 'got', 'still', 'back', 'make',
    'made', 'go', 'going', 'gone', 'went', 'come', 'came', 'take', 'took',
    'say', 'said', 'see', 'seen', 'saw', 'know', 'knew', 'think', 'thought',
    'want', 'wanted', 'use', 'used', 'using', 'find', 'found', 'give', 'gave',
    'tell', 'told', 'try', 'tried', 'put', 'let', 'keep', 'kept', 'set',
    'seem', 'seemed', 'show', 'showed', 'shown', 'look', 'looked', 'call',
    'called', 'thing', 'things', 'way', 'ways', 'much', 'many', 'even',
    'new', 'old', 'well', 'good', 'great', 'right', 'long', 'little', 'big',
    'small', 'high', 'low', 'first', 'last', 'next', 'now', 'really',
    'already', 'always', 'never', 'sometimes', 'often', 'however', 'though',
    'although', 'yet', 'since', 'been', 'done', 'something', 'anything',
    'nothing', 'everything', 'someone', 'anyone', 'everyone', 'nobody',
    'yes', 'no', 'ok', 'okay', 'sure', 'yeah', 'nah', 'hey', 'hi', 'hello',
    'thanks', 'thank', 'please', 'sorry', 'etc', 'one', 'two', 'three',
    'don', 'doesn', 'didn', 'won', 'wouldn', 'couldn', 'shouldn', 'isn',
    'wasn', 'aren', 'weren', 'hasn', 'haven', 'hadn', 'll', 've', 're',
}

WORD_RE = re.compile(r'[a-z][a-z_-]{1,30}')

def load_memories():
    """Load all memories from shards, return list of (hash, content_text)."""
    memories = []
    for shard_file in sorted(SHARDS_DIR.glob("shard_*.json")):
        with open(shard_file) as f:
            data = json.load(f)
        for mem in data.get("memories", []):
            h = mem.get("hash", "")
            # Combine content + tags + search_keywords for richer word extraction
            parts = [mem.get("content", "")]
            if mem.get("tags"):
                parts.append(" ".join(mem["tags"]))
            if mem.get("search_keywords"):
                parts.append(" ".join(mem["search_keywords"]))
            memories.append((h, " ".join(parts)))
    return memories

def extract_words(text):
    """Extract lowercase words from text."""
    return set(WORD_RE.findall(text.lower()))

def main():
    print("Loading memories...")
    memories = load_memories()
    print(f"  Loaded {len(memories)} memories")

    print("Loading embeddings...")
    embeddings = np.load(EMBEDDINGS_PATH)
    hashes = [line.strip() for line in open(HASHES_PATH)]
    print(f"  Embeddings shape: {embeddings.shape}, hashes: {len(hashes)}")

    # Build hash→embedding index
    hash_to_idx = {h: i for i, h in enumerate(hashes)}

    # Build word→memory indices and word frequency
    print("Building word index...")
    word_to_mem_indices = defaultdict(list)
    for i, (h, text) in enumerate(memories):
        if h not in hash_to_idx:
            continue  # skip memories without embeddings
        words = extract_words(text)
        for w in words:
            if w not in STOPWORDS and len(w) >= 3:
                word_to_mem_indices[w].append(i)

    # Filter to words with 3+ occurrences
    word_to_mem_indices = {w: idxs for w, idxs in word_to_mem_indices.items() if len(idxs) >= 2}
    print(f"  {len(word_to_mem_indices)} unique words (freq >= 3)")

    # Build word embeddings by averaging memory embeddings
    print("Computing word embeddings...")
    words = sorted(word_to_mem_indices.keys())
    word_embeddings = np.zeros((len(words), embeddings.shape[1]), dtype=np.float32)

    for i, w in enumerate(words):
        mem_indices = word_to_mem_indices[w]
        emb_indices = []
        for mi in mem_indices:
            h = memories[mi][0]
            if h in hash_to_idx:
                emb_indices.append(hash_to_idx[h])
        if emb_indices:
            word_embeddings[i] = embeddings[emb_indices].mean(axis=0)

    # Normalize for cosine similarity
    norms = np.linalg.norm(word_embeddings, axis=1, keepdims=True)
    norms[norms == 0] = 1
    word_embeddings_normed = word_embeddings / norms

    # Compute similarities in batches to avoid memory issues
    print("Computing similarities...")
    MIN_SIM = 0.72
    MAX_EXPANSIONS = 8
    expansion = {}

    BATCH = 500
    for start in range(0, len(words), BATCH):
        end = min(start + BATCH, len(words))
        # (batch_size, dim) @ (dim, total) → (batch_size, total)
        sims = word_embeddings_normed[start:end] @ word_embeddings_normed.T

        for i_local in range(end - start):
            i_global = start + i_local
            row = sims[i_local]
            row[i_global] = 0  # exclude self

            # Get indices above threshold
            mask = row >= MIN_SIM
            if not mask.any():
                continue

            candidates = np.where(mask)[0]
            candidate_sims = row[candidates]

            # Sort by similarity descending, take top K
            top_k = candidates[np.argsort(-candidate_sims)][:MAX_EXPANSIONS]
            synonyms = [words[j] for j in top_k]

            if synonyms:
                expansion[words[i_global]] = synonyms

        if (end) % 1000 == 0 or end == len(words):
            print(f"  Processed {end}/{len(words)} words, {len(expansion)} with expansions")

    # Add metadata
    result = {
        "_meta": {
            "version": "2.0.0",
            "built": datetime.now().strftime("%Y-%m-%d"),
            "entries": len(expansion),
            "description": "Auto-generated semantic expansion index from embeddinggemma-300m embeddings over 10K+ memories.",
            "model": "google/embeddinggemma-300m",
            "min_similarity": MIN_SIM,
            "max_expansions": MAX_EXPANSIONS,
            "min_word_frequency": 2,
            "corpus_size": len(memories)
        }
    }
    # Sort alphabetically
    for w in sorted(expansion.keys()):
        result[w] = expansion[w]

    print(f"\nWriting {len(expansion)} entries to {OUTPUT_PATH}")
    with open(OUTPUT_PATH, 'w') as f:
        json.dump(result, f, indent=2)

    # Write enrichment meta
    meta = {
        "model": "google/embeddinggemma-300m",
        "embedding_dim": int(embeddings.shape[1]),
        "corpus_size": len(memories),
        "embeddings_cached": int(embeddings.shape[0]),
        "generated": datetime.now().isoformat(),
        "semantic_expansion_entries": len(expansion),
        "unique_words_analyzed": len(words),
        "min_similarity": MIN_SIM,
        "max_expansions": MAX_EXPANSIONS,
    }
    print(f"Writing enrichment meta to {META_PATH}")
    with open(META_PATH, 'w') as f:
        json.dump(meta, f, indent=2)

    print("Done!")

if __name__ == "__main__":
    main()
