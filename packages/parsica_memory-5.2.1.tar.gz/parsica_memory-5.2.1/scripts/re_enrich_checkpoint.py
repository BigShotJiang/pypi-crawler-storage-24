#!/usr/bin/env python3
"""
Fault-tolerant re-enrichment with checkpointing.
- Saves progress every CHECKPOINT_EVERY entries
- Skips already-enriched entries on restart (idempotent)
- Logs progress to a file for external monitoring
- 8 parallel workers for speed
"""
import sys, os, time, json, warnings
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
sys.stdout.reconfigure(line_buffering=True)
warnings.filterwarnings('ignore')
from urllib.request import Request, urlopen

API_KEY = "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"
MODEL = "claude-sonnet-4-20250514"
WORKERS = 8
CHECKPOINT_EVERY = 200  # save to disk every N entries
STORE_PATH = '/Users/moro/.openclaw/workspace/parsica_memory_store'
PROGRESS_FILE = '/tmp/enrichment_progress.json'
LOG_FILE = '/tmp/enrichment.log'

PROMPT = (
    "Analyze this memory/note and extract semantic metadata to improve search recall.\n"
    "Focus on SYNONYMS and RELATED CONCEPTS that someone might use when searching.\n"
    "Return ONLY a valid JSON object with exactly these fields:\n"
    '- "tags": 5-10 snake_case semantic labels\n'
    '- "summary": one sentence rephrasing the core fact using DIFFERENT vocabulary than the original\n'
    '- "keywords": 8-15 terms someone might search to find this memory\n'
    '- "search_queries": 3 SPECIFIC natural language questions that ONLY this exact memory answers. '
    'Include exact names, version numbers, decisions. Each must be discriminative.\n\n'
    "Memory:\n{text}\n\nJSON:"
)

def log(msg):
    ts = time.strftime('%H:%M:%S')
    line = f'[{ts}] {msg}'
    print(line, flush=True)
    with open(LOG_FILE, 'a') as f:
        f.write(line + '\n')

def enrich_one(args):
    h, content = args
    try:
        url = "https://api.anthropic.com/v1/messages"
        payload = json.dumps({
            "model": MODEL,
            "max_tokens": 400,
            "messages": [{"role": "user", "content": PROMPT.format(text=content[:800])}],
        })
        req = Request(url, data=payload.encode("utf-8"), method="POST")
        req.add_header("Content-Type", "application/json")
        req.add_header("x-api-key", API_KEY)
        req.add_header("anthropic-version", "2023-06-01")
        with urlopen(req, timeout=30) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            raw = data["content"][0]["text"].strip()
            start = raw.find('{'); end = raw.rfind('}')
            if start != -1 and end > start:
                return h, json.loads(raw[start:end+1]), None
        return h, None, "empty response"
    except Exception as e:
        return h, None, str(e)[:100]

def save_checkpoint(ms, enriched, errors, total):
    ms.search_engine.mark_dirty()
    ms.search_engine.build_index(ms.memories)
    ms._save_sharded()
    progress = {"enriched": enriched, "errors": errors, "total": total, "ts": time.time()}
    with open(PROGRESS_FILE, 'w') as f:
        json.dump(progress, f)
    log(f'CHECKPOINT saved — {enriched}/{total} enriched, {errors} errors')

log(f'Starting fault-tolerant re-enrichment ({WORKERS} workers, checkpoint every {CHECKPOINT_EVERY})')
log(f'Model: {MODEL} | Store: {STORE_PATH}')

# Load previous progress if any
prev = {}
if os.path.exists(PROGRESS_FILE):
    try:
        with open(PROGRESS_FILE) as f:
            prev = json.load(f)
        log(f'Previous run found: {prev.get("enriched",0)}/{prev.get("total",0)} done')
    except: pass

from parsica_memory import MemorySystem
ms = MemorySystem(workspace=STORE_PATH, agent_name='moro')
ms.load()

total = len(ms.memories)
log(f'Loaded {total} memories')

# Only enrich entries missing search_queries (skip already-enriched = fault-tolerant restart)
to_enrich = []
already_done = 0
for m in ms.memories:
    sq = getattr(m, 'search_queries', None) or []
    kw = getattr(m, 'search_keywords', None) or []
    if not sq or not kw:
        to_enrich.append((m.hash, m.content))
    else:
        already_done += 1

log(f'Already enriched: {already_done} | Need enrichment: {len(to_enrich)}')

if not to_enrich:
    log('Nothing to do — all entries already enriched!')
    sys.exit(0)

mem_map = {m.hash: m for m in ms.memories}
enriched = already_done
errors = 0
batch_enriched = 0
t0 = time.time()
total_to_process = len(to_enrich)

with ThreadPoolExecutor(max_workers=WORKERS) as pool:
    futures = {pool.submit(enrich_one, item): item[0] for item in to_enrich}
    done = 0
    for future in as_completed(futures):
        h, result, err = future.result()
        done += 1
        if result and mem_map.get(h):
            m = mem_map[h]
            if result.get("tags"):
                m.tags = sorted(set(getattr(m,'tags',[]) or []) | {t.lower() for t in result["tags"]})
            if result.get("summary"):
                m.enriched_summary = str(result["summary"])
            if result.get("keywords"):
                m.search_keywords = [str(k).lower() for k in result["keywords"]]
            if result.get("search_queries"):
                m.search_queries = [str(q) for q in result["search_queries"]]
            enriched += 1
            batch_enriched += 1
        else:
            errors += 1

        # Checkpoint every CHECKPOINT_EVERY new enrichments
        if batch_enriched > 0 and batch_enriched % CHECKPOINT_EVERY == 0:
            save_checkpoint(ms, enriched, errors, total)

        if done % 100 == 0:
            elapsed = time.time() - t0
            rate = done / elapsed
            eta = (total_to_process - done) / rate if rate > 0 else 0
            pct = enriched / total * 100
            log(f'[{done}/{total_to_process}] total_enriched={enriched}/{total} ({pct:.0f}%) err={errors} {rate:.1f}/s ETA={eta/60:.1f}m')

elapsed = time.time() - t0
log(f'DONE: {enriched}/{total} enriched in {elapsed:.0f}s ({enriched/max(elapsed,1):.1f}/s). Errors: {errors}')
log('Final save...')
save_checkpoint(ms, enriched, errors, total)
log('Complete ✅')
