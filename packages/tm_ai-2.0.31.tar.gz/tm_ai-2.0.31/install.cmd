@echo off
:: =============================================================================
:: CVC (Cognitive Version Control) — Installer for Windows CMD
:: Usage:  curl -fsSL https://jaimeena.com/cvc/install.cmd -o install.cmd && install.cmd
:: =============================================================================

echo.
echo    @@@@@@  @  @  @@@@@@
echo   @@       @  @  @@
echo   @@       @  @  @@
echo   @@        @@   @@
echo    @@@@@@   @@   @@@@@@
echo.
echo   CVC -- Cognitive Version Control
echo   Time Machine for AI Agents
echo.

:: Check if PowerShell is available (it always is on Windows 7+)
where powershell >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo  x  ERROR: PowerShell is not available on this system.
    echo     Please open PowerShell manually and run:
    echo     irm https://jaimeena.com/cvc/install.ps1 ^| iex
    exit /b 1
)

echo =^> Launching PowerShell installer...
echo.

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "try { irm https://jaimeena.com/cvc/install.ps1 | iex } catch { Write-Host $_.Exception.Message -ForegroundColor Red; exit 1 }; exit 0"

if %ERRORLEVEL% NEQ 0 (
    echo.
    echo  x  Installation failed. Please open PowerShell and run:
    echo     irm https://jaimeena.com/cvc/install.ps1 ^| iex
    exit /b 1
)

echo.
pause
