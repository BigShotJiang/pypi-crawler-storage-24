# Changelog

All notable changes to this project will be documented in this file.

## [0.2.3] - 2026-03-07

### Changed
- Ingestion now treats non-2xx API responses as failed deliveries instead of silently succeeding.
- Added retry classification for transient HTTP responses (`408`, `409`, `425`, `429`, `5xx`).
- Async ingestion now emits runtime warnings with HTTP status/details when final delivery fails.
- Updated SDK user-agent string to `tokvera-python-sdk/0.2.3`.

### Added
- New ingest-focused tests covering retryable/non-retryable HTTP failures and async warning behavior.

## [0.2.2] - 2026-03-07

### Added
- FastAPI middleware integration helpers:
  - `create_fastapi_tracking_middleware(...)`
  - `get_fastapi_request_context()`
  - `get_fastapi_track_kwargs(...)`
- LangChain callback integration helpers:
  - `TokveraLangChainCallbackHandler`
  - `create_langchain_callback_handler(...)`
- LlamaIndex callback integration helpers:
  - `TokveraLlamaIndexCallbackHandler`
  - `create_llamaindex_callback_handler(...)`
- Evaluation Signals v1 support in tags and top-level `evaluation` payload fields.

### Changed
- Expanded integration test coverage for framework callbacks and request middleware context propagation.

## [0.2.1] - 2026-03-04

### Added
- Trace Context v1 support in wrapper inputs and emitted tags.
- New optional tags: `trace_id`, `conversation_id`, `span_id`, `parent_span_id`, `step_name`.

### Changed
- Auto-generates `trace_id` and `span_id` per tracked call when not provided.

## [0.2.0] - 2026-03-02

### Added
- Anthropic tracking wrapper via `track_anthropic(...)` for `messages.create`.
- Gemini tracking wrapper via `track_gemini(...)` for `models.generate_content`.
- Multi-provider event contracts aligned with Tokvera API schema.
- Provider-specific usage extraction for OpenAI, Anthropic, and Gemini responses.
- Test coverage for Anthropic/Gemini emission flows.

## [0.1.0] - 2026-02-16

### Added
- OpenAI client wrapper for `chat.completions.create` and `responses.create`.
- Unified event schema with `schema_version`, `endpoint`, `status`, `usage`, and `tags`.
- Authenticated ingestion via `Authorization: Bearer <api_key>`.
- Failure event emission with error metadata while preserving caller exceptions.
- Privacy-safe telemetry defaults with optional prompt/response hashing.
- Tests for success, failure, and non-blocking ingestion behavior.
