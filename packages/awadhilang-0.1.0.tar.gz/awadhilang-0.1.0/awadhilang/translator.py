from .mapping import mapping

reverse_mapping = {v: k for k, v in mapping.items()}

def translate_to_cpp(code):

    for awadhi in sorted(reverse_mapping, key=len, reverse=True):
        cpp = reverse_mapping[awadhi]
        code = code.replace(awadhi, cpp)


    return code