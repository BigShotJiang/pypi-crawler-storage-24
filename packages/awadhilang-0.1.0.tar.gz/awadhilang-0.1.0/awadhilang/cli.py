import sys
from .runner import run_file

def main():

    if len(sys.argv) < 3:
        print("Usage: awadhi run <file.aw>")
        return

    command = sys.argv[1]
    file = sys.argv[2]

    if command == "run":
        run_file(file)