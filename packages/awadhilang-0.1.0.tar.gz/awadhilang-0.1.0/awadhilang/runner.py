import subprocess
from .translator import translate_to_cpp

def run_file(filename):

    with open(filename) as f:
        code = f.read()

    cpp_code = translate_to_cpp(code)

    with open("temp.cpp", "w") as f:
        f.write(cpp_code)

    compile_process = subprocess.run(
        ["g++", "temp.cpp", "-o", "program"],
        capture_output=True,
        text=True
    )

    if compile_process.returncode != 0:
        print("Compilation Error:")
        print(compile_process.stderr)
        return

    subprocess.run(["program"])