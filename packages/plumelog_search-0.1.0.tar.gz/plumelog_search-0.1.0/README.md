# plumelog-search

基于 [Plume Log](https://github.com/fayechenlong/plumelog) 的 MCP Server，提供日志查询工具，可集成到 Cursor 等支持 MCP 协议的编辑器中。

## 功能

- 通过 MCP 协议暴露 `search_logs` 工具
- 自动管理登录会话（cookie），401 时自动重登录
- 支持按时间范围、追踪码、服务器、应用名、日志内容等条件查询
- 内容查询支持两种模式：精确查询和布尔条件查询
- 自动格式化响应，只返回关键字段

## 环境要求

- Python >= 3.14
- [uv](https://github.com/astral-sh/uv)

## 配置

在 Cursor 的 MCP 配置文件（`.cursor/mcp.json`）中添加：

```json
{
  "mcpServers": {
    "plumelog-search": {
      "command": "uvx",
      "args": ["--from", "/path/to/plumelog-search", "plumelog-search"],
      "env": {
        "LOGBOOK_USERNAME": "your_username",
        "LOGBOOK_PASSWORD": "your_password",
        "LOGBOOK_BASE_URL": "https://your-logbook-server.com"
      }
    }
  }
}
```

| 环境变量 | 必填 | 说明 |
|---------|:---:|------|
| `LOGBOOK_USERNAME` | 是 | 登录账号 |
| `LOGBOOK_PASSWORD` | 是 | 登录密码 |
| `LOGBOOK_BASE_URL` | 是 | LogBook 服务地址 |

## 工具参数

### `search_logs`

| 参数 | 类型 | 必填 | 默认值 | 说明 |
|------|------|:---:|-------|------|
| `start_time` | string | 是 | - | 开始时间，`YYYY-MM-DD` 或 `YYYY-MM-DD HH:mm:ss` |
| `end_time` | string | 是 | - | 结束时间，同上 |
| `content` | string | 是 | - | 查询内容（见下方说明） |
| `content_mode` | string | 否 | `"query"` | `"query"` 或 `"condition"` |
| `trace_id` | string | 否 | - | 追踪码 |
| `server_name` | string | 否 | - | 服务器名称或 IP |
| `app_name` | string | 否 | - | 应用名称 |
| `size` | int | 否 | 100 | 返回条数上限，最大 500 |

### 内容查询模式

**query 模式**（默认）：传入带引号的字符串进行精确匹配

```
"关键词"
```

**condition 模式**：支持布尔语法

```
"关键词1" AND "关键词2" NOT "排除词" OR "备选词"
```

## License

MIT
