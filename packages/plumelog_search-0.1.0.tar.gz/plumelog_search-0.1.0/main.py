from __future__ import annotations

import os
from datetime import datetime, timezone, timedelta
from typing import Optional

import httpx
from mcp.server.fastmcp import FastMCP

CN_TZ = timezone(timedelta(hours=8))


class LogBookClient:
    def __init__(self, username: str, password: str, base_url: str):
        self._username = username
        self._password = password
        self._cookie: str | None = None
        self._http = httpx.AsyncClient(
            base_url=base_url,
            timeout=30,
            headers={
                "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:147.0) Gecko/20100101 Firefox/147.0",
                "Accept": "application/json, text/plain, */*",
                "Content-Type": "application/json;charset=utf-8",
                "Origin": base_url,
                "Referer": f"{base_url}/",
            },
        )

    async def login(self) -> None:
        resp = await self._http.post(
            "/login",
            json={"username": self._username, "password": self._password},
        )
        data = resp.json()
        code = data.get("code")
        if code == 402:
            raise RuntimeError("登录失败：账号或密码错误 (code=402)")

        cookie_header = resp.headers.get("set-cookie", "")
        if "JSESSIONID=" in cookie_header:
            self._cookie = cookie_header.split("JSESSIONID=")[1].split(";")[0]
        elif resp.cookies.get("JSESSIONID"):
            self._cookie = resp.cookies["JSESSIONID"]

        if not self._cookie:
            raise RuntimeError(f"登录失败：未获取到 JSESSIONID, response={resp.text}")

    async def query(self, body: dict, start_ts: int, end_ts: int, size: int) -> dict:
        if not self._cookie:
            await self.login()

        result = await self._do_query(body, start_ts, end_ts, size)
        return result

    async def _do_query(self, body: dict, start_ts: int, end_ts: int, size: int) -> dict:
        resp = await self._http.post(
            "/clientQuery",
            params={
                "clientStartDate": start_ts,
                "clientEndDate": end_ts,
                "size": size,
                "from": 0,
            },
            json=body,
            headers={"Cookie": f"JSESSIONID={self._cookie}"},
        )

        data = resp.json()
        code = data.get("code")

        if code == 401:
            self._cookie = None
            await self.login()
            return await self._do_query(body, start_ts, end_ts, size)

        if code == 402:
            raise RuntimeError("认证失败：账号或密码错误 (code=402)")

        return data


def _parse_time(time_str: str) -> int:
    """将时间字符串转为毫秒时间戳，支持 YYYY-MM-DD 和 YYYY-MM-DD HH:mm:ss"""
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d"):
        try:
            dt = datetime.strptime(time_str, fmt).replace(tzinfo=CN_TZ)
            return int(dt.timestamp() * 1000)
        except ValueError:
            continue
    raise ValueError(f"无法解析时间: {time_str}，请使用 YYYY-MM-DD 或 YYYY-MM-DD HH:mm:ss 格式")


def _build_query_body(
    start_ts: int,
    end_ts: int,
    content: str,
    content_mode: str = "query",
    trace_id: str | None = None,
    server_name: str | None = None,
    app_name: str | None = None,
) -> dict:
    must: list[dict] = []

    if app_name:
        must.append({"match_phrase": {"appName": {"query": app_name}}})

    if trace_id:
        must.append({"match_phrase": {"traceId": {"query": trace_id}}})

    if server_name:
        must.append({"match_phrase": {"serverName": {"query": server_name}}})

    if content_mode == "condition":
        must.append({
            "query_string": {
                "query": content,
                "default_field": "content",
            }
        })
    else:
        must.append({
            "query_string": {
                "query": content,
                "default_field": "content",
            }
        })

    must.append({
        "range": {
            "dtTime": {
                "gte": start_ts,
                "lt": end_ts,
            }
        }
    })

    return {
        "query": {"bool": {"must": must}},
        "highlight": {"fields": {"content": {"fragment_size": 2147483647}}},
        "sort": [{"dtTime": "asc"}, {"seq": "asc"}],
    }


def _format_results(data: dict) -> str:
    hits_data = data.get("hits", {})
    total = hits_data.get("total", {}).get("value", 0)
    hits = hits_data.get("hits", [])

    if total == 0:
        return "未找到匹配的日志记录。"

    lines: list[str] = [f"共找到 {total} 条日志，返回 {len(hits)} 条：\n"]

    for i, hit in enumerate(hits, 1):
        src = hit.get("_source", {})
        lines.append(f"--- [{i}] ---")
        lines.append(f"时间: {src.get('dateTime', 'N/A')}")
        lines.append(f"级别: {src.get('logLevel', 'N/A')}")
        lines.append(f"追踪码: {src.get('traceId', 'N/A')}")
        lines.append(f"应用: {src.get('appName', 'N/A')}")
        lines.append(f"服务器: {src.get('serverName', 'N/A')}")
        lines.append(f"类名: {src.get('className', 'N/A')}")
        lines.append(f"内容: {src.get('content', 'N/A')}")
        lines.append("")

    return "\n".join(lines)


mcp = FastMCP("plumelog-search")
_client: LogBookClient | None = None


def _get_client() -> LogBookClient:
    global _client
    if _client is None:
        username = os.environ.get("LOGBOOK_USERNAME", "")
        password = os.environ.get("LOGBOOK_PASSWORD", "")
        base_url = os.environ.get("LOGBOOK_BASE_URL", "")
        if not username or not password or not base_url:
            raise RuntimeError(
                "请设置环境变量 LOGBOOK_USERNAME、LOGBOOK_PASSWORD 和 LOGBOOK_BASE_URL"
            )
        _client = LogBookClient(username, password, base_url)
    return _client


@mcp.tool()
async def search_logs(
    start_time: str,
    end_time: str,
    content: str,
    content_mode: str = "query",
    trace_id: Optional[str] = None,
    server_name: Optional[str] = None,
    app_name: Optional[str] = None,
    size: int = 100,
) -> str:
    """搜索 LogBook 日志。

    Args:
        start_time: 开始时间，格式 YYYY-MM-DD 或 YYYY-MM-DD HH:mm:ss
        end_time: 结束时间，格式 YYYY-MM-DD 或 YYYY-MM-DD HH:mm:ss
        content: 查询内容。
            query 模式下传入带引号的字符串，如 "用户未获得任何奖牌"；
            condition 模式下支持布尔语法，如 "用户" AND "奖牌" NOT "错误" OR "警告"
        content_mode: 查询模式，"query"（默认）或 "condition"
        trace_id: 追踪码（可选）
        server_name: 服务器名称或 IP（可选）
        app_name: 应用名称，如 ParentCenter（可选）
        size: 返回条数上限，默认 100，最大 500
    """
    size = max(1, min(size, 500))

    start_ts = _parse_time(start_time)
    end_ts = _parse_time(end_time)

    body = _build_query_body(
        start_ts=start_ts,
        end_ts=end_ts,
        content=content,
        content_mode=content_mode,
        trace_id=trace_id,
        server_name=server_name,
        app_name=app_name,
    )

    client = _get_client()
    data = await client.query(body, start_ts, end_ts, size)

    return _format_results(data)


def main():
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
