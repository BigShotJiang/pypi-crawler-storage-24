import os
import shlex

from harbor.agents.installed.base import (
    BaseInstalledAgent,
    with_prompt_template,
    CliFlag,
)
from harbor.environments.base import BaseEnvironment
from harbor.models.agent.context import AgentContext
from harbor.models.agent.name import AgentName


class Aider(BaseInstalledAgent):
    """
    The Aider agent installs https://aider.chat/ into the task container and attempts to
    solve the task using Aider's scripting mode.
    """

    CLI_FLAGS = [
        CliFlag(
            "reasoning_effort",
            cli="--reasoning-effort",
            type="str",
        ),
        CliFlag(
            "thinking_tokens",
            cli="--thinking-tokens",
            type="int",
        ),
        CliFlag(
            "cache_prompts",
            cli="--cache-prompts",
            type="bool",
        ),
        CliFlag(
            "auto_lint",
            cli="--auto-lint",
            type="bool",
        ),
        CliFlag(
            "auto_test",
            cli="--auto-test",
            type="bool",
        ),
        CliFlag(
            "test_cmd",
            cli="--test-cmd",
            type="str",
        ),
        CliFlag(
            "stream",
            cli="--stream",
            type="bool",
        ),
        CliFlag(
            "map_tokens",
            cli="--map-tokens",
            type="int",
        ),
    ]

    @staticmethod
    def name() -> str:
        return AgentName.AIDER.value

    def get_version_command(self) -> str | None:
        return ". $HOME/.local/bin/env; aider --version"

    def parse_version(self, stdout: str) -> str:
        text = stdout.strip()
        for line in text.splitlines():
            line = line.strip()
            if line:
                return line.removeprefix("aider").strip()
        return text

    async def install(self, environment: BaseEnvironment) -> None:
        await self.exec_as_root(
            environment,
            command="apt-get update && apt-get install -y curl",
            env={"DEBIAN_FRONTEND": "noninteractive"},
        )
        await self.exec_as_agent(
            environment,
            command=(
                "set -euo pipefail; "
                "curl -LsSf https://aider.chat/install.sh | sh && "
                'if [ -f "$HOME/.local/bin/env" ]; then source "$HOME/.local/bin/env"; fi && '
                "aider --version"
            ),
        )

    def populate_context_post_run(self, context: AgentContext) -> None:
        pass

    @with_prompt_template
    async def run(
        self,
        instruction: str,
        environment: BaseEnvironment,
        context: AgentContext,
    ) -> None:
        escaped_instruction = shlex.quote(instruction)

        # Determine provider and API key from model name
        if not self.model_name or "/" not in self.model_name:
            raise ValueError("Model name must be in the format provider/model_name")

        provider, model = self.model_name.split("/", 1)

        # Get API key based on provider
        if provider == "openai":
            api_key = os.environ.get("OPENAI_API_KEY")
        elif provider == "anthropic":
            api_key = os.environ.get("ANTHROPIC_API_KEY")
        else:
            raise ValueError(f"Unsupported provider: {provider}")

        if not api_key:
            raise ValueError(f"No API key found for provider: {provider}")

        env = {
            "AIDER_API_KEY": f"{provider}={api_key}",
        }

        cli_flags = self.build_cli_flags()
        extra_flags = (cli_flags + " ") if cli_flags else ""

        await self.exec_as_agent(
            environment,
            command=(
                ". $HOME/.local/bin/env; "
                f"aider --yes {extra_flags}--model={model} --message={escaped_instruction} "
                f"2>&1 | stdbuf -oL tee /logs/agent/aider.txt"
            ),
            env=env,
        )
