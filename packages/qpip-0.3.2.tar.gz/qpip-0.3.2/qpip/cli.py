"""Command line interface for qpip."""

from __future__ import annotations

import sys
from dataclasses import dataclass
from pathlib import Path
from textwrap import dedent
from typing import Mapping, Optional, Sequence, Tuple

from .core import (
    DEFAULT_MIRROR,
    format_mirrors,
    get_default_mirror,
    is_mirror_name,
    normalize_mirror_name,
    run_pip_with_mirror,
)
from .project_config import load_project_config_safe
from .project_cli import (
    ProjectCLIUsageError,
    run_config_command,
    run_doctor_command,
    run_exec_command,
    run_info_command,
    run_mirror_command,
)
from .project_init import run_init_command
from .project_run import run_project_command
from .project_venv import (
    VenvUsageError,
    run_env_command,
    run_venv_command,
)


HELP_TEXT = dedent(
    f"""\
    qpip - 使用更快的软件包镜像运行 pip

    项目:
      qpip init
      qpip init -y
      qpip install requests
      qpip add requests
      qpip remove requests
      qpip update requests
      qpip uninstall requests
      qpip pip install numpy

    脚本与执行:
      qpip run
      qpip run test -- -k api
      qpip exec python -V

    环境:
      qpip env create
      qpip env use
      qpip env current
      qpip env activated
      qpip env path
      qpip env python
      qpip env pip
      qpip env list
      qpip env deactivate

    镜像:
      qpip mirror list
      qpip mirror current
      qpip mirror use tsinghua
      qpip tsinghua install numpy
      qpip --mirror douban install pandas

    其他:
      qpip info
      qpip doctor
      qpip config get mirror
      qpip config list
      qpip --list-mirrors
      qpip --help

    说明:
      - qpip 默认使用 '{DEFAULT_MIRROR}' 镜像。
      - 可通过设置环境变量 QPIP_DEFAULT_MIRROR 修改默认镜像。
      - qpip 自身的参数必须放在 pip 参数之前。
      - 如果你要把前导选项传给 pip 自身，请使用 '--'。
      - `qpip exec` 适合执行任意命令；大多数情况下不需要先 `qpip env use`。
      - `qpip run` / `qpip exec` 会优先使用当前项目 `.venv`。
      - `qpip update` / `qpip up` 等价于 `pip install --upgrade ...`。
      - `qpip add` 等价于 `qpip install`，`qpip remove` 等价于 `qpip uninstall`。
      - `qpip uninstall` / `qpip un` 等价于 `pip uninstall ...`。
      - `qpip init` 会在当前目录生成 pyproject.toml 和默认 scripts。
      - `qpip env create` 会在项目根目录创建 `.venv`。
      - `qpip env use` / `qpip env deactivate` 会输出当前 shell 可直接执行的环境命令。
      - `qpip env activated` 用于脚本判断，`qpip env current` 用于查看当前状态。
      - `qpip mirror use` 会把项目默认镜像写入 `[tool.qpip]`。
    """
).strip()


class CLIUsageError(ValueError):
    """Raised when qpip-specific CLI usage is invalid."""


@dataclass(frozen=True)
class CLIOptions:
    """Parsed qpip command line options."""

    mirror: str
    pip_args: Tuple[str, ...]
    dry_run: bool = False
    json_output: bool = False
    list_mirrors: bool = False
    help_requested: bool = False


def parse_cli_args(
    argv: Sequence[str],
    env: Optional[Mapping[str, str]] = None,
) -> Tuple[CLIOptions, Optional[str]]:
    """Parse qpip flags while leaving the remainder for pip."""
    args = list(argv)
    mirror, warning = get_default_mirror(env)
    positional_mirror = None

    if args and is_mirror_name(args[0]):
        positional_mirror = normalize_mirror_name(args.pop(0))
        mirror = positional_mirror

    dry_run = False
    json_output = False
    list_mirrors = False
    help_requested = False
    pip_args: Tuple[str, ...] = ()

    index = 0
    while index < len(args):
        arg = args[index]

        if arg == "--":
            pip_args = tuple(args[index + 1 :])
            break

        if arg in {"-h", "--help"}:
            help_requested = True
            index += 1
            continue

        if arg == "--list-mirrors":
            list_mirrors = True
            index += 1
            continue

        if arg == "--dry-run":
            dry_run = True
            index += 1
            continue

        if arg == "--json":
            json_output = True
            index += 1
            continue

        if arg in {"-m", "--mirror"}:
            if index + 1 >= len(args):
                raise CLIUsageError(f"{arg} 需要指定镜像名称")

            explicit_mirror = normalize_mirror_name(args[index + 1])
            if positional_mirror and explicit_mirror != positional_mirror:
                raise CLIUsageError("镜像被重复指定且值不一致")

            mirror = explicit_mirror
            index += 2
            continue

        if is_mirror_name(arg):
            explicit_mirror = normalize_mirror_name(arg)
            if positional_mirror and explicit_mirror != positional_mirror:
                raise CLIUsageError("镜像被重复指定且值不一致")

            positional_mirror = explicit_mirror
            mirror = explicit_mirror
            index += 1
            continue

        pip_args = tuple(args[index:])
        break
    else:
        pip_args = ()

    return (
        CLIOptions(
            mirror=mirror,
            pip_args=pip_args,
            dry_run=dry_run,
            json_output=json_output,
            list_mirrors=list_mirrors,
            help_requested=help_requested,
        ),
        warning,
    )


def main(argv: Optional[Sequence[str]] = None) -> int:
    """Console script entry point."""
    raw_args = sys.argv[1:] if argv is None else list(argv)

    try:
        options, warning = parse_cli_args(raw_args)
    except ValueError as exc:
        print(f"错误: {exc}", file=sys.stderr)
        print(HELP_TEXT, file=sys.stderr)
        return 2

    if warning:
        print(f"[qpip] {warning}", file=sys.stderr)

    if options.help_requested:
        print(HELP_TEXT)
        return 0

    if options.list_mirrors:
        print(format_mirrors())
        return 0

    if not options.pip_args:
        print(HELP_TEXT, file=sys.stderr)
        return 2

    command = options.pip_args[0]
    normalized_args = list(options.pip_args)
    if command == "add":
        normalized_args[0] = "install"
    elif command == "remove":
        normalized_args[0] = "uninstall"

    normalized_args_tuple = tuple(normalized_args)

    if normalized_args[0] == "init":
        try:
            return run_init_command(
                normalized_args_tuple,
                cwd=Path.cwd(),
                dry_run=options.dry_run,
            )
        except ValueError as exc:
            print(f"错误: {exc}", file=sys.stderr)
            return 2

    if normalized_args[0] == "run":
        try:
            return run_project_command(
                normalized_args_tuple,
                cwd=Path.cwd(),
                dry_run=options.dry_run,
            )
        except ValueError as exc:
            print(f"错误: {exc}", file=sys.stderr)
            return 2

    if normalized_args[0] == "exec":
        try:
            return run_exec_command(
                normalized_args_tuple,
                cwd=Path.cwd(),
                dry_run=options.dry_run,
            )
        except ProjectCLIUsageError as exc:
            print(f"错误: {exc}", file=sys.stderr)
            return 2

    if normalized_args[0] == "info":
        try:
            return run_info_command(
                normalized_args_tuple,
                cwd=Path.cwd(),
                json_output=options.json_output,
            )
        except ProjectCLIUsageError as exc:
            print(f"错误: {exc}", file=sys.stderr)
            return 2

    if normalized_args[0] == "doctor":
        try:
            return run_doctor_command(
                normalized_args_tuple,
                cwd=Path.cwd(),
                json_output=options.json_output,
            )
        except ProjectCLIUsageError as exc:
            print(f"错误: {exc}", file=sys.stderr)
            return 2

    if normalized_args[0] == "env":
        try:
            return run_env_command(
                normalized_args_tuple,
                cwd=Path.cwd(),
                dry_run=options.dry_run,
                json_output=options.json_output,
            )
        except VenvUsageError as exc:
            print(f"错误: {exc}", file=sys.stderr)
            return 2

    if normalized_args[0] == "mirror":
        try:
            return run_mirror_command(
                normalized_args_tuple,
                cwd=Path.cwd(),
                json_output=options.json_output,
            )
        except ProjectCLIUsageError as exc:
            print(f"错误: {exc}", file=sys.stderr)
            return 2

    if normalized_args[0] == "config":
        try:
            return run_config_command(
                normalized_args_tuple,
                cwd=Path.cwd(),
                json_output=options.json_output,
            )
        except ProjectCLIUsageError as exc:
            print(f"错误: {exc}", file=sys.stderr)
            return 2

    if normalized_args[0] == "venv":
        print("错误: 请使用 `qpip env create`", file=sys.stderr)
        return 2
    if normalized_args[0] in {"activate", "activated", "deactivate"}:
        print("错误: 请使用 `qpip env use`、`qpip env activated` 或 `qpip env deactivate`", file=sys.stderr)
        return 2

    pip_args = tuple(normalized_args[1:]) if normalized_args[0] == "pip" else tuple(normalized_args)
    if normalized_args[0] == "pip" and not pip_args:
        print("错误: `qpip pip` 后需要跟 pip 参数", file=sys.stderr)
        return 2

    try:
        config_result = load_project_config_safe(Path.cwd())
        project_config = config_result.config
        if config_result.warning:
            print(f"[qpip] {config_result.warning}", file=sys.stderr)
        effective_mirror = options.mirror
        if (
            effective_mirror == DEFAULT_MIRROR
            and not any(arg in raw_args for arg in ("-m", "--mirror"))
            and not (raw_args and is_mirror_name(raw_args[0]))
            and project_config.mirror
        ):
            effective_mirror = project_config.mirror

        return run_pip_with_mirror(
            pip_args,
            mirror=effective_mirror,
            dry_run=options.dry_run,
        )
    except ValueError as exc:
        print(f"错误: {exc}", file=sys.stderr)
        return 2
