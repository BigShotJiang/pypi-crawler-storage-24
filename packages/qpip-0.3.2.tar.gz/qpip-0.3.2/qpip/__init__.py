"""Public package API for qpip."""

from .cli import main
from .core import (
    DEFAULT_MIRROR,
    MIRROR_ALIASES,
    MIRRORS,
    build_pip_command,
    format_mirrors,
    get_default_mirror,
    normalize_mirror_name,
    run_pip_with_mirror,
    should_inject_mirror,
)
from .project_cli import (
    run_doctor_command,
    run_exec_command,
    run_info_command,
    run_mirror_command,
)
from .project_venv import (
    DEFAULT_VENV_DIRNAME,
    build_env_execution_env,
    build_venv_command,
    detect_shell,
    find_project_root,
    get_active_virtualenv_path,
    get_env_pip_path,
    get_env_python_path,
    is_project_venv_active,
    run_env_command,
    run_venv_command,
)

__all__ = [
    "DEFAULT_MIRROR",
    "DEFAULT_VENV_DIRNAME",
    "MIRROR_ALIASES",
    "MIRRORS",
    "build_env_execution_env",
    "build_pip_command",
    "build_venv_command",
    "detect_shell",
    "find_project_root",
    "format_mirrors",
    "get_active_virtualenv_path",
    "get_default_mirror",
    "get_env_pip_path",
    "get_env_python_path",
    "is_project_venv_active",
    "main",
    "normalize_mirror_name",
    "run_doctor_command",
    "run_env_command",
    "run_exec_command",
    "run_info_command",
    "run_mirror_command",
    "run_pip_with_mirror",
    "run_venv_command",
    "should_inject_mirror",
]

__version__ = "0.2.3"
