"""sonic-forge — bytebeat music DSL + multi-engine TTS voice system + talking heads."""

__version__ = "0.7.7"
