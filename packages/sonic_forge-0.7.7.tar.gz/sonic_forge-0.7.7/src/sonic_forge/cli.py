"""sonic-forge CLI — bytebeat music + TTS voice system."""

from __future__ import annotations

import os
from pathlib import Path
from typing import Optional

import typer


app = typer.Typer(
    name="sonic-forge",
    help="Sonic Forge — bytebeat music DSL + multi-engine TTS voice system.",
    invoke_without_command=True,
)


@app.callback()
def main(ctx: typer.Context) -> None:
    """Sonic Forge — bytebeat music DSL + multi-engine TTS voice system.

    Run with no arguments for the interactive launcher.
    """
    if ctx.invoked_subcommand is None:
        from sonic_forge.launcher import interactive_menu
        interactive_menu()


@app.command("play")
def play_cmd(
    name: str = typer.Argument(..., help="Track name (e.g. dark-space, midnight-drive, tpl-acid)."),
    minutes: Optional[int] = typer.Option(None, "--minutes", "-m", help="Duration in minutes (ChucK: default 60, templates: default 3)."),
) -> None:
    """Play a built-in track by name.

    sonic-forge play dark-space                 ChucK, plays 1 hour, Ctrl-C to stop
    sonic-forge play dark-space -m 10           ChucK, 10 minutes
    sonic-forge play tpl-acid                   Generate 3 min of acid house
    sonic-forge play tpl-acid -m 10             Generate 10 min of acid house
    sonic-forge play midnight-drive             Render and play the composed song
    """
    from sonic_forge.launcher import play_song
    play_song(name, minutes=minutes)


@app.command("stop")
def stop_cmd() -> None:
    """Stop all playing audio (kills afplay and chuck processes)."""
    import signal
    import subprocess
    killed = []
    for proc in ("afplay", "chuck"):
        result = subprocess.run(["pkill", "-9", proc], capture_output=True)
        if result.returncode == 0:
            killed.append(proc)
    if killed:
        print(f"\n  Stopped: {', '.join(killed)}\n")
    else:
        print("\n  Nothing playing.\n")


@app.command("catalog")
def catalog_cmd() -> None:
    """List all tracks — built-in + your installed songs."""
    from sonic_forge.launcher import list_songs
    list_songs()


@app.command("install")
def install_cmd(
    source: str = typer.Argument(..., help="Path to a .yaml or .ck song file."),
) -> None:
    """Install a song into your collection (~/.sonic-forge/songs/).

    sonic-forge install my_song.yaml
    sonic-forge install dark_forest.ck
    """
    from sonic_forge.launcher import install_song
    install_song(source)


@app.command("export")
def export_cmd(
    name: str = typer.Argument(..., help="Track name to export (e.g. acid-session, dark-space)."),
    output: Optional[str] = typer.Option(None, "-o", "--output", help="Output path."),
) -> None:
    """Export a built-in song file to the current directory.

    Grab any song's source to learn from, remix, or share.

    sonic-forge export acid-session        Get the YAML, edit it, make it yours
    sonic-forge export dark-space          Get the ChucK source
    sonic-forge export trance-og -o remix.yaml
    """
    from sonic_forge.launcher import export_song
    export_song(name, dest=output)


@app.command("dsl")
def dsl_cmd() -> None:
    """Show the song format reference — synths, notes, mini-notation.

    Everything you need to write your own songs or teach an LLM to compose.
    """
    from sonic_forge.launcher import show_dsl
    show_dsl()


@app.command("render")
def render_cmd(
    song: str = typer.Argument(..., help="YAML song file to render."),
    output: Optional[str] = typer.Option(None, "-o", "--output", help="Output WAV path."),
    play: bool = typer.Option(False, "--play", help="Play after rendering."),
    voice: Optional[str] = typer.Option(None, "--voice", help="TTS voice name (Samantha, af_heart, Zarvox...)."),
    engine: Optional[str] = typer.Option(None, "--engine", help="TTS engine: say (macOS), kokoro (Kokoro-82M)."),
    fx: Optional[str] = typer.Option(None, "--fx", help="Robot FX: helmet (muffled, droid), intercom (radio, medium clarity), droid (R2-style), ringmod (metallic), bitcrush (lo-fi, harsh)."),
    template: Optional[str] = typer.Option(None, "--template", help="Apply genre template."),
    lead: Optional[float] = typer.Option(None, "--lead", help="Voiceover lead time (seconds)."),
    rate: Optional[int] = typer.Option(None, "--rate", help="Speech rate (WPM)."),
    voice_stem: Optional[str] = typer.Option(None, "--voice-stem", help="Save voice-only WAV (for lip sync)."),
    music_vol: Optional[float] = typer.Option(None, "--music-vol", help="Music volume (0.0-2.0, default 1.0)."),
    voice_vol: Optional[float] = typer.Option(None, "--voice-vol", help="Voice volume (0.0-2.0, default 1.0)."),
) -> None:
    """Render a YAML song to WAV.

    sonic-forge render song.yaml --play
    sonic-forge render song.yaml --voice af_heart --engine kokoro --fx helmet --play
    sonic-forge render song.yaml --voice-vol 0.5 --music-vol 1.5 --play
    sonic-forge render song.yaml --voice Daniel --template lofi --play
    """
    from sonic_forge.songfile import render_yaml_song
    render_yaml_song(
        song, output_path=output, play=play,
        voice_override=voice, template_name=template,
        lead_override=lead, speech_rate=rate,
        engine=engine, fx=fx, voice_stem=voice_stem,
        music_vol=music_vol, voice_vol=voice_vol,
    )


@app.command("templates")
def templates_cmd() -> None:
    """List available genre templates."""
    from sonic_forge.templates import list_templates
    list_templates()


@app.command("robotize")
def robotize_cmd(
    input_wav: str = typer.Argument(..., help="WAV file to process."),
    effects: Optional[list[str]] = typer.Option(None, "--fx", help="Effects to apply (ringmod, bitcrush, vocoder, droid, helmet, intercom)."),
    output_dir: Optional[str] = typer.Option(None, "-o", "--output-dir", help="Output directory."),
) -> None:
    """Apply robot/droid effects to a WAV file.

    sonic-forge robotize voice.wav
    sonic-forge robotize voice.wav --fx helmet --fx droid
    """
    from sonic_forge.robotize import robotize_file
    robotize_file(input_wav, output_dir=output_dir, effects=effects)


@app.command("speak")
def speak_cmd(
    text: str = typer.Argument(..., help="Text to speak aloud."),
    voice: Optional[str] = typer.Option(None, "--voice", "-v", help="Voice name (af_heart, Samantha, Zarvox...)."),
    engine: Optional[str] = typer.Option(None, "--engine", "-e", help="TTS engine: say, kokoro."),
    fx: Optional[str] = typer.Option(None, "--fx", help="Robot FX: helmet (muffled, droid), intercom (radio, medium clarity), droid (R2-style), ringmod (metallic), bitcrush (lo-fi, harsh)."),
    rate: Optional[int] = typer.Option(None, "--rate", help="Speech rate in WPM (macOS say)."),
    output: Optional[str] = typer.Option(None, "-o", "--output", help="Save WAV to this path."),
    no_play: bool = typer.Option(False, "--no-play", help="Generate only, don't play."),
    visual: Optional[str] = typer.Option(None, "--visual", help="Talking head: droid, human, alien. Add :pixel for pixel art, :palette for color (e.g. alien:pixel:nes)."),
) -> None:
    """Speak text aloud using macOS say or Kokoro TTS.

    sonic-forge speak "Hello world"
    sonic-forge speak "Incoming transmission" --engine kokoro --voice heart
    sonic-forge speak "Captain on deck" --fx helmet
    sonic-forge speak "Warning" --voice Zarvox --fx intercom
    sonic-forge speak "Systems online" --visual droid
    sonic-forge speak "Greetings earthling" --visual alien:pixel:nes --fx helmet
    """
    from sonic_forge.tts import speak
    speak(text, engine=engine, voice=voice, rate=rate, fx=fx,
          output_path=output, play=not no_play, visual=visual)


@app.command("voices")
def voices_cmd(
    engine: Optional[str] = typer.Option(None, "--engine", "-e", help="Filter by engine: say, kokoro."),
    lang: Optional[str] = typer.Option(None, "--lang", "-l", help="Filter by language code (e.g. en, de, ja, zh)."),
) -> None:
    """List available TTS voices by engine.

    sonic-forge voices
    sonic-forge voices --engine say
    sonic-forge voices --engine kokoro
    sonic-forge voices --engine say --lang en
    sonic-forge voices --engine say --lang de
    """
    show_say = engine is None or engine == "say"
    show_kokoro = engine is None or engine == "kokoro"

    if show_say:
        _list_say_voices(lang)
    if show_kokoro:
        _list_kokoro_voices(lang)


def _list_say_voices(lang_filter=None):
    """List macOS say voices."""
    import subprocess
    result = subprocess.run(["say", "-v", "?"], capture_output=True, text=True)
    if result.returncode != 0:
        print("  macOS say not available.")
        return

    lines = result.stdout.strip().splitlines()
    voices = []
    for line in lines:
        # Format: "Name                lang_REGION  # sample text"
        parts = line.split("#", 1)
        name_lang = parts[0].strip()
        # Split on multiple spaces to separate name from lang code
        chunks = name_lang.split()
        if len(chunks) >= 2:
            lang_code = chunks[-1]
            name = " ".join(chunks[:-1])
            lang_short = lang_code.split("_")[0]
            if lang_filter and lang_short != lang_filter:
                continue
            voices.append((name, lang_code))

    print(f"\n  macOS say — {len(voices)} voices")
    print(f"  {'Voice':<22} {'Language':<10} {'Usage'}")
    print(f"  {'─' * 22} {'─' * 10} {'─' * 40}")
    for name, lang_code in voices:
        print(f"  {name:<22} {lang_code:<10} --engine say --voice \"{name}\"")
    print()


# Kokoro voice catalog — all 54 voices
_KOKORO_VOICES = {
    "American English — Female": [
        ("af_alloy", "Alloy"), ("af_aoede", "Aoede"), ("af_bella", "Bella"),
        ("af_heart", "Heart"), ("af_jessica", "Jessica"), ("af_kore", "Kore"),
        ("af_nicole", "Nicole"), ("af_nova", "Nova"), ("af_river", "River"),
        ("af_sarah", "Sarah"), ("af_sky", "Sky"),
    ],
    "American English — Male": [
        ("am_adam", "Adam"), ("am_echo", "Echo"), ("am_eric", "Eric"),
        ("am_fenrir", "Fenrir"), ("am_liam", "Liam"), ("am_michael", "Michael"),
        ("am_onyx", "Onyx"), ("am_puck", "Puck"), ("am_santa", "Santa"),
    ],
    "British English — Female": [
        ("bf_alice", "Alice"), ("bf_emma", "Emma"),
        ("bf_isabella", "Isabella"), ("bf_lily", "Lily"),
    ],
    "British English — Male": [
        ("bm_daniel", "Daniel"), ("bm_fable", "Fable"),
        ("bm_george", "George"), ("bm_lewis", "Lewis"),
    ],
    "Spanish": [
        ("ef_dora", "Dora"), ("em_alex", "Alex"), ("em_santa", "Santa"),
    ],
    "French": [("ff_siwis", "Siwis")],
    "Hindi": [
        ("hf_alpha", "Alpha"), ("hf_beta", "Beta"),
        ("hm_omega", "Omega"), ("hm_psi", "Psi"),
    ],
    "Italian": [("if_sara", "Sara"), ("im_nicola", "Nicola")],
    "Japanese": [
        ("jf_alpha", "Alpha"), ("jf_gongitsune", "Gongitsune"),
        ("jf_nezumi", "Nezumi"), ("jf_tebukuro", "Tebukuro"),
        ("jm_kumo", "Kumo"),
    ],
    "Portuguese": [
        ("pf_dora", "Dora"), ("pm_alex", "Alex"), ("pm_santa", "Santa"),
    ],
    "Chinese": [
        ("zf_xiaobei", "Xiaobei"), ("zf_xiaoni", "Xiaoni"),
        ("zf_xiaoxiao", "Xiaoxiao"), ("zf_xiaoyi", "Xiaoyi"),
        ("zm_yunjian", "Yunjian"), ("zm_yunxi", "Yunxi"),
        ("zm_yunxia", "Yunxia"), ("zm_yunyang", "Yunyang"),
    ],
}

_KOKORO_LANG_MAP = {
    "en": ["American English — Female", "American English — Male",
           "British English — Female", "British English — Male"],
    "es": ["Spanish"], "fr": ["French"], "hi": ["Hindi"],
    "it": ["Italian"], "ja": ["Japanese"], "pt": ["Portuguese"],
    "zh": ["Chinese"],
}


def _list_kokoro_voices(lang_filter=None):
    """List Kokoro-82M voices."""
    # Check if kokoro is installed
    try:
        import kokoro_onnx  # noqa: F401
        available = True
    except ImportError:
        available = False

    total = sum(len(v) for v in _KOKORO_VOICES.values())
    status = "" if available else " [not installed — pip install 'sonic-forge[kokoro]']"
    print(f"\n  Kokoro-82M — {total} voices{status}")

    groups = _KOKORO_VOICES
    if lang_filter:
        group_names = _KOKORO_LANG_MAP.get(lang_filter, [])
        if not group_names:
            print(f"  No Kokoro voices for language '{lang_filter}'")
            print(f"  Available: {', '.join(_KOKORO_LANG_MAP.keys())}")
            return
        groups = {k: v for k, v in groups.items() if k in group_names}

    for group_name, voices in groups.items():
        print(f"\n  {group_name}:")
        for voice_id, display_name in voices:
            print(f"    {voice_id:<18} {display_name:<14} --engine kokoro --voice {voice_id}")
    print()


@app.command("testmodel")
def testmodel_cmd(
    prompt: Optional[str] = typer.Argument(None, help="Prompt to send to the model."),
    model: Optional[str] = typer.Option(None, "--model", "-m", help="Ollama model name (e.g. granite4:3b, qwen3:4b)."),
) -> None:
    """Test an Ollama model — see raw output and timing.

    sonic-forge testmodel --model granite4:3b "brief my crew"
    sonic-forge testmodel "what is bytebeat?"
    sonic-forge testmodel                          # pick a model interactively
    """
    import json
    import re
    import time
    import urllib.request

    ollama_base = os.environ.get("OLLAMA_API_BASE", "http://127.0.0.1:11434")

    # Check Ollama is running
    try:
        with urllib.request.urlopen(f"{ollama_base}/api/tags", timeout=2) as resp:
            tags = json.loads(resp.read())
        models = [m["name"] for m in tags.get("models", [])]
    except Exception:
        print("\n  Ollama not running. Start it with: ollama serve\n")
        raise typer.Exit(1)

    if not models:
        print("\n  No models installed. Try: ollama pull granite4:3b\n")
        raise typer.Exit(1)

    # Pick model
    if not model:
        print(f"\n  Available models ({len(models)}):\n")
        for i, m in enumerate(models, 1):
            size = tags["models"][i - 1].get("size", 0)
            size_gb = size / 1e9 if size else 0
            print(f"    {i:>2}. {m:<30} {size_gb:.1f} GB")
        print()
        choice = input("  Pick a model (number or name): ").strip()
        if choice.isdigit():
            idx = int(choice) - 1
            if 0 <= idx < len(models):
                model = models[idx]
            else:
                print("  Invalid choice.")
                raise typer.Exit(1)
        else:
            model = choice

    if not prompt:
        prompt = input("  Prompt: ").strip()
        if not prompt:
            print("  No prompt given.")
            raise typer.Exit(1)

    print(f"\n  Model:  {model}")
    print(f"  Prompt: {prompt}\n")

    # Send to Ollama
    payload = json.dumps({
        "model": model,
        "messages": [{"role": "user", "content": prompt}],
        "stream": False,
    }).encode()
    req = urllib.request.Request(
        f"{ollama_base}/api/chat",
        data=payload,
        headers={"Content-Type": "application/json"},
    )

    wall_start = time.time()
    try:
        with urllib.request.urlopen(req, timeout=300) as resp:
            data = json.loads(resp.read())
    except Exception as e:
        print(f"  Error: {e}\n")
        raise typer.Exit(1)
    wall_elapsed = time.time() - wall_start

    # Extract response text
    content = data.get("message", {}).get("content", "")
    content = re.sub(r"<think>.*?</think>", "", content, flags=re.DOTALL).strip()

    # Extract Ollama timing (nanoseconds → seconds)
    load_ns = data.get("load_duration", 0)
    prompt_ns = data.get("prompt_eval_duration", 0)
    gen_ns = data.get("eval_duration", 0)
    total_ns = data.get("total_duration", 0)
    tokens = data.get("eval_count", 0)

    load_s = load_ns / 1e9
    prompt_s = prompt_ns / 1e9
    gen_s = gen_ns / 1e9
    total_s = total_ns / 1e9
    tok_per_s = tokens / gen_s if gen_s > 0 else 0

    # Print result
    print("  ─── response ───\n")
    for line in content.splitlines():
        print(f"  {line}")

    print(f"\n  ─── timing ───\n")
    print(f"  Model load:   {load_s:>6.2f}s")
    print(f"  Prompt eval:  {prompt_s:>6.2f}s")
    print(f"  Generation:   {gen_s:>6.2f}s  ({tokens} tokens, {tok_per_s:.1f} tok/s)")
    print(f"  Total:        {total_s:>6.2f}s  (wall: {wall_elapsed:.2f}s)")
    print()


@app.command("brief")
def brief_cmd(
    topic: Optional[str] = typer.Argument(None, help="Topic for AI briefing (optional if --text is used)."),
    text: Optional[str] = typer.Option(None, "--text", "-T", help="Provide your own script (skip AI). Sentences separated by periods."),
    template: Optional[str] = typer.Option("cinematic", "--template", "-t", help="Music template: trance, lofi, cinematic, ambient, acid, hiphop, minimal, anthem."),
    voice: Optional[str] = typer.Option("Daniel", "--voice", "-v", help="TTS voice name."),
    engine: Optional[str] = typer.Option(None, "--engine", "-e", help="TTS engine: say, kokoro."),
    fx: Optional[str] = typer.Option(None, "--fx", help="Robot FX: helmet, intercom, droid, ringmod, bitcrush."),
    output: Optional[str] = typer.Option(None, "-o", "--output", help="Save WAV to this path."),
    visual: Optional[str] = typer.Option(None, "--visual", help="Talking head: droid, human, alien. Add :pixel for pixel art (e.g. alien:pixel:nes)."),
) -> None:
    """Audio briefing with music and optional talking head.

    With AI (needs Claude, Gemini, or Ollama):
      sonic-forge brief "boost the morale of my crew"
      sonic-forge brief "status update" --visual alien:pixel:nes --template acid
      sonic-forge brief "mission log" --fx helmet --voice heart --engine kokoro

    With your own text (no AI needed):
      sonic-forge brief --text "Systems online. All crew accounted for. Ready for departure."
      sonic-forge brief ignored --text "Welcome aboard." --visual droid --template ambient
    """
    import os
    import tempfile

    # Determine sections — from AI or plain text
    sections = None
    title = "Briefing"

    if not topic and not text:
        print("\n  Provide a topic or use --text. Run 'sonic-forge brief --help' for usage.\n")
        raise typer.Exit(1)

    if text:
        # User provided their own script
        sections = [s.strip() for s in text.split(".") if s.strip()]
        title = sections[0][:40] if sections else "Briefing"
    else:
        # Try AI generation
        from sonic_forge.llm import llm_json_request, setup_hint

        brief_prompt = """You write short spoken briefings for a starship audio system. Each section plays over music so it MUST be brief.

Respond with JSON only:
{"title": "short title", "sections": ["Section one.", "Section two.", "Section three.", "Section four."]}

STRICT RULES:
- MAXIMUM 15 words per section. This is non-negotiable. Count your words.
- 4-6 sections total.
- Written for the EAR. No URLs, no code, no punctuation tricks.
- Plain English. Say "pie pie eye" not "PyPI". Spell out numbers.
- Punchy and direct. Like a news anchor, not an essayist."""

        print("\n  Writing briefing script...")
        data = llm_json_request(brief_prompt, topic)

        if data:
            title = data.get("title", "Briefing")
            sections = data.get("sections", [])
            if isinstance(sections, str):
                sections = [s.strip() for s in sections.split(". ") if s.strip()]
        else:
            # No AI available — use topic as literal text
            print(setup_hint())
            print("  Using your text as-is (no AI rewrite).\n")
            sections = [s.strip() for s in topic.split(".") if s.strip()]
            if not sections:
                sections = [topic]
            title = sections[0][:40]

    if not sections:
        print("\n  No briefing content. Provide --text or set up an AI provider.\n")
        raise typer.Exit(1)

    print(f"\n  {title}")
    for i, sec in enumerate(sections, 1):
        print(f"    {i}. {sec}")

    # Build YAML with cycle counts sized to speech length
    yaml_lines = [f"title: {title}", f"voice: {voice}",
                  "voice_lead: 0.5", "", "sections:"]
    for sec_text in sections:
        words = len(sec_text.split())
        speech_secs = (words / 150) * 60 + 1.5
        cycles = max(2, round(speech_secs / 2.4 + 0.5))
        safe_text = sec_text.replace('"', '\\"')
        yaml_lines.append(f'  - say: "{safe_text}"')
        yaml_lines.append(f"    cycles: {cycles}")
    yaml_content = "\n".join(yaml_lines) + "\n"

    # Write temp YAML, render
    out_path = output or tempfile.mktemp(suffix=".wav", prefix="brief_")
    yaml_path = out_path.replace(".wav", ".yaml")

    with open(yaml_path, "w") as f:
        f.write(yaml_content)

    print("\n  Rendering briefing...")

    from sonic_forge.songfile import render_yaml_song

    voice_stem_path = out_path.replace(".wav", "_voice.wav") if visual else None
    render_yaml_song(
        yaml_path, output_path=out_path, play=not visual,
        template_name=template or "cinematic",
        voice_override=voice, engine=engine, fx=fx,
        voice_stem=voice_stem_path,
    )

    # Play with talking head animation if --visual set
    if visual and os.path.exists(out_path):
        parts = visual.split(":")
        char_name = parts[0] if parts else "droid"
        style = parts[1] if len(parts) > 1 else "ascii"
        palette = parts[2] if len(parts) > 2 else "nes"

        full_text = " ... ".join(sections)

        stem = voice_stem_path if voice_stem_path and os.path.exists(voice_stem_path) else None
        try:
            from sonic_forge.talking_heads import animate_character
            animate_character(out_path, char_name=char_name, text=full_text,
                              style=style, palette_name=palette,
                              voice_stem=stem)
        except Exception:
            import subprocess
            subprocess.run(["afplay", out_path])

    # Cleanup temp files
    if not output:
        for f in (yaml_path, out_path):
            if os.path.exists(f):
                os.remove(f)
        if voice_stem_path and os.path.exists(voice_stem_path):
            os.remove(voice_stem_path)
    else:
        print(f"\n  Saved: {out_path}\n")


if __name__ == "__main__":
    app()
