__version__ = "0.7.0"

from r_bridge.bridge import RBridge
from r_bridge.exceptions import RBridgeError, RError, RProtocolError, RStartupError, RTimeoutError
from r_bridge.serializer import register_serializer
from r_bridge.deserializer import register_deserializer
from r_bridge.type_hints import TypeHint


def start_bridge(**kwargs) -> RBridge:
    """Create and start an RBridge. Equivalent to RBridge(**kwargs).start()."""
    return RBridge(**kwargs).start()


__all__ = [
    "__version__",
    "RBridge",
    "start_bridge",
    "RBridgeError",
    "RError",
    "RProtocolError",
    "RStartupError",
    "RTimeoutError",
    "TypeHint",
    "register_serializer",
    "register_deserializer",
]
