from pydantic import BaseModel, Field

class GitOpsOrigin(BaseModel):
    repo_url: str
    branch: str

class GitOpsUser(BaseModel):
    name: str
    email: str

class GitOpsOptions(BaseModel):
    force: bool = Field(default=False)
    pull: bool = Field(default=True)
    target_dir: str = Field(default="data/external/data-catalog")

class GitOpsConfig(BaseModel):
    origin: GitOpsOrigin
    user: GitOpsUser
    options: GitOpsOptions