"""Tests for readme_forge.models."""

from __future__ import annotations

import pytest

from readme_forge.models import (
    EXTENSION_LANGUAGE_MAP,
    LANGUAGE_COLORS,
    SKIP_DIRS,
    DirectoryEntry,
    FileStats,
    Framework,
    Language,
    LicenseType,
    ProjectInfo,
    ProjectType,
    ReadmeConfig,
    Section,
)


class TestLanguage:
    def test_all_values(self):
        assert Language.PYTHON.value == "Python"
        assert Language.JAVASCRIPT.value == "JavaScript"
        assert Language.TYPESCRIPT.value == "TypeScript"
        assert Language.GO.value == "Go"
        assert Language.RUST.value == "Rust"
        assert Language.JAVA.value == "Java"
        assert Language.UNKNOWN.value == "Unknown"

    def test_enum_count(self):
        assert len(Language) >= 20


class TestFramework:
    def test_python_frameworks(self):
        assert Framework.DJANGO.value == "Django"
        assert Framework.FLASK.value == "Flask"
        assert Framework.FASTAPI.value == "FastAPI"
        assert Framework.CLICK.value == "Click"
        assert Framework.PYTEST.value == "pytest"

    def test_js_frameworks(self):
        assert Framework.REACT.value == "React"
        assert Framework.NEXTJS.value == "Next.js"
        assert Framework.VUE.value == "Vue.js"
        assert Framework.ANGULAR.value == "Angular"
        assert Framework.EXPRESS.value == "Express"

    def test_devops_frameworks(self):
        assert Framework.DOCKER.value == "Docker"
        assert Framework.KUBERNETES.value == "Kubernetes"
        assert Framework.TERRAFORM.value == "Terraform"
        assert Framework.GITHUB_ACTIONS.value == "GitHub Actions"


class TestProjectType:
    def test_values(self):
        assert ProjectType.LIBRARY.value == "Library"
        assert ProjectType.CLI_TOOL.value == "CLI Tool"
        assert ProjectType.WEB_APP.value == "Web Application"
        assert ProjectType.API_SERVER.value == "API Server"
        assert ProjectType.UNKNOWN.value == "Project"

    def test_count(self):
        assert len(ProjectType) >= 10


class TestLicenseType:
    def test_values(self):
        assert LicenseType.MIT.value == "MIT"
        assert LicenseType.APACHE2.value == "Apache-2.0"
        assert LicenseType.GPL3.value == "GPL-3.0"
        assert LicenseType.UNKNOWN.value == "Unknown"

    def test_all_types(self):
        assert len(LicenseType) >= 12


class TestProjectInfo:
    def test_defaults(self):
        info = ProjectInfo()
        assert info.name == ""
        assert info.path == "."
        assert info.primary_language == Language.UNKNOWN
        assert info.project_type == ProjectType.UNKNOWN
        assert info.license == LicenseType.UNKNOWN
        assert info.languages == []
        assert info.frameworks == []
        assert info.has_tests is False
        assert info.has_docker is False

    def test_display_name(self):
        info = ProjectInfo(name="my-awesome-tool")
        assert info.display_name == "My Awesome Tool"

    def test_display_name_underscore(self):
        info = ProjectInfo(name="my_cool_lib")
        assert info.display_name == "My Cool Lib"

    def test_display_name_empty(self):
        info = ProjectInfo()
        assert info.display_name == "Project"

    def test_badge_language(self):
        info = ProjectInfo(primary_language=Language.PYTHON)
        assert info.badge_language == "Python"

    def test_badge_language_unknown(self):
        info = ProjectInfo()
        assert info.badge_language == ""

    def test_fully_populated(self, full_project_info):
        info = full_project_info
        assert info.name == "super-tool"
        assert info.version == "3.0.0"
        assert info.primary_language == Language.PYTHON
        assert len(info.frameworks) == 5
        assert info.has_tests is True
        assert info.has_docker is True
        assert info.entry_point == "super-tool"


class TestFileStats:
    def test_defaults(self):
        stats = FileStats()
        assert stats.total_files == 0
        assert stats.total_dirs == 0
        assert stats.total_lines == 0
        assert stats.file_types == {}
        assert stats.largest_files == []


class TestDirectoryEntry:
    def test_basic(self):
        entry = DirectoryEntry(name="src", is_dir=True, depth=0)
        assert entry.name == "src"
        assert entry.is_dir is True
        assert entry.children == []

    def test_with_children(self):
        child = DirectoryEntry(name="main.py", depth=1)
        parent = DirectoryEntry(name="src", is_dir=True, children=[child], depth=0)
        assert len(parent.children) == 1
        assert parent.children[0].name == "main.py"


class TestSection:
    def test_basic(self):
        s = Section(title="Features", content="Feature list", order=1)
        assert s.title == "Features"
        assert s.anchor == "features"
        assert s.include is True

    def test_anchor_generation(self):
        s = Section(title="Tech Stack", content="")
        assert s.anchor == "tech-stack"

    def test_custom_anchor(self):
        s = Section(title="Test", content="", anchor="custom-id")
        assert s.anchor == "custom-id"

    def test_ampersand_anchor(self):
        s = Section(title="Q&A", content="")
        assert s.anchor == "qanda"


class TestReadmeConfig:
    def test_defaults(self):
        c = ReadmeConfig()
        assert c.include_badges is True
        assert c.include_toc is True
        assert c.include_installation is True
        assert c.include_usage is True
        assert c.include_tree is False
        assert c.badge_style == "flat"
        assert c.emoji_headers is True
        assert c.header_style == "banner"
        assert c.toc_style == "bullet"

    def test_custom_config(self):
        c = ReadmeConfig(
            include_badges=False,
            badge_style="for-the-badge",
            emoji_headers=False,
            tree_depth=5,
        )
        assert c.include_badges is False
        assert c.badge_style == "for-the-badge"
        assert c.emoji_headers is False
        assert c.tree_depth == 5

    def test_custom_sections(self):
        sections = [Section(title="Custom", content="text")]
        c = ReadmeConfig(custom_sections=sections)
        assert len(c.custom_sections) == 1

    def test_features_list(self):
        c = ReadmeConfig(features=["Fast", "Reliable", "Extensible"])
        assert len(c.features) == 3


class TestExtensionMap:
    @pytest.mark.parametrize("ext,lang", [
        (".py", Language.PYTHON),
        (".js", Language.JAVASCRIPT),
        (".jsx", Language.JAVASCRIPT),
        (".ts", Language.TYPESCRIPT),
        (".tsx", Language.TYPESCRIPT),
        (".go", Language.GO),
        (".rs", Language.RUST),
        (".java", Language.JAVA),
        (".cs", Language.CSHARP),
        (".rb", Language.RUBY),
        (".php", Language.PHP),
        (".swift", Language.SWIFT),
        (".kt", Language.KOTLIN),
        (".dart", Language.DART),
        (".sh", Language.SHELL),
        (".scala", Language.SCALA),
        (".ex", Language.ELIXIR),
        (".hs", Language.HASKELL),
    ])
    def test_extension_mapping(self, ext, lang):
        assert EXTENSION_LANGUAGE_MAP[ext] == lang


class TestLanguageColors:
    def test_python_color(self):
        assert LANGUAGE_COLORS[Language.PYTHON] == "3776AB"

    def test_javascript_color(self):
        assert LANGUAGE_COLORS[Language.JAVASCRIPT] == "F7DF1E"

    def test_all_have_colors(self):
        for lang in Language:
            if lang != Language.UNKNOWN and lang != Language.R and lang != Language.LUA:
                assert lang in LANGUAGE_COLORS


class TestSkipDirs:
    def test_common_dirs(self):
        assert ".git" in SKIP_DIRS
        assert "node_modules" in SKIP_DIRS
        assert "__pycache__" in SKIP_DIRS
        assert "dist" in SKIP_DIRS
        assert ".venv" in SKIP_DIRS
        assert "target" in SKIP_DIRS
