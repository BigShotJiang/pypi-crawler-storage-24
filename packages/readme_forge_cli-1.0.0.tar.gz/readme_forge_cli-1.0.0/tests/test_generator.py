"""Tests for readme_forge.generator."""

from __future__ import annotations

from readme_forge.generator import (
    _auto_detect_features,
    _categorize_framework,
    _generate_contributing,
    _generate_features,
    _generate_header,
    _generate_installation,
    _generate_license,
    _generate_tech_stack,
    _generate_testing,
    _generate_toc,
    _generate_usage,
    _get_prerequisites,
    generate_readme,
)
from readme_forge.models import (
    Framework,
    Language,
    LicenseType,
    ProjectInfo,
    ProjectType,
    ReadmeConfig,
    Section,
)


class TestGenerateReadme:
    def test_basic(self, full_project_info, default_config):
        readme = generate_readme(full_project_info, default_config)
        assert "super-tool" in readme
        assert "## " in readme
        assert len(readme) > 100

    def test_has_header(self, full_project_info):
        readme = generate_readme(full_project_info)
        assert readme.startswith("# super-tool")

    def test_has_description(self, full_project_info):
        readme = generate_readme(full_project_info)
        assert "super powerful developer tool" in readme

    def test_has_badges(self, full_project_info):
        readme = generate_readme(full_project_info)
        assert "img.shields.io" in readme

    def test_no_badges(self, full_project_info):
        config = ReadmeConfig(include_badges=False)
        readme = generate_readme(full_project_info, config)
        assert "img.shields.io" not in readme

    def test_has_installation(self, full_project_info):
        readme = generate_readme(full_project_info)
        assert "pip install" in readme

    def test_no_installation(self, full_project_info):
        config = ReadmeConfig(include_installation=False)
        readme = generate_readme(full_project_info, config)
        assert "## " in readme  # other sections still present

    def test_has_testing(self, full_project_info):
        readme = generate_readme(full_project_info)
        assert "pytest" in readme

    def test_has_contributing(self, full_project_info):
        readme = generate_readme(full_project_info)
        assert "Contributing" in readme
        assert "Pull Request" in readme

    def test_has_license(self, full_project_info):
        readme = generate_readme(full_project_info)
        assert "MIT" in readme
        assert "License" in readme

    def test_has_author(self, full_project_info):
        readme = generate_readme(full_project_info)
        assert "Test Author" in readme

    def test_has_toc(self, full_project_info):
        readme = generate_readme(full_project_info)
        assert "Table of Contents" in readme

    def test_no_toc_few_sections(self):
        info = ProjectInfo(name="test")
        config = ReadmeConfig(
            include_features=False,
            include_tech_stack=False,
            include_installation=False,
            include_usage=False,
        )
        readme = generate_readme(info, config)
        assert "Table of Contents" not in readme

    def test_with_tree(self, full_project_info):
        config = ReadmeConfig(include_tree=True)
        readme = generate_readme(full_project_info, config)
        assert "Project Structure" in readme or "---" in readme

    def test_emoji_headers(self, full_project_info):
        config = ReadmeConfig(emoji_headers=True)
        readme = generate_readme(full_project_info, config)
        assert "✨" in readme or "🚀" in readme or "🤝" in readme

    def test_no_emoji_headers(self, full_project_info):
        config = ReadmeConfig(emoji_headers=False)
        readme = generate_readme(full_project_info, config)
        assert "✨" not in readme

    def test_custom_sections(self, full_project_info):
        custom = [Section(title="FAQ", content="Q: How?\nA: Like this.")]
        config = ReadmeConfig(custom_sections=custom)
        readme = generate_readme(full_project_info, config)
        assert "FAQ" in readme
        assert "Like this" in readme

    def test_minimal_config(self, full_project_info, minimal_config):
        readme = generate_readme(full_project_info, minimal_config)
        assert "super-tool" in readme
        assert "Contributing" not in readme

    def test_default_config(self, full_project_info):
        readme = generate_readme(full_project_info)
        # Should use default ReadmeConfig
        assert "super-tool" in readme

    def test_empty_project(self):
        info = ProjectInfo()
        readme = generate_readme(info)
        assert "# " in readme


class TestGenerateHeader:
    def test_banner_style(self, full_project_info):
        config = ReadmeConfig(header_style="banner")
        header = _generate_header(full_project_info, config)
        assert "# super-tool" in header
        assert ">" in header  # blockquote

    def test_simple_style(self, full_project_info):
        config = ReadmeConfig(header_style="simple")
        header = _generate_header(full_project_info, config)
        assert "# super-tool" in header

    def test_minimal_style(self, full_project_info):
        config = ReadmeConfig(header_style="minimal")
        header = _generate_header(full_project_info, config)
        assert "# super-tool" in header
        assert ">" not in header


class TestGenerateToc:
    def test_bullet_style(self):
        sections = [
            Section(title="Features", content=""),
            Section(title="Installation", content=""),
            Section(title="Usage", content=""),
        ]
        config = ReadmeConfig(toc_style="bullet")
        toc = _generate_toc(sections, config)
        assert "- [" in toc
        assert "#features" in toc

    def test_numbered_style(self):
        sections = [
            Section(title="Features", content=""),
            Section(title="Installation", content=""),
        ]
        config = ReadmeConfig(toc_style="numbered")
        toc = _generate_toc(sections, config)
        assert "1. [" in toc
        assert "2. [" in toc

    def test_emoji_in_toc(self):
        sections = [Section(title="Features", content="")]
        config = ReadmeConfig(emoji_headers=True)
        toc = _generate_toc(sections, config)
        assert "✨" in toc


class TestGenerateFeatures:
    def test_custom_features(self, full_project_info):
        config = ReadmeConfig(features=["Fast", "Reliable"])
        features = _generate_features(full_project_info, config)
        assert "Fast" in features
        assert "Reliable" in features

    def test_auto_detect(self, full_project_info):
        config = ReadmeConfig()
        features = _generate_features(full_project_info, config)
        assert len(features) > 0

    def test_empty(self):
        info = ProjectInfo()
        config = ReadmeConfig()
        features = _generate_features(info, config)
        assert features == ""


class TestAutoDetectFeatures:
    def test_cli_features(self):
        info = ProjectInfo(project_type=ProjectType.CLI_TOOL, has_tests=True)
        features = _auto_detect_features(info)
        assert any("command-line" in f.lower() or "cli" in f.lower() for f in features)
        assert any("test" in f.lower() for f in features)

    def test_web_app_features(self):
        info = ProjectInfo(project_type=ProjectType.WEB_APP)
        features = _auto_detect_features(info)
        assert len(features) > 0

    def test_docker_feature(self):
        info = ProjectInfo(frameworks=[Framework.DOCKER])
        features = _auto_detect_features(info)
        assert any("docker" in f.lower() for f in features)

    def test_ci_feature(self):
        info = ProjectInfo(frameworks=[Framework.GITHUB_ACTIONS])
        features = _auto_detect_features(info)
        assert any("ci" in f.lower() or "github" in f.lower() for f in features)

    def test_multi_language(self):
        info = ProjectInfo(languages=[Language.PYTHON, Language.TYPESCRIPT, Language.GO])
        features = _auto_detect_features(info)
        assert any("multi" in f.lower() or "language" in f.lower() for f in features)


class TestGenerateTechStack:
    def test_with_frameworks(self, full_project_info):
        tech = _generate_tech_stack(full_project_info)
        assert "Language" in tech
        assert "Python" in tech
        assert "|" in tech  # table format

    def test_no_frameworks(self):
        info = ProjectInfo()
        tech = _generate_tech_stack(info)
        assert tech == ""

    def test_with_python_version(self):
        info = ProjectInfo(
            primary_language=Language.PYTHON,
            python_version=">=3.11",
            frameworks=[Framework.CLICK],
        )
        tech = _generate_tech_stack(info)
        assert ">=3.11" in tech


class TestGenerateInstallation:
    def test_with_git_url(self, full_project_info):
        install = _generate_installation(full_project_info)
        assert "git clone" in install
        assert full_project_info.git_url in install

    def test_pip_install(self, full_project_info):
        install = _generate_installation(full_project_info)
        assert "pip install" in install

    def test_prerequisites(self, full_project_info):
        install = _generate_installation(full_project_info)
        assert "Python" in install

    def test_quick_install(self, full_project_info):
        install = _generate_installation(full_project_info)
        assert "Quick Install" in install


class TestGetPrerequisites:
    def test_python(self):
        info = ProjectInfo(primary_language=Language.PYTHON, python_version=">=3.9")
        prereqs = _get_prerequisites(info)
        assert any("Python" in p for p in prereqs)
        assert any("3.9" in p for p in prereqs)

    def test_node(self):
        info = ProjectInfo(primary_language=Language.JAVASCRIPT, node_version=">=18")
        prereqs = _get_prerequisites(info)
        assert any("Node" in p for p in prereqs)

    def test_go(self):
        info = ProjectInfo(primary_language=Language.GO, go_version="1.21")
        prereqs = _get_prerequisites(info)
        assert any("Go" in p for p in prereqs)

    def test_rust(self):
        info = ProjectInfo(primary_language=Language.RUST)
        prereqs = _get_prerequisites(info)
        assert any("Rust" in p for p in prereqs)

    def test_docker_prerequisite(self):
        info = ProjectInfo(frameworks=[Framework.DOCKER])
        prereqs = _get_prerequisites(info)
        assert any("Docker" in p for p in prereqs)


class TestGenerateUsage:
    def test_cli_tool(self, full_project_info):
        usage = _generate_usage(full_project_info)
        assert "super-tool" in usage
        assert "--help" in usage
        assert "--version" in usage

    def test_with_docker(self):
        info = ProjectInfo(
            name="myapp", has_docker=True, run_command="python main.py"
        )
        usage = _generate_usage(info)
        assert "docker" in usage.lower()
        assert "myapp" in usage

    def test_python_import(self):
        info = ProjectInfo(
            name="my-lib", primary_language=Language.PYTHON,
            project_type=ProjectType.LIBRARY,
        )
        usage = _generate_usage(info)
        assert "import" in usage
        assert "my_lib" in usage

    def test_js_import(self):
        info = ProjectInfo(
            name="my-pkg", primary_language=Language.JAVASCRIPT,
            project_type=ProjectType.LIBRARY,
        )
        usage = _generate_usage(info)
        assert "import" in usage

    def test_api_server(self):
        info = ProjectInfo(
            project_type=ProjectType.API_SERVER,
            run_command="uvicorn main:app",
        )
        usage = _generate_usage(info)
        assert "Endpoint" in usage or "endpoint" in usage


class TestGenerateTesting:
    def test_basic(self, full_project_info):
        testing = _generate_testing(full_project_info)
        assert "pytest tests/ -v" in testing
        assert "```" in testing


class TestGenerateContributing:
    def test_basic(self, full_project_info):
        contributing = _generate_contributing(full_project_info)
        assert "Fork" in contributing
        assert "Pull Request" in contributing
        assert "feature branch" in contributing

    def test_with_contributing_file(self):
        info = ProjectInfo(has_contributing=True)
        contributing = _generate_contributing(info)
        assert "CONTRIBUTING.md" in contributing

    def test_with_git_url(self, full_project_info):
        contributing = _generate_contributing(full_project_info)
        assert "git checkout" in contributing


class TestGenerateLicense:
    def test_known_license(self):
        info = ProjectInfo(license=LicenseType.MIT)
        text = _generate_license(info)
        assert "MIT" in text
        assert "LICENSE" in text

    def test_unknown_license(self):
        info = ProjectInfo()
        text = _generate_license(info)
        assert "LICENSE" in text


class TestCategorizeFramework:
    def test_web_framework(self):
        assert _categorize_framework(Framework.DJANGO) == "Framework"
        assert _categorize_framework(Framework.REACT) == "Framework"
        assert _categorize_framework(Framework.SPRING) == "Framework"

    def test_testing(self):
        assert _categorize_framework(Framework.PYTEST) == "Testing"
        assert _categorize_framework(Framework.JEST) == "Testing"

    def test_build(self):
        assert _categorize_framework(Framework.HATCH) == "Build"
        assert _categorize_framework(Framework.MAVEN) == "Build"

    def test_devops(self):
        assert _categorize_framework(Framework.DOCKER) == "DevOps"
        assert _categorize_framework(Framework.GITHUB_ACTIONS) == "DevOps"

    def test_cli(self):
        assert _categorize_framework(Framework.CLICK) == "CLI"
        assert _categorize_framework(Framework.COBRA) == "CLI"

    def test_tooling(self):
        assert _categorize_framework(Framework.TAILWIND) == "Tooling"
        assert _categorize_framework(Framework.ESLINT) == "Tooling"
