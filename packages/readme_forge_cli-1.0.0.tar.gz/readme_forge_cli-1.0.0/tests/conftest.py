"""Shared fixtures for readme-forge tests."""

from __future__ import annotations

import json
import textwrap

import pytest

from readme_forge.models import (
    Framework,
    Language,
    LicenseType,
    ProjectInfo,
    ProjectType,
    ReadmeConfig,
)


@pytest.fixture
def tmp_project(tmp_path):
    """Empty temporary project directory."""
    return tmp_path


@pytest.fixture
def python_project(tmp_path):
    """Python project with pyproject.toml and tests."""
    (tmp_path / "pyproject.toml").write_text(textwrap.dedent("""\
        [build-system]
        requires = ["hatchling"]
        build-backend = "hatchling.build"

        [project]
        name = "my-awesome-tool"
        version = "2.1.0"
        description = "An awesome CLI tool for developers"
        requires-python = ">=3.8"
        license = {text = "MIT"}
        authors = [
            {name = "Jane Dev", email = "jane@example.com"},
        ]
        keywords = ["cli", "devtools", "automation"]
        dependencies = [
            "click>=8.0",
            "rich>=13.0",
        ]

        [project.optional-dependencies]
        dev = ["pytest>=8.0", "ruff>=0.4"]

        [project.urls]
        Homepage = "https://github.com/janedev/my-awesome-tool"

        [project.scripts]
        awesome-tool = "my_awesome_tool.cli:cli"

        [tool.hatch.build.targets.wheel]
        packages = ["my_awesome_tool"]
    """))

    pkg_dir = tmp_path / "my_awesome_tool"
    pkg_dir.mkdir()
    (pkg_dir / "__init__.py").write_text('__version__ = "2.1.0"\n')
    (pkg_dir / "cli.py").write_text('import click\n\n@click.command()\ndef cli(): pass\n')

    tests_dir = tmp_path / "tests"
    tests_dir.mkdir()
    (tests_dir / "__init__.py").write_text("")
    (tests_dir / "test_cli.py").write_text("def test_placeholder(): pass\n")

    (tmp_path / "LICENSE").write_text("MIT License\n\nCopyright (c) 2025 Jane Dev\n")
    (tmp_path / "requirements.txt").write_text("click>=8.0\nrich>=13.0\n")
    (tmp_path / "conftest.py").write_text("")

    return tmp_path


@pytest.fixture
def node_project(tmp_path):
    """Node.js project with package.json."""
    pkg = {
        "name": "my-react-app",
        "version": "1.0.0",
        "description": "A modern React application",
        "main": "src/index.js",
        "author": {"name": "John Dev", "email": "john@example.com"},
        "license": "MIT",
        "homepage": "https://github.com/johndev/my-react-app",
        "keywords": ["react", "web", "frontend"],
        "engines": {"node": ">=18"},
        "scripts": {
            "start": "react-scripts start",
            "build": "react-scripts build",
            "test": "jest",
        },
        "dependencies": {
            "react": "^18.2.0",
            "react-dom": "^18.2.0",
        },
        "devDependencies": {
            "jest": "^29.0.0",
            "eslint": "^8.0.0",
            "prettier": "^3.0.0",
            "tailwindcss": "^3.0.0",
        },
    }
    (tmp_path / "package.json").write_text(json.dumps(pkg, indent=2))
    (tmp_path / "tailwind.config.js").write_text("module.exports = {}\n")
    (tmp_path / "LICENSE").write_text("MIT License\n")

    src = tmp_path / "src"
    src.mkdir()
    (src / "index.js").write_text("import React from 'react';\n")
    (src / "App.jsx").write_text("export default function App() { return <div/>; }\n")

    tests = tmp_path / "__tests__"
    tests.mkdir()
    (tests / "App.test.js").write_text("test('renders', () => {});\n")

    return tmp_path


@pytest.fixture
def go_project(tmp_path):
    """Go project with go.mod."""
    (tmp_path / "go.mod").write_text(textwrap.dedent("""\
        module github.com/user/myapi

        go 1.21

        require (
            github.com/gin-gonic/gin v1.9.1
            github.com/spf13/cobra v1.8.0
        )
    """))
    (tmp_path / "main.go").write_text('package main\n\nfunc main() {}\n')
    (tmp_path / "LICENSE").write_text(
        "Apache License, Version 2.0\n"
    )
    return tmp_path


@pytest.fixture
def rust_project(tmp_path):
    """Rust project with Cargo.toml."""
    (tmp_path / "Cargo.toml").write_text(textwrap.dedent("""\
        [package]
        name = "my-cli"
        version = "0.3.0"
        edition = "2021"
        description = "A fast CLI tool"
        authors = ["Rust Dev <rust@example.com>"]

        [dependencies]
        clap = "4.0"
        serde = "1.0"
        tokio = { version = "1.0", features = ["full"] }
    """))
    (tmp_path / "src").mkdir()
    (tmp_path / "src" / "main.rs").write_text("fn main() {}\n")
    return tmp_path


@pytest.fixture
def full_project_info():
    """A fully populated ProjectInfo for testing generation."""
    return ProjectInfo(
        name="super-tool",
        path=".",
        description="A super powerful developer tool",
        version="3.0.0",
        license=LicenseType.MIT,
        primary_language=Language.PYTHON,
        languages=[Language.PYTHON, Language.TYPESCRIPT],
        frameworks=[
            Framework.CLICK, Framework.PYTEST, Framework.HATCH,
            Framework.DOCKER, Framework.GITHUB_ACTIONS,
        ],
        project_type=ProjectType.CLI_TOOL,
        python_version=">=3.8",
        has_git=True,
        git_url="https://github.com/user/super-tool",
        git_default_branch="main",
        author="Test Author",
        author_email="test@example.com",
        homepage="https://github.com/user/super-tool",
        keywords=["cli", "tool", "devops"],
        has_tests=True,
        has_docs=True,
        has_ci=True,
        has_docker=True,
        has_contributing=True,
        has_changelog=True,
        has_examples=True,
        entry_point="super-tool",
        install_command='pip install -e ".[dev]"',
        test_command="pytest tests/ -v",
        build_command="python -m build",
        run_command="super-tool",
    )


@pytest.fixture
def default_config():
    """Default ReadmeConfig."""
    return ReadmeConfig()


@pytest.fixture
def minimal_config():
    """Minimal ReadmeConfig with most sections disabled."""
    return ReadmeConfig(
        include_badges=False,
        include_toc=False,
        include_features=False,
        include_tech_stack=False,
        include_contributing=False,
        include_tree=False,
    )
