"""Tests for readme_forge.templates."""

from __future__ import annotations

import pytest

from readme_forge.models import (
    LicenseType,
    ProjectInfo,
    ProjectType,
    ReadmeConfig,
)
from readme_forge.templates import (
    BUILTIN_TEMPLATES,
    list_templates,
    render_template,
)


class TestBuiltinTemplates:
    def test_minimal_exists(self):
        assert "minimal" in BUILTIN_TEMPLATES

    def test_detailed_exists(self):
        assert "detailed" in BUILTIN_TEMPLATES

    def test_minimal_has_content(self):
        assert len(BUILTIN_TEMPLATES["minimal"]) > 50

    def test_detailed_has_content(self):
        assert len(BUILTIN_TEMPLATES["detailed"]) > 50


class TestRenderTemplate:
    def test_minimal_template(self, full_project_info):
        result = render_template("minimal", full_project_info, ReadmeConfig())
        assert "super-tool" in result
        assert "Installation" in result
        assert "Usage" in result
        assert "License" in result

    def test_minimal_with_description(self):
        info = ProjectInfo(name="test-project", description="A test project")
        result = render_template("minimal", info, ReadmeConfig())
        assert "test-project" in result
        assert "A test project" in result

    def test_minimal_without_description(self):
        info = ProjectInfo(name="test", project_type=ProjectType.LIBRARY)
        result = render_template("minimal", info, ReadmeConfig())
        assert "library" in result.lower()

    def test_minimal_install_command(self):
        info = ProjectInfo(name="test", install_command="pip install test")
        result = render_template("minimal", info, ReadmeConfig())
        assert "pip install test" in result

    def test_minimal_run_command(self):
        info = ProjectInfo(name="test", run_command="python main.py")
        result = render_template("minimal", info, ReadmeConfig())
        assert "python main.py" in result

    def test_minimal_license(self):
        info = ProjectInfo(name="test", license=LicenseType.MIT)
        result = render_template("minimal", info, ReadmeConfig())
        assert "MIT" in result

    def test_file_not_found(self):
        info = ProjectInfo(name="test")
        with pytest.raises(FileNotFoundError):
            render_template("/nonexistent/template.j2", info, ReadmeConfig())

    def test_custom_file_template(self, tmp_path):
        tmpl = tmp_path / "custom.j2"
        tmpl.write_text("# {{ info.name }}\n\nCustom template content\n")
        info = ProjectInfo(name="my-project")
        result = render_template(str(tmpl), info, ReadmeConfig())
        assert "my-project" in result
        assert "Custom template content" in result

    def test_extra_context(self, tmp_path):
        tmpl = tmp_path / "extra.j2"
        tmpl.write_text("# {{ info.name }}\n\n{{ custom_var }}\n")
        info = ProjectInfo(name="test")
        result = render_template(
            str(tmpl), info, ReadmeConfig(),
            extra_context={"custom_var": "HELLO WORLD"},
        )
        assert "HELLO WORLD" in result


class TestListTemplates:
    def test_returns_list(self):
        templates = list_templates()
        assert isinstance(templates, list)
        assert len(templates) >= 2

    def test_has_minimal(self):
        templates = list_templates()
        names = [t["name"] for t in templates]
        assert "minimal" in names

    def test_has_detailed(self):
        templates = list_templates()
        names = [t["name"] for t in templates]
        assert "detailed" in names

    def test_has_descriptions(self):
        templates = list_templates()
        for t in templates:
            assert "description" in t
            assert len(t["description"]) > 10
