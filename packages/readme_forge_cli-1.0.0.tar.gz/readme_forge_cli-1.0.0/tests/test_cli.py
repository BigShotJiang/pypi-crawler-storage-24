"""Tests for readme_forge.cli."""

from __future__ import annotations

import json

import pytest
from click.testing import CliRunner

from readme_forge.cli import cli


@pytest.fixture
def runner():
    return CliRunner()


class TestVersion:
    def test_version_flag(self, runner):
        result = runner.invoke(cli, ["--version"])
        assert result.exit_code == 0
        assert "1.0.0" in result.output


class TestGenerateCommand:
    def test_generate_python(self, runner, python_project):
        result = runner.invoke(cli, ["generate", str(python_project), "--force", "--quiet"])
        assert result.exit_code == 0
        readme = (python_project / "README.md").read_text(encoding="utf-8")
        assert "my-awesome-tool" in readme

    def test_generate_node(self, runner, node_project):
        result = runner.invoke(cli, ["generate", str(node_project), "--force", "--quiet"])
        assert result.exit_code == 0
        readme = (node_project / "README.md").read_text(encoding="utf-8")
        assert "my-react-app" in readme

    def test_generate_preview(self, runner, python_project):
        result = runner.invoke(cli, ["generate", str(python_project), "--preview"])
        assert result.exit_code == 0
        # Should not write file if preview
        assert "Preview" in result.output or "README" in result.output

    def test_generate_no_badges(self, runner, python_project):
        result = runner.invoke(
            cli, ["generate", str(python_project), "--no-badges", "--force", "--quiet"],
        )
        assert result.exit_code == 0
        readme = (python_project / "README.md").read_text(encoding="utf-8")
        assert "shields.io" not in readme

    def test_generate_with_tree(self, runner, python_project):
        result = runner.invoke(
            cli, ["generate", str(python_project), "--tree", "--force", "--quiet"],
        )
        assert result.exit_code == 0
        readme = (python_project / "README.md").read_text(encoding="utf-8")
        assert "Structure" in readme or "```" in readme

    def test_generate_minimal_style(self, runner, python_project):
        result = runner.invoke(cli, [
            "generate", str(python_project),
            "--style", "minimal", "--force", "--quiet",
        ])
        assert result.exit_code == 0

    def test_generate_custom_output(self, runner, python_project):
        result = runner.invoke(cli, [
            "generate", str(python_project),
            "-o", "DOCS.md", "--force", "--quiet",
        ])
        assert result.exit_code == 0
        assert (python_project / "DOCS.md").exists()

    def test_generate_badge_style(self, runner, python_project):
        result = runner.invoke(cli, [
            "generate", str(python_project),
            "--badge-style", "for-the-badge", "--force", "--quiet",
        ])
        assert result.exit_code == 0
        readme = (python_project / "README.md").read_text(encoding="utf-8")
        assert "for-the-badge" in readme

    def test_generate_no_emoji(self, runner, python_project):
        result = runner.invoke(cli, [
            "generate", str(python_project),
            "--no-emoji", "--force", "--quiet",
        ])
        assert result.exit_code == 0

    def test_generate_no_sections(self, runner, python_project):
        result = runner.invoke(cli, [
            "generate", str(python_project),
            "--no-badges", "--no-toc", "--no-features",
            "--no-install", "--no-usage", "--no-contributing",
            "--no-license", "--force", "--quiet",
        ])
        assert result.exit_code == 0

    def test_generate_full_output(self, runner, python_project):
        result = runner.invoke(cli, ["generate", str(python_project), "--force"])
        assert result.exit_code == 0
        assert "Analyzing" in result.output
        assert "Generated" in result.output

    def test_generate_api(self, runner, python_project):
        result = runner.invoke(cli, [
            "generate", str(python_project),
            "--api", "--force", "--quiet",
        ])
        assert result.exit_code == 0

    def test_generate_aborted(self, runner, python_project):
        # First generate
        runner.invoke(cli, ["generate", str(python_project), "--force", "--quiet"])
        # Then try without force - send 'n' to decline overwrite
        result = runner.invoke(cli, ["generate", str(python_project)], input="n\n")
        assert "Cancelled" in result.output or result.exit_code == 0


class TestAnalyzeCommand:
    def test_analyze_python(self, runner, python_project):
        result = runner.invoke(cli, ["analyze", str(python_project)])
        assert result.exit_code == 0
        assert "Python" in result.output
        assert "awesome" in result.output.lower() or "my-awesome-tool" in result.output

    def test_analyze_node(self, runner, node_project):
        result = runner.invoke(cli, ["analyze", str(node_project)])
        assert result.exit_code == 0
        assert "JavaScript" in result.output

    def test_analyze_empty(self, runner, tmp_project):
        result = runner.invoke(cli, ["analyze", str(tmp_project)])
        assert result.exit_code == 0


class TestTreeCommand:
    def test_tree_python(self, runner, python_project):
        result = runner.invoke(cli, ["tree", str(python_project)])
        assert result.exit_code == 0
        assert "├── " in result.output or "└── " in result.output

    def test_tree_depth(self, runner, python_project):
        result = runner.invoke(cli, ["tree", str(python_project), "--depth", "1"])
        assert result.exit_code == 0

    def test_tree_empty(self, runner, tmp_project):
        result = runner.invoke(cli, ["tree", str(tmp_project)])
        assert result.exit_code == 0


class TestStatsCommand:
    def test_stats_python(self, runner, python_project):
        result = runner.invoke(cli, ["stats", str(python_project)])
        assert result.exit_code == 0

    def test_stats_empty(self, runner, tmp_project):
        result = runner.invoke(cli, ["stats", str(tmp_project)])
        assert result.exit_code == 0
        assert "0" in result.output


class TestTemplatesCommand:
    def test_list_templates(self, runner):
        result = runner.invoke(cli, ["templates"])
        assert result.exit_code == 0
        assert "minimal" in result.output
        assert "detailed" in result.output


class TestFromTemplateCommand:
    def test_minimal_template(self, runner, python_project):
        result = runner.invoke(cli, [
            "from-template", str(python_project),
            "-t", "minimal", "--force",
        ])
        assert result.exit_code == 0
        readme = (python_project / "README.md").read_text(encoding="utf-8")
        assert "my-awesome-tool" in readme

    def test_nonexistent_template(self, runner, python_project):
        result = runner.invoke(cli, [
            "from-template", str(python_project),
            "-t", "/nonexistent.j2",
        ])
        assert result.exit_code != 0

    def test_custom_output(self, runner, python_project):
        result = runner.invoke(cli, [
            "from-template", str(python_project),
            "-t", "minimal", "-o", "CUSTOM.md", "--force",
        ])
        assert result.exit_code == 0
        assert (python_project / "CUSTOM.md").exists()


class TestDetectCommand:
    def test_detect_python(self, runner, python_project):
        result = runner.invoke(cli, ["detect", str(python_project)])
        assert result.exit_code == 0
        assert "Python" in result.output
        assert "CLI Tool" in result.output

    def test_detect_json(self, runner, python_project):
        result = runner.invoke(cli, ["detect", str(python_project), "--format", "json"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["language"] == "Python"
        assert "CLI Tool" in data["project_type"]

    def test_detect_node(self, runner, node_project):
        result = runner.invoke(cli, ["detect", str(node_project), "--format", "json"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert "JavaScript" in data["language"] or "JavaScript" in data["languages"]

    def test_detect_empty(self, runner, tmp_project):
        result = runner.invoke(cli, ["detect", str(tmp_project)])
        assert result.exit_code == 0
        assert "Unknown" in result.output
