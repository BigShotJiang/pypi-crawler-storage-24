"""Tests for readme_forge.analyzer."""

from __future__ import annotations

import json

from readme_forge.analyzer import (
    analyze_project,
    build_directory_tree,
    get_file_stats,
    tree_to_text,
)
from readme_forge.models import (
    Framework,
    Language,
    LicenseType,
    ProjectType,
)


class TestAnalyzeProject:
    def test_python_project(self, python_project):
        info = analyze_project(str(python_project))
        assert info.name == "my-awesome-tool"
        assert info.version == "2.1.0"
        assert info.description == "An awesome CLI tool for developers"
        assert info.primary_language == Language.PYTHON
        assert info.license == LicenseType.MIT
        assert info.author == "Jane Dev"
        assert info.python_version == ">=3.8"
        assert info.has_tests is True
        assert info.entry_point == "awesome-tool"
        assert "pip install" in info.install_command

    def test_node_project(self, node_project):
        info = analyze_project(str(node_project))
        assert info.name == "my-react-app"
        assert info.version == "1.0.0"
        assert info.description == "A modern React application"
        assert Language.JAVASCRIPT in info.languages
        assert info.license == LicenseType.MIT
        assert info.author == "John Dev"
        assert info.node_version == ">=18"

    def test_go_project(self, go_project):
        info = analyze_project(str(go_project))
        assert info.primary_language == Language.GO
        assert info.go_version == "1.21"
        assert info.license == LicenseType.APACHE2
        assert info.test_command == "go test ./..."

    def test_rust_project(self, rust_project):
        info = analyze_project(str(rust_project))
        assert info.name == "my-cli"
        assert info.version == "0.3.0"
        assert info.primary_language == Language.RUST
        assert info.rust_edition == "2021"
        assert "cargo" in info.install_command

    def test_empty_dir(self, tmp_project):
        info = analyze_project(str(tmp_project))
        assert info.primary_language == Language.UNKNOWN
        assert info.project_type == ProjectType.UNKNOWN

    def test_nonexistent(self, tmp_path):
        info = analyze_project(str(tmp_path / "nonexistent"))
        assert info.name == ""

    def test_keywords_detected(self, python_project):
        info = analyze_project(str(python_project))
        assert "cli" in info.keywords
        assert "devtools" in info.keywords

    def test_homepage_detected(self, python_project):
        info = analyze_project(str(python_project))
        assert "github.com" in info.homepage


class TestLanguageDetection:
    def test_python_files(self, tmp_path):
        (tmp_path / "main.py").write_text("print('hello')\n")
        (tmp_path / "utils.py").write_text("def helper(): pass\n")
        info = analyze_project(str(tmp_path))
        assert info.primary_language == Language.PYTHON

    def test_javascript_files(self, tmp_path):
        (tmp_path / "index.js").write_text("console.log('hi');\n")
        (tmp_path / "app.jsx").write_text("export default App;\n")
        info = analyze_project(str(tmp_path))
        assert Language.JAVASCRIPT in info.languages

    def test_typescript_files(self, tmp_path):
        (tmp_path / "index.ts").write_text("const x: number = 1;\n")
        (tmp_path / "App.tsx").write_text("export default App;\n")
        info = analyze_project(str(tmp_path))
        assert Language.TYPESCRIPT in info.languages

    def test_go_files(self, tmp_path):
        (tmp_path / "main.go").write_text("package main\n")
        info = analyze_project(str(tmp_path))
        assert info.primary_language == Language.GO

    def test_rust_files(self, tmp_path):
        (tmp_path / "main.rs").write_text("fn main() {}\n")
        info = analyze_project(str(tmp_path))
        assert info.primary_language == Language.RUST

    def test_mixed_languages(self, tmp_path):
        for i in range(5):
            (tmp_path / f"file{i}.py").write_text("pass\n")
        (tmp_path / "script.js").write_text(";\n")
        info = analyze_project(str(tmp_path))
        assert info.primary_language == Language.PYTHON
        assert len(info.languages) >= 2

    def test_skip_node_modules(self, tmp_path):
        nm = tmp_path / "node_modules" / "pkg"
        nm.mkdir(parents=True)
        (nm / "index.js").write_text("module.exports = {};\n")
        (tmp_path / "main.py").write_text("pass\n")
        info = analyze_project(str(tmp_path))
        assert info.primary_language == Language.PYTHON


class TestFrameworkDetection:
    def test_click_detected(self, python_project):
        info = analyze_project(str(python_project))
        assert Framework.CLICK in info.frameworks

    def test_hatch_detected(self, python_project):
        info = analyze_project(str(python_project))
        assert Framework.HATCH in info.frameworks

    def test_pytest_detected(self, python_project):
        info = analyze_project(str(python_project))
        assert Framework.PYTEST in info.frameworks

    def test_react_detected(self, node_project):
        info = analyze_project(str(node_project))
        assert Framework.REACT in info.frameworks

    def test_jest_detected(self, node_project):
        info = analyze_project(str(node_project))
        assert Framework.JEST in info.frameworks

    def test_tailwind_detected(self, node_project):
        info = analyze_project(str(node_project))
        assert Framework.TAILWIND in info.frameworks

    def test_eslint_detected(self, node_project):
        info = analyze_project(str(node_project))
        assert Framework.ESLINT in info.frameworks

    def test_gin_detected(self, go_project):
        info = analyze_project(str(go_project))
        assert Framework.GIN in info.frameworks

    def test_cobra_detected(self, go_project):
        info = analyze_project(str(go_project))
        assert Framework.COBRA in info.frameworks

    def test_clap_detected(self, rust_project):
        info = analyze_project(str(rust_project))
        assert Framework.CLAP in info.frameworks

    def test_serde_detected(self, rust_project):
        info = analyze_project(str(rust_project))
        assert Framework.SERDE in info.frameworks

    def test_tokio_detected(self, rust_project):
        info = analyze_project(str(rust_project))
        assert Framework.TOKIO in info.frameworks

    def test_docker_detected(self, tmp_path):
        (tmp_path / "Dockerfile").write_text("FROM python:3.11\n")
        info = analyze_project(str(tmp_path))
        assert Framework.DOCKER in info.frameworks

    def test_github_actions_detected(self, tmp_path):
        wf = tmp_path / ".github" / "workflows"
        wf.mkdir(parents=True)
        (wf / "ci.yml").write_text("name: CI\n")
        info = analyze_project(str(tmp_path))
        assert Framework.GITHUB_ACTIONS in info.frameworks

    def test_django_detected(self, tmp_path):
        (tmp_path / "requirements.txt").write_text("django>=4.0\n")
        (tmp_path / "manage.py").write_text("#!/usr/bin/env python\n")
        info = analyze_project(str(tmp_path))
        assert Framework.DJANGO in info.frameworks

    def test_fastapi_detected(self, tmp_path):
        (tmp_path / "requirements.txt").write_text("fastapi>=0.100\nuvicorn\n")
        (tmp_path / "main.py").write_text("from fastapi import FastAPI\n")
        info = analyze_project(str(tmp_path))
        assert Framework.FASTAPI in info.frameworks

    def test_spring_boot_detected(self, tmp_path):
        (tmp_path / "pom.xml").write_text("<dependency>spring-boot</dependency>\n")
        (tmp_path / "src").mkdir()
        (tmp_path / "src" / "App.java").write_text("public class App {}\n")
        info = analyze_project(str(tmp_path))
        assert Framework.SPRING in info.frameworks

    def test_rails_detected(self, tmp_path):
        (tmp_path / "Gemfile").write_text("gem 'rails', '~> 7.0'\n")
        (tmp_path / "app.rb").write_text("class App < Rails::Application; end\n")
        info = analyze_project(str(tmp_path))
        assert Framework.RAILS in info.frameworks


class TestProjectTypeDetection:
    def test_cli_tool(self, python_project):
        info = analyze_project(str(python_project))
        assert info.project_type == ProjectType.CLI_TOOL

    def test_web_app(self, node_project):
        info = analyze_project(str(node_project))
        assert info.project_type == ProjectType.WEB_APP

    def test_library_default(self, tmp_path):
        (tmp_path / "lib.py").write_text("def helper(): pass\n")
        info = analyze_project(str(tmp_path))
        assert info.project_type == ProjectType.LIBRARY

    def test_api_server(self, tmp_path):
        (tmp_path / "requirements.txt").write_text("fastapi>=0.100\n")
        (tmp_path / "main.py").write_text("app = FastAPI()\n")
        info = analyze_project(str(tmp_path))
        assert info.project_type == ProjectType.API_SERVER

    def test_terraform(self, tmp_path):
        (tmp_path / "main.tf").write_text('resource "aws_instance" "web" {}\n')
        info = analyze_project(str(tmp_path))
        assert info.project_type == ProjectType.CONFIGURATION


class TestLicenseDetection:
    def test_mit_license(self, python_project):
        info = analyze_project(str(python_project))
        assert info.license == LicenseType.MIT

    def test_apache_license(self, go_project):
        info = analyze_project(str(go_project))
        assert info.license == LicenseType.APACHE2

    def test_gpl_license(self, tmp_path):
        (tmp_path / "LICENSE").write_text(
            "GNU GENERAL PUBLIC LICENSE\nVersion 3, 29 June 2007\n"
        )
        info = analyze_project(str(tmp_path))
        assert info.license == LicenseType.GPL3

    def test_bsd_license(self, tmp_path):
        (tmp_path / "LICENSE").write_text(
            "Redistribution and use in source and binary forms\n"
        )
        info = analyze_project(str(tmp_path))
        assert info.license == LicenseType.BSD3

    def test_no_license(self, tmp_project):
        info = analyze_project(str(tmp_project))
        assert info.license == LicenseType.UNKNOWN

    def test_license_from_package_json(self, tmp_path):
        pkg = {"name": "test", "license": "ISC"}
        (tmp_path / "package.json").write_text(json.dumps(pkg))
        info = analyze_project(str(tmp_path))
        assert info.license == LicenseType.ISC


class TestStructureDetection:
    def test_has_tests(self, python_project):
        info = analyze_project(str(python_project))
        assert info.has_tests is True

    def test_no_tests(self, tmp_project):
        info = analyze_project(str(tmp_project))
        assert info.has_tests is False

    def test_has_ci(self, tmp_path):
        wf = tmp_path / ".github" / "workflows"
        wf.mkdir(parents=True)
        (wf / "ci.yml").write_text("name: CI\n")
        info = analyze_project(str(tmp_path))
        assert info.has_ci is True

    def test_has_docker(self, tmp_path):
        (tmp_path / "Dockerfile").write_text("FROM alpine\n")
        info = analyze_project(str(tmp_path))
        assert info.has_docker is True

    def test_has_contributing(self, tmp_path):
        (tmp_path / "CONTRIBUTING.md").write_text("# Contributing\n")
        info = analyze_project(str(tmp_path))
        assert info.has_contributing is True

    def test_has_changelog(self, tmp_path):
        (tmp_path / "CHANGELOG.md").write_text("# Changelog\n")
        info = analyze_project(str(tmp_path))
        assert info.has_changelog is True

    def test_has_examples(self, tmp_path):
        (tmp_path / "examples").mkdir()
        info = analyze_project(str(tmp_path))
        assert info.has_examples is True


class TestCommandDetection:
    def test_python_commands(self, python_project):
        info = analyze_project(str(python_project))
        assert "pip install" in info.install_command
        assert "pytest" in info.test_command
        assert info.run_command == "awesome-tool"

    def test_node_commands(self, node_project):
        info = analyze_project(str(node_project))
        assert "npm install" in info.install_command
        assert info.test_command == "npm test"

    def test_go_commands(self, go_project):
        info = analyze_project(str(go_project))
        assert "go mod" in info.install_command
        assert "go test" in info.test_command

    def test_rust_commands(self, rust_project):
        info = analyze_project(str(rust_project))
        assert "cargo" in info.install_command
        assert "cargo test" in info.test_command

    def test_manage_py_run(self, tmp_path):
        (tmp_path / "manage.py").write_text("#!/usr/bin/env python\n")
        (tmp_path / "app.py").write_text("from django import *\n")
        (tmp_path / "requirements.txt").write_text("django\n")
        info = analyze_project(str(tmp_path))
        assert "manage.py" in info.run_command


class TestGetFileStats:
    def test_basic(self, python_project):
        stats = get_file_stats(str(python_project))
        assert stats.total_files > 0
        assert stats.total_dirs >= 0

    def test_empty(self, tmp_project):
        stats = get_file_stats(str(tmp_project))
        assert stats.total_files == 0

    def test_file_types(self, python_project):
        stats = get_file_stats(str(python_project))
        assert ".py" in stats.file_types

    def test_line_count(self, tmp_path):
        (tmp_path / "code.py").write_text("line1\nline2\nline3\n")
        stats = get_file_stats(str(tmp_path))
        assert stats.total_lines >= 3


class TestBuildDirectoryTree:
    def test_basic(self, python_project):
        tree = build_directory_tree(str(python_project))
        assert tree.is_dir is True
        assert len(tree.children) > 0

    def test_depth_limit(self, tmp_path):
        deep = tmp_path / "a" / "b" / "c" / "d" / "e"
        deep.mkdir(parents=True)
        (deep / "file.txt").write_text("deep\n")

        tree = build_directory_tree(str(tmp_path), max_depth=2)
        # Should not go deeper than 2
        max_depth = _get_max_depth(tree)
        assert max_depth <= 2

    def test_skips_git(self, tmp_path):
        (tmp_path / ".git").mkdir()
        (tmp_path / ".git" / "config").write_text("")
        (tmp_path / "src").mkdir()
        tree = build_directory_tree(str(tmp_path))
        names = [c.name for c in tree.children]
        assert ".git" not in names
        assert "src" in names

    def test_skips_node_modules(self, tmp_path):
        (tmp_path / "node_modules").mkdir()
        (tmp_path / "src").mkdir()
        tree = build_directory_tree(str(tmp_path))
        names = [c.name for c in tree.children]
        assert "node_modules" not in names


class TestTreeToText:
    def test_basic(self, python_project):
        tree = build_directory_tree(str(python_project))
        text = tree_to_text(tree)
        assert python_project.name in text
        assert "├── " in text or "└── " in text

    def test_dirs_have_slash(self, tmp_path):
        (tmp_path / "src").mkdir()
        (tmp_path / "src" / "main.py").write_text("")
        tree = build_directory_tree(str(tmp_path))
        text = tree_to_text(tree)
        assert "src/" in text

    def test_empty_dir(self, tmp_project):
        tree = build_directory_tree(str(tmp_project))
        text = tree_to_text(tree)
        assert tmp_project.name in text


def _get_max_depth(node, current=0):
    if not node.children:
        return current
    return max(_get_max_depth(c, current + 1) for c in node.children)
