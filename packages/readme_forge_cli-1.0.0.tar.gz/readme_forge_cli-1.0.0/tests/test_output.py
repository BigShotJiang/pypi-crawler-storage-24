"""Tests for readme_forge.output."""

from __future__ import annotations

from io import StringIO

from rich.console import Console

from readme_forge.models import (
    FileStats,
    ProjectInfo,
    ReadmeConfig,
)
from readme_forge.output import (
    render_file_stats,
    render_generation_summary,
    render_project_info,
    render_readme_preview,
)


def _capture_output(func, *args, **kwargs):
    """Capture Rich console output."""
    buf = StringIO()
    console = Console(file=buf, force_terminal=True, width=120)

    # Temporarily replace module console
    import readme_forge.output as output_mod
    original = output_mod.console
    output_mod.console = console

    try:
        func(*args, **kwargs)
        return buf.getvalue()
    finally:
        output_mod.console = original


class TestRenderProjectInfo:
    def test_basic(self, full_project_info):
        output = _capture_output(render_project_info, full_project_info)
        assert "super-tool" in output
        assert "Python" in output
        assert "CLI Tool" in output

    def test_shows_frameworks(self, full_project_info):
        output = _capture_output(render_project_info, full_project_info)
        assert "Click" in output or "Docker" in output

    def test_shows_license(self, full_project_info):
        output = _capture_output(render_project_info, full_project_info)
        assert "MIT" in output

    def test_shows_author(self, full_project_info):
        output = _capture_output(render_project_info, full_project_info)
        assert "Test Author" in output

    def test_shows_commands(self, full_project_info):
        output = _capture_output(render_project_info, full_project_info)
        assert "pip install" in output
        assert "pytest" in output

    def test_shows_structure_flags(self, full_project_info):
        output = _capture_output(render_project_info, full_project_info)
        assert "Tests" in output
        assert "Docker" in output

    def test_minimal_info(self):
        info = ProjectInfo(name="basic")
        output = _capture_output(render_project_info, info)
        assert "basic" in output


class TestRenderFileStats:
    def test_basic(self):
        stats = FileStats(
            total_files=42,
            total_dirs=8,
            total_lines=1500,
            file_types={".py": 20, ".js": 10, ".md": 5},
        )
        output = _capture_output(render_file_stats, stats)
        assert "42" in output
        assert "8" in output
        assert "1,500" in output

    def test_empty_stats(self):
        stats = FileStats()
        output = _capture_output(render_file_stats, stats)
        assert "0" in output


class TestRenderReadmePreview:
    def test_short_content(self):
        content = "# Test\n\nShort README.\n"
        output = _capture_output(render_readme_preview, content)
        assert "Test" in output
        assert "Short README" in output

    def test_long_content_truncated(self):
        lines = [f"Line {i}" for i in range(100)]
        content = "\n".join(lines)
        output = _capture_output(render_readme_preview, content, max_lines=10)
        assert "more lines" in output

    def test_shows_line_count(self):
        content = "line1\nline2\nline3\n"
        output = _capture_output(render_readme_preview, content)
        assert "3" in output or "lines" in output


class TestRenderGenerationSummary:
    def test_basic(self, full_project_info):
        config = ReadmeConfig()
        output = _capture_output(
            render_generation_summary, full_project_info, config, "README.md"
        )
        assert "README.md" in output
        assert "Generated" in output

    def test_shows_sections(self, full_project_info):
        config = ReadmeConfig()
        output = _capture_output(
            render_generation_summary, full_project_info, config, "README.md"
        )
        assert "Badges" in output or "Features" in output

    def test_shows_style(self, full_project_info):
        config = ReadmeConfig(badge_style="for-the-badge", header_style="minimal")
        output = _capture_output(
            render_generation_summary, full_project_info, config, "README.md"
        )
        assert "for-the-badge" in output
        assert "minimal" in output
