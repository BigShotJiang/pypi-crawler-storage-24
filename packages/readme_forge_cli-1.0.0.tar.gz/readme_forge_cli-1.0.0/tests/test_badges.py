"""Tests for readme_forge.badges."""

from __future__ import annotations

from readme_forge.badges import (
    _extract_owner_repo,
    _framework_logo,
    _lang_logo,
    generate_badge_line,
    generate_badges,
)
from readme_forge.models import (
    Framework,
    Language,
    LicenseType,
    ProjectInfo,
)


class TestGenerateBadges:
    def test_language_badge(self):
        info = ProjectInfo(primary_language=Language.PYTHON)
        badges = generate_badges(info)
        assert any("Python" in b for b in badges)
        assert any("3776AB" in b for b in badges)

    def test_version_badge(self):
        info = ProjectInfo(version="1.2.3")
        badges = generate_badges(info)
        assert any("1.2.3" in b for b in badges)

    def test_license_badge(self):
        info = ProjectInfo(license=LicenseType.MIT)
        badges = generate_badges(info)
        assert any("MIT" in b for b in badges)

    def test_pypi_badge(self):
        info = ProjectInfo(
            name="my-tool",
            primary_language=Language.PYTHON,
            entry_point="my-tool",
        )
        badges = generate_badges(info)
        assert any("pypi" in b.lower() for b in badges)

    def test_npm_badge(self):
        info = ProjectInfo(
            name="my-pkg",
            primary_language=Language.JAVASCRIPT,
        )
        badges = generate_badges(info)
        assert any("npm" in b.lower() for b in badges)

    def test_ci_badge(self):
        info = ProjectInfo(
            has_ci=True,
            git_url="https://github.com/user/repo",
        )
        badges = generate_badges(info)
        assert any("actions" in b.lower() for b in badges)

    def test_framework_badges(self):
        info = ProjectInfo(frameworks=[Framework.DOCKER, Framework.REACT])
        badges = generate_badges(info)
        assert any("Docker" in b for b in badges)
        assert any("React" in b for b in badges)

    def test_empty_info(self):
        info = ProjectInfo()
        badges = generate_badges(info)
        assert badges == []

    def test_badge_style(self):
        info = ProjectInfo(primary_language=Language.GO)
        badges = generate_badges(info, style="for-the-badge")
        assert any("for-the-badge" in b for b in badges)

    def test_framework_limit(self):
        info = ProjectInfo(
            frameworks=[Framework.DOCKER, Framework.REACT, Framework.JEST,
                        Framework.ESLINT, Framework.PRETTIER, Framework.TAILWIND,
                        Framework.VITE, Framework.WEBPACK]
        )
        badges = generate_badges(info)
        # Should limit framework badges
        fw_badges = [b for b in badges if "555555" in b]
        assert len(fw_badges) <= 5

    def test_no_unknown_license_badge(self):
        info = ProjectInfo(license=LicenseType.UNKNOWN)
        badges = generate_badges(info)
        assert not any("license" in b.lower() for b in badges)


class TestGenerateBadgeLine:
    def test_returns_string(self):
        info = ProjectInfo(primary_language=Language.PYTHON, version="1.0.0")
        line = generate_badge_line(info)
        assert isinstance(line, str)
        assert "Python" in line

    def test_empty(self):
        info = ProjectInfo()
        line = generate_badge_line(info)
        assert line == ""


class TestExtractOwnerRepo:
    def test_https_url(self):
        assert _extract_owner_repo("https://github.com/user/repo") == "user/repo"

    def test_https_with_git(self):
        assert _extract_owner_repo("https://github.com/user/repo.git") == "user/repo"

    def test_trailing_slash(self):
        assert _extract_owner_repo("https://github.com/user/repo/") == "user/repo"

    def test_non_github(self):
        assert _extract_owner_repo("https://gitlab.com/user/repo") == ""

    def test_empty(self):
        assert _extract_owner_repo("") == ""


class TestLangLogo:
    def test_python(self):
        assert _lang_logo(Language.PYTHON) == "python"

    def test_javascript(self):
        assert _lang_logo(Language.JAVASCRIPT) == "javascript"

    def test_go(self):
        assert _lang_logo(Language.GO) == "go"

    def test_rust(self):
        assert _lang_logo(Language.RUST) == "rust"

    def test_unknown(self):
        assert _lang_logo(Language.UNKNOWN) == ""


class TestFrameworkLogo:
    def test_docker(self):
        assert _framework_logo(Framework.DOCKER) == "docker"

    def test_react(self):
        assert _framework_logo(Framework.REACT) == "react"

    def test_django(self):
        assert _framework_logo(Framework.DJANGO) == "django"

    def test_pytest(self):
        assert _framework_logo(Framework.PYTEST) == "pytest"

    def test_spring(self):
        assert _framework_logo(Framework.SPRING) == "springboot"
