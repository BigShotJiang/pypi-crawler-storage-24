"""README content generation engine."""

from __future__ import annotations

from .analyzer import build_directory_tree, tree_to_text
from .badges import generate_badge_line
from .models import (
    Framework,
    Language,
    LicenseType,
    ProjectInfo,
    ProjectType,
    ReadmeConfig,
    Section,
)

# ── Section Emojis ───────────────────────────────────────────

SECTION_EMOJIS: dict[str, str] = {
    "Features": "✨",
    "Tech Stack": "🛠️",
    "Prerequisites": "📋",
    "Installation": "🚀",
    "Usage": "📖",
    "API Reference": "📡",
    "Configuration": "⚙️",
    "Testing": "🧪",
    "Deployment": "🚢",
    "Project Structure": "📁",
    "Contributing": "🤝",
    "License": "📄",
    "Acknowledgements": "🙏",
    "FAQ": "❓",
    "Roadmap": "🗺️",
    "Authors": "👥",
    "Support": "💬",
}


def generate_readme(info: ProjectInfo, config: ReadmeConfig | None = None) -> str:
    """Generate a complete README.md from project info."""
    if config is None:
        config = ReadmeConfig()

    sections: list[Section] = []
    order = 0

    # Header
    header = _generate_header(info, config)

    # Badges
    badge_section = ""
    if config.include_badges:
        badge_line = generate_badge_line(info, config.badge_style)
        if badge_line:
            badge_section = f"\n{badge_line}\n"

    # Table of Contents
    toc_sections: list[Section] = []

    # Features
    if config.include_features:
        order += 1
        features = _generate_features(info, config)
        if features:
            s = Section(title="Features", content=features, order=order)
            sections.append(s)
            toc_sections.append(s)

    # Tech Stack
    if config.include_tech_stack and info.frameworks:
        order += 1
        tech = _generate_tech_stack(info)
        if tech:
            s = Section(title="Tech Stack", content=tech, order=order)
            sections.append(s)
            toc_sections.append(s)

    # Installation
    if config.include_installation and info.install_command:
        order += 1
        install = _generate_installation(info)
        s = Section(title="Installation", content=install, order=order)
        sections.append(s)
        toc_sections.append(s)

    # Usage
    if config.include_usage:
        order += 1
        usage = _generate_usage(info)
        if usage:
            s = Section(title="Usage", content=usage, order=order)
            sections.append(s)
            toc_sections.append(s)

    # Project Structure (tree)
    if config.include_tree:
        order += 1
        tree = _generate_tree(info, config)
        if tree:
            s = Section(title="Project Structure", content=tree, order=order)
            sections.append(s)
            toc_sections.append(s)

    # Testing
    if info.test_command:
        order += 1
        testing = _generate_testing(info)
        s = Section(title="Testing", content=testing, order=order)
        sections.append(s)
        toc_sections.append(s)

    # API Reference
    if config.include_api:
        order += 1
        api = _generate_api_reference(info)
        if api:
            s = Section(title="API Reference", content=api, order=order)
            sections.append(s)
            toc_sections.append(s)

    # Custom sections
    for custom in config.custom_sections:
        order += 1
        custom.order = order
        sections.append(custom)
        toc_sections.append(custom)

    # Contributing
    if config.include_contributing:
        order += 1
        contributing = _generate_contributing(info)
        s = Section(title="Contributing", content=contributing, order=order)
        sections.append(s)
        toc_sections.append(s)

    # License
    if config.include_license:
        order += 1
        license_section = _generate_license(info)
        s = Section(title="License", content=license_section, order=order)
        sections.append(s)
        toc_sections.append(s)

    # Acknowledgements
    if config.include_acknowledgements and config.acknowledgements:
        order += 1
        ack = _generate_acknowledgements(config)
        s = Section(title="Acknowledgements", content=ack, order=order)
        sections.append(s)
        toc_sections.append(s)

    # Build the README
    parts: list[str] = [header]

    if badge_section:
        parts.append(badge_section)

    # Description
    if info.description:
        parts.append(f"\n{info.description}\n")

    # Table of Contents
    if config.include_toc and len(toc_sections) >= 3:
        toc = _generate_toc(toc_sections, config)
        parts.append(f"\n---\n\n{toc}")

    # Render sections
    for section in sections:
        if not section.include:
            continue
        emoji = ""
        if config.emoji_headers:
            emoji = SECTION_EMOJIS.get(section.title, "📌") + " "
        parts.append(f"\n---\n\n## {emoji}{section.title}\n\n{section.content}")

    # Footer
    parts.append("\n---\n")
    if info.author:
        parts.append(f"\n<p align=\"center\">Made with ❤️ by {info.author}</p>\n")

    return "\n".join(parts) + "\n"


# ── Header Generation ────────────────────────────────────────


def _generate_header(info: ProjectInfo, config: ReadmeConfig) -> str:
    """Generate the README header."""
    name = info.display_name
    if info.name:
        name = info.name

    if config.header_style == "banner":
        lines = [f"# {name}"]
        if info.description:
            lines.append("")
            lines.append(f"> {info.description}")
        return "\n".join(lines)

    elif config.header_style == "minimal":
        return f"# {name}"

    else:  # simple
        lines = [f"# {name}"]
        if info.description:
            lines.append("")
            lines.append(info.description)
        return "\n".join(lines)


# ── Table of Contents ────────────────────────────────────────


def _generate_toc(sections: list[Section], config: ReadmeConfig) -> str:
    """Generate table of contents."""
    lines = ["## 📑 Table of Contents", ""]

    for i, section in enumerate(sections, 1):
        emoji = ""
        if config.emoji_headers:
            emoji = SECTION_EMOJIS.get(section.title, "📌") + " "

        if config.toc_style == "numbered":
            lines.append(f"{i}. [{emoji}{section.title}](#{section.anchor})")
        else:
            lines.append(f"- [{emoji}{section.title}](#{section.anchor})")

    return "\n".join(lines)


# ── Features ─────────────────────────────────────────────────


def _generate_features(info: ProjectInfo, config: ReadmeConfig) -> str:
    """Generate features section."""
    features = list(config.features) if config.features else []

    if not features:
        features = _auto_detect_features(info)

    if not features:
        return ""

    lines = []
    for feat in features:
        lines.append(f"- **{feat}**")

    return "\n".join(lines)


def _auto_detect_features(info: ProjectInfo) -> list[str]:
    """Auto-detect features from project info."""
    features: list[str] = []

    # Project type based
    type_features = {
        ProjectType.CLI_TOOL: [
            "Command-line interface with intuitive commands",
            "Rich terminal output with colors and formatting",
        ],
        ProjectType.WEB_APP: [
            "Modern web application with responsive design",
            "Component-based architecture",
        ],
        ProjectType.API_SERVER: [
            "RESTful API with structured endpoints",
            "Request validation and error handling",
        ],
        ProjectType.LIBRARY: [
            "Clean, well-documented API",
            "Comprehensive type hints and documentation",
        ],
    }

    features.extend(type_features.get(info.project_type, []))

    # Framework based
    if Framework.DOCKER in info.frameworks:
        features.append("Docker support for containerized deployment")
    if Framework.GITHUB_ACTIONS in info.frameworks:
        features.append("CI/CD pipeline with GitHub Actions")
    if info.has_tests:
        features.append("Comprehensive test suite")
    if Framework.TAILWIND in info.frameworks:
        features.append("Utility-first CSS with Tailwind")

    # Multi-language
    if len(info.languages) > 1:
        lang_names = ", ".join(lang.value for lang in info.languages[:3])
        features.append(f"Multi-language support ({lang_names})")

    return features


# ── Tech Stack ───────────────────────────────────────────────


def _generate_tech_stack(info: ProjectInfo) -> str:
    """Generate tech stack section."""
    if not info.frameworks:
        return ""

    lines = ["| Category | Technology |", "|----------|-----------|"]

    # Group frameworks by category
    categories: dict[str, list[str]] = {}

    lang_display = info.primary_language.value
    if info.python_version:
        lang_display += f" {info.python_version}"
    elif info.go_version:
        lang_display += f" {info.go_version}"
    elif info.rust_edition:
        lang_display += f" Edition {info.rust_edition}"
    elif info.node_version:
        lang_display = f"Node.js {info.node_version}"

    categories["Language"] = [lang_display]

    for fw in info.frameworks:
        cat = _categorize_framework(fw)
        if cat not in categories:
            categories[cat] = []
        categories[cat].append(fw.value)

    for cat, techs in categories.items():
        lines.append(f"| **{cat}** | {', '.join(techs)} |")

    return "\n".join(lines)


def _categorize_framework(fw: Framework) -> str:
    """Categorize a framework."""
    web = {
        Framework.DJANGO, Framework.FLASK, Framework.FASTAPI,
        Framework.REACT, Framework.NEXTJS, Framework.VUE, Framework.ANGULAR,
        Framework.EXPRESS, Framework.NESTJS, Framework.RAILS, Framework.SINATRA,
        Framework.GIN, Framework.ECHO, Framework.FIBER,
        Framework.ACTIX, Framework.ROCKET, Framework.SPRING,
    }
    testing = {Framework.PYTEST, Framework.JEST, Framework.MOCHA, Framework.RSPEC}
    build = {
        Framework.SETUPTOOLS, Framework.POETRY, Framework.HATCH,
        Framework.MAVEN, Framework.GRADLE, Framework.WEBPACK, Framework.VITE,
    }
    devops = {
        Framework.DOCKER, Framework.KUBERNETES, Framework.TERRAFORM,
        Framework.GITHUB_ACTIONS, Framework.GITLAB_CI,
    }
    styling = {Framework.TAILWIND, Framework.PRETTIER, Framework.ESLINT, Framework.STORYBOOK}
    data = {
        Framework.SQLALCHEMY, Framework.PYDANTIC, Framework.CELERY,
        Framework.SERDE, Framework.TOKIO,
    }
    cli = {Framework.CLICK, Framework.TYPER, Framework.COBRA, Framework.CLAP}
    docs = {Framework.SPHINX}

    if fw in web:
        return "Framework"
    if fw in testing:
        return "Testing"
    if fw in build:
        return "Build"
    if fw in devops:
        return "DevOps"
    if fw in styling:
        return "Tooling"
    if fw in data:
        return "Data"
    if fw in cli:
        return "CLI"
    if fw in docs:
        return "Docs"
    return "Other"


# ── Installation ─────────────────────────────────────────────


def _generate_installation(info: ProjectInfo) -> str:
    """Generate installation section."""
    lines = []

    # Prerequisites
    prereqs = _get_prerequisites(info)
    if prereqs:
        lines.append("### Prerequisites\n")
        for p in prereqs:
            lines.append(f"- {p}")
        lines.append("")

    # Clone
    lines.append("### Setup\n")

    if info.git_url:
        lines.append("```bash")
        lines.append("# Clone the repository")
        lines.append(f"git clone {info.git_url}.git")
        lines.append(f"cd {info.name or 'project'}")
        lines.append("")

    # Install
    if info.install_command:
        if not info.git_url:
            lines.append("```bash")
        lines.append("# Install dependencies")
        lines.append(info.install_command)
        lines.append("```")
    elif info.git_url:
        lines.append("```")

    # Package manager install
    if info.entry_point and info.name:
        lines.append("")
        lines.append("### Quick Install\n")
        if info.primary_language == Language.PYTHON:
            lines.append("```bash")
            lines.append(f"pip install {info.name}")
            lines.append("```")
        elif info.primary_language in (Language.JAVASCRIPT, Language.TYPESCRIPT):
            lines.append("```bash")
            lines.append(f"npm install {info.name}")
            lines.append("```")

    return "\n".join(lines)


def _get_prerequisites(info: ProjectInfo) -> list[str]:
    """Get prerequisite list."""
    prereqs = []

    if info.primary_language == Language.PYTHON:
        ver = info.python_version or "3.8+"
        prereqs.append(f"Python {ver}")
    elif info.primary_language in (Language.JAVASCRIPT, Language.TYPESCRIPT):
        ver = info.node_version or "16+"
        prereqs.append(f"Node.js {ver}")
    elif info.primary_language == Language.GO:
        ver = info.go_version or "1.20+"
        prereqs.append(f"Go {ver}")
    elif info.primary_language == Language.RUST:
        prereqs.append("Rust (latest stable)")
    elif info.primary_language == Language.JAVA:
        prereqs.append("Java 17+")
    elif info.primary_language == Language.RUBY:
        prereqs.append("Ruby 3.0+")

    if Framework.DOCKER in info.frameworks:
        prereqs.append("Docker")

    return prereqs


# ── Usage ────────────────────────────────────────────────────


def _generate_usage(info: ProjectInfo) -> str:
    """Generate usage section."""
    lines = []

    if info.run_command:
        lines.append("```bash")
        lines.append(info.run_command)
        lines.append("```")

    if info.project_type == ProjectType.CLI_TOOL and info.entry_point:
        lines.append("")
        lines.append("### Available Commands\n")
        lines.append("```bash")
        lines.append("# Show help")
        lines.append(f"{info.entry_point} --help")
        lines.append("")
        lines.append("# Show version")
        lines.append(f"{info.entry_point} --version")
        lines.append("```")

    if info.project_type == ProjectType.API_SERVER:
        lines.append("")
        lines.append("### API Endpoints\n")
        lines.append("Once the server is running, you can access:")
        lines.append("")
        lines.append("| Method | Endpoint | Description |")
        lines.append("|--------|----------|-------------|")
        lines.append("| GET | `/` | Health check |")
        lines.append("| GET | `/api/v1/...` | API endpoints |")

    if info.has_docker:
        lines.append("")
        lines.append("### Docker\n")
        lines.append("```bash")
        lines.append(f"docker build -t {info.name or 'app'} .")
        lines.append(f"docker run -p 8000:8000 {info.name or 'app'}")
        lines.append("```")

    if not lines:
        if info.primary_language == Language.PYTHON:
            lines.append("```python")
            lines.append(f"import {info.name.replace('-', '_') if info.name else 'package'}")
            lines.append("")
            lines.append("# Your code here")
            lines.append("```")
        elif info.primary_language in (Language.JAVASCRIPT, Language.TYPESCRIPT):
            ext = "ts" if info.primary_language == Language.TYPESCRIPT else "js"
            lines.append(f"```{ext}")
            lines.append(f'import {{ }} from "{info.name or "package"}";')
            lines.append("")
            lines.append("// Your code here")
            lines.append("```")

    return "\n".join(lines) if lines else ""


# ── Testing ──────────────────────────────────────────────────


def _generate_testing(info: ProjectInfo) -> str:
    """Generate testing section."""
    lines = ["```bash", info.test_command, "```"]
    return "\n".join(lines)


# ── API Reference ────────────────────────────────────────────


def _generate_api_reference(info: ProjectInfo) -> str:
    """Generate API reference section (placeholder)."""
    if info.project_type in (ProjectType.API_SERVER, ProjectType.LIBRARY):
        return "See the [API documentation](docs/) for detailed reference."
    return ""


# ── Project Tree ─────────────────────────────────────────────


def _generate_tree(info: ProjectInfo, config: ReadmeConfig) -> str:
    """Generate project structure tree."""
    tree = build_directory_tree(info.path, config.tree_depth)
    text = tree_to_text(tree)
    if not text:
        return ""

    return f"```\n{text}\n```"


# ── Contributing ─────────────────────────────────────────────


def _generate_contributing(info: ProjectInfo) -> str:
    """Generate contributing section."""
    lines = [
        "Contributions are welcome! Here's how to get started:",
        "",
        "1. Fork the repository",
    ]

    if info.git_url:
        lines.append("2. Create a feature branch (`git checkout -b feature/amazing-feature`)")
    else:
        lines.append("2. Create a feature branch")

    lines.extend([
        "3. Make your changes",
        "4. Commit your changes (`git commit -m 'Add amazing feature'`)",
        "5. Push to the branch (`git push origin feature/amazing-feature`)",
        "6. Open a Pull Request",
    ])

    if info.has_contributing:
        lines.extend([
            "",
            "Please read [CONTRIBUTING.md](CONTRIBUTING.md) for detailed guidelines.",
        ])

    return "\n".join(lines)


# ── License ──────────────────────────────────────────────────


def _generate_license(info: ProjectInfo) -> str:
    """Generate license section."""
    if info.license != LicenseType.UNKNOWN:
        return (
            f"This project is licensed under the **{info.license.value}** License — "
            f"see the [LICENSE](LICENSE) file for details."
        )
    return "See the [LICENSE](LICENSE) file for details."


# ── Acknowledgements ─────────────────────────────────────────


def _generate_acknowledgements(config: ReadmeConfig) -> str:
    """Generate acknowledgements section."""
    lines = []
    for ack in config.acknowledgements:
        lines.append(f"- {ack}")
    return "\n".join(lines)
