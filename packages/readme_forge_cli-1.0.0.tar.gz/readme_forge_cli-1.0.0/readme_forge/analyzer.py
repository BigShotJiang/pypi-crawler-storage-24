"""Project analysis and detection engine."""

from __future__ import annotations

import json
import os
import re
import subprocess
from collections import Counter
from pathlib import Path

from .models import (
    EXTENSION_LANGUAGE_MAP,
    SKIP_DIRS,
    DirectoryEntry,
    FileStats,
    Framework,
    Language,
    LicenseType,
    ProjectInfo,
    ProjectType,
)

# ── Main Analysis ────────────────────────────────────────────


def analyze_project(path: str) -> ProjectInfo:
    """Analyze a project directory and return structured info."""
    project_path = Path(path).resolve()
    if not project_path.is_dir():
        return ProjectInfo(path=path)

    info = ProjectInfo(
        name=project_path.name,
        path=str(project_path),
    )

    # Run all detectors
    _detect_git(info, project_path)
    _detect_languages(info, project_path)
    _detect_frameworks(info, project_path)
    _detect_project_type(info)
    _detect_license(info, project_path)
    _detect_metadata(info, project_path)
    _detect_structure(info, project_path)
    _detect_commands(info, project_path)

    return info


# ── Git Detection ────────────────────────────────────────────


def _detect_git(info: ProjectInfo, path: Path) -> None:
    """Detect git repo information."""
    git_dir = path / ".git"
    if not git_dir.exists():
        return

    info.has_git = True

    try:
        result = subprocess.run(
            ["git", "remote", "get-url", "origin"],
            cwd=str(path), capture_output=True, text=True, timeout=5,
        )
        if result.returncode == 0:
            url = result.stdout.strip()
            # Convert SSH to HTTPS
            if url.startswith("git@"):
                url = url.replace(":", "/").replace("git@", "https://")
            if url.endswith(".git"):
                url = url[:-4]
            info.git_url = url
    except (subprocess.SubprocessError, FileNotFoundError):
        pass

    try:
        result = subprocess.run(
            ["git", "symbolic-ref", "--short", "HEAD"],
            cwd=str(path), capture_output=True, text=True, timeout=5,
        )
        if result.returncode == 0:
            info.git_default_branch = result.stdout.strip()
    except (subprocess.SubprocessError, FileNotFoundError):
        pass


# ── Language Detection ───────────────────────────────────────


def _detect_languages(info: ProjectInfo, path: Path) -> None:
    """Detect programming languages by file extension counts."""
    lang_counts: Counter[Language] = Counter()

    for root, dirs, files in os.walk(str(path)):
        # Skip ignored directories
        dirs[:] = [d for d in dirs if d not in SKIP_DIRS and not d.endswith(".egg-info")]

        for f in files:
            ext = os.path.splitext(f)[1].lower()
            lang = EXTENSION_LANGUAGE_MAP.get(ext)
            if lang:
                lang_counts[lang] += 1

    if lang_counts:
        # Sort by count
        sorted_langs = lang_counts.most_common()
        info.primary_language = sorted_langs[0][0]
        info.languages = [lang for lang, _ in sorted_langs]


# ── Framework Detection ──────────────────────────────────────


# Maps (filename_pattern, content_pattern) -> Framework
FRAMEWORK_SIGNALS: list[tuple[str, str | None, Framework]] = [
    # Python
    ("requirements*.txt", "django", Framework.DJANGO),
    ("requirements*.txt", "flask", Framework.FLASK),
    ("requirements*.txt", "fastapi", Framework.FASTAPI),
    ("requirements*.txt", "celery", Framework.CELERY),
    ("requirements*.txt", "sqlalchemy", Framework.SQLALCHEMY),
    ("requirements*.txt", "pydantic", Framework.PYDANTIC),
    ("requirements*.txt", "click", Framework.CLICK),
    ("requirements*.txt", "typer", Framework.TYPER),
    ("requirements*.txt", "sphinx", Framework.SPHINX),
    ("pyproject.toml", "django", Framework.DJANGO),
    ("pyproject.toml", "flask", Framework.FLASK),
    ("pyproject.toml", "fastapi", Framework.FASTAPI),
    ("pyproject.toml", "click", Framework.CLICK),
    ("pyproject.toml", "typer", Framework.TYPER),
    ("pyproject.toml", "celery", Framework.CELERY),
    ("pyproject.toml", "sqlalchemy", Framework.SQLALCHEMY),
    ("pyproject.toml", "pydantic", Framework.PYDANTIC),
    ("pyproject.toml", "hatchling", Framework.HATCH),
    ("pyproject.toml", "poetry", Framework.POETRY),
    ("pyproject.toml", "setuptools", Framework.SETUPTOOLS),
    ("setup.py", None, Framework.SETUPTOOLS),
    ("conftest.py", None, Framework.PYTEST),
    ("pytest.ini", None, Framework.PYTEST),

    # JavaScript / TypeScript
    ("package.json", "react", Framework.REACT),
    ("package.json", "next", Framework.NEXTJS),
    ("package.json", "vue", Framework.VUE),
    ("package.json", "@angular", Framework.ANGULAR),
    ("package.json", "express", Framework.EXPRESS),
    ("package.json", "@nestjs", Framework.NESTJS),
    ("package.json", "vite", Framework.VITE),
    ("package.json", "webpack", Framework.WEBPACK),
    ("package.json", "jest", Framework.JEST),
    ("package.json", "mocha", Framework.MOCHA),
    ("package.json", "eslint", Framework.ESLINT),
    ("package.json", "prettier", Framework.PRETTIER),
    ("package.json", "tailwindcss", Framework.TAILWIND),
    ("package.json", "storybook", Framework.STORYBOOK),
    ("next.config.js", None, Framework.NEXTJS),
    ("next.config.ts", None, Framework.NEXTJS),
    ("next.config.mjs", None, Framework.NEXTJS),
    ("tailwind.config.js", None, Framework.TAILWIND),
    ("tailwind.config.ts", None, Framework.TAILWIND),
    (".storybook", None, Framework.STORYBOOK),
    (".eslintrc*", None, Framework.ESLINT),
    (".prettierrc*", None, Framework.PRETTIER),

    # Go
    ("go.mod", "github.com/gin-gonic/gin", Framework.GIN),
    ("go.mod", "github.com/labstack/echo", Framework.ECHO),
    ("go.mod", "github.com/gofiber/fiber", Framework.FIBER),
    ("go.mod", "github.com/spf13/cobra", Framework.COBRA),

    # Rust
    ("Cargo.toml", "actix", Framework.ACTIX),
    ("Cargo.toml", "rocket", Framework.ROCKET),
    ("Cargo.toml", "tokio", Framework.TOKIO),
    ("Cargo.toml", "clap", Framework.CLAP),
    ("Cargo.toml", "serde", Framework.SERDE),

    # Java
    ("pom.xml", "spring-boot", Framework.SPRING),
    ("pom.xml", None, Framework.MAVEN),
    ("build.gradle", "spring", Framework.SPRING),
    ("build.gradle", None, Framework.GRADLE),
    ("build.gradle.kts", "spring", Framework.SPRING),
    ("build.gradle.kts", None, Framework.GRADLE),

    # Ruby
    ("Gemfile", "rails", Framework.RAILS),
    ("Gemfile", "sinatra", Framework.SINATRA),
    ("Gemfile", "rspec", Framework.RSPEC),

    # DevOps
    ("Dockerfile", None, Framework.DOCKER),
    ("docker-compose.yml", None, Framework.DOCKER),
    ("docker-compose.yaml", None, Framework.DOCKER),
    (".github/workflows", None, Framework.GITHUB_ACTIONS),
    (".gitlab-ci.yml", None, Framework.GITLAB_CI),
    ("*.tf", None, Framework.TERRAFORM),
    ("main.tf", None, Framework.TERRAFORM),
]


def _detect_frameworks(info: ProjectInfo, path: Path) -> None:
    """Detect frameworks by checking manifest files and config."""
    detected: set[Framework] = set()

    for filename_pattern, content_pattern, framework in FRAMEWORK_SIGNALS:
        # Check if file/dir exists
        matches = list(path.glob(filename_pattern))
        if not matches:
            continue

        if content_pattern is None:
            # Just file existence is enough
            detected.add(framework)
            continue

        # Check file content
        for match in matches:
            if match.is_file():
                try:
                    content = match.read_text(encoding="utf-8", errors="ignore").lower()
                    if content_pattern.lower() in content:
                        detected.add(framework)
                        break
                except OSError:
                    continue

    # Check for Kubernetes
    for yaml_file in path.glob("**/*.yaml"):
        if yaml_file.stat().st_size < 100_000:
            try:
                content = yaml_file.read_text(encoding="utf-8", errors="ignore")
                if "apiVersion:" in content and "kind:" in content:
                    detected.add(Framework.KUBERNETES)
                    break
            except OSError:
                continue

    info.frameworks = sorted(detected, key=lambda f: f.value)


# ── Project Type Detection ───────────────────────────────────


def _detect_project_type(info: ProjectInfo) -> None:
    """Infer the project type from detected frameworks and structure."""
    frameworks = set(info.frameworks)

    # Web frameworks
    web_frameworks = {
        Framework.DJANGO, Framework.FLASK, Framework.FASTAPI,
        Framework.REACT, Framework.NEXTJS, Framework.VUE, Framework.ANGULAR,
        Framework.EXPRESS, Framework.NESTJS, Framework.RAILS, Framework.SINATRA,
        Framework.GIN, Framework.ECHO, Framework.FIBER,
        Framework.ACTIX, Framework.ROCKET, Framework.SPRING,
    }

    api_frameworks = {
        Framework.FASTAPI, Framework.EXPRESS, Framework.NESTJS,
        Framework.GIN, Framework.ECHO, Framework.FIBER,
        Framework.ACTIX, Framework.ROCKET,
    }

    cli_frameworks = {Framework.CLICK, Framework.TYPER, Framework.COBRA, Framework.CLAP}

    frontend_frameworks = {Framework.REACT, Framework.VUE, Framework.ANGULAR, Framework.NEXTJS}

    if frameworks & cli_frameworks:
        info.project_type = ProjectType.CLI_TOOL
    elif frameworks & api_frameworks and not (frameworks & frontend_frameworks):
        info.project_type = ProjectType.API_SERVER
    elif frameworks & frontend_frameworks:
        info.project_type = ProjectType.WEB_APP
    elif frameworks & web_frameworks:
        info.project_type = ProjectType.WEB_APP
    elif Framework.TERRAFORM in frameworks or Framework.KUBERNETES in frameworks:
        info.project_type = ProjectType.CONFIGURATION
    elif info.primary_language != Language.UNKNOWN:
        info.project_type = ProjectType.LIBRARY
    else:
        info.project_type = ProjectType.UNKNOWN


# ── License Detection ────────────────────────────────────────


LICENSE_PATTERNS: list[tuple[str, LicenseType]] = [
    ("MIT License", LicenseType.MIT),
    ("Permission is hereby granted, free of charge", LicenseType.MIT),
    ("Apache License, Version 2.0", LicenseType.APACHE2),
    ("Apache License\n.*Version 2.0", LicenseType.APACHE2),
    ("GNU GENERAL PUBLIC LICENSE.*Version 3", LicenseType.GPL3),
    ("GNU GENERAL PUBLIC LICENSE.*Version 2", LicenseType.GPL2),
    ("GNU LESSER GENERAL PUBLIC LICENSE", LicenseType.LGPL3),
    ("GNU AFFERO GENERAL PUBLIC LICENSE", LicenseType.AGPL3),
    ("BSD 2-Clause", LicenseType.BSD2),
    ("BSD 3-Clause", LicenseType.BSD3),
    ("Redistribution and use in source and binary forms", LicenseType.BSD3),
    ("ISC License", LicenseType.ISC),
    ("The Unlicense", LicenseType.UNLICENSE),
    ("Mozilla Public License.*2.0", LicenseType.MPL2),
]


def _detect_license(info: ProjectInfo, path: Path) -> None:
    """Detect the project license."""
    license_files = ["LICENSE", "LICENSE.md", "LICENSE.txt", "LICENCE", "COPYING"]

    for lf in license_files:
        fp = path / lf
        if fp.is_file():
            try:
                content = fp.read_text(encoding="utf-8", errors="ignore")
                info.license_text = content

                for pattern, license_type in LICENSE_PATTERNS:
                    if re.search(pattern, content, re.IGNORECASE | re.DOTALL):
                        info.license = license_type
                        return
            except OSError:
                continue

    # Check pyproject.toml
    pyproject = path / "pyproject.toml"
    if pyproject.is_file():
        try:
            content = pyproject.read_text(encoding="utf-8", errors="ignore")
            match = re.search(r'license\s*=\s*\{?\s*text\s*=\s*["\']([^"\']+)', content)
            if match:
                license_str = match.group(1).upper()
                for lt in LicenseType:
                    if lt.value.upper() in license_str or license_str in lt.value.upper():
                        info.license = lt
                        return
        except OSError:
            pass

    # Check package.json
    pkg_json = path / "package.json"
    if pkg_json.is_file():
        try:
            data = json.loads(pkg_json.read_text(encoding="utf-8"))
            license_str = data.get("license", "")
            if license_str:
                for lt in LicenseType:
                    if lt.value.upper() == license_str.upper():
                        info.license = lt
                        return
        except (OSError, json.JSONDecodeError):
            pass


# ── Metadata Detection ───────────────────────────────────────


def _detect_metadata(info: ProjectInfo, path: Path) -> None:
    """Extract project metadata from manifest files."""
    _detect_python_metadata(info, path)
    _detect_node_metadata(info, path)
    _detect_go_metadata(info, path)
    _detect_rust_metadata(info, path)


def _detect_python_metadata(info: ProjectInfo, path: Path) -> None:
    """Extract metadata from pyproject.toml or setup.py."""
    pyproject = path / "pyproject.toml"
    if pyproject.is_file():
        try:
            content = pyproject.read_text(encoding="utf-8", errors="ignore")
            _extract_toml_field(info, content, "name", "name", override=True)
            _extract_toml_field(info, content, "version", "version")
            _extract_toml_field(info, content, "description", "description")
            _extract_toml_field(info, content, "requires-python", "python_version")

            # Author
            author_match = re.search(
                r'authors\s*=\s*\[\s*\{[^}]*name\s*=\s*["\']([^"\']+)', content
            )
            if author_match:
                info.author = author_match.group(1)

            email_match = re.search(
                r'authors\s*=\s*\[\s*\{[^}]*email\s*=\s*["\']([^"\']+)', content
            )
            if email_match:
                info.author_email = email_match.group(1)

            # Homepage
            homepage_match = re.search(r'Homepage\s*=\s*["\']([^"\']+)', content)
            if homepage_match:
                info.homepage = homepage_match.group(1)

            # Keywords
            kw_match = re.search(r'keywords\s*=\s*\[(.*?)\]', content, re.DOTALL)
            if kw_match:
                kw_text = kw_match.group(1)
                info.keywords = re.findall(r'["\']([^"\']+)["\']', kw_text)

            # Entry point
            ep_match = re.search(r'\[project\.scripts\]\s*(\w[\w-]*)\s*=', content)
            if ep_match:
                info.entry_point = ep_match.group(1)
        except OSError:
            pass


def _extract_toml_field(
    info: ProjectInfo, content: str, field: str, attr: str, override: bool = False,
) -> None:
    """Extract a simple TOML field value."""
    match = re.search(rf'{field}\s*=\s*["\']([^"\']+)["\']', content)
    if match and (override or not getattr(info, attr)):
        setattr(info, attr, match.group(1))


def _detect_node_metadata(info: ProjectInfo, path: Path) -> None:
    """Extract metadata from package.json."""
    pkg_json = path / "package.json"
    if not pkg_json.is_file():
        return

    try:
        data = json.loads(pkg_json.read_text(encoding="utf-8"))
        pkg_name = data.get("name", "")
        if pkg_name:
            info.name = pkg_name
        if not info.version:
            info.version = data.get("version", "")
        if not info.description:
            info.description = data.get("description", "")
        if not info.author:
            author = data.get("author", "")
            if isinstance(author, dict):
                info.author = author.get("name", "")
                info.author_email = author.get("email", "")
            elif isinstance(author, str):
                info.author = author
        if not info.homepage:
            info.homepage = data.get("homepage", "")
        if not info.keywords:
            info.keywords = data.get("keywords", [])

        # Node engine
        engines = data.get("engines", {})
        if "node" in engines:
            info.node_version = engines["node"]

        # Entry point
        if not info.entry_point:
            main = data.get("main", "")
            if main:
                info.entry_point = main
    except (OSError, json.JSONDecodeError):
        pass


def _detect_go_metadata(info: ProjectInfo, path: Path) -> None:
    """Extract metadata from go.mod."""
    go_mod = path / "go.mod"
    if not go_mod.is_file():
        return

    try:
        content = go_mod.read_text(encoding="utf-8", errors="ignore")
        module_match = re.search(r'^module\s+(\S+)', content, re.MULTILINE)
        if module_match and not info.name:
            module_path = module_match.group(1)
            info.name = module_path.split("/")[-1]

        go_match = re.search(r'^go\s+(\S+)', content, re.MULTILINE)
        if go_match:
            info.go_version = go_match.group(1)
    except OSError:
        pass


def _detect_rust_metadata(info: ProjectInfo, path: Path) -> None:
    """Extract metadata from Cargo.toml."""
    cargo = path / "Cargo.toml"
    if not cargo.is_file():
        return

    try:
        content = cargo.read_text(encoding="utf-8", errors="ignore")
        _extract_toml_field(info, content, "name", "name", override=True)
        _extract_toml_field(info, content, "version", "version")
        _extract_toml_field(info, content, "description", "description")

        edition_match = re.search(r'edition\s*=\s*["\'](\d{4})["\']', content)
        if edition_match:
            info.rust_edition = edition_match.group(1)

        authors_match = re.search(r'authors\s*=\s*\[\s*["\']([^"\']+)', content)
        if authors_match and not info.author:
            info.author = authors_match.group(1)
    except OSError:
        pass


# ── Structure Detection ──────────────────────────────────────


def _detect_structure(info: ProjectInfo, path: Path) -> None:
    """Detect project structure features."""
    info.has_tests = any(
        (path / d).exists()
        for d in ("tests", "test", "spec", "specs", "__tests__", "test_")
    )

    info.has_docs = any(
        (path / d).exists()
        for d in ("docs", "doc", "documentation", "wiki")
    )

    info.has_ci = (
        (path / ".github" / "workflows").exists()
        or (path / ".gitlab-ci.yml").exists()
        or (path / ".circleci").exists()
        or (path / "Jenkinsfile").exists()
        or (path / ".travis.yml").exists()
        or (path / "azure-pipelines.yml").exists()
    )

    info.has_docker = (
        (path / "Dockerfile").exists()
        or (path / "docker-compose.yml").exists()
        or (path / "docker-compose.yaml").exists()
    )

    info.has_contributing = any(
        (path / f).exists()
        for f in ("CONTRIBUTING.md", "CONTRIBUTING.rst", "CONTRIBUTING", "CONTRIBUTING.txt")
    )

    info.has_changelog = any(
        (path / f).exists()
        for f in ("CHANGELOG.md", "CHANGELOG.rst", "CHANGELOG", "CHANGES.md", "HISTORY.md")
    )

    info.has_examples = any(
        (path / d).exists()
        for d in ("examples", "example", "demos", "demo", "samples")
    )


# ── Command Detection ────────────────────────────────────────


def _detect_commands(info: ProjectInfo, path: Path) -> None:
    """Detect install, test, build, and run commands."""
    lang = info.primary_language

    if lang == Language.PYTHON:
        if (path / "pyproject.toml").exists():
            info.install_command = 'pip install -e ".[dev]"'
        elif (path / "requirements.txt").exists():
            info.install_command = "pip install -r requirements.txt"
        elif (path / "setup.py").exists():
            info.install_command = "pip install -e ."

        if info.has_tests:
            info.test_command = "pytest tests/ -v"

        if info.entry_point:
            info.run_command = info.entry_point
        elif (path / "manage.py").exists():
            info.run_command = "python manage.py runserver"
        elif (path / "app.py").exists():
            info.run_command = "python app.py"
        elif (path / "main.py").exists():
            info.run_command = "python main.py"

        info.build_command = "python -m build"

    elif lang in (Language.JAVASCRIPT, Language.TYPESCRIPT):
        info.install_command = "npm install"
        if (path / "yarn.lock").exists():
            info.install_command = "yarn install"
        elif (path / "pnpm-lock.yaml").exists():
            info.install_command = "pnpm install"

        info.test_command = "npm test"
        info.build_command = "npm run build"
        info.run_command = "npm start"

    elif lang == Language.GO:
        info.install_command = "go mod download"
        info.test_command = "go test ./..."
        info.build_command = "go build ./..."
        info.run_command = "go run ."

    elif lang == Language.RUST:
        info.install_command = "cargo build"
        info.test_command = "cargo test"
        info.build_command = "cargo build --release"
        info.run_command = "cargo run"

    elif lang == Language.JAVA:
        if Framework.MAVEN in info.frameworks:
            info.install_command = "mvn install"
            info.test_command = "mvn test"
            info.build_command = "mvn package"
            info.run_command = "mvn spring-boot:run"
        elif Framework.GRADLE in info.frameworks:
            info.install_command = "./gradlew build"
            info.test_command = "./gradlew test"
            info.build_command = "./gradlew assemble"
            info.run_command = "./gradlew bootRun"

    elif lang == Language.RUBY:
        info.install_command = "bundle install"
        info.test_command = (
            "bundle exec rspec"
            if Framework.RSPEC in info.frameworks
            else "rake test"
        )
        if Framework.RAILS in info.frameworks:
            info.run_command = "rails server"


# ── File Statistics ──────────────────────────────────────────


def get_file_stats(path: str) -> FileStats:
    """Gather file statistics for a project."""
    project_path = Path(path).resolve()
    stats = FileStats()
    file_sizes: list[tuple[str, int]] = []

    for root, dirs, files in os.walk(str(project_path)):
        dirs[:] = [d for d in dirs if d not in SKIP_DIRS and not d.endswith(".egg-info")]
        stats.total_dirs += len(dirs)

        for f in files:
            if f.startswith(".") and f in SKIP_DIRS:
                continue

            fp = os.path.join(root, f)
            stats.total_files += 1

            ext = os.path.splitext(f)[1].lower() or f
            stats.file_types[ext] = stats.file_types.get(ext, 0) + 1

            try:
                size = os.path.getsize(fp)
                rel = os.path.relpath(fp, str(project_path))
                file_sizes.append((rel, size))

                # Count lines for text files
                if size < 500_000 and ext in EXTENSION_LANGUAGE_MAP:
                    with open(fp, "r", encoding="utf-8", errors="ignore") as fh:
                        stats.total_lines += sum(1 for _ in fh)
            except OSError:
                continue

    file_sizes.sort(key=lambda x: x[1], reverse=True)
    stats.largest_files = file_sizes[:10]

    return stats


# ── Directory Tree ───────────────────────────────────────────


def build_directory_tree(path: str, max_depth: int = 3) -> DirectoryEntry:
    """Build a directory tree structure."""
    project_path = Path(path).resolve()
    root = DirectoryEntry(name=project_path.name, is_dir=True, depth=0)
    _build_tree_recursive(project_path, root, max_depth, 0)
    return root


def _build_tree_recursive(path: Path, node: DirectoryEntry, max_depth: int, depth: int) -> None:
    """Recursively build directory tree."""
    if depth >= max_depth:
        return

    try:
        entries = sorted(path.iterdir(), key=lambda e: (not e.is_dir(), e.name.lower()))
    except PermissionError:
        return

    for entry in entries:
        name = entry.name

        # Skip hidden and ignored
        if name.startswith(".") and name not in (".github", ".env.example"):
            continue
        if name in SKIP_DIRS or name.endswith(".egg-info"):
            continue

        child = DirectoryEntry(name=name, is_dir=entry.is_dir(), depth=depth + 1)
        node.children.append(child)

        if entry.is_dir():
            _build_tree_recursive(entry, child, max_depth, depth + 1)


def tree_to_text(node: DirectoryEntry, prefix: str = "", is_last: bool = True) -> str:
    """Render a directory tree as text."""
    lines: list[str] = []

    if node.depth == 0:
        lines.append(f"{node.name}/")
    else:
        connector = "└── " if is_last else "├── "
        suffix = "/" if node.is_dir else ""
        lines.append(f"{prefix}{connector}{node.name}{suffix}")

    if node.children:
        for i, child in enumerate(node.children):
            is_child_last = (i == len(node.children) - 1)
            if node.depth == 0:
                child_prefix = ""
            else:
                child_prefix = prefix + ("    " if is_last else "│   ")
            lines.append(tree_to_text(child, child_prefix, is_child_last))

    return "\n".join(lines)
