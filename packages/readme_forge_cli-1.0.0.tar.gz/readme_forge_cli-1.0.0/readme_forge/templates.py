"""Jinja2 template support for custom README templates."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from jinja2 import BaseLoader, Environment, FileSystemLoader

from .models import ProjectInfo, ReadmeConfig

# ── Built-in Templates ───────────────────────────────────────

MINIMAL_TEMPLATE = """\
# {{ info.name }}

{{ info.description or "A " + info.project_type.value|lower + " project." }}

## Installation

```bash
{{ info.install_command or "# Install instructions here" }}
```

## Usage

```bash
{{ info.run_command or "# Usage instructions here" }}
```

## License

{{ info.license.value if info.license.value != "Unknown" else "See LICENSE file." }}
"""

DETAILED_TEMPLATE = """\
# {{ info.name }}

{{ badges }}

{{ info.description or "" }}

---

## Table of Contents

{% for section in sections %}
- [{{ section }}](#{{ section|lower|replace(" ", "-") }})
{% endfor %}

{% for section, content in section_contents.items() %}
---

## {{ section }}

{{ content }}

{% endfor %}

---

{% if info.author %}
<p align="center">Made with ❤️ by {{ info.author }}</p>
{% endif %}
"""

BUILTIN_TEMPLATES = {
    "minimal": MINIMAL_TEMPLATE,
    "detailed": DETAILED_TEMPLATE,
}


def render_template(
    template_name: str,
    info: ProjectInfo,
    config: ReadmeConfig,
    extra_context: dict[str, Any] | None = None,
) -> str:
    """Render a README from a named template."""
    if template_name in BUILTIN_TEMPLATES:
        template_str = BUILTIN_TEMPLATES[template_name]
        env = Environment(loader=BaseLoader())
        template = env.from_string(template_str)
    else:
        # Load from file
        template_path = Path(template_name)
        if not template_path.is_file():
            raise FileNotFoundError(f"Template not found: {template_name}")

        env = Environment(loader=FileSystemLoader(str(template_path.parent)))
        template = env.get_template(template_path.name)

    context = {
        "info": info,
        "config": config,
    }

    if extra_context:
        context.update(extra_context)

    return template.render(**context)


def list_templates() -> list[dict[str, str]]:
    """List available built-in templates."""
    return [
        {"name": "minimal", "description": "Clean, minimal README with essentials only"},
        {"name": "detailed", "description": "Comprehensive README with all sections"},
    ]
