"""Badge generation for README files."""

from __future__ import annotations

from urllib.parse import quote

from .models import (
    LANGUAGE_COLORS,
    Framework,
    Language,
    LicenseType,
    ProjectInfo,
)


def generate_badges(info: ProjectInfo, style: str = "flat") -> list[str]:
    """Generate shields.io badge markdown strings."""
    badges: list[str] = []

    # Language badge
    if info.primary_language != Language.UNKNOWN:
        color = LANGUAGE_COLORS.get(info.primary_language, "555555")
        lang = info.primary_language.value
        badges.append(
            f"![{lang}](https://img.shields.io/badge/{quote(lang)}-{color}?style={style}"
            f"&logo={_lang_logo(info.primary_language)}&logoColor=white)"
        )

    # Version badge
    if info.version:
        badges.append(
            f"![Version](https://img.shields.io/badge/version-{quote(info.version)}-blue"
            f"?style={style})"
        )

    # License badge
    if info.license != LicenseType.UNKNOWN:
        badges.append(
            f"![License](https://img.shields.io/badge/license-{quote(info.license.value)}"
            f"-green?style={style})"
        )

    # PyPI badge
    if info.entry_point and info.primary_language == Language.PYTHON and info.name:
        badges.append(
            f"![PyPI](https://img.shields.io/pypi/v/{quote(info.name)}?style={style})"
        )

    # npm badge
    if info.primary_language in (Language.JAVASCRIPT, Language.TYPESCRIPT) and info.name:
        badges.append(
            f"![npm](https://img.shields.io/npm/v/{quote(info.name)}?style={style})"
        )

    # Build status (GitHub Actions)
    if info.has_ci and info.git_url and "github.com" in info.git_url:
        owner_repo = _extract_owner_repo(info.git_url)
        if owner_repo:
            badges.append(
                f"![Build](https://img.shields.io/github/actions/workflow/status/"
                f"{owner_repo}/ci.yml?style={style})"
            )

    # Framework badges
    for fw in info.frameworks[:5]:  # Limit to 5
        logo = _framework_logo(fw)
        if logo:
            badges.append(
                f"![{fw.value}](https://img.shields.io/badge/{quote(fw.value)}-555555"
                f"?style={style}&logo={logo}&logoColor=white)"
            )

    return badges


def generate_badge_line(info: ProjectInfo, style: str = "flat") -> str:
    """Generate a single line of badges."""
    badges = generate_badges(info, style)
    if not badges:
        return ""
    return " ".join(badges)


def _extract_owner_repo(git_url: str) -> str:
    """Extract owner/repo from a GitHub URL."""
    # https://github.com/owner/repo
    if "github.com" in git_url:
        parts = git_url.rstrip("/").split("github.com/")
        if len(parts) == 2:
            return parts[1].replace(".git", "")
    return ""


def _lang_logo(lang: Language) -> str:
    """Get shields.io logo for a language."""
    logos = {
        Language.PYTHON: "python",
        Language.JAVASCRIPT: "javascript",
        Language.TYPESCRIPT: "typescript",
        Language.GO: "go",
        Language.RUST: "rust",
        Language.JAVA: "openjdk",
        Language.CSHARP: "csharp",
        Language.CPP: "cplusplus",
        Language.C: "c",
        Language.RUBY: "ruby",
        Language.PHP: "php",
        Language.SWIFT: "swift",
        Language.KOTLIN: "kotlin",
        Language.DART: "dart",
        Language.SHELL: "gnubash",
        Language.SCALA: "scala",
        Language.ELIXIR: "elixir",
        Language.HASKELL: "haskell",
    }
    return logos.get(lang, "")


def _framework_logo(fw: Framework) -> str:
    """Get shields.io logo for a framework."""
    logos = {
        Framework.DJANGO: "django",
        Framework.FLASK: "flask",
        Framework.FASTAPI: "fastapi",
        Framework.REACT: "react",
        Framework.NEXTJS: "nextdotjs",
        Framework.VUE: "vuedotjs",
        Framework.ANGULAR: "angular",
        Framework.EXPRESS: "express",
        Framework.NESTJS: "nestjs",
        Framework.DOCKER: "docker",
        Framework.KUBERNETES: "kubernetes",
        Framework.TERRAFORM: "terraform",
        Framework.GITHUB_ACTIONS: "githubactions",
        Framework.TAILWIND: "tailwindcss",
        Framework.VITE: "vite",
        Framework.WEBPACK: "webpack",
        Framework.JEST: "jest",
        Framework.ESLINT: "eslint",
        Framework.PRETTIER: "prettier",
        Framework.SPRING: "springboot",
        Framework.RAILS: "rubyonrails",
        Framework.PYTEST: "pytest",
        Framework.CELERY: "celery",
        Framework.STORYBOOK: "storybook",
        Framework.GIN: "go",
        Framework.COBRA: "go",
        Framework.ACTIX: "rust",
        Framework.ROCKET: "rust",
        Framework.TOKIO: "rust",
        Framework.CLAP: "rust",
        Framework.SERDE: "rust",
        Framework.POETRY: "poetry",
    }
    return logos.get(fw, "")
