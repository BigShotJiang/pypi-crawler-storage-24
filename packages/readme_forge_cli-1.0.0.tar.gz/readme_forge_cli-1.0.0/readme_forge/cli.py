"""CLI commands for readme-forge."""

from __future__ import annotations

import sys
from pathlib import Path

import click
from rich.console import Console

from . import __version__
from .analyzer import analyze_project, build_directory_tree, get_file_stats, tree_to_text
from .generator import generate_readme
from .models import ReadmeConfig
from .output import (
    render_file_stats,
    render_generation_summary,
    render_project_info,
    render_readme_preview,
)
from .templates import list_templates, render_template

console = Console()


@click.group()
@click.version_option(version=__version__, prog_name="readme-forge")
def cli():
    """readme-forge — Intelligent README.md generator.

    Analyze your project structure, detect tech stacks, and generate
    professional documentation automatically.
    """
    pass


@cli.command()
@click.argument("path", default=".", type=click.Path(exists=True))
@click.option("-o", "--output", default="README.md", help="Output file path")
@click.option("--style", type=click.Choice(["banner", "simple", "minimal"]), default="banner",
              help="Header style")
@click.option(
    "--badge-style",
    type=click.Choice(["flat", "flat-square", "for-the-badge", "plastic"]),
    default="flat",
    help="Badge style",
)
@click.option("--no-badges", is_flag=True, help="Skip badges")
@click.option("--no-toc", is_flag=True, help="Skip table of contents")
@click.option("--no-features", is_flag=True, help="Skip features section")
@click.option("--no-install", is_flag=True, help="Skip installation section")
@click.option("--no-usage", is_flag=True, help="Skip usage section")
@click.option("--no-contributing", is_flag=True, help="Skip contributing section")
@click.option("--no-license", is_flag=True, help="Skip license section")
@click.option("--tree", "include_tree", is_flag=True, help="Include project structure tree")
@click.option("--tree-depth", type=int, default=3, help="Tree depth (default: 3)")
@click.option("--api", "include_api", is_flag=True, help="Include API reference section")
@click.option("--emoji/--no-emoji", default=True, help="Use emoji in headers")
@click.option("--preview", is_flag=True, help="Preview without writing file")
@click.option("--force", "-f", is_flag=True, help="Overwrite existing README")
@click.option("--quiet", "-q", is_flag=True, help="Minimal output")
def generate(
    path, output, style, badge_style, no_badges, no_toc, no_features,
    no_install, no_usage, no_contributing, no_license, include_tree,
    tree_depth, include_api, emoji, preview, force, quiet,
):
    """Generate a README.md for your project.

    Analyzes the project at PATH (default: current directory) and generates
    a comprehensive README.md file.
    """
    # Analyze project
    if not quiet:
        console.print(f"\n🔍 Analyzing project at [bold]{path}[/bold]...\n")

    info = analyze_project(path)

    if not quiet:
        render_project_info(info)
        console.print()

    # Build config
    config = ReadmeConfig(
        include_badges=not no_badges,
        include_toc=not no_toc,
        include_features=not no_features,
        include_installation=not no_install,
        include_usage=not no_usage,
        include_contributing=not no_contributing,
        include_license=not no_license,
        include_tree=include_tree,
        include_api=include_api,
        emoji_headers=emoji,
        header_style=style,
        badge_style=badge_style,
        tree_depth=tree_depth,
    )

    # Generate README
    readme_content = generate_readme(info, config)

    if preview:
        render_readme_preview(readme_content)
        return

    # Resolve output path
    output_path = Path(path) / output if not Path(output).is_absolute() else Path(output)

    if output_path.exists() and not force:
        if not click.confirm(f"\n⚠️  {output_path} already exists. Overwrite?"):
            console.print("[yellow]Cancelled.[/yellow]")
            return

    output_path.write_text(readme_content, encoding="utf-8")

    if not quiet:
        console.print()
        render_generation_summary(info, config, str(output_path))
    else:
        console.print(f"✅ Generated {output_path}")


@cli.command()
@click.argument("path", default=".", type=click.Path(exists=True))
def analyze(path):
    """Analyze a project and display detected information.

    Shows detected language, frameworks, project type, license,
    and other metadata without generating a README.
    """
    console.print(f"\n🔍 Analyzing project at [bold]{path}[/bold]...\n")
    info = analyze_project(path)
    render_project_info(info)

    stats = get_file_stats(path)
    console.print()
    render_file_stats(stats)
    console.print()


@cli.command()
@click.argument("path", default=".", type=click.Path(exists=True))
@click.option("--depth", type=int, default=3, help="Maximum depth")
def tree(path, depth):
    """Display the project directory tree.

    Shows a visual tree of the project structure, excluding
    common ignored directories like node_modules, .git, etc.
    """
    tree_root = build_directory_tree(path, max_depth=depth)
    text = tree_to_text(tree_root)
    console.print(f"\n{text}\n")


@cli.command()
@click.argument("path", default=".", type=click.Path(exists=True))
def stats(path):
    """Show project file statistics.

    Displays total files, directories, lines of code,
    and file type distribution.
    """
    console.print(f"\n📊 Gathering stats for [bold]{path}[/bold]...\n")
    file_stats = get_file_stats(path)
    render_file_stats(file_stats)
    console.print()


@cli.command("templates")
def list_tmpl():
    """List available README templates."""
    templates = list_templates()
    console.print("\n📄 Available Templates:\n")
    for t in templates:
        console.print(f"  [bold cyan]{t['name']}[/bold cyan] — {t['description']}")
    console.print()


@cli.command()
@click.argument("path", default=".", type=click.Path(exists=True))
@click.option("-t", "--template", "template_name", required=True, help="Template name or file path")
@click.option("-o", "--output", default="README.md", help="Output file path")
@click.option("--force", "-f", is_flag=True, help="Overwrite existing file")
def from_template(path, template_name, output, force):
    """Generate README from a template.

    Use a built-in template name (minimal, detailed) or provide
    a path to a custom Jinja2 template file.
    """
    console.print(f"\n🔍 Analyzing project at [bold]{path}[/bold]...\n")
    info = analyze_project(path)

    try:
        content = render_template(template_name, info, ReadmeConfig())
    except FileNotFoundError as e:
        console.print(f"[red]Error: {e}[/red]")
        sys.exit(1)

    output_path = Path(path) / output if not Path(output).is_absolute() else Path(output)

    if output_path.exists() and not force:
        if not click.confirm(f"\n⚠️  {output_path} already exists. Overwrite?"):
            console.print("[yellow]Cancelled.[/yellow]")
            return

    output_path.write_text(content, encoding="utf-8")
    console.print(f"✅ Generated {output_path} from template [bold]{template_name}[/bold]")


@cli.command()
@click.argument("path", default=".", type=click.Path(exists=True))
@click.option("--format", "fmt", type=click.Choice(["text", "json"]), default="text",
              help="Output format")
def detect(path, fmt):
    """Detect project language, frameworks, and type.

    Quick detection without full analysis — useful for scripting
    and CI/CD integration.
    """
    info = analyze_project(path)

    if fmt == "json":
        import json
        data = {
            "name": info.name,
            "language": info.primary_language.value,
            "languages": [lang.value for lang in info.languages],
            "frameworks": [fw.value for fw in info.frameworks],
            "project_type": info.project_type.value,
            "license": info.license.value,
            "version": info.version,
        }
        console.print(json.dumps(data, indent=2))
    else:
        console.print(f"\n  [bold]Name:[/bold]       {info.name}")
        console.print(f"  [bold]Language:[/bold]   {info.primary_language.value}")
        if info.languages:
            langs = ", ".join(lang.value for lang in info.languages)
            console.print(f"  [bold]Languages:[/bold]  {langs}")
        if info.frameworks:
            fws = ", ".join(f.value for f in info.frameworks)
            console.print(f"  [bold]Frameworks:[/bold] {fws}")
        console.print(f"  [bold]Type:[/bold]       {info.project_type.value}")
        console.print(f"  [bold]License:[/bold]    {info.license.value}")
        console.print()
