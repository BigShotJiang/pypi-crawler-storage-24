"""readme-forge-cli — Intelligent README.md generator."""

__version__ = "1.0.0"
