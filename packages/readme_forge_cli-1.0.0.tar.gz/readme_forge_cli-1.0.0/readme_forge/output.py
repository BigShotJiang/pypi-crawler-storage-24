"""Rich terminal output for readme-forge."""

from __future__ import annotations

from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from .models import (
    FileStats,
    ProjectInfo,
    ReadmeConfig,
)

console = Console()


def render_project_info(info: ProjectInfo) -> None:
    """Display project analysis summary."""
    table = Table(show_header=False, box=None, padding=(0, 2))
    table.add_column("Field", style="bold cyan", width=18)
    table.add_column("Value")

    table.add_row("Name", info.name or "Unknown")
    table.add_row("Description", info.description or "—")
    table.add_row("Version", info.version or "—")
    table.add_row("Type", info.project_type.value)
    table.add_row("Language", info.primary_language.value)

    if info.languages:
        all_langs = ", ".join(lang.value for lang in info.languages[:6])
        table.add_row("All Languages", all_langs)

    if info.frameworks:
        fw_str = ", ".join(f.value for f in info.frameworks[:8])
        table.add_row("Frameworks", fw_str)

    table.add_row("License", info.license.value)

    if info.author:
        table.add_row("Author", info.author)

    if info.git_url:
        table.add_row("Repository", info.git_url)

    # Structure flags
    flags = []
    if info.has_tests:
        flags.append("✅ Tests")
    if info.has_docs:
        flags.append("✅ Docs")
    if info.has_ci:
        flags.append("✅ CI/CD")
    if info.has_docker:
        flags.append("✅ Docker")
    if info.has_contributing:
        flags.append("✅ Contributing")
    if info.has_changelog:
        flags.append("✅ Changelog")
    if flags:
        table.add_row("Structure", "  ".join(flags))

    # Commands
    if info.install_command:
        table.add_row("Install", info.install_command)
    if info.test_command:
        table.add_row("Test", info.test_command)
    if info.run_command:
        table.add_row("Run", info.run_command)

    panel = Panel(table, title="📋 Project Analysis", border_style="blue")
    console.print(panel)


def render_file_stats(stats: FileStats) -> None:
    """Display file statistics."""
    table = Table(title="📊 File Statistics", show_header=False, box=None, padding=(0, 2))
    table.add_column("Metric", style="bold cyan", width=18)
    table.add_column("Value")

    table.add_row("Total Files", str(stats.total_files))
    table.add_row("Total Dirs", str(stats.total_dirs))
    table.add_row("Total Lines", f"{stats.total_lines:,}")

    if stats.file_types:
        # Top 8 file types
        sorted_types = sorted(stats.file_types.items(), key=lambda x: x[1], reverse=True)[:8]
        types_str = ", ".join(f"{ext} ({count})" for ext, count in sorted_types)
        table.add_row("File Types", types_str)

    console.print(table)


def render_readme_preview(content: str, max_lines: int = 40) -> None:
    """Preview generated README content."""
    lines = content.split("\n")
    preview = "\n".join(lines[:max_lines])

    if len(lines) > max_lines:
        preview += f"\n\n... ({len(lines) - max_lines} more lines)"

    panel = Panel(
        preview,
        title="📝 README Preview",
        border_style="green",
        subtitle=f"{len(lines)} lines total",
    )
    console.print(panel)


def render_generation_summary(info: ProjectInfo, config: ReadmeConfig, output_path: str) -> None:
    """Show generation summary."""
    sections_included = []
    if config.include_badges:
        sections_included.append("Badges")
    if config.include_toc:
        sections_included.append("Table of Contents")
    if config.include_features:
        sections_included.append("Features")
    if config.include_tech_stack and info.frameworks:
        sections_included.append("Tech Stack")
    if config.include_installation and info.install_command:
        sections_included.append("Installation")
    if config.include_usage:
        sections_included.append("Usage")
    if info.test_command:
        sections_included.append("Testing")
    if config.include_tree:
        sections_included.append("Project Structure")
    if config.include_contributing:
        sections_included.append("Contributing")
    if config.include_license:
        sections_included.append("License")

    table = Table(show_header=False, box=None, padding=(0, 2))
    table.add_column("Field", style="bold cyan", width=18)
    table.add_column("Value")

    table.add_row("Output", output_path)
    table.add_row("Sections", str(len(sections_included)))
    table.add_row("Included", ", ".join(sections_included[:6]))
    if len(sections_included) > 6:
        table.add_row("", ", ".join(sections_included[6:]))
    table.add_row("Badge Style", config.badge_style)
    table.add_row("Header Style", config.header_style)

    panel = Panel(table, title="✅ README Generated", border_style="green")
    console.print(panel)
