"""Data models for readme-forge."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum


class Language(Enum):
    """Programming language."""

    PYTHON = "Python"
    JAVASCRIPT = "JavaScript"
    TYPESCRIPT = "TypeScript"
    GO = "Go"
    RUST = "Rust"
    JAVA = "Java"
    CSHARP = "C#"
    CPP = "C++"
    C = "C"
    RUBY = "Ruby"
    PHP = "PHP"
    SWIFT = "Swift"
    KOTLIN = "Kotlin"
    DART = "Dart"
    SHELL = "Shell"
    LUA = "Lua"
    R = "R"
    SCALA = "Scala"
    ELIXIR = "Elixir"
    HASKELL = "Haskell"
    UNKNOWN = "Unknown"


class Framework(Enum):
    """Detected framework."""

    # Python
    DJANGO = "Django"
    FLASK = "Flask"
    FASTAPI = "FastAPI"
    PYTEST = "pytest"
    CLICK = "Click"
    TYPER = "Typer"
    SETUPTOOLS = "setuptools"
    POETRY = "Poetry"
    HATCH = "Hatch"
    SPHINX = "Sphinx"
    CELERY = "Celery"
    SQLALCHEMY = "SQLAlchemy"
    PYDANTIC = "Pydantic"

    # JavaScript / TypeScript
    REACT = "React"
    NEXTJS = "Next.js"
    VUE = "Vue.js"
    ANGULAR = "Angular"
    EXPRESS = "Express"
    NESTJS = "NestJS"
    VITE = "Vite"
    WEBPACK = "Webpack"
    JEST = "Jest"
    MOCHA = "Mocha"
    ESLINT = "ESLint"
    PRETTIER = "Prettier"
    TAILWIND = "Tailwind CSS"
    STORYBOOK = "Storybook"

    # Go
    GIN = "Gin"
    ECHO = "Echo"
    FIBER = "Fiber"
    COBRA = "Cobra"

    # Rust
    ACTIX = "Actix"
    ROCKET = "Rocket"
    TOKIO = "Tokio"
    CLAP = "clap"
    SERDE = "serde"

    # Java
    SPRING = "Spring Boot"
    MAVEN = "Maven"
    GRADLE = "Gradle"

    # Ruby
    RAILS = "Ruby on Rails"
    SINATRA = "Sinatra"
    RSPEC = "RSpec"

    # DevOps / Infra
    DOCKER = "Docker"
    KUBERNETES = "Kubernetes"
    TERRAFORM = "Terraform"
    GITHUB_ACTIONS = "GitHub Actions"
    GITLAB_CI = "GitLab CI"


class ProjectType(Enum):
    """Type of project."""

    LIBRARY = "Library"
    CLI_TOOL = "CLI Tool"
    WEB_APP = "Web Application"
    API_SERVER = "API Server"
    MOBILE_APP = "Mobile App"
    DESKTOP_APP = "Desktop App"
    MONOREPO = "Monorepo"
    STATIC_SITE = "Static Site"
    CONFIGURATION = "Configuration"
    DOCUMENTATION = "Documentation"
    UNKNOWN = "Project"


class LicenseType(Enum):
    """License type."""

    MIT = "MIT"
    APACHE2 = "Apache-2.0"
    GPL3 = "GPL-3.0"
    GPL2 = "GPL-2.0"
    BSD2 = "BSD-2-Clause"
    BSD3 = "BSD-3-Clause"
    ISC = "ISC"
    UNLICENSE = "Unlicense"
    MPL2 = "MPL-2.0"
    LGPL3 = "LGPL-3.0"
    AGPL3 = "AGPL-3.0"
    PROPRIETARY = "Proprietary"
    UNKNOWN = "Unknown"


@dataclass
class ProjectInfo:
    """Core project metadata."""

    name: str = ""
    path: str = "."
    description: str = ""
    version: str = ""
    license: LicenseType = LicenseType.UNKNOWN
    license_text: str = ""
    primary_language: Language = Language.UNKNOWN
    languages: list[Language] = field(default_factory=list)
    frameworks: list[Framework] = field(default_factory=list)
    project_type: ProjectType = ProjectType.UNKNOWN
    python_version: str = ""
    node_version: str = ""
    go_version: str = ""
    rust_edition: str = ""

    # Git info
    git_url: str = ""
    git_default_branch: str = "main"
    has_git: bool = False

    # Package info
    author: str = ""
    author_email: str = ""
    homepage: str = ""
    keywords: list[str] = field(default_factory=list)

    # Structure info
    has_tests: bool = False
    has_docs: bool = False
    has_ci: bool = False
    has_docker: bool = False
    has_contributing: bool = False
    has_changelog: bool = False
    has_examples: bool = False
    entry_point: str = ""
    install_command: str = ""
    test_command: str = ""
    build_command: str = ""
    run_command: str = ""

    @property
    def display_name(self) -> str:
        """Human-friendly project name."""
        if self.name:
            return self.name.replace("-", " ").replace("_", " ").title()
        return "Project"

    @property
    def badge_language(self) -> str:
        """Language string for badges."""
        return self.primary_language.value if self.primary_language != Language.UNKNOWN else ""


@dataclass
class FileStats:
    """File statistics for a project."""

    total_files: int = 0
    total_dirs: int = 0
    total_lines: int = 0
    file_types: dict[str, int] = field(default_factory=dict)
    largest_files: list[tuple[str, int]] = field(default_factory=list)


@dataclass
class DirectoryEntry:
    """A directory tree entry."""

    name: str
    is_dir: bool = False
    children: list[DirectoryEntry] = field(default_factory=list)
    depth: int = 0


@dataclass
class Section:
    """A README section."""

    title: str
    content: str
    order: int = 0
    anchor: str = ""
    include: bool = True

    def __post_init__(self):
        if not self.anchor:
            self.anchor = self.title.lower().replace(" ", "-").replace("&", "and")


@dataclass
class ReadmeConfig:
    """Configuration for README generation."""

    # Section toggles
    include_badges: bool = True
    include_toc: bool = True
    include_installation: bool = True
    include_usage: bool = True
    include_api: bool = False
    include_contributing: bool = True
    include_license: bool = True
    include_tree: bool = False
    include_features: bool = True
    include_tech_stack: bool = True
    include_acknowledgements: bool = False
    include_faq: bool = False

    # Style options
    badge_style: str = "flat"  # flat, flat-square, for-the-badge, plastic, social
    emoji_headers: bool = True
    header_style: str = "banner"  # banner, simple, minimal
    toc_style: str = "bullet"  # bullet, numbered, table
    tree_depth: int = 3

    # Custom content
    custom_badges: list[dict[str, str]] = field(default_factory=list)
    custom_sections: list[Section] = field(default_factory=list)
    features: list[str] = field(default_factory=list)
    acknowledgements: list[str] = field(default_factory=list)


# ── Language / Extension Mapping ─────────────────────────────

EXTENSION_LANGUAGE_MAP: dict[str, Language] = {
    ".py": Language.PYTHON,
    ".js": Language.JAVASCRIPT,
    ".jsx": Language.JAVASCRIPT,
    ".ts": Language.TYPESCRIPT,
    ".tsx": Language.TYPESCRIPT,
    ".go": Language.GO,
    ".rs": Language.RUST,
    ".java": Language.JAVA,
    ".cs": Language.CSHARP,
    ".cpp": Language.CPP,
    ".cc": Language.CPP,
    ".cxx": Language.CPP,
    ".c": Language.C,
    ".h": Language.C,
    ".rb": Language.RUBY,
    ".php": Language.PHP,
    ".swift": Language.SWIFT,
    ".kt": Language.KOTLIN,
    ".kts": Language.KOTLIN,
    ".dart": Language.DART,
    ".sh": Language.SHELL,
    ".bash": Language.SHELL,
    ".zsh": Language.SHELL,
    ".lua": Language.LUA,
    ".r": Language.R,
    ".R": Language.R,
    ".scala": Language.SCALA,
    ".ex": Language.ELIXIR,
    ".exs": Language.ELIXIR,
    ".hs": Language.HASKELL,
}


LANGUAGE_COLORS: dict[Language, str] = {
    Language.PYTHON: "3776AB",
    Language.JAVASCRIPT: "F7DF1E",
    Language.TYPESCRIPT: "3178C6",
    Language.GO: "00ADD8",
    Language.RUST: "000000",
    Language.JAVA: "ED8B00",
    Language.CSHARP: "239120",
    Language.CPP: "00599C",
    Language.C: "A8B9CC",
    Language.RUBY: "CC342D",
    Language.PHP: "777BB4",
    Language.SWIFT: "FA7343",
    Language.KOTLIN: "7F52FF",
    Language.DART: "0175C2",
    Language.SHELL: "4EAA25",
    Language.SCALA: "DC322F",
    Language.ELIXIR: "4B275F",
    Language.HASKELL: "5D4F85",
}


# Directories to skip during analysis
SKIP_DIRS: set[str] = {
    ".git", ".svn", ".hg", "__pycache__", "node_modules", ".tox", ".nox",
    ".mypy_cache", ".pytest_cache", ".ruff_cache", "venv", ".venv", "env",
    ".env", "dist", "build", ".eggs", "*.egg-info", ".idea", ".vscode",
    "target", "vendor", "Pods", ".gradle", ".next", ".nuxt", "out",
    "coverage", "htmlcov", ".terraform", ".cache",
}

SKIP_FILES: set[str] = {
    ".DS_Store", "Thumbs.db", ".gitkeep", "*.pyc", "*.pyo",
}
