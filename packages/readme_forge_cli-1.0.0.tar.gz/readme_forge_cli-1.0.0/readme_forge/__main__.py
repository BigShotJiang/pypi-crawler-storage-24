"""Allow running as python -m readme_forge."""

from readme_forge.cli import cli

if __name__ == "__main__":
    cli()
