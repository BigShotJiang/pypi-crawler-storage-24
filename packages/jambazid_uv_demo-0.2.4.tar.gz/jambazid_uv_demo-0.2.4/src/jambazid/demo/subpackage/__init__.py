"""
Subpackage initialization module.


## Heading 1

Markdown is supported.

```sh
#!/bin/bash

echo "markdown syntax highlighting."
```

## Heading 2

...

Lorem ipsum.


## Heading 3

...

## Mermaid Support

```mermaid
graph TD;
    A-->B;
    A-->C;
    B-->D;
    C-->D;
```
"""
