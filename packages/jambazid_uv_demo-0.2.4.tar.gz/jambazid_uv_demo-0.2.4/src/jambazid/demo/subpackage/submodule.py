"""
Demonstration submodule.
"""

import typing as t


__all__ = [
    "ANOTHER_CONSTANT",
    "YET_ANOTHER_CONSTANT",
]


ANOTHER_CONSTANT: t.Final[int] = 1
"""
Documented module constants are automatically rendered in the API Reference.


```python
# Markdown code blocks are fully supported:

from jambazid.demo.subpackage.submodule import ANOTHER_CONSTANT


assert ANOTHER_CONSTANT == 1, "Invalid constant."
```
"""


YET_ANOTHER_CONSTANT: t.Final[int] = 2
"""
Lorem ipsum.
"""
