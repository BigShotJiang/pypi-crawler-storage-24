import numpy as np

from .types import Point

def astar(
    img: np.ndarray,
    start: tuple[int, int],
    goals: list[tuple[int, int]],
    direction: str,
) -> list[tuple[int, int]] | None: ...

class TableGrower:
    """
    Grow a table using this omni directional method
    """

    def __init__(
        self,
        cross_correlation: np.ndarray,
        column_widths: list[int],
        row_heights: list[int],
        top_row: list[tuple[int, int] | None],
        search_region: int,
        distance_penalty: float = 0.5,
        look_distance: int = 3,
        grow_threshold: float = 0.5,
        skip_astar_threshold: float = 0.7,
        min_row_count: int = 5,
        cuts: int = 5,
        cut_fraction: float = 0.6,
    ): ...
    def get_corner(self, coord: tuple[int, int]) -> Point | None: ...
    def all_rows_complete(self) -> bool: ...
    def get_all_corners(self) -> list[list[Point | None]]: ...
    def get_edge_points(self) -> list[tuple[Point, float]]: ...
    def grow_point(
        self,
        table_image: np.ndarray,
        cross_correlation: np.ndarray,
    ) -> float | None: ...
    def grow_points(
        self,
        table_image: np.ndarray,
        cross_correlation: np.ndarray,
    ): ...
    def extrapolate_one(
        self, table_image: np.ndarray, cross_correlation: np.ndarray
    ) -> Point | None: ...
    def is_table_complete(self) -> bool: ...
    def grow_table(
        self,
        table_image: np.ndarray,
        cross_correlation: np.ndarray,
    ): ...
    def set_threshold(self, value: float): ...
    def smooth_grid(
        self, strength: float = 0.5, iterations: int = 1, degree: int = 1
    ): ...
