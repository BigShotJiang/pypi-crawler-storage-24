#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import unittest
import sys
from unittest.mock import patch
from pyhandytools.env import EnvUtils


class TestEnv(unittest.TestCase):

    def test_init_env(self):
        """测试初始化环境方法可以正常调用"""
        try:
            EnvUtils.init_env()
        except Exception as e:
            self.fail(f"init_env() raised {e} unexpectedly!")

    def test_get_platform_returns_string(self):
        """测试get_platform返回字符串"""
        platform = EnvUtils.get_platform()
        self.assertIsInstance(platform, str)

    def test_get_platform_not_empty(self):
        """测试get_platform返回非空字符串"""
        platform = EnvUtils.get_platform()
        self.assertGreater(len(platform), 0)

    @patch.object(sys, 'platform', 'linux')
    def test_get_platform_linux(self):
        """测试Linux平台识别"""
        platform = EnvUtils.get_platform()
        self.assertEqual(platform, 'linux')

    @patch.object(sys, 'platform', 'win32')
    def test_get_platform_windows(self):
        """测试Windows平台识别"""
        platform = EnvUtils.get_platform()
        self.assertEqual(platform, 'win32')

    @patch.object(sys, 'platform', 'darwin')
    def test_get_platform_macos(self):
        """测试macOS平台识别"""
        platform = EnvUtils.get_platform()
        self.assertEqual(platform, 'darwin')

    @patch.object(sys, 'platform', 'Linux')
    def test_get_platform_case_insensitive(self):
        """测试平台字符串转为小写"""
        platform = EnvUtils.get_platform()
        self.assertEqual(platform, 'linux')


if __name__ == '__main__':
    unittest.main()
