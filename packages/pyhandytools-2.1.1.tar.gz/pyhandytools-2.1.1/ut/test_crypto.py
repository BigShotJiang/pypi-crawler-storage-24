#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import unittest
from pyhandytools.crypto import CryptoUtils


class TestCrypto(unittest.TestCase):

    def setUp(self):
        """设置测试密钥"""
        self.key = "test-key-32-bytes-long!!!!"
        self.crypto = CryptoUtils(self.key)

    def test_encrypt_decrypt(self):
        """测试加密和解密功能"""
        plaintext = "Hello, World!"
        encrypted = self.crypto.encrypt(plaintext)
        decrypted = self.crypto.decrypt(encrypted)
        self.assertEqual(plaintext, decrypted)

    def test_encrypt_different_output(self):
        """测试加密后的结果与原文不同"""
        plaintext = "Test message"
        encrypted = self.crypto.encrypt(plaintext)
        self.assertNotEqual(plaintext, encrypted)

    def test_encrypt_not_empty(self):
        """测试加密结果不为空"""
        plaintext = "Test"
        encrypted = self.crypto.encrypt(plaintext)
        self.assertIsNotNone(encrypted)
        self.assertGreater(len(encrypted), 0)

    def test_decrypt_wrong_key(self):
        """测试使用错误密钥解密会失败"""
        plaintext = "Secret message"
        encrypted = self.crypto.encrypt(plaintext)

        wrong_crypto = CryptoUtils("wrong-key-32-bytes-long!!!")
        with self.assertRaises(Exception):
            wrong_crypto.decrypt(encrypted)

    def test_key_padding(self):
        """测试密钥自动填充到32字节"""
        short_key = "short"
        crypto = CryptoUtils(short_key)
        plaintext = "Test"
        encrypted = crypto.encrypt(plaintext)
        decrypted = crypto.decrypt(encrypted)
        self.assertEqual(plaintext, decrypted)

    def test_key_truncation(self):
        """测试超长密钥会被截断到32字节"""
        long_key = "a" * 100
        crypto = CryptoUtils(long_key)
        plaintext = "Test"
        encrypted = crypto.encrypt(plaintext)
        decrypted = crypto.decrypt(encrypted)
        self.assertEqual(plaintext, decrypted)

    def test_empty_string(self):
        """测试空字符串加密解密"""
        plaintext = ""
        encrypted = self.crypto.encrypt(plaintext)
        decrypted = self.crypto.decrypt(encrypted)
        self.assertEqual(plaintext, decrypted)

    def test_unicode_characters(self):
        """测试Unicode字符加密解密"""
        plaintext = "你好，世界！🌍"
        encrypted = self.crypto.encrypt(plaintext)
        decrypted = self.crypto.decrypt(encrypted)
        self.assertEqual(plaintext, decrypted)

    def test_long_text(self):
        """测试长文本加密解密"""
        plaintext = "A" * 10000
        encrypted = self.crypto.encrypt(plaintext)
        decrypted = self.crypto.decrypt(encrypted)
        self.assertEqual(plaintext, decrypted)


if __name__ == '__main__':
    unittest.main()
