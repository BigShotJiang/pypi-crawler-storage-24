#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import unittest
from pyhandytools.calc import true_round


class TestCalc(unittest.TestCase):

    def test_true_round_integer(self):
        """测试四舍五入到整数"""
        self.assertEqual(true_round(3.4), 3)
        self.assertEqual(true_round(3.5), 4)
        self.assertEqual(true_round(3.6), 4)
        # 注意：当前实现对于负数四舍五入的处理是 int(-3.4 * 1 + 0.5) = int(-2.9) = -2
        self.assertEqual(true_round(-3.4), -2)
        self.assertEqual(true_round(-3.5), -3)
        self.assertEqual(true_round(-3.6), -3)

    def test_true_round_with_decimal(self):
        """测试四舍五入到指定小数位"""
        self.assertEqual(true_round(3.14159, 2), 3.14)
        self.assertEqual(true_round(3.14159, 3), 3.142)
        self.assertEqual(true_round(2.5, 1), 2.5)
        self.assertEqual(true_round(2.55, 1), 2.6)

    def test_true_round_zero_decimal(self):
        """测试四舍五入到0位小数（等同于整数）"""
        self.assertEqual(true_round(3.7, 0), 4)
        self.assertIsInstance(true_round(3.7, 0), int)

    def test_true_round_negative_n(self):
        """测试负数n应该返回None"""
        result = true_round(3.14, -1)
        self.assertIsNone(result)

    def test_true_round_edge_cases(self):
        """测试边界情况"""
        self.assertEqual(true_round(0), 0)
        self.assertEqual(true_round(0.0), 0)
        self.assertEqual(true_round(0.4999, 0), 0)
        self.assertEqual(true_round(0.5, 0), 1)


if __name__ == '__main__':
    unittest.main()
