#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import unittest
from pyhandytools.cleaner import ParserUtil


class TestCleaner(unittest.TestCase):

    def test_clear_text_simple(self):
        """测试简单的HTML清理"""
        html = "<p>Hello World</p>"
        result = ParserUtil.clear_text(html)
        self.assertIn("Hello World", result)

    def test_clear_text_with_nested_tags(self):
        """测试嵌套HTML标签清理"""
        html = "<div><p>Hello <strong>World</strong></p></div>"
        result = ParserUtil.clear_text(html)
        self.assertIn("Hello", result)
        self.assertIn("World", result)

    def test_clear_text_with_script(self):
        """测试包含script标签的HTML清理"""
        html = "<p>Hello</p><script>alert('test')</script><p>World</p>"
        result = ParserUtil.clear_text(html)
        self.assertIn("Hello", result)
        self.assertIn("World", result)
        self.assertNotIn("script", result)
        self.assertNotIn("alert", result)

    def test_clear_text_with_style(self):
        """测试包含style标签的HTML清理"""
        html = "<p>Hello</p><style>.test{color:red}</style><p>World</p>"
        result = ParserUtil.clear_text(html)
        self.assertIn("Hello", result)
        self.assertIn("World", result)

    def test_sanitize(self):
        """测试sanitize方法"""
        html = "<html><body><p>Test</p><script>alert('xss')</script></body></html>"
        result = ParserUtil.sanitize(html)
        self.assertIsInstance(result, str)

    def test_delete_extra_flag(self):
        """测试删除额外字符方法"""
        text = "Hello\\n\\n\\nWorld"
        result = ParserUtil.delete_extra_flag(text, "\\n")
        self.assertEqual(result, "Hello\\nWorld")

    def test_delete_extra_flag_multiple(self):
        """测试删除多个连续重复字符"""
        text = "Hello    World"
        result = ParserUtil.delete_extra_flag(text, " ")
        self.assertEqual(result, "Hello World")

    def test_clear_text_empty(self):
        """测试空HTML - 空字符串会导致解析错误，这里测试简单HTML"""
        html = "<html></html>"
        result = ParserUtil.clear_text(html)
        self.assertIsInstance(result, str)

    def test_labels_list(self):
        """测试labels列表不为空"""
        self.assertIsInstance(ParserUtil.labels, list)
        self.assertGreater(len(ParserUtil.labels), 0)
        self.assertIn('div', ParserUtil.labels)
        self.assertIn('p', ParserUtil.labels)


if __name__ == '__main__':
    unittest.main()
