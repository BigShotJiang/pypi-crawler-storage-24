#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
pyhandytools 单元测试模块

包含以下测试文件:
- test_calc.py: 计算工具模块测试
- test_cleaner.py: HTML清理工具模块测试
- test_crypto.py: 加密工具模块测试
- test_env.py: 环境工具模块测试
- test_file.py: 文件工具模块测试
- test_logger.py: 日志工具模块测试
- test_req.py: 异步请求工具模块测试

运行所有测试:
    python -m unittest discover -s ut -v

运行单个测试文件:
    python -m unittest ut.test_calc -v
"""
