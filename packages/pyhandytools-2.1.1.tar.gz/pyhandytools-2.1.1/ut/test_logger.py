#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import unittest
import os
import tempfile
import shutil
from loguru._logger import Logger
from pyhandytools.logger import LoggerUtils


class TestLoggerUtils(unittest.TestCase):

    def setUp(self):
        """创建临时目录"""
        self.temp_dir = tempfile.mkdtemp()
        self.log_path = os.path.join(self.temp_dir, "test.log")

    def tearDown(self):
        """清理临时目录"""
        shutil.rmtree(self.temp_dir, ignore_errors=True)

    def test_init_logger_returns_logger(self):
        """测试初始化日志返回Logger对象"""
        logger = LoggerUtils.init_logger(
            logger_path=self.log_path,
            service_name="test_service"
        )
        self.assertIsInstance(logger, Logger)

    def test_init_logger_creates_file(self):
        """测试初始化日志创建日志文件"""
        LoggerUtils.init_logger(
            logger_path=self.log_path,
            service_name="test_service"
        )
        # 日志文件可能延迟创建，先写入一条日志
        # 文件应该会被创建
        self.assertTrue(os.path.exists(self.temp_dir))

    def test_init_logger_with_custom_level(self):
        """测试使用自定义日志级别"""
        logger = LoggerUtils.init_logger(
            logger_path=self.log_path,
            service_name="test_service",
            level="INFO"
        )
        self.assertIsInstance(logger, Logger)

    def test_init_logger_with_custom_format(self):
        """测试使用自定义格式"""
        custom_format = "{time} | {level} | {message}"
        logger = LoggerUtils.init_logger(
            logger_path=self.log_path,
            service_name="test_service",
            log_format=custom_format
        )
        self.assertIsInstance(logger, Logger)

    def test_init_logger_with_version(self):
        """测试带版本号的日志初始化"""
        logger = LoggerUtils.init_logger(
            logger_path=self.log_path,
            service_name="test_service",
            version="1.0.0"
        )
        self.assertIsInstance(logger, Logger)

    def test_parse_level_uppercase(self):
        """测试日志级别转为大写"""
        result = LoggerUtils.parse_level("debug")
        self.assertEqual(result, "DEBUG")

        result = LoggerUtils.parse_level("INFO")
        self.assertEqual(result, "INFO")

    def test_new_generic_logger(self):
        """测试创建通用日志器"""
        logger = LoggerUtils.new_generic_logger(
            service_name="generic_service",
            logger_path=self.log_path,
            level="DEBUG"
        )
        self.assertIsInstance(logger, Logger)

    def test_default_log_format(self):
        """测试默认日志格式不为空"""
        self.assertIsNotNone(LoggerUtils.default_log_format)
        self.assertIsInstance(LoggerUtils.default_log_format, str)
        self.assertIn("time:", LoggerUtils.default_log_format)
        self.assertIn("level", LoggerUtils.default_log_format)

    def test_version_prefix(self):
        """测试版本前缀"""
        self.assertEqual(LoggerUtils._version_prefix, "V")


if __name__ == '__main__':
    unittest.main()
