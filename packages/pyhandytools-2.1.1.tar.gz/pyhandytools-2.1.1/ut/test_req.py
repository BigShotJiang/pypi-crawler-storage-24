#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import unittest
from pyhandytools.req import AsyncApiUtil


class TestAsyncApiUtil(unittest.TestCase):

    def setUp(self):
        """设置测试环境"""
        self.test_url = "http://example.com/api"
        self.test_payload = {"key": "value"}
        self.test_headers = {"Content-Type": "application/json"}

    def test_default_headers(self):
        """测试默认headers"""
        self.assertEqual(AsyncApiUtil._AsyncApiUtil__headers, {'Content-Type': "application/json"})

    def test_default_workers(self):
        """测试默认workers数量"""
        self.assertEqual(AsyncApiUtil._AsyncApiUtil__default_workers, 2)

    def test_post_method_exists(self):
        """测试post方法存在"""
        self.assertTrue(hasattr(AsyncApiUtil, 'post'))
        self.assertTrue(callable(getattr(AsyncApiUtil, 'post')))

    def test_get_method_exists(self):
        """测试get方法存在"""
        self.assertTrue(hasattr(AsyncApiUtil, 'get'))
        self.assertTrue(callable(getattr(AsyncApiUtil, 'get')))

    def test_req_post_method_exists(self):
        """测试req_post方法存在"""
        self.assertTrue(hasattr(AsyncApiUtil, 'req_post'))
        self.assertTrue(callable(getattr(AsyncApiUtil, 'req_post')))

    def test_req_get_method_exists(self):
        """测试req_get方法存在"""
        self.assertTrue(hasattr(AsyncApiUtil, 'req_get'))
        self.assertTrue(callable(getattr(AsyncApiUtil, 'req_get')))


if __name__ == '__main__':
    unittest.main()
