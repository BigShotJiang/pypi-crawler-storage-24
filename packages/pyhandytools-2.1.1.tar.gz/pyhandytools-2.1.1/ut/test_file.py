#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import unittest
import os
import json
import tempfile
import shutil
from pyhandytools.file import FileUtils, ImageUtil


class TestFileUtils(unittest.TestCase):

    def setUp(self):
        """创建临时目录"""
        self.temp_dir = tempfile.mkdtemp()
        self.test_json_path = os.path.join(self.temp_dir, "test.json")
        self.test_jsonl_path = os.path.join(self.temp_dir, "test.jsonl")

    def tearDown(self):
        """清理临时目录"""
        shutil.rmtree(self.temp_dir, ignore_errors=True)

    def test_write2json_and_load_json(self):
        """测试写入和读取JSON文件"""
        test_data = {"name": "test", "value": 123}
        FileUtils.write2json(self.test_json_path, test_data)

        self.assertTrue(os.path.exists(self.test_json_path))

        loaded_data = FileUtils.load_json(self.test_json_path)
        self.assertEqual(loaded_data, test_data)

    def test_write2json_list_data(self):
        """测试写入列表数据到JSON"""
        test_data = [{"id": 1}, {"id": 2}]
        FileUtils.write2json(self.test_json_path, test_data)

        loaded_data = FileUtils.load_json(self.test_json_path)
        self.assertEqual(loaded_data, test_data)

    def test_load_json_empty_file(self):
        """测试读取空JSON文件"""
        with open(self.test_json_path, 'w') as f:
            f.write('')

        result = FileUtils.load_json(self.test_json_path)
        self.assertEqual(result, {})

    def test_write2jsonl_and_load_jsonl(self):
        """测试写入和读取JSONL文件"""
        test_data = [{"id": 1, "name": "a"}, {"id": 2, "name": "b"}]
        FileUtils.write2jsonl(self.test_jsonl_path, test_data)

        self.assertTrue(os.path.exists(self.test_jsonl_path))

        loaded_data = FileUtils.load_jsonl(self.test_jsonl_path)
        self.assertEqual(loaded_data, test_data)

    def test_load_jsonl_empty_file(self):
        """测试读取空JSONL文件"""
        with open(self.test_jsonl_path, 'w') as f:
            f.write('')

        result = FileUtils.load_jsonl(self.test_jsonl_path)
        self.assertEqual(result, [])

    def test_check_dir_path(self):
        """测试检查并创建目录"""
        new_dir = os.path.join(self.temp_dir, "new_subdir")
        FileUtils.check_dir_path(new_dir)
        self.assertTrue(os.path.exists(new_dir))
        self.assertTrue(os.path.isdir(new_dir))

    def test_check_dir_path_existing(self):
        """测试检查已存在的目录"""
        FileUtils.check_dir_path(self.temp_dir)
        self.assertTrue(os.path.exists(self.temp_dir))

    def test_count_file_number(self):
        """测试统计文件数量"""
        # 创建一些测试文件
        for i in range(3):
            with open(os.path.join(self.temp_dir, f"file{i}.txt"), 'w') as f:
                f.write('test')

        count = FileUtils.count_file_number(self.temp_dir)
        self.assertEqual(count, 3)

    def test_check_jsonfile_existed_and_mkdir_new_file(self):
        """测试检查不存在的JSON文件并创建"""
        new_json_path = os.path.join(self.temp_dir, "new.json")
        FileUtils.check_jsonfile_existed_and_mkdir(new_json_path)
        self.assertTrue(os.path.exists(new_json_path))

        content = FileUtils.load_json(new_json_path)
        self.assertEqual(content, [])

    def test_check_jsonfile_existed_and_mkdir_existing_file(self):
        """测试检查已存在的JSON文件"""
        test_data = {"existing": True}
        FileUtils.write2json(self.test_json_path, test_data)

        FileUtils.check_jsonfile_existed_and_mkdir(self.test_json_path)
        content = FileUtils.load_json(self.test_json_path)
        self.assertEqual(content, test_data)

    def test_pretty_json(self):
        """测试美化JSON输出"""
        data = {"name": "test", "items": [1, 2, 3]}
        result = FileUtils.pretty_json(data)

        self.assertIsInstance(result, str)
        self.assertIn('"name": "test"', result)
        self.assertIn('"items"', result)

    def test_pretty_json_with_indent(self):
        """测试自定义缩进的美化JSON"""
        data = {"key": "value"}
        result = FileUtils.pretty_json(data, indent=2)
        self.assertIsInstance(result, str)

    def test_pretty_json_none(self):
        """测试传入None返回None"""
        result = FileUtils.pretty_json(None)
        self.assertIsNone(result)

    def test_cp_and_rm_success(self):
        """测试复制并删除文件成功"""
        old_file = os.path.join(self.temp_dir, "old.txt")
        new_file = os.path.join(self.temp_dir, "new.txt")

        with open(old_file, 'w') as f:
            f.write('test content')

        result = FileUtils.cp_and_rm(old_file, new_file)
        self.assertTrue(result)
        self.assertTrue(os.path.exists(new_file))
        self.assertFalse(os.path.exists(old_file))

    def test_cp_and_rm_file_not_exist(self):
        """测试复制不存在的文件"""
        old_file = os.path.join(self.temp_dir, "nonexistent.txt")
        new_file = os.path.join(self.temp_dir, "new.txt")

        result = FileUtils.cp_and_rm(old_file, new_file)
        self.assertFalse(result)


class TestImageUtil(unittest.TestCase):

    def setUp(self):
        """创建临时目录"""
        self.temp_dir = tempfile.mkdtemp()
        self.test_img_path = os.path.join(self.temp_dir, "test_image.png")

        # 创建一个简单的PNG图片（1x1像素，透明）
        import base64
        # 这是一个最小的有效PNG文件（1x1透明像素）
        png_data = base64.b64decode(
            "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8/5+hHgAHggJ/PchI7wAAAABJRU5ErkJggg=="
        )
        with open(self.test_img_path, 'wb') as f:
            f.write(png_data)

    def tearDown(self):
        """清理临时目录"""
        shutil.rmtree(self.temp_dir, ignore_errors=True)

    def test_base64_encode_img(self):
        """测试图片base64编码"""
        encoded = ImageUtil.base64_encode_img(self.test_img_path)
        self.assertIsInstance(encoded, str)
        self.assertGreater(len(encoded), 0)

    def test_base64_decode_img(self):
        """测试base64解码为图片"""
        # 先编码
        encoded = ImageUtil.base64_encode_img(self.test_img_path)

        # 再解码到新文件
        decoded_path = os.path.join(self.temp_dir, "decoded.png")
        result = ImageUtil.base64_decode_img(encoded, decoded_path)

        self.assertTrue(result)
        self.assertTrue(os.path.exists(decoded_path))

    def test_base64_decode_img_invalid_data(self):
        """测试解码无效数据"""
        # 使用有效的base64字符但无效的图片数据
        invalid_encoded = "aW52YWxpZF9pbWFnZV9kYXRh"  # "invalid_image_data" 的base64
        decoded_path = os.path.join(self.temp_dir, "decoded.txt")

        result = ImageUtil.base64_decode_img(invalid_encoded, decoded_path)
        # 虽然数据不是有效的图片，但函数应该成功写入文件
        self.assertTrue(result)


if __name__ == '__main__':
    unittest.main()
