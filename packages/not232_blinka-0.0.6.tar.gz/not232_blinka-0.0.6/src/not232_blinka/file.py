
from . import n232

class File:

    READ_ONLY = 1
    WRITE_ONLY = 2
    READ_WRITE = 3

    CREATE = 0x100
    EXCLUSIVE = 0x200
    TRUNCATE = 0x400
    APPEND = 0x800

    def __init__(self,
                 n232_device: n232.N232,
                 path,
                 rw: READ_ONLY | WRITE_ONLY | READ_WRITE,
                 create : bool = False,
                 exclusive : bool = False,
                 truncate : bool = False,
                 append : bool = False,
                 ):
        self.device = n232_device

        flags = rw | create * File.CREATE | exclusive * File.EXCLUSIVE | truncate * File.TRUNCATE | append * File.APPEND

        # Before open is called, the device is closed. if open fails, then this means close() will not be called
        self._closed = True

        self.fh = self.device.flashfs_file_open(path, flags)

        self._closed = False

    def read(self, size):
        return self.device.flash_file_read(self.fh, size)

    def write(self, data):
        self.device.flash_file_write(self.fh, data)

    def close(self):
        if not self._closed:
            self.device.flashfs_file_close(self.fh)
            self._closed = True

    def __del__(self):
        self.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
        return False