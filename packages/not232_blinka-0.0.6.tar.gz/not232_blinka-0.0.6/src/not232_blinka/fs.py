
from . import n232
from . import file
from . import dirs

class Volume:

    def __init__(self, n232_device: n232.N232):
        self.device = n232_device

    def remove(self, path):
        self.device.flashfs_remove(path)

    def mkdir(self, path):
        self.device.flash_mkdir(path)

    def move(self, source, destination):
        self.device.flashfs_move(source, destination)

    def rename(self, from_path, to_path):
        self.device.flashfs_move(from_path, to_path)

    def listdir(self, path = "/"):
        return (path for _, _, path in dirs.Directories(self.device, path))

    def walk(self, top):
        raise RuntimeError("Unimplemented")

    def open(self,
                 path,
                 rw: file.File.READ_ONLY | file.File.WRITE_ONLY | file.File.READ_WRITE,
                 create : bool = False,
                 exclusive : bool = False,
                 truncate : bool = False,
                 append : bool = False,
                 ):
        return file.File(self.device, path, rw, create, exclusive, truncate, append)