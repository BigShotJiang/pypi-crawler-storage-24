import os



for x in os.walk("./"):
    print(x)