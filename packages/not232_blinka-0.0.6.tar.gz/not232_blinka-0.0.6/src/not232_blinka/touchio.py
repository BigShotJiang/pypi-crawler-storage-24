from . import board

class TouchIn:

    def __init__(self, pin: board.Pin):
        self.pin = pin
        self.threshold = 3000
        self.pin.init(board.Pin.ADC)

    def deinit(self):
        self.pin.deinit()

    def __exit__(self):
        self.deinit()

    def __enter__(self):
        return self

    @property
    def raw_value(self):
        """Read the ADC touch key and return the value"""
        return self.pin.device().adc_tkey_read(self.pin.pin_number())

    # pylint: disable=no-self-use
    @raw_value.setter
    def raw_value(self, value):
        # emulate what CircuitPython does
        raise AttributeError("'AnalogIn' object has no attribute 'touchkey_value'")

    @property
    def value(self):
        """Read the ADC touch key and return the value"""
        return self.raw_value < self.threshold

    # pylint: disable=no-self-use
    @value.setter
    def value(self, value):
        # emulate what CircuitPython does
        raise AttributeError("'AnalogIn' object has no attribute 'touchkey_value'")


