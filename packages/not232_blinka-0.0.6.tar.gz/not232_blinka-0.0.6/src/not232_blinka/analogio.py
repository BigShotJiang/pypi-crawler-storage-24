from . import board

class AnalogIn:

    reference_voltage = 3.3

    def __init__(self, pin):
        self.pin = pin

        self.pin.init(board.Pin.ADC)

    @property
    def value(self):
        """Read the ADC and return the value"""
        return self.pin.value() << 4

    # pylint: disable=no-self-use
    @value.setter
    def value(self, value):
        # emulate what CircuitPython does
        raise AttributeError("'AnalogIn' object has no attribute 'value'")

    @property
    def touchkey_value(self):
        """Read the ADC touch key and return the value"""
        return self.pin.device().adc_tkey_read(self.pin.pin_number())

    # pylint: disable=no-self-use
    @touchkey_value.setter
    def touchkey_value(self, value):
        # emulate what CircuitPython does
        raise AttributeError("'AnalogIn' object has no attribute 'touchkey_value'")

    # pylint: enable=no-self-use

    def deinit(self):
        self.pin.deinit()

    def __enter__(self):
        return self

    def __exit__(self):
        self.deinit()