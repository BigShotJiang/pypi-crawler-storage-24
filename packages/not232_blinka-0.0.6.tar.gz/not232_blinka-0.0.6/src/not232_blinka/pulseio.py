from . import board

class PulseIn:

    def __init__(self, pin: board.Pin, maxlen: int = 2, *, idle_state: bool = False):
        self._pin = pin
        self.maxlen = maxlen
        self.paused = False
        self.pulses = []

        self._pin.device().pulseio_clear()
        self._pin.device().pulseio_resume(self._pin.pin_number())

    def deinit(self):
        self._pin.device().pulseio_stop(self._pin.pin_number())
        self._pin.deinit()

    def pause(self):
        self.paused = True
        self._pin.device().pulseio_stop(self._pin.pin_number())

        self.pulses.extend(self._pin.device().pulseio_read(self.maxlen))

    def resume(self, trigger_duration: int = 0):
        self.paused = False
        self._pin.device().pulseio_resume(self._pin.pin_number(), trigger_duration)

    def clear(self):
        self._pin.device().pulseio_clear()
        self.pulses = []

    def popleft(self):
        return self.pulses.pop(0)

    def __bool__(self):
        return len(self) != 0

    def __len__(self):
        return len(self.pulses)

    def __getitem__(self, item):
        return self.pulses[item]

    def __exit__(self):
        self.deinit()

    def __enter__(self):
        return self


class PulseOut:

    def __init__(self, pin: board.Pin, frequency: int = 37500, duty_cycle: int = 1 << 15):
        self._pin = pin

        if frequency != 37500:
            raise RuntimeError("Only 37.5KHz carrier frequency is currently supported")

        self.duty_cycle = duty_cycle

        self._pin.device().pwm_init(self._pin.pin_number())

    def deinit(self):
        self._pin.deinit()

    def send(self, pulses):
        self._pin.device().pulseio_out(self._pin.pin_number(), duty=self.duty_cycle >> 8, pulses=pulses)