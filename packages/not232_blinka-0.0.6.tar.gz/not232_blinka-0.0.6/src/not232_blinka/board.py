

class Pin:

    # pin modes
    OUT = 0
    IN = 1
    ADC = 2
    DAC = 3
    OPEN_DRAIN = 4
    # pin values
    LOW = 0
    HIGH = 1
    # pin pulls
    PULL_NONE = 0
    PULL_UP = 1
    PULL_DOWN = 2

    def __init__(self, pin_id = None):
        self.id = pin_id
        self._mode = None
        self._pull = None
        self.previous_value = False
        self.current_value = None

    def pin_number(self):
        return self.id[0]

    def device(self):
        return self.id[1]

    def init(self, mode=IN, pull=None, value=None):

        if self.id is None:
            raise RuntimeError("Can not init a None type pin.")

        if mode == Pin.DAC:
            raise RuntimeError("N232 Does not have a dac... YET")

        pull = Pin.PULL_NONE if pull is None else pull

        if mode == Pin.OUT and pull != Pin.PULL_NONE:
            raise RuntimeError("CH32 does not support pull up/push down on output")

        if value is not None:
            if value:
                self.device().set_pin(self.pin_number())
            else:
                self.device().clear_pin(self.pin_number())

        if mode == Pin.IN and pull == Pin.PULL_NONE:
            self.device().input_floating(self.pin_number())
        elif mode == Pin.IN and pull == Pin.PULL_UP:
            self.device().input_pull_up(self.pin_number())
        elif mode == Pin.IN and pull == Pin.PULL_DOWN:
            self.device().input_pull_down(self.pin_number())
        elif mode == Pin.OUT:
            self.device().output_push_pull(self.pin_number())
        elif mode == Pin.OPEN_DRAIN:
            self.device().output_open_drain(self.pin_number())
        elif mode == Pin.ADC:
            self.device().adc_init(self.pin_number())
        else:
            raise RuntimeError(f"Unrecognised mode/pull combo (mode: {mode}, pull: {pull})")

        self._pull = pull
        self._mode = mode

    def deinit(self):
        self.init(Pin.IN)

    def write(self, new_value):
        if new_value:
            self.device().set_pin(self.pin_number())
        else:
            self.device().clear_pin(self.pin_number())

    def read(self):
        if self._mode == Pin.ADC:
            return self.device().adc_read(self.pin_number())
        else:
            return self.device().read_pin(self.pin_number())

    def value(self, val=None):
        if self._mode in (Pin.IN, Pin.OUT, Pin.OPEN_DRAIN):
            # digital read
            if val is None:
                return self.read()
            # digital write
            if val in (Pin.LOW, Pin.HIGH):
                return self.write(val)
            # nope
            raise ValueError("Invalid value for pin.")
            # Analog In
        if self._mode == Pin.ADC:
            if val is None:
                return self.read()
            # read only
            raise AttributeError("'AnalogIn' object has no attribute 'value'")
        raise RuntimeError(
            "No action for mode {} with value {}".format(self._mode, val)
        )

