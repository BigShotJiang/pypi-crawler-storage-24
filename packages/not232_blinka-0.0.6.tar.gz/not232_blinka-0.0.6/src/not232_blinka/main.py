from digitalio import DriveMode

import board
import digitalio
import n232
import time
import busio
import adafruit_lis2mdl
import adafruit_mma8451
import analogio
import pwmio
import pulseio
import adafruit_dht
import adafruit_sdcard
import fs
import file

import n232
import touchio

n = n232.N232()


import neopixel

n232_volume = fs.Volume(n)

with n232_volume.open("hello", file.File.READ_WRITE, create=True, exclusive=False) as f:
    print(f.read(11))

print(list(n232_volume.listdir()))

SDA = n.A6
SCL = n.A7
DHT_PIN = n.A5
NEO = n.A0
SCLK = n.A4
MOSI = n.A3
MISO = n.A1
CS = n.A2
ADC = n.F1
SWITCH = n.F2
LED = n.F3

import file
import fs
import dirs

n.built_in_neopixel(10, 2, 0)

p = touchio.TouchIn(ADC)


i = busio.I2C(SDA, SCL)

d = digitalio.DigitalInOut(SWITCH)
d.switch_to_input(digitalio.Pull.DOWN)

l = digitalio.DigitalInOut(LED)
l.switch_to_output(0)

print("I2C Scan:")
print(i.scan())

try:
    sensor_m = adafruit_lis2mdl.LIS2MDL(i)
except AttributeError:
    sensor_m = None
    print("Could not find LIS2MDL")


try:
    sensor_a = adafruit_mma8451.MMA8451(i)
except RuntimeError:
    sensor_a = None
    print("Could not find MMA8451")

dht22 = adafruit_dht.DHT22(DHT_PIN)

try:
    _tmp = dht22.temperature
except RuntimeError:
    dht22 = None

meo = neopixel.NeoPixel(NEO, 1)

spi = busio.SPI(SCLK, MOSI, MISO)
cs = digitalio.DigitalInOut(CS)

try:
    sdcard = adafruit_sdcard.SDCard(spi, cs)



    b = bytearray([0] * 512)

    sdcard.readblocks(8192, b)

    print(b)
except OSError:
    print("No SD Card")

color = 0

brightness = 10

while True:
    if sensor_m is not None:
        mag_x, mag_y, mag_z = sensor_m.magnetic
        print('Magnetometer (uT): ({0:10.3f}, {1:10.3f}, {2:10.3f})'.format(mag_x, mag_y, mag_z))

    if sensor_a is not None:
        x, y, z = sensor_a.acceleration
        print(f"Acceleration: x={x:0.3f}m/s^2 y={y:0.3f}m/s^2 z={z:0.3f}m/s^2")

    if dht22 is not None:
        temperature = dht22.temperature
        humidity = dht22.humidity
        print(f"Temperature: {temperature}°C Humidity: {humidity}%")

    red = color & 1
    green = (color >> 1) & 1
    blue = (color >> 2) & 1

    meo[0] = (red * brightness, green * brightness, blue * brightness)

    n.built_in_neopixel(red * brightness, green * brightness, blue * brightness)

    color = (color + 1) % 8

    print(f"Touchkey: {p.value}")

    print(f"Switch: {d.value}")

    l.value = not l.value

    print('')
    time.sleep(1.0)