from . import board
from . import analogio
from . import busio
from . import n232
from . import dirs
from . import file
from . import fs
from . import pulseio
from . import pwmio
from . import touchio
from . import digitalio

import sys, types
#import digitalio

# Create a fake module named "neopixel_write"
m = types.ModuleType("neopixel_write")

def n232_neopixel_write(pin, buf):
    raw_pin = pin._pin
    device = raw_pin.device()
    device.neopixel_write(raw_pin.pin_number(), buf)


m.neopixel_write = n232_neopixel_write


# Force any future `import neopixel_write` to get this module
sys.modules["neopixel_write"] = m


# Required to expose digitalio to the board Pin class
#digitalio.Pin = board.Pin
