
from . import board

class I2C:

    def __init__(self, sda: board.Pin, scl: board.Pin, frequency=100_000):

        if frequency < 10_000:
            raise RuntimeError("Frequency too low")

        self.sda = sda
        self.scl = scl
        self.delay = I2C.frequency_to_delay(frequency)

        if self.sda.device() != self.scl.device():
            raise RuntimeError("SDA and SCL pins MUST be from the same N232 device!!")

        self.device = self.scl.device()

        self.device.i2c_init(sda.pin_number(), scl.pin_number())

    @staticmethod
    def frequency_to_delay(frequency):
        return round((6095544.209215442 / frequency) - 4.0224159402241595)

    def deinit(self):
        self.sda.deinit()
        self.scl.deinit()

    def __exit__(self):
        self.deinit()

    def __enter__(self):
        return self

    def scan(self):
        return self.device.i2c_scan(self.sda.pin_number(), self.scl.pin_number(), self.delay)

    def probe(self, address: int):
        return address in self.scan()

    def try_lock(self):
        return True

    def unlock(self):
        pass

    def writeto(self, address, buffer, *, start=0, end=None, stop=True):
        end = len(buffer) if end is None else end
        self.device.i2c_write(self.sda.pin_number(), self.scl.pin_number(), address, buffer[start:end], stop, self.delay)

    def readfrom_into(self, address, buffer, *, start=0, end=None, stop=True):
        end = len(buffer) if end is None else end
        bytes_to_read = end - start
        read = self.device.i2c_read(self.sda.pin_number(), self.scl.pin_number(), address, bytes_to_read, stop, self.delay)

        for i in range(bytes_to_read):
            buffer[i] = read[i]

    def writeto_then_readfrom(
            self,
            address,
            buffer_out,
            buffer_in,
            *,
            out_start=0,
            out_end=None,
            in_start=0,
            in_end=None,
            stop=True,
    ):
        out_end = len(buffer_out) if out_end is None else out_end
        in_end = len(buffer_in) if in_end is None else in_end
        bytes_to_read = in_end - in_start

        read = self.device.i2c_write_read(self.sda.pin_number(), self.scl.pin_number(), address, buffer_out[out_start:out_end], bytes_to_read, stop, self.delay)

        for i in range(bytes_to_read):
            buffer_in[i+in_start] = read[i]

class SPI:

    def __init__(self, clock: board.Pin, mosi: board.Pin, miso: board.Pin):
        if len({clock.device(), mosi.device(), miso.device()}) != 1:
            raise RuntimeError("All SPI pins must come from the same N232 board")

        self.clock = clock
        self.mosi = mosi
        self.miso = miso

        self.device = self.clock.device()

        self.polarity = 0
        self.phase = 0
        self.nop_delay = SPI._baudrate_to_nop_delay(100_000)

        self.device.spi_init(self.clock.pin_number(), self.mosi.pin_number(), self.miso.pin_number())

    def configure(self, baudrate=100_000, polarity=0, phase=0, bits=8):
        if bits != 8:
            raise RuntimeError("Only 8-bits are supported at this time. Todo: support arbitrary bit widths up to 32-bit")

        if baudrate > 3_100_000:
            raise RuntimeError("Baud rates of more than 3_100_000 are not supported")

        if polarity != 0 and polarity != 1:
            raise RuntimeError("Polarity must be either 0 or 1")

        if phase != 0 and phase != 1:
            raise RuntimeError("Phase must be either 0 or 1")

        self.nop_delay = SPI._baudrate_to_nop_delay(baudrate)
        self.polarity = polarity
        self.phase = phase

    # SPI is implemented using NOP delays. These delays allow lower than 3MHz frequencies and are calculated using this equation
    @staticmethod
    def _baudrate_to_nop_delay(baud):
        return int((1 / baud - 3.3E-7) / 1.10E-7)

    # Combine the polarity and phase into a single number, the SPI mode
    def mode(self):
        return (self.polarity << 1) | self.phase

    def deinit(self):
        self.clock.deinit()
        self.mosi.deinit()
        self.miso.deinit()

    def __exit__(self):
        self.deinit()

    def __enter__(self):
        return self

    @property
    def frequency(self):
        return 1 / (3.3E-7 + self.nop_delay * 1.1E-7)

    def readinto(self, buf, start = 0, end=None, write_value=0):
        end = len(buf) if end is None else end
        self.device.spi_read(self.clock.pin_number(), self.mosi.pin_number(), self.miso.pin_number(), memoryview(buf)[start:end], self.mode(), self.nop_delay, write_value)

    def write(self, buf, start = 0, end=None):
        end = len(buf) if end is None else end
        self.device.spi_write(self.clock.pin_number(), self.mosi.pin_number(), self.miso.pin_number(), buf[start:end], self.mode(), self.nop_delay)

    def write_readinto(self, buffer_out, buffer_in, out_start=0, out_end=None, in_start=0, in_end=None):
        out_end = len(buffer_out) if out_end is None else out_end
        in_end = len(buffer_in) if in_end is None else in_end

        out_buffer = memoryview(buffer_out)[out_start:out_end]
        in_buffer = memoryview(buffer_in)[in_start:in_end]

        self.device.spi_write_read(self.clock.pin_number(), self.mosi.pin_number(), self.miso.pin_number(), out_buffer, in_buffer, self.mode(), self.nop_delay)

    def try_lock(self):
        return True

    def unlock(self):
        pass

class UART:
    def __init__(self, tx, rx):
        raise RuntimeError("Unimplemented")