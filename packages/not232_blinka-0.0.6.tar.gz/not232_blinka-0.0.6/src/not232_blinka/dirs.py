
from . import n232

class Directories:

    def __init__(self, n232_device: n232.N232, path = "/"):
        self.device = n232_device
        self._closed = True
        self.dh = self.device.flash_dir_open(path)
        self._closed = False

    def __iter__(self):
        return self

    def __next__(self):
        node = self.device.flash_dir_read(self.dh)
        if node is None:
            raise StopIteration

        # Skip the . and .. entries
        if node[2] == "." or node[2] == "..":
            return next(self)

        return node

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

    def close(self):
        if not self._closed:
            self.device.flash_dir_close(self.dh)
            self._closed = True