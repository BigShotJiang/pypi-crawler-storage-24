from . import board

class PWMOut:

    def __init__(self, pin: board.Pin, *, duty_cycle: int = 0, frequency: int = 37_500, variable_frequency: bool = False):

        if frequency != 37_500:
            raise RuntimeError("Only 37.5KHz PWM is supported")

        if variable_frequency:
            raise RuntimeError("Variable frequency PWM is not supported")

        self._pin = pin
        self._duty_cycle = duty_cycle

        self._pin.device().pwm_init(pin.pin_number())

        self._pin.device().pwm_duty(pin.pin_number(), duty_cycle >> 8)

    def deinit(self):
        self._pin.deinit()

    def __exit__(self):
        self.deinit()

    def __enter__(self):
        return self

    @property
    def duty_cycle(self):
        """Read the ADC and return the value"""
        return self._duty_cycle

    # pylint: disable=no-self-use
    @duty_cycle.setter
    def duty_cycle(self, value):
        self._pin.device().pwm_duty(self._pin.pin_number(), value >> 8)
        self._duty_cycle = value

