import struct
from . import board
import sys
import glob
import serial

# Source - https://stackoverflow.com/a/14224477
# Posted by tfeldmann, modified by community. See post 'Timeline' for change history
# Retrieved 2026-03-03, License - CC BY-SA 3.0
# Modified to exclude any port that is not connected to an N232 device
def n232_ports():
    """ Lists serial port names

        :raises EnvironmentError:
            On unsupported or unknown platforms
        :returns:
            A list of the serial ports available on the system
    """
    if sys.platform.startswith('win'):
        ports = ['COM%s' % (i + 1) for i in range(256)]
    elif sys.platform.startswith('linux') or sys.platform.startswith('cygwin'):
        # this excludes your current terminal "/dev/tty"
        ports = glob.glob('/dev/tty[A-Za-z]*')
    elif sys.platform.startswith('darwin'):
        ports = glob.glob('/dev/tty.*')
    else:
        raise EnvironmentError('Unsupported platform')

    result = []
    for port in ports:
        try:
            n = N232(port, read_timeout=0.1)
            if n.ping():
                result.append([port, n.identify()])
        except (OSError, serial.SerialException, struct.error):
            pass
    return result



class N232:


    PINS = ["A0", "A1", "A2", "A3", "A4", "A5", "A6", "A7",
            "D0", "D1", "D2", "D3", "D4", "D5", "D6", "D7",
            "F0", "F1", "F2", "F3"]

    PING = 0
    IDENTIFY = 1
    RUN = 2

    OUT_PP = 20
    OUT_OD = 21
    IN_FLOATING = 22
    IN_PU = 23
    IN_PD = 24

    SET_PIN = 30
    CLEAR_PIN = 31
    READ_PIN = 32

    PWM_INIT = 119
    PWM_DUTY = 120

    ADC_INIT = 121
    ADC_READ = 122
    ADC_TKEY_READ = 123

    I2C_INIT = 140
    I2C_SCAN = 141
    I2C_READ = 142
    I2C_WRITE = 143
    I2C_WRITE_READ = 144

    PULSEIO_IN_CLEAR = 151
    PULSEIO_IN_STOP = 152
    PULSEIO_IN_RESUME = 153
    PULSEIO_IN_READ = 154

    PULSEIO_OUT_SEND = 160

    NEOPIXEL_WRITE = 170
    BUILT_IN_WS_WRITE = 175

    OW_RESET = 180
    OW_WRITE_0 = 181
    OW_WRITE_1 = 182
    OW_READ = 183

    SPI_INIT = 190
    SPI_READ = 191
    SPI_WRITE = 192
    SPI_WRITE_READ = 193

    FLASH_REMOVE = 235
    FLASH_MOVE = 236
    FLASH_FILE_INFO = 237
    FLASH_FILE_OPEN = 238
    FLASH_FILE_CLOSE = 239
    FLASH_FILE_READ = 240
    FLASH_FILE_WRITE = 241
    FLASH_FILE_SEEK = 242
    FLASH_FILE_TRUNCATE = 2343
    FLASH_MKDIR = 244
    FLASH_DIR_OPEN = 245
    FLASH_DIR_CLOSE = 246
    FLASH_DIR_READ = 247

    def __init__(self, port=None, read_timeout=None):

        if port is None:
            n232s = n232_ports()

            if len(n232s) == 0:
                raise RuntimeError("No free N232 devices detected")
            elif len(n232s) == 1:
                port = n232s[0][0]
            else:
                raise RuntimeError("More than one N232 device detected. (Todo: implement ID based criteria for choosing n232 devices")


        self._serial = serial.Serial(port, baudrate=115200, timeout=read_timeout)


    def __getattr__(self, item):
        if item in N232.PINS:
            index = N232.PINS.index(item)
            return board.Pin([index, self])

    def __setattr__(self, key, value):
        if key in N232.PINS:
            raise RuntimeError("Cannot assign pins")
        object.__setattr__(self, key, value)

    def send_command(self, command: int, data: bytes = bytes()):
        self._serial.write(bytes([command]))

        if len(data) != 0:
            self._serial.write(data)

        self._serial.flush()

    def receive_u32(self):
        return struct.unpack("<I", self._serial.read(4))[0]

    def receive_i32(self):
        return struct.unpack("<i", self._serial.read(4))[0]

    def send_u32(self, value):
        self._serial.write(struct.pack("<I", value))

    def send_string(self, s: str):
        self.send_u32(len(s))
        self._serial.write(s.encode("utf-8"))

    def receive_string(self) -> str:
        len = self.receive_u32()
        return self._serial.read(len).decode("utf-8")

    def receive_response(self, l: int):
        return self._serial.read(l)

    def ping(self):
        self.send_command(N232.PING)

        resp = self.receive_u32()

        return resp == 0

    def identify(self):
        self.send_command(N232.IDENTIFY)

        response = self.receive_response(20)

        return response[12:].decode(encoding="utf-8") + "_" + ''.join(f"{n:02X}" for n in response[:12])

    def output_push_pull(self, pin_number):
        self.send_command(N232.OUT_PP, bytes([pin_number]))

    def output_open_drain(self, pin_number):
        self.send_command(N232.OUT_OD, bytes([pin_number]))

    def input_floating(self, pin_number):
        self.send_command(N232.IN_FLOATING, bytes([pin_number]))

    def input_pull_up(self, pin_number):
        self.send_command(N232.IN_PU, bytes([pin_number]))

    def input_pull_down(self, pin_number):
        self.send_command(N232.IN_PD, bytes([pin_number]))

    def set_pin(self, pin_number):
        self.send_command(N232.SET_PIN, bytes([pin_number]))

    def clear_pin(self, pin_number):
        self.send_command(N232.CLEAR_PIN, bytes([pin_number]))

    def read_pin(self, pin_number):
        self.send_command(N232.READ_PIN, bytes([pin_number]))

        return self.receive_response(1)[0] != 0

    def pwm_init(self, pin_number):
        if pin_number < 0 or (4 <= pin_number <= 5) or (12 <= pin_number <= 15) or pin_number > 17:
            raise RuntimeError(f"Pin number must be 0-3 or 6-11")

        self.send_command(N232.PWM_INIT, bytes([pin_number]))

    def pwm_duty(self, pin_number, duty):
        if pin_number < 0 or (4 <= pin_number <= 5) or (12 <= pin_number <= 15) or pin_number > 17:
            raise RuntimeError(f"Pin number must be 0-3 or 6-11")
        self.send_command(N232.PWM_DUTY, bytes([pin_number, duty]))


    def adc_init(self, pin_number):
        if pin_number < 0 or (8 <= pin_number <= 15) or pin_number > 17:
            raise RuntimeError(f"Pin {pin_number} is not an ADC pin. Choose A0-A7 or F0, F1")

        self.send_command(N232.ADC_INIT, bytes([pin_number]))

    def adc_read(self, pin_number):
        if pin_number < 0 or (8 <= pin_number <= 15) or pin_number > 17:
            raise RuntimeError(f"Pin {pin_number} is not an ADC pin. Choose A0-A7 or F0, F1")

        self.send_command(N232.ADC_READ, bytes([pin_number]))

        return self.receive_u32()

    def adc_tkey_read(self, pin_number):
        if pin_number < 0 or (8 <= pin_number <= 15) or pin_number > 17:
            raise RuntimeError(f"Pin {pin_number} is not an ADC pin. Choose A0-A7 or F0, F1")

        self.send_command(N232.ADC_TKEY_READ, bytes([pin_number]))

        return self.receive_u32()


    def i2c_init(self, sda, scl):
        self.send_command(N232.I2C_INIT, bytes([sda, scl]))

    def i2c_scan(self, sda, scl, delay):
        self.send_command(N232.I2C_SCAN, bytes([sda, scl]))

        self.send_u32(delay)

        byte = 1

        scan = []

        while byte != 0:
            byte = self._serial.read(1)[0]

            if byte == 0:
                break

            scan.append(byte)


        return scan

    def i2c_write_read(self, sda, scl, address: int, write_data: bytes, read_count: int, stop, delay):

        self.send_command(N232.I2C_WRITE_READ, bytes([sda, scl]))

        self._serial.write(bytes([int(address & 0xFF)]))

        self._serial.write(struct.pack("<I", len(write_data)))

        self._serial.write(write_data)

        self._serial.write(struct.pack("<I", read_count))

        self._serial.write(bytes([int(stop)])) # serial.serialutil.SerialTimeoutException: Write timeout

        self.send_u32(delay)

        return self._serial.read(read_count)

    def i2c_write(self, sda, scl, address: int, write_data, stop, delay):

        self.send_command(N232.I2C_WRITE, bytes([sda, scl]))

        self._serial.write(bytes([int(address & 0xFF)]))

        self._serial.write(struct.pack("<I", len(write_data)))

        self._serial.write(write_data)

        self._serial.write(bytes([int(stop)]))

        self.send_u32(delay)

    def i2c_read(self, sda, scl, address: int, read_count: int, stop, delay):

        self.send_command(N232.I2C_READ, bytes([sda, scl]))

        self._serial.write(bytes([int(address & 0xFF)]))

        self._serial.write(struct.pack("<I", read_count))

        self._serial.write(bytes([int(stop)]))

        self.send_u32(delay)

        return self._serial.read(read_count)

    def pulseio_clear(self):
        self.send_command(N232.PULSEIO_IN_CLEAR)

    def pulseio_resume(self, pin, trigger_duration: int = 0):
        if pin > 15:
            raise RuntimeError("pulse io in only available on A0-A7 and D0-D7")
        self.send_command(N232.PULSEIO_IN_RESUME, bytes([pin]))

        self._serial.write(struct.pack("<I", trigger_duration))

    def pulseio_stop(self, pin):
        if pin > 15:
            raise RuntimeError("pulse io in only available on A0-A7 and D0-D7")
        self.send_command(N232.PULSEIO_IN_STOP, bytes([pin]))

    def pulseio_read(self, len):
        self.send_command(N232.PULSEIO_IN_READ)

        self._serial.write(struct.pack("<I", len))

        actual_len = self.receive_u32()

        data = []

        for _ in range(actual_len):
            data.append(self.receive_u32())

        return data

    def pulseio_out(self, pin, duty, pulses):
        self.send_command(N232.PULSEIO_OUT_SEND, bytes([pin]))

        self._serial.write(struct.pack("<I", duty))

        self._serial.write(struct.pack("<I", len(pulses)))

        for pulse in pulses:
            self._serial.write(struct.pack("<I", pulse))

    def neopixel_write(self, pin, data):
        self.send_command(N232.NEOPIXEL_WRITE, bytes([pin])) # serial.serialutil.SerialTimeoutException: Write timeout

        self._serial.write(struct.pack("<I", len(data)))

        self._serial.write(data)

    def built_in_neopixel(self, red, green, blue):
        self.send_command(N232.BUILT_IN_WS_WRITE, bytes([green, red, blue]))


    def ow_reset(self, pin):
        self.send_command(N232.OW_RESET, bytes([pin]))

        return self.receive_u32()

    def ow_write(self, pin, value):
        if value:
            self.send_command(N232.OW_WRITE_1, bytes([pin]))
        else:
            self.send_command(N232.OW_WRITE_0, bytes([pin]))

    def ow_read(self, pin):
        self.send_command(N232.OW_READ, bytes([pin]))

        return self.receive_u32()

    def spi_init(self, clock, mosi, miso):
        self.send_command(N232.SPI_INIT, bytes([clock, mosi, miso]))

    # REad enough bytes from the SPI to fill the buffer
    def spi_read(self, clock, mosi, miso, buffer, mode = 0, delay = 0, write_value = 0):
        self.send_command(N232.SPI_READ, bytes([clock, mosi, miso, mode, write_value]))

        self.send_u32(delay)

        self.send_u32(len(buffer))

        for i in range(len(buffer)):
            buffer[i] = self._serial.read(1)[0]

    # Write all bytes from the buffer to the SPI
    def spi_write(self, clock, mosi, miso, buffer, mode = 0, delay = 0):
        self.send_command(N232.SPI_WRITE, bytes([clock, mosi, miso, mode]))

        self.send_u32(delay)

        self.send_u32(len(buffer))

        self._serial.write(buffer)

    def spi_write_read(self, clock, mosi, miso, out_buffer, in_buffer, mode = 0, delay = 0):

        if len(in_buffer) != len(out_buffer):
            raise RuntimeError("In and Out buffers must be the same length")
        else:
            buffer_len = len(in_buffer)

        self.send_command(N232.SPI_WRITE_READ, bytes([clock, mosi, miso, mode]))

        self.send_u32(delay)

        self.send_u32(buffer_len)

        self._serial.write(out_buffer)

        for i in range(buffer_len):
            in_buffer[i] = self._serial.read(1)[0]

    @staticmethod
    def flashfs_unwrap_return(code):
        if code >= 0:
            return code

        if code == -5:
            raise RuntimeError("LFS_ERR_IO - Error during device operation")
        elif code == -84:
            raise RuntimeError("LFS_ERR_CORRUPT - Corrupted")
        elif code == -2:
            raise RuntimeError("LFS_ERR_NOENT - No directory entry")
        elif code == -17:
            raise RuntimeError("LFS_ERR_EXIST - Entry already exists")
        elif code == -20:
            raise RuntimeError("LFS_ERR_NOTDIR - Entry is not a dir")
        elif code == -21:
            raise RuntimeError("LFS_ERR_ISDIR - Entry is a dir")
        elif code == -39:
            raise RuntimeError("LFS_ERR_NOTEMPTY - Dir is not empty")
        elif code == -9:
            raise RuntimeError("LFS_ERR_BADF - Bad file number")
        elif code == -27:
            raise RuntimeError("LFS_ERR_FBIG - File too large")
        elif code == -22:
            raise RuntimeError("LFS_ERR_INVAL - Invalid parameter")
        elif code == -28:
            raise RuntimeError("LFS_ERR_NOSPC - No space left on device")
        elif code == -12:
            raise RuntimeError("LFS_ERR_NOMEM - No more memory available")
        elif code == -61:
            raise RuntimeError("LFS_ERR_NOATTR - No data/attr available")
        elif code == -36:
            raise RuntimeError("LFS_ERR_NAMETOOLONG - File name too long")
        else:
            raise RuntimeError("Misc error")




    def flashfs_remove(self, path):
        self.send_command(N232.FLASH_REMOVE)

        self.send_string(path)

        flashfs_code = self.receive_i32()

        return N232.flashfs_unwrap_return(flashfs_code)

    def flashfs_move(self, path_from, path_to):
        self.send_command(N232.FLASH_MOVE)

        self.send_string(path_from)
        self.send_string(path_to)

        flashfs_code = self.receive_i32()

        return N232.flashfs_unwrap_return(flashfs_code)

    def flashfs_file_info(self):
        raise RuntimeError("Unimplemented")

    def flashfs_file_open(self, path, flags):
        self.send_command(N232.FLASH_FILE_OPEN)

        self.send_string(path)

        self.send_u32(flags)

        file_handle = self.receive_i32()

        return N232.flashfs_unwrap_return(file_handle)

    def flashfs_file_close(self, file_handle):
        self.send_command(N232.FLASH_FILE_CLOSE)

        self.send_u32(file_handle)

        flashfs_code = self.receive_i32()

        return N232.flashfs_unwrap_return(flashfs_code)

    def flash_file_read(self, file_handle, length):
        self.send_command(N232.FLASH_FILE_READ)

        self.send_u32(file_handle)

        self.send_u32(length)

        flashfs_code = self.receive_i32()

        N232.flashfs_unwrap_return(flashfs_code)

        return self._serial.read(length)

    def flash_file_write(self, file_handle, data):
        self.send_command(N232.FLASH_FILE_WRITE)

        self.send_u32(file_handle)

        self.send_u32(len(data))

        self._serial.write(data)

        flashfs_code = self.receive_i32()

        return N232.flashfs_unwrap_return(flashfs_code)

    def flash_file_seek(self, file_handle, offset, whence):
        self.send_command(N232.FLASH_FILE_SEEK)

        self.send_u32(file_handle)

        self.send_u32(offset)

        self.send_u32(whence)

        flashfs_code = self.receive_i32()

        return N232.flashfs_unwrap_return(flashfs_code)

    def flash_file_truncate(self, file_handle, size):
        self.send_command(N232.FLASH_FILE_TRUNCATE)

        self.send_u32(file_handle)

        self.send_u32(size)

        flashfs_code = self.receive_i32()

        return N232.flashfs_unwrap_return(flashfs_code)

    def flash_mkdir(self, path):
        self.send_command(N232.FLASH_MKDIR)

        self.send_string(path)

        flashfs_code = self.receive_i32()

        return N232.flashfs_unwrap_return(flashfs_code)

    def flash_dir_open(self, path):
        self.send_command(N232.FLASH_DIR_OPEN)

        self.send_string(path)

        dir_handle = self.receive_i32()

        return N232.flashfs_unwrap_return(dir_handle)

    def flash_dir_close(self, dir_handle):
        self.send_command(N232.FLASH_DIR_CLOSE)

        self.send_u32(dir_handle)

        flashfs_code = self.receive_i32()

        return N232.flashfs_unwrap_return(flashfs_code)

    def flash_dir_read(self, dir_handle):
        self.send_command(N232.FLASH_DIR_READ)

        self.send_u32(dir_handle)

        flashfs_code = self.receive_i32()

        node_type = self.receive_u32()

        node_size = self.receive_u32()

        node_path = self.receive_string()

        cleaned_code = N232.flashfs_unwrap_return(flashfs_code)

        if cleaned_code == 0:
            return None # End of directory
        else:
            return node_type, node_size, node_path






