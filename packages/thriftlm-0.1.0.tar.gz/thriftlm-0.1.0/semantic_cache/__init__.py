"""
semantic_cache — A semantic caching layer for LLM applications.

Stop paying for the same LLM call twice just because users phrased it differently.
"""

from semantic_cache.cache import SemanticCache
from semantic_cache.config import Config

__all__ = ["SemanticCache", "Config"]
__version__ = "0.1.0"
