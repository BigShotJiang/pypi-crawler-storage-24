"""
Backend implementations for SemanticCache.

- SupabaseBackend: pgvector-based vector similarity store.
- RedisBackend: Upstash Redis fast cache layer.
"""

from semantic_cache.backends.supabase_backend import SupabaseBackend
from semantic_cache.backends.redis_backend import RedisBackend

__all__ = ["SupabaseBackend", "RedisBackend"]
