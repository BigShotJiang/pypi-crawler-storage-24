"""
Native integrations for SemanticCache.

- langgraph: wrap() helper for LangGraph graphs.
"""

from semantic_cache.integrations.langgraph import wrap

__all__ = ["wrap"]
