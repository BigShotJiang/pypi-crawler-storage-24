# First 10 Customers Plan

## Goal

Get the first 10 real users to try FinStack, then convert the first 1-3 into paying early-access users for FinStack Brief.

This plan is not about vanity metrics.
It is about:

- first real usage
- first useful feedback
- first manual onboarding
- first payment proof

## 1. What Success Looks Like

### Good outcome

- 10 real users try the product
- 3 users respond with useful feedback
- 1 user asks for a sample brief
- 1 user converts to paid early access

### Better outcome

- 10 real users try it
- 5 users respond
- 2-3 users request sample briefs
- 2 users convert to paid early access

## 2. Who The First 10 Should Be

Do not choose random people.

Pick from:

- 3 serious retail investors
- 3 market creators or community admins
- 2 people who actively use Claude / Cursor / MCP tools
- 2 finance/research-oriented contacts

The first 10 users should be:

- accessible
- likely to reply
- likely to give honest feedback
- close enough to the target user

## 3. Where To Find Them

Start from:

- your own network
- LinkedIn contacts
- WhatsApp contacts
- Telegram communities you already know
- X followers / mutuals
- creator connections

Do not start by spamming strangers.

## 4. What To Send

Use a short first message:

```text
Built and launched FinStack MCP.

It is an India-first MCP engine for NSE/BSE, fundamentals, analytics, and market research workflows.

I’m now testing the next layer on top: a daily Indian market brief.

Would you be open to trying it and giving honest feedback?
GitHub: https://github.com/finstacklabs/finstack-mcp
Site: https://finstacklabs.github.io/
```

## 5. What To Ask For

Do not ask:

- “Please star”
- “Please support”
- “Please share blindly”

Ask:

- will you try this?
- what confused you?
- would you want this as a daily brief?
- what delivery format would matter to you?

## 6. First User Flow

### Step 1

Send launch post or direct message.

### Step 2

If they reply with interest, use:

- [INTEREST_TO_PAYMENT.md](INTEREST_TO_PAYMENT.md)

### Step 3

Collect:

- use case
- watchlist
- preferred format
- frequency

### Step 4

Send a sample brief manually.

### Step 5

Ask:

- what was useful
- what was unnecessary
- what they would pay for

### Step 6

If there is real interest, offer monthly early access.

## 7. Pricing For First Users

Keep it simple.

Suggested:

- personal early access: `INR 499-999/month`
- creator / desk: `INR 2,999+`

Do not overcomplicate with many tiers.

## 8. 7-Day Plan

### Day 1

- publish GitHub release
- post on LinkedIn
- post on X
- send 5 direct messages

### Day 2

- reply to comments
- send 5 more direct messages
- note all confusion points

### Day 3

- identify 2 strongest leads
- ask for watchlist + format
- prepare sample briefs

### Day 4

- send the sample briefs
- ask for blunt feedback

### Day 5

- follow up with strongest lead
- ask whether they want daily access

### Day 6

- offer early paid access to the best-fit lead

### Day 7

- review:
  - number of people contacted
  - replies
  - sample requests
  - likely conversions

## 9. What To Track

Maintain a simple list:

- name
- source
- use case
- response status
- watchlist received or not
- sample sent or not
- paid interest yes/no

Do not rely on memory.

## 10. What To Learn From The First 10

You need answers to these:

1. what format do users prefer?
2. what part of the brief matters most?
3. who is most likely to pay first?
4. what wording makes them understand the value fastest?
5. what part of the product still feels weak?

## 11. Biggest Mistakes To Avoid

- waiting for “perfect” before talking to users
- sending long, confusing first messages
- pitching generic AI finance language
- chasing stars instead of feedback
- building more before learning what users want

## 12. Final Rule

The first 10 users matter more than the next 10 features.
