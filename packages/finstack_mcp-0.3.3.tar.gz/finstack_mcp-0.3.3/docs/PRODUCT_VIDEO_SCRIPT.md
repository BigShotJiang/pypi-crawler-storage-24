# FinStack MCP — YouTube Video Script
# Channel: SpawnAgent

---

## OVERVIEW

**Video type:** Product demo + tutorial
**Target length:** 3 minutes 30 seconds to 4 minutes
**Tone:** Founder showing off something real. Calm, confident, no hype.
**Hook style:** Problem-first. Not "I built a tool" — but "Here's what Indian investors can't do with AI today, and I fixed it."

---

## WHAT THIS VIDEO MUST DO

1. Hook the viewer in the first 8 seconds
2. Show a real pain point every Indian stock trader has
3. Prove FinStack solves it — live, no fake demos
4. Make it dead simple to install (one pip command)
5. End with a clear CTA — try it, star it, subscribe

---

## VIDEO LENGTH

- Target: **3 minutes 30 seconds to 4 minutes**
- Hard cap: 4 minutes 30 seconds (retention drops after this for tech demos)

---

## BEFORE YOU RECORD — SETUP CHECKLIST

Open all of these before hitting record. Do not scramble during recording.

- [ ] Browser tab 1: GitHub repo
- [ ] Browser tab 2: PyPI page `https://pypi.org/project/finstack-mcp/`
- [ ] Browser tab 3: Landing page
- [ ] Claude Desktop — logged in, FinStack removed from config (blank slate)
- [ ] Terminal — open, `fintech` env active, ready at finstack-mcp folder
- [ ] Terminal font size: **18px minimum** — text must be readable on YouTube
- [ ] Screen resolution: 1920×1080
- [ ] Mic: tested, no background noise

**Remove FinStack from Claude config before recording:**

Inside Claude Desktop → click `+` → Connectors → toggle FinStack OFF
Then go to: `+` → Connectors → Edit Config → set to:
```json
{ "mcpServers": {} }
```
Save. Fully quit Claude Desktop from system tray. Do not reopen until Scene 6.

---

## FULL SCRIPT — WORD FOR WORD

---

### SCENE 1 — HOOK (0:00 to 0:12)

**Screen:** Black screen or blurred landing page. Nothing distracting.

**On-screen text:** `"Every Indian investor using AI hits the same wall."`

**YOU SAY:**
> "If you've tried asking ChatGPT or Claude about Reliance, TCS, or HDFC Bank — you already know the problem.
> The data is outdated. It doesn't know today's price. It doesn't know this quarter's results.
> And it definitely doesn't know what's happening on NSE right now."

---

### SCENE 2 — INTRODUCE THE PRODUCT (0:12 to 0:28)

**Screen:** Landing page — slow scroll from top hero to features section.

**YOU SAY:**
> "So I built FinStack MCP. It's a financial data engine that plugs live Indian market data directly into Claude.
> NSE, BSE, Nifty, mutual funds, earnings, corporate actions — all of it, free, no API key needed."

**On-screen caption:** `FinStack MCP — India-first financial data for AI`

---

### SCENE 3 — SHOW IT'S REAL (0:28 to 0:45)

**Screen:** Browser — show GitHub repo (star count visible), then PyPI page (version + install count visible).

**YOU SAY:**
> "This is not a side project or a concept. The code is live on GitHub. The package is on PyPI.
> You can install it right now — one command."

---

### SCENE 4 — INSTALL (0:45 to 1:05)

**Screen:** Terminal — type and run this live:

```powershell
pip install finstack-mcp
```

Do not cut during install. Let the viewer see it actually happen.

**YOU SAY:**
> "One pip install. No account. No API key. No credit card.
> It uses Yahoo Finance and AMFI under the hood — both completely free."

**On-screen caption:** `pip install finstack-mcp`

---

### SCENE 5 — DAILY BRIEF DEMO (1:05 to 1:50)

**Screen:** Terminal — run:

```powershell
finstack-brief --watchlist RELIANCE,TCS,HDFCBANK --output text
```

Wait for output. Then run:

```powershell
finstack-brief --watchlist RELIANCE,TCS,HDFCBANK --output telegram
```

**YOU SAY:**
> "This is the daily brief feature. Give it a watchlist — I'm using Reliance, TCS, HDFC Bank —
> and it generates a full market brief. Plain text, Telegram-ready, or email format."

*(while output appears)*
> "Live price, change, 52-week range, quarterly results, upcoming earnings, corporate actions.
> Everything in one brief, generated locally on your machine. No internet subscription. No dashboard login."

**On-screen caption:** `Plain text · Telegram · Email — your choice`

---

### SCENE 6 — ADD TO CLAUDE DESKTOP (1:50 to 2:25)

**Screen:** Claude Desktop → click `+` → Connectors → Edit Config

**YOU SAY:**
> "Now the Claude integration. This is what makes it powerful.
> Inside Claude Desktop, click the plus button, go to Connectors, then Edit Config.
> It opens a JSON file — you just add FinStack here."

Show the config file open. Type or paste:

```json
{
  "mcpServers": {
    "finstack": {
      "command": "python",
      "args": ["-m", "finstack.server"]
    }
  }
}
```

**YOU SAY:**
> "Save the file — that's the entire setup."

**On-screen caption:** `+ → Connectors → Edit Config → paste → save`

---

### SCENE 7 — RESTART CLAUDE (2:25 to 2:40)

**Screen:** Right-click Claude icon in system tray → Quit → Reopen Claude Desktop.

**YOU SAY:**
> "Quit Claude from the system tray — not just close the window — and reopen it.
> Takes ten seconds. When it loads, FinStack is live inside Claude."

---

### SCENE 8 — LIVE DEMO IN CLAUDE (2:40 to 3:35)

**Screen:** Claude Desktop — new chat open. Type slowly so viewer can read.

**Prompt 1 — type and send:**
```
Give me a market brief for RELIANCE, TCS, and HDFCBANK.
```

Do not cut while waiting. Let viewer see Claude calling FinStack tools.

**YOU SAY (while it loads):**
> "Watch the top of Claude's response — you can see it's using the FinStack integration to pull live data."

*(after response appears)*
> "Live price, fundamentals, sector context — and Claude can reason over it, summarize it, compare it.
> This is what you cannot do with a basic stock app or ChatGPT."

**Prompt 2 — type and send:**
```
Compare TCS, Infosys, and Wipro on margins and valuation.
```

*(while it loads)*
> "One more — a comparison query. This is where it gets actually useful for research."

*(after response)*
> "Side by side. P/E, margins, growth. Pulled live. Not copied from a website."

---

### SCENE 9 — CLOSE AND CTA (3:35 to 3:55)

**Screen:** Landing page visible. GitHub repo tab in background.

**YOU SAY:**
> "FinStack MCP is open source. The engine is free. The code is on GitHub.
> If you're building with Claude, using Cursor, or just want better financial data in your AI workflows — install it, try it, and star the repo if it helps."

*(one second pause)*

> "Link is in the description. Subscribe to SpawnAgent for more builds like this."

**On-screen text (hold for 5 seconds):**
```
pip install finstack-mcp
github.com/finstacklabs/finstack-mcp
```

**On-screen caption:** `Open source · Free · India-first`

---

## THUMBNAIL

Design one thumbnail. Do not use YouTube auto-thumbnail.

**Layout:**
- Left: Screenshot of Claude showing Indian stock data response
- Right: Two lines of bold text:
  - **`Live NSE Data`** (large, white)
  - `inside Claude` (smaller, light grey)
- Bottom strip: `FinStack MCP · Free · Open Source`
- Background: Dark navy (#0d1117) or your landing page cream

**Rules:** White text only. No pink. No rainbow gradients.

---

## TITLE OPTIONS

1. `I gave Claude live NSE data — for free (FinStack MCP)`
2. `How I connected Claude to Indian stock markets (no API key)`
3. `FinStack MCP: Live NSE/BSE data inside Claude Desktop`

**Use title 1.** It's curiosity-first, specific, and works for both Indian and global audiences.

---

## VIDEO DESCRIPTION (copy-paste ready)

```
I built FinStack MCP — a free, open-source financial data engine that connects Claude Desktop to live Indian market data.

NSE, BSE, Nifty, mutual funds, earnings, corporate actions — all of it. No API key. No account. One pip install.

🔗 Install: pip install finstack-mcp
📦 GitHub: https://github.com/finstacklabs/finstack-mcp
📄 PyPI: https://pypi.org/project/finstack-mcp/

What it includes:
→ Live NSE/BSE stock quotes
→ Nifty 50, Sensex, Bank Nifty index data
→ Mutual fund NAV (AMFI)
→ Earnings calendar + corporate actions
→ Daily market brief (text, Telegram, email format)
→ 39 tools total — all free tier

Works with: Claude Desktop, Cursor, and any MCP-compatible AI client.

Timestamps:
0:00 — The problem with AI + Indian market data
0:12 — What FinStack MCP is
0:28 — Live on GitHub + PyPI
0:45 — Install in one command
1:05 — Daily brief demo
1:50 — Claude Desktop setup
2:40 — Live demo inside Claude
3:35 — Where to get it

#MCP #ClaudeDesktop #IndianStockMarket #NSE #FinStack #OpenSource #AITools #FinTech
```

---

## RECORD IN THIS ORDER

Do NOT record left to right. Record like this:

1. **Terminal scenes** (install + brief) — record first while fresh
2. **Claude Desktop setup + demo** — record second
3. **GitHub + PyPI + landing page** browser scrolls — record third
4. **Hook scene** (Scene 1) — record LAST after you know the full video
5. **Voiceover** — add after all screen recording is done

This way if anything breaks mid-demo, you haven't wasted your hook.

---

## ONE-LINE PITCH

```
FinStack MCP gives Claude Desktop live access to NSE, BSE, Nifty, mutual funds, and Indian market data — free, open source, one pip install.
```
