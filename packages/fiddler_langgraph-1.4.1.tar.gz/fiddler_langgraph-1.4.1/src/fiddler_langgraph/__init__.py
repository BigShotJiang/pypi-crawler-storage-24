"""Fiddler LangGraph - LangGraph and LangChain instrumentation for Fiddler GenAI observability."""

from importlib.metadata import PackageNotFoundError, version

from fiddler_langgraph.instrumentation import (
    LangGraphInstrumentor,
    add_session_attributes,
    add_span_attributes,
    set_llm_context,
)

# Re-export core symbols so users only need to install fiddler-langgraph
from fiddler_otel import (
    FiddlerChain,
    FiddlerClient,
    FiddlerGeneration,
    FiddlerSpan,
    FiddlerTool,
    get_client,
    get_current_span,
    set_conversation_id,
    trace,
)

try:
    __version__ = version('fiddler-langgraph')
except PackageNotFoundError:
    __version__ = 'unknown'

__all__ = [
    'FiddlerChain',
    'FiddlerClient',
    'FiddlerGeneration',
    'FiddlerSpan',
    'FiddlerTool',
    'LangGraphInstrumentor',
    '__version__',
    'add_session_attributes',
    'add_span_attributes',
    'get_client',
    'get_current_span',
    'set_conversation_id',
    'set_llm_context',
    'trace',
]
