"""Callback handler for LangGraph instrumentation."""

import json
import logging
from collections.abc import Sequence
from typing import Any
from uuid import UUID

from langchain_core.callbacks import BaseCallbackHandler
from langchain_core.documents import Document
from langchain_core.messages import AIMessage, BaseMessage, HumanMessage, SystemMessage, ToolMessage
from langchain_core.outputs import ChatGeneration, LLMResult
from opentelemetry import trace
from opentelemetry.context.context import Context

from fiddler_langgraph.util import _LanggraphJSONEncoder
from fiddler_otel.attributes import (
    _CONVERSATION_ID,
    FIDDLER_METADATA_KEY,
    FIDDLER_USER_SPAN_ATTRIBUTE_TEMPLATE,
    FiddlerSpanAttributes,
    SpanType,
)

logger = logging.getLogger(__name__)


def _get_agent_name(metadata: dict[str, Any]) -> str:
    """Extract the agent name from LangGraph metadata."""
    agent_name = ''
    checkpoint_ns = metadata.get('langgraph_checkpoint_ns', '')
    if checkpoint_ns:
        path = checkpoint_ns.split(':')
        agent_name = path[0]
    return agent_name


def _set_agent_name(span: trace.Span, metadata: dict[str, Any]) -> None:
    """Set the agent name attribute on a span from LangGraph metadata."""
    agent_name = _get_agent_name(metadata)
    span.set_attribute(FiddlerSpanAttributes.AGENT_NAME, agent_name)
    _set_agent_id(span, agent_name)


def _set_agent_id(span: trace.Span, agent_name: str) -> None:
    """Set the agent ID on the span (trace_id:agent_name)."""
    trace_id = format(span.get_span_context().trace_id, '032x')
    agent_id = str(trace_id) + ':' + agent_name
    span.set_attribute(FiddlerSpanAttributes.AGENT_ID, agent_id)


def _stringify_message_content(message: BaseMessage) -> str:
    """Stringify a LangChain message's content."""
    if isinstance(message.content, str):
        return message.content
    return json.dumps(message.content, cls=_LanggraphJSONEncoder)


def _set_model_attributes(span: trace.Span, metadata: dict[str, Any] | None = None) -> None:
    """Set model-related attributes on a span from LangChain metadata.

    :param span: The OTel span to annotate.
    :param metadata: LangChain metadata dict containing ``ls_model_name`` and ``ls_provider``.
    """
    if not metadata:
        return

    ls_model_name = metadata.get('ls_model_name')
    ls_provider = metadata.get('ls_provider')

    if ls_model_name and isinstance(ls_model_name, str) and ls_model_name.strip():
        span.set_attribute(FiddlerSpanAttributes.LLM_REQUEST_MODEL, ls_model_name.strip())

    if ls_provider and isinstance(ls_provider, str) and ls_provider.strip():
        span.set_attribute(FiddlerSpanAttributes.LLM_SYSTEM, ls_provider.strip())


def _set_token_usage_attributes(span: trace.Span, response: LLMResult) -> None:
    """Set token usage attributes on a span from an LLMResult.

    :param span: The OTel span to annotate.
    :param response: The LLM response containing usage metadata.
    """
    try:
        if not response.generations or not response.generations[0]:
            return

        generation = response.generations[0][0]

        if not (
            isinstance(generation, ChatGeneration)
            and hasattr(generation.message, 'usage_metadata')
            and generation.message.usage_metadata
        ):
            return

        usage_metadata = generation.message.usage_metadata

        input_tokens = usage_metadata.get('input_tokens')
        if input_tokens is not None and isinstance(input_tokens, int):
            span.set_attribute(FiddlerSpanAttributes.LLM_TOKEN_COUNT_INPUT, input_tokens)

        output_tokens = usage_metadata.get('output_tokens')
        if output_tokens is not None and isinstance(output_tokens, int):
            span.set_attribute(FiddlerSpanAttributes.LLM_TOKEN_COUNT_OUTPUT, output_tokens)

        total_tokens = usage_metadata.get('total_tokens')
        if total_tokens is not None and isinstance(total_tokens, int):
            span.set_attribute(FiddlerSpanAttributes.LLM_TOKEN_COUNT_TOTAL, total_tokens)
        else:
            if input_tokens is not None and output_tokens is not None:
                span.set_attribute(
                    FiddlerSpanAttributes.LLM_TOKEN_COUNT_TOTAL, input_tokens + output_tokens
                )

    except Exception as e:
        logger.warning('Failed to extract token usage: %s', e)


def _set_tool_definitions(span: trace.Span, kwargs: dict[str, Any]) -> None:
    """Extract and set tool definitions on the span.

    :param span: The OTel span to annotate.
    :param kwargs: Callback kwargs containing ``invocation_params``.
    """
    try:
        invocation_params = kwargs.get('invocation_params', {})
        tools = invocation_params.get('tools')

        if tools and isinstance(tools, list) and len(tools) > 0:
            tool_definitions_json = json.dumps(tools, cls=_LanggraphJSONEncoder)
            span.set_attribute(FiddlerSpanAttributes.TOOL_DEFINITIONS, tool_definitions_json)
    except Exception as e:
        logger.warning('Failed to extract tool definitions: %s', e)


def _convert_message_to_otel_format(message: BaseMessage) -> dict[str, Any]:
    """Convert a LangChain message to OpenTelemetry format.

    :param message: The LangChain message to convert.
    :returns: Message dict in OTel format with ``role`` and ``parts``.
    """
    result: dict[str, Any] = {}

    role_mapping = {'ai': 'assistant', 'human': 'user'}
    result['role'] = role_mapping.get(message.type, message.type)

    parts = []
    content = _stringify_message_content(message)

    if isinstance(message, ToolMessage):
        parts = [
            {
                'type': 'tool_call_response',
                'response': content,
                'id': message.tool_call_id,
            }
        ]
    else:
        if content:
            parts.append({'type': 'text', 'content': content})

        if isinstance(message, AIMessage) and hasattr(message, 'tool_calls') and message.tool_calls:
            for tool_call in message.tool_calls:
                tool_call_part: dict[str, Any] = {
                    'type': 'tool_call',
                    'name': tool_call.get('name', ''),
                }
                if 'id' in tool_call:
                    tool_call_part['id'] = tool_call['id']
                if 'args' in tool_call:
                    tool_call_part['arguments'] = tool_call['args']
                parts.append(tool_call_part)

    result['parts'] = parts

    if isinstance(message, AIMessage) and hasattr(message, 'response_metadata'):
        response_metadata = message.response_metadata
        if response_metadata:
            finish_reason = response_metadata.get('finish_reason')
            if finish_reason:
                result['finish_reason'] = finish_reason

    return result


class _CallbackHandler(BaseCallbackHandler):
    """A LangChain callback handler that creates OpenTelemetry spans for Fiddler.

    Listens to LangGraph events and creates corresponding spans to trace the
    execution of chains, tools, and language models.
    """

    def __init__(self, tracer: trace.Tracer):
        """Initialise the callback handler.

        :param tracer: The OTel tracer to use for creating spans.
        """
        self._active_spans: dict[UUID, trace.Span] = {}
        self._tracer = tracer
        self._root_span: trace.Span | None = None
        # Isolated context prevents ambient global span inheritance
        self._context = Context()

    def _start_new_trace(self, trace_name: str) -> trace.Span:
        """Start a new root span for the trace."""
        span = self._tracer.start_span(
            trace_name, kind=trace.SpanKind.CLIENT, context=self._context
        )
        span.set_attribute(FiddlerSpanAttributes.TYPE, SpanType.CHAIN)
        span.set_attribute(FiddlerSpanAttributes.AGENT_NAME, 'unknown')
        _set_agent_id(span, 'unknown')
        self._set_session_id(span)
        self._root_span = span
        return span

    def _add_span(self, span: trace.Span, run_id: UUID) -> None:
        """Add a span to the active spans registry."""
        self._active_spans[run_id] = span

    def _get_span(self, run_id: UUID | None) -> trace.Span | None:
        """Retrieve a span from the active spans registry by its run ID."""
        if run_id is None:
            return None
        return self._active_spans.get(run_id)

    def _remove_span(self, run_id: UUID) -> None:
        """Remove a span from the active spans registry."""
        del self._active_spans[run_id]
        if len(self._active_spans) == 0:
            self._root_span = None

    def _set_fiddler_attributes_from_metadata(
        self, span: trace.Span, metadata: dict[str, Any] | None
    ) -> None:
        """Set Fiddler-specific attributes on a span from component metadata."""
        if metadata is not None:
            fiddler_attributes = metadata.get(FIDDLER_METADATA_KEY, {})
            for key, value in fiddler_attributes.items():
                fdl_key = (
                    key
                    if key in vars(FiddlerSpanAttributes).values()
                    else FIDDLER_USER_SPAN_ATTRIBUTE_TEMPLATE.format(key=key)
                )
                span.set_attribute(fdl_key, value)

    def _update_root_span_agent_name(self, agent_name: str) -> None:
        """Retroactively update the agent name on the root span once it becomes known."""
        if self._root_span and self._root_span.is_recording():
            self._root_span.set_attribute(FiddlerSpanAttributes.AGENT_NAME, agent_name)
            _set_agent_id(self._root_span, agent_name)

    def _start_trace(self, trace_name: str, run_id: UUID) -> None:
        """Start a new trace and register the root span."""
        span = self._start_new_trace(trace_name)
        self._add_span(span, run_id)

    def _set_session_id(self, span: trace.Span) -> None:
        """Set the session/conversation ID attribute on a span.

        Reads the conversation ID from the contextvar on every call so that changes
        made via set_conversation_id() between invocations are always reflected.
        """
        session_id = _CONVERSATION_ID.get()
        if session_id:
            span.set_attribute(FiddlerSpanAttributes.CONVERSATION_ID, session_id)

    def _create_child_span(self, parent_span: trace.Span, span_name: str) -> trace.Span:
        """Create a child span under the given parent."""
        parent_context = trace.set_span_in_context(parent_span, self._context)
        return self._tracer.start_span(span_name, context=parent_context)

    def on_chain_start(
        self,
        serialized: dict[str, Any],
        inputs: dict[str, Any],
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        tags: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> Any:
        """Called when a chain starts."""
        if not self._root_span:
            trace_name = kwargs.get('name', 'unknown')
            self._start_trace(trace_name, run_id)
            return
        agent_name = _get_agent_name(metadata) if metadata is not None else 'unknown'
        parent_span = self._get_span(parent_run_id)
        if parent_span is None:
            logger.warning(
                'on_chain_start no parent span for run_id %s , parent_run_id %s',
                run_id,
                parent_run_id,
            )
            return
        child_span = self._create_child_span(parent_span, kwargs.get('name', 'unknown'))
        child_span.set_attribute(FiddlerSpanAttributes.TYPE, SpanType.CHAIN)
        child_span.set_attribute(FiddlerSpanAttributes.AGENT_NAME, agent_name)
        _set_agent_id(child_span, agent_name)
        self._update_root_span_agent_name(agent_name)
        if metadata is not None:
            self._set_fiddler_attributes_from_metadata(child_span, metadata)
        self._set_session_id(child_span)
        self._add_span(child_span, run_id)

    def on_chain_end(
        self,
        outputs: dict[str, Any],
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        **kwargs: Any,
    ) -> Any:
        """Called when a chain ends."""
        span = self._get_span(run_id)
        if span:
            span.set_status(trace.Status(trace.StatusCode.OK))
            span.end()
            self._remove_span(run_id)
        else:
            logger.warning('on_chain_end no active span: %s, %s', run_id, kwargs)

    def on_chain_error(
        self,
        error: BaseException,
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        **kwargs: Any,
    ) -> Any:
        """Called when a chain encounters an error."""
        span = self._get_span(run_id)
        if span:
            span.record_exception(error)
            error_message = repr(error) if repr(error) else str(error)
            span.set_status(trace.Status(trace.StatusCode.ERROR, error_message))
            span.end()
            self._remove_span(run_id)
        else:
            logger.warning('on_chain_error no active span: %s, %s', run_id, kwargs)

    def on_tool_start(
        self,
        serialized: dict[str, Any],
        input_str: str,
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        tags: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
        inputs: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> Any:
        """Called when a tool starts."""
        parent_span = self._get_span(parent_run_id)
        if parent_span is None:
            logger.warning(
                'on_tool_start no parent span for run_id %s , parent_run_id %s',
                run_id,
                parent_run_id,
            )
            return
        child_span = self._create_child_span(parent_span, serialized.get('name', 'unknown'))
        span_input = json.dumps(inputs, cls=_LanggraphJSONEncoder) if inputs else input_str
        child_span.set_attribute(FiddlerSpanAttributes.TYPE, SpanType.TOOL)
        child_span.set_attribute(FiddlerSpanAttributes.TOOL_NAME, serialized.get('name', 'unknown'))
        child_span.set_attribute(FiddlerSpanAttributes.TOOL_INPUT, span_input)
        if metadata is not None:
            _set_agent_name(child_span, metadata)
            self._set_fiddler_attributes_from_metadata(child_span, metadata)
        self._set_session_id(child_span)
        self._add_span(child_span, run_id)

    def on_tool_end(
        self,
        output: Any,
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        **kwargs: Any,
    ) -> Any:
        """Called when a tool ends."""
        span = self._get_span(run_id)
        if span:
            span.set_attribute(
                FiddlerSpanAttributes.TOOL_OUTPUT,
                json.dumps(output, cls=_LanggraphJSONEncoder),
            )
            span.set_status(trace.Status(trace.StatusCode.OK))
            span.end()
            self._remove_span(run_id)
        else:
            logger.warning('on_tool_end no active span: %s, %s', run_id, kwargs)

    def on_tool_error(
        self,
        error: BaseException,
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        **kwargs: Any,
    ) -> Any:
        """Called when a tool encounters an error."""
        span = self._get_span(run_id)
        if span:
            span.record_exception(error)
            error_message = repr(error) if repr(error) else str(error)
            span.set_status(trace.Status(trace.StatusCode.ERROR, error_message))
            span.end()
            self._remove_span(run_id)
        else:
            logger.warning('on_tool_error no active span: %s, %s', run_id, kwargs)

    def on_retriever_start(
        self,
        serialized: dict[str, Any],
        query: str,
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        tags: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> Any:
        """Called when a retriever starts."""
        parent_span = self._get_span(parent_run_id)
        if parent_span is None:
            logger.warning(
                'on_retriever_start no parent span for run_id %s , parent_run_id %s',
                run_id,
                parent_run_id,
            )
            return
        child_span = self._create_child_span(parent_span, kwargs.get('name', 'unknown'))
        child_span.set_attribute(FiddlerSpanAttributes.TYPE, SpanType.TOOL)
        child_span.set_attribute(FiddlerSpanAttributes.TOOL_NAME, kwargs.get('name', 'unknown'))
        child_span.set_attribute(FiddlerSpanAttributes.TOOL_INPUT, query)
        if metadata is not None:
            _set_agent_name(child_span, metadata)
            self._set_fiddler_attributes_from_metadata(child_span, metadata)
        self._set_session_id(child_span)
        self._add_span(child_span, run_id)

    def on_retriever_error(
        self,
        error: BaseException,
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        **kwargs: Any,
    ) -> Any:
        """Called when a retriever encounters an error."""
        span = self._get_span(run_id)
        if span:
            span.record_exception(error)
            error_message = repr(error) if repr(error) else str(error)
            span.set_status(trace.Status(trace.StatusCode.ERROR, error_message))
            span.end()
            self._remove_span(run_id)
        else:
            logger.warning('on_retriever_error no active span: %s, %s', run_id, kwargs)

    def on_retriever_end(
        self,
        documents: Sequence[Document],
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        **kwargs: Any,
    ) -> Any:
        """Called when a retriever ends."""
        span = self._get_span(run_id)
        if span:
            span.set_status(trace.Status(trace.StatusCode.OK))
            span.set_attribute(
                FiddlerSpanAttributes.TOOL_OUTPUT,
                json.dumps(documents, cls=_LanggraphJSONEncoder),
            )
            span.end()
            self._remove_span(run_id)
        else:
            logger.warning('on_retriever_end no active span: %s, %s', run_id, kwargs)

    def on_chat_model_start(
        self,
        serialized: dict[str, Any],
        messages: list[list[BaseMessage]],
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        tags: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> Any:
        """Called when a chat model starts."""
        parent_span = self._get_span(parent_run_id)
        if parent_span is None:
            logger.warning(
                'on_llm_start no parent span for run_id %s , parent_run_id %s',
                run_id,
                parent_run_id,
            )
            return
        parent_context = trace.set_span_in_context(parent_span, self._context)
        child_span = self._tracer.start_span(
            serialized.get('name', 'unknown'), context=parent_context
        )

        system_message = []
        user_message = []
        message_history = []

        if messages and messages[0]:
            system_message = [m for m in messages[0] if isinstance(m, SystemMessage)]
            user_message = [m for m in messages[0] if isinstance(m, HumanMessage)]
            message_history = list(messages[0])

        if metadata is not None:
            _set_agent_name(child_span, metadata)
            self._set_fiddler_attributes_from_metadata(child_span, metadata)

        child_span.set_attribute(FiddlerSpanAttributes.TYPE, SpanType.LLM)
        _set_model_attributes(child_span, metadata)
        _set_tool_definitions(child_span, kwargs)

        system_content = _stringify_message_content(system_message[-1]) if system_message else ''
        user_content = _stringify_message_content(user_message[-1]) if user_message else ''
        child_span.set_attribute(FiddlerSpanAttributes.LLM_INPUT_SYSTEM, system_content)
        child_span.set_attribute(FiddlerSpanAttributes.LLM_INPUT_USER, user_content)

        if message_history:
            otel_messages = [_convert_message_to_otel_format(msg) for msg in message_history]
            child_span.set_attribute(
                FiddlerSpanAttributes.GEN_AI_INPUT_MESSAGES,
                json.dumps(otel_messages, cls=_LanggraphJSONEncoder),
            )

        self._set_session_id(child_span)
        self._add_span(child_span, run_id)

    def on_llm_start(
        self,
        serialized: dict[str, Any],
        prompts: list[str],
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        tags: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> Any:
        """Called when a (non-chat) language model starts."""
        parent_span = self._get_span(parent_run_id)
        if parent_span is None:
            logger.warning(
                'on_llm_start no parent span for run_id %s , parent_run_id %s',
                run_id,
                parent_run_id,
            )
            return
        child_span = self._create_child_span(parent_span, serialized.get('name', 'unknown'))
        child_span.set_attribute(FiddlerSpanAttributes.TYPE, SpanType.LLM)
        if metadata is not None:
            _set_agent_name(child_span, metadata)
            self._set_fiddler_attributes_from_metadata(child_span, metadata)
        _set_model_attributes(child_span, metadata)
        _set_tool_definitions(child_span, kwargs)
        child_span.set_attribute(FiddlerSpanAttributes.LLM_INPUT_SYSTEM, prompts[0])
        child_span.set_attribute(FiddlerSpanAttributes.LLM_INPUT_USER, prompts[0])
        self._set_session_id(child_span)
        self._add_span(child_span, run_id)

    def on_llm_end(
        self,
        response: LLMResult,
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        **kwargs: Any,
    ) -> Any:
        """Called when a language model ends."""
        span = self._get_span(run_id)
        if span:
            span.set_status(trace.Status(trace.StatusCode.OK))

            output = ''
            output_message_dict = None

            if (
                response.generations
                and len(response.generations) > 0
                and response.generations[0]
                and len(response.generations[0]) > 0
            ):
                generation = response.generations[0][0]
                output = generation.text

                if isinstance(generation, ChatGeneration) and isinstance(
                    generation.message, AIMessage
                ):
                    output_message_dict = generation.message
                    if (
                        output == ''
                        and hasattr(generation.message, 'tool_calls')
                        and generation.message.tool_calls
                    ):
                        output = json.dumps(
                            generation.message.tool_calls, cls=_LanggraphJSONEncoder
                        )

            span.set_attribute(FiddlerSpanAttributes.LLM_OUTPUT, output)
            _set_token_usage_attributes(span, response)

            if output_message_dict:
                otel_message = _convert_message_to_otel_format(output_message_dict)
                span.set_attribute(
                    FiddlerSpanAttributes.GEN_AI_OUTPUT_MESSAGES,
                    json.dumps([otel_message], cls=_LanggraphJSONEncoder),
                )

            span.end()
            self._remove_span(run_id)
        else:
            logger.warning('on_llm_end no active span: %s, %s', run_id, kwargs)

    def on_llm_error(
        self,
        error: BaseException,
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        **kwargs: Any,
    ) -> Any:
        """Called when a language model encounters an error."""
        span = self._get_span(run_id)
        if span:
            span.record_exception(error)
            error_message = repr(error) if repr(error) else str(error)
            span.set_status(trace.Status(trace.StatusCode.ERROR, error_message))
            span.set_attribute('error_kwargs', str(kwargs))
            span.end()
            self._remove_span(run_id)
        else:
            logger.warning('on_llm_error no active span: %s, %s', run_id, kwargs)
