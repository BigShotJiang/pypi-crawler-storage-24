"""LangGraph instrumentation module for Fiddler."""

import logging
from collections.abc import Callable
from typing import Any, cast

from langchain_core.callbacks import BaseCallbackManager
from langchain_core.language_models import BaseLanguageModel
from langchain_core.retrievers import BaseRetriever
from langchain_core.runnables import RunnableBinding
from langchain_core.tools import BaseTool
from pydantic import ConfigDict, validate_call
from wrapt import wrap_function_wrapper

from fiddler_langgraph.callback import _CallbackHandler
from fiddler_langgraph.util import _check_langgraph_version, _get_package_version
from fiddler_otel import set_conversation_id
from fiddler_otel.attributes import _CUSTOM_ATTRIBUTES, FIDDLER_METADATA_KEY, FiddlerSpanAttributes
from fiddler_otel.client import FiddlerClient

_LOG = logging.getLogger(__name__)

__all__ = [
    'LangGraphInstrumentor',
    'add_session_attributes',
    'add_span_attributes',
    'set_conversation_id',
    'set_llm_context',
]


@validate_call(config=ConfigDict(strict=True, arbitrary_types_allowed=True))
def add_session_attributes(key: str, value: str) -> None:
    """Add custom session-level attributes that persist across all spans in the current context.

    Session attributes are automatically included in all spans created during the
    current execution context. Use this to add metadata such as user information,
    deployment environment, or feature flags.

    :param key: The attribute key. Will appear as ``fiddler.session.user.{key}`` in spans.
    :param value: The attribute value.

    Example::

        from fiddler_langgraph import add_session_attributes

        add_session_attributes("user_id", "user_12345")
        add_session_attributes("environment", "production")
    """
    _raw = _CUSTOM_ATTRIBUTES.get()
    current_attributes = _raw.copy() if _raw else {}
    current_attributes[key] = value
    _CUSTOM_ATTRIBUTES.set(current_attributes)


@validate_call(config=ConfigDict(strict=True, arbitrary_types_allowed=True))
def _set_default_metadata(
    node: BaseLanguageModel | BaseRetriever | BaseTool,
) -> None:
    """Ensure a LangChain component has the default Fiddler metadata dictionary.

    :param node: The component to initialise metadata on (modified in place).
    """
    if not hasattr(node, 'metadata'):
        node.metadata = {}
    if not isinstance(node.metadata, dict):
        node.metadata = {}
    metadata = node.metadata
    if FIDDLER_METADATA_KEY not in metadata:
        metadata[FIDDLER_METADATA_KEY] = {}


@validate_call(config=ConfigDict(strict=True, arbitrary_types_allowed=True))
def add_span_attributes(
    node: BaseLanguageModel | BaseRetriever | BaseTool,
    **kwargs: Any,
) -> None:
    """Add custom span-level attributes to a specific LangChain component's metadata.

    Attributes are stored in the component's metadata and automatically included
    in OTel spans when the component executes. Unlike session attributes, these
    are scoped to individual components.

    :param node: The LangChain component to annotate (modified in place).
    :param kwargs: Arbitrary key-value attributes. Keys matching known
        ``FiddlerSpanAttributes`` values are set directly; all others are
        prefixed with ``fiddler.span.user.``.

    Example::

        from langchain_openai import ChatOpenAI
        from fiddler_langgraph import add_span_attributes

        llm = ChatOpenAI(model="gpt-4")
        add_span_attributes(llm, model_tier="premium", use_case="summarization")
    """
    _set_default_metadata(node)
    metadata = cast(dict[str, Any], node.metadata)
    fiddler_attrs = cast(dict[str, Any], metadata.get(FIDDLER_METADATA_KEY, {}))
    for key, value in kwargs.items():
        fiddler_attrs[key] = value


@validate_call(config=ConfigDict(strict=True))
def set_llm_context(llm: BaseLanguageModel | RunnableBinding, context: str) -> None:
    """Set additional context information on a language model instance.

    The context is attached to all spans created for this model and is stored
    as ``gen_ai.llm.context``. Supports both ``BaseLanguageModel`` instances
    and ``RunnableBinding`` objects.

    :param llm: The language model instance or binding.
    :param context: The context string to attach.
    :raises TypeError: If a ``RunnableBinding`` is provided but its bound
        object is not a ``BaseLanguageModel``.

    Example::

        from langchain_openai import ChatOpenAI
        from fiddler_langgraph import set_llm_context

        llm = ChatOpenAI(model="gpt-4")
        set_llm_context(llm, "User prefers concise responses in Spanish")
    """
    if isinstance(llm, RunnableBinding):
        if not isinstance(llm.bound, BaseLanguageModel):
            raise TypeError(
                'llm must be a BaseLanguageModel or a RunnableBinding of a BaseLanguageModel'
            )
        _llm = llm.bound
    else:
        _llm = llm

    _set_default_metadata(_llm)
    assert _llm.metadata is not None  # guaranteed by _set_default_metadata
    fiddler_attrs = cast(dict[str, Any], _llm.metadata.get(FIDDLER_METADATA_KEY, {}))
    fiddler_attrs[FiddlerSpanAttributes.LLM_CONTEXT] = context


class LangGraphInstrumentor:
    """An OpenTelemetry instrumentor for LangGraph applications.

    Provides automatic instrumentation for applications built with LangGraph by
    monkey-patching LangChain's callback system to inject a custom callback handler
    that captures trace data.

    Once instrumented, all LangGraph/LangChain operations automatically generate
    telemetry. Calling ``instrument()`` multiple times is safe.

    Example::

        from fiddler_langgraph import FiddlerClient, LangGraphInstrumentor

        client = FiddlerClient(
            api_key="...",
            application_id="...",
            url="https://your-instance.fiddler.ai",
        )
        LangGraphInstrumentor(client).instrument()
    """

    def __init__(self, client: FiddlerClient):
        """Initialise the LangGraphInstrumentor.

        :param client: The ``FiddlerClient`` instance to use for tracing.
        :raises ImportError: If LangGraph is not installed or its version is incompatible.
        """
        self._client = client
        self._is_instrumented = False
        self._langgraph_version = _get_package_version('langgraph')
        self._langchain_version = _get_package_version('langchain_core')
        self._fiddler_langgraph_version = _get_package_version('fiddler_langgraph')

        self._client.update_resource(
            {
                'lib.langgraph.version': self._langgraph_version.public,
                'lib.langchain_core.version': self._langchain_version.public,
                'lib.fiddler-langgraph.version': self._fiddler_langgraph_version.public,
            }
        )
        self._tracer: _CallbackHandler | None = None
        self._original_callback_manager_init: Callable[..., None] | None = None

        _check_langgraph_version(self._langgraph_version)

    def instrument(self, **kwargs: Any) -> None:
        """Instrument LangGraph by monkey-patching ``BaseCallbackManager``.

        Calling this method multiple times is safe; subsequent calls are no-ops.

        :raises ValueError: If the tracer is not initialized in the FiddlerClient.
        """
        if self._is_instrumented:
            _LOG.warning('Attempting to instrument while already instrumented')
            return

        import langchain_core

        tracer = self._client.get_tracer()
        if tracer is None:
            raise ValueError('Context tracer is not initialized')

        self._tracer = _CallbackHandler(tracer)
        self._original_callback_manager_init = langchain_core.callbacks.BaseCallbackManager.__init__
        wrap_function_wrapper(
            module='langchain_core.callbacks',
            name='BaseCallbackManager.__init__',
            wrapper=_BaseCallbackManagerInit(self._tracer),
        )
        self._is_instrumented = True

    def uninstrument(self, **kwargs: Any) -> None:
        """Remove the instrumentation from LangGraph."""
        if not self._is_instrumented:
            _LOG.warning('Attempting to uninstrument while already uninstrumented')
            return

        import langchain_core

        if self._original_callback_manager_init is not None:
            setattr(  # noqa: B010
                langchain_core.callbacks.BaseCallbackManager,
                '__init__',
                self._original_callback_manager_init,
            )
        self._original_callback_manager_init = None
        self._tracer = None
        self._is_instrumented = False


class _BaseCallbackManagerInit:
    """Wrapper for ``BaseCallbackManager.__init__`` that injects Fiddler's callback handler."""

    __slots__ = ('_callback_handler',)

    def __init__(self, callback_handler: _CallbackHandler):
        """Initialise the wrapper.

        :param callback_handler: The Fiddler callback handler to inject.
        """
        self._callback_handler = callback_handler

    def __call__(
        self,
        wrapped: Callable[..., None],
        instance: 'BaseCallbackManager',
        args: Any,
        kwargs: Any,
    ) -> None:
        """Call the original ``__init__`` and then inject the Fiddler handler."""
        wrapped(*args, **kwargs)
        for handler in instance.inheritable_handlers:
            if isinstance(handler, type(self._callback_handler)):
                break
        else:
            instance.add_handler(self._callback_handler, True)
