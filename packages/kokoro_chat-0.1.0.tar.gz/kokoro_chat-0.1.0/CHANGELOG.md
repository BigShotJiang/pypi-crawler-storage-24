# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/),
and this project adheres to [Semantic Versioning](https://semver.org/).

## [0.1.0] - 2026-03-18

### Added

- Initial extraction from [roleplay-chat](https://github.com/daiwanwei/roleplay-chat)
- **ChatEngine** — full LLM conversation loop with tool calling (AgentLoop)
- **Protocol-based storage** — 9 `@runtime_checkable` Protocol interfaces for DB-agnostic persistence
  - `AttitudeStore`, `ChatHistoryStore`, `MemoryVectorStore`, `MemoStore`
  - `RollingSummaryStore`, `EventStore`, `UsageLogStore`, `ChatMessageWriter`, `CacheStore`
- **Character system** — YAML V2 character cards with Kokoro extensions
  - `speech_patterns_v2` (mood-based), `affection_overrides`, `post_history_by_level`, `anti_patterns`
  - `Character.from_db_model()` duck-typed constructor
  - `map_v2_yaml_to_db()` YAML V2 loader
- **Attitude system** — affection/trust tracking (0-100) with 5 levels (stranger → married)
  - Time decay after 3+ days inactivity
  - Event-triggered modifiers with turn countdown
- **Memory system** — room/private visibility, stale memo filtering
- **Lorebook engine** — keyword scanning, selective mode, token budget, insertion_order sorting
- **Prompt assembler** — static (slim) and full assembly paths with progressive degradation
  - Token budget enforcement (12000 default)
  - Graceful degradation: memories → events → memos
- **LLM tools** — `update_attitude`, `save_memory`, `upsert_memo`, `search_memories`
- **Background tasks** — summarization, user info extraction, event analysis, markup stripping
- **Context providers** — attitude, persona, recent_chat
- **Multi-provider LLM** — Anthropic, OpenAI, MiniMax via motosan-ai
- **Prompt caching** — Anthropic ephemeral cache support
- **Streaming** — async generator with `text_delta` / `message_complete` events
- Comprehensive test suite (354 tests)
