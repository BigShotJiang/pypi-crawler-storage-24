"""Attitude state and affection level logic."""
from __future__ import annotations

from kokoro_chat.attitude.levels import (  # noqa: F401
    AFFECTION_BEHAVIORS,
    DEFAULT_AFFECTION_LEVELS,
    get_affection_level,
)
from kokoro_chat.attitude.state import AttitudeState  # noqa: F401
