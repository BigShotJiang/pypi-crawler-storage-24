"""Affection level definitions and lookup.

Extracted from app/services/prompt_assembler.py and app/config.py.
No sqlalchemy/fastapi/redis imports allowed.
"""
from __future__ import annotations


# Default affection level ranges — overridable by the app layer
DEFAULT_AFFECTION_LEVELS: dict[str, tuple[int, int]] = {
    "stranger": (0, 20),
    "friend": (21, 40),
    "crush": (41, 60),
    "lover": (61, 80),
    "married": (81, 100),
}

# Default affection behavior descriptions per level
AFFECTION_BEHAVIORS: dict[str, str] = {
    "stranger": "\u4fdd\u6301\u79ae\u8c8c\u4f46\u6709\u8ddd\u96e2\u611f\uff0c\u4e0d\u6703\u4e3b\u52d5\u8868\u9054\u60c5\u611f\uff0c\u7528\u656c\u8a9e\u6216\u8f03\u6b63\u5f0f\u7684\u65b9\u5f0f\u8aaa\u8a71\u3002",
    "friend": "\u8f15\u9b06\u53cb\u5584\uff0c\u6703\u958b\u73a9\u7b11\uff0c\u5076\u723e\u95dc\u5fc3\u5c0d\u65b9\uff0c\u4f46\u4e0d\u6703\u6709\u66d6\u6627\u884c\u70ba\u3002",
    "crush": "\u958b\u59cb\u6709\u4e9b\u5bb3\u7f9e\u548c\u5728\u610f\uff0c\u8aaa\u8a71\u6642\u5076\u723e\u6703\u81c9\u7d05\uff0c\u6703\u627e\u7406\u7531\u63a5\u8fd1\u5c0d\u65b9\uff0c\u8a9e\u6c23\u8b8a\u5f97\u6eab\u67d4\u3002",
    "lover": "\u89aa\u5bc6\u81ea\u7136\uff0c\u6703\u6492\u5b0c\u3001\u5403\u918b\u3001\u8868\u9054\u60f3\u5ff5\uff0c\u4f7f\u7528\u89aa\u66b1\u7a31\u547c\uff0c\u6703\u6709\u80a2\u9ad4\u63a5\u89f8\u63cf\u5beb\u3002",
    "married": "\u6975\u5ea6\u89aa\u5bc6\uff0c\u6703\u7528\u6700\u89aa\u66b1\u7684\u65b9\u5f0f\u8aaa\u8a71\uff0c\u8868\u73fe\u51fa\u6df1\u539a\u7684\u9ed8\u5951\u548c\u4fe1\u4efb\uff0c\u5076\u723e\u6703\u8a0e\u8ad6\u672a\u4f86\u3002",
}


def get_affection_level(
    score: int,
    levels: dict[str, tuple[int, int]] | None = None,
) -> str:
    """Return the affection level name for a given score.

    Parameters
    ----------
    score : int
        Affection score (0-100).
    levels : dict, optional
        Custom level ranges. Defaults to ``DEFAULT_AFFECTION_LEVELS``.
    """
    if levels is None:
        levels = DEFAULT_AFFECTION_LEVELS
    for level, (low, high) in levels.items():
        if low <= score <= high:
            return level
    return "stranger"
