"""AttitudeContextProvider -- relationship and attitude state context.

Extracted from app/providers/attitude.py.
No sqlalchemy / fastapi / redis imports allowed.

Responsible for:
  - [Relationship status] (affection level + behavior guidance)
  - [Current attitude (dynamic)]

V2 enhancement: supports affection_overrides (character-specific affection behaviors).
"""
from __future__ import annotations

from kokoro_chat.attitude.levels import (
    AFFECTION_BEHAVIORS,
    get_affection_level,
)


class AttitudeContextProvider:
    """Build the relationship/attitude section of the system prompt.

    Created per-request with the current attitude state.
    """

    def __init__(
        self,
        affection_score: int,
        attitude_section: str | None = None,
        affection_overrides: dict[str, str] | None = None,
    ):
        self._affection_score = affection_score
        self._attitude_section = attitude_section
        self._affection_overrides = affection_overrides or {}

    async def build(self, query: str) -> str:
        """Build the attitude context string.

        ``query`` is accepted for protocol compliance but not used.
        """
        level = get_affection_level(self._affection_score)
        level_names = {
            "stranger": "\u719f\u4eba",
            "friend": "\u670b\u53cb",
            "crush": "\u5fc3\u52d5",
            "lover": "\u6200\u4eba",
            "married": "\u7d50\u5a5a",
        }

        # V2: use affection_overrides if available, fallback to defaults
        if self._affection_overrides and level in self._affection_overrides:
            behavior_text = self._affection_overrides[level]
        else:
            behavior_text = AFFECTION_BEHAVIORS.get(level, "")

        section = (
            f"[\u95dc\u4fc2\u72c0\u614b]\n"
            f"\u95dc\u4fc2\u7b49\u7d1a\uff1a{level_names.get(level, level)}\n"
            f"\u884c\u70ba\u6307\u5f15\uff1a{behavior_text}"
        )

        if self._attitude_section:
            section += f"\n\n[\u7576\u524d\u614b\u5ea6\uff08\u52d5\u614b\uff09]\n{self._attitude_section}"

        return section
