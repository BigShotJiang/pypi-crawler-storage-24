"""Extracted context providers for kokoro_chat.

Each provider implements the ``async def build(self, query: str) -> str``
protocol used by motosan-chat ContextProvider.

No sqlalchemy / fastapi / redis imports allowed in this package.
"""
from __future__ import annotations

from kokoro_chat.providers.attitude import AttitudeContextProvider
from kokoro_chat.providers.persona import PersonaContextProvider
from kokoro_chat.providers.recent_chat import RecentChatContextProvider

__all__ = [
    "AttitudeContextProvider",
    "PersonaContextProvider",
    "RecentChatContextProvider",
]
