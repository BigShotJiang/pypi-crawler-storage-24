"""ChatEngine core and background task logic.

The engine uses dependency-injected storage (Protocol-based stores)
and does not depend on any web framework or database library.
"""
from __future__ import annotations

from kokoro_chat.engine.chat import ChatEngine
from kokoro_chat.engine.background import (
    build_event_analysis_prompt,
    build_extract_user_info_prompt,
    build_process_memory_prompt,
    build_summarize_prompt,
    may_contain_personal_info,
    parse_event_impact,
    parse_extracted_user_info,
    parse_memory_summary,
    strip_app_markup,
)

__all__ = [
    "ChatEngine",
    "build_event_analysis_prompt",
    "build_extract_user_info_prompt",
    "build_process_memory_prompt",
    "build_summarize_prompt",
    "may_contain_personal_info",
    "parse_event_impact",
    "parse_extracted_user_info",
    "parse_memory_summary",
    "strip_app_markup",
]
