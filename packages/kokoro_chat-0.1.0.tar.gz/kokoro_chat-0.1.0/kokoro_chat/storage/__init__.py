"""Storage protocols for kokoro_chat.

Protocol-based interfaces that decouple domain logic from concrete
persistence implementations (PostgreSQL, Redis, in-memory, etc.).
"""
from __future__ import annotations

from kokoro_chat.storage.protocol import (
    AttitudeRecord,
    AttitudeStore,
    CacheStore,
    ChatHistoryStore,
    ChatMessage,
    ChatMessageWriter,
    EventRecord,
    EventStore,
    MemoStore,
    MemorySearchResult,
    MemoryVectorStore,
    RollingSummaryRecord,
    RollingSummaryStore,
    UsageLogStore,
)

__all__ = [
    "AttitudeRecord",
    "AttitudeStore",
    "CacheStore",
    "ChatHistoryStore",
    "ChatMessage",
    "ChatMessageWriter",
    "EventRecord",
    "EventStore",
    "MemoStore",
    "MemorySearchResult",
    "MemoryVectorStore",
    "RollingSummaryRecord",
    "RollingSummaryStore",
    "UsageLogStore",
]
