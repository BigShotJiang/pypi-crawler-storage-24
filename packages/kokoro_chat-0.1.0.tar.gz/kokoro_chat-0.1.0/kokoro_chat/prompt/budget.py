"""Token estimation and budget defaults.

Extracted from app/services/prompt_assembler.py.
No sqlalchemy/fastapi/redis imports allowed.
"""
from __future__ import annotations


# Sensible defaults, overridable by the app layer
DEFAULT_SYSTEM_PROMPT_TOKEN_BUDGET: int = 12000
DEFAULT_MAX_MEMO_TOKENS: int = 500
DEFAULT_MAX_MES_EXAMPLES: int = 1
DEFAULT_MAX_ROLLING_SUMMARY_TOKENS: int = 80


def _estimate_tokens(text: str) -> int:
    """Rough token estimate: 1 token ~ 2 chars for mixed CJK/English."""
    return len(text) // 2
