"""Conversation history formatting.

Extracted from app/services/prompt_assembler.py.
No sqlalchemy/fastapi/redis imports allowed.
"""
from __future__ import annotations


def format_conversation_history(
    history: list[dict],
    max_turns: int = 20,
) -> list[dict]:
    """Convert conversation history to Claude API messages format.

    Only keeps the most recent *max_turns* turns.
    """
    recent = history[-max_turns * 2:]  # user + assistant = 2 messages per turn
    messages = []
    for msg in recent:
        messages.append({
            "role": msg["role"],
            "content": msg["content"],
        })
    return messages
