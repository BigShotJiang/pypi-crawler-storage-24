"""ChatConfig — pure dataclass configuration for ChatEngine.

No environment variable reading here.  The application layer reads env vars
and constructs a ChatConfig instance to inject into ChatEngine.
"""
from __future__ import annotations

from dataclasses import dataclass, field


# -- Pricing helper (framework-independent) -----------------------------------

MODEL_PRICING: dict[str, tuple[float, float]] = {
    "claude-sonnet-4-5-20250929": (3.0, 15.0),
    "claude-haiku-4-5-20251001": (0.80, 4.0),
    "MiniMax-M1": (0.30, 1.20),
}


def calculate_cost(model: str, input_tokens: int, output_tokens: int) -> float:
    """Calculate USD cost for a given model and token counts."""
    input_rate, output_rate = MODEL_PRICING.get(model, (3.0, 15.0))
    return (input_tokens * input_rate + output_tokens * output_rate) / 1_000_000


@dataclass
class ChatConfig:
    """Configuration for ChatEngine — pure data, no env reading."""

    # Primary chat model
    chat_model: str = "claude-sonnet-4-5-20250929"
    chat_provider: str = "anthropic"

    # Background / memory model (cheaper)
    memory_model: str = "MiniMax-M1"
    memory_provider: str = "minimax"
    memory_llm_model: str = "claude-haiku-4-5-20251001"

    # Generation limits
    max_tokens: int = 4096
    recent_turns: int = 6

    # Feature flags
    prompt_cache_enabled: bool = False

    # Background task concurrency
    bg_task_concurrency: int = 5

    # Summarization
    summarize_every: int = 8

    # API credentials (opaque strings; engine passes them to client builder)
    anthropic_api_key: str = ""
    anthropic_oauth_token: str = ""
    openai_api_key: str = ""
    minimax_api_key: str = ""
