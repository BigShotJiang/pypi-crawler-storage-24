"""Extracted tool logic for kokoro_chat.

Pure domain logic for attitude updates, memory saves, memo upserts,
and memory search. Each function encapsulates the business rules
(validation, clamping, error handling) while accepting Protocol-based
stores for persistence.

No sqlalchemy / fastapi / redis imports allowed in this package.
"""
from __future__ import annotations

from kokoro_chat.tools.attitude_tool import update_attitude
from kokoro_chat.tools.memo_tool import upsert_memo
from kokoro_chat.tools.memory_tool import save_memory
from kokoro_chat.tools.search_tool import search_memories

__all__ = [
    "save_memory",
    "search_memories",
    "update_attitude",
    "upsert_memo",
]
