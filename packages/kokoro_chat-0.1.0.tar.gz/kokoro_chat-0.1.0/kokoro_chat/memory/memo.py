"""Memo filtering utilities.

Extracted from app/services/prompt_assembler.py.
No sqlalchemy/fastapi/redis imports allowed.
"""
from __future__ import annotations

from datetime import datetime, timezone

# Stale memo configuration -- overridable by the app layer
STALE_KEYS = {"current_stress", "recent_event", "current_mood"}
STALE_DAYS = 3


def _filter_stale_memos(memos: list[dict]) -> list[dict]:
    """Filter out stale time-sensitive memos older than STALE_DAYS."""
    now = datetime.now(timezone.utc)
    result = []
    for memo in memos:
        if memo["key"] in STALE_KEYS:
            updated_at = memo.get("updated_at")
            if updated_at:
                age_days = (now - updated_at).days
                if age_days > STALE_DAYS:
                    continue
        result.append(memo)
    return result
