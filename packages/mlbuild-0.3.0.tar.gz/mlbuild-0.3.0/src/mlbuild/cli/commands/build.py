"""
Build command: Convert ONNX → CoreML and register artifact.

Infrastructure guarantees:
- Deterministic build ID (includes environment fingerprint)
- Atomic artifact promotion
- Integrity verification after move
- Full reproducibility tracking
"""

from __future__ import annotations

import os
import sys
import shutil
import hashlib
import tempfile
from pathlib import Path
from datetime import datetime, timezone
from decimal import Decimal
from xml.parsers.expat import model

import click
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn

from mlbuild import __version__ as MLBUILD_VERSION

from ...loaders import load_model
from ...backends.coreml import CoreMLExporter
from ...core.hash import (
    compute_artifact_hash,
    compute_config_hash,
    compute_source_hash,
)
from ...core.environment import (
    collect_environment,
    hash_environment,
    validate_reproducibility,
)
from ...core.calibration import (
    CalibrationConfig,
    CalibrationDataset,
    PreprocessingConfig,
)
from ...registry import LocalRegistry
from ...core.types import Build
from ...core.errors import MLBuildError

# --- PATCH: task detection + validation config ---
from ...core.task_detection import detect_task, detection_warning, ModelInfo, TaskType
from ...core.task_validation import StrictOutputConfig

console = Console()


# ---------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------

def _structured_build_id(
    source_hash: str,
    config_hash: str,
    artifact_hash: str,
    env_fingerprint: str,
    mlbuild_version: str,
) -> str:
    """
    Compute deterministic build ID.
    
    Build ID = SHA256(source_hash || config_hash || artifact_hash || env_fingerprint || version)
    """
    return hashlib.sha256(
        b"\x00".join([
            bytes.fromhex(source_hash),
            bytes.fromhex(config_hash),
            bytes.fromhex(artifact_hash),
            bytes.fromhex(env_fingerprint),
            mlbuild_version.encode('utf-8'),
        ])
    ).hexdigest()


def _directory_size_bytes(path: Path) -> int:
    return sum(f.stat().st_size for f in path.rglob("*") if f.is_file())


def _read_global_strict() -> bool:
    """Read [validation] strict_output from .mlbuild/config.toml if present."""
    try:
        config_path = Path(".mlbuild/config.toml")
        if not config_path.exists():
            return False
        import tomllib  # Python 3.11+
        with config_path.open("rb") as f:
            data = tomllib.load(f)
        return bool(data.get("validation", {}).get("strict_output", False))
    except Exception:
        return False


# ---------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------

@click.command()
@click.argument('build_id')
@click.option('--runs', default=100, type=int, help='Number of benchmark runs')
@click.option('--warmup', default=20, type=int, help='Number of warmup runs')
@click.option(
    '--compute-unit',
    type=click.Choice(['CPU_ONLY', 'CPU_AND_GPU', 'ALL']),
    default='ALL',
    help='Compute unit'
)
@click.option('--json', 'as_json', is_flag=True, help='Output as JSON')
def benchmark(build_id, runs, warmup, compute_unit, as_json):
    """Benchmark a build on current device."""
    from ..commands.benchmark import benchmark as benchmark_cmd

    ctx = click.get_current_context()

    ctx.invoke(
        benchmark_cmd,
        build_id=build_id,
        runs=runs,
        warmup=warmup,
        compute_unit=compute_unit,
        as_json=as_json,
    )


@click.command()
@click.option(
    "--model",
    required=True,
    type=click.Path(exists=True, path_type=Path),
)
@click.option(
    "--backend",
    type=click.Choice(["coreml", "tflite"]),
    default="coreml",
    help="Backend to use for conversion"
)
@click.option(
    "--target",
    required=True,
    type=click.Choice(["apple_a17", "apple_a16", "apple_a15", "apple_m3", "apple_m2", "apple_m1", "android_arm64", "android_arm32", "raspberry_pi"]),
)
@click.option("--name")
@click.option(
    "--quantize",
    type=click.Choice(["fp32", "fp16", "int8"]),
    default="fp32",
)
@click.option("--notes")
# --- PATCH: --task flag ---
@click.option(
    "--task",
    type=click.Choice(["vision", "nlp", "audio", "unknown"]),
    default=None,
    help="Model task type. Auto-detected from ONNX graph if omitted.",
)
# --- PATCH: --strict-output flag ---
@click.option(
    "--strict-output",
    "strict_output",
    is_flag=True,
    default=False,
    help="Hard-fail on output validation warnings (overrides config.toml).",
)
def build(model: Path, backend: str, target: str, name: str, quantize: str, notes: str,
          task: str, strict_output: bool):

    # --- PATCH: resolve StrictOutputConfig once, used downstream ---
    strict_cfg = StrictOutputConfig.from_command(
        strict_flag=strict_output,
        global_strict=_read_global_strict(),
    )

    # ============================================================
    # RESOLVE BACKEND
    # ============================================================
    from ...backends.registry import BackendRegistry

    try:
        backend_inst = BackendRegistry.get_backend(backend)
    except (ValueError, RuntimeError) as e:
        console.print(f"\n[red]Backend Error:[/red] {e}\n")
        sys.exit(1)

    # If backend has its own build method, use it
    if backend != "coreml":
        try:
            # ---------------------------------------------------------
            # Mirror CoreML pipeline: collect env, hash, convert, promote
            # ---------------------------------------------------------
            env_data = collect_environment()
            env_fingerprint = hash_environment(env_data)

            source_hash = compute_source_hash(model)

            config = {
                "target": target,
                "quantization": {"type": quantize},
                "optimizer": {},
            }
            config_hash = compute_config_hash(config)

            console.print(f"\n[bold]Building:[/bold] {Path(model).name}")
            console.print(f"Backend: {backend}")
            console.print(f"Target: {target}")
            console.print(f"Quantization: {quantize}\n")

            # Generate representative dataset for INT8 calibration
            representative_dataset = None
            if quantize == "int8":
                console.print("[dim]Generating INT8 calibration data...[/dim]")
                import onnx
                import numpy as np
                onnx_model = onnx.load(str(model))
                input_shapes = backend_inst._get_input_shapes(onnx_model)
                def _make_representative_dataset(shapes):
                    def generator():
                        for _ in range(100):
                            yield [np.random.randn(*shape).astype(np.float32) for _, shape in shapes]
                    return generator
                representative_dataset = _make_representative_dataset(input_shapes)

            with Progress(SpinnerColumn(), TextColumn("{task.description}"), console=console) as p:
                task_progress = p.add_task(f"Converting to TFLite ({quantize.upper()})...", total=None)
                tflite_path = backend_inst._export(
                    model_path=Path(model),
                    quantize=quantize,
                    name=name,
                    representative_dataset=representative_dataset,
                )
                p.update(task_progress, completed=True)

            artifact_hash = compute_source_hash(tflite_path)

            build_id = _structured_build_id(
                source_hash,
                config_hash,
                artifact_hash,
                env_fingerprint,
                MLBUILD_VERSION,
            )

            # Promote artifact into content-addressed directory
            artifacts_root = Path(".mlbuild/artifacts").resolve()
            final_path = artifacts_root / f"{artifact_hash[:16]}_{name or tflite_path.stem}.tflite"
            artifacts_root.mkdir(parents=True, exist_ok=True)

            if not final_path.exists():
                shutil.copy2(str(tflite_path), str(final_path))
                # Store ONNX graph once for optimize command
                graphs_root = Path(".mlbuild/graphs").resolve()
                graphs_root.mkdir(parents=True, exist_ok=True)
                graph_dest = graphs_root / f"{build_id}.onnx"
                if not graph_dest.exists():
                    shutil.copy2(str(model), str(graph_dest))
                graph_path = f"graphs/{build_id}.onnx"

            size_mb = Decimal(str(round(final_path.stat().st_size / (1024 * 1024), 6)))

            backend_versions = {"tflite": backend_inst._tf_version()}
            if "onnx2tf" in sys.modules:
                import onnx2tf
                backend_versions["onnx2tf"] = onnx2tf.__version__

            # --- PATCH: task detection for TFLite (Tier 2/3 only — no ONNX graph) ---
            import onnx
            onnx_model = onnx.load(str(model))
            task_info = _detect_task_from_onnx(onnx_model, forced_task=task)
            warn = detection_warning(task_info)
            if warn:
                console.print(f"\n[yellow]{warn}[/yellow]")

            build_obj = Build(
                build_id=build_id,
                artifact_hash=artifact_hash,
                source_hash=source_hash,
                config_hash=config_hash,
                env_fingerprint=env_fingerprint,
                name=name,
                notes=notes,
                created_at=datetime.now(timezone.utc),
                source_path=str(Path(model).resolve()),
                target_device=target,
                format=backend,
                quantization=config["quantization"],
                optimizer_config=config["optimizer"],
                backend_versions=backend_versions,
                environment_data=env_data,
                mlbuild_version=MLBUILD_VERSION,
                python_version=env_data["python"]["version"],
                platform=env_data["hardware"]["cpu"]["system"],
                os_version=env_data["hardware"]["cpu"]["release"],
                artifact_path=str(final_path),
                size_mb=size_mb,
                has_graph=True,
                graph_format="onnx",
                graph_path=graph_path,
                task_type=task_info.primary.value,  # --- PATCH ---
            )

            # Registry transaction
            registry = LocalRegistry()
            try:
                registry.save_build(build_obj)
            except Exception:
                pass  # Duplicate build — already registered, artifact still valid

            console.print(f"\n[bold green]✓ Build complete[/bold green]")
            console.print(f"Build ID:      {build_id[:16]}...")
            console.print(f"Artifact Hash: {artifact_hash[:16]}...")
            console.print(f"Source Hash:   {source_hash[:16]}...")
            console.print(f"Config Hash:   {config_hash[:16]}...")
            console.print(f"Env Fingerprint: {env_fingerprint[:16]}...")
            console.print(f"Size:          {size_mb:.2f} MB")
            console.print(f"Artifact Path: {final_path}", overflow="fold")
            console.print(f"Task:          {task_info.primary.value}")
            console.print()
            return

        except MLBuildError as e:
            console.print("\n[bold red]Build failed[/bold red]\n")
            console.print(e.format())
            sys.exit(e.exit_code.value)
        except Exception as e:
            console.print(f"\n[bold red]Build failed[/bold red]: {e}\n")
            import traceback
            traceback.print_exc()
            sys.exit(1)

    # ============================================================
    # ENFORCE DETERMINISM (DO NOT JUST WARN)
    # ============================================================
    import numpy as np
    import torch
    
    # Set environment variables
    os.environ["PYTHONHASHSEED"] = "0"
    
    # Set random seeds
    torch.manual_seed(0)
    torch.cuda.manual_seed_all(0)
    np.random.seed(0)
    
    # Set deterministic algorithms (may impact performance)
    torch.use_deterministic_algorithms(True, warn_only=True)

    console.print("[dim]Deterministic mode enabled (PYTHONHASHSEED=0, seeds set)[/dim]\n")

    console.print(f"\n[bold]Building:[/bold] {os.path.basename(model)}")
    console.print(f"Target: {target}")
    console.print(f"Quantization: {quantize}\n")

    try:
        # -------------------------------------------------------------
        # Step 1: Collect environment ONCE (never recompute)
        # -------------------------------------------------------------
        env_data = collect_environment()
        env_fingerprint = hash_environment(env_data)
        
        # -------------------------------------------------------------
        # Step 2: Validate reproducibility (WARN but allow non-critical)
        # -------------------------------------------------------------
        is_reproducible, warnings = validate_reproducibility()
        if warnings:
            console.print("\n[yellow]⚠️  Reproducibility warnings:[/yellow]")
            for warning in warnings:
                console.print(f"    {warning}")
            
            # Only check for CRITICAL warnings
            has_critical = any("[CRITICAL]" in w for w in warnings)
            if has_critical:
                console.print("\n[bold red]CRITICAL: Build cannot proceed[/bold red]")
                sys.exit(1)

            console.print("\n[bold yellow]WARNING: Build may not be reproducible[/bold yellow]")
            console.print("Run: export PYTHONHASHSEED=0")
            console.print("Or add to ~/.zshrc: echo 'export PYTHONHASHSEED=0' >> ~/.zshrc\n")

        # -------------------------------------------------------------
        # Step 3: Load model
        # -------------------------------------------------------------
        with Progress(SpinnerColumn(), TextColumn("{task.description}"), console=console) as p:
            task_progress = p.add_task("Loading ONNX...", total=None)
            ir = load_model(str(model))
            p.update(task_progress, completed=True)

        # -------------------------------------------------------------
        # Step 4: Hash source
        # -------------------------------------------------------------
        source_hash = compute_source_hash(model)

        # -------------------------------------------------------------
        # Step 5: Build configuration
        # -------------------------------------------------------------
        config = {
            "target": target,
            "quantization": {"type": quantize},
            "optimizer": {"compute_units": "ALL"},
        }

        # Extract coremltools version from environment
        try:
            import coremltools as ct
            coremltools_version = ct.__version__
        except ImportError:
            coremltools_version = "unknown"
        
        config_hash = compute_config_hash(config, coremltools_version=coremltools_version)

        # -------------------------------------------------------------
        # Step 5.5: Generate INT8 calibration data if needed
        # -------------------------------------------------------------
        calibration_data = None
        if quantize == "int8":
            console.print("[dim]Generating INT8 calibration data...[/dim]")
            
            # Get input shape from IR
            from ...backends.coreml.exporter import ModelIngestion
            _, _, shape_tuples = ModelIngestion.extract_input_specs(ir)
            
            # Create calibration config
            cal_config = CalibrationConfig(
                sample_count=100,  # 100 calibration samples
                input_shape=tuple(shape_tuples[0]),  # Use model's input shape
                preprocessing=PreprocessingConfig(),  # No preprocessing for now
                seed=42,
            )
            
            # Generate synthetic calibration data
            cal_dataset = CalibrationDataset(cal_config)
            calibration_samples = cal_dataset.generate_synthetic()
            
            # Compute fingerprint for reproducibility
            cal_fingerprint = cal_dataset.compute_fingerprint()
            
            console.print(f"  Calibration samples: {cal_fingerprint.sample_count}")
            console.print(f"  Calibration hash: {cal_fingerprint.data_hash[:16]}...")
            console.print()
            
            calibration_data = list(calibration_samples)

        # -------------------------------------------------------------
        # Step 5.6: Task detection from ONNX graph (Tier 1/2/3)
        # -------------------------------------------------------------
        import onnx as _onnx
        _onnx_model = _onnx.load(str(model))
        task_result = _detect_task_from_onnx(_onnx_model, forced_task=task)
        warn = detection_warning(task_result)
        if warn:
            console.print(f"[yellow]{warn}[/yellow]\n")

        # -------------------------------------------------------------
        # Step 6: Convert to CoreML
        # -------------------------------------------------------------
        with tempfile.TemporaryDirectory() as tmp_root:

            tmp_root = Path(tmp_root)

            import io
            import contextlib

            with Progress(SpinnerColumn(), TextColumn("{task.description}"), console=console) as p:
                task_progress = p.add_task("Converting to CoreML...", total=None)

                exporter = CoreMLExporter(target=target)
                
                # Suppress all noisy output from coremltools/onnx2torch during conversion
                with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
                    mlpackage_path, conversion_metadata = exporter.export(
                        ir,
                        output_dir=tmp_root,
                        quantization=quantize,
                        calibration_data=calibration_data,
                    )

                p.update(task_progress, completed=True)

            # ---------------------------------------------------------
            # Step 7: Compute artifact hash
            # ---------------------------------------------------------
            artifact_hash = compute_artifact_hash(mlpackage_path)

            # ---------------------------------------------------------
            # Step 8: Compute build ID (INCLUDES ENVIRONMENT)
            # ---------------------------------------------------------
            build_id = _structured_build_id(
                source_hash,
                config_hash,
                artifact_hash,
                env_fingerprint,
                MLBUILD_VERSION,
            )

            # ---------------------------------------------------------
            # Step 9: Prepare final artifact location
            # ---------------------------------------------------------
            artifacts_root = Path(".mlbuild/artifacts").resolve()
            final_dir = artifacts_root / artifact_hash

            artifacts_root.mkdir(parents=True, exist_ok=True)

            # ---------------------------------------------------------
            # Step 10: Promote artifact atomically
            # ---------------------------------------------------------
            if final_dir.exists():
                # Verify integrity before trusting existing artifact
                existing_hash = compute_artifact_hash(final_dir)
                if existing_hash != artifact_hash:
                    raise RuntimeError(
                        "Artifact hash mismatch — possible corruption"
                    )

                console.print(f"[yellow]Reusing existing artifact {artifact_hash[:12]}[/yellow]")

            else:
                # Move entire directory atomically
                shutil.move(str(mlpackage_path), str(final_dir))

                # Post-move verification
                verified_hash = compute_artifact_hash(final_dir)
                if verified_hash != artifact_hash:
                    shutil.rmtree(final_dir, ignore_errors=True)
                    raise RuntimeError("Artifact integrity verification failed")
                
            # ---------------------------------------------------------
            # Step 11: Store ONNX graph once for optimize command
            # ---------------------------------------------------------
            graphs_root = Path(".mlbuild/graphs").resolve()
            graphs_root.mkdir(parents=True, exist_ok=True)
            graph_dest = graphs_root / f"{build_id}.onnx"
            if not graph_dest.exists():
                shutil.copy2(str(model), str(graph_dest))
            graph_path = f"graphs/{build_id}.onnx"

            # ---------------------------------------------------------
            # Step 12: Compute exact byte size
            # ---------------------------------------------------------
            size_bytes = _directory_size_bytes(final_dir)
            size_mb = Decimal(size_bytes) / Decimal(1024 * 1024)

            # ---------------------------------------------------------
            # Step 13: Create Build object with environment data
            # ---------------------------------------------------------
            # Extract framework versions from env_data structure
            backend_versions = {}
            if "numpy" in env_data and env_data["numpy"].get("installed"):
                backend_versions["numpy"] = env_data["numpy"]["version"]
            if "torch" in env_data and env_data["torch"].get("installed"):
                backend_versions["torch"] = env_data["torch"]["version"]
            if "tensorflow" in env_data and env_data["tensorflow"].get("installed"):
                backend_versions["tensorflow"] = env_data["tensorflow"]["version"]
            if "onnxruntime" in env_data and env_data["onnxruntime"].get("installed"):
                backend_versions["onnxruntime"] = env_data["onnxruntime"]["version"]
            
            # Add coremltools
            try:
                import coremltools as ct
                backend_versions["coremltools"] = ct.__version__
            except ImportError:
                backend_versions["coremltools"] = "unknown"
            
            # Add ONNX version from IR
            backend_versions["onnx"] = ir.metadata.get("framework_version", "unknown")
            
            build_obj = Build(
                build_id=build_id,
                artifact_hash=artifact_hash,
                source_hash=source_hash,
                config_hash=config_hash,
                env_fingerprint=env_fingerprint,
                name=name,
                notes=notes,
                created_at=datetime.now(timezone.utc),
                source_path=str(Path(model).resolve()),
                target_device=target,
                format="coreml",
                quantization=config["quantization"],
                optimizer_config=config["optimizer"],
                backend_versions=backend_versions,  # Use extracted versions
                environment_data=env_data,  # Full environment snapshot
                mlbuild_version=MLBUILD_VERSION,
                python_version=env_data["python"]["version"],
                platform=env_data["hardware"]["cpu"]["system"],
                os_version=env_data["hardware"]["cpu"]["release"],
                artifact_path=str(final_dir),
                size_mb=size_mb,
                has_graph=True,
                graph_format="onnx",
                graph_path=graph_path,
                task_type=task_result.primary.value,  # --- PATCH ---
            )

            # ---------------------------------------------------------
            # Step 14: Registry transaction
            # ---------------------------------------------------------
            registry = LocalRegistry()
            try:
                registry.save_build(build_obj)
            except Exception:
                # Roll back artifact if registry fails
                shutil.rmtree(final_dir, ignore_errors=True)
                raise

        # -------------------------------------------------------------
        # Success output
        # -------------------------------------------------------------
        console.print(f"\n[bold green]✓ Build complete[/bold green]")
        console.print(f"Build ID:      {build_id[:16]}...")
        console.print(f"Artifact Hash: {artifact_hash[:16]}...")
        console.print(f"Source Hash:   {source_hash[:16]}...")
        console.print(f"Config Hash:   {config_hash[:16]}...")
        console.print(f"Env Fingerprint: {env_fingerprint[:16]}...")
        console.print(f"Size:          {size_mb:.2f} MB")
        console.print(f"Artifact Path: {final_dir}")
        console.print(f"Task:          {task_result.primary.value}")
        console.print()
        
        if not is_reproducible:
            console.print("[yellow]⚠️  Build may not be reproducible. See warnings above.[/yellow]\n")

    except MLBuildError as e:
        console.print("\n[bold red]Build failed[/bold red]\n")
        console.print(e.format())
        sys.exit(e.exit_code.value)

    except Exception as e:
        console.print(f"\n[bold red]Build failed[/bold red]: {e}\n")
        import traceback
        traceback.print_exc()
        sys.exit(1)

# ============================================================
# Programmatic build API (used by explore and other commands)
# ============================================================

def run_build(
    model_path: Path,
    target: str,
    name: str,
    quantization: str = "fp32",
    format: str = "coreml",
    registry: Optional["LocalRegistry"] = None,
    notes: Optional[str] = None,
    task: Optional[str] = None,
) -> "Build":
    """
    Programmatic build API — no console output, no sys.exit.

    Returns the registered Build object.
    Used by: mlbuild explore, mlbuild optimize (future).
    The Click `build` command remains independent with its own output.
    """
    from ...registry.local import LocalRegistry as _LocalRegistry
    from decimal import Decimal
    from datetime import datetime, timezone

    model_path = Path(model_path)
    _registry = registry or _LocalRegistry()

    if format == "coreml":
        return _run_coreml_build(
            model_path=model_path,
            target=target,
            name=name,
            quantize=quantization,
            notes=notes,
            task=task,
            registry=_registry,
        )
    elif format == "tflite":
        return _run_tflite_build(
            model_path=model_path,
            target=target,
            name=name,
            quantize=quantization,
            notes=notes,
            task=task,
            registry=_registry,
        )
    else:
        raise ValueError(f"Unsupported format: {format}")


def _run_coreml_build(
    model_path: Path,
    target: str,
    name: str,
    quantize: str,
    notes: Optional[str],
    task: Optional[str],
    registry: "LocalRegistry",
) -> "Build":
    import shutil
    import tempfile
    from decimal import Decimal
    from datetime import datetime, timezone

    # Step 1: Environment
    env_data = collect_environment()
    env_fingerprint = hash_environment(env_data)

    # Step 2: Load model
    ir = load_model(str(model_path))

    # Step 3: Hash source
    source_hash = compute_source_hash(model_path)

    # Step 4: Config
    try:
        import coremltools as ct
        coremltools_version = ct.__version__
    except ImportError:
        coremltools_version = "unknown"

    config = {
        "target": target,
        "quantization": {"type": quantize},
        "optimizer": {"compute_units": "ALL"},
    }
    config_hash = compute_config_hash(config, coremltools_version=coremltools_version)

    # Step 5: Task detection
    import onnx as _onnx
    _onnx_model = _onnx.load(str(model_path))
    task_result = _detect_task_from_onnx(_onnx_model, forced_task=task)

    # Step 6: Convert
    with tempfile.TemporaryDirectory() as tmp_root:
        tmp_root = Path(tmp_root)
        import io, contextlib
        exporter = CoreMLExporter(target=target)
        with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
            mlpackage_path, _ = exporter.export(
                ir,
                output_dir=tmp_root,
                quantization=quantize,
                calibration_data=None,
            )

        # Step 7: Artifact hash + build ID
        artifact_hash = compute_artifact_hash(mlpackage_path)
        build_id = _structured_build_id(
            source_hash, config_hash, artifact_hash,
            env_fingerprint, MLBUILD_VERSION,
        )

        # Step 8: Promote artifact
        artifacts_root = Path(".mlbuild/artifacts").resolve()
        final_dir = artifacts_root / artifact_hash
        artifacts_root.mkdir(parents=True, exist_ok=True)

        if not final_dir.exists():
            shutil.move(str(mlpackage_path), str(final_dir))

        # Step 9: Store graph
        graphs_root = Path(".mlbuild/graphs").resolve()
        graphs_root.mkdir(parents=True, exist_ok=True)
        graph_dest = graphs_root / f"{build_id}.onnx"
        if not graph_dest.exists():
            shutil.copy2(str(model_path), str(graph_dest))
        graph_path = f"graphs/{build_id}.onnx"

        # Step 10: Size
        size_bytes = _directory_size_bytes(final_dir)
        size_mb = Decimal(size_bytes) / Decimal(1024 * 1024)

        # Step 11: Backend versions
        backend_versions = {}
        try:
            import coremltools as ct
            backend_versions["coremltools"] = ct.__version__
        except ImportError:
            backend_versions["coremltools"] = "unknown"
        backend_versions["onnx"] = ir.metadata.get("framework_version", "unknown")

        # Step 12: Build object
        build_obj = Build(
            build_id=build_id,
            artifact_hash=artifact_hash,
            source_hash=source_hash,
            config_hash=config_hash,
            env_fingerprint=env_fingerprint,
            name=name,
            notes=notes,
            created_at=datetime.now(timezone.utc),
            source_path=str(model_path.resolve()),
            target_device=target,
            format="coreml",
            quantization=config["quantization"],
            optimizer_config=config["optimizer"],
            backend_versions=backend_versions,
            environment_data=env_data,
            mlbuild_version=MLBUILD_VERSION,
            python_version=env_data["python"]["version"],
            platform=env_data["hardware"]["cpu"]["system"],
            os_version=env_data["hardware"]["cpu"]["release"],
            artifact_path=str(final_dir),
            size_mb=size_mb,
            has_graph=True,
            graph_format="onnx",
            graph_path=graph_path,
            task_type=task_result.primary.value,
        )

        # Step 13: Save
        try:
            registry.save_build(build_obj)
        except Exception:
            pass  # Duplicate — artifact still valid

    return build_obj


def _run_tflite_build(
    model_path: Path,
    target: str,
    name: str,
    quantize: str,
    notes: Optional[str],
    task: Optional[str],
    registry: "LocalRegistry",
) -> "Build":
    import shutil
    from decimal import Decimal
    from datetime import datetime, timezone
    from ...backends.registry import BackendRegistry

    env_data = collect_environment()
    env_fingerprint = hash_environment(env_data)
    source_hash = compute_source_hash(model_path)

    config = {
        "target": target,
        "quantization": {"type": quantize},
        "optimizer": {},
    }
    config_hash = compute_config_hash(config)

    backend_inst = BackendRegistry.get_backend("tflite")
    tflite_path = backend_inst._export(
        model_path=model_path,
        quantize=quantize,
        name=name,
        representative_dataset=None,
    )

    artifact_hash = compute_source_hash(tflite_path)
    build_id = _structured_build_id(
        source_hash, config_hash, artifact_hash,
        env_fingerprint, MLBUILD_VERSION,
    )

    artifacts_root = Path(".mlbuild/artifacts").resolve()
    final_path = artifacts_root / f"{artifact_hash[:16]}_{name or tflite_path.stem}.tflite"
    artifacts_root.mkdir(parents=True, exist_ok=True)

    if not final_path.exists():
        shutil.copy2(str(tflite_path), str(final_path))

    graphs_root = Path(".mlbuild/graphs").resolve()
    graphs_root.mkdir(parents=True, exist_ok=True)
    graph_dest = graphs_root / f"{build_id}.onnx"
    if not graph_dest.exists():
        shutil.copy2(str(model_path), str(graph_dest))

    graph_path = f"graphs/{build_id}.onnx"
    size_mb = Decimal(str(round(final_path.stat().st_size / (1024 * 1024), 6)))

    backend_versions = {"tflite": backend_inst._tf_version()}

    import onnx as _onnx
    _onnx_model = _onnx.load(str(model_path))
    task_result = _detect_task_from_onnx(_onnx_model, forced_task=task)

    build_obj = Build(
        build_id=build_id,
        artifact_hash=artifact_hash,
        source_hash=source_hash,
        config_hash=config_hash,
        env_fingerprint=env_fingerprint,
        name=name,
        notes=notes,
        created_at=datetime.now(timezone.utc),
        source_path=str(model_path.resolve()),
        target_device=target,
        format="tflite",
        quantization=config["quantization"],
        optimizer_config=config["optimizer"],
        backend_versions=backend_versions,
        environment_data=env_data,
        mlbuild_version=MLBUILD_VERSION,
        python_version=env_data["python"]["version"],
        platform=env_data["hardware"]["cpu"]["system"],
        os_version=env_data["hardware"]["cpu"]["release"],
        artifact_path=str(final_path),
        size_mb=size_mb,
        has_graph=True,
        graph_format="onnx",
        graph_path=graph_path,
        task_type=task_result.primary.value,
    )

    try:
        registry.save_build(build_obj)
    except Exception:
        pass

    return build_obj

# ---------------------------------------------------------------------
# Shared helper: build ModelInfo + call detect_task
# ---------------------------------------------------------------------

def _detect_task_from_onnx(onnx_model, forced_task: str | None):
    """
    Build a ModelInfo from a loaded ONNX model and run task detection.
    """
    from ...core.task_detection import TensorInfo
    import numpy as np

    graph = onnx_model.graph

    # Build TensorInfo list from ONNX graph inputs
    inputs = []
    for inp in graph.input:
        shape = []
        for dim in inp.type.tensor_type.shape.dim:
            shape.append(dim.dim_value if dim.dim_value > 0 else -1)
        
        # Map ONNX elem_type to numpy dtype
        elem_type = inp.type.tensor_type.elem_type
        _ONNX_TO_NP = {
            1: np.float32, 2: np.uint8, 3: np.int8,
            5: np.int32,   6: np.int32, 7: np.int64,
            10: np.float16, 11: np.float64,
        }
        dtype = _ONNX_TO_NP.get(elem_type)

        inputs.append(TensorInfo(
            name=inp.name,
            shape=tuple(shape) if shape else None,
            dtype=dtype,
        ))

    # Build TensorInfo list from ONNX graph outputs
    outputs = []
    for out in graph.output:
        outputs.append(TensorInfo(name=out.name))

    op_types = {node.op_type for node in graph.node}

    metadata = {}
    for prop in onnx_model.metadata_props:
        metadata[prop.key] = prop.value

    info = ModelInfo(
        format="onnx",
        inputs=inputs,
        outputs=outputs,
        op_types=op_types,
        node_count=len(graph.node),
        metadata=metadata,
    )

    forced = TaskType(forced_task) if forced_task else None
    return detect_task(info, forced=forced)