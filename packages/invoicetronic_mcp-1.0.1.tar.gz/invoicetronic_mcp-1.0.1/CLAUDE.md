# Invoicetronic MCP Server

Server MCP per fatturazione elettronica italiana via SDI.

## Struttura
- `server.py` — Server FastMCP (uv run --script)
- GitHub: fgasparetto/invoicetronic-mcp

## Esecuzione
```bash
uv run --script server.py
```

## Env vars
- `INVOICETRONIC_API_KEY` — API key Invoicetronic
