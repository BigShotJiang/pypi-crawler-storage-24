import os
import sys
import time
import threading
import random

_R  = '\033[0m'
_B  = '\033[1m'
_DM = '\033[2m'
_G  = '\033[92m'
_Y  = '\033[93m'
_C  = '\033[96m'
_RE = '\033[91m'
_GR = '\033[90m'
_W  = '\033[97m'

def _type(text, end='\n'):
    for ch in text:
        sys.stdout.write(ch)
        sys.stdout.flush()
        time.sleep(random.uniform(0.013, 0.038))
    sys.stdout.write(end)
    sys.stdout.flush()

class _Spinner:
    _frames = ['⣾','⣽','⣻','⢿','⡿','⣟','⣯','⣷']
    def __init__(self, label):
        self.label = label
        self._stop = threading.Event()
        self._t = threading.Thread(target=self._run, daemon=True)
    def _run(self):
        i = 0
        while not self._stop.is_set():
            sys.stdout.write(f'\r  {_C}{self._frames[i % 8]}{_R} {_GR}{self.label}{_R}')
            sys.stdout.flush()
            i += 1
            time.sleep(0.08)
    def start(self):
        self._t.start()
        return self
    def stop(self, ok=True, label='', detail=''):
        self._stop.set()
        self._t.join()
        badge = f'{_G}[ OK ]{_R}' if ok else f'{_RE}[SKIP]{_R}'
        name  = f'{_W}{label:<26}{_R}'
        note  = f'{_GR}{detail}{_R}' if detail else ''
        sys.stdout.write(f'\r\033[K  {badge}  {name}{note}\n')
        sys.stdout.flush()

def _db_get_int(byt):
    return int.from_bytes(byt, 'little')

def _db_get_string(byt, start):
    st  = start + 4
    ofs = _db_get_int(byt[start:st])
    start = st + ofs
    strii = byt[st:start - 1].decode()
    return (start, strii)

def _db_byte_int(num, cot):
    return num.to_bytes(cot, byteorder='little')

def _db_byte_string(stri):
    strii = stri.encode()
    strii = _db_byte_int(len(strii) + 1, 4) + strii + b'\x00'
    return strii

def db_unpack_element(bin, struct):
    start = 4
    ele   = []
    for i in struct:
        if i == 0:
            start, stri = _db_get_string(bin, start)
            ele.append(stri)
        elif 0 < i < 5:
            ele.append(_db_get_int(bin[start:start + i]))
            start += i
        elif i > 4:
            ele.append(bin[start:start + i])
            start += i
    return ele

def db_pack_element(lists, struct):
    for i in range(len(lists)):
        if struct[i] == 0:
            lists[i] = _db_byte_string(lists[i])
        elif type(lists[i]) == int:
            lists[i] = _db_byte_int(lists[i], struct[i])
    con = b''.join(lists)
    return _db_byte_int(len(con), 4) + con

_STRUCT_HEROSKIN     = (4, 4, 0, 4, 0, 0, 4, 109, 12, 0, 0, 0, 0, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 0, 0, 0, 0, 2, 2, 99, 57)
_STRUCT_HEROSKINSHOP = (4, 4, 0, 4, 0, 0, 4, 109, 12, 75, 9, 30)

_PATH_HEROSKIN     = '/Actor/HeroSkin.bytes'
_PATH_HEROSKINSHOP = '/Shop/HeroSkinShop.bytes'

def db_heroskin(dic, struct, task):
    list1 = db_unpack_element(dic[task[1]][0], struct)
    list2 = db_unpack_element(dic[task[1]][0], struct)
    heroid   = str(task[1])[0:3]
    list1[0] = task[0]
    list1[1] = int(heroid)
    list1[3] = int(0x00)
    list1[5] = '30' + heroid + '0'
    list2[43] = 1
    dic[task[0]] = [db_pack_element(list1, struct)]
    dic[task[1]] = [db_pack_element(list2, struct)]

def db_heroskinshop(dic, struct, task):
    try:
        list1 = db_unpack_element(dic[task[1]][0], struct)
        list2 = db_unpack_element(dic[task[1]][0], struct)
        heroid   = str(task[1])[0:3]
        list1[0] = task[0]
        list1[1] = int(heroid)
        list1[3] = int(0x00)
        dic[task[0]] = [db_pack_element(list1, struct)]
        dic[task[1]] = [db_pack_element(list2, struct)]
    except KeyError:
        pass

def db_modify(filepath, struct, tasklist, func, point, outputpath):
    strucount   = 0
    optimistruct = []
    if point != 0:
        for i in range(point):
            if struct[i] == 0:
                if strucount != 0:
                    optimistruct.append(strucount)
                optimistruct.append(0)
                strucount = 0
            else:
                strucount += struct[i]

    bin = open(filepath, 'rb')
    bin.seek(8, 0)
    header = [_db_get_int(bin.read(4)), _db_get_int(bin.read(4))]
    bin.seek(96, 0)
    header.append(bin.read(32))
    bin.seek(140, 0)
    dic = {}

    for count in range(header[1]):
        ofs    = bin.read(4)
        conten = bin.read(_db_get_int(ofs))
        idnum  = 0
        if point != 0:
            for i in optimistruct:
                if i == 0:
                    idnum += _db_get_int(conten[idnum:idnum + 4]) + 4
                else:
                    idnum += i
        skinid1 = _db_get_int(conten[idnum:idnum + struct[point]])
        if skinid1 in dic:
            dic[skinid1].append(ofs + conten)
        else:
            dic[skinid1] = [ofs + conten]
    bin.close()

    if outputpath == '':
        outputpath = filepath

    filechange = False
    for task in tasklist:
        if task[1] in dic:
            func(dic, struct, task)
            filechange = True

    if filechange:
        lens = 0
        for key in dic:
            lens      += len(dic[key])
            dic[key]   = b''.join(dic[key])
        with open(outputpath, 'wb') as f:
            f.write(
                b'MSES\x07\x00\x00\x00' +
                _db_byte_int(header[0], 4) +
                _db_byte_int(lens, 4) +
                b'\x61' * 32 +
                b'\x00' * 16 +
                b'UTF-8' +
                b'\x00' * 27 +
                header[2] +
                b'\x00' * 4 +
                b'\x8c' +
                b'\x00' * 7 +
                b''.join(list(dic.values()))
            )
    return filechange

def build_tasklist(device_path):
    folder    = os.path.join(device_path, 'Task')
    filenames = [f for f in os.listdir(folder) if f.endswith('.jpg')]
    tasklist  = []
    for filename in filenames:
        SKINID = int(filename[:filename.index('.')])
        HEROID = SKINID // 100 * 100
        tasklist.append((HEROID, SKINID, True, True))
    return tasklist

def _sep(char='─', width=44):
    print(f'  {_GR}{char * width}{_R}')

def _badge_ok():   return f'{_G}[ OK ]{_R}'
def _badge_err():  return f'{_RE}[FAIL]{_R}'
def _badge_warn(): return f'{_Y}[WARN]{_R}'

def check_requirements(device_path):
    """Check if required folders and files exist."""
    errors = []
    
    task_folder = os.path.join(device_path, 'Task')
    if not os.path.isdir(task_folder):
        errors.append(f"Missing folder: {task_folder}")
        
    actor_folder = os.path.join(device_path, 'Actor')
    if not os.path.isdir(actor_folder):
        errors.append(f"Missing folder: {actor_folder}")
    else:
        hero_skin = os.path.join(actor_folder, 'HeroSkin.bytes')
        if not os.path.isfile(hero_skin):
            errors.append(f"Missing file: {hero_skin}")
            
    shop_folder = os.path.join(device_path, 'Shop')
    if not os.path.isdir(shop_folder):
        errors.append(f"Missing folder: {shop_folder}")
    else:
        hero_skin_shop = os.path.join(shop_folder, 'HeroSkinShop.bytes')
        if not os.path.isfile(hero_skin_shop):
            errors.append(f"Missing file: {hero_skin_shop}")
            
    return errors

def run():
    print()
    print(f"""
░██████╗░░██████╗████████╗
██╔═══██╗██╔════╝╚══██╔══╝
██║██╗██║╚█████╗░░░░██║░░░
╚██████╔╝░╚═══██╗░░░██║░░░
░╚═██╔═╝░██████╔╝░░░██║░░░
░░░╚═╝░░░╚═════╝░░░░╚═╝░░░   and
██████╗░███╗░░░███╗░█████╗░██████╗░
██╔══██╗████╗░████║██╔══██╗██╔══██╗
██║░░██║██╔████╔██║██║░░██║██║░░██║
██║░░██║██║╚██╔╝██║██║░░██║██║░░██║
██████╔╝██║░╚═╝░██║╚█████╔╝██████╔╝
╚═════╝░╚═╝░░░░░╚═╝░╚════╝░╚═════╝░ v.1.0
      ___Not support EVOs skin___
""")

    device_path = os.getcwd()
    
    # Check requirements
    errors = check_requirements(device_path)
    if errors:
        print(f'  {_badge_err()}  {_RE}Requirements check failed:{_R}')
        for err in errors:
            print(f'  {_GR}  └─ {err}{_R}')
        print(f'\n  {_Y}Please ensure you run this command in a directory containing Task/, Actor/, and Shop/ folders with their respective files.{_R}')
        sys.exit(1)

    tasklist = build_tasklist(device_path)
    if not tasklist:
        print(f'  {_badge_warn()}  no .jpg targets found in Task/ folder')
        sys.exit(0)

    _sep()
    print(f'  {_GR}  {"SKIN ID":<12}{"HERO ID":<12}{"STATUS"}{_R}')
    _sep('·')
    for t in tasklist:
        _type(f'  {_C}  {str(t[1]):<12}{_GR}{str(t[0]):<12}{_Y}queued{_R}')
    _sep()
    print()

    rootpath = device_path.replace('\\', '/')
    path_hs  = rootpath + _PATH_HEROSKIN
    path_hss = rootpath + _PATH_HEROSKINSHOP

    print(f'  {_GR}  CWD   {_R}{_DM}{rootpath}{_R}')
    print()

    sp = _Spinner('HeroSkin.bytes').start()
    if os.path.exists(path_hs):
        changed = db_modify(path_hs, _STRUCT_HEROSKIN, tasklist, db_heroskin, 0, path_hs)
        sp.stop(ok=True,  label='HeroSkin.bytes', detail='patched' if changed else 'no change')
    else:
        sp.stop(ok=False, label='HeroSkin.bytes', detail='file not found')

    sp = _Spinner('HeroSkinShop.bytes').start()
    if os.path.exists(path_hss):
        changed = db_modify(path_hss, _STRUCT_HEROSKINSHOP, tasklist, db_heroskinshop, 0, path_hss)
        sp.stop(ok=True,  label='HeroSkinShop.bytes', detail='patched' if changed else 'no change')
    else:
        sp.stop(ok=False, label='HeroSkinShop.bytes', detail='file not found')

    print()
    _sep()
    _type(f'  {_G}✓{_R}  patch complete  {_GR}({len(tasklist)} skin(s)){_R}')
    _sep()
    print()

if __name__ == "__main__":
    run()
