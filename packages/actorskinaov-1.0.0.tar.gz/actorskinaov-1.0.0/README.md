# ActorMod Patcher

Binary patcher for `HeroSkin.bytes` and `HeroSkinShop.bytes`.
Reads skin tasks from a `Task/` folder and patches MSES binary database files in-place.

## Installation

```bash
pip install actormod-patcher
```

## Usage

Run the command in a directory containing the required folders:

```bash
actormod
```

### Required Folder Structure

```
<working directory>/
├── Task/
│   ├── 10101.jpg        ← Skin ID as filename
│   ├── 20203.jpg
│   └── ...
├── Actor/
│   └── HeroSkin.bytes
└── Shop/
    └── HeroSkinShop.bytes
```

## Features

- Patches **HeroSkin.bytes** and **HeroSkinShop.bytes** in a single run
- Auto-discovers skin targets from `.jpg` filenames inside `Task/`
- Derives Hero ID automatically from Skin ID (`SKINID // 100 * 100`)
- Validates required folder structure before running
- ⚠️ **Does not support EVOs skins**
