from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="actorskinaov",
    version="1.0.0",
    author="Worawit_DMODOF",
    author_email="wineropa107@gmail.com",
    description="Binary patcher for HeroSkin.bytes and HeroSkinShop.bytes (GST & DMOD Skin Patcher)",
    long_description=long_description,
    long_description_content_type="text/markdown",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.6",
    entry_points={
        "console_scripts": [
            "actorskinaov=actormod.main:run",
        ],
    },
)
