# Epsilon Attestation Verifier

[![License](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)
[![Release](https://img.shields.io/github/v/release/Epsilon-Data/epsilon-attestation-verifier)](https://github.com/Epsilon-Data/epsilon-attestation-verifier/releases/latest)
[![Tests](https://github.com/Epsilon-Data/epsilon-attestation-verifier/actions/workflows/tests.yml/badge.svg)](https://github.com/Epsilon-Data/epsilon-attestation-verifier/actions/workflows/tests.yml)

Verify AWS Nitro Enclave attestation documents. No AWS account or Nitro hardware required.

## Install

```bash
pip install epsilon-attestation-verifier
```

## Usage

```python
from epsilon_verifier import verify_attestation

result = verify_attestation(
    attestation_doc="<base64 attestation>",
    expected_pcr0="abc123...",    # Optional: verify enclave image
    expected_output="Hello",      # Optional: verify output hash
    allow_expired=True            # For historical attestations (~3hr cert lifetime)
)

if result.valid:
    print(f"Verified: PCR0={result.pcr0}, AWS signature={result.aws_signature_valid}")
else:
    print(f"Failed: {result.error}")
```

### CLI

```bash
epsilon-verify verify attestation.json
epsilon-verify verify attestation.json --pcr0 abc123... --output output.txt --json
epsilon-verify extract attestation.json
```

## What It Checks

1. **COSE signature** — signed by genuine AWS Nitro hardware (ECDSA P-384)
2. **Certificate chain** — valid chain to AWS Nitro root CA
3. **PCR values** — enclave ran expected code (image hash match)
4. **Output hash** — output integrity (SHA-256)

## Attestation Structure

```
COSE_Sign1 (CBOR):
├── module_id      Enclave instance ID
├── pcrs           PCR0 (image), PCR1 (kernel), PCR2 (app)
├── certificate    Enclave certificate (DER)
├── cabundle       Chain to AWS root
├── user_data      Job ID, script hash, dataset hash, output hash
├── nonce          Replay protection
└── timestamp      Execution time (ms)
```

## Trust Model

**You trust:** AWS Nitro Attestation PKI (hardware root of trust)
**You verify:** COSE signature, certificate chain, PCR values, output hash

## License

[MIT](LICENSE)
