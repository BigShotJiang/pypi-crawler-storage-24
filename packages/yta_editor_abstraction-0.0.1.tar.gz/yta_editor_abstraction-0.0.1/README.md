# Youtube Autonomous Main Editor Abstraction

An abstraction of the main editor, to test concepts, architecture and structures. Simplified to be able to test moked concepts.