"""CLI entrypoint package."""
