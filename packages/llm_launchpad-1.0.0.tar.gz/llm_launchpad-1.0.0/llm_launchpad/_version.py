"""Single source of truth for the package version."""

__all__ = ["__version__"]

__version__ = "1.0.0"
