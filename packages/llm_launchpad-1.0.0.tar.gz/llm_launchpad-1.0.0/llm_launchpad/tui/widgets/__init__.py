"""Reusable TUI widget library."""
