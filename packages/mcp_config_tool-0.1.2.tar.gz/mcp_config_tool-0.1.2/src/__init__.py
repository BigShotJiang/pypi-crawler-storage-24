"""MCP Config package."""
