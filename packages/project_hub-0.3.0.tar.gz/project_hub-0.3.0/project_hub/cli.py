from __future__ import annotations

import asyncio
import signal
import sys
from pathlib import Path

import click


# ---------------------------------------------------------------------------
# Main group
# ---------------------------------------------------------------------------


@click.group(invoke_without_command=True)
@click.option("--mcp", is_flag=True, help="Run as MCP server (stdio)")
@click.pass_context
def main(ctx: click.Context, mcp: bool) -> None:
    """project-hub: Multi-repo workspace manager."""
    if ctx.invoked_subcommand:
        return
    if mcp:
        run_mcp()
    else:
        run_standalone()


# ---------------------------------------------------------------------------
# Standalone mode
# ---------------------------------------------------------------------------


def run_standalone() -> None:
    from .git.ops import check_git_version
    from .core.workspace import detect_state, WorkspaceState

    check_git_version()
    state = detect_state(Path.cwd())

    if state == WorkspaceState.DISABLED_OPT_OUT:
        click.echo(
            "project-hub is disabled here. Delete .no-project-hub to re-enable.",
            err=True,
        )
        sys.exit(0)

    if state == WorkspaceState.DISABLED_SUB_REPO:
        click.echo(
            "Inside a workspace sub-repo — project-hub runs from the parent directory.",
            err=True,
        )
        sys.exit(0)

    if state == WorkspaceState.DORMANT:
        if click.confirm("No workspace found. Initialize here?", default=True):
            _do_init(Path.cwd())
        else:
            sys.exit(0)
        return

    asyncio.run(_run_standalone_async())


async def _run_standalone_async() -> None:
    from .core.workspace import Workspace
    from .web.app import create_app, start_webui

    ws = Workspace(Path.cwd())
    await ws.start()

    # First fetch before starting the UI
    await ws.refresh_once()

    app = create_app(**ws.web_app_kwargs())
    server, port = await start_webui(app, ws.config.http_port)
    click.echo(f"Dashboard running at http://localhost:{port}", err=True)
    import webbrowser
    webbrowser.open(f"http://localhost:{port}")

    loop = asyncio.get_event_loop()
    stop_event = asyncio.Event()
    for sig in (signal.SIGINT, signal.SIGTERM):
        loop.add_signal_handler(sig, stop_event.set)

    refresh_task = asyncio.create_task(ws.refresh_loop())
    await stop_event.wait()
    refresh_task.cancel()
    try:
        await refresh_task
    except asyncio.CancelledError:
        pass
    finally:
        server.should_exit = True
        await ws.stop()


# ---------------------------------------------------------------------------
# MCP mode
# ---------------------------------------------------------------------------


def run_mcp() -> None:
    import logging

    logging.basicConfig(stream=sys.stderr, level=logging.WARNING)

    from .mcp.server import mcp as mcp_server

    mcp_server.run()  # stdio transport, blocks


# ---------------------------------------------------------------------------
# Init logic (shared by `init` command and standalone DORMANT path)
# ---------------------------------------------------------------------------

_KNOWN_GITLAB_HOSTS = {"gitlab.com"}


def _do_init(cwd: Path) -> None:
    hub = cwd / ".project-hub"

    if hub.is_dir():
        click.echo("project-hub is already initialized here.", err=True)
        sys.exit(1)

    # Scan for git repos
    from .core.config import Config
    from .core.discovery import discover_repos
    import yaml

    repos = discover_repos(cwd, Config())
    if not repos:
        click.echo("No git repos found in this directory.", err=True)
        sys.exit(1)

    # Collect forge hosts
    hosts: dict[str, str] = {}  # host -> type
    unknown_hosts: set[str] = set()
    for r in repos:
        if not r.forge_host:
            continue
        if r.forge_host in _KNOWN_GITLAB_HOSTS:
            hosts[r.forge_host] = "gitlab"
        else:
            unknown_hosts.add(r.forge_host)

    # Prompt for unknown hosts
    for host in sorted(unknown_hosts):
        if click.confirm(
            f"Unknown host '{host}' — is this a GitLab instance?", default=True
        ):
            hosts[host] = "gitlab"

    # Build config
    config_data: dict = {}
    if hosts:
        config_data["forges"] = {h: {"type": t} for h, t in sorted(hosts.items())}

    hub.mkdir()
    config_yaml = (
        yaml.dump(config_data, default_flow_style=False) if config_data else ""
    )
    (hub / "config.yaml").write_text(config_yaml)
    (hub / "workspace.md").write_text("")

    repo_names = sorted(r.name for r in repos)
    click.echo(f"Initialized project-hub in {cwd}")
    click.echo(f"Discovered {len(repos)} repos: {', '.join(repo_names)}")
    if hosts:
        click.echo(f"Forges: {', '.join(sorted(hosts))}")
    else:
        click.echo(
            "No forge hosts detected — edit .project-hub/config.yaml to add them."
        )


# ---------------------------------------------------------------------------
# init command
# ---------------------------------------------------------------------------


@main.command()
def init() -> None:
    """Initialize a .project-hub workspace in the current directory."""
    _do_init(Path.cwd())


@main.command("sync-now")
@click.pass_context
def sync_now(ctx: click.Context) -> None:
    """Force a workspace synchronization from the CLI."""
    asyncio.run(_do_sync_now())


async def _do_sync_now() -> None:
    from .core.workspace import Workspace, WorkspaceState, detect_state

    state = detect_state(Path.cwd())
    if state != WorkspaceState.ACTIVE:
        click.echo(
            "No active workspace found. Run from a directory with .project-hub/",
            err=True,
        )
        sys.exit(1)

    ws = Workspace(Path.cwd())
    await ws.start()
    click.echo("Synchronizing workspace...")
    await ws.refresh_once()
    await ws.stop()
    click.echo("Sync complete.")


# ---------------------------------------------------------------------------
# auth group
# ---------------------------------------------------------------------------


@main.group()
def auth() -> None:
    """Manage authentication."""


@auth.command("login")
@click.argument("instance")
def auth_login(instance: str) -> None:
    """Authenticate with a forge instance."""
    import gitlab
    from .gitlab.auth import store_token

    token = click.prompt(f"Personal Access Token for {instance}", hide_input=True)

    try:
        gl = gitlab.Gitlab(f"https://{instance}", private_token=token)
        gl.auth()
        user = gl.user.username
    except Exception as e:
        click.echo(f"Authentication failed: {e}", err=True)
        sys.exit(1)

    store_token(instance, token)
    click.echo(f"Authenticated as @{user} on {instance}")


@main.command()
@click.argument("repo")
def exclude(repo: str) -> None:
    """Exclude a repo from the workspace."""
    import yaml

    config_path = Path.cwd() / ".project-hub" / "config.yaml"
    if not config_path.exists():
        click.echo("No .project-hub/config.yaml found. Are you in a workspace?", err=True)
        sys.exit(1)

    raw: dict = yaml.safe_load(config_path.read_text()) or {}
    excluded: list[str] = raw.get("exclude") or []

    if repo in excluded:
        click.echo(f"{repo} is already excluded.")
        return

    excluded.append(repo)
    raw["exclude"] = excluded
    config_path.write_text(yaml.dump(raw, default_flow_style=False))
    click.echo(f"Excluded {repo}.")


@main.command("include")
@click.argument("repo")
def include_repo(repo: str) -> None:
    """Re-include a previously excluded repo."""
    import yaml

    config_path = Path.cwd() / ".project-hub" / "config.yaml"
    if not config_path.exists():
        click.echo("No .project-hub/config.yaml found. Are you in a workspace?", err=True)
        sys.exit(1)

    raw: dict = yaml.safe_load(config_path.read_text()) or {}
    excluded: list[str] = raw.get("exclude") or []

    if repo not in excluded:
        click.echo(f"{repo} is not in the exclude list.")
        return

    excluded.remove(repo)
    raw["exclude"] = excluded
    config_path.write_text(yaml.dump(raw, default_flow_style=False))
    click.echo(f"Re-included {repo}.")


@auth.command("status")
def auth_status_cmd() -> None:
    """Show authentication status."""
    from .gitlab.auth import auth_status

    statuses = auth_status()
    if not statuses:
        click.echo("No stored credentials.")
        return
    for s in statuses:
        marker = "authenticated" if s.authenticated else "not authenticated"
        click.echo(f"  {s.instance}: {marker}")
