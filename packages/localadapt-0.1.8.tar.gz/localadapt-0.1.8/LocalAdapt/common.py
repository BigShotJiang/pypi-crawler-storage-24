from enum import Enum

class Color(Enum):
    RESET = "\033[0m"
    RED = "\033[31m"
    GREEN = "\033[32m"
    YELLOW = "\033[33m"
    BLUE = "\033[34m"
    MAGENTA = "\033[35m"
    CYAN = "\033[36m"
    WHITE = "\033[37m"

def print_col(txt, col:Color, pref="", suff=""):
    print(f"{pref}{col.value}{txt}{Color.RESET.value}{suff}")