import subprocess
import sys
from . import common
import shutil

# ===========================
# Hilfsfunktionen
# ===========================

def run(cmd):
    """Führt Shell-Befehle aus und bricht bei Fehlern ab."""
    common.print_col(cmd, common.Color.CYAN, pref="> ")
    result = subprocess.run(cmd, shell=True)
    if result.returncode != 0:
        common.print_col(f"Fehler beim Ausführen: {cmd}", common.Color.RED)
        sys.exit(1)

def main():
    common.print_col("Upgrading pip if necessary...", common.Color.BLUE)
    run("python.exe -m pip install --upgrade pip")

    common.print_col("Checking CUDA avaibility...", common.Color.BLUE)
    cuda_available = False
    if shutil.which("nvidia-smi") is not None:
        try:
            output = subprocess.check_output("nvidia-smi", shell=True)
            if b"NVIDIA" in output:
                cuda_available = True
        except subprocess.CalledProcessError:
            cuda_available = False

    packages = ["transformers", "Pillow"]

    if cuda_available:
        common.print_col("CUDA-enabled GPU detected! Install PyTorch with CUDA...", common.Color.BLUE)
        packages.append("torch --index-url https://download.pytorch.org/whl/cu121")
    else:
        common.print_col("No CUDA GPU found. Installing CPU version of PyTorch...", common.Color.YELLOW)
        packages.append("torch")

    for pkg in packages:
        run(f"{sys.executable} -m pip install {pkg}")

    common.print_col("Installation abgeschlossen ✅", common.Color.GREEN)
