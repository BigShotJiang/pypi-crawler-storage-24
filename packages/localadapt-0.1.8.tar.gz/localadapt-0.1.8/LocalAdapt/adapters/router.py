from .base_adapter import BaseAdapter, Value
import os

log = int(os.getenv("LOCALADAPT_LOG_LVL", "0")) == 1

class Router:
    def __init__(self):
        self.adapters:list[BaseAdapter] = []

    def register_adapter(self, adapter:BaseAdapter):
        self.adapters.append(adapter)
    
    def route(self, request:dict):
        if log: print("Routing request..")
        for adapter in self.adapters:
            if adapter.supports(request):
                if adapter.model is None:
                    adapter.load(adapter.register_model(**request.get("model_kwargs", {})))
                return adapter.run(request)
        raise ValueError(f"Couldn't find adapter for request: {request}")