# Tests for labbstart
