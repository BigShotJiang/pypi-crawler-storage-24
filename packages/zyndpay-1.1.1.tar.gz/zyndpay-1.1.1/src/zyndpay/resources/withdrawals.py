from typing import Optional


class Withdrawals:
    """Request and track withdrawals from your balance."""

    def __init__(self, client):
        self._client = client

    def create(
        self,
        amount: str,
        address_id: str = None,
        idempotency_key: str = None,
    ) -> dict:
        """
        Request a withdrawal from your balance.

        Args:
            amount: Amount to withdraw in USDT, e.g. "100.00"
            address_id: ID of saved payout address (optional)
            idempotency_key: Unique key to prevent duplicate requests

        Returns:
            Withdrawal object with status, amount, etc.
        """
        body = {"amount": amount}
        if address_id is not None:
            body["addressId"] = address_id

        res = self._client.post("/withdrawals", json=body, idempotency_key=idempotency_key)
        return res["data"]

    def get(self, withdrawal_id: str) -> dict:
        """Get a withdrawal by ID."""
        res = self._client.get(f"/withdrawals/{withdrawal_id}")
        return res["data"]

    def list(
        self,
        page: int = None,
        limit: int = None,
        status: str = None,
    ) -> dict:
        """
        List withdrawals with optional filters.

        Returns:
            Dict with "data" (list) and "meta" (pagination).
        """
        res = self._client.get("/withdrawals", params={"page": page, "limit": limit, "status": status})
        return {"data": res["data"], "meta": res.get("meta")}

    def cancel(self, withdrawal_id: str) -> None:
        """Cancel a pending withdrawal."""
        self._client.delete(f"/withdrawals/{withdrawal_id}")
