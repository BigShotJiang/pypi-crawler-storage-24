from typing import Any, Dict, Optional


class Payouts:
    """Initiate and track payouts."""

    def __init__(self, client):
        self._client = client

    def create(
        self,
        amount: str,
        destination_address: str,
        currency: str = "USDT_TRC20",
        chain: str = "TRON",
        external_ref: str = None,
        metadata: Dict[str, Any] = None,
        idempotency_key: str = None,
    ) -> dict:
        """
        Initiate a payout.

        Args:
            amount: Amount in USDT (minimum 20 USDT), e.g. "100"
            destination_address: TRON destination address
            currency: Currency (default: USDT_TRC20)
            chain: Chain (default: TRON)
            external_ref: Your internal reference ID
            metadata: Arbitrary metadata
            idempotency_key: Unique key to prevent duplicate requests

        Returns:
            Dict with transactionId, status, processingFee, requiresManualApproval, etc.
        """
        body = {
            "amount": amount,
            "destinationAddress": destination_address,
            "currency": currency,
            "chain": chain,
        }
        if external_ref is not None:
            body["externalRef"] = external_ref
        if metadata is not None:
            body["metadata"] = metadata

        res = self._client.post("/payout", json=body, idempotency_key=idempotency_key)
        return res["data"]

    def get(self, payout_id: str) -> dict:
        """Get a payout by ID."""
        res = self._client.get(f"/payout/{payout_id}")
        return res["data"]

    def list(
        self,
        page: int = None,
        limit: int = None,
    ) -> dict:
        """
        List payouts with optional filters.

        Returns:
            Dict with "items" (list) and "total" (int).
        """
        res = self._client.get("/payout", params={"page": page, "limit": limit})
        return res["data"]
