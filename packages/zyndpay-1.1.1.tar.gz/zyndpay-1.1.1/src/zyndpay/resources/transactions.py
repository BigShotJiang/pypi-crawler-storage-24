from typing import Optional


class Transactions:
    """View transaction history."""

    def __init__(self, client):
        self._client = client

    def get(self, transaction_id: str) -> dict:
        """Get a transaction by ID."""
        res = self._client.get(f"/transactions/{transaction_id}")
        return res["data"]

    def list(
        self,
        page: int = None,
        limit: int = None,
        type: str = None,
        status: str = None,
        from_date: str = None,
        to_date: str = None,
    ) -> dict:
        """
        List transactions with optional filters.

        Args:
            type: Filter by type ("PAYIN" or "PAYOUT")
            status: Filter by status
            from_date: Start date (ISO 8601)
            to_date: End date (ISO 8601)

        Returns:
            Dict with "items", "total", "page", "limit", "totalPages".
        """
        res = self._client.get(
            "/transactions",
            params={
                "page": page,
                "limit": limit,
                "type": type,
                "status": status,
                "from_date": from_date,
                "to_date": to_date,
            },
        )
        return res["data"]
