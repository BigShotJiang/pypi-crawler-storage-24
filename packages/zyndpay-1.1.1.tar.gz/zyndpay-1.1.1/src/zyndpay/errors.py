class ZyndPayError(Exception):
    """Base error for all ZyndPay API errors."""

    def __init__(self, message: str, status_code: int = 0, request_id: str = None):
        super().__init__(message)
        self.status_code = status_code
        self.request_id = request_id


class AuthenticationError(ZyndPayError):
    """Raised when the API key is invalid or missing."""

    def __init__(self, message: str = "Invalid API key", request_id: str = None):
        super().__init__(message, 401, request_id)


class ValidationError(ZyndPayError):
    """Raised when request parameters are invalid."""

    def __init__(self, message: str, request_id: str = None):
        super().__init__(message, 400, request_id)


class NotFoundError(ZyndPayError):
    """Raised when the requested resource does not exist."""

    def __init__(self, message: str = "Resource not found", request_id: str = None):
        super().__init__(message, 404, request_id)


class RateLimitError(ZyndPayError):
    """Raised when rate limit is exceeded."""

    def __init__(self, message: str = "Rate limit exceeded", retry_after: int = None, request_id: str = None):
        super().__init__(message, 429, request_id)
        self.retry_after = retry_after
