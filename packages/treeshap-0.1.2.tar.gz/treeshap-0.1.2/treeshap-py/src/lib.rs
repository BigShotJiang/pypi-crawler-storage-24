//! Python bindings for the TreeSHAP Rust library.
#![allow(clippy::useless_conversion)]

use numpy::{IntoPyArray, PyArray1, PyArray2, PyReadonlyArray2};
use pyo3::prelude::*;
use pyo3::types::PyDict;

use treeshap_core::{BaseValue, Explainer, ShapMode, ShapOutput};

fn to_pyerr<E: std::fmt::Display>(e: E) -> PyErr {
    pyo3::exceptions::PyValueError::new_err(e.to_string())
}

/// A validated tree ensemble model loaded from a file.
#[pyclass(name = "TreeEnsemble")]
struct PyTreeEnsemble {
    inner: treeshap_core::TreeEnsemble,
}

#[pymethods]
impl PyTreeEnsemble {
    /// Load a model from a file.
    #[staticmethod]
    fn from_file(path: &str, format: &str) -> PyResult<Self> {
        let ensemble = match format {
            "xgboost" => treeshap_io::parse_xgboost_json_from_path(path).map_err(to_pyerr)?,
            "lgbm" => treeshap_io::parse_lightgbm_text_from_path(path).map_err(to_pyerr)?,
            "onnx" => treeshap_io::parse_onnx_from_path(path).map_err(to_pyerr)?,
            other => {
                return Err(pyo3::exceptions::PyValueError::new_err(format!(
                    "Unknown format '{other}'. Use: xgboost, lgbm, onnx"
                )));
            }
        };
        Ok(Self { inner: ensemble })
    }

    #[getter]
    fn n_trees(&self) -> usize {
        self.inner.n_trees()
    }

    #[getter]
    fn n_features(&self) -> usize {
        self.inner.n_features()
    }

    #[getter]
    fn base_score(&self) -> f64 {
        self.inner.base_score()
    }

    #[getter]
    fn feature_names(&self) -> Option<Vec<String>> {
        self.inner.feature_names().map(|n| n.to_vec())
    }
}

/// SHAP explainer for tree ensemble models.
#[pyclass(name = "ShapExplainer")]
struct PyShapExplainer {
    ensemble: treeshap_core::TreeEnsemble,
    mode: String,
    background: Option<ndarray::Array2<f64>>,
    max_background_samples: usize,
}

#[pymethods]
impl PyShapExplainer {
    #[new]
    #[pyo3(signature = (model, mode="tree_path", background=None, max_background_samples=100))]
    fn new(
        model: &PyTreeEnsemble,
        mode: &str,
        background: Option<PyReadonlyArray2<f64>>,
        max_background_samples: usize,
    ) -> PyResult<Self> {
        let bg = background.map(|b| b.as_array().to_owned());
        Ok(Self {
            ensemble: model.inner.clone(),
            mode: mode.to_string(),
            background: bg,
            max_background_samples,
        })
    }

    /// Compute SHAP values. Releases the GIL during computation.
    fn explain<'py>(
        &self,
        py: Python<'py>,
        x: PyReadonlyArray2<'py, f64>,
    ) -> PyResult<PyShapExplanation> {
        let x_array = x.as_array();
        let shap_mode = self.build_mode()?;
        let explainer = Explainer::with_mode(&self.ensemble, shap_mode);
        let explanation = py.allow_threads(|| explainer.explain(x_array));
        Ok(PyShapExplanation { inner: explanation })
    }
}

impl PyShapExplainer {
    fn build_mode(&self) -> PyResult<ShapMode> {
        match self.mode.as_str() {
            "tree_path" => Ok(ShapMode::TreePathDependent),
            "interventional" => {
                let bg = self.background.as_ref().ok_or_else(|| {
                    pyo3::exceptions::PyValueError::new_err(
                        "background required for interventional mode",
                    )
                })?;
                Ok(ShapMode::Interventional {
                    background: bg.clone(),
                    max_background_samples: self.max_background_samples,
                    seed: Some(42),
                })
            }
            other => Err(pyo3::exceptions::PyValueError::new_err(format!(
                "Unknown mode '{other}'. Use: tree_path, interventional"
            ))),
        }
    }
}

/// Result of a SHAP computation.
#[pyclass(name = "ShapExplanation")]
struct PyShapExplanation {
    inner: treeshap_core::ShapExplanation,
}

#[pymethods]
impl PyShapExplanation {
    #[getter]
    fn shap_values<'py>(&self, py: Python<'py>) -> Bound<'py, PyArray2<f64>> {
        let arr = match self.inner.shap_values() {
            ShapOutput::Flat(a) => a.to_owned(),
            ShapOutput::Multiclass { values, .. } => values.to_owned(),
            _ => ndarray::Array2::<f64>::zeros((0, 0)),
        };
        arr.into_pyarray_bound(py)
    }

    #[getter]
    fn base_value(&self) -> PyResult<PyObject> {
        Python::with_gil(|py| match self.inner.base_value() {
            BaseValue::Scalar(v) => Ok((*v).to_object(py)),
            BaseValue::Vector(v) => Ok(v.to_vec().to_object(py)),
            _ => Ok(py.None()),
        })
    }

    #[getter]
    fn predictions<'py>(&self, py: Python<'py>) -> Bound<'py, PyArray1<f64>> {
        self.inner.predictions().to_owned().into_pyarray_bound(py)
    }

    #[getter]
    fn feature_names(&self) -> Option<Vec<String>> {
        self.inner.feature_names().map(|n| n.to_vec())
    }

    #[getter]
    fn n_samples(&self) -> usize {
        self.inner.n_samples()
    }

    #[getter]
    fn n_features(&self) -> usize {
        self.inner.n_features()
    }

    #[pyo3(signature = (sample_idx=0, max_display=10))]
    fn plot_waterfall(&self, sample_idx: usize, max_display: usize) -> PyResult<Vec<u8>> {
        treeshap_viz::waterfall(
            &self.inner,
            sample_idx,
            max_display,
            &treeshap_viz::RenderTarget::InMemory,
        )
        .map_err(to_pyerr)
    }

    #[pyo3(signature = (max_display=10))]
    fn plot_beeswarm(&self, max_display: usize) -> PyResult<Vec<u8>> {
        treeshap_viz::beeswarm(
            &self.inner,
            max_display,
            &treeshap_viz::RenderTarget::InMemory,
        )
        .map_err(to_pyerr)
    }

    #[pyo3(signature = (max_display=10))]
    fn plot_importance(&self, max_display: usize) -> PyResult<Vec<u8>> {
        treeshap_viz::summary_bar(
            &self.inner,
            max_display,
            &treeshap_viz::RenderTarget::InMemory,
        )
        .map_err(to_pyerr)
    }

    #[pyo3(signature = (tolerance=1e-7))]
    fn verify(&self, tolerance: f64) -> PyResult<PyObject> {
        let report = self.inner.verify_with_tolerance(tolerance);
        Python::with_gil(|py| {
            let dict = PyDict::new_bound(py);
            dict.set_item("status", if report.is_pass() { "pass" } else { "fail" })?;
            dict.set_item("n_samples", report.n_samples())?;
            dict.set_item("n_passing", report.n_passing())?;
            dict.set_item("n_failing", report.n_failing())?;
            Ok(dict.into_any().unbind())
        })
    }
}

#[pymodule]
fn _treeshap(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_class::<PyTreeEnsemble>()?;
    m.add_class::<PyShapExplainer>()?;
    m.add_class::<PyShapExplanation>()?;
    Ok(())
}
