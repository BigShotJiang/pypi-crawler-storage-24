#![warn(missing_docs)]

//! Visualization helpers for SHAP values.
//!
//! Provides three plot types matching the Python SHAP library conventions:
//!
//! - `summary_bar` — horizontal bar chart of global feature importance
//! - `waterfall` — per-sample cumulative contribution breakdown
//! - `beeswarm` — dot-plot of all samples colored by feature value
//!
//! All plots render to SVG (in-memory or to file) using a lightweight
//! built-in SVG writer with no external rendering dependencies.

pub mod beeswarm;
pub mod color;
pub mod error;
pub mod render;
pub mod summary;
pub mod waterfall;

pub use beeswarm::beeswarm;
pub use error::RenderError;
pub use render::RenderTarget;
pub use summary::summary_bar;
pub use waterfall::waterfall;

/// Returns the crate version at compile time.
#[must_use]
pub const fn version() -> &'static str {
    env!("CARGO_PKG_VERSION")
}
