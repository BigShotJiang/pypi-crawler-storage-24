//! Error types for the visualization layer.

/// Errors that can occur during plot rendering.
#[derive(Debug, thiserror::Error)]
#[non_exhaustive]
pub enum RenderError {
    /// The requested sample index is out of bounds.
    #[error("sample index {index} out of bounds (n_samples = {n_samples})")]
    SampleIndexOutOfBounds {
        /// The requested index.
        index: usize,
        /// Total number of samples.
        n_samples: usize,
    },

    /// An I/O error occurred while writing the output file.
    #[error("I/O error: {0}")]
    IoError(#[from] std::io::Error),
}
