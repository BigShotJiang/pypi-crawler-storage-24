//! Color constants and utilities for SHAP visualizations.
//!
//! Colors match the Python SHAP library convention for visual consistency
//! across ecosystems.

/// An RGB color.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct Rgb {
    /// Red channel (0–255).
    pub r: u8,
    /// Green channel (0–255).
    pub g: u8,
    /// Blue channel (0–255).
    pub b: u8,
}

impl Rgb {
    /// Creates a new RGB color.
    #[must_use]
    pub const fn new(r: u8, g: u8, b: u8) -> Self {
        Self { r, g, b }
    }

    /// Returns the color as a CSS `rgb(r,g,b)` string.
    #[must_use]
    pub fn to_css(&self) -> String {
        format!("rgb({},{},{})", self.r, self.g, self.b)
    }

    /// Linearly interpolates between `self` and `other` at parameter `t` in \[0, 1\].
    #[must_use]
    pub fn lerp(&self, other: &Rgb, t: f64) -> Rgb {
        let t = t.clamp(0.0, 1.0);
        let r = (self.r as f64 * (1.0 - t) + other.r as f64 * t).round() as u8;
        let g = (self.g as f64 * (1.0 - t) + other.g as f64 * t).round() as u8;
        let b = (self.b as f64 * (1.0 - t) + other.b as f64 * t).round() as u8;
        Rgb::new(r, g, b)
    }
}

/// Red — positive SHAP contributions. Matches Python SHAP `#d62728`.
pub const POSITIVE_COLOR: Rgb = Rgb::new(214, 39, 40);

/// Blue — negative SHAP contributions. Matches Python SHAP `#1f77b4`.
pub const NEGATIVE_COLOR: Rgb = Rgb::new(31, 119, 180);

/// Blue end of beeswarm diverging colormap (low feature values).
pub const BEESWARM_LOW: Rgb = Rgb::new(35, 116, 181);

/// Gray midpoint of beeswarm diverging colormap.
pub const BEESWARM_MID: Rgb = Rgb::new(180, 180, 180);

/// Red end of beeswarm diverging colormap (high feature values).
pub const BEESWARM_HIGH: Rgb = Rgb::new(214, 39, 40);

/// Gray for missing / NaN feature values in beeswarm.
pub const MISSING_COLOR: Rgb = Rgb::new(128, 128, 128);

/// Maps a normalized value in \[0, 1\] to the beeswarm diverging colormap.
/// 0.0 → blue, 0.5 → gray, 1.0 → red.
#[must_use]
pub fn beeswarm_color(normalized: f64) -> Rgb {
    if normalized.is_nan() {
        return MISSING_COLOR;
    }
    let t = normalized.clamp(0.0, 1.0);
    if t <= 0.5 {
        BEESWARM_LOW.lerp(&BEESWARM_MID, t * 2.0)
    } else {
        BEESWARM_MID.lerp(&BEESWARM_HIGH, (t - 0.5) * 2.0)
    }
}
