//! Waterfall plot — per-sample feature contribution breakdown.
//!
//! Shows how each feature's SHAP value pushes the prediction from the
//! base value (E\[f(x)\]) to the final output, rendered as cumulative bars.

use treeshap_core::explainer::{BaseValue, ShapOutput};
use treeshap_core::explanation::ShapExplanation;

use crate::color::{Rgb, NEGATIVE_COLOR, POSITIVE_COLOR};
use crate::error::RenderError;
use crate::render::{
    RenderTarget, SvgBuilder, FONT_SIZE_ANNOTATION, FONT_SIZE_LABEL, FONT_SIZE_TITLE,
};

/// Renders a waterfall plot for a single sample.
///
/// # Arguments
///
/// * `explanation` — the SHAP explanation.
/// * `sample_idx` — which sample to plot.
/// * `max_display` — max features to show (rest aggregated as "N other features").
/// * `target` — where to write the output.
pub fn waterfall(
    explanation: &ShapExplanation,
    sample_idx: usize,
    max_display: usize,
    target: &RenderTarget,
) -> Result<Vec<u8>, RenderError> {
    if sample_idx >= explanation.n_samples() {
        return Err(RenderError::SampleIndexOutOfBounds {
            index: sample_idx,
            n_samples: explanation.n_samples(),
        });
    }

    let n_features = explanation.n_features();
    let shap_row = extract_shap_row(explanation, sample_idx);

    let base_val = match explanation.base_value() {
        BaseValue::Scalar(v) => *v,
        BaseValue::Vector(v) => v.iter().sum(),
        _ => 0.0,
    };
    let prediction = explanation.predictions()[sample_idx];

    // Sort features by absolute SHAP value.
    let mut sorted: Vec<(usize, f64)> = shap_row.iter().enumerate().map(|(i, &v)| (i, v)).collect();
    sorted.sort_by(|a, b| {
        b.1.abs()
            .partial_cmp(&a.1.abs())
            .unwrap_or(std::cmp::Ordering::Equal)
    });

    // Split into displayed and aggregated.
    let (displayed, rest) = if n_features > max_display {
        let shown = &sorted[..max_display.saturating_sub(1)];
        let remaining: f64 = sorted[max_display.saturating_sub(1)..]
            .iter()
            .map(|&(_, v)| v)
            .sum();
        (shown.to_vec(), Some(remaining))
    } else {
        (sorted.clone(), None)
    };

    // Build entries: list of (label, shap_value) from bottom to top.
    let mut entries: Vec<(String, f64)> = Vec::new();
    for &(feat_idx, shap_val) in displayed.iter().rev() {
        let name = feature_label(explanation, feat_idx, sample_idx);
        entries.push((name, shap_val));
    }
    if let Some(rest_val) = rest {
        let n_rest = n_features - (max_display - 1);
        entries.insert(0, (format!("{n_rest} other features"), rest_val));
    }

    // Layout.
    let left_margin = 180.0;
    let right_margin = 80.0;
    let top_margin = 50.0;
    let bottom_margin = 30.0;
    let row_height = 28.0;
    let n_rows = entries.len();
    let plot_width = 700.0;
    let plot_height = top_margin + (n_rows as f64) * row_height + bottom_margin + 30.0;
    let bar_area = plot_width - left_margin - right_margin;

    // Compute cumulative positions.
    let mut cumulative = vec![0.0_f64; n_rows + 1];
    cumulative[0] = base_val;
    for (i, (_, shap_val)) in entries.iter().enumerate() {
        cumulative[i + 1] = cumulative[i] + shap_val;
    }

    let all_vals = cumulative.to_vec();
    let min_val = all_vals.iter().cloned().fold(f64::INFINITY, f64::min);
    let max_val = all_vals.iter().cloned().fold(f64::NEG_INFINITY, f64::max);
    let range = (max_val - min_val).max(1e-10);
    let scale = bar_area / range;

    let x_of = |val: f64| left_margin + (val - min_val) * scale;

    let mut svg = SvgBuilder::new(plot_width, plot_height);

    // Title.
    svg.text(
        plot_width / 2.0,
        top_margin - 20.0,
        &format!("f(x) = {prediction:.4}"),
        FONT_SIZE_TITLE,
        "middle",
    );

    let gray = Rgb::new(180, 180, 180);

    // Draw bars bottom to top.
    for (i, (label, shap_val)) in entries.iter().enumerate() {
        let y = top_margin + ((n_rows - 1 - i) as f64) * row_height;
        let start = cumulative[i];
        let end = cumulative[i + 1];

        let x_start = x_of(start.min(end));
        let bar_w = (end - start).abs() * scale;
        let color = if *shap_val >= 0.0 {
            &POSITIVE_COLOR
        } else {
            &NEGATIVE_COLOR
        };

        // Bar.
        svg.rect(x_start, y + 4.0, bar_w, row_height - 8.0, color);

        // Feature label.
        svg.text(
            left_margin - 8.0,
            y + row_height / 2.0 + 4.0,
            label,
            FONT_SIZE_LABEL,
            "end",
        );

        // Connector line to next bar.
        if i + 1 < n_rows {
            let connector_y = y + row_height;
            svg.line(
                x_of(end),
                connector_y - row_height + 4.0,
                x_of(end),
                connector_y + 4.0,
                &gray,
                0.8,
                true,
            );
        }
    }

    // Base value anchor (dashed line at bottom).
    let base_x = x_of(base_val);
    svg.line(
        base_x,
        top_margin,
        base_x,
        top_margin + (n_rows as f64) * row_height,
        &gray,
        1.0,
        true,
    );
    svg.text(
        base_x,
        top_margin + (n_rows as f64) * row_height + 16.0,
        &format!("E[f(x)] = {base_val:.4}"),
        FONT_SIZE_ANNOTATION,
        "middle",
    );

    svg.write_to(target)
}

/// Extracts the SHAP row for a sample (flattened for multiclass).
fn extract_shap_row(explanation: &ShapExplanation, sample_idx: usize) -> Vec<f64> {
    let n_features = explanation.n_features();
    match explanation.shap_values() {
        ShapOutput::Flat(arr) => arr.row(sample_idx).to_vec(),
        ShapOutput::Multiclass { values, n_classes } => {
            let row = values.row(sample_idx);
            (0..n_features)
                .map(|f| (0..*n_classes).map(|c| row[c * n_features + f]).sum())
                .collect()
        }
        _ => vec![0.0; n_features],
    }
}

/// Returns a label like "feature_name = value" for a feature.
fn feature_label(explanation: &ShapExplanation, feat_idx: usize, sample_idx: usize) -> String {
    let name = explanation
        .feature_names()
        .and_then(|n| n.get(feat_idx))
        .cloned()
        .unwrap_or_else(|| format!("Feature {feat_idx}"));

    let truncated = if name.chars().count() > 20 {
        let short: String = name.chars().take(17).collect();
        format!("{short}...")
    } else {
        name
    };

    if let Some(fv) = explanation.feature_values() {
        let val = fv[[sample_idx, feat_idx]];
        if !val.is_finite() {
            truncated
        } else if val.fract() == 0.0 && val.abs() < 1e12 {
            format!("{truncated} = {val:.0}")
        } else {
            format!("{truncated} = {val:.2}")
        }
    } else {
        truncated
    }
}
