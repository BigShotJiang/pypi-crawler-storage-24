//! Rendering targets and SVG generation utilities.

use std::fmt::Write;
use std::path::PathBuf;

use crate::color::Rgb;
use crate::error::RenderError;

/// Where to write the rendered output.
#[derive(Debug, Clone)]
pub enum RenderTarget {
    /// Write SVG to a file path.
    Svg {
        /// Output file path.
        path: PathBuf,
    },
    /// Return SVG as in-memory bytes (no filesystem I/O).
    InMemory,
}

/// Font size constants (in SVG user units / points).
pub const FONT_SIZE_TITLE: f64 = 14.0;
/// Standard label font size.
pub const FONT_SIZE_LABEL: f64 = 12.0;
/// Small annotation font size.
pub const FONT_SIZE_ANNOTATION: f64 = 10.0;

/// A minimal SVG document builder.
///
/// Accumulates SVG elements as a string and can finalize to bytes.
pub struct SvgBuilder {
    width: f64,
    height: f64,
    body: String,
}

impl SvgBuilder {
    /// Creates a new SVG canvas with the given dimensions.
    #[must_use]
    pub fn new(width: f64, height: f64) -> Self {
        Self {
            width,
            height,
            body: String::with_capacity(4096),
        }
    }

    /// Adds a filled rectangle.
    pub fn rect(&mut self, x: f64, y: f64, w: f64, h: f64, fill: &Rgb) {
        let (x, y, w, h) = (svg_num(x), svg_num(y), svg_num(w), svg_num(h));
        let _ = write!(
            self.body,
            r#"<rect x="{x:.2}" y="{y:.2}" width="{w:.2}" height="{h:.2}" fill="{}"/>"#,
            fill.to_css()
        );
    }

    /// Adds a line.
    #[allow(clippy::too_many_arguments)]
    pub fn line(
        &mut self,
        x1: f64,
        y1: f64,
        x2: f64,
        y2: f64,
        stroke: &Rgb,
        width: f64,
        dashed: bool,
    ) {
        let (x1, y1, x2, y2) = (svg_num(x1), svg_num(y1), svg_num(x2), svg_num(y2));
        let width = svg_num(width);
        let dash = if dashed {
            r#" stroke-dasharray="4,3""#
        } else {
            ""
        };
        let _ = write!(
            self.body,
            r#"<line x1="{x1:.2}" y1="{y1:.2}" x2="{x2:.2}" y2="{y2:.2}" stroke="{}" stroke-width="{width:.1}"{dash}/>"#,
            stroke.to_css()
        );
    }

    /// Adds a filled circle.
    pub fn circle(&mut self, cx: f64, cy: f64, r: f64, fill: &Rgb) {
        let (cx, cy, r) = (svg_num(cx), svg_num(cy), svg_num(r));
        let _ = write!(
            self.body,
            r#"<circle cx="{cx:.2}" cy="{cy:.2}" r="{r:.1}" fill="{}"/>"#,
            fill.to_css()
        );
    }

    /// Adds left-aligned text.
    pub fn text(&mut self, x: f64, y: f64, content: &str, size: f64, anchor: &str) {
        let (x, y, size) = (svg_num(x), svg_num(y), svg_num(size));
        let escaped = escape_xml(content);
        let escaped_anchor = escape_xml(anchor);
        let _ = write!(
            self.body,
            r#"<text x="{x:.2}" y="{y:.2}" font-size="{size:.1}" font-family="sans-serif" text-anchor="{escaped_anchor}">{escaped}</text>"#,
        );
    }

    /// Finalizes the SVG document and returns it as a byte vector.
    #[must_use]
    pub fn finalize(self) -> Vec<u8> {
        let mut svg = String::with_capacity(self.body.len() + 256);
        let (w, h) = (svg_num(self.width), svg_num(self.height));
        let _ = write!(
            svg,
            r#"<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="{w:.2}" height="{h:.2}" viewBox="0 0 {w:.2} {h:.2}">
<style>text {{ fill: #333; }}</style>
{}
</svg>"#,
            self.body
        );
        svg.into_bytes()
    }

    /// Writes the SVG to the render target, returning bytes for InMemory.
    pub fn write_to(self, target: &RenderTarget) -> Result<Vec<u8>, RenderError> {
        let bytes = self.finalize();
        match target {
            RenderTarget::Svg { path } => {
                std::fs::write(path, &bytes)?;
                Ok(bytes)
            }
            RenderTarget::InMemory => Ok(bytes),
        }
    }
}

/// Escapes XML special characters in text content.
fn escape_xml(s: &str) -> String {
    s.replace('&', "&amp;")
        .replace('<', "&lt;")
        .replace('>', "&gt;")
        .replace('"', "&quot;")
        .replace('\'', "&apos;")
}

/// Formats an f64 for SVG attributes, replacing NaN/Inf with 0.
fn svg_num(v: f64) -> f64 {
    if v.is_finite() {
        v
    } else {
        0.0
    }
}
