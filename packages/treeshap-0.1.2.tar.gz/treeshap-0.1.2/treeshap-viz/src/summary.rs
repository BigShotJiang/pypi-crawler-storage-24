//! Summary bar chart — global feature importance by mean |SHAP|.
//!
//! Renders a horizontal bar chart where each bar represents one feature,
//! sorted by mean absolute SHAP value (most important at top).

use treeshap_core::explainer::ShapOutput;
use treeshap_core::explanation::ShapExplanation;

use crate::color::POSITIVE_COLOR;
use crate::error::RenderError;
use crate::render::{RenderTarget, SvgBuilder, FONT_SIZE_LABEL, FONT_SIZE_TITLE};

/// Renders a summary bar chart (feature importance) to the specified target.
///
/// # Arguments
///
/// * `explanation` — the SHAP explanation to visualize.
/// * `max_display` — maximum number of features to show (default: 10).
/// * `target` — where to write the output.
///
/// # Returns
///
/// The rendered SVG as bytes.
pub fn summary_bar(
    explanation: &ShapExplanation,
    max_display: usize,
    target: &RenderTarget,
) -> Result<Vec<u8>, RenderError> {
    let n_features = explanation.n_features();
    let n_samples = explanation.n_samples();

    // Compute mean |SHAP| per feature.
    let mean_abs = compute_mean_abs_shap(explanation);

    // Sort features by importance (descending).
    let mut indices: Vec<usize> = (0..n_features).collect();
    indices.sort_by(|&a, &b| {
        mean_abs[b]
            .partial_cmp(&mean_abs[a])
            .unwrap_or(std::cmp::Ordering::Equal)
    });
    indices.truncate(max_display);

    let n_bars = indices.len();
    if n_bars == 0 {
        let svg = SvgBuilder::new(600.0, 100.0);
        return svg.write_to(target);
    }

    // Layout constants.
    let left_margin = 160.0;
    let right_margin = 80.0;
    let top_margin = 40.0;
    let bottom_margin = 30.0;
    let bar_height = 22.0;
    let bar_gap = 6.0;
    let plot_width = 600.0;
    let plot_height = top_margin + (n_bars as f64) * (bar_height + bar_gap) + bottom_margin;
    let bar_area_width = plot_width - left_margin - right_margin;

    let max_val = mean_abs[indices[0]].max(1e-10); // avoid div/0

    let mut svg = SvgBuilder::new(plot_width, plot_height);

    // Title.
    svg.text(
        plot_width / 2.0,
        top_margin - 12.0,
        "Feature Importance",
        FONT_SIZE_TITLE,
        "middle",
    );

    // Bars.
    for (rank, &feat_idx) in indices.iter().enumerate() {
        let y = top_margin + (rank as f64) * (bar_height + bar_gap);
        let bar_w = (mean_abs[feat_idx] / max_val) * bar_area_width;

        // Feature name label.
        let name = feature_name(explanation, feat_idx);
        svg.text(
            left_margin - 8.0,
            y + bar_height / 2.0 + 4.0,
            &name,
            FONT_SIZE_LABEL,
            "end",
        );

        // Bar.
        svg.rect(left_margin, y, bar_w, bar_height, &POSITIVE_COLOR);

        // Value annotation.
        svg.text(
            left_margin + bar_w + 4.0,
            y + bar_height / 2.0 + 4.0,
            &format!("{:.3}", mean_abs[feat_idx]),
            FONT_SIZE_LABEL,
            "start",
        );
    }

    // X-axis label.
    svg.text(
        left_margin + bar_area_width / 2.0,
        plot_height - 6.0,
        "mean(|SHAP value|)",
        FONT_SIZE_LABEL,
        "middle",
    );

    // Subtitle for zero contributions.
    if n_samples > 0 && mean_abs.iter().all(|&v| v < 1e-10) {
        svg.text(
            plot_width / 2.0,
            top_margin + 20.0,
            "No feature contributions",
            FONT_SIZE_LABEL,
            "middle",
        );
    }

    svg.write_to(target)
}

/// Computes mean |SHAP| per feature across all samples.
fn compute_mean_abs_shap(explanation: &ShapExplanation) -> Vec<f64> {
    let n_features = explanation.n_features();
    let n_samples = explanation.n_samples();

    if n_samples == 0 {
        return vec![0.0; n_features];
    }

    let mut sums = vec![0.0_f64; n_features];
    match explanation.shap_values() {
        ShapOutput::Flat(arr) => {
            for row in arr.rows() {
                for (j, &v) in row.iter().enumerate() {
                    sums[j] += v.abs();
                }
            }
        }
        ShapOutput::Multiclass { values, n_classes } => {
            for row in values.rows() {
                for f in 0..n_features {
                    let class_sum: f64 =
                        (0..*n_classes).map(|c| row[c * n_features + f].abs()).sum();
                    sums[f] += class_sum;
                }
            }
        }
        _ => {}
    }

    sums.iter().map(|&s| s / n_samples as f64).collect()
}

/// Returns the display name for a feature, truncated to 25 characters.
fn feature_name(explanation: &ShapExplanation, idx: usize) -> String {
    let name = explanation
        .feature_names()
        .and_then(|names| names.get(idx))
        .cloned()
        .unwrap_or_else(|| format!("Feature {idx}"));

    if name.chars().count() > 25 {
        let truncated: String = name.chars().take(22).collect();
        format!("{truncated}...")
    } else {
        name
    }
}
