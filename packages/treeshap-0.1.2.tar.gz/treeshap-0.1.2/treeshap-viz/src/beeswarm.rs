//! Beeswarm plot — per-sample SHAP values colored by feature value.
//!
//! Renders a dot-plot where each dot is one (sample, feature) pair,
//! positioned horizontally by SHAP value and colored by the normalized
//! feature value (blue=low, red=high).

use treeshap_core::explainer::ShapOutput;
use treeshap_core::explanation::ShapExplanation;

use crate::color::{beeswarm_color, Rgb, BEESWARM_HIGH, BEESWARM_LOW};
use crate::error::RenderError;
use crate::render::{RenderTarget, SvgBuilder, FONT_SIZE_LABEL, FONT_SIZE_TITLE};

/// Renders a beeswarm plot to the specified target.
///
/// # Arguments
///
/// * `explanation` — the SHAP explanation to visualize.
/// * `max_display` — maximum number of features to show.
/// * `target` — where to write the output.
pub fn beeswarm(
    explanation: &ShapExplanation,
    max_display: usize,
    target: &RenderTarget,
) -> Result<Vec<u8>, RenderError> {
    let n_features = explanation.n_features();
    let n_samples = explanation.n_samples();

    // Compute mean |SHAP| per feature for ordering.
    let mean_abs = compute_mean_abs(explanation);

    let mut feat_order: Vec<usize> = (0..n_features).collect();
    feat_order.sort_by(|&a, &b| {
        mean_abs[b]
            .partial_cmp(&mean_abs[a])
            .unwrap_or(std::cmp::Ordering::Equal)
    });
    feat_order.truncate(max_display);

    let n_rows = feat_order.len();
    if n_rows == 0 || n_samples == 0 {
        let svg = SvgBuilder::new(700.0, 100.0);
        return svg.write_to(target);
    }

    // Layout.
    let left_margin = 140.0;
    let right_margin = 80.0;
    let top_margin = 40.0;
    let bottom_margin = 40.0;
    let colorbar_width = 20.0;
    let row_height = 30.0;
    let row_half = 12.0;
    let dot_radius = 3.0;
    let plot_width = 700.0;
    let plot_height = top_margin + (n_rows as f64) * row_height + bottom_margin;
    let bar_area = plot_width - left_margin - right_margin - colorbar_width - 20.0;

    // Determine symmetric x-axis range.
    let shap_matrix = extract_flat_shap(explanation);
    let max_abs: f64 = feat_order
        .iter()
        .flat_map(|&f| {
            let sm = &shap_matrix;
            (0..n_samples).map(move |s| sm[s][f].abs())
        })
        .fold(0.0_f64, f64::max)
        .max(1e-10);
    let x_range = max_abs * 1.1;
    let x_center = left_margin + bar_area / 2.0;
    let x_scale = (bar_area / 2.0) / x_range;

    // Compute per-feature min/max for color normalization.
    let feat_vals = explanation.feature_values();
    let (feat_min, feat_max) = compute_feature_ranges(feat_vals, n_features, n_samples);

    let mut svg = SvgBuilder::new(plot_width, plot_height);

    // Title.
    svg.text(
        plot_width / 2.0 - 30.0,
        top_margin - 12.0,
        "SHAP value (impact on model output)",
        FONT_SIZE_TITLE,
        "middle",
    );

    // Zero line.
    let gray = Rgb::new(200, 200, 200);
    svg.line(
        x_center,
        top_margin,
        x_center,
        top_margin + (n_rows as f64) * row_height,
        &gray,
        0.8,
        false,
    );

    // For each feature row.
    for (rank, &feat_idx) in feat_order.iter().enumerate() {
        let row_y = top_margin + (rank as f64) * row_height + row_height / 2.0;

        // Feature name label.
        let name = feature_name(explanation, feat_idx);
        svg.text(
            left_margin - 8.0,
            row_y + 4.0,
            &name,
            FONT_SIZE_LABEL,
            "end",
        );

        // Collect dots: (shap_value, normalized_feature_value).
        let mut dots: Vec<(f64, f64)> = Vec::with_capacity(n_samples);
        for s in 0..n_samples {
            let shap_val = shap_matrix[s][feat_idx];
            let norm_fv = if let Some(fv) = feat_vals {
                let raw = fv[[s, feat_idx]];
                if raw.is_nan() {
                    f64::NAN
                } else {
                    let range = feat_max[feat_idx] - feat_min[feat_idx];
                    if range > 0.0 {
                        ((raw - feat_min[feat_idx]) / range).clamp(0.0, 1.0)
                    } else {
                        0.5
                    }
                }
            } else {
                f64::NAN
            };
            dots.push((shap_val, norm_fv));
        }

        // Sort by absolute SHAP (render least important first, most on top).
        dots.sort_by(|a, b| {
            a.0.abs()
                .partial_cmp(&b.0.abs())
                .unwrap_or(std::cmp::Ordering::Equal)
        });

        // Jitter: bin dots by x-position and stack vertically.
        let bin_width = dot_radius * 2.0 + 1.0;
        let mut bin_counts: std::collections::HashMap<i32, i32> = std::collections::HashMap::new();

        for &(shap_val, norm_fv) in &dots {
            let px = x_center + shap_val * x_scale;
            let bin = (px / bin_width).round() as i32;
            let count = bin_counts.entry(bin).or_insert(0);

            let y_offset = if *count % 2 == 0 {
                (*count as f64 / 2.0) * (dot_radius * 2.0 + 1.0)
            } else {
                -((*count as f64 + 1.0) / 2.0) * (dot_radius * 2.0 + 1.0)
            };
            let y_offset = y_offset.clamp(-row_half, row_half);
            *count += 1;

            let cy = row_y + y_offset;
            let color = beeswarm_color(norm_fv);
            svg.circle(px, cy, dot_radius, &color);
        }
    }

    // Colorbar on the right.
    let cb_x = plot_width - right_margin + 10.0;
    let cb_top = top_margin;
    let cb_height = (n_rows as f64) * row_height;
    let cb_steps = 50;
    let step_h = cb_height / cb_steps as f64;

    for i in 0..cb_steps {
        let t = 1.0 - (i as f64 / cb_steps as f64); // top = high, bottom = low
        let color = if t <= 0.5 {
            BEESWARM_LOW.lerp(&Rgb::new(180, 180, 180), t * 2.0)
        } else {
            Rgb::new(180, 180, 180).lerp(&BEESWARM_HIGH, (t - 0.5) * 2.0)
        };
        svg.rect(
            cb_x,
            cb_top + (i as f64) * step_h,
            colorbar_width,
            step_h + 0.5,
            &color,
        );
    }
    svg.text(
        cb_x + colorbar_width / 2.0,
        cb_top - 4.0,
        "High",
        10.0,
        "middle",
    );
    svg.text(
        cb_x + colorbar_width / 2.0,
        cb_top + cb_height + 14.0,
        "Low",
        10.0,
        "middle",
    );
    svg.text(
        cb_x + colorbar_width / 2.0,
        cb_top + cb_height + 28.0,
        "Feature value",
        9.0,
        "middle",
    );

    svg.write_to(target)
}

/// Extracts flat SHAP values as `Vec<Vec<f64>>` (samples x features).
fn extract_flat_shap(explanation: &ShapExplanation) -> Vec<Vec<f64>> {
    let n_features = explanation.n_features();
    match explanation.shap_values() {
        ShapOutput::Flat(arr) => arr.rows().into_iter().map(|r| r.to_vec()).collect(),
        ShapOutput::Multiclass { values, n_classes } => values
            .rows()
            .into_iter()
            .map(|row| {
                (0..n_features)
                    .map(|f| (0..*n_classes).map(|c| row[c * n_features + f]).sum())
                    .collect()
            })
            .collect(),
        _ => vec![vec![0.0; n_features]; explanation.n_samples()],
    }
}

fn compute_mean_abs(explanation: &ShapExplanation) -> Vec<f64> {
    let shap = extract_flat_shap(explanation);
    let n_features = explanation.n_features();
    let n_samples = explanation.n_samples();
    if n_samples == 0 {
        return vec![0.0; n_features];
    }
    let mut sums = vec![0.0; n_features];
    for row in &shap {
        for (j, &v) in row.iter().enumerate() {
            sums[j] += v.abs();
        }
    }
    sums.iter().map(|&s| s / n_samples as f64).collect()
}

fn compute_feature_ranges(
    feat_vals: Option<&ndarray::Array2<f64>>,
    n_features: usize,
    n_samples: usize,
) -> (Vec<f64>, Vec<f64>) {
    let mut mins = vec![f64::INFINITY; n_features];
    let mut maxs = vec![f64::NEG_INFINITY; n_features];

    if let Some(fv) = feat_vals {
        for s in 0..n_samples {
            for f in 0..n_features {
                let v = fv[[s, f]];
                if !v.is_nan() {
                    mins[f] = mins[f].min(v);
                    maxs[f] = maxs[f].max(v);
                }
            }
        }
    }

    (mins, maxs)
}

fn feature_name(explanation: &ShapExplanation, idx: usize) -> String {
    let name = explanation
        .feature_names()
        .and_then(|n| n.get(idx))
        .cloned()
        .unwrap_or_else(|| format!("Feature {idx}"));
    if name.chars().count() > 25 {
        let truncated: String = name.chars().take(22).collect();
        format!("{truncated}...")
    } else {
        name
    }
}
