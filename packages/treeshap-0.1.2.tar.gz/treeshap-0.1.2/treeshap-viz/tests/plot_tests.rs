//! Integration tests for all three plot types.

use ndarray::array;
use treeshap_core::{Explainer, MissingDirection, TaskType, TreeEnsembleBuilder, TreeNode};
use treeshap_viz::{beeswarm, summary_bar, waterfall, RenderError, RenderTarget};

/// Helper: build a 2-feature, 2-tree regression ensemble for plotting.
fn plot_ensemble() -> treeshap_core::TreeEnsemble {
    let tree1 = vec![
        TreeNode::internal(0, 0.5, 1, 2, MissingDirection::Left, 100.0),
        TreeNode::leaf(1.0, 60.0),
        TreeNode::leaf(-0.5, 40.0),
    ];
    let tree2 = vec![
        TreeNode::internal(1, 1.0, 1, 2, MissingDirection::Right, 100.0),
        TreeNode::leaf(0.3, 45.0),
        TreeNode::leaf(-0.2, 55.0),
    ];
    TreeEnsembleBuilder::new()
        .task_type(TaskType::Regression)
        .n_features(2)
        .base_score(0.0)
        .trees(vec![tree1, tree2])
        .feature_names(vec!["age".to_string(), "income".to_string()])
        .build()
        .unwrap()
}

fn make_explanation() -> treeshap_core::ShapExplanation {
    let ens = plot_ensemble();
    let explainer = Explainer::new(&ens);
    let x = array![[0.3, 0.8], [0.7, 1.5], [0.5, 0.5]];
    explainer.explain(x.view())
}

// ===================================================================
// Summary bar chart
// ===================================================================

#[test]
fn summary_bar_renders_valid_svg() {
    let explanation = make_explanation();
    let bytes = summary_bar(&explanation, 10, &RenderTarget::InMemory).unwrap();

    let svg = String::from_utf8(bytes).expect("valid UTF-8");
    assert!(
        svg.starts_with("<?xml"),
        "should start with XML declaration"
    );
    assert!(svg.contains("<svg"), "should contain SVG element");
    assert!(svg.contains("</svg>"), "should be closed");
}

#[test]
fn summary_bar_contains_feature_names() {
    let explanation = make_explanation();
    let bytes = summary_bar(&explanation, 10, &RenderTarget::InMemory).unwrap();
    let svg = String::from_utf8(bytes).unwrap();

    assert!(svg.contains("age"), "should contain feature name 'age'");
    assert!(
        svg.contains("income"),
        "should contain feature name 'income'"
    );
}

#[test]
fn summary_bar_max_display_limits_features() {
    let explanation = make_explanation();
    // Only show 1 feature
    let bytes = summary_bar(&explanation, 1, &RenderTarget::InMemory).unwrap();
    let svg = String::from_utf8(bytes).unwrap();

    // Should contain the top feature but not necessarily both.
    assert!(svg.contains("<rect"), "should have at least one bar");
}

#[test]
fn summary_bar_zero_samples() {
    let ens = TreeEnsembleBuilder::new()
        .task_type(TaskType::Regression)
        .n_features(2)
        .base_score(0.0)
        .build()
        .unwrap();
    let explainer = Explainer::new(&ens);
    let x = ndarray::Array2::<f64>::zeros((0, 2));
    let explanation = explainer.explain(x.view());

    let bytes = summary_bar(&explanation, 10, &RenderTarget::InMemory).unwrap();
    assert!(!bytes.is_empty());
}

#[test]
fn summary_bar_no_feature_names() {
    let tree = vec![
        TreeNode::internal(0, 0.5, 1, 2, MissingDirection::Left, 100.0),
        TreeNode::leaf(1.0, 60.0),
        TreeNode::leaf(-1.0, 40.0),
    ];
    let ens = TreeEnsembleBuilder::new()
        .task_type(TaskType::Regression)
        .n_features(2)
        .base_score(0.0)
        .trees(vec![tree])
        .build()
        .unwrap();
    let explainer = Explainer::new(&ens);
    let x = array![[0.3, 0.8]];
    let explanation = explainer.explain(x.view());

    let bytes = summary_bar(&explanation, 10, &RenderTarget::InMemory).unwrap();
    let svg = String::from_utf8(bytes).unwrap();
    assert!(
        svg.contains("Feature 0"),
        "should use default feature names"
    );
}

// ===================================================================
// Waterfall plot
// ===================================================================

#[test]
fn waterfall_renders_valid_svg() {
    let explanation = make_explanation();
    let bytes = waterfall(&explanation, 0, 10, &RenderTarget::InMemory).unwrap();

    let svg = String::from_utf8(bytes).expect("valid UTF-8");
    assert!(svg.starts_with("<?xml"));
    assert!(svg.contains("<svg"));
    assert!(svg.contains("</svg>"));
}

#[test]
fn waterfall_contains_base_value_label() {
    let explanation = make_explanation();
    let bytes = waterfall(&explanation, 0, 10, &RenderTarget::InMemory).unwrap();
    let svg = String::from_utf8(bytes).unwrap();

    assert!(svg.contains("E[f(x)]"), "should show base value label");
    assert!(svg.contains("f(x)"), "should show prediction label");
}

#[test]
fn waterfall_contains_feature_labels() {
    let explanation = make_explanation();
    let bytes = waterfall(&explanation, 0, 10, &RenderTarget::InMemory).unwrap();
    let svg = String::from_utf8(bytes).unwrap();

    assert!(svg.contains("age"), "should contain feature name");
}

#[test]
fn waterfall_out_of_bounds_sample() {
    let explanation = make_explanation();
    let result = waterfall(&explanation, 999, 10, &RenderTarget::InMemory);
    assert!(result.is_err());
    assert!(matches!(
        result.unwrap_err(),
        RenderError::SampleIndexOutOfBounds { .. }
    ));
}

#[test]
fn waterfall_single_feature() {
    let tree = vec![
        TreeNode::internal(0, 0.5, 1, 2, MissingDirection::Left, 100.0),
        TreeNode::leaf(1.0, 60.0),
        TreeNode::leaf(-1.0, 40.0),
    ];
    let ens = TreeEnsembleBuilder::new()
        .task_type(TaskType::Regression)
        .n_features(1)
        .base_score(0.5)
        .trees(vec![tree])
        .build()
        .unwrap();
    let explainer = Explainer::new(&ens);
    let x = array![[0.3]];
    let explanation = explainer.explain(x.view());

    let bytes = waterfall(&explanation, 0, 10, &RenderTarget::InMemory).unwrap();
    assert!(!bytes.is_empty());
}

// ===================================================================
// Beeswarm plot
// ===================================================================

#[test]
fn beeswarm_renders_valid_svg() {
    let explanation = make_explanation();
    let bytes = beeswarm(&explanation, 10, &RenderTarget::InMemory).unwrap();

    let svg = String::from_utf8(bytes).expect("valid UTF-8");
    assert!(svg.starts_with("<?xml"));
    assert!(svg.contains("<svg"));
    assert!(svg.contains("</svg>"));
}

#[test]
fn beeswarm_contains_dots() {
    let explanation = make_explanation();
    let bytes = beeswarm(&explanation, 10, &RenderTarget::InMemory).unwrap();
    let svg = String::from_utf8(bytes).unwrap();

    // 3 samples × 2 features = 6 dots
    let dot_count = svg.matches("<circle").count();
    assert!(dot_count >= 6, "expected at least 6 dots, got {dot_count}");
}

#[test]
fn beeswarm_contains_colorbar() {
    let explanation = make_explanation();
    let bytes = beeswarm(&explanation, 10, &RenderTarget::InMemory).unwrap();
    let svg = String::from_utf8(bytes).unwrap();

    assert!(svg.contains("High"), "should contain colorbar 'High' label");
    assert!(svg.contains("Low"), "should contain colorbar 'Low' label");
    assert!(
        svg.contains("Feature value"),
        "should contain colorbar title"
    );
}

#[test]
fn beeswarm_feature_names_present() {
    let explanation = make_explanation();
    let bytes = beeswarm(&explanation, 10, &RenderTarget::InMemory).unwrap();
    let svg = String::from_utf8(bytes).unwrap();

    assert!(svg.contains("age"));
    assert!(svg.contains("income"));
}

#[test]
fn beeswarm_single_sample() {
    let ens = plot_ensemble();
    let explainer = Explainer::new(&ens);
    let x = array![[0.3, 0.8]];
    let explanation = explainer.explain(x.view());

    let bytes = beeswarm(&explanation, 10, &RenderTarget::InMemory).unwrap();
    let svg = String::from_utf8(bytes).unwrap();
    assert!(
        svg.contains("<circle"),
        "single sample should still render dots"
    );
}

#[test]
fn beeswarm_zero_samples() {
    let ens = TreeEnsembleBuilder::new()
        .task_type(TaskType::Regression)
        .n_features(2)
        .base_score(0.0)
        .build()
        .unwrap();
    let explainer = Explainer::new(&ens);
    let x = ndarray::Array2::<f64>::zeros((0, 2));
    let explanation = explainer.explain(x.view());

    let bytes = beeswarm(&explanation, 10, &RenderTarget::InMemory).unwrap();
    assert!(!bytes.is_empty());
}

// ===================================================================
// Long feature names
// ===================================================================

#[test]
fn long_feature_name_truncated_in_summary() {
    let tree = vec![TreeNode::leaf(0.5, 100.0)];
    let ens = TreeEnsembleBuilder::new()
        .task_type(TaskType::Regression)
        .n_features(1)
        .base_score(0.0)
        .trees(vec![tree])
        .feature_names(vec![
            "this_is_a_very_long_feature_name_that_exceeds_the_limit".to_string(),
        ])
        .build()
        .unwrap();
    let explainer = Explainer::new(&ens);
    let x = array![[0.5]];
    let explanation = explainer.explain(x.view());

    let bytes = summary_bar(&explanation, 10, &RenderTarget::InMemory).unwrap();
    let svg = String::from_utf8(bytes).unwrap();
    assert!(svg.contains("..."), "long names should be truncated");
}

// ===================================================================
// UTF-8 feature names (Issue #8 regression test)
// ===================================================================

#[test]
fn multibyte_utf8_feature_name_does_not_panic() {
    let tree = vec![TreeNode::leaf(0.5, 100.0)];
    let ens = TreeEnsembleBuilder::new()
        .task_type(TaskType::Regression)
        .n_features(1)
        .base_score(0.0)
        .trees(vec![tree])
        .feature_names(vec!["特征名称_非常_非常_非常_长的名字".to_string()])
        .build()
        .unwrap();
    let explainer = Explainer::new(&ens);
    let x = array![[0.5]];
    let explanation = explainer.explain(x.view());

    // Should not panic on multi-byte UTF-8.
    let bytes = summary_bar(&explanation, 10, &RenderTarget::InMemory).unwrap();
    assert!(!bytes.is_empty());

    let bytes = beeswarm(&explanation, 10, &RenderTarget::InMemory).unwrap();
    assert!(!bytes.is_empty());
}

// ===================================================================
// Waterfall aggregation label
// ===================================================================

#[test]
fn waterfall_aggregation_label() {
    // 3 features, max_display=2: should show 1 feature + "2 other features"
    let tree = vec![
        TreeNode::internal(0, 0.5, 1, 2, MissingDirection::Left, 100.0),
        TreeNode::internal(1, 0.3, 3, 4, MissingDirection::Left, 60.0),
        TreeNode::leaf(-1.0, 40.0),
        TreeNode::leaf(2.0, 35.0),
        TreeNode::leaf(0.5, 25.0),
    ];
    let ens = TreeEnsembleBuilder::new()
        .task_type(TaskType::Regression)
        .n_features(3)
        .base_score(0.0)
        .trees(vec![tree])
        .build()
        .unwrap();
    let explainer = Explainer::new(&ens);
    let x = array![[0.2, 0.1, 0.5]];
    let explanation = explainer.explain(x.view());

    let bytes = waterfall(&explanation, 0, 2, &RenderTarget::InMemory).unwrap();
    let svg = String::from_utf8(bytes).unwrap();
    assert!(
        svg.contains("other features"),
        "should show aggregation label"
    );
}

// ===================================================================
// RenderTarget::Svg file write
// ===================================================================

#[test]
fn render_to_svg_file() {
    let explanation = make_explanation();
    let dir = std::env::temp_dir().join("treeshap_test");
    let _ = std::fs::create_dir_all(&dir);
    let path = dir.join("test_summary.svg");

    let bytes = summary_bar(&explanation, 10, &RenderTarget::Svg { path: path.clone() }).unwrap();
    assert!(!bytes.is_empty());

    let file_content = std::fs::read_to_string(&path).unwrap();
    assert!(file_content.contains("<svg"));

    let _ = std::fs::remove_file(&path);
}

#[test]
fn render_to_invalid_path_returns_io_error() {
    let explanation = make_explanation();
    let result = summary_bar(
        &explanation,
        10,
        &RenderTarget::Svg {
            path: "/nonexistent/dir/file.svg".into(),
        },
    );
    assert!(result.is_err());
    assert!(matches!(result.unwrap_err(), RenderError::IoError(_)));
}

// ===================================================================
// NaN feature values
// ===================================================================

#[test]
fn beeswarm_with_nan_feature_values_does_not_panic() {
    let tree = vec![
        TreeNode::internal(0, 0.5, 1, 2, MissingDirection::Left, 100.0),
        TreeNode::leaf(1.0, 60.0),
        TreeNode::leaf(-1.0, 40.0),
    ];
    let ens = TreeEnsembleBuilder::new()
        .task_type(TaskType::Regression)
        .n_features(1)
        .base_score(0.0)
        .trees(vec![tree])
        .build()
        .unwrap();
    let explainer = Explainer::new(&ens);
    let x = array![[f64::NAN]]; // NaN feature value
    let explanation = explainer.explain(x.view());

    let bytes = beeswarm(&explanation, 10, &RenderTarget::InMemory).unwrap();
    let svg = String::from_utf8(bytes).unwrap();
    // Should not contain literal "NaN" in numeric attributes.
    assert!(
        !svg.contains(r#"cx="NaN""#),
        "NaN should not appear in SVG attributes"
    );
}
