# treeshap

Exact TreeSHAP in Rust with Python bindings. Computes Shapley values for XGBoost, LightGBM, and ONNX tree ensemble models.

## Installation

```bash
pip install treeshap
```

Pre-built wheels are available for Linux (x86_64, aarch64), macOS (x86_64, Apple Silicon), and Windows (x86_64). Python 3.8+ required.

## Usage

```python
import numpy as np
from treeshap import TreeEnsemble, ShapExplainer

# Load a model
model = TreeEnsemble.from_file("model.json", "xgboost")

# Explain predictions
explainer = ShapExplainer(model)
explanation = explainer.explain(X)  # X is a numpy array

# Access results
print(explanation.shap_values)   # numpy array (n_samples, n_features)
print(explanation.base_value)    # float or list[float]
print(explanation.predictions)   # numpy array (n_samples,)

# Verify local accuracy
report = explanation.verify()
assert report.is_pass

# Generate plots (returns SVG bytes)
svg = explanation.plot_waterfall(sample_index=0)
svg = explanation.plot_beeswarm()
svg = explanation.plot_importance()
```

## Supported Formats

| Format | Loader | Example |
|:---|:---|:---|
| XGBoost JSON | `TreeEnsemble.from_file(path, "xgboost")` | `booster.save_model("model.json")` |
| LightGBM text | `TreeEnsemble.from_file(path, "lightgbm")` | `booster.save_model("model.txt")` |
| ONNX | `TreeEnsemble.from_file(path, "onnx")` | TreeEnsembleRegressor/Classifier |

## Performance

Sub-millisecond single-sample latency. 10,000 samples with 100 trees at depth 6 in 2.8 seconds on Apple M3. GIL is released during computation for full multi-core utilization.

## License

MIT OR Apache-2.0
