//! Parser for LightGBM text model dumps.
//!
//! Parses the custom line-oriented format produced by
//! `booster.model_to_string()` or `booster.save_model()`. This is not JSON
//! or TOML — it is a bespoke text format with a header block, per-tree
//! blocks delimited by `Tree=N`, and a footer.

use std::path::Path;

use treeshap_core::{MissingDirection, TaskType, TreeEnsembleBuilder, TreeNode};

use crate::error::ParseError;

const FORMAT: &str = "lightgbm";

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

/// Parses a LightGBM text model dump from a string.
///
/// # Errors
///
/// Returns [`ParseError`] if the format is malformed, required fields are
/// missing, or the resulting ensemble fails validation.
pub fn parse_lightgbm_text(text: &str) -> Result<treeshap_core::TreeEnsemble, ParseError> {
    let mut header = Header::default();
    let mut trees: Vec<RawTree> = Vec::new();
    let mut current_tree: Option<RawTree> = None;

    for line in text.lines() {
        let line = line.trim();

        if line.is_empty() || line == "end of parameters" {
            continue;
        }

        // Detect tree block start.
        if let Some(rest) = line.strip_prefix("Tree=") {
            // Flush previous tree.
            if let Some(tree) = current_tree.take() {
                trees.push(tree);
            }
            let _tree_index: usize = rest.parse().map_err(|_| ParseError::InvalidFieldType {
                format: FORMAT,
                field: "Tree=N",
                expected: "integer",
            })?;
            current_tree = Some(RawTree::default());
            continue;
        }

        // Parse key=value lines.
        if let Some((key, value)) = line.split_once('=') {
            if let Some(ref mut tree) = current_tree {
                parse_tree_line(tree, key, value)?;
            } else {
                parse_header_line(&mut header, key, value);
            }
        }
    }

    // Flush last tree.
    if let Some(tree) = current_tree.take() {
        trees.push(tree);
    }

    convert(header, trees)
}

/// Parses a LightGBM text model dump from a file path.
///
/// # Errors
///
/// Returns [`ParseError`] on I/O errors, malformed format, missing fields,
/// or validation failure.
pub fn parse_lightgbm_text_from_path(
    path: impl AsRef<Path>,
) -> Result<treeshap_core::TreeEnsemble, ParseError> {
    let text = std::fs::read_to_string(path)?;
    parse_lightgbm_text(&text)
}

// ---------------------------------------------------------------------------
// Header parsing
// ---------------------------------------------------------------------------

#[derive(Default)]
struct Header {
    num_class: Option<usize>,
    num_tree_per_iteration: Option<usize>,
    max_feature_idx: Option<usize>,
    feature_names: Option<Vec<String>>,
    average_output: Option<f64>,
}

fn parse_header_line(header: &mut Header, key: &str, value: &str) {
    match key.trim() {
        "num_class" => header.num_class = value.trim().parse().ok(),
        "num_tree_per_iteration" => header.num_tree_per_iteration = value.trim().parse().ok(),
        "max_feature_idx" => header.max_feature_idx = value.trim().parse().ok(),
        "feature_names" => {
            let names: Vec<String> = value.split_whitespace().map(String::from).collect();
            if !names.is_empty() {
                header.feature_names = Some(names);
            }
        }
        "average_output" => header.average_output = value.trim().parse().ok(),
        _ => {}
    }
}

// ---------------------------------------------------------------------------
// Tree block parsing
// ---------------------------------------------------------------------------

#[derive(Default)]
struct RawTree {
    num_leaves: Option<usize>,
    num_cat: Option<usize>,
    split_feature: Vec<usize>,
    threshold: Vec<f64>,
    left_child: Vec<i64>,
    right_child: Vec<i64>,
    decision_type: Vec<u8>,
    internal_count: Vec<f64>,
    leaf_value: Vec<f64>,
    leaf_count: Vec<f64>,
}

fn parse_tree_line(tree: &mut RawTree, key: &str, value: &str) -> Result<(), ParseError> {
    match key.trim() {
        "num_leaves" => tree.num_leaves = value.trim().parse().ok(),
        "num_cat" => tree.num_cat = value.trim().parse().ok(),
        "split_feature" => {
            tree.split_feature = parse_int_array(value)?;
        }
        "threshold" => {
            tree.threshold = parse_f64_array(value)?;
        }
        "left_child" => {
            tree.left_child = parse_signed_array(value)?;
        }
        "right_child" => {
            tree.right_child = parse_signed_array(value)?;
        }
        "decision_type" => {
            tree.decision_type = value
                .split_whitespace()
                .map(|s| {
                    s.parse::<u8>().map_err(|_| ParseError::InvalidFieldType {
                        format: FORMAT,
                        field: "decision_type",
                        expected: "u8 integer",
                    })
                })
                .collect::<Result<Vec<_>, _>>()?;
        }
        "internal_count" => {
            tree.internal_count = parse_f64_array(value)?;
        }
        "leaf_value" => {
            tree.leaf_value = parse_f64_array(value)?;
        }
        "leaf_count" => {
            tree.leaf_count = parse_f64_array(value)?;
        }
        _ => {}
    }
    Ok(())
}

fn parse_int_array(value: &str) -> Result<Vec<usize>, ParseError> {
    value
        .split_whitespace()
        .map(|s| {
            s.parse::<usize>()
                .map_err(|_| ParseError::InvalidFieldType {
                    format: FORMAT,
                    field: "integer array element",
                    expected: "non-negative integer",
                })
        })
        .collect()
}

fn parse_signed_array(value: &str) -> Result<Vec<i64>, ParseError> {
    value
        .split_whitespace()
        .map(|s| {
            s.parse::<i64>().map_err(|_| ParseError::InvalidFieldType {
                format: FORMAT,
                field: "signed integer array element",
                expected: "integer",
            })
        })
        .collect()
}

fn parse_f64_array(value: &str) -> Result<Vec<f64>, ParseError> {
    value
        .split_whitespace()
        .map(|s| {
            s.parse::<f64>().map_err(|_| ParseError::InvalidFieldType {
                format: FORMAT,
                field: "float array element",
                expected: "float",
            })
        })
        .collect()
}

// ---------------------------------------------------------------------------
// Conversion to IR
// ---------------------------------------------------------------------------

fn convert(
    header: Header,
    raw_trees: Vec<RawTree>,
) -> Result<treeshap_core::TreeEnsemble, ParseError> {
    let num_class = header.num_class.unwrap_or(1);
    let n_features = header
        .max_feature_idx
        .map(|idx| idx + 1)
        .ok_or(ParseError::MissingField {
            format: FORMAT,
            field: "max_feature_idx",
        })?;

    let task_type = if num_class > 1 {
        TaskType::MulticlassClassification {
            n_classes: num_class,
        }
    } else {
        // Distinguish binary classification from regression by looking at
        // num_tree_per_iteration. For binary classification it is 1 with
        // num_class=1. We default to regression since we cannot distinguish
        // without the objective string (which LightGBM text dumps include
        // inconsistently).
        TaskType::Regression
    };

    let base_score = header.average_output.unwrap_or(0.0);

    let mut trees = Vec::with_capacity(raw_trees.len());
    for raw in &raw_trees {
        trees.push(convert_raw_tree(raw)?);
    }

    let mut builder = TreeEnsembleBuilder::new()
        .task_type(task_type)
        .n_features(n_features)
        .base_score(base_score)
        .trees(trees);

    if let Some(names) = header.feature_names {
        builder = builder.feature_names(names);
    }

    Ok(builder.build()?)
}

fn convert_raw_tree(raw: &RawTree) -> Result<Vec<TreeNode>, ParseError> {
    let n_internal = raw.split_feature.len();
    let n_leaves = raw.leaf_value.len();

    // Validate num_leaves against actual leaf_value count when declared.
    if let Some(declared) = raw.num_leaves {
        if declared != n_leaves {
            return Err(ParseError::NodeCountMismatch {
                declared,
                found: n_leaves,
            });
        }
    }

    // Validate parallel arrays have consistent lengths.
    if raw.threshold.len() != n_internal
        || raw.left_child.len() != n_internal
        || raw.right_child.len() != n_internal
    {
        return Err(ParseError::NodeCountMismatch {
            declared: n_internal,
            found: raw.threshold.len(),
        });
    }

    let total = n_internal + n_leaves;
    let mut nodes = Vec::with_capacity(total);

    // Place internal nodes at indices 0..n_internal.
    for i in 0..n_internal {
        let left_resolved = resolve_child(raw.left_child[i], n_internal)?;
        let right_resolved = resolve_child(raw.right_child[i], n_internal)?;

        let missing_direction = if raw.decision_type.len() > i {
            // Bit 2 (value 4): if set, missing → right; else missing → left.
            if raw.decision_type[i] & 4 != 0 {
                MissingDirection::Right
            } else {
                MissingDirection::Left
            }
        } else {
            MissingDirection::Left
        };

        if raw.decision_type.len() > i && raw.decision_type[i] & 1 != 0 {
            return Err(ParseError::UnsupportedSplitType {
                split_type: "categorical".to_string(),
                format: FORMAT,
            });
        }

        let cover = if raw.internal_count.len() > i {
            raw.internal_count[i]
        } else {
            0.0
        };

        nodes.push(TreeNode::internal(
            raw.split_feature[i],
            raw.threshold[i],
            left_resolved,
            right_resolved,
            missing_direction,
            cover,
        ));
    }

    // Place leaf nodes at indices n_internal..total.
    for i in 0..n_leaves {
        let cover = if raw.leaf_count.len() > i {
            raw.leaf_count[i]
        } else {
            0.0
        };
        nodes.push(TreeNode::leaf(raw.leaf_value[i], cover));
    }

    Ok(nodes)
}

/// Resolves a LightGBM child index to a flat array index.
///
/// Non-negative values are internal node indices (used directly).
/// Negative values are leaf indices: `leaf_index = -(value + 1)`.
/// Leaf nodes are placed after all internal nodes, so the final index
/// is `n_internal + leaf_index`.
fn resolve_child(child: i64, n_internal: usize) -> Result<usize, ParseError> {
    if child >= 0 {
        Ok(child as usize)
    } else if child == i64::MIN {
        Err(ParseError::InvalidFieldType {
            format: FORMAT,
            field: "left_child/right_child",
            expected: "valid child index (i64::MIN is invalid)",
        })
    } else {
        let leaf_index = (-(child + 1)) as usize;
        Ok(n_internal + leaf_index)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn resolve_child_internal() {
        assert_eq!(resolve_child(2, 5).unwrap(), 2);
    }

    #[test]
    fn resolve_child_leaf() {
        // -1 → leaf 0 → at index n_internal + 0
        assert_eq!(resolve_child(-1, 3).unwrap(), 3);
        // -2 → leaf 1 → at index n_internal + 1
        assert_eq!(resolve_child(-2, 3).unwrap(), 4);
    }

    #[test]
    fn resolve_child_i64_min_returns_error() {
        assert!(resolve_child(i64::MIN, 3).is_err());
    }

    #[test]
    fn missing_direction_from_decision_type() {
        let no_missing_bit: u8 = 0;
        // Bit 2 not set → Left
        assert_eq!(no_missing_bit & 4, 0);
        // Bit 2 set → Right
        let missing_right: u8 = 4;
        assert_ne!(missing_right & 4, 0);
        let categorical_and_missing: u8 = 5; // bit 0 and bit 2 both set
        assert_ne!(categorical_and_missing & 4, 0);
    }
}
