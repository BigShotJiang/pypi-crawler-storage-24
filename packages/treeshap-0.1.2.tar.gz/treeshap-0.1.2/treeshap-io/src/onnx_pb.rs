//! Minimal ONNX protobuf types for parsing TreeEnsemble operators.
//!
//! These types are hand-written against the ONNX ML proto specification
//! (`onnx-ml.proto`). Only fields needed for TreeEnsemble parsing are
//! included; unused fields are silently skipped by prost during decoding.

/// Top-level ONNX model container.
#[derive(Clone, PartialEq, prost::Message)]
pub struct ModelProto {
    #[prost(int64, tag = "1")]
    pub ir_version: i64,
    #[prost(message, optional, tag = "7")]
    pub graph: Option<GraphProto>,
}

/// Computation graph containing the model's operators.
#[derive(Clone, PartialEq, prost::Message)]
pub struct GraphProto {
    #[prost(message, repeated, tag = "1")]
    pub node: Vec<NodeProto>,
    #[prost(string, tag = "2")]
    pub name: String,
}

/// A single operator invocation within the graph.
#[derive(Clone, PartialEq, prost::Message)]
pub struct NodeProto {
    #[prost(string, repeated, tag = "1")]
    pub input: Vec<String>,
    #[prost(string, repeated, tag = "2")]
    pub output: Vec<String>,
    #[prost(string, tag = "3")]
    pub name: String,
    #[prost(string, tag = "4")]
    pub op_type: String,
    #[prost(message, repeated, tag = "5")]
    pub attribute: Vec<AttributeProto>,
    #[prost(string, tag = "7")]
    pub domain: String,
}

/// An operator attribute carrying typed data.
///
/// Each attribute has a `name`, a `type` discriminator, and exactly one
/// populated value field matching that type.
#[derive(Clone, PartialEq, prost::Message)]
pub struct AttributeProto {
    /// Attribute name (e.g., "nodes_featureids").
    #[prost(string, tag = "1")]
    pub name: String,
    /// Single float value (AttributeType::FLOAT = 1).
    #[prost(float, tag = "2")]
    pub f: f32,
    /// Single int64 value (AttributeType::INT = 2).
    #[prost(int64, tag = "3")]
    pub i: i64,
    /// Single bytes/string value (AttributeType::STRING = 3).
    #[prost(bytes = "vec", tag = "4")]
    pub s: Vec<u8>,
    /// Repeated float values (AttributeType::FLOATS = 6).
    #[prost(float, repeated, tag = "7")]
    pub floats: Vec<f32>,
    /// Repeated int64 values (AttributeType::INTS = 7).
    #[prost(int64, repeated, tag = "8")]
    pub ints: Vec<i64>,
    /// Repeated bytes values (AttributeType::STRINGS = 8).
    #[prost(bytes = "vec", repeated, tag = "9")]
    pub strings: Vec<Vec<u8>>,
    /// Attribute type discriminator.
    #[prost(int32, tag = "20")]
    pub r#type: i32,
}
