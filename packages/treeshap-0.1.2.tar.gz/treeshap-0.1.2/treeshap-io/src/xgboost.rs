//! Parser for XGBoost JSON model files produced by `booster.save_model()`.
//!
//! Supports XGBoost model format versions 1.0 through 2.x. Handles the
//! base_score storage change introduced in XGBoost 1.6 (where base_score
//! is stored after an internal logit transform for classification tasks).

use std::io::Read;
use std::path::Path;

use serde::Deserialize;
use treeshap_core::{MissingDirection, TaskType, TreeEnsembleBuilder, TreeNode};

use crate::error::ParseError;

const FORMAT: &str = "xgboost";

// ---------------------------------------------------------------------------
// Serde schema for XGBoost save_model() JSON
// ---------------------------------------------------------------------------

#[derive(Deserialize)]
struct XgbModel {
    version: Vec<u32>,
    learner: Learner,
}

#[derive(Deserialize)]
struct Learner {
    learner_model_param: LearnerModelParam,
    objective: Objective,
    gradient_booster: GradientBooster,
    #[serde(default)]
    feature_names: Vec<String>,
}

#[derive(Deserialize)]
struct LearnerModelParam {
    base_score: String,
    num_feature: String,
    #[serde(default)]
    num_class: String,
}

#[derive(Deserialize)]
struct Objective {
    name: String,
}

#[derive(Deserialize)]
struct GradientBooster {
    model: GbtreeModel,
}

#[derive(Deserialize)]
struct GbtreeModel {
    trees: Vec<XgbTree>,
}

#[derive(Deserialize)]
struct XgbTree {
    base_weights: Vec<f64>,
    left_children: Vec<i64>,
    right_children: Vec<i64>,
    split_conditions: Vec<f64>,
    split_indices: Vec<u64>,
    #[serde(default)]
    split_type: Vec<u64>,
    default_left: Vec<bool>,
    sum_hessian: Vec<f64>,
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

/// Parses an XGBoost JSON model from a byte reader.
///
/// The reader should provide the contents of a file produced by
/// `booster.save_model("model.json")`.
///
/// # Errors
///
/// Returns [`ParseError`] if the JSON is malformed, required fields are
/// missing, or the resulting ensemble fails validation.
pub fn parse_xgboost_json(reader: impl Read) -> Result<treeshap_core::TreeEnsemble, ParseError> {
    let model: XgbModel = serde_json::from_reader(reader)?;
    convert_model(model)
}

/// Parses an XGBoost JSON model from a file path.
///
/// # Errors
///
/// Returns [`ParseError`] on I/O errors, malformed JSON, missing fields,
/// or validation failure.
pub fn parse_xgboost_json_from_path(
    path: impl AsRef<Path>,
) -> Result<treeshap_core::TreeEnsemble, ParseError> {
    let file = std::fs::File::open(path)?;
    let reader = std::io::BufReader::new(file);
    parse_xgboost_json(reader)
}

// ---------------------------------------------------------------------------
// Internal conversion logic
// ---------------------------------------------------------------------------

fn convert_model(model: XgbModel) -> Result<treeshap_core::TreeEnsemble, ParseError> {
    if model.version.len() < 2 {
        return Err(ParseError::SchemaVersionUnsupported {
            found: format!("{:?}", model.version),
            supported: "[major, minor, ...] with at least 2 elements",
        });
    }

    let num_class: usize = model
        .learner
        .learner_model_param
        .num_class
        .parse()
        .unwrap_or(0);
    let task_type = parse_task_type(&model.learner.objective, num_class)?;

    let n_features: usize = model
        .learner
        .learner_model_param
        .num_feature
        .parse()
        .map_err(|_| ParseError::InvalidFieldType {
            format: FORMAT,
            field: "num_feature",
            expected: "integer string",
        })?;

    let raw_base_score: f64 = model
        .learner
        .learner_model_param
        .base_score
        .parse()
        .map_err(|_| ParseError::InvalidFieldType {
            format: FORMAT,
            field: "base_score",
            expected: "float string",
        })?;

    let base_score = transform_base_score(raw_base_score, &model.version, &task_type);

    let mut trees = Vec::with_capacity(model.learner.gradient_booster.model.trees.len());
    for xgb_tree in &model.learner.gradient_booster.model.trees {
        trees.push(convert_tree(xgb_tree)?);
    }

    let feature_names = if model.learner.feature_names.is_empty() {
        None
    } else {
        Some(model.learner.feature_names)
    };

    let mut builder = TreeEnsembleBuilder::new()
        .task_type(task_type)
        .n_features(n_features)
        .base_score(base_score)
        .trees(trees);

    if let Some(names) = feature_names {
        builder = builder.feature_names(names);
    }

    Ok(builder.build()?)
}

fn parse_task_type(objective: &Objective, num_class: usize) -> Result<TaskType, ParseError> {
    match objective.name.as_str() {
        "binary:logistic" | "binary:logitraw" | "binary:hinge" => {
            Ok(TaskType::BinaryClassification)
        }
        "reg:squarederror"
        | "reg:linear"
        | "reg:squaredlogerror"
        | "reg:pseudohubererror"
        | "reg:absoluteerror"
        | "reg:quantileerror" => Ok(TaskType::Regression),
        "multi:softmax" | "multi:softprob" => {
            if num_class < 2 {
                return Err(ParseError::InvalidFieldType {
                    format: FORMAT,
                    field: "num_class",
                    expected: "integer >= 2 for multiclass",
                });
            }
            Ok(TaskType::MulticlassClassification {
                n_classes: num_class,
            })
        }
        "rank:pairwise" | "rank:ndcg" | "rank:map" => Ok(TaskType::RankedRegression),
        other => Err(ParseError::UnsupportedSplitType {
            split_type: other.to_string(),
            format: FORMAT,
        }),
    }
}

/// Applies version-dependent base_score transformation.
///
/// - XGBoost < 1.6: base_score is stored in the model's native output space.
///   For binary classification, this is a probability (e.g. 0.5). We convert
///   to log-odds via logit so the IR stores pre-transform values.
/// - XGBoost >= 1.6: base_score is already in log-odds space (the logit
///   transform was applied internally). Use directly.
/// - Regression: base_score is always used directly regardless of version.
fn transform_base_score(raw: f64, version: &[u32], task_type: &TaskType) -> f64 {
    let is_pre_1_6 = version.len() >= 2 && (version[0] < 1 || (version[0] == 1 && version[1] < 6));

    match task_type {
        TaskType::BinaryClassification if is_pre_1_6 => {
            // Pre-1.6 stores probability; convert to log-odds.
            let clamped = raw.clamp(1e-15, 1.0 - 1e-15);
            (clamped / (1.0 - clamped)).ln()
        }
        _ => raw,
    }
}

fn convert_tree(tree: &XgbTree) -> Result<Vec<TreeNode>, ParseError> {
    let n = tree.left_children.len();

    if n != tree.right_children.len()
        || n != tree.split_conditions.len()
        || n != tree.split_indices.len()
        || n != tree.default_left.len()
        || n != tree.sum_hessian.len()
        || n != tree.base_weights.len()
    {
        return Err(ParseError::NodeCountMismatch {
            declared: n,
            found: tree.base_weights.len(),
        });
    }

    let mut nodes = Vec::with_capacity(n);

    for i in 0..n {
        let is_leaf = tree.left_children[i] == -1;

        if is_leaf {
            nodes.push(TreeNode::leaf(tree.base_weights[i], tree.sum_hessian[i]));
        } else {
            // Check for categorical splits (guard against short split_type array).
            if tree.split_type.get(i).copied().unwrap_or(0) != 0 {
                return Err(ParseError::UnsupportedSplitType {
                    split_type: format!("categorical (type={})", tree.split_type[i]),
                    format: FORMAT,
                });
            }

            let missing_direction = if tree.default_left[i] {
                MissingDirection::Left
            } else {
                MissingDirection::Right
            };

            let raw_left = tree.left_children[i];
            let raw_right = tree.right_children[i];
            if raw_left < 0 || raw_right < 0 {
                return Err(ParseError::InvalidFieldType {
                    format: FORMAT,
                    field: "left_children/right_children",
                    expected: "non-negative index for internal node",
                });
            }
            let left = raw_left as usize;
            let right = raw_right as usize;

            nodes.push(TreeNode::internal(
                tree.split_indices[i] as usize,
                tree.split_conditions[i],
                left,
                right,
                missing_direction,
                tree.sum_hessian[i],
            ));
        }
    }

    Ok(nodes)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parse_task_type_binary_logistic() {
        let obj = Objective {
            name: "binary:logistic".to_string(),
        };
        assert_eq!(
            parse_task_type(&obj, 0).unwrap(),
            TaskType::BinaryClassification
        );
    }

    #[test]
    fn parse_task_type_regression() {
        let obj = Objective {
            name: "reg:squarederror".to_string(),
        };
        assert_eq!(parse_task_type(&obj, 0).unwrap(), TaskType::Regression);
    }

    #[test]
    fn parse_task_type_multiclass() {
        let obj = Objective {
            name: "multi:softmax".to_string(),
        };
        assert_eq!(
            parse_task_type(&obj, 5).unwrap(),
            TaskType::MulticlassClassification { n_classes: 5 }
        );
    }

    #[test]
    fn parse_task_type_multiclass_requires_num_class() {
        let obj = Objective {
            name: "multi:softprob".to_string(),
        };
        assert!(parse_task_type(&obj, 0).is_err());
    }

    #[test]
    fn parse_task_type_unknown_errors() {
        let obj = Objective {
            name: "unknown:objective".to_string(),
        };
        assert!(parse_task_type(&obj, 0).is_err());
    }

    #[test]
    fn base_score_pre_1_6_binary_converts_probability() {
        let version = vec![1, 4, 0];
        let bs = transform_base_score(0.5, &version, &TaskType::BinaryClassification);
        assert!(
            (bs - 0.0).abs() < 1e-10,
            "logit(0.5) should be 0.0, got {bs}"
        );
    }

    #[test]
    fn base_score_post_1_6_binary_used_directly() {
        let version = vec![2, 0, 0];
        let bs = transform_base_score(0.0, &version, &TaskType::BinaryClassification);
        assert!((bs - 0.0).abs() < f64::EPSILON);
    }

    #[test]
    fn base_score_regression_always_direct() {
        let version = vec![1, 4, 0];
        let bs = transform_base_score(2.71, &version, &TaskType::Regression);
        assert!((bs - 2.71).abs() < f64::EPSILON);
    }
}
