//! Error types for model format parsers.
//!
//! Every known failure mode has its own named variant with context fields.
//! There is no catch-all variant — new failure modes get new variants.

/// Errors encountered while parsing tree model files into a
/// [`TreeEnsemble`](treeshap_core::TreeEnsemble).
///
/// New variants may be added in future releases.
#[derive(Debug, thiserror::Error)]
#[non_exhaustive]
pub enum ParseError {
    /// A required field was absent from the model file.
    #[error("{format}: missing required field '{field}'")]
    MissingField {
        /// Which model format was being parsed.
        format: &'static str,
        /// The name of the missing field.
        field: &'static str,
    },

    /// A field exists but has an unexpected type.
    #[error("{format}: field '{field}' has wrong type, expected {expected}")]
    InvalidFieldType {
        /// Which model format was being parsed.
        format: &'static str,
        /// The name of the field.
        field: &'static str,
        /// The type that was expected.
        expected: &'static str,
    },

    /// The declared node count does not match the number of nodes found.
    #[error("declared {declared} nodes but found {found}")]
    NodeCountMismatch {
        /// Declared count (from metadata).
        declared: usize,
        /// Actual count found during parsing.
        found: usize,
    },

    /// A node references a feature index beyond the declared feature count.
    #[error(
        "node {node_id}: feature index {feature_index} out of bounds (n_features = {n_features})"
    )]
    FeatureIndexOutOfBounds {
        /// The node that holds the invalid reference.
        node_id: usize,
        /// The invalid feature index.
        feature_index: usize,
        /// The declared feature count.
        n_features: usize,
    },

    /// A split type that this parser does not support.
    #[error("{format}: unsupported split type '{split_type}'")]
    UnsupportedSplitType {
        /// The unsupported split type value.
        split_type: String,
        /// Which model format was being parsed.
        format: &'static str,
    },

    /// The schema version of the model file is not supported.
    #[error("schema version '{found}' not supported (supported: {supported})")]
    SchemaVersionUnsupported {
        /// The version string found in the file.
        found: String,
        /// The range of supported versions.
        supported: &'static str,
    },

    /// The base score could not be converted to the IR representation.
    #[error("{format}: failed to transform base_score {raw_value}")]
    BaseScoreTransformError {
        /// Which model format was being parsed.
        format: &'static str,
        /// The raw base score value that failed conversion.
        raw_value: f64,
    },

    /// An I/O error occurred while reading the model file.
    #[error("I/O error: {0}")]
    IoError(#[from] std::io::Error),

    /// The JSON content was malformed.
    #[error("JSON parse error: {0}")]
    JsonParseError(#[from] serde_json::Error),

    /// The constructed ensemble failed structural validation.
    #[error("validation failed: {0}")]
    ValidationFailed(#[from] treeshap_core::ValidationError),
}
