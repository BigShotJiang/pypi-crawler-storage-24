#![forbid(unsafe_code)]
#![warn(missing_docs)]

//! Input/output adapters for loading tree models into a unified
//! [`TreeEnsemble`](treeshap_core::TreeEnsemble) representation.
//!
//! Three parsers are provided, one per supported model format:
//!
//! - [`xgboost`] — XGBoost JSON (`booster.save_model()`)
//! - [`lightgbm`] — LightGBM text dump (`booster.model_to_string()`)
//! - [`onnx`] — ONNX `TreeEnsembleClassifier` / `TreeEnsembleRegressor`
//!
//! Each parser is fully self-contained and produces a validated
//! `TreeEnsemble` or a structured [`ParseError`].

pub mod error;
pub mod lightgbm;
pub mod onnx;
pub mod xgboost;

mod onnx_pb;

/// Test helpers for constructing ONNX protobuf fixtures.
///
/// This module is only available when running tests. It provides
/// convenience functions for building minimal ONNX model binaries.
#[doc(hidden)]
pub mod onnx_pb_test_helpers {
    use crate::onnx_pb::*;

    /// Creates a minimal ONNX ModelProto with a single graph node.
    pub fn create_minimal_onnx_model(op_type: &str, attributes: Vec<AttributeProto>) -> ModelProto {
        ModelProto {
            ir_version: 7,
            graph: Some(GraphProto {
                node: vec![NodeProto {
                    input: vec![],
                    output: vec![],
                    name: "tree_ensemble".to_string(),
                    op_type: op_type.to_string(),
                    attribute: attributes,
                    domain: "ai.onnx.ml".to_string(),
                }],
                name: "test_graph".to_string(),
            }),
        }
    }

    /// Creates an `ints` attribute.
    pub fn ints_attr(name: &str, values: &[i64]) -> AttributeProto {
        AttributeProto {
            name: name.to_string(),
            r#type: 7, // INTS
            ints: values.to_vec(),
            ..Default::default()
        }
    }

    /// Creates a `floats` attribute.
    pub fn floats_attr(name: &str, values: &[f32]) -> AttributeProto {
        AttributeProto {
            name: name.to_string(),
            r#type: 6, // FLOATS
            floats: values.to_vec(),
            ..Default::default()
        }
    }

    /// Creates a `strings` attribute.
    pub fn strings_attr(name: &str, values: &[&[u8]]) -> AttributeProto {
        AttributeProto {
            name: name.to_string(),
            r#type: 8, // STRINGS
            strings: values.iter().map(|s| s.to_vec()).collect(),
            ..Default::default()
        }
    }
}

pub use error::ParseError;
pub use lightgbm::{parse_lightgbm_text, parse_lightgbm_text_from_path};
pub use onnx::{parse_onnx, parse_onnx_from_path};
pub use xgboost::{parse_xgboost_json, parse_xgboost_json_from_path};

/// Returns the crate version at compile time.
#[must_use]
pub const fn version() -> &'static str {
    env!("CARGO_PKG_VERSION")
}
