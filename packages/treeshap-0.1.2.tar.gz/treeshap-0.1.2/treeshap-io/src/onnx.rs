//! Parser for ONNX models containing `TreeEnsembleClassifier` or
//! `TreeEnsembleRegressor` operators.
//!
//! Reads the ONNX protobuf binary format and extracts the tree ensemble
//! from the flat parallel-array encoding used by the ONNX ML spec.

use std::collections::HashMap;
use std::path::Path;

use prost::Message;
use treeshap_core::{MissingDirection, TaskType, TreeEnsembleBuilder, TreeNode};

use crate::error::ParseError;
use crate::onnx_pb::{AttributeProto, ModelProto, NodeProto};

const FORMAT: &str = "onnx";

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

/// Parses an ONNX model from raw bytes.
///
/// The bytes should be the contents of a `.onnx` file containing a
/// `TreeEnsembleClassifier` or `TreeEnsembleRegressor` operator.
///
/// # Errors
///
/// Returns [`ParseError`] if the protobuf is malformed, the model does not
/// contain a tree ensemble operator, required attributes are missing, or
/// the resulting ensemble fails validation.
pub fn parse_onnx(bytes: &[u8]) -> Result<treeshap_core::TreeEnsemble, ParseError> {
    let model = ModelProto::decode(bytes).map_err(|_| ParseError::InvalidFieldType {
        format: FORMAT,
        field: "protobuf",
        expected: "valid ONNX protobuf",
    })?;

    let graph = model.graph.ok_or(ParseError::MissingField {
        format: FORMAT,
        field: "graph",
    })?;

    // Find the TreeEnsemble operator node.
    let tree_node = graph
        .node
        .iter()
        .find(|n| n.op_type == "TreeEnsembleClassifier" || n.op_type == "TreeEnsembleRegressor")
        .ok_or(ParseError::MissingField {
            format: FORMAT,
            field: "TreeEnsembleClassifier or TreeEnsembleRegressor node",
        })?;

    convert_tree_ensemble_node(tree_node)
}

/// Parses an ONNX model from a file path.
///
/// # Errors
///
/// Returns [`ParseError`] on I/O errors, malformed protobuf, missing tree
/// ensemble operator, or validation failure.
pub fn parse_onnx_from_path(
    path: impl AsRef<Path>,
) -> Result<treeshap_core::TreeEnsemble, ParseError> {
    let bytes = std::fs::read(path)?;
    parse_onnx(&bytes)
}

// ---------------------------------------------------------------------------
// Attribute extraction helpers
// ---------------------------------------------------------------------------

/// Builds a name→attribute lookup from a node's attributes.
fn attr_map(node: &NodeProto) -> HashMap<&str, &AttributeProto> {
    node.attribute
        .iter()
        .map(|a| (a.name.as_str(), a))
        .collect()
}

fn get_ints<'a>(attrs: &'a HashMap<&str, &AttributeProto>, name: &str) -> &'a [i64] {
    attrs.get(name).map_or(&[], |a| a.ints.as_slice())
}

fn get_floats<'a>(attrs: &'a HashMap<&str, &AttributeProto>, name: &str) -> &'a [f32] {
    attrs.get(name).map_or(&[], |a| a.floats.as_slice())
}

fn get_strings<'a>(attrs: &'a HashMap<&str, &AttributeProto>, name: &str) -> &'a [Vec<u8>] {
    attrs.get(name).map_or(&[], |a| a.strings.as_slice())
}

fn get_string<'a>(attrs: &'a HashMap<&str, &AttributeProto>, name: &str) -> Option<&'a [u8]> {
    attrs
        .get(name)
        .map(|a| a.s.as_slice())
        .filter(|s| !s.is_empty())
}

// ---------------------------------------------------------------------------
// Conversion logic
// ---------------------------------------------------------------------------

fn convert_tree_ensemble_node(node: &NodeProto) -> Result<treeshap_core::TreeEnsemble, ParseError> {
    let attrs = attr_map(node);

    let is_classifier = node.op_type == "TreeEnsembleClassifier";

    // Extract parallel flat arrays.
    let tree_ids = get_ints(&attrs, "nodes_treeids");
    let node_ids = get_ints(&attrs, "nodes_nodeids");
    let feature_ids = get_ints(&attrs, "nodes_featureids");
    let values = get_floats(&attrs, "nodes_values");
    let true_node_ids = get_ints(&attrs, "nodes_truenodeids");
    let false_node_ids = get_ints(&attrs, "nodes_falsenodeids");
    let modes = get_strings(&attrs, "nodes_modes");
    let hitrates = get_floats(&attrs, "nodes_hitrates");
    let missing_tracks_true = get_ints(&attrs, "nodes_missing_value_tracks_true");

    if tree_ids.is_empty() {
        return Err(ParseError::MissingField {
            format: FORMAT,
            field: "nodes_treeids",
        });
    }

    let n_nodes = tree_ids.len();

    // Leaf value arrays (different names for classifier vs regressor).
    let (leaf_tree_ids, leaf_node_ids, leaf_weights) = if is_classifier {
        (
            get_ints(&attrs, "class_treeids"),
            get_ints(&attrs, "class_nodeids"),
            get_floats(&attrs, "class_weights"),
        )
    } else {
        (
            get_ints(&attrs, "target_treeids"),
            get_ints(&attrs, "target_nodeids"),
            get_floats(&attrs, "target_weights"),
        )
    };

    // Validate leaf value parallel arrays have matching lengths.
    if leaf_tree_ids.len() != leaf_node_ids.len() || leaf_tree_ids.len() != leaf_weights.len() {
        return Err(ParseError::NodeCountMismatch {
            declared: leaf_tree_ids.len(),
            found: leaf_weights.len(),
        });
    }

    // Build leaf value lookup: (tree_id, node_id) → weight.
    let mut leaf_lookup: HashMap<(i64, i64), f64> = HashMap::new();
    for idx in 0..leaf_tree_ids.len() {
        leaf_lookup.insert(
            (leaf_tree_ids[idx], leaf_node_ids[idx]),
            leaf_weights[idx] as f64,
        );
    }

    // Group nodes by tree_id. Preserve insertion order within each tree.
    let mut tree_groups: Vec<(i64, Vec<usize>)> = Vec::new();
    let mut tree_id_to_group: HashMap<i64, usize> = HashMap::new();

    for (i, &tid) in tree_ids.iter().enumerate() {
        if let Some(&group_idx) = tree_id_to_group.get(&tid) {
            tree_groups[group_idx].1.push(i);
        } else {
            tree_id_to_group.insert(tid, tree_groups.len());
            tree_groups.push((tid, vec![i]));
        }
    }

    // Determine n_features from max feature_id of internal (non-leaf) nodes only.
    // Leaf nodes carry undefined feature_id values in the ONNX spec.
    let max_fid = (0..n_nodes)
        .filter(|&i| modes.get(i).map(|m| m.as_slice()).unwrap_or(b"LEAF") != b"LEAF")
        .map(|i| feature_ids[i])
        .max()
        .unwrap_or(0);

    if max_fid < 0 {
        return Err(ParseError::InvalidFieldType {
            format: FORMAT,
            field: "nodes_featureids",
            expected: "non-negative feature index",
        });
    }
    let n_features = max_fid as usize + 1;

    // Convert each tree group.
    let mut trees = Vec::with_capacity(tree_groups.len());
    for (tid, global_indices) in &tree_groups {
        let tree = convert_single_tree(
            *tid,
            global_indices,
            node_ids,
            feature_ids,
            values,
            true_node_ids,
            false_node_ids,
            modes,
            hitrates,
            missing_tracks_true,
            n_nodes,
            &leaf_lookup,
        )?;
        trees.push(tree);
    }

    // Determine task type from post_transform or operator type.
    let task_type = determine_task_type(&attrs, is_classifier);

    // Extract base values.
    let base_values = get_floats(&attrs, "base_values");
    let base_score = base_values.first().copied().unwrap_or(0.0) as f64;

    let builder = TreeEnsembleBuilder::new()
        .task_type(task_type)
        .n_features(n_features)
        .base_score(base_score)
        .trees(trees);

    Ok(builder.build()?)
}

#[allow(clippy::too_many_arguments)]
fn convert_single_tree(
    tree_id: i64,
    global_indices: &[usize],
    node_ids: &[i64],
    feature_ids: &[i64],
    values: &[f32],
    true_node_ids: &[i64],
    false_node_ids: &[i64],
    modes: &[Vec<u8>],
    hitrates: &[f32],
    missing_tracks_true: &[i64],
    _n_total: usize,
    leaf_lookup: &HashMap<(i64, i64), f64>,
) -> Result<Vec<TreeNode>, ParseError> {
    // Build local node_id → local_index mapping.
    let mut nid_to_local: HashMap<i64, usize> = HashMap::new();
    for (local_idx, &global_idx) in global_indices.iter().enumerate() {
        nid_to_local.insert(node_ids[global_idx], local_idx);
    }

    let mut nodes = Vec::with_capacity(global_indices.len());

    for (local_idx, &global_idx) in global_indices.iter().enumerate() {
        let mode = modes
            .get(global_idx)
            .map(|m| m.as_slice())
            .unwrap_or(b"LEAF");

        let is_leaf = mode == b"LEAF";

        let cover = hitrates.get(global_idx).copied().unwrap_or(0.0) as f64;

        if is_leaf {
            let nid = node_ids[global_idx];
            let value = leaf_lookup.get(&(tree_id, nid)).copied().unwrap_or(0.0);
            nodes.push(TreeNode::leaf(value, cover));
        } else {
            let raw_fid = feature_ids[global_idx];
            if raw_fid < 0 {
                return Err(ParseError::InvalidFieldType {
                    format: FORMAT,
                    field: "nodes_featureids",
                    expected: "non-negative feature index",
                });
            }
            let feature_index = raw_fid as usize;
            let threshold = values.get(global_idx).copied().unwrap_or(0.0) as f64;

            let true_nid = true_node_ids[global_idx];
            let false_nid = false_node_ids[global_idx];

            let left_child = *nid_to_local
                .get(&true_nid)
                .ok_or(ParseError::MissingField {
                    format: FORMAT,
                    field: "nodes_truenodeids (unresolvable child)",
                })?;

            let right_child = *nid_to_local
                .get(&false_nid)
                .ok_or(ParseError::MissingField {
                    format: FORMAT,
                    field: "nodes_falsenodeids (unresolvable child)",
                })?;

            let tracks_true = missing_tracks_true.get(global_idx).copied().unwrap_or(0);

            // In ONNX, "true" branch is typically the left child (condition
            // satisfied), "false" is right. missing_tracks_true means missing
            // values follow the true (left) branch.
            let missing_direction = if tracks_true != 0 {
                MissingDirection::Left
            } else {
                MissingDirection::Right
            };

            nodes.push(TreeNode::internal(
                feature_index,
                threshold,
                left_child,
                right_child,
                missing_direction,
                cover,
            ));
        }

        let _ = local_idx; // suppress unused warning
    }

    Ok(nodes)
}

fn determine_task_type(attrs: &HashMap<&str, &AttributeProto>, is_classifier: bool) -> TaskType {
    if !is_classifier {
        return TaskType::Regression;
    }

    // Check post_transform for classification type.
    let post_transform = get_string(attrs, "post_transform")
        .and_then(|b| std::str::from_utf8(b).ok())
        .unwrap_or("NONE");

    match post_transform {
        "LOGISTIC" => TaskType::BinaryClassification,
        "SOFTMAX" | "SOFTMAX_ZERO" => {
            // Determine n_classes from the class labels or class_ids.
            let class_ids = get_ints(attrs, "class_ids");
            let n_classes = if class_ids.is_empty() {
                2
            } else {
                (*class_ids.iter().max().unwrap_or(&1) + 1) as usize
            };
            if n_classes <= 2 {
                TaskType::BinaryClassification
            } else {
                TaskType::MulticlassClassification { n_classes }
            }
        }
        _ => TaskType::BinaryClassification,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn attr_map_lookup() {
        let node = NodeProto {
            input: vec![],
            output: vec![],
            name: String::new(),
            op_type: "TreeEnsembleRegressor".to_string(),
            attribute: vec![AttributeProto {
                name: "test_attr".to_string(),
                ints: vec![1, 2, 3],
                ..Default::default()
            }],
            domain: String::new(),
        };
        let map = attr_map(&node);
        assert_eq!(get_ints(&map, "test_attr"), &[1, 2, 3]);
        assert!(get_ints(&map, "nonexistent").is_empty());
    }
}
