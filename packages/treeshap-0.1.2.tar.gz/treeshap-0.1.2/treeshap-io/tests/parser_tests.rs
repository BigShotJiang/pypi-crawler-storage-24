//! Integration tests for all three model format parsers.

use treeshap_core::{MissingDirection, TaskType, TreeNode};
use treeshap_io::{parse_lightgbm_text, parse_xgboost_json, ParseError};

// ---------------------------------------------------------------------------
// Fixture paths (relative to workspace root)
// ---------------------------------------------------------------------------

fn fixture(name: &str) -> std::path::PathBuf {
    std::path::PathBuf::from(env!("CARGO_MANIFEST_DIR"))
        .join("..")
        .join("fixtures")
        .join(name)
}

// ===================================================================
// XGBoost JSON Parser Tests
// ===================================================================

#[test]
fn xgboost_regression_basic_fields() {
    let file = std::fs::File::open(fixture("xgboost_regression.json")).unwrap();
    let ensemble = parse_xgboost_json(file).unwrap();

    assert_eq!(ensemble.n_features(), 4);
    assert_eq!(ensemble.n_trees(), 2);
    assert_eq!(*ensemble.task_type(), TaskType::Regression);
    assert!((ensemble.base_score() - 0.5).abs() < 1e-9);

    let names = ensemble.feature_names().unwrap();
    assert_eq!(names, &["age", "income", "score", "flag"]);
}

#[test]
fn xgboost_regression_tree_structure() {
    let file = std::fs::File::open(fixture("xgboost_regression.json")).unwrap();
    let ensemble = parse_xgboost_json(file).unwrap();

    // Tree 0: root splits on feature 0 at 2.5
    let tree0 = &ensemble.trees()[0];
    assert_eq!(tree0.len(), 3);

    if let TreeNode::Internal {
        feature_index,
        threshold,
        left_child,
        right_child,
        missing_direction,
        cover,
        ..
    } = &tree0[0]
    {
        assert_eq!(*feature_index, 0);
        assert!((*threshold - 2.5).abs() < 1e-9);
        assert_eq!(*left_child, 1);
        assert_eq!(*right_child, 2);
        assert_eq!(*missing_direction, MissingDirection::Left);
        assert!((*cover - 100.0).abs() < 1e-9);
    } else {
        panic!("expected Internal node at index 0");
    }

    // Tree 0: left leaf value = 0.3
    if let TreeNode::Leaf { value, cover, .. } = &tree0[1] {
        assert!((*value - 0.3).abs() < 1e-9);
        assert!((*cover - 60.0).abs() < 1e-9);
    } else {
        panic!("expected Leaf at index 1");
    }

    // Tree 0: right leaf value = -0.2
    if let TreeNode::Leaf { value, .. } = &tree0[2] {
        assert!((*value - (-0.2)).abs() < 1e-9);
    } else {
        panic!("expected Leaf at index 2");
    }
}

#[test]
fn xgboost_regression_second_tree() {
    let file = std::fs::File::open(fixture("xgboost_regression.json")).unwrap();
    let ensemble = parse_xgboost_json(file).unwrap();

    // Tree 1: root splits on feature 2 at 1.0
    let tree1 = &ensemble.trees()[1];
    if let TreeNode::Internal {
        feature_index,
        threshold,
        missing_direction,
        ..
    } = &tree1[0]
    {
        assert_eq!(*feature_index, 2);
        assert!((*threshold - 1.0).abs() < 1e-9);
        assert_eq!(*missing_direction, MissingDirection::Right);
    } else {
        panic!("expected Internal node");
    }
}

#[test]
fn xgboost_binary_classification() {
    let file = std::fs::File::open(fixture("xgboost_binary.json")).unwrap();
    let ensemble = parse_xgboost_json(file).unwrap();

    assert_eq!(ensemble.n_features(), 3);
    assert_eq!(ensemble.n_trees(), 1);
    assert_eq!(*ensemble.task_type(), TaskType::BinaryClassification);
    // Version >= 1.6 with base_score 0.0 → used directly (already logit space)
    assert!((ensemble.base_score() - 0.0).abs() < 1e-9);
    // No feature names in fixture (empty array)
    assert!(ensemble.feature_names().is_none());
}

#[test]
fn xgboost_malformed_json_returns_json_error() {
    let result = parse_xgboost_json("not valid json".as_bytes());
    assert!(result.is_err());
    let err = result.unwrap_err();
    assert!(matches!(err, ParseError::JsonParseError(_)));
}

#[test]
fn xgboost_missing_field_returns_error() {
    // Valid JSON but missing required structure
    let json = r#"{"version": [2,0,0]}"#;
    let result = parse_xgboost_json(json.as_bytes());
    assert!(result.is_err());
}

#[test]
fn xgboost_from_path() {
    let ensemble =
        treeshap_io::parse_xgboost_json_from_path(fixture("xgboost_regression.json")).unwrap();
    assert_eq!(ensemble.n_trees(), 2);
}

// ===================================================================
// LightGBM Text Dump Parser Tests
// ===================================================================

#[test]
fn lgbm_regression_basic_fields() {
    let text = std::fs::read_to_string(fixture("lgbm_regression.txt")).unwrap();
    let ensemble = parse_lightgbm_text(&text).unwrap();

    assert_eq!(ensemble.n_features(), 4);
    assert_eq!(ensemble.n_trees(), 2);
    assert_eq!(*ensemble.task_type(), TaskType::Regression);
    assert!((ensemble.base_score() - 0.5).abs() < 1e-9);

    let names = ensemble.feature_names().unwrap();
    assert_eq!(names, &["age", "income", "score", "flag"]);
}

#[test]
fn lgbm_regression_tree_structure() {
    let text = std::fs::read_to_string(fixture("lgbm_regression.txt")).unwrap();
    let ensemble = parse_lightgbm_text(&text).unwrap();

    // Tree 0: 1 internal + 2 leaves = 3 nodes
    let tree0 = &ensemble.trees()[0];
    assert_eq!(tree0.len(), 3);

    // Root: internal node splitting on feature 0 at threshold 2.5
    if let TreeNode::Internal {
        feature_index,
        threshold,
        left_child,
        right_child,
        missing_direction,
        cover,
        ..
    } = &tree0[0]
    {
        assert_eq!(*feature_index, 0);
        assert!((*threshold - 2.5).abs() < 1e-9);
        assert_eq!(*left_child, 1); // leaf 0 → index n_internal(1) + 0 = 1
        assert_eq!(*right_child, 2); // leaf 1 → index n_internal(1) + 1 = 2
        assert_eq!(*missing_direction, MissingDirection::Left); // decision_type=0, bit 2 unset
        assert!((*cover - 100.0).abs() < 1e-9);
    } else {
        panic!("expected Internal node at index 0");
    }

    // Leaf 0: value=0.3, cover=60
    if let TreeNode::Leaf { value, cover, .. } = &tree0[1] {
        assert!((*value - 0.3).abs() < 1e-9);
        assert!((*cover - 60.0).abs() < 1e-9);
    } else {
        panic!("expected Leaf at index 1");
    }

    // Leaf 1: value=-0.2, cover=40
    if let TreeNode::Leaf { value, cover, .. } = &tree0[2] {
        assert!((*value - (-0.2)).abs() < 1e-9);
        assert!((*cover - 40.0).abs() < 1e-9);
    } else {
        panic!("expected Leaf at index 2");
    }
}

#[test]
fn lgbm_regression_second_tree_missing_direction() {
    let text = std::fs::read_to_string(fixture("lgbm_regression.txt")).unwrap();
    let ensemble = parse_lightgbm_text(&text).unwrap();

    // Tree 1: decision_type=4 → bit 2 set → missing goes Right
    let tree1 = &ensemble.trees()[1];
    if let TreeNode::Internal {
        feature_index,
        missing_direction,
        ..
    } = &tree1[0]
    {
        assert_eq!(*feature_index, 2);
        assert_eq!(*missing_direction, MissingDirection::Right);
    } else {
        panic!("expected Internal node");
    }
}

#[test]
fn lgbm_binary_basic_fields() {
    let text = std::fs::read_to_string(fixture("lgbm_binary.txt")).unwrap();
    let ensemble = parse_lightgbm_text(&text).unwrap();

    assert_eq!(ensemble.n_features(), 3);
    assert_eq!(ensemble.n_trees(), 1);
    assert!((ensemble.base_score() - 0.0).abs() < 1e-9);

    let names = ensemble.feature_names().unwrap();
    assert_eq!(names, &["f0", "f1", "f2"]);
}

#[test]
fn lgbm_from_path() {
    let ensemble =
        treeshap_io::parse_lightgbm_text_from_path(fixture("lgbm_regression.txt")).unwrap();
    assert_eq!(ensemble.n_trees(), 2);
}

#[test]
fn lgbm_missing_max_feature_idx_returns_error() {
    let text = "tree\nnum_class=1\nTree=0\nnum_leaves=1\nleaf_value=0.5\nleaf_count=10\n";
    let result = parse_lightgbm_text(text);
    assert!(result.is_err());
    let err = result.unwrap_err();
    assert!(matches!(
        err,
        ParseError::MissingField {
            format: "lightgbm",
            field: "max_feature_idx"
        }
    ));
}

// ===================================================================
// ONNX Parser Tests
// ===================================================================

/// Helper: creates a minimal ONNX protobuf binary with a TreeEnsembleRegressor
/// containing one tree with 3 nodes (1 split + 2 leaves).
fn make_onnx_regression_fixture() -> Vec<u8> {
    use prost::Message;
    use treeshap_io::onnx_pb_test_helpers::*;

    let model = create_minimal_onnx_model(
        "TreeEnsembleRegressor",
        vec![
            ints_attr("nodes_treeids", &[0, 0, 0]),
            ints_attr("nodes_nodeids", &[0, 1, 2]),
            ints_attr("nodes_featureids", &[0, 0, 0]),
            floats_attr("nodes_values", &[2.5, 0.0, 0.0]),
            ints_attr("nodes_truenodeids", &[1, 0, 0]),
            ints_attr("nodes_falsenodeids", &[2, 0, 0]),
            strings_attr("nodes_modes", &[b"BRANCH_LEQ", b"LEAF", b"LEAF"]),
            floats_attr("nodes_hitrates", &[100.0, 60.0, 40.0]),
            ints_attr("nodes_missing_value_tracks_true", &[1, 0, 0]),
            ints_attr("target_treeids", &[0, 0]),
            ints_attr("target_nodeids", &[1, 2]),
            floats_attr("target_weights", &[0.5, -0.3]),
            floats_attr("base_values", &[0.0]),
        ],
    );

    let mut buf = Vec::new();
    model.encode(&mut buf).unwrap();
    buf
}

// We need test helpers in the crate for constructing ONNX proto types.
// Since onnx_pb is private, we expose test helpers via a public test module.

#[test]
fn onnx_regression_basic_fields() {
    let bytes = make_onnx_regression_fixture();
    let ensemble = treeshap_io::parse_onnx(&bytes).unwrap();

    assert_eq!(ensemble.n_features(), 1);
    assert_eq!(ensemble.n_trees(), 1);
    assert_eq!(*ensemble.task_type(), TaskType::Regression);
    assert!((ensemble.base_score() - 0.0).abs() < 1e-9);
}

#[test]
fn onnx_regression_tree_structure() {
    let bytes = make_onnx_regression_fixture();
    let ensemble = treeshap_io::parse_onnx(&bytes).unwrap();

    let tree0 = &ensemble.trees()[0];
    assert_eq!(tree0.len(), 3);

    // Root: split on feature 0 at 2.5
    if let TreeNode::Internal {
        feature_index,
        threshold,
        missing_direction,
        cover,
        ..
    } = &tree0[0]
    {
        assert_eq!(*feature_index, 0);
        assert!((*threshold - 2.5).abs() < 1e-9);
        assert_eq!(*missing_direction, MissingDirection::Left); // tracks_true=1
        assert!((*cover - 100.0).abs() < 1e-9);
    } else {
        panic!("expected Internal node");
    }

    // Left leaf: value=0.5
    if let TreeNode::Leaf { value, .. } = &tree0[1] {
        assert!((*value - 0.5).abs() < 1e-9);
    } else {
        panic!("expected Leaf at index 1");
    }

    // Right leaf: value=-0.3 (f32 → f64, so tolerance is wider)
    if let TreeNode::Leaf { value, .. } = &tree0[2] {
        assert!(
            (*value - (-0.3)).abs() < 1e-6,
            "expected ~-0.3, got {value}"
        );
    } else {
        panic!("expected Leaf at index 2");
    }
}

#[test]
fn onnx_invalid_protobuf_returns_error() {
    let result = treeshap_io::parse_onnx(b"not valid protobuf");
    // prost may or may not error on arbitrary bytes (it's lenient).
    // But it should at minimum not panic.
    // If it succeeds, the tree ensemble node won't be found.
    if let Err(err) = result {
        assert!(matches!(
            err,
            ParseError::InvalidFieldType { .. } | ParseError::MissingField { .. }
        ));
    }
}

#[test]
fn onnx_from_path_nonexistent_returns_io_error() {
    let result = treeshap_io::parse_onnx_from_path("/nonexistent/path.onnx");
    assert!(result.is_err());
    assert!(matches!(result.unwrap_err(), ParseError::IoError(_)));
}

// ===================================================================
// ParseError variant coverage
// ===================================================================

#[test]
fn parse_error_missing_field() {
    let err = ParseError::MissingField {
        format: "test",
        field: "test_field",
    };
    let msg = err.to_string();
    assert!(msg.contains("test"));
    assert!(msg.contains("test_field"));
}

#[test]
fn parse_error_invalid_field_type() {
    let err = ParseError::InvalidFieldType {
        format: "test",
        field: "f",
        expected: "integer",
    };
    let msg = err.to_string();
    assert!(msg.contains("integer"));
}

#[test]
fn parse_error_node_count_mismatch() {
    let err = ParseError::NodeCountMismatch {
        declared: 5,
        found: 3,
    };
    let msg = err.to_string();
    assert!(msg.contains("5"));
    assert!(msg.contains("3"));
}

#[test]
fn parse_error_feature_index_out_of_bounds() {
    let err = ParseError::FeatureIndexOutOfBounds {
        node_id: 0,
        feature_index: 10,
        n_features: 4,
    };
    let msg = err.to_string();
    assert!(msg.contains("10"));
    assert!(msg.contains("4"));
}

#[test]
fn parse_error_unsupported_split_type() {
    let err = ParseError::UnsupportedSplitType {
        split_type: "categorical".to_string(),
        format: "test",
    };
    assert!(err.to_string().contains("categorical"));
}

#[test]
fn parse_error_schema_version_unsupported() {
    let err = ParseError::SchemaVersionUnsupported {
        found: "99.0".to_string(),
        supported: "1.0-2.x",
    };
    assert!(err.to_string().contains("99.0"));
}

#[test]
fn parse_error_base_score_transform() {
    let err = ParseError::BaseScoreTransformError {
        format: "test",
        raw_value: f64::NAN,
    };
    assert!(err.to_string().contains("base_score"));
}

#[test]
fn parse_error_io_error() {
    let err = ParseError::IoError(std::io::Error::new(
        std::io::ErrorKind::NotFound,
        "file not found",
    ));
    assert!(err.to_string().contains("file not found"));
    assert!(std::error::Error::source(&err).is_some());
}

#[test]
fn parse_error_json_parse() {
    let result: Result<serde_json::Value, _> = serde_json::from_str("invalid");
    let err = ParseError::JsonParseError(result.unwrap_err());
    assert!(err.to_string().contains("JSON"));
    assert!(std::error::Error::source(&err).is_some());
}

#[test]
fn parse_error_validation_failed() {
    let err =
        ParseError::ValidationFailed(treeshap_core::ValidationError::EmptyTree { tree_index: 0 });
    assert!(err.to_string().contains("validation"));
    assert!(std::error::Error::source(&err).is_some());
}

#[test]
fn parse_error_is_std_error() {
    fn assert_error<E: std::error::Error>() {}
    assert_error::<ParseError>();
}

// ===================================================================
// Real-world edge case tests
// ===================================================================

#[test]
fn xgboost_scientific_notation_base_score() {
    // Real XGBoost models often store base_score as "5E-1" not "0.5"
    let json = r#"{
        "version": [2, 0, 0],
        "learner": {
            "learner_model_param": {
                "base_score": "5E-1",
                "num_feature": "2"
            },
            "objective": { "name": "reg:squarederror" },
            "gradient_booster": {
                "model": {
                    "gbtree_model_param": { "num_trees": "0" },
                    "trees": []
                }
            },
            "feature_names": []
        }
    }"#;
    let ensemble = parse_xgboost_json(json.as_bytes()).unwrap();
    assert!((ensemble.base_score() - 0.5).abs() < 1e-9);
}

#[test]
fn xgboost_single_leaf_tree() {
    // A tree with only one node (a leaf) is valid — the model predicts
    // base_score + leaf_value for all samples.
    let json = r#"{
        "version": [2, 0, 0],
        "learner": {
            "learner_model_param": {
                "base_score": "0.0",
                "num_feature": "1"
            },
            "objective": { "name": "reg:squarederror" },
            "gradient_booster": {
                "model": {
                    "gbtree_model_param": { "num_trees": "1" },
                    "trees": [{
                        "base_weights": [0.42],
                        "left_children": [-1],
                        "right_children": [-1],
                        "split_conditions": [0.0],
                        "split_indices": [0],
                        "split_type": [0],
                        "default_left": [false],
                        "sum_hessian": [100.0],
                        "tree_param": { "num_nodes": "1" }
                    }]
                }
            },
            "feature_names": []
        }
    }"#;
    let ensemble = parse_xgboost_json(json.as_bytes()).unwrap();
    assert_eq!(ensemble.n_trees(), 1);
    assert_eq!(ensemble.trees()[0].len(), 1);
    assert!(ensemble.trees()[0][0].is_leaf());
}

#[test]
fn xgboost_empty_model_zero_trees() {
    let json = r#"{
        "version": [2, 0, 0],
        "learner": {
            "learner_model_param": {
                "base_score": "0.5",
                "num_feature": "4"
            },
            "objective": { "name": "reg:squarederror" },
            "gradient_booster": {
                "model": {
                    "gbtree_model_param": { "num_trees": "0" },
                    "trees": []
                }
            },
            "feature_names": []
        }
    }"#;
    let ensemble = parse_xgboost_json(json.as_bytes()).unwrap();
    assert_eq!(ensemble.n_trees(), 0);
    assert!(ensemble.trees().is_empty());
}

#[test]
fn xgboost_pre_1_6_base_score_logit_conversion() {
    // Version [1, 4, 0] with binary:logistic — base_score=0.7 should be
    // converted to logit(0.7) = ln(0.7/0.3) ≈ 0.8473
    let json = r#"{
        "version": [1, 4, 0],
        "learner": {
            "learner_model_param": {
                "base_score": "0.7",
                "num_feature": "1"
            },
            "objective": { "name": "binary:logistic" },
            "gradient_booster": {
                "model": {
                    "gbtree_model_param": { "num_trees": "0" },
                    "trees": []
                }
            },
            "feature_names": []
        }
    }"#;
    let ensemble = parse_xgboost_json(json.as_bytes()).unwrap();
    let expected = (0.7_f64 / 0.3).ln();
    assert!(
        (ensemble.base_score() - expected).abs() < 1e-9,
        "expected logit(0.7) = {expected}, got {}",
        ensemble.base_score()
    );
}

#[test]
fn lgbm_empty_model_no_trees() {
    let text = "tree\nversion=v3.3.5\nnum_class=1\nmax_feature_idx=3\n\nend of parameters\n";
    let ensemble = parse_lightgbm_text(text).unwrap();
    assert_eq!(ensemble.n_trees(), 0);
    assert_eq!(ensemble.n_features(), 4);
}

#[test]
fn lgbm_single_leaf_tree() {
    // A tree with 0 internal nodes and 1 leaf (split_feature is empty)
    let text = "\
tree
version=v3.3.5
num_class=1
max_feature_idx=1

Tree=0
num_leaves=1
num_cat=0
leaf_value=0.5
leaf_count=100

end of parameters
";
    let ensemble = parse_lightgbm_text(text).unwrap();
    assert_eq!(ensemble.n_trees(), 1);
    assert_eq!(ensemble.trees()[0].len(), 1);
    assert!(ensemble.trees()[0][0].is_leaf());
}

#[test]
fn lgbm_mismatched_array_lengths_returns_error() {
    // threshold has 1 element but split_feature has 2
    let text = "\
tree
version=v3.3.5
num_class=1
max_feature_idx=1

Tree=0
num_leaves=3
split_feature=0 1
threshold=2.5
left_child=-1 -2
right_child=-2 -3
leaf_value=0.1 0.2 0.3
leaf_count=30 40 30

end of parameters
";
    let result = parse_lightgbm_text(text);
    assert!(result.is_err());
}

#[test]
fn onnx_empty_tree_returns_validation_error() {
    use prost::Message;
    use treeshap_io::onnx_pb_test_helpers::*;

    // Tree with no nodes at all → empty tree error from validation
    let model = create_minimal_onnx_model(
        "TreeEnsembleRegressor",
        vec![
            ints_attr("nodes_treeids", &[]),
            ints_attr("nodes_nodeids", &[]),
        ],
    );
    let mut buf = Vec::new();
    model.encode(&mut buf).unwrap();

    let result = treeshap_io::parse_onnx(&buf);
    assert!(result.is_err());
}

#[test]
fn xgboost_short_version_array_returns_error() {
    let json = r#"{
        "version": [2],
        "learner": {
            "learner_model_param": { "base_score": "0.0", "num_feature": "1" },
            "objective": { "name": "reg:squarederror" },
            "gradient_booster": { "model": { "gbtree_model_param": { "num_trees": "0" }, "trees": [] } },
            "feature_names": []
        }
    }"#;
    let result = parse_xgboost_json(json.as_bytes());
    assert!(result.is_err());
    assert!(matches!(
        result.unwrap_err(),
        ParseError::SchemaVersionUnsupported { .. }
    ));
}

#[test]
fn lgbm_num_leaves_mismatch_returns_error() {
    // Declares num_leaves=3 but only provides 2 leaf values
    let text = "\
tree
num_class=1
max_feature_idx=1

Tree=0
num_leaves=3
split_feature=0
threshold=2.5
left_child=-1
right_child=-2
internal_count=100
leaf_value=0.3 -0.2
leaf_count=60 40

end of parameters
";
    let result = parse_lightgbm_text(text);
    assert!(result.is_err());
    assert!(matches!(
        result.unwrap_err(),
        ParseError::NodeCountMismatch {
            declared: 3,
            found: 2
        }
    ));
}

#[test]
fn onnx_classifier_with_logistic_is_binary() {
    use prost::Message;
    use treeshap_io::onnx_pb_test_helpers::*;

    let model = create_minimal_onnx_model(
        "TreeEnsembleClassifier",
        vec![
            ints_attr("nodes_treeids", &[0, 0, 0]),
            ints_attr("nodes_nodeids", &[0, 1, 2]),
            ints_attr("nodes_featureids", &[0, 0, 0]),
            floats_attr("nodes_values", &[1.0, 0.0, 0.0]),
            ints_attr("nodes_truenodeids", &[1, 0, 0]),
            ints_attr("nodes_falsenodeids", &[2, 0, 0]),
            strings_attr("nodes_modes", &[b"BRANCH_LEQ", b"LEAF", b"LEAF"]),
            floats_attr("nodes_hitrates", &[100.0, 60.0, 40.0]),
            ints_attr("nodes_missing_value_tracks_true", &[1, 0, 0]),
            ints_attr("class_treeids", &[0, 0]),
            ints_attr("class_nodeids", &[1, 2]),
            floats_attr("class_weights", &[0.8, -0.3]),
            floats_attr("base_values", &[0.0]),
            {
                let mut a = treeshap_io::onnx_pb_test_helpers::ints_attr("post_transform", &[]);
                a.s = b"LOGISTIC".to_vec();
                a.r#type = 3; // STRING type
                a
            },
        ],
    );
    let mut buf = Vec::new();
    model.encode(&mut buf).unwrap();

    let ensemble = treeshap_io::parse_onnx(&buf).unwrap();
    assert_eq!(
        *ensemble.task_type(),
        treeshap_core::TaskType::BinaryClassification
    );
}

// ===================================================================
// Additional edge case tests (from review round 2)
// ===================================================================

#[test]
fn lgbm_unparseable_threshold_returns_error() {
    // A non-numeric threshold value should error, not be silently dropped.
    let text = "\
tree
num_class=1
max_feature_idx=1

Tree=0
num_leaves=2
split_feature=0
threshold=not_a_number
left_child=-1
right_child=-2
leaf_value=0.3 -0.2
leaf_count=60 40

end of parameters
";
    let result = parse_lightgbm_text(text);
    assert!(result.is_err());
    assert!(matches!(
        result.unwrap_err(),
        ParseError::InvalidFieldType { .. }
    ));
}

#[test]
fn lgbm_absent_num_leaves_still_works() {
    // When num_leaves is absent from the tree block, parsing should
    // succeed based on the actual leaf_value array length.
    let text = "\
tree
num_class=1
max_feature_idx=1

Tree=0
split_feature=0
threshold=2.5
left_child=-1
right_child=-2
internal_count=100
leaf_value=0.3 -0.2
leaf_count=60 40

end of parameters
";
    let ensemble = parse_lightgbm_text(text).unwrap();
    assert_eq!(ensemble.n_trees(), 1);
    assert_eq!(ensemble.trees()[0].len(), 3); // 1 internal + 2 leaves
}

#[test]
fn onnx_mismatched_leaf_weight_arrays_returns_error() {
    use prost::Message;
    use treeshap_io::onnx_pb_test_helpers::*;

    // target_treeids has 2 entries but target_weights has 1
    let model = create_minimal_onnx_model(
        "TreeEnsembleRegressor",
        vec![
            ints_attr("nodes_treeids", &[0, 0, 0]),
            ints_attr("nodes_nodeids", &[0, 1, 2]),
            ints_attr("nodes_featureids", &[0, 0, 0]),
            floats_attr("nodes_values", &[2.5, 0.0, 0.0]),
            ints_attr("nodes_truenodeids", &[1, 0, 0]),
            ints_attr("nodes_falsenodeids", &[2, 0, 0]),
            strings_attr("nodes_modes", &[b"BRANCH_LEQ", b"LEAF", b"LEAF"]),
            floats_attr("nodes_hitrates", &[100.0, 60.0, 40.0]),
            ints_attr("nodes_missing_value_tracks_true", &[1, 0, 0]),
            ints_attr("target_treeids", &[0, 0]),
            ints_attr("target_nodeids", &[1, 2]),
            floats_attr("target_weights", &[0.5]), // only 1 weight for 2 nodes
            floats_attr("base_values", &[0.0]),
        ],
    );
    let mut buf = Vec::new();
    model.encode(&mut buf).unwrap();

    let result = treeshap_io::parse_onnx(&buf);
    assert!(result.is_err());
    assert!(matches!(
        result.unwrap_err(),
        ParseError::NodeCountMismatch { .. }
    ));
}

#[test]
fn lgbm_categorical_split_returns_error() {
    // decision_type bit 0 set = categorical split, should error
    let text = "\
tree
num_class=1
max_feature_idx=1

Tree=0
num_leaves=2
split_feature=0
threshold=2.5
decision_type=1
left_child=-1
right_child=-2
internal_count=100
leaf_value=0.3 -0.2
leaf_count=60 40

end of parameters
";
    let result = parse_lightgbm_text(text);
    assert!(result.is_err());
    assert!(matches!(
        result.unwrap_err(),
        ParseError::UnsupportedSplitType { .. }
    ));
}
