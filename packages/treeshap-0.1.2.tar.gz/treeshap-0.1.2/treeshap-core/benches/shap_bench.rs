//! Criterion benchmarks for TreeSHAP computation.

use criterion::{criterion_group, criterion_main, Criterion};
use ndarray::Array2;
use treeshap_core::{Explainer, MissingDirection, TaskType, TreeEnsembleBuilder, TreeNode};

/// Builds a synthetic balanced binary tree of the given depth.
fn build_tree(depth: usize, n_features: usize) -> Vec<TreeNode> {
    let n_nodes = (1 << (depth + 1)) - 1;
    let n_internal = (1 << depth) - 1;
    let mut nodes = Vec::with_capacity(n_nodes);

    // Assign covers so parent = left_child + right_child (monotone).
    // Leaf cover = base_cover, internal cover computed bottom-up.
    let base_cover = 10.0;
    let mut covers = vec![0.0; n_nodes];
    // Set leaf covers first.
    for cover in covers[n_internal..n_nodes].iter_mut() {
        *cover = base_cover;
    }
    // Compute internal covers bottom-up.
    for i in (0..n_internal).rev() {
        covers[i] = covers[2 * i + 1] + covers[2 * i + 2];
    }

    for (i, &cover) in covers.iter().enumerate() {
        if i >= n_internal {
            let val = if i % 2 == 0 { 0.1 } else { -0.1 };
            nodes.push(TreeNode::leaf(val, cover));
        } else {
            let left = 2 * i + 1;
            let right = 2 * i + 2;
            nodes.push(TreeNode::internal(
                i % n_features,
                0.5,
                left,
                right,
                MissingDirection::Left,
                cover,
            ));
        }
    }
    nodes
}

fn build_ensemble(n_trees: usize, depth: usize, n_features: usize) -> treeshap_core::TreeEnsemble {
    let trees: Vec<Vec<TreeNode>> = (0..n_trees)
        .map(|_| build_tree(depth, n_features))
        .collect();
    TreeEnsembleBuilder::new()
        .task_type(TaskType::Regression)
        .n_features(n_features)
        .base_score(0.0)
        .trees(trees)
        .build()
        .expect("valid benchmark ensemble")
}

fn random_data(n_samples: usize, n_features: usize) -> Array2<f64> {
    let mut data = Array2::zeros((n_samples, n_features));
    let mut seed = 42u64;
    for row in data.rows_mut() {
        for val in row {
            seed = seed.wrapping_mul(6364136223846793005).wrapping_add(1);
            *val = (seed >> 33) as f64 / (1u64 << 31) as f64;
        }
    }
    data
}

fn bench_shap(c: &mut Criterion) {
    let n_features = 10;

    // Bench 1: single sample, 100 trees, depth 6
    {
        let ens = build_ensemble(100, 6, n_features);
        let data = random_data(1, n_features);
        let explainer = Explainer::new(&ens);
        c.bench_function("shap_1x100t_d6", |b| {
            b.iter(|| explainer.shap_values(data.view()));
        });
    }

    // Bench 2: 100 samples, 100 trees, depth 6
    {
        let ens = build_ensemble(100, 6, n_features);
        let data = random_data(100, n_features);
        let explainer = Explainer::new(&ens);
        c.bench_function("shap_100x100t_d6", |b| {
            b.iter(|| explainer.shap_values(data.view()));
        });
    }

    // Bench 3: 10000 samples, 100 trees, depth 6
    {
        let ens = build_ensemble(100, 6, n_features);
        let data = random_data(10_000, n_features);
        let explainer = Explainer::new(&ens);
        c.bench_function("shap_10kx100t_d6", |b| {
            b.iter(|| explainer.shap_values(data.view()));
        });
    }
}

criterion_group!(benches, bench_shap);
criterion_main!(benches);
