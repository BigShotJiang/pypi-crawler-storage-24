//! Structured output type for SHAP computations.
//!
//! [`ShapExplanation`] bundles SHAP values with the metadata needed for
//! visualization, serialization, and local accuracy verification.

use std::fmt;

use ndarray::{Array1, Array2};

use crate::explainer::{BaseValue, ShapOutput};

/// A complete SHAP explanation for one or more samples.
///
/// Produced by [`Explainer::explain`](crate::Explainer::explain). Contains
/// SHAP values, the base value, original feature values, predictions, and
/// optional feature names.
#[derive(Debug, Clone, PartialEq)]
pub struct ShapExplanation {
    /// SHAP values: per-feature contributions to the model output.
    pub(crate) shap_values: ShapOutput,
    /// The expected model output (E\[f(x)\]).
    pub(crate) base_value: BaseValue,
    /// Raw input feature values per sample, shape `(n_samples, n_features)`.
    /// Required for beeswarm coloring.
    pub(crate) feature_values: Option<Array2<f64>>,
    /// Human-readable feature names.
    pub(crate) feature_names: Option<Vec<String>>,
    /// Model predictions per sample (raw output, pre-post-transform).
    pub(crate) predictions: Array1<f64>,
    /// Number of samples.
    pub(crate) n_samples: usize,
    /// Number of features.
    pub(crate) n_features: usize,
}

impl ShapExplanation {
    /// Returns the SHAP values.
    #[must_use]
    pub fn shap_values(&self) -> &ShapOutput {
        &self.shap_values
    }

    /// Returns the base value (expected model output).
    #[must_use]
    pub fn base_value(&self) -> &BaseValue {
        &self.base_value
    }

    /// Returns the raw input feature values, if provided.
    #[must_use]
    pub fn feature_values(&self) -> Option<&Array2<f64>> {
        self.feature_values.as_ref()
    }

    /// Returns the feature names, if provided.
    #[must_use]
    pub fn feature_names(&self) -> Option<&[String]> {
        self.feature_names.as_deref()
    }

    /// Overrides the feature names. Use this to inject names from CSV headers
    /// or a separate names file when the model does not embed them.
    pub fn set_feature_names(&mut self, names: Vec<String>) {
        self.feature_names = Some(names);
    }

    /// Returns the model predictions per sample.
    #[must_use]
    pub fn predictions(&self) -> &Array1<f64> {
        &self.predictions
    }

    /// Returns the number of samples.
    #[must_use]
    pub fn n_samples(&self) -> usize {
        self.n_samples
    }

    /// Returns the number of features.
    #[must_use]
    pub fn n_features(&self) -> usize {
        self.n_features
    }

    /// Verifies the local accuracy property for all samples.
    ///
    /// For each sample, checks that
    /// `|prediction - (base_value + sum(shap_values))| < tolerance`.
    ///
    /// The default tolerance is `1e-7` (generous for post-serialization
    /// float round-trip loss).
    #[must_use]
    pub fn verify(&self) -> VerificationReport {
        self.verify_with_tolerance(1e-7)
    }

    /// Verifies local accuracy with a custom tolerance.
    ///
    /// For regression/binary: checks `|pred - (base + sum(shap))| < tol`.
    /// For multiclass: checks per-class accuracy using the scalar sum of
    /// all tree outputs vs the sum of all SHAP values + all base values.
    #[must_use]
    pub fn verify_with_tolerance(&self, tolerance: f64) -> VerificationReport {
        let mut failures = Vec::new();

        for s in 0..self.n_samples {
            let prediction = self.predictions[s];
            let shap_sum = self.shap_sum_for_sample(s);
            let base = self.base_scalar_for_sample();
            let reconstructed = base + shap_sum;
            let deviation = (prediction - reconstructed).abs();

            // NaN deviations should always fail — NaN > tolerance is false
            // under IEEE 754, so we explicitly check for it.
            if deviation > tolerance || deviation.is_nan() {
                failures.push(FailingSample::new(s, prediction, reconstructed, deviation));
            }
        }

        VerificationReport {
            n_samples: self.n_samples,
            tolerance,
            failures,
        }
    }

    /// Returns the sum of SHAP values for a single sample.
    fn shap_sum_for_sample(&self, sample_idx: usize) -> f64 {
        match &self.shap_values {
            ShapOutput::Flat(arr) => arr.row(sample_idx).iter().sum(),
            ShapOutput::Multiclass { values, .. } => values.row(sample_idx).iter().sum(),
        }
    }

    /// Returns the scalar base value.
    /// For multiclass, sums all per-class base values to match the scalar
    /// prediction (which is also the sum of all tree outputs).
    fn base_scalar_for_sample(&self) -> f64 {
        match &self.base_value {
            BaseValue::Scalar(v) => *v,
            BaseValue::Vector(v) => v.iter().sum(),
        }
    }
}

impl fmt::Display for ShapExplanation {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        writeln!(
            f,
            "ShapExplanation ({} samples, {} features)",
            self.n_samples, self.n_features
        )?;

        let base_str = match &self.base_value {
            BaseValue::Scalar(v) => format!("{v:.6}"),
            BaseValue::Vector(v) => format!("{v:?}"),
        };
        writeln!(f, "  Base value: {base_str}")?;

        if self.n_samples > 0 {
            let row_data: Vec<f64> = match &self.shap_values {
                ShapOutput::Flat(arr) => arr.row(0).to_vec(),
                ShapOutput::Multiclass { values, n_classes } => {
                    // Show sum across classes per feature for sample 0.
                    writeln!(
                        f,
                        "  (multiclass: {n_classes} classes, showing per-feature sum)"
                    )?;
                    let row = values.row(0);
                    (0..self.n_features)
                        .map(|feat| {
                            (0..*n_classes)
                                .map(|c| row[c * self.n_features + feat])
                                .sum()
                        })
                        .collect()
                }
            };

            writeln!(f, "  Sample 0 SHAP values:")?;
            for (i, &v) in row_data.iter().enumerate().take(10) {
                let name = self
                    .feature_names
                    .as_ref()
                    .and_then(|n| n.get(i))
                    .map(|s| {
                        if s.len() > 20 {
                            format!("{}...", &s[..17])
                        } else {
                            s.clone()
                        }
                    })
                    .unwrap_or_else(|| format!("Feature {i}"));
                writeln!(f, "    {name}: {v:+.6}")?;
            }
            if self.n_features > 10 {
                writeln!(f, "    ... ({} more features)", self.n_features - 10)?;
            }
        }

        Ok(())
    }
}

// Conditional serde support.
#[cfg(feature = "serde")]
mod serde_impl {
    use super::*;
    use serde::{Deserialize, Serialize};

    #[derive(Serialize, Deserialize)]
    struct ShapExplanationSerde {
        shap_values_flat: Option<Vec<Vec<f64>>>,
        shap_values_multiclass: Option<Vec<Vec<f64>>>,
        n_classes: Option<usize>,
        base_value_scalar: Option<f64>,
        base_value_vector: Option<Vec<f64>>,
        feature_values: Option<Vec<Vec<f64>>>,
        feature_names: Option<Vec<String>>,
        predictions: Vec<f64>,
        n_samples: usize,
        n_features: usize,
    }

    impl Serialize for ShapExplanation {
        fn serialize<S: serde::Serializer>(&self, serializer: S) -> Result<S::Ok, S::Error> {
            let (flat, multi, nc) = match &self.shap_values {
                ShapOutput::Flat(arr) => {
                    let rows: Vec<Vec<f64>> = arr.rows().into_iter().map(|r| r.to_vec()).collect();
                    (Some(rows), None, None)
                }
                ShapOutput::Multiclass { values, n_classes } => {
                    let rows: Vec<Vec<f64>> =
                        values.rows().into_iter().map(|r| r.to_vec()).collect();
                    (None, Some(rows), Some(*n_classes))
                }
            };

            let (bs, bv) = match &self.base_value {
                BaseValue::Scalar(v) => (Some(*v), None),
                BaseValue::Vector(v) => (None, Some(v.clone())),
            };

            let fv = self
                .feature_values
                .as_ref()
                .map(|arr| arr.rows().into_iter().map(|r| r.to_vec()).collect());

            let proxy = ShapExplanationSerde {
                shap_values_flat: flat,
                shap_values_multiclass: multi,
                n_classes: nc,
                base_value_scalar: bs,
                base_value_vector: bv,
                feature_values: fv,
                feature_names: self.feature_names.clone(),
                predictions: self.predictions.to_vec(),
                n_samples: self.n_samples,
                n_features: self.n_features,
            };
            proxy.serialize(serializer)
        }
    }

    impl<'de> Deserialize<'de> for ShapExplanation {
        fn deserialize<D: serde::Deserializer<'de>>(deserializer: D) -> Result<Self, D::Error> {
            let proxy = ShapExplanationSerde::deserialize(deserializer)?;

            let shap_values = if let Some(flat) = proxy.shap_values_flat {
                let n = flat.len();
                let m = flat.first().map_or(0, |r| r.len());
                let data: Vec<f64> = flat.into_iter().flatten().collect();
                ShapOutput::Flat(
                    Array2::from_shape_vec((n, m), data).map_err(serde::de::Error::custom)?,
                )
            } else if let Some(multi) = proxy.shap_values_multiclass {
                let n = multi.len();
                let m = multi.first().map_or(0, |r| r.len());
                let data: Vec<f64> = multi.into_iter().flatten().collect();
                ShapOutput::Multiclass {
                    values: Array2::from_shape_vec((n, m), data)
                        .map_err(serde::de::Error::custom)?,
                    n_classes: proxy.n_classes.ok_or_else(|| {
                        serde::de::Error::custom("missing n_classes for multiclass shap_values")
                    })?,
                }
            } else {
                return Err(serde::de::Error::custom(
                    "missing shap_values_flat or shap_values_multiclass",
                ));
            };

            let base_value = if let Some(v) = proxy.base_value_scalar {
                BaseValue::Scalar(v)
            } else if let Some(v) = proxy.base_value_vector {
                BaseValue::Vector(v)
            } else {
                return Err(serde::de::Error::custom(
                    "missing base_value_scalar or base_value_vector",
                ));
            };

            let feature_values = match proxy.feature_values {
                Some(fv) => {
                    let n = fv.len();
                    let m = fv.first().map_or(0, |r| r.len());
                    let data: Vec<f64> = fv.into_iter().flatten().collect();
                    Some(Array2::from_shape_vec((n, m), data).map_err(serde::de::Error::custom)?)
                }
                None => None,
            };

            Ok(ShapExplanation {
                shap_values,
                base_value,
                feature_values,
                feature_names: proxy.feature_names,
                predictions: Array1::from(proxy.predictions),
                n_samples: proxy.n_samples,
                n_features: proxy.n_features,
            })
        }
    }
}

/// A sample that failed the local accuracy check.
#[derive(Debug, Clone, PartialEq)]
pub struct FailingSample {
    index: usize,
    prediction: f64,
    reconstructed: f64,
    deviation: f64,
}

impl FailingSample {
    pub(crate) fn new(index: usize, prediction: f64, reconstructed: f64, deviation: f64) -> Self {
        Self {
            index,
            prediction,
            reconstructed,
            deviation,
        }
    }

    /// Sample index.
    #[must_use]
    pub fn index(&self) -> usize {
        self.index
    }

    /// The model's prediction for this sample.
    #[must_use]
    pub fn prediction(&self) -> f64 {
        self.prediction
    }

    /// The reconstructed value (base + sum(shap)).
    #[must_use]
    pub fn reconstructed(&self) -> f64 {
        self.reconstructed
    }

    /// Absolute deviation between prediction and reconstructed.
    #[must_use]
    pub fn deviation(&self) -> f64 {
        self.deviation
    }
}

/// Result of a local accuracy verification.
#[derive(Debug, Clone, PartialEq)]
pub struct VerificationReport {
    pub(crate) n_samples: usize,
    pub(crate) tolerance: f64,
    pub(crate) failures: Vec<FailingSample>,
}

impl VerificationReport {
    /// Total number of samples checked.
    #[must_use]
    pub fn n_samples(&self) -> usize {
        self.n_samples
    }

    /// Returns the list of failing samples.
    #[must_use]
    pub fn failures(&self) -> &[FailingSample] {
        &self.failures
    }

    /// Returns `true` if all samples pass the accuracy check.
    #[must_use]
    pub fn is_pass(&self) -> bool {
        self.failures.is_empty()
    }

    /// Number of passing samples.
    #[must_use]
    pub fn n_passing(&self) -> usize {
        self.n_samples - self.failures.len()
    }

    /// Number of failing samples.
    #[must_use]
    pub fn n_failing(&self) -> usize {
        self.failures.len()
    }
}

impl fmt::Display for VerificationReport {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if self.is_pass() {
            write!(
                f,
                "PASS: all {} samples within tolerance {:.0e}",
                self.n_samples, self.tolerance
            )
        } else {
            writeln!(
                f,
                "FAIL: {}/{} samples exceed tolerance {:.0e}",
                self.n_failing(),
                self.n_samples,
                self.tolerance
            )?;
            for s in self.failures.iter().take(10) {
                writeln!(
                    f,
                    "  sample {}: prediction={:.8}, reconstructed={:.8}, deviation={:.2e}",
                    s.index(),
                    s.prediction(),
                    s.reconstructed(),
                    s.deviation()
                )?;
            }
            if self.failures.len() > 10 {
                write!(f, "  ... ({} more)", self.failures.len() - 10)?;
            }
            Ok(())
        }
    }
}
