#![forbid(unsafe_code)]
#![warn(missing_docs)]

//! Core algorithms and data structures for TreeSHAP.
//!
//! This crate provides the unified intermediate representation (IR) for tree
//! ensemble models and the SHAP computation engine. The IR is designed to be
//! produced by format-specific parsers (in `treeshap-io`) and consumed by
//! the visualization layer (in `treeshap-viz`) and the CLI (`treeshap-cli`).
//!
//! # Key Types
//!
//! - [`TreeNode`] — a single node in a decision tree (internal or leaf).
//! - [`TreeEnsemble`] — a validated collection of trees with metadata.
//! - [`TreeEnsembleBuilder`] — typestate builder that enforces required fields
//!   at compile time.
//! - [`MissingDirection`] — routing direction for missing feature values.
//! - [`TaskType`] — the learning task (regression, binary, multiclass).
//! - [`ValidationError`] — errors detected during ensemble construction.
//!
//! # Construction
//!
//! ```
//! use treeshap_core::{
//!     TreeEnsembleBuilder, TreeNode, TaskType, MissingDirection,
//! };
//!
//! let tree = vec![
//!     TreeNode::internal(0, 0.5, 1, 2, MissingDirection::Left, 100.0),
//!     TreeNode::leaf(1.0, 60.0),
//!     TreeNode::leaf(-1.0, 40.0),
//! ];
//!
//! let ensemble = TreeEnsembleBuilder::new()
//!     .task_type(TaskType::Regression)
//!     .n_features(1)
//!     .base_score(0.0)
//!     .trees(vec![tree])
//!     .build()
//!     .expect("valid ensemble");
//!
//! assert_eq!(ensemble.n_trees(), 1);
//! ```

pub mod builder;
pub mod ensemble;
pub mod error;
pub mod explainer;
pub mod explanation;
pub mod tree;

pub(crate) mod path;

// Re-export primary public types at the crate root for ergonomic imports.
pub use builder::{Configured, TreeEnsembleBuilder, Unconfigured};
pub use ensemble::TreeEnsemble;
pub use error::ValidationError;
pub use explainer::{BaseValue, Explainer, ShapMode, ShapOutput};
pub use explanation::{FailingSample, ShapExplanation, VerificationReport};
pub use tree::{MissingDirection, TaskType, TreeNode};

// Compile-time assertion: TreeEnsemble must be Send + Sync for safe
// parallel SHAP computation via rayon.
fn _assert_send_sync() {
    fn require_send_sync<T: Send + Sync>() {}
    require_send_sync::<TreeEnsemble>();
}

/// Returns the crate version at compile time.
#[must_use]
pub const fn version() -> &'static str {
    env!("CARGO_PKG_VERSION")
}
