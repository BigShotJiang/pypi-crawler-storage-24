//! Validation errors for the tree ensemble IR.
//!
//! These errors are produced at construction time by
//! [`TreeEnsemble::validate`](crate::ensemble::TreeEnsemble::validate)
//! (called automatically by the builder). Once a
//! [`TreeEnsemble`](crate::ensemble::TreeEnsemble) is successfully
//! constructed, downstream code can assume all structural invariants hold
//! without re-checking.

/// Errors detected during structural validation of a
/// [`TreeEnsemble`](crate::ensemble::TreeEnsemble).
///
/// Every variant carries enough context to pinpoint the offending node,
/// tree, or field. New variants may be added in future releases.
#[derive(Debug, Clone, PartialEq, thiserror::Error)]
#[non_exhaustive]
pub enum ValidationError {
    /// A split node references a child index that exceeds the tree's node
    /// array length.
    #[error(
        "tree {tree_index}, node {node_index}: child index {child_index} \
         out of bounds (tree has {node_count} nodes)"
    )]
    ChildOutOfBounds {
        /// Index of the tree within the ensemble.
        tree_index: usize,
        /// The node index that contains the invalid child reference.
        node_index: usize,
        /// The out-of-bounds child index.
        child_index: usize,
        /// Total number of nodes in this tree.
        node_count: usize,
    },

    /// A split node's feature index is greater than or equal to the declared
    /// feature count.
    #[error(
        "tree {tree_index}, node {node_index}: feature index {feature_index} \
         out of bounds (n_features = {n_features})"
    )]
    FeatureIndexOutOfBounds {
        /// Index of the tree within the ensemble.
        tree_index: usize,
        /// The node index containing the invalid feature reference.
        node_index: usize,
        /// The invalid feature index.
        feature_index: usize,
        /// The ensemble's declared feature count.
        n_features: usize,
    },

    /// A tree's node array is empty.
    #[error("tree {tree_index} is empty")]
    EmptyTree {
        /// Index of the empty tree.
        tree_index: usize,
    },

    /// For multiclass ensembles, the total tree count must be divisible by
    /// the number of classes.
    #[error("tree count {n_trees} is not divisible by n_classes {n_classes}")]
    TreeCountNotDivisible {
        /// Total number of trees in the ensemble.
        n_trees: usize,
        /// Number of classes declared by the task type.
        n_classes: usize,
    },

    /// The base score is not a finite floating-point value.
    #[error("base_score is not finite: {base_score}")]
    BaseScoreNotFinite {
        /// The invalid base score.
        base_score: f64,
    },

    /// A node has a non-finite or negative cover value.
    #[error("tree {tree_index}, node {node_index}: invalid cover {cover}")]
    InvalidCover {
        /// Index of the tree within the ensemble.
        tree_index: usize,
        /// The node index with invalid cover.
        node_index: usize,
        /// The invalid cover value.
        cover: f64,
    },

    /// A split node has a child index pointing to itself, creating a cycle.
    #[error(
        "tree {tree_index}, node {node_index}: child index {child_index} \
         references the node itself (cycle)"
    )]
    SelfReferentialNode {
        /// Index of the tree within the ensemble.
        tree_index: usize,
        /// The node that points to itself.
        node_index: usize,
        /// The self-referential child index.
        child_index: usize,
    },

    /// The `feature_names` vector length does not match `n_features`.
    #[error("feature_names length {names_len} does not match n_features {n_features}")]
    FeatureNamesMismatch {
        /// Length of the provided feature names vector.
        names_len: usize,
        /// The declared feature count.
        n_features: usize,
    },

    /// Multiclass task type has an invalid class count (must be >= 2).
    #[error("multiclass n_classes must be >= 2, got {n_classes}")]
    InvalidClassCount {
        /// The invalid class count.
        n_classes: usize,
    },

    /// A split node has a non-finite threshold value.
    #[error("tree {tree_index}, node {node_index}: threshold is not finite ({threshold})")]
    NonFiniteThreshold {
        /// Index of the tree within the ensemble.
        tree_index: usize,
        /// The node index with the invalid threshold.
        node_index: usize,
        /// The non-finite threshold value.
        threshold: f64,
    },

    /// The stored `n_trees` field does not match `trees.len()`.
    #[error("n_trees field ({n_trees}) does not match trees.len() ({actual})")]
    TreeCountMismatch {
        /// The stored n_trees value.
        n_trees: usize,
        /// The actual length of the trees vector.
        actual: usize,
    },

    /// A leaf node has a non-finite value (NaN or Inf), which would make
    /// the local accuracy invariant impossible to uphold.
    #[error("tree {tree_index}, node {node_index}: leaf value is not finite ({value})")]
    NonFiniteLeafValue {
        /// Index of the tree within the ensemble.
        tree_index: usize,
        /// The node index with the invalid leaf value.
        node_index: usize,
        /// The non-finite leaf value.
        value: f64,
    },
}
