//! The top-level tree ensemble container.
//!
//! [`TreeEnsemble`] is the canonical output of every parser in `treeshap-io`
//! and the sole input to the SHAP computation engine. It is constructed
//! exclusively through
//! [`TreeEnsembleBuilder`](crate::builder::TreeEnsembleBuilder) which
//! validates all structural invariants at construction time.

use crate::error::ValidationError;
use crate::tree::{TaskType, TreeNode};

/// A validated collection of decision trees with associated metadata.
///
/// Once constructed, all structural invariants are guaranteed to hold:
/// child indices are in bounds, feature indices are within `n_features`,
/// no tree is empty, cover values are non-negative, and `base_score` is
/// finite. Downstream code should not re-validate.
///
/// Construct via [`TreeEnsembleBuilder`].
///
/// [`TreeEnsembleBuilder`]: crate::builder::TreeEnsembleBuilder
#[derive(Debug, Clone, PartialEq)]
pub struct TreeEnsemble {
    pub(crate) trees: Vec<Vec<TreeNode>>,
    pub(crate) base_score: f64,
    pub(crate) task_type: TaskType,
    pub(crate) feature_names: Option<Vec<String>>,
    pub(crate) n_features: usize,
    pub(crate) n_trees: usize,
    /// Pre-computed expected (cover-weighted average) leaf value per tree.
    /// Avoids redundant full-tree scans during SHAP computation.
    pub(crate) expected_leaf_values: Vec<f64>,
}

impl TreeEnsemble {
    /// Per-tree flat node arrays. Outer index selects a tree, inner index
    /// selects a node within that tree (index 0 = root).
    #[must_use]
    pub fn trees(&self) -> &[Vec<TreeNode>] {
        &self.trees
    }

    /// Global bias term, in the same space as leaf values (pre-transform).
    #[must_use]
    pub fn base_score(&self) -> f64 {
        self.base_score
    }

    /// The learning task that produced this ensemble.
    #[must_use]
    pub fn task_type(&self) -> &TaskType {
        &self.task_type
    }

    /// Human-readable feature names, if the model format supplied them.
    #[must_use]
    pub fn feature_names(&self) -> Option<&[String]> {
        self.feature_names.as_deref()
    }

    /// Total number of input features. Explicitly stored because a model
    /// may contain features that no split node references.
    #[must_use]
    pub fn n_features(&self) -> usize {
        self.n_features
    }

    /// Total number of trees. Equal to `trees().len()`, stored for fast access.
    #[must_use]
    pub fn n_trees(&self) -> usize {
        self.n_trees
    }

    /// Pre-computed expected leaf values per tree. Index `i` corresponds to
    /// `trees()[i]`. Each value is the cover-weighted average leaf value of
    /// that tree, used to compute the SHAP base value `E[f(x)]`.
    #[must_use]
    pub fn expected_leaf_values(&self) -> &[f64] {
        &self.expected_leaf_values
    }
    /// Validates all structural invariants of the ensemble.
    ///
    /// This is called automatically by the builder at construction time.
    /// It may also be called after deserialization to re-verify integrity.
    ///
    /// # Errors
    ///
    /// Returns the first [`ValidationError`] encountered. Checks are ordered
    /// from cheapest to most expensive.
    pub fn validate(&self) -> Result<(), ValidationError> {
        // Base score must be finite.
        if !self.base_score.is_finite() {
            return Err(ValidationError::BaseScoreNotFinite {
                base_score: self.base_score,
            });
        }

        // n_trees must match actual tree count (catches deserialization drift).
        if self.n_trees != self.trees.len() {
            return Err(ValidationError::TreeCountMismatch {
                n_trees: self.n_trees,
                actual: self.trees.len(),
            });
        }

        // Multiclass n_classes must be >= 2.
        if let TaskType::MulticlassClassification { n_classes } = &self.task_type {
            if *n_classes < 2 {
                return Err(ValidationError::InvalidClassCount {
                    n_classes: *n_classes,
                });
            }
            if self.n_trees % n_classes != 0 {
                return Err(ValidationError::TreeCountNotDivisible {
                    n_trees: self.n_trees,
                    n_classes: *n_classes,
                });
            }
        }

        // Feature names length must match n_features when provided.
        if let Some(ref names) = self.feature_names {
            if names.len() != self.n_features {
                return Err(ValidationError::FeatureNamesMismatch {
                    names_len: names.len(),
                    n_features: self.n_features,
                });
            }
        }

        for (tree_idx, tree) in self.trees.iter().enumerate() {
            // No tree may be empty.
            if tree.is_empty() {
                return Err(ValidationError::EmptyTree {
                    tree_index: tree_idx,
                });
            }

            let node_count = tree.len();

            for (node_idx, node) in tree.iter().enumerate() {
                // Cover must be finite and non-negative on every node.
                // Uses !is_finite() to reject NaN, +Inf, and -Inf
                // (consistent with the base_score check).
                let cover = node.cover();
                if !cover.is_finite() || cover < 0.0 {
                    return Err(ValidationError::InvalidCover {
                        tree_index: tree_idx,
                        node_index: node_idx,
                        cover,
                    });
                }

                if let TreeNode::Leaf { value, .. } = node {
                    if !value.is_finite() {
                        return Err(ValidationError::NonFiniteLeafValue {
                            tree_index: tree_idx,
                            node_index: node_idx,
                            value: *value,
                        });
                    }
                }

                if let TreeNode::Internal {
                    feature_index,
                    threshold,
                    left_child,
                    right_child,
                    ..
                } = node
                {
                    // Threshold must be finite (NaN would corrupt split routing).
                    if !threshold.is_finite() {
                        return Err(ValidationError::NonFiniteThreshold {
                            tree_index: tree_idx,
                            node_index: node_idx,
                            threshold: *threshold,
                        });
                    }

                    // Feature index must be within declared range.
                    if *feature_index >= self.n_features {
                        return Err(ValidationError::FeatureIndexOutOfBounds {
                            tree_index: tree_idx,
                            node_index: node_idx,
                            feature_index: *feature_index,
                            n_features: self.n_features,
                        });
                    }

                    // Child indices must be within the tree's node array.
                    if *left_child >= node_count {
                        return Err(ValidationError::ChildOutOfBounds {
                            tree_index: tree_idx,
                            node_index: node_idx,
                            child_index: *left_child,
                            node_count,
                        });
                    }
                    if *right_child >= node_count {
                        return Err(ValidationError::ChildOutOfBounds {
                            tree_index: tree_idx,
                            node_index: node_idx,
                            child_index: *right_child,
                            node_count,
                        });
                    }

                    // No node may reference itself as a child (cycle).
                    if *left_child == node_idx {
                        return Err(ValidationError::SelfReferentialNode {
                            tree_index: tree_idx,
                            node_index: node_idx,
                            child_index: *left_child,
                        });
                    }
                    if *right_child == node_idx {
                        return Err(ValidationError::SelfReferentialNode {
                            tree_index: tree_idx,
                            node_index: node_idx,
                            child_index: *right_child,
                        });
                    }
                }
            }
        }

        Ok(())
    }
}

/// Computes the expected (cover-weighted average) leaf value of a single tree.
///
/// This is the expected prediction of the tree over the training distribution,
/// used to compute the SHAP base value `E[f(x)]`.
pub(crate) fn expected_leaf_value(tree: &[TreeNode]) -> f64 {
    if tree.is_empty() {
        return 0.0;
    }

    let root_cover = tree[0].cover();
    if root_cover == 0.0 {
        return 0.0;
    }

    let mut sum = 0.0;
    for node in tree {
        if let TreeNode::Leaf { value, cover, .. } = node {
            sum += value * cover;
        }
    }
    sum / root_cover
}

#[cfg(test)]
mod tests {
    use crate::builder::TreeEnsembleBuilder;
    use crate::tree::{MissingDirection, TaskType, TreeNode};
    use crate::ValidationError;

    /// Helper: builds a minimal valid 3-node tree (root + 2 leaves).
    fn minimal_tree() -> Vec<TreeNode> {
        vec![
            TreeNode::Internal {
                feature_index: 0,
                threshold: 0.5,
                left_child: 1,
                right_child: 2,
                missing_direction: MissingDirection::Left,
                cover: 100.0,
            },
            TreeNode::Leaf {
                value: 1.0,
                cover: 60.0,
            },
            TreeNode::Leaf {
                value: -1.0,
                cover: 40.0,
            },
        ]
    }

    /// Helper: builds a valid ensemble from a single minimal tree.
    fn build_valid() -> Result<crate::TreeEnsemble, ValidationError> {
        TreeEnsembleBuilder::new()
            .task_type(TaskType::Regression)
            .n_features(1)
            .base_score(0.0)
            .trees(vec![minimal_tree()])
            .build()
    }

    #[test]
    fn valid_minimal_ensemble() {
        let ensemble = build_valid().expect("should build successfully");
        assert_eq!(ensemble.n_trees, 1);
        assert_eq!(ensemble.n_features, 1);
        assert_eq!(ensemble.task_type, TaskType::Regression);
        assert!((ensemble.base_score - 0.0).abs() < f64::EPSILON);
        assert!(ensemble.feature_names.is_none());
    }

    #[test]
    fn valid_ensemble_with_feature_names() {
        let ensemble = TreeEnsembleBuilder::new()
            .task_type(TaskType::Regression)
            .n_features(1)
            .base_score(0.0)
            .trees(vec![minimal_tree()])
            .feature_names(vec!["age".to_string()])
            .build()
            .expect("should build successfully");
        assert_eq!(
            ensemble.feature_names.as_deref(),
            Some(["age".to_string()].as_slice())
        );
    }

    #[test]
    fn valid_ensemble_fields_accessible() {
        let ensemble = build_valid().expect("should build");
        assert_eq!(ensemble.trees.len(), 1);
        assert_eq!(ensemble.trees[0].len(), 3);
        assert!(ensemble.trees[0][0].is_internal());
        assert!(ensemble.trees[0][1].is_leaf());
        assert!(ensemble.trees[0][2].is_leaf());
    }

    // --- Validation failure tests ---

    #[test]
    fn rejects_left_child_out_of_bounds() {
        let tree = vec![
            TreeNode::Internal {
                feature_index: 0,
                threshold: 0.5,
                left_child: 99, // out of bounds
                right_child: 2,
                missing_direction: MissingDirection::Left,
                cover: 100.0,
            },
            TreeNode::Leaf {
                value: 1.0,
                cover: 60.0,
            },
            TreeNode::Leaf {
                value: -1.0,
                cover: 40.0,
            },
        ];
        let err = TreeEnsembleBuilder::new()
            .task_type(TaskType::Regression)
            .n_features(1)
            .base_score(0.0)
            .trees(vec![tree])
            .build()
            .unwrap_err();
        assert_eq!(
            err,
            ValidationError::ChildOutOfBounds {
                tree_index: 0,
                node_index: 0,
                child_index: 99,
                node_count: 3,
            }
        );
    }

    #[test]
    fn rejects_right_child_out_of_bounds() {
        let tree = vec![
            TreeNode::Internal {
                feature_index: 0,
                threshold: 0.5,
                left_child: 1,
                right_child: 50, // out of bounds
                missing_direction: MissingDirection::Left,
                cover: 100.0,
            },
            TreeNode::Leaf {
                value: 1.0,
                cover: 60.0,
            },
            TreeNode::Leaf {
                value: -1.0,
                cover: 40.0,
            },
        ];
        let err = TreeEnsembleBuilder::new()
            .task_type(TaskType::Regression)
            .n_features(1)
            .base_score(0.0)
            .trees(vec![tree])
            .build()
            .unwrap_err();
        assert_eq!(
            err,
            ValidationError::ChildOutOfBounds {
                tree_index: 0,
                node_index: 0,
                child_index: 50,
                node_count: 3,
            }
        );
    }

    #[test]
    fn rejects_feature_index_out_of_bounds() {
        let tree = vec![
            TreeNode::Internal {
                feature_index: 5, // n_features = 1, so 5 >= 1
                threshold: 0.5,
                left_child: 1,
                right_child: 2,
                missing_direction: MissingDirection::Left,
                cover: 100.0,
            },
            TreeNode::Leaf {
                value: 1.0,
                cover: 60.0,
            },
            TreeNode::Leaf {
                value: -1.0,
                cover: 40.0,
            },
        ];
        let err = TreeEnsembleBuilder::new()
            .task_type(TaskType::Regression)
            .n_features(1)
            .base_score(0.0)
            .trees(vec![tree])
            .build()
            .unwrap_err();
        assert_eq!(
            err,
            ValidationError::FeatureIndexOutOfBounds {
                tree_index: 0,
                node_index: 0,
                feature_index: 5,
                n_features: 1,
            }
        );
    }

    #[test]
    fn rejects_empty_tree() {
        let err = TreeEnsembleBuilder::new()
            .task_type(TaskType::Regression)
            .n_features(1)
            .base_score(0.0)
            .trees(vec![vec![]]) // empty tree
            .build()
            .unwrap_err();
        assert_eq!(err, ValidationError::EmptyTree { tree_index: 0 });
    }

    #[test]
    fn rejects_non_finite_base_score_nan() {
        let err = TreeEnsembleBuilder::new()
            .task_type(TaskType::Regression)
            .n_features(1)
            .base_score(f64::NAN)
            .trees(vec![minimal_tree()])
            .build()
            .unwrap_err();
        // NaN != NaN, so match on variant instead
        assert!(matches!(err, ValidationError::BaseScoreNotFinite { .. }));
    }

    #[test]
    fn rejects_non_finite_base_score_inf() {
        let err = TreeEnsembleBuilder::new()
            .task_type(TaskType::Regression)
            .n_features(1)
            .base_score(f64::INFINITY)
            .trees(vec![minimal_tree()])
            .build()
            .unwrap_err();
        assert_eq!(
            err,
            ValidationError::BaseScoreNotFinite {
                base_score: f64::INFINITY,
            }
        );
    }

    #[test]
    fn rejects_negative_cover() {
        let tree = vec![
            TreeNode::Internal {
                feature_index: 0,
                threshold: 0.5,
                left_child: 1,
                right_child: 2,
                missing_direction: MissingDirection::Left,
                cover: -1.0, // negative
            },
            TreeNode::Leaf {
                value: 1.0,
                cover: 60.0,
            },
            TreeNode::Leaf {
                value: -1.0,
                cover: 40.0,
            },
        ];
        let err = TreeEnsembleBuilder::new()
            .task_type(TaskType::Regression)
            .n_features(1)
            .base_score(0.0)
            .trees(vec![tree])
            .build()
            .unwrap_err();
        assert_eq!(
            err,
            ValidationError::InvalidCover {
                tree_index: 0,
                node_index: 0,
                cover: -1.0,
            }
        );
    }

    #[test]
    fn rejects_negative_cover_on_leaf() {
        let tree = vec![
            TreeNode::Internal {
                feature_index: 0,
                threshold: 0.5,
                left_child: 1,
                right_child: 2,
                missing_direction: MissingDirection::Left,
                cover: 100.0,
            },
            TreeNode::Leaf {
                value: 1.0,
                cover: -5.0, // negative on leaf
            },
            TreeNode::Leaf {
                value: -1.0,
                cover: 40.0,
            },
        ];
        let err = TreeEnsembleBuilder::new()
            .task_type(TaskType::Regression)
            .n_features(1)
            .base_score(0.0)
            .trees(vec![tree])
            .build()
            .unwrap_err();
        assert_eq!(
            err,
            ValidationError::InvalidCover {
                tree_index: 0,
                node_index: 1,
                cover: -5.0,
            }
        );
    }

    #[test]
    fn rejects_multiclass_tree_count_not_divisible() {
        // 2 trees with 3 classes — 2 % 3 != 0
        let err = TreeEnsembleBuilder::new()
            .task_type(TaskType::MulticlassClassification { n_classes: 3 })
            .n_features(1)
            .base_score(0.0)
            .trees(vec![minimal_tree(), minimal_tree()])
            .build()
            .unwrap_err();
        assert_eq!(
            err,
            ValidationError::TreeCountNotDivisible {
                n_trees: 2,
                n_classes: 3,
            }
        );
    }

    #[test]
    fn accepts_multiclass_tree_count_divisible() {
        let ensemble = TreeEnsembleBuilder::new()
            .task_type(TaskType::MulticlassClassification { n_classes: 3 })
            .n_features(1)
            .base_score(0.0)
            .trees(vec![minimal_tree(), minimal_tree(), minimal_tree()])
            .build()
            .expect("3 trees / 3 classes should be valid");
        assert_eq!(ensemble.n_trees, 3);
    }

    #[test]
    fn zero_trees_is_valid_for_regression() {
        // An ensemble with zero trees is structurally valid — it just always
        // predicts base_score.
        let ensemble = TreeEnsembleBuilder::new()
            .task_type(TaskType::Regression)
            .n_features(1)
            .base_score(0.5)
            .build()
            .expect("zero trees should be valid");
        assert_eq!(ensemble.n_trees, 0);
        assert!(ensemble.trees.is_empty());
    }

    #[test]
    fn builder_tree_method_appends() {
        let ensemble = TreeEnsembleBuilder::new()
            .task_type(TaskType::Regression)
            .n_features(1)
            .base_score(0.0)
            .tree(minimal_tree())
            .tree(minimal_tree())
            .build()
            .expect("two trees via tree()");
        assert_eq!(ensemble.n_trees, 2);
    }

    #[test]
    fn builder_fields_can_be_set_in_any_order() {
        let ensemble = TreeEnsembleBuilder::new()
            .base_score(0.0)
            .trees(vec![minimal_tree()])
            .n_features(1)
            .task_type(TaskType::Regression)
            .build()
            .expect("arbitrary field order should work");
        assert_eq!(ensemble.n_trees, 1);
    }

    #[test]
    fn validation_error_display_is_descriptive() {
        let err = ValidationError::ChildOutOfBounds {
            tree_index: 2,
            node_index: 5,
            child_index: 99,
            node_count: 10,
        };
        let msg = err.to_string();
        assert!(msg.contains("tree 2"));
        assert!(msg.contains("node 5"));
        assert!(msg.contains("99"));
        assert!(msg.contains("10"));
    }

    #[test]
    fn validation_error_is_std_error() {
        fn assert_error<E: std::error::Error>() {}
        assert_error::<ValidationError>();
    }

    // --- New edge-case tests from code review ---

    #[test]
    fn rejects_nan_cover_on_internal_node() {
        let tree = vec![
            TreeNode::Internal {
                feature_index: 0,
                threshold: 0.5,
                left_child: 1,
                right_child: 2,
                missing_direction: MissingDirection::Left,
                cover: f64::NAN,
            },
            TreeNode::Leaf {
                value: 1.0,
                cover: 60.0,
            },
            TreeNode::Leaf {
                value: -1.0,
                cover: 40.0,
            },
        ];
        let err = TreeEnsembleBuilder::new()
            .task_type(TaskType::Regression)
            .n_features(1)
            .base_score(0.0)
            .trees(vec![tree])
            .build()
            .unwrap_err();
        assert!(matches!(err, ValidationError::InvalidCover { .. }));
    }

    #[test]
    fn rejects_nan_cover_on_leaf() {
        let tree = vec![
            TreeNode::Internal {
                feature_index: 0,
                threshold: 0.5,
                left_child: 1,
                right_child: 2,
                missing_direction: MissingDirection::Left,
                cover: 100.0,
            },
            TreeNode::Leaf {
                value: 1.0,
                cover: f64::NAN,
            },
            TreeNode::Leaf {
                value: -1.0,
                cover: 40.0,
            },
        ];
        let err = TreeEnsembleBuilder::new()
            .task_type(TaskType::Regression)
            .n_features(1)
            .base_score(0.0)
            .trees(vec![tree])
            .build()
            .unwrap_err();
        assert!(matches!(err, ValidationError::InvalidCover { .. }));
    }

    #[test]
    fn rejects_feature_names_length_mismatch() {
        let err = TreeEnsembleBuilder::new()
            .task_type(TaskType::Regression)
            .n_features(4)
            .base_score(0.0)
            .trees(vec![minimal_tree()])
            .feature_names(vec!["a".into(), "b".into()]) // 2 names, 4 features
            .build()
            .unwrap_err();
        assert_eq!(
            err,
            ValidationError::FeatureNamesMismatch {
                names_len: 2,
                n_features: 4,
            }
        );
    }

    #[test]
    fn rejects_self_referential_left_child() {
        let tree = vec![
            TreeNode::Internal {
                feature_index: 0,
                threshold: 0.5,
                left_child: 0, // points to itself
                right_child: 1,
                missing_direction: MissingDirection::Left,
                cover: 100.0,
            },
            TreeNode::Leaf {
                value: 1.0,
                cover: 60.0,
            },
        ];
        let err = TreeEnsembleBuilder::new()
            .task_type(TaskType::Regression)
            .n_features(1)
            .base_score(0.0)
            .trees(vec![tree])
            .build()
            .unwrap_err();
        assert!(matches!(err, ValidationError::SelfReferentialNode { .. }));
    }

    #[test]
    fn rejects_self_referential_right_child() {
        let tree = vec![
            TreeNode::Internal {
                feature_index: 0,
                threshold: 0.5,
                left_child: 1,
                right_child: 0, // points to itself
                missing_direction: MissingDirection::Left,
                cover: 100.0,
            },
            TreeNode::Leaf {
                value: 1.0,
                cover: 60.0,
            },
        ];
        let err = TreeEnsembleBuilder::new()
            .task_type(TaskType::Regression)
            .n_features(1)
            .base_score(0.0)
            .trees(vec![tree])
            .build()
            .unwrap_err();
        assert!(matches!(err, ValidationError::SelfReferentialNode { .. }));
    }

    #[test]
    fn rejects_multiclass_n_classes_zero() {
        let err = TreeEnsembleBuilder::new()
            .task_type(TaskType::MulticlassClassification { n_classes: 0 })
            .n_features(1)
            .base_score(0.0)
            .trees(vec![minimal_tree()])
            .build()
            .unwrap_err();
        assert_eq!(err, ValidationError::InvalidClassCount { n_classes: 0 });
    }

    #[test]
    fn rejects_multiclass_n_classes_one() {
        let err = TreeEnsembleBuilder::new()
            .task_type(TaskType::MulticlassClassification { n_classes: 1 })
            .n_features(1)
            .base_score(0.0)
            .trees(vec![minimal_tree()])
            .build()
            .unwrap_err();
        assert_eq!(err, ValidationError::InvalidClassCount { n_classes: 1 });
    }

    #[test]
    fn rejects_nan_threshold() {
        let tree = vec![
            TreeNode::Internal {
                feature_index: 0,
                threshold: f64::NAN,
                left_child: 1,
                right_child: 2,
                missing_direction: MissingDirection::Left,
                cover: 100.0,
            },
            TreeNode::Leaf {
                value: 1.0,
                cover: 60.0,
            },
            TreeNode::Leaf {
                value: -1.0,
                cover: 40.0,
            },
        ];
        let err = TreeEnsembleBuilder::new()
            .task_type(TaskType::Regression)
            .n_features(1)
            .base_score(0.0)
            .trees(vec![tree])
            .build()
            .unwrap_err();
        assert!(matches!(err, ValidationError::NonFiniteThreshold { .. }));
    }

    #[test]
    fn rejects_inf_threshold() {
        let tree = vec![
            TreeNode::Internal {
                feature_index: 0,
                threshold: f64::INFINITY,
                left_child: 1,
                right_child: 2,
                missing_direction: MissingDirection::Left,
                cover: 100.0,
            },
            TreeNode::Leaf {
                value: 1.0,
                cover: 60.0,
            },
            TreeNode::Leaf {
                value: -1.0,
                cover: 40.0,
            },
        ];
        let err = TreeEnsembleBuilder::new()
            .task_type(TaskType::Regression)
            .n_features(1)
            .base_score(0.0)
            .trees(vec![tree])
            .build()
            .unwrap_err();
        assert_eq!(
            err,
            ValidationError::NonFiniteThreshold {
                tree_index: 0,
                node_index: 0,
                threshold: f64::INFINITY,
            }
        );
    }

    #[test]
    fn single_leaf_tree_is_valid() {
        let tree = vec![TreeNode::Leaf {
            value: 0.5,
            cover: 100.0,
        }];
        let ensemble = TreeEnsembleBuilder::new()
            .task_type(TaskType::Regression)
            .n_features(1)
            .base_score(0.0)
            .trees(vec![tree])
            .build()
            .expect("single leaf tree should be valid");
        assert_eq!(ensemble.trees[0].len(), 1);
    }

    #[test]
    fn zero_cover_is_valid() {
        let tree = vec![TreeNode::Leaf {
            value: 0.5,
            cover: 0.0,
        }];
        let ensemble = TreeEnsembleBuilder::new()
            .task_type(TaskType::Regression)
            .n_features(1)
            .base_score(0.0)
            .trees(vec![tree])
            .build()
            .expect("zero cover should be valid");
        assert!((ensemble.trees[0][0].cover() - 0.0).abs() < f64::EPSILON);
    }

    #[test]
    fn rejects_inf_cover() {
        let tree = vec![TreeNode::Leaf {
            value: 0.5,
            cover: f64::INFINITY,
        }];
        let err = TreeEnsembleBuilder::new()
            .task_type(TaskType::Regression)
            .n_features(1)
            .base_score(0.0)
            .trees(vec![tree])
            .build()
            .unwrap_err();
        assert!(matches!(err, ValidationError::InvalidCover { .. }));
    }

    #[test]
    fn rejects_neg_inf_cover() {
        let tree = vec![TreeNode::Leaf {
            value: 0.5,
            cover: f64::NEG_INFINITY,
        }];
        let err = TreeEnsembleBuilder::new()
            .task_type(TaskType::Regression)
            .n_features(1)
            .base_score(0.0)
            .trees(vec![tree])
            .build()
            .unwrap_err();
        assert!(matches!(err, ValidationError::InvalidCover { .. }));
    }

    #[test]
    fn rejects_nan_leaf_value() {
        let tree = vec![TreeNode::Leaf {
            value: f64::NAN,
            cover: 100.0,
        }];
        let err = TreeEnsembleBuilder::new()
            .task_type(TaskType::Regression)
            .n_features(1)
            .base_score(0.0)
            .trees(vec![tree])
            .build()
            .unwrap_err();
        assert!(matches!(err, ValidationError::NonFiniteLeafValue { .. }));
    }

    #[test]
    fn rejects_inf_leaf_value() {
        let tree = vec![TreeNode::Leaf {
            value: f64::INFINITY,
            cover: 100.0,
        }];
        let err = TreeEnsembleBuilder::new()
            .task_type(TaskType::Regression)
            .n_features(1)
            .base_score(0.0)
            .trees(vec![tree])
            .build()
            .unwrap_err();
        assert_eq!(
            err,
            ValidationError::NonFiniteLeafValue {
                tree_index: 0,
                node_index: 0,
                value: f64::INFINITY,
            }
        );
    }
}
