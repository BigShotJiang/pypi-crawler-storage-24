//! Typestate builder for [`TreeEnsemble`].
//!
//! The builder enforces at the **type system level** that all required fields
//! are set before [`build()`] can be called. Attempting to call `build()`
//! without setting `task_type`, `n_features`, and `base_score` is a
//! **compile-time error**, not a runtime panic.
//!
//! # Example
//!
//! ```
//! use treeshap_core::{
//!     TreeEnsembleBuilder, TreeNode, TaskType, MissingDirection,
//! };
//!
//! let tree = vec![
//!     TreeNode::internal(0, 0.5, 1, 2, MissingDirection::Left, 100.0),
//!     TreeNode::leaf(1.0, 60.0),
//!     TreeNode::leaf(-1.0, 40.0),
//! ];
//!
//! let ensemble = TreeEnsembleBuilder::new()
//!     .task_type(TaskType::Regression)
//!     .n_features(1)
//!     .base_score(0.0)
//!     .trees(vec![tree])
//!     .build()
//!     .expect("valid ensemble");
//!
//! assert_eq!(ensemble.n_trees(), 1);
//! assert_eq!(ensemble.n_features(), 1);
//! ```
//!
//! [`build()`]: TreeEnsembleBuilder::build

use std::marker::PhantomData;

use crate::ensemble::{self, TreeEnsemble};
use crate::error::ValidationError;
use crate::tree::{TaskType, TreeNode};

/// Marker type indicating a required builder field has been set.
#[derive(Debug)]
pub struct Configured;

/// Marker type indicating a required builder field has **not** been set.
#[derive(Debug)]
pub struct Unconfigured;

/// A typestate builder for constructing validated [`TreeEnsemble`] instances.
///
/// Three type parameters track whether the required fields have been set:
///
/// - `Task` — whether [`task_type()`] has been called
/// - `Features` — whether [`n_features()`] has been called
/// - `Base` — whether [`base_score()`] has been called
///
/// [`build()`] is only available when all three parameters are [`Configured`].
///
/// [`task_type()`]: TreeEnsembleBuilder::task_type
/// [`n_features()`]: TreeEnsembleBuilder::n_features
/// [`base_score()`]: TreeEnsembleBuilder::base_score
/// [`build()`]: TreeEnsembleBuilder::build
#[derive(Debug)]
pub struct TreeEnsembleBuilder<Task = Unconfigured, Features = Unconfigured, Base = Unconfigured> {
    trees: Vec<Vec<TreeNode>>,
    task_type: Option<TaskType>,
    n_features: Option<usize>,
    base_score: Option<f64>,
    feature_names: Option<Vec<String>>,
    _state: PhantomData<(Task, Features, Base)>,
}

// --- Construction (always starts fully unconfigured) ---

impl TreeEnsembleBuilder<Unconfigured, Unconfigured, Unconfigured> {
    /// Creates a new builder with no fields set and an empty tree list.
    #[must_use]
    pub fn new() -> Self {
        Self {
            trees: Vec::new(),
            task_type: None,
            n_features: None,
            base_score: None,
            feature_names: None,
            _state: PhantomData,
        }
    }
}

impl Default for TreeEnsembleBuilder<Unconfigured, Unconfigured, Unconfigured> {
    fn default() -> Self {
        Self::new()
    }
}

// --- Required field setters (each transitions one type parameter) ---

impl<F, B> TreeEnsembleBuilder<Unconfigured, F, B> {
    /// Sets the learning task type. **Required.**
    #[must_use]
    pub fn task_type(self, task_type: TaskType) -> TreeEnsembleBuilder<Configured, F, B> {
        TreeEnsembleBuilder {
            trees: self.trees,
            task_type: Some(task_type),
            n_features: self.n_features,
            base_score: self.base_score,
            feature_names: self.feature_names,
            _state: PhantomData,
        }
    }
}

impl<T, B> TreeEnsembleBuilder<T, Unconfigured, B> {
    /// Sets the total input feature count. **Required.**
    ///
    /// This must equal the maximum possible feature index + 1, even if some
    /// features are never referenced by any split node.
    #[must_use]
    pub fn n_features(self, n_features: usize) -> TreeEnsembleBuilder<T, Configured, B> {
        TreeEnsembleBuilder {
            trees: self.trees,
            task_type: self.task_type,
            n_features: Some(n_features),
            base_score: self.base_score,
            feature_names: self.feature_names,
            _state: PhantomData,
        }
    }
}

impl<T, F> TreeEnsembleBuilder<T, F, Unconfigured> {
    /// Sets the global bias (base score). **Required.**
    ///
    /// Must be in the same space as leaf values (pre-transform).
    #[must_use]
    pub fn base_score(self, base_score: f64) -> TreeEnsembleBuilder<T, F, Configured> {
        TreeEnsembleBuilder {
            trees: self.trees,
            task_type: self.task_type,
            n_features: self.n_features,
            base_score: Some(base_score),
            feature_names: self.feature_names,
            _state: PhantomData,
        }
    }
}

// --- Optional setters and tree mutators (available in any state) ---

impl<T, F, B> TreeEnsembleBuilder<T, F, B> {
    /// Sets the complete list of trees, replacing any previously added trees.
    #[must_use]
    pub fn trees(mut self, trees: Vec<Vec<TreeNode>>) -> Self {
        self.trees = trees;
        self
    }

    /// Appends a single tree to the ensemble.
    #[must_use]
    pub fn tree(mut self, tree: Vec<TreeNode>) -> Self {
        self.trees.push(tree);
        self
    }

    /// Sets human-readable feature names. **Optional.**
    ///
    /// If provided, the length should equal `n_features`.
    #[must_use]
    pub fn feature_names(mut self, names: Vec<String>) -> Self {
        self.feature_names = Some(names);
        self
    }
}

// --- Build (only available when fully configured) ---

impl TreeEnsembleBuilder<Configured, Configured, Configured> {
    /// Consumes the builder and produces a validated [`TreeEnsemble`].
    ///
    /// Runs [`TreeEnsemble::validate`] on the constructed ensemble. If
    /// validation fails, returns the first error encountered.
    ///
    /// # Errors
    ///
    /// Returns [`ValidationError`] if any structural invariant is violated.
    pub fn build(self) -> Result<TreeEnsemble, ValidationError> {
        let n_trees = self.trees.len();

        // Pre-compute expected leaf values before moving trees into the ensemble.
        let expected_leaf_values: Vec<f64> = self
            .trees
            .iter()
            .map(|t| ensemble::expected_leaf_value(t))
            .collect();

        let ensemble = TreeEnsemble {
            trees: self.trees,
            // SAFETY: these unwraps are unreachable — the typestate guarantees
            // that all three required fields have been set via their respective
            // setter methods before `build()` becomes callable.
            base_score: self.base_score.unwrap(),
            task_type: self.task_type.unwrap(),
            n_features: self.n_features.unwrap(),
            feature_names: self.feature_names,
            n_trees,
            expected_leaf_values,
        };

        ensemble.validate()?;

        Ok(ensemble)
    }
}
