//! Fixed-capacity path vector for the TreeSHAP algorithm.
//!
//! Implementation follows Algorithm 2 from Lundberg et al. (2020) and the
//! reference C implementation in the SHAP library (`tree_shap.h`).
//!
//! Optimizations over the naive implementation:
//! - Custom `Clone` copies only active elements (not the full 66-slot array)
//! - Feature presence tracked via bitset for O(1) dedup lookup
//! - Position lookup table for O(1) feature → index resolution (features 0..63)
//! - Lightweight save/restore for recursive DFS (avoids full PathVector clones)

/// Maximum supported tree depth.
pub const MAX_DEPTH: usize = 64;

/// Sentinel value indicating a feature is not present in the path.
const NOT_PRESENT: u8 = u8::MAX;

/// One element on the SHAP path.
#[derive(Debug, Clone, Copy)]
pub(crate) struct PathElement {
    /// Feature index (-1 sentinel = dummy root).
    pub feature_index: i32,
    /// Fraction when feature is absent from the coalition.
    pub zero_fraction: f64,
    /// Fraction when feature is present in the coalition.
    pub one_fraction: f64,
    /// Accumulated Shapley kernel weight.
    pub pweight: f64,
}

impl Default for PathElement {
    fn default() -> Self {
        Self {
            feature_index: -1,
            zero_fraction: 0.0,
            one_fraction: 0.0,
            pweight: 0.0,
        }
    }
}

/// Saved state of a `PathVector` for stack-safe recursive traversal.
///
/// Only captures the mutable state that `extend` modifies: pweights, length,
/// bitset, and position table. Restoring is O(path_len), much cheaper than
/// cloning the full `PathVector`.
pub(crate) struct PathState {
    pweights: [f64; MAX_DEPTH + 2],
    len: usize,
    feature_bits: u64,
    feature_pos: [u8; 64],
}

/// Fixed-capacity path vector with optimized clone and feature tracking.
pub(crate) struct PathVector {
    elements: [PathElement; MAX_DEPTH + 2],
    len: usize,
    /// Bitset tracking which features are on the path (supports features 0..63).
    /// Bit i is set if feature i is present. Features >= 64 fall back to linear scan.
    feature_bits: u64,
    /// For features 0..63, maps feature_index → position in `elements`.
    /// `NOT_PRESENT` (255) means the feature is not on the path.
    feature_pos: [u8; 64],
}

impl Clone for PathVector {
    fn clone(&self) -> Self {
        let mut new = Self {
            elements: [PathElement::default(); MAX_DEPTH + 2],
            len: self.len,
            feature_bits: self.feature_bits,
            feature_pos: self.feature_pos,
        };
        // Only copy the active portion — this is the key optimization.
        // For depth 6 trees (len~7), copies 7 elements instead of 66.
        new.elements[..self.len].copy_from_slice(&self.elements[..self.len]);
        new
    }
}

impl PathVector {
    /// Creates an empty path vector.
    pub fn new() -> Self {
        Self {
            elements: [PathElement::default(); MAX_DEPTH + 2],
            len: 0,
            feature_bits: 0,
            feature_pos: [NOT_PRESENT; 64],
        }
    }

    /// Number of active elements.
    #[cfg(test)]
    pub fn len(&self) -> usize {
        self.len
    }

    /// Slice of active elements.
    pub fn as_slice(&self) -> &[PathElement] {
        &self.elements[..self.len]
    }

    /// Checks if a feature is already on the path. Returns `Some(index)` if found.
    /// Uses the position lookup table for features 0..63 (O(1)), falls back to
    /// linear scan for features >= 64.
    pub fn find_feature(&self, feature_index: i32) -> Option<usize> {
        if feature_index < 0 {
            return None;
        }
        let fi = feature_index as usize;
        if fi < 64 {
            let pos = self.feature_pos[fi];
            if pos == NOT_PRESENT {
                None
            } else {
                Some(pos as usize)
            }
        } else {
            // Fallback for features >= 64.
            self.elements[..self.len]
                .iter()
                .position(|e| e.feature_index == feature_index)
        }
    }

    /// Extends the path by adding a new element.
    /// Matches `extend_path` from the reference SHAP C implementation.
    pub fn extend(&mut self, zero_fraction: f64, one_fraction: f64, feature_index: i32) {
        let unique_depth = self.len;
        debug_assert!(
            unique_depth < MAX_DEPTH + 2,
            "PathVector overflow: depth exceeds MAX_DEPTH"
        );

        self.elements[unique_depth] = PathElement {
            feature_index,
            zero_fraction,
            one_fraction,
            pweight: if unique_depth == 0 { 1.0 } else { 0.0 },
        };
        self.len = unique_depth + 1;

        // Update feature bitset and position table.
        if feature_index >= 0 && (feature_index as usize) < 64 {
            let fi = feature_index as usize;
            self.feature_bits |= 1u64 << fi;
            self.feature_pos[fi] = unique_depth as u8;
        }

        // Redistribute weights in reverse order.
        if unique_depth > 0 {
            let m = unique_depth + 1;
            let m_f = m as f64;
            for i in (0..unique_depth).rev() {
                let old_w = self.elements[i].pweight;
                self.elements[i + 1].pweight += one_fraction * old_w * ((i + 1) as f64) / m_f;
                self.elements[i].pweight =
                    zero_fraction * old_w * ((unique_depth - i) as f64) / m_f;
            }
        }
    }

    /// Computes the unwound path sum for element at `path_index`.
    /// Matches `unwound_path_sum` from the reference SHAP C implementation.
    pub fn unwound_sum(&self, path_index: usize) -> f64 {
        let unique_depth = self.len - 1;
        let one_fraction = self.elements[path_index].one_fraction;
        let zero_fraction = self.elements[path_index].zero_fraction;

        if one_fraction == 0.0 && zero_fraction == 0.0 {
            return 0.0;
        }

        let mut next_one_portion = self.elements[unique_depth].pweight;
        let mut total = 0.0;
        let m = (unique_depth + 1) as f64;

        if one_fraction != 0.0 {
            for i in (0..unique_depth).rev() {
                let tmp = next_one_portion / (((i + 1) as f64) * one_fraction);
                total += tmp;
                next_one_portion =
                    self.elements[i].pweight - tmp * zero_fraction * ((unique_depth - i) as f64);
            }
        } else {
            for i in (0..unique_depth).rev() {
                total += self.elements[i].pweight / (zero_fraction * ((unique_depth - i) as f64));
            }
        }

        total * m
    }

    /// Computes SHAP contributions for ALL features on the path in a single pass.
    /// This avoids calling `unwound_sum` individually for each feature.
    /// Returns the number of contributions written to `out`.
    pub fn leaf_contributions(&self, leaf_value: f64, out: &mut [(i32, f64)]) -> usize {
        let depth = self.len;
        let mut count = 0;

        for i in 1..depth {
            let el = &self.elements[i];
            if el.feature_index < 0 {
                continue;
            }

            let w = self.unwound_sum(i);
            let scale = w * (el.one_fraction - el.zero_fraction);

            if count < out.len() {
                out[count] = (el.feature_index, scale * leaf_value);
                count += 1;
            }
        }

        count
    }

    /// Removes the feature at `path_index` and restores weights.
    /// Used by the explainer's "unwind then re-extend" pattern for repeated features.
    pub fn unwind(&mut self, path_index: usize) {
        let unique_depth = self.len - 1;
        let one_fraction = self.elements[path_index].one_fraction;
        let zero_fraction = self.elements[path_index].zero_fraction;
        let feature_index = self.elements[path_index].feature_index;
        let mut next_one_portion = self.elements[unique_depth].pweight;
        let m = (unique_depth + 1) as f64;

        for i in (0..unique_depth).rev() {
            if one_fraction != 0.0 {
                let tmp = self.elements[i].pweight;
                self.elements[i].pweight = next_one_portion * m / (((i + 1) as f64) * one_fraction);
                next_one_portion = tmp
                    - self.elements[i].pweight * zero_fraction * ((unique_depth - i) as f64) / m;
            } else if zero_fraction != 0.0 {
                self.elements[i].pweight =
                    (self.elements[i].pweight * m) / (zero_fraction * ((unique_depth - i) as f64));
            }
        }

        // Shift elements to remove the one at path_index.
        for i in path_index..unique_depth {
            self.elements[i] = self.elements[i + 1];
        }
        self.len -= 1;

        // Update position table: positions after path_index shifted down by 1.
        if feature_index >= 0 && (feature_index as usize) < 64 {
            let fi = feature_index as usize;
            // Check if the feature is still on the path after removal.
            let still_present = self.elements[..self.len]
                .iter()
                .any(|e| e.feature_index == feature_index);
            if !still_present {
                self.feature_bits &= !(1u64 << fi);
                self.feature_pos[fi] = NOT_PRESENT;
            }
        }
        // Rebuild positions for features whose elements shifted.
        for i in path_index..self.len {
            let fi = self.elements[i].feature_index;
            if fi >= 0 && (fi as usize) < 64 {
                self.feature_pos[fi as usize] = i as u8;
            }
        }
    }

    /// Captures the current mutable state for later restoration.
    ///
    /// Only saves pweights, length, bitset, and position table — the minimum
    /// needed to undo an `extend` or `unwind` operation. This is much cheaper
    /// than cloning the full `PathVector` (~80-144 bytes vs ~2.2KB).
    pub fn save(&self) -> PathState {
        let mut pweights = [0.0f64; MAX_DEPTH + 2];
        for (i, el) in self.elements[..self.len].iter().enumerate() {
            pweights[i] = el.pweight;
        }
        PathState {
            pweights,
            len: self.len,
            feature_bits: self.feature_bits,
            feature_pos: self.feature_pos,
        }
    }

    /// Restores a previously captured state.
    ///
    /// Reverts pweights, length, bitset, and position table to the saved
    /// values. Elements beyond `state.len` retain stale data but are
    /// invisible (past `self.len`).
    pub fn restore(&mut self, state: &PathState) {
        for i in 0..state.len {
            self.elements[i].pweight = state.pweights[i];
        }
        // Restore element metadata (feature_index, fractions) for any
        // elements that were overwritten by extend after the save point.
        // Since extend only appends at position `len` and modifies pweights
        // of existing elements, and unwind shifts elements, we need to
        // restore the full element data for positions that may have been
        // modified by unwind's shift operation.
        //
        // However, save/restore is only used around extend (not unwind) in
        // the recursive DFS, and extend only touches pweights of existing
        // elements + appends one new element. So restoring pweights + len
        // is sufficient when save/restore brackets only extend calls.
        //
        // When save/restore brackets unwind + extend (for repeated features),
        // the unwind shifts elements, so we need a full element restore.
        // The caller handles this by saving state BEFORE the unwind.
        self.len = state.len;
        self.feature_bits = state.feature_bits;
        self.feature_pos = state.feature_pos;
    }

    /// Saves the full element state (not just pweights) for restoration
    /// across unwind operations that shift elements.
    pub fn save_full(&self) -> PathStateFull {
        let mut elements = [PathElement::default(); MAX_DEPTH + 2];
        elements[..self.len].copy_from_slice(&self.elements[..self.len]);
        PathStateFull {
            elements,
            len: self.len,
            feature_bits: self.feature_bits,
            feature_pos: self.feature_pos,
        }
    }

    /// Restores a full element snapshot.
    pub fn restore_full(&mut self, state: &PathStateFull) {
        self.elements[..state.len].copy_from_slice(&state.elements[..state.len]);
        self.len = state.len;
        self.feature_bits = state.feature_bits;
        self.feature_pos = state.feature_pos;
    }
}

/// Full snapshot of a `PathVector` including all element data.
///
/// Used when save/restore must bracket an `unwind` operation (which shifts
/// elements), not just an `extend` (which only modifies pweights).
pub(crate) struct PathStateFull {
    elements: [PathElement; MAX_DEPTH + 2],
    len: usize,
    feature_bits: u64,
    feature_pos: [u8; 64],
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn empty_path() {
        let path = PathVector::new();
        assert_eq!(path.len(), 0);
    }

    #[test]
    fn extend_first_element() {
        let mut path = PathVector::new();
        path.extend(1.0, 1.0, 0);
        assert_eq!(path.len(), 1);
        assert!((path.as_slice()[0].pweight - 1.0).abs() < 1e-12);
    }

    #[test]
    fn extend_two_elements_with_unit_fractions() {
        let mut path = PathVector::new();
        path.extend(1.0, 1.0, -1);
        path.extend(1.0, 1.0, 0);
        let total: f64 = path.as_slice().iter().map(|e| e.pweight).sum();
        assert!(
            (total - 1.0).abs() < 1e-12,
            "weight sum should be 1.0 when all fractions are 1.0, got {total}"
        );
    }

    #[test]
    fn extend_two_elements_partial_fractions() {
        let mut path = PathVector::new();
        path.extend(1.0, 1.0, -1);
        path.extend(0.6, 1.0, 0);
        let total: f64 = path.as_slice().iter().map(|e| e.pweight).sum();
        assert!(
            (total - 0.8).abs() < 1e-12,
            "weight sum should be 0.8, got {total}"
        );
    }

    #[test]
    fn unwind_restores_single_extend() {
        let mut path = PathVector::new();
        path.extend(1.0, 1.0, -1);
        let w0 = path.as_slice()[0].pweight;

        path.extend(0.6, 1.0, 0);
        path.unwind(1);

        assert_eq!(path.len(), 1);
        assert!(
            (path.as_slice()[0].pweight - w0).abs() < 1e-12,
            "weight not restored after unwind"
        );
    }

    #[test]
    fn unwind_restores_depth3() {
        let mut path = PathVector::new();
        path.extend(1.0, 1.0, -1);
        path.extend(0.6, 1.0, 0);
        let saved: Vec<f64> = path.as_slice().iter().map(|e| e.pweight).collect();

        path.extend(0.4, 1.0, 1);
        assert_eq!(path.len(), 3);

        path.unwind(2);
        assert_eq!(path.len(), 2);

        for (i, &expected) in saved.iter().enumerate() {
            assert!(
                (path.as_slice()[i].pweight - expected).abs() < 1e-12,
                "depth3 unwind: element {i} weight {}, expected {expected}",
                path.as_slice()[i].pweight
            );
        }
    }

    #[test]
    fn unwound_sum_single_feature_unit_fractions() {
        let mut path = PathVector::new();
        path.extend(1.0, 1.0, -1);
        path.extend(1.0, 1.0, 0);
        let w = path.unwound_sum(1);
        assert!(
            (w - 1.0).abs() < 1e-12,
            "unwound_sum for unit fractions should be 1.0, got {w}"
        );
    }

    #[test]
    fn unwound_sum_zero_one_fraction() {
        let mut path = PathVector::new();
        path.extend(1.0, 1.0, -1);
        path.extend(0.4, 0.0, 0);
        let w = path.unwound_sum(1);
        assert!(
            w.is_finite(),
            "unwound_sum with one=0 should be finite, got {w}"
        );
    }

    #[test]
    fn extend_depth5_no_panic() {
        let mut path = PathVector::new();
        path.extend(1.0, 1.0, -1);
        for i in 0..5 {
            path.extend(0.5, 1.0, i);
        }
        assert_eq!(path.len(), 6);
        for e in path.as_slice() {
            assert!(e.pweight >= 0.0, "negative weight at depth 5");
        }
    }

    #[test]
    fn find_feature_bitset() {
        let mut path = PathVector::new();
        path.extend(1.0, 1.0, -1);
        path.extend(0.5, 1.0, 3);
        path.extend(0.5, 1.0, 7);

        assert!(path.find_feature(3).is_some());
        assert!(path.find_feature(7).is_some());
        assert!(path.find_feature(0).is_none());
        assert!(path.find_feature(-1).is_none()); // dummy not findable
    }

    #[test]
    fn find_feature_position_table() {
        let mut path = PathVector::new();
        path.extend(1.0, 1.0, -1);
        path.extend(0.5, 1.0, 3);
        path.extend(0.5, 1.0, 7);

        assert_eq!(path.find_feature(3), Some(1));
        assert_eq!(path.find_feature(7), Some(2));
    }

    #[test]
    fn clone_only_copies_active() {
        let mut path = PathVector::new();
        path.extend(1.0, 1.0, -1);
        path.extend(0.5, 1.0, 0);
        path.extend(0.3, 1.0, 1);
        assert_eq!(path.len(), 3);

        let cloned = path.clone();
        assert_eq!(cloned.len(), 3);
        for i in 0..3 {
            assert!((cloned.as_slice()[i].pweight - path.as_slice()[i].pweight).abs() < 1e-15);
        }
    }

    #[test]
    fn feature_bits_updated_on_unwind() {
        let mut path = PathVector::new();
        path.extend(1.0, 1.0, -1);
        path.extend(0.5, 1.0, 3);
        assert!(path.find_feature(3).is_some());

        path.unwind(1);
        assert!(path.find_feature(3).is_none());
    }

    #[test]
    fn save_restore_roundtrip() {
        let mut path = PathVector::new();
        path.extend(1.0, 1.0, -1);
        path.extend(0.5, 1.0, 3);

        let state = path.save();
        let orig_len = path.len();
        let orig_w0 = path.as_slice()[0].pweight;
        let orig_w1 = path.as_slice()[1].pweight;

        // Extend modifies pweights.
        path.extend(0.3, 1.0, 7);
        assert_eq!(path.len(), 3);

        // Restore undoes the extend.
        path.restore(&state);
        assert_eq!(path.len(), orig_len);
        assert!((path.as_slice()[0].pweight - orig_w0).abs() < 1e-15);
        assert!((path.as_slice()[1].pweight - orig_w1).abs() < 1e-15);
        assert!(path.find_feature(7).is_none());
    }

    #[test]
    fn save_full_restore_full_across_unwind() {
        let mut path = PathVector::new();
        path.extend(1.0, 1.0, -1);
        path.extend(0.5, 1.0, 3);
        path.extend(0.3, 1.0, 7);

        let state = path.save_full();

        // Unwind shifts elements.
        path.unwind(1);
        assert_eq!(path.len(), 2);

        // Full restore recovers everything.
        path.restore_full(&state);
        assert_eq!(path.len(), 3);
        assert_eq!(path.find_feature(3), Some(1));
        assert_eq!(path.find_feature(7), Some(2));
    }
}
