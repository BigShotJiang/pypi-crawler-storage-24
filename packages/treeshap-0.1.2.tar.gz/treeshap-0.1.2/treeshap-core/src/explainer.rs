//! TreeSHAP explainer — computes exact SHAP values for tree ensemble models.
//!
//! The core algorithm is tree-path-dependent SHAP (Lundberg et al., 2020),
//! which exploits the additive structure of decision trees to compute exact
//! Shapley values in polynomial time.

use ndarray::{Array1, Array2, ArrayView1, ArrayView2};
use rayon::prelude::*;

use crate::ensemble::TreeEnsemble;
use crate::path::{PathVector, MAX_DEPTH};
use crate::tree::{MissingDirection, TaskType, TreeNode};

/// SHAP computation mode.
#[derive(Debug, Clone)]
pub enum ShapMode {
    /// Tree-path-dependent mode (default). Uses training sample counts
    /// embedded in the tree structure. No background data required.
    TreePathDependent,
    /// Interventional mode. Uses an empirical background dataset to
    /// compute feature absence fractions.
    Interventional {
        /// Background dataset of shape `(n_samples, n_features)`.
        background: Array2<f64>,
        /// Maximum number of background samples to use (default: 100).
        max_background_samples: usize,
        /// Optional RNG seed for reproducible background subsampling.
        seed: Option<u64>,
    },
}

/// Holds the result of a SHAP computation.
#[derive(Debug, Clone, PartialEq)]
#[non_exhaustive]
pub enum ShapOutput {
    /// 2D output for regression / binary classification:
    /// shape `(n_samples, n_features)`.
    Flat(Array2<f64>),
    /// 3D output for multiclass: stored as 2D with shape
    /// `(n_samples, n_features * n_classes)`, reshaped by the consumer.
    Multiclass {
        /// SHAP values of shape `(n_samples, n_features * n_classes)`.
        values: Array2<f64>,
        /// Number of classes.
        n_classes: usize,
    },
}

/// Base value representation.
#[derive(Debug, Clone, PartialEq)]
#[non_exhaustive]
pub enum BaseValue {
    /// Scalar base value for regression / binary classification.
    Scalar(f64),
    /// Per-class base values for multiclass.
    Vector(Vec<f64>),
}

/// The TreeSHAP explainer. Holds a reference to a validated ensemble and
/// the computation mode.
pub struct Explainer<'a> {
    ensemble: &'a TreeEnsemble,
    mode: ShapMode,
}

/// Threshold: if n_samples is at most n_trees / TREE_PAR_RATIO, parallelize
/// over trees instead of samples. This helps single-sample or few-sample
/// workloads utilize all cores.
const TREE_PAR_RATIO: usize = 4;

impl<'a> Explainer<'a> {
    /// Creates a new explainer in tree-path-dependent mode (default).
    #[must_use]
    pub fn new(ensemble: &'a TreeEnsemble) -> Self {
        Self {
            ensemble,
            mode: ShapMode::TreePathDependent,
        }
    }

    /// Creates a new explainer with the specified mode.
    #[must_use]
    pub fn with_mode(ensemble: &'a TreeEnsemble, mode: ShapMode) -> Self {
        Self { ensemble, mode }
    }

    /// Computes SHAP values and returns a full
    /// [`ShapExplanation`](crate::explanation::ShapExplanation).
    ///
    /// `x` has shape `(n_samples, n_features)`. Each row is one sample.
    /// Optionally attach feature names for visualization.
    pub fn explain(&self, x: ArrayView2<f64>) -> crate::explanation::ShapExplanation {
        let (shap_values, base_value) = self.shap_values(x);
        let predictions = self.predict(x);

        crate::explanation::ShapExplanation {
            n_samples: x.nrows(),
            n_features: self.ensemble.n_features,
            shap_values,
            base_value,
            feature_values: Some(x.to_owned()),
            feature_names: self.ensemble.feature_names.clone(),
            predictions,
        }
    }

    /// Computes SHAP values for all samples in `x`.
    ///
    /// `x` has shape `(n_samples, n_features)`. Each row is one sample.
    ///
    /// Returns `(ShapOutput, BaseValue)`.
    pub fn shap_values(&self, x: ArrayView2<f64>) -> (ShapOutput, BaseValue) {
        match &self.ensemble.task_type {
            TaskType::MulticlassClassification { n_classes } => {
                self.shap_values_multiclass(x, *n_classes)
            }
            _ => self.shap_values_flat(x),
        }
    }

    /// Computes flat SHAP values for regression / binary classification.
    fn shap_values_flat(&self, x: ArrayView2<f64>) -> (ShapOutput, BaseValue) {
        let n_samples = x.nrows();
        let n_features = self.ensemble.n_features;
        let trees = &self.ensemble.trees;

        let flat = if n_samples <= trees.len().max(1) / TREE_PAR_RATIO {
            // Few samples, many trees: parallelize over trees per sample.
            self.compute_shap_tree_parallel(x, n_samples, n_features, trees)
        } else {
            // Many samples: parallelize over samples.
            self.compute_shap_sample_parallel(x, n_samples, n_features, trees)
        };

        let result = Array2::from_shape_vec((n_samples, n_features), flat)
            .expect("flat SHAP vector length matches (n_samples, n_features)");

        let expected_leaf_sum: f64 = self.ensemble.expected_leaf_values.iter().sum();
        let base_value = self.ensemble.base_score + expected_leaf_sum;

        (ShapOutput::Flat(result), BaseValue::Scalar(base_value))
    }

    /// Sample-parallel SHAP computation: outer loop over samples, sequential over trees.
    fn compute_shap_sample_parallel(
        &self,
        x: ArrayView2<f64>,
        n_samples: usize,
        n_features: usize,
        trees: &[Vec<TreeNode>],
    ) -> Vec<f64> {
        let all_shap: Vec<Vec<f64>> = (0..n_samples)
            .into_par_iter()
            .map(|s| {
                let sample = x.row(s);
                let mut shap = vec![0.0_f64; n_features];
                for tree in trees {
                    self.tree_shap(tree, sample, &mut shap);
                }
                shap
            })
            .collect();

        all_shap.into_iter().flatten().collect()
    }

    /// Tree-parallel SHAP computation: for each sample, parallelize over trees
    /// and reduce. Better utilizes cores when n_samples is small.
    fn compute_shap_tree_parallel(
        &self,
        x: ArrayView2<f64>,
        n_samples: usize,
        n_features: usize,
        trees: &[Vec<TreeNode>],
    ) -> Vec<f64> {
        let mut flat = Vec::with_capacity(n_samples * n_features);
        for s in 0..n_samples {
            let sample = x.row(s);
            let shap = trees
                .par_iter()
                .fold(
                    || vec![0.0_f64; n_features],
                    |mut acc, tree| {
                        self.tree_shap(tree, sample, &mut acc);
                        acc
                    },
                )
                .reduce(
                    || vec![0.0_f64; n_features],
                    |mut a, b| {
                        for (ai, &bi) in a.iter_mut().zip(b.iter()) {
                            *ai += bi;
                        }
                        a
                    },
                );
            flat.extend_from_slice(&shap);
        }
        flat
    }

    /// Computes SHAP values for multiclass models.
    fn shap_values_multiclass(
        &self,
        x: ArrayView2<f64>,
        n_classes: usize,
    ) -> (ShapOutput, BaseValue) {
        let n_samples = x.nrows();
        let n_features = self.ensemble.n_features;
        let trees = &self.ensemble.trees;
        let cols = n_features * n_classes;

        // For multiclass, trees cycle through classes:
        // tree 0 → class 0, tree 1 → class 1, ..., tree C-1 → class C-1,
        // tree C → class 0, etc.
        let all_shap: Vec<Vec<f64>> = (0..n_samples)
            .into_par_iter()
            .map(|s| {
                let sample = x.row(s);
                let mut shap = vec![0.0_f64; cols];
                // Reusable per-tree buffer (hoisted out of tree loop).
                let mut tree_shap_buf = vec![0.0_f64; n_features];

                for (tree_idx, tree) in trees.iter().enumerate() {
                    let class_idx = tree_idx % n_classes;
                    let offset = class_idx * n_features;

                    tree_shap_buf.iter_mut().for_each(|v| *v = 0.0);
                    self.tree_shap(tree, sample, &mut tree_shap_buf);

                    for (f, &v) in tree_shap_buf.iter().enumerate() {
                        shap[offset + f] += v;
                    }
                }

                shap
            })
            .collect();

        let flat: Vec<f64> = all_shap.into_iter().flatten().collect();
        let result = Array2::from_shape_vec((n_samples, cols), flat)
            .expect("multiclass SHAP vector length matches (n_samples, n_features * n_classes)");

        // Compute per-class base values using pre-computed expected leaf values.
        let mut base_values = vec![self.ensemble.base_score; n_classes];
        for (tree_idx, elv) in self.ensemble.expected_leaf_values.iter().enumerate() {
            base_values[tree_idx % n_classes] += elv;
        }

        (
            ShapOutput::Multiclass {
                values: result,
                n_classes,
            },
            BaseValue::Vector(base_values),
        )
    }

    /// Computes per-tree SHAP contributions for one sample and accumulates
    /// into the `shap_values` vector.
    ///
    /// This is the core tree-path-dependent TreeSHAP algorithm.
    fn tree_shap(&self, tree: &[TreeNode], sample: ArrayView1<f64>, shap_values: &mut [f64]) {
        if tree.is_empty() {
            return;
        }

        match &self.mode {
            ShapMode::TreePathDependent => {
                self.tree_shap_path_dependent(tree, sample, shap_values);
            }
            ShapMode::Interventional {
                background,
                max_background_samples,
                ..
            } => {
                self.tree_shap_interventional(
                    tree,
                    sample,
                    shap_values,
                    background.view(),
                    *max_background_samples,
                );
            }
        }
    }

    /// Tree-path-dependent SHAP for a single tree using recursive DFS.
    ///
    /// Passes `&mut PathVector` through the recursion and uses save/restore
    /// to undo extend operations on return. Eliminates all PathVector heap
    /// clones from the hot path.
    fn tree_shap_path_dependent(
        &self,
        tree: &[TreeNode],
        sample: ArrayView1<f64>,
        shap_values: &mut [f64],
    ) {
        let mut path = PathVector::new();
        path.extend(1.0, 1.0, -1);
        recurse_path_dependent(tree, 0, sample, shap_values, &mut path);
    }

    /// Interventional SHAP for a single tree using background data.
    fn tree_shap_interventional(
        &self,
        tree: &[TreeNode],
        sample: ArrayView1<f64>,
        shap_values: &mut [f64],
        background: ArrayView2<f64>,
        max_bg: usize,
    ) {
        let n_bg = background.nrows().min(max_bg);
        if n_bg == 0 {
            return;
        }

        let weight = 1.0 / n_bg as f64;
        for bg_idx in 0..n_bg {
            let bg_sample = background.row(bg_idx);
            self.tree_shap_interventional_single(tree, sample, bg_sample, shap_values, weight);
        }
    }

    /// Interventional SHAP contribution from one (foreground, background) pair.
    /// Uses recursive DFS to avoid PathVector cloning.
    fn tree_shap_interventional_single(
        &self,
        tree: &[TreeNode],
        sample: ArrayView1<f64>,
        bg_sample: ArrayView1<f64>,
        shap_values: &mut [f64],
        weight: f64,
    ) {
        let mut path = PathVector::new();
        path.extend(1.0, 1.0, -1);
        recurse_interventional(tree, 0, sample, bg_sample, shap_values, weight, &mut path);
    }

    /// Computes the model's raw prediction for a single sample.
    ///
    /// This is the sum of all leaf values the sample reaches plus base_score.
    pub fn predict_single(&self, sample: ArrayView1<f64>) -> f64 {
        let mut pred = self.ensemble.base_score;
        for tree in &self.ensemble.trees {
            pred += self.tree_predict(tree, sample);
        }
        pred
    }

    /// Predicts a batch of samples. Returns an `Array1<f64>`.
    pub fn predict(&self, x: ArrayView2<f64>) -> Array1<f64> {
        let preds: Vec<f64> = (0..x.nrows())
            .into_par_iter()
            .map(|i| self.predict_single(x.row(i)))
            .collect();
        Array1::from(preds)
    }

    /// Traces a sample through a single tree and returns the leaf value.
    fn tree_predict(&self, tree: &[TreeNode], sample: ArrayView1<f64>) -> f64 {
        if tree.is_empty() {
            return 0.0;
        }

        let mut node_idx = 0;
        loop {
            match &tree[node_idx] {
                TreeNode::Leaf { value, .. } => return *value,
                TreeNode::Internal {
                    feature_index,
                    threshold,
                    left_child,
                    right_child,
                    missing_direction,
                    ..
                } => {
                    let val = sample[*feature_index];
                    node_idx = if val.is_nan() {
                        match missing_direction {
                            MissingDirection::Left => *left_child,
                            MissingDirection::Right | MissingDirection::None => *right_child,
                        }
                    } else if val <= *threshold {
                        *left_child
                    } else {
                        *right_child
                    };
                }
            }
        }
    }
}

/// Recursive DFS for tree-path-dependent SHAP.
///
/// Extends `path` on descent and restores via save/restore on return,
/// eliminating all `PathVector` clones from the hot path.
fn recurse_path_dependent(
    tree: &[TreeNode],
    node_idx: usize,
    sample: ArrayView1<f64>,
    shap_values: &mut [f64],
    path: &mut PathVector,
) {
    let node = &tree[node_idx];

    match node {
        TreeNode::Leaf { value, .. } => {
            let mut contribs = [(0i32, 0.0f64); MAX_DEPTH + 2];
            let n = path.leaf_contributions(*value, &mut contribs);
            for &(feat, contrib) in &contribs[..n] {
                let f = feat as usize;
                if f < shap_values.len() {
                    shap_values[f] += contrib;
                }
            }
        }
        TreeNode::Internal {
            feature_index,
            threshold,
            left_child,
            right_child,
            missing_direction,
            cover,
            ..
        } => {
            let left_node = &tree[*left_child];
            let right_node = &tree[*right_child];
            let left_cover = left_node.cover();
            let right_cover = right_node.cover();
            let parent_cover = *cover;

            if parent_cover == 0.0 {
                return;
            }

            let feat_val = sample[*feature_index];
            let go_left = if feat_val.is_nan() {
                matches!(missing_direction, MissingDirection::Left)
            } else {
                feat_val <= *threshold
            };

            let (hot_child, cold_child, hot_cover, cold_cover) = if go_left {
                (*left_child, *right_child, left_cover, right_cover)
            } else {
                (*right_child, *left_child, right_cover, left_cover)
            };

            let hot_zero_fraction = hot_cover / parent_cover;
            let cold_zero_fraction = cold_cover / parent_cover;
            let feat_i32 = *feature_index as i32;

            // Handle repeated features: unwind previous occurrence.
            let mut incoming_zero = 1.0_f64;
            let mut incoming_one = 1.0_f64;

            let existing_idx = path.find_feature(feat_i32);

            // Save full state before any mutation. Required because unwind
            // shifts elements (not just pweights).
            let full_state = path.save_full();

            if let Some(idx) = existing_idx {
                incoming_zero = path.as_slice()[idx].zero_fraction;
                incoming_one = path.as_slice()[idx].one_fraction;
                path.unwind(idx);
            }

            // Save pweight-only state after unwind, before extend.
            let post_unwind = path.save();

            // Hot child.
            path.extend(hot_zero_fraction * incoming_zero, incoming_one, feat_i32);
            recurse_path_dependent(tree, hot_child, sample, shap_values, path);

            // Restore to post-unwind state.
            path.restore(&post_unwind);

            // Cold child.
            path.extend(cold_zero_fraction * incoming_zero, 0.0, feat_i32);
            recurse_path_dependent(tree, cold_child, sample, shap_values, path);

            // Restore to original state (before unwind).
            path.restore_full(&full_state);
        }
    }
}

/// Recursive DFS for interventional SHAP.
#[allow(clippy::too_many_arguments)]
fn recurse_interventional(
    tree: &[TreeNode],
    node_idx: usize,
    sample: ArrayView1<f64>,
    bg_sample: ArrayView1<f64>,
    shap_values: &mut [f64],
    weight: f64,
    path: &mut PathVector,
) {
    let node = &tree[node_idx];

    match node {
        TreeNode::Leaf { value, .. } => {
            let mut contribs = [(0i32, 0.0f64); MAX_DEPTH + 2];
            let n = path.leaf_contributions(*value, &mut contribs);
            for &(feat, contrib) in &contribs[..n] {
                let f = feat as usize;
                if f < shap_values.len() {
                    shap_values[f] += contrib * weight;
                }
            }
        }
        TreeNode::Internal {
            feature_index,
            threshold,
            left_child,
            right_child,
            missing_direction,
            ..
        } => {
            let fg_val = sample[*feature_index];
            let fg_left = if fg_val.is_nan() {
                matches!(missing_direction, MissingDirection::Left)
            } else {
                fg_val <= *threshold
            };

            let bg_val = bg_sample[*feature_index];
            let bg_left = if bg_val.is_nan() {
                matches!(missing_direction, MissingDirection::Left)
            } else {
                bg_val <= *threshold
            };

            let (hot_child, cold_child) = if fg_left {
                (*left_child, *right_child)
            } else {
                (*right_child, *left_child)
            };

            let bg_goes_hot = fg_left == bg_left;
            let hot_one = 1.0;
            let hot_zero = if bg_goes_hot { 1.0 } else { 0.0 };
            let cold_one = 0.0;
            let cold_zero = if !bg_goes_hot { 1.0 } else { 0.0 };

            // Save state before extending.
            let state = path.save();

            // Hot path.
            path.extend(hot_zero, hot_one, *feature_index as i32);
            recurse_interventional(
                tree,
                hot_child,
                sample,
                bg_sample,
                shap_values,
                weight,
                path,
            );

            // Restore and do cold path (only if it contributes).
            if cold_zero != 0.0 || cold_one != 0.0 {
                path.restore(&state);
                path.extend(cold_zero, cold_one, *feature_index as i32);
                recurse_interventional(
                    tree,
                    cold_child,
                    sample,
                    bg_sample,
                    shap_values,
                    weight,
                    path,
                );
            }

            // Restore to original state.
            path.restore(&state);
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{MissingDirection, TaskType, TreeEnsembleBuilder, TreeNode};
    use ndarray::array;

    /// Helper: builds a simple regression ensemble with one 3-node tree.
    /// Tree: feature 0, threshold 0.5, left leaf = 1.0, right leaf = -1.0.
    /// Covers: root=100, left=60, right=40.
    fn simple_ensemble() -> TreeEnsemble {
        let tree = vec![
            TreeNode::Internal {
                feature_index: 0,
                threshold: 0.5,
                left_child: 1,
                right_child: 2,
                missing_direction: MissingDirection::Left,
                cover: 100.0,
            },
            TreeNode::Leaf {
                value: 1.0,
                cover: 60.0,
            },
            TreeNode::Leaf {
                value: -1.0,
                cover: 40.0,
            },
        ];
        TreeEnsembleBuilder::new()
            .task_type(TaskType::Regression)
            .n_features(1)
            .base_score(0.5)
            .trees(vec![tree])
            .build()
            .unwrap()
    }

    /// Helper: builds a 2-feature ensemble with one depth-2 tree.
    ///
    /// ```text
    ///         [f0 <= 0.5]
    ///         /          \
    ///    [f1 <= 1.0]    leaf(-1.0)
    ///    /         \
    ///  leaf(2.0)  leaf(0.5)
    /// ```
    fn two_feature_ensemble() -> TreeEnsemble {
        let tree = vec![
            TreeNode::Internal {
                feature_index: 0,
                threshold: 0.5,
                left_child: 1,
                right_child: 4,
                missing_direction: MissingDirection::Left,
                cover: 100.0,
            },
            TreeNode::Internal {
                feature_index: 1,
                threshold: 1.0,
                left_child: 2,
                right_child: 3,
                missing_direction: MissingDirection::Left,
                cover: 60.0,
            },
            TreeNode::Leaf {
                value: 2.0,
                cover: 40.0,
            },
            TreeNode::Leaf {
                value: 0.5,
                cover: 20.0,
            },
            TreeNode::Leaf {
                value: -1.0,
                cover: 40.0,
            },
        ];
        TreeEnsembleBuilder::new()
            .task_type(TaskType::Regression)
            .n_features(2)
            .base_score(0.0)
            .trees(vec![tree])
            .build()
            .unwrap()
    }

    #[test]
    fn predict_single_left_leaf() {
        let ens = simple_ensemble();
        let explainer = Explainer::new(&ens);
        let sample = array![0.3]; // 0.3 <= 0.5, go left, leaf = 1.0
        let pred = explainer.predict_single(sample.view());
        assert!(
            (pred - 1.5).abs() < 1e-12,
            "expected 0.5 + 1.0 = 1.5, got {pred}"
        );
    }

    #[test]
    fn predict_single_right_leaf() {
        let ens = simple_ensemble();
        let explainer = Explainer::new(&ens);
        let sample = array![0.7]; // 0.7 > 0.5, go right, leaf = -1.0
        let pred = explainer.predict_single(sample.view());
        assert!(
            (pred - (-0.5)).abs() < 1e-12,
            "expected 0.5 + (-1.0) = -0.5, got {pred}"
        );
    }

    #[test]
    fn predict_nan_routes_via_missing_direction() {
        let ens = simple_ensemble();
        let explainer = Explainer::new(&ens);
        let sample = array![f64::NAN]; // missing → Left → leaf 1.0
        let pred = explainer.predict_single(sample.view());
        assert!(
            (pred - 1.5).abs() < 1e-12,
            "NaN should route left, got pred={pred}"
        );
    }

    #[test]
    fn shap_local_accuracy_simple_left() {
        let ens = simple_ensemble();
        let explainer = Explainer::new(&ens);
        let x = array![[0.3]]; // goes left → prediction = 1.5
        let (output, base) = explainer.shap_values(x.view());

        let shap = match &output {
            ShapOutput::Flat(arr) => arr,
            _ => panic!("expected Flat output"),
        };
        let base_val = match base {
            BaseValue::Scalar(v) => v,
            _ => panic!("expected Scalar"),
        };

        let prediction = explainer.predict_single(x.row(0));
        let shap_sum: f64 = shap.row(0).iter().sum();
        let reconstructed = base_val + shap_sum;

        assert!(
            (prediction - reconstructed).abs() < 1e-9,
            "local accuracy violated: prediction={prediction}, \
             base={base_val} + sum(shap)={shap_sum} = {reconstructed}"
        );
    }

    #[test]
    fn shap_local_accuracy_simple_right() {
        let ens = simple_ensemble();
        let explainer = Explainer::new(&ens);
        let x = array![[0.7]]; // goes right → prediction = -0.5
        let (output, base) = explainer.shap_values(x.view());

        let shap = match &output {
            ShapOutput::Flat(arr) => arr,
            _ => panic!("expected Flat"),
        };
        let base_val = match base {
            BaseValue::Scalar(v) => v,
            _ => panic!("expected Scalar"),
        };

        let prediction = explainer.predict_single(x.row(0));
        let shap_sum: f64 = shap.row(0).iter().sum();
        let reconstructed = base_val + shap_sum;

        assert!(
            (prediction - reconstructed).abs() < 1e-9,
            "local accuracy violated: pred={prediction}, recon={reconstructed}"
        );
    }

    #[test]
    fn shap_local_accuracy_two_features() {
        let ens = two_feature_ensemble();
        let explainer = Explainer::new(&ens);

        // Sample goes left at root (f0=0.2 <= 0.5), left at child (f1=0.5 <= 1.0)
        // → leaf value = 2.0, base = 0.0, prediction = 2.0
        let x = array![[0.2, 0.5]];
        let (output, base) = explainer.shap_values(x.view());

        let shap = match &output {
            ShapOutput::Flat(arr) => arr,
            _ => panic!("expected Flat"),
        };
        let base_val = match base {
            BaseValue::Scalar(v) => v,
            _ => panic!("expected Scalar"),
        };

        let prediction = explainer.predict_single(x.row(0));
        let shap_sum: f64 = shap.row(0).iter().sum();
        let reconstructed = base_val + shap_sum;

        assert!(
            (prediction - reconstructed).abs() < 1e-9,
            "local accuracy violated: pred={prediction}, base={base_val}, \
             shap={:?}, sum={shap_sum}, recon={reconstructed}",
            shap.row(0)
        );
    }

    #[test]
    fn shap_local_accuracy_two_features_right_path() {
        let ens = two_feature_ensemble();
        let explainer = Explainer::new(&ens);

        // f0=1.0 > 0.5 → right → leaf -1.0, prediction = -1.0
        let x = array![[1.0, 0.5]];
        let prediction = explainer.predict_single(x.row(0));
        assert!((prediction - (-1.0)).abs() < 1e-12);

        let (output, base) = explainer.shap_values(x.view());
        let shap = match &output {
            ShapOutput::Flat(arr) => arr,
            _ => panic!("expected Flat"),
        };
        let base_val = match base {
            BaseValue::Scalar(v) => v,
            _ => panic!("expected Scalar"),
        };

        let shap_sum: f64 = shap.row(0).iter().sum();
        let reconstructed = base_val + shap_sum;

        assert!(
            (prediction - reconstructed).abs() < 1e-9,
            "local accuracy violated: pred={prediction}, recon={reconstructed}, \
             shap={:?}",
            shap.row(0)
        );
    }

    #[test]
    fn shap_batch_multiple_samples() {
        let ens = simple_ensemble();
        let explainer = Explainer::new(&ens);
        let x = array![[0.3], [0.7], [0.5]]; // left, right, boundary (<=)

        let (output, base) = explainer.shap_values(x.view());
        let shap = match &output {
            ShapOutput::Flat(arr) => arr,
            _ => panic!("expected Flat"),
        };
        let base_val = match base {
            BaseValue::Scalar(v) => v,
            _ => panic!("expected Scalar"),
        };

        // Verify local accuracy for each sample.
        for s in 0..3 {
            let prediction = explainer.predict_single(x.row(s));
            let shap_sum: f64 = shap.row(s).iter().sum();
            let reconstructed = base_val + shap_sum;
            assert!(
                (prediction - reconstructed).abs() < 1e-9,
                "sample {s}: pred={prediction}, recon={reconstructed}"
            );
        }
    }

    #[test]
    fn shap_zero_tree_ensemble() {
        // Ensemble with zero trees should give all-zero SHAP values.
        let ens = TreeEnsembleBuilder::new()
            .task_type(TaskType::Regression)
            .n_features(2)
            .base_score(3.0)
            .build()
            .unwrap();
        let explainer = Explainer::new(&ens);
        let x = array![[1.0, 2.0]];
        let (output, _) = explainer.shap_values(x.view());

        let shap = match &output {
            ShapOutput::Flat(arr) => arr,
            _ => panic!("expected Flat"),
        };
        assert!((shap[[0, 0]]).abs() < 1e-12);
        assert!((shap[[0, 1]]).abs() < 1e-12);
    }

    #[test]
    fn predict_batch() {
        let ens = simple_ensemble();
        let explainer = Explainer::new(&ens);
        let x = array![[0.3], [0.7]];
        let preds = explainer.predict(x.view());
        assert!((preds[0] - 1.5).abs() < 1e-12);
        assert!((preds[1] - (-0.5)).abs() < 1e-12);
    }

    #[test]
    fn shap_local_accuracy_multi_tree() {
        // Two trees: both split on feature 0 at 0.5.
        let tree1 = vec![
            TreeNode::Internal {
                feature_index: 0,
                threshold: 0.5,
                left_child: 1,
                right_child: 2,
                missing_direction: MissingDirection::Left,
                cover: 100.0,
            },
            TreeNode::Leaf {
                value: 0.3,
                cover: 60.0,
            },
            TreeNode::Leaf {
                value: -0.2,
                cover: 40.0,
            },
        ];
        let tree2 = vec![
            TreeNode::Internal {
                feature_index: 0,
                threshold: 0.5,
                left_child: 1,
                right_child: 2,
                missing_direction: MissingDirection::Right,
                cover: 100.0,
            },
            TreeNode::Leaf {
                value: 0.1,
                cover: 50.0,
            },
            TreeNode::Leaf {
                value: -0.1,
                cover: 50.0,
            },
        ];
        let ens = TreeEnsembleBuilder::new()
            .task_type(TaskType::Regression)
            .n_features(1)
            .base_score(0.0)
            .trees(vec![tree1, tree2])
            .build()
            .unwrap();

        let explainer = Explainer::new(&ens);
        let x = array![[0.3], [0.7]];
        let (output, base) = explainer.shap_values(x.view());
        let shap = match &output {
            ShapOutput::Flat(arr) => arr,
            _ => panic!("expected Flat"),
        };
        let base_val = match base {
            BaseValue::Scalar(v) => v,
            _ => panic!("expected Scalar"),
        };

        for s in 0..2 {
            let prediction = explainer.predict_single(x.row(s));
            let shap_sum: f64 = shap.row(s).iter().sum();
            let reconstructed = base_val + shap_sum;
            assert!(
                (prediction - reconstructed).abs() < 1e-9,
                "sample {s}: pred={prediction}, recon={reconstructed}"
            );
        }
    }

    // ---------------------------------------------------------------
    // Depth 3+ tree: exercises the combinatorial weight recurrence
    // at higher depths where bugs in extend/unwound_sum manifest.
    // ---------------------------------------------------------------

    /// Depth-3 balanced tree with 4 features.
    ///
    /// ```text
    ///              [f0 <= 0.5]
    ///            /              \
    ///      [f1 <= 0.5]      [f2 <= 0.5]
    ///      /       \         /       \
    ///   [f3<=0.5] leaf(0.5) leaf(-0.3) leaf(-0.7)
    ///   /      \
    /// leaf(2.0) leaf(1.0)
    /// ```
    fn depth3_ensemble() -> TreeEnsemble {
        let tree = vec![
            TreeNode::Internal {
                feature_index: 0,
                threshold: 0.5,
                left_child: 1,
                right_child: 2,
                missing_direction: MissingDirection::Left,
                cover: 100.0,
            },
            TreeNode::Internal {
                feature_index: 1,
                threshold: 0.5,
                left_child: 3,
                right_child: 4,
                missing_direction: MissingDirection::Left,
                cover: 50.0,
            },
            TreeNode::Internal {
                feature_index: 2,
                threshold: 0.5,
                left_child: 5,
                right_child: 6,
                missing_direction: MissingDirection::Right,
                cover: 50.0,
            },
            TreeNode::Internal {
                feature_index: 3,
                threshold: 0.5,
                left_child: 7,
                right_child: 8,
                missing_direction: MissingDirection::Left,
                cover: 25.0,
            },
            TreeNode::Leaf {
                value: 0.5,
                cover: 25.0,
            },
            TreeNode::Leaf {
                value: -0.3,
                cover: 25.0,
            },
            TreeNode::Leaf {
                value: -0.7,
                cover: 25.0,
            },
            TreeNode::Leaf {
                value: 2.0,
                cover: 12.0,
            },
            TreeNode::Leaf {
                value: 1.0,
                cover: 13.0,
            },
        ];
        TreeEnsembleBuilder::new()
            .task_type(TaskType::Regression)
            .n_features(4)
            .base_score(0.0)
            .trees(vec![tree])
            .build()
            .unwrap()
    }

    #[test]
    fn shap_local_accuracy_depth3_all_left() {
        let ens = depth3_ensemble();
        let explainer = Explainer::new(&ens);
        // All features < 0.5 → left at every split → leaf(2.0)
        let x = array![[0.1, 0.2, 0.3, 0.4]];
        let pred = explainer.predict_single(x.row(0));
        let (output, base) = explainer.shap_values(x.view());
        let shap = match &output {
            ShapOutput::Flat(a) => a,
            _ => panic!(),
        };
        let bv = match base {
            BaseValue::Scalar(v) => v,
            _ => panic!(),
        };
        let recon = bv + shap.row(0).iter().sum::<f64>();
        assert!(
            (pred - recon).abs() < 1e-9,
            "depth3 all-left: pred={pred}, recon={recon}, shap={:?}",
            shap.row(0)
        );
    }

    #[test]
    fn shap_local_accuracy_depth3_mixed_path() {
        let ens = depth3_ensemble();
        let explainer = Explainer::new(&ens);
        // f0=0.1 (left), f1=0.9 (right) → leaf(0.5)
        let x = array![[0.1, 0.9, 0.3, 0.4]];
        let pred = explainer.predict_single(x.row(0));
        let (output, base) = explainer.shap_values(x.view());
        let shap = match &output {
            ShapOutput::Flat(a) => a,
            _ => panic!(),
        };
        let bv = match base {
            BaseValue::Scalar(v) => v,
            _ => panic!(),
        };
        let recon = bv + shap.row(0).iter().sum::<f64>();
        assert!(
            (pred - recon).abs() < 1e-9,
            "depth3 mixed: pred={pred}, recon={recon}, shap={:?}",
            shap.row(0)
        );
    }

    #[test]
    fn shap_local_accuracy_depth3_all_right() {
        let ens = depth3_ensemble();
        let explainer = Explainer::new(&ens);
        // All features > 0.5 → right at every split → leaf(-0.7)
        let x = array![[0.9, 0.9, 0.9, 0.9]];
        let pred = explainer.predict_single(x.row(0));
        let (output, base) = explainer.shap_values(x.view());
        let shap = match &output {
            ShapOutput::Flat(a) => a,
            _ => panic!(),
        };
        let bv = match base {
            BaseValue::Scalar(v) => v,
            _ => panic!(),
        };
        let recon = bv + shap.row(0).iter().sum::<f64>();
        assert!(
            (pred - recon).abs() < 1e-9,
            "depth3 all-right: pred={pred}, recon={recon}, shap={:?}",
            shap.row(0)
        );
    }

    // ---------------------------------------------------------------
    // Feature never split on: SHAP should be 0
    // ---------------------------------------------------------------

    #[test]
    fn shap_unsplit_feature_is_zero() {
        // n_features=3 but tree only splits on feature 0.
        // Features 1 and 2 should have SHAP = 0.
        let tree = vec![
            TreeNode::Internal {
                feature_index: 0,
                threshold: 0.5,
                left_child: 1,
                right_child: 2,
                missing_direction: MissingDirection::Left,
                cover: 100.0,
            },
            TreeNode::Leaf {
                value: 1.0,
                cover: 60.0,
            },
            TreeNode::Leaf {
                value: -1.0,
                cover: 40.0,
            },
        ];
        let ens = TreeEnsembleBuilder::new()
            .task_type(TaskType::Regression)
            .n_features(3)
            .base_score(0.0)
            .trees(vec![tree])
            .build()
            .unwrap();

        let explainer = Explainer::new(&ens);
        let x = array![[0.3, 99.0, -5.0]];
        let (output, _) = explainer.shap_values(x.view());
        let shap = match &output {
            ShapOutput::Flat(a) => a,
            _ => panic!(),
        };
        assert!(
            shap[[0, 1]].abs() < 1e-12,
            "feature 1 should be 0, got {}",
            shap[[0, 1]]
        );
        assert!(
            shap[[0, 2]].abs() < 1e-12,
            "feature 2 should be 0, got {}",
            shap[[0, 2]]
        );
    }

    // ---------------------------------------------------------------
    // NaN feature routing: SHAP should still satisfy local accuracy
    // ---------------------------------------------------------------

    #[test]
    fn shap_local_accuracy_with_nan_feature() {
        let ens = simple_ensemble();
        let explainer = Explainer::new(&ens);
        // NaN routes left (MissingDirection::Left), so prediction = base + 1.0
        let x = array![[f64::NAN]];
        let pred = explainer.predict_single(x.row(0));
        let (output, base) = explainer.shap_values(x.view());
        let shap = match &output {
            ShapOutput::Flat(a) => a,
            _ => panic!(),
        };
        let bv = match base {
            BaseValue::Scalar(v) => v,
            _ => panic!(),
        };
        let recon = bv + shap.row(0).iter().sum::<f64>();
        assert!(
            (pred - recon).abs() < 1e-9,
            "NaN local accuracy: pred={pred}, recon={recon}"
        );
    }

    // ---------------------------------------------------------------
    // Single-leaf tree: all SHAP should be 0, prediction = base + leaf
    // ---------------------------------------------------------------

    #[test]
    fn shap_single_leaf_tree() {
        let tree = vec![TreeNode::Leaf {
            value: 0.42,
            cover: 100.0,
        }];
        let ens = TreeEnsembleBuilder::new()
            .task_type(TaskType::Regression)
            .n_features(2)
            .base_score(1.0)
            .trees(vec![tree])
            .build()
            .unwrap();

        let explainer = Explainer::new(&ens);
        let x = array![[0.5, 0.5]];
        let pred = explainer.predict_single(x.row(0));
        assert!((pred - 1.42).abs() < 1e-12);

        let (output, base) = explainer.shap_values(x.view());
        let shap = match &output {
            ShapOutput::Flat(a) => a,
            _ => panic!(),
        };
        let bv = match base {
            BaseValue::Scalar(v) => v,
            _ => panic!(),
        };

        // All SHAP should be 0 (no splits, no feature attribution).
        assert!(shap[[0, 0]].abs() < 1e-12);
        assert!(shap[[0, 1]].abs() < 1e-12);
        // Base value should equal prediction (base_score + expected_leaf = 1 + 0.42 = 1.42).
        assert!((bv - 1.42).abs() < 1e-12);
    }

    // ---------------------------------------------------------------
    // Multiclass: local accuracy per class
    // ---------------------------------------------------------------

    #[test]
    fn shap_multiclass_local_accuracy() {
        // 3 classes, 3 trees (one per class), 1 feature each.
        let tree_c0 = vec![
            TreeNode::Internal {
                feature_index: 0,
                threshold: 0.5,
                left_child: 1,
                right_child: 2,
                missing_direction: MissingDirection::Left,
                cover: 100.0,
            },
            TreeNode::Leaf {
                value: 1.0,
                cover: 60.0,
            },
            TreeNode::Leaf {
                value: -0.5,
                cover: 40.0,
            },
        ];
        let tree_c1 = vec![
            TreeNode::Internal {
                feature_index: 0,
                threshold: 0.5,
                left_child: 1,
                right_child: 2,
                missing_direction: MissingDirection::Left,
                cover: 100.0,
            },
            TreeNode::Leaf {
                value: -0.3,
                cover: 60.0,
            },
            TreeNode::Leaf {
                value: 0.7,
                cover: 40.0,
            },
        ];
        let tree_c2 = vec![
            TreeNode::Internal {
                feature_index: 0,
                threshold: 0.5,
                left_child: 1,
                right_child: 2,
                missing_direction: MissingDirection::Left,
                cover: 100.0,
            },
            TreeNode::Leaf {
                value: 0.2,
                cover: 60.0,
            },
            TreeNode::Leaf {
                value: -0.1,
                cover: 40.0,
            },
        ];

        let ens = TreeEnsembleBuilder::new()
            .task_type(TaskType::MulticlassClassification { n_classes: 3 })
            .n_features(1)
            .base_score(0.0)
            .trees(vec![tree_c0, tree_c1, tree_c2])
            .build()
            .unwrap();

        let explainer = Explainer::new(&ens);
        let x = array![[0.3]]; // goes left in all trees
        let n_features = 1;
        let n_classes = 3;

        let (output, base) = explainer.shap_values(x.view());
        let (shap_vals, nc) = match &output {
            ShapOutput::Multiclass { values, n_classes } => (values, *n_classes),
            _ => panic!("expected Multiclass"),
        };
        assert_eq!(nc, 3);
        let base_vec = match &base {
            BaseValue::Vector(v) => v,
            _ => panic!("expected Vector"),
        };
        assert_eq!(base_vec.len(), 3);

        // For each class, verify local accuracy:
        // prediction_c = base_score + leaf_value_c
        // shap_sum_c = sum over features of shap[sample, feature * n_classes + c]
        // BUT our layout is shap[sample, class * n_features + feature]
        for c in 0..n_classes {
            let tree = &ens.trees[c]; // class c's tree
            let leaf_val = match &tree[1] {
                // left leaf (sample goes left)
                TreeNode::Leaf { value, .. } => *value,
                _ => panic!(),
            };
            let prediction = ens.base_score + leaf_val;

            let mut shap_sum = 0.0;
            for f in 0..n_features {
                shap_sum += shap_vals[[0, c * n_features + f]];
            }
            let recon = base_vec[c] + shap_sum;

            assert!(
                (prediction - recon).abs() < 1e-9,
                "class {c}: pred={prediction}, recon={recon}, base_c={}, shap_sum={shap_sum}",
                base_vec[c]
            );
        }
    }

    // ---------------------------------------------------------------
    // Interventional mode: basic sanity test
    // ---------------------------------------------------------------

    #[test]
    fn shap_interventional_local_accuracy() {
        let ens = simple_ensemble();
        let bg = array![[0.2], [0.3], [0.7], [0.8]]; // 4 background samples
        let explainer = Explainer::with_mode(
            &ens,
            ShapMode::Interventional {
                background: bg,
                max_background_samples: 100,
                seed: Some(42),
            },
        );

        let x = array![[0.3]]; // goes left
        let _pred = explainer.predict_single(x.row(0));
        let (output, base) = explainer.shap_values(x.view());
        let shap = match &output {
            ShapOutput::Flat(a) => a,
            _ => panic!("expected Flat"),
        };
        let bv = match base {
            BaseValue::Scalar(v) => v,
            _ => panic!("expected Scalar"),
        };

        let recon = bv + shap.row(0).iter().sum::<f64>();
        // Interventional mode may not satisfy exact local accuracy with
        // tree-path-dependent base value, but the sum should be reasonable.
        // At minimum, ensure it doesn't produce NaN or extreme values.
        assert!(
            recon.is_finite(),
            "interventional recon should be finite, got {recon}"
        );
        assert!(
            shap[[0, 0]].is_finite(),
            "interventional shap should be finite"
        );
    }

    #[test]
    fn shap_interventional_identical_fg_bg_gives_near_zero() {
        // When foreground == background, SHAP values should be near zero
        // because every feature routes the same way in both.
        let ens = simple_ensemble();
        let bg = array![[0.3]]; // identical to foreground
        let explainer = Explainer::with_mode(
            &ens,
            ShapMode::Interventional {
                background: bg,
                max_background_samples: 100,
                seed: None,
            },
        );

        let x = array![[0.3]];
        let (output, _) = explainer.shap_values(x.view());
        let shap = match &output {
            ShapOutput::Flat(a) => a,
            _ => panic!(),
        };

        // When fg == bg, all features route the same way for both,
        // so hot_zero and hot_one are both 1.0, and cold_zero/cold_one
        // are both 0.0. The net (one - zero) for the hot path is 0.
        // SHAP values should be ~0.
        assert!(
            shap[[0, 0]].abs() < 1e-9,
            "identical fg/bg should give ~0 SHAP, got {}",
            shap[[0, 0]]
        );
    }

    // ---------------------------------------------------------------
    // Rayon parallelism stress test
    // ---------------------------------------------------------------

    #[test]
    fn shap_large_batch_local_accuracy() {
        let ens = two_feature_ensemble();
        let explainer = Explainer::new(&ens);

        // 500 samples — enough to exercise rayon's work-stealing.
        let mut data = Array2::zeros((500, 2));
        for i in 0..500 {
            data[[i, 0]] = (i as f64) / 500.0;
            data[[i, 1]] = ((i * 7 + 3) as f64 % 500.0) / 500.0;
        }

        let (output, base) = explainer.shap_values(data.view());
        let shap = match &output {
            ShapOutput::Flat(a) => a,
            _ => panic!(),
        };
        let bv = match base {
            BaseValue::Scalar(v) => v,
            _ => panic!(),
        };

        for s in 0..500 {
            let pred = explainer.predict_single(data.row(s));
            let shap_sum: f64 = shap.row(s).iter().sum();
            let recon = bv + shap_sum;
            assert!(
                (pred - recon).abs() < 1e-9,
                "sample {s}: pred={pred}, recon={recon}"
            );
        }
    }

    // ---------------------------------------------------------------
    // Repeated feature on same path: uses unwind-then-re-extend
    // ---------------------------------------------------------------

    #[test]
    fn shap_local_accuracy_repeated_feature() {
        // Tree that splits on feature 0 at both depth 1 and depth 2.
        //
        //       [f0 <= 0.5]
        //       /          \
        //  [f0 <= 0.3]   leaf(-1.0)
        //   /       \
        // leaf(2.0) leaf(0.5)
        let tree = vec![
            TreeNode::Internal {
                feature_index: 0,
                threshold: 0.5,
                left_child: 1,
                right_child: 2,
                missing_direction: MissingDirection::Left,
                cover: 100.0,
            },
            TreeNode::Internal {
                feature_index: 0, // same feature again!
                threshold: 0.3,
                left_child: 3,
                right_child: 4,
                missing_direction: MissingDirection::Left,
                cover: 60.0,
            },
            TreeNode::Leaf {
                value: -1.0,
                cover: 40.0,
            },
            TreeNode::Leaf {
                value: 2.0,
                cover: 30.0,
            },
            TreeNode::Leaf {
                value: 0.5,
                cover: 30.0,
            },
        ];
        let ens = TreeEnsembleBuilder::new()
            .task_type(TaskType::Regression)
            .n_features(1)
            .base_score(0.0)
            .trees(vec![tree])
            .build()
            .unwrap();

        let explainer = Explainer::new(&ens);

        // Test multiple samples to exercise all three leaves.
        for &val in &[0.1, 0.4, 0.7] {
            let x = array![[val]];
            let pred = explainer.predict_single(x.row(0));
            let (output, base) = explainer.shap_values(x.view());
            let shap = match &output {
                ShapOutput::Flat(a) => a,
                _ => panic!(),
            };
            let bv = match base {
                BaseValue::Scalar(v) => v,
                _ => panic!(),
            };
            let recon = bv + shap.row(0).iter().sum::<f64>();
            assert!(
                (pred - recon).abs() < 1e-9,
                "repeated feature val={val}: pred={pred}, recon={recon}, shap={:?}",
                shap.row(0)
            );
        }
    }

    // ---------------------------------------------------------------
    // Zero-cover node: should not produce NaN
    // ---------------------------------------------------------------

    #[test]
    fn shap_zero_cover_internal_does_not_nan() {
        // This tree has a zero-cover internal node at root.
        // The explainer should skip it gracefully (not produce NaN).
        let tree = vec![
            TreeNode::Internal {
                feature_index: 0,
                threshold: 0.5,
                left_child: 1,
                right_child: 2,
                missing_direction: MissingDirection::Left,
                cover: 0.0, // zero cover!
            },
            TreeNode::Leaf {
                value: 1.0,
                cover: 0.0,
            },
            TreeNode::Leaf {
                value: -1.0,
                cover: 0.0,
            },
        ];

        // The validator allows zero cover, but the builder will check cover
        // is non-negative and finite (0.0 passes).
        let ens = TreeEnsembleBuilder::new()
            .task_type(TaskType::Regression)
            .n_features(1)
            .base_score(0.5)
            .trees(vec![tree])
            .build()
            .unwrap();

        let explainer = Explainer::new(&ens);
        let x = array![[0.3]];
        let (output, _) = explainer.shap_values(x.view());
        let shap = match &output {
            ShapOutput::Flat(a) => a,
            _ => panic!(),
        };

        // SHAP values should be finite (not NaN).
        assert!(
            shap[[0, 0]].is_finite(),
            "zero-cover should not produce NaN, got {}",
            shap[[0, 0]]
        );
    }
}
