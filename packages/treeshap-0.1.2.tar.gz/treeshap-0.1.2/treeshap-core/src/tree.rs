//! Core tree node types and supporting enums.
//!
//! These types form the leaves of the unified IR. Every parser in
//! `treeshap-io` produces values of these types, and the SHAP engine
//! in this crate consumes them.

/// Direction in which missing feature values are routed at a split node.
///
/// This is a **required** field on every internal node — there is no safe
/// default. A split node without an explicit missing direction is malformed,
/// and the parser must reject it.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
#[non_exhaustive]
pub enum MissingDirection {
    /// Missing values are routed to the left child.
    Left,
    /// Missing values are routed to the right child.
    Right,
    /// This node never encounters missing values. LightGBM can express this
    /// for features that had no missing values in training data.
    None,
}

/// The learning task that produced the tree ensemble.
///
/// `TaskType` determines the output SHAP matrix shape, whether a
/// post-transform applies, and how many trees form a single boosting round.
/// The IR always stores **pre-transform** leaf values regardless of task type.
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
#[non_exhaustive]
pub enum TaskType {
    /// Binary classification (e.g., `binary:logistic`).
    /// Leaf values are raw log-odds. Post-transform: sigmoid.
    /// One tree per boosting round.
    BinaryClassification,

    /// Regression (e.g., `reg:squarederror`).
    /// Leaf values are raw predictions. No post-transform.
    /// One tree per boosting round.
    Regression,

    /// Multiclass classification (e.g., `multi:softprob`).
    /// Leaf values are raw per-class scores. Post-transform: softmax.
    /// `n_classes` trees per boosting round.
    MulticlassClassification {
        /// Number of target classes.
        n_classes: usize,
    },

    /// Ranked regression (e.g., LightGBM lambdarank).
    /// Leaf values are raw relevance scores. No post-transform.
    /// One tree per boosting round.
    RankedRegression,
}

/// A single node in a decision tree, stored in a flat array.
///
/// Trees are represented as `Vec<TreeNode>` in depth-first order.
/// Index 0 is always the root. Children are referenced by their integer
/// index into the array, enabling bounds-checked access and cache-friendly
/// traversal.
#[derive(Debug, Clone, PartialEq)]
#[non_exhaustive]
pub enum TreeNode {
    /// An internal (split) node that routes samples to one of two children.
    #[non_exhaustive]
    Internal {
        /// Index of the input feature this node splits on.
        feature_index: usize,
        /// The split threshold. Samples with `feature <= threshold` go left.
        threshold: f64,
        /// Index into the tree's node array for the left subtree.
        left_child: usize,
        /// Index into the tree's node array for the right subtree.
        right_child: usize,
        /// Direction for routing samples with missing feature values.
        missing_direction: MissingDirection,
        /// Number of training samples that reached this node. Required for
        /// computing path-dependent SHAP weights.
        cover: f64,
    },

    /// A terminal leaf node that produces a prediction value.
    #[non_exhaustive]
    Leaf {
        /// Raw output of this leaf, always pre-post-transform.
        value: f64,
        /// Number of training samples that reached this leaf. Required for
        /// weight computation in both tree-path-dependent and interventional
        /// SHAP modes.
        cover: f64,
    },
}

impl TreeNode {
    /// Creates an internal (split) node.
    ///
    /// This constructor is provided because `#[non_exhaustive]` on the variant
    /// prevents struct-expression construction outside this crate.
    #[must_use]
    pub fn internal(
        feature_index: usize,
        threshold: f64,
        left_child: usize,
        right_child: usize,
        missing_direction: MissingDirection,
        cover: f64,
    ) -> Self {
        Self::Internal {
            feature_index,
            threshold,
            left_child,
            right_child,
            missing_direction,
            cover,
        }
    }

    /// Creates a leaf node.
    ///
    /// This constructor is provided because `#[non_exhaustive]` on the variant
    /// prevents struct-expression construction outside this crate.
    #[must_use]
    pub fn leaf(value: f64, cover: f64) -> Self {
        Self::Leaf { value, cover }
    }

    /// Returns the cover (training sample count) for this node regardless
    /// of variant.
    #[must_use]
    pub fn cover(&self) -> f64 {
        match self {
            Self::Internal { cover, .. } | Self::Leaf { cover, .. } => *cover,
        }
    }

    /// Returns `true` if this node is a leaf.
    #[must_use]
    pub fn is_leaf(&self) -> bool {
        matches!(self, Self::Leaf { .. })
    }

    /// Returns `true` if this node is an internal (split) node.
    #[must_use]
    pub fn is_internal(&self) -> bool {
        matches!(self, Self::Internal { .. })
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn missing_direction_variants_are_distinct() {
        assert_ne!(MissingDirection::Left, MissingDirection::Right);
        assert_ne!(MissingDirection::Left, MissingDirection::None);
        assert_ne!(MissingDirection::Right, MissingDirection::None);
    }

    #[test]
    fn missing_direction_is_copy() {
        let dir = MissingDirection::Left;
        let copy = dir;
        assert_eq!(dir, copy);
    }

    #[test]
    fn task_type_multiclass_carries_n_classes() {
        let task = TaskType::MulticlassClassification { n_classes: 3 };
        if let TaskType::MulticlassClassification { n_classes } = task {
            assert_eq!(n_classes, 3);
        } else {
            panic!("expected MulticlassClassification");
        }
    }

    #[test]
    fn leaf_node_cover() {
        let leaf = TreeNode::Leaf {
            value: 1.5,
            cover: 42.0,
        };
        assert!((leaf.cover() - 42.0).abs() < f64::EPSILON);
        assert!(leaf.is_leaf());
        assert!(!leaf.is_internal());
    }

    #[test]
    fn internal_node_cover() {
        let node = TreeNode::Internal {
            feature_index: 0,
            threshold: 0.5,
            left_child: 1,
            right_child: 2,
            missing_direction: MissingDirection::Left,
            cover: 100.0,
        };
        assert!((node.cover() - 100.0).abs() < f64::EPSILON);
        assert!(node.is_internal());
        assert!(!node.is_leaf());
    }

    #[test]
    fn internal_node_fields_accessible() {
        let node = TreeNode::Internal {
            feature_index: 3,
            threshold: 2.5,
            left_child: 1,
            right_child: 2,
            missing_direction: MissingDirection::Right,
            cover: 80.0,
        };
        if let TreeNode::Internal {
            feature_index,
            threshold,
            left_child,
            right_child,
            missing_direction,
            cover,
            ..
        } = node
        {
            assert_eq!(feature_index, 3);
            assert!((threshold - 2.5).abs() < f64::EPSILON);
            assert_eq!(left_child, 1);
            assert_eq!(right_child, 2);
            assert_eq!(missing_direction, MissingDirection::Right);
            assert!((cover - 80.0).abs() < f64::EPSILON);
        } else {
            panic!("expected Internal");
        }
    }

    #[test]
    fn leaf_node_fields_accessible() {
        let node = TreeNode::Leaf {
            value: -0.75,
            cover: 25.0,
        };
        if let TreeNode::Leaf { value, cover, .. } = node {
            assert!((value - (-0.75)).abs() < f64::EPSILON);
            assert!((cover - 25.0).abs() < f64::EPSILON);
        } else {
            panic!("expected Leaf");
        }
    }
}
