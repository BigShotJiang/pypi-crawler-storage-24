/// Verify that calling `build()` without setting `task_type` does not compile.
use treeshap_core::{TreeEnsembleBuilder, TreeNode, MissingDirection};

fn main() {
    let tree = vec![
        TreeNode::internal(0, 0.5, 1, 2, MissingDirection::Left, 100.0),
        TreeNode::leaf(1.0, 60.0),
        TreeNode::leaf(-1.0, 40.0),
    ];

    let _ = TreeEnsembleBuilder::new()
        .n_features(1)
        .base_score(0.0)
        .trees(vec![tree])
        .build();
}
