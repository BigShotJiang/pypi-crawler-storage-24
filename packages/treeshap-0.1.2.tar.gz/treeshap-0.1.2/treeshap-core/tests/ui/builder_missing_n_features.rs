/// Verify that calling `build()` without setting `n_features` does not compile.
use treeshap_core::{TreeEnsembleBuilder, TreeNode, TaskType, MissingDirection};

fn main() {
    let tree = vec![
        TreeNode::internal(0, 0.5, 1, 2, MissingDirection::Left, 100.0),
        TreeNode::leaf(1.0, 60.0),
        TreeNode::leaf(-1.0, 40.0),
    ];

    let _ = TreeEnsembleBuilder::new()
        .task_type(TaskType::Regression)
        .base_score(0.0)
        .trees(vec![tree])
        .build();
}
