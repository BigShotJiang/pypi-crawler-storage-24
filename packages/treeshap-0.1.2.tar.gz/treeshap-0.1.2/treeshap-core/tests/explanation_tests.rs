//! Integration tests for ShapExplanation, verify(), and Display.

use ndarray::array;
use treeshap_core::{
    BaseValue, Explainer, MissingDirection, ShapExplanation, ShapOutput, TaskType,
    TreeEnsembleBuilder, TreeNode,
};

/// Builds a simple 1-feature regression ensemble for testing.
fn simple_ensemble() -> treeshap_core::TreeEnsemble {
    let tree = vec![
        TreeNode::internal(0, 0.5, 1, 2, MissingDirection::Left, 100.0),
        TreeNode::leaf(1.0, 60.0),
        TreeNode::leaf(-1.0, 40.0),
    ];
    TreeEnsembleBuilder::new()
        .task_type(TaskType::Regression)
        .n_features(1)
        .base_score(0.5)
        .trees(vec![tree])
        .feature_names(vec!["age".to_string()])
        .build()
        .unwrap()
}

#[test]
fn explain_produces_valid_explanation() {
    let ens = simple_ensemble();
    let explainer = Explainer::new(&ens);
    let x = array![[0.3], [0.7]];

    let explanation = explainer.explain(x.view());

    assert_eq!(explanation.n_samples(), 2);
    assert_eq!(explanation.n_features(), 1);
    assert!(explanation.feature_values().is_some());
    assert_eq!(
        explanation.feature_names(),
        Some(["age".to_string()].as_slice())
    );
    assert_eq!(explanation.predictions().len(), 2);
}

#[test]
fn verify_passes_on_clean_explanation() {
    let ens = simple_ensemble();
    let explainer = Explainer::new(&ens);
    let x = array![[0.3], [0.7], [0.5]];

    let explanation = explainer.explain(x.view());
    let report = explanation.verify();

    assert!(report.is_pass(), "verify should pass: {report}");
    assert_eq!(report.n_samples(), 3);
    assert_eq!(report.n_passing(), 3);
    assert_eq!(report.n_failing(), 0);
}

#[test]
fn verify_display_shows_pass() {
    let ens = simple_ensemble();
    let explainer = Explainer::new(&ens);
    let x = array![[0.3]];

    let explanation = explainer.explain(x.view());
    let report = explanation.verify();
    let display = report.to_string();

    assert!(display.contains("PASS"));
    assert!(display.contains("1 samples"));
}

#[test]
fn verify_default_tolerance_passes() {
    let ens = simple_ensemble();
    let explainer = Explainer::new(&ens);
    let x = array![[0.3], [0.7]];

    let explanation = explainer.explain(x.view());

    // Default tolerance (1e-7) should pass for in-memory computation.
    let report = explanation.verify();
    assert!(report.is_pass(), "default verify should pass: {report}");

    // Strict tolerance (1e-9) per local accuracy invariant should also pass
    // for in-memory computation without serialization round-trip.
    let strict = explanation.verify_with_tolerance(1e-9);
    assert!(
        strict.is_pass(),
        "1e-9 verify should pass for in-memory: {strict}"
    );
}

#[test]
fn explanation_display_shows_feature_names() {
    let ens = simple_ensemble();
    let explainer = Explainer::new(&ens);
    let x = array![[0.3]];

    let explanation = explainer.explain(x.view());
    let display = explanation.to_string();

    assert!(display.contains("ShapExplanation"));
    assert!(display.contains("1 samples"));
    assert!(display.contains("1 features"));
    assert!(display.contains("age"));
}

#[test]
fn explanation_display_truncates_long_names() {
    let tree = vec![TreeNode::leaf(0.5, 100.0)];
    let ens = TreeEnsembleBuilder::new()
        .task_type(TaskType::Regression)
        .n_features(1)
        .base_score(0.0)
        .trees(vec![tree])
        .feature_names(vec![
            "this_is_a_very_long_feature_name_that_exceeds_limit".to_string()
        ])
        .build()
        .unwrap();

    let explainer = Explainer::new(&ens);
    let x = array![[0.5]];
    let explanation = explainer.explain(x.view());
    let display = explanation.to_string();

    assert!(display.contains("..."), "long names should be truncated");
}

#[test]
fn verification_report_display_format() {
    // Use the two_feature tree which may have tiny float drift,
    // and a very strict tolerance to exercise the FAIL path.
    let tree = vec![
        TreeNode::internal(0, 0.5, 1, 2, MissingDirection::Left, 100.0),
        TreeNode::internal(1, 0.3, 3, 4, MissingDirection::Left, 60.0),
        TreeNode::leaf(-1.0, 40.0),
        TreeNode::leaf(2.0, 35.0),
        TreeNode::leaf(0.5, 25.0),
    ];
    let ens = TreeEnsembleBuilder::new()
        .task_type(TaskType::Regression)
        .n_features(2)
        .base_score(0.0)
        .trees(vec![tree])
        .build()
        .unwrap();

    let explainer = Explainer::new(&ens);
    let x = array![[0.2, 0.1]];
    let explanation = explainer.explain(x.view());

    // With normal tolerance, should pass.
    let report = explanation.verify();
    assert!(
        report.is_pass(),
        "should pass at default tolerance: {report}"
    );

    // Verify Display for passing case.
    let display = report.to_string();
    assert!(display.contains("PASS"));
}

#[test]
fn base_value_scalar_for_regression() {
    let ens = simple_ensemble();
    let explainer = Explainer::new(&ens);
    let x = array![[0.3]];

    let explanation = explainer.explain(x.view());
    match explanation.base_value() {
        BaseValue::Scalar(v) => assert!(v.is_finite()),
        _ => panic!("expected Scalar for regression"),
    }
}

#[test]
fn explain_multiclass() {
    let tree_c0 = vec![
        TreeNode::internal(0, 0.5, 1, 2, MissingDirection::Left, 100.0),
        TreeNode::leaf(1.0, 60.0),
        TreeNode::leaf(-0.5, 40.0),
    ];
    let tree_c1 = vec![
        TreeNode::internal(0, 0.5, 1, 2, MissingDirection::Left, 100.0),
        TreeNode::leaf(-0.3, 60.0),
        TreeNode::leaf(0.7, 40.0),
    ];

    let ens = TreeEnsembleBuilder::new()
        .task_type(TaskType::MulticlassClassification { n_classes: 2 })
        .n_features(1)
        .base_score(0.0)
        .trees(vec![tree_c0, tree_c1])
        .build()
        .unwrap();

    let explainer = Explainer::new(&ens);
    let x = array![[0.3]];
    let explanation = explainer.explain(x.view());

    assert_eq!(explanation.n_samples(), 1);
    match explanation.base_value() {
        BaseValue::Vector(v) => assert_eq!(v.len(), 2),
        _ => panic!("expected Vector for multiclass"),
    }
    match explanation.shap_values() {
        ShapOutput::Multiclass { n_classes, .. } => assert_eq!(*n_classes, 2),
        _ => panic!("expected Multiclass"),
    }
}

// Serde tests (only compiled with the "serde" feature).
#[cfg(feature = "serde")]
mod serde_tests {
    use super::*;

    #[test]
    fn serde_round_trip_regression() {
        let ens = simple_ensemble();
        let explainer = Explainer::new(&ens);
        let x = array![[0.3], [0.7]];

        let original = explainer.explain(x.view());

        let json = serde_json::to_string(&original).expect("serialize");
        let restored: ShapExplanation = serde_json::from_str(&json).expect("deserialize");

        assert_eq!(restored.n_samples(), original.n_samples());
        assert_eq!(restored.n_features(), original.n_features());
        assert_eq!(restored.feature_names(), original.feature_names());
        assert_eq!(restored.predictions().len(), original.predictions().len());

        // Verify the restored explanation still passes.
        let report = restored.verify();
        assert!(report.is_pass(), "restored should pass verify: {report}");
    }

    #[test]
    fn serde_round_trip_preserves_values() {
        let ens = simple_ensemble();
        let explainer = Explainer::new(&ens);
        let x = array![[0.3]];

        let original = explainer.explain(x.view());
        let json = serde_json::to_string(&original).unwrap();
        let restored: ShapExplanation = serde_json::from_str(&json).unwrap();

        // Check predictions match element-wise.
        for i in 0..original.n_samples() {
            assert!(
                (original.predictions()[i] - restored.predictions()[i]).abs() < 1e-12,
                "prediction mismatch at sample {i}"
            );
        }
    }
}
