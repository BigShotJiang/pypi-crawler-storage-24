"""
FlashQ v0.2.1 — Clean Install Full Feature Test
================================================
Normal bir kullanıcı gibi pip install yapıp HER ÖZELLİĞİ test eder.
"""
import sys
import os
import time
import threading
import tempfile
import json
import traceback

results = []

def test(name):
    """Decorator to track test results."""
    def decorator(fn):
        def wrapper():
            try:
                fn()
                results.append({"name": name, "status": "PASS", "error": None})
                print(f"  ✅ PASS: {name}")
            except Exception as e:
                results.append({"name": name, "status": "FAIL", "error": f"{type(e).__name__}: {e}"})
                print(f"  ❌ FAIL: {name}")
                print(f"         {type(e).__name__}: {e}")
                traceback.print_exc()
        return wrapper
    return decorator


# ═══════════════════════════════════════
# TEST 1: Import
# ═══════════════════════════════════════
@test("1. Import — FlashQ ana modül")
def test_import():
    from flashq import FlashQ
    assert FlashQ is not None

@test("2. Import — version check")
def test_version():
    from flashq import __version__
    assert __version__ == "0.2.1", f"Expected 0.2.1, got {__version__}"

@test("3. Import — tüm public API")
def test_public_api():
    from flashq import (
        FlashQ, TaskState, TaskPriority, TaskMessage, TaskResult,
        Middleware, Scheduler, __version__
    )
    assert all([FlashQ, TaskState, TaskPriority, TaskMessage, TaskResult, Middleware, Scheduler])

@test("4. Import — canvas primitives")
def test_canvas_imports():
    from flashq import Signature, Chain, Group, Chord, chain, group, chord
    assert all([Signature, Chain, Group, Chord, chain, group, chord])

@test("5. Import — backends")
def test_backend_import():
    from flashq.backends.sqlite import SQLiteBackend
    assert SQLiteBackend is not None

@test("6. Import — worker")
def test_worker_import():
    from flashq.worker import Worker
    assert Worker is not None

@test("7. Import — middleware")
def test_middleware_import():
    from flashq.middleware import Middleware, MiddlewareStack, LoggingMiddleware, TimeoutMiddleware
    assert all([Middleware, MiddlewareStack, LoggingMiddleware, TimeoutMiddleware])

@test("8. Import — rate limiter")
def test_ratelimit_import():
    from flashq.ratelimit import RateLimiter, TokenBucket
    assert all([RateLimiter, TokenBucket])

@test("9. Import — DLQ")
def test_dlq_import():
    from flashq.dlq import DeadLetterQueue
    assert DeadLetterQueue is not None

@test("10. Import — scheduler")
def test_scheduler_import():
    from flashq.scheduler import Scheduler
    assert Scheduler is not None

@test("11. Import — serializers")
def test_serializers_import():
    from flashq.serializers import JSONSerializer, PickleSerializer
    assert all([JSONSerializer, PickleSerializer])

@test("12. Import — exceptions")
def test_exceptions_import():
    from flashq.exceptions import (
        FlashQError, TaskNotFoundError, TaskRetryError,
        TaskTimeoutError, BackendError
    )
    assert all([FlashQError, TaskNotFoundError, TaskRetryError, TaskTimeoutError, BackendError])


# ═══════════════════════════════════════
# TEST 2: App oluşturma
# ═══════════════════════════════════════
@test("13. App — default (SQLite in-memory)")
def test_app_default():
    from flashq import FlashQ
    app = FlashQ()
    assert app is not None
    assert app.name == "flashq"

@test("14. App — custom name")
def test_app_custom_name():
    from flashq import FlashQ
    app = FlashQ(name="myapp")
    assert app.name == "myapp"

@test("15. App — SQLite file backend")
def test_app_sqlite_file():
    from flashq import FlashQ
    from flashq.backends.sqlite import SQLiteBackend
    tmp = tempfile.mktemp(suffix=".db")
    backend = SQLiteBackend(path=tmp)
    backend.setup()
    app = FlashQ(backend=backend)
    assert app is not None
    backend.teardown()
    if os.path.exists(tmp):
        os.unlink(tmp)


# ═══════════════════════════════════════
# TEST 3: Task tanımlama & enqueue
# ═══════════════════════════════════════
@test("16. Task — basit tanımlama")
def test_task_define():
    from flashq import FlashQ
    app = FlashQ()
    
    @app.task(name="hello")
    def hello(name: str) -> str:
        return f"Hello {name}"
    
    assert "hello" in app.registry

@test("17. Task — delay ile enqueue")
def test_task_delay():
    from flashq import FlashQ
    app = FlashQ()
    
    @app.task(name="add")
    def add(a: int, b: int) -> int:
        return a + b
    
    handle = add.delay(a=1, b=2)
    assert handle is not None
    assert handle.id is not None
    assert len(handle.id) == 32  # hex UUID

@test("18. Task — apply ile senkron çalıştırma")
def test_task_apply():
    from flashq import FlashQ
    app = FlashQ()
    
    @app.task(name="multiply")
    def multiply(a: int, b: int) -> int:
        return a * b
    
    handle = multiply.apply(args=(3, 7))
    # apply returns a TaskHandle (enqueues), not direct result
    assert handle is not None
    assert handle.id is not None

@test("19. Task — retry parametreleri")
def test_task_retry_params():
    from flashq import FlashQ
    app = FlashQ()
    
    @app.task(name="retryable", max_retries=5, retry_delay=2.0)
    def retryable():
        pass
    
    task = app.registry["retryable"]
    assert task.max_retries == 5
    assert task.retry_delay == 2.0

@test("20. Task — priority enqueue")
def test_task_priority():
    from flashq import FlashQ, TaskPriority
    app = FlashQ()
    
    @app.task(name="important")
    def important():
        return "done"
    
    handle = important.delay(priority=TaskPriority.HIGH)
    assert handle is not None


# ═══════════════════════════════════════
# TEST 4: Worker — task işleme
# ═══════════════════════════════════════
@test("21. Worker — basit task işleme")
def test_worker_basic():
    from flashq import FlashQ, TaskState
    from flashq.backends.sqlite import SQLiteBackend
    from flashq.worker import Worker
    
    tmp = tempfile.mktemp(suffix=".db")
    backend = SQLiteBackend(path=tmp)
    backend.setup()
    app = FlashQ(backend=backend)
    
    @app.task(name="add")
    def add(a: int, b: int) -> int:
        return a + b
    
    handle = add.delay(a=10, b=20)
    
    worker = Worker(app, poll_interval=0.05, concurrency=2, schedule_interval=0.3)
    t = threading.Thread(target=worker.start, daemon=True)
    t.start()
    time.sleep(2)
    worker.stop()
    t.join(timeout=5)
    
    result = backend.get_result(handle.id)
    assert result is not None, "Result should exist"
    assert result.state == TaskState.SUCCESS
    assert result.result == 30
    
    backend.teardown()
    if os.path.exists(tmp):
        os.unlink(tmp)

@test("22. Worker — birden fazla task")
def test_worker_multiple():
    from flashq import FlashQ, TaskState
    from flashq.backends.sqlite import SQLiteBackend
    from flashq.worker import Worker
    
    tmp = tempfile.mktemp(suffix=".db")
    backend = SQLiteBackend(path=tmp)
    backend.setup()
    app = FlashQ(backend=backend)
    
    @app.task(name="greet")
    def greet(name: str) -> str:
        return f"Hi {name}"
    
    handles = [greet.delay(name=n) for n in ["Alice", "Bob", "Charlie"]]
    
    worker = Worker(app, poll_interval=0.05, concurrency=4, schedule_interval=0.3)
    t = threading.Thread(target=worker.start, daemon=True)
    t.start()
    time.sleep(2)
    worker.stop()
    t.join(timeout=5)
    
    for h, name in zip(handles, ["Alice", "Bob", "Charlie"]):
        result = backend.get_result(h.id)
        assert result is not None
        assert result.state == TaskState.SUCCESS
        assert result.result == f"Hi {name}"
    
    backend.teardown()
    if os.path.exists(tmp):
        os.unlink(tmp)

@test("23. Worker — hata yakalama")
def test_worker_error():
    from flashq import FlashQ, TaskState
    from flashq.backends.sqlite import SQLiteBackend
    from flashq.worker import Worker
    
    tmp = tempfile.mktemp(suffix=".db")
    backend = SQLiteBackend(path=tmp)
    backend.setup()
    app = FlashQ(backend=backend)
    
    @app.task(name="fail_task", max_retries=0)
    def fail_task():
        raise ValueError("intentional error")
    
    handle = fail_task.delay()
    
    worker = Worker(app, poll_interval=0.05, concurrency=2, schedule_interval=0.3)
    t = threading.Thread(target=worker.start, daemon=True)
    t.start()
    time.sleep(2)
    worker.stop()
    t.join(timeout=5)
    
    result = backend.get_result(handle.id)
    assert result is not None, "Result should exist for failed task"
    # Task with max_retries=0 goes to FAILURE or DEAD
    assert result.state in (TaskState.FAILURE, TaskState.DEAD), f"Unexpected state: {result.state}"
    assert result.error is not None and "intentional error" in result.error
    
    backend.teardown()
    if os.path.exists(tmp):
        os.unlink(tmp)

@test("24. Worker — retry mekanizması")
def test_worker_retry():
    from flashq import FlashQ, TaskState
    from flashq.backends.sqlite import SQLiteBackend
    from flashq.worker import Worker
    
    tmp = tempfile.mktemp(suffix=".db")
    backend = SQLiteBackend(path=tmp)
    backend.setup()
    app = FlashQ(backend=backend)
    
    call_count = {"n": 0}
    
    @app.task(name="retry_task", max_retries=3, retry_delay=0.1)
    def retry_task():
        call_count["n"] += 1
        if call_count["n"] < 3:
            raise RuntimeError("not yet")
        return "finally worked"
    
    handle = retry_task.delay()
    
    worker = Worker(app, poll_interval=0.05, concurrency=2, schedule_interval=0.3)
    t = threading.Thread(target=worker.start, daemon=True)
    t.start()
    time.sleep(4)
    worker.stop()
    t.join(timeout=5)
    
    result = backend.get_result(handle.id)
    assert result is not None, f"Result should exist, call_count={call_count['n']}"
    assert result.state == TaskState.SUCCESS, f"State: {result.state}, error: {result.error}"
    assert result.result == "finally worked"
    assert call_count["n"] >= 3
    
    backend.teardown()
    if os.path.exists(tmp):
        os.unlink(tmp)


# ═══════════════════════════════════════
# TEST 5: Middleware
# ═══════════════════════════════════════
@test("25. Middleware — custom middleware")
def test_custom_middleware():
    from flashq import FlashQ, Middleware, TaskState
    from flashq.backends.sqlite import SQLiteBackend
    from flashq.worker import Worker
    
    tmp = tempfile.mktemp(suffix=".db")
    backend = SQLiteBackend(path=tmp)
    backend.setup()
    app = FlashQ(backend=backend)
    
    log = []
    
    class TestMiddleware(Middleware):
        def before_execute(self, message):
            log.append(f"before:{message.task_name}")
        def after_execute(self, message, result):
            log.append(f"after:{message.task_name}:{result}")
    
    app.add_middleware(TestMiddleware())
    
    @app.task(name="mw_task")
    def mw_task():
        return 42
    
    mw_task.delay()
    
    worker = Worker(app, poll_interval=0.05, concurrency=2, schedule_interval=0.3)
    t = threading.Thread(target=worker.start, daemon=True)
    t.start()
    time.sleep(2)
    worker.stop()
    t.join(timeout=5)
    
    assert len(log) >= 1, f"Expected at least 1 log entry, got {log}"
    assert log[0] == "before:mw_task"
    
    backend.teardown()
    if os.path.exists(tmp):
        os.unlink(tmp)

@test("26. Middleware — LoggingMiddleware")
def test_logging_middleware():
    from flashq import FlashQ
    from flashq.middleware import LoggingMiddleware
    app = FlashQ()
    app.add_middleware(LoggingMiddleware())
    assert len(app.middleware.middlewares) >= 1


# ═══════════════════════════════════════
# TEST 6: Rate Limiting
# ═══════════════════════════════════════
@test("27. RateLimiter — configure")
def test_ratelimit_configure():
    from flashq.ratelimit import RateLimiter
    rl = RateLimiter(default_rate="100/s")
    rl.configure("my_task", rate="50/m")
    stats = rl.get_stats()
    assert "my_task" in stats

@test("28. RateLimiter — token bucket")
def test_token_bucket():
    from flashq.ratelimit import TokenBucket
    bucket = TokenBucket(max_tokens=10, period=1.0)
    for _ in range(10):
        assert bucket.acquire() is True
    assert bucket.acquire() is False


# ═══════════════════════════════════════
# TEST 7: DLQ
# ═══════════════════════════════════════
@test("29. DLQ — dead task capture")
def test_dlq():
    from flashq import FlashQ, TaskState
    from flashq.backends.sqlite import SQLiteBackend
    from flashq.worker import Worker
    from flashq.dlq import DeadLetterQueue
    
    tmp = tempfile.mktemp(suffix=".db")
    backend = SQLiteBackend(path=tmp)
    backend.setup()
    app = FlashQ(backend=backend)
    
    dlq = DeadLetterQueue(app)
    app.add_middleware(dlq.middleware())
    
    @app.task(name="dead_task", max_retries=0)
    def dead_task():
        raise Exception("boom")
    
    dead_task.delay()
    
    worker = Worker(app, poll_interval=0.05, concurrency=2, schedule_interval=0.3)
    t = threading.Thread(target=worker.start, daemon=True)
    t.start()
    time.sleep(2)
    worker.stop()
    t.join(timeout=5)
    
    assert dlq.count() >= 1, f"DLQ should have >= 1 task, got {dlq.count()}"
    dead = dlq.list()
    assert len(dead) >= 1
    assert "boom" in dead[0].error
    
    purged = dlq.purge()
    assert purged >= 1
    assert dlq.count() == 0
    
    backend.teardown()
    if os.path.exists(tmp):
        os.unlink(tmp)


# ═══════════════════════════════════════
# TEST 8: Scheduler
# ═══════════════════════════════════════
@test("30. Scheduler — interval schedule")
def test_scheduler_interval():
    from flashq import FlashQ, Scheduler
    from flashq.scheduler import IntervalSchedule
    app = FlashQ()
    scheduler = Scheduler(app)
    
    @app.task(name="periodic")
    def periodic():
        return "tick"
    
    scheduler.add("periodic", IntervalSchedule(seconds=10))
    # scheduler should have at least 1 job
    assert scheduler is not None

@test("31. Scheduler — cron expression")
def test_scheduler_cron():
    from flashq import FlashQ, Scheduler
    from flashq.scheduler import CronSchedule
    app = FlashQ()
    scheduler = Scheduler(app)
    
    @app.task(name="cron_task")
    def cron_task():
        return "cron"
    
    scheduler.add("cron_task", CronSchedule("*/5 * * * *"))
    assert scheduler is not None


# ═══════════════════════════════════════
# TEST 9: Canvas
# ═══════════════════════════════════════
@test("32. Canvas — Signature creation")
def test_signature():
    from flashq import FlashQ, Signature
    app = FlashQ()
    
    @app.task(name="add")
    def add(a, b):
        return a + b
    
    sig = add.s(1, 2)
    assert isinstance(sig, Signature)
    assert sig.task_name == "add"
    assert sig.args == (1, 2)

@test("33. Canvas — chain creation")
def test_chain_create():
    from flashq import FlashQ, chain
    app = FlashQ()
    
    @app.task(name="step1")
    def step1(x):
        return x + 1
    
    @app.task(name="step2")
    def step2(x):
        return x * 2
    
    c = chain(step1.s(5), step2.s())
    assert len(c.signatures) == 2

@test("34. Canvas — group creation")
def test_group_create():
    from flashq import FlashQ, group
    app = FlashQ()
    
    @app.task(name="process")
    def process(n):
        return n * 2
    
    g = group(process.s(1), process.s(2), process.s(3))
    assert len(g.signatures) == 3


# ═══════════════════════════════════════
# TEST 10: Serializers
# ═══════════════════════════════════════
@test("35. Serializer — JSON roundtrip")
def test_json_serializer():
    from flashq.serializers import JSONSerializer
    s = JSONSerializer()
    data = {"key": "value", "num": 42, "list": [1, 2, 3]}
    encoded = s.dumps(data)
    decoded = s.loads(encoded)
    assert decoded == data

@test("36. Serializer — Pickle roundtrip")
def test_pickle_serializer():
    from flashq.serializers import PickleSerializer
    s = PickleSerializer()
    data = {"key": "value", "num": 42, "set": {1, 2, 3}}
    encoded = s.dumps(data)
    decoded = s.loads(encoded)
    assert decoded == data


# ═══════════════════════════════════════
# TEST 11: CLI
# ═══════════════════════════════════════
@test("37. CLI — parser import")
def test_cli_parser():
    from flashq.cli import build_parser
    parser = build_parser()
    assert parser is not None


# ═══════════════════════════════════════
# TEST 12: Demo & Dashboard
# ═══════════════════════════════════════
@test("38. Demo — module exists")
def test_demo_exists():
    import flashq.demo
    assert hasattr(flashq.demo, "main")

@test("39. Dashboard — module import")
def test_dashboard_import():
    import flashq.dashboard
    assert flashq.dashboard is not None


# ═══════════════════════════════════════
# TEST 13: Models
# ═══════════════════════════════════════
@test("40. Models — TaskMessage roundtrip")
def test_taskmessage():
    from flashq import TaskMessage
    msg = TaskMessage(task_name="test", args=(1, 2), kwargs={"key": "val"})
    d = msg.to_dict()
    msg2 = TaskMessage.from_dict(d)
    assert msg2.task_name == "test"
    assert msg2.args == (1, 2)
    assert msg2.kwargs == {"key": "val"}

@test("41. Models — TaskResult")
def test_taskresult():
    from flashq import TaskResult, TaskState
    result = TaskResult(task_id="abc123", state=TaskState.SUCCESS, result=42)
    assert result.task_id == "abc123"
    assert result.state == TaskState.SUCCESS
    assert result.result == 42

@test("42. Models — TaskState enum")
def test_taskstate():
    from flashq import TaskState
    assert TaskState.PENDING.value == "pending"
    assert TaskState.SUCCESS.value == "success"
    assert TaskState.FAILURE.value == "failure"

@test("43. Models — TaskPriority")
def test_taskpriority():
    from flashq import TaskPriority
    assert TaskPriority.LOW.value < TaskPriority.HIGH.value


# ═══════════════════════════════════════
# TEST 14: E2E Senaryolar
# ═══════════════════════════════════════
@test("44. E2E — email processing pipeline")
def test_e2e_pipeline():
    from flashq import FlashQ, TaskState
    from flashq.backends.sqlite import SQLiteBackend
    from flashq.worker import Worker
    
    tmp = tempfile.mktemp(suffix=".db")
    backend = SQLiteBackend(path=tmp)
    backend.setup()
    app = FlashQ(backend=backend)
    
    processed = []
    
    @app.task(name="validate_email")
    def validate_email(email: str) -> dict:
        assert "@" in email
        return {"email": email, "valid": True}
    
    @app.task(name="send_welcome")
    def send_welcome(email: str) -> str:
        processed.append(email)
        return f"Welcome email sent to {email}"
    
    emails = ["alice@test.com", "bob@test.com", "charlie@test.com"]
    handles = []
    for email in emails:
        handles.append(validate_email.delay(email=email))
        handles.append(send_welcome.delay(email=email))
    
    worker = Worker(app, poll_interval=0.05, concurrency=4, schedule_interval=0.3)
    t = threading.Thread(target=worker.start, daemon=True)
    t.start()
    time.sleep(3)
    worker.stop()
    t.join(timeout=5)
    
    for h in handles:
        result = backend.get_result(h.id)
        assert result is not None
        assert result.state == TaskState.SUCCESS
    
    assert len(processed) == 3
    backend.teardown()
    if os.path.exists(tmp):
        os.unlink(tmp)

@test("45. E2E — 50 task high-throughput")
def test_e2e_throughput():
    from flashq import FlashQ, TaskState
    from flashq.backends.sqlite import SQLiteBackend
    from flashq.worker import Worker
    
    tmp = tempfile.mktemp(suffix=".db")
    backend = SQLiteBackend(path=tmp)
    backend.setup()
    app = FlashQ(backend=backend)
    
    @app.task(name="compute")
    def compute(n: int) -> int:
        return n * n
    
    N = 50
    start = time.monotonic()
    handles = [compute.delay(n=i) for i in range(N)]
    enqueue_time = time.monotonic() - start
    
    worker = Worker(app, poll_interval=0.05, concurrency=8, schedule_interval=0.3)
    t = threading.Thread(target=worker.start, daemon=True)
    t.start()
    time.sleep(5)
    worker.stop()
    t.join(timeout=5)
    
    success = 0
    for i, h in enumerate(handles):
        result = backend.get_result(h.id)
        if result and result.state == TaskState.SUCCESS:
            assert result.result == i * i
            success += 1
    
    assert success == N, f"Only {success}/{N} tasks succeeded"
    backend.teardown()
    if os.path.exists(tmp):
        os.unlink(tmp)


# ═══════════════════════════════════════
# RUN ALL TESTS
# ═══════════════════════════════════════
if __name__ == "__main__":
    print()
    print("  ╔══════════════════════════════════════════════════════╗")
    print("  ║  FlashQ v0.2.1 — Clean Install Feature Test         ║")
    print(f"  ║  Python: {sys.version.split()[0]:<44}║")
    print("  ╚══════════════════════════════════════════════════════╝")
    print()
    
    all_tests = [
        test_import, test_version, test_public_api, test_canvas_imports,
        test_backend_import, test_worker_import, test_middleware_import,
        test_ratelimit_import, test_dlq_import, test_scheduler_import,
        test_serializers_import, test_exceptions_import,
        test_app_default, test_app_custom_name, test_app_sqlite_file,
        test_task_define, test_task_delay, test_task_apply, test_task_retry_params,
        test_task_priority,
        test_worker_basic, test_worker_multiple, test_worker_error, test_worker_retry,
        test_custom_middleware, test_logging_middleware,
        test_ratelimit_configure, test_token_bucket,
        test_dlq,
        test_scheduler_interval, test_scheduler_cron,
        test_signature, test_chain_create, test_group_create,
        test_json_serializer, test_pickle_serializer,
        test_cli_parser,
        test_demo_exists, test_dashboard_import,
        test_taskmessage, test_taskresult, test_taskstate, test_taskpriority,
        test_e2e_pipeline, test_e2e_throughput,
    ]
    
    for t in all_tests:
        t()
    
    passed = sum(1 for r in results if r["status"] == "PASS")
    failed = sum(1 for r in results if r["status"] == "FAIL")
    
    print()
    print(f"  ═══════════════════════════════════════════════════")
    print(f"  📊 RESULTS: {passed} passed, {failed} failed, {len(results)} total")
    print(f"  ═══════════════════════════════════════════════════")
    
    if failed > 0:
        print()
        print("  ❌ FAILURES:")
        for r in results:
            if r["status"] == "FAIL":
                print(f"     • {r['name']}: {r['error']}")
    
    print()
    
    # Save JSON results
    with open(os.path.join(os.path.dirname(__file__), "test_results.json"), "w") as f:
        json.dump({
            "python": sys.version,
            "flashq_version": "0.2.1",
            "results": results,
            "passed": passed,
            "failed": failed,
            "total": len(results)
        }, f, indent=2)
    
    sys.exit(1 if failed > 0 else 0)
