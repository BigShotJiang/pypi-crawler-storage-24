"""
FlashQ — En Basit Test
======================
Çalıştır: python test_benim.py
"""
import time
import threading
from flashq import FlashQ
from flashq.worker import Worker


# 1) FlashQ oluştur (SQLite, sıfır kurulum)
app = FlashQ()


# 2) Bir task tanımla
@app.task(name="topla")
def topla(a: int, b: int) -> int:
    print(f"  🔧 Hesaplıyorum: {a} + {b} = {a + b}")
    return a + b


@app.task(name="selamla")
def selamla(isim: str) -> str:
    print(f"  👋 Selam {isim}!")
    return f"Merhaba {isim}!"


# 3) Worker'ı arka planda başlat
worker = Worker(app, poll_interval=0.1, concurrency=2)
t = threading.Thread(target=worker.start, daemon=True)
t.start()
time.sleep(0.5)

print("\n📤 Task'ları gönderiyorum...\n")

# 4) Task gönder
h1 = topla.delay(a=3, b=5)
h2 = topla.delay(a=100, b=200)
h3 = selamla.delay(isim="Özden")

# 5) Sonuçları bekle
time.sleep(2)

print("\n📊 Sonuçlar:\n")
for h in [h1, h2, h3]:
    result = app.backend.get_result(h.id)
    if result:
        print(f"  ✅ {result.result}")
    else:
        print(f"  ⏳ Henüz bitmedi: {h.id[:8]}")

worker.stop()
print("\n🎉 Bitti!")
