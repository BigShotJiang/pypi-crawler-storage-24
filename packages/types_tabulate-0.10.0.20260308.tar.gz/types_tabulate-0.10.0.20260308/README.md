## Typing stubs for tabulate

This is a [type stub package](https://typing.python.org/en/latest/tutorials/external_libraries.html)
for the [`tabulate`](https://github.com/astanin/python-tabulate) package. It can be used by type checkers
to check code that uses `tabulate`. This version of
`types-tabulate` aims to provide accurate annotations for
`tabulate==0.10.*`.

This package is part of the [typeshed project](https://github.com/python/typeshed).
All fixes for types and metadata should be contributed there.
See [the README](https://github.com/python/typeshed/blob/main/README.md)
for more details. The source for this package can be found in the
[`stubs/tabulate`](https://github.com/python/typeshed/tree/main/stubs/tabulate)
directory.

This package was tested with the following type checkers:
* [mypy](https://github.com/python/mypy/) 1.19.1
* [pyright](https://github.com/microsoft/pyright) 1.1.408

It was generated from typeshed commit
[`3e9ca33422712b471f885a2b7dba08c023e6998e`](https://github.com/python/typeshed/commit/3e9ca33422712b471f885a2b7dba08c023e6998e).