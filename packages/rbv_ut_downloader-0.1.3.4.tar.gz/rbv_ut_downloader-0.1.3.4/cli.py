"""
cli.py — Input & setup flow for RBV Downloader.
Handles: course code, relogin flag, and SSO credential setup.
"""
import sys
import getpass
from utils.config import load_config, get_session_cookies, clear_session
from utils.auth_config import has_credentials, save_auth_config, get_credentials, clear_auth_config, UT_DOMAIN


def _setup_credentials():
    """
    Prompt for Student ID and password if not saved.
    Called once only — saved permanently afterwards.
    """
    print("\n" + "=" * 42)
    print("  UT SSO CREDENTIALS SETUP (Just once)")
    print("=" * 42)
    print("  These credentials are stored locally in ~/.rbv_auth.json")
    print("  to auto-login when session expires.")
    print("=" * 42)

    while True:
        nim = input("Student ID (ex: 057256579): ").strip()
        if nim:
            break
        print("[-] NIM cannot be empty.")

    email = nim if nim.upper().endswith(UT_DOMAIN) else f"{nim.upper()}{UT_DOMAIN}"
    print(f"[*] Email SSO: {email}")

    while True:
        password = getpass.getpass("UT SSO Password: ")
        if password:
            break
        print("[-] Password cannot be empty.")

    save_auth_config(nim, password)
    print("[+] Setup complete! Proceed to input course code.\n")


def get_user_input():
    """
    Get user input. Returns (kode_mk, force_relogin).
    If credentials do not exist, run the setup wizard first.
    """
    force_relogin = "--relogin" in sys.argv or "-r" in sys.argv
    reset_creds = "--reset-creds" in sys.argv

    # Reset credentials if requested
    if reset_creds:
        clear_auth_config()
        print("[*] Credentials deleted. You will be prompted to setup again.")

    # Reset session if requested
    if force_relogin:
        clear_session()
        print("[*] Relogin mode: old sessions are deleted.")

    # Setup credentials if they don't exist yet
    if not has_credentials():
        print("[*] SSO credentials are not saved.")
        _setup_credentials()

    # Display saved email
    email, _ = get_credentials()
    if email:
        print(f"[+] Login as: {email}")

    kode_mk = input("Course Code (ex: DAPU6209): ").strip().upper()

    has_session = bool(get_session_cookies())
    if not has_session:
        print("[*] There are no saved sessions yet.")
        print("[*] The SSO login window will appear shortly....")
    else:
        print("[+] Saved session found, skip login.")

    return kode_mk, force_relogin
