# 📕 RBV-DL — Module Downloader

<p align="center">
  <img src="square.png" alt="RBV-DL Logo" width="200">
</p>

<p align="center">
  <strong>Fast, asynchronous, and reliable module downloader for Universitas Terbuka (UT).</strong>
</p>

<p align="center">
  <a href="https://badge.fury.io/py/rbv-ut-downloader">
    <img src="https://img.shields.io/pypi/v/rbv-ut-downloader?style=for-the-badge&color=blue" alt="PyPI Version">
  </a>
  <a href="https://pypi.org/project/rbv-ut-downloader/">
    <img src="https://img.shields.io/pypi/pyversions/rbv-ut-downloader?style=for-the-badge" alt="Python Versions">
  </a>
  <a href="https://saweria.co/fyodordostoevsky">
    <img src="https://img.shields.io/badge/Support_Me-Saweria-ff8800?style=for-the-badge&logo=buymeacoffee&logoColor=white" alt="Support" />
  </a>
  <img src="https://img.shields.io/badge/License-MIT-green?style=for-the-badge" alt="License">
</p>

---

## 📖 About

**RBV-DL** is a lightweight, asynchronous Python-based tool designed to automate authentication, retrieve module metadata, and concurrently download pages to compile them into high-quality PDFs. 

With the introduction of the **Hybrid Auth Bridge**, RBV-DL now utilizes `PyQt6` and `QtWebEngine` for a robust, seamless experience. The background auto-login system synchronizes sessions effortlessly between the CLI and GUI without requiring manual user intervention.

## ✨ Key Features

- **Smart Session Sync:** CLI and GUI share the same authentication logic via the new `auth_bridge`.
- **Zero-Touch Login:** Automatic background SSO handling—just input your course code and let the tool do the rest.
- **Asynchronous Core:** Highly concurrent downloads ensuring maximum speed and efficiency.
- **Native GUI:** A sleek, responsive, and native-feeling graphical interface built with `PyQt6`.
- **Lightweight Footprint:** Efficient architecture without relying on heavy browser engines like Playwright.

---

## ⚙️ Prerequisites

To run **RBV-DL**, ensure your system meets the following requirements:

- **Python:** Version `3.9` or higher.
  - Download from the [official Python website](https://www.python.org/downloads/).
  - **Important:** During installation (especially on Windows), ensure the **"Add Python to PATH"** option is checked.

---

## 🚀 Installation

Installing **RBV-DL** is straightforward and universal.

Open your terminal or command prompt and execute:

```bash
pip install rbv-ut-downloader
```

> **Note for Linux Users:** We highly recommend using `pipx` for a cleaner, isolated environment:
> ```bash
> pipx install rbv-ut-downloader
> ```

---

## 💻 Usage

### Command-Line Interface (CLI)

To launch the CLI application, simply run:

```bash
rbv-dl
```

You will be prompted to provide:
1. **NIM / Email:** Your UT account email.
2. **Password:** Your E-Campus password (input is securely hidden).
3. **Course Code:** The target module code (e.g., `ADPU4433`).

The tool will autonomously handle authentication, download the pages concurrently, and generate a final PDF within a directory named after the course code.

### Graphical User Interface (GUI)

The new and improved GUI offers an intuitive, lightweight experience natively integrated into your OS. Simply launch the application via your application menu or command line, and follow the on-screen instructions for a seamless downloading process.

---

## 🛠️ Running from Source

If you wish to contribute or modify the tool locally:

**1. Clone the repository**
```bash
git clone https://codeberg.org/fyodor-dostoevsky-bit/rbv-dl.git
cd rbv-dl
```

**2. Set up a virtual environment**
```bash
python -m venv venv
# On Linux/macOS
source venv/bin/activate
# On Windows
venv\Scripts\activate
```

**3. Install dependencies**
```bash
pip install -r requirements.txt
```

**4. Run the application**
```bash
python app.py
```

---

## 🐛 Troubleshooting

| Issue | Solution |
| :--- | :--- |
| **`Command not found`** or **`rbv-dl is not recognized`** | Python is likely not correctly added to your system's PATH. Reinstall Python and ensure **"Add Python to PATH"** is selected during setup. |
| **`Login Failed`** | Verify your E-Campus password. Try logging in manually via the [official RBV website](https://pustaka.ut.ac.id/) to ensure your account is active and accessible. |

---

## ⚖️ Disclaimer

> **Educational Purposes Only**
> This tool was strictly developed for educational and archival purposes to help students back up their learning materials. The author shall not be held responsible for any misuse, policy violations, or unauthorized distribution of downloaded content. Please use it responsibly.
