import os
import shutil
import img2pdf
from utils.logger import Logger as log

class PDFProcessor:
    @staticmethod
    def compile_pdf(image_list, output_path):
        """Merge all images into one HD PDF."""
        if not image_list:
            log.log("Zonk. No images were downloaded successfully.", "error")
            return False
        
        try:
            log.log(f"Compiling {len(image_list)} images into PDF...", "info")
            with open(output_path, "wb") as f:
                f.write(img2pdf.convert(image_list))
            log.log(f"SUCCESS! File saved to: {output_path}", "success")
            return True
        except Exception as e:
            log.log(f"Failed to create PDF: {e}", "error")
            return False

    @staticmethod
    def cleanup(temp_dir):
        """Clean up the junk in the temp folder."""
        try:
            if os.path.exists(temp_dir):
                shutil.rmtree(temp_dir)
                log.log("Temp directory cleaned up.", "info")
        except Exception as e:
            log.log(f"Cleanup failed: {e}", "error")
