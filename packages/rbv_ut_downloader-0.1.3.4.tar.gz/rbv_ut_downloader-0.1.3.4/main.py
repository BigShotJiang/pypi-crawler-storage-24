"""
main.py — RBV Downloader v0.2.0 (Zero-Browser Engine)
Main orchestrator. Playwright has been completely removed.
"""
import asyncio
import os
from tqdm import tqdm

from utils import Logger as log, clear_screen, prepare_directories, collect_images_recursive
from utils.config import get_session_cookies, save_config, load_config
from utils.auth_config import get_credentials
from core import PDFProcessor, RBVDownloader
from core.network import AdaptiveRateLimiter
from core.auth_bridge import launch_sso_popup
from providers import get_provider
from utils.scraper import RBVScraper
import cli


def print_banner():
    clear_screen()
    print("==========================================")
    print("              RBV DOWNLOADER              ")
    print("==========================================")

class RBVEngine:
    def __init__(self):
        self.kode_mk: str = ""
        self.base_dir: str = ""
        self.temp_dir: str = ""
        self.cookies: dict = {}
        self.chapters: list = []

        cfg = load_config()
        self.concurrency: int = cfg.get("concurrency", 10)
        self.resolution: str = cfg.get("resolution", "800")

    # ------------------------------------------------------------------
    # AUTH
    # ------------------------------------------------------------------

    def _authenticate(self) -> bool:
        """
        Check for a saved session or open the SSO popup.
        Uses saved credentials to auto-fill the Microsoft login.
        Returns True if cookies are successfully obtained.
        """
        # Try saved session first
        saved = get_session_cookies()
        if saved:
            log.log("Saved session found, skipping login popup.", "info")
            self.cookies = saved
            return True

        # Retrieve saved credentials for auto-fill
        credentials = get_credentials()  # (email, password) or (None, None)

        # Open SSO popup — auto-fill if credentials exist
        log.log("Opening SSO login popup...", "info")
        cookies = launch_sso_popup(self.kode_mk, credentials=credentials)

        if not cookies:
            log.log("Login popup closed or timed out. Aborting.", "error")
            return False

        self.cookies = cookies

        # Save cookies for the next session
        save_config(cookies)
        log.log("Session successfully saved.", "success")
        return True

    # ------------------------------------------------------------------
    # DOWNLOAD
    # ------------------------------------------------------------------

    async def _download_chapter(self, session, downloader: RBVDownloader, bab: dict):
        """Download a single chapter with concurrent batching and resume support."""
        provider = get_provider()
        doc_id = bab["id"].replace(".pdf", "")
        subfolder = bab.get("subfolder", f"{self.kode_mk}/")

        log.log(f"Processing: {bab['label']} (ID: {doc_id})", "info")

        chapter_dir = os.path.join(self.temp_dir, doc_id)
        os.makedirs(chapter_dir, exist_ok=True)

        page_num = 1
        total_downloaded = 0
        
        limiter = AdaptiveRateLimiter(initial_concurrency=self.concurrency, max_concurrency=self.concurrency * 2)

        max_successful_page = 0
        next_page = 1
        max_empty_lookahead = max(10, self.concurrency)
        
        pending_tasks = set()

        async def fetch_page(p):
            page_url = provider.get_page_url(doc_id, subfolder, p, self.resolution)
            filename = os.path.join(chapter_dir, f"page_{p:03d}.jpg")
            ok = await downloader.download_page(session, page_url, filename, limiter=limiter)
            return p, ok

        with tqdm(desc=f"  {doc_id}", unit=" pg", leave=True) as pbar:
            limiter.pbar = pbar
            while True:
                target_lookahead = max_successful_page + max_empty_lookahead
                
                while next_page <= target_lookahead and len(pending_tasks) < limiter.max_concurrency * 2:
                    task = asyncio.create_task(fetch_page(next_page))
                    pending_tasks.add(task)
                    next_page += 1
                    
                if not pending_tasks:
                    break
                    
                done, pending = await asyncio.wait(pending_tasks, return_when=asyncio.FIRST_COMPLETED)
                pending_tasks = pending
                
                for task in done:
                    try:
                        p, ok = task.result()
                        if ok:
                            total_downloaded += 1
                            pbar.update(1)
                            if p > max_successful_page:
                                max_successful_page = p
                    except Exception as e:
                        pbar.write(f"[!] Error on page {p}: {str(e)}")
                        
                latency = getattr(limiter, 'last_latency', 0.0)
                pbar.set_postfix_str(f"Worker: {limiter.concurrency} | Latency: {latency:.1f}s")


            for task in pending_tasks:
                task.cancel()

    # ------------------------------------------------------------------
    # MAIN FLOW
    # ------------------------------------------------------------------

    async def start(self):
        print_banner()

        # 1. Input
        kode_mk, _force_relogin = cli.get_user_input()
        self.kode_mk = kode_mk
        self.base_dir, self.temp_dir = prepare_directories(self.kode_mk)

        # 2. Auth (popup if necessary)
        if not self._authenticate():
            return

        # 3. Scraping chapter list
        log.log("Fetching chapter list...", "info")
        provider = get_provider()
        scraper = RBVScraper(self.cookies, provider)
        self.chapters = await scraper.fetch_chapters(self.kode_mk)

        # Auto-relogin if no chapters found (session might have expired)
        if not self.chapters:
            log.log(
                "No chapters found — session may have expired.",
                "warn"
            )
            log.log("Deleting old session and reopening login...", "info")

            from utils.config import clear_session
            clear_session()
            self.cookies = {}

            # Automatically open re-login popup
            if not self._authenticate():
                log.log("Re-login failed or cancelled. Aborting.", "error")
                return

            # Attempt to scrape again with new cookies
            log.log("Attempting to fetch chapter list with new session...", "info")
            scraper = RBVScraper(self.cookies, provider)
            self.chapters = await scraper.fetch_chapters(self.kode_mk)

            if not self.chapters:
                log.log(
                    "Still no chapters found after re-login.\n"
                    "Please check the course code or access rights.",
                    "error"
                )
                return

        log.log(
            f"Found {len(self.chapters)} chapters. Starting download...",
            "success"
        )

        # 4. Download all chapters
        downloader = RBVDownloader(self.cookies)
        downloader.resolution = self.resolution

        async with downloader._make_session() as session:
            for bab in self.chapters:
                try:
                    await self._download_chapter(session, downloader, bab)
                except Exception as e:
                    log.log(f"Error on chapter {bab.get('label')}: {e}", "error")
                    continue

        # 5. Compile PDF
        log.log("Compiling final PDF...", "info")
        all_images = collect_images_recursive(self.temp_dir)
        output_pdf = os.path.join(self.base_dir, f"{self.kode_mk}-FullBook-HD.pdf")

        if PDFProcessor.compile_pdf(all_images, output_pdf):
            PDFProcessor.cleanup(self.temp_dir)


def main_entry():
    try:
        engine = RBVEngine()
        asyncio.run(engine.start())
    except KeyboardInterrupt:
        log.log("Download interrupted. .part files saved — can be resumed later.", "info")
    except Exception as e:
        log.log(f"Critical Error: {e}", "error")


if __name__ == "__main__":
    main_entry()
