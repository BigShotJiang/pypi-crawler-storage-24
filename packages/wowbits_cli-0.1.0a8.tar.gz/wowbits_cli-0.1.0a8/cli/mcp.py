#!/usr/bin/env python3
"""
WowBits CLI - MCP Commands

Handles MCP (Model Context Protocol) server create and run.
- create: Insert MCP config from mcp_configs.json into mcp_configs table
- run: Execute setup.py then run.py in WOWBITS_ROOT_DIR/mcps/<mcp_name>/
"""

import json
import os
import subprocess
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from db.schema import MCPConfig
from pylibs.database_manager import get_session_context

MCP_CONFIGS_FILENAME = "mcp_configs.json"


def get_mcps_dir() -> Optional[Path]:
    """Return WOWBITS_ROOT_DIR/mcps or None if WOWBITS_ROOT_DIR is not set."""
    root_dir = os.environ.get("WOWBITS_ROOT_DIR")
    if not root_dir:
        return None
    return Path(root_dir).expanduser().resolve() / "mcps"


def load_mcp_configs(mcps_dir: Path) -> List[Dict[str, Any]]:
    """Load mcps array from mcps_dir/mcp_configs.json."""
    config_path = mcps_dir / MCP_CONFIGS_FILENAME
    if not config_path.exists():
        raise FileNotFoundError(f"MCP config file not found: {config_path}")
    with open(config_path, "r") as f:
        data = json.load(f)
    mcps = data.get("mcps")
    if not isinstance(mcps, list):
        raise ValueError(f"{MCP_CONFIGS_FILENAME} must contain a 'mcps' array")
    return mcps


def create_mcp(mcp_name: str) -> None:
    """
    Create MCP by inserting config from mcp_configs.json into mcp_configs table.
    Looks up the MCP entry by name in WOWBITS_ROOT_DIR/mcps/mcp_configs.json.
    """
    mcps_dir = get_mcps_dir()
    if not mcps_dir:
        print("❌ Error: WOWBITS_ROOT_DIR environment variable is not set.")
        sys.exit(1)
    if not mcps_dir.is_dir():
        print(f"❌ Error: MCPs directory not found: {mcps_dir}")
        sys.exit(1)

    try:
        mcps = load_mcp_configs(mcps_dir)
    except FileNotFoundError as e:
        print(f"❌ {e}")
        sys.exit(1)
    except (json.JSONDecodeError, ValueError) as e:
        print(f"❌ Error reading {MCP_CONFIGS_FILENAME}: {e}")
        sys.exit(1)

    entry = None
    for m in mcps:
        if isinstance(m, dict) and m.get("name") == mcp_name:
            entry = m
            break
    if not entry:
        print(f"❌ Error: MCP '{mcp_name}' not found in {MCP_CONFIGS_FILENAME}")
        sys.exit(1)

    name = entry.get("name")
    url = entry.get("url")
    config = entry.get("config")
    if not name:
        print(f"❌ Error: MCP entry for '{mcp_name}' has no 'name' field")
        sys.exit(1)
    if config is None:
        config = {}

    try:
        with get_session_context() as session:
            existing = session.query(MCPConfig).filter(MCPConfig.name == name).first()
            if existing:
                print(f"⚠️  MCP '{name}' already exists in mcp_configs table (id: {existing.id})")
                return
            mcp = MCPConfig(name=name, url=url, config=config)
            session.add(mcp)
            session.flush()
        print(f"✅ MCP '{name}' created and added to mcp_configs table.")
    except Exception as e:
        print(f"❌ Error creating MCP: {e}")
        sys.exit(1)


def run_mcp(mcp_name: str) -> None:
    """
    Run MCP: execute setup.py then run.py in WOWBITS_ROOT_DIR/mcps/<mcp_name>/.
    """
    mcps_dir = get_mcps_dir()
    if not mcps_dir:
        print("❌ Error: WOWBITS_ROOT_DIR environment variable is not set.")
        sys.exit(1)
    mcp_dir = mcps_dir / mcp_name
    if not mcp_dir.is_dir():
        print(f"❌ Error: MCP directory not found: {mcp_dir}")
        sys.exit(1)

    setup_py = mcp_dir / "setup.py"
    run_py = mcp_dir / "run.py"
    if not setup_py.exists():
        print(f"❌ Error: setup.py not found in {mcp_dir}")
        sys.exit(1)
    if not run_py.exists():
        print(f"❌ Error: run.py not found in {mcp_dir}")
        sys.exit(1)

    env = os.environ.copy()
    cwd = str(mcp_dir)

    try:
        print(f"Running setup.py for MCP '{mcp_name}'...")
        subprocess.run(
            [sys.executable, str(setup_py)],
            cwd=cwd,
            env=env,
            check=True,
        )
        print(f"Running run.py for MCP '{mcp_name}'...")
        subprocess.run(
            [sys.executable, str(run_py)],
            cwd=cwd,
            env=env,
            check=True,
        )
    except subprocess.CalledProcessError as e:
        print(f"❌ MCP run failed with exit code {e.returncode}")
        sys.exit(e.returncode or 1)
