__version__ = '0.16.0'         
__author__ = 'pengyeqin'

def hello():
    print("Hello from ub-clean-test!")