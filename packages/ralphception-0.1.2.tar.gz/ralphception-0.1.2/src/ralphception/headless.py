"""Long-running headless mission supervisor."""

from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
from collections.abc import Mapping
from pathlib import Path
import subprocess
import time
from typing import Any, Literal, cast
import uuid

from pydantic import BaseModel, Field, field_validator

from ralphception.audit.service import AuditService
from ralphception.config import DEFAULT_CONFIG, RalphceptionConfig, load_config, write_config_atomically
from ralphception.git.merge import MergeCoordinator
from ralphception.git.identity import resolve_git_commit_identity
from ralphception.git.worktrees import (
    WorktreeAssignment,
    WorktreeCoordinator,
    WorktreeCreateFailed,
    read_worktree_assignment,
)
from ralphception.models.artifacts import ArtifactRef
from ralphception.models.commit_intents import CommitIntent
from ralphception.models.events import Event
from ralphception.models.mission import ExecutionPolicy
from ralphception.models.runtime import ChildAssignment, ExecutionBundle, Run
from ralphception.models.todos import TodoNode
from ralphception.models.verification import AuditFinding, VerificationScope
from ralphception.models.worktree import WorktreeHandoff
from ralphception.paths import config_path
from ralphception.storage.bootstrap import bootstrap_workspace
from ralphception.storage.events import EventStore
from ralphception.storage.files import write_json_atomic
from ralphception.storage.lease import acquire_workspace_lease, clear_workspace_lease
from ralphception.runtime.frontends import FrontendEvent, ReviewPrompt, StartupPrompt
from ralphception.ui.screens.startup import StartupBootstrapController, StartupRecord, load_startup_record
from ralphception.verification.service import VerificationService
from ralphception.workflow.approvals import (
    create_execution_bundle_approval,
    create_spec_review,
    persist_approval,
    read_approval,
)
from ralphception.workflow.bundles import (
    compute_scope_hash_for_artifacts,
    create_bundle,
    read_bundle,
    transition_bundle_state,
)

StageName = Literal["intake", "spec", "plan", "execute", "merge", "audit", "completed", "failed"]
ReviewTargetKind = Literal["spec_review", "execution_bundle", "recovery"]

_ROOT_RUN_ID = "run-root"
_STAGE_SEQUENCE: tuple[str, ...] = ("intake", "spec", "plan", "execute", "merge", "audit")
_CONTRACT_BEGIN = "HEADLESS_CONTRACT_START"
_CONTRACT_END = "HEADLESS_CONTRACT_END"
_SKILLS_DIR = Path(__file__).resolve().parent / "bundled_skills"
_PLACEHOLDER_TOKEN_RE = re.compile(r"<[A-Za-z][^>\n]*>")


class HeadlessState(BaseModel):
    current_stage: StageName = "intake"
    completed_stages: list[str] = Field(default_factory=list)
    stage_attempts: dict[str, int] = Field(default_factory=dict)
    current_child_run_id: str | None = None
    child_run_ids: list[str] = Field(default_factory=list)
    last_approved_bundle_version: int | None = None
    execution_goal: str | None = None
    pending_child_goal: str | None = None
    terminal_outcome: Literal["completed", "failed"] | None = None
    audit_reopened: bool = False


class PlanContract(BaseModel):
    execution_goal: str
    verification_commands: list[str] = Field(default_factory=list)
    todos: list[TodoNode] = Field(default_factory=list)
    commit_intents: list[CommitIntent] = Field(default_factory=list)
    execution_policy: ExecutionPolicy = Field(default_factory=ExecutionPolicy)

    @field_validator("execution_goal")
    @classmethod
    def _validate_goal(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("execution_goal must not be blank")
        return value

    @field_validator("verification_commands")
    @classmethod
    def _normalize_verification_commands(cls, value: list[str]) -> list[str]:
        normalized: list[str] = []
        for command in value:
            stripped = command.strip()
            if not stripped:
                continue
            if _PLACEHOLDER_TOKEN_RE.search(stripped):
                continue
            normalized.append(stripped)
        return normalized


class ExecuteArtifactContract(BaseModel):
    path: str
    kind: str = "code"

    @field_validator("path", "kind")
    @classmethod
    def _validate_non_blank(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("execute artifact fields must not be blank")
        return value


class ExecuteContract(BaseModel):
    summary: str
    artifacts: list[ExecuteArtifactContract] = Field(min_length=1)
    touched_paths: list[str] = Field(min_length=1)
    merge_readiness: Literal["ready", "needs_revision", "blocked"] = "ready"

    @field_validator("artifacts", mode="before")
    @classmethod
    def _normalize_artifacts(cls, value: Any) -> Any:
        if not isinstance(value, list):
            return value
        normalized: list[Any] = []
        for artifact in value:
            if isinstance(artifact, str):
                if _is_child_handoff_metadata_artifact(artifact):
                    continue
                kind = "metadata" if artifact.startswith(".ralphception/") else "code"
                normalized.append({"path": artifact, "kind": kind})
            else:
                if isinstance(artifact, Mapping) and _is_child_handoff_metadata_artifact(str(artifact.get("path", ""))):
                    continue
                normalized.append(artifact)
        return normalized

    @field_validator("touched_paths", mode="before")
    @classmethod
    def _normalize_touched_paths(cls, value: Any) -> Any:
        if not isinstance(value, list):
            return value
        return [
            path
            for path in value
            if isinstance(path, str) and not _is_child_handoff_metadata_artifact(path)
        ]

    @field_validator("merge_readiness", mode="before")
    @classmethod
    def _normalize_merge_readiness(cls, value: Any) -> Any:
        if isinstance(value, str):
            return value
        if not isinstance(value, Mapping):
            return value
        status = value.get("status")
        if isinstance(status, str):
            return status
        if value.get("blocked") is True:
            return "blocked"
        ready = value.get("ready")
        if isinstance(ready, bool):
            return "ready" if ready else "needs_revision"
        return value


class AuditFindingContract(BaseModel):
    finding_id: str
    severity: Literal["P0", "P1", "P2", "P3"]
    kind: Literal["bug", "test_gap", "feature_gap", "spec_drift", "integration_risk"]
    title: str
    status: Literal["open", "accepted", "resolved", "wontfix"] = "open"
    evidence_paths: list[str] = Field(default_factory=list)


class AuditContract(BaseModel):
    findings: list[AuditFindingContract] = Field(default_factory=list)


class HeadlessRunResult(BaseModel):
    mode: Literal["startup", "review", "dashboard", "completed", "failed"]
    actions: tuple[str, ...]
    review_target_kind: ReviewTargetKind | None = None
    root_run_id: str | None = None
    root_run_status: str | None = None
    authoritative_repo_root: str | None = None
    child_run_ids: tuple[str, ...] = ()
    completed_stages: tuple[str, ...] = ()
    current_stage: StageName | None = None
    audit_reopened: bool = False
    engine: object | None = None


def run_headless_mission(
    *,
    repo_root: Path | None = None,
    seed_prompt: str | None = None,
    source_repos: tuple[str, ...] = (),
    approve_all: bool = False,
    approver: str = "headless",
    session_manager_factory=None,
) -> HeadlessRunResult:
    resolved_repo_root = Path.cwd() if repo_root is None else repo_root
    supervisor = HeadlessMissionSupervisor(
        repo_root=resolved_repo_root,
        primary_repo_root=resolved_repo_root,
        seed_prompt=seed_prompt,
        source_repos=source_repos,
        approve_all=approve_all,
        approver=approver,
        session_manager_factory=session_manager_factory,
    )
    return supervisor.run()


class HeadlessMissionSupervisor:
    def __init__(
        self,
        *,
        repo_root: Path,
        primary_repo_root: Path,
        seed_prompt: str | None,
        source_repos: tuple[str, ...],
        approve_all: bool,
        approver: str,
        session_manager_factory,
        announce_resume: bool = True,
    ) -> None:
        self.primary_repo_root = bootstrap_workspace(primary_repo_root)
        self.repo_root = bootstrap_workspace(repo_root)
        self.seed_prompt = seed_prompt
        self.source_repos = source_repos
        self.approve_all = approve_all
        self.approver = approver
        self.announce_resume = announce_resume
        _ensure_runtime_paths_excluded(self.repo_root)
        self.target_branch: str | None = None
        self.config = _load_or_create_config(self.repo_root)
        self.session_manager = None if session_manager_factory is None else session_manager_factory(
            self.repo_root,
            self.config,
        )
        self.event_store = EventStore(self.repo_root)
        self.actions: list[str] = []
        self._frontend = None
        self._last_announced_stage: StageName | None = None
        self._agent_message_chunks: dict[str, list[str]] = {}
        self.startup_record = load_startup_record(self.repo_root)
        self.root_run = self._ensure_root_run() if self.startup_record is not None else None
        self.state = self._load_state() if self.root_run is not None else HeadlessState()
        if self.root_run is not None:
            self._hydrate_state_from_workspace()

    def run(self, *, frontend=None) -> HeadlessRunResult:
        self._frontend = frontend
        if self.startup_record is None:
            if self.seed_prompt is None or not self.seed_prompt.strip():
                if frontend is None:
                    return self._result(mode="startup")
                decision = frontend.prompt_startup(StartupPrompt(repo_root=self.repo_root))
                self.seed_prompt = decision.seed_prompt
                self.source_repos = decision.source_repos
            self.startup_record = self._ensure_startup_record()
            self.root_run = self._ensure_root_run()
            self.state = self._load_state()
            self._hydrate_state_from_workspace()
            if frontend is not None:
                frontend.emit_event(FrontendEvent(message=f"Bootstrapped {self.startup_record.outer_run_id}"))
        elif frontend is not None and self.root_run is not None and self.announce_resume:
            frontend.emit_event(FrontendEvent(message=f"Resumed {self.root_run.run_id}"))

        if self.root_run is None:
            raise RuntimeError("root run is required after bootstrap")

        if self.state.terminal_outcome == "completed":
            self.root_run = self._update_run(self.root_run, status="completed")
            self._cleanup_completed_runtime_state()
            return self._result(mode="completed")
        if self.state.terminal_outcome == "failed":
            self.root_run = self._update_run(self.root_run, status="failed")
            return self._result(mode="failed")

        self._persist_state()
        if self.session_manager is None:
            return self._result(mode="dashboard")

        self._ensure_run_session(self.root_run, workspace_path=self.repo_root)

        try:
            while self.state.terminal_outcome is None:
                if self.state.current_stage == "intake":
                    self._mark_stage_complete("intake", next_stage="spec")
                    continue
                if self.state.current_stage == "spec":
                    self._announce_stage("spec")
                    review_result = self._run_spec_stage(frontend=frontend)
                    if review_result is not None:
                        return review_result
                    continue
                if self.state.current_stage == "plan":
                    self._announce_stage("plan")
                    review_result = self._run_plan_stage(frontend=frontend)
                    if review_result is not None:
                        return review_result
                    continue
                if self.state.current_stage == "execute":
                    self._announce_stage("execute")
                    if not self._run_execute_stage():
                        return self._result(mode="failed")
                    continue
                if self.state.current_stage == "merge":
                    self._announce_stage("merge")
                    self._run_merge_stage()
                    continue
                if self.state.current_stage == "audit":
                    self._announce_stage("audit")
                    self._run_audit_stage()
                    continue
                if self.state.current_stage == "completed":
                    self._emit_frontend_event(f"Mission completed: {self.root_run.run_id}")
                    self.state.terminal_outcome = "completed"
                    self.root_run = self._update_run(self.root_run, status="completed")
                    self._persist_state()
                    self._cleanup_completed_runtime_state()
                    return self._result(mode="completed")
                raise RuntimeError(f"unsupported headless stage: {self.state.current_stage}")
        except Exception:
            self.state.current_stage = "failed"
            self.state.terminal_outcome = "failed"
            self.root_run = self._update_run(self.root_run, status="failed")
            self._persist_state()
            raise

        if self.state.terminal_outcome == "completed":
            self._cleanup_completed_runtime_state()
            return self._result(mode="completed")
        if self.state.terminal_outcome == "failed":
            return self._result(mode="failed")
        return self._result(mode="completed")

    def _run_spec_stage(self, *, frontend=None) -> HeadlessRunResult | None:
        root_run = self._require_root_run()
        startup_record = self._require_startup_record()
        spec_path = _preferred_artifact_path(
            self.repo_root / ".ralphception" / "specs",
            preferred_name="mission-spec.md",
        )
        if not spec_path.exists():
            self._run_turn(
                run_id=root_run.run_id,
                goal=root_run.goal,
                workspace_path=self.repo_root,
                stage_kind="spec",
                prompt=self._build_spec_prompt(spec_path),
            )
        spec_ref = _artifact_ref_for_file(self.repo_root, spec_path.relative_to(self.repo_root), "spec")
        if not self._has_spec_review_approval():
            if not self.approve_all and frontend is None:
                self._persist_state()
                return self._result(mode="review", review_target_kind="spec_review")
            resolved_approver = self.approver
            if not self.approve_all and frontend is not None:
                decision = frontend.prompt_review(
                    ReviewPrompt(
                        review_kind="spec_review",
                        run_id=root_run.run_id,
                        summary_text=f"Spec review pending for {spec_ref.artifact_path}",
                        recommended_actions=("approve",),
                    )
                )
                if decision.action == "pause":
                    self._persist_state()
                    return self._result(mode="review", review_target_kind="spec_review")
                if decision.action != "approve":
                    raise RuntimeError(f"unsupported spec review action: {decision.action}")
                if decision.approver is not None:
                    resolved_approver = decision.approver
            approval = create_spec_review(
                approval_id="approval-spec-1",
                run_id=root_run.run_id,
                approver=resolved_approver,
                spec_artifacts=[spec_ref],
                bundle_version=1,
                scope_hash=compute_scope_hash_for_artifacts(self.repo_root, [spec_ref]),
            )
            persist_approval(self.repo_root, approval)
            self.actions.append("approved:spec_review")
            self._emit_frontend_event("Approved: spec_review")
        self.root_run = self._update_run(
            root_run,
            artifact_refs=[startup_record.intake_artifact, spec_ref],
        )
        self._mark_stage_complete("spec", next_stage="plan")
        return None

    def _run_plan_stage(self, *, frontend=None) -> HeadlessRunResult | None:
        from ralphception.actor_runtime.planner_actor import PlannerActor

        root_run = self._require_root_run()
        startup_record = self._require_startup_record()
        plan_path = _preferred_artifact_path(
            self.repo_root / ".ralphception" / "plans",
            preferred_name="mission-plan.md",
        )
        plan_contract_path = self.repo_root / ".ralphception" / "plans" / "mission-plan.json"
        if not plan_path.exists():
            self._run_turn(
                run_id=root_run.run_id,
                goal=root_run.goal,
                workspace_path=self.repo_root,
                stage_kind="plan",
                prompt=self._build_plan_prompt(plan_path, plan_contract_path),
            )
        plan_ref = _artifact_ref_for_file(self.repo_root, plan_path.relative_to(self.repo_root), "plan")
        bundle = self._ensure_execution_bundle(plan_ref)
        if bundle.state != "approved":
            if not self.approve_all and frontend is None:
                self._persist_state()
                return self._result(mode="review", review_target_kind="execution_bundle")
            resolved_approver = self.approver
            if not self.approve_all and frontend is not None:
                decision = frontend.prompt_review(
                    ReviewPrompt(
                        review_kind="execution_bundle",
                        run_id=bundle.run_id,
                        summary_text=f"Execution bundle {bundle.bundle_id} is waiting for approval.",
                        recommended_actions=("approve",),
                    )
                )
                if decision.action == "pause":
                    self._persist_state()
                    return self._result(mode="review", review_target_kind="execution_bundle")
                if decision.action != "approve":
                    raise RuntimeError(f"unsupported execution bundle action: {decision.action}")
                if decision.approver is not None:
                    resolved_approver = decision.approver
            bundle = transition_bundle_state(
                self.repo_root,
                bundle=bundle,
                next_state="approved",
                stage_id="stage-plan",
            )
            if not self._has_execution_bundle_approval(bundle.bundle_version):
                approval = create_execution_bundle_approval(
                    approval_id=f"approval-exec-{bundle.bundle_version}",
                    approver=resolved_approver,
                    bundle=bundle,
                )
                persist_approval(self.repo_root, approval)
            self.actions.append("approved:execution_bundle")
            self._emit_frontend_event("Approved: execution_bundle")

        plan_contract = _load_plan_contract(plan_contract_path, default_goal=self._default_execution_goal(bundle))
        PlannerActor(repo_root=self.repo_root).plan(
            approved_spec_path=self.repo_root / ".ralphception" / "specs" / "mission-spec.md",
        )
        self.state.execution_goal = plan_contract.execution_goal
        self.state.last_approved_bundle_version = bundle.bundle_version
        intake_ref = _artifact_ref_for_file(
            self.repo_root,
            Path(startup_record.intake_artifact.artifact_path),
            "intake",
        )
        self.root_run = self._update_run(root_run, artifact_refs=[intake_ref, plan_ref])
        self._mark_stage_complete("plan", next_stage="execute")
        return None

    def _run_execute_stage(self) -> bool:
        bundle = self._latest_bundle()
        if bundle is None or bundle.state != "approved":
            raise RuntimeError("execute stage requires an approved execution bundle")
        plan_contract = _load_plan_contract(
            self.repo_root / ".ralphception" / "plans" / "mission-plan.json",
            default_goal=self._default_execution_goal(bundle),
        )
        try:
            child_run = self._ensure_child_run(bundle, plan_contract)
        except WorktreeCreateFailed:
            failed_run = self._current_child_run()
            if failed_run is None:
                raise
            self._emit_frontend_event(f"Worktree setup failed: {failed_run.run_id} execute")
            self._fail_child_run(
                failed_run,
                stage_id="stage-execute",
                reason="worktree_create_failed",
                before_orchestration=True,
            )
            return False
        assignment = read_worktree_assignment(self.repo_root, child_run.run_id)
        self._run_turn(
            run_id=child_run.run_id,
            goal=child_run.goal,
            workspace_path=assignment.worktree_path,
            stage_kind="execute",
            prompt=self._build_execute_prompt(
                run_id=child_run.run_id,
                goal=child_run.goal,
                handoff_path=assignment.worktree_path / ".ralphception" / "runs" / child_run.run_id / "handoff.json",
            ),
        )

        local_handoff_path = assignment.worktree_path / ".ralphception" / "runs" / child_run.run_id / "handoff.json"
        contract = ExecuteContract.model_validate_json(local_handoff_path.read_text(encoding="utf-8"))
        self._commit_child_changes(
            worktree_path=assignment.worktree_path,
            run_id=child_run.run_id,
            touched_paths=contract.touched_paths,
        )
        verification_refs, verification_summary, passed = self._run_verification(
            run_id=child_run.run_id,
            stage_id="stage-execute",
            scope="child_run",
            cwd=assignment.worktree_path,
            commands=plan_contract.verification_commands or _default_verification_commands(self.repo_root),
        )
        if not passed:
            self._fail_child_run(
                child_run,
                stage_id="stage-execute",
                reason="verification_failed",
                artifact_refs=verification_refs,
            )
            return False

        artifact_refs = [
            _artifact_ref_for_file(self.repo_root, Path(artifact.path), artifact.kind, root=assignment.worktree_path)
            for artifact in contract.artifacts
        ]
        normalized_handoff = WorktreeHandoff(
            child_run_id=child_run.run_id,
            worktree_path=str(assignment.worktree_path),
            branch_name=assignment.branch_name or assignment.target_branch,
            base_branch=assignment.base_ref,
            head_commit=_git_output(assignment.worktree_path, "rev-parse", "HEAD"),
            goal=child_run.goal,
            artifact_refs=artifact_refs,
            verification_artifact_refs=[],
            consumed_bundle_version=bundle.bundle_version,
            touched_paths=contract.touched_paths,
            verification_summary=verification_summary,
            merge_readiness=contract.merge_readiness,
            cleanup_state="pending",
        )
        root_handoff_path = self.repo_root / ".ralphception" / "runs" / child_run.run_id / "handoff.json"
        write_json_atomic(root_handoff_path, normalized_handoff.model_dump(mode="json"))
        child_run = self._update_run(
            child_run,
            status="completed",
            artifact_refs=[*artifact_refs, *verification_refs],
        )
        self._persist_run(child_run)
        self._mark_stage_complete("execute", next_stage="merge")
        return True

    def _run_merge_stage(self) -> None:
        root_run = self._require_root_run()
        child_run_id = self.state.current_child_run_id
        if child_run_id is None:
            raise RuntimeError("merge stage requires an active child run")
        acquire_workspace_lease(
            self.repo_root,
            run_id=root_run.run_id,
            process_id=os.getpid(),
            authoritative_repository_root=self.repo_root,
        )
        bundle = self._latest_bundle()
        if bundle is None:
            raise RuntimeError("merge stage requires a bundle")
        handoff_path = self.repo_root / ".ralphception" / "runs" / child_run_id / "handoff.json"
        handoff = WorktreeHandoff.model_validate_json(handoff_path.read_text(encoding="utf-8"))
        plan_contract = _load_plan_contract(
            self.repo_root / ".ralphception" / "plans" / "mission-plan.json",
            default_goal=self._default_execution_goal(bundle),
        )
        coordinator = MergeCoordinator(
            repo_root=self.repo_root,
            run_id=root_run.run_id,
            stage_id="stage-merge",
            target_branch=self._resolve_target_branch(),
        )
        outcome = coordinator.finalize_merge(
            handoff=handoff,
            latest_bundle=bundle,
            latest_goal=handoff.goal,
            dependency_refs=[],
            newest_required_verification_passed=True,
            run_merge_verification=lambda integration_path: self._run_merge_verification(
                run_id=child_run_id,
                cwd=integration_path,
                commands=plan_contract.verification_commands or _default_verification_commands(self.repo_root),
            ),
        )
        if outcome.status != "merged":
            raise RuntimeError("; ".join(outcome.reasons))
        if outcome.recovery is not None and outcome.recovery.lease_updated:
            self._rebind_repo_root(outcome.integration_worktree_path)
        try:
            WorktreeCoordinator(repo_root=self.repo_root).cleanup_worktree(
                run_id=root_run.run_id,
                worktree_path=outcome.integration_worktree_path,
                retain=False,
            )
        except Exception:
            pass
        self.actions.append(f"merged:{child_run_id}")
        self._emit_frontend_event(f"Merged: {child_run_id}")
        self._mark_stage_complete("merge", next_stage="audit")

    def _run_audit_stage(self) -> None:
        root_run = self._require_root_run()
        audit_path = self.repo_root / ".ralphception" / "runs" / root_run.run_id / "audit-findings.json"
        self._run_turn(
            run_id=root_run.run_id,
            goal=root_run.goal,
            workspace_path=self.repo_root,
            stage_kind="audit",
            prompt=self._build_audit_prompt(audit_path),
        )
        contract = AuditContract.model_validate_json(audit_path.read_text(encoding="utf-8"))
        findings = self._persist_audit_contract(contract)
        if AuditService(self.repo_root).blocks_completion(findings):
            titles = ", ".join(finding.title for finding in findings if finding.status == "open")
            replacement_run_id = _next_replacement_run_id(self.state.current_child_run_id or "run-child-1")
            self.state.audit_reopened = True
            self.state.current_child_run_id = replacement_run_id
            if replacement_run_id not in self.state.child_run_ids:
                self.state.child_run_ids.append(replacement_run_id)
            self.state.pending_child_goal = f"Resolve blocking audit findings: {titles}."
            self.state.current_stage = "execute"
            self._append_headless_event(
                run_id=root_run.run_id,
                stage_id="stage-audit",
                event_type="stage.custom_headless_audit_reopened",
                payload={
                    "stage_kind": "audit",
                    "replacement_run_id": replacement_run_id,
                    "findings": [finding.finding_id for finding in findings if finding.status == "open"],
                },
            )
            self.actions.append("reopened:audit")
            self._emit_frontend_event(f"Audit reopened execution with {replacement_run_id}")
            self._persist_state()
            return

        self._mark_stage_complete("audit", next_stage="completed")
        self.state.terminal_outcome = "completed"
        self.state.current_stage = "completed"
        self.root_run = self._update_run(root_run, status="completed")
        self._emit_frontend_event(f"Mission completed: {root_run.run_id}")
        self._persist_state()

    def _ensure_startup_record(self) -> StartupRecord:
        controller = StartupBootstrapController(self.repo_root)
        if not controller.needs_bootstrap():
            record = load_startup_record(self.repo_root)
            if record is None:
                raise RuntimeError("workspace bootstrap state is missing")
            return record
        if self.seed_prompt is None or not self.seed_prompt.strip():
            raise RuntimeError("seed_prompt is required when workspace needs bootstrap")
        record = controller.start_first_run(
            seed_prompt=self.seed_prompt,
            source_repos=self.source_repos,
        )
        self.actions.append(f"bootstrapped:{record.outer_run_id}")
        return record

    def _ensure_root_run(self) -> Run:
        if self.startup_record is None:
            raise RuntimeError("workspace bootstrap state is missing")
        run_path = self.repo_root / ".ralphception" / "runs" / _ROOT_RUN_ID / "run.json"
        if run_path.exists():
            return Run.model_validate_json(run_path.read_text(encoding="utf-8"))
        run = Run(
            run_id=_ROOT_RUN_ID,
            parent_run_id=None,
            supersedes_run_id=None,
            goal=self.startup_record.seed_prompt,
            status="pending",
            stage_ids=[f"stage-{stage}" for stage in _STAGE_SEQUENCE],
            config_snapshot={
                "codex": {"model": self.config.codex.model},
                "source_repos": self.startup_record.source_repos,
            },
            codex_session_ref=None,
            artifact_refs=[self.startup_record.intake_artifact],
            created_at=self.startup_record.created_at,
            updated_at=self.startup_record.created_at,
        )
        self._persist_run(run)
        return run

    def _load_state(self) -> HeadlessState:
        if self.root_run is None:
            return HeadlessState()
        path = self.repo_root / ".ralphception" / "runs" / self.root_run.run_id / "headless-state.json"
        if not path.exists():
            return HeadlessState()
        return HeadlessState.model_validate_json(path.read_text(encoding="utf-8"))

    def _hydrate_state_from_workspace(self) -> None:
        root_run = self._require_root_run()
        if "intake" not in self.state.completed_stages and load_startup_record(self.repo_root) is not None:
            self.state.completed_stages.append("intake")
            self.state.current_stage = "spec"
        spec_path = self.repo_root / ".ralphception" / "specs" / "mission-spec.md"
        if not spec_path.exists():
            spec_path = _preferred_artifact_path(
                self.repo_root / ".ralphception" / "specs",
                preferred_name="mission-spec.md",
            )
        if spec_path.exists() and self._has_spec_review_approval():
            self._ensure_completed_stage("spec")
            if self.state.current_stage == "spec":
                self.state.current_stage = "plan"
        bundle = self._latest_bundle()
        plan_path = _preferred_artifact_path(
            self.repo_root / ".ralphception" / "plans",
            preferred_name="mission-plan.md",
        )
        if plan_path.exists() and bundle is not None and bundle.state == "approved":
            self._ensure_completed_stage("plan")
            self.state.last_approved_bundle_version = bundle.bundle_version
            if self.state.current_stage == "plan":
                self.state.current_stage = "execute"
        for path in sorted((self.repo_root / ".ralphception" / "runs").glob("*/run.json")):
            if path.parent.name == root_run.run_id:
                continue
            run = Run.model_validate_json(path.read_text(encoding="utf-8"))
            if run.run_id not in self.state.child_run_ids:
                self.state.child_run_ids.append(run.run_id)

    def _ensure_execution_bundle(self, plan_ref: ArtifactRef) -> ExecutionBundle:
        root_run = self._require_root_run()
        existing = self._latest_bundle()
        if existing is not None:
            return existing
        spec_ref = _artifact_ref_for_file(
            self.repo_root,
            Path(".ralphception/specs/mission-spec.md"),
            "spec",
        )
        return create_bundle(
            self.repo_root,
            bundle_id="bundle-2",
            run_id=root_run.run_id,
            bundle_version=2,
            state="awaiting_approval",
            artifact_refs=[spec_ref, plan_ref],
            stage_id="stage-plan",
        )

    def _ensure_child_run(self, bundle: ExecutionBundle, plan_contract: PlanContract) -> Run:
        root_run = self._require_root_run()
        if self.state.current_child_run_id is None:
            next_run_id = "run-child-1" if not self.state.child_run_ids else self.state.child_run_ids[-1]
            if next_run_id in self.state.child_run_ids:
                next_run_id = _next_replacement_run_id(next_run_id)
            self.state.current_child_run_id = next_run_id
            if next_run_id not in self.state.child_run_ids:
                self.state.child_run_ids.append(next_run_id)

        run_id = self.state.current_child_run_id
        run_path = self.repo_root / ".ralphception" / "runs" / run_id / "run.json"
        if run_path.exists():
            existing = Run.model_validate_json(run_path.read_text(encoding="utf-8"))
            assignment_path = self.repo_root / ".ralphception" / "runs" / run_id / "worktree.json"
            if assignment_path.exists():
                return existing
            return self._materialize_child_run(
                child_run=existing,
                bundle=bundle,
                plan_contract=plan_contract,
                goal=existing.goal,
                root_run=root_run,
                announce_created=False,
            )

        goal = self.state.pending_child_goal or self.state.execution_goal or plan_contract.execution_goal
        child_run = Run(
            run_id=run_id,
            parent_run_id=root_run.run_id,
            supersedes_run_id=_superseded_run_id(run_id),
            goal=goal,
            status="pending",
            stage_ids=["stage-execute"],
            config_snapshot=root_run.config_snapshot,
            codex_session_ref=None,
            artifact_refs=list(bundle.artifact_refs),
            created_at=_utc_now(),
            updated_at=_utc_now(),
        )
        self._persist_run(child_run)
        return self._materialize_child_run(
            child_run=child_run,
            bundle=bundle,
            plan_contract=plan_contract,
            goal=goal,
            root_run=root_run,
            announce_created=True,
        )

    def _materialize_child_run(
        self,
        *,
        child_run: Run,
        bundle: ExecutionBundle,
        plan_contract: PlanContract,
        goal: str,
        root_run: Run,
        announce_created: bool,
    ) -> Run:
        worktrees = WorktreeCoordinator(repo_root=self.repo_root)
        created = worktrees.create_child_worktree(
            run_id=child_run.run_id,
            base_ref=self._resolve_target_branch(),
            target_branch=child_run.run_id,
            goal=goal,
        )
        session_ref = self._start_run_session(
            run_id=child_run.run_id,
            goal=goal,
            parent_run_id=root_run.run_id,
            workspace_path=created.worktree_path,
        )
        child_run = self._update_run(
            child_run,
            status="running",
            codex_session_ref=session_ref,
            artifact_refs=list(child_run.artifact_refs or bundle.artifact_refs),
        )
        final_commit_message = _resolve_child_final_commit_message(goal=goal, plan_contract=plan_contract)
        assignment = ChildAssignment(
            assignment_id=f"assignment-{child_run.run_id}",
            goal=goal,
            acceptance_criteria_refs=[],
            dependency_refs=list(child_run.artifact_refs or bundle.artifact_refs),
            bundle_version=bundle.bundle_version,
            final_commit_message=final_commit_message,
        )
        write_json_atomic(
            self.repo_root / ".ralphception" / "runs" / child_run.run_id / "assignment.json",
            assignment.model_dump(mode="json"),
        )
        self.state.pending_child_goal = None
        if announce_created:
            self._emit_frontend_event(f"Child run created: {child_run.run_id}")
        self._persist_state()
        return child_run

    def _persist_audit_contract(self, contract: AuditContract) -> list[AuditFinding]:
        root_run = self._require_root_run()
        service = AuditService(self.repo_root)
        findings_dir = self.repo_root / ".ralphception" / "findings"
        existing: dict[str, AuditFinding] = {}
        for path in sorted(findings_dir.glob("*.json")):
            finding = AuditFinding.model_validate_json(path.read_text(encoding="utf-8"))
            existing[finding.finding_id] = finding

        resolved: list[AuditFinding] = []
        current_ids: set[str] = set()
        for finding_contract in contract.findings:
            current_ids.add(finding_contract.finding_id)
            previous = existing.get(finding_contract.finding_id)
            evidence_refs = [
                _artifact_ref_for_file(self.repo_root, Path(path), "audit_evidence")
                for path in finding_contract.evidence_paths
                if (self.repo_root / path).exists()
            ]
            finding = AuditFinding(
                finding_id=finding_contract.finding_id,
                run_id=root_run.run_id,
                severity=finding_contract.severity,
                kind=finding_contract.kind,
                title=finding_contract.title,
                evidence_refs=evidence_refs,
                status=finding_contract.status,
                created_at=previous.created_at if previous is not None else _utc_now(),
                resolved_at=None if finding_contract.status == "open" else _utc_now(),
            )
            resolved.append(service.persist_finding(finding, stage_id="stage-audit"))

        for finding_id, finding in existing.items():
            if finding.status != "open" or finding_id in current_ids:
                if finding_id not in current_ids:
                    resolved.append(finding)
                continue
            resolved.append(
                service.transition_finding_status(
                    finding,
                    new_status="resolved",
                    actor="autonomous",
                    stage_id="stage-audit",
                    supported_by_merge=True,
                ),
            )
        return resolved

    def _run_verification(
        self,
        *,
        run_id: str,
        stage_id: str,
        scope: VerificationScope,
        cwd: Path,
        commands: list[str],
    ) -> tuple[list[ArtifactRef], str, bool]:
        service = VerificationService(self.repo_root)
        verification_id = f"{run_id}-{scope}-{self.state.stage_attempts.get(stage_id.replace('stage-', ''), 1)}"
        bundle = service.create_task_bundle(
            verification_id=verification_id,
            run_id=run_id,
            stage_id=stage_id,
            task_id=f"task-{verification_id}",
            requested_by="headless",
            scope=scope,
            active_bundle_exact_commands=commands,
        )
        started_at = _utc_now()
        command_results = [_run_verification_command(service, verification_id, index, command, cwd, self.config) for index, command in enumerate(bundle.spec.commands, start=1)]
        completed_at = _utc_now()
        persisted = service.persist_result(
            stage_id=stage_id,
            spec=bundle.spec,
            command_results=command_results,
            started_at=started_at,
            completed_at=completed_at,
        )
        stage_kind = stage_id.removeprefix("stage-")
        self._emit_frontend_event(
            f"Verification {persisted.result.status}: {run_id} {stage_kind}",
        )
        return [persisted.result_ref], persisted.result.status, persisted.result.status == "passed"

    def _run_merge_verification(self, *, run_id: str, cwd: Path, commands: list[str]) -> bool:
        _, _, passed = self._run_verification(
            run_id=f"{run_id}-merge",
            stage_id="stage-merge",
            scope="merge",
            cwd=cwd,
            commands=commands,
        )
        return passed

    def _run_turn(
        self,
        *,
        run_id: str,
        goal: str,
        workspace_path: Path,
        stage_kind: Literal["spec", "plan", "execute", "audit"],
        prompt: str,
    ) -> None:
        self.state.stage_attempts[stage_kind] = self.state.stage_attempts.get(stage_kind, 0) + 1
        self.state.current_stage = stage_kind
        self._persist_state()
        task_id = f"task-{stage_kind}-{self.state.stage_attempts[stage_kind]}"
        self._emit_frontend_event(
            f"Turn started: {run_id} {stage_kind} attempt {self.state.stage_attempts[stage_kind]}",
        )
        self._append_headless_event(
            run_id=run_id,
            stage_id=f"stage-{stage_kind}",
            event_type="stage.started",
            payload={"stage_kind": stage_kind, "attempt": self.state.stage_attempts[stage_kind]},
        )
        self._ensure_run_session(self._load_run(run_id), workspace_path=workspace_path)
        run_turn = getattr(self.session_manager, "run_turn", None)
        iter_raw_events = getattr(self.session_manager, "iter_raw_events", None)
        stream_raw_events = getattr(self.session_manager, "stream_raw_events", None)
        normalize_event = getattr(self.session_manager, "normalize_event", None)
        if not callable(run_turn) or not callable(normalize_event):
            raise RuntimeError("session manager does not support headless turn execution")
        run_turn(run_id=run_id, input_text=prompt)
        if callable(iter_raw_events):
            raw_events = iter_raw_events(run_id=run_id, until_methods={"turn/completed", "error"})
        elif callable(stream_raw_events):
            raw_events = stream_raw_events(run_id=run_id, until_methods={"turn/completed", "error"})
        else:
            raise RuntimeError("session manager does not support raw event streaming")
        for raw_event in raw_events:
            progress_message = _format_turn_progress_event(raw_event, self._agent_message_chunks)
            if progress_message is not None:
                self._emit_frontend_event(progress_message)
            normalized = normalize_event(
                raw_event,
                run_id=run_id,
                stage_id=f"stage-{stage_kind}",
                task_id=task_id,
            )
            if normalized is not None:
                self._persist_event(normalized)
            if raw_event.method == "error":
                raise RuntimeError(f"session error while running {stage_kind}")
        self._agent_message_chunks.clear()
        self._append_headless_event(
            run_id=run_id,
            stage_id=f"stage-{stage_kind}",
            event_type="stage.completed",
            payload={"stage_kind": stage_kind, "attempt": self.state.stage_attempts[stage_kind]},
        )
        self._emit_frontend_event(f"Turn completed: {run_id} {stage_kind}")

    def _ensure_run_session(self, run: Run, *, workspace_path: Path) -> None:
        root_run = self._require_root_run()
        get_session_ref = getattr(self.session_manager, "get_session_ref", None)
        if run.codex_session_ref is not None and callable(get_session_ref):
            session_ref = get_session_ref(run.run_id)
            if session_ref is not None and Path(session_ref.workspace_path).resolve(strict=False) == workspace_path.resolve(
                strict=False,
            ):
                return
        session_ref = self._start_run_session(
            run_id=run.run_id,
            goal=run.goal,
            parent_run_id=run.parent_run_id,
            workspace_path=workspace_path,
        )
        updated = self._update_run(run, status="running", codex_session_ref=session_ref)
        if updated.run_id == root_run.run_id:
            self.root_run = updated
        self._persist_run(updated)

    def _rebind_repo_root(self, new_root: Path) -> None:
        root_run = self._require_root_run()
        resolved_root = bootstrap_workspace(new_root)
        if resolved_root == self.repo_root:
            return
        self.repo_root = resolved_root
        _ensure_runtime_paths_excluded(self.repo_root)
        self.config = _load_or_create_config(self.repo_root)
        self.event_store = EventStore(self.repo_root)
        self.startup_record = load_startup_record(self.repo_root) or self.startup_record
        self.root_run = self._load_run(root_run.run_id)
        workspace_path = str(self.repo_root)
        if self.session_manager is not None and hasattr(self.session_manager, "workspace_path"):
            self.session_manager.workspace_path = workspace_path

    def _cleanup_completed_runtime_state(self) -> None:
        cleanup_mission_workspace(
            repo_root=self.repo_root,
            primary_repo_root=self.primary_repo_root,
            root_run_id=self.root_run.run_id if self.root_run is not None else _ROOT_RUN_ID,
        )
        self.repo_root = self.primary_repo_root
        self.startup_record = None

    def _resolve_target_branch(self) -> str:
        if self.target_branch is None:
            self.target_branch = _current_branch(self.repo_root)
        return self.target_branch

    def _start_run_session(
        self,
        *,
        run_id: str,
        goal: str,
        parent_run_id: str | None,
        workspace_path: Path,
    ):
        if self.session_manager is None:
            raise RuntimeError("headless execution requires a session manager")
        start_session = getattr(self.session_manager, "start_session", None)
        get_session_ref = getattr(self.session_manager, "get_session_ref", None)
        if not callable(start_session) or not callable(get_session_ref):
            raise RuntimeError("session manager does not support session startup")
        event = start_session(
            run_id=run_id,
            goal=goal,
            parent_run_id=parent_run_id,
            workspace_path=str(workspace_path),
        )
        if isinstance(event, Event):
            self._persist_event(event)
        session_ref = get_session_ref(run_id)
        if session_ref is None:
            raise RuntimeError(f"session manager did not return a session ref for {run_id}")
        return session_ref

    def _persist_event(self, event: Event) -> None:
        self.event_store.append(
            event_id=event.event_id,
            run_id=event.run_id,
            stage_id=event.stage_id,
            task_id=event.task_id,
            event_type=event.event_type,
            source=event.source,
            payload=event.payload,
            occurred_at=event.occurred_at,
        )

    def _append_headless_event(
        self,
        *,
        run_id: str,
        stage_id: str,
        event_type: str,
        payload: dict[str, object],
    ) -> None:
        self.event_store.append(
            event_id=f"{event_type}-{uuid.uuid4().hex}",
            run_id=run_id,
            stage_id=stage_id,
            task_id=None,
            event_type=event_type,
            source="headless.supervisor",
            payload=payload,
        )

    def _emit_frontend_event(self, message: str) -> None:
        if self._frontend is None:
            return
        self._frontend.emit_event(FrontendEvent(message=message))

    def _announce_stage(self, stage: StageName) -> None:
        if self._last_announced_stage == stage:
            return
        self._last_announced_stage = stage
        self._emit_frontend_event(f"Stage: {stage}")

    def _mark_stage_complete(self, stage: Literal["intake", "spec", "plan", "execute", "merge", "audit"], *, next_stage: StageName) -> None:
        self._ensure_completed_stage(stage)
        self.state.current_stage = next_stage
        self._persist_state()

    def _ensure_completed_stage(self, stage: str) -> None:
        if stage not in self.state.completed_stages:
            self.state.completed_stages.append(stage)

    def _persist_run(self, run: Run) -> None:
        write_json_atomic(
            self.repo_root / ".ralphception" / "runs" / run.run_id / "run.json",
            run.model_dump(mode="json"),
        )

    def _load_run(self, run_id: str) -> Run:
        path = self.repo_root / ".ralphception" / "runs" / run_id / "run.json"
        return Run.model_validate_json(path.read_text(encoding="utf-8"))

    def _update_run(
        self,
        run: Run,
        *,
        status: str | None = None,
        codex_session_ref=None,
        artifact_refs: list[ArtifactRef] | None = None,
    ) -> Run:
        data = run.model_dump(mode="python")
        data["status"] = run.status if status is None else status
        if codex_session_ref is not None:
            data["codex_session_ref"] = codex_session_ref
        data["artifact_refs"] = list(run.artifact_refs if artifact_refs is None else artifact_refs)
        data["updated_at"] = _utc_now()
        updated = Run(**data)
        self._persist_run(updated)
        return updated

    def _fail_child_run(
        self,
        run: Run,
        *,
        stage_id: str,
        reason: str,
        artifact_refs: list[ArtifactRef] | None = None,
        before_orchestration: bool = False,
    ) -> None:
        self._append_headless_event(
            run_id=run.run_id,
            stage_id=stage_id,
            event_type="stage.failed",
            payload={
                "stage_kind": stage_id.removeprefix("stage-"),
                "reason": reason,
            },
        )
        if before_orchestration:
            data = run.model_dump(mode="python")
            data["status"] = "failed"
            data["stage_ids"] = []
            data["artifact_refs"] = [*run.artifact_refs, *(artifact_refs or [])]
            data["updated_at"] = _utc_now()
            updated_child = Run(**data)
            self._persist_run(updated_child)
        else:
            updated_child = self._update_run(
                run,
                status="failed",
                artifact_refs=[*run.artifact_refs, *(artifact_refs or [])],
            )
        self.state.current_stage = "execute"
        self.state.terminal_outcome = None
        if updated_child.run_id not in self.state.child_run_ids:
            self.state.child_run_ids.append(updated_child.run_id)
        self._persist_state()

    def _current_child_run(self) -> Run | None:
        run_id = self.state.current_child_run_id
        if run_id is None:
            return None
        path = self.repo_root / ".ralphception" / "runs" / run_id / "run.json"
        if not path.exists():
            return None
        return Run.model_validate_json(path.read_text(encoding="utf-8"))

    def _persist_state(self) -> None:
        root_run = self._require_root_run()
        write_json_atomic(
            self.repo_root / ".ralphception" / "runs" / root_run.run_id / "headless-state.json",
            self.state.model_dump(mode="json"),
        )

    def _has_spec_review_approval(self) -> bool:
        root_run = self._require_root_run()
        approvals_dir = self.repo_root / ".ralphception" / "approvals"
        for path in approvals_dir.glob("*.json"):
            approval = read_approval(self.repo_root, approval_id=path.stem)
            if approval.run_id == root_run.run_id and approval.approval_kind == "spec_review":
                return True
        return False

    def _has_execution_bundle_approval(self, bundle_version: int) -> bool:
        root_run = self._require_root_run()
        approvals_dir = self.repo_root / ".ralphception" / "approvals"
        for path in approvals_dir.glob("*.json"):
            approval = read_approval(self.repo_root, approval_id=path.stem)
            if (
                approval.run_id == root_run.run_id
                and approval.approval_kind == "execution_bundle"
                and approval.bundle_version == bundle_version
            ):
                return True
        return False

    def _latest_bundle(self) -> ExecutionBundle | None:
        root_run = self._require_root_run()
        bundle_dir = self.repo_root / ".ralphception" / "runs" / root_run.run_id / "bundles"
        candidates: list[ExecutionBundle] = []
        for path in sorted(bundle_dir.glob("*.json")):
            candidates.append(read_bundle(self.repo_root, run_id=root_run.run_id, bundle_id=path.stem))
        if not candidates:
            return None
        return max(candidates, key=lambda bundle: bundle.bundle_version)

    def _build_spec_prompt(self, spec_path: Path) -> str:
        root_run = self._require_root_run()
        startup_record = self._require_startup_record()
        contract = {
            "stage": "spec",
            "run_id": root_run.run_id,
            "output_path": str(spec_path.relative_to(self.repo_root)),
            "seed_prompt": startup_record.seed_prompt,
        }
        return _render_prompt(
            contract=contract,
            skill_name="spec.write.md",
            body=(
                f"Use the intake artifact at `{startup_record.intake_artifact.artifact_path}`.\n"
                f"Write a repo-local mission spec to `{spec_path.relative_to(self.repo_root)}`.\n"
                "Capture scope, architecture, risks, and acceptance criteria."
            ),
        )

    def _build_plan_prompt(self, plan_path: Path, plan_contract_path: Path) -> str:
        root_run = self._require_root_run()
        startup_record = self._require_startup_record()
        contract = {
            "stage": "plan",
            "run_id": root_run.run_id,
            "plan_path": str(plan_path.relative_to(self.repo_root)),
            "plan_contract_path": str(plan_contract_path.relative_to(self.repo_root)),
            "seed_prompt": startup_record.seed_prompt,
        }
        return _render_prompt(
            contract=contract,
            skill_name="plan.write.md",
            body=(
                "Read `.ralphception/specs/mission-spec.md`.\n"
                f"Write human-readable plan markdown to `{plan_path.relative_to(self.repo_root)}`.\n"
                f"Also write JSON to `{plan_contract_path.relative_to(self.repo_root)}` with keys "
                "`execution_goal`, `verification_commands`, `todos`, `commit_intents`, "
                "and `execution_policy`."
            ),
        )

    def _build_execute_prompt(self, *, run_id: str, goal: str, handoff_path: Path) -> str:
        relative_handoff = Path(".ralphception") / "runs" / run_id / "handoff.json"
        contract = {
            "stage": "execute",
            "run_id": run_id,
            "handoff_path": str(relative_handoff),
            "goal": goal,
        }
        return _render_prompt(
            contract=contract,
            skill_name="execute.task.md",
            body=(
                f"Execute the child goal: {goal}\n"
                "Modify the worktree to implement the goal.\n"
                f"Write JSON handoff metadata to `{relative_handoff}` with keys "
                "`summary`, `artifacts`, `touched_paths`, and `merge_readiness`."
            ),
        )

    def _build_audit_prompt(self, audit_path: Path) -> str:
        root_run = self._require_root_run()
        contract = {
            "stage": "audit",
            "run_id": root_run.run_id,
            "audit_path": str(audit_path.relative_to(self.repo_root)),
        }
        return _render_prompt(
            contract=contract,
            skill_name="audit.review.md",
            body=(
                "Review the latest merged state and write audit findings JSON.\n"
                f"Write findings to `{audit_path.relative_to(self.repo_root)}` using "
                "the shape `{ \"findings\": [...] }`."
            ),
        )

    def _default_execution_goal(self, bundle: ExecutionBundle) -> str:
        startup_record = self._require_startup_record()
        return f"Execute approved bundle v{bundle.bundle_version} for {startup_record.seed_prompt}."

    def _result(
        self,
        *,
        mode: Literal["startup", "review", "dashboard", "completed", "failed"],
        review_target_kind: ReviewTargetKind | None = None,
    ) -> HeadlessRunResult:
        return HeadlessRunResult(
            mode=mode,
            actions=tuple(self.actions),
            review_target_kind=review_target_kind,
            root_run_id=self.root_run.run_id if self.root_run is not None else None,
            root_run_status=self.root_run.status if self.root_run is not None else None,
            authoritative_repo_root=str(self.repo_root),
            child_run_ids=tuple(self.state.child_run_ids),
            completed_stages=tuple(stage for stage in _STAGE_SEQUENCE if stage in self.state.completed_stages),
            current_stage=self.state.current_stage,
            audit_reopened=self.state.audit_reopened,
        )

    def _commit_child_changes(self, *, worktree_path: Path, run_id: str, touched_paths: list[str]) -> None:
        if not touched_paths:
            raise RuntimeError("execute handoff must report touched_paths")
        _run_git(worktree_path, "add", "--", *touched_paths)
        status = subprocess.run(
            ["git", "diff", "--cached", "--quiet"],
            cwd=worktree_path,
            check=False,
            capture_output=True,
            text=True,
        )
        if status.returncode == 0:
            raise RuntimeError(f"execute stage produced no staged changes for {run_id}")
        author_name, author_email = resolve_git_commit_identity(worktree_path)
        _run_git(
            worktree_path,
            "-c",
            "commit.gpgsign=false",
            "-c",
            f"user.name={author_name}",
            "-c",
            f"user.email={author_email}",
            "commit",
            "-m",
            f"headless: {run_id}",
        )

    def _require_root_run(self) -> Run:
        if self.root_run is None:
            raise RuntimeError("root run is not initialized")
        return self.root_run

    def _require_startup_record(self) -> StartupRecord:
        if self.startup_record is None:
            raise RuntimeError("startup record is not initialized")
        return self.startup_record


def _load_or_create_config(repo_root: Path) -> RalphceptionConfig:
    cfg_path = config_path(repo_root)
    if not cfg_path.exists():
        write_config_atomically(cfg_path, DEFAULT_CONFIG)
        return DEFAULT_CONFIG
    loaded = load_config(cfg_path)
    if loaded.config is None:
        write_config_atomically(cfg_path, DEFAULT_CONFIG)
        return DEFAULT_CONFIG
    return loaded.config


def _load_plan_contract(path: Path, *, default_goal: str) -> PlanContract:
    if not path.exists():
        return PlanContract(
            execution_goal=default_goal,
            verification_commands=_default_verification_commands(path.parent.parent.parent),
            todos=_default_todos(default_goal),
            commit_intents=_default_commit_intents(default_goal),
        )
    raw = json.loads(path.read_text(encoding="utf-8"))
    normalized = _normalize_plan_contract_payload(
        raw,
        default_goal=default_goal,
        repo_root=path.parent.parent.parent,
    )
    return PlanContract.model_validate(normalized)


def _normalize_plan_contract_payload(
    raw: Any,
    *,
    default_goal: str,
    repo_root: Path,
) -> dict[str, Any]:
    if not isinstance(raw, Mapping):
        raw = {}
    execution_goal = str(raw.get("execution_goal") or default_goal).strip() or default_goal
    todo_specs = _normalize_todo_specs(raw.get("todos"))
    commit_intents = _normalize_commit_intents(
        raw.get("commit_intents"),
        todo_ids=[spec["todo_id"] for spec in todo_specs],
        execution_goal=execution_goal,
    )
    if not commit_intents:
        commit_intents = [
            intent.model_dump(mode="json")
            for intent in _default_commit_intents(execution_goal)
        ]

    commit_todo_ids = {
        todo_id
        for intent in commit_intents
        for todo_id in intent["todo_ids"]
    }
    todo_ids = [spec["todo_id"] for spec in todo_specs]
    if todo_ids and not commit_todo_ids:
        commit_intents[0]["todo_ids"] = list(todo_ids)
    else:
        missing_todo_ids = [todo_id for todo_id in todo_ids if todo_id not in commit_todo_ids]
        if missing_todo_ids:
            commit_intents[0]["todo_ids"] = [*commit_intents[0]["todo_ids"], *missing_todo_ids]

    todos = _normalize_todos(
        todo_specs,
        commit_intents=commit_intents,
        execution_goal=execution_goal,
    )
    if not todos:
        todos = [todo.model_dump(mode="json") for todo in _default_todos(execution_goal)]

    verification_commands = _normalize_verification_command_entries(raw.get("verification_commands"))
    if not verification_commands:
        verification_commands = _default_verification_commands(repo_root)

    return {
        "execution_goal": execution_goal,
        "verification_commands": verification_commands,
        "todos": todos,
        "commit_intents": commit_intents,
        "execution_policy": _normalize_execution_policy(raw.get("execution_policy")),
    }


def _normalize_verification_command_entries(raw_commands: Any) -> list[str]:
    if not isinstance(raw_commands, list):
        return []
    normalized: list[str] = []
    for entry in raw_commands:
        if isinstance(entry, str):
            normalized.append(entry)
            continue
        if isinstance(entry, Mapping):
            command = entry.get("command")
            if isinstance(command, str):
                normalized.append(command)
    return normalized


def _normalize_todo_specs(raw_todos: Any) -> list[dict[str, Any]]:
    if not isinstance(raw_todos, list):
        return []
    specs: list[dict[str, Any]] = []
    previous_todo_id: str | None = None
    for index, entry in enumerate(raw_todos, start=1):
        if isinstance(entry, str):
            todo_id = f"todo-{index}"
            title = entry
            dependency_ids: list[str] | None = [previous_todo_id] if previous_todo_id is not None else []
            scope_hints: list[str] = []
            explicit_commit_intent_id = None
            explicit_status = None
        elif isinstance(entry, Mapping):
            entry_map = cast(Mapping[str, Any], entry)
            todo_id = str(entry_map.get("todo_id") or entry_map.get("id") or f"todo-{index}").strip() or f"todo-{index}"
            title = str(entry_map.get("title") or entry_map.get("summary") or todo_id).strip() or todo_id
            explicit_dependencies = _normalize_string_list(entry_map.get("dependency_ids"))
            dependency_ids = explicit_dependencies if explicit_dependencies is not None else (
                [previous_todo_id] if previous_todo_id is not None else []
            )
            scope_hints = (
                _normalize_string_list(entry_map.get("scope_hints"))
                or _normalize_string_list(entry_map.get("files"))
                or _normalize_string_list(entry_map.get("paths"))
                or []
            )
            explicit_commit_intent_id = _normalize_optional_string(entry_map.get("commit_intent_id"))
            explicit_status = _normalize_optional_string(entry_map.get("status"))
        else:
            continue
        status = explicit_status or ("blocked" if dependency_ids else "ready")
        specs.append(
            {
                "todo_id": todo_id,
                "title": title,
                "dependency_ids": dependency_ids,
                "status": status,
                "scope_hints": scope_hints,
                "explicit_commit_intent_id": explicit_commit_intent_id,
            }
        )
        previous_todo_id = todo_id
    return specs


def _normalize_commit_intents(
    raw_commit_intents: Any,
    *,
    todo_ids: list[str],
    execution_goal: str,
) -> list[dict[str, Any]]:
    if not isinstance(raw_commit_intents, list):
        return []
    normalized: list[dict[str, Any]] = []
    for index, entry in enumerate(raw_commit_intents, start=1):
        if isinstance(entry, Mapping):
            entry_map = cast(Mapping[str, Any], entry)
            intent_id = str(entry_map.get("intent_id") or f"intent-{index}").strip() or f"intent-{index}"
            message = _normalize_optional_string(entry_map.get("message"))
            if message is None:
                scope = _normalize_optional_string(entry_map.get("scope")) or "chore"
                summary = _normalize_optional_string(entry_map.get("summary")) or execution_goal
                message = _format_commit_message(scope, summary)
            assigned_todo_ids = _normalize_string_list(entry_map.get("todo_ids"))
            if not assigned_todo_ids:
                if len(raw_commit_intents) == len(todo_ids) and index - 1 < len(todo_ids):
                    assigned_todo_ids = [todo_ids[index - 1]]
                elif index == 1:
                    assigned_todo_ids = list(todo_ids)
                else:
                    assigned_todo_ids = []
            if not assigned_todo_ids:
                continue
            ordering_after = _normalize_string_list(entry_map.get("ordering_after"))
            if ordering_after is None:
                ordering_after = [normalized[-1]["intent_id"]] if normalized else []
            normalized.append(
                {
                    "intent_id": intent_id,
                    "message": message,
                    "todo_ids": assigned_todo_ids,
                    "ordering_after": ordering_after,
                }
            )
    return normalized


def _normalize_todos(
    todo_specs: list[dict[str, Any]],
    *,
    commit_intents: list[dict[str, Any]],
    execution_goal: str,
) -> list[dict[str, Any]]:
    if not todo_specs:
        return []
    todo_to_commit_intent: dict[str, str] = {}
    for intent in commit_intents:
        intent_id = intent["intent_id"]
        for todo_id in intent["todo_ids"]:
            todo_to_commit_intent.setdefault(todo_id, intent_id)
    default_commit_intent_id = commit_intents[0]["intent_id"] if commit_intents else "intent-1"
    normalized: list[dict[str, Any]] = []
    for spec in todo_specs:
        normalized.append(
            {
                "todo_id": spec["todo_id"],
                "title": spec["title"] or execution_goal,
                "dependency_ids": spec["dependency_ids"],
                "status": spec["status"],
                "commit_intent_id": (
                    spec["explicit_commit_intent_id"]
                    or todo_to_commit_intent.get(spec["todo_id"])
                    or default_commit_intent_id
                ),
                "scope_hints": spec["scope_hints"],
            }
        )
    return normalized


def _normalize_execution_policy(raw_execution_policy: Any) -> dict[str, Any]:
    if not isinstance(raw_execution_policy, Mapping):
        return ExecutionPolicy().model_dump(mode="json")
    normalized: dict[str, Any] = {}
    if isinstance(raw_execution_policy.get("max_parallel_children"), int):
        normalized["max_parallel_children"] = raw_execution_policy["max_parallel_children"]
    if isinstance(raw_execution_policy.get("batch_by_scope"), bool):
        normalized["batch_by_scope"] = raw_execution_policy["batch_by_scope"]
    if isinstance(raw_execution_policy.get("allow_commit_split"), bool):
        normalized["allow_commit_split"] = raw_execution_policy["allow_commit_split"]
    return ExecutionPolicy(**normalized).model_dump(mode="json")


def _normalize_string_list(value: Any) -> list[str] | None:
    if value is None:
        return None
    if not isinstance(value, list):
        return []
    normalized = [str(item).strip() for item in value if isinstance(item, str) and str(item).strip()]
    return normalized


def _normalize_optional_string(value: Any) -> str | None:
    if not isinstance(value, str):
        return None
    stripped = value.strip()
    return stripped or None


def _format_commit_message(scope: str, summary: str) -> str:
    normalized_scope = scope.strip() or "chore"
    normalized_summary = summary.strip() or "update runtime artifacts"
    return f"{normalized_scope}: {normalized_summary}"


def _default_todos(execution_goal: str) -> list[TodoNode]:
    return [
        TodoNode(
            todo_id="todo-1",
            title=execution_goal,
            dependency_ids=[],
            status="ready",
            commit_intent_id="intent-1",
            scope_hints=["src/"],
        )
    ]


def _default_commit_intents(execution_goal: str) -> list[CommitIntent]:
    return [
        CommitIntent(
            intent_id="intent-1",
            message=f"feat: {execution_goal.rstrip('.')}",
            todo_ids=["todo-1"],
            ordering_after=[],
        )
    ]


def _resolve_child_final_commit_message(*, goal: str, plan_contract: PlanContract | None) -> str:
    if plan_contract is not None and plan_contract.commit_intents:
        return plan_contract.commit_intents[0].message
    return f"chore: {goal.rstrip('.')}"


def _artifact_ref_for_file(
    repo_root: Path,
    relative_path: Path,
    artifact_kind: str,
    *,
    root: Path | None = None,
) -> ArtifactRef:
    base_root = root or repo_root
    content = (base_root / relative_path).read_bytes()
    return ArtifactRef(
        artifact_kind=artifact_kind,
        artifact_path=str(relative_path),
        artifact_version=1,
        content_hash=f"sha256:{hashlib.sha256(content).hexdigest()}",
    )


def _preferred_artifact_path(directory: Path, *, preferred_name: str) -> Path:
    preferred = directory / preferred_name
    if preferred.exists():
        return preferred
    for path in sorted(directory.glob("*.md")):
        return path
    return preferred


def _render_prompt(*, contract: Mapping[str, object], skill_name: str, body: str) -> str:
    skill_text = (_SKILLS_DIR / skill_name).read_text(encoding="utf-8").strip()
    return (
        f"{_CONTRACT_BEGIN}\n"
        f"{json.dumps(contract, indent=2, sort_keys=True)}\n"
        f"{_CONTRACT_END}\n\n"
        f"{skill_text}\n\n"
        f"{body}\n"
    )


def _run_verification_command(
    service: VerificationService,
    verification_id: str,
    index: int,
    command: str,
    cwd: Path,
    config: RalphceptionConfig,
):
    started = time.perf_counter()
    try:
        completed = subprocess.run(
            command,
            cwd=cwd,
            shell=True,
            check=False,
            capture_output=True,
            text=True,
            timeout=config.verification.command_timeout_seconds,
        )
        return service.shape_command_result(
            verification_id=verification_id,
            command_index=index,
            command=command,
            cwd=cwd,
            exit_code=completed.returncode,
            duration_ms=int((time.perf_counter() - started) * 1000),
            stdout=completed.stdout,
            stderr=completed.stderr,
        )
    except subprocess.TimeoutExpired as exc:
        stdout = exc.stdout.decode() if isinstance(exc.stdout, bytes) else (exc.stdout or "")
        stderr = exc.stderr.decode() if isinstance(exc.stderr, bytes) else (exc.stderr or "")
        return service.shape_command_result(
            verification_id=verification_id,
            command_index=index,
            command=command,
            cwd=cwd,
            exit_code=None,
            duration_ms=int((time.perf_counter() - started) * 1000),
            stdout=stdout,
            stderr=stderr,
            timed_out=True,
        )


def _default_verification_commands(repo_root: Path) -> list[str]:
    del repo_root
    return ['python -c "print(\'headless verification\')"']


def _current_branch(repo_root: Path) -> str:
    return _git_output(repo_root, "rev-parse", "--abbrev-ref", "HEAD")


def cleanup_mission_workspace(
    *,
    repo_root: Path,
    primary_repo_root: Path,
    root_run_id: str = _ROOT_RUN_ID,
) -> Path:
    current_root = bootstrap_workspace(repo_root)
    canonical_primary_root = bootstrap_workspace(primary_repo_root)
    worktrees = WorktreeCoordinator(repo_root=canonical_primary_root)
    root_assignment = _load_worktree_assignment(canonical_primary_root, root_run_id)
    if current_root != canonical_primary_root and root_assignment is not None and root_assignment.kind == "integration":
        try:
            worktrees.switch_authoritative_root(run_id=root_run_id, new_root=canonical_primary_root)
        except RuntimeError:
            pass

    assignments = _runtime_worktree_assignments(canonical_primary_root)
    for assignment in assignments:
        if assignment.run_id == root_run_id or assignment.cleanup_state == "cleaned":
            continue
        worktrees.cleanup_worktree(run_id=assignment.run_id, worktree_path=assignment.worktree_path, retain=False)
    if root_assignment is not None and root_assignment.cleanup_state != "cleaned":
        worktrees.cleanup_worktree(run_id=root_run_id, worktree_path=root_assignment.worktree_path, retain=False)

    tracked_runtime_paths = _tracked_runtime_paths(canonical_primary_root)
    clear_workspace_lease(canonical_primary_root)
    runtime_root = canonical_primary_root / ".ralphception"
    if runtime_root.exists():
        shutil.rmtree(runtime_root)
    worktrees_root = canonical_primary_root / ".worktrees"
    if worktrees_root.exists():
        shutil.rmtree(worktrees_root)
    if tracked_runtime_paths:
        _run_git(
            canonical_primary_root,
            "restore",
            "--source=HEAD",
            "--staged",
            "--worktree",
            "--",
            *tracked_runtime_paths,
        )
    return canonical_primary_root


def _runtime_worktree_assignments(repo_root: Path) -> list[WorktreeAssignment]:
    assignments: list[WorktreeAssignment] = []
    runs_dir = repo_root / ".ralphception" / "runs"
    if not runs_dir.exists():
        return assignments
    for worktree_path in sorted(runs_dir.glob("*/worktree.json")):
        assignment = _load_worktree_assignment(repo_root, worktree_path.parent.name)
        if assignment is not None:
            assignments.append(assignment)
    return assignments


def _load_worktree_assignment(repo_root: Path, run_id: str) -> WorktreeAssignment | None:
    try:
        return read_worktree_assignment(repo_root, run_id)
    except (FileNotFoundError, ValueError, OSError):
        return None


def _tracked_runtime_paths(repo_root: Path) -> list[str]:
    completed = subprocess.run(
        ["git", "ls-files", "-z", "--", ".ralphception", ".worktrees"],
        cwd=repo_root,
        check=True,
        capture_output=True,
        text=True,
    )
    return [path for path in completed.stdout.split("\0") if path]


def _ensure_runtime_paths_excluded(repo_root: Path) -> None:
    try:
        exclude_path = Path(_git_output(repo_root, "rev-parse", "--git-path", "info/exclude"))
    except subprocess.CalledProcessError:
        return
    if not exclude_path.is_absolute():
        exclude_path = repo_root / exclude_path
    exclude_path.parent.mkdir(parents=True, exist_ok=True)
    existing = exclude_path.read_text(encoding="utf-8") if exclude_path.exists() else ""
    additions = []
    for pattern in (".ralphception/", ".worktrees/"):
        if pattern not in existing.splitlines():
            additions.append(pattern)
    if additions:
        prefix = "" if existing.endswith("\n") or not existing else "\n"
        exclude_path.write_text(existing + prefix + "\n".join(additions) + "\n", encoding="utf-8")


def _format_turn_progress_event(raw_event, agent_message_chunks: dict[str, list[str]]) -> str | None:
    method = raw_event.method
    if method.startswith("codex/event/"):
        return None

    payload = raw_event.payload if isinstance(raw_event.payload, Mapping) else {}
    if method == "item/agentMessage/delta":
        item_id = _as_text(payload.get("item_id"))
        delta = _as_text(payload.get("delta"))
        if item_id is not None and delta:
            agent_message_chunks.setdefault(item_id, []).append(delta)
        return None

    if method == "item/started":
        item = payload.get("item")
        if not isinstance(item, Mapping):
            return None
        if _as_text(item.get("type")) == "commandExecution":
            command = _compact_single_line(_as_text(item.get("command")))
            if command:
                return f"Command started: {command}"
        return None

    if method != "item/completed":
        return None

    item = payload.get("item")
    if not isinstance(item, Mapping):
        return None
    item_type = _as_text(item.get("type"))
    item_id = _as_text(item.get("id"))
    if item_type == "agentMessage":
        text = _compact_single_line(_as_text(item.get("text")))
        if not text and item_id is not None:
            text = _compact_single_line("".join(agent_message_chunks.pop(item_id, [])))
        elif item_id is not None:
            agent_message_chunks.pop(item_id, None)
        if text:
            return f"Agent: {text}"
        return None
    if item_type == "commandExecution":
        command = _compact_single_line(_as_text(item.get("command")))
        if not command:
            return None
        exit_code = item.get("exit_code")
        if isinstance(exit_code, int):
            return f"Command completed (exit {exit_code}): {command}"
        status = _as_text(item.get("status"))
        if status == "completed":
            return f"Command completed: {command}"
        if status:
            return f"Command {status}: {command}"
    return None


def _as_text(value: object) -> str | None:
    return value if isinstance(value, str) and value else None


def _compact_single_line(value: str | None) -> str | None:
    if value is None:
        return None
    compacted = " ".join(value.split())
    return compacted or None


def _is_child_handoff_metadata_artifact(path: str) -> bool:
    normalized = path.strip().replace("\\", "/")
    return normalized.startswith(".ralphception/runs/") and normalized.endswith("/handoff.json")


def _run_git(repo_root: Path, *args: str) -> None:
    subprocess.run(
        ["git", *args],
        cwd=repo_root,
        check=True,
        capture_output=True,
        text=True,
    )


def _git_output(repo_root: Path, *args: str) -> str:
    completed = subprocess.run(
        ["git", *args],
        cwd=repo_root,
        check=True,
        capture_output=True,
        text=True,
    )
    return completed.stdout.strip()


def _utc_now():
    from datetime import datetime, timezone

    return datetime.now(timezone.utc)


def _superseded_run_id(run_id: str) -> str | None:
    marker = "-replacement-"
    if marker not in run_id:
        return None
    return run_id.split(marker, 1)[0]


def _next_replacement_run_id(run_id: str) -> str:
    marker = "-replacement-"
    if marker not in run_id:
        return f"{run_id}{marker}1"
    base, raw_index = run_id.rsplit(marker, 1)
    return f"{base}{marker}{int(raw_index) + 1}"
