"""Textual dashboard shell and command handling for Ralphception."""

from __future__ import annotations

import shlex
import threading
from dataclasses import dataclass, field, replace
from datetime import datetime, timezone
from pathlib import Path
from typing import TYPE_CHECKING, Literal, Protocol, cast

from textual.app import App, ComposeResult
from textual.containers import Horizontal, Vertical
from textual.widgets import Header, Input, Tree

from ralphception.config import DEFAULT_CONFIG, RalphceptionConfig, load_config, write_config_atomically
from ralphception.models.artifacts import ArtifactRef
from ralphception.models.events import Event
from ralphception.models.runtime import ExecutionBundle, Run, RunStageStatus, Stage, StageKind
from ralphception.paths import config_path
from ralphception.runtime.frontends import FrontendEvent, MissionConflictDecision, ReviewDecision
from ralphception.storage.events import EventStore
from ralphception.workflow.engine import WorkflowEngine
from ralphception.workflow.recovery import ResumeResult

if TYPE_CHECKING:
    from ralphception.runtime.supervisor import RuntimeSupervisor

from .widgets.command_bar import CommandBarWidget
from .widgets.detail_pane import DetailContent, DetailPaneWidget
from .widgets.event_feed import EventFeedEntry, EventFeedWidget
from .widgets.workflow_tree import WorkflowTreeEntry, WorkflowTreeWidget

STAGE_ORDER: tuple[StageKind, ...] = (
    "intake",
    "brainstorm",
    "spec",
    "plan",
    "execute",
    "merge",
    "audit",
)
PENDING_BUNDLE_STATES = frozenset({"draft", "awaiting_approval"})
HELP_LINES: tuple[str, ...] = (
    "/model <name>  switch the persisted Codex model",
    "/resume [repair]  replay durable state and hydrate the event feed",
    "/status  summarize the current root run, stages, and bundles",
    "/artifacts  jump to the newest bundle that still needs attention",
    "/approve  advance the selected approval target when possible",
    "/retry  move the selected run back to pending",
    "/restart  restart the selected run session",
    "/replace  create a replacement run for the selected child run",
    "/abort  mark the selected run as aborted",
    "/help  show dashboard commands",
)


class RecoveryServiceProtocol(Protocol):
    """Subset of recovery operations the dashboard can trigger."""

    def resume(self, *, run_id: str, mode: Literal["read", "repair"]) -> ResumeResult: ...

    def retry_run(self, run_id: str) -> Run: ...

    def restart_run(self, run_id: str) -> Run: ...

    def replace_run(self, run_id: str) -> Run: ...


@dataclass(frozen=True, slots=True)
class CommandResult:
    """Outcome of a slash-command execution."""

    ok: bool
    message: str


@dataclass(slots=True)
class DashboardController:
    """Own dashboard state, workflow selection, and slash-command handling."""

    repo_root: Path
    engine: WorkflowEngine
    supervisor: RuntimeSupervisor | None = None
    recovery_service: RecoveryServiceProtocol | None = None
    event_store: EventStore | None = None
    config: RalphceptionConfig = field(init=False)
    selected_node_id: str | None = field(init=False, default=None)
    event_entries: list[EventFeedEntry] = field(init=False, default_factory=list)
    last_message: str = field(init=False, default="")

    def __post_init__(self) -> None:
        self.repo_root = self.repo_root.resolve(strict=False)
        self.event_store = self.event_store or EventStore(self.repo_root)
        self.config = _load_or_create_config(self.repo_root)
        self.selected_node_id = _run_node_id(self.engine.root_run.run_id)
        self.hydrate_event_feed(self.engine.root_run.run_id)

    def workflow_entries(self) -> list[WorkflowTreeEntry]:
        """Return the workflow tree snapshot for the current engine state."""
        root_run = self.engine.root_run
        entries = [
            WorkflowTreeEntry(
                node_id=_run_node_id(root_run.run_id),
                parent_id=None,
                label=f"{root_run.run_id}: {root_run.goal}",
                status=root_run.status,
            ),
        ]

        for stage in self._stages():
            entries.append(
                WorkflowTreeEntry(
                    node_id=_stage_node_id(stage.stage_kind),
                    parent_id=_run_node_id(root_run.run_id),
                    label=f"{stage.stage_kind} stage",
                    status=stage.status,
                ),
            )

        for run in self._child_runs():
            entries.append(
                WorkflowTreeEntry(
                    node_id=_run_node_id(run.run_id),
                    parent_id=_run_node_id(root_run.run_id),
                    label=f"{run.run_id}: {run.goal}",
                    status=run.status,
                ),
            )

        for bundle in self._bundles():
            entries.append(
                WorkflowTreeEntry(
                    node_id=_bundle_node_id(bundle.bundle_id),
                    parent_id=_run_node_id(root_run.run_id),
                    label=f"bundle v{bundle.bundle_version} ({bundle.bundle_id})",
                    status=bundle.state,
                ),
            )

        return entries

    def select_node(self, node_id: str) -> None:
        """Select a workflow node by its dashboard id."""
        if node_id not in {entry.node_id for entry in self.workflow_entries()}:
            return
        self.selected_node_id = node_id

    def selected_detail(self) -> DetailContent | None:
        """Return detail-pane content for the current selection."""
        if self.selected_node_id is None:
            return None
        node_type, _, identifier = self.selected_node_id.partition(":")
        if node_type == "run":
            run = self.engine.run(identifier)
            blocked_reason, next_actions = _run_reason_and_actions(run)
            return DetailContent(
                title=f"Run {run.run_id}",
                lines=(
                    f"Goal: {run.goal}",
                    f"Status: {run.status}",
                    f"Artifacts: {len(run.artifact_refs)}",
                ),
                blocked_reason=blocked_reason,
                next_actions=next_actions,
                actions=_run_actions(run),
            )
        if node_type == "stage":
            stage = self._stage_by_kind(identifier)
            blocked_reason, next_actions = _stage_reason_and_actions(stage)
            return DetailContent(
                title=f"{stage.stage_kind.capitalize()} Stage",
                lines=(
                    f"Run: {stage.run_id}",
                    f"Status: {stage.status}",
                    f"Tasks: {len(stage.task_ids)}",
                ),
                blocked_reason=blocked_reason,
                next_actions=next_actions,
                actions=_stage_actions(stage),
            )
        if node_type == "bundle":
            bundle = self._bundle_by_id(identifier)
            blocked_reason, next_actions = _bundle_reason_and_actions(bundle)
            return DetailContent(
                title=f"Bundle {bundle.bundle_id}",
                lines=(
                    f"Version: {bundle.bundle_version}",
                    f"State: {bundle.state}",
                    f"Artifacts: {len(bundle.artifact_refs)}",
                ),
                blocked_reason=blocked_reason,
                next_actions=next_actions,
                actions=_bundle_actions(bundle),
            )
        return None

    def handle_command(self, raw_command: str) -> CommandResult:
        """Parse and execute a slash command against dashboard state."""
        command = raw_command.strip()
        if not command:
            return self._result(False, "Enter a slash command.")
        if not command.startswith("/"):
            return self._result(False, "Commands must start with '/'.")

        try:
            tokens = shlex.split(command)
        except ValueError as exc:
            return self._result(False, f"Malformed command: {exc}.")
        name = tokens[0]
        args = tokens[1:]
        handlers = {
            "/help": self._handle_help,
            "/model": lambda: self._handle_model(args),
            "/resume": lambda: self._handle_resume(args),
            "/status": self._handle_status,
            "/artifacts": self._handle_artifacts,
            "/approve": self._handle_approve,
            "/retry": self._handle_retry,
            "/restart": self._handle_restart,
            "/replace": self._handle_replace,
            "/abort": self._handle_abort,
        }
        handler = handlers.get(name)
        if handler is None:
            return self._result(False, f"Unknown command: {name}")
        result = handler()
        self.hydrate_event_feed(self.engine.root_run.run_id)
        return result

    def reload_from_supervisor(self) -> None:
        """Reload dashboard state from the shared runtime supervisor."""
        if self.supervisor is None:
            return
        step = self.supervisor.step()
        if step.engine is not None:
            self.engine = step.engine
            self.recovery_service = self.supervisor.build_recovery_service(engine=self.engine)
        if self.selected_node_id not in {entry.node_id for entry in self.workflow_entries()}:
            self.selected_node_id = _run_node_id(self.engine.root_run.run_id)
        self.hydrate_event_feed(self.engine.root_run.run_id)

    def hydrate_event_feed(self, run_id: str) -> None:
        """Reload event-feed rows from the durable event store."""
        store = cast(EventStore, self.event_store)
        self.event_entries = [_event_feed_entry(event) for event in store.read_run(run_id)]

    def _handle_help(self) -> CommandResult:
        return self._result(True, "\n".join(HELP_LINES))

    def _handle_model(self, args: list[str]) -> CommandResult:
        if len(args) != 1:
            return self._result(False, "Usage: /model <name>")
        self.config = replace(
            self.config,
            codex=replace(self.config.codex, model=args[0]),
        )
        write_config_atomically(config_path(self.repo_root), self.config)
        return self._result(True, f"Model updated to {args[0]}.")

    def _handle_resume(self, args: list[str]) -> CommandResult:
        if self.recovery_service is None:
            return self._result(False, "Recovery service is not configured.")
        mode: Literal["read", "repair"] = "repair" if args[:1] == ["repair"] else "read"
        result = self.recovery_service.resume(run_id=self.engine.root_run.run_id, mode=mode)
        self.hydrate_event_feed(result.run_id)
        recommended = f" Next action: /{result.recommended_action}." if result.recommended_action else ""
        return self._result(True, f"Resumed {result.run_id} in {result.mode} mode.{recommended}")

    def _handle_status(self) -> CommandResult:
        root_run = self.engine.root_run
        blocked_stages = sum(
            1 for stage in self._stages() if stage.status in {"awaiting_approval", "blocked"}
        )
        message = (
            f"{root_run.run_id} is {root_run.status}; "
            f"{len(self._stages())} stages, {blocked_stages} blocked, {len(self._bundles())} bundles."
        )
        return self._result(True, message)

    def _handle_artifacts(self) -> CommandResult:
        bundle = self._pending_bundle() or self._latest_bundle()
        if bundle is None:
            return self._result(False, "No bundles are available.")
        self.selected_node_id = _bundle_node_id(bundle.bundle_id)
        return self._result(
            True,
            f"Selected pending bundle {bundle.bundle_id} (v{bundle.bundle_version}, {bundle.state}).",
        )

    def _handle_approve(self) -> CommandResult:
        selected_bundle = self._selected_bundle()
        if selected_bundle is None:
            selected_bundle = self._pending_bundle()
        if selected_bundle is None:
            return self._result(False, "No bundle is waiting for approval.")
        if selected_bundle.state not in PENDING_BUNDLE_STATES:
            return self._result(True, f"Bundle {selected_bundle.bundle_id} is already {selected_bundle.state}.")

        payload = selected_bundle.model_dump(mode="python")
        payload["state"] = "approved"
        approved_bundle = ExecutionBundle(**payload)
        self._bundles_by_id()[approved_bundle.bundle_id] = approved_bundle
        self.selected_node_id = _bundle_node_id(approved_bundle.bundle_id)
        return self._result(True, f"Approved bundle {approved_bundle.bundle_id}.")

    def _handle_retry(self) -> CommandResult:
        run = self._selected_run()
        if run is None:
            return self._result(False, "Select a run before retrying it.")
        if self.recovery_service is None:
            return self._result(False, "Recovery service is not configured.")
        retried = self.recovery_service.retry_run(run.run_id)
        self.selected_node_id = _run_node_id(retried.run_id)
        return self._result(True, f"Run {retried.run_id} moved back to {retried.status}.")

    def _handle_restart(self) -> CommandResult:
        run = self._selected_run() or self.engine.root_run
        if self.recovery_service is None:
            return self._result(False, "Recovery service is not configured.")
        restarted = self.recovery_service.restart_run(run.run_id)
        self.selected_node_id = _run_node_id(restarted.run_id)
        return self._result(True, f"Restarted {restarted.run_id}.")

    def _handle_replace(self) -> CommandResult:
        run = self._selected_run()
        if run is None:
            return self._result(False, "Select a child run before replacing it.")
        if run.run_id == self.engine.root_run.run_id:
            return self._result(False, "Root runs cannot be replaced.")
        if self.recovery_service is None:
            return self._result(False, "Recovery service is not configured.")
        replacement = self.recovery_service.replace_run(run.run_id)
        self.selected_node_id = _run_node_id(replacement.run_id)
        return self._result(True, f"Created replacement run {replacement.run_id}.")

    def _handle_abort(self) -> CommandResult:
        run = self._selected_run() or self.engine.root_run
        aborted = self.engine.update_run(
            run.run_id,
            status="aborted",
            codex_session_ref=run.codex_session_ref,
            updated_at=datetime.now(timezone.utc),
        )
        self.selected_node_id = _run_node_id(aborted.run_id)
        return self._result(True, f"Aborted {aborted.run_id}.")

    def _result(self, ok: bool, message: str) -> CommandResult:
        self.last_message = message
        return CommandResult(ok=ok, message=message)

    def _stages(self) -> list[Stage]:
        stage_map = cast(dict[StageKind, Stage], getattr(self.engine, "_stages_by_kind"))
        return [stage_map[kind] for kind in STAGE_ORDER if kind in stage_map]

    def _stage_by_kind(self, stage_kind: str) -> Stage:
        return next(stage for stage in self._stages() if stage.stage_kind == stage_kind)

    def _child_runs(self) -> list[Run]:
        return [run for run in self.engine.runs() if run.run_id != self.engine.root_run.run_id]

    def _bundles(self) -> list[ExecutionBundle]:
        return sorted(
            self._bundles_by_id().values(),
            key=lambda bundle: (bundle.bundle_version, bundle.bundle_id),
        )

    def _bundle_by_id(self, bundle_id: str) -> ExecutionBundle:
        return self._bundles_by_id()[bundle_id]

    def _bundles_by_id(self) -> dict[str, ExecutionBundle]:
        return cast(dict[str, ExecutionBundle], getattr(self.engine, "_bundles_by_id"))

    def _latest_bundle(self) -> ExecutionBundle | None:
        bundles = self._bundles()
        return bundles[-1] if bundles else None

    def _pending_bundle(self) -> ExecutionBundle | None:
        pending = [bundle for bundle in self._bundles() if bundle.state in PENDING_BUNDLE_STATES]
        return pending[-1] if pending else None

    def _selected_run(self) -> Run | None:
        if self.selected_node_id is None or not self.selected_node_id.startswith("run:"):
            return None
        return self.engine.run(self.selected_node_id.partition(":")[2])

    def _selected_bundle(self) -> ExecutionBundle | None:
        if self.selected_node_id is None or not self.selected_node_id.startswith("bundle:"):
            return None
        return self._bundle_by_id(self.selected_node_id.partition(":")[2])


class RalphceptionDashboardApp(App[str | None]):
    """Minimal Textual dashboard shell for workflow review and control."""

    TITLE = "Ralphception"
    SUB_TITLE = "Core Runtime"
    CSS = """
    Screen {
        layout: vertical;
    }

    #dashboard-body {
        height: 1fr;
    }

    #workflow-tree {
        width: 1fr;
        min-width: 32;
        border: round $accent;
    }

    #details-column {
        width: 2fr;
    }

    #detail-pane, #event-feed {
        height: 1fr;
        border: round $accent;
    }

    #command-bar {
        dock: bottom;
        height: 3;
        border: round $accent;
    }
    """
    BINDINGS = [("q", "quit", "Quit")]

    def __init__(
        self,
        controller: DashboardController,
        *,
        supervisor: RuntimeSupervisor | None = None,
    ) -> None:
        super().__init__()
        self.controller = controller
        self.supervisor = supervisor or getattr(controller, "supervisor", None)
        self._runtime_thread: threading.Thread | None = None

    def compose(self) -> ComposeResult:
        yield Header(show_clock=True)
        with Horizontal(id="dashboard-body"):
            yield WorkflowTreeWidget(id="workflow-tree")
            with Vertical(id="details-column"):
                yield DetailPaneWidget(id="detail-pane")
                yield EventFeedWidget(id="event-feed")
        yield CommandBarWidget(id="command-bar")

    def on_mount(self) -> None:
        self._refresh_view()
        self.query_one(CommandBarWidget).focus()
        if self.supervisor is not None:
            self.set_interval(0.5, self._poll_runtime_state)
            if self.controller.engine.session_manager is not None:
                self._runtime_thread = threading.Thread(target=self._drive_runtime, daemon=True)
                self._runtime_thread.start()

    def on_tree_node_selected(self, event: Tree.NodeSelected[WorkflowTreeEntry]) -> None:
        entry = event.node.data
        if entry is None:
            return
        if entry.node_id == self.controller.selected_node_id:
            return
        self.controller.select_node(entry.node_id)
        self._refresh_view(refresh_tree=False)

    def on_input_submitted(self, event: Input.Submitted) -> None:
        if not isinstance(event.input, CommandBarWidget):
            return
        result = self.controller.handle_command(event.value)
        self.query_one(CommandBarWidget).clear()
        self._refresh_view(status_override=result.message)

    def _refresh_view(self, *, status_override: str | None = None, refresh_tree: bool = True) -> None:
        detail_pane = self.query_one(DetailPaneWidget)
        event_feed = self.query_one(EventFeedWidget)
        if refresh_tree:
            workflow_tree = self.query_one(WorkflowTreeWidget)
            workflow_tree.load_entries(
                self.controller.workflow_entries(),
                selected_node_id=self.controller.selected_node_id,
            )
        detail_pane.show_detail(self.controller.selected_detail())
        event_feed.set_entries(self.controller.event_entries)
        if status_override:
            self.sub_title = status_override
        elif self.controller.last_message:
            self.sub_title = self.controller.last_message

    def _poll_runtime_state(self) -> None:
        self.controller.reload_from_supervisor()
        self._refresh_view()

    def _drive_runtime(self) -> None:
        if self.supervisor is None:
            return
        result = self.supervisor.run(frontend=_DashboardRuntimeFrontend(self))
        self.call_from_thread(self._handle_runtime_result, result.mode)

    def _handle_runtime_result(self, mode: str) -> None:
        self.controller.reload_from_supervisor()
        self._refresh_view(status_override=f"Runtime: {mode}")
        if mode in {"review", "startup", "completed", "failed"}:
            self.exit(result=mode)

    def _handle_frontend_event(self, message: str) -> None:
        self.controller.reload_from_supervisor()
        self._refresh_view(status_override=message)


class _DashboardRuntimeFrontend:
    """Bridge supervisor callbacks into the Textual dashboard app."""

    def __init__(self, app: RalphceptionDashboardApp) -> None:
        self.app = app

    def emit_event(self, event: FrontendEvent) -> None:
        self.app.call_from_thread(self.app._handle_frontend_event, event.message)

    def emit_status(self, step) -> None:
        self.app.call_from_thread(self.app._refresh_view, status_override=f"Runtime: {step.kind}")

    def prompt_startup(self, prompt):
        raise RuntimeError(f"dashboard cannot handle startup prompt: {prompt.message}")

    def prompt_review(self, prompt) -> ReviewDecision:
        return ReviewDecision(action="pause")

    def prompt_conflict(self, prompt) -> MissionConflictDecision:
        return MissionConflictDecision(action="abort")

    def finish(self, step) -> None:
        self.app.call_from_thread(self.app._refresh_view, status_override=f"Runtime: {step.kind}")


def create_dashboard_app(repo_root: Path) -> RalphceptionDashboardApp:
    """Build the real dashboard app for a repository root."""
    from ralphception.app import resolve_runtime_view

    launch = resolve_runtime_view(repo_root)
    if launch.dashboard_app is None:
        raise RuntimeError(f"workspace did not resolve to dashboard mode: {launch.mode}")
    return launch.dashboard_app


def _load_or_create_config(repo_root: Path) -> RalphceptionConfig:
    cfg_path = config_path(repo_root)
    if not cfg_path.exists():
        write_config_atomically(cfg_path, DEFAULT_CONFIG)
        return DEFAULT_CONFIG
    load_result = load_config(cfg_path)
    if load_result.config is None:
        write_config_atomically(cfg_path, DEFAULT_CONFIG)
        return DEFAULT_CONFIG
    return load_result.config


def _run_node_id(run_id: str) -> str:
    return f"run:{run_id}"


def _stage_node_id(stage_kind: str) -> str:
    return f"stage:{stage_kind}"


def _bundle_node_id(bundle_id: str) -> str:
    return f"bundle:{bundle_id}"


def _run_actions(run: Run) -> tuple[str, ...]:
    actions = ["/status"]
    if run.status in {"failed", "blocked"}:
        actions.append("/retry")
    if run.status in {"session_lost", "recovery_blocked"}:
        actions.extend(["/resume", "/restart"])
    if run.run_id != "run-root":
        actions.append("/replace")
    actions.append("/abort")
    return tuple(dict.fromkeys(actions))


def _run_reason_and_actions(run: Run) -> tuple[str | None, tuple[str, ...]]:
    if run.status == "awaiting_approval":
        return "Run is waiting on approval before it can continue.", ("/approve", "/status")
    if run.status == "blocked":
        return "Run is blocked and needs intervention before work can continue.", ("/retry", "/replace")
    if run.status == "session_lost":
        return "Run session was lost and should be resumed or restarted.", ("/resume", "/restart")
    if run.status == "recovery_blocked":
        return "Durable state is inconsistent enough to block recovery.", ("/replace", "/status")
    if run.status == "failed":
        return "Run failed and can be retried or replaced.", ("/retry", "/replace")
    return None, ()


def _stage_actions(stage: Stage) -> tuple[str, ...]:
    actions = ["/status"]
    if stage.stage_kind == "execute":
        actions.append("/artifacts")
    if stage.status == "awaiting_approval":
        actions.append("/approve")
    return tuple(actions)


def _stage_reason_and_actions(stage: Stage) -> tuple[str | None, tuple[str, ...]]:
    if stage.status == "awaiting_approval":
        return (
            f"{stage.stage_kind.capitalize()} stage is waiting on approval.",
            ("/approve", "/status"),
        )
    if stage.status == "blocked":
        return (
            f"{stage.stage_kind.capitalize()} stage is blocked pending manual action.",
            ("/status",),
        )
    if stage.status == "session_lost":
        return (
            f"{stage.stage_kind.capitalize()} stage lost its active session.",
            ("/resume", "/restart"),
        )
    return None, ()


def _bundle_actions(bundle: ExecutionBundle) -> tuple[str, ...]:
    actions = ["/artifacts", "/status"]
    if bundle.state in PENDING_BUNDLE_STATES:
        actions.append("/approve")
    return tuple(actions)


def _bundle_reason_and_actions(bundle: ExecutionBundle) -> tuple[str | None, tuple[str, ...]]:
    if bundle.state == "draft":
        return "Draft bundle is pending approval before execution can consume it.", ("/approve", "/artifacts")
    if bundle.state == "awaiting_approval":
        return "Execution bundle is waiting for approval.", ("/approve", "/artifacts")
    return None, ()


def _event_feed_entry(event: Event) -> EventFeedEntry:
    timestamp = event.occurred_at.isoformat(timespec="seconds")
    summary = _event_summary(event)
    return EventFeedEntry(
        sequence=event.sequence,
        event_type=event.event_type,
        text=f"{timestamp}  {summary}",
    )


def _event_summary(event: Event) -> str:
    if event.event_type.startswith("run."):
        goal = event.payload.get("goal")
        if isinstance(goal, str) and goal:
            return f"{event.event_type} ({goal})"
    if event.event_type.startswith("bundle."):
        bundle_id = event.payload.get("bundle_id")
        if isinstance(bundle_id, str):
            return f"{event.event_type} ({bundle_id})"
    return event.event_type


__all__ = [
    "CommandResult",
    "DashboardController",
    "RalphceptionDashboardApp",
    "create_dashboard_app",
]
