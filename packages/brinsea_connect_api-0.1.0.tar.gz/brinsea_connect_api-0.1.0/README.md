# Brinsea Connect API

Python API client for Brinsea Connect incubators. Supports async operation for use with Home Assistant and other async applications.

## Installation

```bash
pip install brinsea-connect-api
```

## Usage

```python
import asyncio
from brinsea_api import BrinseaClient

async def main():
    client = BrinseaClient("email@example.com", "password")
    await client.authenticate()

    devices = await client.get_devices()
    for device in devices:
        print(f"{device.name} ({device.model})")
        status = await client.get_device_status(device.id)
        print(f"  Temperature: {status.temperature}°C")
        print(f"  Humidity: {status.humidity}%")
        print(f"  Status: {status.connection_status}")

    await client.close()

asyncio.run(main())
```
