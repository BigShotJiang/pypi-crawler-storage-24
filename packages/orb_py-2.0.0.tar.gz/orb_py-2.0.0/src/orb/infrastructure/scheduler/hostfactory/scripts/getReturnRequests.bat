@echo off
call "%~dp0invoke_provider.bat" requests list %*
