"""
Dependency Injection Container Implementation
"""

import threading
import time
from collections.abc import Iterator
from contextlib import contextmanager
from typing import Any, Optional, TypeVar

from orb.domain.base.dependency_injection import is_injectable
from orb.domain.base.di_contracts import (
    CQRSHandlerRegistrationPort,
    DependencyRegistration,
    DIContainerPort,
    DIScope,
)
from orb.domain.base.ports import ContainerPort
from orb.infrastructure.di.components import (
    CQRSHandlerRegistry,
    DependencyResolver,
    ServiceRegistry,
)
from orb.infrastructure.di.exceptions import (
    CircularDependencyError,
    DependencyResolutionError,
    UnregisteredDependencyError,
)
from orb.infrastructure.di.lazy_config import LazyLoadingConfig
from orb.infrastructure.logging.logger import get_logger

T = TypeVar("T")
logger = get_logger(__name__)


@contextmanager
def timed_operation(operation_name: str) -> Iterator[None]:
    """Context manager for timing DI operations."""
    start_time = time.time()
    try:
        yield
    finally:
        elapsed = time.time() - start_time
        if elapsed > 0.1:
            logger.warning("Slow DI operation '%s': %.3fs", operation_name, elapsed)
        else:
            logger.debug("DI operation '%s': %.3fs", operation_name, elapsed)


class DIContainer(DIContainerPort, CQRSHandlerRegistrationPort, ContainerPort):
    """
    Dependency injection container using composition of focused components.
    Includes lazy loading capabilities for improved startup performance.
    """

    def __init__(self) -> None:
        """Initialize the DI container."""
        self._service_registry = ServiceRegistry()
        self._cqrs_registry = CQRSHandlerRegistry()
        self._dependency_resolver = DependencyResolver(
            self._service_registry, self._cqrs_registry, self
        )
        self._lock = threading.RLock()

        # Lazy loading support - use fallback during initialization
        self._lazy_config = LazyLoadingConfig.from_config_manager(None)
        self._lazy_factories: dict[type, Any] = {}
        self._on_demand_registrations: dict[type, Any] = {}

        logger.info(
            "DI Container initialized (lazy_loading=%s)",
            "enabled" if self._lazy_config.enabled else "disabled",
        )

    def is_registered(self, cls: type) -> bool:  # type: ignore[override]
        """Check if a class is registered."""
        return self._service_registry.is_registered(cls)

    def has(self, service_type: type[T]) -> bool:
        """Check if service type is registered."""
        return self._service_registry.has(service_type)

    def register_singleton(self, cls: type[T], instance_or_factory: Any = None) -> None:  # type: ignore[override]
        """Register a singleton service."""
        with timed_operation(f"register_singleton({cls.__name__})"):
            self._service_registry.register_singleton(cls, instance_or_factory)

    def register_factory(self, cls: type[T], factory) -> None:  # type: ignore[override]
        """Register a factory for creating instances."""
        with timed_operation(f"register_factory({cls.__name__})"):
            self._service_registry.register_factory(cls, factory)

    def register_instance(self, cls: type[T], instance: T) -> None:  # type: ignore[override]
        """Register a specific instance."""
        with timed_operation(f"register_instance({cls.__name__})"):
            self._service_registry.register_instance(cls, instance)

    def register(self, registration: DependencyRegistration) -> None:  # type: ignore[override]
        """Register a dependency registration."""
        self._service_registry.register(registration)

    def register_type(  # type: ignore[override]
        self,
        interface_type: type[T],
        implementation_type: type[T],
        registration_type=None,
    ) -> None:
        """Register an interface to implementation mapping."""
        scope = registration_type or DIScope.TRANSIENT
        self._service_registry.register_type(interface_type, implementation_type, scope)

    def unregister(self, dependency_type: type[T]) -> bool:
        """Unregister a dependency type."""
        return self._service_registry.unregister(dependency_type)

    def get_registrations(self) -> dict[type, DependencyRegistration]:
        """Get all registrations."""
        return self._service_registry.get_registrations()

    def get(  # type: ignore[override]
        self,
        cls: type[T],
        parent_type: Optional[type] = None,
        dependency_chain: Optional[set[type]] = None,
    ) -> T:
        """Get an instance of the specified type with lazy loading support."""
        try:
            # First, try normal resolution
            return self._dependency_resolver.resolve(cls, parent_type, dependency_chain)
        except (DependencyResolutionError, UnregisteredDependencyError):
            # If lazy loading is enabled, try on-demand registration
            if self._lazy_config.enabled and not self._service_registry.is_registered(cls):
                self._register_on_demand(cls)

                # Try resolution again after on-demand registration
                if self._service_registry.is_registered(cls):
                    return self._dependency_resolver.resolve(cls, parent_type, dependency_chain)

            # Re-raise the original exception if lazy loading didn't help
            raise
        except Exception as e:
            if isinstance(e, CircularDependencyError):
                raise
            else:
                raise DependencyResolutionError(cls, f"Failed to resolve {cls.__name__}: {e!s}")

    def get_optional(self, dependency_type: type[T]) -> Optional[T]:  # type: ignore[override]
        """Get an optional instance of the specified type."""
        try:
            return self.get(dependency_type)
        except (DependencyResolutionError, UnregisteredDependencyError):
            return None

    def get_all(self, dependency_type: type[T]) -> list[T]:
        """Get all instances of the specified type."""
        instance = self.get_optional(dependency_type)
        return [instance] if instance is not None else []

    def register_command_handler(self, command_type: type, handler_type: type) -> None:
        """Register a command handler."""
        self._cqrs_registry.register_command_handler(command_type, handler_type)
        if not self._service_registry.is_registered(handler_type):
            self._service_registry.register_type(handler_type, handler_type)

    def register_query_handler(self, query_type: type, handler_type: type) -> None:
        """Register a query handler."""
        self._cqrs_registry.register_query_handler(query_type, handler_type)
        if not self._service_registry.is_registered(handler_type):
            self._service_registry.register_type(handler_type, handler_type)

    def register_event_handler(self, event_type: type, handler_type: type) -> None:
        """Register an event handler."""
        self._cqrs_registry.register_event_handler(event_type, handler_type)
        if not self._service_registry.is_registered(handler_type):
            self._service_registry.register_type(handler_type, handler_type)

    def get_command_handler(self, command_type: type) -> Any:
        """Get command handler for a command type."""
        handler_type = self._cqrs_registry.get_command_handler_type(command_type)
        if handler_type is None:
            raise DependencyResolutionError(
                command_type,
                f"No command handler registered for {command_type.__name__}",
            )
        return self.get(handler_type)

    def get_query_handler(self, query_type: type) -> Any:
        """Get query handler for a query type."""
        handler_type = self._cqrs_registry.get_query_handler_type(query_type)
        if handler_type is None:
            raise DependencyResolutionError(
                query_type, f"No query handler registered for {query_type.__name__}"
            )
        return self.get(handler_type)

    def get_event_handlers(self, event_type: type) -> list[Any]:
        """Get event handlers for an event type."""
        handler_types = self._cqrs_registry.get_event_handler_types(event_type)
        return [self.get(handler_type) for handler_type in handler_types]

    def register_injectable_class(self, cls: type[T]) -> None:
        """Register a class as injectable."""
        self._service_registry.register_injectable_class(cls)

        if hasattr(cls, "_command_type"):
            self.register_command_handler(cls._command_type, cls)  # type: ignore[attr-defined]
        if hasattr(cls, "_query_type"):
            self.register_query_handler(cls._query_type, cls)  # type: ignore[attr-defined]
        if hasattr(cls, "_event_type"):
            self.register_event_handler(cls._event_type, cls)  # type: ignore[attr-defined]

    # ========== LAZY LOADING METHODS ==========

    def register_lazy_factory(self, cls: type[T], factory) -> None:
        """Register a lazy factory that creates instances on first access."""
        if self._lazy_config.enabled:
            with self._lock:
                self._lazy_factories[cls] = factory
                logger.debug("Registered lazy factory for %s", cls.__name__)
        else:
            # Fallback to immediate registration
            self.register_factory(cls, factory)

    def register_on_demand(self, cls: type[T], registration_func) -> None:
        """Register a function that will register the service on first access."""
        if self._lazy_config.enabled:
            with self._lock:
                self._on_demand_registrations[cls] = registration_func
                logger.debug("Registered on-demand registration for %s", cls.__name__)
        else:
            # Immediate registration
            registration_func(self)

    def _register_on_demand(self, cls: type[T]) -> None:
        """Register a service on-demand if lazy registration is available."""
        if not self._lazy_config.enabled:
            return

        with self._lock:
            # Check if we have a lazy factory
            if cls in self._lazy_factories:
                factory = self._lazy_factories.pop(cls)
                self.register_factory(cls, factory)
                logger.debug("Lazy factory registered for %s", cls.__name__)
                return

            # Check if we have an on-demand registration
            if cls in self._on_demand_registrations:
                registration_func = self._on_demand_registrations.pop(cls)
                registration_func(self)
                logger.debug("On-demand registration completed for %s", cls.__name__)
                return

            # Try to auto-register injectable classes
            if is_injectable(cls):
                self.register_injectable_class(cls)
                logger.debug("Auto-registered injectable class %s", cls.__name__)
                return

    def is_lazy_loading_enabled(self) -> bool:
        """Check if lazy loading is enabled."""
        return self._lazy_config.enabled

    def get_lazy_config(self) -> LazyLoadingConfig:
        """Get the lazy loading configuration."""
        return self._lazy_config

    def clear(self) -> None:
        """Clear all registrations."""
        with self._lock:
            self._service_registry.clear()
            self._cqrs_registry.clear()
            self._dependency_resolver.clear_cache()
            logger.info("DI Container cleared")

    def get_stats(self) -> dict[str, Any]:
        """Get container statistics."""
        with self._lock:
            return {
                "service_registry": self._service_registry.get_stats(),
                "cqrs_registry": self._cqrs_registry.get_stats(),
                "container_type": "modular",
            }

    def validate_required_ports(self, required_types: list[type]) -> list[str]:
        """Validate that all required port types are registered.

        Args:
            required_types: List of types that must be registered.

        Returns:
            List of error messages for missing registrations (empty = all present).
        """
        missing = [
            t.__name__ for t in required_types if not self._service_registry.is_registered(t)
        ]
        if missing:
            logger.warning("DI container missing required registrations: %s", missing)
        return missing


# Singleton container management
_container_instance: Optional[DIContainer] = None
_container_lock = threading.Lock()
_container_ready = threading.Event()

# Composition root factory hook — set by orb.bootstrap at import time
_container_factory: Optional[Any] = None


def set_container_factory(fn: Any) -> None:
    """Register the composition root factory.

    Must be called (by importing orb.bootstrap) before get_container() is
    first invoked.  The factory receives the bare DIContainer and is
    responsible for registering all services.
    """
    global _container_factory
    _container_factory = fn


def get_container() -> DIContainer:
    """Get the singleton DI container instance."""
    global _container_instance

    with _container_lock:
        if _container_instance is None:
            _container_instance = _create_configured_container()
            _container_ready.set()  # Signal that container is ready
        return _container_instance


def is_container_ready() -> bool:
    """Check if the container is fully initialized and ready for use."""
    return _container_ready.is_set()


def _create_configured_container() -> DIContainer:
    """Create and configure the DI container."""
    container = DIContainer()

    if _container_factory is None:
        raise RuntimeError(
            "No container factory registered. Import orb.bootstrap before calling get_container()."
        )

    _container_factory(container)

    # Validate required ports are registered at startup
    from orb.application.ports.command_bus_port import CommandBusPort
    from orb.application.ports.query_bus_port import QueryBusPort
    from orb.domain.base.ports import ConfigurationPort, ContainerPort, LoggingPort

    missing = container.validate_required_ports(
        [LoggingPort, ConfigurationPort, ContainerPort, CommandBusPort, QueryBusPort]
    )
    if missing:
        logger.warning("Container startup: missing required port registrations: %s", missing)

    logger.info("DI Container configured and ready")
    return container


def create_container() -> DIContainer:
    """Create a new isolated DI container instance (not the singleton)."""
    return _create_configured_container()


def reset_container() -> None:
    """Reset the global container instance."""
    global _container_instance
    with _container_lock:
        if _container_instance:
            _container_instance.clear()
        _container_instance = None
        _container_ready.clear()  # add this line


__all__: list[str] = [
    "DIContainer",
    "create_container",
    "get_container",
    "reset_container",
    "set_container_factory",
    "timed_operation",
]
