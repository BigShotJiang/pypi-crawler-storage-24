"""Storage factory components."""
