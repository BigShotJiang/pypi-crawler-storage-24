"""Common configuration schemas."""

from typing import Optional

from pydantic import BaseModel, Field, field_validator, model_validator


class ResourcePrefixConfig(BaseModel):
    """Resource prefix configuration."""

    default: str = Field("", description="Default prefix for all resources")
    request: str = Field("req-", description="Prefix for acquire request IDs")
    return_prefix: str = Field("ret-", description="Prefix for return request IDs")
    launch_template: str = Field("", description="Prefix for launch template names")
    instance: str = Field("", description="Prefix for instance names")
    fleet: str = Field("", description="Prefix for EC2 Fleet names")
    spot_fleet: str = Field("", description="Prefix for Spot Fleet names")
    asg: str = Field("", description="Prefix for Auto Scaling group names")
    tag: str = Field("", description="Prefix for resource tags")


class ResourceConfig(BaseModel):
    """Resource configuration."""

    default_prefix: str = Field("", description="Default prefix for all resources")
    prefixes: ResourcePrefixConfig = Field(default_factory=lambda: ResourcePrefixConfig())  # type: ignore[call-arg]

    @model_validator(mode="after")
    def set_default_prefix(self) -> "ResourceConfig":
        """Set default prefix if not provided."""
        if not self.default_prefix:
            object.__setattr__(self, "default_prefix", self.prefixes.default)
        return self


class PrefixConfig(BaseModel):
    """Prefix configuration."""

    default: str = Field("", description="Default prefix for all resources")
    request: str = Field("req-", description="Prefix for acquire request IDs")
    return_prefix: str = Field("ret-", description="Prefix for return request IDs")
    launch_template: str = Field("", description="Prefix for launch template names")
    instance: str = Field("", description="Prefix for instance names")
    fleet: str = Field("", description="Prefix for fleet names")
    asg: str = Field("", description="Prefix for Auto Scaling group names")
    tag: str = Field("", description="Prefix for resource tags")


class StatusValuesConfig(BaseModel):
    """Status values configuration."""

    request: dict[str, str] = Field(
        default_factory=lambda: {
            "pending": "pending",
            "running": "running",
            "complete": "complete",
            "complete_with_error": "complete_with_error",
            "failed": "failed",
        },
        description="Request status values",
    )
    machine: dict[str, str] = Field(
        default_factory=lambda: {
            "pending": "pending",
            "running": "running",
            "stopping": "stopping",
            "stopped": "stopped",
            "shutting_down": "shutting-down",
            "terminated": "terminated",
            "unknown": "unknown",
        },
        description="Machine status values",
    )
    machine_result: dict[str, str] = Field(
        default_factory=lambda: {
            "executing": "executing",
            "succeed": "succeed",
            "fail": "fail",
        },
        description="Machine result values",
    )
    circuit_breaker: dict[str, str] = Field(
        default_factory=lambda: {
            "closed": "closed",
            "open": "open",
            "half_open": "half_open",
        },
        description="Circuit breaker state values",
    )


class NamingConfig(BaseModel):
    """Naming configuration."""

    collections: dict[str, str] = Field(
        default_factory=lambda: {
            "requests": "requests",
            "machines": "machines",
            "templates": "templates",
        },
        description="Collection names for NoSQL databases",
    )
    tables: dict[str, str] = Field(
        default_factory=lambda: {
            "requests": "requests",
            "machines": "machines",
            "event_logs": "event_logs",
            "audit_logs": "audit_logs",
            "metrics_logs": "metrics_logs",
        },
        description="Table names for SQL databases",
    )
    fleet_types: dict[str, str] = Field(
        default_factory=lambda: {
            "instant": "instant",
            "request": "request",
            "maintain": "maintain",
        },
        description="Fleet types for EC2 Fleet and Spot Fleet",
    )
    price_types: dict[str, str] = Field(
        default_factory=lambda: {
            "ondemand": "ondemand",
            "spot": "spot",
            "heterogeneous": "heterogeneous",
        },
        description="Price types for templates",
    )
    statuses: StatusValuesConfig = Field(default_factory=lambda: StatusValuesConfig())
    patterns: dict[str, str] = Field(
        default_factory=lambda: {
            "ec2_instance": r"^i-[a-f0-9]+$",
            "spot_fleet": r"^sfr-[a-f0-9]+$",
            "ec2_fleet": r"^fleet-[a-f0-9]+$",
            "asg": r"^[a-zA-Z0-9_-]+$",
            "instance_type": r"^[a-z][0-9][a-z]?\.[a-z0-9]+$",
            "region": r"^[a-z]{2}-[a-z]+-\d$",
            "request_id": r"^(req|ret)-[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$",
            "tag_key": r"^[\w\s+=.@-]+$",
            "cidr_block": r"^(\d{1,3}\.){3}\d{1,3}/\d{1,2}$",
        },
        description="Validation patterns for various resources",
    )
    prefixes: PrefixConfig = Field(default_factory=lambda: PrefixConfig())  # type: ignore[call-arg]


class RequestConfig(BaseModel):
    """Request configuration."""

    max_machines_per_request: int = Field(100, description="Maximum number of machines per request")
    default_grace_period: int = Field(
        300, description="Default grace period in seconds for return requests"
    )
    fulfillment_max_retries: int = Field(
        3, description="Maximum number of provisioning retry attempts"
    )
    fulfillment_timeout_seconds: int = Field(300, description="Provisioning timeout in seconds")
    fulfillment_batch_size: int = Field(
        1000, description="Maximum instances per provisioning attempt"
    )
    fulfillment_fallback_template_id: Optional[str] = Field(
        None, description="Fallback template ID for provisioning"
    )
    default_timeout: int = Field(3600, description="Default request timeout in seconds")

    @field_validator("max_machines_per_request")
    @classmethod
    def validate_max_machines(cls, v: int) -> int:
        """Validate max machines per request."""
        if v < 1:
            raise ValueError("Maximum machines per request must be at least 1")
        return v


class DatabaseConfig(BaseModel):
    """Database configuration."""

    connection_timeout: int = Field(30, description="Database connection timeout in seconds")
    query_timeout: int = Field(60, description="Database query timeout in seconds")
    max_connections: int = Field(10, description="Maximum number of database connections")

    @field_validator("connection_timeout", "query_timeout")
    @classmethod
    def validate_timeouts(cls, v: int) -> int:
        """Validate timeout values."""
        if v < 1:
            raise ValueError("Timeout must be at least 1 second")
        return v

    @field_validator("max_connections")
    @classmethod
    def validate_max_connections(cls, v: int) -> int:
        """Validate max connections."""
        if v < 1:
            raise ValueError("Maximum connections must be at least 1")
        return v


class EventsConfig(BaseModel):
    """Events configuration."""

    enabled: bool = Field(True, description="Whether events are enabled")
    max_events_per_request: int = Field(1000, description="Maximum number of events per request")
    event_retention_days: int = Field(30, description="Number of days to retain events")

    @field_validator("max_events_per_request")
    @classmethod
    def validate_max_events(cls, v: int) -> int:
        """Validate max events per request."""
        if v < 1:
            raise ValueError("Maximum events per request must be at least 1")
        return v

    @field_validator("event_retention_days")
    @classmethod
    def validate_retention_days(cls, v: int) -> int:
        """Validate event retention days."""
        if v < 1:
            raise ValueError("Event retention days must be at least 1")
        return v
