"""Configuration type conversion utilities."""

from typing import Any, Optional, TypeVar

from orb.domain.base.exceptions import ConfigurationError
from orb.infrastructure.logging.logger import get_logger

T = TypeVar("T")
logger = get_logger(__name__)


class ConfigTypeConverter:
    """Handles type conversion for configuration values."""

    def __init__(self, raw_config: dict[str, Any]) -> None:
        """Initialize the instance."""
        self._raw_config = raw_config

    def get(self, key: str, default: Any = None) -> Any:
        """Get configuration value by key with dot notation support."""
        keys = key.split(".")
        value = self._raw_config

        try:
            for k in keys:
                if isinstance(value, dict):
                    value = value[k]
                else:
                    return default
            return value
        except (KeyError, TypeError):
            return default

    def get_bool(self, key: str, default: bool = False) -> bool:
        """Get boolean configuration value."""
        value = self.get(key, default)
        if isinstance(value, bool):
            return value
        if isinstance(value, str):
            return value.lower() in ("true", "1", "yes", "on")
        return bool(value)

    def get_int(self, key: str, default: int = 0) -> int:
        """Get integer configuration value."""
        value = self.get(key, default)
        try:
            return int(value)
        except (ValueError, TypeError):
            logger.warning("Could not convert config value '%s' to int", key, exc_info=True)
            return default

    def get_float(self, key: str, default: float = 0.0) -> float:
        """Get float configuration value."""
        value = self.get(key, default)
        try:
            return float(value)
        except (ValueError, TypeError):
            logger.warning("Could not convert config value '%s' to float", key, exc_info=True)
            return default

    def get_str(self, key: str, default: str = "") -> str:
        """Get string configuration value."""
        value = self.get(key, default)
        return str(value) if value is not None else default

    def get_list(self, key: str, default: Optional[list[Any]] = None) -> list[Any]:
        """Get list configuration value."""
        if default is None:
            default = []

        value = self.get(key, default)
        if isinstance(value, list):
            return value
        elif isinstance(value, str):
            # Try to parse comma-separated values
            return [item.strip() for item in value.split(",") if item.strip()]
        else:
            return default

    def get_dict(self, key: str, default: Optional[dict[str, Any]] = None) -> dict[str, Any]:
        """Get dictionary configuration value."""
        if default is None:
            default = {}

        value = self.get(key, default)
        return value if isinstance(value, dict) else default

    def get_typed(self, config_class: type[T]) -> T:
        """Create typed configuration object from raw config."""
        try:
            class_name = config_class.__name__

            # Special handling for AppConfig - it uses the entire raw config
            if class_name == "AppConfig":
                return config_class(**self._raw_config)

            # For provider-specific config classes registered in ProviderSettingsRegistry,
            # resolve from the active provider config rather than a top-level section.
            from orb.config.schemas.provider_settings_registry import ProviderSettingsRegistry

            for provider_type, registered_cls in ProviderSettingsRegistry._settings_classes.items():
                if registered_cls is config_class or (
                    isinstance(config_class, type) and issubclass(config_class, registered_cls)
                ):
                    return self._get_provider_config_for_type(provider_type, config_class)

            # Other config classes use their respective sections
            section_name = class_name.replace("Config", "").lower()
            config_data = self.get_dict(section_name, {})

            # Create instance with validation
            return config_class(**config_data)
        except Exception as e:
            logger.error(
                "Failed to create typed config for %s: %s", config_class.__name__, e, exc_info=True
            )
            raise ConfigurationError(f"Invalid configuration for {config_class.__name__}: {e}")

    def _get_provider_config_for_type(self, provider_type: str, config_class: type[T]) -> T:
        """Get provider configuration for the given provider type from the provider strategy system."""
        try:
            # Get provider configuration
            provider_config = self.get_dict("provider", {})

            # Get from provider instances (provider strategy)
            providers = provider_config.get("providers", [])
            active_provider = provider_config.get("active_provider")

            # Find the active provider of the requested type, or first enabled one
            matched_config = None

            # First, try to find the active provider if specified
            if active_provider:
                for provider in providers:
                    if (
                        provider.get("name") == active_provider
                        and provider.get("type") == provider_type
                        and provider.get("enabled", True)
                    ):
                        matched_config = provider.get("config", {})
                        logger.debug(
                            "Using %s config from active provider: %s",
                            provider_type,
                            active_provider,
                        )
                        break

            # If no active provider found, use first enabled provider of the requested type
            if not matched_config:
                for provider in providers:
                    if provider.get("type") == provider_type and provider.get("enabled", True):
                        matched_config = provider.get("config", {})
                        logger.debug(
                            "Using %s config from provider: %s",
                            provider_type,
                            provider.get("name"),
                        )
                        break

            if matched_config is not None:
                return config_class(**matched_config)
            else:
                raise ValueError(f"No enabled {provider_type} provider found in configuration")

        except Exception as e:
            logger.error(
                "Failed to resolve %s provider config: %s", provider_type, e, exc_info=True
            )
            raise

    def set(self, key: str, value: Any) -> None:
        """Set configuration value by key with dot notation support."""
        keys = key.split(".")
        config = self._raw_config

        # Navigate to the parent of the target key
        for k in keys[:-1]:
            if k not in config:
                config[k] = {}
            config = config[k]

        # Set the final value
        config[keys[-1]] = value

    def update(self, updates: dict[str, Any]) -> None:
        """Update configuration with new values."""

        def deep_update(base_dict: dict[str, Any], update_dict: dict[str, Any]) -> None:
            """Recursively update nested dictionary values."""
            for key, value in update_dict.items():
                if (
                    key in base_dict
                    and isinstance(base_dict[key], dict)
                    and isinstance(value, dict)
                ):
                    deep_update(base_dict[key], value)
                else:
                    base_dict[key] = value

        deep_update(self._raw_config, updates)
