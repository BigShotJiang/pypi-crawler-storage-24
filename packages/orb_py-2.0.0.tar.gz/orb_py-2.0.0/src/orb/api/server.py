"""FastAPI server factory and application setup."""

from pathlib import Path
from typing import TYPE_CHECKING, Any, cast

try:
    from fastapi import FastAPI
    from fastapi.middleware.cors import CORSMiddleware
    from fastapi.middleware.trustedhost import TrustedHostMiddleware
    from fastapi.responses import JSONResponse, Response

    FASTAPI_AVAILABLE = True
except ImportError:
    FASTAPI_AVAILABLE = False
    FastAPI = None  # type: ignore[assignment,misc]
    CORSMiddleware = None  # type: ignore[assignment,misc]
    TrustedHostMiddleware = None  # type: ignore[assignment,misc]
    JSONResponse = None  # type: ignore[assignment,misc]
    Response = None  # type: ignore[assignment,misc]

if TYPE_CHECKING:
    from fastapi import FastAPI
    from fastapi.middleware.cors import CORSMiddleware
    from fastapi.middleware.trustedhost import TrustedHostMiddleware
    from fastapi.responses import JSONResponse, Response

from orb._package import __version__
from orb.domain.base.exceptions import ConfigurationError
from orb.infrastructure.auth.registry import get_auth_registry
from orb.infrastructure.logging.logger import get_logger


def create_fastapi_app(server_config: Any) -> Any:
    """
    Create and configure FastAPI application.

    Args:
        server_config: Server configuration

    Returns:
        Configured FastAPI application

    Raises:
        ImportError: If FastAPI is not installed
    """
    if not FASTAPI_AVAILABLE:
        raise ImportError(
            "FastAPI not installed. API mode requires FastAPI.\n"
            "Install with: pip install orb-py[api]"
        )

    logger = get_logger(__name__)

    # Validate and default configuration
    if server_config is None:
        logger.warning("No server configuration provided, using defaults")
        from orb.config.schemas.server_schema import ServerConfig

        server_config = ServerConfig()  # type: ignore[call-arg]

    # Validate configuration object has required attributes
    if not hasattr(server_config, "docs_enabled"):
        logger.error("Invalid server configuration: missing docs_enabled attribute")
        from orb.config.schemas.server_schema import ServerConfig

        server_config = ServerConfig()  # type: ignore[call-arg]

    from orb.api.documentation import configure_openapi
    from orb.api.middleware import AuthMiddleware, LoggingMiddleware
    from orb.infrastructure.error.exception_handler import get_exception_handler

    # Create FastAPI app with configuration
    app = FastAPI(  # type: ignore[operator]
        title="Open Resource Broker API",
        description="REST API for Open Resource Broker - Dynamic cloud resource provisioning",
        version=__version__,
        docs_url=server_config.docs_url if server_config.docs_enabled else None,
        redoc_url=server_config.redoc_url if server_config.docs_enabled else None,
        openapi_url=server_config.openapi_url if server_config.docs_enabled else None,
    )

    logger = get_logger(__name__)

    # Add trusted host middleware if configured
    if server_config.trusted_hosts and server_config.trusted_hosts != ["*"]:
        app.add_middleware(TrustedHostMiddleware, allowed_hosts=server_config.trusted_hosts)  # type: ignore[arg-type]

    # Add CORS middleware
    if server_config.cors.enabled:
        app.add_middleware(  # type: ignore[arg-type]
            cast(Any, CORSMiddleware),
            allow_origins=server_config.cors.origins,
            allow_credentials=server_config.cors.credentials,
            allow_methods=server_config.cors.methods,
            allow_headers=server_config.cors.headers,
        )
        logger.info("CORS middleware enabled")

    # Add logging middleware
    app.add_middleware(LoggingMiddleware)
    logger.info("Logging middleware enabled")

    # Add authentication middleware if enabled
    if server_config.auth.enabled:
        auth_strategy = _create_auth_strategy(server_config.auth)
        if auth_strategy:
            app.add_middleware(
                AuthMiddleware,
                auth_port=auth_strategy,
                require_auth=True,
                trusted_proxies=server_config.trusted_proxies,
            )
            logger.info(
                "Authentication middleware enabled with strategy: %s",
                auth_strategy.get_strategy_name(),
            )
        else:
            raise ConfigurationError(
                f"Authentication enabled but strategy '{server_config.auth.strategy}' could not be created"
            )

    # Add global exception handler
    exception_handler = get_exception_handler()

    @app.exception_handler(Exception)
    async def global_exception_handler(request: Any, exc: Exception) -> Any:
        """Global exception handler for all unhandled exceptions."""
        try:
            # Use the existing exception handler infrastructure
            error_response = exception_handler.handle_error_for_http(exc)
            return JSONResponse(  # type: ignore[misc]
                status_code=error_response.http_status or 500,
                content={
                    "success": False,
                    "error": {
                        "code": (
                            error_response.error_code.value
                            if not isinstance(error_response.error_code, str)
                            else error_response.error_code
                        ),
                        "message": error_response.message,
                        "details": error_response.details,
                    },
                    "timestamp": error_response.timestamp.isoformat()
                    if hasattr(error_response.timestamp, "isoformat")
                    else error_response.timestamp,
                    "request_id": getattr(request.state, "request_id", "unknown"),
                },
            )
        except Exception as handler_error:
            # Fallback error response
            logger.error("Exception handler failed: %s", handler_error, exc_info=True)
            return JSONResponse(  # type: ignore[misc]
                status_code=500,
                content={
                    "success": False,
                    "error": {
                        "code": "INTERNAL_ERROR",
                        "message": "An internal server error occurred",
                    },
                },
            )

    # Add health check endpoint
    @app.get("/health", tags=["System"])
    async def health_check() -> Any:
        """Health check endpoint."""
        from orb.domain.base.ports.health_check_port import HealthCheckPort
        from orb.infrastructure.di.container import get_container

        try:
            health_port = get_container().get(HealthCheckPort)
            health_port.run_all_checks()
            status = health_port.get_status()
        except Exception:
            status = {"status": "unknown"}

        status = {"service": "open-resource-broker", "version": __version__, **status}
        http_status = 503 if status.get("status") == "unhealthy" else 200
        return JSONResponse(content=status, status_code=http_status)  # type: ignore[misc]

    # Add metrics endpoint
    @app.get("/metrics", tags=["System"])
    async def metrics() -> Any:
        """Prometheus metrics endpoint."""
        from orb.infrastructure.di.container import get_container
        from orb.monitoring.metrics import MetricsCollector

        try:
            collector = get_container().get_optional(MetricsCollector)
            if collector is None:
                return Response(content="", media_type="text/plain; version=0.0.4")  # type: ignore[misc]
            prometheus_text = collector.to_prometheus_text()
            return Response(content=prometheus_text, media_type="text/plain; version=0.0.4")  # type: ignore[misc]
        except Exception:
            return Response(content="", media_type="text/plain; version=0.0.4")  # type: ignore[misc]

    # Add info endpoint
    @app.get("/info", tags=["System"])
    async def info() -> dict[str, Any]:
        """Service information endpoint."""
        return {
            "service": "open-resource-broker",
            "version": __version__,
            "description": "REST API for Open Resource Broker",
            "auth_enabled": server_config.auth.enabled,
            "auth_strategy": (server_config.auth.strategy if server_config.auth.enabled else None),
        }

    # Serve favicon from project logo assets
    _favicon_path = Path(__file__).resolve().parents[3] / "docs" / "assets" / "orb-icon.png"
    if _favicon_path.exists():

        @app.get("/favicon.ico", include_in_schema=False)
        async def favicon() -> Any:
            from fastapi.responses import FileResponse

            return FileResponse(_favicon_path, media_type="image/png")

    # Register API routers
    _register_routers(app)

    # Configure OpenAPI documentation
    configure_openapi(app, server_config)

    logger.info("FastAPI application created with %s routes", len(app.routes))
    return app


def _create_auth_strategy(auth_config: Any) -> Any:
    """
    Create authentication strategy based on configuration.

    Args:
        auth_config: Authentication configuration

    Returns:
        Authentication strategy instance or None
    """
    logger = get_logger(__name__)

    strategy_name = getattr(auth_config, "strategy", "unknown")
    try:
        auth_registry = get_auth_registry()

        if strategy_name == "none":
            return auth_registry.get_strategy("none", enabled=False)

        elif strategy_name == "bearer_token":
            bearer_config = auth_config.bearer_token or {}
            secret_key = bearer_config.get("secret_key")
            if not secret_key:
                raise ConfigurationError(
                    "Bearer token authentication requires a secret_key in auth.bearer_token config. "
                    "Set HF_AUTH_BEARER_SECRET_KEY or configure auth.bearer_token.secret_key."
                )
            if len(secret_key.encode()) < 32:
                raise ConfigurationError(
                    "Bearer token secret_key must be at least 32 bytes for security."
                )
            return auth_registry.get_strategy(
                "bearer_token",
                secret_key=secret_key,
                algorithm=bearer_config.get("algorithm", "HS256"),
                token_expiry=bearer_config.get("token_expiry", 3600),
                enabled=True,
            )

        elif strategy_name == "iam":
            iam_config = (auth_config.provider_auth or {}).get("iam") or {}
            # Register AWS IAM strategy if not already registered
            try:
                from orb.providers.aws.auth.iam_strategy import IAMAuthStrategy

                auth_registry.register_strategy("iam", IAMAuthStrategy)
            except ImportError:
                logger.warning("AWS IAM strategy not available", exc_info=True)
                return None

            return auth_registry.get_strategy(
                "iam",
                region=iam_config.get("region", "us-east-1"),
                profile=iam_config.get("profile"),
                required_actions=iam_config.get("required_actions", []),
                enabled=True,
            )

        elif strategy_name == "cognito":
            cognito_config = (auth_config.provider_auth or {}).get("cognito") or {}
            # Register AWS Cognito strategy if not already registered
            try:
                from orb.providers.aws.auth.cognito_strategy import CognitoAuthStrategy

                auth_registry.register_strategy("cognito", CognitoAuthStrategy)
            except ImportError:
                logger.warning("AWS Cognito strategy not available", exc_info=True)
                return None

            return auth_registry.get_strategy(
                "cognito",
                user_pool_id=cognito_config.get("user_pool_id", ""),
                client_id=cognito_config.get("client_id", ""),
                region=cognito_config.get("region", "us-east-1"),
                enabled=True,
            )

        else:
            logger.error("Unknown authentication strategy: %s", strategy_name)
            return None

    except Exception as e:
        raise ConfigurationError(f"Failed to create auth strategy '{strategy_name}': {e}") from e


def _register_routers(app: Any) -> None:
    """
    Register API routers.

    Args:
        app: FastAPI application
    """
    try:
        from orb.api.routers import machines, requests, templates

        app.include_router(templates.router, prefix="/api/v1")
        app.include_router(machines.router, prefix="/api/v1")
        app.include_router(requests.router, prefix="/api/v1")

    except ImportError as e:
        logger = get_logger(__name__)
        logger.error("Failed to import routers: %s", e, exc_info=True)
        # Continue without routers - they might not be fully implemented yet
