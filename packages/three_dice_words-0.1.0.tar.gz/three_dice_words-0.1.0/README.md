# three-dice-words (Python)

Generate 3-word hyphenated identifiers from the EFF long Diceware wordlist.

**Minimal API (defaults: bundled wordlist, crypto RNG):**

```python
from three_dice_words import generate_threewords, generate_threewords_batch

generate_threewords()           # e.g. "lantern-galaxy-cactus"
generate_threewords_batch(10)   # list of 10 IDs
```

**Customize (wordlist path, RNG):** `load_wordlist`, `generate`, `generate_batch`.

**Test scaling (serial vs batch, 1 … 1M):** `poetry run python scripts/test_scaling.py`
