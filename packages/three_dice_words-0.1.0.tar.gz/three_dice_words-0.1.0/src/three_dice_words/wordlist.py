"""Load the EFF long Diceware wordlist into memory."""

from pathlib import Path


def load_wordlist(path: str | Path | None = None) -> list[str]:
    """Load the EFF long wordlist (7776 words) into an immutable-style list.

    Args:
        path: Optional path to wordlist file. If None, uses the bundled wordlist
              next to this module (format: one line per word, "number word" or "word").

    Returns:
        List of 7776 lowercase words.
    """
    if path is None:
        path = Path(__file__).parent / "wordlist.txt"
    path = Path(path)
    words: list[str] = []
    with path.open(encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            # EFF format: "11111 abacus" -> take second part
            parts = line.split()
            if len(parts) >= 2:
                words.append(parts[1].lower())
            else:
                words.append(parts[0].lower())
    if len(words) != 7776:
        raise ValueError(f"expected 7776 words, got {len(words)}")
    return words
