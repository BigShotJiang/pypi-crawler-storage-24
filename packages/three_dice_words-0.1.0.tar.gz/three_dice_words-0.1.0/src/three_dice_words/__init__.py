"""Generate 3-word hyphenated identifiers from the EFF long Diceware wordlist."""

import random

from three_dice_words.generator import generate, generate_batch
from three_dice_words.wordlist import load_wordlist

_cached_wordlist: list[str] | None = None


def _get_wordlist() -> list[str]:
    global _cached_wordlist
    if _cached_wordlist is None:
        _cached_wordlist = load_wordlist()
    return _cached_wordlist


def generate_threewords(
    *,
    rng: random.Random | None = None,
) -> str:
    """Generate a single 3-word ID. Uses bundled wordlist (cached)."""
    return generate(_get_wordlist(), rng=rng)


def generate_threewords_batch(
    count: int,
    *,
    rng: random.Random | None = None,
) -> list[str]:
    """Generate `count` 3-word IDs. Uses bundled wordlist (cached)."""
    return generate_batch(_get_wordlist(), count, rng=rng)


__all__ = [
    "load_wordlist",
    "generate",
    "generate_batch",
    "generate_threewords",
    "generate_threewords_batch",
]
