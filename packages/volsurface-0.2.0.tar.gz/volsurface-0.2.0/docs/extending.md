# Extending volsurface

Adding a new volatility model requires implementing one interface. The rest of the library — `calibrate_surface`, `plot_smile`, `diagnose_surface`, `check_butterfly` — works with any model that satisfies it.

## The VolModel interface

Three methods are required:

```python
from volsurface.models.base import VolModel
from volsurface.core import FitResult, MarketSlice
import numpy as np
import numpy.typing as npt


class VolModel:
    @property
    def n_params(self) -> int:
        """Number of free parameters in the model."""
        ...

    def fit(self, market_slice: MarketSlice) -> FitResult:
        """Calibrate model parameters to a market slice.

        Args:
            market_slice: Cleaned market data. Use
                market_slice.log_moneyness and
                market_slice.total_variance as inputs.

        Returns:
            FitResult with params, residuals, rmse, success,
            message, and n_iterations.
        """
        ...

    def total_variance(
        self,
        log_moneyness: float | npt.NDArray[np.float64],
    ) -> npt.NDArray[np.float64]:
        """Compute model total variance w(k) = sigma^2 * T.

        Args:
            log_moneyness: Scalar or array of ln(K/F) values.

        Returns:
            Array of total variance values.
        """
        ...
```

Inheriting from `VolModel` gives you a default `iv()` implementation for free:

```python
def iv(self, log_moneyness) -> npt.NDArray[np.float64]:
    """Implied volatility from total_variance / expiry_years."""
    ...
```

This default requires `self._expiry_years` to be set in `__init__`. See [`models/base.py`](api/models.md) for the full base class.

## Example: SABR skeleton

A minimal SABR implementation showing the pattern:

```python
from __future__ import annotations

import numpy as np
import numpy.typing as npt
from scipy.optimize import minimize

from volsurface.core import FitResult, MarketSlice
from volsurface.models.base import VolModel


class SABR(VolModel):
    """SABR volatility model (Hagan et al. 2002).

    Parameters alpha, beta, rho, nu are calibrated per expiry.
    """

    def __init__(self, beta: float = 0.5) -> None:
        self._beta = beta          # fixed; user-supplied
        self._alpha: float = 0.0
        self._rho: float = 0.0
        self._nu: float = 0.0
        self._expiry_years: float | None = None

    @property
    def n_params(self) -> int:
        return 3  # alpha, rho, nu (beta is fixed)

    def fit(self, market_slice: MarketSlice) -> FitResult:
        self._expiry_years = market_slice.expiry_years
        k = market_slice.log_moneyness
        w_market = market_slice.total_variance

        def objective(x: npt.NDArray[np.float64]) -> float:
            self._alpha, self._rho, self._nu = x[0], x[1], x[2]
            w_model = self.total_variance(k)
            return float(np.sum((w_model - w_market) ** 2))

        x0 = np.array([0.2, -0.3, 0.4])
        bounds = [(1e-4, 2.0), (-0.999, 0.999), (1e-4, 3.0)]
        res = minimize(objective, x0=x0, method="L-BFGS-B", bounds=bounds)

        self._alpha, self._rho, self._nu = res.x[0], res.x[1], res.x[2]
        residuals = self.total_variance(k) - w_market
        rmse = float(np.sqrt(np.mean(residuals ** 2)))

        return FitResult(
            params={"alpha": self._alpha, "rho": self._rho, "nu": self._nu},
            residuals=residuals,
            rmse=rmse,
            success=bool(res.success),
            message=str(res.message),
            n_iterations=int(res.nit),
        )

    def total_variance(
        self,
        log_moneyness: float | npt.NDArray[np.float64],
    ) -> npt.NDArray[np.float64]:
        # Placeholder: insert Hagan et al. (2002) formula here
        k = self._to_array(log_moneyness)
        T = self._expiry_years or 1.0
        # ... SABR implied vol formula -> convert to total variance
        iv_sabr = self._alpha * np.ones_like(k)  # stub
        return np.asarray(iv_sabr ** 2 * T, dtype=np.float64)
```

## Plugging in

Once implemented, the model works with all standard library functions:

```python
from volsurface.calibration import calibrate_surface
from volsurface.plotting import plot_surface
from volsurface.diagnostics import diagnose_surface

result = calibrate_surface(slices, SABR, ticker="SPY")
diag = diagnose_surface(result.surface)
plot_surface(result.surface, kind="3d")
```

## Note on VolModelProtocol

`VolModelProtocol` is a `runtime_checkable` protocol. Custom models do not have to inherit from `VolModel` — they only need to satisfy the `n_params`, `fit`, `total_variance`, and `iv` interface. Inheriting from `VolModel` is the easiest path since it provides the default `iv()` and the `_to_array()` helper, but a standalone class that implements the same methods works equally well.
