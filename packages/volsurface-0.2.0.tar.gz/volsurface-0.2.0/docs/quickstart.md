# Quick Start

This walkthrough fits both Raw SVI and SSVI to SPY options, checks for arbitrage, compares the two models, and produces surface plots.

## Fetching market data

```python
from volsurface.market_data import fetch_chain

slices = fetch_chain("SPY", min_volume=30, moneyness_range=(0.8, 1.2))
print(f"{len(slices)} expiries fetched")
```

`fetch_chain` pulls live option chains from Yahoo Finance and applies several filters in sequence:

- **Liquidity** — strikes with volume below `min_volume` are dropped
- **Moneyness** — only strikes within `[0.8 × spot, 1.2 × spot]` are kept
- **Stale contracts** — contracts where both bid and ask are zero are removed
- **Forward estimation** — the implied forward at each expiry is estimated from put-call parity using mid-prices across matched call/put strikes, with a median aggregator to handle illiquid wings. If fewer than 3 valid pairs exist, it falls back to `spot × exp(rT)`.

The result is a sorted list of [`MarketSlice`](api/core.md) objects, one per expiry.

## Fitting Raw SVI

```python
from volsurface.calibration import calibrate_surface
from volsurface.models import RawSVI

result = calibrate_surface(slices, RawSVI, ticker="SPY")

for t, fr in sorted(result.fit_results.items()):
    status = "ok" if fr.success else "FAILED"
    print(f"  [{status}] T={t:.4f}y  RMSE={fr.rmse:.6f}  ({fr.n_iterations} iters)")
```

`calibrate_surface` fits one `RawSVI` model independently to each expiry, minimising total-variance residuals via L-BFGS-B with multiple data-scaled starting points. Typical output for SPY:

```
  [ok] T=0.0356y  RMSE=0.000842  (12 iters)
  [ok] T=0.0548y  RMSE=0.000631  (15 iters)
  [ok] T=0.1123y  RMSE=0.001247  (18 iters)
  ...
  [ok] T=1.8767y  RMSE=0.006183  (22 iters)
```

RMSE is in implied volatility points (e.g. 0.001 = 0.1 vol point). All 22 expiries converge.

## Checking for arbitrage

```python
report = result.arbitrage_report

print(f"Butterfly violations: {len(report.butterfly_violations)}")
print(f"Calendar violations:  {len(report.calendar_violations)}")
print(f"Clean: {report.is_clean}")
```

The arbitrage report checks three conditions:

- **Butterfly** — each smile must be convex in log-moneyness. Zero violations means every fitted slice is free of local arbitrage.
- **Calendar spread** — total variance must be non-decreasing in time at every log-moneyness level. For SPY with independent per-expiry fits, around 10 out of 21 adjacent expiry pairs typically show calendar violations. This is expected: Raw SVI has no cross-expiry constraint.
- **SVI parameter conditions** — direct checks on the fitted $(a, b, \rho, m, \sigma)$ parameters against the Gatheral-Jacquier no-arbitrage inequalities.

The calendar violations are the motivation for SSVI.

## Querying the surface

```python
point = result.surface.iv(strike=570.0, expiry_years=0.5)
print(f"IV at K=570, T=0.5y: {point.iv:.4f}")
```

For expiries that lie between fitted slices, the surface interpolates linearly in total-variance space — total variance is additive in time under most no-arbitrage conditions, making this the natural interpolation space. The forward price is also linearly interpolated so that both bracketing models are queried at the same log-moneyness point.

## Fitting SSVI

```python
from volsurface.models import SSVI

ssvi = SSVI()
ssvi_slices, ssvi_result = ssvi.fit_surface(slices)

p = ssvi.global_params
print(f"rho={p.rho:.4f}  eta={p.eta:.4f}  gamma={p.gamma:.4f}")
print(f"Surface RMSE: {ssvi_result.rmse:.6f}")
```

SSVI calibrates a single set of global parameters shared across all expiries. Typical values for SPY:

```
rho=-0.7463  eta=1.4684  gamma=0.5021
Surface RMSE: 0.011200
```

The three global parameters have clear interpretations:

- **ρ (rho)** — controls the skew (tilt) of the smile. Strongly negative for equities: left tail is more expensive than right tail.
- **η (eta)** — overall wing steepness scaling. Larger values produce steeper smiles.
- **γ (gamma)** — controls how curvature scales with the ATM variance level. At γ = 0.5 (the Heston limiting case), short-dated options get more curvature than long-dated ones, matching observed market behaviour.

The calibration uses a two-stage approach: first, Raw SVI is fitted independently to each expiry to extract the ATM total variance θ(T); second, the global (ρ, η, γ) are fitted by minimising total-variance residuals across all expiries simultaneously.

## Comparing fits

```python
from volsurface.diagnostics import compare_surfaces
from volsurface.core import VolSurface

# Assemble the SSVI slices into a VolSurface for comparison
ssvi_surface = VolSurface(ticker="SPY (SSVI)")
for ms in slices:
    ssvi_surface.slices[ms.expiry_years] = ssvi_slices[ms.expiry_years]
    ssvi_surface.market_data[ms.expiry_years] = ms

comparison = compare_surfaces(result.surface, ssvi_surface, "Raw SVI", "SSVI")
print(comparison.summary_table())
```

Typical output:

```
                    Raw SVI      SSVI
──────────────────────────────────────────
  T=0.036y  RMSE    0.0008    0.0089
  T=0.055y  RMSE    0.0006    0.0045
  T=0.112y  RMSE    0.0012    0.0031
  T=0.279y  RMSE    0.0023    0.0018
  ...
──────────────────────────────────────────
      Total RMSE    0.0050    0.0112
 Mean slice RMSE    0.0046    0.0098
```

Raw SVI wins on per-slice RMSE because it has 5 free parameters per expiry. SSVI uses only 3 global parameters plus one ATM variance per expiry, trading per-slice accuracy for global consistency. The gap is largest for short-dated expiries where the smile shape is most idiosyncratic; it narrows at longer maturities. Crucially, SSVI eliminates the calendar violations entirely — the surface is calendar-arbitrage-free by construction.

## Plotting

```python
from volsurface.plotting import plot_smile, plot_surface

# Single smile with market data overlay
first_expiry = result.surface.expiries[0]
plot_smile(
    result.surface.market_data[first_expiry],
    model=result.surface.slices[first_expiry],
)

# All SVI smiles overlaid on one chart
plot_surface(result.surface, kind="smiles")

# 3D surface
plot_surface(result.surface, kind="3d")

# The SSVI surface (same calls work on ssvi_surface)
plot_surface(ssvi_surface, kind="3d")
```

`plot_smile` shows market scatter points and the model curve in log-moneyness space. `plot_surface` with `kind="smiles"` overlays all expiry smiles colour-coded from short (dark) to long (light). `kind="3d"` renders the full implied volatility surface over the (log-moneyness, expiry) grid.

## Working with custom data

```python
import numpy as np
from volsurface.market_data import clean_chain
from volsurface.models import RawSVI

# Your own strikes and IVs
strikes = np.array([90.0, 95.0, 100.0, 105.0, 110.0])
ivs     = np.array([0.25,  0.22,   0.20,   0.21,  0.24])

slice_ = clean_chain(
    strikes, ivs,
    expiry_years=0.25,
    forward=100.0,
    spot=100.0,
)

model = RawSVI()
result = model.fit(slice_)
print(f"RMSE: {result.rmse:.6f}")
print(f"Params: {result.params}")
```

`clean_chain` applies the same filtering as `fetch_chain` (IV bounds, moneyness window, duplicate handling) without requiring Yahoo Finance.
