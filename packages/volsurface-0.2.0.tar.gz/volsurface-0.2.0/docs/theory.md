# Theory & Models

This page covers the mathematical background for the volatility models implemented in `volsurface`. The running example throughout is SPY options.

---

## Introduction

Options on the same underlying have different implied volatilities at different strikes and expiries. The pattern of implied volatility across strikes at a fixed expiry is called a *smile* (or *skew* for equity indices, where it tilts strongly to the left). The full two-dimensional function over (strike, expiry) is the *volatility surface*.

Parameterising this surface is important for:

- Pricing path-dependent or exotic options that depend on the full surface
- Computing meaningful Greeks that account for the smile
- Detecting and avoiding model arbitrage
- Interpolating between market quotes at arbitrary (strike, expiry) points

---

## Log-moneyness and total variance

The package works in two natural coordinates throughout.

**Log-moneyness** is defined as:

$$k = \ln\!\left(\frac{K}{F}\right)$$

where $K$ is the strike and $F$ is the forward price for the relevant expiry. At-the-money corresponds to $k = 0$; negative $k$ is in-the-money for a call.

**Total implied variance** is:

$$w(k, T) = \sigma_{\text{imp}}^2(k, T) \cdot T$$

where $T$ is the time to expiry and $\sigma_{\text{imp}}$ is the implied volatility. Total variance is the natural quantity for surface modelling because it is (approximately) additive in time under no-arbitrage conditions, making interpolation and calendar arbitrage checks straightforward.

---

## Raw SVI parameterisation

The Stochastic Volatility Inspired (SVI) parameterisation (Gatheral, 2004) models total implied variance as a function of log-moneyness at a single expiry:

$$w(k) = a + b \left[ \rho (k - m) + \sqrt{(k - m)^2 + \sigma^2} \right]$$

with five parameters $(a, b, \rho, m, \sigma)$.

### Parameter interpretation

| Parameter | Role | Typical range (equities) |
|-----------|------|--------------------------|
| $a$ | Vertical shift — sets the overall variance level | > 0 |
| $b$ | Wing steepness — controls how quickly variance grows in the tails | 0 to 2 |
| $\rho$ | Rotation/skew — tilts the smile; negative for equities | −0.9 to 0 |
| $m$ | Horizontal shift — moves the smile centre in log-moneyness | near 0 |
| $\sigma$ | Smoothing — rounds the ATM vertex; prevents a sharp cusp | > 0 |

The formula is the sum of a linear term $b\rho(k-m)$ (the skew) and a square-root term $b\sqrt{(k-m)^2+\sigma^2}$ (the wings). As $k \to \pm\infty$, $w(k)$ grows linearly — consistent with Roger Lee's moment formula for the large-strike behaviour of implied variance.

### Calibration

The package fits SVI by minimising total-variance residuals:

$$\min_{a,b,\rho,m,\sigma} \sum_i \left[ w(k_i) - \hat{w}_i \right]^2$$

using L-BFGS-B with bounds and three data-scaled initial guesses. The starting points are derived from the data range (ATM level, strike spread, variance spread) to avoid scale sensitivity.

### SPY example

Fitting Raw SVI independently to 22 SPY expiries ($T = 0.036\text{y}$ to $T = 1.877\text{y}$) yields per-slice RMSEs between 0.0001 and 0.0062 vol points, with all fits converging. The aggregate RMSE across all strikes and expiries is 0.0050.

**Limitation**: each expiry is fitted independently. There is no constraint ensuring that total variance is non-decreasing in time. For SPY, independent per-expiry SVI fits produce approximately 10 calendar spread violations — adjacent expiry pairs where total variance decreases at some log-moneyness points. These violations mean the surface cannot be used for calendar spread pricing or any application requiring cross-expiry consistency.

---

## No-arbitrage conditions

### Butterfly (convexity)

Absence of butterfly arbitrage requires that $w(k)$ is convex in $k$ — the smile cannot have local concavities. Equivalently, the risk-neutral density implied by the smile must be everywhere non-negative.

The package checks this via second finite differences of the fitted total variance across the market strikes.

### SVI parameter conditions

From Gatheral & Jacquier (2014), raw SVI is free of butterfly arbitrage if and only if:

1. $b \geq 0$
2. $\sigma > 0$
3. $a + b\sigma\sqrt{1 - \rho^2} \geq 0$ — the minimum of $w(k)$ is non-negative
4. $b(1 + |\rho|) < 4$ — Lee's moment condition for the large-strike tail

These are checked directly on the fitted parameters via `SVIParams.check_no_arbitrage()`, in addition to the grid-based convexity check.

### Calendar spread

Absence of calendar arbitrage requires total variance to be non-decreasing in time at every fixed log-moneyness level:

$$w(k, T_1) \leq w(k, T_2) \quad \text{whenever } T_1 < T_2$$

When fitting SVI independently per expiry, this condition is not enforced and violations are common. For SPY, around 10 of 21 adjacent expiry pairs show calendar violations with independent SVI fits.

---

## SSVI — Surface SVI

SSVI (Gatheral & Jacquier, 2014) addresses the calendar arbitrage problem by parameterising the entire surface with a small set of global parameters.

### The model

$$w(k, \theta) = \frac{\theta}{2} \left[ 1 + \rho \, \varphi(\theta) \, k + \sqrt{\left(\varphi(\theta) \, k + \rho\right)^2 + (1 - \rho^2)} \right]$$

where:

- $\theta = \theta(T)$ is the **ATM total variance** at expiry $T$, extracted from per-expiry SVI fits
- $\varphi(\theta)$ is the **wing steepness function** (power-law parameterisation):

$$\varphi(\theta) = \frac{\eta}{\theta^\gamma (1 + \theta)^{1 - \gamma}}$$

- $(ρ, η, γ)$ are **global parameters** shared across all expiries

### Key insight

The ATM variance $\theta(T)$ captures the term structure — how overall volatility changes with maturity. The function $\varphi(\theta)$ controls how the smile shape scales with maturity. Because $\varphi(\theta)$ is decreasing in $\theta$ (for $0 < \gamma \leq 1$), short-dated options (small $\theta$, small $T$) have steeper smiles than long-dated ones. This matches observed market behaviour in equity indices.

By making the shape parameters global, SSVI ensures the surface is internally consistent across expiries. Specifically, $w(k, \theta)$ is non-decreasing in $\theta$ (and therefore in $T$, since $\theta$ is increasing with $T$), which is the calendar no-arbitrage condition.

### Global parameter interpretation

| Parameter | Role |
|-----------|------|
| $\rho$ | Skew — tilts the smile; strongly negative for equity indices |
| $\eta$ | Overall wing steepness scale; larger = steeper smiles |
| $\gamma$ | Controls how curvature scales with maturity; $\gamma = 0.5$ recovers the Heston limiting case |

### Calibration

The package uses a two-stage approach:

**Stage 1** — Fit Raw SVI independently to each expiry to extract the ATM total variance $\theta_i = w_{\text{ATM}}(T_i)$. The term structure $\theta(T)$ is checked to be non-decreasing; a warning is issued if it is not (which would introduce calendar arbitrage).

**Stage 2** — Fix the $\theta_i$ from Stage 1 and minimise total-variance residuals across all expiries simultaneously over $(ρ, η, γ)$:

$$\min_{\rho, \eta, \gamma} \sum_i \sum_j \left[ w(k_{ij}, \theta_i) - \hat{w}_{ij} \right]^2$$

using L-BFGS-B with multiple starting points.

### SPY example

For SPY, SSVI produces global parameters $\rho = -0.7463$, $\eta = 1.4684$, $\gamma = 0.5021$. The strongly negative $\rho$ reflects the pronounced equity skew — put options are significantly more expensive than equidistant calls. The aggregate surface RMSE is 0.0112, approximately twice the Raw SVI per-expiry fit of 0.0050.

### The accuracy-consistency tradeoff

Raw SVI has 5 parameters $\times$ 22 expiries = 110 degrees of freedom. SSVI has 3 global parameters + 22 ATM variances = 25 degrees of freedom. This reduction from 110 to 25 parameters is precisely what enforces cross-expiry consistency, at the cost of per-slice accuracy.

The diagnostics comparison table makes this explicit:

```
                    Raw SVI      SSVI
──────────────────────────────────────────
  T=0.036y  RMSE    0.0008    0.0089
  T=0.055y  RMSE    0.0006    0.0045
  T=0.112y  RMSE    0.0012    0.0031
  T=0.279y  RMSE    0.0023    0.0018
  T=0.534y  RMSE    0.0041    0.0014
  ...
──────────────────────────────────────────
      Total RMSE    0.0050    0.0112
 Mean slice RMSE    0.0046    0.0098
```

The RMSE gap is largest for short-dated expiries where the smile shape is most idiosyncratic. It narrows — and can reverse — at longer maturities where the power-law scaling of $\varphi(\theta)$ matches market behaviour well.

---

## When to use which

**Raw SVI** is best for single-expiry work: pricing at a specific maturity, computing Greeks for one slice, or when you need maximum fidelity to market quotes. It is also useful as a diagnostic tool — if SVI cannot fit a slice, the data likely has quality issues.

**SSVI** is best for full-surface work: interpolating between expiries, pricing path-dependent options, or any application where calendar arbitrage would produce nonsensical results. It is the right choice when the surface will be queried at arbitrary (strike, expiry) points.

---

## References

- Gatheral, J. (2004). "A parsimonious arbitrage-free implied volatility parameterization with application to the valuation of volatility derivatives." Presentation at Global Derivatives, Madrid.
- Gatheral, J. & Jacquier, A. (2014). "Arbitrage-free SVI volatility surfaces." *Quantitative Finance*, 14(1), 59–71.
- Gatheral, J. & Jacquier, A. (2011). "Convergence of Heston to SVI." *Quantitative Finance*, 11(8), 1129–1132.
- Lee, R. (2004). "The moment formula for implied volatility at extreme strikes." *Mathematical Finance*, 14(3), 469–480.
