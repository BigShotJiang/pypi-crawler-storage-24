# volsurface

A typed, extensible Python toolkit for implied volatility surface calibration.

An implied volatility surface is the function that maps (strike, expiry) pairs to the Black-Scholes implied volatility consistent with observed option prices. Building one programmatically — fitting a smooth, arbitrage-free model to noisy market quotes — is a core task in derivatives pricing, risk management, and model calibration.

`volsurface` provides a clean Python interface for the full workflow: fetch option chain data, clean and validate it, fit smile models per expiry (SVI) or across all expiries simultaneously (SSVI), check for arbitrage, query any (strike, expiry) point, compare models quantitatively, and visualise.

## What volsurface provides

| Step | What it does |
|------|-------------|
| **Fetch** | Pull live option chains from Yahoo Finance with liquidity filtering and put-call parity forward estimation |
| **Clean** | Validate, sort, deduplicate, and filter to a moneyness window |
| **Fit** | Calibrate Raw SVI per expiry, or SSVI globally across all expiries |
| **Check** | Butterfly (convexity), calendar spread, and SVI parameter-level arbitrage conditions |
| **Query** | Interpolate to any (strike, expiry) point in total-variance space |
| **Diagnose** | Per-slice and aggregate RMSE; side-by-side model comparison tables |
| **Plot** | 3D surface, heatmap, overlaid smiles |

## Core abstractions

[`MarketSlice`](api/core.md) — Cleaned, validated option chain data for a single expiry: strikes, implied volatilities, forward price, and time to expiry.

[`VolModel` / `VolModelProtocol`](api/models.md) — The interface every smile parameterisation implements: `fit()`, `total_variance()`, and `iv()`. Inherit from `VolModel` for a default `iv()` implementation, or satisfy the protocol directly.

[`VolSurface`](api/core.md) — A collection of fitted slice models forming a queryable 2D surface. Handles interpolation between expiries in total-variance space.

[`CalibrationResult`](api/calibration.md) — The output of `calibrate_surface()`: the fitted surface, per-expiry `FitResult` diagnostics, and an `ArbitrageReport`.

## Installation

```bash
pip install volsurface            # core only
pip install volsurface[yahoo]     # + Yahoo Finance data
pip install volsurface[plot]      # + matplotlib plotting
pip install volsurface[all]       # everything
```

## Navigation

- [Quick Start](quickstart.md) — Full narrated walkthrough using SPY options
- [Theory & Models](theory.md) — Mathematical background for SVI and SSVI
- [Extending](extending.md) — Adding a custom volatility model
- [API Reference](api/core.md) — Full API documentation
- [Changelog](https://github.com/cjpvanderwouden/volsurface/blob/main/CHANGELOG.md)
