"""Goodness-of-fit diagnostics for fitted volatility surfaces.

Provides per-slice and aggregate metrics, plus a side-by-side comparison
utility for evaluating two surfaces (e.g. Raw SVI vs SSVI) on the same
market data.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

import numpy as np

if TYPE_CHECKING:
    from volsurface.core import VolSurface


# ── Per-slice and aggregate containers ─────────────────────────────


@dataclass(frozen=True, slots=True)
class SliceDiagnostic:
    """Per-expiry fit quality metrics.

    Attributes:
        expiry_years: Time to expiry in years.
        n_strikes: Number of market strikes in this slice.
        rmse: Root mean squared IV error (model − market).
        max_abs_error: Worst single-strike absolute IV miss.
        mean_abs_error: Average absolute IV error across strikes.
    """

    expiry_years: float
    n_strikes: int
    rmse: float
    max_abs_error: float
    mean_abs_error: float


@dataclass(frozen=True, slots=True)
class SurfaceDiagnostic:
    """Aggregate surface fit quality.

    Attributes:
        slices: Per-expiry diagnostics, sorted by expiry.
        total_rmse: Pooled RMSE across every strike on every expiry
            (not an average of per-slice RMSEs).
        mean_slice_rmse: Simple average of per-slice RMSEs.
    """

    slices: list[SliceDiagnostic] = field(default_factory=list)
    total_rmse: float = 0.0
    mean_slice_rmse: float = 0.0


# ── Comparison container ────────────────────────────────────────────


@dataclass(frozen=True, slots=True)
class SurfaceComparison:
    """Side-by-side diagnostics for two fitted surfaces.

    Attributes:
        label_a: Display name for the first surface.
        label_b: Display name for the second surface.
        diag_a: Diagnostics for the first surface.
        diag_b: Diagnostics for the second surface.
    """

    label_a: str
    label_b: str
    diag_a: SurfaceDiagnostic
    diag_b: SurfaceDiagnostic

    def summary_table(self) -> str:
        """Return a plain fixed-width comparison table string.

        Example output::

                              Raw SVI     SSVI
            ──────────────────────────────────────
            T=0.036y  RMSE    0.0012    0.0089
            T=0.112y  RMSE    0.0015    0.0031
            ──────────────────────────────────────
            Total RMSE         0.0011    0.0052
            Mean slice RMSE    0.0012    0.0055

        Returns:
            Multi-line string suitable for ``print()``.
        """
        col_w = max(len(self.label_a), len(self.label_b), 8)
        row_label_w = 18

        header = f"{'':>{row_label_w}}  {self.label_a:>{col_w}}  {self.label_b:>{col_w}}"
        sep = "─" * len(header)

        lines = [header, sep]

        diag_a_map = {s.expiry_years: s for s in self.diag_a.slices}
        diag_b_map = {s.expiry_years: s for s in self.diag_b.slices}
        all_expiries = sorted(diag_a_map.keys() | diag_b_map.keys())

        for t in all_expiries:
            rmse_a = f"{diag_a_map[t].rmse:.4f}" if t in diag_a_map else "  n/a  "
            rmse_b = f"{diag_b_map[t].rmse:.4f}" if t in diag_b_map else "  n/a  "
            row_lbl = f"T={t:.3f}y  RMSE"
            lines.append(f"{row_lbl:>{row_label_w}}  {rmse_a:>{col_w}}  {rmse_b:>{col_w}}")

        lines.append(sep)
        lines.append(
            f"{'Total RMSE':>{row_label_w}}  "
            f"{self.diag_a.total_rmse:>{col_w}.4f}  "
            f"{self.diag_b.total_rmse:>{col_w}.4f}"
        )
        lines.append(
            f"{'Mean slice RMSE':>{row_label_w}}  "
            f"{self.diag_a.mean_slice_rmse:>{col_w}.4f}  "
            f"{self.diag_b.mean_slice_rmse:>{col_w}.4f}"
        )
        return "\n".join(lines)


# ── Public functions ────────────────────────────────────────────────


def diagnose_surface(surface: VolSurface) -> SurfaceDiagnostic:
    """Compute goodness-of-fit diagnostics for a fitted surface.

    For each expiry in ``surface.market_data`` the corresponding model
    is queried at the market strikes.  Residuals are ``model_iv −
    market_iv``.  The ``total_rmse`` pools *all* residuals (weighted by
    strike count), so expiries with more strikes contribute more.

    Args:
        surface: A fitted :class:`~volsurface.core.VolSurface` with at
            least one expiry.

    Returns:
        :class:`SurfaceDiagnostic` with per-slice and aggregate metrics.
    """
    slice_diags: list[SliceDiagnostic] = []
    all_residuals: list[float] = []

    for t in surface.expiries:
        ms = surface.market_data[t]
        model = surface.slices[t]
        k = ms.log_moneyness
        iv_model = model.iv(k)
        residuals = iv_model - ms.ivs

        rmse = float(np.sqrt(np.mean(residuals**2)))
        max_abs = float(np.max(np.abs(residuals)))
        mean_abs = float(np.mean(np.abs(residuals)))

        slice_diags.append(
            SliceDiagnostic(
                expiry_years=t,
                n_strikes=ms.n_strikes,
                rmse=rmse,
                max_abs_error=max_abs,
                mean_abs_error=mean_abs,
            )
        )
        all_residuals.extend(residuals.tolist())

    if not all_residuals:
        return SurfaceDiagnostic()

    total_rmse = float(np.sqrt(np.mean(np.array(all_residuals) ** 2)))
    mean_slice_rmse = float(np.mean([s.rmse for s in slice_diags]))

    return SurfaceDiagnostic(
        slices=slice_diags,
        total_rmse=total_rmse,
        mean_slice_rmse=mean_slice_rmse,
    )


def compare_surfaces(
    surface_a: VolSurface,
    surface_b: VolSurface,
    label_a: str = "A",
    label_b: str = "B",
) -> SurfaceComparison:
    """Compute and bundle diagnostics for two surfaces side-by-side.

    Both surfaces are diagnosed independently, then wrapped in a
    :class:`SurfaceComparison` which provides :meth:`~SurfaceComparison.summary_table`.

    Args:
        surface_a: First fitted surface.
        surface_b: Second fitted surface.
        label_a: Display name for the first surface (default ``"A"``).
        label_b: Display name for the second surface (default ``"B"``).

    Returns:
        :class:`SurfaceComparison` containing both diagnostics.
    """
    return SurfaceComparison(
        label_a=label_a,
        label_b=label_b,
        diag_a=diagnose_surface(surface_a),
        diag_b=diagnose_surface(surface_b),
    )
