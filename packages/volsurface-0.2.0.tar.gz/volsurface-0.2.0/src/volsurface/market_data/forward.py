"""Put-call parity forward price estimation.

Uses put-call parity  F = K + e^{rT}(C - P)  to estimate the implied
forward at each strike where both call and put mid-prices are available,
then takes the median as a robust aggregate.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

import numpy as np
import numpy.typing as npt

if TYPE_CHECKING:
    import pandas as pd

logger = logging.getLogger(__name__)

_MIN_PAIRS = 3  # minimum call/put pairs to trust the parity estimate
_SANITY_LO = 0.8  # forward must be at least 80% of spot
_SANITY_HI = 1.2  # forward must be at most 120% of spot


def estimate_forward_from_parity(
    strikes: npt.NDArray[np.float64],
    call_prices: npt.NDArray[np.float64],
    put_prices: npt.NDArray[np.float64],
    expiry_years: float,
    rate: float = 0.0,
    *,
    spot: float | None = None,
) -> float:
    """Estimate the implied forward price from put-call parity.

    For each strike *K* where both a call mid-price *C* and a put
    mid-price *P* are available (i.e. both are finite and positive),
    put-call parity gives:

        F(K) = K + e^{rT} · (C − P)

    The median of all per-strike estimates is returned as the forward
    (median is robust to outliers from illiquid wings).

    Args:
        strikes: Array of strike prices.
        call_prices: Mid-prices for calls at each strike (NaN / ≤0 if
            unavailable).
        put_prices: Mid-prices for puts at each strike (NaN / ≤0 if
            unavailable).
        expiry_years: Time to expiry T in years.
        rate: Continuously compounded risk-free rate r (default 0).
        spot: Spot price used as fallback when parity estimate is
            unavailable.  If None, a ValueError is raised on fallback.

    Returns:
        Estimated forward price.

    Raises:
        ValueError: If fewer than ``_MIN_PAIRS`` valid pairs exist and
            no ``spot`` fallback is provided.
    """
    strikes = np.asarray(strikes, dtype=np.float64)
    call_prices = np.asarray(call_prices, dtype=np.float64)
    put_prices = np.asarray(put_prices, dtype=np.float64)

    discount: float = float(np.exp(rate * expiry_years))

    valid = (
        np.isfinite(call_prices) & (call_prices > 0) & np.isfinite(put_prices) & (put_prices > 0)
    )

    if valid.sum() < _MIN_PAIRS:
        if spot is not None:
            fallback = float(spot * discount)
            logger.info(
                "Using spot-based forward for T=%.4f (insufficient put-call parity data: "
                "only %d valid pairs, need %d)",
                expiry_years,
                int(valid.sum()),
                _MIN_PAIRS,
            )
            return fallback
        msg = (
            f"Only {int(valid.sum())} valid call/put pairs (need ≥ {_MIN_PAIRS}); "
            "provide a spot fallback."
        )
        raise ValueError(msg)

    forwards = strikes[valid] + discount * (call_prices[valid] - put_prices[valid])
    forward = float(np.median(forwards))
    logger.debug(
        "Parity-implied forward: %.4f (from %d pairs, r=%.4f, T=%.4f)",
        forward,
        int(valid.sum()),
        rate,
        expiry_years,
    )
    return forward


def estimate_forward(
    calls: pd.DataFrame,
    puts: pd.DataFrame,
    spot: float,
    expiry_years: float,
    rate: float = 0.0,
) -> float:
    """Estimate the implied forward price from call and put DataFrames.

    Inner-joins calls and puts on ``strike``, computes mid-prices for rows
    where both bid and ask are positive, then applies put-call parity per
    strike and takes the median.  Falls back to ``spot * exp(r*T)`` when
    fewer than :data:`_MIN_PAIRS` valid pairs exist or the parity estimate
    lies outside ``[0.8 · spot, 1.2 · spot]`` (e.g. off-market hours).

    Args:
        calls: Call option chain DataFrame with columns ``strike``,
            ``bid``, ``ask`` (as returned by ``yfinance``).
        puts: Put option chain DataFrame with the same columns.
        spot: Current spot price used for the fallback forward.
        expiry_years: Time to expiry T in years.
        rate: Continuously compounded risk-free rate r (default 0).

    Returns:
        Estimated forward price.
    """

    fallback: float = float(spot * np.exp(rate * expiry_years))

    # Inner-join on strike, keep bid/ask from both sides
    merged: pd.DataFrame = calls[["strike", "bid", "ask"]].merge(
        puts[["strike", "bid", "ask"]],
        on="strike",
        suffixes=("_c", "_p"),
    )

    valid_mask = (
        (merged["bid_c"] > 0)
        & (merged["ask_c"] > 0)
        & (merged["bid_p"] > 0)
        & (merged["ask_p"] > 0)
    )
    valid_rows = merged[valid_mask]

    if len(valid_rows) < _MIN_PAIRS:
        logger.info(
            "Only %d matched call/put pairs with two-sided quotes — "
            "falling back to spot forward %.4f",
            len(valid_rows),
            fallback,
        )
        return fallback

    call_mids = (valid_rows["bid_c"] + valid_rows["ask_c"]) / 2.0
    put_mids = (valid_rows["bid_p"] + valid_rows["ask_p"]) / 2.0

    K = valid_rows["strike"].to_numpy(dtype=np.float64)
    C = call_mids.to_numpy(dtype=np.float64)
    P = put_mids.to_numpy(dtype=np.float64)

    forward = estimate_forward_from_parity(
        K, C, P, expiry_years=expiry_years, rate=rate, spot=fallback
    )

    # Sanity check: parity forward must stay within ±20% of spot
    if forward < _SANITY_LO * spot or forward > _SANITY_HI * spot:
        logger.warning(
            "Parity-implied forward %.4f is outside [%.0f%%, %.0f%%] of spot %.4f "
            "— falling back to %.4f",
            forward,
            _SANITY_LO * 100,
            _SANITY_HI * 100,
            spot,
            fallback,
        )
        return fallback

    logger.debug(
        "estimate_forward: F=%.4f (spot=%.4f, %d pairs, r=%.4f, T=%.4f)",
        forward,
        spot,
        len(valid_rows),
        rate,
        expiry_years,
    )
    return forward
