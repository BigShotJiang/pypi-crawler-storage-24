"""Yahoo Finance option chain fetcher.

This module requires the optional ``yfinance`` dependency::

    pip install volsurface[yahoo]
"""

from __future__ import annotations

import datetime as dt
import logging
from typing import TYPE_CHECKING, Any

import numpy as np

from volsurface.core import MarketSlice
from volsurface.market_data.forward import estimate_forward

if TYPE_CHECKING:
    import pandas as pd

logger = logging.getLogger(__name__)


def _import_yfinance() -> Any:
    """Lazily import yfinance, raising a clear error if absent."""
    try:
        import yfinance
    except ImportError:
        msg = (
            "yfinance is required for Yahoo data fetching. "
            "Install it with:  pip install volsurface[yahoo]"
        )
        raise ImportError(msg) from None
    return yfinance


def fetch_chain(
    ticker: str,
    *,
    rate: float = 0.0,
    min_volume: int = 0,
    min_open_interest: int = 0,
    max_spread_pct: float = 1.0,
    moneyness_range: tuple[float, float] = (0.7, 1.3),
    min_days_to_expiry: int = 7,
) -> list[MarketSlice]:
    """Fetch and clean option chain data from Yahoo Finance.

    Estimates the forward price from put-call parity when sufficient
    call/put mid-prices are available, falling back to ``spot * exp(r*T)``
    otherwise.

    Args:
        ticker: Yahoo Finance ticker symbol (e.g. ``"SPY"``).
        rate: Continuously compounded risk-free rate (default 0).
        min_volume: Minimum option volume; 0 disables the filter.
        min_open_interest: Minimum open interest; 0 disables the filter.
        max_spread_pct: Maximum bid-ask spread as a fraction of mid-price.
        moneyness_range: (low, high) K/S bounds for strike selection.
        min_days_to_expiry: Skip expiries closer than this many days.

    Returns:
        List of :class:`~volsurface.core.MarketSlice` objects sorted by
        expiry, one per qualifying expiry date.

    Raises:
        ValueError: If no valid option slices are found after filtering.
    """
    yf = _import_yfinance()
    asset = yf.Ticker(ticker)

    # fast_info is more reliable than .info for spot price
    spot: float = float(asset.fast_info["lastPrice"])
    logger.info("Spot price for %s: %.2f", ticker, spot)

    expiry_strings: tuple[str, ...] = asset.options
    if not expiry_strings:
        msg = (
            f"No option expiries found for {ticker}. "
            "Check that the ticker symbol is correct and has listed options."
        )
        raise ValueError(msg)

    today = dt.date.today()
    slices: list[MarketSlice] = []

    for exp_str in expiry_strings:
        exp_date = dt.date.fromisoformat(exp_str)
        days_to_exp = (exp_date - today).days
        T = days_to_exp / 365.0

        if days_to_exp < min_days_to_expiry:
            logger.debug("Skipping %s — only %d days to expiry", exp_str, days_to_exp)
            continue

        try:
            raw = asset.option_chain(exp_str)
            calls: pd.DataFrame = raw.calls
            puts: pd.DataFrame = raw.puts
        except Exception:
            logger.warning("Failed to fetch chain for %s %s", ticker, exp_str)
            continue

        calls = _filter_chain(
            calls,
            spot=spot,
            min_volume=min_volume,
            min_open_interest=min_open_interest,
            max_spread_pct=max_spread_pct,
            moneyness_range=moneyness_range,
        )

        if len(calls) < 5:
            logger.debug(
                "Skipping %s — only %d strikes after filtering (need 5)",
                exp_str,
                len(calls),
            )
            continue

        strikes = calls["strike"].to_numpy(dtype=np.float64)
        ivs = calls["impliedVolatility"].to_numpy(dtype=np.float64)

        # Estimate forward from put-call parity using raw puts DataFrame
        forward = estimate_forward(calls, puts, spot=spot, expiry_years=T, rate=rate)

        try:
            ms = MarketSlice(
                strikes=strikes,
                ivs=ivs,
                expiry_years=T,
                forward=forward,
                spot=spot,
                rate=rate,
                ticker=ticker,
            )
            slices.append(ms)
            logger.info(
                "Added %s (T=%.4f, %d strikes, F=%.2f vs S=%.2f)",
                exp_str,
                T,
                len(strikes),
                forward,
                spot,
            )
        except ValueError as e:
            logger.debug("Validation failed for %s: %s", exp_str, e)
            continue

    if not slices:
        msg = (
            f"No valid option slices for {ticker} after filtering. "
            "Try relaxing filters: reduce min_volume, widen moneyness_range, "
            "or lower min_days_to_expiry."
        )
        raise ValueError(msg)

    return sorted(slices, key=lambda s: s.expiry_years)


def _filter_chain(
    chain: pd.DataFrame,
    *,
    spot: float,
    min_volume: int,
    min_open_interest: int,
    max_spread_pct: float,
    moneyness_range: tuple[float, float],
) -> pd.DataFrame:
    """Apply liquidity and moneyness filters to a raw option chain."""
    df = chain.copy()

    # Moneyness filter (apply first to reduce dataframe size)
    moneyness = df["strike"] / spot
    df = df[(moneyness >= moneyness_range[0]) & (moneyness <= moneyness_range[1])]

    # IV sanity — Yahoo returns 0.00001 for stale/dead contracts
    df = df[df["impliedVolatility"] > 0.01]
    df = df[df["impliedVolatility"] < 5.0]

    # Liquidity filters (only apply if thresholds are > 0)
    if min_volume > 0:
        df = df[df["volume"].fillna(0) >= min_volume]
    if min_open_interest > 0:
        df = df[df["openInterest"].fillna(0) >= min_open_interest]

    # Always drop contracts where both bid and ask are zero — these are
    # stale/dead and should never be included regardless of the fallback path.
    stale = (df["bid"] == 0) & (df["ask"] == 0)
    df = df[~stale]

    # Spread filter — only apply when both bid and ask are quoted
    has_quotes = (df["bid"] > 0) & (df["ask"] > 0)
    if has_quotes.any():
        quoted = df[has_quotes]
        mid = (quoted["bid"] + quoted["ask"]) / 2
        spread_pct = (quoted["ask"] - quoted["bid"]) / mid
        good_spread = quoted[spread_pct <= max_spread_pct]
        # If we have enough quoted contracts, use only those.
        # Otherwise fall back to all contracts with valid IVs.
        if len(good_spread) >= 5:
            df = good_spread
        else:
            logger.info(
                "Few well-quoted contracts (%d with spread ≤ %.0f%%) — "
                "falling back to all %d contracts with valid IVs",
                len(good_spread),
                max_spread_pct * 100,
                len(df),
            )

    return df.sort_values("strike").reset_index(drop=True)
