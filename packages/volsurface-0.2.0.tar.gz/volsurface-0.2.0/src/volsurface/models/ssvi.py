"""SSVI — Surface SVI parameterisation.

SSVI (Gatheral & Jacquier, 2014) parameterises the total variance surface
simultaneously across all expiries:

    w(k, theta) = (theta / 2) * (1 + rho * phi(theta) * k
                   + sqrt((phi(theta) * k + rho)^2 + (1 - rho^2)))

where

    phi(theta) = eta / (theta^gamma * (1 + theta)^(1 - gamma))

is the Heston-like wing steepness function, ``theta(T)`` is the ATM total
variance at expiry ``T``, and ``(rho, eta, gamma)`` are **global** parameters
shared across all expiries.

By construction the surface is free of calendar arbitrage whenever the ATM
term structure ``theta(T)`` is non-decreasing (which is checked and warned
about during calibration).

References:
    Gatheral, J. & Jacquier, A. (2014). "Arbitrage-free SVI volatility
    surfaces." *Quantitative Finance*, 14(1), 59-71.
"""

from __future__ import annotations

import logging
import warnings
from dataclasses import dataclass
from typing import Any

import numpy as np
import numpy.typing as npt
from scipy.optimize import minimize

from volsurface.core import FitResult, MarketSlice
from volsurface.models.base import VolModel
from volsurface.models.svi import RawSVI

logger = logging.getLogger(__name__)


# ── SSVI formula helpers ────────────────────────────────────────────


def _phi(theta: float, eta: float, gamma: float) -> float:
    """Heston-like wing steepness function phi(theta)."""
    return float(eta / (theta**gamma * (1.0 + theta) ** (1.0 - gamma)))


def _ssvi_w(
    k: npt.NDArray[np.float64],
    theta: float,
    rho: float,
    eta: float,
    gamma: float,
) -> npt.NDArray[np.float64]:
    """Evaluate SSVI total variance for a single expiry slice."""
    p = _phi(theta, eta, gamma)
    inner = p * k + rho
    return np.asarray(
        (theta / 2.0) * (1.0 + rho * p * k + np.sqrt(inner**2 + 1.0 - rho**2)),
        dtype=np.float64,
    )


# ── Parameter containers ────────────────────────────────────────────


@dataclass
class SSVIGlobalParams:
    """Global SSVI parameters shared across all expiries.

    Attributes:
        rho: Correlation / skew parameter (-1 < rho < 1).
        eta: Wing steepness scale (eta > 0).
        gamma: Power-law exponent (0 < gamma <= 1).
    """

    rho: float
    eta: float
    gamma: float

    def as_dict(self) -> dict[str, float]:
        """Return parameters as a name -> value dict."""
        return {"rho": self.rho, "eta": self.eta, "gamma": self.gamma}

    def to_array(self) -> npt.NDArray[np.float64]:
        """Pack into a numpy array [rho, eta, gamma]."""
        return np.array([self.rho, self.eta, self.gamma])

    @classmethod
    def from_array(cls, arr: npt.NDArray[np.float64]) -> SSVIGlobalParams:
        """Unpack a [rho, eta, gamma] array."""
        return cls(rho=float(arr[0]), eta=float(arr[1]), gamma=float(arr[2]))


# ── Per-slice SSVI model ────────────────────────────────────────────


class SSVISlice(VolModel):
    """A single SSVI expiry slice; stores one theta and the global params.

    This is not meant to be instantiated directly — use :class:`SSVI`
    which calibrates the full surface and creates these internally.
    """

    def __init__(
        self,
        theta: float,
        global_params: SSVIGlobalParams,
        expiry_years: float,
    ) -> None:
        self._theta = theta
        self._global = global_params
        self._expiry_years: float | None = expiry_years

    @property
    def n_params(self) -> int:
        return 4  # theta + rho + eta + gamma

    def total_variance(
        self,
        log_moneyness: float | npt.NDArray[np.float64],
    ) -> npt.NDArray[np.float64]:
        """Compute SSVI total variance w(k) for this expiry.

        Args:
            log_moneyness: Scalar or array of ln(K/F) values.

        Returns:
            Array of total variance values.
        """
        k = self._to_array(log_moneyness)
        g = self._global
        return _ssvi_w(k, self._theta, g.rho, g.eta, g.gamma)

    def fit(self, market_slice: MarketSlice) -> FitResult:
        """Not supported: use SSVI.fit_surface() instead."""
        msg = (
            "SSVISlice.fit() is not supported. "
            "Use SSVI.fit_surface(slices) to calibrate the full SSVI surface."
        )
        raise NotImplementedError(msg)


# ── Full SSVI surface calibration ─────────────────────────────────


class SSVI:
    """Surface SVI (SSVI) — globally consistent implied volatility surface.

    Calibration is a two-stage process:

    1. **Stage 1** — fit raw SVI independently to each expiry and extract
       the ATM total variance ``theta_i = w_ATM(T_i)`` from each fit.
    2. **Stage 2** — fit the three global parameters ``(rho, eta, gamma)``
       by minimising total-variance residuals across all expiries.

    Example::

        from volsurface.models.ssvi import SSVI

        ssvi = SSVI()
        slice_models, fit_result = ssvi.fit_surface(market_slices)
    """

    def __init__(self) -> None:
        self._global_params: SSVIGlobalParams | None = None
        self._thetas: dict[float, float] = {}  # expiry -> theta
        self._slices: dict[float, SSVISlice] = {}  # expiry -> slice model

    # ── Properties ──────────────────────────────────────────────────

    @property
    def global_params(self) -> SSVIGlobalParams:
        """Fitted global SSVI parameters.

        Raises:
            RuntimeError: If the surface has not been fitted yet.
        """
        if self._global_params is None:
            msg = "SSVI has not been fitted yet — call .fit_surface() first"
            raise RuntimeError(msg)
        return self._global_params

    def slice_model(self, expiry_years: float) -> SSVISlice:
        """Return the fitted SSVISlice for a given expiry.

        Args:
            expiry_years: The target expiry (must match an exact fit key).

        Raises:
            KeyError: If the expiry was not fitted.
        """
        return self._slices[expiry_years]

    # ── Calibration ──────────────────────────────────────────────────

    def fit_surface(
        self,
        slices: list[MarketSlice],
    ) -> tuple[dict[float, SSVISlice], FitResult]:
        """Calibrate SSVI to a list of market slices.

        Stage 1: fit raw SVI per expiry to extract ATM total variance
        (theta).  Stage 2: minimise SSVI residuals to find global
        (rho, eta, gamma).  Warns if the ATM term structure is not
        non-decreasing (which would introduce calendar arbitrage).

        Args:
            slices: Cleaned market slices, one per expiry.

        Returns:
            Tuple of (per-expiry SSVISlice dict, aggregate FitResult).
        """
        if len(slices) < 2:
            msg = "SSVI requires at least 2 expiry slices"
            raise ValueError(msg)

        sorted_slices = sorted(slices, key=lambda s: s.expiry_years)

        # ── Stage 1: extract theta per expiry via raw SVI ──────────
        thetas: dict[float, float] = {}
        for ms in sorted_slices:
            svi = RawSVI()
            svi.fit(ms)
            # Evaluate fitted SVI at k=0 (ATM) to get theta = w(0, T)
            theta = float(svi.total_variance(np.array([0.0]))[0])
            thetas[ms.expiry_years] = theta
            logger.debug("Stage 1: T=%.4f, theta=%.6f", ms.expiry_years, theta)

        self._thetas = thetas

        # Check ATM term structure is non-decreasing
        expiries = [ms.expiry_years for ms in sorted_slices]
        theta_vals = [thetas[t] for t in expiries]
        if any(theta_vals[i + 1] < theta_vals[i] for i in range(len(theta_vals) - 1)):
            warnings.warn(
                "SSVI ATM term structure (theta) is not non-decreasing — "
                "calendar arbitrage may be present.",
                stacklevel=2,
            )

        # ── Stage 2: global (rho, eta, gamma) fit ──────────────────
        global_params, stage2_result = self._fit_global(sorted_slices, thetas)
        self._global_params = global_params

        # Build per-expiry slice models
        for ms in sorted_slices:
            self._slices[ms.expiry_years] = SSVISlice(
                theta=thetas[ms.expiry_years],
                global_params=global_params,
                expiry_years=ms.expiry_years,
            )

        # Aggregate residuals across all slices
        all_residuals = self._compute_residuals(sorted_slices)
        rmse = float(np.sqrt(np.mean(all_residuals**2)))

        aggregate = FitResult(
            params={
                **global_params.as_dict(),
                **{f"theta_{t:.4f}": theta for t, theta in thetas.items()},
            },
            residuals=all_residuals,
            rmse=rmse,
            success=bool(stage2_result.success),
            message=str(stage2_result.message),
            n_iterations=int(stage2_result.nit),
        )
        logger.info(
            "SSVI global fit: RMSE=%.6f, rho=%.4f, eta=%.4f, gamma=%.4f",
            rmse,
            global_params.rho,
            global_params.eta,
            global_params.gamma,
        )
        return self._slices, aggregate

    def _fit_global(
        self,
        slices: list[MarketSlice],
        thetas: dict[float, float],
    ) -> tuple[SSVIGlobalParams, Any]:
        """Stage 2: fit global (rho, eta, gamma) by minimising total-variance residuals."""

        def objective(x: npt.NDArray[np.float64]) -> float:
            rho, eta, gamma = x[0], x[1], x[2]
            total = 0.0
            for ms in slices:
                theta = thetas[ms.expiry_years]
                k = ms.log_moneyness
                w_model = _ssvi_w(k, theta, rho, eta, gamma)
                w_market = ms.total_variance
                total += float(np.sum((w_model - w_market) ** 2))
            return total

        # Bounds: -1 < rho < 1, eta > 0, 0 < gamma <= 1
        bounds = [(-0.999, 0.999), (1e-4, 10.0), (1e-4, 1.0)]

        # Multiple starting points for robustness
        starts = [
            np.array([-0.3, 1.0, 0.5]),
            np.array([0.0, 0.5, 0.3]),
            np.array([-0.5, 2.0, 0.7]),
        ]

        best_result: Any = None
        best_obj = np.inf

        for x0 in starts:
            res = minimize(
                objective,
                x0=x0,
                method="L-BFGS-B",
                bounds=bounds,
                options={"maxiter": 5000, "ftol": 1e-14},
            )
            if res.fun < best_obj:
                best_obj = float(res.fun)
                best_result = res

        assert best_result is not None
        params = SSVIGlobalParams.from_array(best_result.x)
        return params, best_result

    def _compute_residuals(self, slices: list[MarketSlice]) -> npt.NDArray[np.float64]:
        """Compute per-strike IV residuals (model IV - market IV) across all slices."""
        assert self._global_params is not None
        all_resid: list[npt.NDArray[np.float64]] = []
        for ms in slices:
            theta = self._thetas[ms.expiry_years]
            g = self._global_params
            k = ms.log_moneyness
            w_fitted = _ssvi_w(k, theta, g.rho, g.eta, g.gamma)
            iv_model = np.sqrt(np.maximum(w_fitted, 0.0) / ms.expiry_years)
            all_resid.append(iv_model - ms.ivs)
        return np.concatenate(all_resid)
