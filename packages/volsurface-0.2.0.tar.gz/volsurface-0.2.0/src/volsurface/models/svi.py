"""Raw SVI (Stochastic Volatility Inspired) parameterisation.

The raw SVI parameterisation of the implied total variance smile is:

    w(k) = a + b · [ ρ·(k − m) + √((k − m)² + σ²) ]

where *k* = ln(K/F) is log-moneyness and (a, b, ρ, m, σ) are the five
free parameters.

References:
    Gatheral, J. & Jacquier, A. (2014). "Arbitrage-free SVI volatility
    surfaces." *Quantitative Finance*, 14(1), 59–71.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass

import numpy as np
import numpy.typing as npt
from scipy.optimize import minimize

from volsurface.core import FitResult, MarketSlice
from volsurface.models.base import VolModel

logger = logging.getLogger(__name__)


@dataclass
class SVIParams:
    """Container for the five raw SVI parameters.

    Attributes:
        a: Vertical translation of the smile.
        b: Slope tightness (b ≥ 0).
        rho: Rotation / skew (−1 < ρ < 1).
        m: Horizontal translation (smile centre in log-moneyness).
        sigma: Smoothing of the ATM vertex (σ > 0).
    """

    a: float
    b: float
    rho: float
    m: float
    sigma: float

    def to_array(self) -> npt.NDArray[np.float64]:
        """Pack parameters into a numpy array."""
        return np.array([self.a, self.b, self.rho, self.m, self.sigma])

    @classmethod
    def from_array(cls, arr: npt.NDArray[np.float64]) -> SVIParams:
        """Unpack a numpy array into an SVIParams instance."""
        return cls(a=arr[0], b=arr[1], rho=arr[2], m=arr[3], sigma=arr[4])

    def as_dict(self) -> dict[str, float]:
        """Return parameters as a name→value dict."""
        return {"a": self.a, "b": self.b, "rho": self.rho, "m": self.m, "sigma": self.sigma}

    def check_no_arbitrage(self) -> list[str]:
        """Check the Gatheral-Jacquier (2014) parameter-level no-arbitrage conditions.

        Returns a list of strings describing each violated condition.
        An empty list means the parameters are butterfly-arbitrage free.

        The four necessary and sufficient conditions for raw SVI to be free
        of butterfly arbitrage (Gatheral & Jacquier, 2014, Proposition 2.1):

        1. b ≥ 0
        2. σ > 0  (implied by b·σ·√(1−ρ²) > 0 when b > 0)
        3. a + b·σ·√(1−ρ²) ≥ 0  (minimum total variance is non-negative)
        4. b·(1 + |ρ|) < 4  (Roger Lee moment condition for large strikes)

        Returns:
            List of violation descriptions (empty ⟹ no violations).
        """
        violations: list[str] = []

        if self.b < 0:
            violations.append(f"b={self.b:.4f} < 0 (must be ≥ 0)")

        if self.sigma <= 0:
            violations.append(f"sigma={self.sigma:.4f} ≤ 0 (must be > 0)")

        min_w = self.a + self.b * self.sigma * np.sqrt(1.0 - self.rho**2)
        if min_w < 0:
            violations.append(
                f"minimum total variance a+b·σ·√(1-ρ²)={min_w:.4f} < 0 (smile dips below zero)"
            )

        lee_bound = self.b * (1.0 + abs(self.rho))
        if lee_bound >= 4.0:
            violations.append(
                f"b·(1+|ρ|)={lee_bound:.4f} ≥ 4 (violates Roger Lee moment condition)"
            )

        return violations


class RawSVI(VolModel):
    """Raw SVI smile parameterisation.

    Example::

        from volsurface.models import RawSVI

        model = RawSVI()
        result = model.fit(market_slice)
        ivs = model.iv(log_moneyness_grid)
    """

    def __init__(self) -> None:
        self._params: SVIParams | None = None
        self._expiry_years: float | None = None

    # ── Properties ──────────────────────────────────────────────────

    @property
    def n_params(self) -> int:
        return 5

    @property
    def params(self) -> SVIParams:
        """Fitted SVI parameters.

        Raises:
            RuntimeError: If the model has not been fitted.
        """
        if self._params is None:
            msg = "Model has not been fitted yet — call .fit() first"
            raise RuntimeError(msg)
        return self._params

    # ── Core SVI formula ────────────────────────────────────────────

    @staticmethod
    def _w(
        k: npt.NDArray[np.float64],
        a: float,
        b: float,
        rho: float,
        m: float,
        sigma: float,
    ) -> npt.NDArray[np.float64]:
        """Evaluate the raw SVI total-variance formula."""
        diff = k - m
        return np.asarray(a + b * (rho * diff + np.sqrt(diff**2 + sigma**2)), dtype=np.float64)

    # ── Public interface ────────────────────────────────────────────

    def total_variance(
        self,
        log_moneyness: float | npt.NDArray[np.float64],
    ) -> npt.NDArray[np.float64]:
        """Compute total implied variance w(k) for given log-moneyness.

        Args:
            log_moneyness: Scalar or array of ln(K/F) values.

        Returns:
            Array of total variance values.
        """
        p = self.params  # will raise if not fitted
        k = self._to_array(log_moneyness)
        result = self._w(k, p.a, p.b, p.rho, p.m, p.sigma)
        return np.asarray(result, dtype=np.float64)

    def fit(self, market_slice: MarketSlice) -> FitResult:
        """Calibrate raw SVI to a market smile.

        Runs L-BFGS-B from multiple starting points and keeps the best
        result, which dramatically reduces the chance of converging to a
        poor local minimum.

        Args:
            market_slice: Cleaned market data for one expiry.

        Returns:
            FitResult with calibration diagnostics.
        """
        k = market_slice.log_moneyness
        w_market = market_slice.total_variance
        T = market_slice.expiry_years

        bounds = self._param_bounds(k, w_market)
        starts = self._initial_guesses(k, w_market)

        def objective(x: npt.NDArray[np.float64]) -> float:
            w_model = self._w(k, x[0], x[1], x[2], x[3], x[4])
            return float(np.sum((w_model - w_market) ** 2))

        best_result = None
        best_obj = np.inf

        for x0 in starts:
            res = minimize(
                objective,
                x0=x0,
                method="L-BFGS-B",
                bounds=bounds,
                options={"maxiter": 2000, "ftol": 1e-14},
            )
            if res.fun < best_obj:
                best_obj = float(res.fun)
                best_result = res

        assert best_result is not None  # always have ≥1 start
        if len(starts) > 1:
            logger.debug(
                "Multi-start SVI: best objective=%.4e over %d starts",
                best_obj,
                len(starts),
            )

        self._params = SVIParams.from_array(best_result.x)
        self._expiry_years = T

        w_fitted = self._w(k, *best_result.x)
        iv_residuals = np.sqrt(np.maximum(w_fitted, 0.0) / T) - market_slice.ivs
        rmse = float(np.sqrt(np.mean(iv_residuals**2)))

        return FitResult(
            params=self._params.as_dict(),
            residuals=iv_residuals,
            rmse=rmse,
            success=bool(best_result.success),
            message=str(best_result.message),
            n_iterations=int(best_result.nit),
        )

    # ── Private helpers ─────────────────────────────────────────────

    @staticmethod
    def _initial_guesses(
        k: npt.NDArray[np.float64],
        w: npt.NDArray[np.float64],
    ) -> list[npt.NDArray[np.float64]]:
        """Multiple data-scaled starting points for the multi-start optimiser.

        Strategy:
        - *a*: ATM total variance (minimum of *w*).
        - *b*: scaled to the slope of total variance near ATM; clamped to
          a small positive value so the first guess is non-degenerate.
        - *σ*: proportional to the log-moneyness range of the data.
        - Three starts with different skew signs / magnitudes to improve
          coverage of the parameter space.
        """
        atm_idx = int(np.argmin(np.abs(k)))
        a0 = float(w[atm_idx])
        k_range = float(np.ptp(k))

        # b0 proportional to total-variance slope near ATM
        dw = float(np.ptp(w))
        b0 = max(dw / max(k_range, 1e-6), 1e-3)
        b0 = min(b0, 2.0)  # keep within reasonable bounds

        # sigma0 proportional to log-moneyness range
        sigma0 = max(0.1 * k_range, 0.05)
        sigma0 = min(sigma0, 1.0)

        m0 = float(k[atm_idx])

        return [
            np.array([a0, b0, -0.3, m0, sigma0]),  # typical equity skew
            np.array([a0, b0 * 0.5, 0.0, m0, sigma0 * 2.0]),  # symmetric, wider
            np.array([a0, b0 * 1.5, 0.3, m0, sigma0 * 0.5]),  # positive skew, tight
        ]

    @staticmethod
    def _param_bounds(
        k: npt.NDArray[np.float64],
        w: npt.NDArray[np.float64],
    ) -> list[tuple[float, float]]:
        """Parameter bounds for L-BFGS-B.

        These are intentionally somewhat loose to avoid biasing the
        optimiser; tighter no-arbitrage constraints can be applied
        via the arbitrage module post-hoc.
        """
        w_max = float(np.max(w))
        k_range = float(np.ptp(k))
        return [
            (-w_max, 2.0 * w_max),  # a
            (1e-8, 5.0),  # b
            (-0.999, 0.999),  # rho
            (float(k.min()) - k_range, float(k.max()) + k_range),  # m
            (1e-4, 2.0),  # sigma
        ]
