"""One-liner convenience functions for common workflows."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from volsurface.calibration.engine import CalibrationResult
    from volsurface.core import VolSurface


def iv_surface(
    ticker: str,
    *,
    model: str = "svi",
    plot: bool = False,
    **fetch_kwargs: Any,
) -> CalibrationResult | VolSurface:
    """Fetch, fit, and optionally plot a vol surface in one call.

    Args:
        ticker: Underlying ticker symbol (e.g. ``"SPY"``, ``"TSLA"``).
        model: Model to use — ``"svi"`` for per-expiry Raw SVI,
            ``"ssvi"`` for globally consistent SSVI.
        plot: If ``True``, display a 3-D surface plot after fitting.
        **fetch_kwargs: Passed through to :func:`~volsurface.market_data.fetch_chain`
            (e.g. ``min_volume``, ``moneyness_range``).

    Returns:
        :class:`~volsurface.calibration.engine.CalibrationResult` for
        ``model="svi"``, or :class:`~volsurface.core.VolSurface` for
        ``model="ssvi"``.

    Raises:
        ValueError: If *model* is not ``"svi"`` or ``"ssvi"``.

    Example::

        from volsurface.quick import iv_surface

        # Quickest path to a surface
        result = iv_surface("SPY")

        # SSVI with a plot
        surface = iv_surface("TSLA", model="ssvi", plot=True)
    """
    from volsurface.calibration.engine import calibrate_surface
    from volsurface.core import VolSurface
    from volsurface.market_data.yahoo import fetch_chain
    from volsurface.models.svi import RawSVI

    model_lower = model.lower()
    if model_lower not in ("svi", "ssvi"):
        msg = f"Unknown model {model!r}. Valid options are: 'svi', 'ssvi'."
        raise ValueError(msg)

    slices = fetch_chain(ticker, **fetch_kwargs)

    if model_lower == "svi":
        result: CalibrationResult = calibrate_surface(slices, RawSVI, ticker=ticker)
        if plot:
            from volsurface.plotting.visualize import plot_surface

            plot_surface(result.surface, kind="3d", show=True)
        return result

    # model == "ssvi"
    from volsurface.models.ssvi import SSVI

    ssvi = SSVI()
    ssvi_slices, _fit = ssvi.fit_surface(slices)

    surface = VolSurface(ticker=ticker)
    for ms in slices:
        surface.slices[ms.expiry_years] = ssvi_slices[ms.expiry_years]
        surface.market_data[ms.expiry_years] = ms

    if plot:
        from volsurface.plotting.visualize import plot_surface

        plot_surface(surface, kind="3d", show=True)

    return surface
