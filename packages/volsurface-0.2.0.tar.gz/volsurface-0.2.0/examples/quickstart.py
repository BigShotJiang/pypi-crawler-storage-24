"""Quick-start example: fetch TICKER options, fit Raw SVI and SSVI, and plot.

Run with::

    pip install volsurface[all]
    python examples/quickstart.py
"""

from __future__ import annotations

import numpy as np

from volsurface.calibration import calibrate_surface
from volsurface.core import VolSurface
from volsurface.diagnostics import compare_surfaces
from volsurface.market_data import fetch_chain
from volsurface.models import SSVI, RawSVI
from volsurface.plotting import plot_smile, plot_surface


def main() -> None:
    # 1. Fetch live option chains
    print("One second.. fetching option chains from Yahoo Finance...")
    slices = fetch_chain("SPY", min_volume=30, moneyness_range=(0.8, 1.2))
    print(f" --> {len(slices)} expiries with sufficient liquidity\n")

    # ── Raw SVI (per-expiry) ──────────────────────────────────────────

    # 2. Calibrate Raw SVI to each expiry
    print("Calibrating Raw SVI to each expiry...")
    result = calibrate_surface(slices, RawSVI, ticker="SPY")

    for t, fr in sorted(result.fit_results.items()):
        status = "checkmark --" if fr.success else "violation --"
        print(f"  {status} T={t:.4f}y  RMSE={fr.rmse:.6f}  ({fr.n_iterations} iters)")

    # 3. Arbitrage diagnostics
    print()
    if result.arbitrage_report and result.arbitrage_report.is_clean:
        print("No arbitrage violations detected checkmark")
    else:
        report = result.arbitrage_report
        if report:
            print(f"Butterfly violations: {len(report.butterfly_violations)}")
            print(f"Calendar violations:  {len(report.calendar_violations)}")

    # 4. Query the SVI surface
    print()
    pt = result.surface.iv(strike=slices[0].forward, expiry_years=slices[0].expiry_years)
    print(f"ATM IV (SVI) at T={pt.expiry_years:.4f}y: {pt.iv:.4f}")

    # ── SSVI (globally consistent surface) ───────────────────────────

    # 5. Calibrate SSVI across all expiries simultaneously
    print()
    print("Calibrating SSVI surface (global rho/eta/gamma)...")
    ssvi = SSVI()
    ssvi_slices, ssvi_result = ssvi.fit_surface(slices)

    p = ssvi.global_params
    print(f"  Global params — rho={p.rho:.4f}  eta={p.eta:.4f}  gamma={p.gamma:.4f}")
    print(f"  Surface RMSE:  {ssvi_result.rmse:.6f}  (success={ssvi_result.success})")

    # 6. Sample ATM IVs from each SSVI slice
    print()
    print("SSVI ATM implied vols:")
    for t in sorted(ssvi_slices):
        sl = ssvi_slices[t]
        atm_iv = float(sl.iv(np.array([0.0]))[0])
        print(f"  T={t:.4f}y  ATM IV={atm_iv:.4f}")

    # ── Plots ─────────────────────────────────────────────────────────

    # 7. Raw SVI: single smile + full surface
    first_expiry = result.surface.expiries[0]
    model = result.surface.slices[first_expiry]
    market = result.surface.market_data[first_expiry]
    plot_smile(market, model=model, show=True)

    plot_surface(result.surface, kind="smiles", show=True)
    plot_surface(result.surface, kind="3d", show=True)

    # 8. Compare Raw SVI vs SSVI side-by-side
    # (assemble SSVI VolSurface first so diagnose_surface can query it)
    ssvi_surface = VolSurface(ticker="SPY (SSVI)")
    for ms in slices:
        ssvi_surface.slices[ms.expiry_years] = ssvi_slices[ms.expiry_years]
        ssvi_surface.market_data[ms.expiry_years] = ms

    comparison = compare_surfaces(result.surface, ssvi_surface, "Raw SVI", "SSVI")
    print()
    print(comparison.summary_table())

    # 9. SSVI plots
    # Single smile (first expiry)
    first_t = ssvi_surface.expiries[0]
    plot_smile(ssvi_surface.market_data[first_t], model=ssvi_slices[first_t], show=True)

    # All smiles overlaid
    plot_surface(ssvi_surface, kind="smiles", show=True)

    # 3-D surface
    plot_surface(ssvi_surface, kind="3d", show=True)


if __name__ == "__main__":
    main()
