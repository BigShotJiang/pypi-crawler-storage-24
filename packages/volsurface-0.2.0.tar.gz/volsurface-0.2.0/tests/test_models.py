"""Tests for the Raw SVI model implementation."""

from __future__ import annotations

import numpy as np
import pytest

from volsurface.core import MarketSlice
from volsurface.models.svi import RawSVI, SVIParams


class TestSVIParams:
    """Tests for the SVIParams container."""

    def test_roundtrip_array(self) -> None:
        p = SVIParams(a=0.04, b=0.1, rho=-0.3, m=0.0, sigma=0.1)
        arr = p.to_array()
        p2 = SVIParams.from_array(arr)
        assert abs(p.a - p2.a) < 1e-12
        assert abs(p.rho - p2.rho) < 1e-12

    def test_as_dict(self) -> None:
        p = SVIParams(a=0.04, b=0.1, rho=-0.3, m=0.0, sigma=0.1)
        d = p.as_dict()
        assert set(d.keys()) == {"a", "b", "rho", "m", "sigma"}
        assert d["rho"] == -0.3

    def test_check_no_arbitrage_clean_params(self) -> None:
        """Well-behaved SVI parameters should pass all conditions."""
        p = SVIParams(a=0.04, b=0.2, rho=-0.3, m=0.0, sigma=0.3)
        assert p.check_no_arbitrage() == []

    def test_check_no_arbitrage_negative_b(self) -> None:
        p = SVIParams(a=0.04, b=-0.1, rho=-0.3, m=0.0, sigma=0.3)
        violations = p.check_no_arbitrage()
        assert any("b=" in v for v in violations)

    def test_check_no_arbitrage_negative_min_variance(self) -> None:
        # Force a + b*sigma*sqrt(1-rho^2) < 0
        p = SVIParams(a=-1.0, b=0.1, rho=0.0, m=0.0, sigma=0.1)
        violations = p.check_no_arbitrage()
        assert any("minimum total variance" in v for v in violations)

    def test_check_no_arbitrage_lee_condition(self) -> None:
        # b*(1 + |rho|) >= 4
        p = SVIParams(a=0.04, b=3.0, rho=0.5, m=0.0, sigma=0.3)
        violations = p.check_no_arbitrage()
        assert any("Roger Lee" in v for v in violations)


class TestRawSVI:
    """Tests for the RawSVI model."""

    def test_unfitted_model_raises(self) -> None:
        model = RawSVI()
        with pytest.raises(RuntimeError, match="not been fitted"):
            model.iv(0.0)

    def test_unfitted_params_raises(self) -> None:
        model = RawSVI()
        with pytest.raises(RuntimeError, match="not been fitted"):
            _ = model.params

    def test_n_params(self) -> None:
        assert RawSVI().n_params == 5

    def test_fit_converges(self, synthetic_smile: MarketSlice) -> None:
        model = RawSVI()
        result = model.fit(synthetic_smile)
        assert result.success
        assert result.rmse < 0.01  # should fit synthetic data very well
        assert result.n_iterations > 0

    def test_fit_residuals_shape(self, synthetic_smile: MarketSlice) -> None:
        model = RawSVI()
        result = model.fit(synthetic_smile)
        assert result.residuals.shape == (synthetic_smile.n_strikes,)

    def test_fitted_model_returns_positive_iv(self, synthetic_smile: MarketSlice) -> None:
        model = RawSVI()
        model.fit(synthetic_smile)
        k_grid = np.linspace(-0.3, 0.3, 50)
        ivs = model.iv(k_grid)
        assert np.all(ivs > 0)

    def test_total_variance_increases_from_atm(self, synthetic_smile: MarketSlice) -> None:
        """SVI total variance should form a smile shape (increase away from ATM)."""
        model = RawSVI()
        model.fit(synthetic_smile)
        w_atm = float(model.total_variance(0.0)[0])
        w_far_otm = float(model.total_variance(0.2)[0])
        assert w_far_otm > w_atm

    def test_scalar_and_array_inputs_consistent(self, synthetic_smile: MarketSlice) -> None:
        model = RawSVI()
        model.fit(synthetic_smile)

        k = 0.05
        iv_scalar = model.iv(k)
        iv_array = model.iv(np.array([k]))
        assert abs(float(iv_scalar[0]) - float(iv_array[0])) < 1e-12

    def test_params_accessible_after_fit(self, synthetic_smile: MarketSlice) -> None:
        model = RawSVI()
        model.fit(synthetic_smile)
        p = model.params
        assert isinstance(p, SVIParams)
        assert p.b > 0
        assert abs(p.rho) < 1
        assert p.sigma > 0

    def test_parameter_recovery_on_synthetic_svi(self) -> None:
        """Fit should recover known SVI parameters from noise-free synthetic data."""
        true = SVIParams(a=0.04, b=0.15, rho=-0.4, m=0.0, sigma=0.2)
        k = np.linspace(-0.4, 0.4, 30)
        w_true = RawSVI._w(k, true.a, true.b, true.rho, true.m, true.sigma)
        T = 0.5
        ivs = np.sqrt(w_true / T)

        ms = MarketSlice(
            strikes=np.exp(k) * 100.0,  # convert log-moneyness to strikes
            ivs=ivs,
            expiry_years=T,
            forward=100.0,
            spot=100.0,
        )
        model = RawSVI()
        result = model.fit(ms)
        p = model.params

        assert result.rmse < 1e-4
        assert abs(p.a - true.a) < 0.01
        assert abs(p.b - true.b) < 0.01
        assert abs(p.rho - true.rho) < 0.05
        assert abs(p.sigma - true.sigma) < 0.05
