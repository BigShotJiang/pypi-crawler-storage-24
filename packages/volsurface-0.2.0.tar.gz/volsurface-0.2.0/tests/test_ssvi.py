"""Tests for the SSVI model and forward estimation."""

from __future__ import annotations

import numpy as np
import pytest

from volsurface.core import MarketSlice
from volsurface.market_data.forward import estimate_forward_from_parity
from volsurface.models.ssvi import SSVI, SSVIGlobalParams, SSVISlice, _ssvi_w

# ── Helpers ──────────────────────────────────────────────────────────


def _make_ssvi_slice(
    T: float,  # noqa: N803
    rho: float = -0.3,
    eta: float = 1.5,
    gamma: float = 0.5,
    theta: float | None = None,
) -> MarketSlice:
    """Build a synthetic MarketSlice generated from SSVI with known parameters."""
    forward = 100.0
    strikes = np.linspace(80.0, 120.0, 20)
    k = np.log(strikes / forward)

    if theta is None:
        theta = 0.04 + 0.02 * T  # simple linear ATM term structure

    w = _ssvi_w(k, theta, rho, eta, gamma)
    ivs = np.sqrt(w / T)

    return MarketSlice(
        strikes=strikes,
        ivs=ivs,
        expiry_years=T,
        forward=forward,
        spot=forward,
    )


def _make_ssvi_surface(
    expiries: list[float],
    rho: float = -0.3,
    eta: float = 1.5,
    gamma: float = 0.5,
) -> list[MarketSlice]:
    return [_make_ssvi_slice(T, rho=rho, eta=eta, gamma=gamma) for T in expiries]


# ── Tests ─────────────────────────────────────────────────────────────


class TestSSVIFormula:
    """Unit tests for the SSVI total-variance formula."""

    def test_non_negative_total_variance(self) -> None:
        k = np.linspace(-0.5, 0.5, 50)
        w = _ssvi_w(k, theta=0.04, rho=-0.3, eta=1.5, gamma=0.5)
        assert np.all(w >= 0)

    def test_atm_value(self) -> None:
        """At k=0 the SSVI formula reduces to theta/2 * (1 + rho*phi*0 + sqrt((rho)^2 + 1-rho^2))
        = theta/2 * (1 + |rho|) ... actually w(0) = theta/2*(1+sqrt(1)) = theta when rho=0.
        Let's just check it equals theta when rho=0."""
        w_atm = float(_ssvi_w(np.array([0.0]), theta=0.04, rho=0.0, eta=1.5, gamma=0.5)[0])
        # At k=0, rho=0: w = theta/2 * (1 + 0 + sqrt(rho^2 + 1-rho^2)) = theta/2 * 2 = theta
        assert abs(w_atm - 0.04) < 1e-10

    def test_smile_is_symmetric_when_rho_zero(self) -> None:
        """When rho=0 the SSVI smile is symmetric in k."""
        k = np.array([-0.2, -0.1, 0.0, 0.1, 0.2])
        w = _ssvi_w(k, theta=0.04, rho=0.0, eta=1.5, gamma=0.5)
        assert abs(w[0] - w[4]) < 1e-10
        assert abs(w[1] - w[3]) < 1e-10


class TestSSVIGlobalParams:
    """Tests for SSVIGlobalParams."""

    def test_roundtrip_array(self) -> None:
        p = SSVIGlobalParams(rho=-0.3, eta=1.5, gamma=0.5)
        arr = p.to_array()
        p2 = SSVIGlobalParams.from_array(arr)
        assert abs(p.rho - p2.rho) < 1e-12
        assert abs(p.eta - p2.eta) < 1e-12
        assert abs(p.gamma - p2.gamma) < 1e-12

    def test_as_dict_keys(self) -> None:
        p = SSVIGlobalParams(rho=-0.3, eta=1.5, gamma=0.5)
        assert set(p.as_dict().keys()) == {"rho", "eta", "gamma"}


class TestSSVISlice:
    """Tests for SSVISlice (per-expiry model)."""

    def test_total_variance_positive(self) -> None:
        g = SSVIGlobalParams(rho=-0.3, eta=1.5, gamma=0.5)
        sl = SSVISlice(theta=0.04, global_params=g, expiry_years=0.25)
        k = np.linspace(-0.3, 0.3, 20)
        w = sl.total_variance(k)
        assert np.all(w > 0)

    def test_fit_not_supported(self) -> None:
        g = SSVIGlobalParams(rho=-0.3, eta=1.5, gamma=0.5)
        sl = SSVISlice(theta=0.04, global_params=g, expiry_years=0.25)
        ms = _make_ssvi_slice(0.25)
        with pytest.raises(NotImplementedError):
            sl.fit(ms)

    def test_iv_via_base_class(self) -> None:
        """iv() from VolModel base should work after theta/expiry_years are set."""
        g = SSVIGlobalParams(rho=-0.3, eta=1.5, gamma=0.5)
        sl = SSVISlice(theta=0.04, global_params=g, expiry_years=0.25)
        ivs = sl.iv(np.linspace(-0.2, 0.2, 10))
        assert np.all(ivs > 0)


class TestSSVI:
    """Tests for the full SSVI calibration."""

    def test_fit_surface_returns_slice_dict_and_result(self) -> None:
        slices = _make_ssvi_surface([0.25, 0.5, 1.0])
        ssvi = SSVI()
        slice_models, result = ssvi.fit_surface(slices)
        assert len(slice_models) == 3
        assert result.rmse >= 0
        assert result.success

    def test_fitted_global_params_in_range(self) -> None:
        slices = _make_ssvi_surface([0.25, 0.5, 1.0])
        ssvi = SSVI()
        ssvi.fit_surface(slices)
        p = ssvi.global_params
        assert -1 < p.rho < 1
        assert p.eta > 0
        assert 0 < p.gamma <= 1

    def test_global_params_recovered_from_synthetic_data(self) -> None:
        """SSVI should approximately recover the true global params from noise-free data."""
        true_rho, true_eta, true_gamma = -0.3, 1.5, 0.5
        slices = _make_ssvi_surface(
            [0.1, 0.25, 0.5, 1.0], rho=true_rho, eta=true_eta, gamma=true_gamma
        )
        ssvi = SSVI()
        ssvi.fit_surface(slices)
        p = ssvi.global_params

        assert abs(p.rho - true_rho) < 0.05
        assert abs(p.eta - true_eta) < 0.2
        assert abs(p.gamma - true_gamma) < 0.1

    def test_slice_model_gives_reasonable_iv(self) -> None:
        slices = _make_ssvi_surface([0.25, 0.5, 1.0])
        ssvi = SSVI()
        ssvi.fit_surface(slices)
        sl = ssvi.slice_model(0.25)
        ivs = sl.iv(np.linspace(-0.2, 0.2, 20))
        assert np.all(ivs > 0)

    def test_fit_surface_requires_at_least_two_slices(self) -> None:
        slices = _make_ssvi_surface([0.25])
        ssvi = SSVI()
        with pytest.raises(ValueError, match="at least 2"):
            ssvi.fit_surface(slices)

    def test_global_params_raises_before_fit(self) -> None:
        ssvi = SSVI()
        with pytest.raises(RuntimeError, match="not been fitted"):
            _ = ssvi.global_params

    def test_fit_result_contains_theta_entries(self) -> None:
        slices = _make_ssvi_surface([0.25, 0.5])
        ssvi = SSVI()
        _, result = ssvi.fit_surface(slices)
        # FitResult params dict should contain theta_* keys
        theta_keys = [k for k in result.params if k.startswith("theta_")]
        assert len(theta_keys) == 2


class TestEstimateForwardFromParity:
    """Tests for the put-call parity forward estimator."""

    def test_exact_parity_multiple_strikes(self) -> None:
        """With exact call-put pairs (C-P=2) and r=0, median forward = 102."""
        K = np.array([99.0, 100.0, 101.0])
        C = np.array([6.0, 5.0, 4.0])
        P = np.array([4.0, 3.0, 2.0])
        # F = K + e^{rT}*(C-P) = K + 2 for each strike; median([101, 102, 103]) = 102
        forward = estimate_forward_from_parity(K, C, P, expiry_years=1.0, rate=0.0)
        assert abs(forward - 102.0) < 1e-10

    def test_median_aggregation(self) -> None:
        """Median of multiple strike estimates should be robust to a wing outlier."""
        K = np.array([95.0, 100.0, 105.0, 110.0])
        # Exact: F = 102 at every strike (C-P = 2 at each strike, r=0)
        C = np.array([7.0, 5.0, 3.0, 1000.0])  # last is outlier
        P = np.array([5.0, 3.0, 1.0, 998.0])
        forward = estimate_forward_from_parity(K, C, P, expiry_years=1.0, rate=0.0)
        # Median of [95+2, 100+2, 105+2, 110+2] = [97, 102, 107, 112] → median = 104.5
        assert abs(forward - 104.5) < 1e-8

    def test_fallback_when_insufficient_pairs(self) -> None:
        """When < 3 valid pairs, fall back to spot forward."""
        K = np.array([100.0])
        C = np.array([np.nan])
        P = np.array([np.nan])
        forward = estimate_forward_from_parity(K, C, P, expiry_years=1.0, rate=0.0, spot=100.0)
        assert abs(forward - 100.0) < 1e-10

    def test_raises_without_fallback_and_insufficient_pairs(self) -> None:
        K = np.array([100.0])
        C = np.array([np.nan])
        P = np.array([np.nan])
        with pytest.raises(ValueError, match="provide a spot fallback"):
            estimate_forward_from_parity(K, C, P, expiry_years=1.0, rate=0.0)

    def test_rate_effect(self) -> None:
        """Non-zero rate should increase the forward."""
        K = np.array([100.0, 101.0, 102.0])
        # C-P = 2 at each strike; F = K + exp(r)*2 for r > 0 → F > K+2
        C = np.array([4.0, 4.0, 4.0])
        P = np.array([2.0, 2.0, 2.0])
        r = 0.05
        T = 1.0
        fwd = estimate_forward_from_parity(K, C, P, expiry_years=T, rate=r)
        fwd_no_rate = estimate_forward_from_parity(K, C, P, expiry_years=T, rate=0.0)
        assert fwd > fwd_no_rate

    def test_negative_prices_excluded(self) -> None:
        """Zero/negative prices should be treated as missing."""
        K = np.array([100.0, 101.0, 102.0, 103.0])
        C = np.array([5.0, 0.0, 4.0, 3.0])
        P = np.array([3.0, 0.0, 2.0, 1.0])
        # Row 2 has zero prices — should be excluded; 3 valid pairs remain
        forward = estimate_forward_from_parity(K, C, P, expiry_years=1.0, rate=0.0)
        assert np.isfinite(forward)
