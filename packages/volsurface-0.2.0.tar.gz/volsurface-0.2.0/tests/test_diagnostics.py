"""Tests for the diagnostics module and the DataFrame-based estimate_forward."""

from __future__ import annotations

import numpy as np
import pandas as pd

from volsurface.core import MarketSlice, VolSurface
from volsurface.diagnostics import (
    SurfaceComparison,
    SurfaceDiagnostic,
    compare_surfaces,
    diagnose_surface,
)
from volsurface.market_data.forward import estimate_forward
from volsurface.models.svi import RawSVI

# ── Helpers ───────────────────────────────────────────────────────────


def _make_call_put_dfs(
    strikes: list[float],
    forwards: list[float],
    *,
    rate: float = 0.0,
    expiry_years: float = 1.0,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Build synthetic call/put DataFrames satisfying parity exactly.

    C - P = (F - K) * exp(-rT), so with bid=ask=mid the parity
    forward is recovered exactly.
    """
    discount = float(np.exp(-rate * expiry_years))
    calls_rows = []
    puts_rows = []
    for K, F in zip(strikes, forwards, strict=True):
        intrinsic = (F - K) * discount
        c_mid = max(intrinsic, 0.0) + 1.0  # ensure positive
        p_mid = c_mid - intrinsic
        calls_rows.append({"strike": K, "bid": c_mid, "ask": c_mid})
        puts_rows.append({"strike": K, "bid": max(p_mid, 0.01), "ask": max(p_mid, 0.01)})
    return pd.DataFrame(calls_rows), pd.DataFrame(puts_rows)


def _make_surface_with_svi(expiries: list[float]) -> VolSurface:
    """Fit RawSVI to synthetic SSVI-generated slices; return a VolSurface."""
    from volsurface.models.ssvi import _ssvi_w

    surface = VolSurface(ticker="TEST")
    for T in expiries:
        forward = 100.0
        strikes = np.linspace(80.0, 120.0, 20)
        k = np.log(strikes / forward)
        theta = 0.04 + 0.02 * T
        w = _ssvi_w(k, theta, rho=-0.3, eta=1.5, gamma=0.5)
        ivs = np.sqrt(w / T)
        ms = MarketSlice(strikes=strikes, ivs=ivs, expiry_years=T, forward=forward, spot=forward)
        model = RawSVI()
        model.fit(ms)
        surface.slices[T] = model
        surface.market_data[T] = ms
    return surface


# ── Tests: estimate_forward (DataFrame-based) ─────────────────────────


class TestEstimateForward:
    """Tests for the public DataFrame-based estimate_forward function."""

    def test_exact_parity_recovery(self) -> None:
        """Parity-exact quotes should recover the true forward."""
        F_true = 102.0
        strikes = [99.0, 100.0, 101.0, 102.0, 103.0]
        forwards = [F_true] * len(strikes)
        calls, puts = _make_call_put_dfs(strikes, forwards, expiry_years=1.0)
        fwd = estimate_forward(calls, puts, spot=100.0, expiry_years=1.0, rate=0.0)
        assert abs(fwd - F_true) < 1e-6

    def test_fallback_when_all_zero_bids(self) -> None:
        """All-zero bid/ask quotes should fall back to spot * exp(rT)."""
        K = [95.0, 100.0, 105.0, 110.0, 115.0]
        calls = pd.DataFrame({"strike": K, "bid": [0.0] * 5, "ask": [0.0] * 5})
        puts = pd.DataFrame({"strike": K, "bid": [0.0] * 5, "ask": [0.0] * 5})
        fwd = estimate_forward(calls, puts, spot=100.0, expiry_years=1.0, rate=0.0)
        assert abs(fwd - 100.0) < 1e-10

    def test_fallback_with_nonzero_rate(self) -> None:
        """Fallback uses spot * exp(rT) when quotes are zero."""
        K = [95.0, 100.0, 105.0]
        calls = pd.DataFrame({"strike": K, "bid": [0.0] * 3, "ask": [0.0] * 3})
        puts = pd.DataFrame({"strike": K, "bid": [0.0] * 3, "ask": [0.0] * 3})
        r, T = 0.05, 1.0
        fwd = estimate_forward(calls, puts, spot=100.0, expiry_years=T, rate=r)
        assert abs(fwd - 100.0 * np.exp(r * T)) < 1e-8

    def test_sanity_bound_triggers_fallback(self) -> None:
        """A forward implied at 2× spot should be rejected and fall back."""
        # Make C - P = spot everywhere → F ≈ 2 * spot
        K = [95.0, 100.0, 105.0, 110.0, 115.0]
        spot = 100.0
        calls = pd.DataFrame({"strike": K, "bid": [spot] * 5, "ask": [spot] * 5})
        puts = pd.DataFrame({"strike": K, "bid": [0.01] * 5, "ask": [0.01] * 5})
        fwd = estimate_forward(calls, puts, spot=spot, expiry_years=1.0, rate=0.0)
        # Should fall back because F ≈ K + spot >> 1.2 * spot
        assert abs(fwd - spot) < 1e-8

    def test_insufficient_matched_pairs_fallback(self) -> None:
        """Fewer than _MIN_PAIRS matched strikes should fall back."""
        # Only 1 common strike
        calls = pd.DataFrame({"strike": [100.0], "bid": [5.0], "ask": [5.0]})
        puts = pd.DataFrame({"strike": [100.0], "bid": [3.0], "ask": [3.0]})
        fwd = estimate_forward(calls, puts, spot=100.0, expiry_years=1.0, rate=0.0)
        assert abs(fwd - 100.0) < 1e-8

    def test_median_is_robust_to_outlier(self) -> None:
        """An outlier put at one wing should not strongly shift the median."""
        F_true = 102.0
        strikes = [98.0, 100.0, 101.0, 102.0, 103.0]
        forwards = [F_true] * len(strikes)
        calls, puts = _make_call_put_dfs(strikes, forwards, expiry_years=1.0)
        # Corrupt the first put quote to imply a nonsense forward
        puts.loc[0, "bid"] = 0.01
        puts.loc[0, "ask"] = 0.01
        fwd = estimate_forward(calls, puts, spot=100.0, expiry_years=1.0, rate=0.0)
        # Median of remaining valid strikes should still be close to F_true
        assert abs(fwd - F_true) < 0.5


# ── Tests: diagnose_surface ────────────────────────────────────────────


class TestDiagnoseSurface:
    """Tests for diagnose_surface."""

    def test_returns_surface_diagnostic(self) -> None:
        surface = _make_surface_with_svi([0.25, 0.5])
        diag = diagnose_surface(surface)
        assert isinstance(diag, SurfaceDiagnostic)

    def test_slice_count_matches_expiries(self) -> None:
        surface = _make_surface_with_svi([0.25, 0.5, 1.0])
        diag = diagnose_surface(surface)
        assert len(diag.slices) == 3

    def test_rmse_non_negative(self) -> None:
        surface = _make_surface_with_svi([0.25, 0.5])
        diag = diagnose_surface(surface)
        assert diag.total_rmse >= 0
        assert all(s.rmse >= 0 for s in diag.slices)

    def test_max_abs_ge_mean_abs(self) -> None:
        surface = _make_surface_with_svi([0.25, 0.5])
        diag = diagnose_surface(surface)
        for s in diag.slices:
            assert s.max_abs_error >= s.mean_abs_error - 1e-12

    def test_n_strikes_correct(self) -> None:
        surface = _make_surface_with_svi([0.25])
        diag = diagnose_surface(surface)
        assert diag.slices[0].n_strikes == 20  # _make_surface_with_svi uses 20 strikes

    def test_perfect_fit_has_near_zero_rmse(self) -> None:
        """A model queried at its own training data should have ~0 RMSE."""
        # Use synthetic data where the model perfectly fits by construction
        surface = _make_surface_with_svi([0.5])
        diag = diagnose_surface(surface)
        # RawSVI fit to its own synthetic data — RMSE should be very small
        assert diag.total_rmse < 0.01

    def test_single_expiry_works(self) -> None:
        surface = _make_surface_with_svi([0.25])
        diag = diagnose_surface(surface)
        assert len(diag.slices) == 1
        assert diag.total_rmse >= 0

    def test_empty_surface_returns_default(self) -> None:
        surface = VolSurface()
        diag = diagnose_surface(surface)
        assert diag.total_rmse == 0.0
        assert diag.slices == []


# ── Tests: compare_surfaces ────────────────────────────────────────────


class TestCompareSurfaces:
    """Tests for compare_surfaces and SurfaceComparison.summary_table."""

    def _two_surfaces(self) -> tuple[VolSurface, VolSurface]:
        return _make_surface_with_svi([0.25, 0.5]), _make_surface_with_svi([0.25, 0.5])

    def test_returns_surface_comparison(self) -> None:
        sa, sb = self._two_surfaces()
        comp = compare_surfaces(sa, sb, "SVI", "SSVI")
        assert isinstance(comp, SurfaceComparison)

    def test_labels_stored(self) -> None:
        sa, sb = self._two_surfaces()
        comp = compare_surfaces(sa, sb, "Raw SVI", "SSVI")
        assert comp.label_a == "Raw SVI"
        assert comp.label_b == "SSVI"

    def test_summary_table_is_string(self) -> None:
        sa, sb = self._two_surfaces()
        comp = compare_surfaces(sa, sb, "Raw SVI", "SSVI")
        table = comp.summary_table()
        assert isinstance(table, str)

    def test_summary_table_contains_labels(self) -> None:
        sa, sb = self._two_surfaces()
        comp = compare_surfaces(sa, sb, "Raw SVI", "SSVI")
        table = comp.summary_table()
        assert "Raw SVI" in table
        assert "SSVI" in table

    def test_summary_table_contains_expiry_rows(self) -> None:
        sa, sb = self._two_surfaces()
        comp = compare_surfaces(sa, sb)
        table = comp.summary_table()
        assert "T=0.250" in table
        assert "T=0.500" in table

    def test_summary_table_contains_totals(self) -> None:
        sa, sb = self._two_surfaces()
        comp = compare_surfaces(sa, sb, "A", "B")
        table = comp.summary_table()
        assert "Total RMSE" in table
        assert "Mean slice RMSE" in table

    def test_same_surface_gives_identical_columns(self) -> None:
        """Comparing a surface to itself should give identical RMSE values."""
        sa = _make_surface_with_svi([0.25, 0.5])
        comp = compare_surfaces(sa, sa)
        assert abs(comp.diag_a.total_rmse - comp.diag_b.total_rmse) < 1e-12
