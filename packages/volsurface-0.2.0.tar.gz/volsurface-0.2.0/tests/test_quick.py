"""Tests for volsurface.quick — iv_surface convenience function."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import numpy as np
import pytest

from volsurface.core import MarketSlice, VolSurface
from volsurface.quick import iv_surface

_FETCH = "volsurface.market_data.yahoo.fetch_chain"
_PLOT = "volsurface.plotting.visualize.plot_surface"


def _make_slices() -> list[MarketSlice]:
    """Return synthetic slices for mocking fetch_chain."""
    forward = 100.0
    spot = 100.0
    slices = []
    for T in [0.25, 0.5, 1.0]:
        strikes = np.linspace(85, 115, 15)
        log_m = np.log(strikes / forward)
        ivs = 0.20 + 0.4 * log_m**2 + 0.03 * log_m
        slices.append(
            MarketSlice(
                strikes=strikes,
                ivs=ivs,
                expiry_years=T,
                forward=forward,
                spot=spot,
                ticker="TEST",
            )
        )
    return slices


class TestIvSurface:
    def test_invalid_model_raises(self) -> None:
        with pytest.raises(ValueError, match="Unknown model"):
            iv_surface("SPY", model="sabr")

    def test_invalid_model_message_lists_options(self) -> None:
        with pytest.raises(ValueError, match=r"svi.*ssvi"):
            iv_surface("SPY", model="unknown")

    @patch(_FETCH)
    def test_svi_returns_calibration_result(self, mock_fetch: MagicMock) -> None:
        from volsurface.calibration.engine import CalibrationResult

        mock_fetch.return_value = _make_slices()
        result = iv_surface("TEST", model="svi")
        assert isinstance(result, CalibrationResult)
        mock_fetch.assert_called_once_with("TEST")

    @patch(_FETCH)
    def test_ssvi_returns_vol_surface(self, mock_fetch: MagicMock) -> None:
        mock_fetch.return_value = _make_slices()
        result = iv_surface("TEST", model="ssvi")
        assert isinstance(result, VolSurface)
        mock_fetch.assert_called_once_with("TEST")

    @patch(_FETCH)
    def test_svi_case_insensitive(self, mock_fetch: MagicMock) -> None:
        from volsurface.calibration.engine import CalibrationResult

        mock_fetch.return_value = _make_slices()
        result = iv_surface("TEST", model="SVI")
        assert isinstance(result, CalibrationResult)

    @patch(_FETCH)
    def test_ssvi_case_insensitive(self, mock_fetch: MagicMock) -> None:
        mock_fetch.return_value = _make_slices()
        result = iv_surface("TEST", model="SSVI")
        assert isinstance(result, VolSurface)

    @patch(_FETCH)
    def test_svi_surface_has_correct_expiries(self, mock_fetch: MagicMock) -> None:
        from volsurface.calibration.engine import CalibrationResult

        slices = _make_slices()
        mock_fetch.return_value = slices
        result = iv_surface("TEST", model="svi")
        assert isinstance(result, CalibrationResult)
        assert len(result.surface.expiries) == len(slices)

    @patch(_FETCH)
    def test_ssvi_surface_has_correct_expiries(self, mock_fetch: MagicMock) -> None:
        slices = _make_slices()
        mock_fetch.return_value = slices
        result = iv_surface("TEST", model="ssvi")
        assert isinstance(result, VolSurface)
        assert len(result.expiries) == len(slices)

    @patch(_FETCH)
    def test_fetch_kwargs_forwarded(self, mock_fetch: MagicMock) -> None:
        mock_fetch.return_value = _make_slices()
        iv_surface("TEST", model="svi", min_volume=10, min_days_to_expiry=14)
        mock_fetch.assert_called_once_with("TEST", min_volume=10, min_days_to_expiry=14)

    @patch(_PLOT)
    @patch(_FETCH)
    def test_svi_plot_true_calls_plot_surface(
        self, mock_fetch: MagicMock, mock_plot: MagicMock
    ) -> None:
        mock_fetch.return_value = _make_slices()
        iv_surface("TEST", model="svi", plot=True)
        mock_plot.assert_called_once()

    @patch(_PLOT)
    @patch(_FETCH)
    def test_ssvi_plot_true_calls_plot_surface(
        self, mock_fetch: MagicMock, mock_plot: MagicMock
    ) -> None:
        mock_fetch.return_value = _make_slices()
        iv_surface("TEST", model="ssvi", plot=True)
        mock_plot.assert_called_once()
