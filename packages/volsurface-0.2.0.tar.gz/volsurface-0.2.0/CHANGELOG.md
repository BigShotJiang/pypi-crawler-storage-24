# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/).

## [0.2.0] — 2026-03-07

### Added

- **SSVI model** (`volsurface.models.SSVI`) — Surface SVI with global (ρ, η, γ) calibration across all expiries simultaneously; free of calendar arbitrage by construction
- **Put-call parity forward estimation** — `estimate_forward(calls_df, puts_df, spot, expiry_years)` in `volsurface.market_data`; estimates the implied forward from mid-prices with median aggregation and ±20% sanity bounds
- **Fit diagnostics** — `diagnose_surface`, `compare_surfaces`, `SliceDiagnostic`, `SurfaceDiagnostic`, `SurfaceComparison` in `volsurface.diagnostics`
- **SVI no-arbitrage conditions** — `SVIParams.check_no_arbitrage()` checks the four Gatheral-Jacquier parameter-level conditions
- **Theory & Models documentation** — full mathematical background page with LaTeX derivations for SVI and SSVI

### Changed

- Yahoo adapter now fetches both calls and puts per expiry and uses `estimate_forward` for the forward price instead of `forward = spot`
- Improved SVI initial guess scaling — starting points are now derived from the data range (ATM level, strike spread, variance spread) rather than fixed constants
- `fetch_chain` now accepts an optional `rate` parameter (continuously compounded risk-free rate)
- `clean_chain` now averages IVs across duplicate strikes instead of keeping the first occurrence
- `VolSurface._bracket_expiry` uses `bisect.bisect_right` (O(log n)) instead of a linear scan
- Logging in `fetch_chain` now reports forward vs spot: `Added 2025-06-20 (T=0.2877, 42 strikes, F=265.32 vs S=263.15)`

## [0.1.0] — Unreleased

### Added

- Initial release
- Raw SVI parameterisation with L-BFGS-B calibration
- `MarketSlice`, `VolSurface`, `FitResult` core types
- Butterfly and calendar spread arbitrage checks
- Yahoo Finance option chain fetcher
- Linear interpolation in total-variance space
- 3D surface, heatmap, and smile overlay plots
- Full `mypy --strict` compliance
