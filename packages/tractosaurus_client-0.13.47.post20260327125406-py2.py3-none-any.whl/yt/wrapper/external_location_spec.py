from abc import abstractmethod
from dataclasses import dataclass, asdict

from .external_creds_spec import ExternalCredsSpecS3


class ExternalLocationSpec:
    @abstractmethod
    def to_param(self):
        pass


@dataclass
class ExternalLocationSpecS3(ExternalLocationSpec):
    credentials: ExternalCredsSpecS3
    bucket: str
    prefix: str

    def to_param(self):
        return {**asdict(self.credentials), "bucket": self.bucket, "prefix": self.prefix}
