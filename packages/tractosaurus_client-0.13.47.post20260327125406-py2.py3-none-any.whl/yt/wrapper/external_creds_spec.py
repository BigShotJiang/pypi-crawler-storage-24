from abc import abstractmethod
from dataclasses import dataclass, asdict


class ExternalCredsSpec:
    @abstractmethod
    def to_param(self):
        pass


@dataclass
class ExternalCredsSpecS3(ExternalCredsSpec):
    url: str
    region: str
    access_key_id: str
    secret_access_key: str

    def to_param(self):
        return {"type": "s3", **asdict(self)}
