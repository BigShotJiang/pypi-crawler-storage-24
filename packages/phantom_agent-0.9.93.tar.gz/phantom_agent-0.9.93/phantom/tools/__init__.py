import os

from phantom.config import Config

from .executor import (
    execute_tool,
    execute_tool_invocation,
    execute_tool_with_validation,
    extract_screenshot_from_result,
    process_tool_invocations,
    remove_screenshot_from_result,
    validate_tool_availability,
)
from .registry import (
    ImplementedInClientSideOnlyError,
    get_tool_by_name,
    get_tool_names,
    get_tools_prompt,
    needs_agent_state,
    register_tool,
    tools,
)


SANDBOX_MODE = os.getenv("PHANTOM_SANDBOX_MODE", "false").lower() == "true"

HAS_PERPLEXITY_API = bool(Config.get("perplexity_api_key"))

DISABLE_BROWSER = (Config.get("phantom_disable_browser") or "false").lower() == "true"

if not SANDBOX_MODE:
    from .agents_graph import *

    if not DISABLE_BROWSER:
        from .browser import *
    from .file_edit import *
    from .finish import *
    from .notes import *
    from .proxy import *
    from .python import *
    from .reporting import *
    from .scan_registry import *
    from .session import *
    from .terminal import *
    from .thinking import *
    from .todo import *
    if HAS_PERPLEXITY_API:
        from .web_search import *
else:
    if not DISABLE_BROWSER:
        from .browser import *
    from .file_edit import *
    from .proxy import *
    from .python import *
    from .terminal import *

__all__ = [
    "ImplementedInClientSideOnlyError",
    "execute_tool",
    "execute_tool_invocation",
    "execute_tool_with_validation",
    "extract_screenshot_from_result",
    "get_tool_by_name",
    "get_tool_names",
    "get_tools_prompt",
    "needs_agent_state",
    "process_tool_invocations",
    "register_tool",
    "remove_screenshot_from_result",
    "tools",
    "validate_tool_availability",
]
