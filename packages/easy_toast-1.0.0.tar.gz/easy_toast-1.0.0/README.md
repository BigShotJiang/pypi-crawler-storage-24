# EasyToast

一个简单易用的 Windows Toast 通知库，基于 `toasted` 封装。

## 安装

```bash
pip install easy-toast
```