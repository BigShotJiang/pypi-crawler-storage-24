from toasted import Toast,Button,Text,Image,Progress
from toasted import ToastDuration,ToastScenario
from toasted.enums import ToastTextStyle, ToastTextAlign
from datetime import *
import os
__all__=['toast']
DEBUG=False #Debug Options
class toast:
    def __init__(self):
        self._event={}
        self._event_id=0
        self.elements=[]
        self.duration=ToastDuration.SHORT
        self.scenario=ToastScenario.REMINDER
        self.sound="ms-winsoundevent:Notification.Default"
        self.sound_loop=False
        self._app_id=""
        self._initialization=False
        self.group_id=""
        self.toast_id=""
        self.timestamp=datetime.now()
        self.show_popup=True
        self.base_path=os.getcwd()
        self.remote_media=False
        self.add_query_params=False
        self.expiration_time=None
    def init(self,Id,display,ico=None):
        if self._initialization:
            raise RuntimeError("Call init again.")
        if not ico:
            Toast.register_app_id(
                Id,
                display_name=display,
            )
        else:
            Toast.register_app_id(
                Id,
                display_name=display,
                icon_uri=ico
            )
        self._app_id=Id
        self._initialization=True
    def append(self,type,**kwargs):
        if not type in ['button','text','image','progress']:
            raise ValueError('Value of type must be "button","text","image" or "progress".')
        if type=='text':
            place=kwargs.get('place',None)
            is_arg=False
            if place:
                style=place
                if place=='title':
                    style=ToastTextStyle.TITLE
                elif place=='body':
                    style=ToastTextStyle.BODY
                elif place=='caption':
                    style=ToastTextStyle.CAPTION
                elif place=='small_text':
                    style=None
                    is_arg=True
            align=kwargs.get('align',None)
            if align=='right':
                align=ToastTextAlign.RIGHT
            elif align:
                raise ValueError('Invaild Align Value.')
            self.elements.append(Text(kwargs['text'],style=style,align=align,is_attribution=is_arg))
        elif type=='button':
            self._event_id+=1
            evid=str(self._event_id)
            self._event[evid]=kwargs['call']
            is_c=kwargs.get('is_context',False)
            icon=kwargs.get('icon',None)
            tooltip=kwargs.get('tip',None)
            self.elements.append(Button(kwargs['content'],arguments=evid,icon=icon,is_context=is_c,tooltip=tooltip))
        elif type=='image':
            self.elements.append(Image(kwargs['source']))
        elif type=='progress':
            value=kwargs['value']
            assert 0<=value<=1
            title=kwargs.get('title',None)
            value_show=kwargs.get('value_show',str(value*100)+"%")
            self.elements.append(Progress(value=value,title=title,value_string=value_show))
    def show(self):
        if not self._initialization:
            raise ValueError("Please call init() before call show().")
        toastw = Toast(
            app_id=self._app_id,
            duration=self.duration,
            scenario=self.scenario,
            sound=self.sound,
            sound_loop=self.sound_loop,
            group_id=self.group_id,
            toast_id=self.toast_id,
            timestamp=self.timestamp,
            show_popup=self.show_popup,
            base_path=self.base_path,
            remote_media=self.remote_media,
            add_query_params=self.add_query_params,
            expiration_time=self.expiration_time
        )
        toastw.elements = self.elements
        @toastw.on_result
        def callback(result):
            self._event.get(result.arguments)()
        import asyncio
        asyncio.run(toastw.show())
if __name__=='__main__':
    print('*'*100)
    print(r'''███████╗ █████╗ ███████╗██╗   ██╗████████╗ ██████╗  █████╗ ███████╗████████╗
██╔════╝██╔══██╗██╔════╝╚██╗ ██╔╝╚══██╔══╝██╔═══██╗██╔══██╗██╔════╝╚══██╔══╝
█████╗  ███████║███████╗ ╚████╔╝    ██║   ██║   ██║███████║███████╗   ██║   
██╔══╝  ██╔══██║╚════██║  ╚██╔╝     ██║   ██║   ██║██╔══██║╚════██║   ██║   
███████╗██║  ██║███████║   ██║      ██║   ╚██████╔╝██║  ██║███████║   ██║   
╚══════╝╚═╝  ╚═╝╚══════╝   ╚═╝      ╚═╝    ╚═════╝ ╚═╝  ╚═╝╚══════╝   ╚═╝   
                                                                            ''')
    print('*'*100)
    if DEBUG:
        test=toast()
