I'm about to change the file: $ARGUMENTS

Before I make changes, analyze the impact.

Steps:
1. Use `blast_radius` on the specified file to find all transitively affected files
2. Use `query_entity` on key functions/classes in the file to understand their relationships
3. Use `find_callers` on the most important functions to see what depends on them
4. Use `dependency_tree` on the file to see its import chain

Then give me:
- The blast radius: how many files are affected if this file breaks
- A list of the affected files, grouped by app/module
- The key functions in this file and who calls them
- What this file depends on (its imports)
- Practical advice: what to test after making changes, what could break, any coupling concerns
