Index this codebase with Suitable Loop and give me a complete orientation.

Steps:
1. Use `index_codebase` to index the current project directory (use force=true if already indexed)
2. Use `codebase_summary` to get high-level stats
3. Use `complexity_report` (top 10) to find the most complex code
4. Use `hotspot_report` on this repo to find high-risk areas
5. Check `blast_radius` on the top 3 hotspot files

Then give me a concise briefing covering:
- Project size and structure (files, functions, classes)
- The most connected/central modules
- The most complex functions (and why they matter)
- The highest-risk hotspots (high churn + high dependency count)
- Which files have the largest blast radius
- Recommendations for where to focus testing and review
