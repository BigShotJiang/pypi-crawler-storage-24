Trace the function: $ARGUMENTS

Map out everything about this function and its role in the codebase.

Steps:
1. Use `query_entity` to get the function's details (signature, complexity, location)
2. Use `find_callers` to see everything that calls it
3. Use `find_callees` to see everything it calls
4. Use `blast_radius` on the file containing this function
5. Use `search_code` if the function name is ambiguous to find all matches

Then give me:
- Function signature, location, and complexity score
- Who calls this function (direct callers) — grouped by module
- What this function calls (direct callees)
- The blast radius of its containing file
- A visual call chain showing how this function fits into the broader system
