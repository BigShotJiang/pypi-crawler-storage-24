Run a full codebase health check using Suitable Loop.

Steps:
1. Use `reindex` on the current project to ensure data is fresh
2. Use `codebase_summary` for overall stats
3. Use `complexity_report` (top 15) to find overly complex code
4. Use `hotspot_report` on this repo (last 100 commits) to find high-risk areas
5. Use `blast_radius` on the top 5 most-depended-upon files
6. Use `analyze_recent_changes` (last 20 commits) to check recent risk trends

Produce a health report with these sections:

**Codebase overview** — size, structure, key metrics

**Complexity hotspots** — functions above complexity 15, with recommendations to simplify

**Dependency risks** — files with the largest blast radius, coupling concerns

**Change hotspots** — files that change too often relative to how many things depend on them

**Recent risk trend** — are recent commits getting riskier or safer?

**Recommendations** — top 3 actionable items to improve codebase health
