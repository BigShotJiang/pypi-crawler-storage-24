Help me investigate this error: $ARGUMENTS

Steps:
1. Use `correlate_error` with the provided error text to find matching code paths
2. If a log file path was provided instead, use `ingest_logs` first, then `get_error_groups`
3. For each relevant error group, use `error_detail` to get full tracebacks and affected functions
4. Use `query_entity` on the key functions in the stack trace to understand their role
5. Use `find_callers` on the originating function to see all code paths that lead to it

Then give me:
- Where the error originates (file, function, line)
- The full call chain leading to the error
- How many times this error has occurred (if logs were ingested)
- All code paths that could trigger this error
- Suggested investigation steps or likely root cause
