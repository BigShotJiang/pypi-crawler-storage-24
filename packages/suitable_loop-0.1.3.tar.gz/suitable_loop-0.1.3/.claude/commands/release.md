Release a new version of suitable-loop to PyPI.

Steps:
1. Read pyproject.toml to get the current version
2. Determine the next version:
   - If $ARGUMENTS is "patch", "minor", or "major", bump accordingly
   - If $ARGUMENTS is a specific version like "0.2.0", use that
   - If $ARGUMENTS is empty, default to a patch bump
3. Update the version in pyproject.toml and suitable_loop/__init__.py
4. Commit the version bump
5. Create a git tag (v{version}) and push both the commit and tag
6. Wait for the GitHub Actions workflow to complete and report the result
7. Confirm the new version is live on PyPI
