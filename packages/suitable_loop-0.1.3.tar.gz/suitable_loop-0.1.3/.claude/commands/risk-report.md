Analyze recent git activity and produce a risk report.

Steps:
1. Use `analyze_recent_changes` on this repo (last 30 commits)
2. For the top 3 riskiest commits, use `analyze_commit` to get detailed breakdowns
3. Use `hotspot_report` on this repo to cross-reference with code hotspots

Then produce a report covering:
- Top 5 riskiest commits with their risk scores and key factors (complexity delta, blast radius, churn, lines changed)
- For each risky commit: what files were touched and why it's risky
- Current hotspots: files that change frequently AND are heavily depended upon
- Actionable recommendations: which changes deserve extra review, which areas need better test coverage
