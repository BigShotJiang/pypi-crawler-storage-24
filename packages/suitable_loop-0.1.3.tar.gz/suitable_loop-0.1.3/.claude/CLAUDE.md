# Suitable Loop

This is a local MCP server for production engineering. It indexes Python codebases and exposes analysis tools.

## Available slash commands

- `/onboard` — Index a codebase and get a full orientation (structure, hotspots, complexity, blast radius)
- `/risk-report` — Analyze recent commits by risk score, find hotspots, get review recommendations
- `/impact-check <file>` — Before changing a file, see its blast radius, callers, and what could break
- `/debug-error <error text or log path>` — Correlate an error/traceback to source code paths
- `/health-check` — Full codebase health assessment with actionable recommendations
- `/trace-function <name>` — Map a function's callers, callees, and role in the system

## MCP tools reference

### Indexing
- `index_codebase(path, force)` — Parse and index a Python project
- `reindex(path)` — Incremental re-index (only changed files)
- `status()` — Server status and entity counts

### Code analysis
- `query_entity(name)` — Look up any function/class/file with relationships
- `find_callers(function_name)` — Who calls this function?
- `find_callees(function_name)` — What does this function call?
- `dependency_tree(file_path, depth)` — Import tree for a file
- `search_code(query)` — Full-text search across indexed code
- `complexity_report(top_n)` — Most complex functions
- `codebase_summary()` — High-level stats

### Git analysis
- `analyze_recent_changes(repo_path, n_commits)` — Score commits by risk
- `analyze_commit(repo_path, sha)` — Deep-dive a single commit
- `hotspot_report(repo_path, n_commits)` — Files with high churn x high dependencies
- `blast_radius(file_path)` — Transitive impact of changing a file

### Log analysis
- `ingest_logs(path)` — Parse log files, extract and group errors
- `get_error_groups(limit)` — List error groups by frequency
- `error_detail(error_group_id)` — Full error detail with code links
- `correlate_error(error_text)` — Map raw error text to code paths
- `error_timeline(days)` — Error frequency over time
