"""NetworkX-based graph engine for CodeZero.

Builds an in-memory directed graph from the database and exposes
query methods for callers/callees, dependency trees, blast-radius
analysis, and centrality reports.
"""

from __future__ import annotations

import logging
from typing import Any

import networkx as nx  # type: ignore[import-untyped]

from suitable_loop.db import Database
from suitable_loop.models import (
    ClassEntity,
    FileEntity,
    FunctionEntity,
)

logger = logging.getLogger(__name__)


class GraphEngine:
    """Provides graph-based queries over the indexed codebase."""

    def __init__(self, db: Database) -> None:
        self.db = db
        self.graph: nx.DiGraph = nx.DiGraph()
        self._built = False

    # ------------------------------------------------------------------
    # Graph construction
    # ------------------------------------------------------------------

    def build_graph(self, project_root: str) -> None:
        """Load all entities from the database and build the NetworkX graph.

        Node types: ``"file"``, ``"function"``, ``"class"``.
        Edge types: ``"contains"`` (file->function/class), ``"calls"``
        (function->function), ``"imports"`` (file->file).
        """
        self.graph.clear()

        files = self.db.get_all_files(project_root)
        logger.info("Building graph for %d files", len(files))

        for f in files:
            file_node = f"file:{f.path}"
            self.graph.add_node(
                file_node,
                type="file",
                path=f.path,
                entity_id=f.id,
                line_count=f.line_count,
                size_bytes=f.size_bytes,
            )

            # Functions
            functions = self.db.get_functions_by_file(f.id)  # type: ignore[arg-type]
            for func in functions:
                func_node = f"func:{func.qualified_name}"
                self.graph.add_node(
                    func_node,
                    type="function",
                    name=func.name,
                    qualified_name=func.qualified_name,
                    entity_id=func.id,
                    complexity=func.complexity,
                    is_method=func.is_method,
                    is_async=func.is_async,
                    line_start=func.line_start,
                    line_end=func.line_end,
                    signature=func.signature,
                    docstring=func.docstring,
                    class_name=func.class_name,
                )
                self.graph.add_edge(file_node, func_node, type="contains")

            # Classes
            classes = self.db.get_classes_by_file(f.id)  # type: ignore[arg-type]
            for cls in classes:
                cls_node = f"class:{cls.qualified_name}"
                self.graph.add_node(
                    cls_node,
                    type="class",
                    name=cls.name,
                    qualified_name=cls.qualified_name,
                    entity_id=cls.id,
                    bases=cls.bases,
                    line_start=cls.line_start,
                    line_end=cls.line_end,
                    docstring=cls.docstring,
                )
                self.graph.add_edge(file_node, cls_node, type="contains")

            # Call edges
            for func in functions:
                caller_node = f"func:{func.qualified_name}"
                callees = self.db.get_callees(func.id)  # type: ignore[arg-type]
                for callee in callees:
                    callee_node = f"func:{callee.qualified_name}"
                    self.graph.add_edge(caller_node, callee_node, type="calls")

            # File-level import dependencies
            deps = self.db.get_file_dependencies(f.id)  # type: ignore[arg-type]
            for dep in deps:
                target_node = f"file:{dep.path}"
                self.graph.add_edge(file_node, target_node, type="imports")

        self._built = True
        logger.info(
            "Graph built: %d nodes, %d edges",
            self.graph.number_of_nodes(),
            self.graph.number_of_edges(),
        )

    # ------------------------------------------------------------------
    # Query methods
    # ------------------------------------------------------------------

    def get_callers(self, function_name: str) -> list[dict]:
        """Find all direct callers of *function_name*.

        *function_name* may be a bare name (``my_func``) or a qualified
        name (``pkg.mod.my_func``).
        """
        node = self._find_function_node(function_name)
        if node is None:
            return []

        callers: list[dict] = []
        for pred in self.graph.predecessors(node):
            edge_data = self.graph.edges[pred, node]
            if edge_data.get("type") != "calls":
                continue
            callers.append(self._node_to_dict(pred))
        return callers

    def get_callees(self, function_name: str) -> list[dict]:
        """Find all functions directly called by *function_name*."""
        node = self._find_function_node(function_name)
        if node is None:
            return []

        callees: list[dict] = []
        for succ in self.graph.successors(node):
            edge_data = self.graph.edges[node, succ]
            if edge_data.get("type") != "calls":
                continue
            callees.append(self._node_to_dict(succ))
        return callees

    def dependency_tree(self, file_path: str, depth: int = 3) -> dict:
        """Return a recursive import-dependency tree rooted at *file_path*.

        Each level is a dict with ``"file"`` and ``"dependencies"`` keys.
        The tree is bounded by *depth* to avoid runaway recursion.
        """
        node = self._find_file_node(file_path)
        if node is None:
            return {"file": file_path, "dependencies": [], "error": "file not found"}

        return self._build_dep_tree(node, depth, visited=set())

    def blast_radius(self, file_path: str) -> dict:
        """Compute the transitive blast radius of changing *file_path*.

        Returns counts and lists of all files and functions that
        (transitively) depend on this file.
        """
        node = self._find_file_node(file_path)
        if node is None:
            return {
                "file": file_path,
                "error": "file not found",
                "affected_files": [],
                "affected_functions": [],
                "total_affected_files": 0,
                "total_affected_functions": 0,
            }

        # Reverse graph: we want nodes that *import* this file, transitively.
        reverse = self.graph.reverse(copy=False)
        try:
            dependents = nx.descendants(reverse, node)
        except nx.NetworkXError:
            dependents = set()

        affected_files: list[dict] = []
        affected_functions: list[dict] = []

        for dep_node in dependents:
            data = self.graph.nodes[dep_node]
            if data.get("type") == "file":
                affected_files.append(self._node_to_dict(dep_node))
            elif data.get("type") == "function":
                affected_functions.append(self._node_to_dict(dep_node))

        # Also include functions contained in the file itself.
        for succ in self.graph.successors(node):
            edge_data = self.graph.edges[node, succ]
            if edge_data.get("type") == "contains":
                data = self.graph.nodes[succ]
                if data.get("type") == "function":
                    affected_functions.append(self._node_to_dict(succ))

        return {
            "file": file_path,
            "affected_files": affected_files,
            "affected_functions": affected_functions,
            "total_affected_files": len(affected_files),
            "total_affected_functions": len(affected_functions),
        }

    def get_entity_info(self, name: str) -> dict | None:
        """Look up any entity (file, function, class) by name.

        Tries qualified name first, then falls back to a substring search
        across node IDs.
        """
        # Direct lookup by known prefixes.
        for prefix in ("func:", "class:", "file:"):
            candidate = f"{prefix}{name}"
            if candidate in self.graph:
                return self._node_to_dict(candidate)

        # Substring search.
        for node_id, data in self.graph.nodes(data=True):
            qname = data.get("qualified_name") or data.get("path") or ""
            node_name = data.get("name", "")
            if name == qname or name == node_name:
                return self._node_to_dict(node_id)

        return None

    def get_most_connected(self, top_n: int = 10) -> list[dict]:
        """Return the *top_n* nodes with the highest total degree."""
        if not self.graph:
            return []

        degree_list = sorted(
            self.graph.degree(), key=lambda pair: pair[1], reverse=True
        )
        results: list[dict] = []
        for node_id, degree in degree_list[:top_n]:
            info = self._node_to_dict(node_id)
            info["degree"] = degree
            results.append(info)
        return results

    def get_complexity_report(self, top_n: int = 20) -> list[dict]:
        """Return the *top_n* most complex functions in the graph."""
        func_nodes: list[tuple[str, dict[str, Any]]] = []
        for node_id, data in self.graph.nodes(data=True):
            if data.get("type") == "function" and data.get("complexity", 0) > 0:
                func_nodes.append((node_id, data))

        func_nodes.sort(key=lambda pair: pair[1].get("complexity", 0), reverse=True)

        results: list[dict] = []
        for node_id, data in func_nodes[:top_n]:
            info = self._node_to_dict(node_id)
            info["callers"] = len([
                p for p in self.graph.predecessors(node_id)
                if self.graph.edges[p, node_id].get("type") == "calls"
            ])
            info["callees"] = len([
                s for s in self.graph.successors(node_id)
                if self.graph.edges[node_id, s].get("type") == "calls"
            ])
            results.append(info)
        return results

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _find_function_node(self, function_name: str) -> str | None:
        """Find a function node by qualified or bare name."""
        candidate = f"func:{function_name}"
        if candidate in self.graph:
            return candidate

        # Fall back to searching by bare name or suffix.
        for node_id, data in self.graph.nodes(data=True):
            if data.get("type") != "function":
                continue
            if data.get("name") == function_name:
                return node_id
            qname = data.get("qualified_name", "")
            if qname.endswith(f".{function_name}"):
                return node_id
        return None

    def _find_file_node(self, file_path: str) -> str | None:
        """Find a file node by path (exact or suffix match)."""
        candidate = f"file:{file_path}"
        if candidate in self.graph:
            return candidate

        # Try suffix matching for relative paths.
        for node_id, data in self.graph.nodes(data=True):
            if data.get("type") != "file":
                continue
            path = data.get("path", "")
            if path.endswith(file_path) or file_path.endswith(path):
                return node_id
        return None

    def _node_to_dict(self, node_id: str) -> dict:
        """Convert a graph node to a plain dict for API consumption."""
        data = dict(self.graph.nodes[node_id])
        data["node_id"] = node_id
        return data

    def _build_dep_tree(
        self, node: str, depth: int, visited: set[str]
    ) -> dict:
        """Recursively build a dependency tree dict."""
        data = self.graph.nodes[node]
        result: dict[str, Any] = {
            "file": data.get("path", node),
            "node_id": node,
            "dependencies": [],
        }

        if depth <= 0 or node in visited:
            return result

        visited.add(node)

        for succ in self.graph.successors(node):
            edge_data = self.graph.edges[node, succ]
            if edge_data.get("type") != "imports":
                continue
            child = self._build_dep_tree(succ, depth - 1, visited)
            result["dependencies"].append(child)

        return result
