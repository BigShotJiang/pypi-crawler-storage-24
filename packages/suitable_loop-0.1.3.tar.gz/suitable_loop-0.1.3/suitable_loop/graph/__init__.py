"""Suitable Loop graph engine."""
