"""SQLite database layer for CodeZero."""

from __future__ import annotations

import json
import sqlite3
from pathlib import Path

from .config import SuitableLoopConfig
from .models import (
    CallEdge,
    ClassEntity,
    CommitFile,
    CommitInfo,
    ErrorCodeLink,
    ErrorGroup,
    FileDependency,
    FileEntity,
    FunctionEntity,
    ImportEntity,
    LogEntry,
)

SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS files (
    id INTEGER PRIMARY KEY,
    path TEXT UNIQUE NOT NULL,
    project_root TEXT NOT NULL,
    size_bytes INTEGER,
    last_modified REAL,
    last_indexed REAL,
    line_count INTEGER,
    hash TEXT
);

CREATE TABLE IF NOT EXISTS functions (
    id INTEGER PRIMARY KEY,
    file_id INTEGER REFERENCES files(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    qualified_name TEXT NOT NULL,
    class_name TEXT,
    line_start INTEGER,
    line_end INTEGER,
    signature TEXT,
    docstring TEXT,
    complexity INTEGER,
    is_method BOOLEAN DEFAULT FALSE,
    is_async BOOLEAN DEFAULT FALSE
);

CREATE TABLE IF NOT EXISTS classes (
    id INTEGER PRIMARY KEY,
    file_id INTEGER REFERENCES files(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    qualified_name TEXT NOT NULL,
    line_start INTEGER,
    line_end INTEGER,
    bases TEXT,
    docstring TEXT
);

CREATE TABLE IF NOT EXISTS imports (
    id INTEGER PRIMARY KEY,
    file_id INTEGER REFERENCES files(id) ON DELETE CASCADE,
    module TEXT NOT NULL,
    alias TEXT,
    is_internal BOOLEAN,
    resolved_file_id INTEGER REFERENCES files(id)
);

CREATE TABLE IF NOT EXISTS call_edges (
    id INTEGER PRIMARY KEY,
    caller_id INTEGER REFERENCES functions(id) ON DELETE CASCADE,
    callee_id INTEGER REFERENCES functions(id) ON DELETE CASCADE,
    file_id INTEGER REFERENCES files(id),
    line_number INTEGER,
    UNIQUE(caller_id, callee_id, line_number)
);

CREATE TABLE IF NOT EXISTS file_dependencies (
    id INTEGER PRIMARY KEY,
    source_file_id INTEGER REFERENCES files(id) ON DELETE CASCADE,
    target_file_id INTEGER REFERENCES files(id) ON DELETE CASCADE,
    UNIQUE(source_file_id, target_file_id)
);

CREATE TABLE IF NOT EXISTS commits (
    id INTEGER PRIMARY KEY,
    repo_path TEXT NOT NULL,
    sha TEXT NOT NULL,
    author TEXT,
    timestamp REAL,
    message TEXT,
    files_changed INTEGER,
    insertions INTEGER,
    deletions INTEGER,
    risk_score REAL,
    UNIQUE(repo_path, sha)
);

CREATE TABLE IF NOT EXISTS commit_files (
    id INTEGER PRIMARY KEY,
    commit_id INTEGER REFERENCES commits(id) ON DELETE CASCADE,
    file_path TEXT NOT NULL,
    change_type TEXT,
    insertions INTEGER,
    deletions INTEGER,
    complexity_before INTEGER,
    complexity_after INTEGER
);

CREATE TABLE IF NOT EXISTS log_entries (
    id INTEGER PRIMARY KEY,
    source_file TEXT NOT NULL,
    timestamp REAL,
    level TEXT,
    logger_name TEXT,
    message TEXT,
    raw_line TEXT,
    error_group_id INTEGER REFERENCES error_groups(id)
);

CREATE TABLE IF NOT EXISTS error_groups (
    id INTEGER PRIMARY KEY,
    signature TEXT UNIQUE NOT NULL,
    exception_type TEXT,
    exception_message TEXT,
    traceback TEXT,
    first_seen REAL,
    last_seen REAL,
    occurrence_count INTEGER DEFAULT 1
);

CREATE TABLE IF NOT EXISTS error_code_links (
    id INTEGER PRIMARY KEY,
    error_group_id INTEGER REFERENCES error_groups(id) ON DELETE CASCADE,
    function_id INTEGER REFERENCES functions(id),
    file_id INTEGER REFERENCES files(id),
    line_number INTEGER,
    frame_position INTEGER
);

CREATE INDEX IF NOT EXISTS idx_functions_file ON functions(file_id);
CREATE INDEX IF NOT EXISTS idx_functions_qname ON functions(qualified_name);
CREATE INDEX IF NOT EXISTS idx_classes_file ON classes(file_id);
CREATE INDEX IF NOT EXISTS idx_imports_file ON imports(file_id);
CREATE INDEX IF NOT EXISTS idx_call_edges_caller ON call_edges(caller_id);
CREATE INDEX IF NOT EXISTS idx_call_edges_callee ON call_edges(callee_id);
CREATE INDEX IF NOT EXISTS idx_commits_repo ON commits(repo_path);
CREATE INDEX IF NOT EXISTS idx_log_entries_group ON log_entries(error_group_id);
CREATE INDEX IF NOT EXISTS idx_error_code_links_group ON error_code_links(error_group_id);
"""


class Database:
    def __init__(self, config: SuitableLoopConfig):
        self.db_path = config.db_path
        self._conn: sqlite3.Connection | None = None

    def connect(self) -> sqlite3.Connection:
        if self._conn is not None:
            return self._conn
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(str(self.db_path))
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA foreign_keys=ON")
        self._conn.row_factory = sqlite3.Row
        self._init_schema()
        return self._conn

    def _init_schema(self):
        self._conn.executescript(SCHEMA_SQL)
        self._conn.commit()

    def close(self):
        if self._conn:
            self._conn.close()
            self._conn = None

    @property
    def conn(self) -> sqlite3.Connection:
        return self.connect()

    # --- File operations ---

    def upsert_file(self, f: FileEntity) -> int:
        cur = self.conn.execute(
            """INSERT INTO files (path, project_root, size_bytes, last_modified, last_indexed, line_count, hash)
               VALUES (?, ?, ?, ?, ?, ?, ?)
               ON CONFLICT(path) DO UPDATE SET
                   size_bytes=excluded.size_bytes, last_modified=excluded.last_modified,
                   last_indexed=excluded.last_indexed, line_count=excluded.line_count, hash=excluded.hash
               RETURNING id""",
            (f.path, f.project_root, f.size_bytes, f.last_modified, f.last_indexed, f.line_count, f.hash),
        )
        row = cur.fetchone()
        self.conn.commit()
        return row[0]

    def get_file_by_path(self, path: str) -> FileEntity | None:
        row = self.conn.execute("SELECT * FROM files WHERE path = ?", (path,)).fetchone()
        if not row:
            return None
        return FileEntity(**dict(row))

    def get_file_by_id(self, file_id: int) -> FileEntity | None:
        row = self.conn.execute("SELECT * FROM files WHERE id = ?", (file_id,)).fetchone()
        if not row:
            return None
        return FileEntity(**dict(row))

    def find_file_by_suffix(self, suffix: str) -> FileEntity | None:
        """Find a file whose path ends with *suffix* (e.g. ``db.py``)."""
        row = self.conn.execute(
            "SELECT * FROM files WHERE path LIKE ? LIMIT 1", (f"%{suffix}",)
        ).fetchone()
        if not row:
            return None
        return FileEntity(**dict(row))

    def get_all_files(self, project_root: str) -> list[FileEntity]:
        rows = self.conn.execute("SELECT * FROM files WHERE project_root = ?", (project_root,)).fetchall()
        return [FileEntity(**dict(r)) for r in rows]

    def delete_file(self, file_id: int):
        self.conn.execute("DELETE FROM files WHERE id = ?", (file_id,))
        self.conn.commit()

    # --- Function operations ---

    def insert_function(self, f: FunctionEntity) -> int:
        cur = self.conn.execute(
            """INSERT INTO functions (file_id, name, qualified_name, class_name, line_start, line_end,
                                     signature, docstring, complexity, is_method, is_async)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) RETURNING id""",
            (f.file_id, f.name, f.qualified_name, f.class_name, f.line_start, f.line_end,
             f.signature, f.docstring, f.complexity, f.is_method, f.is_async),
        )
        row = cur.fetchone()
        return row[0]

    def get_functions_by_file(self, file_id: int) -> list[FunctionEntity]:
        rows = self.conn.execute("SELECT * FROM functions WHERE file_id = ?", (file_id,)).fetchall()
        return [FunctionEntity(**dict(r)) for r in rows]

    def get_function_by_qualified_name(self, qname: str) -> FunctionEntity | None:
        row = self.conn.execute("SELECT * FROM functions WHERE qualified_name = ?", (qname,)).fetchone()
        if not row:
            return None
        return FunctionEntity(**dict(row))

    def get_function_by_id(self, func_id: int) -> FunctionEntity | None:
        row = self.conn.execute("SELECT * FROM functions WHERE id = ?", (func_id,)).fetchone()
        if not row:
            return None
        return FunctionEntity(**dict(row))

    def search_functions(self, query: str, limit: int = 20) -> list[FunctionEntity]:
        rows = self.conn.execute(
            "SELECT * FROM functions WHERE qualified_name LIKE ? OR name LIKE ? LIMIT ?",
            (f"%{query}%", f"%{query}%", limit),
        ).fetchall()
        return [FunctionEntity(**dict(r)) for r in rows]

    def delete_functions_by_file(self, file_id: int):
        self.conn.execute("DELETE FROM functions WHERE file_id = ?", (file_id,))

    # --- Class operations ---

    def insert_class(self, c: ClassEntity) -> int:
        cur = self.conn.execute(
            """INSERT INTO classes (file_id, name, qualified_name, line_start, line_end, bases, docstring)
               VALUES (?, ?, ?, ?, ?, ?, ?) RETURNING id""",
            (c.file_id, c.name, c.qualified_name, c.line_start, c.line_end, json.dumps(c.bases), c.docstring),
        )
        row = cur.fetchone()
        return row[0]

    def get_classes_by_file(self, file_id: int) -> list[ClassEntity]:
        rows = self.conn.execute("SELECT * FROM classes WHERE file_id = ?", (file_id,)).fetchall()
        result = []
        for r in rows:
            d = dict(r)
            d["bases"] = json.loads(d["bases"]) if d["bases"] else []
            result.append(ClassEntity(**d))
        return result

    def delete_classes_by_file(self, file_id: int):
        self.conn.execute("DELETE FROM classes WHERE file_id = ?", (file_id,))

    # --- Import operations ---

    def insert_import(self, imp: ImportEntity) -> int:
        cur = self.conn.execute(
            """INSERT INTO imports (file_id, module, alias, is_internal, resolved_file_id)
               VALUES (?, ?, ?, ?, ?) RETURNING id""",
            (imp.file_id, imp.module, imp.alias, imp.is_internal, imp.resolved_file_id),
        )
        row = cur.fetchone()
        return row[0]

    def get_imports_by_file(self, file_id: int) -> list[ImportEntity]:
        rows = self.conn.execute("SELECT * FROM imports WHERE file_id = ?", (file_id,)).fetchall()
        return [ImportEntity(**dict(r)) for r in rows]

    def delete_imports_by_file(self, file_id: int):
        self.conn.execute("DELETE FROM imports WHERE file_id = ?", (file_id,))

    # --- Call edge operations ---

    def insert_call_edge(self, edge: CallEdge) -> int | None:
        try:
            cur = self.conn.execute(
                """INSERT INTO call_edges (caller_id, callee_id, file_id, line_number)
                   VALUES (?, ?, ?, ?) RETURNING id""",
                (edge.caller_id, edge.callee_id, edge.file_id, edge.line_number),
            )
            row = cur.fetchone()
            return row[0]
        except sqlite3.IntegrityError:
            return None

    def get_callers(self, function_id: int) -> list[FunctionEntity]:
        rows = self.conn.execute(
            """SELECT f.* FROM functions f
               JOIN call_edges ce ON f.id = ce.caller_id
               WHERE ce.callee_id = ?""",
            (function_id,),
        ).fetchall()
        return [FunctionEntity(**dict(r)) for r in rows]

    def get_callees(self, function_id: int) -> list[FunctionEntity]:
        rows = self.conn.execute(
            """SELECT f.* FROM functions f
               JOIN call_edges ce ON f.id = ce.callee_id
               WHERE ce.caller_id = ?""",
            (function_id,),
        ).fetchall()
        return [FunctionEntity(**dict(r)) for r in rows]

    def delete_call_edges_by_file(self, file_id: int):
        self.conn.execute("DELETE FROM call_edges WHERE file_id = ?", (file_id,))

    # --- File dependency operations ---

    def insert_file_dependency(self, dep: FileDependency) -> int | None:
        try:
            cur = self.conn.execute(
                """INSERT INTO file_dependencies (source_file_id, target_file_id)
                   VALUES (?, ?) RETURNING id""",
                (dep.source_file_id, dep.target_file_id),
            )
            row = cur.fetchone()
            return row[0]
        except sqlite3.IntegrityError:
            return None

    def get_file_dependents(self, file_id: int) -> list[FileEntity]:
        rows = self.conn.execute(
            """SELECT f.* FROM files f
               JOIN file_dependencies fd ON f.id = fd.source_file_id
               WHERE fd.target_file_id = ?""",
            (file_id,),
        ).fetchall()
        return [FileEntity(**dict(r)) for r in rows]

    def get_file_dependencies(self, file_id: int) -> list[FileEntity]:
        rows = self.conn.execute(
            """SELECT f.* FROM files f
               JOIN file_dependencies fd ON f.id = fd.target_file_id
               WHERE fd.source_file_id = ?""",
            (file_id,),
        ).fetchall()
        return [FileEntity(**dict(r)) for r in rows]

    def delete_file_dependencies_by_source(self, file_id: int):
        self.conn.execute("DELETE FROM file_dependencies WHERE source_file_id = ?", (file_id,))

    # --- Commit operations ---

    def upsert_commit(self, c: CommitInfo) -> int:
        cur = self.conn.execute(
            """INSERT INTO commits (repo_path, sha, author, timestamp, message, files_changed,
                                   insertions, deletions, risk_score)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
               ON CONFLICT(repo_path, sha) DO UPDATE SET risk_score=excluded.risk_score
               RETURNING id""",
            (c.repo_path, c.sha, c.author, c.timestamp, c.message, c.files_changed,
             c.insertions, c.deletions, c.risk_score),
        )
        row = cur.fetchone()
        self.conn.commit()
        return row[0]

    def insert_commit_file(self, cf: CommitFile) -> int:
        cur = self.conn.execute(
            """INSERT INTO commit_files (commit_id, file_path, change_type, insertions, deletions,
                                        complexity_before, complexity_after)
               VALUES (?, ?, ?, ?, ?, ?, ?) RETURNING id""",
            (cf.commit_id, cf.file_path, cf.change_type, cf.insertions, cf.deletions,
             cf.complexity_before, cf.complexity_after),
        )
        row = cur.fetchone()
        return row[0]

    def get_commits(self, repo_path: str, limit: int = 50) -> list[CommitInfo]:
        rows = self.conn.execute(
            "SELECT * FROM commits WHERE repo_path = ? ORDER BY timestamp DESC LIMIT ?",
            (repo_path, limit),
        ).fetchall()
        return [CommitInfo(**dict(r)) for r in rows]

    # --- Error group operations ---

    def upsert_error_group(self, eg: ErrorGroup) -> int:
        cur = self.conn.execute(
            """INSERT INTO error_groups (signature, exception_type, exception_message, traceback,
                                        first_seen, last_seen, occurrence_count)
               VALUES (?, ?, ?, ?, ?, ?, ?)
               ON CONFLICT(signature) DO UPDATE SET
                   last_seen=excluded.last_seen,
                   occurrence_count=error_groups.occurrence_count + excluded.occurrence_count
               RETURNING id""",
            (eg.signature, eg.exception_type, eg.exception_message, eg.traceback,
             eg.first_seen, eg.last_seen, eg.occurrence_count),
        )
        row = cur.fetchone()
        self.conn.commit()
        return row[0]

    def get_error_groups(self, limit: int = 20) -> list[ErrorGroup]:
        rows = self.conn.execute(
            "SELECT * FROM error_groups ORDER BY occurrence_count DESC LIMIT ?", (limit,)
        ).fetchall()
        return [ErrorGroup(**dict(r)) for r in rows]

    def get_error_group_by_id(self, group_id: int) -> ErrorGroup | None:
        row = self.conn.execute("SELECT * FROM error_groups WHERE id = ?", (group_id,)).fetchone()
        if not row:
            return None
        return ErrorGroup(**dict(row))

    # --- Log entry operations ---

    def insert_log_entry(self, le: LogEntry) -> int:
        cur = self.conn.execute(
            """INSERT INTO log_entries (source_file, timestamp, level, logger_name, message, raw_line, error_group_id)
               VALUES (?, ?, ?, ?, ?, ?, ?) RETURNING id""",
            (le.source_file, le.timestamp, le.level, le.logger_name, le.message, le.raw_line, le.error_group_id),
        )
        row = cur.fetchone()
        return row[0]

    # --- Error code link operations ---

    def insert_error_code_link(self, link: ErrorCodeLink) -> int:
        cur = self.conn.execute(
            """INSERT INTO error_code_links (error_group_id, function_id, file_id, line_number, frame_position)
               VALUES (?, ?, ?, ?, ?) RETURNING id""",
            (link.error_group_id, link.function_id, link.file_id, link.line_number, link.frame_position),
        )
        row = cur.fetchone()
        return row[0]

    def get_error_code_links(self, error_group_id: int) -> list[dict]:
        rows = self.conn.execute(
            """SELECT ecl.*, f.qualified_name as function_name, fi.path as file_path
               FROM error_code_links ecl
               LEFT JOIN functions f ON ecl.function_id = f.id
               LEFT JOIN files fi ON ecl.file_id = fi.id
               WHERE ecl.error_group_id = ?
               ORDER BY ecl.frame_position""",
            (error_group_id,),
        ).fetchall()
        return [dict(r) for r in rows]

    # --- Utility ---

    def get_stats(self) -> dict:
        stats = {}
        for table in ["files", "functions", "classes", "imports", "call_edges",
                       "file_dependencies", "commits", "log_entries", "error_groups"]:
            row = self.conn.execute(f"SELECT COUNT(*) FROM {table}").fetchone()  # noqa: S608
            stats[table] = row[0]
        stats["db_size_bytes"] = self.db_path.stat().st_size if self.db_path.exists() else 0
        return stats

    def clear_file_data(self, file_id: int):
        """Remove all data associated with a file for re-indexing."""
        self.delete_call_edges_by_file(file_id)
        self.delete_functions_by_file(file_id)
        self.delete_classes_by_file(file_id)
        self.delete_imports_by_file(file_id)
        self.delete_file_dependencies_by_source(file_id)

    def commit(self):
        self.conn.commit()
