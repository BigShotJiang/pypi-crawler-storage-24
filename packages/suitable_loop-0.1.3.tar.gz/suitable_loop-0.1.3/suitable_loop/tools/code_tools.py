"""MCP tool handlers for code analysis."""

from __future__ import annotations

import logging

from mcp.server.fastmcp import FastMCP

from ..analyzers.code_analyzer import CodeAnalyzer
from ..config import SuitableLoopConfig
from ..db import Database
from ..graph.engine import GraphEngine

logger = logging.getLogger(__name__)


def register_code_tools(mcp: FastMCP, db: Database, config: SuitableLoopConfig):
    analyzer = CodeAnalyzer(db, config)
    graph = GraphEngine(db)

    @mcp.tool()
    def index_codebase(path: str, force: bool = False) -> dict:
        """Index a Python codebase. Parses all .py files, extracts functions, classes,
        imports, and call relationships. Builds a semantic graph for querying.
        Use force=True to re-index even unchanged files."""
        result = analyzer.index_codebase(path, force=force)
        graph.build_graph(path)
        return result

    @mcp.tool()
    def query_entity(name: str) -> dict:
        """Look up a function, class, or file by name. Returns details and all
        relationships (callers, callees, file location, complexity)."""
        info = graph.get_entity_info(name)
        if not info:
            return {"error": f"Entity '{name}' not found. Try search_code for broader search."}
        return info

    @mcp.tool()
    def find_callers(function_name: str) -> dict:
        """Find all functions that call the given function."""
        callers = graph.get_callers(function_name)
        return {
            "function": function_name,
            "caller_count": len(callers),
            "callers": callers,
        }

    @mcp.tool()
    def find_callees(function_name: str) -> dict:
        """Find all functions called by the given function."""
        callees = graph.get_callees(function_name)
        return {
            "function": function_name,
            "callee_count": len(callees),
            "callees": callees,
        }

    @mcp.tool()
    def dependency_tree(file_path: str, depth: int = 3) -> dict:
        """Get the import dependency tree for a file, up to N levels deep."""
        return graph.dependency_tree(file_path, depth=depth)

    @mcp.tool()
    def search_code(query: str, max_results: int = 20) -> dict:
        """Full-text search across indexed functions and classes."""
        functions = db.search_functions(query, limit=max_results)
        results = []
        for f in functions:
            file_entity = db.get_file_by_id(f.file_id) if f.file_id else None
            results.append({
                "name": f.qualified_name,
                "type": "method" if f.is_method else "function",
                "file": file_entity.path if file_entity else None,
                "line_start": f.line_start,
                "line_end": f.line_end,
                "complexity": f.complexity,
                "signature": f.signature,
                "docstring": f.docstring,
            })
        return {"query": query, "result_count": len(results), "results": results}

    @mcp.tool()
    def complexity_report(top_n: int = 20) -> dict:
        """Get the most complex functions in the indexed codebase, ranked by
        cyclomatic complexity."""
        report = graph.get_complexity_report(top_n=top_n)
        return {"top_n": top_n, "functions": report}

    @mcp.tool()
    def codebase_summary() -> dict:
        """High-level summary of the indexed codebase: file count, function count,
        class count, average complexity, most-connected modules."""
        stats = db.get_stats()
        most_connected = graph.get_most_connected(top_n=10)
        return {
            "files": stats.get("files", 0),
            "functions": stats.get("functions", 0),
            "classes": stats.get("classes", 0),
            "imports": stats.get("imports", 0),
            "call_edges": stats.get("call_edges", 0),
            "file_dependencies": stats.get("file_dependencies", 0),
            "most_connected_modules": most_connected,
        }
