"""Suitable Loop MCP tool handlers."""
