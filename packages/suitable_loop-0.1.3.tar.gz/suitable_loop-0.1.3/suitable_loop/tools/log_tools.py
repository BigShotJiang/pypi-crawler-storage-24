"""MCP tool handlers for log analysis."""

from __future__ import annotations

import logging

from mcp.server.fastmcp import FastMCP

from ..analyzers.log_analyzer import LogAnalyzer
from ..config import SuitableLoopConfig
from ..db import Database

logger = logging.getLogger(__name__)


def register_log_tools(mcp: FastMCP, db: Database, config: SuitableLoopConfig):
    analyzer = LogAnalyzer(db, config)

    @mcp.tool()
    def ingest_logs(path: str) -> dict:
        """Parse and store a log file or directory of log files. Auto-detects format
        (Python stdlib logging or JSON-per-line). Extracts errors, groups them by
        signature, and maps stack frames to indexed code."""
        return analyzer.ingest_logs(path)

    @mcp.tool()
    def get_error_groups(limit: int = 20) -> dict:
        """List all distinct error groups sorted by frequency. Each group includes
        exception type, occurrence count, and links to affected code."""
        groups = analyzer.get_error_groups(limit=limit)
        return {"error_group_count": len(groups), "error_groups": groups}

    @mcp.tool()
    def error_detail(error_group_id: int) -> dict:
        """Get full detail on an error group: traceback, affected functions,
        sample log entries, and timeline."""
        detail = analyzer.error_detail(error_group_id)
        if not detail:
            return {"error": f"Error group {error_group_id} not found."}
        return detail

    @mcp.tool()
    def correlate_error(error_text: str) -> dict:
        """Given a raw error or traceback text, find the relevant code paths in the
        indexed codebase. Useful for investigating production errors."""
        return analyzer.correlate_error(error_text)

    @mcp.tool()
    def error_timeline(days: int = 7) -> dict:
        """Show error frequency over time, grouped by error type. Useful for spotting
        trends and regressions."""
        timeline = analyzer.error_timeline(days=days)
        return {"days": days, "timeline": timeline}
