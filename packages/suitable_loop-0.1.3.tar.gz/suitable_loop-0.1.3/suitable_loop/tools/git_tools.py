"""MCP tool handlers for git analysis."""

from __future__ import annotations

import logging

from mcp.server.fastmcp import FastMCP

from ..analyzers.git_analyzer import GitAnalyzer
from ..config import SuitableLoopConfig
from ..db import Database

logger = logging.getLogger(__name__)


def register_git_tools(mcp: FastMCP, db: Database, config: SuitableLoopConfig):
    analyzer = GitAnalyzer(db, config)

    @mcp.tool()
    def analyze_recent_changes(repo_path: str, n_commits: int = 50) -> dict:
        """Analyze recent git commits and score them by risk. Risk factors include
        complexity delta, blast radius, churn rate, lines changed, and file count.
        Returns commits sorted by risk score (highest first)."""
        commits = analyzer.analyze_recent_changes(repo_path, n_commits=n_commits)
        return {
            "repo_path": repo_path,
            "commits_analyzed": len(commits),
            "commits": commits,
        }

    @mcp.tool()
    def analyze_commit(repo_path: str, sha: str) -> dict:
        """Deep-dive a single git commit. Shows changed files, complexity delta per file,
        blast radius, and detailed risk breakdown."""
        return analyzer.analyze_commit(repo_path, sha)

    @mcp.tool()
    def hotspot_report(repo_path: str, n_commits: int = 100) -> dict:
        """Find code hotspots — files that change frequently AND are highly depended upon.
        These are the highest-risk areas of the codebase."""
        hotspots = analyzer.hotspot_report(repo_path, n_commits=n_commits)
        return {
            "repo_path": repo_path,
            "commits_analyzed": n_commits,
            "hotspots": hotspots,
        }

    @mcp.tool()
    def blast_radius(file_path: str) -> dict:
        """Calculate the blast radius of a file — how many other files and functions
        are transitively affected if this file breaks."""
        return analyzer.blast_radius(file_path)
