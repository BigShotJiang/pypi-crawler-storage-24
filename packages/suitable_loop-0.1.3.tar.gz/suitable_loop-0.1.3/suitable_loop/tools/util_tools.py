"""MCP tool handlers for utility operations."""

from __future__ import annotations

import logging
import time

from mcp.server.fastmcp import FastMCP

from ..analyzers.code_analyzer import CodeAnalyzer
from ..config import SuitableLoopConfig
from ..db import Database
from ..graph.engine import GraphEngine

logger = logging.getLogger(__name__)


def register_util_tools(mcp: FastMCP, db: Database, config: SuitableLoopConfig):
    analyzer = CodeAnalyzer(db, config)
    graph = GraphEngine(db)

    @mcp.tool()
    def status() -> dict:
        """Get Suitable Loop server status: indexed projects, database size, entity counts,
        and last index time."""
        stats = db.get_stats()
        return {
            "status": "running",
            "db_path": str(config.db_path),
            "db_size_bytes": stats.get("db_size_bytes", 0),
            "entities": {
                "files": stats.get("files", 0),
                "functions": stats.get("functions", 0),
                "classes": stats.get("classes", 0),
                "call_edges": stats.get("call_edges", 0),
                "commits": stats.get("commits", 0),
                "error_groups": stats.get("error_groups", 0),
            },
        }

    @mcp.tool()
    def reindex(path: str) -> dict:
        """Re-index only changed files in a project (uses content hashing to detect changes).
        Faster than a full index_codebase with force=True."""
        start = time.time()
        result = analyzer.index_codebase(path, force=False)
        graph.build_graph(path)
        result["duration_seconds"] = round(time.time() - start, 2)
        return result
