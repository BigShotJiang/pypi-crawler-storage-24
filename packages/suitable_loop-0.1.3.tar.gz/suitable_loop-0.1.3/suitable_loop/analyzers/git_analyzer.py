"""Git-based change analysis engine for CodeZero.

Reads repository history via GitPython, computes per-commit risk scores
using a weighted formula over complexity delta, blast radius, churn,
lines changed, and file count, and persists results to the database.
"""

from __future__ import annotations

import logging
from collections import Counter
from pathlib import Path

import git

from suitable_loop.config import SuitableLoopConfig
from suitable_loop.db import Database
from suitable_loop.models import CommitFile, CommitInfo

logger = logging.getLogger(__name__)


class GitAnalyzer:
    """Analyzes Git repository history to surface risky changes and hotspots."""

    def __init__(self, db: Database, config: SuitableLoopConfig) -> None:
        self.db = db
        self.config = config

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def analyze_recent_changes(
        self, repo_path: str, n_commits: int | None = None
    ) -> list[dict]:
        """Analyze the last *n_commits* commits and return risk-scored results.

        Each commit is scored with a weighted combination of complexity delta,
        blast radius, churn rate, lines changed, and file count.  Results are
        persisted to the database and returned sorted by ``risk_score``
        descending.
        """
        depth = n_commits or self.config.git.default_commit_depth
        weights = self.config.git.risk_weights

        repo = self._open_repo(repo_path)
        if repo is None:
            return []

        commits = self._iter_commits(repo, depth)
        if not commits:
            logger.info("No commits found in %s", repo_path)
            return []

        # ----------------------------------------------------------
        # Phase 1: extract raw data per commit
        # ----------------------------------------------------------
        raw_records: list[dict] = []
        # Track file appearance counts across the batch for churn.
        file_appearance: Counter[str] = Counter()

        for commit in commits:
            changed_files = self._extract_changed_files(commit)
            total_insertions = 0
            total_deletions = 0
            commit_file_records: list[dict] = []

            for cf in changed_files:
                total_insertions += cf["insertions"]
                total_deletions += cf["deletions"]
                file_appearance[cf["file_path"]] += 1

                # Complexity delta for .py files
                complexity_before, complexity_after = self._compute_complexity_delta(
                    commit, cf["file_path"], cf["change_type"]
                )
                cf["complexity_before"] = complexity_before
                cf["complexity_after"] = complexity_after
                commit_file_records.append(cf)

            record = {
                "sha": commit.hexsha,
                "author": str(commit.author),
                "timestamp": commit.committed_date,
                "message": commit.message.strip(),
                "files_changed": len(changed_files),
                "insertions": total_insertions,
                "deletions": total_deletions,
                "commit_files": commit_file_records,
                # Raw factors (pre-normalization)
                "_complexity_delta": sum(
                    abs((cf.get("complexity_after") or 0) - (cf.get("complexity_before") or 0))
                    for cf in commit_file_records
                ),
                "_blast_radius": self._commit_blast_radius(commit_file_records, repo_path),
                "_churn_rate": sum(
                    file_appearance[cf["file_path"]] for cf in commit_file_records
                ),
                "_lines_changed": total_insertions + total_deletions,
                "_file_count": len(changed_files),
            }
            raw_records.append(record)

        # ----------------------------------------------------------
        # Phase 2: normalize factors and compute risk scores
        # ----------------------------------------------------------
        complexity_vals = [r["_complexity_delta"] for r in raw_records]
        blast_vals = [r["_blast_radius"] for r in raw_records]
        churn_vals = [float(r["_churn_rate"]) for r in raw_records]
        lines_vals = [float(r["_lines_changed"]) for r in raw_records]
        files_vals = [float(r["_file_count"]) for r in raw_records]

        norm_complexity = self._normalize(complexity_vals)
        norm_blast = self._normalize(blast_vals)
        norm_churn = self._normalize(churn_vals)
        norm_lines = self._normalize(lines_vals)
        norm_files = self._normalize(files_vals)

        w_complexity = weights.get("complexity", 0.30)
        w_blast = weights.get("blast_radius", 0.25)
        w_churn = weights.get("churn", 0.20)
        w_lines = weights.get("lines", 0.15)
        w_files = weights.get("files", 0.10)

        results: list[dict] = []
        for i, record in enumerate(raw_records):
            risk_score = (
                w_complexity * norm_complexity[i]
                + w_blast * norm_blast[i]
                + w_churn * norm_churn[i]
                + w_lines * norm_lines[i]
                + w_files * norm_files[i]
            )

            # Persist commit
            commit_info = CommitInfo(
                repo_path=repo_path,
                sha=record["sha"],
                author=record["author"],
                timestamp=record["timestamp"],
                message=record["message"],
                files_changed=record["files_changed"],
                insertions=record["insertions"],
                deletions=record["deletions"],
                risk_score=risk_score,
            )
            commit_id = self.db.upsert_commit(commit_info)

            # Persist commit files
            for cf in record["commit_files"]:
                commit_file = CommitFile(
                    commit_id=commit_id,
                    file_path=cf["file_path"],
                    change_type=cf["change_type"],
                    insertions=cf["insertions"],
                    deletions=cf["deletions"],
                    complexity_before=cf.get("complexity_before"),
                    complexity_after=cf.get("complexity_after"),
                )
                self.db.insert_commit_file(commit_file)

            results.append({
                "sha": record["sha"],
                "author": record["author"],
                "timestamp": record["timestamp"],
                "message": record["message"],
                "files_changed": record["files_changed"],
                "insertions": record["insertions"],
                "deletions": record["deletions"],
                "risk_score": round(risk_score, 4),
                "factors": {
                    "complexity_delta": norm_complexity[i],
                    "blast_radius": norm_blast[i],
                    "churn_rate": norm_churn[i],
                    "lines_changed": norm_lines[i],
                    "file_count": norm_files[i],
                },
            })

        self.db.commit()
        results.sort(key=lambda r: r["risk_score"], reverse=True)
        logger.info(
            "Analyzed %d commits in %s; highest risk %.4f (%s)",
            len(results),
            repo_path,
            results[0]["risk_score"] if results else 0.0,
            results[0]["sha"][:8] if results else "n/a",
        )
        return results

    def analyze_commit(self, repo_path: str, sha: str) -> dict:
        """Return a detailed breakdown of a single commit.

        Includes per-file diffs, complexity deltas, and blast radius.
        """
        repo = self._open_repo(repo_path)
        if repo is None:
            return {"error": f"Cannot open repository at {repo_path}"}

        try:
            commit = repo.commit(sha)
        except (git.BadName, git.GitCommandError, ValueError) as exc:
            logger.warning("Cannot resolve commit %s: %s", sha, exc)
            return {"error": f"Cannot resolve commit {sha}: {exc}"}

        changed_files = self._extract_changed_files(commit)
        file_details: list[dict] = []
        total_insertions = 0
        total_deletions = 0

        for cf in changed_files:
            total_insertions += cf["insertions"]
            total_deletions += cf["deletions"]

            complexity_before, complexity_after = self._compute_complexity_delta(
                commit, cf["file_path"], cf["change_type"]
            )

            blast = self.blast_radius(cf["file_path"])

            # Attempt to get the diff for this file
            diff_text = self._file_diff_text(commit, cf["file_path"])

            file_details.append({
                "file_path": cf["file_path"],
                "change_type": cf["change_type"],
                "insertions": cf["insertions"],
                "deletions": cf["deletions"],
                "complexity_before": complexity_before,
                "complexity_after": complexity_after,
                "complexity_delta": (complexity_after or 0) - (complexity_before or 0),
                "blast_radius": blast,
                "diff": diff_text,
            })

        return {
            "sha": commit.hexsha,
            "author": str(commit.author),
            "timestamp": commit.committed_date,
            "message": commit.message.strip(),
            "files_changed": len(changed_files),
            "insertions": total_insertions,
            "deletions": total_deletions,
            "files": file_details,
        }

    def hotspot_report(
        self, repo_path: str, n_commits: int | None = None
    ) -> list[dict]:
        """Identify hotspot files by cross-referencing churn with dependency count.

        Returns files ranked by ``churn * dependency_count`` descending.
        """
        depth = n_commits or self.config.git.default_commit_depth

        repo = self._open_repo(repo_path)
        if repo is None:
            return []

        commits = self._iter_commits(repo, depth)
        if not commits:
            return []

        # Count how often each file path appears across commits.
        file_churn: Counter[str] = Counter()
        for commit in commits:
            changed = self._extract_changed_files(commit)
            for cf in changed:
                file_churn[cf["file_path"]] += 1

        # For each file, look up dependency count from the database.
        hotspots: list[dict] = []
        for file_path, churn in file_churn.items():
            dep_count = self._dependency_count(file_path)
            score = churn * dep_count
            hotspots.append({
                "file_path": file_path,
                "churn": churn,
                "dependency_count": dep_count,
                "hotspot_score": score,
            })

        hotspots.sort(key=lambda h: h["hotspot_score"], reverse=True)
        return hotspots

    def blast_radius(self, file_path: str) -> dict:
        """Find all files that transitively depend on *file_path*.

        Returns a dict with ``count`` and ``dependents`` (list of file paths).
        """
        file_entity = self.db.get_file_by_path(file_path)
        if file_entity is None:
            file_entity = self.db.find_file_by_suffix(file_path)
        if file_entity is None:
            return {"count": 0, "dependents": []}

        visited: set[int] = set()
        queue: list[int] = [file_entity.id]  # type: ignore[arg-type]

        while queue:
            current_id = queue.pop()
            if current_id in visited:
                continue
            visited.add(current_id)
            dependents = self.db.get_file_dependents(current_id)
            for dep in dependents:
                if dep.id not in visited:
                    queue.append(dep.id)  # type: ignore[arg-type]

        # Remove the original file itself from the result set.
        visited.discard(file_entity.id)  # type: ignore[arg-type]

        dependent_paths: list[str] = []
        for fid in visited:
            entity = self.db.get_file_by_id(fid)
            if entity is not None:
                dependent_paths.append(entity.path)

        return {"count": len(dependent_paths), "dependents": sorted(dependent_paths)}

    # ------------------------------------------------------------------
    # Normalization helper
    # ------------------------------------------------------------------

    @staticmethod
    def _normalize(values: list[float]) -> list[float]:
        """Normalize *values* to the ``[0, 1]`` range using min-max scaling.

        Returns a list of zeros when all values are identical.
        """
        if not values:
            return []
        min_val = min(values)
        max_val = max(values)
        span = max_val - min_val
        if span == 0:
            return [0.0] * len(values)
        return [(v - min_val) / span for v in values]

    # ------------------------------------------------------------------
    # Git helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _open_repo(repo_path: str) -> git.Repo | None:
        """Open a Git repository, returning ``None`` on failure."""
        try:
            return git.Repo(repo_path, search_parent_directories=True)
        except (git.InvalidGitRepositoryError, git.NoSuchPathError) as exc:
            logger.error("Cannot open Git repository at %s: %s", repo_path, exc)
            return None

    @staticmethod
    def _iter_commits(repo: git.Repo, max_count: int) -> list[git.Commit]:
        """Return up to *max_count* commits from the active branch."""
        try:
            return list(repo.iter_commits(max_count=max_count))
        except (git.GitCommandError, ValueError) as exc:
            logger.warning("Cannot iterate commits: %s", exc)
            return []

    @staticmethod
    def _extract_changed_files(commit: git.Commit) -> list[dict]:
        """Extract changed file metadata from a commit's diff against its parent.

        Returns a list of dicts with keys ``file_path``, ``change_type``,
        ``insertions``, and ``deletions``.
        """
        results: list[dict] = []

        # Determine the parent to diff against.  For the initial commit the
        # tree is diffed against an empty tree (NULL_TREE).
        if commit.parents:
            diffs = commit.parents[0].diff(commit, create_patch=False)
        else:
            diffs = commit.diff(git.NULL_TREE, create_patch=False)

        # Use commit.stats for line-level counts since Diff objects do not
        # always expose insertions/deletions directly.
        stats_files: dict[str, dict] = {}
        try:
            stats_files = commit.stats.files
        except Exception:
            pass

        for diff_item in diffs:
            # Determine a usable file path from the diff.
            file_path = diff_item.b_path or diff_item.a_path or ""
            if not file_path:
                continue

            # Map GitPython change type to a human-readable label.
            change_type = _diff_change_type(diff_item)

            file_stats = stats_files.get(file_path, {})
            results.append({
                "file_path": file_path,
                "change_type": change_type,
                "insertions": file_stats.get("insertions", 0),
                "deletions": file_stats.get("deletions", 0),
            })

        return results

    # ------------------------------------------------------------------
    # Complexity helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _compute_complexity_delta(
        commit: git.Commit, file_path: str, change_type: str
    ) -> tuple[int | None, int | None]:
        """Compute radon cyclomatic complexity before and after the commit.

        Only applies to ``.py`` files.  Returns ``(None, None)`` for
        non-Python files or when radon is unavailable.
        """
        if not file_path.endswith(".py"):
            return None, None

        try:
            from radon.complexity import cc_visit  # type: ignore[import-untyped]
        except ImportError:
            return None, None

        complexity_before: int | None = None
        complexity_after: int | None = None

        # Complexity *after* the commit (file in the commit's tree).
        if change_type != "D":
            try:
                blob = commit.tree / file_path
                source_after = blob.data_stream.read().decode("utf-8", errors="replace")
                complexity_after = _total_complexity(cc_visit, source_after)
            except (KeyError, TypeError, Exception):
                complexity_after = 0

        # Complexity *before* the commit (file in the parent's tree).
        if change_type != "A" and commit.parents:
            try:
                parent_blob = commit.parents[0].tree / file_path
                source_before = parent_blob.data_stream.read().decode("utf-8", errors="replace")
                complexity_before = _total_complexity(cc_visit, source_before)
            except (KeyError, TypeError, Exception):
                complexity_before = 0

        return complexity_before, complexity_after

    @staticmethod
    def _file_diff_text(commit: git.Commit, file_path: str) -> str:
        """Return the unified diff text for *file_path* within *commit*."""
        try:
            if commit.parents:
                diffs = commit.parents[0].diff(commit, paths=[file_path], create_patch=True)
            else:
                diffs = commit.diff(git.NULL_TREE, paths=[file_path], create_patch=True)

            for diff_item in diffs:
                if diff_item.diff:
                    raw = diff_item.diff
                    if isinstance(raw, bytes):
                        return raw.decode("utf-8", errors="replace")
                    return str(raw)
        except Exception as exc:
            logger.debug("Cannot get diff for %s in %s: %s", file_path, commit.hexsha[:8], exc)
        return ""

    # ------------------------------------------------------------------
    # Blast radius / dependency helpers
    # ------------------------------------------------------------------

    def _commit_blast_radius(self, commit_files: list[dict], repo_path: str) -> float:
        """Sum transitive dependent counts for all files in a commit."""
        total = 0
        for cf in commit_files:
            total += self._dependency_count(cf["file_path"])
        return float(total)

    def _dependency_count(self, file_path: str) -> int:
        """Return the number of files that transitively depend on *file_path*."""
        result = self.blast_radius(file_path)
        return result["count"]


# ------------------------------------------------------------------
# Module-level helpers
# ------------------------------------------------------------------

def _diff_change_type(diff_item: git.Diff) -> str:  # type: ignore[name-defined]
    """Map a GitPython Diff object's change_type to a readable string."""
    mapping = {
        "A": "A",
        "D": "D",
        "M": "M",
        "R": "R",
        "C": "C",
        "T": "T",
    }
    ct = getattr(diff_item, "change_type", None) or "M"
    return mapping.get(ct, ct)


def _total_complexity(cc_visit_fn, source: str) -> int:
    """Sum cyclomatic complexity across all blocks returned by radon."""
    try:
        blocks = cc_visit_fn(source)
        return sum(block.complexity for block in blocks)
    except Exception:
        return 0
