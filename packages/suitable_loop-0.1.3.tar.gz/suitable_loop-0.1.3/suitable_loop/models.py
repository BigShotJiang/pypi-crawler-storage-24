"""Data models for CodeZero entities."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class FileEntity:
    id: int | None = None
    path: str = ""
    project_root: str = ""
    size_bytes: int = 0
    last_modified: float = 0.0
    last_indexed: float = 0.0
    line_count: int = 0
    hash: str = ""


@dataclass
class FunctionEntity:
    id: int | None = None
    file_id: int | None = None
    name: str = ""
    qualified_name: str = ""
    class_name: str | None = None
    line_start: int = 0
    line_end: int = 0
    signature: str = ""
    docstring: str | None = None
    complexity: int = 0
    is_method: bool = False
    is_async: bool = False


@dataclass
class ClassEntity:
    id: int | None = None
    file_id: int | None = None
    name: str = ""
    qualified_name: str = ""
    line_start: int = 0
    line_end: int = 0
    bases: list[str] = field(default_factory=list)
    docstring: str | None = None


@dataclass
class ImportEntity:
    id: int | None = None
    file_id: int | None = None
    module: str = ""
    alias: str | None = None
    is_internal: bool = False
    resolved_file_id: int | None = None


@dataclass
class CallEdge:
    id: int | None = None
    caller_id: int | None = None
    callee_id: int | None = None
    file_id: int | None = None
    line_number: int = 0


@dataclass
class FileDependency:
    id: int | None = None
    source_file_id: int | None = None
    target_file_id: int | None = None


@dataclass
class CommitInfo:
    id: int | None = None
    repo_path: str = ""
    sha: str = ""
    author: str = ""
    timestamp: float = 0.0
    message: str = ""
    files_changed: int = 0
    insertions: int = 0
    deletions: int = 0
    risk_score: float = 0.0


@dataclass
class CommitFile:
    id: int | None = None
    commit_id: int | None = None
    file_path: str = ""
    change_type: str = ""
    insertions: int = 0
    deletions: int = 0
    complexity_before: int | None = None
    complexity_after: int | None = None


@dataclass
class LogEntry:
    id: int | None = None
    source_file: str = ""
    timestamp: float | None = None
    level: str = ""
    logger_name: str = ""
    message: str = ""
    raw_line: str = ""
    error_group_id: int | None = None


@dataclass
class ErrorGroup:
    id: int | None = None
    signature: str = ""
    exception_type: str = ""
    exception_message: str = ""
    traceback: str = ""
    first_seen: float = 0.0
    last_seen: float = 0.0
    occurrence_count: int = 1


@dataclass
class ErrorCodeLink:
    id: int | None = None
    error_group_id: int | None = None
    function_id: int | None = None
    file_id: int | None = None
    line_number: int = 0
    frame_position: int = 0
