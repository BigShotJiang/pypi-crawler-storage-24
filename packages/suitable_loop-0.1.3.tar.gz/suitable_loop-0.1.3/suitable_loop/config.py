"""Configuration management for Suitable Loop."""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class AnalysisConfig:
    max_file_size_kb: int = 500
    exclude_patterns: list[str] = field(default_factory=lambda: [
        "**/venv/**",
        "**/.venv/**",
        "**/node_modules/**",
        "**/__pycache__/**",
        "**/migrations/**",
        "**/.git/**",
    ])
    complexity_threshold: int = 10


@dataclass
class GitConfig:
    default_commit_depth: int = 50
    risk_weights: dict[str, float] = field(default_factory=lambda: {
        "complexity": 0.30,
        "blast_radius": 0.25,
        "churn": 0.20,
        "lines": 0.15,
        "files": 0.10,
    })


@dataclass
class LogConfig:
    auto_detect_format: bool = True
    max_entries_per_ingest: int = 50_000


@dataclass
class SuitableLoopConfig:
    db_path: Path = field(default_factory=lambda: Path(
        os.environ.get("SUITABLE_LOOP_DB_PATH", "~/.suitable-loop/suitable-loop.db")
    ).expanduser())
    log_level: str = "INFO"
    analysis: AnalysisConfig = field(default_factory=AnalysisConfig)
    git: GitConfig = field(default_factory=GitConfig)
    logging: LogConfig = field(default_factory=LogConfig)


def load_config() -> SuitableLoopConfig:
    """Load configuration from environment variables."""
    config = SuitableLoopConfig()
    if db_path := os.environ.get("SUITABLE_LOOP_DB_PATH"):
        config.db_path = Path(db_path).expanduser()
    if log_level := os.environ.get("SUITABLE_LOOP_LOG_LEVEL"):
        config.log_level = log_level
    return config
