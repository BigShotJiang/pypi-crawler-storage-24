"""Entry point for `python -m suitable_loop`."""

from .server import main

main()
