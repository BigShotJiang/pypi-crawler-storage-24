"""Suitable Loop MCP Server — entry point."""

from __future__ import annotations

import logging

from mcp.server.fastmcp import FastMCP

from .config import load_config
from .db import Database
from .tools.code_tools import register_code_tools
from .tools.git_tools import register_git_tools
from .tools.log_tools import register_log_tools
from .tools.util_tools import register_util_tools

logger = logging.getLogger(__name__)


def create_server() -> FastMCP:
    config = load_config()

    logging.basicConfig(
        level=getattr(logging, config.log_level, logging.INFO),
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    )

    db = Database(config)
    db.connect()

    mcp = FastMCP("Suitable Loop", json_response=True)

    register_code_tools(mcp, db, config)
    register_git_tools(mcp, db, config)
    register_log_tools(mcp, db, config)
    register_util_tools(mcp, db, config)

    logger.info("Suitable Loop MCP server initialized (db: %s)", config.db_path)
    return mcp


server = create_server()


def main():
    """CLI entry point for uvx / python -m suitable_loop."""
    server.run(transport="stdio")
