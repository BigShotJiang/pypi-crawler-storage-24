# UltraBalance

A modular robot balance and control framework for education and research.

## Features
- **State Estimation**: Kalman filter, complementary filter
- **Control Algorithms**: PID, LQR, adaptive control, impedance control
- **Path Planning**: A* global planner
- **Hardware Abstraction**: Simulator interface, real-time control loop
- **Pure Python**: Only depends on numpy and scipy

## Quick Start

Install the package:
```bash

 ```pip install ub-clean-test```

from ultra_balance import create_robot
robot = create_robot('two_wheel')
robot.start()