"""Policy action models."""

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Literal


class ActionType(Enum):
    """Policy action types."""

    ALLOW = "ALLOW"
    DENY = "DENY"
    AUDIT = "AUDIT"  # Log but don't block
    REDIRECT = "REDIRECT"
    RETRY = "RETRY"
    FAULT_INJECTION = "FAULT_INJECTION"
    RATE_LIMIT = "RATE_LIMIT"
    CUSTOM = "CUSTOM"


class HTTPMethod(Enum):
    """Standard HTTP methods."""

    GET = "GET"
    POST = "POST"
    PUT = "PUT"
    DELETE = "DELETE"
    PATCH = "PATCH"
    HEAD = "HEAD"
    OPTIONS = "OPTIONS"
    CONNECT = "CONNECT"
    TRACE = "TRACE"

    # TODO: WEBDAV methods? Are they relevant?
    # PROPFIND = "PROPFIND"  # WebDAV
    # PROPPATCH = "PROPPATCH"  # WebDAV
    # MKCOL = "MKCOL"  # WebDAV
    # COPY = "COPY"  # WebDAV
    # MOVE = "MOVE"  # WebDAV
    # LOCK = "LOCK"  # WebDAV
    # UNLOCK = "UNLOCK"  # WebDAV

    # Wildcard
    ALL = "*"  # Match all methods


@dataclass
class AllowedRoute:
    """Traffic route specification for policies."""

    methods: set[HTTPMethod] = field(default_factory=set)
    paths: list[str] = field(default_factory=list)  # URL paths with wildcards: /api/*, /health
    ports: list[int] = field(default_factory=list)  # TCP/UDP ports

    # Protocol-specific fields
    hosts: list[str] = field(default_factory=list)  # DNS names: api.example.com, *.internal
    headers: dict[str, str] = field(default_factory=dict)  # Required headers
    # Special route flags
    allow_all: bool = False
    deny_all: bool = False


@dataclass
class RateLimitConfig:
    """Rate limiting configuration."""

    requests_per_second: int | None = None
    burst_size: int | None = None
    duration_seconds: int = 60
    by_header: str | None = None  # Rate limit by specific header value
    by_remote_ip: bool = False
    by_path: bool = False
    response_status_code: Literal[429, 503] = 429  # Too Many Requests or Service Unavailable


@dataclass
class RetryConfig:
    """Retry policy configuration."""

    attempts: int = 3
    per_try_timeout_seconds: int = 30
    retry_on: set[Literal["5xx", "4xx", "reset", "connect-failure", "refused-stream"]] = field(default_factory=set)
    retry_on_status_codes: set[int] = field(default_factory=set)
    backoff_strategy: Literal["exponential", "linear", "fixed"] = "exponential"


@dataclass
class FaultInjectionConfig:
    """Fault injection for testing resilience."""

    delay_percentage: float = 0.0
    delay_seconds: float = 0.0
    abort_percentage: float = 0.0
    abort_status_code: int = 500


@dataclass
class PolicyAction:
    """
    Represents what action a policy takes when conditions match.
    Different from basic ALLOW/DENY - includes traffic management capabilities.
    """

    type: ActionType

    # Basic action modifiers
    enabled: bool = True
    priority: int = 0  # Higher priority actions execute first

    # Traffic management configs
    rate_limit: RateLimitConfig | None = None
    retry: RetryConfig | None = None
    fault_injection: FaultInjectionConfig | None = None

    # Redirect configuration
    redirect_host: str | None = None
    redirect_port: int | None = None
    redirect_scheme: Literal["http", "https"] | None = None
    redirect_path: str | None = None

    # Custom action data for extensibility
    custom_config: dict[str, Any] = field(default_factory=dict)

    # Audit/logging configuration
    log_level: Literal["DEBUG", "INFO", "WARN", "ERROR", "NONE"] = "INFO"

    def is_blocking(self) -> bool:
        """Check if this action blocks traffic."""
        return self.type in [ActionType.DENY, ActionType.REDIRECT]

    def has_traffic_management(self) -> bool:
        """Check if action includes traffic management features."""
        return any([self.rate_limit, self.retry, self.fault_injection])
