import base64
import json
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.serialization import load_pem_private_key
from cryptography.hazmat.backends import default_backend

def sign_request(data, private_key_data):

    payload_bytes = json.dumps(data, separators=(",", ":")).encode("utf-8")
        
    private_key = load_pem_private_key(private_key_data, password=None, backend=default_backend())

    # Sign the data
    signature = private_key.sign(
        payload_bytes,
        padding.PSS(
            mgf=padding.MGF1(hashes.SHA256()),
            salt_length=padding.PSS.MAX_LENGTH
        ),
        hashes.SHA256()
    )

    # Convert to hex and base64
    signature_b64 = base64.b64encode(signature).decode()

    return signature_b64

