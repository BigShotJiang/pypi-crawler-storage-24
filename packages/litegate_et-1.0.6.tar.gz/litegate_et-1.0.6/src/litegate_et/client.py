import requests
from typing import Optional
from .signature import sign_request
from typing import Dict, Any

VERSION = 1.0

class LiteGateClient:
    def __init__(self, public_key: str, private_key: str):
        self.public_key = public_key
        self.private_key = private_key
        self.base_url = "https://api.litegate.et"

    def initiate_telebirr_payment(
        self,
        title: str,
        amount: str,
        phone: str,
    ) -> str:
        payload = {
            "title": title,
            "amount": amount,
            "buyer_phone_number": phone,
        }

        signature = sign_request(payload, self.private_key)

        response = requests.post(
            f"{self.base_url}/v1/telebirr/initiate/",
            json=(payload),
            headers={
                "Content-Type": "application/json",
                "Accept": "application/json",
                "Authorization": f"PublicKey {self.public_key}",
                "X-SIGNATURE": signature,
                "User-Agent": f"LiteGate-Python-SDK/{VERSION}",
            },
        )

        response.raise_for_status()

        return (response.json()["redirect_url"])
    
    def telebirr_callback(self, data: Dict[str, Any]) -> Dict[str, Any]:

        response = requests.post(
            f"{self.base_url}/v1/telebirr/notify/",
            json=(data),
            headers={
                "Content-Type": "application/json",
                "Accept": "application/json",
                "User-Agent": f"LiteGate-Python-SDK/{VERSION}",
            },
        )

        response.raise_for_status()

        return (response.json())
    
    def initiate_cbebirr_payment(
        self,
        title: str,
        amount: str,
        phone: str,
    ) -> str:
        payload = {
            "title": title,
            "amount": amount,
            "buyer_phone_number": phone,
        }

        signature = sign_request(payload, self.private_key)

        response = requests.post(
            f"{self.base_url}/v1/cbebirr/initiate/",
            json=(payload),
            headers={
                "Content-Type": "application/json",
                "Accept": "application/json",
                "Authorization": f"PublicKey {self.public_key}",
                "X-SIGNATURE": signature,
                "User-Agent": f"LiteGate-Python-SDK/{VERSION}",
            },
        )

        response.raise_for_status()

        return (response.json()["redirect_url"])
    
    def cbebirr_callback(self, enc_val: str) -> Dict[str, Any]:

        signature = sign_request(enc_val, self.private_key)

        response = requests.post(
            f"{self.base_url}/v1/cbebirr/notify/",
            json=({"EncVal": enc_val}),
            headers={
                "Content-Type": "application/json",
                "Accept": "application/json",
                "Authorization": f"PublicKey {self.public_key}",
                "X-SIGNATURE": signature,
                "User-Agent": f"LiteGate-Python-SDK/{VERSION}",
            },
        )

        response.raise_for_status()

        return (response.json())
