import os
import time
import uuid
import click
import shutil
import sys
import subprocess
from pathlib import Path
from .consts import gitcmd as git
from .repo import Repo
from .tools import prepare_dir
from .tools import remember_cwd
from .tools import reformat_url
from .tools import _raise_error
from .tools import rmtree
from .tools import replace_dir_with
from .tools import temppath

# store big repos in tar file and try to restore from there;
# otherwise lot of downloads have to be done


from contextlib import contextmanager


@contextmanager
def _get_cache_dir(main_repo, repo_yml, no_action_if_not_exist=False, update=None):
    url = repo_yml.url
    if not url:
        click.secho(f"Missing url for: {repo_yml.path}")
        sys.exit(-1)
    try:
        urlsafe = reformat_url(url, "git")
    except Exception:
        urlsafe = url
    for c in "?:+[]{}\\/\"'_":
        urlsafe = urlsafe.replace(c, "-")
    urlsafe = urlsafe.split("@")[-1]
    path = Path(os.path.expanduser("~/.cache/gimera")) / urlsafe

    if os.getenv("GIMERA_NO_CACHE", "") == "1":
        TEMP_KEY = f"{repo_yml.url}_{repo_yml.sha or repo_yml.branch}"
        with temppath(mkdir=False, reuse_key=TEMP_KEY) as path:
            if not path.exists():
                subprocess.run(["git", "clone", "--single-branch", "--depth=1", "--branch", repo_yml.branch, repo_yml.url, path], check=True)
                if repo_yml.sha:
                    Repo(path).X(*(git + ["fetch", "origin", repo_yml.sha]))
                    Repo(path).X(*(git + ["checkout", repo_yml.sha]))
            yield path
            return

    golden_path = path
    if no_action_if_not_exist and not golden_path.exists():
        yield None
        return
    possible_temp_path = Path(str(path) + "." + str(uuid.uuid4()))
    del path
    try:
        golden_path.parent.mkdir(exist_ok=True, parents=True)

        must_exist = ["HEAD", "refs", "objects", "config"]
        if golden_path.exists() and (any(
            not (golden_path / x).exists() for x in must_exist
        ) or os.getenv("GIMERA_CLEAR_CACHE") == "1"):
            click.secho(f"Removing cache directory:\n{golden_path}", fg="red")
            rmtree(golden_path)

        if os.getenv("GIMERA_CLEAR_ZIP_CACHE", "") == "1":
            tarfile = _get_cache_dir_tarfile(golden_path)
            if tarfile.exists():
                click.secho(f"Removing cache tar file:\n{tarfile}", fg="red")
                tarfile.unlink()

        just_cloned = False
        if not golden_path.exists():
            click.secho(
                f"Caching the repository {repo_yml.url} for quicker reuse",
                fg="yellow",
            )
            tarfile = _get_cache_dir_tarfile(golden_path)
            with prepare_dir(possible_temp_path) as _path:
                with remember_cwd(
                    "/tmp"
                ):  # called from other situations where path may not exist anymore
                    if tarfile.exists():
                        try:
                            _extract_tar_file(_path, tarfile)
                            just_cloned = True
                        except Exception:
                            click.secho(
                                f"Failed to extract tar file {tarfile} - will try to clone again.",
                                fg="red",
                            )
                            tarfile.unlink()

                    if not just_cloned:
                        rmtree(_path)
                        _path.mkdir(parents=True)
                        Repo(main_repo.path).X(*(git + ["clone", "--bare", url, _path]))
                        _make_tar_file(_path, tarfile)
                        just_cloned = True

        effective_path = possible_temp_path if just_cloned else golden_path

        if repo_yml.sha:
            repo = Repo(effective_path)
            if not repo.contain_commit(repo_yml.sha):
                # make a fetch quickly; sha is missing
                # did not fetch all in a bare repo:
                #repo.X(*(git + ["fetch", "--all", "--tags", "--prune"]))
                repo.fetchall()
                if not repo.contain_commit(repo_yml.sha):
                    if not update:
                        _raise_error(
                            (
                                f"After fetching the commit {repo_yml.sha} "
                                f"was not found for {repo_yml.path}.\n"
                                f"All remote branches were checked."
                            )
                        )
                    else:
                        click.secho(
                            f"Warning: commit {repo_yml.sha} not found "
                            f"for {repo_yml.path} - will retry after update.",
                            fg="yellow",
                        )

        yield effective_path

        if just_cloned:
            replace_dir_with(possible_temp_path, golden_path)

    finally:
        possible_temp_path = Path(possible_temp_path)
        if possible_temp_path.exists():
            rmtree(possible_temp_path)


def _get_cache_dir_tarfile(_path):
    return Path(str(_path) + ".tar.gz")


def _make_tar_file(_path, tarfile):
    if tarfile.exists():
        tarfile.unlink()
    click.secho(
        f"Creating tar file {tarfile} from {_path} - might take some time on large repos.",
        fg="yellow",
    )
    tempfilename = str(tarfile) + "." + str(uuid.uuid4())
    subprocess.check_call(["tar", "cfz", str(tempfilename), "-C", str(_path), "."])
    os.replace(tempfilename, tarfile)


def _extract_tar_file(_path, tarfile):
    click.secho(f"Extracting tar file {tarfile} to {_path}", fg="yellow")
    subprocess.check_call(["tar", "xfz", str(tarfile)], cwd=_path)
