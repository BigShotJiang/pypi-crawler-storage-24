"""
Standalone certification package for CogniFlow step packages.

This package provides cryptographic certification and verification for step packages
in the CogniFlow ecosystem. It works independently of cf-pipeline-backend and can
be used by:
- Step package authors to request certification
- The certification authority to sign certificates
- Pipeline operators to verify step package authenticity

Trust Model:
- Ed25519 public key cryptography
- Official public key embedded in package
- Certificates stored in the step manifest RDF document (cf:pluginCertificate)
"""

__version__ = "0.2.1"

# Official CogniFlow certification public key (Ed25519)
# This key is used to verify that certificates were issued by the official authority
# The corresponding private key is held securely by the CogniFlow project maintainers
OFFICIAL_PUBLIC_KEY_B64 = None  # Will be set after first keypair generation

from .crypto import (
    generate_keypair,
    sign_data,
    verify_signature,
    compute_distribution_hash,
)
from .validation import (
    validate_step_package,
    verify_certificate,
    ValidationResult,
    CertificateInfo,
)

__all__ = [
    "__version__",
    "OFFICIAL_PUBLIC_KEY_B64",
    "generate_keypair",
    "sign_data", 
    "verify_signature",
    "compute_distribution_hash",
    "validate_step_package",
    "verify_certificate",
    "ValidationResult",
    "CertificateInfo",
]
