"""Affinity CRM tools for ecs-mcp."""

import os
from typing import Any

import httpx

from ecs_mcp import mcp

AFFINITY_BASE_URL = "https://api.affinity.co"


# ---------------------------------------------------------------------------
# Affinity API client helpers
# ---------------------------------------------------------------------------

def _get_api_key() -> str:
    key = os.environ.get("AFFINITY_API_KEY", "").strip()
    if not key:
        raise ValueError(
            "AFFINITY_API_KEY environment variable is not set. "
            "Add it to your Claude Desktop config under 'env'."
        )
    return key


def _client() -> httpx.AsyncClient:
    return httpx.AsyncClient(
        base_url=AFFINITY_BASE_URL,
        auth=("", _get_api_key()),
        headers={"Content-Type": "application/json"},
        timeout=30.0,
    )


async def _find_list_by_name(client: httpx.AsyncClient, list_name: str) -> dict[str, Any] | None:
    response = await client.get("/lists")
    response.raise_for_status()
    for lst in response.json():
        if lst.get("name", "").lower() == list_name.lower():
            return lst
    return None


async def _find_organization(client: httpx.AsyncClient, org_name: str) -> dict[str, Any] | None:
    response = await client.get("/organizations", params={"term": org_name})
    response.raise_for_status()
    orgs = response.json().get("organizations", [])
    if not orgs:
        return None
    for org in orgs:
        if org.get("name", "").lower() == org_name.lower():
            return org
    return orgs[0]


async def _create_organization(
    client: httpx.AsyncClient, org_name: str, domain: str = ""
) -> dict[str, Any]:
    if not domain:
        domain = "".join(c for c in org_name.lower() if c.isalnum()) + ".com"
    response = await client.post(
        "/organizations",
        json={"name": org_name, "domain": domain},
    )
    response.raise_for_status()
    return response.json()


LIST_TYPE_OPPORTUNITY = 8


async def _create_list_entry(
    client: httpx.AsyncClient, list_id: int, entity_id: int
) -> dict[str, Any]:
    response = await client.post(
        f"/lists/{list_id}/list-entries",
        json={"entity_id": entity_id},
    )
    response.raise_for_status()
    return response.json()


async def _create_opportunity(
    client: httpx.AsyncClient,
    name: str,
    list_id: int,
    org_id: int,
    person_ids: list[int] | None = None,
) -> dict[str, Any]:
    body: dict[str, Any] = {
        "name": name,
        "list_id": list_id,
        "organization_id": org_id,
    }
    if person_ids:
        body["person_ids"] = person_ids
    response = await client.post("/opportunities", json=body)
    response.raise_for_status()
    return response.json()


async def _find_person_by_email(
    client: httpx.AsyncClient, email: str
) -> dict[str, Any] | None:
    response = await client.get("/persons", params={"term": email})
    response.raise_for_status()
    for person in response.json().get("persons", []):
        if email.lower() in [e.lower() for e in person.get("emails", [])]:
            return person
    return None


async def _create_person(
    client: httpx.AsyncClient,
    full_name: str,
    email: str,
    org_id: int,
) -> dict[str, Any]:
    parts = full_name.strip().split(" ", 1)
    first_name = parts[0]
    last_name = parts[1] if len(parts) > 1 else ""
    body: dict[str, Any] = {
        "first_name": first_name,
        "last_name": last_name,
        "organization_ids": [org_id],
    }
    if email:
        body["emails"] = [email]
    response = await client.post("/persons", json=body)
    response.raise_for_status()
    return response.json()


async def _create_note(
    client: httpx.AsyncClient,
    content: str,
    org_id: int,
    person_id: int | None = None,
) -> dict[str, Any]:
    body: dict[str, Any] = {
        "content": content,
        "organization_ids": [org_id],
    }
    if person_id is not None:
        body["person_ids"] = [person_id]
    response = await client.post("/notes", json=body)
    response.raise_for_status()
    return response.json()


# ---------------------------------------------------------------------------
# MCP tool
# ---------------------------------------------------------------------------

@mcp.tool()
async def create_deal(
    list_name: str,
    organization_name: str,
    domain: str = "",
    contact_name: str = "",
    contact_email: str = "",
    note: str = "",
) -> str:
    """Add a company as a new deal entry on an Affinity CRM list.

    Finds or creates the organization, optionally creates the contact person,
    and attaches a note with opportunity details. Avoids duplicate organizations.

    Args:
        list_name: The exact name of the Affinity list (e.g. "ALL DEALS ECS").
        organization_name: The company name to add (e.g. "Acme Corp").
        domain: Company website domain (e.g. "acme.com"). Derived from name if omitted.
        contact_name: Full name of the contact person from the email.
        contact_email: Email address of the contact person.
        note: Opportunity details or context extracted from the email.
    """
    async with _client() as client:
        # Resolve the target list
        lst = await _find_list_by_name(client, list_name)
        if lst is None:
            return (
                f"Error: No Affinity list found with name '{list_name}'. "
                "Check the list name in Affinity and try again."
            )

        # Find or create the organization
        org = await _find_organization(client, organization_name)
        created_new_org = org is None
        if created_new_org:
            org = await _create_organization(client, organization_name, domain)

        org_id: int = org["id"]

        # Find or create the contact person (needed before adding to list for opportunities)
        person_id: int | None = None
        person_status = ""
        if contact_name or contact_email:
            existing_person = None
            if contact_email:
                existing_person = await _find_person_by_email(client, contact_email)
            if existing_person is None:
                person = await _create_person(client, contact_name, contact_email, org_id)
                person_id = person["id"]
                person_status = f"created new contact '{contact_name}' (id={person_id})"
            else:
                person_id = existing_person["id"]
                person_status = f"found existing contact '{existing_person.get('first_name', '')} {existing_person.get('last_name', '')}' (id={person_id})"

        # Add to list — opportunity lists require POST /opportunities; others use list entries
        if lst.get("type") == LIST_TYPE_OPPORTUNITY:
            entry = await _create_opportunity(
                client,
                name=org.get("name", organization_name),
                list_id=lst["id"],
                org_id=org_id,
                person_ids=[person_id] if person_id else None,
            )
        else:
            entry = await _create_list_entry(client, lst["id"], org_id)

        # Attach note
        note_status = ""
        if note:
            await _create_note(client, note, org_id, person_id)
            note_status = f"note added: {note[:80]}{'...' if len(note) > 80 else ''}"

        # Build status summary
        org_status = "created new organization" if created_new_org else "found existing organization"
        lines = [
            f"Successfully added '{org.get('name', organization_name)}' to '{lst['name']}'.",
            f"  - Organization: {org_status} (id={org_id})",
            f"  - List entry id: {entry.get('id', '?')}",
        ]
        if person_status:
            lines.append(f"  - Contact: {person_status}")
        if note_status:
            lines.append(f"  - Note: {note_status}")
        return "\n".join(lines)
