# key storage
_INTERNAL_CONFIG = {}

VERBOSE_LOGGING = False

# 1. Hardcode your required keys here! No more text files needed.
REQUIRED_KEYS = [
    "KALSHI_API_KEY",
    "PREDEXON_API_KEY",
    "DOME_API_KEY"
]


def set_verbose(enabled: bool):
    global VERBOSE_LOGGING
    VERBOSE_LOGGING = enabled


def is_verbose():
    return VERBOSE_LOGGING


def get_missing_keys():
    """Returns keys listed in REQUIRED_KEYS but not yet in _INTERNAL_CONFIG."""
    # 2. Just check against our hardcoded list
    return [k for k in REQUIRED_KEYS if k not in _INTERNAL_CONFIG]


def set_key(key: str, value: str):
    """Sets the key in our private dictionary."""
    _INTERNAL_CONFIG[key] = str(value)


def get_key(key: str):
    """Accessor for trackers to get their keys."""
    val = _INTERNAL_CONFIG.get(key)
    if not val:
        raise ValueError(f"Configuration Error: '{key}' was accessed but not set.")
    return val