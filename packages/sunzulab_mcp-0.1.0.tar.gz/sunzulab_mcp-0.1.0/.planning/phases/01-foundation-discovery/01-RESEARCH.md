# Phase 1: Foundation & Discovery - Research

**Researched:** 2026-03-14
**Domain:** Python MCP server development, packaging, authentication, REST API integration
**Confidence:** HIGH

## Summary

This phase builds a Python MCP server from scratch, distributable via `uvx sunzulab-mcp`, that authenticates to the SunzuLab gateway API and exposes three discovery tools (`list_exchanges`, `list_pairs`, `list_data_types`). The project is greenfield -- no existing code in the repository.

The standard approach uses the official `mcp` Python SDK (v1.26.0) which bundles FastMCP for high-level server creation. Tools are defined with decorated functions, input validation is automatic via type annotations and JSON Schema generation, and errors are returned as structured `isError: true` responses. The server communicates over stdio transport (default), requires no networking configuration, and runs as a console script entry point registered in `pyproject.toml`.

**Primary recommendation:** Use the official `mcp` package (not the standalone `fastmcp` package) with `from mcp.server.fastmcp import FastMCP`. Use `httpx.AsyncClient` for HTTP calls to the gateway API, managed through the lifespan pattern. Package with `hatchling` build backend and register a `[project.scripts]` console entry point for `uvx` compatibility.

<user_constraints>
## User Constraints (from CONTEXT.md)

### Locked Decisions
- Single env var `SUNZU_API_TOKEN` -- no config files, no interactive prompts
- Token is passed as Bearer header to the SunzuLab gateway API on every request
- Error messages must be actionable and non-technical:
  - Missing token: "No API token found. Set SUNZU_API_TOKEN in your MCP client config. Get your token at [website URL]."
  - Invalid/expired token: "Your API token is invalid or expired. Get a new one at [website URL]."
  - Insufficient permissions: "Your account doesn't have access to [resource]. Contact support."
- Token validation happens on first tool call (lazy), not at server startup
- Three separate tools: `list_exchanges`, `list_pairs` (required `exchange` param), `list_data_types`
- All three tools hit the `/v1/referential` endpoint and extract relevant slices
- Compact plain text responses, never raw JSON
- Short lists as bullet points, longer lists as comma-separated grouped by category
- Always include counts in responses
- Package name: `sunzulab-mcp` (PyPI), entry point command: `sunzulab-mcp`
- stdio transport, zero-code setup via JSON config block
- Config block shape uses `"command": "uvx", "args": ["sunzulab-mcp"]`

### Claude's Discretion
- Project structure and module layout
- HTTP client choice (httpx, aiohttp, etc.)
- Caching strategy for referential data (if any)
- Exact error message wording beyond the intent above
- Test framework and test structure

### Deferred Ideas (OUT OF SCOPE)
None -- discussion stayed within phase scope
</user_constraints>

<phase_requirements>
## Phase Requirements

| ID | Description | Research Support |
|----|-------------|-----------------|
| SETUP-01 | Server installs and runs via `uvx sunzulab-mcp` with no prior setup beyond `uv` | pyproject.toml with hatchling build, console_scripts entry point, `mcp` dependency |
| SETUP-02 | Client configures server by pasting JSON config into LLM client and setting `SUNZU_API_TOKEN` env var | stdio transport default, env var read via `os.environ`, JSON config block documented |
| SETUP-03 | Server authenticates to SunzuLab API using client's OAuth/JWT token from env var | httpx.AsyncClient with Bearer header, lazy validation on first tool call |
| SETUP-04 | Server returns clear, actionable error messages for auth failures | Structured error responses via `isError=True` in tool results, user-facing messages |
| PROT-01 | Server implements MCP protocol over stdio transport | `mcp.run()` defaults to stdio, official SDK handles protocol |
| PROT-02 | All tools expose JSON Schema input validation | FastMCP auto-generates JSON Schema from type annotations |
| PROT-03 | Errors return structured responses with `isError: true` and human-readable messages | `CallToolResult(isError=True, content=[TextContent(...)])` pattern |
| PROT-04 | Server works with Claude Desktop, Cursor, and any standard MCP client | stdio transport + official SDK ensures compatibility |
| DISC-01 | User can list available exchanges | `list_exchanges` tool calling `/v1/referential`, formatting as bullets with count |
| DISC-02 | User can list available trading pairs for a given exchange | `list_pairs` tool with `exchange` param, filtering referential data |
| DISC-03 | User can list available data types | `list_data_types` tool extracting data type info from referential endpoint |
</phase_requirements>

## Standard Stack

### Core
| Library | Version | Purpose | Why Standard |
|---------|---------|---------|--------------|
| `mcp` | 1.26.0 | Official MCP Python SDK with bundled FastMCP | Anthropic-maintained, spec-compliant, standard for all Python MCP servers |
| `httpx` | 0.28.1 | Async HTTP client for gateway API calls | De facto standard async HTTP client for Python; native async/await, connection pooling |

### Supporting
| Library | Version | Purpose | When to Use |
|---------|---------|---------|-------------|
| `pytest` | latest | Test framework | All unit and integration tests |
| `pytest-asyncio` | latest | Async test support | Testing async tool functions and httpx calls |
| `respx` | latest | Mock httpx requests | Mocking gateway API responses in tests |

### Alternatives Considered
| Instead of | Could Use | Tradeoff |
|------------|-----------|----------|
| `mcp` (official SDK) | `fastmcp` (standalone v3.x) | Standalone has more features but diverged from spec; official SDK is safer for production MCP servers |
| `httpx` | `aiohttp` | aiohttp is older, heavier; httpx has cleaner API, sync+async, better type support |
| `respx` | `pytest-httpx` | Both work; respx has more ergonomic API for httpx mocking |

**Installation:**
```bash
uv add "mcp[cli]" httpx
uv add --dev pytest pytest-asyncio respx
```

## Architecture Patterns

### Recommended Project Structure
```
sunzulab-mcp/
├── pyproject.toml
├── src/
│   └── sunzulab_mcp/
│       ├── __init__.py
│       ├── __main__.py          # python -m sunzulab_mcp support
│       ├── server.py            # FastMCP instance, tool definitions, main()
│       ├── client.py            # SunzuLab API client (httpx wrapper)
│       └── formatting.py        # Response formatting (bullets, counts, compact lists)
└── tests/
    ├── conftest.py              # Shared fixtures (mock API responses, MCP client)
    ├── test_server.py           # Tool integration tests via MCP Client
    ├── test_client.py           # API client unit tests
    └── test_formatting.py       # Formatting logic unit tests
```

### Pattern 1: FastMCP Server with Lifespan
**What:** Initialize shared resources (httpx client) at server startup, clean up on shutdown.
**When to use:** Always -- the httpx.AsyncClient should be shared across tool calls for connection pooling.
**Example:**
```python
# Source: Official MCP Python SDK README + verified patterns
from contextlib import asynccontextmanager
from collections.abc import AsyncIterator
from dataclasses import dataclass

import httpx
from mcp.server.fastmcp import FastMCP

@dataclass
class AppContext:
    http_client: httpx.AsyncClient

@asynccontextmanager
async def app_lifespan(server: FastMCP) -> AsyncIterator[AppContext]:
    async with httpx.AsyncClient(base_url="https://api.sunzulab.com") as client:
        yield AppContext(http_client=client)

mcp = FastMCP("sunzulab", lifespan=app_lifespan)
```

### Pattern 2: Tool with Context Injection
**What:** Access lifespan resources (httpx client) inside tool functions via Context parameter.
**When to use:** Every tool that needs to call the gateway API.
**Example:**
```python
# Source: Official MCP Python SDK patterns
from mcp.server.fastmcp import Context

@mcp.tool()
async def list_exchanges(ctx: Context) -> str:
    """List all available cryptocurrency exchanges.

    Returns the exchanges where SunzuLab collects market data.
    Use this to discover which exchanges you can query for trading pairs and data.
    """
    app = ctx.request_context.lifespan_context
    # ... call gateway API with app.http_client
```

### Pattern 3: Lazy Auth with Actionable Errors
**What:** Read token from env on first tool call, return structured error if missing/invalid.
**When to use:** All tool calls that hit the gateway API.
**Example:**
```python
import os
from mcp.types import CallToolResult, TextContent

def get_auth_headers() -> dict[str, str]:
    token = os.environ.get("SUNZU_API_TOKEN")
    if not token:
        raise AuthError(
            "No API token found. Set SUNZU_API_TOKEN in your MCP client config. "
            "Get your token at https://app.sunzulab.com/settings/api."
        )
    return {"Authorization": f"Bearer {token}"}
```

### Pattern 4: Structured Error Responses
**What:** Return `isError=True` responses that the LLM can understand and relay to the user.
**When to use:** Auth failures, API errors, invalid parameters.
**Example:**
```python
# Source: MCP spec + official SDK patterns
from mcp.types import CallToolResult, TextContent

# In tool implementation:
try:
    response = await http_client.get("/v1/referential", headers=headers)
    response.raise_for_status()
except httpx.HTTPStatusError as e:
    if e.response.status_code == 401:
        return CallToolResult(
            isError=True,
            content=[TextContent(
                type="text",
                text="Your API token is invalid or expired. Get a new one at https://app.sunzulab.com/settings/api."
            )]
        )
```

### Pattern 5: Console Entry Point
**What:** Register a console script in pyproject.toml so `uvx sunzulab-mcp` works.
**When to use:** Required for SETUP-01.
**Example:**
```toml
# pyproject.toml
[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[project]
name = "sunzulab-mcp"
version = "0.1.0"
description = "SunzuLab MCP server for crypto market data"
requires-python = ">=3.10"
dependencies = [
    "mcp[cli]>=1.20.0",
    "httpx>=0.28.0",
]

[project.scripts]
sunzulab-mcp = "sunzulab_mcp.server:main"
```

### Anti-Patterns to Avoid
- **Validating token at server startup:** Breaks the MCP connection if token is temporarily unavailable. Validate lazily on first tool call.
- **Using standalone `fastmcp` package:** It has diverged from the official spec; mixing imports causes type incompatibilities.
- **Creating one mega-tool with action parameter:** LLMs select specific tools better than parsing multi-purpose tool parameters. Use three separate tools.
- **Returning raw JSON from tools:** Wastes LLM tokens. Return compact formatted text.
- **Creating a new httpx.AsyncClient per request:** Loses connection pooling benefits. Use lifespan pattern to share one client.

## Don't Hand-Roll

| Problem | Don't Build | Use Instead | Why |
|---------|-------------|-------------|-----|
| MCP protocol handling | Custom JSON-RPC over stdio | `mcp` SDK | Protocol compliance, session management, capability negotiation |
| JSON Schema generation | Manual schema dicts | FastMCP type annotations | Auto-generated from Python types, stays in sync with code |
| Input validation | Custom parameter checking | FastMCP + Pydantic `Field` | Automatic coercion, constraints, error messages |
| HTTP connection management | Manual socket/session handling | `httpx.AsyncClient` in lifespan | Connection pooling, timeouts, retries, async support |
| Response content types | Manual JSON-RPC response building | `CallToolResult` / `TextContent` | Spec-compliant, handles serialization edge cases |

**Key insight:** The MCP SDK handles all protocol concerns. The server code should only focus on: calling the gateway API, formatting responses, and handling auth errors.

## Common Pitfalls

### Pitfall 1: Logging to stdout corrupts stdio transport
**What goes wrong:** `print()` or logging to stdout interleaves with MCP JSON-RPC messages, causing parse errors.
**Why it happens:** stdio transport uses stdout for protocol messages.
**How to avoid:** Configure all logging to stderr: `logging.basicConfig(stream=sys.stderr)`.
**Warning signs:** "Parse error" or garbled responses in the MCP client.

### Pitfall 2: Blocking the event loop with sync code
**What goes wrong:** Sync HTTP calls or CPU-heavy formatting freezes the server.
**Why it happens:** MCP server runs on asyncio; blocking calls stall all tool execution.
**How to avoid:** Use `httpx.AsyncClient` (not sync `httpx.Client`). FastMCP auto-runs sync tool functions in a threadpool, but prefer async for I/O.
**Warning signs:** Tools taking much longer than expected, timeouts.

### Pitfall 3: Missing error handling for gateway API responses
**What goes wrong:** Unhandled exceptions from httpx propagate as protocol errors instead of user-friendly messages.
**Why it happens:** Not wrapping API calls in try/except with structured error returns.
**How to avoid:** Catch `httpx.HTTPStatusError`, `httpx.ConnectError`, `httpx.TimeoutException` and return `CallToolResult(isError=True, ...)` with actionable messages.
**Warning signs:** LLM receives cryptic error messages or "internal server error".

### Pitfall 4: Forgetting to exclude Context from JSON Schema
**What goes wrong:** The `ctx: Context` parameter appears in the tool's input schema, confusing the LLM.
**Why it happens:** Incorrect type annotation.
**How to avoid:** FastMCP handles this automatically when the parameter is annotated with the `Context` type from `mcp.server.fastmcp`. The parameter name can be anything (`ctx`, `context`, etc.) as long as the type annotation is `Context`.
**Warning signs:** LLM tries to pass a "context" argument when calling the tool.

### Pitfall 5: pyproject.toml entry point function doesn't exist
**What goes wrong:** `uvx sunzulab-mcp` fails with import error.
**Why it happens:** The `[project.scripts]` entry points to a function that doesn't exist or isn't importable.
**How to avoid:** Ensure `server.py` has a `def main():` function that calls `mcp.run()` (or `mcp.run(transport="stdio")`). Test locally with `uv run sunzulab-mcp` before publishing.
**Warning signs:** "No module named" or "has no attribute 'main'" errors.

## Code Examples

### Complete Minimal Server
```python
# src/sunzulab_mcp/server.py
# Source: Official MCP Python SDK patterns
import logging
import os
import sys
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from dataclasses import dataclass

import httpx
from mcp.server.fastmcp import Context, FastMCP

logging.basicConfig(stream=sys.stderr, level=logging.INFO)
logger = logging.getLogger("sunzulab-mcp")

GATEWAY_BASE_URL = os.environ.get("SUNZU_API_URL", "https://api.sunzulab.com")


@dataclass
class AppContext:
    http_client: httpx.AsyncClient


@asynccontextmanager
async def app_lifespan(server: FastMCP) -> AsyncIterator[AppContext]:
    async with httpx.AsyncClient(base_url=GATEWAY_BASE_URL, timeout=30.0) as client:
        yield AppContext(http_client=client)


mcp = FastMCP("sunzulab", lifespan=app_lifespan)


def _get_auth_headers() -> dict[str, str]:
    token = os.environ.get("SUNZU_API_TOKEN")
    if not token:
        raise ValueError(
            "No API token found. Set SUNZU_API_TOKEN in your MCP client config. "
            "Get your token at https://app.sunzulab.com/settings/api."
        )
    return {"Authorization": f"Bearer {token}"}


@mcp.tool()
async def list_exchanges(ctx: Context) -> str:
    """List all available cryptocurrency exchanges.

    Returns the exchanges where SunzuLab collects market data.
    Use this to discover which exchanges you can query for trading pairs and data.
    """
    app = ctx.request_context.lifespan_context
    headers = _get_auth_headers()
    response = await app.http_client.get("/v1/referential", headers=headers)
    response.raise_for_status()
    data = response.json()
    # Extract and format exchanges from referential data
    exchanges = data.get("exchanges", [])
    count = len(exchanges)
    lines = [f"{count} exchanges available:", ""]
    for ex in exchanges:
        lines.append(f"- {ex['name']}")
    return "\n".join(lines)


def main():
    mcp.run()


if __name__ == "__main__":
    main()
```

### Entry Point Module
```python
# src/sunzulab_mcp/__main__.py
from sunzulab_mcp.server import main

main()
```

### pyproject.toml
```toml
[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[project]
name = "sunzulab-mcp"
version = "0.1.0"
description = "MCP server for SunzuLab crypto market data"
requires-python = ">=3.10"
dependencies = [
    "mcp[cli]>=1.20.0",
    "httpx>=0.28.0",
]

[project.scripts]
sunzulab-mcp = "sunzulab_mcp.server:main"

[tool.pytest.ini_options]
asyncio_mode = "auto"

[tool.hatch.build.targets.wheel]
packages = ["src/sunzulab_mcp"]
```

### Test Example
```python
# tests/test_server.py
# Source: FastMCP testing patterns
import pytest
from unittest.mock import AsyncMock, patch

from sunzulab_mcp.server import mcp


@pytest.fixture
async def mcp_client():
    from mcp.client import Client
    async with Client(transport=mcp) as client:
        yield client


async def test_list_exchanges(mcp_client):
    # Mock the httpx response
    mock_response = AsyncMock()
    mock_response.json.return_value = {
        "exchanges": [{"name": "Binance"}, {"name": "Coinbase"}]
    }
    mock_response.raise_for_status = lambda: None

    with patch.object(mcp_client, "call_tool") as mock_call:
        # ... test implementation
        pass
```

## State of the Art

| Old Approach | Current Approach | When Changed | Impact |
|--------------|------------------|--------------|--------|
| Custom JSON-RPC server | FastMCP decorators in official `mcp` SDK | 2024 (FastMCP 1.0 merged into SDK) | 90% less boilerplate |
| `aiohttp` for async HTTP | `httpx` with native async | 2023-2024 | Cleaner API, better typing |
| `setup.py` / `setuptools` | `pyproject.toml` + `hatchling` | 2023-2024 | Standard packaging, simpler config |
| `pip install` for MCP servers | `uvx` for ephemeral install | 2024-2025 | Zero-persistence install, always latest |
| FastMCP 1.0 (in SDK) for advanced features | Standalone FastMCP 2.0/3.0 | 2025-2026 | More features but diverged from spec |

**Deprecated/outdated:**
- `mcp.server.fastmcp` and standalone `fastmcp` are **not interchangeable** -- do not mix imports
- SSE transport is being superseded by Streamable HTTP in newer versions, but stdio remains standard for local servers

## Open Questions

1. **Gateway `/v1/referential` response shape**
   - What we know: Single endpoint returns exchanges, instruments, pairs, and data types
   - What's unclear: Exact JSON structure, field names, nesting
   - Recommendation: Need to inspect actual API response or OpenAPI spec to build formatters. Can stub with mock data initially.

2. **Gateway base URL for production vs staging**
   - What we know: Should be configurable via env var, defaults to production
   - What's unclear: Actual production URL
   - Recommendation: Use `SUNZU_API_URL` env var with sensible default. The team can fill in the real URL.

3. **Token website URL**
   - What we know: Error messages should include URL where users get their token
   - What's unclear: Exact URL path
   - Recommendation: Use placeholder like `https://app.sunzulab.com/settings/api` that can be updated.

## Validation Architecture

### Test Framework
| Property | Value |
|----------|-------|
| Framework | pytest + pytest-asyncio |
| Config file | `pyproject.toml` `[tool.pytest.ini_options]` |
| Quick run command | `uv run pytest tests/ -x -q` |
| Full suite command | `uv run pytest tests/ -v --tb=short` |

### Phase Requirements -> Test Map
| Req ID | Behavior | Test Type | Automated Command | File Exists? |
|--------|----------|-----------|-------------------|-------------|
| SETUP-01 | Server starts without errors | smoke | `uv run sunzulab-mcp --help` or import test | No -- Wave 0 |
| SETUP-02 | JSON config block works with uvx | manual | Manual verification in Claude Desktop | N/A -- manual |
| SETUP-03 | Auth header sent to gateway API | unit | `uv run pytest tests/test_client.py::test_auth_header -x` | No -- Wave 0 |
| SETUP-04 | Actionable error on auth failure | unit | `uv run pytest tests/test_client.py::test_auth_errors -x` | No -- Wave 0 |
| PROT-01 | stdio transport works | integration | `uv run pytest tests/test_server.py::test_server_starts -x` | No -- Wave 0 |
| PROT-02 | Tools have JSON Schema | unit | `uv run pytest tests/test_server.py::test_tool_schemas -x` | No -- Wave 0 |
| PROT-03 | Errors use isError=True | unit | `uv run pytest tests/test_server.py::test_error_responses -x` | No -- Wave 0 |
| PROT-04 | Works with standard MCP clients | manual | Manual verification in Claude Desktop + Cursor | N/A -- manual |
| DISC-01 | list_exchanges returns exchange list | unit | `uv run pytest tests/test_server.py::test_list_exchanges -x` | No -- Wave 0 |
| DISC-02 | list_pairs returns pairs for exchange | unit | `uv run pytest tests/test_server.py::test_list_pairs -x` | No -- Wave 0 |
| DISC-03 | list_data_types returns data types | unit | `uv run pytest tests/test_server.py::test_list_data_types -x` | No -- Wave 0 |

### Sampling Rate
- **Per task commit:** `uv run pytest tests/ -x -q`
- **Per wave merge:** `uv run pytest tests/ -v --tb=short`
- **Phase gate:** Full suite green before `/gsd:verify-work`

### Wave 0 Gaps
- [ ] `pyproject.toml` -- project file with pytest config and dependencies (does not exist yet)
- [ ] `tests/conftest.py` -- shared fixtures: mock API responses, MCP client wrapper
- [ ] `tests/test_server.py` -- tool integration tests
- [ ] `tests/test_client.py` -- API client unit tests
- [ ] `tests/test_formatting.py` -- response formatting tests
- [ ] Framework install: `uv add --dev pytest pytest-asyncio respx`

## Sources

### Primary (HIGH confidence)
- [Official MCP Python SDK](https://github.com/modelcontextprotocol/python-sdk) - server creation, tool definition, lifespan, Context injection, error handling
- [MCP Python SDK on PyPI](https://pypi.org/project/mcp/) - version 1.26.0, Python >=3.10, dependencies
- [httpx on PyPI](https://pypi.org/project/httpx/) - version 0.28.1, async client API
- [create-python-server template](https://github.com/modelcontextprotocol/create-python-server) - project structure, pyproject.toml patterns

### Secondary (MEDIUM confidence)
- [FastMCP Tools docs](https://gofastmcp.com/servers/tools) - tool definition, Context injection, error handling, return types (standalone FastMCP docs but patterns align with official SDK)
- [FastMCP Testing docs](https://gofastmcp.com/servers/testing) - in-memory testing with Client, pytest fixtures
- [MCP Error Handling Guide](https://mcpcat.io/guides/error-handling-custom-mcp-servers/) - isError pattern, layered error handling
- [MCP Unit Testing Guide](https://mcpcat.io/guides/writing-unit-tests-mcp-servers/) - pytest fixtures, mocking httpx
- [mcp-server-git on PyPI](https://pypi.org/project/mcp-server-git/) - real-world pyproject.toml and entry point patterns
- [FastMCP 2.0 vs SDK discussion](https://github.com/modelcontextprotocol/python-sdk/issues/1068) - official vs standalone package guidance

### Tertiary (LOW confidence)
- [Build MCP Servers tutorial](https://www.heyuan110.com/posts/ai/2026-03-05-build-mcp-server-python/) - pyproject.toml with hatchling example (community tutorial)
- [How to Convert Package to MCP](https://mer.vin/2025/12/how-to-convert-a-python-package-to-support-mcp-model-context-protocol/) - entry point patterns (community blog)

## Metadata

**Confidence breakdown:**
- Standard stack: HIGH - Official SDK version verified on PyPI, httpx version verified, patterns consistent across multiple official sources
- Architecture: HIGH - Project structure follows official template, lifespan/Context patterns from SDK README, entry point pattern from multiple real MCP servers
- Pitfalls: HIGH - stdio logging, async blocking, error handling patterns well-documented across official and community sources
- Testing: MEDIUM - Testing patterns from standalone FastMCP docs; official SDK testing guide is less detailed, but in-memory Client approach is confirmed

**Research date:** 2026-03-14
**Valid until:** 2026-04-14 (30 days -- stable ecosystem, official SDK unlikely to break)
