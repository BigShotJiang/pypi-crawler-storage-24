# Phase 1: Foundation & Discovery - Context

**Gathered:** 2026-03-14
**Status:** Ready for planning

<domain>
## Phase Boundary

Working MCP server installable via `uvx sunzulab-mcp`. Users authenticate with their existing JWT token, get clear error messages on auth failures, and can discover available exchanges, trading pairs, and data types through natural language. No data retrieval, alerts, or workflows — those are later phases.

</domain>

<decisions>
## Implementation Decisions

### Auth token handling
- Single env var `SUNZU_API_TOKEN` — no config files, no interactive prompts
- Token is passed as Bearer header to the SunzuLab gateway API on every request
- Error messages must be actionable and non-technical:
  - Missing token: "No API token found. Set SUNZU_API_TOKEN in your MCP client config. Get your token at [website URL]."
  - Invalid/expired token: "Your API token is invalid or expired. Get a new one at [website URL]."
  - Insufficient permissions: "Your account doesn't have access to [resource]. Contact support."
- Token validation happens on first tool call (lazy), not at server startup — avoids breaking the MCP connection on transient issues

### Discovery tool design
- Three separate tools, not one combined tool:
  - `list_exchanges` — returns available exchanges (no parameters)
  - `list_pairs` — returns trading pairs, with required `exchange` parameter to filter
  - `list_data_types` — returns available data types (OHLCV, trades, order book, indicators)
- Separate tools match how users think: "what exchanges?" then "what pairs on Binance?"
- LLMs select specific tools better than parsing multi-purpose tool parameters
- Under the hood, all three hit the `/v1/referential` endpoint and extract the relevant slice

### Response formatting
- Compact plain text, never raw JSON
- Short lists rendered as bullet points
- Longer lists (pairs) rendered as a compact comma-separated list grouped by category
- Always include counts: "12 exchanges available", "47 pairs on Binance"
- Token-efficient: minimize tokens consumed by tool responses so the LLM has room for reasoning

### Package & install UX
- Package name: `sunzulab-mcp` (PyPI)
- Entry point command: `sunzulab-mcp`
- Zero-code setup: user copies a JSON config block and pastes it into their LLM client
- Config block shape (Claude Desktop / Cursor):
  ```json
  {
    "mcpServers": {
      "sunzulab": {
        "command": "uvx",
        "args": ["sunzulab-mcp"],
        "env": {
          "SUNZU_API_TOKEN": "paste-your-token-here"
        }
      }
    }
  }
  ```
- Website should ideally generate this config with the user's token pre-filled so it's a single copy-paste
- stdio transport (standard MCP) — no HTTP server, no ports, no networking config

### Claude's Discretion
- Project structure and module layout
- HTTP client choice (httpx, aiohttp, etc.)
- Caching strategy for referential data (if any)
- Exact error message wording beyond the intent above
- Test framework and test structure

</decisions>

<specifics>
## Specific Ideas

- "People who will be using this aren't necessarily proficient in coding. They need to be able to use this as easily as possible, even from web interfaces, with the lowest amount of config."
- Users should be able to copy-paste config + API key from the SunzuLab website and pass it to their favorite LLM client — that's the entire setup.
- The north star is friction-free onboarding for non-technical users.

</specifics>

<code_context>
## Existing Code Insights

### Reusable Assets
- Gateway referential endpoint (`/v1/referential`): Returns all exchanges, instruments, pairs, and data types in a single call — MCP discovery tools extract slices from this
- Gateway auth model: JWT with scopes and coverage-based access control — MCP server just forwards the token as a Bearer header

### Established Patterns
- Gateway uses FastAPI + Pydantic schemas — MCP server is a separate project but calls the same API
- Auth scopes control endpoint access (e.g., `referential`, `historical`) — MCP token needs at minimum the `referential` scope for Phase 1

### Integration Points
- MCP server calls the SunzuLab gateway REST API (not the database directly)
- Gateway base URL needs to be configurable (env var or default to production)
- Auth: forward `SUNZU_API_TOKEN` as `Authorization: Bearer {token}` header

</code_context>

<deferred>
## Deferred Ideas

None — discussion stayed within phase scope

</deferred>

---

*Phase: 01-foundation-discovery*
*Context gathered: 2026-03-14*
