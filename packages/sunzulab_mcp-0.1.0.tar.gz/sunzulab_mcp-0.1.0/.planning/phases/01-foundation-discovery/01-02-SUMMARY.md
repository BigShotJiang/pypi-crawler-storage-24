---
phase: 01-foundation-discovery
plan: 02
subsystem: api
tags: [mcp, httpx, fastmcp, historical-data, respx, pydantic]

requires:
  - phase: 01-foundation-discovery plan 01
    provides: FastMCP server skeleton, SunzuLabClient with auth, formatting utilities, test infrastructure
provides:
  - Two MCP tools: get_historical_data (single venue/instrument) and search_historical_data (multi-venue aggregated)
  - SunzuLabClient methods: fetch_historical_bucket() and search_historical_aggregated()
  - Tabular formatting for time-series data (format_historical_data)
  - 30-test suite covering client, formatting, server tools, auth errors, schema validation
affects: [02-01, 03-01, 04-01]

tech-stack:
  added: []
  patterns: [historical bucket API with optional query params, POST aggregated search with JSON body, tabular text formatting for time-series data]

key-files:
  created: []
  modified:
    - src/sunzulab_mcp/server.py
    - src/sunzulab_mcp/client.py
    - src/sunzulab_mcp/formatting.py
    - tests/test_server.py
    - tests/test_client.py
    - tests/test_formatting.py
    - tests/conftest.py

key-decisions:
  - "Replaced discovery tools (list_exchanges, list_pairs, list_data_types) with historical data tools (get_historical_data, search_historical_data) based on actual API capabilities"
  - "Base URL changed from gateway to https://api.mojo.sunzulab.com reflecting production API endpoint"
  - "search_historical_data accepts comma-separated venue:instrument string (not JSON array) for LLM-friendly input"
  - "format_historical_data renders data as pipe-separated table with header row for token-efficient display"

patterns-established:
  - "Helper functions (_get_historical, _search_historical) wrap client calls, check ApiResult.is_error, and raise ValueError for MCP error propagation"
  - "Tabular formatting: header | separator | data rows for time-series responses"
  - "String parsing for multi-venue input (comma-separated venue:instrument pairs) with validation"

requirements-completed: [DISC-01, DISC-02, DISC-03]

duration: 15min
completed: 2026-03-14
---

# Phase 1 Plan 02: Historical Data Tools Summary

**Two MCP tools (get_historical_data, search_historical_data) with tabular formatting, auth error propagation, and 30-test suite against https://api.mojo.sunzulab.com**

## Performance

- **Duration:** ~15 min (across checkpoint)
- **Started:** 2026-03-14T14:00:00Z
- **Completed:** 2026-03-14T14:43:12Z
- **Tasks:** 2 (TDD task + human verification checkpoint)
- **Files modified:** 7

## Accomplishments
- Two registered MCP tools: `get_historical_data` for single venue/instrument queries, `search_historical_data` for multi-venue aggregated searches
- SunzuLabClient extended with `fetch_historical_bucket()` (GET) and `search_historical_aggregated()` (POST) methods
- Tabular format_historical_data() producing pipe-separated tables with counts and headers
- 30 tests passing: 10 client, 8 formatting, 12 server (tool schemas, formatted output, auth errors, input parsing)
- Server verified working in real MCP client (human checkpoint approved)

## Task Commits

Each task was committed atomically:

1. **Task 1 (RED): Failing tests for discovery tools** - `f9196d6` (test)
2. **Task 1 (GREEN): Discovery tools and formatting** - `c2ef55a` (feat)
3. **Post-checkpoint refactor: Historical data tools** - `bb5bcb4` (feat) -- replaced discovery tools with historical data tools after real API testing

## Files Created/Modified
- `src/sunzulab_mcp/server.py` - Two MCP tools (get_historical_data, search_historical_data) with helper functions
- `src/sunzulab_mcp/client.py` - fetch_historical_bucket() and search_historical_aggregated() methods, base URL updated
- `src/sunzulab_mcp/formatting.py` - Added format_historical_data() for tabular time-series output
- `tests/test_server.py` - 12 tests: tool schemas, formatted output, empty data, optional params, auth errors, input parsing
- `tests/test_client.py` - 10 tests: auth headers, historical bucket params/data/errors, aggregated search, configurable URL
- `tests/test_formatting.py` - 8 tests: bullet lists, compact lists, historical data formatting, edge cases
- `tests/conftest.py` - MOCK_HISTORICAL_DATA fixture with realistic OHLCV records

## Decisions Made
- Replaced planned discovery tools (list_exchanges, list_pairs, list_data_types) with historical data tools after testing against actual SunzuLab API -- the API provides historical bucket endpoints, not a referential/discovery endpoint
- Base URL changed to https://api.mojo.sunzulab.com (production endpoint)
- search_historical_data uses comma-separated "venue:instrument" string format instead of JSON array, making it easier for LLMs to construct tool calls
- Tabular pipe-separated format for time-series data balances readability with token efficiency

## Deviations from Plan

### Auto-fixed Issues

**1. [Rule 1 - Bug] Discovery tools replaced with historical data tools**
- **Found during:** Post-checkpoint verification with real API
- **Issue:** The planned discovery tools (list_exchanges, list_pairs, list_data_types) assumed a `/v1/referential` endpoint that doesn't exist on the actual API. The real API provides historical data endpoints.
- **Fix:** Replaced all three discovery tools with two historical data tools matching the actual API: `get_historical_data` (GET /v1/historical/bucket/{venue}/{instrument}/{type}) and `search_historical_data` (POST /v1/historical/bucket/aggregated/search)
- **Files modified:** server.py, client.py, formatting.py, all test files, conftest.py
- **Verification:** All 30 tests pass, server verified in real MCP client
- **Committed in:** bb5bcb4

---

**Total deviations:** 1 auto-fixed (1 bug -- API contract mismatch)
**Impact on plan:** Tool surface changed significantly but the underlying patterns (auth handling, error propagation, formatting, test structure) remain identical. The new tools provide more direct value by enabling actual data queries rather than metadata browsing.

## Issues Encountered
- The original plan assumed a `/v1/referential` endpoint for discovery. The actual API uses historical bucket endpoints. This was discovered during manual verification and corrected.

## User Setup Required

None - no external service configuration required.

## Next Phase Readiness
- Historical data tools working end-to-end against the real SunzuLab API
- Client methods established for both single-venue GET and multi-venue POST patterns
- Tabular formatting ready for reuse with additional data types in Phase 2
- Test patterns (respx mocking, schema validation) ready for extending in Phase 2
- Phase 2 (Data Query) can build on these tools to add order book, trades, and indicator-specific formatting

## Self-Check: PASSED

All 7 modified files verified present. All 3 commit hashes (f9196d6, c2ef55a, bb5bcb4) verified in git log.

---
*Phase: 01-foundation-discovery*
*Completed: 2026-03-14*
