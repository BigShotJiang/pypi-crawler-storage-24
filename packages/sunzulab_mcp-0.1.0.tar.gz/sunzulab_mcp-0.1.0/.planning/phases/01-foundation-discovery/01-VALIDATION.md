---
phase: 1
slug: foundation-discovery
status: draft
nyquist_compliant: false
wave_0_complete: false
created: 2026-03-14
---

# Phase 1 — Validation Strategy

> Per-phase validation contract for feedback sampling during execution.

---

## Test Infrastructure

| Property | Value |
|----------|-------|
| **Framework** | pytest 7.x + pytest-asyncio |
| **Config file** | `pyproject.toml` `[tool.pytest.ini_options]` |
| **Quick run command** | `uv run pytest tests/ -x -q` |
| **Full suite command** | `uv run pytest tests/ -v --tb=short` |
| **Estimated runtime** | ~5 seconds |

---

## Sampling Rate

- **After every task commit:** Run `uv run pytest tests/ -x -q`
- **After every plan wave:** Run `uv run pytest tests/ -v --tb=short`
- **Before `/gsd:verify-work`:** Full suite must be green
- **Max feedback latency:** 5 seconds

---

## Per-Task Verification Map

| Task ID | Plan | Wave | Requirement | Test Type | Automated Command | File Exists | Status |
|---------|------|------|-------------|-----------|-------------------|-------------|--------|
| 01-01-01 | 01 | 0 | SETUP-01 | smoke | `uv run sunzulab-mcp --help` | No -- Wave 0 | pending |
| 01-01-02 | 01 | 1 | SETUP-03 | unit | `uv run pytest tests/test_client.py::test_auth_header -x` | No -- Wave 0 | pending |
| 01-01-03 | 01 | 1 | SETUP-04 | unit | `uv run pytest tests/test_client.py::test_auth_errors -x` | No -- Wave 0 | pending |
| 01-01-04 | 01 | 1 | PROT-01 | integration | `uv run pytest tests/test_server.py::test_server_starts -x` | No -- Wave 0 | pending |
| 01-01-05 | 01 | 1 | PROT-02 | unit | `uv run pytest tests/test_server.py::test_tool_schemas -x` | No -- Wave 0 | pending |
| 01-01-06 | 01 | 1 | PROT-03 | unit | `uv run pytest tests/test_server.py::test_error_responses -x` | No -- Wave 0 | pending |
| 01-02-01 | 02 | 1 | DISC-01 | unit | `uv run pytest tests/test_server.py::test_list_exchanges -x` | No -- Wave 0 | pending |
| 01-02-02 | 02 | 1 | DISC-02 | unit | `uv run pytest tests/test_server.py::test_list_pairs -x` | No -- Wave 0 | pending |
| 01-02-03 | 02 | 1 | DISC-03 | unit | `uv run pytest tests/test_server.py::test_list_data_types -x` | No -- Wave 0 | pending |
| 01-M-01 | -- | -- | SETUP-02 | manual | Manual verification in Claude Desktop | N/A | pending |
| 01-M-02 | -- | -- | PROT-04 | manual | Manual verification in Claude Desktop + Cursor | N/A | pending |

*Status: pending / green / red / flaky*

---

## Wave 0 Requirements

- [ ] `pyproject.toml` -- project file with pytest config and dependencies
- [ ] `tests/conftest.py` -- shared fixtures: mock API responses, MCP client wrapper
- [ ] `tests/test_server.py` -- tool integration test stubs
- [ ] `tests/test_client.py` -- API client unit test stubs
- [ ] Framework install: `uv add --dev pytest pytest-asyncio respx`

---

## Manual-Only Verifications

| Behavior | Requirement | Why Manual | Test Instructions |
|----------|-------------|------------|-------------------|
| JSON config block works with uvx | SETUP-02 | Requires real LLM client (Claude Desktop) | 1. Add config to claude_desktop_config.json 2. Set SUNZU_API_TOKEN 3. Restart Claude Desktop 4. Verify server connects |
| Works with standard MCP clients | PROT-04 | Requires real LLM clients | 1. Test in Claude Desktop 2. Test in Cursor 3. Verify tools appear and respond |

---

## Validation Sign-Off

- [ ] All tasks have automated verify or Wave 0 dependencies
- [ ] Sampling continuity: no 3 consecutive tasks without automated verify
- [ ] Wave 0 covers all MISSING references
- [ ] No watch-mode flags
- [ ] Feedback latency < 5s
- [ ] `nyquist_compliant: true` set in frontmatter

**Approval:** pending
