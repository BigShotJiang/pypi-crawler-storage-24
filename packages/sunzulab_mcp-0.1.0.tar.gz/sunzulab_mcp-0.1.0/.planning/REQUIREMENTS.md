# Requirements: SunzuLab MCP Server

**Defined:** 2026-03-14
**Core Value:** Clients can ask natural-language questions about crypto market data and get accurate answers backed by SunzuLab's real data, without needing to know the API or write code.

## v1 Requirements

Requirements for initial release. Each maps to roadmap phases.

### Setup & Authentication

- [x] **SETUP-01**: Server installs and runs via `uvx sunzulab-mcp` with no prior setup beyond `uv`
- [x] **SETUP-02**: Client configures server by pasting JSON config into LLM client and setting `SUNZU_API_TOKEN` env var
- [x] **SETUP-03**: Server authenticates to SunzuLab API using client's OAuth/JWT token from env var
- [x] **SETUP-04**: Server returns clear, actionable error messages for auth failures (invalid, expired, insufficient permissions)

### Discovery

- [x] **DISC-01**: User can list available exchanges
- [x] **DISC-02**: User can list available trading pairs for a given exchange
- [x] **DISC-03**: User can list available data types (OHLCV, trades, order book, indicators)
- [ ] **DISC-04**: Server exposes MCP Resources for browsable metadata catalogs (exchanges, pairs, data types)
- [ ] **DISC-05**: Tool descriptions include "when to use" and "chain with" guidance for LLM reasoning

### Data Query

- [ ] **DATA-01**: User can retrieve historical OHLCV data for a given exchange, pair, and time range
- [ ] **DATA-02**: User can retrieve historical trade data for a given exchange, pair, and time range
- [ ] **DATA-03**: User can retrieve order book snapshots for a given exchange and pair
- [ ] **DATA-04**: User can retrieve indicator data for a given exchange, pair, and indicator type
- [ ] **DATA-05**: Data tools return token-efficient formatted responses (compact tables, not verbose JSON)
- [ ] **DATA-06**: Large result sets are auto-paginated with summary statistics (count, avg, min, max)

### Alert Management

- [ ] **ALRT-01**: User can create alerts with price or indicator thresholds via natural language
- [ ] **ALRT-02**: User can list their active alerts
- [ ] **ALRT-03**: User can delete or modify existing alerts

### Guided Workflows

- [ ] **FLOW-01**: Server provides pre-built MCP Prompts for common analysis workflows (market overview, liquidity analysis, exchange comparison)

### Protocol Compliance

- [x] **PROT-01**: Server implements MCP protocol over stdio transport
- [x] **PROT-02**: All tools expose JSON Schema input validation
- [x] **PROT-03**: Errors return structured responses with `isError: true` and human-readable messages
- [x] **PROT-04**: Server works with Claude Desktop, Cursor, and any standard MCP client

## v2 Requirements

Deferred to future release. Tracked but not in current roadmap.

### Live Data

- **LIVE-01**: User can get real-time market snapshots via websocket (connect, capture N messages, return)
- **LIVE-02**: User receives alert notifications pushed through MCP server when alerts trigger

### Account Management

- **ACCT-01**: User can view their account info (subscription, plan)
- **ACCT-02**: User can view API usage and remaining quota

### Guided Workflows

- **FLOW-02**: Server provides onboarding prompt (`/getting-started`) that walks new users through first queries

### Advanced Features

- **ADV-01**: Tools return structured output schemas for programmatic consumption
- **ADV-02**: MCP Resource templates for parameterized discovery (e.g., `sunzu://orderbook/{exchange}/{pair}`)

## Out of Scope

| Feature | Reason |
|---------|--------|
| Persistent websocket connections | LLMs can't hold stateful connections; use snapshot + alert pattern |
| Custom analytics/transformations | API already provides indicators; LLM can synthesize returned data |
| Dashboard or visualization | MCP servers are protocol endpoints, not UIs |
| Multi-user auth | Client-side deployment = one user per instance |
| Caching layer | API responses are time-sensitive; stale cache = wrong data for traders |
| Hosted/remote MCP server | Client-side only for v1; credentials stay local |
| TypeScript implementation | Python with official MCP SDK; `uvx` provides `npx` equivalent |
| Runtime OpenAPI-to-MCP generation | Adds startup latency and error surface; use spec as dev reference |

## Traceability

Which phases cover which requirements. Updated during roadmap creation.

| Requirement | Phase | Status |
|-------------|-------|--------|
| SETUP-01 | Phase 1 | Complete |
| SETUP-02 | Phase 1 | Complete |
| SETUP-03 | Phase 1 | Complete |
| SETUP-04 | Phase 1 | Complete |
| DISC-01 | Phase 1 | Complete |
| DISC-02 | Phase 1 | Complete |
| DISC-03 | Phase 1 | Complete |
| DISC-04 | Phase 4 | Pending |
| DISC-05 | Phase 4 | Pending |
| DATA-01 | Phase 2 | Pending |
| DATA-02 | Phase 2 | Pending |
| DATA-03 | Phase 2 | Pending |
| DATA-04 | Phase 2 | Pending |
| DATA-05 | Phase 2 | Pending |
| DATA-06 | Phase 2 | Pending |
| ALRT-01 | Phase 3 | Pending |
| ALRT-02 | Phase 3 | Pending |
| ALRT-03 | Phase 3 | Pending |
| FLOW-01 | Phase 4 | Pending |
| PROT-01 | Phase 1 | Complete |
| PROT-02 | Phase 1 | Complete |
| PROT-03 | Phase 1 | Complete |
| PROT-04 | Phase 1 | Complete |

**Coverage:**
- v1 requirements: 23 total
- Mapped to phases: 23
- Unmapped: 0

---
*Requirements defined: 2026-03-14*
*Last updated: 2026-03-14 after plan 01-01 execution*
