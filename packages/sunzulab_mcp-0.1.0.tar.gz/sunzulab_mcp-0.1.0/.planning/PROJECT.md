# SunzuLab MCP Server

## What This Is

A Python MCP (Model Context Protocol) server that lets SunzuLab clients interact with high-frequency crypto market data through LLMs. Clients install the server locally via `uvx sunzulab-mcp`, configure their API token, and use any MCP-compatible LLM client (Claude Desktop, Cursor, etc.) to query historical data, monitor live streams, manage alerts, and control their account — all through natural language.

## Core Value

Clients can ask natural-language questions about crypto market data and get accurate answers backed by SunzuLab's real data, without needing to know the API or write code.

## Requirements

### Validated

<!-- Shipped and confirmed valuable. -->

(None yet — ship to validate)

### Active

<!-- Current scope. Building toward these. -->

- [ ] Client can query historical market data (OHLCV, trades, order books, indicators) via natural language
- [ ] Client can discover available exchanges, pairs, and data types
- [ ] Client can get real-time market snapshots (latest N messages from a live stream)
- [ ] Client can set up and manage alerts (price, indicator thresholds)
- [ ] Client can receive alert notifications through the MCP server
- [ ] Client can view and manage their SunzuLab account
- [ ] MCP tools are derived from the existing OpenAPI spec (10-30 REST endpoints)
- [ ] Server authenticates to SunzuLab API via client's OAuth/JWT token
- [ ] Server distributable as PyPI package, installable via `uvx sunzulab-mcp`
- [ ] Works with Claude Desktop, Cursor/IDEs, and any standard MCP client

### Out of Scope

- Hosted/remote MCP server — client-side only for v1
- TypeScript implementation — Python with official MCP SDK
- Persistent websocket connections held by the LLM — use snapshot + alert pattern instead
- Dashboard or UI — this is a protocol server, not a visual tool
- Data transformation or custom analytics beyond what the API provides

## Context

SunzuLab specializes in collecting high-frequency data on centralized crypto markets, augmenting it, and redistributing it to clients via API, dashboards, and ad-hoc analysis. The existing REST API has 10-30 endpoints covering historical data, live streams (topic-based websockets), alerts, and account management. Clients authenticate via OAuth/JWT. An OpenAPI spec exists for the API.

Clients range in technical ability — many are not developers. The MCP server needs a zero-code installation path: paste a JSON config into Claude Desktop, set a token env var, done.

The LLM interaction with live data uses two patterns:
- **Snapshot mode**: MCP tool connects to websocket, captures latest N messages, returns them to the LLM for analysis
- **Alert-driven**: LLM sets up alerts via the API, MCP server delivers notifications when triggered

Vague queries like "describe the liquidity depth for BTC on the 3 biggest exchanges" require the LLM to chain multiple tool calls — discover exchanges, rank by volume, pull order book data, synthesize.

## Constraints

- **Tech stack**: Python, official MCP Python SDK
- **Distribution**: PyPI package, `uvx` compatible
- **Auth**: Must use client's existing OAuth/JWT token — no separate auth system
- **API surface**: Tools map to existing REST API — no new backend endpoints
- **Compatibility**: Must work with standard MCP protocol (stdio transport)

## Key Decisions

| Decision | Rationale | Outcome |
|----------|-----------|---------|
| Python over TypeScript | Directory structure, team expertise, `uvx` provides equivalent of `npx` | -- Pending |
| Client-side deployment | Client credentials stay local, simpler infra, standard MCP pattern | -- Pending |
| Snapshot + alert for live data | LLMs can't hold persistent connections; snapshots for ad-hoc, alerts for ongoing | -- Pending |
| OpenAPI-driven tool generation | 10-30 endpoints can be mapped to MCP tools systematically from existing spec | -- Pending |

---
*Last updated: 2026-03-14 after initialization*
