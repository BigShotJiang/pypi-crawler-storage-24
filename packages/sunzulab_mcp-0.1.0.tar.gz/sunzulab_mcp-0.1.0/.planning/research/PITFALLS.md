# Domain Pitfalls

**Domain:** Python MCP server wrapping crypto market data REST API
**Researched:** 2026-03-14
**Confidence:** MEDIUM (based on MCP SDK documentation patterns, Python packaging expertise, and crypto API domain knowledge; web search unavailable for cross-validation)

## Critical Pitfalls

Mistakes that cause rewrites, broken installations, or unusable servers.

### Pitfall 1: stdout Pollution Kills the MCP Connection

**What goes wrong:** MCP over stdio uses stdout as the protocol transport. Any print statement, logging to stdout, or library that writes to stdout (e.g., `requests` debug logging, `print()` debug statements, warnings from imported packages) corrupts the JSON-RPC message stream. The client silently disconnects or throws cryptic parse errors.

**Why it happens:** Developers test with `python server.py` and see print output working fine. But when Claude Desktop launches the server as a subprocess, stdout is the protocol channel, not a console. This is the single most common MCP server bug.

**Consequences:** Server appears to start but tools never appear in the client. Or tools work intermittently. Extremely hard to debug because the error is invisible -- the corrupted bytes are consumed by the client's JSON parser.

**Prevention:**
- Configure ALL logging to stderr: `logging.basicConfig(stream=sys.stderr)`
- Never use `print()` anywhere in the codebase -- use `logging.debug()` routed to stderr
- Set `PYTHONUNBUFFERED=1` in the recommended Claude Desktop config
- Suppress warnings from third-party libraries: `warnings.filterwarnings` or redirect warnings to stderr
- Add a CI check that greps for `print(` in source files (excluding tests)

**Detection:** Server starts but client shows "0 tools available" or connection drops after handshake.

**Phase:** Must be correct from Phase 1 (core server setup). Add lint rule immediately.

---

### Pitfall 2: Tool Descriptions That Confuse the LLM

**What goes wrong:** MCP tool descriptions are the LLM's only guide for deciding which tool to call and how to structure arguments. Vague, overly technical, or missing descriptions cause the LLM to pick wrong tools, pass wrong parameters, or fail to chain tools for complex queries like "describe liquidity depth for BTC on the 3 biggest exchanges."

**Why it happens:** Developers write tool descriptions like API docs (for developers) rather than instructions (for an LLM). They assume the LLM understands the domain schema, abbreviations, or implicit parameter relationships.

**Consequences:** The product feels broken -- users ask natural-language questions and get wrong answers or errors. This is the difference between a demo and a product.

**Prevention:**
- Write descriptions as if explaining to a smart assistant who has never seen the API before
- Include: what the tool returns, when to use it vs. similar tools, parameter constraints (valid values, formats, ranges)
- For enum parameters, list all valid values in the description
- Add "use this tool when..." and "do NOT use this tool when..." guidance
- Test with actual LLM queries before shipping: ask the vague questions from PROJECT.md and see if the LLM chains tools correctly
- Include example parameter values in descriptions

**Detection:** Users report the LLM "doesn't understand" their questions, picks wrong tools, or asks for parameters the user doesn't know.

**Phase:** Phase 1 (tool definition), but requires iteration throughout. Budget time for prompt-engineering tool descriptions after initial implementation.

---

### Pitfall 3: Websocket Snapshot That Hangs or Times Out

**What goes wrong:** The snapshot pattern (connect to websocket, grab N messages, disconnect) sounds simple but has multiple failure modes: the websocket connection hangs during TLS handshake, the topic has no messages (empty stream), the first N messages take 30+ seconds on low-volume pairs, or the connection isn't cleanly closed and leaks resources across repeated calls.

**Why it happens:** Websocket behavior varies dramatically by exchange pair volume. BTC/USDT on Binance sends hundreds of messages per second; an obscure altcoin pair might send one message per minute. The "grab N messages" pattern assumes a steady stream.

**Consequences:** Tool call hangs, Claude Desktop shows a spinner for 60+ seconds, users think the server is broken. Worse: leaked connections accumulate and the server becomes unresponsive.

**Prevention:**
- Always use a timeout (5-10 seconds max) with `asyncio.wait_for()`
- Return partial results if timeout fires: "received 3 of 10 requested messages in 5s"
- Use `async with` for websocket connections to guarantee cleanup
- Consider a minimum-messages-OR-timeout pattern: return after N messages or T seconds, whichever comes first
- Document to users that low-volume pairs may return fewer messages
- Add connection pooling only if profiling shows connection setup is a bottleneck (don't premature-optimize)

**Detection:** Tool calls for obscure pairs take >10 seconds. Server memory grows over time (leaked connections).

**Phase:** Phase 2 (live data tools). Must be designed correctly from the start -- retrofitting timeouts into working websocket code is error-prone.

---

### Pitfall 4: `uvx` Installation Fails for Non-Technical Users

**What goes wrong:** The distribution path is `uvx sunzulab-mcp`, but `uvx` (from `uv`) may not be installed on the user's machine. Users who aren't Python developers don't have `uv`, `pip`, or even Python installed. The zero-code promise breaks at step one.

**Why it happens:** The MCP ecosystem assumes a developer audience. SunzuLab's audience includes non-technical clients. The gap between "paste JSON config into Claude Desktop" and "first install uv, then..." is enormous for these users.

**Consequences:** Support tickets. Users can't onboard. The entire value proposition fails.

**Prevention:**
- Provide OS-specific installation instructions: a single copy-paste command that installs `uv` + runs `uvx sunzulab-mcp`
- Test installation on a clean macOS, Windows, and Linux machine (not a dev machine)
- Consider providing a standalone installer script or a Homebrew formula as alternatives
- Include a "troubleshooting installation" section in the Claude Desktop config documentation
- Pin the Python version requirement explicitly in `pyproject.toml` (`requires-python = ">=3.10"`)
- Test that `uvx sunzulab-mcp` works after a fresh `uv` install (dependency resolution can fail if the package has complex native dependencies)

**Detection:** Users report "command not found" or dependency resolution errors. Support volume spikes after release.

**Phase:** Phase 1 (packaging/distribution), but validate with real non-technical users in Phase 3 (integration testing).

---

### Pitfall 5: Token/Auth Errors Return Cryptic Messages

**What goes wrong:** When the OAuth/JWT token is missing, expired, or invalid, the REST API returns a 401/403. The MCP server passes this through as a raw error or a generic "request failed" message. The LLM then tells the user something unhelpful like "I encountered an error calling the tool."

**Why it happens:** Developers handle the happy path first and treat auth errors as edge cases. But for real users, auth errors are the FIRST thing they encounter (misconfigured token, expired token, wrong env var name).

**Consequences:** Users think the server is broken when it's actually a configuration issue. They can't self-diagnose.

**Prevention:**
- Validate the token at server startup (make a lightweight API call like "get account info")
- If the token env var is missing, fail immediately with a clear message to stderr: "SUNZULAB_TOKEN environment variable not set. See [setup docs URL]"
- If the token is invalid/expired, return a tool result that says: "Authentication failed. Your API token may be expired. Regenerate it at [URL]"
- Never expose the raw token value in error messages or logs
- Distinguish between "no token" (config error), "invalid token" (wrong token), and "expired token" (needs refresh) in error messages

**Detection:** Users report "tools don't work" but the server is actually running fine -- it's just failing auth on every API call.

**Phase:** Phase 1 (auth setup). Token validation at startup is a day-one requirement.

## Moderate Pitfalls

### Pitfall 6: Too Many Tools Overwhelm the LLM's Tool Selection

**What goes wrong:** Mapping all 10-30 REST endpoints 1:1 to MCP tools creates a tool list so large that the LLM struggles to pick the right one. Tool selection accuracy degrades significantly above ~15 tools. The LLM may also hit context limits just reading tool descriptions.

**Why it happens:** The OpenAPI-driven generation approach naturally produces one tool per endpoint. It feels complete and systematic. But the LLM is not a developer reading API docs -- it needs a curated, purposeful tool set.

**Prevention:**
- Group related endpoints into fewer, smarter tools (e.g., one `query_market_data` tool with a `data_type` parameter instead of separate `get_ohlcv`, `get_trades`, `get_orderbook` tools)
- Prioritize the 8-12 most valuable tools for v1; add more only if users request them
- Use the tool description to guide the LLM toward the right tool; fewer tools = less ambiguity
- Consider a "discovery" tool that lists available data types/exchanges so the LLM can narrow down before calling specific tools

**Detection:** LLM frequently picks wrong tools or asks the user to clarify which tool to use when it should be obvious.

**Phase:** Phase 1 (tool design). This is an architectural decision that's expensive to change later.

---

### Pitfall 7: Large API Responses Blow Up LLM Context

**What goes wrong:** Crypto market data queries can return massive payloads -- thousands of OHLCV candles, full order books with hundreds of levels, or trade histories with thousands of entries. The MCP server returns the full response, which consumes the LLM's context window and may exceed tool response size limits.

**Why it happens:** The API is designed for programmatic consumers who process data in bulk. LLMs need summarized, human-scale responses.

**Consequences:** LLM context exhaustion, truncated responses, degraded conversation quality, or outright errors. Users pay more for LLM tokens on data they didn't need.

**Prevention:**
- Set sensible default limits on all data-returning tools (e.g., max 100 candles, top 20 order book levels, last 50 trades)
- Let the LLM override defaults with explicit parameters, but cap at a hard maximum
- For large datasets, return summary statistics (min, max, mean, latest) plus a truncated sample
- Include metadata in responses: "showing 100 of 5,432 available candles for this range"
- Never return raw JSON arrays -- structure responses with clear labels

**Detection:** LLM responses become slow, truncated, or the LLM says "the data is too large to analyze."

**Phase:** Phase 2 (data tools). Design response formatting conventions early.

---

### Pitfall 8: No Structured Error Handling Across Tools

**What goes wrong:** Each tool handles errors differently -- some raise exceptions, some return error strings, some return empty results. The LLM can't distinguish between "no data exists" and "the request failed."

**Why it happens:** Tools are developed incrementally without a shared error convention. The first few tools work fine; inconsistency appears as the tool count grows.

**Prevention:**
- Define a standard tool response format from day one: `{"success": bool, "data": ..., "error": str | null, "metadata": {...}}`
- Map API HTTP status codes to user-friendly messages consistently
- Return `{"success": true, "data": [], "metadata": {"message": "No trades found for this pair in the specified time range"}}` instead of raising an exception or returning an empty string
- Create a shared error-handling wrapper that all tools use

**Detection:** LLM gives inconsistent explanations for failures across different tools.

**Phase:** Phase 1 (tool framework). Establish the convention before building individual tools.

---

### Pitfall 9: Ignoring MCP Protocol Versioning and Client Differences

**What goes wrong:** The MCP protocol is evolving rapidly. Server built against one version of the spec may break with client updates. Different clients (Claude Desktop, Cursor, Continue) may support different protocol features or have different quirks.

**Why it happens:** Developers test against one client (usually Claude Desktop) and assume compatibility. The MCP spec is pre-1.0 and changes between versions.

**Prevention:**
- Pin the MCP Python SDK version in `pyproject.toml` with a compatible release specifier (e.g., `mcp>=1.0,<2.0`)
- Test against at least Claude Desktop and one IDE client (Cursor)
- Follow the MCP SDK changelog for breaking changes
- Don't use undocumented or experimental protocol features
- Implement graceful degradation: if a client doesn't support a feature, the server should still work (just without that feature)

**Detection:** Server works in Claude Desktop but fails in Cursor, or vice versa. Server breaks after a client update.

**Phase:** Phase 3 (multi-client testing). But pin SDK version from Phase 1.

## Minor Pitfalls

### Pitfall 10: Blocking Async Event Loop with Synchronous HTTP Calls

**What goes wrong:** The MCP Python SDK is async (built on `anyio`/`asyncio`). Using synchronous HTTP libraries like `requests` blocks the event loop, causing the server to freeze during API calls. This manifests as the server becoming unresponsive to subsequent tool calls while one is in progress.

**Prevention:**
- Use `httpx.AsyncClient` (not `requests`) for all API calls
- Use an async websocket library (`websockets` or `httpx-ws`) for snapshot connections
- Never call `time.sleep()` -- use `asyncio.sleep()`
- Run `asyncio` in strict mode during development to catch accidental blocking calls

**Detection:** Server handles one tool call at a time; concurrent requests queue up.

**Phase:** Phase 1. Choose async HTTP client from the start.

---

### Pitfall 11: Hardcoded API Base URL

**What goes wrong:** The SunzuLab API base URL is hardcoded. When the API moves to a new domain, adds a staging environment, or the server needs testing against a local mock, every user must update the server code.

**Prevention:**
- Accept an optional `SUNZULAB_API_URL` env var with a sensible production default
- Document it as an advanced/debug option, not something normal users need to set

**Detection:** Can't test the server against a local mock API.

**Phase:** Phase 1. Trivial to implement, painful to add later.

---

### Pitfall 12: Missing Rate Limiting Awareness

**What goes wrong:** LLMs can chain rapid tool calls (e.g., querying 10 exchanges in a loop). Without awareness of API rate limits, the server hits 429 errors and returns confusing failures mid-chain.

**Prevention:**
- Read rate limit headers from API responses (`X-RateLimit-Remaining`, `Retry-After`)
- When approaching limits, include a warning in the tool response: "Rate limit: 5 of 100 requests remaining this minute"
- On 429, wait and retry once with backoff before returning an error
- Consider adding rate limit info to the tool descriptions so the LLM knows to batch requests

**Detection:** Burst queries fail with 429 errors partway through.

**Phase:** Phase 2. Not needed for initial single-tool testing, but essential before multi-tool chaining works reliably.

## Phase-Specific Warnings

| Phase Topic | Likely Pitfall | Mitigation |
|-------------|---------------|------------|
| Core server setup | stdout pollution (#1) | stderr-only logging from line one, lint rule for `print()` |
| Core server setup | Auth errors (#5) | Validate token at startup, clear error messages |
| Core server setup | Sync HTTP blocking (#10) | Use `httpx.AsyncClient`, never `requests` |
| Tool design | Too many tools (#6) | Curate 8-12 tools, not 1:1 endpoint mapping |
| Tool design | Bad descriptions (#2) | Write for LLMs, not developers; test with real queries |
| Tool design | No error convention (#8) | Define shared response format before building tools |
| Data tools | Response size (#7) | Default limits, summary stats, metadata |
| Data tools | Rate limits (#12) | Read rate headers, retry on 429, warn LLM |
| Live data | Websocket hangs (#3) | Timeout + partial results, guaranteed cleanup |
| Distribution | Install failures (#4) | Test on clean machines, OS-specific instructions |
| Multi-client | Protocol versioning (#9) | Pin SDK version, test Claude Desktop + Cursor |

## Sources

- MCP Python SDK documentation and examples (training data, MEDIUM confidence)
- MCP protocol specification patterns (training data, MEDIUM confidence)
- Python async ecosystem (`httpx`, `asyncio`) best practices (training data, HIGH confidence)
- `uv`/`uvx` packaging model (training data, MEDIUM confidence)
- Crypto market data API patterns (training data, HIGH confidence)
- Note: Web search was unavailable for cross-validation; confidence levels reflect this limitation
