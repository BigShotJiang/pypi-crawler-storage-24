# Architecture Patterns

**Domain:** Python MCP Server wrapping a crypto market data REST API
**Researched:** 2026-03-14
**Confidence:** MEDIUM (based on official MCP architecture docs + SDK training data; WebSearch/WebFetch were unavailable for cross-verification)

## Recommended Architecture

The server follows a layered architecture with clear separation between MCP protocol handling, API domain logic, and HTTP client concerns.

```
+---------------------------+
|  MCP Host (Claude Desktop)|
|  +---------------------+  |
|  |    MCP Client        |  |
|  +---------------------+  |
+-----------|---------------+
            | stdio (JSON-RPC 2.0)
+-----------|---------------+
|  sunzulab-mcp server      |
|                           |
|  +---------------------+  |
|  |  FastMCP Server      |  |  <-- Protocol layer: tool/resource registration
|  +---------------------+  |
|           |               |
|  +---------------------+  |
|  |  Tool Modules        |  |  <-- Domain layer: one module per API domain
|  |  - market_data       |  |
|  |  - streams           |  |
|  |  - alerts            |  |
|  |  - account           |  |
|  |  - discovery         |  |
|  +---------------------+  |
|           |               |
|  +---------------------+  |
|  |  API Client          |  |  <-- Infrastructure: HTTP + WebSocket + auth
|  +---------------------+  |
+-----------|---------------+
            | HTTPS / WSS
+---------------------------+
|  SunzuLab REST API        |
+---------------------------+
```

### Component Boundaries

| Component | Responsibility | Communicates With |
|-----------|---------------|-------------------|
| **FastMCP Server** | MCP protocol lifecycle, tool/resource/prompt registration, stdio transport, request routing | MCP Client (upstream), Tool Modules (downstream) |
| **Tool Modules** | Domain-specific MCP tool implementations, input validation, response formatting | FastMCP Server (registers with), API Client (calls) |
| **API Client** | HTTP session management, auth token injection, request/response serialization, error mapping, rate limit handling | SunzuLab REST API (external), WebSocket endpoints (external) |
| **Auth Provider** | Token storage, refresh logic, header injection | API Client (used by), Environment variables (reads from) |
| **Config** | Server settings, API base URL, token source | All components (read by) |

### Detailed Component Design

#### 1. FastMCP Server (Entry Point)

The `mcp` Python SDK provides `FastMCP`, a high-level server class. The server entry point creates a `FastMCP` instance, registers all tools via module imports, and configures the stdio transport.

```python
# src/sunzulab_mcp/server.py
from mcp.server.fastmcp import FastMCP

mcp = FastMCP(
    "sunzulab",
    dependencies=["httpx"],
)

# Import tool modules to trigger registration
from sunzulab_mcp.tools import market_data, streams, alerts, account, discovery
```

The FastMCP instance is the single coordination point. Tools register themselves via decorators on this instance. The server runs via `mcp.run()` which handles the stdio transport lifecycle.

**Lifespan pattern**: FastMCP supports a `lifespan` context manager for setup/teardown of shared resources (HTTP client, auth). This is where the `httpx.AsyncClient` gets created and torn down.

```python
from contextlib import asynccontextmanager
from mcp.server.fastmcp import FastMCP

@asynccontextmanager
async def lifespan(server: FastMCP):
    async with httpx.AsyncClient(...) as client:
        yield {"api_client": SunzuLabClient(client)}

mcp = FastMCP("sunzulab", lifespan=lifespan)
```

Tools access shared state via `ctx.request_context.lifespan_context["api_client"]`.

#### 2. Tool Modules (Domain Layer)

Each domain area gets its own module with tools registered via `@mcp.tool()` decorators. Tools are thin wrappers: validate input, call API client, format response for LLM consumption.

**Module breakdown:**

| Module | Tools | Description |
|--------|-------|-------------|
| `discovery.py` | `list_exchanges`, `list_pairs`, `list_data_types`, `get_api_status` | Enumerate available data dimensions |
| `market_data.py` | `get_ohlcv`, `get_trades`, `get_order_book`, `get_indicators` | Historical data queries with time range, exchange, pair parameters |
| `streams.py` | `get_stream_snapshot` | Connect to WebSocket, capture N messages, return structured data |
| `alerts.py` | `create_alert`, `list_alerts`, `delete_alert`, `get_alert_history` | CRUD operations for price/indicator alerts |
| `account.py` | `get_account_info`, `get_usage`, `get_subscription` | Account and billing information |

**Tool design principles:**
- Each tool has a clear, descriptive `name` and `description` so the LLM understands when to use it
- Input schemas use typed parameters with defaults and descriptions
- Return structured text (not raw JSON) so the LLM can reason about it
- Large datasets get summarized or paginated to stay within context limits

```python
# src/sunzulab_mcp/tools/market_data.py
from sunzulab_mcp.server import mcp

@mcp.tool()
async def get_ohlcv(
    exchange: str,
    pair: str,
    interval: str = "1h",
    start: str | None = None,
    end: str | None = None,
    limit: int = 100,
    ctx: Context = None,
) -> str:
    """Get OHLCV candlestick data for a trading pair on an exchange."""
    client = ctx.request_context.lifespan_context["api_client"]
    data = await client.get_ohlcv(exchange, pair, interval, start, end, limit)
    return format_ohlcv_response(data)
```

#### 3. API Client (Infrastructure Layer)

A single `SunzuLabClient` class wraps all HTTP interactions with the SunzuLab REST API. This is NOT an MCP concern -- it is a standard async HTTP client.

```python
# src/sunzulab_mcp/client.py
class SunzuLabClient:
    def __init__(self, http_client: httpx.AsyncClient):
        self._http = http_client

    async def get_ohlcv(self, exchange, pair, interval, start, end, limit):
        response = await self._http.get(
            "/v1/market-data/ohlcv",
            params={...},
        )
        response.raise_for_status()
        return response.json()
```

**Key design decisions:**
- Uses `httpx.AsyncClient` (async, HTTP/2 capable, connection pooling)
- Auth token injected via `httpx.AsyncClient(headers={"Authorization": f"Bearer {token}"})` at client creation time
- All methods return parsed Python dicts/lists (not raw responses)
- Error handling maps HTTP errors to user-friendly MCP error messages
- WebSocket snapshots use a separate method with `websockets` or `httpx-ws`

#### 4. Auth Provider

Token comes from environment variable (`SUNZULAB_API_TOKEN`). Read at startup, injected into httpx client headers. No refresh logic needed for v1 (JWT/API key pattern).

```python
# src/sunzulab_mcp/auth.py
import os

def get_auth_headers() -> dict[str, str]:
    token = os.environ.get("SUNZULAB_API_TOKEN")
    if not token:
        raise ValueError("SUNZULAB_API_TOKEN environment variable is required")
    return {"Authorization": f"Bearer {token}"}
```

#### 5. Response Formatters

A dedicated module for converting raw API responses into LLM-friendly text. This is critical: LLMs process natural language better than raw JSON.

```python
# src/sunzulab_mcp/formatters.py
def format_ohlcv_response(data: list[dict]) -> str:
    """Format OHLCV data as a readable table for LLM consumption."""
    ...
```

### Data Flow

#### Historical Data Query Flow

```
User asks: "What was BTC price on Binance last week?"
    |
    v
LLM decides to call: get_ohlcv(exchange="binance", pair="BTC/USDT", interval="1d", start="2026-03-07")
    |
    v
MCP Client --> stdio --> FastMCP Server
    |
    v
FastMCP routes to get_ohlcv tool function
    |
    v
Tool validates params, calls api_client.get_ohlcv(...)
    |
    v
SunzuLabClient sends: GET /v1/market-data/ohlcv?exchange=binance&pair=BTC/USDT&...
    |                  Authorization: Bearer <token>
    v
REST API returns JSON array of OHLCV records
    |
    v
format_ohlcv_response() converts to readable table text
    |
    v
Tool returns formatted string --> FastMCP --> stdio --> MCP Client --> LLM
    |
    v
LLM synthesizes answer: "BTC on Binance ranged from $X to $Y last week..."
```

#### WebSocket Snapshot Flow

```
User asks: "What's the current order book for ETH?"
    |
    v
LLM calls: get_stream_snapshot(topic="orderbook", exchange="binance", pair="ETH/USDT", count=5)
    |
    v
Tool function:
  1. Opens WSS connection to SunzuLab streaming endpoint
  2. Subscribes to topic
  3. Collects N messages (with timeout)
  4. Closes connection
  5. Formats and returns snapshot
    |
    v
Formatted snapshot returned to LLM via MCP
```

**Important**: The WebSocket connection is ephemeral -- opened per-request, not held persistently. This matches the "snapshot mode" described in PROJECT.md.

#### Alert Flow

```
User: "Alert me when BTC drops below $50,000"
    |
    v
LLM calls: create_alert(pair="BTC/USDT", condition="price_below", threshold=50000)
    |
    v
Tool calls: POST /v1/alerts with alert config
    |
    v
API creates alert, returns alert ID
    |
    v
[Later, when alert triggers]
    |
    v
Options for notification delivery:
  A. Polling: LLM periodically calls get_alert_history()
  B. MCP notification: Server pushes via notification primitive (if host supports it)
  C. External: Alert delivered via email/webhook outside MCP
```

**Note**: Alert notification delivery within MCP is a design question to resolve in implementation. The MCP protocol supports server-to-client notifications, but whether the host (Claude Desktop) surfaces them to the user mid-conversation is host-dependent.

## Recommended Project Structure

```
sunzulab-mcp/
  pyproject.toml            # Package config, entry points, dependencies
  src/
    sunzulab_mcp/
      __init__.py
      __main__.py            # Entry point: python -m sunzulab_mcp
      server.py              # FastMCP instance, lifespan, mcp.run()
      auth.py                # Token loading from env
      client.py              # SunzuLabClient (httpx wrapper)
      formatters.py          # Response formatting for LLM consumption
      tools/
        __init__.py          # Imports all tool modules (triggers registration)
        discovery.py         # Exchange/pair/data type enumeration
        market_data.py       # OHLCV, trades, order book, indicators
        streams.py           # WebSocket snapshot capture
        alerts.py            # Alert CRUD
        account.py           # Account info, usage, subscription
  tests/
    conftest.py              # Shared fixtures, mock API client
    test_tools/
      test_discovery.py
      test_market_data.py
      test_streams.py
      test_alerts.py
      test_account.py
    test_client.py           # API client tests with httpx mocking
    test_formatters.py
    test_server.py           # Integration tests via MCP test client
```

**Entry point in pyproject.toml:**

```toml
[project.scripts]
sunzulab-mcp = "sunzulab_mcp.server:main"
```

This allows `uvx sunzulab-mcp` to work. The `main()` function calls `mcp.run()`.

## Patterns to Follow

### Pattern 1: Lifespan Context for Shared Resources

**What:** Use FastMCP's `lifespan` parameter to create and tear down the httpx client and API wrapper once, shared across all tool invocations.
**When:** Always. Every tool needs the API client.
**Why:** Avoids creating new HTTP connections per tool call. Connection pooling improves performance.

### Pattern 2: Thin Tools, Fat Client

**What:** Tool functions contain only input validation and response formatting. All HTTP logic lives in `SunzuLabClient`.
**When:** Every tool.
**Why:** Tools are easy to test (mock the client). Client is testable independently (mock HTTP). No duplication of HTTP logic across tools.

### Pattern 3: LLM-Optimized Response Formatting

**What:** Convert raw JSON API responses into structured text with clear labels, units, and context.
**When:** Every tool response.
**Why:** LLMs reason better over natural language than raw JSON. Reduces token waste from verbose JSON keys. Allows adding contextual hints ("Note: volume is in USD").

### Pattern 4: Descriptive Tool Metadata

**What:** Every tool has a detailed `description` that tells the LLM when and how to use it, plus typed parameters with descriptions.
**When:** Every tool registration.
**Why:** The LLM uses tool descriptions to decide which tool to call. Poor descriptions = wrong tool selection = bad user experience.

### Pattern 5: Graceful Error Handling in Tools

**What:** Catch API errors and return user-friendly error messages rather than raising exceptions.
**When:** Every tool call.
**Why:** Unhandled exceptions crash the MCP connection. The LLM can recover from a clear error message ("Exchange 'binanse' not found. Available: binance, coinbase, kraken").

## Anti-Patterns to Avoid

### Anti-Pattern 1: One Giant Tool

**What:** A single "query" tool that accepts free-form parameters and tries to handle all API endpoints.
**Why bad:** LLMs struggle with ambiguous tool schemas. They perform much better when tools are specific and well-typed (e.g., `get_ohlcv` vs `query_api`).
**Instead:** One tool per distinct operation. Overlap is fine; clarity is better.

### Anti-Pattern 2: Returning Raw JSON

**What:** Passing API response JSON directly to the LLM.
**Why bad:** Wastes context tokens on JSON syntax. LLM may misinterpret nested structures. Missing units and context.
**Instead:** Format into readable text or Markdown tables with clear headers.

### Anti-Pattern 3: Persistent WebSocket Connections

**What:** Holding WebSocket connections open between tool calls.
**Why bad:** MCP tools are request-response. The server process may be idle for minutes between calls. Resource leak risk.
**Instead:** Ephemeral connections per snapshot request with timeouts.

### Anti-Pattern 4: Auto-generating All Tools from OpenAPI

**What:** Mechanically converting every OpenAPI endpoint to an MCP tool without curation.
**Why bad:** Produces confusing, overlapping tools with poor descriptions. Internal/admin endpoints get exposed. LLM tool selection degrades with too many similar tools.
**Instead:** Manually curate which endpoints become tools. Group related endpoints. Write human-quality descriptions. Aim for 10-15 well-defined tools, not 30 thin wrappers.

### Anti-Pattern 5: Blocking Synchronous Calls

**What:** Using `requests` or synchronous HTTP in an async MCP server.
**Why bad:** Blocks the event loop. Stdio transport hangs.
**Instead:** Use `httpx.AsyncClient` for all HTTP operations.

## Scalability Considerations

| Concern | At 1 user (local) | At 10 users (hypothetical remote) | Notes |
|---------|--------------------|------------------------------------|-------|
| Connection pooling | httpx default pool sufficient | Connection pool limits matter | v1 is single-user local; not a concern |
| WebSocket snapshots | Open/close per request is fine | Would need connection pooling | Ephemeral pattern is correct for v1 |
| Token context | 10-15 tools fit in context | Same | Tool count is the constraint, not users |
| Rate limiting | Unlikely to hit API limits | Need client-side throttling | API may have per-token rate limits |

## Build Order (Dependencies Between Components)

Components should be built in this order based on dependencies:

```
Phase 1: Foundation
  auth.py          (no deps, needed by everything)
  client.py        (depends on: auth)
  server.py        (depends on: mcp SDK)

Phase 2: First Tools
  formatters.py    (no deps, needed by tools)
  tools/discovery.py  (depends on: client, server, formatters)
  tools/market_data.py (depends on: client, server, formatters)

Phase 3: Advanced Tools
  tools/streams.py    (depends on: client + websocket logic, server, formatters)
  tools/alerts.py     (depends on: client, server, formatters)
  tools/account.py    (depends on: client, server, formatters)

Phase 4: Distribution
  pyproject.toml      (entry points, dependencies)
  __main__.py         (depends on: server)
  packaging + PyPI    (depends on: everything)
```

**Rationale:**
- Auth and client must exist before any tools
- Discovery and market_data tools are the core value proposition -- build and validate first
- Streams require WebSocket handling, a distinct concern from REST -- separate phase
- Alerts have notification delivery complexity -- build after core tools work
- Account tools are low-risk, low-complexity -- can be added anytime after Phase 1
- Distribution packaging depends on the full working server

## Sources

- MCP Architecture documentation (https://modelcontextprotocol.io/docs/concepts/architecture) -- fetched 2026-03-14, HIGH confidence
- MCP Python SDK (`mcp` package, FastMCP API) -- from training data, MEDIUM confidence (SDK API may have evolved; verify `lifespan` and `Context` patterns against current SDK version before implementation)
- MCP Protocol specification -- from training data, HIGH confidence (protocol is stable)
