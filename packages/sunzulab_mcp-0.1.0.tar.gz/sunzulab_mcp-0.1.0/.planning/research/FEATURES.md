# Feature Landscape

**Domain:** MCP server for crypto market data API
**Researched:** 2026-03-14

## Table Stakes

Features users expect. Missing = product feels incomplete or broken.

### MCP Protocol Compliance

| Feature | Why Expected | Complexity | Notes |
|---------|--------------|------------|-------|
| Tool discovery (`tools/list`) | MCP clients enumerate tools to present to the LLM; without this, nothing works | Low | Auto-generated from OpenAPI spec |
| Tool invocation (`tools/call`) | Core protocol requirement for executing API calls | Low | Route to REST endpoints |
| Input validation via JSON Schema | LLMs need schema to generate correct arguments; clients validate against it | Low | Derive `inputSchema` from OpenAPI parameter schemas |
| Structured error responses | LLMs must distinguish success from failure to retry or explain to user | Low | Use `isError: true` with human-readable messages |
| stdio transport | Claude Desktop and most MCP clients use stdio; SSE/HTTP is optional | Low | Default transport in MCP Python SDK |

### Data Query Tools

| Feature | Why Expected | Complexity | Notes |
|---------|--------------|------------|-------|
| Historical OHLCV retrieval | Core use case -- "show me BTC price last week" | Low | Direct REST mapping |
| Trade data retrieval | Fundamental crypto data type clients pay for | Low | Direct REST mapping |
| Order book snapshots | Essential for liquidity analysis | Low | Direct REST mapping |
| Indicator data retrieval | Pre-computed analytics clients expect access to | Low | Direct REST mapping |
| Exchange discovery | LLM needs to know what exchanges are available before querying | Low | Direct REST mapping |
| Pair/symbol discovery | LLM needs to enumerate tradable pairs to answer vague queries | Low | Direct REST mapping |
| Data type discovery | LLM must know what data types exist (OHLCV, trades, etc.) | Low | Direct REST mapping |

### Authentication and Configuration

| Feature | Why Expected | Complexity | Notes |
|---------|--------------|------------|-------|
| Token-based auth (OAuth/JWT) | Clients already have SunzuLab tokens; no separate auth | Low | Read from env var, pass as header |
| Zero-config installation | Non-technical traders need paste-JSON-and-go experience | Low | `uvx sunzulab-mcp` with env var for token |
| Auth error clarity | "Invalid token" vs "expired token" vs "insufficient permissions" | Low | Map API error codes to user-friendly messages |

### Account Management

| Feature | Why Expected | Complexity | Notes |
|---------|--------------|------------|-------|
| View account info | "What's my subscription?" / "How much API usage have I used?" | Low | Direct REST mapping |
| View usage/quota status | Prevents surprise rate limits; users want to check before heavy queries | Low | Direct REST mapping |

### Alert Management

| Feature | Why Expected | Complexity | Notes |
|---------|--------------|------------|-------|
| Create alerts (price, indicator thresholds) | "Alert me when BTC drops below 60k" | Medium | REST mapping, but LLM must interpret natural language thresholds |
| List active alerts | "What alerts do I have?" | Low | Direct REST mapping |
| Delete/modify alerts | "Cancel my ETH alert" | Low | Direct REST mapping |

## Differentiators

Features that set the product apart. Not expected in a generic MCP server, but high value for this domain.

### LLM-Optimized Data Formatting

| Feature | Value Proposition | Complexity | Notes |
|---------|-------------------|------------|-------|
| Token-efficient data serialization | OHLCV/trade data can be massive; compress into tabular or summary format to stay within context limits | Medium | Format as compact tables, not verbose JSON arrays. E.g., CSV-like text for time series |
| Automatic pagination with summarization | When query returns 10k candles, return page 1 + summary stats instead of truncating | Medium | Server-side pagination with metadata: "Showing 100 of 8,500 candles, avg price: X" |
| Output annotations for audience routing | Mark raw data as `assistant`-only (for LLM processing) and summaries as `user`-facing | Low | MCP annotations: `audience: ["assistant"]` for data, `audience: ["user"]` for summaries |

### Intelligent Discovery

| Feature | Value Proposition | Complexity | Notes |
|---------|-------------------|------------|-------|
| MCP Resources for metadata | Expose exchange list, pair catalog, data type inventory as browsable Resources (`resources/list`) | Medium | Lets LLM pre-load context without tool calls. Resource URIs like `sunzu://exchanges`, `sunzu://pairs/{exchange}` |
| Resource templates for parameterized discovery | `sunzu://orderbook/{exchange}/{pair}` lets clients browse data hierarchically | Medium | MCP resource templates with auto-completion |
| Tool descriptions optimized for LLM reasoning | Descriptions explain not just "what" but "when to use" and "chain with" | Low | E.g., "Use this after `list_exchanges` to get pairs for a specific exchange" |

### Live Data Access

| Feature | Value Proposition | Complexity | Notes |
|---------|-------------------|------------|-------|
| Websocket snapshot tool | "What's BTC trading at right now?" -- connect, grab N messages, disconnect, return | High | Ephemeral websocket connection per tool call. Must handle connection timeout, message buffering |
| Alert notification delivery | Server pushes alert triggers to client via MCP notifications | High | Requires MCP server to poll or receive webhooks from SunzuLab API, then emit notifications |

### Guided Workflows (MCP Prompts)

| Feature | Value Proposition | Complexity | Notes |
|---------|-------------------|------------|-------|
| Pre-built analysis prompts | Slash commands like `/market-overview`, `/liquidity-analysis`, `/compare-exchanges` that chain multiple tools | Medium | MCP Prompts that inject structured multi-step instructions for the LLM |
| Onboarding prompt | `/getting-started` that discovers account capabilities and walks through first queries | Low | Single prompt template |

### Structured Output

| Feature | Value Proposition | Complexity | Notes |
|---------|-------------------|------------|-------|
| Output schemas on data tools | Typed, validated responses that downstream code can parse reliably | Medium | MCP `outputSchema` on tools returning structured data (OHLCV, order books) |
| Dual content (structured + text) | Return both `structuredContent` for programmatic use and `content` text for LLM display | Medium | MCP spec recommends this for backward compatibility |

## Anti-Features

Features to explicitly NOT build.

| Anti-Feature | Why Avoid | What to Do Instead |
|--------------|-----------|-------------------|
| Persistent websocket connections | LLMs cannot hold stateful connections across turns; wastes server resources; MCP stdio transport is request-response | Use snapshot pattern: connect, capture N messages, disconnect. Use alerts for ongoing monitoring |
| Custom analytics/transformations | Scope creep; the API already provides indicators; LLM can do ad-hoc analysis on returned data | Return raw data, let the LLM synthesize. Keep server as a thin proxy |
| Dashboard or visualization | MCP servers are protocol endpoints, not UIs; Claude Desktop/Cursor handle display | Return structured data; let the client render charts if it supports them |
| Multi-user auth or user management | Client-side deployment means one user per instance; token comes from env var | Single-token design, one user per server process |
| Caching layer with invalidation | Adds complexity; API responses are time-sensitive (stale cache = wrong data for traders) | Let the upstream API handle caching. Add simple TTL cache only if rate limits become a problem (defer to later phase) |
| Rate limit management in server | The upstream API enforces its own rate limits; duplicating logic creates drift | Pass through API rate limit errors clearly. Surface remaining quota via account tools |
| Hosted/remote MCP server | Out of scope for v1 per project constraints; security implications of routing tokens through third-party infra | Client-side deployment only. Revisit in v2 if demand exists |
| TypeScript port | Team expertise is Python; `uvx` provides equivalent of `npx`; maintaining two implementations doubles work | Python-only with official MCP Python SDK |
| OpenAPI-to-MCP at runtime | Dynamic generation from live OpenAPI spec adds startup latency, error surface, and makes tool names unstable | Generate tools at build time from OpenAPI spec. Pin tool definitions |

## Feature Dependencies

```
Authentication (token config)
  |
  +-- All data query tools (OHLCV, trades, order books, indicators)
  |     |
  |     +-- Websocket snapshot tool (needs same auth + exchange/pair knowledge)
  |     +-- Guided workflow prompts (chain multiple query tools)
  |
  +-- Discovery tools (exchanges, pairs, data types)
  |     |
  |     +-- MCP Resources for metadata (alternative to discovery tools)
  |     +-- Resource templates (builds on resource infrastructure)
  |
  +-- Account management tools
  |     |
  |     +-- Usage/quota display
  |
  +-- Alert management tools (create, list, delete)
        |
        +-- Alert notification delivery (requires alert infrastructure)
```

Key dependency chains:

- Discovery tools must exist before guided workflow prompts (prompts need to reference tool names)
- Token auth must work before anything else
- Data query tools are independent of each other (OHLCV, trades, order books can ship in parallel)
- Alert notifications depend on alert CRUD tools existing first
- MCP Resources are additive -- can layer on after tools work

## MVP Recommendation

Prioritize:
1. **Token auth + stdio transport** -- gate for everything else
2. **Discovery tools** (exchanges, pairs, data types) -- LLM needs these to answer any vague query
3. **Core data query tools** (OHLCV, trades, order books, indicators) -- the primary value
4. **Account management** (view account, usage) -- low effort, high utility
5. **Alert CRUD** (create, list, delete alerts) -- completes the "manage" part of the value prop
6. **Token-efficient formatting** -- differentiator that makes the LLM interaction actually work well with large datasets

Defer:
- **Websocket snapshots**: High complexity, requires careful connection management. Ship after core tools work.
- **Alert notifications**: Requires polling/webhook infrastructure. Ship after alert CRUD works.
- **MCP Resources**: Additive improvement over discovery tools. Nice-to-have after tools are stable.
- **Guided workflow prompts**: Need stable tool names and tested tool chains before authoring prompts.
- **Output schemas**: Valuable but not blocking. Can retrofit onto existing tools.

## Sources

- MCP Protocol Specification (2025-06-18): Tools, Resources, Prompts, Sampling concepts -- https://modelcontextprotocol.io/docs/concepts/tools
- SunzuLab PROJECT.md: Domain constraints, API surface, client profiles
- MCP protocol analysis: Confidence MEDIUM (based on official docs, no web search for competitor MCP servers)
