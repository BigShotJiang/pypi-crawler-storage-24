# Project Research Summary

**Project:** SunzuLab MCP Server
**Domain:** Python MCP server wrapping a crypto market data REST API
**Researched:** 2026-03-14
**Confidence:** MEDIUM

## Executive Summary

SunzuLab MCP Server is a Python package that wraps the SunzuLab crypto market data REST API as a Model Context Protocol server, enabling LLMs (primarily Claude Desktop) to query real-time and historical market data through natural language. The recommended approach is FastMCP (high-level Anthropic SDK) over stdio transport, distributed via `uvx sunzulab-mcp`. The stack is deliberately minimal: `mcp`, `httpx`, `pydantic-settings`, and `websockets` — everything else is already a transitive dependency or an anti-pattern for this domain. Tools should be manually curated (8-12 total), not auto-generated from OpenAPI, and responses must be formatted as LLM-friendly text rather than raw JSON.

The architecture follows three clean layers: a FastMCP protocol layer, domain-specific tool modules, and a shared `SunzuLabClient` HTTP wrapper. A lifespan context manager creates a single `httpx.AsyncClient` at startup and tears it down on shutdown — this is the correct pattern for connection pooling across tool calls. WebSocket access uses an ephemeral connect-capture-disconnect pattern per request, matching the MCP request-response model. Auth comes from a single env var validated at startup.

The main risks are operational, not architectural. stdout pollution is the single most common MCP server bug and must be prevented from day one via stderr-only logging. Poor tool descriptions that confuse LLM tool selection will make the product feel broken even when the API calls succeed. WebSocket snapshot timeouts and large response payloads are the other two issues likely to surface in production. All four are preventable with design decisions made in Phase 1.

## Key Findings

### Recommended Stack

The stack consists entirely of dependencies already in the MCP SDK's transitive tree, plus one purpose-built addition. Python 3.10+ is required by the SDK; target 3.12. Use `uv`/`uvx` for packaging and distribution — this is the only path to the target UX of `uvx sunzulab-mcp`. No CLI framework, web framework, ORM, task queue, or caching layer belongs in this server.

**Core technologies:**
- `mcp>=1.6` (FastMCP API): MCP server framework — official Anthropic SDK, only supported Python path
- `httpx>=0.27`: Async REST client — already an MCP SDK transitive dep, native async, HTTP/2 and connection pooling
- `pydantic-settings>=2.5`: Config/env var management — already in Pydantic ecosystem, reads `SUNZULAB_TOKEN` from env
- `websockets>=13.0`: WebSocket client for snapshot mode — lightweight, avoids pulling in aiohttp framework
- `uv` + `hatchling`: Build and distribution — enables `uvx sunzulab-mcp` zero-install UX
- `ruff`, `mypy`, `pytest`, `pytest-asyncio`, `respx`: Dev toolchain — standard, no surprises

### Expected Features

**Must have (table stakes):**
- MCP protocol compliance (`tools/list`, `tools/call`, JSON Schema input validation, structured error responses)
- Token auth via env var with startup validation and clear error messages
- Discovery tools: list exchanges, pairs, data types
- Core data query tools: OHLCV, trades, order book, indicators
- Account management: account info, usage/quota
- Alert CRUD: create, list, delete alerts
- Token-efficient response formatting (compact tables, not verbose JSON arrays)

**Should have (differentiators):**
- WebSocket snapshot tool for live data (ephemeral connection per call)
- MCP Resources for metadata (browsable exchange/pair catalogs without tool calls)
- Guided workflow prompts (`/market-overview`, `/compare-exchanges`)
- Output schemas on data tools (`structuredContent` + `content` dual output)

**Defer to v2+:**
- Alert notification delivery via MCP notifications (requires polling/webhook infrastructure)
- MCP resource templates with auto-completion
- Multi-client compatibility testing beyond Claude Desktop
- Hosted/remote MCP server deployment

### Architecture Approach

The server uses a three-layer architecture: FastMCP (protocol), tool modules (domain), and SunzuLabClient (HTTP infrastructure). A lifespan context manager on the FastMCP instance creates the shared `httpx.AsyncClient` once. Tool functions are thin wrappers: validate input, call the client, format output. All HTTP logic and error mapping live in `SunzuLabClient`. A dedicated `formatters.py` module converts raw API responses to LLM-readable text. Auth is loaded at startup from env and injected into the HTTP client headers — no per-request auth logic.

**Major components:**
1. `server.py` (FastMCP instance + lifespan) — protocol layer, tool registration, stdio transport, startup/shutdown
2. `client.py` (SunzuLabClient) — HTTP session, auth injection, error mapping, WebSocket snapshot logic
3. `tools/` (5 modules: discovery, market_data, streams, alerts, account) — MCP tool definitions, input validation, response formatting calls
4. `formatters.py` — LLM-optimized response serialization (compact tables, summary stats, metadata annotations)
5. `auth.py` + `config.py` — env var loading, startup validation, API base URL config

### Critical Pitfalls

1. **stdout pollution** — Any `print()` or library writing to stdout corrupts the stdio JSON-RPC stream and silently breaks tool discovery. Prevention: configure `logging.basicConfig(stream=sys.stderr)` from line one; add a CI lint rule banning `print(` in source files.

2. **Tool descriptions that confuse LLMs** — Vague or developer-oriented descriptions cause wrong tool selection, making the product feel broken. Prevention: write descriptions as instructions to a smart assistant; include when-to-use, valid parameter values, and chain-with guidance; test with real natural-language queries before shipping.

3. **WebSocket snapshot hangs** — Low-volume pairs may produce zero messages in 60+ seconds; unclosed connections leak resources. Prevention: always wrap with `asyncio.wait_for()` (5-10s timeout); use `async with` for guaranteed cleanup; return partial results on timeout.

4. **`uvx` installation failure for non-technical users** — Traders who aren't developers don't have `uv` installed. Prevention: provide OS-specific single-command install instructions; test on clean machines (not dev machines).

5. **Cryptic auth error messages** — 401/403 from the API surfaces as "I encountered an error." Prevention: validate token at startup with a lightweight API call; return actionable messages distinguishing missing, invalid, and expired tokens.

## Implications for Roadmap

Based on research, suggested phase structure:

### Phase 1: Foundation and Core Tools
**Rationale:** Auth, HTTP client, and tool framework are hard dependencies for everything else. The error-handling convention and stdout-safety must be correct before any tools are built — retrofitting is expensive. Discovery tools are the LLM's prerequisite for answering vague queries; market data tools are the primary value proposition. Together they represent the minimum viable product.
**Delivers:** Working `uvx sunzulab-mcp` command; auth with startup validation; discovery tools (exchanges, pairs, data types); core data tools (OHLCV, trades, order book, indicators); account tools; LLM-optimized response formatting
**Addresses:** All table-stakes features from FEATURES.md
**Avoids:** Pitfalls #1 (stdout), #2 (tool descriptions), #5 (auth errors), #8 (no error convention), #10 (sync HTTP blocking)

### Phase 2: Live Data and Alert Management
**Rationale:** Alert CRUD and WebSocket snapshots both depend on the HTTP client and tool framework from Phase 1. The WebSocket snapshot tool has distinct complexity (timeouts, partial results, connection cleanup) that justifies its own phase. Rate limit awareness must arrive before multi-tool chaining becomes normal use.
**Delivers:** Alert CRUD tools (create, list, delete); WebSocket snapshot tool with timeout handling; rate limit header reading and LLM-facing quota warnings
**Uses:** `websockets>=13.0` (STACK.md), ephemeral connection pattern (ARCHITECTURE.md)
**Avoids:** Pitfalls #3 (WebSocket hangs), #12 (rate limit 429 failures mid-chain)

### Phase 3: LLM Differentiation and Distribution Polish
**Rationale:** MCP Resources, guided prompts, and output schemas are additive improvements that depend on stable tool names and tested tool chains from Phases 1-2. Distribution and multi-client testing should happen after the product works, not before.
**Delivers:** MCP Resources for metadata (exchange/pair catalogs); guided workflow prompts (`/market-overview`, `/compare-exchanges`); output schemas on data tools; cross-client testing (Claude Desktop + Cursor); packaging validation on clean machines
**Avoids:** Pitfalls #4 (install failure), #6 (too many tools), #7 (large response payloads), #9 (protocol versioning)

### Phase Ordering Rationale

- Discovery tools must precede guided prompts (prompts reference tool names that must already exist)
- Auth and HTTP client must precede all tools (hard dependency)
- Data query tools are independent of each other (OHLCV, trades, order book can be built in parallel within Phase 1)
- Alert notifications depend on alert CRUD (defer to v2+ alongside webhook infrastructure)
- Formatting conventions must be designed before tools are built, not retrofitted — drives Phase 1 scope
- WebSocket is separated from REST tools because it introduces a distinct async concern (timeout handling, `asyncio.wait_for`)
- Distribution validation on clean machines belongs late (after the product works, not during initial development)

### Research Flags

Phases likely needing deeper research during planning:
- **Phase 2 (WebSocket snapshot):** The SunzuLab streaming API endpoint structure, authentication over WebSocket, and topic subscription protocol are not fully documented in the research. Needs API-specific investigation before implementation.
- **Phase 3 (MCP Resources):** MCP Resource implementation with the current FastMCP SDK API (lifespan context access from resource handlers) has MEDIUM confidence. Verify against current SDK docs before planning.

Phases with standard patterns (skip research-phase):
- **Phase 1 (Foundation + Core Tools):** Well-documented FastMCP patterns, httpx async client, and pydantic-settings. High confidence in implementation approach.
- **Phase 3 (Prompts + Packaging):** MCP Prompts are straightforward template definitions. `uvx` packaging with `hatchling` is well-documented.

## Confidence Assessment

| Area | Confidence | Notes |
|------|------------|-------|
| Stack | HIGH | All libraries well-established; MCP SDK version may need verification against current release |
| Features | MEDIUM | MCP protocol concepts are well-documented; SunzuLab-specific API surface inferred from PROJECT.md, not tested |
| Architecture | MEDIUM | FastMCP lifespan/Context patterns from training data; verify `lifespan` API shape against current SDK before building |
| Pitfalls | MEDIUM | MCP stdio pollution and async patterns are HIGH confidence; WebSocket and packaging pitfalls from domain knowledge |

**Overall confidence:** MEDIUM

### Gaps to Address

- **SunzuLab streaming API spec:** WebSocket endpoint URL, subscription message format, auth protocol, and topic naming are unknown. Request API documentation or test against staging before implementing `streams.py`.
- **FastMCP SDK current API:** The `lifespan` context manager pattern and `ctx.request_context.lifespan_context` access were accurate as of training data but should be verified against the current `mcp` package before implementation. Run `uv add mcp` and read the installed source.
- **MCP SDK version pin:** The research recommends `mcp>=1.6` but notes the SDK was evolving rapidly in early 2025. Check the current release before finalizing `pyproject.toml` constraints.
- **Alert notification delivery:** Whether MCP server-to-client notifications are surfaced to users in Claude Desktop mid-conversation is host-dependent and untested. Design alert tools assuming polling-first, notification-second.

## Sources

### Primary (HIGH confidence)
- MCP Architecture documentation — https://modelcontextprotocol.io/docs/concepts/architecture
- MCP Protocol Specification (2025-06-18) — tools, resources, prompts concepts
- httpx documentation — https://www.python-httpx.org/
- Pydantic v2 documentation — https://docs.pydantic.dev/
- uv/uvx documentation — https://docs.astral.sh/uv/

### Secondary (MEDIUM confidence)
- MCP Python SDK (GitHub: modelcontextprotocol/python-sdk) — FastMCP API, lifespan patterns, Context access
- websockets library documentation — https://websockets.readthedocs.io/
- SunzuLab PROJECT.md — domain constraints, target audience, API surface description

### Tertiary (LOW confidence — validate during implementation)
- WebSocket streaming API specifics — inferred from project description, not directly documented
- MCP client compatibility matrix (Claude Desktop vs Cursor) — based on community knowledge, not tested

---
*Research completed: 2026-03-14*
*Ready for roadmap: yes*
