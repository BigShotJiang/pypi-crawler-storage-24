# Technology Stack

**Project:** SunzuLab MCP Server
**Researched:** 2026-03-14
**Overall confidence:** MEDIUM (versions based on training data through May 2025; verify pinned versions before implementation)

## Recommended Stack

### Core Framework

| Technology | Version | Purpose | Why | Confidence |
|------------|---------|---------|-----|------------|
| `mcp` (Python SDK) | `>=1.6` | MCP server framework | Official Anthropic SDK. Only supported way to build MCP servers in Python. Provides `@mcp.tool()` decorators, stdio transport, SSE transport, and the `FastMCP` high-level API. | HIGH |
| Python | `>=3.10` | Runtime | MCP SDK requires 3.10+. Use 3.12 as target for best performance and typing support. | HIGH |

### HTTP Client

| Technology | Version | Purpose | Why | Confidence |
|------------|---------|---------|-----|------------|
| `httpx` | `>=0.27` | REST API client | Async-native (`AsyncClient`), HTTP/2 support, connection pooling, timeout handling. The MCP SDK already depends on httpx internally, so no extra dependency weight. Preferred over `aiohttp` (less ergonomic) and `requests` (sync-only). | HIGH |

### Data Validation & Serialization

| Technology | Version | Purpose | Why | Confidence |
|------------|---------|---------|-----|------------|
| `pydantic` | `>=2.7` | Request/response models, settings | MCP SDK already depends on Pydantic v2. Use it for API response parsing, tool input validation, and `BaseSettings` for configuration. Zero additional dependency cost. | HIGH |

### WebSocket Client

| Technology | Version | Purpose | Why | Confidence |
|------------|---------|---------|-----|------------|
| `websockets` | `>=13.0` | WebSocket connections for snapshot mode | Clean async API, well-maintained, lightweight. Used for connecting to SunzuLab's topic-based websocket streams to capture N messages then disconnect. Preferred over `aiohttp` websockets (pulls in full web framework) or httpx (no native websocket support). | MEDIUM |

### Build & Distribution

| Technology | Version | Purpose | Why | Confidence |
|------------|---------|---------|-----|------------|
| `uv` | latest | Package manager, build tool | Required for `uvx` distribution. Replaces pip, pip-tools, virtualenv, and setuptools in one tool. `uvx sunzulab-mcp` runs the package without permanent install -- the target UX. | HIGH |
| `hatchling` | `>=1.25` | Build backend | Lightweight, standards-compliant PEP 517 backend. Works well with uv. Preferred over setuptools (legacy complexity) and poetry-core (opinionated lockfile story conflicts with uv). | MEDIUM |

### Configuration

| Technology | Version | Purpose | Why | Confidence |
|------------|---------|---------|-----|------------|
| `pydantic-settings` | `>=2.5` | Environment variable + config management | Reads auth tokens from env vars (`SUNZULAB_TOKEN`), supports `.env` files, validates config at startup. Already in the Pydantic ecosystem. | HIGH |

### Testing

| Technology | Version | Purpose | Why | Confidence |
|------------|---------|---------|-----|------------|
| `pytest` | `>=8.0` | Test framework | Standard. No reason to use anything else. | HIGH |
| `pytest-asyncio` | `>=0.24` | Async test support | Required for testing async MCP tools and httpx calls. | HIGH |
| `respx` | `>=0.21` | HTTP mocking | Purpose-built for mocking httpx requests. Preferred over `responses` (requests-only) or generic `unittest.mock`. | HIGH |
| `pytest-cov` | `>=5.0` | Coverage reporting | Standard coverage tool. | HIGH |

### Code Quality

| Technology | Version | Purpose | Why | Confidence |
|------------|---------|---------|-----|------------|
| `ruff` | `>=0.6` | Linter + formatter | Replaces flake8, isort, black in one tool. 10-100x faster. De facto standard for new Python projects. | HIGH |
| `mypy` | `>=1.11` | Type checking | Catches type errors at dev time. Pydantic plugin available. | HIGH |

## Alternatives Considered

| Category | Recommended | Alternative | Why Not |
|----------|-------------|-------------|---------|
| HTTP client | httpx | aiohttp | aiohttp has a less ergonomic API, heavier dependency tree, and is not already a transitive dependency of the MCP SDK |
| HTTP client | httpx | requests | Sync-only. MCP tools are async. Would need `anyio.to_thread` wrappers everywhere. |
| Build backend | hatchling | setuptools | setuptools requires more boilerplate (`setup.cfg`/`setup.py`), less clean for pure Python packages |
| Build backend | hatchling | poetry-core | Poetry's lockfile and resolver duplicate uv's job. Creates friction for `uvx` users. |
| WebSocket | websockets | aiohttp ws | Pulls in the entire aiohttp framework as a dependency for one feature |
| Formatter | ruff | black + isort | Two tools doing what one does faster |
| OpenAPI parsing | Manual tool definitions | openapi-python-client | Auto-generated clients are brittle, hard to customize, and overkill when you have 10-30 endpoints with known shapes |

## Key Architecture Decisions

### Use FastMCP (high-level API), not low-level Server class

The MCP Python SDK provides two APIs:
- `FastMCP`: Decorator-based, handles serialization, type inference from function signatures
- `Server`: Low-level, manual message handling

Use `FastMCP` because:
1. Tool definitions derive from function signatures + docstrings -- less boilerplate
2. Pydantic model integration is automatic
3. Sufficient for REST API wrapping (no custom protocol extensions needed)

### Single httpx.AsyncClient instance, shared across tools

Create one `httpx.AsyncClient` in the server lifespan context. Share it across all tool functions. This gives you:
- Connection pooling (reuse TCP connections to SunzuLab API)
- Consistent auth headers (set once via `base_url` and `headers`)
- Proper cleanup on server shutdown

### Do NOT auto-generate tools from OpenAPI spec at runtime

While tempting, runtime OpenAPI-to-MCP-tool generation creates problems:
- Tool descriptions are generic, confusing LLMs
- No control over parameter naming or grouping
- Harder to test, debug, and evolve
- Schema changes in the API silently change tool behavior

Instead: Write explicit tool functions that call the API. Use the OpenAPI spec as a *reference* during development, not as a runtime code generator.

### pyproject.toml with `[project.scripts]` entry point

For `uvx` compatibility, the package needs a console script entry point:

```toml
[project.scripts]
sunzulab-mcp = "sunzulab_mcp:main"
```

This lets `uvx sunzulab-mcp` find and execute the server.

## pyproject.toml Skeleton

```toml
[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[project]
name = "sunzulab-mcp"
version = "0.1.0"
description = "MCP server for SunzuLab crypto market data"
requires-python = ">=3.10"
dependencies = [
    "mcp>=1.6",
    "httpx>=0.27",
    "pydantic-settings>=2.5",
    "websockets>=13.0",
]

[project.scripts]
sunzulab-mcp = "sunzulab_mcp:main"

[dependency-groups]
dev = [
    "pytest>=8.0",
    "pytest-asyncio>=0.24",
    "respx>=0.21",
    "pytest-cov>=5.0",
    "ruff>=0.6",
    "mypy>=1.11",
]
```

## What NOT to Install

| Library | Why Not |
|---------|---------|
| `click` / `typer` | MCP servers don't need CLI argument parsing. The server reads config from env vars and communicates over stdio. |
| `fastapi` / `flask` | This is not a web server. MCP uses stdio transport (or SSE, handled by the SDK). |
| `sqlalchemy` / any ORM | No local database. All data comes from the SunzuLab API. |
| `celery` / task queues | No background job processing needed. Snapshot mode is request-response. Alerts are API-managed. |
| `openapi-python-client` | Auto-generated API clients add complexity without value for 10-30 known endpoints. |
| `python-dotenv` | Redundant with `pydantic-settings` which handles `.env` files natively. |
| `tenacity` | httpx has built-in retry via transports. For simple retry logic, a 10-line wrapper is cleaner than a dependency. |

## Version Verification Notes

Versions listed are based on training data through May 2025. Before implementation:

1. Run `uv pip compile` to resolve latest compatible versions
2. Check MCP SDK changelog for breaking changes between 1.6 and current
3. Verify `websockets` v13+ API stability (the library had breaking API changes between v10-v12)

The MCP Python SDK was evolving rapidly in early 2025. Pin to a specific minor version after verifying the current release.

## Sources

- MCP Python SDK: https://github.com/modelcontextprotocol/python-sdk (training data, MEDIUM confidence on exact version)
- httpx: https://www.python-httpx.org/ (well-established, HIGH confidence)
- Pydantic v2: https://docs.pydantic.dev/ (well-established, HIGH confidence)
- uv/uvx: https://docs.astral.sh/uv/ (well-established, HIGH confidence)
- websockets: https://websockets.readthedocs.io/ (well-established, MEDIUM confidence on version)
