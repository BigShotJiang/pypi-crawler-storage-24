# Roadmap: SunzuLab MCP Server

## Overview

This roadmap delivers a Python MCP server that wraps SunzuLab's crypto market data API, enabling LLM clients to query historical data, discover available markets, manage alerts, and follow guided analysis workflows -- all through natural language. The journey starts with a working server skeleton and protocol compliance, adds the core data query tools that represent the primary value, layers on alert management, and finishes with LLM-specific enhancements (Resources, guided prompts, tool chaining guidance).

## Phases

**Phase Numbering:**
- Integer phases (1, 2, 3): Planned milestone work
- Decimal phases (2.1, 2.2): Urgent insertions (marked with INSERTED)

Decimal phases appear between their surrounding integers in numeric order.

- [x] **Phase 1: Foundation & Discovery** - Working MCP server with auth, protocol compliance, and basic discovery tools (completed 2026-03-14)
- [ ] **Phase 2: Data Query** - Core data retrieval tools (OHLCV, trades, order book, indicators) with LLM-optimized formatting
- [ ] **Phase 3: Alert Management** - Alert CRUD operations (create, list, modify/delete)
- [ ] **Phase 4: LLM Integration & Polish** - MCP Resources, guided workflow prompts, and tool description refinement

## Phase Details

### Phase 1: Foundation & Discovery
**Goal**: Users can install the server, authenticate, and explore available exchanges, pairs, and data types through their LLM client
**Depends on**: Nothing (first phase)
**Requirements**: SETUP-01, SETUP-02, SETUP-03, SETUP-04, PROT-01, PROT-02, PROT-03, PROT-04, DISC-01, DISC-02, DISC-03
**Success Criteria** (what must be TRUE):
  1. User can install via `uvx sunzulab-mcp` and the server starts without errors
  2. User can configure their LLM client by pasting a JSON config block and setting `SUNZU_API_TOKEN`
  3. User receives a clear, actionable error message when their token is missing, invalid, or expired
  4. User can ask "what exchanges are available?" and get a correct list from the LLM
  5. User can ask "what pairs are on Binance?" and get a correct list of trading pairs
**Plans:** 2/2 plans complete

Plans:
- [x] 01-01-PLAN.md -- Project scaffolding, API client with auth, server skeleton, test infrastructure
- [x] 01-02-PLAN.md -- Historical data tools (get_historical_data, search_historical_data) with formatting and human verification

### Phase 2: Data Query
**Goal**: Users can retrieve historical market data (OHLCV, trades, order books, indicators) through natural language and receive concise, LLM-friendly responses
**Depends on**: Phase 1
**Requirements**: DATA-01, DATA-02, DATA-03, DATA-04, DATA-05, DATA-06
**Success Criteria** (what must be TRUE):
  1. User can ask "show me BTC/USDT hourly candles on Binance for last week" and get formatted OHLCV data
  2. User can ask for order book snapshots and receive a readable depth summary, not raw JSON
  3. User can request a large dataset and receives paginated results with summary statistics (count, avg, min, max)
  4. All data tool responses are token-efficient (compact tables) rather than verbose JSON arrays
**Plans**: TBD

Plans:
- [ ] 02-01: TBD
- [ ] 02-02: TBD

### Phase 3: Alert Management
**Goal**: Users can create, view, and manage price/indicator alerts through their LLM client
**Depends on**: Phase 1
**Requirements**: ALRT-01, ALRT-02, ALRT-03
**Success Criteria** (what must be TRUE):
  1. User can say "alert me when BTC drops below 60k on Binance" and an alert is created
  2. User can ask "what alerts do I have?" and see a list of their active alerts
  3. User can delete or modify an existing alert by describing it in natural language
**Plans**: TBD

Plans:
- [ ] 03-01: TBD

### Phase 4: LLM Integration & Polish
**Goal**: The server provides metadata browsing, guided workflows, and tool descriptions that help LLMs chain tools effectively
**Depends on**: Phase 2, Phase 3
**Requirements**: DISC-04, DISC-05, FLOW-01
**Success Criteria** (what must be TRUE):
  1. LLM client can browse exchange and pair catalogs via MCP Resources without making tool calls
  2. Tool descriptions include "when to use" and "chain with" guidance that helps the LLM select the right tool for ambiguous queries
  3. User can invoke a guided prompt (e.g., market overview) and the LLM executes a multi-step analysis workflow
**Plans**: TBD

Plans:
- [ ] 04-01: TBD

## Progress

**Execution Order:**
Phases execute in numeric order: 1 -> 2 -> 3 -> 4
Note: Phase 3 depends only on Phase 1, so it could execute in parallel with Phase 2 if needed.

| Phase | Plans Complete | Status | Completed |
|-------|----------------|--------|-----------|
| 1. Foundation & Discovery | 2/2 | Complete   | 2026-03-14 |
| 2. Data Query | 0/2 | Not started | - |
| 3. Alert Management | 0/1 | Not started | - |
| 4. LLM Integration & Polish | 0/1 | Not started | - |
