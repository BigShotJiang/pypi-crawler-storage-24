from __future__ import annotations


def format_bullet_list(title: str, items: list[str]) -> str:
    count = len(items)
    if count == 0:
        return f"0 {title} found."
    lines = [f"{count} {title}:", ""]
    lines.extend(f"- {item}" for item in items)
    return "\n".join(lines)


def format_compact_list(title: str, items: list[str]) -> str:
    count = len(items)
    if count == 0:
        return f"0 {title} found."
    return f"{count} {title}: {', '.join(items)}"


def format_historical_data(
    venue: str, instrument: str, indicator_type: str, rows: list | None
) -> str:
    if not rows:
        return f"No {indicator_type} data found for {instrument} on {venue}."

    count = len(rows)
    header = f"{count} {indicator_type} records for {instrument} on {venue}"

    if count == 0:
        return f"{header}: none."

    sample = rows[0]
    keys = list(sample.keys())

    lines = [f"{header}:", ""]
    lines.append(" | ".join(keys))
    lines.append(" | ".join("---" for _ in keys))
    for row in rows:
        lines.append(" | ".join(str(row.get(k, "")) for k in keys))

    return "\n".join(lines)
