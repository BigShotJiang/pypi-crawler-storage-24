from __future__ import annotations

import os
from dataclasses import dataclass
from urllib.parse import quote

import httpx


@dataclass
class ApiResult:
    is_error: bool
    message: str
    data: list | dict | None = None


class SunzuLabClient:
    def __init__(self, http_client: httpx.AsyncClient) -> None:
        self._http = http_client

    def _get_auth_headers(self) -> dict[str, str]:
        token = os.environ.get("SUNZU_API_TOKEN")
        if not token:
            raise ValueError(
                "No API token found. Set SUNZU_API_TOKEN in your MCP client config. "
                "Get your token at https://app.sunzulab.com/settings/api."
            )
        return {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
        }

    def _base_url(self) -> str:
        return os.environ.get("SUNZU_API_URL", "https://api.mojo.sunzulab.com")

    def _referential_url(self) -> str:
        return os.environ.get(
            "SUNZU_REFERENTIAL_URL", "https://referential.mojo.sunzulab.com"
        )

    async def _handle_response(self, response: httpx.Response) -> ApiResult:
        response.raise_for_status()
        return ApiResult(is_error=False, message="ok", data=response.json())

    async def _request(
        self,
        method: str,
        path: str,
        *,
        base_url: str | None = None,
        params: dict | None = None,
        json_body: dict | None = None,
    ) -> ApiResult:
        headers = self._get_auth_headers()
        url = f"{base_url or self._base_url()}{path}"
        if params:
            qs = "&".join(
                f"{k}={quote(str(v), safe=':')}" for k, v in params.items()
            )
            url = f"{url}?{qs}"
        try:
            response = await self._http.request(
                method, url, headers=headers, json=json_body
            )
            return await self._handle_response(response)
        except httpx.HTTPStatusError as e:
            if e.response.status_code == 401:
                return ApiResult(
                    is_error=True,
                    message=(
                        "Your API token is invalid or expired. "
                        "Get a new one at https://app.sunzulab.com/settings/api."
                    ),
                )
            if e.response.status_code == 403:
                return ApiResult(
                    is_error=True,
                    message=(
                        "Your account doesn't have access to this resource. "
                        "Contact support or check your subscription."
                    ),
                )
            return ApiResult(
                is_error=True,
                message=f"API request failed (HTTP {e.response.status_code}). Please try again later.",
            )
        except httpx.ConnectError:
            return ApiResult(
                is_error=True,
                message=(
                    "Could not reach the SunzuLab API. "
                    "Check your internet connection and try again."
                ),
            )
        except httpx.TimeoutException:
            return ApiResult(
                is_error=True,
                message="The request to SunzuLab API timed out. Please try again.",
            )

    async def fetch_historical_bucket(
        self,
        venue: str,
        instrument: str,
        indicator_type: str,
        *,
        bucket: str | None = None,
        from_date: str | None = None,
        to_date: str | None = None,
        mode: str | None = None,
    ) -> ApiResult:
        params: dict[str, str] = {}
        if bucket:
            params["bucket"] = bucket
        if from_date:
            params["from"] = from_date
        if to_date:
            params["to"] = to_date
        if mode:
            params["mode"] = mode
        return await self._request(
            "GET",
            f"/v1/historical/bucket/{venue}/{instrument}/{indicator_type}",
            params=params or None,
        )

    async def search_historical_aggregated(
        self,
        instrument_venues: list[dict[str, str]],
        indicator_type: str,
        *,
        bucket: str | None = None,
        from_date: str | None = None,
        to_date: str | None = None,
        mode: str | None = None,
    ) -> ApiResult:
        body: dict = {
            "instrumentVenues": instrument_venues,
            "indicatorType": indicator_type,
        }
        if bucket:
            body["bucket"] = bucket
        if from_date:
            body["from"] = from_date
        if to_date:
            body["to"] = to_date
        if mode:
            body["mode"] = mode
        return await self._request(
            "POST",
            "/v1/historical/bucket/aggregated/search",
            json_body=body,
        )

    async def fetch_referential(self) -> ApiResult:
        return await self._request(
            "GET",
            "/config/crypto/GENERIC",
            base_url=self._referential_url(),
        )
