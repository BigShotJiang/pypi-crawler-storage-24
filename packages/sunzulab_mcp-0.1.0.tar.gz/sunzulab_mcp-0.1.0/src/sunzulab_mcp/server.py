from __future__ import annotations

import logging
import sys
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from dataclasses import dataclass
from typing import Annotated

import httpx
from mcp.server.fastmcp import Context, FastMCP
from pydantic import Field

from .client import SunzuLabClient
from .formatting import format_bullet_list, format_compact_list, format_historical_data

logging.basicConfig(stream=sys.stderr, level=logging.INFO)
logger = logging.getLogger("sunzulab-mcp")


@dataclass
class AppContext:
    client: SunzuLabClient


@asynccontextmanager
async def app_lifespan(server: FastMCP) -> AsyncIterator[AppContext]:
    async with httpx.AsyncClient(timeout=30.0) as http:
        yield AppContext(client=SunzuLabClient(http))


mcp = FastMCP("sunzulab", lifespan=app_lifespan)


async def _fetch_referential(client: SunzuLabClient) -> dict:
    result = await client.fetch_referential()
    if result.is_error:
        raise ValueError(result.message)
    return result.data


async def _list_exchanges(client: SunzuLabClient) -> str:
    data = await _fetch_referential(client)
    available = data.get("crypto", {}).get("available", {})
    venues: set[str] = set()
    for info in available.values():
        venues.update(info.get("venues", []))
    return format_bullet_list("exchanges", sorted(venues))


async def _list_pairs(client: SunzuLabClient, exchange: str) -> str:
    data = await _fetch_referential(client)
    available = data.get("crypto", {}).get("available", {})
    pairs = [
        instrument
        for instrument, info in available.items()
        if exchange.lower() in (v.lower() for v in info.get("venues", []))
    ]
    if not pairs:
        return (
            f"No pairs found for '{exchange}'. "
            "Use list_exchanges to see available exchanges."
        )
    return format_compact_list("pairs", sorted(pairs))


@mcp.tool()
async def list_exchanges(ctx: Context) -> str:
    """List all available cryptocurrency exchanges.

    Returns the exchanges (venues) where SunzuLab collects market data.
    Use this to discover which exchanges you can query for trading pairs and data.
    """
    client = ctx.request_context.lifespan_context.client
    return await _list_exchanges(client)


@mcp.tool()
async def list_pairs(
    exchange: Annotated[
        str, Field(description="Exchange name (e.g., 'binance-spot', 'coinbase-pro')")
    ],
    ctx: Context,
) -> str:
    """List available trading pairs for a given exchange.

    Returns the trading pairs (e.g., btc-usdt) available on the specified exchange.
    Use list_exchanges first to see which exchanges are available.
    """
    client = ctx.request_context.lifespan_context.client
    return await _list_pairs(client, exchange)


async def _get_historical(
    client: SunzuLabClient,
    venue: str,
    instrument: str,
    indicator_type: str,
    bucket: str | None = None,
    from_date: str | None = None,
    to_date: str | None = None,
    mode: str | None = None,
) -> str:
    result = await client.fetch_historical_bucket(
        venue,
        instrument,
        indicator_type,
        bucket=bucket,
        from_date=from_date,
        to_date=to_date,
        mode=mode,
    )
    if result.is_error:
        raise ValueError(result.message)
    return format_historical_data(venue, instrument, indicator_type, result.data)


async def _search_historical(
    client: SunzuLabClient,
    venues_instruments: list[dict[str, str]],
    indicator_type: str,
    bucket: str | None = None,
    from_date: str | None = None,
    to_date: str | None = None,
    mode: str | None = None,
) -> str:
    result = await client.search_historical_aggregated(
        venues_instruments,
        indicator_type,
        bucket=bucket,
        from_date=from_date,
        to_date=to_date,
        mode=mode,
    )
    if result.is_error:
        raise ValueError(result.message)
    return format_historical_data("multiple", "multiple", indicator_type, result.data)


@mcp.tool()
async def get_historical_data(
    venue: Annotated[str, Field(description="Exchange/venue name (e.g., 'binance-spot', 'coinbase-pro')")],
    instrument: Annotated[str, Field(description="Trading pair in uppercase dash format (e.g., 'BTC-USDT', 'ETH-USD')")],
    indicator_type: Annotated[str, Field(description="Indicator type (e.g., 'bar', 'spread', 'trade_volume', 'market_depth_mmm')")],
    ctx: Context,
    bucket: Annotated[str | None, Field(description="Time bucket/interval (e.g., '5 minute', '1 hour', '1 day')")] = None,
    from_date: Annotated[str | None, Field(description="Start date (ISO datetime, e.g., '2024-01-01T00:00Z')")] = None,
    to_date: Annotated[str | None, Field(description="End date (ISO datetime, e.g., '2024-12-31T23:59Z')")] = None,
    mode: Annotated[str | None, Field(description="Bucket mode: 'LAST' or 'AVERAGE'")] = None,
) -> str:
    """Get historical market data for a specific venue, instrument, and indicator.

    Returns time-series data for a trading pair on a given exchange.
    Use bucket parameter to control the time interval.

    Available indicator types and their returned fields:
    - bar: OHLCV candles (open, high, low, close, nbTrade, totalVolume, vwap)
    - spread: bid-ask spread in basis points (spread)
    - trade_volume: traded volume in quote currency (tradeVolume)
    - market_depth_mmm: order book depth at price levels
      (mdAsk2p5, mdAsk5, mdAsk10, mdAsk25, mdAsk50, mdAsk100, mdAsk200,
       mdBid2p5, mdBid5, mdBid10, mdBid25, mdBid50, mdBid100, mdBid200,
       baskPrice, baskQuantity, bbidPrice, bbidQuantity)
    """
    client = ctx.request_context.lifespan_context.client
    return await _get_historical(
        client, venue, instrument, indicator_type,
        bucket=bucket, from_date=from_date, to_date=to_date, mode=mode,
    )


@mcp.tool()
async def search_historical_data(
    venues_instruments: Annotated[
        str,
        Field(description="Comma-separated venue:instrument pairs (e.g., 'binance-spot:BTC-USDT,coinbase-pro:BTC-USD')"),
    ],
    indicator_type: Annotated[str, Field(description="Indicator type (e.g., 'bar', 'spread', 'trade_volume', 'market_depth_mmm')")],
    ctx: Context,
    bucket: Annotated[str | None, Field(description="Time bucket/interval (e.g., '5 minute', '1 hour', '1 day')")] = None,
    from_date: Annotated[str | None, Field(description="Start date (ISO datetime, e.g., '2024-01-01T00:00Z')")] = None,
    to_date: Annotated[str | None, Field(description="End date (ISO datetime, e.g., '2024-12-31T23:59Z')")] = None,
    mode: Annotated[str | None, Field(description="Bucket mode: 'LAST' or 'AVERAGE'")] = None,
) -> str:
    """Search historical data across multiple venue/instrument pairs at once.

    Aggregated search for comparing the same indicator across different exchanges
    or trading pairs. Provide pairs as comma-separated venue:instrument values.

    Available indicator types and their returned fields:
    - bar: OHLCV candles (open, high, low, close, nbTrade, totalVolume, vwap)
    - spread: bid-ask spread in basis points (spread)
    - trade_volume: traded volume in quote currency (tradeVolume)
    - market_depth_mmm: order book depth at price levels
      (mdAsk/mdBid at 2.5, 5, 10, 25, 50, 100, 200 bps,
       baskPrice, baskQuantity, bbidPrice, bbidQuantity)
    """
    pairs = []
    for pair in venues_instruments.split(","):
        pair = pair.strip()
        if ":" not in pair:
            raise ValueError(
                f"Invalid format '{pair}'. Use 'venue:instrument' (e.g., 'binance:BTC/USDT')."
            )
        v, i = pair.split(":", 1)
        pairs.append({"venue": v.strip(), "instrument": i.strip()})
    client = ctx.request_context.lifespan_context.client
    return await _search_historical(
        client, pairs, indicator_type,
        bucket=bucket, from_date=from_date, to_date=to_date, mode=mode,
    )


def main():
    mcp.run()
