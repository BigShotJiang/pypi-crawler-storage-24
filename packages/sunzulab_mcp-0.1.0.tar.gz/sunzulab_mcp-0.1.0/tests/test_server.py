import httpx
import pytest
import respx
from mcp.server.fastmcp import FastMCP

from sunzulab_mcp.server import main, mcp
from tests.conftest import MOCK_HISTORICAL_DATA, MOCK_REFERENTIAL


BASE_URL = "https://test.api"
REF_URL = "https://test.ref"


class TestServerSkeleton:
    def test_main_entry_point_exists(self):
        assert callable(main)

    def test_mcp_instance_exists(self):
        assert isinstance(mcp, FastMCP)

    def test_server_name(self):
        assert mcp.name == "sunzulab"


class TestToolSchemas:
    def _get_tool(self, name: str):
        tools = mcp._tool_manager._tools
        assert name in tools, f"Tool '{name}' not registered"
        return tools[name]

    def test_list_exchanges_schema(self):
        tool = self._get_tool("list_exchanges")
        schema = tool.parameters
        required = schema.get("required", [])
        assert "exchange" not in required

    def test_list_pairs_schema(self):
        tool = self._get_tool("list_pairs")
        schema = tool.parameters
        assert "exchange" in schema.get("required", [])
        assert schema["properties"]["exchange"]["type"] == "string"

    def test_get_historical_data_schema(self):
        tool = self._get_tool("get_historical_data")
        schema = tool.parameters
        required = schema.get("required", [])
        assert "venue" in required
        assert "instrument" in required
        assert "indicator_type" in required

    def test_search_historical_data_schema(self):
        tool = self._get_tool("search_historical_data")
        schema = tool.parameters
        required = schema.get("required", [])
        assert "venues_instruments" in required
        assert "indicator_type" in required


class TestListExchanges:
    @respx.mock
    async def test_returns_sorted_venues(self, mock_env_token, monkeypatch):
        monkeypatch.setenv("SUNZU_REFERENTIAL_URL", REF_URL)
        respx.get(f"{REF_URL}/config/crypto/GENERIC").mock(
            return_value=httpx.Response(200, json=MOCK_REFERENTIAL)
        )
        from sunzulab_mcp.client import SunzuLabClient
        from sunzulab_mcp.server import _list_exchanges

        async with httpx.AsyncClient() as http:
            client = SunzuLabClient(http)
            result = await _list_exchanges(client)
        assert "3 exchanges:" in result
        assert "- binance-spot" in result
        assert "- coinbase-pro" in result
        assert "- kraken" in result


class TestListPairs:
    @respx.mock
    async def test_returns_pairs_for_exchange(self, mock_env_token, monkeypatch):
        monkeypatch.setenv("SUNZU_REFERENTIAL_URL", REF_URL)
        respx.get(f"{REF_URL}/config/crypto/GENERIC").mock(
            return_value=httpx.Response(200, json=MOCK_REFERENTIAL)
        )
        from sunzulab_mcp.client import SunzuLabClient
        from sunzulab_mcp.server import _list_pairs

        async with httpx.AsyncClient() as http:
            client = SunzuLabClient(http)
            result = await _list_pairs(client, "binance-spot")
        assert "2 pairs:" in result
        assert "btc-usdt" in result
        assert "eth-usdt" in result

    @respx.mock
    async def test_unknown_exchange(self, mock_env_token, monkeypatch):
        monkeypatch.setenv("SUNZU_REFERENTIAL_URL", REF_URL)
        respx.get(f"{REF_URL}/config/crypto/GENERIC").mock(
            return_value=httpx.Response(200, json=MOCK_REFERENTIAL)
        )
        from sunzulab_mcp.client import SunzuLabClient
        from sunzulab_mcp.server import _list_pairs

        async with httpx.AsyncClient() as http:
            client = SunzuLabClient(http)
            result = await _list_pairs(client, "nonexistent")
        assert "no pairs" in result.lower()
        assert "list_exchanges" in result.lower()

    @respx.mock
    async def test_case_insensitive(self, mock_env_token, monkeypatch):
        monkeypatch.setenv("SUNZU_REFERENTIAL_URL", REF_URL)
        respx.get(f"{REF_URL}/config/crypto/GENERIC").mock(
            return_value=httpx.Response(200, json=MOCK_REFERENTIAL)
        )
        from sunzulab_mcp.client import SunzuLabClient
        from sunzulab_mcp.server import _list_pairs

        async with httpx.AsyncClient() as http:
            client = SunzuLabClient(http)
            result = await _list_pairs(client, "Binance-Spot")
        assert "2 pairs:" in result


class TestGetHistoricalData:
    @respx.mock
    async def test_returns_formatted(self, mock_env_token, monkeypatch):
        monkeypatch.setenv("SUNZU_API_URL", BASE_URL)
        respx.get(f"{BASE_URL}/v1/historical/bucket/binance/BTC-USDT/ohlcv").mock(
            return_value=httpx.Response(200, json=MOCK_HISTORICAL_DATA)
        )
        from sunzulab_mcp.client import SunzuLabClient
        from sunzulab_mcp.server import _get_historical

        async with httpx.AsyncClient() as http:
            client = SunzuLabClient(http)
            result = await _get_historical(client, "binance", "BTC-USDT", "ohlcv")
        assert "3 ohlcv records" in result
        assert "binance" in result
        assert "42000" in result

    @respx.mock
    async def test_empty_data(self, mock_env_token, monkeypatch):
        monkeypatch.setenv("SUNZU_API_URL", BASE_URL)
        respx.get(f"{BASE_URL}/v1/historical/bucket/binance/BTC-USDT/ohlcv").mock(
            return_value=httpx.Response(200, json=[])
        )
        from sunzulab_mcp.client import SunzuLabClient
        from sunzulab_mcp.server import _get_historical

        async with httpx.AsyncClient() as http:
            client = SunzuLabClient(http)
            result = await _get_historical(client, "binance", "BTC-USDT", "ohlcv")
        assert "no ohlcv data" in result.lower()

    @respx.mock
    async def test_passes_optional_params(self, mock_env_token, monkeypatch):
        monkeypatch.setenv("SUNZU_API_URL", BASE_URL)
        route = respx.get(f"{BASE_URL}/v1/historical/bucket/binance/BTC-USDT/ohlcv").mock(
            return_value=httpx.Response(200, json=MOCK_HISTORICAL_DATA)
        )
        from sunzulab_mcp.client import SunzuLabClient
        from sunzulab_mcp.server import _get_historical

        async with httpx.AsyncClient() as http:
            client = SunzuLabClient(http)
            await _get_historical(
                client, "binance", "BTC-USDT", "ohlcv",
                bucket="1d", from_date="2024-01-01",
            )
        request = route.calls.last.request
        assert "bucket=1d" in str(request.url)
        assert "from=2024-01-01" in str(request.url)


class TestSearchHistoricalData:
    @respx.mock
    async def test_returns_formatted(self, mock_env_token, monkeypatch):
        monkeypatch.setenv("SUNZU_API_URL", BASE_URL)
        respx.post(f"{BASE_URL}/v1/historical/bucket/aggregated/search").mock(
            return_value=httpx.Response(200, json=MOCK_HISTORICAL_DATA)
        )
        from sunzulab_mcp.client import SunzuLabClient
        from sunzulab_mcp.server import _search_historical

        async with httpx.AsyncClient() as http:
            client = SunzuLabClient(http)
            result = await _search_historical(
                client,
                [{"venue": "binance", "instrument": "BTC-USDT"}],
                "ohlcv",
            )
        assert "3 ohlcv records" in result


class TestToolAuthError:
    @respx.mock
    async def test_missing_token_raises(self, mock_env_no_token):
        from sunzulab_mcp.client import SunzuLabClient
        from sunzulab_mcp.server import _get_historical

        async with httpx.AsyncClient() as http:
            client = SunzuLabClient(http)
            with pytest.raises(ValueError, match="SUNZU_API_TOKEN"):
                await _get_historical(client, "binance", "BTC-USDT", "ohlcv")

    @respx.mock
    async def test_api_auth_error_raises(self, mock_env_token, monkeypatch):
        monkeypatch.setenv("SUNZU_API_URL", BASE_URL)
        respx.get(f"{BASE_URL}/v1/historical/bucket/binance/BTC-USDT/ohlcv").mock(
            return_value=httpx.Response(401)
        )
        from sunzulab_mcp.client import SunzuLabClient
        from sunzulab_mcp.server import _get_historical

        async with httpx.AsyncClient() as http:
            client = SunzuLabClient(http)
            with pytest.raises(ValueError, match="invalid or expired"):
                await _get_historical(client, "binance", "BTC-USDT", "ohlcv")
