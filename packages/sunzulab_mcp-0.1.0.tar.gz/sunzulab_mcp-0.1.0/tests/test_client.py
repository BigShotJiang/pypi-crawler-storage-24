import httpx
import pytest
import respx

from sunzulab_mcp.client import SunzuLabClient
from tests.conftest import MOCK_HISTORICAL_DATA, MOCK_REFERENTIAL


BASE_URL = "https://api.mojo.sunzulab.com"
REF_URL = "https://referential.mojo.sunzulab.com"


class TestGetAuthHeaders:
    def test_returns_bearer_when_token_set(self, mock_env_token):
        client = SunzuLabClient(httpx.AsyncClient())
        headers = client._get_auth_headers()
        assert headers == {
            "Authorization": "Bearer test-token-abc123",
            "Content-Type": "application/json",
        }

    def test_raises_when_token_missing(self, mock_env_no_token):
        client = SunzuLabClient(httpx.AsyncClient())
        with pytest.raises(ValueError, match="Set SUNZU_API_TOKEN"):
            client._get_auth_headers()

    def test_error_message_includes_url(self, mock_env_no_token):
        client = SunzuLabClient(httpx.AsyncClient())
        with pytest.raises(ValueError, match="Get your token at"):
            client._get_auth_headers()


class TestHistoricalBucket:
    @respx.mock
    async def test_sends_auth_header(self, mock_env_token):
        route = respx.get(f"{BASE_URL}/v1/historical/bucket/binance/BTC-USDT/ohlcv").mock(
            return_value=httpx.Response(200, json=MOCK_HISTORICAL_DATA)
        )
        async with httpx.AsyncClient() as http:
            client = SunzuLabClient(http)
            await client.fetch_historical_bucket("binance", "BTC-USDT", "ohlcv")
        assert route.called
        request = route.calls.last.request
        assert request.headers["Authorization"] == "Bearer test-token-abc123"

    @respx.mock
    async def test_passes_query_params(self, mock_env_token):
        route = respx.get(f"{BASE_URL}/v1/historical/bucket/binance/BTC-USDT/ohlcv").mock(
            return_value=httpx.Response(200, json=MOCK_HISTORICAL_DATA)
        )
        async with httpx.AsyncClient() as http:
            client = SunzuLabClient(http)
            await client.fetch_historical_bucket(
                "binance", "BTC-USDT", "ohlcv",
                bucket="1d", from_date="2024-01-01", to_date="2024-01-31", mode="LAST",
            )
        request = route.calls.last.request
        assert "bucket=1d" in str(request.url)
        assert "from=2024-01-01" in str(request.url)
        assert "to=2024-01-31" in str(request.url)
        assert "mode=LAST" in str(request.url)

    @respx.mock
    async def test_returns_data(self, mock_env_token):
        respx.get(f"{BASE_URL}/v1/historical/bucket/binance/BTC-USDT/ohlcv").mock(
            return_value=httpx.Response(200, json=MOCK_HISTORICAL_DATA)
        )
        async with httpx.AsyncClient() as http:
            client = SunzuLabClient(http)
            result = await client.fetch_historical_bucket("binance", "BTC-USDT", "ohlcv")
        assert result.is_error is False
        assert len(result.data) == 3

    @respx.mock
    async def test_auth_error_401(self, mock_env_token):
        respx.get(f"{BASE_URL}/v1/historical/bucket/binance/BTC-USDT/ohlcv").mock(
            return_value=httpx.Response(401)
        )
        async with httpx.AsyncClient() as http:
            client = SunzuLabClient(http)
            result = await client.fetch_historical_bucket("binance", "BTC-USDT", "ohlcv")
        assert result.is_error is True
        assert "invalid or expired" in result.message.lower()

    @respx.mock
    async def test_network_error(self, mock_env_token):
        respx.get(f"{BASE_URL}/v1/historical/bucket/binance/BTC-USDT/ohlcv").mock(
            side_effect=httpx.ConnectError("Connection refused")
        )
        async with httpx.AsyncClient() as http:
            client = SunzuLabClient(http)
            result = await client.fetch_historical_bucket("binance", "BTC-USDT", "ohlcv")
        assert result.is_error is True
        assert "reach" in result.message.lower()


class TestHistoricalAggregated:
    @respx.mock
    async def test_sends_post_with_body(self, mock_env_token):
        route = respx.post(f"{BASE_URL}/v1/historical/bucket/aggregated/search").mock(
            return_value=httpx.Response(200, json=MOCK_HISTORICAL_DATA)
        )
        async with httpx.AsyncClient() as http:
            client = SunzuLabClient(http)
            await client.search_historical_aggregated(
                [{"venue": "binance", "instrument": "BTC-USDT"}],
                "ohlcv",
                bucket="1d",
            )
        assert route.called
        import json
        body = json.loads(route.calls.last.request.content)
        assert body["indicatorType"] == "ohlcv"
        assert body["bucket"] == "1d"
        assert body["instrumentVenues"] == [{"venue": "binance", "instrument": "BTC-USDT"}]


class TestReferential:
    @respx.mock
    async def test_fetches_from_referential_host(self, mock_env_token):
        route = respx.get(f"{REF_URL}/config/crypto/GENERIC").mock(
            return_value=httpx.Response(200, json=MOCK_REFERENTIAL)
        )
        async with httpx.AsyncClient() as http:
            client = SunzuLabClient(http)
            result = await client.fetch_referential()
        assert route.called
        assert result.is_error is False
        assert "crypto" in result.data

    @respx.mock
    async def test_configurable_referential_url(self, mock_env_token, monkeypatch):
        monkeypatch.setenv("SUNZU_REFERENTIAL_URL", "https://ref.staging.sunzulab.com")
        route = respx.get("https://ref.staging.sunzulab.com/config/crypto/GENERIC").mock(
            return_value=httpx.Response(200, json=MOCK_REFERENTIAL)
        )
        async with httpx.AsyncClient() as http:
            client = SunzuLabClient(http)
            await client.fetch_referential()
        assert route.called

    @respx.mock
    async def test_auth_error(self, mock_env_token):
        respx.get(f"{REF_URL}/config/crypto/GENERIC").mock(
            return_value=httpx.Response(401)
        )
        async with httpx.AsyncClient() as http:
            client = SunzuLabClient(http)
            result = await client.fetch_referential()
        assert result.is_error is True
        assert "invalid or expired" in result.message.lower()


class TestGatewayUrl:
    @respx.mock
    async def test_configurable_base_url(self, mock_env_token, monkeypatch):
        monkeypatch.setenv("SUNZU_API_URL", "https://staging.sunzulab.com")
        route = respx.get("https://staging.sunzulab.com/v1/historical/bucket/binance/BTC-USDT/ohlcv").mock(
            return_value=httpx.Response(200, json=MOCK_HISTORICAL_DATA)
        )
        async with httpx.AsyncClient() as http:
            client = SunzuLabClient(http)
            await client.fetch_historical_bucket("binance", "BTC-USDT", "ohlcv")
        assert route.called
