import pytest


MOCK_REFERENTIAL = {
    "crypto": {
        "available": {
            "btc-usdt": {
                "venues": ["binance-spot", "coinbase-pro", "kraken"],
                "significant": 5,
            },
            "eth-usdt": {
                "venues": ["binance-spot", "kraken"],
                "significant": 5,
            },
            "btc-usd": {
                "venues": ["coinbase-pro", "kraken"],
                "significant": 5,
            },
        },
        "translation": {"btc": "bitcoin", "eth": "ethereum"},
    },
    "colors": {},
}


MOCK_HISTORICAL_DATA = [
    {"ts": "2024-01-01T00:00:00Z", "open": 42000, "high": 42500, "low": 41800, "close": 42300, "volume": 150.5},
    {"ts": "2024-01-02T00:00:00Z", "open": 42300, "high": 43000, "low": 42100, "close": 42800, "volume": 200.3},
    {"ts": "2024-01-03T00:00:00Z", "open": 42800, "high": 43200, "low": 42600, "close": 43100, "volume": 175.8},
]


@pytest.fixture
def mock_env_token(monkeypatch):
    monkeypatch.setenv("SUNZU_API_TOKEN", "test-token-abc123")


@pytest.fixture
def mock_env_no_token(monkeypatch):
    monkeypatch.delenv("SUNZU_API_TOKEN", raising=False)
