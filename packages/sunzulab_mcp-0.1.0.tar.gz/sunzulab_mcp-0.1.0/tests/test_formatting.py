from sunzulab_mcp.formatting import (
    format_bullet_list,
    format_compact_list,
    format_historical_data,
)


class TestFormatBulletList:
    def test_multiple_items(self):
        result = format_bullet_list("exchanges", ["Binance", "Coinbase"])
        assert result == "2 exchanges:\n\n- Binance\n- Coinbase"

    def test_empty_list(self):
        result = format_bullet_list("exchanges", [])
        assert result == "0 exchanges found."

    def test_single_item(self):
        result = format_bullet_list("data types", ["OHLCV"])
        assert result == "1 data types:\n\n- OHLCV"


class TestFormatCompactList:
    def test_multiple_items(self):
        result = format_compact_list("pairs", ["BTC/USDT", "ETH/USDT"])
        assert result == "2 pairs: BTC/USDT, ETH/USDT"

    def test_empty_list(self):
        result = format_compact_list("pairs", [])
        assert result == "0 pairs found."


class TestFormatHistoricalData:
    def test_formats_rows(self):
        rows = [
            {"ts": "2024-01-01", "open": 42000, "close": 42300},
            {"ts": "2024-01-02", "open": 42300, "close": 42800},
        ]
        result = format_historical_data("binance", "BTC-USDT", "ohlcv", rows)
        assert "2 ohlcv records for BTC-USDT on binance" in result
        assert "ts | open | close" in result
        assert "2024-01-01 | 42000 | 42300" in result

    def test_empty_data(self):
        result = format_historical_data("binance", "BTC-USDT", "ohlcv", [])
        assert "no ohlcv data" in result.lower()

    def test_none_data(self):
        result = format_historical_data("binance", "BTC-USDT", "ohlcv", None)
        assert "no ohlcv data" in result.lower()
