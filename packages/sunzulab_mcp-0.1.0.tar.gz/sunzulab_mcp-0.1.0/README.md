# sunzulab-mcp

MCP server for [SunzuLab](https://sunzulab.com) crypto market data. Connects any MCP-compatible AI assistant to SunzuLab's historical market data API.

## Setup

Get your API token at [app.sunzulab.com/settings/api](https://app.sunzulab.com/settings/api).

### Claude Desktop

Add to your Claude Desktop config (`claude_desktop_config.json`):

```json
{
  "mcpServers": {
    "sunzulab": {
      "command": "uvx",
      "args": ["sunzulab-mcp"],
      "env": {
        "SUNZU_API_TOKEN": "your-token-here"
      }
    }
  }
}
```

### Claude Code

```bash
claude mcp add sunzulab -- uvx sunzulab-mcp -e SUNZU_API_TOKEN=your-token-here
```

## Tools

### list_exchanges

List all available cryptocurrency exchanges where SunzuLab collects market data.

### list_pairs

List available trading pairs for a given exchange (e.g., `binance-spot`).

### get_historical_data

Get historical market data for a specific venue, instrument, and indicator type.

Supported indicators:
- `bar` -- OHLCV candles (open, high, low, close, volume, vwap)
- `spread` -- bid-ask spread in basis points
- `trade_volume` -- traded volume in quote currency
- `market_depth_mmm` -- order book depth at various price levels

### search_historical_data

Search historical data across multiple venue/instrument pairs at once. Useful for comparing the same indicator across different exchanges or trading pairs.

## Development

```bash
git clone https://github.com/sunzulab/mcp-python.git
cd mcp-python
uv sync --dev
uv run pytest
```
