"""Direct Supabase provider for self-hosted mode."""

from __future__ import annotations
from typing import Optional, List
from datetime import datetime, timezone
import uuid
import hashlib

import json as _json

from .embeddings import get_embedding
from .types import Memory, MemoryPack, Stats


def _make_hash_id(content: str) -> str:
    h = hashlib.sha256(content.encode()).hexdigest()[:8]
    return f"clude-{h}"


class SupabaseProvider:
    def __init__(self, supabase_url: str, supabase_key: str, voyage_api_key: str, owner_wallet: str):
        self.supabase_url = supabase_url
        self.supabase_key = supabase_key
        self.voyage_api_key = voyage_api_key
        self.owner_wallet = owner_wallet
        self._client = None

    async def _get_client(self):
        if self._client is None:
            from supabase._async.client import create_client
            self._client = await create_client(self.supabase_url, self.supabase_key)
        return self._client

    async def store(
        self,
        content: str,
        summary: Optional[str] = None,
        type: str = "episodic",
        tags: Optional[List[str]] = None,
        importance: float = 0.5,
    ) -> str:
        client = await self._get_client()
        # Use summary for embedding (short text embeds better with Voyage-4-Large)
        embed_text = summary or content[:200]
        embedding = await get_embedding(embed_text, self.voyage_api_key, input_type="document")
        hash_id = _make_hash_id(content + str(uuid.uuid4()))
        now = datetime.now(timezone.utc).isoformat()

        row = {
            "content": content,
            "summary": summary or content[:200],
            "memory_type": type,
            "tags": tags or [],
            "importance": importance,
            "owner_wallet": self.owner_wallet,
            "embedding": embedding,
            "created_at": now,
            "last_accessed": now,
            "hash_id": hash_id,
            "access_count": 0,
            "decay_factor": 1.0,
            "emotional_valence": 0,
            "source": "python-sdk",
            "metadata": {},
            "evidence_ids": [],
            "concepts": [],
        }

        resp = await client.table("memories").insert(row).execute()
        # Return the auto-generated integer id as string
        return str(resp.data[0]["id"])

    async def recall(
        self,
        query: str,
        limit: int = 5,
        types: Optional[List[str]] = None,
        threshold: float = 0.3,
    ) -> List[Memory]:
        client = await self._get_client()
        embedding = await get_embedding(query, self.voyage_api_key, input_type="query")

        params = {
            "query_embedding": embedding,
            "match_threshold": threshold,
            "match_count": limit,
            "filter_owner": self.owner_wallet,
            "min_decay": 0.0,
        }
        if types:
            params["filter_types"] = types

        resp = await client.rpc("match_memories", params).execute()
        matches = resp.data or []
        if not matches:
            return []

        # RPC returns only id + similarity; fetch full rows
        ids = [m["id"] for m in matches]
        sim_map = {m["id"]: m.get("similarity") for m in matches}

        full = await client.table("memories").select("*").in_("id", ids).execute()
        memories = []
        for row in full.data or []:
            memories.append(Memory(
                id=str(row["id"]),
                content=row["content"],
                summary=row.get("summary"),
                type=row.get("memory_type", "episodic"),
                tags=row.get("tags", []),
                importance=row.get("importance", 0.5),
                owner_wallet=row.get("owner_wallet"),
                created_at=row.get("created_at"),
                similarity=sim_map.get(row["id"]),
                decay_rate=row.get("decay_factor", 1.0),
                access_count=row.get("access_count", 0),
            ))
        # Sort by similarity descending
        memories.sort(key=lambda m: m.similarity or 0, reverse=True)
        return memories

    async def forget(self, memory_id: str) -> bool:
        client = await self._get_client()
        resp = await client.table("memories").delete().eq("id", int(memory_id)).execute()
        return len(resp.data or []) > 0

    async def stats(self) -> Stats:
        client = await self._get_client()
        resp = await client.table("memories").select("id, memory_type").eq("owner_wallet", self.owner_wallet).execute()
        rows = resp.data or []
        by_type: dict = {}
        for r in rows:
            t = r.get("memory_type", "unknown")
            by_type[t] = by_type.get(t, 0) + 1
        return Stats(total_memories=len(rows), by_type=by_type, owner_wallet=self.owner_wallet)

    async def export_pack(self, query: str, limit: int = 50) -> MemoryPack:
        memories = await self.recall(query, limit=limit)
        mem_dicts = [m.to_dict() for m in memories]
        pack = MemoryPack(
            version="1.0",
            identity=self.owner_wallet,
            memories=mem_dicts,
            connections=[],
        )
        pack.content_hash = pack.compute_hash()
        return pack

    async def import_pack(self, pack: MemoryPack) -> int:
        count = 0
        for mem in pack.memories:
            await self.store(
                content=mem["content"],
                summary=mem.get("summary"),
                type=mem.get("type", "episodic"),
                tags=mem.get("tags", []),
                importance=mem.get("importance", 0.5),
            )
            count += 1
        return count

    async def close(self):
        self._client = None
