"""MemoryPack utilities."""

from .types import MemoryPack


def validate_pack(pack: MemoryPack) -> bool:
    """Validate a MemoryPack's content hash."""
    if not pack.content_hash:
        return True
    return pack.compute_hash() == pack.content_hash


def merge_packs(*packs: MemoryPack) -> MemoryPack:
    """Merge multiple MemoryPacks into one."""
    all_memories = []
    all_connections = []
    seen_ids = set()

    for pack in packs:
        for mem in pack.memories:
            mid = mem.get("id")
            if mid and mid not in seen_ids:
                seen_ids.add(mid)
                all_memories.append(mem)
        all_connections.extend(pack.connections)

    merged = MemoryPack(
        version="1.0",
        memories=all_memories,
        connections=all_connections,
    )
    merged.content_hash = merged.compute_hash()
    return merged
