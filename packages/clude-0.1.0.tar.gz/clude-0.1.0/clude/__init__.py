"""Clude — persistent memory for AI agents."""

from .client import Clude
from .types import Memory, MemoryPack, Stats
from .pack import validate_pack, merge_packs

__version__ = "0.1.0"
__all__ = ["Clude", "Memory", "MemoryPack", "Stats", "validate_pack", "merge_packs"]
