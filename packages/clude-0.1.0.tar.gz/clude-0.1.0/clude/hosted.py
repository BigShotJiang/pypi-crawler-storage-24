"""HTTP transport for hosted Clude API mode."""

from __future__ import annotations
from typing import Optional, List
import httpx

from .types import Memory, MemoryPack, Stats


class HostedProvider:
    def __init__(self, api_key: str, base_url: str = "https://clude.io"):
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self._client: Optional[httpx.AsyncClient] = None

    def _get_client(self) -> httpx.AsyncClient:
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(
                base_url=self.base_url,
                headers={"Authorization": f"Bearer {self.api_key}", "Content-Type": "application/json"},
                timeout=30,
            )
        return self._client

    async def store(self, content: str, summary: Optional[str] = None, type: str = "episodic",
                    tags: Optional[List[str]] = None, importance: float = 0.5) -> str:
        client = self._get_client()
        resp = await client.post("/api/cortex/store", json={
            "content": content, "summary": summary or content[:200], "type": type,
            "tags": tags or [], "importance": importance,
            "source": "python-sdk",
        })
        resp.raise_for_status()
        data = resp.json()
        return str(data.get("memory_id", data.get("id", "")))

    async def recall(self, query: str, limit: int = 5, types: Optional[List[str]] = None,
                     threshold: float = 0.3) -> List[Memory]:
        client = self._get_client()
        params: dict = {"query": query, "limit": limit, "threshold": threshold}
        if types:
            params["types"] = types
        resp = await client.post("/api/cortex/recall", json=params)
        resp.raise_for_status()
        return [Memory.from_dict(m) for m in resp.json().get("memories", [])]

    async def forget(self, memory_id: str) -> bool:
        client = self._get_client()
        resp = await client.delete(f"/api/cortex/memories/{memory_id}")
        resp.raise_for_status()
        return True

    async def stats(self) -> Stats:
        client = self._get_client()
        resp = await client.get("/api/cortex/stats")
        resp.raise_for_status()
        data = resp.json()
        return Stats(**data)

    async def export_pack(self, query: str, limit: int = 50) -> MemoryPack:
        client = self._get_client()
        resp = await client.post("/api/cortex/export", json={"query": query, "limit": limit})
        resp.raise_for_status()
        return MemoryPack.from_dict(resp.json())

    async def import_pack(self, pack: MemoryPack) -> int:
        client = self._get_client()
        resp = await client.post("/api/cortex/import", json=pack.to_dict())
        resp.raise_for_status()
        return resp.json().get("imported", 0)

    async def close(self):
        if self._client:
            await self._client.aclose()
            self._client = None
