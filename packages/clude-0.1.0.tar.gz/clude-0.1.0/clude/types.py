"""Type definitions for the Clude SDK."""

from __future__ import annotations
from dataclasses import dataclass, field, asdict
from typing import Optional, List, Any
from datetime import datetime
import hashlib
import json


@dataclass
class Memory:
    id: str
    content: str
    summary: Optional[str] = None
    type: str = "episodic"
    tags: List[str] = field(default_factory=list)
    importance: float = 0.5
    owner_wallet: Optional[str] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None
    decay_rate: float = 0.01
    access_count: int = 0
    similarity: Optional[float] = None

    def to_dict(self) -> dict:
        return {k: v for k, v in asdict(self).items() if v is not None}

    @classmethod
    def from_dict(cls, data: dict) -> "Memory":
        known = {f.name for f in cls.__dataclass_fields__.values()}
        return cls(**{k: v for k, v in data.items() if k in known})


@dataclass
class MemoryPack:
    version: str = "1.0"
    identity: Optional[str] = None
    memories: List[dict] = field(default_factory=list)
    connections: List[dict] = field(default_factory=list)
    content_hash: Optional[str] = None

    def compute_hash(self) -> str:
        raw = json.dumps(self.memories, sort_keys=True)
        return hashlib.sha256(raw.encode()).hexdigest()

    def to_dict(self) -> dict:
        d = {
            "version": self.version,
            "identity": self.identity,
            "memories": self.memories,
            "connections": self.connections,
            "content_hash": self.content_hash or self.compute_hash(),
        }
        return d

    @classmethod
    def from_dict(cls, data: dict) -> "MemoryPack":
        return cls(
            version=data.get("version", "1.0"),
            identity=data.get("identity"),
            memories=data.get("memories", []),
            connections=data.get("connections", []),
            content_hash=data.get("content_hash"),
        )

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), indent=2)

    @classmethod
    def from_json(cls, raw: str) -> "MemoryPack":
        return cls.from_dict(json.loads(raw))


@dataclass
class Stats:
    total_memories: int = 0
    by_type: dict = field(default_factory=dict)
    owner_wallet: Optional[str] = None
