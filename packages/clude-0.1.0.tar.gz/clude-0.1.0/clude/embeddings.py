"""Voyage AI embeddings client."""

from __future__ import annotations
from typing import List
import httpx

VOYAGE_URL = "https://api.voyageai.com/v1/embeddings"
VOYAGE_MODEL = "voyage-4-large"


async def get_embedding(text: str, api_key: str, input_type: str = "document") -> List[float]:
    """Get embedding vector for text using Voyage AI.
    
    Args:
        text: Text to embed
        api_key: Voyage API key
        input_type: "document" for storage, "query" for recall
    """
    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.post(
            VOYAGE_URL,
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            },
            json={
                "input": [text],
                "model": VOYAGE_MODEL,
                "input_type": input_type,
            },
        )
        resp.raise_for_status()
        data = resp.json()
        return data["data"][0]["embedding"]
