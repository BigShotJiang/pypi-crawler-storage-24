"""Main Clude client."""

from __future__ import annotations
from typing import Optional, List

from .types import Memory, MemoryPack, Stats


class Clude:
    """Unified client for Clude memory API.

    Hosted mode:
        brain = Clude(api_key="xxx", base_url="https://clude.io")

    Self-hosted mode:
        brain = Clude(
            supabase_url="...", supabase_key="...",
            voyage_api_key="...", owner_wallet="..."
        )
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: str = "https://clude.io",
        supabase_url: Optional[str] = None,
        supabase_key: Optional[str] = None,
        voyage_api_key: Optional[str] = None,
        owner_wallet: Optional[str] = None,
    ):
        if supabase_url and supabase_key and voyage_api_key:
            from .supabase import SupabaseProvider
            self._provider = SupabaseProvider(
                supabase_url=supabase_url,
                supabase_key=supabase_key,
                voyage_api_key=voyage_api_key,
                owner_wallet=owner_wallet or "default",
            )
            self.mode = "supabase"
        elif api_key:
            from .hosted import HostedProvider
            self._provider = HostedProvider(api_key=api_key, base_url=base_url)
            self.mode = "hosted"
        else:
            raise ValueError("Provide either api_key (hosted) or supabase_url+supabase_key+voyage_api_key (self-hosted)")

    async def store(
        self,
        content: str,
        summary: Optional[str] = None,
        type: str = "episodic",
        tags: Optional[List[str]] = None,
        importance: float = 0.5,
    ) -> str:
        """Store a memory. Returns memory ID."""
        return await self._provider.store(content=content, summary=summary, type=type, tags=tags, importance=importance)

    async def recall(
        self,
        query: str,
        limit: int = 5,
        types: Optional[List[str]] = None,
        threshold: float = 0.3,
    ) -> List[Memory]:
        """Recall memories by semantic search."""
        return await self._provider.recall(query=query, limit=limit, types=types, threshold=threshold)

    async def forget(self, memory_id: str) -> bool:
        """Delete a memory by ID."""
        return await self._provider.forget(memory_id)

    async def stats(self) -> Stats:
        """Get memory statistics."""
        return await self._provider.stats()

    async def export_pack(self, query: str, limit: int = 50) -> MemoryPack:
        """Export memories as a MemoryPack."""
        return await self._provider.export_pack(query=query, limit=limit)

    async def import_pack(self, pack: MemoryPack) -> int:
        """Import a MemoryPack. Returns count of imported memories."""
        return await self._provider.import_pack(pack)

    async def close(self):
        """Close underlying connections."""
        await self._provider.close()

    async def __aenter__(self):
        return self

    async def __aexit__(self, *args):
        await self.close()
