"""Example: Using Clude with CrewAI agents."""

import asyncio
from clude import Clude


async def store_agent_memory(brain: Clude, task_result: str):
    """Store task results as agent memory."""
    return await brain.store(
        content=task_result,
        type="procedural",
        tags=["crewai", "task-result"],
        importance=0.7,
    )


async def recall_context(brain: Clude, task_description: str):
    """Recall relevant context for a new task."""
    return await brain.recall(query=task_description, limit=10)


async def main():
    brain = Clude(
        supabase_url="https://your-project.supabase.co",
        supabase_key="your-key",
        voyage_api_key="your-voyage-key",
        owner_wallet="crewai-agent",
    )

    # After a CrewAI task completes, store the result
    mid = await store_agent_memory(brain, "Analyzed market: BTC showing bullish divergence on 4H")

    # Before a new task, recall relevant memories
    context = await recall_context(brain, "What do we know about BTC market analysis?")
    print(f"Found {len(context)} relevant memories for context")

    await brain.forget(mid)
    await brain.close()


if __name__ == "__main__":
    asyncio.run(main())
