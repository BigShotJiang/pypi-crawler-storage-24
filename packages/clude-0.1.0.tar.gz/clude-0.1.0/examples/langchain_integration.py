"""Example: Using Clude as a LangChain memory backend."""

import asyncio
from clude import Clude


class CludeLangChainMemory:
    """Adapter to use Clude as LangChain-compatible memory."""

    def __init__(self, brain: Clude):
        self.brain = brain

    async def add_memory(self, text: str, metadata: dict = None):
        return await self.brain.store(
            content=text,
            type=metadata.get("type", "episodic") if metadata else "episodic",
            tags=metadata.get("tags", []) if metadata else [],
        )

    async def search(self, query: str, k: int = 5):
        memories = await self.brain.recall(query=query, limit=k)
        return [{"content": m.content, "metadata": {"type": m.type, "id": m.id}} for m in memories]


async def main():
    brain = Clude(
        supabase_url="https://your-project.supabase.co",
        supabase_key="your-key",
        voyage_api_key="your-voyage-key",
        owner_wallet="langchain-agent",
    )

    memory = CludeLangChainMemory(brain)
    mid = await memory.add_memory("User asked about Python decorators", {"type": "episodic", "tags": ["python"]})
    results = await memory.search("Python concepts")
    print(f"Found {len(results)} results")

    await brain.forget(mid)
    await brain.close()


if __name__ == "__main__":
    asyncio.run(main())
