"""Quickstart example for Clude Python SDK."""

import asyncio
from clude import Clude


async def main():
    brain = Clude(
        supabase_url="https://your-project.supabase.co",
        supabase_key="your-service-key",
        voyage_api_key="your-voyage-key",
        owner_wallet="my-agent",
    )

    # Store
    mid = await brain.store(content="Hello world", type="episodic", tags=["test"])
    print(f"Stored: {mid}")

    # Recall
    memories = await brain.recall(query="hello", limit=5)
    for m in memories:
        print(f"  [{m.type}] {m.content[:80]}")

    # Cleanup
    await brain.forget(mid)
    await brain.close()


if __name__ == "__main__":
    asyncio.run(main())
