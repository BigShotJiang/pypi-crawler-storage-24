"""End-to-end tests against live Supabase."""

import pytest
from clude import Clude, MemoryPack

SUPABASE_URL = "https://ilmkakcqakvwtfrsabrd.supabase.co"
SUPABASE_KEY = "sb_secret_3Ck1GJHtT3vVDR6p-qvgog_v_W6UVC8"
VOYAGE_KEY = "pa-M-rDVzpYrI82t-2Fad54iKZugVyejn995zFi9ZNmHhh"
OWNER = "test-python-sdk"


@pytest.fixture
async def brain():
    client = Clude(
        supabase_url=SUPABASE_URL,
        supabase_key=SUPABASE_KEY,
        voyage_api_key=VOYAGE_KEY,
        owner_wallet=OWNER,
    )
    yield client
    await client.close()


@pytest.fixture
async def cleanup_ids():
    """Collect memory IDs to clean up after test."""
    ids = []
    yield ids
    # Cleanup happens in tests that use this


async def _cleanup(brain, memory_ids):
    for mid in memory_ids:
        try:
            await brain.forget(mid)
        except Exception:
            pass


class TestStoreAndRecall:
    async def test_store_returns_id(self, brain):
        mid = await brain.store(
            content="Python SDK test memory: the quick brown fox jumps over the lazy dog",
            summary="fox and dog test",
            type="episodic",
            tags=["test", "python-sdk"],
            importance=0.7,
        )
        assert mid is not None
        assert isinstance(mid, str)
        assert len(mid) > 0
        # Cleanup
        await brain.forget(mid)

    async def test_recall_finds_stored(self, brain):
        mid = await brain.store(
            content="Python SDK unique test: quantum entanglement in blockchain systems 12345",
            summary="quantum blockchain test",
            type="semantic",
            tags=["test"],
            importance=0.8,
        )
        try:
            memories = await brain.recall(query="quantum entanglement blockchain", limit=5)
            assert len(memories) > 0
            found = any(m.id == mid for m in memories)
            assert found, f"Stored memory {mid} not found in recall results"
            # Check memory fields
            match = next(m for m in memories if m.id == mid)
            assert "quantum" in match.content.lower()
            assert match.type == "semantic"
        finally:
            await brain.forget(mid)

    async def test_recall_with_type_filter(self, brain):
        mid = await brain.store(
            content="Procedural test: how to deploy a smart contract on Solana step by step",
            type="procedural",
            tags=["test"],
        )
        try:
            # Should find with correct type
            memories = await brain.recall(query="deploy smart contract solana", limit=5, types=["procedural"])
            found = any(m.id == mid for m in memories)
            assert found
        finally:
            await brain.forget(mid)


class TestForget:
    async def test_forget_removes_memory(self, brain):
        mid = await brain.store(content="Memory to forget: temporary test data xyz789", tags=["test"])
        result = await brain.forget(mid)
        assert result is True
        # Verify it's gone - recall shouldn't find it
        memories = await brain.recall(query="temporary test data xyz789", limit=5)
        found = any(m.id == mid for m in memories)
        assert not found


class TestStats:
    async def test_stats_returns_data(self, brain):
        mid = await brain.store(content="Stats test memory: counting memories", type="episodic", tags=["test"])
        try:
            stats = await brain.stats()
            assert stats.total_memories >= 1
            assert stats.owner_wallet == OWNER
            assert isinstance(stats.by_type, dict)
        finally:
            await brain.forget(mid)


class TestMemoryPack:
    async def test_export_pack(self, brain):
        mid = await brain.store(
            content="Export test: DeFi yield farming strategies for 2024",
            type="semantic",
            tags=["test", "defi"],
        )
        try:
            pack = await brain.export_pack(query="DeFi yield farming", limit=10)
            assert isinstance(pack, MemoryPack)
            assert pack.version == "1.0"
            assert len(pack.memories) > 0
            assert pack.content_hash is not None
        finally:
            await brain.forget(mid)

    async def test_import_pack(self, brain):
        pack = MemoryPack(
            version="1.0",
            identity="test-import",
            memories=[
                {
                    "content": "Imported memory: cross-chain bridge security analysis alpha",
                    "summary": "bridge security",
                    "type": "semantic",
                    "tags": ["test", "import"],
                    "importance": 0.6,
                }
            ],
            connections=[],
        )
        pack.content_hash = pack.compute_hash()

        count = await brain.import_pack(pack)
        assert count == 1

        # Verify imported
        memories = await brain.recall(query="cross-chain bridge security analysis alpha", limit=5)
        imported = [m for m in memories if "cross-chain bridge security" in m.content]
        assert len(imported) > 0

        # Cleanup
        for m in imported:
            await brain.forget(m.id)

    async def test_pack_roundtrip(self, brain):
        mid = await brain.store(
            content="Roundtrip test: NFT metadata standards comparison ERC721 vs ERC1155",
            type="semantic",
            tags=["test"],
        )
        try:
            pack = await brain.export_pack(query="NFT metadata standards", limit=10)
            json_str = pack.to_json()
            restored = MemoryPack.from_json(json_str)
            assert restored.version == pack.version
            assert len(restored.memories) == len(pack.memories)
            assert restored.content_hash == pack.content_hash
        finally:
            await brain.forget(mid)


class TestClientInit:
    def test_supabase_mode(self):
        brain = Clude(
            supabase_url=SUPABASE_URL,
            supabase_key=SUPABASE_KEY,
            voyage_api_key=VOYAGE_KEY,
            owner_wallet=OWNER,
        )
        assert brain.mode == "supabase"

    def test_hosted_mode(self):
        brain = Clude(api_key="test-key")
        assert brain.mode == "hosted"

    def test_no_credentials_raises(self):
        with pytest.raises(ValueError):
            Clude()
