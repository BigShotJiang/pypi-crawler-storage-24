"""Tests for hosted provider (mocked HTTP)."""

import pytest
from unittest.mock import AsyncMock, patch, MagicMock
from clude.hosted import HostedProvider


class TestHostedProvider:
    def test_init(self):
        p = HostedProvider(api_key="test", base_url="https://example.com")
        assert p.api_key == "test"
        assert p.base_url == "https://example.com"

    def test_init_strips_slash(self):
        p = HostedProvider(api_key="test", base_url="https://example.com/")
        assert p.base_url == "https://example.com"
