"""Unit tests for Supabase provider types and utilities."""

import pytest
from clude.types import Memory, MemoryPack, Stats
from clude.pack import validate_pack, merge_packs


class TestMemory:
    def test_to_dict(self):
        m = Memory(id="123", content="test", type="episodic")
        d = m.to_dict()
        assert d["id"] == "123"
        assert d["content"] == "test"

    def test_from_dict(self):
        m = Memory.from_dict({"id": "abc", "content": "hello", "type": "semantic", "extra_field": True})
        assert m.id == "abc"
        assert m.type == "semantic"


class TestMemoryPack:
    def test_hash_consistency(self):
        pack = MemoryPack(memories=[{"content": "a"}, {"content": "b"}])
        h1 = pack.compute_hash()
        h2 = pack.compute_hash()
        assert h1 == h2

    def test_validate_pack(self):
        pack = MemoryPack(memories=[{"content": "test"}])
        pack.content_hash = pack.compute_hash()
        assert validate_pack(pack) is True

    def test_validate_pack_tampered(self):
        pack = MemoryPack(memories=[{"content": "test"}])
        pack.content_hash = "wrong"
        assert validate_pack(pack) is False

    def test_merge_packs(self):
        p1 = MemoryPack(memories=[{"id": "1", "content": "a"}])
        p2 = MemoryPack(memories=[{"id": "2", "content": "b"}, {"id": "1", "content": "a"}])
        merged = merge_packs(p1, p2)
        assert len(merged.memories) == 2

    def test_json_roundtrip(self):
        pack = MemoryPack(version="1.0", memories=[{"content": "test"}], identity="me")
        pack.content_hash = pack.compute_hash()
        json_str = pack.to_json()
        restored = MemoryPack.from_json(json_str)
        assert restored.content_hash == pack.content_hash


class TestStats:
    def test_defaults(self):
        s = Stats()
        assert s.total_memories == 0
        assert s.by_type == {}
