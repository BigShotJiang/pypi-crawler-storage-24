# loci-sdk

Official Python SDK for the Loci API.

## Installation

```bash
pip install loci-sdk
```

## Quick Start

```python
from loci import LociClient

client = LociClient(api_key="your-api-key")

# List documents
docs = client.documents.list(limit=20, tags=["contract"])
print(docs["documents"])

# RAG query
answer = client.query.ask("When does my lease expire?")
print(answer["answer"])
print(answer["sources"])

# Account info
account = client.account.get()
print(f"Plan: {account['plan_tier']}")
```

## Configuration

```python
client = LociClient(
    api_key="your-api-key",
    base_url="https://api.locivault.com",  # optional, this is the default
)
```

## Documents

```python
# List with filters
result = client.documents.list(
    q="lease agreement",
    file_type="pdf",
    date_from="2026-01-01",
    date_to="2026-12-31",
    tags=["legal"],
    limit=10,
    offset=0,
)
```

## Query

```python
# Simple query
answer = client.query.ask("What are the payment terms?")

# Team-scoped query
answer = client.query.ask("Q4 revenue projections", team_id="team-uuid")

# Continue a conversation thread
follow_up = client.query.ask("Can you elaborate?", thread_id="thread-uuid")
```

## Webhooks

```python
# List webhooks
hooks = client.webhooks.list()

# Create a webhook
created = client.webhooks.create(
    url="https://example.com/webhook",
    events=["document.processed", "query.completed"],
)

# Test a webhook
test = client.webhooks.test(created["webhook"]["id"])
print(f"Status: {test['responseCode']}, Latency: {test['latencyMs']}ms")

# Delete a webhook
client.webhooks.delete(created["webhook"]["id"])
```

## Error Handling

```python
from loci import LociClient, LociApiError

try:
    docs = client.documents.list()
except LociApiError as err:
    print(f"API error {err.status_code}: {err.message}")
    print(f"Response body: {err.body}")
```
