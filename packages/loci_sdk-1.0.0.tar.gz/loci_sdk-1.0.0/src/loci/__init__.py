"""Official Python SDK for the Loci API."""

from .client import LociClient
from .errors import LociApiError

__all__ = ["LociClient", "LociApiError"]
__version__ = "1.0.0"
