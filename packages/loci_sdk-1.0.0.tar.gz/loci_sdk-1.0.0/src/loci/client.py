"""Official Python client for the Loci API."""

import json
import urllib.request
import urllib.error
import urllib.parse
from typing import Any, Dict, List, Optional

from .errors import LociApiError
from .types import (
    AccountResponse,
    CollectionCreateResponse,
    CollectionListResponse,
    CollectionUpdateResponse,
    DocumentBulkResponse,
    DocumentDeleteResponse,
    DocumentGetResponse,
    DocumentListResponse,
    DocumentUpdateResponse,
    DocumentUploadResponse,
    QueryResponse,
    TagListResponse,
    TagMutationResponse,
    TeamCreateResponse,
    TeamGetResponse,
    TeamListResponse,
    ThreadGetResponse,
    ThreadListResponse,
    WebhookCreateResponse,
    WebhookListResponse,
    WebhookTestResponse,
)

DEFAULT_BASE_URL = "https://api.locivault.com"


class LociClient:
    """Official Python client for the Loci API.

    Example::

        from loci import LociClient

        client = LociClient(api_key="your-api-key")

        # List documents
        docs = client.documents.list(limit=20)

        # Upload a document
        upload = client.documents.upload("report.pdf", "application/pdf")

        # Ask a question
        answer = client.query.ask("When does my lease expire?")
        print(answer["answer"])

        # Manage collections
        col = client.collections.create("Contracts")

        # Work with teams
        teams = client.teams.list()

    Args:
        api_key: Your Loci API key.
        base_url: Base URL for the API. Defaults to ``https://api.locivault.com``.
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
    ) -> None:
        if not api_key:
            raise ValueError("api_key is required")
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")

        self.documents = self.Documents(self)
        self.query = self.Query(self)
        self.account = self.Account(self)
        self.collections = self.Collections(self)
        self.tags = self.Tags(self)
        self.threads = self.Threads(self)
        self.teams = self.Teams(self)
        self.webhooks = self.Webhooks(self)

    def _request(
        self,
        method: str,
        path: str,
        body: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, str]] = None,
    ) -> Any:
        """Send an HTTP request to the Loci API.

        Args:
            method: HTTP method (GET, POST, DELETE, etc.).
            path: URL path (e.g., ``/v1/documents``).
            body: JSON request body (for POST/PUT/PATCH).
            params: Query string parameters.

        Returns:
            Parsed JSON response body.

        Raises:
            LociApiError: If the API returns a non-2xx status code.
        """
        url = f"{self._base_url}{path}"
        if params:
            filtered = {k: v for k, v in params.items() if v is not None}
            if filtered:
                url = f"{url}?{urllib.parse.urlencode(filtered)}"

        data = None
        if body is not None:
            data = json.dumps(body).encode("utf-8")

        req = urllib.request.Request(
            url,
            data=data,
            method=method,
            headers={
                "Authorization": f"Bearer {self._api_key}",
                "Content-Type": "application/json",
                "Accept": "application/json",
            },
        )

        try:
            with urllib.request.urlopen(req) as resp:
                resp_body = resp.read().decode("utf-8")
                if resp_body:
                    return json.loads(resp_body)
                return None
        except urllib.error.HTTPError as exc:
            resp_body_raw = exc.read().decode("utf-8") if exc.fp else ""
            try:
                parsed_body = json.loads(resp_body_raw) if resp_body_raw else None
            except json.JSONDecodeError:
                parsed_body = resp_body_raw
            raise LociApiError(
                message=f"Loci API error: {exc.code} {exc.reason}",
                status_code=exc.code,
                body=parsed_body,
            ) from exc

    # ─── Documents ───────────────────────────────────────────

    class Documents:
        """Methods for managing documents."""

        def __init__(self, client: "LociClient") -> None:
            self._client = client

        def list(
            self,
            q: Optional[str] = None,
            date_from: Optional[str] = None,
            date_to: Optional[str] = None,
            file_type: Optional[str] = None,
            tags: Optional[List[str]] = None,
            collection_id: Optional[str] = None,
            team_id: Optional[str] = None,
            limit: Optional[int] = None,
            offset: Optional[int] = None,
        ) -> DocumentListResponse:
            """List documents with optional filtering and pagination.

            Args:
                q: Full-text search query.
                date_from: Filter documents created after this date (ISO 8601).
                date_to: Filter documents created before this date (ISO 8601).
                file_type: Filter by file type (e.g., pdf, docx, txt).
                tags: List of tags to filter by.
                collection_id: Filter by collection ID. Use "root" for uncategorized.
                team_id: Team ID for team-scoped listing.
                limit: Number of results per page (max 100). Default: 10.
                offset: Offset for pagination. Default: 0.

            Returns:
                A dict with ``documents`` and ``meta`` keys.
            """
            params: Dict[str, str] = {}
            if q is not None:
                params["q"] = q
            if date_from is not None:
                params["dateFrom"] = date_from
            if date_to is not None:
                params["dateTo"] = date_to
            if file_type is not None:
                params["fileType"] = file_type
            if tags is not None:
                params["tags"] = ",".join(tags)
            if collection_id is not None:
                params["collectionId"] = collection_id
            if team_id is not None:
                params["teamId"] = team_id
            if limit is not None:
                params["limit"] = str(limit)
            if offset is not None:
                params["offset"] = str(offset)

            return self._client._request("GET", "/v1/documents", params=params)

        def get(self, document_id: int) -> DocumentGetResponse:
            """Get a single document by ID.

            Args:
                document_id: The document ID.

            Returns:
                A dict with a ``document`` key.
            """
            return self._client._request("GET", f"/v1/documents/{document_id}")

        def upload(
            self,
            file_name: str,
            file_type: str,
            team_id: Optional[str] = None,
        ) -> DocumentUploadResponse:
            """Request a presigned URL for uploading a document.

            After receiving the presigned URL, POST the file directly to S3
            using the returned ``url`` and ``fields``.

            Args:
                file_name: File name for the document.
                file_type: MIME type of the file (e.g., "application/pdf").
                team_id: Team ID to upload to a team vault.

            Returns:
                A dict with ``url``, ``fields``, ``s3Key``, ``bucket``, and ``reservationId``.
            """
            body: Dict[str, Any] = {"fileName": file_name, "fileType": file_type}
            if team_id is not None:
                body["teamId"] = team_id
            return self._client._request("POST", "/v1/documents/upload", body=body)

        def update(
            self,
            document_id: int,
            tags: Optional[List[str]] = None,
            collection_id: Optional[int] = None,
            action_items: Optional[List[Dict[str, Any]]] = None,
        ) -> DocumentUpdateResponse:
            """Update a document's metadata.

            Args:
                document_id: The document ID.
                tags: New tags for the document.
                collection_id: Collection ID to move to. Use None for uncategorized.
                action_items: Action items to set.

            Returns:
                A dict with ``success`` and ``document`` keys.
            """
            body: Dict[str, Any] = {}
            if tags is not None:
                body["tags"] = tags
            if collection_id is not None:
                body["collection_id"] = collection_id
            if action_items is not None:
                body["action_items"] = action_items
            return self._client._request(
                "PATCH", f"/v1/documents/{document_id}", body=body
            )

        def delete(self, document_id: int) -> DocumentDeleteResponse:
            """Delete a document.

            Args:
                document_id: The document ID.

            Returns:
                A dict with ``success`` and ``message`` keys.
            """
            return self._client._request("DELETE", f"/v1/documents/{document_id}")

        def bulk(
            self,
            action: str,
            document_ids: List[int],
            collection_id: Optional[int] = None,
            tags: Optional[List[str]] = None,
            tag_mode: Optional[str] = None,
        ) -> DocumentBulkResponse:
            """Perform bulk operations on multiple documents.

            Args:
                action: Operation to perform: "delete", "move", or "tag".
                document_ids: List of document IDs (max 100).
                collection_id: Target collection for "move" action.
                tags: Tags for "tag" action.
                tag_mode: "add" (merge) or "set" (replace). Default: "add".

            Returns:
                A dict with ``success`` and ``affected`` keys.
            """
            body: Dict[str, Any] = {
                "action": action,
                "documentIds": document_ids,
            }
            if collection_id is not None:
                body["collectionId"] = collection_id
            if tags is not None:
                body["tags"] = tags
            if tag_mode is not None:
                body["tagMode"] = tag_mode
            return self._client._request("POST", "/v1/documents/bulk", body=body)

    # ─── Query ───────────────────────────────────────────────

    class Query:
        """Methods for running RAG queries against your knowledge base."""

        def __init__(self, client: "LociClient") -> None:
            self._client = client

        def ask(
            self,
            query: str,
            team_id: Optional[str] = None,
            thread_id: Optional[str] = None,
        ) -> QueryResponse:
            """Submit a natural language query against your document knowledge base.

            Args:
                query: The natural language question to ask.
                team_id: Team ID for team-scoped queries.
                thread_id: Thread ID for conversation context.

            Returns:
                A dict with ``answer`` and ``sources`` keys.
            """
            body: Dict[str, Any] = {"query": query}
            if team_id is not None:
                body["teamId"] = team_id
            if thread_id is not None:
                body["threadId"] = thread_id
            return self._client._request("POST", "/v1/query", body=body)

    # ─── Account ─────────────────────────────────────────────

    class Account:
        """Methods for retrieving account information."""

        def __init__(self, client: "LociClient") -> None:
            self._client = client

        def get(self) -> AccountResponse:
            """Retrieve the authenticated user's account information.

            Returns:
                A dict with account details including email, plan tier, and creation date.
            """
            return self._client._request("GET", "/v1/account")

    # ─── Collections ─────────────────────────────────────────

    class Collections:
        """Methods for managing collections (folders)."""

        def __init__(self, client: "LociClient") -> None:
            self._client = client

        def list(self, team_id: Optional[str] = None) -> CollectionListResponse:
            """List all collections.

            Args:
                team_id: Team ID for team-scoped collections.

            Returns:
                A dict with a ``collections`` key.
            """
            params: Dict[str, str] = {}
            if team_id is not None:
                params["teamId"] = team_id
            return self._client._request("GET", "/v1/collections", params=params)

        def create(
            self,
            name: str,
            team_id: Optional[str] = None,
            parent_id: Optional[int] = None,
        ) -> CollectionCreateResponse:
            """Create a new collection.

            Args:
                name: Name of the collection.
                team_id: Team ID for team-scoped collections.
                parent_id: Parent collection ID for nesting.

            Returns:
                A dict with a ``collection`` key.
            """
            body: Dict[str, Any] = {"name": name}
            if team_id is not None:
                body["teamId"] = team_id
            if parent_id is not None:
                body["parentId"] = parent_id
            return self._client._request("POST", "/v1/collections", body=body)

        def update(
            self,
            collection_id: int,
            name: Optional[str] = None,
            parent_id: Optional[int] = None,
        ) -> CollectionUpdateResponse:
            """Update a collection (rename or move).

            Args:
                collection_id: The collection ID.
                name: New name for the collection.
                parent_id: New parent collection ID.

            Returns:
                A dict with a ``collection`` key.
            """
            body: Dict[str, Any] = {}
            if name is not None:
                body["name"] = name
            if parent_id is not None:
                body["parentId"] = parent_id
            return self._client._request(
                "PATCH", f"/v1/collections/{collection_id}", body=body
            )

        def delete(self, collection_id: int) -> None:
            """Delete a collection. Documents become uncategorized.

            Args:
                collection_id: The collection ID.
            """
            self._client._request("DELETE", f"/v1/collections/{collection_id}")

    # ─── Tags ────────────────────────────────────────────────

    class Tags:
        """Methods for managing tags."""

        def __init__(self, client: "LociClient") -> None:
            self._client = client

        def list(self, team_id: Optional[str] = None) -> TagListResponse:
            """List all tags with usage counts.

            Args:
                team_id: Team ID for team-scoped tags.

            Returns:
                A dict with a ``tags`` key containing tag/count pairs.
            """
            params: Dict[str, str] = {}
            if team_id is not None:
                params["teamId"] = team_id
            return self._client._request("GET", "/v1/tags", params=params)

        def rename(
            self,
            old_tag: str,
            new_tag: str,
            team_id: Optional[str] = None,
        ) -> TagMutationResponse:
            """Rename a tag across all documents.

            Args:
                old_tag: Current tag name.
                new_tag: New tag name.
                team_id: Team ID for team-scoped operation.

            Returns:
                A dict with ``success`` and ``affected`` keys.
            """
            body: Dict[str, Any] = {"oldTag": old_tag, "newTag": new_tag}
            if team_id is not None:
                body["teamId"] = team_id
            return self._client._request("POST", "/v1/tags/rename", body=body)

        def delete(
            self,
            tag: str,
            team_id: Optional[str] = None,
        ) -> TagMutationResponse:
            """Remove a tag from all documents.

            Args:
                tag: Tag to remove.
                team_id: Team ID for team-scoped operation.

            Returns:
                A dict with ``success`` and ``affected`` keys.
            """
            body: Dict[str, Any] = {"tag": tag}
            if team_id is not None:
                body["teamId"] = team_id
            return self._client._request("POST", "/v1/tags/delete", body=body)

    # ─── Threads ─────────────────────────────────────────────

    class Threads:
        """Methods for managing conversation threads."""

        def __init__(self, client: "LociClient") -> None:
            self._client = client

        def list(
            self,
            team_id: Optional[str] = None,
            search: Optional[str] = None,
            starred: Optional[bool] = None,
            limit: Optional[int] = None,
            offset: Optional[int] = None,
        ) -> ThreadListResponse:
            """List conversation threads.

            Args:
                team_id: Team ID for team-scoped threads.
                search: Search thread titles.
                starred: Filter to starred threads only.
                limit: Max results per page.
                offset: Offset for pagination.

            Returns:
                A dict with ``threads``, ``total``, and ``nextCursor`` keys.
            """
            params: Dict[str, str] = {}
            if team_id is not None:
                params["teamId"] = team_id
            if search is not None:
                params["search"] = search
            if starred is not None:
                params["starred"] = str(starred).lower()
            if limit is not None:
                params["limit"] = str(limit)
            if offset is not None:
                params["offset"] = str(offset)
            return self._client._request("GET", "/v1/threads", params=params)

        def get(self, thread_id: str) -> ThreadGetResponse:
            """Get messages in a thread.

            Args:
                thread_id: The thread ID.

            Returns:
                A dict with ``threadId`` and ``messages`` keys.
            """
            return self._client._request("GET", f"/v1/threads/{thread_id}")

        def star(self, thread_id: str, starred: bool) -> None:
            """Star or unstar a thread.

            Args:
                thread_id: The thread ID.
                starred: Whether to star (True) or unstar (False).
            """
            self._client._request(
                "PATCH", f"/v1/threads/{thread_id}", body={"starred": starred}
            )

        def delete(self, thread_id: str) -> None:
            """Delete a thread and all its messages.

            Args:
                thread_id: The thread ID.
            """
            self._client._request("DELETE", f"/v1/threads/{thread_id}")

    # ─── Teams ───────────────────────────────────────────────

    class Teams:
        """Methods for managing teams."""

        def __init__(self, client: "LociClient") -> None:
            self._client = client

        def list(self) -> TeamListResponse:
            """List teams you belong to.

            Returns:
                A dict with a ``teams`` key.
            """
            return self._client._request("GET", "/v1/teams")

        def create(self, name: str, slug: str) -> TeamCreateResponse:
            """Create a new team. Requires Business plan.

            Args:
                name: Team display name.
                slug: URL slug (unique).

            Returns:
                A dict with a ``team`` key.
            """
            return self._client._request(
                "POST", "/v1/teams", body={"name": name, "slug": slug}
            )

        def get(self, team_id: str) -> TeamGetResponse:
            """Get team details including members and usage.

            Args:
                team_id: The team ID.

            Returns:
                A dict with ``team``, ``members``, and ``usage`` keys.
            """
            return self._client._request("GET", f"/v1/teams/{team_id}")

        def documents(self, team_id: str) -> DocumentListResponse:
            """List documents in a team vault.

            Args:
                team_id: The team ID.

            Returns:
                A dict with ``documents`` and ``meta`` keys.
            """
            return self._client._request("GET", f"/v1/teams/{team_id}/documents")

        def add_member(
            self,
            team_id: str,
            email: str,
            role: Optional[str] = None,
        ) -> None:
            """Add a member to a team.

            Args:
                team_id: The team ID.
                email: Email of the user to add.
                role: Role to assign ("admin", "member", "viewer"). Default: "member".
            """
            body: Dict[str, Any] = {"email": email}
            if role is not None:
                body["role"] = role
            self._client._request("POST", f"/v1/teams/{team_id}/members", body=body)

        def remove_member(self, team_id: str, user_id: str) -> None:
            """Remove a member from a team.

            Args:
                team_id: The team ID.
                user_id: The user ID to remove.
            """
            self._client._request(
                "DELETE", f"/v1/teams/{team_id}/members/{user_id}"
            )

    # ─── Webhooks ────────────────────────────────────────────

    class Webhooks:
        """Methods for managing webhook subscriptions."""

        def __init__(self, client: "LociClient") -> None:
            self._client = client

        def list(self) -> WebhookListResponse:
            """List all configured webhooks.

            Returns:
                A dict with a ``webhooks`` key containing the list of webhooks.
            """
            return self._client._request("GET", "/v1/webhooks")

        def create(
            self,
            url: str,
            events: List[str],
            team_id: Optional[str] = None,
        ) -> WebhookCreateResponse:
            """Create a new webhook subscription.

            Args:
                url: URL to receive webhook payloads.
                events: List of event types to subscribe to.
                team_id: Team ID for team-scoped webhooks.

            Returns:
                A dict with a ``webhook`` key containing the created webhook.
            """
            body: Dict[str, Any] = {"url": url, "events": events}
            if team_id is not None:
                body["teamId"] = team_id
            return self._client._request("POST", "/v1/webhooks", body=body)

        def delete(self, webhook_id: str) -> None:
            """Delete a webhook subscription.

            Args:
                webhook_id: The ID of the webhook to delete.
            """
            self._client._request("DELETE", f"/v1/webhooks/{webhook_id}")

        def test(self, webhook_id: str) -> WebhookTestResponse:
            """Send a test payload to a webhook URL.

            Args:
                webhook_id: The ID of the webhook to test.

            Returns:
                A dict with delivery result including response code and latency.
            """
            return self._client._request("POST", f"/v1/webhooks/{webhook_id}/test")
