"""Type definitions for the Loci SDK.

Hand-written for ergonomic SDK usage.
For auto-generated types from OpenAPI, see generated_types.py
"""

from typing import Any, Dict, List, Optional, TypedDict


class Document(TypedDict, total=False):
    """A document stored in the Loci vault."""

    id: int
    file_name: str
    file_type: str
    summary: str
    tags: List[str]
    collection_id: Optional[int]
    created_at: str
    updated_at: str


class PaginationMeta(TypedDict):
    """Pagination metadata returned with list endpoints."""

    limit: int
    offset: int
    total: int
    hasMore: bool


class DocumentListResponse(TypedDict):
    """Response from GET /v1/documents."""

    documents: List[Document]
    meta: PaginationMeta


class DocumentGetResponse(TypedDict):
    """Response from GET /v1/documents/:id."""

    document: Document


class DocumentUploadResponse(TypedDict):
    """Response from POST /v1/documents/upload."""

    url: str
    fields: Dict[str, str]
    s3Key: str
    bucket: str
    reservationId: str


class DocumentUpdateResponse(TypedDict):
    """Response from PATCH /v1/documents/:id."""

    success: bool
    document: Document


class DocumentDeleteResponse(TypedDict):
    """Response from DELETE /v1/documents/:id."""

    success: bool
    message: str


class DocumentBulkResponse(TypedDict):
    """Response from POST /v1/documents/bulk."""

    success: bool
    affected: int


class QuerySource(TypedDict):
    """A source chunk returned with a RAG query response."""

    documentId: int
    fileName: str
    chunk: str
    score: float


class QueryResponse(TypedDict):
    """Response from POST /v1/query."""

    answer: str
    sources: List[QuerySource]


class Webhook(TypedDict, total=False):
    """A configured webhook."""

    id: str
    url: str
    events: List[str]
    active: bool
    secret: str
    created_at: str


class WebhookListResponse(TypedDict):
    """Response from GET /v1/webhooks."""

    webhooks: List[Webhook]


class WebhookCreateResponse(TypedDict):
    """Response from POST /v1/webhooks."""

    webhook: Webhook


class WebhookTestResponse(TypedDict):
    """Response from POST /v1/webhooks/{webhookId}/test."""

    status: str
    responseCode: int
    latencyMs: int


class AccountLimits(TypedDict):
    """Plan limits for the account."""

    documents: int
    queriesPerMonth: int
    teamMembers: int
    canCreateTeams: bool


class AccountUsage(TypedDict):
    """Current usage for the account."""

    documents: int
    queriesThisMonth: int


class AccountResponse(TypedDict, total=False):
    """User account information."""

    userId: str
    email: str
    planTier: str
    role: str
    authProvider: str
    subscriptionStatus: str
    limits: AccountLimits
    usage: AccountUsage


# ─── Collections ────────────────────────────────────────────


class Collection(TypedDict, total=False):
    """A collection (folder) for organizing documents."""

    id: int
    name: str
    user_id: Optional[str]
    team_id: Optional[str]
    parent_id: Optional[int]
    created_at: str


class CollectionListResponse(TypedDict):
    """Response from GET /v1/collections."""

    collections: List[Collection]


class CollectionCreateResponse(TypedDict):
    """Response from POST /v1/collections."""

    collection: Collection


class CollectionUpdateResponse(TypedDict):
    """Response from PATCH /v1/collections/:id."""

    collection: Collection


# ─── Tags ───────────────────────────────────────────────────


class Tag(TypedDict):
    """A tag with its usage count."""

    tag: str
    count: int


class TagListResponse(TypedDict):
    """Response from GET /v1/tags."""

    tags: List[Tag]


class TagMutationResponse(TypedDict):
    """Response from tag rename/delete."""

    success: bool
    affected: int


# ─── Threads ────────────────────────────────────────────────


class Thread(TypedDict, total=False):
    """A conversation thread."""

    id: str
    title: str
    starred: bool
    updatedAt: str
    messageCount: int


class ThreadMessage(TypedDict, total=False):
    """A message in a conversation thread."""

    id: str
    role: str
    content: str
    sources: Optional[List[QuerySource]]
    createdAt: str
    vote: Optional[str]


class ThreadListResponse(TypedDict, total=False):
    """Response from GET /v1/threads."""

    threads: List[Thread]
    total: int
    nextCursor: Optional[str]


class ThreadGetResponse(TypedDict):
    """Response from GET /v1/threads/:id."""

    threadId: str
    messages: List[ThreadMessage]


# ─── Teams ──────────────────────────────────────────────────


class Team(TypedDict, total=False):
    """A team workspace."""

    id: str
    name: str
    slug: str
    owner_id: str
    created_at: str


class TeamMember(TypedDict, total=False):
    """A team member."""

    user_id: str
    email: str
    name: str
    role: str
    joined_at: str


class TeamListResponse(TypedDict):
    """Response from GET /v1/teams."""

    teams: List[Team]


class TeamCreateResponse(TypedDict):
    """Response from POST /v1/teams."""

    team: Team


class TeamGetResponse(TypedDict):
    """Response from GET /v1/teams/:id."""

    team: Team
    members: List[TeamMember]
    usage: Dict[str, Any]
