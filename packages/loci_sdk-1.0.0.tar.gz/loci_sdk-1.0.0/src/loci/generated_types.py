"""Type definitions for the Loci SDK.

Auto-generated from the OpenAPI spec. Do not edit manually.
Run the generation script to regenerate.
"""

from typing import Any, Dict, List, Optional, TypedDict


class Document(TypedDict, total=False):
    """Schema: Document"""

    id: int
    file_name: str
    file_type: str
    summary: str
    tags: List[str]
    created_at: str
    updated_at: str


class Webhook(TypedDict, total=False):
    """Schema: Webhook"""

    id: str
    url: str
    events: List[str]
    active: bool
    secret: str
    created_at: str


class ListdocumentsResponse(TypedDict):
    """Response from GET /v1/documents."""

    documents: List[Document]
    meta: Dict[str, Any]


class RAGqueryResponse(TypedDict):
    """Response from POST /v1/query."""

    answer: str
    sources: List[Dict[str, Any]]


class ListwebhooksResponse(TypedDict):
    """Response from GET /v1/webhooks."""

    webhooks: List[Webhook]


class CreatewebhookResponse(TypedDict):
    """Response from POST /v1/webhooks."""

    webhook: Webhook


class TestwebhookResponse(TypedDict):
    """Response from POST /v1/webhooks/{webhookId}/test."""

    status: str
    responseCode: int
    latencyMs: int


class PaginationMeta(TypedDict):
    """Pagination metadata returned with list endpoints."""

    limit: int
    offset: int
    total: int
    hasMore: bool


class AccountResponse(TypedDict, total=False):
    """User account information."""

    id: str
    email: str
    name: str
    plan_tier: str
    created_at: str
