"""Custom exceptions for the Loci SDK."""

from typing import Any


class LociApiError(Exception):
    """Raised when the Loci API returns a non-success HTTP response.

    Attributes:
        status_code: The HTTP status code returned by the API.
        body: The response body, parsed as JSON if possible.
        message: A human-readable error message.
    """

    def __init__(self, message: str, status_code: int, body: Any = None) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.body = body
        self.message = message

    def __repr__(self) -> str:
        return f"LociApiError(status_code={self.status_code}, message={self.message!r})"
