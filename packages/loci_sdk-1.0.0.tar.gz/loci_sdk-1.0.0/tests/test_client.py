"""Tests for the Loci Python SDK client."""

import json
import unittest
from unittest.mock import patch, MagicMock
import urllib.error

import sys
import os

# Add src to path so we can import loci
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from loci import LociClient, LociApiError


def make_mock_response(body, status=200):
    """Create a mock HTTP response."""
    mock_resp = MagicMock()
    encoded = json.dumps(body).encode("utf-8") if body is not None else b""
    mock_resp.read.return_value = encoded
    mock_resp.__enter__ = MagicMock(return_value=mock_resp)
    mock_resp.__exit__ = MagicMock(return_value=False)
    return mock_resp


def make_http_error(body, status=401, reason="Unauthorized"):
    """Create a mock urllib HTTPError."""
    encoded = json.dumps(body).encode("utf-8") if body else b""
    mock_fp = MagicMock()
    mock_fp.read.return_value = encoded
    err = urllib.error.HTTPError(
        url="https://api.locivault.com/v1/documents",
        code=status,
        msg=reason,
        hdrs=None,
        fp=mock_fp,
    )
    return err


class TestLociClientConstructor(unittest.TestCase):
    def test_requires_api_key(self):
        with self.assertRaises(ValueError):
            LociClient(api_key="")

    def test_accepts_custom_base_url(self):
        client = LociClient(api_key="key", base_url="https://custom.api.com")
        self.assertEqual(client._base_url, "https://custom.api.com")

    def test_strips_trailing_slashes(self):
        client = LociClient(api_key="key", base_url="https://custom.api.com///")
        self.assertEqual(client._base_url, "https://custom.api.com")


class TestDocumentsList(unittest.TestCase):
    @patch("loci.client.urllib.request.urlopen")
    def test_list_documents_no_params(self, mock_urlopen):
        response_body = {
            "documents": [
                {
                    "id": 1,
                    "file_name": "lease.pdf",
                    "file_type": "pdf",
                    "summary": "A lease",
                    "tags": ["legal"],
                    "created_at": "2026-01-01T00:00:00Z",
                    "updated_at": "2026-01-01T00:00:00Z",
                }
            ],
            "meta": {"limit": 10, "offset": 0, "total": 1, "hasMore": False},
        }
        mock_urlopen.return_value = make_mock_response(response_body)

        client = LociClient(api_key="test-key-123")
        result = client.documents.list()

        self.assertEqual(result, response_body)
        call_args = mock_urlopen.call_args[0][0]
        self.assertEqual(call_args.full_url, "https://api.locivault.com/v1/documents")
        self.assertEqual(call_args.get_method(), "GET")
        self.assertEqual(call_args.get_header("Authorization"), "Bearer test-key-123")

    @patch("loci.client.urllib.request.urlopen")
    def test_list_documents_with_params(self, mock_urlopen):
        mock_urlopen.return_value = make_mock_response(
            {"documents": [], "meta": {"limit": 5, "offset": 10, "total": 0, "hasMore": False}}
        )

        client = LociClient(api_key="key")
        client.documents.list(limit=5, offset=10, tags=["legal", "contract"])

        call_url = mock_urlopen.call_args[0][0].full_url
        self.assertIn("limit=5", call_url)
        self.assertIn("offset=10", call_url)
        self.assertIn("tags=legal%2Ccontract", call_url)


class TestQueryAsk(unittest.TestCase):
    @patch("loci.client.urllib.request.urlopen")
    def test_ask_simple_query(self, mock_urlopen):
        response_body = {
            "answer": "Your lease expires Dec 31, 2026.",
            "sources": [
                {"documentId": 1, "fileName": "lease.pdf", "chunk": "expires Dec 31", "score": 0.92}
            ],
        }
        mock_urlopen.return_value = make_mock_response(response_body)

        client = LociClient(api_key="key")
        result = client.query.ask("When does my lease expire?")

        self.assertEqual(result, response_body)
        call_args = mock_urlopen.call_args[0][0]
        self.assertEqual(call_args.get_method(), "POST")
        body = json.loads(call_args.data.decode("utf-8"))
        self.assertEqual(body["query"], "When does my lease expire?")

    @patch("loci.client.urllib.request.urlopen")
    def test_ask_with_team_and_thread(self, mock_urlopen):
        mock_urlopen.return_value = make_mock_response({"answer": "test", "sources": []})

        client = LociClient(api_key="key")
        client.query.ask("question", team_id="team-uuid", thread_id="thread-uuid")

        body = json.loads(mock_urlopen.call_args[0][0].data.decode("utf-8"))
        self.assertEqual(body["teamId"], "team-uuid")
        self.assertEqual(body["threadId"], "thread-uuid")

    @patch("loci.client.urllib.request.urlopen")
    def test_ask_without_optional_fields(self, mock_urlopen):
        mock_urlopen.return_value = make_mock_response({"answer": "yes", "sources": []})

        client = LociClient(api_key="key")
        client.query.ask("is this working?")

        body = json.loads(mock_urlopen.call_args[0][0].data.decode("utf-8"))
        self.assertNotIn("teamId", body)
        self.assertNotIn("threadId", body)


class TestAccountGet(unittest.TestCase):
    @patch("loci.client.urllib.request.urlopen")
    def test_get_account(self, mock_urlopen):
        response_body = {
            "id": "user-123",
            "email": "user@example.com",
            "name": "Test User",
            "plan_tier": "pro",
            "created_at": "2026-01-01T00:00:00Z",
        }
        mock_urlopen.return_value = make_mock_response(response_body)

        client = LociClient(api_key="key")
        result = client.account.get()

        self.assertEqual(result, response_body)
        call_url = mock_urlopen.call_args[0][0].full_url
        self.assertIn("/v1/account", call_url)


class TestErrorHandling(unittest.TestCase):
    @patch("loci.client.urllib.request.urlopen")
    def test_401_raises_loci_api_error(self, mock_urlopen):
        mock_urlopen.side_effect = make_http_error(
            {"error": "Unauthorized"}, 401, "Unauthorized"
        )

        client = LociClient(api_key="bad-key")
        with self.assertRaises(LociApiError) as ctx:
            client.documents.list()

        self.assertEqual(ctx.exception.status_code, 401)
        self.assertEqual(ctx.exception.body, {"error": "Unauthorized"})

    @patch("loci.client.urllib.request.urlopen")
    def test_429_raises_loci_api_error(self, mock_urlopen):
        mock_urlopen.side_effect = make_http_error(
            {"error": "Rate limit exceeded"}, 429, "Too Many Requests"
        )

        client = LociClient(api_key="key")
        with self.assertRaises(LociApiError) as ctx:
            client.query.ask("test")

        self.assertEqual(ctx.exception.status_code, 429)

    @patch("loci.client.urllib.request.urlopen")
    def test_500_raises_loci_api_error(self, mock_urlopen):
        mock_urlopen.side_effect = make_http_error(
            {"error": "Internal server error"}, 500, "Internal Server Error"
        )

        client = LociClient(api_key="key")
        with self.assertRaises(LociApiError) as ctx:
            client.account.get()

        self.assertEqual(ctx.exception.status_code, 500)


class TestWebhooks(unittest.TestCase):
    @patch("loci.client.urllib.request.urlopen")
    def test_list_webhooks(self, mock_urlopen):
        mock_urlopen.return_value = make_mock_response({"webhooks": []})

        client = LociClient(api_key="key")
        result = client.webhooks.list()

        self.assertEqual(result["webhooks"], [])

    @patch("loci.client.urllib.request.urlopen")
    def test_create_webhook(self, mock_urlopen):
        webhook = {
            "id": "wh-1",
            "url": "https://example.com/hook",
            "events": ["document.processed"],
            "active": True,
            "secret": "sec_abc",
            "created_at": "2026-01-01T00:00:00Z",
        }
        mock_urlopen.return_value = make_mock_response({"webhook": webhook})

        client = LociClient(api_key="key")
        result = client.webhooks.create(
            url="https://example.com/hook",
            events=["document.processed"],
        )

        self.assertEqual(result["webhook"], webhook)
        body = json.loads(mock_urlopen.call_args[0][0].data.decode("utf-8"))
        self.assertEqual(body["url"], "https://example.com/hook")

    @patch("loci.client.urllib.request.urlopen")
    def test_delete_webhook(self, mock_urlopen):
        mock_urlopen.return_value = make_mock_response(None)

        client = LociClient(api_key="key")
        client.webhooks.delete("wh-123")

        call_url = mock_urlopen.call_args[0][0].full_url
        self.assertIn("/v1/webhooks/wh-123", call_url)
        self.assertEqual(mock_urlopen.call_args[0][0].get_method(), "DELETE")

    @patch("loci.client.urllib.request.urlopen")
    def test_test_webhook(self, mock_urlopen):
        mock_urlopen.return_value = make_mock_response(
            {"status": "delivered", "responseCode": 200, "latencyMs": 150}
        )

        client = LociClient(api_key="key")
        result = client.webhooks.test("wh-123")

        self.assertEqual(result["responseCode"], 200)


if __name__ == "__main__":
    unittest.main()
