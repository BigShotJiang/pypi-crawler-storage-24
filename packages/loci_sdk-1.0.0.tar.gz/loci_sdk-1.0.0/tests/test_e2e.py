"""SDK end-to-end tests — hits a real running backend, no mocks.

Prerequisites:
    - Local backend running on port 3001 (start-local.sh)
    - Database running with migrations applied

Run:
    python -m pytest tests/test_e2e.py -v
"""

import json
import os
import time
import unittest
import urllib.request
import urllib.error

import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from loci import LociClient, LociApiError

API_BASE = os.environ.get("API_BASE_URL", "http://localhost:3001")
TEST_EMAIL = f"sdk-e2e-py-{int(time.time() * 1000)}@test.locivault.com"
TEST_PASSWORD = "SdkE2ePyP@ss123!"


def _post_json(path: str, body: dict, headers: dict | None = None) -> dict:
    """Helper to POST JSON to the backend."""
    url = f"{API_BASE}{path}"
    data = json.dumps(body).encode("utf-8")
    hdrs = {"Content-Type": "application/json"}
    if headers:
        hdrs.update(headers)
    req = urllib.request.Request(url, data=data, method="POST", headers=hdrs)
    with urllib.request.urlopen(req) as resp:
        return json.loads(resp.read().decode("utf-8"))


def _parse_cookies(headers) -> dict[str, str]:
    """Parse Set-Cookie headers into a dict."""
    cookies: dict[str, str] = {}
    raw = headers.get_all("Set-Cookie") or []
    for header in raw:
        name_value = header.split(";")[0]
        name, _, value = name_value.partition("=")
        cookies[name.strip()] = value.strip()
    return cookies


# Module-level state
_client: LociClient | None = None
_raw_api_key: str | None = None


def setUpModule():
    global _client, _raw_api_key

    # 1. Create test user
    _post_json("/auth/test-create-user", {"email": TEST_EMAIL, "password": TEST_PASSWORD})

    # 2. Set plan to pro
    _post_json("/auth/test-set-plan", {"email": TEST_EMAIL, "planTier": "pro"})

    # 3. Sign in to get session cookies
    url = f"{API_BASE}/signin"
    data = json.dumps({"email": TEST_EMAIL, "password": TEST_PASSWORD}).encode("utf-8")
    req = urllib.request.Request(url, data=data, method="POST", headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req) as resp:
        cookies = _parse_cookies(resp.headers)

    access_token = cookies.get("accessToken", "")
    csrf_token = cookies.get("csrf-token", "")
    refresh_token = cookies.get("refreshToken", "")

    if not access_token or not csrf_token:
        raise RuntimeError(f"Missing auth cookies. Got: {list(cookies.keys())}")

    # 4. Create API key via session-authenticated endpoint
    auth_headers = {
        "Content-Type": "application/json",
        "Cookie": f"accessToken={access_token}; csrf-token={csrf_token}; refreshToken={refresh_token}",
        "X-CSRF-Token": csrf_token,
    }
    result = _post_json("/api-keys", {"name": "sdk-e2e-py-key"}, headers=auth_headers)
    _raw_api_key = result["key"]

    # 5. Create SDK client
    _client = LociClient(api_key=_raw_api_key, base_url=API_BASE)


def tearDownModule():
    try:
        _post_json("/auth/test-cleanup", {})
    except Exception:
        pass


class TestAccount(unittest.TestCase):
    def test_get_account(self):
        account = _client.account.get()
        self.assertEqual(account["email"], TEST_EMAIL)
        self.assertIn("planTier", account)
        self.assertIn("userId", account)


class TestDocuments(unittest.TestCase):
    def test_list_documents(self):
        result = _client.documents.list()
        self.assertIn("documents", result)
        self.assertIsInstance(result["documents"], list)
        self.assertIn("meta", result)

    def test_list_with_filters(self):
        result = _client.documents.list(limit=5, offset=0)
        self.assertEqual(result["meta"]["limit"], 5)
        self.assertEqual(result["meta"]["offset"], 0)

    def test_upload_presigned_url(self):
        upload = _client.documents.upload("sdk-test.pdf", "application/pdf")
        self.assertIn("url", upload)
        self.assertIn("fields", upload)
        self.assertIsInstance(upload["url"], str)


class TestCollections(unittest.TestCase):
    _collection_id: int | None = None

    def test_1_create(self):
        result = _client.collections.create("Python SDK Test Collection")
        self.assertIn("collection", result)
        self.assertEqual(result["collection"]["name"], "Python SDK Test Collection")
        TestCollections._collection_id = result["collection"]["id"]

    def test_2_list(self):
        result = _client.collections.list()
        self.assertIn("collections", result)
        found = any(c["id"] == self._collection_id for c in result["collections"])
        self.assertTrue(found)

    def test_3_update(self):
        result = _client.collections.update(self._collection_id, name="Py SDK Renamed")
        self.assertEqual(result["collection"]["name"], "Py SDK Renamed")

    def test_4_delete(self):
        _client.collections.delete(self._collection_id)
        result = _client.collections.list()
        found = any(c["id"] == self._collection_id for c in result["collections"])
        self.assertFalse(found)


class TestTags(unittest.TestCase):
    def test_list_tags(self):
        result = _client.tags.list()
        self.assertIn("tags", result)
        self.assertIsInstance(result["tags"], list)


class TestThreads(unittest.TestCase):
    def test_list_threads(self):
        result = _client.threads.list()
        self.assertIn("threads", result)
        self.assertIsInstance(result["threads"], list)


class TestTeams(unittest.TestCase):
    def test_list_teams(self):
        result = _client.teams.list()
        self.assertIn("teams", result)
        self.assertIsInstance(result["teams"], list)


class TestWebhooks(unittest.TestCase):
    _webhook_id: str | None = None

    def test_1_list_empty(self):
        result = _client.webhooks.list()
        self.assertIn("webhooks", result)
        self.assertIsInstance(result["webhooks"], list)

    def test_2_create(self):
        result = _client.webhooks.create(
            url="https://example.com/py-webhook-test",
            events=["document.processed"],
        )
        self.assertIn("webhook", result)
        self.assertEqual(result["webhook"]["url"], "https://example.com/py-webhook-test")
        TestWebhooks._webhook_id = result["webhook"]["id"]

    def test_3_delete(self):
        _client.webhooks.delete(self._webhook_id)
        result = _client.webhooks.list()
        found = any(w["id"] == self._webhook_id for w in result["webhooks"])
        self.assertFalse(found)


class TestQuery(unittest.TestCase):
    def test_rag_query(self):
        result = _client.query.ask("What documents do I have?")
        self.assertIn("answer", result)
        self.assertIn("sources", result)
        self.assertIsInstance(result["answer"], str)
        self.assertIsInstance(result["sources"], list)


class TestErrorHandling(unittest.TestCase):
    def test_invalid_api_key(self):
        bad_client = LociClient(api_key="loci_invalid_key_12345", base_url=API_BASE)
        with self.assertRaises(LociApiError) as ctx:
            bad_client.account.get()
        self.assertEqual(ctx.exception.status_code, 401)


if __name__ == "__main__":
    unittest.main()
