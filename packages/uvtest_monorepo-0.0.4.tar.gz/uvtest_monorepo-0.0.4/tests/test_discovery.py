"""Tests for package discovery."""

import pytest
from pathlib import Path

from uvtest.discovery import (
    DuplicatePackageNameError,
    Package,
    _parse_project_dependencies,
    find_packages,
    _parse_package_name,
    _has_test_directory,
    _parse_test_dependencies,
    SKIP_DIRS,
    _should_skip_dir,
    build_local_package_index,
    resolve_local_dependency_paths,
)


class TestShouldSkipDir:
    """Tests for _should_skip_dir function."""

    def test_skips_venv(self):
        assert _should_skip_dir(".venv") is True

    def test_skips_pycache(self):
        assert _should_skip_dir("__pycache__") is True

    def test_skips_node_modules(self):
        assert _should_skip_dir("node_modules") is True

    def test_skips_git(self):
        assert _should_skip_dir(".git") is True

    def test_skips_hidden_dirs(self):
        assert _should_skip_dir(".hidden") is True
        assert _should_skip_dir(".mypy_cache") is True

    def test_allows_normal_dirs(self):
        assert _should_skip_dir("packages") is False
        assert _should_skip_dir("src") is False
        assert _should_skip_dir("libs") is False


class TestHasTestDirectory:
    """Tests for _has_test_directory function."""

    def test_detects_tests_dir(self, tmp_path: Path):
        (tmp_path / "tests").mkdir()
        assert _has_test_directory(tmp_path) is True

    def test_detects_test_dir(self, tmp_path: Path):
        (tmp_path / "test").mkdir()
        assert _has_test_directory(tmp_path) is True

    def test_no_test_dir(self, tmp_path: Path):
        assert _has_test_directory(tmp_path) is False

    def test_test_file_not_dir(self, tmp_path: Path):
        (tmp_path / "tests").write_text("")  # File, not directory
        assert _has_test_directory(tmp_path) is False


class TestParsePackageName:
    """Tests for _parse_package_name function."""

    def test_parses_valid_pyproject(self, tmp_path: Path):
        pyproject = tmp_path / "pyproject.toml"
        pyproject.write_text('[project]\nname = "my-package"')
        assert _parse_package_name(pyproject) == "my-package"

    def test_returns_none_for_missing_project_section(self, tmp_path: Path):
        pyproject = tmp_path / "pyproject.toml"
        pyproject.write_text('[build-system]\nrequires = ["hatchling"]')
        assert _parse_package_name(pyproject) is None

    def test_returns_none_for_missing_name(self, tmp_path: Path):
        pyproject = tmp_path / "pyproject.toml"
        pyproject.write_text('[project]\nversion = "1.0.0"')
        assert _parse_package_name(pyproject) is None

    def test_returns_none_for_invalid_toml(self, tmp_path: Path):
        pyproject = tmp_path / "pyproject.toml"
        pyproject.write_text("this is not valid toml [[[")
        assert _parse_package_name(pyproject) is None

    def test_returns_none_for_missing_file(self, tmp_path: Path):
        pyproject = tmp_path / "nonexistent.toml"
        assert _parse_package_name(pyproject) is None


class TestFindPackages:
    """Tests for find_packages function."""

    def test_finds_package_with_project_name(self, tmp_path: Path):
        # Create a package with pyproject.toml
        pkg_dir = tmp_path / "my-package"
        pkg_dir.mkdir()
        (pkg_dir / "pyproject.toml").write_text('[project]\nname = "my-package"')

        packages = find_packages(tmp_path)

        assert len(packages) == 1
        assert packages[0].name == "my-package"
        assert packages[0].path == pkg_dir
        assert packages[0].has_tests is False
        assert packages[0].pyproject_path == pkg_dir / "pyproject.toml"

    def test_falls_back_to_directory_name(self, tmp_path: Path):
        pkg_dir = tmp_path / "fallback-pkg"
        pkg_dir.mkdir()
        # No [project].name in pyproject.toml
        (pkg_dir / "pyproject.toml").write_text(
            '[build-system]\nrequires = ["hatchling"]'
        )

        packages = find_packages(tmp_path)

        assert len(packages) == 1
        assert packages[0].name == "fallback-pkg"

    def test_detects_tests_directory(self, tmp_path: Path):
        pkg_dir = tmp_path / "tested-pkg"
        pkg_dir.mkdir()
        (pkg_dir / "pyproject.toml").write_text('[project]\nname = "tested-pkg"')
        (pkg_dir / "tests").mkdir()

        packages = find_packages(tmp_path)

        assert len(packages) == 1
        assert packages[0].has_tests is True

    def test_detects_test_directory(self, tmp_path: Path):
        pkg_dir = tmp_path / "tested-pkg"
        pkg_dir.mkdir()
        (pkg_dir / "pyproject.toml").write_text('[project]\nname = "tested-pkg"')
        (pkg_dir / "test").mkdir()

        packages = find_packages(tmp_path)

        assert len(packages) == 1
        assert packages[0].has_tests is True

    def test_excludes_root_pyproject(self, tmp_path: Path):
        # Root pyproject.toml should be excluded
        (tmp_path / "pyproject.toml").write_text('[project]\nname = "root"')

        packages = find_packages(tmp_path)

        assert len(packages) == 0

    def test_finds_nested_packages(self, tmp_path: Path):
        # Create nested package structure
        packages_dir = tmp_path / "packages"
        packages_dir.mkdir()

        pkg1 = packages_dir / "pkg1"
        pkg1.mkdir()
        (pkg1 / "pyproject.toml").write_text('[project]\nname = "pkg1"')

        pkg2 = packages_dir / "pkg2"
        pkg2.mkdir()
        (pkg2 / "pyproject.toml").write_text('[project]\nname = "pkg2"')

        packages = find_packages(tmp_path)

        assert len(packages) == 2
        names = {p.name for p in packages}
        assert names == {"pkg1", "pkg2"}

    def test_skips_venv_directory(self, tmp_path: Path):
        venv_dir = tmp_path / ".venv"
        venv_dir.mkdir()
        pkg_in_venv = venv_dir / "site-packages" / "some-pkg"
        pkg_in_venv.mkdir(parents=True)
        (pkg_in_venv / "pyproject.toml").write_text('[project]\nname = "hidden"')

        packages = find_packages(tmp_path)

        assert len(packages) == 0

    def test_skips_node_modules(self, tmp_path: Path):
        nm_dir = tmp_path / "node_modules"
        nm_dir.mkdir()
        pkg_in_nm = nm_dir / "some-pkg"
        pkg_in_nm.mkdir()
        (pkg_in_nm / "pyproject.toml").write_text('[project]\nname = "hidden"')

        packages = find_packages(tmp_path)

        assert len(packages) == 0

    def test_skips_pycache(self, tmp_path: Path):
        cache_dir = tmp_path / "__pycache__"
        cache_dir.mkdir()
        # This would be unusual but we should still skip it
        (cache_dir / "pyproject.toml").write_text('[project]\nname = "hidden"')

        packages = find_packages(tmp_path)

        assert len(packages) == 0

    def test_skips_git_directory(self, tmp_path: Path):
        git_dir = tmp_path / ".git"
        git_dir.mkdir()
        (git_dir / "pyproject.toml").write_text('[project]\nname = "hidden"')

        packages = find_packages(tmp_path)

        assert len(packages) == 0

    def test_returns_sorted_packages(self, tmp_path: Path):
        # Create packages in random order
        for name in ["zeta", "alpha", "mango"]:
            pkg = tmp_path / name
            pkg.mkdir()
            (pkg / "pyproject.toml").write_text(f'[project]\nname = "{name}"')

        packages = find_packages(tmp_path)

        names = [p.name for p in packages]
        assert names == ["alpha", "mango", "zeta"]

    def test_handles_invalid_pyproject(self, tmp_path: Path):
        pkg_dir = tmp_path / "broken-pkg"
        pkg_dir.mkdir()
        (pkg_dir / "pyproject.toml").write_text("this is [[[ not valid toml")

        # Should still find the package with directory name fallback
        packages = find_packages(tmp_path)

        assert len(packages) == 1
        assert packages[0].name == "broken-pkg"

    def test_uses_cwd_by_default(self, tmp_path: Path, monkeypatch):
        pkg_dir = tmp_path / "cwd-pkg"
        pkg_dir.mkdir()
        (pkg_dir / "pyproject.toml").write_text('[project]\nname = "cwd-pkg"')

        monkeypatch.chdir(tmp_path)
        packages = find_packages()  # No argument

        assert len(packages) == 1
        assert packages[0].name == "cwd-pkg"

    def test_finds_deeply_nested_packages(self, tmp_path: Path):
        # Create deeply nested structure
        deep = tmp_path / "level1" / "level2" / "level3"
        deep.mkdir(parents=True)
        (deep / "pyproject.toml").write_text('[project]\nname = "deep-pkg"')

        packages = find_packages(tmp_path)

        assert len(packages) == 1
        assert packages[0].name == "deep-pkg"

    def test_multiple_packages_mixed_test_status(self, tmp_path: Path):
        # Package with tests
        pkg1 = tmp_path / "with-tests"
        pkg1.mkdir()
        (pkg1 / "pyproject.toml").write_text('[project]\nname = "with-tests"')
        (pkg1 / "tests").mkdir()

        # Package without tests
        pkg2 = tmp_path / "without-tests"
        pkg2.mkdir()
        (pkg2 / "pyproject.toml").write_text('[project]\nname = "without-tests"')

        packages = find_packages(tmp_path)

        pkg_map = {p.name: p for p in packages}
        assert pkg_map["with-tests"].has_tests is True
        assert pkg_map["without-tests"].has_tests is False


class TestParseTestDependencies:
    """Tests for _parse_test_dependencies function."""

    def test_parses_valid_dependency_groups(self, tmp_path: Path):
        pyproject = tmp_path / "pyproject.toml"
        pyproject.write_text(
            '[project]\nname = "test-pkg"\n\n'
            "[dependency-groups]\n"
            'test = ["pytest>=7.0", "pytest-cov>=4.0"]'
        )
        deps = _parse_test_dependencies(pyproject)
        assert deps == ["pytest>=7.0", "pytest-cov>=4.0"]

    def test_returns_empty_list_for_missing_dependency_groups(self, tmp_path: Path):
        pyproject = tmp_path / "pyproject.toml"
        pyproject.write_text('[project]\nname = "test-pkg"')
        deps = _parse_test_dependencies(pyproject)
        assert deps == []

    def test_returns_empty_list_for_missing_test_group(self, tmp_path: Path):
        pyproject = tmp_path / "pyproject.toml"
        pyproject.write_text(
            '[project]\nname = "test-pkg"\n\n'
            "[dependency-groups]\n"
            'dev = ["black", "ruff"]'
        )
        deps = _parse_test_dependencies(pyproject)
        assert deps == ["black", "ruff"]

    def test_combines_test_and_dev_groups_without_duplicates(self, tmp_path: Path):
        pyproject = tmp_path / "pyproject.toml"
        pyproject.write_text(
            '[project]\nname = "test-pkg"\n\n'
            "[dependency-groups]\n"
            'test = ["pytest", "pytest-cov"]\n'
            'dev = ["pytest", "ruff"]'
        )
        deps = _parse_test_dependencies(pyproject)
        assert deps == ["pytest", "pytest-cov", "ruff"]

    def test_returns_empty_list_for_invalid_toml(self, tmp_path: Path):
        pyproject = tmp_path / "pyproject.toml"
        pyproject.write_text("this is [[[ not valid toml")
        deps = _parse_test_dependencies(pyproject)
        assert deps == []

    def test_returns_empty_list_for_missing_file(self, tmp_path: Path):
        pyproject = tmp_path / "nonexistent.toml"
        deps = _parse_test_dependencies(pyproject)
        assert deps == []

    def test_handles_non_dict_dependency_groups(self, tmp_path: Path):
        pyproject = tmp_path / "pyproject.toml"
        pyproject.write_text(
            '[project]\nname = "test-pkg"\n\ndependency-groups = "not-a-dict"'
        )
        deps = _parse_test_dependencies(pyproject)
        assert deps == []

    def test_handles_non_list_test_group(self, tmp_path: Path):
        pyproject = tmp_path / "pyproject.toml"
        pyproject.write_text(
            '[project]\nname = "test-pkg"\n\n[dependency-groups]\ntest = "not-a-list"'
        )
        deps = _parse_test_dependencies(pyproject)
        assert deps == []

    def test_filters_non_string_entries(self, tmp_path: Path):
        pyproject = tmp_path / "pyproject.toml"
        pyproject.write_text(
            '[project]\nname = "test-pkg"\n\n'
            "[dependency-groups]\n"
            'test = ["pytest>=7.0", 123, "pytest-cov>=4.0", true]'
        )
        deps = _parse_test_dependencies(pyproject)
        # Should filter out non-string entries (123, true)
        assert deps == ["pytest>=7.0", "pytest-cov>=4.0"]

    def test_handles_empty_test_group(self, tmp_path: Path):
        pyproject = tmp_path / "pyproject.toml"
        pyproject.write_text(
            '[project]\nname = "test-pkg"\n\n[dependency-groups]\ntest = []'
        )
        deps = _parse_test_dependencies(pyproject)
        assert deps == []

    def test_parses_single_dependency(self, tmp_path: Path):
        pyproject = tmp_path / "pyproject.toml"
        pyproject.write_text(
            '[project]\nname = "test-pkg"\n\n[dependency-groups]\ntest = ["pytest"]'
        )
        deps = _parse_test_dependencies(pyproject)
        assert deps == ["pytest"]


class TestFindPackagesWithDependencies:
    """Tests for find_packages with dependency-groups parsing."""

    def test_includes_test_dependencies_in_package(self, tmp_path: Path):
        pkg_dir = tmp_path / "my-package"
        pkg_dir.mkdir()
        (pkg_dir / "pyproject.toml").write_text(
            '[project]\nname = "my-package"\n\n'
            "[dependency-groups]\n"
            'test = ["pytest>=7.0", "pytest-cov>=4.0"]'
        )

        packages = find_packages(tmp_path)

        assert len(packages) == 1
        assert packages[0].test_dependencies == ["pytest>=7.0", "pytest-cov>=4.0"]

    def test_includes_empty_list_when_no_dependency_groups(self, tmp_path: Path):
        pkg_dir = tmp_path / "my-package"
        pkg_dir.mkdir()
        (pkg_dir / "pyproject.toml").write_text('[project]\nname = "my-package"')

        packages = find_packages(tmp_path)

        assert len(packages) == 1
        assert packages[0].test_dependencies == []

    def test_multiple_packages_with_different_dependencies(self, tmp_path: Path):
        # Package 1 with dependencies
        pkg1 = tmp_path / "pkg1"
        pkg1.mkdir()
        (pkg1 / "pyproject.toml").write_text(
            '[project]\nname = "pkg1"\n\n'
            "[dependency-groups]\n"
            'test = ["pytest", "requests"]'
        )

        # Package 2 without dependencies
        pkg2 = tmp_path / "pkg2"
        pkg2.mkdir()
        (pkg2 / "pyproject.toml").write_text('[project]\nname = "pkg2"')

        # Package 3 with different dependencies
        pkg3 = tmp_path / "pkg3"
        pkg3.mkdir()
        (pkg3 / "pyproject.toml").write_text(
            '[project]\nname = "pkg3"\n\n[dependency-groups]\ntest = ["pytest-asyncio"]'
        )

        packages = find_packages(tmp_path)

        pkg_map = {p.name: p for p in packages}
        assert pkg_map["pkg1"].test_dependencies == ["pytest", "requests"]
        assert pkg_map["pkg2"].test_dependencies == []
        assert pkg_map["pkg3"].test_dependencies == ["pytest-asyncio"]


class TestParseProjectDependencies:
    """Tests for _parse_project_dependencies function."""

    def test_parses_runtime_dependencies(self, tmp_path: Path):
        pyproject = tmp_path / "pyproject.toml"
        pyproject.write_text(
            '[project]\nname = "test-pkg"\n'
            'dependencies = ["requests>=2", "local-lib>=1"]'
        )

        deps = _parse_project_dependencies(pyproject)

        assert deps == ["requests>=2", "local-lib>=1"]

    def test_returns_empty_list_for_missing_runtime_dependencies(self, tmp_path: Path):
        pyproject = tmp_path / "pyproject.toml"
        pyproject.write_text('[project]\nname = "test-pkg"')

        assert _parse_project_dependencies(pyproject) == []


class TestLocalDependencyResolution:
    """Tests for local sibling dependency resolution."""

    def test_find_packages_includes_runtime_dependencies(self, tmp_path: Path):
        pkg_dir = tmp_path / "my-package"
        pkg_dir.mkdir()
        (pkg_dir / "pyproject.toml").write_text(
            '[project]\nname = "my-package"\n'
            'dependencies = ["local-lib>=0.1", "requests>=2"]'
        )

        packages = find_packages(tmp_path)

        assert packages[0].dependencies == ["local-lib>=0.1", "requests>=2"]

    def test_build_local_package_index_raises_on_duplicate_names(self, tmp_path: Path):
        pkg1 = Package(
            name="my-package",
            path=tmp_path / "pkg1",
            has_tests=False,
            pyproject_path=tmp_path / "pkg1" / "pyproject.toml",
        )
        pkg2 = Package(
            name="my_package",
            path=tmp_path / "pkg2",
            has_tests=False,
            pyproject_path=tmp_path / "pkg2" / "pyproject.toml",
        )

        with pytest.raises(DuplicatePackageNameError):
            build_local_package_index([pkg1, pkg2])

    def test_resolves_recursive_local_dependencies(self, tmp_path: Path):
        pkg_core = Package(
            name="datapizza-ai-core",
            path=tmp_path / "core",
            has_tests=False,
            pyproject_path=tmp_path / "core" / "pyproject.toml",
        )
        pkg_mid = Package(
            name="datapizza-ai-mid",
            path=tmp_path / "mid",
            has_tests=False,
            pyproject_path=tmp_path / "mid" / "pyproject.toml",
            dependencies=["datapizza-ai-core>=0.1.0"],
        )
        pkg_app = Package(
            name="datapizza-ai-app",
            path=tmp_path / "app",
            has_tests=True,
            pyproject_path=tmp_path / "app" / "pyproject.toml",
            dependencies=["datapizza-ai-mid>=0.1.0", "requests>=2"],
        )

        package_index = build_local_package_index([pkg_app, pkg_mid, pkg_core])

        assert resolve_local_dependency_paths(pkg_app, package_index) == [
            pkg_core.path,
            pkg_mid.path,
        ]

    def test_ignores_invalid_and_external_requirements(self, tmp_path: Path):
        pkg_local = Package(
            name="local-lib",
            path=tmp_path / "local-lib",
            has_tests=False,
            pyproject_path=tmp_path / "local-lib" / "pyproject.toml",
        )
        pkg_app = Package(
            name="app",
            path=tmp_path / "app",
            has_tests=True,
            pyproject_path=tmp_path / "app" / "pyproject.toml",
            dependencies=["local-lib>=0.1", "not valid [[[", "requests>=2"],
        )

        package_index = build_local_package_index([pkg_app, pkg_local])

        assert resolve_local_dependency_paths(pkg_app, package_index) == [
            pkg_local.path
        ]
