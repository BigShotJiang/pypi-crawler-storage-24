"""Package discovery for UV monorepos."""

from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from packaging.requirements import InvalidRequirement, Requirement
from packaging.utils import canonicalize_name

# Use tomllib for Python 3.11+, fallback to tomli for 3.10
try:
    import tomllib
except ImportError:
    import tomli as tomllib  # type: ignore


# Directories to skip during discovery
SKIP_DIRS = frozenset(
    {
        ".venv",
        "__pycache__",
        "node_modules",
        ".git",
        ".tox",
        ".nox",
        "dist",
        "build",
        ".eggs",
    }
)


@dataclass
class Package:
    """Represents a discovered package in the monorepo."""

    name: str
    path: Path
    has_tests: bool
    pyproject_path: Path
    test_dependencies: list[str] = field(default_factory=list)
    dependencies: list[str] = field(default_factory=list)


class DuplicatePackageNameError(ValueError):
    """Raised when multiple local packages resolve to the same normalized name."""


def _load_pyproject_data(pyproject_path: Path) -> Optional[dict]:
    """Load pyproject.toml data, returning None on parse or IO errors."""
    try:
        with open(pyproject_path, "rb") as f:
            data = tomllib.load(f)
    except (OSError, tomllib.TOMLDecodeError):
        return None

    return data if isinstance(data, dict) else None


def _parse_package_name(pyproject_path: Path) -> Optional[str]:
    """Extract package name from pyproject.toml [project].name field.

    Returns None if the file cannot be parsed or doesn't have [project].name.
    """
    data = _load_pyproject_data(pyproject_path)
    if data is None:
        return None

    project = data.get("project", {})
    if not isinstance(project, dict):
        return None

    name = project.get("name")
    return name if isinstance(name, str) else None


def _has_test_directory(package_path: Path) -> bool:
    """Check if package has a tests/ or test/ directory."""
    return (package_path / "tests").is_dir() or (package_path / "test").is_dir()


def _parse_test_dependencies(pyproject_path: Path) -> list[str]:
    """Extract test dependencies from [dependency-groups].

    Prefers the ``test`` group and then appends unique entries from ``dev``.
    Returns an empty list if the file cannot be parsed, doesn't have the section,
    or if the section is malformed.
    """
    data = _load_pyproject_data(pyproject_path)
    if data is None:
        return []

    dependency_groups = data.get("dependency-groups", {})
    if not isinstance(dependency_groups, dict):
        return []

    dependencies: list[str] = []
    for group_name in ("test", "dev"):
        group_values = dependency_groups.get(group_name, [])
        if not isinstance(group_values, list):
            return []

        for dep in group_values:
            if isinstance(dep, str) and dep not in dependencies:
                dependencies.append(dep)

    return dependencies


def _parse_project_dependencies(pyproject_path: Path) -> list[str]:
    """Extract runtime dependencies from [project].dependencies."""
    data = _load_pyproject_data(pyproject_path)
    if data is None:
        return []

    project = data.get("project", {})
    if not isinstance(project, dict):
        return []

    dependencies = project.get("dependencies", [])
    if not isinstance(dependencies, list):
        return []

    return [dependency for dependency in dependencies if isinstance(dependency, str)]


def normalize_package_name(name: str) -> str:
    """Normalize package names for local dependency matching."""
    return canonicalize_name(name)


def build_local_package_index(packages: list[Package]) -> dict[str, Package]:
    """Build a normalized name -> package map for discovered local packages."""
    package_index: dict[str, Package] = {}

    for package in packages:
        normalized_name = normalize_package_name(package.name)
        existing = package_index.get(normalized_name)
        if existing is not None and existing.path != package.path:
            raise DuplicatePackageNameError(
                "Duplicate local package name "
                f"'{package.name}' found at '{existing.path}' and '{package.path}'."
            )
        package_index[normalized_name] = package

    return package_index


def resolve_local_dependency_paths(
    package: Package, package_index: dict[str, Package]
) -> list[Path]:
    """Resolve recursive local sibling dependencies for a package."""

    resolved_packages: list[Package] = []
    visiting: set[str] = set()
    visited: set[str] = set()

    def _visit(current_package: Package) -> None:
        current_name = normalize_package_name(current_package.name)
        if current_name in visiting:
            return

        visiting.add(current_name)
        for dependency in current_package.dependencies:
            try:
                dependency_name = normalize_package_name(Requirement(dependency).name)
            except InvalidRequirement:
                continue

            local_dependency = package_index.get(dependency_name)
            if local_dependency is None:
                continue

            if local_dependency.path == package.path:
                continue

            if dependency_name not in visited:
                _visit(local_dependency)
                visited.add(dependency_name)
                resolved_packages.append(local_dependency)

        visiting.remove(current_name)

    _visit(package)
    return [resolved_package.path for resolved_package in resolved_packages]


def _should_skip_dir(dirname: str) -> bool:
    """Check if directory should be skipped during discovery."""
    return dirname in SKIP_DIRS or dirname.startswith(".")


def find_packages(root: Optional[Path] = None) -> list[Package]:
    """Find all packages with pyproject.toml in subdirectories.

    Recursively searches for pyproject.toml files in subdirectories,
    excluding the root directory. Returns a list of Package objects
    with package metadata.

    Args:
        root: Root directory to search from. Defaults to current working directory.

    Returns:
        List of Package objects found in the monorepo.
    """
    if root is None:
        root = Path.cwd()
    root = root.resolve()

    packages: list[Package] = []

    def _scan_directory(directory: Path) -> None:
        """Recursively scan directory for packages."""
        try:
            entries = list(directory.iterdir())
        except PermissionError:
            return

        for entry in entries:
            if not entry.is_dir():
                continue

            if _should_skip_dir(entry.name):
                continue

            pyproject_path = entry / "pyproject.toml"
            if pyproject_path.is_file():
                # Found a package
                name = _parse_package_name(pyproject_path)
                if name is None:
                    # Fallback to directory name
                    name = entry.name

                packages.append(
                    Package(
                        name=name,
                        path=entry,
                        has_tests=_has_test_directory(entry),
                        pyproject_path=pyproject_path,
                        test_dependencies=_parse_test_dependencies(pyproject_path),
                        dependencies=_parse_project_dependencies(pyproject_path),
                    )
                )

            # Continue scanning subdirectories
            _scan_directory(entry)

    _scan_directory(root)

    # Sort packages by name for consistent output
    packages.sort(key=lambda p: p.name)

    return packages
