# What's New

## v0.20

* **Rule Quality curated pairs**: Rule Quality reports now compute only analyst-configured curated outcome→label pairs (instead of all observed pairs), while preserving existing precision/recall/F1 and best/worst rule summaries.
* **Curated pair catalog in Settings**: Added centralized pair management under **Settings → General** with create/toggle/delete controls and outcome/label dropdowns.
* **New settings APIs for curated pairs**: Added CRUD endpoints under `/api/v2/settings/rule-quality-pairs` plus `/options` for dropdown catalogs.
* **Async report snapshots**: Added `POST/GET /api/v2/analytics/rule-quality/reports` to request and poll persisted snapshots. Reports are frozen at a specific `freeze_at` timestamp and are reused until an explicit refresh request (`force_refresh=true`) is made.
* **Pair-set-aware report cache**: Rule quality report reuse now includes a pair-set hash, so changing curated pairs invalidates stale cached reports automatically.
* **Runtime lookback controls**: `GET /api/v2/analytics/rule-quality` now supports `lookback_days`. A new **Settings → General** page persists the default lookback via `GET/PUT /api/v2/settings/runtime` so teams can bound query windows without redeploying.
* **Bombardment fraud labeling**: Enhanced `scripts/bombard_evaluator.py` to optionally mark a small random portion of successful evaluations as fraud labels (default 1%) using `--fraud-rate` and labels API calls.
* **Fraud-shaped demo data generation**: `uv run ezrules generate-random-data` now seeds correlated payment events and list-backed rules that look more like analyst-facing fraud operations, including CNP geo mismatch, card-testing bursts, account-takeover reset patterns, and payout cash-out scenarios.
* **Showcase rule patterns in demo seed**: The generated sample rule set now also includes a few intentionally illustrative rules that demonstrate nested branching, loop-based signal counting, and customer-baseline computations.
* **Observation write-path optimization**: Field observations are now upserted in one query per event instead of one lookup per field, which matters much more now that demo events carry richer payloads.

## v0.18

* **Rule lifecycle states**: Rules now carry lifecycle metadata with `status` (`draft`, `active`, `archived`), `effective_from`, `approved_by`, and `approved_at`.
* **Promotion workflow**: Added `POST /api/v2/rules/{id}/promote` to transition draft rules to active with approver audit attribution.
* **Archive workflow**: Added `POST /api/v2/rules/{id}/archive` to archive rules and remove active rules from production evaluation.
* **Delete endpoint documented and permissioned**: `DELETE /api/v2/rules/{id}` is explicitly documented and guarded by `DELETE_RULE`.
* **UI lifecycle controls**: Rule list now shows lifecycle badges and includes promote/archive actions.
* **Audit trail enrichment**: Rule history entries now persist lifecycle/approval metadata plus explicit rule actions (`promoted`, `deactivated`, `deleted`) with target status transitions; deleted rules retain audit history and remain queryable via `GET /api/v2/audit/rules/{rule_id}`.
* **E2E setup guardrail**: Frontend e2e docs now explicitly require starting API with `EZRULES_TESTING=false` for invite/reset email flows; testing mode disables SMTP delivery and causes those tests to fail.

## v0.17

* **Invitation onboarding flow**: Added `POST /api/v2/users/invite` for admin-triggered email invitations. Invited users can complete onboarding via `POST /api/v2/auth/accept-invite` and set their own password.
* **Self-service password reset**: Added `POST /api/v2/auth/forgot-password` and `POST /api/v2/auth/reset-password` with one-time, expiring reset tokens. Admin intervention is no longer required for standard password resets.
* **Email delivery settings**: Added SMTP configuration keys (`EZRULES_SMTP_HOST`, `EZRULES_SMTP_PORT`, `EZRULES_SMTP_USER`, `EZRULES_SMTP_PASSWORD`, `EZRULES_FROM_EMAIL`) and `EZRULES_APP_BASE_URL` for invite/reset link generation.
* **Frontend auth pages**: Added dedicated pages/routes for invite acceptance, forgot password, and reset password. Login now includes a "Forgot password?" path.
* **Security hardening**: Invitation and reset tokens are stored as SHA-256 hashes, checked for expiration, and enforced as single-use. Successful password reset revokes active refresh sessions.

## v0.16

* **Full-stack Docker Compose**: Two new compose files replace the previous infrastructure-only setup.
  * `docker-compose.demo.yml` — starts the complete stack (PostgreSQL, Redis, Celery worker, FastAPI API, Angular frontend) and seeds the database with 10 sample rules and 100 events. One command to a working UI: `docker compose -f docker-compose.demo.yml up --build`.
  * `docker-compose.prod.yml` — same full stack with an empty database. Credentials are read from a `.env` file (template provided as `.env.example`).
* **`Dockerfile.frontend`**: New multi-stage Dockerfile (Node 20 build → nginx serve) for the Angular frontend.
* The original `docker-compose.yml` (PostgreSQL + Redis only) is unchanged and remains the recommended setup for local development.
* **API key authentication on evaluate**: `POST /api/v2/evaluate` now requires credentials. Pass an `X-API-Key` header with a key created via `POST /api/v2/api-keys`, or a standard Bearer JWT. Unauthenticated requests receive `401 Authentication required`.
* **API key management**: New endpoints `POST /api/v2/api-keys`, `GET /api/v2/api-keys`, `DELETE /api/v2/api-keys/{gid}` allow administrators with the `MANAGE_API_KEYS` permission to create, list, and revoke service API keys. The raw key is returned exactly once at creation and is never stored in plain text (only a SHA-256 hash is retained).
* **Body size limit**: All API requests are now rejected with `413 Request body too large` when the `Content-Length` header exceeds 1 MB (configurable via `EZRULES_MAX_BODY_SIZE_KB`).
* **Error sanitisation**: Internal errors from evaluate no longer leak exception messages; the response body is always `{"detail": "Evaluation failed"}`.

## v0.15

* **Server-side session revocation**: Refresh tokens are now tracked in a `user_session` database table. Logging out invalidates the refresh token immediately, preventing reuse even if a token is intercepted after logout.
* **Refresh token rotation**: Each call to `POST /api/v2/auth/refresh` deletes the presented token and issues a new one. A refresh token can be used exactly once; reuse returns `401 Session not found or already revoked`.
* **Logout endpoint**: New `POST /api/v2/auth/logout` endpoint accepts the current refresh token (plus a valid access token in the `Authorization` header) and deletes the session server-side. Multiple concurrent sessions (e.g. multiple browsers) are supported — only the presented token is revoked.
* **Lazy session cleanup**: Expired session rows for a user are deleted automatically on login, refresh, and logout, keeping the `user_session` table small without a background scheduler.

## v0.14

* **Shadow Rule Deployment**: Rules can now be deployed to a "shadow" environment that evaluates them against every incoming live event without affecting production outcomes. Shadow results are stored in a dedicated `shadow_results_log` table and never returned to callers. This complements backtesting (historical) with continuous live validation.
* **Deploy to Shadow button**: In the Rule Detail edit panel, a new amber "Deploy to Shadow" button sends the current draft of the rule logic to the shadow config.
* **Shadow Rules page**: A new **Shadow Rules** page (accessible from the sidebar) lists all rules currently in shadow, shows a summary of recent shadow outcomes, and provides per-rule "Promote to Production" and "Remove" actions.
* **Promote to production**: Promoting a rule moves its logic from the shadow config into the production config in one atomic step, then clears it from shadow. Both the production and shadow rule executors are invalidated so they pick up the change on the next request.
* **SHADOW badge**: Rules that have an active shadow version are annotated with an amber `SHADOW` badge in the Rule List and a "Shadow version active" badge in Rule Detail view mode.
* **New API endpoints**: `POST /api/v2/rules/{id}/shadow`, `DELETE /api/v2/rules/{id}/shadow`, `POST /api/v2/rules/{id}/shadow/promote`, `GET /api/v2/shadow`, `GET /api/v2/shadow/results`.
* **`in_shadow` field**: The `GET /api/v2/rules` response now includes `in_shadow: bool` on each rule item.

## v0.13.1

* **New PR Playwright E2E workflow**: added a dedicated GitHub Actions workflow that runs single-threaded Playwright end-to-end tests for pull requests against `main`, including backend/frontend startup and report artifact upload.

## v0.12

* **Field type management**: ezrules now auto-discovers the JSON types of event fields by observing traffic through `/api/v2/evaluate` and the **Test Rule** panel. Operators can declare a canonical type for each field (`integer`, `float`, `string`, `boolean`, `datetime`, `compare_as_is`) under **Settings → Field Types**. Values are cast to the declared type before rule execution, so comparisons like `$amount > 500` behave correctly regardless of how values arrive in JSON.
* **Per-type observation tracking**: field observations are recorded per `(field_name, observed_type)` pair, so if `amount` has been seen as both `int` and `str` you will see two separate rows with individual occurrence counts. This helps identify data quality issues upstream.
* **Casting at evaluation and test time**: `/api/v2/evaluate` rejects requests with a `400` error when a value cannot be cast to the configured type. The **Test Rule** panel surfaces the same error inline, giving immediate feedback before deployment.
* **Field type audit trail**: every create, update, and delete of a field type configuration is recorded in the audit trail. Accessible via **Audit Trail → Field Type History** in the UI or `GET /api/v2/audit/field-types`.
* **New API endpoints**: `GET /api/v2/field-types`, `GET /api/v2/field-types/observations`, `POST /api/v2/field-types`, `PUT /api/v2/field-types/{field_name}`, `DELETE /api/v2/field-types/{field_name}`, `GET /api/v2/audit/field-types`.
* **Sidebar Settings section**: the sidebar now groups **Role Management** and **Field Types** under a collapsible **Settings** section header.

## v0.11.2

* **License metadata consolidated**: License declarations in project metadata and documentation are now aligned with the repository's `LICENSE` file. ezrules is documented and published under Apache License 2.0.

## v0.11

* **Frontend authentication**: The Angular frontend now has full JWT authentication. Users must log in with email/password before accessing any page. Includes a login page, automatic token refresh, HTTP interceptor for attaching tokens to API requests, route guards that redirect unauthenticated users to login, and a Sign Out button in the sidebar. E2E tests use Playwright's global setup to authenticate once and share auth state across all tests.
* **Flask removal**: The legacy Flask manager service (`ezrules manager`) has been fully removed. The Angular frontend with FastAPI API v2 is now the sole interface.
* **Removed CLI commands**: `ezrules manager` and `ezrules evaluator` commands have been removed. Use `ezrules api` to start the service.
* **Removed dependencies**: Flask, Flask-Security-Too, Flask-WTF, Flask-CORS, Bootstrap-Flask, and pytz have been removed from the project dependencies. Gunicorn is retained for production deployments with uvicorn workers.
* **Standalone model mixins**: `AsaList`, `RoleMixin`, and `UserMixin` previously imported from flask_security are now defined directly in `ezrules.models.backend_core`, removing the flask_security dependency from the data model layer.
* **Removed Flask decorator**: The `requires_permission` Flask decorator in `ezrules.core.permissions` has been removed. The FastAPI API v2 uses its own `require_permission` dependency in `ezrules.backend.api_v2.auth.dependencies`.
* **Explicit versioning**: Replaced `history_meta.py` auto-versioning system with explicit `RuleHistory` and `RuleEngineConfigHistory` models. History snapshots are now created by helper functions (`save_rule_history`, `save_config_history`) before mutations, giving full control over when and how history is recorded.
* **Changed-by tracking**: Rule and configuration history entries now include a `changed_by` column that records who made each change (user email from API, `"cli"` from CLI commands). The Audit Trail page in the Angular frontend displays this in a new "Changed By" column.
* **Removed history_meta.py**: The SQLAlchemy event-listener-based `history_meta.py` module and all `versioned_session()` calls have been removed. Database tables must be recreated with `uv run ezrules init-db --auto-delete`.
* **Enhanced audit trail**: The audit trail now tracks changes to user lists (create, rename, delete, add/remove entries), outcomes (create, delete), and labels (create, delete) in addition to rules and configurations. Each audit entry records who performed the action and when. New API endpoints: `GET /api/v2/audit/user-lists`, `GET /api/v2/audit/outcomes`, `GET /api/v2/audit/labels`.
* **Accordion audit page**: The Audit Trail page has been redesigned with collapsible accordion sections for Rule History, Configuration History, User List History, Outcome History, and Label History. Sections are collapsed by default to reduce visual clutter. Action types are shown with color-coded badges (green for creates, red for deletes, blue for renames).

## v0.10

* **FastAPI Migration (In Progress)**: New API v2 service built on FastAPI for improved performance and modern async support
* **Evaluator merged into API service**: The standalone evaluator service (port 9999) has been merged into the main API service. Rule evaluation is now available at `/api/v2/evaluate` on port 8888. The `evaluator` CLI command is deprecated in favour of `api`.
* New CLI command `uv run ezrules api --port 8888` to start FastAPI server with optional `--reload` flag for development
* JWT authentication system (coming soon) - will support both local users and future OAuth/SSO integrations
* OpenAPI documentation automatically available at `/docs` (Swagger UI) and `/redoc`
* CORS configured for Angular development server (localhost:4200)
* **User Lists management page**: Angular frontend page for managing user lists and their entries. Accessible from the sidebar, supports creating/deleting lists, adding/removing entries with a master-detail layout. Backend API at `/api/v2/user-lists/`.
* **Database initialisation seeds default data**: `uv run ezrules init-db` now seeds default outcomes (RELEASE, HOLD, CANCEL) and default user lists (MiddleAsiaCountries, NACountries, LatamCountries) so rules using `@ListName` notation work out of the box.
* **Rule test endpoint accepts string outcomes**: The rule test endpoint (`POST /api/v2/rules/test`) now correctly handles rules that return string outcomes like `"HOLD"`, not just booleans.
* **Dashboard page**: Angular dashboard showing active rules count, transaction volume chart, and rule outcomes over time charts. Includes time range selector (1h, 6h, 12h, 24h, 30d). Accessible from sidebar and is the default landing page.
* **User Management admin panel**: Angular page at `/management/users` for managing user accounts. Supports creating users with optional role assignment, deleting users, toggling active/inactive status, admin-initiated password reset, and inline role assignment/removal. Accessible from sidebar "Security" link.
* **Role Management page**: Angular page at `/role_management` for managing roles. Supports creating roles with descriptions, assigning roles to users via dropdowns, removing roles from users, deleting roles (only when no users assigned), and links to per-role permission configuration. Accessible from sidebar "Settings" link.
* **Role Permissions page**: Angular page at `/role_management/{id}/permissions` for configuring per-role permissions. Displays all available permissions grouped by resource type with checkboxes, shows current permissions as green summary badges, and supports saving permission changes. Navigable from the Role Management page via "Manage Permissions" link.
* **Audit Trail page**: Angular page at `/audit` showing the history of rule and configuration changes. Displays two tables: Rule History (version, rule ID, description truncated to 100 chars, changed timestamp) and Configuration History (version, label, changed timestamp), each sorted by date descending. Accessible from the sidebar.

## v0.9

* Implementation of RBAC: per-resource access control, audit trail
* List and outcomes are now editable
* User management UI
* Role and permissions management UI
* Enhanced init-db script with interactive database management and --auto-delete option
* Transaction marking for analytics: mark transactions with true labels for fraud detection analysis
* Single event marking API endpoint (/mark-event) for programmatic labeling
* Bulk CSV upload interface for efficient batch labeling of events
* Enhanced CLI test data generation with realistic fraud patterns and label assignment
* Automatic default label creation (FRAUD, CHARGEBACK, NORMAL) for immediate testing
* Dashboard transaction volume chart with Chart.js: visualize transaction patterns over configurable time ranges
* Time aggregation options: 1 hour, 6 hours, 12 hours, 24 hours, and 30 days
* Real-time API endpoint for transaction volume data (/api/transaction_volume)
* **Label Analytics Dashboard**: Comprehensive analytics for ground truth labels with temporal analysis
* Total labeled events metric card tracking overall labeling coverage
* Individual time-series charts for each label type showing temporal trends over configurable time ranges
* Label analytics API endpoints: /api/labels_summary, /api/labels_distribution
* Configurable time ranges for label analytics (1h, 6h, 12h, 24h, 30d)
* Angular frontend revision navigation: clicking a rule revision link now navigates to a read-only view of that historical revision via GET /api/rules/<id>/revisions/<rev>
* **Outcomes management page**: Ported to Angular frontend. Users can list, create, and delete allowed outcomes via the new /outcomes page, reachable from the sidebar. Backend API endpoints added: GET/POST /api/outcomes, DELETE /api/outcomes/<name>
* **Label Analytics page ported to Angular frontend**: The /label_analytics page is now available in the Angular app, reachable via the sidebar "Analytics" link. Displays the total labeled events metric card and per-label time-series line charts powered by Chart.js, with a time range selector (1h, 6h, 12h, 24h, 30d) that updates charts in real time

## v0.7

* Migrated from Poetry to UV for faster dependency management
* Upgraded to Python 3.12 minimum requirement

## v0.6

* Ability to backtest rule changes: make change, submit for backtesting, check result
* Switch to pydantic-based settings management
* Transaction submitted for testing are now saved in the history table
* Rule evaluation results are now saved in the history table
* New CLI utilities to generate test data

## v0.5

* The app is compatible with AWS EKS
* Basic testing introduced
* Rule history is maintained through a history table
* Standalone scripts to init the db and add a user
* Internally, switch to poetry dependency management
* Manager and evaluator can run as executables

## v0.4

* RDBMS are now supported as a backend for rule configuration storage
* The application can now be deployed in a k8s cluster

## v0.3

* At-notation is available. Constructs of type `if $send_country in @Latam...`
* Users are now required to login to make changes to the rule set

## v0.2

* Dollar-notation can be used to refer to attributes, e.g. `if $amount>1000...`
* When you create a rule, you can now test it right away before deploying
* Outcomes of rules are now controlled against a list of allowed outcomes
* When a rule is edited, there is now a warning that someone else is working on it too
* Each rule revision now has a timestamp associated with it
* For rules with modification history, see the changelog with highlighted diffs

## v0.1

* A better documentation on rules writing
* Fixed a bug wherein the lambda rule executor was not properly configured with the environment variable
* Rule evaluator app now accepts lambda function name through an environment variable
* Rule manager fetched the s3 bucket name from an environment variable now
* Rule manager backend table name is now automatically configured with `DYNAMODB_RULE_MANAGER_TABLE_NAME` environment variable
* General code cleanup

## v0.0

* A single script that deploys application to AWS
* This is a first release, so all previous changes are squashed into it
