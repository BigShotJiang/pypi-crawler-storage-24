# Repo skills

Design rules:
- Keep each skill scoped to one job.
- Write the description like routing logic, not marketing copy.
- Include "use when" and "do not use when" criteria.
- Add at least one negative example for adjacent tasks.
- Put templates and worked examples inside the skill folder.
- Keep the root `AGENTS.md` for always-on rules only.

Canonical skills included here:
- `plan`
- `implement`
- `docs`
- `publish`
- `exec-plan`
- `skill-instantiator`
