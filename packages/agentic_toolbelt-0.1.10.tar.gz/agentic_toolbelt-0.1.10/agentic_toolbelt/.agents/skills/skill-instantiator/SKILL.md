---
name: skill-instantiator
description: Create focused skill and specialist role artifacts when a valid task capability is not covered by existing catalog entries.
---
## Use when
- a requested task type is not covered by existing canonical repo skills
- repeated ask patterns suggest a stable specialist role should be added
- a `.agents`/`.github/agents`/`templates/codex/agents` change is needed to reduce recurring handoff errors

## Do not use when
- the change is routine one-off refactoring
- task is fully covered by existing `implement`/`planner`/`docs`/`reviewer` flows
- dependency, security, or migration changes dominate and are better routed to dedicated chain nodes

## Inputs
- task intent and missing capabilities
- existing skills and agent catalog inventory
- allowed scope for instruction/system-file edits

## Outputs
- created or updated skill definition file(s)
- updated catalog handoff recommendation
- ownership-safe scope declaration and validation checklist

## Success criteria
- new catalog artifacts are minimal, coherent, and discoverable
- capability-to-role mapping is explicit
- ownership and validation steps are clear to downstream reviewers

## Routing
1. coordinator confirms whether the capability is already covered
2. coordinator records owned scope for catalog edits
3. skill-instantiator creates canonical files for any missing skill or specialist role
   - `.agents/skills/<name>/SKILL.md`
   - `.github/agents/<name>.agent.md` (for platform-supported execution)
   - `templates/codex/agents/<name>.toml`
4. if needed, define a cohesive specialist cohort (e.g., one specialist for each recurring failure mode)
5. coordinator routes output through validation (`test-engineer`) and review (`reviewer`) before use

## Shared memory
Write a compact update to `.agent-memory/events/` with:
- gap summary
- created/updated artifact paths
- remaining follow-up for cohort stabilization
