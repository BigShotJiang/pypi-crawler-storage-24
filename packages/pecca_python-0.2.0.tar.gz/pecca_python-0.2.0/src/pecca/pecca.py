"""
Pecca Python SDK — Phase 2
Supports pecca_cloud, custom cloud, and local (DuckDB + ChromaDB) knowledge bases.
"""

import os
import json
import pathlib
import requests
import pandas as pd


class Pecca:
    BASE_URL = "https://pecca-core-engine-dev.politerock-4db9b7c6.southindia.azurecontainerapps.io"
    HEADERS = {"Accept": "application/json"}

    def __init__(
        self,
        api_key: str,
        custom_clouds: list = None,
        primary_location: str = "local",
        base_url: str = None,
    ):
        """
        Initialize the Pecca SDK client.

        Args:
            api_key: Your Pecca API key (project-scoped).
            custom_clouds: Optional list of custom cloud configs to pre-declare, each a dict with:
                           {"name": str, "mysql_conn": str|None, "psql_conn": str|None}
                           These are upserted to encrypted server-side storage and merged with
                           any previously persisted credentials for this project.
                           You can also add clouds later with add_new_cloud().
            primary_location: Merge target for cross-source SQL joins.
                              "local" (default), "pecca_cloud", or a custom cloud name.
                              Use assign_primary_location() to change this at any time.
            base_url: Override the default server URL (e.g. "http://localhost:8000" for local dev).
                      Must be set here — not after construction — so credential sync uses the right server.
        """
        self.api_key = api_key
        if base_url:
            self.BASE_URL = base_url
        constructor_clouds = list(custom_clouds or [])
        self.custom_clouds = list(constructor_clouds)
        self.primary_location = primary_location

        # Lazily populated
        self._project_info = None

        # Tracked local KB state (populated on upload_to_knowledge_base with source="local")
        self._local_structured_tables: list = []   # [{parquet_path, file_name, columns, row_count}]
        self._local_chromadb_path: str = None       # abs path to the ChromaDB directory
        self._local_base_path: str = None           # default local storage root (set by assign_primary_location)

        # Sync credentials: load stored creds from server + persist constructor-provided ones
        self._sync_credentials(constructor_clouds)

    def _sync_credentials(self, constructor_clouds: list) -> None:
        """
        Two-way sync between constructor-provided credentials and server-side encrypted storage.

        1. Load stored credentials from server → append any that are not in self.custom_clouds.
        2. Upsert each constructor-provided credential to server (update if exists, insert if new).

        Constructor-provided entries take precedence for the same name (already in self.custom_clouds).
        Failures are silenced so the SDK remains usable in offline / local-only scenarios.
        """
        try:
            # Step 1: load stored credentials, append server-only entries
            resp = requests.get(
                f"{self.BASE_URL}/credentials/list",
                params={"api_key": self.api_key},
                headers=self.HEADERS,
                timeout=10,
            )
            if resp.status_code == 200:
                stored = resp.json().get("credentials", [])
                constructor_names = {c["name"] for c in constructor_clouds}
                for cred in stored:
                    if cred["name"] not in constructor_names:
                        self.custom_clouds.append(cred)
        except Exception:
            pass  # offline or server unreachable — continue with constructor-provided only

        try:
            # Step 2: upsert constructor-provided credentials to server
            for cloud in constructor_clouds:
                requests.post(
                    f"{self.BASE_URL}/credentials/store",
                    data={
                        "api_key": self.api_key,
                        "name": cloud["name"],
                        "mysql_conn": cloud.get("mysql_conn") or "",
                        "psql_conn": cloud.get("psql_conn") or "",
                        "upsert": "true",
                    },
                    headers=self.HEADERS,
                    timeout=10,
                )
        except Exception:
            pass  # offline — credentials stay in-memory only for this session

    # -----------------------------------------------------------------------
    # Dynamic cloud & location management
    # -----------------------------------------------------------------------

    def add_new_cloud(self, connection: dict) -> None:
        """
        Register a new custom cloud connection and persist it to encrypted server-side storage.

        Args:
            connection: dict with keys:
                "name"       (required) — unique identifier for this cloud
                "mysql_conn" (optional) — MySQL connection string
                "psql_conn"  (optional) — PostgreSQL connection string
                At least one of mysql_conn or psql_conn must be provided.

        Raises:
            ValueError: if 'name' is missing, no connection string is given,
                        or a cloud with the same name is already registered
                        (in memory or on the server). Use remove_connection()
                        before re-adding a connection with the same name.
        """
        name = connection.get("name")
        if not name:
            raise ValueError("connection must include a 'name' key.")
        if not (connection.get("mysql_conn") or connection.get("psql_conn")):
            raise ValueError("connection must include at least 'mysql_conn' or 'psql_conn'.")
        if any(c.get("name") == name for c in self.custom_clouds):
            raise ValueError(
                f"Connection '{name}' is already registered. "
                "Use remove_connection('{name}') before re-adding.".format(name=name)
            )

        # Persist to server (strict insert — 409 if name already exists in DB)
        resp = requests.post(
            f"{self.BASE_URL}/credentials/store",
            data={
                "api_key": self.api_key,
                "name": name,
                "mysql_conn": connection.get("mysql_conn") or "",
                "psql_conn": connection.get("psql_conn") or "",
                "upsert": "false",
            },
            headers=self.HEADERS,
            timeout=10,
        )
        if resp.status_code == 409:
            raise ValueError(
                f"Connection '{name}' already exists for this project on the server. "
                "Use remove_connection('{name}') before re-adding.".format(name=name)
            )
        resp.raise_for_status()

        self.custom_clouds.append(connection)

    def assign_primary_location(self, primary_location: str, path: str = None) -> None:
        """
        Set (or change) the primary location used as the merge target for cross-source queries.

        Args:
            primary_location: "local", "pecca_cloud", or a name registered via add_new_cloud().
            path: Base directory for local storage. Only used when primary_location="local".
                  Defaults to ./pecca_kb in the current working directory if not provided.

        Raises:
            ValueError: if primary_location is not a known location.
        """
        known = {"pecca_cloud", "local"} | {c["name"] for c in self.custom_clouds}
        if primary_location not in known:
            raise ValueError(
                f"Unknown location '{primary_location}'. "
                "Register it first with add_new_cloud() or use 'pecca_cloud' / 'local'."
            )
        self.primary_location = primary_location
        if primary_location == "local":
            self._local_base_path = path or os.path.join(os.getcwd(), "pecca_kb")

    def remove_connection(self, name: str) -> dict:
        """
        Remove a custom cloud connection from in-memory state and server-side encrypted storage.

        Args:
            name: The connection name to remove (as passed to add_new_cloud).

        Returns:
            Server response dict, e.g. {"status": "removed", "name": "my_cloud"}.

        Raises:
            requests.HTTPError: if the connection is not found on the server (404).
        """
        resp = requests.delete(
            f"{self.BASE_URL}/credentials/remove",
            params={"api_key": self.api_key, "name": name},
            headers=self.HEADERS,
            timeout=10,
        )
        resp.raise_for_status()
        self.custom_clouds = [c for c in self.custom_clouds if c.get("name") != name]
        return resp.json()

    # -----------------------------------------------------------------------
    # Project info
    # -----------------------------------------------------------------------

    def _get_project_info(self) -> dict:
        """Fetch and cache project info (project_id, project_name) for this API key."""
        if not self._project_info:
            resp = requests.get(
                f"{self.BASE_URL}/project/info",
                params={"api_key": self.api_key},
                headers=self.HEADERS
            )
            resp.raise_for_status()
            self._project_info = resp.json()
        return self._project_info

    # -----------------------------------------------------------------------
    # Upload
    # -----------------------------------------------------------------------

    def upload_to_knowledge_base(
        self,
        file_path: str,
        path: str = None,
        source: str = None
    ) -> dict:
        """
        Upload a file to the knowledge base.

        Default routing (when source=None):
            Structured files (CSV, Excel, Parquet) → stored locally as Parquet (requires path).
            Unstructured files (PDF, DOCX, TXT)    → stored in pecca_cloud (pgvector).

        Args:
            file_path: Local path to the file.
            path: Base directory for local structured storage.
                  Parquet written to {path}/structured/{filename}.parquet
                  Required for structured files.
            source: Override the default routing.
                    "local"        — force local storage (structured or unstructured).
                    "pecca_cloud"  — force pecca_cloud for both types.
                    "<custom_name>" — a custom cloud defined in custom_clouds.
                    None (default) — auto-route: structured→local, unstructured→pecca_cloud.
        """
        file_name = os.path.basename(file_path)
        file_ext = pathlib.Path(file_path).suffix.lower()
        is_structured = file_ext in {".csv", ".xlsx", ".xls", ".parquet"}

        # Auto-route by file type when no explicit source is given
        if source is None:
            if is_structured:
                return self._upload_local(file_path, file_name, file_ext, is_structured, path)
            else:
                return self._upload_to_cloud(file_path, file_name, "pecca_cloud")

        if source == "local":
            return self._upload_local(file_path, file_name, file_ext, is_structured, path)
        else:
            return self._upload_to_cloud(file_path, file_name, source)

    def _upload_to_cloud(self, file_path: str, file_name: str, source: str) -> dict:
        """Send file to /upload_to_cloud with optional custom cloud credentials."""
        custom = next((c for c in self.custom_clouds if c.get("name") == source), None)
        if source != "pecca_cloud" and not custom:
            raise ValueError(
                f"No credentials found for cloud '{source}'. "
                "Use client.add_new_cloud({'name': '...', 'mysql_conn': '...', 'psql_conn': '...'}) to register it."
            )
        if custom:
            is_structured = pathlib.Path(file_name).suffix.lower() in {".csv", ".xlsx", ".xls", ".parquet"}
            if not is_structured and not custom.get("psql_conn"):
                raise ValueError(
                    f"Cannot upload unstructured file '{file_name}' to cloud '{source}': "
                    "this connection does not have a PostgreSQL (pgvector) database. "
                    "Add a 'psql_conn' to this cloud or use 'pecca_cloud' instead."
                )
            if is_structured and not custom.get("mysql_conn"):
                raise ValueError(
                    f"Cannot upload structured file '{file_name}' to cloud '{source}': "
                    "this connection does not have a MySQL database. "
                    "Add a 'mysql_conn' to this cloud or use 'pecca_cloud' instead."
                )

        data = {
            "api_key": self.api_key,
            "source": source,
        }
        if custom:
            if custom.get("mysql_conn"):
                data["mysql_conn"] = custom["mysql_conn"]
            if custom.get("psql_conn"):
                data["psql_conn"] = custom["psql_conn"]

        with open(file_path, "rb") as f:
            resp = requests.post(
                f"{self.BASE_URL}/upload_to_cloud",
                files={"file": (file_name, f)},
                data=data
            )
        resp.raise_for_status()
        return resp.json()

    def _upload_local(
        self, file_path: str, file_name: str, file_ext: str,
        is_structured: bool, path: str
    ) -> dict:
        """
        Local upload:
        - Structured: SDK converts to Parquet, tells server to update metadata only.
        - Unstructured: SDK sends raw file to server for embedding generation;
          server returns chunks+embeddings; SDK stores in ChromaDB.
        """
        resolved_path = path or self._local_base_path or os.path.join(os.getcwd(), "pecca_kb")
        path = resolved_path

        if is_structured:
            return self._upload_local_structured(file_path, file_name, file_ext, path)
        else:
            return self._upload_local_unstructured(file_path, file_name, path)

    def _upload_local_structured(
        self, file_path: str, file_name: str, file_ext: str, path: str
    ) -> dict:
        """Convert file to Parquet locally, register metadata with server."""
        structured_dir = os.path.join(path, "structured")
        os.makedirs(structured_dir, exist_ok=True)

        df = self._read_file_as_df(file_path, file_ext)
        stem = pathlib.Path(file_name).stem
        parquet_path = os.path.abspath(os.path.join(structured_dir, stem + ".parquet"))
        df.to_parquet(parquet_path, index=False)

        schema = [{"name": col, "type": str(df[col].dtype)} for col in df.columns]

        resp = requests.post(
            f"{self.BASE_URL}/upload_to_local",
            data={
                "api_key": self.api_key,
                "file_name": file_name,
                "file_type": "structured",
                "local_parquet_path": parquet_path,
                "schema": json.dumps(schema),
                "row_count": str(len(df))
            }
        )
        resp.raise_for_status()

        # Track locally for automatic local_schema inclusion in queries
        self._local_structured_tables.append({
            "parquet_path": parquet_path,
            "file_name": file_name,
            "columns": schema,
            "row_count": len(df)
        })

        return resp.json()

    def _upload_local_unstructured(self, file_path: str, file_name: str, path: str) -> dict:
        """
        Send raw file to server. Server generates embeddings and returns chunks.
        SDK stores chunks+embeddings in local ChromaDB.
        """
        with open(file_path, "rb") as f:
            resp = requests.post(
                f"{self.BASE_URL}/upload_to_local",
                files={"file": (file_name, f)},
                data={
                    "api_key": self.api_key,
                    "file_name": file_name,
                    "file_type": "unstructured",
                    "local_base_path": os.path.abspath(path)
                }
            )
        resp.raise_for_status()
        result = resp.json()

        if result.get("status") != "success":
            return result

        chromadb_path = result.get("chromadb_path", os.path.join(os.path.abspath(path), "unstructured_kb"))
        chunks = result.get("chunks", [])

        if chunks:
            self._save_to_chromadb(chromadb_path, file_name, chunks)
            self._local_chromadb_path = chromadb_path

        return {"status": "success", "file_name": file_name, "chromadb_path": chromadb_path}

    def _save_to_chromadb(self, chromadb_path: str, document_name: str, chunks: list):
        """Persist embedding chunks to a local ChromaDB collection."""
        import chromadb as chromadb_lib
        client = chromadb_lib.PersistentClient(path=chromadb_path)
        collection = client.get_or_create_collection(name="local_kb")

        ids = [f"{document_name}_{c['chunk_index']}" for c in chunks]
        embeddings = [c["embedding"] for c in chunks]
        documents = [c["text"] for c in chunks]
        metadatas = [
            {"document_name": document_name, "chunk_index": c["chunk_index"]}
            for c in chunks
        ]
        collection.upsert(ids=ids, embeddings=embeddings, documents=documents, metadatas=metadatas)

    # -----------------------------------------------------------------------
    # Query
    # -----------------------------------------------------------------------

    def ask_pecca(
        self,
        user_query: str,
        use_only_knowledge_base: bool = False,
        generate_graph: bool = False,
        source_filter: list = None
    ) -> dict:
        """
        Ask a natural language question against your knowledge base.

        Automatically handles two-phase queries: if local data is involved,
        the SDK executes DuckDB/ChromaDB locally and calls /query/finalize
        transparently before returning the final answer.

        Args:
            user_query: Your question in plain English.
            use_only_knowledge_base: If True, only answer from KB data.
            generate_graph: If True, attempt to generate a visualization.
            source_filter: Limit query to specific sources (e.g. ["pecca_cloud", "local"]).
        """
        local_schema = None
        if self._local_structured_tables or self._local_chromadb_path:
            local_schema = {
                "structured": self._local_structured_tables,
                "unstructured_chromadb_path": self._local_chromadb_path
            }

        payload = {
            "api_key": self.api_key,
            "user_query": user_query,
            "use_only_knowledge_base": use_only_knowledge_base,
            "generate_graph": generate_graph,
            "custom_clouds": self.custom_clouds,
            "primary_location": self.primary_location,
            "source_filter": source_filter or [],
            "local_schema": local_schema
        }

        resp = requests.post(f"{self.BASE_URL}/query", json=payload, headers=self.HEADERS)
        resp.raise_for_status()
        result = resp.json()

        if result.get("type") == "query_plan":
            return self._handle_query_plan(result, use_only_knowledge_base, generate_graph)

        return result

    def _handle_query_plan(
        self,
        plan: dict,
        use_only_knowledge_base: bool,
        generate_graph: bool
    ) -> dict:
        """
        Execute local DuckDB / ChromaDB queries and call /query/finalize.
        Called transparently from ask_pecca when server returns a query_plan.
        """
        inference_id = plan["inference_id"]
        mode = plan.get("mode")
        result_dataframe = None
        local_semantic_docs = None

        if mode == "structured_local":
            duckdb_sql = plan.get("duckdb_sql")
            cloud_dataframes = plan.get("cloud_dataframes", [])

            if duckdb_sql:
                try:
                    import duckdb
                    conn = duckdb.connect()

                    # Register cloud DataFrames as in-memory DuckDB views
                    for cdf in cloud_dataframes:
                        alias = cdf["alias"]
                        df = pd.DataFrame(cdf["data"], columns=cdf["columns"])
                        conn.register(alias, df)

                    local_df = conn.execute(duckdb_sql).df()
                    result_dataframe = local_df.to_dict("records") if not local_df.empty else []
                except Exception as e:
                    print(f"[Pecca SDK] DuckDB execution failed: {e}")
                    result_dataframe = []

        elif mode == "unstructured_local":
            query_embedding = plan.get("query_embedding")
            cloud_docs = plan.get("cloud_semantic_docs", [])
            local_docs = []

            if query_embedding and self._local_chromadb_path:
                try:
                    import chromadb as chromadb_lib
                    client = chromadb_lib.PersistentClient(path=self._local_chromadb_path)
                    collection = client.get_collection("local_kb")
                    results = collection.query(query_embeddings=[query_embedding], n_results=10)

                    for doc, meta, dist in zip(
                        results["documents"][0],
                        results["metadatas"][0],
                        results["distances"][0]
                    ):
                        local_docs.append({
                            "document_name": meta.get("document_name", "local"),
                            "chunk_text": doc,
                            "similarity": max(0.0, 1.0 - dist)
                        })
                except Exception as e:
                    print(f"[Pecca SDK] ChromaDB query failed: {e}")

            local_semantic_docs = cloud_docs + local_docs

        # Send local results to server for steps 3a+4+5
        finalize_payload = {
            "api_key": self.api_key,
            "inference_id": inference_id,
            "use_only_knowledge_base": use_only_knowledge_base,
            "generate_graph": generate_graph,
            "result_dataframe": result_dataframe,
            "local_semantic_docs": local_semantic_docs
        }

        final_resp = requests.post(
            f"{self.BASE_URL}/query/finalize",
            json=finalize_payload,
            headers=self.HEADERS
        )
        final_resp.raise_for_status()
        final_result = final_resp.json()
        if mode == "structured_local" and plan.get("duckdb_sql"):
            final_result["duckdb_sql"] = plan["duckdb_sql"]
        return final_result

    # -----------------------------------------------------------------------
    # Knowledge base management
    # -----------------------------------------------------------------------

    def view_knowledge_base(self) -> dict:
        """List all files in the project's knowledge base."""
        params = {"api_key": self.api_key}
        resp = requests.get(f"{self.BASE_URL}/view", params=params, headers=self.HEADERS)
        resp.raise_for_status()
        return resp.json()

    def list_connections(self) -> dict:
        """
        Return the unique sources/connections used by this project's knowledge base,
        grouped with the files that belong to each.

        Returns:
            {
                "connections": [
                    {
                        "source": "pecca_cloud",
                        "file_count": 2,
                        "files": [{"file_name": "sales.csv", "type": "structured"}, ...]
                    },
                    ...
                ]
            }
        """
        kb = self.view_knowledge_base()
        files = kb.get("files", [])

        grouped: dict = {}
        for f in files:
            src = f.get("source", "unknown")
            if src not in grouped:
                grouped[src] = []
            grouped[src].append({"file_name": f.get("file_name"), "type": f.get("type")})

        connections = [
            {"source": src, "file_count": len(flist), "files": flist}
            for src, flist in grouped.items()
        ]

        # Include registered custom clouds that currently have no files
        registered_names = {c["source"] for c in connections}
        for cloud in self.custom_clouds:
            cloud_name = cloud.get("name")
            if cloud_name and cloud_name not in registered_names:
                connections.append({
                    "source": cloud_name,
                    "file_count": 0,
                    "files": []
                })

        return {"connections": connections}

    def delete_from_knowledge_base(self, file_name: str) -> dict:
        """Delete a file from the knowledge base by its original filename."""
        payload = {"api_key": self.api_key, "file_name": file_name}
        resp = requests.delete(f"{self.BASE_URL}/delete", params=payload, headers=self.HEADERS)
        resp.raise_for_status()
        result = resp.json()

        if result.get("status") == "success":
            details = result.get("details", {})

            # Structured local: delete the parquet file from disk
            parquet_path = details.get("local_parquet_path")
            if parquet_path and os.path.exists(parquet_path):
                os.remove(parquet_path)
            self._local_structured_tables = [
                t for t in self._local_structured_tables if t.get("file_name") != file_name
            ]

            # Unstructured local: delete document chunks from ChromaDB
            chromadb_path = details.get("local_chromadb_path")
            if chromadb_path and os.path.isdir(chromadb_path):
                try:
                    import chromadb as chromadb_lib
                    chroma_client = chromadb_lib.PersistentClient(path=chromadb_path)
                    collection = chroma_client.get_collection("local_kb")
                    existing = collection.get(where={"document_name": file_name})
                    if existing["ids"]:
                        collection.delete(ids=existing["ids"])
                except Exception as e:
                    print(f"[Pecca SDK] ChromaDB deletion failed: {e}")

        return result

    def download_chart(self, inference_id: str) -> str:
        """Download a generated chart HTML by inference_id."""
        params = {"api_key": self.api_key, "inference_id": inference_id}
        resp = requests.get(f"{self.BASE_URL}/download-chart", params=params)
        return resp.text

    # -----------------------------------------------------------------------
    # Internal helpers
    # -----------------------------------------------------------------------

    def _read_file_as_df(self, file_path: str, file_ext: str) -> pd.DataFrame:
        if file_ext == ".csv":
            return pd.read_csv(file_path)
        elif file_ext in (".xlsx", ".xls"):
            return pd.read_excel(file_path)
        elif file_ext == ".parquet":
            return pd.read_parquet(file_path)
        raise ValueError(f"Unsupported structured file type: {file_ext}")
