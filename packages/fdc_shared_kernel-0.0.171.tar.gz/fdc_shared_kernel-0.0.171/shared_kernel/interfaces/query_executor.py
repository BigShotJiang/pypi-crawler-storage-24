"""Base interface for query executors."""

from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional, Tuple


class DataWarehouseQueryExecutor(ABC):
    """
    Abstract base class for data warehouse query executors.
    """

    @abstractmethod
    def execute_query(
        self,
        query: str,
        params: Optional[tuple] = None,
    ) -> List[Dict[str, Any]]:
        pass

    @abstractmethod
    def execute_queries(
        self,
        queries: List[str],
    ) -> List[List[Dict[str, Any]]]:
        pass

    @abstractmethod
    def execute_query_with_column_types(
        self,
        query: str,
        params: Optional[tuple] = None,
    ) -> Tuple[List[Dict[str, Any]], List[Tuple]]:
        pass
    