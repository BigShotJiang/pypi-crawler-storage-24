from abc import ABC, abstractmethod


class WarehouseHandler(ABC):
    """
    Base abstract class for data warehouse handlers.
    """

    def __init__(self, payload: dict = None):
        self.payload = payload or {}
        pagination = self.payload.get("pagination") or {}
        self.pagination = pagination
        self.page = pagination.get("page") if isinstance(pagination, dict) else None
        self.limit = pagination.get("limit") if isinstance(pagination, dict) else None
        self.search = self.payload.get("search")

    @abstractmethod
    def get_config(self):
        pass

    @abstractmethod
    def get_executor(self):
        pass

    @abstractmethod
    def get_query_object(self):
        pass
    