"""Base interface for data warehouse connections."""

from abc import ABC, abstractmethod


class DataWarehouseConnection(ABC):
    """Abstract base class for data warehouse connections."""

    @abstractmethod
    def __init__(self, source_config) -> None:
        super().__init__()

    @abstractmethod
    def get_connection(self, retries: int, delay: int):
        pass

    @abstractmethod
    def is_valid_connection(self):
        pass

    @abstractmethod
    def close_connection(self):
        pass

    @abstractmethod
    def test_connection(self):
        pass
