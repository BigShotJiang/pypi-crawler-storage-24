from pypika import Query

from shared_kernel.data_warehouse_handlers.connections.postgresql_warehouse_connection import PostgreSQLWarehouseConnection
from shared_kernel.data_warehouse_handlers.query_executors.postgresql_query_executor import PostgreSQLQueryExecutor
from shared_kernel.dataclasses.warehouse_configs import PostgreSQLConfig
from shared_kernel.interfaces.data_warehouse_handler import WarehouseHandler


class PostgreSQLWarehouseHandler(WarehouseHandler):

    def __init__(self, payload: dict = None):
        super().__init__(payload)
        self.set_default_schema = self.payload.get("set_default_schema", True)

    def get_config(self) -> PostgreSQLConfig:

        source_config: PostgreSQLConfig = self.payload.get("source_config")
        if source_config and isinstance(source_config, PostgreSQLConfig):
            return source_config

        required = ("host", "user", "password", "database", "port")
        missing = [f for f in required if not self.payload.get(f)]
        if missing:
            raise ValueError(
                f"PostgreSQL payload is missing required fields: {missing}."
            )

        return PostgreSQLConfig(
            username=str(self.payload.get("user")).strip(),
            password=str(self.payload.get("password")).strip(),
            host=str(self.payload.get("host")).strip(),
            database=str(self.payload.get("database")).strip(),
            port=str(self.payload.get("port")).strip(),
            schema=str(self.payload.get("schema")).strip() if self.payload.get("schema") else None,
            schema_list=self.payload.get("schema_list"),
            pagination=self.pagination,
        )

    def _build_connection(self) -> PostgreSQLWarehouseConnection:
        return PostgreSQLWarehouseConnection(
            source_config=self.get_config(),
            set_default_schema=self.set_default_schema,
        )

    def get_executor(self) -> PostgreSQLQueryExecutor:
        connection = self._build_connection()
        return PostgreSQLQueryExecutor(warehouse_connection=connection)

    def get_query_object(self) -> Query:
        return Query

    def create_records_and_count_query(
        self,
        query: str,
        limit: str,
        page: str,
    ) -> tuple[str, str]:
        count_query = f"SELECT COUNT(*) FROM ({query})"

        if limit:
            query = f"{query} LIMIT {int(limit)}"
            if page:
                offset = (int(page) - 1) * int(limit)
                query = f"{query} OFFSET {offset}"

        return count_query, query
    