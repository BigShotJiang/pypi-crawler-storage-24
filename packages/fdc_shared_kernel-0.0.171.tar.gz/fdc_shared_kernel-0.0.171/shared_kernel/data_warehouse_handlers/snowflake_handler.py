from pypika import Query

from shared_kernel.data_warehouse_handlers.connections.snowflake_warehouse_connection import SnowflakeWarehouseConnection
from shared_kernel.data_warehouse_handlers.query_executors.snowflake_query_executor import SnowflakeQueryExecutor
from shared_kernel.dataclasses.warehouse_configs import SnowflakeConfig
from shared_kernel.interfaces.data_warehouse_handler import WarehouseHandler


class SnowflakeWarehouseHandler(WarehouseHandler):

    def __init__(self, payload: dict = None):
        super().__init__(payload)
        self.set_default_schema = self.payload.get("set_default_schema", True)

    def get_config(self) -> SnowflakeConfig:
        source_config: SnowflakeConfig = self.payload.get("source_config")
        if source_config and isinstance(source_config, SnowflakeConfig):
            return source_config

        required = ("user", "password", "account", "database")
        missing = [f for f in required if not self.payload.get(f)]
        if missing:
            raise ValueError(
                f"Snowflake payload is missing required fields: {missing}."
            )

        return SnowflakeConfig(
            user=str(self.payload.get("user")).strip(),
            password=str(self.payload.get("password")).strip(),
            account=str(self.payload.get("account")).strip(),
            database=str(self.payload.get("database")).strip(),
            schema=str(self.payload.get("schema")).strip() if self.payload.get("schema") else None,
            schema_list=self.payload.get("schema_list")
        )

    def _build_connection(self) -> SnowflakeWarehouseConnection:
        return SnowflakeWarehouseConnection(
            source_config=self.get_config(),
            set_default_schema=self.set_default_schema,
        )

    def get_executor(self) -> SnowflakeQueryExecutor:
        connection = self._build_connection()
        return SnowflakeQueryExecutor(warehouse_connection=connection)

    def get_query_object(self) -> Query:
        return Query

    def create_records_and_count_query(
        self,
        query: str,
        limit: str,
        page: str,
    ) -> tuple[str, str]:
        count_query = f"SELECT COUNT(*) FROM ({query}) AS _count"

        if limit:
            query = f"{query} LIMIT {int(limit)}"
            if page:
                offset = (int(page) - 1) * int(limit)
                query = f"{query} OFFSET {offset}"

        return count_query, query
    