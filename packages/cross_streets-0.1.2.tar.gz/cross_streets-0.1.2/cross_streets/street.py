import re
from .insane_type_hashmap import key_to_types

class Street:
    name: str # main street name ("Hennepin", etc.)
    type: str | None # unabbreviated street type # ("Avenue", etc.)
    direction: str | None # direction code ('N', 'SE', etc.)
    # Modifiers come immediately before/after the name (like a second name)
    # ^ extrapolated from https://www.austintexas.gov/sites/default/files/files/Planning/Applications_Forms/street-naming-standards.pdf
    modifier: str | None # street modifier
    
    def __str__(self):
        out = '\n\t'.join(['[Street Object]:',
                            f'name:     \t{self.name}',
                            f'type:     \t{self.type if self.type else ''}',
                            f'direction:\t{self.direction if self.direction else ''}',
                            f'modifier: \t{self.modifier if self.modifier else ''}',
                            'permutations:\t'])
        out += '\n\t\t\t'.join(self.permutations())
        
        return out
    
    def __init__(self, tag: dict[str,str]):
        self.name = tag['StreetName']
        self.direction = self.map_direction(tag.get('StreetNamePreDirectional') if tag.get('StreetNamePreDirectional') else tag.get('StreetNamePostDirectional'))
        self.type = self.long_type(tag.get('StreetNamePreType') if tag.get('StreetNamePreType') else tag.get('StreetNamePostType'))
        self.modifier = tag.get('StreetNamePreModifier') if tag.get('StreetNamePreModifier') else tag.get('StreetNamePostModifier')
        
        
    
    def map_direction(self, dir: str|None) -> str|None:
        if dir is None:
            return None
        out = ''
        dir = dir.lower()
        
        if len(dir) <= 2:
            return (dir.upper()*2)[:2]
        
        # They call me The Riddler:
        matches = re.match(r'^(no?r?t?h?)?(so?u?t?h?)?(ea?s?t?)?(we?s?t?)?$',dir)
        if matches is None:
            return ''
        # North/South
        if matches.group(1):
            out += 'N'
        elif matches.group(2):
            out += 'S'
        # East/West    
        if matches.group(3):
            out += 'E'
        elif matches.group(4):
            out += 'W'    
        return out
    
    def permute_directions(self) -> list[str]:
        '''Gets a list of [abbr. direction (`NE`), full direction (`Northeast`)]''' # type: ignore
        if self.direction is None:
            return []
        
        short = self.direction
        long = ''
        # North/South:
        if self.direction.startswith('N'):
            long += 'north'
        elif self.direction.startswith('S'):
            long += 'south'
        # East/West:
        if self.direction.endswith('E'):
            long += 'east'
        elif self.direction.endswith('W'):
            long += 'west'
        
        return [short, long.capitalize()]
    
    def long_type(self, type: str|None) -> str|None:
        if type is None:
            return None
        
        # TODO: is there a better way to do this?
        forms = key_to_types(type)
        if forms is None:
            return None
        return forms[0]
    
    def permutations(self) -> list[str]:
        '''### Gets all permutations of the street\n\n
           We use the following CFG under the hood:\n
           N &rarr; name<br>
           M &rarr; modifier [N]] | [N] modifier | [N] <br>
           T &rarr; [M] type | [M] <br>
           D &rarr; direction [T] | [T] direction | [T] <br>
           [Output D]
        '''
        
        # M -> modifier name] | name modifier | modifier
        if self.modifier:
            m_cfg = [f'{self.modifier} {self.name}', f'{self.name} {self.modifier}']
        else: 
            m_cfg = [self.name]
        # T -> [M] type | [M]
        types = key_to_types(self.type)
        t_cfg = []
        if types:
            for type in types:
                for m in m_cfg:
                    t_cfg.append(f"{m} {type}")
        else:
            t_cfg = m_cfg          
        # D -> direction [T] | [T] direction | [T] <br>
        d_cfg = []
        if self.direction:
            for t in t_cfg:
                d_cfg.append(f'{t} {self.direction}')
                d_cfg.append(f'{self.direction} {t}')
        else: 
            d_cfg = t_cfg
        # [Output D]
        return d_cfg
    

if __name__ == '__main__':
    import usaddress
    
    tag = usaddress.tag('Hennepin Ave Southeast')[0]
    street = Street(tag)
    print(street)