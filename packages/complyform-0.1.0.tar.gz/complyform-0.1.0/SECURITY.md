# Security Policy

## Supported Versions

| Version | Supported |
|---|---|
| Latest release | ✅ |
| Previous minor | ✅ (security fixes only) |
| Older | ❌ |

## Reporting a Vulnerability

**Email:** security@complyform.dev

**What to include:**
- Description of the vulnerability
- Steps to reproduce
- Potential impact
- Suggested fix (if any)

**Our commitment:**
- Acknowledge receipt within 48 hours
- Provide initial assessment within 7 days
- Aim to fix within 90 days (severity-dependent)
- Coordinate disclosure timeline with reporter
- Credit reporter in security advisory (unless they prefer anonymity)

**Timeline:**
- Day 0: Report received
- Day 2: Acknowledgment sent
- Day 7: Initial assessment shared with reporter
- Day 30-90: Fix developed, tested, deployed
- Day 90: Public disclosure via GitHub Security Advisory

## Scope

In scope:
- ComplyForm CLI (all versions)
- ComplyForm backend API
- Profile distribution and licensing system
- complyform.dev and subdomains

Out of scope:
- Vulnerabilities in Checkov, Terraform, OpenTofu, or other third-party tools
- Social engineering attacks
- Denial of service attacks against our hosted services
- Issues in the user's own GCP infrastructure

We conduct regular security assessments including automated scanning (OWASP ZAP monthly)
and periodic third-party penetration testing (annual, post-SOC 2 trigger).

## Bug Bounty

We do not currently operate a paid bug bounty program. We do publicly credit
security researchers who report valid vulnerabilities.
