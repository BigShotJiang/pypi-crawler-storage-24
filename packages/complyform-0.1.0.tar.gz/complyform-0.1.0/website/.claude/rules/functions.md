# Rules for functions/**/*.ts

## Cloudflare Pages Functions conventions:

1. Export an `onRequest` handler (or `onRequestPost`, `onRequestGet`, etc.):
   ```typescript
   export const onRequestPost: PagesFunction<Env> = async (context) => {
     // handler logic
   };
   ```

2. Define an `Env` interface for environment bindings:
   ```typescript
   interface Env {
     POSTMARK_SERVER_TOKEN: string;
   }
   ```

3. Always validate request body server-side — never trust client input

4. Honeypot pattern: include a hidden `website` field. If non-empty, return success silently (don't reveal detection):
   ```typescript
   if (body.website) {
     return Response.json({ success: true }); // bot detected, fake success
   }
   ```

5. Rate limiting: use in-memory counter per IP. Reset on cold start is acceptable for this scale.

6. Error opacity: NEVER expose internal errors, stack traces, or Postmark API responses to the client. Always return a generic success/failure message.

7. Secrets: access via `context.env.SECRET_NAME` — never hardcode tokens

8. Return JSON responses with appropriate status codes:
   - `200` with `{ success: true }` for success
   - `400` with `{ success: false, error: "..." }` for validation errors
   - `200` with `{ success: true }` even on honeypot detection (no information leakage)
   - `500` with `{ success: false, error: "Something went wrong" }` for server errors (generic message)
