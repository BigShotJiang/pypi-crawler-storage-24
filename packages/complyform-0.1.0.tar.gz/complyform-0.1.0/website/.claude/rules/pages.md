# Rules for src/pages/**/*.astro

## Every page MUST:

1. Import and use the `Base` layout from `@layouts/Base.astro`
2. Pass a unique `title` prop (format: "Page Name — ComplyForm")
3. Pass a unique `description` prop (under 160 characters)
4. Have exactly one `<h1>` element
5. NOT include `<html>`, `<head>`, or `<body>` tags — these are in Base.astro
6. NOT duplicate meta tags — Base.astro handles all `<head>` content
7. Wrap page content in `<main>` with container classes: `max-w-6xl mx-auto px-4 md:px-6 lg:px-8`

## Page structure template:

```astro
---
import Base from '@layouts/Base.astro';
---

<Base title="Page Title — ComplyForm" description="Unique description under 160 chars.">
  <main class="max-w-6xl mx-auto px-4 md:px-6 lg:px-8 py-16 md:py-24">
    <h1 class="text-4xl md:text-5xl font-semibold text-text-primary mb-6">Page Title</h1>
    <!-- page content -->
  </main>
</Base>
```
