import { defineConfig, envField } from "astro/config";
import tailwindcss from "@tailwindcss/vite";
import sitemap from "@astrojs/sitemap";

export default defineConfig({
  site: "https://complyform.dev",
  integrations: [sitemap()],
  env: {
    schema: {
      PUBLIC_PADDLE_CLIENT_TOKEN: envField.string({ context: "client", access: "public" }),
      PUBLIC_PADDLE_PRICE_PRO: envField.string({ context: "client", access: "public" }),
      PUBLIC_PADDLE_PRICE_TEAM: envField.string({ context: "client", access: "public" }),
      PUBLIC_PADDLE_PRICE_AGENCY: envField.string({ context: "client", access: "public" }),
      PUBLIC_PADDLE_PRICE_ENTERPRISE: envField.string({ context: "client", access: "public" }),
    },
  },
  vite: {
    plugins: [tailwindcss()],
  },
});
