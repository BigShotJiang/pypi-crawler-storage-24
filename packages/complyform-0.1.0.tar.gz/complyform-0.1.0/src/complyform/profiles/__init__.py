"""YAML profile data package — controls, mappings, and registry."""

from __future__ import annotations
