"""Attestation: in-toto Statement v1 builder and verification."""

from __future__ import annotations
