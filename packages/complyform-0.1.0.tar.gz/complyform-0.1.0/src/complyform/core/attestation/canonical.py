"""RFC 8785 canonical JSON serialization."""

from __future__ import annotations

import json
from typing import Any


def canonical_json(obj: dict[str, Any]) -> bytes:
    """RFC 8785 canonical JSON serialization.

    Sort keys recursively, no whitespace, UTF-8 encoding.
    """
    return json.dumps(
        obj,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
    ).encode("utf-8")
