"""Authentication, licensing, and tier enforcement for ComplyForm."""

from __future__ import annotations
