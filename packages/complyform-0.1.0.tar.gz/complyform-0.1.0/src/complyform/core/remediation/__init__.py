"""Remediation package — GitHub PR client and related utilities."""

from __future__ import annotations
