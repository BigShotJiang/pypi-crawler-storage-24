"""Profile validators: verify controls and mappings YAML integrity."""

from __future__ import annotations

from complyform.core.profiles.control_loader import load_controls
from complyform.core.profiles.mapping_loader import load_mappings
from complyform.core.profiles.registry import get_framework


def validate_framework_profile(framework_id: str, cloud: str) -> list[str]:
    """Validate a framework profile. Returns list of warnings (empty = valid).

    Checks:
    1. Framework exists in registry.
    2. Controls YAML loads and validates.
    3. Mappings YAML loads and validates.
    4. All mapping control_ids reference valid controls.
    """
    warnings: list[str] = []

    try:
        get_framework(framework_id)
    except Exception as exc:
        warnings.append(f"Registry: {exc}")
        return warnings

    try:
        controls_file = load_controls(framework_id)
    except Exception as exc:
        warnings.append(f"Controls: {exc}")
        return warnings

    control_ids = {c.id for c in controls_file.controls}

    try:
        mappings_file = load_mappings(framework_id, cloud)
    except Exception as exc:
        warnings.append(f"Mappings ({cloud}): {exc}")
        return warnings

    for m in mappings_file.mappings:
        if m.control_id not in control_ids:
            warnings.append(
                f"Mapping {m.check_id} references unknown control {m.control_id}"
            )

    return warnings
