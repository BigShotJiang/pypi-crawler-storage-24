"""Profile signing stub — placeholder for future integrity verification.

In a future release, profiles will be signed with Ed25519 keys.
This module provides the interface that downstream code can depend on.
"""

from __future__ import annotations


def verify_profile(path: str) -> bool:
    """Verify profile signature. Always returns True (stub)."""
    return True


def sign_profile(path: str, key: str) -> str:
    """Sign a profile file. Returns empty signature (stub)."""
    return ""
