"""Profile engine: framework registry, control/mapping loaders, cross-mappings.

Architecture spec (Part G) defines a single loader.py for all profile loading.
Implementation splits into registry.py, control_loader.py, and mapping_loader.py
for separation of concerns. All three are the "loader" referenced in the spec.
"""

from __future__ import annotations
