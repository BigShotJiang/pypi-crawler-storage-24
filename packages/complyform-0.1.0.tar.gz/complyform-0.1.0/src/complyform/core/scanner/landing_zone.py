"""Landing zone detection dispatcher and data model.

Contract:
- LandingZoneContext holds detected landing zone metadata.
- detect_landing_zone() dispatches to cloud-specific detector.
- Never raises — returns LandingZoneContext(detected=False) on any failure.
"""

from __future__ import annotations

import sys
from dataclasses import dataclass, field

__all__ = [
    "LandingZoneContext",
    "detect_landing_zone",
]


@dataclass
class LandingZoneContext:
    """Landing zone detection result."""

    cloud: str  # "gcp" | "aws" | "azure"
    detected: bool  # Whether a landing zone was detected
    type: str | None  # "assured_workloads" | "control_tower" | "alz" | "slz" | None
    inherited_policies: list[str] = field(default_factory=list)
    compliance_regime: str | None = None  # "fedramp" | "hipaa" | "eu_sovereign" | None
    hierarchy_path: list[str] = field(default_factory=list)
    drift_risk_policies: list[str] = field(default_factory=list)


def detect_landing_zone(
    cloud: str,
    project_id: str,
    credentials: object | None = None,
) -> LandingZoneContext:
    """Dispatch to cloud-specific landing zone detector.

    Best-effort: on any failure, returns LandingZoneContext(detected=False).
    Never raises. Logs warnings to stderr on failure.
    """
    try:
        if cloud == "gcp":
            from complyform.core.scanner.landing_zone_gcp import (
                detect_gcp_landing_zone,
            )

            return detect_gcp_landing_zone(project_id, credentials)
        if cloud == "aws":
            from complyform.core.scanner.landing_zone_aws import (
                detect_aws_landing_zone,
            )

            return detect_aws_landing_zone(project_id, credentials)
        if cloud == "azure":
            from complyform.core.scanner.landing_zone_azure import (
                detect_azure_landing_zone,
            )

            return detect_azure_landing_zone(project_id, credentials)
    except Exception as exc:
        print(
            f"Warning: landing zone detection failed for {cloud}: {exc}",
            file=sys.stderr,
        )

    return LandingZoneContext(cloud=cloud, detected=False, type=None)
