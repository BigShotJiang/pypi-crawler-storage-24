"""ComplyForm scanner package."""

from __future__ import annotations
