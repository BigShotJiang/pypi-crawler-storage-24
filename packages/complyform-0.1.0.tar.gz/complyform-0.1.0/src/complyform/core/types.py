"""Shared type aliases used across the ComplyForm package."""

from __future__ import annotations

type CloudProvider = str  # Literal["gcp", "aws", "azure"] — validated at boundaries
type FrameworkId = str  # e.g. "soc2", "hipaa", "cis_gcp"
type ExitCode = int
