"""Compliance scoring: severity-weighted formula per §A.2.3.1."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from complyform.core.assessor.control_matcher import Finding

SEVERITY_WEIGHTS: dict[str, int] = {
    "CRITICAL": 10,
    "HIGH": 5,
    "MEDIUM": 2,
    "LOW": 1,
}


def compute_compliance_score(findings: list[Finding]) -> float:
    """Severity-weighted compliance score (0-100).

    Only PASS and FAIL findings contribute. MANUAL_REVIEW and NOT_ASSESSED excluded.
    No scoreable findings → 100.0.
    """
    total_weight = 0
    failed_weight = 0

    for f in findings:
        if f.status not in ("PASS", "FAIL"):
            continue
        w = SEVERITY_WEIGHTS.get(f.severity, 1)
        total_weight += w
        if f.status == "FAIL":
            failed_weight += w

    if total_weight == 0:
        return 100.0

    score = ((total_weight - failed_weight) / total_weight) * 100
    return round(score, 1)
