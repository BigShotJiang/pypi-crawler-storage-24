"""Resource coverage classifier per §A.2.3.2."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from complyform.core.assessor.control_matcher import Finding
    from complyform.core.scanner.state_parser import ResourceRecord


class ResourceCoverageClassifier:
    """Classify resources as mapped, not_applicable, or not_assessed."""

    def __init__(
        self,
        applicable_types: frozenset[str],
        not_applicable_types: frozenset[str],
    ) -> None:
        self._applicable = applicable_types
        self._not_applicable = not_applicable_types

    def classify(self, resource: ResourceRecord) -> str:
        """Returns: 'mapped' | 'not_applicable' | 'not_assessed'."""
        if resource.resource_type in self._applicable:
            return "mapped"
        if resource.resource_type in self._not_applicable:
            return "not_applicable"
        return "not_assessed"

    def generate_not_assessed_findings(
        self,
        resources: list[ResourceRecord],
        framework: str,
    ) -> list[Finding]:
        """Generate NOT_ASSESSED Finding for each not-assessed resource."""
        from complyform.core.assessor.control_matcher import Finding

        findings: list[Finding] = []
        for r in resources:
            if self.classify(r) != "not_assessed":
                continue
            findings.append(
                Finding(
                    control_id="N/A",
                    framework=framework,
                    resource_address=r.address,
                    resource_type=r.resource_type,
                    status="NOT_ASSESSED",
                    severity="LOW",
                    finding=f"No mapping for resource type '{r.resource_type}'",
                    remediation="",
                    checkov_id=None,
                    cross_mappings=None,
                    native_ids=None,
                    confidence="inferred",
                    not_assessed_reason="no_mapping",
                )
            )
        return findings
