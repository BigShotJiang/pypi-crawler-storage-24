"""Assessment engine: control matching, check evaluation, scoring, coverage."""

from __future__ import annotations
