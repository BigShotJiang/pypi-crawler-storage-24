"""Greenfield infrastructure generation — init wizard + Terraform rendering."""

from __future__ import annotations
