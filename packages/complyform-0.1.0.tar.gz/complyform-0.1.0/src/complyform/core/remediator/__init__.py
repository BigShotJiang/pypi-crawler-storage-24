"""Remediation engine: patch generation, import blocks, dependency resolution."""
