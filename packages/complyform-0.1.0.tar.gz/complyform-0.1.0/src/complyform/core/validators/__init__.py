"""Validation runners: Checkov integration and result parsing."""
