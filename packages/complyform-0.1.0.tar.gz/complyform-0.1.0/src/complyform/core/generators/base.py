"""Shared generator infrastructure — ABC and result dataclass.

All policy generators inherit from PolicyGenerator and return GenerationResult.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from pathlib import Path


@dataclass
class GenerationResult:
    """Result of a policy generation operation."""

    format: str
    files_written: list[Path]
    artifact_count: int
    output_dir: Path
    metadata: dict[str, object] = field(default_factory=dict)


class PolicyGenerator(ABC):
    """Abstract base for all policy generators."""

    FORMAT_ID: str
    TIER_FEATURE: str

    @abstractmethod
    def generate(
        self,
        findings: list[dict[str, object]],
        mappings: dict[str, object],
        cloud: str,
        tier: str,
        output_dir: Path,
    ) -> GenerationResult:
        """Generate policy artifacts from findings."""
        ...

    @abstractmethod
    def supports_tier(self, tier: str) -> bool:
        """Check if this generator is available at the given tier."""
        ...

    @abstractmethod
    def format_name(self) -> str:
        """Human-readable format name for display."""
        ...
