"""Evidence exporter ABC and result dataclass.

All exporters inherit from EvidenceExporter and return ExportResult.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from pathlib import Path


@dataclass
class ExportResult:
    """Result of a single export operation."""

    format: str
    output_files: list[Path]
    record_count: int
    api_push_status: str | None = None
    api_push_details: dict[str, object] | None = None
    warnings: list[str] = field(default_factory=list)


class EvidenceExporter(ABC):
    """Abstract base for all export format implementations."""

    FORMAT_ID: str
    TIER_FEATURE: str
    SUPPORTS_API_PUSH: bool = False

    @abstractmethod
    def export_to_file(
        self,
        findings: list[dict[str, object]],
        metadata: dict[str, object],
        output_dir: Path,
        project_label: str | None = None,
    ) -> ExportResult:
        """Export findings to file(s)."""
        ...

    def push_to_api(
        self,
        findings: list[dict[str, object]],
        metadata: dict[str, object],
        api_config: dict[str, object],
    ) -> ExportResult:
        """Push findings to external API."""
        msg = f"{self.FORMAT_ID} does not support direct API push"
        raise NotImplementedError(msg)
