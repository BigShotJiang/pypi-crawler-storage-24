"""Evidence exporter registry.

Maps format IDs to exporter classes for file-only evidence export.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from complyform.core.errors import ExportFormatError

if TYPE_CHECKING:
    from complyform.core.generators.evidence_export.base import EvidenceExporter

EXPORTER_REGISTRY: dict[str, type[EvidenceExporter]] = {}

FORMAT_TO_FEATURE: dict[str, str] = {
    "scc-json": "evidence_export_native",
    "audit-manager": "evidence_export_native",
    "purview": "evidence_export_native",
    "grc-json": "evidence_export_native",
    "vanta": "evidence_export_grc",
    "drata": "evidence_export_grc",
    "secureframe": "evidence_export_grc",
}


def register_exporter(cls: type[EvidenceExporter]) -> type[EvidenceExporter]:
    """Register an exporter class by its FORMAT_ID."""
    EXPORTER_REGISTRY[cls.FORMAT_ID] = cls
    return cls


def get_exporter(format_id: str) -> EvidenceExporter:
    """Instantiate and return an exporter by format ID."""
    if format_id not in EXPORTER_REGISTRY:
        raise ExportFormatError(format_id, list(EXPORTER_REGISTRY.keys()))
    return EXPORTER_REGISTRY[format_id]()


def _register_exporters() -> None:
    """Populate registry with built-in exporters."""
    from complyform.core.generators.evidence_export.audit_manager import (
        AuditManagerExporter,
    )
    from complyform.core.generators.evidence_export.drata import DrataExporter
    from complyform.core.generators.evidence_export.grc_json import GrcJsonExporter
    from complyform.core.generators.evidence_export.purview import PurviewExporter
    from complyform.core.generators.evidence_export.scc_json import SccJsonExporter
    from complyform.core.generators.evidence_export.secureframe import (
        SecureframeExporter,
    )
    from complyform.core.generators.evidence_export.vanta import VantaExporter

    register_exporter(SccJsonExporter)
    register_exporter(AuditManagerExporter)
    register_exporter(PurviewExporter)
    register_exporter(GrcJsonExporter)
    register_exporter(VantaExporter)
    register_exporter(DrataExporter)
    register_exporter(SecureframeExporter)


_register_exporters()
