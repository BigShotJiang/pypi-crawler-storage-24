"""Policy generator registry.

Maps format IDs to generator classes for policy-as-code artifact generation.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from complyform.core.generators.base import PolicyGenerator

GENERATORS: dict[str, type[PolicyGenerator]] = {}


def _register_generators() -> None:
    """Populate the registry with available generators."""
    from complyform.core.generators.checkov_custom import CheckovCustomGenerator
    from complyform.core.generators.github_action import GitHubActionGenerator
    from complyform.core.generators.opa_rego import OpaRegoGenerator

    GENERATORS["opa"] = OpaRegoGenerator
    GENERATORS["checkov"] = CheckovCustomGenerator
    GENERATORS["github-action"] = GitHubActionGenerator


_register_generators()
