"""Explainer package — deterministic and AI-enhanced explanations."""

from __future__ import annotations
