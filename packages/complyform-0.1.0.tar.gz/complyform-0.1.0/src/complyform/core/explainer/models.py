"""Pydantic models for explain output."""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict


class Explanation(BaseModel):
    """Single explanation of a compliance finding."""

    model_config = ConfigDict(strict=True)

    control_id: str
    framework: str
    title: str
    severity: str
    status: str
    summary: str
    why_it_matters: str
    severity_rationale: str
    remediation_hint: str
    resource_address: str
    ai_generated: bool = False
    model: str | None = None
    cached: bool = False
