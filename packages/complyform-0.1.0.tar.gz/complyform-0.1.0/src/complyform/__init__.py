"""ComplyForm — Compliance-as-code CLI for GCP, AWS, and Azure infrastructure."""

from __future__ import annotations

__version__: str = "0.1.0"
