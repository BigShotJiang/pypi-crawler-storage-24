"""Progress display helpers with branded spinner.

Provides create_status() and create_progress() that respect
--quiet and --no-progress flags.
"""

from __future__ import annotations

import contextlib
import sys
from typing import TYPE_CHECKING, Any

from rich.progress import (
    BarColumn,
    Progress,
    SpinnerColumn,
    TaskProgressColumn,
    TextColumn,
)

if TYPE_CHECKING:
    from rich.console import Console
    from rich.status import Status

# Guarantee spinner registration before any command runs.
import complyform.cli.spinner as _spinner  # noqa: F401


def _suppressed(*, quiet: bool, no_progress: bool) -> bool:
    """Return True if progress indicators should be suppressed."""
    return quiet or no_progress or not sys.stderr.isatty()


def create_status(
    console: Console,
    message: str,
    *,
    quiet: bool,
    no_progress: bool,
) -> Status | contextlib.nullcontext[Any]:
    """Rich Status spinner with branded animation.

    Returns nullcontext if suppressed.
    """
    if _suppressed(quiet=quiet, no_progress=no_progress):
        return contextlib.nullcontext()
    return console.status(
        message,
        spinner="complyform",
        spinner_style="bold bright_cyan",
    )


def create_progress(
    console: Console,
    *,
    quiet: bool,
    no_progress: bool,
) -> Progress | contextlib.nullcontext[Any]:
    """Rich Progress bar with branded SpinnerColumn.

    Returns nullcontext if suppressed.
    """
    if _suppressed(quiet=quiet, no_progress=no_progress):
        return contextlib.nullcontext()
    return Progress(
        SpinnerColumn("complyform", style="bold bright_cyan"),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        TaskProgressColumn(),
        console=console,
    )
