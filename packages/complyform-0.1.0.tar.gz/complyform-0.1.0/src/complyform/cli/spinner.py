"""Branded CF spinner registration for Rich.

Registers a custom "complyform" spinner into Rich's SPINNERS registry at import time.
"""

from __future__ import annotations

from rich.spinner import SPINNERS  # type: ignore[attr-defined]

_SPIN: list[str] = ["◜◞", "◠◡", "◝◟", "◑◐", "◞◜", "◡◠", "◟◝", "◐◑"]

CF_SPINNER_FRAMES: list[str] = (
    ["CF"] * 8 + ["C)", "()", "◜◞"] + _SPIN * 2 + ["()", "(F", "CF"]
)

SPINNERS["complyform"] = {"interval": 80, "frames": CF_SPINNER_FRAMES}
