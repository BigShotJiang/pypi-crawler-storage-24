"""Branded ASCII banner for CLI output."""

from __future__ import annotations

import sys
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from rich.console import Console

# The banner. Do NOT reformat, rewrap, or modify these strings.
# Each line is exactly as specified — alignment is load-bearing.
_BANNER_LINES: list[str] = [
    r"  _____                __     ____             ",
    r" / ___/__  __ _  ___  / /_ __/ __/__  ______ _ ",
    "/ /__/ _ \\/  ' \\/ _ \\/ / // / _// _ \\/ __/  ' \\",
    r"\___/\___/_/_/_/ .__/_/\_, /_/  \___/_/ /_/_/_/",
    r"              /_/     /___/                    ",
]

BANNER_STYLE = "bold bright_cyan"


def print_banner(console: Console, version: str) -> None:
    """Print the ComplyForm ASCII banner with version to stderr.

    Callers are responsible for suppression checks (quiet, non-TTY, piped).
    This function only prints — it does not check conditions.
    """
    for line in _BANNER_LINES:
        console.print(line, style=BANNER_STYLE, highlight=False)
    console.print(f"{'':>41}v{version}", style=BANNER_STYLE, highlight=False)
    console.print()  # blank line after banner


def should_show_banner(*, quiet: bool = False) -> bool:
    """Return True if the banner should be displayed.

    Suppressed when:
    - --quiet is active
    - stdout is not a TTY (piped or redirected)
    - NO_COLOR=1 is set (banner is decorative — skip in accessibility mode)
    """
    if quiet:
        return False
    return sys.stderr.isatty()
