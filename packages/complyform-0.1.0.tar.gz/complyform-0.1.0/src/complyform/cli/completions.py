"""Shell completion helpers for framework IDs and other dynamic values."""

from __future__ import annotations


def complete_framework_id(incomplete: str) -> list[str]:
    """Return framework IDs matching the incomplete string."""
    try:
        from complyform.core.profiles.registry import list_frameworks

        fws = list_frameworks()
        return [f.id for f in fws if f.id.startswith(incomplete)]
    except Exception:
        return []


def complete_cloud(incomplete: str) -> list[str]:
    """Return cloud names matching the incomplete string."""
    clouds = ["gcp", "aws", "azure"]
    return [c for c in clouds if c.startswith(incomplete)]


def complete_tier(incomplete: str) -> list[str]:
    """Return tier names matching the incomplete string."""
    tiers = ["community", "pro", "team", "agency", "enterprise"]
    return [t for t in tiers if t.startswith(incomplete)]


def complete_category(incomplete: str) -> list[str]:
    """Return category names matching the incomplete string."""
    categories = ["global", "regional", "industry", "cis"]
    return [c for c in categories if c.startswith(incomplete)]
