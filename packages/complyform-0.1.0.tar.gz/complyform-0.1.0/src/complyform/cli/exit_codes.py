"""Exit code constants per section A.1.5. CI/CD pipelines depend on this contract."""

from __future__ import annotations

EXIT_SUCCESS: int = 0  # No issues found
EXIT_COMPLIANCE_FAILURE: int = 1  # Compliance gaps exist (tool worked correctly)
EXIT_RUNTIME_ERROR: int = 2  # Bad input, auth failure, any ComplyFormError
EXIT_PARTIAL_FAILURE: int = 3  # Batch: some succeeded, some failed
EXIT_INTERRUPTED: int = 130  # KeyboardInterrupt (128 + SIGINT=2)
