"""Report formatters: JSON envelope, SARIF v2.1.0, Rich terminal output."""

from __future__ import annotations
