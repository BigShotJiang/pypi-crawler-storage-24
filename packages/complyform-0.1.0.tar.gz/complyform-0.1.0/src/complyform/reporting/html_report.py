"""HTML report renderer: self-contained single-file compliance report.

Uses Jinja2 with PackageLoader to load the compliance_report.html template.
All CSS and JS are inlined — no external dependencies, works offline.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from jinja2 import Environment, PackageLoader, StrictUndefined

from complyform.reporting.report_data import FRAMEWORK_COLORS

if TYPE_CHECKING:
    from complyform.reporting.report_data import ReportData


def render_html_report(report_data: ReportData) -> str:
    """Render self-contained HTML report from ReportData.

    Returns: Complete HTML string (single file, all CSS/JS inlined).
    """
    env = Environment(
        loader=PackageLoader("complyform", "templates/reports"),
        autoescape=True,
        trim_blocks=True,
        lstrip_blocks=True,
        undefined=StrictUndefined,
    )

    # Build framework color mapping
    fw_colors: dict[str, str] = {}
    for i, fw_id in enumerate(report_data.metadata.frameworks):
        fw_colors[fw_id] = FRAMEWORK_COLORS[i % len(FRAMEWORK_COLORS)]

    template = env.get_template("compliance_report.html")
    return template.render(
        report_data=report_data,
        framework_colors=fw_colors,
    )
