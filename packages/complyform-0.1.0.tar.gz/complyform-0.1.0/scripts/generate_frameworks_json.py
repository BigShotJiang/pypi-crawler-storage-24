#!/usr/bin/env python3
"""Convert profiles/framework_registry.yaml → JSON for website and docs."""

import json
import os
import sys

import yaml

YAML_PATH = os.path.join(os.path.dirname(__file__), "..", "profiles", "framework_registry.yaml")
OUTPUT_PATHS = [
    os.path.join(os.path.dirname(__file__), "..", "website", "public", "data", "frameworks.json"),
    os.path.join(os.path.dirname(__file__), "..", "docs", "public", "data", "frameworks.json"),
]


def main():
    yaml_path = os.path.normpath(YAML_PATH)
    if not os.path.isfile(yaml_path):
        print(f"Error: {yaml_path} not found", file=sys.stderr)
        sys.exit(1)

    try:
        with open(yaml_path, "r") as f:
            data = yaml.safe_load(f)
    except yaml.YAMLError as e:
        print(f"Error parsing YAML: {e}", file=sys.stderr)
        sys.exit(1)

    framework_count = len(data.get("frameworks", []))

    for output_path in OUTPUT_PATHS:
        output_path = os.path.normpath(output_path)
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        with open(output_path, "w") as f:
            json.dump(data, f, indent=2)

    print(f"Generated frameworks.json with {framework_count} frameworks → website/ and docs/")


if __name__ == "__main__":
    main()
