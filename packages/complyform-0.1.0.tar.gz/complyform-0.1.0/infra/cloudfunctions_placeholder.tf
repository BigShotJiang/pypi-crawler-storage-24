# --- Placeholder Cloud Function Source ZIP ---

data "archive_file" "cf_placeholder" {
  type        = "zip"
  output_path = "${path.module}/placeholder/cf_placeholder.zip"

  source {
    content  = <<-PYTHON
    import functions_framework

    @functions_framework.http
    def entry_point(request):
        return ({"status": "placeholder", "service": "complyform"}, 200)
    PYTHON
    filename = "main.py"
  }

  source {
    content  = "functions-framework==3.*\n"
    filename = "requirements.txt"
  }
}

resource "google_storage_bucket_object" "cf_placeholder" {
  name   = "placeholder/cf_placeholder-${data.archive_file.cf_placeholder.output_md5}.zip"
  bucket = google_storage_bucket.cf_source.name
  source = data.archive_file.cf_placeholder.output_path
}
