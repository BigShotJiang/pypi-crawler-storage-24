# --- Cloud Armor WAF Security Policy ---

resource "google_compute_security_policy" "waf" {
  name        = "complyform-waf"
  project     = var.project_id
  description = "WAF policy with rate-limiting, OWASP CRS, and adaptive protection"

  # --- Adaptive Protection ---

  adaptive_protection_config {
    layer_7_ddos_defense_config {
      enable = true
    }
  }

  # --- OWASP Preconfigured WAF Rules (preview mode) ---

  rule {
    action   = "deny(403)"
    priority = 100
    preview  = true

    match {
      expr {
        expression = "evaluatePreconfiguredExpr('sqli-v33-stable')"
      }
    }

    description = "OWASP SQLi detection (preview)"
  }

  rule {
    action   = "deny(403)"
    priority = 200
    preview  = true

    match {
      expr {
        expression = "evaluatePreconfiguredExpr('xss-v33-stable')"
      }
    }

    description = "OWASP XSS detection (preview)"
  }

  rule {
    action   = "deny(403)"
    priority = 300
    preview  = true

    match {
      expr {
        expression = "evaluatePreconfiguredExpr('lfi-v33-stable')"
      }
    }

    description = "OWASP LFI detection (preview)"
  }

  rule {
    action   = "deny(403)"
    priority = 400
    preview  = true

    match {
      expr {
        expression = "evaluatePreconfiguredExpr('rfi-v33-stable')"
      }
    }

    description = "OWASP RFI detection (preview)"
  }

  rule {
    action   = "deny(403)"
    priority = 500
    preview  = true

    match {
      expr {
        expression = "evaluatePreconfiguredExpr('rce-v33-stable')"
      }
    }

    description = "OWASP RCE detection (preview)"
  }

  rule {
    action   = "deny(403)"
    priority = 600
    preview  = true

    match {
      expr {
        expression = "evaluatePreconfiguredExpr('protocolattack-v33-stable')"
      }
    }

    description = "OWASP protocol attack detection (preview)"
  }

  # --- Rate-Limiting Rules ---

  rule {
    action   = "rate_based_ban"
    priority = 1000

    match {
      expr {
        expression = "request.path.matches('/auth/login') || request.path.matches('/auth/callback')"
      }
    }

    rate_limit_options {
      conform_action   = "allow"
      exceed_action    = "deny(429)"
      ban_duration_sec = 300

      rate_limit_threshold {
        count        = 10
        interval_sec = 60
      }

      enforce_on_key = "IP"
    }

    description = "OAuth brute-force prevention"
  }

  rule {
    action   = "throttle"
    priority = 1100

    match {
      expr {
        expression = "request.path.matches('/v1/license/validate')"
      }
    }

    rate_limit_options {
      conform_action = "allow"
      exceed_action  = "deny(429)"

      rate_limit_threshold {
        count        = 10
        interval_sec = 60
      }

      enforce_on_key = "IP"
    }

    description = "License validation abuse"
  }

  rule {
    action   = "throttle"
    priority = 1150

    match {
      expr {
        expression = "request.path.matches('/v1/drift/event')"
      }
    }

    rate_limit_options {
      conform_action = "allow"
      exceed_action  = "deny(429)"

      rate_limit_threshold {
        count        = 120
        interval_sec = 60
      }

      enforce_on_key = "IP"
    }

    description = "Event-driven drift ingestion (bursts legit)"
  }

  rule {
    action   = "rate_based_ban"
    priority = 1175

    match {
      expr {
        expression = "request.path.matches('/v1/license/resend')"
      }
    }

    rate_limit_options {
      conform_action   = "allow"
      exceed_action    = "deny(429)"
      ban_duration_sec = 900

      rate_limit_threshold {
        count        = 3
        interval_sec = 60
      }

      enforce_on_key = "IP"
    }

    description = "License resend abuse"
  }

  rule {
    action   = "throttle"
    priority = 1200

    match {
      expr {
        expression = "request.path.matches('/dashboard/consent/.*') || request.path.matches('/dashboard/settings/regenerate-api-key')"
      }
    }

    rate_limit_options {
      conform_action = "allow"
      exceed_action  = "deny(429)"

      rate_limit_threshold {
        count        = 5
        interval_sec = 60
      }

      enforce_on_key = "IP"
    }

    description = "State-mutating endpoint protection"
  }

  rule {
    action   = "throttle"
    priority = 1250

    match {
      expr {
        expression = "request.path.matches('/v1/export/.*')"
      }
    }

    rate_limit_options {
      conform_action = "allow"
      exceed_action  = "deny(429)"

      rate_limit_threshold {
        count        = 10
        interval_sec = 60
      }

      enforce_on_key = "IP"
    }

    description = "Export operations (expensive)"
  }

  rule {
    action   = "throttle"
    priority = 1300

    match {
      expr {
        expression = "request.path.matches('/auth/logout')"
      }
    }

    rate_limit_options {
      conform_action = "allow"
      exceed_action  = "deny(429)"

      rate_limit_threshold {
        count        = 10
        interval_sec = 60
      }

      enforce_on_key = "IP"
    }

    description = "Session invalidation abuse"
  }

  rule {
    action   = "throttle"
    priority = 1500

    match {
      expr {
        expression = "request.path.matches('/dashboard/shared/.*')"
      }
    }

    rate_limit_options {
      conform_action = "allow"
      exceed_action  = "deny(429)"

      rate_limit_threshold {
        count        = 30
        interval_sec = 60
      }

      enforce_on_key = "IP"
    }

    description = "Public share link abuse (SPEC-015)"
  }

  rule {
    action   = "throttle"
    priority = 2000

    match {
      expr {
        expression = "request.path.matches('/dashboard/.*')"
      }
    }

    rate_limit_options {
      conform_action = "allow"
      exceed_action  = "deny(429)"

      rate_limit_threshold {
        count        = 60
        interval_sec = 60
      }

      enforce_on_key = "IP"
    }

    description = "General dashboard abuse"
  }

  rule {
    action   = "throttle"
    priority = 2100

    match {
      expr {
        expression = "request.path.matches('/v1/.*')"
      }
    }

    rate_limit_options {
      conform_action = "allow"
      exceed_action  = "deny(429)"

      rate_limit_threshold {
        count        = 60
        interval_sec = 60
      }

      enforce_on_key = "IP"
    }

    description = "General API abuse"
  }

  # --- Log4j2 Protection (CVE-2021-44228) ---

  rule {
    action   = "deny(403)"
    priority = 900

    match {
      expr {
        expression = "evaluatePreconfiguredExpr('cve-canary')"
      }
    }

    description = "Log4j2 CVE-2021-44228 protection"
  }

  # --- Default Rule ---

  rule {
    action   = "allow"
    priority = 2147483647

    match {
      versioned_expr = "SRC_IPS_V1"

      config {
        src_ip_ranges = ["*"]
      }
    }

    description = "Default allow"
  }
}
