# --- Notification Channels ---

resource "google_monitoring_notification_channel" "pagerduty" {
  display_name = "PagerDuty"
  type         = "pagerduty"
  project      = var.project_id

  labels = {
    service_key = var.pagerduty_integration_key
  }
}

resource "google_monitoring_notification_channel" "email" {
  display_name = "ComplyForm Alerts Email"
  type         = "email"
  project      = var.project_id

  labels = {
    email_address = "alerts@complyform.dev"
  }
}

# --- Uptime Checks ---

resource "google_monitoring_uptime_check_config" "api_health" {
  display_name = "api-health"
  project      = var.project_id
  timeout      = "10s"
  period       = "60s"

  http_check {
    path         = "/health"
    port         = 443
    use_ssl      = true
    validate_ssl = true
  }

  monitored_resource {
    type = "uptime_url"
    labels = {
      project_id = var.project_id
      host       = "api.complyform.dev"
    }
  }
}

resource "google_monitoring_uptime_check_config" "dashboard_health" {
  display_name = "dashboard-health"
  project      = var.project_id
  timeout      = "10s"
  period       = "60s"

  http_check {
    path         = "/"
    port         = 443
    use_ssl      = true
    validate_ssl = true
  }

  monitored_resource {
    type = "uptime_url"
    labels = {
      project_id = var.project_id
      host       = "dashboard.complyform.dev"
    }
  }
}

# --- Helper Locals ---

locals {
  pagerduty_and_email = [
    google_monitoring_notification_channel.pagerduty.name,
    google_monitoring_notification_channel.email.name,
  ]
  email_only = [
    google_monitoring_notification_channel.email.name,
  ]

  # --- Pattern A: Cloud Run 5xx count ---
  cloud_run_5xx_alerts = {
    "api-5xx" = {
      service   = "complyform-api"
      threshold = 5
      channels  = "pagerduty_and_email"
    }
    "gotenberg-5xx" = {
      service   = "complyform-gotenberg"
      threshold = 3
      channels  = "email_only"
    }
  }

  # --- Pattern C: Cloud Run Function error rate ---
  function_error_alerts = {
    "billing-webhook-errors" = {
      function  = "complyform-billing-webhook"
      threshold = 10
      duration  = "900s"
      channels  = "pagerduty_and_email"
    }
    "drift-event-handler-errors" = {
      function  = "complyform-drift-event-handler"
      threshold = 10
      duration  = "900s"
      channels  = "pagerduty_and_email"
    }
    "telemetry-errors" = {
      function  = "complyform-telemetry-ingest"
      threshold = 50
      duration  = "3600s"
      channels  = "email_only"
    }
    "data-cleanup-errors" = {
      function  = "complyform-data-cleanup"
      threshold = 0
      duration  = "86400s"
      channels  = "email_only"
    }
    "founder-metrics-errors" = {
      function  = "complyform-founder-metrics"
      threshold = 50
      duration  = "3600s"
      channels  = "email_only"
    }
    "github-issues-sync-errors" = {
      function  = "complyform-github-issues-sync"
      threshold = 50
      duration  = "3600s"
      channels  = "email_only"
    }
    "overage-enforcement-errors" = {
      function  = "complyform-overage-enforcement"
      threshold = 50
      duration  = "3600s"
      channels  = "email_only"
    }
    "usage-reconciler-errors" = {
      function  = "complyform-usage-reconciler"
      threshold = 50
      duration  = "3600s"
      channels  = "email_only"
    }
    "onboarding-drip-errors" = {
      function  = "complyform-onboarding-drip"
      threshold = 50
      duration  = "3600s"
      channels  = "email_only"
    }
    "postmark-webhook-errors" = {
      function  = "complyform-postmark-webhook"
      threshold = 10
      duration  = "900s"
      channels  = "email_only"
    }
  }

  # --- Pattern D: Function staleness (no successful invocation) ---
  staleness_alerts = {
    "founder-metrics-stale" = {
      function = "complyform-founder-metrics"
      duration = "84600s" # 23h30m (GCP max)
    }
    "github-issues-sync-stale" = {
      function = "complyform-github-issues-sync"
      duration = "10800s" # 3hr
    }
    "overage-enforcement-stale" = {
      function = "complyform-overage-enforcement"
      duration = "84600s" # 23h30m (GCP max)
    }
    "usage-reconciler-stale" = {
      function = "complyform-usage-reconciler"
      duration = "84600s" # 23h30m (GCP max)
    }
    "onboarding-drip-stale" = {
      function = "complyform-onboarding-drip"
      duration = "84600s" # 23h30m (GCP max)
    }
    "rotation-reminder-stale" = {
      function = "complyform-rotation-reminder"
      duration = "84600s" # 23h30m (GCP max)
    }
    "newsletter-draft-stale" = {
      function = "complyform-newsletter-draft"
      duration = "84600s" # 23h30m (GCP max)
    }
    "dormancy-detection-stale" = {
      function = "complyform-dormancy-detection"
      duration = "84600s" # 23h30m (GCP max)
    }
  }

  # --- Pattern F: Log-based metric alerts ---
  log_metric_alerts = {
    "auth-callback-floods" = {
      metric    = "auth_callback_failed"
      threshold = 20
      duration  = "900s"
      channels  = "pagerduty_and_email"
    }
    "session-anomaly" = {
      metric    = "session_ip_mismatch"
      threshold = 5
      duration  = "300s"
      channels  = "email_only"
    }
    "email-delivery-failures" = {
      metric    = "email_delivery_failed"
      threshold = 3
      duration  = "3600s"
      channels  = "email_only"
    }

  }
}

# --- Pattern A: Cloud Run 5xx count ---

resource "google_monitoring_alert_policy" "cloud_run_5xx" {
  for_each = local.cloud_run_5xx_alerts

  display_name = each.key
  project      = var.project_id
  combiner     = "OR"

  notification_channels = each.value.channels == "pagerduty_and_email" ? local.pagerduty_and_email : local.email_only

  conditions {
    display_name = "${each.value.service} 5xx count"

    condition_threshold {
      filter          = "resource.type = \"cloud_run_revision\" AND resource.labels.service_name = \"${each.value.service}\" AND metric.type = \"run.googleapis.com/request_count\" AND metric.labels.response_code_class = \"5xx\""
      comparison      = "COMPARISON_GT"
      threshold_value = each.value.threshold
      duration        = "300s"

      aggregations {
        alignment_period   = "300s"
        per_series_aligner = "ALIGN_SUM"
      }
    }
  }

  alert_strategy {
    auto_close = "1800s"
  }
}

# Gotenberg error rate (separate — uses ratio, not count)
resource "google_monitoring_alert_policy" "gotenberg_error_rate" {
  display_name = "gotenberg-error-rate"
  project      = var.project_id
  combiner     = "OR"

  notification_channels = local.pagerduty_and_email

  conditions {
    display_name = "complyform-gotenberg 5xx rate > 10%"

    condition_threshold {
      filter          = "resource.type = \"cloud_run_revision\" AND resource.labels.service_name = \"complyform-gotenberg\" AND metric.type = \"run.googleapis.com/request_count\" AND metric.labels.response_code_class = \"5xx\""
      comparison      = "COMPARISON_GT"
      threshold_value = 0.1
      duration        = "300s"

      denominator_filter = "resource.type = \"cloud_run_revision\" AND resource.labels.service_name = \"complyform-gotenberg\" AND metric.type = \"run.googleapis.com/request_count\""

      aggregations {
        alignment_period   = "300s"
        per_series_aligner = "ALIGN_SUM"
      }

      denominator_aggregations {
        alignment_period   = "300s"
        per_series_aligner = "ALIGN_SUM"
      }
    }
  }

  alert_strategy {
    auto_close = "1800s"
  }
}

# --- Pattern B: Cloud Run latency ---

resource "google_monitoring_alert_policy" "api_latency" {
  display_name = "api-latency"
  project      = var.project_id
  combiner     = "OR"

  notification_channels = local.email_only

  conditions {
    display_name = "complyform-api p95 latency > 10s"

    condition_threshold {
      filter          = "resource.type = \"cloud_run_revision\" AND resource.labels.service_name = \"complyform-api\" AND metric.type = \"run.googleapis.com/request_latencies\""
      comparison      = "COMPARISON_GT"
      threshold_value = 10000 # milliseconds
      duration        = "300s"

      aggregations {
        alignment_period     = "300s"
        per_series_aligner   = "ALIGN_PERCENTILE_95"
        cross_series_reducer = "REDUCE_MAX"
      }
    }
  }

  alert_strategy {
    auto_close = "1800s"
  }
}

# --- Pattern C: Cloud Run Function error rate ---

resource "google_monitoring_alert_policy" "function_errors" {
  for_each = local.function_error_alerts

  display_name = each.key
  project      = var.project_id
  combiner     = "OR"

  notification_channels = each.value.channels == "pagerduty_and_email" ? local.pagerduty_and_email : local.email_only

  conditions {
    display_name = "${each.value.function} error rate > ${each.value.threshold}%"

    condition_threshold {
      filter          = "resource.type = \"cloud_run_revision\" AND resource.labels.service_name = \"${each.value.function}\" AND metric.type = \"run.googleapis.com/request_count\" AND metric.labels.response_code_class = \"5xx\""
      comparison      = "COMPARISON_GT"
      threshold_value = each.value.threshold / 100
      duration        = each.value.duration

      denominator_filter = "resource.type = \"cloud_run_revision\" AND resource.labels.service_name = \"${each.value.function}\" AND metric.type = \"run.googleapis.com/request_count\""

      aggregations {
        alignment_period   = each.value.duration
        per_series_aligner = "ALIGN_SUM"
      }

      denominator_aggregations {
        alignment_period   = each.value.duration
        per_series_aligner = "ALIGN_SUM"
      }
    }
  }

  alert_strategy {
    auto_close = "1800s"
  }
}

# --- Pattern D: Function staleness ---

resource "google_monitoring_alert_policy" "function_stale" {
  for_each = local.staleness_alerts

  display_name = each.key
  project      = var.project_id
  combiner     = "OR"

  notification_channels = local.email_only

  conditions {
    display_name = "${each.value.function} no successful invocations"

    condition_absent {
      filter   = "resource.type = \"cloud_run_revision\" AND resource.labels.service_name = \"${each.value.function}\" AND metric.type = \"run.googleapis.com/request_count\" AND metric.labels.response_code_class = \"2xx\""
      duration = each.value.duration

      aggregations {
        alignment_period   = "3600s"
        per_series_aligner = "ALIGN_SUM"
      }
    }
  }

  alert_strategy {
    auto_close = "1800s"
  }
}

# --- Pattern E: Cloud Run Job failure ---

resource "google_monitoring_alert_policy" "drift_monitor_failure" {
  display_name = "drift-monitor-failure"
  project      = var.project_id
  combiner     = "OR"

  notification_channels = local.pagerduty_and_email

  conditions {
    display_name = "complyform-drift-monitor job failure"

    condition_threshold {
      filter          = "resource.type = \"cloud_run_job\" AND resource.labels.job_name = \"complyform-drift-monitor\" AND metric.type = \"run.googleapis.com/job/completed_task_attempt_count\" AND metric.labels.result = \"failed\""
      comparison      = "COMPARISON_GT"
      threshold_value = 0
      duration        = "0s"

      aggregations {
        alignment_period   = "300s"
        per_series_aligner = "ALIGN_SUM"
      }
    }
  }

  alert_strategy {
    auto_close = "1800s"
  }
}

# --- Pattern F: Log-based metric alerts ---

resource "google_monitoring_alert_policy" "log_metric_alerts" {
  for_each = local.log_metric_alerts

  display_name = each.key
  project      = var.project_id
  combiner     = "OR"

  notification_channels = each.value.channels == "pagerduty_and_email" ? local.pagerduty_and_email : local.email_only

  conditions {
    display_name = "${each.value.metric} > ${each.value.threshold}"

    condition_threshold {
      filter          = "resource.type = \"cloud_run_revision\" AND metric.type = \"logging.googleapis.com/user/${each.value.metric}\""
      comparison      = "COMPARISON_GT"
      threshold_value = each.value.threshold
      duration        = each.value.duration

      aggregations {
        alignment_period   = each.value.duration
        per_series_aligner = "ALIGN_SUM"
      }
    }
  }

  alert_strategy {
    auto_close = "1800s"
  }

  depends_on = [google_logging_metric.metrics]
}

# firestore_errors alert: deferred to I-4b hardening patch (GCP metric not yet available)

# profile_bundle_errors alert: deferred to I-4b hardening patch (response_code filter requires traffic)

# --- Pattern H: Pub/Sub drift event backlog ---

resource "google_monitoring_alert_policy" "drift_event_backlog" {
  display_name = "drift-event-backlog"
  project      = var.project_id
  combiner     = "OR"

  notification_channels = local.email_only

  conditions {
    display_name = "Drift event undelivered messages > 1000"

    condition_threshold {
      filter          = "resource.type = \"pubsub_subscription\" AND resource.labels.subscription_id = monitoring.regex.full_match(\".*drift-event.*\") AND metric.type = \"pubsub.googleapis.com/subscription/num_undelivered_messages\""
      comparison      = "COMPARISON_GT"
      threshold_value = 1000
      duration        = "300s"

      aggregations {
        alignment_period   = "300s"
        per_series_aligner = "ALIGN_MAX"
      }
    }
  }

  conditions {
    display_name = "Drift event oldest unacked > 30min"

    condition_threshold {
      filter          = "resource.type = \"pubsub_subscription\" AND resource.labels.subscription_id = monitoring.regex.full_match(\".*drift-event.*\") AND metric.type = \"pubsub.googleapis.com/subscription/oldest_unacked_message_age\""
      comparison      = "COMPARISON_GT"
      threshold_value = 1800
      duration        = "300s"

      aggregations {
        alignment_period   = "300s"
        per_series_aligner = "ALIGN_MAX"
      }
    }
  }

  alert_strategy {
    auto_close = "1800s"
  }
}

# waf_block_spike alert: deferred to post-I-5 (requires live traffic for metric validation)
