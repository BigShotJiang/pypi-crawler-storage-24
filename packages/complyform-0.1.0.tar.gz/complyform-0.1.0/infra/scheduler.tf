# --- Cloud Scheduler Jobs & Pub/Sub Topics ---

locals {
  scheduler_jobs = {
    "complyform-drift-monitor" = {
      schedule    = "0 */6 * * *"
      topic       = "drift-monitor-trigger"
      description = "Trigger scheduled drift scans"
    }
    "complyform-data-cleanup" = {
      schedule    = "0 4 * * *"
      topic       = "data-cleanup-trigger"
      description = "Purge cancelled data, trim history"
    }
    "complyform-backup-verify" = {
      schedule    = "0 5 * * 1"
      topic       = "backup-verify-trigger"
      description = "Verify Firestore exports in DR"
    }
    "complyform-license-audit" = {
      schedule    = "0 6 1 */3 *"
      topic       = "license-audit-trigger"
      description = "Compare licenses vs Paddle subs"
    }
    "complyform-cost-review" = {
      schedule    = "0 7 1 */3 *"
      topic       = "cost-review-trigger"
      description = "GCP billing vs Paddle revenue"
    }
    "complyform-dr-test" = {
      schedule    = "0 8 1 */3 *"
      topic       = "dr-test-trigger"
      description = "Restore Firestore to staging, verify"
    }
    "complyform-arr-monitor" = {
      schedule    = "0 9 * * *"
      topic       = "arr-monitor-trigger"
      description = "Daily ARR snapshot, $100K alert"
    }
    "complyform-founder-metrics" = {
      schedule    = "0 10 * * *"
      topic       = "founder-metrics-trigger"
      description = "Full metrics suite for dashboard"
    }
    "complyform-github-issues-sync" = {
      schedule    = "0 * * * *"
      topic       = "github-issues-sync-trigger"
      description = "Sync GitHub issues to Firestore"
    }
    "complyform-overage-enforcement" = {
      schedule    = "0 11 * * *"
      topic       = "overage-enforcement-trigger"
      description = "Suspend past-due overage engagements"
    }
    "complyform-customer-health" = {
      schedule    = "0 8 * * 1"
      topic       = "customer-health-trigger"
      description = "Proactive churn signals (Phase 7)"
    }
    "complyform-onboarding-drip" = {
      schedule    = "0 12 * * *"
      topic       = "onboarding-drip-trigger"
      description = "Email lifecycle sequence"
    }
    "complyform-rotation-reminder" = {
      schedule    = "0 6 1 * *"
      topic       = "rotation-reminder-trigger"
      description = "Secret rotation age check"
    }
    "complyform-newsletter-draft" = {
      schedule    = "0 14 1,15 * *"
      topic       = "newsletter-draft-trigger"
      description = "Assemble newsletter Markdown"
    }
    "complyform-dormancy-detection" = {
      schedule    = "0 6 * * 0"
      topic       = "dormancy-detection-trigger"
      description = "Mark inactive projects dormant"
    }
    "complyform-usage-reconciler" = {
      schedule    = "0 13 * * *"
      topic       = "usage-reconciler-trigger"
      description = "Active project count reconciliation"
    }
    "complyform-auto-update" = {
      schedule    = "0 2 * * 1"
      topic       = "auto-update-trigger"
      description = "Dependency + competitive monitoring"
    }
  }
}

resource "google_pubsub_topic" "scheduler" {
  for_each = local.scheduler_jobs

  name    = each.value.topic
  project = var.project_id

  kms_key_name = google_kms_crypto_key.data_key.id
}
resource "google_cloud_scheduler_job" "jobs" {
  for_each = local.scheduler_jobs

  name      = each.key
  project   = var.project_id
  region    = var.region
  schedule  = each.value.schedule
  time_zone = "Etc/UTC"

  pubsub_target {
    topic_name = google_pubsub_topic.scheduler[each.key].id
    data       = base64encode("{\"trigger\": \"scheduled\"}")
  }

  retry_config {
    retry_count          = 1
    min_backoff_duration = "10s"
    max_backoff_duration = "60s"
  }
}
