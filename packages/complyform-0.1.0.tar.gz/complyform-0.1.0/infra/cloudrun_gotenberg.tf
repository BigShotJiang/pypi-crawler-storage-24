# --- Cloud Run Gotenberg Service ---

resource "google_cloud_run_v2_service" "complyform_gotenberg" {
  deletion_protection = false
  name                = "complyform-gotenberg"
  location            = var.region
  project             = var.project_id
  ingress             = "INGRESS_TRAFFIC_INTERNAL_ONLY"

  template {
    execution_environment = "EXECUTION_ENVIRONMENT_GEN2"
    service_account       = google_service_account.functions.email
    timeout               = "60s"

    max_instance_request_concurrency = 4

    scaling {
      min_instance_count = 0
      max_instance_count = 2
    }

    containers {
      image = var.gotenberg_image

      resources {
        limits = {
          cpu    = "1"
          memory = "1Gi"
        }
      }

      ports {
        container_port = 3000
      }

      startup_probe {
        tcp_socket {
          port = 3000
        }
        failure_threshold = 5
        period_seconds    = 10
        timeout_seconds   = 5
      }
    }
  }
}

resource "google_cloud_run_v2_service_iam_member" "gotenberg_api_invoker" {
  project  = var.project_id
  location = var.region
  name     = google_cloud_run_v2_service.complyform_gotenberg.name
  role     = "roles/run.invoker"
  member   = "serviceAccount:${google_service_account.api.email}"
}
