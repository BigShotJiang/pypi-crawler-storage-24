# --- Service Accounts ---

resource "google_service_account" "api" {
  account_id   = "complyform-api"
  display_name = "ComplyForm API Service"
  description  = "Service account for Cloud Run API and dashboard"
  project      = var.project_id
}

resource "google_service_account" "drift" {
  account_id   = "complyform-drift"
  display_name = "ComplyForm Drift Monitor"
  description  = "Service account for Cloud Run Job drift scanning"
  project      = var.project_id
}

resource "google_service_account" "functions" {
  account_id   = "complyform-functions"
  display_name = "ComplyForm Cloud Functions"
  description  = "Shared service account for all Cloud Run Functions gen2"
  project      = var.project_id
}

resource "google_service_account" "cicd" {
  account_id   = "complyform-cicd"
  display_name = "ComplyForm CI/CD (GitHub Actions)"
  description  = "Service account for deployments via Workload Identity Federation"
  project      = var.project_id
}

# --- IAM Role Bindings ---

locals {
  # SA → roles mapping. Using for_each with a flat map for deterministic resource addresses.
  sa_role_bindings = {
    # complyform-api
    "api-datastore-user"  = { sa = google_service_account.api.email, role = "roles/datastore.user" }
    "api-storage-admin"   = { sa = google_service_account.api.email, role = "roles/storage.objectAdmin" }
    "api-secret-accessor" = { sa = google_service_account.api.email, role = "roles/secretmanager.secretAccessor" }
    "api-run-invoker"     = { sa = google_service_account.api.email, role = "roles/run.invoker" }

    # complyform-drift
    "drift-datastore-user"  = { sa = google_service_account.drift.email, role = "roles/datastore.user" }
    "drift-storage-admin"   = { sa = google_service_account.drift.email, role = "roles/storage.objectAdmin" }
    "drift-secret-accessor" = { sa = google_service_account.drift.email, role = "roles/secretmanager.secretAccessor" }
    "drift-asset-viewer"    = { sa = google_service_account.drift.email, role = "roles/cloudasset.viewer" }

    # complyform-functions
    "functions-datastore-user"  = { sa = google_service_account.functions.email, role = "roles/datastore.user" }
    "functions-storage-admin"   = { sa = google_service_account.functions.email, role = "roles/storage.objectAdmin" }
    "functions-secret-accessor" = { sa = google_service_account.functions.email, role = "roles/secretmanager.secretAccessor" }
    "functions-log-writer"      = { sa = google_service_account.functions.email, role = "roles/logging.logWriter" }

    # complyform-cicd
    "cicd-ar-writer"       = { sa = google_service_account.cicd.email, role = "roles/artifactregistry.writer" }
    "cicd-run-admin"       = { sa = google_service_account.cicd.email, role = "roles/run.admin" }
    "cicd-functions-admin" = { sa = google_service_account.cicd.email, role = "roles/cloudfunctions.admin" }
    "cicd-storage-admin"   = { sa = google_service_account.cicd.email, role = "roles/storage.objectAdmin" }
    "cicd-secret-accessor" = { sa = google_service_account.cicd.email, role = "roles/secretmanager.secretAccessor" }
  }
}

resource "google_project_iam_member" "sa_bindings" {
  for_each = local.sa_role_bindings

  project = var.project_id
  role    = each.value.role
  member  = "serviceAccount:${each.value.sa}"
}

# --- CI/CD SA-level impersonation (scoped, not project-level) ---

resource "google_service_account_iam_member" "cicd_act_as_api" {
  service_account_id = google_service_account.api.name
  role               = "roles/iam.serviceAccountUser"
  member             = "serviceAccount:${google_service_account.cicd.email}"
}

resource "google_service_account_iam_member" "cicd_act_as_drift" {
  service_account_id = google_service_account.drift.name
  role               = "roles/iam.serviceAccountUser"
  member             = "serviceAccount:${google_service_account.cicd.email}"
}

resource "google_service_account_iam_member" "cicd_act_as_functions" {
  service_account_id = google_service_account.functions.name
  role               = "roles/iam.serviceAccountUser"
  member             = "serviceAccount:${google_service_account.cicd.email}"
}

# --- Workload Identity Federation ---

resource "google_iam_workload_identity_pool" "github" {
  workload_identity_pool_id = "github-actions"
  display_name              = "GitHub Actions"
  description               = "Workload Identity Pool for GitHub Actions CI/CD"
  project                   = var.project_id
}

resource "google_iam_workload_identity_pool_provider" "github_oidc" {
  # checkov:skip=CKV_GCP_125:Multi-repo CI/CD requires OR condition on two explicit repos (complyform + profiles-private)
  workload_identity_pool_id          = google_iam_workload_identity_pool.github.workload_identity_pool_id
  workload_identity_pool_provider_id = "github-oidc"
  display_name                       = "GitHub OIDC"
  description                        = "OIDC provider for GitHub Actions"
  project                            = var.project_id

  oidc {
    issuer_uri        = "https://token.actions.githubusercontent.com"
    allowed_audiences = ["https://iam.googleapis.com/${google_iam_workload_identity_pool.github.name}"]
  }

  attribute_mapping = {
    "google.subject"             = "assertion.sub"
    "attribute.actor"            = "assertion.actor"
    "attribute.repository"       = "assertion.repository"
    "attribute.repository_owner" = "assertion.repository_owner"
  }

  # Only tokens from the complyform org/repo can assume this identity
  attribute_condition = "assertion.repository == '${var.github_org}/${var.github_repo}' || assertion.repository == '${var.github_org}/profiles-private'"
}

# Allow GitHub Actions from the configured repo to impersonate the CI/CD SA
resource "google_service_account_iam_member" "cicd_workload_identity" {
  service_account_id = google_service_account.cicd.name
  role               = "roles/iam.workloadIdentityUser"
  member             = "principalSet://iam.googleapis.com/${google_iam_workload_identity_pool.github.name}/attribute.repository/${var.github_org}/${var.github_repo}"
}

resource "google_service_account_iam_member" "cicd_workload_identity_profiles" {
  service_account_id = google_service_account.cicd.name
  role               = "roles/iam.workloadIdentityUser"
  member             = "principalSet://iam.googleapis.com/${google_iam_workload_identity_pool.github.name}/attribute.repository/${var.github_org}/profiles-private"
}

# ---------------------------------------------------------------------------
# Cloud Build / Cloud Functions gen2 IAM bindings (D-9: added post-I-5)
# Cloud Functions gen2 uses Cloud Build under the hood. Post-2024 GCP projects
# do not auto-grant these roles to the default compute SA.
# ---------------------------------------------------------------------------


resource "google_project_iam_member" "functions_log_viewer" {
  project = var.project_id
  role    = "roles/logging.viewer"
  member  = "serviceAccount:${google_service_account.functions.email}"
}

resource "google_project_iam_member" "functions_storage_viewer" {
  project = var.project_id
  role    = "roles/storage.objectViewer"
  member  = "serviceAccount:${google_service_account.functions.email}"
}

resource "google_project_iam_member" "cloudbuild_sa_storage_viewer" {
  project = var.project_id
  role    = "roles/storage.objectViewer"
  member  = "serviceAccount:${data.google_project.current.number}@cloudbuild.gserviceaccount.com"
}

resource "google_project_iam_member" "cloudbuild_agent_storage_viewer" {
  project = var.project_id
  role    = "roles/storage.objectViewer"
  member  = "serviceAccount:service-${data.google_project.current.number}@gcp-sa-cloudbuild.iam.gserviceaccount.com"
}

resource "google_project_iam_member" "gcf_admin_storage_viewer" {
  project = var.project_id
  role    = "roles/storage.objectViewer"
  member  = "serviceAccount:service-${data.google_project.current.number}@gcf-admin-robot.iam.gserviceaccount.com"
}

resource "google_project_iam_member" "serverless_robot_storage_viewer" {
  project = var.project_id
  role    = "roles/storage.objectViewer"
  member  = "serviceAccount:service-${data.google_project.current.number}@serverless-robot-prod.iam.gserviceaccount.com"
}

# ---------------------------------------------------------------------------
# Cloud Run public access IAM (I-6: org policy blocks allUsers via Terraform,
# but gcloud succeeded after org policy reset. These bindings ensure
# reproducibility if Cloud Run services are recreated.)
# ---------------------------------------------------------------------------

resource "google_cloud_run_v2_service_iam_member" "api_public" {
  project  = var.project_id
  location = var.region
  name     = "complyform-api"
  role     = "roles/run.invoker"
  member   = "allUsers"
}

resource "google_cloud_run_v2_service_iam_member" "telemetry_public" {
  project  = var.project_id
  location = var.region
  name     = "complyform-telemetry-ingest"
  role     = "roles/run.invoker"
  member   = "allUsers"
}
