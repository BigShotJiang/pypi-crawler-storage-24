# --- Secret Manager Service Agent CMEK Binding ---
# Force-create the Secret Manager service agent so we can grant it CMEK access
# before creating CMEK-encrypted secrets.
resource "google_project_service_identity" "secretmanager" {
  provider = google-beta
  project  = var.project_id
  service  = "secretmanager.googleapis.com"
}

resource "google_kms_crypto_key_iam_member" "secretmanager_cmek" {
  crypto_key_id = google_kms_crypto_key.secretmanager_key.id
  role          = "roles/cloudkms.cryptoKeyEncrypterDecrypter"
  member        = "serviceAccount:${google_project_service_identity.secretmanager.email}"
  depends_on    = [google_project_service_identity.secretmanager]
}

# --- Secret Manager Secrets (16 total) ---
# Secret shells only — values are populated manually by the founder.
# All secrets use automatic replication with CMEK encryption.

locals {
  secrets = {
    paddle_webhook_secret      = { id = "paddle-webhook-secret", desc = "Paddle webhook signature verification" }
    paddle_api_key             = { id = "paddle-api-key", desc = "Paddle server-side API key" }
    paddle_client_token        = { id = "paddle-client-token", desc = "Paddle.js client-side token" }
    postmark_server_token      = { id = "postmark-server-token", desc = "Postmark transactional email API" }
    profile_bundle_signing_key = { id = "profile-bundle-signing-key", desc = "HMAC-SHA256 profile bundle signing" }
    airgap_license_signing_key = { id = "airgap-license-signing-key", desc = "Ed25519 private key for air-gapped licenses" }
    github_token               = { id = "github-token", desc = "Auto-update detector GitHub API" }
    homebrew_tap_token         = { id = "homebrew-tap-token", desc = "GitHub PAT for Homebrew formula" }
    google_oauth_client_id     = { id = "google-oauth-client-id", desc = "Dashboard OAuth 2.0 client ID" }
    google_oauth_client_secret = { id = "google-oauth-client-secret", desc = "Dashboard OAuth 2.0 client secret" }
    session_encryption_key     = { id = "session-encryption-key", desc = "AES-256-GCM session cookie encryption" }
    broker_api_key             = { id = "broker-api-key", desc = "WorkOS API key for SSO" }
    broker_webhook_secret      = { id = "broker-webhook-secret", desc = "SCIM Directory Sync webhook verification" }
    nps_signing_key            = { id = "nps-signing-key", desc = "HMAC-SHA256 NPS survey URL signing" }
    buttondown_api_key         = { id = "buttondown-api-key", desc = "Buttondown newsletter API" }
    anthropic_api_key          = { id = "anthropic-api-key", desc = "Anthropic API for AI-enhanced explain" }
  }
}

resource "google_secret_manager_secret" "secrets" {
  for_each  = local.secrets
  project   = var.project_id
  secret_id = each.value.id

  labels = {
    purpose = replace(each.key, "_", "-")
  }

  # Automatic replication with global CMEK key for multi-region durability.
  replication {
    auto {
      customer_managed_encryption {
        kms_key_name = google_kms_crypto_key.secretmanager_key.id
      }
    }
  }

  depends_on = [google_kms_crypto_key_iam_member.secretmanager_cmek]
}

# --- Per-Secret IAM Accessor Bindings ---
# Each binding grants roles/secretmanager.secretAccessor to the specified service account.

locals {
  secret_accessors = {
    # paddle-webhook-secret → functions
    "paddle-webhook-secret/functions" = { secret = "paddle_webhook_secret", sa = google_service_account.functions.email }

    # paddle-api-key → api, functions
    "paddle-api-key/api"       = { secret = "paddle_api_key", sa = google_service_account.api.email }
    "paddle-api-key/functions" = { secret = "paddle_api_key", sa = google_service_account.functions.email }

    # paddle-client-token → api
    "paddle-client-token/api" = { secret = "paddle_client_token", sa = google_service_account.api.email }

    # postmark-server-token → api, functions
    "postmark-server-token/api"       = { secret = "postmark_server_token", sa = google_service_account.api.email }
    "postmark-server-token/functions" = { secret = "postmark_server_token", sa = google_service_account.functions.email }

    # profile-bundle-signing-key → api
    "profile-bundle-signing-key/api" = { secret = "profile_bundle_signing_key", sa = google_service_account.api.email }

    # airgap-license-signing-key → api
    "airgap-license-signing-key/api" = { secret = "airgap_license_signing_key", sa = google_service_account.api.email }

    # github-token → functions
    "github-token/functions" = { secret = "github_token", sa = google_service_account.functions.email }

    # homebrew-tap-token → cicd
    "homebrew-tap-token/cicd" = { secret = "homebrew_tap_token", sa = google_service_account.cicd.email }

    # google-oauth-client-id → api
    "google-oauth-client-id/api" = { secret = "google_oauth_client_id", sa = google_service_account.api.email }

    # google-oauth-client-secret → api
    "google-oauth-client-secret/api" = { secret = "google_oauth_client_secret", sa = google_service_account.api.email }

    # session-encryption-key → api
    "session-encryption-key/api" = { secret = "session_encryption_key", sa = google_service_account.api.email }

    # broker-api-key → api
    "broker-api-key/api" = { secret = "broker_api_key", sa = google_service_account.api.email }

    # broker-webhook-secret → api
    "broker-webhook-secret/api" = { secret = "broker_webhook_secret", sa = google_service_account.api.email }

    # nps-signing-key → api, functions
    "nps-signing-key/api"       = { secret = "nps_signing_key", sa = google_service_account.api.email }
    "nps-signing-key/functions" = { secret = "nps_signing_key", sa = google_service_account.functions.email }

    # buttondown-api-key → functions
    "buttondown-api-key/functions" = { secret = "buttondown_api_key", sa = google_service_account.functions.email }

    # anthropic-api-key → api
    "anthropic-api-key/api" = { secret = "anthropic_api_key", sa = google_service_account.api.email }
  }
}

resource "google_secret_manager_secret_iam_member" "accessor" {
  for_each  = local.secret_accessors
  project   = var.project_id
  secret_id = google_secret_manager_secret.secrets[each.value.secret].secret_id
  role      = "roles/secretmanager.secretAccessor"
  member    = "serviceAccount:${each.value.sa}"
}
