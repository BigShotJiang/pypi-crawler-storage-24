# --- Global HTTPS Load Balancer + Cloud Armor ---

resource "google_compute_global_address" "complyform_api_ip" {
  name    = "complyform-api-ip"
  project = var.project_id
}

resource "google_compute_region_network_endpoint_group" "complyform_api_neg" {
  name                  = "complyform-api-neg"
  project               = var.project_id
  region                = var.region
  network_endpoint_type = "SERVERLESS"

  cloud_run {
    service = google_cloud_run_v2_service.complyform_api.name
  }
}

resource "google_compute_backend_service" "complyform_api_backend" {
  name                  = "complyform-api-backend"
  project               = var.project_id
  protocol              = "HTTPS"
  enable_cdn            = false
  load_balancing_scheme = "EXTERNAL_MANAGED"

  security_policy = google_compute_security_policy.waf.id

  backend {
    group = google_compute_region_network_endpoint_group.complyform_api_neg.id
  }

  log_config {
    enable      = true
    sample_rate = 1.0
  }
}

resource "google_compute_url_map" "complyform_api_urlmap" {
  name            = "complyform-api-urlmap"
  project         = var.project_id
  default_service = google_compute_backend_service.complyform_api_backend.id
}

resource "google_compute_managed_ssl_certificate" "complyform_api_cert" {
  name    = "complyform-api-cert"
  project = var.project_id

  managed {
    domains = ["api.complyform.dev", "dashboard.complyform.dev"]
  }
}

resource "google_compute_target_https_proxy" "complyform_api_https_proxy" {
  name             = "complyform-api-https-proxy"
  project          = var.project_id
  url_map          = google_compute_url_map.complyform_api_urlmap.id
  ssl_certificates = [google_compute_managed_ssl_certificate.complyform_api_cert.id]
}

resource "google_compute_global_forwarding_rule" "complyform_api_forwarding" {
  name                  = "complyform-api-forwarding"
  project               = var.project_id
  target                = google_compute_target_https_proxy.complyform_api_https_proxy.id
  port_range            = "443"
  ip_address            = google_compute_global_address.complyform_api_ip.id
  load_balancing_scheme = "EXTERNAL_MANAGED"
}

# --- HTTP → HTTPS Redirect ---

resource "google_compute_url_map" "complyform_api_http_redirect" {
  name    = "complyform-api-http-redirect"
  project = var.project_id

  default_url_redirect {
    https_redirect = true
    strip_query    = false
  }
}

resource "google_compute_target_http_proxy" "complyform_api_http_proxy" {
  name    = "complyform-api-http-proxy"
  project = var.project_id
  url_map = google_compute_url_map.complyform_api_http_redirect.id
}

resource "google_compute_global_forwarding_rule" "complyform_api_http_forwarding" {
  name                  = "complyform-api-http-forwarding"
  project               = var.project_id
  target                = google_compute_target_http_proxy.complyform_api_http_proxy.id
  port_range            = "80"
  ip_address            = google_compute_global_address.complyform_api_ip.id
  load_balancing_scheme = "EXTERNAL_MANAGED"
}
