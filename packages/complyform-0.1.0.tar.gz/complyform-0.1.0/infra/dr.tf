# Firestore daily export bucket in the DR project.
# Uses Google-managed encryption (NOT CMEK) so exports survive prod KMS key loss.
resource "google_storage_bucket" "dr_exports" {
  name                        = "complyform-dr-exports"
  project                     = var.dr_project_id
  location                    = var.region
  storage_class               = "STANDARD"
  uniform_bucket_level_access = true
  public_access_prevention    = "enforced"

  versioning {
    enabled = true
  }

  logging {
    log_bucket        = "${var.project_id}-audit-logs"
    log_object_prefix = "dr-exports"
  }

  lifecycle_rule {
    condition {
      age = 90
    }
    action {
      type = "Delete"
    }
  }
}

# Grant the prod project's default Firestore service agent write access to DR bucket
resource "google_storage_bucket_iam_member" "dr_exports_writer" {
  bucket     = google_storage_bucket.dr_exports.name
  role       = "roles/storage.objectAdmin"
  member     = "serviceAccount:${google_project_service_identity.firestore.email}"
  depends_on = [google_project_service_identity.firestore]
}

# --- DR IAM for Cloud Functions (Firestore export automation) ---

# Functions SA needs Firestore import/export admin to trigger exports
resource "google_project_iam_member" "functions_datastore_export" {
  project = var.project_id
  role    = "roles/datastore.importExportAdmin"
  member  = "serviceAccount:${google_service_account.functions.email}"
}

# Functions SA needs write access to DR exports bucket (cross-project)
resource "google_storage_bucket_iam_member" "dr_exports_functions_writer" {
  bucket = google_storage_bucket.dr_exports.name
  role   = "roles/storage.objectCreator"
  member = "serviceAccount:${google_service_account.functions.email}"
}
