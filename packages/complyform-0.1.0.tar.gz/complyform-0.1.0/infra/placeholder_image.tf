# --- Placeholder Container Images for Cloud Run ---

resource "null_resource" "placeholder_images" {
  triggers = {
    api_dockerfile   = filemd5("${path.module}/placeholder/Dockerfile.api")
    api_app          = filemd5("${path.module}/placeholder/app.py")
    drift_dockerfile = filemd5("${path.module}/placeholder/Dockerfile.drift")
  }

  provisioner "local-exec" {
    command = <<-EOT
      cd ${path.module}/placeholder && \
      docker build -f Dockerfile.api -t us-central1-docker.pkg.dev/${var.project_id}/complyform/api:placeholder . && \
      docker push us-central1-docker.pkg.dev/${var.project_id}/complyform/api:placeholder && \
      docker build -f Dockerfile.drift -t us-central1-docker.pkg.dev/${var.project_id}/complyform/drift:placeholder . && \
      docker push us-central1-docker.pkg.dev/${var.project_id}/complyform/drift:placeholder
    EOT
  }
}
