resource "google_vpc_access_connector" "complyform" {
  name          = "complyform-connector"
  region        = var.region
  network       = "default"
  ip_cidr_range = var.vpc_connector_cidr
  machine_type  = "e2-micro"

  # Min 2 for availability; max 3 for cost control (connectors don't scale to zero)
  min_instances = 2
  max_instances = 3
}
