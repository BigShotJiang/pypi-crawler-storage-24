output "kms_key_ring_id" {
  description = "KMS key ring resource ID"
  value       = google_kms_key_ring.complyform.id
}

output "kms_data_key_id" {
  description = "KMS crypto key resource ID (used for Firestore and GCS CMEK in I-3)"
  value       = google_kms_crypto_key.data_key.id
}

output "artifact_registry_url" {
  description = "Full Docker registry URL for container image pushes"
  value       = "${var.region}-docker.pkg.dev/${var.project_id}/${google_artifact_registry_repository.complyform.repository_id}"
}

output "vpc_connector_id" {
  description = "Serverless VPC Access connector self_link (referenced by Cloud Run in I-5)"
  value       = google_vpc_access_connector.complyform.id
}

output "workload_identity_provider" {
  description = "Full Workload Identity Pool Provider resource name (set as GCP_WORKLOAD_IDENTITY_PROVIDER in GitHub Actions)"
  value       = google_iam_workload_identity_pool_provider.github_oidc.name
}

output "cicd_service_account_email" {
  description = "CI/CD service account email (set as GCP_SERVICE_ACCOUNT in GitHub Actions)"
  value       = google_service_account.cicd.email
}

output "api_service_account_email" {
  description = "API service account email (used by Cloud Run API service in I-5)"
  value       = google_service_account.api.email
}

output "drift_service_account_email" {
  description = "Drift monitor service account email (used by Cloud Run Job in I-5)"
  value       = google_service_account.drift.email
}

output "functions_service_account_email" {
  description = "Cloud Functions service account email (used by Cloud Run Functions in I-5)"
  value       = google_service_account.functions.email
}

# --- I-3: Data Stores ---

output "firestore_database_name" {
  description = "Firestore database name"
  value       = google_firestore_database.default.name
}

output "findings_bucket_name" {
  description = "Findings GCS bucket"
  value       = google_storage_bucket.findings.name
}

output "profiles_bucket_name" {
  description = "Profile bundles GCS bucket"
  value       = google_storage_bucket.profiles.name
}

output "telemetry_bucket_name" {
  description = "Telemetry GCS bucket"
  value       = google_storage_bucket.telemetry.name
}

output "corpus_bucket_name" {
  description = "Remediation corpus GCS bucket"
  value       = google_storage_bucket.corpus.name
}

output "dr_exports_bucket_name" {
  description = "DR exports GCS bucket"
  value       = google_storage_bucket.dr_exports.name
}

# --- I-5: Compute ---

output "api_service_url" {
  description = "Cloud Run API service URL (for DNS configuration in I-6)"
  value       = google_cloud_run_v2_service.complyform_api.uri
}

output "api_service_name" {
  description = "Cloud Run API service name (for CI/CD deploy scripts)"
  value       = google_cloud_run_v2_service.complyform_api.name
}

output "gotenberg_service_url" {
  description = "Cloud Run Gotenberg service URL (for API service env var)"
  value       = google_cloud_run_v2_service.complyform_gotenberg.uri
}

output "drift_job_name" {
  description = "Cloud Run drift monitor job name (for scheduler / manual trigger)"
  value       = google_cloud_run_v2_job.complyform_drift_monitor.name
}

output "load_balancer_ip" {
  description = "Global static IP address (for DNS A record in I-6)"
  value       = google_compute_global_address.complyform_api_ip.address
}

output "ssl_certificate_name" {
  description = "Managed SSL certificate name (for verification)"
  value       = google_compute_managed_ssl_certificate.complyform_api_cert.name
}

output "cf_source_bucket" {
  description = "Cloud Function source bucket name (for CI/CD deploy scripts)"
  value       = google_storage_bucket.cf_source.name
}
