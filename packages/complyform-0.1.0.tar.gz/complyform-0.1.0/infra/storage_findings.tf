# Scan findings JSON storage. Cleanup handled by Cloud Function, not lifecycle rules.
resource "google_storage_bucket" "findings" {
  name                        = "${var.project_id}-findings"
  project                     = var.project_id
  location                    = var.region
  storage_class               = "STANDARD"
  uniform_bucket_level_access = true
  public_access_prevention    = "enforced"

  versioning {
    enabled = true
  }

  encryption {
    default_kms_key_name = google_kms_crypto_key.data_key.id
  }


  logging {
    log_bucket = google_storage_bucket.audit_logs.name
  }

  depends_on = [google_kms_crypto_key_iam_member.gcs_cmek]
}
