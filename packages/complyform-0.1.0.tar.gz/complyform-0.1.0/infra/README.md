# ComplyForm Infrastructure — Phase I-2

Core infrastructure: KMS, Artifact Registry, networking, IAM, Workload Identity Federation, and org policies.

## Prerequisites

1. **Phase I-1 (bootstrap)** must be applied first — it creates the GCS state bucket (`complyform-tfstate`) and enables required APIs.
2. Authenticated `gcloud` session with sufficient permissions on `complyform-prod`.

## Usage

```bash
# Copy and fill in variables
cp terraform.tfvars.example terraform.tfvars

# Initialize with GCS remote backend
terraform init

# Review the plan
terraform plan

# Apply
terraform apply
```

## Notes

- `terraform.tfvars` is gitignored — never commit it.
- Org policies are disabled by default (`enable_org_policies = false`) because they require Org Policy Admin.
- KMS key ring and crypto key have `prevent_destroy = true` — intentional, key rings cannot be deleted.

## Phase Dependency Chain

```
I-1 (bootstrap) → I-2 (this) → I-3 (secrets, Firestore, GCS) → I-4 (Cloud Armor) → I-5 (Cloud Run) → I-6 (DNS/TLS)
```

## Post-Apply

Configure GitHub Actions secrets on `complyform/complyform`:

```bash
# Get values
terraform output workload_identity_provider
terraform output cicd_service_account_email
```

Set as `GCP_WORKLOAD_IDENTITY_PROVIDER` and `GCP_SERVICE_ACCOUNT` repository secrets.
