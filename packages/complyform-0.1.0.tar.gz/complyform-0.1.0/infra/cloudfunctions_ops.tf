# --- Cloud Functions: Operational (Pub/Sub triggered) ---

locals {
  ops_functions = {
    "complyform-backup-verify"       = "complyform-backup-verify"
    "complyform-license-audit"       = "complyform-license-audit"
    "complyform-cost-review"         = "complyform-cost-review"
    "complyform-dr-test"             = "complyform-dr-test"
    "complyform-arr-monitor"         = "complyform-arr-monitor"
    "complyform-founder-metrics"     = "complyform-founder-metrics"
    "complyform-github-issues-sync"  = "complyform-github-issues-sync"
    "complyform-overage-enforcement" = "complyform-overage-enforcement"
    "complyform-customer-health"     = "complyform-customer-health"
    "complyform-onboarding-drip"     = "complyform-onboarding-drip"
    "complyform-rotation-reminder"   = "complyform-rotation-reminder"
    "complyform-newsletter-draft"    = "complyform-newsletter-draft"
    "complyform-dormancy-detection"  = "complyform-dormancy-detection"
    "complyform-usage-reconciler"    = "complyform-usage-reconciler"
  }
}

resource "google_cloudfunctions2_function" "ops" {
  for_each = local.ops_functions

  name     = each.key
  location = var.region
  project  = var.project_id

  build_config {
    runtime     = "python313"
    entry_point = "entry_point"

    source {
      storage_source {
        bucket = google_storage_bucket.cf_source.name
        object = google_storage_bucket_object.cf_placeholder.name
      }
    }
  }

  service_config {
    available_memory      = "256Mi"
    available_cpu         = "0.167"
    max_instance_count    = 5
    min_instance_count    = 0
    timeout_seconds       = 60
    ingress_settings      = "ALLOW_INTERNAL_AND_GCLB"
    service_account_email = google_service_account.functions.email

    vpc_connector                 = google_vpc_access_connector.complyform.id
    vpc_connector_egress_settings = "PRIVATE_RANGES_ONLY"

    environment_variables = {
      PROJECT_ID = var.project_id
      REGION     = var.region
    }
  }

  event_trigger {
    trigger_region = var.region
    event_type     = "google.cloud.pubsub.topic.v1.messagePublished"
    pubsub_topic   = google_pubsub_topic.scheduler[each.value].id
    retry_policy   = "RETRY_POLICY_DO_NOT_RETRY"
  }
}
