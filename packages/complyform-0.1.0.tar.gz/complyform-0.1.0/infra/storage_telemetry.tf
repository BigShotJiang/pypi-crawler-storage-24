# Daily NDJSON telemetry. 12-month retention via lifecycle delete.
resource "google_storage_bucket" "telemetry" {
  name                        = "${var.project_id}-telemetry"
  project                     = var.project_id
  location                    = var.region
  storage_class               = "STANDARD"
  uniform_bucket_level_access = true
  public_access_prevention    = "enforced"

  versioning {
    enabled = true
  }

  encryption {
    default_kms_key_name = google_kms_crypto_key.data_key.id
  }

  lifecycle_rule {
    condition {
      age = 365
    }
    action {
      type = "Delete"
    }
  }


  logging {
    log_bucket = google_storage_bucket.audit_logs.name
  }

  depends_on = [google_kms_crypto_key_iam_member.gcs_cmek]
}
