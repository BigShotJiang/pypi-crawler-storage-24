# --- Cloud Functions: Cleanup & Telemetry ---

resource "google_cloudfunctions2_function" "data_cleanup" {
  name     = "complyform-data-cleanup"
  location = var.region
  project  = var.project_id

  build_config {
    runtime     = "python313"
    entry_point = "entry_point"

    source {
      storage_source {
        bucket = google_storage_bucket.cf_source.name
        object = google_storage_bucket_object.cf_placeholder.name
      }
    }
  }

  service_config {
    available_memory      = "256Mi"
    available_cpu         = "0.167"
    max_instance_count    = 5
    min_instance_count    = 0
    timeout_seconds       = 60
    ingress_settings      = "ALLOW_INTERNAL_AND_GCLB"
    service_account_email = google_service_account.functions.email

    vpc_connector                 = google_vpc_access_connector.complyform.id
    vpc_connector_egress_settings = "PRIVATE_RANGES_ONLY"

    environment_variables = {
      PROJECT_ID = var.project_id
      REGION     = var.region
    }
  }

  event_trigger {
    trigger_region = var.region
    event_type     = "google.cloud.pubsub.topic.v1.messagePublished"
    pubsub_topic   = google_pubsub_topic.scheduler["complyform-data-cleanup"].id
    retry_policy   = "RETRY_POLICY_DO_NOT_RETRY"
  }
}

resource "google_cloudfunctions2_function" "telemetry_ingest" {
  name     = "complyform-telemetry-ingest"
  location = var.region
  project  = var.project_id

  build_config {
    runtime     = "python313"
    entry_point = "entry_point"

    source {
      storage_source {
        bucket = google_storage_bucket.cf_source.name
        object = google_storage_bucket_object.cf_placeholder.name
      }
    }
  }

  service_config {
    available_memory      = "256Mi"
    available_cpu         = "0.167"
    max_instance_count    = 10
    min_instance_count    = 0
    timeout_seconds       = 60
    ingress_settings      = "ALLOW_INTERNAL_AND_GCLB"
    service_account_email = google_service_account.functions.email

    vpc_connector                 = google_vpc_access_connector.complyform.id
    vpc_connector_egress_settings = "PRIVATE_RANGES_ONLY"

    environment_variables = {
      PROJECT_ID = var.project_id
      REGION     = var.region
    }
  }
}
