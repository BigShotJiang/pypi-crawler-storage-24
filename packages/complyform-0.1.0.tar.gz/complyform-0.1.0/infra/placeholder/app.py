async def app(scope, receive, send):
    if scope["type"] == "http":
        path = scope.get("path", "")
        if path == "/health":
            status = 200
            body = b'{"status":"healthy","service":"complyform-api-placeholder"}'
        else:
            status = 503
            body = b'{"status":"placeholder","message":"service not yet deployed"}'
        await send({"type": "http.response.start", "status": status, "headers": [[b"content-type", b"application/json"]]})
        await send({"type": "http.response.body", "body": body})
