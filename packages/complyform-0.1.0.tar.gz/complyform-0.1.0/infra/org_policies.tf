# Org policies are gated behind var.enable_org_policies because they require
# Org Policy Admin, which may not be available on Google Workspace Starter.

resource "google_org_policy_policy" "deny_vm_external_ip" {
  count  = var.enable_org_policies ? 1 : 0
  name   = "projects/${var.project_id}/policies/compute.vmExternalIpAccess"
  parent = "projects/${var.project_id}"

  spec {
    rules {
      deny_all = "TRUE"
    }
  }
}

resource "google_org_policy_policy" "disable_sa_key_creation" {
  count  = var.enable_org_policies ? 1 : 0
  name   = "projects/${var.project_id}/policies/iam.disableServiceAccountKeyCreation"
  parent = "projects/${var.project_id}"

  spec {
    rules {
      enforce = "TRUE"
    }
  }
}

resource "google_org_policy_policy" "uniform_bucket_access" {
  count  = var.enable_org_policies ? 1 : 0
  name   = "projects/${var.project_id}/policies/storage.uniformBucketLevelAccess"
  parent = "projects/${var.project_id}"

  spec {
    rules {
      enforce = "TRUE"
    }
  }
}

resource "google_org_policy_policy" "deny_sql_public_ip" {
  count  = var.enable_org_policies ? 1 : 0
  name   = "projects/${var.project_id}/policies/sql.restrictPublicIp"
  parent = "projects/${var.project_id}"

  spec {
    rules {
      deny_all = "TRUE"
    }
  }
}

# ---------------------------------------------------------------------------
# Reset iam.allowedPolicyMemberDomains at project level (I-6)
# The org-level policy restricts IAM members to the Google Workspace domain,
# blocking allUsers bindings on Cloud Run. Cloud Run services behind the
# Global HTTPS LB need allUsers for run.invoker — Cloud Armor handles security.
# ---------------------------------------------------------------------------

resource "google_org_policy_policy" "allow_all_iam_members" {
  count  = var.enable_org_policies ? 1 : 0
  name   = "projects/${var.project_id}/policies/iam.allowedPolicyMemberDomains"
  parent = "projects/${var.project_id}"

  spec {
    reset = true
  }
}
