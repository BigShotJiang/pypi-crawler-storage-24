resource "google_artifact_registry_repository" "complyform" {
  location      = var.region
  repository_id = "complyform"
  format        = "DOCKER"
  description   = "Container images for ComplyForm Cloud Run services"

  cleanup_policies {
    id     = "keep-recent"
    action = "KEEP"
    most_recent_versions {
      keep_count = 10
    }
  }

  cleanup_policies {
    id     = "delete-old-untagged"
    action = "DELETE"
    condition {
      tag_state  = "UNTAGGED"
      older_than = "604800s" # 7 days
    }
  }

  kms_key_name = google_kms_crypto_key.data_key.id
}
