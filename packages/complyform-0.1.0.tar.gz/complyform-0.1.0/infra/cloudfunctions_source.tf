# --- Cloud Function Source Bucket ---

resource "google_storage_bucket" "cf_source" {
  name     = "${var.project_id}-cf-source"
  project  = var.project_id
  location = var.region

  uniform_bucket_level_access = true
  public_access_prevention    = "enforced"
  force_destroy               = true

  versioning {
    enabled = true
  }

  logging {
    log_bucket = google_storage_bucket.audit_logs.name
  }
}
