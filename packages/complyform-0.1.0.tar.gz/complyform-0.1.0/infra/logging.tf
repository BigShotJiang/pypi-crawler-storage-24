# --- Audit Log Bucket ---

resource "google_storage_bucket" "audit_logs_access" {
  name                        = "${var.project_id}-audit-logs-access"
  project                     = var.project_id
  location                    = var.region
  storage_class               = "STANDARD"
  uniform_bucket_level_access = true
  public_access_prevention    = "enforced"

  versioning {
    enabled = true
  }

  logging {
    log_bucket        = "${var.project_id}-audit-logs"
    log_object_prefix = "access-logs"
  }

  lifecycle_rule {
    condition {
      age = 90
    }
    action {
      type = "Delete"
    }
  }

  encryption {
    default_kms_key_name = google_kms_crypto_key.data_key.id
  }

  depends_on = [google_kms_crypto_key_iam_member.gcs_cmek]
}

resource "google_storage_bucket" "audit_logs" {
  name                        = "${var.project_id}-audit-logs"
  project                     = var.project_id
  location                    = var.region
  storage_class               = "STANDARD"
  uniform_bucket_level_access = true
  public_access_prevention    = "enforced"

  versioning {
    enabled = true
  }

  logging {
    log_bucket = google_storage_bucket.audit_logs_access.name
  }

  lifecycle_rule {
    condition {
      age = 365
    }
    action {
      type = "Delete"
    }
  }

  retention_policy {
    is_locked        = true
    retention_period = 31536000
  }

  encryption {
    default_kms_key_name = google_kms_crypto_key.data_key.id
  }

  depends_on = [google_kms_crypto_key_iam_member.gcs_cmek]
}

# --- Log Sinks ---

resource "google_logging_project_sink" "audit_logs" {
  name                   = "audit-logs-long-term"
  project                = var.project_id
  destination            = "storage.googleapis.com/${google_storage_bucket.audit_logs.id}"
  filter                 = "logName:\"cloudaudit.googleapis.com\""
  unique_writer_identity = true
}

# Grant the log sink writer access to the audit logs bucket
resource "google_storage_bucket_iam_member" "audit_logs_sink_writer" {
  bucket = google_storage_bucket.audit_logs.name
  role   = "roles/storage.objectCreator"
  member = google_logging_project_sink.audit_logs.writer_identity
}

resource "google_logging_project_sink" "application_errors" {
  name    = "application-errors"
  project = var.project_id

  # Route to default bucket (no export destination needed — stays in Cloud Logging)
  destination = "logging.googleapis.com/projects/${var.project_id}/locations/global/buckets/_Default"

  filter = "severity >= ERROR AND (resource.type = \"cloud_run_revision\" OR resource.type = \"cloud_function\")"
}

# --- Log-Based Metrics ---

locals {
  log_metrics = {
    "auth_callback_failed" = {
      filter      = "resource.type=\"cloud_run_revision\" AND resource.labels.service_name=\"complyform-api\" AND jsonPayload.event=\"auth_callback_failed\""
      description = "OAuth callback failures"
    }
    "session_ip_mismatch" = {
      filter      = "resource.type=\"cloud_run_revision\" AND resource.labels.service_name=\"complyform-api\" AND jsonPayload.event=\"session_ip_mismatch\""
      description = "Session IP anomalies"
    }
    "email_delivery_failed" = {
      filter      = "resource.type=\"cloud_run_revision\" AND jsonPayload.event=\"email_delivery_failed\""
      description = "Postmark send failures"
    }
    "export_api_push_failed" = {
      filter      = "resource.type=\"cloud_run_revision\" AND jsonPayload.event=\"export_api_push_failed\""
      description = "GRC API push failures"
    }
    "waf_blocked_requests" = {
      filter      = "resource.type=\"http_load_balancer\" AND jsonPayload.enforcedSecurityPolicy.outcome=\"DENY\""
      description = "Cloud Armor WAF blocks"
    }
  }
}

resource "google_logging_metric" "metrics" {
  for_each = local.log_metrics

  name    = each.key
  project = var.project_id
  filter  = each.value.filter

  metric_descriptor {
    metric_kind  = "DELTA"
    value_type   = "INT64"
    display_name = each.value.description
  }
}

# --- Data Access Audit Logs (SOC 2 CC7.2) ---
# Admin activity logs are always-on. Data access logs are opt-in per service.

resource "google_project_iam_audit_config" "firestore" {
  project = var.project_id
  service = "datastore.googleapis.com"

  audit_log_config {
    log_type = "DATA_READ"
  }
  audit_log_config {
    log_type = "DATA_WRITE"
  }
}

resource "google_project_iam_audit_config" "storage" {
  project = var.project_id
  service = "storage.googleapis.com"

  audit_log_config {
    log_type = "DATA_READ"
  }
  audit_log_config {
    log_type = "DATA_WRITE"
  }
}

resource "google_project_iam_audit_config" "secretmanager" {
  project = var.project_id
  service = "secretmanager.googleapis.com"

  audit_log_config {
    log_type = "DATA_READ"
  }
  audit_log_config {
    log_type = "DATA_WRITE"
  }
}

resource "google_project_iam_audit_config" "kms" {
  project = var.project_id
  service = "cloudkms.googleapis.com"

  audit_log_config {
    log_type = "DATA_READ"
  }
  audit_log_config {
    log_type = "DATA_WRITE"
  }
}
