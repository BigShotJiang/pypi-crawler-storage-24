# --- Cloud Run Drift Monitor Job ---

resource "google_cloud_run_v2_job" "complyform_drift_monitor" {
  deletion_protection = false
  name                = "complyform-drift-monitor"
  location            = var.region
  project             = var.project_id

  template {
    task_count  = 1
    parallelism = 1

    template {
      execution_environment = "EXECUTION_ENVIRONMENT_GEN2"
      service_account       = google_service_account.drift.email
      max_retries           = 1
      timeout               = "3600s"

      vpc_access {
        connector = google_vpc_access_connector.complyform.id
        egress    = "PRIVATE_RANGES_ONLY"
      }

      containers {
        image = "us-central1-docker.pkg.dev/${var.project_id}/complyform/drift:placeholder"

        resources {
          limits = {
            cpu    = "1"
            memory = "512Mi"
          }
        }

        env {
          name  = "PROJECT_ID"
          value = var.project_id
        }

        env {
          name  = "REGION"
          value = var.region
        }
      }
    }
  }
}
