variable "project_id" {
  description = "GCP project ID for complyform-prod"
  type        = string

  validation {
    condition     = can(regex("^[a-z][a-z0-9-]{4,28}[a-z0-9]$", var.project_id))
    error_message = "Project ID must be 6-30 chars, start with a letter, contain only lowercase letters, digits, and hyphens, and not end with a hyphen."
  }
}

variable "dr_project_id" {
  description = "GCP project ID for complyform-dr (disaster recovery)"
  type        = string

  validation {
    condition     = can(regex("^[a-z][a-z0-9-]{4,28}[a-z0-9]$", var.dr_project_id))
    error_message = "Project ID must be 6-30 chars, start with a letter, contain only lowercase letters, digits, and hyphens, and not end with a hyphen."
  }
}

variable "region" {
  description = "Primary GCP region"
  type        = string
  default     = "us-central1"

  validation {
    condition     = contains(["us-central1", "europe-west1", "me-central1"], var.region)
    error_message = "Region must be one of: us-central1, europe-west1, me-central1."
  }
}

variable "environment" {
  description = "Environment label applied to resources"
  type        = string
  default     = "production"

  validation {
    condition     = contains(["production", "staging"], var.environment)
    error_message = "Environment must be one of: production, staging."
  }
}

variable "github_org" {
  description = "GitHub organization for Workload Identity Federation"
  type        = string
  default     = "complyform"
}

variable "github_repo" {
  description = "GitHub repository for CI/CD Workload Identity Federation"
  type        = string
  default     = "complyform"
}

variable "kms_rotation_period" {
  description = "KMS key automatic rotation period (default: 90 days)"
  type        = string
  default     = "7776000s"
}

variable "vpc_connector_cidr" {
  description = "CIDR range for Serverless VPC Access connector (/28 required)"
  type        = string
  default     = "10.8.0.0/28"

  validation {
    condition     = can(cidrhost(var.vpc_connector_cidr, 0))
    error_message = "Must be a valid CIDR block."
  }
}

variable "firestore_location" {
  description = "Firestore database location (multi-region)"
  type        = string
  default     = "nam5"
}

variable "enable_org_policies" {
  description = "Enable org policies (requires Org Policy Admin role — may not be available on Workspace Starter)"
  type        = bool
  default     = false
}

variable "pagerduty_integration_key" {
  description = "PagerDuty integration key for alert notifications"
  type        = string
  sensitive   = true
}

# --- I-5: Compute ---

variable "gotenberg_image" {
  description = "Gotenberg Docker image (pin to minor version)"
  type        = string
  default     = "gotenberg/gotenberg:8.13.0-cloudrun"
}
