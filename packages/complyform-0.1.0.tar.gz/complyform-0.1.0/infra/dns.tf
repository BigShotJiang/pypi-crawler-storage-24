# ── I-6: DNS & TLS — Telemetry Domain Mapping ──────────────────────────────
#
# Cloud Run domain mapping for telemetry.complyform.dev → complyform-telemetry-ingest.
# Cloud Functions gen2 are Cloud Run services under the hood.
#
# All other DNS records (api, dashboard, docs, status, email) are managed
# via Cloudflare Dashboard — see scripts/setup-dns.sh and scripts/README-dns.md.

resource "google_cloud_run_domain_mapping" "telemetry" {
  name     = "telemetry.complyform.dev"
  location = var.region
  project  = var.project_id

  metadata {
    namespace = var.project_id
  }

  spec {
    route_name = "complyform-telemetry-ingest"
  }
}

output "telemetry_domain_cname_target" {
  description = "CNAME target for telemetry.complyform.dev — add this as a CNAME record in Cloudflare"
  value       = google_cloud_run_domain_mapping.telemetry.status[0].resource_records[0].rrdata
}
