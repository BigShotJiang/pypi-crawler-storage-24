# Look up project number for service agent email construction
data "google_project" "current" {
  project_id = var.project_id
}

resource "google_kms_key_ring" "complyform" {
  name     = "complyform-keyring"
  location = var.region

  lifecycle {
    prevent_destroy = true
  }
}

resource "google_kms_crypto_key" "data_key" {
  name     = "complyform-data-key"
  key_ring = google_kms_key_ring.complyform.id
  purpose  = "ENCRYPT_DECRYPT"

  rotation_period            = var.kms_rotation_period
  destroy_scheduled_duration = "86400s" # 24 hours

  lifecycle {
    prevent_destroy = true
  }
}

# Grant CMEK access to application service accounts and GCP service agents.
# Service agents need this before I-3 can enable CMEK on Firestore and GCS.
resource "google_kms_crypto_key_iam_member" "encrypter_decrypter" {
  for_each = toset([
    google_service_account.api.member,
    google_service_account.drift.member,
    google_service_account.functions.member,
  ])

  crypto_key_id = google_kms_crypto_key.data_key.id
  role          = "roles/cloudkms.cryptoKeyEncrypterDecrypter"
  member        = each.value
}

resource "google_kms_key_ring" "global" {
  name     = "complyform-global-keyring"
  location = "global"

  lifecycle {
    prevent_destroy = true
  }
}

resource "google_kms_crypto_key" "secretmanager_key" {
  name     = "complyform-secretmanager-key"
  key_ring = google_kms_key_ring.global.id
  purpose  = "ENCRYPT_DECRYPT"

  rotation_period            = var.kms_rotation_period
  destroy_scheduled_duration = "86400s"

  lifecycle {
    prevent_destroy = true
  }
}

# Pub/Sub service agent needs CMEK access for encrypted topics (I-7 fix)
resource "google_kms_crypto_key_iam_member" "pubsub_cmek" {
  crypto_key_id = google_kms_crypto_key.data_key.id
  role          = "roles/cloudkms.cryptoKeyEncrypterDecrypter"
  member        = "serviceAccount:service-${data.google_project.current.number}@gcp-sa-pubsub.iam.gserviceaccount.com"
}

# Artifact Registry service agent needs CMEK access (I-7 fix)
resource "google_kms_crypto_key_iam_member" "ar_cmek" {
  crypto_key_id = google_kms_crypto_key.data_key.id
  role          = "roles/cloudkms.cryptoKeyEncrypterDecrypter"
  member        = "serviceAccount:service-${data.google_project.current.number}@gcp-sa-artifactregistry.iam.gserviceaccount.com"
}
