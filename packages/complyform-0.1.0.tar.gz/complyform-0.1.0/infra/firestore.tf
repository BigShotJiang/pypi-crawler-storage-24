# --- Firestore Service Agent CMEK Binding ---
# Force-create the Firestore service agent so we can grant it CMEK access
# before creating the CMEK-encrypted database.
resource "google_project_service_identity" "firestore" {
  provider = google-beta
  project  = var.project_id
  service  = "firestore.googleapis.com"
}

resource "google_kms_crypto_key_iam_member" "firestore_cmek" {
  crypto_key_id = google_kms_crypto_key.data_key.id
  role          = "roles/cloudkms.cryptoKeyEncrypterDecrypter"
  member        = "serviceAccount:${google_project_service_identity.firestore.email}"
  depends_on    = [google_project_service_identity.firestore]
}

# --- Firestore Database ---
# Primary Firestore database with CMEK, PITR, and delete protection.
resource "google_firestore_database" "default" {
  project                           = var.project_id
  name                              = "(default)"
  location_id                       = var.firestore_location
  type                              = "FIRESTORE_NATIVE"
  delete_protection_state           = "DELETE_PROTECTION_ENABLED"
  point_in_time_recovery_enablement = "POINT_IN_TIME_RECOVERY_ENABLED"

  # CMEK requires per-project allowlisting via https://forms.gle/D3cB7xY6A44aVusY9
  # Uncomment cmek_config once the project is approved:
  # cmek_config {
  #   kms_key_name = google_kms_crypto_key.data_key.id
  # }

  depends_on = [google_kms_crypto_key_iam_member.firestore_cmek]
}

# --- TTL Policies ---
# Each policy auto-deletes documents after their TTL field timestamp passes.

# 7-day webhook deduplication expiry
resource "google_firestore_field" "processed_webhook_events_ttl" {
  project    = var.project_id
  database   = google_firestore_database.default.name
  collection = "processed_webhook_events"
  field      = "created_at"

  ttl_config {}
}

# Sliding 7-day session window
resource "google_firestore_field" "sessions_ttl" {
  project    = var.project_id
  database   = google_firestore_database.default.name
  collection = "sessions"
  field      = "expires_at"

  ttl_config {}
}

# 30-day email event retention
resource "google_firestore_field" "postmark_events_ttl" {
  project    = var.project_id
  database   = google_firestore_database.default.name
  collection = "postmark_events"
  field      = "expires_at"

  ttl_config {}
}

# Max 30-day share link expiry
resource "google_firestore_field" "shared_links_ttl" {
  project    = var.project_id
  database   = google_firestore_database.default.name
  collection = "shared_links"
  field      = "expires_at"

  ttl_config {}
}
