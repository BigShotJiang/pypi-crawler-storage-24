# --- GCS Service Agent CMEK Binding ---
# Cloud Storage uses a dedicated data source for its service agent email
# (google_project_service_identity returns null for storage.googleapis.com).
data "google_storage_project_service_account" "gcs" {
  project = var.project_id
}

resource "google_kms_crypto_key_iam_member" "gcs_cmek" {
  crypto_key_id = google_kms_crypto_key.data_key.id
  role          = "roles/cloudkms.cryptoKeyEncrypterDecrypter"
  member        = "serviceAccount:${data.google_storage_project_service_account.gcs.email_address}"
}
