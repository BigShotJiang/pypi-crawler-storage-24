"""Founder dashboard — admin-only KPI views and drilldowns."""

from __future__ import annotations
