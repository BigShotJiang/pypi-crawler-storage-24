"""Founder dashboard context dataclasses — template rendering contexts.

Each dataclass maps to a founder dashboard page or htmx partial.
Built from ``founder_metrics/{date}`` and ``founder_metrics/github_issues``
Firestore documents.
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class TopRowMetrics:
    """2-second glance: ARR, MRR, customers, system health."""

    arr: float | None
    mrr: float | None
    total_customers: int | None
    system_health: str  # "green" | "yellow" | "red"


@dataclass
class GrowthRowMetrics:
    """Growth signals: NRR, churn, burn, CAC payback."""

    nrr: float | None  # percentage
    logo_churn_30d: float | None  # percentage
    burn_multiple: float | None  # ratio, None if no growth
    cac_payback_days: int | None


@dataclass
class HealthRowMetrics:
    """Operational health: scans, issues, corpus, cost ratio."""

    scan_frequency_trend: str  # "up" | "stable" | "declining"
    open_issues_p1_p2: int | None
    corpus_triples: int | None
    cost_to_revenue_ratio: float | None  # percentage


@dataclass
class FounderDashboardContext:
    """Full context for the main founder dashboard page."""

    top_row: TopRowMetrics
    growth_row: GrowthRowMetrics
    health_row: HealthRowMetrics
    computed_at: str | None  # ISO 8601
    is_stale: bool  # True if computed_at > 48hr old


@dataclass
class HealthDrilldownContext:
    """Context for the health drilldown htmx partial."""

    services: list[dict[str, object]] = field(
        default_factory=list,
    )  # [{name, status, latency_p95, sparkline_data}]
    postmark_delivery_rate: float | None = None
    postmark_bounce_rate: float | None = None
    postmark_spam_rate: float | None = None
    activation_at_risk_count: int = 0
    rotation_health: dict[str, object] = field(
        default_factory=dict,
    )  # {secret_name: {days_since_rotation, status}}
    issues_by_tier: dict[str, int] = field(
        default_factory=dict,
    )  # {community: N, pro: N, team: N, agency: N}
    # {number, title, url, created_at}
    oldest_unresolved: dict[str, object] | None = None


@dataclass
class GrowthDrilldownContext:
    """Context for the growth drilldown htmx partial."""

    revenue_by_tier: dict[str, float] = field(
        default_factory=dict,
    )  # {pro: N, team: N, agency: N, enterprise: N}
    arpu: float | None = None
    mrr_growth_rate: float | None = None
    quick_ratio: float | None = None
    nps_score: float | None = None
    scan_frequency_7d: int | None = None
    scan_frequency_30d: int | None = None
    cancellation_reasons_90d: dict[str, int] = field(
        default_factory=dict,
    )  # {too_expensive: N, missing_features: N, ...}


@dataclass
class CorpusDrilldownContext:
    """Context for the corpus drilldown htmx partial."""

    total_triples: int = 0
    readiness: str = "red"  # "red" | "yellow" | "green"
    resource_type_distribution: dict[str, int] = field(
        default_factory=dict,
    )  # {type: count}
