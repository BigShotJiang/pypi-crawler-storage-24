"""Jinja2 environment — template loader and SVG helper registration.

Configures autoescaping, async mode, and registers SVG chart
helpers as template globals.
"""

from __future__ import annotations

from jinja2 import Environment, FileSystemLoader, select_autoescape

from backend.dashboard.svg_helpers import (
    render_donut_svg,
    render_score_trend_svg,
    render_severity_bar_svg,
    render_sparkline_svg,
)

jinja_env = Environment(
    loader=FileSystemLoader("backend/dashboard/templates"),
    autoescape=select_autoescape(["html"]),
    enable_async=True,
)

# Register SVG helpers as template globals
jinja_env.globals["render_donut_svg"] = render_donut_svg
jinja_env.globals["render_sparkline_svg"] = render_sparkline_svg
jinja_env.globals["render_severity_bar_svg"] = render_severity_bar_svg
jinja_env.globals["render_score_trend_svg"] = render_score_trend_svg
