"""License key and API key generation.

Keys are generated as cryptographically random hex strings.  Only the
SHA-256 hash is persisted; the plaintext is sent to the customer once.
"""

from __future__ import annotations

import hashlib
import secrets


def generate_license_key() -> tuple[str, str]:
    """Generate license key and its SHA-256 hash.

    Returns:
        ``(plaintext_key, key_hash)`` — plaintext sent to customer once,
        hash stored in Firestore.
        Format: ``cf_live_{32 hex chars}``
    """
    raw = secrets.token_hex(16)
    key = f"cf_live_{raw}"
    key_hash = hashlib.sha256(key.encode()).hexdigest()
    return key, key_hash


def generate_api_key() -> tuple[str, str]:
    """Generate API key and its SHA-256 hash.

    Returns:
        ``(plaintext_key, key_hash)``
        Format: ``sk_{32 hex chars}``
    """
    raw = secrets.token_hex(16)
    key = f"sk_{raw}"
    key_hash = hashlib.sha256(key.encode()).hexdigest()
    return key, key_hash
