"""Pydantic v2 models for drift monitoring events, alerts, and configuration."""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field


class DriftFinding(BaseModel, strict=True):
    """Single finding in a drift detection result. Max 5 per alert."""

    control_id: str
    framework: str
    resource_address: str
    severity: Literal["critical", "high", "medium", "low"]


class NormalizedDriftEvent(BaseModel, strict=True):
    """Cloud-agnostic drift event after normalization."""

    cloud: Literal["gcp", "aws", "azure"]
    cloud_account_id: str
    resource_type: str
    resource_id: str
    change_type: Literal["create", "update", "delete"]
    event_timestamp: str
    raw_event: dict  # type: ignore[type-arg]


class DriftDetectionResult(BaseModel, strict=True):
    """Result of a drift re-assessment for one project."""

    project_id: str
    project_label: str
    cloud: str
    previous_score: float
    new_score: float
    score_delta: float
    new_failures: int
    resolved_failures: int
    top_findings: list[DriftFinding]
    findings_uri: str
    alert_required: bool


class DriftAlertPayload(BaseModel, strict=True):
    """Outgoing webhook payload for drift alerts."""

    event: Literal["drift_alert"] = "drift_alert"
    project_label: str
    cloud: str
    old_score: float
    new_score: float
    score_delta: float
    top_findings: list[DriftFinding]
    dashboard_url: str
    timestamp: str


class DriftConfigureRequest(BaseModel, strict=True):
    """Request body for POST /v1/dashboard/projects/{id}/configure."""

    drift_mode: Literal["scheduled", "event_driven"] | None = None
    drift_alerts: bool | None = None
    state_source: str | None = None
    frameworks: list[str] | None = None
    alert_email: str | None = None
    alert_threshold: int | None = Field(None, ge=1, le=50)
    alert_webhook: str | None = None
    tfc_token: str | None = None


class DriftSetupInstructions(BaseModel, strict=True):
    """Returned when drift_mode switches to event_driven."""

    cloud: str
    webhook_url: str
    terraform_module_url: str
    variables: dict[str, str]
    quickstart: str


class DriftConfigureResponse(BaseModel, strict=True):
    """Response from POST /v1/dashboard/projects/{id}/configure."""

    project_id: str
    drift_mode: str
    drift_alerts: bool
    setup_instructions: DriftSetupInstructions | None = None
    webhook_secret: str | None = None
