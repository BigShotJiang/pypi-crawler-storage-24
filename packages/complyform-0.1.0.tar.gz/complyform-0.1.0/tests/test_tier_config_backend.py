"""Tests for backend.shared.tier_config."""

from __future__ import annotations

from backend.shared.tier_config import (
    ALL_FRAMEWORKS,
    FREE_FRAMEWORKS,
    TIER_CONFIG,
    TIER_RANK,
)


def test_free_frameworks_subset_of_all() -> None:
    assert FREE_FRAMEWORKS <= ALL_FRAMEWORKS


def test_all_tiers_present() -> None:
    expected = {
        "community",
        "pro",
        "team",
        "agency",
        "enterprise",
        "enterprise_unlimited",
    }
    assert set(TIER_CONFIG.keys()) == expected


def test_tier_rank_covers_all_tiers() -> None:
    assert set(TIER_RANK.keys()) == set(TIER_CONFIG.keys())


def test_tier_rank_ordering() -> None:
    assert TIER_RANK["community"] < TIER_RANK["pro"]
    assert TIER_RANK["pro"] < TIER_RANK["team"]
    assert TIER_RANK["team"] < TIER_RANK["agency"]
    assert TIER_RANK["agency"] < TIER_RANK["enterprise"]
    assert TIER_RANK["enterprise"] < TIER_RANK["enterprise_unlimited"]


def test_community_has_no_features() -> None:
    assert TIER_CONFIG["community"]["features"] == []


def test_community_remediate_is_free() -> None:
    assert set(TIER_CONFIG["community"]["remediate_frameworks"]) == set(FREE_FRAMEWORKS)  # type: ignore[arg-type]


def test_enterprise_unlimited_has_all_frameworks() -> None:
    assert TIER_CONFIG["enterprise_unlimited"]["remediate_frameworks"] == ["all"]


def test_overage_field_exists_for_agency_enterprise() -> None:
    assert "overage_per_engagement_month" in TIER_CONFIG["agency"]
    assert "overage_per_engagement_month" in TIER_CONFIG["enterprise"]


def test_no_overage_for_community_pro_team() -> None:
    for tier in ("community", "pro", "team", "enterprise_unlimited"):
        assert "overage_per_engagement_month" not in TIER_CONFIG[tier]


def test_hosted_dashboard_not_in_community_pro() -> None:
    for tier in ("community", "pro"):
        features = TIER_CONFIG[tier]["features"]
        assert isinstance(features, list)
        assert "hosted_dashboard" not in features


def test_hosted_dashboard_in_team_plus() -> None:
    for tier in ("team", "agency", "enterprise", "enterprise_unlimited"):
        features = TIER_CONFIG[tier]["features"]
        assert isinstance(features, list)
        assert "hosted_dashboard" in features
