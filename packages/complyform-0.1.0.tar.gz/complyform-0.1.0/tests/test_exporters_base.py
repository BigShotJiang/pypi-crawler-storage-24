"""Tests for evidence exporter base classes."""

from __future__ import annotations

from typing import TYPE_CHECKING

import pytest

from complyform.core.errors import ExportFormatError
from complyform.core.generators.evidence_export import (
    EXPORTER_REGISTRY,
    get_exporter,
    register_exporter,
)
from complyform.core.generators.evidence_export.base import (
    EvidenceExporter,
    ExportResult,
)

if TYPE_CHECKING:
    from pathlib import Path


class TestExportResult:
    def test_creation(self, tmp_path: Path) -> None:
        result = ExportResult(
            format="scc-json",
            output_files=[tmp_path / "test.ndjson"],
            record_count=10,
        )
        assert result.format == "scc-json"
        assert result.record_count == 10
        assert result.api_push_status is None
        assert result.warnings == []

    def test_with_warnings(self, tmp_path: Path) -> None:
        result = ExportResult(
            format="grc-json",
            output_files=[],
            record_count=0,
            warnings=["test warning"],
        )
        assert result.warnings == ["test warning"]


class TestEvidenceExporterABC:
    def test_cannot_instantiate(self) -> None:
        with pytest.raises(TypeError):
            EvidenceExporter()  # type: ignore[abstract]


class TestExporterRegistry:
    def test_get_nonexistent(self) -> None:
        with pytest.raises(ExportFormatError):
            get_exporter("nonexistent")

    def test_registry_has_builtin_exporters(self) -> None:
        assert "scc-json" in EXPORTER_REGISTRY
        assert "audit-manager" in EXPORTER_REGISTRY
        assert "purview" in EXPORTER_REGISTRY
        assert "grc-json" in EXPORTER_REGISTRY

    def test_get_exporter_returns_instance(self) -> None:
        exporter = get_exporter("scc-json")
        assert isinstance(exporter, EvidenceExporter)

    def test_register_exporter(self) -> None:
        class _DummyExporter(EvidenceExporter):
            FORMAT_ID = "_test_dummy"
            TIER_FEATURE = "evidence_export_native"

            def export_to_file(
                self,
                findings,
                metadata,
                output_dir,
                project_label=None,
            ):
                return ExportResult(
                    format=self.FORMAT_ID,
                    output_files=[],
                    record_count=0,
                )

        register_exporter(_DummyExporter)
        assert "_test_dummy" in EXPORTER_REGISTRY
        # Cleanup
        del EXPORTER_REGISTRY["_test_dummy"]
