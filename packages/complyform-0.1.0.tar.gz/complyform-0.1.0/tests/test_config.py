"""Tests for complyform.core.config."""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import pytest

from complyform.core.config import (
    ComplyFormConfig,
    ensure_complyform_dir,
    load_config,
    resolve_config_path,
    save_config,
)


class TestResolveConfigPath:
    def test_default(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.delenv("COMPLYFORM_CONFIG", raising=False)
        path = resolve_config_path()
        assert path == Path.home() / ".complyform" / "config.yaml"

    def test_env_var(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("COMPLYFORM_CONFIG", "/tmp/custom.yaml")
        path = resolve_config_path()
        assert path == Path("/tmp/custom.yaml")

    def test_cli_overrides_env(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("COMPLYFORM_CONFIG", "/tmp/env.yaml")
        path = resolve_config_path("/tmp/cli.yaml")
        assert path == Path("/tmp/cli.yaml")


class TestEnsureComplyformDir:
    def test_creates_dir(
        self,
        tmp_path: Path,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        fake_home = tmp_path / "fakehome"
        fake_home.mkdir()
        monkeypatch.setattr(Path, "home", staticmethod(lambda: fake_home))
        result = ensure_complyform_dir()
        assert result.exists()
        assert result == fake_home / ".complyform"
        assert oct(result.stat().st_mode & 0o777) == oct(0o700)

    def test_idempotent(
        self,
        tmp_path: Path,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        fake_home = tmp_path / "fakehome"
        fake_home.mkdir()
        monkeypatch.setattr(Path, "home", staticmethod(lambda: fake_home))
        ensure_complyform_dir()
        ensure_complyform_dir()  # Should not raise


class TestLoadConfig:
    def test_missing_file_creates_default(self, tmp_path: Path) -> None:
        config_path = tmp_path / ".complyform" / "config.yaml"
        cfg = load_config(config_path)
        assert config_path.exists()
        assert cfg.tier == "community"
        assert cfg.telemetry is False
        assert cfg.color is True

    def test_existing_file(self, tmp_path: Path) -> None:
        config_path = tmp_path / "config.yaml"
        config_path.write_text("default_cloud: gcp\ntier: professional\n")
        cfg = load_config(config_path)
        assert cfg.default_cloud == "gcp"
        assert cfg.tier == "professional"

    def test_empty_file(self, tmp_path: Path) -> None:
        config_path = tmp_path / "config.yaml"
        config_path.write_text("")
        cfg = load_config(config_path)
        assert cfg.tier == "community"


class TestSaveConfig:
    def test_writes_file(self, tmp_path: Path) -> None:
        config_path = tmp_path / "config.yaml"
        cfg = ComplyFormConfig(default_cloud="aws")
        save_config(cfg, config_path)
        assert config_path.exists()
        assert oct(config_path.stat().st_mode & 0o777) == oct(0o600)

    def test_round_trip(self, tmp_path: Path) -> None:
        config_path = tmp_path / "config.yaml"
        original = ComplyFormConfig(
            default_cloud="azure",
            cache_ttl_hours=48,
            tier="professional",
        )
        save_config(original, config_path)
        loaded = load_config(config_path)
        assert loaded.default_cloud == original.default_cloud
        assert loaded.cache_ttl_hours == original.cache_ttl_hours
        assert loaded.tier == original.tier


class TestDefaults:
    def test_default_values(self) -> None:
        cfg = ComplyFormConfig()
        assert cfg.tier == "community"
        assert cfg.telemetry is False
        assert cfg.color is True
        assert cfg.default_format == "terminal"
        assert cfg.cache_ttl_hours == 24
