"""Tests for backend.billing.license_generator."""

from __future__ import annotations

import hashlib
import re

from backend.billing.license_generator import generate_api_key, generate_license_key


def test_license_key_format() -> None:
    key, key_hash = generate_license_key()
    assert re.match(r"^cf_live_[a-f0-9]{32}$", key)
    assert key_hash == hashlib.sha256(key.encode()).hexdigest()


def test_license_key_uniqueness() -> None:
    keys = {generate_license_key()[0] for _ in range(100)}
    assert len(keys) == 100


def test_api_key_format() -> None:
    key, key_hash = generate_api_key()
    assert re.match(r"^sk_[a-f0-9]{32}$", key)
    assert key_hash == hashlib.sha256(key.encode()).hexdigest()


def test_api_key_uniqueness() -> None:
    keys = {generate_api_key()[0] for _ in range(100)}
    assert len(keys) == 100
