"""Tests for complyform-action/action.yml — Phase 20c."""

from __future__ import annotations

from pathlib import Path

import pytest
import yaml

_ACTION_PATH = (
    Path(__file__).resolve().parent.parent / "complyform-action" / "action.yml"
)

pytestmark = pytest.mark.skipif(
    not _ACTION_PATH.exists(), reason="complyform-action not co-located"
)


class TestActionYmlValid:
    def test_action_yml_valid(self) -> None:
        """action.yml loads as valid YAML with required inputs."""
        data = yaml.safe_load(_ACTION_PATH.read_text(encoding="utf-8"))

        assert data is not None
        assert "inputs" in data
        assert "outputs" in data
        assert "runs" in data

        # Required inputs
        inputs = data["inputs"]
        assert inputs["cloud"]["required"] is True
        assert inputs["state-path"]["required"] is True
        assert inputs["license-key"]["required"] is True


class TestActionYmlOutputs:
    def test_action_yml_outputs(self) -> None:
        """All 5 outputs are defined."""
        data = yaml.safe_load(_ACTION_PATH.read_text(encoding="utf-8"))
        outputs = data["outputs"]

        expected = {
            "score",
            "findings-count",
            "critical-count",
            "report-path",
            "exit-code",
        }
        assert set(outputs.keys()) == expected

        for key in expected:
            assert "description" in outputs[key]
            assert "value" in outputs[key]


class TestActionYmlSteps:
    def test_action_yml_steps(self) -> None:
        """All 7 steps are present."""
        data = yaml.safe_load(_ACTION_PATH.read_text(encoding="utf-8"))
        steps = data["runs"]["steps"]

        assert len(steps) == 7

        step_names = [s["name"] for s in steps]
        assert "Install ComplyForm CLI" in step_names
        assert "Activate license" in step_names
        assert "Run compliance scan" in step_names
        assert "Custom Checkov policies" in step_names
        assert "OPA/Conftest policies" in step_names
        assert "Dashboard push" in step_names
        assert "Check findings" in step_names
