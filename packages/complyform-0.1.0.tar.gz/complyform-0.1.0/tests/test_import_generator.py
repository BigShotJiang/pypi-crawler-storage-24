"""Tests for complyform.core.remediator.import_generator."""

from __future__ import annotations

from complyform.core.remediator.import_generator import (
    IMPORT_ID_PATTERNS,
    ImportGenerator,
)
from complyform.core.scanner.state_parser import ResourceRecord


def _resource(
    resource_type: str = "google_storage_bucket",
    address: str = "google_storage_bucket.data",
    name: str = "data",
    **attrs: object,
) -> ResourceRecord:
    defaults = {"id": "test-id", "name": name, "project": "my-proj"}
    defaults.update(attrs)
    return ResourceRecord(
        provider="google",
        resource_type=resource_type,
        name=name,
        address=address,
        attributes=defaults,
        module=None,
        source_state="test",
    )


class TestGCPImportID:
    def test_storage_bucket(self) -> None:
        gen = ImportGenerator()
        r = _resource(
            resource_type="google_storage_bucket",
            address="google_storage_bucket.data",
            name="my-bucket",
            project="my-proj",
        )
        block = gen.generate_import_block(r, "gcp")
        assert "google_storage_bucket.data" in block
        assert "my-proj/my-bucket" in block

    def test_compute_instance(self) -> None:
        gen = ImportGenerator()
        r = _resource(
            resource_type="google_compute_instance",
            address="google_compute_instance.vm",
            name="vm-1",
            project="proj-1",
            zone="us-central1-a",
        )
        block = gen.generate_import_block(r, "gcp")
        assert "projects/proj-1/zones/us-central1-a/instances/vm-1" in block

    def test_sql_instance(self) -> None:
        gen = ImportGenerator()
        r = _resource(
            resource_type="google_sql_database_instance",
            address="google_sql_database_instance.main",
            name="main",
            project="my-proj",
        )
        block = gen.generate_import_block(r, "gcp")
        assert "projects/my-proj/instances/main" in block


class TestAWSImportID:
    def test_s3_bucket(self) -> None:
        gen = ImportGenerator()
        r = ResourceRecord(
            provider="aws",
            resource_type="aws_s3_bucket",
            name="data",
            address="aws_s3_bucket.data",
            attributes={"bucket": "my-data-bucket", "id": "my-data-bucket"},
            module=None,
            source_state="test",
        )
        block = gen.generate_import_block(r, "aws")
        assert "my-data-bucket" in block

    def test_instance_uses_id(self) -> None:
        gen = ImportGenerator()
        r = ResourceRecord(
            provider="aws",
            resource_type="aws_instance",
            name="web",
            address="aws_instance.web",
            attributes={"id": "i-1234567890abcdef"},
            module=None,
            source_state="test",
        )
        block = gen.generate_import_block(r, "aws")
        assert "i-1234567890abcdef" in block


class TestAzureImportID:
    def test_uses_id_attribute(self) -> None:
        gen = ImportGenerator()
        azure_id = (
            "/subscriptions/sub-1/resourceGroups/rg-1"
            "/providers/Microsoft.Storage"
            "/storageAccounts/sa1"
        )
        r = ResourceRecord(
            provider="azurerm",
            resource_type="azurerm_storage_account",
            name="sa1",
            address="azurerm_storage_account.sa1",
            attributes={"id": azure_id},
            module=None,
            source_state="test",
        )
        block = gen.generate_import_block(r, "azure")
        assert azure_id in block


class TestUnknownResourceType:
    def test_fallback_to_id(self) -> None:
        gen = ImportGenerator()
        r = ResourceRecord(
            provider="unknown",
            resource_type="unknown_resource",
            name="x",
            address="unknown_resource.x",
            attributes={"id": "fallback-id"},
            module=None,
            source_state="test",
        )
        block = gen.generate_import_block(r, "gcp")
        assert "fallback-id" in block


class TestPatternCoverage:
    def test_all_patterns_have_valid_keys(self) -> None:
        """All patterns in IMPORT_ID_PATTERNS are well-formed."""
        for rt, pattern in IMPORT_ID_PATTERNS.items():
            assert isinstance(rt, str)
            assert isinstance(pattern, str)
            assert len(pattern) > 0
