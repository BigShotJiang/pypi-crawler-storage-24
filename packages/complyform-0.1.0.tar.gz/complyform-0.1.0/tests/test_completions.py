"""Tests for complyform.cli.completions — full coverage."""

from __future__ import annotations

from unittest.mock import patch

import pytest

from complyform.cli.completions import (
    complete_category,
    complete_cloud,
    complete_framework_id,
    complete_tier,
)
from complyform.core.profiles.registry import _reset_cache


@pytest.fixture(autouse=True)
def _clear_registry_cache() -> None:
    _reset_cache()


# -------------------------------------------------------------------
# complete_framework_id
# -------------------------------------------------------------------


class TestCompleteFrameworkId:
    def test_prefix_match(self) -> None:
        results = complete_framework_id("soc")
        assert "soc2" in results

    def test_empty_prefix(self) -> None:
        results = complete_framework_id("")
        assert len(results) == 53

    def test_no_match(self) -> None:
        results = complete_framework_id("zzz_nonexistent")
        assert results == []

    def test_cis_prefix(self) -> None:
        results = complete_framework_id("cis_")
        assert "cis_gcp" in results
        assert "cis_aws" in results
        assert "cis_azure" in results

    def test_exception_returns_empty(self) -> None:
        """When registry loading fails, return empty list."""
        with patch(
            "complyform.core.profiles.registry._load_registry",
            side_effect=RuntimeError("boom"),
        ):
            from complyform.core.profiles.registry import _reset_cache

            _reset_cache()
            results = complete_framework_id("")
            assert results == []


# -------------------------------------------------------------------
# complete_cloud
# -------------------------------------------------------------------


class TestCompleteCloud:
    def test_g_prefix(self) -> None:
        assert complete_cloud("g") == ["gcp"]

    def test_a_prefix(self) -> None:
        assert complete_cloud("a") == ["aws", "azure"]

    def test_empty(self) -> None:
        assert complete_cloud("") == ["gcp", "aws", "azure"]

    def test_no_match(self) -> None:
        assert complete_cloud("x") == []

    def test_full_match(self) -> None:
        assert complete_cloud("gcp") == ["gcp"]


# -------------------------------------------------------------------
# complete_tier
# -------------------------------------------------------------------


class TestCompleteTier:
    def test_no_f_match(self) -> None:
        assert complete_tier("f") == []

    def test_c_prefix(self) -> None:
        assert complete_tier("c") == ["community"]

    def test_p_prefix(self) -> None:
        assert complete_tier("p") == ["pro"]

    def test_t_prefix(self) -> None:
        assert complete_tier("t") == ["team"]

    def test_a_prefix(self) -> None:
        assert complete_tier("a") == ["agency"]

    def test_e_prefix(self) -> None:
        assert complete_tier("e") == ["enterprise"]

    def test_empty(self) -> None:
        assert complete_tier("") == ["community", "pro", "team", "agency", "enterprise"]

    def test_no_match(self) -> None:
        assert complete_tier("z") == []


# -------------------------------------------------------------------
# complete_category
# -------------------------------------------------------------------


class TestCompleteCategory:
    def test_g_prefix(self) -> None:
        assert complete_category("g") == ["global"]

    def test_r_prefix(self) -> None:
        assert complete_category("r") == ["regional"]

    def test_i_prefix(self) -> None:
        assert complete_category("i") == ["industry"]

    def test_c_prefix(self) -> None:
        assert complete_category("c") == ["cis"]

    def test_empty(self) -> None:
        assert complete_category("") == ["global", "regional", "industry", "cis"]

    def test_no_match(self) -> None:
        assert complete_category("z") == []
