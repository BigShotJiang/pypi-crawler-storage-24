"""Tests for generator base classes."""

from __future__ import annotations

from typing import TYPE_CHECKING

import pytest

from complyform.core.generators.base import GenerationResult, PolicyGenerator

if TYPE_CHECKING:
    from pathlib import Path


class TestGenerationResult:
    """GenerationResult dataclass tests."""

    def test_creation(self, tmp_path: Path) -> None:
        result = GenerationResult(
            format="opa",
            files_written=[tmp_path / "test.rego"],
            artifact_count=1,
            output_dir=tmp_path,
        )
        assert result.format == "opa"
        assert result.artifact_count == 1
        assert len(result.files_written) == 1
        assert result.metadata == {}

    def test_with_metadata(self, tmp_path: Path) -> None:
        result = GenerationResult(
            format="checkov",
            files_written=[],
            artifact_count=0,
            output_dir=tmp_path,
            metadata={"key": "value"},
        )
        assert result.metadata == {"key": "value"}

    def test_serialization(self, tmp_path: Path) -> None:
        result = GenerationResult(
            format="opa",
            files_written=[tmp_path / "a.rego", tmp_path / "b.rego"],
            artifact_count=2,
            output_dir=tmp_path,
        )
        assert result.format == "opa"
        assert result.artifact_count == 2


class TestPolicyGeneratorABC:
    """PolicyGenerator ABC cannot be instantiated."""

    def test_cannot_instantiate(self) -> None:
        with pytest.raises(TypeError):
            PolicyGenerator()  # type: ignore[abstract]
