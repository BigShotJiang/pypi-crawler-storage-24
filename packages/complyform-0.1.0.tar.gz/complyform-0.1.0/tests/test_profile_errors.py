"""Tests for error classes #47 and #50 — instantiation and display()."""

from __future__ import annotations

from io import StringIO

from rich.console import Console

from complyform.core.errors import ProfileBundleVersionError, UnknownFrameworkError


class TestProfileBundleVersionError:
    def test_instantiation(self) -> None:
        err = ProfileBundleVersionError("2.0", "1.5.0", "1.2.0")
        assert err.title == "Profile Bundle Version Mismatch"
        assert "v2.0" in err.message
        assert "v1.5.0" in err.message
        assert "v1.2.0" in err.message
        assert "Upgrade" in err.fix

    def test_display(self) -> None:
        err = ProfileBundleVersionError("2.0", "1.5.0", "1.2.0")
        buf = StringIO()
        console = Console(file=buf, stderr=True, force_terminal=True)
        err.display(console)
        output = buf.getvalue()
        assert "Profile Bundle Version Mismatch" in output
        assert "v2.0" in output

    def test_is_complyform_error(self) -> None:
        from complyform.core.errors import ComplyFormError

        err = ProfileBundleVersionError("2.0", "1.5.0", "1.2.0")
        assert isinstance(err, ComplyFormError)
        assert isinstance(err, Exception)

    def test_str(self) -> None:
        err = ProfileBundleVersionError("2.0", "1.5.0", "1.2.0")
        assert "v2.0" in str(err)


class TestUnknownFrameworkError:
    def test_instantiation(self) -> None:
        err = UnknownFrameworkError(["bad_fw"], ["soc2", "hipaa"])
        assert err.title == "Unknown Framework"
        assert "bad_fw" in err.message
        assert "frameworks list" in err.fix
        assert "soc2" in err.hint

    def test_display(self) -> None:
        err = UnknownFrameworkError(["bad_fw"], ["soc2"])
        buf = StringIO()
        console = Console(file=buf, stderr=True, force_terminal=True)
        err.display(console)
        output = buf.getvalue()
        assert "Unknown Framework" in output
        assert "bad_fw" in output

    def test_multiple_ids(self) -> None:
        err = UnknownFrameworkError(["fw1", "fw2"], ["soc2"])
        assert "fw1" in err.message
        assert "fw2" in err.message

    def test_is_complyform_error(self) -> None:
        from complyform.core.errors import ComplyFormError

        err = UnknownFrameworkError(["x"], ["soc2"])
        assert isinstance(err, ComplyFormError)

    def test_str(self) -> None:
        err = UnknownFrameworkError(["test_fw"], ["soc2"])
        assert "test_fw" in str(err)
