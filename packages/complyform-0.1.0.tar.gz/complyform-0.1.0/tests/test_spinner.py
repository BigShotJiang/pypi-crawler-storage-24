"""Tests for complyform.cli.spinner."""

from __future__ import annotations

from rich.spinner import SPINNERS  # type: ignore[attr-defined]


class TestSpinner:
    def test_registered(self) -> None:
        from complyform.cli import spinner as _  # noqa: F401

        assert "complyform" in SPINNERS

    def test_frame_count(self) -> None:
        from complyform.cli.spinner import CF_SPINNER_FRAMES

        assert len(CF_SPINNER_FRAMES) == 30

    def test_interval(self) -> None:
        from complyform.cli import spinner as _  # noqa: F401

        assert SPINNERS["complyform"]["interval"] == 80

    def test_first_and_last_frame(self) -> None:
        from complyform.cli.spinner import CF_SPINNER_FRAMES

        assert CF_SPINNER_FRAMES[0] == "CF"
        assert CF_SPINNER_FRAMES[-1] == "CF"
