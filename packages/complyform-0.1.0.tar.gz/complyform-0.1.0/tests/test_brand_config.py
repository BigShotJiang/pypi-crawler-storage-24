"""Tests for brand_config module."""

from __future__ import annotations

from pathlib import Path  # noqa: TC003 — pytest fixtures need runtime

import pytest
from pydantic import ValidationError

from complyform.reporting.brand_config import BrandConfig, load_brand_config


def test_load_valid_brand_config(tmp_path: Path) -> None:
    """All fields populated — loads successfully."""
    logo = tmp_path / "logo.png"
    logo.write_bytes(b"\x89PNG" + b"\x00" * 100)

    brand_yaml = tmp_path / "brand.yaml"
    brand_yaml.write_text(
        """\
company_name: Acme Corp
logo_path: logo.png
primary_color: "#1a56db"
accent_color: "#6366f1"
contact_email: admin@acme.com
contact_phone: "+1-555-0100"
website: https://acme.com
report_footer: "Confidential — Acme Corp"
cover_page_title: "Quarterly Compliance Report"
""",
        encoding="utf-8",
    )

    config = load_brand_config(brand_yaml)

    assert config.company_name == "Acme Corp"
    assert config.logo_path is not None
    assert config.logo_path.exists()
    assert config.primary_color == "#1a56db"
    assert config.accent_color == "#6366f1"
    assert config.contact_email == "admin@acme.com"
    assert config.contact_phone == "+1-555-0100"
    assert config.website == "https://acme.com"
    assert config.report_footer == "Confidential — Acme Corp"
    assert config.cover_page_title == "Quarterly Compliance Report"


def test_load_minimal_brand_config(tmp_path: Path) -> None:
    """Only company_name provided — defaults are None."""
    brand_yaml = tmp_path / "brand.yaml"
    brand_yaml.write_text("company_name: MinimalCo\n", encoding="utf-8")

    config = load_brand_config(brand_yaml)

    assert config.company_name == "MinimalCo"
    assert config.logo_path is None
    assert config.primary_color is None
    assert config.accent_color is None
    assert config.contact_email is None


def test_brand_config_invalid_color() -> None:
    """Rejects invalid hex color like #GGGGGG."""
    with pytest.raises(ValidationError, match="Invalid hex color"):
        BrandConfig(company_name="Test", primary_color="#GGGGGG")


def test_brand_config_missing_company_name() -> None:
    """Raises ValidationError when company_name is missing."""
    with pytest.raises(ValidationError):
        BrandConfig()  # type: ignore[call-arg]


def test_brand_config_logo_not_found(tmp_path: Path) -> None:
    """Raises ValidationError when logo file does not exist."""
    brand_yaml = tmp_path / "brand.yaml"
    brand_yaml.write_text(
        "company_name: Test\nlogo_path: /nonexistent/logo.png\n",
        encoding="utf-8",
    )

    with pytest.raises((ValidationError, ValueError), match="not found"):
        load_brand_config(brand_yaml)


def test_brand_config_logo_too_large(tmp_path: Path) -> None:
    """Logo > 2MB raises ValidationError."""
    logo = tmp_path / "big.png"
    logo.write_bytes(b"\x89PNG" + b"\x00" * (3 * 1024 * 1024))

    brand_yaml = tmp_path / "brand.yaml"
    brand_yaml.write_text(
        "company_name: Test\nlogo_path: big.png\n",
        encoding="utf-8",
    )

    with pytest.raises((ValidationError, ValueError), match="too large"):
        load_brand_config(brand_yaml)


def test_brand_config_logo_invalid_extension(
    tmp_path: Path,
) -> None:
    """Rejects .gif logo extension."""
    logo = tmp_path / "logo.gif"
    logo.write_bytes(b"GIF89a" + b"\x00" * 100)

    with pytest.raises(ValidationError, match="Unsupported logo format"):
        BrandConfig(company_name="Test", logo_path=logo)
