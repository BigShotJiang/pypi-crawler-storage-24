"""CLI integration tests for the fix command."""

from __future__ import annotations

from unittest.mock import patch

from typer.testing import CliRunner

from complyform.cli.main import app

runner = CliRunner()


class TestFixStubFlags:
    def test_estimate_cost_stub(self) -> None:
        result = runner.invoke(app, ["fix", "--estimate-cost"])
        assert result.exit_code == 0
        assert "future release" in result.output.lower()

    def test_iam_analysis_stub(self) -> None:
        result = runner.invoke(app, ["fix", "--iam-analysis"])
        assert result.exit_code == 0
        assert "future release" in result.output.lower()


class TestFixNoCachedAssessment:
    def test_no_cache_raises(self) -> None:
        with patch("complyform.cli.remediate_cmd.ScanCache") as mock_cache:
            mock_cache.return_value.latest.return_value = None
            result = runner.invoke(app, ["fix"])
            assert result.exit_code != 0


class TestFixDryRun:
    def test_dry_run_skips_validate(self) -> None:
        from complyform.core.assessor.control_matcher import (
            Finding,
        )
        from complyform.core.profiles.models import (
            MappingFile,
            ResourceMapping,
        )
        from complyform.core.scanner.state_parser import (
            ResourceRecord,
        )

        resources = [
            ResourceRecord(
                provider="google",
                resource_type="google_sql_database_instance",
                name="main",
                address="google_sql_database_instance.main",
                attributes={
                    "id": "test",
                    "name": "main",
                    "project": "proj",
                },
                module=None,
                source_state="test",
            )
        ]
        meta = {
            "cloud": "gcp",
            "state_hash": "sha256:abc",
            "provider_versions": {},
        }
        findings = [
            Finding(
                control_id="CC6.1",
                framework="soc2",
                resource_address=("google_sql_database_instance.main"),
                resource_type=("google_sql_database_instance"),
                status="FAIL",
                severity="HIGH",
                finding="fail",
                remediation="fix",
                checkov_id="CKV_GCP_6",
                cross_mappings=None,
                native_ids=None,
                confidence="high",
            )
        ]
        rm = ResourceMapping(
            check_id="CKV_GCP_6",
            control_id="CC6.1",
            resource_types=["google_sql_database_instance"],
            required_config={"ssl": True},
        )
        mf = MappingFile(
            schema_version=1,
            framework_id="soc2",
            cloud="gcp",
            mappings=[rm],
        )

        with (
            patch("complyform.cli.remediate_cmd.ScanCache") as mock_cache,
            patch(
                "complyform.cli.remediate_cmd._load_findings",
                return_value=findings,
            ),
            patch(
                "complyform.core.profiles.mapping_loader.load_mappings",
                return_value=mf,
            ),
        ):
            mock_cache.return_value.latest.return_value = (
                resources,
                meta,
            )
            result = runner.invoke(app, ["fix", "--dry-run"])
            assert result.exit_code == 0
