"""Tests for CLI data export/delete commands."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import typer
from typer.testing import CliRunner

runner = CliRunner()


def _make_test_app() -> typer.Typer:
    """Create a minimal typer app with data commands."""
    app = typer.Typer()

    @app.command(name="export-data")
    def _export(ctx: typer.Context) -> None:
        from complyform.cli.data_cmd import export_data_cmd

        export_data_cmd(ctx)

    @app.command(name="delete-data")
    def _delete(
        ctx: typer.Context,
        confirm: bool = typer.Option(False, "--confirm"),
    ) -> None:
        from complyform.cli.data_cmd import delete_data_cmd

        delete_data_cmd(ctx, confirm=confirm)

    return app


class TestExportDataCmd:
    def test_export_data_cmd_success(self) -> None:
        """Export command calls API endpoint."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "status": "export_started",
            "estimated_minutes": 5,
        }
        mock_response.raise_for_status = MagicMock()

        mock_client_inst = MagicMock()
        mock_client_inst.post.return_value = mock_response
        mock_client_inst.__enter__ = MagicMock(return_value=mock_client_inst)
        mock_client_inst.__exit__ = MagicMock(return_value=False)

        with (
            patch(
                "httpx.Client",
                return_value=mock_client_inst,
            ),
            patch(
                "complyform.cli.data_cmd._resolve_api_key",
                return_value="cf_live_test123",
            ),
        ):
            app = _make_test_app()
            result = runner.invoke(app, ["export-data"])

        assert result.exit_code == 0


class TestDeleteDataCmd:
    def test_delete_data_cmd_requires_confirm_noninteractive(
        self,
    ) -> None:
        """No --confirm in non-TTY -> error."""
        with patch(
            "complyform.cli.data_cmd._resolve_api_key",
            return_value="cf_live_test123",
        ):
            app = _make_test_app()
            result = runner.invoke(app, ["delete-data"])

        assert result.exit_code == 1

    def test_delete_data_cmd_with_confirm(self) -> None:
        """--confirm -> sends DELETE request."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "status": "deletion_started",
        }
        mock_response.raise_for_status = MagicMock()

        mock_client_inst = MagicMock()
        mock_client_inst.post.return_value = mock_response
        mock_client_inst.__enter__ = MagicMock(return_value=mock_client_inst)
        mock_client_inst.__exit__ = MagicMock(return_value=False)

        with (
            patch(
                "httpx.Client",
                return_value=mock_client_inst,
            ),
            patch(
                "complyform.cli.data_cmd._resolve_api_key",
                return_value="cf_live_test123",
            ),
        ):
            app = _make_test_app()
            result = runner.invoke(app, ["delete-data", "--confirm"])

        assert result.exit_code == 0
