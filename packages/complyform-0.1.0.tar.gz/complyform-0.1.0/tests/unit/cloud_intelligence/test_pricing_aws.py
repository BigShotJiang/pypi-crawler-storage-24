"""Tests for AWS pricing API client."""

from __future__ import annotations

import json
from unittest.mock import MagicMock, patch

from complyform.core.cloud_intelligence.pricing_aws import get_aws_supplemental_costs


class TestAWSPricing:
    def test_successful_response(self) -> None:
        price_data = json.dumps(
            {
                "terms": {
                    "OnDemand": {
                        "term1": {
                            "priceDimensions": {
                                "dim1": {"pricePerUnit": {"USD": "1.00"}}
                            }
                        }
                    }
                }
            }
        )
        mock_client = MagicMock()
        mock_client.get_products.return_value = {"PriceList": [price_data]}

        with patch("boto3.client", return_value=mock_client):
            items = get_aws_supplemental_costs("us-east-1")
        assert len(items) >= 1
        assert items[0].source == "pricing_api"

    def test_api_failure_returns_empty(self) -> None:
        with patch("boto3.client", side_effect=Exception("error")):
            items = get_aws_supplemental_costs("us-east-1")
        assert items == []

    def test_no_boto3_returns_empty(self) -> None:
        with (
            patch.dict("sys.modules", {"boto3": None}),
            patch("builtins.__import__", side_effect=ImportError),
        ):
            items = get_aws_supplemental_costs("us-east-1")
        assert items == []
