"""Tests for Azure Defender cross-validator."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

from complyform.core.cloud_intelligence.xval_azure import AzureCrossValidator


class TestAzureCrossValidator:
    def test_analyze_no_sdk(self) -> None:
        validator = AzureCrossValidator("azure", "sub-123")
        with patch("builtins.__import__", side_effect=ImportError):
            result = validator.analyze()
        assert result.success is False

    def test_never_raises(self) -> None:
        validator = AzureCrossValidator("azure", "sub-123")
        with patch(
            "complyform.core.cloud_intelligence.xval_azure.AzureCrossValidator.analyze"
        ) as mock:
            mock.return_value = MagicMock(success=False, error="test")
            result = validator.analyze()
            assert result.success is False

    def test_check_prerequisites_no_sdk(self) -> None:
        validator = AzureCrossValidator("azure", "sub-123")
        with (
            patch.dict("sys.modules", {"azure.mgmt.security": None}),
            patch("builtins.__import__", side_effect=ImportError),
        ):
            issues = validator.check_prerequisites()
        assert len(issues) >= 1

    def test_stores_complyform_findings(self) -> None:
        findings = [MagicMock()]
        validator = AzureCrossValidator("azure", "sub", complyform_findings=findings)
        assert validator.complyform_findings == findings
