"""Tests for landing zone dispatcher and data model."""

from __future__ import annotations

from unittest.mock import patch

from complyform.core.scanner.landing_zone import (
    LandingZoneContext,
    detect_landing_zone,
)


class TestLandingZoneContext:
    def test_seven_fields(self) -> None:
        lz = LandingZoneContext(
            cloud="gcp",
            detected=True,
            type="assured_workloads",
            inherited_policies=["p1"],
            compliance_regime="fedramp",
            hierarchy_path=["/orgs/123"],
            drift_risk_policies=[],
        )
        assert lz.cloud == "gcp"
        assert lz.detected is True
        assert lz.type == "assured_workloads"
        assert lz.inherited_policies == ["p1"]
        assert lz.compliance_regime == "fedramp"
        assert lz.hierarchy_path == ["/orgs/123"]
        assert lz.drift_risk_policies == []

    def test_defaults(self) -> None:
        lz = LandingZoneContext(cloud="aws", detected=False, type=None)
        assert lz.inherited_policies == []
        assert lz.compliance_regime is None
        assert lz.hierarchy_path == []
        assert lz.drift_risk_policies == []


class TestDetectLandingZone:
    def test_gcp_dispatches(self) -> None:
        expected = LandingZoneContext(
            cloud="gcp", detected=True, type="assured_workloads"
        )
        with patch(
            "complyform.core.scanner.landing_zone_gcp.detect_gcp_landing_zone",
            return_value=expected,
        ):
            result = detect_landing_zone("gcp", "proj-1")
        assert result.detected is True
        assert result.type == "assured_workloads"

    def test_aws_dispatches(self) -> None:
        expected = LandingZoneContext(cloud="aws", detected=True, type="control_tower")
        with patch(
            "complyform.core.scanner.landing_zone_aws.detect_aws_landing_zone",
            return_value=expected,
        ):
            result = detect_landing_zone("aws", "123456789")
        assert result.detected is True
        assert result.type == "control_tower"

    def test_azure_dispatches(self) -> None:
        expected = LandingZoneContext(cloud="azure", detected=True, type="alz")
        with patch(
            "complyform.core.scanner.landing_zone_azure.detect_azure_landing_zone",
            return_value=expected,
        ):
            result = detect_landing_zone("azure", "sub-123")
        assert result.detected is True
        assert result.type == "alz"

    def test_unknown_cloud(self) -> None:
        result = detect_landing_zone("unknown", "id-1")
        assert result.detected is False

    def test_exception_returns_not_detected(self) -> None:
        with patch(
            "complyform.core.scanner.landing_zone_gcp.detect_gcp_landing_zone",
            side_effect=RuntimeError("boom"),
        ):
            result = detect_landing_zone("gcp", "proj-1")
        assert result.detected is False
