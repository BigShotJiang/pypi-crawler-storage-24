"""Tests for GCP pricing API client."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

from complyform.core.cloud_intelligence.pricing_gcp import get_gcp_supplemental_costs


class TestGCPPricing:
    def test_successful_response(self) -> None:
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "skus": [
                {
                    "description": "Active CMEK key versions",
                    "pricingInfo": [
                        {
                            "pricingExpression": {
                                "tieredRates": [
                                    {
                                        "unitPrice": {
                                            "units": "1",
                                            "nanos": 0,
                                        }
                                    }
                                ]
                            }
                        }
                    ],
                }
            ]
        }
        mock_response.raise_for_status = MagicMock()
        with patch("httpx.get", return_value=mock_response):
            items = get_gcp_supplemental_costs("us-east1")
        assert len(items) >= 1
        assert items[0].source == "pricing_api"

    def test_api_failure_returns_empty(self) -> None:
        with patch("httpx.get", side_effect=Exception("network error")):
            items = get_gcp_supplemental_costs("us-east1")
        assert items == []

    def test_no_httpx_returns_empty(self) -> None:
        with (
            patch.dict("sys.modules", {"httpx": None}),
            patch("builtins.__import__", side_effect=ImportError),
        ):
            items = get_gcp_supplemental_costs("us-east1")
        assert items == []
