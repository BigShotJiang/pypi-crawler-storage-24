"""Tests for Azure ALZ/SLZ landing zone detection."""

from __future__ import annotations

import importlib
import sys
from unittest.mock import MagicMock, patch


def _setup_azure_mocks():
    """Create and install mock Azure SDK modules, return key mocks."""
    mock_resource = MagicMock()
    mock_resourcegraph = MagicMock()
    mock_resourcegraph_models = MagicMock()

    mock_ResourceGraphClient = MagicMock()
    mock_QueryRequest = MagicMock()

    mock_resourcegraph.ResourceGraphClient = mock_ResourceGraphClient
    mock_resourcegraph_models.QueryRequest = mock_QueryRequest

    modules = {
        "azure": MagicMock(),
        "azure.mgmt": MagicMock(),
        "azure.mgmt.resource": mock_resource,
        "azure.mgmt.resourcegraph": mock_resourcegraph,
        "azure.mgmt.resourcegraph.models": mock_resourcegraph_models,
        "httpx": MagicMock(),
    }
    return modules, mock_ResourceGraphClient, mock_QueryRequest


class TestAzureLandingZone:
    def test_no_httpx(self) -> None:
        from complyform.core.scanner.landing_zone_azure import (
            detect_azure_landing_zone,
        )

        with patch("builtins.__import__", side_effect=ImportError):
            result = detect_azure_landing_zone("sub-123", None)
        assert result.detected is False

    def test_three_standard_names_detected(self) -> None:
        modules, mock_RGClient, mock_QR = _setup_azure_mocks()

        mock_rg_client = MagicMock()
        mock_RGClient.return_value = mock_rg_client

        mg_result = MagicMock()
        mg_result.data = [
            {"name": "mg-platform", "properties_displayName": "Platform"},
            {"name": "mg-lz", "properties_displayName": "Landing Zones"},
            {"name": "mg-conn", "properties_displayName": "Connectivity"},
        ]
        policy_result = MagicMock()
        policy_result.data = [
            {
                "name": "p1",
                "properties_displayName": "Allowed Locations",
                "properties_enforcementMode": "Default",
                "properties_policyDefinitionId": (
                    "/providers/Microsoft.Authorization/policyDefinitions/xxx"
                ),
            }
        ]
        mock_rg_client.resources.side_effect = [mg_result, policy_result]

        with patch.dict(sys.modules, modules):
            import complyform.core.scanner.landing_zone_azure as mod

            importlib.reload(mod)
            result = mod.detect_azure_landing_zone("sub-123", MagicMock())

        assert result.detected is True
        assert result.type == "alz"
        assert "Allowed Locations" in result.inherited_policies

    def test_fewer_than_three_names_not_detected(self) -> None:
        modules, mock_RGClient, mock_QR = _setup_azure_mocks()

        mock_rg_client = MagicMock()
        mock_RGClient.return_value = mock_rg_client

        mg_result = MagicMock()
        mg_result.data = [
            {"name": "mg-platform", "properties_displayName": "Platform"},
            {"name": "mg-custom", "properties_displayName": "Custom"},
        ]
        mock_rg_client.resources.return_value = mg_result

        with patch.dict(sys.modules, modules):
            import complyform.core.scanner.landing_zone_azure as mod

            importlib.reload(mod)
            result = mod.detect_azure_landing_zone("sub-123", MagicMock())

        assert result.detected is False

    def test_api_error_returns_not_detected(self) -> None:
        modules, mock_RGClient, mock_QR = _setup_azure_mocks()
        mock_RGClient.side_effect = Exception("boom")

        with patch.dict(sys.modules, modules):
            import complyform.core.scanner.landing_zone_azure as mod

            importlib.reload(mod)
            result = mod.detect_azure_landing_zone("sub-123", MagicMock())

        assert result.detected is False
