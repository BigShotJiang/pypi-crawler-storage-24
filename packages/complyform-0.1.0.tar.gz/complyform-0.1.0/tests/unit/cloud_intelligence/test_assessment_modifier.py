"""Tests for assessment modifier."""

from __future__ import annotations

import complyform.core.cloud_intelligence.assessment_modifier as _am_mod
from complyform.core.assessor.control_matcher import Finding
from complyform.core.cloud_intelligence.assessment_modifier import (
    apply_landing_zone_context,
)
from complyform.core.scanner.landing_zone import LandingZoneContext


def _make_finding(
    control_id: str = "Art.44",
    framework: str = "gdpr",
    status: str = "FAIL",
) -> Finding:
    return Finding(
        control_id=control_id,
        framework=framework,
        resource_address="google_compute_instance.vm1",
        resource_type="google_compute_instance",
        status=status,
        severity="HIGH",
        finding="Test finding",
        remediation="Fix it",
        checkov_id="CKV_GCP_1",
        cross_mappings=None,
        native_ids=None,
        confidence="high",
    )


class TestApplyLandingZoneContext:
    def setup_method(self) -> None:
        # Reset cached mappings so each test reloads from disk
        _am_mod.LANDING_ZONE_CONTROL_MAP = {}

    def test_matching_control_set_to_pass(self) -> None:
        findings = [_make_finding(control_id="Art.44", framework="gdpr")]
        lz = LandingZoneContext(
            cloud="gcp",
            detected=True,
            type="assured_workloads",
            inherited_policies=["constraints/gcp.resourceLocations"],
        )
        modified, skipped = apply_landing_zone_context(findings, lz)
        assert skipped == 1
        assert modified[0].status == "PASS"
        assert "Enforced by" in modified[0].finding

    def test_unmatched_control_unchanged(self) -> None:
        findings = [_make_finding(control_id="CC6.6", framework="soc2")]
        lz = LandingZoneContext(
            cloud="gcp",
            detected=True,
            type="assured_workloads",
            inherited_policies=["constraints/gcp.resourceLocations"],
        )
        modified, skipped = apply_landing_zone_context(findings, lz)
        assert skipped == 0
        assert modified[0].status == "FAIL"

    def test_not_detected_no_changes(self) -> None:
        findings = [_make_finding()]
        lz = LandingZoneContext(cloud="gcp", detected=False, type=None)
        modified, skipped = apply_landing_zone_context(findings, lz)
        assert skipped == 0
        assert modified == findings

    def test_empty_inherited_policies_no_changes(self) -> None:
        findings = [_make_finding()]
        lz = LandingZoneContext(
            cloud="gcp",
            detected=True,
            type="assured_workloads",
            inherited_policies=[],
        )
        modified, skipped = apply_landing_zone_context(findings, lz)
        assert skipped == 0

    def test_skipped_count_correct(self) -> None:
        findings = [
            _make_finding(control_id="Art.44", framework="gdpr"),
            _make_finding(control_id="Art.21", framework="nis2"),
            _make_finding(control_id="CC6.6", framework="soc2"),
        ]
        lz = LandingZoneContext(
            cloud="gcp",
            detected=True,
            type="assured_workloads",
            inherited_policies=["constraints/gcp.resourceLocations"],
        )
        modified, skipped = apply_landing_zone_context(findings, lz)
        assert skipped == 2
        assert len(modified) == 3

    def test_yaml_loads_correctly(self) -> None:
        from pathlib import Path

        import yaml

        yaml_path = (
            Path(__file__).resolve().parent.parent.parent.parent
            / "profiles"
            / "landing_zone_mappings.yaml"
        )
        if yaml_path.exists():
            data = yaml.safe_load(yaml_path.read_text())
            assert "assured_workloads" in data
            assert "control_tower" in data
            assert "alz" in data
            assert "slz" in data
