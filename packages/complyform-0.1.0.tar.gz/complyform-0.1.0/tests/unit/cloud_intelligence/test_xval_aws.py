"""Tests for AWS Security Hub cross-validator."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

from complyform.core.cloud_intelligence.xval_aws import AWSCrossValidator


class TestAWSCrossValidator:
    def test_analyze_no_boto3(self) -> None:
        validator = AWSCrossValidator("aws", "123456789")
        with patch("builtins.__import__", side_effect=ImportError):
            result = validator.analyze()
        assert result.success is False

    def test_never_raises(self) -> None:
        validator = AWSCrossValidator("aws", "123456789")
        with patch(
            "complyform.core.cloud_intelligence.xval_aws.AWSCrossValidator.analyze"
        ) as mock:
            mock.return_value = MagicMock(success=False, error="test")
            result = validator.analyze()
            assert result.success is False

    def test_check_prerequisites_no_boto3(self) -> None:
        validator = AWSCrossValidator("aws", "123456789")
        with (
            patch.dict("sys.modules", {"boto3": None}),
            patch("builtins.__import__", side_effect=ImportError),
        ):
            issues = validator.check_prerequisites()
        assert len(issues) >= 1

    def test_stores_complyform_findings(self) -> None:
        findings = [MagicMock()]
        validator = AWSCrossValidator("aws", "acct", complyform_findings=findings)
        assert validator.complyform_findings == findings
