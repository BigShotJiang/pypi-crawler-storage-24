"""Tests for cost impact estimator."""

from __future__ import annotations

from unittest.mock import patch

from complyform.core.cloud_intelligence.cost_estimator import (
    CostImpactEstimate,
    CostLineItem,
    estimate_cost_impact,
)


class TestCostImpactEstimate:
    def test_annual_is_monthly_times_12(self) -> None:
        est = CostImpactEstimate(
            feature="cost_impact",
            cloud="aws",
            success=True,
            error=None,
            duration_ms=0,
            timestamp="",
            total_monthly_delta=100.0,
            total_annual_delta=1200.0,
        )
        assert est.total_annual_delta == est.total_monthly_delta * 12

    def test_default_confidence(self) -> None:
        est = CostImpactEstimate(
            feature="cost_impact",
            cloud="aws",
            success=True,
            error=None,
            duration_ms=0,
            timestamp="",
        )
        assert est.confidence == "estimated"


class TestEstimateCostImpact:
    @patch("complyform.core.cloud_intelligence.cost_estimator.CostLineItem")
    def test_no_infracost_estimated_confidence(self, _: object) -> None:
        with patch(
            "complyform.core.cloud_intelligence.pricing_aws.get_aws_supplemental_costs",
            return_value=[],
        ):
            result = estimate_cost_impact("aws", tf_path=None)
        assert result.confidence == "estimated"
        assert result.infracost_available is False

    def test_infracost_available_high_confidence(self) -> None:
        mock_result = {
            "projects": [
                {
                    "breakdown": {
                        "resources": [
                            {"name": "aws_kms_key.main", "monthlyCost": "1.00"}
                        ]
                    }
                }
            ]
        }
        with (
            patch(
                "complyform.core.cloud_intelligence.infracost_runner.run_infracost_breakdown",
                return_value=mock_result,
            ),
            patch(
                "complyform.core.cloud_intelligence.pricing_aws.get_aws_supplemental_costs",
                return_value=[],
            ),
        ):
            result = estimate_cost_impact("aws", tf_path="/tmp/tf")
        assert result.infracost_available is True
        assert result.confidence == "high"

    def test_infracost_plus_supplemental_medium(self) -> None:
        mock_result = {
            "projects": [
                {
                    "breakdown": {
                        "resources": [
                            {"name": "aws_kms_key.main", "monthlyCost": "1.00"}
                        ]
                    }
                }
            ]
        }
        supplemental = [
            CostLineItem(
                category="logging",
                description="test",
                monthly_cost=5.0,
                resource_count=1,
                source="pricing_api",
            )
        ]
        with (
            patch(
                "complyform.core.cloud_intelligence.infracost_runner.run_infracost_breakdown",
                return_value=mock_result,
            ),
            patch(
                "complyform.core.cloud_intelligence.pricing_aws.get_aws_supplemental_costs",
                return_value=supplemental,
            ),
        ):
            result = estimate_cost_impact("aws", tf_path="/tmp/tf")
        assert result.confidence == "medium"

    def test_pricing_api_failure_still_returns(self) -> None:
        with patch(
            "complyform.core.cloud_intelligence.pricing_gcp.get_gcp_supplemental_costs",
            side_effect=Exception("API error"),
        ):
            result = estimate_cost_impact("gcp", tf_path=None)
        assert result.success is True
        assert result.confidence == "estimated"
