"""Tests for resource ID normalizers."""

from __future__ import annotations

from complyform.core.cloud_intelligence.resource_normalizers import (
    normalize_azure_resource,
    normalize_scc_resource,
    normalize_security_hub_resource,
)


class TestNormalizeSCCResource:
    def test_compute_instance(self) -> None:
        result = normalize_scc_resource(
            "//compute.googleapis.com/projects/p/zones/z/instances/vm1"
        )
        assert result == "google_compute_instance.vm1"

    def test_sql_instance(self) -> None:
        result = normalize_scc_resource(
            "//sqladmin.googleapis.com/projects/p/instances/mydb"
        )
        assert result == "google_sql_database_instance.mydb"

    def test_storage_bucket(self) -> None:
        result = normalize_scc_resource(
            "//storage.googleapis.com/projects/p/buckets/mybucket"
        )
        assert result == "google_storage_bucket.mybucket"

    def test_unknown_service(self) -> None:
        result = normalize_scc_resource("//unknown.googleapis.com/projects/p/things/t1")
        assert result is None

    def test_malformed_input(self) -> None:
        assert normalize_scc_resource("not-a-resource-name") is None

    def test_empty_string(self) -> None:
        assert normalize_scc_resource("") is None


class TestNormalizeSecurityHubResource:
    def test_rds_instance(self) -> None:
        result = normalize_security_hub_resource(
            "arn:aws:rds:us-east-1:123456789:db:mydb",
            "AwsRdsDbInstance",
        )
        assert result == "aws_db_instance.mydb"

    def test_s3_bucket(self) -> None:
        result = normalize_security_hub_resource(
            "arn:aws:s3:::my-bucket",
            "AwsS3Bucket",
        )
        assert result == "aws_s3_bucket.my-bucket"

    def test_ec2_instance(self) -> None:
        result = normalize_security_hub_resource(
            "arn:aws:ec2:us-east-1:123456789:instance/i-12345",
            "AwsEc2Instance",
        )
        assert result == "aws_instance.i-12345"

    def test_unknown_type(self) -> None:
        result = normalize_security_hub_resource(
            "arn:aws:foo:us-east-1:123:bar/baz",
            "UnknownType",
        )
        assert result is None

    def test_iam_role(self) -> None:
        result = normalize_security_hub_resource(
            "arn:aws:iam::123456789:role/my-role",
            "AwsIamRole",
        )
        assert result == "aws_iam_role.my-role"


class TestNormalizeAzureResource:
    def test_sql_server(self) -> None:
        result = normalize_azure_resource(
            "/subscriptions/sub1/resourceGroups/rg1/providers/Microsoft.Sql/servers/mydb"
        )
        assert result == "azurerm_mssql_server.mydb"

    def test_storage_account(self) -> None:
        result = normalize_azure_resource(
            "/subscriptions/sub1/resourceGroups/rg1/providers/Microsoft.Storage/storageAccounts/mystorage"
        )
        assert result == "azurerm_storage_account.mystorage"

    def test_unknown_provider(self) -> None:
        result = normalize_azure_resource(
            "/subscriptions/sub1/resourceGroups/rg1/providers/Microsoft.Unknown/things/t1"
        )
        assert result is None

    def test_malformed_input(self) -> None:
        assert normalize_azure_resource("not-a-resource-id") is None

    def test_key_vault(self) -> None:
        result = normalize_azure_resource(
            "/subscriptions/sub1/resourceGroups/rg1/providers/Microsoft.KeyVault/vaults/myvault"
        )
        assert result == "azurerm_key_vault.myvault"
