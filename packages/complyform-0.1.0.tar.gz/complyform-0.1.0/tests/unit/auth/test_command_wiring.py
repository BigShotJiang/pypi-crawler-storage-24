"""Tests for tier enforcement wiring in CLI commands."""

from __future__ import annotations

import pytest

from complyform.core.auth.tier_config import TIER_CONFIG
from complyform.core.auth.tier_enforcement import TierInfo
from complyform.core.errors import (
    FeatureNotAvailableError,
    RemediationTierError,
    ScanSourceTierError,
)


def _community_tier_info() -> TierInfo:
    cfg = TIER_CONFIG["community"]

    def _sl(v: object) -> list[str]:
        return [str(x) for x in v] if isinstance(v, list) else []

    def _oi(v: object) -> int | None:
        return v if isinstance(v, int) else None

    return TierInfo(
        tier="community",
        assess_frameworks=_sl(cfg["assess_frameworks"]),
        remediate_frameworks=_sl(cfg["remediate_frameworks"]),
        features=_sl(cfg["features"]),
        scan_sources=_sl(cfg["scan_sources"]),
        project_limit=_oi(cfg["project_limit"]),
        batch_limit=_oi(cfg["batch_limit"]),
        discover_limit=_oi(cfg["discover_limit"]),
        expires_at=None,
    )


class TestRemediateWiring:
    def test_community_soc2_passes(self) -> None:
        """Community can remediate free frameworks."""
        from complyform.core.auth.tier_enforcement import check_framework_access

        ti = _community_tier_info()
        check_framework_access(["soc2"], "remediate", ti)

    def test_community_hipaa_blocked(self) -> None:
        """Community blocked from remediating hipaa."""
        from complyform.core.auth.tier_enforcement import check_framework_access

        ti = _community_tier_info()
        with pytest.raises(RemediationTierError):
            check_framework_access(["hipaa"], "remediate", ti)


class TestAssessWiring:
    def test_community_any_framework_passes(self) -> None:
        """Assess is always free for all 53 frameworks."""
        from complyform.core.auth.tier_enforcement import check_framework_access

        ti = _community_tier_info()
        check_framework_access(["hipaa", "fedramp", "nca_ecc"], "assess", ti)


class TestScanWiring:
    def test_community_local_state_passes(self) -> None:
        from complyform.core.auth.tier_enforcement import check_scan_source

        ti = _community_tier_info()
        check_scan_source("local_state", ti)

    def test_community_remote_blocked(self) -> None:
        from complyform.core.auth.tier_enforcement import check_scan_source

        ti = _community_tier_info()
        with pytest.raises(ScanSourceTierError):
            check_scan_source("gcs", ti)


class TestErrorRendering:
    def test_remediation_tier_error_has_pricing_url(self) -> None:
        err = RemediationTierError("hipaa", "community")
        assert "complyform.dev/pricing" in err.fix

    def test_scan_source_error_has_pricing_url(self) -> None:
        err = ScanSourceTierError("gcs", "community")
        assert "complyform.dev/pricing" in err.fix

    def test_feature_error_has_pricing_url(self) -> None:
        err = FeatureNotAvailableError("branded_pdf", "community")
        assert "complyform.dev/pricing" in err.fix

    def test_error_renders_as_panel(self) -> None:
        from io import StringIO

        from rich.console import Console

        err = RemediationTierError("hipaa", "community")
        buf = StringIO()
        console = Console(file=buf, force_terminal=True)
        err.display(console)
        output = buf.getvalue()
        assert "hipaa" in output
        assert "Tier" in output
