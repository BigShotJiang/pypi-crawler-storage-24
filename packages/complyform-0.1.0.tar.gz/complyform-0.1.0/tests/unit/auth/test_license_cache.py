"""Tests for LicenseCache model."""

from __future__ import annotations

import pytest
from pydantic import ValidationError

from complyform.core.auth.license import LicenseCache


class TestLicenseCache:
    def test_valid_construction(self) -> None:
        cache = LicenseCache(
            key_hash="sha256:abc",
            tier="pro",
            assess_frameworks=["all"],
            remediate_frameworks=["soc2"],
            features=["html_report"],
            project_limit=10,
            expires_at="2026-12-31T00:00:00+00:00",
            last_validated_at="2026-03-10T00:00:00+00:00",
        )
        assert cache.tier == "pro"
        assert cache.cache_version == 1

    def test_optional_fields_default_none(self) -> None:
        cache = LicenseCache(
            key_hash="sha256:abc",
            tier="community",
            assess_frameworks=["all"],
            remediate_frameworks=[],
            features=[],
            project_limit=None,
            expires_at=None,
            last_validated_at="2026-03-10T00:00:00+00:00",
        )
        assert cache.profile_bundle_version is None
        assert cache.api_key_hash is None
        assert cache.batch_limit is None
        assert cache.discover_limit is None
        assert cache.scan_sources is None

    def test_strict_mode_rejects_wrong_types(self) -> None:
        with pytest.raises(ValidationError):
            LicenseCache.model_validate(
                {
                    "key_hash": 123,  # wrong type: int instead of str
                    "tier": "pro",
                    "assess_frameworks": ["all"],
                    "remediate_frameworks": [],
                    "features": [],
                    "project_limit": None,
                    "expires_at": None,
                    "last_validated_at": "2026-03-10T00:00:00+00:00",
                },
                strict=True,
            )

    def test_model_dump_json(self) -> None:
        cache = LicenseCache(
            key_hash="sha256:abc",
            tier="pro",
            assess_frameworks=["all"],
            remediate_frameworks=["soc2"],
            features=[],
            project_limit=10,
            expires_at=None,
            last_validated_at="2026-03-10T00:00:00+00:00",
        )
        dumped = cache.model_dump(mode="json")
        assert dumped["tier"] == "pro"
        assert dumped["cache_version"] == 1
