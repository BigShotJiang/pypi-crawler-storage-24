"""Tests for CLI banner display."""

from __future__ import annotations

from io import StringIO

import pytest  # noqa: TC002
from rich.console import Console

from complyform.cli.banner import _BANNER_LINES, print_banner, should_show_banner


class TestBannerContent:
    """Verify banner content integrity."""

    def test_banner_has_five_lines(self) -> None:
        assert len(_BANNER_LINES) == 5

    def test_banner_contains_complyform(self) -> None:
        full = "\n".join(_BANNER_LINES)
        # The ASCII art spells "ComplyForm" — verify key fragments
        assert "___" in full
        assert "/_/" in full

    def test_banner_lines_are_consistent_width(self) -> None:
        # All lines should be roughly the same width (within 10 chars)
        widths = [len(line) for line in _BANNER_LINES]
        assert max(widths) - min(widths) <= 10


class TestPrintBanner:
    """Verify banner rendering."""

    def test_print_banner_outputs_version(self) -> None:
        buf = StringIO()
        console = Console(file=buf, force_terminal=True, width=120)
        print_banner(console, "1.2.3")
        output = buf.getvalue()
        assert "v1.2.3" in output

    def test_print_banner_outputs_all_lines(self) -> None:
        buf = StringIO()
        console = Console(file=buf, force_terminal=True, width=120)
        print_banner(console, "0.0.1")
        output = buf.getvalue()
        # Should have banner lines + version line + blank line
        lines = output.strip().split("\n")
        assert len(lines) >= 6  # 5 banner + 1 version


class TestShouldShowBanner:
    """Verify suppression logic."""

    def test_quiet_suppresses(self) -> None:
        assert should_show_banner(quiet=True) is False

    def test_non_tty_suppresses(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setattr("sys.stderr", StringIO())
        assert should_show_banner(quiet=False) is False
