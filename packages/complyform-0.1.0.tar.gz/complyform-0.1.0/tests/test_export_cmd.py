"""Tests for export CLI command."""

from __future__ import annotations

import pytest

from complyform.core.errors import (
    ExportFormatError,
    ExportNoCachedAssessmentError,
    ExportTierError,
)


class TestExportCmd:
    def test_no_cached_assessment_error(self) -> None:
        err = ExportNoCachedAssessmentError()
        assert err.error_code == 43
        assert "scan --assess" in err.fix

    def test_export_format_error(self) -> None:
        err = ExportFormatError("invalid", ["scc-json", "grc-json"])
        assert err.error_code == 39
        assert "invalid" in err.message
        assert "scc-json" in err.fix

    def test_export_tier_error(self) -> None:
        err = ExportTierError("scc-json", "evidence_export_native", "community")
        assert err.error_code == 42
        assert "community" in err.fix

    def test_format_to_feature_mapping(self) -> None:
        from complyform.core.generators.evidence_export import FORMAT_TO_FEATURE

        assert FORMAT_TO_FEATURE["scc-json"] == "evidence_export_native"
        assert FORMAT_TO_FEATURE["audit-manager"] == "evidence_export_native"
        assert FORMAT_TO_FEATURE["purview"] == "evidence_export_native"
        assert FORMAT_TO_FEATURE["grc-json"] == "evidence_export_native"
        assert FORMAT_TO_FEATURE["vanta"] == "evidence_export_grc"
        assert FORMAT_TO_FEATURE["drata"] == "evidence_export_grc"
        assert FORMAT_TO_FEATURE["secureframe"] == "evidence_export_grc"

    def test_get_exporter_unknown_format(self) -> None:
        from complyform.core.generators.evidence_export import get_exporter

        with pytest.raises(ExportFormatError):
            get_exporter("unknown_format")
