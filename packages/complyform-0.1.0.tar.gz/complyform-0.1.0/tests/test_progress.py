"""Tests for complyform.cli.progress."""

from __future__ import annotations

import contextlib
from io import StringIO
from unittest.mock import patch

from rich.console import Console
from rich.progress import Progress
from rich.status import Status

from complyform.cli.progress import create_progress, create_status


class TestCreateStatus:
    def test_quiet_returns_nullcontext(self) -> None:
        console = Console(file=StringIO(), force_terminal=True)
        result = create_status(console, "Working...", quiet=True, no_progress=False)
        assert isinstance(result, contextlib.nullcontext)

    def test_no_progress_returns_nullcontext(self) -> None:
        console = Console(file=StringIO(), force_terminal=True)
        result = create_status(console, "Working...", quiet=False, no_progress=True)
        assert isinstance(result, contextlib.nullcontext)

    def test_non_tty_returns_nullcontext(self) -> None:
        console = Console(file=StringIO(), force_terminal=True)
        with patch("sys.stderr") as mock_stderr:
            mock_stderr.isatty.return_value = False
            result = create_status(
                console,
                "Working...",
                quiet=False,
                no_progress=False,
            )
            assert isinstance(result, contextlib.nullcontext)

    def test_tty_returns_status(self) -> None:
        console = Console(file=StringIO(), force_terminal=True)
        with patch("sys.stderr") as mock_stderr:
            mock_stderr.isatty.return_value = True
            result = create_status(
                console,
                "Working...",
                quiet=False,
                no_progress=False,
            )
            assert isinstance(result, Status)


class TestCreateProgress:
    def test_quiet_returns_nullcontext(self) -> None:
        console = Console(file=StringIO(), force_terminal=True)
        result = create_progress(console, quiet=True, no_progress=False)
        assert isinstance(result, contextlib.nullcontext)

    def test_no_progress_returns_nullcontext(self) -> None:
        console = Console(file=StringIO(), force_terminal=True)
        result = create_progress(console, quiet=False, no_progress=True)
        assert isinstance(result, contextlib.nullcontext)

    def test_tty_returns_progress(self) -> None:
        console = Console(file=StringIO(), force_terminal=True)
        with patch("sys.stderr") as mock_stderr:
            mock_stderr.isatty.return_value = True
            result = create_progress(console, quiet=False, no_progress=False)
            assert isinstance(result, Progress)
