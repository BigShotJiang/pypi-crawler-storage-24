"""Tests for complyform.cli.exit_codes."""

from __future__ import annotations

from complyform.cli.exit_codes import (
    EXIT_COMPLIANCE_FAILURE,
    EXIT_INTERRUPTED,
    EXIT_PARTIAL_FAILURE,
    EXIT_RUNTIME_ERROR,
    EXIT_SUCCESS,
)


class TestExitCodes:
    def test_values(self) -> None:
        assert EXIT_SUCCESS == 0
        assert EXIT_COMPLIANCE_FAILURE == 1
        assert EXIT_RUNTIME_ERROR == 2
        assert EXIT_PARTIAL_FAILURE == 3
        assert EXIT_INTERRUPTED == 130

    def test_no_duplicates(self) -> None:
        codes = [
            EXIT_SUCCESS,
            EXIT_COMPLIANCE_FAILURE,
            EXIT_RUNTIME_ERROR,
            EXIT_PARTIAL_FAILURE,
            EXIT_INTERRUPTED,
        ]
        assert len(codes) == len(set(codes))
