"""Tests for backend.shared.region_mapping."""

from __future__ import annotations

import pytest
from backend.shared.region_mapping import resolve_data_region


@pytest.mark.parametrize(
    ("country", "regions", "expected"),
    [
        ("DE", ["us", "eu"], "eu"),
        ("FR", ["us", "eu"], "eu"),
        ("SE", ["us", "eu"], "eu"),
        ("NO", ["us", "eu"], "eu"),  # EEA non-EU
        ("IS", ["us", "eu"], "eu"),  # EEA non-EU
        ("SA", ["us", "eu", "me"], "me"),
        ("AE", ["us", "eu", "me"], "me"),
        ("QA", ["us", "eu", "me"], "me"),
        ("BH", ["us", "eu", "me"], "me"),
        ("SA", ["us", "eu"], "us"),  # ME not available for tier
        ("US", ["us", "eu"], "us"),
        ("JP", ["us", "eu"], "us"),
        ("BR", ["us", "eu", "me"], "us"),
        (None, ["us", "eu"], "us"),
        ("XX", ["us"], "us"),
        ("de", ["us", "eu"], "eu"),  # lowercase
    ],
    ids=[
        "DE-eu",
        "FR-eu",
        "SE-eu",
        "NO-eea",
        "IS-eea",
        "SA-me",
        "AE-me",
        "QA-me",
        "BH-me",
        "SA-no-me-region",
        "US",
        "JP",
        "BR",
        "None",
        "unknown",
        "lowercase",
    ],
)
def test_resolve_data_region(
    country: str | None,
    regions: list[str],
    expected: str,
) -> None:
    assert resolve_data_region(country, regions) == expected
