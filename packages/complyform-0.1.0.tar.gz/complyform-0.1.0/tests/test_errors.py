"""Tests for complyform.core.errors."""

from __future__ import annotations

from io import StringIO

import pytest
from rich.console import Console

from complyform.core.errors import (
    CheckovNotFoundError,
    CloudCredentialError,
    ComplyFormError,
    GCPAPINotEnabledError,
    LicenseInvalidError,
    NetworkUnreachableError,
    NoFindingsToRemediate,
    ProfileBundleError,
    RemediationTierError,
    StateFileNotFoundError,
    UnsupportedStateFormatError,
)


class TestComplyFormError:
    def test_stores_attributes(self) -> None:
        err = ComplyFormError(title="T", message="M", fix="F", hint="H")
        assert err.title == "T"
        assert err.message == "M"
        assert err.fix == "F"
        assert err.hint == "H"
        assert err.error_code == 0

    def test_error_code_kwarg(self) -> None:
        err = ComplyFormError(title="T", message="M", fix="F", error_code=42)
        assert err.error_code == 42

    def test_display_renders_panel(self) -> None:
        buf = StringIO()
        console = Console(file=buf, force_terminal=True)
        err = ComplyFormError(title="Oops", message="Something broke", fix="Fix it")
        err.display(console)
        output = buf.getvalue()
        assert "Oops" in output
        assert "Something broke" in output
        assert "Fix it" in output

    def test_display_includes_hint(self) -> None:
        buf = StringIO()
        console = Console(file=buf, force_terminal=True)
        err = ComplyFormError(title="T", message="M", fix="F", hint="Check docs")
        err.display(console)
        assert "Check docs" in buf.getvalue()

    def test_str_is_message(self) -> None:
        err = ComplyFormError(title="T", message="The message", fix="F")
        assert str(err) == "The message"


class TestCloudCredentialError:
    @pytest.mark.parametrize(
        ("cloud", "expected_fix"),
        [
            ("gcp", "gcloud auth application-default login"),
            ("aws", "aws configure"),
            ("azure", "az login"),
        ],
    )
    def test_fix_per_cloud(self, cloud: str, expected_fix: str) -> None:
        err = CloudCredentialError(cloud)
        assert expected_fix in err.fix
        assert err.error_code == 11

    def test_unknown_cloud(self) -> None:
        err = CloudCredentialError("oracle")
        assert "oracle" in err.fix


class TestStateFileNotFoundError:
    def test_fix_contains_path(self) -> None:
        err = StateFileNotFoundError("/tmp/terraform.tfstate")
        assert "/tmp/terraform.tfstate" in err.fix
        assert "remote state" in err.hint


class TestUnsupportedStateFormatError:
    def test_message_contains_version(self) -> None:
        err = UnsupportedStateFormatError("3")
        assert "3" in err.message
        assert "init -upgrade" in err.fix


class TestCheckovNotFoundError:
    def test_fix_command(self) -> None:
        err = CheckovNotFoundError()
        assert "uv tool install" in err.fix


class TestNetworkUnreachableError:
    def test_grace_days_positive(self) -> None:
        err = NetworkUnreachableError(grace_days=5)
        assert "5 day(s) remaining" in err.message

    def test_grace_days_zero(self) -> None:
        err = NetworkUnreachableError(grace_days=0)
        assert "expired" in err.message


class TestLicenseInvalidError:
    def test_fix_command(self) -> None:
        err = LicenseInvalidError("expired")
        assert "complyform config activate" in err.fix
        assert "expired" in err.message


class TestRemediationTierError:
    def test_attributes(self) -> None:
        err = RemediationTierError("hipaa", "professional")
        assert "hipaa" in err.message
        assert "professional" in err.message
        assert "Assess is always free" in err.hint
        assert err.error_code == 7


class TestNoFindingsToRemediate:
    def test_green_panel(self) -> None:
        buf = StringIO()
        console = Console(file=buf, force_terminal=True)
        err = NoFindingsToRemediate(["soc2", "hipaa"])
        err.display(console)
        output = buf.getvalue()
        assert "soc2" in output
        assert "hipaa" in output

    def test_frameworks_listed(self) -> None:
        err = NoFindingsToRemediate(["cis_gcp"])
        assert "cis_gcp" in err.message


class TestProfileBundleError:
    def test_fix_command(self) -> None:
        err = ProfileBundleError("corrupted checksum")
        assert "complyform config activate" in err.fix
        assert "corrupted checksum" in err.message


class TestGCPAPINotEnabledError:
    def test_fix_command(self) -> None:
        err = GCPAPINotEnabledError("compute.googleapis.com", "my-project")
        assert "gcloud services enable compute.googleapis.com" in err.fix
        assert "--project=my-project" in err.fix
