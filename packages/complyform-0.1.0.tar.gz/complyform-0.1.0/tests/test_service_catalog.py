"""Tests for complyform.core.greenfield.service_catalog — ServiceCatalog loader."""

from __future__ import annotations

import pytest

from complyform.core.errors import ServiceCatalogNotFoundError
from complyform.core.greenfield.service_catalog import (
    _reset_cache,
    load_service_catalog,
)


@pytest.fixture(autouse=True)
def _clear_cache() -> None:
    _reset_cache()


class TestLoadGcpCatalog:
    def test_loads_and_parses(self) -> None:
        catalog = load_service_catalog("gcp")
        assert catalog.cloud == "gcp"
        assert len(catalog.services) >= 25


class TestLoadAwsCatalog:
    def test_loads(self) -> None:
        catalog = load_service_catalog("aws")
        assert catalog.cloud == "aws"
        assert len(catalog.services) >= 30


class TestLoadAzureCatalog:
    def test_loads(self) -> None:
        catalog = load_service_catalog("azure")
        assert catalog.cloud == "azure"
        assert len(catalog.services) == 25


class TestGetServiceById:
    def test_found(self) -> None:
        catalog = load_service_catalog("gcp")
        svc = catalog.get_service("cloudsql")
        assert svc is not None
        assert svc.display_name == "Cloud SQL"

    def test_not_found(self) -> None:
        catalog = load_service_catalog("gcp")
        assert catalog.get_service("nonexistent") is None


class TestGetServicesByCategory:
    def test_filters_correctly(self) -> None:
        catalog = load_service_catalog("gcp")
        db_services = catalog.get_services_by_category("database")
        assert len(db_services) >= 1
        assert all(s.category == "database" for s in db_services)


class TestCatalogNotFound:
    def test_raises_error(self) -> None:
        with pytest.raises(ServiceCatalogNotFoundError):
            load_service_catalog("nonexistent_cloud")
