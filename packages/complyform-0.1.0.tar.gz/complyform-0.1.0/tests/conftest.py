"""Shared test fixtures for ComplyForm tests."""

from __future__ import annotations

import warnings
from io import StringIO

import pytest
from rich.console import Console

# Python 3.14 deprecated asyncio event-loop-policy APIs. pytest-asyncio 0.26
# still calls them during fixture setup, which triggers DeprecationWarning.
# Patch warnings._deprecated to suppress asyncio deprecations globally so
# that -W error does not turn them into test errors.
_orig_deprecated = warnings._deprecated  # type: ignore[attr-defined]


def _quiet_deprecated(name: str, *args: object, **kwargs: object) -> None:
    if isinstance(name, str) and name.startswith("asyncio."):
        return
    _orig_deprecated(name, *args, **kwargs)


warnings._deprecated = _quiet_deprecated  # type: ignore[attr-defined]


@pytest.fixture
def stderr_console() -> Console:
    """Console that captures output to a string buffer."""
    return Console(file=StringIO(), force_terminal=True)
