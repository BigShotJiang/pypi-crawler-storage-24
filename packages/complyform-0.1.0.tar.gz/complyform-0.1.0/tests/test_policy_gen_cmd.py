"""Tests for policy-gen CLI command."""

from __future__ import annotations

from unittest.mock import patch

from complyform.core.errors import (
    PolicyGenNoFindingsError,
    PolicyGenOverwriteError,
)


class TestPolicyGenCmd:
    def test_no_cached_assessment(self) -> None:
        """No cached assessment raises NoCachedAssessmentError."""
        with patch("complyform.cli.policy_gen_cmd.ScanCache") as mock_cache:
            mock_cache.return_value.latest.return_value = None
            mock_cache.return_value.read.return_value = None
            from complyform.core.errors import NoCachedAssessmentError

            # Verify the error class exists and has correct code
            err = NoCachedAssessmentError("")
            assert err.error_code == 17

    def test_policy_gen_no_findings_error(self) -> None:
        """PolicyGenNoFindingsError has green panel."""
        err = PolicyGenNoFindingsError()
        assert err.error_code == 33
        assert (
            "no policies to generate" in err.fix.lower() or "success" in err.fix.lower()
        )

    def test_policy_gen_overwrite_error(self) -> None:
        """PolicyGenOverwriteError shows correct fix."""
        err = PolicyGenOverwriteError("/tmp/test")
        assert err.error_code == 32
        assert "--overwrite" in err.fix

    def test_format_to_feature_keys(self) -> None:
        """Feature keys match TIER_CONFIG exactly."""
        from complyform.cli.policy_gen_cmd import _FORMAT_TO_FEATURE

        assert _FORMAT_TO_FEATURE["opa"] == "opa_rego"
        assert _FORMAT_TO_FEATURE["checkov"] == "checkov_custom"
        assert _FORMAT_TO_FEATURE["github-action"] == "github_action"
