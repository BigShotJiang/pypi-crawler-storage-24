# Bootstrap — Phase I-1
#
# Creates the GCS bucket for Terraform remote state and enables required
# GCP APIs on both prod and DR projects.
#
# No backend block: this phase uses local state because the remote state
# bucket it creates cannot be its own backend. Phase I-2 migrates state
# to the GCS backend once the bucket exists.

terraform {
  required_version = ">= 1.9"

  required_providers {
    google = {
      source  = "hashicorp/google"
      version = "~> 7.0"
    }
  }
}

# Default provider — targets the production project.
provider "google" {
  project = var.prod_project_id
  region  = var.region
}

# Aliased provider — targets the disaster-recovery project.
provider "google" {
  alias   = "dr"
  project = var.dr_project_id
  region  = var.region
}

# ---------------------------------------------------------------------------
# GCS bucket for Terraform remote state
# ---------------------------------------------------------------------------
# CMEK note: This bucket uses Google-managed AES-256 encryption at bootstrap
# because the KMS key ring does not exist yet (Phase I-2 creates it). Phase
# I-2 retroactively adds CMEK encryption to this bucket.
resource "google_storage_bucket" "tfstate" {
  name     = var.tfstate_bucket_name
  project  = var.prod_project_id
  location = var.region

  # Enable versioning so state can be rolled back after a bad apply.
  versioning {
    enabled = true
  }

  # Delete noncurrent object versions once 30 newer versions exist.
  lifecycle_rule {
    condition {
      num_newer_versions = 30
    }
    action {
      type = "Delete"
    }
  }

  # Enforce uniform IAM-only access (no per-object ACLs).
  uniform_bucket_level_access = true

  # Block all public access to the state bucket.
  public_access_prevention = "enforced"

  # Retain soft-deleted objects for 7 days (604800 seconds).
  soft_delete_policy {
    retention_duration_seconds = 604800
  }

  labels = {
    purpose     = "terraform-state"
    managed-by  = "bootstrap"
    environment = "prod"
  }
}

# ---------------------------------------------------------------------------
# GCP API enablement — prod project
# ---------------------------------------------------------------------------
locals {
  # APIs required on the production project.
  prod_apis = [
    "run.googleapis.com",
    "firestore.googleapis.com",
    "storage.googleapis.com",
    "secretmanager.googleapis.com",
    "cloudscheduler.googleapis.com",
    "compute.googleapis.com",
    "artifactregistry.googleapis.com",
    "cloudkms.googleapis.com",
    "cloudasset.googleapis.com",
    "recommender.googleapis.com",
    "securitycenter.googleapis.com",
    "containeranalysis.googleapis.com",
    "logging.googleapis.com",
    "monitoring.googleapis.com",
    "pubsub.googleapis.com",
    "cloudfunctions.googleapis.com",
    "cloudresourcemanager.googleapis.com",
    "cloudbuild.googleapis.com",
    "eventarc.googleapis.com",
    "iap.googleapis.com",
    "orgpolicy.googleapis.com",
  ]

  # APIs required on the disaster-recovery project.
  dr_apis = [
    "firestore.googleapis.com",
    "storage.googleapis.com",
    "cloudkms.googleapis.com",
  ]
}

# Enable each required API on the prod project. Never disable on teardown —
# other resources outside this module depend on these APIs.
resource "google_project_service" "prod" {
  for_each = toset(local.prod_apis)

  project = var.prod_project_id
  service = each.value

  disable_on_destroy = false
}

# ---------------------------------------------------------------------------
# GCP API enablement — DR project
# ---------------------------------------------------------------------------
# Enable each required API on the DR project. Same disable_on_destroy policy.
resource "google_project_service" "dr" {
  for_each = toset(local.dr_apis)
  provider = google.dr

  project = var.dr_project_id
  service = each.value

  disable_on_destroy = false
}

# ---------------------------------------------------------------------------
# Outputs
# ---------------------------------------------------------------------------
output "tfstate_bucket_name" {
  description = "Name of the GCS bucket holding Terraform remote state"
  value       = google_storage_bucket.tfstate.name
}

output "tfstate_bucket_url" {
  description = "URL of the GCS bucket holding Terraform remote state"
  value       = google_storage_bucket.tfstate.url
}

output "prod_project_id" {
  description = "Production GCP project ID"
  value       = var.prod_project_id
}

output "dr_project_id" {
  description = "Disaster-recovery GCP project ID"
  value       = var.dr_project_id
}
