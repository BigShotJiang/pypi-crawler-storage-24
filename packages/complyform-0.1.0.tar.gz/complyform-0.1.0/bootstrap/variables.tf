variable "prod_project_id" {
  description = "GCP project ID for production"
  type        = string
}

variable "dr_project_id" {
  description = "GCP project ID for disaster recovery"
  type        = string
}

variable "region" {
  description = "Primary GCP region"
  type        = string
  default     = "us-central1"
}

variable "tfstate_bucket_name" {
  description = "GCS bucket name for remote state"
  type        = string
  default     = "complyform-tfstate"
}
