# Bootstrap — Phase I-1

Creates the GCS bucket for Terraform remote state and enables required GCP APIs on both the production and disaster-recovery projects.

## Prerequisites

- GCP projects `complyform-prod` and `complyform-dr` exist with billing enabled
- `gcloud` authenticated with owner-level access to both projects
- Terraform >= 1.9 installed locally

## Usage

```bash
cd bootstrap/
cp terraform.tfvars.example terraform.tfvars
# Edit terraform.tfvars with your actual project IDs
terraform init
terraform plan
terraform apply
```

## After Bootstrap

1. **Verify the bucket exists:**
   ```bash
   gsutil ls gs://complyform-tfstate/
   ```
2. **Verify APIs are enabled:**
   ```bash
   gcloud services list --project=complyform-prod --enabled
   gcloud services list --project=complyform-dr --enabled
   ```
3. Proceed to **Phase I-2** to migrate state to the GCS backend and add CMEK encryption.

## State Management

This phase intentionally uses **local** Terraform state. The remote state bucket cannot serve as its own backend during creation. Keep `terraform.tfstate` backed up (and out of version control) until Phase I-2 migrates state to GCS.

## CMEK

The state bucket launches with Google-managed AES-256 encryption. Phase I-2 creates the KMS key ring and retroactively applies CMEK encryption to this bucket.
