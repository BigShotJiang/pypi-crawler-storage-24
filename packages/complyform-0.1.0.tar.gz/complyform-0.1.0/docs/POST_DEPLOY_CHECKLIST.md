# Post-Deploy Checklist

## Pre-Deploy QA

- [ ] `cd website && npm run build` — zero errors
- [ ] `cd docs && npm run build` — zero errors
- [ ] All 8 landing site pages render correctly (/, /pricing, /frameworks, /integrations, /security, /welcome, /resend-license, /contact-sales)
- [ ] All docs pages render correctly (~85 pages total)
- [ ] Paddle.js loads without console errors (placeholder token OK)
- [ ] Contact form CF Function works locally via `npx wrangler pages dev`
- [ ] `robots.txt`, `llms.txt`, `sitemap-index.xml` accessible at root
- [ ] Mobile responsive: tested at 375px, 768px, 1024px, 1440px
- [ ] Logo at `/assets/logo-512.png` accessible
- [ ] Nav links resolve (Docs → docs.complyform.dev, GitHub → github.com/complyform/complyform)
- [ ] Footer iubenda links use placeholder URLs (swap to real after iubenda setup)
- [ ] No hardcoded secrets in any committed file
- [ ] Both deploy workflows pass (dry run or actual deploy)

## Post-Deploy Steps (Manual)

1. Create CF Pages project `complyform-website` → custom domain `complyform.dev`
2. Create CF Pages project `complyform-docs` → custom domain `docs.complyform.dev`
3. Set GitHub Secrets for deploy workflows:
   - `CLOUDFLARE_API_TOKEN` — CF API token with Pages edit permission
   - `CLOUDFLARE_ACCOUNT_ID` — CF account ID
   - `PUBLIC_PADDLE_CLIENT_TOKEN`
   - `PUBLIC_PADDLE_PRICE_PRO`
   - `PUBLIC_PADDLE_PRICE_TEAM`
   - `PUBLIC_PADDLE_PRICE_AGENCY`
   - `PUBLIC_PADDLE_PRICE_ENTERPRISE`
   - `POSTMARK_SERVER_TOKEN`
   - `IUBENDA_SITE_ID`
   - `IUBENDA_COOKIE_POLICY_ID`
4. Configure iubenda → get real Site ID + Cookie Policy ID → update GitHub Secrets
5. Upload real logo to `website/public/assets/logo-512.png` and push
6. Update Postmark layout template: swap base64 logo → `https://complyform.dev/assets/logo-512.png`
7. Upload logo to Paddle product icons + checkout branding
8. Request Paddle domain approval (live ToS/Privacy now accessible)
9. Move Google OAuth consent screen to Production (live privacy policy URL now available)
10. Reserve `complyform` PyPI package name (first publish)
