// @ts-check
import { defineConfig } from 'astro/config';
import starlight from '@astrojs/starlight';

export default defineConfig({
  site: 'https://docs.complyform.dev',
  integrations: [
    starlight({
      title: 'ComplyForm Docs',
      favicon: '/favicon.svg',
      social: [
        { icon: 'github', label: 'GitHub', href: 'https://github.com/complyform/complyform' },
      ],
      customCss: ['./src/styles/custom.css'],
      sidebar: [
        {
          label: 'Getting Started',
          items: [
            { label: 'Quickstart', slug: 'quickstart' },
          ],
        },
        {
          label: 'CLI Reference',
          items: [
            { label: 'Overview', slug: 'cli-reference' },
            { label: 'scan', slug: 'cli-reference/scan' },
            { label: 'assess', slug: 'cli-reference/assess' },
            { label: 'remediate', slug: 'cli-reference/remediate' },
            { label: 'validate', slug: 'cli-reference/validate' },
            { label: 'report', slug: 'cli-reference/report' },
            { label: 'export', slug: 'cli-reference/export' },
            { label: 'policy-gen', slug: 'cli-reference/policy-gen' },
            { label: 'frameworks', slug: 'cli-reference/frameworks' },
            { label: 'update', slug: 'cli-reference/update' },
            { label: 'doctor', slug: 'cli-reference/doctor' },
            { label: 'init', slug: 'cli-reference/init' },
            { label: 'drift', slug: 'cli-reference/drift' },
            { label: 'activate', slug: 'cli-reference/activate' },
            { label: 'feedback', slug: 'cli-reference/feedback' },
            { label: 'version', slug: 'cli-reference/version' },
          ],
        },
        {
          label: 'Frameworks',
          autogenerate: { directory: 'frameworks' },
        },
        {
          label: 'Guides',
          items: [
            { label: 'Brownfield Assessment', slug: 'guides/brownfield' },
            { label: 'Greenfield Generation', slug: 'guides/greenfield' },
            { label: 'CI/CD Integration', slug: 'guides/cicd' },
            { label: 'Air-Gapped Environments', slug: 'guides/air-gapped' },
            { label: 'Evidence Export', slug: 'guides/evidence-export' },
            { label: 'Drift Monitoring', slug: 'guides/drift-monitoring' },
          ],
        },
        {
          label: 'API Reference',
          items: [
            { label: 'Overview', slug: 'api-reference' },
            { label: 'Dashboard Push API', slug: 'api-reference/dashboard-push' },
            { label: 'Authentication', slug: 'api-reference/authentication' },
          ],
        },
        {
          label: 'Drift Setup',
          items: [
            { label: 'Overview', slug: 'drift-setup' },
            { label: 'GCP', slug: 'drift-setup/gcp' },
            { label: 'AWS', slug: 'drift-setup/aws' },
            { label: 'Azure', slug: 'drift-setup/azure' },
          ],
        },
        {
          label: 'Changelog',
          items: [
            { label: 'CLI', slug: 'changelog/cli' },
            { label: 'Profiles', slug: 'changelog/profiles' },
          ],
        },
      ],
    }),
  ],
});
