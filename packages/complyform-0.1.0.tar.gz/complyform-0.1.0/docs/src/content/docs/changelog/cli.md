---
title: CLI Changelog
description: "ComplyForm CLI release history"
---

Changelog will be populated with the first release.

See [GitHub Releases](https://github.com/complyform/complyform/releases) for the latest updates.
