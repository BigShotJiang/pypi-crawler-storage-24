---
title: Profiles Changelog
description: "ComplyForm compliance profile bundle release history"
---

Profile changelog will be populated with the first profile bundle release.

Changes include control additions, modifications, and removals with source references.
