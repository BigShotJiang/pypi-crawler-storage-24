"""
warp_picker.py — Tkinter dialog for picking 4 perspective corners on a camera frame.

Usage:
    pts = WarpPickerDialog(parent, frame_bgr).run()
    # returns [[x,y],[x,y],[x,y],[x,y]] clockwise TL→TR→BR→BL, or None if cancelled
"""

from __future__ import annotations
import tkinter as tk
from tkinter import ttk, messagebox
from typing import Optional
import numpy as np

try:
    from PIL import Image, ImageTk, ImageDraw
    HAS_PIL = True
except ImportError:
    HAS_PIL = False

try:
    import cv2
    HAS_CV2 = True
except ImportError:
    HAS_CV2 = False

CORNER_LABELS = ["TL", "TR", "BR", "BL"]
CORNER_COLORS = ["#FF4444", "#44FF44", "#4488FF", "#FFFF44"]
DOT_RADIUS = 8


class WarpPickerDialog:
    """
    Modal dialog showing a still camera frame.
    User clicks 4 corners in order: TL, TR, BR, BL.
    Points can be dragged after placement.
    """

    DISPLAY_MAX = 800   # max display width/height

    def __init__(self, parent: tk.Widget, frame_bgr: np.ndarray,
                 existing_pts: Optional[list] = None):
        self.parent = parent
        self.frame_bgr = frame_bgr
        self.result: Optional[list] = None

        # Scale frame for display
        h, w = frame_bgr.shape[:2]
        scale = min(self.DISPLAY_MAX / w, self.DISPLAY_MAX / h, 1.0)
        self.scale = scale
        self.disp_w = int(w * scale)
        self.disp_h = int(h * scale)

        # Points in DISPLAY coords (will convert back on OK)
        if existing_pts:
            self.pts = [[int(x * scale), int(y * scale)] for x, y in existing_pts]
        else:
            self.pts = []

        self._dragging: Optional[int] = None
        self._build()

    def _build(self):
        self.top = tk.Toplevel(self.parent)
        self.top.title("Pick 4 Corners — TL → TR → BR → BL")
        self.top.resizable(False, False)
        self.top.grab_set()

        info = ttk.Label(self.top,
            text="Click 4 corners in order:  TL → TR → BR → BL   (drag to adjust)",
            font=("TkDefaultFont", 10))
        info.pack(pady=4)

        self.canvas = tk.Canvas(self.top, width=self.disp_w, height=self.disp_h,
                                cursor="crosshair", bg="#111")
        self.canvas.pack()
        self.canvas.bind("<Button-1>", self._on_click)
        self.canvas.bind("<B1-Motion>", self._on_drag)
        self.canvas.bind("<ButtonRelease-1>", self._on_release)

        btn_frame = ttk.Frame(self.top)
        btn_frame.pack(pady=6)
        ttk.Button(btn_frame, text="Clear", command=self._clear).pack(side=tk.LEFT, padx=4)
        ttk.Button(btn_frame, text="Cancel", command=self._cancel).pack(side=tk.LEFT, padx=4)
        self.ok_btn = ttk.Button(btn_frame, text="Apply", command=self._ok, state=tk.DISABLED)
        self.ok_btn.pack(side=tk.LEFT, padx=4)

        self._render()

    def _render(self):
        self.canvas.delete("all")

        # Background frame
        if HAS_PIL:
            import cv2 as _cv2
            rgb = _cv2.cvtColor(self.frame_bgr, _cv2.COLOR_BGR2RGB) if HAS_CV2 else self.frame_bgr
            img = Image.fromarray(rgb).resize((self.disp_w, self.disp_h), Image.LANCZOS)
            # Draw warp quad overlay
            draw = ImageDraw.Draw(img)
            if len(self.pts) > 1:
                poly = [tuple(p) for p in self.pts]
                if len(self.pts) == 4:
                    poly.append(poly[0])
                for i in range(len(poly) - 1):
                    draw.line([poly[i], poly[i + 1]], fill="#FFFFFF88", width=2)
            self._tk_img = ImageTk.PhotoImage(img)
            self.canvas.create_image(0, 0, anchor=tk.NW, image=self._tk_img)

        # Corner dots
        for i, (x, y) in enumerate(self.pts):
            color = CORNER_COLORS[i]
            self.canvas.create_oval(x - DOT_RADIUS, y - DOT_RADIUS,
                                    x + DOT_RADIUS, y + DOT_RADIUS,
                                    fill=color, outline="white", width=2, tags=f"dot{i}")
            self.canvas.create_text(x, y - DOT_RADIUS - 10,
                                    text=CORNER_LABELS[i], fill=color,
                                    font=("TkDefaultFont", 10, "bold"))

        # Status label
        remaining = 4 - len(self.pts)
        if remaining > 0:
            next_label = CORNER_LABELS[len(self.pts)]
            self.canvas.create_text(self.disp_w // 2, self.disp_h - 14,
                text=f"Click: {next_label}  ({remaining} remaining)",
                fill="white", font=("TkDefaultFont", 10))

        self.ok_btn.config(state=tk.NORMAL if len(self.pts) == 4 else tk.DISABLED)

    def _hit_test(self, x, y) -> Optional[int]:
        for i, (px, py) in enumerate(self.pts):
            if abs(x - px) <= DOT_RADIUS + 4 and abs(y - py) <= DOT_RADIUS + 4:
                return i
        return None

    def _on_click(self, event):
        hit = self._hit_test(event.x, event.y)
        if hit is not None:
            self._dragging = hit
            return
        if len(self.pts) < 4:
            self.pts.append([event.x, event.y])
            self._render()

    def _on_drag(self, event):
        if self._dragging is not None:
            self.pts[self._dragging] = [event.x, event.y]
            self._render()

    def _on_release(self, event):
        self._dragging = None

    def _clear(self):
        self.pts = []
        self._render()

    def _cancel(self):
        self.result = None
        self.top.destroy()

    def _ok(self):
        # Convert back from display coords to full-res camera coords
        inv = 1.0 / self.scale
        self.result = [[int(x * inv), int(y * inv)] for x, y in self.pts]
        self.top.destroy()

    def run(self) -> Optional[list]:
        self.parent.wait_window(self.top)
        return self.result
