"""
region.py — Region definition and perspective de-warp.

Each Region describes:
  - A rectangular output crop (x, y, w, h) in the composited HUD strip
  - Four source corner points in camera-frame pixel coordinates
    (top-left, top-right, bottom-right, bottom-left — clockwise)
    used to compute a homography that flattens perspective distortion.

If no warp points are set the region falls back to a simple rect crop.
"""

from __future__ import annotations
import dataclasses
import json
from typing import Optional
import numpy as np

try:
    import cv2
    HAS_CV2 = True
except ImportError:
    HAS_CV2 = False


@dataclasses.dataclass
class Region:
    name: str = "Region"

    # --- Output geometry (position in the HUD composite strip) ----------
    out_x: int = 0
    out_y: int = 0
    out_w: int = 320
    out_h: int = 100

    # --- Source corners in camera pixels (clockwise: TL, TR, BR, BL) ---
    # None = not set yet, fall back to simple rect crop
    src_pts: Optional[list[list[int]]] = None   # [[x,y], [x,y], [x,y], [x,y]]

    # --- Simple rect crop fallback (used when src_pts is None) ----------
    crop_x: int = 0
    crop_y: int = 0
    crop_w: int = 320
    crop_h: int = 100

    # --- Display toggle --------------------------------------------------
    enabled: bool = True
    locked: bool = False

    # --- Cached homography (not serialised) ------------------------------
    _H: Optional[np.ndarray] = dataclasses.field(default=None, repr=False, compare=False)

    # ------------------------------------------------------------------
    # Homography helpers
    # ------------------------------------------------------------------

    def compute_homography(self):
        """(Re)compute H from src_pts → output rect. Call after editing src_pts."""
        if not HAS_CV2:
            raise RuntimeError("opencv-python required for perspective correction")
        if self.src_pts is None or len(self.src_pts) != 4:
            self._H = None
            return
        src = np.array(self.src_pts, dtype=np.float32)
        dst = np.array([
            [0,           0          ],
            [self.out_w - 1, 0       ],
            [self.out_w - 1, self.out_h - 1],
            [0,           self.out_h - 1],
        ], dtype=np.float32)
        self._H, _ = cv2.findHomography(src, dst)

    def extract(self, frame: np.ndarray) -> Optional[np.ndarray]:
        """
        Extract this region from a full camera frame.
        Returns a BGR numpy array of size (out_h, out_w) or None.
        """
        if frame is None or not self.enabled:
            return None

        if self.src_pts is not None and len(self.src_pts) == 4:
            return self._warp(frame)
        else:
            return self._crop(frame)

    def _warp(self, frame: np.ndarray) -> Optional[np.ndarray]:
        if not HAS_CV2:
            return self._crop(frame)
        if self._H is None:
            self.compute_homography()
        if self._H is None:
            return self._crop(frame)
        warped = cv2.warpPerspective(frame, self._H, (self.out_w, self.out_h))
        return warped

    def _crop(self, frame: np.ndarray) -> Optional[np.ndarray]:
        h, w = frame.shape[:2]
        x1 = max(0, self.crop_x)
        y1 = max(0, self.crop_y)
        x2 = min(w, self.crop_x + self.crop_w)
        y2 = min(h, self.crop_y + self.crop_h)
        if x2 <= x1 or y2 <= y1:
            return None
        crop = frame[y1:y2, x1:x2]
        if crop.shape[1] != self.out_w or crop.shape[0] != self.out_h:
            if HAS_CV2:
                crop = cv2.resize(crop, (self.out_w, self.out_h))
        return crop

    # ------------------------------------------------------------------
    # Serialisation
    # ------------------------------------------------------------------

    def to_dict(self) -> dict:
        d = dataclasses.asdict(self)
        d.pop("_H", None)
        return d

    @classmethod
    def from_dict(cls, d: dict) -> "Region":
        d = {k: v for k, v in d.items() if k != "_H"}
        r = cls(**d)
        if r.src_pts:
            r.compute_homography()
        return r


class RegionSet:
    """Ordered list of regions with JSON save/load."""

    def __init__(self):
        self.regions: list[Region] = []

    def add(self, region: Region):
        self.regions.append(region)

    def remove(self, index: int):
        self.regions.pop(index)

    def move_up(self, index: int):
        if index > 0:
            self.regions[index - 1], self.regions[index] = (
                self.regions[index], self.regions[index - 1]
            )

    def move_down(self, index: int):
        if index < len(self.regions) - 1:
            self.regions[index], self.regions[index + 1] = (
                self.regions[index + 1], self.regions[index]
            )

    def save(self, path: str):
        data = {"regions": [r.to_dict() for r in self.regions]}
        with open(path, "w") as f:
            json.dump(data, f, indent=2)

    def load(self, path: str):
        with open(path) as f:
            data = json.load(f)
        self.regions = [Region.from_dict(d) for d in data.get("regions", [])]

    def composite(self, frame: np.ndarray, strip_w: int, strip_h: int) -> np.ndarray:
        """Render all regions onto a blank strip of size (strip_h, strip_w)."""
        strip = np.zeros((strip_h, strip_w, 3), dtype=np.uint8)
        for r in self.regions:
            patch = r.extract(frame)
            if patch is None:
                continue
            x1, y1 = r.out_x, r.out_y
            x2, y2 = x1 + r.out_w, y1 + r.out_h
            # Clamp to strip bounds
            sx1 = max(0, x1); sy1 = max(0, y1)
            sx2 = min(strip_w, x2); sy2 = min(strip_h, y2)
            px1 = sx1 - x1; py1 = sy1 - y1
            px2 = px1 + (sx2 - sx1); py2 = py1 + (sy2 - sy1)
            if sx2 > sx1 and sy2 > sy1:
                strip[sy1:sy2, sx1:sx2] = patch[py1:py2, px1:px2]
        return strip
