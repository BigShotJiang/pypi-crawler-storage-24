"""djhud-pi entry point."""
import logging
from .app import App

logging.basicConfig(level=logging.INFO,
                    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")


def main():
    app = App()
    app.mainloop()


if __name__ == "__main__":
    main()
