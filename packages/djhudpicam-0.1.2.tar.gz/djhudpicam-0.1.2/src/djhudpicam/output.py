"""
output.py — Output backends for djhud-pi.

Three backends selectable at runtime:
  1. vpn_stream  — JPEG-over-WebSocket server (aiohttp), compatible with
                   the main DJ HUD StreamClient receiver.
  2. vdoninja    — VDO.Ninja WebRTC push via aiortc (stub — mirrors
                   vdoninja_client.py from the main app).
  3. virtualcam  — pyvirtualcam virtual camera device.

Each backend runs in its own thread/event-loop and accepts frames via
push_frame(bgr_array).
"""

from __future__ import annotations
import asyncio
import io
import logging
import threading
import time
from typing import Optional
import numpy as np

log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _bgr_to_jpeg(frame: np.ndarray, quality: int = 80) -> bytes:
    try:
        import cv2
        ret, buf = cv2.imencode(".jpg", frame, [cv2.IMWRITE_JPEG_QUALITY, quality])
        return bytes(buf) if ret else b""
    except ImportError:
        from PIL import Image
        rgb = frame[:, :, ::-1]
        img = Image.fromarray(rgb)
        buf = io.BytesIO()
        img.save(buf, format="JPEG", quality=quality)
        return buf.getvalue()


# ---------------------------------------------------------------------------
# 1. VPN WebSocket stream (aiohttp)
# ---------------------------------------------------------------------------

class VpnStreamOutput:
    """
    Serves a JPEG-over-WebSocket stream on ws://<vpn-ip>:<port>/stream
    Matches the protocol expected by StreamClient in the main DJ HUD app.
    """

    def __init__(self, host: str = "0.0.0.0", port: int = 8765, quality: int = 80):
        self.host = host
        self.port = port
        self.quality = quality
        self._latest: Optional[bytes] = None
        self._lock = threading.Lock()
        self._loop: Optional[asyncio.AbstractEventLoop] = None
        self._thread: Optional[threading.Thread] = None
        self._clients: set = set()
        self._running = False

    def start(self):
        self._running = True
        self._thread = threading.Thread(target=self._run_loop, daemon=True)
        self._thread.start()

    def stop(self):
        self._running = False
        if self._loop:
            self._loop.call_soon_threadsafe(self._loop.stop)

    def push_frame(self, frame: np.ndarray):
        jpeg = _bgr_to_jpeg(frame, self.quality)
        with self._lock:
            self._latest = jpeg
        if self._loop and self._clients:
            asyncio.run_coroutine_threadsafe(self._broadcast(jpeg), self._loop)

    def _run_loop(self):
        self._loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self._loop)
        self._loop.run_until_complete(self._serve())

    async def _serve(self):
        try:
            from aiohttp import web
        except ImportError:
            log.error("aiohttp not installed — VPN stream unavailable")
            return

        app = web.Application()
        app.router.add_get("/stream", self._ws_handler)
        runner = web.AppRunner(app)
        await runner.setup()
        site = web.TCPSite(runner, self.host, self.port)
        await site.start()
        log.info("VPN stream listening on ws://%s:%d/stream", self.host, self.port)
        while self._running:
            await asyncio.sleep(0.5)
        await runner.cleanup()

    async def _ws_handler(self, request):
        from aiohttp import web
        ws = web.WebSocketResponse()
        await ws.prepare(request)
        self._clients.add(ws)
        log.info("WS client connected: %s", request.remote)
        try:
            async for _ in ws:
                pass
        finally:
            self._clients.discard(ws)
            log.info("WS client disconnected: %s", request.remote)
        return ws

    async def _broadcast(self, jpeg: bytes):
        dead = set()
        for ws in list(self._clients):
            try:
                await ws.send_bytes(jpeg)
            except Exception:
                dead.add(ws)
        self._clients -= dead

    @property
    def viewer_url(self) -> str:
        import socket
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("10.66.66.1", 80))
            ip = s.getsockname()[0]
            s.close()
        except Exception:
            ip = "127.0.0.1"
        return f"ws://{ip}:{self.port}/stream"


# ---------------------------------------------------------------------------
# 2. VDO.Ninja WebRTC via aiortc (stub)
# ---------------------------------------------------------------------------

class VdoNinjaOutput:
    """
    Push frames to VDO.Ninja via WebRTC (aiortc).
    This is a skeleton — wire up the full handshake from
    vdoninja_client.py in the main djhud app.
    """

    def __init__(self, room: str, password: str = "", width: int = 1280, height: int = 100):
        self.room = room
        self.password = password
        self.width = width
        self.height = height
        self._track = None
        self._loop: Optional[asyncio.AbstractEventLoop] = None
        self._thread: Optional[threading.Thread] = None
        self._running = False

    def start(self):
        try:
            import aiortc  # noqa: F401
        except ImportError:
            log.error("aiortc not installed — VDO.Ninja output unavailable")
            return
        self._running = True
        self._thread = threading.Thread(target=self._run_loop, daemon=True)
        self._thread.start()

    def stop(self):
        self._running = False

    def push_frame(self, frame: np.ndarray):
        if self._track is not None:
            self._track.push_frame(frame)

    def _run_loop(self):
        self._loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self._loop)
        self._loop.run_until_complete(self._connect())

    async def _connect(self):
        """
        TODO: Port the full VDO.Ninja handshake from vdoninja_client.py.
        Steps:
          1. Open WSS to wss://wss.vdo.ninja:443
          2. Send join-room with AES-CBC encrypted password hash
          3. Handle offer/answer SDP exchange
          4. Create aiortc VideoStreamTrack and push frames
        """
        log.warning("VDO.Ninja output: handshake not yet implemented in djhud-pi. "
                    "Port vdoninja_client.py from the main app.")
        # Placeholder: keep thread alive
        while self._running:
            await asyncio.sleep(1)


# ---------------------------------------------------------------------------
# 3. Virtual camera via pyvirtualcam
# ---------------------------------------------------------------------------

class VirtualCamOutput:
    """
    Output to a virtual camera device via pyvirtualcam.
    On Pi: v4l2loopback kernel module required.
      sudo modprobe v4l2loopback
    """

    def __init__(self, width: int = 1280, height: int = 100, fps: int = 30):
        self.width = width
        self.height = height
        self.fps = fps
        self._cam = None
        self._running = False

    def start(self):
        try:
            import pyvirtualcam
        except ImportError:
            log.error("pyvirtualcam not installed — virtual camera unavailable")
            return
        import pyvirtualcam
        self._cam = pyvirtualcam.Camera(width=self.width, height=self.height,
                                        fps=self.fps, fmt=pyvirtualcam.PixelFormat.BGR)
        self._running = True
        log.info("Virtual camera started: %s", self._cam.device)

    def stop(self):
        self._running = False
        if self._cam:
            self._cam.close()
            self._cam = None

    def push_frame(self, frame: np.ndarray):
        if not self._running or self._cam is None:
            return
        try:
            import cv2
            resized = cv2.resize(frame, (self.width, self.height))
        except ImportError:
            resized = frame
        self._cam.send(resized)
        self._cam.sleep_until_next_frame()


# ---------------------------------------------------------------------------
# Output manager — owns all active backends
# ---------------------------------------------------------------------------

class OutputManager:
    """
    Holds references to all active output backends.
    Call push_frame() once per composite frame; it fans out to all active outputs.
    """

    def __init__(self):
        self.vpn: Optional[VpnStreamOutput] = None
        self.vdoninja: Optional[VdoNinjaOutput] = None
        self.virtualcam: Optional[VirtualCamOutput] = None

    def push_frame(self, frame: np.ndarray):
        if self.vpn:
            self.vpn.push_frame(frame)
        if self.vdoninja:
            self.vdoninja.push_frame(frame)
        if self.virtualcam:
            self.virtualcam.push_frame(frame)

    def stop_all(self):
        for backend in (self.vpn, self.vdoninja, self.virtualcam):
            if backend:
                try:
                    backend.stop()
                except Exception:
                    pass
