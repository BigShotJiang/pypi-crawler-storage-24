"""
Sandflare Python SDK
====================
Two resource types, both backed by Firecracker microVMs:

    Database  — Managed PostgreSQL (psql-N)
    Sandbox   — Compute VM for AI agents (sb-N), can be wired to databases

Quick start:
    from sandflare import Database, Sandbox

    # Create a database
    db = Database.create("myapp", password="Secret#1",
                          schema_prompt="A todo app with users and tasks")

    # Create a sandbox
    sb = Sandbox.create("agent")

    # Wire the sandbox to the database
    sb.wire("psql-1")
    # Now inside sb-1: os.environ["DATABASE_URL"] = postgres://...

    # Run Python code in the sandbox that accesses the database
    result = sb.run_python('''
        import os, psycopg2
        conn = psycopg2.connect(os.environ["DATABASE_URL"])
        cur = conn.cursor()
        cur.execute("SELECT count(*) FROM users")
        print(cur.fetchone())
    ''')
    print(result.stdout)

    # Query database in natural language
    print(db.query_nl("How many users signed up today?"))

    # Clean up
    sb.delete()
    db.delete()
"""
from __future__ import annotations

import json
import os
import time
import urllib.error
import urllib.request
import base64
import shlex
from dataclasses import dataclass, field
from typing import Any, Generator

DEFAULT_BASE_URL = "https://api.sandflare.io"


def _first_env(*names: str) -> str:
    for name in names:
        value = os.environ.get(name, "")
        if value:
            return value
    return ""


def _resolve_base_url(base_url: str | None = None) -> str:
    return (base_url or _first_env("SANDFLARE_API_URL", "PANDAAGENT_BASE_URL") or DEFAULT_BASE_URL).rstrip("/")


def _resolve_api_key(api_key: str | None = None) -> str:
    return api_key or _first_env("SANDFLARE_API_KEY", "PANDAAGENT_API_KEY", "AGENTBOX_API_KEY")


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------

@dataclass
class ExecResult:
    exit_code: int
    stdout:    str
    stderr:    str
    ok:        bool

    def __str__(self):
        parts = [f"exit_code={self.exit_code}"]
        if self.stdout:
            parts.append(f"stdout={self.stdout[:200]!r}")
        if self.stderr:
            parts.append(f"stderr={self.stderr[:200]!r}")
        return f"ExecResult({', '.join(parts)})"

    def raise_on_error(self):
        if not self.ok:
            raise RuntimeError(
                f"Command failed (exit {self.exit_code}):\n{self.stderr or self.stdout}"
            )
        return self


@dataclass
class FileEntry:
    name:   str
    path:   str
    is_dir: bool
    size:   int
    mtime:  int


class SandflareError(Exception):
    def __init__(self, status: int, message: str, body: dict):
        super().__init__(f"HTTP {status}: {message}")
        self.status  = status
        self.message = message
        self.body    = body


AgentBoxError = SandflareError


class TierLimitError(SandflareError):
    """Raised when a request exceeds the plan's resource limits (HTTP 429)."""
    def __init__(self, message: str, body: dict):
        super().__init__(429, message, body)
        self.upgrade_url = body.get("upgrade_url", "https://app.sandflare.io/upgrade")

    def __str__(self):
        return (
            f"\n  ⚠️  Plan limit reached: {self.message}\n"
            f"  → Upgrade at: {self.upgrade_url}\n"
        )


class AuthError(SandflareError):
    """Raised on authentication failure (HTTP 401/403)."""
    def __init__(self, message: str, body: dict):
        super().__init__(403, message, body)


# ---------------------------------------------------------------------------
# HTTP helpers
# ---------------------------------------------------------------------------

def _req(method: str, url: str, body: Any = None, headers: dict | None = None,
         timeout: int = 35) -> dict:
    data = json.dumps(body).encode() if body is not None else None
    hdrs: dict[str, str] = {
        "Content-Type": "application/json",
        "User-Agent": "sandflare-sdk/1.0",
    } if data else {"User-Agent": "sandflare-sdk/1.0"}
    if headers:
        hdrs.update(headers)
    req = urllib.request.Request(url, data=data, headers=hdrs, method=method)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read())
    except urllib.error.HTTPError as e:
        try:
            raw = e.read()
            # Cloudflare returns HTML on bot-blocks (error code 1010)
            if b"error code: 1010" in raw or b"<!doctype html" in raw.lower():
                raise AuthError(
                    "Request blocked — check your API key and ensure you are using the sandflare-sdk/1.0 User-Agent",
                    {"error": "cloudflare_block"}
                ) from None
            err = json.loads(raw)
        except (AuthError, TierLimitError):
            raise
        except Exception:
            err = {"error": str(e)}
        if e.code == 429:
            raise TierLimitError(err.get("error", "Resource limit exceeded"), err) from None
        if e.code in (401, 403):
            raise AuthError(
                err.get("error", "Unauthorized — check your SANDFLARE_API_KEY (or legacy AGENTBOX_API_KEY)"),
                err,
            ) from None
        raise SandflareError(e.code, err.get("error", str(e)), err) from None


# ---------------------------------------------------------------------------
# Database — wraps /instances/psql-N
# ---------------------------------------------------------------------------

@dataclass
class DatabaseInfo:
    name:       str
    ip:         str
    pg_port:    int
    agent_port: int
    panel_port: int
    psql_url:   str
    agent_url:  str
    panel_url:  str
    status:     str
    memory_mb:  int
    vcpus:      int
    root_gb:    int
    username:   str = "admin"
    expires_at: str | None = None
    raw:        dict = field(default_factory=dict)


@dataclass
class SnapshotInfo:
    name:       str
    created_at: str | None = None
    size_mb:    float | None = None
    vmstate:    str | None = None
    mem:        str | None = None
    raw:        dict = field(default_factory=dict)


class Database:
    """
    A managed PostgreSQL database backed by a Firecracker microVM.

    Create:  Database.create("psql-1", password="...")
    Attach:  Database.get("psql-1")
    List:    Database.list()
    """

    def __init__(self, info: DatabaseInfo, base_url: str | None = None,
                 api_key: str | None = None):
        self._info    = info
        self._base    = _resolve_base_url(base_url)
        self._api_key = _resolve_api_key(api_key)

    # -- Factory --

    @classmethod
    def create(
        cls,
        label:         str,
        password:      str | None = None,
        memory_mb:     int = 512,
        vcpus:         int = 1,
        root_gb:       int = 10,
        schema_prompt: str = "",
        ttl_hours:     int = 0,
        wait_timeout:  int = 120,
        base_url:      str | None = None,
        api_key:       str | None = None,
    ) -> "Database":
        """Provision a new Postgres database VM."""
        payload: dict[str, Any] = {
            "label": label,
            "memory_mb": memory_mb, "vcpus": vcpus, "root_gb": root_gb,
        }
        if password:
            payload["password"] = password
        if schema_prompt:
            payload["schema_prompt"] = schema_prompt
        if ttl_hours:
            payload["ttl_hours"] = ttl_hours
        resolved_base_url = _resolve_base_url(base_url)
        key = _resolve_api_key(api_key)
        raw = _req("POST", f"{resolved_base_url}/instances", payload,
                   headers={"Authorization": f"Bearer {key}"} if key else None,
                   timeout=60)
        db = cls(_db_info_from_raw(raw), base_url=resolved_base_url, api_key=key)
        deadline = time.time() + max(wait_timeout, 1)
        while db.info.status == "starting" and time.time() < deadline:
            time.sleep(2)
            db = cls.get(db.name, base_url=resolved_base_url, api_key=key)
        if db.info.status == "starting":
            raise SandflareError(504, f"Database '{db.name}' did not become ready within {wait_timeout}s")
        if db.info.status == "error":
            detail = db.info.raw.get("error", "database failed to start")
            raise SandflareError(502, detail, db.info.raw)
        return db

    @classmethod
    def get(cls, name: str, base_url: str | None = None,
            api_key: str | None = None) -> "Database":
        """Attach to an existing database."""
        resolved_base_url = _resolve_base_url(base_url)
        key = _resolve_api_key(api_key)
        raw = _req("GET", f"{resolved_base_url}/instances/{name}",
                   headers={"Authorization": f"Bearer {key}"} if key else None, timeout=10)
        if raw.get("status") == "absent":
            raise SandflareError(404, f"Database '{name}' not found", raw)
        return cls(_db_info_from_raw(raw), base_url=resolved_base_url, api_key=key)

    @classmethod
    def list(cls, base_url: str | None = None,
             api_key: str | None = None) -> list["Database"]:
        """List all databases."""
        resolved_base_url = _resolve_base_url(base_url)
        key = _resolve_api_key(api_key)
        raw_list = _req("GET", f"{resolved_base_url}/instances",
                        headers={"Authorization": f"Bearer {key}"} if key else None, timeout=10)
        return [cls(_db_info_from_raw(r), base_url=resolved_base_url, api_key=key) for r in raw_list]

    # -- Properties --

    @property
    def name(self) -> str: return self._info.name
    @property
    def info(self) -> DatabaseInfo: return self._info
    @property
    def psql_url(self) -> str: return self._info.psql_url
    @property
    def pg_port(self) -> int: return self._info.pg_port

    # -- Queries --

    def query_nl(self, question: str) -> dict:
        """Ask a natural-language question. Returns {sql, columns, rows, row_count}."""
        try:
            return self._post(f"/instances/{self.name}/ai", {"prompt": question})
        except SandflareError as exc:
            if exc.status not in (400, 404, 405):
                raise
            return self._post(f"/instances/{self.name}/query", {"ask": question})

    def query_sql(self, sql: str) -> dict:
        """Execute raw SQL. Returns {sql, columns, rows, row_count}."""
        return self._post(f"/instances/{self.name}/query", {"sql": sql})

    def schema(self) -> dict:
        """Return the live database schema."""
        return self._get(f"/instances/{self.name}/schema")

    def migrate(self, description: str) -> dict:
        """Apply a natural-language migration (LLM generates DDL and applies it)."""
        return self._post(f"/instances/{self.name}/migrate", {"description": description}, timeout=40)

    # -- Lifecycle --

    def delete(self) -> None:
        """Stop the VM and delete all data."""
        hdrs = {**self._auth_headers(), "User-Agent": "sandflare-sdk/1.0"}
        req = urllib.request.Request(
            f"{self._base}/instances/{self.name}",
            method="DELETE", headers=hdrs,
        )
        try:
            urllib.request.urlopen(req, timeout=30)
        except urllib.error.HTTPError as e:
            if e.code != 404:
                raise

    def create_snapshot(self) -> SnapshotInfo:
        """Create a snapshot of this database VM."""
        r = self._post(f"/instances/{self.name}/snapshot", {})
        return _snapshot_info_from_raw(r)

    def list_snapshots(self) -> list[SnapshotInfo]:
        """List snapshots for this database VM."""
        r = self._get(f"/instances/{self.name}/snapshots")
        if isinstance(r, list):
            return [_snapshot_info_from_raw(item) for item in r]
        return []

    # -- Internals --

    def _auth_headers(self) -> dict:
        return {"Authorization": f"Bearer {self._api_key}"} if self._api_key else {}

    def _get(self, path: str, timeout: int = 10) -> dict:
        return _req("GET", f"{self._base}{path}", headers=self._auth_headers(), timeout=timeout)

    def _post(self, path: str, body: Any, timeout: int = 35) -> dict:
        return _req("POST", f"{self._base}{path}", body,
                    headers=self._auth_headers(), timeout=timeout)


# ---------------------------------------------------------------------------
# Sandbox — wraps /sandboxes/sb-N
# ---------------------------------------------------------------------------

@dataclass
class SandboxInfo:
    name:        str
    ip:          str
    agent_port:  int
    agent_url:   str
    status:      str
    memory_mb:   int
    vcpus:       int
    root_gb:     int
    public_url:  str = ""
    panel_url:   str = ""
    wires:       list[str] = field(default_factory=list)
    preview_url: str | None = None
    preview_port: int | None = None
    subdomain:   str | None = None
    subdomain_url: str | None = None
    template_id: str | None = None
    expires_at:  str | None = None
    label:       str = ""
    ephemeral:   bool = False
    size:        str = "nano"
    raw:         dict = field(default_factory=dict)


@dataclass
class StreamEvent:
    """A single SSE event from a streaming exec call."""
    event: str
    data:  dict

    @property
    def line(self) -> str:
        """Convenience: return stdout/stderr line text."""
        return self.data.get("line", "")

    @property
    def exit_code(self) -> int | None:
        return self.data.get("exit_code")

    def __str__(self):
        return f"StreamEvent(event={self.event!r}, data={self.data})"


class Sandbox:
    """
    An isolated compute VM for running AI agent code.

    Create:  Sandbox.create("sb-1")
    Attach:  Sandbox.get("sb-1")
    Wire:    sb.wire("psql-1")   # injects DATABASE_URL into the VM

    Agent code inside the sandbox can then:
        import os, psycopg2
        conn = psycopg2.connect(os.environ["DATABASE_URL"])
    """

    def __init__(self, info: SandboxInfo, base_url: str | None = None,
                 api_key: str | None = None):
        self._info    = info
        self._base    = _resolve_base_url(base_url)
        self._api_key = _resolve_api_key(api_key)

    # -- Factory --

    @classmethod
    def create(
        cls,
        label:        str,
        memory_mb:    int = 512,
        vcpus:        int = 1,
        root_gb:      int = 5,
        ttl_hours:    int = 0,
        template_id:  str = "",
        env:          dict[str, str] | None = None,
        size:         str = "nano",
        ephemeral:    bool = False,
        base_url:     str | None = None,
        api_key:      str | None = None,
        wait:         bool = True,
        wait_timeout: int = 120,
    ) -> "Sandbox":
        """Provision a new compute sandbox.

        size choices: "nano" (1vCPU/512MB), "small" (1vCPU/1GB), "medium" (2vCPU/2GB),
                      "large" (4vCPU/4GB), "xl" (4vCPU/8GB)

        template_id choices:
            ""                 — default (base Ubuntu)
            "sandbox-python"   — Python 3 + pip + fastapi + httpx
            "sandbox-node"     — Node.js 18 + npm + yarn + TypeScript
            "sandbox-full"     — Node.js + Python + git
            "code-interpreter" — Jupyter + pandas + numpy + matplotlib + scipy
            "coding-agent"     — git + Python + Node + anthropic + openai SDKs
        """
        payload: dict[str, Any] = {
            "label": label,
            "size": size,
            "memory_mb": memory_mb,
            "vcpus": vcpus, "root_gb": root_gb,
            "ephemeral": ephemeral,
        }
        if ttl_hours:
            payload["ttl_hours"] = ttl_hours
        if template_id:
            payload["template_id"] = template_id
        if env:
            payload["env"] = env
        resolved_base_url = _resolve_base_url(base_url)
        key = _resolve_api_key(api_key)
        raw = _req("POST", f"{resolved_base_url}/sandboxes", payload,
                   headers={"Authorization": f"Bearer {key}"} if key else None,
                   timeout=60)
        sb = cls(_sb_info_from_raw(raw), base_url=resolved_base_url, api_key=key)
        if template_id:
            sb._info.template_id = template_id
        if wait:
            sb._wait_for_agent(wait_timeout)
        if template_id:
            sb._provision_template(template_id)
        return sb

    @classmethod
    def get(cls, name: str, base_url: str | None = None,
            api_key: str | None = None) -> "Sandbox":
        """Attach to an existing sandbox."""
        resolved_base_url = _resolve_base_url(base_url)
        key = _resolve_api_key(api_key)
        raw = _req("GET", f"{resolved_base_url}/sandboxes/{name}",
                   headers={"Authorization": f"Bearer {key}"} if key else None, timeout=10)
        if raw.get("status") == "absent":
            raise SandflareError(404, f"Sandbox '{name}' not found", raw)
        return cls(_sb_info_from_raw(raw), base_url=resolved_base_url, api_key=key)

    @classmethod
    def list(cls, label: str | None = None, base_url: str | None = None,
             api_key: str | None = None) -> list["Sandbox"]:
        """List all sandboxes, optionally filtered by label (case-insensitive substring)."""
        resolved_base_url = _resolve_base_url(base_url)
        key = _resolve_api_key(api_key)
        url = f"{resolved_base_url}/sandboxes"
        if label:
            url += f"?label={label}"
        raw_list = _req("GET", url,
                        headers={"Authorization": f"Bearer {key}"} if key else None, timeout=10)
        return [cls(_sb_info_from_raw(r), base_url=resolved_base_url, api_key=key) for r in raw_list]

    # -- Properties --

    @property
    def name(self) -> str: return self._info.name
    @property
    def info(self) -> SandboxInfo: return self._info
    @property
    def agent_url(self) -> str: return self._info.agent_url
    @property
    def public_url(self) -> str: return self._info.public_url
    @property
    def panel_url(self) -> str: return self._info.panel_url
    @property
    def preview_url(self) -> str | None: return self._info.preview_url
    @property
    def preview_port(self) -> int | None: return self._info.preview_port
    @property
    def subdomain(self) -> str | None: return self._info.subdomain
    @property
    def subdomain_url(self) -> str | None: return self._info.subdomain_url
    @property
    def wires(self) -> list[str]: return self._info.wires

    # -- Wiring --

    def wire(self, database: str) -> None:
        """
        Connect this sandbox to a database.
        Injects DATABASE_URL and <DB>_URL env vars into the VM.
        """
        self._post(f"/sandboxes/{self.name}/wire", {"database": database})
        if database not in self._info.wires:
            self._info.wires.append(database)

    def unwire(self, database: str) -> None:
        """Disconnect this sandbox from a database."""
        req = urllib.request.Request(
            f"{self._base}/sandboxes/{self.name}/wire/{database}",
            method="DELETE", headers=self._auth_headers(),
        )
        try:
            urllib.request.urlopen(req, timeout=10)
        except urllib.error.HTTPError as e:
            if e.code != 404:
                raise
        if database in self._info.wires:
            self._info.wires.remove(database)

    def list_wires(self) -> list[dict]:
        """List databases connected to this sandbox with connection details."""
        r = self._get(f"/sandboxes/{self.name}/wires")
        return r.get("wires", [])

    # -- Code execution --

    def exec(self, cmd: str, timeout: int = 30, cwd: str = "/home/agent") -> ExecResult:
        """Run a shell command inside the sandbox."""
        wrapped_cmd = f"bash -lc {shlex.quote(f'cd {shlex.quote(cwd)} && {cmd}')}"
        r = self._post(f"/sandboxes/{self.name}/exec",
                       {"cmd": wrapped_cmd, "timeout": timeout, "cwd": "/home/agent"},
                       timeout=timeout + 5)
        return ExecResult(exit_code=r.get("exit_code", -1), stdout=r.get("stdout", ""),
                          stderr=r.get("stderr", ""), ok=r.get("ok", False))

    def run_python(self, code: str, timeout: int = 30) -> ExecResult:
        """Execute Python 3 code inside the sandbox."""
        r = self._post(f"/sandboxes/{self.name}/run/python",
                       {"code": code, "timeout": timeout}, timeout=timeout + 5)
        return ExecResult(exit_code=r.get("exit_code", -1), stdout=r.get("stdout", ""),
                          stderr=r.get("stderr", ""), ok=r.get("ok", False))

    def run_code(self, code: str, timeout: int = 30) -> ExecResult:
        """Alias for run_python() to support code-interpreter style examples."""
        return self.run_python(code, timeout=timeout)

    def run_node(self, code: str, timeout: int = 30) -> ExecResult:
        """Execute Node.js code inside the sandbox."""
        try:
            r = self._post(f"/sandboxes/{self.name}/run/node",
                           {"code": code, "timeout": timeout}, timeout=timeout + 5)
            return ExecResult(exit_code=r.get("exit_code", -1), stdout=r.get("stdout", ""),
                              stderr=r.get("stderr", ""), ok=r.get("ok", False))
        except AgentBoxError as e:
            if e.status != 408:
                raise
            time.sleep(3)
            try:
                r = self._post(f"/sandboxes/{self.name}/run/node",
                               {"code": code, "timeout": timeout}, timeout=timeout + 5)
                return ExecResult(exit_code=r.get("exit_code", -1), stdout=r.get("stdout", ""),
                                  stderr=r.get("stderr", ""), ok=r.get("ok", False))
            except AgentBoxError:
                pass
        script_b64 = base64.b64encode(code.encode("utf-8")).decode("ascii")
        cmd = f"printf %s '{script_b64}' | base64 -d >/tmp/_agentbox_run.js && node /tmp/_agentbox_run.js"
        return self.exec(cmd, timeout=timeout, cwd="/home/agent")

    def stream(
        self, cmd: str, timeout: int = 30, cwd: str = "/home/agent"
    ) -> "Generator[StreamEvent, None, None]":
        """
        Stream a shell command's output in real-time via SSE.

        Yields :class:`StreamEvent` objects as lines arrive::

            for event in sb.stream("python3 train.py"):
                if event.event in ("stdout", "stderr"):
                    print(event.line, end="", flush=True)
                elif event.event == "done":
                    print(f"\\nexited {event.exit_code}")
        """
        import http.client
        from urllib.parse import quote, urlparse as _up

        qs     = f"cmd={quote(cmd)}&timeout={timeout}&cwd={quote(cwd)}"
        parsed = _up(self._base)
        # Use Connection: close so the server closes after all SSE events are
        # sent; this lets resp.read() return instead of waiting indefinitely.
        conn   = http.client.HTTPConnection(parsed.netloc, timeout=timeout + 20)
        emitted = False
        try:
            conn.request(
                "GET", f"/sandboxes/{self.name}/exec/stream?{qs}",
                headers={
                    **self._auth_headers(),
                    "Accept": "text/event-stream",
                    "Connection": "close",
                },
            )
            resp       = conn.getresponse()
            body       = resp.read().decode("utf-8", errors="replace")
            event_type = "message"
            for line in body.splitlines():
                line = line.rstrip("\r")
                if line.startswith("event:"):
                    event_type = line[6:].strip()
                elif line.startswith("data:"):
                    data_str = line[5:].strip()
                    try:
                        data = json.loads(data_str)
                    except Exception:
                        data = {"raw": data_str}
                    emitted = True
                    yield StreamEvent(event=event_type, data=data)
                    event_type = "message"
        finally:
            conn.close()
        if emitted:
            return
        result = self.exec(cmd, timeout=timeout, cwd=cwd)
        for line in result.stdout.splitlines():
            yield StreamEvent(event="stdout", data={"line": line})
        for line in result.stderr.splitlines():
            yield StreamEvent(event="stderr", data={"line": line})
        yield StreamEvent(event="done", data={"exit_code": result.exit_code, "ok": result.ok})

    def _provision_template(self, template_id: str) -> None:
        if template_id == "code-interpreter":
            self._ensure_packages(
                verify_cmd="python3 -c \"import pandas,numpy,matplotlib,scipy\"",
                install_cmd=(
                    "((python3 -m ensurepip --upgrade || true) && "
                    "(command -v pip3 >/dev/null 2>&1 || "
                    "(apt-get update && DEBIAN_FRONTEND=noninteractive apt-get install -y python3-pip)) && "
                    "python3 -m pip install --quiet --prefer-binary --upgrade pip setuptools wheel && "
                    "python3 -m pip install --quiet --prefer-binary pandas numpy matplotlib scipy)"
                ),
                timeout=600,
                label=template_id,
            )
            return
        if template_id == "sandbox-python":
            self._ensure_packages(
                verify_cmd="python3 -c \"import requests\"",
                install_cmd=(
                    "((python3 -m ensurepip --upgrade || true) && "
                    "(command -v pip3 >/dev/null 2>&1 || "
                    "(apt-get update && DEBIAN_FRONTEND=noninteractive apt-get install -y python3-pip)) && "
                    "python3 -m pip install --quiet --prefer-binary requests)"
                ),
                timeout=300,
                label=template_id,
            )
            return
        if template_id == "sandbox-node":
            self._ensure_packages(
                verify_cmd="command -v node",
                install_cmd="apt-get update && DEBIAN_FRONTEND=noninteractive apt-get install -y nodejs npm",
                timeout=300,
                label=template_id,
            )
            return
        if template_id == "sandbox-full":
            self._ensure_packages(
                verify_cmd="command -v git && command -v node",
                install_cmd="apt-get update && DEBIAN_FRONTEND=noninteractive apt-get install -y git nodejs npm python3-pip",
                timeout=300,
                label=template_id,
            )
            return
        if template_id == "coding-agent":
            self._ensure_packages(
                verify_cmd="command -v git && command -v node",
                install_cmd="apt-get update && DEBIAN_FRONTEND=noninteractive apt-get install -y git nodejs npm python3-pip",
                timeout=300,
                label=template_id,
            )
            self._ensure_packages(
                verify_cmd="python3 -c \"import anthropic,openai\"",
                install_cmd="((python3 -m ensurepip --upgrade || true) && (command -v pip3 >/dev/null 2>&1 || (apt-get update && DEBIAN_FRONTEND=noninteractive apt-get install -y python3-pip)) && python3 -m pip install --quiet --prefer-binary anthropic openai)",
                timeout=300,
                label=template_id,
            )
            return

    def _ensure_packages(self, verify_cmd: str, install_cmd: str, timeout: int, label: str) -> None:
        verify = self._exec_template_verify(verify_cmd, timeout)
        if verify.ok:
            return
        install = self.exec(install_cmd, timeout=timeout)
        if not install.ok:
            raise RuntimeError(
                f"template provisioning failed for {label}: {install.stderr or install.stdout or 'unknown error'}"
            )
        verify = self._exec_template_verify(verify_cmd, timeout)
        if not verify.ok:
            raise RuntimeError(
                f"template provisioning verification failed for {label}: "
                f"{verify.stderr or verify.stdout or 'packages still unavailable'}"
            )

    def _exec_template_verify(self, verify_cmd: str, timeout: int) -> ExecResult:
        last_err: Optional[AgentBoxError] = None
        for attempt in range(15):
            try:
                return self.exec(f"{verify_cmd} >/dev/null 2>&1", timeout=timeout)
            except AgentBoxError as exc:
                if exc.status not in (408, 503) or attempt == 14:
                    raise
                last_err = exc
                time.sleep(2)
        if last_err is not None:
            raise last_err
        return self.exec(f"{verify_cmd} >/dev/null 2>&1", timeout=timeout)

    # -- File I/O --

    def write_file(self, path: str, content: str) -> None:
        """Write a text file to the sandbox filesystem."""
        self._post(f"/sandboxes/{self.name}/files",
                   {"path": path, "content": content}, timeout=15)

    def read_file(self, path: str) -> str:
        """Read a text file from the sandbox filesystem."""
        r = self._get(f"/sandboxes/{self.name}/files?path={path}", timeout=10)
        if r.get("encoding") == "base64":
            import base64
            return base64.b64decode(r["content"]).decode("utf-8", errors="replace")
        return r.get("content", "")

    def upload(self, src: "str | bytes | os.PathLike", remote_path: str) -> None:
        """
        Upload a file to the sandbox.

        *src* can be:
        - a local file path (``str`` or ``os.PathLike``)
        - raw bytes / ``bytearray``

        Example::

            sb.upload("data.csv", "/home/agent/data.csv")
            sb.upload(b"hello", "/home/agent/hello.txt")
        """
        import base64 as _b64
        if isinstance(src, (bytes, bytearray)):
            raw = bytes(src)
        else:
            with open(src, "rb") as f:
                raw = f.read()
        self._post(
            f"/sandboxes/{self.name}/files",
            {"path": remote_path, "content": _b64.b64encode(raw).decode(), "encoding": "base64"},
            timeout=30,
        )

    def download(self, remote_path: str) -> bytes:
        """
        Download a file from the sandbox as raw bytes.

        Example::

            chart_png = sb.download("/home/agent/chart.png")
            with open("chart.png", "wb") as f:
                f.write(chart_png)
        """
        import base64 as _b64
        r = self._get(f"/sandboxes/{self.name}/files?path={remote_path}", timeout=15)
        content = r.get("content", "")
        if r.get("encoding") == "base64":
            return _b64.b64decode(content)
        return content.encode("utf-8")

    def ls(self, path: str = "/home/agent") -> list[FileEntry]:
        """List directory contents inside the sandbox."""
        r = self._get(f"/sandboxes/{self.name}/ls?path={path}", timeout=10)
        return [FileEntry(**e) for e in r.get("entries", [])]

    # -- Package management --

    def install(self, pkg: str, runtime: str = "apt") -> ExecResult:
        """Install a package. runtime: 'apt' | 'pip' | 'npm'"""
        r = self._post(f"/sandboxes/{self.name}/install",
                       {"pkg": pkg, "runtime": runtime}, timeout=200)
        return ExecResult(exit_code=r.get("exit_code", 0 if r.get("ok") else 1),
                          stdout=r.get("stdout", ""), stderr=r.get("stderr", ""),
                          ok=r.get("ok", False))

    # -- Lifecycle --

    def health(self) -> dict:
        """Check the guest agent health."""
        return self._get(f"/sandboxes/{self.name}/health", timeout=5)

    def delete(self) -> None:
        """Stop the VM and delete all data."""
        hdrs = {**self._auth_headers(), "User-Agent": "sandflare-sdk/1.0"}
        req = urllib.request.Request(
            f"{self._base}/sandboxes/{self.name}",
            method="DELETE", headers=hdrs,
        )
        try:
            urllib.request.urlopen(req, timeout=30)
        except urllib.error.HTTPError as e:
            if e.code != 404:
                raise

    def pause(self) -> None:
        """Suspend the sandbox VM (CPU + memory frozen, billed at reduced rate)."""
        self._post(f"/sandboxes/{self.name}/pause", {})

    def resume(self) -> None:
        """Resume a previously paused sandbox VM."""
        self._post(f"/sandboxes/{self.name}/resume", {})

    def get_env(self) -> dict[str, str]:
        """Return current environment variables inside the sandbox."""
        return self._get(f"/sandboxes/{self.name}/agent/env")  # type: ignore[return-value]

    def set_env(self, vars: dict[str, str]) -> None:
        """Set environment variables inside the running sandbox."""
        self._post(f"/sandboxes/{self.name}/agent/env", vars)

    def create_snapshot(self) -> SnapshotInfo:
        """Create a snapshot of this sandbox."""
        r = self._post(f"/sandboxes/{self.name}/snapshot", {})
        return _snapshot_info_from_raw(r)

    def list_snapshots(self) -> list[SnapshotInfo]:
        """List snapshots for this sandbox."""
        r = self._get(f"/sandboxes/{self.name}/snapshots")
        if isinstance(r, list):
            return [_snapshot_info_from_raw(item) for item in r]
        return []

    # -- Internals --

    def _wait_for_agent(self, timeout: int = 120) -> None:
        deadline = time.time() + timeout
        last_err = None
        while time.time() < deadline:
            try:
                self.health()
                return
            except Exception as e:
                last_err = e
                time.sleep(3)
        raise TimeoutError(f"Agent not reachable after {timeout}s for {self.name}: {last_err}")

    def _auth_headers(self) -> dict:
        return {"Authorization": f"Bearer {self._api_key}"} if self._api_key else {}

    def _get(self, path: str, timeout: int = 10) -> dict:
        return _req("GET", f"{self._base}{path}", headers=self._auth_headers(), timeout=timeout)

    def _post(self, path: str, body: Any, timeout: int = 35) -> dict:
        return _req("POST", f"{self._base}{path}", body,
                    headers=self._auth_headers(), timeout=timeout)


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _db_info_from_raw(raw: dict) -> DatabaseInfo:
    return DatabaseInfo(
        name=raw.get("name", ""),
        ip=raw.get("ip", ""),
        pg_port=raw.get("pg_port", 0),
        agent_port=raw.get("agent_port", 0),
        panel_port=raw.get("panel_port", 0),
        psql_url=raw.get("psql_url", ""),
        agent_url=raw.get("agent_url", ""),
        panel_url=raw.get("panel_url", ""),
        status=raw.get("status", "unknown"),
        memory_mb=raw.get("memory_mb", 0),
        vcpus=raw.get("vcpus", 0),
        root_gb=raw.get("root_gb", 0),
        username=raw.get("username", "admin"),
        expires_at=raw.get("expires_at"),
        raw=raw,
    )


def _sb_info_from_raw(raw: dict) -> SandboxInfo:
    return SandboxInfo(
        name=raw.get("name", ""),
        ip=raw.get("ip", ""),
        agent_port=raw.get("agent_port", 0),
        agent_url=raw.get("agent_url", ""),
        public_url=raw.get("public_url", ""),
        panel_url=raw.get("panel_url", raw.get("subdomain_url", "")),
        preview_url=raw.get("preview_url"),
        preview_port=int(raw["preview_port"]) if raw.get("preview_port") is not None else None,
        subdomain=raw.get("subdomain"),
        subdomain_url=raw.get("subdomain_url"),
        status=raw.get("status", "unknown"),
        memory_mb=raw.get("memory_mb", 0),
        vcpus=raw.get("vcpus", 0),
        root_gb=raw.get("root_gb", 0),
        wires=raw.get("wires", []),
        template_id=raw.get("template") or raw.get("template_id"),
        expires_at=raw.get("expires_at"),
        label=raw.get("label", ""),
        ephemeral=bool(raw.get("ephemeral", False)),
        size=raw.get("size", "nano"),
        raw=raw,
    )


def _snapshot_info_from_raw(raw: dict) -> SnapshotInfo:
    return SnapshotInfo(
        name=raw.get("name", ""),
        created_at=raw.get("created_at"),
        size_mb=raw.get("size_mb"),
        vmstate=raw.get("vmstate"),
        mem=raw.get("mem"),
        raw=raw,
    )
