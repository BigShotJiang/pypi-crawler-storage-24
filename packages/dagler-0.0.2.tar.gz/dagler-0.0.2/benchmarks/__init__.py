"""dagler benchmark suite."""
