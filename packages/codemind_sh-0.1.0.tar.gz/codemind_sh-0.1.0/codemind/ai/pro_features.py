"""Pro AI features — Architectural Review, Onboarding Brief, Impact Predictor.

All three features require an Anthropic API key (BYOK or Pro tier).
Responses are cached in ``.codemind/ai-cache/`` so the same analysis
doesn't cost API tokens twice.

Tools
-----
generate_review(graph, codemind_dir, api_key) → writes REVIEW.md
generate_brief(graph, codemind_dir, api_key)  → writes BRIEF.md
predict_impact(graph, component, api_key)     → returns markdown string
"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from codemind.core.graph import CodeGraph

# Maximum nodes to send in the graph summary to keep tokens under control
_MAX_NODES_SUMMARY = 60
_CACHE_DIR_NAME = "ai-cache"


# ── Cache helpers ─────────────────────────────────────────────────────────────


def _cache_key(kind: str, payload: str) -> str:
    digest = hashlib.sha256(payload.encode()).hexdigest()[:16]
    return f"{kind}-{digest}.md"


def _read_cache(codemind_dir: Path, filename: str) -> str | None:
    cache_file = codemind_dir / _CACHE_DIR_NAME / filename
    if cache_file.exists():
        return cache_file.read_text(encoding="utf-8")
    return None


def _write_cache(codemind_dir: Path, filename: str, content: str) -> None:
    cache_dir = codemind_dir / _CACHE_DIR_NAME
    cache_dir.mkdir(exist_ok=True)
    (cache_dir / filename).write_text(content, encoding="utf-8")


# ── Graph summary builder ─────────────────────────────────────────────────────


def _graph_summary(graph: "CodeGraph") -> str:
    """Build a compact text summary of the graph for AI prompts."""
    from collections import Counter

    type_counts = Counter(n.type for n in graph.nodes.values())
    edge_counts: Counter[str] = Counter()
    for e in graph.edges:
        edge_counts[e.kind] += 1

    cross = edge_counts.get("cross_layer", 0)

    lines = [
        f"Project: {graph.project}",
        f"Languages: {', '.join(graph.languages)}",
        f"Nodes: {len(graph.nodes)}  Edges: {len(graph.edges)}  Cross-layer: {cross}",
        "",
        "Node types:",
    ]
    for t, c in sorted(type_counts.items(), key=lambda x: -x[1])[:12]:
        lines.append(f"  {t}: {c}")

    lines.append("")
    lines.append(f"Edge types: {dict(edge_counts)}")

    # Top structural components (services + controllers, up to _MAX_NODES_SUMMARY)
    structural = [
        n for n in graph.nodes.values()
        if n.type in {"service", "controller", "repository", "entity"}
    ]
    structural.sort(key=lambda n: -len(list(graph.edges_from(n.id))))

    lines.append("")
    lines.append("Key components (by connection count):")
    for node in structural[:_MAX_NODES_SUMMARY]:
        out_count = len(list(graph.edges_from(node.id)))
        in_count = len(list(graph.edges_to(node.id)))
        lines.append(
            f"  {node.name} ({node.type}, {node.language}) "
            f"→{out_count} ←{in_count}  pkg:{node.package}"
        )

    return "\n".join(lines)


def _health_summary(graph: "CodeGraph") -> str:
    """Run health checks and return a compact summary."""
    from codemind.health.checker import HealthChecker
    report = HealthChecker().run(graph)
    lines = [
        f"Health: {len(report.errors)} errors, {len(report.warnings)} warnings",
        "",
    ]
    for v in report.errors[:5]:
        lines.append(f"  ERROR  [{v.rule}] {v.component}: {v.message}")
    for v in report.warnings[:10]:
        lines.append(f"  WARN   [{v.rule}] {v.component}: {v.message}")
    return "\n".join(lines)


# ── Anthropic call helper ─────────────────────────────────────────────────────


def _call_claude(prompt: str, api_key: str, model: str = "claude-haiku-4-5-20251001") -> str:
    """Send a prompt to Claude and return the text response."""
    try:
        import anthropic  # noqa: PLC0415
    except ImportError as exc:
        raise ImportError(
            "Anthropic package not installed. Run: pip install codemind[ai]"
        ) from exc

    client = anthropic.Anthropic(api_key=api_key)
    message = client.messages.create(
        model=model,
        max_tokens=2048,
        system=(
            "You are a software architecture analysis assistant for CodeMind, "
            "a local-first code knowledge graph tool. "
            "You analyse code graphs — nodes (classes, services, controllers, repositories) "
            "and typed edges (injects, calls, extends, implements, cross_layer) — "
            "to provide technical insights about software project structure. "
            "All responses are in Markdown format and focus strictly on software engineering."
        ),
        messages=[{"role": "user", "content": prompt}],
    )
    return message.content[0].text


# ── generate_review ───────────────────────────────────────────────────────────


_REVIEW_PROMPT = """\
You are an expert software architect reviewing a codebase via its knowledge graph.

Here is the graph summary:
{graph_summary}

Health check results:
{health_summary}

Provide a structured architectural review as markdown with these sections:

## Architecture Review: {project}

### Overview
2-3 sentences summarising what kind of system this is.

### Strengths
- List 2-4 things the architecture does well (based on the graph structure).

### Risks
- List the top 3-5 architectural risks. Focus on patterns visible in the graph:
  layer violations, orphan components, missing tests, unbalanced domains.

### Recommendations
- List 3-5 concrete, actionable recommendations. Be specific about component names.

### Key Metrics
- Node count, edge count, cross-layer connections
- Health errors and warnings count
- Most connected component and its risk level

Keep it concise — max 400 words. Use component names from the graph.
"""


def generate_review(
    graph: "CodeGraph",
    codemind_dir: Path,
    api_key: str,
    force: bool = False,
) -> tuple[str, bool]:
    """Generate an AI architectural review and write it to REVIEW.md.

    Args:
        graph:        The live code graph.
        codemind_dir: The ``.codemind/`` directory.
        api_key:      Anthropic API key.
        force:        If True, regenerate even if cached.

    Returns:
        Tuple of (markdown content, was_cached).
    """
    graph_sum = _graph_summary(graph)
    health_sum = _health_summary(graph)
    payload = graph_sum + health_sum
    cache_key = _cache_key("review", payload)

    if not force:
        cached = _read_cache(codemind_dir, cache_key)
        if cached:
            return cached, True

    prompt = _REVIEW_PROMPT.format(
        graph_summary=graph_sum,
        health_summary=health_sum,
        project=graph.project,
    )
    content = _call_claude(prompt, api_key)

    _write_cache(codemind_dir, cache_key, content)
    # Write to canonical output file
    out = codemind_dir / "REVIEW.md"
    out.write_text(content, encoding="utf-8")

    return content, False


# ── generate_brief ────────────────────────────────────────────────────────────


_BRIEF_PROMPT = """\
You are writing an onboarding brief for a new developer joining a project.
You have access to the project's knowledge graph.

Graph summary:
{graph_summary}

Write a concise, friendly onboarding brief as markdown:

## Developer Onboarding Brief: {project}

### What This System Does
1-2 sentences. What problem does it solve?

### Tech Stack
List the languages, frameworks, and key patterns detected.

### The 5 Most Important Components
For each, explain what it does and why it matters. Use names from the graph.

### The 3 Domains to Understand First
Which package groups / modules should a new developer study first to
get productive quickly? Why each one?

### Key Patterns
How is the code structured? (e.g. layered architecture: controller → service → repository)
What naming conventions are used?

### Glossary
5-8 domain-specific terms extracted from component names and packages.
Format: **Term** — definition.

Keep it practical and under 500 words. Be specific about actual component names.
"""


def generate_brief(
    graph: "CodeGraph",
    codemind_dir: Path,
    api_key: str,
    force: bool = False,
) -> tuple[str, bool]:
    """Generate an AI onboarding brief and write it to BRIEF.md.

    Args:
        graph:        The live code graph.
        codemind_dir: The ``.codemind/`` directory.
        api_key:      Anthropic API key.
        force:        If True, regenerate even if cached.

    Returns:
        Tuple of (markdown content, was_cached).
    """
    graph_sum = _graph_summary(graph)
    cache_key = _cache_key("brief", graph_sum)

    if not force:
        cached = _read_cache(codemind_dir, cache_key)
        if cached:
            return cached, True

    prompt = _BRIEF_PROMPT.format(
        graph_summary=graph_sum,
        project=graph.project,
    )
    content = _call_claude(prompt, api_key)

    _write_cache(codemind_dir, cache_key, content)
    out = codemind_dir / "BRIEF.md"
    out.write_text(content, encoding="utf-8")

    return content, False


# ── predict_impact ────────────────────────────────────────────────────────────


_IMPACT_PROMPT = """\
You are a software architect assessing the risk of changing a component.

Graph summary:
{graph_summary}

The developer is about to change: **{component}**

BFS impact (structural dependents from the graph):
{bfs_result}

Assess the RISK of this change as markdown:

## AI Impact Prediction: {component}

### Risk Level
One of: 🟢 LOW / 🟡 MEDIUM / 🔴 HIGH

### Why
2-3 sentences explaining the risk level based on the structural impact.

### High-Risk Callers
Which of the dependents listed above are most likely to break?
Name 2-3 specific components and why they are risky.

### Safe to Change?
What would make this change safe? (e.g. "if you keep the method signature",
"if you add backwards-compatible overload", etc.)

### Recommended Steps
3 bullet points: what to check/test before merging this change.

Keep it under 200 words. Be specific about component names from the graph.
"""


def predict_impact(
    graph: "CodeGraph",
    component: str,
    api_key: str,
) -> str:
    """Predict the risk of changing a component using AI reasoning on the BFS result.

    Args:
        graph:     The live code graph.
        component: Component name (simple or fully-qualified).
        api_key:   Anthropic API key.

    Returns:
        Markdown string with AI risk assessment.
    """
    from codemind.graph import query as gq

    result = gq.impact_of(graph, component)
    if result is None:
        return (
            f"Component `{component}` not found in the graph.\n\n"
            "Run `codemind scan` first."
        )

    bfs_lines = []
    for node in result.direct[:10]:
        bfs_lines.append(f"  direct (dist 1): {node.name} ({node.type})")
    for node in result.indirect[:15]:
        bfs_lines.append(f"  indirect (dist 2+): {node.name} ({node.type})")

    if not bfs_lines:
        return (
            f"**`{component}`** has no dependents — safe to change freely.\n\n"
            "_No AI analysis needed: zero blast radius._"
        )

    bfs_result = "\n".join(bfs_lines) or "No dependents found."
    graph_sum = _graph_summary(graph)

    prompt = _IMPACT_PROMPT.format(
        graph_summary=graph_sum,
        component=result.node.name,
        bfs_result=bfs_result,
    )
    return _call_claude(prompt, api_key)
