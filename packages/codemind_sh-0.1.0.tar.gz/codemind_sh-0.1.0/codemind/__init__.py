"""CodeMind — Local-first intelligence layer for software projects."""

__version__ = "0.1.0"
__app_name__ = "codemind"
