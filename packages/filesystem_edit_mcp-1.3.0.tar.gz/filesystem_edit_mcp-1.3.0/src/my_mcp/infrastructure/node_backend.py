import os
import shutil
import tempfile
import asyncio
from typing import Any

from mcp.client.stdio import stdio_client, StdioServerParameters
from mcp.client.session import ClientSession
from mcp.types import CallToolResult

from my_mcp.core.interfaces import FileSystemBackendProtocol

TOOL_NAME = "edit_file" # Actually the official server also has 'read_text_file' but tests and users check for 'edit_file'


class NodeSubprocessBackend(FileSystemBackendProtocol):
    """
    Implements FileSystemBackendProtocol by running the official Node.js
    filesystem MCP server as a subprocess via npx.
    """
    def __init__(self, allowed_dirs: list[str]):
        self.allowed_dirs = allowed_dirs
        self._session_context = None
        self._client_session: ClientSession | None = None
        self._lock = asyncio.Lock()

    async def _start(self):
        npx_path = shutil.which("npx")
        if npx_path is None:
            raise RuntimeError("npx is not installed or not on PATH.")

        server_params = StdioServerParameters(
            command=npx_path,
            args=[
                "-y",
                "@modelcontextprotocol/server-filesystem",
                *self.allowed_dirs,
                tempfile.gettempdir()
            ],
            env={**os.environ}
        )

        self._session_context = stdio_client(server_params)
        read_stream, write_stream = await self._session_context.__aenter__()
        
        self._client_session = ClientSession(read_stream, write_stream)
        await self._client_session.__aenter__()
        await self._client_session.initialize()

    async def _stop(self):
        try:
            if self._client_session:
                await self._client_session.__aexit__(None, None, None)
        except Exception:
            pass
        finally:
            self._client_session = None
            try:
                if self._session_context:
                    await self._session_context.__aexit__(None, None, None)
            except Exception:
                pass
            finally:
                self._session_context = None

    async def __aenter__(self):
        await self._start()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self._stop()

    async def _ensure_connected(self):
        if not self._client_session:
            await self._start()

    async def list_tools(self):
        """Used mainly to verify backend is up."""
        async with self._lock:
            await self._ensure_connected()
            try:
                return await self._client_session.list_tools()
            except Exception:
                await self._stop()
                await self._start()
                return await self._client_session.list_tools()

    async def call_tool(self, name: str, arguments: dict[str, Any]) -> CallToolResult:
        async with self._lock:
            await self._ensure_connected()
            try:
                return await self._client_session.call_tool(name, arguments)
            except Exception:
                await self._stop()
                await self._start()
                return await self._client_session.call_tool(name, arguments)
