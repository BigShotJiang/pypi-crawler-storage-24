from my_mcp.server import main

main()
