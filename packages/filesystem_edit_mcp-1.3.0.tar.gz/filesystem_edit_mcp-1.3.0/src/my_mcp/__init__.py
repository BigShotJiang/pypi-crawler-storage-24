"""MCP Server for filesystem operations."""
