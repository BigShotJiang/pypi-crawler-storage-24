import json
import os
import platform
import re
import sys
import tempfile
import asyncio
from contextlib import asynccontextmanager

from mcp.server.fastmcp import Context, FastMCP

from my_mcp.domain.path_validator import resolve_path
from my_mcp.domain.server_config import ServerConfig
from my_mcp.infrastructure.node_backend import NodeSubprocessBackend
from my_mcp.core.use_cases import EditorInteractor


def _parse_allowed_dirs(raw: str) -> list[str]:
    """Parse allowed directories from env var."""
    pattern = r"[,;]" if platform.system() == "Windows" else r"[,:;]"
    return [d.strip() for d in re.split(pattern, raw) if d.strip()]


def _get_system_temp_dirs() -> list[str]:
    temps = set()
    for var in ("TEMP", "TMP"):
        val = os.environ.get(var)
        if val:
            temps.add(str(resolve_path(val)))
    temps.add(str(resolve_path(tempfile.gettempdir())))
    return list(temps)


_cli_dirs = sys.argv[1:]
ALLOWED_DIRS: list[str] = (
    _cli_dirs
    if _cli_dirs
    else _parse_allowed_dirs(os.environ.get("ALLOWED_DIRS", os.getcwd()))
)
ALLOWED_DIRS.extend(d for d in _get_system_temp_dirs() if d not in ALLOWED_DIRS)
SERVER_CONFIG_PATH = os.environ.get("SERVER_CONFIG", "server_config.json")

@asynccontextmanager
async def manage_backend(server: FastMCP):
    config = ServerConfig.from_path(SERVER_CONFIG_PATH) if os.path.exists(SERVER_CONFIG_PATH) else ServerConfig()
    
    backend = NodeSubprocessBackend(ALLOWED_DIRS)
    try:
        await asyncio.wait_for(backend.__aenter__(), timeout=20)
    except TimeoutError as e:
        raise RuntimeError("Backend server init timed out") from e
    
    try:
        try:
            tools = await asyncio.wait_for(backend.list_tools(), timeout=10)
        except TimeoutError as e:
            raise RuntimeError(
                "Backend server (@modelcontextprotocol/server-filesystem) did not "
                "respond within 10 seconds. Make sure Node.js and npx are installed."
            ) from e

        interactor = EditorInteractor(backend, config, ALLOWED_DIRS)
        ctx = {"interactor": interactor}
        yield ctx
    finally:
        await backend.__aexit__(None, None, None)

mcp = FastMCP("filesystem-edit-mcp", lifespan=manage_backend)


@mcp.tool()
async def read_text_file(
    path: str,
    head: int | None = None,
    tail: int | None = None,
    ctx: Context | None = None,
) -> str:
    """Read complete contents of a file as text.
    Reads the source file in the configured encoding.
    Cannot specify both head and tail simultaneously."""
    assert ctx is not None
    interactor: EditorInteractor = ctx.request_context.lifespan_context["interactor"]
    return await interactor.read_text_file(path, head, tail)


@mcp.tool()
async def edit_file(
    path: str,
    edits: list[dict],
    dryRun: bool = False,
    ctx: Context | None = None,
) -> str:
    """Edit a file using advanced pattern matching and formatting.
    Reads the file in the configured encoding, converts to UTF-8 for editing,
    then converts back. Applies umlaut fixing at the end.
    Use dryRun=True to preview changes before applying."""
    assert ctx is not None
    interactor: EditorInteractor = ctx.request_context.lifespan_context["interactor"]
    return await interactor.edit_file(path, edits, dryRun)


DEFAULT_CONFIG = {
    "enable_umlaut_fixing": False,
    "umlaut_config": {
        "string_mapping": {
            "ä": "AE_UMLT",
            "Ä": "CAE_UMLT",
            "ö": "OE_UMLT",
            "Ö": "COE_UMLT",
            "ü": "UE_UMLT",
            "Ü": "CUE_UMLT",
            "ß": "SS_UMLT",
        },
        "comment_mapping": {
            "ä": "ae",
            "Ä": "Ae",
            "ö": "oe",
            "Ö": "Oe",
            "ü": "ue",
            "Ü": "Ue",
            "ß": "ss",
        },
        "char_mapping": {
            "ä": "AE_UMLT_CHAR",
            "Ä": "CAE_UMLT_CHAR",
            "ö": "OE_UMLT_CHAR",
            "Ö": "COE_UMLT_CHAR",
            "ü": "UE_UMLT_CHAR",
            "Ü": "CUE_UMLT_CHAR",
            "ß": "SS_UMLT_CHAR",
        },
    },
    "encoding_config": {
        "default": "utf-8",
        "mapping": {
            "*.cpp": "latin-1",
            "*.h": "latin-1",
        },
    },
}

@mcp.tool()
async def initialize_config(overwrite: bool = False) -> str:
    """Create a default server_config.json in the current working directory."""
    path = os.path.abspath(SERVER_CONFIG_PATH)
    if os.path.exists(path) and not overwrite:
        return f"Config already exists at {path}. Pass overwrite=True to replace it."
    with open(path, "w", encoding="utf-8") as f:
        json.dump(DEFAULT_CONFIG, f, indent=2, ensure_ascii=False)
    return f"Created default config at {path}. Edit before restarting server."


def main() -> None:
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
