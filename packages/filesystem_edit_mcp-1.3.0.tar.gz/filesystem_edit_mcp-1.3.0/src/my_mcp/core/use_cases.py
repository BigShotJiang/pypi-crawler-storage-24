import os
import tempfile
import asyncio
from contextlib import contextmanager
from typing import Optional

from my_mcp.core.interfaces import FileSystemBackendProtocol
from my_mcp.domain.server_config import ServerConfig
from my_mcp.domain.path_validator import validate_path
from my_mcp.domain.umlaut_fixer import fix_document

BACKEND_TIMEOUT = float(os.environ.get("MCP_BACKEND_TIMEOUT", "60"))

@contextmanager
def utf8_temp(content: str):
    """Write content to a UTF-8 temp file, yield its path, then clean up."""
    with tempfile.NamedTemporaryFile(
        mode="w", suffix=".txt", encoding="utf-8", delete=False
    ) as tmp:
        tmp.write(content)
        tmp_path = tmp.name
    try:
        yield tmp_path
    finally:
        os.unlink(tmp_path)


class EditorInteractor:
    def __init__(
        self,
        backend: FileSystemBackendProtocol,
        config: ServerConfig,
        allowed_dirs: list[str],
    ):
        self.backend = backend
        self.config = config
        self.allowed_dirs = allowed_dirs

    async def read_text_file(
        self, path: str, head: Optional[int] = None, tail: Optional[int] = None
    ) -> str:
        validate_path(path, self.allowed_dirs)
        encoding = self.config.encoding_for(path)

        with open(path, encoding=encoding) as f:
            content = f.read()

        with utf8_temp(content) as tmp_path:
            args: dict[str, str | int] = {"path": tmp_path}
            if head is not None:
                args["head"] = head
            if tail is not None:
                args["tail"] = tail
            
            try:
                result = await asyncio.wait_for(
                    self.backend.call_tool("read_text_file", args),
                    timeout=BACKEND_TIMEOUT,
                )
            except TimeoutError as e:
                raise RuntimeError(
                    f"Backend call timed out after {BACKEND_TIMEOUT}s while reading '{path}'."
                ) from e

        return result.content[0].text if result.content else ""

    async def edit_file(self, path: str, edits: list[dict], dry_run: bool = False) -> str:
        validate_path(path, self.allowed_dirs)
        encoding = self.config.encoding_for(path)

        with open(path, encoding=encoding) as f:
            content = f.read()

        with utf8_temp(content) as tmp_path:
            try:
                result = await asyncio.wait_for(
                    self.backend.call_tool(
                        "edit_file",
                        {
                            "path": tmp_path,
                            "edits": edits,
                            "dryRun": dry_run,
                        },
                    ),
                    timeout=BACKEND_TIMEOUT,
                )
            except TimeoutError as e:
                raise RuntimeError(
                    f"Backend call timed out after {BACKEND_TIMEOUT}s while editing '{path}'."
                ) from e

            if not dry_run:
                with open(tmp_path, encoding="utf-8") as f:
                    edited = f.read()
                
                # Assume enable_umlaut_fixing comes from a dict access or is a field. 
                # According to the old code, enable_umlaut_fixing is in a higher level or in ServerConfig?
                # Oh wait, DEFAULT_CONFIG had enable_umlaut_fixing. We might need to add it to ServerConfig config model.
                if getattr(self.config, "enable_umlaut_fixing", False):
                    edited = fix_document(edited, self.config.umlaut_config)
                
                with open(path, "w", encoding=encoding) as f:
                    f.write(edited)

        return result.content[0].text if result.content else ""
