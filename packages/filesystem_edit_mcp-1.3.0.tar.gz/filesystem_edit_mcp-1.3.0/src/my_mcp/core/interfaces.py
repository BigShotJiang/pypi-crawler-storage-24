from typing import Protocol, Any
from mcp.types import CallToolResult

class FileSystemBackendProtocol(Protocol):
    """Protocol for abstracting the underlying filesystem MCP server."""
    
    async def call_tool(self, name: str, arguments: dict[str, Any]) -> CallToolResult:
        """Calls a tool on the backend server."""
        ...
