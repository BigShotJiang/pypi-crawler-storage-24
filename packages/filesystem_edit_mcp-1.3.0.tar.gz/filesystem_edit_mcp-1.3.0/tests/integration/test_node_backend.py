import pytest
from my_mcp.infrastructure.node_backend import NodeSubprocessBackend

@pytest.mark.asyncio
async def test_node_backend_starts_and_lists_tools(tmp_dir):
    backend = NodeSubprocessBackend([tmp_dir])
    
    # Actually wait to make sure node process initializes properly
    async with backend as b:
        tools = await b.list_tools()
        tool_names = [t.name for t in tools.tools]
        
        # Ensure it has loaded the filesystem tools
        assert "read_file" in tool_names or "edit_file" in tool_names or "read_multiple_files" in tool_names

@pytest.mark.asyncio
async def test_node_backend_calls_tool(tmp_dir, tmp_path_fn, write_file):
    backend = NodeSubprocessBackend([tmp_dir])
    
    path = tmp_path_fn("backend_test.txt")
    write_file(path, "Direct backend logic")
    
    async with backend as b:
        result = await b.call_tool("read_file", {"path": path}) # Standard FS MCP uses read_file not read_text_file. Wait actually we don't know the exact tool, it might be read_file. In our server it says "read_text_file"? No our wrapper overrides it. wait, in the wrapper we used "read_text_file" but also "edit_file".
        # wait! I need to be careful. The official npx @modelcontextprotocol/server-filesystem has `read_multiple_files`, `edit_file` but maybe not `read_text_file`. If it doesn't, we will get an error. Oh we are testing integration here with the actual node server. Let's just use `list_tools` for safety or `read_multiple_files`. Let's just use `edit_file` with dryRun since that's what backend definitely supports.
        
        result = await b.call_tool(
            "edit_file", 
            {
                "path": path, 
                "edits": [{"oldText": "Direct", "newText": "Indirect"}], 
                "dryRun": True
            }
        )
        assert not result.isError
