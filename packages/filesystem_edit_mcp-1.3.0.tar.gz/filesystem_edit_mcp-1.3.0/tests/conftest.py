import json
import os
import tempfile
from typing import Callable
import pytest

TEST_CONFIG = {
    "enable_umlaut_fixing": True,
    "umlaut_config": {
        "string_mapping": {"Ä": "CAE_UMLT", "ü": "UE_UMLT"},
        "comment_mapping": {"Ä": "Ae", "ü": "ue"},
    },
    "encoding_config": {
        "default": "utf-8",
        "mapping": {"*.cpp": "latin-1", "*.h": "latin-1"},
    },
}

@pytest.fixture(scope="session")
def tmp_dir():
    with tempfile.TemporaryDirectory() as d:
        yield d.replace("\\", "/")

@pytest.fixture(scope="session")
def config_path(tmp_dir: str) -> str:
    path = os.path.join(tmp_dir, "test_config.json")
    with open(path, "w") as f:
        json.dump(TEST_CONFIG, f)
    return path

@pytest.fixture
def tmp_path_fn(tmp_dir: str) -> Callable[[str], str]:
    def _tmp_path(name: str) -> str:
        return os.path.join(tmp_dir, name).replace("\\", "/")
    return _tmp_path

@pytest.fixture
def write_file() -> Callable[[str, str, str], None]:
    def _write_file(path: str, content: str, encoding: str = "utf-8") -> None:
        with open(path, "w", encoding=encoding) as f:
            f.write(content)
    return _write_file

@pytest.fixture
def read_file() -> Callable[[str, str], str]:
    def _read_file(path: str, encoding: str = "utf-8") -> str:
        with open(path, encoding=encoding) as f:
            return f.read()
    return _read_file
