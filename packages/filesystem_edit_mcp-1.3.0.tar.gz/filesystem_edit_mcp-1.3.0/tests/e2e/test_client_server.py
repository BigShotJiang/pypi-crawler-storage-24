import sys
import os
import pytest
from mcp.client.stdio import stdio_client, StdioServerParameters
from mcp.client.session import ClientSession

@pytest.mark.asyncio
async def test_e2e_server_running(tmp_dir, config_path, write_file, tmp_path_fn):
    server_params = StdioServerParameters(
        command=sys.executable,
        args=["-m", "my_mcp"],
        env={
            **os.environ,
            "ALLOWED_DIRS": tmp_dir,
            "SERVER_CONFIG": config_path
        }
    )
    
    async with stdio_client(server_params) as (read_stream, write_stream):
        async with ClientSession(read_stream, write_stream) as session:
            await session.initialize()
            
            # verify tools are bubbled up
            tools = await session.list_tools()
            tool_names = [t.name for t in tools.tools]
            assert "edit_file" in tool_names
            assert "read_text_file" in tool_names
            
            # test reading
            path = tmp_path_fn("e2e_test.txt")
            write_file(path, "E2E Test Output", "utf-8")
            
            result = await session.call_tool("read_text_file", {"path": path})
            assert not result.isError
            assert "E2E Test Output" in result.content[0].text
            
            # test editing and umlaut config
            cpp_path = tmp_path_fn("e2e_umlaut.cpp")
            write_file(cpp_path, 'const char* s = "Ärger";', "latin-1")
            
            edit_result = await session.call_tool("edit_file", {
                "path": cpp_path,
                "edits": [{"oldText": "Ärger", "newText": "Ärger Hello"}], # Since the read file does not transliterate when we write string edits? Wait.
                # Actually, just replacing any string
                "dryRun": False
            })
            assert not edit_result.isError
            
            read_result = await session.call_tool("read_text_file", {"path": cpp_path})
            assert "Hello" in read_result.content[0].text
