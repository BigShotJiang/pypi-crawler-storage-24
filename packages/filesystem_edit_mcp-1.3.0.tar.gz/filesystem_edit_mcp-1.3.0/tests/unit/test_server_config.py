import pathlib

from my_mcp.domain.server_config import EncodingConfig, ServerConfig
from my_mcp.domain.umlaut_config import UmlautConfig


class TestEncodingConfig:
    def test_default_encoding(self):
        config = EncodingConfig()
        assert config.find_encoding(pathlib.Path("test.txt")) == "utf-8"

    def test_pattern_match(self):
        config = EncodingConfig(mapping={"*.cpp": "latin-1", "*.h": "latin-1"})
        assert config.find_encoding(pathlib.Path("test.cpp")) == "latin-1"
        assert config.find_encoding(pathlib.Path("header.h")) == "latin-1"
        assert config.find_encoding(pathlib.Path("test.txt")) == "utf-8"

    def test_multiple_patterns(self):
        config = EncodingConfig(mapping={"*.cpp": "latin-1", "special_*": "ascii"})
        assert config.find_encoding(pathlib.Path("test.cpp")) == "latin-1"
        assert config.find_encoding(pathlib.Path("special_file.txt")) == "ascii"
        assert config.find_encoding(pathlib.Path("other.txt")) == "utf-8"


class TestServerConfig:
    def test_defaults(self):
        config = ServerConfig()
        assert config.encoding_for("test.txt") == "utf-8"

    def test_encoding_for_path(self):
        config = ServerConfig(
            encoding_config=EncodingConfig(mapping={"*.cpp": "latin-1"})
        )
        assert config.encoding_for("test.cpp") == "latin-1"
        assert config.encoding_for("test.txt") == "utf-8"

    def test_from_dict(self):
        config = ServerConfig(
            umlaut_config=UmlautConfig(string_mapping={"Ä": "AE"}),
            encoding_config=EncodingConfig(default="ascii"),
        )
        assert config.encoding_for("test.txt") == "ascii"
        assert config.umlaut_config.string_mapping == {"Ä": "AE"}
