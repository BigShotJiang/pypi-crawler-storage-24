import pytest
import os
import json
from mcp.types import CallToolResult, TextContent

from my_mcp.core.use_cases import EditorInteractor
from my_mcp.domain.server_config import ServerConfig

class MockBackend:
    def __init__(self):
        self.calls = []
        
    async def call_tool(self, name: str, arguments: dict):
        self.calls.append((name, arguments))
        if name == "read_text_file":
            path = arguments["path"]
            with open(path, "r", encoding="utf-8") as f:
                content = f.read()
            return CallToolResult(content=[TextContent(type="text", text=content)])
        elif name == "edit_file":
            path = arguments["path"]
            edits = arguments.get("edits", [])
            with open(path, "r", encoding="utf-8") as f:
                content = f.read()
            for edit in edits:
                content = content.replace(edit.get("oldText", ""), edit.get("newText", ""))
            if not arguments.get("dryRun", False):
                with open(path, "w", encoding="utf-8") as f:
                    f.write(content)
            return CallToolResult(content=[TextContent(type="text", text=content)])
        
@pytest.fixture
def mock_backend():
    return MockBackend()

@pytest.fixture
def interactor(mock_backend, tmp_dir):
    config = ServerConfig.model_validate({
        "enable_umlaut_fixing": True,
        "umlaut_config": {
            "string_mapping": {"Ä": "CAE_UMLT"},
            "comment_mapping": {"Ä": "Ae"},
            "char_mapping": {"Ä": "CAE_UMLT_CHAR"}
        },
        "encoding_config": {
            "default": "utf-8",
            "mapping": {"*.cpp": "latin-1"}
        }
    })
    return EditorInteractor(mock_backend, config, [tmp_dir])


@pytest.mark.asyncio
async def test_read_text_file(interactor, tmp_path_fn, write_file):
    path = tmp_path_fn("test.txt")
    write_file(path, "Hello world", "utf-8")
    
    result = await interactor.read_text_file(path)
    assert result == "Hello world"
    assert interactor.backend.calls[0][0] == "read_text_file"

@pytest.mark.asyncio
async def test_read_text_file_umlaut_encoding(interactor, tmp_path_fn, write_file):
    path = tmp_path_fn("test.cpp")
    write_file(path, 'const char* s = "Ärger";', "latin-1")
    
    result = await interactor.read_text_file(path)
    assert 'const char* s = "Ärger";' in result
    
@pytest.mark.asyncio
async def test_edit_file_translates_umlauts(interactor, tmp_path_fn, write_file, read_file):
    path = tmp_path_fn("test_edit.cpp")
    write_file(path, 'const char* s = "Ärger Hello";', "latin-1")
    
    result = await interactor.edit_file(path, [{"oldText": "Hello", "newText": "World"}])
    # The MockBackend will replace Hello with World
    # Then interactor's fix_document will translate Ä to CAE_UMLT
    
    content = read_file(path, "latin-1")
    assert "CAE_UMLT" in content
    assert "World" in content
