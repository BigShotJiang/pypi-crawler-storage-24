# filesystem-edit-mcp

An MCP (Model Context Protocol) server for filesystem operations with encoding support and umlaut fixing for C++ code.

## Architecture

![High-Level Overview](docs/overview.png)

### Encoding & Temp File Flow

![Encoding Flow](docs/encoding-flow.png)

## Features

- **read_text_file**: Read files with configurable encoding per file extension
- **edit_file**: Edit files with pattern matching and automatic umlaut fixing
- **Path validation**: Security boundary enforcement via `ALLOWED_DIRS`
- **Encoding support**: Configure encodings per file pattern (e.g., latin-1 for `.cpp`)
- **Umlaut fixing**: Transform German umlauts in C++ string literals, comments, and character constants

## Installation

No extra dependencies. Pure Python — works out of the box.

```bash
uvx filesystem-edit-mcp
```

## Configuration

Add to your MCP client config (Windsurf / Cursor / any MCP-compatible client):

```json
{
  "mcpServers": {
    "filesystem-edit-mcp": {
      "command": "uvx",
      "args": ["filesystem-edit-mcp", "/path/to/your/codebase"]
    }
  }
}
```

Multiple directories:

```json
{
  "mcpServers": {
    "filesystem-edit-mcp": {
      "command": "uvx",
      "args": ["filesystem-edit-mcp", "/path/to/dir1", "/path/to/dir2"]
    }
  }
}
```

### Environment Variables

| Variable | Description |
|----------|-------------|
| `ALLOWED_DIRS` | Allowed directories (supports `:`, `,`, `;` delimiters) — CLI args take precedence |
| `SERVER_CONFIG` | Path to the server config file (default: `server_config.json`) |

**Notes:**
- Windows 8.3 short paths (e.g., `C:\Users\FOO~1`) are automatically expanded to long form
- System temp directories (`%TEMP%`, `%TMP%`) are automatically allow-listed
- Error messages show resolved paths for easier debugging

### Server Config

```json
{
  "umlaut_config": {
    "string_mapping": { "Ä": "CAE_UMLT", "ä": "AE_UMLT" },
    "comment_mapping": { "Ä": "Ae", "ä": "ae" },
    "char_mapping": { "Ä": "CAE_UMLT_CHAR" }
  },
  "encoding_config": {
    "default": "utf-8",
    "mapping": { "*.cpp": "latin-1", "*.h": "latin-1" }
  }
}
```

## Security

![Security Diagram](docs/security.png)

Path validation prevents access to files outside configured directories.

## License

MIT
