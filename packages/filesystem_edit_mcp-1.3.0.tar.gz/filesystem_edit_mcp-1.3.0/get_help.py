import sys
from mcp.server.fastmcp import FastMCP
import pydoc

with open("temp_help.txt", "w", encoding="utf-8") as f:
    f.write(pydoc.render_doc(FastMCP))
