import json
import re
from pathlib import Path

import prajnyavan


def _cargo_version() -> str:
    cargo = Path("prajnyavan_service/Cargo.toml").read_text()
    m = re.search(r'^version\\s*=\\s*\"([0-9A-Za-z\\.-]+)\"', cargo, re.MULTILINE)
    return m.group(1) if m else ""


def _pyproject_version() -> str:
    pyproject = Path("pyproject.toml").read_text()
    m = re.search(r'^version\\s*=\\s*\"([0-9A-Za-z\\.-]+)\"', pyproject, re.MULTILINE)
    return m.group(1) if m else ""


def test_python_and_rust_versions_align():
    cargo_ver = _cargo_version()
    py_ver = _pyproject_version()
    assert prajnyavan.__version__ == cargo_ver or cargo_ver == "", "Python package vs Cargo version mismatch"
    assert prajnyavan.__version__ == py_ver or py_ver == "", "Python package vs pyproject version mismatch"
