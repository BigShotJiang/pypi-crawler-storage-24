import json
import os
import subprocess
import sys
import time

import pytest

from prajnyavan import auto_client


@pytest.mark.integration
def test_dev_roundtrip():
    """Start local daemon, run a memory round-trip, then stop."""
    if not os.getenv("RUN_PRAJNYAVAN_INTEGRATION"):
        pytest.skip("Set RUN_PRAJNYAVAN_INTEGRATION=1 to run integration test.")

    subprocess.run([sys.executable, "-m", "prajnyavan.cli", "stop"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

    subprocess.run([sys.executable, "-m", "prajnyavan.cli", "dev"], check=True, timeout=60)
    time.sleep(1)

    mem = auto_client(user_id="itest")

    @mem.wrap_llm(user_id="itest")
    def echo(prompt: str):
        return prompt + "!"

    out = echo("hello memory")
    assert "hello memory" in out.lower()

    hits = mem.search("itest", "hello")
    assert len(hits) >= 1

    subprocess.run([sys.executable, "-m", "prajnyavan.cli", "stop"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


@pytest.mark.integration
def test_smoke_command_json():
    if not os.getenv("RUN_PRAJNYAVAN_INTEGRATION"):
        pytest.skip("Set RUN_PRAJNYAVAN_INTEGRATION=1 to run integration test.")

    subprocess.run([sys.executable, "-m", "prajnyavan.cli", "stop"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

    result = subprocess.run(
        [sys.executable, "-m", "prajnyavan.cli", "smoke", "--json"],
        check=True,
        capture_output=True,
        text=True,
        timeout=90,
    )

    payload = json.loads(result.stdout)
    assert payload["ok"] is True
    assert payload["search_match"] is True
