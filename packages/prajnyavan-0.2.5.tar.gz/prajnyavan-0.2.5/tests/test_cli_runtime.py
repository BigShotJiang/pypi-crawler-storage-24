from importlib.metadata import PackageNotFoundError, version
import json
from types import SimpleNamespace

import pytest

import sys
from pathlib import Path

# Ensure the repo root (where the package lives) is importable even when pytest is launched from a global install.
ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import prajnyavan
from prajnyavan import cli


def test_version_matches_installed_metadata():
    repo_pyproject = ROOT / "pyproject.toml"
    if repo_pyproject.exists():
        marker = 'version = "'
        version_line = next(
            (line for line in repo_pyproject.read_text(encoding="utf-8").splitlines() if line.strip().startswith(marker)),
            None,
        )
        assert version_line is not None
        expected = version_line.split('"')[1]
        assert prajnyavan.__version__ == expected
        return

    try:
        dist_version = version("prajnyavan")
    except PackageNotFoundError:
        pytest.skip("Package metadata is not available in this environment.")

    assert prajnyavan.__version__ == dist_version


def test_status_is_ascii_safe_and_uses_health_probe(monkeypatch, capsys):
    monkeypatch.setattr(cli, "_load_config", lambda: {"base_url": "http://127.0.0.1:9999", "pid": None})
    monkeypatch.setattr(cli, "_resolve_daemon_pid", lambda cfg: None)
    monkeypatch.setattr(cli, "_fetch_health", lambda url: {"version": "0.1.9"})
    monkeypatch.setattr(cli, "_find_service_pid", lambda: None)

    result = cli.cmd_status(SimpleNamespace(verbose=False, json=False))
    captured = capsys.readouterr()

    assert result == 0
    assert "[running] prajnyavan" in captured.out
    assert all(ord(ch) < 128 or ch in "\r\n\t" for ch in captured.out)


def test_status_snapshot_preserves_actual_daemon_version(monkeypatch):
    monkeypatch.setattr(cli, "_load_config", lambda: {"base_url": "http://127.0.0.1:9999", "pid": None})
    monkeypatch.setattr(cli, "_resolve_daemon_pid", lambda cfg: None)
    monkeypatch.setattr(cli, "_fetch_health", lambda url: {"version": "0.2.0", "status": "ok"})
    monkeypatch.setattr(cli, "_find_service_pid", lambda: None)

    snapshot = cli._status_snapshot(scan=False)

    assert snapshot["health"]["version"] == "0.2.0"
    assert snapshot["health"]["version_mismatch"] is True
    assert snapshot["health"]["expected_version"] == cli._package_version()


def test_status_json_outputs_snapshot(monkeypatch, capsys):
    snapshot = {
        "running": False,
        "base_url": None,
        "pid": None,
        "config_exists": False,
        "health": {},
        "cache_mb": 0.0,
    }
    monkeypatch.setattr(cli, "_status_snapshot", lambda scan=True: snapshot)

    result = cli.cmd_status(SimpleNamespace(verbose=False, json=True))
    captured = capsys.readouterr()

    assert result == 1
    assert json.loads(captured.out)["running"] is False


def test_stop_removes_runtime_state(monkeypatch, tmp_path, capsys):
    pid_file = tmp_path / "prajnyavan.pid"
    dev_config = tmp_path / "dev.json"
    pid_file.write_text("4242")
    dev_config.write_text('{"base_url": "http://127.0.0.1:9999", "pid": 4242}')

    state = {"alive": True}

    def fake_pid_alive(pid: int) -> bool:
        return state["alive"]

    def fake_kill(pid: int) -> None:
        state["alive"] = False

    monkeypatch.setattr(cli, "PID_FILE", pid_file)
    monkeypatch.setattr(cli, "DEV_CONFIG", dev_config)
    monkeypatch.setattr(cli, "_load_config", lambda: {"base_url": "http://127.0.0.1:9999", "pid": 4242})
    monkeypatch.setattr(cli, "_pid_alive", fake_pid_alive)
    monkeypatch.setattr(cli, "_kill_pid", fake_kill)
    monkeypatch.setattr(cli.time, "sleep", lambda *_: None)

    result = cli.cmd_stop(SimpleNamespace())
    captured = capsys.readouterr()

    assert result == 0
    assert not pid_file.exists()
    assert not dev_config.exists()
    assert "[prajnyavan] stopped." in captured.out


def test_doctor_json_uses_structured_report(monkeypatch, capsys):
    report = {
        "ready": False,
        "summary": {"ok": 2, "warn": 1, "fail": 1, "skip": 0},
        "snapshot": {"running": False},
        "checks": [{"name": "daemon_running", "status": "fail", "detail": "not running", "fix": "Run: prajnyavan dev"}],
    }
    monkeypatch.setattr(cli, "_doctor_report", lambda allow_mock=False: report)

    result = cli.cmd_doctor(SimpleNamespace(json=True, allow_mock=False))
    captured = capsys.readouterr()

    assert result == 1
    assert json.loads(captured.out)["ready"] is False


def test_doctor_fails_on_version_mismatch(monkeypatch, capsys):
    snapshot = {
        "running": True,
        "base_url": "http://127.0.0.1:9999",
        "config_exists": True,
        "config_path": "dev.json",
        "log_exists": True,
        "log_path": "daemon.log",
        "cache_mb": 0.0,
        "mode": "real",
        "health": {
            "version": "0.2.0",
            "version_reported": "0.2.0",
            "expected_version": cli._package_version(),
            "version_mismatch": True,
        },
    }
    monkeypatch.setattr(cli, "_status_snapshot", lambda: snapshot)
    monkeypatch.setattr(cli, "_check_base_dir_writable", lambda: (True, "ok"))
    monkeypatch.setattr(cli, "_check_port_readiness", lambda snapshot: ("ok", "http://127.0.0.1:9999", ""))
    monkeypatch.setattr(cli, "get_token", lambda *args, **kwargs: "Bearer test")

    result = cli.cmd_doctor(SimpleNamespace(json=True, allow_mock=False))
    captured = capsys.readouterr()
    payload = json.loads(captured.out)

    assert result == 1
    assert payload["ready"] is False
    assert any(
        check["name"] == "version_alignment" and check["status"] == "fail"
        for check in payload["checks"]
    )


def test_smoke_json_stays_machine_readable(monkeypatch, capsys):
    class FakeClient:
        def store(self, user_id, content, **kwargs):
            return "mid_123"

        def search(self, user_id, query, **kwargs):
            return [{"content_text": query}]

        def get_emotion(self):
            return {"valence": 0.2, "arousal": 0.1}

        def delete_user(self, user_id):
            return 1

    class FakeMemoryClient:
        @classmethod
        def dev(cls, user_id="developer", **kwargs):
            return FakeClient()

    stop_calls = []
    monkeypatch.setattr(cli, "_status_snapshot", lambda *args, **kwargs: {"running": False})
    monkeypatch.setattr(cli, "_ensure_daemon_running_for_cli", lambda quiet=False: {"base_url": "http://127.0.0.1:9999"})
    monkeypatch.setattr(cli, "MemoryClient", FakeMemoryClient)
    monkeypatch.setattr(cli, "cmd_stop", lambda *_args, quiet=False: stop_calls.append(quiet) or 0)

    result = cli.cmd_smoke(SimpleNamespace(json=True, keep_running=False, stop_after=False))
    captured = capsys.readouterr()
    payload = json.loads(captured.out)

    assert result == 0
    assert payload["ok"] is True
    assert payload["search_match"] is True
    assert payload["left_daemon_running"] is True
    assert stop_calls == []


def test_smoke_stop_after_stops_started_daemon(monkeypatch, capsys):
    class FakeClient:
        def store(self, user_id, content, **kwargs):
            return "mid_123"

        def search(self, user_id, query, **kwargs):
            return [{"content_text": query}]

        def get_emotion(self):
            return {"valence": 0.2, "arousal": 0.1}

        def delete_user(self, user_id):
            return 1

    class FakeMemoryClient:
        @classmethod
        def dev(cls, user_id="developer", **kwargs):
            return FakeClient()

    stop_calls = []
    monkeypatch.setattr(cli, "_status_snapshot", lambda *args, **kwargs: {"running": False})
    monkeypatch.setattr(cli, "_ensure_daemon_running_for_cli", lambda quiet=False: {"base_url": "http://127.0.0.1:9999"})
    monkeypatch.setattr(cli, "MemoryClient", FakeMemoryClient)
    monkeypatch.setattr(cli, "cmd_stop", lambda *_args, quiet=False: stop_calls.append(quiet) or 0)

    result = cli.cmd_smoke(SimpleNamespace(json=True, keep_running=False, stop_after=True))
    captured = capsys.readouterr()
    payload = json.loads(captured.out)

    assert result == 0
    assert payload["stopped_daemon"] is True
    assert stop_calls == [True]


def test_export_writes_portable_profile_schema(monkeypatch, tmp_path, capsys):
    exported = {
        "schema_version": 1,
        "exported_at": "2025-03-22T10:00:00Z",
        "user_id": "alice",
        "stats": {
            "total_memories": 2,
            "earliest_memory": "2025-03-20T10:00:00Z",
            "latest_memory": "2025-03-22T10:00:00Z",
        },
        "memories": [
            {"id": "m1", "content": "Alice likes tea", "importance": 0.5, "valence": 0.1, "arousal": 0.0, "tags": [], "category": "prefs", "created_at": "2025-03-20T10:00:00Z", "access_count": 1},
            {"id": "m2", "content": "Alice has a dog", "importance": 0.8, "valence": 0.4, "arousal": 0.2, "tags": ["pet"], "category": "personal", "created_at": "2025-03-22T10:00:00Z", "access_count": 3},
        ],
    }

    class FakeClient:
        def export_user(self, user_id):
            assert user_id == "alice"
            return exported

    class FakeMemoryClient:
        @classmethod
        def dev(cls, user_id="developer", **kwargs):
            return FakeClient()

        @classmethod
        def from_env(cls, **kwargs):
            return FakeClient()

    out = tmp_path / "alice_profile.json"
    monkeypatch.setattr(cli, "MemoryClient", FakeMemoryClient)

    result = cli.cmd_export(SimpleNamespace(user="alice", output=str(out)))
    captured = capsys.readouterr()
    payload = json.loads(out.read_text())

    assert result == 0
    assert payload["schema_version"] == 1
    assert payload["stats"]["total_memories"] == 2
    assert payload["memories"][0]["content"] == "Alice likes tea"
    assert "Exported 2 memories" in captured.out


def test_import_uses_profile_endpoint_contract(monkeypatch, tmp_path, capsys):
    captured = {}
    profile = {
        "schema_version": 1,
        "exported_at": "2025-03-22T10:00:00Z",
        "user_id": "alice",
        "stats": {"total_memories": 1, "earliest_memory": None, "latest_memory": None},
        "memories": [
            {
                "id": "m1",
                "content": "Alice likes tea",
                "importance": 0.5,
                "valence": 0.1,
                "arousal": 0.0,
                "tags": ["prefs"],
                "category": "personal",
                "created_at": "2025-03-22T10:00:00Z",
                "access_count": 2,
            }
        ],
    }

    class FakeClient:
        def import_profile(self, profile_doc, *, target_user_id=None, skip_duplicates=True):
            captured["profile"] = profile_doc
            captured["target_user_id"] = target_user_id
            captured["skip_duplicates"] = skip_duplicates
            return {"imported": 1, "skipped": 0, "total": 1}

    class FakeMemoryClient:
        @classmethod
        def dev(cls, user_id="developer", **kwargs):
            return FakeClient()

        @classmethod
        def from_env(cls, **kwargs):
            return FakeClient()

    path = tmp_path / "profile.json"
    path.write_text(json.dumps(profile))
    monkeypatch.setattr(cli, "MemoryClient", FakeMemoryClient)

    result = cli.cmd_import(SimpleNamespace(user="bob", file=str(path)))
    captured_out = capsys.readouterr()

    assert result == 0
    assert captured["profile"]["schema_version"] == 1
    assert captured["target_user_id"] == "bob"
    assert captured["skip_duplicates"] is True
    assert "Imported 1 memories for user bob" in captured_out.out


def test_benchmark_import_reports_count_preserving_result(monkeypatch, capsys):
    class FakeClient:
        def store_batch(self, user_id, items, **kwargs):
            return [f"id-{idx}" for idx, _ in enumerate(items)]

        def export_user(self, user_id):
            return {
                "schema_version": 1,
                "user_id": user_id,
                "memories": [{"id": f"id-{idx}", "content": f"fact-{idx}"} for idx in range(5)],
            }

        def import_profile(self, profile, *, target_user_id=None, skip_duplicates=True):
            return {"imported": len(profile["memories"]), "skipped": 0, "total": len(profile["memories"])}

        def list_memories(self, user_id, namespace=None):
            return [{"memory_id": f"id-{idx}"} for idx in range(5)]

        def delete_user(self, user_id):
            return 5

    monkeypatch.setattr(cli, "_memory_client_for_cli", lambda user_id: FakeClient())

    result = cli.cmd_benchmark_import(SimpleNamespace(memories=5, json=True))
    captured = capsys.readouterr()
    payload = json.loads(captured.out)

    assert result == 0
    assert payload["ok"] is True
    assert payload["returned_ids"] == 5
    assert payload["unique_ids"] == 5
    assert payload["imported"] == 5
    assert payload["listed"] == 5
    assert payload["exported"] == 5
