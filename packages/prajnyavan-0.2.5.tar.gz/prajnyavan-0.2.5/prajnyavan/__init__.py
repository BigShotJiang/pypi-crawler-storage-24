"""
Prajnyavan - persistent, emotionally-weighted memory for any LLM.

Quick start:
    pip install prajnyavan[openai]

    from prajnyavan import MemoryClient, get_token
"""

import re
from pathlib import Path
from importlib.metadata import PackageNotFoundError, version as _dist_version

try:
    from .async_client import AsyncMemoryClient, AsyncSessionMemory
except ImportError:  # pragma: no cover - optional httpx dependency
    AsyncMemoryClient = None  # type: ignore[assignment]
    AsyncSessionMemory = None  # type: ignore[assignment]

try:
    from .integrations.ollama import OllamaChatMemory
except ImportError:  # pragma: no cover - optional local integration path
    OllamaChatMemory = None  # type: ignore[assignment]

from .client import MemoryClient, SessionMemory, auto_client, get_token
from .exceptions import (
    DimensionMismatchError,
    MemoryNotFoundError,
    PIIBlockedError,
    PrajnyavanAuthError,
    PrajnyavanConfigError,
    PrajnyavanConnectionError,
    PrajnyavanError,
    PrajnyavanSetupError,
    QuotaError,
)

def _read_version_from_file(path: Path, pattern: str) -> str | None:
    try:
        match = re.search(pattern, path.read_text(encoding="utf-8"))
        if match:
            return match.group(1)
    except Exception:
        return None
    return None


def _module_version() -> str:
    module_dir = Path(__file__).resolve().parent
    repo_pyproject = module_dir.parent / "pyproject.toml"
    if repo_pyproject.exists():
        version = _read_version_from_file(repo_pyproject, r'(?m)^version\s*=\s*"([^"]+)"')
        if version:
            return version

    for dist_info in module_dir.parent.glob("prajnyavan-*.dist-info"):
        metadata = dist_info / "METADATA"
        version = _read_version_from_file(metadata, r"(?m)^Version:\s*([^\s]+)")
        if version:
            return version

    try:
        return _dist_version("prajnyavan")
    except PackageNotFoundError:
        return "0.2.5"
    except Exception:
        return "0.2.5"

__version__ = _module_version()

__all__ = [
    "MemoryClient",
    "SessionMemory",
    "AsyncMemoryClient",
    "AsyncSessionMemory",
    "OllamaChatMemory",
    "get_token",
    "auto_client",
    "PrajnyavanError",
    "PrajnyavanConnectionError",
    "PrajnyavanAuthError",
    "PrajnyavanSetupError",
    "PrajnyavanConfigError",
    "DimensionMismatchError",
    "QuotaError",
    "MemoryNotFoundError",
    "PIIBlockedError",
]
