from __future__ import annotations

import json
from typing import Any, Dict, List

from prajnyavan import MemoryClient


class OpenAIChatMemory:
    """
    Prepend Prajnyavan context to OpenAI ChatCompletion calls.
    Uses get_context() - respects token budget so the system
    message never grows unbounded.
    """

    def __init__(
        self,
        user_id: str,
        max_tokens: int = 400,
        client: MemoryClient | None = None,
        **kwargs: Any,
    ) -> None:
        self.user_id = user_id
        self.max_tokens = max_tokens
        self.client = client or MemoryClient.dev(user_id=user_id, **kwargs)

    def build_context(self, query: str) -> str:
        result = self.client.get_context(
            self.user_id,
            query,
            max_tokens=self.max_tokens,
        )
        return result.get("context", "")

    def augment_messages(
        self, messages: List[Dict[str, str]]
    ) -> List[Dict[str, str]]:
        last_user = ""
        for message in reversed(messages):
            if message.get("role") == "user":
                last_user = message.get("content", "")
                break
        context = self.build_context(last_user)
        if not context:
            return messages
        return [{"role": "system", "content": context}] + messages

    def tool_definition(self) -> Dict[str, Any]:
        return {
            "type": "function",
            "function": {
                "name": "prajnyavan_get_context",
                "description": (
                    "Get compressed memory context within a token budget. "
                    "Use before answering any user question that might benefit "
                    "from remembering past conversations."
                ),
                "parameters": {
                    "type": "object",
                    "properties": {
                        "query": {
                            "type": "string",
                            "description": "What to search for in memory",
                        },
                        "max_tokens": {
                            "type": "integer",
                            "default": self.max_tokens,
                            "description": "Token budget for the context string",
                        },
                    },
                    "required": ["query"],
                },
            },
        }

    def tool_call(self, query: str, max_tokens: int | None = None) -> str:
        result = self.client.get_context(
            self.user_id,
            query,
            max_tokens=max_tokens or self.max_tokens,
        )
        return json.dumps(result)
