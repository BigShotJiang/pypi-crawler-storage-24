from __future__ import annotations

from typing import List

from prajnyavan import MemoryClient

try:
    from llama_index.core.retrievers import BaseRetriever
    from llama_index.core.schema import NodeWithScore, TextNode
except Exception:
    BaseRetriever = object  # type: ignore
    NodeWithScore = None  # type: ignore
    TextNode = None  # type: ignore


class PrajnyavanRetriever(BaseRetriever):
    """
    LlamaIndex retriever backed by Prajnyavan memory.
    Uses get_context() - returns a single compressed node
    instead of N raw search results.
    Requires: pip install prajnyavan[llamaindex]
    """

    def __init__(
        self,
        user_id: str,
        max_tokens: int = 400,
        client: MemoryClient | None = None,
        **kwargs,
    ) -> None:
        if BaseRetriever is object:
            raise ImportError("Install prajnyavan[llamaindex] to use PrajnyavanRetriever")
        super().__init__()
        self.user_id = user_id
        self.max_tokens = max_tokens
        self.client = client or MemoryClient.dev(user_id=user_id, **kwargs)

    def _get_relevant_nodes(
        self, query: str
    ) -> List[NodeWithScore]:  # type: ignore[override]
        result = self.client.get_context(
            self.user_id,
            query,
            max_tokens=self.max_tokens,
        )
        context_text = result.get("context", "")
        if not context_text or TextNode is None or NodeWithScore is None:
            return []
        node = TextNode(
            text=context_text,
            metadata={
                "tokens_used": result.get("tokens_used", 0),
                "compression_ratio": result.get("compression_ratio", 0.0),
                "facts_included": result.get("facts_included", 0),
            },
        )
        return [NodeWithScore(node=node, score=1.0)]

    async def _aget_relevant_nodes(
        self, query: str
    ) -> List[NodeWithScore]:  # type: ignore[override]
        return self._get_relevant_nodes(query)
