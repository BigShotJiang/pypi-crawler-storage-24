"""
Ollama integration helper.
"""

from __future__ import annotations

from typing import Any, Dict, List

from ..client import MemoryClient


class OllamaChatMemory:
    """Inject Prajnyavan context into Ollama chat message lists."""

    def __init__(self, user_id: str, max_tokens: int = 400, **kwargs: Any) -> None:
        self.user_id = user_id
        self.max_tokens = max_tokens
        self.client = MemoryClient.dev(user_id=user_id, **kwargs)

    def build_context(self, query: str) -> str:
        result = self.client.get_context(self.user_id, query, max_tokens=self.max_tokens)
        return result.get("context", "")

    def augment_messages(self, messages: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        last_user = next(
            (message.get("content", "") for message in reversed(messages) if message.get("role") == "user"),
            "",
        )
        context = self.build_context(last_user)
        if not context:
            return messages
        return [{"role": "system", "content": context}] + messages
