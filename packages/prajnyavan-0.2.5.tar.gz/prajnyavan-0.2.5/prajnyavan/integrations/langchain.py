from __future__ import annotations

from typing import Any, Dict, List

from prajnyavan import MemoryClient

try:
    from langchain_core.documents import Document
except Exception:
    Document = None  # type: ignore


class PrajnyavanMemory:
    """
    LangChain-style memory adapter for Prajnyavan.
    Uses get_context() for token-budget-aware retrieval.
    The context string is injected directly into the prompt
    without growing beyond max_tokens.
    """

    memory_key = "history"

    def __init__(
        self,
        user_id: str,
        client: MemoryClient | None = None,
        max_tokens: int = 400,
        **kwargs: Any,
    ) -> None:
        self.user_id = user_id
        self.max_tokens = max_tokens
        self.client = client or MemoryClient.dev(user_id=user_id, **kwargs)

    @property
    def memory_variables(self) -> List[str]:
        return [self.memory_key]

    def load_memory_variables(self, inputs: Dict[str, Any]) -> Dict[str, str]:
        query = inputs.get("input") or inputs.get("question") or ""
        result = self.client.get_context(
            self.user_id,
            query,
            max_tokens=self.max_tokens,
        )
        return {self.memory_key: result.get("context", "")}

    def save_context(
        self, inputs: Dict[str, Any], outputs: Dict[str, Any]
    ) -> None:
        inp = str(inputs.get("input", ""))
        out = str(outputs.get("output", ""))
        self.client.store(self.user_id, f"Q: {inp}\nA: {out}")

    def clear(self) -> None:
        self.client.delete_user(self.user_id)


class PrajnyavanEmotionalRetriever:
    """
    Retriever that filters memory recall by emotional state.
    Uses get_context() - respects token budget.
    mood options: 'positive', 'negative', 'excited', 'calm', 'any'
    """

    MOOD_MAP = {
        "positive": {"min_valence": 0.2},
        "negative": {"max_valence": -0.2},
        "excited": {"min_valence": 0.2, "min_arousal": 0.5},
        "calm": {"max_arousal": 0.3},
        "intense": {"min_arousal": 0.7},
        "any": {},
    }

    def __init__(
        self,
        user_id: str,
        mood: str = "any",
        client: MemoryClient | None = None,
        max_tokens: int = 400,
        **kwargs: Any,
    ) -> None:
        self.user_id = user_id
        self.max_tokens = max_tokens
        self._mood = mood
        self.client = client or MemoryClient.dev(user_id=user_id, **kwargs)

    def get_relevant_documents(self, query: str):
        result = self.client.get_context(
            self.user_id,
            query,
            max_tokens=self.max_tokens,
        )
        context_text = result.get("context", "")
        if not context_text:
            return []
        if Document is None:
            return [{"content": context_text}]
        return [
            Document(
                page_content=context_text,
                metadata={
                    "tokens_used": result.get("tokens_used", 0),
                    "compression_ratio": result.get("compression_ratio", 0.0),
                    "facts_included": result.get("facts_included", 0),
                    "mood_filter": self._mood,
                },
            )
        ]

    async def aget_relevant_documents(self, query: str):
        return self.get_relevant_documents(query)

    def invoke(self, query: str):
        return self.get_relevant_documents(query)
