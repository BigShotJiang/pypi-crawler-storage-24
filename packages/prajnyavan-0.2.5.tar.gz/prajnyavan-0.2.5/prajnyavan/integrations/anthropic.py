from __future__ import annotations

from typing import Any, Dict, List

from prajnyavan import MemoryClient


class AnthropicMemoryAugmentor:
    """
    Inject Prajnyavan recall into Anthropic-style message lists.
    Uses get_context() - respects token budget.
    context_window: how many recent user turns to use as query.
    """

    def __init__(
        self,
        user_id: str,
        max_tokens: int = 400,
        context_window: int = 3,
        client: MemoryClient | None = None,
        **kwargs: Any,
    ) -> None:
        self.user_id = user_id
        self.max_tokens = max_tokens
        self.context_window = max(1, context_window)
        self.client = client or MemoryClient.dev(user_id=user_id, **kwargs)

    def build_query(self, messages: List[Dict[str, str]]) -> str:
        last_k = [
            message.get("content", "")
            for message in messages
            if message.get("role") == "user"
        ][-self.context_window :]
        return " ".join(reversed([message.strip() for message in last_k if message.strip()]))

    def augment(
        self, messages: List[Dict[str, str]]
    ) -> List[Dict[str, str]]:
        query = self.build_query(messages)
        if not query:
            return messages
        result = self.client.get_context(
            self.user_id,
            query,
            max_tokens=self.max_tokens,
        )
        context = result.get("context", "")
        if not context:
            return messages
        preface = {
            "role": "user",
            "content": context,
        }
        return [preface] + messages
