"""
Integration helpers for popular LLM frameworks.
"""

try:
    from .langchain import PrajnyavanMemory, PrajnyavanEmotionalRetriever
except ImportError:  # pragma: no cover - optional integration dependency
    PrajnyavanMemory = None  # type: ignore[assignment]
    PrajnyavanEmotionalRetriever = None  # type: ignore[assignment]

try:
    from .llamaindex import PrajnyavanRetriever
except ImportError:  # pragma: no cover - optional integration dependency
    PrajnyavanRetriever = None  # type: ignore[assignment]

try:
    from .openai import OpenAIChatMemory
except ImportError:  # pragma: no cover - optional integration dependency
    OpenAIChatMemory = None  # type: ignore[assignment]

try:
    from .anthropic import AnthropicMemoryAugmentor
except ImportError:  # pragma: no cover - optional integration dependency
    AnthropicMemoryAugmentor = None  # type: ignore[assignment]

from .ollama import OllamaChatMemory

__all__ = [
    "PrajnyavanMemory",
    "PrajnyavanEmotionalRetriever",
    "PrajnyavanRetriever",
    "OpenAIChatMemory",
    "AnthropicMemoryAugmentor",
    "OllamaChatMemory",
]
