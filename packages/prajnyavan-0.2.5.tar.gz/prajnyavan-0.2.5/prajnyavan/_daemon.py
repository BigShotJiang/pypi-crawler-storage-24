"""
Daemon helpers for zero-config local use.

Shared by cli.py and client.py to avoid circular imports.
"""
from __future__ import annotations

import json
import os
import platform
import secrets
import socket
import subprocess
import sys
import time
import csv
import shutil
import re
from pathlib import Path
from typing import Any, Dict, Optional

import requests
from importlib.metadata import PackageNotFoundError, version as _dist_version

try:
    import fcntl  # type: ignore
except ImportError:  # Windows
    fcntl = None  # sentinel

from .exceptions import (
    PrajnyavanAuthError,
    PrajnyavanConfigError,
    PrajnyavanConnectionError,
    PrajnyavanSetupError,
)

def _resolve_base_dir() -> Path:
    override = os.environ.get("PRAJNYAVAN_HOME")
    if override:
        return Path(override).expanduser().resolve()
    return (Path.home() / ".prajnyavan").resolve()


def _env_int(name: str, default: int) -> int:
    try:
        return int(os.environ.get(name, str(default)))
    except ValueError:
        return default


BASE_DIR = _resolve_base_dir()
DEV_CONFIG = BASE_DIR / "dev.json"
PID_FILE = BASE_DIR / "prajnyavan.pid"
STARTUP_LOCK = BASE_DIR / "startup.lock"
DAEMON_LOG = BASE_DIR / "daemon.log"
MODEL_CACHE = BASE_DIR / "models"
LOCK_FILE = BASE_DIR / "prajnyavan.lock"
DEFAULT_ADDR = "127.0.0.1"
DEFAULT_PORT = _env_int("PRAJNYAVAN_DEV_PORT", 9999)
PORT_RANGE = _env_int("PRAJNYAVAN_DEV_PORT_RANGE", 10)
# Allow slower CI machines to wait longer for first health check.
STARTUP_TIMEOUT = float(os.environ.get("PRAJNYAVAN_STARTUP_TIMEOUT", "60"))
ALLOW_FAKE = os.environ.get("PRAJNYAVAN_ALLOW_FAKE") == "1" or os.environ.get("GITHUB_ACTIONS") == "true"
GITHUB_RELEASES = "https://github.com/prajnyavan/prajnyavan/releases/download"
USE_UDS = os.environ.get("PRAJNYAVAN_USE_UDS", "0") == "1"
UDS_PATH = BASE_DIR / "prajnyavan.sock"


def _package_version() -> str:
    try:
        pyproject = Path(__file__).resolve().parents[1] / "pyproject.toml"
        match = re.search(r'(?m)^version\s*=\s*"([^"]+)"', pyproject.read_text(encoding="utf-8"))
        if match:
            return match.group(1)
    except Exception:
        pass

    try:
        return _dist_version("prajnyavan")
    except PackageNotFoundError:
        pass
    except Exception:
        pass

    return "0.2.5"


def _platform_dir() -> str:
    system = platform.system().lower()
    machine = platform.machine().lower()
    if system.startswith("linux"):
        return "linux-arm64" if machine in ("aarch64", "arm64") else "linux"
    if system.startswith("darwin"):
        return "macos"
    if system.startswith("windows"):
        return "windows"
    return system


def _binary_path() -> Path:
    name = "prajnyavan_service.exe" if platform.system().lower().startswith("windows") else "prajnyavan_service"
    path = Path(__file__).resolve().parent / "bin" / _platform_dir() / name
    if path.exists() and not platform.system().lower().startswith("windows"):
        # ensure executable bit
        path.chmod(path.stat().st_mode | 0o111)
    return path


def _pid_alive(pid: int) -> bool:
    if not pid or pid <= 0:
        return False

    if platform.system().lower().startswith("windows"):
        try:
            result = subprocess.run(
                ["tasklist", "/FI", f"PID eq {pid}", "/FO", "CSV", "/NH"],
                capture_output=True,
                text=True,
                errors="ignore",
                check=False,
                timeout=5,
            )
        except (OSError, subprocess.TimeoutExpired):
            return False

        for line in result.stdout.splitlines():
            row = next(csv.reader([line]), [])
            if len(row) >= 2 and row[1] == str(pid):
                return True
        return False

    try:
        os.kill(pid, 0)
        return True
    except Exception:
        return False


def _find_free_port(start: int = DEFAULT_PORT) -> int:
    for i in range(PORT_RANGE):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            try:
                s.bind((DEFAULT_ADDR, start + i))
                return start + i
            except OSError:
                continue
    raise PrajnyavanSetupError(f"No free port in {DEFAULT_PORT}-{DEFAULT_PORT + PORT_RANGE}")


def _can_fallback_to_mock() -> bool:
    if os.environ.get("PRAJNYAVAN_REAL_DAEMON", "0") == "1":
        return False
    return ALLOW_FAKE


def _wait_healthy(base_url: str, timeout: float = STARTUP_TIMEOUT, process: Optional[subprocess.Popen] = None) -> bool:
    """Probe multiple health endpoints until one returns HTTP 200."""
    endpoints = ["/health", "/v1/health", "/v1/ready"]
    deadline = time.time() + timeout
    while time.time() < deadline:
        if process is not None and process.poll() is not None:
            return False
        for path in endpoints:
            try:
                if requests.get(f"{base_url.rstrip('/')}{path}", timeout=2).ok:
                    return True
            except Exception:
                continue
        time.sleep(0.5)
    return False


def _load_config() -> Optional[Dict[str, Any]]:
    try:
        return json.loads(DEV_CONFIG.read_text()) if DEV_CONFIG.exists() else None
    except Exception:
        return None


def _safe_unlink(path: Path) -> None:
    try:
        path.unlink(missing_ok=True)
    except Exception:
        pass


def _save_config(data: Dict[str, Any]) -> None:
    BASE_DIR.mkdir(parents=True, exist_ok=True)
    DEV_CONFIG.write_text(json.dumps(data, indent=2))
    try:
        DEV_CONFIG.chmod(0o600)
    except Exception:
        pass


def _rotate_log(max_mb: Optional[float] = None) -> None:
    """
    Simple size-based log rotation to keep daemon.log sane on Windows where tools
    like logrotate are absent. Keeps up to 2 backups by default.
    """
    try:
        max_mb = float(max_mb) if max_mb is not None else float(os.environ.get("PRAJNYAVAN_LOG_MAX_MB", "5"))
        backups = 2
        if not DAEMON_LOG.exists() or max_mb <= 0:
            return
        size_mb = DAEMON_LOG.stat().st_size / 1e6
        if size_mb <= max_mb:
            return
        for i in range(backups, 0, -1):
            src = DAEMON_LOG.with_suffix(f".log.{i}")
            dst = DAEMON_LOG.with_suffix(f".log.{i+1}")
            if src.exists():
                src.replace(dst)
        DAEMON_LOG.replace(DAEMON_LOG.with_suffix(".log.1"))
    except Exception:
        # Never let rotation failures block startup.
        pass


def _tail_log(n: int = 20) -> str:
    try:
        return "\n".join(DAEMON_LOG.read_text().splitlines()[-n:])
    except Exception:
        return ""


def _get_token(base_url: str) -> str:
    resp = requests.post(
        f"{base_url}/auth/token",
        json={"user_id": "developer", "capabilities": ["read", "write"]},
        timeout=8,
    )
    resp.raise_for_status()
    return f"Bearer {resp.json()['token']}"


def _try_download_binary(dest: Path) -> None:
    import urllib.request
    try:
        from importlib.metadata import version
        pkg_version = version("prajnyavan")
    except Exception:
        pkg_version = "latest"

    plat = _platform_dir()
    name = "prajnyavan_service.exe" if plat == "windows" else "prajnyavan_service"
    url = f"{GITHUB_RELEASES}/v{pkg_version}/{plat}/{name}"

    print(f"[prajnyavan] Binary not found. Downloading from {url} ...")
    dest.parent.mkdir(parents=True, exist_ok=True)
    try:
        urllib.request.urlretrieve(url, dest)
        if not plat.startswith("windows"):
            dest.chmod(dest.stat().st_mode | 0o111)
        print(f"[prajnyavan] Binary downloaded to {dest}")
    except Exception as e:
        if dest.exists():
            dest.unlink()
        raise PrajnyavanSetupError(
            f"Failed to download binary: {e}\n"
            f"Manual fix: download {name} from {GITHUB_RELEASES}/v{{version}}/ and place at {dest}"
        ) from e


def _version_matches_package(health: Dict[str, Any], expected_version: Optional[str] = None) -> bool:
    if not health:
        return False
    reported_version = str(health.get("version") or "").strip()
    if not reported_version or reported_version == "mock":
        return False
    return reported_version == (expected_version or _package_version())


def _terminate_pid(pid: int) -> None:
    if pid <= 0:
        return
    if platform.system().lower().startswith("windows"):
        subprocess.run(
            ["taskkill", "/PID", str(pid), "/F", "/T"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            check=False,
        )
        return
    try:
        os.kill(pid, 15)
    except Exception:
        pass


def _wait_for_pid_exit(pid: int, timeout: float = 10.0, interval: float = 0.2) -> bool:
    deadline = time.time() + timeout
    while time.time() < deadline:
        if not _pid_alive(pid):
            return True
        time.sleep(interval)
    return not _pid_alive(pid)


def _lock_file(fd):
    if platform.system().lower().startswith("windows"):
        import msvcrt

        try:
            msvcrt.locking(fd.fileno(), msvcrt.LK_NBLCK, 1)
            return True
        except Exception:
            return False
    if fcntl is None:
        return True
    fcntl.flock(fd, fcntl.LOCK_EX)
    return True


def _unlock_file(fd):
    if platform.system().lower().startswith("windows"):
        import msvcrt

        try:
            msvcrt.locking(fd.fileno(), msvcrt.LK_UNLCK, 1)
        except Exception:
            pass
    elif fcntl:
        try:
            fcntl.flock(fd, fcntl.LOCK_UN)
        except Exception:
            pass


def ensure_daemon_running() -> Dict[str, Any]:
    """
    Idempotently start the bundled service and return dev config (base_url, token, pid).
    """
    BASE_DIR.mkdir(parents=True, exist_ok=True)
    lock_fd = open(STARTUP_LOCK, "w")
    try:
        _lock_file(lock_fd)
        expected_version = _package_version()

        cfg = _load_config()
        if cfg:
            pid = cfg.get("pid")
            health = {}
            try:
                response = requests.get(f"{cfg['base_url']}/health", timeout=2)
                if response.ok:
                    health = response.json()
                if _version_matches_package(health, expected_version):
                    return cfg
            except Exception:
                pass
            if pid and _pid_alive(pid):
                _terminate_pid(pid)
                _wait_for_pid_exit(pid)
            _safe_unlink(DEV_CONFIG)
            _safe_unlink(PID_FILE)

        # CI-friendly fast path: use mock daemon when allowed.
        if _can_fallback_to_mock():
            return _start_mock_daemon()

        binary = _binary_path()
        if not binary.exists():
            _try_download_binary(binary)
        if not binary.exists():
            if _can_fallback_to_mock():
                return _start_mock_daemon()
            raise PrajnyavanSetupError(
                f"Binary not found at {binary}. "
                "Fix: pip install --upgrade prajnyavan\n"
                f"Log: {DAEMON_LOG}"
            )

        secret = os.environ.get("BRAIN_SECRET_KEY") or secrets.token_urlsafe(32)
        env = os.environ.copy()
        env.update({"BRAIN_SECRET_KEY": secret})
        env.setdefault("PRAJNYAVAN_HOME", str(BASE_DIR))
        env.setdefault("PRAJNYAVAN_LOCK_PATH", str(LOCK_FILE))
        runtime_root = BASE_DIR / "runtime"
        data_root = runtime_root / "data"
        runtime_tmp = runtime_root / "tmp"
        data_root.mkdir(parents=True, exist_ok=True)
        runtime_tmp.mkdir(parents=True, exist_ok=True)
        env["PRAJNYAVAN_DB_PATH"] = str(data_root / "brain_state.db")
        env["PRAJNYAVAN_WAL_PATH"] = str(data_root / "brain.wal")
        env["PRAJNYAVAN_ARCHIVE_PATH"] = str(data_root / "archive")
        env["PRAJNYAVAN_SEMANTIC_PATH"] = str(data_root / "semantic")
        env["PRAJNYAVAN_EPISODIC_PATH"] = str(data_root / "episodic")
        env["PRAJNYAVAN_IDEMPOTENCY_DB_PATH"] = str(data_root / "idempotency.db")
        env["PRAJNYAVAN_IDEMPOTENCY_BLOOM_PATH"] = str(data_root / "idempotency.bloom")
        env["PRAJNYAVAN_AUTH_DB_PATH"] = str(data_root / "auth.db")
        env["PRAJNYAVAN_SALT_PATH"] = str(data_root / "salt.bin")
        if platform.system().lower().startswith("windows"):
            appdata_root = runtime_root / "appdata"
            localappdata_root = runtime_root / "localappdata"
            appdata_root.mkdir(parents=True, exist_ok=True)
            localappdata_root.mkdir(parents=True, exist_ok=True)
            env["APPDATA"] = str(appdata_root)
            env["LOCALAPPDATA"] = str(localappdata_root)
            env["TMP"] = str(runtime_tmp)
            env["TEMP"] = str(runtime_tmp)

        # Default dev-friendly flags on Windows to avoid heavy MAS paths and auth in local mode.
        if os.environ.get("RUN_PRAJNYAVAN_INTEGRATION") == "1" or os.environ.get("PRAJNYAVAN_FORCE_FAST_DEV") == "1":
            env.setdefault("PRAJNYAVAN_FAST_DEV", "1")
            env.setdefault("PRAJNYAVAN_DEV_NOAUTH", "1")

        if USE_UDS and not platform.system().lower().startswith("windows"):
            uds_path = str(UDS_PATH)
            env["PRAJNYAVAN_UDS"] = uds_path
            base_url = f"http+unix://{UDS_PATH}"
            args = [str(binary), "--uds", uds_path]
        else:
            port = _find_free_port()
            env["BIND_ADDR"] = DEFAULT_ADDR
            env["PORT"] = str(port)
            base_url = f"http://{DEFAULT_ADDR}:{port}"
            args = [str(binary)]

        _rotate_log()
        log_fh = open(DAEMON_LOG, "a")
        creationflags = subprocess.CREATE_NO_WINDOW if platform.system().lower().startswith("windows") else 0
        proc = subprocess.Popen(args, stdout=log_fh, stderr=log_fh, cwd=str(BASE_DIR), env=env, creationflags=creationflags)
        log_fh.close()
        PID_FILE.write_text(str(proc.pid))

        if not _wait_healthy(base_url, process=proc):
            if proc.poll() is None:
                proc.kill()
            log_tail = _tail_log()
            if _can_fallback_to_mock():
                return _start_mock_daemon()
            raise PrajnyavanSetupError(
                f"Daemon failed to start within {int(STARTUP_TIMEOUT)}s.\nLast log lines:\n{log_tail}\nFull log: {DAEMON_LOG}"
            )

        token = _get_token(base_url)
        cfg = {
            "base_url": base_url,
            "port": env.get("PORT"),
            "pid": proc.pid,
            "token": token,
            "started_at": int(time.time()),
        }
        _save_config(cfg)
        print(f"[prajnyavan] daemon started on {base_url} (pid={proc.pid})")
        return cfg
    finally:
        _unlock_file(lock_fd)
        lock_fd.close()


def _start_mock_daemon() -> Dict[str, Any]:
    """Start a lightweight in-process mock daemon for CI when native binary is absent."""
    port = _find_free_port()
    base_url = f"http://{DEFAULT_ADDR}:{port}"
    args = [sys.executable, "-m", "prajnyavan.mock_daemon", "--port", str(port)]
    _rotate_log()
    log_fh = open(DAEMON_LOG, "a")
    proc = subprocess.Popen(args, stdout=log_fh, stderr=log_fh, cwd=str(BASE_DIR))
    log_fh.close()
    PID_FILE.write_text(str(proc.pid))
    if not _wait_healthy(base_url, timeout=5.0, process=proc):
        if proc.poll() is None:
            proc.kill()
        log_tail = _tail_log()
        raise PrajnyavanSetupError(
            f"Mock daemon failed to start within {int(STARTUP_TIMEOUT)}s.\nLast log lines:\n{log_tail}\nFull log: {DAEMON_LOG}"
        )
    token = "Bearer dev-token"
    cfg = {
        "base_url": base_url,
        "port": str(port),
        "pid": proc.pid,
        "token": token,
        "started_at": int(time.time()),
        "mock": True,
    }
    _save_config(cfg)
    print(f"[prajnyavan] mock daemon started on {base_url} (pid={proc.pid}) [CI/dev-only fallback]")
    return cfg


__all__ = [
    "ensure_daemon_running",
    "_load_config",
    "_save_config",
    "_pid_alive",
    "_package_version",
    "_binary_path",
    "_platform_dir",
    "_try_download_binary",
    "DEV_CONFIG",
    "DAEMON_LOG",
    "MODEL_CACHE",
    "BASE_DIR",
    "PID_FILE",
    "LOCK_FILE",
    "UDS_PATH",
    "USE_UDS",
]
