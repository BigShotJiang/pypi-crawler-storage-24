﻿from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional, Dict


@dataclass
class StoreRequest:
    content: str
    user_id: str
    embedding: Optional[List[float]] = None
    tags: List[str] = field(default_factory=list)
    category: Optional[str] = None
    ttl_days: Optional[int] = None
    importance: float = 0.5
    idempotency_key: Optional[str] = None


@dataclass
class SearchResult:
    memory_id: str
    content: str
    score: float
    valence: float
    arousal: float
    salience: float
    tags: List[str]
    category: Optional[str]
    created_at: int


@dataclass
class HealthResponse:
    version: str
    uptime_seconds: int
    current_memory_count: int
    embedding_dim: int
    queue_depth: int
    wal_ok: bool
    db_ok: bool


@dataclass
class MemoryEvent:
    event_type: str
    id: str
    tags: List[str] = field(default_factory=list)
