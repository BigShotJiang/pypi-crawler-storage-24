"""
Lightweight mock daemon used in CI when the native Rust binary is unavailable.
Implements just enough of the API for dev-roundtrip tests:
- /health, /v1/health, /v1/ready
- /auth/token
- /memory (POST store)
- /memory/search (POST search)
- /memory/context (POST compact context)
- /memory/export/<user_id> (GET portable profile)
- /memory/import (POST portable profile import)
"""
from __future__ import annotations

import argparse
import json
import threading
import time
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from typing import Dict, List
from urllib.parse import parse_qs, urlparse
from uuid import uuid4

MEMORIES: List[Dict] = []
START_TIME = time.time()
TOTAL_STORES_EVER = 0


def _approx_tokens(text: str) -> int:
    return (len(text) + 3) // 4 if text else 0


def _query_terms(text: str) -> List[str]:
    terms = []
    for raw in text.lower().split():
        token = "".join(ch for ch in raw if ch.isalnum())
        if len(token) > 2:
            terms.append(token)
    return terms


def _score_memory(query: str, content: str) -> float:
    query_l = query.lower()
    content_l = content.lower()
    if not query_l:
        return 0.0
    if query_l in content_l:
        return 1.0

    terms = _query_terms(query_l)
    if not terms:
        return 0.0
    overlap = sum(1 for term in terms if term in content_l)
    return overlap / len(terms)


def _matching_memories(
    query: str,
    user_id: str | None,
    session_id: str | None = None,
    limit: int | None = None,
) -> List[Dict]:
    results = []
    for memory in MEMORIES:
        if session_id:
            if memory.get("session_id") != session_id:
                continue
        elif user_id and memory.get("user_id") != user_id:
            continue

        content = memory.get("content", "")
        score = _score_memory(query, content)
        if query and score <= 0.0:
            continue

        results.append(
            {
                "id": memory["memory_id"],
                "memory_id": memory["memory_id"],
                "content": content,
                "content_text": content,
                "score": score,
                "relevance_score": score,
                "importance": 0.5,
                "salience": 0.5,
                "valence": 0.0,
                "arousal": 0.0,
                "tags": list(memory.get("tags") or []),
                "category": memory.get("category"),
                "created_at": memory.get("created_at", 0),
            }
        )

    results.sort(key=lambda item: item["score"], reverse=True)
    if limit is not None:
        results = results[:limit]
    return results


class Handler(BaseHTTPRequestHandler):
    server_version = "prajnyavan-mock/0.1"

    def _json(self, code: int, payload: Dict) -> None:
        body = json.dumps(payload).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, fmt, *args):
        # reduce noise in CI
        return

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path

        if path in ("/health", "/v1/health", "/v1/ready"):
            return self._json(
                200,
                {
                    "status": "ok",
                    "version": "mock",
                    "uptime_seconds": int(time.time() - START_TIME),
                    "total_stores_ever": TOTAL_STORES_EVER,
                    "current_memory_count": len(MEMORIES),
                    "embedding_dim": 768,
                },
            )
        if path in ("/brain/emotion", "/v1/brain/emotion"):
            return self._json(
                200,
                {
                    "primary_emotion": "None",
                    "valence": 0.0,
                    "arousal": 0.0,
                    "mood": "neutral",
                },
            )
        if path.startswith("/brain/emotion/") or path.startswith("/v1/brain/emotion/"):
            user_id = path.rsplit("/", 1)[-1]
            memory_count = sum(1 for memory in MEMORIES if memory.get("user_id") == user_id)
            return self._json(
                200,
                {
                    "primary_emotion": "None",
                    "valence": 0.0,
                    "arousal": 0.0,
                    "dominance": 0.5,
                    "memory_count": memory_count,
                },
            )
        if path.startswith("/memory/export/") or path.startswith("/v1/memory/export/"):
            user_id = path.rsplit("/", 1)[-1]
            query = parse_qs(parsed.query)
            limit = int((query.get("limit") or ["500"])[0])
            offset = int((query.get("offset") or ["0"])[0])
            all_memories = [
                {
                    "id": memory["memory_id"],
                    "memory_id": memory["memory_id"],
                    "content": memory.get("content", ""),
                    "user_id": memory.get("user_id"),
                    "category": memory.get("category"),
                    "importance": memory.get("importance", 0.5),
                    "tags": list(memory.get("tags") or []),
                    "session_id": memory.get("session_id"),
                }
                for memory in MEMORIES
                if memory.get("user_id") == user_id
            ]
            page = all_memories[offset : offset + limit]
            return self._json(
                200,
                {
                    "schema_version": 1,
                    "user_id": user_id,
                    "memories": page,
                    "total": len(all_memories),
                    "offset": offset,
                    "limit": limit,
                    "has_more": offset + limit < len(all_memories),
                },
            )
        if path in ("/memory/stream", "/v1/memory/stream", "/memories/stream", "/v1/memories/stream"):
            query = parse_qs(parsed.query)
            session_id = (query.get("session_id") or [None])[0]
            user_id = (query.get("user_id") or [None])[0]
            seen = len(MEMORIES)
            deadline = time.time() + 5.0

            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream")
            self.send_header("Cache-Control", "no-cache")
            self.end_headers()

            while time.time() < deadline:
                for memory in MEMORIES[seen:]:
                    seen += 1
                    if session_id and memory.get("session_id") != session_id:
                        continue
                    if user_id and memory.get("user_id") != user_id:
                        continue
                    payload = {
                        "event_type": "stored",
                        "memory_id": memory["memory_id"],
                        "session_id": memory.get("session_id"),
                        "user_id": memory.get("user_id"),
                        "ts": int(time.time() * 1_000_000),
                    }
                    body = (
                        f"event: stored\n"
                        f"data: {json.dumps(payload)}\n\n"
                    ).encode("utf-8")
                    self.wfile.write(body)
                    self.wfile.flush()
                    return
                time.sleep(0.1)
            return
        return self._json(404, {"error": "not found"})

    def do_POST(self):
        global TOTAL_STORES_EVER
        length = int(self.headers.get("Content-Length", "0"))
        raw = self.rfile.read(length) if length else b"{}"
        try:
            data = json.loads(raw.decode("utf-8"))
        except Exception:
            data = {}

        if self.path == "/auth/token":
            return self._json(200, {"token": str(uuid4())})

        if self.path.endswith("/memory") or self.path.endswith("/memory/"):
            mem_id = str(uuid4())
            tags = list(data.get("tags") or [])
            MEMORIES.append(
                {
                    "memory_id": mem_id,
                    "user_id": data.get("user_id"),
                    "session_id": data.get("session_id"),
                    "content": data.get("content") or data.get("content_text", ""),
                    "tags": tags,
                    "category": data.get("category"),
                    "created_at": int(time.time()),
                }
            )
            TOTAL_STORES_EVER += 1
            return self._json(200, {"memory_id": mem_id, "id": mem_id, "tags": tags})

        if self.path.endswith("/memory/search") or self.path.endswith("/memory/search/"):
            q = (data.get("query") or "").lower()
            filters = data.get("filters") or {}
            user = data.get("user_id") or filters.get("person")
            session_id = filters.get("session_id")
            limit = data.get("k") or 5
            results = _matching_memories(q, user, session_id=session_id, limit=limit)
            filter_tags = list(filters.get("tags") or [])
            if filter_tags:
                results = [
                    result
                    for result in results
                    if all(tag in (result.get("tags") or []) for tag in filter_tags)
                ]
            if filters.get("category"):
                results = [
                    result
                    for result in results
                    if result.get("category") == filters.get("category")
                ]
            return self._json(200, {"results": results})

        if self.path.endswith("/memory/context") or self.path.endswith("/memory/context/"):
            user = data.get("user_id")
            query = data.get("query", "")
            max_tokens = int(data.get("max_tokens") or 500)
            session_id = data.get("session_id")
            matches = _matching_memories(
                query,
                None if session_id else user,
                session_id=session_id,
                limit=8,
            )

            header = f"Relevant memories about {user}:\n"
            used_tokens = _approx_tokens(header)
            lines = []
            for memory in matches:
                line = f"- ({memory['importance']:.2f} importance) {memory['content_text']}"
                line_tokens = _approx_tokens(line)
                if lines and used_tokens + line_tokens > max_tokens:
                    break
                lines.append(line)
                used_tokens += line_tokens

            context = header + ("\n".join(lines) if lines else "- (no relevant memories found)")
            return self._json(
                200,
                {
                    "context": context,
                    "tokens_used": _approx_tokens(context),
                    "facts_count": len(lines),
                    "compression_ratio": 0.0,
                },
            )

        if self.path.endswith("/memory/import") or self.path.endswith("/memory/import/"):
            profile = data.get("profile") or {}
            target_user = data.get("target_user_id") or profile.get("user_id")
            memories = list(profile.get("memories") or [])
            skip_duplicates = bool(data.get("skip_duplicates", True))
            imported = 0
            skipped = 0

            for memory in memories:
                source_id = memory.get("id") or memory.get("memory_id") or str(uuid4())
                if skip_duplicates and any(
                    existing.get("user_id") == target_user and existing.get("memory_id") == source_id
                    for existing in MEMORIES
                ):
                    skipped += 1
                    continue

                content = memory.get("content") or memory.get("content_text") or ""
                if not content:
                    skipped += 1
                    continue

                MEMORIES.append(
                    {
                        "memory_id": source_id,
                        "user_id": target_user,
                        "session_id": memory.get("session_id"),
                        "content": content,
                        "tags": list(memory.get("tags") or []),
                        "category": memory.get("category"),
                        "importance": memory.get("importance", 0.5),
                        "created_at": int(time.time()),
                    }
                )
                imported += 1

            return self._json(
                200,
                {
                    "imported": imported,
                    "skipped": skipped,
                    "total": len(memories),
                    "user_id": target_user,
                },
            )

        return self._json(404, {"error": "not found"})

    def do_DELETE(self):
        if self.path.startswith("/v1/memory/user/") or self.path.startswith("/memory/user/"):
            user_id = self.path.rsplit("/", 1)[-1]
            before = len(MEMORIES)
            MEMORIES[:] = [memory for memory in MEMORIES if memory.get("user_id") != user_id]
            return self._json(200, {"deleted": before - len(MEMORIES)})
        return self._json(404, {"error": "not found"})


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=9999)
    args = parser.parse_args()
    httpd = ThreadingHTTPServer(("127.0.0.1", args.port), Handler)
    threading.Thread(target=httpd.serve_forever, daemon=True).start()
    try:
        threading.Event().wait()  # block forever
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
