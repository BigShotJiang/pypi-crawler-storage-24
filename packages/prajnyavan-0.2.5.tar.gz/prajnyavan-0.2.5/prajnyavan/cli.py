"""
CLI entrypoint for Prajnyavan.
"""
from __future__ import annotations

import argparse
import contextlib
import csv
import io
import json
import os
import shutil
import signal
import subprocess
import sys
import time
from pathlib import Path
from urllib.parse import urlparse
from uuid import uuid4

import requests

# Console-script bootstrap: ensure the package location is on sys.path even when
# installed with --target or run from a copied executable on Windows.
_THIS_FILE = Path(__file__).resolve()
_CANDIDATE_PATHS = [
    _THIS_FILE.parent,
    _THIS_FILE.parent.parent,
    Path(sys.argv[0]).resolve().parent,
    Path(sys.argv[0]).resolve().parent.parent,
]
for _p in _CANDIDATE_PATHS:
    if _p.exists() and str(_p) not in sys.path:
        sys.path.insert(0, str(_p))

from ._daemon import (
    BASE_DIR,
    DAEMON_LOG,
    DEFAULT_ADDR,
    DEFAULT_PORT,
    DEV_CONFIG,
    LOCK_FILE,
    PORT_RANGE,
    PID_FILE,
    MODEL_CACHE,
    _find_free_port,
    _load_config,
    _package_version,
    _pid_alive,
    _rotate_log,
    ensure_daemon_running,
)
from .client import MemoryClient, get_token


def _tail_log(path: Path, n: int = 50) -> str:
    try:
        return "\n".join(path.read_text().splitlines()[-n:])
    except Exception:
        return ""


def _safe_unlink(path: Path) -> str | None:
    try:
        # On Windows, permission bits can block unlink; relax them best-effort.
        try:
            path.chmod(0o666)
        except Exception:
            pass
        path.unlink(missing_ok=True)
    except Exception as exc:
        if path.exists():
            return str(exc)
    return None


def _print_ascii(text: str) -> None:
    """Print text safely under cp1252 consoles by replacing non-ASCII glyphs."""
    safe = text.encode("ascii", "replace").decode("ascii", "replace")
    print(safe)


def _wait_for_pid_exit(pid: int, timeout: float = 10.0, interval: float = 0.2) -> bool:
    deadline = time.time() + timeout
    while time.time() < deadline:
        if not _pid_alive(pid):
            return True
        time.sleep(interval)
    return not _pid_alive(pid)


def _extract_port(url: str | None) -> int | None:
    if not url:
        return None
    try:
        return urlparse(url).port
    except ValueError:
        return None


def _find_pid_by_port(port: int | None) -> int | None:
    if not port:
        return None

    if os.name == "nt":
        try:
            result = subprocess.run(
                ["netstat", "-ano", "-p", "tcp"],
                capture_output=True,
                text=True,
                errors="ignore",
                check=False,
            )
        except OSError:
            return None

        suffix = f":{port}"
        for line in result.stdout.splitlines():
            parts = line.split()
            if len(parts) < 5 or parts[0].upper() != "TCP":
                continue
            local_addr = parts[1]
            state = parts[3].upper()
            if state != "LISTENING" or not local_addr.endswith(suffix):
                continue
            try:
                return int(parts[4])
            except ValueError:
                continue
        return None

    try:
        result = subprocess.run(
            ["lsof", "-nP", "-i", f"TCP:{port}", "-sTCP:LISTEN", "-t"],
            capture_output=True,
            text=True,
            check=False,
        )
    except OSError:
        return None

    for line in result.stdout.splitlines():
        try:
            return int(line.strip())
        except ValueError:
            continue
    return None


def _find_service_pid() -> int | None:
    pids = _find_service_pids()
    return pids[0] if len(pids) == 1 else None


def _find_mock_daemon_pids() -> list[int]:
    if os.name == "nt":
        try:
            result = subprocess.run(
                [
                    "powershell",
                    "-NoProfile",
                    "-Command",
                    "Get-CimInstance Win32_Process | "
                    "Where-Object { $_.Name -eq 'python.exe' -and $_.CommandLine -match 'prajnyavan\\.mock_daemon' } | "
                    "Select-Object -ExpandProperty ProcessId",
                ],
                capture_output=True,
                text=True,
                errors="ignore",
                check=False,
            )
        except OSError:
            return []
        return [
            int(line.strip())
            for line in result.stdout.splitlines()
            if line.strip().isdigit()
        ]

    try:
        result = subprocess.run(
            ["pgrep", "-f", "prajnyavan.mock_daemon"],
            capture_output=True,
            text=True,
            check=False,
        )
    except OSError:
        return []
    return [int(line.strip()) for line in result.stdout.splitlines() if line.strip().isdigit()]


def _find_service_pids() -> list[int]:
    pids: list[int] = []
    if os.name == "nt":
        try:
            result = subprocess.run(
                ["tasklist", "/FI", "IMAGENAME eq prajnyavan_service.exe", "/FO", "CSV", "/NH"],
                capture_output=True,
                text=True,
                errors="ignore",
                check=False,
            )
        except OSError:
            return None

        pids = []
        for line in result.stdout.splitlines():
            row = next(csv.reader([line]), [])
            if len(row) >= 2 and row[0].lower() == "prajnyavan_service.exe":
                try:
                    pids.append(int(row[1]))
                except ValueError:
                    continue
        pids.extend(_find_mock_daemon_pids())
        return sorted(set(pids))

    try:
        result = subprocess.run(
            ["pgrep", "-f", "prajnyavan_service|prajnyavan.mock_daemon"],
            capture_output=True,
            text=True,
            check=False,
        )
    except OSError:
        return []

    return [int(line.strip()) for line in result.stdout.splitlines() if line.strip().isdigit()]


def _resolve_daemon_pid(cfg: dict | None) -> int | None:
    if not cfg:
        return None

    pid = cfg.get("pid")
    if isinstance(pid, int) and pid > 0:
        if _pid_alive(pid):
            return pid

    port = cfg.get("port")
    if isinstance(port, str) and port.isdigit():
        resolved = _find_pid_by_port(int(port))
        if resolved is not None:
            return resolved
    if isinstance(port, int):
        resolved = _find_pid_by_port(port)
        if resolved is not None:
            return resolved
    resolved = _find_pid_by_port(_extract_port(cfg.get("base_url")))
    if resolved is not None:
        return resolved
    return _find_service_pid()


def _fetch_health(url: str | None, timeout: float = 2.0) -> dict:
    if not url:
        return {}
    try:
        response = requests.get(f"{url}/health", timeout=timeout)
        response.raise_for_status()
        return response.json()
    except Exception:
        return {}


def _cache_size_mb() -> float:
    if not MODEL_CACHE.exists():
        return 0.0
    return sum(p.stat().st_size for p in MODEL_CACHE.rglob("*") if p.is_file()) / 1e6


def _find_running_url(timeout: float = 0.5) -> tuple[str | None, dict]:
    for port in range(DEFAULT_PORT, DEFAULT_PORT + PORT_RANGE):
        url = f"http://{DEFAULT_ADDR}:{port}"
        health = _fetch_health(url, timeout=timeout)
        if health:
            return url, health
    return None, {}


def _status_snapshot(*, scan: bool = True) -> dict:
    cfg = _load_config()
    url = cfg.get("base_url") if cfg else None
    health = _fetch_health(url) if url else {}
    discovered_via_scan = False

    pkg_version = _package_version()
    daemon_mode = "unknown"
    if health:
        reported_version = health.get("version")
        if reported_version == "mock":
            daemon_mode = "mock"
        else:
            daemon_mode = "real"
        if reported_version and reported_version != pkg_version:
            health["version_reported"] = reported_version
            health["version_mismatch"] = True
            health["expected_version"] = pkg_version
        else:
            health["version_mismatch"] = False
            health.pop("version_reported", None)
            health["expected_version"] = pkg_version

    if scan and not health:
        scanned_url, scanned_health = _find_running_url()
        if scanned_url:
            url = scanned_url
            health = scanned_health
            discovered_via_scan = True
            reported_version = health.get("version")
            if reported_version == "mock":
                daemon_mode = "mock"
            elif reported_version:
                daemon_mode = "real"
            if reported_version and reported_version != pkg_version:
                health["version_reported"] = reported_version
                health["version_mismatch"] = True
                health["expected_version"] = pkg_version
            else:
                health["version_mismatch"] = False
                health.pop("version_reported", None)
                health["expected_version"] = pkg_version

    cfg_for_pid = dict(cfg or {})
    if url:
        cfg_for_pid["base_url"] = url
        cfg_for_pid.setdefault("port", _extract_port(url))

    pid = _resolve_daemon_pid(cfg_for_pid or None)
    if pid is None:
        pid = _find_service_pid()

    running = bool(health) or (_pid_alive(pid) if pid else False)
    port = cfg_for_pid.get("port") if cfg_for_pid else None
    if isinstance(port, str) and port.isdigit():
        port = int(port)
    if port is None:
        port = _extract_port(url)

    return {
        "running": running,
        "base_url": url,
        "port": port,
        "pid": pid,
        "config_exists": DEV_CONFIG.exists(),
        "config_path": str(DEV_CONFIG),
        "pid_file_exists": PID_FILE.exists(),
        "pid_file_path": str(PID_FILE),
        "base_dir": str(BASE_DIR),
        "lock_path": str(LOCK_FILE),
        "log_exists": DAEMON_LOG.exists(),
        "log_path": str(DAEMON_LOG),
        "cache_path": str(MODEL_CACHE),
        "cache_mb": round(_cache_size_mb(), 1),
        "mode": daemon_mode,
        "health": health,
        "discovered_via_scan": discovered_via_scan,
    }


def _emit_json(data: dict) -> None:
    print(json.dumps(data, indent=2, sort_keys=True))


def _ensure_daemon_running_for_cli(*, quiet: bool = False) -> dict:
    if not quiet:
        return ensure_daemon_running()
    with contextlib.redirect_stdout(io.StringIO()):
        return ensure_daemon_running()


def _check_base_dir_writable() -> tuple[bool, str]:
    try:
        BASE_DIR.mkdir(parents=True, exist_ok=True)
        test_file = BASE_DIR / ".doctor_write_test"
        test_file.write_text("ok")
        test_file.unlink(missing_ok=True)
        return True, str(BASE_DIR)
    except Exception as exc:
        return False, str(exc)


def _check_port_readiness(snapshot: dict) -> tuple[str, str, str]:
    if snapshot["running"] and snapshot["base_url"]:
        return "ok", str(snapshot["base_url"]), ""
    try:
        free_port = _find_free_port()
        return "ok", f"http://{DEFAULT_ADDR}:{free_port}", ""
    except Exception as exc:
        return "fail", str(exc), "Free a port in the 9999-10008 range or set PRAJNYAVAN_USE_UDS=1."


def _make_check(name: str, status: str, detail: str, fix: str = "") -> dict:
    return {"name": name, "status": status, "detail": detail, "fix": fix}


def _doctor_report(*, allow_mock: bool = False) -> dict:
    snapshot = _status_snapshot()
    health = snapshot["health"]
    checks = []

    python_ok = sys.version_info >= (3, 9)
    checks.append(
        _make_check(
            "python_version",
            "ok" if python_ok else "fail",
            sys.version.split()[0],
            "Use Python 3.9 or newer.",
        )
    )

    base_dir_ok, base_dir_detail = _check_base_dir_writable()
    checks.append(
        _make_check(
            "base_dir_writable",
            "ok" if base_dir_ok else "fail",
            base_dir_detail,
            f"Ensure {BASE_DIR} exists and is writable by your user account.",
        )
    )

    port_status, port_detail, port_fix = _check_port_readiness(snapshot)
    checks.append(_make_check("port_readiness", port_status, port_detail, port_fix))

    config_status = "ok" if snapshot["config_exists"] else "warn"
    config_detail = snapshot["config_path"] if snapshot["config_exists"] else "missing"
    checks.append(
        _make_check(
            "dev_config",
            config_status,
            config_detail,
            "Run `prajnyavan dev` once to create local config." if not snapshot["config_exists"] else "",
        )
    )

    daemon_status = "ok" if snapshot["running"] else "fail"
    daemon_detail = snapshot["base_url"] or "not running"
    checks.append(
        _make_check(
            "daemon_running",
            daemon_status,
            daemon_detail,
            "Run `prajnyavan dev` to start the local daemon.",
        )
    )

    mode = snapshot.get("mode", "unknown")
    if snapshot["running"]:
        if mode == "mock" and not allow_mock:
            checks.append(
                _make_check(
                    "daemon_mode",
                    "fail",
                    "mock daemon",
                    "Start the real daemon and rerun doctor, or pass --allow-mock only for CI/dev checks.",
                )
            )
        elif mode == "mock":
            checks.append(
                _make_check(
                    "daemon_mode",
                    "warn",
                    "mock daemon",
                    "Mock mode is acceptable only for CI/dev checks.",
                )
            )
        elif mode == "real":
            checks.append(_make_check("daemon_mode", "ok", "real daemon"))

    health_status = "ok" if health else "fail"
    checks.append(
        _make_check(
            "health_endpoint",
            health_status,
            snapshot["base_url"] or "unreachable",
            "Run `prajnyavan logs -n 50` and `prajnyavan reset` if the daemon is hung.",
        )
    )
    if snapshot["running"] and health and mode != "mock":
        mismatch = bool(health.get("version_mismatch"))
        actual = health.get("version_reported") or health.get("version") or "unknown"
        expected = health.get("expected_version") or _package_version()
        checks.append(
            _make_check(
                "version_alignment",
                "fail" if mismatch else "ok",
                f"daemon={actual} package={expected}",
                "Run `prajnyavan stop --force` then `prajnyavan dev` so the local daemon matches the installed package.",
            )
        )

    if snapshot["base_url"] and health:
        try:
            token = get_token(snapshot["base_url"], user_id="doctor")
            token_status = "ok" if token else "fail"
            token_detail = "token issued"
            token_fix = "Restart the daemon with `prajnyavan stop` then `prajnyavan dev`."
        except Exception as exc:
            token_status = "fail"
            token_detail = str(exc)
            token_fix = "Restart the daemon with `prajnyavan stop` then `prajnyavan dev`."
    else:
        token_status = "skip"
        token_detail = "daemon unavailable"
        token_fix = ""
    checks.append(_make_check("token_issue", token_status, token_detail, token_fix))

    log_status = "ok" if snapshot["log_exists"] else "warn"
    checks.append(
        _make_check(
            "log_file",
            log_status,
            snapshot["log_path"] if snapshot["log_exists"] else "missing",
            "Run `prajnyavan dev` once to create the daemon log.",
        )
    )

    counts = {
        "ok": sum(1 for check in checks if check["status"] == "ok"),
        "warn": sum(1 for check in checks if check["status"] == "warn"),
        "fail": sum(1 for check in checks if check["status"] == "fail"),
        "skip": sum(1 for check in checks if check["status"] == "skip"),
    }
    ready = counts["fail"] == 0

    return {
        "ready": ready,
        "summary": counts,
        "snapshot": snapshot,
        "checks": checks,
    }


def _run_smoke(*, stop_after: bool = False) -> dict:
    before = _status_snapshot()
    started_here = not before["running"]
    user_id = f"smoke_{uuid4().hex[:12]}"
    phrase = f"Prajnyavan smoke marker {uuid4().hex}"
    result = {
        "ok": False,
        "started_daemon": started_here,
        "stopped_daemon": False,
        "user_id": user_id,
        "memory_id": None,
        "search_hits": 0,
        "search_match": False,
        "emotion_keys": [],
        "cleanup_deleted": None,
        "left_daemon_running": False,
    }

    client = None
    try:
        _ensure_daemon_running_for_cli(quiet=True)
        client = MemoryClient.dev(user_id=user_id)
        memory_id = client.store(user_id, phrase, importance=0.7, tags=["smoke", "cli"])
        hits = client.search(user_id, phrase, exact_match=True, k=3)
        emotion = client.get_emotion()

        search_match = any(
            phrase in (item.get("content_text") or item.get("content", ""))
            for item in hits
        )
        emotion_keys = sorted(str(key) for key in emotion.keys())
        emotion_ok = "valence" in emotion and "arousal" in emotion

        result.update(
            {
                "memory_id": memory_id,
                "search_hits": len(hits),
                "search_match": search_match,
                "emotion_keys": emotion_keys,
            }
        )
        result["ok"] = bool(memory_id) and search_match and emotion_ok
        if not result["ok"]:
            result["error"] = "Smoke checks completed but one or more assertions failed."
    except Exception as exc:
        result["error"] = str(exc)
    finally:
        if client is not None:
            try:
                result["cleanup_deleted"] = client.delete_user(user_id)
            except Exception as exc:
                result["cleanup_error"] = str(exc)

        if started_here and stop_after:
            stop_code = cmd_stop(None, quiet=True)
            result["stopped_daemon"] = stop_code == 0
            if stop_code != 0:
                result["ok"] = False
                result.setdefault("error", "Smoke test passed, but daemon cleanup failed.")
        elif started_here:
            result["left_daemon_running"] = True

    return result


def cmd_dev(_: argparse.Namespace) -> int:
    # Pre-flight: ensure BASE_DIR is writable
    try:
        BASE_DIR.mkdir(parents=True, exist_ok=True)
        test_file = BASE_DIR / ".write_test"
        test_file.write_text("ok")
        test_file.unlink(missing_ok=True)
    except Exception as e:
        print(f"[prajnyavan] Cannot write to {BASE_DIR}: {e}", file=sys.stderr)
        return 1

    cfg = ensure_daemon_running()
    snippet = (
        "from prajnyavan import MemoryClient\n"
        "mem = MemoryClient.dev(user_id=\"user_123\")\n"
        "@mem.wrap_llm(user_id=\"user_123\")\n"
        "def chat(prompt):\n"
        "    return \"Your LLM call here\"\n"
    )
    _print_ascii(f"[prajnyavan] running at {cfg['base_url']} (pid={cfg.get('pid')})")
    _print_ascii("[prajnyavan] paste this snippet into your app:\n")
    _print_ascii(snippet)
    return 0


def cmd_status(args: argparse.Namespace) -> int:
    snapshot = _status_snapshot()
    if args.json:
        _emit_json(snapshot)
        return 0 if snapshot["running"] else 1

    _print_ascii(f"[{'running' if snapshot['running'] else 'stopped'}] prajnyavan")
    _print_ascii(f"  url:      {snapshot['base_url'] or '-'}")
    _print_ascii(f"  pid:      {snapshot['pid'] if snapshot['pid'] is not None else 'unknown'}")
    if snapshot["running"]:
        _print_ascii(f"  mode:     {snapshot.get('mode', 'unknown')}")
    if args.verbose and snapshot["health"]:
        health = snapshot["health"]
        _print_ascii(f"  version:  {health.get('version', '?')}")
        if health.get("version_mismatch"):
            reported = health.get("version_reported", "?")
            expected = health.get("expected_version", "?")
            _print_ascii(f"  package:  {expected}")
            _print_ascii(f"  mismatch: daemon reports {reported}")
        _print_ascii(f"  uptime:   {health.get('uptime_seconds', 0)}s")
        _print_ascii(f"  memories (live):  {health.get('current_memory_count', 0)}")
        _print_ascii(f"  total stored ever:{health.get('total_stores_ever', 0)}")
        _print_ascii(f"  cache:    {snapshot['cache_mb']:.1f} MB")
        _print_ascii(f"  log:      {snapshot['log_path']}")
    if not snapshot["running"] and not snapshot["config_exists"]:
        _print_ascii("  note:     No local dev config found. Start with: prajnyavan dev")
    return 0 if snapshot["running"] else 1


def cmd_logs(args: argparse.Namespace) -> int:
    if getattr(args, "rotate", False):
        _rotate_log(max_mb=args.max_mb)
    if not DAEMON_LOG.exists():
        _print_ascii("[prajnyavan] No log file found. Run prajnyavan dev first.")
        return 1
    _print_ascii(_tail_log(DAEMON_LOG, n=args.lines))
    return 0


def _kill_pid(pid: int, *, force: bool = False) -> None:
    if os.name == "nt":
        try:
            subprocess.run(
                [
                    "powershell",
                    "-NoProfile",
                    "-Command",
                    f"Stop-Process -Id {pid} -Force -ErrorAction SilentlyContinue",
                ],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                check=False,
                timeout=10,
            )
        except subprocess.TimeoutExpired:
            subprocess.run(
                ["taskkill", "/PID", str(pid), "/F", "/T"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                check=False,
                timeout=10,
            )
    else:
        try:
            os.kill(pid, signal.SIGTERM)
            if force:
                time.sleep(0.2)
                os.kill(pid, signal.SIGKILL)
        except Exception:
            pass


def cmd_stop(args: argparse.Namespace | None, *, quiet: bool = False) -> int:
    cfg = _load_config()
    force = bool(getattr(args, "force", False))
    fallback_pids = _find_service_pids() if force else []
    had_state = PID_FILE.exists() or bool(cfg) or bool(fallback_pids)
    if not had_state:
        if not quiet:
            _print_ascii("[prajnyavan] No running daemon found.")
        return 0

    pids: set[int] = set()
    if PID_FILE.exists():
        try:
            pid = int(PID_FILE.read_text().strip())
            if pid > 0:
                pids.add(pid)
        except Exception:
            pass
    resolved_pid = _resolve_daemon_pid(cfg)
    if resolved_pid is not None:
        pids.add(resolved_pid)
    pids.update(fallback_pids)
    pids = {pid for pid in pids if isinstance(pid, int) and pid > 0}

    was_running = bool(pids)
    for pid in sorted(pids):
        try:
            _kill_pid(pid, force=force)
        except TypeError:
            _kill_pid(pid)
    for pid in sorted(pids):
        if not _wait_for_pid_exit(pid):
            if not quiet:
                print(
                    f"[prajnyavan] Timed out waiting for daemon pid={pid} to exit.",
                    file=sys.stderr,
                )
            return 1
    if was_running:
        time.sleep(0.2)

    cleanup_errors = []
    for path in (PID_FILE, DEV_CONFIG):
        err = _safe_unlink(path)
        if err:
            cleanup_errors.append((path, err))

    if cleanup_errors and not quiet:
        _print_ascii("[prajnyavan] stopped, but some local state files could not be removed:")
        for path, err in cleanup_errors:
            _print_ascii(f"  - {path}: {err}")

    if not quiet:
        if was_running:
            _print_ascii("[prajnyavan] stopped.")
        else:
            _print_ascii("[prajnyavan] Cleared stale daemon state.")
    return 0


def cmd_reset(_: argparse.Namespace) -> int:
    cmd_stop(_)
    if BASE_DIR.exists():
        shutil.rmtree(BASE_DIR, ignore_errors=True)
    _print_ascii("[prajnyavan] reset: cleared data and model cache.")
    return 0


def cmd_export(args: argparse.Namespace) -> int:
    mem = _memory_client_for_cli(args.user)
    data = mem.export_user(args.user)
    total = data.get("stats", {}).get("total_memories")
    if not isinstance(total, int):
        total = len(data.get("memories", []))
    out = Path(args.output or f"prajnyavan_export_{args.user}.json")
    out.write_text(json.dumps(data, indent=2))
    _print_ascii(f"[prajnyavan] Exported {total} memories to {out}")
    return 0


def _memory_client_for_cli(user_id: str) -> MemoryClient:
    if os.environ.get("PRAJNYAVAN_URL") and os.environ.get("PRAJNYAVAN_TOKEN"):
        return MemoryClient.from_env()
    return MemoryClient.dev(user_id=user_id)


def cmd_import(args: argparse.Namespace) -> int:
    mem = _memory_client_for_cli(args.user)
    data = json.loads(Path(args.file).read_text())
    result = mem.import_profile(data, target_user_id=args.user)
    imported = int(result.get("imported", 0))
    skipped = int(result.get("skipped", 0))
    _print_ascii(
        f"[prajnyavan] Imported {imported} memories for user {args.user} "
        f"(skipped {skipped})"
    )
    return 0


def _run_import_benchmark(memories: int) -> dict[str, object]:
    source_user = f"bench-src-{uuid4().hex[:8]}"
    target_user = f"bench-dst-{uuid4().hex[:8]}"
    mem = _memory_client_for_cli(source_user)

    items = [
        {"content": f"benchmark memory {idx} unique {uuid4().hex[:8]}"}
        for idx in range(memories)
    ]

    error: str | None = None
    store_ids: list[str] = []
    imported = 0
    listed = 0
    exported_count = 0
    elapsed = 0.0

    try:
        store_ids = mem.store_batch(source_user, items)
        exported = mem.export_user(source_user)
        profile_memories = exported.get("memories", [])
        source_exported = len(profile_memories)

        started = time.perf_counter()
        result = mem.import_profile(exported, target_user_id=target_user)
        elapsed = max(time.perf_counter() - started, 1e-9)

        imported = int(result.get("imported", 0))
        listed = len(mem.list_memories(target_user))
        exported_target = mem.export_user(target_user)
        exported_count = len(exported_target.get("memories", []))

        ok = (
            len(store_ids) == memories
            and len(set(store_ids)) == memories
            and source_exported == memories
            and imported == memories
            and listed == memories
            and exported_count == memories
        )
    except Exception as exc:
        ok = False
        source_exported = 0
        error = str(exc)
    finally:
        with contextlib.suppress(Exception):
            mem.delete_user(source_user)
        with contextlib.suppress(Exception):
            mem.delete_user(target_user)

    return {
        "ok": ok,
        "memories_requested": memories,
        "returned_ids": len(store_ids),
        "unique_ids": len(set(store_ids)),
        "source_exported": source_exported,
        "imported": imported,
        "listed": listed,
        "exported": exported_count,
        "elapsed_seconds": round(elapsed, 4),
        "memories_per_sec": round(memories / elapsed, 2) if elapsed > 0 else 0.0,
        "error": error,
    }


def cmd_benchmark_import(args: argparse.Namespace) -> int:
    result = _run_import_benchmark(args.memories)
    if args.json:
        _emit_json(result)
    else:
        status = "ok" if result["ok"] else "fail"
        _print_ascii(f"[{status}] prajnyavan benchmark import")
        _print_ascii(f"  requested:   {result['memories_requested']}")
        _print_ascii(f"  returned ids:{result['returned_ids']}")
        _print_ascii(f"  unique ids:  {result['unique_ids']}")
        _print_ascii(f"  imported:    {result['imported']}")
        _print_ascii(f"  listed:      {result['listed']}")
        _print_ascii(f"  exported:    {result['exported']}")
        _print_ascii(f"  elapsed:     {result['elapsed_seconds']}s")
        _print_ascii(f"  throughput:  {result['memories_per_sec']} mem/s")
        if result.get("error"):
            _print_ascii(f"  error:       {result['error']}")
    return 0 if result["ok"] else 1


def cmd_list(args: argparse.Namespace) -> int:
    mem = MemoryClient.dev()
    items = mem.list_memories(args.user, namespace=args.namespace)
    for m in items:
        content = m.get("content_text") or m.get("content", "")
        _print_ascii(f"{m.get('id') or m.get('memory_id','?')}: {content[:80]}... tags={m.get('tags', [])}")
    _print_ascii(f"[prajnyavan] Total: {len(items)}")
    return 0


def cmd_delete(args: argparse.Namespace) -> int:
    mem = MemoryClient.dev()
    ok = mem.delete_memory(args.id)
    _print_ascii(f"[prajnyavan] Deleted {args.id}" if ok else f"[prajnyavan] Delete failed for {args.id}")
    return 0


def cmd_update(args: argparse.Namespace) -> int:
    mem = MemoryClient.dev()
    ok = mem.update_memory(
        args.id,
        content=args.content,
        importance=args.importance,
        tags=args.tags,
    )
    _print_ascii(f"[prajnyavan] Updated {args.id}" if ok else f"[prajnyavan] Update failed for {args.id}")
    return 0


def cmd_doctor(args: argparse.Namespace) -> int:
    report = _doctor_report(allow_mock=args.allow_mock)
    if args.json:
        _emit_json(report)
        return 0 if report["ready"] else 1

    icons = {"ok": "[OK]", "warn": "[WARN]", "fail": "[FAIL]", "skip": "[SKIP]"}
    _print_ascii(f"[{'ready' if report['ready'] else 'not ready'}] prajnyavan doctor")
    for check in report["checks"]:
        _print_ascii(f"  {icons[check['status']]} {check['name']}: {check['detail']}")
        if check["status"] in {"warn", "fail"} and check["fix"]:
            _print_ascii(f"       Fix: {check['fix']}")
    _print_ascii(
        "  summary: "
        f"{report['summary']['ok']} ok, "
        f"{report['summary']['warn']} warn, "
        f"{report['summary']['fail']} fail, "
        f"{report['summary']['skip']} skip"
    )
    return 0 if report["ready"] else 1


def cmd_smoke(args: argparse.Namespace) -> int:
    result = _run_smoke(stop_after=bool(getattr(args, "stop_after", False)))
    if args.json:
        _emit_json(result)
    else:
        _print_ascii(f"[{'ok' if result['ok'] else 'fail'}] prajnyavan smoke")
        _print_ascii(f"  started daemon: {result['started_daemon']}")
        _print_ascii(f"  stopped daemon: {result['stopped_daemon']}")
        if result.get("left_daemon_running"):
            _print_ascii("  left running:   True")
        _print_ascii(f"  memory id:      {result['memory_id'] or '-'}")
        _print_ascii(f"  search hits:    {result['search_hits']}")
        _print_ascii(f"  search match:   {result['search_match']}")
        _print_ascii(
            "  emotion keys:   "
            + (", ".join(result["emotion_keys"]) if result["emotion_keys"] else "-")
        )
        if result.get("cleanup_deleted") is not None:
            _print_ascii(f"  cleanup deleted:{result['cleanup_deleted']}")
        if result.get("error"):
            _print_ascii(f"  error:          {result['error']}")
        if result.get("cleanup_error"):
            _print_ascii(f"  cleanup error:  {result['cleanup_error']}")
    return 0 if result["ok"] else 1


def cmd_demo(_: argparse.Namespace) -> int:
    from prajnyavan import MemoryClient

    client = MemoryClient.dev(user_id="demo_user")
    _print_ascii("[prajnyavan] Running demo with user_id=demo_user")
    mid = client.store("demo_user", "Bruno is a golden retriever", tags=["pet", "dog"], importance=0.8)
    _print_ascii(f"  Stored memory: {mid}")
    results = client.search("demo_user", "What kind of pet is Bruno?", k=3)
    _print_ascii("  Search results:")
    for r in results:
        _print_ascii(f"   - {r.get('content_text') or r.get('content', '')} (score={r.get('relevance_score') or r.get('score'):.3f})")
    emotion = client.get_emotion()
    _print_ascii(
        "  Emotion state: "
        f"valence={emotion.get('valence', 0):.2f} "
        f"arousal={emotion.get('arousal', 0):.2f}"
    )
    _print_ascii("Demo complete.")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(prog="prajnyavan", description="Prajnyavan CLI")
    sub = parser.add_subparsers(dest="cmd", required=True)

    sub.add_parser("dev", help="Start local daemon")

    status_p = sub.add_parser("status", help="Show daemon status")
    status_p.add_argument("--verbose", "-v", action="store_true")
    status_p.add_argument("--json", action="store_true", help="Emit machine-readable status")

    logs_p = sub.add_parser("logs", help="Tail daemon log")
    logs_p.add_argument("--lines", "-n", type=int, default=50)
    logs_p.add_argument("--rotate", action="store_true", help="Rotate daemon.log before printing.")
    logs_p.add_argument("--max-mb", type=float, default=None, help="Override log rotation threshold (MB).")

    stop_p = sub.add_parser("stop", help="Stop daemon")
    stop_p.add_argument("--force", action="store_true", help="Force-kill the daemon and clear pid even if stale.")
    sub.add_parser("reset", help="Stop and clear local data/cache")
    doctor_p = sub.add_parser("doctor", help="Run readiness checks")
    doctor_p.add_argument("--json", action="store_true", help="Emit machine-readable readiness report")
    doctor_p.add_argument("--allow-mock", action="store_true", help="Treat mock daemon mode as acceptable for CI/dev-only checks")
    smoke_p = sub.add_parser("smoke", help="Run a start/store/search/emotion smoke test")
    smoke_p.add_argument("--json", action="store_true", help="Emit machine-readable smoke report")
    smoke_p.add_argument("--keep-running", action="store_true", help="Deprecated: smoke now leaves a newly started daemon running by default")
    smoke_p.add_argument("--stop-after", action="store_true", help="Stop the daemon after smoke if this command started it")
    sub.add_parser("demo", help="Run a local demo")
    benchmark_p = sub.add_parser("benchmark", help="Run local benchmark helpers")
    benchmark_sub = benchmark_p.add_subparsers(dest="benchmark_cmd", required=True)
    benchmark_import_p = benchmark_sub.add_parser(
        "import",
        help="Measure portable-profile import throughput with count checks",
    )
    benchmark_import_p.add_argument("--memories", type=int, default=500)
    benchmark_import_p.add_argument("--json", action="store_true", help="Emit machine-readable benchmark output")

    export_p = sub.add_parser("export", help="Export memories for a user")
    export_p.add_argument("--user", required=True)
    export_p.add_argument("--output", "-o")

    import_p = sub.add_parser("import", help="Import memories for a user")
    import_p.add_argument("--user", required=True)
    import_p.add_argument("--file", required=True)

    list_p = sub.add_parser("list", help="List memories for a user")
    list_p.add_argument("--user", required=True)
    list_p.add_argument("--namespace")

    del_p = sub.add_parser("delete", help="Delete a memory by id")
    del_p.add_argument("--id", required=True)

    update_p = sub.add_parser("update", help="Update a memory by id")
    update_p.add_argument("--id", required=True)
    update_p.add_argument("--content")
    update_p.add_argument("--importance", type=float)
    update_p.add_argument("--tags", nargs="+")

    args = parser.parse_args()

    if args.cmd == "dev":
        return cmd_dev(args)
    if args.cmd == "status":
        return cmd_status(args)
    if args.cmd == "logs":
        return cmd_logs(args)
    if args.cmd == "stop":
        return cmd_stop(args)
    if args.cmd == "reset":
        return cmd_reset(args)
    if args.cmd == "doctor":
        return cmd_doctor(args)
    if args.cmd == "smoke":
        return cmd_smoke(args)
    if args.cmd == "demo":
        return cmd_demo(args)
    if args.cmd == "benchmark":
        if args.benchmark_cmd == "import":
            return cmd_benchmark_import(args)
        parser.print_help()
        return 1
    if args.cmd == "export":
        return cmd_export(args)
    if args.cmd == "import":
        return cmd_import(args)
    if args.cmd == "list":
        return cmd_list(args)
    if args.cmd == "delete":
        return cmd_delete(args)
    if args.cmd == "update":
        return cmd_update(args)

    parser.print_help()
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
