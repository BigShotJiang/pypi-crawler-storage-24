"""
Prajnyavan SDK — zero-friction client.
"""
from __future__ import annotations

import json
import os
import re
import inspect
import warnings
from functools import lru_cache, wraps
from typing import Any, Callable, Dict, List, Optional, Union

import requests

from ._daemon import MODEL_CACHE, ensure_daemon_running, _load_config, _save_config
from .exceptions import (
    PrajnyavanAuthError,
    PrajnyavanConfigError,
    PrajnyavanConnectionError,
    PrajnyavanError,
    DimensionMismatchError,
    QuotaError,
    MemoryNotFoundError,
    PIIBlockedError,
)

# ── Embedding helpers ────────────────────────────────────────────────────────

API_PREFIX = "/v1"
_DEFAULT_BULK_STORE_CHUNK_SIZE = 100
_LOCAL_MODELS: Dict[str, Any] = {}
_SENSITIVE_PATTERNS = [
    r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}",
    r"sk-[A-Za-z0-9]{20,}",  # API-like keys
    r"(?<!\d)\d{13,16}(?!\d)",  # credit-card-like digit runs
    r"(?i)secret|password|api[_-]?key|token",
]


def _is_sensitive(text: str) -> bool:
    return any(re.search(pat, text) for pat in _SENSITIVE_PATTERNS)


def _embedding_dim() -> int:
    try:
        dim = int(os.environ.get("PRAJNYAVAN_EMBEDDING_DIM", "768"))
    except ValueError:
        dim = 768
    return dim if dim in (384, 768, 1536, 3072) else 768


def _fit_embedding(vec: List[float]) -> List[float]:
    target = _embedding_dim()
    if len(vec) == target:
        return vec
    if not vec:
        return [0.0] * target
    out = [0.0] * target
    n = len(vec)
    for i in range(target):
        src = int(i * n / target)
        out[i] = float(vec[src])
    return out


def _approx_tokens(text: str) -> int:
    return (len(text) + 3) // 4 if text else 0


def _parse_prometheus_metrics(text: str) -> Dict[str, Any]:
    metrics: Dict[str, Any] = {}
    for raw_line in text.splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        parts = line.split()
        if len(parts) != 2:
            continue
        key, value = parts
        if "{" in key:
            continue
        try:
            number = float(value)
        except ValueError:
            continue
        metrics[key] = int(number) if number.is_integer() else number
    return metrics


def _chunk_items(items: List[Dict[str, Any]], chunk_size: int) -> List[List[Dict[str, Any]]]:
    if chunk_size <= 0:
        raise ValueError("chunk_size must be greater than zero")
    return [items[idx : idx + chunk_size] for idx in range(0, len(items), chunk_size)]


def _embed_openai(text: str, api_key: str, model: str = "text-embedding-3-small") -> List[float]:
    import openai

    client = openai.OpenAI(api_key=api_key)
    response = client.embeddings.create(model=model, input=text)
    return _fit_embedding(response.data[0].embedding)


def _embed_cohere(text: str, api_key: str, model: str = "embed-english-v3.0") -> List[float]:
    import cohere

    co = cohere.Client(api_key)
    response = co.embed(texts=[text], model=model, input_type="search_document")
    return _fit_embedding(response.embeddings[0])


def _ensure_local_model(model_name: str) -> Any:
    if model_name in _LOCAL_MODELS:
        return _LOCAL_MODELS[model_name]

    MODEL_CACHE.mkdir(parents=True, exist_ok=True)
    try:
        from sentence_transformers import SentenceTransformer

        model = SentenceTransformer(model_name, cache_folder=str(MODEL_CACHE))
        _LOCAL_MODELS[model_name] = model
        return model
    except Exception:
        _LOCAL_MODELS[model_name] = None
        return None


def _hash_embed(text: str) -> List[float]:
    dim = _embedding_dim()
    out = [0.0] * dim
    h = 14695981039346656037  # FNV-1a offset
    for b in text.encode("utf-8"):
        h ^= b
        h = (h * 1099511628211) & 0xFFFFFFFFFFFFFFFF
        idx = h % dim
        out[idx] = min(1.0, out[idx] + b / 255.0)
    return out


def _embed_local(text: str, model_name: str = "all-mpnet-base-v2") -> List[float]:
    model = _ensure_local_model(model_name)
    if model is None:
        return _hash_embed(text)
    return _fit_embedding(model.encode(text).tolist())


# ── Client ───────────────────────────────────────────────────────────────────


class MemoryClient:
    """
    Prajnyavan memory client.
    """

    def __init__(
        self,
        base_url: Optional[str] = None,
        token: Optional[str] = None,
        openai_api_key: Optional[str] = None,
        embedding_provider: str = "local",
        embedding_model: Optional[str] = None,
    ):
        if base_url is None or token is None:
            cfg = _load_config()
            if not cfg:
                raise PrajnyavanConfigError(
                    "base_url and token are required unless prajnyavan dev has been started."
                )
            base_url = base_url or cfg["base_url"]
            token = token or cfg["token"]

        self.base_url = base_url.rstrip("/")
        self.token = token
        self.embedding_provider = embedding_provider
        self.embedding_model = embedding_model
        self._openai_key = openai_api_key or os.environ.get("OPENAI_API_KEY")
        self._can_auto_refresh = False

        if self.base_url.startswith("http+unix://"):
            try:
                from requests_unixsocket import Session  # type: ignore
            except ImportError as e:
                raise PrajnyavanConfigError("requests-unixsocket is required for UDS mode") from e
            self.session = Session()
        else:
            self.session = requests.Session()

        self.session.headers.update(
            {
                "authorization": token,
                "content-type": "application/json",
            }
        )

        self._embed_cached = lru_cache(maxsize=512)(self._embed_uncached)

    # ---- Classmethods -------------------------------------------------------
    @classmethod
    def dev(cls, user_id: str = "developer", **kwargs) -> "MemoryClient":
        cfg = ensure_daemon_running()
        client = cls(
            base_url=cfg["base_url"],
            token=cfg["token"],
            embedding_provider=kwargs.pop("embedding_provider", "hash"),
            **kwargs,
        )
        client._can_auto_refresh = True
        return client

    @classmethod
    def from_env(cls, **kwargs) -> "MemoryClient":
        url = os.environ.get("PRAJNYAVAN_URL")
        token = os.environ.get("PRAJNYAVAN_TOKEN")
        if not url or not token:
            missing = [name for name, val in [("PRAJNYAVAN_URL", url), ("PRAJNYAVAN_TOKEN", token)] if not val]
            raise PrajnyavanConfigError(f"Missing env vars: {missing}. Use MemoryClient.dev() for local development.")
        provider = os.environ.get("PRAJNYAVAN_EMBEDDING_PROVIDER", "local")
        return cls(base_url=url, token=token, embedding_provider=provider, **kwargs)

    @classmethod
    def hosted(
        cls,
        *,
        base_url: Optional[str] = None,
        token: Optional[str] = None,
        **kwargs,
    ) -> "MemoryClient":
        resolved_url = base_url or os.environ.get("PRAJNYAVAN_HOSTED_URL") or os.environ.get("PRAJNYAVAN_URL")
        resolved_token = token or os.environ.get("PRAJNYAVAN_TOKEN")
        if not resolved_url:
            raise PrajnyavanConfigError(
                "base_url is required for hosted mode unless PRAJNYAVAN_HOSTED_URL or PRAJNYAVAN_URL is set."
            )
        if not resolved_token:
            raise PrajnyavanConfigError("token is required for hosted mode unless PRAJNYAVAN_TOKEN is set.")
        return cls(base_url=resolved_url, token=resolved_token, **kwargs)

    # ---- Internal HTTP helper ----------------------------------------------
    def _refresh_token(self) -> None:
        new_token = get_token(self.base_url)
        self.token = new_token
        self.session.headers["authorization"] = new_token
        cfg = _load_config() or {}
        if cfg:
            cfg["token"] = new_token
            _save_config(cfg)

    def _request(self, method: str, path: str, retry: bool = True, **kwargs) -> requests.Response:
        url = f"{self.base_url}{path}"
        try:
            resp = self.session.request(method, url, timeout=kwargs.pop("timeout", 10), **kwargs)
        except requests.exceptions.RequestException as e:
            raise PrajnyavanConnectionError(f"Daemon unreachable: {e}") from e

        if resp.status_code in (401, 403):
            if self._can_auto_refresh and retry:
                try:
                    self._refresh_token()
                    return self._request(method, path, retry=False, **kwargs)
                except Exception:
                    pass
            raise PrajnyavanAuthError(
                "Token expired or unauthorized.",
                error_code=resp.json().get("error_code") if resp.headers.get("content-type", "").startswith("application/json") else None,
                request_id=resp.headers.get("X-Request-ID"),
            )

        if resp.status_code == 404:
            if path.startswith(API_PREFIX):
                # Fallback for older daemons without /v1 prefix.
                return self._request(method, path.replace(API_PREFIX, "", 1), retry=retry, **kwargs)
            raise MemoryNotFoundError(
                "Memory not found",
                error_code="MEMORY_NOT_FOUND",
                request_id=resp.headers.get("X-Request-ID"),
            )

        if resp.status_code == 422:
            try:
                body = resp.json()
            except Exception:
                body = {}
            code = body.get("error_code")
            if code == "PII_BLOCKED":
                raise PIIBlockedError(
                    body.get("message", "PII blocked"),
                    pii_types=body.get("pii_types", []),
                    error_code=code,
                    request_id=resp.headers.get("X-Request-ID"),
                )
            if code == "DIMENSION_MISMATCH":
                raise DimensionMismatchError(
                    body.get("message", "Embedding dimension mismatch"),
                    error_code=code,
                    request_id=resp.headers.get("X-Request-ID"),
                )

        if resp.status_code == 429:
            retry_after = resp.headers.get("Retry-After")
            raise QuotaError(
                "Rate limit exceeded",
                retry_after=int(retry_after) if retry_after and retry_after.isdigit() else None,
                error_code="QUOTA_EXCEEDED",
                request_id=resp.headers.get("X-Request-ID"),
            )

        resp.raise_for_status()
        return resp

    # ---- Embedding ---------------------------------------------------------
    def _embed_uncached(self, text: str) -> tuple:
        return tuple(self._embed_raw(text))

    def _embed_raw(self, text: str) -> List[float]:
        if self.embedding_provider == "hash":
            return _hash_embed(text)
        if self.embedding_provider == "openai":
            if not self._openai_key:
                raise PrajnyavanConfigError("OPENAI_API_KEY required for openai embeddings.")
            model = self.embedding_model or "text-embedding-3-small"
            return _embed_openai(text, self._openai_key, model=model)
        if self.embedding_provider == "cohere":
            api_key = os.environ.get("COHERE_API_KEY")
            if not api_key:
                raise PrajnyavanConfigError("COHERE_API_KEY required for cohere embeddings.")
            model = self.embedding_model or "embed-english-v3.0"
            return _embed_cohere(text, api_key, model=model)
        if self.embedding_provider == "local":
            return _embed_local(text, self.embedding_model or "all-mpnet-base-v2")
        # hash fallback
        return _hash_embed(text)

    def embed(self, text: str) -> List[float]:
        return list(self._embed_cached(text))

    # ---- API surface --------------------------------------------------------
    def store(
        self,
        user_id: str,
        content: str,
        *,
        namespace: Optional[str] = None,
        importance: Optional[float] = None,
        category: Optional[str] = None,
        ttl_days: Optional[int] = None,
        tags: Optional[List[str]] = None,
        memory_id: Optional[str] = None,
        valence: Optional[float] = None,
        arousal: Optional[float] = None,
        return_metadata: bool = False,
        idempotency_key: Optional[str] = None,
        session_id: Optional[str] = None,
    ) -> Union[str, Dict[str, Any]]:
        embedding = self.embed(content)
        payload: Dict[str, Any] = {
            "content": content,
            "embedding": embedding,
            "context": {"who": user_id, "embedding_provider": self.embedding_provider},
            "user_id": user_id,
            "tags": tags or [],
            "category": category,
            "session_id": session_id,
            "ttl_days": ttl_days,
            "importance": importance,
            "memory_id": memory_id,
            "modality": "text",
            "valence": valence,
            "arousal": arousal,
        }
        if idempotency_key:
            payload["idempotency_key"] = idempotency_key
        if namespace:
            payload["tags"] = list(set((tags or []) + [f"ns:{namespace}"]))
        if _is_sensitive(content):
            payload["tags"] = list(set(payload["tags"] + ["sensitive"]))
            if payload.get("ttl_days") is None:
                payload["ttl_days"] = 1
            warnings.warn("[prajnyavan] Sensitive-looking content detected: applying short TTL and tag.", RuntimeWarning, stacklevel=2)
        resp = self._request("post", f"{API_PREFIX}/memory", data=json.dumps(payload))
        data = resp.json()
        if return_metadata:
            return data
        return data["id"]

    def smart_store(
        self,
        user_id: str,
        content: str,
        **kwargs: Any,
    ) -> Dict[str, Any]:
        embedding = self.embed(content)
        payload: Dict[str, Any] = {
            "content": content,
            "embedding": embedding,
            "context": {"who": user_id, "embedding_provider": self.embedding_provider},
            "user_id": user_id,
            "tags": kwargs.pop("tags", []),
            "category": kwargs.pop("category", None),
            "session_id": kwargs.pop("session_id", None),
            "ttl_days": kwargs.pop("ttl_days", None),
            "importance": kwargs.pop("importance", None),
            "memory_id": kwargs.pop("memory_id", None),
            "modality": kwargs.pop("modality", "text"),
            "valence": kwargs.pop("valence", None),
            "arousal": kwargs.pop("arousal", None),
        }
        if kwargs:
            payload.update(kwargs)
        resp = self._request("post", f"{API_PREFIX}/memory/smart", data=json.dumps(payload))
        return resp.json()

    def search(
        self,
        user_id: Optional[str],
        query: str,
        *,
        namespace: Optional[str] = None,
        k: int = 5,
        top_k: Optional[int] = None,
        valence_bias: Optional[str] = None,
        min_importance: Optional[float] = None,
        category: Optional[str] = None,
        exact_match: bool = False,
        min_valence: Optional[float] = None,
        max_valence: Optional[float] = None,
        min_arousal: Optional[float] = None,
        max_arousal: Optional[float] = None,
        emotion_boost: Optional[float] = None,
        session_id: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        embedding = self.embed(query)
        resolved_k = top_k if top_k is not None else k
        payload: Dict[str, Any] = {
            "query": query,
            "embedding": embedding,
            "k": resolved_k,
            "filters": {},
            "exact_match": exact_match,
        }
        if user_id:
            payload["filters"]["person"] = user_id
        if valence_bias:
            payload["filters"]["valence_bias"] = valence_bias
        if min_importance is not None:
            payload["filters"]["min_importance"] = min_importance
        if category:
            payload["filters"]["category"] = category
        if namespace:
            payload["filters"]["tags"] = [f"ns:{namespace}"]
        if min_valence is not None:
            payload["filters"]["min_valence"] = min_valence
        if max_valence is not None:
            payload["filters"]["max_valence"] = max_valence
        if min_arousal is not None:
            payload["filters"]["min_arousal"] = min_arousal
        if max_arousal is not None:
            payload["filters"]["max_arousal"] = max_arousal
        if emotion_boost is not None:
            payload["filters"]["emotion_boost"] = emotion_boost
        if session_id is not None:
            payload["filters"]["session_id"] = session_id
        resp = self._request("post", f"{API_PREFIX}/memory/search", data=json.dumps(payload))
        results = resp.json().get("results", [])
        if namespace:
            results = [
                r for r in results if any(t == f"ns:{namespace}" for t in r.get("tags", []))
            ]
        return results

    def get_context(
        self,
        user_id: str,
        query: str,
        max_tokens: int = 500,
        embedding: Optional[List[float]] = None,
        session_id: Optional[str] = None,
        profile: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Build a compact context window from the daemon.
        """
        payload: Dict[str, Any] = {
            "user_id": user_id,
            "query": query,
            "max_tokens": max_tokens,
            "embedding": embedding if embedding is not None else self.embed(query),
        }
        if session_id is not None:
            payload["session_id"] = session_id
        if profile is not None:
            payload["profile"] = profile
        resp = self._request("post", f"{API_PREFIX}/memory/context", data=json.dumps(payload))
        return resp.json()

    def bulk_store(
        self,
        user_id: str,
        items: List[Dict[str, Any]],
        *,
        ttl_days: Optional[int] = None,
        session_id: Optional[str] = None,
        allow_duplicates: bool = True,
        chunk_size: int = _DEFAULT_BULK_STORE_CHUNK_SIZE,
    ) -> Dict[str, Any]:
        chunks = _chunk_items(items, chunk_size) if items else []
        if not chunks:
            return {"stored": 0, "errors": 0, "unique_ids": 0, "ids": [], "chunks": 0}

        ids: List[str] = []
        errors = 0
        stored_total = 0

        for chunk in chunks:
            memories = []
            for item in chunk:
                content = item["content"]
                memories.append(
                    {
                        "content": content,
                        "embedding": item.get("embedding") or self.embed(content),
                        "context": item.get(
                            "context",
                            {"who": item.get("user_id", user_id), "embedding_provider": self.embedding_provider},
                        ),
                        "user_id": item.get("user_id"),
                        "tags": item.get("tags", []),
                        "category": item.get("category"),
                        "session_id": item.get("session_id", session_id),
                        "ttl_days": ttl_days if ttl_days is not None else item.get("ttl_days"),
                        "importance": item.get("importance"),
                        "memory_id": item.get("memory_id"),
                        "modality": item.get("modality", "text"),
                        "memory_type": item.get("memory_type"),
                        "idempotency_key": item.get("idempotency_key"),
                    }
                )
            payload = {
                "user_id": user_id,
                "memories": memories,
                "allow_duplicates": allow_duplicates,
            }
            resp = self._request("post", f"{API_PREFIX}/memory/bulk", data=json.dumps(payload))
            chunk_payload = resp.json()
            ids.extend(chunk_payload.get("ids", []))
            stored_total += int(chunk_payload.get("stored", len(chunk_payload.get("ids", []))))
            errors += int(chunk_payload.get("errors", 0))

        return {
            "stored": stored_total,
            "errors": errors,
            "unique_ids": len(set(ids)),
            "ids": ids,
            "chunks": len(chunks),
        }

    def store_batch(
        self,
        user_id: str,
        items: List[Dict[str, Any]],
        *,
        ttl_days=None,
        chunk_size: int = _DEFAULT_BULK_STORE_CHUNK_SIZE,
    ) -> List[str]:
        return self.bulk_store(
            user_id,
            items,
            ttl_days=ttl_days,
            allow_duplicates=True,
            chunk_size=chunk_size,
        ).get("ids", [])

    def search_batch(
        self,
        user_id: str,
        queries: List[str],
        *,
        k: int = 5,
        namespace: Optional[str] = None,
        exact_match: bool = False,
    ) -> List[List[Dict[str, Any]]]:
        return [self.search(user_id, q, k=k, namespace=namespace, exact_match=exact_match) for q in queries]

    def get_memory(self, memory_id: str) -> Dict[str, Any]:
        """Fetch a single memory by UUID."""
        resp = self._request("get", f"{API_PREFIX}/memory/{memory_id}")
        return resp.json()

    def get_related(self, memory_id: str, *, depth: int = 2) -> List[Dict[str, Any]]:
        """Return memories connected in the knowledge graph up to `depth` hops."""
        resp = self._request("get", f"{API_PREFIX}/memory/{memory_id}/related", params={"depth": depth})
        payload = resp.json()
        return payload.get("related", payload.get("results", []))

    def store_profile(
        self,
        user_id: str,
        key: str,
        value: str,
        *,
        importance: Optional[float] = None,
        ttl_days: Optional[int] = None,
    ) -> Dict[str, Any]:
        """Upsert a structured profile fact for a user."""
        payload = {
            "user_id": user_id,
            "key": key,
            "value": value,
            "importance": importance,
            "ttl_days": ttl_days,
        }
        resp = self._request("post", f"{API_PREFIX}/memory/profile", data=json.dumps(payload))
        return resp.json()

    def last_strong_event(self, user_id: str, *, min_arousal: float = 0.7) -> Optional[Dict[str, Any]]:
        """Return the most emotionally intense memory for a user."""
        try:
            resp = self._request(
                "get",
                f"{API_PREFIX}/memory/last_strong_event/{user_id}",
                params={"min_arousal": min_arousal},
            )
            return resp.json()
        except requests.HTTPError as e:
            if e.response is not None and e.response.status_code == 404:
                return None
            raise

    def delete_user(self, user_id: str) -> int:
        resp = self._request("delete", f"{API_PREFIX}/memory/user/{user_id}")
        return resp.json().get("deleted", 0)

    def delete_memory(self, memory_id: str) -> bool:
        resp = self._request("delete", f"{API_PREFIX}/memory/{memory_id}")
        return resp.status_code == 200

    def review_memory(self, memory_id: str) -> Dict[str, Any]:
        resp = self._request("post", f"{API_PREFIX}/memory/{memory_id}/review", data=json.dumps({}))
        return resp.json()

    def update(self, memory_id: str, changes: Dict[str, Any]) -> bool:
        """Partially update a memory. Keys: content, importance, tags, category, ttl_days."""
        if not changes:
            raise ValueError("At least one field must be provided to update.")
        if "content" in changes and "embedding" not in changes:
            changes["embedding"] = self.embed(changes["content"])
        resp = self._request("post", f"{API_PREFIX}/mas/update/{memory_id}", data=json.dumps(changes))
        return resp.status_code == 200

    def update_memory(
        self,
        memory_id: str,
        *,
        content: Optional[str] = None,
        importance: Optional[float] = None,
        tags: Optional[List[str]] = None,
    ) -> bool:
        """Update fields on an existing memory. Pass only the fields to change."""
        changes: Dict[str, Any] = {}
        if content is not None:
            changes["content"] = content
        if importance is not None:
            changes["importance"] = importance
        if tags is not None:
            changes["tags"] = tags
        return self.update(memory_id, changes)

    def forget(
        self,
        memory_id: str,
        reason: str = "api_delete",
        *,
        tombstone_only: bool = False,
        purge_hot: bool = True,
        purge_episodic: bool = True,
        purge_semantic: bool = True,
        purge_graph: bool = True,
        purge_archive: bool = False,
        write_wal: bool = True,
    ) -> bool:
        """Fine-grained delete with per-layer control."""
        payload = {
            "reason": reason,
            "options": {
                "tombstone_only": tombstone_only,
                "purge_hot": purge_hot,
                "purge_episodic": purge_episodic,
                "purge_semantic": purge_semantic,
                "purge_graph": purge_graph,
                "purge_archive": purge_archive,
                "write_wal": write_wal,
            },
        }
        resp = self._request("post", f"{API_PREFIX}/mas/forget/{memory_id}", data=json.dumps(payload))
        return resp.json().get("status") == "ok"

    def associate(
        self,
        from_id: str,
        to_id: str,
        *,
        edge_type: int = 1,
        strength: float = 0.8,
    ) -> bool:
        """Create a weighted association edge between two memories."""
        payload = {
            "from_id": from_id,
            "to_id": to_id,
            "edge_type": edge_type,
            "strength": strength,
        }
        resp = self._request("post", f"{API_PREFIX}/mas/associate", data=json.dumps(payload))
        return resp.json().get("status") == "ok"

    def list_memories(self, user_id: str, namespace: Optional[str] = None) -> List[Dict[str, Any]]:
        items = self.export_user_all(user_id)
        if namespace:
            tag = f"ns:{namespace}"
            items = [m for m in items if tag in m.get("tags", [])]
        return items

    def export_user(
        self,
        user_id: str,
        *,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
    ) -> Dict[str, Any]:
        """Return the portable profile document for a user."""
        _ = (limit, offset)
        resp = self._request("get", f"{API_PREFIX}/memory/export/{user_id}")
        return resp.json()

    def export_user_all(self, user_id: str) -> List[Dict[str, Any]]:
        """Return only the memories array from the portable profile document."""
        return self.export_user(user_id).get("memories", [])

    def import_profile(
        self,
        profile: Dict[str, Any],
        *,
        target_user_id: Optional[str] = None,
        skip_duplicates: bool = True,
    ) -> Dict[str, Any]:
        payload: Dict[str, Any] = {
            "profile": profile,
            "skip_duplicates": skip_duplicates,
        }
        if target_user_id is not None:
            payload["target_user_id"] = target_user_id
        resp = self._request("post", f"{API_PREFIX}/memory/import", data=json.dumps(payload))
        return resp.json()

    def highlights(self, user_id: str, limit: int = 10) -> List[Dict[str, Any]]:
        resp = self._request("get", f"{API_PREFIX}/memory/highlights/{user_id}")
        return resp.json().get("highlights", [])[:limit]

    def summary(self, user_id: str, days: int = 7) -> str:
        resp = self._request("get", f"{API_PREFIX}/memory/summary/{user_id}", params={"days": days})
        return resp.json().get("summary", "")

    def explain(self, query: str) -> List[Dict[str, Any]]:
        embedding = self.embed(query)
        payload = {"query": query, "embedding": embedding, "k": 5}
        resp = self._request("post", f"{API_PREFIX}/memory/explain", data=json.dumps(payload))
        return resp.json().get("results", [])

    def get_emotion(self) -> Dict[str, Any]:
        """Return the brain's current emotional state.
        Fields: primary_emotion, valence (-1..1), arousal (0..1), mood.
        """
        resp = self._request("get", f"{API_PREFIX}/brain/emotion")
        return resp.json()

    def get_user_emotion(self, user_id: str) -> Dict[str, Any]:
        """Return aggregate emotional state for a specific user."""
        try:
            resp = self._request("get", f"{API_PREFIX}/brain/emotion/{user_id}")
            return resp.json()
        except requests.HTTPError as e:
            if e.response is not None and e.response.status_code == 404:
                return {
                    "primary_emotion": "None",
                    "valence": 0.0,
                    "arousal": 0.0,
                    "dominance": 0.5,
                    "memory_count": 0,
                    "message": "no memories found for user; returning neutral baseline",
                }
            raise

    def stats(self) -> Dict[str, Any]:
        """Return daemon performance and usage metrics."""
        resp = self._request("get", "/metrics", headers={"Accept": "application/json"})
        content_type = resp.headers.get("content-type", "").lower()
        if content_type.startswith("application/json"):
            return resp.json()
        return _parse_prometheus_metrics(resp.text)

    def brain_status(self) -> Dict[str, Any]:
        """Return BrainController developmental stage and internal state."""
        resp = self._request("get", f"{API_PREFIX}/brain/status")
        return resp.json()

    def compact(self, layer: str = "semantic") -> bool:
        """Compact in-memory indexes. layer: semantic | episodic | graph."""
        valid = {"semantic", "episodic", "graph"}
        if layer not in valid:
            raise ValueError(f"layer must be one of {valid}")
        try:
            resp = self._request("post", f"{API_PREFIX}/maintenance/compact/{layer}")
        except requests.HTTPError as e:
            if e.response is not None and e.response.status_code == 503:
                try:
                    body = e.response.json()
                    detail = body.get("message", "maintenance disabled")
                except Exception:
                    detail = "maintenance disabled"
                raise PrajnyavanConfigError(detail) from e
            raise
        return resp.json().get("status") == "ok"

    def recover_from_wal(self) -> bool:
        """Replay WAL into all layers after a crash."""
        try:
            resp = self._request("post", f"{API_PREFIX}/maintenance/recover_from_wal")
        except requests.HTTPError as e:
            if e.response is not None and e.response.status_code == 503:
                try:
                    body = e.response.json()
                    detail = body.get("message", "maintenance disabled")
                except Exception:
                    detail = "maintenance disabled"
                raise PrajnyavanConfigError(detail) from e
            raise
        return resp.json().get("status") == "ok"

    def register_app(self, app_name: str, context_mode: str = "session") -> str:
        """Register an application context."""
        payload = {"app_name": app_name, "context_mode": context_mode}
        resp = self._request("post", f"{API_PREFIX}/app/register", data=json.dumps(payload))
        return resp.json().get("app_id", "")

    def list_apps(self) -> List[Dict[str, Any]]:
        """List registered application contexts."""
        resp = self._request("get", f"{API_PREFIX}/app/list")
        return resp.json().get("applications", [])

    # ---- Agents -----------------------------------------------------------
    def spawn_agent(self, name: str, role: str, goal: str, *, edge: Optional[str] = None, protocol: Optional[list] = None) -> Dict[str, Any]:
        payload = {
            "name": name,
            "role": role,
            "goal": goal,
            "edge": edge,
            "protocol": protocol or [],
        }
        resp = self._request("post", f"{API_PREFIX}/agents", data=json.dumps(payload))
        return resp.json()

    def list_agents(self) -> List[Dict[str, Any]]:
        resp = self._request("get", f"{API_PREFIX}/agents")
        return resp.json().get("agents", [])

    def agent_status(self, agent_id: str) -> Dict[str, Any]:
        resp = self._request("get", f"{API_PREFIX}/agents/{agent_id}")
        if resp.status_code == 404:
            raise MemoryNotFoundError(f"agent {agent_id} not found")
        return resp.json()

    def agent_dream(self, agent_id: str, prompt: Optional[str] = None, *, store: bool = True, tags: Optional[List[str]] = None) -> Dict[str, Any]:
        payload = {"prompt": prompt, "store": store, "tags": tags or []}
        resp = self._request("post", f"{API_PREFIX}/agents/{agent_id}/dream", data=json.dumps(payload))
        return resp.json()

    def run_protocol(self, agent_id: str, steps: Optional[list] = None, *, dry_run: bool = False) -> Dict[str, Any]:
        payload = {"steps": steps or [], "dry_run": dry_run}
        resp = self._request("post", f"{API_PREFIX}/agents/{agent_id}/protocol", data=json.dumps(payload))
        return resp.json()

    def delete_agent(self, agent_id: str) -> bool:
        resp = self._request("delete", f"{API_PREFIX}/agents/{agent_id}")
        return resp.status_code == 204

    # ---- Decorator ----------------------------------------------------------
    def wrap_llm(
        self,
        user_id: str,
        *,
        k: int = 5,
        valence_bias: Optional[str] = None,
        debug: bool = False,
    ):
        def decorator(fn: Callable[..., str]):
            @wraps(fn)
            def wrapper(prompt: str, *args, **kwargs):
                memories = self.search(user_id, prompt, k=k, valence_bias=valence_bias)
                emotion = self.get_emotion() if debug else None

                emotion_line = ""
                if emotion:
                    emotion_line = f"[emotion: {emotion.get('primary_emotion', '?')}/{emotion.get('valence', 0)}]"

                if memories:
                    ctx_lines = [
                        f"- ({m.get('importance', 0):.2f} importance) {m.get('content_text') or m.get('content', '')}"
                        for m in memories
                    ]
                    enriched = "Relevant memories about this user:\n" + "\n".join(ctx_lines) + "\n\nUser message: " + prompt
                else:
                    enriched = prompt

                if emotion_line:
                    enriched = f"{emotion_line}\n{enriched}"

                sig = inspect.signature(fn)
                accepts_kwargs = any(p.kind == inspect.Parameter.VAR_KEYWORD for p in sig.parameters.values())
                call_kwargs = dict(kwargs)

                if accepts_kwargs or "memory_context" in sig.parameters:
                    call_kwargs.setdefault("memory_context", memories)
                if accepts_kwargs or "enriched_prompt" in sig.parameters:
                    call_kwargs.setdefault("enriched_prompt", enriched)

                result = fn(enriched, *args, **call_kwargs)

                try:
                    if prompt.strip():
                        self.smart_store(
                            user_id,
                            prompt,
                            importance=0.4,
                        )
                except PrajnyavanConnectionError:
                    warnings.warn(
                        "[prajnyavan] Memory store failed: daemon unreachable. Run: prajnyavan status",
                        RuntimeWarning,
                        stacklevel=3,
                    )
                except PrajnyavanError as e:
                    warnings.warn(f"[prajnyavan] Memory store failed: {e}", RuntimeWarning, stacklevel=3)

                if debug:
                    return {
                        "result": result,
                        "memories_used": memories,
                        "emotion": emotion,
                        "debug_prompt": enriched,
                    }
                return result

            return wrapper

        return decorator


class SessionMemory:
    """
    Session-scoped memory helper for cooperating agents.
    """

    def __init__(
        self,
        session_id: str,
        user_id: str = "developer",
        client: Optional[MemoryClient] = None,
        **kwargs: Any,
    ) -> None:
        self.session_id = session_id
        self.user_id = user_id
        if client is not None:
            self.client = client
        elif os.environ.get("PRAJNYAVAN_URL") and os.environ.get("PRAJNYAVAN_TOKEN"):
            self.client = MemoryClient.from_env(**kwargs)
        else:
            self.client = MemoryClient.dev(user_id=user_id, **kwargs)

    def store(self, content: str, **kwargs: Any) -> Union[str, Dict[str, Any]]:
        return self.client.store(
            self.user_id,
            content,
            session_id=self.session_id,
            **kwargs,
        )

    def search(self, query: str, **kwargs: Any) -> List[Dict[str, Any]]:
        return self.client.search(
            None,
            query,
            session_id=self.session_id,
            **kwargs,
        )

    def get_context(self, query: str, **kwargs: Any) -> Dict[str, Any]:
        return self.client.get_context(
            self.user_id,
            query,
            session_id=self.session_id,
            **kwargs,
        )

    def subscribe(self) -> str:
        base = self.client.base_url.rstrip("/")
        return f"{base}{API_PREFIX}/memories/stream?session_id={self.session_id}"

    def __getattr__(self, name: str) -> Any:
        return getattr(self.client, name)


# ── Helpers -----------------------------------------------------------------


def get_token(base_url: str, user_id: str = "developer") -> str:
    resp = requests.post(
        f"{base_url.rstrip('/')}/auth/token",
        json={"user_id": user_id, "capabilities": ["read", "write"]},
        timeout=8,
    )
    resp.raise_for_status()
    return f"Bearer {resp.json()['token']}"


def auto_client(user_id: str = "developer", **kwargs: Any) -> MemoryClient:
    cfg = _load_config()
    if not cfg:
        cfg = ensure_daemon_running()
    base_url = cfg.get("base_url")
    token = get_token(base_url, user_id=user_id)
    client = MemoryClient(base_url=base_url, token=token, **kwargs)
    client._can_auto_refresh = True
    return client


__all__ = ["MemoryClient", "SessionMemory", "get_token", "auto_client"]
