from __future__ import annotations

import json
import os
from typing import Any, AsyncIterator, Dict, List, Optional, Union

import httpx

from ._daemon import _load_config, _save_config, ensure_daemon_running
from .client import (
    API_PREFIX,
    _DEFAULT_BULK_STORE_CHUNK_SIZE,
    _chunk_items,
    _embed_cohere,
    _embed_local,
    _embed_openai,
    _hash_embed,
)
from .exceptions import (
    DimensionMismatchError,
    MemoryNotFoundError,
    PIIBlockedError,
    PrajnyavanAuthError,
    PrajnyavanConfigError,
    PrajnyavanConnectionError,
    QuotaError,
)
from .models import MemoryEvent


class AsyncMemoryClient:
    """Async Prajnyavan memory client backed by httpx."""

    def __init__(
        self,
        base_url: Optional[str] = None,
        token: Optional[str] = None,
        openai_api_key: Optional[str] = None,
        embedding_provider: str = "local",
        embedding_model: Optional[str] = None,
    ) -> None:
        if base_url is None or token is None:
            cfg = _load_config()
            if not cfg:
                raise PrajnyavanConfigError(
                    "base_url and token are required unless prajnyavan dev has been started."
                )
            base_url = base_url or cfg["base_url"]
            token = token or cfg["token"]

        self.base_url = base_url.rstrip("/")
        self.token = token
        self.embedding_provider = embedding_provider
        self.embedding_model = embedding_model
        self._openai_key = openai_api_key or os.environ.get("OPENAI_API_KEY")
        self._can_auto_refresh = False

        if self.base_url.startswith("http+unix://"):
            raise PrajnyavanConfigError("AsyncMemoryClient does not support UDS URLs yet.")

        self.client = httpx.AsyncClient(
            headers={
                "authorization": token,
                "content-type": "application/json",
            },
            timeout=10.0,
        )

    @classmethod
    def dev(cls, **kwargs: Any) -> "AsyncMemoryClient":
        cfg = ensure_daemon_running()
        client = cls(
            base_url=cfg["base_url"],
            token=cfg["token"],
            embedding_provider=kwargs.pop("embedding_provider", "hash"),
            **kwargs,
        )
        client._can_auto_refresh = True
        return client

    @classmethod
    def from_env(cls, **kwargs: Any) -> "AsyncMemoryClient":
        url = os.environ.get("PRAJNYAVAN_URL")
        token = os.environ.get("PRAJNYAVAN_TOKEN")
        if not url or not token:
            missing = [
                name
                for name, value in (
                    ("PRAJNYAVAN_URL", url),
                    ("PRAJNYAVAN_TOKEN", token),
                )
                if not value
            ]
            raise PrajnyavanConfigError(
                f"Missing env vars: {missing}. Use AsyncMemoryClient.dev() for local development."
            )
        provider = os.environ.get("PRAJNYAVAN_EMBEDDING_PROVIDER", "local")
        return cls(base_url=url, token=token, embedding_provider=provider, **kwargs)

    @classmethod
    def hosted(
        cls,
        *,
        base_url: Optional[str] = None,
        token: Optional[str] = None,
        **kwargs: Any,
    ) -> "AsyncMemoryClient":
        resolved_url = base_url or os.environ.get("PRAJNYAVAN_HOSTED_URL") or os.environ.get("PRAJNYAVAN_URL")
        resolved_token = token or os.environ.get("PRAJNYAVAN_TOKEN")
        if not resolved_url:
            raise PrajnyavanConfigError(
                "base_url is required for hosted mode unless PRAJNYAVAN_HOSTED_URL or PRAJNYAVAN_URL is set."
            )
        if not resolved_token:
            raise PrajnyavanConfigError("token is required for hosted mode unless PRAJNYAVAN_TOKEN is set.")
        return cls(base_url=resolved_url, token=resolved_token, **kwargs)

    async def aclose(self) -> None:
        await self.client.aclose()

    async def __aenter__(self) -> "AsyncMemoryClient":
        return self

    async def __aexit__(self, exc_type, exc, tb) -> None:
        await self.aclose()

    async def _refresh_token(self) -> None:
        from .client import get_token

        new_token = get_token(self.base_url)
        self.token = new_token
        self.client.headers["authorization"] = new_token
        cfg = _load_config() or {}
        if cfg:
            cfg["token"] = new_token
            _save_config(cfg)

    async def _request(
        self, method: str, path: str, retry: bool = True, **kwargs: Any
    ) -> httpx.Response:
        url = f"{self.base_url}{path}"
        try:
            resp = await self.client.request(method, url, **kwargs)
        except httpx.HTTPError as exc:
            raise PrajnyavanConnectionError(f"Daemon unreachable: {exc}") from exc

        if resp.status_code in (401, 403):
            if self._can_auto_refresh and retry:
                try:
                    await self._refresh_token()
                    return await self._request(method, path, retry=False, **kwargs)
                except Exception:
                    pass
            raise PrajnyavanAuthError(
                "Token expired or unauthorized.",
                error_code=(
                    resp.json().get("error_code")
                    if resp.headers.get("content-type", "").startswith("application/json")
                    else None
                ),
                request_id=resp.headers.get("X-Request-ID"),
            )

        if resp.status_code == 404:
            if path.startswith(API_PREFIX):
                return await self._request(
                    method, path.replace(API_PREFIX, "", 1), retry=retry, **kwargs
                )
            raise MemoryNotFoundError(
                "Memory not found",
                error_code="MEMORY_NOT_FOUND",
                request_id=resp.headers.get("X-Request-ID"),
            )

        if resp.status_code == 422:
            try:
                body = resp.json()
            except Exception:
                body = {}
            code = body.get("error_code")
            if code == "PII_BLOCKED":
                raise PIIBlockedError(
                    body.get("message", "PII blocked"),
                    pii_types=body.get("pii_types", []),
                    error_code=code,
                    request_id=resp.headers.get("X-Request-ID"),
                )
            if code == "DIMENSION_MISMATCH":
                raise DimensionMismatchError(
                    body.get("message", "Embedding dimension mismatch"),
                    error_code=code,
                    request_id=resp.headers.get("X-Request-ID"),
                )

        if resp.status_code == 429:
            retry_after = resp.headers.get("Retry-After")
            raise QuotaError(
                "Rate limit exceeded",
                retry_after=int(retry_after) if retry_after and retry_after.isdigit() else None,
                error_code="QUOTA_EXCEEDED",
                request_id=resp.headers.get("X-Request-ID"),
            )

        resp.raise_for_status()
        return resp

    def _embed_raw(self, text: str) -> List[float]:
        if self.embedding_provider == "hash":
            return _hash_embed(text)
        if self.embedding_provider == "openai":
            if not self._openai_key:
                raise PrajnyavanConfigError("OPENAI_API_KEY required for openai embeddings.")
            model = self.embedding_model or "text-embedding-3-small"
            return _embed_openai(text, self._openai_key, model=model)
        if self.embedding_provider == "cohere":
            api_key = os.environ.get("COHERE_API_KEY")
            if not api_key:
                raise PrajnyavanConfigError("COHERE_API_KEY required for cohere embeddings.")
            model = self.embedding_model or "embed-english-v3.0"
            return _embed_cohere(text, api_key, model=model)
        if self.embedding_provider == "local":
            return _embed_local(text, self.embedding_model or "all-mpnet-base-v2")
        return _hash_embed(text)

    def embed(self, text: str) -> List[float]:
        return self._embed_raw(text)

    async def store(
        self,
        user_id: str,
        content: str,
        *,
        namespace: Optional[str] = None,
        importance: Optional[float] = None,
        category: Optional[str] = None,
        ttl_days: Optional[int] = None,
        tags: Optional[List[str]] = None,
        memory_id: Optional[str] = None,
        valence: Optional[float] = None,
        arousal: Optional[float] = None,
        return_metadata: bool = False,
        idempotency_key: Optional[str] = None,
        session_id: Optional[str] = None,
    ) -> Union[str, Dict[str, Any]]:
        payload: Dict[str, Any] = {
            "content": content,
            "embedding": self.embed(content),
            "context": {"who": user_id, "embedding_provider": self.embedding_provider},
            "user_id": user_id,
            "tags": list(tags or []),
            "category": category,
            "session_id": session_id,
            "ttl_days": ttl_days,
            "importance": importance,
            "memory_id": memory_id,
            "modality": "text",
            "valence": valence,
            "arousal": arousal,
            "pinned": False,
        }
        if namespace:
            payload["tags"].append(f"ns:{namespace}")
        if idempotency_key:
            payload["idempotency_key"] = idempotency_key

        resp = await self._request("POST", f"{API_PREFIX}/memory", json=payload)
        data = resp.json()
        return data if return_metadata else data.get("memory_id", data.get("id"))

    async def smart_store(
        self,
        user_id: str,
        content: str,
        **kwargs: Any,
    ) -> Dict[str, Any]:
        payload: Dict[str, Any] = {
            "content": content,
            "embedding": kwargs.pop("embedding", None) or self.embed(content),
            "context": kwargs.pop(
                "context",
                {"who": user_id, "embedding_provider": self.embedding_provider},
            ),
            "user_id": user_id,
            "tags": kwargs.pop("tags", []),
            "category": kwargs.pop("category", None),
            "session_id": kwargs.pop("session_id", None),
            "ttl_days": kwargs.pop("ttl_days", None),
            "importance": kwargs.pop("importance", None),
            "memory_id": kwargs.pop("memory_id", None),
            "modality": kwargs.pop("modality", "text"),
            "memory_type": kwargs.pop("memory_type", None),
            "idempotency_key": kwargs.pop("idempotency_key", None),
        }
        if kwargs:
            payload.update(kwargs)
        resp = await self._request("POST", f"{API_PREFIX}/memory/smart", json=payload)
        return resp.json()

    async def search(
        self,
        user_id: str,
        query: str,
        *,
        namespace: Optional[str] = None,
        k: int = 5,
        top_k: Optional[int] = None,
        valence_bias: Optional[str] = None,
        min_importance: Optional[float] = None,
        category: Optional[str] = None,
        exact_match: bool = False,
        min_valence: Optional[float] = None,
        max_valence: Optional[float] = None,
        min_arousal: Optional[float] = None,
        max_arousal: Optional[float] = None,
        emotion_boost: Optional[float] = None,
        session_id: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        resolved_k = top_k if top_k is not None else k
        payload: Dict[str, Any] = {
            "query": query,
            "embedding": self.embed(query),
            "k": resolved_k,
            "filters": {"person": user_id},
            "exact_match": exact_match,
        }
        if valence_bias:
            payload["filters"]["valence_bias"] = valence_bias
        if min_importance is not None:
            payload["filters"]["min_importance"] = min_importance
        if category:
            payload["filters"]["category"] = category
        if namespace:
            payload["filters"]["tags"] = [f"ns:{namespace}"]
        if min_valence is not None:
            payload["filters"]["min_valence"] = min_valence
        if max_valence is not None:
            payload["filters"]["max_valence"] = max_valence
        if min_arousal is not None:
            payload["filters"]["min_arousal"] = min_arousal
        if max_arousal is not None:
            payload["filters"]["max_arousal"] = max_arousal
        if emotion_boost is not None:
            payload["filters"]["emotion_boost"] = emotion_boost
        if session_id is not None:
            payload["filters"]["session_id"] = session_id

        resp = await self._request("POST", f"{API_PREFIX}/memory/search", json=payload)
        results = resp.json().get("results", [])
        if namespace:
            results = [
                item
                for item in results
                if any(tag == f"ns:{namespace}" for tag in item.get("tags", []))
            ]
        return results

    async def get_context(
        self,
        user_id: str,
        query: str,
        max_tokens: int = 500,
        embedding: Optional[List[float]] = None,
        session_id: Optional[str] = None,
        profile: Optional[str] = None,
    ) -> Dict[str, Any]:
        payload: Dict[str, Any] = {
            "user_id": user_id,
            "query": query,
            "max_tokens": max_tokens,
            "embedding": embedding if embedding is not None else self.embed(query),
        }
        if session_id is not None:
            payload["session_id"] = session_id
        if profile is not None:
            payload["profile"] = profile
        resp = await self._request("POST", f"{API_PREFIX}/memory/context", json=payload)
        return resp.json()

    async def bulk_store(
        self,
        user_id: str,
        items: List[Dict[str, Any]],
        *,
        ttl_days: Optional[int] = None,
        session_id: Optional[str] = None,
        allow_duplicates: bool = True,
        chunk_size: int = _DEFAULT_BULK_STORE_CHUNK_SIZE,
    ) -> Dict[str, Any]:
        chunks = _chunk_items(items, chunk_size) if items else []
        if not chunks:
            return {"stored": 0, "errors": 0, "unique_ids": 0, "ids": [], "chunks": 0}

        ids: List[str] = []
        errors = 0
        stored_total = 0

        for chunk in chunks:
            memories: List[Dict[str, Any]] = []
            for item in chunk:
                content = item["content"]
                memories.append(
                    {
                        "content": content,
                        "embedding": item.get("embedding") or self.embed(content),
                        "context": item.get(
                            "context",
                            {"who": item.get("user_id", user_id), "embedding_provider": self.embedding_provider},
                        ),
                        "user_id": item.get("user_id"),
                        "tags": item.get("tags", []),
                        "category": item.get("category"),
                        "session_id": item.get("session_id", session_id),
                        "ttl_days": ttl_days if ttl_days is not None else item.get("ttl_days"),
                        "importance": item.get("importance"),
                        "memory_id": item.get("memory_id"),
                        "modality": item.get("modality", "text"),
                        "memory_type": item.get("memory_type"),
                        "idempotency_key": item.get("idempotency_key"),
                    }
                )
            payload = {
                "user_id": user_id,
                "memories": memories,
                "allow_duplicates": allow_duplicates,
            }
            resp = await self._request("POST", f"{API_PREFIX}/memory/bulk", json=payload)
            chunk_payload = resp.json()
            ids.extend(chunk_payload.get("ids", []))
            stored_total += int(chunk_payload.get("stored", len(chunk_payload.get("ids", []))))
            errors += int(chunk_payload.get("errors", 0))

        return {
            "stored": stored_total,
            "errors": errors,
            "unique_ids": len(set(ids)),
            "ids": ids,
            "chunks": len(chunks),
        }

    async def review_memory(self, memory_id: str) -> Dict[str, Any]:
        resp = await self._request("POST", f"{API_PREFIX}/memory/{memory_id}/review", json={})
        return resp.json()

    async def export_user(
        self,
        user_id: str,
        *,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
    ) -> Dict[str, Any]:
        _ = (limit, offset)
        resp = await self._request("GET", f"{API_PREFIX}/memory/export/{user_id}")
        return resp.json()

    async def import_profile(
        self,
        profile: Dict[str, Any],
        *,
        target_user_id: Optional[str] = None,
        skip_duplicates: bool = True,
    ) -> Dict[str, Any]:
        payload: Dict[str, Any] = {
            "profile": profile,
            "skip_duplicates": skip_duplicates,
        }
        if target_user_id is not None:
            payload["target_user_id"] = target_user_id
        resp = await self._request("POST", f"{API_PREFIX}/memory/import", json=payload)
        return resp.json()

    async def stream_events(self, session_id: Optional[str] = None) -> AsyncIterator[MemoryEvent]:
        url = f"{self.base_url}{API_PREFIX}/memories/stream"
        params = {"session_id": session_id} if session_id is not None else None
        async with self.client.stream("GET", url, params=params) as resp:
            if resp.status_code in (401, 403):
                raise PrajnyavanAuthError(
                    "Token expired or unauthorized.",
                    request_id=resp.headers.get("X-Request-ID"),
                )
            resp.raise_for_status()

            data_lines: List[str] = []
            async for line in resp.aiter_lines():
                if not line:
                    if not data_lines:
                        continue
                    payload = json.loads("\n".join(data_lines))
                    data_lines.clear()
                    yield MemoryEvent(
                        event_type=payload["event_type"],
                        id=payload["id"],
                        tags=payload.get("tags", []),
                    )
                    continue
                if line.startswith("data: "):
                    data_lines.append(line[6:])

    async def stream(self, session_id: Optional[str] = None) -> AsyncIterator[MemoryEvent]:
        async for event in self.stream_events(session_id=session_id):
            yield event


class AsyncSessionMemory:
    """Async session-scoped memory helper for cooperating agents."""

    def __init__(
        self,
        session_id: str,
        user_id: str = "developer",
        client: Optional[AsyncMemoryClient] = None,
        **kwargs: Any,
    ) -> None:
        self.session_id = session_id
        self.user_id = user_id
        if client is not None:
            self.client = client
        elif os.environ.get("PRAJNYAVAN_URL") and os.environ.get("PRAJNYAVAN_TOKEN"):
            self.client = AsyncMemoryClient.from_env(**kwargs)
        else:
            self.client = AsyncMemoryClient.dev(**kwargs)

    async def store(self, content: str, **kwargs: Any) -> Union[str, Dict[str, Any]]:
        return await self.client.store(
            self.user_id,
            content,
            session_id=self.session_id,
            **kwargs,
        )

    async def search(self, query: str, **kwargs: Any) -> List[Dict[str, Any]]:
        return await self.client.search(
            None,
            query,
            session_id=self.session_id,
            **kwargs,
        )

    async def get_context(self, query: str, **kwargs: Any) -> Dict[str, Any]:
        return await self.client.get_context(
            self.user_id,
            query,
            session_id=self.session_id,
            **kwargs,
        )

    def subscribe(self) -> str:
        base = self.client.base_url.rstrip("/")
        return f"{base}{API_PREFIX}/memories/stream?session_id={self.session_id}"

    async def stream(self) -> AsyncIterator[MemoryEvent]:
        async for event in self.client.stream(session_id=self.session_id):
            yield event

    async def aclose(self) -> None:
        await self.client.aclose()

    async def __aenter__(self) -> "AsyncSessionMemory":
        return self

    async def __aexit__(self, exc_type, exc, tb) -> None:
        await self.aclose()

    def __getattr__(self, name: str) -> Any:
        return getattr(self.client, name)
