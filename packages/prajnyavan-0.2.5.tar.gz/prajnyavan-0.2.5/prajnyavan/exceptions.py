﻿class PrajnyavanError(Exception):
    """Base exception for Prajnyavan."""

    def __init__(self, message, error_code=None, hint=None, request_id=None):
        self.error_code = error_code
        self.hint = hint
        self.request_id = request_id
        super().__init__(message)


class PrajnyavanConnectionError(PrajnyavanError):
    """Daemon unreachable."""


class PrajnyavanAuthError(PrajnyavanError):
    """Token expired or invalid."""


class PrajnyavanSetupError(PrajnyavanError):
    """Binary missing or daemon failed to start."""


class PrajnyavanConfigError(PrajnyavanError):
    """Required configuration missing."""


class DimensionMismatchError(PrajnyavanError):
    """Embedding dimension mismatch."""


class QuotaError(PrajnyavanError):
    def __init__(self, msg, retry_after=None, **kw):
        self.retry_after = retry_after
        super().__init__(msg, **kw)


class MemoryNotFoundError(PrajnyavanError):
    """Requested memory not found."""


class PIIBlockedError(PrajnyavanError):
    def __init__(self, msg, pii_types=None, **kw):
        self.pii_types = pii_types or []
        super().__init__(msg, **kw)
