"""YouTube video analysis and content generation pipeline exposed as MCP tools."""

__version__ = "0.5.1"
