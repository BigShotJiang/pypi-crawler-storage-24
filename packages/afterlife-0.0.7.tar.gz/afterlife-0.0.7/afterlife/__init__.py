"""
Afterlife — Precision astrological chart engine with a terminal CLI.

Public API::

    from afterlife import Afterlife
    import json

    eng   = Afterlife()
    chart = json.loads(eng.compute_astro_chart(
        date_str="01-01-1990",
        time_str="12:00",
        lat=41.0,
        lon=29.0,
        house_system="placidus",  # placidus | whole | equal | koch | ...
        tz_offset=3.0,
        sort_by="",               # name | lon | house | sign
        exclude="",               # comma-separated body names
        include="",               # comma-separated body names
        limit=0,                  # 0 = unlimited
    ))

    print(chart["bodies"]["planets"])
    print(chart["bodies"]["centaurs"])
"""
from afterlife._version import __version__
from afterlife.engine import Afterlife

__all__ = ["Afterlife", "__version__"]
