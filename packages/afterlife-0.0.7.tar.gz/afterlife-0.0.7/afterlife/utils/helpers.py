from __future__ import annotations

import json
import unicodedata
from typing import Any, Dict, List, Optional, Tuple

from afterlife.constants import ARABIC_LOT_ABBR, SIGNS_EN


def is_true(val: Any) -> bool:
    if isinstance(val, bool):
        return val
    if val is None:
        return False
    return str(val).lower() in ("true", "1", "yes", "on")


def ang_dist(a: float, b: float) -> float:
    return abs((a - b + 180.0) % 360.0 - 180.0)


def norm360(x: float) -> float:
    x = x % 360.0
    return x + 360.0 if x < 0 else x


def zodiac_sign(lon: float) -> Tuple[str, float]:
    lon = norm360(lon)
    idx = int(lon // 30)
    return SIGNS_EN[idx], lon - idx * 30


def split_house_list(house_str: Optional[str]) -> List[int]:
    out: List[int] = []
    if not house_str:
        return out
    for part in str(house_str).split(","):
        try:
            h = int(part.strip())
            if 1 <= h <= 12:
                out.append(h)
        except ValueError:
            pass
    return out