"""afterlife utils package."""
