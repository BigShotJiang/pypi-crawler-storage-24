"""afterlife CLI package."""
