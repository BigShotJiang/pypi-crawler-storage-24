from __future__ import annotations

import json
from typing import Any, Dict, List, Optional

from rich import box
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text
from rich import print as rprint

# ---------------------------------------------------------------------------
# Theme constants
# ---------------------------------------------------------------------------
PURPLE  = "#ae00ff"
WHITE   = "#ffffff"
DIM     = "dim white"
ACCENT  = "bold #ae00ff"
HEADER  = "bold white on #ae00ff"
ERROR   = "bold red"
SUCCESS = "bold #ae00ff"

console = Console(highlight=False)


# ---------------------------------------------------------------------------
# Low-level helpers
# ---------------------------------------------------------------------------

def _col(text: str, style: str = WHITE) -> Text:
    return Text(str(text), style=style)


def _table(title: str, columns: List[tuple]) -> Table:
    t = Table(
        title       = title,
        title_style = ACCENT,
        box         = box.SIMPLE_HEAD,
        border_style= PURPLE,
        header_style= f"bold {PURPLE}",
        show_lines  = False,
        pad_edge    = False,
        expand      = False,
    )
    for header, style, justify in columns:
        t.add_column(header, style=style, justify=justify, no_wrap=True)
    return t


def _retro(obj: Dict[str, Any]) -> str:
    return "[dim]℞[/dim]" if obj.get("retro") else ""


def _glyph(name: str) -> str:
    from afterlife.constants import PLANET_GLYPH
    return PLANET_GLYPH.get(name, "")


# ---------------------------------------------------------------------------
# Error / info panels
# ---------------------------------------------------------------------------

def show_error(msg: str) -> None:
    console.print(Panel(f"[{ERROR}]{msg}[/]", title="[bold red]Error[/]", border_style="red"))


def show_json(data: Any) -> None:
    console.print_json(json.dumps(data, ensure_ascii=False, indent=2))


# ---------------------------------------------------------------------------
# Input summary panel
# ---------------------------------------------------------------------------

def show_input_panel(inp: Dict[str, Any]) -> None:
    lines = [
        f"[{DIM}]Date      :[/]  [{WHITE}]{inp.get('date', '')}[/]",
        f"[{DIM}]Time      :[/]  [{WHITE}]{inp.get('time', '')}[/]",
        f"[{DIM}]Latitude  :[/]  [{WHITE}]{inp.get('lat', '')}[/]",
        f"[{DIM}]Longitude :[/]  [{WHITE}]{inp.get('lon', '')}[/]",
        f"[{DIM}]Timezone  :[/]  [{WHITE}]{inp.get('tz_offset', '')}[/]",
        f"[{DIM}]Houses    :[/]  [{WHITE}]{inp.get('house_system', 'placidus').title()}[/]",
    ]
    console.print(Panel("\n".join(lines), title="[bold #ae00ff]Chart Input[/]", border_style=PURPLE))


# ---------------------------------------------------------------------------
# Bodies table
# ---------------------------------------------------------------------------

def show_bodies(bodies: Dict[str, Any], title: str = "Bodies") -> None:
    from afterlife.constants import CATEGORY_TITLES_BASE

    for cat, objs in bodies.items():
        if not isinstance(objs, dict) or not objs:
            continue
        cat_title = CATEGORY_TITLES_BASE.get(cat, cat.upper())
        t = _table(
            cat_title,
            [
                ("Glyph", PURPLE,     "center"),
                ("Name",  WHITE,      "left"),
                ("Sign",  DIM,        "left"),
                ("Deg",   DIM,        "left"),
                ("House", PURPLE,     "right"),
                ("",      "dim",      "left"),   # retro / flags
            ],
        )
        for name, obj in objs.items():
            if not isinstance(obj, dict):
                continue
            raw_dms = obj.get("dms", "")
            sign    = obj.get("sign", "")
            deg_only = raw_dms.replace(sign, "").strip() if sign and raw_dms.startswith(sign) else raw_dms
            t.add_row(
                _glyph(name),
                name,
                sign,
                deg_only,
                str(obj.get("house", "")),
                _retro(obj),
            )
        console.print(t)


# ---------------------------------------------------------------------------
# Houses table
# ---------------------------------------------------------------------------

def show_houses(houses: Dict[str, Any]) -> None:
    if not houses or not houses.get("cusps"):
        return
    t = _table(
        f"Houses — {houses.get('system', '').title()}",
        [
            ("House", PURPLE, "right"),
            ("Cusp",  WHITE,  "left"),
        ],
    )
    for i, cusp in enumerate(houses["cusps"], 1):
        t.add_row(str(i), f"{cusp:.4f}°")
    angles = houses.get("angles", {})
    if angles:
        t.add_row("ASC", f"{angles.get('ASC', ''):.4f}°")
        t.add_row("MC",  f"{angles.get('MC',  ''):.4f}°")
    console.print(t)


# ---------------------------------------------------------------------------
# Aspects table
# ---------------------------------------------------------------------------

def show_aspects(aspects: List[Dict[str, Any]]) -> None:
    if not aspects:
        return
    from afterlife.constants import ASPECT_GLYPH
    t = _table(
        "Aspects",
        [
            ("A",      WHITE,  "right"),
            ("Glyph",  PURPLE, "center"),
            ("Aspect", DIM,    "left"),
            ("B",      WHITE,  "left"),
            ("Orb",    DIM,    "right"),
        ],
    )
    for asp in aspects:
        t.add_row(
            asp.get("a", ""),
            ASPECT_GLYPH.get(asp.get("aspect", ""), ""),
            asp.get("aspect", ""),
            asp.get("b", ""),
            f"{asp.get('orb', 0):.2f}°",
        )
    console.print(t)


# ---------------------------------------------------------------------------
# Moon cycle
# ---------------------------------------------------------------------------

def show_moon_cycle(data: Dict[str, Any]) -> None:
    t = _table(
        f"Moon Cycle — {data.get('year')}/{data.get('month')}",
        [
            ("Date",         WHITE,  "left"),
            ("Phase",        PURPLE, "left"),
            ("Illumination", DIM,    "right"),
            ("Moon Sign",    DIM,    "left"),
            ("Moon DMS",     DIM,    "left"),
            ("Lunar Day",    DIM,    "right"),
        ],
    )
    for day in data.get("days", []):
        if day.get("missing"):
            continue
        t.add_row(
            day["date"],
            day.get("phase", ""),
            f"{day.get('illumination', 0):.1f}%",
            day.get("moon", {}).get("sign", ""),
            day.get("moon", {}).get("dms",  ""),
            str(day.get("lunar_day", "")),
        )
    console.print(t)


# ---------------------------------------------------------------------------
# Transit events
# ---------------------------------------------------------------------------

def show_transit_events(data: Dict[str, Any]) -> None:
    t = _table(
        "Transit Events",
        [
            ("Date",   WHITE,  "left"),
            ("Type",   PURPLE, "left"),
            ("Detail", DIM,    "left"),
        ],
    )
    events = data.get("transit", {}).get("events", [])
    for ev in events:
        detail_parts = []
        for k in ("sign", "house", "degree", "with", "orb"):
            v = ev.get(k)
            if v is not None:
                detail_parts.append(f"{k}={v}")
        t.add_row(
            ev.get("date", ""),
            ev.get("type", ""),
            "  ".join(detail_parts),
        )
    console.print(t)


# ---------------------------------------------------------------------------
# Yearly transits
# ---------------------------------------------------------------------------

def show_yearly_transits(data: Dict[str, Any]) -> None:
    console.print(
        Panel(
            f"[{WHITE}]Year: [{PURPLE}]{data.get('year')}[/]  "
            f"Bodies: [{PURPLE}]{len(data.get('transits', {}))}[/]",
            title="[bold #ae00ff]Yearly Transits[/]",
            border_style=PURPLE,
        )
    )
    for body, events in (data.get("transits") or {}).items():
        t = _table(
            f"[bold]{body}[/]",
            [
                ("Date",   WHITE,  "left"),
                ("Type",   PURPLE, "left"),
                ("Detail", DIM,    "left"),
            ],
        )
        for ev in (events or []):
            detail_parts = []
            for k in ("sign", "house", "degree", "with", "orb"):
                v = ev.get(k)
                if v is not None:
                    detail_parts.append(f"{k}={v}")
            t.add_row(ev.get("date",""), ev.get("type",""), "  ".join(detail_parts))
        console.print(t)


# ---------------------------------------------------------------------------
# Object list
# ---------------------------------------------------------------------------

def show_object_list(data: Dict[str, Any]) -> None:
    objects: List[str] = data.get("objects", [])
    t = _table(
        f"Supported Objects ({data.get('count', len(objects))})",
        [("Name", WHITE, "left")],
    )
    for name in objects:
        t.add_row(name)
    console.print(t)


# ---------------------------------------------------------------------------
# Search results
# ---------------------------------------------------------------------------

def show_search_results(data: Dict[str, Any]) -> None:
    results: List[Dict[str, Any]] = data.get("results", [])
    t = _table(
        f"Search: {data.get('query', '')}  ({data.get('count', len(results))} results)",
        [
            ("Name",     WHITE,  "left"),
            ("Type",     PURPLE, "left"),
            ("Category", DIM,    "left"),
        ],
    )
    for obj in results:
        t.add_row(
            obj.get("name", ""),
            obj.get("type", ""),
            obj.get("category", ""),
        )
    console.print(t)


# ---------------------------------------------------------------------------
# Quick snapshot
# ---------------------------------------------------------------------------

def show_quick_snapshot(data: Dict[str, Any]) -> None:
    r = data.get("range", {})
    console.print(
        Panel(
            f"[{WHITE}]Mode: [{PURPLE}]{data.get('quick_mode')}[/]  "
            f"[{DIM}]{r.get('start','')} → {r.get('end','')}[/]",
            title="[bold #ae00ff]Quick Transits[/]",
            border_style=PURPLE,
        )
    )
    snap = data.get("snapshot", {})
    if snap:
        t = _table(
            "Current Positions",
            [
                ("Glyph", PURPLE, "center"),
                ("Planet", WHITE, "left"),
                ("Sign",   DIM,   "left"),
                ("DMS",    DIM,   "left"),
            ],
        )
        for name, obj in snap.items():
            if isinstance(obj, dict):
                t.add_row(
                    _glyph(name),
                    name,
                    obj.get("sign", ""),
                    obj.get("dms",  ""),
                )
        console.print(t)


# ---------------------------------------------------------------------------
# Master dispatcher
# ---------------------------------------------------------------------------

def render(payload: Dict[str, Any], output_json: bool = False) -> None:
    if output_json:
        show_json(payload)
        return

    if "error" in payload:
        show_error(str(payload["error"]))
        return

    mode = payload.get("mode", "chart")

    if mode == "chart":
        chart = payload.get("chart", payload)
        inp   = chart.get("input", {})
        if inp:
            show_input_panel(inp)
        bodies = chart.get("bodies", {})
        if bodies:
            show_bodies(bodies)
        houses = chart.get("houses", {})
        if houses:
            show_houses(houses)
        aspects = chart.get("aspects", [])
        if aspects:
            show_aspects(aspects)
        totals = chart.get("totals", {})
        if totals:
            console.print(
                f"[{DIM}]Total objects: [{PURPLE}]{totals.get('overall', '')}[/]"
            )

    elif mode == "chart_find":
        chart = payload.get("chart", {})
        show_bodies(chart.get("bodies", {}))

    elif mode == "moon_cycle":
        show_moon_cycle(payload)

    elif mode == "transit_snapshot":
        show_transit_events(payload)

    elif mode == "yearly_transits":
        show_yearly_transits(payload)

    elif mode == "quick_transits":
        show_quick_snapshot(payload)

    elif mode == "list":
        show_object_list(payload)

    elif mode == "search":
        show_search_results(payload)

    else:
        show_json(payload)
