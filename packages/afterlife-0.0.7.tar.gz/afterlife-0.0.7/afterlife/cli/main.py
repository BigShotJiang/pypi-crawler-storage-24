"""
Afterlife CLI — Precision astrological chart engine with a terminal CLI.

Usage (after pip install afterlife):
    afterlife chart --date 01-01-1990 --time 12:00 --lat 41.0 --lon 29.0
    afterlife moon 2026-3
    afterlife transit --date 01-01-1990 --time 12:00 --lat 41.0 --lon 29.0 \\
                      --body Saturn --from 2026-01-01 --to 2026-12-31
    afterlife transits --date 01-01-1990 --time 12:00 --lat 41.0 --lon 29.0 --year 2026
    afterlife quick today --lat 41.0 --lon 29.0
    afterlife list
    afterlife search chiron

All commands accept --json to get raw JSON output.
"""
from __future__ import annotations

import sys
from typing import Optional

import typer
from rich.console import Console

from afterlife.cli import display
from afterlife.cli import runner

app     = typer.Typer(
    name            = "afterlife",
    help            = "Precision astrological chart engine with a terminal CLI.",
    no_args_is_help = True,
    rich_markup_mode= "rich",
    add_completion  = True,
)
console = Console(highlight=False)

# ---------------------------------------------------------------------------
# Shared option defaults (DRY)
# ---------------------------------------------------------------------------

_OPT = {
    "date":    typer.Option(None, "--date", "-d"),
    "time":    typer.Option(None, "--time", "-t"),
    "lat":     typer.Option(None, "--lat"),
    "lon":     typer.Option(None, "--lon"),
    "tz":      typer.Option(3.0, "--tz"),
    "hs":      typer.Option("placidus", "--house-system", "-H"),
    "orb":     typer.Option(2.5, "--fixed-star-orb"),
    "include": typer.Option(None, "--include", "-i"),
    "exclude": typer.Option("", "--exclude", "-e"),
    "sign":    typer.Option(None, "--sign"),
    "house":   typer.Option(None, "--house"),
    "parent":  typer.Option(None, "--parent"),
    "json":    typer.Option(False, "--json", "-J"),
    "ephe":    typer.Option(None, "--ephe-dir"),

    "sort_by": typer.Option("", "--sort-by", "-s", help="Sort bodies by: name | lon | house | sign"),
    "limit": typer.Option(0, "--limit"),

    "planets_limit": typer.Option(0, "--planets-limit"),
    "moons_limit": typer.Option(0, "--moons-limit"),
    "dwarfs_limit": typer.Option(0, "--dwarfs-limit"),
    "asteroids_limit": typer.Option(0, "--asteroids-limit"),
    "centaurs_limit": typer.Option(0, "--centaurs-limit"),
    "points_limit": typer.Option(0, "--points-limit"),
    "advanced_points_limit": typer.Option(0, "--advanced-points-limit"),
    "lilith_limit": typer.Option(0, "--lilith-limit"),
    "planetary_nodes_limit": typer.Option(0, "--planetary-nodes-limit"),
    "exoplanets_limit": typer.Option(0, "--exoplanets-limit"),
    "interstellar_limit": typer.Option(0, "--interstellar-limit"),
    "fixed_stars_limit": typer.Option(0, "--fixed-stars-limit"),
    "arabic_lots_limit": typer.Option(0, "--arabic-lots-limit"),

    "show_houses":          typer.Option(True, "--show-houses/--no-houses"),
    "show_aspects":         typer.Option(True, "--show-aspects/--no-aspects"),
    "show_fixed_stars":     typer.Option(True, "--show-fixed-stars/--no-fixed-stars"),
    "show_arabic_lots":     typer.Option(True, "--show-arabic-lots/--no-arabic-lots"),
    "show_planetary_nodes": typer.Option(True, "--show-planetary-nodes/--no-planetary-nodes"),
    "show_eclipses":        typer.Option(True, "--show-eclipses/--no-eclipses"),
    "show_moons":           typer.Option(True, "--show-moons/--no-moons"),
    "show_planets":         typer.Option(True, "--show-planets/--no-planets"),
    "show_dwarfs":          typer.Option(True, "--show-dwarfs/--no-dwarfs"),
    "show_asteroids":       typer.Option(True, "--show-asteroids/--no-asteroids"),
    "show_centaurs":        typer.Option(True, "--show-centaurs/--no-centaurs"),
    "show_exoplanets":      typer.Option(True, "--show-exoplanets/--no-exoplanets"),
    "show_interstellar":    typer.Option(True, "--show-interstellar/--no-interstellar"),
    "show_points":          typer.Option(True, "--show-points/--no-points"),
    "show_advanced_points": typer.Option(True, "--show-advanced-points/--no-advanced-points"),
    "show_lilith":          typer.Option(True, "--show-lilith/--no-lilith"),
}


@app.command("chart")
def cmd_chart(
    date:  Optional[str]   = _OPT["date"],
    time:  Optional[str]   = _OPT["time"],
    lat:   Optional[float] = _OPT["lat"],
    lon:   Optional[float] = _OPT["lon"],
    tz:    float           = _OPT["tz"],
    house_system: str      = _OPT["hs"],
    fixed_star_orb: float  = _OPT["orb"],
    include: Optional[str] = _OPT["include"],
    exclude: str           = _OPT["exclude"],
    sign:   Optional[str]  = _OPT["sign"],
    house:  Optional[str]  = _OPT["house"],
    parent: Optional[str]  = _OPT["parent"],
    sort_by: str           = _OPT["sort_by"],

    limit: int = _OPT["limit"],

    planets_limit: int = _OPT["planets_limit"],
    moons_limit: int = _OPT["moons_limit"],
    dwarfs_limit: int = _OPT["dwarfs_limit"],
    asteroids_limit: int = _OPT["asteroids_limit"],
    centaurs_limit: int = _OPT["centaurs_limit"],
    points_limit: int = _OPT["points_limit"],
    advanced_points_limit: int = _OPT["advanced_points_limit"],
    lilith_limit: int = _OPT["lilith_limit"],
    planetary_nodes_limit: int = _OPT["planetary_nodes_limit"],
    exoplanets_limit: int = _OPT["exoplanets_limit"],
    interstellar_limit: int = _OPT["interstellar_limit"],
    fixed_stars_limit: int = _OPT["fixed_stars_limit"],
    arabic_lots_limit: int = _OPT["arabic_lots_limit"],

    show_houses:          bool = _OPT["show_houses"],
    show_aspects:         bool = _OPT["show_aspects"],
    show_fixed_stars:     bool = _OPT["show_fixed_stars"],
    show_arabic_lots:     bool = _OPT["show_arabic_lots"],
    show_planetary_nodes: bool = _OPT["show_planetary_nodes"],
    show_eclipses:        bool = _OPT["show_eclipses"],
    show_moons:           bool = _OPT["show_moons"],
    show_planets:         bool = _OPT["show_planets"],
    show_dwarfs:          bool = _OPT["show_dwarfs"],
    show_asteroids:       bool = _OPT["show_asteroids"],
    show_centaurs:        bool = _OPT["show_centaurs"],
    show_exoplanets:      bool = _OPT["show_exoplanets"],
    show_interstellar:    bool = _OPT["show_interstellar"],
    show_points:          bool = _OPT["show_points"],
    show_advanced_points: bool = _OPT["show_advanced_points"],
    show_lilith:          bool = _OPT["show_lilith"],

    output_json: bool = _OPT["json"],
    ephe_dir: Optional[str] = _OPT["ephe"],
) -> None:

    params = {
        "date": date,
        "time": time,
        "lat": lat,
        "lon": lon,
        "tz": tz,
        "house_system": house_system,
        "fixed_star_orb": fixed_star_orb,
        "include": include,
        "exclude": exclude,
        "sign": sign,
        "house": house,
        "parent": parent,
        "sort_by": sort_by,

        "limit": limit,
        "planets_limit": planets_limit,
        "moons_limit": moons_limit,
        "dwarfs_limit": dwarfs_limit,
        "asteroids_limit": asteroids_limit,
        "centaurs_limit": centaurs_limit,
        "points_limit": points_limit,
        "advanced_points_limit": advanced_points_limit,
        "lilith_limit": lilith_limit,
        "planetary_nodes_limit": planetary_nodes_limit,
        "exoplanets_limit": exoplanets_limit,
        "interstellar_limit": interstellar_limit,
        "fixed_stars_limit": fixed_stars_limit,
        "arabic_lots_limit": arabic_lots_limit,

        "ephe_dir": ephe_dir,

        "show_houses": show_houses,
        "show_aspects": show_aspects,
        "show_fixed_stars": show_fixed_stars,
        "show_arabic_lots": show_arabic_lots,
        "show_planetary_nodes": show_planetary_nodes,
        "show_eclipses": show_eclipses,
        "show_moons": show_moons,
        "show_planets": show_planets,
        "show_dwarfs": show_dwarfs,
        "show_asteroids": show_asteroids,
        "show_centaurs": show_centaurs,
        "show_exoplanets": show_exoplanets,
        "show_interstellar": show_interstellar,
        "show_points": show_points,
        "show_advanced_points": show_advanced_points,
        "show_lilith": show_lilith,
    }

    payload = runner.run_chart(params)
    display.render(payload, output_json=output_json)

# ---------------------------------------------------------------------------
# transit
# ---------------------------------------------------------------------------

@app.command("transit")
def cmd_transit(
    date:  Optional[str]   = _OPT["date"],
    time:  Optional[str]   = _OPT["time"],
    lat:   Optional[float] = _OPT["lat"],
    lon:   Optional[float] = _OPT["lon"],
    tz:    float           = _OPT["tz"],
    house_system: str      = _OPT["hs"],
    body:    str           = typer.Option(..., "--body", "-b", help="Planet name, e.g. Saturn"),
    date_from: str         = typer.Option(..., "--from", help="Start date YYYY-MM-DD"),
    date_to:   str         = typer.Option(..., "--to",   help="End date   YYYY-MM-DD"),
    step:  int             = typer.Option(1, "--step", help="Step in days"),
    exclude: str           = _OPT["exclude"],
    sort_by: str           = _OPT["sort_by"],

    limit: int = _OPT["limit"],

    planets_limit: int = _OPT["planets_limit"],
    moons_limit: int = _OPT["moons_limit"],
    dwarfs_limit: int = _OPT["dwarfs_limit"],
    asteroids_limit: int = _OPT["asteroids_limit"],
    centaurs_limit: int = _OPT["centaurs_limit"],
    points_limit: int = _OPT["points_limit"],
    advanced_points_limit: int = _OPT["advanced_points_limit"],
    lilith_limit: int = _OPT["lilith_limit"],
    planetary_nodes_limit: int = _OPT["planetary_nodes_limit"],
    exoplanets_limit: int = _OPT["exoplanets_limit"],
    interstellar_limit: int = _OPT["interstellar_limit"],
    fixed_stars_limit: int = _OPT["fixed_stars_limit"],
    arabic_lots_limit: int = _OPT["arabic_lots_limit"],

    output_json: bool      = _OPT["json"],
    ephe_dir: Optional[str]= _OPT["ephe"],
) -> None:
    params = {
        "date": date,
        "time": time,
        "lat": lat,
        "lon": lon,
        "tz": tz,
        "house_system": house_system,
        "transit": body,
        "date_from": date_from,
        "date_to": date_to,
        "step": step,
        "exclude": exclude,
        "sort_by": sort_by,

        "limit": limit,
        "planets_limit": planets_limit,
        "moons_limit": moons_limit,
        "dwarfs_limit": dwarfs_limit,
        "asteroids_limit": asteroids_limit,
        "centaurs_limit": centaurs_limit,
        "points_limit": points_limit,
        "advanced_points_limit": advanced_points_limit,
        "lilith_limit": lilith_limit,
        "planetary_nodes_limit": planetary_nodes_limit,
        "exoplanets_limit": exoplanets_limit,
        "interstellar_limit": interstellar_limit,
        "fixed_stars_limit": fixed_stars_limit,
        "arabic_lots_limit": arabic_lots_limit,

        "ephe_dir": ephe_dir,
    }

    payload = runner.run_transit(params)
    display.render(payload, output_json=output_json)
    

# ---------------------------------------------------------------------------
# transits (yearly)
# ---------------------------------------------------------------------------

@app.command("transits")
def cmd_transits(
    date:  Optional[str]   = _OPT["date"],
    time:  Optional[str]   = _OPT["time"],
    lat:   Optional[float] = _OPT["lat"],
    lon:   Optional[float] = _OPT["lon"],
    tz:    float           = _OPT["tz"],
    house_system: str      = _OPT["hs"],
    year:  int             = typer.Option(..., "--year", "-y"),
    step:  int             = typer.Option(1, "--step"),
    exclude: str           = _OPT["exclude"],
    sort_by: str           = _OPT["sort_by"],

    limit: int = _OPT["limit"],

    planets_limit: int = _OPT["planets_limit"],
    moons_limit: int = _OPT["moons_limit"],
    dwarfs_limit: int = _OPT["dwarfs_limit"],
    asteroids_limit: int = _OPT["asteroids_limit"],
    centaurs_limit: int = _OPT["centaurs_limit"],
    points_limit: int = _OPT["points_limit"],
    advanced_points_limit: int = _OPT["advanced_points_limit"],
    lilith_limit: int = _OPT["lilith_limit"],
    planetary_nodes_limit: int = _OPT["planetary_nodes_limit"],
    exoplanets_limit: int = _OPT["exoplanets_limit"],
    interstellar_limit: int = _OPT["interstellar_limit"],
    fixed_stars_limit: int = _OPT["fixed_stars_limit"],
    arabic_lots_limit: int = _OPT["arabic_lots_limit"],

    output_json: bool      = _OPT["json"],
    ephe_dir: Optional[str]= _OPT["ephe"],
) -> None:

    params = {
        "date": date,
        "time": time,
        "lat": lat,
        "lon": lon,
        "tz": tz,
        "house_system": house_system,

        "year": year,
        "step": step,
        "exclude": exclude,
        "sort_by": sort_by,

        "limit": limit,
        "planets_limit": planets_limit,
        "moons_limit": moons_limit,
        "dwarfs_limit": dwarfs_limit,
        "asteroids_limit": asteroids_limit,
        "centaurs_limit": centaurs_limit,
        "points_limit": points_limit,
        "advanced_points_limit": advanced_points_limit,
        "lilith_limit": lilith_limit,
        "planetary_nodes_limit": planetary_nodes_limit,
        "exoplanets_limit": exoplanets_limit,
        "interstellar_limit": interstellar_limit,
        "fixed_stars_limit": fixed_stars_limit,
        "arabic_lots_limit": arabic_lots_limit,

        "ephe_dir": ephe_dir,
    }

    payload = runner.run_transits(params)
    display.render(payload, output_json=output_json)

# ---------------------------------------------------------------------------
# moon
# ---------------------------------------------------------------------------

@app.command("moon")
def cmd_moon(
    month: str              = typer.Argument(..., help="YYYY-M  e.g. 2026-3"),
    tz:    float            = _OPT["tz"],
    output_json: bool       = _OPT["json"],
    ephe_dir: Optional[str] = _OPT["ephe"],
) -> None:
    """Moon phase calendar for a given month."""
    params = {"moon": month, "tz": tz, "ephe_dir": ephe_dir}
    payload = runner.run_moon(params)
    display.render(payload, output_json=output_json)


# ---------------------------------------------------------------------------
# quick
# ---------------------------------------------------------------------------

@app.command("quick")
def cmd_quick(
    mode:  str              = typer.Argument(..., help="today | thisweek | thismonth | thisyear"),
    lat:   Optional[float]  = _OPT["lat"],
    lon:   Optional[float]  = _OPT["lon"],
    tz:    float            = _OPT["tz"],
    output_json: bool       = _OPT["json"],
    ephe_dir: Optional[str] = _OPT["ephe"],
) -> None:
    """Quick planet snapshot for today / this week / month / year."""
    params = {
        "quick": mode, "lat": lat, "lon": lon, "tz": tz,
        "ephe_dir": ephe_dir,
    }
    payload = runner.run_quick(params)
    display.render(payload, output_json=output_json)


# ---------------------------------------------------------------------------
# list
# ---------------------------------------------------------------------------

@app.command("list")
def cmd_list(
    output_json: bool       = _OPT["json"],
    ephe_dir: Optional[str] = _OPT["ephe"],
) -> None:
    """List all supported celestial objects."""
    params  = {"ephe_dir": ephe_dir}
    payload = runner.run_list(params)
    display.render(payload, output_json=output_json)


# ---------------------------------------------------------------------------
# search
# ---------------------------------------------------------------------------

@app.command("search")
def cmd_search(
    query:  str             = typer.Argument(..., help="Search query, e.g. chiron"),
    parent: Optional[str]   = _OPT["parent"],
    output_json: bool       = _OPT["json"],
    ephe_dir: Optional[str] = _OPT["ephe"],
) -> None:
    """Search for a celestial object by name."""
    params  = {"search": query, "parent": parent, "ephe_dir": ephe_dir}
    payload = runner.run_search(params)
    display.render(payload, output_json=output_json)


# ---------------------------------------------------------------------------
# download
# ---------------------------------------------------------------------------

@app.command("download")
def cmd_download(
    force: bool = typer.Option(False, "--force", "-f", help="Re-download even if already cached"),
    check: bool = typer.Option(False, "--check", help="Only check if data is already present"),
) -> None:
    """Download ephemeris data files from GitHub Releases."""
    from afterlife.data.downloader import (
        _cache_dir, download_ephe, is_downloaded,
    )

    cache = _cache_dir()

    if check:
        if is_downloaded(cache):
            console.print(f"[bold #ae00ff]Ephemeris already downloaded:[/] {cache}")
        else:
            console.print("[dim]Ephemeris not yet downloaded.[/]")
            console.print(f"[dim]Run [bold]afterlife download[/] to fetch (~400 MB)[/]")
        return

    if not force and is_downloaded(cache):
        console.print(f"[bold #ae00ff]Already downloaded:[/] {cache}")
        console.print("[dim]Use --force to re-download.[/]")
        return

    console.print(f"[bold white]Downloading ephemeris data...[/]")
    console.print(f"[dim]Destination: {cache}[/]\n")
    try:
        path = download_ephe(force=force)
        console.print(f"\n[bold #ae00ff]Done![/] Ephemeris ready at: [white]{path}[/]")
    except Exception as exc:
        console.print(f"\n[bold red]Download failed:[/] {exc}")
        raise typer.Exit(1)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main() -> None:
    app()


if __name__ == "__main__":
    main()
