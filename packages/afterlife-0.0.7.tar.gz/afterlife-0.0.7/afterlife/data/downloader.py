"""
Afterlife ephemeris downloader.

Downloads ephemeris files from GitHub Releases on first use and caches them
in ~/.cache/afterlife/ephe/. Subsequent runs use the cache directly.

Usage (automatic — called by engine._resolve_paths):
    from afterlife.data.downloader import ensure_ephe
    ephe_path = ensure_ephe()          # returns Path to ephe dir

Usage (manual / CLI):
    python -m afterlife.data.downloader
"""
from __future__ import annotations

import hashlib
import os
import shutil
import sys
import tarfile
import tempfile
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Dict, List, Optional

# ---------------------------------------------------------------------------
# Release metadata
# Each entry: (asset_filename, sha256_hex_or_None)
# sha256 = None means skip checksum (set it after first upload)
# ---------------------------------------------------------------------------

_GITHUB_USER    = "mustafayavuzak"
_GITHUB_REPO    = "Afterlife"
_RELEASE_TAG    = "v1.0.0-ephe"

_BASE_URL = (
    f"https://github.com/{_GITHUB_USER}/{_GITHUB_REPO}"
    f"/releases/download/{_RELEASE_TAG}"
)

# (filename, sha256)
ASSETS: List[tuple] = [
    ("afterlife-ephe-se1.tar.gz",         "7411b8a2880a2e3983d744e16eba0fa4860bfae7cbaae2e0e1d780c55efcc863"),
    ("afterlife-ephe-bsp-core.tar.gz",    "7793f8303ad7ffc14097b37107bab26407bb1d74e46ebb200a7949d3d677ba99"),
    ("afterlife-ephe-bsp-objects.tar.gz", "8c9a63598dfcdaa3a4bd704a1fa80a0b0a081f78c4feb636e14c020cf20c6b64"),
    ("afterlife-ephe-extras.tar.gz",      "42a3adc5d36f58b35880bb272bef33b8b2b4dbe3d3d428365cdda53f0f7f86fb"),
]

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------

def _cache_dir() -> Path:
    """Platform-aware cache directory."""
    xdg = os.environ.get("XDG_CACHE_HOME")
    if xdg:
        base = Path(xdg)
    elif sys.platform == "win32":
        base = Path(os.environ.get("LOCALAPPDATA", Path.home() / "AppData" / "Local"))
    else:
        base = Path.home() / ".cache"
    return base / "afterlife" / "ephe"


def _marker(cache: Path) -> Path:
    return cache / ".download_complete"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _progress(filename: str, downloaded: int, total: int) -> None:
    if total <= 0:
        sys.stderr.write(f"\r  {filename}: {downloaded // (1 << 20)} MB")
    else:
        pct = downloaded * 100 // total
        bar = "#" * (pct // 4) + "-" * (25 - pct // 4)
        mb_done = downloaded // (1 << 20)
        mb_total = total // (1 << 20)
        sys.stderr.write(f"\r  [{bar}] {pct:3d}%  {mb_done}/{mb_total} MB  {filename}")
    sys.stderr.flush()


def _download_asset(url: str, dest: Path, expected_sha256: Optional[str]) -> None:
    filename = url.split("/")[-1]
    sys.stderr.write(f"\nDownloading {filename}...\n")

    parsed = urllib.parse.urlparse(url)
    if parsed.scheme != "https" or parsed.netloc not in ("github.com", "objects.githubusercontent.com"):
        raise ValueError(f"Untrusted download URL: {url}")

    req = urllib.request.Request(url, headers={"User-Agent": "afterlife-downloader/1.0"})
    with urllib.request.urlopen(req) as resp, tempfile.NamedTemporaryFile(delete=False, suffix=".tmp") as tmp:
        total = int(resp.headers.get("Content-Length", 0))
        downloaded = 0
        while True:
            chunk = resp.read(1 << 16)
            if not chunk:
                break
            tmp.write(chunk)
            downloaded += len(chunk)
            _progress(filename, downloaded, total)
        tmp_path = Path(tmp.name)

    sys.stderr.write("\n")

    if expected_sha256:
        actual = _sha256(tmp_path)
        if actual != expected_sha256:
            tmp_path.unlink(missing_ok=True)
            raise ValueError(
                f"Checksum mismatch for {filename}\n"
                f"  expected: {expected_sha256}\n"
                f"  actual:   {actual}"
            )

    shutil.move(str(tmp_path), str(dest))


def _extract(archive: Path, target_dir: Path) -> None:
    sys.stderr.write(f"  Extracting {archive.name}...\n")
    with tarfile.open(archive, "r:gz") as tf:
        target_dir_resolved = target_dir.resolve()
        for member in tf.getmembers():
            member_path = (target_dir_resolved / member.name).resolve()
            if not str(member_path).startswith(str(target_dir_resolved)):
                raise ValueError(f"Unsafe path in archive: {member.name}")
        tf.extractall(target_dir)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def is_downloaded(cache: Optional[Path] = None) -> bool:
    """Return True if ephemeris files are already cached."""
    return _marker(cache or _cache_dir()).exists()


def download_ephe(force: bool = False) -> Path:
    """
    Download all ephemeris assets from GitHub Releases and extract to cache.

    Returns the Path to the ephemeris directory.
    Skips download if already complete (use force=True to re-download).
    """
    cache = _cache_dir()

    if not force and _marker(cache).exists():
        return cache

    cache.mkdir(parents=True, exist_ok=True)
    tmp_dir = cache / "_tmp"
    tmp_dir.mkdir(exist_ok=True)

    try:
        for filename, expected_sha256 in ASSETS:
            url      = f"{_BASE_URL}/{filename}"
            archive  = tmp_dir / filename
            _download_asset(url, archive, expected_sha256)
            _extract(archive, cache)
            archive.unlink()

        # Write completion marker
        _marker(cache).write_text("ok\n")
        sys.stderr.write(f"\nEphemeris ready at: {cache}\n")

    finally:
        if tmp_dir.exists():
            shutil.rmtree(tmp_dir, ignore_errors=True)

    return cache


def ensure_ephe(prompt: bool = True) -> Optional[Path]:
    """
    Return the ephemeris path, downloading if necessary.

    If prompt=True (default) and running interactively, asks user consent
    before downloading. Pass prompt=False to download silently.
    """
    cache = _cache_dir()

    if _marker(cache).exists():
        return cache

    # Also check if bundled data exists (dev install / editable)
    bundled = Path(__file__).resolve().parent / "ephe"
    if bundled.exists() and any(bundled.iterdir()):
        return bundled

    if prompt and sys.stdin.isatty():
        size_hint = "~400 MB"
        sys.stderr.write(
            f"\n[afterlife] Ephemeris data not found.\n"
            f"  Download from GitHub Releases? ({size_hint})\n"
            f"  Cache location: {cache}\n"
            f"  [Y/n] "
        )
        sys.stderr.flush()
        answer = sys.stdin.readline().strip().lower()
        if answer not in ("", "y", "yes"):
            sys.stderr.write("  Skipped. Some calculations will be unavailable.\n")
            return None

    return download_ephe()


# ---------------------------------------------------------------------------
# CLI: python -m afterlife.data.downloader
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Download Afterlife ephemeris files")
    parser.add_argument("--force", action="store_true", help="Re-download even if already cached")
    parser.add_argument("--check", action="store_true", help="Check if data is already downloaded")
    args = parser.parse_args()

    if args.check:
        if is_downloaded():
            print(f"Ephemeris already downloaded: {_cache_dir()}")
        else:
            print("Ephemeris not yet downloaded.")
        sys.exit(0)

    path = download_ephe(force=args.force)
    print(f"Done. Ephemeris path: {path}")