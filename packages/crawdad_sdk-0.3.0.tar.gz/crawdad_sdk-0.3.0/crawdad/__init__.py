"""Crawdad Python SDK — security, privacy, and control for autonomous AI agents."""

from .admin import AdminClient
from .client import CrawdadClient
from .exceptions import AuthenticationError, CrawdadError, NotFoundError, RateLimitError

__all__ = [
    "CrawdadClient",
    "AdminClient",
    "CrawdadError",
    "AuthenticationError",
    "NotFoundError",
    "RateLimitError",
    "__version__",
]

__version__ = "0.3.0"
