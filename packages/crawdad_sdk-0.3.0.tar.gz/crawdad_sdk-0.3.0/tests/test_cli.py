"""Unit tests for the Crawdad CLI."""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
from unittest import mock

import httpx
import pytest

from crawdad.cli import (
    _AGENT_PY_TEMPLATE,
    _load_env,
    cmd_demo,
    cmd_health,
    cmd_init,
    cmd_status,
    main,
)


# ── Mock transport (reuse the same canned routes from test_client) ──────

AGENT_ID = "550e8400-e29b-41d4-a716-446655440000"
SKILL_ID = "660e8400-e29b-41d4-a716-446655440001"
AGENT_B = "880e8400-e29b-41d4-a716-446655440003"

_agent_counter = 0


def _mock_handler(request: httpx.Request) -> httpx.Response:
    global _agent_counter
    path = request.url.path
    method = request.method

    if path == "/health" and method == "GET":
        return httpx.Response(200, json={"status": "ok"})

    if path == "/metrics" and method == "GET":
        return httpx.Response(200, json={
            "uptime_seconds": 7200,
            "total_requests": 250,
            "agents_registered": 4,
            "audit_entries_count": 80,
            "active_emergency_halt": False,
            "memory_usage_bytes": 4194304,
        })

    if path == "/agents" and method == "POST":
        _agent_counter += 1
        body = json.loads(request.content)
        aid = AGENT_ID if _agent_counter % 2 == 1 else AGENT_B
        return httpx.Response(201, json={
            "agent_id": aid,
            "display_name": body["display_name"],
            "did": f"did:crawdad:{aid}",
            "trust_level": "Medium",
            "status": "Active",
        })

    if path == "/policy/evaluate" and method == "POST":
        body = json.loads(request.content)
        return httpx.Response(200, json={
            "agent_id": body["agent_id"],
            "decision": "Permit",
            "risk_score": 12,
            "reason": "no matching deny rules",
            "matching_rules": [],
        })

    if path == "/firewall/analyze" and method == "POST":
        return httpx.Response(200, json={
            "threat_score": 85,
            "verdict": "Malicious",
            "patterns_detected": ["prompt_injection"],
            "confidence": 0.92,
        })

    if path.startswith("/memory/") and path.endswith("/write") and method == "POST":
        return httpx.Response(201, json={
            "entry_id": "eee00000-0000-0000-0000-000000000001",
            "chain_hash": "abc123",
        })

    if path.startswith("/memory/") and path.endswith("/verify") and method == "POST":
        return httpx.Response(200, json={
            "agent_id": AGENT_ID,
            "chain_valid": True,
            "entry_count": 1,
        })

    if path == "/skills/register" and method == "POST":
        body = json.loads(request.content)
        return httpx.Response(201, json={
            "skill_id": SKILL_ID,
            "name": body["name"],
            "version": body["version"],
            "author": body["author"],
            "description": body["description"],
            "attestation_status": "Unverified",
            "capabilities_requested": body["capabilities_requested"],
        })

    if path == f"/skills/{SKILL_ID}/attest" and method == "POST":
        return httpx.Response(200, json={
            "risk_score": 15,
            "hash_valid": True,
            "injection_patterns": [],
            "capability_risk": "Low",
            "recommended_status": "Attested",
        })

    if path == "/comms/send" and method == "POST":
        body = json.loads(request.content)
        return httpx.Response(201, json={
            "message_id": "mmm00000-0000-0000-0000-000000000001",
            "from_agent": body["from_agent"],
            "to_agent": body["to_agent"],
            "content": body["content"],
            "signed_hash": "sig_abc",
            "content_filter": {
                "threat_score": 2,
                "recommendation": "Deliver",
                "pii_detected": [],
                "injection_detected": False,
            },
        })

    if path == "/comms/scan" and method == "POST":
        return httpx.Response(200, json={
            "threat_score": 90,
            "recommendation": "Block",
            "pii_detected": [],
            "injection_detected": True,
        })

    if path == "/privacy/scan" and method == "POST":
        return httpx.Response(200, json={
            "detections": [
                {"category": "email", "confidence": 0.99, "start": 20, "end": 36, "matched_text": "john@example.com"},
            ],
            "categories_found": ["email"],
            "count": 1,
        })

    if path == "/privacy/transform" and method == "POST":
        return httpx.Response(200, json={
            "original_length": 36,
            "transformed_text": "Contact [REDACTED] for details",
            "transformations_applied": 1,
            "mode": "redact",
        })

    if path == "/privacy/compliance-check" and method == "POST":
        return httpx.Response(200, json={
            "jurisdiction": "EU",
            "compliant": True,
            "operations_requiring_consent": ["Collect", "Process"],
            "restricted_operations": [],
            "required_notifications": [],
        })

    if path == "/firewall/guard" and method == "POST":
        return httpx.Response(200, json={
            "action_allowed": False,
            "risk_score": 90,
            "flags": ["filesystem_write", "sensitive_path"],
            "recommendation": "Block",
        })

    return httpx.Response(404, json={"error": f"mock: no route for {method} {path}"})


# ── Fixtures ────────────────────────────────────────────────────────────


@pytest.fixture(autouse=True)
def _reset_agent_counter():
    global _agent_counter
    _agent_counter = 0
    yield
    _agent_counter = 0


@pytest.fixture
def tmp_project(tmp_path, monkeypatch):
    """Create a temporary project directory and cd into it."""
    monkeypatch.chdir(tmp_path)
    return tmp_path


@pytest.fixture
def env_file(tmp_project):
    """Write a .crawdad.env in the tmp project dir."""
    p = tmp_project / ".crawdad.env"
    p.write_text(
        '# test config\n'
        'BASE_URL="http://test"\n'
        'API_KEY="test-key-1234567890"\n'
    )
    return p


# ── Tests ───────────────────────────────────────────────────────────────


def test_load_env(env_file):
    env = _load_env(str(env_file))
    assert env["BASE_URL"] == "http://test"
    assert env["API_KEY"] == "test-key-1234567890"


def test_load_env_missing(tmp_project):
    env = _load_env("nonexistent.env")
    assert env == {}


def test_main_no_command(capsys):
    with pytest.raises(SystemExit) as exc_info:
        main([])
    assert exc_info.value.code == 0
    out = capsys.readouterr().out
    assert "crawdad" in out.lower()


def test_main_version(capsys):
    with pytest.raises(SystemExit) as exc_info:
        main(["--version"])
    assert exc_info.value.code == 0
    out = capsys.readouterr().out
    assert "0.3.0" in out


def test_cmd_init(tmp_project, monkeypatch):
    """Test the init command creates .crawdad.env and agent.py."""
    inputs = iter(["test-agent", "http://mock-server", "my-secret-key"])
    monkeypatch.setattr("builtins.input", lambda _: next(inputs))

    # Patch httpx.get to return a healthy response
    def mock_get(url, **kwargs):
        return httpx.Response(200, json={"status": "ok"})

    monkeypatch.setattr("httpx.get", mock_get)

    args = argparse.Namespace()
    cmd_init(args)

    # Check .crawdad.env was created
    env_path = tmp_project / ".crawdad.env"
    assert env_path.exists()
    content = env_path.read_text()
    assert "http://mock-server" in content
    assert "my-secret-key" in content

    # Check agent.py was created with substituted values
    agent_path = tmp_project / "agent.py"
    assert agent_path.exists()
    agent_content = agent_path.read_text()
    assert "test-agent" in agent_content
    assert "http://mock-server" in agent_content
    assert "my-secret-key" in agent_content
    assert "What just happened?" in agent_content
    assert "{{AGENT_NAME}}" not in agent_content
    assert "{{BASE_URL}}" not in agent_content
    assert "{{API_KEY}}" not in agent_content


def test_cmd_health(env_file, capsys, monkeypatch):
    """Test health command with a mock server."""
    def mock_get(url, **kwargs):
        return httpx.Response(200, json={"status": "ok"})

    monkeypatch.setattr("httpx.get", mock_get)

    args = argparse.Namespace()
    cmd_health(args)
    out = capsys.readouterr().out
    assert "healthy" in out


def test_cmd_health_failure(env_file, capsys, monkeypatch):
    """Test health command when server is unreachable."""
    def mock_get(url, **kwargs):
        raise httpx.ConnectError("connection refused")

    monkeypatch.setattr("httpx.get", mock_get)

    args = argparse.Namespace()
    with pytest.raises(SystemExit) as exc_info:
        cmd_health(args)
    assert exc_info.value.code == 1


def test_cmd_status(env_file, capsys, monkeypatch):
    """Test status command shows config and metrics."""
    def mock_get(url, **kwargs):
        return httpx.Response(200, json={
            "uptime_seconds": 7200,
            "total_requests": 250,
            "agents_registered": 4,
            "audit_entries_count": 80,
            "active_emergency_halt": False,
            "memory_usage_bytes": 4194304,
        })

    monkeypatch.setattr("httpx.get", mock_get)

    args = argparse.Namespace()
    cmd_status(args)
    out = capsys.readouterr().out
    assert "test" in out.lower()
    assert "operational" in out
    assert "4" in out  # agents_registered


def test_cmd_status_masked_key(env_file, capsys, monkeypatch):
    """Test that the API key is properly masked."""
    def mock_get(url, **kwargs):
        return httpx.Response(200, json={
            "uptime_seconds": 0, "total_requests": 0, "agents_registered": 0,
            "audit_entries_count": 0, "active_emergency_halt": False,
            "memory_usage_bytes": 0,
        })

    monkeypatch.setattr("httpx.get", mock_get)

    args = argparse.Namespace()
    cmd_status(args)
    out = capsys.readouterr().out
    # Key is "test-key-1234567890" (20 chars) -> "test************7890"
    assert "test-key-1234567890" not in out
    assert "test" in out  # first 4 chars visible


def test_cmd_demo(env_file, capsys, monkeypatch):
    """Test the full demo command with mock transport."""
    # Patch CrawdadClient to use our mock transport
    from crawdad.client import CrawdadClient

    original_init = CrawdadClient.__init__

    def patched_init(self, base_url, api_key, **kwargs):
        kwargs["transport"] = httpx.MockTransport(_mock_handler)
        original_init(self, base_url, api_key, **kwargs)

    monkeypatch.setattr(CrawdadClient, "__init__", patched_init)

    args = argparse.Namespace()
    cmd_demo(args)
    out = capsys.readouterr().out

    assert "IDENTITY" in out
    assert "POLICY" in out
    assert "FIREWALL" in out
    assert "MEMORY" in out
    assert "SKILLS" in out
    assert "COMMS" in out
    assert "PRIVACY" in out
    assert "All 7 pillars verified" in out


def test_cmd_no_env_exits(tmp_project, capsys):
    """Test that commands requiring .crawdad.env exit gracefully."""
    args = argparse.Namespace()
    with pytest.raises(SystemExit) as exc_info:
        cmd_health(args)
    assert exc_info.value.code == 1
    out = capsys.readouterr().out
    assert "crawdad init" in out


def test_agent_template_is_valid_python():
    """Verify the agent.py template is syntactically valid Python."""
    source = _AGENT_PY_TEMPLATE.replace("{{AGENT_NAME}}", "test")
    source = source.replace("{{BASE_URL}}", "http://localhost:3000")
    source = source.replace("{{API_KEY}}", "key123")
    compile(source, "agent.py", "exec")
