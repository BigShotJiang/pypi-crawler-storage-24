"""Module to load configuration from a libsonata config"""

import json
import logging
import os.path
from dataclasses import dataclass
from enum import Enum

import libsonata


class ConnectionTypes(str, Enum):
    Synaptic = "Synaptic"
    GapJunction = "GapJunction"
    NeuroModulation = "NeuroModulation"
    NeuroGlial = "NeuroGlial"
    GlioVascular = "GlioVascular"


@dataclass
class ConnectionOverride:
    """Python-side mutable version of SimulationConfig.ConnectionOverride."""

    name: str
    source: str
    destination: str
    weight: float
    spont_minis: float | None = None
    synapse_configure: dict | None = None
    modoverride: str | None = None
    synapse_delay_override: float | None = None
    delay: float | None = None
    neuromodulation_dtc: float | None = None
    neuromodulation_strength: float | None = None

    @classmethod
    def from_libsonata(
        cls,
        conn: libsonata._libsonata.SimulationConfig.ConnectionOverride,
    ) -> "ConnectionOverride":
        return cls(
            name=conn.name,
            source=conn.source,
            destination=conn.target,
            weight=conn.weight,
            spont_minis=conn.spont_minis,
            synapse_configure=conn.synapse_configure,
            modoverride=conn.modoverride,
            synapse_delay_override=conn.synapse_delay_override,
            delay=conn.delay,
            neuromodulation_dtc=conn.neuromodulation_dtc,
            neuromodulation_strength=conn.neuromodulation_strength,
        )


@dataclass
class RunConfig:
    """Python-side mutable version of SimulationConfig.Run."""

    tstop: float
    dt: float
    base_seed: int
    spike_threshold: float
    second_order: str
    stimulus_seed: int
    ionchannel_seed: int
    minis_seed: int
    synapse_seed: int
    lfp_weights_path: str

    # Additional extended fields
    output_root: str
    config_node_sets_file: str
    target_file: str
    spikes_file: str
    spikes_sort_order: libsonata.SimulationConfig.Output.SpikesSortOrder
    simulator: libsonata.SimulationConfig.SimulatorType
    population_name: str | None
    nodeset_name: str
    celsius: float
    v_init: float
    extracellular_calcium: float
    spike_location: libsonata.SimulationConfig.Conditions.SpikeLocation
    compartment_sets_file: str
    enable_reports: bool | None = None  # set in node.py
    restore: str | None = None  # set in configuration.py


class SonataConfig:
    __slots__ = (
        "_circuit_conf",  # libsonata.CircuitConfig
        "_circuits",
        "_sim_conf",  # libsonata.SimulationConfig
        # Currently, the `inputs` of a simulation_config is a json object,
        # which is unordered; however, the order of stimuli matter, so try and
        # recover the order defined in the json file: this assumes that `json.load`
        # keeps it; *which is not guaranteed* see the discussion:
        # https://github.com/openbraininstitute/neurodamus/issues/217#issuecomment-2827930163
        # the SONATA specification should be updated to be a list
        "_stable_inputs_order",
    )

    def __init__(self, config_path):
        self._sim_conf = libsonata.SimulationConfig.from_file(config_path)

        with open(config_path, encoding="utf-8") as fd:
            if inputs := json.load(fd).get("inputs", None):
                self._stable_inputs_order = tuple(inputs.keys())
            else:
                self._stable_inputs_order = ()

        self._circuit_conf = libsonata.CircuitConfig.from_file(self._sim_conf.network)
        self._circuits = self._extract_circuits_info()

    @property
    def beta_features(self):
        return self._sim_conf.beta_features

    @property
    def parsedRun(self):
        return RunConfig(
            tstop=self._sim_conf.run.tstop,
            dt=self._sim_conf.run.dt,
            base_seed=self._sim_conf.run.random_seed,
            spike_threshold=self._sim_conf.run.spike_threshold,
            second_order=self._sim_conf.run.integration_method,
            stimulus_seed=self._sim_conf.run.stimulus_seed,
            ionchannel_seed=self._sim_conf.run.ionchannel_seed,
            minis_seed=self._sim_conf.run.minis_seed,
            synapse_seed=self._sim_conf.run.synapse_seed,
            lfp_weights_path=self._sim_conf.run.electrodes_file,
            output_root=self._sim_conf.output.output_dir,
            config_node_sets_file=self._circuit_conf.node_sets_path,
            target_file=self._sim_conf.node_sets_file,
            spikes_file=self._sim_conf.output.spikes_file,
            spikes_sort_order=self._sim_conf.output.spikes_sort_order,
            simulator=self._sim_conf.target_simulator,
            population_name=None,
            nodeset_name=self._sim_conf.node_set,
            celsius=self._sim_conf.conditions.celsius,
            v_init=self._sim_conf.conditions.v_init,
            extracellular_calcium=self._sim_conf.conditions.extracellular_calcium,
            spike_location=self._sim_conf.conditions.spike_location,
            compartment_sets_file=self._sim_conf.compartment_sets_file,
        )

    @property
    def parsedConditions(self):
        return self._sim_conf.conditions

    def _extract_circuits_info(self) -> dict:  # noqa: C901
        """Extract the circuits information from confile file with libsonata.CircuitConfig parser,
        return a dictionary of circuit info as:
        {
            pop_name: { "CellLibraryFile": ...,
                        "CircuitTarget": ...,
                        "MorphologyPath": ...,
                        "MorphologyType": ...,
                        "METypePath": ...,
                        "Engine": ...,
                        "nrnPath": ...,
                        "PopulationType": ...
                }
        }
        It will be used to build the internal circuit structure CircuitConfig in configuration.py
        """
        node_info_to_circuit = {"nodes_file": "CellLibraryFile", "type": "PopulationType"}

        simulation_nodeset_name = self._sim_conf.node_set or ""
        if not simulation_nodeset_name:
            logging.warning("Simulating all populations from all node files...")

        network = json.loads(self._circuit_conf.expanded_json)["networks"]

        def make_circuit(nodes_file, node_pop_name, population_info):
            if not os.path.isabs(nodes_file):
                nodes_file = os.path.join(os.path.dirname(self._sim_conf.network), nodes_file)
            circuit_config = dict(
                CellLibraryFile=nodes_file,
                # Use the extended ":" syntax to filter the nodeset by the related population
                PopulationName=node_pop_name,
                NodesetName=simulation_nodeset_name,
                **{
                    node_info_to_circuit.get(key, key): value
                    for key, value in population_info.items()
                },
            )
            node_prop = self._circuit_conf.node_population_properties(node_pop_name)
            circuit_config["MorphologyPath"] = node_prop.morphologies_dir
            circuit_config["MorphologyType"] = "h5" if node_prop.type == "astrocyte" else "swc"
            circuit_config["METypePath"] = node_prop.biophysical_neuron_models_dir
            if node_prop.alternate_morphology_formats:
                if "neurolucida-asc" in node_prop.alternate_morphology_formats:
                    circuit_config["MorphologyPath"] = node_prop.alternate_morphology_formats[
                        "neurolucida-asc"
                    ]
                    circuit_config["MorphologyType"] = "asc"
                elif "h5v1" in node_prop.alternate_morphology_formats:
                    circuit_config["MorphologyPath"] = node_prop.alternate_morphology_formats[
                        "h5v1"
                    ]
                    circuit_config["MorphologyType"] = "h5"
            circuit_config["Engine"] = "NGV" if node_prop.type == "astrocyte" else "METype"

            # Find inner connectivity
            # NOTE: Inner connectivity is a special kind of projection, and represents the circuit
            # default set of connections. Even though nowadays we can potentially consider
            # all connectivity as projections, under certain circuitry, like NGV, order matters and
            # therefore we keep inner connectivity to ensure they are created in the same order,
            # respecting engine precedence
            # For edges to be considered inner connectivity they must be named "default"
            for edge_config in network.get("edges") or []:
                if "nrnPath" in circuit_config:
                    break  # Already found

                for edge_pop_name in edge_config["populations"]:
                    edge_storage = self._circuit_conf.edge_population(edge_pop_name)
                    edge_type = self._circuit_conf.edge_population_properties(edge_pop_name).type
                    inner_pop_name = f"{node_pop_name}__{node_pop_name}__chemical"
                    if edge_pop_name == inner_pop_name or (
                        edge_storage.source == edge_storage.target == node_pop_name
                        and edge_type == "chemical"
                        and edge_pop_name == "default"
                    ):
                        edges_file = edge_config["edges_file"]
                        if not os.path.isabs(edges_file):
                            edges_file = os.path.join(
                                os.path.dirname(self._sim_conf.network), edges_file
                            )
                        edge_pop_path = edges_file + ":" + edge_pop_name
                        circuit_config["nrnPath"] = edge_pop_path
                        break

            circuit_config.setdefault("nrnPath", False)
            logging.debug("Circuit config for node pop '%s': %s", node_pop_name, circuit_config)
            return circuit_config

        return {
            pop_name: make_circuit(node_file_info["nodes_file"], pop_name, pop_info)
            for node_file_info in network["nodes"]
            for pop_name, pop_info in node_file_info["populations"].items()
            if pop_info.get("type") != "vasculature"
        }

    @property
    def Circuit(self):
        return self._circuits

    @property
    def parsedProjections(self):
        projection_type_convert = {
            "chemical": ConnectionTypes.Synaptic,
            "electrical": ConnectionTypes.GapJunction,
            "synapse_astrocyte": ConnectionTypes.NeuroGlial,
            "endfoot": ConnectionTypes.GlioVascular,
            "neuromodulatory": ConnectionTypes.NeuroModulation,
        }
        internal_edge_pops = {c_conf["nrnPath"] for c_conf in self._circuits.values()}
        projections = {}

        networks = json.loads(self._circuit_conf.expanded_json)["networks"]
        for edge_config in networks.get("edges") or []:
            for edge_pop_name, edge_pop_config in edge_config["populations"].items():
                edge_pop = self._circuit_conf.edge_population(edge_pop_name)
                pop_type = edge_pop_config.get("type", "chemical")

                if pop_type not in projection_type_convert:
                    logging.warning("Unhandled synapse type: %s", pop_type)
                    continue

                edges_file = edge_config["edges_file"]
                if not os.path.isabs(edges_file):
                    edges_file = os.path.join(os.path.dirname(self._sim_conf.network), edges_file)

                # skip inner connectivity populations
                edge_pop_path = edges_file + ":" + edge_pop_name
                if edge_pop_path in internal_edge_pops:
                    continue

                projection = {
                    "Path": edge_pop_path,
                    "Source": edge_pop.source,
                    "Destination": edge_pop.target,
                    "Type": projection_type_convert.get(pop_type),
                }
                # Reverse projection direction for Astrocyte projection: from neurons to astrocytes
                if projection["Type"] == ConnectionTypes.NeuroGlial:
                    projection["Source"], projection["Destination"] = (
                        projection["Destination"],
                        projection["Source"],
                    )
                elif projection["Type"] == ConnectionTypes.GlioVascular:
                    vasculature_popnames = [
                        name
                        for node_info in networks["nodes"]
                        for name, pop_info in node_info["populations"].items()
                        if pop_info.get("type") == "vasculature"
                    ]
                    if vasculature_popnames:
                        assert len(vasculature_popnames) == 1
                        projection["VasculaturePath"] = (
                            self._circuit_conf.node_population_properties(
                                vasculature_popnames[0]
                            ).elements_path
                        )

                proj_name = f"{edge_pop_name}__{edge_pop.source}-{edge_pop.target}"
                projections[proj_name] = projection

        return projections

    @property
    def parsedConnects(self):
        return [
            ConnectionOverride.from_libsonata(libsonata_conn)
            for libsonata_conn in self._sim_conf.connection_overrides()
        ]

    @property
    def parsedStimuli(self) -> list:
        """Read the inputs information parsed by libsonata,
        and convert them to the internal parameters used by StimulusManager
        """
        item_translation = {
            "module": "Pattern",
            "input_type": "Mode",
            "random_seed": "Seed",
            "series_resistance": "RS",
            "node_set": "Target",
            "sd_percent": "SDPercent",
            "relative_skew": "RelativeSkew",
        }
        input_type_translation = {
            "spikes": "Current",
            "current_clamp": "Current",
            "voltage_clamp": "Voltage",
            "extracellular_stimulation": "Extracellular",
            "conductance": "Conductance",
        }
        module_translation = {"seclamp": "SEClamp", "subthreshold": "SubThreshold"}

        stimuli = []
        # TODO: loop over self._sim_conf.inputs() list after updating SONATA SPEC and libsonata API,
        # The order of stimulus injection could lead to minor difference on the results
        # so need to preserve it as in the config file
        for name in self._stable_inputs_order:
            stimulus = self._translate_dict(item_translation, self._sim_conf.input(name))
            self._adapt_libsonata_fields(stimulus)
            stimulus["Pattern"] = module_translation.get(
                stimulus["Pattern"], snake_to_camel(stimulus["Pattern"])
            )
            stimulus["Mode"] = input_type_translation.get(stimulus["Mode"], stimulus["Mode"])
            stimulus["Name"] = name
            if stimulus["Pattern"] == "SpatiallyUniformEField":
                fields = [
                    self._translate_dict({}, field) for field in self._sim_conf.input(name).fields
                ]
                stimulus["Fields"] = fields
            stimuli.append(stimulus)

        return stimuli

    @property
    def parsedReports(self):
        return {name: self._sim_conf.report(name) for name in self._sim_conf.list_report_names}

    @property
    def parsedModifications(self):
        return self._sim_conf.conditions.modifications()

    @staticmethod
    def _adapt_libsonata_fields(rep):
        for key in rep:
            # Convert enums to its string representation
            if key in {
                "Type",
                "Sections",
                "Scaling",
                "Compartments",
                "Mode",
                "Pattern",
                "SpikeLocation",
            } and not isinstance(rep[key], str):
                rep[key] = rep[key].name
            # Convert comma separated variable names to space separated
            if key == "ReportOn":
                rep[key] = rep[key].replace(",", " ")
            # Get the int value of the enum
            elif key == "SecondOrder":
                rep[key] = int(rep[key])

    @staticmethod
    def _translate_dict(item_translation, libsonata_obj) -> dict:
        """Translate SONATA/libsonata key names (snake_case) to Neurodamus internal paramters"""
        attrs = [
            x
            for x in dir(libsonata_obj)
            if not x.startswith("__") and not callable(getattr(libsonata_obj, x))
        ]
        result = {}
        for att in attrs:
            key = item_translation.get(att, snake_to_camel(att))
            parsed_value = getattr(libsonata_obj, att)
            if parsed_value is not None:
                result[key] = parsed_value
        return result


def snake_to_camel(word):
    return "".join(x.capitalize() or "_" for x in word.split("_"))
