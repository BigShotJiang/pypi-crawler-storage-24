# Yap Accessibility Expansion — Design Spec

**Date:** 2026-03-10
**Goal:** Make yap accessible to more people — more platforms, lower barrier to entry, friendlier interface for non-technical users.

**Target audience:** General productivity users (not just developers).

**Constraints:**
- Free to use (no paid cloud APIs for core functionality)
- Willing to invest in platform-specific code
- Cloud transcription is acceptable as an option

---

## 1. Windows Support

Add Windows as a supported platform via platform shims in existing modules.

### record.py
- Windows ffmpeg uses `-f dshow -i audio="<device>"` (DirectShow)
- Device discovery via `ffmpeg -list_devices true -f dshow -i dummy` (output goes to stderr; needs parsing)
- **Stopping ffmpeg on Windows:** `signal.SIGTERM` doesn't cleanly stop ffmpeg on Windows (Python translates it to `TerminateProcess`, which corrupts the WAV header). Instead, stop ffmpeg by writing `q\n` to its stdin. This requires launching ffmpeg with `stdin=subprocess.PIPE` on Windows.
- **Process existence checks:** `os.kill(pid, 0)` and `/proc/{pid}/cmdline` are Linux-only. On Windows, use `subprocess.call(["tasklist", "/FI", f"PID eq {pid}"], ...)` or `ctypes.windll.kernel32.OpenProcess()` to check if a PID is alive. Abstract this into a `_is_process_alive(pid)` helper with platform branches.

### output.py
- **Typing:** `pyautogui` for basic ASCII, but for Unicode/non-English text (which yap supports via `--lang`), use clipboard-paste simulation: copy text to clipboard via `pyperclip`, then simulate Ctrl+V via `pyautogui.hotkey('ctrl', 'v')`. This handles CJK and other non-ASCII input correctly.
- **Clipboard:** `pyperclip` (cross-platform, pure Python) — replaces `clip.exe` subprocess
- **Notifications:** PowerShell toast notification via subprocess
- **Dependencies:** `pyautogui` + `pyperclip` as Windows-only optional extras

### cli.py
- Toggle mode PID file moves from `/tmp` to `%TEMP%` (via `tempfile.gettempdir()`) on Windows
- Signal handling: replace SIGTERM-based toggle stop with file-based flag (write a sentinel file; recording loop polls for it) — works cross-platform

### config.py
- Config path: use `%APPDATA%\yap` on Windows instead of `~/.config/yap` for platform convention

### Install story
- `pip install yap-dictation[windows]` installs Windows-specific extras
- ffmpeg requires separate install (`winget install ffmpeg` or `choco install ffmpeg`)
- README gets a Windows section

### Testing
- Platform-conditional mocks in existing test files
- No new test modules needed for Windows shims

---

## 2. Web UI

A local browser-based interface served by yap itself, providing a friendly GUI for non-technical users.

### New module: `src/yap/server.py` (~100-150 lines)
- Uses `websockets` library for both HTTP serving and WebSocket connections (it supports serving static files, eliminating the need for `http.server` and avoiding sync/async composition issues)
- Single asyncio event loop handles everything
- Serves a single HTML page from `src/yap/static/index.html`

### Entry point
- `yap --serve` starts the server, opens browser to `localhost:8765`
- `yap --serve --port 9000` for custom port
- Prints URL to terminal for manual opening
- Ctrl+C gracefully shuts down (closes WebSocket connections, cleans up temp audio files)
- `--serve` is a separate mode — all other CLI flags (`--toggle`, `--clipboard`, `--llm`, `--model`, `--lang`) are ignored with a warning if combined with `--serve`. Server-side settings are controlled from the web UI.

### Two transcription paths

**Browser Speech (default for new users):**
- Uses Web Speech API — runs entirely in-browser
- Free, no API key, no rate limits
- Sends final text to Python server only for LLM correction (if enabled)
- No ffmpeg or Whisper model download needed

**Local Whisper:**
- Browser captures audio via MediaRecorder API (produces WebM/Opus or OGG, not WAV)
- Sends audio blob over WebSocket to Python server
- Server converts to WAV via ffmpeg (`ffmpeg -i input.webm -ar 16000 -ac 1 output.wav`) before passing to `transcribe.py`
- Result sent back over WebSocket

### The HTML page (`src/yap/static/index.html`, ~300-400 lines)
- Single-file: HTML + CSS + JS, no framework, no build step
- Big record button, text output area, copy button, settings drawer
- "Type into window" button calls server endpoint triggering existing `output.py`
- Settings persisted to `localStorage` in browser; server reads settings from WebSocket messages per-request (no bidirectional sync with `config.json` — web UI and CLI have independent settings)
- Responsive layout, but note: accessing from a non-localhost device (e.g., phone on LAN) requires HTTPS for Web Speech API to work — this is a browser security requirement. Localhost is exempt.

### Architecture principle
The server imports and calls the same `record`, `transcribe`, `correct`, and `output` modules as the CLI. No logic duplication.

---

## 3. Free Cloud Transcription

### Browser Speech API (Web Speech API)
- Built into Chrome, Edge, Safari — free, no API key
- Accuracy comparable to Google Docs voice typing
- Requires internet connection (audio processed by browser vendor's servers)
- Not available in Firefox
- **Web UI only** — the CLI continues to use local Whisper

### Privacy notice
The web UI settings drawer notes that "Browser speech" sends audio to browser vendor servers, while "Local Whisper" keeps everything on-device.

### No third-party ASR API integration
Yap does not call any external speech-to-text API. The free cloud path is entirely handled by the browser's built-in capability.

---

## 4. Project Structure & Dependencies

### New files
```
src/yap/
├── server.py
├── static/
│   └── index.html
tests/
├── test_server.py
```

### New dependencies
- `websockets>=12.0` — optional dependency for web UI (`[web]` extra), not pulled in for CLI-only users
- `pyautogui>=0.9` + `pyperclip>=1.8` — Windows-only optional (`[windows]` extra)

### Updated pyproject.toml
```toml
dependencies = [
    "faster-whisper>=1.0.0",
]

[project.optional-dependencies]
web = ["websockets>=12.0"]
windows = ["pyautogui>=0.9", "pyperclip>=1.8"]
```

`yap --serve` checks for `websockets` at runtime and prints a helpful install message if missing: `pip install yap-dictation[web]`.

### Testing
- `tests/test_server.py` for server module
- Web UI JS tested manually (single file, simple event handlers)

---

## Explicitly Out of Scope

- **Mobile native apps** — wrong ROI; app stores, native code, and OS already has dictation
- **Electron/Tauri desktop wrapper** — unnecessary complexity for what a web UI achieves
- **Hosted cloud service** — not needed; yap runs locally
- **Third-party ASR API integration** — browser speech API covers the free cloud path
