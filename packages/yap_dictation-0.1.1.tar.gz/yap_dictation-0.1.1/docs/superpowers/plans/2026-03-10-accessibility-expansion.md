# Accessibility Expansion Implementation Plan

> **For agentic workers:** REQUIRED: Use superpowers:subagent-driven-development (if subagents available) or superpowers:executing-plans to implement this plan. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add Windows support and a local web UI to make yap accessible to non-technical productivity users.

**Architecture:** Platform shims added to existing modules (`record.py`, `output.py`, `config.py`, `cli.py`) for Windows. New `server.py` module + single-file `index.html` for the web UI, served via `websockets` library. Web Speech API provides free browser-based transcription.

**Tech Stack:** Python 3.10+, websockets, pyautogui (Windows), pyperclip (Windows), ffmpeg

**Spec:** `docs/superpowers/specs/2026-03-10-accessibility-design.md`

---

## Chunk 1: Windows Platform Support

### Task 1: Platform-aware ffmpeg input args

**Files:**
- Modify: `src/yap/record.py:15-20` (`get_ffmpeg_input_args`)
- Test: `tests/test_record.py`

- [ ] **Step 1: Write the failing test**

In `tests/test_record.py`, add:

```python
def test_ffmpeg_args_windows():
    with patch("platform.system", return_value="Windows"):
        args = get_ffmpeg_input_args()
        assert args[0:2] == ["-f", "dshow"]
        assert "-i" in args
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_record.py::test_ffmpeg_args_windows -v`
Expected: FAIL — current code returns PulseAudio args for non-Darwin

- [ ] **Step 3: Implement Windows ffmpeg args**

In `src/yap/record.py`, update `get_ffmpeg_input_args`:

```python
def get_ffmpeg_input_args():
    system = platform.system()
    if system == "Darwin":
        return ["-f", "avfoundation", "-i", ":default"]
    elif system == "Windows":
        return ["-f", "dshow", "-i", "audio=default"]
    else:  # Linux / other Unix
        return ["-f", "pulse", "-i", "default"]
```

Note: `audio=default` works for most Windows setups. If device discovery is needed later, that's a separate enhancement.

- [ ] **Step 4: Run test to verify it passes**

Run: `uv run pytest tests/test_record.py::test_ffmpeg_args_windows -v`
Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add src/yap/record.py tests/test_record.py
git commit -m "feat(record): add Windows DirectShow ffmpeg input args"
```

---

### Task 2: Platform-aware process stopping

**Files:**
- Modify: `src/yap/record.py:23-42` (`start_recording`, `stop_recording`)
- Test: `tests/test_record.py`

- [ ] **Step 1: Write failing tests**

In `tests/test_record.py`, add:

```python
def test_start_recording_windows_uses_pipe_stdin():
    with (
        patch("platform.system", return_value="Windows"),
        patch("yap.record.get_ffmpeg_input_args", return_value=["-f", "dshow", "-i", "audio=default"]),
        patch("subprocess.Popen") as mock_popen,
        patch("os.makedirs"),
    ):
        start_recording()
        _, kwargs = mock_popen.call_args
        assert kwargs.get("stdin") == subprocess.PIPE


def test_start_recording_unix_uses_devnull():
    with (
        patch("platform.system", return_value="Linux"),
        patch("yap.record.get_ffmpeg_input_args", return_value=["-f", "pulse", "-i", "default"]),
        patch("subprocess.Popen") as mock_popen,
        patch("os.makedirs"),
    ):
        start_recording()
        _, kwargs = mock_popen.call_args
        assert kwargs.get("stdin") == subprocess.DEVNULL


def test_stop_recording_windows_writes_q():
    proc = MagicMock()
    proc.stdin = MagicMock()
    proc.wait.return_value = 0
    with patch("platform.system", return_value="Windows"):
        stop_recording(proc)
    proc.stdin.write.assert_called_once_with(b"q\n")
    proc.stdin.flush.assert_called_once()
    proc.send_signal.assert_not_called()


def test_stop_recording_unix_sends_sigterm():
    proc = MagicMock()
    proc.stdin = None
    proc.wait.return_value = 0
    with patch("platform.system", return_value="Linux"):
        stop_recording(proc)
    proc.send_signal.assert_called_once_with(signal.SIGTERM)
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `uv run pytest tests/test_record.py -k "start_recording_windows or start_recording_unix or stop_recording_windows or stop_recording_unix" -v`
Expected: FAIL

- [ ] **Step 3: Implement platform-aware start/stop**

In `src/yap/record.py`:

```python
def start_recording():
    os.makedirs(TMPDIR, exist_ok=True)
    input_args = get_ffmpeg_input_args()
    cmd = (
        ["ffmpeg", "-y"]
        + input_args
        + ["-ac", "1", "-ar", "16000", AUDIO_PATH, "-loglevel", "error"]
    )
    stdin = subprocess.PIPE if platform.system() == "Windows" else subprocess.DEVNULL
    proc = subprocess.Popen(cmd, stdin=stdin)
    return proc


def stop_recording(proc):
    if platform.system() == "Windows" and proc.stdin:
        proc.stdin.write(b"q\n")
        proc.stdin.flush()
    else:
        proc.send_signal(signal.SIGTERM)
    try:
        proc.wait(timeout=10)
    except subprocess.TimeoutExpired:
        proc.kill()
        proc.wait()
    return AUDIO_PATH
```

- [ ] **Step 4: Run all record tests**

Run: `uv run pytest tests/test_record.py -v`
Expected: ALL PASS (including existing tests — check `test_stop_recording_timeout` still works; it mocks `send_signal` so platform doesn't matter)

- [ ] **Step 5: Commit**

```bash
git add src/yap/record.py tests/test_record.py
git commit -m "feat(record): platform-aware ffmpeg start/stop for Windows"
```

---

### Task 3: Platform-aware process existence checks

**Files:**
- Modify: `src/yap/record.py:80-113` (`wait_for_exit`, `_is_ffmpeg_alive`)
- Test: `tests/test_record.py`

- [ ] **Step 1: Write failing tests**

In `tests/test_record.py`, add `_is_process_alive` to the top-level import block (alongside the existing imports from `yap.record`). The import will fail until Step 3 implements it, which is expected.

```python
def test_is_process_alive_unix():
    with (
        patch("platform.system", return_value="Linux"),
        patch("os.kill") as mock_kill,
    ):
        assert _is_process_alive(1234) is True
        mock_kill.assert_called_once_with(1234, 0)


def test_is_process_alive_unix_dead():
    with (
        patch("platform.system", return_value="Linux"),
        patch("os.kill", side_effect=ProcessLookupError),
    ):
        assert _is_process_alive(1234) is False


def test_is_process_alive_windows():
    with (
        patch("platform.system", return_value="Windows"),
        patch("subprocess.run") as mock_run,
    ):
        mock_run.return_value = MagicMock(returncode=0, stdout="1234")
        assert _is_process_alive(1234) is True


def test_is_process_alive_windows_dead():
    with (
        patch("platform.system", return_value="Windows"),
        patch("subprocess.run") as mock_run,
    ):
        mock_run.return_value = MagicMock(returncode=0, stdout="INFO: No tasks")
        assert _is_process_alive(1234) is False
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `uv run pytest tests/test_record.py -k "is_process_alive" -v`
Expected: FAIL — function doesn't exist yet

- [ ] **Step 3: Implement `_is_process_alive` and refactor callers**

In `src/yap/record.py`, add new helper and update existing functions:

```python
def _is_process_alive(pid):
    """Check if a process with the given PID exists. Cross-platform."""
    if platform.system() == "Windows":
        result = subprocess.run(
            ["tasklist", "/FI", f"PID eq {pid}", "/NH"],
            capture_output=True, text=True,
        )
        return str(pid) in result.stdout
    else:
        try:
            os.kill(pid, 0)
            return True
        except ProcessLookupError:
            return False


def wait_for_exit(pid, timeout=5):
    """Poll until a process exits (for non-child processes)."""
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if not _is_process_alive(pid):
            return True
        time.sleep(0.05)
    return False


def _is_ffmpeg_alive(pid):
    if not _is_process_alive(pid):
        return False
    # Verify it's actually ffmpeg (Linux only — others assume alive)
    try:
        with open(f"/proc/{pid}/cmdline", "rb") as f:
            cmdline = f.read().decode(errors="replace")
        return "ffmpeg" in cmdline
    except (FileNotFoundError, PermissionError):
        return True
```

- [ ] **Step 4: Run all record tests**

Run: `uv run pytest tests/test_record.py -v`
Expected: ALL PASS. Existing `test_wait_for_exit_*` and `test_is_ffmpeg_alive_dead` tests should still pass since they mock at the `os.kill` level which `_is_process_alive` wraps.

Note: If existing `test_wait_for_exit_*` tests break because they mock `os.kill` directly, update them to mock `yap.record._is_process_alive` instead.

- [ ] **Step 5: Commit**

```bash
git add src/yap/record.py tests/test_record.py
git commit -m "feat(record): cross-platform process existence checks"
```

---

### Task 4: Windows output — typing, clipboard, notifications

**Files:**
- Modify: `src/yap/output.py`
- Test: `tests/test_output.py`

- [ ] **Step 1: Write failing tests**

In `tests/test_output.py`, add:

```python
def test_type_text_windows():
    with (
        patch("yap.output.platform.system", return_value="Windows"),
        patch("yap.output._windows_type") as mock_wintype,
    ):
        result = type_text("hello world")
        mock_wintype.assert_called_once_with("hello world")
        assert result is True


def test_clipboard_windows():
    with (
        patch("yap.output.platform.system", return_value="Windows"),
        patch("yap.output._windows_clipboard") as mock_clip,
    ):
        copy_to_clipboard("hello")
        mock_clip.assert_called_once_with("hello")


def test_notify_windows():
    with (
        patch("yap.output.platform.system", return_value="Windows"),
        patch("yap.output.subprocess.run") as mock_run,
    ):
        notify("Title", "Body")
        assert mock_run.called
        cmd_str = " ".join(mock_run.call_args[0][0])
        assert "powershell" in cmd_str.lower() or "PowerShell" in cmd_str
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `uv run pytest tests/test_output.py -k "windows" -v`
Expected: FAIL

- [ ] **Step 3: Implement Windows output**

In `src/yap/output.py`:

```python
def type_text(text):
    """Type text into the active window. Returns True on success, False if no tool found."""
    system = platform.system()
    if system == "Darwin":
        script = f'tell application "System Events" to keystroke "{_escape_applescript(text)}"'
        subprocess.run(["osascript", "-e", script], check=True)
        return True
    elif system == "Windows":
        _windows_type(text)
        return True
    elif shutil.which("xdotool"):
        time.sleep(0.2)
        subprocess.run(["xdotool", "type", "--delay", "10", text], check=True)
        return True
    elif shutil.which("wtype"):
        subprocess.run(["wtype", text], check=True)
        return True
    return False


def _windows_type(text):
    """Type text on Windows via clipboard-paste (supports Unicode)."""
    import pyperclip
    import pyautogui
    pyperclip.copy(text)
    pyautogui.hotkey("ctrl", "v")


def copy_to_clipboard(text):
    system = platform.system()
    if system == "Darwin":
        subprocess.run(["pbcopy"], input=text.encode(), check=True)
    elif system == "Windows":
        _windows_clipboard(text)
    elif shutil.which("wl-copy"):
        subprocess.run(["wl-copy", text], check=True)
    else:
        subprocess.run(
            ["xclip", "-selection", "clipboard"],
            input=text.encode(),
            check=True,
        )


def _windows_clipboard(text):
    """Copy to clipboard on Windows."""
    import pyperclip
    pyperclip.copy(text)


def notify(title, body=""):
    system = platform.system()
    try:
        if system == "Darwin":
            safe_title = _escape_applescript(title)
            safe_body = _escape_applescript(body)
            script = f'display notification "{safe_body}" with title "{safe_title}"'
            subprocess.run(["osascript", "-e", script], capture_output=True, timeout=5)
        elif system == "Windows":
            ps_script = (
                f"[Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, "
                f"ContentType = WindowsRuntime] | Out-Null; "
                f"$template = '<toast><visual><binding template=\"ToastText02\">"
                f"<text id=\"1\">{title}</text><text id=\"2\">{body}</text>"
                f"</binding></visual></toast>'; "
                f"$xml = New-Object Windows.Data.Xml.Dom.XmlDocument; "
                f"$xml.LoadXml($template); "
                f"[Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier('yap')"
                f".Show([Windows.UI.Notifications.ToastNotification]::new($xml))"
            )
            subprocess.run(
                ["powershell", "-Command", ps_script],
                capture_output=True, timeout=5,
            )
        else:
            subprocess.run(
                ["notify-send", "-a", "yap", title, body],
                capture_output=True,
                timeout=5,
            )
    except (subprocess.TimeoutExpired, FileNotFoundError):
        pass
```

- [ ] **Step 4: Run all output tests**

Run: `uv run pytest tests/test_output.py -v`
Expected: ALL PASS

- [ ] **Step 5: Commit**

```bash
git add src/yap/output.py tests/test_output.py
git commit -m "feat(output): Windows typing, clipboard, and notifications"
```

---

### Task 5: Windows-aware config path

**Files:**
- Modify: `src/yap/config.py:7-9`
- Test: `tests/test_config.py`

- [ ] **Step 1: Write failing test**

In `tests/test_config.py`, add:

```python
def test_get_config_dir_windows():
    with (
        patch("yap.config.platform.system", return_value="Windows"),
        patch.dict(os.environ, {"APPDATA": "/fake/appdata"}),
    ):
        from yap.config import _get_config_dir
        assert _get_config_dir() == os.path.join("/fake/appdata", "yap")


def test_get_config_dir_unix():
    with (
        patch("yap.config.platform.system", return_value="Linux"),
        patch.dict(os.environ, {"XDG_CONFIG_HOME": "/fake/config"}, clear=False),
    ):
        from yap.config import _get_config_dir
        assert _get_config_dir() == os.path.join("/fake/config", "yap")
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `uv run pytest tests/test_config.py -k "get_config_dir" -v`
Expected: FAIL — function doesn't exist

- [ ] **Step 3: Implement platform-aware config dir**

In `src/yap/config.py`, add `import platform` and refactor:

```python
import platform

def _get_config_dir():
    if platform.system() == "Windows":
        base = os.environ.get("APPDATA", os.path.expanduser("~"))
    else:
        base = os.environ.get("XDG_CONFIG_HOME", os.path.expanduser("~/.config"))
    return os.path.join(base, "yap")

CONFIG_DIR = _get_config_dir()
CONFIG_PATH = os.path.join(CONFIG_DIR, "config.json")
```

- [ ] **Step 4: Run all config tests**

Run: `uv run pytest tests/test_config.py -v`
Expected: ALL PASS

- [ ] **Step 5: Commit**

```bash
git add src/yap/config.py tests/test_config.py
git commit -m "feat(config): use APPDATA on Windows for config path"
```

---

### Task 6: Cross-platform toggle mode stop

**Files:**
- Modify: `src/yap/cli.py:74-89` (toggle mode section)
- Test: `tests/test_cli.py`

Toggle mode kills a non-child ffmpeg process by PID. On Unix, `os.kill(pid, signal.SIGTERM)` works. On Windows, use `taskkill`. Keep the `signal` import in `cli.py` (still needed for Unix path). Add `import platform` and `import subprocess` to `cli.py`.

- [ ] **Step 1: Update CLI toggle stop with platform branch**

In `src/yap/cli.py`, replace the toggle stop block:

```python
            try:
                os.kill(pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
            else:
                wait_for_exit(pid)
```

With:

```python
            if platform.system() == "Windows":
                subprocess.run(
                    ["taskkill", "/PID", str(pid)],
                    capture_output=True,
                )
            else:
                try:
                    os.kill(pid, signal.SIGTERM)
                except ProcessLookupError:
                    pass
            wait_for_exit(pid)
```

Add `import platform` and `import subprocess` to `cli.py` imports.

- [ ] **Step 2: Write CLI toggle test for Windows**

In `tests/test_cli.py`, add:

```python
def test_toggle_stop_windows():
    with (
        patch("yap.cli.build_parser") as mock_bp,
        patch("yap.cli.is_recording", return_value=True),
        patch("yap.cli.load_and_clear_pid", return_value=1234),
        patch("yap.cli.platform.system", return_value="Windows"),
        patch("yap.cli.subprocess.run") as mock_run,
        patch("yap.cli.wait_for_exit"),
        patch("yap.cli.notify"),
        patch("yap.cli.transcribe", return_value="hello"),
        patch("yap.cli.cleanup_audio"),
        patch("yap.cli.type_text", return_value=True),
        patch("builtins.print"),
    ):
        mock_bp.return_value.parse_args.return_value = MagicMock(
            clipboard=False, llm=False, toggle=True,
            model=None, lang=None, command=None,
        )
        main()
        mock_run.assert_called_once()
        assert "taskkill" in mock_run.call_args[0][0]
```

- [ ] **Step 7: Run all tests**

Run: `uv run pytest -v`
Expected: ALL PASS

- [ ] **Step 8: Commit**

```bash
git add src/yap/record.py src/yap/cli.py tests/test_record.py tests/test_cli.py
git commit -m "feat(cli): cross-platform toggle stop (taskkill on Windows, SIGTERM on Unix)"
```

---

### Task 7: pyproject.toml and README updates

**Files:**
- Modify: `pyproject.toml`
- Modify: `README.md`

- [ ] **Step 1: Update pyproject.toml**

Add optional dependencies:

```toml
[project.optional-dependencies]
dev = ["pytest"]
web = ["websockets>=12.0"]
windows = ["pyautogui>=0.9", "pyperclip>=1.8"]
```

- [ ] **Step 2: Update README.md**

Add a Windows section under Requirements:

```markdown
- **Windows:** ffmpeg (`winget install ffmpeg`), install with `pip install yap-dictation[windows]`
```

Add a note under Install:

```markdown
Windows users: `pip install yap-dictation[windows]`
```

- [ ] **Step 3: Run tests to make sure nothing broke**

Run: `uv run pytest -v`
Expected: ALL PASS

- [ ] **Step 4: Commit**

```bash
git add pyproject.toml README.md
git commit -m "feat: add Windows optional dependencies and README section"
```

---

## Chunk 2: Web UI

### Task 8: Server module — core WebSocket server

**Files:**
- Create: `src/yap/server.py`
- Test: `tests/test_server.py`

- [ ] **Step 1: Write failing tests**

Create `tests/test_server.py`:

```python
import json
import pytest
from unittest.mock import patch, MagicMock, AsyncMock


@pytest.mark.asyncio
async def test_handle_correct_message():
    """LLM correction via WebSocket message."""
    from yap.server import handle_message

    msg = json.dumps({"type": "correct", "text": "hello wrold", "provider": "openai"})
    with patch("yap.server.llm_correct", return_value="hello world") as mock_correct:
        result = await handle_message(msg)
    parsed = json.loads(result)
    assert parsed["type"] == "corrected"
    assert parsed["text"] == "hello world"
    mock_correct.assert_called_once_with("hello wrold", "openai")


@pytest.mark.asyncio
async def test_handle_transcribe_message(tmp_path):
    """Local Whisper transcription via WebSocket."""
    from yap.server import handle_audio_message

    fake_audio = b"\x00" * 100
    with (
        patch("yap.server.transcribe", return_value="hello world") as mock_transcribe,
        patch("yap.server.TMPDIR", str(tmp_path)),
        patch("yap.server.subprocess.run"),  # ffmpeg conversion
    ):
        result = await handle_audio_message(fake_audio, {"model": "small.en", "language": None})
    parsed = json.loads(result)
    assert parsed["type"] == "transcription"
    assert parsed["text"] == "hello world"


@pytest.mark.asyncio
async def test_handle_type_message():
    """Type-into-window via WebSocket message."""
    from yap.server import handle_message

    msg = json.dumps({"type": "type_text", "text": "hello"})
    with patch("yap.server.type_text", return_value=True) as mock_type:
        result = await handle_message(msg)
    parsed = json.loads(result)
    assert parsed["type"] == "typed"
    assert parsed["success"] is True


@pytest.mark.asyncio
async def test_handle_clipboard_message():
    """Copy-to-clipboard via WebSocket message."""
    from yap.server import handle_message

    msg = json.dumps({"type": "clipboard", "text": "hello"})
    with patch("yap.server.copy_to_clipboard") as mock_clip:
        result = await handle_message(msg)
    parsed = json.loads(result)
    assert parsed["type"] == "copied"
    mock_clip.assert_called_once_with("hello")


@pytest.mark.asyncio
async def test_handle_unknown_message_type():
    """Unknown message types return an error."""
    from yap.server import handle_message

    msg = json.dumps({"type": "unknown"})
    result = await handle_message(msg)
    parsed = json.loads(result)
    assert parsed["type"] == "error"
```

Also add `pytest-asyncio` to dev dependencies in pyproject.toml and configure asyncio mode:

```toml
dev = ["pytest", "pytest-asyncio"]
```

Add to pyproject.toml:

```toml
[tool.pytest.ini_options]
asyncio_mode = "auto"
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `uv run pytest tests/test_server.py -v`
Expected: FAIL — module doesn't exist

- [ ] **Step 3: Implement server module**

Create `src/yap/server.py`:

```python
"""Web UI server for yap — serves HTML + handles WebSocket messages."""

import asyncio
import json
import os
import subprocess
import tempfile
import uuid

from yap.transcribe import transcribe
from yap.correct import llm_correct
from yap.output import type_text, copy_to_clipboard

TMPDIR = os.path.join(tempfile.gettempdir(), "yap")


async def handle_message(raw):
    """Handle a JSON WebSocket message, return a JSON response string."""
    msg = json.loads(raw)
    msg_type = msg.get("type")

    if msg_type == "correct":
        # llm_correct is synchronous (HTTP/subprocess) — offload to thread
        text = await asyncio.to_thread(llm_correct, msg["text"], msg["provider"])
        return json.dumps({"type": "corrected", "text": text})

    elif msg_type == "type_text":
        success = await asyncio.to_thread(type_text, msg["text"])
        return json.dumps({"type": "typed", "success": success})

    elif msg_type == "clipboard":
        await asyncio.to_thread(copy_to_clipboard, msg["text"])
        return json.dumps({"type": "copied"})

    else:
        return json.dumps({"type": "error", "message": f"Unknown type: {msg_type}"})


async def handle_audio_message(audio_bytes, settings):
    """Handle binary audio data: convert to WAV, transcribe, return JSON."""
    os.makedirs(TMPDIR, exist_ok=True)
    # Use unique filenames to avoid race conditions with concurrent clients
    uid = uuid.uuid4().hex[:8]
    webm_path = os.path.join(TMPDIR, f"upload-{uid}.webm")
    wav_path = os.path.join(TMPDIR, f"upload-{uid}.wav")

    with open(webm_path, "wb") as f:
        f.write(audio_bytes)

    # Convert browser audio (WebM/Opus) to WAV for faster-whisper
    await asyncio.to_thread(
        subprocess.run,
        ["ffmpeg", "-y", "-i", webm_path, "-ar", "16000", "-ac", "1", wav_path,
         "-loglevel", "error"],
        check=True,
    )

    text = await asyncio.to_thread(
        transcribe,
        wav_path,
        model_size=settings.get("model", "small.en"),
        language=settings.get("language"),
    )

    # Cleanup temp files
    for path in (webm_path, wav_path):
        try:
            os.remove(path)
        except FileNotFoundError:
            pass

    return json.dumps({"type": "transcription", "text": text})


def _get_static_dir():
    return os.path.join(os.path.dirname(__file__), "static")


async def _serve(host, port):
    """Start the WebSocket + HTTP server."""
    try:
        from websockets.asyncio.server import serve
        from websockets.http11 import Response
        from websockets.datastructures import Headers
    except ImportError:
        print("Web UI requires the 'websockets' package.")
        print("Install it with: pip install yap-dictation[web]")
        raise SystemExit(1)

    static_dir = _get_static_dir()
    index_path = os.path.join(static_dir, "index.html")

    with open(index_path, "rb") as f:
        index_html = f.read()

    async def handler(websocket):
        settings = {}
        async for message in websocket:
            if isinstance(message, bytes):
                response = await handle_audio_message(message, settings)
            else:
                parsed = json.loads(message)
                if parsed.get("type") == "settings":
                    settings = parsed.get("settings", {})
                    continue
                response = await handle_message(message)
            await websocket.send(response)

    async def process_request(connection, request):
        """Serve index.html for HTTP GET requests."""
        if request.path == "/" or request.path == "/index.html":
            headers = Headers([("Content-Type", "text/html; charset=utf-8")])
            return Response(200, "OK", headers, index_html)

    url = f"http://{host}:{port}"
    print(f"yap web UI running at {url}")

    # Open browser once server is ready
    import webbrowser
    asyncio.get_running_loop().call_later(1.0, webbrowser.open, url)

    async with serve(
        handler,
        host,
        port,
        process_request=process_request,
        max_size=10 * 1024 * 1024,  # 10MB for longer recordings
    ):
        await asyncio.Future()  # Run forever


def run_server(host="localhost", port=8765):
    """Entry point called from CLI."""
    try:
        asyncio.run(_serve(host, port))
    except KeyboardInterrupt:
        # Cleanup any leftover temp files
        for f in os.listdir(TMPDIR) if os.path.isdir(TMPDIR) else []:
            if f.startswith("upload-"):
                try:
                    os.remove(os.path.join(TMPDIR, f))
                except FileNotFoundError:
                    pass
        print("\nServer stopped.")
```

The core message handling (`handle_message`, `handle_audio_message`) is the testable business logic; the server wiring is integration-tested manually. All synchronous calls (`llm_correct`, `type_text`, `copy_to_clipboard`, `subprocess.run`, `transcribe`) are wrapped in `asyncio.to_thread()` to avoid blocking the event loop.

- [ ] **Step 4: Run server tests**

Run: `uv run pytest tests/test_server.py -v`
Expected: ALL PASS

- [ ] **Step 5: Commit**

```bash
git add src/yap/server.py tests/test_server.py pyproject.toml
git commit -m "feat(server): WebSocket server with transcription, correction, and output handlers"
```

---

### Task 9: Web UI HTML page

**Files:**
- Create: `src/yap/static/index.html`

- [ ] **Step 1: Create the static directory**

```bash
mkdir -p src/yap/static
```

- [ ] **Step 2: Create index.html**

Create `src/yap/static/index.html` — a single-file web app with:

**HTML structure:**
- Header with "yap" title
- Large circular record button (toggles recording on/off)
- Text output area (readonly textarea)
- Action buttons: "Copy" and "Type into window"
- Collapsible settings drawer

**CSS (embedded `<style>`):**
- Clean, minimal design — dark background, large centered button
- Record button pulses red when recording
- Responsive layout (flexbox, works at any width)
- No external fonts or assets

**JavaScript (embedded `<script>`):**
- **WebSocket connection** to `ws://localhost:${port}` (port from URL)
- **Web Speech API path** (`SpeechRecognition`):
  - `recognition.continuous = true`
  - `recognition.interimResults = true`
  - On result, show interim text in output area
  - On end, send final text to server for LLM correction if enabled
- **Local Whisper path** (`MediaRecorder`):
  - Start MediaRecorder on button press
  - On stop, send audio blob as binary WebSocket message
  - First send a `{"type": "settings", "settings": {...}}` message with model/language
  - Receive transcription result from server
- **Settings drawer:**
  - Transcription mode: "Browser Speech (free)" / "Local Whisper"
  - Whisper model dropdown: tiny.en, base.en, small.en, medium.en
  - Language text input
  - LLM correction toggle + provider dropdown
  - Persist to `localStorage`
  - Send settings to server via WebSocket on change
- **Copy button:** Uses `navigator.clipboard.writeText()`
- **Type button:** Sends `{"type": "type_text", "text": "..."}` via WebSocket
- **Privacy note** in settings: "Browser Speech sends audio to your browser vendor's servers. Local Whisper keeps everything on your device."

Key implementation details:
- Feature-detect `webkitSpeechRecognition || SpeechRecognition` — if absent, hide Browser Speech option and default to Local Whisper
- Show "Not supported in this browser" message for Firefox users selecting Browser Speech
- WebSocket reconnection: if connection drops, retry every 2 seconds with backoff

- [ ] **Step 3: Manually test in browser**

Run: `uv run yap --serve` (after Task 10 wires it up)
Verify: page loads, record button works, settings drawer opens

- [ ] **Step 4: Commit**

```bash
git add src/yap/static/index.html
git commit -m "feat(web): single-file web UI with Speech API and Local Whisper modes"
```

---

### Task 10: CLI integration — `--serve` flag

**Files:**
- Modify: `src/yap/cli.py`
- Test: `tests/test_cli.py`

- [ ] **Step 1: Write failing tests**

In `tests/test_cli.py`, add:

```python
def test_parser_serve_flag():
    parser = build_parser()
    args = parser.parse_args(["--serve"])
    assert args.serve is True
    assert args.port == 8765


def test_parser_serve_with_port():
    parser = build_parser()
    args = parser.parse_args(["--serve", "--port", "9000"])
    assert args.serve is True
    assert args.port == 9000


def test_main_serve_mode():
    with (
        patch("yap.cli.build_parser") as mock_bp,
        patch("yap.cli.run_server") as mock_serve,
    ):
        mock_bp.return_value.parse_args.return_value = MagicMock(
            serve=True, port=8765, command=None,
            clipboard=False, llm=False, toggle=False,
            model=None, lang=None,
        )
        result = main()
        mock_serve.assert_called_once_with(host="localhost", port=8765)
        assert result == 0


def test_main_serve_warns_on_extra_flags(capsys):
    with (
        patch("yap.cli.build_parser") as mock_bp,
        patch("yap.cli.run_server"),
    ):
        mock_bp.return_value.parse_args.return_value = MagicMock(
            serve=True, port=8765, command=None,
            clipboard=True, llm=True, toggle=False,
            model=None, lang=None,
        )
        main()
        captured = capsys.readouterr()
        assert "ignored" in captured.out.lower() or "warning" in captured.out.lower()
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `uv run pytest tests/test_cli.py -k "serve" -v`
Expected: FAIL

**Important:** After adding `--serve` and `--port` to the parser, all existing CLI tests that mock `parse_args` must be updated to include `serve=False, port=8765` in their `MagicMock` kwargs. Otherwise `args.serve` will be a truthy `MagicMock` and existing tests will take the serve code path. Update every existing `MagicMock(clipboard=..., ...)` call in `tests/test_cli.py` to include these two new attributes.

- [ ] **Step 3: Implement --serve flag in CLI**

In `src/yap/cli.py`, add to `build_parser()`:

```python
    parser.add_argument(
        "-s", "--serve",
        action="store_true",
        help="Start the web UI server",
    )
    parser.add_argument(
        "--port",
        type=int,
        default=8765,
        help="Port for web UI server (default: 8765)",
    )
```

In `main()`, add serve mode handling after the config subcommand check and before the model/lang setup:

```python
    # --- Serve mode ---
    if args.serve:
        extra_flags = []
        if args.clipboard:
            extra_flags.append("--clipboard")
        if args.llm:
            extra_flags.append("--llm")
        if args.toggle:
            extra_flags.append("--toggle")
        if extra_flags:
            print(f"Warning: {', '.join(extra_flags)} ignored in serve mode. "
                  f"Use the web UI settings instead.")
        from yap.server import run_server
        run_server(host="localhost", port=args.port)
        return 0
```

- [ ] **Step 4: Run all tests**

Run: `uv run pytest -v`
Expected: ALL PASS

- [ ] **Step 5: Commit**

```bash
git add src/yap/cli.py tests/test_cli.py
git commit -m "feat(cli): add --serve and --port flags for web UI"
```

---

### Task 11: Include static files in package build

**Files:**
- Modify: `pyproject.toml`

- [ ] **Step 1: Verify static files are included**

The hatch build config at `[tool.hatch.build.targets.wheel]` has `packages = ["src/yap"]`. Since `static/` is inside `src/yap/`, it should be included automatically. Verify:

```bash
uv run python -c "from yap.server import _get_static_dir; import os; print(os.listdir(_get_static_dir()))"
```

Expected: `['index.html']`

If files are missing, add to pyproject.toml:

```toml
[tool.hatch.build.targets.wheel]
packages = ["src/yap"]
artifacts = ["src/yap/static/*"]
```

- [ ] **Step 2: Run full test suite**

Run: `uv run pytest -v`
Expected: ALL PASS

- [ ] **Step 3: Commit**

```bash
git add pyproject.toml
git commit -m "build: ensure static files included in wheel"
```

---

### Task 12: Update README with web UI docs

**Files:**
- Modify: `README.md`

- [ ] **Step 1: Add web UI section to README**

After the "Hotkey mode" section, add:

```markdown
## Web UI

For a graphical interface, start the web server:

\`\`\`bash
pip install yap-dictation[web]   # one-time setup
yap --serve
\`\`\`

Opens a browser page with a record button, transcription display, and settings.

Two transcription modes available in the web UI:
- **Browser Speech** — free, uses your browser's built-in speech recognition (Chrome, Edge, Safari)
- **Local Whisper** — private, uses the same local Whisper model as the CLI

Note: Browser Speech sends audio to your browser vendor's servers for processing.
```

Update the Options table to include `--serve` and `--port`.

- [ ] **Step 2: Commit**

```bash
git add README.md
git commit -m "docs: add web UI section to README"
```

---

### Task 13: Final integration test and lint

- [ ] **Step 1: Run full test suite**

Run: `uv run pytest -v`
Expected: ALL PASS

- [ ] **Step 2: Lint and format**

Run: `uv run ruff check . --fix && uv run ruff format .`
Expected: Clean or auto-fixed

- [ ] **Step 3: Commit any lint fixes**

```bash
git add -u
git commit -m "style: lint and format fixes"
```

(Skip if no changes.)
