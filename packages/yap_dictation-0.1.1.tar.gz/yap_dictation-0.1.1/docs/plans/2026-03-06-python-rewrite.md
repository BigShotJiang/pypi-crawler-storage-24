# Python Package Rewrite Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Rewrite yap from a bash script to a cross-platform Python CLI package installable via `pip install`.

**Architecture:** Single Python package with platform-detection for audio recording (ffmpeg with OS-specific input format), text output (xdotool/wtype on Linux, osascript on macOS), and clipboard (xclip/pbcopy). CLI via argparse. Entry point via `pyproject.toml` console_scripts. Whisper transcription via faster-whisper. Optional LLM correction via curl-equivalent (urllib or subprocess curl).

**Tech Stack:** Python 3.10+, faster-whisper, ffmpeg (subprocess), argparse, pyproject.toml with uv

---

### Task 1: Project scaffolding

**Files:**
- Create: `pyproject.toml`
- Create: `src/yap/__init__.py`
- Create: `src/yap/__main__.py`
- Create: `src/yap/cli.py`
- Remove: `install.sh` (replaced by pip install)
- Keep: `yap` (bash script, remove in Task 7 after Python version works)

**Step 1: Create pyproject.toml**

```toml
[project]
name = "yap-dictation"
version = "0.1.0"
description = "Talk is cheap. Voice dictation for the terminal."
readme = "README.md"
license = "GPL-3.0-or-later"
requires-python = ">=3.10"
dependencies = [
    "faster-whisper>=1.0.0",
]

[project.optional-dependencies]
dev = ["pytest"]

[project.scripts]
yap = "yap.cli:main"

[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[tool.hatch.build.targets.wheel]
packages = ["src/yap"]
```

**Step 2: Create src/yap/__init__.py**

```python
"""yap - Talk is cheap. Voice dictation for the terminal."""

__version__ = "0.1.0"
```

**Step 3: Create src/yap/__main__.py**

```python
from yap.cli import main

main()
```

**Step 4: Create src/yap/cli.py (skeleton)**

```python
import argparse
import sys


def build_parser():
    parser = argparse.ArgumentParser(
        prog="yap",
        description="Voice dictation for the terminal.",
    )
    parser.add_argument("-c", "--clipboard", action="store_true",
                        help="Copy to clipboard instead of typing")
    parser.add_argument("-l", "--llm", action="store_true",
                        help="Correct transcription with an LLM")
    parser.add_argument("-t", "--toggle", action="store_true",
                        help="Hotkey mode: 1st call starts, 2nd stops and transcribes")
    parser.add_argument("--model", default=None,
                        help="Whisper model (default: small.en, env: WHISPER_MODEL)")
    parser.add_argument("--lang", default=None,
                        help="Language code e.g. en, zh, ja (default: en, env: YAP_LANG)")
    return parser


def main():
    parser = build_parser()
    args = parser.parse_args()
    print(f"yap called with: {args}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
```

**Step 5: Verify install works**

Run: `cd /home/julie/Projects/yap && uv venv && uv pip install -e ".[dev]"`
Then: `uv run yap --help`
Expected: Help text prints with all options.

**Step 6: Commit**

```bash
git add pyproject.toml src/
git commit -m "feat: scaffold Python package structure"
```

---

### Task 2: Cross-platform audio recording

**Files:**
- Create: `src/yap/record.py`
- Create: `tests/test_record.py`

**Step 1: Write the test**

```python
import platform
from unittest.mock import patch
from yap.record import get_ffmpeg_input_args


def test_ffmpeg_args_linux():
    with patch("platform.system", return_value="Linux"):
        args = get_ffmpeg_input_args()
        assert args == ["-f", "pulse", "-i", "default"]


def test_ffmpeg_args_macos():
    with patch("platform.system", return_value="Darwin"):
        args = get_ffmpeg_input_args()
        assert args == ["-f", "avfoundation", "-i", ":default"]
```

**Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_record.py -v`
Expected: FAIL — module not found

**Step 3: Write implementation**

```python
"""Audio recording via ffmpeg (cross-platform)."""

import os
import platform
import signal
import subprocess
import tempfile

TMPDIR = os.path.join(tempfile.gettempdir(), "yap")
AUDIO_PATH = os.path.join(TMPDIR, "recording.wav")
PID_FILE = os.path.join(TMPDIR, "recording.pid")


def get_ffmpeg_input_args():
    system = platform.system()
    if system == "Darwin":
        return ["-f", "avfoundation", "-i", ":default"]
    else:  # Linux
        return ["-f", "pulse", "-i", "default"]


def start_recording():
    os.makedirs(TMPDIR, exist_ok=True)
    input_args = get_ffmpeg_input_args()
    cmd = ["ffmpeg", "-y"] + input_args + ["-ac", "1", "-ar", "16000",
           AUDIO_PATH, "-loglevel", "error"]
    proc = subprocess.Popen(cmd)
    return proc


def stop_recording(proc):
    proc.send_signal(signal.SIGTERM)
    proc.wait()
    return AUDIO_PATH


def save_pid(pid):
    with open(PID_FILE, "w") as f:
        f.write(str(pid))


def load_and_clear_pid():
    if not os.path.exists(PID_FILE):
        return None
    with open(PID_FILE) as f:
        pid = int(f.read().strip())
    os.remove(PID_FILE)
    return pid


def is_recording():
    return os.path.exists(PID_FILE)
```

**Step 4: Run tests**

Run: `uv run pytest tests/test_record.py -v`
Expected: PASS

**Step 5: Commit**

```bash
git add src/yap/record.py tests/test_record.py
git commit -m "feat: cross-platform audio recording module"
```

---

### Task 3: Whisper transcription

**Files:**
- Create: `src/yap/transcribe.py`
- Create: `tests/test_transcribe.py`

**Step 1: Write the test**

```python
from unittest.mock import patch, MagicMock
from yap.transcribe import transcribe


def test_transcribe_returns_text():
    mock_model = MagicMock()
    mock_segment = MagicMock()
    mock_segment.text = "Hello world"
    mock_model.transcribe.return_value = ([mock_segment], None)

    with patch("yap.transcribe.WhisperModel", return_value=mock_model):
        result = transcribe("/tmp/test.wav", model_size="tiny.en")

    assert result == "Hello world"


def test_transcribe_empty_returns_empty():
    mock_model = MagicMock()
    mock_model.transcribe.return_value = ([], None)

    with patch("yap.transcribe.WhisperModel", return_value=mock_model):
        result = transcribe("/tmp/test.wav", model_size="tiny.en")

    assert result == ""
```

**Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_transcribe.py -v`
Expected: FAIL

**Step 3: Write implementation**

```python
"""Speech-to-text via faster-whisper."""

from faster_whisper import WhisperModel

_model_cache = {}


def transcribe(audio_path, model_size="small.en", language=None):
    if model_size not in _model_cache:
        _model_cache[model_size] = WhisperModel(
            model_size, device="auto", compute_type="auto"
        )
    model = _model_cache[model_size]

    kwargs = {"beam_size": 5}
    if language:
        kwargs["language"] = language

    segments, _ = model.transcribe(audio_path, **kwargs)
    return "".join(segment.text for segment in segments).strip()
```

**Step 4: Run tests**

Run: `uv run pytest tests/test_transcribe.py -v`
Expected: PASS

**Step 5: Commit**

```bash
git add src/yap/transcribe.py tests/test_transcribe.py
git commit -m "feat: whisper transcription module with model caching"
```

---

### Task 4: Cross-platform text output

**Files:**
- Create: `src/yap/output.py`
- Create: `tests/test_output.py`

**Step 1: Write the test**

```python
import platform
from unittest.mock import patch, call
from yap.output import type_text, copy_to_clipboard


def test_type_text_linux_xdotool():
    with patch("platform.system", return_value="Linux"), \
         patch("shutil.which", return_value="/usr/bin/xdotool"), \
         patch("subprocess.run") as mock_run:
        type_text("hello")
        mock_run.assert_called_once_with(
            ["xdotool", "type", "--delay", "10", "hello"], check=True
        )


def test_type_text_macos():
    with patch("platform.system", return_value="Darwin"), \
         patch("subprocess.run") as mock_run:
        type_text("hello")
        # Should use osascript
        assert mock_run.called
        cmd = mock_run.call_args[0][0]
        assert cmd[0] == "osascript"


def test_clipboard_linux():
    with patch("platform.system", return_value="Linux"), \
         patch("subprocess.run") as mock_run:
        copy_to_clipboard("hello")
        mock_run.assert_called_once()
        cmd = mock_run.call_args[0][0]
        assert "xclip" in cmd


def test_clipboard_macos():
    with patch("platform.system", return_value="Darwin"), \
         patch("subprocess.run") as mock_run:
        copy_to_clipboard("hello")
        mock_run.assert_called_once()
        cmd = mock_run.call_args[0][0]
        assert "pbcopy" in cmd
```

**Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_output.py -v`
Expected: FAIL

**Step 3: Write implementation**

```python
"""Cross-platform text output: type into window or copy to clipboard."""

import platform
import shutil
import subprocess
import time


def type_text(text):
    system = platform.system()
    if system == "Darwin":
        # macOS: use osascript to simulate keystrokes
        script = f'tell application "System Events" to keystroke "{_escape_applescript(text)}"'
        subprocess.run(["osascript", "-e", script], check=True)
    elif shutil.which("xdotool"):
        time.sleep(0.2)
        subprocess.run(["xdotool", "type", "--delay", "10", text], check=True)
    elif shutil.which("wtype"):
        subprocess.run(["wtype", text], check=True)
    else:
        copy_to_clipboard(text)
        _notify("Copied to clipboard (no typing tool found)")


def copy_to_clipboard(text):
    system = platform.system()
    if system == "Darwin":
        subprocess.run(["pbcopy"], input=text.encode(), check=True)
    else:
        subprocess.run(
            ["xclip", "-selection", "clipboard"],
            input=text.encode(), check=True,
        )


def notify(title, body=""):
    system = platform.system()
    try:
        if system == "Darwin":
            script = f'display notification "{body}" with title "{title}"'
            subprocess.run(["osascript", "-e", script],
                           capture_output=True, timeout=5)
        else:
            subprocess.run(["notify-send", "-a", "yap", title, body],
                           capture_output=True, timeout=5)
    except (subprocess.TimeoutExpired, FileNotFoundError):
        pass


def _escape_applescript(text):
    return text.replace("\\", "\\\\").replace('"', '\\"')


def _notify(msg):
    notify("yap", msg)
```

**Step 4: Run tests**

Run: `uv run pytest tests/test_output.py -v`
Expected: PASS

**Step 5: Commit**

```bash
git add src/yap/output.py tests/test_output.py
git commit -m "feat: cross-platform text output and clipboard"
```

---

### Task 5: LLM correction

**Files:**
- Create: `src/yap/correct.py`
- Create: `tests/test_correct.py`

**Step 1: Write the test**

```python
import json
from unittest.mock import patch, MagicMock
from yap.correct import detect_provider, llm_correct


def test_detect_claude_code():
    with patch("shutil.which", return_value="/usr/bin/claude"), \
         patch.dict("os.environ", {}, clear=True):
        assert detect_provider() == "claude-code"


def test_detect_anthropic_key():
    with patch("shutil.which", return_value=None), \
         patch.dict("os.environ", {"ANTHROPIC_API_KEY": "sk-test"}, clear=True):
        assert detect_provider() == "claude"


def test_detect_none():
    with patch("shutil.which", return_value=None), \
         patch.dict("os.environ", {}, clear=True):
        assert detect_provider() is None


def test_llm_correct_no_provider():
    with patch("yap.correct.detect_provider", return_value=None):
        assert llm_correct("hello wrold") == "hello wrold"
```

**Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_correct.py -v`
Expected: FAIL

**Step 3: Write implementation**

```python
"""LLM-based transcription correction."""

import json
import os
import shutil
import subprocess

PROMPT = (
    "Fix any speech-to-text transcription errors in the following text. "
    "Fix grammar, punctuation, and misheard words. "
    "Do not rephrase or change the meaning. "
    "Return only the corrected text, nothing else."
)


def detect_provider(override=None):
    if override:
        return override
    if shutil.which("claude"):
        return "claude-code"
    if os.environ.get("ANTHROPIC_API_KEY"):
        return "claude"
    if os.environ.get("OPENAI_API_KEY"):
        return "openai"
    if os.environ.get("GEMINI_API_KEY"):
        return "gemini"
    return None


def llm_correct(text, provider_override=None):
    provider = detect_provider(provider_override)
    if not provider:
        return text

    try:
        if provider == "claude-code":
            return _correct_claude_code(text)
        elif provider == "claude":
            return _correct_claude_api(text)
        elif provider == "openai":
            return _correct_openai(text)
        elif provider == "gemini":
            return _correct_gemini(text)
    except Exception:
        return text
    return text


def _correct_claude_code(text):
    result = subprocess.run(
        ["claude", "-p", "--model", "haiku",
         "--no-session-persistence", "--tools", "",
         "--system-prompt", PROMPT],
        input=text, capture_output=True, text=True, timeout=30,
    )
    return result.stdout.strip() or text


def _correct_claude_api(text):
    payload = json.dumps({
        "model": "claude-haiku-4-5-20251001",
        "max_tokens": 1024,
        "messages": [{"role": "user", "content": f"{PROMPT}\n\n{text}"}],
    })
    result = subprocess.run(
        ["curl", "-s", "https://api.anthropic.com/v1/messages",
         "-H", f"x-api-key: {os.environ['ANTHROPIC_API_KEY']}",
         "-H", "anthropic-version: 2023-06-01",
         "-H", "content-type: application/json",
         "-d", payload],
        capture_output=True, text=True, timeout=30,
    )
    r = json.loads(result.stdout)
    return r["content"][0]["text"]


def _correct_openai(text):
    payload = json.dumps({
        "model": "gpt-4o-mini",
        "messages": [{"role": "user", "content": f"{PROMPT}\n\n{text}"}],
    })
    result = subprocess.run(
        ["curl", "-s", "https://api.openai.com/v1/chat/completions",
         "-H", f"Authorization: Bearer {os.environ['OPENAI_API_KEY']}",
         "-H", "Content-Type: application/json",
         "-d", payload],
        capture_output=True, text=True, timeout=30,
    )
    r = json.loads(result.stdout)
    return r["choices"][0]["message"]["content"]


def _correct_gemini(text):
    key = os.environ["GEMINI_API_KEY"]
    payload = json.dumps({
        "contents": [{"parts": [{"text": f"{PROMPT}\n\n{text}"}]}],
    })
    url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key={key}"
    result = subprocess.run(
        ["curl", "-s", url, "-H", "Content-Type: application/json",
         "-d", payload],
        capture_output=True, text=True, timeout=30,
    )
    r = json.loads(result.stdout)
    return r["candidates"][0]["content"]["parts"][0]["text"]
```

**Step 4: Run tests**

Run: `uv run pytest tests/test_correct.py -v`
Expected: PASS

**Step 5: Commit**

```bash
git add src/yap/correct.py tests/test_correct.py
git commit -m "feat: LLM correction module with multi-provider support"
```

---

### Task 6: Wire up CLI

**Files:**
- Modify: `src/yap/cli.py`
- Create: `tests/test_cli.py`

**Step 1: Write the test**

```python
from unittest.mock import patch, MagicMock
from yap.cli import build_parser


def test_parser_defaults():
    parser = build_parser()
    args = parser.parse_args([])
    assert args.clipboard is False
    assert args.llm is False
    assert args.toggle is False
    assert args.model is None
    assert args.lang is None


def test_parser_all_flags():
    parser = build_parser()
    args = parser.parse_args(["--clipboard", "--llm", "--toggle", "--model", "tiny.en", "--lang", "zh"])
    assert args.clipboard is True
    assert args.llm is True
    assert args.toggle is True
    assert args.model == "tiny.en"
    assert args.lang == "zh"
```

**Step 2: Run test to verify it passes (parser already exists)**

Run: `uv run pytest tests/test_cli.py -v`
Expected: PASS

**Step 3: Rewrite cli.py with full pipeline**

```python
"""yap CLI entry point."""

import argparse
import os
import signal
import sys

from yap.record import (
    start_recording, stop_recording, save_pid,
    load_and_clear_pid, is_recording, AUDIO_PATH,
)
from yap.transcribe import transcribe
from yap.correct import llm_correct
from yap.output import type_text, copy_to_clipboard, notify


def build_parser():
    parser = argparse.ArgumentParser(
        prog="yap",
        description="Talk is cheap. Voice dictation for the terminal.",
    )
    parser.add_argument("-c", "--clipboard", action="store_true",
                        help="Copy to clipboard instead of typing")
    parser.add_argument("-l", "--llm", action="store_true",
                        help="Correct transcription with an LLM")
    parser.add_argument("-t", "--toggle", action="store_true",
                        help="Hotkey mode: 1st call starts, 2nd stops and transcribes")
    parser.add_argument("--model", default=None,
                        help="Whisper model (default: small.en, env: WHISPER_MODEL)")
    parser.add_argument("--lang", default=None,
                        help="Language code e.g. en, zh, ja (default: en, env: YAP_LANG)")
    return parser


def main():
    parser = build_parser()
    args = parser.parse_args()

    model = args.model or os.environ.get("WHISPER_MODEL", "small.en")
    lang = args.lang or os.environ.get("YAP_LANG")

    # --- Toggle mode ---
    if args.toggle:
        if is_recording():
            pid = load_and_clear_pid()
            if pid:
                try:
                    os.kill(pid, signal.SIGTERM)
                    os.waitpid(pid, 0)
                except (ProcessLookupError, ChildProcessError):
                    pass
            notify("Transcribing...")
        else:
            proc = start_recording()
            save_pid(proc.pid)
            notify("Recording...", "Press hotkey again to stop.")
            return 0

    # --- Interactive mode ---
    else:
        print("Recording... Press Enter to stop.")
        proc = start_recording()
        try:
            input()
        except (EOFError, KeyboardInterrupt):
            pass
        stop_recording(proc)
        print("Transcribing...")

    # --- Transcribe ---
    text = transcribe(AUDIO_PATH, model_size=model, language=lang)

    try:
        os.remove(AUDIO_PATH)
    except FileNotFoundError:
        pass

    if not text:
        msg = "No speech detected."
        if args.toggle:
            notify(msg)
        else:
            print(msg)
        return 0

    # --- LLM correction ---
    if args.llm:
        provider_override = os.environ.get("YAP_LLM")
        if not args.toggle:
            print("Correcting...")
        text = llm_correct(text, provider_override)

    # --- Output ---
    if args.toggle:
        notify("Done", text)
    else:
        print(text)

    if args.clipboard:
        copy_to_clipboard(text)
        if not args.toggle:
            print("(copied to clipboard)")
    else:
        type_text(text)

    return 0


if __name__ == "__main__":
    sys.exit(main())
```

**Step 4: Run all tests**

Run: `uv run pytest -v`
Expected: All PASS

**Step 5: Manual smoke test**

Run: `uv run yap --help`
Expected: Help text with all options including --toggle, --lang, --model

**Step 6: Commit**

```bash
git add src/yap/cli.py tests/test_cli.py
git commit -m "feat: wire up full CLI pipeline"
```

---

### Task 7: Clean up old files and update README

**Files:**
- Remove: `yap` (bash script)
- Remove: `install.sh`
- Remove: `design-philosophy.md`
- Modify: `README.md`
- Modify: `.gitignore`

**Step 1: Update .gitignore**

```
*.wav
*.mp3
*.pyc
__pycache__/
.env
.venv/
dist/
*.egg-info/
```

**Step 2: Update README.md**

Update install section to:
```bash
pip install yap-dictation
```

Add `--lang` and `--model` to usage. Add macOS to supported platforms.

**Step 3: Remove old files**

```bash
rm yap install.sh design-philosophy.md
```

**Step 4: Run all tests one final time**

Run: `uv run pytest -v`
Expected: All PASS

**Step 5: Commit**

```bash
git add -A
git commit -m "chore: remove bash script, update for Python package"
```

---

### Task 8: Final verification

**Step 1: Clean install test**

```bash
uv venv /tmp/yap-test && source /tmp/yap-test/bin/activate
cd /home/julie/Projects/yap
uv pip install .
yap --help
deactivate && rm -rf /tmp/yap-test
```

**Step 2: Push**

```bash
git push
```
