# LLM Config Design

## Goal
Replace auto-detection of LLM providers with explicit user configuration via `yap config` wizard.

## Config file
- Location: `~/.config/yap/config.json`
- Contents: `{"llm_provider": "openai"}`

## `yap config` subcommand
Interactive wizard: presents 4 providers, validates prerequisites (CLI on PATH or env var set), saves choice.

## `--llm` behavior
- Config exists → use saved provider
- No config → print message to run `yap config`, skip correction
- No auto-detection, no `YAP_LLM` env var override

## Files
- New: `src/yap/config.py` — load_config, save_config, run_config_wizard
- Modify: `src/yap/correct.py` — remove detect_provider, llm_correct takes explicit provider
- Modify: `src/yap/cli.py` — add config subcommand, wire up config loading
- New: `tests/test_config.py`
- Modify: `tests/test_correct.py`
