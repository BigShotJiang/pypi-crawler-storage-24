# Review Fixes Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Fix all 31 findings from the 4-dimension code review (architecture, quality, testing, docs).

**Architecture:** Four independent workstreams — code fixes to `record.py`/`correct.py`/`output.py`/`cli.py`, new tests, README updates, and minor cleanup. Code fixes land first since tests depend on new interfaces.

**Tech Stack:** Python 3.10+, uv, pytest, urllib.request (stdlib)

---

### Task 1: Fix `record.py` — PID logic, stop timeout, cleanup helper, comments

**Files:**
- Modify: `src/yap/record.py`
- Test: `tests/test_record.py`

**Step 1: Write tests for PID round-trip, stale detection, and cleanup**

Add to `tests/test_record.py`:

```python
import os
import signal
from unittest.mock import patch, mock_open, MagicMock
from yap.record import (
    save_pid, load_and_clear_pid, is_recording, wait_for_exit,
    _read_pid, _is_ffmpeg_alive, cleanup_audio, stop_recording,
    TMPDIR, PID_FILE, AUDIO_PATH,
)


def test_save_and_load_pid(tmp_path):
    pid_file = str(tmp_path / "recording.pid")
    with patch("yap.record.PID_FILE", pid_file), \
         patch("yap.record.TMPDIR", str(tmp_path)):
        save_pid(12345)
        assert os.path.exists(pid_file)
        pid = load_and_clear_pid()
        assert pid == 12345
        assert not os.path.exists(pid_file)


def test_load_and_clear_pid_missing(tmp_path):
    pid_file = str(tmp_path / "recording.pid")
    with patch("yap.record.PID_FILE", pid_file):
        assert load_and_clear_pid() is None


def test_load_and_clear_pid_corrupt(tmp_path):
    pid_file = str(tmp_path / "recording.pid")
    with open(pid_file, "w") as f:
        f.write("not-a-number")
    with patch("yap.record.PID_FILE", pid_file):
        assert load_and_clear_pid() is None
        assert not os.path.exists(pid_file)


def test_is_recording_no_pid_file(tmp_path):
    pid_file = str(tmp_path / "recording.pid")
    with patch("yap.record.PID_FILE", pid_file):
        assert is_recording() is False


def test_is_recording_stale_pid(tmp_path):
    pid_file = str(tmp_path / "recording.pid")
    with open(pid_file, "w") as f:
        f.write("99999999")
    with patch("yap.record.PID_FILE", pid_file), \
         patch("yap.record._is_ffmpeg_alive", return_value=False):
        assert is_recording() is False
        assert not os.path.exists(pid_file)


def test_is_recording_alive(tmp_path):
    pid_file = str(tmp_path / "recording.pid")
    with open(pid_file, "w") as f:
        f.write("1234")
    with patch("yap.record.PID_FILE", pid_file), \
         patch("yap.record._read_pid", return_value=1234), \
         patch("yap.record._is_ffmpeg_alive", return_value=True):
        assert is_recording() is True


def test_wait_for_exit_immediate():
    with patch("os.kill", side_effect=ProcessLookupError):
        assert wait_for_exit(99999, timeout=1) is True


def test_wait_for_exit_timeout():
    with patch("os.kill"):  # never raises — process stays alive
        assert wait_for_exit(99999, timeout=0.1) is False


def test_is_ffmpeg_alive_dead():
    with patch("os.kill", side_effect=ProcessLookupError):
        assert _is_ffmpeg_alive(99999) is False


def test_cleanup_audio(tmp_path):
    audio = str(tmp_path / "recording.wav")
    with open(audio, "w") as f:
        f.write("fake")
    with patch("yap.record.AUDIO_PATH", audio):
        cleanup_audio()
        assert not os.path.exists(audio)


def test_cleanup_audio_missing(tmp_path):
    audio = str(tmp_path / "recording.wav")
    with patch("yap.record.AUDIO_PATH", audio):
        cleanup_audio()  # should not raise


def test_stop_recording_timeout():
    proc = MagicMock()
    proc.wait.side_effect = subprocess.TimeoutExpired(cmd="ffmpeg", timeout=10)
    proc.kill.return_value = None
    with patch("yap.record.subprocess", wraps=__import__("subprocess")):
        # stop_recording should kill on timeout and not raise
        stop_recording(proc)
        proc.send_signal.assert_called_once_with(signal.SIGTERM)
        proc.kill.assert_called_once()
```

Also need to import subprocess at top of test file.

**Step 2: Run tests — expect failures for missing functions**

Run: `uv run pytest tests/test_record.py -v`
Expected: FAIL — `cleanup_audio` not defined, `load_and_clear_pid` doesn't handle corrupt, `stop_recording` no timeout

**Step 3: Implement fixes in `record.py`**

Changes:
1. Line 1: Change docstring to `"""Audio recording via ffmpeg (Linux / macOS)."""`
2. Line 19: Change comment `# Linux` to `# Linux / other Unix`
3. Lines 32-35: Add timeout to `stop_recording`:
```python
def stop_recording(proc):
    proc.send_signal(signal.SIGTERM)
    try:
        proc.wait(timeout=10)
    except subprocess.TimeoutExpired:
        proc.kill()
        proc.wait()
    return AUDIO_PATH
```
4. Lines 44-50: Rewrite `load_and_clear_pid` to use `_read_pid`:
```python
def load_and_clear_pid():
    pid = _read_pid()
    if pid is None:
        # Clean up corrupt/empty PID file if it exists
        try:
            os.remove(PID_FILE)
        except FileNotFoundError:
            pass
        return None
    os.remove(PID_FILE)
    return pid
```
5. Lines 53-64: Fix `is_recording` to NOT delete the PID file (let `load_and_clear_pid` handle it):
```python
def is_recording():
    if not os.path.exists(PID_FILE):
        return False
    pid = _read_pid()
    if pid is None or not _is_ffmpeg_alive(pid):
        return False
    return True
```
6. Add `cleanup_audio()` function:
```python
def cleanup_audio():
    try:
        os.remove(AUDIO_PATH)
    except FileNotFoundError:
        pass
```

**Step 4: Run tests — expect pass**

Run: `uv run pytest tests/test_record.py -v`
Expected: All PASS

**Step 5: Commit**

```bash
git add src/yap/record.py tests/test_record.py
git commit -m "fix(record): stop timeout, PID robustness, cleanup helper"
```

---

### Task 2: Rewrite `correct.py` — urllib, error logging, max_tokens

**Files:**
- Modify: `src/yap/correct.py`
- Test: `tests/test_correct.py`

**Step 1: Write tests for all providers and error handling**

Add to `tests/test_correct.py`:

```python
import json
import os
from unittest.mock import patch, MagicMock
from yap.correct import (
    detect_provider, llm_correct,
    _correct_claude_api, _correct_openai, _correct_gemini,
)


def test_detect_openai_key():
    with patch("yap.correct.shutil.which", return_value=None), \
         patch.dict(os.environ, {"OPENAI_API_KEY": "sk-test"}, clear=True):
        assert detect_provider() == "openai"


def test_detect_gemini_key():
    with patch("yap.correct.shutil.which", return_value=None), \
         patch.dict(os.environ, {"GEMINI_API_KEY": "AI-test"}, clear=True):
        assert detect_provider() == "gemini"


def test_detect_override():
    with patch("yap.correct.shutil.which", return_value="/usr/bin/claude"), \
         patch.dict(os.environ, {"ANTHROPIC_API_KEY": "sk"}, clear=True):
        assert detect_provider("openai") == "openai"


# Provider priority: claude-code > claude > openai > gemini
def test_detect_priority():
    with patch("yap.correct.shutil.which", return_value=None), \
         patch.dict(os.environ, {
             "ANTHROPIC_API_KEY": "sk", "OPENAI_API_KEY": "sk",
             "GEMINI_API_KEY": "AI"
         }, clear=True):
        assert detect_provider() == "claude"


def test_llm_correct_exception_returns_original(capsys):
    with patch("yap.correct.detect_provider", return_value="claude"), \
         patch("yap.correct._correct_claude_api", side_effect=RuntimeError("boom")):
        result = llm_correct("hello wrold")
        assert result == "hello wrold"
        captured = capsys.readouterr()
        assert "LLM correction failed" in captured.err


def _mock_urlopen(response_body):
    mock_resp = MagicMock()
    mock_resp.read.return_value = json.dumps(response_body).encode()
    mock_resp.__enter__ = lambda s: s
    mock_resp.__exit__ = MagicMock(return_value=False)
    return mock_resp


def test_correct_claude_api():
    body = {"content": [{"text": "hello world"}]}
    with patch.dict(os.environ, {"ANTHROPIC_API_KEY": "sk-test"}), \
         patch("yap.correct.urlopen", return_value=_mock_urlopen(body)):
        result = _correct_claude_api("hello wrold")
        assert result == "hello world"


def test_correct_openai():
    body = {"choices": [{"message": {"content": "hello world"}}]}
    with patch.dict(os.environ, {"OPENAI_API_KEY": "sk-test"}), \
         patch("yap.correct.urlopen", return_value=_mock_urlopen(body)):
        result = _correct_openai("hello wrold")
        assert result == "hello world"


def test_correct_gemini():
    body = {"candidates": [{"content": {"parts": [{"text": "hello world"}]}}]}
    with patch.dict(os.environ, {"GEMINI_API_KEY": "AI-test"}), \
         patch("yap.correct.urlopen", return_value=_mock_urlopen(body)):
        result = _correct_gemini("hello wrold")
        assert result == "hello world"
```

**Step 2: Run tests — expect failures**

Run: `uv run pytest tests/test_correct.py -v`
Expected: FAIL — `urlopen` not importable from `yap.correct`, error not printed

**Step 3: Rewrite `correct.py`**

Replace the entire file:

```python
"""LLM-based transcription correction."""

import json
import os
import shutil
import subprocess
import sys
from urllib.request import Request, urlopen

PROMPT = (
    "Fix any speech-to-text transcription errors in the following text. "
    "Fix grammar, punctuation, and misheard words. "
    "Do not rephrase or change the meaning. "
    "Return only the corrected text, nothing else."
)

# Provider priority: claude-code CLI > ANTHROPIC_API_KEY > OPENAI_API_KEY > GEMINI_API_KEY
# Override with YAP_LLM=claude-code|claude|openai|gemini


def detect_provider(override=None):
    if override:
        return override
    if shutil.which("claude"):
        return "claude-code"
    if os.environ.get("ANTHROPIC_API_KEY"):
        return "claude"
    if os.environ.get("OPENAI_API_KEY"):
        return "openai"
    if os.environ.get("GEMINI_API_KEY"):
        return "gemini"
    return None


def llm_correct(text, provider_override=None):
    provider = detect_provider(provider_override)
    if not provider:
        return text

    try:
        if provider == "claude-code":
            return _correct_claude_code(text)
        elif provider == "claude":
            return _correct_claude_api(text)
        elif provider == "openai":
            return _correct_openai(text)
        elif provider == "gemini":
            return _correct_gemini(text)
    except Exception as e:
        print(f"LLM correction failed ({provider}): {e}", file=sys.stderr)
        return text
    return text


def _correct_claude_code(text):
    result = subprocess.run(
        ["claude", "-p", "--model", "haiku",
         "--no-session-persistence", "--tools", "",
         "--system-prompt", PROMPT],
        input=text, capture_output=True, text=True, timeout=30,
    )
    return result.stdout.strip() or text


def _api_request(url, headers, payload):
    data = json.dumps(payload).encode()
    req = Request(url, data=data, headers=headers, method="POST")
    with urlopen(req, timeout=30) as resp:
        return json.loads(resp.read())


def _correct_claude_api(text):
    r = _api_request(
        "https://api.anthropic.com/v1/messages",
        {
            "x-api-key": os.environ["ANTHROPIC_API_KEY"],
            "anthropic-version": "2023-06-01",
            "content-type": "application/json",
        },
        {
            "model": "claude-haiku-4-5-20251001",
            "max_tokens": 4096,
            "messages": [{"role": "user", "content": f"{PROMPT}\n\n{text}"}],
        },
    )
    return r["content"][0]["text"]


def _correct_openai(text):
    r = _api_request(
        "https://api.openai.com/v1/chat/completions",
        {
            "Authorization": f"Bearer {os.environ['OPENAI_API_KEY']}",
            "Content-Type": "application/json",
        },
        {
            "model": "gpt-4o-mini",
            "messages": [{"role": "user", "content": f"{PROMPT}\n\n{text}"}],
        },
    )
    return r["choices"][0]["message"]["content"]


def _correct_gemini(text):
    key = os.environ["GEMINI_API_KEY"]
    r = _api_request(
        f"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key={key}",
        {"Content-Type": "application/json"},
        {"contents": [{"parts": [{"text": f"{PROMPT}\n\n{text}"}]}]},
    )
    return r["candidates"][0]["content"]["parts"][0]["text"]
```

**Step 4: Run tests**

Run: `uv run pytest tests/test_correct.py -v`
Expected: All PASS

**Step 5: Commit**

```bash
git add src/yap/correct.py tests/test_correct.py
git commit -m "fix(correct): replace curl with urllib, log errors, bump max_tokens"
```

---

### Task 3: Fix `output.py` — wl-copy, type_text return, AppleScript escaping in notify

**Files:**
- Modify: `src/yap/output.py`
- Test: `tests/test_output.py`

**Step 1: Write tests**

Add to `tests/test_output.py`:

```python
from yap.output import type_text, copy_to_clipboard, notify, _escape_applescript


def test_type_text_wtype():
    with patch("yap.output.platform.system", return_value="Linux"), \
         patch("yap.output.shutil.which", side_effect=lambda x: "/usr/bin/wtype" if x == "wtype" else None), \
         patch("yap.output.subprocess.run") as mock_run:
        result = type_text("hello")
        mock_run.assert_called_once_with(["wtype", "hello"], check=True)
        assert result is True


def test_type_text_no_tool():
    with patch("yap.output.platform.system", return_value="Linux"), \
         patch("yap.output.shutil.which", return_value=None):
        result = type_text("hello")
        assert result is False


def test_type_text_xdotool_returns_true():
    with patch("yap.output.platform.system", return_value="Linux"), \
         patch("yap.output.shutil.which", return_value="/usr/bin/xdotool"), \
         patch("yap.output.subprocess.run"):
        result = type_text("hello")
        assert result is True


def test_clipboard_linux_wl_copy():
    with patch("yap.output.platform.system", return_value="Linux"), \
         patch("yap.output.shutil.which", side_effect=lambda x: "/usr/bin/wl-copy" if x == "wl-copy" else None), \
         patch("yap.output.subprocess.run") as mock_run:
        copy_to_clipboard("hello")
        mock_run.assert_called_once()
        cmd = mock_run.call_args[0][0]
        assert "wl-copy" in cmd


def test_escape_applescript():
    assert _escape_applescript('he said "hi"') == 'he said \\"hi\\"'
    assert _escape_applescript("back\\slash") == "back\\\\slash"


def test_notify_escapes_applescript():
    with patch("yap.output.platform.system", return_value="Darwin"), \
         patch("yap.output.subprocess.run") as mock_run:
        notify('Title "quoted"', 'Body "quoted"')
        script = mock_run.call_args[0][0][2]
        assert '\\"' in script
```

**Step 2: Run tests — expect failures**

Run: `uv run pytest tests/test_output.py -v`
Expected: FAIL — `type_text` returns None, `wl-copy` not handled, notify doesn't escape

**Step 3: Implement fixes in `output.py`**

```python
"""Text output: type into window or copy to clipboard (Linux / macOS)."""

import platform
import shutil
import subprocess
import time


def type_text(text):
    """Type text into the active window. Returns True on success, False if no tool found."""
    system = platform.system()
    if system == "Darwin":
        script = f'tell application "System Events" to keystroke "{_escape_applescript(text)}"'
        subprocess.run(["osascript", "-e", script], check=True)
        return True
    elif shutil.which("xdotool"):
        time.sleep(0.2)
        subprocess.run(["xdotool", "type", "--delay", "10", text], check=True)
        return True
    elif shutil.which("wtype"):
        subprocess.run(["wtype", text], check=True)
        return True
    return False


def copy_to_clipboard(text):
    system = platform.system()
    if system == "Darwin":
        subprocess.run(["pbcopy"], input=text.encode(), check=True)
    elif shutil.which("wl-copy"):
        subprocess.run(["wl-copy", text], check=True)
    else:
        subprocess.run(
            ["xclip", "-selection", "clipboard"],
            input=text.encode(), check=True,
        )


def notify(title, body=""):
    system = platform.system()
    try:
        if system == "Darwin":
            safe_title = _escape_applescript(title)
            safe_body = _escape_applescript(body)
            script = f'display notification "{safe_body}" with title "{safe_title}"'
            subprocess.run(["osascript", "-e", script],
                           capture_output=True, timeout=5)
        else:
            subprocess.run(["notify-send", "-a", "yap", title, body],
                           capture_output=True, timeout=5)
    except (subprocess.TimeoutExpired, FileNotFoundError):
        pass


def _escape_applescript(text):
    return text.replace("\\", "\\\\").replace('"', '\\"')
```

**Step 4: Run tests**

Run: `uv run pytest tests/test_output.py -v`
Expected: All PASS

**Step 5: Commit**

```bash
git add src/yap/output.py tests/test_output.py
git commit -m "fix(output): wl-copy support, type_text return value, escape notify args"
```

---

### Task 4: Fix `cli.py` — use cleanup_audio, handle type_text fallback, nonzero exit codes

**Files:**
- Modify: `src/yap/cli.py`
- Test: `tests/test_cli.py`

**Step 1: Write tests for main() flow**

Add to `tests/test_cli.py`:

```python
import os
from unittest.mock import patch, MagicMock


def test_main_interactive_no_speech():
    with patch("yap.cli.build_parser") as mock_bp, \
         patch("yap.cli.start_recording", return_value=MagicMock()), \
         patch("yap.cli.stop_recording"), \
         patch("yap.cli.transcribe", return_value=""), \
         patch("yap.cli.cleanup_audio"), \
         patch("builtins.input"):
        mock_bp.return_value.parse_args.return_value = MagicMock(
            clipboard=False, llm=False, toggle=False, model=None, lang=None)
        from yap.cli import main
        assert main() == 1


def test_main_interactive_with_text():
    with patch("yap.cli.build_parser") as mock_bp, \
         patch("yap.cli.start_recording", return_value=MagicMock()), \
         patch("yap.cli.stop_recording"), \
         patch("yap.cli.transcribe", return_value="hello world"), \
         patch("yap.cli.cleanup_audio"), \
         patch("yap.cli.type_text", return_value=True), \
         patch("builtins.input"), \
         patch("builtins.print"):
        mock_bp.return_value.parse_args.return_value = MagicMock(
            clipboard=False, llm=False, toggle=False, model=None, lang=None)
        from yap.cli import main
        assert main() == 0


def test_main_type_text_fallback():
    with patch("yap.cli.build_parser") as mock_bp, \
         patch("yap.cli.start_recording", return_value=MagicMock()), \
         patch("yap.cli.stop_recording"), \
         patch("yap.cli.transcribe", return_value="hello"), \
         patch("yap.cli.cleanup_audio"), \
         patch("yap.cli.type_text", return_value=False), \
         patch("yap.cli.copy_to_clipboard"), \
         patch("builtins.input"), \
         patch("builtins.print") as mock_print:
        mock_bp.return_value.parse_args.return_value = MagicMock(
            clipboard=False, llm=False, toggle=False, model=None, lang=None)
        from yap.cli import main
        result = main()
        assert result == 0
        # Should have printed fallback message
        calls = [str(c) for c in mock_print.call_args_list]
        assert any("clipboard" in c.lower() for c in calls)
```

**Step 2: Run tests — expect failures**

Run: `uv run pytest tests/test_cli.py -v`
Expected: FAIL — `cleanup_audio` not imported, exit codes wrong

**Step 3: Implement cli.py changes**

Update imports:
```python
from yap.record import (
    start_recording, stop_recording, save_pid,
    load_and_clear_pid, is_recording, wait_for_exit, cleanup_audio,
)
```

Remove `AUDIO_PATH` from the import.

Add import of `AUDIO_PATH` only where needed for `transcribe()` call (it's still used there). Actually, `transcribe` takes a path — keep importing `AUDIO_PATH` but use `cleanup_audio()` instead of inline `os.remove`.

Updated `main()`:
- Replace `os.remove(AUDIO_PATH)` block (lines 74-77) with `cleanup_audio()`
- Return `1` instead of `0` on "No speech detected" (line 85)
- Handle `type_text` return value — if False, fall back to clipboard with message:
```python
    if args.clipboard:
        copy_to_clipboard(text)
        if not args.toggle:
            print("(copied to clipboard)")
    else:
        if not type_text(text):
            copy_to_clipboard(text)
            if not args.toggle:
                print("(no typing tool found — copied to clipboard)")
```

**Step 4: Run tests**

Run: `uv run pytest tests/test_cli.py -v`
Expected: All PASS

**Step 5: Commit**

```bash
git add src/yap/cli.py tests/test_cli.py
git commit -m "fix(cli): cleanup_audio, type_text fallback, nonzero exit on no speech"
```

---

### Task 5: Add test infrastructure — conftest.py, remaining test gaps

**Files:**
- Create: `tests/conftest.py`
- Modify: `tests/test_transcribe.py`

**Step 1: Create conftest.py with cache cleanup fixture**

```python
import pytest
from yap.transcribe import _model_cache


@pytest.fixture(autouse=True)
def clear_model_cache():
    _model_cache.clear()
    yield
    _model_cache.clear()
```

**Step 2: Update test_transcribe.py — remove manual cache clearing, add tests**

```python
from unittest.mock import patch, MagicMock
from yap.transcribe import transcribe, _model_cache


def test_transcribe_returns_text():
    mock_model = MagicMock()
    mock_segment = MagicMock()
    mock_segment.text = "Hello world"
    mock_model.transcribe.return_value = ([mock_segment], None)

    with patch("yap.transcribe.WhisperModel", return_value=mock_model):
        result = transcribe("/tmp/test.wav", model_size="tiny.en")

    assert result == "Hello world"


def test_transcribe_empty_returns_empty():
    mock_model = MagicMock()
    mock_model.transcribe.return_value = ([], None)

    with patch("yap.transcribe.WhisperModel", return_value=mock_model):
        result = transcribe("/tmp/test.wav", model_size="tiny.en")

    assert result == ""


def test_transcribe_multi_segment():
    mock_model = MagicMock()
    seg1 = MagicMock(); seg1.text = " Hello"
    seg2 = MagicMock(); seg2.text = " world"
    mock_model.transcribe.return_value = ([seg1, seg2], None)

    with patch("yap.transcribe.WhisperModel", return_value=mock_model):
        result = transcribe("/tmp/test.wav", model_size="tiny.en")

    assert result == "Hello world"


def test_transcribe_caches_model():
    mock_model = MagicMock()
    mock_model.transcribe.return_value = ([], None)

    with patch("yap.transcribe.WhisperModel", return_value=mock_model) as mock_cls:
        transcribe("/tmp/test.wav", model_size="tiny.en")
        transcribe("/tmp/test.wav", model_size="tiny.en")
        assert mock_cls.call_count == 1


def test_transcribe_passes_language():
    mock_model = MagicMock()
    mock_model.transcribe.return_value = ([], None)

    with patch("yap.transcribe.WhisperModel", return_value=mock_model):
        transcribe("/tmp/test.wav", model_size="tiny.en", language="zh")
        call_kwargs = mock_model.transcribe.call_args[1]
        assert call_kwargs["language"] == "zh"


def test_transcribe_omits_language_when_none():
    mock_model = MagicMock()
    mock_model.transcribe.return_value = ([], None)

    with patch("yap.transcribe.WhisperModel", return_value=mock_model):
        transcribe("/tmp/test.wav", model_size="tiny.en")
        call_kwargs = mock_model.transcribe.call_args[1]
        assert "language" not in call_kwargs
```

**Step 3: Run all tests**

Run: `uv run pytest -v`
Expected: All PASS

**Step 4: Commit**

```bash
git add tests/conftest.py tests/test_transcribe.py
git commit -m "test: conftest cache fixture, transcribe coverage (caching, language, multi-segment)"
```

---

### Task 6: Update README

**Files:**
- Modify: `README.md`

**Step 1: Update install section**

Change `pip install yap-dictation` to `uv pip install yap-dictation` and `pip install .` to `uv pip install .`. Add note that pip also works.

**Step 2: Add env vars to options table**

| Flag / Env Var | Description |
|------|-------------|
| `-c`, `--clipboard` | Copy to clipboard instead of typing |
| `-l`, `--llm` | Correct transcription with an LLM |
| `-t`, `--toggle` | Hotkey mode |
| `--model MODEL` | Whisper model (default: `small.en`, env: `WHISPER_MODEL`) |
| `--lang LANG` | Language code (env: `YAP_LANG`) |
| `YAP_LLM` | Override LLM provider: `claude-code\|claude\|openai\|gemini` |

**Step 3: Update Requirements section**

Add PulseAudio/PipeWire and notify-send:
```markdown
- **Linux:** xdotool or wtype (typing), xclip or wl-copy (clipboard), notify-send (notifications, optional)
- **Linux audio:** PulseAudio or PipeWire with pipewire-pulse
```

**Step 4: Add LLM model names to LLM section**

After the API key block, add:
```markdown
Models used: Claude Haiku 4.5, GPT-4o-mini, Gemini 2.0 Flash.
```

**Step 5: Document fallback**

Add under Usage:
```markdown
If no typing tool is found, yap copies to clipboard as a fallback.
```

**Step 6: Commit**

```bash
git add README.md
git commit -m "docs: env vars, Linux deps, LLM models, install with uv"
```

---

### Task 7: Minor cleanup — __main__.py docstring

**Files:**
- Modify: `src/yap/__main__.py`

**Step 1: Add docstring**

```python
"""Allow running yap as `python -m yap`."""
import sys
from yap.cli import main

sys.exit(main())
```

**Step 2: Commit**

```bash
git add src/yap/__main__.py
git commit -m "chore: add __main__.py docstring"
```

---

### Task 8: Run full test suite and verify

**Step 1: Run all tests**

Run: `uv run pytest -v`
Expected: All tests pass

**Step 2: Run linter**

Run: `uv run ruff check . --fix && uv run ruff format .`

**Step 3: Commit any lint fixes**

```bash
git add -u
git commit -m "style: lint fixes"
```
