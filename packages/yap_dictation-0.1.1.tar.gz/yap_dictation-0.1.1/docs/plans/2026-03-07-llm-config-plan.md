# LLM Config Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Replace auto-detection of LLM providers with explicit `yap config` wizard and config file.

**Architecture:** New `config.py` module handles loading/saving `~/.config/yap/config.json` and running the interactive wizard. `correct.py` loses `detect_provider()` and takes an explicit provider string. `cli.py` adds a `config` subcommand and wires config loading into the `--llm` path.

**Tech Stack:** Python 3.10+, json (stdlib), argparse subparsers

---

### Task 1: Create `config.py` — load, save, wizard

**Files:**
- Create: `src/yap/config.py`
- Create: `tests/test_config.py`

**Step 1: Write tests**

Create `tests/test_config.py`:

```python
import json
import os
import shutil
from unittest.mock import patch
from yap.config import load_config, save_config, run_config_wizard, CONFIG_PATH


def test_load_config_missing(tmp_path):
    path = str(tmp_path / "config.json")
    with patch("yap.config.CONFIG_PATH", path):
        assert load_config() == {}


def test_save_and_load_config(tmp_path):
    path = str(tmp_path / "config.json")
    with patch("yap.config.CONFIG_PATH", path):
        save_config({"llm_provider": "openai"})
        assert load_config() == {"llm_provider": "openai"}


def test_save_config_creates_dir(tmp_path):
    path = str(tmp_path / "subdir" / "config.json")
    with patch("yap.config.CONFIG_PATH", path):
        save_config({"llm_provider": "gemini"})
        assert os.path.exists(path)


def test_wizard_claude_code(tmp_path):
    path = str(tmp_path / "config.json")
    with (
        patch("yap.config.CONFIG_PATH", path),
        patch("builtins.input", return_value="1"),
        patch("yap.config.shutil.which", return_value="/usr/bin/claude"),
    ):
        run_config_wizard()
        cfg = load_config()
        assert cfg["llm_provider"] == "claude-code"


def test_wizard_openai_with_key(tmp_path):
    path = str(tmp_path / "config.json")
    with (
        patch("yap.config.CONFIG_PATH", path),
        patch("builtins.input", return_value="3"),
        patch.dict(os.environ, {"OPENAI_API_KEY": "sk-test"}),
    ):
        run_config_wizard()
        cfg = load_config()
        assert cfg["llm_provider"] == "openai"


def test_wizard_openai_without_key(tmp_path, capsys):
    path = str(tmp_path / "config.json")
    with (
        patch("yap.config.CONFIG_PATH", path),
        patch("builtins.input", return_value="3"),
        patch.dict(os.environ, {}, clear=True),
    ):
        run_config_wizard()
        cfg = load_config()
        assert cfg["llm_provider"] == "openai"
        captured = capsys.readouterr()
        assert "OPENAI_API_KEY" in captured.out


def test_wizard_invalid_then_valid(tmp_path):
    path = str(tmp_path / "config.json")
    with (
        patch("yap.config.CONFIG_PATH", path),
        patch("builtins.input", side_effect=["9", "abc", "2"]),
        patch.dict(os.environ, {"ANTHROPIC_API_KEY": "sk"}, clear=True),
    ):
        run_config_wizard()
        cfg = load_config()
        assert cfg["llm_provider"] == "claude"
```

**Step 2: Run tests — expect failure**

Run: `uv run pytest tests/test_config.py -v`
Expected: FAIL — module not found

**Step 3: Implement `src/yap/config.py`**

```python
"""Configuration management for yap."""

import json
import os
import shutil

CONFIG_DIR = os.path.join(os.environ.get("XDG_CONFIG_HOME", os.path.expanduser("~/.config")), "yap")
CONFIG_PATH = os.path.join(CONFIG_DIR, "config.json")

PROVIDERS = [
    ("claude-code", "Claude Code CLI", "claude", None),
    ("claude", "Anthropic API", None, "ANTHROPIC_API_KEY"),
    ("openai", "OpenAI API", None, "OPENAI_API_KEY"),
    ("gemini", "Google Gemini API", None, "GEMINI_API_KEY"),
]


def load_config():
    try:
        with open(CONFIG_PATH) as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return {}


def save_config(cfg):
    os.makedirs(os.path.dirname(CONFIG_PATH), exist_ok=True)
    with open(CONFIG_PATH, "w") as f:
        json.dump(cfg, f, indent=2)
        f.write("\n")


def run_config_wizard():
    print("\n🔧 yap configuration\n")
    print("Choose an LLM provider for transcription correction:\n")
    for i, (key, label, cli_bin, env_var) in enumerate(PROVIDERS, 1):
        extra = ""
        if cli_bin:
            extra = " (no API key needed)"
        elif env_var:
            extra = f" (requires {env_var})"
        print(f"  {i}) {key:<14} — {label}{extra}")

    print()
    choice = _prompt_choice(len(PROVIDERS))
    key, label, cli_bin, env_var = PROVIDERS[choice - 1]

    # Validate prerequisites
    if cli_bin:
        if shutil.which(cli_bin):
            print(f"\nChecking for '{cli_bin}' CLI... ✅ found")
        else:
            print(f"\n⚠️  '{cli_bin}' CLI not found on PATH. Install it before using --llm.")
    elif env_var:
        if os.environ.get(env_var):
            print(f"\nChecking for {env_var}... ✅ found")
        else:
            print(f"\n⚠️  {env_var} not set. Export it before using --llm.")

    cfg = load_config()
    cfg["llm_provider"] = key
    save_config(cfg)
    print(f"\nSaved to {CONFIG_PATH}")


def _prompt_choice(max_val):
    while True:
        try:
            val = int(input(f"Enter choice [1-{max_val}]: "))
            if 1 <= val <= max_val:
                return val
        except (ValueError, EOFError):
            pass
        print(f"Please enter a number between 1 and {max_val}.")
```

**Step 4: Run tests**

Run: `uv run pytest tests/test_config.py -v`
Expected: All PASS

**Step 5: Commit**

```bash
git add src/yap/config.py tests/test_config.py
git commit -m "feat(config): add config module with load, save, and interactive wizard"
```

---

### Task 2: Simplify `correct.py` — remove detect_provider, take explicit provider

**Files:**
- Modify: `src/yap/correct.py`
- Modify: `tests/test_correct.py`

**Step 1: Rewrite tests**

Replace `tests/test_correct.py` with:

```python
import json
import os
from unittest.mock import patch, MagicMock
from yap.correct import (
    llm_correct,
    _correct_claude_api,
    _correct_openai,
    _correct_gemini,
)


def test_llm_correct_no_provider():
    assert llm_correct("hello wrold", None) == "hello wrold"


def test_llm_correct_unknown_provider():
    assert llm_correct("hello wrold", "unknown") == "hello wrold"


def test_llm_correct_exception_returns_original(capsys):
    with patch("yap.correct._correct_claude_api", side_effect=RuntimeError("boom")):
        result = llm_correct("hello wrold", "claude")
        assert result == "hello wrold"
        captured = capsys.readouterr()
        assert "LLM correction failed" in captured.err


def _mock_urlopen(response_body):
    mock_resp = MagicMock()
    mock_resp.read.return_value = json.dumps(response_body).encode()
    mock_resp.__enter__ = lambda s: s
    mock_resp.__exit__ = MagicMock(return_value=False)
    return mock_resp


def test_correct_claude_api():
    body = {"content": [{"text": "hello world"}]}
    with (
        patch.dict(os.environ, {"ANTHROPIC_API_KEY": "sk-test"}),
        patch("yap.correct.urlopen", return_value=_mock_urlopen(body)),
    ):
        result = _correct_claude_api("hello wrold")
        assert result == "hello world"


def test_correct_openai():
    body = {"choices": [{"message": {"content": "hello world"}}]}
    with (
        patch.dict(os.environ, {"OPENAI_API_KEY": "sk-test"}),
        patch("yap.correct.urlopen", return_value=_mock_urlopen(body)),
    ):
        result = _correct_openai("hello wrold")
        assert result == "hello world"


def test_correct_gemini():
    body = {"candidates": [{"content": {"parts": [{"text": "hello world"}]}}]}
    with (
        patch.dict(os.environ, {"GEMINI_API_KEY": "AI-test"}),
        patch("yap.correct.urlopen", return_value=_mock_urlopen(body)),
    ):
        result = _correct_gemini("hello wrold")
        assert result == "hello world"
```

**Step 2: Rewrite `src/yap/correct.py`**

Remove `detect_provider`, remove `shutil` import, change `llm_correct` to take explicit provider:

```python
"""LLM-based transcription correction."""

import json
import os
import subprocess
import sys
from urllib.request import Request, urlopen

PROMPT = (
    "Fix any speech-to-text transcription errors in the following text. "
    "Fix grammar, punctuation, and misheard words. "
    "Do not rephrase or change the meaning. "
    "Return only the corrected text, nothing else."
)


def llm_correct(text, provider):
    if not provider:
        return text

    try:
        if provider == "claude-code":
            return _correct_claude_code(text)
        elif provider == "claude":
            return _correct_claude_api(text)
        elif provider == "openai":
            return _correct_openai(text)
        elif provider == "gemini":
            return _correct_gemini(text)
    except Exception as e:
        print(f"LLM correction failed ({provider}): {e}", file=sys.stderr)
        return text
    return text


def _correct_claude_code(text):
    result = subprocess.run(
        [
            "claude",
            "-p",
            "--model",
            "haiku",
            "--no-session-persistence",
            "--tools",
            "",
            "--system-prompt",
            PROMPT,
        ],
        input=text,
        capture_output=True,
        text=True,
        timeout=30,
    )
    return result.stdout.strip() or text


def _api_request(url, headers, payload):
    data = json.dumps(payload).encode()
    req = Request(url, data=data, headers=headers, method="POST")
    with urlopen(req, timeout=30) as resp:
        return json.loads(resp.read())


def _correct_claude_api(text):
    r = _api_request(
        "https://api.anthropic.com/v1/messages",
        {
            "x-api-key": os.environ["ANTHROPIC_API_KEY"],
            "anthropic-version": "2023-06-01",
            "content-type": "application/json",
        },
        {
            "model": "claude-haiku-4-5-20251001",
            "max_tokens": 4096,
            "messages": [{"role": "user", "content": f"{PROMPT}\n\n{text}"}],
        },
    )
    return r["content"][0]["text"]


def _correct_openai(text):
    r = _api_request(
        "https://api.openai.com/v1/chat/completions",
        {
            "Authorization": f"Bearer {os.environ['OPENAI_API_KEY']}",
            "Content-Type": "application/json",
        },
        {
            "model": "gpt-4o-mini",
            "messages": [{"role": "user", "content": f"{PROMPT}\n\n{text}"}],
        },
    )
    return r["choices"][0]["message"]["content"]


def _correct_gemini(text):
    key = os.environ["GEMINI_API_KEY"]
    r = _api_request(
        f"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key={key}",
        {"Content-Type": "application/json"},
        {"contents": [{"parts": [{"text": f"{PROMPT}\n\n{text}"}]}]},
    )
    return r["candidates"][0]["content"]["parts"][0]["text"]
```

**Step 3: Run tests**

Run: `uv run pytest tests/test_correct.py -v`
Expected: All PASS

**Step 4: Commit**

```bash
git add src/yap/correct.py tests/test_correct.py
git commit -m "refactor(correct): remove detect_provider, take explicit provider arg"
```

---

### Task 3: Update `cli.py` — add config subcommand, wire config into --llm

**Files:**
- Modify: `src/yap/cli.py`
- Modify: `tests/test_cli.py`

**Step 1: Write new tests**

Add to `tests/test_cli.py`:

```python
def test_main_llm_no_config(capsys):
    """--llm without config should print setup message and skip correction."""
    with (
        patch("yap.cli.build_parser") as mock_bp,
        patch("yap.cli.start_recording", return_value=MagicMock()),
        patch("yap.cli.stop_recording"),
        patch("yap.cli.transcribe", return_value="hello world"),
        patch("yap.cli.cleanup_audio"),
        patch("yap.cli.type_text", return_value=True),
        patch("yap.cli.load_config", return_value={}),
        patch("builtins.input"),
        patch("builtins.print") as mock_print,
    ):
        mock_bp.return_value.parse_args.return_value = MagicMock(
            clipboard=False, llm=True, toggle=False, model=None, lang=None,
            command=None,
        )
        result = main()
        assert result == 0
        calls = [str(c) for c in mock_print.call_args_list]
        assert any("yap config" in c for c in calls)


def test_main_llm_with_config():
    """--llm with config should call llm_correct with the saved provider."""
    with (
        patch("yap.cli.build_parser") as mock_bp,
        patch("yap.cli.start_recording", return_value=MagicMock()),
        patch("yap.cli.stop_recording"),
        patch("yap.cli.transcribe", return_value="hello wrold"),
        patch("yap.cli.cleanup_audio"),
        patch("yap.cli.type_text", return_value=True),
        patch("yap.cli.load_config", return_value={"llm_provider": "openai"}),
        patch("yap.cli.llm_correct", return_value="hello world") as mock_llm,
        patch("builtins.input"),
        patch("builtins.print"),
    ):
        mock_bp.return_value.parse_args.return_value = MagicMock(
            clipboard=False, llm=True, toggle=False, model=None, lang=None,
            command=None,
        )
        main()
        mock_llm.assert_called_once_with("hello wrold", "openai")


def test_config_subcommand():
    """yap config should run the wizard."""
    with (
        patch("yap.cli.build_parser") as mock_bp,
        patch("yap.cli.run_config_wizard") as mock_wizard,
    ):
        mock_bp.return_value.parse_args.return_value = MagicMock(command="config")
        result = main()
        mock_wizard.assert_called_once()
        assert result == 0
```

**Step 2: Update `src/yap/cli.py`**

Key changes:
- Add import: `from yap.config import load_config, run_config_wizard`
- Add `config` subcommand to argparse using subparsers
- In `main()`: handle `config` subcommand first, then wire config into `--llm` path
- Remove `YAP_LLM` env var reference

```python
"""yap CLI entry point."""

import argparse
import os
import signal
import sys

from yap.record import (
    start_recording,
    stop_recording,
    save_pid,
    load_and_clear_pid,
    is_recording,
    wait_for_exit,
    cleanup_audio,
    AUDIO_PATH,
)
from yap.transcribe import transcribe
from yap.correct import llm_correct
from yap.config import load_config, run_config_wizard
from yap.output import type_text, copy_to_clipboard, notify


def build_parser():
    parser = argparse.ArgumentParser(
        prog="yap",
        description="Talk is cheap. Voice dictation for the terminal.",
    )
    parser.add_argument(
        "-c",
        "--clipboard",
        action="store_true",
        help="Copy to clipboard instead of typing",
    )
    parser.add_argument(
        "-l", "--llm", action="store_true", help="Correct transcription with an LLM"
    )
    parser.add_argument(
        "-t",
        "--toggle",
        action="store_true",
        help="Hotkey mode: 1st call starts, 2nd stops and transcribes",
    )
    parser.add_argument(
        "--model",
        default=None,
        help="Whisper model (default: small.en, env: WHISPER_MODEL)",
    )
    parser.add_argument(
        "--lang",
        default=None,
        help="Language code e.g. en, zh, ja (default: en, env: YAP_LANG)",
    )

    subparsers = parser.add_subparsers(dest="command")
    subparsers.add_parser("config", help="Configure LLM provider")

    return parser


def main():
    parser = build_parser()
    args = parser.parse_args()

    # --- Config subcommand ---
    if args.command == "config":
        run_config_wizard()
        return 0

    model = args.model or os.environ.get("WHISPER_MODEL", "small.en")
    lang = args.lang or os.environ.get("YAP_LANG")

    # --- Toggle mode ---
    if args.toggle:
        if is_recording():
            pid = load_and_clear_pid()
            if pid:
                try:
                    os.kill(pid, signal.SIGTERM)
                except ProcessLookupError:
                    pass
                else:
                    wait_for_exit(pid)
            notify("Transcribing...")
        else:
            proc = start_recording()
            save_pid(proc.pid)
            notify("Recording...", "Press hotkey again to stop.")
            return 0

    # --- Interactive mode ---
    else:
        print("🎙️ Recording... Press Enter to stop.")
        proc = start_recording()
        try:
            input()
        except (EOFError, KeyboardInterrupt):
            pass
        stop_recording(proc)
        print("✍️ Transcribing...")

    # --- Transcribe ---
    text = transcribe(AUDIO_PATH, model_size=model, language=lang)

    cleanup_audio()

    if not text:
        msg = "No speech detected."
        if args.toggle:
            notify(msg)
        else:
            print(msg)
        return 1

    # --- LLM correction ---
    if args.llm:
        cfg = load_config()
        provider = cfg.get("llm_provider")
        if not provider:
            if not args.toggle:
                print("No LLM provider configured. Run 'yap config' to set one up.")
        else:
            if not args.toggle:
                print("🔧 Correcting...")
            text = llm_correct(text, provider)

    # --- Output ---
    if args.toggle:
        notify("Done", text)
    else:
        print(text)

    if args.clipboard:
        copy_to_clipboard(text)
        if not args.toggle:
            print("(copied to clipboard)")
    else:
        if not type_text(text):
            copy_to_clipboard(text)
            if not args.toggle:
                print("(no typing tool found — copied to clipboard)")

    return 0


if __name__ == "__main__":
    sys.exit(main())
```

**Step 3: Run tests**

Run: `uv run pytest tests/test_cli.py -v`
Expected: All PASS

**Step 4: Run full suite**

Run: `uv run pytest -v`
Expected: All PASS

**Step 5: Commit**

```bash
git add src/yap/cli.py tests/test_cli.py
git commit -m "feat(cli): add yap config subcommand, wire config into --llm"
```

---

### Task 4: Update README and cleanup

**Files:**
- Modify: `README.md`

**Step 1: Update LLM section**

Replace the LLM correction section with:

```markdown
## LLM correction (optional)

Use `--llm` to send transcription through an LLM for grammar, punctuation, and misheard word fixes.

### Setup

Run `yap config` to choose your provider:

```bash
yap config
```

Available providers:

| Provider | Requires |
|----------|----------|
| `claude-code` | [Claude Code](https://claude.com/claude-code) CLI installed |
| `claude` | `ANTHROPIC_API_KEY` env var |
| `openai` | `OPENAI_API_KEY` env var |
| `gemini` | `GEMINI_API_KEY` env var |

Models used: Claude Haiku 4.5, GPT-4o-mini, Gemini 2.0 Flash.

Configuration is saved to `~/.config/yap/config.json`.
```

Remove the `YAP_LLM` row from the options table.

**Step 2: Commit**

```bash
git add README.md
git commit -m "docs: update README for yap config workflow"
```

---

### Task 5: Run full test suite and lint

**Step 1: Run all tests**

Run: `uv run pytest -v`
Expected: All PASS

**Step 2: Run linter**

Run: `uv run ruff check . --fix && uv run ruff format .`

**Step 3: Commit any fixes**

```bash
git add -u
git commit -m "style: lint fixes"
```
