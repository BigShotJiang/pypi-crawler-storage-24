from enum import Enum

class RequestFileFormat(Enum):
    CSV="csv"
    PARQUET="parquet"
