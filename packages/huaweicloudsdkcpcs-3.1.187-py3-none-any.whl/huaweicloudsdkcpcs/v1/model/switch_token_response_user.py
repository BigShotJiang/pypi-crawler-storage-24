# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class SwitchTokenResponseUser:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'domain': 'SwitchTokenResponseUserDomain',
        'name': 'str',
        'id': 'str'
    }

    attribute_map = {
        'domain': 'domain',
        'name': 'name',
        'id': 'id'
    }

    def __init__(self, domain=None, name=None, id=None):
        r"""SwitchTokenResponseUser

        The model defined in huaweicloud sdk

        :param domain: 
        :type domain: :class:`huaweicloudsdkcpcs.v1.SwitchTokenResponseUserDomain`
        :param name: 用户名称
        :type name: str
        :param id: 用户id
        :type id: str
        """
        
        

        self._domain = None
        self._name = None
        self._id = None
        self.discriminator = None

        if domain is not None:
            self.domain = domain
        if name is not None:
            self.name = name
        if id is not None:
            self.id = id

    @property
    def domain(self):
        r"""Gets the domain of this SwitchTokenResponseUser.

        :return: The domain of this SwitchTokenResponseUser.
        :rtype: :class:`huaweicloudsdkcpcs.v1.SwitchTokenResponseUserDomain`
        """
        return self._domain

    @domain.setter
    def domain(self, domain):
        r"""Sets the domain of this SwitchTokenResponseUser.

        :param domain: The domain of this SwitchTokenResponseUser.
        :type domain: :class:`huaweicloudsdkcpcs.v1.SwitchTokenResponseUserDomain`
        """
        self._domain = domain

    @property
    def name(self):
        r"""Gets the name of this SwitchTokenResponseUser.

        用户名称

        :return: The name of this SwitchTokenResponseUser.
        :rtype: str
        """
        return self._name

    @name.setter
    def name(self, name):
        r"""Sets the name of this SwitchTokenResponseUser.

        用户名称

        :param name: The name of this SwitchTokenResponseUser.
        :type name: str
        """
        self._name = name

    @property
    def id(self):
        r"""Gets the id of this SwitchTokenResponseUser.

        用户id

        :return: The id of this SwitchTokenResponseUser.
        :rtype: str
        """
        return self._id

    @id.setter
    def id(self, id):
        r"""Sets the id of this SwitchTokenResponseUser.

        用户id

        :param id: The id of this SwitchTokenResponseUser.
        :type id: str
        """
        self._id = id

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, SwitchTokenResponseUser):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
