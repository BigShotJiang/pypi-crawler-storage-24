# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class CreateAppAccessKeyRequestBody:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'key_name': 'str',
        'access_key': 'str',
        'secret_key': 'str'
    }

    attribute_map = {
        'key_name': 'key_name',
        'access_key': 'access_key',
        'secret_key': 'secret_key'
    }

    def __init__(self, key_name=None, access_key=None, secret_key=None):
        r"""CreateAppAccessKeyRequestBody

        The model defined in huaweicloud sdk

        :param key_name: 访问密钥名称
        :type key_name: str
        :param access_key: 访问密钥ak，默认为空，系统自动生成
        :type access_key: str
        :param secret_key: 访问密钥sk，默认为空，系统自动生成
        :type secret_key: str
        """
        
        

        self._key_name = None
        self._access_key = None
        self._secret_key = None
        self.discriminator = None

        self.key_name = key_name
        if access_key is not None:
            self.access_key = access_key
        if secret_key is not None:
            self.secret_key = secret_key

    @property
    def key_name(self):
        r"""Gets the key_name of this CreateAppAccessKeyRequestBody.

        访问密钥名称

        :return: The key_name of this CreateAppAccessKeyRequestBody.
        :rtype: str
        """
        return self._key_name

    @key_name.setter
    def key_name(self, key_name):
        r"""Sets the key_name of this CreateAppAccessKeyRequestBody.

        访问密钥名称

        :param key_name: The key_name of this CreateAppAccessKeyRequestBody.
        :type key_name: str
        """
        self._key_name = key_name

    @property
    def access_key(self):
        r"""Gets the access_key of this CreateAppAccessKeyRequestBody.

        访问密钥ak，默认为空，系统自动生成

        :return: The access_key of this CreateAppAccessKeyRequestBody.
        :rtype: str
        """
        return self._access_key

    @access_key.setter
    def access_key(self, access_key):
        r"""Sets the access_key of this CreateAppAccessKeyRequestBody.

        访问密钥ak，默认为空，系统自动生成

        :param access_key: The access_key of this CreateAppAccessKeyRequestBody.
        :type access_key: str
        """
        self._access_key = access_key

    @property
    def secret_key(self):
        r"""Gets the secret_key of this CreateAppAccessKeyRequestBody.

        访问密钥sk，默认为空，系统自动生成

        :return: The secret_key of this CreateAppAccessKeyRequestBody.
        :rtype: str
        """
        return self._secret_key

    @secret_key.setter
    def secret_key(self, secret_key):
        r"""Sets the secret_key of this CreateAppAccessKeyRequestBody.

        访问密钥sk，默认为空，系统自动生成

        :param secret_key: The secret_key of this CreateAppAccessKeyRequestBody.
        :type secret_key: str
        """
        self._secret_key = secret_key

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, CreateAppAccessKeyRequestBody):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
