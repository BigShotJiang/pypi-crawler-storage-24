# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class DisAssociateAppsRequestBody:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'cluster_id': 'str',
        'app_ids': 'list[str]'
    }

    attribute_map = {
        'cluster_id': 'cluster_id',
        'app_ids': 'app_ids'
    }

    def __init__(self, cluster_id=None, app_ids=None):
        r"""DisAssociateAppsRequestBody

        The model defined in huaweicloud sdk

        :param cluster_id: 所需要绑定的集群ID
        :type cluster_id: str
        :param app_ids: 所需要解绑的应用ID列表
        :type app_ids: list[str]
        """
        
        

        self._cluster_id = None
        self._app_ids = None
        self.discriminator = None

        self.cluster_id = cluster_id
        self.app_ids = app_ids

    @property
    def cluster_id(self):
        r"""Gets the cluster_id of this DisAssociateAppsRequestBody.

        所需要绑定的集群ID

        :return: The cluster_id of this DisAssociateAppsRequestBody.
        :rtype: str
        """
        return self._cluster_id

    @cluster_id.setter
    def cluster_id(self, cluster_id):
        r"""Sets the cluster_id of this DisAssociateAppsRequestBody.

        所需要绑定的集群ID

        :param cluster_id: The cluster_id of this DisAssociateAppsRequestBody.
        :type cluster_id: str
        """
        self._cluster_id = cluster_id

    @property
    def app_ids(self):
        r"""Gets the app_ids of this DisAssociateAppsRequestBody.

        所需要解绑的应用ID列表

        :return: The app_ids of this DisAssociateAppsRequestBody.
        :rtype: list[str]
        """
        return self._app_ids

    @app_ids.setter
    def app_ids(self, app_ids):
        r"""Sets the app_ids of this DisAssociateAppsRequestBody.

        所需要解绑的应用ID列表

        :param app_ids: The app_ids of this DisAssociateAppsRequestBody.
        :type app_ids: list[str]
        """
        self._app_ids = app_ids

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, DisAssociateAppsRequestBody):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
