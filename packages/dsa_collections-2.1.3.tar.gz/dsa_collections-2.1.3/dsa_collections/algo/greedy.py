"""module for greedy algo"""
