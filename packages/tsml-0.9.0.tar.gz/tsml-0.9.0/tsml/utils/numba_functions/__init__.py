"""Numba utility functions."""
