"""Composable estimator tests."""
