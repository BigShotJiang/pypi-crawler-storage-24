# Privatiser Engine
# Copyright (c) 2025 XionDot (github.com/XionDot)
# MIT License - https://github.com/XionDot/privatiser-engine/blob/main/LICENSE
#
# If you use this in your product, a "Powered by Privatiser" credit is appreciated.
# https://privatiser.net
"""Privatiser — Content anonymizer/pseudonymizer."""

# Import pattern modules to trigger registration
import privatiser.patterns.network
import privatiser.patterns.aws
import privatiser.patterns.secrets
import privatiser.patterns.pii
import privatiser.patterns.identifiers
import privatiser.patterns.cloud

from privatiser.core import Privatiser
from privatiser.patterns import PatternHandler
from privatiser.patterns.identifiers import register_custom

__version__ = "0.1.0"
__all__ = ["Privatiser", "PatternHandler", "register_custom"]
