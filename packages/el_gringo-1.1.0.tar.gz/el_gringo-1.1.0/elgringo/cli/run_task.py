"""
Shared task runner — used by CLI, browse, verify, and coding modules.
"""


async def run_single_task(team, prompt: str, mode: str = "auto", context: str = "", agent: str = None):
    """Run a single task with simplified mode aliases and optional context."""
    _MODE_ALIASES = {"auto": None, "quick": "turbo", "team": "parallel", "deep": "debate", "hybrid": "hybrid"}
    resolved = _MODE_ALIASES.get(mode, mode)
    display_mode = mode if resolved else "auto (smart routing)"
    if agent:
        print(f"\n Running task with agent: {agent} ({display_mode})...\n")
    else:
        print(f"\n Running task with {len(team.agents)} agents ({display_mode})...\n")

    agents_list = [agent] if agent else None
    result = await team.collaborate(prompt, context=context, mode=resolved, agents=agents_list)

    if result.success:
        print(f"✅ Completed in {result.total_time:.2f}s")
        print(f"   Confidence: {result.confidence_score:.0%}")
        print(f"   Agents: {', '.join(result.participating_agents)}")
        print("\n" + "─" * 60)
        print(result.final_answer)
        print("─" * 60)
    else:
        print(f"❌ Failed: {result.final_answer}")

    return result
