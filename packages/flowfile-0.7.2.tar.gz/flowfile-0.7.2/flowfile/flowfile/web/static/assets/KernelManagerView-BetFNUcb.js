import { G as onMounted, q as onUnmounted, r as ref, d as defineComponent, c as createElementBlock, a as createBaseVNode, f as createTextVNode, n as normalizeClass, h as withDirectives, v as vModelText, av as vModelCheckbox, t as toDisplayString, w as withModifiers, e as createCommentVNode, L as computed, o as openBlock, g as _export_sfc, y as createVNode, Y as normalizeStyle, H as Fragment, I as renderList, z as unref, B as createBlock } from "./index-BAmalrlq.js";
import { K as KernelApi } from "./kernel.api-C70jELSB.js";
const POLL_INTERVAL_MS = 5e3;
const MEMORY_POLL_INTERVAL_MS = 3e3;
function useKernelManager() {
  const kernels = ref([]);
  const isLoading = ref(true);
  const errorMessage = ref(null);
  const dockerStatus = ref(null);
  const actionInProgress = ref({});
  const memoryStats = ref({});
  let pollTimer = null;
  let memoryPollTimer = null;
  const checkDockerStatus = async () => {
    dockerStatus.value = await KernelApi.getDockerStatus();
  };
  const loadKernels = async () => {
    try {
      kernels.value = await KernelApi.getAll();
      errorMessage.value = null;
    } catch (error) {
      console.error("Failed to load kernels:", error);
      errorMessage.value = error.message || "Failed to load kernels";
      throw error;
    } finally {
      isLoading.value = false;
    }
  };
  const createKernel = async (config) => {
    const kernel = await KernelApi.create(config);
    await loadKernels();
    return kernel;
  };
  const startKernel = async (kernelId) => {
    actionInProgress.value[kernelId] = true;
    try {
      await KernelApi.start(kernelId);
      await loadKernels();
    } finally {
      actionInProgress.value[kernelId] = false;
    }
  };
  const stopKernel = async (kernelId) => {
    actionInProgress.value[kernelId] = true;
    try {
      await KernelApi.stop(kernelId);
      await loadKernels();
    } finally {
      actionInProgress.value[kernelId] = false;
    }
  };
  const deleteKernel = async (kernelId) => {
    actionInProgress.value[kernelId] = true;
    try {
      await KernelApi.delete(kernelId);
      await loadKernels();
    } finally {
      delete actionInProgress.value[kernelId];
    }
  };
  const isActionInProgress = (kernelId) => {
    return !!actionInProgress.value[kernelId];
  };
  const loadMemoryStats = async () => {
    const running = kernels.value.filter((k) => k.state === "idle" || k.state === "executing");
    const results = {};
    await Promise.all(
      running.map(async (k) => {
        results[k.id] = await KernelApi.getMemoryStats(k.id);
      })
    );
    memoryStats.value = results;
  };
  const startPolling = () => {
    stopPolling();
    pollTimer = setInterval(async () => {
      try {
        kernels.value = await KernelApi.getAll();
      } catch {
      }
    }, POLL_INTERVAL_MS);
    memoryPollTimer = setInterval(loadMemoryStats, MEMORY_POLL_INTERVAL_MS);
  };
  const stopPolling = () => {
    if (pollTimer !== null) {
      clearInterval(pollTimer);
      pollTimer = null;
    }
    if (memoryPollTimer !== null) {
      clearInterval(memoryPollTimer);
      memoryPollTimer = null;
    }
  };
  onMounted(async () => {
    await checkDockerStatus();
    try {
      await loadKernels();
      loadMemoryStats();
    } catch {
    }
    startPolling();
  });
  onUnmounted(() => {
    stopPolling();
  });
  return {
    kernels,
    isLoading,
    errorMessage,
    dockerStatus,
    actionInProgress,
    memoryStats,
    loadKernels,
    createKernel,
    startKernel,
    stopKernel,
    deleteKernel,
    isActionInProgress
  };
}
const _hoisted_1$2 = { class: "card mb-3" };
const _hoisted_2$2 = {
  key: 0,
  class: "card-content"
};
const _hoisted_3$2 = { class: "form-grid" };
const _hoisted_4$2 = { class: "form-field" };
const _hoisted_5$2 = { class: "form-field" };
const _hoisted_6$2 = { class: "form-field" };
const _hoisted_7$2 = { class: "form-grid form-grid--3col" };
const _hoisted_8$2 = { class: "form-field" };
const _hoisted_9$2 = { class: "form-field" };
const _hoisted_10$2 = { class: "form-field" };
const _hoisted_11$2 = { class: "toggle-label" };
const _hoisted_12$2 = { class: "toggle-text" };
const _hoisted_13$2 = { class: "form-actions" };
const _hoisted_14$2 = ["disabled"];
const _sfc_main$3 = /* @__PURE__ */ defineComponent({
  __name: "CreateKernelForm",
  emits: ["create"],
  setup(__props, { emit: __emit }) {
    const emit = __emit;
    const isExpanded = ref(false);
    const isSubmitting = ref(false);
    const packagesInput = ref("");
    const form = ref({
      id: "",
      name: "",
      memory_gb: 4,
      cpu_cores: 2,
      gpu: false
    });
    const isValid = computed(() => {
      return form.value.id.trim() !== "" && form.value.name.trim() !== "";
    });
    const parsePackages = () => {
      if (!packagesInput.value.trim()) return [];
      return packagesInput.value.split(",").map((p) => p.trim()).filter((p) => p.length > 0);
    };
    const handleSubmit = async () => {
      if (!isValid.value || isSubmitting.value) return;
      isSubmitting.value = true;
      try {
        const config = {
          id: form.value.id.trim(),
          name: form.value.name.trim(),
          packages: parsePackages(),
          memory_gb: form.value.memory_gb,
          cpu_cores: form.value.cpu_cores,
          gpu: form.value.gpu
        };
        emit("create", config);
        form.value = { id: "", name: "", memory_gb: 4, cpu_cores: 2, gpu: false };
        packagesInput.value = "";
        isExpanded.value = false;
      } finally {
        isSubmitting.value = false;
      }
    };
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1$2, [
        createBaseVNode("div", {
          class: "card-header",
          style: { "cursor": "pointer" },
          onClick: _cache[0] || (_cache[0] = ($event) => isExpanded.value = !isExpanded.value)
        }, [
          _cache[7] || (_cache[7] = createBaseVNode("h3", { class: "card-title" }, [
            createBaseVNode("i", {
              class: "fa-solid fa-plus",
              style: { "margin-right": "6px" }
            }),
            createTextVNode(" Create New Kernel ")
          ], -1)),
          createBaseVNode("i", {
            class: normalizeClass(isExpanded.value ? "fa-solid fa-chevron-up" : "fa-solid fa-chevron-down"),
            style: { "color": "var(--color-text-muted)" }
          }, null, 2)
        ]),
        isExpanded.value ? (openBlock(), createElementBlock("div", _hoisted_2$2, [
          createBaseVNode("form", {
            class: "form",
            onSubmit: withModifiers(handleSubmit, ["prevent"])
          }, [
            createBaseVNode("div", _hoisted_3$2, [
              createBaseVNode("div", _hoisted_4$2, [
                _cache[8] || (_cache[8] = createBaseVNode("label", {
                  for: "kernel-id",
                  class: "form-label"
                }, "Kernel ID", -1)),
                withDirectives(createBaseVNode("input", {
                  id: "kernel-id",
                  "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => form.value.id = $event),
                  type: "text",
                  class: "form-input",
                  placeholder: "my-kernel",
                  pattern: "[a-zA-Z0-9_-]+",
                  title: "Only letters, numbers, hyphens, and underscores",
                  required: ""
                }, null, 512), [
                  [vModelText, form.value.id]
                ])
              ]),
              createBaseVNode("div", _hoisted_5$2, [
                _cache[9] || (_cache[9] = createBaseVNode("label", {
                  for: "kernel-name",
                  class: "form-label"
                }, "Display Name", -1)),
                withDirectives(createBaseVNode("input", {
                  id: "kernel-name",
                  "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => form.value.name = $event),
                  type: "text",
                  class: "form-input",
                  placeholder: "My Data Science Kernel",
                  required: ""
                }, null, 512), [
                  [vModelText, form.value.name]
                ])
              ])
            ]),
            createBaseVNode("div", _hoisted_6$2, [
              _cache[10] || (_cache[10] = createBaseVNode("label", {
                for: "kernel-packages",
                class: "form-label"
              }, [
                createTextVNode(" Python Packages "),
                createBaseVNode("span", { class: "form-label-hint" }, "(comma-separated)")
              ], -1)),
              withDirectives(createBaseVNode("input", {
                id: "kernel-packages",
                "onUpdate:modelValue": _cache[3] || (_cache[3] = ($event) => packagesInput.value = $event),
                type: "text",
                class: "form-input",
                placeholder: "pandas, scikit-learn, torch"
              }, null, 512), [
                [vModelText, packagesInput.value]
              ])
            ]),
            createBaseVNode("div", _hoisted_7$2, [
              createBaseVNode("div", _hoisted_8$2, [
                _cache[11] || (_cache[11] = createBaseVNode("label", {
                  for: "kernel-memory",
                  class: "form-label"
                }, "Memory (GB)", -1)),
                withDirectives(createBaseVNode("input", {
                  id: "kernel-memory",
                  "onUpdate:modelValue": _cache[4] || (_cache[4] = ($event) => form.value.memory_gb = $event),
                  type: "number",
                  class: "form-input",
                  min: "0.5",
                  max: "64",
                  step: "0.5"
                }, null, 512), [
                  [
                    vModelText,
                    form.value.memory_gb,
                    void 0,
                    { number: true }
                  ]
                ])
              ]),
              createBaseVNode("div", _hoisted_9$2, [
                _cache[12] || (_cache[12] = createBaseVNode("label", {
                  for: "kernel-cpu",
                  class: "form-label"
                }, "CPU Cores", -1)),
                withDirectives(createBaseVNode("input", {
                  id: "kernel-cpu",
                  "onUpdate:modelValue": _cache[5] || (_cache[5] = ($event) => form.value.cpu_cores = $event),
                  type: "number",
                  class: "form-input",
                  min: "0.5",
                  max: "32",
                  step: "0.5"
                }, null, 512), [
                  [
                    vModelText,
                    form.value.cpu_cores,
                    void 0,
                    { number: true }
                  ]
                ])
              ]),
              createBaseVNode("div", _hoisted_10$2, [
                _cache[13] || (_cache[13] = createBaseVNode("label", { class: "form-label" }, "GPU", -1)),
                createBaseVNode("label", _hoisted_11$2, [
                  withDirectives(createBaseVNode("input", {
                    "onUpdate:modelValue": _cache[6] || (_cache[6] = ($event) => form.value.gpu = $event),
                    type: "checkbox",
                    class: "toggle-checkbox"
                  }, null, 512), [
                    [vModelCheckbox, form.value.gpu]
                  ]),
                  createBaseVNode("span", _hoisted_12$2, toDisplayString(form.value.gpu ? "Enabled" : "Disabled"), 1)
                ])
              ])
            ]),
            createBaseVNode("div", _hoisted_13$2, [
              createBaseVNode("button", {
                type: "submit",
                class: "btn btn-primary",
                disabled: !isValid.value || isSubmitting.value
              }, [
                createBaseVNode("i", {
                  class: normalizeClass(isSubmitting.value ? "fa-solid fa-spinner fa-spin" : "fa-solid fa-plus")
                }, null, 2),
                createTextVNode(" " + toDisplayString(isSubmitting.value ? "Creating..." : "Create Kernel"), 1)
              ], 8, _hoisted_14$2)
            ])
          ], 32)
        ])) : createCommentVNode("", true)
      ]);
    };
  }
});
const CreateKernelForm = /* @__PURE__ */ _export_sfc(_sfc_main$3, [["__scopeId", "data-v-51d9380c"]]);
const _sfc_main$2 = /* @__PURE__ */ defineComponent({
  __name: "KernelStatusBadge",
  props: {
    state: {}
  },
  setup(__props) {
    const props = __props;
    const config = computed(() => {
      const map = {
        stopped: { icon: "fa-solid fa-circle-stop", label: "Stopped" },
        starting: { icon: "fa-solid fa-spinner fa-spin", label: "Starting" },
        idle: { icon: "fa-solid fa-circle-check", label: "Ready" },
        executing: { icon: "fa-solid fa-gear fa-spin", label: "Executing" },
        error: { icon: "fa-solid fa-circle-exclamation", label: "Error" }
      };
      return map[props.state] ?? { icon: "fa-solid fa-question", label: props.state };
    });
    const iconClass = computed(() => config.value.icon);
    const label = computed(() => config.value.label);
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("span", {
        class: normalizeClass(["kernel-status-badge", `status-${__props.state}`])
      }, [
        createBaseVNode("i", {
          class: normalizeClass(iconClass.value)
        }, null, 2),
        createTextVNode(" " + toDisplayString(label.value), 1)
      ], 2);
    };
  }
});
const KernelStatusBadge = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["__scopeId", "data-v-29d208d7"]]);
const _hoisted_1$1 = { class: "kernel-card__header" };
const _hoisted_2$1 = { class: "kernel-card__title-row" };
const _hoisted_3$1 = { class: "kernel-card__name" };
const _hoisted_4$1 = { class: "kernel-card__meta" };
const _hoisted_5$1 = { class: "kernel-card__id" };
const _hoisted_6$1 = {
  key: 0,
  class: "kernel-card__version",
  title: "Kernel runtime version"
};
const _hoisted_7$1 = { class: "kernel-card__body" };
const _hoisted_8$1 = { class: "kernel-card__resources" };
const _hoisted_9$1 = {
  class: "kernel-card__resource",
  title: "CPU cores"
};
const _hoisted_10$1 = {
  class: "kernel-card__resource",
  title: "Memory limit"
};
const _hoisted_11$1 = {
  key: 0,
  class: "kernel-card__resource",
  title: "GPU enabled"
};
const _hoisted_12$1 = {
  key: 0,
  class: "kernel-card__memory-bar"
};
const _hoisted_13$1 = { class: "kernel-card__memory-header" };
const _hoisted_14$1 = { class: "kernel-card__memory-track" };
const _hoisted_15$1 = {
  key: 1,
  class: "kernel-card__packages"
};
const _hoisted_16 = ["title"];
const _hoisted_17 = {
  key: 2,
  class: "kernel-card__no-packages"
};
const _hoisted_18 = {
  key: 3,
  class: "kernel-card__error"
};
const _hoisted_19 = { class: "kernel-card__actions" };
const _hoisted_20 = ["disabled"];
const _hoisted_21 = ["disabled"];
const _hoisted_22 = ["disabled"];
const maxPackagesShown = 5;
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "KernelCard",
  props: {
    kernel: {},
    busy: { type: Boolean },
    memoryInfo: {}
  },
  emits: ["start", "stop", "delete"],
  setup(__props) {
    const props = __props;
    const displayedPackages = computed(() => props.kernel.packages.slice(0, maxPackagesShown));
    const formatBytes = (bytes) => {
      const gb = bytes / (1024 * 1024 * 1024);
      return gb >= 1 ? `${gb.toFixed(1)} GB` : `${(bytes / (1024 * 1024)).toFixed(0)} MB`;
    };
    const memoryDisplay = computed(() => {
      if (!props.memoryInfo || props.memoryInfo.limit_bytes === 0) return null;
      const used = formatBytes(props.memoryInfo.used_bytes);
      const limit = formatBytes(props.memoryInfo.limit_bytes);
      return `${used} / ${limit}`;
    });
    const memoryLevel = computed(() => {
      if (!props.memoryInfo) return "normal";
      if (props.memoryInfo.usage_percent >= 95) return "critical";
      if (props.memoryInfo.usage_percent >= 80) return "warning";
      return "normal";
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", {
        class: normalizeClass(["kernel-card", { "kernel-card--error": __props.kernel.state === "error" }])
      }, [
        createBaseVNode("div", _hoisted_1$1, [
          createBaseVNode("div", _hoisted_2$1, [
            createBaseVNode("h4", _hoisted_3$1, toDisplayString(__props.kernel.name), 1),
            createVNode(KernelStatusBadge, {
              state: __props.kernel.state
            }, null, 8, ["state"])
          ]),
          createBaseVNode("div", _hoisted_4$1, [
            createBaseVNode("p", _hoisted_5$1, toDisplayString(__props.kernel.id), 1),
            __props.kernel.kernel_version ? (openBlock(), createElementBlock("span", _hoisted_6$1, " v" + toDisplayString(__props.kernel.kernel_version), 1)) : createCommentVNode("", true)
          ])
        ]),
        createBaseVNode("div", _hoisted_7$1, [
          createBaseVNode("div", _hoisted_8$1, [
            createBaseVNode("span", _hoisted_9$1, [
              _cache[3] || (_cache[3] = createBaseVNode("i", { class: "fa-solid fa-microchip" }, null, -1)),
              createTextVNode(" " + toDisplayString(__props.kernel.cpu_cores) + " CPU ", 1)
            ]),
            createBaseVNode("span", _hoisted_10$1, [
              _cache[4] || (_cache[4] = createBaseVNode("i", { class: "fa-solid fa-memory" }, null, -1)),
              createTextVNode(" " + toDisplayString(__props.kernel.memory_gb) + " GB ", 1)
            ]),
            __props.kernel.gpu ? (openBlock(), createElementBlock("span", _hoisted_11$1, [..._cache[5] || (_cache[5] = [
              createBaseVNode("i", { class: "fa-solid fa-display" }, null, -1),
              createTextVNode(" GPU ", -1)
            ])])) : createCommentVNode("", true)
          ]),
          __props.memoryInfo && __props.memoryInfo.limit_bytes > 0 ? (openBlock(), createElementBlock("div", _hoisted_12$1, [
            createBaseVNode("div", _hoisted_13$1, [
              _cache[6] || (_cache[6] = createBaseVNode("span", { class: "kernel-card__memory-label" }, "Memory", -1)),
              createBaseVNode("span", {
                class: normalizeClass(["kernel-card__memory-value", `memory-level--${memoryLevel.value}`])
              }, toDisplayString(memoryDisplay.value) + " (" + toDisplayString(__props.memoryInfo.usage_percent) + "%) ", 3)
            ]),
            createBaseVNode("div", _hoisted_14$1, [
              createBaseVNode("div", {
                class: normalizeClass(["kernel-card__memory-fill", `memory-level--${memoryLevel.value}`]),
                style: normalizeStyle({ width: `${Math.min(__props.memoryInfo.usage_percent, 100)}%` })
              }, null, 6)
            ])
          ])) : createCommentVNode("", true),
          __props.kernel.packages.length > 0 ? (openBlock(), createElementBlock("div", _hoisted_15$1, [
            (openBlock(true), createElementBlock(Fragment, null, renderList(displayedPackages.value, (pkg) => {
              return openBlock(), createElementBlock("span", {
                key: pkg,
                class: "kernel-card__package-tag"
              }, toDisplayString(pkg), 1);
            }), 128)),
            __props.kernel.packages.length > maxPackagesShown ? (openBlock(), createElementBlock("span", {
              key: 0,
              class: "kernel-card__package-tag kernel-card__package-tag--more",
              title: __props.kernel.packages.slice(maxPackagesShown).join(", ")
            }, " +" + toDisplayString(__props.kernel.packages.length - maxPackagesShown) + " more ", 9, _hoisted_16)) : createCommentVNode("", true)
          ])) : (openBlock(), createElementBlock("div", _hoisted_17, "No extra packages")),
          __props.kernel.state === "error" && __props.kernel.error_message ? (openBlock(), createElementBlock("div", _hoisted_18, [
            _cache[7] || (_cache[7] = createBaseVNode("i", { class: "fa-solid fa-triangle-exclamation" }, null, -1)),
            createBaseVNode("span", null, toDisplayString(__props.kernel.error_message), 1)
          ])) : createCommentVNode("", true)
        ]),
        createBaseVNode("div", _hoisted_19, [
          __props.kernel.state === "stopped" || __props.kernel.state === "error" ? (openBlock(), createElementBlock("button", {
            key: 0,
            class: "btn btn-primary btn-sm",
            disabled: __props.busy,
            onClick: _cache[0] || (_cache[0] = ($event) => _ctx.$emit("start", __props.kernel.id))
          }, [..._cache[8] || (_cache[8] = [
            createBaseVNode("i", { class: "fa-solid fa-play" }, null, -1),
            createTextVNode(" Start ", -1)
          ])], 8, _hoisted_20)) : createCommentVNode("", true),
          __props.kernel.state === "idle" || __props.kernel.state === "executing" ? (openBlock(), createElementBlock("button", {
            key: 1,
            class: "btn btn-secondary btn-sm",
            disabled: __props.busy,
            onClick: _cache[1] || (_cache[1] = ($event) => _ctx.$emit("stop", __props.kernel.id))
          }, [..._cache[9] || (_cache[9] = [
            createBaseVNode("i", { class: "fa-solid fa-stop" }, null, -1),
            createTextVNode(" Stop ", -1)
          ])], 8, _hoisted_21)) : createCommentVNode("", true),
          createBaseVNode("button", {
            class: "btn btn-danger btn-sm",
            disabled: __props.busy || __props.kernel.state === "starting",
            onClick: _cache[2] || (_cache[2] = ($event) => _ctx.$emit("delete", __props.kernel.id, __props.kernel.name))
          }, [..._cache[10] || (_cache[10] = [
            createBaseVNode("i", { class: "fa-solid fa-trash-alt" }, null, -1),
            createTextVNode(" Delete ", -1)
          ])], 8, _hoisted_22)
        ])
      ], 2);
    };
  }
});
const KernelCard = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-1893409f"]]);
const _hoisted_1 = { class: "kernel-manager-container" };
const _hoisted_2 = {
  key: 0,
  class: "status-banner status-banner--error mb-3"
};
const _hoisted_3 = {
  key: 1,
  class: "status-banner status-banner--warning mb-3"
};
const _hoisted_4 = {
  key: 2,
  class: "status-banner status-banner--error mb-3"
};
const _hoisted_5 = { class: "card" };
const _hoisted_6 = { class: "card-header" };
const _hoisted_7 = { class: "card-title" };
const _hoisted_8 = { class: "card-content" };
const _hoisted_9 = {
  key: 0,
  class: "loading-state"
};
const _hoisted_10 = {
  key: 1,
  class: "empty-state"
};
const _hoisted_11 = {
  key: 2,
  class: "kernel-grid"
};
const _hoisted_12 = { class: "modal-content" };
const _hoisted_13 = { class: "modal-actions" };
const _hoisted_14 = ["disabled"];
const _hoisted_15 = {
  key: 0,
  class: "fas fa-spinner fa-spin"
};
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "KernelManagerView",
  setup(__props) {
    const {
      kernels,
      isLoading,
      errorMessage,
      dockerStatus,
      memoryStats,
      createKernel,
      startKernel,
      stopKernel,
      deleteKernel,
      isActionInProgress
    } = useKernelManager();
    const showDeleteModal = ref(false);
    const deleteTarget = ref({ id: "", name: "" });
    const isDeleting = ref(false);
    const handleCreate = async (config) => {
      try {
        await createKernel(config);
        alert(`Kernel "${config.name}" created successfully.`);
      } catch (error) {
        const msg = error.message || "Failed to create kernel.";
        alert(`Error creating kernel: ${msg}`);
      }
    };
    const handleStart = async (kernelId) => {
      try {
        await startKernel(kernelId);
      } catch (error) {
        const msg = error.message || "Failed to start kernel.";
        alert(`Error: ${msg}`);
      }
    };
    const handleStop = async (kernelId) => {
      try {
        await stopKernel(kernelId);
      } catch (error) {
        alert(`Error: ${error.message || "Failed to stop kernel."}`);
      }
    };
    const confirmDelete = (kernelId, kernelName) => {
      deleteTarget.value = { id: kernelId, name: kernelName };
      showDeleteModal.value = true;
    };
    const cancelDelete = () => {
      showDeleteModal.value = false;
      deleteTarget.value = { id: "", name: "" };
    };
    const handleDelete = async () => {
      if (!deleteTarget.value.id) return;
      isDeleting.value = true;
      try {
        const name = deleteTarget.value.name;
        await deleteKernel(deleteTarget.value.id);
        cancelDelete();
        alert(`Kernel "${name}" deleted successfully.`);
      } catch {
        alert("Failed to delete kernel. Please try again.");
        cancelDelete();
      } finally {
        isDeleting.value = false;
      }
    };
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1, [
        _cache[11] || (_cache[11] = createBaseVNode("div", { class: "mb-3" }, [
          createBaseVNode("h2", { class: "page-title" }, "Kernel Manager"),
          createBaseVNode("p", { class: "page-description" }, "Manage Python execution environments for your flows")
        ], -1)),
        unref(dockerStatus) && !unref(dockerStatus).available ? (openBlock(), createElementBlock("div", _hoisted_2, [..._cache[1] || (_cache[1] = [
          createBaseVNode("i", { class: "fa-solid fa-circle-exclamation" }, null, -1),
          createBaseVNode("div", null, [
            createBaseVNode("strong", null, "Docker is not running."),
            createTextVNode(" Kernels require Docker to create and run containers. Please start Docker and reload this page. ")
          ], -1)
        ])])) : unref(dockerStatus) && unref(dockerStatus).available && !unref(dockerStatus).image_available ? (openBlock(), createElementBlock("div", _hoisted_3, [..._cache[2] || (_cache[2] = [
          createBaseVNode("i", { class: "fa-solid fa-triangle-exclamation" }, null, -1),
          createBaseVNode("div", null, [
            createBaseVNode("strong", null, "Kernel image not found."),
            createTextVNode(" The "),
            createBaseVNode("code", null, "flowfile-kernel"),
            createTextVNode(" Docker image is not available. Build or pull the image before starting kernels. ")
          ], -1)
        ])])) : createCommentVNode("", true),
        unref(errorMessage) && (!unref(dockerStatus) || unref(dockerStatus).available) ? (openBlock(), createElementBlock("div", _hoisted_4, [
          _cache[3] || (_cache[3] = createBaseVNode("i", { class: "fa-solid fa-circle-exclamation" }, null, -1)),
          createBaseVNode("span", null, toDisplayString(unref(errorMessage)), 1)
        ])) : createCommentVNode("", true),
        createVNode(CreateKernelForm, { onCreate: handleCreate }),
        createBaseVNode("div", _hoisted_5, [
          createBaseVNode("div", _hoisted_6, [
            createBaseVNode("h3", _hoisted_7, "Your Kernels (" + toDisplayString(unref(kernels).length) + ")", 1)
          ]),
          createBaseVNode("div", _hoisted_8, [
            unref(isLoading) ? (openBlock(), createElementBlock("div", _hoisted_9, [..._cache[4] || (_cache[4] = [
              createBaseVNode("div", { class: "loading-spinner" }, null, -1),
              createBaseVNode("p", null, "Loading kernels...", -1)
            ])])) : unref(kernels).length === 0 && !unref(errorMessage) ? (openBlock(), createElementBlock("div", _hoisted_10, [..._cache[5] || (_cache[5] = [
              createBaseVNode("i", { class: "fa-solid fa-server" }, null, -1),
              createBaseVNode("p", null, "No kernels configured yet", -1),
              createBaseVNode("p", null, "Create a kernel above to start running Python code in your flows", -1)
            ])])) : (openBlock(), createElementBlock("div", _hoisted_11, [
              (openBlock(true), createElementBlock(Fragment, null, renderList(unref(kernels), (kernel) => {
                return openBlock(), createBlock(KernelCard, {
                  key: kernel.id,
                  kernel,
                  busy: unref(isActionInProgress)(kernel.id),
                  "memory-info": unref(memoryStats)[kernel.id] ?? null,
                  onStart: handleStart,
                  onStop: handleStop,
                  onDelete: confirmDelete
                }, null, 8, ["kernel", "busy", "memory-info"]);
              }), 128))
            ]))
          ])
        ]),
        showDeleteModal.value ? (openBlock(), createElementBlock("div", {
          key: 3,
          class: "modal-overlay",
          onClick: cancelDelete
        }, [
          createBaseVNode("div", {
            class: "modal-container",
            onClick: _cache[0] || (_cache[0] = withModifiers(() => {
            }, ["stop"]))
          }, [
            createBaseVNode("div", { class: "modal-header" }, [
              _cache[7] || (_cache[7] = createBaseVNode("h3", { class: "modal-title" }, "Delete Kernel", -1)),
              createBaseVNode("button", {
                class: "modal-close",
                "aria-label": "Close",
                onClick: cancelDelete
              }, [..._cache[6] || (_cache[6] = [
                createBaseVNode("i", { class: "fa-solid fa-times" }, null, -1)
              ])])
            ]),
            createBaseVNode("div", _hoisted_12, [
              createBaseVNode("p", null, [
                _cache[8] || (_cache[8] = createTextVNode(" Are you sure you want to delete the kernel ", -1)),
                createBaseVNode("strong", null, toDisplayString(deleteTarget.value.name), 1),
                _cache[9] || (_cache[9] = createTextVNode("? ", -1))
              ]),
              _cache[10] || (_cache[10] = createBaseVNode("p", { class: "warning-text" }, " This will stop and remove the container. This action cannot be undone. ", -1))
            ]),
            createBaseVNode("div", _hoisted_13, [
              createBaseVNode("button", {
                class: "btn btn-secondary",
                onClick: cancelDelete
              }, "Cancel"),
              createBaseVNode("button", {
                class: "btn btn-danger-filled",
                disabled: isDeleting.value,
                onClick: handleDelete
              }, [
                isDeleting.value ? (openBlock(), createElementBlock("i", _hoisted_15)) : createCommentVNode("", true),
                createTextVNode(" " + toDisplayString(isDeleting.value ? "Deleting..." : "Delete Kernel"), 1)
              ], 8, _hoisted_14)
            ])
          ])
        ])) : createCommentVNode("", true)
      ]);
    };
  }
});
const KernelManagerView = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-9d08ae9e"]]);
export {
  KernelManagerView as default
};
