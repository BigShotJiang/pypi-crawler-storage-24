import { d as defineComponent, l as useNodeStore, G as onMounted, c as createElementBlock, a as createBaseVNode, y as createVNode, A as withCtx, H as Fragment, I as renderList, B as createBlock, t as toDisplayString, e as createCommentVNode, r as ref, L as computed, C as resolveComponent, o as openBlock, g as _export_sfc } from "./index-BAmalrlq.js";
import { u as useNodeSettings } from "./useNodeSettings-CBGAzH1r.js";
import { C as CatalogApi } from "./catalog.api-Ym5X6s3O.js";
const _hoisted_1 = {
  key: 0,
  class: "listbox-wrapper"
};
const _hoisted_2 = { class: "main-part" };
const _hoisted_3 = { class: "catalog-field" };
const _hoisted_4 = { class: "catalog-field" };
const _hoisted_5 = {
  key: 0,
  class: "table-meta"
};
const _hoisted_6 = { class: "meta-row" };
const _hoisted_7 = { class: "meta-value" };
const _hoisted_8 = { class: "meta-row" };
const _hoisted_9 = { class: "meta-value" };
const _hoisted_10 = {
  key: 0,
  class: "schema-preview"
};
const _hoisted_11 = { class: "schema-list" };
const _hoisted_12 = { class: "col-name" };
const _hoisted_13 = { class: "col-type" };
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "CatalogReader",
  setup(__props, { expose: __expose }) {
    const nodeStore = useNodeStore();
    const nodeData = ref(null);
    const dataLoaded = ref(false);
    const { saveSettings, pushNodeData } = useNodeSettings({
      nodeRef: nodeData
    });
    const catalogNamespaces = ref([]);
    const allTables = ref([]);
    const selectedTableMeta = ref(null);
    const filteredTables = computed(() => {
      var _a;
      if (((_a = nodeData.value) == null ? void 0 : _a.catalog_namespace_id) == null) return allTables.value;
      return allTables.value.filter((t) => {
        var _a2;
        return t.namespace_id === ((_a2 = nodeData.value) == null ? void 0 : _a2.catalog_namespace_id);
      });
    });
    function formatNumber(n) {
      if (n === null) return "—";
      return n.toLocaleString();
    }
    function handleNamespaceChange() {
      if (nodeData.value) {
        nodeData.value.catalog_table_id = null;
        nodeData.value.catalog_table_name = null;
      }
      selectedTableMeta.value = null;
    }
    function handleTableChange(tableId) {
      if (!nodeData.value) return;
      const table = allTables.value.find((t) => t.id === tableId);
      if (table) {
        nodeData.value.catalog_table_name = table.name;
        nodeData.value.catalog_namespace_id = table.namespace_id;
        selectedTableMeta.value = table;
      } else {
        nodeData.value.catalog_table_name = null;
        selectedTableMeta.value = null;
      }
    }
    function collectTablesFromTree(nodes) {
      const result = [];
      for (const node of nodes) {
        for (const t of node.tables ?? []) {
          result.push(t);
        }
        result.push(...collectTablesFromTree(node.children ?? []));
      }
      return result;
    }
    let catalogLoadPromise = null;
    async function loadCatalogData() {
      try {
        const tree = await CatalogApi.getNamespaceTree();
        for (const catalog of tree) {
          for (const schema of catalog.children ?? []) {
            catalogNamespaces.value.push({
              id: schema.id,
              label: `${catalog.name} / ${schema.name}`
            });
          }
        }
        allTables.value = collectTablesFromTree(tree);
      } catch {
      }
    }
    onMounted(() => {
      catalogLoadPromise = loadCatalogData();
    });
    async function loadNodeData(nodeId) {
      var _a;
      const nodeResult = await nodeStore.getNodeData(nodeId, false);
      if ((nodeResult == null ? void 0 : nodeResult.setting_input) && nodeResult.setting_input.is_setup) {
        nodeData.value = nodeResult.setting_input;
      } else {
        nodeData.value = {
          catalog_table_id: null,
          catalog_table_name: null,
          catalog_namespace_id: null,
          flow_id: nodeStore.flow_id,
          node_id: nodeId,
          cache_results: false,
          pos_x: 0,
          pos_y: 0,
          is_setup: false,
          description: ""
        };
      }
      dataLoaded.value = true;
      if (catalogLoadPromise) await catalogLoadPromise;
      if ((_a = nodeData.value) == null ? void 0 : _a.catalog_table_id) {
        const table = allTables.value.find((t) => {
          var _a2;
          return t.id === ((_a2 = nodeData.value) == null ? void 0 : _a2.catalog_table_id);
        });
        if (table) {
          selectedTableMeta.value = table;
        }
      }
    }
    __expose({
      loadNodeData,
      pushNodeData,
      saveSettings
    });
    return (_ctx, _cache) => {
      const _component_el_option = resolveComponent("el-option");
      const _component_el_select = resolveComponent("el-select");
      return dataLoaded.value && nodeData.value ? (openBlock(), createElementBlock("div", _hoisted_1, [
        createBaseVNode("div", _hoisted_2, [
          createBaseVNode("div", _hoisted_3, [
            _cache[2] || (_cache[2] = createBaseVNode("label", { class: "catalog-label" }, "Catalog / Schema", -1)),
            createVNode(_component_el_select, {
              modelValue: nodeData.value.catalog_namespace_id,
              "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => nodeData.value.catalog_namespace_id = $event),
              size: "small",
              placeholder: "Select namespace",
              clearable: "",
              onChange: handleNamespaceChange
            }, {
              default: withCtx(() => [
                (openBlock(true), createElementBlock(Fragment, null, renderList(catalogNamespaces.value, (ns) => {
                  return openBlock(), createBlock(_component_el_option, {
                    key: ns.id,
                    label: ns.label,
                    value: ns.id
                  }, null, 8, ["label", "value"]);
                }), 128))
              ]),
              _: 1
            }, 8, ["modelValue"])
          ]),
          createBaseVNode("div", _hoisted_4, [
            _cache[3] || (_cache[3] = createBaseVNode("label", { class: "catalog-label" }, "Table", -1)),
            createVNode(_component_el_select, {
              modelValue: nodeData.value.catalog_table_id,
              "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => nodeData.value.catalog_table_id = $event),
              size: "small",
              placeholder: "Select table",
              filterable: "",
              onChange: handleTableChange
            }, {
              default: withCtx(() => [
                (openBlock(true), createElementBlock(Fragment, null, renderList(filteredTables.value, (table) => {
                  return openBlock(), createBlock(_component_el_option, {
                    key: table.id,
                    label: table.name,
                    value: table.id
                  }, null, 8, ["label", "value"]);
                }), 128))
              ]),
              _: 1
            }, 8, ["modelValue"])
          ]),
          selectedTableMeta.value ? (openBlock(), createElementBlock("div", _hoisted_5, [
            createBaseVNode("div", _hoisted_6, [
              _cache[4] || (_cache[4] = createBaseVNode("span", { class: "meta-label" }, "Rows", -1)),
              createBaseVNode("span", _hoisted_7, toDisplayString(formatNumber(selectedTableMeta.value.row_count)), 1)
            ]),
            createBaseVNode("div", _hoisted_8, [
              _cache[5] || (_cache[5] = createBaseVNode("span", { class: "meta-label" }, "Columns", -1)),
              createBaseVNode("span", _hoisted_9, toDisplayString(selectedTableMeta.value.column_count), 1)
            ]),
            selectedTableMeta.value.schema_columns.length > 0 ? (openBlock(), createElementBlock("div", _hoisted_10, [
              _cache[6] || (_cache[6] = createBaseVNode("label", { class: "catalog-label" }, "Schema", -1)),
              createBaseVNode("div", _hoisted_11, [
                (openBlock(true), createElementBlock(Fragment, null, renderList(selectedTableMeta.value.schema_columns, (col) => {
                  return openBlock(), createElementBlock("div", {
                    key: col.name,
                    class: "schema-col"
                  }, [
                    createBaseVNode("span", _hoisted_12, toDisplayString(col.name), 1),
                    createBaseVNode("span", _hoisted_13, toDisplayString(col.dtype), 1)
                  ]);
                }), 128))
              ])
            ])) : createCommentVNode("", true)
          ])) : createCommentVNode("", true)
        ])
      ])) : createCommentVNode("", true);
    };
  }
});
const CatalogReader = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-ce538588"]]);
export {
  CatalogReader as default
};
