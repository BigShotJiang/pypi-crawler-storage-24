import { d as defineComponent, l as useNodeStore, G as onMounted, c as createElementBlock, a as createBaseVNode, y as createVNode, A as withCtx, H as Fragment, I as renderList, B as createBlock, e as createCommentVNode, r as ref, C as resolveComponent, o as openBlock, g as _export_sfc } from "./index-BAmalrlq.js";
import { u as useNodeSettings } from "./useNodeSettings-CBGAzH1r.js";
import { C as CatalogApi } from "./catalog.api-Ym5X6s3O.js";
const _hoisted_1 = {
  key: 0,
  class: "listbox-wrapper"
};
const _hoisted_2 = { class: "main-part" };
const _hoisted_3 = { class: "catalog-field" };
const _hoisted_4 = { class: "catalog-field" };
const _hoisted_5 = { class: "catalog-field" };
const _hoisted_6 = { class: "catalog-field" };
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "CatalogWriter",
  setup(__props, { expose: __expose }) {
    const nodeStore = useNodeStore();
    const nodeData = ref(null);
    const dataLoaded = ref(false);
    const { saveSettings, pushNodeData } = useNodeSettings({
      nodeRef: nodeData
    });
    const catalogNamespaces = ref([]);
    onMounted(async () => {
      try {
        const tree = await CatalogApi.getNamespaceTree();
        for (const catalog of tree) {
          for (const schema of catalog.children ?? []) {
            catalogNamespaces.value.push({
              id: schema.id,
              label: `${catalog.name} / ${schema.name}`
            });
          }
        }
      } catch {
      }
    });
    async function loadNodeData(nodeId) {
      const nodeResult = await nodeStore.getNodeData(nodeId, false);
      if ((nodeResult == null ? void 0 : nodeResult.setting_input) && nodeResult.setting_input.is_setup) {
        nodeData.value = nodeResult.setting_input;
      } else {
        nodeData.value = {
          catalog_write_settings: {
            table_name: "",
            namespace_id: null,
            description: null,
            write_mode: "overwrite"
          },
          flow_id: nodeStore.flow_id,
          node_id: nodeId,
          cache_results: false,
          pos_x: 0,
          pos_y: 0,
          is_setup: false,
          description: ""
        };
      }
      dataLoaded.value = true;
    }
    __expose({
      loadNodeData,
      pushNodeData,
      saveSettings
    });
    return (_ctx, _cache) => {
      const _component_el_input = resolveComponent("el-input");
      const _component_el_option = resolveComponent("el-option");
      const _component_el_select = resolveComponent("el-select");
      return dataLoaded.value && nodeData.value ? (openBlock(), createElementBlock("div", _hoisted_1, [
        createBaseVNode("div", _hoisted_2, [
          createBaseVNode("div", _hoisted_3, [
            _cache[4] || (_cache[4] = createBaseVNode("label", { class: "catalog-label" }, "Table name", -1)),
            createVNode(_component_el_input, {
              modelValue: nodeData.value.catalog_write_settings.table_name,
              "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => nodeData.value.catalog_write_settings.table_name = $event),
              size: "small",
              placeholder: "Enter table name"
            }, null, 8, ["modelValue"])
          ]),
          createBaseVNode("div", _hoisted_4, [
            _cache[5] || (_cache[5] = createBaseVNode("label", { class: "catalog-label" }, "Catalog / Schema", -1)),
            createVNode(_component_el_select, {
              modelValue: nodeData.value.catalog_write_settings.namespace_id,
              "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => nodeData.value.catalog_write_settings.namespace_id = $event),
              size: "small",
              placeholder: "Select namespace",
              clearable: ""
            }, {
              default: withCtx(() => [
                (openBlock(true), createElementBlock(Fragment, null, renderList(catalogNamespaces.value, (ns) => {
                  return openBlock(), createBlock(_component_el_option, {
                    key: ns.id,
                    label: ns.label,
                    value: ns.id
                  }, null, 8, ["label", "value"]);
                }), 128))
              ]),
              _: 1
            }, 8, ["modelValue"])
          ]),
          createBaseVNode("div", _hoisted_5, [
            _cache[6] || (_cache[6] = createBaseVNode("label", { class: "catalog-label" }, "Write mode", -1)),
            createVNode(_component_el_select, {
              modelValue: nodeData.value.catalog_write_settings.write_mode,
              "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => nodeData.value.catalog_write_settings.write_mode = $event),
              size: "small"
            }, {
              default: withCtx(() => [
                createVNode(_component_el_option, {
                  label: "Overwrite",
                  value: "overwrite"
                }),
                createVNode(_component_el_option, {
                  label: "Error if exists",
                  value: "error"
                })
              ]),
              _: 1
            }, 8, ["modelValue"])
          ]),
          createBaseVNode("div", _hoisted_6, [
            _cache[7] || (_cache[7] = createBaseVNode("label", { class: "catalog-label" }, "Description (optional)", -1)),
            createVNode(_component_el_input, {
              modelValue: nodeData.value.catalog_write_settings.description,
              "onUpdate:modelValue": _cache[3] || (_cache[3] = ($event) => nodeData.value.catalog_write_settings.description = $event),
              size: "small",
              type: "textarea",
              rows: 2,
              placeholder: "Table description"
            }, null, 8, ["modelValue"])
          ])
        ])
      ])) : createCommentVNode("", true);
    };
  }
});
const CatalogWriter = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-922cbc05"]]);
export {
  CatalogWriter as default
};
