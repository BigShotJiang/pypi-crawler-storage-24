import { k as axios } from "./index-BAmalrlq.js";
class CatalogApi {
  // ====== Namespaces ======
  static async getNamespaces(parentId) {
    const params = {};
    if (parentId !== void 0 && parentId !== null) params.parent_id = parentId;
    const response = await axios.get("/catalog/namespaces", { params });
    return response.data;
  }
  static async getNamespaceTree() {
    const response = await axios.get("/catalog/namespaces/tree");
    return response.data;
  }
  static async createNamespace(body) {
    const response = await axios.post("/catalog/namespaces", body);
    return response.data;
  }
  static async updateNamespace(id, body) {
    const response = await axios.put(`/catalog/namespaces/${id}`, body);
    return response.data;
  }
  static async deleteNamespace(id) {
    await axios.delete(`/catalog/namespaces/${id}`);
  }
  // ====== Flow Registrations ======
  static async getFlows(namespaceId) {
    const params = {};
    if (namespaceId !== void 0 && namespaceId !== null) params.namespace_id = namespaceId;
    const response = await axios.get("/catalog/flows", { params });
    return response.data;
  }
  static async getFlow(id) {
    const response = await axios.get(`/catalog/flows/${id}`);
    return response.data;
  }
  static async registerFlow(body) {
    const response = await axios.post("/catalog/flows", body);
    return response.data;
  }
  static async updateFlow(id, body) {
    const response = await axios.put(`/catalog/flows/${id}`, body);
    return response.data;
  }
  static async deleteFlow(id) {
    await axios.delete(`/catalog/flows/${id}`);
  }
  // ====== Favorites ======
  static async getFavorites() {
    const response = await axios.get("/catalog/favorites");
    return response.data;
  }
  static async addFavorite(flowId) {
    await axios.post(`/catalog/flows/${flowId}/favorite`);
  }
  static async removeFavorite(flowId) {
    await axios.delete(`/catalog/flows/${flowId}/favorite`);
  }
  // ====== Follows ======
  static async getFollowing() {
    const response = await axios.get("/catalog/following");
    return response.data;
  }
  static async addFollow(flowId) {
    await axios.post(`/catalog/flows/${flowId}/follow`);
  }
  static async removeFollow(flowId) {
    await axios.delete(`/catalog/flows/${flowId}/follow`);
  }
  // ====== Runs ======
  static async getRuns(registrationId, limit = 50, offset = 0) {
    const params = { limit, offset };
    if (registrationId !== void 0 && registrationId !== null)
      params.registration_id = registrationId;
    const response = await axios.get("/catalog/runs", { params });
    return response.data;
  }
  static async getRunDetail(runId) {
    const response = await axios.get(`/catalog/runs/${runId}`);
    return response.data;
  }
  // ====== Default Namespace ======
  static async getDefaultNamespaceId() {
    const response = await axios.get("/catalog/default-namespace-id");
    return response.data;
  }
  // ====== Open Snapshot ======
  static async openRunSnapshot(runId) {
    const response = await axios.post(`/catalog/runs/${runId}/open`);
    return response.data.flow_id;
  }
  // ====== Artifacts ======
  /** List active artifacts produced by a specific registered flow. */
  static async getFlowArtifacts(registrationId) {
    const response = await axios.get(
      `/catalog/flows/${registrationId}/artifacts`
    );
    return response.data;
  }
  // ====== Table Favorites ======
  static async getTableFavorites() {
    const response = await axios.get("/catalog/table-favorites");
    return response.data;
  }
  static async addTableFavorite(tableId) {
    await axios.post(`/catalog/tables/${tableId}/favorite`);
  }
  static async removeTableFavorite(tableId) {
    await axios.delete(`/catalog/tables/${tableId}/favorite`);
  }
  // ====== Catalog Tables ======
  static async getTables(namespaceId) {
    const params = {};
    if (namespaceId !== void 0 && namespaceId !== null) params.namespace_id = namespaceId;
    const response = await axios.get("/catalog/tables", { params });
    return response.data;
  }
  static async getTable(tableId) {
    const response = await axios.get(`/catalog/tables/${tableId}`);
    return response.data;
  }
  static async registerTable(body) {
    const response = await axios.post("/catalog/tables", body);
    return response.data;
  }
  static async updateTable(id, body) {
    const response = await axios.put(`/catalog/tables/${id}`, body);
    return response.data;
  }
  static async deleteTable(id) {
    await axios.delete(`/catalog/tables/${id}`);
  }
  static async getTablePreview(tableId, limit = 100) {
    const url = `/catalog/tables/${tableId}/preview`;
    const response = await axios.get(url, { params: { limit } });
    return response.data;
  }
  // ====== Stats ======
  static async getStats() {
    const response = await axios.get("/catalog/stats");
    return response.data;
  }
}
export {
  CatalogApi as C
};
