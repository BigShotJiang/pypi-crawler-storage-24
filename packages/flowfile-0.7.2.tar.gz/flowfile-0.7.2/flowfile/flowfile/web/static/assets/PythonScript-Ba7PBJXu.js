import { C as CodeLoader } from "./vue-content-loader.es-DOReMSGi.js";
import { P as Position } from "./DesignerView-DyW2xFZq.js";
import { d as defineComponent, l as useNodeStore, m as useEditorStore, aj as useFlowStore, D as watch, q as onUnmounted, c as createElementBlock, y as createVNode, A as withCtx, a as createBaseVNode, H as Fragment, I as renderList, B as createBlock, n as normalizeClass, t as toDisplayString, f as createTextVNode, e as createCommentVNode, z as unref, r as ref, L as computed, F as FlowApi, C as resolveComponent, o as openBlock, g as _export_sfc } from "./index-BAmalrlq.js";
import { u as useNodeSettings } from "./useNodeSettings-CBGAzH1r.js";
import { K as KernelApi } from "./kernel.api-C70jELSB.js";
import { G as GenericNodeSettings } from "./genericNodeSettings-skGXb6PV.js";
import FlowfileApiHelp from "./FlowfileApiHelp-BmA0PPeQ.js";
import NotebookEditor from "./NotebookEditor-BnOE-q6G.js";
import "./fileBrowser-B9lrIIDi.js";
import "./PopOver-C3KnJRsl.js";
import "./index-DgPd_2U1.js";
import "./vue-codemirror.esm-DfAEZG05.js";
import "./NotebookCell-DMBvrxOz.js";
import "./CellOutput-CK2tu127.js";
const DEFAULT_PYTHON_SCRIPT_CODE = `import polars as pl

df = flowfile.read_input()

# Your transformation here

flowfile.publish_output(df)
`;
const createPythonScriptNode = (flowId, nodeId) => {
  const pythonScriptInput = {
    code: DEFAULT_PYTHON_SCRIPT_CODE,
    kernel_id: null,
    cells: [{ id: crypto.randomUUID(), code: DEFAULT_PYTHON_SCRIPT_CODE }]
  };
  return {
    flow_id: flowId,
    node_id: nodeId,
    pos_x: 0,
    pos_y: 0,
    depending_on_ids: null,
    python_script_input: pythonScriptInput,
    cache_results: false,
    output_names: ["main"]
  };
};
const _hoisted_1 = {
  key: 0,
  class: "listbox-wrapper"
};
const _hoisted_2 = { class: "python-script-settings" };
const _hoisted_3 = { class: "setting-block" };
const _hoisted_4 = { class: "kernel-row" };
const _hoisted_5 = { class: "kernel-option" };
const _hoisted_6 = { class: "kernel-state-label" };
const _hoisted_7 = { class: "kernel-memory__text" };
const _hoisted_8 = { class: "kernel-memory__percent" };
const _hoisted_9 = {
  key: 1,
  class: "kernel-warning"
};
const _hoisted_10 = {
  key: 2,
  class: "kernel-warning"
};
const _hoisted_11 = {
  key: 0,
  class: "setting-block"
};
const _hoisted_12 = { class: "input-names-display" };
const _hoisted_13 = { class: "input-name-type" };
const _hoisted_14 = { class: "setting-block" };
const _hoisted_15 = { class: "output-names-editor" };
const _hoisted_16 = ["onClick"];
const _hoisted_17 = { class: "setting-block" };
const _hoisted_18 = { class: "artifacts-panel" };
const _hoisted_19 = {
  key: 0,
  class: "artifacts-loading"
};
const _hoisted_20 = { class: "artifact-group" };
const _hoisted_21 = {
  key: 0,
  class: "artifact-type"
};
const _hoisted_22 = {
  key: 1,
  class: "artifacts-empty"
};
const _hoisted_23 = { class: "artifact-group" };
const _hoisted_24 = {
  key: 0,
  class: "artifact-type"
};
const _hoisted_25 = {
  key: 1,
  class: "artifacts-empty"
};
const _hoisted_26 = { class: "setting-block" };
const _hoisted_27 = { class: "code-header" };
const _hoisted_28 = { class: "code-header-actions" };
const _hoisted_29 = { class: "expanded-dialog-header" };
const _hoisted_30 = { class: "expanded-dialog-actions" };
const _hoisted_31 = {
  key: 0,
  class: "kernel-indicator"
};
const _hoisted_32 = { class: "expanded-editor-content" };
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "PythonScript",
  setup(__props, { expose: __expose }) {
    const nodeStore = useNodeStore();
    const editorStore = useEditorStore();
    const flowStore = useFlowStore();
    const dataLoaded = ref(false);
    const showEditor = ref(false);
    const showHelp = ref(false);
    const showExpandedEditor = ref(false);
    const nodePythonScript = ref(null);
    const nodeData = ref(null);
    const cells = ref([]);
    const inputNames = ref([]);
    const outputNames = ref(["main"]);
    const kernels = ref([]);
    const kernelsLoading = ref(false);
    const selectedKernelId = ref(null);
    let kernelPollTimer = null;
    const memoryInfo = ref(null);
    let memoryPollTimer = null;
    const availableArtifacts = ref([]);
    const publishedArtifacts = ref([]);
    const artifactsLoading = ref(false);
    const selectedKernelState = computed(() => {
      if (!selectedKernelId.value) return null;
      const kernel = kernels.value.find((k) => k.id === selectedKernelId.value);
      return (kernel == null ? void 0 : kernel.state) ?? null;
    });
    const formatBytes = (bytes) => {
      const gb = bytes / (1024 * 1024 * 1024);
      return gb >= 1 ? `${gb.toFixed(1)} GB` : `${(bytes / (1024 * 1024)).toFixed(0)} MB`;
    };
    const memoryDisplay = computed(() => {
      if (!memoryInfo.value || memoryInfo.value.limit_bytes === 0) return null;
      const used = formatBytes(memoryInfo.value.used_bytes);
      const limit = formatBytes(memoryInfo.value.limit_bytes);
      return `${used} / ${limit}`;
    });
    const memoryLevel = computed(() => {
      if (!memoryInfo.value) return "normal";
      if (memoryInfo.value.usage_percent >= 95) return "critical";
      if (memoryInfo.value.usage_percent >= 80) return "warning";
      return "normal";
    });
    const loadMemoryStats = async () => {
      const kernelId = selectedKernelId.value;
      if (!kernelId) {
        memoryInfo.value = null;
        return;
      }
      const kernel = kernels.value.find((k) => k.id === kernelId);
      if (!kernel || kernel.state !== "idle" && kernel.state !== "executing") {
        memoryInfo.value = null;
        return;
      }
      memoryInfo.value = await KernelApi.getMemoryStats(kernelId);
    };
    const startMemoryPolling = () => {
      stopMemoryPolling();
      loadMemoryStats();
      memoryPollTimer = setInterval(loadMemoryStats, 3e3);
    };
    const stopMemoryPolling = () => {
      if (memoryPollTimer !== null) {
        clearInterval(memoryPollTimer);
        memoryPollTimer = null;
      }
    };
    const loadKernels = async () => {
      kernelsLoading.value = true;
      try {
        kernels.value = await KernelApi.getAll();
      } catch (error) {
        console.error("Failed to load kernels:", error);
      } finally {
        kernelsLoading.value = false;
      }
    };
    const startKernelPolling = () => {
      stopKernelPolling();
      kernelPollTimer = setInterval(async () => {
        try {
          kernels.value = await KernelApi.getAll();
        } catch {
        }
      }, 5e3);
    };
    const stopKernelPolling = () => {
      if (kernelPollTimer !== null) {
        clearInterval(kernelPollTimer);
        kernelPollTimer = null;
      }
    };
    const handleKernelChange = (kernelId) => {
      if (nodePythonScript.value) {
        nodePythonScript.value.python_script_input.kernel_id = kernelId ?? null;
      }
      loadArtifacts();
      if (kernelId) {
        startMemoryPolling();
      } else {
        stopMemoryPolling();
        memoryInfo.value = null;
      }
    };
    const loadArtifacts = async () => {
      var _a, _b;
      const kernelId = selectedKernelId.value;
      if (!kernelId) {
        availableArtifacts.value = [];
        publishedArtifacts.value = [];
        return;
      }
      const kernel = kernels.value.find((k) => k.id === kernelId);
      if (!kernel || kernel.state !== "idle" && kernel.state !== "executing") {
        availableArtifacts.value = [];
        publishedArtifacts.value = [];
        return;
      }
      artifactsLoading.value = true;
      try {
        const flowId = (_a = nodePythonScript.value) == null ? void 0 : _a.flow_id;
        const currentNodeId = (_b = nodePythonScript.value) == null ? void 0 : _b.node_id;
        const [response, upstreamIds] = await Promise.all([
          KernelApi.getArtifacts(kernelId),
          flowId != null && currentNodeId != null ? FlowApi.getNodeUpstreamIds(Number(flowId), currentNodeId) : Promise.resolve([])
        ]);
        const allArtifacts = Object.entries(response).map(
          ([name, meta]) => ({
            name,
            type_name: (meta == null ? void 0 : meta.type_name) ?? "",
            node_id: meta == null ? void 0 : meta.node_id
          })
        );
        const upstreamSet = new Set(upstreamIds);
        if (currentNodeId != null) {
          availableArtifacts.value = allArtifacts.filter(
            (a) => a.node_id != null && upstreamSet.has(a.node_id)
          );
          publishedArtifacts.value = allArtifacts.filter((a) => a.node_id === currentNodeId);
        } else {
          availableArtifacts.value = [];
          publishedArtifacts.value = [];
        }
      } catch {
        availableArtifacts.value = [];
        publishedArtifacts.value = [];
      } finally {
        artifactsLoading.value = false;
      }
    };
    const loadInputNames = async () => {
      var _a, _b;
      const flowId = (_a = nodePythonScript.value) == null ? void 0 : _a.flow_id;
      const nodeId = (_b = nodePythonScript.value) == null ? void 0 : _b.node_id;
      if (flowId == null || nodeId == null) return;
      try {
        inputNames.value = await FlowApi.getNodeInputNames(Number(flowId), nodeId);
      } catch {
        inputNames.value = [];
      }
    };
    const addOutputName = () => {
      outputNames.value.push(`output_${outputNames.value.length}`);
      handleOutputNamesChange();
    };
    const removeOutputName = (index) => {
      outputNames.value.splice(index, 1);
      handleOutputNamesChange();
    };
    const handleOutputNamesChange = () => {
      if (nodePythonScript.value) {
        nodePythonScript.value.output_names = [...outputNames.value];
      }
      updateNodeOutputHandles();
    };
    const updateNodeOutputHandles = () => {
      var _a;
      const vfInstance = flowStore.vueFlowInstance;
      if (!vfInstance) return;
      const nodeId = String((_a = nodePythonScript.value) == null ? void 0 : _a.node_id);
      const vfNode = vfInstance.findNode(nodeId);
      if (vfNode) {
        vfNode.data.outputs = outputNames.value.map((name, i) => ({
          id: `output-${i}`,
          position: Position.Right,
          label: outputNames.value.length > 1 ? name : void 0
        }));
      }
    };
    const loadFlowRunDisplayOutputs = async () => {
      var _a, _b;
      const kernelId = selectedKernelId.value;
      const flowId = (_a = nodePythonScript.value) == null ? void 0 : _a.flow_id;
      const nodeId = (_b = nodePythonScript.value) == null ? void 0 : _b.node_id;
      if (!kernelId || flowId == null || nodeId == null) return;
      try {
        const outputs = await KernelApi.getDisplayOutputs(kernelId, Number(flowId), nodeId);
        if (outputs.length > 0 && cells.value.length > 0) {
          const lastCell = cells.value[cells.value.length - 1];
          cells.value = cells.value.map(
            (c) => c.id === lastCell.id ? {
              ...c,
              output: {
                stdout: "",
                stderr: "",
                display_outputs: outputs,
                error: null,
                execution_time_ms: 0,
                execution_count: 0
              }
            } : c
          );
        }
      } catch {
      }
    };
    watch(
      () => editorStore.isRunning,
      (running, wasRunning) => {
        if (wasRunning && !running && dataLoaded.value) {
          loadFlowRunDisplayOutputs();
          loadArtifacts();
        }
      }
    );
    const handleCellsUpdate = (updatedCells) => {
      cells.value = updatedCells;
      syncCellsToNode();
    };
    const syncCellsToNode = () => {
      if (!nodePythonScript.value) return;
      nodePythonScript.value.python_script_input.cells = cells.value.map((c) => ({
        id: c.id,
        code: c.code
      }));
      nodePythonScript.value.python_script_input.code = cells.value.map((c) => c.code).filter(Boolean).join("\n\n");
    };
    const { saveSettings, pushNodeData, handleGenericSettingsUpdate } = useNodeSettings({
      nodeRef: nodePythonScript,
      onBeforeSave: () => {
        var _a;
        syncCellsToNode();
        const combinedCode = (_a = nodePythonScript.value) == null ? void 0 : _a.python_script_input.code;
        if (!(combinedCode == null ? void 0 : combinedCode.trim())) {
          return false;
        }
        return true;
      }
    });
    const loadNodeData = async (nodeId) => {
      var _a, _b, _c, _d;
      try {
        nodeData.value = await nodeStore.getNodeData(nodeId, false);
        if (nodeData.value) {
          const hasValidSetup = Boolean(
            ((_b = (_a = nodeData.value) == null ? void 0 : _a.setting_input) == null ? void 0 : _b.is_setup) && ((_d = (_c = nodeData.value) == null ? void 0 : _c.setting_input) == null ? void 0 : _d.python_script_input)
          );
          nodePythonScript.value = hasValidSetup ? nodeData.value.setting_input : createPythonScriptNode(nodeStore.flow_id, nodeStore.node_id);
          const input = nodePythonScript.value.python_script_input;
          if (input.cells && input.cells.length > 0) {
            cells.value = input.cells.map((c) => ({
              id: c.id,
              code: c.code,
              output: null
            }));
          } else {
            cells.value = [
              {
                id: crypto.randomUUID(),
                code: input.code || DEFAULT_PYTHON_SCRIPT_CODE,
                output: null
              }
            ];
          }
          selectedKernelId.value = nodePythonScript.value.python_script_input.kernel_id;
          const savedOutputNames = nodePythonScript.value.output_names;
          outputNames.value = savedOutputNames && savedOutputNames.length > 0 ? [...savedOutputNames] : ["main"];
          showEditor.value = true;
          dataLoaded.value = true;
          await loadKernels();
          startKernelPolling();
          loadArtifacts();
          loadFlowRunDisplayOutputs();
          loadInputNames();
          if (selectedKernelId.value) {
            startMemoryPolling();
          }
        }
      } catch (error) {
        console.error("Failed to load node data:", error);
        showEditor.value = false;
        dataLoaded.value = false;
      }
    };
    onUnmounted(() => {
      stopKernelPolling();
      stopMemoryPolling();
    });
    __expose({ loadNodeData, pushNodeData, saveSettings });
    return (_ctx, _cache) => {
      const _component_el_option = resolveComponent("el-option");
      const _component_el_select = resolveComponent("el-select");
      const _component_router_link = resolveComponent("router-link");
      const _component_el_input = resolveComponent("el-input");
      const _component_el_dialog = resolveComponent("el-dialog");
      return dataLoaded.value && nodePythonScript.value ? (openBlock(), createElementBlock("div", _hoisted_1, [
        createVNode(GenericNodeSettings, {
          "model-value": nodePythonScript.value,
          "onUpdate:modelValue": unref(handleGenericSettingsUpdate),
          onRequestSave: unref(saveSettings)
        }, {
          default: withCtx(() => [
            createBaseVNode("div", _hoisted_2, [
              createBaseVNode("div", _hoisted_3, [
                _cache[10] || (_cache[10] = createBaseVNode("label", { class: "setting-label" }, "Kernel", -1)),
                createBaseVNode("div", _hoisted_4, [
                  createVNode(_component_el_select, {
                    modelValue: selectedKernelId.value,
                    "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => selectedKernelId.value = $event),
                    placeholder: "Select a kernel...",
                    class: "kernel-select",
                    size: "small",
                    loading: kernelsLoading.value,
                    onChange: handleKernelChange
                  }, {
                    default: withCtx(() => [
                      (openBlock(true), createElementBlock(Fragment, null, renderList(kernels.value, (kernel) => {
                        return openBlock(), createBlock(_component_el_option, {
                          key: kernel.id,
                          value: kernel.id,
                          label: `${kernel.name} (${kernel.state})`
                        }, {
                          default: withCtx(() => [
                            createBaseVNode("span", _hoisted_5, [
                              createBaseVNode("span", {
                                class: normalizeClass(["kernel-state-dot", `kernel-state-dot--${kernel.state}`])
                              }, null, 2),
                              createBaseVNode("span", null, toDisplayString(kernel.name), 1),
                              createBaseVNode("span", _hoisted_6, "(" + toDisplayString(kernel.state) + ")", 1)
                            ])
                          ]),
                          _: 2
                        }, 1032, ["value", "label"]);
                      }), 128))
                    ]),
                    _: 1
                  }, 8, ["modelValue", "loading"]),
                  createVNode(_component_router_link, {
                    to: { name: "kernelManager" },
                    class: "manage-kernels-link"
                  }, {
                    default: withCtx(() => [..._cache[6] || (_cache[6] = [
                      createTextVNode(" Manage Kernels ", -1)
                    ])]),
                    _: 1
                  })
                ]),
                memoryDisplay.value ? (openBlock(), createElementBlock("div", {
                  key: 0,
                  class: normalizeClass(["kernel-memory", `kernel-memory--${memoryLevel.value}`])
                }, [
                  _cache[7] || (_cache[7] = createBaseVNode("i", { class: "fa-solid fa-memory" }, null, -1)),
                  createBaseVNode("span", _hoisted_7, toDisplayString(memoryDisplay.value), 1),
                  createBaseVNode("span", _hoisted_8, "(" + toDisplayString(memoryInfo.value.usage_percent) + "%)", 1)
                ], 2)) : createCommentVNode("", true),
                !selectedKernelId.value ? (openBlock(), createElementBlock("div", _hoisted_9, [..._cache[8] || (_cache[8] = [
                  createBaseVNode("i", { class: "fa-solid fa-triangle-exclamation" }, null, -1),
                  createTextVNode(" No kernel selected. A kernel is required to run Python code. ", -1)
                ])])) : selectedKernelState.value && selectedKernelState.value !== "idle" ? (openBlock(), createElementBlock("div", _hoisted_10, [
                  _cache[9] || (_cache[9] = createBaseVNode("i", { class: "fa-solid fa-triangle-exclamation" }, null, -1)),
                  createTextVNode(" Kernel is " + toDisplayString(selectedKernelState.value) + ". ", 1),
                  selectedKernelState.value === "stopped" ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [
                    createTextVNode("Start it from the Kernel Manager to execute code.")
                  ], 64)) : selectedKernelState.value === "error" ? (openBlock(), createElementBlock(Fragment, { key: 1 }, [
                    createTextVNode("Check the Kernel Manager for details.")
                  ], 64)) : selectedKernelState.value === "starting" ? (openBlock(), createElementBlock(Fragment, { key: 2 }, [
                    createTextVNode("Please wait for it to become idle.")
                  ], 64)) : selectedKernelState.value === "executing" ? (openBlock(), createElementBlock(Fragment, { key: 3 }, [
                    createTextVNode("Please wait for the current execution to finish.")
                  ], 64)) : createCommentVNode("", true)
                ])) : createCommentVNode("", true)
              ]),
              inputNames.value.length > 0 ? (openBlock(), createElementBlock("div", _hoisted_11, [
                _cache[12] || (_cache[12] = createBaseVNode("label", { class: "setting-label" }, "Available Inputs", -1)),
                createBaseVNode("div", _hoisted_12, [
                  (openBlock(true), createElementBlock(Fragment, null, renderList(inputNames.value, (inp) => {
                    return openBlock(), createElementBlock("span", {
                      key: inp.name,
                      class: "input-name-tag"
                    }, [
                      createTextVNode(toDisplayString(inp.name) + " ", 1),
                      createBaseVNode("span", _hoisted_13, "(" + toDisplayString(inp.source_node_type) + ")", 1)
                    ]);
                  }), 128)),
                  _cache[11] || (_cache[11] = createBaseVNode("span", { class: "input-names-hint" }, ' Use flowfile.read_input("name") to read a specific input ', -1))
                ])
              ])) : createCommentVNode("", true),
              createBaseVNode("div", _hoisted_14, [
                _cache[15] || (_cache[15] = createBaseVNode("label", { class: "setting-label" }, "Output Names", -1)),
                createBaseVNode("div", _hoisted_15, [
                  (openBlock(true), createElementBlock(Fragment, null, renderList(outputNames.value, (name, index) => {
                    return openBlock(), createElementBlock("div", {
                      key: index,
                      class: "output-name-row"
                    }, [
                      createVNode(_component_el_input, {
                        modelValue: outputNames.value[index],
                        "onUpdate:modelValue": ($event) => outputNames.value[index] = $event,
                        size: "small",
                        placeholder: "output name",
                        onBlur: handleOutputNamesChange
                      }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                      outputNames.value.length > 1 ? (openBlock(), createElementBlock("button", {
                        key: 0,
                        class: "icon-button icon-button--danger",
                        title: "Remove output",
                        onClick: ($event) => removeOutputName(index)
                      }, [..._cache[13] || (_cache[13] = [
                        createBaseVNode("i", { class: "fa-solid fa-minus" }, null, -1)
                      ])], 8, _hoisted_16)) : createCommentVNode("", true)
                    ]);
                  }), 128)),
                  createBaseVNode("button", {
                    class: "add-output-button",
                    onClick: addOutputName
                  }, [..._cache[14] || (_cache[14] = [
                    createBaseVNode("i", { class: "fa-solid fa-plus" }, null, -1),
                    createTextVNode(" Add Output ", -1)
                  ])])
                ])
              ]),
              createBaseVNode("div", _hoisted_17, [
                _cache[19] || (_cache[19] = createBaseVNode("label", { class: "setting-label" }, "Artifacts", -1)),
                createBaseVNode("div", _hoisted_18, [
                  artifactsLoading.value ? (openBlock(), createElementBlock("div", _hoisted_19, [..._cache[16] || (_cache[16] = [
                    createBaseVNode("i", { class: "fas fa-spinner fa-spin" }, null, -1),
                    createTextVNode(" Loading artifacts... ", -1)
                  ])])) : (openBlock(), createElementBlock(Fragment, { key: 1 }, [
                    createBaseVNode("div", _hoisted_20, [
                      _cache[17] || (_cache[17] = createBaseVNode("span", { class: "artifact-group-label" }, "Available:", -1)),
                      availableArtifacts.value.length > 0 ? (openBlock(true), createElementBlock(Fragment, { key: 0 }, renderList(availableArtifacts.value, (artifact) => {
                        return openBlock(), createElementBlock("span", {
                          key: artifact.name,
                          class: "artifact-tag"
                        }, [
                          createTextVNode(toDisplayString(artifact.name) + " ", 1),
                          artifact.type_name ? (openBlock(), createElementBlock("span", _hoisted_21, "(" + toDisplayString(artifact.type_name) + ")", 1)) : createCommentVNode("", true)
                        ]);
                      }), 128)) : (openBlock(), createElementBlock("span", _hoisted_22, "None"))
                    ]),
                    createBaseVNode("div", _hoisted_23, [
                      _cache[18] || (_cache[18] = createBaseVNode("span", { class: "artifact-group-label" }, "Published:", -1)),
                      publishedArtifacts.value.length > 0 ? (openBlock(true), createElementBlock(Fragment, { key: 0 }, renderList(publishedArtifacts.value, (artifact) => {
                        return openBlock(), createElementBlock("span", {
                          key: artifact.name,
                          class: "artifact-tag artifact-tag--published"
                        }, [
                          createTextVNode(toDisplayString(artifact.name) + " ", 1),
                          artifact.type_name ? (openBlock(), createElementBlock("span", _hoisted_24, "(" + toDisplayString(artifact.type_name) + ")", 1)) : createCommentVNode("", true)
                        ]);
                      }), 128)) : (openBlock(), createElementBlock("span", _hoisted_25, "Run the flow to see published artifacts"))
                    ])
                  ], 64))
                ])
              ]),
              createBaseVNode("div", _hoisted_26, [
                createBaseVNode("div", _hoisted_27, [
                  _cache[22] || (_cache[22] = createBaseVNode("label", { class: "setting-label" }, "Code", -1)),
                  createBaseVNode("div", _hoisted_28, [
                    createBaseVNode("button", {
                      class: "icon-button",
                      title: "Expand Editor",
                      onClick: _cache[1] || (_cache[1] = ($event) => showExpandedEditor.value = true)
                    }, [..._cache[20] || (_cache[20] = [
                      createBaseVNode("i", { class: "fa-solid fa-expand" }, null, -1)
                    ])]),
                    createBaseVNode("button", {
                      class: "icon-button",
                      title: "API Reference",
                      onClick: _cache[2] || (_cache[2] = ($event) => showHelp.value = true)
                    }, [..._cache[21] || (_cache[21] = [
                      createBaseVNode("i", { class: "fa-solid fa-circle-question" }, null, -1)
                    ])])
                  ])
                ]),
                showEditor.value && cells.value.length > 0 ? (openBlock(), createBlock(NotebookEditor, {
                  key: 0,
                  cells: cells.value,
                  "kernel-id": selectedKernelId.value,
                  "flow-id": nodePythonScript.value.flow_id,
                  "node-id": nodePythonScript.value.node_id,
                  "depending-on-ids": nodePythonScript.value.depending_on_ids ?? [],
                  "onUpdate:cells": handleCellsUpdate
                }, null, 8, ["cells", "kernel-id", "flow-id", "node-id", "depending-on-ids"])) : createCommentVNode("", true)
              ])
            ])
          ]),
          _: 1
        }, 8, ["model-value", "onUpdate:modelValue", "onRequestSave"]),
        showHelp.value ? (openBlock(), createBlock(FlowfileApiHelp, {
          key: 0,
          onClose: _cache[3] || (_cache[3] = ($event) => showHelp.value = false)
        })) : createCommentVNode("", true),
        createVNode(_component_el_dialog, {
          modelValue: showExpandedEditor.value,
          "onUpdate:modelValue": _cache[5] || (_cache[5] = ($event) => showExpandedEditor.value = $event),
          title: "Python Script",
          fullscreen: "",
          "close-on-click-modal": false,
          class: "expanded-editor-dialog"
        }, {
          header: withCtx(() => {
            var _a;
            return [
              createBaseVNode("div", _hoisted_29, [
                _cache[24] || (_cache[24] = createBaseVNode("span", { class: "expanded-dialog-title" }, "Python Script", -1)),
                createBaseVNode("div", _hoisted_30, [
                  selectedKernelId.value ? (openBlock(), createElementBlock("span", _hoisted_31, [
                    createBaseVNode("span", {
                      class: normalizeClass(["kernel-state-dot", `kernel-state-dot--${selectedKernelState.value}`])
                    }, null, 2),
                    createTextVNode(" " + toDisplayString((_a = kernels.value.find((k) => k.id === selectedKernelId.value)) == null ? void 0 : _a.name) + " ", 1),
                    memoryDisplay.value ? (openBlock(), createElementBlock("span", {
                      key: 0,
                      class: normalizeClass(["kernel-indicator__memory", `kernel-memory--${memoryLevel.value}`])
                    }, toDisplayString(memoryDisplay.value), 3)) : createCommentVNode("", true)
                  ])) : createCommentVNode("", true),
                  createBaseVNode("button", {
                    class: "icon-button",
                    title: "API Reference",
                    onClick: _cache[4] || (_cache[4] = ($event) => showHelp.value = true)
                  }, [..._cache[23] || (_cache[23] = [
                    createBaseVNode("i", { class: "fa-solid fa-circle-question" }, null, -1)
                  ])])
                ])
              ])
            ];
          }),
          default: withCtx(() => [
            createBaseVNode("div", _hoisted_32, [
              showExpandedEditor.value && cells.value.length > 0 ? (openBlock(), createBlock(NotebookEditor, {
                key: 0,
                cells: cells.value,
                "kernel-id": selectedKernelId.value,
                "flow-id": nodePythonScript.value.flow_id,
                "node-id": nodePythonScript.value.node_id,
                "depending-on-ids": nodePythonScript.value.depending_on_ids ?? [],
                "onUpdate:cells": handleCellsUpdate
              }, null, 8, ["cells", "kernel-id", "flow-id", "node-id", "depending-on-ids"])) : createCommentVNode("", true)
            ])
          ]),
          _: 1
        }, 8, ["modelValue"])
      ])) : (openBlock(), createBlock(unref(CodeLoader), { key: 1 }));
    };
  }
});
const PythonScript = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-598d56dc"]]);
export {
  PythonScript as default
};
