import { k as axios, az as path, K as defineStore, d as defineComponent, L as computed, D as watch, aA as onActivated, G as onMounted, c as createElementBlock, a as createBaseVNode, n as normalizeClass, t as toDisplayString, y as createVNode, A as withCtx, w as withModifiers, H as Fragment, I as renderList, e as createCommentVNode, B as createBlock, r as ref, J as ElMessage, C as resolveComponent, f as createTextVNode, _ as _imports_1, ay as withKeys, o as openBlock, aB as ElMessageBox, g as _export_sfc } from "./index-BAmalrlq.js";
const handleApiError = (error) => {
  var _a, _b, _c;
  throw {
    message: ((_b = (_a = error.response) == null ? void 0 : _a.data) == null ? void 0 : _b.detail) || "An unknown error occurred",
    status: ((_c = error.response) == null ? void 0 : _c.status) || 500
  };
};
class FileApi {
  static async getDirectoryContents(directory, params) {
    try {
      const response = await axios.get("files/directory_contents/", {
        params: { directory, ...params }
      });
      return response.data;
    } catch (error) {
      return handleApiError(error);
    }
  }
  static async getDefaultPath() {
    try {
      const response = await axios.get("files/default_path/");
      return response.data;
    } catch (error) {
      return handleApiError(error);
    }
  }
  static async createDirectory(directoryName) {
    try {
      const response = await axios.post("files/create_directory", {
        name: directoryName
      });
      return response.data;
    } catch (error) {
      return handleApiError(error);
    }
  }
  static async getLocalFiles(directory) {
    try {
      const response = await axios.get("files/files_in_local_directory/", {
        params: { directory }
      });
      return response.data;
    } catch (error) {
      return handleApiError(error);
    }
  }
  static getParentPath(currentPath) {
    if (!currentPath) return "";
    const parent = path.dirname(currentPath);
    if (parent === currentPath || parent === ".") {
      return currentPath;
    }
    return parent;
  }
  static joinPath(currentPath, subdir) {
    if (!currentPath) return subdir;
    return path.join(currentPath, subdir);
  }
  static isRootPath(pathStr) {
    if (!pathStr) return true;
    if (pathStr === "/" || pathStr === "~") return true;
    if (/^[A-Za-z]:[/\\]?$/.test(pathStr)) return true;
    return false;
  }
}
const getDirectoryContents = FileApi.getDirectoryContents;
const getDefaultPath$1 = FileApi.getDefaultPath;
const getParentPath = FileApi.getParentPath;
const joinPath = FileApi.joinPath;
const _imports_0 = "/images/sheets.png";
function getDefaultPath() {
  return "";
}
function loadContextState(context) {
  const storedPath = localStorage.getItem(`fileBrowser_${context}_lastPath`);
  return {
    currentPath: storedPath || getDefaultPath(),
    lastUsedPath: storedPath || getDefaultPath()
  };
}
function saveContextPath(context, path2) {
  if (path2) {
    localStorage.setItem(`fileBrowser_${context}_lastPath`, path2);
  }
}
const useFileBrowserStore = defineStore("fileBrowser", {
  state: () => ({
    // Initialize sort state from localStorage if available, otherwise use defaults.
    sortBy: localStorage.getItem("fileBrowser_sortBy") || "name",
    sortDirection: localStorage.getItem("fileBrowser_sortDirection") || "asc",
    // Context-specific path states
    contexts: {
      flows: loadContextState("flows"),
      dataFiles: loadContextState("dataFiles")
    }
  }),
  getters: {
    /**
     * Get the current path for a specific context
     */
    getCurrentPath: (state) => (context) => {
      var _a;
      return ((_a = state.contexts[context]) == null ? void 0 : _a.currentPath) || "";
    },
    /**
     * Get the last used path for a specific context
     */
    getLastUsedPath: (state) => (context) => {
      var _a;
      return ((_a = state.contexts[context]) == null ? void 0 : _a.lastUsedPath) || "";
    }
  },
  actions: {
    setSortBy(newSortBy) {
      this.sortBy = newSortBy;
      localStorage.setItem("fileBrowser_sortBy", newSortBy);
    },
    setSortDirection(newSortDirection) {
      this.sortDirection = newSortDirection;
      localStorage.setItem("fileBrowser_sortDirection", newSortDirection);
    },
    toggleSortDirection() {
      this.sortDirection = this.sortDirection === "asc" ? "desc" : "asc";
      localStorage.setItem("fileBrowser_sortDirection", this.sortDirection);
    },
    /**
     * Set the current path for a specific context
     */
    setCurrentPath(context, path2) {
      if (!this.contexts[context]) {
        this.contexts[context] = { currentPath: "", lastUsedPath: "" };
      }
      this.contexts[context].currentPath = path2;
      this.contexts[context].lastUsedPath = path2;
      saveContextPath(context, path2);
    },
    /**
     * Initialize a context with a path if it doesn't have one yet
     */
    initializeContext(context, defaultPath) {
      if (!this.contexts[context]) {
        this.contexts[context] = { currentPath: "", lastUsedPath: "" };
      }
      if (!this.contexts[context].currentPath && defaultPath) {
        this.contexts[context].currentPath = defaultPath;
      }
    },
    /**
     * Reset a context to its default state
     */
    resetContext(context) {
      const defaultPath = getDefaultPath();
      this.contexts[context] = {
        currentPath: defaultPath,
        lastUsedPath: defaultPath
      };
      localStorage.removeItem(`fileBrowser_${context}_lastPath`);
    }
  }
});
const FLOWFILE_EXTENSIONS = ["flowfile", "yml", "yaml", "test"];
const DATA_FILE_EXTENSIONS = ["xlsx", "parquet", "csv", "txt"];
const ALLOWED_SAVE_EXTENSIONS = ["yaml", "yml"];
const _hoisted_1 = { class: "file-browser" };
const _hoisted_2 = { class: "browser-content" };
const _hoisted_3 = { class: "browser-toolbar" };
const _hoisted_4 = { class: "path-navigation" };
const _hoisted_5 = ["disabled"];
const _hoisted_6 = ["disabled"];
const _hoisted_7 = { class: "current-path" };
const _hoisted_8 = { class: "controls-row" };
const _hoisted_9 = { class: "search-container" };
const _hoisted_10 = { class: "sort-controls" };
const _hoisted_11 = { class: "material-icons" };
const _hoisted_12 = { class: "show-hidden-toggle" };
const _hoisted_13 = {
  key: 0,
  class: "loading-state"
};
const _hoisted_14 = {
  key: 1,
  class: "error-state"
};
const _hoisted_15 = { class: "error-content" };
const _hoisted_16 = { class: "error-message" };
const _hoisted_17 = {
  key: 2,
  class: "grid-container"
};
const _hoisted_18 = ["onClick", "onDblclick"];
const _hoisted_19 = { class: "file-item-content" };
const _hoisted_20 = { class: "file-icon-wrapper" };
const _hoisted_21 = {
  key: 0,
  src: _imports_0,
  alt: "Table file",
  class: "file-icon"
};
const _hoisted_22 = {
  key: 1,
  src: _imports_1,
  alt: "Flow file",
  class: "file-icon"
};
const _hoisted_23 = { class: "file-details" };
const _hoisted_24 = { class: "file-info" };
const _hoisted_25 = {
  key: 3,
  class: "empty-state"
};
const _hoisted_26 = { class: "browser-actions" };
const _hoisted_27 = {
  key: 0,
  class: "form-hint"
};
const _hoisted_28 = {
  key: 0,
  class: "auto-extension-hint"
};
const _hoisted_29 = { class: "dialog-footer" };
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "fileBrowser",
  props: {
    allowedFileTypes: { default: () => [] },
    modelValue: { default: null },
    mode: { default: "open" },
    initialFilePath: { default: "" },
    allowDirectorySelection: { type: Boolean, default: false },
    showWarningOnOverwrite: { type: Boolean, default: true },
    isVisible: { type: Boolean, default: true },
    context: { default: "flows" }
  },
  emits: ["fileSelected", "update:modelValue", "createFile", "overwriteFile", "directorySelected"],
  setup(__props, { expose: __expose, emit: __emit }) {
    const fileBrowserStore = useFileBrowserStore();
    const sortBy = computed({
      get: () => fileBrowserStore.sortBy,
      set: (newValue) => {
        fileBrowserStore.setSortBy(newValue);
      }
    });
    const sortDirection = computed(() => fileBrowserStore.sortDirection);
    const toggleSortDirection = () => fileBrowserStore.toggleSortDirection();
    const props = __props;
    const emit = __emit;
    const files = ref([]);
    const currentPath = ref("");
    const searchTerm = ref("");
    const showHidden = ref(false);
    const loading = ref(false);
    const error = ref(null);
    const showCreateDialog = ref(false);
    const newFileName = ref("");
    const fileNameError = ref("");
    const selectedFile = ref(null);
    const loadDirectoryContents = async (directoryPath) => {
      loading.value = true;
      error.value = null;
      try {
        const filesResponse = await getDirectoryContents(directoryPath, {
          include_hidden: showHidden.value
        });
        files.value = filesResponse;
        currentPath.value = directoryPath;
        fileBrowserStore.setCurrentPath(props.context, directoryPath);
      } catch (err) {
        error.value = err.message || "Failed to load directory";
      } finally {
        loading.value = false;
      }
    };
    const loadDefaultDirectory = async () => {
      loading.value = true;
      error.value = null;
      try {
        const defaultPath = await getDefaultPath$1();
        await loadDirectoryContents(defaultPath);
      } catch (err) {
        error.value = err.message || "Failed to load directory";
        loading.value = false;
      }
    };
    const loadCurrentDirectory = async () => {
      const storedPath = fileBrowserStore.getCurrentPath(props.context);
      if (storedPath) {
        await loadDirectoryContents(storedPath);
        if (error.value) {
          fileBrowserStore.resetContext(props.context);
          await loadDefaultDirectory();
        }
      } else {
        await loadDefaultDirectory();
      }
    };
    const navigateToPath = async (directoryPath) => {
      const previousPath = currentPath.value;
      const previousFiles = [...files.value];
      await loadDirectoryContents(directoryPath);
      if (error.value) {
        currentPath.value = previousPath;
        files.value = previousFiles;
        fileBrowserStore.setCurrentPath(props.context, previousPath);
        error.value = null;
        ElMessage.warning("Cannot navigate to this directory");
        return;
      }
      searchTerm.value = "";
      selectedFile.value = null;
    };
    const navigateUpDirectory = async () => {
      const parentPath = getParentPath(currentPath.value);
      if (parentPath && parentPath !== currentPath.value) {
        await navigateToPath(parentPath);
      }
    };
    const navigateIntoDirectory = async (directoryName) => {
      const newPath = joinPath(currentPath.value, directoryName);
      await navigateToPath(newPath);
    };
    const handleInitialFileSelection = async () => {
      if (!props.initialFilePath) return;
      loading.value = true;
      error.value = null;
      try {
        const directoryPath = path.dirname(props.initialFilePath);
        const fileName = path.basename(props.initialFilePath);
        await loadDirectoryContents(directoryPath);
        const fileToSelect = files.value.find((file) => file.name === fileName);
        if (fileToSelect) {
          selectedFile.value = fileToSelect;
          emit("update:modelValue", fileToSelect);
        }
      } catch (err) {
        error.value = err.message || "Failed to navigate to initial file";
        ElMessage.error("Failed to navigate to initial file location");
      } finally {
        loading.value = false;
      }
    };
    const isDataFile = (file) => {
      if (file.is_directory) return false;
      const name = file.name.toLowerCase();
      return DATA_FILE_EXTENSIONS.some((ext) => name.endsWith(`.${ext}`));
    };
    const isFlowfile = (file) => {
      if (file.is_directory) return false;
      const name = file.name.toLowerCase();
      return FLOWFILE_EXTENSIONS.some((ext) => name.endsWith(`.${ext}`));
    };
    const formatFileSize = (bytes) => {
      if (bytes < 1024) return bytes + " B";
      if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + " KB";
      if (bytes < 1024 * 1024 * 1024) return (bytes / (1024 * 1024)).toFixed(1) + " MB";
      return (bytes / (1024 * 1024 * 1024)).toFixed(1) + " GB";
    };
    const formatDate = (dateString) => {
      const date = new Date(dateString);
      return `${date.toLocaleDateString("en-US", {
        year: "numeric",
        month: "short",
        day: "numeric"
      })} ${date.toLocaleTimeString("en-US", {
        hour: "2-digit",
        minute: "2-digit",
        hour12: false
      })}`;
    };
    const handleBackgroundClick = () => {
      selectedFile.value = null;
      emit("update:modelValue", null);
    };
    const handleOpenFile = () => {
      if (selectedFile.value && !selectedFile.value.is_directory) {
        emit("fileSelected", selectedFile.value);
      }
    };
    const handleSingleClick = (file) => {
      emit("update:modelValue", file);
      selectedFile.value = file;
    };
    const handleSelectDirectory = () => {
      emit("directorySelected", currentPath.value);
    };
    const handleDoubleClick = async (file) => {
      if (file.is_directory) {
        selectedFile.value = null;
        await navigateIntoDirectory(file.name);
      } else {
        emit("fileSelected", file);
      }
    };
    const handleDialogClosed = () => {
      newFileName.value = "";
      fileNameError.value = "";
    };
    const validateFileName = (fileName) => {
      if (!fileName.trim()) {
        fileNameError.value = "File name cannot be empty";
        return false;
      }
      if (!/^[a-zA-Z0-9-_. ]+$/.test(fileName)) {
        fileNameError.value = "File name contains invalid characters";
        return false;
      }
      if (files.value.some((file) => file.name.toLowerCase() === fileName.toLowerCase())) {
        fileNameError.value = "A file with this name already exists";
        return false;
      }
      return true;
    };
    const hasValidExtension = computed(() => {
      const name = newFileName.value.trim().toLowerCase();
      const validExtensions = props.allowedFileTypes.length > 0 ? props.allowedFileTypes : ALLOWED_SAVE_EXTENSIONS;
      return validExtensions.some((ext) => name.endsWith(`.${ext}`));
    });
    const previewFileName = computed(() => {
      const name = newFileName.value.trim();
      if (!name) return "";
      if (hasValidExtension.value) return name;
      const defaultExt = props.allowedFileTypes.length > 0 ? props.allowedFileTypes[0] : "yaml";
      return `${name}.${defaultExt}`;
    });
    const handleCreateFile = () => {
      if (validateFileName(newFileName.value)) {
        const fileName = previewFileName.value;
        const newFilePath = path.join(currentPath.value, fileName);
        emit("createFile", newFilePath, currentPath.value, fileName);
        showCreateDialog.value = false;
      }
    };
    const confirmOverwrite = () => {
      if (selectedFile.value && !selectedFile.value.is_directory) {
        ElMessageBox.confirm(
          `Are you sure you want to overwrite "${selectedFile.value.name}"?`,
          "Warning",
          {
            confirmButtonText: "OK",
            cancelButtonText: "Cancel",
            type: "warning",
            customClass: "overwrite-confirm-dialog"
          }
        ).then(() => {
          if (selectedFile.value)
            emit(
              "overwriteFile",
              selectedFile.value.path,
              currentPath.value,
              selectedFile.value.name
            );
        }).catch(() => {
        });
      }
    };
    const refresh = async () => {
      await loadCurrentDirectory();
    };
    __expose({
      refresh,
      handleInitialFileSelection,
      loadCurrentDirectory,
      navigateUpDirectory,
      selectedFile: computed(() => selectedFile.value)
    });
    const calculateSortedFiles = () => {
      return files.value.filter((file) => {
        if (file.is_directory) {
          const matchesSearch2 = file.name.toLowerCase().includes(searchTerm.value.toLowerCase());
          const matchesHidden2 = showHidden.value || !file.is_hidden;
          return matchesSearch2 && matchesHidden2;
        }
        const matchesSearch = file.name.toLowerCase().includes(searchTerm.value.toLowerCase());
        const matchesHidden = showHidden.value || !file.is_hidden;
        const matchesType = props.allowedFileTypes.length === 0 || props.allowedFileTypes.some(
          (type) => file.name.toLowerCase().endsWith(`.${type.toLowerCase()}`)
        );
        return matchesSearch && matchesHidden && matchesType;
      }).sort((a, b) => {
        let comparison = 0;
        switch (sortBy.value) {
          case "size": {
            const aSize = a.is_directory ? a.size || 0 : a.size;
            const bSize = b.is_directory ? b.size || 0 : b.size;
            comparison = aSize - bSize;
            break;
          }
          case "last_modified":
            comparison = new Date(a.last_modified).getTime() - new Date(b.last_modified).getTime();
            break;
          case "created_date":
            comparison = new Date(a.created_date).getTime() - new Date(b.created_date).getTime();
            break;
          case "name":
          default:
            comparison = a.name.toLowerCase().localeCompare(b.name.toLowerCase());
            break;
        }
        return sortDirection.value === "asc" ? comparison : -comparison;
      });
    };
    const filteredFiles = computed(() => {
      return calculateSortedFiles();
    });
    watch(
      () => props.allowedFileTypes,
      () => {
        loadCurrentDirectory();
      }
    );
    watch(
      () => props.initialFilePath,
      async (newPath) => {
        if (newPath) {
          await handleInitialFileSelection();
        }
      }
    );
    watch(
      () => props.isVisible,
      async (newVisible, oldVisible) => {
        if (newVisible && !oldVisible) {
          await loadCurrentDirectory();
        }
      }
    );
    onActivated(async () => {
      await loadCurrentDirectory();
    });
    onMounted(async () => {
      if (props.initialFilePath) {
        await handleInitialFileSelection();
      } else {
        await loadCurrentDirectory();
      }
    });
    return (_ctx, _cache) => {
      const _component_el_input = resolveComponent("el-input");
      const _component_el_option = resolveComponent("el-option");
      const _component_el_select = resolveComponent("el-select");
      const _component_el_button = resolveComponent("el-button");
      const _component_el_checkbox = resolveComponent("el-checkbox");
      const _component_el_form_item = resolveComponent("el-form-item");
      const _component_el_form = resolveComponent("el-form");
      const _component_el_dialog = resolveComponent("el-dialog");
      return openBlock(), createElementBlock("div", _hoisted_1, [
        _cache[20] || (_cache[20] = createBaseVNode("div", { class: "browser-header" }, [
          createBaseVNode("div", { class: "browser-title" }, [
            createBaseVNode("span", { class: "material-icons" }, "folder"),
            createBaseVNode("span", null, "File Browser")
          ])
        ], -1)),
        createBaseVNode("div", _hoisted_2, [
          createBaseVNode("div", _hoisted_3, [
            createBaseVNode("div", _hoisted_4, [
              createBaseVNode("button", {
                class: "nav-button",
                disabled: loading.value,
                onClick: navigateUpDirectory
              }, [..._cache[7] || (_cache[7] = [
                createBaseVNode("span", { class: "material-icons" }, "arrow_upward", -1),
                createBaseVNode("span", null, "Up", -1)
              ])], 8, _hoisted_5),
              createBaseVNode("button", {
                class: "nav-button refresh-button",
                disabled: loading.value,
                title: "Refresh",
                onClick: loadCurrentDirectory
              }, [
                createBaseVNode("span", {
                  class: normalizeClass(["material-icons", { spin: loading.value }])
                }, "refresh", 2)
              ], 8, _hoisted_6),
              createBaseVNode("div", _hoisted_7, toDisplayString(currentPath.value), 1)
            ]),
            createBaseVNode("div", _hoisted_8, [
              createBaseVNode("div", _hoisted_9, [
                createVNode(_component_el_input, {
                  modelValue: searchTerm.value,
                  "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => searchTerm.value = $event),
                  placeholder: "Search files...",
                  class: "search-input"
                }, {
                  prefix: withCtx(() => [..._cache[8] || (_cache[8] = [
                    createBaseVNode("span", { class: "material-icons" }, "search", -1)
                  ])]),
                  _: 1
                }, 8, ["modelValue"])
              ]),
              createBaseVNode("div", _hoisted_10, [
                createVNode(_component_el_select, {
                  modelValue: sortBy.value,
                  "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => sortBy.value = $event),
                  placeholder: "Sort by",
                  size: "small",
                  class: "sort-select"
                }, {
                  default: withCtx(() => [
                    createVNode(_component_el_option, {
                      label: "Name",
                      value: "name"
                    }),
                    createVNode(_component_el_option, {
                      label: "Size",
                      value: "size"
                    }),
                    createVNode(_component_el_option, {
                      label: "Modified",
                      value: "last_modified"
                    }),
                    createVNode(_component_el_option, {
                      label: "Created",
                      value: "created_date"
                    })
                  ]),
                  _: 1
                }, 8, ["modelValue"]),
                createVNode(_component_el_button, {
                  class: "sort-direction-button",
                  size: "small",
                  onClick: toggleSortDirection
                }, {
                  default: withCtx(() => [
                    createBaseVNode("span", _hoisted_11, toDisplayString(sortDirection.value === "asc" ? "arrow_upward" : "arrow_downward"), 1)
                  ]),
                  _: 1
                })
              ]),
              createBaseVNode("label", _hoisted_12, [
                createVNode(_component_el_checkbox, {
                  modelValue: showHidden.value,
                  "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => showHidden.value = $event),
                  onChange: loadCurrentDirectory
                }, {
                  default: withCtx(() => [..._cache[9] || (_cache[9] = [
                    createTextVNode(" Show hidden files ", -1)
                  ])]),
                  _: 1
                }, 8, ["modelValue"])
              ])
            ])
          ]),
          createBaseVNode("div", {
            class: "browser-main",
            onClick: handleBackgroundClick
          }, [
            loading.value ? (openBlock(), createElementBlock("div", _hoisted_13)) : error.value ? (openBlock(), createElementBlock("div", _hoisted_14, [
              createBaseVNode("div", _hoisted_15, [
                _cache[11] || (_cache[11] = createBaseVNode("span", { class: "material-icons error-icon" }, "error_outline", -1)),
                createBaseVNode("span", _hoisted_16, toDisplayString(error.value), 1),
                createVNode(_component_el_button, {
                  type: "primary",
                  size: "small",
                  onClick: withModifiers(loadCurrentDirectory, ["stop"])
                }, {
                  default: withCtx(() => [..._cache[10] || (_cache[10] = [
                    createBaseVNode("span", { class: "material-icons" }, "refresh", -1),
                    createTextVNode(" Retry ", -1)
                  ])]),
                  _: 1
                })
              ])
            ])) : (openBlock(), createElementBlock("div", _hoisted_17, [
              (openBlock(true), createElementBlock(Fragment, null, renderList(filteredFiles.value, (file) => {
                var _a;
                return openBlock(), createElementBlock("div", {
                  key: file.path,
                  class: normalizeClass(["file-item", {
                    selected: ((_a = selectedFile.value) == null ? void 0 : _a.path) === file.path,
                    "is-directory": file.is_directory
                  }]),
                  onClick: withModifiers(($event) => handleSingleClick(file), ["stop"]),
                  onDblclick: ($event) => handleDoubleClick(file)
                }, [
                  createBaseVNode("div", _hoisted_19, [
                    createBaseVNode("div", _hoisted_20, [
                      isDataFile(file) ? (openBlock(), createElementBlock("img", _hoisted_21)) : isFlowfile(file) ? (openBlock(), createElementBlock("img", _hoisted_22)) : (openBlock(), createElementBlock("span", {
                        key: 2,
                        class: normalizeClass(["material-icons file-icon", { "hidden-file": file.is_hidden }])
                      }, toDisplayString(file.is_directory ? "folder" : "insert_drive_file"), 3))
                    ]),
                    createBaseVNode("div", _hoisted_23, [
                      createBaseVNode("div", {
                        class: normalizeClass(["file-name", { "hidden-file": file.is_hidden }])
                      }, toDisplayString(file.name), 3),
                      createBaseVNode("div", _hoisted_24, toDisplayString(formatFileSize(file.size)) + " • " + toDisplayString(formatDate(file.last_modified)), 1)
                    ])
                  ])
                ], 42, _hoisted_18);
              }), 128))
            ])),
            !loading.value && !error.value && filteredFiles.value.length === 0 ? (openBlock(), createElementBlock("div", _hoisted_25, [..._cache[12] || (_cache[12] = [
              createBaseVNode("span", { class: "material-icons" }, "folder_open", -1),
              createBaseVNode("span", null, "No files found", -1)
            ])])) : createCommentVNode("", true)
          ]),
          createBaseVNode("div", _hoisted_26, [
            __props.mode === "create" ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [
              selectedFile.value && !selectedFile.value.is_directory && __props.showWarningOnOverwrite ? (openBlock(), createBlock(_component_el_button, {
                key: 0,
                type: "warning",
                disabled: loading.value,
                size: "small",
                class: "browser-action-btn",
                onClick: confirmOverwrite
              }, {
                default: withCtx(() => [..._cache[13] || (_cache[13] = [
                  createBaseVNode("span", { class: "material-icons" }, "save", -1),
                  createTextVNode(" Overwrite File ", -1)
                ])]),
                _: 1
              }, 8, ["disabled"])) : (openBlock(), createBlock(_component_el_button, {
                key: 1,
                type: "primary",
                disabled: loading.value,
                size: "small",
                class: "browser-action-btn",
                onClick: _cache[3] || (_cache[3] = ($event) => showCreateDialog.value = true)
              }, {
                default: withCtx(() => [..._cache[14] || (_cache[14] = [
                  createBaseVNode("span", { class: "material-icons" }, "add", -1),
                  createTextVNode(" Create New File Here ", -1)
                ])]),
                _: 1
              }, 8, ["disabled"]))
            ], 64)) : createCommentVNode("", true),
            __props.allowDirectorySelection ? (openBlock(), createBlock(_component_el_button, {
              key: 1,
              type: "primary",
              disabled: loading.value,
              size: "small",
              class: "browser-action-btn",
              style: { "margin-right": "auto" },
              onClick: handleSelectDirectory
            }, {
              default: withCtx(() => [..._cache[15] || (_cache[15] = [
                createBaseVNode("span", { class: "material-icons" }, "folder", -1),
                createTextVNode(" Select This Directory ", -1)
              ])]),
              _: 1
            }, 8, ["disabled"])) : createCommentVNode("", true),
            __props.mode === "open" && selectedFile.value && !selectedFile.value.is_directory ? (openBlock(), createBlock(_component_el_button, {
              key: 2,
              type: "primary",
              disabled: loading.value,
              size: "small",
              class: "browser-action-btn",
              onClick: handleOpenFile
            }, {
              default: withCtx(() => [..._cache[16] || (_cache[16] = [
                createBaseVNode("span", { class: "material-icons" }, "open_in_new", -1),
                createTextVNode(" Open File ", -1)
              ])]),
              _: 1
            }, 8, ["disabled"])) : createCommentVNode("", true)
          ])
        ]),
        createVNode(_component_el_dialog, {
          modelValue: showCreateDialog.value,
          "onUpdate:modelValue": _cache[6] || (_cache[6] = ($event) => showCreateDialog.value = $event),
          title: "Create New File",
          width: "30%",
          "close-on-click-modal": false,
          onClosed: handleDialogClosed
        }, {
          footer: withCtx(() => [
            createBaseVNode("span", _hoisted_29, [
              createVNode(_component_el_button, {
                onClick: _cache[5] || (_cache[5] = ($event) => showCreateDialog.value = false)
              }, {
                default: withCtx(() => [..._cache[18] || (_cache[18] = [
                  createTextVNode("Cancel", -1)
                ])]),
                _: 1
              }),
              createVNode(_component_el_button, {
                type: "primary",
                disabled: !newFileName.value.trim(),
                onClick: handleCreateFile
              }, {
                default: withCtx(() => [..._cache[19] || (_cache[19] = [
                  createTextVNode(" Create ", -1)
                ])]),
                _: 1
              }, 8, ["disabled"])
            ])
          ]),
          default: withCtx(() => [
            createVNode(_component_el_form, {
              onSubmit: withModifiers(handleCreateFile, ["prevent"])
            }, {
              default: withCtx(() => [
                createVNode(_component_el_form_item, {
                  error: fileNameError.value,
                  label: "File Name"
                }, {
                  default: withCtx(() => [
                    createVNode(_component_el_input, {
                      ref: "fileNameInput",
                      modelValue: newFileName.value,
                      "onUpdate:modelValue": _cache[4] || (_cache[4] = ($event) => newFileName.value = $event),
                      placeholder: "Enter file name (e.g., my_flow)",
                      onKeyup: withKeys(handleCreateFile, ["enter"])
                    }, null, 8, ["modelValue"]),
                    newFileName.value.trim() ? (openBlock(), createElementBlock("div", _hoisted_27, [
                      _cache[17] || (_cache[17] = createBaseVNode("span", { class: "preview-label" }, "Will be saved as:", -1)),
                      createBaseVNode("code", null, toDisplayString(previewFileName.value), 1),
                      !hasValidExtension.value ? (openBlock(), createElementBlock("span", _hoisted_28)) : createCommentVNode("", true)
                    ])) : createCommentVNode("", true)
                  ]),
                  _: 1
                }, 8, ["error"])
              ]),
              _: 1
            })
          ]),
          _: 1
        }, 8, ["modelValue"])
      ]);
    };
  }
});
const FileBrowser = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-85296e16"]]);
export {
  ALLOWED_SAVE_EXTENSIONS as A,
  FileBrowser as F,
  FLOWFILE_EXTENSIONS as a
};
