import { E as EditorView, k as keymap, a as acceptCompletion, i as indentMore, b as indentLess, c as EditorState, d as autocompletion, P as Prec, T } from "./vue-codemirror.esm-DfAEZG05.js";
import { o as oneDark, p as python } from "./index-DgPd_2U1.js";
import CellOutput from "./CellOutput-CK2tu127.js";
import { d as defineComponent, c as createElementBlock, n as normalizeClass, a as createBaseVNode, t as toDisplayString, y as createVNode, z as unref, B as createBlock, e as createCommentVNode, f as createTextVNode, L as computed, o as openBlock, g as _export_sfc } from "./index-BAmalrlq.js";
const flowfileCompletionVals = [
  // flowfile module
  {
    label: "flowfile",
    type: "variable",
    info: "FlowFile API module for data I/O and artifacts"
  },
  // Data I/O functions
  {
    label: "read_input",
    type: "function",
    info: "Read input DataFrame. Optional name parameter for named inputs.",
    detail: "flowfile.read_input(name?)",
    apply: "read_input()"
  },
  {
    label: "read_inputs",
    type: "function",
    info: "Read all inputs as a dict of LazyFrame lists (one per connection).",
    detail: "flowfile.read_inputs() -> dict[str, list[LazyFrame]]",
    apply: "read_inputs()"
  },
  {
    label: "publish_output",
    type: "function",
    info: "Write output DataFrame. Optional name parameter for named outputs.",
    detail: "flowfile.publish_output(df, name?)",
    apply: "publish_output(df)"
  },
  // Display function
  {
    label: "display",
    type: "function",
    info: "Display a rich object (matplotlib figure, plotly figure, PIL image, HTML string) in the output panel.",
    detail: "flowfile.display(obj, title?)",
    apply: "display(obj)"
  },
  // Artifact functions
  {
    label: "publish_artifact",
    type: "function",
    info: "Store a Python object as a named artifact in kernel memory.",
    detail: 'flowfile.publish_artifact("name", obj)',
    apply: 'publish_artifact("name", obj)'
  },
  {
    label: "read_artifact",
    type: "function",
    info: "Retrieve a Python object from a named artifact.",
    detail: 'flowfile.read_artifact("name")',
    apply: 'read_artifact("name")'
  },
  {
    label: "delete_artifact",
    type: "function",
    info: "Remove a named artifact from kernel memory.",
    detail: 'flowfile.delete_artifact("name")',
    apply: 'delete_artifact("name")'
  },
  {
    label: "list_artifacts",
    type: "function",
    info: "List all artifacts available in the kernel. Returns list[ArtifactInfo] with .name, .type_name, .module, .node_id, .flow_id, .created_at, .size_bytes, .persisted fields.",
    detail: "flowfile.list_artifacts() -> list[ArtifactInfo]",
    apply: "list_artifacts()"
  },
  // Global Artifact functions
  {
    label: "publish_global",
    type: "function",
    info: "Persist a Python object to the global artifact store (survives across sessions).",
    detail: 'flowfile.publish_global("name", obj, description?, tags?, namespace_id?, fmt?)',
    apply: 'publish_global("name", obj)'
  },
  {
    label: "get_global",
    type: "function",
    info: "Retrieve a Python object from the global artifact store.",
    detail: 'flowfile.get_global("name", version?, namespace_id?)',
    apply: 'get_global("name")'
  },
  {
    label: "list_global_artifacts",
    type: "function",
    info: "List available global artifacts with optional namespace/tag filters. Returns list[GlobalArtifactInfo] with .id, .name, .version, .status, .python_type, .size_bytes, .created_at, .tags, .owner_id fields.",
    detail: "flowfile.list_global_artifacts(namespace_id?, tags?) -> list[GlobalArtifactInfo]",
    apply: "list_global_artifacts()"
  },
  {
    label: "get_shared_location",
    type: "function",
    info: "Get the shared location to make objects available to other processes",
    detail: "flowfile.get_shared_location()->str",
    apply: "get_shared_location()"
  },
  {
    label: "delete_global_artifact",
    type: "function",
    info: "Delete a global artifact by name, optionally a specific version.",
    detail: 'flowfile.delete_global_artifact("name", version?, namespace_id?)',
    apply: 'delete_global_artifact("name")'
  },
  // Logging functions
  {
    label: "log",
    type: "function",
    info: "Send a log message to the FlowFile log viewer.",
    detail: 'flowfile.log("message", level?)',
    apply: 'log("message")'
  },
  {
    label: "log_info",
    type: "function",
    info: "Send an INFO log message to the FlowFile log viewer.",
    detail: 'flowfile.log_info("message")',
    apply: 'log_info("message")'
  },
  {
    label: "log_warning",
    type: "function",
    info: "Send a WARNING log message to the FlowFile log viewer.",
    detail: 'flowfile.log_warning("message")',
    apply: 'log_warning("message")'
  },
  {
    label: "log_error",
    type: "function",
    info: "Send an ERROR log message to the FlowFile log viewer.",
    detail: 'flowfile.log_error("message")',
    apply: 'log_error("message")'
  },
  // Polars basics (also useful in python_script context)
  { label: "pl", type: "variable", info: "Polars main module" },
  { label: "col", type: "function", info: "Polars column selector" },
  { label: "lit", type: "function", info: "Polars literal value" },
  // Common Polars operations
  { label: "select", type: "method", info: "Select columns" },
  { label: "filter", type: "method", info: "Filter rows" },
  { label: "group_by", type: "method", info: "Group by columns" },
  { label: "with_columns", type: "method", info: "Add/modify columns" },
  { label: "join", type: "method", info: "Join operations" },
  { label: "sort", type: "method", info: "Sort DataFrame" },
  { label: "collect", type: "method", info: "Collect LazyFrame to DataFrame" },
  // Basic Python
  { label: "print", type: "function" },
  { label: "len", type: "function" },
  { label: "range", type: "function" },
  { label: "import", type: "keyword" }
];
const _hoisted_1 = { class: "cell-gutter" };
const _hoisted_2 = { class: "cell-content" };
const _hoisted_3 = { class: "cell-toolbar" };
const _hoisted_4 = ["disabled"];
const _hoisted_5 = ["disabled"];
const _hoisted_6 = ["disabled"];
const _hoisted_7 = ["disabled"];
const _hoisted_8 = { class: "cell-editor-wrapper" };
const _hoisted_9 = {
  key: 1,
  class: "cell-executing"
};
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "NotebookCell",
  props: {
    cell: {},
    cellIndex: {},
    isExecuting: { type: Boolean },
    isLastCell: { type: Boolean },
    cellCount: {}
  },
  emits: ["update:code", "run-cell", "run-cell-and-advance", "move-up", "move-down", "delete"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emit = __emit;
    const cellClasses = computed(() => {
      var _a;
      return {
        "cell--executing": props.isExecuting,
        "cell--error": (_a = props.cell.output) == null ? void 0 : _a.error
      };
    });
    const flowfileCompletions = (context) => {
      const word = context.matchBefore(/\w*/);
      if ((word == null ? void 0 : word.from) === (word == null ? void 0 : word.to) && !context.explicit) return null;
      return { from: (word == null ? void 0 : word.from) ?? 0, options: flowfileCompletionVals };
    };
    const cellEditorTheme = EditorView.theme({
      "&": {
        fontSize: "0.8rem",
        maxHeight: "350px"
      },
      ".cm-content": {
        minHeight: "40px",
        padding: "0.4rem 0",
        fontFamily: "'Fira Code', 'Monaco', 'Menlo', monospace"
      },
      ".cm-gutters": {
        fontSize: "0.7rem",
        minWidth: "2.5rem"
      },
      ".cm-scroller": {
        overflow: "auto"
      }
    });
    const notebookKeymap = keymap.of([
      {
        key: "Shift-Enter",
        run: () => {
          emit("run-cell");
          return true;
        }
      },
      {
        key: "Mod-Enter",
        // Ctrl+Enter on Windows/Linux, Cmd+Enter on Mac
        run: () => {
          emit("run-cell-and-advance");
          return true;
        }
      }
    ]);
    const tabKeymap = keymap.of([
      {
        key: "Tab",
        run: (view) => {
          if (acceptCompletion(view)) return true;
          return indentMore(view);
        }
      },
      {
        key: "Shift-Tab",
        run: (view) => {
          return indentLess(view);
        }
      }
    ]);
    const cellExtensions = [
      python(),
      oneDark,
      cellEditorTheme,
      EditorState.tabSize.of(4),
      autocompletion({
        override: [flowfileCompletions],
        defaultKeymap: true,
        closeOnBlur: false
      }),
      Prec.highest(notebookKeymap),
      Prec.high(tabKeymap)
    ];
    return (_ctx, _cache) => {
      var _a;
      return openBlock(), createElementBlock("div", {
        class: normalizeClass(["cell-wrapper", cellClasses.value])
      }, [
        createBaseVNode("div", _hoisted_1, "[" + toDisplayString(((_a = __props.cell.output) == null ? void 0 : _a.execution_count) ?? __props.cellIndex + 1) + "]", 1),
        createBaseVNode("div", _hoisted_2, [
          createBaseVNode("div", _hoisted_3, [
            createBaseVNode("button", {
              disabled: __props.isExecuting,
              title: "Run cell (Shift+Enter)",
              onClick: _cache[0] || (_cache[0] = ($event) => emit("run-cell"))
            }, [..._cache[5] || (_cache[5] = [
              createBaseVNode("i", { class: "fa-solid fa-play" }, null, -1)
            ])], 8, _hoisted_4),
            createBaseVNode("button", {
              disabled: __props.cellIndex === 0,
              title: "Move up",
              onClick: _cache[1] || (_cache[1] = ($event) => emit("move-up"))
            }, [..._cache[6] || (_cache[6] = [
              createBaseVNode("i", { class: "fa-solid fa-chevron-up" }, null, -1)
            ])], 8, _hoisted_5),
            createBaseVNode("button", {
              disabled: __props.isLastCell,
              title: "Move down",
              onClick: _cache[2] || (_cache[2] = ($event) => emit("move-down"))
            }, [..._cache[7] || (_cache[7] = [
              createBaseVNode("i", { class: "fa-solid fa-chevron-down" }, null, -1)
            ])], 8, _hoisted_6),
            createBaseVNode("button", {
              disabled: __props.cellCount <= 1,
              title: "Delete cell",
              onClick: _cache[3] || (_cache[3] = ($event) => emit("delete"))
            }, [..._cache[8] || (_cache[8] = [
              createBaseVNode("i", { class: "fa-solid fa-xmark" }, null, -1)
            ])], 8, _hoisted_7)
          ]),
          createBaseVNode("div", _hoisted_8, [
            createVNode(unref(T), {
              "model-value": __props.cell.code,
              placeholder: "# Enter code...",
              autofocus: false,
              "indent-with-tab": false,
              "tab-size": 4,
              extensions: cellExtensions,
              "onUpdate:modelValue": _cache[4] || (_cache[4] = (val) => emit("update:code", val))
            }, null, 8, ["model-value"])
          ]),
          __props.cell.output ? (openBlock(), createBlock(CellOutput, {
            key: 0,
            output: __props.cell.output
          }, null, 8, ["output"])) : createCommentVNode("", true),
          __props.isExecuting ? (openBlock(), createElementBlock("div", _hoisted_9, [..._cache[9] || (_cache[9] = [
            createBaseVNode("i", { class: "fas fa-spinner fa-spin" }, null, -1),
            createTextVNode(" Running... ", -1)
          ])])) : createCommentVNode("", true)
        ])
      ], 2);
    };
  }
});
const NotebookCellComponent = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-570ee672"]]);
export {
  NotebookCellComponent as default
};
