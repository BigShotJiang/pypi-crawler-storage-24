import { k as axios, d as defineComponent, l as useNodeStore, c as createElementBlock, a as createBaseVNode, f as createTextVNode, t as toDisplayString, e as createCommentVNode, y as createVNode, A as withCtx, h as withDirectives, au as vModelSelect, H as Fragment, I as renderList, aq as vShow, B as createBlock, r as ref, o as openBlock, g as _export_sfc } from "./index-BAmalrlq.js";
import { G as GenericNodeSettings } from "./genericNodeSettings-skGXb6PV.js";
import { _ as _sfc_main$3 } from "./MultiSelect.vue_vue_type_script_setup_true_lang-DqxhfYGZ.js";
import { _ as _sfc_main$5 } from "./ToggleSwitch.vue_vue_type_script_setup_true_lang-pw1BW-fQ.js";
import { _ as _sfc_main$1 } from "./TextInput.vue_vue_type_script_setup_true_lang-D8edAVC0.js";
import { _ as _sfc_main$2 } from "./NumericInput.vue_vue_type_script_setup_true_lang-DfTj-KVI.js";
import SliderInput from "./SliderInput-OC9ctw-u.js";
import { _ as _sfc_main$4 } from "./SingleSelect.vue_vue_type_script_setup_true_lang-D_HuXkMN.js";
import ColumnSelector from "./ColumnSelector-BoEY2wWY.js";
import SecretSelector from "./SecretSelector-dQnUVSbJ.js";
import ColumnActionInput from "./ColumnActionInput-DHYWcxu_.js";
import "./secrets.api-WJzOGLDO.js";
async function getCustomNodeSchema(flowId, nodeId) {
  const response = await axios.get(
    `/user_defined_components/custom-node-schema`,
    {
      params: { flow_id: flowId, node_id: nodeId },
      headers: { accept: "application/json" }
    }
  );
  return response.data;
}
const _hoisted_1 = {
  key: 0,
  class: "p-4 text-center text-gray-500"
};
const _hoisted_2 = {
  key: 1,
  class: "p-4 text-red-600 bg-red-100 rounded-md"
};
const _hoisted_3 = {
  key: 2,
  class: "custom-node-wrapper"
};
const _hoisted_4 = {
  key: 0,
  class: "listbox-subtitle"
};
const _hoisted_5 = {
  key: 0,
  class: "listbox-wrapper kernel-selector-section"
};
const _hoisted_6 = { class: "kernel-select-row" };
const _hoisted_7 = ["value"];
const _hoisted_8 = {
  key: 0,
  class: "kernel-error"
};
const _hoisted_9 = { class: "section-title" };
const _hoisted_10 = {
  key: 0,
  class: "section-description"
};
const _hoisted_11 = { class: "components-container" };
const _hoisted_12 = {
  key: 9,
  class: "text-red-500 text-xs"
};
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "CustomNode",
  setup(__props, { expose: __expose }) {
    const schema = ref(null);
    const formData = ref(null);
    const loading = ref(true);
    const error = ref("");
    const nodeStore = useNodeStore();
    const nodeData = ref(null);
    const availableColumns = ref([]);
    const currentNodeId = ref(null);
    const nodeUserDefined = ref(null);
    const columnTypes = ref([]);
    const artifactOptions = ref([]);
    const availableKernels = ref([]);
    const selectedKernelId = ref(null);
    const kernelRequiredError = ref(false);
    async function fetchKernels() {
      try {
        const response = await axios.get("/kernels/");
        availableKernels.value = response.data || [];
      } catch {
        availableKernels.value = [];
      }
    }
    async function fetchAvailableArtifacts(nodeId, kernelId) {
      var _a;
      try {
        const response = await axios.get("/flow/node_available_artifacts", {
          params: { flow_id: nodeStore.flow_id, node_id: nodeId, kernel_id: kernelId }
        });
        const artifacts = ((_a = response.data) == null ? void 0 : _a.artifacts) ?? [];
        artifactOptions.value = artifacts.map((artifact) => artifact.name);
      } catch {
        artifactOptions.value = [];
      }
    }
    const loadNodeData = async (nodeId) => {
      var _a, _b, _c, _d, _e;
      loading.value = true;
      error.value = "";
      currentNodeId.value = nodeId;
      try {
        const inputNodeData = await nodeStore.getNodeData(nodeId, false);
        if (!inputNodeData) {
          return;
        }
        const [schemaData] = await Promise.all([
          getCustomNodeSchema(nodeStore.flow_id, nodeId),
          fetchKernels()
        ]);
        schema.value = schemaData;
        nodeData.value = inputNodeData;
        nodeUserDefined.value = (_a = nodeData.value) == null ? void 0 : _a.setting_input;
        if (!((_b = nodeData.value) == null ? void 0 : _b.setting_input.is_setup) && nodeUserDefined.value) {
          nodeUserDefined.value.settings = {};
        }
        selectedKernelId.value = ((_c = nodeUserDefined.value) == null ? void 0 : _c.kernel_id) ?? schemaData.kernel_id ?? null;
        kernelRequiredError.value = !!schemaData.requires_kernel && !selectedKernelId.value;
        const mainColumns = ((_d = inputNodeData == null ? void 0 : inputNodeData.main_input) == null ? void 0 : _d.columns) ?? [];
        if (mainColumns.length) {
          availableColumns.value = mainColumns;
          columnTypes.value = ((_e = inputNodeData.main_input) == null ? void 0 : _e.table_schema) ?? [];
        } else {
          console.warn(
            `No main_input or columns found for node ${nodeId}. Select components may be empty.`
          );
        }
        await fetchAvailableArtifacts(nodeId, selectedKernelId.value ?? schemaData.kernel_id ?? null);
        initializeFormData(schemaData, inputNodeData == null ? void 0 : inputNodeData.setting_input);
      } catch (err) {
        error.value = err.message || "An unknown error occurred while loading node data.";
      } finally {
        loading.value = false;
      }
    };
    const pushNodeData = async () => {
      var _a, _b;
      if (!nodeData.value || currentNodeId.value === null) {
        console.warn("Cannot push data: node data or ID is not available.");
        return;
      }
      if (nodeUserDefined.value) {
        kernelRequiredError.value = !!((_a = schema.value) == null ? void 0 : _a.requires_kernel) && !selectedKernelId.value;
        nodeUserDefined.value.settings = formData.value;
        nodeUserDefined.value.is_user_defined = true;
        nodeUserDefined.value.is_setup = true;
        nodeUserDefined.value.kernel_id = selectedKernelId.value;
        if ((_b = schema.value) == null ? void 0 : _b.output_names) {
          nodeUserDefined.value.output_names = schema.value.output_names;
        }
      }
      nodeStore.updateUserDefinedSettings(nodeUserDefined);
    };
    function initializeFormData(schemaData, savedSettings) {
      var _a;
      const data = {};
      for (const sectionKey in schemaData.settings_schema) {
        data[sectionKey] = {};
        const section = schemaData.settings_schema[sectionKey];
        for (const componentKey in section.components) {
          const component = section.components[componentKey];
          const savedValue = (_a = savedSettings == null ? void 0 : savedSettings[sectionKey]) == null ? void 0 : _a[componentKey];
          if (savedValue !== void 0) {
            data[sectionKey][componentKey] = savedValue;
          } else if (component.value !== void 0) {
            data[sectionKey][componentKey] = component.value;
          } else {
            let defaultValue = component.default ?? null;
            if (component.input_type === "array" && defaultValue === null) {
              defaultValue = [];
            }
            data[sectionKey][componentKey] = defaultValue;
          }
        }
      }
      formData.value = data;
    }
    __expose({
      loadNodeData,
      pushNodeData
    });
    return (_ctx, _cache) => {
      return loading.value ? (openBlock(), createElementBlock("div", _hoisted_1, "Loading Node UI...")) : error.value ? (openBlock(), createElementBlock("div", _hoisted_2, [
        _cache[2] || (_cache[2] = createBaseVNode("strong", null, "Error:", -1)),
        createTextVNode(" " + toDisplayString(error.value), 1)
      ])) : schema.value && formData.value && nodeUserDefined.value ? (openBlock(), createElementBlock("div", _hoisted_3, [
        schema.value.intro ? (openBlock(), createElementBlock("div", _hoisted_4, toDisplayString(schema.value.intro), 1)) : createCommentVNode("", true),
        createVNode(GenericNodeSettings, {
          modelValue: nodeUserDefined.value,
          "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => nodeUserDefined.value = $event)
        }, {
          default: withCtx(() => [
            schema.value.requires_kernel ? (openBlock(), createElementBlock("div", _hoisted_5, [
              _cache[6] || (_cache[6] = createBaseVNode("div", { class: "section-title" }, "Execution", -1)),
              createBaseVNode("div", _hoisted_6, [
                _cache[5] || (_cache[5] = createBaseVNode("label", {
                  class: "kernel-label",
                  for: "kernel-select"
                }, "Kernel", -1)),
                withDirectives(createBaseVNode("select", {
                  id: "kernel-select",
                  "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => selectedKernelId.value = $event),
                  class: "kernel-select"
                }, [
                  _cache[4] || (_cache[4] = createBaseVNode("option", { value: null }, "Local (default)", -1)),
                  (openBlock(true), createElementBlock(Fragment, null, renderList(availableKernels.value, (k) => {
                    return openBlock(), createElementBlock("option", {
                      key: k.id,
                      value: k.id
                    }, [
                      createTextVNode(toDisplayString(k.name) + " ", 1),
                      k.packages.length ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [
                        createTextVNode(" (" + toDisplayString(k.packages.slice(0, 3).join(", ")), 1),
                        k.packages.length > 3 ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [
                          createTextVNode("...")
                        ], 64)) : createCommentVNode("", true),
                        _cache[3] || (_cache[3] = createTextVNode(") ", -1))
                      ], 64)) : createCommentVNode("", true)
                    ], 8, _hoisted_7);
                  }), 128))
                ], 512), [
                  [vModelSelect, selectedKernelId.value]
                ])
              ]),
              kernelRequiredError.value ? (openBlock(), createElementBlock("div", _hoisted_8, " Kernel execution is required for this node. Select a kernel to enable it. ")) : createCommentVNode("", true)
            ])) : createCommentVNode("", true),
            (openBlock(true), createElementBlock(Fragment, null, renderList(schema.value.settings_schema, (section, sectionKey) => {
              return withDirectives((openBlock(), createElementBlock("div", {
                key: sectionKey,
                class: "listbox-wrapper"
              }, [
                createBaseVNode("div", _hoisted_9, toDisplayString(section.title || sectionKey.toString().replace(/_/g, " ")), 1),
                section.description ? (openBlock(), createElementBlock("p", _hoisted_10, toDisplayString(section.description), 1)) : createCommentVNode("", true),
                createBaseVNode("div", _hoisted_11, [
                  (openBlock(true), createElementBlock(Fragment, null, renderList(section.components, (component, componentKey) => {
                    return openBlock(), createElementBlock("div", {
                      key: componentKey,
                      class: "component-item"
                    }, [
                      component.component_type === "TextInput" ? (openBlock(), createBlock(_sfc_main$1, {
                        key: 0,
                        modelValue: formData.value[sectionKey][componentKey],
                        "onUpdate:modelValue": ($event) => formData.value[sectionKey][componentKey] = $event,
                        schema: component
                      }, null, 8, ["modelValue", "onUpdate:modelValue", "schema"])) : component.component_type === "NumericInput" ? (openBlock(), createBlock(_sfc_main$2, {
                        key: 1,
                        modelValue: formData.value[sectionKey][componentKey],
                        "onUpdate:modelValue": ($event) => formData.value[sectionKey][componentKey] = $event,
                        schema: component
                      }, null, 8, ["modelValue", "onUpdate:modelValue", "schema"])) : component.component_type === "SliderInput" ? (openBlock(), createBlock(SliderInput, {
                        key: 2,
                        modelValue: formData.value[sectionKey][componentKey],
                        "onUpdate:modelValue": ($event) => formData.value[sectionKey][componentKey] = $event,
                        schema: component
                      }, null, 8, ["modelValue", "onUpdate:modelValue", "schema"])) : component.component_type === "MultiSelect" ? (openBlock(), createBlock(_sfc_main$3, {
                        key: 3,
                        modelValue: formData.value[sectionKey][componentKey],
                        "onUpdate:modelValue": ($event) => formData.value[sectionKey][componentKey] = $event,
                        schema: component,
                        "incoming-columns": availableColumns.value,
                        "available-artifacts": artifactOptions.value
                      }, null, 8, ["modelValue", "onUpdate:modelValue", "schema", "incoming-columns", "available-artifacts"])) : component.component_type === "SingleSelect" ? (openBlock(), createBlock(_sfc_main$4, {
                        key: 4,
                        modelValue: formData.value[sectionKey][componentKey],
                        "onUpdate:modelValue": ($event) => formData.value[sectionKey][componentKey] = $event,
                        schema: component,
                        "incoming-columns": availableColumns.value,
                        "available-artifacts": artifactOptions.value
                      }, null, 8, ["modelValue", "onUpdate:modelValue", "schema", "incoming-columns", "available-artifacts"])) : component.component_type === "ToggleSwitch" ? (openBlock(), createBlock(_sfc_main$5, {
                        key: 5,
                        modelValue: formData.value[sectionKey][componentKey],
                        "onUpdate:modelValue": ($event) => formData.value[sectionKey][componentKey] = $event,
                        schema: component
                      }, null, 8, ["modelValue", "onUpdate:modelValue", "schema"])) : component.component_type === "ColumnSelector" ? (openBlock(), createBlock(ColumnSelector, {
                        key: 6,
                        modelValue: formData.value[sectionKey][componentKey],
                        "onUpdate:modelValue": ($event) => formData.value[sectionKey][componentKey] = $event,
                        schema: component,
                        "incoming-columns": columnTypes.value
                      }, null, 8, ["modelValue", "onUpdate:modelValue", "schema", "incoming-columns"])) : component.component_type === "SecretSelector" ? (openBlock(), createBlock(SecretSelector, {
                        key: 7,
                        modelValue: formData.value[sectionKey][componentKey],
                        "onUpdate:modelValue": ($event) => formData.value[sectionKey][componentKey] = $event,
                        schema: component
                      }, null, 8, ["modelValue", "onUpdate:modelValue", "schema"])) : component.component_type === "ColumnActionInput" ? (openBlock(), createBlock(ColumnActionInput, {
                        key: 8,
                        modelValue: formData.value[sectionKey][componentKey],
                        "onUpdate:modelValue": ($event) => formData.value[sectionKey][componentKey] = $event,
                        schema: component,
                        "incoming-columns": columnTypes.value
                      }, null, 8, ["modelValue", "onUpdate:modelValue", "schema", "incoming-columns"])) : (openBlock(), createElementBlock("div", _hoisted_12, " Unknown component type: " + toDisplayString(component.component_type), 1))
                    ]);
                  }), 128))
                ])
              ])), [
                [vShow, !section.hidden]
              ]);
            }), 128))
          ]),
          _: 1
        }, 8, ["modelValue"])
      ])) : createCommentVNode("", true);
    };
  }
});
const CustomNode = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-6ec68198"]]);
export {
  CustomNode as default
};
