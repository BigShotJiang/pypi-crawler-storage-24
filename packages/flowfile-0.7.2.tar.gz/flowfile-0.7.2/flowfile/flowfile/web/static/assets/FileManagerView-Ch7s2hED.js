import { k as axios, r as ref, L as computed, d as defineComponent, G as onMounted, c as createElementBlock, a as createBaseVNode, w as withModifiers, n as normalizeClass, H as Fragment, I as renderList, e as createCommentVNode, t as toDisplayString, z as unref, h as withDirectives, v as vModelText, a3 as isRef, f as createTextVNode, Y as normalizeStyle, o as openBlock, g as _export_sfc } from "./index-BAmalrlq.js";
const API_BASE = "/file_manager";
class FileManagerApi {
  static async listFiles() {
    const response = await axios.get(`${API_BASE}/files`);
    return response.data;
  }
  static async uploadFile(file, onProgress) {
    const formData = new FormData();
    formData.append("file", file);
    const response = await axios.post(`${API_BASE}/upload`, formData, {
      headers: { "Content-Type": "multipart/form-data" },
      onUploadProgress: (e) => {
        if (onProgress && e.total) {
          onProgress(Math.round(e.loaded * 100 / e.total));
        }
      }
    });
    return response.data;
  }
  static async deleteFile(filename) {
    await axios.delete(`${API_BASE}/files/${encodeURIComponent(filename)}`);
  }
}
function useFileManager() {
  const files = ref([]);
  const isLoading = ref(true);
  const searchTerm = ref("");
  const filteredFiles = computed(() => {
    const sorted = [...files.value].sort((a, b) => a.name.localeCompare(b.name));
    if (!searchTerm.value) return sorted;
    const term = searchTerm.value.toLowerCase();
    return sorted.filter((f) => f.name.toLowerCase().includes(term));
  });
  const loadFiles = async () => {
    isLoading.value = true;
    try {
      files.value = await FileManagerApi.listFiles();
    } catch (error) {
      console.error("Failed to load files:", error);
      files.value = [];
      throw error;
    } finally {
      isLoading.value = false;
    }
  };
  const uploadFile = async (file, onProgress) => {
    const result = await FileManagerApi.uploadFile(file, onProgress);
    await loadFiles();
    return result;
  };
  const deleteFile = async (filename) => {
    await FileManagerApi.deleteFile(filename);
    await loadFiles();
    return filename;
  };
  return {
    files,
    filteredFiles,
    isLoading,
    searchTerm,
    loadFiles,
    uploadFile,
    deleteFile
  };
}
const _hoisted_1 = { class: "file-manager-container" };
const _hoisted_2 = { class: "card mb-3" };
const _hoisted_3 = { class: "card-content" };
const _hoisted_4 = {
  key: 0,
  class: "upload-queue"
};
const _hoisted_5 = { class: "upload-queue__info" };
const _hoisted_6 = { class: "upload-queue__name" };
const _hoisted_7 = { class: "upload-queue__status" };
const _hoisted_8 = { class: "upload-queue__progress-bar" };
const _hoisted_9 = { class: "upload-queue__percent" };
const _hoisted_10 = {
  key: 1,
  class: "fa-solid fa-check upload-queue__done"
};
const _hoisted_11 = {
  key: 2,
  class: "upload-queue__error"
};
const _hoisted_12 = { class: "card" };
const _hoisted_13 = { class: "card-header" };
const _hoisted_14 = { class: "card-title" };
const _hoisted_15 = {
  key: 0,
  class: "search-container"
};
const _hoisted_16 = { class: "card-content" };
const _hoisted_17 = {
  key: 0,
  class: "loading-state"
};
const _hoisted_18 = {
  key: 1,
  class: "empty-state"
};
const _hoisted_19 = {
  key: 2,
  class: "connections-list"
};
const _hoisted_20 = { class: "connection-info" };
const _hoisted_21 = { class: "connection-name" };
const _hoisted_22 = { class: "file-badge" };
const _hoisted_23 = { class: "file-meta" };
const _hoisted_24 = { class: "connection-actions" };
const _hoisted_25 = ["aria-label", "onClick"];
const _hoisted_26 = {
  key: 3,
  class: "empty-state"
};
const _hoisted_27 = { class: "modal-content" };
const _hoisted_28 = { class: "modal-actions" };
const _hoisted_29 = ["disabled"];
const _hoisted_30 = {
  key: 0,
  class: "fas fa-spinner fa-spin"
};
const acceptString = ".csv,.parquet,.xlsx,.xls,.json,.txt,.tsv";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "FileManagerView",
  setup(__props) {
    const { files, filteredFiles, isLoading, searchTerm, loadFiles, uploadFile, deleteFile } = useFileManager();
    const fileInput = ref(null);
    const isDragging = ref(false);
    const uploadQueue = ref([]);
    const showDeleteModal = ref(false);
    const fileToDelete = ref("");
    const isDeleting = ref(false);
    function openFilePicker() {
      var _a;
      (_a = fileInput.value) == null ? void 0 : _a.click();
    }
    function handleFileSelect(event) {
      const input = event.target;
      if (input.files) {
        processFiles(Array.from(input.files));
        input.value = "";
      }
    }
    function handleDrop(event) {
      var _a;
      isDragging.value = false;
      if ((_a = event.dataTransfer) == null ? void 0 : _a.files) {
        processFiles(Array.from(event.dataTransfer.files));
      }
    }
    async function processFiles(fileList) {
      var _a, _b;
      for (const file of fileList) {
        const item = {
          name: file.name,
          status: "uploading",
          progress: 0
        };
        uploadQueue.value.push(item);
        try {
          await uploadFile(file, (percent) => {
            item.progress = percent;
          });
          item.status = "done";
          item.progress = 100;
        } catch (error) {
          item.status = "error";
          item.error = ((_b = (_a = error.response) == null ? void 0 : _a.data) == null ? void 0 : _b.detail) || error.message || "Upload failed";
        }
      }
      setTimeout(() => {
        uploadQueue.value = uploadQueue.value.filter((i) => i.status === "uploading");
      }, 3e3);
    }
    function handleConfirmDelete(filename) {
      fileToDelete.value = filename;
      showDeleteModal.value = true;
    }
    function cancelDelete() {
      showDeleteModal.value = false;
      fileToDelete.value = "";
    }
    async function handleDeleteFile() {
      if (!fileToDelete.value) return;
      isDeleting.value = true;
      try {
        await deleteFile(fileToDelete.value);
        cancelDelete();
      } catch {
        alert("Failed to delete file. Please try again.");
        cancelDelete();
      } finally {
        isDeleting.value = false;
      }
    }
    function getFileIcon(filename) {
      var _a;
      const ext = ((_a = filename.split(".").pop()) == null ? void 0 : _a.toLowerCase()) || "";
      const icons = {
        csv: "fa-solid fa-file-csv",
        tsv: "fa-solid fa-file-csv",
        parquet: "fa-solid fa-database",
        xlsx: "fa-solid fa-file-excel",
        xls: "fa-solid fa-file-excel",
        json: "fa-solid fa-file-code",
        txt: "fa-solid fa-file-lines"
      };
      return icons[ext] || "fa-solid fa-file";
    }
    function formatSize(bytes) {
      if (bytes === 0) return "0 B";
      const units = ["B", "KB", "MB", "GB"];
      const i = Math.floor(Math.log(bytes) / Math.log(1024));
      return (bytes / Math.pow(1024, i)).toFixed(i > 0 ? 1 : 0) + " " + units[i];
    }
    function formatDate(dateStr) {
      const d = new Date(dateStr);
      return d.toLocaleDateString(void 0, {
        year: "numeric",
        month: "short",
        day: "numeric",
        hour: "2-digit",
        minute: "2-digit"
      });
    }
    onMounted(() => {
      loadFiles().catch(() => {
        alert("Failed to load files. Please try again.");
      });
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1, [
        _cache[18] || (_cache[18] = createBaseVNode("div", { class: "mb-3" }, [
          createBaseVNode("h2", { class: "page-title" }, "File Manager"),
          createBaseVNode("p", { class: "page-description" }, "Upload and manage data files in the shared directory")
        ], -1)),
        createBaseVNode("div", _hoisted_2, [
          _cache[7] || (_cache[7] = createBaseVNode("div", { class: "card-header" }, [
            createBaseVNode("h3", { class: "card-title" }, "Upload Files")
          ], -1)),
          createBaseVNode("div", _hoisted_3, [
            createBaseVNode("div", {
              class: normalizeClass(["upload-zone", { "upload-zone--active": isDragging.value }]),
              onDragover: _cache[0] || (_cache[0] = withModifiers(($event) => isDragging.value = true, ["prevent"])),
              onDragleave: _cache[1] || (_cache[1] = withModifiers(($event) => isDragging.value = false, ["prevent"])),
              onDrop: withModifiers(handleDrop, ["prevent"]),
              onClick: openFilePicker
            }, [
              _cache[4] || (_cache[4] = createBaseVNode("i", { class: "fa-solid fa-cloud-arrow-up upload-zone__icon" }, null, -1)),
              _cache[5] || (_cache[5] = createBaseVNode("p", { class: "upload-zone__text" }, "Drag and drop files here, or click to browse", -1)),
              _cache[6] || (_cache[6] = createBaseVNode("p", { class: "upload-zone__hint" }, " Supported: CSV, Parquet, Excel (.xlsx/.xls), JSON, TXT, TSV ", -1)),
              createBaseVNode("input", {
                ref_key: "fileInput",
                ref: fileInput,
                type: "file",
                multiple: "",
                accept: acceptString,
                class: "upload-zone__input",
                onChange: handleFileSelect
              }, null, 544)
            ], 34),
            uploadQueue.value.length > 0 ? (openBlock(), createElementBlock("div", _hoisted_4, [
              (openBlock(true), createElementBlock(Fragment, null, renderList(uploadQueue.value, (item) => {
                return openBlock(), createElementBlock("div", {
                  key: item.name,
                  class: "upload-queue__item"
                }, [
                  createBaseVNode("div", _hoisted_5, [
                    createBaseVNode("i", {
                      class: normalizeClass([getFileIcon(item.name), "upload-queue__file-icon"])
                    }, null, 2),
                    createBaseVNode("span", _hoisted_6, toDisplayString(item.name), 1)
                  ]),
                  createBaseVNode("div", _hoisted_7, [
                    item.status === "uploading" ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [
                      createBaseVNode("div", _hoisted_8, [
                        createBaseVNode("div", {
                          class: "upload-queue__progress-fill",
                          style: normalizeStyle({ width: item.progress + "%" })
                        }, null, 4)
                      ]),
                      createBaseVNode("span", _hoisted_9, toDisplayString(item.progress) + "%", 1)
                    ], 64)) : item.status === "done" ? (openBlock(), createElementBlock("i", _hoisted_10)) : item.status === "error" ? (openBlock(), createElementBlock("span", _hoisted_11, toDisplayString(item.error), 1)) : createCommentVNode("", true)
                  ])
                ]);
              }), 128))
            ])) : createCommentVNode("", true)
          ])
        ]),
        createBaseVNode("div", _hoisted_12, [
          createBaseVNode("div", _hoisted_13, [
            createBaseVNode("h3", _hoisted_14, "Files (" + toDisplayString(unref(filteredFiles).length) + ")", 1),
            unref(files).length > 0 ? (openBlock(), createElementBlock("div", _hoisted_15, [
              withDirectives(createBaseVNode("input", {
                "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => isRef(searchTerm) ? searchTerm.value = $event : null),
                type: "text",
                placeholder: "Search files...",
                class: "search-input",
                "aria-label": "Search files"
              }, null, 512), [
                [vModelText, unref(searchTerm)]
              ]),
              _cache[8] || (_cache[8] = createBaseVNode("i", { class: "fa-solid fa-search search-icon" }, null, -1))
            ])) : createCommentVNode("", true)
          ]),
          createBaseVNode("div", _hoisted_16, [
            unref(isLoading) ? (openBlock(), createElementBlock("div", _hoisted_17, [..._cache[9] || (_cache[9] = [
              createBaseVNode("div", { class: "loading-spinner" }, null, -1),
              createBaseVNode("p", null, "Loading files...", -1)
            ])])) : unref(files).length === 0 ? (openBlock(), createElementBlock("div", _hoisted_18, [..._cache[10] || (_cache[10] = [
              createBaseVNode("i", { class: "fa-solid fa-folder-open" }, null, -1),
              createBaseVNode("p", null, "No files uploaded yet", -1),
              createBaseVNode("p", null, "Upload CSV, Parquet, Excel, JSON, or text files to get started", -1)
            ])])) : unref(filteredFiles).length > 0 ? (openBlock(), createElementBlock("div", _hoisted_19, [
              (openBlock(true), createElementBlock(Fragment, null, renderList(unref(filteredFiles), (file) => {
                return openBlock(), createElementBlock("div", {
                  key: file.name,
                  class: "connection-item"
                }, [
                  createBaseVNode("div", _hoisted_20, [
                    createBaseVNode("div", _hoisted_21, [
                      createBaseVNode("i", {
                        class: normalizeClass(getFileIcon(file.name))
                      }, null, 2),
                      createBaseVNode("span", null, toDisplayString(file.name), 1),
                      createBaseVNode("span", _hoisted_22, toDisplayString(file.file_type.toUpperCase()), 1)
                    ]),
                    createBaseVNode("span", _hoisted_23, toDisplayString(formatSize(file.size)) + " · Modified " + toDisplayString(formatDate(file.last_modified)), 1)
                  ]),
                  createBaseVNode("div", _hoisted_24, [
                    createBaseVNode("button", {
                      type: "button",
                      class: "btn btn-danger btn-sm",
                      "aria-label": `Delete file ${file.name}`,
                      onClick: ($event) => handleConfirmDelete(file.name)
                    }, [..._cache[11] || (_cache[11] = [
                      createBaseVNode("i", { class: "fa-solid fa-trash-alt" }, null, -1),
                      createBaseVNode("span", null, "Delete", -1)
                    ])], 8, _hoisted_25)
                  ])
                ]);
              }), 128))
            ])) : (openBlock(), createElementBlock("div", _hoisted_26, [
              _cache[12] || (_cache[12] = createBaseVNode("i", { class: "fa-solid fa-search" }, null, -1)),
              createBaseVNode("p", null, 'No files found matching "' + toDisplayString(unref(searchTerm)) + '"', 1)
            ]))
          ])
        ]),
        showDeleteModal.value ? (openBlock(), createElementBlock("div", {
          key: 0,
          class: "modal-overlay",
          onClick: cancelDelete
        }, [
          createBaseVNode("div", {
            class: "modal-container",
            onClick: _cache[3] || (_cache[3] = withModifiers(() => {
            }, ["stop"]))
          }, [
            createBaseVNode("div", { class: "modal-header" }, [
              _cache[14] || (_cache[14] = createBaseVNode("h3", { class: "modal-title" }, "Delete File", -1)),
              createBaseVNode("button", {
                class: "modal-close",
                "aria-label": "Close delete confirmation",
                onClick: cancelDelete
              }, [..._cache[13] || (_cache[13] = [
                createBaseVNode("i", { class: "fa-solid fa-times" }, null, -1)
              ])])
            ]),
            createBaseVNode("div", _hoisted_27, [
              createBaseVNode("p", null, [
                _cache[15] || (_cache[15] = createTextVNode(" Are you sure you want to delete ", -1)),
                createBaseVNode("strong", null, toDisplayString(fileToDelete.value), 1),
                _cache[16] || (_cache[16] = createTextVNode("? ", -1))
              ]),
              _cache[17] || (_cache[17] = createBaseVNode("p", { class: "warning-text" }, " This action cannot be undone. Any flows referencing this file will need to be updated. ", -1))
            ]),
            createBaseVNode("div", _hoisted_28, [
              createBaseVNode("button", {
                class: "btn btn-secondary",
                onClick: cancelDelete
              }, "Cancel"),
              createBaseVNode("button", {
                class: "btn btn-danger-filled",
                disabled: isDeleting.value,
                onClick: handleDeleteFile
              }, [
                isDeleting.value ? (openBlock(), createElementBlock("i", _hoisted_30)) : createCommentVNode("", true),
                createTextVNode(" " + toDisplayString(isDeleting.value ? "Deleting..." : "Delete File"), 1)
              ], 8, _hoisted_29)
            ])
          ])
        ])) : createCommentVNode("", true)
      ]);
    };
  }
});
const FileManagerView = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-0cd11c7a"]]);
export {
  FileManagerView as default
};
