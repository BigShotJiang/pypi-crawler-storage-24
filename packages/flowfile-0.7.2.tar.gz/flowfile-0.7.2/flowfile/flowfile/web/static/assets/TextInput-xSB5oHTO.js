import { _ as _sfc_main } from "./TextInput.vue_vue_type_script_setup_true_lang-D8edAVC0.js";
import "./index-BAmalrlq.js";
export {
  _sfc_main as default
};
