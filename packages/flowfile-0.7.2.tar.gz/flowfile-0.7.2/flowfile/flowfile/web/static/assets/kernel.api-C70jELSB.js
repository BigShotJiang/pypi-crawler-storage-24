import { k as axios } from "./index-BAmalrlq.js";
const API_BASE_URL = "/kernels";
class KernelApi {
  static async getAll() {
    var _a, _b;
    try {
      const response = await axios.get(`${API_BASE_URL}/`);
      return response.data;
    } catch (error) {
      console.error("API Error: Failed to load kernels:", error);
      const errorMsg = ((_b = (_a = error.response) == null ? void 0 : _a.data) == null ? void 0 : _b.detail) || "Failed to load kernels";
      throw new Error(errorMsg);
    }
  }
  static async get(kernelId) {
    try {
      const response = await axios.get(
        `${API_BASE_URL}/${encodeURIComponent(kernelId)}`
      );
      return response.data;
    } catch (error) {
      console.error("API Error: Failed to get kernel:", error);
      throw error;
    }
  }
  static async create(config) {
    var _a, _b;
    try {
      const response = await axios.post(`${API_BASE_URL}/`, config);
      return response.data;
    } catch (error) {
      console.error("API Error: Failed to create kernel:", error);
      const errorMsg = ((_b = (_a = error.response) == null ? void 0 : _a.data) == null ? void 0 : _b.detail) || "Failed to create kernel";
      throw new Error(errorMsg);
    }
  }
  static async delete(kernelId) {
    try {
      await axios.delete(`${API_BASE_URL}/${encodeURIComponent(kernelId)}`);
    } catch (error) {
      console.error("API Error: Failed to delete kernel:", error);
      throw error;
    }
  }
  static async start(kernelId) {
    var _a, _b;
    try {
      const response = await axios.post(
        `${API_BASE_URL}/${encodeURIComponent(kernelId)}/start`
      );
      return response.data;
    } catch (error) {
      console.error("API Error: Failed to start kernel:", error);
      const errorMsg = ((_b = (_a = error.response) == null ? void 0 : _a.data) == null ? void 0 : _b.detail) || "Failed to start kernel";
      throw new Error(errorMsg);
    }
  }
  static async stop(kernelId) {
    try {
      await axios.post(`${API_BASE_URL}/${encodeURIComponent(kernelId)}/stop`);
    } catch (error) {
      console.error("API Error: Failed to stop kernel:", error);
      throw error;
    }
  }
  static async getArtifacts(kernelId) {
    try {
      const response = await axios.get(
        `${API_BASE_URL}/${encodeURIComponent(kernelId)}/artifacts`
      );
      return response.data;
    } catch (error) {
      console.error("API Error: Failed to get artifacts:", error);
      return {};
    }
  }
  static async getDockerStatus() {
    try {
      const response = await axios.get(`${API_BASE_URL}/docker-status`);
      return response.data;
    } catch (error) {
      console.error("API Error: Failed to check Docker status:", error);
      return { available: false, image_available: false, error: "Failed to reach server" };
    }
  }
  static async executeCell(kernelId, request) {
    var _a, _b;
    try {
      const response = await axios.post(
        `${API_BASE_URL}/${encodeURIComponent(kernelId)}/execute_cell`,
        request
      );
      return response.data;
    } catch (error) {
      console.error("API Error: Failed to execute cell:", error);
      const errorMsg = ((_b = (_a = error.response) == null ? void 0 : _a.data) == null ? void 0 : _b.detail) || "Failed to execute cell";
      throw new Error(errorMsg);
    }
  }
  static async clearNamespace(kernelId, flowId) {
    var _a, _b;
    const url = `${API_BASE_URL}/${encodeURIComponent(kernelId)}/clear_namespace`;
    try {
      await axios.post(url, null, { params: { flow_id: flowId } });
    } catch (error) {
      console.error("API Error: Failed to clear namespace:", error);
      const errorMsg = ((_b = (_a = error.response) == null ? void 0 : _a.data) == null ? void 0 : _b.detail) || "Failed to clear namespace";
      throw new Error(errorMsg);
    }
  }
  static async getDisplayOutputs(kernelId, flowId, nodeId) {
    try {
      const response = await axios.get(
        `${API_BASE_URL}/${encodeURIComponent(kernelId)}/display_outputs`,
        { params: { flow_id: flowId, node_id: nodeId } }
      );
      return response.data;
    } catch {
      return [];
    }
  }
  static async getMemoryStats(kernelId) {
    try {
      const response = await axios.get(
        `${API_BASE_URL}/${encodeURIComponent(kernelId)}/memory`
      );
      return response.data;
    } catch {
      return null;
    }
  }
}
export {
  KernelApi as K
};
