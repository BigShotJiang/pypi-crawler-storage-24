import { K as defineStore, d as defineComponent, D as watch, c as createElementBlock, a as createBaseVNode, n as normalizeClass, t as toDisplayString, e as createCommentVNode, w as withModifiers, H as Fragment, I as renderList, y as createVNode, L as computed, r as ref, C as resolveComponent, o as openBlock, g as _export_sfc, f as createTextVNode, h as withDirectives, v as vModelText, ay as withKeys, Z as nextTick, b as createStaticVNode, B as createBlock, al as Teleport, au as vModelSelect, J as ElMessage, aj as useFlowStore, G as onMounted, A as withCtx, z as unref, av as vModelCheckbox, F as FlowApi, j as useRouter } from "./index-BAmalrlq.js";
import { C as CatalogApi } from "./catalog.api-Ym5X6s3O.js";
import { F as FileBrowser } from "./fileBrowser-B9lrIIDi.js";
const useCatalogStore = defineStore("catalog", {
  state: () => ({
    tree: [],
    allFlows: [],
    favorites: [],
    following: [],
    runs: [],
    stats: null,
    selectedFlowId: null,
    selectedRunId: null,
    selectedRunDetail: null,
    selectedArtifactId: null,
    selectedArtifact: null,
    flowArtifacts: [],
    loadingArtifacts: false,
    selectedTableId: null,
    selectedTable: null,
    tablePreview: null,
    loadingTablePreview: false,
    allTables: [],
    activeTab: "catalog",
    loading: false,
    error: null
  }),
  getters: {
    selectedFlow: (state) => state.allFlows.find((f) => f.id === state.selectedFlowId) ?? null,
    flowRuns: (state) => {
      if (state.selectedFlowId === null) return state.runs;
      return state.runs.filter((r) => r.registration_id === state.selectedFlowId);
    }
  },
  actions: {
    async loadTree() {
      this.loading = true;
      this.error = null;
      try {
        this.tree = await CatalogApi.getNamespaceTree();
      } catch (e) {
        this.error = (e == null ? void 0 : e.message) ?? "Failed to load catalog tree";
      } finally {
        this.loading = false;
      }
    },
    async loadAllFlows() {
      try {
        this.allFlows = await CatalogApi.getFlows();
      } catch (e) {
        this.error = (e == null ? void 0 : e.message) ?? "Failed to load flows";
      }
    },
    async loadFavorites() {
      try {
        this.favorites = await CatalogApi.getFavorites();
      } catch (e) {
        this.error = (e == null ? void 0 : e.message) ?? "Failed to load favorites";
      }
    },
    async loadFollowing() {
      try {
        this.following = await CatalogApi.getFollowing();
      } catch (e) {
        this.error = (e == null ? void 0 : e.message) ?? "Failed to load following";
      }
    },
    async loadRuns(registrationId) {
      try {
        this.runs = await CatalogApi.getRuns(registrationId);
      } catch (e) {
        this.error = (e == null ? void 0 : e.message) ?? "Failed to load runs";
      }
    },
    async loadRunDetail(runId) {
      try {
        this.selectedRunId = runId;
        this.selectedRunDetail = await CatalogApi.getRunDetail(runId);
      } catch (e) {
        this.error = (e == null ? void 0 : e.message) ?? "Failed to load run detail";
      }
    },
    async loadStats() {
      try {
        this.stats = await CatalogApi.getStats();
      } catch (e) {
        this.error = (e == null ? void 0 : e.message) ?? "Failed to load stats";
      }
    },
    async toggleFavorite(flowId) {
      const flow = this.allFlows.find((f) => f.id === flowId);
      if (!flow) return;
      try {
        if (flow.is_favorite) {
          await CatalogApi.removeFavorite(flowId);
        } else {
          await CatalogApi.addFavorite(flowId);
        }
        flow.is_favorite = !flow.is_favorite;
        this.updateFavoriteInTree(flowId, flow.is_favorite);
        await Promise.all([this.loadFavorites(), this.loadStats()]);
      } catch (e) {
        this.error = (e == null ? void 0 : e.message) ?? "Failed to toggle favorite";
      }
    },
    /** Update is_favorite on a flow within the tree without replacing the tree. */
    updateFavoriteInTree(flowId, isFavorite) {
      const walk = (nodes) => {
        for (const node of nodes) {
          for (const f of node.flows) {
            if (f.id === flowId) f.is_favorite = isFavorite;
          }
          walk(node.children);
        }
      };
      walk(this.tree);
    },
    async toggleTableFavorite(tableId) {
      const table = this.findTableInTree(tableId);
      if (!table) return;
      try {
        if (table.is_favorite) {
          await CatalogApi.removeTableFavorite(tableId);
        } else {
          await CatalogApi.addTableFavorite(tableId);
        }
        table.is_favorite = !table.is_favorite;
        if (this.selectedTable && this.selectedTable.id === tableId) {
          this.selectedTable.is_favorite = table.is_favorite;
        }
        const allTable = this.allTables.find((t) => t.id === tableId);
        if (allTable) allTable.is_favorite = table.is_favorite;
        await this.loadStats();
      } catch (e) {
        this.error = (e == null ? void 0 : e.message) ?? "Failed to toggle table favorite";
      }
    },
    async toggleFollow(flowId) {
      const flow = this.allFlows.find((f) => f.id === flowId);
      if (!flow) return;
      try {
        if (flow.is_following) {
          await CatalogApi.removeFollow(flowId);
        } else {
          await CatalogApi.addFollow(flowId);
        }
        flow.is_following = !flow.is_following;
        await Promise.all([this.loadFollowing(), this.loadTree()]);
      } catch (e) {
        this.error = (e == null ? void 0 : e.message) ?? "Failed to toggle follow";
      }
    },
    async loadFlowArtifacts(registrationId) {
      this.loadingArtifacts = true;
      try {
        this.flowArtifacts = await CatalogApi.getFlowArtifacts(registrationId);
      } catch {
        this.flowArtifacts = [];
      } finally {
        this.loadingArtifacts = false;
      }
    },
    selectArtifact(artifactId) {
      this.selectedArtifactId = artifactId;
      this.selectedArtifact = this.flowArtifacts.find((a) => a.id === artifactId) ?? this.findArtifactInTree(artifactId) ?? null;
    },
    clearArtifactSelection() {
      this.selectedArtifactId = null;
      this.selectedArtifact = null;
    },
    // -- Catalog Table actions --
    async loadAllTables() {
      try {
        this.allTables = await CatalogApi.getTables();
      } catch (e) {
        this.error = (e == null ? void 0 : e.message) ?? "Failed to load tables";
      }
    },
    selectTable(tableId) {
      this.selectedTableId = tableId;
      this.selectedFlowId = null;
      this.selectedRunId = null;
      this.selectedRunDetail = null;
      this.selectedArtifactId = null;
      this.selectedArtifact = null;
      this.tablePreview = null;
      if (tableId !== null) {
        this.selectedTable = this.findTableInTree(tableId) ?? null;
        this.loadTablePreview(tableId);
      } else {
        this.selectedTable = null;
      }
    },
    clearTableSelection() {
      this.selectedTableId = null;
      this.selectedTable = null;
      this.tablePreview = null;
    },
    async loadTablePreview(tableId, limit = 100) {
      this.loadingTablePreview = true;
      try {
        this.tablePreview = await CatalogApi.getTablePreview(tableId, limit);
      } catch {
        this.tablePreview = null;
      } finally {
        this.loadingTablePreview = false;
      }
    },
    /** Walk the namespace tree to find a table by ID. */
    findTableInTree(tableId) {
      for (const cat of this.tree) {
        for (const t of cat.tables ?? []) {
          if (t.id === tableId) return t;
        }
        for (const schema of cat.children) {
          for (const t of schema.tables ?? []) {
            if (t.id === tableId) return t;
          }
        }
      }
      return null;
    },
    /** Walk the namespace tree to find an artifact by ID. */
    findArtifactInTree(artifactId) {
      for (const cat of this.tree) {
        for (const a of cat.artifacts) {
          if (a.id === artifactId) return a;
        }
        for (const schema of cat.children) {
          for (const a of schema.artifacts) {
            if (a.id === artifactId) return a;
          }
        }
      }
      return null;
    },
    selectFlow(flowId) {
      this.selectedFlowId = flowId;
      this.selectedRunId = null;
      this.selectedRunDetail = null;
      this.clearTableSelection();
      if (flowId !== null) {
        this.loadRuns(flowId);
        this.loadFlowArtifacts(flowId);
      }
    },
    setActiveTab(tab) {
      this.activeTab = tab;
      if (tab === "favorites") this.loadFavorites();
      else if (tab === "following") this.loadFollowing();
      else if (tab === "runs") this.loadRuns();
      else if (tab === "catalog") this.loadTree();
    },
    async initialize() {
      await Promise.all([
        this.loadTree(),
        this.loadAllFlows(),
        this.loadAllTables(),
        this.loadStats(),
        this.loadFavorites(),
        this.loadRuns()
      ]);
    }
  }
});
const _hoisted_1$b = { class: "tree-node" };
const _hoisted_2$b = { class: "ns-name" };
const _hoisted_3$b = {
  key: 0,
  class: "ns-count"
};
const _hoisted_4$b = {
  key: 0,
  class: "tree-children"
};
const _hoisted_5$a = {
  key: 0,
  class: "tree-section"
};
const _hoisted_6$a = { class: "section-count" };
const _hoisted_7$9 = {
  key: 0,
  class: "section-content"
};
const _hoisted_8$9 = ["onClick"];
const _hoisted_9$9 = { class: "flow-name" };
const _hoisted_10$8 = {
  key: 0,
  class: "fa-solid fa-triangle-exclamation missing-icon",
  title: "Flow file not found on disk"
};
const _hoisted_11$8 = ["title", "onClick"];
const _hoisted_12$8 = ["title"];
const _hoisted_13$8 = {
  key: 1,
  class: "tree-section"
};
const _hoisted_14$8 = { class: "section-count" };
const _hoisted_15$8 = {
  key: 0,
  class: "section-content"
};
const _hoisted_16$6 = ["onClick"];
const _hoisted_17$6 = { class: "artifact-name" };
const _hoisted_18$6 = {
  key: 0,
  class: "artifact-versions-count"
};
const _hoisted_19$6 = { class: "artifact-version" };
const _hoisted_20$5 = {
  key: 2,
  class: "tree-section"
};
const _hoisted_21$5 = { class: "section-count" };
const _hoisted_22$5 = {
  key: 0,
  class: "section-content"
};
const _hoisted_23$4 = ["onClick"];
const _hoisted_24$4 = { class: "table-name" };
const _hoisted_25$4 = {
  key: 0,
  class: "table-rows"
};
const _hoisted_26$4 = ["title", "onClick"];
const _sfc_main$b = /* @__PURE__ */ defineComponent({
  __name: "CatalogTreeNode",
  props: {
    node: {},
    selectedFlowId: {},
    selectedArtifactId: {},
    selectedTableId: {},
    searchQuery: { default: "" },
    showUnavailable: { type: Boolean, default: false }
  },
  emits: ["selectFlow", "selectArtifact", "selectTable", "toggleFavorite", "toggleTableFavorite", "registerFlow", "registerTable", "createSchema"],
  setup(__props) {
    const props = __props;
    function formatRowCount(n) {
      if (n === null) return "0";
      if (n >= 1e6) return `${(n / 1e6).toFixed(1)}M`;
      if (n >= 1e3) return `${(n / 1e3).toFixed(1)}K`;
      return String(n);
    }
    function containsFlow(node, flowId) {
      if (node.flows.some((f) => f.id === flowId)) return true;
      return node.children.some((child) => containsFlow(child, flowId));
    }
    function containsArtifact(node, artifactId) {
      if ((node.artifacts ?? []).some((a) => a.id === artifactId)) return true;
      return node.children.some((child) => containsArtifact(child, artifactId));
    }
    function containsTable(node, tableId) {
      if ((node.tables ?? []).some((t) => t.id === tableId)) return true;
      return node.children.some((child) => containsTable(child, tableId));
    }
    const query = computed(() => props.searchQuery.toLowerCase());
    const visibleFlows = computed(() => {
      let flows = props.node.flows;
      if (!props.showUnavailable) {
        flows = flows.filter((f) => f.file_exists);
      }
      if (query.value) {
        flows = flows.filter((f) => f.name.toLowerCase().includes(query.value));
      }
      return flows;
    });
    const visibleTables = computed(() => {
      let tables = props.node.tables ?? [];
      if (!props.showUnavailable) {
        tables = tables.filter((t) => t.file_exists !== false);
      }
      if (query.value) {
        tables = tables.filter((t) => t.name.toLowerCase().includes(query.value));
      }
      return tables;
    });
    const groupedArtifacts = computed(() => {
      const byName = /* @__PURE__ */ new Map();
      for (const a of props.node.artifacts ?? []) {
        const list = byName.get(a.name) ?? [];
        list.push(a);
        byName.set(a.name, list);
      }
      return [...byName.entries()].map(([name, versions]) => {
        const sorted = [...versions].sort((a, b) => b.version - a.version);
        return { name, latest: sorted[0], versionCount: versions.length };
      });
    });
    const visibleArtifacts = computed(() => {
      let groups = groupedArtifacts.value;
      if (query.value) {
        groups = groups.filter((g) => g.name.toLowerCase().includes(query.value));
      }
      return groups;
    });
    const expanded = ref(true);
    const toggle = () => {
      expanded.value = !expanded.value;
    };
    const flowsExpanded = ref(false);
    const modelsExpanded = ref(false);
    const tablesExpanded = ref(false);
    const showFlowsSection = computed(() => props.node.level === 1 && visibleFlows.value.length > 0);
    const showModelsSection = computed(
      () => props.node.level === 1 && visibleArtifacts.value.length > 0
    );
    const showTablesSection = computed(() => props.node.level === 1 && visibleTables.value.length > 0);
    const toggleFlows = () => {
      flowsExpanded.value = !flowsExpanded.value;
    };
    const toggleModels = () => {
      modelsExpanded.value = !modelsExpanded.value;
    };
    const toggleTables = () => {
      tablesExpanded.value = !tablesExpanded.value;
    };
    watch(
      () => props.selectedFlowId,
      (flowId) => {
        if (flowId !== null && containsFlow(props.node, flowId)) {
          expanded.value = true;
          flowsExpanded.value = true;
        }
      }
    );
    watch(
      () => props.selectedArtifactId,
      (artifactId) => {
        if (artifactId !== null && containsArtifact(props.node, artifactId)) {
          expanded.value = true;
          modelsExpanded.value = true;
        }
      }
    );
    watch(
      () => props.selectedTableId,
      (tableId) => {
        if (tableId !== null && containsTable(props.node, tableId)) {
          expanded.value = true;
          tablesExpanded.value = true;
        }
      }
    );
    watch(query, (value) => {
      if (!value) return;
      if (visibleFlows.value.length > 0) flowsExpanded.value = true;
      if (visibleArtifacts.value.length > 0) modelsExpanded.value = true;
      if (visibleTables.value.length > 0) tablesExpanded.value = true;
    });
    watch(
      () => props.node.id,
      () => {
        flowsExpanded.value = false;
        modelsExpanded.value = false;
        tablesExpanded.value = false;
      }
    );
    function countUniqueArtifactNames(artifacts) {
      return new Set(artifacts.map((a) => a.name)).size;
    }
    const totalFlows = computed(() => {
      let count = props.node.flows.length + countUniqueArtifactNames(props.node.artifacts ?? []) + (props.node.tables ?? []).length;
      for (const child of props.node.children) {
        count += child.flows.length + countUniqueArtifactNames(child.artifacts ?? []) + (child.tables ?? []).length;
      }
      return count;
    });
    return (_ctx, _cache) => {
      const _component_CatalogTreeNode = resolveComponent("CatalogTreeNode", true);
      return openBlock(), createElementBlock("div", _hoisted_1$b, [
        createBaseVNode("div", {
          class: normalizeClass(["tree-row", { expanded: expanded.value }]),
          onClick: toggle
        }, [
          createBaseVNode("i", {
            class: normalizeClass([expanded.value ? "fa-solid fa-chevron-down" : "fa-solid fa-chevron-right", "chevron"])
          }, null, 2),
          createBaseVNode("i", {
            class: normalizeClass([__props.node.level === 0 ? "fa-solid fa-box-archive" : "fa-solid fa-layer-group", "ns-icon"])
          }, null, 2),
          createBaseVNode("span", _hoisted_2$b, toDisplayString(__props.node.name), 1),
          totalFlows.value > 0 ? (openBlock(), createElementBlock("span", _hoisted_3$b, toDisplayString(totalFlows.value), 1)) : createCommentVNode("", true),
          createBaseVNode("div", {
            class: "tree-actions",
            onClick: _cache[3] || (_cache[3] = withModifiers(() => {
            }, ["stop"]))
          }, [
            __props.node.level === 0 ? (openBlock(), createElementBlock("button", {
              key: 0,
              class: "action-btn",
              title: "Add schema",
              onClick: _cache[0] || (_cache[0] = ($event) => _ctx.$emit("createSchema", __props.node.id))
            }, [..._cache[14] || (_cache[14] = [
              createBaseVNode("i", { class: "fa-solid fa-plus" }, null, -1)
            ])])) : createCommentVNode("", true),
            __props.node.level === 1 ? (openBlock(), createElementBlock("button", {
              key: 1,
              class: "action-btn",
              title: "Register table",
              onClick: _cache[1] || (_cache[1] = ($event) => _ctx.$emit("registerTable", __props.node.id))
            }, [..._cache[15] || (_cache[15] = [
              createBaseVNode("i", { class: "fa-solid fa-table" }, null, -1)
            ])])) : createCommentVNode("", true),
            __props.node.level === 1 ? (openBlock(), createElementBlock("button", {
              key: 2,
              class: "action-btn",
              title: "Register flow",
              onClick: _cache[2] || (_cache[2] = ($event) => _ctx.$emit("registerFlow", __props.node.id))
            }, [..._cache[16] || (_cache[16] = [
              createBaseVNode("i", { class: "fa-solid fa-file-circle-plus" }, null, -1)
            ])])) : createCommentVNode("", true)
          ])
        ], 2),
        expanded.value ? (openBlock(), createElementBlock("div", _hoisted_4$b, [
          (openBlock(true), createElementBlock(Fragment, null, renderList(__props.node.children, (child) => {
            return openBlock(), createElementBlock("div", {
              key: child.id,
              class: "tree-child-wrapper"
            }, [
              createVNode(_component_CatalogTreeNode, {
                node: child,
                "selected-flow-id": __props.selectedFlowId,
                "selected-artifact-id": __props.selectedArtifactId,
                "selected-table-id": __props.selectedTableId,
                "search-query": __props.searchQuery,
                "show-unavailable": __props.showUnavailable,
                onSelectFlow: _cache[4] || (_cache[4] = ($event) => _ctx.$emit("selectFlow", $event)),
                onSelectArtifact: _cache[5] || (_cache[5] = ($event) => _ctx.$emit("selectArtifact", $event)),
                onSelectTable: _cache[6] || (_cache[6] = ($event) => _ctx.$emit("selectTable", $event)),
                onToggleFavorite: _cache[7] || (_cache[7] = ($event) => _ctx.$emit("toggleFavorite", $event)),
                onToggleTableFavorite: _cache[8] || (_cache[8] = ($event) => _ctx.$emit("toggleTableFavorite", $event)),
                onRegisterFlow: _cache[9] || (_cache[9] = ($event) => _ctx.$emit("registerFlow", $event)),
                onRegisterTable: _cache[10] || (_cache[10] = ($event) => _ctx.$emit("registerTable", $event)),
                onCreateSchema: _cache[11] || (_cache[11] = ($event) => _ctx.$emit("createSchema", $event))
              }, null, 8, ["node", "selected-flow-id", "selected-artifact-id", "selected-table-id", "search-query", "show-unavailable"])
            ]);
          }), 128)),
          showFlowsSection.value ? (openBlock(), createElementBlock("div", _hoisted_5$a, [
            createBaseVNode("button", {
              class: "section-header",
              onClick: withModifiers(toggleFlows, ["stop"])
            }, [
              createBaseVNode("i", {
                class: normalizeClass([flowsExpanded.value ? "fa-solid fa-chevron-down" : "fa-solid fa-chevron-right", "section-chevron"])
              }, null, 2),
              _cache[17] || (_cache[17] = createBaseVNode("span", { class: "section-title" }, "Flows", -1)),
              createBaseVNode("span", _hoisted_6$a, toDisplayString(visibleFlows.value.length), 1)
            ]),
            flowsExpanded.value ? (openBlock(), createElementBlock("div", _hoisted_7$9, [
              (openBlock(true), createElementBlock(Fragment, null, renderList(visibleFlows.value, (flow) => {
                return openBlock(), createElementBlock("div", {
                  key: "f-" + flow.id,
                  class: normalizeClass(["tree-flow", { selected: __props.selectedFlowId === flow.id, "file-missing": !flow.file_exists }]),
                  onClick: withModifiers(($event) => _ctx.$emit("selectFlow", flow.id), ["stop"])
                }, [
                  _cache[18] || (_cache[18] = createBaseVNode("i", { class: "fa-solid fa-diagram-project flow-icon" }, null, -1)),
                  createBaseVNode("span", _hoisted_9$9, toDisplayString(flow.name), 1),
                  !flow.file_exists ? (openBlock(), createElementBlock("i", _hoisted_10$8)) : createCommentVNode("", true),
                  createBaseVNode("div", {
                    class: "flow-actions",
                    onClick: _cache[12] || (_cache[12] = withModifiers(() => {
                    }, ["stop"]))
                  }, [
                    createBaseVNode("button", {
                      class: normalizeClass(["action-btn star-btn", { active: flow.is_favorite }]),
                      title: flow.is_favorite ? "Unfavorite" : "Favorite",
                      onClick: ($event) => _ctx.$emit("toggleFavorite", flow.id)
                    }, [
                      createBaseVNode("i", {
                        class: normalizeClass(flow.is_favorite ? "fa-solid fa-star" : "fa-regular fa-star")
                      }, null, 2)
                    ], 10, _hoisted_11$8),
                    flow.last_run_success !== null ? (openBlock(), createElementBlock("span", {
                      key: 0,
                      class: normalizeClass(["run-indicator", flow.last_run_success ? "success" : "failure"]),
                      title: flow.last_run_success ? "Last run succeeded" : "Last run failed"
                    }, null, 10, _hoisted_12$8)) : createCommentVNode("", true)
                  ])
                ], 10, _hoisted_8$9);
              }), 128))
            ])) : createCommentVNode("", true)
          ])) : createCommentVNode("", true),
          showModelsSection.value ? (openBlock(), createElementBlock("div", _hoisted_13$8, [
            createBaseVNode("button", {
              class: "section-header",
              onClick: withModifiers(toggleModels, ["stop"])
            }, [
              createBaseVNode("i", {
                class: normalizeClass([modelsExpanded.value ? "fa-solid fa-chevron-down" : "fa-solid fa-chevron-right", "section-chevron"])
              }, null, 2),
              _cache[19] || (_cache[19] = createBaseVNode("span", { class: "section-title" }, "Models", -1)),
              createBaseVNode("span", _hoisted_14$8, toDisplayString(visibleArtifacts.value.length), 1)
            ]),
            modelsExpanded.value ? (openBlock(), createElementBlock("div", _hoisted_15$8, [
              (openBlock(true), createElementBlock(Fragment, null, renderList(visibleArtifacts.value, (group) => {
                return openBlock(), createElementBlock("div", {
                  key: "ag-" + group.name,
                  class: normalizeClass(["tree-artifact", { selected: __props.selectedArtifactId === group.latest.id }]),
                  onClick: withModifiers(($event) => _ctx.$emit("selectArtifact", group.latest.id), ["stop"])
                }, [
                  _cache[20] || (_cache[20] = createBaseVNode("i", { class: "fa-solid fa-cube artifact-icon" }, null, -1)),
                  createBaseVNode("span", _hoisted_17$6, toDisplayString(group.name), 1),
                  group.versionCount > 1 ? (openBlock(), createElementBlock("span", _hoisted_18$6, toDisplayString(group.versionCount) + " versions", 1)) : createCommentVNode("", true),
                  createBaseVNode("span", _hoisted_19$6, "v" + toDisplayString(group.latest.version), 1)
                ], 10, _hoisted_16$6);
              }), 128))
            ])) : createCommentVNode("", true)
          ])) : createCommentVNode("", true),
          showTablesSection.value ? (openBlock(), createElementBlock("div", _hoisted_20$5, [
            createBaseVNode("button", {
              class: "section-header",
              onClick: withModifiers(toggleTables, ["stop"])
            }, [
              createBaseVNode("i", {
                class: normalizeClass([tablesExpanded.value ? "fa-solid fa-chevron-down" : "fa-solid fa-chevron-right", "section-chevron"])
              }, null, 2),
              _cache[21] || (_cache[21] = createBaseVNode("span", { class: "section-title" }, "Tables", -1)),
              createBaseVNode("span", _hoisted_21$5, toDisplayString(visibleTables.value.length), 1)
            ]),
            tablesExpanded.value ? (openBlock(), createElementBlock("div", _hoisted_22$5, [
              (openBlock(true), createElementBlock(Fragment, null, renderList(visibleTables.value, (table) => {
                return openBlock(), createElementBlock("div", {
                  key: "t-" + table.id,
                  class: normalizeClass(["tree-table", {
                    selected: __props.selectedTableId === table.id,
                    "file-missing": table.file_exists === false
                  }]),
                  onClick: withModifiers(($event) => _ctx.$emit("selectTable", table.id), ["stop"])
                }, [
                  _cache[22] || (_cache[22] = createBaseVNode("i", { class: "fa-solid fa-table table-icon" }, null, -1)),
                  createBaseVNode("span", _hoisted_24$4, toDisplayString(table.name), 1),
                  table.row_count !== null ? (openBlock(), createElementBlock("span", _hoisted_25$4, toDisplayString(formatRowCount(table.row_count)) + " rows ", 1)) : createCommentVNode("", true),
                  createBaseVNode("div", {
                    class: "flow-actions",
                    onClick: _cache[13] || (_cache[13] = withModifiers(() => {
                    }, ["stop"]))
                  }, [
                    createBaseVNode("button", {
                      class: normalizeClass(["action-btn star-btn", { active: table.is_favorite }]),
                      title: table.is_favorite ? "Unfavorite" : "Favorite",
                      onClick: ($event) => _ctx.$emit("toggleTableFavorite", table.id)
                    }, [
                      createBaseVNode("i", {
                        class: normalizeClass(table.is_favorite ? "fa-solid fa-star" : "fa-regular fa-star")
                      }, null, 2)
                    ], 10, _hoisted_26$4)
                  ])
                ], 10, _hoisted_23$4);
              }), 128))
            ])) : createCommentVNode("", true)
          ])) : createCommentVNode("", true)
        ])) : createCommentVNode("", true)
      ]);
    };
  }
});
const CatalogTreeNode = /* @__PURE__ */ _export_sfc(_sfc_main$b, [["__scopeId", "data-v-ac544a90"]]);
const _hoisted_1$a = { class: "flow-main" };
const _hoisted_2$a = { class: "flow-info" };
const _hoisted_3$a = { class: "flow-name-row" };
const _hoisted_4$a = { class: "flow-name" };
const _hoisted_5$9 = {
  key: 0,
  class: "fa-solid fa-triangle-exclamation missing-icon",
  title: "Flow file not found on disk"
};
const _hoisted_6$9 = {
  key: 0,
  class: "flow-meta missing-text"
};
const _hoisted_7$8 = {
  key: 1,
  class: "flow-meta"
};
const _hoisted_8$8 = { class: "flow-actions" };
const _hoisted_9$8 = ["title"];
const _sfc_main$a = /* @__PURE__ */ defineComponent({
  __name: "FlowListItem",
  props: {
    flow: {},
    selected: { type: Boolean }
  },
  emits: ["select", "toggleFavorite"],
  setup(__props) {
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", {
        class: normalizeClass(["flow-list-item", { selected: __props.selected, "file-missing": !__props.flow.file_exists }]),
        onClick: _cache[1] || (_cache[1] = ($event) => _ctx.$emit("select"))
      }, [
        createBaseVNode("div", _hoisted_1$a, [
          _cache[2] || (_cache[2] = createBaseVNode("i", { class: "fa-solid fa-diagram-project flow-icon" }, null, -1)),
          createBaseVNode("div", _hoisted_2$a, [
            createBaseVNode("div", _hoisted_3$a, [
              createBaseVNode("span", _hoisted_4$a, toDisplayString(__props.flow.name), 1),
              !__props.flow.file_exists ? (openBlock(), createElementBlock("i", _hoisted_5$9)) : createCommentVNode("", true)
            ]),
            !__props.flow.file_exists ? (openBlock(), createElementBlock("span", _hoisted_6$9, "File missing")) : (openBlock(), createElementBlock("span", _hoisted_7$8, toDisplayString(__props.flow.run_count) + " runs", 1))
          ])
        ]),
        createBaseVNode("div", _hoisted_8$8, [
          createBaseVNode("button", {
            class: normalizeClass(["action-btn star-btn", { active: __props.flow.is_favorite }]),
            title: __props.flow.is_favorite ? "Unfavorite" : "Favorite",
            onClick: _cache[0] || (_cache[0] = withModifiers(($event) => _ctx.$emit("toggleFavorite"), ["stop"]))
          }, [
            createBaseVNode("i", {
              class: normalizeClass(__props.flow.is_favorite ? "fa-solid fa-star" : "fa-regular fa-star")
            }, null, 2)
          ], 10, _hoisted_9$8),
          __props.flow.last_run_success !== null ? (openBlock(), createElementBlock("span", {
            key: 0,
            class: normalizeClass(["run-dot", __props.flow.last_run_success ? "success" : "failure"])
          }, null, 2)) : createCommentVNode("", true)
        ])
      ], 2);
    };
  }
});
const FlowListItem = /* @__PURE__ */ _export_sfc(_sfc_main$a, [["__scopeId", "data-v-caf64a4b"]]);
const _hoisted_1$9 = { class: "flow-detail" };
const _hoisted_2$9 = { class: "detail-header" };
const _hoisted_3$9 = { class: "header-main" };
const _hoisted_4$9 = { class: "header-name" };
const _hoisted_5$8 = {
  key: 0,
  class: "description"
};
const _hoisted_6$8 = { class: "header-actions" };
const _hoisted_7$7 = {
  key: 0,
  class: "missing-banner"
};
const _hoisted_8$7 = { class: "meta-grid" };
const _hoisted_9$7 = { class: "meta-card" };
const _hoisted_10$7 = { class: "meta-value" };
const _hoisted_11$7 = { class: "meta-card" };
const _hoisted_12$7 = { class: "meta-value" };
const _hoisted_13$7 = { class: "meta-card" };
const _hoisted_14$7 = { class: "meta-value" };
const _hoisted_15$7 = { class: "meta-card" };
const _hoisted_16$5 = { class: "meta-card" };
const _hoisted_17$5 = { class: "meta-value mono" };
const _hoisted_18$5 = { class: "section" };
const _hoisted_19$5 = {
  key: 0,
  class: "empty-runs"
};
const _hoisted_20$4 = {
  key: 1,
  class: "runs-table"
};
const _hoisted_21$4 = ["onClick"];
const _hoisted_22$4 = {
  key: 0,
  class: "snapshot-link"
};
const _hoisted_23$3 = {
  key: 1,
  class: "no-snapshot"
};
const _hoisted_24$3 = {
  key: 1,
  class: "section"
};
const _hoisted_25$3 = { class: "lineage-grid" };
const _hoisted_26$3 = {
  key: 0,
  class: "lineage-group"
};
const _hoisted_27$3 = { class: "lineage-group-header" };
const _hoisted_28$3 = { class: "lineage-count" };
const _hoisted_29$3 = { class: "lineage-items" };
const _hoisted_30$3 = ["onClick"];
const _hoisted_31$3 = { class: "lineage-item-name" };
const _hoisted_32$3 = {
  key: 1,
  class: "lineage-group"
};
const _hoisted_33$3 = { class: "lineage-group-header" };
const _hoisted_34$3 = { class: "lineage-count" };
const _hoisted_35$3 = { class: "lineage-items" };
const _hoisted_36$3 = ["onClick"];
const _hoisted_37$3 = { class: "lineage-item-name" };
const _hoisted_38$3 = { class: "section" };
const _hoisted_39$2 = {
  key: 0,
  class: "empty-state"
};
const _hoisted_40$2 = {
  key: 1,
  class: "runs-table"
};
const _hoisted_41$2 = { class: "artifact-name" };
const _hoisted_42$2 = {
  key: 0,
  class: "artifact-desc"
};
const _hoisted_43$2 = { class: "type-badge" };
const _sfc_main$9 = /* @__PURE__ */ defineComponent({
  __name: "FlowDetailPanel",
  props: {
    flow: {},
    runs: {},
    artifacts: {}
  },
  emits: ["close", "viewRun", "toggleFavorite", "openFlow", "selectTable", "deleteFlow", "renameFlow"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emit = __emit;
    const isEditing = ref(false);
    const editName = ref("");
    const editInput = ref(null);
    function startRename() {
      editName.value = props.flow.name;
      isEditing.value = true;
      nextTick(() => {
        var _a, _b;
        (_a = editInput.value) == null ? void 0 : _a.focus();
        (_b = editInput.value) == null ? void 0 : _b.select();
      });
    }
    function saveRename() {
      if (!isEditing.value) return;
      const trimmed = editName.value.trim();
      isEditing.value = false;
      if (trimmed && trimmed !== props.flow.name) {
        emit("renameFlow", props.flow.id, trimmed);
      }
    }
    function cancelRename() {
      isEditing.value = false;
    }
    const statusClass = computed(() => {
      if (props.flow.last_run_success === null) return "";
      return props.flow.last_run_success ? "text-success" : "text-danger";
    });
    const statusText = computed(() => {
      if (props.flow.last_run_success === null) return "No runs";
      return props.flow.last_run_success ? "Success" : "Failed";
    });
    function runStatusClass(run) {
      if (run.success === null) return "pending";
      return run.success ? "success" : "failure";
    }
    function runStatusText(run) {
      if (run.success === null) return "Running";
      return run.success ? "Success" : "Failed";
    }
    function formatDate(dateStr) {
      return new Date(dateStr).toLocaleString(void 0, {
        month: "short",
        day: "numeric",
        hour: "2-digit",
        minute: "2-digit"
      });
    }
    function formatDuration(seconds) {
      if (seconds === null) return "--";
      if (seconds < 1) return `${Math.round(seconds * 1e3)}ms`;
      if (seconds < 60) return `${seconds.toFixed(1)}s`;
      return `${Math.floor(seconds / 60)}m ${Math.round(seconds % 60)}s`;
    }
    function formatType(artifact) {
      if (artifact.python_type) {
        const parts = artifact.python_type.split(".");
        return parts[parts.length - 1];
      }
      return artifact.serialization_format ?? "unknown";
    }
    function formatSize(bytes) {
      if (bytes === null) return "--";
      if (bytes < 1024) return `${bytes} B`;
      if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
      return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
    }
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1$9, [
        createBaseVNode("button", {
          class: "back-btn",
          onClick: _cache[0] || (_cache[0] = ($event) => _ctx.$emit("close"))
        }, [..._cache[5] || (_cache[5] = [
          createBaseVNode("i", { class: "fa-solid fa-arrow-left" }, null, -1),
          createTextVNode(" Back ", -1)
        ])]),
        createBaseVNode("div", _hoisted_2$9, [
          createBaseVNode("div", _hoisted_3$9, [
            createBaseVNode("div", _hoisted_4$9, [
              isEditing.value ? withDirectives((openBlock(), createElementBlock("input", {
                key: 0,
                ref_key: "editInput",
                ref: editInput,
                "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => editName.value = $event),
                class: "edit-name-input",
                onKeydown: [
                  withKeys(saveRename, ["enter"]),
                  withKeys(cancelRename, ["escape"])
                ],
                onBlur: saveRename
              }, null, 544)), [
                [vModelText, editName.value]
              ]) : (openBlock(), createElementBlock(Fragment, { key: 1 }, [
                createBaseVNode("h2", null, toDisplayString(__props.flow.name), 1),
                createBaseVNode("button", {
                  class: "btn-icon-inline",
                  title: "Rename",
                  onClick: startRename
                }, [..._cache[6] || (_cache[6] = [
                  createBaseVNode("i", { class: "fa-solid fa-pen" }, null, -1)
                ])])
              ], 64))
            ]),
            __props.flow.description ? (openBlock(), createElementBlock("p", _hoisted_5$8, toDisplayString(__props.flow.description), 1)) : createCommentVNode("", true)
          ]),
          createBaseVNode("div", _hoisted_6$8, [
            __props.flow.file_exists ? (openBlock(), createElementBlock("button", {
              key: 0,
              class: "action-btn-primary",
              onClick: _cache[2] || (_cache[2] = ($event) => _ctx.$emit("openFlow", __props.flow.flow_path))
            }, [..._cache[7] || (_cache[7] = [
              createBaseVNode("i", { class: "fa-solid fa-up-right-from-square" }, null, -1),
              createTextVNode(" Open in Designer ", -1)
            ])])) : createCommentVNode("", true),
            createBaseVNode("button", {
              class: normalizeClass(["action-btn-lg", { active: __props.flow.is_favorite }]),
              onClick: _cache[3] || (_cache[3] = ($event) => _ctx.$emit("toggleFavorite", __props.flow.id))
            }, [
              createBaseVNode("i", {
                class: normalizeClass(__props.flow.is_favorite ? "fa-solid fa-star" : "fa-regular fa-star")
              }, null, 2),
              createTextVNode(" " + toDisplayString(__props.flow.is_favorite ? "Favorited" : "Favorite"), 1)
            ], 2),
            createBaseVNode("button", {
              class: "btn-danger-outline",
              title: "Delete flow",
              onClick: _cache[4] || (_cache[4] = ($event) => _ctx.$emit("deleteFlow", __props.flow.id))
            }, [..._cache[8] || (_cache[8] = [
              createBaseVNode("i", { class: "fa-solid fa-trash" }, null, -1),
              createTextVNode(" Delete ", -1)
            ])])
          ])
        ]),
        !__props.flow.file_exists ? (openBlock(), createElementBlock("div", _hoisted_7$7, [
          _cache[12] || (_cache[12] = createBaseVNode("i", { class: "fa-solid fa-triangle-exclamation" }, null, -1)),
          createBaseVNode("div", null, [
            _cache[11] || (_cache[11] = createBaseVNode("strong", null, "Flow file not found", -1)),
            createBaseVNode("p", null, [
              _cache[9] || (_cache[9] = createTextVNode(" The file ", -1)),
              createBaseVNode("code", null, toDisplayString(__props.flow.flow_path), 1),
              _cache[10] || (_cache[10] = createTextVNode(" no longer exists on disk. The flow cannot be opened or executed, but its run history is still available below. ", -1))
            ])
          ])
        ])) : createCommentVNode("", true),
        createBaseVNode("div", _hoisted_8$7, [
          createBaseVNode("div", _hoisted_9$7, [
            _cache[13] || (_cache[13] = createBaseVNode("span", { class: "meta-label" }, "Total Runs", -1)),
            createBaseVNode("span", _hoisted_10$7, toDisplayString(__props.flow.run_count), 1)
          ]),
          createBaseVNode("div", _hoisted_11$7, [
            _cache[14] || (_cache[14] = createBaseVNode("span", { class: "meta-label" }, "Last Run", -1)),
            createBaseVNode("span", _hoisted_12$7, toDisplayString(__props.flow.last_run_at ? formatDate(__props.flow.last_run_at) : "Never"), 1)
          ]),
          createBaseVNode("div", _hoisted_13$7, [
            _cache[15] || (_cache[15] = createBaseVNode("span", { class: "meta-label" }, "Artifacts", -1)),
            createBaseVNode("span", _hoisted_14$7, toDisplayString(__props.flow.artifact_count ?? 0), 1)
          ]),
          createBaseVNode("div", _hoisted_15$7, [
            _cache[16] || (_cache[16] = createBaseVNode("span", { class: "meta-label" }, "Status", -1)),
            createBaseVNode("span", {
              class: normalizeClass(["meta-value", statusClass.value])
            }, toDisplayString(statusText.value), 3)
          ]),
          createBaseVNode("div", _hoisted_16$5, [
            _cache[17] || (_cache[17] = createBaseVNode("span", { class: "meta-label" }, "Path", -1)),
            createBaseVNode("span", _hoisted_17$5, toDisplayString(__props.flow.flow_path), 1)
          ])
        ]),
        createBaseVNode("div", _hoisted_18$5, [
          _cache[20] || (_cache[20] = createBaseVNode("h3", null, [
            createBaseVNode("i", { class: "fa-solid fa-clock-rotate-left section-icon" }),
            createTextVNode(" Run History")
          ], -1)),
          __props.runs.length === 0 ? (openBlock(), createElementBlock("div", _hoisted_19$5, "No runs recorded yet.")) : (openBlock(), createElementBlock("table", _hoisted_20$4, [
            _cache[19] || (_cache[19] = createBaseVNode("thead", null, [
              createBaseVNode("tr", null, [
                createBaseVNode("th", null, "Status"),
                createBaseVNode("th", null, "Started"),
                createBaseVNode("th", null, "Duration"),
                createBaseVNode("th", null, "Nodes"),
                createBaseVNode("th", null, "Version")
              ])
            ], -1)),
            createBaseVNode("tbody", null, [
              (openBlock(true), createElementBlock(Fragment, null, renderList(__props.runs, (run) => {
                return openBlock(), createElementBlock("tr", {
                  key: run.id,
                  class: "run-row",
                  onClick: ($event) => _ctx.$emit("viewRun", run.id)
                }, [
                  createBaseVNode("td", null, [
                    createBaseVNode("span", {
                      class: normalizeClass(["status-badge", runStatusClass(run)])
                    }, toDisplayString(runStatusText(run)), 3)
                  ]),
                  createBaseVNode("td", null, toDisplayString(formatDate(run.started_at)), 1),
                  createBaseVNode("td", null, toDisplayString(formatDuration(run.duration_seconds)), 1),
                  createBaseVNode("td", null, toDisplayString(run.nodes_completed) + " / " + toDisplayString(run.number_of_nodes), 1),
                  createBaseVNode("td", null, [
                    run.has_snapshot ? (openBlock(), createElementBlock("span", _hoisted_22$4, [..._cache[18] || (_cache[18] = [
                      createBaseVNode("i", { class: "fa-solid fa-code-branch" }, null, -1),
                      createTextVNode(" View ", -1)
                    ])])) : (openBlock(), createElementBlock("span", _hoisted_23$3, "--"))
                  ])
                ], 8, _hoisted_21$4);
              }), 128))
            ])
          ]))
        ]),
        __props.flow.tables_produced && __props.flow.tables_produced.length > 0 || __props.flow.tables_read && __props.flow.tables_read.length > 0 ? (openBlock(), createElementBlock("div", _hoisted_24$3, [
          _cache[27] || (_cache[27] = createBaseVNode("h3", null, [
            createBaseVNode("i", { class: "fa-solid fa-diagram-project section-icon" }),
            createTextVNode(" Data Lineage")
          ], -1)),
          createBaseVNode("div", _hoisted_25$3, [
            __props.flow.tables_read && __props.flow.tables_read.length > 0 ? (openBlock(), createElementBlock("div", _hoisted_26$3, [
              createBaseVNode("div", _hoisted_27$3, [
                _cache[21] || (_cache[21] = createBaseVNode("span", { class: "lineage-label read-label" }, [
                  createBaseVNode("i", { class: "fa-solid fa-arrow-right-to-bracket" }),
                  createTextVNode(" Reads ")
                ], -1)),
                createBaseVNode("span", _hoisted_28$3, toDisplayString(__props.flow.tables_read.length), 1)
              ]),
              createBaseVNode("div", _hoisted_29$3, [
                (openBlock(true), createElementBlock(Fragment, null, renderList(__props.flow.tables_read, (table) => {
                  return openBlock(), createElementBlock("div", {
                    key: table.id,
                    class: "lineage-item read-item",
                    onClick: ($event) => _ctx.$emit("selectTable", table.id)
                  }, [
                    _cache[22] || (_cache[22] = createBaseVNode("i", { class: "fa-solid fa-table lineage-item-icon" }, null, -1)),
                    createBaseVNode("span", _hoisted_31$3, toDisplayString(table.name), 1),
                    _cache[23] || (_cache[23] = createBaseVNode("i", { class: "fa-solid fa-chevron-right lineage-item-arrow" }, null, -1))
                  ], 8, _hoisted_30$3);
                }), 128))
              ])
            ])) : createCommentVNode("", true),
            __props.flow.tables_produced && __props.flow.tables_produced.length > 0 ? (openBlock(), createElementBlock("div", _hoisted_32$3, [
              createBaseVNode("div", _hoisted_33$3, [
                _cache[24] || (_cache[24] = createBaseVNode("span", { class: "lineage-label produced-label" }, [
                  createBaseVNode("i", { class: "fa-solid fa-arrow-right-from-bracket" }),
                  createTextVNode(" Produces ")
                ], -1)),
                createBaseVNode("span", _hoisted_34$3, toDisplayString(__props.flow.tables_produced.length), 1)
              ]),
              createBaseVNode("div", _hoisted_35$3, [
                (openBlock(true), createElementBlock(Fragment, null, renderList(__props.flow.tables_produced, (table) => {
                  return openBlock(), createElementBlock("div", {
                    key: table.id,
                    class: "lineage-item produced-item",
                    onClick: ($event) => _ctx.$emit("selectTable", table.id)
                  }, [
                    _cache[25] || (_cache[25] = createBaseVNode("i", { class: "fa-solid fa-table lineage-item-icon" }, null, -1)),
                    createBaseVNode("span", _hoisted_37$3, toDisplayString(table.name), 1),
                    _cache[26] || (_cache[26] = createBaseVNode("i", { class: "fa-solid fa-chevron-right lineage-item-arrow" }, null, -1))
                  ], 8, _hoisted_36$3);
                }), 128))
              ])
            ])) : createCommentVNode("", true)
          ])
        ])) : createCommentVNode("", true),
        createBaseVNode("div", _hoisted_38$3, [
          _cache[31] || (_cache[31] = createBaseVNode("h3", null, [
            createBaseVNode("i", { class: "fa-solid fa-cube section-icon" }),
            createTextVNode(" Global Artifacts")
          ], -1)),
          __props.artifacts.length === 0 ? (openBlock(), createElementBlock("div", _hoisted_39$2, [..._cache[28] || (_cache[28] = [
            createBaseVNode("i", { class: "fa-solid fa-cube empty-state-icon" }, null, -1),
            createBaseVNode("span", null, "No artifacts published yet", -1)
          ])])) : (openBlock(), createElementBlock("table", _hoisted_40$2, [
            _cache[30] || (_cache[30] = createBaseVNode("thead", null, [
              createBaseVNode("tr", null, [
                createBaseVNode("th", null, "Name"),
                createBaseVNode("th", null, "Version"),
                createBaseVNode("th", null, "Type"),
                createBaseVNode("th", null, "Size"),
                createBaseVNode("th", null, "Created")
              ])
            ], -1)),
            createBaseVNode("tbody", null, [
              (openBlock(true), createElementBlock(Fragment, null, renderList(__props.artifacts, (artifact) => {
                return openBlock(), createElementBlock("tr", {
                  key: artifact.id,
                  class: "artifact-row"
                }, [
                  createBaseVNode("td", null, [
                    createBaseVNode("div", _hoisted_41$2, [
                      _cache[29] || (_cache[29] = createBaseVNode("i", { class: "fa-solid fa-cube artifact-icon" }, null, -1)),
                      createTextVNode(" " + toDisplayString(artifact.name), 1)
                    ]),
                    artifact.description ? (openBlock(), createElementBlock("div", _hoisted_42$2, toDisplayString(artifact.description), 1)) : createCommentVNode("", true)
                  ]),
                  createBaseVNode("td", null, "v" + toDisplayString(artifact.version), 1),
                  createBaseVNode("td", null, [
                    createBaseVNode("span", _hoisted_43$2, toDisplayString(formatType(artifact)), 1)
                  ]),
                  createBaseVNode("td", null, toDisplayString(formatSize(artifact.size_bytes)), 1),
                  createBaseVNode("td", null, toDisplayString(artifact.created_at ? formatDate(artifact.created_at) : "--"), 1)
                ]);
              }), 128))
            ])
          ]))
        ])
      ]);
    };
  }
});
const FlowDetailPanel = /* @__PURE__ */ _export_sfc(_sfc_main$9, [["__scopeId", "data-v-c045f194"]]);
const _hoisted_1$8 = { class: "artifact-detail" };
const _hoisted_2$8 = { class: "detail-header" };
const _hoisted_3$8 = { class: "header-main" };
const _hoisted_4$8 = { class: "header-title" };
const _hoisted_5$7 = {
  key: 0,
  class: "description"
};
const _hoisted_6$7 = { class: "meta-grid" };
const _hoisted_7$6 = { class: "meta-card" };
const _hoisted_8$6 = { class: "meta-value mono" };
const _hoisted_9$6 = { class: "meta-card" };
const _hoisted_10$6 = { class: "meta-value" };
const _hoisted_11$6 = { class: "meta-card" };
const _hoisted_12$6 = { class: "meta-value" };
const _hoisted_13$6 = { class: "meta-card" };
const _hoisted_14$6 = { class: "meta-value" };
const _hoisted_15$6 = { class: "meta-card" };
const _hoisted_16$4 = { class: "meta-value" };
const _hoisted_17$4 = { class: "meta-card" };
const _hoisted_18$4 = { class: "meta-value" };
const _hoisted_19$4 = { class: "section" };
const _hoisted_20$3 = { class: "detail-list" };
const _hoisted_21$3 = {
  key: 0,
  class: "detail-row"
};
const _hoisted_22$3 = { class: "detail-value mono" };
const _hoisted_23$2 = {
  key: 1,
  class: "detail-row"
};
const _hoisted_24$2 = { class: "detail-value mono" };
const _hoisted_25$2 = {
  key: 2,
  class: "detail-row"
};
const _hoisted_26$2 = { class: "detail-value mono sha" };
const _hoisted_27$2 = {
  key: 3,
  class: "detail-row"
};
const _hoisted_28$2 = {
  key: 4,
  class: "detail-row"
};
const _hoisted_29$2 = { class: "detail-value mono" };
const _hoisted_30$2 = {
  key: 5,
  class: "detail-row"
};
const _hoisted_31$2 = { class: "detail-value" };
const _hoisted_32$2 = {
  key: 0,
  class: "section"
};
const _hoisted_33$2 = { class: "tags-list" };
const _hoisted_34$2 = {
  key: 1,
  class: "section"
};
const _hoisted_35$2 = { class: "versions-table" };
const _hoisted_36$2 = { class: "col-version" };
const _hoisted_37$2 = {
  key: 0,
  class: "latest-tag"
};
const _hoisted_38$2 = { class: "col-type mono" };
const _hoisted_39$1 = { class: "col-size" };
const _hoisted_40$1 = { class: "col-date" };
const _hoisted_41$1 = { class: "section" };
const _hoisted_42$1 = { class: "code-block" };
const _hoisted_43$1 = {
  key: 0,
  class: "code-block",
  style: { "margin-top": "8px" }
};
const _sfc_main$8 = /* @__PURE__ */ defineComponent({
  __name: "ArtifactDetailPanel",
  props: {
    artifact: {},
    versions: {}
  },
  emits: ["close", "navigate-to-flow"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emit = __emit;
    const catalogStore = useCatalogStore();
    const sourceFlowName = computed(() => {
      const regId = props.artifact.source_registration_id;
      if (regId === null) return null;
      const flow = catalogStore.allFlows.find((f) => f.id === regId);
      return (flow == null ? void 0 : flow.name) ?? null;
    });
    function formatDate(dateStr) {
      return new Date(dateStr).toLocaleString(void 0, {
        month: "short",
        day: "numeric",
        hour: "2-digit",
        minute: "2-digit"
      });
    }
    function formatType(artifact) {
      if (artifact.python_type) {
        const parts = artifact.python_type.split(".");
        return parts[parts.length - 1];
      }
      return artifact.serialization_format ?? "unknown";
    }
    function formatSize(bytes) {
      if (bytes === null) return "--";
      if (bytes < 1024) return `${bytes} B`;
      if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
      return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
    }
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1$8, [
        createBaseVNode("button", {
          class: "back-btn",
          onClick: _cache[0] || (_cache[0] = ($event) => _ctx.$emit("close"))
        }, [..._cache[2] || (_cache[2] = [
          createBaseVNode("i", { class: "fa-solid fa-arrow-left" }, null, -1),
          createTextVNode(" Back ", -1)
        ])]),
        createBaseVNode("div", _hoisted_2$8, [
          createBaseVNode("div", _hoisted_3$8, [
            createBaseVNode("div", _hoisted_4$8, [
              _cache[3] || (_cache[3] = createBaseVNode("i", { class: "fa-solid fa-cube header-icon" }, null, -1)),
              createBaseVNode("h2", null, toDisplayString(__props.artifact.name), 1),
              createBaseVNode("span", {
                class: normalizeClass(["status-badge", __props.artifact.status])
              }, toDisplayString(__props.artifact.status), 3)
            ]),
            __props.artifact.description ? (openBlock(), createElementBlock("p", _hoisted_5$7, toDisplayString(__props.artifact.description), 1)) : createCommentVNode("", true)
          ])
        ]),
        createBaseVNode("div", _hoisted_6$7, [
          createBaseVNode("div", _hoisted_7$6, [
            _cache[4] || (_cache[4] = createBaseVNode("span", { class: "meta-label" }, "Type", -1)),
            createBaseVNode("span", _hoisted_8$6, toDisplayString(formatType(__props.artifact)), 1)
          ]),
          createBaseVNode("div", _hoisted_9$6, [
            _cache[5] || (_cache[5] = createBaseVNode("span", { class: "meta-label" }, "Format", -1)),
            createBaseVNode("span", _hoisted_10$6, toDisplayString(__props.artifact.serialization_format ?? "unknown"), 1)
          ]),
          createBaseVNode("div", _hoisted_11$6, [
            _cache[6] || (_cache[6] = createBaseVNode("span", { class: "meta-label" }, "Size", -1)),
            createBaseVNode("span", _hoisted_12$6, toDisplayString(formatSize(__props.artifact.size_bytes)), 1)
          ]),
          createBaseVNode("div", _hoisted_13$6, [
            _cache[7] || (_cache[7] = createBaseVNode("span", { class: "meta-label" }, "Latest Version", -1)),
            createBaseVNode("span", _hoisted_14$6, "v" + toDisplayString(__props.artifact.version), 1)
          ]),
          createBaseVNode("div", _hoisted_15$6, [
            _cache[8] || (_cache[8] = createBaseVNode("span", { class: "meta-label" }, "Total Versions", -1)),
            createBaseVNode("span", _hoisted_16$4, toDisplayString(__props.versions.length), 1)
          ]),
          createBaseVNode("div", _hoisted_17$4, [
            _cache[9] || (_cache[9] = createBaseVNode("span", { class: "meta-label" }, "Created", -1)),
            createBaseVNode("span", _hoisted_18$4, toDisplayString(__props.artifact.created_at ? formatDate(__props.artifact.created_at) : "--"), 1)
          ])
        ]),
        createBaseVNode("div", _hoisted_19$4, [
          _cache[16] || (_cache[16] = createBaseVNode("h3", null, "Details", -1)),
          createBaseVNode("div", _hoisted_20$3, [
            __props.artifact.python_type ? (openBlock(), createElementBlock("div", _hoisted_21$3, [
              _cache[10] || (_cache[10] = createBaseVNode("span", { class: "detail-label" }, "Python Type", -1)),
              createBaseVNode("span", _hoisted_22$3, toDisplayString(__props.artifact.python_type), 1)
            ])) : createCommentVNode("", true),
            __props.artifact.python_module ? (openBlock(), createElementBlock("div", _hoisted_23$2, [
              _cache[11] || (_cache[11] = createBaseVNode("span", { class: "detail-label" }, "Module", -1)),
              createBaseVNode("span", _hoisted_24$2, toDisplayString(__props.artifact.python_module), 1)
            ])) : createCommentVNode("", true),
            __props.artifact.sha256 ? (openBlock(), createElementBlock("div", _hoisted_25$2, [
              _cache[12] || (_cache[12] = createBaseVNode("span", { class: "detail-label" }, "SHA-256", -1)),
              createBaseVNode("span", _hoisted_26$2, toDisplayString(__props.artifact.sha256), 1)
            ])) : createCommentVNode("", true),
            sourceFlowName.value ? (openBlock(), createElementBlock("div", _hoisted_27$2, [
              _cache[13] || (_cache[13] = createBaseVNode("span", { class: "detail-label" }, "Source Flow", -1)),
              createBaseVNode("span", {
                class: "detail-value flow-link",
                onClick: _cache[1] || (_cache[1] = ($event) => emit("navigate-to-flow", __props.artifact.source_registration_id))
              }, toDisplayString(sourceFlowName.value), 1)
            ])) : __props.artifact.source_registration_id ? (openBlock(), createElementBlock("div", _hoisted_28$2, [
              _cache[14] || (_cache[14] = createBaseVNode("span", { class: "detail-label" }, "Source Flow", -1)),
              createBaseVNode("span", _hoisted_29$2, "ID " + toDisplayString(__props.artifact.source_registration_id), 1)
            ])) : createCommentVNode("", true),
            __props.artifact.source_node_id ? (openBlock(), createElementBlock("div", _hoisted_30$2, [
              _cache[15] || (_cache[15] = createBaseVNode("span", { class: "detail-label" }, "Source Node", -1)),
              createBaseVNode("span", _hoisted_31$2, "Node " + toDisplayString(__props.artifact.source_node_id), 1)
            ])) : createCommentVNode("", true)
          ])
        ]),
        __props.artifact.tags && __props.artifact.tags.length > 0 ? (openBlock(), createElementBlock("div", _hoisted_32$2, [
          _cache[17] || (_cache[17] = createBaseVNode("h3", null, "Tags", -1)),
          createBaseVNode("div", _hoisted_33$2, [
            (openBlock(true), createElementBlock(Fragment, null, renderList(__props.artifact.tags, (tag) => {
              return openBlock(), createElementBlock("span", {
                key: tag,
                class: "tag-badge"
              }, toDisplayString(tag), 1);
            }), 128))
          ])
        ])) : createCommentVNode("", true),
        __props.versions.length > 1 ? (openBlock(), createElementBlock("div", _hoisted_34$2, [
          _cache[19] || (_cache[19] = createBaseVNode("h3", null, "Versions", -1)),
          createBaseVNode("div", _hoisted_35$2, [
            _cache[18] || (_cache[18] = createStaticVNode('<div class="versions-header" data-v-c557f7b7><span class="col-version" data-v-c557f7b7>Version</span><span class="col-type" data-v-c557f7b7>Type</span><span class="col-size" data-v-c557f7b7>Size</span><span class="col-date" data-v-c557f7b7>Created</span></div>', 1)),
            (openBlock(true), createElementBlock(Fragment, null, renderList(__props.versions, (v) => {
              return openBlock(), createElementBlock("div", {
                key: v.id,
                class: normalizeClass(["versions-row", { current: v.id === __props.artifact.id }])
              }, [
                createBaseVNode("span", _hoisted_36$2, [
                  createTextVNode(" v" + toDisplayString(v.version) + " ", 1),
                  v.id === __props.artifact.id ? (openBlock(), createElementBlock("span", _hoisted_37$2, "latest")) : createCommentVNode("", true)
                ]),
                createBaseVNode("span", _hoisted_38$2, toDisplayString(formatType(v)), 1),
                createBaseVNode("span", _hoisted_39$1, toDisplayString(formatSize(v.size_bytes)), 1),
                createBaseVNode("span", _hoisted_40$1, toDisplayString(v.created_at ? formatDate(v.created_at) : "--"), 1)
              ], 2);
            }), 128))
          ])
        ])) : createCommentVNode("", true),
        createBaseVNode("div", _hoisted_41$1, [
          _cache[20] || (_cache[20] = createBaseVNode("h3", null, "Usage", -1)),
          createBaseVNode("div", _hoisted_42$1, [
            createBaseVNode("code", null, 'obj = flowfile.get_global("' + toDisplayString(__props.artifact.name) + '")', 1)
          ]),
          __props.versions.length > 1 ? (openBlock(), createElementBlock("div", _hoisted_43$1, [
            createBaseVNode("code", null, 'obj_v1 = flowfile.get_global("' + toDisplayString(__props.artifact.name) + '", version=1)', 1)
          ])) : createCommentVNode("", true)
        ])
      ]);
    };
  }
});
const ArtifactDetailPanel = /* @__PURE__ */ _export_sfc(_sfc_main$8, [["__scopeId", "data-v-c557f7b7"]]);
const _hoisted_1$7 = { class: "table-detail" };
const _hoisted_2$7 = { class: "detail-header" };
const _hoisted_3$7 = { class: "header-main" };
const _hoisted_4$7 = { class: "header-title" };
const _hoisted_5$6 = {
  key: 0,
  class: "description"
};
const _hoisted_6$6 = { class: "header-actions" };
const _hoisted_7$5 = { class: "meta-grid" };
const _hoisted_8$5 = { class: "meta-card" };
const _hoisted_9$5 = { class: "meta-value" };
const _hoisted_10$5 = { class: "meta-card" };
const _hoisted_11$5 = { class: "meta-value" };
const _hoisted_12$5 = { class: "meta-card" };
const _hoisted_13$5 = { class: "meta-value" };
const _hoisted_14$5 = { class: "meta-card" };
const _hoisted_15$5 = { class: "meta-value" };
const _hoisted_16$3 = {
  key: 0,
  class: "meta-card"
};
const _hoisted_17$3 = ["title"];
const _hoisted_18$3 = { class: "meta-link-text" };
const _hoisted_19$3 = { class: "meta-value" };
const _hoisted_20$2 = { class: "modal-content" };
const _hoisted_21$2 = { class: "modal-header" };
const _hoisted_22$2 = { class: "modal-body" };
const _hoisted_23$1 = ["onClick"];
const _hoisted_24$1 = {
  key: 0,
  class: "section"
};
const _hoisted_25$1 = { class: "schema-table-wrapper" };
const _hoisted_26$1 = { class: "schema-table" };
const _hoisted_27$1 = { class: "col-name" };
const _hoisted_28$1 = { class: "col-type" };
const _hoisted_29$1 = { class: "section" };
const _hoisted_30$1 = { class: "section-header" };
const _hoisted_31$1 = {
  key: 0,
  class: "preview-info"
};
const _hoisted_32$1 = {
  key: 0,
  class: "loading-state"
};
const _hoisted_33$1 = {
  key: 1,
  class: "preview-table-wrapper"
};
const _hoisted_34$1 = { class: "preview-table" };
const _hoisted_35$1 = { class: "col-header" };
const _hoisted_36$1 = { class: "col-header-name" };
const _hoisted_37$1 = { class: "col-header-type" };
const _hoisted_38$1 = {
  key: 2,
  class: "empty-state"
};
const _sfc_main$7 = /* @__PURE__ */ defineComponent({
  __name: "TableDetailPanel",
  props: {
    table: {},
    preview: {},
    loadingPreview: { type: Boolean }
  },
  emits: ["close", "deleteTable", "toggleTableFavorite", "navigateToFlow"],
  setup(__props, { emit: __emit }) {
    const showReadByModal = ref(false);
    const emit = __emit;
    function handleReadByClick(flowId) {
      emit("navigateToFlow", flowId);
      showReadByModal.value = false;
    }
    function formatNumber(n) {
      if (n === null || n === void 0) return "--";
      return n.toLocaleString();
    }
    function formatSize(bytes) {
      if (bytes === null || bytes === void 0) return "--";
      if (bytes < 1024) return `${bytes} B`;
      if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
      if (bytes < 1024 * 1024 * 1024) return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
      return `${(bytes / (1024 * 1024 * 1024)).toFixed(1)} GB`;
    }
    function formatDate(isoStr) {
      const d = new Date(isoStr);
      return d.toLocaleDateString(void 0, { year: "numeric", month: "short", day: "numeric" });
    }
    function formatCell(value) {
      if (value === null || value === void 0) return "";
      if (typeof value === "number" && !Number.isInteger(value)) {
        return value.toFixed(4);
      }
      return String(value);
    }
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1$7, [
        createBaseVNode("button", {
          class: "back-btn",
          onClick: _cache[0] || (_cache[0] = ($event) => emit("close"))
        }, [..._cache[7] || (_cache[7] = [
          createBaseVNode("i", { class: "fa-solid fa-arrow-left" }, null, -1),
          createTextVNode(" Back ", -1)
        ])]),
        createBaseVNode("div", _hoisted_2$7, [
          createBaseVNode("div", _hoisted_3$7, [
            createBaseVNode("div", _hoisted_4$7, [
              _cache[8] || (_cache[8] = createBaseVNode("i", { class: "fa-solid fa-table header-icon" }, null, -1)),
              createBaseVNode("h2", null, toDisplayString(__props.table.name), 1)
            ]),
            __props.table.description ? (openBlock(), createElementBlock("p", _hoisted_5$6, toDisplayString(__props.table.description), 1)) : createCommentVNode("", true)
          ]),
          createBaseVNode("div", _hoisted_6$6, [
            createBaseVNode("button", {
              class: normalizeClass(["action-btn-lg", { active: __props.table.is_favorite }]),
              onClick: _cache[1] || (_cache[1] = ($event) => emit("toggleTableFavorite", __props.table.id))
            }, [
              createBaseVNode("i", {
                class: normalizeClass(__props.table.is_favorite ? "fa-solid fa-star" : "fa-regular fa-star")
              }, null, 2),
              createTextVNode(" " + toDisplayString(__props.table.is_favorite ? "Favorited" : "Favorite"), 1)
            ], 2),
            createBaseVNode("button", {
              class: "btn-danger-outline",
              title: "Delete table",
              onClick: _cache[2] || (_cache[2] = ($event) => emit("deleteTable", __props.table.id))
            }, [..._cache[9] || (_cache[9] = [
              createBaseVNode("i", { class: "fa-solid fa-trash" }, null, -1),
              createTextVNode(" Delete ", -1)
            ])])
          ])
        ]),
        createBaseVNode("div", _hoisted_7$5, [
          createBaseVNode("div", _hoisted_8$5, [
            _cache[10] || (_cache[10] = createBaseVNode("span", { class: "meta-label" }, "Rows", -1)),
            createBaseVNode("span", _hoisted_9$5, toDisplayString(formatNumber(__props.table.row_count)), 1)
          ]),
          createBaseVNode("div", _hoisted_10$5, [
            _cache[11] || (_cache[11] = createBaseVNode("span", { class: "meta-label" }, "Columns", -1)),
            createBaseVNode("span", _hoisted_11$5, toDisplayString(__props.table.column_count ?? "--"), 1)
          ]),
          createBaseVNode("div", _hoisted_12$5, [
            _cache[12] || (_cache[12] = createBaseVNode("span", { class: "meta-label" }, "Size", -1)),
            createBaseVNode("span", _hoisted_13$5, toDisplayString(formatSize(__props.table.size_bytes)), 1)
          ]),
          createBaseVNode("div", _hoisted_14$5, [
            _cache[13] || (_cache[13] = createBaseVNode("span", { class: "meta-label" }, "Created", -1)),
            createBaseVNode("span", _hoisted_15$5, toDisplayString(formatDate(__props.table.created_at)), 1)
          ]),
          __props.table.source_registration_id && __props.table.source_registration_name ? (openBlock(), createElementBlock("div", _hoisted_16$3, [
            _cache[15] || (_cache[15] = createBaseVNode("span", { class: "meta-label" }, "Produced by", -1)),
            createBaseVNode("span", {
              class: "meta-value meta-link",
              title: __props.table.source_registration_name,
              onClick: _cache[3] || (_cache[3] = ($event) => emit("navigateToFlow", __props.table.source_registration_id))
            }, [
              _cache[14] || (_cache[14] = createBaseVNode("i", { class: "fa-solid fa-diagram-project" }, null, -1)),
              createBaseVNode("span", _hoisted_18$3, toDisplayString(__props.table.source_registration_name), 1)
            ], 8, _hoisted_17$3)
          ])) : createCommentVNode("", true),
          __props.table.read_by_flows && __props.table.read_by_flows.length > 0 ? (openBlock(), createElementBlock("div", {
            key: 1,
            class: "meta-card meta-card-clickable",
            onClick: _cache[4] || (_cache[4] = ($event) => showReadByModal.value = true)
          }, [
            _cache[16] || (_cache[16] = createBaseVNode("span", { class: "meta-label" }, "Read by", -1)),
            createBaseVNode("span", _hoisted_19$3, toDisplayString(__props.table.read_by_flows.length) + " flow" + toDisplayString(__props.table.read_by_flows.length !== 1 ? "s" : ""), 1)
          ])) : createCommentVNode("", true)
        ]),
        (openBlock(), createBlock(Teleport, { to: "body" }, [
          showReadByModal.value ? (openBlock(), createElementBlock("div", {
            key: 0,
            class: "modal-overlay",
            onClick: _cache[6] || (_cache[6] = withModifiers(($event) => showReadByModal.value = false, ["self"]))
          }, [
            createBaseVNode("div", _hoisted_20$2, [
              createBaseVNode("div", _hoisted_21$2, [
                createBaseVNode("h3", null, 'Flows reading "' + toDisplayString(__props.table.name) + '"', 1),
                createBaseVNode("button", {
                  class: "modal-close",
                  onClick: _cache[5] || (_cache[5] = ($event) => showReadByModal.value = false)
                }, [..._cache[17] || (_cache[17] = [
                  createBaseVNode("i", { class: "fa-solid fa-xmark" }, null, -1)
                ])])
              ]),
              createBaseVNode("div", _hoisted_22$2, [
                (openBlock(true), createElementBlock(Fragment, null, renderList(__props.table.read_by_flows, (flow) => {
                  return openBlock(), createElementBlock("div", {
                    key: flow.id,
                    class: "read-by-item",
                    onClick: ($event) => handleReadByClick(flow.id)
                  }, [
                    _cache[18] || (_cache[18] = createBaseVNode("i", { class: "fa-solid fa-diagram-project read-by-icon" }, null, -1)),
                    createBaseVNode("span", null, toDisplayString(flow.name), 1)
                  ], 8, _hoisted_23$1);
                }), 128))
              ])
            ])
          ])) : createCommentVNode("", true)
        ])),
        __props.table.schema_columns && __props.table.schema_columns.length > 0 ? (openBlock(), createElementBlock("div", _hoisted_24$1, [
          _cache[20] || (_cache[20] = createBaseVNode("h3", null, "Schema", -1)),
          createBaseVNode("div", _hoisted_25$1, [
            createBaseVNode("table", _hoisted_26$1, [
              _cache[19] || (_cache[19] = createBaseVNode("thead", null, [
                createBaseVNode("tr", null, [
                  createBaseVNode("th", null, "Column"),
                  createBaseVNode("th", null, "Type")
                ])
              ], -1)),
              createBaseVNode("tbody", null, [
                (openBlock(true), createElementBlock(Fragment, null, renderList(__props.table.schema_columns, (col) => {
                  return openBlock(), createElementBlock("tr", {
                    key: col.name
                  }, [
                    createBaseVNode("td", _hoisted_27$1, toDisplayString(col.name), 1),
                    createBaseVNode("td", _hoisted_28$1, toDisplayString(col.dtype), 1)
                  ]);
                }), 128))
              ])
            ])
          ])
        ])) : createCommentVNode("", true),
        createBaseVNode("div", _hoisted_29$1, [
          createBaseVNode("div", _hoisted_30$1, [
            _cache[21] || (_cache[21] = createBaseVNode("h3", null, "Data Preview", -1)),
            __props.preview ? (openBlock(), createElementBlock("span", _hoisted_31$1, " Showing " + toDisplayString(__props.preview.rows.length) + " of " + toDisplayString(__props.preview.total_rows) + " rows ", 1)) : createCommentVNode("", true)
          ]),
          __props.loadingPreview ? (openBlock(), createElementBlock("div", _hoisted_32$1, "Loading preview...")) : __props.preview && __props.preview.rows.length > 0 ? (openBlock(), createElementBlock("div", _hoisted_33$1, [
            createBaseVNode("table", _hoisted_34$1, [
              createBaseVNode("thead", null, [
                createBaseVNode("tr", null, [
                  (openBlock(true), createElementBlock(Fragment, null, renderList(__props.preview.columns, (col, idx) => {
                    return openBlock(), createElementBlock("th", { key: idx }, [
                      createBaseVNode("div", _hoisted_35$1, [
                        createBaseVNode("span", _hoisted_36$1, toDisplayString(col), 1),
                        createBaseVNode("span", _hoisted_37$1, toDisplayString(__props.preview.dtypes[idx]), 1)
                      ])
                    ]);
                  }), 128))
                ])
              ]),
              createBaseVNode("tbody", null, [
                (openBlock(true), createElementBlock(Fragment, null, renderList(__props.preview.rows, (row, rIdx) => {
                  return openBlock(), createElementBlock("tr", { key: rIdx }, [
                    (openBlock(true), createElementBlock(Fragment, null, renderList(row, (cell, cIdx) => {
                      return openBlock(), createElementBlock("td", { key: cIdx }, toDisplayString(formatCell(cell)), 1);
                    }), 128))
                  ]);
                }), 128))
              ])
            ])
          ])) : (openBlock(), createElementBlock("div", _hoisted_38$1, "No data to preview."))
        ])
      ]);
    };
  }
});
const TableDetailPanel = /* @__PURE__ */ _export_sfc(_sfc_main$7, [["__scopeId", "data-v-9e948019"]]);
const _hoisted_1$6 = { class: "run-info" };
const _hoisted_2$6 = { class: "run-name" };
const _hoisted_3$6 = { class: "run-time" };
const _hoisted_4$6 = { class: "run-right" };
const _hoisted_5$5 = { class: "run-duration" };
const _hoisted_6$5 = {
  key: 0,
  class: "fa-solid fa-code-branch snapshot-icon",
  title: "Has version snapshot"
};
const _sfc_main$6 = /* @__PURE__ */ defineComponent({
  __name: "RunListItem",
  props: {
    run: {},
    selected: { type: Boolean }
  },
  emits: ["select"],
  setup(__props) {
    const props = __props;
    const statusClass = computed(() => {
      if (props.run.success === null) return "pending";
      return props.run.success ? "success" : "failure";
    });
    function formatDate(dateStr) {
      return new Date(dateStr).toLocaleString(void 0, {
        month: "short",
        day: "numeric",
        hour: "2-digit",
        minute: "2-digit"
      });
    }
    function formatDuration(seconds) {
      if (seconds === null) return "--";
      if (seconds < 1) return `${Math.round(seconds * 1e3)}ms`;
      if (seconds < 60) return `${seconds.toFixed(1)}s`;
      return `${Math.floor(seconds / 60)}m ${Math.round(seconds % 60)}s`;
    }
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", {
        class: normalizeClass(["run-list-item", { selected: __props.selected }]),
        onClick: _cache[0] || (_cache[0] = ($event) => _ctx.$emit("select"))
      }, [
        createBaseVNode("span", {
          class: normalizeClass(["status-dot", statusClass.value])
        }, null, 2),
        createBaseVNode("div", _hoisted_1$6, [
          createBaseVNode("span", _hoisted_2$6, toDisplayString(__props.run.flow_name), 1),
          createBaseVNode("span", _hoisted_3$6, toDisplayString(formatDate(__props.run.started_at)), 1)
        ]),
        createBaseVNode("div", _hoisted_4$6, [
          createBaseVNode("span", _hoisted_5$5, toDisplayString(formatDuration(__props.run.duration_seconds)), 1),
          __props.run.has_snapshot ? (openBlock(), createElementBlock("i", _hoisted_6$5)) : createCommentVNode("", true)
        ])
      ], 2);
    };
  }
});
const RunListItem = /* @__PURE__ */ _export_sfc(_sfc_main$6, [["__scopeId", "data-v-b230d54e"]]);
const _hoisted_1$5 = { class: "run-detail" };
const _hoisted_2$5 = { class: "detail-header" };
const _hoisted_3$5 = { class: "meta-grid" };
const _hoisted_4$5 = { class: "meta-card" };
const _hoisted_5$4 = {
  key: 1,
  class: "meta-value"
};
const _hoisted_6$4 = { class: "meta-card" };
const _hoisted_7$4 = { class: "meta-card" };
const _hoisted_8$4 = { class: "meta-value" };
const _hoisted_9$4 = { class: "meta-card" };
const _hoisted_10$4 = { class: "meta-value" };
const _hoisted_11$4 = { class: "meta-card" };
const _hoisted_12$4 = { class: "meta-value" };
const _hoisted_13$4 = { class: "meta-card" };
const _hoisted_14$4 = { class: "meta-value" };
const _hoisted_15$4 = {
  key: 0,
  class: "section"
};
const _hoisted_16$2 = { class: "results-table" };
const _hoisted_17$2 = { class: "mono" };
const _hoisted_18$2 = { class: "error-text" };
const _hoisted_19$2 = {
  key: 1,
  class: "section"
};
const _hoisted_20$1 = { class: "snapshot-header" };
const _hoisted_21$1 = { class: "snapshot-viewer" };
const _hoisted_22$1 = { class: "snapshot-code" };
const _sfc_main$5 = /* @__PURE__ */ defineComponent({
  __name: "RunDetailPanel",
  props: {
    run: {}
  },
  emits: ["close", "openSnapshot", "viewFlow"],
  setup(__props) {
    const props = __props;
    const statusClass = computed(() => {
      if (props.run.success === null) return "text-pending";
      return props.run.success ? "text-success" : "text-danger";
    });
    const statusText = computed(() => {
      if (props.run.success === null) return "Running";
      return props.run.success ? "Success" : "Failed";
    });
    const nodeResults = computed(() => {
      if (!props.run.node_results_json) return [];
      try {
        return JSON.parse(props.run.node_results_json);
      } catch {
        return [];
      }
    });
    const formattedSnapshot = computed(() => {
      if (!props.run.flow_snapshot) return "";
      try {
        return JSON.stringify(JSON.parse(props.run.flow_snapshot), null, 2);
      } catch {
        return props.run.flow_snapshot;
      }
    });
    function formatDate(dateStr) {
      return new Date(dateStr).toLocaleString();
    }
    function formatDuration(seconds) {
      if (seconds === null) return "--";
      if (seconds < 1) return `${Math.round(seconds * 1e3)}ms`;
      if (seconds < 60) return `${seconds.toFixed(1)}s`;
      return `${Math.floor(seconds / 60)}m ${Math.round(seconds % 60)}s`;
    }
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1$5, [
        createBaseVNode("div", _hoisted_2$5, [
          createBaseVNode("button", {
            class: "back-btn",
            onClick: _cache[0] || (_cache[0] = ($event) => _ctx.$emit("close"))
          }, [..._cache[3] || (_cache[3] = [
            createBaseVNode("i", { class: "fa-solid fa-arrow-left" }, null, -1),
            createTextVNode(" Back ", -1)
          ])]),
          createBaseVNode("h2", null, "Run #" + toDisplayString(__props.run.id), 1)
        ]),
        createBaseVNode("div", _hoisted_3$5, [
          createBaseVNode("div", _hoisted_4$5, [
            _cache[5] || (_cache[5] = createBaseVNode("span", { class: "meta-label" }, "Flow", -1)),
            __props.run.registration_id ? (openBlock(), createElementBlock("span", {
              key: 0,
              class: "meta-value flow-link",
              onClick: _cache[1] || (_cache[1] = ($event) => _ctx.$emit("viewFlow", __props.run.registration_id))
            }, [
              createTextVNode(toDisplayString(__props.run.flow_name) + " ", 1),
              _cache[4] || (_cache[4] = createBaseVNode("i", { class: "fa-solid fa-arrow-right flow-link-icon" }, null, -1))
            ])) : (openBlock(), createElementBlock("span", _hoisted_5$4, toDisplayString(__props.run.flow_name), 1))
          ]),
          createBaseVNode("div", _hoisted_6$4, [
            _cache[6] || (_cache[6] = createBaseVNode("span", { class: "meta-label" }, "Status", -1)),
            createBaseVNode("span", {
              class: normalizeClass(["meta-value", statusClass.value])
            }, toDisplayString(statusText.value), 3)
          ]),
          createBaseVNode("div", _hoisted_7$4, [
            _cache[7] || (_cache[7] = createBaseVNode("span", { class: "meta-label" }, "Started", -1)),
            createBaseVNode("span", _hoisted_8$4, toDisplayString(formatDate(__props.run.started_at)), 1)
          ]),
          createBaseVNode("div", _hoisted_9$4, [
            _cache[8] || (_cache[8] = createBaseVNode("span", { class: "meta-label" }, "Duration", -1)),
            createBaseVNode("span", _hoisted_10$4, toDisplayString(formatDuration(__props.run.duration_seconds)), 1)
          ]),
          createBaseVNode("div", _hoisted_11$4, [
            _cache[9] || (_cache[9] = createBaseVNode("span", { class: "meta-label" }, "Nodes", -1)),
            createBaseVNode("span", _hoisted_12$4, toDisplayString(__props.run.nodes_completed) + " / " + toDisplayString(__props.run.number_of_nodes), 1)
          ]),
          createBaseVNode("div", _hoisted_13$4, [
            _cache[10] || (_cache[10] = createBaseVNode("span", { class: "meta-label" }, "Run Type", -1)),
            createBaseVNode("span", _hoisted_14$4, toDisplayString(__props.run.run_type), 1)
          ])
        ]),
        nodeResults.value.length > 0 ? (openBlock(), createElementBlock("div", _hoisted_15$4, [
          _cache[12] || (_cache[12] = createBaseVNode("h3", null, "Node Results", -1)),
          createBaseVNode("table", _hoisted_16$2, [
            _cache[11] || (_cache[11] = createBaseVNode("thead", null, [
              createBaseVNode("tr", null, [
                createBaseVNode("th", null, "Node"),
                createBaseVNode("th", null, "Status"),
                createBaseVNode("th", null, "Duration"),
                createBaseVNode("th", null, "Error")
              ])
            ], -1)),
            createBaseVNode("tbody", null, [
              (openBlock(true), createElementBlock(Fragment, null, renderList(nodeResults.value, (nr, idx) => {
                return openBlock(), createElementBlock("tr", { key: idx }, [
                  createBaseVNode("td", null, toDisplayString(nr.node_name || `Node ${nr.node_id}`), 1),
                  createBaseVNode("td", null, [
                    createBaseVNode("span", {
                      class: normalizeClass(["status-badge", nr.success ? "success" : nr.success === false ? "failure" : "pending"])
                    }, toDisplayString(nr.success ? "OK" : nr.success === false ? "Failed" : "Running"), 3)
                  ]),
                  createBaseVNode("td", _hoisted_17$2, toDisplayString(nr.run_time >= 0 ? `${nr.run_time}ms` : "--"), 1),
                  createBaseVNode("td", _hoisted_18$2, toDisplayString(nr.error || "--"), 1)
                ]);
              }), 128))
            ])
          ])
        ])) : createCommentVNode("", true),
        __props.run.flow_snapshot ? (openBlock(), createElementBlock("div", _hoisted_19$2, [
          createBaseVNode("div", _hoisted_20$1, [
            _cache[14] || (_cache[14] = createBaseVNode("h3", null, [
              createBaseVNode("i", { class: "fa-solid fa-code-branch" }),
              createTextVNode(" Flow Version at Run Time ")
            ], -1)),
            createBaseVNode("button", {
              class: "open-snapshot-btn",
              onClick: _cache[2] || (_cache[2] = ($event) => _ctx.$emit("openSnapshot", __props.run.id))
            }, [..._cache[13] || (_cache[13] = [
              createBaseVNode("i", { class: "fa-solid fa-up-right-from-square" }, null, -1),
              createTextVNode(" Open this version ", -1)
            ])])
          ]),
          createBaseVNode("div", _hoisted_21$1, [
            createBaseVNode("pre", _hoisted_22$1, toDisplayString(formattedSnapshot.value), 1)
          ])
        ])) : createCommentVNode("", true)
      ]);
    };
  }
});
const RunDetailPanel = /* @__PURE__ */ _export_sfc(_sfc_main$5, [["__scopeId", "data-v-3dfe8416"]]);
const _hoisted_1$4 = { class: "stats-panel" };
const _hoisted_2$4 = {
  key: 0,
  class: "stats-grid"
};
const _hoisted_3$4 = { class: "stat-info" };
const _hoisted_4$4 = { class: "stat-value" };
const _hoisted_5$3 = { class: "stat-info" };
const _hoisted_6$3 = { class: "stat-value" };
const _hoisted_7$3 = { class: "stat-info" };
const _hoisted_8$3 = { class: "stat-value" };
const _hoisted_9$3 = { class: "stat-info" };
const _hoisted_10$3 = { class: "stat-value" };
const _hoisted_11$3 = {
  key: 1,
  class: "section"
};
const _hoisted_12$3 = { class: "item-list" };
const _hoisted_13$3 = ["onClick"];
const _hoisted_14$3 = { class: "item-name" };
const _hoisted_15$3 = { class: "item-meta" };
const _hoisted_16$1 = {
  key: 2,
  class: "section"
};
const _hoisted_17$1 = { class: "item-list" };
const _hoisted_18$1 = ["onClick"];
const _hoisted_19$1 = { class: "item-name" };
const _hoisted_20 = { class: "item-meta" };
const _hoisted_21 = {
  key: 3,
  class: "section"
};
const _hoisted_22 = { class: "item-list" };
const _hoisted_23 = ["onClick"];
const _hoisted_24 = { class: "item-name" };
const _hoisted_25 = { class: "item-meta" };
const _hoisted_26 = ["onClick"];
const _hoisted_27 = { class: "item-name" };
const _hoisted_28 = { class: "item-meta" };
const _hoisted_29 = {
  key: 4,
  class: "section"
};
const _hoisted_30 = { class: "item-list" };
const _hoisted_31 = ["onClick"];
const _hoisted_32 = { class: "item-name" };
const _hoisted_33 = { class: "item-meta" };
const _hoisted_34 = { class: "item-duration" };
const _hoisted_35 = {
  key: 5,
  class: "section"
};
const _hoisted_36 = { class: "item-list" };
const _hoisted_37 = ["onClick"];
const _hoisted_38 = { class: "item-name" };
const _hoisted_39 = { class: "item-meta" };
const _hoisted_40 = {
  key: 6,
  class: "section"
};
const _hoisted_41 = { class: "item-list" };
const _hoisted_42 = ["onClick"];
const _hoisted_43 = { class: "item-name" };
const _hoisted_44 = { class: "item-meta" };
const _hoisted_45 = {
  key: 7,
  class: "welcome"
};
const _sfc_main$4 = /* @__PURE__ */ defineComponent({
  __name: "StatsPanel",
  props: {
    stats: {},
    flows: {},
    tables: {},
    favorites: {},
    runs: {}
  },
  emits: ["viewRun", "viewFlow", "viewTable"],
  setup(__props) {
    const props = __props;
    const favoriteTables = computed(() => {
      var _a;
      return ((_a = props.stats) == null ? void 0 : _a.favorite_tables) ?? [];
    });
    const activeSection = ref(null);
    function toggleSection(section) {
      activeSection.value = activeSection.value === section ? null : section;
    }
    function formatNumber(n) {
      if (n === null) return "--";
      return n.toLocaleString();
    }
    function formatDate(dateStr) {
      return new Date(dateStr).toLocaleString(void 0, {
        month: "short",
        day: "numeric",
        hour: "2-digit",
        minute: "2-digit"
      });
    }
    function formatDuration(seconds) {
      if (seconds === null) return "--";
      if (seconds < 1) return `${Math.round(seconds * 1e3)}ms`;
      if (seconds < 60) return `${seconds.toFixed(1)}s`;
      return `${Math.floor(seconds / 60)}m ${Math.round(seconds % 60)}s`;
    }
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1$4, [
        _cache[26] || (_cache[26] = createBaseVNode("h2", null, "Catalog Overview", -1)),
        __props.stats ? (openBlock(), createElementBlock("div", _hoisted_2$4, [
          createBaseVNode("div", {
            class: normalizeClass(["stat-card clickable", { "stat-card--active": activeSection.value === "flows" }]),
            onClick: _cache[0] || (_cache[0] = ($event) => toggleSection("flows"))
          }, [
            _cache[5] || (_cache[5] = createBaseVNode("i", { class: "fa-solid fa-diagram-project stat-icon" }, null, -1)),
            createBaseVNode("div", _hoisted_3$4, [
              createBaseVNode("span", _hoisted_4$4, toDisplayString(__props.stats.total_flows), 1),
              _cache[4] || (_cache[4] = createBaseVNode("span", { class: "stat-label" }, "Registered Flows", -1))
            ])
          ], 2),
          createBaseVNode("div", {
            class: normalizeClass(["stat-card clickable", { "stat-card--active": activeSection.value === "runs" }]),
            onClick: _cache[1] || (_cache[1] = ($event) => toggleSection("runs"))
          }, [
            _cache[7] || (_cache[7] = createBaseVNode("i", { class: "fa-solid fa-play stat-icon" }, null, -1)),
            createBaseVNode("div", _hoisted_5$3, [
              createBaseVNode("span", _hoisted_6$3, toDisplayString(__props.stats.total_runs), 1),
              _cache[6] || (_cache[6] = createBaseVNode("span", { class: "stat-label" }, "Total Runs", -1))
            ])
          ], 2),
          createBaseVNode("div", {
            class: normalizeClass(["stat-card clickable", { "stat-card--active": activeSection.value === "tables" }]),
            onClick: _cache[2] || (_cache[2] = ($event) => toggleSection("tables"))
          }, [
            _cache[9] || (_cache[9] = createBaseVNode("i", { class: "fa-solid fa-table stat-icon" }, null, -1)),
            createBaseVNode("div", _hoisted_7$3, [
              createBaseVNode("span", _hoisted_8$3, toDisplayString(__props.stats.total_tables), 1),
              _cache[8] || (_cache[8] = createBaseVNode("span", { class: "stat-label" }, "Tables", -1))
            ])
          ], 2),
          createBaseVNode("div", {
            class: normalizeClass(["stat-card clickable", { "stat-card--active": activeSection.value === "favorites" }]),
            onClick: _cache[3] || (_cache[3] = ($event) => toggleSection("favorites"))
          }, [
            _cache[11] || (_cache[11] = createBaseVNode("i", { class: "fa-solid fa-star stat-icon" }, null, -1)),
            createBaseVNode("div", _hoisted_9$3, [
              createBaseVNode("span", _hoisted_10$3, toDisplayString(__props.stats.total_favorites + __props.stats.total_table_favorites), 1),
              _cache[10] || (_cache[10] = createBaseVNode("span", { class: "stat-label" }, "Favorites", -1))
            ])
          ], 2)
        ])) : createCommentVNode("", true),
        activeSection.value === "flows" && __props.flows.length > 0 ? (openBlock(), createElementBlock("div", _hoisted_11$3, [
          _cache[13] || (_cache[13] = createBaseVNode("h3", null, "All Flows", -1)),
          createBaseVNode("div", _hoisted_12$3, [
            (openBlock(true), createElementBlock(Fragment, null, renderList(__props.flows, (flow) => {
              return openBlock(), createElementBlock("div", {
                key: flow.id,
                class: "item-row clickable",
                onClick: ($event) => _ctx.$emit("viewFlow", flow.id)
              }, [
                _cache[12] || (_cache[12] = createBaseVNode("i", { class: "fa-solid fa-diagram-project item-icon" }, null, -1)),
                createBaseVNode("span", _hoisted_14$3, toDisplayString(flow.name), 1),
                createBaseVNode("span", _hoisted_15$3, toDisplayString(flow.run_count) + " runs", 1)
              ], 8, _hoisted_13$3);
            }), 128))
          ])
        ])) : createCommentVNode("", true),
        activeSection.value === "tables" && __props.tables.length > 0 ? (openBlock(), createElementBlock("div", _hoisted_16$1, [
          _cache[15] || (_cache[15] = createBaseVNode("h3", null, "All Tables", -1)),
          createBaseVNode("div", _hoisted_17$1, [
            (openBlock(true), createElementBlock(Fragment, null, renderList(__props.tables, (table) => {
              return openBlock(), createElementBlock("div", {
                key: table.id,
                class: "item-row clickable",
                onClick: ($event) => _ctx.$emit("viewTable", table.id)
              }, [
                _cache[14] || (_cache[14] = createBaseVNode("i", { class: "fa-solid fa-table item-icon" }, null, -1)),
                createBaseVNode("span", _hoisted_19$1, toDisplayString(table.name), 1),
                createBaseVNode("span", _hoisted_20, toDisplayString(formatNumber(table.row_count)) + " rows", 1)
              ], 8, _hoisted_18$1);
            }), 128))
          ])
        ])) : createCommentVNode("", true),
        activeSection.value === "favorites" && (__props.favorites.length > 0 || favoriteTables.value.length > 0) ? (openBlock(), createElementBlock("div", _hoisted_21, [
          _cache[19] || (_cache[19] = createBaseVNode("h3", null, "Favorites", -1)),
          createBaseVNode("div", _hoisted_22, [
            (openBlock(true), createElementBlock(Fragment, null, renderList(__props.favorites, (flow) => {
              return openBlock(), createElementBlock("div", {
                key: "fav-f-" + flow.id,
                class: "item-row clickable",
                onClick: ($event) => _ctx.$emit("viewFlow", flow.id)
              }, [
                _cache[16] || (_cache[16] = createBaseVNode("i", { class: "fa-solid fa-star item-icon fav" }, null, -1)),
                createBaseVNode("span", _hoisted_24, toDisplayString(flow.name), 1),
                createBaseVNode("span", _hoisted_25, toDisplayString(flow.run_count) + " runs", 1)
              ], 8, _hoisted_23);
            }), 128)),
            (openBlock(true), createElementBlock(Fragment, null, renderList(favoriteTables.value, (table) => {
              return openBlock(), createElementBlock("div", {
                key: "fav-t-" + table.id,
                class: "item-row clickable",
                onClick: ($event) => _ctx.$emit("viewTable", table.id)
              }, [
                _cache[17] || (_cache[17] = createBaseVNode("i", { class: "fa-solid fa-star item-icon fav" }, null, -1)),
                _cache[18] || (_cache[18] = createBaseVNode("i", { class: "fa-solid fa-table item-icon" }, null, -1)),
                createBaseVNode("span", _hoisted_27, toDisplayString(table.name), 1),
                createBaseVNode("span", _hoisted_28, toDisplayString(formatNumber(table.row_count)) + " rows", 1)
              ], 8, _hoisted_26);
            }), 128))
          ])
        ])) : createCommentVNode("", true),
        activeSection.value === "runs" && __props.runs.length > 0 ? (openBlock(), createElementBlock("div", _hoisted_29, [
          _cache[20] || (_cache[20] = createBaseVNode("h3", null, "Run History", -1)),
          createBaseVNode("div", _hoisted_30, [
            (openBlock(true), createElementBlock(Fragment, null, renderList(__props.runs, (run) => {
              return openBlock(), createElementBlock("div", {
                key: run.id,
                class: "item-row clickable",
                onClick: ($event) => _ctx.$emit("viewRun", run.id)
              }, [
                createBaseVNode("span", {
                  class: normalizeClass(["status-dot", run.success ? "success" : run.success === false ? "failure" : "pending"])
                }, null, 2),
                createBaseVNode("span", _hoisted_32, toDisplayString(run.flow_name), 1),
                createBaseVNode("span", _hoisted_33, toDisplayString(formatDate(run.started_at)), 1),
                createBaseVNode("span", _hoisted_34, toDisplayString(formatDuration(run.duration_seconds)), 1)
              ], 8, _hoisted_31);
            }), 128))
          ])
        ])) : createCommentVNode("", true),
        __props.favorites.length > 0 && activeSection.value !== "favorites" ? (openBlock(), createElementBlock("div", _hoisted_35, [
          _cache[22] || (_cache[22] = createBaseVNode("h3", null, "Favorite Flows", -1)),
          createBaseVNode("div", _hoisted_36, [
            (openBlock(true), createElementBlock(Fragment, null, renderList(__props.favorites, (flow) => {
              return openBlock(), createElementBlock("div", {
                key: flow.id,
                class: "item-row clickable",
                onClick: ($event) => _ctx.$emit("viewFlow", flow.id)
              }, [
                _cache[21] || (_cache[21] = createBaseVNode("i", { class: "fa-solid fa-star item-icon fav" }, null, -1)),
                createBaseVNode("span", _hoisted_38, toDisplayString(flow.name), 1),
                createBaseVNode("span", _hoisted_39, toDisplayString(flow.run_count) + " runs", 1)
              ], 8, _hoisted_37);
            }), 128))
          ])
        ])) : createCommentVNode("", true),
        favoriteTables.value.length > 0 && activeSection.value !== "favorites" ? (openBlock(), createElementBlock("div", _hoisted_40, [
          _cache[24] || (_cache[24] = createBaseVNode("h3", null, "Favorite Tables", -1)),
          createBaseVNode("div", _hoisted_41, [
            (openBlock(true), createElementBlock(Fragment, null, renderList(favoriteTables.value, (table) => {
              return openBlock(), createElementBlock("div", {
                key: table.id,
                class: "item-row clickable",
                onClick: ($event) => _ctx.$emit("viewTable", table.id)
              }, [
                _cache[23] || (_cache[23] = createBaseVNode("i", { class: "fa-solid fa-star item-icon fav" }, null, -1)),
                createBaseVNode("span", _hoisted_43, toDisplayString(table.name), 1),
                createBaseVNode("span", _hoisted_44, toDisplayString(formatNumber(table.row_count)) + " rows", 1)
              ], 8, _hoisted_42);
            }), 128))
          ])
        ])) : createCommentVNode("", true),
        !__props.stats || __props.stats.total_flows === 0 && __props.stats.total_runs === 0 ? (openBlock(), createElementBlock("div", _hoisted_45, [..._cache[25] || (_cache[25] = [
          createStaticVNode('<i class="fa-solid fa-folder-tree welcome-icon" data-v-76b678c0></i><h3 data-v-76b678c0>Welcome to Catalog</h3><p data-v-76b678c0> Organize your flows into catalogs and schemas, track run history, and favorite the flows you use most. </p><div class="welcome-steps" data-v-76b678c0><div class="step" data-v-76b678c0><span class="step-num" data-v-76b678c0>1</span><span data-v-76b678c0>Create a catalog to group related flows</span></div><div class="step" data-v-76b678c0><span class="step-num" data-v-76b678c0>2</span><span data-v-76b678c0>Add schemas within catalogs for finer organization</span></div><div class="step" data-v-76b678c0><span class="step-num" data-v-76b678c0>3</span><span data-v-76b678c0>Register your flow files to track and manage them</span></div></div>', 4)
        ])])) : createCommentVNode("", true)
      ]);
    };
  }
});
const StatsPanel = /* @__PURE__ */ _export_sfc(_sfc_main$4, [["__scopeId", "data-v-76b678c0"]]);
const _hoisted_1$3 = { class: "modal-card" };
const _hoisted_2$3 = ["placeholder"];
const _hoisted_3$3 = { class: "modal-actions" };
const _hoisted_4$3 = ["disabled"];
const _sfc_main$3 = /* @__PURE__ */ defineComponent({
  __name: "CreateNamespaceModal",
  props: {
    visible: { type: Boolean },
    parentId: {}
  },
  emits: ["close"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emit = __emit;
    const catalogStore = useCatalogStore();
    const name = ref("");
    const description = ref("");
    watch(
      () => props.visible,
      (val) => {
        if (val) {
          name.value = "";
          description.value = "";
        }
      }
    );
    async function submit() {
      var _a, _b;
      if (!name.value.trim()) return;
      try {
        await CatalogApi.createNamespace({
          name: name.value.trim(),
          parent_id: props.parentId,
          description: description.value.trim() || null
        });
        emit("close");
        await Promise.all([catalogStore.loadTree(), catalogStore.loadStats()]);
      } catch (e) {
        alert(((_b = (_a = e == null ? void 0 : e.response) == null ? void 0 : _a.data) == null ? void 0 : _b.detail) ?? "Failed to create namespace");
      }
    }
    return (_ctx, _cache) => {
      return __props.visible ? (openBlock(), createElementBlock("div", {
        key: 0,
        class: "modal-overlay",
        onClick: _cache[3] || (_cache[3] = withModifiers(($event) => _ctx.$emit("close"), ["self"]))
      }, [
        createBaseVNode("div", _hoisted_1$3, [
          createBaseVNode("h3", null, toDisplayString(__props.parentId ? "Create Schema" : "Create Catalog"), 1),
          withDirectives(createBaseVNode("input", {
            "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => name.value = $event),
            class: "input-field",
            placeholder: __props.parentId ? "Schema name" : "Catalog name",
            onKeyup: withKeys(submit, ["enter"])
          }, null, 40, _hoisted_2$3), [
            [vModelText, name.value]
          ]),
          withDirectives(createBaseVNode("input", {
            "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => description.value = $event),
            class: "input-field",
            placeholder: "Description (optional)"
          }, null, 512), [
            [vModelText, description.value]
          ]),
          createBaseVNode("div", _hoisted_3$3, [
            createBaseVNode("button", {
              class: "btn-secondary",
              onClick: _cache[2] || (_cache[2] = ($event) => _ctx.$emit("close"))
            }, "Cancel"),
            createBaseVNode("button", {
              class: "btn-primary",
              disabled: !name.value.trim(),
              onClick: submit
            }, "Create", 8, _hoisted_4$3)
          ])
        ])
      ])) : createCommentVNode("", true);
    };
  }
});
const CreateNamespaceModal = /* @__PURE__ */ _export_sfc(_sfc_main$3, [["__scopeId", "data-v-b87a548c"]]);
const _hoisted_1$2 = { class: "modal-card" };
const _hoisted_2$2 = { class: "modal-header" };
const _hoisted_3$2 = { class: "modal-body" };
const _hoisted_4$2 = { class: "form-panel" };
const _hoisted_5$2 = { class: "form-group" };
const _hoisted_6$2 = { class: "form-group" };
const _hoisted_7$2 = { class: "form-group" };
const _hoisted_8$2 = ["value"];
const _hoisted_9$2 = {
  key: 0,
  class: "ns-hint"
};
const _hoisted_10$2 = {
  key: 0,
  class: "selected-file-badge"
};
const _hoisted_11$2 = {
  key: 1,
  class: "no-file-hint"
};
const _hoisted_12$2 = { class: "browser-panel" };
const _hoisted_13$2 = { class: "file-browser-container" };
const _hoisted_14$2 = { class: "modal-footer" };
const _hoisted_15$2 = ["disabled"];
const _sfc_main$2 = /* @__PURE__ */ defineComponent({
  __name: "RegisterFlowModal",
  props: {
    visible: { type: Boolean },
    namespaceId: {},
    defaultNamespaceId: {}
  },
  emits: ["close"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emit = __emit;
    const catalogStore = useCatalogStore();
    const name = ref("");
    const path = ref("");
    const description = ref("");
    const selectedNamespaceId = ref(null);
    const schemaNamespaces = computed(() => {
      const result = [];
      for (const catalog of catalogStore.tree) {
        for (const schema of catalog.children) {
          result.push({ id: schema.id, label: `${catalog.name} / ${schema.name}` });
        }
      }
      return result;
    });
    const fileName = computed(() => {
      if (!path.value) return "";
      const parts = path.value.replace(/\\/g, "/").split("/");
      return parts[parts.length - 1] || path.value;
    });
    watch(
      () => props.visible,
      (val) => {
        if (val) {
          name.value = "";
          path.value = "";
          description.value = "";
          selectedNamespaceId.value = props.namespaceId;
        }
      }
    );
    function handleFileClicked(file) {
      if (!file || file.is_directory) return;
      path.value = file.path;
      if (!name.value.trim()) {
        const baseName = file.name.replace(/\.(yaml|yml|flowfile)$/i, "");
        name.value = baseName;
      }
    }
    function handleFileSelected(fileInfo) {
      path.value = fileInfo.path;
      if (!name.value.trim()) {
        const baseName = fileInfo.name.replace(/\.(yaml|yml|flowfile)$/i, "");
        name.value = baseName;
      }
    }
    async function submit() {
      var _a, _b;
      if (!name.value.trim() || !path.value.trim()) return;
      try {
        const nsId = selectedNamespaceId.value ?? props.defaultNamespaceId;
        await CatalogApi.registerFlow({
          name: name.value.trim(),
          flow_path: path.value.trim(),
          description: description.value.trim() || null,
          namespace_id: nsId
        });
        emit("close");
        await Promise.all([
          catalogStore.loadTree(),
          catalogStore.loadAllFlows(),
          catalogStore.loadStats()
        ]);
      } catch (e) {
        alert(((_b = (_a = e == null ? void 0 : e.response) == null ? void 0 : _a.data) == null ? void 0 : _b.detail) ?? "Failed to register flow");
      }
    }
    return (_ctx, _cache) => {
      return __props.visible ? (openBlock(), createElementBlock("div", {
        key: 0,
        class: "modal-overlay",
        onClick: _cache[6] || (_cache[6] = withModifiers(($event) => _ctx.$emit("close"), ["self"]))
      }, [
        createBaseVNode("div", _hoisted_1$2, [
          createBaseVNode("div", _hoisted_2$2, [
            _cache[8] || (_cache[8] = createBaseVNode("h3", null, "Register Flow", -1)),
            createBaseVNode("button", {
              class: "close-btn",
              onClick: _cache[0] || (_cache[0] = ($event) => _ctx.$emit("close"))
            }, [..._cache[7] || (_cache[7] = [
              createBaseVNode("i", { class: "fa-solid fa-xmark" }, null, -1)
            ])])
          ]),
          createBaseVNode("div", _hoisted_3$2, [
            createBaseVNode("aside", _hoisted_4$2, [
              createBaseVNode("div", _hoisted_5$2, [
                _cache[9] || (_cache[9] = createBaseVNode("label", { class: "field-label" }, "Flow name", -1)),
                withDirectives(createBaseVNode("input", {
                  "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => name.value = $event),
                  class: "input-field",
                  placeholder: "Flow name"
                }, null, 512), [
                  [vModelText, name.value]
                ])
              ]),
              createBaseVNode("div", _hoisted_6$2, [
                _cache[10] || (_cache[10] = createBaseVNode("label", { class: "field-label" }, "Description", -1)),
                withDirectives(createBaseVNode("input", {
                  "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => description.value = $event),
                  class: "input-field",
                  placeholder: "Optional"
                }, null, 512), [
                  [vModelText, description.value]
                ])
              ]),
              createBaseVNode("div", _hoisted_7$2, [
                _cache[11] || (_cache[11] = createBaseVNode("label", { class: "field-label" }, "Catalog / Schema", -1)),
                withDirectives(createBaseVNode("select", {
                  "onUpdate:modelValue": _cache[3] || (_cache[3] = ($event) => selectedNamespaceId.value = $event),
                  class: "input-field"
                }, [
                  (openBlock(true), createElementBlock(Fragment, null, renderList(schemaNamespaces.value, (ns) => {
                    return openBlock(), createElementBlock("option", {
                      key: ns.id,
                      value: ns.id
                    }, toDisplayString(ns.label), 9, _hoisted_8$2);
                  }), 128))
                ], 512), [
                  [vModelSelect, selectedNamespaceId.value]
                ]),
                schemaNamespaces.value.length === 0 ? (openBlock(), createElementBlock("p", _hoisted_9$2, " No schemas available. Create a catalog and schema first. ")) : createCommentVNode("", true)
              ]),
              path.value ? (openBlock(), createElementBlock("div", _hoisted_10$2, [
                _cache[13] || (_cache[13] = createBaseVNode("i", { class: "fa-solid fa-file" }, null, -1)),
                createBaseVNode("span", null, toDisplayString(fileName.value), 1),
                createBaseVNode("button", {
                  class: "clear-file-btn",
                  title: "Clear",
                  onClick: _cache[4] || (_cache[4] = ($event) => path.value = "")
                }, [..._cache[12] || (_cache[12] = [
                  createBaseVNode("i", { class: "fa-solid fa-xmark" }, null, -1)
                ])])
              ])) : (openBlock(), createElementBlock("div", _hoisted_11$2, [..._cache[14] || (_cache[14] = [
                createBaseVNode("i", { class: "fa-solid fa-arrow-right" }, null, -1),
                createBaseVNode("span", null, "Select a flow file from the browser", -1)
              ])]))
            ]),
            createBaseVNode("div", _hoisted_12$2, [
              createBaseVNode("div", _hoisted_13$2, [
                createVNode(FileBrowser, {
                  "allowed-file-types": ["yaml", "yml", "flowfile"],
                  mode: "open",
                  context: "flows",
                  "is-visible": __props.visible,
                  onFileSelected: handleFileSelected,
                  "onUpdate:modelValue": handleFileClicked
                }, null, 8, ["is-visible"])
              ])
            ])
          ]),
          createBaseVNode("div", _hoisted_14$2, [
            createBaseVNode("button", {
              class: "btn-secondary",
              onClick: _cache[5] || (_cache[5] = ($event) => _ctx.$emit("close"))
            }, "Cancel"),
            createBaseVNode("button", {
              class: "btn-primary",
              disabled: !name.value.trim() || !path.value.trim(),
              onClick: submit
            }, " Register ", 8, _hoisted_15$2)
          ])
        ])
      ])) : createCommentVNode("", true);
    };
  }
});
const RegisterFlowModal = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["__scopeId", "data-v-5c5da57c"]]);
const _hoisted_1$1 = { class: "modal-card" };
const _hoisted_2$1 = { class: "modal-header" };
const _hoisted_3$1 = { class: "modal-body" };
const _hoisted_4$1 = { class: "form-panel" };
const _hoisted_5$1 = { class: "form-group" };
const _hoisted_6$1 = { class: "form-group" };
const _hoisted_7$1 = { class: "form-group" };
const _hoisted_8$1 = ["value"];
const _hoisted_9$1 = {
  key: 0,
  class: "ns-hint"
};
const _hoisted_10$1 = {
  key: 0,
  class: "selected-file-badge"
};
const _hoisted_11$1 = {
  key: 1,
  class: "no-file-hint"
};
const _hoisted_12$1 = { class: "browser-panel" };
const _hoisted_13$1 = { class: "file-browser-container" };
const _hoisted_14$1 = { class: "modal-footer" };
const _hoisted_15$1 = ["disabled"];
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "RegisterTableModal",
  props: {
    visible: { type: Boolean },
    namespaceId: {},
    defaultNamespaceId: {}
  },
  emits: ["close"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emit = __emit;
    const catalogStore = useCatalogStore();
    const name = ref("");
    const path = ref("");
    const description = ref("");
    const selectedNamespaceId = ref(null);
    const submitting = ref(false);
    const fileName = computed(() => {
      if (!path.value) return "";
      const parts = path.value.replace(/\\/g, "/").split("/");
      return parts[parts.length - 1] || path.value;
    });
    const schemaNamespaces = computed(() => {
      const result = [];
      for (const catalog of catalogStore.tree) {
        for (const schema of catalog.children) {
          result.push({ id: schema.id, label: `${catalog.name} / ${schema.name}` });
        }
      }
      return result;
    });
    watch(
      () => props.visible,
      (val) => {
        if (val) {
          name.value = "";
          path.value = "";
          description.value = "";
          selectedNamespaceId.value = props.namespaceId;
        }
      }
    );
    function handleFileSelected(fileInfo) {
      path.value = fileInfo.path;
      if (!name.value.trim()) {
        const baseName = fileInfo.name.replace(/\.parquet$/i, "");
        name.value = baseName;
      }
    }
    function handleFileUpdate(file) {
      if (file && !file.is_directory) {
        handleFileSelected(file);
      }
    }
    async function submit() {
      var _a, _b;
      if (!name.value.trim() || !path.value.trim()) return;
      submitting.value = true;
      try {
        const nsId = selectedNamespaceId.value ?? props.defaultNamespaceId;
        await CatalogApi.registerTable({
          name: name.value.trim(),
          file_path: path.value.trim(),
          description: description.value.trim() || null,
          namespace_id: nsId
        });
        ElMessage.success("Table registered successfully");
        emit("close");
        await Promise.all([
          catalogStore.loadTree(),
          catalogStore.loadAllTables(),
          catalogStore.loadStats()
        ]);
      } catch (e) {
        ElMessage.error(((_b = (_a = e == null ? void 0 : e.response) == null ? void 0 : _a.data) == null ? void 0 : _b.detail) ?? "Failed to register table");
      } finally {
        submitting.value = false;
      }
    }
    return (_ctx, _cache) => {
      return __props.visible ? (openBlock(), createElementBlock("div", {
        key: 0,
        class: "modal-overlay",
        onClick: _cache[6] || (_cache[6] = withModifiers(($event) => _ctx.$emit("close"), ["self"]))
      }, [
        createBaseVNode("div", _hoisted_1$1, [
          createBaseVNode("div", _hoisted_2$1, [
            _cache[8] || (_cache[8] = createBaseVNode("h3", null, "Register Table", -1)),
            createBaseVNode("button", {
              class: "close-btn",
              onClick: _cache[0] || (_cache[0] = ($event) => _ctx.$emit("close"))
            }, [..._cache[7] || (_cache[7] = [
              createBaseVNode("i", { class: "fa-solid fa-xmark" }, null, -1)
            ])])
          ]),
          createBaseVNode("div", _hoisted_3$1, [
            createBaseVNode("aside", _hoisted_4$1, [
              createBaseVNode("div", _hoisted_5$1, [
                _cache[9] || (_cache[9] = createBaseVNode("label", { class: "field-label" }, "Table name", -1)),
                withDirectives(createBaseVNode("input", {
                  "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => name.value = $event),
                  class: "input-field",
                  placeholder: "Table name"
                }, null, 512), [
                  [vModelText, name.value]
                ])
              ]),
              createBaseVNode("div", _hoisted_6$1, [
                _cache[10] || (_cache[10] = createBaseVNode("label", { class: "field-label" }, "Description", -1)),
                withDirectives(createBaseVNode("input", {
                  "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => description.value = $event),
                  class: "input-field",
                  placeholder: "Optional"
                }, null, 512), [
                  [vModelText, description.value]
                ])
              ]),
              createBaseVNode("div", _hoisted_7$1, [
                _cache[11] || (_cache[11] = createBaseVNode("label", { class: "field-label" }, "Catalog / Schema", -1)),
                withDirectives(createBaseVNode("select", {
                  "onUpdate:modelValue": _cache[3] || (_cache[3] = ($event) => selectedNamespaceId.value = $event),
                  class: "input-field"
                }, [
                  (openBlock(true), createElementBlock(Fragment, null, renderList(schemaNamespaces.value, (ns) => {
                    return openBlock(), createElementBlock("option", {
                      key: ns.id,
                      value: ns.id
                    }, toDisplayString(ns.label), 9, _hoisted_8$1);
                  }), 128))
                ], 512), [
                  [vModelSelect, selectedNamespaceId.value]
                ]),
                schemaNamespaces.value.length === 0 ? (openBlock(), createElementBlock("p", _hoisted_9$1, " No schemas available. Create a catalog and schema first. ")) : createCommentVNode("", true)
              ]),
              path.value ? (openBlock(), createElementBlock("div", _hoisted_10$1, [
                _cache[13] || (_cache[13] = createBaseVNode("i", { class: "fa-solid fa-table" }, null, -1)),
                createBaseVNode("span", null, toDisplayString(fileName.value), 1),
                createBaseVNode("button", {
                  class: "clear-file-btn",
                  title: "Clear",
                  onClick: _cache[4] || (_cache[4] = ($event) => path.value = "")
                }, [..._cache[12] || (_cache[12] = [
                  createBaseVNode("i", { class: "fa-solid fa-xmark" }, null, -1)
                ])])
              ])) : (openBlock(), createElementBlock("div", _hoisted_11$1, [..._cache[14] || (_cache[14] = [
                createBaseVNode("i", { class: "fa-solid fa-arrow-right" }, null, -1),
                createBaseVNode("span", null, "Select a Parquet file from the browser", -1)
              ])])),
              _cache[15] || (_cache[15] = createBaseVNode("p", { class: "parquet-hint" }, " Only Parquet files can be registered directly. For CSV, Excel, or other formats, use a Flow to transform and output to the catalog. ", -1))
            ]),
            createBaseVNode("div", _hoisted_12$1, [
              createBaseVNode("div", _hoisted_13$1, [
                createVNode(FileBrowser, {
                  "allowed-file-types": ["parquet"],
                  mode: "open",
                  context: "dataFiles",
                  "is-visible": __props.visible,
                  onFileSelected: handleFileSelected,
                  "onUpdate:modelValue": handleFileUpdate
                }, null, 8, ["is-visible"])
              ])
            ])
          ]),
          createBaseVNode("div", _hoisted_14$1, [
            createBaseVNode("button", {
              class: "btn-secondary",
              onClick: _cache[5] || (_cache[5] = ($event) => _ctx.$emit("close"))
            }, "Cancel"),
            createBaseVNode("button", {
              class: "btn-primary",
              disabled: !name.value.trim() || !path.value.trim() || submitting.value,
              onClick: submit
            }, toDisplayString(submitting.value ? "Registering..." : "Register"), 9, _hoisted_15$1)
          ])
        ])
      ])) : createCommentVNode("", true);
    };
  }
});
const RegisterTableModal = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-0dd79d8f"]]);
const _hoisted_1 = { class: "catalog-view" };
const _hoisted_2 = { class: "catalog-tabs" };
const _hoisted_3 = ["onClick"];
const _hoisted_4 = {
  key: 0,
  class: "tab-badge"
};
const _hoisted_5 = { class: "catalog-content" };
const _hoisted_6 = { class: "catalog-sidebar" };
const _hoisted_7 = { class: "sidebar-header" };
const _hoisted_8 = {
  key: 0,
  class: "sidebar-header-actions"
};
const _hoisted_9 = {
  key: 0,
  class: "tree-container"
};
const _hoisted_10 = { class: "sidebar-filters" };
const _hoisted_11 = { class: "unavailable-toggle" };
const _hoisted_12 = {
  key: 0,
  class: "loading-state"
};
const _hoisted_13 = {
  key: 1,
  class: "empty-state"
};
const _hoisted_14 = { key: 2 };
const _hoisted_15 = {
  key: 1,
  class: "list-container"
};
const _hoisted_16 = {
  key: 0,
  class: "empty-state"
};
const _hoisted_17 = {
  key: 2,
  class: "list-container"
};
const _hoisted_18 = {
  key: 0,
  class: "empty-state"
};
const _hoisted_19 = { class: "catalog-detail" };
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "CatalogView",
  setup(__props) {
    const router = useRouter();
    const catalogStore = useCatalogStore();
    const flowStore = useFlowStore();
    const tabs = computed(() => {
      var _a;
      return [
        {
          key: "catalog",
          label: "Catalog",
          icon: "fa-solid fa-folder-tree",
          badge: null
        },
        {
          key: "favorites",
          label: "Favorites",
          icon: "fa-solid fa-star",
          badge: ((_a = catalogStore.stats) == null ? void 0 : _a.total_favorites) ?? null
        },
        {
          key: "runs",
          label: "Run History",
          icon: "fa-solid fa-clock-rotate-left",
          badge: null
        }
      ];
    });
    const sidebarTitle = computed(() => {
      switch (catalogStore.activeTab) {
        case "catalog":
          return "Catalogs";
        case "favorites":
          return "Favorites";
        case "runs":
          return "Run History";
        default:
          return "";
      }
    });
    const searchQuery = ref("");
    const showUnavailable = ref(false);
    const showInfoModal = ref(false);
    const showCreateNamespace = ref(false);
    const createSchemaParentId = ref(null);
    const showRegisterFlow = ref(false);
    const registerFlowNamespaceId = ref(null);
    const showRegisterTable = ref(false);
    const registerTableNamespaceId = ref(null);
    const defaultNamespaceId = ref(null);
    function selectFlow(flowId) {
      catalogStore.clearArtifactSelection();
      catalogStore.selectFlow(flowId);
    }
    function selectTable(tableId) {
      catalogStore.clearArtifactSelection();
      catalogStore.selectTable(tableId);
    }
    function selectArtifact(artifactId) {
      catalogStore.selectedFlowId = null;
      catalogStore.clearTableSelection();
      catalogStore.selectArtifact(artifactId);
    }
    function collectArtifactVersions(nodes, name, nsId) {
      const result = [];
      for (const node of nodes) {
        for (const a of node.artifacts ?? []) {
          if (a.name === name && a.namespace_id === nsId) result.push(a);
        }
        result.push(...collectArtifactVersions(node.children, name, nsId));
      }
      return result;
    }
    const selectedArtifactVersions = computed(() => {
      const a = catalogStore.selectedArtifact;
      if (!a) return [];
      const versions = collectArtifactVersions(catalogStore.tree, a.name, a.namespace_id);
      return versions.sort((x, y) => y.version - x.version);
    });
    function openCreateSchema(parentId) {
      createSchemaParentId.value = parentId;
      showCreateNamespace.value = true;
    }
    function openRegisterFlow(namespaceId) {
      registerFlowNamespaceId.value = namespaceId;
      showRegisterFlow.value = true;
    }
    function openRegisterTable(namespaceId) {
      registerTableNamespaceId.value = namespaceId;
      showRegisterTable.value = true;
    }
    function openRegisterTableGlobal() {
      var _a;
      const schemaNamespaces = [];
      for (const catalog of catalogStore.tree) {
        for (const schema of catalog.children) {
          schemaNamespaces.push({ id: schema.id });
        }
      }
      registerTableNamespaceId.value = defaultNamespaceId.value ?? ((_a = schemaNamespaces[0]) == null ? void 0 : _a.id) ?? null;
      showRegisterTable.value = true;
    }
    function openRegisterFlowGlobal() {
      registerFlowNamespaceId.value = defaultNamespaceId.value ?? null;
      showRegisterFlow.value = true;
    }
    async function handleDeleteTable(tableId) {
      var _a, _b;
      if (!confirm("Are you sure you want to delete this table? The materialized data will be removed.")) {
        return;
      }
      try {
        await CatalogApi.deleteTable(tableId);
        catalogStore.clearTableSelection();
        await Promise.all([
          catalogStore.loadTree(),
          catalogStore.loadAllTables(),
          catalogStore.loadStats()
        ]);
      } catch (e) {
        alert(((_b = (_a = e == null ? void 0 : e.response) == null ? void 0 : _a.data) == null ? void 0 : _b.detail) ?? "Failed to delete table");
      }
    }
    async function handleDeleteFlow(flowId) {
      var _a, _b;
      if (!confirm(
        "Are you sure you want to delete this flow registration? Run history will also be removed."
      )) {
        return;
      }
      try {
        await CatalogApi.deleteFlow(flowId);
        catalogStore.selectedFlowId = null;
        await Promise.all([
          catalogStore.loadTree(),
          catalogStore.loadAllFlows(),
          catalogStore.loadFavorites(),
          catalogStore.loadFollowing(),
          catalogStore.loadStats()
        ]);
      } catch (e) {
        alert(((_b = (_a = e == null ? void 0 : e.response) == null ? void 0 : _a.data) == null ? void 0 : _b.detail) ?? "Failed to delete flow");
      }
    }
    async function handleRenameFlow(flowId, newName) {
      var _a, _b;
      try {
        await CatalogApi.updateFlow(flowId, { name: newName });
        await Promise.all([
          catalogStore.loadTree(),
          catalogStore.loadAllFlows(),
          catalogStore.loadFavorites(),
          catalogStore.loadFollowing()
        ]);
      } catch (e) {
        alert(((_b = (_a = e == null ? void 0 : e.response) == null ? void 0 : _a.data) == null ? void 0 : _b.detail) ?? "Failed to rename flow");
      }
    }
    async function openRunSnapshot(runId) {
      var _a, _b;
      try {
        const flowId = await CatalogApi.openRunSnapshot(runId);
        flowStore.setFlowId(flowId);
        router.push({ name: "designer" });
      } catch (e) {
        alert(((_b = (_a = e == null ? void 0 : e.response) == null ? void 0 : _a.data) == null ? void 0 : _b.detail) ?? "Failed to open flow snapshot");
      }
    }
    async function openFlowInDesigner(flowPath) {
      var _a, _b;
      try {
        const flowId = await FlowApi.importFlow(flowPath);
        flowStore.setFlowId(flowId);
        router.push({ name: "designer" });
      } catch (e) {
        alert(((_b = (_a = e == null ? void 0 : e.response) == null ? void 0 : _a.data) == null ? void 0 : _b.detail) ?? "Failed to open flow");
      }
    }
    function navigateToFlow(registrationId) {
      catalogStore.selectedRunId = null;
      catalogStore.selectedRunDetail = null;
      catalogStore.selectFlow(registrationId);
      catalogStore.setActiveTab("catalog");
    }
    onMounted(async () => {
      await catalogStore.initialize();
      try {
        defaultNamespaceId.value = await CatalogApi.getDefaultNamespaceId();
      } catch {
      }
    });
    return (_ctx, _cache) => {
      const _component_el_tooltip = resolveComponent("el-tooltip");
      const _component_el_dialog = resolveComponent("el-dialog");
      return openBlock(), createElementBlock("div", _hoisted_1, [
        createBaseVNode("div", _hoisted_2, [
          (openBlock(true), createElementBlock(Fragment, null, renderList(tabs.value, (tab) => {
            return openBlock(), createElementBlock("button", {
              key: tab.key,
              class: normalizeClass(["catalog-tab", { active: unref(catalogStore).activeTab === tab.key }]),
              onClick: ($event) => unref(catalogStore).setActiveTab(tab.key)
            }, [
              createBaseVNode("i", {
                class: normalizeClass(tab.icon)
              }, null, 2),
              createBaseVNode("span", null, toDisplayString(tab.label), 1),
              tab.badge !== null ? (openBlock(), createElementBlock("span", _hoisted_4, toDisplayString(tab.badge), 1)) : createCommentVNode("", true)
            ], 10, _hoisted_3);
          }), 128)),
          _cache[37] || (_cache[37] = createBaseVNode("div", { class: "tab-spacer" }, null, -1)),
          createVNode(_component_el_tooltip, {
            content: "About the Catalog",
            placement: "bottom",
            "show-after": 400
          }, {
            default: withCtx(() => [
              createBaseVNode("button", {
                class: "catalog-tab info-btn",
                onClick: _cache[0] || (_cache[0] = ($event) => showInfoModal.value = true)
              }, [..._cache[36] || (_cache[36] = [
                createBaseVNode("i", { class: "fa-solid fa-circle-info" }, null, -1)
              ])])
            ]),
            _: 1
          })
        ]),
        createBaseVNode("div", _hoisted_5, [
          createBaseVNode("div", _hoisted_6, [
            createBaseVNode("div", _hoisted_7, [
              createBaseVNode("h3", null, toDisplayString(sidebarTitle.value), 1),
              unref(catalogStore).activeTab === "catalog" ? (openBlock(), createElementBlock("div", _hoisted_8, [
                createVNode(_component_el_tooltip, {
                  content: "Register table",
                  placement: "bottom",
                  "show-after": 400
                }, {
                  default: withCtx(() => [
                    createBaseVNode("button", {
                      class: "btn-icon",
                      onClick: openRegisterTableGlobal
                    }, [..._cache[38] || (_cache[38] = [
                      createBaseVNode("i", { class: "fa-solid fa-table" }, null, -1)
                    ])])
                  ]),
                  _: 1
                }),
                createVNode(_component_el_tooltip, {
                  content: "Register flow",
                  placement: "bottom",
                  "show-after": 400
                }, {
                  default: withCtx(() => [
                    createBaseVNode("button", {
                      class: "btn-icon",
                      onClick: openRegisterFlowGlobal
                    }, [..._cache[39] || (_cache[39] = [
                      createBaseVNode("i", { class: "fa-solid fa-file-circle-plus" }, null, -1)
                    ])])
                  ]),
                  _: 1
                }),
                createVNode(_component_el_tooltip, {
                  content: "New catalog",
                  placement: "bottom",
                  "show-after": 400
                }, {
                  default: withCtx(() => [
                    createBaseVNode("button", {
                      class: "btn-icon",
                      onClick: _cache[1] || (_cache[1] = ($event) => showCreateNamespace.value = true)
                    }, [..._cache[40] || (_cache[40] = [
                      createBaseVNode("i", { class: "fa-solid fa-plus" }, null, -1)
                    ])])
                  ]),
                  _: 1
                })
              ])) : createCommentVNode("", true)
            ]),
            unref(catalogStore).activeTab === "catalog" ? (openBlock(), createElementBlock("div", _hoisted_9, [
              createBaseVNode("div", _hoisted_10, [
                withDirectives(createBaseVNode("input", {
                  "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => searchQuery.value = $event),
                  class: "search-input",
                  placeholder: "Search..."
                }, null, 512), [
                  [vModelText, searchQuery.value]
                ]),
                createBaseVNode("label", _hoisted_11, [
                  withDirectives(createBaseVNode("input", {
                    "onUpdate:modelValue": _cache[3] || (_cache[3] = ($event) => showUnavailable.value = $event),
                    type: "checkbox"
                  }, null, 512), [
                    [vModelCheckbox, showUnavailable.value]
                  ]),
                  _cache[41] || (_cache[41] = createBaseVNode("span", null, "Show unavailable", -1))
                ])
              ]),
              unref(catalogStore).loading ? (openBlock(), createElementBlock("div", _hoisted_12, "Loading...")) : unref(catalogStore).tree.length === 0 ? (openBlock(), createElementBlock("div", _hoisted_13, [
                _cache[42] || (_cache[42] = createBaseVNode("p", null, "No catalogs yet.", -1)),
                createBaseVNode("button", {
                  class: "btn-primary btn-sm",
                  onClick: _cache[4] || (_cache[4] = ($event) => showCreateNamespace.value = true)
                }, " Create your first catalog ")
              ])) : (openBlock(), createElementBlock("div", _hoisted_14, [
                (openBlock(true), createElementBlock(Fragment, null, renderList(unref(catalogStore).tree, (node) => {
                  return openBlock(), createBlock(CatalogTreeNode, {
                    key: node.id,
                    node,
                    "selected-flow-id": unref(catalogStore).selectedFlowId,
                    "selected-artifact-id": unref(catalogStore).selectedArtifactId,
                    "selected-table-id": unref(catalogStore).selectedTableId,
                    "search-query": searchQuery.value,
                    "show-unavailable": showUnavailable.value,
                    onSelectFlow: _cache[5] || (_cache[5] = ($event) => selectFlow($event)),
                    onSelectArtifact: _cache[6] || (_cache[6] = ($event) => selectArtifact($event)),
                    onSelectTable: _cache[7] || (_cache[7] = ($event) => selectTable($event)),
                    onToggleFavorite: _cache[8] || (_cache[8] = ($event) => unref(catalogStore).toggleFavorite($event)),
                    onToggleTableFavorite: _cache[9] || (_cache[9] = ($event) => unref(catalogStore).toggleTableFavorite($event)),
                    onRegisterFlow: _cache[10] || (_cache[10] = ($event) => openRegisterFlow($event)),
                    onRegisterTable: _cache[11] || (_cache[11] = ($event) => openRegisterTable($event)),
                    onCreateSchema: _cache[12] || (_cache[12] = ($event) => openCreateSchema($event))
                  }, null, 8, ["node", "selected-flow-id", "selected-artifact-id", "selected-table-id", "search-query", "show-unavailable"]);
                }), 128))
              ]))
            ])) : unref(catalogStore).activeTab === "favorites" ? (openBlock(), createElementBlock("div", _hoisted_15, [
              unref(catalogStore).favorites.length === 0 ? (openBlock(), createElementBlock("div", _hoisted_16, [..._cache[43] || (_cache[43] = [
                createBaseVNode("p", null, "No favorites yet.", -1),
                createBaseVNode("p", { class: "muted" }, "Star flows from the Catalog tab to see them here.", -1)
              ])])) : createCommentVNode("", true),
              (openBlock(true), createElementBlock(Fragment, null, renderList(unref(catalogStore).favorites, (flow) => {
                return openBlock(), createBlock(FlowListItem, {
                  key: flow.id,
                  flow,
                  selected: unref(catalogStore).selectedFlowId === flow.id,
                  onSelect: ($event) => unref(catalogStore).selectFlow(flow.id),
                  onToggleFavorite: ($event) => unref(catalogStore).toggleFavorite(flow.id)
                }, null, 8, ["flow", "selected", "onSelect", "onToggleFavorite"]);
              }), 128))
            ])) : unref(catalogStore).activeTab === "runs" ? (openBlock(), createElementBlock("div", _hoisted_17, [
              (openBlock(true), createElementBlock(Fragment, null, renderList(unref(catalogStore).runs, (run) => {
                return openBlock(), createBlock(RunListItem, {
                  key: run.id,
                  run,
                  selected: unref(catalogStore).selectedRunId === run.id,
                  onSelect: ($event) => unref(catalogStore).loadRunDetail(run.id)
                }, null, 8, ["run", "selected", "onSelect"]);
              }), 128)),
              unref(catalogStore).runs.length === 0 ? (openBlock(), createElementBlock("div", _hoisted_18, [..._cache[44] || (_cache[44] = [
                createBaseVNode("p", null, "No runs recorded yet.", -1),
                createBaseVNode("p", { class: "muted" }, "Run a flow to see its history here.", -1)
              ])])) : createCommentVNode("", true)
            ])) : createCommentVNode("", true)
          ]),
          createBaseVNode("div", _hoisted_19, [
            unref(catalogStore).selectedRunDetail ? (openBlock(), createBlock(RunDetailPanel, {
              key: 0,
              run: unref(catalogStore).selectedRunDetail,
              onClose: _cache[13] || (_cache[13] = ($event) => {
                unref(catalogStore).selectedRunId = null;
                unref(catalogStore).selectedRunDetail = null;
              }),
              onOpenSnapshot: _cache[14] || (_cache[14] = ($event) => openRunSnapshot($event)),
              onViewFlow: _cache[15] || (_cache[15] = ($event) => navigateToFlow($event))
            }, null, 8, ["run"])) : unref(catalogStore).selectedArtifact ? (openBlock(), createBlock(ArtifactDetailPanel, {
              key: 1,
              artifact: unref(catalogStore).selectedArtifact,
              versions: selectedArtifactVersions.value,
              onClose: _cache[16] || (_cache[16] = ($event) => unref(catalogStore).clearArtifactSelection()),
              onNavigateToFlow: _cache[17] || (_cache[17] = ($event) => navigateToFlow($event))
            }, null, 8, ["artifact", "versions"])) : unref(catalogStore).selectedTable ? (openBlock(), createBlock(TableDetailPanel, {
              key: 2,
              table: unref(catalogStore).selectedTable,
              preview: unref(catalogStore).tablePreview,
              "loading-preview": unref(catalogStore).loadingTablePreview,
              onClose: _cache[18] || (_cache[18] = ($event) => unref(catalogStore).clearTableSelection()),
              onDeleteTable: _cache[19] || (_cache[19] = ($event) => handleDeleteTable($event)),
              onToggleTableFavorite: _cache[20] || (_cache[20] = ($event) => unref(catalogStore).toggleTableFavorite($event)),
              onNavigateToFlow: _cache[21] || (_cache[21] = ($event) => navigateToFlow($event))
            }, null, 8, ["table", "preview", "loading-preview"])) : unref(catalogStore).selectedFlow ? (openBlock(), createBlock(FlowDetailPanel, {
              key: 3,
              flow: unref(catalogStore).selectedFlow,
              runs: unref(catalogStore).flowRuns,
              artifacts: unref(catalogStore).flowArtifacts,
              onClose: _cache[22] || (_cache[22] = ($event) => unref(catalogStore).selectFlow(null)),
              onViewRun: _cache[23] || (_cache[23] = ($event) => unref(catalogStore).loadRunDetail($event)),
              onToggleFavorite: _cache[24] || (_cache[24] = ($event) => unref(catalogStore).toggleFavorite($event)),
              onToggleFollow: _cache[25] || (_cache[25] = ($event) => unref(catalogStore).toggleFollow($event)),
              onOpenFlow: _cache[26] || (_cache[26] = ($event) => openFlowInDesigner($event)),
              onSelectTable: _cache[27] || (_cache[27] = ($event) => selectTable($event)),
              onDeleteFlow: _cache[28] || (_cache[28] = ($event) => handleDeleteFlow($event)),
              onRenameFlow: handleRenameFlow
            }, null, 8, ["flow", "runs", "artifacts"])) : (openBlock(), createBlock(StatsPanel, {
              key: 4,
              stats: unref(catalogStore).stats,
              flows: unref(catalogStore).allFlows,
              tables: unref(catalogStore).allTables,
              favorites: unref(catalogStore).favorites,
              runs: unref(catalogStore).runs,
              onViewRun: _cache[29] || (_cache[29] = ($event) => unref(catalogStore).loadRunDetail($event)),
              onViewFlow: _cache[30] || (_cache[30] = ($event) => navigateToFlow($event)),
              onViewTable: _cache[31] || (_cache[31] = ($event) => selectTable($event))
            }, null, 8, ["stats", "flows", "tables", "favorites", "runs"]))
          ])
        ]),
        createVNode(CreateNamespaceModal, {
          visible: showCreateNamespace.value,
          "parent-id": createSchemaParentId.value,
          onClose: _cache[32] || (_cache[32] = ($event) => {
            showCreateNamespace.value = false;
            createSchemaParentId.value = null;
          })
        }, null, 8, ["visible", "parent-id"]),
        createVNode(RegisterFlowModal, {
          visible: showRegisterFlow.value,
          "namespace-id": registerFlowNamespaceId.value,
          "default-namespace-id": defaultNamespaceId.value,
          onClose: _cache[33] || (_cache[33] = ($event) => showRegisterFlow.value = false)
        }, null, 8, ["visible", "namespace-id", "default-namespace-id"]),
        createVNode(RegisterTableModal, {
          visible: showRegisterTable.value,
          "namespace-id": registerTableNamespaceId.value,
          "default-namespace-id": defaultNamespaceId.value,
          onClose: _cache[34] || (_cache[34] = ($event) => showRegisterTable.value = false)
        }, null, 8, ["visible", "namespace-id", "default-namespace-id"]),
        createVNode(_component_el_dialog, {
          modelValue: showInfoModal.value,
          "onUpdate:modelValue": _cache[35] || (_cache[35] = ($event) => showInfoModal.value = $event),
          title: "About the Catalog",
          width: "600px",
          "append-to-body": true
        }, {
          default: withCtx(() => [..._cache[45] || (_cache[45] = [
            createBaseVNode("div", { class: "info-modal-content" }, [
              createBaseVNode("div", { class: "info-card" }, [
                createBaseVNode("div", { class: "info-card-header" }, [
                  createBaseVNode("i", { class: "fa-solid fa-folder-tree" }),
                  createBaseVNode("h4", null, "Organization")
                ]),
                createBaseVNode("p", null, [
                  createTextVNode(" Flows and tables are organized into "),
                  createBaseVNode("strong", null, "catalogs"),
                  createTextVNode(" and "),
                  createBaseVNode("strong", null, "schemas"),
                  createTextVNode(". Use catalogs for broad groupings (e.g. by team or domain) and schemas for finer separation within them. ")
                ])
              ]),
              createBaseVNode("div", { class: "info-card" }, [
                createBaseVNode("div", { class: "info-card-header" }, [
                  createBaseVNode("i", { class: "fa-solid fa-clock-rotate-left" }),
                  createBaseVNode("h4", null, "Run history")
                ]),
                createBaseVNode("p", null, " Every registered flow tracks its executions automatically. View status, duration, and node-level progress for each run, or open a snapshot to inspect a past state. ")
              ]),
              createBaseVNode("div", { class: "info-card" }, [
                createBaseVNode("div", { class: "info-card-header" }, [
                  createBaseVNode("i", { class: "fa-solid fa-table" }),
                  createBaseVNode("h4", null, "Tables & artifacts")
                ]),
                createBaseVNode("p", null, " Register datasets as catalog tables to preview and track them centrally. Artifacts produced by flows are versioned and linked back to the run that created them. ")
              ])
            ], -1)
          ])]),
          _: 1
        }, 8, ["modelValue"])
      ]);
    };
  }
});
const CatalogView = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-00a2dfaa"]]);
export {
  CatalogView as default
};
