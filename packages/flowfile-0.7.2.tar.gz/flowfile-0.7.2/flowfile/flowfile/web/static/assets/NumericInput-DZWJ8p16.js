import { _ as _sfc_main } from "./NumericInput.vue_vue_type_script_setup_true_lang-DfTj-KVI.js";
import "./index-BAmalrlq.js";
export {
  _sfc_main as default
};
