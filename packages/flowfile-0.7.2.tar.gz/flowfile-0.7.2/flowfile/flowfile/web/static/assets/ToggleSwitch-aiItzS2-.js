import { _ as _sfc_main } from "./ToggleSwitch.vue_vue_type_script_setup_true_lang-pw1BW-fQ.js";
import "./index-BAmalrlq.js";
export {
  _sfc_main as default
};
