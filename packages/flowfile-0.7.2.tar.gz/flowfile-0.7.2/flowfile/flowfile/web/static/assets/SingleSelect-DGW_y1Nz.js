import { _ as _sfc_main } from "./SingleSelect.vue_vue_type_script_setup_true_lang-D_HuXkMN.js";
import "./index-BAmalrlq.js";
export {
  _sfc_main as default
};
