import { d as defineComponent, c as createElementBlock, t as toDisplayString, e as createCommentVNode, a as createBaseVNode, H as Fragment, I as renderList, o as openBlock, g as _export_sfc } from "./index-BAmalrlq.js";
const _hoisted_1 = {
  key: 0,
  class: "cell-output"
};
const _hoisted_2 = {
  key: 0,
  class: "output-meta"
};
const _hoisted_3 = {
  key: 1,
  class: "output-error"
};
const _hoisted_4 = {
  key: 0,
  class: "display-title"
};
const _hoisted_5 = ["src"];
const _hoisted_6 = ["srcdoc"];
const _hoisted_7 = {
  key: 3,
  class: "display-text"
};
const _hoisted_8 = {
  key: 4,
  class: "display-text"
};
const _hoisted_9 = {
  key: 2,
  class: "output-stdout"
};
const _hoisted_10 = {
  key: 3,
  class: "output-stderr"
};
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "CellOutput",
  props: {
    output: {}
  },
  setup(__props) {
    const formatTime = (ms) => {
      if (ms < 1) return "<1ms";
      if (ms < 1e3) return `${Math.round(ms)}ms`;
      return `${(ms / 1e3).toFixed(2)}s`;
    };
    const autoResizeIframe = (event) => {
      var _a, _b, _c;
      const iframe = event.target;
      try {
        const height = (_c = (_b = (_a = iframe.contentWindow) == null ? void 0 : _a.document) == null ? void 0 : _b.body) == null ? void 0 : _c.scrollHeight;
        if (height) {
          iframe.style.height = `${Math.min(height + 20, 600)}px`;
        }
      } catch {
      }
    };
    return (_ctx, _cache) => {
      return __props.output ? (openBlock(), createElementBlock("div", _hoisted_1, [
        __props.output.execution_count ? (openBlock(), createElementBlock("div", _hoisted_2, " [" + toDisplayString(__props.output.execution_count) + "] " + toDisplayString(formatTime(__props.output.execution_time_ms)), 1)) : createCommentVNode("", true),
        __props.output.error ? (openBlock(), createElementBlock("div", _hoisted_3, [
          createBaseVNode("pre", null, toDisplayString(__props.output.error), 1)
        ])) : createCommentVNode("", true),
        (openBlock(true), createElementBlock(Fragment, null, renderList(__props.output.display_outputs, (disp, index) => {
          return openBlock(), createElementBlock("div", {
            key: index,
            class: "display-item"
          }, [
            disp.title ? (openBlock(), createElementBlock("div", _hoisted_4, toDisplayString(disp.title), 1)) : createCommentVNode("", true),
            disp.mime_type === "image/png" ? (openBlock(), createElementBlock("img", {
              key: 1,
              src: "data:image/png;base64," + disp.data,
              class: "display-image",
              alt: "Output image"
            }, null, 8, _hoisted_5)) : disp.mime_type === "text/html" ? (openBlock(), createElementBlock("iframe", {
              key: 2,
              srcdoc: disp.data,
              class: "display-iframe",
              sandbox: "allow-scripts",
              onLoad: _cache[0] || (_cache[0] = ($event) => autoResizeIframe($event))
            }, null, 40, _hoisted_6)) : disp.mime_type === "text/plain" ? (openBlock(), createElementBlock("div", _hoisted_7, [
              createBaseVNode("pre", null, toDisplayString(disp.data), 1)
            ])) : (openBlock(), createElementBlock("div", _hoisted_8, [
              createBaseVNode("pre", null, toDisplayString(disp.data), 1)
            ]))
          ]);
        }), 128)),
        __props.output.stdout ? (openBlock(), createElementBlock("div", _hoisted_9, [
          createBaseVNode("pre", null, toDisplayString(__props.output.stdout), 1)
        ])) : createCommentVNode("", true),
        __props.output.stderr && !__props.output.error ? (openBlock(), createElementBlock("div", _hoisted_10, [
          createBaseVNode("pre", null, toDisplayString(__props.output.stderr), 1)
        ])) : createCommentVNode("", true)
      ])) : createCommentVNode("", true);
    };
  }
});
const CellOutput = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-377c5e23"]]);
export {
  CellOutput as default
};
