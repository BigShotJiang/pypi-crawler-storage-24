import { K as KernelApi } from "./kernel.api-C70jELSB.js";
import NotebookCellComponent from "./NotebookCell-DMBvrxOz.js";
import { d as defineComponent, c as createElementBlock, a as createBaseVNode, f as createTextVNode, t as toDisplayString, H as Fragment, I as renderList, B as createBlock, r as ref, L as computed, o as openBlock, g as _export_sfc } from "./index-BAmalrlq.js";
import "./vue-codemirror.esm-DfAEZG05.js";
import "./index-DgPd_2U1.js";
import "./CellOutput-CK2tu127.js";
const _hoisted_1 = { class: "notebook-editor" };
const _hoisted_2 = { class: "notebook-toolbar" };
const _hoisted_3 = ["disabled"];
const _hoisted_4 = ["disabled"];
const _hoisted_5 = { class: "notebook-info" };
const _hoisted_6 = { class: "notebook-cells" };
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "NotebookEditor",
  props: {
    cells: {},
    kernelId: {},
    flowId: {},
    nodeId: {},
    dependingOnIds: {}
  },
  emits: ["update:cells"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emit = __emit;
    const executingCellId = ref(null);
    const executionCounter = ref(1);
    const isAnyExecuting = computed(() => executingCellId.value !== null);
    const updateCellCode = (cellId, code) => {
      emit(
        "update:cells",
        props.cells.map((c) => c.id === cellId ? { ...c, code } : c)
      );
    };
    const addCell = () => {
      emit("update:cells", [...props.cells, { id: crypto.randomUUID(), code: "", output: null }]);
    };
    const deleteCell = (cellId) => {
      if (props.cells.length <= 1) return;
      emit(
        "update:cells",
        props.cells.filter((c) => c.id !== cellId)
      );
    };
    const moveCell = (index, direction) => {
      const newIndex = index + direction;
      if (newIndex < 0 || newIndex >= props.cells.length) return;
      const newCells = [...props.cells];
      const [cell] = newCells.splice(index, 1);
      newCells.splice(newIndex, 0, cell);
      emit("update:cells", newCells);
    };
    const clearAllOutputs = () => {
      emit(
        "update:cells",
        props.cells.map((c) => ({ ...c, output: null }))
      );
    };
    const updateCellOutput = (cellId, output) => {
      emit(
        "update:cells",
        props.cells.map((c) => c.id === cellId ? { ...c, output } : c)
      );
    };
    const runCell = async (cellId) => {
      if (!props.kernelId) return false;
      const cell = props.cells.find((c) => c.id === cellId);
      if (!cell) return true;
      const codeToRun = cell.code;
      if (!codeToRun.trim()) return true;
      executingCellId.value = cellId;
      try {
        const result = await KernelApi.executeCell(props.kernelId, {
          node_id: props.nodeId,
          code: codeToRun,
          flow_id: props.flowId
        });
        const execCount = executionCounter.value++;
        updateCellOutput(cellId, {
          stdout: result.stdout,
          stderr: result.stderr,
          display_outputs: result.display_outputs,
          error: result.error,
          execution_time_ms: result.execution_time_ms,
          execution_count: execCount
        });
        return result.success;
      } catch (error) {
        const execCount = executionCounter.value++;
        updateCellOutput(cellId, {
          stdout: "",
          stderr: "",
          display_outputs: [],
          error: error instanceof Error ? error.message : String(error),
          execution_time_ms: 0,
          execution_count: execCount
        });
        return false;
      } finally {
        executingCellId.value = null;
      }
    };
    const runAllCells = async () => {
      for (const cell of props.cells) {
        const success = await runCell(cell.id);
        if (!success) break;
      }
    };
    const runCellAndAdvance = async (cellId, index) => {
      await runCell(cellId);
      if (index >= props.cells.length - 1) {
        addCell();
      }
    };
    const restartKernel = async () => {
      if (!props.kernelId) return;
      try {
        await KernelApi.clearNamespace(props.kernelId, props.flowId);
        clearAllOutputs();
        executionCounter.value = 1;
      } catch (error) {
        console.error("Failed to restart kernel:", error);
      }
    };
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1, [
        createBaseVNode("div", _hoisted_2, [
          createBaseVNode("button", {
            disabled: !__props.kernelId || isAnyExecuting.value,
            title: "Run All Cells",
            onClick: runAllCells
          }, [..._cache[0] || (_cache[0] = [
            createBaseVNode("i", { class: "fa-solid fa-play" }, null, -1),
            createTextVNode(" Run All ", -1)
          ])], 8, _hoisted_3),
          createBaseVNode("button", {
            title: "Clear All Outputs",
            onClick: clearAllOutputs
          }, [..._cache[1] || (_cache[1] = [
            createBaseVNode("i", { class: "fa-solid fa-eraser" }, null, -1),
            createTextVNode(" Clear ", -1)
          ])]),
          createBaseVNode("button", {
            disabled: !__props.kernelId || isAnyExecuting.value,
            title: "Restart Kernel (clear all variables)",
            onClick: restartKernel
          }, [..._cache[2] || (_cache[2] = [
            createBaseVNode("i", { class: "fa-solid fa-rotate-right" }, null, -1),
            createTextVNode(" Restart ", -1)
          ])], 8, _hoisted_4),
          createBaseVNode("span", _hoisted_5, toDisplayString(__props.cells.length) + " cell" + toDisplayString(__props.cells.length !== 1 ? "s" : ""), 1)
        ]),
        createBaseVNode("div", _hoisted_6, [
          (openBlock(true), createElementBlock(Fragment, null, renderList(__props.cells, (cell, index) => {
            return openBlock(), createBlock(NotebookCellComponent, {
              key: cell.id,
              cell,
              "cell-index": index,
              "is-executing": executingCellId.value === cell.id,
              "is-last-cell": index === __props.cells.length - 1,
              "cell-count": __props.cells.length,
              "onUpdate:code": (code) => updateCellCode(cell.id, code),
              onRunCell: () => runCell(cell.id),
              onRunCellAndAdvance: () => runCellAndAdvance(cell.id, index),
              onMoveUp: () => moveCell(index, -1),
              onMoveDown: () => moveCell(index, 1),
              onDelete: () => deleteCell(cell.id)
            }, null, 8, ["cell", "cell-index", "is-executing", "is-last-cell", "cell-count", "onUpdate:code", "onRunCell", "onRunCellAndAdvance", "onMoveUp", "onMoveDown", "onDelete"]);
          }), 128))
        ]),
        createBaseVNode("button", {
          class: "add-cell-button",
          onClick: addCell
        }, [..._cache[3] || (_cache[3] = [
          createBaseVNode("i", { class: "fa-solid fa-plus" }, null, -1),
          createTextVNode(" Add Cell ", -1)
        ])])
      ]);
    };
  }
});
const NotebookEditor = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-c6858ae0"]]);
export {
  NotebookEditor as default
};
