"""Domain-specific exceptions for the Flow Catalog system.

These exceptions represent business-rule violations and are raised by the
service layer.  Route handlers catch them and translate to appropriate
HTTP responses.
"""


class CatalogError(Exception):
    """Base exception for all catalog domain errors."""


class NamespaceNotFoundError(CatalogError):
    """Raised when a namespace lookup fails."""

    def __init__(self, namespace_id: int | None = None, name: str | None = None):
        self.namespace_id = namespace_id
        self.name = name
        detail = "Namespace not found"
        if namespace_id is not None:
            detail = f"Namespace with id={namespace_id} not found"
        elif name is not None:
            detail = f"Namespace '{name}' not found"
        super().__init__(detail)


class NamespaceExistsError(CatalogError):
    """Raised when attempting to create a duplicate namespace."""

    def __init__(self, name: str, parent_id: int | None = None):
        self.name = name
        self.parent_id = parent_id
        super().__init__(
            f"Namespace '{name}' already exists"
            + (f" under parent_id={parent_id}" if parent_id is not None else " at root level")
        )


class NestingLimitError(CatalogError):
    """Raised when attempting to nest namespaces deeper than catalog -> schema."""

    def __init__(self, parent_id: int, parent_level: int):
        self.parent_id = parent_id
        self.parent_level = parent_level
        super().__init__("Cannot nest deeper than catalog -> schema")


class NamespaceNotEmptyError(CatalogError):
    """Raised when trying to delete a namespace that still has children, flows, or tables."""

    def __init__(self, namespace_id: int, children: int = 0, flows: int = 0, tables: int = 0):
        self.namespace_id = namespace_id
        self.children = children
        self.flows = flows
        self.tables = tables
        parts = []
        if children:
            parts.append(f"{children} child namespace(s)")
        if flows:
            parts.append(f"{flows} flow(s)")
        if tables:
            parts.append(f"{tables} table(s)")
        detail = ", ".join(parts) if parts else "children or flows"
        super().__init__(f"Cannot delete namespace: still contains {detail}")


class FlowNotFoundError(CatalogError):
    """Raised when a flow registration lookup fails."""

    def __init__(self, registration_id: int | None = None, name: str | None = None):
        self.registration_id = registration_id
        self.name = name
        detail = "Flow not found"
        if registration_id is not None:
            detail = f"Flow with id={registration_id} not found"
        elif name is not None:
            detail = f"Flow '{name}' not found"
        super().__init__(detail)


class FlowExistsError(CatalogError):
    """Raised when attempting to create a duplicate flow registration."""

    def __init__(self, name: str, namespace_id: int | None = None):
        self.name = name
        self.namespace_id = namespace_id
        super().__init__(f"Flow '{name}' already exists in namespace_id={namespace_id}")


class RunNotFoundError(CatalogError):
    """Raised when a flow run lookup fails."""

    def __init__(self, run_id: int):
        self.run_id = run_id
        super().__init__(f"Run with id={run_id} not found")


class NotAuthorizedError(CatalogError):
    """Raised when a user attempts an action they are not permitted to perform."""

    def __init__(self, user_id: int, action: str = "perform this action"):
        self.user_id = user_id
        self.action = action
        super().__init__(f"User {user_id} is not authorized to {action}")


class FavoriteNotFoundError(CatalogError):
    """Raised when a favorite record is not found."""

    def __init__(self, user_id: int, registration_id: int):
        self.user_id = user_id
        self.registration_id = registration_id
        super().__init__(f"Favorite not found for user={user_id}, flow={registration_id}")


class FollowNotFoundError(CatalogError):
    """Raised when a follow record is not found."""

    def __init__(self, user_id: int, registration_id: int):
        self.user_id = user_id
        self.registration_id = registration_id
        super().__init__(f"Follow not found for user={user_id}, flow={registration_id}")


class FlowHasArtifactsError(CatalogError):
    """Raised when trying to delete a flow that still has active artifacts."""

    def __init__(self, registration_id: int, artifact_count: int):
        self.registration_id = registration_id
        self.artifact_count = artifact_count
        super().__init__(
            f"Cannot delete flow {registration_id}: " f"{artifact_count} active artifact(s) still reference it"
        )


class NoSnapshotError(CatalogError):
    """Raised when a run has no flow snapshot available."""

    def __init__(self, run_id: int):
        self.run_id = run_id
        super().__init__(f"No flow snapshot available for run id={run_id}")


class TableNotFoundError(CatalogError):
    """Raised when a catalog table lookup fails."""

    def __init__(self, table_id: int | None = None, name: str | None = None):
        self.table_id = table_id
        self.name = name
        detail = "Catalog table not found"
        if table_id is not None:
            detail = f"Catalog table with id={table_id} not found"
        elif name is not None:
            detail = f"Catalog table '{name}' not found"
        super().__init__(detail)


class TableExistsError(CatalogError):
    """Raised when attempting to create a duplicate catalog table."""

    def __init__(self, name: str, namespace_id: int | None = None):
        self.name = name
        self.namespace_id = namespace_id
        super().__init__(f"Catalog table '{name}' already exists in namespace_id={namespace_id}")


class TableFavoriteNotFoundError(CatalogError):
    """Raised when a table favorite record is not found."""

    def __init__(self, user_id: int, table_id: int):
        self.user_id = user_id
        self.table_id = table_id
        super().__init__(f"Table favorite not found for user={user_id}, table={table_id}")
