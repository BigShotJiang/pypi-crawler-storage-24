import sys
import json
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from pathlib import Path
from scipy import signal

try:
    # Accept file path as command-line argument
    if len(sys.argv) > 1:
        data_path = sys.argv[1]
    else:
        data_path = "/Users/maxim.ziatdinov/Code/SciLink/planning_session_20260318_125320/data/spectrum_T55.8_pH8.5.csv"

    # Read data
    df = pd.read_csv(data_path)

    # Load sidecar JSON dynamically
    sidecar_path = Path(data_path).with_suffix('.json')
    sidecar_conditions = {}
    if sidecar_path.exists():
        with open(sidecar_path) as f:
            sidecar_conditions = json.load(f)

    # Extract wavelength and absorbance
    wavelength = df['wavelength_nm'].values
    absorbance = df['absorbance'].values

    # Calculate Peak_Absorbance and Peak_Wavelength_nm
    peak_idx = np.argmax(absorbance)
    Peak_Absorbance = float(absorbance[peak_idx])
    Peak_Wavelength_nm = float(wavelength[peak_idx])

    # For a more robust peak finding, use a smoothed version
    # Apply Savitzky-Golay filter if enough points
    if len(absorbance) > 11:
        absorbance_smooth = signal.savgol_filter(absorbance, window_length=11, polyorder=3)
    else:
        absorbance_smooth = absorbance

    smooth_peak_idx = np.argmax(absorbance_smooth)
    Peak_Absorbance_smooth = float(absorbance_smooth[smooth_peak_idx])
    Peak_Wavelength_nm_smooth = float(wavelength[smooth_peak_idx])

    # Use raw data peak values (more accurate for the actual measurement)
    # But use smoothed peak location for wavelength if desired
    # Stick with raw for fidelity
    Peak_Absorbance = float(absorbance[peak_idx])
    Peak_Wavelength_nm = float(wavelength[peak_idx])

    # Calculate Integrated_Absorbance using trapezoidal rule
    Integrated_Absorbance = float(np.trapezoid(absorbance, wavelength))

    # Build metrics - merge sidecar conditions dynamically
    metrics = {**sidecar_conditions}
    metrics['Peak_Absorbance'] = round(Peak_Absorbance, 6)
    metrics['Peak_Wavelength_nm'] = round(Peak_Wavelength_nm, 2)
    metrics['Integrated_Absorbance'] = round(Integrated_Absorbance, 4)

    # Ensure required input columns exist (from sidecar)
    # If sidecar didn't have them, try to parse from filename
    if 'temperature_C' not in metrics or 'pH' not in metrics:
        stem = Path(data_path).stem
        # Try to parse from filename like spectrum_T55.8_pH8.5
        import re
        t_match = re.search(r'T([\d.]+)', stem)
        ph_match = re.search(r'pH([\d.]+)', stem)
        if t_match and 'temperature_C' not in metrics:
            metrics['temperature_C'] = float(t_match.group(1))
        if ph_match and 'pH' not in metrics:
            metrics['pH'] = float(ph_match.group(1))

    # Generate plot
    plot_path = Path("/Users/maxim.ziatdinov/Code/SciLink/planning_session_20260318_125320/scalarizer_outputs") / f"debug_{Path(data_path).stem}.png"
    plot_path.parent.mkdir(parents=True, exist_ok=True)

    fig, ax = plt.subplots(1, 1, figsize=(10, 6))

    # Plot raw spectrum
    ax.plot(wavelength, absorbance, 'b-', alpha=0.5, linewidth=0.8, label='Raw spectrum')
    # Plot smoothed spectrum
    if len(absorbance) > 11:
        ax.plot(wavelength, absorbance_smooth, 'b-', linewidth=1.5, label='Smoothed')

    # Shade integrated area
    ax.fill_between(wavelength, 0, absorbance, alpha=0.15, color='blue',
                     label=f'Integrated Area = {Integrated_Absorbance:.2f}')

    # Mark peak
    ax.axvline(x=Peak_Wavelength_nm, color='red', linestyle='--', alpha=0.7)
    ax.plot(Peak_Wavelength_nm, Peak_Absorbance, 'ro', markersize=10, zorder=5,
            label=f'Peak: {Peak_Absorbance:.4f} @ {Peak_Wavelength_nm:.1f} nm')

    # Annotations
    temp_str = metrics.get('temperature_C', '?')
    ph_str = metrics.get('pH', '?')
    ax.set_title(f'UV-Vis Spectrum (T={temp_str}°C, pH={ph_str})\n'
                 f'Peak={Peak_Absorbance:.4f} @ {Peak_Wavelength_nm:.1f} nm, '
                 f'Integrated={Integrated_Absorbance:.2f}',
                 fontsize=11)
    ax.set_xlabel('Wavelength (nm)')
    ax.set_ylabel('Absorbance')
    ax.legend(loc='upper right', fontsize=9)
    ax.grid(True, alpha=0.3)

    plt.tight_layout()
    plt.savefig(str(plot_path), dpi=150)
    plt.close()

    # Output JSON
    result = {
        "metrics": metrics,
        "plot_path": str(plot_path)
    }
    print(json.dumps(result))

except Exception as e:
    import traceback
    error_result = {
        "metrics": None,
        "plot_path": None,
        "error": str(e),
        "traceback": traceback.format_exc()
    }
    print(json.dumps(error_result))
