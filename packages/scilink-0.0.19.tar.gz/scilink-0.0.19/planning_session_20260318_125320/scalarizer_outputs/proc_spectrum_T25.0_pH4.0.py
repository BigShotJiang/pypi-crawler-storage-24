import sys
import json
import pandas as pd
import numpy as np
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

try:
    # Accept file path as command-line argument
    if len(sys.argv) > 1:
        data_path = sys.argv[1]
    else:
        data_path = "/Users/maxim.ziatdinov/Code/SciLink/planning_session_20260318_125320/data/spectrum_T25.0_pH4.0.csv"

    # Read data
    df = pd.read_csv(data_path)

    # Load sidecar JSON dynamically
    sidecar_path = Path(data_path).with_suffix('.json')
    sidecar_conditions = {}
    if sidecar_path.exists():
        with open(sidecar_path) as f:
            sidecar_conditions = json.load(f)

    # Extract wavelength and absorbance
    wavelength = df['wavelength_nm'].values
    absorbance = df['absorbance'].values

    # Calculate peak absorbance and peak wavelength
    peak_idx = np.argmax(absorbance)
    peak_absorbance = float(absorbance[peak_idx])
    peak_wavelength = float(wavelength[peak_idx])

    # Calculate integrated absorbance (area under the curve)
    integrated_absorbance = float(np.trapezoid(absorbance, wavelength))

    # Build metrics: sidecar conditions + derived targets
    metrics = {
        **sidecar_conditions,
        "Peak_Absorbance": peak_absorbance,
        "Peak_Wavelength_nm": peak_wavelength,
        "Integrated_Absorbance": integrated_absorbance
    }

    # Generate plot
    output_dir = Path("/Users/maxim.ziatdinov/Code/SciLink/planning_session_20260318_125320/scalarizer_outputs")
    output_dir.mkdir(parents=True, exist_ok=True)
    plot_path = output_dir / f"debug_{Path(data_path).stem}.png"

    fig, ax = plt.subplots(1, 1, figsize=(8, 5))

    # Plot spectrum and shade integrated area
    ax.fill_between(wavelength, absorbance, alpha=0.3, color='steelblue', label=f'Integrated area = {integrated_absorbance:.4f}')
    ax.plot(wavelength, absorbance, color='steelblue', linewidth=1.0)

    # Mark the peak
    ax.axvline(peak_wavelength, color='red', linestyle='--', alpha=0.7, linewidth=0.8)
    ax.plot(peak_wavelength, peak_absorbance, 'ro', markersize=8, zorder=5,
            label=f'Peak: {peak_absorbance:.4f} @ {peak_wavelength:.0f} nm')

    ax.set_xlabel('Wavelength (nm)', fontsize=12)
    ax.set_ylabel('Absorbance', fontsize=12)
    ax.set_title(f'UV-Vis Spectrum (T={sidecar_conditions.get("temperature_C", "?")}°C, pH={sidecar_conditions.get("pH", "?")})', fontsize=13)
    ax.legend(fontsize=10, loc='upper right')
    ax.grid(True, alpha=0.3)

    plt.tight_layout()
    fig.savefig(str(plot_path), dpi=150)
    plt.close(fig)

    # Output JSON
    result = {
        "metrics": metrics,
        "plot_path": str(plot_path)
    }
    print(json.dumps(result))

except Exception as e:
    error_result = {
        "metrics": None,
        "plot_path": None,
        "error": str(e)
    }
    print(json.dumps(error_result))
