from opentrons import protocol_api

metadata = {
    'protocolName': 'REE Precipitation Screening - NdFeB Leachate',
    'author': 'OpentronsAI',
    'description': 'High-throughput screening for selective precipitation of Nd and Dy from NdFeB magnet leachate',
    'source': 'OpentronsAI'
}

requirements = {
    'robotType': 'OT-2',
    'apiLevel': '2.19'
}

def run(protocol: protocol_api.ProtocolContext):
    
    # ===== LABWARE SETUP =====
    protocol.comment("Loading labware...")
    
    # Plates and reservoirs
    reaction_plate = protocol.load_labware('nest_96_wellplate_2ml_deep', '1', 'Reaction Plate')
    reservoir = protocol.load_labware('nest_12_reservoir_15ml', '2', 'Reagent Reservoir')
    sampling_plate = protocol.load_labware('nest_96_wellplate_200ul_flat', '3', 'ICP-MS Sampling Plate')
    
    # Tip racks
    tiprack_1 = protocol.load_labware('opentrons_96_tiprack_300ul', '4', 'Tips 1')
    tiprack_2 = protocol.load_labware('opentrons_96_tiprack_300ul', '5', 'Tips 2')
    tiprack_3 = protocol.load_labware('opentrons_96_tiprack_300ul', '6', 'Tips 3')
    
    # Pipette
    p300 = protocol.load_instrument(
        'p300_single_gen2',
        'left',
        tip_racks=[tiprack_1, tiprack_2, tiprack_3]
    )
    
    # ===== EXPERIMENTAL DESIGN PARAMETERS =====
    protocol.comment("Setting up experimental parameters...")
    
    # H2O2 volumes (µL) for rows A-H
    # Corresponds to 0, 0, 1.0, 1.0, 1.5, 1.5, 2.0, 3.0 × stoichiometric
    h2o2_volumes = [0, 0, 10, 10, 15, 15, 20, 30]
    
    # Oxalic acid volumes (µL) for column groups
    # Columns 1-3: 0.8× stoich, 4-6: 1.0× stoich, 7-9: 1.2× stoich, 10-12: 1.4× stoich
    oxalate_volumes = {
        'cols_1_3': 40,    # 0.8× stoichiometric
        'cols_4_6': 50,    # 1.0× stoichiometric
        'cols_7_9': 60,    # 1.2× stoichiometric
        'cols_10_12': 70   # 1.4× stoichiometric
    }
    
    # Target total volume
    target_volume = 300  # µL
    
    # ===== STEP 1: DISPENSE LEACHATE =====
    protocol.comment("Step 1: Dispensing 200 µL leachate to all wells...")
    
    # Transfer leachate from reservoir A1 to all 96 wells
    p300.transfer(
        200,
        reservoir['A1'],
        reaction_plate.wells(),
        new_tip='once'
    )
    
    # ===== STEP 2: ADD H2O2 =====
    protocol.comment("Step 2: Adding H2O2 based on row assignments...")
    
    # Process each row with its corresponding H2O2 volume
    for row_idx, h2o2_vol in enumerate(h2o2_volumes):
        if h2o2_vol > 0:  # Skip rows with 0 µL H2O2
            row_letter = 'ABCDEFGH'[row_idx]
            protocol.comment(f"Adding {h2o2_vol} µL H2O2 to row {row_letter}")
            
            # Get all wells in this row
            row_wells = reaction_plate.rows()[row_idx]
            
            # Pick up tip once for this H2O2 volume
            p300.pick_up_tip()
            
            # Add H2O2 to all wells in the row
            for well in row_wells:
                p300.transfer(h2o2_vol, reservoir['A2'], well, new_tip='never')
            
            p300.drop_tip()
    
    # ===== STEP 3: MIX AFTER H2O2 ADDITION =====
    protocol.comment("Step 3: Mixing wells that received H2O2...")
    
    for row_idx, h2o2_vol in enumerate(h2o2_volumes):
        if h2o2_vol > 0:
            row_letter = 'ABCDEFGH'[row_idx]
            protocol.comment(f"Mixing row {row_letter}")
            
            row_wells = reaction_plate.rows()[row_idx]
            
            # Pick up tip once for mixing this row
            p300.pick_up_tip()
            
            for well in row_wells:
                p300.mix(3, 150, well)
            
            p300.drop_tip()
    
    # ===== STEP 4: OXIDATION DELAY =====
    protocol.comment("Step 4: Pausing for 30 minutes to allow Fe2+ oxidation...")
    protocol.delay(minutes=30)
    
    # ===== STEP 5: ADD OXALIC ACID =====
    protocol.comment("Step 5: Adding oxalic acid based on column groups...")
    
    # Define column groups
    column_groups = [
        (range(0, 3), oxalate_volumes['cols_1_3'], '1-3'),
        (range(3, 6), oxalate_volumes['cols_4_6'], '4-6'),
        (range(6, 9), oxalate_volumes['cols_7_9'], '7-9'),
        (range(9, 12), oxalate_volumes['cols_10_12'], '10-12')
    ]
    
    for col_range, oxalate_vol, col_label in column_groups:
        protocol.comment(f"Adding {oxalate_vol} µL oxalic acid to columns {col_label}")
        
        # Pick up tip once for this oxalate volume
        p300.pick_up_tip()
        
        for col_idx in col_range:
            column_wells = reaction_plate.columns()[col_idx]
            for well in column_wells:
                p300.transfer(oxalate_vol, reservoir['A3'], well, new_tip='never')
        
        p300.drop_tip()
    
    # ===== STEP 6: MIX AFTER OXALIC ACID =====
    protocol.comment("Step 6: Mixing after oxalic acid addition...")
    
    for well in reaction_plate.wells():
        p300.pick_up_tip()
        p300.mix(5, 150, well)
        p300.drop_tip()
    
    # ===== STEP 7: ADD DI WATER FOR VOLUME NORMALIZATION =====
    protocol.comment("Step 7: Adding DI water to normalize total volume to 300 µL...")
    
    # Calculate water volume for each well based on its row and column
    for row_idx in range(8):
        h2o2_vol = h2o2_volumes[row_idx]
        
        for col_idx in range(12):
            # Determine oxalate volume for this column
            if col_idx < 3:
                oxalate_vol = oxalate_volumes['cols_1_3']
            elif col_idx < 6:
                oxalate_vol = oxalate_volumes['cols_4_6']
            elif col_idx < 9:
                oxalate_vol = oxalate_volumes['cols_7_9']
            else:
                oxalate_vol = oxalate_volumes['cols_10_12']
            
            # Calculate water volume needed
            water_vol = target_volume - 200 - h2o2_vol - oxalate_vol
            
            # Get the well
            well = reaction_plate.rows()[row_idx][col_idx]
            
            # Add water
            if water_vol > 0:
                p300.pick_up_tip()
                p300.transfer(water_vol, reservoir['A4'], well, new_tip='never')
                p300.drop_tip()
    
    # ===== STEP 8: PAUSE FOR PRECIPITATION =====
    protocol.comment("=" * 60)
    protocol.comment("PROTOCOL PAUSE")
    protocol.comment("=" * 60)
    protocol.comment("Remove the reaction plate for 24h precipitation at room temperature.")
    protocol.comment("After precipitation, centrifuge the plate.")
    protocol.comment("Return the plate to slot 1 and resume the protocol.")
    protocol.comment("=" * 60)
    protocol.pause("Remove plate for 24h precipitation and centrifugation. Return plate to slot 1 before resuming.")
    
    # ===== STEP 9: SAMPLE SUPERNATANT FOR ICP-MS =====
    protocol.comment("Step 9: Sampling 100 µL supernatant for ICP-MS analysis...")
    
    # Transfer supernatant from each well of reaction plate to corresponding well in sampling plate
    # Use new tips for each transfer to avoid cross-contamination
    for well_idx, (source_well, dest_well) in enumerate(zip(reaction_plate.wells(), sampling_plate.wells())):
        if (well_idx + 1) % 12 == 1:  # Progress indicator every row
            row_letter = 'ABCDEFGH'[well_idx // 12]
            protocol.comment(f"Sampling row {row_letter}...")
        
        p300.transfer(
            100,
            source_well,
            dest_well,
            new_tip='always'
        )
    
    protocol.comment("=" * 60)
    protocol.comment("Protocol complete!")
    protocol.comment("Sampling plate ready for ICP-MS analysis.")
    protocol.comment("=" * 60)
