import sys
import json
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from pathlib import Path

try:
    # Accept file path as command-line argument
    if len(sys.argv) > 1:
        data_path = sys.argv[1]
    else:
        data_path = "/Users/maxim.ziatdinov/Code/SciLink/planning_session_20260318_113511/data/round1_oxalate_precipitation.csv"

    # Read data
    df = pd.read_csv(data_path)

    # Load sidecar if exists
    sidecar_path = Path(data_path).with_suffix('.json')
    sidecar_conditions = {}
    if sidecar_path.exists():
        with open(sidecar_path) as f:
            sidecar_conditions = json.load(f)

    # Filter to experimental wells only
    df_exp = df[df['Well_Type'] == 'Experimental'].copy()

    # Define input and target columns
    input_cols = ['H2O2_Stoich_Factor', 'Oxalate_Stoich_Factor']
    target_cols = ['Nd_Recovery_pct', 'Dy_Recovery_pct', 'Fe_Rejection_pct', 'Selectivity_Index']

    # Group by conditions and compute mean of targets
    grouped = df_exp.groupby(input_cols)[target_cols].mean().reset_index()

    # Build multi-row metrics
    metrics_list = []
    for _, row in grouped.iterrows():
        entry = {}
        for col in input_cols + target_cols:
            entry[col] = round(float(row[col]), 4)
        # Merge sidecar conditions if any
        entry = {**sidecar_conditions, **entry}
        metrics_list.append(entry)

    # --- Plotting ---
    fig, axes = plt.subplots(2, 2, figsize=(12, 10))
    fig.suptitle('Round 1 Oxalate Precipitation: Mean Targets by Condition', fontsize=14, fontweight='bold')

    # Create pivot tables for heatmap-style plots
    for idx, target in enumerate(target_cols):
        ax = axes[idx // 2][idx % 2]
        pivot = grouped.pivot(index='H2O2_Stoich_Factor', columns='Oxalate_Stoich_Factor', values=target)
        
        # Plot as a colored table / imshow
        im = ax.imshow(pivot.values, cmap='YlGnBu', aspect='auto')
        
        # Set tick labels
        ax.set_xticks(range(len(pivot.columns)))
        ax.set_xticklabels([f'{v:.1f}' for v in pivot.columns])
        ax.set_yticks(range(len(pivot.index)))
        ax.set_yticklabels([f'{v:.1f}' for v in pivot.index])
        ax.set_xlabel('Oxalate_Stoich_Factor')
        ax.set_ylabel('H2O2_Stoich_Factor')
        ax.set_title(target)
        
        # Annotate cells with values
        for i in range(len(pivot.index)):
            for j in range(len(pivot.columns)):
                val = pivot.values[i, j]
                text_color = 'white' if val > (pivot.values.max() + pivot.values.min()) / 2 else 'black'
                ax.text(j, i, f'{val:.1f}', ha='center', va='center', color=text_color, fontsize=9, fontweight='bold')
        
        plt.colorbar(im, ax=ax, shrink=0.8)

    plt.tight_layout()
    
    plot_path = Path("/Users/maxim.ziatdinov/Code/SciLink/planning_session_20260318_113511/scalarizer_outputs") / f"debug_{Path(data_path).stem}.png"
    plt.savefig(str(plot_path), dpi=150, bbox_inches='tight')
    plt.close()

    # Output results
    result = {
        "metrics": metrics_list,
        "plot_path": str(plot_path)
    }
    print(json.dumps(result))

except Exception as e:
    import traceback
    error_result = {
        "metrics": None,
        "plot_path": None,
        "error": str(e),
        "traceback": traceback.format_exc()
    }
    print(json.dumps(error_result))
