from opentrons import protocol_api

metadata = {
    'protocolName': 'Selective Precipitation Screen - Nd/Dy Separation',
    'author': 'OpentronsAI',
    'description': '''96-well aqueous selective precipitation screen for separating 
                   Neodymium (Nd) and Dysprosium (Dy). This protocol sets up a gradient 
                   of HCl and Ligand concentrations across the plate to identify optimal 
                   precipitation conditions. Final volume per well: 850 µL 
                   (250 µL stock + 600 µL reagents).''',
    'source': 'OpentronsAI'
}

requirements = {
    'robotType': 'Flex',
    'apiLevel': '2.25'
}

def run(protocol: protocol_api.ProtocolContext):
    
    # ===================== LABWARE SETUP =====================
    
    # Load tip racks - we'll need multiple for this protocol
    tips_1000_1 = protocol.load_labware(
        'opentrons_flex_96_tiprack_1000ul', 'A1')
    tips_1000_2 = protocol.load_labware(
        'opentrons_flex_96_tiprack_1000ul', 'A2')
    tips_1000_3 = protocol.load_labware(
        'opentrons_flex_96_tiprack_1000ul', 'B1')
    
    # Load 2mL deep well reaction plate (96-well format)
    reaction_plate = protocol.load_labware(
        'nest_96_wellplate_2ml_deep', 'D1',
        label='Reaction Plate')
    
    # Load reservoir for stock solution and reagents
    # Using 12-well reservoir: A1=Nd/Dy stock, A2=HCl, A3=Ligand
    reservoir = protocol.load_labware(
        'nest_12_reservoir_15ml', 'D2',
        label='Reagent Reservoir')
    
    # Load trash bin
    trash = protocol.load_trash_bin('A3')
    
    # ===================== PIPETTE SETUP =====================
    
    # Load 8-channel pipette for efficient column-wise operations
    # Using 1000 µL pipette to handle the larger volumes needed
    p1000_multi = protocol.load_instrument(
        'flex_8channel_1000',
        'left',
        tip_racks=[tips_1000_1, tips_1000_2, tips_1000_3])
    
    # ===================== LIQUID DEFINITIONS =====================
    
    # Define liquids for visualization in the Opentrons App
    nd_dy_stock = protocol.define_liquid(
        name='Nd/Dy Stock Solution',
        description='Aqueous stock solution containing Nd and Dy',
        display_color='#50C878')  # Emerald green
    
    hcl_solution = protocol.define_liquid(
        name='HCl Solution',
        description='Hydrochloric acid solution for precipitation',
        display_color='#FF6B6B')  # Red
    
    ligand_solution = protocol.define_liquid(
        name='Ligand Solution',
        description='Selective ligand for Nd/Dy separation',
        display_color='#4169E1')  # Royal blue
    
    # Load liquids into reservoir
    reservoir['A1'].load_liquid(nd_dy_stock, 25000)  # 25 mL stock
    reservoir['A2'].load_liquid(hcl_solution, 40000)  # 40 mL HCl
    reservoir['A3'].load_liquid(ligand_solution, 40000)  # 40 mL Ligand
    
    # ===================== PROTOCOL STEPS =====================
    
    protocol.comment('=== Starting Selective Precipitation Screen ===')
    protocol.comment('This protocol creates a gradient of HCl and Ligand concentrations')
    protocol.comment('across a 96-well plate for aqueous Nd/Dy separation.')
    
    # STEP 1: Distribute Nd/Dy stock solution to all wells
    protocol.comment('\n--- Step 1: Adding 250 µL Nd/Dy stock to all wells ---')
    
    # Transfer 250 µL of stock solution to all 12 columns
    # Using column-wise transfer with 8-channel pipette
    for col_index in range(12):
        p1000_multi.transfer(
            volume=250,
            source=reservoir['A1'],
            dest=reaction_plate.columns()[col_index][0],  # Access first well of each column
            new_tip='always',
            blow_out=True,
            blowout_location='destination well')
    
    protocol.comment('Stock solution distribution complete.')
    
    # STEP 2: Create gradient of HCl and Ligand solutions
    # Total reagent volume per well = 600 µL (HCl + Ligand)
    # We'll create a gradient across columns 1-12
    # Column 1: High HCl (500 µL), Low Ligand (100 µL)
    # Column 12: Low HCl (100 µL), High Ligand (500 µL)
    # Linear gradient in between
    
    protocol.comment('\n--- Step 2: Creating HCl and Ligand gradient ---')
    protocol.comment('Gradient design:')
    protocol.comment('  Column 1:  500 µL HCl + 100 µL Ligand')
    protocol.comment('  Column 6:  300 µL HCl + 300 µL Ligand')
    protocol.comment('  Column 12: 100 µL HCl + 500 µL Ligand')
    
    # Define gradient volumes for each column
    # HCl decreases from 500 to 100 µL across 12 columns
    # Ligand increases from 100 to 500 µL across 12 columns
    hcl_volumes = []
    ligand_volumes = []
    
    for col in range(12):
        # Linear gradient calculation
        # HCl: starts at 500, decreases by ~36.4 µL per column
        hcl_vol = 500 - (col * 400 / 11)
        # Ligand: starts at 100, increases by ~36.4 µL per column
        ligand_vol = 100 + (col * 400 / 11)
        
        hcl_volumes.append(round(hcl_vol, 1))
        ligand_volumes.append(round(ligand_vol, 1))
    
    # Add HCl solution with gradient
    protocol.comment('\n--- Adding HCl solution (gradient: 500 → 100 µL) ---')
    for col_index in range(12):
        p1000_multi.transfer(
            volume=hcl_volumes[col_index],
            source=reservoir['A2'],
            dest=reaction_plate.columns()[col_index][0],
            new_tip='always',
            mix_after=(3, 200),  # Mix 3 times with 200 µL after adding
            blow_out=True,
            blowout_location='destination well')
        
        protocol.comment(f'Column {col_index + 1}: Added {hcl_volumes[col_index]} µL HCl')
    
    # Add Ligand solution with gradient
    protocol.comment('\n--- Adding Ligand solution (gradient: 100 → 500 µL) ---')
    for col_index in range(12):
        p1000_multi.transfer(
            volume=ligand_volumes[col_index],
            source=reservoir['A3'],
            dest=reaction_plate.columns()[col_index][0],
            new_tip='always',
            mix_after=(5, 400),  # Mix 5 times with 400 µL for thorough mixing
            blow_out=True,
            blowout_location='destination well')
        
        protocol.comment(f'Column {col_index + 1}: Added {ligand_volumes[col_index]} µL Ligand')
    
    # ===================== PROTOCOL SUMMARY =====================
    
    protocol.comment('\n=== Selective Precipitation Screen Setup Complete ===')
    protocol.comment('\nFinal composition per well:')
    protocol.comment('  - 250 µL Nd/Dy stock solution')
    protocol.comment('  - Variable HCl (100-500 µL)')
    protocol.comment('  - Variable Ligand (100-500 µL)')
    protocol.comment('  - Total volume: 850 µL')
    protocol.comment('\nGradient Summary:')
    for col_index in range(12):
        total_vol = 250 + hcl_volumes[col_index] + ligand_volumes[col_index]
        protocol.comment(f'  Column {col_index + 1}: {hcl_volumes[col_index]} µL HCl + '
                        f'{ligand_volumes[col_index]} µL Ligand (Total: {total_vol} µL)')
    
    protocol.comment('\n*** NEXT STEPS (OFF-DECK): ***')
    protocol.comment('1. Seal the reaction plate with appropriate sealing film')
    protocol.comment('2. Place on orbital shaker at appropriate speed for 24 hours')
    protocol.comment('3. Centrifuge to pellet precipitated material')
    protocol.comment('4. Analyze supernatant and pellet for Nd/Dy content')
    protocol.comment('\nProtocol complete. Remove plate for off-deck processing.')
