from opentrons import protocol_api

metadata = {
    'protocolName': 'Liquid-Liquid Extraction - Nd/Dy Separation',
    'author': 'OpentronsAI',
    'description': '''Liquid-liquid extraction protocol for separating Neodymium (Nd) 
                   and Dysprosium (Dy) from aqueous leachate using organic extractants.
                   Uses 8-channel pipette for efficient 96-well plate processing.''',
    'source': 'OpentronsAI'
}

requirements = {
    'robotType': 'Flex',
    'apiLevel': '2.25'
}

def run(protocol: protocol_api.ProtocolContext):
    
    # ===================== LABWARE SETUP =====================
    
    # Load tip racks - we'll need multiple racks for this protocol
    # Using 1000 µL tips for the 8-channel pipette
    tiprack_1 = protocol.load_labware(
        'opentrons_flex_96_tiprack_1000ul', 
        'A1',
        'Tips for aqueous transfer'
    )
    tiprack_2 = protocol.load_labware(
        'opentrons_flex_96_tiprack_1000ul', 
        'A2',
        'Tips for organic transfer'
    )
    tiprack_3 = protocol.load_labware(
        'opentrons_flex_96_tiprack_1000ul', 
        'B1',
        'Tips for mixing'
    )
    tiprack_4 = protocol.load_labware(
        'opentrons_flex_96_tiprack_1000ul', 
        'B2',
        'Tips for organic phase transfer'
    )
    
    # Load reservoirs for aqueous leachate and organic extractants
    # Using 12-well reservoirs for easy access with 8-channel pipette
    aqueous_reservoir = protocol.load_labware(
        'nest_12_reservoir_15ml',
        'C1',
        'Aqueous Leachate Reservoir'
    )
    organic_reservoir = protocol.load_labware(
        'nest_12_reservoir_15ml',
        'C2',
        'Organic Extractant Reservoir'
    )
    
    # Load 96-well plates
    # Extraction plate - where mixing occurs
    extraction_plate = protocol.load_labware(
        'nest_96_wellplate_2ml_deep',
        'D1',
        'Extraction Plate (mixing)'
    )
    
    # Collection plate - for separated organic phase
    collection_plate = protocol.load_labware(
        'nest_96_wellplate_2ml_deep',
        'D2',
        'Collection Plate (organic phase)'
    )
    
    # Load trash bin
    trash = protocol.load_trash_bin('A3')
    
    # ===================== PIPETTE SETUP =====================
    
    # Load 8-channel 1000 µL pipette on left mount
    pipette = protocol.load_instrument(
        'flex_8channel_1000',
        'left',
        tip_racks=[tiprack_1, tiprack_2, tiprack_3, tiprack_4]
    )
    
    # ===================== PROTOCOL PARAMETERS =====================
    
    # Volume parameters (in µL)
    aqueous_volume = 100
    organic_volume = 100
    mixing_volume = 150  # Volume for mixing (should be less than total to avoid overflow)
    mixing_repetitions = 10  # Number of mix cycles to simulate shaking
    organic_transfer_volume = 50  # Volume of organic phase to transfer
    
    # Separation time (in minutes)
    separation_time = 5
    
    # Height parameters for careful organic phase aspiration
    # Aspirate from top of liquid to get organic phase (less dense, floats on top)
    organic_phase_height = -2  # mm from top of well
    
    # ===================== PROTOCOL STEPS =====================
    
    protocol.comment("=" * 50)
    protocol.comment("LIQUID-LIQUID EXTRACTION PROTOCOL")
    protocol.comment("Nd/Dy Separation")
    protocol.comment("=" * 50)
    
    # STEP 1: Transfer aqueous leachate to extraction plate
    protocol.comment("\n--- STEP 1: Adding aqueous leachate to extraction plate ---")
    protocol.comment(f"Transferring {aqueous_volume} µL of aqueous leachate to all wells")
    
    # Transfer to all 12 columns using 8-channel pipette
    # The 8-channel will handle all 8 rows simultaneously
    for column_index in range(12):
        pipette.transfer(
            volume=aqueous_volume,
            source=aqueous_reservoir['A1'],  # All channels aspirate from same reservoir well
            dest=extraction_plate.columns()[column_index][0],  # Target first well of each column
            new_tip='always',
            blow_out=True,
            blowout_location='destination well'
        )
    
    # STEP 2: Transfer organic extractant to extraction plate
    protocol.comment("\n--- STEP 2: Adding organic extractant to extraction plate ---")
    protocol.comment(f"Transferring {organic_volume} µL of organic extractant to all wells")
    
    for column_index in range(12):
        pipette.transfer(
            volume=organic_volume,
            source=organic_reservoir['A1'],
            dest=extraction_plate.columns()[column_index][0],
            new_tip='always',
            blow_out=True,
            blowout_location='destination well'
        )
    
    # STEP 3: Mix to simulate shaking
    protocol.comment("\n--- STEP 3: Mixing aqueous and organic phases ---")
    protocol.comment(f"Mixing {mixing_repetitions} times with {mixing_volume} µL to simulate shaking")
    protocol.comment("This creates intimate contact between phases for extraction")
    
    for column_index in range(12):
        pipette.pick_up_tip()
        
        # Mix thoroughly to create emulsion for extraction
        # Using the well's center position for mixing
        for mix_cycle in range(mixing_repetitions):
            pipette.aspirate(
                volume=mixing_volume,
                location=extraction_plate.columns()[column_index][0].bottom(z=2)
            )
            pipette.dispense(
                volume=mixing_volume,
                location=extraction_plate.columns()[column_index][0].bottom(z=5)
            )
        
        # Final dispense to ensure all liquid is in the well
        pipette.blow_out(extraction_plate.columns()[column_index][0].top())
        pipette.drop_tip()
    
    # STEP 4: Pause for phase separation
    protocol.comment("\n--- STEP 4: Phase separation ---")
    protocol.comment(f"Pausing for {separation_time} minutes to allow phases to separate")
    protocol.comment("Organic phase (less dense) will rise to the top")
    protocol.comment("Aqueous phase (more dense) will settle to the bottom")
    
    protocol.delay(minutes=separation_time)
    
    # STEP 5: Carefully transfer organic phase to collection plate
    protocol.comment("\n--- STEP 5: Transferring organic phase to collection plate ---")
    protocol.comment(f"Carefully aspirating {organic_transfer_volume} µL from top layer (organic phase)")
    protocol.comment("Using slow aspiration to avoid disturbing the interface")
    
    # Reduce flow rate for careful aspiration of organic phase
    pipette.flow_rate.aspirate = 50  # Slower aspiration (default is ~478 µL/s for this pipette)
    pipette.flow_rate.dispense = 100  # Normal dispense speed
    
    for column_index in range(12):
        pipette.pick_up_tip()
        
        # Aspirate from near the top of the well to get organic phase
        # The organic phase floats on top due to lower density
        pipette.aspirate(
            volume=organic_transfer_volume,
            location=extraction_plate.columns()[column_index][0].top(z=organic_phase_height),
            rate=0.5  # Even slower rate (50% of already reduced flow rate)
        )
        
        # Small air gap to prevent dripping during transfer
        pipette.air_gap(volume=10)
        
        # Dispense into collection plate
        pipette.dispense(
            volume=organic_transfer_volume + 10,  # Include air gap volume
            location=collection_plate.columns()[column_index][0].bottom(z=2)
        )
        
        # Blow out to ensure complete transfer
        pipette.blow_out(collection_plate.columns()[column_index][0].top())
        
        # Touch tip to remove any droplets
        pipette.touch_tip(location=collection_plate.columns()[column_index][0])
        
        pipette.drop_tip()
    
    # Reset flow rates to default
    pipette.flow_rate.aspirate = 478
    pipette.flow_rate.dispense = 478
    
    # ===================== PROTOCOL COMPLETE =====================
    
    protocol.comment("\n" + "=" * 50)
    protocol.comment("PROTOCOL COMPLETE")
    protocol.comment("=" * 50)
    protocol.comment("\nResults:")
    protocol.comment("- Extraction plate contains aqueous phase (bottom layer) with remaining Nd/Dy")
    protocol.comment("- Collection plate contains organic phase with extracted metals")
    protocol.comment("\nNext steps:")
    protocol.comment("- Analyze organic phase in collection plate for metal content")
    protocol.comment("- Aqueous phase can be subjected to additional extraction cycles if needed")
    protocol.comment("=" * 50)