import sys
import json
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from pathlib import Path
from scipy import signal

try:
    # Accept file path as command-line argument
    if len(sys.argv) > 1:
        data_path = sys.argv[1]
    else:
        data_path = "/Users/maxim.ziatdinov/Code/SciLink/planning_session_20260318_100425/data/spectrum_T55.4_pH9.0.csv"

    # Read data
    df = pd.read_csv(data_path)

    # Load sidecar conditions dynamically
    sidecar_path = Path(data_path).with_suffix('.json')
    sidecar_conditions = {}
    if sidecar_path.exists():
        with open(sidecar_path) as f:
            sidecar_conditions = json.load(f)

    wavelength = df['wavelength_nm'].values
    absorbance = df['absorbance'].values

    # Peak Absorbance and Peak Wavelength
    peak_idx = np.argmax(absorbance)
    Peak_Absorbance = float(absorbance[peak_idx])
    Peak_Wavelength_nm = float(wavelength[peak_idx])

    # For a more refined peak, use parabolic interpolation around the max
    if 1 <= peak_idx <= len(absorbance) - 2:
        y0, y1, y2 = absorbance[peak_idx - 1], absorbance[peak_idx], absorbance[peak_idx + 1]
        x0, x1, x2 = wavelength[peak_idx - 1], wavelength[peak_idx], wavelength[peak_idx + 1]
        # Parabolic interpolation
        denom = 2.0 * (2*y1 - y0 - y2)
        if abs(denom) > 1e-12:
            shift = (y0 - y2) / denom
            Peak_Wavelength_nm = float(x1 + shift * (x2 - x1))
            Peak_Absorbance = float(y1 + 0.25 * (y0 - y2) * shift)

    # Integrated Absorbance (area under the curve using trapezoidal rule)
    Integrated_Absorbance = float(np.trapezoid(absorbance, wavelength))

    # Build metrics
    metrics = {
        **sidecar_conditions,
        "Peak_Absorbance": round(Peak_Absorbance, 6),
        "Peak_Wavelength_nm": round(Peak_Wavelength_nm, 2),
        "Integrated_Absorbance": round(Integrated_Absorbance, 4)
    }

    # Plot
    plot_path = Path("/Users/maxim.ziatdinov/Code/SciLink/planning_session_20260318_100425/scalarizer_outputs") / f"debug_{Path(data_path).stem}.png"
    plot_path.parent.mkdir(parents=True, exist_ok=True)

    fig, ax = plt.subplots(1, 1, figsize=(8, 5))
    ax.plot(wavelength, absorbance, 'b-', linewidth=0.8, label='Spectrum')
    ax.fill_between(wavelength, absorbance, alpha=0.15, color='blue', label=f'Integrated = {Integrated_Absorbance:.2f}')
    ax.axvline(Peak_Wavelength_nm, color='red', linestyle='--', alpha=0.7, label=f'Peak @ {Peak_Wavelength_nm:.1f} nm')
    ax.plot(Peak_Wavelength_nm, Peak_Absorbance, 'ro', markersize=8, zorder=5, label=f'Peak Abs = {Peak_Absorbance:.4f}')
    ax.set_xlabel('Wavelength (nm)')
    ax.set_ylabel('Absorbance')
    temp_val = sidecar_conditions.get('temperature_C', '?')
    ph_val = sidecar_conditions.get('pH', '?')
    ax.set_title(f'UV-Vis Spectrum (T={temp_val}°C, pH={ph_val})\nPeak={Peak_Absorbance:.4f} @ {Peak_Wavelength_nm:.1f} nm, Area={Integrated_Absorbance:.2f}')
    ax.legend(loc='best', fontsize=9)
    ax.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(str(plot_path), dpi=150)
    plt.close()

    result = {
        "metrics": metrics,
        "plot_path": str(plot_path)
    }
    print(json.dumps(result))

except Exception as e:
    import traceback
    error_result = {
        "metrics": None,
        "error": str(e),
        "traceback": traceback.format_exc(),
        "plot_path": None
    }
    print(json.dumps(error_result))
