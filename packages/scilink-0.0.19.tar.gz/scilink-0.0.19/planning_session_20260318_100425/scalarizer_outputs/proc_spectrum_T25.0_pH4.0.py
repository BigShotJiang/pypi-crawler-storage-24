import sys
import json
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from pathlib import Path

try:
    # Accept file path as command-line argument
    if len(sys.argv) > 1:
        data_path = sys.argv[1]
    else:
        data_path = "/Users/maxim.ziatdinov/Code/SciLink/planning_session_20260318_100425/data/spectrum_T25.0_pH4.0.csv"

    # Read data
    df = pd.read_csv(data_path)

    # Load sidecar metadata dynamically
    sidecar_path = Path(data_path).with_suffix('.json')
    sidecar_conditions = {}
    if sidecar_path.exists():
        with open(sidecar_path) as f:
            sidecar_conditions = json.load(f)

    # Extract wavelength and absorbance
    wavelength = df['wavelength_nm'].values
    absorbance = df['absorbance'].values

    # Remove NaN values if any
    valid_mask = ~(np.isnan(wavelength) | np.isnan(absorbance))
    wavelength = wavelength[valid_mask]
    absorbance = absorbance[valid_mask]

    # Sort by wavelength to ensure proper integration
    sort_idx = np.argsort(wavelength)
    wavelength = wavelength[sort_idx]
    absorbance = absorbance[sort_idx]

    # Calculate peak absorbance and peak wavelength
    peak_idx = np.argmax(absorbance)
    peak_absorbance = float(absorbance[peak_idx])
    peak_wavelength_nm = float(wavelength[peak_idx])

    # Calculate integrated absorbance area under the curve
    integrated_absorbance_area = float(np.trapezoid(absorbance, wavelength))

    # Build metrics: merge sidecar conditions with derived values
    metrics = {
        **sidecar_conditions,
        "Peak_Absorbance": peak_absorbance,
        "Peak_Wavelength_nm": peak_wavelength_nm,
        "Integrated_Absorbance_Area": integrated_absorbance_area
    }

    # Generate diagnostic plot
    output_dir = Path("/Users/maxim.ziatdinov/Code/SciLink/planning_session_20260318_100425/scalarizer_outputs")
    output_dir.mkdir(parents=True, exist_ok=True)
    plot_path = output_dir / f"debug_{Path(data_path).stem}.png"

    fig, ax = plt.subplots(1, 1, figsize=(10, 6))

    # Plot spectrum
    ax.plot(wavelength, absorbance, 'b-', linewidth=0.8, label='Absorbance')

    # Shade integrated area
    ax.fill_between(wavelength, 0, absorbance, alpha=0.2, color='blue',
                     label=f'Integrated Area = {integrated_absorbance_area:.4f}')

    # Mark peak
    ax.plot(peak_wavelength_nm, peak_absorbance, 'rv', markersize=12,
            label=f'Peak: {peak_absorbance:.4f} @ {peak_wavelength_nm:.1f} nm')
    ax.axvline(peak_wavelength_nm, color='red', linestyle='--', alpha=0.4)

    # Labels and title
    cond_str = ', '.join([f"{k}={v}" for k, v in sidecar_conditions.items()])
    ax.set_title(f'UV-Vis Spectrum ({cond_str})\n'
                 f'Peak={peak_absorbance:.4f} @ {peak_wavelength_nm:.1f} nm, '
                 f'Area={integrated_absorbance_area:.4f}',
                 fontsize=11)
    ax.set_xlabel('Wavelength (nm)')
    ax.set_ylabel('Absorbance')
    ax.legend(loc='best', fontsize=9)
    ax.set_xlim(wavelength.min(), wavelength.max())
    ax.set_ylim(bottom=0)
    plt.tight_layout()
    plt.savefig(str(plot_path), dpi=150)
    plt.close(fig)

    # Output result as JSON
    result = {
        "metrics": metrics,
        "plot_path": str(plot_path)
    }
    print(json.dumps(result))

except Exception as e:
    error_result = {
        "metrics": None,
        "plot_path": None,
        "error": str(e)
    }
    print(json.dumps(error_result))
