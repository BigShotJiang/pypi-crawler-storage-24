import sys
import json
import pandas as pd
import numpy as np
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

try:
    # Accept file path as command-line argument
    if len(sys.argv) > 1:
        data_path = sys.argv[1]
    else:
        data_path = "/Users/maxim.ziatdinov/Code/SciLink/planning_session_20260317_212727/data/iteration_1_96well_leaching_screen.csv"

    # Read data
    df = pd.read_csv(data_path)

    # Load sidecar if exists
    sidecar_path = Path(data_path).with_suffix('.json')
    sidecar_conditions = {}
    if sidecar_path.exists():
        with open(sidecar_path) as f:
            sidecar_conditions = json.load(f)

    # Filter to experimental wells only
    df_exp = df[df['Well_Type'] == 'Experimental'].copy()

    if df_exp.empty:
        print(json.dumps({"metrics": None, "plot_path": None}))
        sys.exit(0)

    # Parse SL_Ratio from string like '1:20' to numeric g/mL
    def parse_sl_ratio(sl_str):
        try:
            parts = str(sl_str).split(':')
            return float(parts[0]) / float(parts[1])
        except:
            return None

    df_exp['SL_Ratio_numeric'] = df_exp['SL_Ratio'].apply(parse_sl_ratio)

    # Compute composite economic value score per the GOAL
    # Score = (Nd_recovery_pct/100 * 120) + (Dy_recovery_pct/100 * 350) + (Pr_recovery_pct/100 * 95)
    df_exp['Composite_Economic_Score'] = (
        (df_exp['Nd_Recovery_pct'] / 100.0) * 120.0 +
        (df_exp['Dy_Recovery_pct'] / 100.0) * 350.0 +
        (df_exp['Pr_Recovery_pct'] / 100.0) * 95.0
    )

    # Build metrics list - each row is an independent experiment
    metrics_list = []
    for _, row in df_exp.iterrows():
        record = {
            **sidecar_conditions,
            "Acid_System": row['Acid_System'],
            "Concentration_M": float(row['Concentration_M']),
            "SL_Ratio": float(row['SL_Ratio_numeric']) if pd.notna(row['SL_Ratio_numeric']) else None,
            "Temperature_C": float(row['Temperature_C']),
            "Nd_Recovery_pct": float(row['Nd_Recovery_pct']) if pd.notna(row['Nd_Recovery_pct']) else None,
            "Dy_Recovery_pct": float(row['Dy_Recovery_pct']) if pd.notna(row['Dy_Recovery_pct']) else None,
            "Pr_Recovery_pct": float(row['Pr_Recovery_pct']) if pd.notna(row['Pr_Recovery_pct']) else None,
            "Fe_Recovery_pct": float(row['Fe_Recovery_pct']) if pd.notna(row['Fe_Recovery_pct']) else None,
            "Composite_Economic_Score": float(row['Composite_Economic_Score']) if pd.notna(row['Composite_Economic_Score']) else None
        }
        metrics_list.append(record)

    # --- Plotting ---
    plot_path = Path("/Users/maxim.ziatdinov/Code/SciLink/planning_session_20260317_212727/scalarizer_outputs") / f"debug_{Path(data_path).stem}.png"
    plot_path.parent.mkdir(parents=True, exist_ok=True)

    fig, axes = plt.subplots(1, 2, figsize=(16, 6))

    # Subplot 1: REE recoveries and Fe by condition index, colored by acid type
    ax1 = axes[0]
    acid_colors = {'HCl': 'tab:blue', 'H2SO4': 'tab:orange', 'HNO3': 'tab:green'}
    for acid in df_exp['Acid_System'].unique():
        mask = df_exp['Acid_System'] == acid
        subset = df_exp[mask]
        ax1.scatter(subset.index, subset['Nd_Recovery_pct'], label=f'Nd ({acid})',
                    color=acid_colors.get(acid, 'gray'), marker='o', alpha=0.7, s=30)
        ax1.scatter(subset.index, subset['Dy_Recovery_pct'],
                    color=acid_colors.get(acid, 'gray'), marker='s', alpha=0.5, s=25)
        ax1.scatter(subset.index, subset['Fe_Recovery_pct'],
                    color=acid_colors.get(acid, 'gray'), marker='x', alpha=0.5, s=25)

    ax1.axhline(y=90, color='red', linestyle='--', linewidth=1, label='Nd target (90%)')
    ax1.axhline(y=20, color='darkred', linestyle=':', linewidth=1, label='Fe limit (20%)')
    ax1.set_xlabel('Well Index')
    ax1.set_ylabel('Recovery (%)')
    ax1.set_title('REE & Fe Recovery by Well\n(o=Nd, s=Dy, x=Fe)')
    ax1.legend(fontsize=7, loc='upper left')
    ax1.set_ylim(-5, 105)

    # Subplot 2: Composite Economic Score distribution by acid type and temperature
    ax2 = axes[1]
    for acid in sorted(df_exp['Acid_System'].unique()):
        for temp in sorted(df_exp['Temperature_C'].unique()):
            mask = (df_exp['Acid_System'] == acid) & (df_exp['Temperature_C'] == temp)
            subset = df_exp[mask]
            label = f"{acid}, {int(temp)}°C"
            ax2.scatter(subset['Concentration_M'] + np.random.uniform(-0.03, 0.03, size=len(subset)),
                        subset['Composite_Economic_Score'],
                        label=label, alpha=0.7, s=40)

    best_idx = df_exp['Composite_Economic_Score'].idxmax()
    best_row = df_exp.loc[best_idx]
    ax2.annotate(f"Best: {best_row['Composite_Economic_Score']:.1f}\n({best_row['Acid_System']}, {best_row['Concentration_M']}M, {int(best_row['Temperature_C'])}°C)",
                 xy=(best_row['Concentration_M'], best_row['Composite_Economic_Score']),
                 xytext=(best_row['Concentration_M'] - 0.8, best_row['Composite_Economic_Score'] - 40),
                 arrowprops=dict(arrowstyle='->', color='red'),
                 fontsize=8, color='red', fontweight='bold')

    ax2.set_xlabel('Acid Concentration (M)')
    ax2.set_ylabel('Composite Economic Score')
    ax2.set_title(f'Composite Economic Score vs Concentration\nBest={best_row["Composite_Economic_Score"]:.1f}')
    ax2.legend(fontsize=6, loc='upper left', ncol=2)

    plt.tight_layout()
    plt.savefig(str(plot_path), dpi=150)
    plt.close()

    # Output results
    result = {
        "metrics": metrics_list,
        "plot_path": str(plot_path)
    }
    print(json.dumps(result))

except Exception as e:
    import traceback
    error_result = {
        "metrics": None,
        "plot_path": None,
        "error": str(e),
        "traceback": traceback.format_exc()
    }
    print(json.dumps(error_result))
