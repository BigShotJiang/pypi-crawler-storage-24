from opentrons import protocol_api

metadata = {
    'protocolName': 'REE Leaching Screen - Iteration 2 (Direct + Roasted)',
    'author': 'Opentrons AI',
    'description': '''High-throughput acid leaching screen for rare earth element recovery 
                      from NdFeB magnet waste. Iteration 2 includes both direct (unroasted) 
                      and oxidatively roasted powder feedstocks with kinetic sampling.''',
    'source': 'OpentronsAI'
}

requirements = {
    'robotType': 'OT-2',
    'apiLevel': '2.19'
}

def run(protocol: protocol_api.ProtocolContext):
    
    # ===================== LABWARE SETUP =====================
    
    # Deep well plates for leaching (Plates C and D)
    plate_c = protocol.load_labware('nest_96_wellplate_2ml_deep', '1', 'Plate C - 60 min leach')
    plate_d = protocol.load_labware('nest_96_wellplate_2ml_deep', '2', 'Plate D - 240 min leach')
    
    # Reservoir with acid stock solutions
    reservoir = protocol.load_labware('nest_12_reservoir_15ml', '3', 'Acid Stock Solutions')
    
    # Tip racks
    tips_1000_1 = protocol.load_labware('opentrons_96_tiprack_1000ul', '4')
    tips_1000_2 = protocol.load_labware('opentrons_96_tiprack_1000ul', '5')
    tips_1000_3 = protocol.load_labware('opentrons_96_tiprack_1000ul', '7')
    tips_1000_4 = protocol.load_labware('opentrons_96_tiprack_1000ul', '8')
    tips_300_1 = protocol.load_labware('opentrons_96_tiprack_300ul', '10')
    tips_300_2 = protocol.load_labware('opentrons_96_tiprack_300ul', '11')
    
    # PLS collection plates — these slots are reused across Parts 2 and 3.
    # The user will physically swap plates at each pause.
    pls_slot6 = protocol.load_labware('nest_96_wellplate_2ml_deep', '6', 'Collection / Dilution Plate (slot 6)')
    pls_slot9 = protocol.load_labware('nest_96_wellplate_2ml_deep', '9', 'Collection / Dilution Plate (slot 9)')
    
    # ===================== PIPETTE SETUP =====================
    
    p1000 = protocol.load_instrument(
        'p1000_single_gen2',
        'left',
        tip_racks=[tips_1000_1, tips_1000_2, tips_1000_3, tips_1000_4]
    )
    
    p300_multi = protocol.load_instrument(
        'p300_multi_gen2',
        'right',
        tip_racks=[tips_300_1, tips_300_2]
    )
    
    # ===================== ACID MAPPING =====================
    
    # Map reservoir wells to acid types
    acids = {
        'HCl_3.0M': reservoir['A1'],
        'HCl_4.0M': reservoir['A2'],
        'HCl_5.0M': reservoir['A3'],
        'HCl_6.0M': reservoir['A4'],
        'HNO3_2.0M': reservoir['A5'],
        'HNO3_3.0M': reservoir['A6'],
        'HNO3_4.0M': reservoir['A7'],
        'HNO3_H2O2': reservoir['A8'],   # 1.0M HNO3 + 0.3M H2O2
        'HCl_0.2M': reservoir['A9'],
        'HCl_0.5M': reservoir['A10'],
        'HCl_1.0M': reservoir['A11'],
        'HCl_2.0M': reservoir['A12']
    }
    
    # ===================== WELL-TO-ACID MAP =====================
    
    well_acid_map = {}
    
    # Block 1: Intensified HCl direct leach (Rows A-D, Columns 1-4)
    block1_acids = {'A': 'HCl_3.0M', 'B': 'HCl_4.0M', 'C': 'HCl_5.0M', 'D': 'HCl_6.0M'}
    for row, acid_key in block1_acids.items():
        for col in ['1', '2', '3', '4']:
            well_acid_map[f'{row}{col}'] = acid_key
    
    # Block 2: Intensified HNO3 direct leach (Rows E-G, Columns 1-4)
    block2_acids = {'E': 'HNO3_2.0M', 'F': 'HNO3_3.0M', 'G': 'HNO3_4.0M'}
    for row, acid_key in block2_acids.items():
        for col in ['1', '2', '3', '4']:
            well_acid_map[f'{row}{col}'] = acid_key
    
    # Block 3: Oxidant-assisted HNO3 (Row H, Columns 1-4)
    for col in ['1', '2', '3', '4']:
        well_acid_map[f'H{col}'] = 'HNO3_H2O2'
    
    # Block 4: Roasted powder selective leach (Rows A-D, Columns 5-8)
    block4_acids = {'A': 'HCl_0.2M', 'B': 'HCl_0.5M', 'C': 'HNO3_2.0M', 'D': 'HNO3_H2O2'}
    for row, acid_key in block4_acids.items():
        for col in ['5', '6', '7', '8']:
            well_acid_map[f'{row}{col}'] = acid_key
    
    # Block 5: Roasted powder higher conc (Rows E-F, Columns 5-8)
    for col in ['5', '6', '7', '8']:
        well_acid_map[f'E{col}'] = 'HCl_1.0M'
        well_acid_map[f'F{col}'] = 'HCl_2.0M'
    
    # Block 6: Controls (Row G, Columns 5-8) — acid-only blanks
    well_acid_map['G5'] = 'HCl_4.0M'
    well_acid_map['G6'] = 'HCl_4.0M'
    well_acid_map['G7'] = 'HNO3_H2O2'
    well_acid_map['G8'] = 'HNO3_H2O2'
    # H5-H8: DI water controls — SKIP (user adds manually)
    
    # Kinetic replicates — Columns 9-10 (S:L 1:50)
    kinetic_910 = {
        'A': 'HCl_4.0M', 'B': 'HCl_6.0M', 'C': 'HNO3_3.0M',
        'D': 'HNO3_H2O2', 'E': 'HCl_0.5M', 'F': 'HCl_2.0M'
    }
    for row, acid_key in kinetic_910.items():
        for col in ['9', '10']:
            well_acid_map[f'{row}{col}'] = acid_key
    
    # Kinetic replicates — Columns 11-12 (S:L 1:100)
    kinetic_1112 = {
        'A': 'HCl_4.0M', 'B': 'HCl_6.0M', 'C': 'HNO3_3.0M',
        'D': 'HNO3_H2O2', 'E': 'HCl_0.5M', 'F': 'HCl_2.0M'
    }
    for row, acid_key in kinetic_1112.items():
        for col in ['11', '12']:
            well_acid_map[f'{row}{col}'] = acid_key
    
    # Rows G-H columns 9-12: empty/spare — not mapped
    
    # ===================== PART 1: ACID DISPENSING =====================
    
    protocol.comment('=== PART 1: ACID DISPENSING ===')
    protocol.comment('Dispensing 1000 uL of acid to both Plate C and Plate D')
    
    p1000.flow_rate.aspirate = 150   # uL/s
    p1000.flow_rate.dispense = 100   # uL/s
    
    # Group wells by acid type and dispense with one tip per acid
    for acid_key in sorted(set(well_acid_map.values())):
        wells_for_acid = sorted(
            [w for w, a in well_acid_map.items() if a == acid_key],
            key=lambda w: (w[0], int(w[1:]))
        )
        
        protocol.comment(f'Dispensing {acid_key} to {len(wells_for_acid)} wells per plate')
        p1000.pick_up_tip()
        
        for well_name in wells_for_acid:
            # Plate C
            p1000.aspirate(1000, acids[acid_key])
            p1000.dispense(1000, plate_c[well_name])
            # Plate D
            p1000.aspirate(1000, acids[acid_key])
            p1000.dispense(1000, plate_d[well_name])
        
        p1000.drop_tip()
    
    protocol.comment('Part 1 Complete: Acid dispensing finished')
    
    protocol.pause(
        'PART 1 COMPLETE - MANUAL STEPS REQUIRED:\n\n'
        '1. Remove Plate C (slot 1) and Plate D (slot 2) from the robot.\n'
        '2. Using an analytical balance, add solid powder to each well:\n'
        '   -- Columns 1-2, 5-6, 9-10: 20 mg powder (S:L 1:50)\n'
        '   -- Columns 3-4, 7-8, 11-12: 10 mg powder (S:L 1:100)\n'
        '   -- Columns 1-4 and 9-12 rows A-H: use DIRECT (unroasted) powder\n'
        '   -- Columns 5-8 rows A-F: use ROASTED powder\n'
        '   -- Row G columns 5-8: NO solid (acid-only blanks)\n'
        '   -- Row H columns 5-8: add DI water manually (water controls)\n'
        '   -- Rows G-H columns 9-12: leave empty (spare wells)\n'
        '3. Seal plates with polypropylene heat-seal film.\n'
        '4. Place on heated orbital shaker at 90 C / 500 rpm.\n'
        '5. START TIMER. After exactly 30 minutes, return BOTH plates\n'
        '   to the OT-2 for kinetic sampling.\n'
        '6. Place an EMPTY 96-well collection plate on slot 6 (kinetic Plate C)\n'
        '   and an EMPTY 96-well collection plate on slot 9 (kinetic Plate D).\n\n'
        'Press RESUME when plates are on the robot and ready for 30-min sampling.'
    )
    
    # ===================== PART 2: 30-MINUTE KINETIC SAMPLING =====================
    
    protocol.comment('=== PART 2: 30-MINUTE KINETIC SAMPLING ===')
    
    p1000.flow_rate.aspirate = 50    # uL/s — slow to avoid pellet
    p1000.flow_rate.dispense = 100   # uL/s
    
    # Kinetic wells: columns 9-12, rows A-F
    kinetic_wells = []
    for row in ['A', 'B', 'C', 'D', 'E', 'F']:
        for col in ['9', '10', '11', '12']:
            kinetic_wells.append(f'{row}{col}')
    
    # Sample from Plate C
    protocol.comment('Sampling kinetic wells from Plate C')
    for well_name in kinetic_wells:
        p1000.pick_up_tip()
        # Aspirate 500 uL supernatant from 3mm above bottom
        p1000.aspirate(500, plate_c[well_name].bottom(z=3))
        # Dispense to collection plate on slot 6
        p1000.dispense(500, pls_slot6[well_name])
        # Replenish with 500 uL matching fresh acid
        acid_key = well_acid_map[well_name]
        p1000.aspirate(500, acids[acid_key])
        p1000.dispense(500, plate_c[well_name])
        p1000.drop_tip()
    
    # Sample from Plate D
    protocol.comment('Sampling kinetic wells from Plate D')
    for well_name in kinetic_wells:
        p1000.pick_up_tip()
        p1000.aspirate(500, plate_d[well_name].bottom(z=3))
        p1000.dispense(500, pls_slot9[well_name])
        acid_key = well_acid_map[well_name]
        p1000.aspirate(500, acids[acid_key])
        p1000.dispense(500, plate_d[well_name])
        p1000.drop_tip()
    
    protocol.comment('Part 2 Complete: 30-min kinetic sampling finished')
    
    protocol.pause(
        'PART 2 COMPLETE - MANUAL STEPS REQUIRED:\n\n'
        '1. Remove the 30-min kinetic collection plates from slots 6 and 9.\n'
        '   Label them: "Plate C - 30min kinetic" and "Plate D - 30min kinetic"\n'
        '2. Return Plate C and Plate D to the heated shaker at 90 C / 500 rpm.\n'
        '3. Continue incubation:\n'
        '   -- Plate C: 30 more minutes (total 60 min), then centrifuge.\n'
        '   -- Plate D: 210 more minutes (total 240 min), then centrifuge.\n'
        '4. After centrifugation (3000 x g, 10 min):\n'
        '   -- Place centrifuged Plate C on slot 1\n'
        '   -- Place centrifuged Plate D on slot 2\n'
        '   -- Place EMPTY PLS collection plates on slots 6 and 9\n\n'
        'Press RESUME when ready for supernatant transfer.'
    )
    
    # ===================== PART 3: SUPERNATANT TRANSFER & DILUTION =====================
    
    protocol.comment('=== PART 3: SUPERNATANT TRANSFER ===')
    
    p1000.flow_rate.aspirate = 50    # uL/s — slow
    p1000.flow_rate.dispense = 100   # uL/s
    
    # All wells except H5-H8 (DI water controls) and G9-H12 (spare)
    transfer_wells = []
    for row in ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H']:
        for col in range(1, 13):
            well_name = f'{row}{col}'
            # Skip DI water controls
            if well_name in ['H5', 'H6', 'H7', 'H8']:
                continue
            # Skip spare wells
            if row in ['G', 'H'] and col >= 9:
                continue
            transfer_wells.append(well_name)
    
    # Transfer from Plate C to PLS collection plate (slot 6)
    protocol.comment('Transferring 700 uL supernatant from Plate C to PLS plate (slot 6)')
    for well_name in transfer_wells:
        p1000.pick_up_tip()
        p1000.aspirate(700, plate_c[well_name].bottom(z=3))
        p1000.dispense(700, pls_slot6[well_name])
        p1000.drop_tip()
    
    # Transfer from Plate D to PLS collection plate (slot 9)
    protocol.comment('Transferring 700 uL supernatant from Plate D to PLS plate (slot 9)')
    for well_name in transfer_wells:
        p1000.pick_up_tip()
        p1000.aspirate(700, plate_d[well_name].bottom(z=3))
        p1000.dispense(700, pls_slot9[well_name])
        p1000.drop_tip()
    
    protocol.comment('Supernatant transfer complete')
    
    protocol.pause(
        'SUPERNATANT TRANSFER COMPLETE - MANUAL STEPS REQUIRED:\n\n'
        '1. Remove PLS collection plates from slots 6 and 9.\n'
        '   Label them: "Plate C - PLS" and "Plate D - PLS"\n'
        '2. Prepare TWO dilution plates:\n'
        '   -- Add 1980 uL of 2 percent HNO3 to each well.\n'
        '3. Place Plate C-PLS BACK on slot 1 (source for dilution).\n'
        '4. Place a DILUTION plate on slot 6 (destination).\n\n'
        'Press RESUME when ready for ICP-MS dilution.'
    )
    
    # --- ICP-MS Dilution: Plate C ---
    protocol.comment('Performing 100x dilution: Plate C-PLS (slot 1) -> Dilution plate (slot 6)')
    # Note: after user swap, plate_c (slot 1) now holds the Plate C-PLS,
    # and pls_slot6 (slot 6) now holds the dilution plate.
    
    for col_idx in range(12):
        p300_multi.pick_up_tip()
        p300_multi.aspirate(20, plate_c.columns()[col_idx][0])
        p300_multi.dispense(20, pls_slot6.columns()[col_idx][0])
        p300_multi.mix(3, 200, pls_slot6.columns()[col_idx][0])
        p300_multi.drop_tip()
    
    protocol.pause(
        'PLATE C DILUTION COMPLETE.\n\n'
        '1. Remove the Plate C dilution plate from slot 6. Label it.\n'
        '2. Place Plate D-PLS on slot 1 (source for dilution).\n'
        '3. Place a FRESH dilution plate (with 1980 uL 2 percent HNO3) on slot 6.\n\n'
        'Press RESUME for Plate D dilution.'
    )
    
    # --- ICP-MS Dilution: Plate D ---
    protocol.comment('Performing 100x dilution: Plate D-PLS (slot 1) -> Dilution plate (slot 6)')
    
    for col_idx in range(12):
        p300_multi.pick_up_tip()
        p300_multi.aspirate(20, plate_c.columns()[col_idx][0])   # slot 1 now has Plate D-PLS
        p300_multi.dispense(20, pls_slot6.columns()[col_idx][0])  # slot 6 has fresh dilution plate
        p300_multi.mix(3, 200, pls_slot6.columns()[col_idx][0])
        p300_multi.drop_tip()
    
    protocol.comment('=== PROTOCOL COMPLETE ===')
    protocol.comment(
        'All steps finished. Samples ready for ICP-MS:\n'
        '- 30-min kinetic samples (collected during Part 2)\n'
        '- Plate C dilution plate (60-min leach, 100x diluted)\n'
        '- Plate D dilution plate (240-min leach, 100x diluted)\n'
        'Remove all plates and proceed with ICP-MS analysis.'
    )
