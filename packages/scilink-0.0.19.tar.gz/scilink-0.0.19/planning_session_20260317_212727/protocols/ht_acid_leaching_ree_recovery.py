from opentrons import protocol_api

metadata = {
    'protocolName': 'High-Throughput Acid Leaching Screen for REE Recovery',
    'author': 'OpentronsAI',
    'description': 'Automated acid dispensing and supernatant transfer for rare earth element recovery from NdFeB magnet waste',
    'source': 'OpentronsAI'
}

requirements = {
    'robotType': 'OT-2',
    'apiLevel': '2.19'
}

def run(protocol: protocol_api.ProtocolContext):
    
    # ===================== LABWARE SETUP =====================
    
    # Reaction plates (will receive acid and solid powder)
    plate_a = protocol.load_labware('nest_96_wellplate_2ml_deep', '1', 'Reaction Plate A (25°C)')
    plate_b = protocol.load_labware('nest_96_wellplate_2ml_deep', '2', 'Reaction Plate B (70°C)')
    
    # Reservoir with acid stock solutions
    reservoir = protocol.load_labware('nest_12_reservoir_15ml', '3', 'Acid Stock Solutions')
    
    # Tip racks for P1000
    tiprack_1000_1 = protocol.load_labware('opentrons_96_tiprack_1000ul', '4')
    tiprack_1000_2 = protocol.load_labware('opentrons_96_tiprack_1000ul', '5')
    tiprack_1000_3 = protocol.load_labware('opentrons_96_tiprack_1000ul', '7')
    tiprack_1000_4 = protocol.load_labware('opentrons_96_tiprack_1000ul', '8')
    
    # Tip racks for P300
    tiprack_300_1 = protocol.load_labware('opentrons_96_tiprack_300ul', '10')
    tiprack_300_2 = protocol.load_labware('opentrons_96_tiprack_300ul', '11')
    
    # PLS collection plates (loaded in slot 6 initially, slot 9 will be used later)
    plate_a_pls = protocol.load_labware('nest_96_wellplate_2ml_deep', '6', 'Plate A-PLS Collection')
    plate_b_pls = protocol.load_labware('nest_96_wellplate_2ml_deep', '9', 'Plate B-PLS Collection')
    
    # ===================== PIPETTE SETUP =====================
    
    p1000 = protocol.load_instrument(
        'p1000_single_gen2',
        'left',
        tip_racks=[tiprack_1000_1, tiprack_1000_2, tiprack_1000_3, tiprack_1000_4]
    )
    
    p300_multi = protocol.load_instrument(
        'p300_multi_gen2',
        'right',
        tip_racks=[tiprack_300_1, tiprack_300_2]
    )
    
    # ===================== HELPER FUNCTIONS =====================
    
    def dispense_acid_to_plate(plate, acid_well, target_wells, acid_name):
        """
        Dispense acid from reservoir to specified wells in a plate.
        Uses fresh tip for each acid type to prevent cross-contamination.
        """
        protocol.comment(f'Dispensing {acid_name} to {len(target_wells)} wells')
        
        p1000.pick_up_tip()
        p1000.flow_rate.aspirate = 150  # µL/s
        p1000.flow_rate.dispense = 100  # µL/s
        
        for well in target_wells:
            p1000.aspirate(1000, reservoir[acid_well])
            p1000.dispense(1000, plate[well])
        
        p1000.drop_tip()
    
    def get_wells_for_condition(acid_columns, concentration_row, sl_ratio_rows):
        """
        Generate list of well names for a specific acid/concentration/S:L ratio condition.
        """
        wells = []
        for col in acid_columns:
            for row in sl_ratio_rows:
                wells.append(f'{row}{col}')
        return wells
    
    # ===================== PART 1: ACID DISPENSING =====================
    
    def part1_acid_dispensing():
        protocol.comment('=' * 60)
        protocol.comment('PART 1: ACID DISPENSING INTO REACTION PLATES')
        protocol.comment('=' * 60)
        
        # Define plate layout mapping
        # Columns 1-2: HCl conditions (replicates)
        # Columns 3-4: H2SO4 conditions (replicates)
        # Columns 5-6: HNO3 conditions (replicates)
        # Columns 7-8: Blanks (acid only, matching cols 1-2 pattern)
        # Columns 9-10: Water controls (skip - manual DI water)
        # Columns 11-12: Kinetic timepoints
        
        # Process both plates with same layout
        for plate in [plate_a, plate_b]:
            protocol.comment(f'Processing {plate.load_name}')
            
            # ===== HCl CONDITIONS (Columns 1-2 and Blanks 7-8) =====
            
            # S:L = 1:20 (Rows A-D)
            # Row A: HCl 0.5M
            wells = get_wells_for_condition(['1', '2', '7', '8'], 'A', ['A'])
            dispense_acid_to_plate(plate, 'A1', wells, 'HCl 0.5M (S:L 1:20)')
            
            # Row B: HCl 1.0M
            wells = get_wells_for_condition(['1', '2', '7', '8'], 'B', ['B'])
            dispense_acid_to_plate(plate, 'A2', wells, 'HCl 1.0M (S:L 1:20)')
            
            # Row C: HCl 2.0M
            wells = get_wells_for_condition(['1', '2', '7', '8'], 'C', ['C'])
            dispense_acid_to_plate(plate, 'A3', wells, 'HCl 2.0M (S:L 1:20)')
            
            # Row D: HCl 3.0M
            wells = get_wells_for_condition(['1', '2', '7', '8'], 'D', ['D'])
            dispense_acid_to_plate(plate, 'A4', wells, 'HCl 3.0M (S:L 1:20)')
            
            # S:L = 1:50 (Rows E-H)
            # Row E: HCl 0.5M
            wells = get_wells_for_condition(['1', '2', '7', '8'], 'E', ['E'])
            dispense_acid_to_plate(plate, 'A1', wells, 'HCl 0.5M (S:L 1:50)')
            
            # Row F: HCl 1.0M
            wells = get_wells_for_condition(['1', '2', '7', '8'], 'F', ['F'])
            dispense_acid_to_plate(plate, 'A2', wells, 'HCl 1.0M (S:L 1:50)')
            
            # Row G: HCl 2.0M
            wells = get_wells_for_condition(['1', '2', '7', '8'], 'G', ['G'])
            dispense_acid_to_plate(plate, 'A3', wells, 'HCl 2.0M (S:L 1:50)')
            
            # Row H: HCl 3.0M
            wells = get_wells_for_condition(['1', '2', '7', '8'], 'H', ['H'])
            dispense_acid_to_plate(plate, 'A4', wells, 'HCl 3.0M (S:L 1:50)')
            
            # ===== H2SO4 CONDITIONS (Columns 3-4) =====
            
            # S:L = 1:20 (Rows A-D)
            wells = get_wells_for_condition(['3', '4'], 'A', ['A'])
            dispense_acid_to_plate(plate, 'A5', wells, 'H2SO4 0.5M (S:L 1:20)')
            
            wells = get_wells_for_condition(['3', '4'], 'B', ['B'])
            dispense_acid_to_plate(plate, 'A6', wells, 'H2SO4 1.0M (S:L 1:20)')
            
            wells = get_wells_for_condition(['3', '4'], 'C', ['C'])
            dispense_acid_to_plate(plate, 'A7', wells, 'H2SO4 2.0M (S:L 1:20)')
            
            wells = get_wells_for_condition(['3', '4'], 'D', ['D'])
            dispense_acid_to_plate(plate, 'A8', wells, 'H2SO4 3.0M (S:L 1:20)')
            
            # S:L = 1:50 (Rows E-H)
            wells = get_wells_for_condition(['3', '4'], 'E', ['E'])
            dispense_acid_to_plate(plate, 'A5', wells, 'H2SO4 0.5M (S:L 1:50)')
            
            wells = get_wells_for_condition(['3', '4'], 'F', ['F'])
            dispense_acid_to_plate(plate, 'A6', wells, 'H2SO4 1.0M (S:L 1:50)')
            
            wells = get_wells_for_condition(['3', '4'], 'G', ['G'])
            dispense_acid_to_plate(plate, 'A7', wells, 'H2SO4 2.0M (S:L 1:50)')
            
            wells = get_wells_for_condition(['3', '4'], 'H', ['H'])
            dispense_acid_to_plate(plate, 'A8', wells, 'H2SO4 3.0M (S:L 1:50)')
            
            # ===== HNO3 CONDITIONS (Columns 5-6) =====
            
            # S:L = 1:20 (Rows A-D)
            wells = get_wells_for_condition(['5', '6'], 'A', ['A'])
            dispense_acid_to_plate(plate, 'A9', wells, 'HNO3 0.5M (S:L 1:20)')
            
            wells = get_wells_for_condition(['5', '6'], 'B', ['B'])
            dispense_acid_to_plate(plate, 'A10', wells, 'HNO3 1.0M (S:L 1:20)')
            
            wells = get_wells_for_condition(['5', '6'], 'C', ['C'])
            dispense_acid_to_plate(plate, 'A11', wells, 'HNO3 2.0M (S:L 1:20)')
            
            wells = get_wells_for_condition(['5', '6'], 'D', ['D'])
            dispense_acid_to_plate(plate, 'A12', wells, 'HNO3 3.0M (S:L 1:20)')
            
            # S:L = 1:50 (Rows E-H)
            wells = get_wells_for_condition(['5', '6'], 'E', ['E'])
            dispense_acid_to_plate(plate, 'A9', wells, 'HNO3 0.5M (S:L 1:50)')
            
            wells = get_wells_for_condition(['5', '6'], 'F', ['F'])
            dispense_acid_to_plate(plate, 'A10', wells, 'HNO3 1.0M (S:L 1:50)')
            
            wells = get_wells_for_condition(['5', '6'], 'G', ['G'])
            dispense_acid_to_plate(plate, 'A11', wells, 'HNO3 2.0M (S:L 1:50)')
            
            wells = get_wells_for_condition(['5', '6'], 'H', ['H'])
            dispense_acid_to_plate(plate, 'A12', wells, 'HNO3 3.0M (S:L 1:50)')
            
            # ===== KINETIC TIMEPOINTS (Columns 11-12) =====
            
            # Rows A-B: HCl 1.0M (S:L 1:20)
            wells = get_wells_for_condition(['11', '12'], 'A-B', ['A', 'B'])
            dispense_acid_to_plate(plate, 'A2', wells, 'HCl 1.0M - Kinetic (S:L 1:20)')
            
            # Rows C-D: H2SO4 2.0M (S:L 1:20)
            wells = get_wells_for_condition(['11', '12'], 'C-D', ['C', 'D'])
            dispense_acid_to_plate(plate, 'A7', wells, 'H2SO4 2.0M - Kinetic (S:L 1:20)')
            
            # Rows E-F: HNO3 1.0M (S:L 1:50)
            wells = get_wells_for_condition(['11', '12'], 'E-F', ['E', 'F'])
            dispense_acid_to_plate(plate, 'A10', wells, 'HNO3 1.0M - Kinetic (S:L 1:50)')
            
            # Rows G-H: HCl 1.0M (S:L 1:50)
            wells = get_wells_for_condition(['11', '12'], 'G-H', ['G', 'H'])
            dispense_acid_to_plate(plate, 'A2', wells, 'HCl 1.0M - Kinetic (S:L 1:50)')
        
        protocol.comment('Part 1 Complete: Acid dispensing finished')
    
    # ===================== PART 2: SUPERNATANT TRANSFER & DILUTION =====================
    
    def part2_supernatant_and_dilution():
        protocol.comment('=' * 60)
        protocol.comment('PART 2: SUPERNATANT TRANSFER AND ICP-MS DILUTION')
        protocol.comment('=' * 60)
        
        # Set slow aspiration for supernatant transfer to avoid pellet disturbance
        p1000.flow_rate.aspirate = 50  # µL/s
        p1000.flow_rate.dispense = 100  # µL/s
        
        # Transfer supernatant from Plate A to Plate A-PLS
        protocol.comment('Transferring supernatant from Plate A to Plate A-PLS')
        for well in plate_a.wells():
            well_name = well.well_name
            p1000.pick_up_tip()
            # Aspirate from 3mm above well bottom to avoid pellet
            p1000.aspirate(700, plate_a[well_name].bottom(z=3))
            p1000.dispense(700, plate_a_pls[well_name])
            p1000.drop_tip()
        
        # Transfer supernatant from Plate B to Plate B-PLS
        protocol.comment('Transferring supernatant from Plate B to Plate B-PLS')
        for well in plate_b.wells():
            well_name = well.well_name
            p1000.pick_up_tip()
            # Aspirate from 3mm above well bottom to avoid pellet
            p1000.aspirate(700, plate_b[well_name].bottom(z=3))
            p1000.dispense(700, plate_b_pls[well_name])
            p1000.drop_tip()
        
        protocol.comment('Supernatant transfer complete')
        
        # Pause for user to swap plates for dilution
        protocol.pause(
            'MANUAL STEP REQUIRED:\n'
            '1. Remove Reaction Plate A from slot 1\n'
            '2. Prepare dilution plate with 1980 µL of 2% HNO3 per well\n'
            '3. Place dilution plate in slot 1\n'
            '4. Resume protocol when ready'
        )
        
        # Perform 100x dilution for ICP-MS using 8-channel pipette
        protocol.comment('Performing 100x dilution for ICP-MS analysis')
        protocol.comment('Transferring 20 µL from Plate A-PLS to dilution plate')
        
        # Note: dilution_plate is now in slot 1 (user swapped it)
        # We'll reference it as plate_a since that's the slot location
        dilution_plate = plate_a  # This is now the dilution plate after user swap
        
        # Transfer 20 µL from each column of Plate A-PLS to dilution plate
        # Using 8-channel pipette for efficiency
        for col_idx in range(12):
            p300_multi.pick_up_tip()
            # Transfer from column in PLS plate to same column in dilution plate
            p300_multi.transfer(
                20,
                plate_a_pls.columns()[col_idx][0],  # Access first well of column (A row)
                dilution_plate.columns()[col_idx][0],
                mix_after=(3, 200),
                new_tip='never'
            )
            p300_multi.drop_tip()
        
        protocol.comment('Part 2 Complete: Supernatant transfer and dilution finished')
    
    # ===================== PROTOCOL EXECUTION =====================
    
    # Execute Part 1
    part1_acid_dispensing()
    
    # Pause with detailed instructions for manual steps
    protocol.pause(
        'PART 1 COMPLETE - MANUAL STEPS REQUIRED:\n\n'
        '1. Remove both reaction plates (slots 1 and 2)\n'
        '2. Seal plates with adhesive film\n'
        '3. Add appropriate amounts of NdFeB magnet powder to each well:\n'
        '   - Rows A-D (S:L 1:20): Add 50 mg powder per well\n'
        '   - Rows E-H (S:L 1:50): Add 20 mg powder per well\n'
        '   - Columns 7-8 (Blanks): Do NOT add powder\n'
        '   - Columns 9-10: Add DI water instead of acid (manual)\n'
        '4. Vortex or shake plates to mix\n'
        '5. Incubate Plate A at 25°C for specified time\n'
        '6. Incubate Plate B at 70°C for specified time\n'
        '7. Centrifuge both plates (e.g., 4000 rpm, 10 min)\n'
        '8. Return centrifuged Plate A to slot 1\n'
        '9. Return centrifuged Plate B to slot 2\n'
        '10. Ensure empty PLS collection plates are in slots 6 and 9\n\n'
        'Resume protocol when ready for Part 2'
    )
    
    # Execute Part 2
    part2_supernatant_and_dilution()
    
    protocol.comment('=' * 60)
    protocol.comment('PROTOCOL COMPLETE')
    protocol.comment('=' * 60)
    protocol.comment(
        'Final steps:\n'
        '- Diluted samples in slot 1 are ready for ICP-MS analysis\n'
        '- PLS samples in slots 6 and 9 can be stored for further analysis'
    )
