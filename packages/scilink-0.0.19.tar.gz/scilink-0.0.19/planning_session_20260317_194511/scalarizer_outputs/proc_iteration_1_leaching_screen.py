import sys
import json
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from pathlib import Path

# Accept file path as command-line argument
if len(sys.argv) > 1:
    data_path = sys.argv[1]
else:
    data_path = "/Users/maxim.ziatdinov/Code/SciLink/planning_session_20260317_194511/data/iteration_1_leaching_screen.csv"

try:
    # Read data
    df = pd.read_csv(data_path)

    # If a sidecar JSON exists, load conditions DYNAMICALLY from it
    sidecar_path = Path(data_path).with_suffix('.json')
    sidecar_conditions = {}
    if sidecar_path.exists():
        with open(sidecar_path) as f:
            sidecar_conditions = json.load(f)

    # Define required columns
    input_cols = ['Acid_System', 'Concentration_M', 'SL_Ratio', 'Temperature_C', 'Feedstock']
    target_cols = ['Nd_Recovery_pct', 'Dy_Recovery_pct', 'Pr_Recovery_pct', 'Fe_Recovery_pct', 'Dy_Fe_Selectivity', 'Composite_Score']
    all_cols = input_cols + target_cols

    # Verify all required columns exist
    missing = [c for c in all_cols if c not in df.columns]
    if missing:
        raise ValueError(f"Missing columns: {missing}")

    # Extract relevant columns, drop rows with NaN in any required column
    df_out = df[all_cols].dropna().copy()

    # Convert to list of dicts for multi-row output
    metrics_list = df_out.to_dict(orient='records')

    # Merge sidecar conditions into each row if any exist
    if sidecar_conditions:
        for row in metrics_list:
            for k, v in sidecar_conditions.items():
                if k not in row:
                    row[k] = v

    # --- Plotting ---
    plot_path = Path("/Users/maxim.ziatdinov/Code/SciLink/planning_session_20260317_194511/scalarizer_outputs") / f"debug_{Path(data_path).stem}.png"
    plot_path.parent.mkdir(parents=True, exist_ok=True)

    fig, axes = plt.subplots(2, 1, figsize=(14, 10))

    # Create a label for each condition
    labels = df_out.apply(lambda r: f"{r['Acid_System']}|{r['Concentration_M']}M|{r['SL_Ratio']}|{r['Temperature_C']}C|{r['Feedstock'][:3]}", axis=1).values
    x = np.arange(len(labels))

    # Sort by Composite_Score descending for better visualization
    sort_idx = df_out['Composite_Score'].values.argsort()[::-1]
    labels_sorted = labels[sort_idx]
    df_sorted = df_out.iloc[sort_idx].reset_index(drop=True)

    # Subplot 1: Recovery percentages (stacked-ish grouped bar)
    bar_width = 0.18
    ax1 = axes[0]
    ax1.bar(x - 1.5*bar_width, df_sorted['Nd_Recovery_pct'], bar_width, label='Nd Recovery %', color='#2196F3')
    ax1.bar(x - 0.5*bar_width, df_sorted['Dy_Recovery_pct'], bar_width, label='Dy Recovery %', color='#FF9800')
    ax1.bar(x + 0.5*bar_width, df_sorted['Pr_Recovery_pct'], bar_width, label='Pr Recovery %', color='#4CAF50')
    ax1.bar(x + 1.5*bar_width, df_sorted['Fe_Recovery_pct'], bar_width, label='Fe Recovery %', color='#F44336', alpha=0.7)
    ax1.set_ylabel('Recovery (%)')
    ax1.set_title('REE & Fe Recovery by Condition (sorted by Composite Score)')
    ax1.set_xticks(x)
    ax1.set_xticklabels(labels_sorted, rotation=90, fontsize=6)
    ax1.legend(fontsize=8)
    ax1.set_ylim(0, 110)

    # Subplot 2: Dy/Fe Selectivity and Composite Score
    ax2 = axes[1]
    color1 = '#9C27B0'
    color2 = '#009688'
    ax2.bar(x - 0.2, df_sorted['Dy_Fe_Selectivity'], 0.4, label='Dy/Fe Selectivity', color=color1, alpha=0.8)
    ax2_twin = ax2.twinx()
    ax2_twin.bar(x + 0.2, df_sorted['Composite_Score'], 0.4, label='Composite Score', color=color2, alpha=0.8)
    ax2.set_ylabel('Dy/Fe Selectivity', color=color1)
    ax2_twin.set_ylabel('Composite Score', color=color2)
    ax2.set_title('Dy/Fe Selectivity & Composite Score by Condition')
    ax2.set_xticks(x)
    ax2.set_xticklabels(labels_sorted, rotation=90, fontsize=6)
    # Combined legend
    lines1, labels1 = ax2.get_legend_handles_labels()
    lines2, labels2 = ax2_twin.get_legend_handles_labels()
    ax2.legend(lines1 + lines2, labels1 + labels2, fontsize=8, loc='upper right')

    plt.tight_layout()
    plt.savefig(str(plot_path), dpi=150, bbox_inches='tight')
    plt.close()

    # Output results as JSON
    result = {
        "metrics": metrics_list,
        "plot_path": str(plot_path)
    }
    print(json.dumps(result))

except Exception as e:
    import traceback
    error_result = {
        "metrics": None,
        "plot_path": None,
        "error": str(e),
        "traceback": traceback.format_exc()
    }
    print(json.dumps(error_result))
