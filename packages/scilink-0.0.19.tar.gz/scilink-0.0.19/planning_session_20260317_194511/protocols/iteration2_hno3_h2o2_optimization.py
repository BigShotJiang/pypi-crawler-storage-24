from opentrons import protocol_api

metadata = {
    'protocolName': 'Focused HNO3+H2O2 Acid Leaching Optimization',
    'author': 'OpentronsAI',
    'description': '''Focused optimization of HNO3+H2O2 acid leaching on roasted NdFeB magnet feedstock.
                      Phase 1: Dispense water, HNO3 (slow), and H2O2 to 6 wells with varying concentrations.
                      Phase 2: After manual incubation and centrifugation, collect 500 uL supernatant from each well.''',
    'source': 'OpentronsAI'
}

requirements = {
    'robotType': 'OT-2',
    'apiLevel': '2.16'
}

def run(protocol: protocol_api.ProtocolContext):
    # Load labware
    plate = protocol.load_labware('corning_6_wellplate_16.8ml_flat', '1')  # Plate 7 with pre-weighed powder
    tube_rack = protocol.load_labware('opentrons_10_tuberack_falcon_4x50ml_6x15ml_conical', '2')  # Stock solutions
    tiprack = protocol.load_labware('opentrons_96_tiprack_1000ul', '3')
    collection_tubes = protocol.load_labware('opentrons_24_tuberack_eppendorf_1.5ml_safelock_snapcap', '5')
    
    # Load pipette
    p1000 = protocol.load_instrument('p1000_single_gen2', 'left', tip_racks=[tiprack])
    
    # Define stock solutions in tube rack
    # A1 = 4M HNO3 stock (50 mL Falcon)
    # A2 = DI water (50 mL Falcon)
    # B1 = 1.5M H2O2 stock (50 mL Falcon)
    hno3_stock = tube_rack['A1']
    water_stock = tube_rack['A2']
    h2o2_stock = tube_rack['B1']
    
    # Define well conditions with volumes (all in uL)
    # Format: {well: (water_vol, hno3_vol, h2o2_vol, condition_label)}
    well_conditions = {
        'A1': (2750, 1250, 1000, '1.0M HNO3, 0.3M H2O2, S/L 1:20, 80C'),
        'A2': (1500, 2500, 1000, '2.0M HNO3, 0.3M H2O2, S/L 1:20, 80C'),
        'A3': (3375, 625, 1000, '0.5M HNO3, 0.3M H2O2, S/L 1:20, 80C'),
        'B1': (3417, 1250, 333, '1.0M HNO3, 0.1M H2O2, S/L 1:20, 80C'),
        'B2': (2083, 1250, 1667, '1.0M HNO3, 0.5M H2O2, S/L 1:20, 50C'),
        'B3': (2750, 1250, 1000, '1.0M HNO3, 0.3M H2O2, S/L 1:15, 80C')
    }
    
    protocol.comment("=== PHASE 1: Acid + Oxidant Dispensing ===")
    protocol.comment("Stock solutions: A1=4M HNO3, A2=DI water, B1=1.5M H2O2")
    protocol.comment("Target: 5.0 mL total volume per well")
    
    # PHASE 1: Dispense reagents (water first, then HNO3 slowly, then H2O2)
    # Use dedicated tips for each reagent type to prevent cross-contamination
    
    # Step 1: Dispense DI water to all wells (use one dedicated tip)
    protocol.comment("Step 1: Dispensing DI water to all wells...")
    p1000.pick_up_tip()
    for well_name, (water_vol, _, _, condition) in well_conditions.items():
        protocol.comment(f"Adding {water_vol} uL water to {well_name} ({condition})")
        # Split into multiple aspirate/dispense cycles if volume > 1000 uL
        remaining = water_vol
        while remaining > 0:
            transfer_vol = min(remaining, 1000)
            p1000.aspirate(transfer_vol, water_stock)
            p1000.dispense(transfer_vol, plate[well_name])
            remaining -= transfer_vol
    p1000.drop_tip()
    
    # Step 2: Dispense HNO3 to all wells at slow rate (use one dedicated tip)
    protocol.comment("Step 2: Dispensing HNO3 slowly to all wells...")
    p1000.pick_up_tip()
    for well_name, (_, hno3_vol, _, condition) in well_conditions.items():
        protocol.comment(f"Adding {hno3_vol} uL HNO3 to {well_name} ({condition})")
        # Split into multiple aspirate/dispense cycles if volume > 1000 uL
        remaining = hno3_vol
        while remaining > 0:
            transfer_vol = min(remaining, 1000)
            p1000.aspirate(transfer_vol, hno3_stock, rate=0.5)  # Slow aspirate
            p1000.dispense(transfer_vol, plate[well_name], rate=0.5)  # Slow dispense
            remaining -= transfer_vol
    p1000.drop_tip()
    
    # Step 3: Dispense H2O2 to all wells (use one dedicated tip)
    protocol.comment("Step 3: Dispensing H2O2 to all wells...")
    p1000.pick_up_tip()
    for well_name, (_, _, h2o2_vol, condition) in well_conditions.items():
        protocol.comment(f"Adding {h2o2_vol} uL H2O2 to {well_name} ({condition})")
        # Split into multiple aspirate/dispense cycles if volume > 1000 uL
        remaining = h2o2_vol
        while remaining > 0:
            transfer_vol = min(remaining, 1000)
            p1000.aspirate(transfer_vol, h2o2_stock)
            p1000.dispense(transfer_vol, plate[well_name])
            remaining -= transfer_vol
    p1000.drop_tip()
    
    protocol.comment("=== Phase 1 Complete ===")
    protocol.pause("""Phase 1 complete. Please perform the following manual steps:
    1. Place Plate 7 wells at their target temperatures:
       - Wells A1, A2, A3, B1, B3: 80C
       - Well B2: 50C
    2. Incubate for 120 minutes with periodic swirling
    3. After incubation, centrifuge at 3000 rpm for 10 minutes
    4. Return plate to slot 1 for Phase 2 supernatant collection
    5. Press 'Resume' when ready to continue""")
    
    # PHASE 2: Supernatant collection
    protocol.comment("=== PHASE 2: Supernatant Collection ===")
    
    # Map plate wells to collection tubes
    well_to_tube = {
        'A1': 'A1',
        'A2': 'A2',
        'A3': 'A3',
        'B1': 'B1',
        'B2': 'B2',
        'B3': 'B3'
    }
    
    for well_name, tube_name in well_to_tube.items():
        condition = well_conditions[well_name][3]
        protocol.comment(f"Collecting supernatant from {well_name} ({condition})")
        
        # Pick up new tip for each well
        p1000.pick_up_tip()
        
        # Aspirate 500 uL from 2 mm above well bottom at slow rate
        p1000.aspirate(500, plate[well_name].bottom(z=2), rate=0.3)
        
        # Dispense into corresponding collection tube
        p1000.dispense(500, collection_tubes[tube_name])
        
        # Drop tip
        p1000.drop_tip()
        
        protocol.comment(f"Collected 500 uL from {well_name} to tube {tube_name}")
    
    protocol.comment("=== Protocol Complete ===")
    protocol.comment("All supernatant samples collected successfully")
