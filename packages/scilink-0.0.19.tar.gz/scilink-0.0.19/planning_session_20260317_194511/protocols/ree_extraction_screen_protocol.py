from opentrons import protocol_api

metadata = {
    'protocolName': 'REE Extraction Screen - NdFeB Magnet E-waste',
    'author': 'OpentronsAI',
    'description': '''High-throughput acid leaching screen for rare earth element 
                   extraction from NdFeB magnet e-waste. Phase 1: Acid dispensing 
                   to pre-weighed magnet powder. Phase 2: Supernatant collection 
                   and ICP-MS sample preparation.''',
    'source': 'OpentronsAI'
}

requirements = {
    'robotType': 'OT-2',
    'apiLevel': '2.16'
}

def run(protocol: protocol_api.ProtocolContext):
    
    # ===================== LABWARE SETUP =====================
    
    # Load labware
    plate_1 = protocol.load_labware('corning_6_wellplate_16.8ml_flat', 1, 'Plate 1 - HCl System')
    acid_rack = protocol.load_labware('opentrons_10_tuberack_falcon_4x50ml_6x15ml_conical', 2, 'Acid Stock Solutions')
    tiprack = protocol.load_labware('opentrons_96_tiprack_1000ul', 3)
    plate_2 = protocol.load_labware('corning_6_wellplate_16.8ml_flat', 4, 'Plate 2 - HNO3 System')
    collection_tubes = protocol.load_labware('opentrons_24_tuberack_eppendorf_1.5ml_safelock_snapcap', 5, 'ICP-MS Collection Tubes')
    plate_3 = protocol.load_labware('corning_6_wellplate_16.8ml_flat', 7, 'Plate 3 - H2SO4 System')
    reservoir = protocol.load_labware('nest_12_reservoir_15ml', 8, 'Reagent Reservoir')
    
    # Load pipette
    p1000 = protocol.load_instrument('p1000_single_gen2', 'left', tip_racks=[tiprack])
    
    # ===================== REAGENT LOCATIONS =====================
    
    # Acid stock solutions in tube rack (50 mL tubes)
    hcl_stock = acid_rack['A1']      # 2M HCl
    hno3_stock = acid_rack['A2']     # 2M HNO3
    h2so4_stock = acid_rack['B1']    # 2M H2SO4
    di_water = acid_rack['B2']       # DI water for dilution
    
    # Reservoir solutions
    h2o2_solution = reservoir['A1']   # 0.3M H2O2 oxidant
    icpms_diluent = reservoir['A12']  # 2% HNO3 for ICP-MS dilution
    
    # ===================== PHASE 1: ACID DISPENSING =====================
    
    protocol.comment("=" * 50)
    protocol.comment("PHASE 1: ACID DISPENSING TO REACTION PLATES")
    protocol.comment("=" * 50)
    
    # -------------------- PLATE 1: HCl SYSTEM --------------------
    protocol.comment("\n--- Processing Plate 1: HCl System (Unroasted Feedstock) ---")
    
    # Well A1: 0.5M HCl (1.25 mL 2M HCl + 3.75 mL DI water)
    protocol.comment("Plate 1, Well A1: 0.5M HCl, S/L 1:10")
    p1000.pick_up_tip()
    p1000.transfer(750, di_water, plate_1['A1'], new_tip='never')
    p1000.transfer(750, di_water, plate_1['A1'], new_tip='never')
    p1000.transfer(750, di_water, plate_1['A1'], new_tip='never')
    p1000.transfer(750, di_water, plate_1['A1'], new_tip='never')
    p1000.transfer(750, di_water, plate_1['A1'], new_tip='never')
    p1000.drop_tip()
    
    p1000.pick_up_tip()
    p1000.transfer(625, hcl_stock, plate_1['A1'], rate=0.5, new_tip='never')
    p1000.transfer(625, hcl_stock, plate_1['A1'], rate=0.5, new_tip='never')
    p1000.drop_tip()
    
    # Well A2: 1.0M HCl (2.50 mL 2M HCl + 2.50 mL DI water)
    protocol.comment("Plate 1, Well A2: 1.0M HCl, S/L 1:10")
    p1000.pick_up_tip()
    p1000.transfer(833, di_water, plate_1['A2'], new_tip='never')
    p1000.transfer(833, di_water, plate_1['A2'], new_tip='never')
    p1000.transfer(834, di_water, plate_1['A2'], new_tip='never')
    p1000.drop_tip()
    
    p1000.pick_up_tip()
    p1000.transfer(833, hcl_stock, plate_1['A2'], rate=0.5, new_tip='never')
    p1000.transfer(833, hcl_stock, plate_1['A2'], rate=0.5, new_tip='never')
    p1000.transfer(834, hcl_stock, plate_1['A2'], rate=0.5, new_tip='never')
    p1000.drop_tip()
    
    # Well A3: 2.0M HCl (5.00 mL 2M HCl)
    protocol.comment("Plate 1, Well A3: 2.0M HCl, S/L 1:10")
    p1000.pick_up_tip()
    p1000.transfer(1000, hcl_stock, plate_1['A3'], rate=0.5, new_tip='never')
    p1000.transfer(1000, hcl_stock, plate_1['A3'], rate=0.5, new_tip='never')
    p1000.transfer(1000, hcl_stock, plate_1['A3'], rate=0.5, new_tip='never')
    p1000.transfer(1000, hcl_stock, plate_1['A3'], rate=0.5, new_tip='never')
    p1000.transfer(1000, hcl_stock, plate_1['A3'], rate=0.5, new_tip='never')
    p1000.drop_tip()
    
    # Well B1: 0.5M HCl (1.25 mL 2M HCl + 3.75 mL DI water, S/L 1:20)
    protocol.comment("Plate 1, Well B1: 0.5M HCl, S/L 1:20")
    p1000.pick_up_tip()
    p1000.transfer(750, di_water, plate_1['B1'], new_tip='never')
    p1000.transfer(750, di_water, plate_1['B1'], new_tip='never')
    p1000.transfer(750, di_water, plate_1['B1'], new_tip='never')
    p1000.transfer(750, di_water, plate_1['B1'], new_tip='never')
    p1000.transfer(750, di_water, plate_1['B1'], new_tip='never')
    p1000.drop_tip()
    
    p1000.pick_up_tip()
    p1000.transfer(625, hcl_stock, plate_1['B1'], rate=0.5, new_tip='never')
    p1000.transfer(625, hcl_stock, plate_1['B1'], rate=0.5, new_tip='never')
    p1000.drop_tip()
    
    # Well B2: 1.0M HCl (2.50 mL 2M HCl + 2.50 mL DI water, S/L 1:20)
    protocol.comment("Plate 1, Well B2: 1.0M HCl, S/L 1:20")
    p1000.pick_up_tip()
    p1000.transfer(833, di_water, plate_1['B2'], new_tip='never')
    p1000.transfer(833, di_water, plate_1['B2'], new_tip='never')
    p1000.transfer(834, di_water, plate_1['B2'], new_tip='never')
    p1000.drop_tip()
    
    p1000.pick_up_tip()
    p1000.transfer(833, hcl_stock, plate_1['B2'], rate=0.5, new_tip='never')
    p1000.transfer(833, hcl_stock, plate_1['B2'], rate=0.5, new_tip='never')
    p1000.transfer(834, hcl_stock, plate_1['B2'], rate=0.5, new_tip='never')
    p1000.drop_tip()
    
    # Well B3: 2.0M HCl (5.00 mL 2M HCl, S/L 1:20)
    protocol.comment("Plate 1, Well B3: 2.0M HCl, S/L 1:20")
    p1000.pick_up_tip()
    p1000.transfer(1000, hcl_stock, plate_1['B3'], rate=0.5, new_tip='never')
    p1000.transfer(1000, hcl_stock, plate_1['B3'], rate=0.5, new_tip='never')
    p1000.transfer(1000, hcl_stock, plate_1['B3'], rate=0.5, new_tip='never')
    p1000.transfer(1000, hcl_stock, plate_1['B3'], rate=0.5, new_tip='never')
    p1000.transfer(1000, hcl_stock, plate_1['B3'], rate=0.5, new_tip='never')
    p1000.drop_tip()
    
    # -------------------- PLATE 2: HNO3 SYSTEM --------------------
    protocol.comment("\n--- Processing Plate 2: HNO3 System (Unroasted Feedstock) ---")
    
    # Well A1: 0.5M HNO3 (1.25 mL 2M HNO3 + 3.75 mL DI water)
    protocol.comment("Plate 2, Well A1: 0.5M HNO3")
    p1000.pick_up_tip()
    p1000.transfer(750, di_water, plate_2['A1'], new_tip='never')
    p1000.transfer(750, di_water, plate_2['A1'], new_tip='never')
    p1000.transfer(750, di_water, plate_2['A1'], new_tip='never')
    p1000.transfer(750, di_water, plate_2['A1'], new_tip='never')
    p1000.transfer(750, di_water, plate_2['A1'], new_tip='never')
    p1000.drop_tip()
    
    p1000.pick_up_tip()
    p1000.transfer(625, hno3_stock, plate_2['A1'], rate=0.5, new_tip='never')
    p1000.transfer(625, hno3_stock, plate_2['A1'], rate=0.5, new_tip='never')
    p1000.drop_tip()
    
    # Well A2: 1.0M HNO3 (2.50 mL 2M HNO3 + 2.50 mL DI water)
    protocol.comment("Plate 2, Well A2: 1.0M HNO3")
    p1000.pick_up_tip()
    p1000.transfer(833, di_water, plate_2['A2'], new_tip='never')
    p1000.transfer(833, di_water, plate_2['A2'], new_tip='never')
    p1000.transfer(834, di_water, plate_2['A2'], new_tip='never')
    p1000.drop_tip()
    
    p1000.pick_up_tip()
    p1000.transfer(833, hno3_stock, plate_2['A2'], rate=0.5, new_tip='never')
    p1000.transfer(833, hno3_stock, plate_2['A2'], rate=0.5, new_tip='never')
    p1000.transfer(834, hno3_stock, plate_2['A2'], rate=0.5, new_tip='never')
    p1000.drop_tip()
    
    # Well A3: 2.0M HNO3 (5.00 mL 2M HNO3)
    protocol.comment("Plate 2, Well A3: 2.0M HNO3")
    p1000.pick_up_tip()
    p1000.transfer(1000, hno3_stock, plate_2['A3'], rate=0.5, new_tip='never')
    p1000.transfer(1000, hno3_stock, plate_2['A3'], rate=0.5, new_tip='never')
    p1000.transfer(1000, hno3_stock, plate_2['A3'], rate=0.5, new_tip='never')
    p1000.transfer(1000, hno3_stock, plate_2['A3'], rate=0.5, new_tip='never')
    p1000.transfer(1000, hno3_stock, plate_2['A3'], rate=0.5, new_tip='never')
    p1000.drop_tip()
    
    # Well B1: 0.5M HNO3 + H2O2 (1.25 mL 2M HNO3 + 1.25 mL H2O2 + 2.50 mL DI water)
    protocol.comment("Plate 2, Well B1: 0.5M HNO3 + 0.075M H2O2")
    p1000.pick_up_tip()
    p1000.transfer(833, di_water, plate_2['B1'], new_tip='never')
    p1000.transfer(833, di_water, plate_2['B1'], new_tip='never')
    p1000.transfer(834, di_water, plate_2['B1'], new_tip='never')
    p1000.drop_tip()
    
    p1000.pick_up_tip()
    p1000.transfer(625, hno3_stock, plate_2['B1'], rate=0.5, new_tip='never')
    p1000.transfer(625, hno3_stock, plate_2['B1'], rate=0.5, new_tip='never')
    p1000.drop_tip()
    
    p1000.pick_up_tip()
    p1000.transfer(625, h2o2_solution, plate_2['B1'], new_tip='never')
    p1000.transfer(625, h2o2_solution, plate_2['B1'], new_tip='never')
    p1000.drop_tip()
    
    # Well B2: 1.0M HNO3 + H2O2 (2.50 mL 2M HNO3 + 1.25 mL H2O2 + 1.25 mL DI water)
    protocol.comment("Plate 2, Well B2: 1.0M HNO3 + 0.075M H2O2")
    p1000.pick_up_tip()
    p1000.transfer(625, di_water, plate_2['B2'], new_tip='never')
    p1000.transfer(625, di_water, plate_2['B2'], new_tip='never')
    p1000.drop_tip()
    
    p1000.pick_up_tip()
    p1000.transfer(833, hno3_stock, plate_2['B2'], rate=0.5, new_tip='never')
    p1000.transfer(833, hno3_stock, plate_2['B2'], rate=0.5, new_tip='never')
    p1000.transfer(834, hno3_stock, plate_2['B2'], rate=0.5, new_tip='never')
    p1000.drop_tip()
    
    p1000.pick_up_tip()
    p1000.transfer(625, h2o2_solution, plate_2['B2'], new_tip='never')
    p1000.transfer(625, h2o2_solution, plate_2['B2'], new_tip='never')
    p1000.drop_tip()
    
    # Well B3: 2.0M HNO3 (5.00 mL 2M HNO3)
    protocol.comment("Plate 2, Well B3: 2.0M HNO3 (H2O2 addition to be handled manually)")
    p1000.pick_up_tip()
    p1000.transfer(1000, hno3_stock, plate_2['B3'], rate=0.5, new_tip='never')
    p1000.transfer(1000, hno3_stock, plate_2['B3'], rate=0.5, new_tip='never')
    p1000.transfer(1000, hno3_stock, plate_2['B3'], rate=0.5, new_tip='never')
    p1000.transfer(1000, hno3_stock, plate_2['B3'], rate=0.5, new_tip='never')
    p1000.transfer(1000, hno3_stock, plate_2['B3'], rate=0.5, new_tip='never')
    p1000.drop_tip()
    
    # -------------------- PLATE 3: H2SO4 SYSTEM --------------------
    protocol.comment("\n--- Processing Plate 3: H2SO4 System (Unroasted Feedstock) ---")
    
    # Well A1: 0.5M H2SO4 (1.25 mL 2M H2SO4 + 3.75 mL DI water)
    protocol.comment("Plate 3, Well A1: 0.5M H2SO4")
    p1000.pick_up_tip()
    p1000.transfer(750, di_water, plate_3['A1'], new_tip='never')
    p1000.transfer(750, di_water, plate_3['A1'], new_tip='never')
    p1000.transfer(750, di_water, plate_3['A1'], new_tip='never')
    p1000.transfer(750, di_water, plate_3['A1'], new_tip='never')
    p1000.transfer(750, di_water, plate_3['A1'], new_tip='never')
    p1000.drop_tip()
    
    p1000.pick_up_tip()
    p1000.transfer(625, h2so4_stock, plate_3['A1'], rate=0.5, new_tip='never')
    p1000.transfer(625, h2so4_stock, plate_3['A1'], rate=0.5, new_tip='never')
    p1000.drop_tip()
    
    # Well A2: 1.0M H2SO4 (2.50 mL 2M H2SO4 + 2.50 mL DI water)
    protocol.comment("Plate 3, Well A2: 1.0M H2SO4")
    p1000.pick_up_tip()
    p1000.transfer(833, di_water, plate_3['A2'], new_tip='never')
    p1000.transfer(833, di_water, plate_3['A2'], new_tip='never')
    p1000.transfer(834, di_water, plate_3['A2'], new_tip='never')
    p1000.drop_tip()
    
    p1000.pick_up_tip()
    p1000.transfer(833, h2so4_stock, plate_3['A2'], rate=0.5, new_tip='never')
    p1000.transfer(833, h2so4_stock, plate_3['A2'], rate=0.5, new_tip='never')
    p1000.transfer(834, h2so4_stock, plate_3['A2'], rate=0.5, new_tip='never')
    p1000.drop_tip()
    
    # Well A3: 2.0M H2SO4 (5.00 mL 2M H2SO4)
    protocol.comment("Plate 3, Well A3: 2.0M H2SO4")
    p1000.pick_up_tip()
    p1000.transfer(1000, h2so4_stock, plate_3['A3'], rate=0.5, new_tip='never')
    p1000.transfer(1000, h2so4_stock, plate_3['A3'], rate=0.5, new_tip='never')
    p1000.transfer(1000, h2so4_stock, plate_3['A3'], rate=0.5, new_tip='never')
    p1000.transfer(1000, h2so4_stock, plate_3['A3'], rate=0.5, new_tip='never')
    p1000.transfer(1000, h2so4_stock, plate_3['A3'], rate=0.5, new_tip='never')
    p1000.drop_tip()
    
    # Well B1: 0.5M H2SO4 (1.25 mL 2M H2SO4 + 3.75 mL DI water, S/L 1:20)
    protocol.comment("Plate 3, Well B1: 0.5M H2SO4, S/L 1:20")
    p1000.pick_up_tip()
    p1000.transfer(750, di_water, plate_3['B1'], new_tip='never')
    p1000.transfer(750, di_water, plate_3['B1'], new_tip='never')
    p1000.transfer(750, di_water, plate_3['B1'], new_tip='never')
    p1000.transfer(750, di_water, plate_3['B1'], new_tip='never')
    p1000.transfer(750, di_water, plate_3['B1'], new_tip='never')
    p1000.drop_tip()
    
    p1000.pick_up_tip()
    p1000.transfer(625, h2so4_stock, plate_3['B1'], rate=0.5, new_tip='never')
    p1000.transfer(625, h2so4_stock, plate_3['B1'], rate=0.5, new_tip='never')
    p1000.drop_tip()
    
    # Well B2: 1.0M H2SO4 (2.50 mL 2M H2SO4 + 2.50 mL DI water, S/L 1:20)
    protocol.comment("Plate 3, Well B2: 1.0M H2SO4, S/L 1:20")
    p1000.pick_up_tip()
    p1000.transfer(833, di_water, plate_3['B2'], new_tip='never')
    p1000.transfer(833, di_water, plate_3['B2'], new_tip='never')
    p1000.transfer(834, di_water, plate_3['B2'], new_tip='never')
    p1000.drop_tip()
    
    p1000.pick_up_tip()
    p1000.transfer(833, h2so4_stock, plate_3['B2'], rate=0.5, new_tip='never')
    p1000.transfer(833, h2so4_stock, plate_3['B2'], rate=0.5, new_tip='never')
    p1000.transfer(834, h2so4_stock, plate_3['B2'], rate=0.5, new_tip='never')
    p1000.drop_tip()
    
    # Well B3: 2.0M H2SO4 (5.00 mL 2M H2SO4, S/L 1:20)
    protocol.comment("Plate 3, Well B3: 2.0M H2SO4, S/L 1:20")
    p1000.pick_up_tip()
    p1000.transfer(1000, h2so4_stock, plate_3['B3'], rate=0.5, new_tip='never')
    p1000.transfer(1000, h2so4_stock, plate_3['B3'], rate=0.5, new_tip='never')
    p1000.transfer(1000, h2so4_stock, plate_3['B3'], rate=0.5, new_tip='never')
    p1000.transfer(1000, h2so4_stock, plate_3['B3'], rate=0.5, new_tip='never')
    p1000.transfer(1000, h2so4_stock, plate_3['B3'], rate=0.5, new_tip='never')
    p1000.drop_tip()
    
    # ===================== PAUSE FOR OFF-ROBOT INCUBATION =====================
    
    protocol.comment("\n" + "=" * 50)
    protocol.comment("PHASE 1 COMPLETE")
    protocol.comment("=" * 50)
    protocol.pause("""Phase 1 complete. Remove plates for off-robot incubation at target 
                   temperatures (25-80C) for 120 minutes with periodic swirling. 
                   After incubation, centrifuge plates at 3000 rpm for 10 min, 
                   then return plates to the same deck positions for Phase 2 
                   supernatant collection.""")
    
    # ===================== PHASE 2: SUPERNATANT COLLECTION =====================
    
    protocol.comment("\n" + "=" * 50)
    protocol.comment("PHASE 2: SUPERNATANT COLLECTION AND ICP-MS PREP")
    protocol.comment("=" * 50)
    
    # Define all wells from the three plates
    all_wells = [
        plate_1['A1'], plate_1['A2'], plate_1['A3'], plate_1['B1'], plate_1['B2'], plate_1['B3'],
        plate_2['A1'], plate_2['A2'], plate_2['A3'], plate_2['B1'], plate_2['B2'], plate_2['B3'],
        plate_3['A1'], plate_3['A2'], plate_3['A3'], plate_3['B1'], plate_3['B2'], plate_3['B3']
    ]
    
    # Define collection tube positions (18 tubes needed)
    collection_positions = collection_tubes.wells()[:18]
    
    # Collect 500 uL supernatant from each well
    protocol.comment("\n--- Collecting supernatant from all wells ---")
    for i, (source_well, dest_tube) in enumerate(zip(all_wells, collection_positions), 1):
        protocol.comment(f"Collecting from well {i}/18: {source_well}")
        p1000.pick_up_tip()
        # Aspirate slowly from 2 mm above well bottom to avoid disturbing pellet
        p1000.aspirate(500, source_well.bottom(z=2), rate=0.3)
        p1000.dispense(500, dest_tube)
        p1000.drop_tip()
    
    # ===================== ICP-MS SAMPLE PREPARATION =====================
    
    protocol.comment("\n--- Preparing ICP-MS dilution samples (1:10 dilution) ---")
    
    # Prepare 1:10 dilutions for ICP-MS analysis
    # Transfer 100 uL from each collection tube to a fresh tube, add 900 uL of 2% HNO3
    for i in range(18):
        source_tube = collection_positions[i]
        # Use the second half of the tube rack for diluted samples
        dest_tube = collection_tubes.wells()[i + 6] if i < 6 else collection_tubes.wells()[i + 12]
        
        protocol.comment(f"Preparing ICP-MS sample {i+1}/18")
        
        # Transfer 100 uL of supernatant
        p1000.pick_up_tip()
        p1000.aspirate(100, source_tube)
        p1000.dispense(100, dest_tube)
        p1000.drop_tip()
        
        # Add 900 uL of 2% HNO3 diluent
        p1000.pick_up_tip()
        p1000.aspirate(900, icpms_diluent)
        p1000.dispense(900, dest_tube)
        p1000.mix(3, 500, dest_tube)  # Mix 3 times with 500 uL
        p1000.drop_tip()
    
    protocol.comment("\n" + "=" * 50)
    protocol.comment("PROTOCOL COMPLETE")
    protocol.comment("=" * 50)
    protocol.comment("All supernatant samples collected and ICP-MS dilutions prepared.")
