from opentrons import protocol_api

metadata = {
    'protocolName': 'Dy/Nd Solvent Extraction Screening - 96-well Deep-well Plate',
    'author': 'OpentronsAI',
    'description': '''High-throughput screening of D2EHPA extractant at varying pH, 
                      concentrations, and O/A ratios for Dy/Nd separation. Includes 
                      pre-fill of ICP plate, aqueous and organic additions, and 
                      post-centrifugation sampling.''',
    'source': 'OpentronsAI'
}

requirements = {
    'robotType': 'OT-2',
    'apiLevel': '2.19'
}

def run(protocol: protocol_api.ProtocolContext):
    
    # ===================== LABWARE SETUP =====================
    
    # Deep-well reaction plate (slot 1)
    reaction_plate = protocol.load_labware('nest_96_wellplate_2ml_deep', 1, 'Reaction Plate')
    
    # ICP sampling plate (slot 2)
    icp_plate = protocol.load_labware('nest_96_wellplate_200ul_flat', 2, 'ICP Sampling Plate')
    
    # Aqueous feed reservoir (slot 3)
    aq_reservoir = protocol.load_labware('nest_12_reservoir_15ml', 3, 'Aqueous Feeds')
    
    # Organic/HNO3 reservoir (slot 4)
    org_reservoir = protocol.load_labware('nest_12_reservoir_15ml', 4, 'Organic Solutions')
    
    # Tip racks - 4x P1000 + 2x P300
    tips_1000_1 = protocol.load_labware('opentrons_96_tiprack_1000ul', 5)
    tips_1000_2 = protocol.load_labware('opentrons_96_tiprack_1000ul', 6)
    tips_1000_3 = protocol.load_labware('opentrons_96_tiprack_1000ul', 7)
    tips_1000_4 = protocol.load_labware('opentrons_96_tiprack_1000ul', 8)
    tips_300_1 = protocol.load_labware('opentrons_96_tiprack_300ul', 9)
    tips_300_2 = protocol.load_labware('opentrons_96_tiprack_300ul', 10)
    
    # ===================== PIPETTE SETUP =====================
    
    # P1000 single-channel on left mount
    p1000 = protocol.load_instrument(
        'p1000_single_gen2', 
        'left', 
        tip_racks=[tips_1000_1, tips_1000_2, tips_1000_3, tips_1000_4]
    )
    
    # P300 8-channel on right mount
    p300_multi = protocol.load_instrument(
        'p300_multi_gen2', 
        'right', 
        tip_racks=[tips_300_1, tips_300_2]
    )
    
    # ===================== VOLUME CALCULATIONS =====================
    # O/A ratio volume calculations (total ~1500 uL per well)
    # O/A = 0.5: 500 uL organic + 1000 uL aqueous
    # O/A = 1.0: 750 uL organic + 750 uL aqueous
    # O/A = 1.5: 900 uL organic + 600 uL aqueous
    
    volumes = {
        'OA_0.5': {'organic': 500, 'aqueous': 1000},
        'OA_1.0': {'organic': 750, 'aqueous': 750},
        'OA_1.5': {'organic': 900, 'aqueous': 600}
    }
    
    # Map columns (0-indexed) to O/A ratios
    # Cols 1,4,7,10 -> O/A=0.5 | Cols 2,5,8,11 -> O/A=1.0 | Cols 3,6,9,12 -> O/A=1.5
    column_to_oa = {
        0: 'OA_0.5', 1: 'OA_1.0', 2: 'OA_1.5',   # 0.05 M D2EHPA
        3: 'OA_0.5', 4: 'OA_1.0', 5: 'OA_1.5',   # 0.10 M D2EHPA
        6: 'OA_0.5', 7: 'OA_1.0', 8: 'OA_1.5',   # 0.25 M D2EHPA
        9: 'OA_0.5', 10: 'OA_1.0', 11: 'OA_1.5'  # 0.50 M D2EHPA
    }
    
    # Map columns to extractant source wells in organic reservoir
    # A1=0.05M, A2=0.10M, A3=0.25M, A4=0.50M D2EHPA
    column_to_extractant = {
        0: 'A1', 1: 'A1', 2: 'A1',    # 0.05 M D2EHPA
        3: 'A2', 4: 'A2', 5: 'A2',    # 0.10 M D2EHPA
        6: 'A3', 7: 'A3', 8: 'A3',    # 0.25 M D2EHPA
        9: 'A4', 10: 'A4', 11: 'A4'   # 0.50 M D2EHPA
    }
    
    # Map rows (0-indexed) to aqueous feed pH source wells
    # A1=pH1.0, A2=pH1.5, A3=pH2.0, A4=pH2.5, A5=pH3.0, A6=pH3.5, A7=pH4.0
    row_to_ph = {
        0: 'A1',  # Row A -> pH 1.0
        1: 'A2',  # Row B -> pH 1.5
        2: 'A3',  # Row C -> pH 2.0
        3: 'A4',  # Row D -> pH 2.5
        4: 'A5',  # Row E -> pH 3.0
        5: 'A6',  # Row F -> pH 3.5
        6: 'A7'   # Row G -> pH 4.0
    }
    
    # =====================================================================
    # STEP 1: PRE-FILL ICP PLATE WITH 2% HNO3
    # Using P300 8-channel for efficiency (100 uL per well, all 96 wells)
    # =====================================================================
    
    protocol.comment("=== STEP 1: Pre-filling ICP plate with 100 uL 2% HNO3 ===")
    
    for col in icp_plate.columns():
        p300_multi.pick_up_tip()
        p300_multi.aspirate(100, org_reservoir['A6'])  # 2% HNO3 source
        p300_multi.dispense(100, col[0])
        p300_multi.drop_tip()
    
    protocol.comment("ICP plate pre-fill complete.")
    
    # =====================================================================
    # STEP 2: ADD AQUEOUS FEED SOLUTIONS TO REACTION PLATE
    # Using P1000 single-channel with reduced flow rate
    # Fresh tip per pH level (rows share the same pH)
    # =====================================================================
    
    protocol.comment("=== STEP 2: Adding pH-adjusted aqueous feeds (rows A-G) ===")
    
    p1000.flow_rate.aspirate = 150  # Reduced from default ~274 uL/s
    
    for row_idx in range(7):  # Rows A-G (pH 1.0 to 4.0)
        ph_well = row_to_ph[row_idx]
        
        p1000.pick_up_tip()
        
        for col_idx in range(12):
            oa_ratio = column_to_oa[col_idx]
            aq_volume = volumes[oa_ratio]['aqueous']
            well = reaction_plate.rows()[row_idx][col_idx]
            
            p1000.aspirate(aq_volume, aq_reservoir[ph_well])
            p1000.dispense(aq_volume, well)
        
        p1000.drop_tip()
    
    # Row H control wells - aqueous addition
    protocol.comment("Adding aqueous to Row H control wells")
    p1000.pick_up_tip()
    # H1: Blank (kerosene + pH 1.0 aq), 750 uL aqueous
    p1000.aspirate(750, aq_reservoir['A1'])
    p1000.dispense(750, reaction_plate['H1'])
    # H2: Blank (kerosene + pH 3.0 aq), 750 uL aqueous
    p1000.aspirate(750, aq_reservoir['A5'])
    p1000.dispense(750, reaction_plate['H2'])
    # H3: Feed-only control (pH 1.0, no organic), 750 uL
    p1000.aspirate(750, aq_reservoir['A1'])
    p1000.dispense(750, reaction_plate['H3'])
    # H4: Feed-only control (pH 3.0, no organic), 750 uL
    p1000.aspirate(750, aq_reservoir['A5'])
    p1000.dispense(750, reaction_plate['H4'])
    # H5-H6: Replicate pair - 0.10M, O/A=1.0, pH 3.0 -> 750 uL aqueous each
    p1000.aspirate(750, aq_reservoir['A5'])
    p1000.dispense(750, reaction_plate['H5'])
    p1000.aspirate(750, aq_reservoir['A5'])
    p1000.dispense(750, reaction_plate['H6'])
    # H7-H8: Replicate pair - 0.10M, O/A=1.5, pH 3.0 -> 600 uL aqueous each
    p1000.aspirate(600, aq_reservoir['A5'])
    p1000.dispense(600, reaction_plate['H7'])
    p1000.aspirate(600, aq_reservoir['A5'])
    p1000.dispense(600, reaction_plate['H8'])
    # H9-H10: Replicate pair - 0.50M, O/A=1.5, pH 1.5 -> 600 uL aqueous each
    p1000.aspirate(600, aq_reservoir['A2'])
    p1000.dispense(600, reaction_plate['H9'])
    p1000.aspirate(600, aq_reservoir['A2'])
    p1000.dispense(600, reaction_plate['H10'])
    # H11-H12: Replicate pair - 0.25M, O/A=1.0, pH 2.5 -> 750 uL aqueous each
    p1000.aspirate(750, aq_reservoir['A4'])
    p1000.dispense(750, reaction_plate['H11'])
    p1000.aspirate(750, aq_reservoir['A4'])
    p1000.dispense(750, reaction_plate['H12'])
    p1000.drop_tip()
    
    protocol.comment("Aqueous feed addition complete.")
    p1000.flow_rate.aspirate = 274  # Reset to default
    
    # =====================================================================
    # STEP 3: ADD ORGANIC EXTRACTANT SOLUTIONS
    # Using P1000 single-channel with slow aspiration (100 uL/s)
    # FRESH TIP FOR EVERY WELL to prevent cross-contamination
    # Dispense gently from 5mm above liquid surface
    # =====================================================================
    
    protocol.comment("=== STEP 3: Adding organic extractant solutions (rows A-G) ===")
    
    p1000.flow_rate.aspirate = 100  # Slow for organic solvents
    
    for row_idx in range(7):  # Rows A-G
        for col_idx in range(12):
            oa_ratio = column_to_oa[col_idx]
            org_volume = volumes[oa_ratio]['organic']
            extractant_well = column_to_extractant[col_idx]
            well = reaction_plate.rows()[row_idx][col_idx]
            
            p1000.pick_up_tip()
            p1000.aspirate(org_volume, org_reservoir[extractant_well])
            p1000.dispense(org_volume, well.top(-5))  # 5mm below top
            p1000.drop_tip()
    
    # Row H control wells - organic addition
    protocol.comment("Adding organic to Row H control/replicate wells")
    
    # H1: Kerosene blank, 750 uL
    p1000.pick_up_tip()
    p1000.aspirate(750, org_reservoir['A5'])  # Kerosene only
    p1000.dispense(750, reaction_plate['H1'].top(-5))
    p1000.drop_tip()
    
    # H2: Kerosene blank, 750 uL
    p1000.pick_up_tip()
    p1000.aspirate(750, org_reservoir['A5'])
    p1000.dispense(750, reaction_plate['H2'].top(-5))
    p1000.drop_tip()
    
    # H3, H4: Feed-only controls — NO organic added
    
    # H5-H6: 0.10M D2EHPA, O/A=1.0 -> 750 uL organic each
    p1000.pick_up_tip()
    p1000.aspirate(750, org_reservoir['A2'])  # 0.10 M
    p1000.dispense(750, reaction_plate['H5'].top(-5))
    p1000.drop_tip()
    
    p1000.pick_up_tip()
    p1000.aspirate(750, org_reservoir['A2'])
    p1000.dispense(750, reaction_plate['H6'].top(-5))
    p1000.drop_tip()
    
    # H7-H8: 0.10M D2EHPA, O/A=1.5 -> 900 uL organic each
    p1000.pick_up_tip()
    p1000.aspirate(900, org_reservoir['A2'])
    p1000.dispense(900, reaction_plate['H7'].top(-5))
    p1000.drop_tip()
    
    p1000.pick_up_tip()
    p1000.aspirate(900, org_reservoir['A2'])
    p1000.dispense(900, reaction_plate['H8'].top(-5))
    p1000.drop_tip()
    
    # H9-H10: 0.50M D2EHPA, O/A=1.5 -> 900 uL organic each
    p1000.pick_up_tip()
    p1000.aspirate(900, org_reservoir['A4'])  # 0.50 M
    p1000.dispense(900, reaction_plate['H9'].top(-5))
    p1000.drop_tip()
    
    p1000.pick_up_tip()
    p1000.aspirate(900, org_reservoir['A4'])
    p1000.dispense(900, reaction_plate['H10'].top(-5))
    p1000.drop_tip()
    
    # H11-H12: 0.25M D2EHPA, O/A=1.0 -> 750 uL organic each
    p1000.pick_up_tip()
    p1000.aspirate(750, org_reservoir['A3'])  # 0.25 M
    p1000.dispense(750, reaction_plate['H11'].top(-5))
    p1000.drop_tip()
    
    p1000.pick_up_tip()
    p1000.aspirate(750, org_reservoir['A3'])
    p1000.dispense(750, reaction_plate['H12'].top(-5))
    p1000.drop_tip()
    
    protocol.comment("Organic extractant addition complete.")
    p1000.flow_rate.aspirate = 274  # Reset to default
    
    # =====================================================================
    # OFF-ROBOT MANUAL STEPS
    # =====================================================================
    
    protocol.pause(
        '''
        ========================================
        === MANUAL INTERVENTION REQUIRED ===
        ========================================
        
        Please perform the following OFF-ROBOT steps:
        
        1. REMOVE the deep-well reaction plate from Slot 1
        2. SEAL the plate with chemically resistant aluminum foil seal
           (e.g., VWR 89049-178)
        3. VORTEX the sealed plate at 1500 rpm for 5 minutes
           (e.g., IKA MS 3 digital microplate vortexer)
        4. CENTRIFUGE at 3000 x g for 10 minutes at 22°C
           (e.g., Eppendorf 5810R with microplate rotor)
        5. Carefully PEEL the aluminum seal
        6. RETURN the plate to Slot 1 on the OT-2 deck
        
        IMPORTANT: Handle plate gently to avoid disturbing
        the organic-aqueous phase boundary.
        
        Press RESUME when the plate is back on the deck.
        '''
    )
    
    # =====================================================================
    # STEP 4: SAMPLE AQUEOUS RAFFINATE FOR ICP ANALYSIS
    # Using P1000 single-channel at very slow aspiration (50 uL/s)
    # Aspirate from 2mm above well bottom (below organic-aqueous interface)
    # FRESH TIP FOR EVERY WELL
    # =====================================================================
    
    protocol.comment("=== STEP 4: Sampling aqueous raffinate for ICP analysis ===")
    
    p1000.flow_rate.aspirate = 50  # Very slow to avoid disturbing interface
    
    for row_idx in range(8):  # All rows A-H
        for col_idx in range(12):
            source_well = reaction_plate.rows()[row_idx][col_idx]
            dest_well = icp_plate.rows()[row_idx][col_idx]
            
            p1000.pick_up_tip()
            # Aspirate 100 uL from 2mm above well bottom
            # This targets the aqueous phase below the organic layer
            p1000.aspirate(100, source_well.bottom(2))
            # Dispense into ICP plate (already contains 100 uL 2% HNO3)
            # Final volume = 200 uL (2x dilution)
            p1000.dispense(100, dest_well)
            p1000.drop_tip()
    
    protocol.comment("Aqueous raffinate sampling complete.")
    p1000.flow_rate.aspirate = 274  # Reset to default
    
    # =====================================================================
    # PROTOCOL COMPLETE
    # =====================================================================
    
    protocol.comment(
        '''
        ============================================
        === PROTOCOL COMPLETE ===
        ============================================
        
        PLATE MAP SUMMARY:
        
        Reaction Plate (Slot 1):
          Rows A-G: pH 1.0 to 4.0 (7 pH levels)
          Cols 1-3:   0.05 M D2EHPA at O/A = 0.5, 1.0, 1.5
          Cols 4-6:   0.10 M D2EHPA at O/A = 0.5, 1.0, 1.5
          Cols 7-9:   0.25 M D2EHPA at O/A = 0.5, 1.0, 1.5
          Cols 10-12: 0.50 M D2EHPA at O/A = 0.5, 1.0, 1.5
          Row H: Controls (H1-H2 blanks, H3-H4 feed-only, H5-H12 replicates)
        
        ICP Sampling Plate (Slot 2):
          All 96 wells contain 200 uL total:
            100 uL 2% HNO3 + 100 uL aqueous raffinate
            (2x dilution factor for ICP-OES analysis)
        
        NEXT STEPS (OFF-ROBOT):
          1. Measure equilibrium pH on representative wells (Row E recommended)
          2. Run ICP-OES on the sampling plate
             - Dy at 353.170 nm, Nd at 401.225 nm
          3. Calculate: D_Dy, D_Nd, SF(Dy/Nd), %Extraction
          4. Generate response-surface plots
          5. Confirm top 3 conditions at bench scale (15 mL vials)
        '''
    )
