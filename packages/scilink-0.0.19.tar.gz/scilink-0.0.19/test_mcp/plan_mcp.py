from scilink.agents.planning_agents.planning_orchestrator import (                                                                                 
      PlanningOrchestratorAgent, AutonomyLevel                                                                                                       
  )                                                        


objective = """Optimize Nd and Dy extraction from the feedstock, 
      using Opentron liquid handling robot with 96 well plates.
      After generating the experimental plan, use the OpentronsAI MCP tools to create 
      the code implementation for automated execution."""
                                                                                                                                     
# Create the orchestrator in autonomous mode                                                                                                       
agent = PlanningOrchestratorAgent(
      objective=objective,
      knowledge_dir="/Users/maxim.ziatdinov/Code/scilink_workshop/data/Planning/papers",
      data_dir="/Users/maxim.ziatdinov/Code/scilink_workshop/data/Planning/data",
      model_name="claude-opus-4-6-v1-project",
      embedding_model="gemini-embedding-001-project",
      base_url="https://ai-incubator-api.pnnl.gov",
      autonomy_level=AutonomyLevel.AUTONOMOUS
  )

# Connect the OpentronsAI MCP server
n_tools = agent.connect_mcp_server(
    "OpentronsAI",
    command=["npx", "mcp-remote",
            "https://opentrons-opentronsai-mcp-server.hf.space/gradio_api/mcp/"]
)
print(f"Connected OpentronsAI: {n_tools} tools available")

# In autonomous mode, a single chat call can chain the entire pipeline:
# plan generation → protocol design → data analysis → optimization
response = agent.chat("Start the campaign")
