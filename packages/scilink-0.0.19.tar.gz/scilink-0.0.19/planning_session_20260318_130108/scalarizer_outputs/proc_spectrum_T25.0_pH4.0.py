import sys
import json
import pandas as pd
import numpy as np
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

try:
    # Accept file path as command-line argument
    if len(sys.argv) > 1:
        data_path = sys.argv[1]
    else:
        data_path = "/Users/maxim.ziatdinov/Code/SciLink/planning_session_20260318_130108/data/spectrum_T25.0_pH4.0.csv"

    # Read data
    df = pd.read_csv(data_path)

    # Load sidecar JSON dynamically
    sidecar_path = Path(data_path).with_suffix('.json')
    sidecar_conditions = {}
    if sidecar_path.exists():
        with open(sidecar_path) as f:
            sidecar_conditions = json.load(f)

    # Extract columns
    wavelength = df['wavelength_nm'].values
    absorbance = df['absorbance'].values

    # Calculate peak absorbance and peak wavelength
    peak_idx = np.argmax(absorbance)
    peak_absorbance = float(absorbance[peak_idx])
    peak_wavelength = float(wavelength[peak_idx])

    # Calculate integrated absorbance (area under the curve)
    # Sort by wavelength to ensure proper integration
    sort_idx = np.argsort(wavelength)
    wavelength_sorted = wavelength[sort_idx]
    absorbance_sorted = absorbance[sort_idx]
    integrated_absorbance = float(np.trapezoid(absorbance_sorted, wavelength_sorted))

    # Build metrics: sidecar conditions + derived targets
    metrics = {
        **sidecar_conditions,
        "Peak_Absorbance": peak_absorbance,
        "Peak_Wavelength_nm": peak_wavelength,
        "Integrated_Absorbance": integrated_absorbance
    }

    # Generate plot
    output_dir = Path("/Users/maxim.ziatdinov/Code/SciLink/planning_session_20260318_130108/scalarizer_outputs")
    output_dir.mkdir(parents=True, exist_ok=True)
    plot_path = output_dir / f"debug_{Path(data_path).stem}.png"

    fig, ax = plt.subplots(1, 1, figsize=(8, 5))

    # Plot spectrum and shade the area under the curve
    ax.fill_between(wavelength_sorted, absorbance_sorted, alpha=0.3, color='steelblue',
                     label=f'Integrated Area = {integrated_absorbance:.4f}')
    ax.plot(wavelength_sorted, absorbance_sorted, color='steelblue', linewidth=1.0)

    # Mark the peak
    ax.plot(peak_wavelength, peak_absorbance, 'rv', markersize=12,
            label=f'Peak: {peak_absorbance:.4f} @ {peak_wavelength:.1f} nm')
    ax.axvline(peak_wavelength, color='red', linestyle='--', alpha=0.4)

    # Labels and title
    cond_str = ', '.join(f'{k}={v}' for k, v in sidecar_conditions.items())
    ax.set_title(f'UV-Vis Spectrum ({cond_str})\nPeak={peak_absorbance:.4f}, λ={peak_wavelength:.1f} nm, Area={integrated_absorbance:.4f}',
                 fontsize=10)
    ax.set_xlabel('Wavelength (nm)')
    ax.set_ylabel('Absorbance')
    ax.legend(loc='best', fontsize=9)
    ax.set_xlim(wavelength_sorted[0], wavelength_sorted[-1])
    plt.tight_layout()
    fig.savefig(str(plot_path), dpi=150)
    plt.close(fig)

    # Output JSON
    result = {
        "metrics": metrics,
        "plot_path": str(plot_path)
    }
    print(json.dumps(result))

except Exception as e:
    error_result = {
        "metrics": None,
        "plot_path": None,
        "error": str(e)
    }
    print(json.dumps(error_result))
