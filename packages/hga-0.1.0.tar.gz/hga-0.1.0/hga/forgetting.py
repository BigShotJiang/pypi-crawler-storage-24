"""Salience-Guided Forgetting — Principled memory lifecycle management.

Computes salience scores for memory items and neurons, then applies
lifecycle actions: keep, summarize, migrate (cold storage), or delete.

Privacy guard: Restricted/Sensitive items are NEVER deleted, only migrated.
All operations are LLM-free.
"""

import logging
import math
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Dict, List, Optional, Tuple, TYPE_CHECKING

if TYPE_CHECKING:
    from .l2.vault import DeterministicVault, DVRecord, PolicyTag
    from .l3.matcher import NeuronMatcher
    from .l3.neuron import DecisionNeuron
    from .storage.sqlite_backend import SQLiteBackend

logger = logging.getLogger("hga.forgetting")


# ─── Salience Scoring ──────────────────────────────────────────────────────

# Lifecycle thresholds
KEEP_THRESHOLD = 0.7
SUMMARIZE_THRESHOLD = 0.4
MIGRATE_THRESHOLD = 0.15

# Salience weights
RECENCY_WEIGHT = 0.4
FREQUENCY_WEIGHT = 0.3
IMPORTANCE_WEIGHT = 0.3

# Recency decay (hours)
RECENCY_DECAY = 0.01  # exp(-decay * hours)

# Neuron forgetting thresholds (seconds)
NEURON_PRUNE_IDLE = 86400       # 24 hours: prune Stage 0 with 0 hits
NEURON_DEMOTE_IDLE = 43200      # 12 hours: demote Stage 1
NEURON_DEMOTE_MATURE_IDLE = 86400  # 24 hours: demote Stage 2+


@dataclass
class SalienceScore:
    """Computed salience for a memory item."""
    item_id: str
    recency: float = 0.0
    frequency: float = 0.0
    importance: float = 0.0
    salience: float = 0.0
    action: str = "keep"  # "keep" | "summarize" | "migrate" | "delete"


@dataclass
class ForgettingResult:
    """Summary of a forgetting cycle."""
    items_scored: int = 0
    items_kept: int = 0
    items_summarized: int = 0
    items_migrated: int = 0
    items_deleted: int = 0
    neurons_pruned: int = 0
    neurons_demoted: int = 0
    privacy_protected: int = 0
    duration_ms: float = 0.0


class SalienceScorer:
    """Computes salience scores for memory items."""

    def __init__(
        self,
        recency_decay: float = RECENCY_DECAY,
        keep_threshold: float = KEEP_THRESHOLD,
        summarize_threshold: float = SUMMARIZE_THRESHOLD,
        migrate_threshold: float = MIGRATE_THRESHOLD,
    ):
        self.recency_decay = recency_decay
        self.keep_threshold = keep_threshold
        self.summarize_threshold = summarize_threshold
        self.migrate_threshold = migrate_threshold

    def compute_salience(
        self,
        item_id: str,
        last_accessed: Optional[str],
        access_count: int,
        max_access_count: int,
        importance: float = 0.0,
        has_dv_pointer: bool = False,
        high_access: bool = False,
        user_importance: Optional[float] = None,
    ) -> SalienceScore:
        """Compute salience for a memory item.

        Salience = 0.4 * recency + 0.3 * frequency + 0.3 * importance

        Args:
            item_id: Item identifier.
            last_accessed: ISO timestamp of last access (or created_at).
            access_count: Number of times accessed.
            max_access_count: Maximum access count across all items.
            importance: Base importance score [0, 1].
            has_dv_pointer: Item has a DV record → +0.3 importance.
            high_access: High access count → +0.2 importance.
            user_importance: User-tagged importance overrides auto.
        """
        # Recency: exp(-decay * hours_since_access)
        hours = self._hours_since(last_accessed)
        recency = math.exp(-self.recency_decay * hours)

        # Frequency: log1p(access_count) / log1p(max_count)
        max_count = max(max_access_count, 1)
        frequency = math.log1p(access_count) / math.log1p(max_count)

        # Importance: auto-computed or user-tagged
        if user_importance is not None:
            imp = user_importance
        else:
            imp = importance
            if has_dv_pointer:
                imp += 0.3
            if high_access:
                imp += 0.2
            imp = min(imp, 1.0)

        salience = (
            RECENCY_WEIGHT * recency +
            FREQUENCY_WEIGHT * frequency +
            IMPORTANCE_WEIGHT * imp
        )

        action = self._decide_action(salience, imp)

        return SalienceScore(
            item_id=item_id,
            recency=recency,
            frequency=frequency,
            importance=imp,
            salience=salience,
            action=action,
        )

    def _decide_action(self, salience: float, importance: float) -> str:
        """Determine lifecycle action based on salience."""
        if salience >= self.keep_threshold:
            return "keep"
        elif salience >= self.summarize_threshold:
            return "summarize"
        elif salience >= self.migrate_threshold:
            return "migrate"
        else:
            # Only delete if importance is 0
            if importance <= 0:
                return "delete"
            return "migrate"

    @staticmethod
    def _hours_since(timestamp: Optional[str]) -> float:
        """Compute hours since a timestamp."""
        if timestamp is None:
            return 0.0
        try:
            # Parse ISO format
            if timestamp.endswith("Z"):
                timestamp = timestamp[:-1] + "+00:00"
            if "+" not in timestamp and "T" in timestamp:
                # Assume UTC
                dt = datetime.fromisoformat(timestamp).replace(tzinfo=timezone.utc)
            else:
                dt = datetime.fromisoformat(timestamp)
            now = datetime.now(timezone.utc)
            delta = now - dt
            return max(delta.total_seconds() / 3600.0, 0.0)
        except (ValueError, TypeError):
            return 0.0


class MemoryForgetting:
    """Applies salience-guided forgetting to the memory system.

    Privacy guard: items with Restricted or Sensitive policy tags
    are NEVER deleted, only migrated to cold storage.
    """

    # Policy tags that prevent deletion
    PROTECTED_TAGS = {"restricted", "sensitive"}

    def __init__(self, scorer: Optional[SalienceScorer] = None):
        self.scorer = scorer or SalienceScorer()

    def can_delete(self, policy_tag: str) -> bool:
        """Check if an item with this policy tag can be deleted.

        Restricted and Sensitive items are NEVER deleted.
        """
        return policy_tag.lower() not in self.PROTECTED_TAGS

    def run_forgetting_cycle(
        self,
        storage: "SQLiteBackend",
        vault: "DeterministicVault",
        matcher: "NeuronMatcher",
    ) -> ForgettingResult:
        """Run a full salience-guided forgetting cycle.

        1. Score all memory items
        2. Apply lifecycle actions (keep/summarize/migrate/delete)
        3. Forget idle neurons (prune/demote)

        All operations are LLM-free.
        """
        start = time.time()
        result = ForgettingResult()

        # 1. Score and apply lifecycle to memory items
        self._process_items(storage, vault, result)

        # 2. Forget idle neurons
        self._forget_neurons(matcher, storage, result)

        result.duration_ms = (time.time() - start) * 1000
        logger.info(
            f"Forgetting cycle: {result.duration_ms:.1f}ms, "
            f"kept={result.items_kept}, summarized={result.items_summarized}, "
            f"migrated={result.items_migrated}, deleted={result.items_deleted}, "
            f"neurons_pruned={result.neurons_pruned}, neurons_demoted={result.neurons_demoted}"
        )
        return result

    def _process_items(
        self,
        storage: "SQLiteBackend",
        vault: "DeterministicVault",
        result: ForgettingResult,
    ) -> None:
        """Score all items and apply lifecycle actions."""
        items = storage.get_all_items()
        if not items:
            return

        # Compute max access count for frequency normalization
        max_access = max(
            (item.get("metadata", {}).get("access_count", 0) for item in items),
            default=1,
        )

        # Collect DV keys for pointer check
        dv_keys = set(vault._local.keys())

        scores = []
        for item in items:
            meta = item.get("metadata", {})
            access_count = meta.get("access_count", 0)
            last_accessed = meta.get("last_accessed", item.get("created_at"))
            importance = meta.get("importance", 0.0)
            user_importance = meta.get("user_importance")
            has_dv = item["id"] in dv_keys
            high_access = access_count > max_access * 0.7

            score = self.scorer.compute_salience(
                item_id=item["id"],
                last_accessed=last_accessed,
                access_count=access_count,
                max_access_count=max_access,
                importance=importance,
                has_dv_pointer=has_dv,
                high_access=high_access,
                user_importance=user_importance,
            )
            scores.append((item, score))

        result.items_scored = len(scores)

        for item, score in scores:
            # Privacy guard: check DV policy tag
            policy_tag = self._get_policy_tag(item, vault)

            if score.action == "keep":
                result.items_kept += 1
            elif score.action == "summarize":
                # In LLM-free mode, we just mark for summarization
                # (actual summary generation would need LLM, so we keep as-is
                #  but flag in metadata)
                self._mark_summarized(storage, item)
                result.items_summarized += 1
            elif score.action == "migrate":
                self._migrate_to_cold(storage, item)
                result.items_migrated += 1
            elif score.action == "delete":
                if not self.can_delete(policy_tag):
                    # Privacy guard: migrate instead of delete
                    self._migrate_to_cold(storage, item)
                    result.items_migrated += 1
                    result.privacy_protected += 1
                else:
                    self._delete_item(storage, item)
                    result.items_deleted += 1

    def _get_policy_tag(self, item: Dict, vault: "DeterministicVault") -> str:
        """Get the DV policy tag for an item, if any."""
        record = vault._local.get(item["id"])
        if record:
            return record.policy_tag.value if hasattr(record.policy_tag, 'value') else str(record.policy_tag)
        return "public"

    def _mark_summarized(self, storage: "SQLiteBackend", item: Dict) -> None:
        """Mark an item as summarized in metadata."""
        meta = item.get("metadata", {})
        meta["summarized"] = True
        storage.conn.execute(
            "UPDATE items SET metadata = ? WHERE id = ?",
            (self._json_meta(meta), item["id"])
        )
        storage.conn.commit()

    def _migrate_to_cold(self, storage: "SQLiteBackend", item: Dict) -> None:
        """Move item to cold storage table."""
        # Ensure cold storage table exists
        storage.conn.execute("""
            CREATE TABLE IF NOT EXISTS cold_items (
                id TEXT PRIMARY KEY,
                text TEXT NOT NULL,
                embedding BLOB NOT NULL,
                metadata TEXT DEFAULT '{}',
                sensitivity TEXT DEFAULT 'low',
                created_at TIMESTAMP,
                migrated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        # Insert into cold storage
        row = storage.conn.execute(
            "SELECT * FROM items WHERE id = ?", (item["id"],)
        ).fetchone()
        if row:
            storage.conn.execute(
                """INSERT OR REPLACE INTO cold_items
                   (id, text, embedding, metadata, sensitivity, created_at)
                   VALUES (?, ?, ?, ?, ?, ?)""",
                (row["id"], row["text"], row["embedding"],
                 row["metadata"], row["sensitivity"], row["created_at"])
            )
            # Remove from hot storage
            storage.conn.execute("DELETE FROM items WHERE id = ?", (item["id"],))
            storage.conn.commit()

    def _delete_item(self, storage: "SQLiteBackend", item: Dict) -> None:
        """Permanently delete an item."""
        storage.conn.execute("DELETE FROM items WHERE id = ?", (item["id"],))
        storage.conn.commit()

    def _forget_neurons(
        self,
        matcher: "NeuronMatcher",
        storage: "SQLiteBackend",
        result: ForgettingResult,
    ) -> None:
        """Prune or demote idle neurons.

        - Stage 0 with 0 hits and idle > prune_threshold → delete
        - Stage 1 idle > demote_threshold → demote to Stage 0, halve edge weight
        - Stage 2+ idle > demote_threshold * 2 → demote by 1 (min Stage 1)
        """
        now = time.time()
        neurons_to_remove = []

        for neuron in matcher.get_all_neurons():
            idle_seconds = self._neuron_idle_seconds(neuron, now)

            if neuron.stage == 0 and neuron.hit_count == 0:
                if idle_seconds > NEURON_PRUNE_IDLE:
                    neurons_to_remove.append(neuron.id)
                    result.neurons_pruned += 1

            elif neuron.stage == 1:
                if idle_seconds > NEURON_DEMOTE_IDLE:
                    neuron.stage = 0
                    neuron.edge_weight *= 0.5
                    result.neurons_demoted += 1

            elif neuron.stage >= 2:
                if idle_seconds > NEURON_DEMOTE_MATURE_IDLE:
                    neuron.stage = max(neuron.stage - 1, 1)
                    result.neurons_demoted += 1

        for nid in neurons_to_remove:
            matcher.remove_neuron(nid)
            storage.delete_neuron(nid)

    @staticmethod
    def _neuron_idle_seconds(neuron, now: float) -> float:
        """Compute seconds since neuron was last fired."""
        try:
            last = neuron.last_fired
            if isinstance(last, str):
                dt = datetime.fromisoformat(last)
                if dt.tzinfo is None:
                    dt = dt.replace(tzinfo=timezone.utc)
                return now - dt.timestamp()
            return 0.0
        except (ValueError, TypeError):
            return 0.0

    @staticmethod
    def _json_meta(meta: Dict) -> str:
        import json
        return json.dumps(meta)


def recover_from_cold(storage: "SQLiteBackend", item_id: str) -> Optional[Dict]:
    """Recover a migrated item from cold storage back to hot storage.

    Returns the recovered item dict, or None if not found.
    """
    row = storage.conn.execute(
        "SELECT * FROM cold_items WHERE id = ?", (item_id,)
    ).fetchone()
    if row is None:
        return None

    # Move back to hot storage
    storage.conn.execute(
        """INSERT OR REPLACE INTO items
           (id, text, embedding, metadata, sensitivity, created_at)
           VALUES (?, ?, ?, ?, ?, ?)""",
        (row["id"], row["text"], row["embedding"],
         row["metadata"], row["sensitivity"], row["created_at"])
    )
    storage.conn.execute("DELETE FROM cold_items WHERE id = ?", (item_id,))
    storage.conn.commit()

    return {
        "id": row["id"],
        "text": row["text"],
        "sensitivity": row["sensitivity"],
    }
