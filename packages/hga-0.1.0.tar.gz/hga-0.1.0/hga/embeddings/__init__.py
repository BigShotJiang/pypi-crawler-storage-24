from .local import LocalEmbeddings

__all__ = ["LocalEmbeddings"]
