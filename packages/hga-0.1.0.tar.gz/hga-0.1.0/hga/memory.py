"""AgentMemory — Single entry point for HGA memory system.

Usage:
    from hga import AgentMemory

    mem = AgentMemory()
    mem.add("User prefers dark mode")
    mem.add("TX-4821: payment $240", sensitivity="high")
    result = mem.recall("what does user prefer?")

    # Sprint 3: Decision chain capture
    mem.record_decision(
        query="İstanbul'da hava nasıl?",
        decision_chain={"classification": "weather_lookup", "tool": "get_weather",
                        "slots": {"city": {"value": "Istanbul", "extracted_from": "query"}}},
        outcome="success"
    )
"""

import json
import re
import uuid
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

import numpy as np

from .embeddings.local import LocalEmbeddings
from .l1.codebook import Codebook
from .l1.drift import DriftMonitor
from .l1.retrieval import L1Retriever, L1Result
from .l1.filtering import filter_by_score
from .l2.vault import DeterministicVault, detect_sensitivity, PolicyTag
from .gate.governance import GovernanceGate, GateDecision, ExecutionPath, L3Signal
from .l3.neuron import (
    DecisionNeuron, DecisionChain, DecisionStep, SlotRule,
    create_neuron, create_multi_step_neuron, get_task_family,
)
from .l3.matcher import NeuronMatcher
from .l3.replay import DecisionReplay, ReplayResult
from .consolidation import PassiveConsolidation, ConsolidationResult
from .forgetting import recover_from_cold, ForgettingResult
from .storage.sqlite_backend import SQLiteBackend


@dataclass
class RecallResult:
    """Result from mem.recall()."""
    text: Optional[str] = None
    payload: Any = None
    source: str = "none"         # "L1", "L2", "L3", "none"
    confidence: float = 0.0
    exact: bool = False
    path: str = "Stage0Path"     # ExecutionPath value
    llm_needed: bool = True
    reason: str = ""             # gate decision explanation
    neuron_id: Optional[str] = None
    tool_call: Optional[Dict] = None  # {"name": str, "args": {}} from L3 replay
    verify_prompt: Optional[str] = None  # VerifyPath: "Proposed: tool(args). Correct?"
    items: List[Dict] = field(default_factory=list)
    context: List[Dict] = field(default_factory=list)  # items to send to LLM


class AgentMemory:
    """Unified memory interface. Zero-config: just instantiate and use."""

    def __init__(
        self,
        db_path: str = "hga_memory.db",
        embedding_model: str = "all-MiniLM-L6-v2",
        n_probes: int = 3,
        score_threshold: float = 0.3,
        alpha: float = 0.6,
        delta_min: float = 0.01,
        neuron_match_threshold: float = 0.60,
    ):
        # Storage
        self._storage = SQLiteBackend(db_path)

        # Embeddings
        self._embedder = LocalEmbeddings(embedding_model)

        # L1: semantic retrieval
        self._codebook = Codebook(dim=self._embedder.dim)
        self._retriever = L1Retriever(
            self._codebook,
            n_probes=n_probes,
            score_threshold=score_threshold,
        )

        # L2: exact store
        self._vault = DeterministicVault(storage_backend=self._storage)

        # L3: decision neurons + replay
        self._matcher = NeuronMatcher(match_threshold=neuron_match_threshold)
        self._replay = DecisionReplay(embedder=self._embedder)

        # Gate
        self._gate = GovernanceGate(alpha=alpha, delta_min=delta_min)

        # Drift monitor (Sprint 9)
        self._drift = DriftMonitor()
        self._query_count = 0  # for adaptation interval

        # Passive consolidation (Sprint 10) + forgetting (Sprint 11)
        self._consolidation = PassiveConsolidation(forgetting_enabled=False)

        # Load existing data
        self._load_from_storage()

        # Cache for L3 match result (used between _get_l3_signal and _build_result)
        self._last_l3_match: Optional[tuple] = None  # (neuron, similarity)

        # Stats
        self._stats = {
            "total_adds": 0,
            "total_recalls": 0,
            "total_decisions": 0,
            "l1_hits": 0,
            "l2_hits": 0,
            "l3_hits": 0,
            "misses": 0,
            "paths": {p.value: 0 for p in ExecutionPath},
        }

    def _load_from_storage(self) -> None:
        """Restore L1 + L3 state from persisted data."""
        # L1
        items = self._storage.get_all_items()
        if items:
            ids = [item["id"] for item in items]
            embeddings = np.array([item["embedding"] for item in items], dtype=np.float32)
            self._codebook.fit(embeddings, ids)
            for item in items:
                self._retriever.register_item(
                    item["id"], item["text"], item["embedding"], item.get("metadata", {})
                )

        # L3 neurons
        neuron_jsons = self._storage.get_all_neurons()
        for nj in neuron_jsons:
            data = json.loads(nj)
            neuron = DecisionNeuron.from_dict(data)
            self._matcher.add_neuron(neuron)

    # ─── Public API ──────────────────────────────────────────────────────────

    def add(self, text: str, sensitivity: Optional[str] = None,
            key: Optional[str] = None, policy_tag: str = "public",
            metadata: Optional[Dict] = None) -> str:
        """Store a memory item."""
        if sensitivity is None:
            sensitivity = detect_sensitivity(text)

        item_id = key or str(uuid.uuid4())[:12]
        meta = metadata or {}

        if sensitivity == "high":
            self._vault.write(item_id, text, policy_tag=policy_tag, metadata=meta)

        embedding = self._embedder.encode(text)
        self._storage.insert_item(item_id, text, embedding, meta, sensitivity)
        self._codebook.add(item_id, embedding)
        self._retriever.register_item(item_id, text, embedding, meta)

        self._stats["total_adds"] += 1
        return item_id

    def recall(self, query: str, top_k: int = 5) -> RecallResult:
        """Recall from memory. Gate routes between L1/L2/L3 paths."""
        self._stats["total_recalls"] += 1

        # Gather signals
        l2_record = self._find_l2(query)
        l1_result = self._try_l1(query, top_k)
        l3_signal = self._get_l3_signal(query)

        # Gate decision
        decision = self._gate.decide(
            query=query,
            l1_result=l1_result,
            l2_record=l2_record,
            l3_signal=l3_signal,
        )

        self._stats["paths"][decision.path.value] += 1
        return self._build_result(decision, l1_result, l2_record, query=query)

    def record_decision(
        self,
        query: str,
        decision_chain: Dict,
        outcome: str = "success",
        source: str = "experience",
    ) -> Optional[str]:
        """Record a decision (tool call) for L3 neuron learning.

        Args:
            query: The original query text.
            decision_chain: Dict with keys:
                - classification: str (task type, e.g. "weather_lookup")
                - tool: str (tool name, e.g. "get_weather")
                - slots: Dict[str, Dict] with each slot having:
                    - value: the extracted value
                    - extracted_from: "query" | "context" | "l2"
            outcome: "success" or "failure"
            source: "experience", "theoretical", or "prompt"

        Returns:
            Neuron ID (new or updated).
        """
        self._stats["total_decisions"] += 1

        classification = decision_chain.get("classification", "unknown")
        tool = decision_chain.get("tool", "unknown")
        slots_raw = decision_chain.get("slots", {})

        query_embedding = self._embedder.encode(query)

        # Try to match to existing neuron
        match_result = self._matcher.match_or_classify(
            query_embedding, classification=classification
        )
        matched_neuron, similarity, is_new = match_result

        if is_new or matched_neuron is None:
            # Try exploration transfer before creating from scratch
            transferred = self._matcher.attempt_transfer(
                query_embedding, classification
            )
            if transferred is not None:
                # Warm-started neuron — add slot examples and record outcome
                for slot_name, slot_info in slots_raw.items():
                    value = slot_info.get("value", "")
                    if value:
                        transferred.add_slot_example(slot_name, query, value)
                transferred.update_outcome(outcome, source)
                alive = self._matcher.update_provisional(transferred, outcome)
                if alive:
                    self._persist_neuron(transferred)
                else:
                    self._storage.delete_neuron(transferred.id)
                return transferred.id

            # No transfer candidate — create new neuron from scratch
            slot_rules = {}
            for slot_name, slot_info in slots_raw.items():
                rule = SlotRule(
                    name=slot_name,
                    extraction=f"from_{slot_info.get('extracted_from', 'query')}",
                    examples=[(query, slot_info.get("value", ""))],
                )
                slot_rules[slot_name] = rule

            neuron = create_neuron(
                classification=classification,
                tool=tool,
                query_embedding=query_embedding,
                slots=slot_rules,
            )
            neuron.update_outcome(outcome, source)
            self._matcher.add_neuron(neuron)
            self._persist_neuron(neuron)
            return neuron.id

        else:
            # Update existing neuron
            neuron = matched_neuron
            neuron.update_centroid(query_embedding)
            neuron.add_exemplar(query_embedding)
            neuron.update_outcome(outcome, source)

            # Handle provisional lifecycle
            if neuron.provisional:
                alive = self._matcher.update_provisional(neuron, outcome)
                if not alive:
                    self._storage.delete_neuron(neuron.id)
                    return neuron.id

            # Add slot examples
            for slot_name, slot_info in slots_raw.items():
                value = slot_info.get("value", "")
                if value:
                    neuron.add_slot_example(slot_name, query, value)

            # Infer patterns from accumulated examples
            self._infer_slot_patterns(neuron)

            self._persist_neuron(neuron)
            return neuron.id

    def record_multi_step_decision(
        self,
        query: str,
        steps: List[Dict],
        classification: str,
        outcome: str = "success",
        source: str = "experience",
    ) -> Optional[str]:
        """Record a multi-step decision chain for L3 neuron learning.

        Args:
            query: The original query text.
            steps: List of step dicts, each with:
                - tool: str (tool name)
                - args: Dict[str, Any] (arguments used)
                - result: Any (step output, optional)
                - depends_on: List[int] (step indices this depends on, optional)
            classification: Task type (e.g. "compare_products").
            outcome: "success" or "failure"
            source: "experience", "theoretical", or "prompt"

        Returns:
            Neuron ID (new or updated).
        """
        self._stats["total_decisions"] += 1
        query_embedding = self._embedder.encode(query)

        # Infer DecisionSteps with dependencies and slot sources
        decision_steps = []
        query_slots = {}  # slots extracted from the query

        for i, step_data in enumerate(steps):
            tool = step_data.get("tool", "unknown")
            args = step_data.get("args", {})
            depends = step_data.get("depends_on", [])
            action = step_data.get("action", "tool_call")
            output_key = step_data.get("output_key", f"step_{i}")

            # Infer slot sources: if arg value is a string from query → from_query
            # If arg value references a prior step's output → from_step:N
            slot_sources = {}
            for arg_name, arg_val in args.items():
                if isinstance(arg_val, str) and arg_val in query:
                    slot_sources[arg_name] = "from_query"
                    # Track query-level slots
                    if arg_name not in query_slots:
                        query_slots[arg_name] = SlotRule(
                            name=arg_name,
                            extraction="from_query",
                            examples=[(query, arg_val)],
                        )
                elif isinstance(arg_val, str) and arg_val.startswith("<step"):
                    # Explicit step reference like "<step0>"
                    slot_sources[arg_name] = f"from_step:{arg_val}"
                else:
                    # Check if any prior step could have produced this
                    for dep_idx in depends:
                        slot_sources[arg_name] = f"from_step:{dep_idx}"
                        break
                    else:
                        slot_sources[arg_name] = "from_query"
                        if arg_name not in query_slots and isinstance(arg_val, str):
                            query_slots[arg_name] = SlotRule(
                                name=arg_name,
                                extraction="from_query",
                                examples=[(query, arg_val)],
                            )

            decision_steps.append(DecisionStep(
                tool=tool,
                step_id=i,
                action=action,
                depends_on=depends,
                output_key=output_key,
                slot_sources=slot_sources,
            ))

        # Try to match to existing neuron
        match_result = self._matcher.match_or_classify(
            query_embedding, classification=classification
        )
        matched_neuron, similarity, is_new = match_result

        if is_new or matched_neuron is None:
            # Try exploration transfer first
            transferred = self._matcher.attempt_transfer(
                query_embedding, classification
            )
            if transferred is not None:
                for slot_name, rule in query_slots.items():
                    for q, v in rule.examples:
                        if v:
                            transferred.add_slot_example(slot_name, q, v)
                transferred.update_outcome(outcome, source)
                alive = self._matcher.update_provisional(transferred, outcome)
                if alive:
                    self._persist_neuron(transferred)
                else:
                    self._storage.delete_neuron(transferred.id)
                return transferred.id

            neuron = create_multi_step_neuron(
                classification=classification,
                steps=decision_steps,
                query_embedding=query_embedding,
                slots=query_slots,
            )
            neuron.update_outcome(outcome, source)
            self._matcher.add_neuron(neuron)
            self._persist_neuron(neuron)
            return neuron.id
        else:
            neuron = matched_neuron
            neuron.update_centroid(query_embedding)
            neuron.add_exemplar(query_embedding)
            neuron.update_outcome(outcome, source)

            if neuron.provisional:
                alive = self._matcher.update_provisional(neuron, outcome)
                if not alive:
                    self._storage.delete_neuron(neuron.id)
                    return neuron.id

            # Add query-level slot examples
            for slot_name, rule in query_slots.items():
                for q, v in rule.examples:
                    if v:
                        neuron.add_slot_example(slot_name, q, v)

            self._infer_slot_patterns(neuron)
            self._persist_neuron(neuron)
            return neuron.id

    def get_neuron(self, neuron_id: str) -> Optional[DecisionNeuron]:
        """Get a neuron by ID."""
        return self._matcher.get_neuron(neuron_id)

    def get_neurons(self, classification: Optional[str] = None) -> List[DecisionNeuron]:
        """Get all neurons, optionally filtered by classification."""
        if classification:
            return self._matcher.get_by_classification(classification)
        return self._matcher.get_all_neurons()

    def search(self, query: str, top_k: int = 5) -> List[Dict]:
        """Search both L1 and L2, return merged results."""
        results = []

        dv_results = self._vault.search(query)
        for r in dv_results:
            results.append({
                "text": r.payload if isinstance(r.payload, str) else str(r.payload),
                "key": r.key,
                "source": "L2",
                "exact": True,
                "score": 1.0,
            })

        if self._codebook.fitted:
            emb = self._embedder.encode(query)
            l1 = self._retriever.query(emb)
            for r in l1.results[:top_k]:
                results.append({
                    "text": r.text,
                    "id": r.item_id,
                    "source": "L1",
                    "exact": False,
                    "score": r.score,
                })

        results.sort(key=lambda x: x["score"], reverse=True)
        return results[:top_k]

    @property
    def gate(self) -> GovernanceGate:
        return self._gate

    @property
    def matcher(self) -> NeuronMatcher:
        return self._matcher

    @property
    def drift_monitor(self) -> DriftMonitor:
        return self._drift

    @property
    def stats(self) -> Dict:
        return {
            **self._stats,
            "item_count": self._storage.item_count(),
            "dv_count": self._vault.count,
            "neuron_count": self._matcher.neuron_count,
            "codebook_k": self._codebook.K,
            "codebook_fitted": self._codebook.fitted,
            "drift": self._drift.get_stats(),
        }

    def run_passive_consolidation(self) -> ConsolidationResult:
        """Run a passive consolidation cycle (LLM-free).

        Call between sessions or during idle time.
        Includes forgetting if enabled via enable_forgetting().
        """
        return self._consolidation.run_passive_cycle(
            matcher=self._matcher,
            vault=self._vault,
            codebook=self._codebook,
            drift=self._drift,
            storage=self._storage,
        )

    def enable_forgetting(self, enabled: bool = True) -> None:
        """Enable or disable salience-guided forgetting during passive consolidation."""
        self._consolidation.forgetting_enabled = enabled

    def recover_cold_item(self, item_id: str) -> Optional[Dict]:
        """Recover a migrated item from cold storage back to hot storage."""
        result = recover_from_cold(self._storage, item_id)
        if result:
            # Re-register in L1
            item = self._storage.get_item(item_id)
            if item:
                self._codebook.add(item_id, item["embedding"])
                self._retriever.register_item(
                    item_id, item["text"], item["embedding"], item.get("metadata", {})
                )
        return result

    @property
    def consolidation(self) -> PassiveConsolidation:
        return self._consolidation

    def print_stats(self) -> None:
        s = self.stats
        print(f"=== HGA Memory Stats ===")
        print(f"Items: {s['item_count']} (L1) | {s['dv_count']} (L2/DV) | {s['neuron_count']} neurons (L3)")
        print(f"Codebook: K={s['codebook_k']}, fitted={s['codebook_fitted']}")
        print(f"Recalls: {s['total_recalls']} | Decisions recorded: {s['total_decisions']}")
        print(f"  L1: {s['l1_hits']}, L2: {s['l2_hits']}, L3: {s['l3_hits']}, miss: {s['misses']}")
        print(f"Path distribution:")
        for path, count in s["paths"].items():
            if count > 0:
                print(f"  {path}: {count}")
        # Neuron stages
        neurons = self._matcher.get_all_neurons()
        if neurons:
            stages = {}
            for n in neurons:
                stages[n.stage] = stages.get(n.stage, 0) + 1
            print(f"Neuron stages: {stages}")

    # ─── Internal ────────────────────────────────────────────────────────────

    def _find_l2(self, query: str):
        record = self._vault.read(query)
        if record:
            return record
        if self._has_l2_pattern(query):
            results = self._vault.search(query)
            if results:
                return results[0]
        return None

    def _try_l1(self, query: str, top_k: int = 5) -> L1Result:
        if not self._codebook.fitted:
            return L1Result(results=[], confidence=0.0, margin=0.0, top_centroid=-1)
        emb = self._embedder.encode(query)
        result = self._retriever.query(emb)
        result.results = result.results[:top_k]

        # Drift monitoring + EMA update (Sprint 9)
        self._query_count += 1
        if self._codebook.fitted:
            cid, qerr = self._codebook.encode(emb)
            margin = self._codebook.margin(emb)
            self._drift.record(qerr, margin)
            # EMA update on every query (cheap)
            self._codebook.ema_update(cid, emb)
            # Periodic adaptation
            if self._query_count % self._codebook.UPDATE_INTERVAL == 0:
                self._codebook.run_adaptation()

        return result

    # Soft-match threshold: below matcher threshold but still informative
    _SOFT_MATCH_THRESHOLD = 0.45

    def _get_l3_signal(self, query: str) -> L3Signal:
        """Get real L3 neuron signal for the gate.

        Uses strict match first. If no strict match, falls back to a soft
        match (closest neuron above _SOFT_MATCH_THRESHOLD) to give the gate
        more information — prevents Stage0 for queries that are close to
        known patterns but phrased differently (e.g. "Don't let me forget to X"
        vs "Remind me to X").
        """
        self._last_l3_match = None

        if self._matcher.neuron_count == 0:
            return L3Signal()

        emb = self._embedder.encode(query)

        # Strict match
        result = self._matcher.match(emb)
        if result is not None:
            neuron, similarity = result
            self._last_l3_match = (neuron, similarity)
            self._consolidation.record_probe(neuron.id)
            return L3Signal(
                neuron_id=neuron.id,
                stage=neuron.stage,
                edge_weight=neuron.edge_weight,
                task_type=neuron.classification,
                similarity=similarity,
            )

        # Soft match: find closest neuron even below strict threshold
        similar = self._matcher.find_similar(emb, top_k=1)
        if similar:
            neuron, similarity = similar[0]
            if similarity >= self._SOFT_MATCH_THRESHOLD:
                self._last_l3_match = (neuron, similarity)
                return L3Signal(
                    neuron_id=neuron.id,
                    stage=neuron.stage,
                    edge_weight=neuron.edge_weight,
                    task_type=neuron.classification,
                    similarity=similarity,
                )

        return L3Signal()

    def _build_result(self, decision: GateDecision, l1_result: L1Result,
                      l2_record, query: str = "") -> RecallResult:
        if decision.path == ExecutionPath.DETERMINISTIC:
            self._stats["l2_hits"] += 1
            payload = decision.l2_record["payload"] if decision.l2_record else None
            text = payload if isinstance(payload, str) else None
            return RecallResult(
                text=text,
                payload=payload,
                source="L2",
                confidence=1.0,
                exact=True,
                path=decision.path.value,
                llm_needed=False,
                reason=decision.reason,
                neuron_id=decision.neuron_id,
            )

        # Stage3Path or VerifyPath — attempt L3 replay
        if decision.path in (ExecutionPath.STAGE3, ExecutionPath.VERIFY):
            replay_result = self._try_replay(query, decision)
            if replay_result is not None:
                return replay_result

        if decision.path in (ExecutionPath.FAST_SEMANTIC, ExecutionPath.VERIFY,
                             ExecutionPath.STAGE3):
            if l1_result.results:
                self._stats["l1_hits"] += 1
                best = l1_result.results[0]
                return RecallResult(
                    text=best.text,
                    source="L1",
                    confidence=best.score,
                    exact=False,
                    path=decision.path.value,
                    llm_needed=decision.llm_needed,
                    reason=decision.reason,
                    neuron_id=decision.neuron_id,
                    items=[{"text": r.text, "score": r.score, "id": r.item_id}
                           for r in l1_result.results],
                    context=decision.context,
                )

        # Stage0Path or no results
        self._stats["misses"] += 1
        return RecallResult(
            source="none",
            confidence=decision.confidence,
            path=decision.path.value,
            llm_needed=True,
            reason=decision.reason,
            neuron_id=decision.neuron_id,
            context=decision.context,
        )

    def _try_replay(self, query: str, decision: GateDecision) -> Optional[RecallResult]:
        """Attempt L3 decision replay. Returns RecallResult or None to fallback."""
        if not self._last_l3_match:
            return None

        neuron, similarity = self._last_l3_match

        # Use chain replay for multi-step neurons
        if neuron.decision_chain.is_multi_step:
            replay = self._replay.replay_chain(query, neuron, similarity)
        else:
            replay = self._replay.replay(query, neuron, similarity)

        if replay.success:
            self._stats["l3_hits"] += 1

            is_verify = decision.path == ExecutionPath.VERIFY
            if is_verify:
                # VerifyPath: replay succeeded, but LLM must verify
                tool_call = replay.tool_call
                args_str = ", ".join(f"{k}={v!r}" for k, v in tool_call["args"].items())
                verify_prompt = (
                    f"Proposed action: {tool_call['name']}({args_str}). "
                    f"Is this correct for the query: \"{query}\"? Answer Yes or No."
                )
                return RecallResult(
                    source="L3",
                    confidence=replay.confidence,
                    path=decision.path.value,
                    llm_needed=True,  # LLM needed for verification
                    reason=replay.reason,
                    neuron_id=neuron.id,
                    tool_call=replay.tool_call,
                    verify_prompt=verify_prompt,
                )
            else:
                # Stage3Path: fully LLM-free
                return RecallResult(
                    source="L3",
                    confidence=replay.confidence,
                    path=decision.path.value,
                    llm_needed=False,
                    reason=replay.reason,
                    neuron_id=neuron.id,
                    tool_call=replay.tool_call,
                )

        # Replay failed — fallback. For Stage3Path this means LLM needed.
        return None

    def _persist_neuron(self, neuron: DecisionNeuron) -> None:
        """Save neuron to SQLite."""
        data = neuron.to_dict()
        self._storage.save_neuron(neuron.id, json.dumps(data))

    def _infer_slot_patterns(self, neuron: DecisionNeuron) -> None:
        """Infer regex patterns from slot examples when we have 2+ examples."""
        for slot_name, rule in neuron.slot_schema.items():
            if len(rule.examples) >= 2 and rule.pattern is None:
                rule.pattern = self._try_infer_pattern(rule.examples)

    @staticmethod
    def _try_infer_pattern(examples: List) -> Optional[str]:
        """Try to infer a common extraction pattern from examples.

        Looks for a common template where the slot value varies.
        E.g. "X'da hava nasıl?" → extracts word before "'da"
        """
        if len(examples) < 2:
            return None

        queries = [q for q, v in examples]
        values = [v for q, v in examples]

        # Strategy: find common prefix/suffix around the slot value
        patterns_found = []
        for query, value in examples:
            if value not in query:
                continue
            idx = query.index(value)
            prefix = query[:idx]
            suffix = query[idx + len(value):]
            patterns_found.append((prefix.strip(), suffix.strip()))

        if len(patterns_found) < 2:
            return None

        # Check if all prefixes and suffixes are similar
        prefixes = [p for p, s in patterns_found]
        suffixes = [s for p, s in patterns_found]

        # Find common suffix of prefixes (the part just before the value)
        common_pre = _common_suffix(prefixes)
        # Find common prefix of suffixes (the part just after the value)
        common_suf = _common_prefix(suffixes)

        if common_pre or common_suf:
            # Build a regex-ish pattern description
            pre_escaped = re.escape(common_pre) if common_pre else ""
            suf_escaped = re.escape(common_suf) if common_suf else ""
            return f"{pre_escaped}(.+?){suf_escaped}" if (pre_escaped or suf_escaped) else None

        return None

    @staticmethod
    def _has_l2_pattern(text: str) -> bool:
        patterns = [
            r'[A-Z]{2,}-\d+',
            r'\d{4}-\d{2}-\d{2}',
            r'\$[\d,]+\.?\d*',
        ]
        return any(re.search(p, text) for p in patterns)


def _common_prefix(strings: List[str]) -> str:
    if not strings:
        return ""
    prefix = strings[0]
    for s in strings[1:]:
        while not s.startswith(prefix):
            prefix = prefix[:-1]
            if not prefix:
                return ""
    return prefix


def _common_suffix(strings: List[str]) -> str:
    if not strings:
        return ""
    reversed_strings = [s[::-1] for s in strings]
    rev_prefix = _common_prefix(reversed_strings)
    return rev_prefix[::-1]
