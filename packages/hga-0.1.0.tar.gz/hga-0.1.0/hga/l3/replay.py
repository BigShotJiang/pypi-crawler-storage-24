"""L3 Decision Replay — Replay mature neuron decisions without LLM.

Tiered slot extraction:
1. Exact match: slot value seen before → direct match
2. Pattern match: regex learned from 3+ examples
3. Embedding diff: semantic extraction via embedding subtraction
4. Fallback: returns None (caller should delegate to LLM)

Stage 2 neurons use methods 1-3. If method 4 is needed → stays Stage 2.
Stage 3 only if methods 1-3 succeed ≥95% of the time.
"""

import re
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

import numpy as np

from .neuron import DecisionNeuron, DecisionStep, SlotRule


# ─── Replay Result ───────────────────────────────────────────────────────────

@dataclass
class ReplayResult:
    """Output of a decision replay attempt."""
    success: bool
    tool_call: Optional[Dict] = None     # {"name": str, "args": {slot: value}}
    confidence: float = 0.0
    extraction_methods: Dict[str, str] = field(default_factory=dict)  # slot → method used
    failed_slots: List[str] = field(default_factory=list)
    reason: str = ""


# ─── Slot Extractor ─────────────────────────────────────────────────────────

class SlotExtractor:
    """Tiered slot extraction from queries using learned patterns."""

    def __init__(self, embedder=None):
        self._embedder = embedder

    def extract(self, query: str, slot_rule: SlotRule,
                neuron: Optional[DecisionNeuron] = None) -> Tuple[Optional[str], str]:
        """Extract a slot value from query using tiered methods.

        Returns:
            (value, method) where method is one of:
            "exact_match", "template_match", "pattern_match", "embedding_diff", "failed"
        """
        # Method 1: Exact match — value seen before in examples
        value = self._exact_match(query, slot_rule)
        if value is not None:
            return value, "exact_match"

        # Method 2: Template match — try each example's prefix/suffix as template
        value = self._template_match(query, slot_rule)
        if value is not None:
            return value, "template_match"

        # Method 3: Pattern match — regex learned from examples
        value = self._pattern_match(query, slot_rule)
        if value is not None:
            return value, "pattern_match"

        # Method 4: Embedding diff — semantic extraction
        if self._embedder is not None and neuron is not None:
            value = self._embedding_diff(query, slot_rule, neuron)
            if value is not None:
                return value, "embedding_diff"

        return None, "failed"

    def extract_all(self, query: str, neuron: DecisionNeuron) -> Tuple[Dict[str, str], Dict[str, str], List[str]]:
        """Extract all slots for a neuron.

        Returns:
            (values, methods, failed_slots) where:
            - values: {slot_name: extracted_value}
            - methods: {slot_name: method_used}
            - failed_slots: list of slot names that failed extraction
        """
        values = {}
        methods = {}
        failed = []

        for slot_name, rule in neuron.slot_schema.items():
            value, method = self.extract(query, rule, neuron)
            if value is not None:
                values[slot_name] = value
                methods[slot_name] = method
            else:
                failed.append(slot_name)

        return values, methods, failed

    # ─── Extraction Methods ──────────────────────────────────────────────

    @staticmethod
    def _exact_match(query: str, rule: SlotRule) -> Optional[str]:
        """Method 1: Check if any previously seen value appears in the query."""
        if not rule.examples:
            return None

        # Collect known values
        known_values = list({v for _, v in rule.examples if v})
        # Sort by length descending to match longest first
        known_values.sort(key=len, reverse=True)

        for value in known_values:
            if value in query:
                return value

        return None

    @staticmethod
    def _template_match(query: str, rule: SlotRule) -> Optional[str]:
        """Method 2: Try each example's (prefix, suffix) as a mini-template.

        For "Remind me to call the dentist" with value "call the dentist",
        prefix="Remind me to ", suffix="". If new query is "Remind me to
        book flight tickets", extract "book flight tickets".

        This handles free-text slots where each template variant provides
        a valid extraction frame, even when no global pattern exists.
        """
        if not rule.examples:
            return None

        for ex_query, ex_value in rule.examples:
            if not ex_value or ex_value not in ex_query:
                continue
            idx = ex_query.index(ex_value)
            prefix = ex_query[:idx]
            suffix = ex_query[idx + len(ex_value):]

            # Try to match this template against the query
            starts = prefix and query.startswith(prefix)
            ends = suffix and query.endswith(suffix)

            if prefix and suffix:
                if starts and ends:
                    extracted = query[len(prefix):len(query) - len(suffix)].strip()
                    if extracted:
                        return extracted
            elif prefix:
                if starts:
                    extracted = query[len(prefix):].strip()
                    if extracted:
                        return extracted
            elif suffix:
                if ends:
                    extracted = query[:len(query) - len(suffix)].strip()
                    if extracted:
                        return extracted

        return None

    @staticmethod
    def _pattern_match(query: str, rule: SlotRule) -> Optional[str]:
        """Method 2: Use inferred regex pattern to extract value."""
        if not rule.pattern:
            return None

        try:
            match = re.search(rule.pattern, query)
            if match and match.group(1):
                return match.group(1).strip()
        except (re.error, IndexError):
            pass

        return None

    def _embedding_diff(self, query: str, rule: SlotRule,
                        neuron: DecisionNeuron) -> Optional[str]:
        """Method 3: Semantic extraction via embedding subtraction.

        Idea: query_emb - pattern_emb ≈ slot_value_emb
        Compare this "diff vector" against known slot value embeddings.
        If closest match is similar enough, use that as a template to
        find the value in the query text.
        """
        if not rule.examples or self._embedder is None:
            return None

        query_emb = self._embedder.encode(query)
        diff_vec = query_emb - neuron.pattern_embedding

        # Compute embeddings for known slot values and their diff vectors
        best_value = None
        best_sim = -1.0

        for ex_query, ex_value in rule.examples:
            if not ex_value:
                continue
            ex_emb = self._embedder.encode(ex_query)
            ex_diff = ex_emb - neuron.pattern_embedding

            sim = float(diff_vec @ ex_diff / (
                max(np.linalg.norm(diff_vec), 1e-10) *
                max(np.linalg.norm(ex_diff), 1e-10)
            ))
            if sim > best_sim:
                best_sim = sim
                best_value = ex_value

        if best_sim < 0.3 or best_value is None:
            return None

        # The diff vectors are similar, meaning the query has the same
        # structural relationship. Now find the novel part of the query
        # that isn't in the pattern.
        return self._find_novel_segment(query, rule)

    @staticmethod
    def _find_novel_segment(query: str, rule: SlotRule) -> Optional[str]:
        """Find the part of the query that varies across examples.

        Uses the examples to identify the fixed template parts, then
        extracts what's different in the new query.
        """
        if len(rule.examples) < 2:
            return None

        # Build a template from examples: find common parts
        queries = [q for q, v in rule.examples]
        values = [v for q, v in rule.examples]

        # Find prefix before value and suffix after value
        prefixes = []
        suffixes = []
        for q, v in zip(queries, values):
            if v in q:
                idx = q.index(v)
                prefixes.append(q[:idx])
                suffixes.append(q[idx + len(v):])

        if len(prefixes) < 2:
            return None

        # Find longest common prefix of prefixes and suffix of suffixes
        common_pre = _lcp(prefixes)
        common_suf = _lcs(suffixes)

        # Extract from the new query
        start = len(common_pre) if query.startswith(common_pre) else 0
        end = len(query) - len(common_suf) if common_suf and query.endswith(common_suf) else len(query)

        if start < end:
            extracted = query[start:end].strip()
            if extracted:
                return extracted

        return None


# ─── Decision Replay ─────────────────────────────────────────────────────────

class DecisionReplay:
    """Replays mature neuron decisions to produce tool calls without LLM.

    Only replays if:
    - Neuron is Stage 2+ (for VerifyPath) or Stage 3 (for Stage3Path)
    - Similarity between query and neuron exceeds threshold
    - All required slots can be extracted
    - No slot extraction failure (NEVER silent failure)
    """

    REPLAY_SIMILARITY_THRESHOLD = 0.55
    STAGE3_SIMILARITY_THRESHOLD = 0.60

    def __init__(self, embedder=None):
        self._extractor = SlotExtractor(embedder=embedder)

    def replay(self, query: str, neuron: DecisionNeuron,
               similarity: float) -> ReplayResult:
        """Attempt to replay a neuron's decision chain.

        Args:
            query: The incoming query.
            neuron: The matched neuron.
            similarity: Cosine similarity between query and neuron centroid.

        Returns:
            ReplayResult. success=False means caller should fallback to LLM.
            NEVER returns a wrong tool call silently.
        """
        # Check similarity threshold based on stage
        min_sim = (self.STAGE3_SIMILARITY_THRESHOLD if neuron.stage >= 3
                   else self.REPLAY_SIMILARITY_THRESHOLD)

        if similarity < min_sim:
            return ReplayResult(
                success=False,
                confidence=similarity,
                reason=f"Similarity {similarity:.2f} below threshold {min_sim}",
            )

        # Extract all slots
        values, methods, failed = self._extractor.extract_all(query, neuron)

        # If any required slot failed → fallback (NEVER silent failure)
        if failed:
            return ReplayResult(
                success=False,
                confidence=similarity,
                extraction_methods=methods,
                failed_slots=failed,
                reason=f"Slot extraction failed for: {failed}",
            )

        # Coherence check 1: if all slots were extracted via embedding_diff only
        # (no exact/template/pattern match), the query may be adversarial.
        if neuron.stage >= 3 and values:
            exact_or_pattern_count = sum(
                1 for m in methods.values()
                if m in ("exact_match", "template_match", "pattern_match")
            )
            if exact_or_pattern_count == 0 and similarity < 0.80:
                return ReplayResult(
                    success=False,
                    confidence=similarity,
                    extraction_methods=methods,
                    reason=f"Coherence check failed: no exact/pattern slot match, sim={similarity:.2f}",
                )
            if exact_or_pattern_count == 0:
                return ReplayResult(
                    success=False,
                    confidence=similarity,
                    extraction_methods=methods,
                    reason=f"Coherence check failed: no known slot values extracted",
                )

        # Coherence check 2: template structure check.
        # Remove the extracted slot value from the query and compare the
        # "template skeleton" to known example skeletons. If the skeleton
        # is novel (doesn't match any known pattern), this may be adversarial.
        if neuron.stage >= 3 and values and neuron.slot_schema:
            query_skeleton = query.lower()
            for v in values.values():
                query_skeleton = query_skeleton.replace(v.lower(), "{}").replace(str(v).lower(), "{}")

            # Check if skeleton matches any known template
            skeleton_matched = False
            query_words = set(query_skeleton.split()) - {"{}"}
            for slot_name, rule in neuron.slot_schema.items():
                for ex_query, ex_value in (rule.examples or []):
                    if ex_value:
                        ex_skeleton = ex_query.lower().replace(ex_value.lower(), "{}")
                        ex_words = set(ex_skeleton.split()) - {"{}"}
                        # Match if: exact skeleton match, prefix match, or
                        # >60% word overlap (handles rephrased queries)
                        overlap = len(query_words & ex_words) / max(len(query_words | ex_words), 1)
                        if (ex_skeleton == query_skeleton or
                            query_skeleton.startswith(ex_skeleton[:15]) or
                            ex_skeleton.startswith(query_skeleton[:15]) or
                            overlap >= 0.5):
                            skeleton_matched = True
                            break
                if skeleton_matched:
                    break

            if not skeleton_matched and similarity < 0.75:
                return ReplayResult(
                    success=False,
                    confidence=similarity,
                    extraction_methods=methods,
                    reason=f"Template structure check failed: novel query skeleton",
                )

        # Coherence check 3: novel content words (single-step neurons only).
        # Even if skeleton overlap is high, the query may contain intent-changing
        # words not seen in ANY training example (e.g., "forecast accuracy" added
        # to a weather query changes intent entirely). Flag if the fraction of
        # novel words exceeds a threshold.
        # Skip for multi-step neurons: compound queries naturally contain novel
        # action words (e.g., "remind", "call", "compare") that are legitimate.
        is_single_step = not getattr(neuron.decision_chain, "is_multi_step", False)
        if neuron.stage >= 3 and values and neuron.slot_schema and is_single_step:
            _stop = {"a", "an", "the", "is", "are", "was", "were", "in", "on",
                     "at", "to", "for", "of", "and", "or", "but", "it", "its",
                     "do", "does", "did", "be", "been", "being", "have", "has",
                     "had", "i", "me", "my", "you", "your", "we", "they", "he",
                     "she", "that", "this", "with", "from", "by", "about", "as",
                     "if", "not", "no", "so", "up", "out", "can", "will", "just",
                     "than", "then", "also", "very", "s", "t", "what", "how",
                     "when", "where", "which", "who", "whom", "whose", "{}", "?"}
            # Rebuild query skeleton if not already computed
            if "query_skeleton" not in dir():
                query_skeleton = query.lower()
                for v in values.values():
                    query_skeleton = query_skeleton.replace(
                        v.lower(), "{}").replace(str(v).lower(), "{}")
            # Strip punctuation before splitting to avoid "{}?" artifacts
            import string as _string
            _punct_table = str.maketrans("", "", _string.punctuation.replace("{", "").replace("}", ""))
            _clean = lambda s: set(s.translate(_punct_table).split()) - _stop - {""}
            q_content = _clean(query_skeleton)

            # Collect all content words from all known example skeletons
            known_content = set()
            for slot_name, rule in neuron.slot_schema.items():
                for ex_query, ex_value in (rule.examples or []):
                    if ex_value:
                        ex_skel = ex_query.lower().replace(ex_value.lower(), "{}")
                        known_content.update(_clean(ex_skel))

            novel = q_content - known_content
            if q_content and len(novel) / len(q_content) > 0.20:
                return ReplayResult(
                    success=False,
                    confidence=similarity,
                    extraction_methods=methods,
                    reason=f"Novel content words detected: {novel} "
                           f"({len(novel)}/{len(q_content)} content words are new)",
                )

        # Build tool call
        tool_call = {
            "name": neuron.decision_chain.tool,
            "args": values,
        }

        return ReplayResult(
            success=True,
            tool_call=tool_call,
            confidence=similarity,
            extraction_methods=methods,
            reason=f"Replay OK: tool={tool_call['name']}, methods={methods}",
        )

    def replay_chain(self, query: str, neuron: DecisionNeuron,
                     similarity: float,
                     tool_executor=None) -> ReplayResult:
        """Replay a multi-step decision chain.

        Args:
            query: The incoming query.
            neuron: The matched neuron (must have multi-step chain).
            similarity: Cosine similarity between query and neuron.
            tool_executor: Callable(tool_name, args) -> result. Required for
                          multi-step chains to execute intermediate steps.

        Returns:
            ReplayResult. Contains list of tool_calls for multi-step.
            Fails explicitly on any causal link violation.
        """
        chain = neuron.decision_chain

        # For single-step chains, delegate to standard replay
        if not chain.is_multi_step:
            return self.replay(query, neuron, similarity)

        # Check similarity threshold
        min_sim = (self.STAGE3_SIMILARITY_THRESHOLD if neuron.stage >= 3
                   else self.REPLAY_SIMILARITY_THRESHOLD)
        if similarity < min_sim:
            return ReplayResult(
                success=False,
                confidence=similarity,
                reason=f"Similarity {similarity:.2f} below threshold {min_sim}",
            )

        # Extract query-level slots
        values, methods, failed = self._extractor.extract_all(query, neuron)
        if failed:
            return ReplayResult(
                success=False,
                confidence=similarity,
                extraction_methods=methods,
                failed_slots=failed,
                reason=f"Query-level slot extraction failed: {failed}",
            )

        # Topological sort of steps
        sorted_steps = _topological_sort(chain.steps)
        if sorted_steps is None:
            return ReplayResult(
                success=False,
                confidence=similarity,
                reason="Cycle detected in step dependencies",
            )

        # Execute steps in order
        step_results = {}  # step_id → result
        all_tool_calls = []
        all_methods = dict(methods)

        for step in sorted_steps:
            # Causal check: all dependencies must have succeeded
            for dep_id in step.depends_on:
                if dep_id not in step_results:
                    return ReplayResult(
                        success=False,
                        confidence=similarity,
                        extraction_methods=all_methods,
                        reason=f"Causal link violation: step {step.step_id} depends on "
                               f"step {dep_id} which did not produce a result",
                    )

            # Resolve slot values for this step
            step_args = {}
            for slot_name, source in step.slot_sources.items():
                if source == "from_query":
                    if slot_name in values:
                        step_args[slot_name] = values[slot_name]
                    else:
                        return ReplayResult(
                            success=False,
                            confidence=similarity,
                            reason=f"Step {step.step_id}: query slot '{slot_name}' not found",
                        )
                elif source.startswith("from_step:"):
                    dep_ref = source.split(":", 1)[1]
                    # Handle "<stepN>" format
                    dep_id = int(dep_ref.replace("<step", "").replace(">", ""))
                    if dep_id in step_results:
                        step_args[slot_name] = step_results[dep_id]
                    else:
                        return ReplayResult(
                            success=False,
                            confidence=similarity,
                            reason=f"Step {step.step_id}: dependency step {dep_id} has no result",
                        )

            tool_call = {"name": step.tool, "args": step_args, "step_id": step.step_id}
            all_tool_calls.append(tool_call)

            # Execute the step if executor provided
            if tool_executor is not None and step.action == "tool_call":
                try:
                    result = tool_executor(step.tool, step_args)
                    step_results[step.step_id] = result
                except Exception as e:
                    return ReplayResult(
                        success=False,
                        confidence=similarity,
                        reason=f"Step {step.step_id} execution failed: {e}",
                    )
            elif step.action == "format":
                # Format steps combine prior results
                step_results[step.step_id] = step_args
            else:
                # No executor — record the call but mark result as pending
                step_results[step.step_id] = f"<pending:{step.tool}>"

        return ReplayResult(
            success=True,
            tool_call={"name": "__multi_step__", "args": {},
                       "steps": all_tool_calls},
            confidence=similarity,
            extraction_methods=all_methods,
            reason=f"Multi-step replay OK: {len(all_tool_calls)} steps",
        )

    def can_replay(self, neuron: DecisionNeuron, similarity: float) -> bool:
        """Quick check: is this neuron eligible for replay?"""
        if neuron.stage < 2:
            return False
        min_sim = (self.STAGE3_SIMILARITY_THRESHOLD if neuron.stage >= 3
                   else self.REPLAY_SIMILARITY_THRESHOLD)
        return similarity >= min_sim


# ─── Helpers ─────────────────────────────────────────────────────────────────

def _topological_sort(steps: List[DecisionStep]) -> Optional[List[DecisionStep]]:
    """Topological sort of steps by depends_on. Returns None if cycle detected."""
    step_map = {s.step_id: s for s in steps}
    visited = set()
    in_progress = set()
    result = []

    def visit(step_id):
        if step_id in in_progress:
            return False  # cycle
        if step_id in visited:
            return True
        in_progress.add(step_id)
        step = step_map.get(step_id)
        if step is None:
            in_progress.discard(step_id)
            return True
        for dep in step.depends_on:
            if not visit(dep):
                return False
        in_progress.discard(step_id)
        visited.add(step_id)
        result.append(step)
        return True

    for s in steps:
        if s.step_id not in visited:
            if not visit(s.step_id):
                return None
    return result


def _lcp(strings: List[str]) -> str:
    """Longest common prefix."""
    if not strings:
        return ""
    prefix = strings[0]
    for s in strings[1:]:
        while not s.startswith(prefix):
            prefix = prefix[:-1]
            if not prefix:
                return ""
    return prefix


def _lcs(strings: List[str]) -> str:
    """Longest common suffix."""
    if not strings:
        return ""
    reversed_strings = [s[::-1] for s in strings]
    rev_prefix = _lcp(reversed_strings)
    return rev_prefix[::-1]
