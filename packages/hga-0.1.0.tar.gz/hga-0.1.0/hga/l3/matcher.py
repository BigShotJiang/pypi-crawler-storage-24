"""L3 Pattern Matcher — Maps queries to neurons via embedding similarity.

Includes exploration transfer: mature neurons can warm-start new neurons
in the same task family, reducing maturation time by 15%+.
"""

import copy
import uuid
import numpy as np
from typing import Dict, List, Optional, Tuple

from .neuron import (
    DecisionNeuron, DecisionChain, DecisionStep, SlotRule,
    get_task_family, structural_similarity,
)


# Similarity threshold to match a query to an existing neuron
MATCH_THRESHOLD = 0.60

# Below this similarity, a new neuron should be created
NEW_NEURON_THRESHOLD = 0.35

# Minimum similarity for transfer (semantic or hybrid)
TRANSFER_SIMILARITY_THRESHOLD = 0.35

# Number of trial hits for provisional neurons
PROVISIONAL_TRIAL_COUNT = 3


class NeuronMatcher:
    """Matches incoming queries to existing neurons using embedding similarity.

    Uses a flat index over neuron centroids for matching. Fast enough for
    hundreds of neurons; can be replaced with ANN index later.
    """

    def __init__(self, match_threshold: float = MATCH_THRESHOLD):
        self.match_threshold = match_threshold
        self._neurons: Dict[str, DecisionNeuron] = {}  # id → neuron
        self._classification_index: Dict[str, List[str]] = {}  # classification → [neuron_ids]

    @property
    def neuron_count(self) -> int:
        return len(self._neurons)

    def add_neuron(self, neuron: DecisionNeuron) -> None:
        """Register a neuron for matching."""
        self._neurons[neuron.id] = neuron
        cls = neuron.classification
        if cls not in self._classification_index:
            self._classification_index[cls] = []
        if neuron.id not in self._classification_index[cls]:
            self._classification_index[cls].append(neuron.id)

    def remove_neuron(self, neuron_id: str) -> None:
        """Remove a neuron from the matcher."""
        neuron = self._neurons.pop(neuron_id, None)
        if neuron:
            cls = neuron.classification
            if cls in self._classification_index:
                self._classification_index[cls] = [
                    nid for nid in self._classification_index[cls] if nid != neuron_id
                ]

    def get_neuron(self, neuron_id: str) -> Optional[DecisionNeuron]:
        return self._neurons.get(neuron_id)

    def get_all_neurons(self) -> List[DecisionNeuron]:
        return list(self._neurons.values())

    def match(
        self,
        query_embedding: np.ndarray,
        classification: Optional[str] = None,
    ) -> Optional[Tuple[DecisionNeuron, float]]:
        """Find the best matching neuron for a query.

        Args:
            query_embedding: Normalized query embedding.
            classification: If provided, only match neurons of this type.

        Returns:
            (neuron, similarity) or None if no match above threshold.
        """
        candidates = self._get_candidates(classification)
        if not candidates:
            return None

        best_neuron = None
        best_sim = -1.0

        for neuron in candidates:
            sim = neuron.best_similarity(query_embedding)
            if sim > best_sim:
                best_sim = sim
                best_neuron = neuron

        if best_neuron is not None and best_sim >= self.match_threshold:
            return best_neuron, best_sim

        return None

    def match_or_classify(
        self,
        query_embedding: np.ndarray,
        classification: Optional[str] = None,
    ) -> Tuple[Optional[DecisionNeuron], float, bool]:
        """Match query to neuron, indicating whether a new neuron is needed.

        Returns:
            (neuron, similarity, is_new) where:
            - neuron: matched neuron or None
            - similarity: best similarity score
            - is_new: True if no match found and a new neuron should be created
        """
        candidates = self._get_candidates(classification)
        if not candidates:
            return None, 0.0, True

        best_neuron = None
        best_sim = -1.0

        for neuron in candidates:
            sim = neuron.best_similarity(query_embedding)
            if sim > best_sim:
                best_sim = sim
                best_neuron = neuron

        if best_sim >= self.match_threshold:
            return best_neuron, best_sim, False
        elif best_sim < NEW_NEURON_THRESHOLD:
            return None, best_sim, True
        else:
            # Ambiguous zone — match to best but flag as uncertain
            return best_neuron, best_sim, False

    def find_similar(
        self,
        query_embedding: np.ndarray,
        top_k: int = 3,
    ) -> List[Tuple[DecisionNeuron, float]]:
        """Find top-k most similar neurons regardless of threshold."""
        all_neurons = list(self._neurons.values())
        if not all_neurons:
            return []

        scored = []
        for neuron in all_neurons:
            sim = neuron.best_similarity(query_embedding)
            scored.append((neuron, sim))

        scored.sort(key=lambda x: x[1], reverse=True)
        return scored[:top_k]

    def get_by_classification(self, classification: str) -> List[DecisionNeuron]:
        """Get all neurons of a given classification/task type."""
        ids = self._classification_index.get(classification, [])
        return [self._neurons[nid] for nid in ids if nid in self._neurons]

    def attempt_transfer(
        self,
        query_embedding: np.ndarray,
        classification: str,
    ) -> Optional[DecisionNeuron]:
        """Try to create a provisional neuron via exploration transfer.

        Looks for a mature neuron (stage >= 2) in the same task family
        with high structural similarity. If found, creates a provisional
        Stage 1 neuron with the donor's chain structure (but no slot values).

        Cross-family transfer is strictly forbidden.

        Returns:
            Provisional neuron if transfer succeeded, None otherwise.
        """
        query_family = get_task_family(classification)

        # Find mature donors in the same family
        donors = []
        for neuron in self._neurons.values():
            if neuron.stage < 2:
                continue
            donor_family = get_task_family(neuron.classification)
            if donor_family != query_family:
                continue  # cross-family guard
            donors.append(neuron)

        if not donors:
            return None

        # Create a temporary "probe" neuron to measure structural similarity
        # We need at least a classification and tool to compare
        best_donor = None
        best_score = -1.0

        for donor in donors:
            # Semantic similarity
            sem_sim = donor.best_similarity(query_embedding)
            # Structural bonus: same classification gets a boost
            struct_bonus = 0.15 if donor.classification == classification else 0.0
            score = sem_sim + struct_bonus
            if score > best_score:
                best_score = score
                best_donor = donor

        if best_donor is None or best_score < TRANSFER_SIMILARITY_THRESHOLD:
            return None

        # Create provisional neuron: copy chain structure, reset values
        return self._create_provisional(query_embedding, classification, best_donor)

    def _create_provisional(
        self,
        query_embedding: np.ndarray,
        classification: str,
        donor: DecisionNeuron,
    ) -> DecisionNeuron:
        """Create a provisional Stage 1 neuron from a donor.

        Copies: chain structure (tools, steps, dependencies).
        Does NOT copy: slot values/examples, hit counts, edge weight history.
        """
        # Deep copy steps, clear slot-specific data
        new_steps = []
        for step in donor.decision_chain.steps:
            new_steps.append(DecisionStep(
                tool=step.tool,
                step_id=step.step_id,
                action=step.action,
                depends_on=list(step.depends_on),
                output_key=step.output_key,
                slot_sources=dict(step.slot_sources),
                slot_mapping=dict(step.slot_mapping),
            ))

        # Copy slot schema structure but clear examples
        new_slots = {}
        for name, rule in donor.slot_schema.items():
            new_slots[name] = SlotRule(
                name=rule.name,
                extraction=rule.extraction,
                pattern=None,  # don't transfer learned patterns
                examples=[],   # don't transfer slot values
            )

        chain = DecisionChain(
            tool=donor.decision_chain.tool,
            slots={k: SlotRule(name=v.name, extraction=v.extraction)
                   for k, v in donor.decision_chain.slots.items()},
            steps=new_steps,
        )

        neuron = DecisionNeuron(
            id=str(uuid.uuid4())[:12],
            pattern_embedding=query_embedding.copy(),
            classification=classification,
            decision_chain=chain,
            slot_schema=new_slots,
            stage=1,           # start at Stage 1 (warm start)
            edge_weight=1.0,   # provisional confidence
            provisional=True,
            provisional_hits=0,
            transferred_from=donor.id,
            exemplar_embeddings=[query_embedding.copy()],
        )

        self.add_neuron(neuron)
        return neuron

    def update_provisional(self, neuron: DecisionNeuron, outcome: str) -> bool:
        """Update a provisional neuron after a trial execution.

        Args:
            neuron: The provisional neuron.
            outcome: "success" or "failure".

        Returns:
            True if neuron is still alive, False if it was deleted.
        """
        if not neuron.provisional:
            return True  # not provisional, nothing special

        neuron.provisional_hits += 1

        if outcome == "failure":
            # Any failure during trial → delete provisional neuron
            self.remove_neuron(neuron.id)
            return False

        if neuron.provisional_hits >= PROVISIONAL_TRIAL_COUNT:
            # 3/3 success → confirm, normal maturation continues
            neuron.provisional = False
            neuron.provisional_hits = 0

        return True

    def get_family_neurons(self, family: str) -> List[DecisionNeuron]:
        """Get all neurons belonging to a task family."""
        return [
            n for n in self._neurons.values()
            if get_task_family(n.classification) == family
        ]

    def _get_candidates(self, classification: Optional[str]) -> List[DecisionNeuron]:
        if classification:
            return self.get_by_classification(classification)
        return list(self._neurons.values())
