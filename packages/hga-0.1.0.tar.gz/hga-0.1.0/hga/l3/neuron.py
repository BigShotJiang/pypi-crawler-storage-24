"""L3 Semantic Neuron Layer — Decision chain capture and maturation.

Neurons capture repeating decision patterns (tool calls) and mature
through stages 0→1→2→3 as they accumulate successful hits.
"""

import uuid
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple

import numpy as np


# ─── Stage Thresholds ────────────────────────────────────────────────────────

STAGE_THRESHOLDS = {
    # stage → (min_hits, min_success_rate)
    0: (0, 0.0),        # just created
    1: (3, 0.5),         # 3 hits, >50% success
    2: (8, 0.7),         # 8 hits, >70% success
    3: (15, 0.85),       # 15 hits, >85% success + 5 consecutive clean
}

CONSECUTIVE_CLEAN_FOR_STAGE3 = 5
EDGE_WEIGHT_RANGE = (-3.0, 3.0)

SOURCE_WEIGHTS = {
    "experience": 3.0,
    "theoretical": 2.0,
    "prompt": 1.0,
}


# ─── Data Classes ────────────────────────────────────────────────────────────

@dataclass
class SlotRule:
    """How to extract a slot value from a query."""
    name: str
    extraction: str = "from_query"  # "from_query" | "from_context" | "from_l2"
    pattern: Optional[str] = None   # regex pattern (inferred from examples)
    examples: List[Tuple[str, str]] = field(default_factory=list)  # (query, extracted_value)


@dataclass
class DecisionStep:
    """A single step in a decision chain.

    For single-step chains (legacy): just tool + slot_mapping.
    For multi-step chains: action type, dependencies, output routing.
    """
    tool: str
    slot_mapping: Dict[str, str] = field(default_factory=dict)  # slot_name → extraction_key
    step_id: int = 0
    action: str = "tool_call"  # "tool_call" | "format"
    depends_on: List[int] = field(default_factory=list)  # step_ids this step depends on
    output_key: str = ""  # result key for downstream steps
    slot_sources: Dict[str, str] = field(default_factory=dict)  # slot → "from_query" | "from_step:N"


@dataclass
class DecisionChain:
    """Captured decision: which tool + how to fill slots.

    Single-step chains: tool + slots (backward compatible).
    Multi-step chains: steps list with dependency graph.
    """
    tool: str  # primary tool (first step for multi-step)
    slots: Dict[str, SlotRule] = field(default_factory=dict)
    pre_conditions: List[str] = field(default_factory=list)
    steps: List[DecisionStep] = field(default_factory=list)

    @property
    def is_multi_step(self) -> bool:
        return len(self.steps) > 1


@dataclass
class DecisionNeuron:
    """A semantic neuron that captures a repeating decision pattern."""
    id: str
    pattern_embedding: np.ndarray       # semantic centroid of matching queries
    classification: str                  # task type (e.g. "weather_lookup")
    decision_chain: DecisionChain
    slot_schema: Dict[str, SlotRule] = field(default_factory=dict)
    hit_count: int = 0
    success_count: int = 0
    fail_count: int = 0
    stage: int = 0
    edge_weight: float = 0.0
    consecutive_clean: int = 0          # consecutive successes without fallback
    created_at: str = field(default_factory=lambda: datetime.utcnow().isoformat())
    last_fired: str = field(default_factory=lambda: datetime.utcnow().isoformat())

    # Multi-exemplar embeddings for diverse template matching
    exemplar_embeddings: List[np.ndarray] = field(default_factory=list)
    EXEMPLAR_NOVELTY_THRESHOLD: float = field(default=0.85, repr=False)
    MAX_EXEMPLARS: int = field(default=8, repr=False)

    # Exploration transfer fields
    provisional: bool = False               # True if created via transfer
    provisional_hits: int = 0               # hits since transfer (0-3 trial)
    transferred_from: Optional[str] = None  # source neuron ID

    # Running embedding accumulator for centroid update
    _embedding_sum: Optional[np.ndarray] = field(default=None, repr=False)
    _embedding_count: int = field(default=0, repr=False)

    @property
    def success_rate(self) -> float:
        total = self.success_count + self.fail_count
        return self.success_count / total if total > 0 else 0.0

    def update_outcome(self, outcome: str, source: str = "experience") -> None:
        """Update neuron after a decision outcome.

        Args:
            outcome: "success" or "failure"
            source: "experience", "theoretical", or "prompt"
        """
        self.hit_count += 1
        self.last_fired = datetime.utcnow().isoformat()

        src_weight = SOURCE_WEIGHTS.get(source, 1.0)
        if outcome == "success":
            self.success_count += 1
            self.consecutive_clean += 1
            self.edge_weight += src_weight * 1.0
        else:
            self.fail_count += 1
            self.consecutive_clean = 0
            self.edge_weight += src_weight * (-1.0)

        # Clip edge weight
        lo, hi = EDGE_WEIGHT_RANGE
        self.edge_weight = max(lo, min(hi, self.edge_weight))

        # Check stage progression
        self._check_stage_progression()

    def _check_stage_progression(self) -> None:
        """Promote to next stage if thresholds are met."""
        for target_stage in (1, 2, 3):
            if self.stage >= target_stage:
                continue
            min_hits, min_rate = STAGE_THRESHOLDS[target_stage]
            if self.hit_count >= min_hits and self.success_rate >= min_rate:
                if target_stage == 3:
                    if self.consecutive_clean >= CONSECUTIVE_CLEAN_FOR_STAGE3:
                        self.stage = target_stage
                else:
                    self.stage = target_stage

    def update_centroid(self, query_embedding: np.ndarray) -> None:
        """Update pattern embedding as running mean of matched queries."""
        if self._embedding_sum is None:
            self._embedding_sum = query_embedding.copy()
            self._embedding_count = 1
        else:
            self._embedding_sum += query_embedding
            self._embedding_count += 1

        # Update centroid as mean
        self.pattern_embedding = self._embedding_sum / self._embedding_count
        # Normalize
        norm = np.linalg.norm(self.pattern_embedding)
        if norm > 1e-10:
            self.pattern_embedding = self.pattern_embedding / norm

    def add_exemplar(self, query_embedding: np.ndarray) -> bool:
        """Add a template-variant exemplar if sufficiently novel.

        Returns True if a new exemplar was added.
        """
        for ex_emb in self.exemplar_embeddings:
            sim = float(query_embedding @ ex_emb)
            if sim > self.EXEMPLAR_NOVELTY_THRESHOLD:
                return False  # too similar to existing exemplar
        if len(self.exemplar_embeddings) < self.MAX_EXEMPLARS:
            self.exemplar_embeddings.append(query_embedding.copy())
            return True
        return False

    def best_similarity(self, query_embedding: np.ndarray) -> float:
        """Compute best similarity across centroid + all exemplars."""
        best = float(query_embedding @ self.pattern_embedding)
        for ex_emb in self.exemplar_embeddings:
            sim = float(query_embedding @ ex_emb)
            if sim > best:
                best = sim
        return best

    def add_slot_example(self, slot_name: str, query: str, value: str) -> None:
        """Add an example for slot extraction learning."""
        if slot_name not in self.slot_schema:
            self.slot_schema[slot_name] = SlotRule(name=slot_name)
        rule = self.slot_schema[slot_name]
        rule.examples.append((query, value))
        # Also update decision_chain slots
        if slot_name not in self.decision_chain.slots:
            self.decision_chain.slots[slot_name] = rule

    def to_dict(self) -> Dict:
        """Serialize for storage."""
        return {
            "id": self.id,
            "pattern_embedding": self.pattern_embedding.tolist(),
            "classification": self.classification,
            "decision_chain": {
                "tool": self.decision_chain.tool,
                "slots": {
                    k: {
                        "name": v.name,
                        "extraction": v.extraction,
                        "pattern": v.pattern,
                        "examples": v.examples,
                    }
                    for k, v in self.decision_chain.slots.items()
                },
                "pre_conditions": self.decision_chain.pre_conditions,
                "steps": [
                    {
                        "tool": s.tool,
                        "slot_mapping": s.slot_mapping,
                        "step_id": s.step_id,
                        "action": s.action,
                        "depends_on": s.depends_on,
                        "output_key": s.output_key,
                        "slot_sources": s.slot_sources,
                    }
                    for s in self.decision_chain.steps
                ],
            },
            "slot_schema": {
                k: {
                    "name": v.name,
                    "extraction": v.extraction,
                    "pattern": v.pattern,
                    "examples": v.examples,
                }
                for k, v in self.slot_schema.items()
            },
            "hit_count": self.hit_count,
            "success_count": self.success_count,
            "fail_count": self.fail_count,
            "stage": self.stage,
            "edge_weight": self.edge_weight,
            "consecutive_clean": self.consecutive_clean,
            "created_at": self.created_at,
            "last_fired": self.last_fired,
            "exemplar_embeddings": [e.tolist() for e in self.exemplar_embeddings],
            "provisional": self.provisional,
            "provisional_hits": self.provisional_hits,
            "transferred_from": self.transferred_from,
        }

    @classmethod
    def from_dict(cls, data: Dict) -> "DecisionNeuron":
        """Deserialize from storage."""
        chain_data = data["decision_chain"]
        slots = {}
        for k, v in chain_data.get("slots", {}).items():
            slots[k] = SlotRule(
                name=v["name"],
                extraction=v.get("extraction", "from_query"),
                pattern=v.get("pattern"),
                examples=v.get("examples", []),
            )
        steps = [
            DecisionStep(
                tool=s["tool"],
                slot_mapping=s.get("slot_mapping", {}),
                step_id=s.get("step_id", i),
                action=s.get("action", "tool_call"),
                depends_on=s.get("depends_on", []),
                output_key=s.get("output_key", ""),
                slot_sources=s.get("slot_sources", {}),
            )
            for i, s in enumerate(chain_data.get("steps", []))
        ]
        chain = DecisionChain(
            tool=chain_data["tool"],
            slots=slots,
            pre_conditions=chain_data.get("pre_conditions", []),
            steps=steps,
        )

        schema = {}
        for k, v in data.get("slot_schema", {}).items():
            schema[k] = SlotRule(
                name=v["name"],
                extraction=v.get("extraction", "from_query"),
                pattern=v.get("pattern"),
                examples=v.get("examples", []),
            )

        emb = np.array(data["pattern_embedding"], dtype=np.float32)

        exemplars = [
            np.array(e, dtype=np.float32)
            for e in data.get("exemplar_embeddings", [])
        ]

        neuron = cls(
            id=data["id"],
            pattern_embedding=emb,
            classification=data["classification"],
            decision_chain=chain,
            slot_schema=schema,
            hit_count=data.get("hit_count", 0),
            success_count=data.get("success_count", 0),
            fail_count=data.get("fail_count", 0),
            stage=data.get("stage", 0),
            edge_weight=data.get("edge_weight", 0.0),
            consecutive_clean=data.get("consecutive_clean", 0),
            created_at=data.get("created_at", datetime.utcnow().isoformat()),
            last_fired=data.get("last_fired", datetime.utcnow().isoformat()),
            exemplar_embeddings=exemplars,
            provisional=data.get("provisional", False),
            provisional_hits=data.get("provisional_hits", 0),
            transferred_from=data.get("transferred_from"),
        )
        return neuron


# ─── Transfer Utilities ─────────────────────────────────────────────────────

def get_task_family(classification: str) -> str:
    """Extract task family from classification string.

    'weather_lookup' → 'weather'
    'compare_weather' → 'compare'
    'calendar::tuesday' → 'calendar'
    """
    # Handle :: separator
    if "::" in classification:
        return classification.split("::")[0]
    # Handle _ separator — take first word
    return classification.split("_")[0]


def structural_similarity(neuron_a: "DecisionNeuron", neuron_b: "DecisionNeuron") -> float:
    """Compute structural similarity between two neurons.

    3 dimensions:
    - slot_overlap: Jaccard similarity of slot names
    - tool_match: 1.0 if same primary tool, else 0.0
    - chain_length_sim: 1 - |len_a - len_b| / max(len_a, len_b)

    Returns weighted score in [0, 1].
    """
    # Slot overlap (Jaccard)
    slots_a = set(neuron_a.slot_schema.keys())
    slots_b = set(neuron_b.slot_schema.keys())
    if slots_a or slots_b:
        slot_overlap = len(slots_a & slots_b) / len(slots_a | slots_b)
    else:
        slot_overlap = 1.0  # both have no slots

    # Tool match
    tool_match = 1.0 if neuron_a.decision_chain.tool == neuron_b.decision_chain.tool else 0.0

    # Chain length similarity
    len_a = len(neuron_a.decision_chain.steps)
    len_b = len(neuron_b.decision_chain.steps)
    max_len = max(len_a, len_b, 1)
    chain_length_sim = 1.0 - abs(len_a - len_b) / max_len

    return 0.4 * slot_overlap + 0.4 * tool_match + 0.2 * chain_length_sim


def create_neuron(
    classification: str,
    tool: str,
    query_embedding: np.ndarray,
    slots: Optional[Dict[str, SlotRule]] = None,
) -> DecisionNeuron:
    """Factory: create a new Stage 0 neuron from a first observation."""
    chain = DecisionChain(
        tool=tool,
        slots=slots or {},
        steps=[DecisionStep(tool=tool)],
    )
    return DecisionNeuron(
        id=str(uuid.uuid4())[:12],
        pattern_embedding=query_embedding.copy(),
        classification=classification,
        decision_chain=chain,
        slot_schema=dict(slots) if slots else {},
        exemplar_embeddings=[query_embedding.copy()],
    )


def create_multi_step_neuron(
    classification: str,
    steps: List[DecisionStep],
    query_embedding: np.ndarray,
    slots: Optional[Dict[str, SlotRule]] = None,
) -> DecisionNeuron:
    """Factory: create a new Stage 0 multi-step neuron.

    Args:
        classification: Task type (e.g. "compare_products").
        steps: List of DecisionStep with dependencies.
        query_embedding: Embedding of the first query.
        slots: Query-level slot rules.
    """
    primary_tool = steps[0].tool if steps else "unknown"
    chain = DecisionChain(
        tool=primary_tool,
        slots=slots or {},
        steps=steps,
    )
    return DecisionNeuron(
        id=str(uuid.uuid4())[:12],
        pattern_embedding=query_embedding.copy(),
        classification=classification,
        decision_chain=chain,
        slot_schema=dict(slots) if slots else {},
        exemplar_embeddings=[query_embedding.copy()],
    )
