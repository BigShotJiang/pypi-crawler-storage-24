"""Zero-config SQLite storage backend."""

import json
import sqlite3
import numpy as np
from pathlib import Path
from typing import Any, Dict, List, Optional

from .base import StorageBackend


class SQLiteBackend(StorageBackend):
    """Default storage: single SQLite file, zero external dependencies."""

    def __init__(self, db_path: str = "hga_memory.db"):
        self.db_path = db_path
        self._conn: Optional[sqlite3.Connection] = None
        self._connect()
        self.init_schema()

    def _connect(self) -> None:
        self._conn = sqlite3.connect(self.db_path, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA synchronous=NORMAL")

    @property
    def conn(self) -> sqlite3.Connection:
        if self._conn is None:
            self._connect()
        return self._conn

    def init_schema(self) -> None:
        self.conn.executescript("""
            CREATE TABLE IF NOT EXISTS items (
                id TEXT PRIMARY KEY,
                text TEXT NOT NULL,
                embedding BLOB NOT NULL,
                metadata TEXT DEFAULT '{}',
                sensitivity TEXT DEFAULT 'low',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );

            CREATE TABLE IF NOT EXISTS dv (
                key TEXT PRIMARY KEY,
                payload TEXT NOT NULL,
                hash TEXT NOT NULL,
                policy_tag TEXT DEFAULT 'public',
                metadata TEXT DEFAULT '{}',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );

            CREATE TABLE IF NOT EXISTS codebook (
                id INTEGER PRIMARY KEY CHECK (id = 1),
                centroids BLOB NOT NULL,
                assignments TEXT NOT NULL,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );

            CREATE TABLE IF NOT EXISTS neurons (
                id TEXT PRIMARY KEY,
                data TEXT NOT NULL,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );

            CREATE INDEX IF NOT EXISTS idx_items_sensitivity ON items(sensitivity);
            CREATE INDEX IF NOT EXISTS idx_dv_hash ON dv(hash);
            CREATE INDEX IF NOT EXISTS idx_dv_policy ON dv(policy_tag);
        """)
        self.conn.commit()

    # --- Items ---

    def insert_item(self, item_id: str, text: str, embedding: np.ndarray,
                    metadata: Optional[Dict] = None, sensitivity: str = "low") -> None:
        emb_blob = embedding.astype(np.float32).tobytes()
        meta_json = json.dumps(metadata or {})
        self.conn.execute(
            "INSERT OR REPLACE INTO items (id, text, embedding, metadata, sensitivity) VALUES (?, ?, ?, ?, ?)",
            (item_id, text, emb_blob, meta_json, sensitivity)
        )
        self.conn.commit()

    def get_item(self, item_id: str) -> Optional[Dict]:
        row = self.conn.execute("SELECT * FROM items WHERE id = ?", (item_id,)).fetchone()
        if row is None:
            return None
        return self._row_to_item(row)

    def get_all_items(self) -> List[Dict]:
        rows = self.conn.execute("SELECT * FROM items ORDER BY created_at").fetchall()
        return [self._row_to_item(r) for r in rows]

    def get_all_embeddings(self) -> tuple:
        rows = self.conn.execute("SELECT id, embedding FROM items").fetchall()
        if not rows:
            return [], np.empty((0, 0))
        ids = [r["id"] for r in rows]
        embs = np.array([np.frombuffer(r["embedding"], dtype=np.float32) for r in rows])
        return ids, embs

    def item_count(self) -> int:
        row = self.conn.execute("SELECT COUNT(*) as cnt FROM items").fetchone()
        return row["cnt"]

    def _row_to_item(self, row) -> Dict:
        return {
            "id": row["id"],
            "text": row["text"],
            "embedding": np.frombuffer(row["embedding"], dtype=np.float32),
            "metadata": json.loads(row["metadata"]),
            "sensitivity": row["sensitivity"],
            "created_at": row["created_at"],
        }

    # --- DV ---

    def insert_dv(self, key: str, payload: Any, hash_val: str,
                  policy_tag: str = "public", metadata: Optional[Dict] = None) -> None:
        payload_json = json.dumps(payload) if not isinstance(payload, str) else payload
        meta_json = json.dumps(metadata or {})
        self.conn.execute(
            "INSERT OR REPLACE INTO dv (key, payload, hash, policy_tag, metadata) VALUES (?, ?, ?, ?, ?)",
            (key, payload_json, hash_val, policy_tag, meta_json)
        )
        self.conn.commit()

    def get_dv(self, key: str) -> Optional[Dict]:
        row = self.conn.execute("SELECT * FROM dv WHERE key = ?", (key,)).fetchone()
        if row is None:
            return None
        return self._row_to_dv(row)

    def search_dv(self, query: str) -> List[Dict]:
        rows = self.conn.execute(
            "SELECT * FROM dv WHERE key LIKE ? OR payload LIKE ?",
            (f"%{query}%", f"%{query}%")
        ).fetchall()
        return [self._row_to_dv(r) for r in rows]

    def _row_to_dv(self, row) -> Dict:
        payload = row["payload"]
        try:
            payload = json.loads(payload)
        except (json.JSONDecodeError, TypeError):
            pass
        return {
            "key": row["key"],
            "payload": payload,
            "hash": row["hash"],
            "policy_tag": row["policy_tag"],
            "metadata": json.loads(row["metadata"]),
            "created_at": row["created_at"],
        }

    # --- Codebook ---

    def save_codebook(self, centroids: np.ndarray, assignments: Dict) -> None:
        blob = centroids.astype(np.float32).tobytes()
        assign_json = json.dumps({str(k): v for k, v in assignments.items()})
        self.conn.execute(
            """INSERT OR REPLACE INTO codebook (id, centroids, assignments, updated_at)
               VALUES (1, ?, ?, CURRENT_TIMESTAMP)""",
            (blob, assign_json)
        )
        self.conn.commit()

    def load_codebook(self) -> Optional[tuple]:
        row = self.conn.execute("SELECT * FROM codebook WHERE id = 1").fetchone()
        if row is None:
            return None
        centroids = np.frombuffer(row["centroids"], dtype=np.float32)
        assignments = json.loads(row["assignments"])
        assignments = {int(k): v for k, v in assignments.items()}
        return centroids, assignments

    # --- Neurons ---

    def save_neuron(self, neuron_id: str, data_json: str) -> None:
        self.conn.execute(
            "INSERT OR REPLACE INTO neurons (id, data, updated_at) VALUES (?, ?, CURRENT_TIMESTAMP)",
            (neuron_id, data_json)
        )
        self.conn.commit()

    def get_neuron(self, neuron_id: str) -> Optional[str]:
        row = self.conn.execute("SELECT data FROM neurons WHERE id = ?", (neuron_id,)).fetchone()
        return row["data"] if row else None

    def get_all_neurons(self) -> List[str]:
        rows = self.conn.execute("SELECT data FROM neurons").fetchall()
        return [row["data"] for row in rows]

    def delete_neuron(self, neuron_id: str) -> None:
        self.conn.execute("DELETE FROM neurons WHERE id = ?", (neuron_id,))
        self.conn.commit()

    def close(self) -> None:
        if self._conn:
            self._conn.close()
            self._conn = None
