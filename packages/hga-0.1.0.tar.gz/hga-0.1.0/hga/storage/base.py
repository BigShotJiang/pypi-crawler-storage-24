"""Abstract storage backend interface."""

from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional
import numpy as np


class StorageBackend(ABC):
    """Abstract base for storage backends (SQLite, Postgres, etc.)."""

    @abstractmethod
    def init_schema(self) -> None:
        """Create tables if they don't exist."""

    # --- Items (L1 memory) ---
    @abstractmethod
    def insert_item(self, item_id: str, text: str, embedding: np.ndarray,
                    metadata: Optional[Dict] = None, sensitivity: str = "low") -> None:
        ...

    @abstractmethod
    def get_item(self, item_id: str) -> Optional[Dict]:
        ...

    @abstractmethod
    def get_all_items(self) -> List[Dict]:
        ...

    @abstractmethod
    def get_all_embeddings(self) -> tuple:
        """Return (ids, embeddings_matrix) for all items."""

    @abstractmethod
    def item_count(self) -> int:
        ...

    # --- DV (L2 exact store) ---
    @abstractmethod
    def insert_dv(self, key: str, payload: Any, hash_val: str,
                  policy_tag: str = "public", metadata: Optional[Dict] = None) -> None:
        ...

    @abstractmethod
    def get_dv(self, key: str) -> Optional[Dict]:
        ...

    @abstractmethod
    def search_dv(self, query: str) -> List[Dict]:
        """Search DV by key prefix or payload content."""

    # --- Codebook ---
    @abstractmethod
    def save_codebook(self, centroids: np.ndarray, assignments: Dict) -> None:
        ...

    @abstractmethod
    def load_codebook(self) -> Optional[tuple]:
        """Return (centroids, assignments) or None."""

    # --- Neurons (L3) ---
    @abstractmethod
    def save_neuron(self, neuron_id: str, data_json: str) -> None:
        ...

    @abstractmethod
    def get_neuron(self, neuron_id: str) -> Optional[str]:
        """Return JSON string or None."""

    @abstractmethod
    def get_all_neurons(self) -> List[str]:
        """Return list of JSON strings."""

    @abstractmethod
    def delete_neuron(self, neuron_id: str) -> None:
        ...
