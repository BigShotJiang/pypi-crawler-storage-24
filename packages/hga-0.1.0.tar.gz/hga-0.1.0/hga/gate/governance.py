"""Governance Gate — Automatic path selection for query routing.

Decides which execution path to use based on:
- L1 confidence & margin signals
- L2 sensitivity detection
- L3 neuron stage & edge weight (when available)
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional

import numpy as np

from ..l1.retrieval import L1Result
from ..l2.vault import DVRecord, detect_sensitivity


# ─── Constants ───────────────────────────────────────────────────────────────

ALPHA = 0.6           # minimum confidence threshold
DELTA_MIN = 0.01      # minimum margin for VerifyPath
SENSITIVITY_OVERRIDE_THRESHOLD = -1.0  # edge weight below this → DeterministicPath


# ─── Path Enum ───────────────────────────────────────────────────────────────

class ExecutionPath(str, Enum):
    """All possible execution paths through the system."""
    STAGE0 = "Stage0Path"             # Full LLM call needed
    FAST_SEMANTIC = "FastSemanticPath" # L1 retrieval + LLM with context
    VERIFY = "VerifyPath"             # L3 replay + LLM verification
    STAGE3 = "Stage3Path"             # L3 replay, no LLM needed
    DETERMINISTIC = "DeterministicPath"  # L2 exact lookup, no LLM


# ─── Gate Decision ───────────────────────────────────────────────────────────

@dataclass
class GateDecision:
    """Output of the Governance Gate."""
    path: ExecutionPath
    confidence: float = 0.0
    margin: float = 0.0
    sensitivity: str = "low"
    context: List[Dict] = field(default_factory=list)  # retrieved items to send to LLM
    l2_record: Optional[Dict] = None                    # DV payload if deterministic
    neuron_id: Optional[str] = None                     # L3 neuron if matched
    neuron_stage: int = -1
    edge_weight: float = 0.0
    reason: str = ""                                     # human-readable explanation

    @property
    def llm_needed(self) -> bool:
        """Whether this path requires an LLM call."""
        return self.path in (ExecutionPath.STAGE0, ExecutionPath.FAST_SEMANTIC, ExecutionPath.VERIFY)

    @property
    def estimated_tokens(self) -> int:
        """Rough token cost estimate per path."""
        costs = {
            ExecutionPath.STAGE0: 500,
            ExecutionPath.FAST_SEMANTIC: 200,
            ExecutionPath.VERIFY: 50,
            ExecutionPath.STAGE3: 0,
            ExecutionPath.DETERMINISTIC: 0,
        }
        return costs[self.path]


# ─── L3 Stub (for Sprint 2 — real L3 comes in Sprint 3) ─────────────────────

@dataclass
class L3Signal:
    """Signal from L3 layer."""
    neuron_id: Optional[str] = None
    stage: int = -1                   # -1 = no neuron
    edge_weight: float = 0.0
    task_type: Optional[str] = None
    similarity: float = 0.0           # cosine sim between query and neuron centroid


# ─── Governance Gate ─────────────────────────────────────────────────────────

class GovernanceGate:
    """Routes queries to the optimal execution path.

    Decision logic (from paper):
    1. High sensitivity OR very negative edge weight → DeterministicPath
    2. Stage 3 neuron + high confidence → Stage3Path (LLM-free)
    3. Stage 2 neuron + confidence + margin → VerifyPath
    4. Stage 1+ neuron + confidence → FastSemanticPath
    5. No neuron or low confidence → Stage0Path
    """

    def __init__(self, alpha: float = ALPHA, delta_min: float = DELTA_MIN):
        self.alpha = alpha
        self.delta_min = delta_min

    def decide(
        self,
        query: str,
        l1_result: L1Result,
        l2_record: Optional[DVRecord] = None,
        l3_signal: Optional[L3Signal] = None,
        sensitivity: Optional[str] = None,
    ) -> GateDecision:
        """Make a routing decision.

        Args:
            query: The user's query text.
            l1_result: L1 semantic retrieval results.
            l2_record: L2 exact match record (if found).
            l3_signal: L3 neuron signal (if matched).
            sensitivity: Override sensitivity. None = auto-detect from query.

        Returns:
            GateDecision with selected path and context.
        """
        if sensitivity is None:
            sensitivity = detect_sensitivity(query)

        conf = l1_result.confidence
        margin = l1_result.margin

        # Extract L3 signals
        stage = l3_signal.stage if l3_signal else -1
        w = l3_signal.edge_weight if l3_signal else 0.0
        neuron_id = l3_signal.neuron_id if l3_signal else None
        l3_sim = l3_signal.similarity if l3_signal else 0.0

        # For L3 paths, use max(L1 confidence, L3 similarity) as effective confidence
        # A mature neuron with high similarity should be trusted even if L1 conf is low
        effective_conf = max(conf, l3_sim) if stage >= 1 else conf

        # Build context from L1 results
        context = [
            {"text": r.text, "score": r.score, "id": r.item_id}
            for r in l1_result.results
        ]

        # Build L2 payload
        l2_payload = None
        if l2_record:
            l2_payload = {
                "key": l2_record.key,
                "payload": l2_record.payload,
            }

        # ── Decision Logic ──────────────────────────────────────────────

        # Rule 1: High sensitivity or very negative edge weight → Deterministic
        if sensitivity == "high" or w < SENSITIVITY_OVERRIDE_THRESHOLD:
            if l2_record:
                return GateDecision(
                    path=ExecutionPath.DETERMINISTIC,
                    confidence=1.0,
                    margin=margin,
                    sensitivity=sensitivity,
                    l2_record=l2_payload,
                    neuron_id=neuron_id,
                    neuron_stage=stage,
                    edge_weight=w,
                    reason=f"DeterministicPath: sensitivity={sensitivity}" + (f", w={w:.1f}" if w < SENSITIVITY_OVERRIDE_THRESHOLD else ""),
                )
            # High sensitivity but no L2 record → Stage0 with caution
            return GateDecision(
                path=ExecutionPath.STAGE0,
                confidence=conf,
                margin=margin,
                sensitivity=sensitivity,
                context=context,
                neuron_id=neuron_id,
                neuron_stage=stage,
                edge_weight=w,
                reason=f"Stage0Path: high sensitivity but no L2 record",
            )

        # Rule 1b: L2 exact match found → Deterministic (exact recall always wins)
        if l2_record:
            return GateDecision(
                path=ExecutionPath.DETERMINISTIC,
                confidence=1.0,
                margin=margin,
                sensitivity=sensitivity,
                l2_record=l2_payload,
                neuron_id=neuron_id,
                neuron_stage=stage,
                edge_weight=w,
                reason=f"DeterministicPath: L2 exact record found",
            )

        # Rule 2: Stage 3 + high confidence (L1 or L3) → LLM-free replay
        if stage == 3 and effective_conf >= self.alpha:
            return GateDecision(
                path=ExecutionPath.STAGE3,
                confidence=effective_conf,
                margin=margin,
                sensitivity=sensitivity,
                context=context,
                neuron_id=neuron_id,
                neuron_stage=stage,
                edge_weight=w,
                reason=f"Stage3Path: stage=3, conf={effective_conf:.2f}≥{self.alpha} (l1={conf:.2f}, l3_sim={l3_sim:.2f})",
            )

        # Rule 3: Stage 2 + confidence → Verify (replay + LLM verification)
        # No margin check: VerifyPath uses L3 replay, not L1 retrieval
        if stage == 2 and effective_conf >= self.alpha:
            return GateDecision(
                path=ExecutionPath.VERIFY,
                confidence=effective_conf,
                margin=margin,
                sensitivity=sensitivity,
                context=context,
                neuron_id=neuron_id,
                neuron_stage=stage,
                edge_weight=w,
                reason=f"VerifyPath: stage=2, conf={effective_conf:.2f}",
            )

        # Rule 4: Stage 1+ + confidence → Fast semantic
        if stage >= 1 and effective_conf >= self.alpha:
            return GateDecision(
                path=ExecutionPath.FAST_SEMANTIC,
                confidence=effective_conf,
                margin=margin,
                sensitivity=sensitivity,
                context=context,
                neuron_id=neuron_id,
                neuron_stage=stage,
                edge_weight=w,
                reason=f"FastSemanticPath: stage={stage}, conf={effective_conf:.2f}",
            )

        # Rule 5: Good L1 confidence but no L3 neuron → Fast semantic
        if conf >= self.alpha and l1_result.results:
            return GateDecision(
                path=ExecutionPath.FAST_SEMANTIC,
                confidence=conf,
                margin=margin,
                sensitivity=sensitivity,
                context=context,
                neuron_id=neuron_id,
                neuron_stage=stage,
                edge_weight=w,
                reason=f"FastSemanticPath: no neuron, but conf={conf:.2f}≥{self.alpha}",
            )

        # Default: Stage 0 — full LLM
        return GateDecision(
            path=ExecutionPath.STAGE0,
            confidence=conf,
            margin=margin,
            sensitivity=sensitivity,
            context=context,
            neuron_id=neuron_id,
            neuron_stage=stage,
            edge_weight=w,
            reason=f"Stage0Path: conf={conf:.2f}<{self.alpha}, no match",
        )
