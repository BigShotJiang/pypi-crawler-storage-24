"""Deterministic Vault: exact key-value store with SHA-256 integrity and policy tags."""

import hashlib
import json
import re
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional


class PolicyTag(str, Enum):
    PUBLIC = "public"
    INTERNAL = "internal"
    SENSITIVE = "sensitive"
    RESTRICTED = "restricted"


@dataclass
class DVRecord:
    key: str
    payload: Any
    hash: str
    policy_tag: PolicyTag = PolicyTag.PUBLIC
    metadata: Dict = field(default_factory=dict)
    created_at: Optional[str] = None


# Patterns that suggest structured/sensitive data → L2
_L2_PATTERNS = [
    re.compile(r'[A-Z]{2,}-\d+'),          # TX-4821, ID-001
    re.compile(r'\d{4}-\d{2}-\d{2}'),       # dates
    re.compile(r'\$[\d,]+\.?\d*'),           # money
    re.compile(r'(?i)password|secret|key|token|api.?key'),  # sensitive keywords
]


def detect_sensitivity(text: str) -> str:
    """Heuristic: structured data → 'high', free text → 'low'."""
    for p in _L2_PATTERNS:
        if p.search(text):
            return "high"
    return "low"


def compute_hash(payload: Any) -> str:
    """SHA-256 hash of payload."""
    if isinstance(payload, str):
        data = payload.encode("utf-8")
    else:
        data = json.dumps(payload, sort_keys=True, default=str).encode("utf-8")
    return hashlib.sha256(data).hexdigest()


class DeterministicVault:
    """L2: Exact key-value store with hash integrity verification."""

    def __init__(self, storage_backend=None):
        self._backend = storage_backend
        self._local: Dict[str, DVRecord] = {}  # in-memory fallback

    def write(self, key: str, payload: Any, policy_tag: str = "public",
              metadata: Optional[Dict] = None) -> DVRecord:
        """Store a record. Returns the created DVRecord."""
        h = compute_hash(payload)
        tag = PolicyTag(policy_tag) if isinstance(policy_tag, str) else policy_tag
        record = DVRecord(
            key=key,
            payload=payload,
            hash=h,
            policy_tag=tag,
            metadata=metadata or {},
        )
        self._local[key] = record

        if self._backend:
            self._backend.insert_dv(key, payload, h, tag.value, metadata)

        return record

    def read(self, key: str) -> Optional[DVRecord]:
        """Exact lookup by key. Verifies hash integrity."""
        # Check local cache first
        if key in self._local:
            record = self._local[key]
            if self._verify(record):
                return record

        # Check backend
        if self._backend:
            data = self._backend.get_dv(key)
            if data:
                record = DVRecord(
                    key=data["key"],
                    payload=data["payload"],
                    hash=data["hash"],
                    policy_tag=PolicyTag(data["policy_tag"]),
                    metadata=data.get("metadata", {}),
                    created_at=data.get("created_at"),
                )
                if self._verify(record):
                    self._local[key] = record
                    return record

        return None

    def search(self, query: str) -> List[DVRecord]:
        """Search by key prefix or payload content."""
        results = []

        # Local search
        for key, record in self._local.items():
            if query in key or (isinstance(record.payload, str) and query in record.payload):
                results.append(record)

        # Backend search (dedup by key)
        if self._backend:
            found_keys = {r.key for r in results}
            for data in self._backend.search_dv(query):
                if data["key"] not in found_keys:
                    results.append(DVRecord(
                        key=data["key"],
                        payload=data["payload"],
                        hash=data["hash"],
                        policy_tag=PolicyTag(data["policy_tag"]),
                        metadata=data.get("metadata", {}),
                        created_at=data.get("created_at"),
                    ))

        return results

    def sanitize(self, record: DVRecord) -> Dict:
        """Strip policy tag before LLM injection. Returns safe dict."""
        return {
            "key": record.key,
            "payload": record.payload,
            "metadata": record.metadata,
        }

    def _verify(self, record: DVRecord) -> bool:
        """Verify hash integrity."""
        return compute_hash(record.payload) == record.hash

    @property
    def count(self) -> int:
        return len(self._local)
