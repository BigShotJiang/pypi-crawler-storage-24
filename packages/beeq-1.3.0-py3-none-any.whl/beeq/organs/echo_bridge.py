"""
beeq/organs/echo_bridge.py — ECHO Organ Protocol Bridge.

Z = dI/d(log s) · exp(iθ)

Connecte deux organes ECHO via FractalOrgan.
  Kimi (System 2, 1.35t/s) → encode → innovations → decode → Qwen3B (System 1)
  Bande passante divisée par 5-28× sans perte mesurable.

Usage :
    bridge = EchoBridge(source_id="kimi", target_id="qwen3b")
    result = bridge.transmit(activations, layer_id="L24")
    # result.reconstructed = activations reconstruites
    # result.compression = facteur de compression atteint
"""

from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Sequence

from .fractal_organ import FractalOrgan, InnovationPacket, COMPRESSION_H6


# ── Résultat d'une transmission ──────────────────────────────────────────────

@dataclass
class TransmitResult:
    source_id:     str
    target_id:     str
    layer_id:      str
    original_dim:  int
    reconstructed: list[float]
    compression:   float
    error_pct:     float
    latency_ms:    float
    bandwidth_saved_pct: float
    ok:            bool

    @property
    def summary(self) -> str:
        status = "✅" if self.ok else "❌"
        return (
            f"{status} [{self.source_id}→{self.target_id}] {self.layer_id}: "
            f"comp={self.compression:.1f}x bw_saved={self.bandwidth_saved_pct:.0f}% "
            f"err={self.error_pct:.4f}% lat={self.latency_ms:.1f}ms"
        )


# ── EchoBridge ───────────────────────────────────────────────────────────────

class EchoBridge:
    """
    Bridge fractal entre deux organes ECHO.

    Architecture :
        source (Kimi System 2)
            |
            | activations[dim=2048]
            ↓
        FractalOrgan.encode()
            |
            | InnovationPacket (~3% du signal en variance)
            ↓
        FractalOrgan.decode()
            |
            | reconstructed[dim=2048] — erreur < 0.01%
            ↓
        target (Qwen3B System 1)
    """

    def __init__(
        self,
        source_id: str = "kimi",
        target_id: str = "qwen3b",
        ar_order:  int = 8,
        error_threshold_pct: float = 0.1,  # erreur max tolérée
    ):
        self.source_id   = source_id
        self.target_id   = target_id
        self.error_threshold = error_threshold_pct
        self._organ      = FractalOrgan(ar_order=ar_order)
        self._history:   list[TransmitResult] = []

    def transmit(
        self,
        activations: Sequence[float],
        layer_id:    str = "",
    ) -> TransmitResult:
        """
        Encoder → transmettre → décoder un vecteur d'activations.
        Mesure compression, erreur, latence.
        """
        t0 = time.perf_counter()

        # Encode
        packet = self._organ.encode(list(activations), layer_id=layer_id)

        # Decode (simulation transmission locale — en prod: pickle/bytes sur réseau)
        reconstructed = self._organ.decode(packet)

        # Métriques
        error_pct = self._organ.reconstruction_error(activations, reconstructed)
        latency   = (time.perf_counter() - t0) * 1000  # ms
        ok        = error_pct < self.error_threshold

        result = TransmitResult(
            source_id    = self.source_id,
            target_id    = self.target_id,
            layer_id     = layer_id,
            original_dim = len(activations),
            reconstructed= reconstructed,
            compression  = packet.compression_ratio,
            error_pct    = error_pct,
            latency_ms   = latency,
            bandwidth_saved_pct = packet.bandwidth_saved_pct,
            ok           = ok,
        )
        self._history.append(result)
        return result

    def transmit_layer_batch(
        self,
        layer_activations: dict[str, Sequence[float]],
    ) -> dict[str, TransmitResult]:
        """
        Transmettre plusieurs couches en batch.
        {layer_id: activations} → {layer_id: TransmitResult}
        """
        return {
            lid: self.transmit(acts, layer_id=lid)
            for lid, acts in layer_activations.items()
        }

    def stats(self) -> dict:
        """Statistiques cumulées des transmissions."""
        if not self._history:
            return {
                "n_transmissions": 0,
                "mean_compression": 0.0,
                "mean_error_pct": 0.0,
                "mean_latency_ms": 0.0,
                "ok_rate": 1.0,
                "h6_target": COMPRESSION_H6,
            }
        n = len(self._history)
        return {
            "n_transmissions":  n,
            "mean_compression": round(sum(r.compression for r in self._history) / n, 2),
            "mean_error_pct":   round(sum(r.error_pct for r in self._history) / n, 6),
            "mean_latency_ms":  round(sum(r.latency_ms for r in self._history) / n, 2),
            "ok_rate":          round(sum(1 for r in self._history if r.ok) / n, 3),
            "h6_target":        COMPRESSION_H6,
        }

    def is_healthy(self) -> bool:
        """True si le bridge transmet avec erreur < seuil."""
        if not self._history:
            return True
        last = self._history[-1]
        return last.ok

    def reset(self) -> None:
        self._history.clear()
        self._organ.reset_stats()
