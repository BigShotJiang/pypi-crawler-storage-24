"""BeeQ — The First AI Hive."""
import sys
import os

# Ensure vendored AAP is available if not installed globally
_vendor = os.path.join(os.path.dirname(__file__), "_vendor")
if _vendor not in sys.path:
    sys.path.insert(0, _vendor)

# Verify AAP is importable
try:
    import aap  # noqa: F401
except ImportError:
    raise ImportError(
        "BeeQ requires AAP (Agent Accountability Protocol). "
        "Please run: pip install aap-protocol\n"
        "Or it should be bundled — check your installation."
    )

__version__ = "1.3.0"
__author__  = "Elmadani SALKA"
__url__     = "https://beeq.run"
