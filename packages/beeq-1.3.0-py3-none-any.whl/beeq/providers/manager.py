"""
ProviderManager — selects the right LLM for each task.

LEX §7: données sensibles → local uniquement (brain/IX).
LEX §8: réponse proportionnelle à la tâche.

Hiérarchie des providers:
  brain   → IX local (souverain, 0 coût, CONFIDENTIAL/PRIVATE)
  claude  → Anthropic API (complexe, raisonnement)
  ollama  → Ollama local (routine, fallback)
"""

import asyncio
import os

from .base import BaseProvider, ProviderResponse
from .router import LLMRouter, RoutingDecision


class ProviderManager:

    def __init__(self):
        self._providers: list[BaseProvider] = []
        self._local:     list[BaseProvider] = []
        self.router      = LLMRouter()
        # Auto-register brain si IX disponible
        self._auto_register_brain()

    # ── REGISTRATION ─────────────────────────────────────────────

    def register(self, provider: BaseProvider, local: bool = False) -> None:
        """Enregistrer un provider. brain/ollama sont locaux."""
        # Éviter les doublons par nom
        existing_names = {type(p).__name__ for p in self._providers}
        if type(provider).__name__ in existing_names:
            return
        self._providers.append(provider)
        if local or getattr(provider, "is_local", False):
            self._local.append(provider)

    def _auto_register_brain(self):
        """Auto-register BrainProvider si IX est disponible sur le système."""
        try:
            from .brain import BrainProvider
            p = BrainProvider()
            if p.is_available:
                self.register(p, local=True)
        except Exception:
            pass  # IX non trouvé — pas bloquant

    @property
    def providers(self) -> list[BaseProvider]:
        return self._providers

    # ── ROUTING ───────────────────────────────────────────────────

    def route(self, task: str, context: dict | None = None) -> RoutingDecision:
        """Analyse la tâche et retourne la décision de routing."""
        return self.router.analyze(task, context)

    async def complete_routed(
        self,
        messages:   list[dict],
        task_hint:  str = "",
        context:    dict | None = None,
        **kwargs,
    ) -> ProviderResponse:
        """Complete avec routing automatique selon sensibilité + complexité."""
        task    = task_hint or (messages[-1].get("content", "") if messages else "")
        decision = self.route(task, context)

        # Essayer dans l'ordre: provider préféré → fallback
        for provider_name in [decision.provider_name, decision.fallback]:
            if not provider_name:
                continue
            p = self._find_provider(provider_name)
            if p:
                try:
                    result = await p.complete(messages, **kwargs)
                    # Annoter la décision de routing dans la réponse
                    result.model = f"{result.model} [{decision.reason[:40]}]"
                    return result
                except Exception:
                    continue

        # Fallback ultime: n'importe quel provider disponible
        return await self.complete(messages, **kwargs)

    def _find_provider(self, name: str) -> BaseProvider | None:
        """Trouve un provider par nom (insensible à la casse)."""
        name_l = name.lower()
        for p in self._providers:
            if name_l in type(p).__name__.lower() or name_l == p.name:
                return p
        return None

    # ── COMPLETION ────────────────────────────────────────────────

    async def complete(
        self,
        messages:   list[dict],
        system:     str | None = None,
        max_tokens: int = 4096,
        local_only: bool = False,
    ) -> ProviderResponse:
        """
        Complete avec fallback chain.
        local_only=True → uniquement brain/ollama (LEX §7).
        """
        pool = self._local if local_only else self._providers
        if not pool:
            raise RuntimeError(
                "No LLM provider configured.\n"
                "Run: beeq connect claude  OR  beeq connect ollama\n"
                "IX local: auto-detected if inference-x binary is in PATH."
            )

        for provider in pool:
            try:
                if await provider.health():
                    return await provider.complete(
                        messages, system=system, max_tokens=max_tokens
                    )
            except Exception:
                continue

        raise RuntimeError(
            f"All providers unavailable: {[p.name for p in pool]}"
        )

    # ── HEALTH ────────────────────────────────────────────────────

    async def health_all(self) -> dict[str, bool]:
        """Vérifie tous les providers en parallèle."""
        async def check(p):
            try:
                return p.name, await p.health()
            except Exception:
                return p.name, False
        results = await asyncio.gather(*[check(p) for p in self._providers])
        return dict(results)

    def summary(self) -> dict:
        """Résumé des providers configurés."""
        return {
            "total":    len(self._providers),
            "local":    len(self._local),
            "names":    [p.name for p in self._providers],
            "brain_ix": any(p.name == "brain" for p in self._providers),
        }
