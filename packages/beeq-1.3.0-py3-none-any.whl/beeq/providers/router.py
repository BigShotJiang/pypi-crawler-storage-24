"""
LLM Router — sélection automatique du provider par tâche.

Principe Z: maximiser dI/d(coût) · maintenir θ ≈ 0
  - Tâche sensible → local uniquement (zéro données cloud)
  - Tâche de routine → modèle le moins cher qui réussit
  - Tâche complexe → meilleur modèle disponible

4 critères de sélection, dans l'ordre:
  1. Sensibilité (confidentiel → local forcé, LEX §7)
  2. Complexité (raisonnement → meilleur modèle)
  3. Type (code, recherche, écriture, synthèse)
  4. Coût (priorité au moins cher si qualité équivalente)
"""

import re
from dataclasses import dataclass

# Security — vérification LEX §7 au routing
try:
    from ..security.lex import LEX, LexViolation
    _LEX_AVAILABLE = True
except ImportError:
    _LEX_AVAILABLE = False
from enum import Enum
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .manager import ProviderManager


class Sensitivity(Enum):
    PUBLIC     = 0   # Données publiques — n'importe quel provider
    INTERNAL   = 1   # Données internes — préférer local
    PRIVATE    = 2   # Données personnelles — local fortement recommandé
    CONFIDENTIAL = 3 # Données sensibles — LOCAL UNIQUEMENT (LEX §7)


class Complexity(Enum):
    TRIVIAL  = 0   # Extraction, formatage, classification simple
    SIMPLE   = 1   # Q&A basique, résumé court
    MODERATE = 2   # Analyse, rédaction, recherche
    COMPLEX  = 3   # Raisonnement multi-étape, code complexe, synthèse avancée


class TaskType(Enum):
    CHAT       = "chat"      # Conversation générale
    CODE       = "code"      # Génération ou analyse de code
    RESEARCH   = "research"  # Recherche et synthèse
    WRITING    = "writing"   # Rédaction longue forme
    REASONING  = "reasoning" # Raisonnement logique
    EXTRACTION = "extraction" # Extraction d'info structurée
    ROUTING    = "routing"   # Décision de routing (Queen planning)


@dataclass
class RoutingDecision:
    provider_name: str
    reason: str
    sensitivity: Sensitivity
    complexity: Complexity
    task_type: TaskType
    estimated_tokens: int = 0
    fallback: str = ""


class LLMRouter:
    """
    Selects the optimal LLM provider for each task.

    Integrates with ProviderManager to route:
    - Sensitive data → local Ollama/GGUF only
    - Simple tasks → fastest/cheapest model
    - Complex reasoning → best available model
    - Code tasks → Claude (best code quality) or local codestral
    """

    # CONFIDENTIAL → brain (IX local, LEX §7)
    CONFIDENTIAL_PATTERNS = [
        r"\bconfidentiel", r"\bconfidential", r"\bsecret\b",
        r"\bpassword\b", r"\bapi.?key\b", r"\btoken\b",
        r"\busine\b", r"\bcapteurs?\b", r"\bplc\b",
        r"\bsiham\b", r"\byasmin\b",
    ]
    # PRIVATE → brain préféré, ollama fallback
    SENSITIVE_PATTERNS = [
        r"\bprivate\b", r"\bprivé", r"\bsalaire\b",
        r"\bm[eé]dical", r"\bsant[ée]\b", r"\bdossier\b", r"\bpatient\b",
        r"\bbank\b", r"\biban\b", r"\bpersonnel\b", r"\bemploy[ée]",
        r"\bdonn[ée]es.{0,15}person", r"\brh\b",
    ]

    COMPLEXITY_HIGH = [
        r"\banalyse\b", r"\bcompare\b", r"\braisonne\b", r"\bexplique\b",
        r"\barthicle\b", r"\brédige\b", r"\bsynth[eè]se\b", r"\bplan\b",
        r"\barchitecture\b", r"\bstrat[eé]gie\b", r"\bimplémente\b",
        r"\bcode\b", r"\bpython\b", r"\bscript\b", r"\bfunction\b",
    ]

    CODE_PATTERNS = [
        r"\bpython\b", r"\bjavascript\b", r"\brust\b", r"\bcode\b",
        r"\bfunction\b", r"\bclass\b", r"\bimport\b", r"\bdef \b",
        r"```", r"#include", r"print\(",
    ]

    def analyze(self, task: str, context: dict = None) -> RoutingDecision:
        """
        Analyze a task and return the optimal routing decision.

        Args:
            task: The task description or instruction
            context: Optional dict with hints (sensitivity, budget, etc.)
        """
        ctx = context or {}
        task_lower = task.lower()

        # 1. Sensitivity detection
        sensitivity = self._detect_sensitivity(task_lower, ctx)

        # 2. Task type detection
        task_type = self._detect_type(task_lower)

        # 3. Complexity estimation
        complexity = self._detect_complexity(task_lower, task_type)

        # 4. Provider selection
        provider, reason, fallback = self._select_provider(
            sensitivity, complexity, task_type, ctx
        )

        # 5. Token estimate
        tokens = max(200, len(task.split()) * 4)

        return RoutingDecision(
            provider_name=provider,
            reason=reason,
            sensitivity=sensitivity,
            complexity=complexity,
            task_type=task_type,
            estimated_tokens=tokens,
            fallback=fallback,
        )

    def _detect_sensitivity(self, task: str, ctx: dict) -> Sensitivity:
        # Explicit override from context — formes multiples acceptées
        if ctx.get("sensitivity") == "confidential" or ctx.get("confidential"):
            return Sensitivity.CONFIDENTIAL
        if ctx.get("sensitivity") == "private" or ctx.get("private"):
            return Sensitivity.PRIVATE
        if ctx.get("local_only") or ctx.get("force_local"):
            return Sensitivity.CONFIDENTIAL

        # CONFIDENTIAL patterns d'abord (LEX §7)
        for pattern in self.CONFIDENTIAL_PATTERNS:
            if re.search(pattern, task, re.IGNORECASE):
                return Sensitivity.CONFIDENTIAL

        # PRIVATE patterns
        for pattern in self.SENSITIVE_PATTERNS:
            if re.search(pattern, task, re.IGNORECASE):
                return Sensitivity.PRIVATE

        return Sensitivity.PUBLIC

    def _detect_type(self, task: str) -> TaskType:
        for p in self.CODE_PATTERNS:
            if re.search(p, task, re.IGNORECASE):
                return TaskType.CODE
        if any(w in task for w in ["recherche", "search", "find", "look up", "arxiv"]):
            return TaskType.RESEARCH
        if any(w in task for w in ["écris", "rédige", "write", "article", "rapport"]):
            return TaskType.WRITING
        if any(w in task for w in ["raisonne", "analyse", "compare", "why", "explain"]):
            return TaskType.REASONING
        if any(w in task for w in ["extract", "parse", "liste", "enumère", "json"]):
            return TaskType.EXTRACTION
        if any(w in task for w in ["plan", "decompose", "subtask", "mission"]):
            return TaskType.ROUTING
        return TaskType.CHAT

    def _detect_complexity(self, task: str, task_type: TaskType) -> Complexity:
        # Code and reasoning are inherently complex
        if task_type in (TaskType.CODE, TaskType.REASONING, TaskType.ROUTING):
            return Complexity.COMPLEX
        if task_type == TaskType.WRITING:
            return Complexity.MODERATE

        # Pattern-based
        high_count = sum(1 for p in self.COMPLEXITY_HIGH
                        if re.search(p, task, re.IGNORECASE))
        if high_count >= 2:
            return Complexity.COMPLEX
        if high_count == 1:
            return Complexity.MODERATE

        # Length-based
        words = len(task.split())
        if words > 100:
            return Complexity.MODERATE
        if words > 30:
            return Complexity.SIMPLE

        return Complexity.TRIVIAL

    def _select_provider(
        self,
        sensitivity: Sensitivity,
        complexity: Complexity,
        task_type: TaskType,
        ctx: dict,
    ) -> tuple[str, str, str]:
        """
        Returns (provider_name, reason, fallback_provider).

        Priority:
          CONFIDENTIAL → local only
          COMPLEX + CODE → claude (best code quality)
          COMPLEX + REASONING → claude
          MODERATE → claude with ollama fallback
          SIMPLE/TRIVIAL → ollama first
        """
        # CONFIDENTIAL → brain (IX local) en priorité, ollama en fallback (LEX §7)
        if sensitivity == Sensitivity.CONFIDENTIAL:
            # Vérifier LEX §7 dans le code
            if _LEX_AVAILABLE:
                try:
                    LEX.check_7_confidentiality("confidential", "claude")
                except LexViolation:
                    pass  # Expected — confirme que claude est bien bloqué
            return ("brain", "LEX §7: données confidentielles → IX local souverain", "ollama")

        # PRIVATE → brain (IX local) préféré, ollama fallback
        if sensitivity == Sensitivity.PRIVATE:
            return ("brain",
                    "Données privées → IX local préféré (zéro envoi cloud)",
                    "ollama")

        # COMPLEX tasks → meilleur modèle
        if complexity == Complexity.COMPLEX:
            if task_type == TaskType.CODE:
                return ("claude",
                        "Code complexe → Claude (meilleure qualité code)",
                        "ollama")
            return ("claude",
                    f"Complexité élevée ({task_type.value}) → Claude",
                    "ollama")

        # MODERATE → Claude avec fallback
        if complexity == Complexity.MODERATE:
            return ("claude",
                    f"Complexité modérée → Claude, Ollama fallback",
                    "ollama")

        # SIMPLE/TRIVIAL → Ollama (gratuit, rapide)
        return ("ollama",
                f"Tâche simple → Ollama (gratuit, local)",
                "claude")
