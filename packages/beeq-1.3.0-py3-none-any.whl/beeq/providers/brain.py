"""
beeq/providers/brain.py — Local inference via IX engine.

Z = dI/d(log s) · exp(iθ)
Le provider le plus souverain:
  - 0 API key       — LEX §7: données sensibles ne quittent jamais le périmètre
  - 0 données cloud — CONFIDENTIAL → brain obligatoire
  - 0 coût/token    — vend du SAVOIR, pas du COMPUTE
  - Fonctionne hors-ligne et sur solaire

Architecture: IX --serve → OpenAI-compatible API sur localhost
  Phase 1: GGUF standard (maintenant)
  Phase 2: .brain binaire natif (quand loader IX prêt)

Usage:
    from beeq.providers.brain import BrainProvider
    provider = BrainProvider(model_path="/path/to/model.gguf")
    if await provider.health():
        result = await provider.complete(messages=[{"role":"user","content":"Bonjour"}])
"""

import asyncio
import json
import os
import shutil
import urllib.request
import urllib.error
from pathlib import Path

from .base import BaseProvider, ProviderResponse

# Chemins IX par ordre de priorité (ARCHE, install locale, PATH)
IX_PATHS = [
    "/mnt/data/Z-ANATOMIE/engine/inference-x",
    os.path.expanduser("~/.beeq/bin/inference-x"),
    "inference-x",
]

# Port dédié IX — ne pas conflictes avec ECHO ou autres services
IX_DEFAULT_PORT = 8080


def _find_ix() -> str | None:
    """Trouve le binaire IX sur le système."""
    for p in IX_PATHS:
        if os.path.isfile(p) and os.access(p, os.X_OK):
            return p
    return shutil.which("inference-x")


class BrainProvider(BaseProvider):
    """
    Provider IX local — inférence souveraine via GGUF ou .brain.

    Mode server (recommandé):
        IX démarre en --serve, accepte requêtes OpenAI-compatible.
        Le modèle reste en mémoire entre les appels → rapide.

    Mode subprocess (fallback):
        Chaque appel lance IX, charge le modèle, génère, meurt.
        Plus lent mais plus simple.
    """

    name = "brain"

    def __init__(
        self,
        model_path:  str | None = None,
        ix_binary:   str | None = None,
        z_profile:   str | None = None,
        port:        int        = IX_DEFAULT_PORT,
        mode:        str        = "server",   # "server" | "subprocess"
        auto_start:  bool       = True,
    ):
        # Modèle par défaut: SmolLM2 sur ARCHE ou Qwen3B GGUF
        self.model_path = model_path or self._default_model()
        self.ix_binary  = ix_binary or _find_ix()
        self.z_profile  = z_profile
        self.port       = port
        self.mode       = mode
        self.auto_start = auto_start
        self._server_proc: asyncio.subprocess.Process | None = None

    # ── INTERFACE BaseProvider ────────────────────────────────────

    async def complete(
        self,
        messages:   list[dict],
        system:     str | None = None,
        max_tokens: int = 512,
        **kwargs,
    ) -> ProviderResponse:
        """Inférence locale via IX. Données ne sortent jamais."""

        if self.mode == "server":
            return await self._complete_server(messages, system, max_tokens)
        else:
            return await self._complete_subprocess(messages, system, max_tokens)

    async def health(self) -> bool:
        """Vérifie si IX est disponible (binaire + modèle)."""
        if not self.ix_binary:
            return False
        if self.model_path and not os.path.isfile(self.model_path):
            return False
        if self.mode == "server":
            # Vérifier si le serveur est déjà up
            if await self._server_alive():
                return True
            # Essayer de le démarrer
            if self.auto_start and self.model_path:
                await self.start_server()
                await asyncio.sleep(2)
                return await self._server_alive()
            return False
        return True

    # ── SERVER MODE ───────────────────────────────────────────────

    async def start_server(self) -> bool:
        """Démarre IX en mode --serve sur le port configuré."""
        if not self.ix_binary or not self.model_path:
            return False
        if await self._server_alive():
            return True  # déjà en marche

        # IX: --serve [port] — port optionnel, positionnel
        cmd = [self.ix_binary, self.model_path, "--serve"]
        if self.port != 8080:
            cmd.append(str(self.port))
        if self.z_profile:
            cmd.extend(["--z-profile", self.z_profile])

        self._server_proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.DEVNULL,
            stderr=asyncio.subprocess.DEVNULL,
        )
        # Attendre que le serveur soit prêt (max 10s)
        for _ in range(20):
            await asyncio.sleep(0.5)
            if await self._server_alive():
                return True
        return False

    async def stop_server(self):
        """Arrête le serveur IX."""
        if self._server_proc:
            self._server_proc.terminate()
            try:
                await asyncio.wait_for(self._server_proc.wait(), timeout=5)
            except asyncio.TimeoutError:
                self._server_proc.kill()
            self._server_proc = None

    async def _server_alive(self) -> bool:
        """Vérifie si le serveur IX répond."""
        try:
            url = f"http://localhost:{self.port}/health"
            req = urllib.request.Request(url)
            with urllib.request.urlopen(req, timeout=1) as r:
                return r.status == 200
        except Exception:
            return False

    async def _complete_server(
        self, messages: list[dict], system: str | None, max_tokens: int
    ) -> ProviderResponse:
        """Appel OpenAI-compatible vers le serveur IX local."""

        # Auto-démarrer si nécessaire
        if not await self._server_alive():
            if self.auto_start:
                started = await self.start_server()
                if not started:
                    return self._error_response("IX server failed to start")
            else:
                return self._error_response("IX server not running")

        # Construire la requête OpenAI-compatible
        msgs = []
        if system:
            msgs.append({"role": "system", "content": system})
        msgs.extend(messages)

        payload = json.dumps({
            "model":       Path(self.model_path).stem,
            "messages":    msgs,
            "max_tokens":  max_tokens,
            "temperature": 0.7,
        }).encode()

        try:
            url = f"http://localhost:{self.port}/v1/chat/completions"
            req = urllib.request.Request(
                url, data=payload,
                headers={"Content-Type": "application/json"}
            )
            loop = asyncio.get_event_loop()
            response_data = await loop.run_in_executor(
                None, lambda: self._http_post(url, payload)
            )

            content = (response_data
                       .get("choices", [{}])[0]
                       .get("message", {})
                       .get("content", ""))
            usage   = response_data.get("usage", {})

            return ProviderResponse(
                content=content,
                model=f"ix:{Path(self.model_path).stem}",
                provider="brain",
                input_tokens=usage.get("prompt_tokens", 0),
                output_tokens=usage.get("completion_tokens", 0),
            )

        except Exception as e:
            return self._error_response(str(e))

    def _http_post(self, url: str, payload: bytes) -> dict:
        """Appel HTTP synchrone (exécuté dans executor)."""
        req = urllib.request.Request(
            url, data=payload,
            headers={"Content-Type": "application/json"}
        )
        with urllib.request.urlopen(req, timeout=300) as r:
            return json.loads(r.read())

    # ── SUBPROCESS MODE (fallback) ────────────────────────────────

    async def _complete_subprocess(
        self, messages: list[dict], system: str | None, max_tokens: int
    ) -> ProviderResponse:
        """Lance IX en subprocess — fallback si --serve non disponible."""

        prompt = self._format_prompt(messages, system)
        cmd = [
            self.ix_binary,
            self.model_path,
            "-p", prompt,
            "-n", str(max_tokens),
        ]
        if self.z_profile:
            cmd.extend(["--z-profile", self.z_profile])

        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.DEVNULL,
            )
            stdout, _ = await asyncio.wait_for(
                proc.communicate(), timeout=120
            )
            output = stdout.decode("utf-8", errors="replace").strip()
            # Supprimer le prompt du output
            if prompt in output:
                output = output[len(prompt):].strip()

            return ProviderResponse(
                content=output,
                model=f"ix:{Path(self.model_path).stem}",
                provider="brain",
                output_tokens=len(output.split()),
            )

        except asyncio.TimeoutError:
            return self._error_response("IX timeout (120s)")
        except Exception as e:
            return self._error_response(str(e))

    # ── UTILS ─────────────────────────────────────────────────────

    def _format_prompt(self, messages: list[dict], system: str | None) -> str:
        """Format messages → prompt string (pour mode subprocess)."""
        parts = []
        if system:
            parts.append(f"<|system|>\n{system}\n")
        for msg in messages:
            role    = msg.get("role", "user")
            content = msg.get("content", "")
            if role == "user":
                parts.append(f"<|user|>\n{content}\n")
            elif role == "assistant":
                parts.append(f"<|assistant|>\n{content}\n")
        parts.append("<|assistant|>\n")
        return "".join(parts)

    def _error_response(self, error: str) -> ProviderResponse:
        return ProviderResponse(
            content=f"[BrainProvider error: {error}]",
            model=f"ix:{Path(self.model_path or 'unknown').stem}",
            provider="brain",
        )

    @staticmethod
    def _default_model() -> str | None:
        """Cherche un modèle GGUF disponible sur le système."""
        candidates = [
            "/mnt/data/models/hub/smollm2-135m-instruct-q8_0.gguf",
            "/mnt/data/NOUS/models/Qwen2.5-3B-Instruct-Q4_K_M.gguf",
            os.path.expanduser("~/.beeq/models/default.gguf"),
        ]
        for p in candidates:
            if os.path.isfile(p):
                return p
        return None

    # ── PROPRIÉTÉS ────────────────────────────────────────────────

    @property
    def cost_per_million_tokens(self) -> float:
        return 0.0  # souverain = gratuit

    @property
    def is_local(self) -> bool:
        return True  # données ne sortent JAMAIS — LEX §7

    @property
    def is_available(self) -> bool:
        return self.ix_binary is not None and (
            self.model_path is None or os.path.isfile(self.model_path)
        )

    def __repr__(self) -> str:
        model = Path(self.model_path).name if self.model_path else "no model"
        return f"BrainProvider(model={model}, port={self.port}, mode={self.mode})"


# ── BrainAutoBuilder — pipeline scan → quantize → .brain ─────────────────────

class BrainAutoBuilder:
    """
    Pipeline autonome : scan activations → QuantMap → GGUF mixte → IX serve.

    Z = dI/d(log s) · exp(iθ)

    Usage:
        builder = BrainAutoBuilder()
        result = await builder.build(domain="darija", model_gguf="/path/to/qwen3b.gguf")
        if result["status"] == "ok":
            provider = BrainProvider(model_path=result["brain_path"])
    """

    BRAIN_DIR = Path("/mnt/data/LABO_Z/brains")
    SCAN_DIR  = Path("/mnt/data/LABO_Z/domain_scans")

    def __init__(self):
        self.BRAIN_DIR.mkdir(parents=True, exist_ok=True)

    async def build(
        self,
        domain:      str,
        model_gguf:  str | None = None,
        model_name:  str = "Qwen3B",
        force_rebuild: bool = False,
    ) -> dict:
        """
        Build pipeline complet. Retourne {status, brain_path, ppl_expected, size_gb}.
        """
        import sys
        sys.path.insert(0, str(Path(__file__).parent.parent.parent))
        from brain.quantizer import BrainQuantizer

        # 1. Vérifier si .brain existe déjà
        brain_path = self.BRAIN_DIR / f"{model_name}_{domain}.gguf"
        if brain_path.exists() and not force_rebuild:
            size_gb = brain_path.stat().st_size / 1e9
            return {
                "status": "cached",
                "brain_path": str(brain_path),
                "domain": domain,
                "size_gb": round(size_gb, 2),
                "message": f".brain {domain} déjà disponible ({size_gb:.2f}GB)",
            }

        # 2. Charger le QuantMap v2 (K4 + H activations)
        q = BrainQuantizer()
        qmap = q.quantize_map_v2(domain, model_name)

        # 3. Sauvegarder le QuantMap
        map_path = self.BRAIN_DIR / f"{model_name}_{domain}_quantmap.json"
        qmap.save(map_path)

        # 4. Vérifier si llama-quantize disponible
        llama_quantize = _find_llama_quantize()
        if not llama_quantize:
            return {
                "status": "map_ready",
                "brain_path": None,
                "map_path": str(map_path),
                "domain": domain,
                "expected_size_gb": qmap.expected_size_gb,
                "message": "QuantMap généré. llama-quantize non trouvé — GGUF à produire manuellement.",
                "llama_cmd": _build_llama_cmd(llama_quantize or "llama-quantize", model_gguf or "model.gguf", str(brain_path), qmap),
            }

        # 5. Lancer llama-quantize
        if not model_gguf or not Path(model_gguf).exists():
            return {
                "status": "error",
                "message": f"model_gguf requis et doit exister: {model_gguf}",
                "map_path": str(map_path),
            }

        cmd = _build_llama_cmd(llama_quantize, model_gguf, str(brain_path), qmap)
        proc = await asyncio.create_subprocess_shell(
            cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        _, stderr = await asyncio.wait_for(proc.communicate(), timeout=1800)

        if proc.returncode != 0:
            return {
                "status": "error",
                "message": f"llama-quantize failed: {stderr.decode()[:200]}",
                "cmd": cmd,
            }

        size_gb = brain_path.stat().st_size / 1e9 if brain_path.exists() else 0
        return {
            "status": "ok",
            "brain_path": str(brain_path),
            "domain": domain,
            "size_gb": round(size_gb, 2),
            "expected_size_gb": qmap.expected_size_gb,
            "map_path": str(map_path),
            "message": f".brain {domain} produit ({size_gb:.2f}GB vs {qmap.expected_size_gb:.2f}GB estimé)",
        }

    def get_quantmap(self, domain: str, model_name: str = "Qwen3B") -> dict:
        """Retourne un résumé du QuantMap sans le produire."""
        import sys
        sys.path.insert(0, str(Path(__file__).parent.parent.parent))
        from brain.quantizer import BrainQuantizer
        q = BrainQuantizer()
        qmap = q.quantize_map_v2(domain, model_name)
        return {
            "domain": domain,
            "model": model_name,
            "n_collapse": qmap.n_collapse,
            "n_peak": qmap.n_peak,
            "n_domain": qmap.n_domain,
            "expected_size_gb": qmap.expected_size_gb,
            "summary": qmap.summary(),
        }


def _find_llama_quantize() -> str | None:
    """Cherche llama-quantize dans les chemins standards."""
    candidates = [
        "/mnt/data/llama.cpp/llama-quantize",
        "/mnt/data/llama_cpp_build/bin/llama-quantize",
        shutil.which("llama-quantize") or "",
    ]
    for c in candidates:
        if c and Path(c).exists() and os.access(c, os.X_OK):
            return c
    return None


def _build_llama_cmd(
    llama_quantize: str,
    model_in: str,
    model_out: str,
    qmap: "QuantMap",
) -> str:
    """Construit la commande llama-quantize avec allocation par couche."""
    # Base: Q4_K_M par défaut
    cmd = f"{llama_quantize} {model_in} {model_out} Q4_K_M"
    # Ajouter les overrides par couche depuis le QuantMap
    tensor_args = []
    for spec in qmap.layers:
        if spec.is_collapse:
            quant = "Q8_0"
        elif spec.is_peak:
            quant = spec.quant_mid  # Q2_K ou Q3_K selon H
        else:
            quant = spec.quant_mid  # allocation optimale K4+H
        tensor_args.append(f"--tensor-type blk.{spec.layer_idx}.ffn={quant}")
    if tensor_args:
        cmd += " " + " ".join(tensor_args[:20])  # premier subset pour tester
    return cmd
