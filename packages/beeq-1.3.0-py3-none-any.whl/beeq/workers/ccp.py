"""
beeq/workers/ccp.py - Cultural Context Protocol Worker.
Z = dI/d(log s) * exp(i*theta)
Auteur: SALKA Elmadani | 24 mars 2026

7e protocole BeeQ. Detecte le contexte culturel, applique aux outputs.

LEX 7 : langue locale (darija/amazigh) -> brain local obligatoire.
"""

from __future__ import annotations
import re
from dataclasses import dataclass, field
from enum import Enum


class Language(str, Enum):
    DARIJA  = "darija"
    AMAZIGH = "amazigh"
    ARABIC  = "arabic"
    FRENCH  = "french"
    ENGLISH = "english"
    UNKNOWN = "unknown"


class Register(str, Enum):
    FORMAL    = "formal"
    FAMILIAR  = "familiar"
    TECHNICAL = "technical"


# Caracteres arabes Unicode
_ARABIC_CHARS = re.compile("[؀-ۿ]")

# Marqueurs darija - sans word-boundary (incompatible Unicode arabe)
_DARIJA_WORDS = [
    "واش",      # واش
    "كيفاش",  # كيفاش
    "بزاف",  # بزاف
    "مزيان",  # مزيان
    "ديالي",  # ديالي
    "بغيت",  # بغيت
    "كاين",  # كاين
    "داير",  # داير
    "دابا",  # دابا
    "هاد",        # هاد
    "غادي",  # غادي
    "باغي",  # باغي
    "شوية",  # شوية
    "نمشي",  # نمشي
    "صافي",  # صافي
]
_DARIJA_MARKERS = re.compile("|".join(_DARIJA_WORDS), re.IGNORECASE)

_AMAZIGH_MARKERS = re.compile(
    r"(?<![a-z])(azul|tafat|imazighen|tamazight|tamurt|yella|netta)(?![a-z])",
    re.IGNORECASE,
)

_TIFINAGH = re.compile("[ⴰ-⵿]")

# Sensibilites
_SENS_RELIGION = re.compile(
    "الله|حلال|حرام"
    "|(?<![a-z])(allah|islam|halal|haram|prayer|mosque|ramadan)(?![a-z])",
    re.IGNORECASE,
)
_SENS_GENDER = re.compile(
    "امرأة|رجل"
    "|(?<![a-z])(femme|homme|woman|man|genre|gender|droits|egalite)(?![a-z])",
    re.IGNORECASE,
)
_SENS_POLITIQUE = re.compile(
    "سياسة|حكومة"
    "|(?<![a-z])(roi|gouvernement|politique|election|droits)(?![a-z])",
    re.IGNORECASE,
)
_SENS_FAMILLE = re.compile(
    "عائلة|زواج"
    "|(?<![a-z])(famille|mariage|divorce|parents|enfants)(?![a-z])",
    re.IGNORECASE,
)

_SENSITIVITY_PATTERNS = {
    "religion":  _SENS_RELIGION,
    "gender":    _SENS_GENDER,
    "politique": _SENS_POLITIQUE,
    "famille":   _SENS_FAMILLE,
}

_MOROCCAN_NORMS = {
    "salutation":      "assalam alaykoum / marhaba",
    "refus":           "indirect - suggerer une alternative",
    "hierarchie":      "respecter les aines et autorites",
    "hospitalite":     "partager le repas / le the",
    "confidentialite": "famille et communaute priment",
}


@dataclass
class CulturalContext:
    language:           Language       = Language.UNKNOWN
    register:           Register       = Register.FORMAL
    sensitivities:      list[str]      = field(default_factory=list)
    norms:              dict[str, str] = field(default_factory=dict)
    requires_local:     bool           = False
    confidence_penalty: float          = 0.0

    def __post_init__(self):
        if self.language in (Language.DARIJA, Language.AMAZIGH):
            self.requires_local = True

    @property
    def is_local_language(self) -> bool:
        return self.language in (Language.DARIJA, Language.AMAZIGH)

    @property
    def effective_confidence_cap(self) -> float:
        return max(0.50, 0.90 - self.confidence_penalty)


class CCPDetector:
    """Detecte le contexte culturel depuis un texte."""

    def detect(self, text: str) -> CulturalContext:
        ctx = CulturalContext()
        ctx.language = self._detect_language(text)
        ctx.register = self._detect_register(text)
        for sense, pattern in _SENSITIVITY_PATTERNS.items():
            if pattern.search(text):
                ctx.sensitivities.append(sense)
        if ctx.language in (Language.DARIJA, Language.AMAZIGH, Language.ARABIC):
            ctx.norms = dict(_MOROCCAN_NORMS)
        ctx.requires_local = ctx.is_local_language
        ctx.confidence_penalty = len(ctx.sensitivities) * 0.05
        return ctx

    def _detect_language(self, text: str) -> Language:
        if _TIFINAGH.search(text):
            return Language.AMAZIGH
        has_arabic = bool(_ARABIC_CHARS.search(text))
        if has_arabic:
            if _DARIJA_MARKERS.search(text):
                return Language.DARIJA
            if _AMAZIGH_MARKERS.search(text):
                return Language.AMAZIGH
            return Language.ARABIC
        if _AMAZIGH_MARKERS.search(text):
            return Language.AMAZIGH
        tl = text.lower()
        fr_words = re.findall(
            r"(?<![a-z])(le|la|les|du|des|un|une|est|sont|pour|avec|dans|"
            r"je|tu|il|nous|vous|ils|par|sur|mais|et|donc|"
            r"voudrais|comment|bonjour|veuillez|monsieur|madame|trouver)(?![a-z])",
            tl,
        )
        en_words = re.findall(
            r"(?<![a-z])(the|is|are|was|were|for|with|"
            r"you|he|she|we|they|and|but|to|of|"
            r"would|like|hello|understand|how|works|want|presents|patient)(?![a-z])",
            tl,
        )
        if len(fr_words) > len(en_words):
            return Language.FRENCH
        if len(en_words) > 0:
            return Language.ENGLISH
        return Language.UNKNOWN

    def _detect_register(self, text: str) -> Register:
        tl = text.lower()
        tech = re.findall(
            r"(?<![a-z])(patient|diagnostic|prescription|tribunal|contrat|"
            r"protocol|algorithm|diagnosis|treatment|analysis|specification|"
            r"medication|acute|presents|required|chest|pain)(?![a-z])",
            tl,
        )
        if len(tech) >= 1:
            return Register.TECHNICAL
        formal = re.findall(
            r"(?<![a-z])(monsieur|madame|veuillez|cordialement|priere)(?![a-z])",
            tl,
        )
        if formal:
            return Register.FORMAL
        return Register.FAMILIAR


class CCPFilter:
    """Applique le contexte culturel a l'output d'un worker."""

    def apply(self, text: str, ctx: CulturalContext) -> str:
        if not ctx.sensitivities:
            return text
        senses = ", ".join(ctx.sensitivities)
        return f"[Contexte culturel - sensibilites: {senses}] " + text

    def calibrate_confidence(
        self, confidence: float, ctx: CulturalContext, domain: str = "default"
    ) -> float:
        return min(confidence, ctx.effective_confidence_cap)


class CCPWorker:
    """Cultural Context Protocol Worker."""

    name          = "ccp"
    description   = "Cultural Context Protocol - adapte au contexte langue/culture"
    default_scope = ["detect:culture", "filter:cultural", "calibrate:confidence"]

    def __init__(self):
        self.detector = CCPDetector()
        self.filter_  = CCPFilter()

    def detect(self, text: str) -> CulturalContext:
        return self.detector.detect(text)

    def apply_to_output(self, output: str, mission: str):
        ctx = self.detector.detect(mission)
        filtered = self.filter_.apply(output, ctx)
        return filtered, ctx

    def get_router_override(self, ctx: CulturalContext) -> dict | None:
        if ctx.requires_local:
            return {
                "force_provider": "brain",
                "reason": f"LEX 7 - langue locale ({ctx.language.value}) - 0 cloud",
                "lex_article": "7",
            }
        return None

    def confidence_cap(self, ctx: CulturalContext, domain: str = "default") -> float:
        return ctx.effective_confidence_cap
