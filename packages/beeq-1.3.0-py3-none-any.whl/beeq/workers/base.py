"""
BaseWorker — base class for all BeeQ workers.

Each worker has:
  - A name and specialization
  - An AAP identity (signed by human supervisor)
  - An authorized scope it cannot exceed
  - A connection to the provider manager

LEX §6: freedom is real within the authorized scope.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

# Security
from ..security.sanitizer import InputSanitizer, ExternalData
from ..security.budget    import MissionBudget

_WORKER_SANITIZER = InputSanitizer()

if TYPE_CHECKING:
    from ..providers.manager import ProviderManager
    from ..governance.hive import HiveGovernance, WorkerIdentity


@dataclass
class WorkerResult:
    worker:    str
    action:    str
    success:   bool
    output:    str
    artifacts: list[str] = field(default_factory=list)
    error:     str | None = None
    metadata:  dict       = field(default_factory=dict)

    # θ6 — Quantification d'incertitude (Worker-Uncertainty)
    # Obligatoire pour domaines critiques: medical, legal, financial
    # Jamais 1.0 pour ces domaines — la certitude absolue est un mensonge
    confidence:          float        = 1.0    # 0.0 → 1.0
    uncertainty_reason:  str          = ""     # pourquoi pas 1.0
    evidence:            list[str]    = field(default_factory=list)
    limitations:         str          = ""     # ce que cette réponse NE DIT PAS

    @property
    def confidence_label(self) -> str:
        if self.confidence >= 0.9: return "élevée"
        if self.confidence >= 0.7: return "modérée"
        if self.confidence >= 0.5: return "faible"
        return "très faible"

    def with_uncertainty(self, confidence: float, reason: str = "",
                         limitations: str = "") -> "WorkerResult":
        """Fluent builder pour annoter l'incertitude."""
        self.confidence         = max(0.0, min(1.0, confidence))
        self.uncertainty_reason = reason
        self.limitations        = limitations
        return self

    def formatted_output(self) -> str:
        """Output avec annotation d'incertitude si < 0.95."""
        out = self.output
        if self.confidence < 0.95 and self.uncertainty_reason:
            out += f"\n\n---\n⚠️ Confiance {self.confidence_label} ({self.confidence:.0%})"
            out += f"\n{self.uncertainty_reason}"
        if self.limitations:
            out += f"\n\n📌 Limites: {self.limitations}"
        return out


class BaseWorker(ABC):
    """
    Base class for all BeeQ workers.

    Workers are specialized agents that execute specific types of tasks.
    Each worker operates within its authorized scope — it cannot exceed
    what the Queen has delegated. This is enforced by AAP.
    """

    name:        str = "base"
    description: str = "Base worker"
    default_scope: list[str] = []

    def __init__(
        self,
        governance: "HiveGovernance",
        providers:  "ProviderManager",
    ):
        self.governance = governance
        self.providers  = providers
        self._identity: "WorkerIdentity | None" = None

    # ── Security helpers ─────────────────────────────────────────

    def sanitize_web(self, url: str, content: str) -> str:
        """Sanitize web content avant injection dans contexte LLM.
        Appeler sur TOUT contenu venant d'internet.
        """
        data = _WORKER_SANITIZER.from_web(url, content)
        if data.injection_detected:
            # Log dans le résultat pour audit
            self._last_security_alert = data.injection_details
        return data.safe_content()

    def sanitize_uap(self, address: str, value) -> str:
        """Sanitize données UAP avant injection dans contexte LLM."""
        data = _WORKER_SANITIZER.from_uap(address, value)
        return data.safe_content()

    def sanitize_file(self, filename: str, content: str) -> str:
        """Sanitize contenu de fichier uploadé."""
        data = _WORKER_SANITIZER.from_file(filename, content)
        return data.safe_content()

    def register(self) -> None:
        """Register this worker with the governance layer (AAP identity)."""
        self._identity = self.governance.register_worker(
            name=self.name,
            scope=self.default_scope,
        )

    @abstractmethod
    async def execute(self, task: str, context: dict | None = None) -> WorkerResult:
        """Execute a task. Returns WorkerResult."""
        ...

    @property
    def identity(self):
        return self._identity

    def _uncertain_result(self, action: str, output: str,
                           confidence: float, reason: str = "",
                           limitations: str = "") -> WorkerResult:
        """Créer un WorkerResult avec incertitude quantifiée."""
        return WorkerResult(
            worker=self.name, action=action,
            success=True, output=output,
            confidence=confidence,
            uncertainty_reason=reason,
            limitations=limitations,
        )

    def _record(self, action: str, success: bool,
                input_data: bytes = b"", output_data: bytes = b"") -> str:
        """Record action in the consolidated audit chain."""
        
        result = "success" if success else "failure"
        return self.governance.record_action(
            worker_name=self.name,
            action=action,
            result=result,
            input_data=input_data,
            output_data=output_data,
        )
