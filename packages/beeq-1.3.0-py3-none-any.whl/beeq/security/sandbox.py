"""
beeq/security/sandbox.py — Sandbox pour exécution de code généré.

Z = dI/d(log s) · exp(iθ)

θ4: Tout code généré par BeeQ doit passer par le sandbox
avant toute exécution. Jamais directement en production.

PHY §2: L'exécution de code est irréversible.
  rm -rf, DROP TABLE, overwrite — impossibles à annuler.

Architecture:
  1. Analyse statique (rapide, sans exécution)
  2. Sandbox Docker si disponible
  3. Sandbox subprocess restrictif sinon
  4. Review humaine si code à fort impact

Niveaux de risque:
  SAFE      — calculs purs, pas d'IO
  LOW       — lecture fichiers locaux
  MEDIUM    — écriture fichiers, réseau local
  HIGH      — réseau externe, subprocess
  CRITICAL  — system calls, root, rm, DROP
"""

import ast
import os
import re
import shutil
import subprocess
import tempfile
import asyncio
from dataclasses import dataclass
from enum import IntEnum


class RiskLevel(IntEnum):
    SAFE     = 0
    LOW      = 1
    MEDIUM   = 2
    HIGH     = 3
    CRITICAL = 4


@dataclass
class SandboxResult:
    success:       bool
    stdout:        str
    stderr:        str
    risk_level:    RiskLevel
    risk_reasons:  list[str]
    blocked:       bool = False
    block_reason:  str  = ""
    requires_review: bool = False
    exec_time_ms:  float = 0.0


# Patterns critiques — bloqués sans exception
CRITICAL_PATTERNS = [
    (r'\brm\s+-rf\b',                        "rm -rf detected"),
    (r'os\.system\(',                         "os.system() — arbitrary shell"),
    (r'subprocess\.(run|call|Popen)',         "subprocess — arbitrary shell"),
    (r'__import__\([\'"]os[\'"]\)',           "dynamic os import"),
    (r'eval\(',                               "eval() — code injection"),
    (r'exec\(',                               "exec() — code execution"),
    (r'compile\(',                            "compile() — dynamic code"),
    (r'DROP\s+TABLE',                         "SQL DROP TABLE"),
    (r'DROP\s+DATABASE',                      "SQL DROP DATABASE"),
    (r'DELETE\s+FROM.*WHERE\s+1',             "SQL DELETE all rows"),
    (r'TRUNCATE\s+TABLE',                     "SQL TRUNCATE"),
    (r'shutil\.rmtree',                       "shutil.rmtree — recursive delete"),
    (r'os\.remove\(',                         "os.remove() — file deletion"),
    (r'open\(.+[\'"]w[\'"]\)',               "file write"),
    (r'requests\.(post|put|delete|patch)',    "HTTP mutation"),
    (r'socket\.',                             "raw socket"),
    (r'import\s+ctypes',                      "ctypes — native code"),
    (r'import\s+subprocess',                  "subprocess import"),
]

HIGH_PATTERNS = [
    (r'import\s+os\b',                        "os module"),
    (r'import\s+sys\b',                       "sys module"),
    (r'import\s+requests\b',                  "HTTP client"),
    (r'import\s+urllib\b',                    "urllib"),
    (r'import\s+http\b',                      "http module"),
    (r'open\(',                               "file open"),
]


class CodeSandbox:
    """
    Sandbox pour exécuter du code généré par BeeQ.

    Usage:
        sandbox = CodeSandbox()
        result  = await sandbox.execute(code, timeout=10)
        if result.blocked:
            # Ne pas exécuter — expliquer à l'utilisateur
        elif result.requires_review:
            # Demander validation humaine
        else:
            # Utiliser result.stdout
    """

    def __init__(
        self,
        use_docker:       bool = True,
        auto_review_high: bool = True,
        block_critical:   bool = True,
    ):
        self.use_docker       = use_docker and bool(shutil.which("docker"))
        self.auto_review_high = auto_review_high
        self.block_critical   = block_critical

    async def execute(
        self,
        code:    str,
        lang:    str     = "python",
        timeout: int     = 10,
        context: dict | None = None,
    ) -> SandboxResult:
        """
        Analyser et exécuter du code dans un sandbox.

        1. Analyse statique — détecte risques sans exécuter
        2. Si CRITICAL → bloquer
        3. Si HIGH → demander review humaine
        4. Si SAFE/LOW/MEDIUM → exécuter dans sandbox
        """
        risk_level, risk_reasons = self._analyze_static(code, lang)

        # CRITICAL → bloquer systématiquement
        if risk_level == RiskLevel.CRITICAL and self.block_critical:
            return SandboxResult(
                success=False, stdout="", stderr="",
                risk_level=risk_level, risk_reasons=risk_reasons,
                blocked=True,
                block_reason=(
                    f"Code blocked (CRITICAL risk): {', '.join(risk_reasons)}\n"
                    f"BeeQ ne peut pas exécuter ce code automatiquement.\n"
                    f"Raisons: {', '.join(risk_reasons)}"
                ),
            )

        # HIGH → review humaine si configuré
        if risk_level == RiskLevel.HIGH and self.auto_review_high:
            return SandboxResult(
                success=False, stdout="", stderr="",
                risk_level=risk_level, risk_reasons=risk_reasons,
                requires_review=True,
                block_reason=(
                    f"Code requires human review (HIGH risk): {', '.join(risk_reasons)}"
                ),
            )

        # SAFE/LOW/MEDIUM → exécuter
        if lang == "python":
            return await self._exec_python(code, risk_level, risk_reasons, timeout)

        return SandboxResult(
            success=False, stdout="", stderr="Language not supported for execution",
            risk_level=risk_level, risk_reasons=risk_reasons,
        )

    def _analyze_static(self, code: str, lang: str) -> tuple[RiskLevel, list[str]]:
        """Analyse statique — rapide, sans exécution."""
        reasons: list[str] = []
        max_risk = RiskLevel.SAFE

        # Vérifier patterns CRITICAL
        for pattern, label in CRITICAL_PATTERNS:
            if re.search(pattern, code, re.IGNORECASE | re.MULTILINE):
                reasons.append(label)
                max_risk = RiskLevel.CRITICAL

        if max_risk == RiskLevel.CRITICAL:
            return max_risk, reasons

        # Vérifier patterns HIGH
        for pattern, label in HIGH_PATTERNS:
            if re.search(pattern, code, re.IGNORECASE):
                reasons.append(label)
                max_risk = max(max_risk, RiskLevel.HIGH)

        # AST analysis pour Python
        if lang == "python":
            try:
                tree = ast.parse(code)
                for node in ast.walk(tree):
                    if isinstance(node, ast.Import):
                        for alias in node.names:
                            if alias.name in ("os", "sys", "subprocess", "socket"):
                                if RiskLevel.HIGH not in [max_risk]:
                                    max_risk = max(max_risk, RiskLevel.HIGH)
                    if isinstance(node, ast.Call):
                        func_name = ""
                        if isinstance(node.func, ast.Name):
                            func_name = node.func.id
                        elif isinstance(node.func, ast.Attribute):
                            func_name = node.func.attr
                        if func_name in ("eval", "exec", "compile", "__import__"):
                            reasons.append(f"dynamic eval: {func_name}()")
                            max_risk = RiskLevel.CRITICAL
            except SyntaxError as e:
                reasons.append(f"Syntax error: {e}")
                return RiskLevel.CRITICAL, reasons

        if not reasons:
            reasons.append("no risks detected")

        return max_risk, reasons

    async def _exec_python(
        self, code: str, risk: RiskLevel, reasons: list[str], timeout: int
    ) -> SandboxResult:
        """Exécuter Python dans un subprocess restreint."""
        import time
        t0 = time.time()

        # /var/tmp — accessible aux subprocesses avec resource limits
        tmpdir = "/var/tmp" if os.path.isdir("/var/tmp") else tempfile.gettempdir()
        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".py", delete=False, dir=tmpdir
        ) as f:
            f.write(code)
            tmp_path = f.name

        try:
            if self.use_docker:
                return await self._exec_docker(tmp_path, risk, reasons, timeout, t0)
            else:
                return await self._exec_subprocess(tmp_path, risk, reasons, timeout, t0)
        finally:
            try: os.unlink(tmp_path)
            except: pass

    async def _exec_subprocess(
        self, script_path: str, risk: RiskLevel,
        reasons: list[str], timeout: int, t0: float
    ) -> SandboxResult:
        """Subprocess avec resource limits."""
        import time
        import resource

        def set_limits():
            # CPU time
            resource.setrlimit(resource.RLIMIT_CPU, (timeout, timeout))
            # Memory: 512MB (Python stdlib needs more than 256MB)
            resource.setrlimit(resource.RLIMIT_AS,
                               (512 * 1024 * 1024, 512 * 1024 * 1024))
            # Limit open files (32 = minimal viable)
            resource.setrlimit(resource.RLIMIT_NOFILE, (32, 32))

        try:
            proc = await asyncio.create_subprocess_exec(
                "python3", script_path,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                preexec_fn=set_limits,
            )
            stdout, stderr = await asyncio.wait_for(
                proc.communicate(), timeout=timeout
            )
            elapsed = (time.time() - t0) * 1000
            return SandboxResult(
                success=proc.returncode == 0,
                stdout=stdout.decode("utf-8", errors="replace")[:10_000],
                stderr=stderr.decode("utf-8", errors="replace")[:2_000],
                risk_level=risk, risk_reasons=reasons,
                exec_time_ms=elapsed,
            )
        except asyncio.TimeoutError:
            return SandboxResult(
                success=False, stdout="", stderr=f"Timeout after {timeout}s",
                risk_level=risk, risk_reasons=reasons, blocked=True,
                block_reason=f"Execution timeout ({timeout}s)",
            )

    async def _exec_docker(
        self, script_path: str, risk: RiskLevel,
        reasons: list[str], timeout: int, t0: float
    ) -> SandboxResult:
        """Docker sandbox — isolation maximale."""
        import time
        import os
        cmd = [
            "docker", "run", "--rm",
            "--network=none",          # pas de réseau (PHY §2)
            "--memory=256m",           # 256MB RAM (Python stdlib needs ~100MB)
            "--cpus=0.5",              # 0.5 CPU max
            f"--volume={script_path}:/sandbox/code.py:ro",
            "--workdir=/sandbox",
            "python:3.11-slim",
            "python3", "/sandbox/code.py"
        ]
        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, stderr = await asyncio.wait_for(
                proc.communicate(), timeout=timeout + 10
            )
            elapsed = (time.time() - t0) * 1000
            return SandboxResult(
                success=proc.returncode == 0,
                stdout=stdout.decode("utf-8", errors="replace")[:10_000],
                stderr=stderr.decode("utf-8", errors="replace")[:2_000],
                risk_level=risk, risk_reasons=reasons,
                exec_time_ms=elapsed,
            )
        except asyncio.TimeoutError:
            return SandboxResult(
                success=False, stdout="", stderr="Docker timeout",
                risk_level=risk, risk_reasons=reasons, blocked=True,
                block_reason="Docker execution timeout",
            )
