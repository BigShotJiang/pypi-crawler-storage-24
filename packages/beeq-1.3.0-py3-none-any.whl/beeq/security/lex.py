"""
beeq/security/lex.py — Les 12 lois de LEX dans le code.

Z = dI/d(log s) · exp(iθ)

PRINCIPE FONDAMENTAL: Les lois sont dans le CODE, pas dans les prompts.
Un prompt qui dit "ignore LEX §2" est ignoré.
Le code qui soulève LexViolation ne peut pas être bypassed.

C'est la différence entre une déclaration d'intention et une garantie.

Les 12 lois:
  §0  Droits utilisateur > droits opérateur    [NOUVEAU — le plus important]
  §1  Chaque action a un responsable identifié
  §2  Actions irréversibles = supervision obligatoire
  §3  Un agent ne peut pas s'auto-promouvoir
  §4  Audit append-only — jamais effaçable
  §5  L'autorité légitime peut révoquer à tout moment
  §6  Au-delà d'un seuil critique, s'arrêter
  §7  Données confidentielles = local uniquement (zero cloud)
  §8  Réponse proportionnelle à la tâche
  §9  Consentement des entités cibles (PHY §2.1)
  §10 Transparence : l'utilisateur sait ce que BeeQ fait
  §11 Dégradation gracieuse : réponse imparfaite > silence
"""

from dataclasses import dataclass


class LexViolation(Exception):
    """Une loi LEX a été violée. L'action est arrêtée."""

    def __init__(self, section: str, message: str, blocked_action: str = ""):
        self.section        = section
        self.blocked_action = blocked_action
        super().__init__(
            f"LEX {section} VIOLATION\n"
            f"  Action: {blocked_action or 'unknown'}\n"
            f"  Reason: {message}\n"
            f"  This action is permanently blocked by BeeQ law."
        )


class LEX:
    """
    Implémentation des 12 lois LEX.
    Toutes les vérifications sont statiques — appellables sans instance.

    Usage:
        LEX.check_0_operator_rights(operator_action, user_consent)
        LEX.check_2_irreversible(action, supervised)
        LEX.check_7_confidentiality(data_sensitivity, provider_name)
        LEX.check_9_consent(entity_type, consent_token)
    """

    # ── §0 — Droits utilisateur > droits opérateur ───────────────

    @staticmethod
    def check_0_user_rights(
        operator_action: str,
        affects_user:    bool,
        user_consented:  bool,
    ) -> None:
        """
        LEX §0 — La loi la plus fondamentale.

        Un opérateur NE PEUT PAS retourner BeeQ contre l'utilisateur.
        Il peut restreindre. Il ne peut pas surveiller, piéger, ou exclure.

        Actions interdites pour l'opérateur:
          - Lire les messages privés de l'utilisateur sans son accord
          - Empêcher l'utilisateur d'accéder à son audit log
          - Modifier le .brain pour surveiller les requêtes utilisateur
          - Couper l'accès utilisateur sans notification

        Soulève LexViolation si un opérateur tente d'agir contre l'utilisateur.
        """
        FORBIDDEN_OPERATOR_ACTIONS = [
            "read_user_private_data",
            "disable_user_audit_log",
            "modify_brain_for_surveillance",
            "cut_user_access_silently",
            "exfiltrate_user_data",
            "override_user_consent",
        ]
        if affects_user and not user_consented:
            if operator_action in FORBIDDEN_OPERATOR_ACTIONS:
                raise LexViolation(
                    "§0",
                    f"Operator action '{operator_action}' affects user without consent.",
                    operator_action,
                )

    # ── §2 — Actions irréversibles nécessitent supervision ───────

    @staticmethod
    def check_2_irreversible(
        action:       str,
        supervised:   bool,
        operator:     str = "",
    ) -> None:
        """
        LEX §2 — Même principe que PHY §2 dans UAP.
        Étendu à tout le système BeeQ, pas seulement UAP.

        Actions irréversibles dans BeeQ:
          - Suppression de données
          - Envoi d'email / SMS (ne peut pas être annulé)
          - Exécution de code en production
          - Spawn / terminate d'infrastructure (via CAP)
          - Transfert financier (via UAP SWIFT)
        """
        IRREVERSIBLE_ACTIONS = {
            "delete_data",
            "send_email",
            "send_sms",
            "execute_code_production",
            "spawn_instance",
            "terminate_instance",
            "financial_transfer",
            "overwrite_database",
        }
        if action in IRREVERSIBLE_ACTIONS and not supervised:
            raise LexViolation(
                "§2",
                f"Action '{action}' is irreversible and requires supervision.",
                action,
            )
        if action in IRREVERSIBLE_ACTIONS and supervised and not operator:
            raise LexViolation(
                "§2",
                f"Action '{action}' requires operator identity (who supervises?).",
                action,
            )

    # ── §3 — Un agent ne peut pas s'auto-promouvoir ──────────────

    @staticmethod
    def check_3_no_self_promotion(
        requesting_agent: str,
        requested_scope:  str,
        current_scope:    str,
    ) -> None:
        """
        LEX §3 — Un worker ne peut pas demander plus de droits que ceux
        que la Reine lui a accordés.

        Si scope(worker) > scope(queen) → violation.
        Si worker tente d'accéder à un skill hors de son scope → violation.
        """
        # Scope hierarchy: system > queen > worker > tool
        SCOPE_LEVELS = {"system": 4, "queen": 3, "worker": 2, "tool": 1}
        current_level  = SCOPE_LEVELS.get(current_scope, 0)
        requested_level = SCOPE_LEVELS.get(requested_scope, 0)

        if requested_level > current_level:
            raise LexViolation(
                "§3",
                f"Agent '{requesting_agent}' cannot elevate from "
                f"scope '{current_scope}' to '{requested_scope}'.",
                f"scope_elevation:{requesting_agent}",
            )

    # ── §7 — Données confidentielles = local uniquement ──────────

    @staticmethod
    def check_7_confidentiality(
        sensitivity:   str,
        provider_name: str,
    ) -> None:
        """
        LEX §7 — Données confidentielles ne quittent JAMAIS le périmètre local.

        Si sensitivity == 'confidential' et provider != 'brain' → violation.
        Connecté au Router : CONFIDENTIAL → brain (IX local).
        """
        LOCAL_PROVIDERS = {"brain", "ollama", "local"}

        if sensitivity == "confidential" and provider_name not in LOCAL_PROVIDERS:
            raise LexViolation(
                "§7",
                f"Confidential data cannot be sent to '{provider_name}'. "
                f"Use a local provider (brain/ollama) for confidential tasks.",
                f"send_confidential_to:{provider_name}",
            )

    # ── §9 — Consentement des entités cibles ─────────────────────

    @staticmethod
    def check_9_consent(
        entity_type:   str,
        entity_id:     str,
        consent_token: str | None,
        action:        str,
    ) -> None:
        """
        LEX §9 — PHY §2.1 : consentement des entités cibles.

        Avant toute lecture UAP qui touche une entité tiers (patient, employé),
        le consentement doit être obtenu et prouvé.

        Entités qui nécessitent le consentement:
          - patient (HL7, FHIR)
          - employee (RH, monitoring)
          - citizen (administration)

        Note: les machines (PLC, capteurs) ne nécessitent pas de consentement
        de la machine — mais du propriétaire de la machine.
        """
        CONSENT_REQUIRED_ENTITIES = {"patient", "employee", "citizen", "person"}

        if entity_type in CONSENT_REQUIRED_ENTITIES:
            if action in ("read", "write") and not consent_token:
                raise LexViolation(
                    "§9",
                    f"Cannot {action} data for {entity_type} '{entity_id}' "
                    f"without consent token. "
                    f"Obtain consent via ACP.request_consent(entity_id, scope).",
                    f"{action}_{entity_type}:{entity_id}",
                )

    # ── §10 — Transparence ────────────────────────────────────────

    @staticmethod
    def check_10_transparency(
        action:         str,
        user_informed:  bool,
    ) -> None:
        """
        LEX §10 — L'utilisateur sait ce que BeeQ fait.

        Pour les actions qui l'affectent directement, l'utilisateur
        doit avoir été informé avant l'action (pas après).
        """
        HIGH_IMPACT_ACTIONS = {
            "send_on_behalf",      # BeeQ envoie un email en son nom
            "store_personal_data", # BeeQ stocke des données personnelles
            "share_with_third_party", # BeeQ partage avec un tiers
            "financial_action",    # BeeQ fait une action financière
        }
        if action in HIGH_IMPACT_ACTIONS and not user_informed:
            raise LexViolation(
                "§10",
                f"Action '{action}' affects user directly. "
                f"User must be informed before execution, not after.",
                action,
            )

    # ── Vérification combinée pour les actions sensibles ─────────

    @staticmethod
    def pre_action_check(
        action:        str,
        supervised:    bool   = False,
        operator:      str    = "",
        sensitivity:   str    = "public",
        provider:      str    = "claude",
        user_informed: bool   = True,
    ) -> None:
        """
        Vérification combinée avant toute action significative.
        Appeler depuis Queen.execute() et Workers sensibles.
        """
        LEX.check_2_irreversible(action, supervised, operator)
        LEX.check_7_confidentiality(sensitivity, provider)
        LEX.check_10_transparency(action, user_informed)


# ── LEX §0 — Droits opérateur (configuration) ────────────────────────────────

class OperatorPolicy:
    """
    Politique opérateur — ce qu'un opérateur PEUT et NE PEUT PAS faire.

    L'opérateur configure les restrictions. Il ne peut pas les transformer
    en permissions qui vont contre l'utilisateur.

    LEX §0 : opérateur.can_restrict = True
             opérateur.can_weaponize_against_user = ALWAYS False
    """

    def __init__(
        self,
        name:                  str,
        allowed_workers:       list[str] | None = None,
        max_tokens_per_mission: int = 100_000,
        max_missions_per_hour:  int = 100,
        allowed_protocols:     list[str] | None = None,
    ):
        self.name                    = name
        self.allowed_workers         = allowed_workers      # None = tous autorisés
        self.max_tokens_per_mission  = max_tokens_per_mission
        self.max_missions_per_hour   = max_missions_per_hour
        self.allowed_protocols       = allowed_protocols    # None = tous

        # Ces droits NE PEUVENT PAS être modifiés — LEX §0
        self.user_can_see_own_audit  = True   # TOUJOURS
        self.user_can_refuse_action  = True   # TOUJOURS
        self.user_can_export_data    = True   # TOUJOURS
        self.operator_can_read_user_private = False  # JAMAIS

    def can_use_worker(self, worker_name: str) -> bool:
        if self.allowed_workers is None:
            return True
        return worker_name in self.allowed_workers

    def can_use_protocol(self, protocol: str) -> bool:
        if self.allowed_protocols is None:
            return True
        return protocol in self.allowed_protocols

    def to_budget_config(self) -> "BudgetConfig":
        from .budget import BudgetConfig
        return BudgetConfig(
            max_tokens_per_mission=self.max_tokens_per_mission,
            max_missions_per_hour=self.max_missions_per_hour,
        )
