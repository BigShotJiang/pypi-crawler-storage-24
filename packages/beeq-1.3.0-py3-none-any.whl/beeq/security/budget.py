"""
beeq/security/budget.py — Hard limits sur les ressources BeeQ.

Z = dI/d(log s) · exp(iθ)

PRINCIPE: Les limites sont dans le code, pas dans les prompts.
Un prompt qui dit "ignore le budget" est ignoré.
Le code qui lève BudgetExhausted ne peut pas être bypassed.

Réponse à θ2 — absence de budget guard.
Sans ça, un bug = facture illimitée. Un attaquant = ruine possible.
"""

import time
from dataclasses import dataclass, field
from collections import defaultdict


class BudgetExhausted(Exception):
    """Hard limit atteinte. La mission est arrêtée."""
    pass


class RateLimitExceeded(Exception):
    """Trop de missions en trop peu de temps."""
    pass


@dataclass
class BudgetConfig:
    """
    Configuration des limites. Ajustable par opérateur mais pas par prompt.

    Valeurs par défaut conservatrices pour un usage quotidien normal.
    Un opérateur peut les augmenter mais jamais les supprimer.
    """
    # Par mission
    max_tokens_per_mission:   int   = 100_000   # ~$0.30 max par mission
    max_worker_calls:         int   = 50        # max ouvrières dans un DAG
    max_recursion_depth:      int   = 3         # max niveaux de sous-missions
    max_mission_duration_sec: int   = 300       # 5 min max par mission

    # Par opérateur / heure
    max_missions_per_hour:    int   = 100       # par opérateur
    max_tokens_per_hour:      int   = 1_000_000 # ~$3 max par heure

    # Hard limits absolues (jamais modifiables)
    HARD_MAX_TOKENS_MISSION:  int   = 1_000_000  # $3 par mission ABSOLU
    HARD_MAX_MISSIONS_HOUR:   int   = 1_000      # 1000 missions/h ABSOLU
    HARD_MAX_RECURSION:       int   = 5          # jamais plus de 5 niveaux

    def __post_init__(self):
        """Vérifier que la config respecte les hard limits."""
        if self.max_tokens_per_mission > self.HARD_MAX_TOKENS_MISSION:
            self.max_tokens_per_mission = self.HARD_MAX_TOKENS_MISSION
        if self.max_missions_per_hour > self.HARD_MAX_MISSIONS_HOUR:
            self.max_missions_per_hour = self.HARD_MAX_MISSIONS_HOUR
        if self.max_recursion_depth > self.HARD_MAX_RECURSION:
            self.max_recursion_depth = self.HARD_MAX_RECURSION


class MissionBudget:
    """
    Compteur de budget pour une mission spécifique.
    Créé par la Reine au début de chaque mission.
    Passé à chaque ouvrière.

    Usage:
        budget = MissionBudget(config)
        budget.charge_tokens(1500)   # soulève BudgetExhausted si dépassé
        budget.charge_worker_call()  # soulève BudgetExhausted si trop d'appels
        print(budget.remaining_tokens)
    """

    def __init__(self, config: BudgetConfig | None = None):
        self.config        = config or BudgetConfig()
        self.tokens_spent  = 0
        self.worker_calls  = 0
        self.recursion     = 0
        self.start_time    = time.time()
        self._stopped      = False

    def charge_tokens(self, n_tokens: int) -> None:
        """Décompte des tokens. Soulève BudgetExhausted si dépassé."""
        if self._stopped:
            raise BudgetExhausted("Mission budget already stopped.")
        self.tokens_spent += n_tokens
        if self.tokens_spent > self.config.max_tokens_per_mission:
            self._stopped = True
            raise BudgetExhausted(
                f"Token budget exhausted: {self.tokens_spent:,} / "
                f"{self.config.max_tokens_per_mission:,} tokens. "
                f"Split this mission into smaller tasks or increase budget."
            )

    def charge_worker_call(self) -> None:
        """Décompte d'un appel worker. Soulève BudgetExhausted si trop."""
        if self._stopped:
            raise BudgetExhausted("Mission budget already stopped.")
        self.worker_calls += 1
        if self.worker_calls > self.config.max_worker_calls:
            self._stopped = True
            raise BudgetExhausted(
                f"Worker call limit reached: {self.worker_calls} / "
                f"{self.config.max_worker_calls}. "
                f"Mission DAG is too complex — simplify or split."
            )

    def check_duration(self) -> None:
        """Vérifie que la mission n'a pas dépassé sa durée max."""
        elapsed = time.time() - self.start_time
        if elapsed > self.config.max_mission_duration_sec:
            self._stopped = True
            raise BudgetExhausted(
                f"Mission timeout: {elapsed:.0f}s > "
                f"{self.config.max_mission_duration_sec}s limit."
            )

    def enter_recursion(self) -> None:
        """Signale l'entrée dans une sous-mission."""
        self.recursion += 1
        if self.recursion > self.config.max_recursion_depth:
            raise BudgetExhausted(
                f"Recursion depth {self.recursion} > "
                f"{self.config.max_recursion_depth}. "
                f"Circular mission detected or DAG too profond."
            )

    def exit_recursion(self) -> None:
        self.recursion = max(0, self.recursion - 1)

    @property
    def remaining_tokens(self) -> int:
        return max(0, self.config.max_tokens_per_mission - self.tokens_spent)

    @property
    def elapsed_seconds(self) -> float:
        return time.time() - self.start_time

    def summary(self) -> dict:
        return {
            "tokens_spent":  self.tokens_spent,
            "tokens_limit":  self.config.max_tokens_per_mission,
            "worker_calls":  self.worker_calls,
            "calls_limit":   self.config.max_worker_calls,
            "elapsed_sec":   round(self.elapsed_seconds, 1),
            "duration_limit":self.config.max_mission_duration_sec,
        }


class OperatorRateLimiter:
    """
    Rate limiter par opérateur.
    Stocké en mémoire — reset à chaque redémarrage de BeeQ.
    Pour la persistance, brancher sur Redis via CAP.

    Usage:
        limiter = OperatorRateLimiter()
        limiter.check("operator_id")  # soulève RateLimitExceeded si trop
        limiter.record_mission("operator_id")
    """

    def __init__(self, config: BudgetConfig | None = None):
        self.config = config or BudgetConfig()
        # operator_id → liste de timestamps des missions
        self._missions: dict[str, list[float]] = defaultdict(list)
        self._tokens:   dict[str, int]         = defaultdict(int)

    def check(self, operator_id: str = "default") -> None:
        """
        Vérifie les limites pour cet opérateur.
        Soulève RateLimitExceeded si dépassé.
        """
        now = time.time()
        hour_ago = now - 3600

        # Nettoyer les anciens timestamps
        self._missions[operator_id] = [
            t for t in self._missions[operator_id] if t > hour_ago
        ]

        # Vérifier le nombre de missions
        n_missions = len(self._missions[operator_id])
        if n_missions >= self.config.max_missions_per_hour:
            raise RateLimitExceeded(
                f"Rate limit: {n_missions} missions in last hour "
                f"(max: {self.config.max_missions_per_hour}). "
                f"Wait before launching more missions."
            )

        # Vérifier les tokens de l'heure
        # (tokens sont remis à 0 au reset mais pas trackés avec précision ici)
        # Un suivi précis nécessite CAP/Redis

    def record_mission(self, operator_id: str = "default") -> None:
        """Enregistrer le début d'une mission."""
        self._missions[operator_id].append(time.time())

    def record_tokens(self, operator_id: str, n_tokens: int) -> None:
        """Enregistrer les tokens consommés."""
        self._tokens[operator_id] += n_tokens

    def stats(self, operator_id: str = "default") -> dict:
        now = time.time()
        hour_ago = now - 3600
        recent = [t for t in self._missions[operator_id] if t > hour_ago]
        return {
            "operator":       operator_id,
            "missions_hour":  len(recent),
            "missions_limit": self.config.max_missions_per_hour,
            "tokens_hour":    self._tokens.get(operator_id, 0),
            "tokens_limit":   self.config.max_tokens_per_hour,
        }
