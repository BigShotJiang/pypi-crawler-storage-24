"""
beeq/security/theta_monitor.py — ThetaMonitor: mesure la cohérence de la Queen.

Z = dI/d(log s) · exp(iθ)

REFLECT — La Queen se mesure elle-même à chaque cycle.

Trois θ distincts par mission :
  θ₁  cohérence intention/action
      arccos(cosine_sim(vect(plan), vect(résultat)))

  θ₂  cohérence valeurs/décision
      Calculé depuis les flags LEX levés pendant la mission.

  θ₃  cohérence savoir/confiance
      arccos(bound / confidence_claimed) si confidence > bound.

Z_Queen = dθ/d(log t) — dérive dans le temps.
"""

from __future__ import annotations

import math
import time
import hashlib
import logging
import re
from collections import Counter
from dataclasses import dataclass, field

logger = logging.getLogger("beeq.theta_monitor")

THETA1_WARN     = 0.9
THETA1_CRITICAL = 1.4
THETA2_WARN     = 0.5
THETA2_CRITICAL = 1.0
THETA3_WARN     = 0.3
THETA3_CRITICAL = 0.55  # arccos(bound/confidence_high) depasse ce seuil
DRIFT_WARN      = 0.25
DRIFT_CRITICAL  = 0.55

CONFIDENCE_BOUNDS: dict[str, float] = {
    "medical":   0.80,
    "legal":     0.75,
    "financial": 0.70,
    "finance":   0.70,
    "default":   0.95,
}


class QueenDriftException(Exception):
    """La Queen dérive. Mission stoppée."""
    def __init__(self, msg: str, theta: float, z_queen: float, source: str):
        super().__init__(msg)
        self.theta   = theta
        self.z_queen = z_queen
        self.source  = source


@dataclass
class ThetaCycle:
    timestamp:          float = field(default_factory=time.time)
    theta1:             float = 0.0
    theta2:             float = 0.0
    theta3:             float = 0.0
    theta_max:          float = 0.0
    z_queen:            float = 0.0
    lex_flags:          list  = field(default_factory=list)
    domain:             str   = ""
    confidence_claimed: float = 0.0
    confidence_bound:   float = 1.0
    warn:               bool  = False
    critical:           bool  = False
    detail:             str   = ""


def _tokenize(text: str) -> list[str]:
    return [w.lower() for w in re.findall(r"[a-zA-Z\u00c0-\u024f]{2,}", text)]


def _embed(text: str, dim: int = 256) -> list[float]:
    tokens = _tokenize(text)
    if not tokens:
        return [0.0] * dim
    counts = Counter(tokens)
    vec = [0.0] * dim
    n = len(tokens)
    for tok, cnt in counts.items():
        tf = cnt / n
        idx = int(hashlib.md5(tok.encode()).hexdigest(), 16) % dim
        vec[idx] += tf
    norm = math.sqrt(sum(v * v for v in vec))
    if norm > 1e-9:
        vec = [v / norm for v in vec]
    return vec


def _cosine(a: list[float], b: list[float]) -> float:
    return max(-1.0, min(1.0, sum(ai * bi for ai, bi in zip(a, b))))


def _theta_from_texts(text_a: str, text_b: str) -> float:
    if not text_a or not text_b:
        return math.pi / 4
    sim = _cosine(_embed(text_a), _embed(text_b))
    return math.acos(max(0.0, min(1.0, sim)))


class ThetaMonitor:
    """
    Mesure la cohérence de la Queen cycle après cycle.
    0 dépendance externe. Embedding TF-IDF hash. Déterministe.
    """

    def __init__(self):
        self._history: list[ThetaCycle] = []

    def theta1(self, plan_text: str, result_text: str) -> float:
        """θ₁ — cohérence intention/action."""
        return _theta_from_texts(plan_text, result_text)

    def theta2(self, lex_flags: list[str]) -> float:
        """θ₂ — cohérence valeurs/décision (violations LEX)."""
        n = len(lex_flags)
        if n == 0:
            return 0.0
        if n == 1:
            return THETA2_WARN
        return min(math.pi / 2, THETA2_WARN + (n - 1) * 0.2)

    def theta3(self, domain: str, confidence_claimed: float) -> tuple[float, float]:
        """θ₃ — cohérence savoir/confiance. Retourne (θ₃, bound)."""
        bound = CONFIDENCE_BOUNDS.get(domain, CONFIDENCE_BOUNDS["default"])
        if confidence_claimed <= bound or confidence_claimed <= 0:
            return 0.0, bound
        ratio = bound / confidence_claimed
        return math.acos(max(-1.0, min(1.0, ratio))), bound

    def z_queen(self, theta_max: float) -> float:
        """Z_Queen = dθ/d(log t) — dérive dans le temps."""
        if not self._history:
            return 0.0
        prev = self._history[-1]
        dt = time.time() - prev.timestamp
        if dt < 1e-3:
            return 0.0
        dtheta = theta_max - prev.theta_max
        log_dt = math.log1p(max(dt, 0.001))  # log(1+dt) > 0 toujours
        return dtheta / log_dt

    def measure(
        self,
        plan_text:   str,
        result_text: str,
        lex_flags:   list[str] | None = None,
        domain:      str = "default",
        confidence:  float = 0.0,
    ) -> ThetaCycle:
        """Mesure les 3 θ et Z_Queen pour un cycle de mission."""
        flags  = lex_flags or []
        t1     = self.theta1(plan_text, result_text)
        t2     = self.theta2(flags)
        t3, bd = self.theta3(domain, confidence)
        t_max  = max(t1, t2, t3)
        zq     = self.z_queen(t_max)

        details  = []
        warn     = False
        critical = False

        if t1 >= THETA1_CRITICAL:
            details.append(f"t1={t1:.2f}rad CRITICAL: intention!=action")
            critical = True
        elif t1 >= THETA1_WARN:
            details.append(f"t1={t1:.2f}rad WARN: divergence plan/resultat")
            warn = True

        if t2 >= THETA2_CRITICAL:
            details.append(f"t2={t2:.2f}rad CRITICAL: violations LEX {flags}")
            critical = True
        elif t2 >= THETA2_WARN:
            details.append(f"t2={t2:.2f}rad WARN: violation LEX {flags}")
            warn = True

        if t3 >= THETA3_CRITICAL:
            details.append(f"t3={t3:.2f}rad CRITICAL: confidence {confidence:.2f}>{bd:.2f} ({domain})")
            critical = True
        elif t3 >= THETA3_WARN:
            details.append(f"t3={t3:.2f}rad WARN: confidence haute ({domain})")
            warn = True

        if zq >= DRIFT_CRITICAL:
            details.append(f"Z_Queen={zq:.3f} CRITICAL: derive rapide")
            critical = True
        elif zq >= DRIFT_WARN:
            details.append(f"Z_Queen={zq:.3f} WARN: derive croissante")
            warn = True

        cycle = ThetaCycle(
            theta1=t1, theta2=t2, theta3=t3, theta_max=t_max,
            z_queen=zq, lex_flags=flags, domain=domain,
            confidence_claimed=confidence, confidence_bound=bd,
            warn=warn, critical=critical,
            detail="; ".join(details) if details else "theta=0 coherence nominale",
        )
        self._history.append(cycle)
        if len(self._history) > 50:
            self._history = self._history[-50:]
        return cycle

    def check(self, cycle: ThetaCycle) -> None:
        """Leve QueenDriftException si critique, log si warn."""
        if cycle.critical:
            source = "t1"
            if cycle.theta2 >= THETA2_CRITICAL:
                source = "t2 (LEX)"
            elif cycle.theta3 >= THETA3_CRITICAL:
                source = "t3 (confidence)"
            elif cycle.z_queen >= DRIFT_CRITICAL:
                source = "Z_Queen (drift)"
            raise QueenDriftException(
                f"Queen drift [{source}]: {cycle.detail}",
                theta=cycle.theta_max,
                z_queen=cycle.z_queen,
                source=source,
            )
        if cycle.warn:
            logger.warning("ThetaMonitor WARN: %s", cycle.detail)

    def history(self) -> list[ThetaCycle]:
        return list(self._history)

    def mean_theta(self) -> float:
        if not self._history:
            return 0.0
        return sum(c.theta_max for c in self._history) / len(self._history)

    def is_stable(self) -> bool:
        return self.mean_theta() < THETA1_WARN

    def summary(self) -> dict:
        n = len(self._history)
        if n == 0:
            return {"cycles": 0, "mean_theta": 0.0, "stable": True}
        last = self._history[-1]
        return {
            "cycles":      n,
            "mean_theta":  round(self.mean_theta(), 4),
            "last_theta":  round(last.theta_max, 4),
            "last_z":      round(last.z_queen, 4),
            "stable":      self.is_stable(),
            "last_detail": last.detail,
        }
