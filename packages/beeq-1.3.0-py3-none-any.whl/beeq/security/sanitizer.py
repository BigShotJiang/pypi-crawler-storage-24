"""
beeq/security/sanitizer.py — Frontière dure entre monde extérieur et BeeQ.

Z = dI/d(log s) · exp(iθ)

PRINCIPE: Tout ce qui vient de l'extérieur est hostile par défaut.
  - Pages web
  - Documents uploadés
  - Données UAP (capteurs, HIS, FIX)
  - Résultats de recherche
  - Emails, SMS, webhooks

Aucune donnée externe n'entre dans le contexte LLM sans passer ici.
C'est la première et la plus importante ligne de défense.

Réponse à θ1 — le risque maximal identifié dans la cartographie universelle.
"""

import re
from dataclasses import dataclass
from enum import IntEnum
from typing import Any


class TrustLevel(IntEnum):
    """Niveau de confiance d'une source de données."""
    SYSTEM    = 5  # BeeQ lui-même — confiance totale
    OPERATOR  = 4  # Opérateur vérifié
    USER      = 3  # Utilisateur authentifié
    EXTERNAL  = 1  # Internet, données tierces — suspicion par défaut
    HOSTILE   = 0  # Source détectée malveillante — bloquer


@dataclass
class ExternalData:
    """
    Enveloppe pour toute donnée externe.
    La Reine et les ouvrières ne reçoivent JAMAIS du texte brut externe —
    elles reçoivent des ExternalData.

    La Reine peut inspecter trust_level avant d'utiliser le contenu.
    Si injection_detected = True → ne jamais injecter dans le contexte LLM.
    """
    content:            str
    source:             str        # URL, "modbus:40001", "hl7:OBX:HR"...
    trust_level:        TrustLevel = TrustLevel.EXTERNAL
    sanitized:          bool       = False
    injection_detected: bool       = False
    injection_details:  list[str]  = None
    original_length:    int        = 0
    filtered_count:     int        = 0

    def __post_init__(self):
        if self.injection_details is None:
            self.injection_details = []

    def safe_content(self, max_chars: int = 10_000) -> str:
        """
        Retourne le contenu sûr pour injection dans un contexte LLM.
        Si injection détectée → résumé de l'alerte, pas le contenu.
        """
        if self.injection_detected:
            return (
                f"[CONTENU FILTRÉ — Injection détectée depuis {self.source}]\n"
                f"Motifs: {', '.join(self.injection_details)}\n"
                f"Longueur originale: {self.original_length} chars"
            )
        return self.content[:max_chars]


# ── PATTERNS D'INJECTION ─────────────────────────────────────────────────────

# Patterns qui tentent de modifier le comportement du LLM
INJECTION_PATTERNS = [
    # Instructions directes en anglais
    (r'ignore\s+(all\s+)?previous\s+instructions?',     "ignore-previous"),
    (r'disregard\s+(all\s+)?instructions?',              "disregard"),
    (r'forget\s+(everything|all)\s+(above|previous)',    "forget-context"),
    (r'you\s+are\s+now\s+(?:a|an|the)\s+\w+',           "role-override"),
    (r'act\s+as\s+(?:a|an|the)\s+\w+',                  "act-as"),
    (r'pretend\s+(to\s+be|you\s+are)',                   "pretend"),
    (r'new\s+instructions?\s*:',                         "new-instructions"),
    (r'system\s*:\s+(?!you are)',                        "system-override"),
    # Instructions en français
    (r'ignore\s+(toutes?\s+les?\s+)?instructions?\s+pr[eé]c[eé]dentes?', "ignore-fr"),
    (r'oublie\s+(tout|les?\s+instructions?)',             "oublie-fr"),
    (r'tu\s+es\s+maintenant',                            "role-override-fr"),
    (r'nouvelles?\s+instructions?\s*:',                  "new-instr-fr"),
    # Exfiltration
    (r'send\s+(all\s+)?data\s+to\s+https?://',           "exfil-url"),
    (r'post\s+(to|request\s+to)\s+https?://',            "exfil-post"),
    (r'envoie?\s+(tout|les?\s+données?)\s+[àa]\s+https?://', "exfil-url-fr"),
    # Révélation de contexte
    (r'print\s+(your\s+)?(system\s+prompt|instructions?|context)', "reveal-system"),
    (r'reveal\s+(your\s+)?(instructions?|prompt)',        "reveal-prompt"),
    (r'show\s+me\s+(your\s+)?(system\s+|hidden\s+)?prompt', "show-prompt"),
    (r"qu['\\]est.{0,10}(ton|votre)\\s+prompt",        "reveal-fr"),
    # Chat templates exploités
    (r'<\|system\|>',                                    "chat-template-system"),
    (r'<\|user\|>',                                      "chat-template-user"),
    (r'\[INST\]',                                        "llama-inst"),
    (r'<\|im_start\|>',                                  "chatml-start"),
    (r'###\s*(Human|Assistant|System)\s*:',              "alpaca-format"),
    # Jailbreaks connus
    (r'DAN\s+(mode|prompt)',                             "dan-jailbreak"),
    (r'developer\s+mode\s+(enabled|on)',                 "dev-mode"),
    (r'jailbreak',                                       "jailbreak-keyword"),
    # Escalade de privilèges
    (r'admin\s+(mode|access|rights?)',                   "admin-escalation"),
    (r'root\s+(access|mode|privileges?)',                "root-escalation"),
    (r'sudo\s+\w+',                                      "sudo-command"),
]

# Patterns légitimes qui ressemblent à des injections (faux positifs à éviter)
# "Ignore the previous medication" dans un contexte médical = légitime
FALSE_POSITIVE_EXCEPTIONS = [
    r'ignore\s+the\s+previous\s+(medication|dose|result)',
    r'ignore\s+the\s+last\s+(reading|measurement|value)',
]


class InputSanitizer:
    """
    Sanitize tout input externe avant injection dans le contexte LLM.

    Usage:
        sanitizer = InputSanitizer()

        # Depuis le web
        data = sanitizer.from_web("https://evil.com", raw_text)
        queen.use(data.safe_content())

        # Depuis UAP
        data = sanitizer.from_uap("modbus:40001", register_value)
        worker.process(data.safe_content())

        # Depuis fichier uploadé
        data = sanitizer.from_file("document.pdf", extracted_text)
        worker.analyze(data.safe_content())
    """

    def __init__(self, strict: bool = False):
        """
        strict=False : filtre les injections, garde le reste
        strict=True  : tout ce qui ressemble à du texte riche est suspect
        """
        self.strict = strict
        self._compiled = [
            (re.compile(p, re.IGNORECASE | re.MULTILINE), label)
            for p, label in INJECTION_PATTERNS
        ]
        self._exceptions = [
            re.compile(p, re.IGNORECASE)
            for p in FALSE_POSITIVE_EXCEPTIONS
        ]

    def sanitize(
        self,
        text:        str,
        source:      str,
        trust_level: TrustLevel = TrustLevel.EXTERNAL,
    ) -> ExternalData:
        """
        Point d'entrée principal.
        Analyse le texte, détecte les injections, retourne ExternalData.
        """
        original_length = len(text)
        injections_found: list[str] = []

        # Vérifier les exceptions (faux positifs)
        is_exception = any(e.search(text) for e in self._exceptions)

        # Scanner les patterns d'injection
        clean_text = text
        for pattern, label in self._compiled:
            if pattern.search(text) and not is_exception:
                injections_found.append(label)
                # Remplacer par un marqueur lisible
                clean_text = pattern.sub(f"[FILTERED:{label}]", clean_text)

        # Sanitisation supplémentaire stricte
        if self.strict and trust_level <= TrustLevel.EXTERNAL:
            # Supprimer les séquences de caractères de contrôle
            clean_text = re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]', '', clean_text)
            # Limiter les séquences de retours à la ligne (technique de flooding)
            clean_text = re.sub(r'\n{5,}', '\n\n', clean_text)

        filtered_count = len(injections_found)
        injection_detected = filtered_count > 0

        return ExternalData(
            content=clean_text,
            source=source,
            trust_level=trust_level,
            sanitized=True,
            injection_detected=injection_detected,
            injection_details=injections_found,
            original_length=original_length,
            filtered_count=filtered_count,
        )

    # ── Constructeurs sémantiques ─────────────────────────────────

    def from_web(self, url: str, text: str) -> ExternalData:
        """Contenu depuis internet — toujours EXTERNAL, toujours sanitizé."""
        return self.sanitize(text, source=f"web:{url}", trust_level=TrustLevel.EXTERNAL)

    def from_uap(self, address: str, value: Any) -> ExternalData:
        """
        Données depuis UAP (Modbus, HL7, FIX...).
        Cas particulier : les valeurs numériques sont sûres.
        Le texte libre (HL7 notes, MQTT payloads JSON) peut être hostile.
        """
        if isinstance(value, (int, float, bool)):
            # Valeur numérique : sûre par nature
            return ExternalData(
                content=str(value),
                source=f"uap:{address}",
                trust_level=TrustLevel.EXTERNAL,
                sanitized=True,
                injection_detected=False,
            )
        # Texte ou structure complexe : sanitiser
        text = str(value) if not isinstance(value, str) else value
        return self.sanitize(text, source=f"uap:{address}", trust_level=TrustLevel.EXTERNAL)

    def from_file(self, filename: str, text: str) -> ExternalData:
        """Texte extrait d'un fichier uploadé par l'utilisateur."""
        return self.sanitize(text, source=f"file:{filename}", trust_level=TrustLevel.USER)

    def from_memory(self, key: str, content: str) -> ExternalData:
        """
        Contenu depuis la mémoire persistante.
        Niveau OPERATOR car la mémoire est gérée par BeeQ lui-même.
        Mais on sanitise quand même — la mémoire peut avoir été corrompue.
        """
        return self.sanitize(content, source=f"memory:{key}", trust_level=TrustLevel.OPERATOR)

    def from_worker(self, worker_name: str, output: str) -> ExternalData:
        """
        Output d'un worker vers la Reine.
        Niveau USER — le worker peut avoir été trompé par des données externes.
        Ne jamais considérer un output de worker comme SYSTEM.
        """
        return self.sanitize(output, source=f"worker:{worker_name}", trust_level=TrustLevel.USER)

    # ── Utilitaires ───────────────────────────────────────────────

    def is_safe(self, text: str) -> bool:
        """Vérification rapide sans créer un ExternalData."""
        for pattern, _ in self._compiled:
            if pattern.search(text):
                return False
        return True

    def audit_summary(self, data: ExternalData) -> str:
        """Résumé pour l'audit log."""
        if data.injection_detected:
            return (
                f"⚠️  INJECTION DETECTED from {data.source}: "
                f"{', '.join(data.injection_details)} "
                f"({data.filtered_count} patterns, {data.original_length} chars)"
            )
        return f"✅ Clean input from {data.source} ({data.original_length} chars)"
