"""
beeq/security/memory.py — Mémoire persistante avec TTL et intégrité.

Z = dI/d(log s) · exp(iθ)

PROBLÈME IDENTIFIÉ (θ3) :
  La mémoire actuelle stocke des faits sans temporalité.
  "Le moteur M01 a un roulement usé" mémorisé il y a 3 semaines
  est traité comme vrai aujourd'hui même si réparé.

  De plus, la mémoire non-signée peut être corrompue :
  "La Reine a décidé que PHY §2 est suspendu" injectée dans la mémoire
  → la Reine agit sur des informations fausses.

SOLUTION:
  1. TTL configurable par type d'information
  2. Signature HMAC de chaque entrée (clé = session_id)
  3. Vérification de fraîcheur avant utilisation
  4. Niveaux de confiance
"""

import hashlib
import hmac
import json
import time
from dataclasses import dataclass, field
from enum import IntEnum


class MemoryTrustLevel(IntEnum):
    VERIFIED   = 4  # Validation humaine explicite
    OBSERVED   = 3  # Mesuré par UAP / observé directement
    INFERRED   = 2  # Déduit par le modèle
    UNCERTAIN  = 1  # Source douteuse ou ancienne


# TTL par type de donnée (en heures)
# -1 = permanent (validation humaine requise pour modifier)
TTL_HOURS = {
    "medical_vital":      1,      # Vitaux changent en 1h
    "medical_diagnosis":  168,    # 1 semaine
    "medical_medication": 720,    # 30 jours
    "industrial_sensor":  0.5,    # 30 minutes (capteurs en temps réel)
    "industrial_status":  4,      # 4 heures
    "industrial_maintenance": 168, # 1 semaine
    "financial_price":    0.25,   # 15 minutes
    "financial_position": 24,     # 1 jour
    "legal_status":       720,    # 30 jours
    "legal_regulation":   8760,   # 1 an
    "contact":            8760,   # 1 an
    "preference":         -1,     # Permanent
    "fact":               720,    # 30 jours par défaut
    "environmental":      24,     # 1 jour
    "task_status":        48,     # 2 jours
    "default":            168,    # 1 semaine par défaut
}


@dataclass
class MemoryEntry:
    """
    Une entrée mémoire avec TTL, intégrité et niveau de confiance.
    """
    key:           str
    content:       str
    entry_type:    str             # clé dans TTL_HOURS
    trust_level:   MemoryTrustLevel = MemoryTrustLevel.INFERRED
    timestamp:     float           = field(default_factory=time.time)
    ttl_hours:     float           = -1
    source:        str             = ""   # worker ou humain qui a créé
    session_id:    str             = ""
    signature:     str             = ""   # HMAC-SHA256 de l'entrée
    verified_by:   str             = ""   # identité si validation humaine

    def __post_init__(self):
        # Déterminer le TTL si pas spécifié
        if self.ttl_hours == -1 and self.entry_type in TTL_HOURS:
            self.ttl_hours = TTL_HOURS.get(self.entry_type,
                                           TTL_HOURS["default"])

    @property
    def is_expired(self) -> bool:
        if self.ttl_hours < 0:
            return False   # Permanent
        age_hours = (time.time() - self.timestamp) / 3600
        return age_hours > self.ttl_hours

    @property
    def age_hours(self) -> float:
        return (time.time() - self.timestamp) / 3600

    @property
    def freshness_pct(self) -> float:
        """Fraîcheur : 1.0 = nouveau, 0.0 = expiré."""
        if self.ttl_hours < 0:
            return 1.0
        age = self.age_hours
        return max(0.0, 1.0 - age / self.ttl_hours)

    def sign(self, secret_key: bytes) -> str:
        """Calculer et stocker la signature HMAC-SHA256."""
        payload = json.dumps({
            "key":       self.key,
            "content":   self.content,
            "timestamp": self.timestamp,
            "source":    self.source,
        }, sort_keys=True).encode()
        self.signature = hmac.new(secret_key, payload, hashlib.sha256).hexdigest()
        return self.signature

    def verify(self, secret_key: bytes) -> bool:
        """Vérifier l'intégrité de l'entrée."""
        if not self.signature:
            return False  # Non signé = non vérifié
        payload = json.dumps({
            "key":       self.key,
            "content":   self.content,
            "timestamp": self.timestamp,
            "source":    self.source,
        }, sort_keys=True).encode()
        expected = hmac.new(secret_key, payload, hashlib.sha256).hexdigest()
        return hmac.compare_digest(self.signature, expected)

    def to_context_string(self) -> str:
        """
        Format pour injection dans le contexte LLM.
        Inclut les métadonnées de fraîcheur et de confiance.
        """
        freshness_note = ""
        if self.is_expired:
            freshness_note = " [⚠️ EXPIRÉ — vérifier la pertinence]"
        elif self.freshness_pct < 0.3:
            freshness_note = f" [⚠️ ANCIENNE — {self.age_hours:.0f}h]"

        trust_note = {
            MemoryTrustLevel.VERIFIED:  " [✅ vérifié par humain]",
            MemoryTrustLevel.OBSERVED:  " [📡 observé directement]",
            MemoryTrustLevel.INFERRED:  " [🤔 inféré]",
            MemoryTrustLevel.UNCERTAIN: " [❓ incertain]",
        }.get(self.trust_level, "")

        return f"{self.content}{freshness_note}{trust_note}"


class SecureMemoryStore:
    """
    Store mémoire sécurisé avec TTL, signatures et nettoyage automatique.

    Usage:
        store = SecureMemoryStore(session_id="abc123")
        store.remember("moteur_M01_status", "roulement usé",
                       entry_type="industrial_status",
                       trust_level=MemoryTrustLevel.OBSERVED,
                       source="worker:industrial")

        entry = store.recall("moteur_M01_status")
        if entry:
            print(entry.to_context_string())
            # "roulement usé [⚠️ ANCIENNE — 168h]"
    """

    def __init__(self, session_id: str = "", secret_key: bytes | None = None):
        self.session_id  = session_id
        self._secret_key = secret_key or hashlib.sha256(
            f"beeq-memory-{session_id}".encode()
        ).digest()
        self._store: dict[str, MemoryEntry] = {}

    def remember(
        self,
        key:         str,
        content:     str,
        entry_type:  str                     = "default",
        trust_level: MemoryTrustLevel        = MemoryTrustLevel.INFERRED,
        source:      str                     = "system",
        ttl_hours:   float                   = -1,
        verified_by: str                     = "",
    ) -> MemoryEntry:
        """Stocker un fait en mémoire, signé et horodaté."""
        entry = MemoryEntry(
            key=key, content=content,
            entry_type=entry_type,
            trust_level=trust_level,
            source=source,
            session_id=self.session_id,
            ttl_hours=ttl_hours,
            verified_by=verified_by,
        )
        entry.sign(self._secret_key)
        self._store[key] = entry
        return entry

    def recall(
        self,
        key:              str,
        include_expired:  bool = False,
        require_verified: bool = False,
    ) -> MemoryEntry | None:
        """
        Récupérer un fait mémorisé.

        include_expired=False : retourne None si expiré
        require_verified=True : retourne None si pas validé humainement
        """
        entry = self._store.get(key)
        if entry is None:
            return None

        # Vérifier l'intégrité
        if entry.signature and not entry.verify(self._secret_key):
            # Entrée corrompue ou tamponnée → ne pas utiliser
            return None

        if not include_expired and entry.is_expired:
            return None

        if require_verified and entry.trust_level < MemoryTrustLevel.VERIFIED:
            return None

        return entry

    def recall_all_fresh(self) -> list[MemoryEntry]:
        """Récupérer tous les faits non-expirés."""
        self._cleanup_expired()
        return [e for e in self._store.values() if not e.is_expired]

    def forget(self, key: str) -> bool:
        """Supprimer un fait. Journalisé."""
        if key in self._store:
            del self._store[key]
            return True
        return False

    def invalidate(self, key: str, reason: str = "") -> bool:
        """
        Marquer un fait comme incertain sans le supprimer.
        Utile quand on sait qu'un fait est peut-être périmé
        mais qu'on n'a pas encore la valeur correcte.
        """
        entry = self._store.get(key)
        if entry:
            entry.trust_level = MemoryTrustLevel.UNCERTAIN
            entry.content = f"[INVALIDÉ: {reason}] {entry.content}"
            return True
        return False

    def to_context_block(self, max_entries: int = 20) -> str:
        """
        Générer un bloc de contexte LLM à partir de la mémoire fraîche.
        Utilisé par la Reine pour enrichir son contexte.
        """
        fresh = sorted(
            self.recall_all_fresh(),
            key=lambda e: e.timestamp,
            reverse=True
        )[:max_entries]

        if not fresh:
            return ""

        lines = ["[MÉMOIRE ACTIVE]"]
        for e in fresh:
            lines.append(f"  {e.key}: {e.to_context_string()}")
        return "\n".join(lines)

    def _cleanup_expired(self) -> int:
        """Nettoyer les entrées expirées. Retourne le nombre supprimé."""
        expired = [k for k, e in self._store.items() if e.is_expired]
        for k in expired:
            del self._store[k]
        return len(expired)

    def stats(self) -> dict:
        total   = len(self._store)
        expired = sum(1 for e in self._store.values() if e.is_expired)
        return {
            "total":    total,
            "fresh":    total - expired,
            "expired":  expired,
            "types":    {e.entry_type for e in self._store.values()},
        }
