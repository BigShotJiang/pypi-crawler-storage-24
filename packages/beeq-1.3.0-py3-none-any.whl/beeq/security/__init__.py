"""
beeq.security — Architecture de sécurité BeeQ.

Z = dI/d(log s) · exp(iθ)
θ → 0 = le système fait ce qu'il prétend faire, sans angles morts.

Modules:
  sanitizer   — frontière dure monde extérieur → espace BeeQ
  budget      — hard limits tokens/missions (code, pas prompts)
  lex         — 12 lois dans le code, pas dans les prompts
  memory      — mémoire avec TTL et signature
"""
from .sanitizer import InputSanitizer, ExternalData, TrustLevel
from .budget    import MissionBudget, BudgetExhausted, BudgetConfig
from .lex       import LEX, LexViolation
from .sandbox   import CodeSandbox, SandboxResult, RiskLevel

__all__ = [
    "InputSanitizer", "ExternalData", "TrustLevel",
    "MissionBudget", "BudgetExhausted", "BudgetConfig",
    "LEX", "LexViolation",
    "CodeSandbox", "SandboxResult", "RiskLevel",
]
