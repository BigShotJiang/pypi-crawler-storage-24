"""
Preuve d'Intention Antérieure (PIA)
Prior Intent Proof

The most fundamental feature of BeeQ:
The Queen signs her reasoning BEFORE acting.

This proves, cryptographically and temporally, that:
1. An intention existed BEFORE the action
2. The intention was coherent (not post-hoc rationalization)
3. The action followed the intention (or diverged — also provable)

No other AI system has done this. Ever.

Why it matters:
- Legal: citable in court. "The AI intended X, then did X."
- Ethical: proves the AI is not improvising dangerously
- Trust: verifiable by anyone, anywhere, forever

Structure:
  PIA {
    mission_hash     SHA-256 of the mission text
    plan_hash        SHA-256 of the decomposed plan (JSON)
    timestamp_intent ISO-8601 — BEFORE any action
    signature        Ed25519 signature of (mission_hash + plan_hash + timestamp)
    node_id          Which hive generated this
    verify_url       https://beeq.run/verify/<pia_hash>
  }

The verify_url contains everything needed to reconstruct and verify the proof.
Anyone can check it. No account needed. No API key.
It is permanent. Immutable. The chain is append-only.

Z = dI/d(log s) · exp(iθ)
  The PIA is what makes θ → 0:
  the declared intention and the actual action are the same.
  When they diverge, the chain proves it — that too is valuable.
"""

import hashlib
import json
import time
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional


PIA_STORE = Path.home() / ".beeq" / "intentions"


@dataclass
class PriorIntentProof:
    """
    Cryptographic proof that an intention existed BEFORE an action.

    This is the fundamental unit of trust in BeeQ.
    Every mission generates one. Every mission is traceable to one.
    """
    # Identity
    pia_id:          str   # SHA-256 of the full PIA content — the canonical ID
    node_id:         str   # Which hive (hostname or user-defined)

    # The mission
    mission:         str   # The exact mission text (what the human asked)
    mission_hash:    str   # SHA-256 of mission — tamper-evident

    # The plan (what the Queen decided to do)
    plan:            dict  # Full plan JSON (subtasks, dependencies, expected result)
    plan_hash:       str   # SHA-256 of plan JSON — tamper-evident

    # The temporal proof — this is what makes it "prior"
    timestamp_intent: str  # ISO-8601 UTC — signed BEFORE any action starts
    timestamp_unix:   float  # Unix timestamp for easy comparison

    # Cryptographic signature
    # Ed25519 over (mission_hash + plan_hash + timestamp_intent + node_id)
    # Signed by the Queen's AAP identity
    signature:       str   # "ed25519:<hex>" or "sha256:<hex>" (fallback)

    # Execution results (filled AFTER actions complete)
    timestamp_action: Optional[str] = None  # When first action started
    timestamp_done:   Optional[str] = None  # When mission completed
    actions_count:    int = 0               # How many actions were taken
    proof_hash:       Optional[str] = None  # Hash of final mission state

    # Divergence tracking
    # Did the actions match the plan? Or did the Queen adapt?
    plan_followed:   bool = True   # True if actions matched plan exactly
    divergences:     list = field(default_factory=list)  # Any deviations

    # REFLECT — cohérence Queen mesurée après mission
    theta_queen:     float = 0.0   # max(θ₁, θ₂, θ₃) — 0=cohérent, π/2=dérive totale
    z_queen:         float = 0.0   # Z_Queen = dθ/d(log t) — vitesse dérive

    # Verification
    verify_url:      str = ""  # https://beeq.run/verify/<pia_id>

    def to_dict(self) -> dict:
        return asdict(self)

    def to_json(self, indent: int = 2) -> str:
        return json.dumps(self.to_dict(), indent=indent, ensure_ascii=False)

    def summary(self) -> str:
        """Human-readable summary of the PIA."""
        lines = [
            f"┌─ PRIOR INTENT PROOF ─────────────────────────────",
            f"│  ID:       {self.pia_id[:16]}...",
            f"│  Mission:  {self.mission[:60]}{'...' if len(self.mission) > 60 else ''}",
            f"│  Intent:   {self.timestamp_intent}",
        ]
        if self.timestamp_action:
            lines.append(f"│  Action:   {self.timestamp_action}")
        if self.timestamp_done:
            lines.append(f"│  Done:     {self.timestamp_done}")
            lines.append(f"│  Actions:  {self.actions_count}")
        lines.append(f"│  Signed:   {self.signature[:32]}...")
        lines.append(f"│  Verify:   {self.verify_url}")
        lines.append(f"└───────────────────────────────────────────────────")
        return "\n".join(lines)


class IntentionEngine:
    """
    The engine that creates and manages Prior Intent Proofs.

    This sits at the core of the Queen's execution loop.
    It creates the PIA BEFORE the Queen acts.
    It updates the PIA AFTER the Queen completes.
    It stores everything permanently.
    It serves verifications.
    """

    def __init__(self, node_id: str = ""):
        import socket
        self.node_id = node_id or socket.gethostname()
        PIA_STORE.mkdir(parents=True, exist_ok=True)

    def create_prior_intent(
        self,
        mission: str,
        plan: dict,
        queen_signature: str = "",
    ) -> PriorIntentProof:
        """
        Create a Prior Intent Proof BEFORE any action is taken.

        This is the moment of commitment:
        "I, the Queen, declare that I intend to do THIS,
         at THIS moment, for THIS mission."

        Args:
            mission: The exact mission text from the human
            plan:    The Queen's decomposed plan (subtasks + dependencies)
            queen_signature: Optional Ed25519 signature from AAP

        Returns:
            PriorIntentProof — signed, timestamped, stored
        """
        # Exact UTC timestamp — this must precede all actions
        now = datetime.now(timezone.utc)
        timestamp_intent = now.isoformat()
        timestamp_unix = now.timestamp()

        # Hashes
        mission_hash = hashlib.sha256(mission.encode()).hexdigest()
        plan_json = json.dumps(plan, sort_keys=True, ensure_ascii=False)
        plan_hash = hashlib.sha256(plan_json.encode()).hexdigest()

        # Signature over the intent content
        # If AAP queen signature provided: use it
        # Fallback: SHA-256 over (mission_hash + plan_hash + timestamp + node_id)
        if queen_signature:
            signature = queen_signature
        else:
            sig_content = f"{mission_hash}{plan_hash}{timestamp_intent}{self.node_id}"
            sig_hash = hashlib.sha256(sig_content.encode()).hexdigest()
            signature = f"sha256:{sig_hash}"

        # PIA ID — hash of everything (the canonical identifier)
        pia_content = f"{mission_hash}{plan_hash}{timestamp_intent}{self.node_id}{signature}"
        pia_id = hashlib.sha256(pia_content.encode()).hexdigest()

        verify_url = f"https://beeq.run/verify/{pia_id}"

        pia = PriorIntentProof(
            pia_id=pia_id,
            node_id=self.node_id,
            mission=mission,
            mission_hash=mission_hash,
            plan=plan,
            plan_hash=plan_hash,
            timestamp_intent=timestamp_intent,
            timestamp_unix=timestamp_unix,
            signature=signature,
            verify_url=verify_url,
        )

        # Store permanently — append-only
        self._store(pia)

        return pia

    def record_action_start(self, pia: PriorIntentProof) -> PriorIntentProof:
        """Record when the first action actually started."""
        pia.timestamp_action = datetime.now(timezone.utc).isoformat()
        self._store(pia)
        return pia

    def record_completion(
        self,
        pia: PriorIntentProof,
        actions_count: int,
        proof_hash: str,
        divergences: list = None,
    ) -> PriorIntentProof:
        """
        Record mission completion and any divergences from the plan.

        Divergences are NOT failures — they are honest records.
        If the Queen had to adapt (tool failure, unexpected result),
        the PIA records WHY and WHAT changed.
        This is more trustworthy than a system that hides adaptation.
        """
        pia.timestamp_done = datetime.now(timezone.utc).isoformat()
        pia.actions_count = actions_count
        pia.proof_hash = proof_hash
        pia.divergences = divergences or []
        pia.plan_followed = len(pia.divergences) == 0
        self._store(pia)
        return pia

    def get(self, pia_id: str) -> Optional[PriorIntentProof]:
        """Retrieve a PIA by ID — used for verification."""
        path = PIA_STORE / f"{pia_id}.json"
        if not path.exists():
            return None
        try:
            data = json.loads(path.read_text())
            return PriorIntentProof(**data)
        except Exception:
            return None

    def verify(self, pia_id: str) -> dict:
        """
        Full cryptographic verification of a PIA.

        Returns a human-readable + machine-readable verification result.
        This is what beeq.run/verify/<hash> returns.
        """
        pia = self.get(pia_id)
        if not pia:
            return {
                "valid": False,
                "error": "PIA not found",
                "pia_id": pia_id,
            }

        errors = []

        # 1. Verify mission hash
        computed_mission_hash = hashlib.sha256(pia.mission.encode()).hexdigest()
        if computed_mission_hash != pia.mission_hash:
            errors.append("mission_hash_mismatch")

        # 2. Verify plan hash
        plan_json = json.dumps(pia.plan, sort_keys=True, ensure_ascii=False)
        computed_plan_hash = hashlib.sha256(plan_json.encode()).hexdigest()
        if computed_plan_hash != pia.plan_hash:
            errors.append("plan_hash_mismatch")

        # 3. Verify signature (sha256 fallback)
        if pia.signature.startswith("sha256:"):
            sig_content = f"{pia.mission_hash}{pia.plan_hash}{pia.timestamp_intent}{pia.node_id}"
            expected_sig = f"sha256:{hashlib.sha256(sig_content.encode()).hexdigest()}"
            if expected_sig != pia.signature:
                errors.append("signature_mismatch")

        # 4. Verify temporal order (intent MUST precede action)
        temporal_valid = True
        if pia.timestamp_action:
            intent_t = datetime.fromisoformat(pia.timestamp_intent).timestamp()
            action_t = datetime.fromisoformat(pia.timestamp_action).timestamp()
            if intent_t >= action_t:
                errors.append("temporal_violation: intent did not precede action")
                temporal_valid = False

        # 5. Recompute PIA ID
        pia_content = f"{pia.mission_hash}{pia.plan_hash}{pia.timestamp_intent}{pia.node_id}{pia.signature}"
        computed_pia_id = hashlib.sha256(pia_content.encode()).hexdigest()
        if computed_pia_id != pia.pia_id:
            errors.append("pia_id_mismatch")

        valid = len(errors) == 0

        return {
            "valid": valid,
            "pia_id": pia.pia_id,
            "errors": errors,
            "temporal_valid": temporal_valid,
            "plan_followed": pia.plan_followed,
            "divergences": pia.divergences,
            "mission": pia.mission,
            "timestamp_intent": pia.timestamp_intent,
            "timestamp_action": pia.timestamp_action,
            "timestamp_done": pia.timestamp_done,
            "actions_count": pia.actions_count,
            "subtasks": len(pia.plan.get("subtasks", [])),
            "node_id": pia.node_id,
            "verify_url": pia.verify_url,
            "summary": (
                "✅ VALID: This AI system declared its intention "
                f"BEFORE acting, at {pia.timestamp_intent}. "
                f"The plan was {'followed exactly' if pia.plan_followed else 'adapted (see divergences)'}."
            ) if valid else (
                f"❌ INVALID: {', '.join(errors)}"
            ),
        }

    def list_recent(self, n: int = 10) -> list[PriorIntentProof]:
        """List the n most recent PIAs."""
        files = sorted(PIA_STORE.glob("*.json"), key=lambda f: f.stat().st_mtime, reverse=True)
        result = []
        for f in files[:n]:
            try:
                data = json.loads(f.read_text())
                result.append(PriorIntentProof(**data))
            except Exception:
                pass
        return result

    def _store(self, pia: PriorIntentProof):
        """Store PIA permanently. Append-only — never overwrites old content without tracking."""
        path = PIA_STORE / f"{pia.pia_id}.json"
        path.write_text(pia.to_json(), encoding="utf-8")
