from typing import Any, Optional
from vicentin.kernels import Kernel
from vicentin.utils import Dispatcher


class RBFKernel(Kernel):
    def __init__(self, X: Optional[Any] = None, gamma: float = 1, **kwargs):
        super().__init__(X, **kwargs)
        self.gamma = gamma

        self.disp_sq_dist = Dispatcher()
        self.disp_exp = Dispatcher()

        try:
            import numpy as np

            def np_sq_dist(x, y):
                if y is None:
                    y = x
                return (
                    np.sum(x**2, axis=1)[:, None]
                    + np.sum(y**2, axis=1)[None, :]
                    - 2 * (x @ y.T)
                )

            self.disp_sq_dist.register("numpy", np_sq_dist)
            self.disp_exp.register("numpy", np.exp)
        except ImportError:
            pass

        try:
            import torch

            def torch_sq_dist(x, y):
                if y is None:
                    y = x
                return torch.cdist(x, y, p=2.0) ** 2

            self.disp_sq_dist.register("torch", torch_sq_dist)
            self.disp_exp.register("torch", torch.exp)
        except ImportError:
            pass

    def _compute(self, x: Any, y: Optional[Any] = None) -> Any:
        self.disp_sq_dist.detect_backend(x)
        self.disp_exp.detect_backend(x)

        if getattr(x, "ndim", 1) == 1:
            x = x[None, :]
        if y is not None and getattr(y, "ndim", 1) == 1:
            y = y[None, :]

        dists = self.disp_sq_dist(x, y)

        return self.disp_exp(-self.gamma * dists).squeeze()
