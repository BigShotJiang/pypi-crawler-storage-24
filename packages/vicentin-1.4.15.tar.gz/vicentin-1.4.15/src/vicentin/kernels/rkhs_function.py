from typing import Any
from vicentin.kernels.kernel import Kernel
from vicentin.machine_learning.predictor import Predictor


class RKHSFunction(Predictor):
    def __init__(self, kernel: Kernel, alpha: Any, b: float = 0):
        self.kernel = kernel
        self.alpha = alpha
        self.b = b

    def __call__(self, x: Any) -> Any:
        return self.kernel(x, self.kernel.X) @ self.alpha + self.b

    def squared_norm(self):
        return self.alpha.T @ (self.kernel @ self.alpha)

    def to(self, device):
        if hasattr(self.alpha, "to"):
            self.alpha = self.alpha.to(device)

        return self
