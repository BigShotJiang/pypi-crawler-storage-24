import numpy as np


def SMO(
    X: np.ndarray,
    y: np.ndarray,
    kernel,
    C: float,
    tol: float = 1e-3,
    max_passes: int = 5,
    is_l2: bool = False,
):
    n = X.shape[0]
    alphas = np.zeros(n)
    b = 0.0

    if is_l2:
        C_bound = np.inf
        l2_shift = 1.0 / (2 * C)
    else:
        C_bound = C
        l2_shift = 0.0

    E = -y.astype(float).copy()
    passes = 0
    eps = 1e-10

    K_diag = np.full(n, np.nan)

    def get_diag(idx):
        if np.isnan(K_diag[idx]):
            K_diag[idx] = float(
                np.ravel(kernel(X[idx : idx + 1], X[idx : idx + 1]))[0]
            )
        return K_diag[idx]

    while passes < max_passes:
        num_changed = 0
        for i in range(n):
            E_i = E[i]
            y_i = y[i]
            alpha_i = alphas[i]
            r_i = y_i * E_i

            if (r_i < -tol and alpha_i < C_bound - eps) or (
                r_i > tol and alpha_i > eps
            ):
                j = np.argmax(np.abs(E - E_i))
                if i == j:
                    j = (i + 1) % n

                E_j = E[j]
                y_j = y[j]
                alpha_j = alphas[j]

                if y_i != y_j:
                    L = max(0.0, alpha_j - alpha_i)
                    H = min(C_bound, C_bound + alpha_j - alpha_i)
                else:
                    L = max(0.0, alpha_i + alpha_j - C_bound)
                    H = min(C_bound, alpha_i + alpha_j)

                if L == H:
                    continue

                K_ii = get_diag(i)
                K_jj = get_diag(j)
                K_ij = float(np.ravel(kernel(X[i : i + 1], X[j : j + 1]))[0])

                eta = 2.0 * K_ij - (K_ii + l2_shift) - (K_jj + l2_shift)
                if eta >= 0:
                    continue

                new_alpha_j = np.clip(alpha_j - (y_j * (E_i - E_j)) / eta, L, H)

                if abs(new_alpha_j - alpha_j) < 1e-5:
                    continue

                new_alpha_i = alpha_i + y_i * y_j * (alpha_j - new_alpha_j)

                K_i_full = np.ravel(kernel(X[i : i + 1], X))
                K_j_full = np.ravel(kernel(X[j : j + 1], X))

                delta_alpha_i = new_alpha_i - alpha_i
                delta_alpha_j = new_alpha_j - alpha_j

                b1 = (
                    b
                    - E_i
                    - y_i * delta_alpha_i * (K_ii + l2_shift)
                    - y_j * delta_alpha_j * K_ij
                )
                b2 = (
                    b
                    - E_j
                    - y_i * delta_alpha_i * K_ij
                    - y_j * delta_alpha_j * (K_jj + l2_shift)
                )

                b_old = b
                if 0 < new_alpha_i < C_bound:
                    b = b1
                elif 0 < new_alpha_j < C_bound:
                    b = b2
                else:
                    b = (b1 + b2) / 2.0

                E += (
                    y_i * delta_alpha_i * K_i_full
                    + y_j * delta_alpha_j * K_j_full
                    + (b - b_old)
                )

                if is_l2:
                    E[i] += y_i * delta_alpha_i * l2_shift
                    E[j] += y_j * delta_alpha_j * l2_shift

                alphas[i] = new_alpha_i
                alphas[j] = new_alpha_j
                num_changed += 1

        if num_changed == 0:
            passes += 1
        else:
            passes = 0

    return alphas * y, b
