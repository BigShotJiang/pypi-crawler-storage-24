from typing import Any, Optional

from vicentin.kernels import Kernel, LinearKernel
from vicentin.utils import Dispatcher

disp_svm = Dispatcher()
disp_predict = Dispatcher()
disp_l2_svm = Dispatcher()

try:
    from .svm_np import SVM as SVM_np, predict as predict_np
    from .l2_svm_np import L2_SVM as L2_SVM_np

    disp_svm.register("numpy", SVM_np)
    disp_predict.register("numpy", predict_np)
    disp_l2_svm.register("numpy", L2_SVM_np)
except ModuleNotFoundError:
    pass

try:
    from .svm_torch import SVM as SVM_torch, predict as predict_torch
    from .l2_svm_torch import L2_SVM as L2_SVM_torch

    disp_svm.register("torch", SVM_torch)
    disp_predict.register("torch", predict_torch)
    disp_l2_svm.register("torch", L2_SVM_torch)
except ModuleNotFoundError:
    pass


class SVMClassifier:
    """
    Trains a Support Vector Machine (SVM) classifier.

    Supports both standard soft-margin SVM (hinge loss) and
    L2-SVM (squared hinge loss).

    Mathematical Formulation (Hinge Loss):
    --------------------------------------
    Solves the soft-margin SVM dual problem:

    $$
    \\begin{aligned}
    & \\min_{x} & & \\frac{1}{2} x^\\top K x - y^\\top x \\
    & \\text{s.t.} & & 0 \\leq y_i x_i \\leq C, \\quad i = 1, \\dots, n \\
    & & & \\sum_{i=1}^n x_i = 0
    \\end{aligned}
    $$

    Implementation Details:
    -----------------------
    - **Backend Dispatch:** Automatically routes to NumPy or PyTorch based on input type.
    - **Adaptive Solver Routing:** For small datasets ($N \\leq$ `smo_threshold`),
      uses an exact interior-point QP solver. For large datasets, delegates to the
      SMO algorithm to avoid memory errors.
    - **Exact Solver Equality Constraint:** Because the underlying exact QP solver
      optimizes the variable $x_i = \\alpha_i y_i$, the standard SVM equality constraint
      $\\sum \\alpha_i y_i = 0$ is naturally expressed and enforced as $\\sum x_i = 0$.

    Parameters:
    -----------
    loss : str, optional (default="hinge")
        The loss function to use: "hinge" for standard SVM, or "squared_hinge" for L2-SVM.
    lambda_ : float, optional (default=1)
        L2 regularization parameter. Used to compute `C` if `C` is not provided.
    C : float, optional (default=None)
        The box constraint parameter. If None, it is calculated as $1 / (\\lambda n)$.
    strategy : str, optional (default="ovo")
        The multi-class strategy to employ:
        - "binary": Used automatically if only two classes are present.
        - "ovo": One-vs-One. Trains $K(K-1)/2$ classifiers for $K$ classes.
        - "ovr": One-vs-Rest. Trains $K$ classifiers, one for each class against all others.
    smo_threshold : int, optional (default=10000)
        The dataset size threshold. If exceeded, the solver switches from the
        exact QP solver to the SMO algorithm.
    backend : str, optional (default=None)
        Explicitly specify the backend ('numpy', 'torch').
    **kwargs
        Additional arguments passed to the underlying solvers (e.g., `tol` and
        `max_passes` for SMO, or `max_iter` and `epsilon` for QP).
    """

    def __init__(
        self,
        loss: str = "hinge",
        lambda_: float = 1,
        C: Optional[float] = None,
        strategy: str = "ovo",
        smo_threshold: int = 10_000,
        backend: Optional[str] = None,
        **kwargs,
    ):
        self.loss = loss
        self.lambda_ = lambda_
        self.C = C
        self.strategy = strategy
        self.smo_threshold = smo_threshold
        self.backend = backend
        self.kwargs = kwargs

        self.kernel = None
        self.X = None
        self.model_data = None

        if self.C is None and self.lambda_ == 0:
            self.C = float("inf")

    def fit(self, X: Any | Kernel, y: Any):
        """Fits the SVM model according to the given training data."""
        if isinstance(X, Kernel):
            self.kernel = X
            self.X = self.kernel.X
        else:
            self.kernel = LinearKernel(X)
            self.X = X

        if self.loss == "hinge":
            disp = disp_svm
        elif self.loss == "squared_hinge":
            disp = disp_l2_svm
        else:
            raise ValueError("loss must be 'hinge' or 'squared_hinge'")

        disp.detect_backend(self.kernel.X, self.backend)
        y = disp.cast_values(y)

        self.model_data = disp(
            self.kernel,
            y,
            self.lambda_,
            self.C,
            self.strategy,
            self.smo_threshold,
            **self.kwargs,
        )

        return self

    def predict(self, X: Any) -> Any:
        """Evaluates the decision function on X."""
        if self.model_data is None or self.kernel is None:
            raise RuntimeError("Model is not fitted yet.")

        disp_predict.detect_backend(X, self.backend)
        X = disp_predict.cast_values(X)

        return disp_predict(self.model_data, self.kernel, X)
