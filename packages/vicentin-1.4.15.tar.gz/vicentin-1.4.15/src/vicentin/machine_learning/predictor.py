from typing import Any
from abc import ABC, abstractmethod


class Predictor(ABC):
    @abstractmethod
    def __call__(self, x: Any) -> Any:
        pass


class LinearPredictor(Predictor):
    def __init__(self, w: Any, b: float = 0):
        self.w = w
        self.b = b

    def __call__(self, x: Any) -> Any:
        return (x @ self.w) + self.b
