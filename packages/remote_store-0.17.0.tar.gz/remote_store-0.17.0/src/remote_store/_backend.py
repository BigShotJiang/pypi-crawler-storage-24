"""Backend abstract base class — the core contract."""

from __future__ import annotations

import abc
from typing import TYPE_CHECKING, BinaryIO, TypeVar

from remote_store._errors import CapabilityNotSupported

if TYPE_CHECKING:
    from collections.abc import Iterator
    from contextlib import AbstractContextManager

    from remote_store._capabilities import CapabilitySet
    from remote_store._models import FileInfo, FolderEntry, FolderInfo
    from remote_store._types import WritableContent

T = TypeVar("T")


class Backend(abc.ABC):
    """Abstract base class for all storage backends.

    Every backend must implement all abstract methods. Backend-native
    exceptions must never leak — they must be mapped to ``remote_store`` errors.
    """

    @property
    @abc.abstractmethod
    def name(self) -> str:
        """Unique identifier for this backend type (e.g. ``'local'``, ``'s3'``)."""

    @property
    @abc.abstractmethod
    def capabilities(self) -> CapabilitySet:
        """Declared capabilities of this backend."""

    @abc.abstractmethod
    def exists(self, path: str) -> bool:
        """Check if a file or folder exists. Never raises ``NotFound``.

        Args:
            path: Backend-relative key, or ``""`` for the root.

        Returns:
            ``True`` if a file or folder exists at *path*.
        """

    @abc.abstractmethod
    def is_file(self, path: str) -> bool:
        """Return ``True`` if ``path`` is an existing file.

        Args:
            path: Backend-relative key.

        Returns:
            ``True`` if *path* exists and is a file.
        """

    @abc.abstractmethod
    def is_folder(self, path: str) -> bool:
        """Return ``True`` if ``path`` is an existing folder.

        Args:
            path: Backend-relative key, or ``""`` for the root.

        Returns:
            ``True`` if *path* exists and is a folder.
        """

    @abc.abstractmethod
    def read(self, path: str) -> BinaryIO:
        """Open a file for reading and return a binary stream.

        Args:
            path: Backend-relative key.

        Returns:
            A readable binary stream.

        Raises:
            NotFound: If the file does not exist.
        """

    @abc.abstractmethod
    def read_bytes(self, path: str) -> bytes:
        """Read the full content of a file as bytes.

        Args:
            path: Backend-relative key.

        Returns:
            The file content.

        Raises:
            NotFound: If the file does not exist.
        """

    @abc.abstractmethod
    def write(self, path: str, content: WritableContent, *, overwrite: bool = False) -> None:
        """Write content to a file.

        Args:
            path: Backend-relative key.
            content: Data to write.
            overwrite: If ``False``, raise if file already exists.

        Raises:
            AlreadyExists: If the file exists and ``overwrite`` is ``False``.
        """

    @abc.abstractmethod
    def write_atomic(self, path: str, content: WritableContent, *, overwrite: bool = False) -> None:
        """Write content atomically via temp file + rename.

        Args:
            path: Backend-relative key.
            content: Data to write.
            overwrite: If ``False``, raise if file already exists.

        Raises:
            CapabilityNotSupported: If backend lacks ``ATOMIC_WRITE``.
            AlreadyExists: If the file exists and ``overwrite`` is ``False``.
        """

    @abc.abstractmethod
    def open_atomic(self, path: str, *, overwrite: bool = False) -> AbstractContextManager[BinaryIO]:
        """Yield a writable file object backed by a temporary location.

        On successful exit the temp file is atomically promoted to *path*.
        On exception the temp file is removed and *path* is untouched.

        Args:
            path: Backend-relative key.
            overwrite: If ``False``, raise if file already exists.

        Raises:
            AlreadyExists: If *path* exists and *overwrite* is ``False``.
            CapabilityNotSupported: If the backend lacks ``ATOMIC_WRITE``.
        """

    @abc.abstractmethod
    def delete(self, path: str, *, missing_ok: bool = False) -> None:
        """Delete a file.

        Args:
            path: Backend-relative key.
            missing_ok: If ``True``, do not raise when the file is absent.

        Raises:
            NotFound: If the file is missing and ``missing_ok`` is ``False``.
        """

    @abc.abstractmethod
    def delete_folder(self, path: str, *, recursive: bool = False, missing_ok: bool = False) -> None:
        """Delete a folder.

        Args:
            path: Backend-relative key.
            recursive: If ``True``, delete all contents first.
            missing_ok: If ``True``, do not raise when absent.

        Raises:
            NotFound: If the folder is missing and ``missing_ok`` is ``False``.
            DirectoryNotEmpty: If non-empty and ``recursive`` is ``False``.
        """

    @abc.abstractmethod
    def list_files(self, path: str, *, recursive: bool = False) -> Iterator[FileInfo]:
        """List files under ``path``.

        Args:
            path: Backend-relative folder key, or ``""`` for the root.
            recursive: If ``True``, include files in all subdirectories.

        Returns:
            An iterator of ``FileInfo`` objects.
        """

    @abc.abstractmethod
    def list_folders(self, path: str) -> Iterator[FolderEntry]:
        """List immediate subfolders under ``path``.

        Args:
            path: Backend-relative folder key, or ``""`` for the root.

        Returns:
            An iterator of ``FolderEntry`` objects with ``.name`` and ``.path``.
        """

    @abc.abstractmethod
    def get_file_info(self, path: str) -> FileInfo:
        """Get metadata for a file.

        Args:
            path: Backend-relative key.

        Returns:
            A ``FileInfo`` with size, modification time, etc.

        Raises:
            NotFound: If the file does not exist.
        """

    @abc.abstractmethod
    def get_folder_info(self, path: str) -> FolderInfo:
        """Get metadata for a folder.

        Args:
            path: Backend-relative folder key, or ``""`` for the root.

        Returns:
            A ``FolderInfo`` with file count, total size, etc.

        Raises:
            NotFound: If the folder does not exist.
        """

    @abc.abstractmethod
    def move(self, src: str, dst: str, *, overwrite: bool = False) -> None:
        """Move or rename a file.

        Args:
            src: Backend-relative source key.
            dst: Backend-relative destination key.
            overwrite: If ``True``, replace any existing file at *dst*.

        Raises:
            NotFound: If ``src`` does not exist.
            AlreadyExists: If ``dst`` exists and ``overwrite`` is ``False``.
        """

    @abc.abstractmethod
    def copy(self, src: str, dst: str, *, overwrite: bool = False) -> None:
        """Copy a file.

        Args:
            src: Backend-relative source key.
            dst: Backend-relative destination key.
            overwrite: If ``True``, replace any existing file at *dst*.

        Raises:
            NotFound: If ``src`` does not exist.
            AlreadyExists: If ``dst`` exists and ``overwrite`` is ``False``.
        """

    def iter_children(self, path: str) -> Iterator[FileInfo | FolderEntry]:
        """Yield both files and folders under ``path`` in a single pass.

        Files are yielded as ``FileInfo`` objects, folders as
        ``FolderEntry`` objects. The default implementation chains
        ``list_files()`` and ``list_folders()``. Backends that can fetch
        both in a single I/O call should override this for efficiency.

        Args:
            path: Backend-relative folder key, or ``""`` for the root.

        Returns:
            An iterator of ``FileInfo`` (files) and ``FolderEntry`` (folders).
        """
        yield from self.list_files(path)
        yield from self.list_folders(path)

    def glob(self, pattern: str) -> Iterator[FileInfo]:
        """Match files against a glob pattern.

        Non-abstract — backends with native glob support override this
        and add ``Capability.GLOB`` to their capability set.

        Args:
            pattern: Glob pattern (e.g., ``"data/*.csv"``, ``"**/*.txt"``).

        Raises:
            CapabilityNotSupported: If the backend lacks ``GLOB``.
        """
        raise CapabilityNotSupported(
            f"Backend '{self.name}' does not support glob."
            " Use list_files(pattern=...) for name filtering"
            " or ext.glob.glob_files() for full glob.",
            capability="glob",
            backend=self.name,
        )

    def to_key(self, native_path: str) -> str:
        """Convert a backend-native path to a backend-relative key.

        Strips the backend's own root/prefix from the path. The default
        implementation is the identity function — backends with a native
        root (filesystem path, bucket prefix, base_path) override this.

        Args:
            native_path: Absolute or backend-native path string.

        Returns:
            Path relative to the backend's root.
        """
        return native_path

    def native_path(self, path: str) -> str:
        """Convert a backend-relative key to the backend-native path.

        The inverse of ``to_key()``. The default implementation is the
        identity function — backends with a native root (bucket, base_path)
        override this to prepend their prefix.

        Args:
            path: Backend-relative key.

        Returns:
            Backend-native path usable with the native handle from ``unwrap()``.
        """
        return path

    def check_health(self) -> None:  # noqa: B027
        """Verify the backend is reachable and credentials are valid.

        The default implementation is a no-op (always succeeds). Backends
        override this to perform a lightweight, non-destructive connectivity
        check using the cheapest possible read-only operation.

        Raises:
            PermissionDenied: If credentials are invalid.
            NotFound: If the bucket, container, or root path does not exist.
            BackendUnavailable: If the backend cannot be reached.
        """

    def close(self) -> None:  # noqa: B027
        """Release resources. Default is a no-op."""

    def unwrap(self, type_hint: type[T]) -> T:
        """Return the native backend handle if it matches the requested type.

        Args:
            type_hint: The expected type (e.g., ``fsspec.AbstractFileSystem``).

        Raises:
            CapabilityNotSupported: If backend cannot provide the requested type.
        """
        raise CapabilityNotSupported(
            f"Backend '{self.name}' does not expose native handle of type {type_hint.__name__}. "
            f"Override unwrap() in your backend to provide native access.",
            capability="unwrap",
            backend=self.name,
        )
