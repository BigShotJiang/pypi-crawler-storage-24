import json
import subprocess
import time

import yaml
from click.testing import CliRunner

from .fixtures import audit_log
from dump_things_pyclient.commands.dtc import cli
from dump_things_pyclient.tests.common import read_records_from_store


def test_dtc_post_get_end_to_end(dump_things_service):
    port, store = dump_things_service

    records = tuple(
        {"pid": f"test:person_{i}", "given_name": f"gustav_{i}", "family_name": f"maler_{i}"}
        for i in range(5)
    )

    runner = CliRunner()
    result = runner.invoke(
        cli,
        ['--token=user_1', 'post-records', f'http://127.0.0.1:{port}', 'collection_1', 'Person'],
        input='\n'.join(
            json.dumps(record, ensure_ascii=False) for record in records
        ) + '\n'
    )
    assert result.exit_code == 0

    # Read all records from disk, check for annotations.
    for disk_record in map(
            lambda t: t[2],
            read_records_from_store(store, incoming='test_user_1', class_name='Person')
    ):
        if disk_record['given_name'].startswith('gustav'):
            assert 'annotations' in disk_record

    # Ensure that all records from `records` are on disk
    cleaned_disk_records = tuple(
        map(
            lambda t: t[2],
            read_records_from_store(store, incoming='test_user_1', class_name='Person', remove_keys=['annotations', 'schema_type'])
        )
    )
    assert all(r in cleaned_disk_records for r in records)

    # Check via get-records, this might return more than the records we just posted
    result = runner.invoke(
        cli,
        [
            '--token=user_1',
            'get-records', f'http://127.0.0.1:{port}', 'collection_1'
        ],
    )
    assert result.exit_code == 0
    returned_records = tuple(json.loads(line) for line in result.output.splitlines())

    # Due to other tests, there might be more records in the server than the
    # ones that we just uploaded
    assert len(returned_records) >= len(records)

    # This assertion relies on the fact that the result of get-records is
    # ordered by PID. This is the case because the server does order the
    # results by PID (by default).
    cleaned_records = tuple(
        {k: v for k, v in r.items() if k not in ('annotations', 'schema_type')}
        for r in returned_records
    )

    for r in records:
        assert r in cleaned_records, f'record {r} not found in cleaned records'


def test_dtc_post_curated(dump_things_service):
    port, store = dump_things_service

    # We add `schema_type` to the test record because the server API code, i.e.,
    # the fastapi pydantic interface classes that are generated via linkml
    # add it automatically. The curated interface does never use a schema_type
    # layer, so `schema_type` will end up in the persisted record. Adding it
    # to our input record keeps the input and output records consistent, and
    # we don't have to care about the schema_type attribute when comparing
    # uploaded and downloaded records.
    records = tuple(
        {
            "pid": f"test:person_curated_{i}",
            "given_name": f"hans_{i}",
            "family_name": f"post_curated_{i}",
            'schema_type': 'test:Person',
        }
        for i in range(5)
    )

    runner = CliRunner()
    result = runner.invoke(
        cli,
        [
            '--token=token-curator',
            'post-records',
            '--curated',
            '--author_id', 'author_1@example.com',
            f'http://127.0.0.1:{port}', 'collection_1', 'Person'
        ],
        input='\n'.join(
            json.dumps(record, ensure_ascii=False) for record in records
        ) + '\n'
    )
    assert result.exit_code == 0

    # Check on disk, read all records from disk, check for annotations,
    # delete their annotations, and ensure that all records from `records`
    # are in there.
    curated = store / 'curated' / 'Person'
    disk_records = tuple(
        yaml.load(yaml_file.read_text(), Loader=yaml.SafeLoader)
        for yaml_file in curated.glob('**/*.yaml')
    )
    # Check that curated access does not add annotations
    for record in disk_records:
        if record['given_name'].startswith('hans_'):
            assert 'annotations' not in record

    # Check that all uploaded records appear verbatim on disk, i.e., that they
    # were really uploaded through the `curated`-interface.
    assert all(r in disk_records for r in records)

    # Check via get-records, this might return more than the records we just posted
    result = runner.invoke(
        cli,
        [
            '--token=user_1',
            'get-records',
            '--class', 'Person',
            f'http://127.0.0.1:{port}', 'collection_1'
        ],
    )
    assert result.exit_code == 0
    returned_records = tuple(json.loads(line) for line in result.output.splitlines())
    assert len(returned_records) >= len(records)
    assert all(r in returned_records for r in records)

    # Check audit log
    time.sleep(1)
    audit_log_report = [
        json.loads(line)
        for line in subprocess.run(
            ['dump-things-gitaudit-report', store / audit_log, '.*' ],
            capture_output = True,
            check=True,
        ).stdout.decode().splitlines()
    ]
    # Check that the author ID shows up in the log of `hans_*`-records
    assert len(audit_log_report) >= 5, 'Audit log report: entry count mismatch'
    assert all(
        entry['author-id'] == 'author_1@example.com' for entry in audit_log_report
        if entry['resulting-record'].find('given_name: hans_') >= 0
    )


def test_dtc_post_record_any_class(dump_things_service):
    port, store = dump_things_service

    person_records = tuple(
        {
            "pid": f"test:person_wildcard_{i}",
            "given_name": f"johann_{i}",
            "family_name": f"post_wildcard_class_{i}",
            'schema_type': 'test:Person',
        }
        for i in range(3)
    )
    document_records = tuple(
        {
            "pid": f"test:document_wildcard_{i}",
            "title": f"document_{i}",
            'schema_type': 'test:Document',
        }
        for i in range(3)
    )

    runner = CliRunner()
    result = runner.invoke(
        cli,
        [
            '--token=user_1',
            'post-records',
            '--author_id', 'author_1@example.org',
            f'http://127.0.0.1:{port}', 'collection_1', '*',
        ],
        input='\n'.join(
            json.dumps(record, ensure_ascii=False)
            for record in person_records + document_records
        ) + '\n'
    )
    assert result.exit_code == 0

    # Check that the records were associated with the correct class on disk.
    # (This checks the interpretation of the schema_type attribute in the
    # input records and the interface implementation).
    inbox = store / 'incoming' / 'test_user_1' / 'Person'
    disk_records = tuple(
        yaml.load(yaml_file.read_text(), Loader=yaml.SafeLoader)
        for yaml_file in inbox.glob('**/*.yaml')
    )
    cleaned_disk_record = tuple(
        {k: v for k, v in r.items() if k not in ('annotations',)}
        for r in disk_records
    )

    assert all(r in cleaned_disk_record for r in person_records)

    inbox = store / 'incoming' / 'test_user_1' / 'Document'
    disk_records = tuple(
        yaml.load(yaml_file.read_text(), Loader=yaml.SafeLoader)
        for yaml_file in inbox.glob('**/*.yaml')
    )
    cleaned_disk_record = tuple(
        {k: v for k, v in r.items() if k not in ('annotations',)}
        for r in disk_records
    )

    assert all(r in cleaned_disk_record for r in document_records)
