import json

import yaml
from click.testing import CliRunner

from dump_things_pyclient.commands.dtc import cli


def test_dtc_version():
    runner = CliRunner()
    result = runner.invoke(cli, ['version'])
    assert result.exit_code == 0
