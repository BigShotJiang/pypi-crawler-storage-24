import json
import random
import re
import sys


vowels = [
    'a', 'e', 'i', 'o', 'u',
    'io', 'eo', 'ai', 'oi', 'ua', 'ou',
]

consonants = [
    'b', 'c', 'd', 'f', 'g', 'h', 'j', 'k', 'l', 'm', 'n', 'p', 'q', 'r',
    's', 't', 'u', 'v', 'w', 'x', 'y', 'z', 'st',
]

atoms = [vowels, consonants]

email_matcher = re.compile(r'[a-zA-z.-]+@[a-zA-z.-]+(\.[a-zA-z.-]+)+')


manual_replacements = {
    '@doktorpanik': '@dowazka',
    'mhanke': 'lenziota',
    '@mih': 'lae',
    'jsheunis': 'klopez',
    'Stephan Heunis': 'Adam Family',
    'Adina ventured into the world of open software and research software engineering via DataLad and DataLad-Handbook development. Apart from coffee, she runs on cuss words, scotch, and xkcd comics.': 'A description of someone',
    'A description of Stephan': 'A description of someone-2',
    'xyzrins:persons/simon-eickhoff': 'xyzrins:persons/some-leader-1',
    'https://mszczepanik.eu/': 'https://some-one-1.eu/',
    'https://abcd-j.de/contributors/stephan-heunis/': 'https://example.com/contributor-1',
    'https://abcd-j.de/contributors/adina-wagner/': 'https://example.com/contributor-2',
    'https://abcd-j.de/contributors/michael-hanke/': 'https://example.com/contributor-3',
    'https://abcd-j.de/contributors/jenna-swarthout-goddard/': 'https://example.com/contributor-4',
    'https://abcd-j.de/contributors/simon-eickhoff/': 'https://example.com/contributor-5',
    'https://www.trr379.de/contributors/michael-hanke/': 'https://example.com/contributor-6',
    'A portrait of Stephan Heunis taken from https://www.psychoinformatics.de/lab-members.html': 'A portrait',
    'Michael Hanke is a group leader at Forschungszentrum Jülich and an internationally renowned expert on psychoinformatics.nHe takes on the high responsibility of data management and research software and secures the use, reproducibility andnaccessibility of large data sets that TRR379 strives for.': 'A description',
}


def anonymize_person(
        json_object: dict,
        known_names: dict,
        know_pids: dict,
):
    family_name = json_object.get('family_name', None)
    given_name = json_object.get('given_name', None)
    if family_name or given_name:
        replacement = known_names.get((family_name, given_name), None)
        if not replacement:
            length_1 = random.choice(range(4, 8))
            start_1 = random.choice(range(0, 2))
            length_2 = random.choice(range(4, 8))
            start_2 = random.choice(range(0, 2))
            replacement = (
                create_name(length_1, start_1),
                create_name(length_2, start_2)
            )
            known_names[(family_name, given_name)] = replacement

        new_pid = know_pids.get(json_object['pid'], None)
        if not new_pid:
            new_pid = f'xyzrins:persons/{replacement[1]}-{replacement[0]}'
            know_pids[json_object['pid']] = new_pid

        json_object['family_name'] = replacement[0][0].upper() + replacement[0][1:]
        json_object['given_name'] = replacement[1][0].upper() + replacement[1][1:]
        json_object['pid'] = new_pid


def create_name(
        length: int,
        start: int,
) -> str:
    result = ''
    for i in range(length):
        result += random.choice(atoms[start % 2])
        start += 1
    return result


def replace_emails(
        json_object: dict | list | str | int | float | None,
        known_emails: dict,
):
    if isinstance(json_object, str):
        if email_matcher.match(json_object):
            if json_object not in known_emails:
                known_emails[json_object] = f'{create_name(8, 1)}@example.com'
            return known_emails[json_object]

    elif isinstance(json_object, list):
        return [replace_emails(element, known_emails) for element in json_object]

    elif isinstance(json_object, dict):
        return {
            key: replace_emails(value, known_emails)
            for key, value in json_object.items()
        }
    return json_object


def replace_strings(
        json_object: dict | list | str | int | float | None,
        new_strings: dict,
):
    if isinstance(json_object, str):
        return new_strings.get(json_object, json_object)

    elif isinstance(json_object, list):
        return [replace_strings(element, new_strings) for element in json_object]

    elif isinstance(json_object, dict):
        return {
            key: replace_strings(value, new_strings)
            for key, value in json_object.items()
        }
    return json_object


#anonymized_names = {}
#anonymized_emails = {}
#for line in sys.stdin.readlines():
#    json_object = json.loads(line)
#    if json_object['schema_type'] in ('xyzri:XYZPerson', 'XYZPerson', 'Person'):
#        anonymize_person(json_object, anonymized_names)
#    json_object = replace_emails(json_object, anonymized_emails)
#    print(json.dumps(json_object, ensure_ascii=False))


def anonymize_persons(json_objects: list[dict]):
    anonymized_names = {}
    modified_pids = {}
    for json_object in json_objects:
        if json_object['schema_type'] in ('xyzri:XYZPerson', 'XYZPerson', 'Person'):
            anonymize_person(json_object, anonymized_names, modified_pids)
    return anonymized_names, modified_pids


def main():
    all_objects = [json.loads(l) for l in sys.stdin.readlines()]

    # Anonymize person records, that gives new PIDs and names
    new_names, new_pids = anonymize_persons(all_objects)

    # Perform string replacement for pids, known information, and emails
    new_pids.update(manual_replacements)

    known_emails = {}
    for json_object in all_objects:
        json_object = replace_emails(json_object, known_emails)
        json_object = replace_strings(json_object, new_pids)
        print(json.dumps(json_object, ensure_ascii=False))



if __name__ == '__main__':
    main()


#for length in range(4, 8):
#    print(create_name(length, 0))
#    print(create_name(length, 1))
