
import importlib.metadata
import rich_click as click


subcommand_name = 'version'


@click.command(short_help='Show the version of `dtc`')
def cli():
    """Show the version of `dtc` and exit
    """
    click.echo(importlib.metadata.version('dump-things-pyclient'))
    return 0
