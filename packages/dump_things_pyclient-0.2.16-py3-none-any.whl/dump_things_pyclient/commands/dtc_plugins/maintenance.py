import logging
import sys

import rich_click as click
from rich.console import Console

from ...communicate import (
    HTTPError,
    get_session,
    maintenance as communicate_maintenance,
)


logger = logging.getLogger('maintenance')

console = Console(file=sys.stderr)

subcommand_name = 'maintenance'


@click.command(short_help='Activate or deactivate maintenance mode on a collection')
@click.pass_obj
@click.argument(
    'service_url',
    metavar='SERVICE_URL',
)
@click.argument(
    'collection',
    metavar='COLLECTION',
)
@click.argument(
    'active',
    metavar='ACTIVE',
    type=click.Choice(['On', 'Off'], case_sensitive=False),
)
def cli(
        obj,
        service_url: str,
        collection: str,
        active: bool,
):
    """Activate or deactivate maintenance mode on collection COLLECTION on the
    service SERVICE_URL. The argument ACTIVE should be either `On` or `Off`
    (case-insensitive).

    A token with curator rights is required.

    This command expects a server version >= 5.4.0"""
    try:
        sys.exit(
            maintenance(
                obj,
                service_url,
                collection,
                active,
            )
        )
    except HTTPError as e:
        click.echo(f'[red]Error[/red]: {e}: {e.response.text}')
    sys.exit(1)


def maintenance(
        obj: str,
        service_url: str,
        collection: str,
        active: bool,
) -> int:
    token = obj
    if token is None:
        console.print('[red]Error[/red]: no token provided')
        return 1

    session = get_session()
    communicate_maintenance(
        service_url=service_url,
        collection=collection,
        active=active,
        token=token,
        session=session,
    )
    return 0
