import json
import logging
import sys
from functools import partial
from typing import Iterable

import rich_click as click
from rich.progress import track
from rich.console import Console

from ...communicate import (
    HTTPError,
    get_session,
    collection_delete_record,
    collection_read_records_of_class,
    curated_delete_record,
    curated_read_records_of_class,
    incoming_delete_record,
    incoming_read_labels,
    incoming_read_records_of_class,
)


subcommand_name = 'delete-records'

logger = logging.getLogger('delete-records')

console = Console(file=sys.stderr)


@click.command(short_help='Delete records from a dump-things collection')
@click.pass_obj
@click.argument(
    'service_url',
    metavar='SERVICE_URL',
)
@click.argument(
    'collection',
    metavar='COLLECTION',
)
@click.argument(
    'pids',
    metavar='PIDS',
    nargs=-1,
)
@click.option(
    '--curated', '-c',
    default=False,
    is_flag=True,
    help='delete record from the curated area of the collection. (Note: requires a token with curator rights)',
)
@click.option(
    '--incoming', '-i',
    metavar='LABEL',
    help='delete from the collection\'s inbox with label LABEL, if LABEL is "-", return labels of all collection inboxes and exit',
)
@click.option(
    '--ignore-errors',
    default=False,
    is_flag=True,
    help='ignore errors when deleting a pid and continue with remaining pids',
)
@click.option(
    '--class', '-C', 'class_name',
    metavar='CLASS',
    default=None,
    help='delete ALL records of class CLASS from the collection\'s incoming '
         'area that is associated with the token. Can be '
         'combined with `-i/--incoming LABEL` or `-c/--curated` to delete all '
         'records of class CLASS from the incoming area `LABEL` or from the '
         'curated area. Note: if neither `-c/--curated` nor `-i/--incoming LABEL` '
         'is specified, the command cannot reliably determine which records are '
         'stored in the incoming area associated with a token and which '
         'records are stored in the curated area of the collection. This can '
         'lead to warnings about records that cannot be deleted. The command '
         'will print a list of all PIDs that could not be deleted.',
)
@click.option(
    '--json-error-messages',
    default=False,
    is_flag=True,
    help='if this flag is given, output information about failed delete '
         'operations to stdout. The format is JSONL (JSON lines), each JSON '
         'record contains the detailed error message, the PID of the record '
         'that could not be deleted.'
)
def cli(
        obj,
        service_url,
        collection,
        pids,
        curated,
        incoming,
        ignore_errors,
        class_name,
        json_error_messages,
):
    """Delete records from a collection on a dump-things-service

    This command delete the records given by PIDS from the collection COLLECTION
    of the dump-things service SERVICE_URL. If no pids are provided on the
    command line, the pid that should be deleted are read from stdin (one pid
    per line, lines are stripped).

    By default, the records will be deleted from the inbox associated with the
    token. If the option `-c/--curated` is given, the records are deleted from
    the curated area of the collection (this requires a token with
    curator rights). If the option `-i/--incoming LABEL` is given, the records
    are deleted from the inbox specified by `LABEL` (this requires a token with
    curator rights).

    Note: because the server overlays records from the inbox associated with
    the token over records from the curated area in a `get-records` command
    with neither `-c/--curated` nor `-i/--incoming LABEL`, the result of such
    a `get-record` might contain a mix of records that are stored in the inbox
    and records that are stored in the curated area. `delete-records` without
    `-c/--curated` or `-i/--incoming LABEL` is only able to delete records that
    are stored in the inbox associated with the token. This might lead to
    warnings if one tries to delete all records return by a "plain"
    `get-records`. A second pass of `delete-records` with `--curated` will
    ensure that all records that all records that are returned by a plain
    `get-records` are deleted (this second pass will require a CURATOR token).
    """
    try:
        sys.exit(delete_records(
            obj,
            service_url,
            collection,
            pids,
            curated,
            incoming,
            ignore_errors,
            class_name,
            json_error_messages,
        ))
    except HTTPError as e:
        console.print(f'[red]Error[/red]: {e}: {e.response.text}')
    sys.exit(1)


def delete_records(
        token,
        service_url,
        collection,
        pids,
        curated,
        incoming,
        ignore_errors,
        class_name,
        json_error_messages,
):
    if incoming and curated:
        console.print('[red]Error[/red]: -i/--incoming and -c/--curated are mutually exclusive')
        return 1

    if pids and class_name:
        console.print('[red]Error[/red]: -C/--class cannot be combined with PID-specification')
        return 1

    if token is None:
        console.print(f'[yellow]Warning[/yellow]: no token provided')
        return 1

    if class_name and pids:
        console.print(f'[yellow]Warning[/yellow]: PIDs will be ignored because -C/--class was provided')

    session = get_session()
    kwargs = dict(
        service_url=service_url,
        collection=collection,
        token=token,
        session=session,
    )

    if incoming == '-':
        result = incoming_read_labels(**kwargs)
        click.echo('\n'.join(
            map(
                partial(json.dumps, ensure_ascii=False),
                result
            )
        ))
        return 0

    if incoming:
        operation = partial(incoming_delete_record, label=incoming)
    elif curated:
        operation = curated_delete_record
    else:
        operation = collection_delete_record

    # If a class name is specified, read the PIDs from the server
    if class_name:
        pids = _get_pids_for_class(
            class_name=class_name,
            incoming=incoming,
            curated=curated,
            kwargs=kwargs,
        )
    else:
        if not pids:
            pids = sys.stdin

    return_code = 0
    errors = []
    explanation = False
    for pid in track(pids, console=console):
        try:
            operation(
                pid=pid.strip(),
                **kwargs,
            )
        except HTTPError as e:
            if class_name and not (incoming or curated):
                if not explanation:
                    explanation = True
                    console.print(
                        f'[yellow]The record with pid {pid} could not be deleted, this is not an error, iff: '
                        f'the record is only contained in the curated area of collection {collection}, and '
                        f'not in the incoming area associated with the provided token. To delete such records, '
                        f'use the option -c/--curated.[/yellow]'
                    )
                console.print(f'[yellow]Warning[/yellow]: could not delete record with pid [green]{pid}[/green]: {e}: {e.response.text}')
                _append_error(errors, e, pid, collection)
                return_code = 1
                if ignore_errors:
                    continue
                break

            console.print(f'[red]Error[/red]: could not delete record with pid [green]{pid}[/green]: {e}, {e.response.text}')
            _append_error(errors, e, pid, collection)
            return_code = 1
            if ignore_errors:
                continue
            break

    if errors and json_error_messages:
        click.echo('\n'.join(errors))
    return return_code


def _get_pids_for_class(
        class_name: str,
        incoming: str | None,
        curated: bool,
        kwargs,
) -> Iterable[str]:

    if incoming:
        operation = partial(incoming_read_records_of_class, label=incoming)
    elif curated:
        operation = curated_read_records_of_class
    else:
        operation = collection_read_records_of_class

    return map(
        lambda result: result[0]['pid'],
        operation(
            class_name=class_name,
            **kwargs,
        )
    )


def _append_error(
        container: list,
        e: HTTPError,
        pid: str,
        collection: str,
):
    container.append(
        json.dumps(
            {
            'status': 'error',
            'pid': pid,
            'collection': collection,
            'details': e.response.text,
            }
        )
    )
