

def de_prefix(name: str) -> str:
    return name.split(':', 1)[-1]
