import json
import sys

from rich.console import Console
import rich_click as click

from ...communicate import (
    HTTPError,
    get_session,
    incoming_delete_record,
    incoming_read_records,
)


subcommand_name = 'clean-incoming'

console = Console(file=sys.stderr)


@click.command(short_help='Remove records from an inbox of a dump-things collection')
@click.pass_obj
@click.argument(
    'service_url',
    metavar='SERVICE_URL',
)
@click.argument(
    'collection',
    metavar='COLLECTION',
)
@click.argument(
    'inbox_label',
    metavar='INBOX_LABEL',
)
@click.option(
    '--list-only', '-l',
    default=False,
    is_flag=True,
    help='only list records in the inbox, do not remove them',
)
def cli(
        obj,
        service_url,
        collection,
        inbox_label,
        list_only,
):
    """Remove all records from an incoming areas of a collection on a dump-things-service

    This command removes all records from the inbox with label INBOX_LABEL in
    the collection COLLECTION on the dump-things service given by SERVICE_URL.

    A token with curator rights has to be provided.
    """
    try:
        sys.exit(
            clean_incoming(
                obj,
                service_url,
                collection,
                inbox_label,
                list_only,
            )
        )
    except HTTPError as e:
        console.print(f'[red]Error[/red]: {e}: {e.response.text}')
    sys.exit(1)


def clean_incoming(
        obj,
        service_url,
        collection,
        inbox_label,
        list_only,
):
    token = obj
    if token is None:
        console.print('[red]Error[/red]: no token provided')
        return 1

    session = get_session()
    for record, _, _, _, _ in incoming_read_records(
            service_url=service_url,
            collection=collection,
            label=inbox_label,
            token=token,
            session=session,
    ):
        if list_only:
            click.echo(json.dumps(record, ensure_ascii=False))
            continue

        # Delete record from incoming area
        incoming_delete_record(
            service_url=service_url,
            collection=collection,
            label=inbox_label,
            pid=record['pid'],
            token=token,
            session=session,
        )
    return 0
