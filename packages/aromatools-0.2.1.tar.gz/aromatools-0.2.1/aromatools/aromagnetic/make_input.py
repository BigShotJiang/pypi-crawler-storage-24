#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sys

GEN_INPUT = """
# ================================
#        AroMagnetic INPUT
# ================================
# Usage:
#   python work_amg.py prepare
#   python work_amg.py analyze
#
# The workflow (prepare/analyze) is chosen via CLI.


# --------------------------------
# 1. General Information
# --------------------------------

NAME_MOLECULE             name_molecule
PROGRAM                   ORCA            # ORCA or GAUSSIAN
KEYWORD_LINE              B3LYP def2-TZVP NMR 

PROCS                     8
MEMORY_GB                 16

CHARGE                    0
MULTIPLICITY              1

MOLECULAR_COORDINATES     mol.xyz
PSEUDO_PI                 NO              # YES or NO


# --------------------------------
# 2. Module Switchboard
# --------------------------------
# Turn ON only what you need.

GRID_MODULE                 ON
PROFILE_MODULE             OFF
NICS_SCAN_XY_MODULE        OFF


# --------------------------------
# 3. GRID (Grid generation)
# --------------------------------
# Required if GRID_MODULE = ON

BEGIN_GRID

GA_MAX            200              # Maximum number of ghost atoms per input
EXTERNAL_FIELD    0.0 0.0 1.0      # Bx By Bz
NUM_POINTS        50 50 50         # Nx Ny Nz
GRID_MARGIN       2.0              # Å
VTK_FILES         YES              # NO

END_GRID


# --------------------------------
# 4. Profile (1D normal to ring)
# --------------------------------
# Required if PROFILE_MODULE = ON
#
# Linear scale requires:
#   START, DELTA_Z, NUM_GA
#
# Logarithmic scale requires:
#   START, END, NUM_GA

BEGIN_PROFILE

SCALE       Linear               # Linear or Logarithmic

START       0.0
DELTA_Z     0.1
NUM_GA      100

# Only for Logarithmic scale:
# END      5.0

END_PROFILE


# --------------------------------
# 5. NICS Scan XY (Transversal scan)
# --------------------------------
# Required if NICS_SCAN_XY_MODULE = ON
#
# If both POINTS and DELTA_X are defined:
#   Code checks consistency. If inconsistent → error.

BEGIN_NICS_SCAN_XY

POINTS        81
MARGIN        2.0
HEIGHT        0.0 1.0 1.5
DELTA_X       0.1

MAKE_AXIS_Y   YES            # YES or NO

END_NICS_SCAN_XY


# --------------------------------
# 6. Orbital Partition (optional)
# --------------------------------

BEGIN_ORBITALS

MO_core     1 2 3
MO_sigma    4 5 6
MO_pi       7 8 9
MO_others

END_ORBITALS


# --------------------------------
# 7. ORCA Block (Optional)
# --------------------------------
# Used only if PROGRAM = ORCA.
# If present, this block overrides PROCS/MEMORY_GB
# and adds advanced ORCA-specific settings.

BEGIN_ORCA_BLOCK

%pal
  nprocs 8
end

%maxcore 2000

END_ORCA_BLOCK

"""

def main():
    filename = sys.argv[1] if len(sys.argv) > 1 else "INPUT.txt"
    with open(filename, "w", encoding="utf-8") as f:
        f.write(GEN_INPUT)
    print("Done!!")
    print("Now, you should complete with your specifications the imf.txt file!")
  
if __name__ == "__main__":
    main()

