#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import re
import sys
from pathlib import Path

from .amg_read_input import read_input
from .get_cube import main as get_cube_main
from .get_grid import main as get_grid_main
from .get_integral import main as get_integral_main
from .get_mo import main as get_mo_main
from .get_nics_scan import main as get_nics_scan_main
from .get_profile import main as get_profile_main
from .extrac_values import main as extract_values_main
from .nics_scan import main as nics_scan_main
from .reset_calc import main as reset_calc_main
from .check_out import main as check_out_main
from .sum_rest import main as sum_rest_main


BANNER = r"""
======================================================================
                           AROMAGNETIC
              Magnetic Criteria for Aromaticity Evaluation
======================================================================

AroMagnetic implements widely used magnetic descriptors of aromaticity,
allowing detailed analysis of magnetic response properties derived from
the nuclear magnetic shielding tensor.

Main capabilities:

 • NICS-based analysis:
      NICS-scan
      NICS-2D
      NICS-3D
      NICS-SP
      INICS (Integral NICS)

 • Evaluation of ring current strength via numerical integration

 • Reconstruction of the induced magnetic field (Bind) from the
   nuclear magnetic shielding tensor under an external magnetic field (Bext)

 • Molecular orbital decomposition of the shielding tensor

 • Pseudo-π model implementation for π-electron magnetic response analysis

 • Generation of scalar fields (.cube) and visualization grids (.vtk)

These tools enable quantitative characterization of aromaticity,
antiaromaticity and magnetic response in molecular systems.

----------------------------------------------------------------------
Developed by:

   Fernando Martínez-Villarino
   Mesías Orozco-Ic
   Gabriel Merino

   Cinvestav – Mérida
   Centro de Investigación y de Estudios Avanzados del IPN
   Mérida, Yucatán, México

----------------------------------------------------------------------
Citation:

   Martínez-Villarino, F.; Orozco-Ic, M.; Merino, G.
   AromaTools 1.0, Cinvestav Mérida, Mérida, Mexico, 2025.

----------------------------------------------------------------------
Available workflows:

   work_amg       → generate inputs from INPUT.txt
   analyze_amg    → compute NICS / Bind / integrals
   mo_amg         → MO decomposition analysis
   reset          → remove generated files
   check_outs     → verify Gaussian/ORCA calculations
   add / sub      → algebra with .cube or .vtk fields

======================================================================
"""


def print_banner():
    print(BANNER)


def _truthy(value):
    if isinstance(value, bool):
        return value
    if value is None:
        return False
    return str(value).strip().upper() in {"ON", "TRUE", "YES", "1"}


def _read_cfg():
    cfg = read_input("INPUT.txt")
    if not cfg:
        raise SystemExit(
            "ERROR: INPUT.txt was not found or could not be read."
        )
    return cfg


def detect_active_module(cfg):
    mods = cfg.get("modules", {})
    active = [
        key for key in ("GRID_MODULE", "PROFILE_MODULE", "NICS_SCAN_XY_MODULE")
        if _truthy(mods.get(key, False))
    ]

    if len(active) != 1:
        raise SystemExit(
            "ERROR: exactly one module must be active in INPUT.txt.\n"
            f"Detected active modules: {active}"
        )

    return active[0]


def keyword_needs_generic_basis(cfg):
    general = cfg.get("general", {})
    kline = str(general.get("KEYWORD_LINE", "") or "").strip()

    if re.search(r"\bGEN(ECP)?\b", kline, flags=re.IGNORECASE):
        return True

    if re.search(r"\bPSEUDO\s*=\s*READ\b", kline, flags=re.IGNORECASE):
        return True

    return False


def ensure_basis_if_needed(cfg):
    if not keyword_needs_generic_basis(cfg):
        return

    try:
        with open("basis.txt", "r", encoding="utf-8") as f:
            content = f.read().strip()
    except FileNotFoundError:
        raise SystemExit(
            "ERROR: KEYWORD_LINE contains GEN, GENECP or PSEUDO=READ, "
            "but basis.txt was not found."
        )

    if not content:
        raise SystemExit("ERROR: basis.txt exists but is empty.")


def _run_check_out_main(args=None):
    args = [] if args is None else list(args)
    old_argv = sys.argv[:]
    try:
        sys.argv = ["check_outs"] + args
        check_out_main()
    finally:
        sys.argv = old_argv


def _run_sum_rest_main(op, file1, file2):
    mapped = {"add": "sum", "sub": "rest"}
    old_argv = sys.argv[:]
    try:
        sys.argv = ["sum_rest", mapped[op], file1, file2]
        sum_rest_main()
    finally:
        sys.argv = old_argv


def run_work():
    cfg = _read_cfg()
    active = detect_active_module(cfg)
    ensure_basis_if_needed(cfg)

    if active == "GRID_MODULE":
        get_grid_main()
    elif active == "PROFILE_MODULE":
        get_profile_main()
    elif active == "NICS_SCAN_XY_MODULE":
        nics_scan_main()
    else:
        raise SystemExit("ERROR: unknown module.")


def run_analysis():
    cfg = _read_cfg()
    active = detect_active_module(cfg)

    if active == "GRID_MODULE":
        get_cube_main()
        return

    if active == "PROFILE_MODULE":
        extract_values_main()
        get_integral_main()
        return

    if active == "NICS_SCAN_XY_MODULE":
        get_nics_scan_main()
        return

    raise SystemExit("ERROR: unknown module.")


def run_mo():
    cfg = _read_cfg()
    general = cfg.get("general", {})
    program = str(general.get("PROGRAM", "GAUSSIAN")).strip().upper()

    if program != "GAUSSIAN":
        raise SystemExit("ERROR: mo_amg is currently implemented only for Gaussian.")

    get_mo_main()


def dispatch(exe_name, args):
    exe = exe_name.lower()

    if exe == "aromagnetic":
        print_banner()
        return

    if exe == "work_amg":
        print_banner()
        run_work()
        return

    if exe == "analyze_amg":
        print_banner()
        run_analysis()
        return

    if exe == "mo_amg":
        print_banner()
        run_mo()
        return

    if exe == "reset":
        print_banner()
        reset_calc_main()
        return

    if exe == "check_outs":
        print_banner()
        _run_check_out_main(args)
        return

    if exe in {"add", "sub"}:
        print_banner()
        if len(args) != 2:
            raise SystemExit(
                f"ERROR: '{exe}' requires exactly 2 files.\n"
                f"Usage: {exe} file1.vtk file2.vtk\n"
                f"   or: {exe} file1.cube file2.cube"
            )
        _run_sum_rest_main(exe, args[0], args[1])
        return

    raise SystemExit(
        "Unknown command. Expected one of:\n"
        "  work_amg\n"
        "  analyze_amg\n"
        "  mo_amg\n"
        "  reset\n"
        "  check_outs\n"
        "  add\n"
        "  sub"
    )


def main():
    exe_name = Path(sys.argv[0]).name
    args = sys.argv[1:]
    dispatch(exe_name, args)


if __name__ == "__main__":
    main()

