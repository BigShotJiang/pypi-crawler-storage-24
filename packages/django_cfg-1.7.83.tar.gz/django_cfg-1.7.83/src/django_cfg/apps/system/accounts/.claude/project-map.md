# Project Map
> django-app — A comprehensive Django accounts application providing user management, OTP authentication, and registration source tracking.
> Generated: 2026-03-14T16:34:49.759293+00:00

## Structure

- `admin/` — Django admin site registrations and customizations for user, group, activity, and OAuth models.
  - `management/commands/` — Django management commands, such as for testing OTP functionality.
- `managers/` — Custom Django model managers, primarily for user account operations.
- `migrations/` — Django database migration files for evolving the application's data models.
- `models/` — Django ORM models for user accounts, authentication, activity tracking, OAuth, and settings.
- `serializers/` — Django REST Framework serializers for OAuth, OTP, and user profile API endpoints.
- `services/` — Business logic services for user activity, brute-force protection, GitHub integration, and OTP handling.
  - `templates/emails/` — HTML and plain-text email templates for OTP verification and welcome messages.
- `tests/` — Unit and integration tests for views, serializers, signals, and brute-force protection.
- `utils/` — Utility functions, such as for sending user notifications.
- `views/` — Django REST Framework API views for OAuth, OTP, and user profile operations.

---
Model: cache | Tokens: 0