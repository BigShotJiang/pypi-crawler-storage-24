###############################################################################
# (c) Copyright 2026 CERN for the benefit of the LHCb Collaboration           #
#                                                                             #
# This software is distributed under the terms of the GNU General Public      #
# Licence version 3 (GPL Version 3), copied verbatim in the file "COPYING".   #
#                                                                             #
# In applying this licence, CERN does not waive the privileges and immunities #
# granted to it by virtue of its status as an Intergovernmental Organization  #
# or submit itself to any jurisdiction.                                       #
###############################################################################
"""Tests for LbAgents.context — message trimming for context window management."""

from __future__ import annotations

from langchain_core.messages import AIMessage, HumanMessage, SystemMessage, ToolMessage

from LbAgents.context import (
    _CHARS_PER_TOKEN,
    _estimate_tokens,
    trim_messages_for_context,
)


def _make_tool_msg(content: str, tool_call_id: str = "tc1") -> ToolMessage:
    return ToolMessage(content=content, tool_call_id=tool_call_id)


def _make_ai_with_tool_calls(tool_names: list[str]) -> AIMessage:
    """Create an AIMessage with tool_calls metadata."""
    return AIMessage(
        content="",
        tool_calls=[
            {"name": name, "args": {}, "id": f"tc_{i}"}
            for i, name in enumerate(tool_names)
        ],
    )


class TestEstimateTokens:
    def test_empty_messages(self):
        assert _estimate_tokens([]) == 0

    def test_simple_message(self):
        msgs = [HumanMessage(content="a" * 400)]
        assert _estimate_tokens(msgs) == 400 // _CHARS_PER_TOKEN

    def test_includes_tool_call_metadata(self):
        ai = _make_ai_with_tool_calls(["get_pipeline_info"])
        tokens = _estimate_tokens([ai])
        assert tokens > 0


class TestTrimMessagesForContext:
    def test_no_trimming_when_under_budget(self):
        msgs = [
            SystemMessage(content="You are a debugger."),
            HumanMessage(content="Debug pipeline 123"),
        ]
        result = trim_messages_for_context(msgs, max_tokens=10_000)
        assert result == msgs

    def test_truncates_old_tool_messages(self):
        """Old tool messages should have their content truncated."""
        system = SystemMessage(content="You are a debugger.")
        human = HumanMessage(content="Debug pipeline 123")
        # Old messages (will be in "middle" section)
        old_ai = _make_ai_with_tool_calls(["get_logs"])
        old_tool = _make_tool_msg("x" * 5000, tool_call_id="tc_0")
        # Recent messages (kept intact)
        recent_ai = AIMessage(content="Let me check the validation report.")
        recent_ai2 = _make_ai_with_tool_calls(["get_validation"])
        recent_tool = _make_tool_msg("validation ok", tool_call_id="tc_0")
        recent_final = AIMessage(content="Done.")

        msgs = [
            system,
            human,
            old_ai,
            old_tool,
            recent_ai,
            recent_ai2,
            recent_tool,
            recent_final,
        ]

        # Set a tight budget that forces trimming (5000 chars / 4 = ~1250 tokens for tool alone)
        result = trim_messages_for_context(msgs, max_tokens=500, keep_recent=4)

        # System and human should be preserved
        assert isinstance(result[0], SystemMessage)
        assert isinstance(result[1], HumanMessage)

        # The old tool message should be truncated
        old_tool_result = [
            m for m in result if isinstance(m, ToolMessage) and len(m.content) > 1000
        ]
        assert len(old_tool_result) == 0, "Old tool message should have been truncated"

    def test_drops_old_messages_if_still_over_budget(self):
        """If truncating tool content isn't enough, drop oldest messages entirely."""
        system = SystemMessage(content="System prompt.")
        human = HumanMessage(content="Debug pipeline 123")

        # Create many old message pairs
        middle_msgs = []
        for i in range(20):
            middle_msgs.append(_make_ai_with_tool_calls([f"tool_{i}"]))
            middle_msgs.append(_make_tool_msg("x" * 2000, tool_call_id=f"tc_{i}"))

        # Recent messages
        recent = [AIMessage(content="Final analysis.")]

        msgs = [system, human] + middle_msgs + recent

        # Very tight budget
        result = trim_messages_for_context(msgs, max_tokens=500, keep_recent=1)

        # Should have system + human + at most a few middle + recent
        assert len(result) < len(msgs)
        assert isinstance(result[0], SystemMessage)
        assert isinstance(result[1], HumanMessage)
        assert result[-1].content == "Final analysis."

    def test_keeps_recent_messages_intact(self):
        """The most recent messages should never be truncated."""
        system = SystemMessage(content="System.")
        human = HumanMessage(content="Debug.")
        old_tool = _make_tool_msg("x" * 10000, tool_call_id="tc_old")
        recent_tool = _make_tool_msg("y" * 3000, tool_call_id="tc_recent")
        recent_ai = AIMessage(content="Analysis complete.")

        msgs = [
            system,
            human,
            _make_ai_with_tool_calls(["old"]),
            old_tool,
            _make_ai_with_tool_calls(["recent"]),
            recent_tool,
            recent_ai,
        ]

        result = trim_messages_for_context(msgs, max_tokens=3000, keep_recent=3)

        # Recent tool should keep its full content
        recent_tools = [m for m in result[-3:] if isinstance(m, ToolMessage)]
        if recent_tools:
            assert len(recent_tools[0].content) == 3000

    def test_preserves_tool_call_ids(self):
        """Truncated ToolMessages must keep their tool_call_id."""
        system = SystemMessage(content="System.")
        human = HumanMessage(content="Debug.")
        ai = _make_ai_with_tool_calls(["get_logs"])
        tool = _make_tool_msg("x" * 5000, tool_call_id="tc_0")
        recent = AIMessage(content="Done.")

        msgs = [system, human, ai, tool, recent]
        result = trim_messages_for_context(msgs, max_tokens=500, keep_recent=1)

        tool_msgs = [m for m in result if isinstance(m, ToolMessage)]
        for tm in tool_msgs:
            assert tm.tool_call_id == "tc_0"

    def test_tool_content_under_threshold_not_truncated(self):
        """Tool messages with small content should not be modified."""
        system = SystemMessage(content="System.")
        human = HumanMessage(content="Debug.")
        ai = _make_ai_with_tool_calls(["check"])
        tool = _make_tool_msg("small result", tool_call_id="tc_0")
        recent = AIMessage(content="Done.")

        msgs = [system, human, ai, tool, recent]
        # Budget large enough to fit but would trigger trimming check
        result = trim_messages_for_context(msgs, max_tokens=100_000)
        assert result == msgs
