###############################################################################
# (c) Copyright 2026 CERN for the benefit of the LHCb Collaboration           #
#                                                                             #
# This software is distributed under the terms of the GNU General Public      #
# Licence version 3 (GPL Version 3), copied verbatim in the file "COPYING".   #
#                                                                             #
# In applying this licence, CERN does not waive the privileges and immunities #
# granted to it by virtue of its status as an Intergovernmental Organization  #
# or submit itself to any jurisdiction.                                       #
###############################################################################
"""Tests for LbAgents graph factories and workflow registry."""

from __future__ import annotations

from unittest.mock import MagicMock

from langchain_core.messages import AIMessage, HumanMessage
from langgraph.checkpoint.memory import MemorySaver


def _make_mock_llm(response_content="Analysis complete."):
    """Create a mock LLM that returns an AIMessage with no tool calls."""
    mock_llm = MagicMock()
    mock_llm.bind_tools.return_value = mock_llm
    mock_llm.invoke.return_value = AIMessage(content=response_content)
    return mock_llm


class TestWorkflowRegistry:
    def test_registry_populated(self):
        from LbAgents import WORKFLOW_REGISTRY

        assert "ap_debug_ci_failure" in WORKFLOW_REGISTRY

    def test_registry_has_all_workflows(self):
        from LbAgents import WORKFLOW_REGISTRY

        assert len(WORKFLOW_REGISTRY) == 5

    def test_ci_failure_spec(self):
        from LbAgents import WORKFLOW_REGISTRY

        spec = WORKFLOW_REGISTRY["ap_debug_ci_failure"]
        assert callable(spec.factory)
        assert spec.requires_review is True
        assert spec.delivery[0].value == "gitlab_mr"
        assert spec.llms_required == ["orchestrator"]
        assert spec.tool_allowlist is not None
        assert "get_pipeline_info" in spec.tool_allowlist
        assert spec.timeout_seconds > 0

    def test_workflow_spec_serialisation_excludes_factory(self):
        from LbAgents import WORKFLOW_REGISTRY

        spec = WORKFLOW_REGISTRY["ap_debug_ci_failure"]
        dumped = spec.model_dump()
        assert "factory" not in dumped
        assert "name" in dumped


class TestCIFailureDebugGraph:
    def test_compiles(self):
        from LbAgents.graphs import build_ap_debug_ci_failure_graph

        mock_llm = _make_mock_llm()
        graph = build_ap_debug_ci_failure_graph(orchestrator_llm=mock_llm, tools=[])
        compiled = graph.compile(checkpointer=MemorySaver())
        assert compiled is not None

    def test_has_expected_nodes(self):
        from LbAgents.graphs import build_ap_debug_ci_failure_graph

        mock_llm = _make_mock_llm()
        graph = build_ap_debug_ci_failure_graph(orchestrator_llm=mock_llm, tools=[])
        compiled = graph.compile(checkpointer=MemorySaver())
        node_names = set(compiled.get_graph().nodes.keys())
        assert "agent" in node_names
        assert "tools" in node_names
        assert "nudge" in node_names
        # No separate review phase nodes
        assert "draft_review" not in node_names
        assert "review_tools" not in node_names
        assert "review_loop" not in node_names

    def test_has_human_review_when_write_tools(self):
        from LbAgents.graphs import build_ap_debug_ci_failure_graph

        mock_llm = _make_mock_llm()
        graph = build_ap_debug_ci_failure_graph(
            orchestrator_llm=mock_llm, tools=[], write_tool_names=["post_mr_review"]
        )
        compiled = graph.compile(checkpointer=MemorySaver())
        node_names = set(compiled.get_graph().nodes.keys())
        assert "human_review" in node_names

    def test_terminates_on_no_tool_calls(self):
        """When the LLM returns no tool calls, the graph should go to END."""
        from LbAgents.graphs import build_ap_debug_ci_failure_graph

        mock_llm = _make_mock_llm("Pipeline 26990: all jobs passed validation.")
        graph = build_ap_debug_ci_failure_graph(orchestrator_llm=mock_llm, tools=[])
        compiled = graph.compile(checkpointer=MemorySaver())
        result = compiled.invoke(
            {"messages": [HumanMessage(content="debug pipeline 26990")]},
            config={"configurable": {"thread_id": "test-ci-failure-1"}},
        )
        assert (
            result["messages"][-1].content
            == "Pipeline 26990: all jobs passed validation."
        )


class TestCIFailureMultiagentGraph:
    def test_compiles(self):
        from LbAgents.graphs import build_ap_debug_ci_failure_multiagent_graph

        mock_llm = _make_mock_llm()
        graph = build_ap_debug_ci_failure_multiagent_graph(
            orchestrator_llm=mock_llm, tools=[]
        )
        compiled = graph.compile(checkpointer=MemorySaver())
        assert compiled is not None

    def test_has_expected_nodes(self):
        from LbAgents.graphs import build_ap_debug_ci_failure_multiagent_graph

        mock_llm = _make_mock_llm()
        graph = build_ap_debug_ci_failure_multiagent_graph(
            orchestrator_llm=mock_llm, tools=[]
        )
        compiled = graph.compile(checkpointer=MemorySaver())
        node_names = set(compiled.get_graph().nodes.keys())
        assert "triage_agent" in node_names
        assert "triage_tools" in node_names
        assert "collect_job_info" in node_names
        assert "cluster_jobs" in node_names
        assert "investigate_job" in node_names
        assert "synthesize_agent" in node_names
        assert "synthesize_tools" in node_names

    def test_has_human_review_when_write_tools(self):
        from LbAgents.graphs import build_ap_debug_ci_failure_multiagent_graph

        mock_llm = _make_mock_llm()
        graph = build_ap_debug_ci_failure_multiagent_graph(
            orchestrator_llm=mock_llm,
            tools=[],
            write_tool_names=["post_mr_review"],
        )
        compiled = graph.compile(checkpointer=MemorySaver())
        node_names = set(compiled.get_graph().nodes.keys())
        assert "human_review" in node_names

    def test_registry_entry(self):
        from LbAgents import WORKFLOW_REGISTRY

        spec = WORKFLOW_REGISTRY["ap_debug_ci_failure_multiagent"]
        assert callable(spec.factory)
        assert spec.requires_review is True
        assert spec.delivery[0].value == "gitlab_mr"
        assert "get_pipeline_info" in spec.tool_allowlist
