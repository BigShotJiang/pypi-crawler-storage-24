###############################################################################
# (c) Copyright 2026 CERN for the benefit of the LHCb Collaboration           #
#                                                                             #
# This software is distributed under the terms of the GNU General Public      #
# Licence version 3 (GPL Version 3), copied verbatim in the file "COPYING".   #
#                                                                             #
# In applying this licence, CERN does not waive the privileges and immunities #
# granted to it by virtue of its status as an Intergovernmental Organization  #
# or submit itself to any jurisdiction.                                       #
###############################################################################
"""Mock LLM for Layer 1 (deterministic) evaluation."""

from __future__ import annotations

import uuid
from unittest.mock import MagicMock

from langchain_core.messages import AIMessage

from eval.models import ScriptedLLMResponse


class ScriptedResponseExhausted(Exception):
    """Raised when all scripted LLM responses have been consumed."""


def make_scripted_llm(responses: list[ScriptedLLMResponse]) -> MagicMock:
    """Create a mock LLM that returns scripted responses in order.

    Each response can either be plain text (agent decides to stop or continue)
    or include tool_calls (agent invokes tools).
    """
    response_iter = iter(responses)

    def invoke(messages, **kwargs):
        try:
            scripted = next(response_iter)
        except StopIteration as e:
            raise ScriptedResponseExhausted(
                f"Scripted LLM responses exhausted after {len(responses)} calls. "
                f"The scenario may need more scripted_llm_responses entries."
            ) from e

        if scripted.tool_calls:
            tool_calls = []
            for tc in scripted.tool_calls:
                tool_calls.append(
                    {
                        "id": f"call_{uuid.uuid4().hex[:8]}",
                        "name": tc["tool_name"],
                        "args": tc.get("arguments", {}),
                    }
                )
            return AIMessage(content=scripted.content, tool_calls=tool_calls)
        return AIMessage(content=scripted.content)

    mock_llm = MagicMock()
    mock_llm.bind_tools.return_value = mock_llm
    mock_llm.invoke.side_effect = invoke
    return mock_llm


def collect_tool_calls(messages: list) -> list[dict]:
    """Extract tool calls from a message history in order."""
    calls = []
    for msg in messages:
        if hasattr(msg, "tool_calls") and msg.tool_calls:
            for tc in msg.tool_calls:
                calls.append({"tool_name": tc["name"], "arguments": tc.get("args", {})})
    return calls
