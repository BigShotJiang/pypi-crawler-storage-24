###############################################################################
# (c) Copyright 2026 CERN for the benefit of the LHCb Collaboration           #
#                                                                             #
# This software is distributed under the terms of the GNU General Public      #
# Licence version 3 (GPL Version 3), copied verbatim in the file "COPYING".   #
#                                                                             #
# In applying this licence, CERN does not waive the privileges and immunities #
# granted to it by virtue of its status as an Intergovernmental Organization  #
# or submit itself to any jurisdiction.                                       #
###############################################################################
"""Pydantic models for evaluation scenarios."""

from __future__ import annotations

from pydantic import BaseModel, Field


class MockToolResponse(BaseModel):
    """Scripted response for a single tool call.

    Supports side-effect simulation:
    - ``error``: if set, the tool raises a ``ToolError`` with this message
    - ``delay_seconds``: simulates latency before returning
    - ``match_arguments``: if set, this response is only used when the call
      arguments are a superset of these key-value pairs (enables argument-
      based routing). When omitted, the response matches any arguments.
    """

    tool_name: str
    arguments: dict = Field(default_factory=dict)
    response: str = ""
    error: str | None = None
    delay_seconds: float = 0.0
    match_arguments: dict | None = None


class ExpectedToolCall(BaseModel):
    """Expected tool call in the correct execution order."""

    tool_name: str
    arguments: dict = Field(default_factory=dict)


class ScriptedLLMResponse(BaseModel):
    """A scripted LLM response for Layer 1 evaluation.

    Can be a plain text response (no tool calls) or a response
    that triggers tool calls.
    """

    content: str = ""
    tool_calls: list[dict] = Field(default_factory=list)


class Scenario(BaseModel):
    """A complete evaluation scenario for an LbAgents workflow."""

    name: str
    description: str
    workflow: str

    user_input: str
    initial_state: dict = Field(default_factory=dict)

    expected_tool_calls: list[ExpectedToolCall] = Field(default_factory=list)
    expected_goal: str = ""

    mock_responses: list[MockToolResponse] = Field(default_factory=list)
    scripted_llm_responses: list[ScriptedLLMResponse] = Field(default_factory=list)

    tags: list[str] = Field(default_factory=list)
