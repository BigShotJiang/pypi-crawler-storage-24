###############################################################################
# (c) Copyright 2026 CERN for the benefit of the LHCb Collaboration           #
#                                                                             #
# This software is distributed under the terms of the GNU General Public      #
# Licence version 3 (GPL Version 3), copied verbatim in the file "COPYING".   #
#                                                                             #
# In applying this licence, CERN does not waive the privileges and immunities #
# granted to it by virtue of its status as an Intergovernmental Organization  #
# or submit itself to any jurisdiction.                                       #
###############################################################################
"""YAML scenario loader and validator."""

from __future__ import annotations

from pathlib import Path

import yaml

from eval.models import Scenario

SCENARIOS_DIR = Path(__file__).parent / "scenarios"


def load_scenario(path: str | Path) -> Scenario:
    """Load a single scenario from a YAML file."""
    path = Path(path)
    with open(path) as f:
        data = yaml.safe_load(f)
    return Scenario(**data)


def load_scenarios_for_workflow(workflow: str) -> list[Scenario]:
    """Load all scenarios for a given workflow name."""
    scenarios = []
    for yaml_file in sorted(SCENARIOS_DIR.glob("*.yaml")):
        scenario = load_scenario(yaml_file)
        if scenario.workflow == workflow:
            scenarios.append(scenario)
    return scenarios


def load_all_scenarios() -> list[Scenario]:
    """Load all scenarios from the scenarios directory."""
    return [load_scenario(f) for f in sorted(SCENARIOS_DIR.glob("*.yaml"))]


class ScenarioValidationError(Exception):
    """Raised when a scenario has internal inconsistencies."""


def validate_scenario(scenario: Scenario) -> list[str]:
    """Check cross-references within a scenario and return a list of warnings.

    Raises ScenarioValidationError if any check is fatal.
    """
    errors: list[str] = []
    warnings: list[str] = []

    mock_tool_names = {mr.tool_name for mr in scenario.mock_responses}

    # Check that every expected tool call has a corresponding mock response
    for tc in scenario.expected_tool_calls:
        if tc.tool_name not in mock_tool_names:
            errors.append(
                f"expected_tool_calls references '{tc.tool_name}' "
                f"but no mock_response provides it"
            )

    # Check that scripted LLM tool calls reference tools with mock responses
    for i, resp in enumerate(scenario.scripted_llm_responses):
        for tc in resp.tool_calls:
            name = tc.get("tool_name") or tc.get("name", "")
            if name and name not in mock_tool_names:
                errors.append(
                    f"scripted_llm_responses[{i}] calls '{name}' "
                    f"but no mock_response provides it"
                )

    # Check that there are enough scripted responses for expected tool calls.
    # Each tool-calling scripted response produces one LLM turn, plus the
    # agent needs at least one final (non-tool-call) response to finish.
    if scenario.scripted_llm_responses and scenario.expected_tool_calls:
        scripted_tool_calls = sum(
            len(r.tool_calls) for r in scenario.scripted_llm_responses
        )
        expected_count = len(scenario.expected_tool_calls)
        if scripted_tool_calls < expected_count:
            warnings.append(
                f"scripted_llm_responses contain {scripted_tool_calls} tool calls "
                f"but expected_tool_calls has {expected_count} entries"
            )

    if errors:
        raise ScenarioValidationError(
            f"Scenario {scenario.name!r} validation failed:\n"
            + "\n".join(f"  - {e}" for e in errors)
        )

    return warnings
