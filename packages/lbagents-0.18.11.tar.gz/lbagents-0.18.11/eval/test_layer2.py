###############################################################################
# (c) Copyright 2026 CERN for the benefit of the LHCb Collaboration           #
#                                                                             #
# This software is distributed under the terms of the GNU General Public      #
# Licence version 3 (GPL Version 3), copied verbatim in the file "COPYING".   #
#                                                                             #
# In applying this licence, CERN does not waive the privileges and immunities #
# granted to it by virtue of its status as an Intergovernmental Organization  #
# or submit itself to any jurisdiction.                                       #
###############################################################################
"""Layer 2 evaluation tests — requires LLM API keys.

These tests run the full agent loop with a real LLM (mocked tools)
and score results with all metrics (deterministic + LLM-as-judge).

Run with: pytest eval/test_layer2.py -m layer2 -v

Scores are attached to each test via ``record_property`` (visible in
JUnit XML with ``--junitxml=eval_results.xml``) and written as a JSON
report to ``eval/results.json`` for downstream Langfuse ingestion.
"""

from __future__ import annotations

import json
import os
from pathlib import Path

import pytest

from eval.loader import SCENARIOS_DIR, load_scenario
from eval.metrics import MetricResult, score_all
from eval.runner import run_scenario_layer2

BASELINES_FILE = Path(__file__).parent / "baselines.json"


def _load_baselines() -> dict:
    """Load baseline scores and tolerance from baselines.json."""
    with open(BASELINES_FILE) as f:
        return json.load(f)


_BASELINES = _load_baselines()
_TOLERANCE = _BASELINES.get("tolerance", 0.1)


def _assert_baseline(scenario_name: str, metric_name: str, actual: float | None):
    """Assert that actual score meets baseline - tolerance.

    Skips silently if the metric has no baseline or actual is None.
    """
    if actual is None:
        return
    scenario_baselines = _BASELINES.get("scenarios", {}).get(scenario_name, {})
    baseline = scenario_baselines.get(metric_name)
    if baseline is None:
        return
    threshold = round(baseline - _TOLERANCE, 4)
    assert actual >= threshold, (
        f"{metric_name} for {scenario_name}: {actual:.2f} < baseline "
        f"{baseline:.2f} - tolerance {_TOLERANCE} = {threshold:.2f}"
    )


requires_llm = pytest.mark.skipif(
    not (
        os.environ.get("LLM_API_KEY")
        or os.environ.get("OPENAI_API_KEY")
        or os.environ.get("OPENAI_BASE_URL")
    ),
    reason="Layer 2 tests require LLM_API_KEY (or OPENAI_API_KEY/OPENAI_BASE_URL)",
)

pytestmark = [pytest.mark.layer2, requires_llm]

RESULTS_FILE = Path(__file__).parent / "results.json"

# Accumulated during the session, written at the end
_session_results: list[dict] = []


def _get_llm():
    """Create an LLM instance for Layer 2 evaluation."""
    from langchain_openai import ChatOpenAI

    return ChatOpenAI(
        base_url=os.environ.get("LLM_BASE_URL"),
        model=os.environ.get("LLM_MODEL", os.environ.get("EVAL_MODEL", "gpt-4o-mini")),
        api_key=os.environ.get(
            "LLM_API_KEY", os.environ.get("OPENAI_API_KEY", "unused")
        ),
        temperature=0,
    )


def _record(record_property, metrics: MetricResult):
    """Attach scores to the pytest test via record_property and accumulate for JSON."""
    for score in metrics.as_langfuse_scores():
        record_property(score["name"], score["value"])
    _session_results.append(
        {
            "scenario": metrics.scenario_name,
            "model": os.environ.get("LLM_MODEL", "unknown"),
            "scores": {s["name"]: s["value"] for s in metrics.as_langfuse_scores()},
        }
    )


@pytest.fixture(autouse=True, scope="session")
def _write_results_json():
    """Write accumulated results to JSON after all tests complete."""
    yield
    if _session_results:
        RESULTS_FILE.write_text(json.dumps(_session_results, indent=2))

        from eval.langfuse_utils import push_scores

        push_scores(_session_results)


class TestCIFailureLayer2:
    @pytest.fixture(
        params=[
            "ci_failure_memory_limit",
            "ci_failure_cvmfs_missing",
            "ci_failure_api_error",
        ]
    )
    def scenario(self, request):
        return load_scenario(SCENARIOS_DIR / f"{request.param}.yaml")

    def test_metrics(self, scenario, record_property):
        llm = _get_llm()
        result = run_scenario_layer2(scenario, llm)
        assert result.error is None, f"Scenario {scenario.name} failed: {result.error}"

        metrics = score_all(scenario, result, llm=llm)
        _record(record_property, metrics)

        for metric_name in [
            "tool_call_accuracy",
            "tool_call_accuracy_unordered",
            "tool_call_f1",
            "tool_call_precision",
            "tool_call_recall",
            "agent_goal_accuracy",
            "topic_adherence",
            "faithfulness",
        ]:
            _assert_baseline(scenario.name, metric_name, getattr(metrics, metric_name))


class TestStuckProductionLayer2:
    @pytest.fixture(
        params=[
            "stuck_production_maxreset",
            "stuck_production_stalled",
            "stuck_production_empty_response",
        ]
    )
    def scenario(self, request):
        return load_scenario(SCENARIOS_DIR / f"{request.param}.yaml")

    def test_metrics(self, scenario, record_property):
        llm = _get_llm()
        result = run_scenario_layer2(scenario, llm)
        assert result.error is None, f"Scenario {scenario.name} failed: {result.error}"

        metrics = score_all(scenario, result, llm=llm)
        _record(record_property, metrics)

        for metric_name in [
            "tool_call_accuracy",
            "tool_call_accuracy_unordered",
            "tool_call_f1",
            "tool_call_precision",
            "tool_call_recall",
            "agent_goal_accuracy",
            "topic_adherence",
            "faithfulness",
        ]:
            _assert_baseline(scenario.name, metric_name, getattr(metrics, metric_name))


class TestMattermostLayer2:
    @pytest.fixture(
        params=[
            "mattermost_why_stuck",
            "mattermost_ci_failed",
            "mattermost_api_timeout",
        ]
    )
    def scenario(self, request):
        return load_scenario(SCENARIOS_DIR / f"{request.param}.yaml")

    def test_metrics(self, scenario, record_property):
        llm = _get_llm()
        result = run_scenario_layer2(scenario, llm)
        assert result.error is None, f"Scenario {scenario.name} failed: {result.error}"

        metrics = score_all(scenario, result, llm=llm)
        _record(record_property, metrics)

        for metric_name in [
            "tool_call_accuracy",
            "tool_call_accuracy_unordered",
            "tool_call_f1",
            "tool_call_precision",
            "tool_call_recall",
            "agent_goal_accuracy",
            "topic_adherence",
            "faithfulness",
        ]:
            _assert_baseline(scenario.name, metric_name, getattr(metrics, metric_name))
