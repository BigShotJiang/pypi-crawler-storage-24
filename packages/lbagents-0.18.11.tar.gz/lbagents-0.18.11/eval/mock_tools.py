###############################################################################
# (c) Copyright 2026 CERN for the benefit of the LHCb Collaboration           #
#                                                                             #
# This software is distributed under the terms of the GNU General Public      #
# Licence version 3 (GPL Version 3), copied verbatim in the file "COPYING".   #
#                                                                             #
# In applying this licence, CERN does not waive the privileges and immunities #
# granted to it by virtue of its status as an Intergovernmental Organization  #
# or submit itself to any jurisdiction.                                       #
###############################################################################
"""Mock MCP tool factory for evaluation scenarios.

Builds LangChain ``StructuredTool`` instances from scenario ``mock_responses``.
Supports:

* **Argument-based routing** — a response with ``match_arguments`` is only
  selected when the actual call arguments contain all specified key-value
  pairs.  Responses without ``match_arguments`` act as fallbacks.
* **Error simulation** — when ``error`` is set the tool raises a
  ``ToolException`` so the agent sees an error message instead of a result.
* **Latency simulation** — ``delay_seconds`` pauses execution before
  returning, useful for timeout testing.
* **Cycling** — when multiple responses match, they are returned round-robin.
"""

from __future__ import annotations

import time

from langchain_core.tools import StructuredTool, ToolException

from eval.models import MockToolResponse


class ToolError(ToolException):
    """Raised by mock tools to simulate MCP errors."""


def _matches(call_args: dict, match_args: dict) -> bool:
    """Return True if *call_args* is a superset of *match_args*."""
    return all(call_args.get(k) == v for k, v in match_args.items())


def _select_response(
    responses: list[MockToolResponse],
    call_args: dict,
    call_counts: dict[str, int],
) -> MockToolResponse:
    """Pick the best matching response for a tool call.

    1. Try responses with ``match_arguments`` that match *call_args*.
    2. Fall back to responses without ``match_arguments`` (round-robin).
    """
    # Partition into argument-matched and fallback
    matched = [
        r
        for r in responses
        if r.match_arguments and _matches(call_args, r.match_arguments)
    ]
    fallbacks = [r for r in responses if not r.match_arguments]

    # Build a stable key for round-robin counting
    key = str(sorted(call_args.items())) if call_args else "__no_args__"

    if matched:
        pool = matched
    elif fallbacks:
        pool = fallbacks
    else:
        pool = responses  # nothing matched — use everything

    idx = call_counts.get(key, 0) % len(pool)
    call_counts[key] = call_counts.get(key, 0) + 1
    return pool[idx]


def _apply_side_effects(response: MockToolResponse) -> str:
    """Apply delay / error side effects and return the response string."""
    if response.delay_seconds > 0:
        time.sleep(response.delay_seconds)

    if response.error:
        raise ToolError(response.error)

    return response.response


def make_mock_tools(mock_responses: list[MockToolResponse]) -> list[StructuredTool]:
    """Create mock LangChain tools from scenario ``mock_responses``.

    Groups responses by ``tool_name``.  Each tool selects a response based
    on argument matching, applies side effects, and returns the response
    string (or raises ``ToolError``).
    """
    grouped: dict[str, list[MockToolResponse]] = {}
    for mr in mock_responses:
        grouped.setdefault(mr.tool_name, []).append(mr)

    tools = []
    for tool_name, responses in grouped.items():

        def _make_func(name: str, resps: list[MockToolResponse]):
            call_counts: dict[str, int] = {}

            def func(**kwargs) -> str:
                selected = _select_response(resps, kwargs, call_counts)
                return _apply_side_effects(selected)

            return func

        tool = StructuredTool.from_function(
            func=_make_func(tool_name, responses),
            name=tool_name,
            description=f"Mock tool: {tool_name}",
            handle_tool_error=True,
        )
        tools.append(tool)

    return tools
