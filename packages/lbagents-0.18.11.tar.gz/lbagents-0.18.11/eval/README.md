# Evaluation Framework

Scenario-based evaluation harness for LbAgents workflows, using two-layer testing and RAGAS metrics.

## Structure

```
eval/
├── models.py              # Pydantic scenario model
├── loader.py              # YAML scenario loader
├── mock_llm.py            # Mock LLM and tools for Layer 1
├── runner.py              # Evaluation runner (Layer 1 + Layer 2)
├── metrics.py             # RAGAS metrics wrapper
├── conftest.py            # Pytest fixtures
├── test_layer1.py         # Layer 1 tests (no LLM, runs in CI)
├── test_layer2.py         # Layer 2 tests (with LLM, RAGAS scoring)
└── scenarios/             # YAML scenario definitions
    ├── ci_failure_memory_limit.yaml
    ├── ci_failure_cvmfs_missing.yaml
    ├── stuck_production_maxreset.yaml
    ├── stuck_production_stalled.yaml
    ├── mattermost_why_stuck.yaml
    └── mattermost_ci_failed.yaml
```

## Two-Layer Evaluation

### Layer 1 — Deterministic (no LLM)

Runs in CI without API keys. Uses scripted LLM responses and mocked tool outputs to verify:
- Graph executes end-to-end without errors
- Expected tool calls are made in the correct order
- Final response is produced

```bash
pytest eval/test_layer1.py -v
```

### Layer 2 — With LLM (RAGAS metrics)

Requires an LLM API key. Runs the full agent loop with a real LLM and mocked tools, then scores with:

**Deterministic (no LLM needed):**
- **tool_call_accuracy**: Ordered sequence matching — position-by-position comparison of expected vs actual tool calls, scoring tool name + argument match
- **tool_call_accuracy_unordered**: Same but with greedy best-match pairing (order doesn't matter)
- **tool_call_precision**: matched / actual calls (penalizes extra calls)
- **tool_call_recall**: matched / expected calls (penalizes missing calls)
- **tool_call_f1**: Harmonic mean of precision and recall

**LLM-as-judge:**
- **agent_goal_accuracy**: Uses RAGAS `AgentGoalAccuracyWithReference` (with a simple LLM-as-judge fallback) to score whether the agent achieved the expected goal
- **topic_adherence**: Scores whether the response stays within LHCb/AP domain topics
- **faithfulness**: Scores whether the final response is grounded in tool outputs (no fabricated error messages, job IDs, etc.)

A **random baseline** floor is also computed analytically for the tool-call metrics, plus operational metrics (wall time, latency, token counts).

```bash
OPENAI_API_KEY=... pytest eval/test_layer2.py -m layer2 -v
```

Optional: set `EVAL_MODEL` to use a different model (default: `gpt-4o-mini`).

## Scenario YAML Format

```yaml
name: ci_failure_memory_limit
description: "Pipeline fails due to memory limit exceeded"
workflow: ap_debug_ci_failure

user_input: "Pipeline 27100 failed for MR !85. Please investigate."

initial_state:
  pipeline_id: 27100
  mr_iid: 85
  diagnosis_complete: false

expected_tool_calls:
  - tool_name: get_pipeline_info
    arguments:
      pipeline_id: 27100
  - tool_name: get_ci_job_logs

expected_goal: "Agent should diagnose memory limit as root cause"

mock_responses:
  - tool_name: get_pipeline_info
    arguments:
      pipeline_id: 27100
    response: '{"pipeline_id": 27100, "status": "FAILED", ...}'

scripted_llm_responses:
  - content: "Investigating pipeline."
    tool_calls:
      - tool_name: get_pipeline_info
        arguments:
          pipeline_id: 27100
  - content: "Diagnosis: memory limit exceeded."
```

## Adding a New Scenario

1. Create a YAML file in `eval/scenarios/`
2. Set `workflow` to one of: `ap_debug_ci_failure`, `ap_debug_stuck_productions`, `mattermost_debug_user_request`
3. Define `mock_responses` for all tools the agent will call
4. Define `scripted_llm_responses` for Layer 1 (deterministic path through the graph)
5. Set `expected_tool_calls` and `expected_goal` for scoring
6. Run `pytest eval/test_layer1.py -v` to verify

## Baselines

`baselines.json` stores reference scores per scenario. Layer 2 tests assert that each metric meets `baseline - tolerance` (default tolerance: `0.1`). This catches quality regressions when prompts are edited or models are swapped.

### Updating baselines

After a confirmed improvement (e.g. better prompts, upgraded model):

1. Run Layer 2 tests and verify the new scores in `eval/results.json`
2. Update the relevant values in `eval/baselines.json` (round to 2 decimal places)
3. Update `last_updated` to the current date
4. Commit the updated baselines with a message explaining the change

Do **not** update baselines to paper over regressions — investigate the root cause first.

### Structure

```json
{
  "model": "agent",
  "last_updated": "2026-03-06",
  "tolerance": 0.1,
  "scenarios": {
    "ci_failure_memory_limit": {
      "tool_call_accuracy": 0.2,
      "agent_goal_accuracy": 0.9
    }
  }
}
```

Metrics without a baseline entry are skipped (no assertion). Metrics where the actual value is `None` (e.g. LLM-as-judge when no LLM is provided) are also skipped.

## Dependencies

Layer 1 requires only the base LbAgents dependencies plus `pyyaml`.

Layer 2 additionally requires:
- `ragas` (optional — falls back to simple LLM-as-judge)
- `langchain-openai` (or another LangChain LLM provider)
