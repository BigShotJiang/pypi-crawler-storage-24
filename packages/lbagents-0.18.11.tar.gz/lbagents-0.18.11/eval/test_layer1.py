###############################################################################
# (c) Copyright 2026 CERN for the benefit of the LHCb Collaboration           #
#                                                                             #
# This software is distributed under the terms of the GNU General Public      #
# Licence version 3 (GPL Version 3), copied verbatim in the file "COPYING".   #
#                                                                             #
# In applying this licence, CERN does not waive the privileges and immunities #
# granted to it by virtue of its status as an Intergovernmental Organization  #
# or submit itself to any jurisdiction.                                       #
###############################################################################
"""Layer 1 evaluation tests — deterministic, no LLM API keys required.

These tests use scripted LLM responses and mocked tool responses to verify
that workflows execute correctly end-to-end.
"""

from __future__ import annotations

import pytest

from eval.loader import SCENARIOS_DIR, load_scenario, validate_scenario
from eval.metrics import compute_random_baseline, compute_tool_call_accuracy
from eval.runner import run_scenario_layer1


class TestScenarioLoading:
    """Verify all scenario YAML files load and validate correctly."""

    def test_all_scenarios_load(self):
        from eval.loader import load_all_scenarios

        scenarios = load_all_scenarios()
        assert len(scenarios) >= 9

    def test_each_scenario_has_required_fields(self):
        from eval.loader import load_all_scenarios

        for s in load_all_scenarios():
            assert s.name, "Scenario missing name"
            assert s.workflow, f"Scenario {s.name} missing workflow"
            assert s.user_input, f"Scenario {s.name} missing user_input"
            assert (
                s.expected_tool_calls
            ), f"Scenario {s.name} missing expected_tool_calls"
            assert s.expected_goal, f"Scenario {s.name} missing expected_goal"
            assert s.mock_responses, f"Scenario {s.name} missing mock_responses"
            assert (
                s.scripted_llm_responses
            ), f"Scenario {s.name} missing scripted_llm_responses"

    def test_all_scenarios_validate(self):
        from eval.loader import load_all_scenarios

        for s in load_all_scenarios():
            warnings = validate_scenario(s)  # raises on fatal errors
            assert not warnings, f"Scenario {s.name} has warnings: {warnings}"

    def test_workflow_names_are_valid(self):
        from eval.loader import load_all_scenarios
        from LbAgents import WORKFLOW_REGISTRY

        for s in load_all_scenarios():
            assert (
                s.workflow in WORKFLOW_REGISTRY
            ), f"Scenario {s.name} references unknown workflow '{s.workflow}'"


class TestCIFailureScenarios:
    """Layer 1 tests for CI failure diagnosis workflows."""

    @pytest.fixture(
        params=[
            "ci_failure_memory_limit",
            "ci_failure_cvmfs_missing",
            "ci_failure_api_error",
        ]
    )
    def scenario(self, request):
        return load_scenario(SCENARIOS_DIR / f"{request.param}.yaml")

    def test_scenario_runs_without_error(self, scenario):
        result = run_scenario_layer1(scenario)
        assert result.error is None, f"Scenario {scenario.name} failed: {result.error}"

    def test_produces_tool_calls(self, scenario):
        result = run_scenario_layer1(scenario)
        assert len(result.actual_tool_calls) > 0, f"No tool calls in {scenario.name}"

    def test_tool_call_names_match(self, scenario):
        result = run_scenario_layer1(scenario)
        expected_names = [tc.tool_name for tc in scenario.expected_tool_calls]
        actual_names = [tc["tool_name"] for tc in result.actual_tool_calls]
        for name in expected_names:
            assert (
                name in actual_names
            ), f"Expected tool {name} not found in actual calls for {scenario.name}"

    def test_final_response_not_empty(self, scenario):
        result = run_scenario_layer1(scenario)
        assert result.final_response, f"Empty final response for {scenario.name}"

    def test_tool_call_accuracy_above_threshold(self, scenario):
        result = run_scenario_layer1(scenario)
        accuracy = compute_tool_call_accuracy(scenario, result)
        assert (
            accuracy >= 0.5
        ), f"Tool call accuracy {accuracy:.2f} below threshold for {scenario.name}"

    def test_beats_random_baseline(self, scenario):
        """Ordered accuracy must strictly beat random (order matters)."""
        result = run_scenario_layer1(scenario)
        baseline = compute_random_baseline(scenario)
        ordered_acc = compute_tool_call_accuracy(scenario, result, ordered=True)
        assert ordered_acc > baseline.tool_call_accuracy_ordered, (
            f"Ordered accuracy {ordered_acc:.2f} does not beat random baseline "
            f"{baseline.tool_call_accuracy_ordered:.2f} for {scenario.name}"
        )


class TestStuckProductionScenarios:
    """Layer 1 tests for stuck production diagnosis workflows."""

    @pytest.fixture(
        params=[
            "stuck_production_maxreset",
            "stuck_production_stalled",
            "stuck_production_empty_response",
        ]
    )
    def scenario(self, request):
        return load_scenario(SCENARIOS_DIR / f"{request.param}.yaml")

    def test_scenario_runs_without_error(self, scenario):
        result = run_scenario_layer1(scenario)
        assert result.error is None, f"Scenario {scenario.name} failed: {result.error}"

    def test_produces_tool_calls(self, scenario):
        result = run_scenario_layer1(scenario)
        assert len(result.actual_tool_calls) > 0, f"No tool calls in {scenario.name}"

    def test_tool_call_names_match(self, scenario):
        result = run_scenario_layer1(scenario)
        expected_names = [tc.tool_name for tc in scenario.expected_tool_calls]
        actual_names = [tc["tool_name"] for tc in result.actual_tool_calls]
        for name in expected_names:
            assert (
                name in actual_names
            ), f"Expected tool {name} not found in actual calls for {scenario.name}"

    def test_final_response_not_empty(self, scenario):
        result = run_scenario_layer1(scenario)
        assert result.final_response, f"Empty final response for {scenario.name}"

    def test_tool_call_accuracy_above_threshold(self, scenario):
        result = run_scenario_layer1(scenario)
        accuracy = compute_tool_call_accuracy(scenario, result)
        assert (
            accuracy >= 0.5
        ), f"Tool call accuracy {accuracy:.2f} below threshold for {scenario.name}"

    def test_beats_random_baseline(self, scenario):
        """Ordered accuracy must strictly beat random (order matters)."""
        result = run_scenario_layer1(scenario)
        baseline = compute_random_baseline(scenario)
        ordered_acc = compute_tool_call_accuracy(scenario, result, ordered=True)
        assert ordered_acc > baseline.tool_call_accuracy_ordered, (
            f"Ordered accuracy {ordered_acc:.2f} does not beat random baseline "
            f"{baseline.tool_call_accuracy_ordered:.2f} for {scenario.name}"
        )


class TestMattermostScenarios:
    """Layer 1 tests for Mattermost user request workflows."""

    @pytest.fixture(
        params=[
            "mattermost_why_stuck",
            "mattermost_ci_failed",
            "mattermost_api_timeout",
        ]
    )
    def scenario(self, request):
        return load_scenario(SCENARIOS_DIR / f"{request.param}.yaml")

    def test_scenario_runs_without_error(self, scenario):
        result = run_scenario_layer1(scenario)
        assert result.error is None, f"Scenario {scenario.name} failed: {result.error}"

    def test_produces_tool_calls(self, scenario):
        result = run_scenario_layer1(scenario)
        assert len(result.actual_tool_calls) > 0, f"No tool calls in {scenario.name}"

    def test_tool_call_names_match(self, scenario):
        result = run_scenario_layer1(scenario)
        expected_names = [tc.tool_name for tc in scenario.expected_tool_calls]
        actual_names = [tc["tool_name"] for tc in result.actual_tool_calls]
        for name in expected_names:
            assert (
                name in actual_names
            ), f"Expected tool {name} not found in actual calls for {scenario.name}"

    def test_final_response_not_empty(self, scenario):
        result = run_scenario_layer1(scenario)
        assert result.final_response, f"Empty final response for {scenario.name}"

    def test_tool_call_accuracy_above_threshold(self, scenario):
        result = run_scenario_layer1(scenario)
        accuracy = compute_tool_call_accuracy(scenario, result)
        assert (
            accuracy >= 0.5
        ), f"Tool call accuracy {accuracy:.2f} below threshold for {scenario.name}"

    def test_beats_random_baseline(self, scenario):
        """Ordered accuracy must strictly beat random (order matters)."""
        result = run_scenario_layer1(scenario)
        baseline = compute_random_baseline(scenario)
        ordered_acc = compute_tool_call_accuracy(scenario, result, ordered=True)
        assert ordered_acc > baseline.tool_call_accuracy_ordered, (
            f"Ordered accuracy {ordered_acc:.2f} does not beat random baseline "
            f"{baseline.tool_call_accuracy_ordered:.2f} for {scenario.name}"
        )
