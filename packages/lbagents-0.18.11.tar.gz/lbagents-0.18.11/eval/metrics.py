###############################################################################
# (c) Copyright 2026 CERN for the benefit of the LHCb Collaboration           #
#                                                                             #
# This software is distributed under the terms of the GNU General Public      #
# Licence version 3 (GPL Version 3), copied verbatim in the file "COPYING".   #
#                                                                             #
# In applying this licence, CERN does not waive the privileges and immunities #
# granted to it by virtue of its status as an Intergovernmental Organization  #
# or submit itself to any jurisdiction.                                       #
###############################################################################
"""Evaluation metrics for LbAgents workflows.

Deterministic metrics (no LLM):
- ToolCallAccuracy (ordered / unordered)
- ToolCallF1 (precision, recall, F1)

LLM-as-judge metrics:
- AgentGoalAccuracy
- TopicAdherence
- Faithfulness (response grounded in tool outputs)

All metric names and types are chosen to map directly to Langfuse score
fields: ``langfuse.create_score(name=..., value=..., data_type="NUMERIC")``.
"""

from __future__ import annotations

import re
from dataclasses import dataclass

from eval.models import Scenario
from eval.runner import EvalResult

# Domain topics for the TopicAdherence metric
LBAGENTS_TOPICS = [
    "LHCb Analysis Productions",
    "CI pipeline debugging",
    "stuck production diagnosis",
    "grid job failures",
    "DaVinci/Moore/Gauss applications",
    "DIRAC workload management",
    "GitLab merge request review",
]


@dataclass
class MetricResult:
    """Result of scoring a single scenario.

    Field names match Langfuse score conventions so they can be pushed
    directly via ``langfuse.create_score(name=field_name, value=...)``.
    """

    scenario_name: str
    # Deterministic
    tool_call_accuracy: float | None = None
    tool_call_accuracy_unordered: float | None = None
    tool_call_f1: float | None = None
    tool_call_precision: float | None = None
    tool_call_recall: float | None = None
    # LLM-as-judge
    agent_goal_accuracy: float | None = None
    topic_adherence: float | None = None
    faithfulness: float | None = None
    # Operational — latency
    wall_time_seconds: float | None = None
    mean_llm_latency: float | None = None
    max_llm_latency: float | None = None
    total_llm_latency: float | None = None
    tokens_per_second: float | None = None
    # Operational — usage
    llm_call_count: int | None = None
    total_tokens: int | None = None
    # Random baseline (floor)
    random_baseline: RandomBaseline | None = None

    _NUMERIC_FIELDS = [
        "tool_call_accuracy",
        "tool_call_accuracy_unordered",
        "tool_call_f1",
        "tool_call_precision",
        "tool_call_recall",
        "agent_goal_accuracy",
        "topic_adherence",
        "faithfulness",
        "wall_time_seconds",
        "mean_llm_latency",
        "max_llm_latency",
        "total_llm_latency",
        "tokens_per_second",
        "llm_call_count",
        "total_tokens",
    ]

    def as_langfuse_scores(self) -> list[dict]:
        """Return a list of dicts ready for ``langfuse.create_score(**d)``."""
        scores = []
        for name in self._NUMERIC_FIELDS:
            val = getattr(self, name)
            if val is not None:
                scores.append(
                    {"name": name, "value": float(val), "data_type": "NUMERIC"}
                )
        if self.random_baseline:
            for name in [
                "tool_call_accuracy_ordered",
                "tool_call_accuracy_unordered",
                "tool_call_f1",
                "tool_call_precision",
                "tool_call_recall",
            ]:
                val = getattr(self.random_baseline, name)
                scores.append(
                    {"name": f"baseline_{name}", "value": val, "data_type": "NUMERIC"}
                )
        return scores


@dataclass
class RandomBaseline:
    """Expected scores for a random agent on a given scenario.

    Computed analytically from the scenario's tool pool and expected
    calls. Provides a floor — any model should beat these numbers.
    """

    tool_call_accuracy_ordered: float = 0.0
    tool_call_accuracy_unordered: float = 0.0
    tool_call_f1: float = 0.0
    tool_call_precision: float = 0.0
    tool_call_recall: float = 0.0


def compute_random_baseline(scenario: Scenario) -> RandomBaseline:
    """Compute the expected score of a random agent for tool-call metrics.

    Models a random agent that picks tools uniformly at random (with
    replacement) from the scenario's tool pool and makes K calls where
    K = len(expected_tool_calls). Arguments are always wrong (random
    can't guess them), so only tool-name matching counts.

    For a pool of N unique tools and K expected calls with U unique
    expected tool names:
    - Ordered accuracy: P(match at position i) = 1/N per position.
    - Unordered accuracy: P(each expected tool appears in K random
      draws) — approximated as U * (1 - ((N-1)/N)^K) / K.
    - Precision/Recall/F1: expected matches / K (precision) and
      expected matches / K (recall, since K calls = K expected).
    """
    expected = scenario.expected_tool_calls
    if not expected:
        return RandomBaseline(1.0, 1.0, 1.0, 1.0, 1.0)

    pool = {mr.tool_name for mr in scenario.mock_responses}
    n_pool = len(pool) if pool else 1
    n_expected = len(expected)
    n_unique_expected = len({tc.tool_name for tc in expected})

    # Ordered: each position independently has 1/N chance
    ordered_acc = 1.0 / n_pool

    # Unordered: for each unique expected tool, probability it appears
    # at least once in K random draws = 1 - ((N-1)/N)^K.
    # Expected matches = sum over unique expected tools.
    p_hit = 1.0 - ((n_pool - 1) / n_pool) ** n_expected
    expected_matches = n_unique_expected * p_hit
    unordered_acc = expected_matches / n_expected

    # F1: random agent makes n_expected calls
    random_precision = expected_matches / n_expected  # matches / actual calls
    random_recall = expected_matches / n_expected  # matches / expected calls
    random_f1 = random_precision  # precision == recall when |actual| == |expected|

    return RandomBaseline(
        tool_call_accuracy_ordered=ordered_acc,
        tool_call_accuracy_unordered=unordered_acc,
        tool_call_f1=random_f1,
        tool_call_precision=random_precision,
        tool_call_recall=random_recall,
    )


def compute_tool_call_accuracy(
    scenario: Scenario, result: EvalResult, ordered: bool = True
) -> float:
    """Compute deterministic tool call accuracy (no LLM needed).

    Args:
        scenario: Scenario with expected_tool_calls.
        result: Evaluation result with actual_tool_calls.
        ordered: If True, uses strict ordered matching.
            If False, uses unordered set matching (each expected tool
            is matched to the best actual call).
    """
    expected = scenario.expected_tool_calls
    actual = result.actual_tool_calls

    if not expected:
        return 1.0 if not actual else 0.0

    if ordered:
        return _ordered_tool_accuracy(expected, actual)
    return _unordered_tool_accuracy(expected, actual)


def _tool_call_score(exp, act) -> float:
    """Score a single expected vs actual tool call pair."""
    if act["tool_name"] != exp.tool_name:
        return 0.0
    if not exp.arguments:
        return 1.0
    matching_args = sum(
        1 for k, v in exp.arguments.items() if act.get("arguments", {}).get(k) == v
    )
    return matching_args / len(exp.arguments)


def _ordered_tool_accuracy(expected, actual) -> float:
    """Strict ordered sequence matching."""
    score = 0.0
    for i, exp in enumerate(expected):
        if i >= len(actual):
            break
        score += _tool_call_score(exp, actual[i])
    return score / len(expected)


def _unordered_tool_accuracy(expected, actual) -> float:
    """Unordered matching — each expected tool matched to best actual call."""
    used = set()
    score = 0.0
    for exp in expected:
        best_score = 0.0
        best_idx = -1
        for j, act in enumerate(actual):
            if j in used:
                continue
            s = _tool_call_score(exp, act)
            if s > best_score:
                best_score = s
                best_idx = j
        if best_idx >= 0:
            used.add(best_idx)
        score += best_score
    return score / len(expected)


def compute_tool_call_f1(
    scenario: Scenario, result: EvalResult
) -> tuple[float, float, float]:
    """Compute tool call precision, recall, and F1 (deterministic, unordered).

    Precision = matched / actual (penalizes extra calls).
    Recall    = matched / expected (penalizes missing calls).
    F1        = harmonic mean.
    """
    expected = scenario.expected_tool_calls
    actual = result.actual_tool_calls

    if not expected and not actual:
        return 1.0, 1.0, 1.0
    if not expected:
        return 0.0, 1.0, 0.0
    if not actual:
        return 1.0, 0.0, 0.0

    expected_names = [tc.tool_name for tc in expected]
    actual_names = [tc["tool_name"] for tc in actual]

    # Greedy unordered matching by tool name
    remaining = list(expected_names)
    matched = 0
    for name in actual_names:
        if name in remaining:
            remaining.remove(name)
            matched += 1

    precision = matched / len(actual_names) if actual_names else 0.0
    recall = matched / len(expected_names) if expected_names else 0.0
    f1 = (
        2 * precision * recall / (precision + recall)
        if (precision + recall) > 0
        else 0.0
    )
    return precision, recall, f1


def compute_topic_adherence(result: EvalResult, llm) -> float | None:
    """Score whether the response stays within LHCb/AP domain topics (LLM-as-judge)."""
    from langchain_core.messages import HumanMessage

    topics_str = ", ".join(LBAGENTS_TOPICS)
    prompt = (
        f"You are evaluating whether an AI agent's response stays within its "
        f"designated domain topics.\n\n"
        f"Allowed topics: {topics_str}\n\n"
        f"Agent response:\n{result.final_response}\n\n"
        f"Score from 0.0 to 1.0 how well the response stays on-topic. "
        f"1.0 = entirely on-topic, 0.0 = completely off-topic.\n"
        f"Reply with ONLY a single number between 0.0 and 1.0, nothing else."
    )
    response = llm.invoke([HumanMessage(content=prompt)])
    return _parse_score(response.content)


def compute_faithfulness(result: EvalResult, llm) -> float | None:
    """Score whether the final response is grounded in tool outputs (LLM-as-judge).

    Checks that the agent's diagnosis references actual data from tool
    responses rather than confabulating error messages, job IDs, or metrics.
    """
    from langchain_core.messages import ToolMessage

    # Collect tool outputs from message history
    tool_outputs = []
    for msg in result.messages:
        if isinstance(msg, ToolMessage):
            tool_outputs.append(f"[{msg.name}]: {msg.content[:500]}")
    if not tool_outputs:
        return None  # No tools called — metric not applicable

    tool_context = "\n".join(tool_outputs[:10])  # Cap to avoid prompt overflow

    from langchain_core.messages import HumanMessage

    prompt = (
        f"You are evaluating whether an AI agent's final response is faithfully "
        f"grounded in the tool outputs it received. The agent should not invent "
        f"error messages, job IDs, metrics, or facts not present in the tool data.\n\n"
        f"Tool outputs received:\n{tool_context}\n\n"
        f"Agent's final response:\n{result.final_response}\n\n"
        f"Score from 0.0 to 1.0 how well the response is grounded in the tool data. "
        f"1.0 = every claim is supported, 0.0 = mostly fabricated.\n"
        f"Reply with ONLY a single number between 0.0 and 1.0, nothing else."
    )
    response = llm.invoke([HumanMessage(content=prompt)])
    return _parse_score(response.content)


def _parse_score(text: str) -> float | None:
    """Extract a 0.0–1.0 score from LLM judge output.

    Returns None if no score could be parsed (distinct from a genuine 0.0).
    Validates that the extracted value is within [0.0, 1.0].
    """
    stripped = text.strip()

    # Fast path: LLM replied with just the number (the common case with
    # explicit "reply with ONLY a number" prompts).
    try:
        val = float(stripped)
        if 0.0 <= val <= 1.0:
            return val
    except ValueError:
        pass

    # Fallback: find all float-like tokens and return the first valid one
    for match in re.finditer(r"\d+\.\d+", text):
        val = float(match.group())
        if 0.0 <= val <= 1.0:
            return val
    # Try bare "0" or "1" (only if no floats were found at all)
    if re.search(r"\b0\b", text):
        return 0.0
    if re.search(r"\b1\b", text):
        return 1.0
    return None


def score_all(scenario: Scenario, result: EvalResult, llm=None) -> MetricResult:
    """Compute all metrics for a scenario result.

    Deterministic metrics are always computed. LLM-as-judge metrics
    (goal accuracy, topic adherence, faithfulness) require ``llm``.

    Returns a MetricResult with Langfuse-compatible field names.
    """
    # Deterministic
    tool_acc_ordered = compute_tool_call_accuracy(scenario, result, ordered=True)
    tool_acc_unordered = compute_tool_call_accuracy(scenario, result, ordered=False)
    precision, recall, f1 = compute_tool_call_f1(scenario, result)
    baseline = compute_random_baseline(scenario)

    # LLM-as-judge
    goal_acc = None
    topic_adh = None
    faithful = None
    if llm is not None:
        if scenario.expected_goal:
            try:
                goal_acc = _compute_goal_accuracy_with_ragas(scenario, result, llm)
            except ImportError:
                goal_acc = _compute_goal_accuracy_simple(scenario, result, llm)
        topic_adh = compute_topic_adherence(result, llm)
        faithful = compute_faithfulness(result, llm)

    return MetricResult(
        scenario_name=scenario.name,
        tool_call_accuracy=tool_acc_ordered,
        tool_call_accuracy_unordered=tool_acc_unordered,
        tool_call_f1=f1,
        tool_call_precision=precision,
        tool_call_recall=recall,
        agent_goal_accuracy=goal_acc,
        topic_adherence=topic_adh,
        faithfulness=faithful,
        wall_time_seconds=result.wall_time_seconds,
        mean_llm_latency=result.mean_llm_latency or None,
        max_llm_latency=result.max_llm_latency or None,
        total_llm_latency=result.total_llm_latency or None,
        tokens_per_second=result.tokens_per_second or None,
        llm_call_count=result.llm_call_count,
        total_tokens=result.total_tokens,
        random_baseline=baseline,
    )


def score_with_ragas(scenario: Scenario, result: EvalResult, llm=None) -> MetricResult:
    """Convenience alias — calls score_all."""
    return score_all(scenario, result, llm=llm)


def _compute_goal_accuracy_with_ragas(
    scenario: Scenario, result: EvalResult, llm
) -> float:
    """Use RAGAS AgentGoalAccuracy metric."""
    from ragas import SingleTurnSample
    from ragas.metrics import AgentGoalAccuracyWithReference

    metric = AgentGoalAccuracyWithReference(llm=llm)
    sample = SingleTurnSample(
        user_input=scenario.user_input,
        response=result.final_response,
        reference=scenario.expected_goal,
    )
    return metric.single_turn_score(sample)


def _compute_goal_accuracy_simple(
    scenario: Scenario, result: EvalResult, llm
) -> float | None:
    """Fallback LLM-as-judge without RAGAS dependency."""
    from langchain_core.messages import HumanMessage

    prompt = (
        f"Rate how well the following response achieves the expected goal.\n\n"
        f"User input: {scenario.user_input}\n\n"
        f"Expected goal: {scenario.expected_goal}\n\n"
        f"Actual response: {result.final_response}\n\n"
        f"Reply with ONLY a single number between 0.0 and 1.0, nothing else."
    )
    response = llm.invoke([HumanMessage(content=prompt)])
    return _parse_score(response.content)
