###############################################################################
# (c) Copyright 2026 CERN for the benefit of the LHCb Collaboration           #
#                                                                             #
# This software is distributed under the terms of the GNU General Public      #
# Licence version 3 (GPL Version 3), copied verbatim in the file "COPYING".   #
#                                                                             #
# In applying this licence, CERN does not waive the privileges and immunities #
# granted to it by virtue of its status as an Intergovernmental Organization  #
# or submit itself to any jurisdiction.                                       #
###############################################################################
"""Optional Langfuse integration for pushing eval scores.

Scores are pushed only when ``LANGFUSE_SECRET_KEY`` is set.  When the
``langfuse`` package is not installed the module degrades gracefully.
"""

from __future__ import annotations

import logging
import os

logger = logging.getLogger(__name__)


def is_langfuse_enabled() -> bool:
    """Return True when Langfuse credentials are configured."""
    return bool(os.environ.get("LANGFUSE_SECRET_KEY"))


def push_scores(results: list[dict]) -> None:
    """Push evaluation scores to the Langfuse dashboard.

    Each entry in *results* should have a ``"scores"`` dict mapping
    score names to numeric values, as produced by ``_record`` in
    ``test_layer2.py``.

    Does nothing when Langfuse is not configured or not installed.
    """
    if not is_langfuse_enabled():
        return

    try:
        from langfuse import get_client
    except ImportError:
        logger.warning(
            "LANGFUSE_SECRET_KEY is set but the 'langfuse' package is not installed — skipping score push."
        )
        return

    langfuse = get_client()

    for entry in results:
        scenario = entry.get("scenario", "unknown")
        model = entry.get("model", "unknown")
        with langfuse.start_as_current_observation(
            as_type="span",
            name=f"eval-{scenario}",
            metadata={"model": model},
        ) as span:
            for name, value in entry.get("scores", {}).items():
                span.score_trace(name=name, value=float(value), data_type="NUMERIC")

    langfuse.flush()
    logger.info("Pushed %d eval result(s) to Langfuse.", len(results))
