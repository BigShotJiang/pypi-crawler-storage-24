###############################################################################
# (c) Copyright 2026 CERN for the benefit of the LHCb Collaboration           #
#                                                                             #
# This software is distributed under the terms of the GNU General Public      #
# Licence version 3 (GPL Version 3), copied verbatim in the file "COPYING".   #
#                                                                             #
# In applying this licence, CERN does not waive the privileges and immunities #
# granted to it by virtue of its status as an Intergovernmental Organization  #
# or submit itself to any jurisdiction.                                       #
###############################################################################
"""Pytest fixtures for evaluation tests."""

from __future__ import annotations

import pytest

from eval.loader import load_all_scenarios, load_scenario
from eval.models import Scenario


@pytest.fixture(
    params=[
        "ci_failure_memory_limit",
        "ci_failure_cvmfs_missing",
        "ci_failure_api_error",
    ]
)
def ci_failure_scenario(request) -> Scenario:
    """Parametrised fixture for CI failure scenarios."""
    from eval.loader import SCENARIOS_DIR

    return load_scenario(SCENARIOS_DIR / f"{request.param}.yaml")


@pytest.fixture(
    params=[
        "stuck_production_maxreset",
        "stuck_production_stalled",
        "stuck_production_empty_response",
    ]
)
def stuck_production_scenario(request) -> Scenario:
    """Parametrised fixture for stuck production scenarios."""
    from eval.loader import SCENARIOS_DIR

    return load_scenario(SCENARIOS_DIR / f"{request.param}.yaml")


@pytest.fixture(
    params=[
        "mattermost_why_stuck",
        "mattermost_ci_failed",
        "mattermost_api_timeout",
    ]
)
def mattermost_scenario(request) -> Scenario:
    """Parametrised fixture for Mattermost scenarios."""
    from eval.loader import SCENARIOS_DIR

    return load_scenario(SCENARIOS_DIR / f"{request.param}.yaml")


@pytest.fixture
def all_scenarios() -> list[Scenario]:
    """Load all evaluation scenarios."""
    return load_all_scenarios()
