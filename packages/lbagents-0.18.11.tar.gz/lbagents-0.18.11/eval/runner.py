###############################################################################
# (c) Copyright 2026 CERN for the benefit of the LHCb Collaboration           #
#                                                                             #
# This software is distributed under the terms of the GNU General Public      #
# Licence version 3 (GPL Version 3), copied verbatim in the file "COPYING".   #
#                                                                             #
# In applying this licence, CERN does not waive the privileges and immunities #
# granted to it by virtue of its status as an Intergovernmental Organization  #
# or submit itself to any jurisdiction.                                       #
###############################################################################
"""Evaluation runner — executes scenarios against compiled graphs."""

from __future__ import annotations

import signal
import time
import uuid
from dataclasses import dataclass, field

from langchain_core.callbacks import BaseCallbackHandler
from langchain_core.messages import HumanMessage
from langgraph.checkpoint.memory import MemorySaver
from langgraph.errors import GraphInterrupt

from eval.mock_llm import collect_tool_calls, make_scripted_llm
from eval.mock_tools import make_mock_tools
from eval.models import Scenario
from LbAgents import WORKFLOW_REGISTRY


@dataclass
class LLMCallStats:
    """Timing and token stats for a single LLM invocation."""

    latency_seconds: float = 0.0
    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0


@dataclass
class EvalResult:
    """Result of running a single evaluation scenario."""

    scenario_name: str
    workflow: str
    messages: list = field(default_factory=list)
    actual_tool_calls: list[dict] = field(default_factory=list)
    final_response: str = ""
    error: str | None = None
    # Operational metrics
    wall_time_seconds: float = 0.0
    llm_call_count: int = 0
    total_tokens: int = 0
    # Per-call breakdown
    llm_calls: list[LLMCallStats] = field(default_factory=list)

    @property
    def mean_llm_latency(self) -> float:
        """Average LLM call latency in seconds."""
        if not self.llm_calls:
            return 0.0
        return sum(c.latency_seconds for c in self.llm_calls) / len(self.llm_calls)

    @property
    def max_llm_latency(self) -> float:
        """Maximum single LLM call latency in seconds."""
        if not self.llm_calls:
            return 0.0
        return max(c.latency_seconds for c in self.llm_calls)

    @property
    def total_llm_latency(self) -> float:
        """Total time spent in LLM calls (excludes tool execution)."""
        return sum(c.latency_seconds for c in self.llm_calls)

    @property
    def tokens_per_second(self) -> float:
        """Overall throughput: total tokens / total LLM latency."""
        if self.total_llm_latency == 0:
            return 0.0
        return self.total_tokens / self.total_llm_latency


class LatencyCallback(BaseCallbackHandler):
    """LangChain callback that records per-call latency and token usage.

    Compatible with Langfuse's callback pattern — when Langfuse is added,
    both callbacks can run side by side on the same invocation.
    """

    def __init__(self):
        self.calls: list[LLMCallStats] = []
        self._start_times: dict[str, float] = {}

    def on_llm_start(self, serialized, prompts, *, run_id, **kwargs):
        self._start_times[str(run_id)] = time.monotonic()

    def on_chat_model_start(self, serialized, messages, *, run_id, **kwargs):
        self._start_times[str(run_id)] = time.monotonic()

    def on_llm_end(self, response, *, run_id, **kwargs):
        start = self._start_times.pop(str(run_id), None)
        latency = time.monotonic() - start if start else 0.0

        stats = LLMCallStats(latency_seconds=latency)
        if response.llm_output and isinstance(response.llm_output, dict):
            usage = response.llm_output.get("token_usage", {})
            stats.prompt_tokens = usage.get("prompt_tokens", 0)
            stats.completion_tokens = usage.get("completion_tokens", 0)
            stats.total_tokens = usage.get("total_tokens", 0)
        self.calls.append(stats)


def run_scenario_layer1(scenario: Scenario) -> EvalResult:
    """Run a scenario with scripted LLM responses (no real LLM needed).

    This is the deterministic Layer 1 evaluation. The LLM responses are
    pre-scripted in the scenario YAML, and tool responses are mocked.
    """
    spec = WORKFLOW_REGISTRY.get(scenario.workflow)
    if spec is None:
        return EvalResult(
            scenario_name=scenario.name,
            workflow=scenario.workflow,
            error=f"Unknown workflow: {scenario.workflow}",
        )

    mock_llm = make_scripted_llm(scenario.scripted_llm_responses)
    mock_tools = make_mock_tools(scenario.mock_responses)

    try:
        graph = spec.factory(
            orchestrator_llm=mock_llm,
            tools=mock_tools,
        )
        compiled = graph.compile(checkpointer=MemorySaver())

        thread_id = f"eval-{uuid.uuid4().hex[:8]}"
        config = {"configurable": {"thread_id": thread_id}}
        initial = {
            "messages": [HumanMessage(content=scenario.user_input)],
            **scenario.initial_state,
        }
        try:
            result = compiled.invoke(initial, config=config)
            messages = result["messages"]
        except GraphInterrupt:
            # Graph paused for human review — expected for workflows with
            # interrupt() nodes. Retrieve the saved state from the checkpointer.
            state = compiled.get_state(config)
            messages = state.values.get("messages", [])

        tool_calls = collect_tool_calls(messages)
        final = messages[-1].content if messages else ""

        return EvalResult(
            scenario_name=scenario.name,
            workflow=scenario.workflow,
            messages=messages,
            actual_tool_calls=tool_calls,
            final_response=final,
        )
    except Exception as e:
        return EvalResult(
            scenario_name=scenario.name,
            workflow=scenario.workflow,
            error=str(e),
        )


class EvalTimeoutError(Exception):
    """Raised when a Layer 2 scenario exceeds its time budget."""


def run_scenario_layer2(
    scenario: Scenario, llm, tools: list | None = None, timeout: int = 120
) -> EvalResult:
    """Run a scenario with a real LLM (Layer 2 evaluation).

    Uses real LLM but mocked tool responses. Suitable for scoring with
    RAGAS ToolCallAccuracy and AgentGoalAccuracy.

    Args:
        scenario: The evaluation scenario.
        llm: A real LangChain chat model.
        tools: Optional real tools. If None, uses mock tools from the scenario.
        timeout: Maximum wall-clock seconds before aborting (default 120).
    """
    spec = WORKFLOW_REGISTRY.get(scenario.workflow)
    if spec is None:
        return EvalResult(
            scenario_name=scenario.name,
            workflow=scenario.workflow,
            error=f"Unknown workflow: {scenario.workflow}",
        )

    eval_tools = tools or make_mock_tools(scenario.mock_responses)
    latency_cb = LatencyCallback()

    def _alarm_handler(signum, frame):
        raise EvalTimeoutError(
            f"Scenario {scenario.name!r} exceeded {timeout}s timeout"
        )

    try:
        graph = spec.factory(
            orchestrator_llm=llm,
            tools=eval_tools,
        )
        compiled = graph.compile(checkpointer=MemorySaver())

        thread_id = f"eval-l2-{uuid.uuid4().hex[:8]}"
        invoke_config = {
            "configurable": {"thread_id": thread_id},
            "callbacks": [latency_cb],
        }
        initial = {
            "messages": [HumanMessage(content=scenario.user_input)],
            **scenario.initial_state,
        }

        old_handler = signal.signal(signal.SIGALRM, _alarm_handler)
        signal.alarm(timeout)
        try:
            t0 = time.monotonic()
            try:
                result = compiled.invoke(initial, config=invoke_config)
                messages = result["messages"]
            except GraphInterrupt:
                state = compiled.get_state(invoke_config)
                messages = state.values.get("messages", [])
            wall_time = time.monotonic() - t0
        finally:
            signal.alarm(0)
            signal.signal(signal.SIGALRM, old_handler)
        tool_calls = collect_tool_calls(messages)
        final = messages[-1].content if messages else ""

        llm_calls, total_tokens = _count_llm_usage(messages)

        return EvalResult(
            scenario_name=scenario.name,
            workflow=scenario.workflow,
            messages=messages,
            actual_tool_calls=tool_calls,
            final_response=final,
            wall_time_seconds=wall_time,
            llm_call_count=llm_calls,
            total_tokens=total_tokens,
            llm_calls=latency_cb.calls,
        )
    except EvalTimeoutError as e:
        return EvalResult(
            scenario_name=scenario.name,
            workflow=scenario.workflow,
            error=str(e),
        )
    except Exception as e:
        return EvalResult(
            scenario_name=scenario.name,
            workflow=scenario.workflow,
            error=str(e),
        )


def _count_llm_usage(messages: list) -> tuple[int, int]:
    """Count LLM calls and total tokens from message metadata."""
    from langchain_core.messages import AIMessage

    llm_calls = 0
    total_tokens = 0
    for msg in messages:
        if isinstance(msg, AIMessage):
            llm_calls += 1
            usage = getattr(msg, "usage_metadata", None)
            if usage and isinstance(usage, dict):
                total_tokens += usage.get("total_tokens", 0)
    return llm_calls, total_tokens
