###############################################################################
# (c) Copyright 2026 CERN for the benefit of the LHCb Collaboration           #
#                                                                             #
# This software is distributed under the terms of the GNU General Public      #
# Licence version 3 (GPL Version 3), copied verbatim in the file "COPYING".   #
#                                                                             #
# In applying this licence, CERN does not waive the privileges and immunities #
# granted to it by virtue of its status as an Intergovernmental Organization  #
# or submit itself to any jurisdiction.                                       #
###############################################################################
"""Evaluation framework for LbAgents workflows.

Two-layer evaluation:
- Layer 1 (no LLM): Deterministic tool execution with scripted LLM responses.
- Layer 2 (with LLM): Full agent loop scored with RAGAS metrics.
"""

from eval.loader import load_all_scenarios, load_scenario, load_scenarios_for_workflow
from eval.metrics import (
    MetricResult,
    RandomBaseline,
    compute_random_baseline,
    compute_tool_call_accuracy,
    compute_tool_call_f1,
    score_all,
)
from eval.mock_tools import ToolError, make_mock_tools
from eval.models import ExpectedToolCall, MockToolResponse, Scenario
from eval.runner import EvalResult, run_scenario_layer1, run_scenario_layer2

__all__ = [
    "EvalResult",
    "ExpectedToolCall",
    "MetricResult",
    "RandomBaseline",
    "ToolError",
    "compute_random_baseline",
    "make_mock_tools",
    "MockToolResponse",
    "Scenario",
    "compute_tool_call_accuracy",
    "compute_tool_call_f1",
    "load_all_scenarios",
    "load_scenario",
    "load_scenarios_for_workflow",
    "run_scenario_layer1",
    "run_scenario_layer2",
    "score_all",
]
