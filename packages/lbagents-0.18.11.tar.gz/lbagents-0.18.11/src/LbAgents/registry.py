###############################################################################
# (c) Copyright 2026 CERN for the benefit of the LHCb Collaboration           #
#                                                                             #
# This software is distributed under the terms of the GNU General Public      #
# Licence version 3 (GPL Version 3), copied verbatim in the file "COPYING".   #
#                                                                             #
# In applying this licence, CERN does not waive the privileges and immunities #
# granted to it by virtue of its status as an Intergovernmental Organization  #
# or submit itself to any jurisdiction.                                       #
###############################################################################
from __future__ import annotations

from collections.abc import Callable
from enum import Enum

from pydantic import BaseModel, Field


class TriggerType(str, Enum):
    INTERNAL = "internal"
    WEBHOOK_GITLAB = "webhook_gitlab"
    WEBHOOK_MATTERMOST = "webhook_mattermost"
    SCHEDULE = "schedule"
    MANUAL = "manual"


class DeliveryTarget(str, Enum):
    GITLAB_MR = "gitlab_mr"
    GITLAB_ISSUE = "gitlab_issue"
    MATTERMOST = "mattermost"


class WorkflowSpec(BaseModel):
    name: str
    description: str
    factory: Callable = Field(exclude=True)  # not serialised to API responses
    triggers: list[TriggerType]
    delivery: list[DeliveryTarget]
    requires_review: bool = False
    schedule: str | None = None
    timeout_seconds: int = 600
    llms_required: list[str] = Field(default_factory=lambda: ["orchestrator"])
    tool_allowlist: set[str] | None = None  # None = all MCP tools

    model_config = {"arbitrary_types_allowed": True}


WORKFLOW_REGISTRY: dict[str, WorkflowSpec] = {}


def register_workflow(spec: WorkflowSpec) -> WorkflowSpec:
    """Register a workflow spec in the global registry."""
    WORKFLOW_REGISTRY[spec.name] = spec
    return spec
