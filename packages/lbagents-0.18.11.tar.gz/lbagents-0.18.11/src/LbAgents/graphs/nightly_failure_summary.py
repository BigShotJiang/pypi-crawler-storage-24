###############################################################################
# (c) Copyright 2026 CERN for the benefit of the LHCb Collaboration           #
#                                                                             #
# This software is distributed under the terms of the GNU General Public      #
# Licence version 3 (GPL Version 3), copied verbatim in the file "COPYING".   #
#                                                                             #
# In applying this licence, CERN does not waive the privileges and immunities #
# granted to it by virtue of its status as an Intergovernmental Organization  #
# or submit itself to any jurisdiction.                                       #
###############################################################################
"""Nightly Failure Summary workflow — summarizes test failures from nightly builds.

Single ReAct agent: one LLM with nightly tools queries SQLite databases stored
on S3 and produces a structured summary of test failures.
"""

from __future__ import annotations

import logging

from langchain_core.language_models import BaseChatModel
from langchain_core.messages import AIMessage
from langgraph.graph import END, StateGraph
from langgraph.prebuilt import ToolNode
from openai import BadRequestError

from LbAgents.context import cap_tool_message_content, trim_messages_for_context
from LbAgents.prompts.templates import NIGHTLY_FAILURE_SUMMARY_PROMPT
from LbAgents.schemas.state import NightlyFailureSummaryState

logger = logging.getLogger(__name__)

_DEFAULT_MAX_MESSAGE_TOKENS = 32_000


def build_nightly_failure_summary_graph(
    orchestrator_llm: BaseChatModel,
    tools: list,
    config: dict | None = None,
    max_context_tokens: int | None = None,
    **kwargs,
) -> StateGraph:
    """Build an uncompiled StateGraph for nightly test failure summarization.

    Single ReAct loop: the agent queries nightly test databases and produces
    a structured summary. No write tools or human review needed.

    Args:
        orchestrator_llm: LLM for all reasoning and tool use.
        tools: Nightly query tools (from make_nightly_tools).
        config: Optional configuration dict.
        max_context_tokens: Token budget for messages.

    Returns:
        Uncompiled StateGraph. Caller must call .compile(checkpointer=...).
    """
    llm_with_tools = orchestrator_llm.bind_tools(tools)
    token_budget = max_context_tokens or _DEFAULT_MAX_MESSAGE_TOKENS

    def agent_node(state: NightlyFailureSummaryState):
        """Query nightly results and build a failure summary."""
        messages = NIGHTLY_FAILURE_SUMMARY_PROMPT.format_messages(
            messages=state["messages"]
        )
        messages = trim_messages_for_context(messages, max_tokens=token_budget)
        try:
            response = llm_with_tools.invoke(messages)
        except BadRequestError as exc:
            logger.error("LLM request failed: %s", exc)
            return {
                "messages": [AIMessage(content="Agent stopped: LLM request failed.")],
                "error": str(exc),
            }
        return {"messages": [response]}

    def should_continue(state: NightlyFailureSummaryState):
        """Route: tools if there are tool calls, otherwise END."""
        if state.get("error"):
            return END
        last = state["messages"][-1]
        if not hasattr(last, "tool_calls") or not last.tool_calls:
            return END
        return "tools"

    tool_node = ToolNode(tools)

    async def capped_tools(state: NightlyFailureSummaryState):
        """Run tools and cap oversized ToolMessage content."""
        result = await tool_node.ainvoke(state)
        result["messages"] = cap_tool_message_content(result["messages"])
        return result

    graph = StateGraph(NightlyFailureSummaryState)
    graph.add_node("agent", agent_node)
    graph.add_node("tools", capped_tools)

    graph.set_entry_point("agent")
    graph.add_conditional_edges("agent", should_continue, {"tools": "tools", END: END})
    graph.add_edge("tools", "agent")

    return graph
