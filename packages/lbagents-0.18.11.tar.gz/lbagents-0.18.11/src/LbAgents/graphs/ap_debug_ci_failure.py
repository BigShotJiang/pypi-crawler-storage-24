###############################################################################
# (c) Copyright 2026 CERN for the benefit of the LHCb Collaboration           #
#                                                                             #
# This software is distributed under the terms of the GNU General Public      #
# Licence version 3 (GPL Version 3), copied verbatim in the file "COPYING".   #
#                                                                             #
# In applying this licence, CERN does not waive the privileges and immunities #
# granted to it by virtue of its status as an Intergovernmental Organization  #
# or submit itself to any jurisdiction.                                       #
###############################################################################
"""CI Failure Debug workflow — diagnoses failing CI pipelines for AP merge requests.

Single ReAct agent: one LLM with all tools (pipeline MCP tools + GitLab tools)
investigates the failure, reads the MR diff if available, and posts a review.
"""

from __future__ import annotations

import logging

from langchain_core.language_models import BaseChatModel
from langchain_core.messages import AIMessage, HumanMessage, ToolMessage
from langgraph.graph import END, StateGraph
from langgraph.prebuilt import ToolNode
from openai import BadRequestError

from LbAgents.context import cap_tool_message_content, trim_messages_for_context
from LbAgents.prompts.templates import CI_FAILURE_AGENT_PROMPT
from LbAgents.schemas.state import CIFailureDebugState

logger = logging.getLogger(__name__)

# Default context budget: 40960 (Qwen3...) - 4096 (completion) - 2000 (safety)
_DEFAULT_MAX_MESSAGE_TOKENS = 32_000


def build_ap_debug_ci_failure_graph(
    orchestrator_llm: BaseChatModel,
    tools: list,
    write_tool_names: list[str] | None = None,
    config: dict | None = None,
    max_context_tokens: int | None = None,
) -> StateGraph:
    """Build an uncompiled StateGraph for CI pipeline failure diagnosis.

    Single ReAct loop: the agent investigates the failure using pipeline tools,
    reads the MR diff using GitLab tools, and posts a review — all in one loop.

    Args:
        orchestrator_llm: LLM for all reasoning and tool use.
        tools: All available tools (MCP pipeline tools + GitLab tools).
        write_tool_names: Names of tools that require human approval
            (e.g. ``["post_mr_review"]``).
        config: Optional configuration dict.
        max_context_tokens: Token budget for messages (excluding completion).
            Defaults to 34000 (suitable for 40960-token models with 4096
            completion tokens).

    Returns:
        Uncompiled StateGraph. Caller must call .compile(checkpointer=...).
    """
    write_names = set(write_tool_names or [])
    llm_with_tools = orchestrator_llm.bind_tools(tools)
    token_budget = max_context_tokens or _DEFAULT_MAX_MESSAGE_TOKENS

    def agent_node(state: CIFailureDebugState):
        """Investigate, analyze, and review using all available tools."""
        messages = CI_FAILURE_AGENT_PROMPT.format_messages(messages=state["messages"])
        messages = trim_messages_for_context(messages, max_tokens=token_budget)
        try:
            response = llm_with_tools.invoke(messages)
        except BadRequestError as exc:
            logger.error("LLM request failed: %s", exc)
            return {
                "messages": [AIMessage(content="Agent stopped: LLM request failed.")],
                "error": str(exc),
            }
        return {"messages": [response]}

    def _has_called_tool(state: CIFailureDebugState, tool_name: str) -> bool:
        """Check if a tool has been called (has a ToolMessage response) in the conversation."""
        return any(
            isinstance(m, ToolMessage) and getattr(m, "name", None) == tool_name
            for m in state["messages"]
        )

    def _count_nudges(state: CIFailureDebugState) -> int:
        """Count how many times we've nudged the agent to call post_mr_review."""
        return sum(
            1
            for m in state["messages"]
            if isinstance(m, HumanMessage) and "post_mr_review" in m.content
        )

    def nudge_node(state: CIFailureDebugState):
        """Nudge the agent to call post_mr_review instead of writing text."""
        logger.info("Nudging agent to call post_mr_review tool")
        return {
            "messages": [
                HumanMessage(
                    content=(
                        "You must deliver your analysis by calling the "
                        "`post_mr_review` tool. Do not write the review as "
                        "text — call the tool now with the body parameter."
                    )
                )
            ]
        }

    def should_continue(state: CIFailureDebugState):
        """Route: tools, human_review, nudge (if review not posted), or END."""
        if state.get("error"):
            return END
        last = state["messages"][-1]
        if not hasattr(last, "tool_calls") or not last.tool_calls:
            # If post_mr_review is available but hasn't been called, nudge
            if (
                "post_mr_review" in write_names
                and not _has_called_tool(state, "post_mr_review")
                and _count_nudges(state) < 2
            ):
                return "nudge"
            return END
        if write_names:
            for tc in last.tool_calls:
                if tc["name"] in write_names:
                    return "human_review"
        return "tools"

    tool_node = ToolNode(tools)

    async def capped_tools(state: CIFailureDebugState):
        """Run tools and cap oversized ToolMessage content."""
        result = await tool_node.ainvoke(state)
        result["messages"] = cap_tool_message_content(result["messages"])
        return result

    graph = StateGraph(CIFailureDebugState)
    graph.add_node("agent", agent_node)
    graph.add_node("tools", capped_tools)
    graph.add_node("nudge", nudge_node)

    graph.set_entry_point("agent")
    graph.add_edge("nudge", "agent")

    edges = {"tools": "tools", "nudge": "nudge", END: END}

    if write_names:
        from langgraph.types import interrupt

        def human_review_node(state: CIFailureDebugState):
            """Pause for human approval before write operations.

            On approval: returns empty update so the pending tool calls execute.
            On rejection with feedback: strips the pending tool calls from the
            last AI message and injects feedback as a HumanMessage so the agent
            can revise and try again.
            On rejection without feedback: stops the graph.
            """
            last = state["messages"][-1]
            review_payload = {
                "pending_tool_calls": [
                    tc for tc in last.tool_calls if tc["name"] in write_names
                ],
                "summary": last.content if hasattr(last, "content") else "",
            }
            decision = interrupt(review_payload)

            if decision.get("approved", False):
                return {"review_approved": True}

            feedback = decision.get("feedback", "")
            if not feedback:
                return {
                    "review_approved": False,
                    "messages": [
                        AIMessage(
                            content="Human reviewer rejected the proposed action. Stopping."
                        )
                    ],
                }

            # Strip the rejected tool calls so they don't execute, then
            # feed the reviewer's feedback back to the agent for revision.
            logger.info("Review rejected with feedback, returning to agent")
            revised_last = AIMessage(
                content=last.content if hasattr(last, "content") else "",
            )
            return {
                "review_approved": False,
                "messages": [
                    revised_last,
                    HumanMessage(
                        content=(
                            "The human reviewer rejected your proposed review "
                            "and provided this feedback:\n\n"
                            f"{feedback}\n\n"
                            "Please revise your review based on this feedback "
                            "and call `post_mr_review` again."
                        )
                    ),
                ],
            }

        def after_human_review(state: CIFailureDebugState):
            """Route after human review: tools if approved, agent if rejected with feedback, END otherwise."""
            if state.get("review_approved", False):
                return "tools"
            last = state["messages"][-1]
            if isinstance(last, HumanMessage):
                return "agent"
            return END

        graph.add_node("human_review", human_review_node)
        edges["human_review"] = "human_review"
        graph.add_conditional_edges(
            "human_review",
            after_human_review,
            {"tools": "tools", "agent": "agent", END: END},
        )

    graph.add_conditional_edges("agent", should_continue, edges)
    graph.add_edge("tools", "agent")

    return graph
