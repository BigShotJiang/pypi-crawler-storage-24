###############################################################################
# (c) Copyright 2026 CERN for the benefit of the LHCb Collaboration           #
#                                                                             #
# This software is distributed under the terms of the GNU General Public      #
# Licence version 3 (GPL Version 3), copied verbatim in the file "COPYING".   #
#                                                                             #
# In applying this licence, CERN does not waive the privileges and immunities #
# granted to it by virtue of its status as an Intergovernmental Organization  #
# or submit itself to any jurisdiction.                                       #
###############################################################################
"""Mattermost User Request workflow — support bot for AP user questions.

Called by an admin in a Mattermost channel thread (typically based on a
user's support message). The agent investigates using tools, drafts a
response, then pauses for human verification before the reply is posted.
"""

from __future__ import annotations

import logging

from langchain_core.language_models import BaseChatModel
from langchain_core.messages import AIMessage
from langgraph.graph import END, StateGraph
from langgraph.prebuilt import ToolNode
from langgraph.types import interrupt
from openai import BadRequestError

from LbAgents.context import cap_tool_message_content, trim_messages_for_context
from LbAgents.prompts.templates import MATTERMOST_REQUEST_PROMPT
from LbAgents.schemas.state import MattermostRequestState

logger = logging.getLogger(__name__)

_DEFAULT_MAX_MESSAGE_TOKENS = 34_000


def build_mattermost_debug_user_request_graph(
    orchestrator_llm: BaseChatModel,
    tools: list,
    write_tool_names: list[str] | None = None,
    config: dict | None = None,
    max_context_tokens: int | None = None,
) -> StateGraph:
    """Build an uncompiled StateGraph for Mattermost user request handling.

    The graph implements a ReAct loop that always pauses for human verification
    before the final response is delivered. The admin reviews and may edit the
    response before it is posted to the user.

    Args:
        orchestrator_llm: Primary LLM for interpreting user requests.
        tools: List of tool objects (e.g. from MCP server discovery).
        write_tool_names: Names of tools that require human approval.
        config: Optional configuration dict.

    Returns:
        Uncompiled StateGraph.
    """
    write_names = set(write_tool_names or [])
    llm_with_tools = orchestrator_llm.bind_tools(tools)
    token_budget = max_context_tokens or _DEFAULT_MAX_MESSAGE_TOKENS

    def agent_node(state: MattermostRequestState):
        """Invoke the LLM with the current message history."""
        messages = MATTERMOST_REQUEST_PROMPT.format_messages(messages=state["messages"])
        messages = trim_messages_for_context(messages, max_tokens=token_budget)
        try:
            response = llm_with_tools.invoke(messages)
        except BadRequestError as exc:
            logger.error("LLM request failed: %s", exc)
            return {
                "messages": [AIMessage(content="Agent stopped: LLM request failed.")],
                "error": str(exc),
            }
        return {"messages": [response]}

    def should_continue(state: MattermostRequestState):
        """Route to tools if there are tool calls, otherwise to human verification."""
        if state.get("error"):
            return END
        last = state["messages"][-1]
        if not hasattr(last, "tool_calls") or not last.tool_calls:
            # Agent is done reasoning — pause for human verification before delivery
            return "human_verify"
        # Check for write tools that need separate approval
        if write_names:
            for tc in last.tool_calls:
                if tc["name"] in write_names:
                    return "human_verify"
        return "tools"

    def human_verify_node(state: MattermostRequestState):
        """Pause for admin verification before the response is posted.

        The admin can approve, edit, or reject the agent's response.
        Resume with Command(resume={"approved": True/False, "edited_response": "..."}).
        """
        last = state["messages"][-1]
        review_payload = {
            "draft_response": last.content if hasattr(last, "content") else "",
            "pending_tool_calls": [
                tc for tc in (last.tool_calls if hasattr(last, "tool_calls") else [])
            ],
        }
        decision = interrupt(review_payload)

        if not decision.get("approved", False):
            return {
                "messages": [
                    AIMessage(content="Admin rejected the response. Not posting.")
                ]
            }

        # Admin may have edited the response
        edited = decision.get("edited_response")
        if edited:
            return {"messages": [AIMessage(content=edited)]}
        return {}

    tool_node = ToolNode(tools)

    async def capped_tools(state: MattermostRequestState):
        """Run tools and cap oversized ToolMessage content."""
        result = await tool_node.ainvoke(state)
        result["messages"] = cap_tool_message_content(result["messages"])
        return result

    graph = StateGraph(MattermostRequestState)
    graph.add_node("agent", agent_node)
    graph.add_node("tools", capped_tools)
    graph.add_node("human_verify", human_verify_node)

    graph.set_entry_point("agent")
    graph.add_conditional_edges(
        "agent",
        should_continue,
        {"tools": "tools", "human_verify": "human_verify", END: END},
    )
    graph.add_edge("tools", "agent")
    graph.add_edge("human_verify", END)

    return graph
