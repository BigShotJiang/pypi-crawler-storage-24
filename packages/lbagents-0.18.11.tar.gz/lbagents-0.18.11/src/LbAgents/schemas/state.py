###############################################################################
# (c) Copyright 2026 CERN for the benefit of the LHCb Collaboration           #
#                                                                             #
# This software is distributed under the terms of the GNU General Public      #
# Licence version 3 (GPL Version 3), copied verbatim in the file "COPYING".   #
#                                                                             #
# In applying this licence, CERN does not waive the privileges and immunities #
# granted to it by virtue of its status as an Intergovernmental Organization  #
# or submit itself to any jurisdiction.                                       #
###############################################################################
from __future__ import annotations

import operator
from typing import Annotated, TypedDict

from langchain_core.messages import BaseMessage
from langgraph.graph.message import add_messages


class CIFailureDebugState(TypedDict):
    """State for the ap_debug_ci_failure workflow.

    Diagnoses CI pipeline failures for Analysis Production merge requests.
    A single ReAct agent investigates the failure, reads the MR diff,
    and posts a review on GitLab.
    """

    messages: Annotated[list[BaseMessage], add_messages]
    pipeline_id: int | None
    ci_run_name: str | None
    mr_iid: int | None
    gitlab_project_id: int | None
    review_approved: bool | None
    error: str | None


class JobFinding(TypedDict):
    """Structured finding from a job investigator sub-agent."""

    job_name: str
    ci_run_name: str
    affected_jobs: list[str]
    diagnosis: str
    root_cause: str
    severity: str  # "critical" | "error" | "warning"
    evidence: str  # key error messages, tracebacks, log excerpts
    code_context: str  # cross-repo code paths from RAG trace (set by code_trace)


class CodeReviewComment(TypedDict):
    """An inline review comment produced by the code review sub-agent."""

    file_path: str
    new_line: int
    body: str  # Markdown, may contain ```suggestion blocks


class JobCluster(TypedDict):
    """A cluster of jobs sharing the same failure signature."""

    signature: str
    representative_job: str
    ci_run_name: str
    job_names: list[str]
    failure_summary: dict


class JobInvestigationState(TypedDict):
    """State for a single job investigator sub-agent."""

    messages: Annotated[list[BaseMessage], add_messages]
    pipeline_id: int | None
    ci_run_name: str | None
    job_name: str | None
    affected_jobs: list[str]
    job_findings: Annotated[list[JobFinding], operator.add]
    error: str | None


class CodeReviewState(TypedDict):
    """State for the code review sub-agent."""

    messages: Annotated[list[BaseMessage], add_messages]
    mr_iid: int | None
    pipeline_id: int | None
    code_review_comments: Annotated[list[CodeReviewComment], operator.add]
    error: str | None


class CodeTraceState(TypedDict):
    """State for the code trace sub-agent (coder LLM + RAG tools)."""

    messages: Annotated[list[BaseMessage], add_messages]
    pipeline_id: int | None
    # Input: the investigator's finding to enrich with code context
    finding: JobFinding | None
    # Output: code context discovered by tracing through the knowledge graph
    code_context: str | None
    error: str | None


class MultiAgentCIDebugState(TypedDict):
    """State for the ap_debug_ci_failure_multiagent workflow.

    Multi-agent variant: triage identifies failing jobs, clusters them by
    failure signature, fans out sub-agents for parallel investigation, then
    synthesizes findings into a single MR review.
    """

    messages: Annotated[list[BaseMessage], add_messages]
    pipeline_id: int | None
    ci_run_name: str | None
    mr_iid: int | None
    gitlab_project_id: int | None
    # Triage outputs
    failing_jobs: list[dict]
    job_clusters: list[JobCluster]
    # Fan-out / fan-in
    job_findings: Annotated[list[JobFinding], operator.add]
    code_review_comments: Annotated[list[CodeReviewComment], operator.add]
    # Synthesizer draft (review body text, before code review comments)
    review_body: str | None
    # Review
    review_approved: bool | None
    review_findings: bool
    error: str | None


class StuckProductionState(TypedDict):
    """State for the ap_triage_stuck_production workflow.

    Debugs a single stuck production (MaxReset, stalled). A Celery task
    dispatches one instance of this graph per identified stuck production.
    After diagnosis, pauses for human review before routing to GitLab issues.
    """

    messages: Annotated[list[BaseMessage], add_messages]
    # Input: request_id is the primary entry point (from TransformationFamily)
    request_id: int | None
    # GitLab tracking issue context
    gitlab_project_id: int | None
    gitlab_issue_iid: int | None
    # Stuck transformation IDs and their MaxReset counts
    stuck_transformations: dict[str, int] | None
    error: str | None


class NightlyFailureSummaryState(TypedDict):
    """State for the nightly_failure_summary workflow.

    Summarizes test failures from nightly build results by querying
    per-project SQLite databases stored on S3.
    """

    messages: Annotated[list[BaseMessage], add_messages]
    flavour: str | None
    slot: str | None
    build_id: int | None
    error: str | None


class MattermostRequestState(TypedDict):
    """State for the mattermost_debug_user_request workflow.

    Handles user support questions from Mattermost threads. An admin invokes
    the bot; the agent investigates, then pauses for human verification
    before the response is posted back.
    """

    messages: Annotated[list[BaseMessage], add_messages]
    user_username: str | None
    admin_username: str | None
    intent: str | None
    error: str | None
