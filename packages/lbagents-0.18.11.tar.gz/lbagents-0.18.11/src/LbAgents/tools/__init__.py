###############################################################################
# (c) Copyright 2026 CERN for the benefit of the LHCb Collaboration           #
#                                                                             #
# This software is distributed under the terms of the GNU General Public      #
# Licence version 3 (GPL Version 3), copied verbatim in the file "COPYING".   #
#                                                                             #
# In applying this licence, CERN does not waive the privileges and immunities #
# granted to it by virtue of its status as an Intergovernmental Organization  #
# or submit itself to any jurisdiction.                                       #
###############################################################################
"""LbAgents tool definitions.

Tools in this package are concrete implementations (not placeholders).
They are created via factory functions that accept credentials/config
at runtime — the host application (LbAPI) provides these when building graphs.
"""

from LbAgents.tools.gitlab import make_gitlab_review_tools
from LbAgents.tools.nightly import make_nightly_tools

__all__ = ["make_gitlab_review_tools", "make_nightly_tools"]
