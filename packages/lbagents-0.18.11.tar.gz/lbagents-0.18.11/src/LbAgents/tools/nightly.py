###############################################################################
# (c) Copyright 2026 CERN for the benefit of the LHCb Collaboration           #
#                                                                             #
# This software is distributed under the terms of the GNU General Public      #
# Licence version 3 (GPL Version 3), copied verbatim in the file "COPYING".   #
#                                                                             #
# In applying this licence, CERN does not waive the privileges and immunities #
# granted to it by virtue of its status as an Intergovernmental Organization  #
# or submit itself to any jurisdiction.                                       #
###############################################################################
"""Nightly test results tools for querying SQLite databases from S3.

These tools are created at runtime via ``make_nightly_tools()``, which
accepts a bucket URL and returns tool instances that download per-project
SQLite databases on demand and run queries against them.

The nightly build API at lhcb-nightlies.web.cern.ch is used to discover
which platforms and projects are available for a given build.
"""

from __future__ import annotations

import logging
import sqlite3
import tempfile
from pathlib import Path

import httpx
import zstandard
from langchain_core.tools import tool

logger = logging.getLogger(__name__)

NIGHTLY_API_BASE = "https://lhcb-nightlies.web.cern.ch/api/v1"


def make_nightly_tools(bucket_url: str) -> list:
    """Create nightly test result tools that query SQLite databases from S3.

    All returned tools download databases from the given bucket URL on
    demand and cache them locally for the lifetime of the tool closure.

    Args:
        bucket_url: Base URL of the S3 bucket containing the SQLite databases.
            The expected layout is:
            ``{bucket_url}/{flavour}/{slot}/{build_id}/{platform}/{project}-tests.db``

    Returns:
        List of LangChain tool objects for querying nightly test results.
    """
    # Cache: (flavour, slot, build_id, platform, project) -> Path
    _db_cache: dict[tuple, Path] = {}
    # Cache: (flavour, slot, build_id) -> dict (API JSON)
    _api_cache: dict[tuple, dict] = {}
    _tmpdir = Path(tempfile.mkdtemp(prefix="lbagents-nightly-"))
    _http = httpx.Client(timeout=60.0, follow_redirects=True)

    def _fetch_build_json(flavour: str, slot: str, build_id: int) -> dict:
        """Fetch and cache the build JSON from the nightly API."""
        key = (flavour, slot, build_id)
        if key not in _api_cache:
            url = f"{NIGHTLY_API_BASE}/{flavour}/{slot}/{build_id}/"
            logger.info("Fetching build JSON from %s", url)
            resp = _http.get(url)
            resp.raise_for_status()
            _api_cache[key] = resp.json()
        return _api_cache[key]

    def _download_db(
        flavour: str, slot: str, build_id: int, platform: str, project: str
    ) -> Path | None:
        """Download a project database from S3 and return the local path.

        Returns None if the database does not exist (404).
        """
        key = (flavour, slot, build_id, platform, project)
        if key not in _db_cache:
            url = f"{bucket_url}/{flavour}/{slot}/{build_id}/{platform}/{project}-tests.db"
            local_path = (
                _tmpdir
                / flavour
                / slot
                / str(build_id)
                / platform
                / f"{project}-tests.db"
            )
            local_path.parent.mkdir(parents=True, exist_ok=True)
            logger.info("Downloading %s", url)
            resp = _http.get(url)
            if resp.status_code == 404:
                logger.warning("Database not found: %s", url)
                _db_cache[key] = None
                return None
            resp.raise_for_status()
            local_path.write_bytes(resp.content)
            _db_cache[key] = local_path
        return _db_cache[key]

    def _query_db(db_path: Path, sql: str, params: tuple = ()) -> list[dict]:
        """Run a SQL query and return results as a list of dicts."""
        conn = sqlite3.connect(str(db_path), timeout=10)
        conn.row_factory = sqlite3.Row
        try:
            rows = conn.execute(sql, params).fetchall()
            return [dict(row) for row in rows]
        finally:
            conn.close()

    def _decompress_zstd(data: bytes) -> str:
        """Decompress zstd-compressed data and return as UTF-8 text."""
        dctx = zstandard.ZstdDecompressor()
        return dctx.decompress(data).decode("utf-8", errors="replace")

    @tool
    def get_nightly_status_summary(
        slot: str, build_id: int, flavour: str = "nightly"
    ) -> dict:
        """Get an overview of test results for a nightly build across all platforms and projects.

        Returns per-project/platform counts of passed, failed, and not-run tests.
        This is the primary entry point for understanding a build's health.
        """
        build = _fetch_build_json(flavour, slot, build_id)
        tests = build.get("tests", {})
        if not tests:
            return {"error": "No test results found in build JSON"}

        summary = {}
        errors = []
        for platform, projects in sorted(tests.items()):
            platform_summary = {}
            for project, info in sorted(projects.items()):
                results = info.get("results", {})
                if not results:
                    continue
                counts = {status: len(names) for status, names in results.items()}
                platform_summary[project] = counts
            summary[platform] = platform_summary

        # Download DBs for projects with failures to get detailed counts
        failures_by_platform = {}
        for platform, projects in sorted(tests.items()):
            platform_failures = {}
            for project, info in sorted(projects.items()):
                results = info.get("results", {})
                fail_count = len(results.get("FAIL", []))
                if fail_count > 0:
                    platform_failures[project] = fail_count
            if platform_failures:
                failures_by_platform[platform] = platform_failures

        return {
            "flavour": flavour,
            "slot": slot,
            "build_id": build_id,
            "status_counts": summary,
            "failures_by_platform": failures_by_platform,
            "errors": errors if errors else None,
        }

    @tool
    def list_nightly_platforms(
        slot: str, build_id: int, flavour: str = "nightly"
    ) -> list[str]:
        """List available platforms for a nightly build."""
        build = _fetch_build_json(flavour, slot, build_id)
        return sorted(build.get("tests", {}).keys())

    @tool
    def list_nightly_projects(
        slot: str, build_id: int, platform: str, flavour: str = "nightly"
    ) -> list[str]:
        """List available projects for a given platform in a nightly build."""
        build = _fetch_build_json(flavour, slot, build_id)
        platform_tests = build.get("tests", {}).get(platform, {})
        return sorted(platform_tests.keys())

    @tool
    def get_failed_tests(
        slot: str, build_id: int, platform: str, project: str, flavour: str = "nightly"
    ) -> list[dict]:
        """Get failed tests for a specific project/platform combination.

        Returns test names, causes, exit values, and failed pytest steps.
        """
        db_path = _download_db(flavour, slot, build_id, platform, project)
        if db_path is None:
            return f"No test database available for {project} on {platform}."
        rows = _query_db(
            db_path,
            """
            SELECT t.id, t.name, t.path, t.causes, t.exit_value, t.execution_time,
                   GROUP_CONCAT(s.name, ', ') FILTER (WHERE s.outcome = 'failed') AS failed_steps
            FROM tests t
            LEFT JOIN test_steps s ON s.test_id = t.id
            WHERE t.status = 'failed'
            GROUP BY t.id
            ORDER BY t.causes, t.name
            """,
        )
        return rows

    @tool
    def get_test_output(
        slot: str,
        build_id: int,
        platform: str,
        project: str,
        test_id: int,
        tail_lines: int = 500,
        flavour: str = "nightly",
    ) -> str:
        """Get the stdout/stderr output for a specific test.

        Returns the last N lines (tail) of the test output.
        """
        db_path = _download_db(flavour, slot, build_id, platform, project)
        if db_path is None:
            return f"No test database available for {project} on {platform}."
        conn = sqlite3.connect(str(db_path), timeout=10)
        try:
            row = conn.execute(
                "SELECT output FROM tests WHERE id = ?", (test_id,)
            ).fetchone()
            if not row or not row[0]:
                return "(no output stored for this test)"
            text = _decompress_zstd(row[0])
            lines = text.splitlines()
            if len(lines) > tail_lines:
                return (
                    f"[... showing last {tail_lines} of {len(lines)} lines ...]\n"
                    + "\n".join(lines[-tail_lines:])
                )
            return text
        finally:
            conn.close()

    @tool
    def get_test_measurement(
        slot: str,
        build_id: int,
        platform: str,
        project: str,
        test_id: int,
        measurement_name: str,
        flavour: str = "nightly",
    ) -> str:
        """Get a diagnostic measurement for a specific test.

        Common measurement names: "Output Diff", "CountersMismatch",
        "1DHistogramsMismatch", "Causes", "Validator", "stderr".
        """
        db_path = _download_db(flavour, slot, build_id, platform, project)
        if db_path is None:
            return f"No test database available for {project} on {platform}."
        conn = sqlite3.connect(str(db_path), timeout=10)
        try:
            row = conn.execute(
                "SELECT value_text, value_blob FROM test_measurements WHERE test_id = ? AND name = ?",
                (test_id, measurement_name),
            ).fetchone()
            if not row:
                # List available measurements for this test
                available = conn.execute(
                    "SELECT name FROM test_measurements WHERE test_id = ?", (test_id,)
                ).fetchall()
                names = [r[0] for r in available]
                return f"No measurement '{measurement_name}' for test {test_id}. Available: {names}"
            if row[0] is not None:
                return row[0]
            if row[1] is not None:
                return _decompress_zstd(row[1])
            return "(measurement exists but has no value)"
        finally:
            conn.close()

    return [
        get_nightly_status_summary,
        list_nightly_platforms,
        list_nightly_projects,
        get_failed_tests,
        get_test_output,
        get_test_measurement,
    ]
