---
name: summarize-nightly-failures
description: Summarize test failures from LHCb nightly build results
version: "1.0"
tags: [lhcb, nightly, testing, debugging]
tools:
  - get_nightly_status_summary
  - list_nightly_platforms
  - list_nightly_projects
  - get_failed_tests
  - get_test_output
  - get_test_measurement
---

# Summarize Nightly Test Failures

## Step 1: Get the overview

Call `get_nightly_status_summary(slot, build_id)` to see pass/fail/not-run counts
across all platforms and projects. Identify which project/platform combinations have
failures and how many.

Note which projects are **clean** (no failures on any platform) — mention these briefly
at the end of the summary.

## Step 2: Investigate the worst offenders

For each project/platform combination with significant failures, call
`get_failed_tests(slot, build_id, platform, project)` to get the full list of
failed test names, causes, exit values, and failed pytest steps.

Prioritise by failure count — investigate the combinations with the most failures
first.

## Step 3: Categorize failures

Group failures by pattern. The two main test frameworks produce different diagnostics:

### QMTest failures (have `causes` column set)

Common cause patterns and what they mean:

| Cause pattern | Meaning |
|--------------|---------|
| `Wrong Counters` | Algorithm counter values changed — likely needs reference update |
| `Wrong 1DHistograms`, `Wrong 1DProfiles` | Histogram content changed — likely needs reference update |
| `Missing Counters`, `Missing 1DHistograms` | Expected counters/histograms not produced — algorithm may have been removed or renamed |
| `unexpected standard output` | Stdout differs from reference |
| `FATAL(N), ERROR(N)` | Application produced fatal/error messages |
| `unexpected missing signature` | Expected output signature not found — configuration or plugin issue |
| `Exception in validator` | The test validator itself threw an exception |
| `exit code` | Non-zero exit code (often combined with other causes) |

When you see `Wrong Counters` or `Wrong 1DHistograms` as the **only** cause across
many tests, this almost always means an algorithm change requires reference file updates.

### Pytest failures (have `failed_steps` from test_steps table)

Common failed step names:

| Step | Meaning |
|------|---------|
| `test_returncode` | Application exited with non-zero return code |
| `test_stdout` | Stdout comparison failed |
| `test_counters` | Counter comparison failed |
| `test_histos` | Histogram comparison failed |
| `test_stderr` | Unexpected stderr output |
| `test_expected_files` | Expected output files not produced |
| `test_count_messages` | Wrong number of log messages |
| `test_trackmva`, `test_twotrackmva` | HLT1 line selection validation failed |

### Exit codes

| Code | Meaning |
|------|---------|
| 1 | General error |
| 127 | Command/binary not found |
| 139 | Segmentation fault (SIGSEGV) |
| 101-102 | Application-specific error codes |

## Step 4: Read diagnostic details (if needed)

For failures where the cause is unclear from the metadata alone, use:

- `get_test_output(...)` — read the test stdout/stderr (tail is usually most useful)
- `get_test_measurement(..., "Output Diff")` — see what changed in the output
- `get_test_measurement(..., "CountersMismatch")` — see counter differences
- `get_test_measurement(..., "Causes")` — detailed cause description
- `get_test_measurement(..., "Validator")` — validator output

Only read outputs for a small number of representative failures — do not attempt
to read output for every failed test.

## Step 5: Produce the summary

Structure the summary as follows:

### 1. Failure count table

A table showing failed test counts per platform and project. Only include
project/platform combinations that have failures.

### 2. Key failure categories

Group failures into categories with counts and explanations:
- What tests are affected (name patterns, modules)
- What the likely root cause is
- Whether it affects one platform or all platforms

### 3. Cross-platform patterns

Note which failures appear on all platforms (systemic) vs only specific ones:
- All-platform failures suggest algorithm/code changes needing reference updates
- Single-platform failures suggest compiler or configuration-specific issues
- detdesc-only failures suggest DetDesc/DD4Hep compatibility issues
- CUDA-only failures suggest GPU stack issues

### 4. Clean projects

Briefly list projects with no failures on any platform.

## Guidelines

- Be concise — group similar failures rather than listing every test individually.
- When many tests fail with the same cause pattern, say "N tests fail with Wrong Counters"
  rather than listing all N test names.
- Identify likely root causes where possible (reference updates needed, configuration
  issue, build problem, etc.).
- If a single project dominates failures, investigate whether there's a common thread
  (same module path, same cause pattern, same exit code).
