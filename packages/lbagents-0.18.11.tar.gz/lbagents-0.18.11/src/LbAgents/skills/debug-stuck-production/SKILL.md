---
name: debug-stuck-production
description: Diagnose and triage stuck LHCb Analysis Productions
version: "5.0"
tags: [lhcb, production, debugging, maxreset, analysis-productions, triage]
tools:
  - get_sample_by_request
  - get_sample_details
  - get_sample_progress
  - get_maxreset_files
  - analyze_transformation
  - read_production_file
  - list_production_directory
  - list_job_log_files
  - read_job_log
  - grep_job_log
  - get_grid_job_info
  - get_job_status_history
  - get_grid_job_log_url
  - get_debugging_guide
  - explain_sample_state
  - get_production_repo_path
  - query_code_graph
  - get_code_snippet
---

# Debug a Stuck Production

## Context

Analysis Productions process ~24k samples/year across hundreds of physics
analyses. Productions get "stuck" when jobs repeatedly fail (MaxReset) or
never transition from "new" to "active".

## Steps — follow in order

1. **Resolve sample coordinates.** Call `get_sample_by_request(request_id)`
   to get the correct wg, analysis, version, and name. This returns the
   web URL on the AP website. Do NOT parse sample coordinates from
   transformation names — they are unreliable.

2. Call `get_sample_details` and `get_sample_progress` in parallel (using
   the coordinates from step 1) to get the sample state, transformation
   statuses, and file counts.

3. Identify the stuck transformation(s):
   - **MaxReset > 0** → jobs keep failing, retries exhausted. Go to step 4.
   - **Assigned > 0** → files are currently being processed by running
     jobs, or waiting to be picked up. This is a **normal transient state**,
     not an error. Do not flag Assigned files as problematic.
   - **All Unused** → upstream transformation blocked or sample misconfigured.
   - **NotProcessed > 0** → these files have been deliberately skipped
     by someone (usually the liaison) and will no longer be processed.
     NotProcessed files are a resolved state, not an active problem —
     do not investigate them further unless asked.

4. **Run `analyze_transformation(transformation_id)`** — this is the primary
   diagnostic tool. It downloads job logs from EOS, runs hyperscan pattern
   matching against ~100 known failure patterns, and returns structured
   results grouped by problem type. This replaces manual log reading.

   The output includes:
   - `reason_counts` — how many files hit each failure type
   - `post_analysis_counts` — recovery-relevant classifications
     (HIGH_MEMORY_USAGE, NEEDS_DOWNLOAD_INPUT_DATA, etc.)
   - `problems` — grouped details with LFNs, job IDs, sites, peak memory

5. **Interpret the results** using the classification guide below.

6. If the analysis result has `reason_type` pointing to a code issue
   (e.g. segfault with traceback, exception in user configuration), use
   `read_production_file` to examine the analyst's options and
   `query_code_graph` / `get_code_snippet` to trace the failing code.

7. If the analysis returned no results or you need more context, fall
   back to manual log reading:
   a. Pick a representative **task_id** from `get_maxreset_files`.
   b. `grep_job_log(tid, task_id, "ERROR|FATAL|Exception|Traceback")`
   c. `read_job_log` for context around errors.
   d. If no logs on EOS, use `get_grid_job_info(job_id)`.

8. Call `get_production_repo_path` to get the GitLab link.

9. Present your findings (see Output format below).

## Classification guide — `analyze_transformation` output

### Pre-analysis results (no log reading needed)

| `pre_analysis` | Meaning | Action |
|---|---|---|
| `stalled` | Job watchdog killed it — pilot not running | Check if site-specific. May need reset. |
| `failed_input_data_resolution` | Input files not found at any site | Check replica availability. |
| `no_logse_job_parameter` | No log URL — job never uploaded logs | Use `get_grid_job_info` for status. |
| `no_log_file` | Log archive exists but app log missing | Likely early crash. Check DIRAC.log. |
| `no_xml_summary` | No XMLSummary — app didn't finish cleanly | Check for startup errors. |
| `probably_ok` | File processed OK but task overall failed | Another file in the task caused failure. |
| `needs_group_size_reduction` | Multi-step job can't isolate bad file | Reduce group size to find culprit. |
| `input_data_already_processed` | File was already processed successfully | DIRAC bookkeeping issue. |

### Post-analysis results (recovery-relevant)

| `post_analysis` | Meaning | Recovery |
|---|---|---|
| `high_memory_usage` | Peak RSS > 5 GB | Report as memory issue. Analyst should profile with `lb-ap make-reproducer`. |
| `extremely_high_memory_usage` | Peak RSS > 10 GB | Critical memory issue. Same as above but more urgent. |
| `too_much_memory_for_cgroups` | Peak RSS > 2.8 GB at IN2P3 | Site enforces cgroup limits. Send to hospital or exclude site. |
| `needs_download_input_data` | XRD timeouts — remote file access failing | Switch to download input data strategy. |
| `needs_group_size_reduction` | Need smaller groups to isolate failure | Reduce group size. |
| `too_many_attempts` | Over 20 retries | Something is very wrong — investigate urgently. |

### Reason types (from log pattern matching)

Common `reason_type` values and what they mean:

- **FatalGaudiError** — Gaudi FATAL with context. Read the `match_text`.
- **FunctorCompilationFailure** — JIT functor compilation failed (memory-heavy).
  Recovery: reduce group size, send to hospital.
- **UnknownSegmentationFaultWithTraceback** — Segfault with stack trace.
  Could be data-triggered or a software bug.
- **MaybeOOMKiller** — OOM killer evidence in logs.
- **XRDOperationExpired** / **XRDIssue** — XRootD file access problems.
- **MaybeCorruptedFile** / **KnownCorruptedFile** — Input data corruption.
- **EventTimeout** / **EventWatchdog** — Single event took too long.
- **TTDiraBestVertexReturnsNull** — Known config issue (TupleTool).
- **ReportedFailureMoore954** — Known HLT2 corruption pattern.

## Production file access (CVMFS)

When you need to examine the analyst's configuration:

1. Get the AP version from `get_sample_details` (the `version` field).
2. `list_production_directory(version)` to see the structure.
3. `read_production_file(version, "analysis/info.yaml")` for
   the production spec.
4. `read_production_file(version, "analysis/options.py")` for
   the options file(s) (FunTuple config, DaVinci settings, etc.).

## Interpreting `get_grid_job_info` results

(Fallback — only needed when `analyze_transformation` has no results for a job)

- **"Job stalled: pilot not running"** — pilot was killed. Could be OOM,
  site issue, or pilot bug. Do NOT assume OOM without prmon evidence.
- **"Application Finished With Errors"** — check logs for specifics.
- **"Input Data Not Available"** — staging or data access failure.

## Output format

Present your findings as:

1. **Sample**: `wg/analysis/name` `version`
   - Link: [web_url from `get_sample_by_request`]
   - State: [active/idle/etc], progress: X% (N Processed / M total)

2. **Problem summary**: What the analysis found (e.g. "18/49 files in
   MaxReset, all classified as FunctorCompilationFailure with peak
   memory 6.2 GB across 3 sites")

3. **Classification**: The `reason_type` and `post_analysis` from
   `analyze_transformation`, with the key error message verbatim.

4. **Recommended action**: Pick from the allowed actions below.

5. **Link to production source code** (from `get_production_repo_path`)

## Allowed recommended actions

You MUST only recommend actions from this list. Do not invent actions
or suggest creating GitLab issues — that is not how things are handled.

| Action | When to recommend |
|---|---|
| **Ping an expert in Mattermost** | Default for any non-trivial issue. State what the expert should look at. |
| **Reset and re-run** | Site-specific failures, transient grid issues, stalled jobs. |
| **Exclude site** | Failures concentrated at one grid site. |
| **Reduce group size** | Functor compilation failures, memory issues at boundary. |
| **Send to hospital** | Persistent failures that need isolation from the main queue. |
| **Switch to download input data** | XRootD access failures (XRDOperationExpired, XRDIssue). |
| **Run `lb-ap make-reproducer`** | Code issues (segfaults with traceback, configuration errors) where local reproduction would help diagnosis. |
| **Skip file (NotProcessed)** | Known corrupted input files. |
| **No action needed** | Files in Assigned (normal), NotProcessed (already handled), or probably_ok. |
