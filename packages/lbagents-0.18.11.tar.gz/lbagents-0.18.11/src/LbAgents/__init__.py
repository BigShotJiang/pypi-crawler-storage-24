###############################################################################
# (c) Copyright 2026 CERN for the benefit of the LHCb Collaboration           #
#                                                                             #
# This software is distributed under the terms of the GNU General Public      #
# Licence version 3 (GPL Version 3), copied verbatim in the file "COPYING".   #
#                                                                             #
# In applying this licence, CERN does not waive the privileges and immunities #
# granted to it by virtue of its status as an Intergovernmental Organization  #
# or submit itself to any jurisdiction.                                       #
###############################################################################
"""LbAgents — LangGraph-based agent workflows for LHCb Analysis Productions.

Importing this package populates the WORKFLOW_REGISTRY with all available
workflows via the graphs sub-package.
"""

from __future__ import annotations

# Import graphs to trigger workflow registration
import LbAgents.graphs  # noqa: F401
from LbAgents.registry import WORKFLOW_REGISTRY, WorkflowSpec, register_workflow

__all__ = ["WORKFLOW_REGISTRY", "WorkflowSpec", "register_workflow"]
