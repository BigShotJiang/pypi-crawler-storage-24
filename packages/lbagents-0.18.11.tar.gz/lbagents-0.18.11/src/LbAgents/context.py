###############################################################################
# (c) Copyright 2026 CERN for the benefit of the LHCb Collaboration           #
#                                                                             #
# This software is distributed under the terms of the GNU General Public      #
# Licence version 3 (GPL Version 3), copied verbatim in the file "COPYING".   #
#                                                                             #
# In applying this licence, CERN does not waive the privileges and immunities #
# granted to it by virtue of its status as an Intergovernmental Organization  #
# or submit itself to any jurisdiction.                                       #
###############################################################################
"""Context window management for LLM conversations.

Provides message trimming to prevent ReAct loops from exceeding the model's
context window.  Each iteration adds tool-call + tool-result messages; after
10+ iterations the cumulative token count can exceed the limit even when
individual tool outputs are moderate.

Strategy:
    1. Always keep the system message and first human message (the task).
    2. Always keep the most recent ``keep_recent`` message pairs.
    3. For older messages, aggressively truncate ToolMessage content to a
       short summary so the LLM retains the *sequence* of actions taken
       without the full payloads.
"""

from __future__ import annotations

import logging

from langchain_core.messages import (
    BaseMessage,
    HumanMessage,
    SystemMessage,
    ToolMessage,
)

logger = logging.getLogger(__name__)

# Rough chars-per-token.  Qwen tokenizers average ~3 chars/token for
# English prose, but structured content (JSON, timestamps, log lines)
# tokenises at ~1.5-2 chars/token.  Using 2.0 to avoid under-trimming
# on tool outputs that are mostly structured data.
_CHARS_PER_TOKEN = 2.0

# When truncating old tool messages, keep this many characters of the
# original content as a summary prefix.
_TOOL_SUMMARY_CHARS = 400

# Maximum characters for any single ToolMessage content.  Prevents a
# single huge tool result (e.g. a 100K-char log dump) from consuming
# most of the context window before the trimmer even runs.
# At ~2 chars/token, 8000 chars ≈ 4000 tokens — keeps each tool call
# under ~10% of the typical message budget.
_MAX_TOOL_CONTENT_CHARS = 8_000


def _estimate_tokens(messages: list[BaseMessage]) -> int:
    """Rough token estimate from character count."""
    total_chars = 0
    for msg in messages:
        content = msg.content if isinstance(msg.content, str) else str(msg.content)
        total_chars += len(content)
        # Account for tool_calls metadata (function names, args JSON)
        if hasattr(msg, "tool_calls") and msg.tool_calls:
            for tc in msg.tool_calls:
                total_chars += len(tc.get("name", ""))
                total_chars += len(str(tc.get("args", {})))
    return int(total_chars / _CHARS_PER_TOKEN)


def _truncate_tool_content(msg: ToolMessage) -> ToolMessage:
    """Return a copy of a ToolMessage with truncated content."""
    content = msg.content if isinstance(msg.content, str) else str(msg.content)
    if len(content) <= _TOOL_SUMMARY_CHARS:
        return msg
    summary = (
        content[:_TOOL_SUMMARY_CHARS] + "\n\n[... output truncated for context ...]"
    )
    return ToolMessage(
        content=summary,
        tool_call_id=msg.tool_call_id,
        name=msg.name if hasattr(msg, "name") else None,
    )


def cap_tool_message_content(messages: list[BaseMessage]) -> list[BaseMessage]:
    """Cap ToolMessage content to _MAX_TOOL_CONTENT_CHARS.

    This is a pre-processing step applied to tool results BEFORE they
    accumulate in the conversation history.  It prevents a single huge
    tool result from blowing the context window even if the trimmer's
    token estimate says there's room.

    Non-ToolMessage messages are returned unchanged.

    Args:
        messages: List of messages (typically the output of a ToolNode).

    Returns:
        Same list with oversized ToolMessage content truncated.
    """
    result = []
    for msg in messages:
        if isinstance(msg, ToolMessage):
            content = msg.content if isinstance(msg.content, str) else str(msg.content)
            if len(content) > _MAX_TOOL_CONTENT_CHARS:
                logger.info(
                    "Capping ToolMessage %s from %d to %d chars",
                    getattr(msg, "name", msg.tool_call_id),
                    len(content),
                    _MAX_TOOL_CONTENT_CHARS,
                )
                capped = (
                    content[:_MAX_TOOL_CONTENT_CHARS] + "\n\n[... content truncated — "
                    f"original was {len(content)} chars. "
                    "Use a targeted search tool (grep_job_log, grep_ci_job_log) "
                    "to find specific patterns instead of reading the full output.]"
                )
                result.append(
                    ToolMessage(
                        content=capped,
                        tool_call_id=msg.tool_call_id,
                        name=msg.name if hasattr(msg, "name") else None,
                    )
                )
            else:
                result.append(msg)
        else:
            result.append(msg)
    return result


def trim_messages_for_context(
    messages: list[BaseMessage],
    max_tokens: int,
    keep_recent: int = 6,
) -> list[BaseMessage]:
    """Trim a message list to fit within a token budget.

    Args:
        messages: Full message list (system + human + AI/tool pairs).
        max_tokens: Maximum token budget for the messages (context window
            minus completion tokens minus safety margin).
        keep_recent: Number of recent messages to always keep unmodified.
            Defaults to 6 (typically 3 AI+tool pairs = last 3 iterations).

    Returns:
        Trimmed message list that fits within the token budget.
    """
    if _estimate_tokens(messages) <= max_tokens:
        return messages

    # Split into: head (system + first human), middle (older), tail (recent)
    head: list[BaseMessage] = []
    rest: list[BaseMessage] = []

    for msg in messages:
        if not rest and isinstance(msg, (SystemMessage, HumanMessage)):
            head.append(msg)
        else:
            rest.append(msg)

    # Ensure we have at least one non-head message
    if not rest:
        return messages

    tail = rest[-keep_recent:] if len(rest) > keep_recent else rest
    middle = rest[: len(rest) - len(tail)]

    # Phase 1: Truncate tool messages in the middle section
    trimmed_middle = []
    for msg in middle:
        if isinstance(msg, ToolMessage):
            trimmed_middle.append(_truncate_tool_content(msg))
        else:
            trimmed_middle.append(msg)

    result = head + trimmed_middle + tail
    est = _estimate_tokens(result)

    if est <= max_tokens:
        logger.debug(
            "Trimmed tool messages: %d → %d estimated tokens",
            _estimate_tokens(messages),
            est,
        )
        return result

    # Phase 2: Drop oldest middle messages until we fit
    while (
        trimmed_middle and _estimate_tokens(head + trimmed_middle + tail) > max_tokens
    ):
        trimmed_middle.pop(0)

    result = head + trimmed_middle + tail
    est = _estimate_tokens(result)

    # Phase 3: If still over budget, truncate tool messages in the tail too.
    # The tail's keep_recent messages are normally preserved, but a single
    # large tool result (e.g. 200K-char log grep) can blow the budget alone.
    if est > max_tokens:
        tail = [
            _truncate_tool_content(m) if isinstance(m, ToolMessage) else m for m in tail
        ]
        result = head + trimmed_middle + tail
        est = _estimate_tokens(result)

    logger.info(
        "Trimmed context: %d → %d estimated tokens " "(%d middle messages remaining)",
        _estimate_tokens(messages),
        est,
        len(trimmed_middle),
    )

    return result
