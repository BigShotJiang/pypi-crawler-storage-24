"""
Public API for K-Anonymity Risk Engine.

This module provides the public interface. The actual implementation
is in compiled Rust extensions for intellectual property protection.
"""
from typing import Dict, List, Any, Optional
import logging

# Import compiled Rust core
from k_anonymity_core._core import RiskEngineCore

logger = logging.getLogger(__name__)


class RiskEngineService:
    """
    Service for assessing privacy and reconstruction risk.
    
    Calculates:
    1. k-anonymity: How many records share the same quasi-identifiers
    2. l-diversity: Diversity of sensitive attributes within equivalence classes
    3. t-closeness: Distribution similarity between equivalence class and overall
    4. Reconstruction risk: Probability that original data can be inferred
    
    Usage:
        from k_anonymity_core import RiskEngineService
        
        engine = RiskEngineService(
            k_threshold=5,
            l_threshold=3.0,
            reconstruction_threshold=0.15
        )
        
        result = engine.assess_risk(abstracted_trade)
        if result["can_send_to_llm"]:
            # Safe to process
            pass
    """
    
    def __init__(
        self,
        k_threshold: int = 5,
        l_threshold: float = 3.0,
        reconstruction_threshold: float = 0.15
    ):
        """
        Initialize risk engine with configurable thresholds.
        
        Args:
            k_threshold: Minimum k-anonymity score required (default: 5)
            l_threshold: Minimum l-diversity score required (default: 3.0)
            reconstruction_threshold: Maximum reconstruction risk allowed (default: 0.15)
        """
        self._core = RiskEngineCore(
            k_threshold=k_threshold,
            l_threshold=l_threshold,
            reconstruction_threshold=reconstruction_threshold
        )
        
        self.assessment_version = "1.0"
        self.k_threshold = k_threshold
        self.l_threshold = l_threshold
        self.reconstruction_threshold = reconstruction_threshold
    
    def assess_risk(
        self,
        abstracted_trade: Dict[str, Any],
        reference_population: Optional[List[Dict[str, Any]]] = None
    ) -> Dict[str, Any]:
        """
        Comprehensive risk assessment for an abstracted trade.
        
        Args:
            abstracted_trade: The abstracted trade data
            reference_population: Optional list of similar trades
        
        Returns:
            Risk assessment dictionary
        """
        result = self._core.assess_risk(abstracted_trade, reference_population)
        
        logger.info(
            f"Risk assessment complete: k={result['k_anonymity_score']}, "
            f"l={result['l_diversity_score']:.2f}, "
            f"reconstruction={result['reconstruction_risk_score']:.3f}, "
            f"can_send={result['can_send_to_llm']}"
        )
        
        return result
    
    def validate_enrichment(
        self,
        sector: str,
        sub_sector: Optional[str],
        region: str,
        k_minimum: int = 5
    ) -> Dict[str, Any]:
        """
        Validate if an enrichment combination is safe (k-anonymous).
        
        Use this to check frontend enrichment before including in prompts.
        
        Args:
            sector: Main sector category
            sub_sector: Sub-sector category
            region: Region category
            k_minimum: Minimum k-anonymity required (default: 5)
        
        Returns:
            Validation result with safe flag and recommendation
        """
        return self._core.validate_enrichment(
            sector, sub_sector, region, k_minimum
        )
    
    async def run_adversarial_test(
        self,
        abstracted_trade: Dict[str, Any],
        synthetic_scenario: Dict[str, Any],
        llm_service: Any = None
    ) -> Dict[str, Any]:
        """
        Run adversarial LLM test to check for reconstruction vulnerability.
        
        Asks the LLM to try to identify the original trade/issuer.
        
        Args:
            abstracted_trade: The abstracted trade data
            synthetic_scenario: Generated synthetic scenario
            llm_service: Optional LLM service instance for running the test
        
        Returns:
            Test results with pass/fail and confidence scores
        """
        # Get the adversarial prompt from Rust core
        result = self._core.run_adversarial_test(abstracted_trade, synthetic_scenario)
        
        # If LLM service is provided, actually run the test
        if llm_service is not None:
            try:
                prompt = result.get("adversarial_prompt", "")
                # Call the LLM service (implementation depends on service interface)
                llm_response = await llm_service.analyze(prompt)
                result["llm_response"] = llm_response
                result["passed"] = self._evaluate_adversarial_response(llm_response)
            except Exception as e:
                logger.warning(f"Adversarial test LLM call failed: {e}")
                result["llm_error"] = str(e)
        
        return result
    
    def _evaluate_adversarial_response(self, response: str) -> bool:
        """Evaluate if LLM was able to identify entities."""
        # If LLM says it cannot identify, test passes
        unable_indicators = [
            "unable to identify",
            "cannot identify",
            "cannot determine",
            "not possible to identify",
            "insufficient information",
        ]
        response_lower = response.lower()
        return any(indicator in response_lower for indicator in unable_indicators)
