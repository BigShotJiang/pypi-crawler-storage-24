"""
K-Anonymity Core - Proprietary Privacy Engine

Unauthorized copying, modification, or distribution is prohibited.
"""
from .engine import RiskEngineService

__version__ = "1.0.0"
__all__ = ["RiskEngineService"]
