#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
工具模块
提供速率限制、行为模拟、Chrome 辅助等功能
"""

from .rate_limiter import RateLimiter
from .behavior_simulator import (
    human_like_delay,
    human_like_scroll,
    random_mouse_movement
)
from .chrome_helper import (
    get_system_chrome_user_data_path,
    ensure_project_chrome_data,
    get_chrome_user_data_path
)

__all__ = [
    'RateLimiter',
    'human_like_delay',
    'human_like_scroll',
    'random_mouse_movement',
    'get_system_chrome_user_data_path',
    'ensure_project_chrome_data',
    'get_chrome_user_data_path'
]
