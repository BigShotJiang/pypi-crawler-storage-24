#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
速率限制器
控制请求频率，防止被反爬系统封禁
"""

import time
import logging
from collections import deque
from threading import Lock
from typing import Optional

logger = logging.getLogger(__name__)


class RateLimiter:
    """速率限制器

    实现功能：
    - 每分钟/每小时请求数限制
    - 自动退避机制（失败后增加等待时间）
    - 线程安全

    使用方式：
        limiter = RateLimiter(max_per_minute=15, max_per_hour=500)
        limiter.acquire()  # 阻塞直到可以发送请求
        # ... 发送请求 ...
        limiter.report_success()  # 或 report_failure()
    """

    def __init__(
        self,
        max_per_minute: int = 15,
        max_per_hour: int = 500,
        initial_backoff: float = 1.0,
        max_backoff: float = 60.0,
        backoff_multiplier: float = 2.0
    ):
        """初始化速率限制器

        Args:
            max_per_minute: 每分钟最大请求数
            max_per_hour: 每小时最大请求数
            initial_backoff: 初始退避时间（秒）
            max_backoff: 最大退避时间（秒）
            backoff_multiplier: 退避时间倍增系数
        """
        self.max_per_minute = max_per_minute
        self.max_per_hour = max_per_hour
        self.initial_backoff = initial_backoff
        self.max_backoff = max_backoff
        self.backoff_multiplier = backoff_multiplier

        # 请求时间戳队列
        self._minute_window: deque = deque()
        self._hour_window: deque = deque()

        # 当前退避时间
        self._current_backoff: float = 0.0

        # 连续失败计数
        self._consecutive_failures: int = 0

        # 线程锁
        self._lock = Lock()

        # 统计信息
        self.stats = {
            'total_requests': 0,
            'successful_requests': 0,
            'failed_requests': 0,
            'total_wait_time': 0.0,
            'rate_limit_hits': 0
        }

    def acquire(self, timeout: Optional[float] = None) -> bool:
        """获取请求许可（阻塞直到可以发送请求）

        Args:
            timeout: 超时时间（秒），None 表示无限等待

        Returns:
            bool: 是否成功获取许可
        """
        start_time = time.time()

        with self._lock:
            while True:
                now = time.time()

                # 清理过期记录
                self._cleanup_windows(now)

                # 计算需要等待的时间
                wait_time = self._calculate_wait_time(now)

                # 加上退避时间
                if self._current_backoff > 0:
                    wait_time = max(wait_time, self._current_backoff)
                    logger.debug(f"退避等待: {self._current_backoff:.1f}秒")

                if wait_time <= 0:
                    # 可以发送请求
                    self._minute_window.append(now)
                    self._hour_window.append(now)
                    self.stats['total_requests'] += 1
                    return True

                # 检查超时
                if timeout is not None:
                    elapsed = time.time() - start_time
                    if elapsed + wait_time > timeout:
                        logger.warning(f"速率限制等待超时 (已等待 {elapsed:.1f}秒)")
                        return False

                # 记录统计
                self.stats['total_wait_time'] += wait_time
                self.stats['rate_limit_hits'] += 1
                logger.debug(f"速率限制: 等待 {wait_time:.1f}秒")

                # 释放锁并等待
                self._lock.release()
                try:
                    time.sleep(wait_time)
                finally:
                    self._lock.acquire()

    def report_success(self):
        """报告请求成功"""
        with self._lock:
            self.stats['successful_requests'] += 1
            self._consecutive_failures = 0
            # 成功后逐步减少退避时间
            if self._current_backoff > 0:
                self._current_backoff = max(0, self._current_backoff / self.backoff_multiplier)
                if self._current_backoff < 0.5:
                    self._current_backoff = 0

    def report_failure(self):
        """报告请求失败（触发退避机制）"""
        with self._lock:
            self.stats['failed_requests'] += 1
            self._consecutive_failures += 1

            # 计算新的退避时间
            if self._current_backoff == 0:
                self._current_backoff = self.initial_backoff
            else:
                self._current_backoff = min(
                    self._current_backoff * self.backoff_multiplier,
                    self.max_backoff
                )

            logger.warning(
                f"请求失败，连续失败次数: {self._consecutive_failures}, "
                f"退避时间: {self._current_backoff:.1f}秒"
            )

    def _cleanup_windows(self, now: float):
        """清理过期的时间戳记录"""
        minute_ago = now - 60
        hour_ago = now - 3600

        # 清理分钟窗口
        while self._minute_window and self._minute_window[0] < minute_ago:
            self._minute_window.popleft()

        # 清理小时窗口
        while self._hour_window and self._hour_window[0] < hour_ago:
            self._hour_window.popleft()

    def _calculate_wait_time(self, now: float) -> float:
        """计算需要等待的时间

        Returns:
            float: 需要等待的秒数，0 表示可以立即发送
        """
        wait_time = 0.0

        # 检查分钟限制
        if len(self._minute_window) >= self.max_per_minute:
            oldest_minute = self._minute_window[0]
            wait_for_minute = 60 - (now - oldest_minute)
            wait_time = max(wait_time, wait_for_minute)

        # 检查小时限制
        if len(self._hour_window) >= self.max_per_hour:
            oldest_hour = self._hour_window[0]
            wait_for_hour = 3600 - (now - oldest_hour)
            wait_time = max(wait_time, wait_for_hour)

        return max(0, wait_time)

    def get_stats(self) -> dict:
        """获取统计信息"""
        with self._lock:
            return {
                **self.stats,
                'current_backoff': self._current_backoff,
                'consecutive_failures': self._consecutive_failures,
                'minute_window_size': len(self._minute_window),
                'hour_window_size': len(self._hour_window)
            }

    def reset(self):
        """重置限制器状态"""
        with self._lock:
            self._minute_window.clear()
            self._hour_window.clear()
            self._current_backoff = 0.0
            self._consecutive_failures = 0
            for key in self.stats:
                self.stats[key] = 0 if isinstance(self.stats[key], int) else 0.0
