import secrets
from pathlib import Path
from typing import Optional

import garaga.hints.io as io
from garaga import garaga_rs
from garaga.drand.client import (
    DrandNetwork,
    G2Point,
    digest_func,
    get_chain_info,
    get_randomness,
)
from garaga.drand.tlock import encrypt_for_round
from garaga.signature import hash_to_curve
from garaga.starknet.tests_and_calldata_generators.map_to_curve import *
from garaga.starknet.tests_and_calldata_generators.mpcheck import (
    G1G2Pair,
    MPCheckCalldataBuilder,
)


def drand_round_to_calldata(round_number: int, use_rust=False) -> list[int]:
    if use_rust:
        return _drand_round_to_calldata_rust(round_number)

    message = digest_func(round_number)
    # print(f"round {round_number} message {message}")
    msg_point = hash_to_curve(message, CurveID.BLS12_381, "sha256")

    chain = get_chain_info(DrandNetwork.quicknet.value)

    round = get_randomness(chain.hash, round_number)

    sig_pt = round.signature_point
    ###################
    mpc_builder = MPCheckCalldataBuilder(
        curve_id=CurveID.BLS12_381,
        pairs=[
            G1G2Pair(p=sig_pt, q=G2Point.get_nG(CurveID.BLS12_381, 1)),
            G1G2Pair(p=msg_point, q=-chain.public_key),
        ],
        n_fixed_g2=2,
        public_pair=None,
    )

    cd = []
    sig_pt: G1Point
    cd.append(round_number)
    cd.extend(io.bigint_split(sig_pt.x))
    cd.extend(io.bigint_split(sig_pt.y))
    cd.extend(build_hash_to_curve_hint(message).to_calldata())
    cd.extend(mpc_builder.serialize_to_calldata())

    return [len(cd)] + cd


def _drand_round_to_calldata_rust(
    round_number: int,
) -> list[int]:
    chain = get_chain_info(DrandNetwork.quicknet.value)
    round = get_randomness(chain.hash, round_number)
    randomness = round.randomness
    signature = int(round.signature, 16)
    data = [
        round_number,
        randomness,
        signature,
    ]
    return garaga_rs.drand_calldata_builder(data)


def drand_encrypt_to_calldata(
    round_number: int,
    message: bytes,
    randomness: Optional[bytes] = None,
    use_rust=False,
) -> list[int]:
    if use_rust:
        return _drand_encrypt_to_calldata(round_number, message, randomness)
    chain = get_chain_info(DrandNetwork.quicknet.value)
    cipher_text = encrypt_for_round(
        chain.public_key, round_number, message, randomness is not None, randomness
    )
    cd = []
    cd.append(round_number)
    cd.extend(cipher_text.serialize_to_calldata())
    return [len(cd)] + cd


def _drand_encrypt_to_calldata(
    round_number: int,
    message: bytes,
    randomness: Optional[bytes] = None,
) -> list[int]:
    if randomness is None:
        randomness = secrets.token_bytes(16)
    data = [
        round_number,
        int.from_bytes(message, "big"),
        int.from_bytes(randomness, "big"),
    ]
    return garaga_rs.drand_tlock_encrypt_calldata_builder(data)


def generate_drand_decrypt_constants(
    verifier_class_hash: int, decrypt_contract_path: Path
):
    """Write the verifier class hash to the decrypt contract's constants file."""
    constants_file = decrypt_contract_path / "src" / "drand_decrypt_constants.cairo"
    constants_file.write_text(
        f"// Generated — do not edit manually.\n"
        f"pub const VERIFIER_CLASS_HASH: felt252 = {hex(verifier_class_hash)};\n"
    )


if __name__ == "__main__":

    drand_round_to_calldata(1)
    drand_round_to_calldata(2)
    # drand_round_to_calldata(3)
