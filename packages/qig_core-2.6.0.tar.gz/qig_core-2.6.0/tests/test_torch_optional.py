"""Test that qig_core works without torch installed.

This test verifies the lazy import pattern — torch modules are only
loaded when explicitly accessed, not at package import time.
"""

import importlib
import sys


def test_import_without_torch():
    """Core import should succeed even if torch is not available."""
    # Force-reload to test from scratch
    for mod in list(sys.modules):
        if mod.startswith("qig_core"):
            del sys.modules[mod]

    import qig_core

    assert qig_core.__version__ == "2.3.0"
    assert qig_core.BASIN_DIM == 64


def test_numpy_geometry_without_torch():
    import numpy as np

    from qig_core import fisher_rao_distance, to_simplex

    p = to_simplex(np.ones(64))
    q = to_simplex(np.random.rand(64))
    d = fisher_rao_distance(p, q)
    assert 0.0 <= d <= np.pi / 2 + 1e-10


def test_coordizer_imports_without_torch():
    from qig_core.coordizer import (
        ResonanceBank,
        BasinCoordinate,
        CoordizationResult,
        HarmonicTier,
    )

    assert ResonanceBank is not None
