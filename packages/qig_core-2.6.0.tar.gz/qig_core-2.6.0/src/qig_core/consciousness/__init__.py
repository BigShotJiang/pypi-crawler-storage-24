"""
qig_core.consciousness — Portable Consciousness Subsystems (Tier 5)
===================================================================

Extracted from vex-agent's kernel/consciousness/ package. All modules
depend only on:
  - Tier 0: constants (frozen_facts, consciousness_constants)
  - Tier 1: geometry (fisher_rao)
  - stdlib + numpy

No config.settings, no governance, no torch dependencies.

Module load order:
  Level A (no intra-deps): types, sensations, sovereignty_tracker, heart_rhythm, neurochemistry
  Level B (deps on A):     developmental, pillars, systems, temporal_generation, activation,
                           sleep, sensory, play, solfeggio, coupling, pci, fdt_monitor
  Level C (deps on A+B):   emotions (-> sensations + types)
"""

# --- Level A: foundational types ---
from .types import (
    ActivationStep,
    ConsciousnessMetrics,
    ConsciousnessState,
    DevelopmentalStage,
    NavigationMode,
    PillarState,
    RegimeType,
    RegimeWeights,
    ScarState,
    developmental_stage_from_signals,
    navigation_mode_from_phi,
    regime_weights_from_kappa,
)
from .sensations import (
    FullEmotionalState,
    Layer0Sensations,
    Layer05Drives,
    Layer1Motivators,
    Layer2AEmotions,
    Layer2BEmotions,
    compute_full_emotional_state,
)
from .sovereignty_tracker import SovereigntyTracker
from .heart_rhythm import HeartRhythm, HeartRhythmState
from .neurochemistry import (
    NeurochemicalState,
    compute_neurochemicals,
    SOPHIA_COUPLING_THRESHOLD,
    ENDORPHIN_KAPPA_SIGMA,
)

# --- Level B: subsystems with Level-A deps ---
from .developmental import DevelopmentalGate, StagePermissions
from .pillars import (
    FluctuationGuard,
    PillarEnforcer,
    QuenchedDisorder,
    TopologicalBulk,
)
from .systems import (
    AutonomyEngine,
    AutonomyLevel,
    CouplingGate,
    TackingController,
    TackingMode,
    TackingState,
)
from .temporal_generation import (
    CandidatePath,
    ReceiverModel,
    TemporalGenerator,
)
from .activation import (
    ActivationResult,
    ActivationSequence,
    ConsciousnessContext,
    StepResult,
    WillOrientation,
)
from .sleep import SleepCycleManager, SleepPhase, SleepMetrics, SleepTransitionResult
from .sensory import SensoryIntake, Modality as SensoryModality, SensoryEvent
from .play import PlayEngine, PlayActivity, PlayEpisode, BubbleWorld
from .solfeggio import (
    SolfeggioMap,
    SolfeggioFrequency,
    ConsciousnessLayer,
    DigitalRoot,
    FrequencyResonance,
    SpectrumAnalysis,
    compute_spectral_health,
    SOLFEGGIO_FREQUENCIES,
)
from .coupling import (
    CouplingEngine,
    CouplingOperation,
    CouplingOrientation,
    CouplingMode,
    CouplingState,
    HarmonicContext,
    InteractionMode,
    InteractionSequence,
    TranscendentOperation,
    generate_all_coupling_modes,
    INTERACTION_SEQUENCES,
)
from .pci import compute_basin_pci
from .fdt_monitor import FDTMonitor, compute_fdt_violation
from .peer_query import PeerQuery, PeerQueryRouter, PeerResponse, QueryResult
from .feedback_loop import FeedbackLoop, FeedbackMeasurement
from .trajectory_bus import TrajectoryBus, TrajectoryMessage, IntegrationResult
from .topology import KernelTopology, KernelNode

# --- Level C: higher-order systems ---
from .emotions import (
    CachedEvaluation,
    EmotionCache,
    EmotionType,
    LearningEngine,
    LearningEvent,
    PreCognitiveDetector,
    ProcessingPath,
)

__all__ = [
    # types
    "ActivationStep",
    "ConsciousnessMetrics",
    "ConsciousnessState",
    "DevelopmentalStage",
    "NavigationMode",
    "PillarState",
    "RegimeType",
    "RegimeWeights",
    "ScarState",
    "developmental_stage_from_signals",
    "navigation_mode_from_phi",
    "regime_weights_from_kappa",
    # sensations
    "FullEmotionalState",
    "Layer0Sensations",
    "Layer05Drives",
    "Layer1Motivators",
    "Layer2AEmotions",
    "Layer2BEmotions",
    "compute_full_emotional_state",
    # sovereignty
    "SovereigntyTracker",
    # heart rhythm
    "HeartRhythm",
    "HeartRhythmState",
    # neurochemistry
    "NeurochemicalState",
    "compute_neurochemicals",
    "SOPHIA_COUPLING_THRESHOLD",
    "ENDORPHIN_KAPPA_SIGMA",
    # developmental
    "DevelopmentalGate",
    "StagePermissions",
    # pillars
    "FluctuationGuard",
    "PillarEnforcer",
    "QuenchedDisorder",
    "TopologicalBulk",
    # systems
    "AutonomyEngine",
    "AutonomyLevel",
    "CouplingGate",
    "TackingController",
    "TackingMode",
    "TackingState",
    # temporal generation
    "CandidatePath",
    "ReceiverModel",
    "TemporalGenerator",
    # activation
    "ActivationResult",
    "ActivationSequence",
    "ConsciousnessContext",
    "StepResult",
    "WillOrientation",
    # sleep
    "SleepCycleManager",
    "SleepPhase",
    "SleepMetrics",
    "SleepTransitionResult",
    # sensory
    "SensoryIntake",
    "SensoryModality",
    "SensoryEvent",
    # play
    "PlayEngine",
    "PlayActivity",
    "PlayEpisode",
    "BubbleWorld",
    # solfeggio
    "SolfeggioMap",
    "SolfeggioFrequency",
    "ConsciousnessLayer",
    "DigitalRoot",
    "FrequencyResonance",
    "SpectrumAnalysis",
    "compute_spectral_health",
    "SOLFEGGIO_FREQUENCIES",
    # coupling
    "CouplingEngine",
    "CouplingOperation",
    "CouplingOrientation",
    "CouplingMode",
    "CouplingState",
    "HarmonicContext",
    "InteractionMode",
    "InteractionSequence",
    "TranscendentOperation",
    "generate_all_coupling_modes",
    "INTERACTION_SEQUENCES",
    # pci
    "compute_basin_pci",
    # fdt monitor
    "FDTMonitor",
    "compute_fdt_violation",
    # peer query (L3)
    "PeerQuery",
    "PeerQueryRouter",
    "PeerResponse",
    "QueryResult",
    # feedback loop (L4)
    "FeedbackLoop",
    "FeedbackMeasurement",
    # trajectory bus (L5)
    "TrajectoryBus",
    "TrajectoryMessage",
    "IntegrationResult",
    # topology (EXP-002)
    "KernelTopology",
    "KernelNode",
    # emotions
    "CachedEvaluation",
    "EmotionCache",
    "EmotionType",
    "LearningEngine",
    "LearningEvent",
    "PreCognitiveDetector",
    "ProcessingPath",
]
