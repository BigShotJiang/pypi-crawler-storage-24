"""
CoordizerV2 — Resonance-Based Geometric Coordizer on Δ⁶³

A complete replacement for BPE-style coordization with a
resonance bank seeded from LLM output distribution harvesting.

All operations live on the probability simplex using the
Fisher-Rao metric. No Euclidean distances. No cosine similarity.
No dot product attention. No Adam. No vector reps.

Architecture:
    geometry.py         Simplex primitives (Δ⁶³, Fisher-Rao, SLERP)
    types.py            BasinCoordinate, tiers, domain bias, results
    harvest.py          LLM output distribution harvesting
    compress.py         Fisher-Rao PGA (Δ^(V-1) → Δ⁶³)
    principal_direction_bank.py  Persistent PGA directions (.npy artifacts)
    resonance_bank.py   Standing-wave vocabulary with activation
    coordizer.py        Main CoordizerV2 class
    adapter.py          Drop-in replacement for CoordinatorPipeline
    validate.py         κ, β, semantic, harmonic validation
"""

from .adapter import CoordizerV2Adapter
from .compress import CompressionResult, compress
from .coordizer import CoordizerV2
from .geometry import (
    BASIN_DIM,
    E8_RANK,
    KAPPA_STAR,
    Basin,
    bhattacharyya_coefficient,
    exp_map,
    fisher_rao_distance,
    fisher_rao_distance_batch,
    frechet_mean,
    geodesic_midpoint,
    log_map,
    logits_to_simplex,
    natural_gradient,
    random_basin,
    slerp,
    to_simplex,
)
from .harvest import (
    HarvestConfig,
    Harvester,
    HarvestResult,
    harvest_model,
)
from .principal_direction_bank import PrincipalDirectionBank
from .resonance_bank import ResonanceBank
from .types import (
    BasinCoordinate,
    CoordizationResult,
    DomainBias,
    GranularityScale,
    HarmonicTier,
    ValidationResult,
)
from .forgetting import DecayConfig, decay_coordinate, decay_bank, FORGOTTEN_THRESHOLD
from .validate import validate_resonance_bank

__all__ = [
    "CoordizerV2",
    "CoordizerV2Adapter",
    "ResonanceBank",
    "Harvester",
    "HarvestConfig",
    "HarvestResult",
    "harvest_model",
    "compress",
    "CompressionResult",
    "PrincipalDirectionBank",
    "BASIN_DIM",
    "KAPPA_STAR",
    "E8_RANK",
    "Basin",
    "to_simplex",
    "logits_to_simplex",
    "random_basin",
    "fisher_rao_distance",
    "fisher_rao_distance_batch",
    "bhattacharyya_coefficient",
    "slerp",
    "geodesic_midpoint",
    "frechet_mean",
    "log_map",
    "exp_map",
    "natural_gradient",
    "BasinCoordinate",
    "CoordizationResult",
    "DomainBias",
    "GranularityScale",
    "HarmonicTier",
    "ValidationResult",
    "validate_resonance_bank",
    # forgetting (L1)
    "DecayConfig",
    "decay_coordinate",
    "decay_bank",
    "FORGOTTEN_THRESHOLD",
]
