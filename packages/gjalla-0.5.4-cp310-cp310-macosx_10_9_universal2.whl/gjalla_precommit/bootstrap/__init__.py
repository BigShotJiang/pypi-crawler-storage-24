"""State bootstrap — WebSocket-based codebase analysis."""
