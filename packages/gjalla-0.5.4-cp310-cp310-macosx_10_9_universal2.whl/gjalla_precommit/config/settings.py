"""Configuration settings for gjalla-precommit."""

import os
from pathlib import Path
from typing import Any

import yaml
from pydantic import BaseModel, Field


def get_config_dir() -> Path:
    """Get the configuration directory path.

    Respects HOME environment variable for testing.
    """
    home = os.environ.get("HOME")
    if home:
        return Path(home) / ".gjalla"
    return Path.home() / ".gjalla"


def get_config_file() -> Path:
    """Get the configuration file path."""
    return get_config_dir() / "config.yaml"



class Settings(BaseModel):
    """Application settings loaded from ~/.gjalla/config.yaml with env var overrides."""

    api_key: str = ""
    api_url: str = "https://gjalla.io"
    projects: dict[str, str] = Field(default_factory=dict)  # repo_path -> project_id
    telemetry: bool | None = None
    install_id: str = ""

    @classmethod
    def load(cls) -> "Settings":
        """Load settings from ~/.gjalla/config.yaml, merged with environment variables.

        Environment variable overrides:
        - GJALLA_API_KEY overrides api_key
        - GJALLA_API_URL overrides api_url

        Returns:
            Settings instance with merged configuration.
        """
        data: dict[str, Any] = {}

        # Load from config file if it exists (use function for dynamic HOME)
        config_file = get_config_file()
        if config_file.exists():
            try:
                with open(config_file, encoding="utf-8") as f:
                    file_data = yaml.safe_load(f)
                    if file_data:
                        data = file_data
            except yaml.YAMLError:
                pass

        # Create settings from file data
        settings = cls(**data)

        # Override with environment variables
        env_api_key = os.environ.get("GJALLA_API_KEY")
        if env_api_key:
            settings = settings.model_copy(update={"api_key": env_api_key})

        env_api_url = os.environ.get("GJALLA_API_URL")
        if env_api_url:
            settings = settings.model_copy(update={"api_url": env_api_url})

        return settings

    @classmethod
    def load_for_repo(cls, repo_root: "Path") -> "Settings":
        """Load settings with local project overrides layered on top.

        Delegates to ``resolve_api_context()`` for consistent priority:
        1. GJALLA_API_KEY / GJALLA_API_URL env vars
        2. Local .gjalla/config.yaml (direct api_key, api_key_env, api_url)
        3. Global ~/.gjalla/config.yaml (api_key, api_url)
        4. Defaults ("" / "https://gjalla.io")
        """
        from ..commands._shared import resolve_api_context

        # Load raw global config for non-key/url fields (projects, telemetry, etc.)
        data = load_config()
        # resolve_api_context is the single source of truth for key/url
        api_key, api_url = resolve_api_context(repo_root)
        data["api_key"] = api_key
        data["api_url"] = api_url
        return cls(**data)

    def save(self) -> None:
        """Save settings to ~/.gjalla/config.yaml.

        Creates the ~/.gjalla directory if it doesn't exist.
        """
        # Create directory if missing (use functions for dynamic HOME)
        config_dir = get_config_dir()
        config_file = get_config_file()
        config_dir.mkdir(parents=True, exist_ok=True)

        # Save to YAML file
        with open(config_file, "w", encoding="utf-8") as f:
            yaml.dump(self.model_dump(), f, default_flow_style=False)

    def get_project_id(self, repo_path: Path) -> str | None:
        """Lookup project_id for given repo path.

        Args:
            repo_path: Path to the repository.

        Returns:
            Project ID if found, None otherwise.
        """
        # Normalize path to string for lookup
        path_str = str(repo_path.resolve())
        return self.projects.get(path_str)

    def set_project(self, repo_path: Path, project_id: str) -> None:
        """Set project mapping for a repository path.

        Args:
            repo_path: Path to the repository.
            project_id: Project ID to associate with the path.
        """
        # Normalize path to string for storage
        path_str = str(repo_path.resolve())
        self.projects[path_str] = project_id


def load_config() -> dict[str, Any]:
    """Load configuration from ~/.gjalla/config.yaml.

    Returns:
        Configuration dictionary with api_key, api_url, and projects.
        Empty dict if file is missing or contains invalid YAML.
    """
    data: dict[str, Any] = {}
    config_file = get_config_file()

    if config_file.exists():
        try:
            with open(config_file, encoding="utf-8") as f:
                file_data = yaml.safe_load(f)
                if file_data:
                    data = file_data
        except yaml.YAMLError:
            pass

    return data


def save_config(data: dict[str, Any]) -> None:
    """Save configuration data to the config file.

    This is a convenience function for saving arbitrary config data.
    Merges with existing settings if present.

    Args:
        data: Configuration data to save.
    """
    config_dir = get_config_dir()
    config_file = get_config_file()

    # Load existing config and deep-merge with new data
    existing = load_config()
    for key, value in data.items():
        if key in existing and isinstance(existing[key], dict) and isinstance(value, dict):
            existing[key].update(value)
        else:
            existing[key] = value

    # Create directory if missing
    config_dir.mkdir(parents=True, exist_ok=True)

    # Save to YAML file
    with open(config_file, "w", encoding="utf-8") as f:
        yaml.dump(existing, f, default_flow_style=False)
