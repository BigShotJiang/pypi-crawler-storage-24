import uuid

import requests


class PFCClient:
    def __init__(self, api_url="https://pfc-api.fly.dev", api_key=None, timeout=10):
        self.api_url = api_url.rstrip("/")
        self.api_key = api_key
        self.timeout = timeout

    def _headers(self):
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["x-api-key"] = self.api_key
        return headers

    def evaluate(
        self,
        action,
        subject=None,
        resource=None,
        policy=None,
        context=None,
        irreversible=True,
    ):
        payload = {
            "request_id": str(uuid.uuid4()),
            "action": action,
            "subject": subject or {"type": "agent", "id": "default-agent"},
            "resource": resource or {"type": "system", "id": "default"},
            "proposed_execution": {"irreversible": irreversible},
            "policy": policy or {"policy_id": "default-policy", "rules": {}},
            "context": context or {"environment": "prod", "tenant_id": "default"},
        }

        response = requests.post(
            f"{self.api_url}/v1/evaluate",
            json=payload,
            headers=self._headers(),
            timeout=self.timeout,
        )
        response.raise_for_status()
        return response.json()

    def verify(self, artifact, public_key_pem):
        response = requests.post(
            f"{self.api_url}/v1/verify",
            json={"artifact": artifact, "public_key_pem": public_key_pem},
            headers=self._headers(),
            timeout=self.timeout,
        )
        response.raise_for_status()
        return response.json()
