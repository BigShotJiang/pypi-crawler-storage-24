from functools import wraps

from .client import PFCClient


def guarded_tool(client: PFCClient):
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            decision = client.evaluate(
                action=func.__name__,
                resource={"type": "tool", "id": func.__name__},
            )

            if not decision.get("allow"):
                raise RuntimeError(f"PFC blocked execution: {decision.get('reason')}")

            return func(*args, **kwargs)

        return wrapper

    return decorator
