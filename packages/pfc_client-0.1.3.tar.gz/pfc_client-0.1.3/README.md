# pfc-client

`pfc-client` is the lightweight Python SDK for customers integrating with the PFC API.

## Install

```bash
pip install pfc-client
```

For local development from this repository:

```bash
pip install ./sdk/python
```

## Quickstart

```python
from pfc_client import PFCClient, guarded_tool

client = PFCClient(
    api_url="https://pfc-api.fly.dev",
    api_key="YOUR_API_KEY",
)

decision = client.evaluate(
    action="deploy_production",
    subject={"type": "agent", "id": "website-backend"},
    resource={"type": "service", "id": "checkout-api"},
)

print(decision)
```

## Base URL Configuration

By default the client points to the hosted PFC API:

```python
client = PFCClient()
```

To use a different environment:

```python
client = PFCClient(api_url="https://your-pfc-host.example.com")
```

## API Key Usage

Pass your website customer API key when creating the client:

```python
client = PFCClient(
    api_url="https://pfc-api.fly.dev",
    api_key="pfc_live_your_api_key",
)
```

The SDK sends the key as the `x-api-key` header on evaluate requests.

## Guarded Tool Example

```python
from pfc_client import PFCClient, guarded_tool

client = PFCClient(api_key="pfc_live_your_api_key")


@guarded_tool(client)
def deploy():
    print("Deploying to production")


deploy()
```

## Supported Operations

- `client.evaluate(...)` submits an action for policy and authority evaluation
- `client.verify(...)` verifies an artifact against a public key via the API
