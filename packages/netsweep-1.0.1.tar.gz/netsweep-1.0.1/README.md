Instant network visibility from the command line.
netsweep scans a subnet, discovers live hosts, and checks open ports — all in a single command. No config files, no GUI, no noise.

```
$ netsweep 192.168.1.0/24
```
```
  Network: 192.168.1.0/24  ·  Up: 3  ·  Down: 1  ·  Scanned in 2.8s

 ╭─────────────────┬────────┬────────────────────╮
 │ IP Address      │ Status │ Open Ports         │
 ├─────────────────┼────────┼────────────────────┤
 │ 192.168.1.1     │ ● UP   │ 80/HTTP, 443/HTTPS │
 │ 192.168.1.50    │ ● UP   │ 22/SSH             │
 │ 192.168.1.105   │ ● UP   │ 3306/MySQL         │
 │ 192.168.1.100   │ ● DOWN │ —                  │
 ╰─────────────────┴────────┴────────────────────╯
 ```

Install

```
pip install netsweep
```

Usage

```
# Scan a subnet
netsweep 192.168.1.0/24

# Custom ports
netsweep 192.168.1.0/24 --ports 22 80 443 3306 8080

# Only show live hosts
netsweep 192.168.1.0/24 --up-only

# Save results
netsweep 192.168.1.0/24 --output report.txt

# Tune performance
netsweep 192.168.1.0/24 --workers 100 --timeout 2 --limit 50
```

Features

Parallel scanning — concurrent workers, scans large subnets fast
Port detection — TCP connect scan with named service labels
CIDR support — full subnet ranges or single hosts (/32)
Rich terminal UI — color-coded output, live progress bar
Plain fallback — works without rich if not installed
Export — save clean plain-text reports with --output
Cross-platform — Linux, macOS, Windows (WSL)

Requirements

Python ≥ 3.10
rich ≥ 13.0 — for colored output (optional but recommended)

Useful for: network inventory, deployment verification, firewall validation, on-call debugging, and quick connectivity checks.