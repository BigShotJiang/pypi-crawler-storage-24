import{l as o,a as r}from"../chunks/BUjdNFJn.js";export{o as load_css,r as start};
