"""Optimization utilities."""
