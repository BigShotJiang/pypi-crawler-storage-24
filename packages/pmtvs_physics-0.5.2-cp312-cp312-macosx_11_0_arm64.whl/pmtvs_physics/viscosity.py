"""Hurst-based viscosity analog for manifold departure."""

import numpy as np
from pmtvs_fractal import hurst_exponent


def hurst_viscosity(departure_series: np.ndarray) -> float:
    """
    Viscosity analog from Hurst exponent of departure series.

    Maps the Hurst exponent to a viscosity-like quantity:
        H > 0.5: persistent departure (high viscosity)
                 system resists change — hard to reverse
        H < 0.5: antipersistent departure (low viscosity)
                 system oscillates — may recover
        H = 0.5: random walk (neutral viscosity)

    Returns the Hurst exponent directly as the viscosity analog.
    Range: [0, 1].

    Args:
        departure_series: 1D array of departure distances over time

    Returns:
        float in [0, 1] — viscosity analog
        NaN if series too short (< 50 observations)
    """
    series = np.asarray(departure_series, dtype=np.float64)
    series = series[np.isfinite(series)]
    if len(series) < 50:
        return float('nan')
    try:
        return float(hurst_exponent(series))
    except Exception:
        return float('nan')
