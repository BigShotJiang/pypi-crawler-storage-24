"""
Subspace geometry for manifold departure analysis.
"""

import numpy as np
from pmtvs_physics._core import subspace_angle as _rs_subspace_angle


def subspace_angle(
    V1: np.ndarray,
    V2: np.ndarray,
) -> float:
    """
    Principal angle between two subspaces.

    Measures orientational departure — how differently oriented
    two manifolds are in the same feature space.

    This is the Grassmannian distance between the subspaces
    spanned by V1 and V2. It captures rotational departure
    that centroid distance (geodesic_distance) cannot see:
    two cohorts can be at the same centroid distance from
    the system manifold but have very different orientations.

    Combined with departure_distance:
        geodesic = sqrt(departure_distance² + subspace_angle²)

    Args:
        V1: (d, K1) orthonormal columns — first subspace basis
        V2: (d, K2) orthonormal columns — second subspace basis
            Both must span subspaces of the same ambient space R^d
            d must match between V1 and V2

    Returns:
        float in [0, π/2] — mean principal angle in radians
        0.0 = subspaces are identical (same orientation)
        π/2 = subspaces are perpendicular (maximally different)
        NaN if either input is None, empty, or mismatched

    Math:
        Compute the cross-product matrix M = V1[:, :K].T @ V2[:, :K]
        where K = min(K1, K2).
        SVD of M gives singular values sigma in [0, 1].
        Principal angles = arccos(clip(sigma, -1, 1)).
        Return mean of principal angles.

    Note:
        This is NOT eigendecomposition.
        This is NOT the same as correlation between vectors.
        This measures the geometric angle between LINEAR SUBSPACES,
        not between individual vectors.

    Example:
        V1 = first 2 principal directions of cohort A
        V2 = first 2 principal directions of system manifold
        angle = subspace_angle(V1, V2)
        # angle near 0: cohort A aligned with system
        # angle near π/2: cohort A perpendicular to system
    """
    if V1 is None or V2 is None:
        return float('nan')

    V1 = np.asarray(V1, dtype=np.float64)
    V2 = np.asarray(V2, dtype=np.float64)

    if V1.ndim != 2 or V2.ndim != 2:
        return float('nan')
    if V1.shape[0] != V2.shape[0]:
        return float('nan')
    if V1.shape[1] == 0 or V2.shape[1] == 0:
        return float('nan')

    return float(_rs_subspace_angle(
        np.ascontiguousarray(V1, dtype=np.float64),
        np.ascontiguousarray(V2, dtype=np.float64),
    ))
