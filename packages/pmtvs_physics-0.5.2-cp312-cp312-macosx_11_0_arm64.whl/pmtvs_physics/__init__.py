"""
pmtvs-physics: Physics analogs for signal manifold analysis.

Math functions. Arrays in, scalars/arrays out.
No file IO. No orchestration. No pipeline awareness.

Novel physics analogs applied to manifold departure:
    Reynolds number → laminar vs turbulent departure
    Phase transitions → thermodynamic melting of geometric order
    Dissipation rate → irreversible geometric structure loss
    Subspace angle → Grassmannian distance between manifold orientations
"""

__version__ = "0.5.1"

try:
    from pmtvs_physics._core import subspace_angle as _rs_subspace_angle  # noqa: F401
except ImportError as e:
    raise ImportError(
        f"\n\nRust extension not found: {e}\n"
        f"The pmtvs framework requires compiled Rust extensions.\n"
        f"Install with: cd packages/pmtvs-physics && maturin develop --release\n"
        f"Or rebuild the Docker image.\n"
    ) from e

BACKEND = "rust"

from .viscosity import hurst_viscosity
from .momentum import (
    compute_momentum,
    compute_reynolds_analog,
    classify_flow_regime,
    compute_dissipation_rate,
)
from .thermodynamics import (
    detect_phase_transition,
    free_energy_slope,
)
from .subspace import subspace_angle

__all__ = [
    "hurst_viscosity",
    "compute_momentum",
    "compute_reynolds_analog",
    "classify_flow_regime",
    "compute_dissipation_rate",
    "detect_phase_transition",
    "free_energy_slope",
    "subspace_angle",
]
