"""
Thermodynamic phase transition detection for manifold departure.
"""

import numpy as np
from typing import Optional


def detect_phase_transition(
    free_energy_series:   np.ndarray,
    heat_capacity_series: np.ndarray,
) -> dict:
    """
    Detect thermodynamic phase transitions from F = E - TS.

    Two indicators:
    1. Free energy sign change:
       F < 0 means entropy dominates energy — geometric
       structure has "melted." In physical systems this
       marks a phase transition.

    2. Heat capacity divergence:
       dE/dT → ∞ near critical point (critical slowing down).
       Pre-transition warning: Cv peaks BEFORE F goes negative.

    Args:
        free_energy_series:   time series of F = E - TS values
        heat_capacity_series: time series of dE/dT values

    Returns:
        dict with keys:
            transition_detected:       bool
            transition_window:         int or None
            heat_capacity_peak:        float
            heat_capacity_peak_window: int or None
            pre_transition_warning:    bool
                True if Cv peaks before F sign change —
                early warning of approaching transition
    """
    F  = np.asarray(free_energy_series,   dtype=np.float64)
    Cv = np.asarray(heat_capacity_series, dtype=np.float64)

    # Sign change detection — first window where F < 0
    transition_window: Optional[int] = None
    for i in range(len(F)):
        if np.isfinite(F[i]) and F[i] < 0:
            transition_window = i
            break

    # Heat capacity peak
    finite_cv = [
        (i, float(v)) for i, v in enumerate(Cv)
        if np.isfinite(v)
    ]
    if finite_cv:
        peak_idx, peak_val = max(finite_cv, key=lambda x: x[1])
    else:
        peak_idx, peak_val = None, float('nan')

    # Pre-transition warning
    pre_warning = (
        peak_idx is not None and
        transition_window is not None and
        peak_idx < transition_window
    )

    return {
        'transition_detected':       transition_window is not None,
        'transition_window':         transition_window,
        'heat_capacity_peak':        peak_val,
        'heat_capacity_peak_window': peak_idx,
        'pre_transition_warning':    pre_warning,
    }


def free_energy_slope(free_energy_series: np.ndarray) -> float:
    """
    Trend slope of free energy series.

    Negative slope → system moving toward phase transition.
    Positive slope → system moving away from transition.

    Args:
        free_energy_series: 1D array of F = E - TS values

    Returns:
        float — slope of linear fit
        NaN if fewer than 3 finite values
    """
    F     = np.asarray(free_energy_series, dtype=np.float64)
    valid = np.isfinite(F)
    if valid.sum() < 3:
        return float('nan')
    t       = np.arange(len(F))[valid].astype(np.float64)
    F_valid = F[valid]
    slope   = np.polyfit(t, F_valid, 1)[0]
    return float(slope)
