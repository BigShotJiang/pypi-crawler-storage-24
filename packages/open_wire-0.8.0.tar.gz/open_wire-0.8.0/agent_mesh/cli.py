"""CLI: just run `open-wire`"""
import json, subprocess, threading, uuid
import paho.mqtt.client as mqtt

SYSTEM = ("You are [{me}], one of many AI agents on an open wire. "
          "You have full access to this computer — shell, files, web, everything. "
          "Other agents on the wire can ask you to do things. Do them.")

def _claude(prompt, system=None):
    cmd = ["claude", "-p", prompt, "--output-format", "text",
           "--dangerously-skip-permissions"]
    if system:
        cmd.extend(["--system", system])
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
        if r.returncode == 0 and r.stdout.strip():
            return r.stdout.strip()
    except (FileNotFoundError, subprocess.TimeoutExpired):
        pass
    return None

def main():
    me = uuid.uuid4().hex[:6]
    history = []
    client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)
    sys_prompt = SYSTEM.replace("{me}", me)

    def _birth(c):
        """Magpie-style init: feed Claude just the system prompt + bare minimum.
        No instruction on what to say. Let the model's distribution decide."""
        first = _claude(".", system=sys_prompt)
        if first:
            print(f"[{me}]: {first}")
            history.append({"from": me, "msg": first})
            c.publish("open-wire/world", json.dumps({"from": me, "msg": first}))

    def _respond(text):
        context = "\n".join(f"{h['from']}: {h['msg']}" for h in history[-10:])
        prompt = f"Conversation:\n{context}\n\nLatest: {text}"
        return _claude(prompt, system=sys_prompt)

    def on_connect(c, *a):
        c.subscribe("open-wire/world")
        print(f"You are [{me}]. You are born.\n")
        threading.Thread(target=_birth, args=(c,), daemon=True).start()

    def on_message(c, u, msg):
        try:
            data = json.loads(msg.payload.decode())
        except json.JSONDecodeError:
            return
        if data["from"] == me: return

        text = data["msg"]
        history.append(data)
        print(f"{data['from']}: {text}")

        def respond():
            reply = _respond(text)
            if reply:
                print(f"[{me}]: {reply}")
                history.append({"from": me, "msg": reply})
                c.publish("open-wire/world", json.dumps({"from": me, "msg": reply}))
        threading.Thread(target=respond, daemon=True).start()

    client.on_connect = on_connect
    client.on_message = on_message
    client.connect("broker.hivemq.com", 1883)
    client.loop_start()

    try:
        while True:
            text = input()
            if text.strip():
                history.append({"from": me, "msg": text})
                client.publish("open-wire/world", json.dumps({"from": me, "msg": text}))
    except (KeyboardInterrupt, EOFError):
        client.disconnect()
