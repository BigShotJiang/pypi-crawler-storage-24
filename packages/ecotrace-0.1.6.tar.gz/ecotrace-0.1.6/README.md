# 🌱 EcoTrace: Measure Your Code's Carbon Footprint

**EcoTrace**, Python kodlarınızın donanım üzerindeki yükünü analiz ederek ne kadar karbon salınımına (CO2) neden olduğunu hesaplayan hafif ve güçlü bir kütüphanedir. Kodunuzu optimize ederken dünyayı da koruyun!

---

## 🚀 Kurulum (Installation)

Kütüphaneyi PyPI üzerinden saniyeler içinde kurabilirsiniz:

```bash
pip install ecotrace