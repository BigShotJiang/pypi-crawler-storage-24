# Copyright (c) 2025, NVIDIA CORPORATION.  All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
from pydantic import Field

from aviary.envs.gsm8k import CalculatorEnv, GSM8kDataset, GSM8kDatasetSplit
from resources_servers.aviary.app import AviaryResourcesServer


class GSM8kResourcesServer(AviaryResourcesServer[CalculatorEnv, GSM8kDataset]):
    dataset: GSM8kDataset = Field(default_factory=lambda: GSM8kDataset(GSM8kDatasetSplit.train))


if __name__ == "__main__":
    GSM8kResourcesServer.run_webserver()
