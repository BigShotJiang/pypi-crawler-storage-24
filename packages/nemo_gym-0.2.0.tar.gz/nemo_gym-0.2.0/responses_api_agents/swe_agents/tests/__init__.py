# Tests for swe agents
