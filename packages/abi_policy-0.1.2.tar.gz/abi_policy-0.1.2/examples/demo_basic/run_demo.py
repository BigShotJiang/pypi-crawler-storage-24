#!/usr/bin/env python3
"""Basic demo of abi-policy evaluation.

Runs entirely offline with no external dependencies.
"""
from __future__ import annotations

import sys
from pathlib import Path

# Add src to path for standalone execution
sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent / "src"))

from abi_policy.bundles import load_bundle
from abi_policy.decision_points import (
    evaluate_file_write,
    evaluate_model_call,
    evaluate_tool_call,
)
from abi_policy.engine import PolicyEngine

REPO_ROOT = Path(__file__).resolve().parent.parent.parent


def main() -> None:
    print("=== abi-policy Basic Demo ===\n")

    # Load default policy
    bundle = load_bundle("default", REPO_ROOT / "policies")
    engine = PolicyEngine(bundle)

    # Test various scenarios
    scenarios = [
        evaluate_tool_call("read_file", run_id="demo0001"),
        evaluate_tool_call("shell_exec", run_id="demo0001"),
        evaluate_file_write("src/main.py", run_id="demo0001"),
        evaluate_file_write("../../../etc/passwd", run_id="demo0001"),
        evaluate_file_write(".env", run_id="demo0001"),
        evaluate_model_call("claude-sonnet", run_id="demo0001"),
        evaluate_model_call("unknown-model", run_id="demo0001"),
        evaluate_model_call(
            "claude-sonnet", run_id="demo0001", token_count=999999, budget_scope="step"
        ),
    ]

    ndjson_lines = []
    for req in scenarios:
        resp = engine.evaluate(req)
        icon = {"allow": "OK", "deny": "XX", "require_approval": "??"}[resp.decision]
        print(f"  [{icon}] {req.action}:{req.resource} -> {resp.decision} ({resp.reason_code})")
        ndjson_lines.append(resp.to_ndjson_line())

    print(f"\n--- NDJSON Output ({len(ndjson_lines)} lines) ---")
    for line in ndjson_lines:
        print(line)

    print("\nDemo complete.")


if __name__ == "__main__":
    main()
