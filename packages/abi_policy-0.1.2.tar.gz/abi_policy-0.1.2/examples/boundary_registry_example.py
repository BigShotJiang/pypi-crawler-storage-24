"""Example: Using Capability Boundary Registry for task authorization.

This example demonstrates how to:
1. Load default boundary rules from YAML
2. Check authorization for different task categories
3. Use agent-specific overrides
4. Integrate boundaries with routing decisions
"""

from pathlib import Path

from abi_policy.boundary_registry import BoundaryEntry, BoundaryRegistry


def main() -> None:
    """Demonstrate boundary registry usage."""
    print("=" * 70)
    print("Capability Boundary Registry Example")
    print("=" * 70)

    # 1. Load default boundaries from YAML
    boundaries_path = Path(__file__).parent.parent / "data" / "default_boundaries.yaml"
    registry = BoundaryRegistry.from_yaml(boundaries_path)

    print(f"\nLoaded {len(registry.entries)} boundary rules")

    # 2. Display all boundary rules
    print("\n" + "=" * 70)
    print("Default Boundary Rules")
    print("=" * 70)
    print(f"\n{'Task Category':<25} {'Risk Tier':<12} {'Action':<18}")
    print("-" * 70)

    for entry in registry.entries:
        agent_info = f" (agent: {entry.agent_id})" if entry.agent_id else ""
        print(
            f"{entry.task_category:<25} {entry.risk_tier:<12} "
            f"{entry.action:<18}{agent_info}"
        )

    # 3. Check authorization for various tasks
    print("\n" + "=" * 70)
    print("Authorization Checks")
    print("=" * 70)

    test_tasks = [
        "code_generation",
        "test_generation",
        "documentation",
        "schema_change",
        "deployment",
        "database_migration",
        "security_config",
        "production_data_access",
        "unknown_task",  # Not in registry, should default to requires_hil
    ]

    print(f"\n{'Task Category':<25} {'Authorization':<18}")
    print("-" * 70)

    for task in test_tasks:
        action = registry.check(task)
        status_symbol = {
            "autonomous": "[OK] ALLOWED",
            "requires_hil": "[REVIEW] REQUIRES HIL",
            "forbidden": "[BLOCKED] FORBIDDEN",
        }.get(action, action)
        print(f"{task:<25} {status_symbol:<18}")

    # 4. Demonstrate agent-specific overrides
    print("\n" + "=" * 70)
    print("Agent-Specific Override Example")
    print("=" * 70)

    # Create a custom registry with agent-specific rules
    custom_entries = [
        # General rule: deployment requires HIL
        BoundaryEntry("deployment", None, "high", "requires_hil"),
        # Agent-specific: trusted_agent can deploy autonomously
        BoundaryEntry("deployment", "trusted_agent", "medium", "autonomous"),
        # General rule: refactoring is autonomous
        BoundaryEntry("refactoring", None, "low", "autonomous"),
        # Agent-specific: experimental_agent requires review for refactoring
        BoundaryEntry("refactoring", "experimental_agent", "medium", "requires_hil"),
    ]

    custom_registry = BoundaryRegistry(entries=custom_entries)

    print("\nDeployment authorization:")
    print(f"  trusted_agent: {custom_registry.check('deployment', 'trusted_agent')}")
    print(f"  other_agent: {custom_registry.check('deployment', 'other_agent')}")
    print(f"  no agent specified: {custom_registry.check('deployment')}")

    print("\nRefactoring authorization:")
    print(
        f"  experimental_agent: "
        f"{custom_registry.check('refactoring', 'experimental_agent')}"
    )
    print(f"  other_agent: {custom_registry.check('refactoring', 'other_agent')}")

    # 5. Integration example: pre-flight check
    print("\n" + "=" * 70)
    print("Pre-flight Authorization Check")
    print("=" * 70)

    def execute_task(task_category: str, agent_id: str = None) -> None:
        """Simulate task execution with boundary check."""
        action = registry.check(task_category, agent_id)

        print(f"\nTask: {task_category}")
        if agent_id:
            print(f"Agent: {agent_id}")

        if action == "autonomous":
            print("[OK] Proceeding with autonomous execution")
        elif action == "requires_hil":
            print("[REVIEW] Escalating to human for approval")
        else:  # forbidden
            print("[BLOCKED] Task execution blocked by policy")

    # Simulate various task execution attempts
    execute_task("code_generation")
    execute_task("deployment")
    execute_task("security_config")

    # 6. Practical workflow example
    print("\n" + "=" * 70)
    print("Practical Workflow Example")
    print("=" * 70)

    workflow_tasks = [
        ("Generate unit tests", "test_generation"),
        ("Update documentation", "documentation"),
        ("Modify database schema", "schema_change"),
        ("Deploy to production", "deployment"),
    ]

    print("\nWorkflow:")
    for description, category in workflow_tasks:
        action = registry.check(category)
        status = {
            "autonomous": "AUTO",
            "requires_hil": "REVIEW",
            "forbidden": "BLOCKED",
        }[action]
        print(f"  {description:<30} [{status}]")

    print("\n" + "=" * 70)


if __name__ == "__main__":
    main()
