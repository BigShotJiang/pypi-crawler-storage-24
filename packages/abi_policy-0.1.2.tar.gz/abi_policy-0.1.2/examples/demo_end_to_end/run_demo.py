#!/usr/bin/env python3
"""Cross-repo integration demo for abi-policy.

Simulates a mock orchestration step:
1. Creates a synthetic PlanGraph
2. Evaluates policy decisions for each plan step
3. Emits policy_decisions.ndjson (abi-observability compatible)
4. Produces eval-compatible assertions (abi-evals compatible)
5. Outputs a small evidence-pack-like folder

Runs entirely offline. Does not require other abi-* repos to be installed.
"""
from __future__ import annotations

import json
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent / "src"))

from abi_policy.bundles import load_bundle
from abi_policy.decision_points import (
    evaluate_file_write,
    evaluate_model_call,
    evaluate_tool_call,
)
from abi_policy.engine import PolicyEngine

REPO_ROOT = Path(__file__).resolve().parent.parent.parent

# Fixed timestamp for determinism
FIXED_TS = "2025-01-01T00:00:00Z"
RUN_ID = "e2e00001"


def make_synthetic_plan_graph() -> dict:
    """Create a small synthetic PlanGraph (plan-graph/1.0 compatible)."""
    return {
        "schema_version": "plan-graph/1.0",
        "run_id": RUN_ID,
        "description": "Demo plan graph for policy evaluation",
        "nodes": [
            {
                "node_id": "step-1",
                "name": "Read source code",
                "depends_on": [],
                "status": "pending",
                "agent": "builder",
                "metadata": {"node_type": "TOOL_CALL", "tool": "read_file"},
            },
            {
                "node_id": "step-2",
                "name": "Analyze with model",
                "depends_on": ["step-1"],
                "status": "pending",
                "agent": "builder",
                "metadata": {"node_type": "AGENT_TASK", "model": "claude-sonnet"},
            },
            {
                "node_id": "step-3",
                "name": "Write output",
                "depends_on": ["step-2"],
                "status": "pending",
                "agent": "builder",
                "metadata": {"node_type": "TOOL_CALL", "tool": "write_file"},
            },
            {
                "node_id": "step-4",
                "name": "Deploy (risky)",
                "depends_on": ["step-3"],
                "status": "pending",
                "agent": "builder",
                "metadata": {"node_type": "TOOL_CALL", "tool": "deploy_prod"},
            },
        ],
    }


def main() -> None:
    print("=== abi-policy Cross-Repo Integration Demo ===\n")

    # 1. Create synthetic PlanGraph
    print("--- Step 1: Create PlanGraph ---")
    plan_graph = make_synthetic_plan_graph()
    print(f"  Nodes: {len(plan_graph['nodes'])}")
    for node in plan_graph["nodes"]:
        print(f"    {node['node_id']}: {node['name']}")

    # 2. Load policy bundle and evaluate each step
    print("\n--- Step 2: Policy Evaluation ---")
    bundle = load_bundle("default", REPO_ROOT / "policies")
    engine = PolicyEngine(bundle)

    ndjson_lines = []
    eval_assertions = []

    for node in plan_graph["nodes"]:
        meta = node.get("metadata", {})
        node_type = meta.get("node_type", "AGENT_TASK")

        # Create appropriate decision request based on node type
        if node_type == "TOOL_CALL":
            tool = meta.get("tool", "unknown")
            req = evaluate_tool_call(tool, run_id=RUN_ID, timestamp=FIXED_TS)
        elif node_type == "AGENT_TASK":
            model = meta.get("model", "claude-sonnet")
            req = evaluate_model_call(model, run_id=RUN_ID, timestamp=FIXED_TS)
        else:
            req = evaluate_tool_call(node["name"], run_id=RUN_ID, timestamp=FIXED_TS)

        response = engine.evaluate(req)
        icon = {"allow": "OK", "deny": "XX", "require_approval": "??"}[response.decision]
        print(f"  [{icon}] {node['node_id']} ({req.resource}): {response.decision}")

        # Collect NDJSON line for observability
        ndjson_lines.append(response.to_ndjson_line())

        # Collect eval assertion
        eval_assertions.append({
            "case_id": f"policy-{node['node_id']}",
            "description": f"Policy decision for {node['name']}",
            "input": response.decision,
            "expected": response.decision,
            "comparison": "exact",
        })

    # 3. Write evidence-pack-like folder
    with tempfile.TemporaryDirectory() as tmp:
        pack_dir = Path(tmp) / f"evidence_pack_{RUN_ID}"
        pack_dir.mkdir(parents=True)

        print(f"\n--- Step 3: Write Evidence Pack ---")

        # Write plan_graph.json
        with open(pack_dir / "plan_graph.json", "w") as f:
            json.dump(plan_graph, f, indent=2, sort_keys=True)
            f.write("\n")
        print(f"  plan_graph.json")

        # Write policy_decisions.ndjson
        with open(pack_dir / "policy_decisions.ndjson", "w") as f:
            for line in ndjson_lines:
                f.write(line + "\n")
        print(f"  policy_decisions.ndjson ({len(ndjson_lines)} decisions)")

        # Write eval_suite.json (for abi-evals consumption)
        eval_suite = {
            "schema_version": "eval-suite/1.0",
            "suite_id": "policy-e2e-demo",
            "description": "Auto-generated eval suite from policy demo",
            "cases": eval_assertions,
        }
        with open(pack_dir / "eval_suite.json", "w") as f:
            json.dump(eval_suite, f, indent=2, sort_keys=True)
            f.write("\n")
        print(f"  eval_suite.json ({len(eval_assertions)} cases)")

        # Write events.ndjson stub (tier2-event-envelope/1.0 compatible)
        events = [
            {
                "schema_version": "tier2-event-envelope/1.0",
                "event_id": "evt-001",
                "event_type": "RUN_STARTED",
                "timestamp": FIXED_TS,
                "run_id": RUN_ID,
                "payload": {"message": "Policy demo started"},
                "metadata": {},
            },
            {
                "schema_version": "tier2-event-envelope/1.0",
                "event_id": "evt-002",
                "event_type": "RUN_COMPLETED",
                "timestamp": "2025-01-01T00:00:05Z",
                "run_id": RUN_ID,
                "payload": {"status": "success"},
                "metadata": {},
            },
        ]
        with open(pack_dir / "events.ndjson", "w") as f:
            for evt in events:
                f.write(json.dumps(evt, sort_keys=True) + "\n")
        print(f"  events.ndjson ({len(events)} events)")

        # Write manifest (tier2-pack-manifest/1.0)
        manifest = {
            "schema_version": "tier2-pack-manifest/1.0",
            "run_id": RUN_ID,
            "created_at": FIXED_TS,
            "components": {
                "plan_graph": "plan_graph.json",
                "policy_decisions": "policy_decisions.ndjson",
                "eval_suite": "eval_suite.json",
                "events": "events.ndjson",
            },
            "summary": {
                "total_files": 4,
                "total_artifacts": 0,
            },
        }
        with open(pack_dir / "manifest.json", "w") as f:
            json.dump(manifest, f, indent=2, sort_keys=True)
            f.write("\n")
        print(f"  manifest.json")

        # Print artifact listing
        print(f"\n--- Evidence Pack Contents ---")
        for item in sorted(pack_dir.iterdir()):
            size = item.stat().st_size
            print(f"  {item.name} ({size} bytes)")

    print("\nCross-repo integration demo complete.")


if __name__ == "__main__":
    main()
