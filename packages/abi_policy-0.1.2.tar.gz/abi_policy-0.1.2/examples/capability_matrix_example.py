"""Example: Using Agent Capability Matrix for routing decisions.

This example demonstrates how to:
1. Load agent profiles from YAML seed file
2. Query confidence scores for different agents and tasks
3. Get the best agent recommendation for a task
4. Integrate with the RoutingEngine for enhanced routing decisions
"""

from pathlib import Path

from abi_policy.capability_matrix import CapabilityMatrix
from abi_policy.routing import RoutingEngine


def main() -> None:
    """Demonstrate capability matrix usage."""
    print("=" * 70)
    print("Agent Capability Matrix Example")
    print("=" * 70)

    # 1. Load capability matrix from seed file
    seed_path = Path(__file__).parent.parent / "data" / "capability_matrix_seed.yaml"
    matrix = CapabilityMatrix.from_yaml(seed_path)

    print(f"\nLoaded {len(matrix.profiles)} agent profiles")
    print(f"Agents: {', '.join(matrix.profiles.keys())}")

    # 2. Query confidence scores
    print("\n" + "=" * 70)
    print("Confidence Scores")
    print("=" * 70)

    agents = ["claude_code", "codex", "local_llm"]
    tasks = ["code_generation", "code_review", "documentation", "verification"]

    print(f"\n{'Task Category':<20} {'claude_code':<15} {'codex':<15} {'local_llm':<15}")
    print("-" * 70)

    for task in tasks:
        scores = [f"{matrix.get_confidence(agent, task):.2f}" for agent in agents]
        print(f"{task:<20} {scores[0]:<15} {scores[1]:<15} {scores[2]:<15}")

    # 3. Get best agent recommendations
    print("\n" + "=" * 70)
    print("Best Agent Recommendations")
    print("=" * 70)

    for task in tasks:
        best_agent = matrix.get_best_agent(task)
        if best_agent:
            confidence = matrix.get_confidence(best_agent, task)
            print(f"{task:<20} -> {best_agent:<15} (confidence: {confidence:.2f})")
        else:
            print(f"{task:<20} -> No agent found")

    # 4. View failure patterns
    print("\n" + "=" * 70)
    print("Known Failure Patterns")
    print("=" * 70)

    for agent_id, profile in matrix.profiles.items():
        if profile.failure_patterns:
            print(f"\n{agent_id}:")
            for pattern in profile.failure_patterns:
                print(f"  - {pattern}")

    # 5. Example: Integration with RoutingEngine
    print("\n" + "=" * 70)
    print("Integration with RoutingEngine")
    print("=" * 70)

    # Sample registry and policy
    registry = {
        "providers": [
            {
                "name": "anthropic",
                "channels": [
                    {
                        "name": "api",
                        "models": [
                            {
                                "id": "claude-sonnet-4",
                                "tier": "standard",
                                "capabilities": ["code_generation", "tool_use"],
                                "ru_per_1k": {"input": 0.8, "output": 3.2},
                            }
                        ],
                    }
                ],
            }
        ]
    }

    policy = {
        "rules": [
            {
                "rule_id": "standard-code-gen",
                "priority": 20,
                "task_type": "code_generation",
                "tier": "any",
                "model_ref": "anthropic/api/claude-sonnet-4",
            }
        ]
    }

    budget_state = {"zone": "GREEN", "ru_remaining": 1000.0}

    # Create routing engine with capability matrix
    engine = RoutingEngine(
        registry=registry,
        policy=policy,
        profile=None,
        budget_state=budget_state,
        capability_matrix=matrix,
    )

    # Route a task with task_category
    task = {
        "task_type": "code_generation",
        "task_category": "code_generation",
        "estimated_input_tokens": 100,
        "estimated_output_tokens": 50,
    }

    result = engine.route(task)

    print(f"\nRouting decision for {task['task_category']}:")
    print(f"  Rule ID: {result['rule_id']}")
    print(f"  Model: {result['model']['model_id']}")
    print(f"  RU Estimate: {result['ru_estimate']}")

    if "capability_metadata" in result:
        print(f"\n  Capability Matrix Recommendation:")
        print(f"    Agent: {result['capability_metadata']['recommended_agent']}")
        print(f"    Confidence: {result['capability_metadata']['confidence']:.2f}")

    print("\n" + "=" * 70)


if __name__ == "__main__":
    main()
