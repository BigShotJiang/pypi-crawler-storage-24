#!/usr/bin/env python3
"""Preflight check — runs lint + tests + key invariants for abi-policy."""
from __future__ import annotations

import subprocess
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent

REQUIRED_FILES = [
    "README.md",
    "SECURITY.md",
    "pyproject.toml",
    "src/abi_policy/__init__.py",
    "src/abi_policy/engine.py",
    "src/abi_policy/cli.py",
    "policies/default/policy.json",
    "policies/hil_low/policy.json",
    "policies/hil_medium/policy.json",
    "policies/hil_high/policy.json",
]

REQUIRED_BUNDLES = ["default", "hil_low", "hil_medium", "hil_high"]


def check_files() -> list[str]:
    errors = []
    for f in REQUIRED_FILES:
        if not (REPO_ROOT / f).exists():
            errors.append(f"Missing required file: {f}")
    return errors


def check_bundles() -> list[str]:
    import json
    errors = []
    for name in REQUIRED_BUNDLES:
        path = REPO_ROOT / "policies" / name / "policy.json"
        if not path.exists():
            errors.append(f"Missing bundle: {name}")
            continue
        try:
            with open(path) as f:
                data = json.load(f)
            if "bundle_id" not in data or "rules" not in data:
                errors.append(f"Bundle {name} missing required fields")
        except json.JSONDecodeError as e:
            errors.append(f"Bundle {name} invalid JSON: {e}")
    return errors


def run_lint() -> int:
    print("=== Running ruff ===")
    result = subprocess.run(
        [sys.executable, "-m", "ruff", "check", "src/", "tests/"],
        cwd=REPO_ROOT,
    )
    return result.returncode


def run_tests() -> int:
    print("=== Running pytest ===")
    result = subprocess.run(
        [sys.executable, "-m", "pytest", "tests/", "-v", "--tb=short"],
        cwd=REPO_ROOT,
    )
    return result.returncode


def main() -> int:
    print("abi-policy preflight check")
    print("=" * 40)

    # Check required files
    print("\n--- File presence ---")
    file_errors = check_files()
    for e in file_errors:
        print(f"  FAIL: {e}")
    if not file_errors:
        print("  OK: All required files present")

    # Check bundles
    print("\n--- Bundle validation ---")
    bundle_errors = check_bundles()
    for e in bundle_errors:
        print(f"  FAIL: {e}")
    if not bundle_errors:
        print("  OK: All bundles valid")

    # Run lint
    print()
    lint_rc = run_lint()
    if lint_rc != 0:
        print("  FAIL: Lint errors found")

    # Run tests
    print()
    test_rc = run_tests()
    if test_rc != 0:
        print("  FAIL: Test failures")

    all_errors = file_errors + bundle_errors
    if all_errors or lint_rc != 0 or test_rc != 0:
        print("\nPREFLIGHT FAILED")
        return 1

    print("\nPREFLIGHT PASSED")
    return 0


if __name__ == "__main__":
    sys.exit(main())
