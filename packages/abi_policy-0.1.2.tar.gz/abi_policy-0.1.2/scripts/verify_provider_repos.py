#!/usr/bin/env python3
"""Verify provider_repos.json manifest.

Checks:
  1. Manifest is valid JSON and passes JSON schema validation.
  2. All consumer_repos are a subset of provider_repos.
  3. All repo names follow the abi-* lowercase convention.
  4. (Best-effort) If GITHUB_TOKEN is available, checks app installation
     against the manifest — warns on failure, does not hard-fail.

Exit code: 0 = all checks passed, 1 = one or more checks failed.
"""
from __future__ import annotations

import json
import os
import re
import sys
import urllib.request
import urllib.error
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent
MANIFEST_PATH = REPO_ROOT / "manifests" / "provider_repos.json"
SCHEMA_PATH = REPO_ROOT / "schemas" / "provider_repos.schema.json"

_REPO_NAME_RE = re.compile(r"^[a-z0-9][a-z0-9-]*[a-z0-9]$")


def _load_json(path: Path) -> dict:
    with open(path) as f:
        return json.load(f)


def check_manifest_exists() -> list[str]:
    errors = []
    if not MANIFEST_PATH.exists():
        errors.append(f"FAIL: manifest not found: {MANIFEST_PATH}")
    if not SCHEMA_PATH.exists():
        errors.append(f"FAIL: schema not found: {SCHEMA_PATH}")
    return errors


def check_schema_validation(manifest: dict) -> list[str]:
    """Validate manifest against JSON Schema using jsonschema if available,
    otherwise perform manual structural validation."""
    errors = []
    required_keys = {"schema_version", "updated_at", "org", "provider_repos", "consumer_repos"}
    missing = required_keys - manifest.keys()
    if missing:
        errors.append(f"FAIL: manifest missing required keys: {missing}")
        return errors

    if not isinstance(manifest["provider_repos"], list):
        errors.append("FAIL: provider_repos must be a list")
    if not isinstance(manifest["consumer_repos"], list):
        errors.append("FAIL: consumer_repos must be a list")
    if not isinstance(manifest["org"], str) or not manifest["org"]:
        errors.append("FAIL: org must be a non-empty string")

    # Try jsonschema if installed
    try:
        import jsonschema  # type: ignore
        schema = _load_json(SCHEMA_PATH)
        try:
            jsonschema.validate(manifest, schema)
        except jsonschema.ValidationError as exc:
            errors.append(f"FAIL: JSON Schema validation: {exc.message}")
    except ImportError:
        print("  WARN: jsonschema not installed — skipping full schema validation")

    return errors


def check_repo_names(manifest: dict) -> list[str]:
    errors = []
    for repo in manifest.get("provider_repos", []):
        if not _REPO_NAME_RE.match(repo):
            errors.append(f"FAIL: provider_repo name invalid (must be lowercase kebab): {repo!r}")
    for repo in manifest.get("consumer_repos", []):
        if not _REPO_NAME_RE.match(repo):
            errors.append(f"FAIL: consumer_repo name invalid: {repo!r}")
    return errors


def check_consumer_subset(manifest: dict) -> list[str]:
    errors = []
    provider_set = set(manifest.get("provider_repos", []))
    consumer_set = set(manifest.get("consumer_repos", []))
    not_in_providers = consumer_set - provider_set
    if not_in_providers:
        errors.append(
            f"FAIL: consumer_repos not in provider_repos: {sorted(not_in_providers)}"
        )
    return errors


def check_no_duplicates(manifest: dict) -> list[str]:
    errors = []
    for key in ("provider_repos", "consumer_repos"):
        items = manifest.get(key, [])
        if len(items) != len(set(items)):
            seen = set()
            dupes = [x for x in items if x in seen or seen.add(x)]
            errors.append(f"FAIL: duplicate entries in {key}: {dupes}")
    return errors


def check_app_installation_best_effort(manifest: dict) -> list[str]:
    """Best-effort: query GitHub API for app installations. Warns on failure."""
    warnings = []
    token = os.environ.get("GITHUB_TOKEN", "")
    if not token:
        print("  INFO: GITHUB_TOKEN not set — skipping app installation check")
        return []

    org = manifest.get("org", "")
    # List app installations for the org — requires org admin:read permission.
    # This is best-effort; will fail for standard GITHUB_TOKEN with contents:read only.
    url = f"https://api.github.com/orgs/{org}/installations"
    req = urllib.request.Request(
        url,
        headers={
            "Authorization": f"Bearer {token}",
            "Accept": "application/vnd.github+json",
            "X-GitHub-Api-Version": "2022-11-28",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read())
            installed_slugs = {
                inst["app_slug"] for inst in data.get("installations", [])
            }
            if "abilitybi-ci-access" not in installed_slugs:
                warnings.append(
                    "WARN: AbilityBI-CI-Access app not found in org installations "
                    f"(found: {sorted(installed_slugs)})"
                )
    except urllib.error.HTTPError as exc:
        if exc.code in (403, 404):
            print(f"  INFO: Org installation check skipped (HTTP {exc.code} — insufficient permissions)")
        else:
            warnings.append(f"WARN: GitHub API error checking installations: {exc}")
    except Exception as exc:
        warnings.append(f"WARN: Could not check app installation: {exc}")

    return warnings


def main() -> int:
    print("=== verify_provider_repos.py ===")

    # Step 1: File existence
    print("\n-- Check: files exist --")
    errors = check_manifest_exists()
    for e in errors:
        print(f"  {e}")
    if errors:
        print("ABORT: required files missing")
        return 1

    # Step 2: Load
    manifest = _load_json(MANIFEST_PATH)
    print(f"  PASS: manifest loaded ({len(manifest.get('provider_repos', []))} providers, "
          f"{len(manifest.get('consumer_repos', []))} consumers)")

    all_errors: list[str] = []
    all_warnings: list[str] = []

    # Step 3: Schema
    print("\n-- Check: schema validation --")
    errs = check_schema_validation(manifest)
    all_errors.extend(errs)
    if not errs:
        print("  PASS: schema valid")
    else:
        for e in errs:
            print(f"  {e}")

    # Step 4: Repo name conventions
    print("\n-- Check: repo name conventions --")
    errs = check_repo_names(manifest)
    all_errors.extend(errs)
    if not errs:
        print("  PASS: all repo names valid")
    else:
        for e in errs:
            print(f"  {e}")

    # Step 5: Consumer subset of Provider
    print("\n-- Check: consumer_repos subset of provider_repos --")
    errs = check_consumer_subset(manifest)
    all_errors.extend(errs)
    if not errs:
        print("  PASS: all consumers are in provider list")
    else:
        for e in errs:
            print(f"  {e}")

    # Step 6: No duplicates
    print("\n-- Check: no duplicate entries --")
    errs = check_no_duplicates(manifest)
    all_errors.extend(errs)
    if not errs:
        print("  PASS: no duplicates")
    else:
        for e in errs:
            print(f"  {e}")

    # Step 7: App installation (best-effort)
    print("\n-- Check: app installation (best-effort) --")
    warns = check_app_installation_best_effort(manifest)
    all_warnings.extend(warns)
    if not warns:
        print("  PASS: app installation check passed (or skipped)")
    else:
        for w in warns:
            print(f"  {w}")

    # Summary
    print()
    if all_warnings:
        print(f"Warnings ({len(all_warnings)}):")
        for w in all_warnings:
            print(f"  {w}")

    exit_code = 1 if all_errors else 0
    print(f"\nEXIT_CODE={exit_code}")
    print(f"Results: {len(all_errors)} error(s), {len(all_warnings)} warning(s)")
    return exit_code


if __name__ == "__main__":
    sys.exit(main())
