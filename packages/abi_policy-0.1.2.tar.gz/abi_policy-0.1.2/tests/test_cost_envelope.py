"""Tests for cost_envelope module."""
from __future__ import annotations

import pytest

from abi_policy.cost_envelope import (
    BudgetSnapshot,
    CostEnvelopeConfig,
    _parse_simple_yaml,
    evaluate_cost_envelope,
    load_cost_envelope,
    parse_percentage,
    validate_cost_envelope_config,
)

# ---------------------------------------------------------------------------
# TestParsePercentage
# ---------------------------------------------------------------------------


class TestParsePercentage:
    def test_parse_string_percent(self) -> None:
        assert parse_percentage("10%") == pytest.approx(0.10)

    def test_parse_string_decimal(self) -> None:
        assert parse_percentage("0.15") == pytest.approx(0.15)

    def test_parse_float(self) -> None:
        assert parse_percentage(0.10) == pytest.approx(0.10)

    def test_parse_integer_percent(self) -> None:
        assert parse_percentage(10) == pytest.approx(0.10)


# ---------------------------------------------------------------------------
# TestCostEnvelopeConfig
# ---------------------------------------------------------------------------


class TestCostEnvelopeConfig:
    def test_load_from_yaml(self, tmp_path) -> None:
        yaml_file = tmp_path / "envelope.yaml"
        yaml_file.write_text(
            "max_total_tokens_delta: 10%\n"
            "max_single_prompt_delta: 15%\n"
            "allow_risk_escalation: false\n"
            "allow_policy_escalation: false\n"
        )
        config = load_cost_envelope(yaml_file)
        assert config.max_total_tokens_delta == pytest.approx(0.10)
        assert config.max_single_prompt_delta == pytest.approx(0.15)
        assert config.allow_risk_escalation is False
        assert config.allow_policy_escalation is False

    def test_validate_valid_config(self) -> None:
        data = {
            "max_total_tokens_delta": "10%",
            "max_single_prompt_delta": "15%",
        }
        errors = validate_cost_envelope_config(data)
        assert errors == []

    def test_validate_missing_fields(self) -> None:
        data = {"allow_risk_escalation": "false"}
        errors = validate_cost_envelope_config(data)
        assert len(errors) == 2
        assert any("max_total_tokens_delta" in e for e in errors)
        assert any("max_single_prompt_delta" in e for e in errors)


# ---------------------------------------------------------------------------
# TestEvaluateCostEnvelope
# ---------------------------------------------------------------------------


@pytest.fixture
def config_10_15() -> CostEnvelopeConfig:
    return CostEnvelopeConfig(
        max_total_tokens_delta=0.10,
        max_single_prompt_delta=0.15,
    )


class TestEvaluateCostEnvelope:
    def test_pass_no_delta(self, config_10_15) -> None:
        snap = BudgetSnapshot(total_tokens=1000, prompt_tokens={"a": 500})
        result = evaluate_cost_envelope(config_10_15, snap, snap)
        assert result.status == "PASS"

    def test_pass_within_threshold(self, config_10_15) -> None:
        baseline = BudgetSnapshot(total_tokens=1000, prompt_tokens={"a": 500})
        current = BudgetSnapshot(total_tokens=1050, prompt_tokens={"a": 525})
        result = evaluate_cost_envelope(config_10_15, baseline, current)
        assert result.status == "PASS"

    def test_fail_total_exceeds_threshold(self, config_10_15) -> None:
        baseline = BudgetSnapshot(total_tokens=1000)
        current = BudgetSnapshot(total_tokens=1200)
        result = evaluate_cost_envelope(config_10_15, baseline, current)
        assert result.status == "FAIL"

    def test_fail_single_prompt_exceeds(self, config_10_15) -> None:
        baseline = BudgetSnapshot(total_tokens=1000, prompt_tokens={"a": 500})
        current = BudgetSnapshot(total_tokens=1000, prompt_tokens={"a": 700})
        result = evaluate_cost_envelope(config_10_15, baseline, current)
        assert result.status == "FAIL"

    def test_warn_near_threshold(self, config_10_15) -> None:
        # 9% delta is > 80% of 10% threshold (i.e. > 8%) -> WARN
        baseline = BudgetSnapshot(total_tokens=1000)
        current = BudgetSnapshot(total_tokens=1090)
        result = evaluate_cost_envelope(config_10_15, baseline, current)
        assert result.status == "WARN"

    def test_risk_escalation_blocked(self, config_10_15) -> None:
        baseline = BudgetSnapshot(total_tokens=1000, risk_level="low")
        current = BudgetSnapshot(total_tokens=1000, risk_level="high")
        result = evaluate_cost_envelope(config_10_15, baseline, current)
        assert result.status == "FAIL"
        assert result.risk_escalation_blocked is True

    def test_risk_escalation_allowed(self) -> None:
        config = CostEnvelopeConfig(
            max_total_tokens_delta=0.10,
            max_single_prompt_delta=0.15,
            allow_risk_escalation=True,
        )
        baseline = BudgetSnapshot(total_tokens=1000, risk_level="low")
        current = BudgetSnapshot(total_tokens=1000, risk_level="high")
        result = evaluate_cost_envelope(config, baseline, current)
        assert result.risk_escalation_blocked is False

    def test_policy_escalation_blocked(self, config_10_15) -> None:
        baseline = BudgetSnapshot(total_tokens=1000, policy_level="default")
        current = BudgetSnapshot(total_tokens=1000, policy_level="strict")
        result = evaluate_cost_envelope(config_10_15, baseline, current)
        assert result.status == "FAIL"
        assert result.policy_escalation_blocked is True

    def test_policy_escalation_allowed(self) -> None:
        config = CostEnvelopeConfig(
            max_total_tokens_delta=0.10,
            max_single_prompt_delta=0.15,
            allow_policy_escalation=True,
        )
        baseline = BudgetSnapshot(total_tokens=1000, policy_level="default")
        current = BudgetSnapshot(total_tokens=1000, policy_level="strict")
        result = evaluate_cost_envelope(config, baseline, current)
        assert result.policy_escalation_blocked is False

    def test_deterministic_json_output(self, config_10_15) -> None:
        baseline = BudgetSnapshot(total_tokens=1000)
        current = BudgetSnapshot(total_tokens=1050)
        r1 = evaluate_cost_envelope(config_10_15, baseline, current)
        r2 = evaluate_cost_envelope(config_10_15, baseline, current)
        assert r1.to_json() == r2.to_json()

    def test_to_decision_response(self, config_10_15) -> None:
        baseline = BudgetSnapshot(total_tokens=1000)
        current = BudgetSnapshot(total_tokens=1200)
        result = evaluate_cost_envelope(config_10_15, baseline, current)
        assert result.status == "FAIL"
        dr = result.to_decision_response()
        assert dr.decision == "deny"

    def test_baseline_zero_tokens(self, config_10_15) -> None:
        baseline = BudgetSnapshot(total_tokens=0)
        current = BudgetSnapshot(total_tokens=100)
        result = evaluate_cost_envelope(config_10_15, baseline, current)
        assert result.status == "FAIL"

    def test_both_zero_tokens(self, config_10_15) -> None:
        baseline = BudgetSnapshot(total_tokens=0)
        current = BudgetSnapshot(total_tokens=0)
        result = evaluate_cost_envelope(config_10_15, baseline, current)
        assert result.status == "PASS"


# ---------------------------------------------------------------------------
# TestSimpleYamlParser
# ---------------------------------------------------------------------------


class TestSimpleYamlParser:
    def test_parse_basic(self) -> None:
        text = "key1: value1\nkey2: value2\n"
        result = _parse_simple_yaml(text)
        assert result == {"key1": "value1", "key2": "value2"}

    def test_parse_comments(self) -> None:
        text = "# This is a comment\nkey: value\n# Another comment\n"
        result = _parse_simple_yaml(text)
        assert result == {"key": "value"}
