"""Tests for the Capability Boundary Registry."""

import tempfile
from pathlib import Path

import pytest

from abi_policy.boundary_registry import BoundaryEntry, BoundaryRegistry


class TestBoundaryEntry:
    """Tests for BoundaryEntry dataclass."""

    def test_boundary_entry_creation(self):
        """Test creating a boundary entry with all fields."""
        entry = BoundaryEntry(
            task_category="code_generation",
            agent_id="claude_code",
            risk_tier="low",
            action="autonomous",
            conditions="For non-critical paths"
        )

        assert entry.task_category == "code_generation"
        assert entry.agent_id == "claude_code"
        assert entry.risk_tier == "low"
        assert entry.action == "autonomous"
        assert entry.conditions == "For non-critical paths"

    def test_boundary_entry_none_agent(self):
        """Test creating a boundary entry with None agent_id (applies to all)."""
        entry = BoundaryEntry(
            task_category="deployment",
            agent_id=None,
            risk_tier="high",
            action="requires_hil"
        )

        assert entry.agent_id is None
        assert entry.conditions is None

    def test_boundary_entry_forbidden(self):
        """Test creating a forbidden boundary entry."""
        entry = BoundaryEntry(
            task_category="security_config",
            agent_id=None,
            risk_tier="critical",
            action="forbidden"
        )

        assert entry.action == "forbidden"


class TestBoundaryRegistry:
    """Tests for BoundaryRegistry class."""

    def test_empty_registry(self):
        """Test creating an empty registry."""
        registry = BoundaryRegistry()
        assert registry.entries == []

    def test_registry_with_entries(self):
        """Test creating a registry with initial entries."""
        entries = [
            BoundaryEntry("code_generation", None, "low", "autonomous"),
            BoundaryEntry("deployment", None, "high", "requires_hil")
        ]
        registry = BoundaryRegistry(entries=entries)
        assert len(registry.entries) == 2

    def test_check_autonomous_task(self):
        """Test that autonomous tasks pass through."""
        entries = [
            BoundaryEntry("code_generation", None, "low", "autonomous"),
            BoundaryEntry("test_generation", None, "low", "autonomous")
        ]
        registry = BoundaryRegistry(entries=entries)

        assert registry.check("code_generation") == "autonomous"
        assert registry.check("test_generation") == "autonomous"

    def test_check_forbidden_task(self):
        """Test that forbidden tasks are blocked."""
        entries = [
            BoundaryEntry("security_config", None, "critical", "forbidden"),
            BoundaryEntry("production_data_access", None, "critical", "forbidden")
        ]
        registry = BoundaryRegistry(entries=entries)

        assert registry.check("security_config") == "forbidden"
        assert registry.check("production_data_access") == "forbidden"

    def test_check_requires_hil_task(self):
        """Test that requires_hil tasks flag for review."""
        entries = [
            BoundaryEntry("deployment", None, "high", "requires_hil"),
            BoundaryEntry("schema_change", None, "high", "requires_hil")
        ]
        registry = BoundaryRegistry(entries=entries)

        assert registry.check("deployment") == "requires_hil"
        assert registry.check("schema_change") == "requires_hil"

    def test_agent_specific_override(self):
        """Test that agent-specific rules override general rules."""
        entries = [
            # General rule: deployment requires HIL
            BoundaryEntry("deployment", None, "high", "requires_hil"),
            # Agent-specific rule: claude_code can deploy autonomously
            BoundaryEntry("deployment", "claude_code", "medium", "autonomous")
        ]
        registry = BoundaryRegistry(entries=entries)

        # Agent-specific rule should take priority
        assert registry.check("deployment", agent_id="claude_code") == "autonomous"

        # Other agents should use general rule
        assert registry.check("deployment", agent_id="codex") == "requires_hil"
        assert registry.check("deployment") == "requires_hil"

    def test_default_fallback(self):
        """Test that unknown tasks default to requires_hil."""
        entries = [
            BoundaryEntry("code_generation", None, "low", "autonomous")
        ]
        registry = BoundaryRegistry(entries=entries)

        # Unknown task should default to requires_hil
        assert registry.check("unknown_task") == "requires_hil"
        assert registry.check("another_unknown", agent_id="claude_code") == "requires_hil"

    def test_matching_priority(self):
        """Test the matching priority: agent-specific > general > default."""
        entries = [
            # General rule for code_generation
            BoundaryEntry("code_generation", None, "low", "autonomous"),
            # Agent-specific rule
            BoundaryEntry("code_generation", "local_llm", "medium", "requires_hil")
        ]
        registry = BoundaryRegistry(entries=entries)

        # Agent-specific match (highest priority)
        assert registry.check("code_generation", agent_id="local_llm") == "requires_hil"

        # General match (medium priority)
        assert registry.check("code_generation", agent_id="claude_code") == "autonomous"
        assert registry.check("code_generation") == "autonomous"

        # Default fallback (lowest priority)
        assert registry.check("unknown_task") == "requires_hil"


class TestYAMLLoading:
    """Tests for loading boundaries from YAML files."""

    def test_load_from_yaml(self):
        """Test loading boundary registry from YAML."""
        yaml_content = """
boundaries:
  - task_category: code_generation
    risk_tier: low
    action: autonomous

  - task_category: deployment
    risk_tier: high
    action: requires_hil

  - task_category: security_config
    risk_tier: critical
    action: forbidden
"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
            f.write(yaml_content)
            temp_path = f.name

        try:
            registry = BoundaryRegistry.from_yaml(temp_path)

            assert len(registry.entries) == 3
            assert registry.check("code_generation") == "autonomous"
            assert registry.check("deployment") == "requires_hil"
            assert registry.check("security_config") == "forbidden"
        finally:
            Path(temp_path).unlink()

    def test_load_with_agent_specific_rules(self):
        """Test loading YAML with agent-specific rules."""
        yaml_content = """
boundaries:
  - task_category: deployment
    risk_tier: high
    action: requires_hil

  - task_category: deployment
    agent_id: claude_code
    risk_tier: medium
    action: autonomous
    conditions: Verified deployment pipeline
"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
            f.write(yaml_content)
            temp_path = f.name

        try:
            registry = BoundaryRegistry.from_yaml(temp_path)

            assert len(registry.entries) == 2
            assert registry.check("deployment", agent_id="claude_code") == "autonomous"
            assert registry.check("deployment", agent_id="codex") == "requires_hil"
        finally:
            Path(temp_path).unlink()

    def test_load_with_conditions(self):
        """Test loading YAML with conditions field."""
        yaml_content = """
boundaries:
  - task_category: schema_change
    risk_tier: high
    action: requires_hil
    conditions: Database schema changes require review for compatibility
"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
            f.write(yaml_content)
            temp_path = f.name

        try:
            registry = BoundaryRegistry.from_yaml(temp_path)

            assert len(registry.entries) == 1
            entry = registry.entries[0]
            assert entry.conditions == "Database schema changes require review for compatibility"
        finally:
            Path(temp_path).unlink()

    def test_load_invalid_yaml_missing_boundaries(self):
        """Test that loading invalid YAML (missing boundaries key) raises ValueError."""
        yaml_content = """
rules:
  - task_category: code_generation
    action: autonomous
"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
            f.write(yaml_content)
            temp_path = f.name

        try:
            with pytest.raises(ValueError, match="must contain 'boundaries' key"):
                BoundaryRegistry.from_yaml(temp_path)
        finally:
            Path(temp_path).unlink()

    def test_load_invalid_yaml_missing_required_fields(self):
        """Test that loading YAML with missing required fields raises ValueError."""
        yaml_content = """
boundaries:
  - task_category: code_generation
    # Missing action field
    risk_tier: low
"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
            f.write(yaml_content)
            temp_path = f.name

        try:
            with pytest.raises(ValueError, match="missing required fields"):
                BoundaryRegistry.from_yaml(temp_path)
        finally:
            Path(temp_path).unlink()

    def test_load_invalid_action_value(self):
        """Test that loading YAML with invalid action value raises ValueError."""
        yaml_content = """
boundaries:
  - task_category: code_generation
    action: maybe_allow
    risk_tier: low
"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
            f.write(yaml_content)
            temp_path = f.name

        try:
            with pytest.raises(ValueError, match="Invalid action"):
                BoundaryRegistry.from_yaml(temp_path)
        finally:
            Path(temp_path).unlink()

    def test_load_nonexistent_file(self):
        """Test that loading from non-existent file raises FileNotFoundError."""
        with pytest.raises(FileNotFoundError):
            BoundaryRegistry.from_yaml("/nonexistent/path/boundaries.yaml")

    def test_load_without_pyyaml(self, monkeypatch):
        """Test that loading without PyYAML raises ImportError."""
        import builtins
        original_import = builtins.__import__

        def mock_import(name, *args, **kwargs):
            if name == "yaml":
                raise ImportError("No module named 'yaml'")
            return original_import(name, *args, **kwargs)

        monkeypatch.setattr(builtins, "__import__", mock_import)

        with pytest.raises(ImportError, match="PyYAML is required"):
            BoundaryRegistry.from_yaml("dummy.yaml")


class TestSchemaValidation:
    """Tests for JSON schema validation."""

    def test_load_with_schema_validation(self):
        """Test loading YAML with schema validation."""
        pytest.importorskip("jsonschema")

        yaml_content = """
boundaries:
  - task_category: code_generation
    risk_tier: low
    action: autonomous
"""
        schema_content = """{
  "$schema": "http://json-schema.org/draft-07/schema#",
  "type": "object",
  "required": ["boundaries"],
  "properties": {
    "boundaries": {
      "type": "array",
      "items": {
        "type": "object",
        "required": ["task_category", "action"],
        "properties": {
          "task_category": {"type": "string"},
          "agent_id": {"type": ["string", "null"]},
          "risk_tier": {"type": "string"},
          "action": {"type": "string", "enum": ["autonomous", "requires_hil", "forbidden"]},
          "conditions": {"type": ["string", "null"]}
        }
      }
    }
  }
}"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as yf:
            yf.write(yaml_content)
            yaml_path = yf.name

        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as sf:
            sf.write(schema_content)
            schema_path = sf.name

        try:
            registry = BoundaryRegistry.from_yaml_with_schema(yaml_path, schema_path)
            assert len(registry.entries) == 1
            assert registry.check("code_generation") == "autonomous"
        finally:
            Path(yaml_path).unlink()
            Path(schema_path).unlink()

    def test_schema_validation_failure(self):
        """Test that schema validation catches invalid data."""
        pytest.importorskip("jsonschema")

        # Invalid: action is not one of the allowed values
        yaml_content = """
boundaries:
  - task_category: code_generation
    action: invalid_action
"""
        schema_content = """{
  "$schema": "http://json-schema.org/draft-07/schema#",
  "type": "object",
  "required": ["boundaries"],
  "properties": {
    "boundaries": {
      "type": "array",
      "items": {
        "type": "object",
        "required": ["task_category", "action"],
        "properties": {
          "task_category": {"type": "string"},
          "action": {"type": "string", "enum": ["autonomous", "requires_hil", "forbidden"]}
        }
      }
    }
  }
}"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as yf:
            yf.write(yaml_content)
            yaml_path = yf.name

        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as sf:
            sf.write(schema_content)
            schema_path = sf.name

        try:
            with pytest.raises(Exception):  # jsonschema.ValidationError
                BoundaryRegistry.from_yaml_with_schema(yaml_path, schema_path)
        finally:
            Path(yaml_path).unlink()
            Path(schema_path).unlink()


class TestDefaultBoundaries:
    """Tests using the default boundaries file."""

    def test_default_boundaries_exist(self):
        """Test that the default boundaries file exists and can be loaded."""
        # This assumes the test is run from the project root
        default_path = Path("data/default_boundaries.yaml")

        if default_path.exists():
            registry = BoundaryRegistry.from_yaml(default_path)

            # Check that expected defaults are present
            assert registry.check("code_generation") == "autonomous"
            assert registry.check("test_generation") == "autonomous"
            assert registry.check("documentation") == "autonomous"
            assert registry.check("schema_change") == "requires_hil"
            assert registry.check("deployment") == "requires_hil"
            assert registry.check("database_migration") == "requires_hil"
            assert registry.check("security_config") == "forbidden"
            assert registry.check("production_data_access") == "forbidden"
        else:
            pytest.skip("Default boundaries file not found (test may be running from wrong directory)")
