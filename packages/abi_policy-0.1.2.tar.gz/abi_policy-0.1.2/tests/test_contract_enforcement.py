"""Phase 3 — Contract enforcement tightening for abi-policy.

Validates that abi-policy NDJSON output conforms to abi-core schemas (read-only).
"""

from __future__ import annotations

import json

from abi_policy.engine import PolicyEngine
from abi_policy.models import DecisionRequest


class TestTier2PolicyDecisionSchema:
    """Policy decision NDJSON validates against tier2-policy-decision schema."""

    def _make_record(self, default_bundle, action="tool_call", resource="read_file"):
        engine = PolicyEngine(default_bundle)
        req = DecisionRequest(
            action=action,
            resource=resource,
            run_id="ct000001",
            timestamp="2025-06-15T12:00:00Z",
        )
        resp = engine.evaluate(req)
        return json.loads(resp.to_ndjson_line())

    def test_allow_record_has_valid_structure(self, default_bundle):
        record = self._make_record(default_bundle)
        assert record["schema_version"] == "tier2-policy-decision/1.0"
        assert record["decision"] in ("allow", "deny", "escalate", "warn")
        assert isinstance(record["run_id"], str)
        assert isinstance(record["policy_id"], str)
        assert isinstance(record["decided_at"], str)
        assert isinstance(record["reason"], str)
        assert isinstance(record["context"], dict)

    def test_deny_record_has_valid_structure(self, default_bundle):
        record = self._make_record(default_bundle, resource="shell_exec")
        assert record["decision"] in ("allow", "deny", "escalate", "warn")
        assert isinstance(record["context"]["reason_code"], str)

    def test_malformed_decision_missing_run_id(self, default_bundle):
        """Decisions without run_id still produce valid NDJSON with default."""
        engine = PolicyEngine(default_bundle)
        req = DecisionRequest(
            action="tool_call",
            resource="read_file",
            timestamp="2025-06-15T12:00:00Z",
        )
        resp = engine.evaluate(req)
        record = json.loads(resp.to_ndjson_line())
        assert record["run_id"] == "00000000"  # Default fallback

    def test_context_contains_action_and_resource(self, default_bundle):
        record = self._make_record(default_bundle)
        assert "action" in record["context"]
        assert "resource" in record["context"]
