"""Phase 2 — Evidence pack deepening for abi-policy.

Verifies that policy decisions are logged with:
- rule ID (policy_id)
- input hash (via request determinism)
- output decision
- timestamp (deterministic when supplied)
"""

from __future__ import annotations

import hashlib
import json

from abi_policy.engine import PolicyEngine
from abi_policy.models import DecisionRequest


def _sha256(data: str) -> str:
    return hashlib.sha256(data.encode()).hexdigest()


class TestDecisionRecordCompleteness:
    """Each decision record contains all required traceability fields."""

    def test_ndjson_contains_required_fields(self, default_bundle):
        engine = PolicyEngine(default_bundle)
        req = DecisionRequest(
            action="tool_call",
            resource="read_file",
            run_id="ev000001",
            timestamp="2025-06-15T12:00:00Z",
        )
        resp = engine.evaluate(req)
        line = resp.to_ndjson_line()
        record = json.loads(line)

        assert "schema_version" in record
        assert record["schema_version"] == "tier2-policy-decision/1.0"
        assert "run_id" in record
        assert record["run_id"] == "ev000001"
        assert "policy_id" in record
        assert "decision" in record
        assert "decided_at" in record
        assert "reason" in record
        assert "context" in record
        assert "action" in record["context"]
        assert "resource" in record["context"]
        assert "reason_code" in record["context"]

    def test_deny_record_has_correct_fields(self, default_bundle):
        engine = PolicyEngine(default_bundle)
        req = DecisionRequest(
            action="file_write",
            resource="../../../etc/passwd",
            run_id="ev000002",
            timestamp="2025-06-15T12:00:00Z",
        )
        resp = engine.evaluate(req)
        record = json.loads(resp.to_ndjson_line())
        assert record["decision"] == "deny"
        assert record["context"]["reason_code"] == "PATH_TRAVERSAL"

    def test_input_hash_deterministic(self, default_bundle):
        """Hashing the serialized request yields the same digest."""
        req = DecisionRequest(
            action="model_call",
            resource="claude-sonnet",
            run_id="ev000003",
            timestamp="2025-06-15T12:00:00Z",
        )
        h1 = _sha256(json.dumps(req.to_dict(), sort_keys=True))
        h2 = _sha256(json.dumps(req.to_dict(), sort_keys=True))
        assert h1 == h2

    def test_all_hil_profiles_emit_complete_records(self, bundles_dir):
        """Every HIL profile produces complete NDJSON records."""
        req = DecisionRequest(
            action="tool_call",
            resource="read_file",
            run_id="ev000004",
            timestamp="2025-06-15T12:00:00Z",
        )
        for name in ["default", "hil_low", "hil_medium", "hil_high"]:
            bundle = json.loads((bundles_dir / name / "policy.json").read_text())
            engine = PolicyEngine(bundle)
            resp = engine.evaluate(req)
            record = json.loads(resp.to_ndjson_line())
            assert "schema_version" in record, f"{name}: missing schema_version"
            assert "decision" in record, f"{name}: missing decision"
            assert "policy_id" in record, f"{name}: missing policy_id"
