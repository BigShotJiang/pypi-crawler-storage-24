"""Tests for policy bundle loading and validation."""

import pytest

from abi_policy.bundles import list_bundles, load_bundle, validate_bundle


class TestBundles:
    def test_list_bundles(self, bundles_dir):
        names = list_bundles(bundles_dir)
        assert "default" in names
        assert "hil_low" in names
        assert "hil_medium" in names
        assert "hil_high" in names

    def test_load_default_bundle(self, bundles_dir):
        bundle = load_bundle("default", bundles_dir)
        assert bundle["bundle_id"] == "default"
        assert "rules" in bundle

    def test_load_missing_bundle(self, bundles_dir):
        with pytest.raises(FileNotFoundError):
            load_bundle("nonexistent", bundles_dir)

    def test_validate_all_bundles(self, bundles_dir):
        for name in list_bundles(bundles_dir):
            bundle = load_bundle(name, bundles_dir)
            errors = validate_bundle(bundle)
            assert errors == [], f"Bundle '{name}' has errors: {errors}"

    def test_validate_invalid_bundle(self):
        errors = validate_bundle({"no_bundle_id": True})
        assert len(errors) > 0
        assert any("bundle_id" in e for e in errors)

    def test_validate_missing_rules(self):
        errors = validate_bundle({"bundle_id": "test", "version": "1.0"})
        assert any("rules" in e for e in errors)
