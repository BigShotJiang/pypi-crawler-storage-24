"""Tests for RoutingEngine integration with CapabilityMatrix."""

from __future__ import annotations

from abi_policy.capability_matrix import AgentProfile, CapabilityMatrix
from abi_policy.routing import RoutingEngine

# ======================================================================
# Test fixtures
# ======================================================================

EXAMPLE_REGISTRY = {
    "providers": [
        {
            "name": "anthropic",
            "channels": [
                {
                    "name": "api",
                    "models": [
                        {
                            "id": "claude-sonnet-4",
                            "tier": "standard",
                            "capabilities": ["code_generation", "tool_use"],
                            "ru_per_1k": {"input": 0.8, "output": 3.2},
                        },
                    ],
                },
            ],
        },
    ],
}

EXAMPLE_POLICY = {
    "rules": [
        {
            "rule_id": "standard-code-gen",
            "priority": 20,
            "task_type": "code_generation",
            "tier": "any",
            "model_ref": "anthropic/api/claude-sonnet-4",
        },
    ],
}

BUDGET_STATE = {
    "zone": "GREEN",
    "ru_remaining": 1000.0,
}


# ======================================================================
# RoutingEngine with CapabilityMatrix tests
# ======================================================================


class TestRoutingEngineWithCapabilityMatrix:
    """Test RoutingEngine with CapabilityMatrix integration."""

    def test_routing_without_capability_matrix(self) -> None:
        """Test routing without capability matrix (baseline)."""
        engine = RoutingEngine(
            registry=EXAMPLE_REGISTRY,
            policy=EXAMPLE_POLICY,
            profile=None,
            budget_state=BUDGET_STATE,
        )

        task = {
            "task_type": "code_generation",
            "estimated_input_tokens": 100,
            "estimated_output_tokens": 50,
        }

        result = engine.route(task)

        assert result["no_route"] is False
        assert result["rule_id"] == "standard-code-gen"
        assert "capability_metadata" not in result

    def test_routing_with_capability_matrix_no_task_category(self) -> None:
        """Test routing with capability matrix but no task_category in task."""
        profile = AgentProfile(
            agent_id="claude_code",
            agent_version="claude-sonnet-4",
            confidence_by_task={"code_generation": 0.90},
        )
        matrix = CapabilityMatrix(profiles={"claude_code": profile})

        engine = RoutingEngine(
            registry=EXAMPLE_REGISTRY,
            policy=EXAMPLE_POLICY,
            profile=None,
            budget_state=BUDGET_STATE,
            capability_matrix=matrix,
        )

        task = {
            "task_type": "code_generation",
            "estimated_input_tokens": 100,
            "estimated_output_tokens": 50,
        }

        result = engine.route(task)

        assert result["no_route"] is False
        assert result["rule_id"] == "standard-code-gen"
        # No task_category, so no capability_metadata should be added
        assert "capability_metadata" not in result

    def test_routing_with_capability_matrix_with_task_category(self) -> None:
        """Test routing with capability matrix and task_category."""
        profile = AgentProfile(
            agent_id="claude_code",
            agent_version="claude-sonnet-4",
            confidence_by_task={"code_generation": 0.90},
        )
        matrix = CapabilityMatrix(profiles={"claude_code": profile})

        engine = RoutingEngine(
            registry=EXAMPLE_REGISTRY,
            policy=EXAMPLE_POLICY,
            profile=None,
            budget_state=BUDGET_STATE,
            capability_matrix=matrix,
        )

        task = {
            "task_type": "code_generation",
            "task_category": "code_generation",
            "estimated_input_tokens": 100,
            "estimated_output_tokens": 50,
        }

        result = engine.route(task)

        assert result["no_route"] is False
        assert result["rule_id"] == "standard-code-gen"

        # Capability metadata should be present
        assert "capability_metadata" in result
        assert result["capability_metadata"]["recommended_agent"] == "claude_code"
        assert result["capability_metadata"]["confidence"] == 0.90

    def test_routing_with_multiple_agents_selects_best(self) -> None:
        """Test that capability matrix recommends agent with highest confidence."""
        profile1 = AgentProfile(
            agent_id="claude_code",
            agent_version="claude-sonnet-4",
            confidence_by_task={"code_generation": 0.90, "documentation": 0.95},
        )

        profile2 = AgentProfile(
            agent_id="codex",
            agent_version="gpt-5.3-codex",
            confidence_by_task={"code_generation": 0.80, "code_review": 0.95},
        )

        matrix = CapabilityMatrix(
            profiles={"claude_code": profile1, "codex": profile2}
        )

        engine = RoutingEngine(
            registry=EXAMPLE_REGISTRY,
            policy=EXAMPLE_POLICY,
            profile=None,
            budget_state=BUDGET_STATE,
            capability_matrix=matrix,
        )

        # Test code_generation — claude_code should be recommended
        task_codegen = {
            "task_type": "code_generation",
            "task_category": "code_generation",
            "estimated_input_tokens": 100,
            "estimated_output_tokens": 50,
        }

        result_codegen = engine.route(task_codegen)
        assert result_codegen["capability_metadata"]["recommended_agent"] == "claude_code"
        assert result_codegen["capability_metadata"]["confidence"] == 0.90

        # Test code_review — codex should be recommended
        task_review = {
            "task_type": "code_generation",
            "task_category": "code_review",
            "estimated_input_tokens": 100,
            "estimated_output_tokens": 50,
        }

        result_review = engine.route(task_review)
        assert result_review["capability_metadata"]["recommended_agent"] == "codex"
        assert result_review["capability_metadata"]["confidence"] == 0.95

    def test_routing_with_unknown_task_category(self) -> None:
        """Test routing when task_category has no matching agent."""
        profile = AgentProfile(
            agent_id="claude_code",
            agent_version="claude-sonnet-4",
            confidence_by_task={"code_generation": 0.90},
        )
        matrix = CapabilityMatrix(profiles={"claude_code": profile})

        engine = RoutingEngine(
            registry=EXAMPLE_REGISTRY,
            policy=EXAMPLE_POLICY,
            profile=None,
            budget_state=BUDGET_STATE,
            capability_matrix=matrix,
        )

        task = {
            "task_type": "code_generation",
            "task_category": "unknown_category",
            "estimated_input_tokens": 100,
            "estimated_output_tokens": 50,
        }

        result = engine.route(task)

        assert result["no_route"] is False
        assert result["rule_id"] == "standard-code-gen"
        # No agent has confidence for unknown_category, so no metadata
        assert "capability_metadata" not in result

    def test_routing_no_route_scenario_includes_capability_metadata(self) -> None:
        """Test that capability metadata is included even in no_route scenarios."""
        profile = AgentProfile(
            agent_id="claude_code",
            agent_version="claude-sonnet-4",
            confidence_by_task={"code_generation": 0.90},
        )
        matrix = CapabilityMatrix(profiles={"claude_code": profile})

        # Policy with no matching rules
        empty_policy = {"rules": []}

        engine = RoutingEngine(
            registry=EXAMPLE_REGISTRY,
            policy=empty_policy,
            profile=None,
            budget_state=BUDGET_STATE,
            capability_matrix=matrix,
        )

        task = {
            "task_type": "code_generation",
            "task_category": "code_generation",
            "estimated_input_tokens": 100,
            "estimated_output_tokens": 50,
        }

        result = engine.route(task)

        assert result["no_route"] is True
        # Even in no_route scenario, capability metadata should be present
        assert "capability_metadata" in result
        assert result["capability_metadata"]["recommended_agent"] == "claude_code"
        assert result["capability_metadata"]["confidence"] == 0.90

    def test_routing_determinism_with_capability_matrix(self) -> None:
        """Test that routing is deterministic even with capability matrix."""
        profile = AgentProfile(
            agent_id="claude_code",
            agent_version="claude-sonnet-4",
            confidence_by_task={"code_generation": 0.90},
        )
        matrix = CapabilityMatrix(profiles={"claude_code": profile})

        engine = RoutingEngine(
            registry=EXAMPLE_REGISTRY,
            policy=EXAMPLE_POLICY,
            profile=None,
            budget_state=BUDGET_STATE,
            capability_matrix=matrix,
        )

        task = {
            "task_type": "code_generation",
            "task_category": "code_generation",
            "estimated_input_tokens": 100,
            "estimated_output_tokens": 50,
        }

        # Route the same task multiple times
        result1 = engine.route(task)
        result2 = engine.route(task)
        result3 = engine.route(task)

        # All results should have the same record_hash (determinism)
        assert result1["record_hash"] == result2["record_hash"]
        assert result2["record_hash"] == result3["record_hash"]

        # Capability metadata should be consistent
        assert result1["capability_metadata"] == result2["capability_metadata"]
        assert result2["capability_metadata"] == result3["capability_metadata"]
