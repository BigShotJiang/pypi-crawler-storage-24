"""Tests for the deterministic policy engine."""
import json

from abi_policy.engine import PolicyEngine
from abi_policy.models import DecisionRequest


class TestPolicyEngine:
    """Core engine evaluation tests."""

    def test_allow_safe_tool(self, default_bundle):
        engine = PolicyEngine(default_bundle)
        req = DecisionRequest(action="tool_call", resource="read_file")
        resp = engine.evaluate(req)
        assert resp.decision == "allow"
        assert resp.reason_code == "TOOL_ALLOWED"

    def test_deny_dangerous_tool(self, default_bundle):
        engine = PolicyEngine(default_bundle)
        req = DecisionRequest(action="tool_call", resource="shell_exec")
        resp = engine.evaluate(req)
        assert resp.decision == "deny"
        assert resp.reason_code in ("TOOL_DENIED", "ESCALATION_MATCH")

    def test_deny_path_traversal(self, default_bundle):
        engine = PolicyEngine(default_bundle)
        req = DecisionRequest(action="file_write", resource="../../../etc/passwd")
        resp = engine.evaluate(req)
        assert resp.decision == "deny"
        assert resp.reason_code == "PATH_TRAVERSAL"

    def test_deny_absolute_path(self, default_bundle):
        engine = PolicyEngine(default_bundle)
        req = DecisionRequest(action="file_write", resource="/etc/passwd")
        resp = engine.evaluate(req)
        assert resp.decision == "deny"
        assert resp.reason_code == "ABSOLUTE_PATH"

    def test_deny_env_file(self, default_bundle):
        engine = PolicyEngine(default_bundle)
        req = DecisionRequest(action="file_write", resource="config/.env")
        resp = engine.evaluate(req)
        assert resp.decision == "deny"

    def test_allow_safe_path(self, default_bundle):
        engine = PolicyEngine(default_bundle)
        req = DecisionRequest(action="file_write", resource="src/main.py")
        resp = engine.evaluate(req)
        assert resp.decision == "allow"

    def test_allow_known_model(self, default_bundle):
        engine = PolicyEngine(default_bundle)
        req = DecisionRequest(action="model_call", resource="claude-sonnet")
        resp = engine.evaluate(req)
        assert resp.decision == "allow"

    def test_deny_unknown_model(self, default_bundle):
        engine = PolicyEngine(default_bundle)
        req = DecisionRequest(action="model_call", resource="unknown-model-xyz")
        resp = engine.evaluate(req)
        assert resp.decision == "deny"
        assert resp.reason_code == "MODEL_NOT_ALLOWED"

    def test_override_requires_approval(self, default_bundle):
        engine = PolicyEngine(default_bundle)
        req = DecisionRequest(action="override", resource="any_policy")
        resp = engine.evaluate(req)
        assert resp.decision == "require_approval"

    def test_budget_exceeded_per_step(self, default_bundle):
        engine = PolicyEngine(default_bundle)
        req = DecisionRequest(
            action="model_call",
            resource="claude-sonnet",
            context={"token_count": 999999, "budget_scope": "step"},
        )
        resp = engine.evaluate(req)
        assert resp.decision == "deny"
        assert resp.reason_code == "BUDGET_EXCEEDED"

    def test_budget_within_limit(self, default_bundle):
        engine = PolicyEngine(default_bundle)
        req = DecisionRequest(
            action="model_call",
            resource="claude-sonnet",
            context={"token_count": 1000, "budget_scope": "step"},
        )
        resp = engine.evaluate(req)
        assert resp.decision == "allow"

    def test_deterministic_output_for_fixed_input(self, default_bundle):
        """Verify same input always produces same decision/reason (timestamps may vary)."""
        engine = PolicyEngine(default_bundle)
        req = DecisionRequest(
            action="tool_call",
            resource="read_file",
            run_id="abcd1234",
            timestamp="2025-01-01T00:00:00Z",
        )
        results = [engine.evaluate(req) for _ in range(10)]
        # Decision logic fields must be identical across all evaluations
        for r in results[1:]:
            assert r.decision == results[0].decision
            assert r.reason_code == results[0].reason_code
            assert r.explanation == results[0].explanation
            assert r.policy_id == results[0].policy_id

    def test_ndjson_output_stable(self, default_bundle):
        """Verify NDJSON serialization is deterministic."""
        engine = PolicyEngine(default_bundle)
        req = DecisionRequest(
            action="tool_call",
            resource="read_file",
            run_id="abcd1234",
            timestamp="2025-01-01T00:00:00Z",
        )
        resp = engine.evaluate(req)
        lines = [resp.to_ndjson_line() for _ in range(10)]
        assert all(line == lines[0] for line in lines)
        # Verify it's valid JSON
        parsed = json.loads(lines[0])
        assert parsed["decision"] == "allow"


class TestHILProfileDifferences:
    """Verify HIL profiles differ in expected ways."""

    def test_hil_low_allows_shell_exec(self, bundles_dir):
        with open(bundles_dir / "hil_low" / "policy.json") as f:
            bundle = json.load(f)
        engine = PolicyEngine(bundle)
        req = DecisionRequest(action="tool_call", resource="shell_exec")
        resp = engine.evaluate(req)
        # hil_low allows shell_exec (it's not in deny list)
        assert resp.decision == "allow"

    def test_hil_medium_escalates_shell_exec(self, bundles_dir):
        with open(bundles_dir / "hil_medium" / "policy.json") as f:
            bundle = json.load(f)
        engine = PolicyEngine(bundle)
        req = DecisionRequest(action="tool_call", resource="shell_exec")
        resp = engine.evaluate(req)
        assert resp.decision == "require_approval"

    def test_hil_high_denies_shell_exec(self, bundles_dir):
        with open(bundles_dir / "hil_high" / "policy.json") as f:
            bundle = json.load(f)
        engine = PolicyEngine(bundle)
        req = DecisionRequest(action="tool_call", resource="shell_exec")
        resp = engine.evaluate(req)
        assert resp.decision in ("deny", "require_approval")

    def test_hil_profiles_budget_ordering(self, bundles_dir):
        """Higher HIL profiles have lower budget limits."""
        budgets = {}
        for name in ["hil_low", "hil_medium", "hil_high"]:
            with open(bundles_dir / name / "policy.json") as f:
                b = json.load(f)
            budgets[name] = b["rules"]["budget"]["max_tokens_per_run"]

        assert budgets["hil_low"] > budgets["hil_medium"] > budgets["hil_high"]

    def test_hil_high_override_denied(self, bundles_dir):
        with open(bundles_dir / "hil_high" / "policy.json") as f:
            bundle = json.load(f)
        engine = PolicyEngine(bundle)
        req = DecisionRequest(action="override", resource="any_policy")
        resp = engine.evaluate(req)
        assert resp.decision == "deny"
