"""Shared fixtures for abi-policy tests."""
import json
from pathlib import Path

import pytest


@pytest.fixture
def bundles_dir(tmp_path: Path) -> Path:
    """Create a temporary bundles directory with all standard bundles."""
    policies_src = Path(__file__).resolve().parent.parent / "policies"
    bundles = tmp_path / "policies"
    bundles.mkdir()

    for bundle_dir in policies_src.iterdir():
        if bundle_dir.is_dir() and (bundle_dir / "policy.json").exists():
            dest = bundles / bundle_dir.name
            dest.mkdir()
            with open(bundle_dir / "policy.json") as f:
                data = json.load(f)
            with open(dest / "policy.json", "w") as f:
                json.dump(data, f)

    return bundles


@pytest.fixture
def default_bundle(bundles_dir: Path) -> dict:
    with open(bundles_dir / "default" / "policy.json") as f:
        return json.load(f)
