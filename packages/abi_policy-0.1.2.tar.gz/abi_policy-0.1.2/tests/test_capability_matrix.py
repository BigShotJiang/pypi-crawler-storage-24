"""Comprehensive tests for Agent Capability Matrix functionality."""

from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path

import pytest

from abi_policy.capability_matrix import AgentProfile, CapabilityMatrix

# ======================================================================
# AgentProfile tests
# ======================================================================


class TestAgentProfile:
    """Test AgentProfile dataclass functionality."""

    def test_agent_profile_creation(self) -> None:
        """Test basic AgentProfile creation."""
        profile = AgentProfile(
            agent_id="claude_code",
            agent_version="claude-sonnet-4",
            confidence_by_task={"code_generation": 0.90, "documentation": 0.95},
            failure_patterns=["scope_expansion"],
        )

        assert profile.agent_id == "claude_code"
        assert profile.agent_version == "claude-sonnet-4"
        assert profile.confidence_by_task["code_generation"] == 0.90
        assert profile.confidence_by_task["documentation"] == 0.95
        assert profile.failure_patterns == ["scope_expansion"]
        assert profile.updated_at != ""

    def test_agent_profile_auto_timestamp(self) -> None:
        """Test that updated_at is automatically set."""
        profile = AgentProfile(
            agent_id="test_agent",
            agent_version="v1.0",
        )

        # Verify timestamp is set and is valid ISO format
        assert profile.updated_at != ""
        datetime.fromisoformat(profile.updated_at)  # Should not raise

    def test_get_confidence_known_task(self) -> None:
        """Test get_confidence for known task category."""
        profile = AgentProfile(
            agent_id="claude_code",
            agent_version="claude-sonnet-4",
            confidence_by_task={"code_generation": 0.90},
        )

        assert profile.get_confidence("code_generation") == 0.90

    def test_get_confidence_unknown_task(self) -> None:
        """Test get_confidence returns 0.0 for unknown task."""
        profile = AgentProfile(
            agent_id="claude_code",
            agent_version="claude-sonnet-4",
            confidence_by_task={"code_generation": 0.90},
        )

        assert profile.get_confidence("unknown_task") == 0.0

    def test_update_confidence_valid(self) -> None:
        """Test updating confidence with valid value."""
        profile = AgentProfile(
            agent_id="claude_code",
            agent_version="claude-sonnet-4",
            confidence_by_task={"code_generation": 0.90},
        )

        original_timestamp = profile.updated_at
        profile.update_confidence("code_generation", 0.95)

        assert profile.get_confidence("code_generation") == 0.95
        assert profile.updated_at != original_timestamp

    def test_update_confidence_new_task(self) -> None:
        """Test updating confidence for new task category."""
        profile = AgentProfile(
            agent_id="claude_code",
            agent_version="claude-sonnet-4",
            confidence_by_task={},
        )

        profile.update_confidence("new_task", 0.80)
        assert profile.get_confidence("new_task") == 0.80

    def test_update_confidence_invalid_too_high(self) -> None:
        """Test update_confidence rejects values > 1.0."""
        profile = AgentProfile(
            agent_id="claude_code",
            agent_version="claude-sonnet-4",
        )

        with pytest.raises(ValueError, match="between 0.0 and 1.0"):
            profile.update_confidence("code_generation", 1.5)

    def test_update_confidence_invalid_too_low(self) -> None:
        """Test update_confidence rejects values < 0.0."""
        profile = AgentProfile(
            agent_id="claude_code",
            agent_version="claude-sonnet-4",
        )

        with pytest.raises(ValueError, match="between 0.0 and 1.0"):
            profile.update_confidence("code_generation", -0.1)

    def test_to_dict(self) -> None:
        """Test conversion to dictionary."""
        profile = AgentProfile(
            agent_id="claude_code",
            agent_version="claude-sonnet-4",
            confidence_by_task={"code_generation": 0.90},
            failure_patterns=["scope_expansion"],
        )

        result = profile.to_dict()

        assert result["agent_id"] == "claude_code"
        assert result["agent_version"] == "claude-sonnet-4"
        assert result["confidence_by_task"]["code_generation"] == 0.90
        assert result["failure_patterns"] == ["scope_expansion"]
        assert "updated_at" in result


# ======================================================================
# CapabilityMatrix tests
# ======================================================================


class TestCapabilityMatrix:
    """Test CapabilityMatrix class functionality."""

    def test_empty_matrix_creation(self) -> None:
        """Test creating empty capability matrix."""
        matrix = CapabilityMatrix()
        assert matrix.profiles == {}

    def test_matrix_creation_with_profiles(self) -> None:
        """Test creating matrix with initial profiles."""
        profile1 = AgentProfile(
            agent_id="claude_code",
            agent_version="claude-sonnet-4",
            confidence_by_task={"code_generation": 0.90},
        )

        matrix = CapabilityMatrix(profiles={"claude_code": profile1})
        assert "claude_code" in matrix.profiles
        assert matrix.profiles["claude_code"] == profile1

    def test_get_confidence_existing_agent_and_task(self) -> None:
        """Test get_confidence for existing agent and task."""
        profile = AgentProfile(
            agent_id="claude_code",
            agent_version="claude-sonnet-4",
            confidence_by_task={"code_generation": 0.90, "documentation": 0.95},
        )

        matrix = CapabilityMatrix(profiles={"claude_code": profile})

        assert matrix.get_confidence("claude_code", "code_generation") == 0.90
        assert matrix.get_confidence("claude_code", "documentation") == 0.95

    def test_get_confidence_unknown_agent(self) -> None:
        """Test get_confidence returns 0.0 for unknown agent."""
        matrix = CapabilityMatrix()
        assert matrix.get_confidence("unknown_agent", "code_generation") == 0.0

    def test_get_confidence_unknown_task(self) -> None:
        """Test get_confidence returns 0.0 for unknown task."""
        profile = AgentProfile(
            agent_id="claude_code",
            agent_version="claude-sonnet-4",
            confidence_by_task={"code_generation": 0.90},
        )

        matrix = CapabilityMatrix(profiles={"claude_code": profile})
        assert matrix.get_confidence("claude_code", "unknown_task") == 0.0

    def test_get_best_agent_single_agent(self) -> None:
        """Test get_best_agent with single agent."""
        profile = AgentProfile(
            agent_id="claude_code",
            agent_version="claude-sonnet-4",
            confidence_by_task={"code_generation": 0.90},
        )

        matrix = CapabilityMatrix(profiles={"claude_code": profile})
        assert matrix.get_best_agent("code_generation") == "claude_code"

    def test_get_best_agent_multiple_agents(self) -> None:
        """Test get_best_agent selects highest confidence agent."""
        profile1 = AgentProfile(
            agent_id="claude_code",
            agent_version="claude-sonnet-4",
            confidence_by_task={"code_generation": 0.90, "documentation": 0.95},
        )

        profile2 = AgentProfile(
            agent_id="codex",
            agent_version="gpt-5.3-codex",
            confidence_by_task={"code_generation": 0.80, "code_review": 0.95},
        )

        profile3 = AgentProfile(
            agent_id="local_llm",
            agent_version="qwen2.5-coder",
            confidence_by_task={"code_generation": 0.65},
        )

        matrix = CapabilityMatrix(
            profiles={
                "claude_code": profile1,
                "codex": profile2,
                "local_llm": profile3,
            }
        )

        # claude_code has highest confidence for code_generation
        assert matrix.get_best_agent("code_generation") == "claude_code"

        # claude_code has highest confidence for documentation
        assert matrix.get_best_agent("documentation") == "claude_code"

        # codex has highest confidence for code_review
        assert matrix.get_best_agent("code_review") == "codex"

    def test_get_best_agent_empty_matrix(self) -> None:
        """Test get_best_agent returns empty string for empty matrix."""
        matrix = CapabilityMatrix()
        assert matrix.get_best_agent("code_generation") == ""

    def test_get_best_agent_no_confidence(self) -> None:
        """Test get_best_agent returns empty string when no agent has confidence."""
        profile = AgentProfile(
            agent_id="claude_code",
            agent_version="claude-sonnet-4",
            confidence_by_task={"code_generation": 0.90},
        )

        matrix = CapabilityMatrix(profiles={"claude_code": profile})
        assert matrix.get_best_agent("unknown_task") == ""

    def test_update_profile_existing_agent(self) -> None:
        """Test updating an existing agent profile."""
        profile = AgentProfile(
            agent_id="claude_code",
            agent_version="claude-sonnet-4",
            confidence_by_task={"code_generation": 0.90},
        )

        matrix = CapabilityMatrix(profiles={"claude_code": profile})

        # Update confidence scores
        matrix.update_profile(
            "claude_code",
            {"confidence_by_task": {"code_generation": 0.95, "documentation": 0.98}},
        )

        assert matrix.get_confidence("claude_code", "code_generation") == 0.95
        assert matrix.get_confidence("claude_code", "documentation") == 0.98

    def test_update_profile_new_agent(self) -> None:
        """Test creating new agent profile via update_profile."""
        matrix = CapabilityMatrix()

        matrix.update_profile(
            "new_agent",
            {
                "agent_version": "v1.0",
                "confidence_by_task": {"code_generation": 0.85},
                "failure_patterns": ["pattern1"],
            },
        )

        assert "new_agent" in matrix.profiles
        assert matrix.get_confidence("new_agent", "code_generation") == 0.85
        assert matrix.profiles["new_agent"].agent_version == "v1.0"
        assert matrix.profiles["new_agent"].failure_patterns == ["pattern1"]

    def test_update_profile_failure_patterns(self) -> None:
        """Test updating failure patterns."""
        profile = AgentProfile(
            agent_id="claude_code",
            agent_version="claude-sonnet-4",
            failure_patterns=["old_pattern"],
        )

        matrix = CapabilityMatrix(profiles={"claude_code": profile})

        matrix.update_profile(
            "claude_code",
            {"failure_patterns": ["new_pattern1", "new_pattern2"]},
        )

        assert matrix.profiles["claude_code"].failure_patterns == [
            "new_pattern1",
            "new_pattern2",
        ]

    def test_update_profile_agent_version(self) -> None:
        """Test updating agent version."""
        profile = AgentProfile(
            agent_id="claude_code",
            agent_version="claude-sonnet-4",
        )

        matrix = CapabilityMatrix(profiles={"claude_code": profile})

        matrix.update_profile("claude_code", {"agent_version": "claude-sonnet-4.5"})

        assert matrix.profiles["claude_code"].agent_version == "claude-sonnet-4.5"

    def test_add_profile(self) -> None:
        """Test adding a profile directly."""
        matrix = CapabilityMatrix()

        profile = AgentProfile(
            agent_id="claude_code",
            agent_version="claude-sonnet-4",
            confidence_by_task={"code_generation": 0.90},
        )

        matrix.add_profile(profile)

        assert "claude_code" in matrix.profiles
        assert matrix.profiles["claude_code"] == profile

    def test_to_dict(self) -> None:
        """Test converting matrix to dictionary."""
        profile1 = AgentProfile(
            agent_id="claude_code",
            agent_version="claude-sonnet-4",
            confidence_by_task={"code_generation": 0.90},
        )

        profile2 = AgentProfile(
            agent_id="codex",
            agent_version="gpt-5.3-codex",
            confidence_by_task={"code_review": 0.95},
        )

        matrix = CapabilityMatrix(profiles={"claude_code": profile1, "codex": profile2})

        result = matrix.to_dict()

        assert "profiles" in result
        assert "claude_code" in result["profiles"]
        assert "codex" in result["profiles"]
        assert result["profiles"]["claude_code"]["confidence_by_task"]["code_generation"] == 0.90
        assert result["profiles"]["codex"]["confidence_by_task"]["code_review"] == 0.95


# ======================================================================
# File I/O tests
# ======================================================================


class TestCapabilityMatrixIO:
    """Test file loading and saving functionality."""

    def test_load_from_yaml(self, tmp_path: Path) -> None:
        """Test loading capability matrix from YAML."""
        yaml_content = """
profiles:
  claude_code:
    agent_version: "claude-sonnet-4"
    confidence_by_task:
      code_generation: 0.90
      documentation: 0.95
    failure_patterns:
      - scope_expansion
      - overconfident_structural_edits

  codex:
    agent_version: "gpt-5.3-codex"
    confidence_by_task:
      code_review: 0.95
      verification: 0.95
    failure_patterns:
      - sandbox_policy_blocks
"""

        yaml_file = tmp_path / "test_matrix.yaml"
        yaml_file.write_text(yaml_content, encoding="utf-8")

        matrix = CapabilityMatrix.from_yaml(yaml_file)

        assert "claude_code" in matrix.profiles
        assert "codex" in matrix.profiles

        assert matrix.get_confidence("claude_code", "code_generation") == 0.90
        assert matrix.get_confidence("claude_code", "documentation") == 0.95
        assert matrix.profiles["claude_code"].failure_patterns == [
            "scope_expansion",
            "overconfident_structural_edits",
        ]

        assert matrix.get_confidence("codex", "code_review") == 0.95
        assert matrix.get_confidence("codex", "verification") == 0.95
        assert matrix.profiles["codex"].failure_patterns == ["sandbox_policy_blocks"]

    def test_load_from_yaml_missing_file(self, tmp_path: Path) -> None:
        """Test loading from non-existent YAML file raises error."""
        with pytest.raises(FileNotFoundError):
            CapabilityMatrix.from_yaml(tmp_path / "nonexistent.yaml")

    def test_load_from_json(self, tmp_path: Path) -> None:
        """Test loading capability matrix from JSON."""
        json_data = {
            "profiles": {
                "claude_code": {
                    "agent_id": "claude_code",
                    "agent_version": "claude-sonnet-4",
                    "confidence_by_task": {"code_generation": 0.90},
                    "failure_patterns": ["scope_expansion"],
                    "updated_at": "2025-01-01T00:00:00Z",
                }
            }
        }

        json_file = tmp_path / "test_matrix.json"
        json_file.write_text(json.dumps(json_data), encoding="utf-8")

        matrix = CapabilityMatrix.from_json(json_file)

        assert "claude_code" in matrix.profiles
        assert matrix.get_confidence("claude_code", "code_generation") == 0.90

    def test_save_to_json(self, tmp_path: Path) -> None:
        """Test saving capability matrix to JSON."""
        profile = AgentProfile(
            agent_id="claude_code",
            agent_version="claude-sonnet-4",
            confidence_by_task={"code_generation": 0.90},
            failure_patterns=["scope_expansion"],
        )

        matrix = CapabilityMatrix(profiles={"claude_code": profile})

        json_file = tmp_path / "output_matrix.json"
        matrix.to_json(json_file)

        # Verify file was created and is valid JSON
        assert json_file.exists()
        with open(json_file, encoding="utf-8") as f:
            data = json.load(f)

        assert "profiles" in data
        assert "claude_code" in data["profiles"]
        assert data["profiles"]["claude_code"]["confidence_by_task"]["code_generation"] == 0.90


# ======================================================================
# Integration tests with seed file
# ======================================================================


class TestCapabilityMatrixWithSeedFile:
    """Test capability matrix with actual seed file."""

    def test_load_seed_file(self) -> None:
        """Test loading the actual seed file if it exists."""
        seed_path = Path(__file__).parent.parent / "data" / "capability_matrix_seed.yaml"

        if not seed_path.exists():
            pytest.skip("Seed file not found")

        matrix = CapabilityMatrix.from_yaml(seed_path)

        # Verify expected agents are present
        assert "claude_code" in matrix.profiles
        assert "codex" in matrix.profiles
        assert "local_llm" in matrix.profiles

        # Verify some expected confidence scores
        assert matrix.get_confidence("claude_code", "code_generation") > 0.0
        assert matrix.get_confidence("codex", "code_review") > 0.0

        # Verify get_best_agent works with seed data
        best_for_docs = matrix.get_best_agent("documentation")
        assert best_for_docs != ""
