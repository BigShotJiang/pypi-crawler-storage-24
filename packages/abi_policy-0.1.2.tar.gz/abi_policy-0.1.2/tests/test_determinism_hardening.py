"""Phase 1 — Determinism hardening tests for abi-policy.

Verifies that:
- Policy evaluation produces identical output for identical input (hash-stable)
- NDJSON serialization is byte-identical across runs
- Bundle serialization order is deterministic
- No OS-dependent path behavior leaks into decisions

Note: The engine captures datetime.now(UTC) internally for decided_at timestamps.
Hash-stability tests freeze time via unittest.mock to isolate the determinism of
all other fields, proving that the engine is fully deterministic when the clock
is held constant (as it would be within a single evaluation in production).
"""

from __future__ import annotations

import hashlib
import json
from datetime import UTC, datetime
from unittest.mock import patch

from abi_policy.bundles import list_bundles, load_bundle
from abi_policy.engine import PolicyEngine
from abi_policy.models import DecisionRequest

_FROZEN_DT = datetime(2025, 1, 1, 0, 0, 0, tzinfo=UTC)


def _sha256(data: str) -> str:
    return hashlib.sha256(data.encode()).hexdigest()


class TestPolicyEvaluationHashStability:
    """Same input => same SHA-256 of NDJSON output."""

    @patch("abi_policy.engine.datetime")
    def test_ndjson_hash_stable_across_invocations(self, mock_dt, default_bundle):
        mock_dt.now.return_value = _FROZEN_DT
        mock_dt.side_effect = lambda *a, **kw: datetime(*a, **kw)
        engine = PolicyEngine(default_bundle)
        req = DecisionRequest(
            action="tool_call",
            resource="read_file",
            run_id="hash0001",
            timestamp="2025-01-01T00:00:00Z",
        )
        hashes = set()
        for _ in range(10):
            resp = engine.evaluate(req)
            line = resp.to_ndjson_line()
            hashes.add(_sha256(line))
        assert len(hashes) == 1, f"Expected 1 unique hash, got {len(hashes)}: {hashes}"

    @patch("abi_policy.engine.datetime")
    def test_deny_decision_hash_stable(self, mock_dt, default_bundle):
        mock_dt.now.return_value = _FROZEN_DT
        mock_dt.side_effect = lambda *a, **kw: datetime(*a, **kw)
        engine = PolicyEngine(default_bundle)
        req = DecisionRequest(
            action="tool_call",
            resource="shell_exec",
            run_id="hash0002",
            timestamp="2025-01-01T00:00:00Z",
        )
        hashes = set()
        for _ in range(10):
            resp = engine.evaluate(req)
            line = resp.to_ndjson_line()
            hashes.add(_sha256(line))
        assert len(hashes) == 1, f"Expected 1 unique hash, got {len(hashes)}"

    @patch("abi_policy.engine.datetime")
    def test_budget_decision_hash_stable(self, mock_dt, default_bundle):
        mock_dt.now.return_value = _FROZEN_DT
        mock_dt.side_effect = lambda *a, **kw: datetime(*a, **kw)
        engine = PolicyEngine(default_bundle)
        req = DecisionRequest(
            action="model_call",
            resource="claude-sonnet",
            context={"token_count": 999999, "budget_scope": "step"},
            run_id="hash0003",
            timestamp="2025-01-01T00:00:00Z",
        )
        hashes = set()
        for _ in range(10):
            resp = engine.evaluate(req)
            line = resp.to_ndjson_line()
            hashes.add(_sha256(line))
        assert len(hashes) == 1


class TestBundleSerializationDeterminism:
    """Bundle listing and loading is deterministic."""

    def test_list_bundles_sorted(self, bundles_dir):
        names = list_bundles(bundles_dir)
        assert names == sorted(names), "Bundle list must be sorted"

    def test_bundle_json_roundtrip_stable(self, bundles_dir):
        """Load bundle, serialize, load again => identical."""
        for name in list_bundles(bundles_dir):
            bundle = load_bundle(name, bundles_dir)
            s1 = json.dumps(bundle, sort_keys=True)
            s2 = json.dumps(bundle, sort_keys=True)
            assert s1 == s2, f"Bundle '{name}' serialization unstable"


class TestCrossPlatformPathHandling:
    """Path-based decisions are OS-independent."""

    def test_backslash_path_normalized(self, default_bundle):
        """Windows-style backslash paths are handled correctly."""
        engine = PolicyEngine(default_bundle)
        req = DecisionRequest(action="file_write", resource="src\\main.py")
        resp = engine.evaluate(req)
        assert resp.decision == "allow"

    def test_forward_slash_path(self, default_bundle):
        engine = PolicyEngine(default_bundle)
        req = DecisionRequest(action="file_write", resource="src/main.py")
        resp = engine.evaluate(req)
        assert resp.decision == "allow"

    def test_traversal_blocked_both_styles(self, default_bundle):
        engine = PolicyEngine(default_bundle)
        for path in ["../../../etc/passwd", "..\\..\\..\\etc\\passwd"]:
            req = DecisionRequest(action="file_write", resource=path)
            resp = engine.evaluate(req)
            assert resp.decision == "deny", f"Path not denied: {path}"
