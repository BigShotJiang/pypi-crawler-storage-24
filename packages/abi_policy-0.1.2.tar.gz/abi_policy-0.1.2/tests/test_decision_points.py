"""Tests for decision point helper functions."""
from abi_policy.decision_points import (
    evaluate_file_write,
    evaluate_model_call,
    evaluate_override,
    evaluate_tool_call,
)


class TestDecisionPoints:
    def test_evaluate_tool_call(self):
        req = evaluate_tool_call("read_file", run_id="abc12345")
        assert req.action == "tool_call"
        assert req.resource == "read_file"
        assert req.run_id == "abc12345"

    def test_evaluate_file_write(self):
        req = evaluate_file_write("src/main.py", content_size=1024)
        assert req.action == "file_write"
        assert req.resource == "src/main.py"
        assert req.context["content_size"] == 1024

    def test_evaluate_model_call(self):
        req = evaluate_model_call("claude-sonnet", token_count=5000, budget_scope="run")
        assert req.action == "model_call"
        assert req.resource == "claude-sonnet"
        assert req.context["token_count"] == 5000
        assert req.context["budget_scope"] == "run"

    def test_evaluate_override(self):
        req = evaluate_override("budget_limit", override_reason="testing")
        assert req.action == "override"
        assert req.resource == "budget_limit"
        assert req.context["override_reason"] == "testing"
