"""Tests for CLI interface."""
import json

from abi_policy.cli import main


class TestCLI:
    def test_evaluate_command(self, bundles_dir, tmp_path):
        input_file = tmp_path / "input.json"
        input_file.write_text(json.dumps({
            "action": "tool_call",
            "resource": "read_file",
            "run_id": "test1234",
        }))

        out_file = tmp_path / "output.json"
        rc = main([
            "--bundles-dir", str(bundles_dir),
            "evaluate",
            "--policy", "default",
            "--input", str(input_file),
            "--out", str(out_file),
        ])

        assert rc == 0
        results = json.loads(out_file.read_text())
        assert len(results) == 1
        assert results[0]["decision"] == "allow"

    def test_explain_command(self, bundles_dir, tmp_path, capsys):
        input_file = tmp_path / "input.json"
        input_file.write_text(json.dumps({
            "action": "tool_call",
            "resource": "shell_exec",
        }))

        rc = main([
            "--bundles-dir", str(bundles_dir),
            "explain",
            "--policy", "default",
            "--input", str(input_file),
        ])

        assert rc == 0
        captured = capsys.readouterr()
        assert "deny" in captured.out.lower()

    def test_validate_bundle_command(self, bundles_dir, capsys):
        rc = main([
            "--bundles-dir", str(bundles_dir),
            "validate-bundle",
            "--policy", "default",
        ])
        assert rc == 0
        assert "valid" in capsys.readouterr().out.lower()

    def test_list_command(self, bundles_dir, capsys):
        rc = main([
            "--bundles-dir", str(bundles_dir),
            "list",
        ])
        assert rc == 0
        out = capsys.readouterr().out
        assert "default" in out

    def test_cost_envelope_command(self, tmp_path, capsys):
        envelope_file = tmp_path / "envelope.yaml"
        envelope_file.write_text(
            "max_total_tokens_delta: 10%\n"
            "max_single_prompt_delta: 15%\n"
            "allow_risk_escalation: false\n"
            "allow_policy_escalation: false\n"
        )

        baseline_file = tmp_path / "baseline.json"
        baseline_file.write_text(json.dumps({
            "total_tokens": 1000,
            "prompt_tokens": {"a": 500},
            "risk_level": "low",
            "policy_level": "default",
        }))

        current_file = tmp_path / "current.json"
        current_file.write_text(json.dumps({
            "total_tokens": 1050,
            "prompt_tokens": {"a": 525},
            "risk_level": "low",
            "policy_level": "default",
        }))

        rc = main([
            "cost-envelope",
            "--envelope", str(envelope_file),
            "--baseline", str(baseline_file),
            "--current", str(current_file),
        ])

        assert rc == 0
        captured = capsys.readouterr()
        result = json.loads(captured.out)
        assert result["status"] == "PASS"
        assert result["schema_version"] == "cost-envelope-result/1.0"
