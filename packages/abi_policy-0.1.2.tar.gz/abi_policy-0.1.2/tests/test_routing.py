"""Comprehensive tests for model-governance routing engine, budget controller,
and evidence ledger.
"""

from __future__ import annotations

import json
import re

from abi_policy.budget import BudgetController
from abi_policy.evidence_ledger import EvidenceLedger
from abi_policy.routing import RoutingEngine

# ======================================================================
# Fixtures — shared across all test classes
# ======================================================================

EXAMPLE_REGISTRY: dict = {
    "providers": [
        {
            "name": "anthropic",
            "channels": [
                {
                    "name": "api",
                    "models": [
                        {
                            "id": "claude-opus-4",
                            "tier": "frontier",
                            "capabilities": [
                                "code_generation",
                                "reasoning",
                                "tool_use",
                            ],
                            "ru_per_1k": {"input": 3.0, "output": 15.0},
                        },
                        {
                            "id": "claude-sonnet-4",
                            "tier": "standard",
                            "capabilities": [
                                "code_generation",
                                "tool_use",
                            ],
                            "ru_per_1k": {"input": 0.8, "output": 3.2},
                        },
                    ],
                },
            ],
        },
        {
            "name": "ollama",
            "channels": [
                {
                    "name": "local",
                    "models": [
                        {
                            "id": "qwen2.5-coder",
                            "tier": "local",
                            "capabilities": ["code_generation"],
                            "ru_per_1k": {"input": 0, "output": 0},
                        },
                    ],
                },
            ],
        },
    ],
}

EXAMPLE_POLICY: dict = {
    "rules": [
        {
            "rule_id": "frontier-code-gen",
            "priority": 10,
            "task_type": "code_generation",
            "tier": "frontier",
            "model_ref": "anthropic/api/claude-opus-4",
            "fallback_chain": "code-gen-fallback",
        },
        {
            "rule_id": "standard-code-gen",
            "priority": 20,
            "task_type": "code_generation",
            "tier": "any",
            "model_ref": "anthropic/api/claude-sonnet-4",
        },
        {
            "rule_id": "local-only",
            "priority": 30,
            "task_type": "code_generation",
            "constraints": ["no_external_models"],
            "model_ref": "ollama/local/qwen2.5-coder",
        },
    ],
    "fallback_chains": {
        "code-gen-fallback": [
            "anthropic/api/claude-sonnet-4",
            "ollama/local/qwen2.5-coder",
        ],
    },
}

EXAMPLE_PROFILE: dict = {
    "profile_id": "abi-core-project",
}

BUDGET_GREEN: dict = {"zone": "GREEN", "ru_remaining": 1000.0}
BUDGET_RED: dict = {"zone": "RED", "ru_remaining": 50.0}
BUDGET_EXHAUSTED: dict = {"zone": "EXHAUSTED", "ru_remaining": 0.0}


# ======================================================================
# TestRoutingEngine
# ======================================================================


class TestRoutingEngine:
    """Deterministic routing engine tests."""

    def _make_engine(
        self,
        *,
        registry: dict = EXAMPLE_REGISTRY,
        policy: dict = EXAMPLE_POLICY,
        profile: dict | None = EXAMPLE_PROFILE,
        budget: dict = BUDGET_GREEN,
    ) -> RoutingEngine:
        return RoutingEngine(registry, policy, profile, budget)

    # --- determinism ---

    def test_deterministic_same_inputs_same_decision(self):
        engine = self._make_engine()
        task = {"task_type": "code_generation", "tier_required": "frontier"}
        d1 = engine.route(task)
        d2 = engine.route(task)
        assert d1["record_hash"] == d2["record_hash"]

    # --- priority ordering ---

    def test_priority_ordering(self):
        engine = self._make_engine()
        task = {"task_type": "code_generation", "tier_required": "frontier"}
        decision = engine.route(task)
        assert decision["no_route"] is False
        assert decision["rule_id"] == "frontier-code-gen"
        assert decision["model"]["model_id"] == "claude-opus-4"

    # --- tie-breaking ---

    def test_tie_breaking_by_rule_id(self):
        policy = {
            "rules": [
                {
                    "rule_id": "aaa-rule",
                    "priority": 10,
                    "task_type": "code_generation",
                    "tier": "any",
                    "model_ref": "anthropic/api/claude-sonnet-4",
                },
                {
                    "rule_id": "bbb-rule",
                    "priority": 10,
                    "task_type": "code_generation",
                    "tier": "any",
                    "model_ref": "anthropic/api/claude-opus-4",
                },
            ],
            "fallback_chains": {},
        }
        engine = self._make_engine(policy=policy)
        task = {"task_type": "code_generation"}
        decision = engine.route(task)
        assert decision["rule_id"] == "aaa-rule"
        assert decision["model"]["model_id"] == "claude-sonnet-4"

    # --- tier enforcement ---

    def test_frontier_required_no_downgrade(self):
        """tier_required=frontier must NOT match a standard-tier model."""
        policy = {
            "rules": [
                {
                    "rule_id": "std-only",
                    "priority": 10,
                    "task_type": "code_generation",
                    "tier": "any",
                    "model_ref": "anthropic/api/claude-sonnet-4",
                },
            ],
            "fallback_chains": {},
        }
        engine = self._make_engine(policy=policy)
        task = {"task_type": "code_generation", "tier_required": "frontier"}
        decision = engine.route(task)
        assert decision["no_route"] is True

    # --- capabilities ---

    def test_capabilities_filtering(self):
        engine = self._make_engine()
        task = {
            "task_type": "code_generation",
            "tier_required": "any",
            "capabilities_required": ["reasoning"],
        }
        decision = engine.route(task)
        assert decision["no_route"] is False
        # claude-sonnet-4 lacks reasoning — must pick opus or skip to it
        assert decision["model"]["model_id"] == "claude-opus-4"

    # --- no route ---

    def test_no_route_when_all_disqualified(self):
        policy = {
            "rules": [
                {
                    "rule_id": "needs-vision",
                    "priority": 10,
                    "task_type": "code_generation",
                    "tier": "any",
                    "model_ref": "anthropic/api/claude-sonnet-4",
                },
            ],
            "fallback_chains": {},
        }
        engine = self._make_engine(policy=policy)
        task = {
            "task_type": "code_generation",
            "capabilities_required": ["vision"],
        }
        decision = engine.route(task)
        assert decision["no_route"] is True
        assert len(decision["reasons"]) > 0

    # --- project profile: no_external_models ---

    def test_project_profile_no_external(self):
        profile = {"profile_id": "locked-down", "no_external_models": True}
        engine = self._make_engine(profile=profile)
        task = {"task_type": "code_generation", "tier_required": "any"}
        decision = engine.route(task)
        # API-based models rejected; only local-only rule with constraint match works
        # But the local-only rule requires constraint active AND task_type match
        # Since no_external_models is active, the constraint rule should match
        assert decision["no_route"] is False
        assert decision["model"]["channel"] == "local"

    # --- project profile: disallow_providers ---

    def test_project_profile_disallow_provider(self):
        profile = {
            "profile_id": "no-anthropic",
            "disallow_providers": ["anthropic"],
        }
        engine = self._make_engine(profile=profile)
        task = {"task_type": "code_generation", "tier_required": "any"}
        decision = engine.route(task)
        # All anthropic models disqualified; only ollama remains via fallback
        if not decision["no_route"]:
            assert decision["model"]["provider"] != "anthropic"

    # --- fallback chain ---

    def test_fallback_chain_used(self):
        """When primary model is blocked by profile, fallback chain activates."""
        profile = {
            "profile_id": "no-frontier",
            "require_frontier": False,
            "disallow_providers": [],
        }
        # Make the primary model_ref invalid so fallback is tried
        policy = {
            "rules": [
                {
                    "rule_id": "broken-primary",
                    "priority": 10,
                    "task_type": "code_generation",
                    "tier": "any",
                    "model_ref": "anthropic/api/nonexistent-model",
                    "fallback_chain": "code-gen-fallback",
                },
            ],
            "fallback_chains": {
                "code-gen-fallback": [
                    "anthropic/api/claude-sonnet-4",
                    "ollama/local/qwen2.5-coder",
                ],
            },
        }
        engine = self._make_engine(policy=policy, profile=profile)
        task = {"task_type": "code_generation"}
        decision = engine.route(task)
        assert decision["no_route"] is False
        assert decision["via_fallback"] == "code-gen-fallback"
        assert decision["model"]["model_id"] == "claude-sonnet-4"

    # --- budget: exhausted ---

    def test_quota_zone_exhausted_no_route(self):
        engine = self._make_engine(budget=BUDGET_EXHAUSTED)
        task = {"task_type": "code_generation", "tier_required": "frontier"}
        decision = engine.route(task)
        assert decision["no_route"] is True
        assert any("EXHAUSTED" in r for r in decision["reasons"])

    # --- quota zone transitions ---

    def test_quota_zone_transitions(self):
        bc = BudgetController(1000)
        assert bc.zone == "GREEN"

        bc.consume(600)
        assert bc.zone == "YELLOW"

        bc.consume(200)  # total 800
        assert bc.zone == "RED"

        bc.consume(150)  # total 950
        assert bc.zone == "EXHAUSTED"

    # --- record_hash format ---

    def test_record_hash_is_sha256(self):
        engine = self._make_engine()
        task = {"task_type": "code_generation", "tier_required": "frontier"}
        decision = engine.route(task)
        assert "record_hash" in decision
        assert re.fullmatch(r"[0-9a-f]{64}", decision["record_hash"])

    # --- schema version ---

    def test_schema_version_correct(self):
        engine = self._make_engine()
        task = {"task_type": "code_generation", "tier_required": "frontier"}
        decision = engine.route(task)
        assert decision["schema_version"] == "routing-decision-record/1.0"


# ======================================================================
# TestBudgetController
# ======================================================================


class TestBudgetController:
    """RU budget controller tests."""

    def test_initial_zone_green(self):
        bc = BudgetController(1000)
        assert bc.zone == "GREEN"

    def test_zone_transitions(self):
        bc = BudgetController(100, yellow_pct=60, red_pct=80, exhausted_pct=95)
        assert bc.zone == "GREEN"

        bc.consume(60)
        assert bc.zone == "YELLOW"

        bc.consume(20)  # 80 total
        assert bc.zone == "RED"

        bc.consume(15)  # 95 total
        assert bc.zone == "EXHAUSTED"

    def test_consume_updates_state(self):
        bc = BudgetController(1000)
        state = bc.consume(100)
        assert state.ru_consumed == 100
        assert state.remaining == 900
        assert state.zone == "GREEN"

        state2 = bc.consume(550)
        assert state2.ru_consumed == 650
        assert state2.remaining == 350
        assert state2.zone == "YELLOW"

    def test_can_route_checks_remaining(self):
        bc = BudgetController(100, exhausted_pct=95)
        assert bc.can_route(90) is True
        bc.consume(90)
        # 90 consumed, adding 10 -> 100 = 100% >= 95% exhausted
        assert bc.can_route(10) is False
        # Small amount still fits
        assert bc.can_route(1) is True

    def test_snapshot_schema(self):
        bc = BudgetController(500)
        bc.consume(100)
        snap = bc.snapshot()
        assert snap["schema_version"] == "budget-state/1.0"
        assert snap["ru_allocated"] == 500
        assert snap["ru_consumed"] == 100
        assert snap["ru_remaining"] == 400
        assert snap["zone"] == "GREEN"
        assert "canonical" in snap
        # canonical must be valid JSON
        parsed = json.loads(snap["canonical"])
        assert parsed["ru_allocated"] == 500


# ======================================================================
# TestEvidenceLedger
# ======================================================================


class TestEvidenceLedger:
    """Append-only JSONL evidence ledger tests."""

    def test_append_creates_hash_chain(self, tmp_path):
        ledger = EvidenceLedger(tmp_path / "ledger.jsonl")
        r1 = ledger.append({"event": "first"})
        r2 = ledger.append({"event": "second"})

        assert r1["record_hash"] != r2["record_hash"]
        assert r2["prev_hash"] == r1["record_hash"]

    def test_verify_chain_valid(self, tmp_path):
        ledger = EvidenceLedger(tmp_path / "ledger.jsonl")
        ledger.append({"event": "a"})
        ledger.append({"event": "b"})
        ledger.append({"event": "c"})

        assert ledger.verify_chain() is True

    def test_verify_chain_detects_tampering(self, tmp_path):
        path = tmp_path / "ledger.jsonl"
        ledger = EvidenceLedger(path)
        ledger.append({"event": "a"})
        ledger.append({"event": "b"})

        # Tamper with the first record
        lines = path.read_text(encoding="utf-8").splitlines()
        record = json.loads(lines[0])
        record["event"] = "TAMPERED"
        lines[0] = json.dumps(record, sort_keys=True, ensure_ascii=False)
        path.write_text("\n".join(lines) + "\n", encoding="utf-8")

        ledger2 = EvidenceLedger(path)
        assert ledger2.verify_chain() is False

    def test_first_record_has_zero_prev_hash(self, tmp_path):
        ledger = EvidenceLedger(tmp_path / "ledger.jsonl")
        r = ledger.append({"event": "genesis"})
        assert r["prev_hash"] == "0" * 64

    def test_deterministic_serialization(self, tmp_path):
        path = tmp_path / "ledger.jsonl"
        ledger = EvidenceLedger(path)
        r1 = ledger.append({"z_field": 1, "a_field": 2})

        # Re-open, re-read, verify content hash
        ledger2 = EvidenceLedger(path)
        records = ledger2.read_all()
        assert len(records) == 1
        assert records[0]["record_hash"] == r1["record_hash"]
