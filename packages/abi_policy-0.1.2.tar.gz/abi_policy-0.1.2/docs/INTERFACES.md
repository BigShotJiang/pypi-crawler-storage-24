# abi-policy Interfaces

## Input: DecisionRequest

```json
{
  "action": "tool_call | file_write | model_call | override",
  "resource": "<tool_name | file_path | model_name | policy_name>",
  "context": { "<action-specific fields>" },
  "run_id": "<8-hex-char run id>",
  "timestamp": "<ISO 8601>"
}
```

## Output: DecisionResponse

```json
{
  "decision": "allow | deny | require_approval",
  "reason_code": "TOOL_DENIED | PATH_TRAVERSAL | MODEL_NOT_ALLOWED | ...",
  "explanation": "<human-readable explanation>",
  "request": { "<original DecisionRequest>" },
  "policy_id": "<bundle_id>",
  "timestamp": "<ISO 8601>"
}
```

## Output: PolicyDecision NDJSON line

Compatible with abi-core `policy-decision/1.0`:
```json
{"run_id":"abcd1234","policy_id":"default","decision":"allow","decided_at":"...","reason":"...","context":{...}}
```

## Policy Bundle Format

```json
{
  "bundle_id": "default",
  "version": "1.0.0",
  "description": "...",
  "rules": {
    "tools": { "allow": [...], "deny": [...] },
    "paths": { "deny_patterns": [...] },
    "models": { "allow": [...] },
    "budget": { "max_tokens_per_run": N, "max_tokens_per_step": N },
    "escalation": { "risky_actions": {...}, "override_policy": "..." }
  }
}
```

## CLI Commands

| Command | Input | Output |
|---------|-------|--------|
| `evaluate --policy P --input F --out O` | JSON file with DecisionRequest(s) | JSON file with DecisionResponse(s) |
| `explain --policy P --input F` | JSON file with DecisionRequest(s) | Human-readable explanation to stdout |
| `validate-bundle --policy P` | Policy bundle name | Validation result to stdout |
| `list` | (none) | Available bundle names to stdout |
