# Architecture

## High-Level Design
Deterministic policy evaluation engine for AbilityBI agent governance.

## Components
- src/abi_policy/ — policy engine and decision models
- schemas/ — policy definition JSON schemas
- manifests/ — provider repo manifests
- scripts/verify_provider_repos.py — provider compliance checker

## Interfaces
Inputs: Structured data, policy definitions, or API requests depending on module.
Outputs: Processed results, evidence packs, or structured reports.
