# Schema Proposal: decision-request/1.0 and decision-response/1.0

## Rationale

The current abi-core `policy_decision.schema.json` records decisions that have already been made.
However, there is no standard schema for requesting a decision evaluation. abi-policy currently
uses an internal DecisionRequest/DecisionResponse format that should be standardized.

## Proposed: decision-request/1.0

```json
{
  "schema_version": "decision-request/1.0",
  "action": "tool_call | file_write | model_call | override",
  "resource": "<target resource identifier>",
  "context": {
    "arguments": {},
    "content_size": 0,
    "token_count": 0,
    "budget_scope": "step | run",
    "override_reason": ""
  },
  "run_id": "<8-char hex>",
  "timestamp": "<ISO 8601>"
}
```

## Proposed: decision-response/1.0

```json
{
  "schema_version": "decision-response/1.0",
  "decision": "allow | deny | require_approval",
  "reason_code": "<machine-readable code>",
  "explanation": "<human-readable text>",
  "request": { "<original decision-request>" },
  "policy_id": "<bundle that was evaluated>",
  "timestamp": "<ISO 8601>"
}
```

## Relationship to Existing Schemas

- `policy_decision.schema.json` remains the canonical record of a decided action
- `decision-request/1.0` is the input to the evaluation
- `decision-response/1.0` is the evaluation result (which then gets recorded as a policy_decision)
