# Verification Notes — abi-policy

## Traceability Markers

### Full node ID: determinism

```
tests/test_engine.py::TestPolicyEngine::test_deterministic_output_for_fixed_input
```

Verifies that the same `DecisionRequest` input always produces identical
`decision`, `reason_code`, `explanation`, and `policy_id` fields across
10 repeated evaluations.

### Full node ID: timestamp exclusion

N/A — abi-policy does not produce hashed payloads. The determinism test above
uses a fixed timestamp (`2025-01-01T00:00:00Z`) and excludes it from equality
comparison. The stability node below serves as the second traceability anchor.

### Full node ID: stability

```
tests/test_engine.py::TestPolicyEngine::test_ndjson_output_stable
```

Asserts that `resp.to_ndjson_line()` produces byte-identical NDJSON output
across 10 repeated calls for the same input with a fixed timestamp.

---

## Tranche History

- **Control Plane Tranche** (base HEAD `b45020d`) — determinism hardening, evidence deepening, contract enforcement

### Control Plane Tranche — Capability Advancement

**Determinism hardening** — 8 tests in `tests/test_determinism_hardening.py`

Full node ID:
```
tests/test_determinism_hardening.py::TestDeterminismHardening::test_ndjson_hash_stability_allow
```

**Evidence deepening** — 4 tests in `tests/test_evidence_deepening.py`

Full node ID:
```
tests/test_evidence_deepening.py::TestEvidenceDeepening::test_ndjson_records_have_required_fields
```

**Contract enforcement** — 4 tests in `tests/test_contract_enforcement.py`

Full node ID:
```
tests/test_contract_enforcement.py::TestContractEnforcement::test_allow_record_has_valid_structure
```

16 new tests total. All pass. Clock frozen via `unittest.mock.patch`
for hash stability. Tier-2 policy-decision schema validation.

### Model Governance & Routing Spec v1.0 — Routing Engine Tranche

**Base HEAD**: `b45020d`

New modules:
- `src/abi_policy/routing.py` — Deterministic `RoutingEngine` with priority-ordered rules, first-match wins, fallback chains, profile constraints, quota zone gating
- `src/abi_policy/budget.py` — `BudgetController` with RU tracking and quota zones (GREEN/YELLOW/RED/EXHAUSTED)
- `src/abi_policy/evidence_ledger.py` — Append-only JSONL evidence ledger with SHA-256 hash chaining

23 new tests in `tests/test_routing.py` (13 routing + 5 budget + 5 ledger). 71 tests total.

Full node ID:
```
tests/test_routing.py::TestRoutingEngine::test_deterministic_same_input_same_output
```

verify.log: EXIT_CODE=0, Results: 3 passed, 0 failed
