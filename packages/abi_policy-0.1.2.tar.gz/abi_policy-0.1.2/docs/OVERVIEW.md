# Overview

## Purpose
Deterministic policy engine that governs agent routing, tool access, and budget allocation across AbilityBI orchestration runs.

## Primary Users
- AbilityBI engineering and AI pipeline operators

## Scope
- What it covers: Deterministic policy evaluation engine for AbilityBI agent governance.
- What it does not cover: External distribution or unsanctioned integrations
