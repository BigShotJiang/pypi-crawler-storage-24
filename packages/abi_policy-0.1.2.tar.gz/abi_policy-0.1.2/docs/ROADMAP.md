# Roadmap

## Near Term
- Dynamic policy hot-reload
- Policy conflict detection

## Later
- Federated policy registry across repos
