# Cross-Repo CI Access — Threat Model & Usage

> **Status:** Implemented — CI Access Layer v1 (2026-03-02)
> **Owner:** AbilityBI platform team
> **Related:** [manifests/provider_repos.json](../manifests/provider_repos.json), [abi-template: CI_ACCESS_LAYER.md](../../abi-template/docs/CI_ACCESS_LAYER.md)

---

## Overview

Consumer CI workflows need read-only access to sibling repositories (provider repos) to run verification. This document defines the threat model, the access mechanism, the scope, and the controls.

---

## Threat Model

### Assets

| Asset | Sensitivity | Location |
|-------|-------------|----------|
| Source code in provider repos | Internal — not public | GitHub private repos |
| GitHub App private key | Critical — grants read to all installed repos | Org secret |
| GitHub App installation token | High — short-lived (1 h), read-only | Ephemeral in CI runner |
| CI workflow logs | Internal | GitHub Actions |

### Threats & Mitigations

| Threat | Mitigation |
|--------|-----------|
| **Credential leakage via long-lived PAT** | No PATs used. The GitHub App private key is stored as an org secret restricted to consumer repos. Installation tokens are short-lived (1 h) and scoped to installed repos. |
| **Accidental write access to provider repos** | App permission is `Contents: Read` only. No write permission requested or granted. |
| **Workflow injection via provider repo content** | Provider repos are checked out to `.providers/<repo>` inside the working directory. No `eval` or `source` of provider content occurs in CI workflows. |
| **Token exfiltration via `continue-on-error` bypass** | `continue-on-error` is prohibited on provider checkout steps. Any checkout failure is hard-fail. |
| **Reintroduction of GITHUB_TOKEN clone hacks** | Phase D compliance linter detects and fails on any `git clone.*GITHUB_TOKEN.*AbilityBI` pattern in workflow files. Integrated into verify gate. |
| **Scope creep — app installed to unintended repos** | App installation is restricted to the repos listed in `manifests/provider_repos.json`. Verifier script cross-checks manifest against installed repos. |
| **Stale manifest drift** | `scripts/verify_provider_repos.py` validates manifest schema and warns if consumer repos reference repos not in the provider list. |

### Trust Boundaries

```
CI Runner (ephemeral)
  ├── GITHUB_TOKEN: Contents:Read on calling repo only
  ├── ABI_GH_APP_ID: org secret (read by runner, never logged)
  ├── ABI_GH_APP_PRIVATE_KEY: org secret (read by runner, never logged)
  └── App installation token (1h, Contents:Read on all installed repos)
        ├── .providers/abi-core/      ← checked out, read-only
        └── .providers/<other-repo>/  ← checked out, read-only
```

---

## Access Mechanism

### GitHub App: AbilityBI-CI-Access

- **Type:** GitHub App (not OAuth App, not PAT)
- **Permission:** `Contents: Read`
- **Installation:** Organization-level, restricted to listed repos
- **Token lifetime:** 1 hour (GitHub maximum for installation tokens)
- **Token scope:** All repos the app is installed on

### Token Flow

1. CI workflow calls `AbilityBI/abi-template/.github/actions/checkout-providers`
2. Action calls `actions/create-github-app-token` with `ABI_GH_APP_ID` + `ABI_GH_APP_PRIVATE_KEY`
3. GitHub returns a short-lived installation token
4. Action clones provider repos using `https://x-access-token:<token>@github.com/...`
5. Token is not stored after the step completes

---

## Manifest: provider_repos.json

The file `manifests/provider_repos.json` is the single source of truth for:
- Which repos the app must be installed on (`provider_repos`)
- Which repos are consumers of the checkout-providers action (`consumer_repos`)

Changes to this manifest must:
1. Be accompanied by a corresponding change to the GitHub App installation
2. Pass schema validation via `schemas/provider_repos.schema.json`
3. Pass the verifier (`scripts/verify_provider_repos.py`)

---

## Verifier

```
python scripts/verify_provider_repos.py
```

Checks:
1. Manifest parses and validates against its JSON schema
2. All `consumer_repos` are a subset of `provider_repos` (consumer must also be a provider)
3. No provider repo contains whitespace or uppercase (naming convention)

When run in CI with `GITHUB_TOKEN` set and sufficient permissions, it additionally:
4. Lists installed repos for the app (requires org admin read) — best-effort, warns on failure

---

## Usage in Consumer Workflows

```yaml
- name: Checkout providers
  uses: AbilityBI/abi-template/.github/actions/checkout-providers@main  # pin SHA in prod
  with:
    app_id: ${{ secrets.ABI_GH_APP_ID }}
    private_key: ${{ secrets.ABI_GH_APP_PRIVATE_KEY }}
```

Provider repos are available at `.providers/<repo-name>/` after this step.

---

## Audit Receipts

Every CI run that uses `checkout-providers` is auditable via GitHub Actions logs. Receipts
are stored under `runs/` in repositories that opt in to local receipt writing.

---

## Prohibited Patterns

The following patterns are detected and rejected by the Phase D compliance linter:

| Pattern | Reason |
|---------|--------|
| `git clone.*GITHUB_TOKEN.*AbilityBI` | GITHUB_TOKEN lacks cross-repo read; relies on silent fail |
| `continue-on-error: true` on provider checkout steps | Masks checkout failures; allows untested code to reach verify |
| `if [ -d .../abi-core ]` fallback in verify | Allows skipping required tests; degrades CI signal |
