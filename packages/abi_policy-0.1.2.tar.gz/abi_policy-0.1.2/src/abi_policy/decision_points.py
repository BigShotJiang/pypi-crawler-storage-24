"""Decision point helper functions for orchestrators.

Each function creates a well-formed DecisionRequest for common scenarios.
"""
from __future__ import annotations

from typing import Any

from abi_policy.models import DecisionRequest


def evaluate_tool_call(
    tool_name: str,
    *,
    run_id: str = "",
    arguments: dict[str, Any] | None = None,
    timestamp: str = "",
) -> DecisionRequest:
    """Create a DecisionRequest for a tool invocation."""
    return DecisionRequest(
        action="tool_call",
        resource=tool_name,
        context={"arguments": arguments or {}},
        run_id=run_id,
        timestamp=timestamp,
    )


def evaluate_file_write(
    file_path: str,
    *,
    run_id: str = "",
    content_size: int = 0,
    timestamp: str = "",
) -> DecisionRequest:
    """Create a DecisionRequest for a file write operation."""
    return DecisionRequest(
        action="file_write",
        resource=file_path,
        context={"content_size": content_size},
        run_id=run_id,
        timestamp=timestamp,
    )


def evaluate_model_call(
    model_name: str,
    *,
    run_id: str = "",
    token_count: int = 0,
    budget_scope: str = "step",
    timestamp: str = "",
) -> DecisionRequest:
    """Create a DecisionRequest for a model/provider invocation."""
    return DecisionRequest(
        action="model_call",
        resource=model_name,
        context={"token_count": token_count, "budget_scope": budget_scope},
        run_id=run_id,
        timestamp=timestamp,
    )


def evaluate_override(
    resource: str,
    *,
    run_id: str = "",
    override_reason: str = "",
    timestamp: str = "",
) -> DecisionRequest:
    """Create a DecisionRequest for a policy override."""
    return DecisionRequest(
        action="override",
        resource=resource,
        context={"override_reason": override_reason},
        run_id=run_id,
        timestamp=timestamp,
    )
