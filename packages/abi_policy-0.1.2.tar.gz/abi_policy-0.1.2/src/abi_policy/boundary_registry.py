"""Capability Boundary Registry — enforce task execution boundaries per agent and category.

This module provides a registry for managing capability boundaries that determine whether
agents can execute tasks autonomously, require human-in-the-loop review, or are forbidden.

⚠️  DIVERGENCE NOTICE:
This is the SIMPLIFIED abi-policy implementation for general use cases.
A MORE SOPHISTICATED implementation exists in abi-orchestrator with:
  - Hash-chained audit trails
  - Deterministic timestamps for testing
  - BoundaryCheckRecord ledgers
  - Different API: check_boundary(task_type, run_id, task_id)

The two implementations have INCOMPATIBLE APIs:
  - abi-policy:     check(task_category, agent_id) -> Literal[str]
  - abi-orchestrator: check_boundary(task_type, run_id, task_id) -> BoundaryAction

Do NOT attempt to unify these — they serve different purposes.
Use THIS version for simple boundary checks without audit requirements.
Use the orchestrator version when you need compliance-grade audit trails.
"""

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Literal


@dataclass
class BoundaryEntry:
    """A single boundary rule for a task category.

    Attributes:
        task_category: The category of task (e.g., "code_generation", "deployment")
        agent_id: Specific agent ID this rule applies to (None means all agents)
        risk_tier: Risk classification (e.g., "low", "medium", "high", "critical")
        action: Required action level for this boundary
        conditions: Optional conditions or notes about when this boundary applies
    """
    task_category: str
    agent_id: str | None
    risk_tier: str
    action: Literal["autonomous", "requires_hil", "forbidden"]
    conditions: str | None = None


class BoundaryRegistry:
    """Registry for managing and checking capability boundaries.

    The registry maintains a list of boundary entries and provides a check method
    to determine the required action level for a given task category and agent.

    Matching priority:
    1. Agent-specific entry (exact match on both task_category and agent_id)
    2. General entry (match on task_category with agent_id=None)
    3. Default fallback ("requires_hil")
    """

    def __init__(self, entries: list[BoundaryEntry] | None = None):
        """Initialize the boundary registry.

        Args:
            entries: List of boundary entries. If None, initializes empty.
        """
        self.entries = entries or []

    def check(
        self,
        task_category: str,
        agent_id: str | None = None
    ) -> Literal["autonomous", "requires_hil", "forbidden"]:
        """Check the boundary action for a given task category and agent.

        Args:
            task_category: The task category to check
            agent_id: Optional agent ID for agent-specific rules

        Returns:
            The required action level: "autonomous", "requires_hil", or "forbidden"
        """
        # Priority 1: Check for agent-specific entry
        if agent_id is not None:
            for entry in self.entries:
                if (entry.task_category == task_category and
                    entry.agent_id == agent_id):
                    return entry.action

        # Priority 2: Check for general entry (agent_id=None)
        for entry in self.entries:
            if (entry.task_category == task_category and
                entry.agent_id is None):
                return entry.action

        # Priority 3: Default fallback
        return "requires_hil"

    @classmethod
    def from_yaml(cls, yaml_path: str | Path) -> "BoundaryRegistry":
        """Load boundary registry from a YAML file.

        Args:
            yaml_path: Path to the YAML file containing boundary definitions

        Returns:
            A new BoundaryRegistry instance populated with entries from the file

        Raises:
            ImportError: If PyYAML is not installed
            FileNotFoundError: If the YAML file doesn't exist
            ValueError: If the YAML structure is invalid
        """
        try:
            import yaml
        except ImportError as e:
            raise ImportError(
                "PyYAML is required for YAML loading. "
                "Install with: pip install pyyaml"
            ) from e

        yaml_path = Path(yaml_path)
        if not yaml_path.exists():
            raise FileNotFoundError(f"Boundary YAML file not found: {yaml_path}")

        with yaml_path.open("r", encoding="utf-8") as f:
            data = yaml.safe_load(f)

        if not isinstance(data, dict) or "boundaries" not in data:
            raise ValueError(
                "Invalid boundary YAML: must contain 'boundaries' key at root"
            )

        entries = []
        for item in data["boundaries"]:
            # Validate required fields
            if "task_category" not in item or "action" not in item:
                raise ValueError(
                    f"Boundary entry missing required fields: {item}"
                )

            # Validate action value
            action = item["action"]
            if action not in ("autonomous", "requires_hil", "forbidden"):
                raise ValueError(
                    f"Invalid action '{action}' for task '{item['task_category']}'. "
                    "Must be one of: autonomous, requires_hil, forbidden"
                )

            entry = BoundaryEntry(
                task_category=item["task_category"],
                agent_id=item.get("agent_id"),
                risk_tier=item.get("risk_tier", "medium"),
                action=action,
                conditions=item.get("conditions")
            )
            entries.append(entry)

        return cls(entries=entries)

    @classmethod
    def from_yaml_with_schema(
        cls,
        yaml_path: str | Path,
        schema_path: str | Path
    ) -> "BoundaryRegistry":
        """Load boundary registry from YAML and validate against JSON schema.

        Args:
            yaml_path: Path to the YAML file containing boundary definitions
            schema_path: Path to the JSON schema file for validation

        Returns:
            A new BoundaryRegistry instance populated and validated

        Raises:
            ImportError: If required libraries (PyYAML, jsonschema) are not installed
            FileNotFoundError: If files don't exist
            jsonschema.ValidationError: If validation fails
        """
        try:
            import json
            import jsonschema
        except ImportError as e:
            raise ImportError(
                "jsonschema is required for schema validation. "
                "Install with: pip install jsonschema"
            ) from e

        # Load the schema
        schema_path = Path(schema_path)
        if not schema_path.exists():
            raise FileNotFoundError(f"Schema file not found: {schema_path}")

        with schema_path.open("r", encoding="utf-8") as f:
            schema = json.load(f)

        # Load and validate the YAML data
        try:
            import yaml
        except ImportError as e:
            raise ImportError(
                "PyYAML is required for YAML loading. "
                "Install with: pip install pyyaml"
            ) from e

        yaml_path = Path(yaml_path)
        if not yaml_path.exists():
            raise FileNotFoundError(f"Boundary YAML file not found: {yaml_path}")

        with yaml_path.open("r", encoding="utf-8") as f:
            data = yaml.safe_load(f)

        # Validate against schema
        jsonschema.validate(instance=data, schema=schema)

        # Now load normally
        return cls.from_yaml(yaml_path)

    @classmethod
    def from_json(cls, json_path: Path | str) -> "BoundaryRegistry":
        """Load boundary registry from JSON configuration file.

        Args:
            json_path: Path to JSON configuration file

        Returns:
            BoundaryRegistry instance loaded from JSON

        Raises:
            FileNotFoundError: If json_path does not exist
        """
        json_path = Path(json_path)
        if not json_path.exists():
            raise FileNotFoundError(f"JSON file not found: {json_path}")

        with open(json_path, encoding="utf-8") as f:
            data = json.load(f)

        entries: list[BoundaryEntry] = []
        for entry_data in data.get("boundaries", []):
            entries.append(
                BoundaryEntry(
                    task_category=entry_data["task_category"],
                    action=entry_data["action"],
                    agent_id=entry_data.get("agent_id"),
                    risk_tier=entry_data.get("risk_tier", "medium"),
                    conditions=entry_data.get("conditions"),
                )
            )

        return cls(entries=entries)

    def add_entry(self, entry: BoundaryEntry) -> None:
        """Add a boundary entry to the registry.

        Args:
            entry: The BoundaryEntry to add
        """
        self.entries.append(entry)

    def get_entries_for_task(self, task_category: str) -> list[BoundaryEntry]:
        """Get all boundary entries for a specific task category.

        Args:
            task_category: The task category to filter by

        Returns:
            List of BoundaryEntry objects matching the task category
        """
        return [entry for entry in self.entries if entry.task_category == task_category]

    def get_entries_for_agent(self, agent_id: str) -> list[BoundaryEntry]:
        """Get all agent-specific boundary entries for a given agent.

        Args:
            agent_id: The agent ID to filter by

        Returns:
            List of BoundaryEntry objects specific to this agent
        """
        return [entry for entry in self.entries if entry.agent_id == agent_id]

    def to_dict(self) -> dict[str, Any]:
        """Convert boundary registry to dictionary representation.

        Returns:
            Dict with boundaries key containing all entries
        """
        return {
            "boundaries": [
                {
                    "task_category": entry.task_category,
                    "action": entry.action,
                    "agent_id": entry.agent_id,
                    "risk_tier": entry.risk_tier,
                    "conditions": entry.conditions,
                }
                for entry in self.entries
            ]
        }

    def to_json(self, json_path: Path | str, indent: int = 2) -> None:
        """Save boundary registry to JSON file.

        Args:
            json_path: Path to save JSON file
            indent: JSON indentation level (default: 2)
        """
        json_path = Path(json_path)
        with open(json_path, "w", encoding="utf-8") as f:
            json.dump(self.to_dict(), f, indent=indent, ensure_ascii=False)
