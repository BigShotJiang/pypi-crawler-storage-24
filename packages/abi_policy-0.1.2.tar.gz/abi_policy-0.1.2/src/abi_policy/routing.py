"""Deterministic model-governance routing engine.

Routes task requests to appropriate model providers based on:
- Priority-ordered rule matching (lower number = higher priority)
- Tier and capability requirements
- Project profile constraints (no_external_models, disallow_providers, require_frontier)
- Budget quota zone checks
- Fallback chain resolution

All outputs are deterministic: same inputs always produce the same routing
decision record with an identical record_hash.
"""

from __future__ import annotations

import hashlib
import json
import logging
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from abi_policy.capability_matrix import CapabilityMatrix

logger = logging.getLogger(__name__)


def _canonical_json(obj: dict[str, Any]) -> str:
    """Return canonical JSON for hashing (sorted keys, compact separators)."""
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def _sha256(data: str) -> str:
    return hashlib.sha256(data.encode("utf-8")).hexdigest()


# ------------------------------------------------------------------
# Model resolution helpers
# ------------------------------------------------------------------


@dataclass(frozen=True)
class ResolvedModel:
    """A model fully resolved from the registry."""

    provider: str
    channel: str
    model_id: str
    tier: str
    capabilities: frozenset[str]
    ru_per_1k_input: float
    ru_per_1k_output: float


def _resolve_model_ref(
    model_ref: str,
    registry: dict[str, Any],
) -> ResolvedModel | None:
    """Resolve a ``provider/channel/model`` ref to a ResolvedModel.

    Returns None if the ref cannot be found in *registry*.
    """
    parts = model_ref.split("/")
    if len(parts) != 3:
        return None
    provider_name, channel_name, model_id = parts

    providers = registry.get("providers", [])
    for provider in providers:
        if provider.get("name") != provider_name:
            continue
        for channel in provider.get("channels", []):
            if channel.get("name") != channel_name:
                continue
            for model in channel.get("models", []):
                if model.get("id") == model_id:
                    ru = model.get("ru_per_1k", {})
                    return ResolvedModel(
                        provider=provider_name,
                        channel=channel_name,
                        model_id=model_id,
                        tier=model.get("tier", "standard"),
                        capabilities=frozenset(model.get("capabilities", [])),
                        ru_per_1k_input=ru.get("input", 0.0),
                        ru_per_1k_output=ru.get("output", 0.0),
                    )
    return None


# ------------------------------------------------------------------
# Routing engine
# ------------------------------------------------------------------


class RoutingEngine:
    """Deterministic model routing engine.

    Parameters
    ----------
    registry:
        Model registry dict with ``providers[].channels[].models[]``.
    policy:
        Routing policy dict with ``rules[]`` and ``fallback_chains``.
    profile:
        Optional project profile dict with constraint overrides.
    budget_state:
        Budget state dict with at least ``zone`` and ``ru_remaining``.
    capability_matrix:
        Optional CapabilityMatrix for agent confidence-based routing.
    """

    def __init__(
        self,
        registry: dict[str, Any],
        policy: dict[str, Any],
        profile: dict[str, Any] | None,
        budget_state: dict[str, Any],
        capability_matrix: CapabilityMatrix | None = None,
    ) -> None:
        self._registry = registry
        self._policy = policy
        self._profile = profile or {}
        self._budget_state = budget_state
        self._capability_matrix = capability_matrix

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def route(self, task: dict[str, Any]) -> dict[str, Any]:
        """Return a routing-decision-record/1.0 for *task*.

        The algorithm is fully deterministic:
        1. Sort rules by (priority, rule_id)
        2. For each rule, check if task matches
        3. Resolve model_ref from registry
        4. Apply project profile constraints
        5. Check budget quota zone
        6. If primary route unavailable, try fallback chain
        7. Emit decision record

        If capability_matrix is available and task includes 'task_category',
        the best agent recommendation will be included in metadata.
        """
        reasons: list[str] = []
        sorted_rules = self._sorted_rules()

        # Get capability matrix recommendation if available
        # (recommendation will be added to decision record in _emit_decision)

        for rule in sorted_rules:
            match_result = self._task_matches_rule(task, rule)
            if not match_result.matched:
                continue

            # --- Try primary model_ref ---
            model_ref = rule.get("model_ref", "")
            resolved = _resolve_model_ref(model_ref, self._registry)

            if resolved is None:
                reasons.append(f"rule={rule['rule_id']}: model_ref '{model_ref}' not in registry")
            else:
                profile_ok, profile_reason = self._check_profile(resolved)
                if not profile_ok:
                    reasons.append(f"rule={rule['rule_id']}: {profile_reason}")
                elif not self._check_tier(task, resolved):
                    reasons.append(
                        f"rule={rule['rule_id']}: tier '{resolved.tier}' does not satisfy "
                        f"tier_required '{task.get('tier_required', 'any')}'"
                    )
                elif not self._check_capabilities(task, resolved):
                    missing = set(task.get("capabilities_required", [])) - resolved.capabilities
                    reasons.append(
                        f"rule={rule['rule_id']}: missing capabilities {sorted(missing)}"
                    )
                else:
                    # Model passes all checks — verify budget
                    ru_estimate = self._estimate_ru(task, resolved)
                    budget_ok, budget_reason = self._check_budget(ru_estimate)
                    if not budget_ok:
                        reasons.append(f"rule={rule['rule_id']}: {budget_reason}")
                    else:
                        return self._emit_decision(
                            task=task,
                            rule=rule,
                            resolved=resolved,
                            ru_estimate=ru_estimate,
                            no_route=False,
                            reasons=[],
                        )

            # --- Try fallback chain ---
            fallback_chain_id = rule.get("fallback_chain")
            if fallback_chain_id:
                fallback_result = self._try_fallback_chain(
                    task,
                    rule,
                    fallback_chain_id,
                    reasons,
                )
                if fallback_result is not None:
                    return fallback_result

        # No matching rule or all candidates disqualified
        if not reasons:
            reasons.append("no matching rule found for task")

        return self._emit_decision(
            task=task,
            rule=None,
            resolved=None,
            ru_estimate=0.0,
            no_route=True,
            reasons=reasons,
        )

    # ------------------------------------------------------------------
    # Rule sorting & matching
    # ------------------------------------------------------------------

    def _sorted_rules(self) -> list[dict[str, Any]]:
        rules = list(self._policy.get("rules", []))
        rules.sort(key=lambda r: (r.get("priority", 999), r.get("rule_id", "")))
        return rules

    @dataclass(frozen=True)
    class _MatchResult:
        matched: bool
        reason: str = ""

    def _task_matches_rule(
        self, task: dict[str, Any], rule: dict[str, Any]
    ) -> RoutingEngine._MatchResult:
        # task_type match
        rule_task_type = rule.get("task_type")
        if rule_task_type and task.get("task_type") != rule_task_type:
            return self._MatchResult(False, "task_type mismatch")

        # tier match — rule may specify tier or "any"
        rule_tier = rule.get("tier")
        if rule_tier and rule_tier != "any":
            task_tier = task.get("tier_required", "any")
            if task_tier != "any" and task_tier != rule_tier:
                return self._MatchResult(False, "tier mismatch")

        # constraint-based rules (e.g. ["no_external_models"])
        rule_constraints = rule.get("constraints", [])
        if rule_constraints:
            profile_constraints = self._active_constraints()
            if not all(c in profile_constraints for c in rule_constraints):
                return self._MatchResult(False, "constraint not active")

        return self._MatchResult(True)

    # ------------------------------------------------------------------
    # Constraint & profile helpers
    # ------------------------------------------------------------------

    def _active_constraints(self) -> set[str]:
        constraints: set[str] = set()
        if self._profile.get("no_external_models"):
            constraints.add("no_external_models")
        if self._profile.get("require_frontier"):
            constraints.add("require_frontier")
        for p in self._profile.get("disallow_providers", []):
            constraints.add(f"disallow:{p}")
        return constraints

    def _check_profile(self, resolved: ResolvedModel) -> tuple[bool, str]:
        # no_external_models — only local channel allowed
        if self._profile.get("no_external_models") and resolved.channel != "local":
            return False, "no_external_models: non-local channel rejected"

        # disallow_providers
        disallowed = self._profile.get("disallow_providers", [])
        if resolved.provider in disallowed:
            return False, f"disallow_providers: provider '{resolved.provider}' blocked"

        # require_frontier
        if self._profile.get("require_frontier") and resolved.tier != "frontier":
            return False, "require_frontier: non-frontier model rejected"

        return True, ""

    def _check_tier(self, task: dict[str, Any], resolved: ResolvedModel) -> bool:
        tier_required = task.get("tier_required", "any")
        if tier_required == "any":
            return True
        return resolved.tier == tier_required

    def _check_capabilities(self, task: dict[str, Any], resolved: ResolvedModel) -> bool:
        required = set(task.get("capabilities_required", []))
        return required.issubset(resolved.capabilities)

    # ------------------------------------------------------------------
    # Budget helpers
    # ------------------------------------------------------------------

    def _estimate_ru(self, task: dict[str, Any], resolved: ResolvedModel) -> float:
        input_tokens = task.get("estimated_input_tokens", 0)
        output_tokens = task.get("estimated_output_tokens", 0)
        ru = (input_tokens / 1000) * resolved.ru_per_1k_input + (
            output_tokens / 1000
        ) * resolved.ru_per_1k_output
        return round(ru, 6)

    def _check_budget(self, ru_estimate: float) -> tuple[bool, str]:
        zone = self._budget_state.get("zone", "GREEN")
        if zone == "EXHAUSTED":
            return False, "quota zone EXHAUSTED — cannot route"
        if zone == "RED":
            logger.warning("Budget quota zone is RED (ru_estimate=%.4f)", ru_estimate)
        remaining = self._budget_state.get("ru_remaining", float("inf"))
        if ru_estimate > remaining:
            return False, f"ru_estimate {ru_estimate} exceeds remaining {remaining}"
        return True, ""

    # ------------------------------------------------------------------
    # Fallback chain
    # ------------------------------------------------------------------

    def _try_fallback_chain(
        self,
        task: dict[str, Any],
        rule: dict[str, Any],
        chain_id: str,
        reasons: list[str],
    ) -> dict[str, Any] | None:
        chains = self._policy.get("fallback_chains", {})
        chain = chains.get(chain_id, [])
        for fb_ref in chain:
            resolved = _resolve_model_ref(fb_ref, self._registry)
            if resolved is None:
                reasons.append(f"fallback '{fb_ref}': not in registry")
                continue

            profile_ok, profile_reason = self._check_profile(resolved)
            if not profile_ok:
                reasons.append(f"fallback '{fb_ref}': {profile_reason}")
                continue

            if not self._check_tier(task, resolved):
                reasons.append(
                    f"fallback '{fb_ref}': tier '{resolved.tier}' does not satisfy "
                    f"tier_required '{task.get('tier_required', 'any')}'"
                )
                continue

            if not self._check_capabilities(task, resolved):
                missing = set(task.get("capabilities_required", [])) - resolved.capabilities
                reasons.append(f"fallback '{fb_ref}': missing capabilities {sorted(missing)}")
                continue

            ru_estimate = self._estimate_ru(task, resolved)
            budget_ok, budget_reason = self._check_budget(ru_estimate)
            if not budget_ok:
                reasons.append(f"fallback '{fb_ref}': {budget_reason}")
                continue

            return self._emit_decision(
                task=task,
                rule=rule,
                resolved=resolved,
                ru_estimate=ru_estimate,
                no_route=False,
                reasons=[],
                via_fallback=chain_id,
            )

        return None

    # ------------------------------------------------------------------
    # Decision record emission
    # ------------------------------------------------------------------

    def _emit_decision(
        self,
        *,
        task: dict[str, Any],
        rule: dict[str, Any] | None,
        resolved: ResolvedModel | None,
        ru_estimate: float,
        no_route: bool,
        reasons: list[str],
        via_fallback: str | None = None,
    ) -> dict[str, Any]:
        record: dict[str, Any] = {
            "schema_version": "routing-decision-record/1.0",
            "task": task,
            "no_route": no_route,
        }

        if no_route:
            record["reasons"] = reasons
        else:
            record["rule_id"] = rule["rule_id"] if rule else ""
            record["model"] = {
                "provider": resolved.provider if resolved else "",
                "channel": resolved.channel if resolved else "",
                "model_id": resolved.model_id if resolved else "",
                "tier": resolved.tier if resolved else "",
                "capabilities": sorted(resolved.capabilities) if resolved else [],
            }
            record["ru_estimate"] = ru_estimate
            record["budget_zone"] = self._budget_state.get("zone", "GREEN")
            if via_fallback:
                record["via_fallback"] = via_fallback

        # Add capability matrix metadata if available
        if self._capability_matrix and "task_category" in task:
            task_category = task["task_category"]
            recommended_agent = self._capability_matrix.get_best_agent(task_category)
            if recommended_agent:
                record["capability_metadata"] = {
                    "recommended_agent": recommended_agent,
                    "confidence": self._capability_matrix.get_confidence(
                        recommended_agent, task_category
                    ),
                }

        # Compute record_hash over everything except the hash itself
        canonical = _canonical_json(record)
        record["record_hash"] = _sha256(canonical)

        return record
