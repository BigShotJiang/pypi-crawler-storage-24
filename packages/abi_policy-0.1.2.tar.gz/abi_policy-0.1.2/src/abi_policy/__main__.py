"""Allow running as python -m abi_policy.cli"""
import sys

from abi_policy.cli import main

sys.exit(main())
