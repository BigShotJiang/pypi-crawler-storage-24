"""Cost Envelope Policy — budget-drift detection for orchestrator runs.

Compares a baseline BudgetSnapshot against a current snapshot, evaluating
whether token consumption and risk/policy level changes fall within the
configured envelope thresholds.
"""
from __future__ import annotations

import json
import math
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

# ---------------------------------------------------------------------------
# Status ordering
# ---------------------------------------------------------------------------

_STATUS_ORDER: dict[str, int] = {"pass": 0, "warn": 1, "fail": 2}
_RISK_ORDER: dict[str, int] = {"low": 0, "medium": 1, "high": 2}

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def parse_percentage(value: str | float | int) -> float:
    """Normalise a percentage value to a 0-1 float.

    Accepted forms:
      "10%"  -> 0.10
      "0.15" -> 0.15
      0.10   -> 0.10
      10     -> 0.10  (integers >= 1 are treated as whole-number percents)
    """
    if isinstance(value, str):
        value = value.strip()
        if value.endswith("%"):
            return float(value[:-1]) / 100.0
        f = float(value)
        if f >= 1.0:
            return f / 100.0
        return f
    if isinstance(value, int):
        if value >= 1:
            return value / 100.0
        return float(value)
    # float
    if value >= 1.0:
        return value / 100.0
    return float(value)


def _parse_simple_yaml(text: str) -> dict[str, str]:
    """Minimal flat YAML parser (key: value).  No nesting, no lists."""
    result: dict[str, str] = {}
    for line in text.splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        if ":" not in stripped:
            continue
        key, _, val = stripped.partition(":")
        key = key.strip()
        val = val.strip()
        # Strip inline comments
        if " #" in val:
            val = val[: val.index(" #")].strip()
        result[key] = val
    return result


def _parse_bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        return value.lower() in ("true", "yes", "1")
    return bool(value)


# ---------------------------------------------------------------------------
# Dataclasses
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class CostEnvelopeConfig:
    """Thresholds for cost-envelope evaluation."""

    max_total_tokens_delta: float
    max_single_prompt_delta: float
    allow_risk_escalation: bool = False
    allow_policy_escalation: bool = False

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class BudgetSnapshot:
    """Point-in-time snapshot of token budget consumption."""

    total_tokens: int
    prompt_tokens: dict[str, int] = field(default_factory=dict)
    risk_level: str = "low"
    policy_level: str = "default"


@dataclass(frozen=True)
class DeltaDetail:
    """One delta comparison between baseline and current."""

    field: str
    baseline_value: int
    current_value: int
    delta_pct: float
    threshold_pct: float
    status: str  # "pass" | "warn" | "fail"


@dataclass(frozen=True)
class CostEnvelopeResult:
    """Aggregate result of a cost-envelope evaluation."""

    status: str  # "PASS" | "WARN" | "FAIL"
    deltas: list[DeltaDetail]
    risk_escalation_blocked: bool = False
    policy_escalation_blocked: bool = False
    explanation: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": "cost-envelope-result/1.0",
            "status": self.status,
            "deltas": [asdict(d) for d in self.deltas],
            "risk_escalation_blocked": self.risk_escalation_blocked,
            "policy_escalation_blocked": self.policy_escalation_blocked,
            "explanation": self.explanation,
        }

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), sort_keys=True, ensure_ascii=False)

    def to_decision_response(self) -> Any:
        """Map envelope result to a DecisionResponse (lazy import)."""
        from abi_policy.models import DecisionRequest, DecisionResponse

        decision_map = {"PASS": "allow", "FAIL": "deny", "WARN": "require_approval"}
        decision = decision_map.get(self.status, "deny")

        request = DecisionRequest(
            action="cost_envelope_check",
            resource="budget_snapshot",
        )
        return DecisionResponse(
            decision=decision,
            reason_code=f"COST_ENVELOPE_{self.status}",
            explanation=self.explanation,
            request=request,
            policy_id="cost-envelope-policy",
        )


# ---------------------------------------------------------------------------
# Config loading / validation
# ---------------------------------------------------------------------------


def validate_cost_envelope_config(data: dict[str, Any]) -> list[str]:
    """Return a list of error messages for an invalid config dict."""
    errors: list[str] = []
    if "max_total_tokens_delta" not in data:
        errors.append("Missing required field: max_total_tokens_delta")
    if "max_single_prompt_delta" not in data:
        errors.append("Missing required field: max_single_prompt_delta")
    return errors


def load_cost_envelope(path: Path) -> CostEnvelopeConfig:
    """Load a CostEnvelopeConfig from a simple YAML file."""
    text = path.read_text(encoding="utf-8")
    raw = _parse_simple_yaml(text)

    errors = validate_cost_envelope_config(raw)
    if errors:
        raise ValueError(
            f"Invalid cost-envelope config at {path}: {'; '.join(errors)}"
        )

    return CostEnvelopeConfig(
        max_total_tokens_delta=parse_percentage(raw["max_total_tokens_delta"]),
        max_single_prompt_delta=parse_percentage(raw["max_single_prompt_delta"]),
        allow_risk_escalation=_parse_bool(raw.get("allow_risk_escalation", False)),
        allow_policy_escalation=_parse_bool(
            raw.get("allow_policy_escalation", False)
        ),
    )


# ---------------------------------------------------------------------------
# Evaluation
# ---------------------------------------------------------------------------


def _compute_delta_detail(
    field_name: str,
    baseline_value: int,
    current_value: int,
    threshold_pct: float,
) -> DeltaDetail:
    """Compute a single DeltaDetail for a given metric."""
    if baseline_value == 0:
        delta_pct = 0.0 if current_value == 0 else math.inf
    else:
        delta_pct = abs(current_value - baseline_value) / baseline_value

    if delta_pct > threshold_pct:
        status = "fail"
    elif delta_pct > threshold_pct * 0.8:
        status = "warn"
    else:
        status = "pass"

    return DeltaDetail(
        field=field_name,
        baseline_value=baseline_value,
        current_value=current_value,
        delta_pct=delta_pct,
        threshold_pct=threshold_pct,
        status=status,
    )


def _escalate_status(current: str, new: str) -> str:
    """Return the more severe of two statuses."""
    if _STATUS_ORDER.get(new, 0) > _STATUS_ORDER.get(current, 0):
        return new
    return current


def _build_explanation(
    status: str,
    deltas: list[DeltaDetail],
    risk_blocked: bool,
    policy_blocked: bool,
) -> str:
    """Build a human-readable explanation string."""
    parts: list[str] = []
    for d in deltas:
        if d.status != "pass":
            pct_str = f"{d.delta_pct:.1%}" if not math.isinf(d.delta_pct) else "inf"
            parts.append(
                f"{d.field}: {d.status.upper()} "
                f"(delta={pct_str}, threshold={d.threshold_pct:.1%})"
            )
    if risk_blocked:
        parts.append("Risk escalation blocked")
    if policy_blocked:
        parts.append("Policy escalation blocked")
    if not parts:
        return f"Cost envelope check {status}: all deltas within thresholds."
    return f"Cost envelope check {status}: " + "; ".join(parts) + "."


def evaluate_cost_envelope(
    config: CostEnvelopeConfig,
    baseline: BudgetSnapshot,
    current: BudgetSnapshot,
) -> CostEnvelopeResult:
    """Evaluate current snapshot against baseline using config thresholds."""
    deltas: list[DeltaDetail] = []
    overall_status = "pass"

    # 1. Total tokens delta
    total_delta = _compute_delta_detail(
        "total_tokens",
        baseline.total_tokens,
        current.total_tokens,
        config.max_total_tokens_delta,
    )
    deltas.append(total_delta)
    overall_status = _escalate_status(overall_status, total_delta.status)

    # 2. Per-prompt deltas (sorted union of prompt ids)
    all_prompt_ids = sorted(
        set(baseline.prompt_tokens.keys()) | set(current.prompt_tokens.keys())
    )
    for prompt_id in all_prompt_ids:
        b_val = baseline.prompt_tokens.get(prompt_id, 0)
        c_val = current.prompt_tokens.get(prompt_id, 0)
        d = _compute_delta_detail(
            f"prompt:{prompt_id}",
            b_val,
            c_val,
            config.max_single_prompt_delta,
        )
        deltas.append(d)
        overall_status = _escalate_status(overall_status, d.status)

    # 3. Risk escalation check
    risk_blocked = False
    if not config.allow_risk_escalation:
        b_risk = _RISK_ORDER.get(baseline.risk_level, 0)
        c_risk = _RISK_ORDER.get(current.risk_level, 0)
        if c_risk > b_risk:
            risk_blocked = True
            overall_status = _escalate_status(overall_status, "fail")

    # 4. Policy escalation check
    policy_blocked = False
    if not config.allow_policy_escalation and current.policy_level != baseline.policy_level:
        policy_blocked = True
        overall_status = _escalate_status(overall_status, "fail")

    # Uppercase status for result
    status_upper = overall_status.upper()

    explanation = _build_explanation(status_upper, deltas, risk_blocked, policy_blocked)

    return CostEnvelopeResult(
        status=status_upper,
        deltas=deltas,
        risk_escalation_blocked=risk_blocked,
        policy_escalation_blocked=policy_blocked,
        explanation=explanation,
    )
