"""Policy bundle loader and validator."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

_BUNDLES_DIR = Path(__file__).resolve().parent.parent.parent / "policies"

REQUIRED_RULE_KEYS = {
    "tools",
    "paths",
    "models",
    "budget",
    "escalation",
}

REQUIRED_TOOLS_KEYS = {"allow", "deny"}
REQUIRED_PATHS_KEYS = {"deny_patterns"}
REQUIRED_MODELS_KEYS = {"allow"}
REQUIRED_BUDGET_KEYS = {"max_tokens_per_run", "max_tokens_per_step"}
REQUIRED_ESCALATION_KEYS = {"risky_actions"}


def list_bundles(bundles_dir: Path | None = None) -> list[str]:
    """List available policy bundle names."""
    d = bundles_dir or _BUNDLES_DIR
    if not d.is_dir():
        return []
    return sorted(
        p.name for p in d.iterdir()
        if p.is_dir() and (p / "policy.json").exists()
    )


def load_bundle(name: str, bundles_dir: Path | None = None) -> dict[str, Any]:
    """Load a named policy bundle."""
    d = bundles_dir or _BUNDLES_DIR
    policy_path = d / name / "policy.json"
    if not policy_path.exists():
        raise FileNotFoundError(f"Policy bundle not found: {name} (looked in {d})")
    with open(policy_path) as f:
        return json.load(f)


def validate_bundle(bundle: dict[str, Any]) -> list[str]:
    """Validate a policy bundle structure. Returns list of error messages (empty = valid)."""
    errors: list[str] = []

    if "bundle_id" not in bundle:
        errors.append("Missing required field: bundle_id")
    if "version" not in bundle:
        errors.append("Missing required field: version")
    if "rules" not in bundle:
        errors.append("Missing required field: rules")
        return errors

    rules = bundle["rules"]
    for key in REQUIRED_RULE_KEYS:
        if key not in rules:
            errors.append(f"Missing required rule section: {key}")

    if "tools" in rules:
        for k in REQUIRED_TOOLS_KEYS:
            if k not in rules["tools"]:
                errors.append(f"Missing tools.{k}")

    if "paths" in rules:
        for k in REQUIRED_PATHS_KEYS:
            if k not in rules["paths"]:
                errors.append(f"Missing paths.{k}")

    if "models" in rules:
        for k in REQUIRED_MODELS_KEYS:
            if k not in rules["models"]:
                errors.append(f"Missing models.{k}")

    if "budget" in rules:
        for k in REQUIRED_BUDGET_KEYS:
            if k not in rules["budget"]:
                errors.append(f"Missing budget.{k}")

    if "escalation" in rules:
        for k in REQUIRED_ESCALATION_KEYS:
            if k not in rules["escalation"]:
                errors.append(f"Missing escalation.{k}")

    return errors
