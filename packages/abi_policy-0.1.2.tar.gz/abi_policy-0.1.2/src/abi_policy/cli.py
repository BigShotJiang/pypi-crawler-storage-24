"""CLI interface for abi-policy.

Usage:
    python -m abi_policy.cli evaluate --policy <bundle> --input <json> --out <json>
    python -m abi_policy.cli explain --policy <bundle> --input <json>
    python -m abi_policy.cli validate-bundle --policy <bundle>
    python -m abi_policy.cli cost-envelope --envelope <yaml> --baseline <json> --current <json>
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from abi_policy.bundles import list_bundles, load_bundle, validate_bundle
from abi_policy.cost_envelope import (
    BudgetSnapshot,
    evaluate_cost_envelope,
    load_cost_envelope,
)
from abi_policy.engine import PolicyEngine
from abi_policy.models import DecisionRequest


def cmd_evaluate(args: argparse.Namespace) -> int:
    bundle = load_bundle(args.policy, bundles_dir=args.bundles_dir)
    engine = PolicyEngine(bundle)

    with open(args.input) as f:
        raw = json.load(f)

    # Support single request or list of requests
    requests = raw if isinstance(raw, list) else [raw]

    results = []
    for req_data in requests:
        request = DecisionRequest(
            action=req_data["action"],
            resource=req_data["resource"],
            context=req_data.get("context", {}),
            run_id=req_data.get("run_id", ""),
            timestamp=req_data.get("timestamp", ""),
        )
        response = engine.evaluate(request)
        results.append(response.to_dict())

    output = json.dumps(results, indent=2, ensure_ascii=False, sort_keys=True)

    if args.out:
        Path(args.out).parent.mkdir(parents=True, exist_ok=True)
        with open(args.out, "w") as f:
            f.write(output + "\n")
        print(f"Wrote {len(results)} decision(s) to {args.out}")
    else:
        print(output)

    return 0


def cmd_explain(args: argparse.Namespace) -> int:
    bundle = load_bundle(args.policy, bundles_dir=args.bundles_dir)
    engine = PolicyEngine(bundle)

    with open(args.input) as f:
        raw = json.load(f)

    requests = raw if isinstance(raw, list) else [raw]

    for i, req_data in enumerate(requests):
        request = DecisionRequest(
            action=req_data["action"],
            resource=req_data["resource"],
            context=req_data.get("context", {}),
            run_id=req_data.get("run_id", ""),
            timestamp=req_data.get("timestamp", ""),
        )
        response = engine.evaluate(request)

        if i > 0:
            print("---")
        print(f"Action:    {request.action}")
        print(f"Resource:  {request.resource}")
        print(f"Decision:  {response.decision}")
        print(f"Reason:    [{response.reason_code}] {response.explanation}")
        print(f"Policy:    {response.policy_id}")

    return 0


def cmd_validate_bundle(args: argparse.Namespace) -> int:
    bundle = load_bundle(args.policy, bundles_dir=args.bundles_dir)
    errors = validate_bundle(bundle)

    if errors:
        print(f"Bundle '{args.policy}' has {len(errors)} validation error(s):")
        for err in errors:
            print(f"  - {err}")
        return 1

    print(f"Bundle '{args.policy}' is valid.")
    return 0


def cmd_list(args: argparse.Namespace) -> int:
    bundles = list_bundles(bundles_dir=args.bundles_dir)
    if not bundles:
        print("No policy bundles found.")
        return 1
    for name in bundles:
        print(f"  {name}")
    return 0


def cmd_cost_envelope(args: argparse.Namespace) -> int:
    """Evaluate a cost-envelope policy against baseline/current snapshots."""
    config = load_cost_envelope(Path(args.envelope))

    with open(args.baseline) as f:
        raw_baseline = json.load(f)
    with open(args.current) as f:
        raw_current = json.load(f)

    baseline = BudgetSnapshot(
        total_tokens=raw_baseline["total_tokens"],
        prompt_tokens=raw_baseline.get("prompt_tokens", {}),
        risk_level=raw_baseline.get("risk_level", "low"),
        policy_level=raw_baseline.get("policy_level", "default"),
    )
    current = BudgetSnapshot(
        total_tokens=raw_current["total_tokens"],
        prompt_tokens=raw_current.get("prompt_tokens", {}),
        risk_level=raw_current.get("risk_level", "low"),
        policy_level=raw_current.get("policy_level", "default"),
    )

    result = evaluate_cost_envelope(config, baseline, current)
    output = result.to_json()

    if args.out:
        Path(args.out).parent.mkdir(parents=True, exist_ok=True)
        with open(args.out, "w") as f:
            f.write(output + "\n")
        print(f"Wrote cost-envelope result to {args.out}")
    else:
        print(output)

    return 0 if result.status == "PASS" else 1


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="abi-policy",
        description="ABI Policy Engine — deterministic policy evaluation",
    )
    parser.add_argument(
        "--bundles-dir",
        type=Path,
        default=None,
        help="Override policy bundles directory",
    )

    sub = parser.add_subparsers(dest="command", required=True)

    # evaluate
    p_eval = sub.add_parser("evaluate", help="Evaluate a decision request")
    p_eval.add_argument("--policy", required=True, help="Policy bundle name")
    p_eval.add_argument("--input", required=True, help="Input JSON file (DecisionRequest)")
    p_eval.add_argument("--out", default=None, help="Output JSON file (DecisionResponse)")

    # explain
    p_explain = sub.add_parser("explain", help="Explain a policy decision in human-readable form")
    p_explain.add_argument("--policy", required=True, help="Policy bundle name")
    p_explain.add_argument("--input", required=True, help="Input JSON file")

    # validate-bundle
    p_validate = sub.add_parser("validate-bundle", help="Validate a policy bundle")
    p_validate.add_argument("--policy", required=True, help="Policy bundle name")

    # list
    sub.add_parser("list", help="List available policy bundles")

    # cost-envelope
    p_ce = sub.add_parser("cost-envelope", help="Evaluate a cost-envelope policy")
    p_ce.add_argument("--envelope", required=True, help="Path to cost-envelope YAML config")
    p_ce.add_argument("--baseline", required=True, help="Path to baseline BudgetSnapshot JSON")
    p_ce.add_argument("--current", required=True, help="Path to current BudgetSnapshot JSON")
    p_ce.add_argument("--out", default=None, help="Output JSON file for result")

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    if args.bundles_dir:
        args.bundles_dir = Path(args.bundles_dir)

    commands = {
        "evaluate": cmd_evaluate,
        "explain": cmd_explain,
        "validate-bundle": cmd_validate_bundle,
        "list": cmd_list,
        "cost-envelope": cmd_cost_envelope,
    }

    return commands[args.command](args)


if __name__ == "__main__":
    sys.exit(main())
