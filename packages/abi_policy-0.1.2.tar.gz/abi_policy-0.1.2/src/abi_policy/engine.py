"""Deterministic policy evaluation engine.

Evaluates a DecisionRequest against a loaded policy bundle
and returns a DecisionResponse with allow/deny/require_approval.
"""
from __future__ import annotations

import fnmatch
import posixpath
from datetime import UTC, datetime
from typing import Any

from abi_policy.models import DecisionRequest, DecisionResponse


class PolicyEngine:
    """Deterministic policy evaluator."""

    def __init__(self, bundle: dict[str, Any]) -> None:
        self.bundle = bundle
        self.bundle_id = bundle.get("bundle_id", "unknown")
        self.rules = bundle.get("rules", {})

    def evaluate(self, request: DecisionRequest) -> DecisionResponse:
        """Evaluate a request against the loaded policy bundle.

        Evaluation order (first match wins):
        1. Check escalation rules (risky actions -> require_approval or deny)
        2. Check action-specific rules (tool_call, file_write, model_call)
        3. Check budget constraints
        4. Default: allow
        """
        # Capture a single timestamp for deterministic output within one call
        now = datetime.now(UTC).isoformat()

        # 1. Check escalation rules
        escalation = self.rules.get("escalation", {})
        risky_actions = escalation.get("risky_actions", {})

        action_key = f"{request.action}:{request.resource}"
        for pattern, disposition in sorted(risky_actions.items()):
            if fnmatch.fnmatch(action_key, pattern):
                return DecisionResponse(
                    decision=disposition,  # "require_approval" or "deny"
                    reason_code="ESCALATION_MATCH",
                    explanation=f"Action '{action_key}' matches escalation pattern '{pattern}'",
                    request=request,
                    policy_id=self.bundle_id,
                    timestamp=now,
                )

        # 2. Action-specific checks
        if request.action == "tool_call":
            return self._evaluate_tool_call(request, now)
        elif request.action == "file_write":
            return self._evaluate_file_write(request, now)
        elif request.action == "model_call":
            return self._evaluate_model_call(request, now)
        elif request.action == "override":
            return self._evaluate_override(request, now)

        # 3. Budget check (if context has token_count)
        budget_result = self._check_budget(request, now)
        if budget_result is not None:
            return budget_result

        # 4. Default: allow
        return DecisionResponse(
            decision="allow",
            reason_code="DEFAULT_ALLOW",
            explanation="No matching deny or escalation rule",
            request=request,
            policy_id=self.bundle_id,
            timestamp=now,
        )

    def _evaluate_tool_call(self, request: DecisionRequest, now: str) -> DecisionResponse:
        tools = self.rules.get("tools", {})
        allow_list = tools.get("allow", [])
        deny_list = tools.get("deny", [])
        tool_name = request.resource

        # Deny list takes precedence
        for pattern in deny_list:
            if fnmatch.fnmatch(tool_name, pattern):
                return DecisionResponse(
                    decision="deny",
                    reason_code="TOOL_DENIED",
                    explanation=f"Tool '{tool_name}' matches deny pattern '{pattern}'",
                    request=request,
                    policy_id=self.bundle_id,
                    timestamp=now,
                )

        # If allow list is non-empty, tool must match
        if allow_list and not any(fnmatch.fnmatch(tool_name, p) for p in allow_list):
            return DecisionResponse(
                decision="deny",
                reason_code="TOOL_NOT_ALLOWED",
                explanation=f"Tool '{tool_name}' not in allow list",
                request=request,
                policy_id=self.bundle_id,
                timestamp=now,
            )

        return DecisionResponse(
            decision="allow",
            reason_code="TOOL_ALLOWED",
            explanation=f"Tool '{tool_name}' is permitted",
            request=request,
            policy_id=self.bundle_id,
            timestamp=now,
        )

    def _evaluate_file_write(self, request: DecisionRequest, now: str) -> DecisionResponse:
        paths = self.rules.get("paths", {})
        deny_patterns = paths.get("deny_patterns", [])
        file_path = request.resource

        # Normalize path separators
        normalized = file_path.replace("\\", "/")

        # Check for path traversal
        if ".." in normalized.split("/"):
            return DecisionResponse(
                decision="deny",
                reason_code="PATH_TRAVERSAL",
                explanation=f"Path '{file_path}' contains path traversal (..) component",
                request=request,
                policy_id=self.bundle_id,
                timestamp=now,
            )

        # Check absolute paths (cross-platform: detect both Unix / and Windows C:\ style)
        if posixpath.isabs(normalized) or (len(normalized) >= 2 and normalized[1] == ":"):
            return DecisionResponse(
                decision="deny",
                reason_code="ABSOLUTE_PATH",
                explanation=f"Absolute paths are not allowed: '{file_path}'",
                request=request,
                policy_id=self.bundle_id,
                timestamp=now,
            )

        # Check deny patterns
        for pattern in deny_patterns:
            if fnmatch.fnmatch(normalized, pattern):
                return DecisionResponse(
                    decision="deny",
                    reason_code="PATH_DENIED",
                    explanation=f"Path '{file_path}' matches deny pattern '{pattern}'",
                    request=request,
                    policy_id=self.bundle_id,
                    timestamp=now,
                )

        return DecisionResponse(
            decision="allow",
            reason_code="PATH_ALLOWED",
            explanation=f"Path '{file_path}' is permitted",
            request=request,
            policy_id=self.bundle_id,
            timestamp=now,
        )

    def _evaluate_model_call(self, request: DecisionRequest, now: str) -> DecisionResponse:
        models = self.rules.get("models", {})
        allow_list = models.get("allow", [])
        model_name = request.resource

        if allow_list and model_name not in allow_list:
            return DecisionResponse(
                decision="deny",
                reason_code="MODEL_NOT_ALLOWED",
                explanation=f"Model '{model_name}' not in allow list: {allow_list}",
                request=request,
                policy_id=self.bundle_id,
                timestamp=now,
            )

        # Also check budget for model calls
        budget_result = self._check_budget(request, now)
        if budget_result is not None:
            return budget_result

        return DecisionResponse(
            decision="allow",
            reason_code="MODEL_ALLOWED",
            explanation=f"Model '{model_name}' is permitted",
            request=request,
            policy_id=self.bundle_id,
            timestamp=now,
        )

    def _evaluate_override(self, request: DecisionRequest, now: str) -> DecisionResponse:
        escalation = self.rules.get("escalation", {})
        override_policy = escalation.get("override_policy", "require_approval")

        return DecisionResponse(
            decision=override_policy,
            reason_code="OVERRIDE_POLICY",
            explanation=f"Override requests follow policy: {override_policy}",
            request=request,
            policy_id=self.bundle_id,
            timestamp=now,
        )

    def _check_budget(self, request: DecisionRequest, now: str) -> DecisionResponse | None:
        budget = self.rules.get("budget", {})
        token_count = request.context.get("token_count")
        scope = request.context.get("budget_scope", "step")

        if token_count is None:
            return None

        if scope == "run":
            limit = budget.get("max_tokens_per_run", float("inf"))
        else:
            limit = budget.get("max_tokens_per_step", float("inf"))

        if token_count > limit:
            return DecisionResponse(
                decision="deny",
                reason_code="BUDGET_EXCEEDED",
                explanation=f"Token count {token_count} exceeds {scope} limit of {limit}",
                request=request,
                policy_id=self.bundle_id,
                timestamp=now,
            )

        return None
