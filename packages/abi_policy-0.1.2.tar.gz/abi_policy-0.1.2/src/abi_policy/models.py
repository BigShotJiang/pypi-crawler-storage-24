"""Internal models for policy evaluation.

TODO: Propose abi-core schemas:
  - decision-request/1.0 (see docs/schema_proposals/decision_request_response.md)
  - decision-response/1.0
"""
from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from datetime import UTC, datetime
from typing import Any


@dataclass(frozen=True)
class DecisionRequest:
    """A request to evaluate a policy decision."""
    action: str  # e.g. "tool_call", "file_write", "model_call", "override"
    resource: str  # e.g. tool name, file path, model name
    context: dict[str, Any] = field(default_factory=dict)
    run_id: str = ""
    timestamp: str = ""

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        if not d["timestamp"]:
            d["timestamp"] = datetime.now(UTC).isoformat()
        return d


@dataclass(frozen=True)
class DecisionResponse:
    """Result of a policy evaluation."""
    decision: str  # "allow" | "deny" | "require_approval"
    reason_code: str
    explanation: str
    request: DecisionRequest
    policy_id: str = ""
    timestamp: str = ""

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        if not d["timestamp"]:
            d["timestamp"] = datetime.now(UTC).isoformat()
        return d

    def to_ndjson_line(self) -> str:
        """Emit as a Tier-2 policy decision NDJSON line (tier2-policy-decision/1.0)."""
        record = {
            "schema_version": "tier2-policy-decision/1.0",
            "run_id": self.request.run_id or "00000000",
            "policy_id": self.policy_id or "abi-policy",
            "decision": self.decision if self.decision != "require_approval" else "escalate",
            "decided_at": self.timestamp or datetime.now(UTC).isoformat(),
            "reason": self.explanation,
            "context": {
                "action": self.request.action,
                "resource": self.request.resource,
                "reason_code": self.reason_code,
                **self.request.context,
            },
        }
        return json.dumps(record, ensure_ascii=False, sort_keys=True)
