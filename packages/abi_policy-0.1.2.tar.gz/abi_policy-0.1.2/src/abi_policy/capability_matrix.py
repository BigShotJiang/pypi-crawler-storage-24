"""Agent Capability Matrix — per-agent, per-task confidence scoring.

Tracks confidence scores for each agent on different task categories,
enabling intelligent agent selection and routing based on historical
performance and known failure patterns.
"""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any


@dataclass
class AgentProfile:
    """Profile for a single agent with confidence scores by task category.

    Matches agent_profile.schema.json structure.

    Attributes:
        agent_id: Unique identifier for the agent (e.g., "claude_code", "codex")
        agent_version: Version string of the agent (e.g., "claude-sonnet-4")
        confidence_by_task: Dict mapping task categories to confidence scores (0.0-1.0)
        failure_patterns: List of known failure patterns for this agent
        updated_at: ISO 8601 timestamp of last profile update
    """

    agent_id: str
    agent_version: str
    confidence_by_task: dict[str, float] = field(default_factory=dict)
    failure_patterns: list[str] = field(default_factory=list)
    updated_at: str = ""

    def __post_init__(self) -> None:
        """Ensure updated_at is set."""
        if not self.updated_at:
            object.__setattr__(self, "updated_at", datetime.now(UTC).isoformat())

    def get_confidence(self, task_category: str) -> float:
        """Get confidence score for a task category.

        Returns:
            Confidence score (0.0-1.0), or 0.0 if task category is unknown.
        """
        return self.confidence_by_task.get(task_category, 0.0)

    def update_confidence(self, task_category: str, new_confidence: float) -> None:
        """Update confidence score for a task category.

        Args:
            task_category: The task category to update
            new_confidence: New confidence value (0.0-1.0)
        """
        if not 0.0 <= new_confidence <= 1.0:
            raise ValueError(f"Confidence must be between 0.0 and 1.0, got {new_confidence}")

        self.confidence_by_task[task_category] = new_confidence
        object.__setattr__(self, "updated_at", datetime.now(UTC).isoformat())

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary representation."""
        return asdict(self)


class CapabilityMatrix:
    """Manages agent capability profiles and provides routing recommendations.

    The capability matrix tracks confidence scores for multiple agents across
    different task categories, enabling intelligent agent selection based on
    historical performance data.

    Attributes:
        profiles: Dict mapping agent_id to AgentProfile
    """

    def __init__(self, profiles: dict[str, AgentProfile] | None = None) -> None:
        """Initialize capability matrix.

        Args:
            profiles: Optional dict of agent_id -> AgentProfile
        """
        self.profiles: dict[str, AgentProfile] = profiles or {}

    @classmethod
    def from_yaml(cls, yaml_path: Path | str) -> CapabilityMatrix:
        """Load capability matrix from YAML seed file.

        Expected YAML structure:
            profiles:
              agent_id:
                agent_version: "version-string"
                confidence_by_task:
                  task_category: 0.85
                failure_patterns: [pattern1, pattern2]

        Args:
            yaml_path: Path to YAML seed file

        Returns:
            CapabilityMatrix instance loaded from YAML

        Raises:
            ImportError: If PyYAML is not installed
            FileNotFoundError: If yaml_path does not exist
        """
        try:
            import yaml
        except ImportError as e:
            raise ImportError(
                "PyYAML is required for YAML loading. Install with: pip install pyyaml"
            ) from e

        yaml_path = Path(yaml_path)
        if not yaml_path.exists():
            raise FileNotFoundError(f"YAML file not found: {yaml_path}")

        with open(yaml_path, encoding="utf-8") as f:
            data = yaml.safe_load(f)

        profiles: dict[str, AgentProfile] = {}
        for agent_id, profile_data in data.get("profiles", {}).items():
            profiles[agent_id] = AgentProfile(
                agent_id=agent_id,
                agent_version=profile_data.get("agent_version", ""),
                confidence_by_task=profile_data.get("confidence_by_task", {}),
                failure_patterns=profile_data.get("failure_patterns", []),
                updated_at=profile_data.get("updated_at", ""),
            )

        return cls(profiles=profiles)

    @classmethod
    def from_json(cls, json_path: Path | str) -> CapabilityMatrix:
        """Load capability matrix from JSON file.

        Args:
            json_path: Path to JSON file

        Returns:
            CapabilityMatrix instance loaded from JSON
        """
        json_path = Path(json_path)
        with open(json_path, encoding="utf-8") as f:
            data = json.load(f)

        profiles: dict[str, AgentProfile] = {}
        for agent_id, profile_data in data.get("profiles", {}).items():
            profiles[agent_id] = AgentProfile(
                agent_id=agent_id,
                agent_version=profile_data.get("agent_version", ""),
                confidence_by_task=profile_data.get("confidence_by_task", {}),
                failure_patterns=profile_data.get("failure_patterns", []),
                updated_at=profile_data.get("updated_at", ""),
            )

        return cls(profiles=profiles)

    def get_confidence(self, agent_id: str, task_category: str) -> float:
        """Get confidence score for an agent on a specific task category.

        Args:
            agent_id: The agent identifier
            task_category: The task category

        Returns:
            Confidence score (0.0-1.0), or 0.0 if agent or task is unknown
        """
        profile = self.profiles.get(agent_id)
        if profile is None:
            return 0.0
        return profile.get_confidence(task_category)

    def get_best_agent(self, task_category: str) -> str:
        """Get the agent with highest confidence for a task category.

        Args:
            task_category: The task category to find best agent for

        Returns:
            Agent ID with highest confidence, or empty string if no agents found
        """
        if not self.profiles:
            return ""

        best_agent = ""
        best_confidence = -1.0

        for agent_id, profile in self.profiles.items():
            confidence = profile.get_confidence(task_category)
            if confidence > best_confidence:
                best_confidence = confidence
                best_agent = agent_id

        return best_agent if best_confidence > 0.0 else ""

    def update_profile(self, agent_id: str, metrics: dict[str, Any]) -> None:
        """Update an agent's profile with new metrics.

        Metrics dict can contain:
            - confidence_by_task: dict of task_category -> confidence score
            - failure_patterns: list of failure pattern strings
            - agent_version: updated version string

        Args:
            agent_id: The agent to update
            metrics: Dict containing metrics to update
        """
        profile = self.profiles.get(agent_id)

        if profile is None:
            # Create new profile if it doesn't exist
            profile = AgentProfile(
                agent_id=agent_id,
                agent_version=metrics.get("agent_version", ""),
                confidence_by_task=metrics.get("confidence_by_task", {}),
                failure_patterns=metrics.get("failure_patterns", []),
            )
            self.profiles[agent_id] = profile
        else:
            # Update existing profile
            if "confidence_by_task" in metrics:
                for task_category, confidence in metrics["confidence_by_task"].items():
                    profile.update_confidence(task_category, confidence)

            if "failure_patterns" in metrics:
                # Replace failure patterns list
                object.__setattr__(profile, "failure_patterns", list(metrics["failure_patterns"]))
                object.__setattr__(profile, "updated_at", datetime.now(UTC).isoformat())

            if "agent_version" in metrics:
                object.__setattr__(profile, "agent_version", metrics["agent_version"])
                object.__setattr__(profile, "updated_at", datetime.now(UTC).isoformat())

    def add_profile(self, profile: AgentProfile) -> None:
        """Add or replace an agent profile.

        Args:
            profile: The AgentProfile to add
        """
        self.profiles[profile.agent_id] = profile

    def to_dict(self) -> dict[str, Any]:
        """Convert capability matrix to dictionary representation.

        Returns:
            Dict with profiles key containing all agent profiles
        """
        return {
            "profiles": {
                agent_id: profile.to_dict()
                for agent_id, profile in self.profiles.items()
            }
        }

    def to_json(self, json_path: Path | str, indent: int = 2) -> None:
        """Save capability matrix to JSON file.

        Args:
            json_path: Path to save JSON file
            indent: JSON indentation level (default: 2)
        """
        json_path = Path(json_path)
        with open(json_path, "w", encoding="utf-8") as f:
            json.dump(self.to_dict(), f, indent=indent, ensure_ascii=False)
