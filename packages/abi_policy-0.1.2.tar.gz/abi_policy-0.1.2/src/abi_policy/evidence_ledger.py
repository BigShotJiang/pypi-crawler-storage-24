"""Append-only JSONL evidence ledger with hash-chain integrity.

Each record is appended as a single JSON line with:
- record_hash: SHA-256 of canonical JSON (excluding record_hash and prev_hash)
- prev_hash:   hash of the preceding record ("0" * 64 for the first entry)
"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any


def _canonical_json(obj: dict[str, Any]) -> str:
    """Return canonical JSON for hashing (sorted keys, compact separators)."""
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def _sha256(data: str) -> str:
    return hashlib.sha256(data.encode("utf-8")).hexdigest()


class EvidenceLedger:
    """Append-only JSONL ledger with hash-chain verification."""

    def __init__(self, path: Path) -> None:
        self._path = Path(path)
        self._prev_hash: str = "0" * 64

        # If the file exists, read the last record to recover prev_hash
        if self._path.exists() and self._path.stat().st_size > 0:
            last_line = ""
            with self._path.open("r", encoding="utf-8") as f:
                for line in f:
                    stripped = line.strip()
                    if stripped:
                        last_line = stripped
            if last_line:
                last_record = json.loads(last_line)
                self._prev_hash = last_record.get("record_hash", "0" * 64)

    # ------------------------------------------------------------------
    # Write
    # ------------------------------------------------------------------

    def append(self, record: dict[str, Any]) -> dict[str, Any]:
        """Append *record* to the ledger with hash-chain fields.

        Returns a new dict that is *record* plus record_hash and prev_hash.
        """
        # Strip hash-chain fields before computing digest
        hashable = {k: v for k, v in record.items() if k not in ("record_hash", "prev_hash")}
        record_hash = _sha256(_canonical_json(hashable))

        enriched: dict[str, Any] = {
            **record,
            "record_hash": record_hash,
            "prev_hash": self._prev_hash,
        }

        with self._path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(enriched, sort_keys=True, ensure_ascii=False) + "\n")

        self._prev_hash = record_hash
        return enriched

    # ------------------------------------------------------------------
    # Read
    # ------------------------------------------------------------------

    def read_all(self) -> list[dict[str, Any]]:
        """Read every record from the ledger."""
        if not self._path.exists():
            return []
        records: list[dict[str, Any]] = []
        with self._path.open("r", encoding="utf-8") as f:
            for line in f:
                stripped = line.strip()
                if stripped:
                    records.append(json.loads(stripped))
        return records

    # ------------------------------------------------------------------
    # Verification
    # ------------------------------------------------------------------

    def verify_chain(self) -> bool:
        """Read entire ledger and verify hash-chain integrity.

        Returns True if every record's hash matches its content and each
        prev_hash links to the preceding record (first record must link
        to "0" * 64).
        """
        records = self.read_all()
        if not records:
            return True

        expected_prev = "0" * 64
        for record in records:
            stored_hash = record.get("record_hash", "")
            stored_prev = record.get("prev_hash", "")

            if stored_prev != expected_prev:
                return False

            hashable = {k: v for k, v in record.items() if k not in ("record_hash", "prev_hash")}
            computed = _sha256(_canonical_json(hashable))
            if computed != stored_hash:
                return False

            expected_prev = stored_hash

        return True
