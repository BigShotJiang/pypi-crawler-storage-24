"""RU Budget Controller — deterministic resource-unit budget tracking.

Tracks consumption of Resource Units (RU) against a fixed allocation
and reports the current quota zone (GREEN / YELLOW / RED / EXHAUSTED).
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any


@dataclass(frozen=True)
class BudgetState:
    """Immutable snapshot of budget status after a consumption event."""

    ru_allocated: float
    ru_consumed: float
    zone: str
    remaining: float
    pct_consumed: float


class BudgetController:
    """Deterministic RU budget controller with zone-based quota tracking.

    Zones (by percentage of ru_allocated consumed):
    - GREEN:     consumption < yellow_pct%
    - YELLOW:    yellow_pct% <= consumption < red_pct%
    - RED:       red_pct% <= consumption < exhausted_pct%
    - EXHAUSTED: consumption >= exhausted_pct%
    """

    def __init__(
        self,
        ru_allocated: float,
        *,
        yellow_pct: float = 60,
        red_pct: float = 80,
        exhausted_pct: float = 95,
    ) -> None:
        if ru_allocated <= 0:
            msg = f"ru_allocated must be positive, got {ru_allocated}"
            raise ValueError(msg)
        self._ru_allocated = float(ru_allocated)
        self._ru_consumed: float = 0.0
        self._yellow_pct = yellow_pct
        self._red_pct = red_pct
        self._exhausted_pct = exhausted_pct
        self._events: list[dict[str, Any]] = []

    # ------------------------------------------------------------------
    # Zone calculation
    # ------------------------------------------------------------------

    @property
    def zone(self) -> str:
        """Return the current quota zone string."""
        return self._compute_zone(self._ru_consumed)

    def _compute_zone(self, consumed: float) -> str:
        pct = (consumed / self._ru_allocated) * 100
        if pct >= self._exhausted_pct:
            return "EXHAUSTED"
        if pct >= self._red_pct:
            return "RED"
        if pct >= self._yellow_pct:
            return "YELLOW"
        return "GREEN"

    # ------------------------------------------------------------------
    # Consumption
    # ------------------------------------------------------------------

    def consume(self, ru_amount: float) -> BudgetState:
        """Record consumption of *ru_amount* RU and return the new state."""
        self._ru_consumed += ru_amount
        state = BudgetState(
            ru_allocated=self._ru_allocated,
            ru_consumed=self._ru_consumed,
            zone=self.zone,
            remaining=max(0.0, self._ru_allocated - self._ru_consumed),
            pct_consumed=(self._ru_consumed / self._ru_allocated) * 100,
        )
        self._events.append(
            {
                "ru_amount": ru_amount,
                "ru_consumed_after": self._ru_consumed,
                "zone_after": state.zone,
                "timestamp": datetime.now(UTC).isoformat(),
            }
        )
        return state

    # ------------------------------------------------------------------
    # Queries
    # ------------------------------------------------------------------

    def can_route(self, ru_estimate: float) -> bool:
        """Return True if *ru_estimate* fits within remaining budget."""
        projected = self._ru_consumed + ru_estimate
        return self._compute_zone(projected) != "EXHAUSTED"

    def snapshot(self) -> dict[str, Any]:
        """Return a budget-state/1.0 record."""
        return {
            "schema_version": "budget-state/1.0",
            "ru_allocated": self._ru_allocated,
            "ru_consumed": self._ru_consumed,
            "ru_remaining": max(0.0, self._ru_allocated - self._ru_consumed),
            "pct_consumed": (self._ru_consumed / self._ru_allocated) * 100,
            "zone": self.zone,
            "canonical": json.dumps(
                {
                    "ru_allocated": self._ru_allocated,
                    "ru_consumed": self._ru_consumed,
                    "zone": self.zone,
                },
                sort_keys=True,
                separators=(",", ":"),
                ensure_ascii=False,
            ),
        }
