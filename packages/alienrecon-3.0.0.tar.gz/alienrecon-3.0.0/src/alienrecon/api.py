"""AlienRecon API client — auth and chat proxy."""

import json
import os
import webbrowser
from pathlib import Path
from typing import Optional

import httpx
from rich.console import Console

console = Console()

CONFIG_DIR = Path.home() / ".alienrecon"
CONFIG_FILE = CONFIG_DIR / "config.json"
DEFAULT_API_URL = "http://137.220.32.162:3747"


def _load_config() -> dict:
    if CONFIG_FILE.exists():
        return json.loads(CONFIG_FILE.read_text())
    return {}


def _save_config(config: dict):
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_FILE.write_text(json.dumps(config, indent=2))


def get_api_url() -> str:
    config = _load_config()
    return config.get("api_url", os.environ.get("ALIENRECON_API_URL", DEFAULT_API_URL))


def get_token() -> Optional[str]:
    config = _load_config()
    return config.get("token")


def get_tier() -> str:
    config = _load_config()
    return config.get("tier", "free")


def get_byok_key() -> Optional[str]:
    config = _load_config()
    return config.get("byok_key")


def get_byok_model() -> Optional[str]:
    config = _load_config()
    return config.get("byok_model")


def is_logged_in() -> bool:
    return get_token() is not None


def _headers() -> dict:
    token = get_token()
    if not token:
        return {}
    headers = {"Authorization": f"Bearer {token}"}
    byok_key = get_byok_key()
    if byok_key:
        headers["X-Byok-Key"] = byok_key
        byok_model = get_byok_model()
        if byok_model:
            headers["X-Byok-Model"] = byok_model
    return headers


def _handle_error(resp: httpx.Response) -> dict:
    """Parse error response and raise with helpful message."""
    try:
        data = resp.json()
        detail = data.get("detail", resp.text)
    except Exception:
        detail = resp.text
    return {"error": True, "detail": detail, "status": resp.status_code}


# ── Auth ─────────────────────────────────────────────────────────────

def register(email: str, password: str) -> dict:
    url = f"{get_api_url()}/auth/register"
    resp = httpx.post(url, json={"email": email, "password": password}, timeout=15)
    if resp.status_code != 200:
        return _handle_error(resp)
    data = resp.json()
    _save_config({
        "api_url": get_api_url(),
        "token": data["token"],
        "email": data["user"]["email"],
        "tier": data["user"]["tier"],
    })
    return data


def login(email: str, password: str) -> dict:
    url = f"{get_api_url()}/auth/login"
    resp = httpx.post(url, json={"email": email, "password": password}, timeout=15)
    if resp.status_code != 200:
        return _handle_error(resp)
    data = resp.json()
    _save_config({
        "api_url": get_api_url(),
        "token": data["token"],
        "email": data["user"]["email"],
        "tier": data["user"]["tier"],
    })
    return data


def get_me() -> dict:
    url = f"{get_api_url()}/auth/me"
    resp = httpx.get(url, headers=_headers(), timeout=10)
    if resp.status_code != 200:
        return _handle_error(resp)
    data = resp.json()
    # Cache tier locally
    config = _load_config()
    config["tier"] = data.get("tier", "free")
    _save_config(config)
    return data


def logout():
    if CONFIG_FILE.exists():
        CONFIG_FILE.unlink()


def open_subscribe():
    """Create checkout session and open in browser."""
    url = f"{get_api_url()}/stripe/checkout"
    resp = httpx.post(url, headers=_headers(), timeout=15)
    if resp.status_code != 200:
        return _handle_error(resp)
    data = resp.json()
    checkout_url = data.get("checkout_url")
    if checkout_url:
        console.print(f"[cyan]Opening checkout:[/cyan] {checkout_url}")
        webbrowser.open(checkout_url)
    return data


# ── Chat proxy ───────────────────────────────────────────────────────

def chat_sync(
    messages: list[dict],
    system: str = "",
    tools: list[dict] | None = None,
    room_slug: str | None = None,
    max_tokens: int = 500,
) -> dict:
    """Send a chat request through our API proxy. Returns the full Anthropic response."""
    token = get_token()
    if not token:
        return {"error": True, "detail": "Not logged in. Run: alienrecon login", "status": 401}

    url = f"{get_api_url()}/api/chat/sync"
    payload = {
        "messages": messages,
        "max_tokens": max_tokens,
    }
    if system:
        payload["system"] = system
    if tools:
        payload["tools"] = tools
    if room_slug:
        payload["room_slug"] = room_slug

    try:
        resp = httpx.post(
            url,
            json=payload,
            headers=_headers(),
            timeout=120,  # Claude can take a while
        )
    except httpx.ConnectError:
        return {"error": True, "detail": "Cannot reach AlienRecon API. Check your connection.", "status": 0}
    except httpx.TimeoutException:
        return {"error": True, "detail": "Request timed out. Try again.", "status": 0}

    if resp.status_code != 200:
        return _handle_error(resp)

    return resp.json()
