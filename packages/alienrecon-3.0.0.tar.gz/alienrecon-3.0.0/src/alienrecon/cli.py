"""AlienRecon CLI — Cybersecurity Instructor."""

from typing import Optional

import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

app = typer.Typer(
    name="alienrecon",
    help="Your pentesting instructor. From zero to first blood.",
    no_args_is_help=True,
)
console = Console()


# ── Auth commands ────────────────────────────────────────────────────

@app.command()
def register():
    """Create an AlienRecon account."""
    from . import api

    email = console.input("[green]Email:[/green] ").strip()
    password = console.input("[green]Password:[/green] ", password=True).strip()
    confirm = console.input("[green]Confirm password:[/green] ", password=True).strip()

    if password != confirm:
        console.print("[red]Passwords don't match.[/red]")
        raise typer.Exit(1)

    result = api.register(email, password)
    if result.get("error"):
        console.print(f"[red]{result[detail]}[/red]")
        raise typer.Exit(1)

    console.print(f"\n[green]Account created![/green] Welcome, {result['user']['email']}")
    console.print("You're on the [cyan]Free[/cyan] tier — 6 trial rooms to get started.")
    console.print("Unlock [bold]all 39 rooms free[/bold] with your own API key:")
    console.print("  [green]alienrecon config --api-key sk-ant-...[/green]  (Anthropic)")
    console.print("  [green]alienrecon config --api-key sk-... --model gpt-4o[/green]  (OpenAI)")
    console.print("\nRun [green]alienrecon start[/green] to begin your first room.")


@app.command()
def login():
    """Log in to your AlienRecon account."""
    from . import api

    email = console.input("[green]Email:[/green] ").strip()
    password = console.input("[green]Password:[/green] ", password=True).strip()

    result = api.login(email, password)
    if result.get("error"):
        console.print(f"[red]{result[detail]}[/red]")
        raise typer.Exit(1)

    tier = result["user"]["tier"]
    console.print(f"\n[green]Logged in![/green] Tier: [cyan]{tier}[/cyan]")


@app.command()
def logout():
    """Log out and clear stored credentials."""
    from . import api

    api.logout()
    console.print("[green]Logged out.[/green]")


@app.command()
def account():
    """Show your account — tier, rooms used, subscription status."""
    from . import api

    if not api.is_logged_in():
        console.print("[yellow]Not logged in.[/yellow] Run: [green]alienrecon login[/green]")
        raise typer.Exit(1)

    result = api.get_me()
    if result.get("error"):
        console.print(f"[red]{result[detail]}[/red]")
        raise typer.Exit(1)

    table = Table(title="Account", border_style="green")
    table.add_column("Field", style="cyan")
    table.add_column("Value", style="green")
    table.add_row("Email", result["email"])
    table.add_row("Tier", result["tier"].upper())
    table.add_row("Rooms Used", ", ".join(result.get("rooms_used", [])) or "None")
    if result.get("subscription_expires_at"):
        table.add_row("Renews", result["subscription_expires_at"][:10])
    console.print(table)

    if result["tier"] == "free":
        console.print("\n[yellow]Upgrade to Pro[/yellow] for all 45+ rooms: [green]alienrecon subscribe[/green]")


@app.command()
def config(
    api_key: Optional[str] = typer.Option(None, "--api-key", help="Your BYOK API key (Anthropic, OpenAI, Groq, etc.)"),
    model: Optional[str] = typer.Option(None, "--model", help="LiteLLM model string (e.g. gpt-4o, groq/llama-3.3-70b, gemini/gemini-1.5-pro)"),
    clear_key: bool = typer.Option(False, "--clear-key", help="Remove stored BYOK key and model"),
    show: bool = typer.Option(False, "--show", help="Show current config"),
):
    """Configure BYOK — bring your own API key to unlock all 39 rooms for free.

    Examples:
      alienrecon config --api-key sk-ant-...                           # Anthropic (auto-detects model)
      alienrecon config --api-key sk-... --model gpt-4o               # OpenAI
      alienrecon config --api-key gsk_... --model groq/llama-3.3-70b  # Groq
      alienrecon config --api-key ... --model gemini/gemini-1.5-pro   # Google Gemini
      alienrecon config --clear-key                                     # Remove BYOK key
    """
    from . import api as _api
    from pathlib import Path
    import json

    config_file = Path.home() / ".alienrecon" / "config.json"

    if show:
        if config_file.exists():
            cfg = json.loads(config_file.read_text())
            table = Table(title="Config", border_style="cyan")
            table.add_column("Key", style="cyan")
            table.add_column("Value", style="green")
            table.add_row("API URL", cfg.get("api_url", "default"))
            table.add_row("Logged in", cfg.get("email", "no"))
            table.add_row("Tier", cfg.get("tier", "free"))
            key = cfg.get("byok_key", "")
            table.add_row("BYOK Key", f"{key[:12]}..." if key else "not set")
            table.add_row("BYOK Model", cfg.get("byok_model", "auto-detect"))
            console.print(table)
        else:
            console.print("[yellow]No config file found.[/yellow] Run: [green]alienrecon login[/green]")
        return

    if clear_key:
        if config_file.exists():
            cfg = json.loads(config_file.read_text())
            cfg.pop("byok_key", None)
            cfg.pop("byok_model", None)
            config_file.write_text(json.dumps(cfg, indent=2))
        console.print("[green]BYOK key cleared.[/green]")
        return

    if not api_key and not model:
        console.print("Provide at least [cyan]--api-key[/cyan] or [cyan]--model[/cyan]. Use [cyan]--show[/cyan] to view current config.")
        raise typer.Exit(1)

    if config_file.exists():
        cfg = json.loads(config_file.read_text())
    else:
        cfg = {}

    if api_key:
        cfg["byok_key"] = api_key
        console.print(f"[green]BYOK key saved.[/green] ({api_key[:12]}...)")
    if model:
        cfg["byok_model"] = model
        console.print(f"[green]Model set:[/green] {model}")

    config_file.parent.mkdir(parents=True, exist_ok=True)
    config_file.write_text(json.dumps(cfg, indent=2))

    if api_key and not model:
        # Show auto-detected provider hint
        if api_key.startswith("sk-ant-"):
            console.print("[dim]Provider: Anthropic (auto-detected)[/dim]")
        elif api_key.startswith("sk-"):
            console.print("[dim]Provider: OpenAI (auto-detected — use --model to override)[/dim]")
        elif api_key.startswith("AIza"):
            console.print("[dim]Provider: Google Gemini (auto-detected)[/dim]")
        else:
            console.print("[dim]Provider: unknown — set --model explicitly if needed[/dim]")

    console.print("\n[green]All 39 rooms unlocked.[/green] Run [cyan]alienrecon start[/cyan] to begin.")


@app.command()
def subscribe():
    """Upgrade to AlienRecon Pro ($14/month)."""
    from . import api

    if not api.is_logged_in():
        console.print("[yellow]Not logged in.[/yellow] Run: [green]alienrecon register[/green] first.")
        raise typer.Exit(1)

    result = api.open_subscribe()
    if result.get("error"):
        console.print(f"[red]{result[detail]}[/red]")
        raise typer.Exit(1)

    console.print("[green]Checkout opened in your browser.[/green]")


# ── Core commands ────────────────────────────────────────────────────

@app.command()
def start(
    room: str = typer.Option(None, "--room", "-r", help="Specific room to start (overrides curriculum)"),
    resume: bool = typer.Option(False, "--resume", help="Resume current room in progress"),
):
    """Start instructor mode. The agent assigns you a room and teaches you through it."""
    from . import api
    from .agent.instructor import Instructor
    from .curriculum.profile import StudentProfile
    from .curriculum.rooms import RoomDatabase

    if not api.is_logged_in():
        console.print("[yellow]Not logged in.[/yellow]")
        console.print("Run [green]alienrecon register[/green] to create a free account.")
        console.print("Run [green]alienrecon login[/green] if you already have one.")
        raise typer.Exit(1)

    profile = StudentProfile.load()
    rooms = RoomDatabase()
    instructor = Instructor(profile=profile, rooms=rooms)

    if resume and profile.current_room:
        instructor.resume_room()
    elif room:
        instructor.start_room(room)
    else:
        instructor.start_next()


@app.command()
def recon(
    target: str = typer.Option(..., "--target", "-t", help="Target IP or hostname"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Preview commands without executing"),
):
    """Free mode. Pick your own target, agent assists. (Pro only)"""
    from . import api
    from .agent.assistant import Assistant
    from .curriculum.profile import StudentProfile

    if not api.is_logged_in():
        console.print("[yellow]Not logged in.[/yellow] Run: [green]alienrecon login[/green]")
        raise typer.Exit(1)

    me = api.get_me()
    byok_active = bool(api.get_byok_key())
    if me.get("tier") != "pro" and not byok_active:
        console.print("[yellow]Free recon mode requires AlienRecon Pro or a BYOK key.[/yellow]")
        console.print("Upgrade: [green]alienrecon subscribe[/green]")
        console.print("BYOK:    [green]alienrecon config --api-key <key>[/green]")
        raise typer.Exit(1)

    profile = StudentProfile.load()
    assistant = Assistant(profile=profile, dry_run=dry_run)
    assistant.start(target)


@app.command()
def profile():
    """Show your student profile — skills, progress, stats."""
    from .curriculum.profile import StudentProfile
    from .display.ui import display_profile

    p = StudentProfile.load()
    display_profile(p)


@app.command()
def curriculum():
    """Show the curriculum — room catalog, skill tree, your progress."""
    from . import api
    from .curriculum.profile import StudentProfile
    from .curriculum.rooms import RoomDatabase
    from .display.ui import display_curriculum

    p = StudentProfile.load()
    rooms = RoomDatabase()
    display_curriculum(rooms, p)


@app.command()
def doctor():
    """Check your environment — required tools, API keys, connectivity."""
    from . import api
    from .display.ui import display_doctor
    from .tools.checker import check_environment

    results = check_environment()
    display_doctor(results)

    # Also check API connectivity
    console.print("\n[cyan]API Connection:[/cyan]")
    if api.is_logged_in():
        me = api.get_me()
        if me.get("error"):
            console.print(f"  [red]Error:[/red] {me[detail]}")
        else:
            console.print(f"  [green]Connected[/green] — {me[email]} ({me[tier]})")
    else:
        console.print("  [yellow]Not logged in[/yellow] — run: alienrecon register")


@app.command()
def reset(
    confirm: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation"),
):
    """Reset your progress. This cannot be undone."""
    from .curriculum.profile import StudentProfile

    if not confirm:
        confirmed = typer.confirm("This will delete all your progress. Are you sure?")
        if not confirmed:
            console.print("[yellow]Cancelled.[/yellow]")
            raise typer.Exit()

    StudentProfile.reset()
    console.print("[green]Profile reset. Fresh start.[/green]")


def main():
    app()


if __name__ == "__main__":
    main()
