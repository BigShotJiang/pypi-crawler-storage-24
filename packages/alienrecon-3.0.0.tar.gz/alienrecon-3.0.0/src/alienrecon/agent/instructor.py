"""Instructor agent — walks you through rooms."""

import logging
import re
import subprocess
import time
from typing import Optional

from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from ..core.flag_celebrator import FlagCelebrator
from ..curriculum.profile import StudentProfile
from ..curriculum.rooms import Phase, Room, RoomDatabase, Step
from ..tools.vpn import ensure_vpn
from . import brain

logger = logging.getLogger(__name__)
console = Console()


class Instructor:
    """Cybersecurity mentor that walks students through rooms."""

    def __init__(self, profile: StudentProfile, rooms: RoomDatabase):
        self.profile = profile
        self.rooms = rooms
        self.current_room: Optional[Room] = None
        self.target: str = ""
        self.hints_used = 0
        self.start_time = 0.0
        self.flags_found = 0
        self.conversation: list[dict] = []
        self.ai_mode = brain.is_available()

        if self.ai_mode:
            console.print("[dim]Instructor: connected[/dim]")
        else:
            console.print("[dim]Instructor: scripted mode (run alienrecon login for full experience)[/dim]")

    # ── Legacy chat (used for intro, debrief) ────────────────────────────

    def _chat(self, message: str, phase: Optional[Phase] = None,
              step: Optional[Step] = None) -> Optional[str]:
        """Get a response from Claude with full room context (legacy v1)."""
        if not self.ai_mode:
            return None

        response = brain.ask_claude(
            student_input=message,
            room_name=self.current_room.name if self.current_room else "",
            room_brief=self.current_room.brief if self.current_room else "",
            room_slug=self.current_room.id if self.current_room else "",
            phase_name=phase.name if phase else "",
            phase_objective=phase.objective if phase else "",
            step_id=step.id if step else "",
            step_instruction=step.narration if step else "",
            look_for=step.look_for if step else None,
            key_takeaway=step.key_takeaway if step else "",
            if_fails=step.if_fails if step else "",
            skill_level=self.profile.current_tier,
            hints_used=self.hints_used,
            conversation_history=self.conversation,
        )

        if response:
            self.conversation.append({"role": "user", "content": message})
            self.conversation.append({"role": "assistant", "content": response})

        return response

    # ── Room lifecycle (unchanged) ───────────────────────────────────────

    def start_next(self):
        room = self.rooms.get_next_room(self.profile)
        if not room:
            console.print(Panel(
                "[green]You\'ve completed all available rooms![/green]\n"
                "Check back for new rooms or try free mode: [cyan]alienrecon recon --target <IP>[/cyan]",
                title="Curriculum Complete", border_style="green",
            ))
            return
        self._begin_room(room)

    def start_room(self, room_id: str):
        room = self.rooms.get_room(room_id)
        if not room:
            console.print(f"[red]Room \'{room_id}\' not found.[/red]")
            available = self.rooms.list_rooms()
            if available:
                console.print("\nAvailable rooms:")
                for r in available:
                    console.print(f"  [cyan]{r.id}[/cyan] — {r.name} ({r.difficulty})")
            return
        self._begin_room(room)

    def resume_room(self):
        if not self.profile.current_room:
            console.print("[yellow]No room in progress. Starting next...[/yellow]")
            self.start_next()
            return

        room = self.rooms.get_room(self.profile.current_room.room_id)
        if not room:
            console.print("[red]Room data not found. Starting fresh...[/red]")
            self.start_next()
            return

        self.current_room = room
        self.start_time = time.time()
        self.hints_used = self.profile.current_room.hints_used

        console.print(Panel(
            f"[green]Resuming:[/green] {room.name}\n"
            f"Phase: [cyan]{self.profile.current_room.phase}[/cyan] | "
            f"Step: [cyan]{self.profile.current_room.step}[/cyan]",
            title="Welcome Back", border_style="green",
        ))

        self.target = self._ask("What was the target IP?") or ""
        if not self.target:
            return

        resume_phase = self.profile.current_room.phase
        resume_step = self.profile.current_room.step
        resuming = True

        for phase in room.phases:
            if resuming and phase.id != resume_phase:
                continue
            for step in phase.steps:
                if resuming and step.id != resume_step:
                    continue
                resuming = False
                self._teach_step(phase, step)
            if not resuming:
                self._phase_complete(phase)

        self._room_complete()

    def _begin_room(self, room: Room):
        self.current_room = room
        self.start_time = time.time()
        self.hints_used = 0
        self.flags_found = 0
        self.conversation = []

        skills_str = ", ".join(room.skills) if room.skills else "General"

        console.print()
        console.print(Panel(
            f"[bold]{room.name}[/bold]\n\n"
            f"Platform: [cyan]{room.platform}[/cyan] | "
            f"Difficulty: [yellow]{room.difficulty}[/yellow] | "
            f"Est. time: [cyan]{room.estimated_time} min[/cyan]\n"
            f"Skills: [green]{skills_str}[/green]\n\n"
            f"[dim]{room.url}[/dim]\n\n"
            f"Connect to {room.platform} and start the machine.\n"
            f"When it\'s up, give me the target IP.",
            title="Room Assignment", border_style="green",
        ))

        if room.questions:
            console.print("\n[cyan]Questions to answer:[/cyan]")
            for q in room.questions:
                console.print(f"  {q.id}: {q.text}")
            console.print()

        ensure_vpn(platform=room.platform)

        self.target = self._ask("Target IP") or ""
        if not self.target:
            return

        console.print(f"\n[green]Target set:[/green] {self.target}\n")
        self.profile.set_current_room(room.id, phase="", step="")

        intro = self._chat(
            f"Starting {room.name} on {room.platform}. Target: {self.target}. "
            f"Difficulty: {room.difficulty}. Skills: {skills_str}. "
            f"Give a brief 2-sentence intro — what kind of box this is and what we\'ll learn."
        )
        if intro:
            console.print(f"\n{intro}\n")
        else:
            console.print(f"\nLet\'s get into it. {room.name} — {room.difficulty} difficulty.\n")

        for phase in room.phases:
            self._teach_phase(phase)

        self._room_complete()

    def _teach_phase(self, phase: Phase):
        console.print()
        console.print(Panel(
            f"[bold]Objective:[/bold] {phase.objective}",
            title=f"Phase: {phase.name}", border_style="cyan",
        ))

        for step in phase.steps:
            self.profile.set_current_room(
                self.current_room.id, phase.id, step.id
            )
            self._teach_step(phase, step)

        self._phase_complete(phase)

    # ── The core teaching loop (tool_use driven) ─────────────────────────

    def _teach_step(self, phase: Phase, step: Step):
        """Conversation-driven step using Claude tool_use."""
        if not self.ai_mode:
            self._teach_step_scripted(phase, step)
            return

        # Build step knowledge for Claude
        step_knowledge = {
            "step_id": step.id,
            "narration": step.narration,
            "command": step.command.replace("{target}", self.target) if step.command else None,
            "expected_output": getattr(step, "expected_output", None),
            "explanation": step.explanation,
            "look_for": step.look_for,
            "key_takeaway": step.key_takeaway,
            "if_fails": step.if_fails,
            "conversation": step.conversation,
        }

        # Add questions linked to this step
        if self.current_room and self.current_room.questions:
            step_qs = [q for q in self.current_room.questions
                       if q.answer_step == step.id and not getattr(q, "no_answer", False)]
            if step_qs:
                step_knowledge["questions"] = [
                    {"id": q.id, "text": q.text, "answer": q.answer or ""}
                    for q in step_qs
                ]

        # Claude opens the step
        text, tool_calls = brain.teach_step(
            message="Begin this step. Open with an engaging question — do NOT show the command yet.",
            step_knowledge=step_knowledge,
            phase_name=phase.name,
            phase_objective=phase.objective,
            room_name=self.current_room.name if self.current_room else "",
            room_brief=self.current_room.brief if self.current_room else "",
            room_slug=self.current_room.id if self.current_room else "",
            difficulty=self.current_room.difficulty if self.current_room else "",
            conversation_history=self.conversation,
        )

        if text:
            console.print(f"\n{text}\n")
            self.conversation.append({"role": "assistant", "content": text})

        # Handle any tool calls from the opener
        should_advance = self._process_tool_calls(tool_calls, step, phase, step_knowledge)
        if should_advance:
            return

        # Conversation loop (max 12 turns per step)
        MAX_TURNS = 12
        turn = 0
        while turn < MAX_TURNS:
            turn += 1
            student_input = self._ask("")
            if not student_input:
                student_input = "continue"

            if student_input.lower() in ("skip", "next"):
                break

            # Nudge Claude to wrap up if nearing turn limit
            if turn >= MAX_TURNS - 1:
                student_input += " [Student seems ready to move on. Use advance_step.]"

            self.conversation.append({"role": "user", "content": student_input})

            text, tool_calls = brain.teach_step(
                message=student_input,
                step_knowledge=step_knowledge,
                phase_name=phase.name,
                phase_objective=phase.objective,
                room_name=self.current_room.name if self.current_room else "",
                room_brief=self.current_room.brief if self.current_room else "",
                difficulty=self.current_room.difficulty if self.current_room else "",
                conversation_history=self.conversation,
            )

            if text:
                console.print(f"\n{text}\n")
                self.conversation.append({"role": "assistant", "content": text})

            should_advance = self._process_tool_calls(tool_calls, step, phase, step_knowledge)
            if should_advance:
                break

            if not text and not tool_calls:
                console.print("[dim]Ask a question, or type \'next\' to continue.[/dim]\n")

        # Safety: if turns exhausted without advance_step, show takeaway and move on
        if turn >= MAX_TURNS:
            if step.key_takeaway:
                console.print(Panel(step.key_takeaway.strip(), title="Key Takeaway", border_style="yellow"))
            console.print("[dim]Moving to next step...[/dim]\n")

    def _process_tool_calls(self, tool_calls: list, step: Step, phase: Phase,
                            step_knowledge: dict) -> bool:
        """Execute tool calls from Claude. Returns True if advance_step was called."""
        for tc in tool_calls:
            name = tc["name"]
            inp = tc["input"]
            tool_id = tc["id"]

            if name == "run_command":
                return self._handle_run_command(tc, step, phase, step_knowledge)

            elif name == "show_hint":
                level = inp.get("level", 1)
                hint = inp.get("hint", "")
                self.hints_used += 1
                label = {1: "Nudge", 2: "Hint", 3: "Strong Hint"}.get(level, "Hint")
                console.print(Panel(
                    hint, title=f"{label} (level {level})", border_style="yellow",
                ))

            elif name == "check_answer":
                qid = inp.get("question_id", "")
                student_ans = inp.get("student_answer", "")
                correct = False
                if self.current_room and self.current_room.questions:
                    for q in self.current_room.questions:
                        if q.id == qid and q.answer:
                            correct = student_ans.strip().lower() == q.answer.strip().lower()
                            break
                if correct:
                    console.print("[green]Correct![/green]")
                else:
                    console.print("[yellow]Not quite — keep thinking.[/yellow]")

            elif name == "advance_step":
                summary = inp.get("summary", "")
                if step.key_takeaway:
                    console.print(Panel(
                        step.key_takeaway.strip(),
                        title="Key Takeaway", border_style="yellow",
                    ))
                if summary:
                    console.print(f"[dim]{summary}[/dim]\n")
                return True

        return False


    @staticmethod
    def _looks_like_command(text: str) -> bool:
        """Check if user input looks like a shell command vs natural language."""
        t = text.strip()
        # Starts with a known tool or path
        cmd_starters = (
            "nmap", "gobuster", "ffuf", "curl", "wget", "nikto", "hydra",
            "john", "sqlmap", "searchsploit", "msfconsole", "netcat", "nc",
            "cat", "ls", "cd", "grep", "find", "sudo", "ssh", "scp",
            "python", "perl", "ruby", "bash", "sh", "whoami", "id", "pwd",
            "echo", "mkdir", "rm", "cp", "mv", "chmod", "chown", "ping",
            "traceroute", "dig", "whois", "telnet", "socat", "./", "/",
        )
        first_word = t.split()[0].lower() if t.split() else ""
        if first_word in cmd_starters or t.startswith("/") or t.startswith("./"):
            return True
        # Contains shell operators
        if any(op in t for op in ("|", ">>", "&&", ";", "`", "$(")):
            return True
        # Has flags like -sV, --version
        if re.search(r"\s-[a-zA-Z]", t):
            return True
        return False

    def _handle_run_command(self, tool_call: dict, step: Step, phase: Phase,
                            step_knowledge: dict) -> bool:
        """Handle a run_command tool call — execute and feed output back to Claude."""
        inp = tool_call["input"]
        cmd = inp.get("command", "")
        explanation = inp.get("explanation", "")

        # Substitute target
        cmd = cmd.replace("{target}", self.target)

        if explanation:
            console.print(f"[dim]{explanation}[/dim]")
        console.print(f"\n[cyan]Command:[/cyan] [bold]{cmd}[/bold]\n")

        response = self._ask("Ready? (y / skip / or type your own command)")
        if not response:
            response = "y"

        response_lower = response.lower().strip()
        if response_lower in ("n", "no", "skip"):
            console.print("[yellow]Skipped.[/yellow]")
            return False
        elif response_lower in ("y", "yes", "yeah", "go", "run", "run it", "do it", ""):
            pass  # Run the suggested command
        elif self._looks_like_command(response):
            cmd = response
            console.print(f"[dim]Running your command: {cmd}[/dim]")
        else:
            # Natural language response — just run the suggested command
            console.print(f"[dim]Running suggested command.[/dim]")

        output = self._execute_command(cmd)

        # Check for flags
        if output:
            flag = FlagCelebrator.check_for_flag(output)
            if flag:
                FlagCelebrator.celebrate(flag)
                self.flags_found += 1

        # Feed output back to Claude for discussion
        output_trimmed = (output or "No output.").strip()[:3000]
        self.conversation.append({
            "role": "user",
            "content": f"[Command output from: {cmd}]\n{output_trimmed}"
        })

        # Add tool result to conversation
        text, new_tool_calls = brain.teach_step(
            message=f"Command output:\n{output_trimmed}\n\nAsk the student what they notice before explaining.",
            step_knowledge=step_knowledge,
            phase_name=phase.name,
            phase_objective=phase.objective,
            room_name=self.current_room.name if self.current_room else "",
            room_brief=self.current_room.brief if self.current_room else "",
            room_slug=self.current_room.id if self.current_room else "",
            difficulty=self.current_room.difficulty if self.current_room else "",
            conversation_history=self.conversation,
        )

        if text:
            console.print(f"\n{text}\n")
            self.conversation.append({"role": "assistant", "content": text})

        # Process any follow-up tool calls (e.g., advance after output discussion)
        if new_tool_calls:
            return self._process_tool_calls(new_tool_calls, step, phase, step_knowledge)

        return False

    # ── Scripted fallback (no API key) ───────────────────────────────────

    def _teach_step_scripted(self, phase: Phase, step: Step):
        """Fallback for users without an API key — show YAML content directly."""
        console.print()
        console.print(Panel(
            step.narration.strip(),
            title=f"[bold]{step.id}[/bold]", border_style="green",
        ))

        if step.explanation:
            console.print(Panel(step.explanation.strip(), title="How this works", border_style="dim"))

        if step.command:
            cmd = step.command.replace("{target}", self.target)
            console.print(f"\n[cyan]Command:[/cyan] [bold]{cmd}[/bold]\n")
            response = self._ask("Ready? (y / skip / or type your own command)")
            if not response:
                response = "y"
            response_lower = response.lower().strip()
            if response_lower in ("n", "no", "skip"):
                console.print("[yellow]Skipped.[/yellow]")
                return
            elif response_lower in ("y", "yes", "yeah", "go", "run", "run it", "do it", ""):
                output = self._execute_command(cmd)
            elif self._looks_like_command(response):
                output = self._execute_command(response)
            else:
                # Natural language — run the suggested command
                console.print("[dim]Running suggested command.[/dim]")
                output = self._execute_command(cmd)

            if output:
                flag = FlagCelebrator.check_for_flag(output)
                if flag:
                    FlagCelebrator.celebrate(flag)
                    self.flags_found += 1

        if step.key_takeaway:
            console.print(Panel(step.key_takeaway.strip(), title="Key Takeaway", border_style="yellow"))

        self._show_resources(step)

        if step.conversation:
            console.print(f"\n[cyan]{step.conversation}[/cyan]")

        console.print("\n[dim]Press Enter to continue[/dim]\n")
        self._ask("")

    # ── Shared utilities (unchanged) ─────────────────────────────────────

    def _show_resources(self, step: Step):
        if not step.resources:
            return
        lines = []
        for res in step.resources:
            title = res.get("title", "")
            url = res.get("url", "")
            desc = res.get("description", "")
            if title and url:
                lines.append(f"[cyan]{title}[/cyan] — {url}")
                if desc:
                    lines.append(f"  [dim]{desc}[/dim]")
            elif url:
                lines.append(f"[cyan]{url}[/cyan]")
        if lines:
            console.print(Panel("\n".join(lines), title="Resources", border_style="blue"))

    def _execute_command(self, cmd: str) -> Optional[str]:
        try:
            console.print("[dim]Running...[/dim]\n")
            result = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=300)
            output = result.stdout + result.stderr
            if output.strip():
                display = output.strip()
                if len(display) > 5000:
                    display = display[:5000] + "\n\n[dim]... (output truncated)[/dim]"
                console.print(Panel(display, title="Output", border_style="dim"))
            else:
                console.print("[dim]No output.[/dim]")
            return output
        except subprocess.TimeoutExpired:
            console.print("[red]Command timed out (5 min limit).[/red]")
            return None
        except Exception as e:
            console.print(f"[red]Error: {e}[/red]")
            return None

    def _phase_complete(self, phase: Phase):
        console.print(f"\n[green]Phase complete:[/green] {phase.name}\n")

    def _room_complete(self):
        if not self.current_room:
            return

        elapsed = int((time.time() - self.start_time) / 60)
        room = self.current_room

        self.profile.complete_room(
            room_id=room.id,
            time_taken=elapsed,
            hints_used=self.hints_used,
            flags_found=self.flags_found,
            skills_earned=room.skills_earned,
        )

        table = Table(title="Room Complete", border_style="green")
        table.add_column("Metric", style="cyan")
        table.add_column("Value", style="green")
        table.add_row("Room", room.name)
        table.add_row("Time", f"{elapsed} min")
        table.add_row("Hints Used", str(self.hints_used))
        table.add_row("Flags Found", str(self.flags_found))
        table.add_row("Skills Earned", ", ".join(room.skills_earned))
        table.add_row("Total Rooms", str(self.profile.total_rooms))
        console.print()
        console.print(table)

        debrief = self._chat(
            f"Room complete: {room.name}. {self.flags_found} flags, "
            f"{self.hints_used} hints, {elapsed} min. "
            f"Skills: {', '.join(room.skills_earned)}. "
            f"Brief debrief — what we covered and what to focus on next."
        )
        if debrief:
            console.print(f"\n{debrief}\n")

        next_room = self.rooms.get_next_room(self.profile)
        if next_room:
            console.print(f"[cyan]Next up:[/cyan] {next_room.name} ({next_room.difficulty})")
            console.print(f"Run [green]alienrecon start[/green] when you\'re ready.\n")

    def _ask(self, prompt: str) -> Optional[str]:
        try:
            if prompt:
                response = console.input(f"[green]  > [/green]{prompt} ")
            else:
                response = console.input("[green]  > [/green]")
            return response.strip() if response else None
        except (KeyboardInterrupt, EOFError):
            console.print("\n[yellow]Session ended. Progress saved.[/yellow]")
            self.profile.save()
            raise SystemExit(0)
