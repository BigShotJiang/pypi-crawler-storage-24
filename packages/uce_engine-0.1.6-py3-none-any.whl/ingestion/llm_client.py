import os
from typing import Any


class LLMClientError(RuntimeError):
    pass


def _env_int(name: str, default: int) -> int:
    value = os.getenv(name)
    if not value:
        return default
    value = value.strip()
    if not value:
        return default
    try:
        return int(value)
    except ValueError:
        return default


def _is_placeholder(value: str, placeholder: str) -> bool:
    return not value or value.strip() == placeholder


class LLMClient:
    def __init__(self) -> None:
        self.primary = (os.getenv("LLM_PROVIDER") or "anthropic").strip().lower()
        self.fallback = (os.getenv("LLM_FALLBACK") or "openai").strip().lower()

        self.anthropic_key = os.getenv("ANTHROPIC_API_KEY", "<CLAUDE_API_KEY_PLACEHOLDER>")
        self.openai_key = os.getenv("OPENAI_API_KEY", "<OPENAI_API_KEY_PLACEHOLDER>")

        self.anthropic_model = os.getenv("ANTHROPIC_MODEL", "claude-3-5-sonnet-latest")
        self.openai_model = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
        self.max_tokens = _env_int("LLM_MAX_TOKENS", 2048)

    def generate(self, prompt: str, provider: str | None = None) -> str:
        provider = (provider or self.primary).strip().lower()
        if provider == "anthropic":
            return self._call_anthropic(prompt)
        if provider == "openai":
            return self._call_openai(prompt)
        raise LLMClientError(f"Unsupported LLM provider: {provider}")

    def _call_anthropic(self, prompt: str) -> str:
        if _is_placeholder(self.anthropic_key, "<CLAUDE_API_KEY_PLACEHOLDER>"):
            raise LLMClientError("ANTHROPIC_API_KEY is not set for the Anthropic provider.")
        try:
            from anthropic import Anthropic
        except Exception as exc:  # pragma: no cover - import dependent
            raise LLMClientError("Anthropic client library is not installed.") from exc

        client = Anthropic(api_key=self.anthropic_key)
        response = client.messages.create(
            model=self.anthropic_model,
            max_tokens=self.max_tokens,
            temperature=0,
            messages=[{"role": "user", "content": prompt}],
        )
        content = getattr(response, "content", None)
        if isinstance(content, list):
            parts = []
            for block in content:
                text = getattr(block, "text", None)
                if text:
                    parts.append(text)
            return "".join(parts).strip()
        if isinstance(content, str):
            return content.strip()
        text = getattr(response, "text", None)
        if isinstance(text, str):
            return text.strip()
        raise LLMClientError("Anthropic response did not contain text output.")

    def _call_openai(self, prompt: str) -> str:
        if _is_placeholder(self.openai_key, "<OPENAI_API_KEY_PLACEHOLDER>"):
            raise LLMClientError("OPENAI_API_KEY is not set for the OpenAI provider.")
        try:
            from openai import OpenAI
        except Exception as exc:  # pragma: no cover - import dependent
            raise LLMClientError("OpenAI client library is not installed.") from exc

        client = OpenAI(api_key=self.openai_key)
        response = client.chat.completions.create(
            model=self.openai_model,
            temperature=0,
            messages=[{"role": "user", "content": prompt}],
        )
        choices = getattr(response, "choices", None)
        if not choices:
            raise LLMClientError("OpenAI response did not include any choices.")
        message = choices[0].message
        content = getattr(message, "content", None)
        if isinstance(content, str):
            return content.strip()
        raise LLMClientError("OpenAI response did not contain text output.")
