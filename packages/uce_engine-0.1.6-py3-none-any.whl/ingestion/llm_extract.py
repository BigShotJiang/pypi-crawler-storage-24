import json
import logging
import os
from typing import Any

from ingestion.llm_client import LLMClient, LLMClientError


class LLMExtractionError(RuntimeError):
    pass


logger = logging.getLogger("uce.llm_extract")


def _env_bool(name: str, default: bool = False) -> bool:
    value = os.getenv(name)
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "y", "on"}


def _safe_symbol(value: str) -> bool:
    if not value or value[0].isdigit():
        return False
    for char in value:
        if not (char.isalnum() or char == "_"):
            return False
    return True


def _optional_str(value: Any) -> str | None:
    if value is None:
        return None
    if not isinstance(value, str):
        raise LLMExtractionError("Optional fields must be strings when present.")
    cleaned = value.strip()
    return cleaned or None


def _coerce_confidence(value: Any) -> float:
    if isinstance(value, bool):
        raise LLMExtractionError("Confidence must be a number between 0 and 1.")
    if isinstance(value, (int, float)):
        confidence = float(value)
    elif isinstance(value, str):
        try:
            confidence = float(value.strip())
        except ValueError as exc:
            raise LLMExtractionError("Confidence must be a number between 0 and 1.") from exc
    else:
        raise LLMExtractionError("Confidence must be a number between 0 and 1.")
    if confidence < 0 or confidence > 1:
        raise LLMExtractionError("Confidence must be between 0 and 1.")
    return confidence


def _normalize_with_map(text: str) -> tuple[str, list[int]]:
    normalized: list[str] = []
    index_map: list[int] = []
    in_space = False
    for idx, char in enumerate(text):
        if char.isspace():
            if not in_space:
                normalized.append(" ")
                index_map.append(idx)
                in_space = True
        else:
            normalized.append(char)
            index_map.append(idx)
            in_space = False
    return "".join(normalized), index_map


def _find_span_in_document(span: str, document_text: str) -> str | None:
    if span in document_text:
        return span

    doc_lower = document_text.lower()
    span_lower = span.lower()
    idx = doc_lower.find(span_lower)
    if idx != -1:
        return document_text[idx : idx + len(span)]

    normalized_doc, index_map = _normalize_with_map(document_text)
    normalized_span, _ = _normalize_with_map(span)
    if normalized_span:
        idx = normalized_doc.find(normalized_span)
        if idx != -1:
            start = index_map[idx]
            end = index_map[idx + len(normalized_span) - 1] + 1
            return document_text[start:end]
        idx = normalized_doc.lower().find(normalized_span.lower())
        if idx != -1:
            start = index_map[idx]
            end = index_map[idx + len(normalized_span) - 1] + 1
            return document_text[start:end]

    return None


def _validate_evidence_spans(
    spans: Any, document_text: str, require_evidence: bool, strict: bool = True
) -> list[str]:
    if not require_evidence:
        if not isinstance(spans, list):
            return []
        cleaned: list[str] = []
        for span in spans:
            if not isinstance(span, str):
                continue
            if not span.strip():
                continue
            if span in document_text:
                cleaned.append(span)
                continue
            corrected = _find_span_in_document(span, document_text)
            if corrected:
                cleaned.append(corrected)
        return cleaned

    if not isinstance(spans, list) or not spans:
        raise LLMExtractionError("evidence_spans must be a non-empty list of strings.")
    cleaned: list[str] = []
    for span in spans:
        if not isinstance(span, str):
            raise LLMExtractionError("Evidence spans must be strings.")
        if not span.strip():
            raise LLMExtractionError("Evidence spans cannot be empty.")
        if span in document_text:
            cleaned.append(span)
            continue
        corrected = _find_span_in_document(span, document_text)
        if corrected:
            cleaned.append(corrected)
            continue
        if strict:
            raise LLMExtractionError("Evidence spans must be exact quotes from the document.")
    return cleaned


def _safe_json(data: Any) -> str:
    return json.dumps(data, ensure_ascii=True, default=str)


def build_prompt(
    document_text: str,
    metadata: dict[str, Any],
    graph_schema: Any,
    graph_context: dict[str, Any],
    doc_kind: str,
    strict: bool,
    require_evidence: bool,
) -> str:
    schema_definition = {
        "nodes": [
            {
                "id": "string",
                "type": "string",
                "title": "string (optional)",
                "description": "string (optional)",
                "category": "string (optional)",
                "confidence": "number 0-1",
                "evidence_spans": [
                    "string list (optional; exact quotes from document when provided)"
                ],
            }
        ],
        "edges": [
            {
                "type": "string",
                "source_id": "string",
                "target_id": "string",
                "confidence": "number 0-1",
                "evidence_spans": [
                    "string list (optional; exact quotes from document when provided)"
                ],
            }
        ],
    }

    instructions = [
        "Return ONLY valid JSON. No markdown, no comments.",
        "Include nodes for every edge endpoint, even if the node already exists.",
        "Use existing graph context to choose node IDs and types when possible.",
    ]
    if require_evidence:
        instructions.append("Evidence spans must be exact substrings from the document text.")
        instructions.append("If you cannot quote an exact evidence span, omit that node or edge.")
    if require_evidence and strict:
        instructions.append(
            "Before responding, verify each evidence span appears verbatim in the document text."
        )
        instructions.append(
            "Do NOT paraphrase evidence spans; copy exact text including punctuation and casing."
        )

    if doc_kind.lower() == "requirement":
        instructions.append("For requirements, relate Requirement nodes to Table/Column nodes using GOVERNS.")
    if doc_kind.lower() == "policy":
        instructions.append("For policies, relate Policy nodes to Requirement nodes using ENFORCES.")

    prompt = (
        "You are a strict JSON extraction engine.\n"
        f"Document type: {doc_kind}\n\n"
        "Rules:\n"
        + "\n".join(f"- {line}" for line in instructions)
        + "\n\nSchema:\n"
        + _safe_json(schema_definition)
        + "\n\nDocument metadata:\n"
        + _safe_json(metadata)
        + "\n\nGraph schema (from MCP get-schema):\n"
        + _safe_json(graph_schema)
        + "\n\nGraph context (from MCP read-cypher):\n"
        + _safe_json(graph_context)
        + "\n\nDocument text:\n"
        + document_text
    )
    return prompt


def build_repair_prompt(
    document_text: str,
    metadata: dict[str, Any],
    graph_schema: Any,
    graph_context: dict[str, Any],
    doc_kind: str,
    previous_json: str,
    error_message: str,
) -> str:
    instructions = [
        "Return ONLY valid JSON. No markdown, no comments.",
        "Fix ONLY evidence_spans so that every span is an exact substring of the document text.",
        "Do not change node/edge ids or types unless absolutely necessary to fix evidence.",
        "If you cannot find an exact quote, remove that node or edge.",
    ]

    prompt = (
        "You are a strict JSON repair engine.\n"
        f"Document type: {doc_kind}\n\n"
        "Validation error:\n"
        + error_message
        + "\n\nRules:\n"
        + "\n".join(f"- {line}" for line in instructions)
        + "\n\nSchema:\n"
        + _safe_json(
            {
                "nodes": [
                    {
                        "id": "string",
                        "type": "string",
                        "title": "string (optional)",
                        "description": "string (optional)",
                        "category": "string (optional)",
                        "confidence": "number 0-1",
                        "evidence_spans": ["exact quotes from document"],
                    }
                ],
                "edges": [
                    {
                        "type": "string",
                        "source_id": "string",
                        "target_id": "string",
                        "confidence": "number 0-1",
                        "evidence_spans": ["exact quotes from document"],
                    }
                ],
            }
        )
        + "\n\nDocument metadata:\n"
        + _safe_json(metadata)
        + "\n\nGraph schema (from MCP get-schema):\n"
        + _safe_json(graph_schema)
        + "\n\nGraph context (from MCP read-cypher):\n"
        + _safe_json(graph_context)
        + "\n\nOriginal JSON:\n"
        + previous_json
        + "\n\nDocument text:\n"
        + document_text
    )
    return prompt


def validate_extraction(
    data: Any, document_text: str, require_evidence: bool, strict: bool = True
) -> dict[str, Any]:
    if not isinstance(data, dict):
        raise LLMExtractionError("LLM output must be a JSON object.")
    nodes = data.get("nodes")
    edges = data.get("edges")
    if not isinstance(nodes, list) or not isinstance(edges, list):
        raise LLMExtractionError("LLM output must include 'nodes' and 'edges' lists.")

    cleaned_nodes: list[dict[str, Any]] = []
    for node in nodes:
        if not isinstance(node, dict):
            raise LLMExtractionError("Each node must be an object.")
        node_id = node.get("id")
        node_type = node.get("type")
        if not isinstance(node_id, str) or not node_id.strip():
            raise LLMExtractionError("Node id is required.")
        if not isinstance(node_type, str) or not node_type.strip():
            raise LLMExtractionError("Node type is required.")
        node_type = node_type.strip()
        if not _safe_symbol(node_type):
            raise LLMExtractionError("Node type must be alphanumeric/underscore and not start with a digit.")

        title = _optional_str(node.get("title"))
        description = _optional_str(node.get("description"))
        category = _optional_str(node.get("category"))
        confidence = _coerce_confidence(node.get("confidence"))
        try:
            evidence_spans = _validate_evidence_spans(
                node.get("evidence_spans"),
                document_text,
                require_evidence=require_evidence,
                strict=strict,
            )
        except LLMExtractionError as exc:
            if strict:
                raise
            logger.warning("Skipping node %s due to invalid evidence spans: %s", node_id, exc)
            continue

        cleaned_nodes.append(
            {
                "id": node_id.strip(),
                "type": node_type,
                "title": title,
                "description": description,
                "category": category,
                "confidence": confidence,
                "evidence_spans": evidence_spans,
            }
        )

    if not cleaned_nodes:
        if not strict:
            return {"nodes": [], "edges": []}
            raise LLMExtractionError("LLM output contained no nodes.")

    node_ids = {node["id"] for node in cleaned_nodes}

    cleaned_edges: list[dict[str, Any]] = []
    for edge in edges:
        if not isinstance(edge, dict):
            raise LLMExtractionError("Each edge must be an object.")
        edge_type = edge.get("type")
        source_id = edge.get("source_id")
        target_id = edge.get("target_id")
        if not isinstance(edge_type, str) or not edge_type.strip():
            raise LLMExtractionError("Edge type is required.")
        edge_type = edge_type.strip()
        if not _safe_symbol(edge_type):
            raise LLMExtractionError("Edge type must be alphanumeric/underscore and not start with a digit.")
        if not isinstance(source_id, str) or not source_id.strip():
            raise LLMExtractionError("Edge source_id is required.")
        if not isinstance(target_id, str) or not target_id.strip():
            raise LLMExtractionError("Edge target_id is required.")

        source_id = source_id.strip()
        target_id = target_id.strip()
        if source_id not in node_ids or target_id not in node_ids:
            if strict:
                raise LLMExtractionError(
                    "Edges must reference node ids that are included in the nodes list."
                )
            logger.warning(
                "Skipping edge %s -> %s due to missing node references.", source_id, target_id
            )
            continue

        confidence = _coerce_confidence(edge.get("confidence"))
        try:
            evidence_spans = _validate_evidence_spans(
                edge.get("evidence_spans"),
                document_text,
                require_evidence=require_evidence,
                strict=strict,
            )
        except LLMExtractionError as exc:
            if strict:
                raise
            logger.warning(
                "Skipping edge %s -> %s due to invalid evidence spans: %s",
                source_id,
                target_id,
                exc,
            )
            continue
        cleaned_edges.append(
            {
                "type": edge_type,
                "source_id": source_id,
                "target_id": target_id,
                "confidence": confidence,
                "evidence_spans": evidence_spans,
            }
        )

    return {"nodes": cleaned_nodes, "edges": cleaned_edges}


def extract_graph_updates(
    document_text: str,
    metadata: dict[str, Any],
    graph_schema: Any,
    graph_context: dict[str, Any],
    doc_kind: str,
    llm_client: LLMClient | None = None,
) -> dict[str, Any]:
    if not document_text:
        raise LLMExtractionError("Document text is empty.")

    client = llm_client or LLMClient()
    require_evidence = _env_bool("LLM_REQUIRE_EVIDENCE", False)
    strict = _env_bool("LLM_EVIDENCE_STRICT", True)
    prompt = build_prompt(
        document_text,
        metadata,
        graph_schema,
        graph_context,
        doc_kind,
        strict=strict,
        require_evidence=require_evidence,
    )

    errors: list[str] = []
    providers: list[str] = []
    for provider in [client.primary, client.fallback]:
        if provider and provider not in providers:
            providers.append(provider)

    for provider in providers:
        if not provider:
            continue
        try:
            raw = client.generate(prompt, provider=provider)
            parsed = json.loads(raw)
            return validate_extraction(
                parsed,
                document_text,
                require_evidence=require_evidence,
                strict=strict,
            )
        except (json.JSONDecodeError, LLMClientError) as exc:
            errors.append(f"{provider}: {exc}")
            continue
        except LLMExtractionError as exc:
            error_message = str(exc)
            if require_evidence and strict and ("evidence" in error_message.lower()):
                try:
                    repair_prompt = build_repair_prompt(
                        document_text=document_text,
                        metadata=metadata,
                        graph_schema=graph_schema,
                        graph_context=graph_context,
                        doc_kind=doc_kind,
                        previous_json=raw,
                        error_message=error_message,
                    )
                    repaired_raw = client.generate(repair_prompt, provider=provider)
                    repaired = json.loads(repaired_raw)
                    return validate_extraction(
                        repaired,
                        document_text,
                        require_evidence=require_evidence,
                        strict=strict,
                    )
                except (json.JSONDecodeError, LLMExtractionError, LLMClientError) as repair_exc:
                    errors.append(
                        f"{provider}: {error_message} | repair failed: {repair_exc}"
                    )
                    continue
            errors.append(f"{provider}: {exc}")
            continue

    raise LLMExtractionError(
        "LLM extraction failed after trying primary and fallback providers. "
        + " | ".join(errors)
    )
