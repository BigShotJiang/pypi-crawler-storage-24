import logging
import os
from typing import Any, Iterable

from ingestion.llm_client import LLMClient, LLMClientError
from ingestion.llm_extract import extract_graph_updates, LLMExtractionError
from ingestion.mcp_neo4j import McpNeo4jClient, McpNeo4jError

logger = logging.getLogger("uce.ingestion.llm")

ARTIFACTS_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "artifacts"))
REQUIREMENTS_DIR = os.path.join(ARTIFACTS_DIR, "requirements")
POLICIES_DIR = os.path.join(ARTIFACTS_DIR, "policies")


def _extract_metadata(content: str, filename: str) -> dict[str, Any]:
    metadata: dict[str, Any] = {
        "filename": filename,
        "doc_id": None,
        "owner": None,
        "effective_date": None,
    }
    for line in content.splitlines():
        stripped = line.strip()
        if not stripped:
            continue
        lower = stripped.lower()
        if lower.startswith("id:"):
            metadata["doc_id"] = stripped.split(":", 1)[1].strip()
        elif lower.startswith("owner:"):
            metadata["owner"] = stripped.split(":", 1)[1].strip()
        elif lower.startswith("effective date:") or lower.startswith("effective_date:"):
            metadata["effective_date"] = stripped.split(":", 1)[1].strip()
    return metadata


def _load_graph_context(mcp: McpNeo4jClient) -> dict[str, Any]:
    tables_rows = mcp.read_cypher("MATCH (t:Table) RETURN t.name AS name ORDER BY name")
    columns_rows = mcp.read_cypher(
        "MATCH (c:Column) RETURN c.name AS name, c.table AS table ORDER BY c.table, c.name"
    )
    requirement_rows = mcp.read_cypher("MATCH (r:Requirement) RETURN r.id AS id ORDER BY id")
    policy_rows = mcp.read_cypher("MATCH (p:Policy) RETURN p.id AS id ORDER BY id")

    tables: list[str] = []
    if isinstance(tables_rows, list):
        for row in tables_rows:
            if isinstance(row, dict):
                name = row.get("name")
                if name:
                    tables.append(name)

    columns: list[dict[str, str]] = []
    if isinstance(columns_rows, list):
        for row in columns_rows:
            if isinstance(row, dict):
                name = row.get("name")
                table = row.get("table")
                if name and table:
                    columns.append({"name": name, "table": table})

    requirements: list[str] = []
    if isinstance(requirement_rows, list):
        for row in requirement_rows:
            if isinstance(row, dict):
                req_id = row.get("id")
                if req_id:
                    requirements.append(req_id)

    policies: list[str] = []
    if isinstance(policy_rows, list):
        for row in policy_rows:
            if isinstance(row, dict):
                pol_id = row.get("id")
                if pol_id:
                    policies.append(pol_id)

    return {
        "tables": sorted(set(tables)),
        "columns": columns,
        "requirements": sorted(set(requirements)),
        "policies": sorted(set(policies)),
    }


def _safe_label(value: str) -> bool:
    if not value or value[0].isdigit():
        return False
    for char in value:
        if not (char.isalnum() or char == "_"):
            return False
    return True


def _apply_graph_updates(mcp: McpNeo4jClient, extraction: dict[str, Any]) -> None:
    nodes = extraction.get("nodes") or []
    edges = extraction.get("edges") or []

    id_to_type: dict[str, str] = {}
    for node in nodes:
        node_id = node["id"]
        node_type = node["type"]
        existing = id_to_type.get(node_id)
        if existing and existing != node_type:
            raise ValueError(f"Conflicting node types for id {node_id}: {existing} vs {node_type}")
        id_to_type[node_id] = node_type

    for node in nodes:
        node_id = node["id"]
        node_type = node["type"]
        if not _safe_label(node_type):
            raise ValueError(f"Unsafe node label: {node_type}")

        mcp.read_cypher(f"MATCH (n:{node_type} {{id: $id}}) RETURN n LIMIT 1", {"id": node_id})

        props: dict[str, Any] = {
            "confidence": node["confidence"],
            "evidence_spans": node["evidence_spans"],
        }
        for field in ("title", "description", "category"):
            value = node.get(field)
            if value is not None:
                props[field] = value

        mcp.write_cypher(
            f"MERGE (n:{node_type} {{id: $id}}) SET n += $props",
            {"id": node_id, "props": props},
        )

    for edge in edges:
        rel_type = edge["type"]
        if not _safe_label(rel_type):
            raise ValueError(f"Unsafe relationship type: {rel_type}")

        source_id = edge["source_id"]
        target_id = edge["target_id"]
        source_type = id_to_type[source_id]
        target_type = id_to_type[target_id]
        if not _safe_label(source_type) or not _safe_label(target_type):
            raise ValueError("Unsafe node label in edge endpoints.")

        mcp.write_cypher(
            f"""
            MATCH (s:{source_type} {{id: $source_id}})
            MATCH (t:{target_type} {{id: $target_id}})
            MERGE (s)-[r:{rel_type}]->(t)
            SET r.confidence = $confidence,
                r.evidence_spans = $evidence_spans
            """,
            {
                "source_id": source_id,
                "target_id": target_id,
                "confidence": edge["confidence"],
                "evidence_spans": edge["evidence_spans"],
            },
        )


def _coerce_dirs(value: str | Iterable[str] | None, default_dir: str) -> list[str]:
    if value is None:
        return [default_dir]
    if isinstance(value, str):
        return [value]
    return [str(v) for v in value if v]


def _short_error(exc: Exception, limit: int = 160) -> str:
    text = str(exc).replace("\n", " ").strip()
    if len(text) <= limit:
        return text
    return text[: limit - 3].rstrip() + "..."


def _ingest_documents(
    doc_kind: str,
    directories: Iterable[str],
) -> None:
    existing_dirs = [path for path in directories if os.path.isdir(path)]
    if not existing_dirs:
        raise FileNotFoundError(
            f"{doc_kind} directory not found: " + ", ".join(directories)
        )

    mcp = McpNeo4jClient()
    llm = LLMClient()
    summary: list[dict[str, Any]] = []
    processed = 0
    skipped = 0
    total_nodes = 0
    total_edges = 0

    files = [
        os.path.join(d, f)
        for d in existing_dirs
        for f in sorted(os.listdir(d))
        if f.endswith(".md")
    ]
    logger.info("LLM %s ingestion: %d file(s) to process", doc_kind.lower(), len(files))

    try:
        if mcp.read_only:
            raise McpNeo4jError(f"NEO4J_READ_ONLY is true; {doc_kind.lower()} ingestion requires write access.")

        logger.info("Fetching graph schema from MCP...")
        schema = mcp.get_schema()
        logger.info("Fetching graph context from MCP...")
        context = _load_graph_context(mcp)
        logger.info("Schema/context ready. Processing files...")

        for idx, full_path in enumerate(files, 1):
            filename = os.path.basename(full_path)
            logger.info("[%d/%d] %s: reading %s", idx, len(files), doc_kind, filename)
            with open(full_path, "r", encoding="utf-8") as file:
                content = file.read()

            metadata = _extract_metadata(content, filename)
            logger.info("[%d/%d] %s: calling LLM for %s", idx, len(files), doc_kind, filename)
            try:
                extraction = extract_graph_updates(
                    document_text=content,
                    metadata=metadata,
                    graph_schema=schema,
                    graph_context=context,
                    doc_kind=doc_kind,
                    llm_client=llm,
                )
                logger.info(
                    "[%d/%d] %s: applying %d node(s) / %d edge(s) for %s",
                    idx,
                    len(files),
                    doc_kind,
                    len(extraction.get("nodes") or []),
                    len(extraction.get("edges") or []),
                    filename,
                )
                _apply_graph_updates(mcp, extraction)
                nodes_count = len(extraction.get("nodes") or [])
                edges_count = len(extraction.get("edges") or [])
                processed += 1
                total_nodes += nodes_count
                total_edges += edges_count
                summary.append(
                    {
                        "filename": filename,
                        "nodes": nodes_count,
                        "edges": edges_count,
                        "status": "ok",
                    }
                )
                logger.info("[%d/%d] %s: done %s", idx, len(files), doc_kind, filename)
            except (LLMExtractionError, LLMClientError, ValueError, McpNeo4jError) as exc:
                skipped += 1
                summary.append(
                    {
                        "filename": filename,
                        "nodes": 0,
                        "edges": 0,
                        "status": f"error: {_short_error(exc)}",
                    }
                )
                logger.warning(
                    "[%d/%d] %s: skipping %s due to error: %s",
                    idx,
                    len(files),
                    doc_kind,
                    filename,
                    exc,
                )
                continue
    finally:
        if summary:
            logger.info(
                "LLM %s ingestion summary: processed=%d skipped=%d nodes=%d edges=%d",
                doc_kind.lower(),
                processed,
                skipped,
                total_nodes,
                total_edges,
            )
            for item in summary:
                logger.info(
                    "LLM %s file summary: %s nodes=%d edges=%d status=%s",
                    doc_kind.lower(),
                    item["filename"],
                    item["nodes"],
                    item["edges"],
                    item["status"],
                )
        mcp.close()


def ingest_requirements(requirements_dir: str | Iterable[str] | None = None) -> None:
    dirs = _coerce_dirs(requirements_dir, REQUIREMENTS_DIR)
    _ingest_documents("Requirement", dirs)


def ingest_policies(policies_dir: str | Iterable[str] | None = None) -> None:
    dirs = _coerce_dirs(policies_dir, POLICIES_DIR)
    _ingest_documents("Policy", dirs)


if __name__ == "__main__":
    ingest_requirements()
