from __future__ import annotations

import logging
import os
from contextlib import contextmanager
from typing import Iterable

from core.config import UceConfig, resolve_paths
from core.graph_db import GraphDB
from ingestion import code_parser, schema_parser, requirement_parser, policy_parser
from ingestion.graph_builder import (
    is_ignored,
    ensure_relative,
    normalize_path,
    upsert_code_file,
    upsert_schema,
    upsert_requirements,
    upsert_policies,
    load_tables,
    load_columns,
    link_tables_for_file,
)


class GraphUpdater:
    def __init__(self, config: UceConfig, graph: GraphDB, logger: logging.Logger | None = None):
        self.config = config
        self.graph = graph
        self.paths = resolve_paths(config)
        self.logger = logger or logging.getLogger("uce.updater")
        self.extensions = self._extensions_for_languages(config.languages)
        self.identifier_paths = self._resolve_identifier_paths()
        self.identifier_max_bytes = self._env_int("UCE_IDENTIFIER_MAX_BYTES", 200000)
        self.identifier_max_count = self._env_int("UCE_IDENTIFIER_MAX_COUNT", 5000)

    def _extensions_for_languages(self, languages: Iterable[str]) -> tuple[str, ...]:
        exts = []
        for ext, lang in code_parser.LANGUAGE_BY_EXTENSION.items():
            if lang in languages:
                exts.append(ext)
        return tuple(sorted(set(exts)))

    def _env_int(self, name: str, default: int) -> int:
        value = os.getenv(name)
        if value is None:
            return default
        value = value.strip()
        if not value:
            return default
        try:
            return int(value)
        except ValueError:
            return default

    def _resolve_identifier_paths(self) -> tuple[str, ...]:
        env_value = os.getenv("UCE_IDENTIFIER_PATHS")
        if env_value:
            normalized = env_value.replace(",", os.pathsep)
            parts = [p.strip() for p in normalized.split(os.pathsep) if p.strip()]
            resolved = []
            for part in parts:
                if os.path.isabs(part):
                    resolved.append(os.path.normpath(part))
                else:
                    resolved.append(os.path.normpath(os.path.join(self.config.project_root, part)))
            return tuple(sorted(set(resolved)))

        paths = self.paths.get("identifiers") if isinstance(self.paths, dict) else None
        if paths:
            return tuple(sorted(set(paths)))
        return tuple()

    def _should_index_identifiers(self, full_path: str) -> bool:
        if not self.identifier_paths:
            return False
        abs_path = os.path.abspath(full_path)
        in_scope = False
        for root in self.identifier_paths:
            try:
                if os.path.commonpath([abs_path, root]) == root:
                    in_scope = True
                    break
            except ValueError:
                continue
        if not in_scope:
            return False
        if self.identifier_max_bytes > 0:
            try:
                size = os.path.getsize(full_path)
            except OSError:
                return False
            if size > self.identifier_max_bytes:
                self.logger.info("Skipping identifier indexing for %s: size %d exceeds limit %d", full_path, size, self.identifier_max_bytes)
                return False
        return True

    def _iter_code_files(self):
        for root_path in self.paths["code"]:
            if not os.path.isdir(root_path):
                continue
            for root, _, files in os.walk(root_path):
                for filename in files:
                    ext = os.path.splitext(filename)[1].lower()
                    if ext not in self.extensions:
                        continue
                    full_path = os.path.join(root, filename)
                    rel_path = ensure_relative(full_path, self.config.project_root)
                    if is_ignored(rel_path, self.config.ignore):
                        continue
                    yield full_path, rel_path

    def _iter_schema_files(self):
        for root_path in self.paths["schema"]:
            if os.path.isdir(root_path):
                for root, _, files in os.walk(root_path):
                    for filename in files:
                        if not filename.endswith((".sql", ".ts", ".js", ".json", ".yaml", ".yml")):
                            continue
                        yield os.path.join(root, filename)
            elif os.path.isfile(root_path):
                yield root_path

    def _iter_requirement_dirs(self):
        for path in self.paths["requirements"]:
            if os.path.isdir(path):
                yield path

    def _iter_policy_dirs(self):
        for path in self.paths["policies"]:
            if os.path.isdir(path):
                yield path

    def _llm_config(self):
        return getattr(self.config, "llm", None)

    def _llm_enabled(self) -> bool:
        llm = self._llm_config()
        return bool(llm and llm.enabled)

    def _llm_requirements_enabled(self) -> bool:
        llm = self._llm_config()
        return bool(llm and llm.enabled and llm.requirements)

    def _llm_policies_enabled(self) -> bool:
        llm = self._llm_config()
        return bool(llm and llm.enabled and llm.policies)

    @contextmanager
    def _temp_env(self, overrides: dict[str, str]):
        original: dict[str, str | None] = {}
        for key, value in overrides.items():
            original[key] = os.environ.get(key)
            os.environ[key] = value
        try:
            yield
        finally:
            for key, value in original.items():
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value

    def _llm_env_overrides(self) -> dict[str, str]:
        return {
            "NEO4J_URI": str(self.config.neo4j.uri),
            "NEO4J_USER": str(self.config.neo4j.user),
            "NEO4J_USERNAME": str(self.config.neo4j.user),
            "NEO4J_PASSWORD": str(self.config.neo4j.password),
        }

    def _llm_ingest_requirements(self, directories: Iterable[str]) -> None:
        if not self._llm_requirements_enabled():
            return

        try:
            from ingestion import llm_ingest
        except Exception as exc:
            self.logger.error("Failed to import LLM requirements ingestion: %s", exc)
            return

        existing_dirs = [path for path in directories if os.path.isdir(path)]
        if not existing_dirs:
            self.logger.warning("LLM requirements ingestion skipped: no requirement directories found")
            return

        self.logger.info("Starting LLM requirements ingestion (%d director(ies))", len(existing_dirs))
        with self._temp_env(self._llm_env_overrides()):
            try:
                llm_ingest.ingest_requirements(existing_dirs)
                self.logger.info("LLM requirements ingestion completed")
            except Exception as exc:
                self.logger.warning("LLM requirements ingestion failed: %s", exc)

    def _llm_ingest_policies(self, directories: Iterable[str]) -> None:
        if not self._llm_policies_enabled():
            return

        try:
            from ingestion import llm_ingest
        except Exception as exc:
            self.logger.error("Failed to import LLM policies ingestion: %s", exc)
            return

        existing_dirs = [path for path in directories if os.path.isdir(path)]
        if not existing_dirs:
            self.logger.warning("LLM policies ingestion skipped: no policy directories found")
            return

        self.logger.info("Starting LLM policies ingestion (%d director(ies))", len(existing_dirs))
        with self._temp_env(self._llm_env_overrides()):
            try:
                llm_ingest.ingest_policies(existing_dirs)
                self.logger.info("LLM policies ingestion completed")
            except Exception as exc:
                self.logger.warning("LLM policies ingestion failed: %s", exc)

    def run_llm_ingestion(self) -> None:
        if not self._llm_enabled():
            return

        self._llm_ingest_requirements(self.paths["requirements"])
        self._llm_ingest_policies(self.paths["policies"])

    def llm_ingest_requirements_dir(self, directory: str) -> None:
        self._llm_ingest_requirements([directory])

    def llm_ingest_policies_dir(self, directory: str) -> None:
        self._llm_ingest_policies([directory])

    def full_refresh(self) -> None:
        self.logger.info("Starting full ingestion")
        self.refresh_schema()
        if self._llm_enabled():
            self.logger.info("Skipping deterministic requirements/policies ingestion (LLM enabled)")
        else:
            self.refresh_requirements()
            self.refresh_policies()
        self.refresh_code()
        self.logger.info("Full ingestion completed")

    def refresh_schema(self) -> None:
        tables = []
        for schema_file in self._iter_schema_files():
            tables.extend(schema_parser.parse_schema_file(schema_file))
        if tables:
            upsert_schema(self.graph, tables)
            self.logger.info("Schema ingestion: %s tables", len(tables))
        else:
            self.logger.info(
                "Schema ingestion: no tables detected (paths=%s)",
                ", ".join(self.paths["schema"]),
            )

    def refresh_requirements(self) -> None:
        if self._llm_enabled():
            self.logger.info("Deterministic requirements ingestion skipped (LLM enabled)")
            return

        all_requirements = []
        for directory in self._iter_requirement_dirs():
            all_requirements.extend(requirement_parser.parse_requirements(directory))
        tables = load_tables(self.graph)
        columns_by_table = load_columns(self.graph)
        if all_requirements:
            upsert_requirements(self.graph, all_requirements, tables, columns_by_table)
            self.logger.info("Requirements ingestion: %s requirements", len(all_requirements))
        else:
            self.logger.info(
                "Requirements ingestion: none detected (paths=%s)",
                ", ".join(self.paths["requirements"]),
            )

    def refresh_policies(self) -> None:
        if self._llm_enabled():
            self.logger.info("Deterministic policies ingestion skipped (LLM enabled)")
            return

        all_policies = []
        for directory in self._iter_policy_dirs():
            all_policies.extend(policy_parser.parse_policies(directory))
        if all_policies:
            upsert_policies(self.graph, all_policies)
            self.logger.info("Policies ingestion: %s policies", len(all_policies))
        else:
            self.logger.info(
                "Policies ingestion: none detected (paths=%s)",
                ", ".join(self.paths["policies"]),
            )

    def refresh_code(self) -> None:
        tables = load_tables(self.graph)
        columns_by_table = load_columns(self.graph)

        total_files = 0
        parsed_files = 0
        for full_path, rel_path in self._iter_code_files():
            total_files += 1
            index_identifiers = self._should_index_identifiers(full_path)
            try:
                parsed = code_parser.parse_file(full_path, collect_identifiers=index_identifiers)
            except Exception as exc:  # pragma: no cover - defensive logging
                self.logger.error("Failed to parse %s: %s", full_path, exc)
                continue

            if not parsed:
                continue

            identifier_names: tuple[str, ...] = tuple()
            if index_identifiers:
                identifier_names = parsed.identifiers
                if self.identifier_max_count > 0 and len(identifier_names) > self.identifier_max_count:
                    self.logger.info("Skipping identifier indexing for %s: %d identifiers exceeds limit %d", full_path, len(identifier_names), self.identifier_max_count)
                    identifier_names = tuple()

            parsed_files += 1
            upsert_code_file(
                self.graph,
                rel_path,
                parsed,
                self.config.project_root,
                self.config.aliases,
                self.extensions,
                self.config.ignore,
                identifier_names=identifier_names,
            )

            with open(full_path, "r", encoding="utf-8", errors="ignore") as handle:
                content = handle.read()
            link_tables_for_file(self.graph, rel_path, content, tables, columns_by_table)

        self.graph.cleanup_orphan_apis()
        self.graph.cleanup_orphan_identifiers()
        self.logger.info("Code ingestion: parsed %s/%s files", parsed_files, total_files)

    def update_code_file(self, full_path: str) -> None:
        if not os.path.isfile(full_path):
            return
        rel_path = ensure_relative(full_path, self.config.project_root)
        if is_ignored(rel_path, self.config.ignore):
            return

        index_identifiers = self._should_index_identifiers(full_path)
        try:
            parsed = code_parser.parse_file(full_path, collect_identifiers=index_identifiers)
        except Exception as exc:  # pragma: no cover - defensive logging
            self.logger.error("Failed to parse %s: %s", full_path, exc)
            return

        if not parsed:
            return

        identifier_names: tuple[str, ...] = tuple()
        if index_identifiers:
            identifier_names = parsed.identifiers
            if self.identifier_max_count > 0 and len(identifier_names) > self.identifier_max_count:
                self.logger.info("Skipping identifier indexing for %s: %d identifiers exceeds limit %d", full_path, len(identifier_names), self.identifier_max_count)
                identifier_names = tuple()

        upsert_code_file(
            self.graph,
            rel_path,
            parsed,
            self.config.project_root,
            self.config.aliases,
            self.extensions,
            self.config.ignore,
            identifier_names=identifier_names,
        )

        tables = load_tables(self.graph)
        columns_by_table = load_columns(self.graph)
        with open(full_path, "r", encoding="utf-8", errors="ignore") as handle:
            content = handle.read()
        link_tables_for_file(self.graph, rel_path, content, tables, columns_by_table)

        self.graph.cleanup_orphan_apis()
        self.graph.cleanup_orphan_identifiers()

    def delete_code_file(self, full_path: str) -> None:
        rel_path = ensure_relative(full_path, self.config.project_root)
        self.graph.delete_file(normalize_path(rel_path))
        self.graph.cleanup_orphan_apis()
        self.graph.cleanup_orphan_identifiers()

    def update_schema_file(self, full_path: str) -> None:
        tables = schema_parser.parse_schema_file(full_path)
        if tables:
            upsert_schema(self.graph, tables)
            self.logger.info("Schema updated: %s", full_path)

    def update_requirements_dir(self, directory: str) -> None:
        if self._llm_enabled():
            self.logger.info("Deterministic requirements update skipped (LLM enabled)")
            return

        requirements = requirement_parser.parse_requirements(directory)
        if requirements:
            tables = load_tables(self.graph)
            columns_by_table = load_columns(self.graph)
            upsert_requirements(self.graph, requirements, tables, columns_by_table)
            self.logger.info("Requirements updated: %s", directory)

    def update_policies_dir(self, directory: str) -> None:
        if self._llm_enabled():
            self.logger.info("Deterministic policies update skipped (LLM enabled)")
            return

        policies = policy_parser.parse_policies(directory)
        if policies:
            upsert_policies(self.graph, policies)
            self.logger.info("Policies updated: %s", directory)
