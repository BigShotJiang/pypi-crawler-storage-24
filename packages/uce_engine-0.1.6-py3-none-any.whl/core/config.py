import os
from dataclasses import dataclass
from typing import Any

try:
    import yaml
except ImportError as exc:  # pragma: no cover - explicit runtime guidance
    raise ImportError(
        "PyYAML is required. Install with `pip install pyyaml`."
    ) from exc


@dataclass(frozen=True)
class Neo4jConfig:
    uri: str
    user: str
    password: str


@dataclass(frozen=True)
class PathsConfig:
    code: tuple[str, ...]
    schema: tuple[str, ...]
    requirements: tuple[str, ...]
    policies: tuple[str, ...]
    identifiers: tuple[str, ...]


@dataclass(frozen=True)
class LlmIngestConfig:
    enabled: bool
    requirements: bool
    policies: bool


@dataclass(frozen=True)
class UceConfig:
    project_root: str
    languages: tuple[str, ...]
    paths: PathsConfig
    ignore: tuple[str, ...]
    aliases: dict[str, str]
    neo4j: Neo4jConfig
    llm: LlmIngestConfig


def _as_tuple(value: Any) -> tuple[str, ...]:
    if value is None:
        return tuple()
    if isinstance(value, (list, tuple)):
        return tuple(str(v) for v in value if v is not None)
    return (str(value),)


def _as_bool(value: Any, default: bool) -> bool:
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return value != 0
    if isinstance(value, str):
        cleaned = value.strip().lower()
        if cleaned in {"1", "true", "yes", "y", "on"}:
            return True
        if cleaned in {"0", "false", "no", "n", "off"}:
            return False
    return default


def _env_bool(name: str) -> bool | None:
    if name not in os.environ:
        return None
    return _as_bool(os.getenv(name), False)


def _normalize_path(root: str, path: str) -> str:
    joined = os.path.abspath(os.path.join(root, path))
    return os.path.normpath(joined)


def load_config(config_path: str, project_root_override: str | None = None) -> UceConfig:
    if not os.path.exists(config_path):
        raise FileNotFoundError(f"Config not found: {config_path}")

    with open(config_path, "r", encoding="utf-8") as handle:
        raw = yaml.safe_load(handle) or {}

    config_dir = os.path.dirname(os.path.abspath(config_path))

    project_root = project_root_override or raw.get("project_root") or "."
    project_root = os.path.expanduser(str(project_root))
    if not os.path.isabs(project_root):
        project_root = os.path.abspath(os.path.join(config_dir, project_root))
    else:
        project_root = os.path.abspath(project_root)

    languages = _as_tuple(raw.get("languages") or [])
    languages = tuple(sorted({lang.lower() for lang in languages}))

    paths_raw = raw.get("paths") or {}
    paths = PathsConfig(
        code=_as_tuple(paths_raw.get("code") or ["."]),
        schema=_as_tuple(paths_raw.get("schema") or ["db"]),
        requirements=_as_tuple(paths_raw.get("requirements") or ["artifacts/requirements"]),
        policies=_as_tuple(paths_raw.get("policies") or ["artifacts/policies"]),
        identifiers=_as_tuple(paths_raw.get("identifiers") or []),
    )

    ignore = _as_tuple(raw.get("ignore") or [])

    aliases = {str(k): str(v) for k, v in (raw.get("aliases") or {}).items()}

    llm_raw = raw.get("llm") or {}
    llm_enabled = _as_bool(llm_raw.get("enabled"), False)
    llm_requirements = _as_bool(llm_raw.get("requirements"), True)
    llm_policies = _as_bool(llm_raw.get("policies"), True)

    env_llm_enabled = _env_bool("UCE_LLM_INGEST")
    if env_llm_enabled is not None:
        llm_enabled = env_llm_enabled
    env_llm_requirements = _env_bool("UCE_LLM_REQUIREMENTS")
    if env_llm_requirements is not None:
        llm_requirements = env_llm_requirements
    env_llm_policies = _env_bool("UCE_LLM_POLICIES")
    if env_llm_policies is not None:
        llm_policies = env_llm_policies

    llm = LlmIngestConfig(
        enabled=llm_enabled,
        requirements=llm_requirements,
        policies=llm_policies,
    )

    neo4j_raw = raw.get("neo4j") or {}
    env_uri = os.getenv("NEO4J_URI")
    env_user = os.getenv("NEO4J_USER") or os.getenv("NEO4J_USERNAME")
    env_pass = os.getenv("NEO4J_PASSWORD") or os.getenv("NEO4J_PASS")
    neo4j = Neo4jConfig(
        uri=str(env_uri or neo4j_raw.get("uri") or "bolt://localhost:7687"),
        user=str(env_user or neo4j_raw.get("user") or "neo4j"),
        password=str(env_pass or neo4j_raw.get("password") or "password"),
    )

    return UceConfig(
        project_root=project_root,
        languages=languages,
        paths=paths,
        ignore=ignore,
        aliases=aliases,
        neo4j=neo4j,
        llm=llm,
    )


def resolve_paths(config: UceConfig) -> dict[str, tuple[str, ...]]:
    root = config.project_root
    return {
        "code": tuple(_normalize_path(root, p) for p in config.paths.code),
        "schema": tuple(_normalize_path(root, p) for p in config.paths.schema),
        "requirements": tuple(_normalize_path(root, p) for p in config.paths.requirements),
        "policies": tuple(_normalize_path(root, p) for p in config.paths.policies),
        "identifiers": tuple(_normalize_path(root, p) for p in config.paths.identifiers),
    }
