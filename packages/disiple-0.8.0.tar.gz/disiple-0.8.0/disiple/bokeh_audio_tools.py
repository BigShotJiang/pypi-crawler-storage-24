from bokeh.core.properties import Bool, Float, Seq
from bokeh.models import Tool


class AudioPlayerTool(Tool):
    __implementation__ = 'bokeh_audio_tools.ts'
    samplerate = Float(default=44100)
    samples = Seq(Float, default=[])
    normalize = Bool(default=False)
    dynamic_audio = Bool(default=True)
