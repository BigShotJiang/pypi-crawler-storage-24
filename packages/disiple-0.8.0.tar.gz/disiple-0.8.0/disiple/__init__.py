"""A lightweight package aimed at teaching DSP with Jupyter Notebooks"""

__version__ = '0.8.0'
