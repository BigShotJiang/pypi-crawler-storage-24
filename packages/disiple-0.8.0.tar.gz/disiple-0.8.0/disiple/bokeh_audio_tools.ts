import {GestureTool, GestureToolView} from "models/tools/gestures/gesture_tool"
import {TapEvent} from "core/ui_events"
import {GlyphRenderer} from "models/renderers/glyph_renderer"
import * as p from "core/properties"


export class AudioPlayerToolView extends GestureToolView {
  declare model: AudioPlayerTool;
  private _canvas: HTMLCanvasElement;
  private _animFrameId: number = 0;

  override initialize(): void {
    super.initialize();
    this._canvas = document.createElement("canvas");
    this._canvas.style.cssText = "position:fixed; pointer-events:none; z-index:9999; visibility:hidden;";
    document.body.appendChild(this._canvas);
  }

  private _drawPlayhead(xPixel?: number): void {
    this._canvas.style.visibility = xPixel != null ? "visible" : "hidden";
    if (xPixel == null) return;
    const ctx = this._canvas.getContext("2d")!;
    ctx.clearRect(0, 0, this._canvas.width, this._canvas.height);
    ctx.strokeStyle = "#ff4000";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(xPixel, 0);
    ctx.lineTo(xPixel, this._canvas.height);
    ctx.stroke();
  }

  private _startAnimation(startOffset: number): void {
    window.cancelAnimationFrame(this._animFrameId);
    const {audioContext, buffer, playStart} = this.model;
    const frame = this.plot_view.frame;

    const rect = this.plot_view.canvas_view.el.getBoundingClientRect();
    const bb = frame.bbox;
    this._canvas.width  = Math.round(bb.width);
    this._canvas.height = Math.round(bb.height);
    this._canvas.style.left   = `${Math.round(rect.left + bb.left)}px`;
    this._canvas.style.top    = `${Math.round(rect.top  + bb.top)}px`;
    this._canvas.style.width  = `${Math.round(bb.width)}px`;
    this._canvas.style.height = `${Math.round(bb.height)}px`;

    const tick = () => {
      const elapsed = (audioContext!.currentTime - playStart + startOffset) % buffer!.duration;

      if (!this.model.sourceNode) {
        this._drawPlayhead();
        this._animFrameId = 0;
        return;
      }

      this._drawPlayhead(frame.x_scale.compute(elapsed) - bb.left);
      this._animFrameId = window.requestAnimationFrame(tick);
    };

    this._animFrameId = window.requestAnimationFrame(tick);
  }

  private _stopAnimation(): void {
    window.cancelAnimationFrame(this._animFrameId);
    this._animFrameId = 0;
    this._drawPlayhead();
    this.model.sourceNode?.stop();
  }

  override _tap(event: TapEvent): void {
    const {samplerate, samples} = this.model;
    const audioContext = this.model.audioContext ?? (this.model.audioContext = new AudioContext());

    if (this.model.buffer == null || this.model.dynamic_audio) {
      let bufferData: number[];
      if (samples.length > 0) {
        bufferData = samples;
      } else if (this.plot_view.model.data_renderers.length > 0) {
        bufferData = (this.plot_view.model.data_renderers[0] as GlyphRenderer).data_source.get_array<number>('y');
        if (bufferData.length === 0) return;
      } else {
        return;
      }
      if (this.model.normalize) {
        const maxAmp = Math.max(...bufferData.map(Math.abs));
        bufferData = bufferData.map(i => i / maxAmp);
      }
      this.model.buffer = audioContext.createBuffer(1, bufferData.length, samplerate);
      this.model.buffer.copyToChannel(Float32Array.from(bufferData), 0);
    }
    this._stopAnimation();

    this.model.sourceNode = new AudioBufferSourceNode(audioContext, {buffer: this.model.buffer, loop: event.modifiers.shift});
    this.model.sourceNode.connect(audioContext.destination);
    this.model.sourceNode.onended = () => { if (!event.modifiers.shift) this._stopAnimation(); };
    const startOffset = event.modifiers.alt ? this.plot_view.frame.x_scale.invert(event.sx) : 0;
    this.model.sourceNode.start(audioContext.currentTime, startOffset);
    this.model.playStart = audioContext.currentTime;
    this._startAnimation(startOffset);
  }

  override _doubletap(_: TapEvent): void {
    this._stopAnimation();
  }

  override remove(): void {
    this._stopAnimation();
    this._canvas.remove();
    super.remove();
  }
}

export namespace AudioPlayerTool {
  export type Attrs = p.AttrsOf<Props>
  export type Props = GestureTool.Props & {
    samplerate: p.Property<number>,
    samples: p.Property<number[]>,
    normalize: p.Property<boolean>,
    dynamic_audio: p.Property<boolean>,
  }
}

export interface AudioPlayerTool extends AudioPlayerTool.Attrs {}

export class AudioPlayerTool extends GestureTool {
  declare properties: AudioPlayerTool.Props;
  declare __view_type__: AudioPlayerToolView;
  audioContext: AudioContext | null = null;
  buffer: AudioBuffer | null = null;
  sourceNode: AudioBufferSourceNode | null = null;
  playStart: number = 0;

  static {
    this.prototype.default_view = AudioPlayerToolView;

    this.define<AudioPlayerTool.Props>(({Number, Array, Boolean}) => ({
      samplerate: [Number, 44100],
      samples: [Array(Number), []],
      normalize: [Boolean, false],
      dynamic_audio: [Boolean, true],
    }))
  }

  override tool_name = "Play Audio";
  override tool_icon = "bk-tool-icon-caret-right";
  override event_type = "tap" as "tap";
  override default_order = 12;
}
