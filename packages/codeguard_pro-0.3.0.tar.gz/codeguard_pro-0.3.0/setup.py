from pathlib import Path
from setuptools import setup

README = Path(__file__).with_name("README.md").read_text(encoding="utf-8")

setup(
    name="codeguard-pro",
    version="0.3.0",
    description="Inline security gate for AI coding agents: secrets, supply chain, OWASP, and MiniMax-assisted deep analysis.",
    author="Miles",
    url="https://github.com/Miles0sage/codeguard-mcp",
    long_description=README,
    long_description_content_type="text/markdown",
    py_modules=[
        "secret_scanner",
        "hook",
        "cli",
        "server",
        "tools_review",
        "tools_security",
        "supply_chain",
        "autofix",
        "agent_analyzer",
        "learning_loop",
    ],
    entry_points={
        "console_scripts": [
            "codeguard=cli:main",
        ],
    },
    python_requires=">=3.10",
    install_requires=[
        "mcp[cli]>=1.0.0",
        "requests>=2.31.0",
    ],
    classifiers=[
        "Development Status :: 4 - Beta",
        "Topic :: Security",
        "Topic :: Software Development :: Quality Assurance",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
    ],
)
