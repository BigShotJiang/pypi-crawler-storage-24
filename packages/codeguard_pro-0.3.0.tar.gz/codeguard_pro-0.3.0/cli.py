#!/usr/bin/env python3
"""CodeGuard Pro CLI — Install, scan, and protect your code.

Usage:
    codeguard init [--policy]  Initialize CodeGuard in current repo
    codeguard install          Install pre-commit hook in current repo
    codeguard scan <path>      Scan a file or directory for secrets
    codeguard scan-diff        Scan staged git diff for secrets
    codeguard learn-add        Save a suspicious sample for later review
    codeguard learn-report     Generate an issue-ready markdown report
    codeguard learn-summary    Summarize the local learning corpus
    codeguard uninstall        Remove pre-commit hook
"""

import os
import sys
import stat
import json
import shutil
import subprocess
import argparse

CODEGUARD_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, CODEGUARD_DIR)

HOOK_SCRIPT = f'''#!/usr/bin/env python3
"""CodeGuard Pro pre-commit hook — auto-installed."""
import sys
sys.path.insert(0, "{CODEGUARD_DIR}")
from hook import main
main()
'''

RED = "\033[91m"
GREEN = "\033[92m"
YELLOW = "\033[93m"
BOLD = "\033[1m"
RESET = "\033[0m"


def find_git_root() -> str:
    """Find the .git directory from current working directory."""
    cwd = os.getcwd()
    while cwd != "/":
        if os.path.isdir(os.path.join(cwd, ".git")):
            return cwd
        cwd = os.path.dirname(cwd)
    return ""


def cmd_install():
    """Install the pre-commit hook."""
    git_root = find_git_root()
    if not git_root:
        print(f"{RED}Error: Not a git repository.{RESET}")
        sys.exit(1)

    hooks_dir = os.path.join(git_root, ".git", "hooks")
    os.makedirs(hooks_dir, exist_ok=True)

    hook_path = os.path.join(hooks_dir, "pre-commit")

    # Back up existing hook
    if os.path.exists(hook_path):
        backup = hook_path + ".backup"
        shutil.copy2(hook_path, backup)
        print(f"{YELLOW}Existing hook backed up to {backup}{RESET}")

    with open(hook_path, "w") as f:
        f.write(HOOK_SCRIPT)

    os.chmod(hook_path, os.stat(hook_path).st_mode | stat.S_IEXEC)

    print(f"{GREEN}{BOLD}CodeGuard Pro installed.{RESET}")
    print(f"Hook: {hook_path}")
    print(f"Every commit will be scanned for secrets automatically.")


def cmd_uninstall():
    """Remove the pre-commit hook."""
    git_root = find_git_root()
    if not git_root:
        print(f"{RED}Error: Not a git repository.{RESET}")
        sys.exit(1)

    hook_path = os.path.join(git_root, ".git", "hooks", "pre-commit")
    backup = hook_path + ".backup"

    if os.path.exists(hook_path):
        os.remove(hook_path)
        print(f"{GREEN}CodeGuard Pro hook removed.{RESET}")

        if os.path.exists(backup):
            shutil.move(backup, hook_path)
            print(f"Restored previous hook from backup.")
    else:
        print("No hook found.")


def cmd_scan(path: str):
    """Scan a file or directory for secrets."""
    from secret_scanner import scan_secrets, format_findings

    if os.path.isfile(path):
        with open(path, "r", errors="ignore") as f:
            code = f.read()
        findings = scan_secrets(code, path)
        print(f"{BOLD}Scan: {path}{RESET}\n")
        print(format_findings(findings, block_mode=False))
        if findings:
            sys.exit(1)
    elif os.path.isdir(path):
        total_findings = []
        files_scanned = 0
        skip_dirs = {'.git', 'node_modules', '__pycache__', '.venv', 'venv', 'dist', 'build', '.next'}
        skip_ext = {'.pyc', '.whl', '.so', '.dll', '.png', '.jpg', '.gif', '.ico', '.svg',
                    '.woff', '.ttf', '.mp3', '.mp4', '.zip', '.tar', '.gz', '.lock'}

        for root, dirs, files in os.walk(path):
            dirs[:] = [d for d in dirs if d not in skip_dirs]
            for fname in files:
                ext = os.path.splitext(fname)[1].lower()
                if ext in skip_ext:
                    continue
                fpath = os.path.join(root, fname)
                try:
                    with open(fpath, "r", errors="ignore") as f:
                        code = f.read()
                    findings = scan_secrets(code, fpath)
                    files_scanned += 1
                    for finding in findings:
                        total_findings.append((fpath, finding))
                except Exception:
                    continue

        print(f"{BOLD}Directory Scan: {path}{RESET}")
        print(f"Files scanned: {files_scanned}\n")

        if not total_findings:
            print(f"{GREEN}PASS — No secrets detected.{RESET}")
        else:
            critical = sum(1 for _, f in total_findings if f.severity == "CRITICAL")
            high = sum(1 for _, f in total_findings if f.severity == "HIGH")
            print(f"{RED}FOUND {len(total_findings)} secret(s){RESET}")
            print(f"  CRITICAL: {critical}")
            print(f"  HIGH:     {high}\n")

            for fpath, f in total_findings:
                rel = os.path.relpath(fpath, path)
                print(f"  [{f.severity}] {f.secret_type} in {rel}:{f.line}")
                print(f"    {f.matched}")
                print(f"    Fix: {f.fix}\n")

            sys.exit(1)
    else:
        print(f"{RED}Error: {path} not found.{RESET}")
        sys.exit(1)


POLICIES = {
    "minimal": {
        "block_on_critical": True,
        "block_on_high": False,
        "scan_secrets": True,
        "scan_owasp": False,
        "scan_packages": False,
        "autofix": False,
        "autofix_model": None,
    },
    "standard": {
        "block_on_critical": True,
        "block_on_high": False,
        "scan_secrets": True,
        "scan_owasp": True,
        "scan_packages": False,
        "autofix": False,
        "autofix_model": None,
    },
    "full": {
        "block_on_critical": True,
        "block_on_high": False,
        "scan_secrets": True,
        "scan_owasp": True,
        "scan_packages": True,
        "autofix": True,
        "autofix_model": "MiniMax-M2.7",
    },
}

SECRET_FILE_PATTERNS = [
    ".env",
    ".env.local",
    ".env.production",
    ".env.staging",
    "*.pem",
    "*.key",
    "*.p12",
    "*.pfx",
    "*.jks",
]


def _ensure_gitignore_patterns(git_root: str) -> list:
    """Add common secret file patterns to .gitignore if missing. Returns list of added patterns."""
    gitignore_path = os.path.join(git_root, ".gitignore")
    existing_lines = set()

    if os.path.exists(gitignore_path):
        with open(gitignore_path, "r") as f:
            existing_lines = {line.strip() for line in f.readlines()}

    added = []
    lines_to_add = []
    for pattern in SECRET_FILE_PATTERNS:
        if pattern not in existing_lines:
            lines_to_add.append(pattern)
            added.append(pattern)

    if lines_to_add:
        with open(gitignore_path, "a") as f:
            if existing_lines and "" not in existing_lines:
                f.write("\n")
            f.write("# CodeGuard Pro — secret file patterns\n")
            for line in lines_to_add:
                f.write(f"{line}\n")

    return added


def cmd_init(policy: str = "standard"):
    """Initialize CodeGuard Pro in current repo: hook + config + gitignore."""
    git_root = find_git_root()
    if not git_root:
        print(f"{RED}Error: Not a git repository. Run 'git init' first.{RESET}")
        sys.exit(1)

    print(f"{BOLD}CodeGuard Pro — Initializing ({policy} policy){RESET}\n")

    steps_done = []

    # 1. Install pre-commit hook (reuse existing logic)
    cmd_install()
    steps_done.append("Pre-commit hook installed")

    # 2. Create .codeguard.json config
    config = dict(POLICIES[policy])
    config_path = os.path.join(git_root, ".codeguard.json")

    if os.path.exists(config_path):
        print(f"{YELLOW}  .codeguard.json already exists — overwriting with {policy} policy{RESET}")

    with open(config_path, "w") as f:
        json.dump(config, f, indent=2)
        f.write("\n")
    steps_done.append(f".codeguard.json created ({policy} policy)")

    # 3. Git-track .codeguard.json
    try:
        subprocess.run(
            ["git", "add", ".codeguard.json"],
            capture_output=True, text=True, timeout=10, cwd=git_root,
        )
        steps_done.append(".codeguard.json added to git tracking")
    except Exception:
        print(f"{YELLOW}  Warning: Could not git add .codeguard.json{RESET}")

    # 4. Add secret file patterns to .gitignore
    added_patterns = _ensure_gitignore_patterns(git_root)
    if added_patterns:
        steps_done.append(f".gitignore updated (+{len(added_patterns)} patterns)")
        # Also stage .gitignore
        try:
            subprocess.run(
                ["git", "add", ".gitignore"],
                capture_output=True, text=True, timeout=10, cwd=git_root,
            )
        except Exception:
            pass
    else:
        steps_done.append(".gitignore already has secret patterns")

    # 5. Print summary
    print(f"\n{GREEN}{BOLD}Setup complete!{RESET}\n")
    for step in steps_done:
        print(f"  {GREEN}+{RESET} {step}")

    print(f"\n{BOLD}Policy: {policy}{RESET}")
    print(f"  Secrets scanning:  {'ON' if config.get('scan_secrets') else 'OFF'}")
    print(f"  OWASP scanning:    {'ON' if config.get('scan_owasp') else 'OFF'}")
    print(f"  Package scanning:  {'ON' if config.get('scan_packages') else 'OFF'}")
    print(f"  Auto-fix:          {'ON' if config.get('autofix') else 'OFF'}")
    if config.get('autofix_model'):
        print(f"  Auto-fix model:    {config['autofix_model']}")
    print(f"  Block on CRITICAL: {'YES' if config.get('block_on_critical') else 'NO'}")
    print(f"  Block on HIGH:     {'YES' if config.get('block_on_high') else 'NO'}")
    print(f"\nRun {BOLD}codeguard scan .{RESET} to scan your project now.")


def cmd_check(packages: list, registry: str = "pypi"):
    """Scan packages BEFORE installing — catches typosquats + suspicious packages."""
    from supply_chain import scan_pip_package, scan_npm_package

    scanner = scan_pip_package if registry == "pypi" else scan_npm_package
    blocked = []
    warnings = []

    print(f"{BOLD}CodeGuard Pre-Install Check ({registry}){RESET}\n")

    for pkg in packages:
        pkg = pkg.strip().split("==")[0].split(">=")[0].split("<=")[0].split("~=")[0]
        if not pkg:
            continue
        result = scanner(pkg)
        verdict = result.get("verdict", "ERROR")
        reasons = result.get("reasons", [])

        if verdict == "BLOCKED":
            print(f"  {RED}BLOCKED{RESET}  {pkg}")
            for r in reasons:
                print(f"           {r}")
            blocked.append(pkg)
        elif verdict == "WARNING":
            print(f"  {YELLOW}WARNING{RESET}  {pkg}")
            for r in reasons:
                print(f"           {r}")
            warnings.append(pkg)
        elif verdict == "SAFE":
            print(f"  {GREEN}SAFE{RESET}     {pkg}")
        else:
            print(f"  {YELLOW}?{RESET}        {pkg} ({verdict})")

    print()
    if blocked:
        print(f"{RED}{BOLD}BLOCKED: {len(blocked)} package(s) look dangerous.{RESET}")
        print(f"  {', '.join(blocked)}")
        print(f"\n  DO NOT install these. They may be typosquats or malicious.")
        sys.exit(1)
    elif warnings:
        print(f"{YELLOW}WARNING: {len(warnings)} package(s) flagged.{RESET}")
        print(f"  Proceed with caution.")
    else:
        print(f"{GREEN}All {len(packages)} package(s) look safe to install.{RESET}")


def cmd_scan_diff():
    """Scan staged diff for secrets."""
    from hook import get_staged_diff
    from secret_scanner import scan_diff, format_findings

    diff = get_staged_diff()
    if not diff:
        print("No staged changes found.")
        return

    findings = scan_diff(diff)
    print(f"{BOLD}Staged Diff Scan{RESET}\n")
    print(format_findings(findings, block_mode=False))


def cmd_learn_add(sample_path: str, title: str, language: str = "python", source: str = "manual", expected_behavior: str = ""):
    """Store a suspicious sample in the review corpus."""
    from agent_analyzer import deep_analyze
    from learning_loop import record_candidate

    if not os.path.isfile(sample_path):
        print(f"{RED}Error: {sample_path} not found.{RESET}")
        sys.exit(1)

    with open(sample_path, "r", errors="ignore") as f:
        code = f.read()

    ai_result = deep_analyze(code, language)
    result = record_candidate(
        title=title,
        code=code,
        language=language,
        source=source,
        expected_behavior=expected_behavior,
        regex_findings=[f for f in ai_result.get("findings", []) if f.get("source") == "[REGEX]"],
        ai_findings=[f for f in ai_result.get("findings", []) if f.get("source") == "[AI-BETA]"],
    )
    print(json.dumps(result, indent=2))


def cmd_learn_report(candidate_path: str):
    """Generate issue-ready markdown for a stored learning sample."""
    from learning_loop import generate_issue_markdown

    if not os.path.isfile(candidate_path):
        print(f"{RED}Error: {candidate_path} not found.{RESET}")
        sys.exit(1)
    print(json.dumps(generate_issue_markdown(candidate_path), indent=2))


def cmd_learn_summary(corpus_dir: str = "learning"):
    """Summarize the local learning corpus."""
    from learning_loop import corpus_summary
    print(json.dumps(corpus_summary(corpus_dir), indent=2))


def main():
    parser = argparse.ArgumentParser(
        prog="codeguard",
        description="CodeGuard Pro — Stop secrets from reaching git."
    )
    sub = parser.add_subparsers(dest="command")

    init_p = sub.add_parser("init", help="Initialize CodeGuard in repo")
    init_p.add_argument(
        "--policy", choices=["minimal", "standard", "full"],
        default="standard",
        help="Security policy level (default: standard)"
    )

    sub.add_parser("install", help="Install pre-commit hook")
    sub.add_parser("uninstall", help="Remove pre-commit hook")

    scan_p = sub.add_parser("scan", help="Scan file or directory")
    scan_p.add_argument("path", help="File or directory to scan")

    sub.add_parser("scan-diff", help="Scan staged git diff")

    check_p = sub.add_parser("check", help="Scan packages BEFORE installing")
    check_p.add_argument("packages", nargs="+", help="Package names to check")
    check_p.add_argument("--npm", action="store_true", help="Check npm instead of pip")

    learn_add_p = sub.add_parser("learn-add", help="Add suspicious sample to learning corpus")
    learn_add_p.add_argument("sample_path", help="Path to the suspicious sample file")
    learn_add_p.add_argument("--title", required=True, help="Short title for the sample")
    learn_add_p.add_argument("--language", default="python", help="Source language")
    learn_add_p.add_argument("--source", default="manual", help="Where the sample came from")
    learn_add_p.add_argument("--expected", default="", help="Expected detector behavior")

    learn_report_p = sub.add_parser("learn-report", help="Generate issue-ready markdown from a candidate")
    learn_report_p.add_argument("candidate_path", help="Path to learning candidate JSON")

    learn_summary_p = sub.add_parser("learn-summary", help="Summarize the learning corpus")
    learn_summary_p.add_argument("--corpus-dir", default="learning", help="Learning corpus directory")

    args = parser.parse_args()

    if args.command == "init":
        cmd_init(args.policy)
    elif args.command == "install":
        cmd_install()
    elif args.command == "uninstall":
        cmd_uninstall()
    elif args.command == "scan":
        cmd_scan(args.path)
    elif args.command == "scan-diff":
        cmd_scan_diff()
    elif args.command == "check":
        cmd_check(args.packages, registry="npm" if args.npm else "pypi")
    elif args.command == "learn-add":
        cmd_learn_add(args.sample_path, args.title, args.language, args.source, args.expected)
    elif args.command == "learn-report":
        cmd_learn_report(args.candidate_path)
    elif args.command == "learn-summary":
        cmd_learn_summary(args.corpus_dir)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
