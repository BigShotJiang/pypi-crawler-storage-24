"""Hyper-V hypervisor driver."""

from collections.abc import Sequence
from pathlib import Path

import psrp

from ..base.hypervisor import Hypervisor
from ..base.storage import Storage
from .base import HyperVirtualDriver
from .vm import HyperVirtualMachine


class HyperVirtualHost(Hypervisor[psrp.WSManInfo], HyperVirtualDriver):
    """Driver for managing Hyper-V server."""

    async def _connect(self) -> None:
        """Get driver object."""
        self.conn = psrp.WSManInfo(
            server=f'https://{self.host}:5986/wsman',
            auth='basic',
            username=self.auth.user,
            password=self.auth.password,
        )

    async def _close(self) -> None: ...

    async def get_vm(self, vm_id: str) -> HyperVirtualMachine:
        async with self.get_ps() as ps:
            ps.add_command('Get-VM')
            ps.add_parameter('Id', vm_id)
            result = await self.exec_ps(ps)

        return HyperVirtualMachine(conn=self.conn, id=str(result[0].Id))

    async def get_vms(self) -> list[HyperVirtualMachine]:
        async with self.get_ps() as ps:
            ps.add_command('Get-VM')
            ps.add_command('Select')
            ps.add_parameter('Property', 'Id')
            result = await self.exec_ps(ps)

        return [HyperVirtualMachine(conn=self.conn, id=str(r.Id)) for r in result]

    async def import_vm(self, source: str, storage: str, name: str) -> str:
        virtual_machine_path = snapshot_file_path = Path(f'{storage}:') / 'hyperv' / name
        vhd_destination_path = virtual_machine_path / 'Virtual Hard Disks'
        source_path = Path(source) / 'Virtual Machines'

        async with self.get_ps() as ps:
            ps.add_command('Get-ChildItem')
            ps.add_parameters(Path=str(source_path), Filter='*.vmcx')
            ps.add_parameter('Recurse', True)
            result = await self.exec_ps(ps)
        vmcx_path = result[0].FullName

        async with self.get_ps() as ps:
            ps.add_command('Import-VM')
            ps.add_parameters(
                Path=vmcx_path,
                GenerateNewId=True,
                Copy=True,
                VirtualMachinePath=str(virtual_machine_path),
                VhdDestinationPath=str(vhd_destination_path),
                SnapshotFilePath=str(snapshot_file_path),
            )
            ps.add_command('Rename-VM')
            ps.add_parameters(NewName=name, Passthru=True)
            ps.add_command('Select')
            ps.add_parameter('Property', 'Id')
            result = await self.exec_ps(ps)
        return str(result[0].Id)

    async def storages(self) -> Sequence[Storage]:
        async with self.get_ps() as ps:
            ps.add_command('Get-WmiObject')
            ps.add_argument('win32_logicaldisk')
            result = await self.exec_ps(ps)
        storages = []
        for s in result:
            if s.DriveType != 3:
                continue
            storages.append(Storage(name=s.DeviceID[0], size=s.Size, free=s.FreeSpace))
        return storages
