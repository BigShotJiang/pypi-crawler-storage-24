"""Hypervisors management module."""

from abc import ABC, abstractmethod
from collections.abc import Sequence
from types import TracebackType
from typing import TYPE_CHECKING, Literal, Self, overload

from .base import AuthData, HypervisorPlatform
from .storage import Storage
from .vm import VirtualMachine

if TYPE_CHECKING:
    from ..hyperv.hypervisor import HyperVirtualHost
    from ..kvm.hypervisor import KernelVirtualHost


class Hypervisor[TConn](ABC):
    """Essential class for managing the hypervisor."""

    conn: TConn

    def __init__(self, host: str, auth: AuthData) -> None:
        self.host = host
        self.auth = auth

    async def __aenter__(self) -> Self:
        await self._connect()
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        await self._close()

    @overload
    @classmethod
    def connect(cls, platform: Literal[HypervisorPlatform.KVM], host: str, auth: AuthData) -> 'KernelVirtualHost': ...

    @overload
    @classmethod
    def connect(cls, platform: Literal[HypervisorPlatform.HYPERV], host: str, auth: AuthData) -> 'HyperVirtualHost': ...

    @classmethod
    def connect(
        cls,
        platform: HypervisorPlatform,
        host: str,
        auth: AuthData,
    ) -> 'Hypervisor':
        if platform is HypervisorPlatform.KVM:
            from ..kvm.hypervisor import KernelVirtualHost

            return KernelVirtualHost(host=host, auth=auth)

        if platform is HypervisorPlatform.HYPERV:
            from ..hyperv.hypervisor import HyperVirtualHost

            return HyperVirtualHost(host=host, auth=auth)

        msg = 'Unknown platform'
        raise ValueError(msg)

    async def close(self) -> None:
        await self._close()

    @abstractmethod
    async def _connect(self) -> None:
        pass

    @abstractmethod
    async def _close(self) -> None:
        pass

    @abstractmethod
    async def get_vms(self) -> Sequence[VirtualMachine]:
        pass

    @abstractmethod
    async def storages(self) -> Sequence[Storage]:
        pass

    @abstractmethod
    async def import_vm(self, source: str, storage: str, name: str) -> str:
        """Import a virtual machine from the source."""
