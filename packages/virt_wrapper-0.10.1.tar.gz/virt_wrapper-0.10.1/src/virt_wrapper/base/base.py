"""Base module."""

from dataclasses import dataclass
from enum import StrEnum, unique


@unique
class HypervisorPlatform(StrEnum):
    """Type of virtualization platform."""

    KVM = 'kvm'
    HYPERV = 'hyperv'


@dataclass(frozen=True, slots=True)
class AuthData:
    user: str
    password: str
