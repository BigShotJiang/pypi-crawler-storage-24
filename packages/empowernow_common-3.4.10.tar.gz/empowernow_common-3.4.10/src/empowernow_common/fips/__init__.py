"""
FIPS 140-3 Compliance Module

This module provides FIPS 140-3 compliant cryptographic operations and validation
based on the proven implementation from the EmpowerNow IdP.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

# NOTE: Keep imports lazy.
# This package is often imported transitively (e.g. via AuthZEN models), and
# eagerly importing cryptography-backed modules can break tooling on some
# platforms (notably coverage/pytest-cov on Windows with PyO3-based wheels).
if TYPE_CHECKING:
    from .algorithms import FIPSAlgorithms as FIPSAlgorithms  # noqa: F401
    from .entropy import FIPSCompliantRandom as FIPSCompliantRandom  # noqa: F401
    from .entropy import SecureRandomGenerator as SecureRandomGenerator  # noqa: F401
    from .validator import FIPSValidator as FIPSValidator  # noqa: F401
    from .validator import ensure_fips_compliance as ensure_fips_compliance  # noqa: F401
    from .validator import is_fips_mode as is_fips_mode  # noqa: F401


def __getattr__(name: str) -> Any:
    if name == "FIPSAlgorithms":
        from .algorithms import FIPSAlgorithms as _FIPSAlgorithms

        return _FIPSAlgorithms
    if name in {"FIPSValidator", "ensure_fips_compliance", "is_fips_mode"}:
        from .validator import (
            FIPSValidator as _FIPSValidator,
            ensure_fips_compliance as _ensure_fips_compliance,
            is_fips_mode as _is_fips_mode,
        )

        return {
            "FIPSValidator": _FIPSValidator,
            "ensure_fips_compliance": _ensure_fips_compliance,
            "is_fips_mode": _is_fips_mode,
        }[name]
    if name in {"SecureRandomGenerator", "FIPSCompliantRandom"}:
        from .entropy import (
            FIPSCompliantRandom as _FIPSCompliantRandom,
            SecureRandomGenerator as _SecureRandomGenerator,
        )

        return {
            "SecureRandomGenerator": _SecureRandomGenerator,
            "FIPSCompliantRandom": _FIPSCompliantRandom,
        }[name]
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

__all__ = [
    "FIPSAlgorithms",
    "FIPSValidator",
    "ensure_fips_compliance",
    "is_fips_mode",
    "SecureRandomGenerator",
    "FIPSCompliantRandom",
    "is_fips_runtime",
]

# ---------------------------------------------------------------------------
# Runtime helper — expose current FIPS mode (backlog 4.1)
# ---------------------------------------------------------------------------


def is_fips_runtime() -> bool:
    """Return *True* if the running OpenSSL backend reports FIPS mode enabled.

    The check is best-effort: if OpenSSL bindings are missing or do not expose
    `openssl_fips_mode()`, we fall back to *False*.
    """

    try:
        import ssl

        # OpenSSL 3.x provides FIPS provider; older versions expose FIPS_mode()
        if hasattr(ssl, "FIPS_mode"):
            return bool(ssl.FIPS_mode())  # type: ignore[attr-defined]

        # cryptography.io helper (OpenSSL 3)
        from cryptography.hazmat.bindings.openssl import binding  # type: ignore

        backend = binding.Binding()
        return backend.lib.EVP_default_properties_is_fips_enabled(None) == 1  # type: ignore[attr-defined]
    except Exception:
        return False
