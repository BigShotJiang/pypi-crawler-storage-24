"""
User OAuth Vault - Secure storage for user-bound OAuth tokens.

This package provides encrypted storage and lifecycle management for
user OAuth credentials across multiple external systems.

Features:
- FIPS 140-3 compliant AES-256-GCM encryption
- Multi-tenant isolation
- Refresh failure tracking with auto-reauth flagging
- Pluggable provider architecture

Quick Start:
    from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
    from sqlalchemy.orm import sessionmaker, declarative_base
    from empowernow_common.vault.user_oauth import (
        PostgresUserOAuthProvider,
        create_third_party_credential_model,
        UserOAuthCredential,
    )

    # Setup SQLAlchemy
    engine = create_async_engine("postgresql+asyncpg://...")
    async_session = sessionmaker(engine, class_=AsyncSession)
    Base = declarative_base()

    # Create model and provider
    ThirdPartyCredential = create_third_party_credential_model(Base)
    provider = PostgresUserOAuthProvider(
        session_factory=async_session,
        model_class=ThirdPartyCredential,
    )

    # Store credential from OAuth callback
    credential_id = await provider.store_credential(
        user_arn="arn:empowernow:user:123",
        system_key="salesforce",
        tokens={
            "access_token": "...",
            "refresh_token": "...",
            "expires_in": 3600,
            "token_type": "Bearer",
            "scope": "api refresh_token",
        },
        metadata={"instance_url": "https://myorg.salesforce.com"},
    )

    # Retrieve credential
    cred = await provider.get_credential(
        user_arn="arn:empowernow:user:123",
        system_key="salesforce",
    )

    if cred and cred.is_active:
        headers = {"Authorization": cred.to_auth_header()}
        # Make API call...

Environment Variables:
    CREDENTIAL_ENCRYPTION_KEY: Base64-encoded 32-byte AES key
    CREDENTIAL_ENCRYPTION_KEY_POINTER: Vault path to retrieve key
"""

from empowernow_common.vault.user_oauth.base import (
    BaseUserOAuthProvider,
    UserOAuthProviderCapabilities,
)
from empowernow_common.vault.user_oauth.types import (
    UserOAuthCredential,
    CredentialStatus,
)
from empowernow_common.vault.user_oauth.exceptions import (
    UserOAuthError,
    UserCredentialNotFoundError,
    CredentialDecryptionError,
    CredentialExpiredError,
    RefreshTokenRevokedError,
    CredentialStorageError,
    TokenRefreshError,
)
from empowernow_common.vault.user_oauth.models import (
    create_third_party_credential_model,
)
from empowernow_common.vault.user_oauth.providers.postgres import (
    PostgresUserOAuthProvider,
)
from empowernow_common.vault.user_oauth.metadata import (
    OAuthMetadataExtractor,
    OAuthMetadataExtractionError,
)
from empowernow_common.vault.user_oauth.refresh import (
    AutoTokenRefreshService,
    OAuthRefreshConfig,
)

__all__ = [
    # Base classes
    "BaseUserOAuthProvider",
    "UserOAuthProviderCapabilities",
    # Types
    "UserOAuthCredential",
    "CredentialStatus",
    # Exceptions
    "UserOAuthError",
    "UserCredentialNotFoundError",
    "CredentialDecryptionError",
    "CredentialExpiredError",
    "RefreshTokenRevokedError",
    "CredentialStorageError",
    "TokenRefreshError",
    # Providers
    "PostgresUserOAuthProvider",
    # Model factory
    "create_third_party_credential_model",
    # Metadata extraction
    "OAuthMetadataExtractor",
    "OAuthMetadataExtractionError",
    # Token refresh
    "AutoTokenRefreshService",
    "OAuthRefreshConfig",
]
