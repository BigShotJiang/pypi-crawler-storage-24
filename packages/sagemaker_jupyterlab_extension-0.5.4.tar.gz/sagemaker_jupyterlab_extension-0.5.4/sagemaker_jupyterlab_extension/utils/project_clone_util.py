import asyncio
import logging

from async_lru import alru_cache
from sagemaker_jupyterlab_extension_common.clients import (
    get_sagemaker_client,
    get_resource_groups_tagging_api_client,
    get_codecommit_client,
)

"""
This utlility file provides methods for validating Project Clone Plugin URL.  
The current TTL is set to 60 secs.
"""


@alru_cache(maxsize=1, ttl=60)
async def _get_projects_list():
    response = await get_sagemaker_client().list_projects()
    projects = response.get("ProjectSummaryList", [])
    projects_list = list(project["ProjectName"] for project in projects)
    return projects_list


async def _get_project_repository_urls(project_name: str):
    """
    Get all repository URLs for a given SageMaker project.

    Args:
        project_name: The name of the SageMaker project

    Returns:
        List of repository clone URLs (HTTP) associated with the project
    """
    try:
        # Get repository ARNs using Resource Groups Tagging API
        # Query for both CodeCommit and SageMaker Code Repositories
        tagging_client = get_resource_groups_tagging_api_client()
        tagging_response = await tagging_client.get_resources(
            ResourceTypeFilters=["codecommit", "sagemaker:code-repository"],
            TagFilters=[{"Key": "sagemaker:project-name", "Values": [project_name]}],
        )

        resource_list = tagging_response.get("ResourceTagMappingList", [])

        if not resource_list:
            logging.warning(f"No repositories found for project: {project_name}")
            return []

        # Separate CodeCommit and SageMaker repository ARNs
        codecommit_repo_names = []
        sagemaker_repo_names = []

        for resource in resource_list:
            arn = resource.get("ResourceARN", "")
            if not arn:
                continue

            # Parse ARN to determine repository type
            # ARN format: arn:aws:service:region:account:resource-type/resource-name
            arn_parts = arn.split(":")
            if len(arn_parts) >= 6:
                service = arn_parts[2]
                resource_part = arn_parts[5]

                logging.info(
                    f"ARN parts - service: {service}, resource_part: {resource_part}"
                )

                if service == "sagemaker" and resource_part.startswith(
                    "code-repository/"
                ):
                    # SageMaker Code Repository
                    repo_name = resource_part.split("/", 1)[1]
                    sagemaker_repo_names.append(repo_name)
                    logging.info(f"Found SageMaker repo: {repo_name}")
                elif service == "codecommit":
                    # CodeCommit Repository
                    repo_name = arn_parts[-1]
                    codecommit_repo_names.append(repo_name)
                    logging.info(f"Found CodeCommit repo: {repo_name}")

        clone_urls = []

        # Get CodeCommit repository details
        if codecommit_repo_names:
            codecommit_client = get_codecommit_client()
            repo_response = await codecommit_client.batch_get_repositories(
                repositoryNames=codecommit_repo_names
            )

            repositories = repo_response.get("repositories", [])

            # Extract clone URLs (HTTP)
            for repo in repositories:
                clone_url = repo.get("cloneUrlHttp")
                if clone_url:
                    clone_urls.append(clone_url)

        # Get SageMaker Code Repository details
        if sagemaker_repo_names:
            sagemaker_client = get_sagemaker_client()

            # Call describe_code_repository for each SageMaker repository
            for repo_name in sagemaker_repo_names:
                try:
                    repo_response = await sagemaker_client.describe_code_repository(
                        code_repository_name=repo_name
                    )

                    # Extract clone URL from GitConfig
                    git_config = repo_response.get("GitConfig", {})
                    clone_url = git_config.get("RepositoryUrl")
                    if clone_url:
                        clone_urls.append(clone_url)
                except Exception as error:
                    logging.error(
                        f"Failed to describe SageMaker repository {repo_name}: {error}"
                    )
                    # Continue processing other repositories

        return clone_urls

    except Exception as error:
        logging.error(
            f"Failed to get repository URLs for project {project_name}: {error}"
        )
        raise
