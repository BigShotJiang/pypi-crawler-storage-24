import json
import pytest
import asyncio

from unittest.mock import ANY, Mock, patch, MagicMock, AsyncMock
from sagemaker_jupyterlab_extension.utils.project_clone_util import (
    _get_projects_list,
    _get_project_repository_urls,
)

LIST_PROJECTS_TEST_RESPONSE = {
    "NextToken": "token",
    "ProjectSummaryList": [
        {
            "CreationTime": 12345,
            "ProjectArn": "arn:test-project",
            "ProjectDescription": "test project",
            "ProjectId": "test-project",
            "ProjectName": "test-project",
            "ProjectStatus": "CreateCompleted",
        }
    ],
}


TEST_LIST_PROJECTS_RESPONSE = ["test-project"]


# Test data for Resource Groups Tagging API response
GET_RESOURCES_TEST_RESPONSE = {
    "ResourceTagMappingList": [
        {
            "ResourceARN": "arn:aws:codecommit:us-west-2:123456789012:sagemaker-test-project-modelbuild",
            "Tags": [
                {"Key": "sagemaker:project-name", "Value": "test-project"},
                {"Key": "sagemaker:project-id", "Value": "p-abc123"},
            ],
        },
        {
            "ResourceARN": "arn:aws:codecommit:us-west-2:123456789012:sagemaker-test-project-modeldeploy",
            "Tags": [
                {"Key": "sagemaker:project-name", "Value": "test-project"},
                {"Key": "sagemaker:project-id", "Value": "p-abc123"},
            ],
        },
        {
            "ResourceARN": "arn:aws:codecommit:us-west-2:123456789012:sagemaker-test-project-modelmonitor",
            "Tags": [
                {"Key": "sagemaker:project-name", "Value": "test-project"},
                {"Key": "sagemaker:project-id", "Value": "p-abc123"},
            ],
        },
    ]
}


# Test data for CodeCommit batch_get_repositories response
BATCH_GET_REPOSITORIES_TEST_RESPONSE = {
    "repositories": [
        {
            "accountId": "123456789012",
            "repositoryId": "repo-id-1",
            "repositoryName": "sagemaker-test-project-modelbuild",
            "repositoryDescription": "Model build repository",
            "defaultBranch": "main",
            "cloneUrlHttp": "https://git-codecommit.us-west-2.amazonaws.com/v1/repos/sagemaker-test-project-modelbuild",
            "cloneUrlSsh": "ssh://git-codecommit.us-west-2.amazonaws.com/v1/repos/sagemaker-test-project-modelbuild",
            "Arn": "arn:aws:codecommit:us-west-2:123456789012:sagemaker-test-project-modelbuild",
        },
        {
            "accountId": "123456789012",
            "repositoryId": "repo-id-2",
            "repositoryName": "sagemaker-test-project-modeldeploy",
            "repositoryDescription": "Model deploy repository",
            "defaultBranch": "main",
            "cloneUrlHttp": "https://git-codecommit.us-west-2.amazonaws.com/v1/repos/sagemaker-test-project-modeldeploy",
            "cloneUrlSsh": "ssh://git-codecommit.us-west-2.amazonaws.com/v1/repos/sagemaker-test-project-modeldeploy",
            "Arn": "arn:aws:codecommit:us-west-2:123456789012:sagemaker-test-project-modeldeploy",
        },
        {
            "accountId": "123456789012",
            "repositoryId": "repo-id-3",
            "repositoryName": "sagemaker-test-project-modelmonitor",
            "repositoryDescription": "Model monitor repository",
            "defaultBranch": "main",
            "cloneUrlHttp": "https://git-codecommit.us-west-2.amazonaws.com/v1/repos/sagemaker-test-project-modelmonitor",
            "cloneUrlSsh": "ssh://git-codecommit.us-west-2.amazonaws.com/v1/repos/sagemaker-test-project-modelmonitor",
            "Arn": "arn:aws:codecommit:us-west-2:123456789012:sagemaker-test-project-modelmonitor",
        },
    ],
    "repositoriesNotFound": [],
    "errors": [],
}


TEST_EXPECTED_REPOSITORY_URLS = [
    "https://git-codecommit.us-west-2.amazonaws.com/v1/repos/sagemaker-test-project-modelbuild",
    "https://git-codecommit.us-west-2.amazonaws.com/v1/repos/sagemaker-test-project-modeldeploy",
    "https://git-codecommit.us-west-2.amazonaws.com/v1/repos/sagemaker-test-project-modelmonitor",
]


class SageMakerClientMock:
    list_projects_response: any

    def __init__(self, list_projects_resp):
        self.list_projects_response = list_projects_resp

    async def list_projects(self):
        return self.list_projects_response


class ResourceGroupsTaggingAPIClientMock:
    get_resources_response: any

    def __init__(self, get_resources_resp):
        self.get_resources_response = get_resources_resp

    async def get_resources(self, ResourceTypeFilters=None, TagFilters=None):
        return self.get_resources_response


class CodeCommitClientMock:
    batch_get_repositories_response: any

    def __init__(self, batch_get_repositories_resp):
        self.batch_get_repositories_response = batch_get_repositories_resp

    async def batch_get_repositories(self, repositoryNames=None):
        return self.batch_get_repositories_response


@pytest.mark.asyncio
@patch("sagemaker_jupyterlab_extension.utils.project_clone_util.get_sagemaker_client")
async def test_get_domain_repositories(sagemaker_client_mock):
    sagemaker_client_mock.return_value = SageMakerClientMock(
        LIST_PROJECTS_TEST_RESPONSE
    )
    _get_projects_list.cache_clear()
    response = await _get_projects_list()
    assert response == TEST_LIST_PROJECTS_RESPONSE


@pytest.mark.asyncio
@patch("sagemaker_jupyterlab_extension.utils.project_clone_util.get_codecommit_client")
@patch(
    "sagemaker_jupyterlab_extension.utils.project_clone_util.get_resource_groups_tagging_api_client"
)
async def test_get_project_repository_urls_success(
    tagging_client_mock, codecommit_client_mock
):
    """Test successfully retrieving repository URLs for a project"""
    tagging_client_mock.return_value = ResourceGroupsTaggingAPIClientMock(
        GET_RESOURCES_TEST_RESPONSE
    )
    codecommit_client_mock.return_value = CodeCommitClientMock(
        BATCH_GET_REPOSITORIES_TEST_RESPONSE
    )

    response = await _get_project_repository_urls("test-project")

    assert response == TEST_EXPECTED_REPOSITORY_URLS
    assert len(response) == 3


@pytest.mark.asyncio
@patch("sagemaker_jupyterlab_extension.utils.project_clone_util.get_codecommit_client")
@patch(
    "sagemaker_jupyterlab_extension.utils.project_clone_util.get_resource_groups_tagging_api_client"
)
async def test_get_project_repository_urls_no_resources(
    tagging_client_mock, codecommit_client_mock
):
    """Test when no CodeCommit repositories are found for a project"""
    tagging_client_mock.return_value = ResourceGroupsTaggingAPIClientMock(
        {"ResourceTagMappingList": []}
    )

    response = await _get_project_repository_urls("nonexistent-project")

    assert response == []
    # CodeCommit client should not be called if no resources found
    codecommit_client_mock.return_value.batch_get_repositories.assert_not_called()


@pytest.mark.asyncio
@patch("sagemaker_jupyterlab_extension.utils.project_clone_util.get_codecommit_client")
@patch(
    "sagemaker_jupyterlab_extension.utils.project_clone_util.get_resource_groups_tagging_api_client"
)
async def test_get_project_repository_urls_empty_repositories(
    tagging_client_mock, codecommit_client_mock
):
    """Test when CodeCommit returns no repositories"""
    tagging_client_mock.return_value = ResourceGroupsTaggingAPIClientMock(
        GET_RESOURCES_TEST_RESPONSE
    )
    codecommit_client_mock.return_value = CodeCommitClientMock(
        {"repositories": [], "repositoriesNotFound": [], "errors": []}
    )

    response = await _get_project_repository_urls("test-project")

    assert response == []


@pytest.mark.asyncio
@patch("sagemaker_jupyterlab_extension.utils.project_clone_util.get_codecommit_client")
@patch(
    "sagemaker_jupyterlab_extension.utils.project_clone_util.get_resource_groups_tagging_api_client"
)
async def test_get_project_repository_urls_partial_results(
    tagging_client_mock, codecommit_client_mock
):
    """Test when some repositories don't have cloneUrlHttp"""
    tagging_client_mock.return_value = ResourceGroupsTaggingAPIClientMock(
        GET_RESOURCES_TEST_RESPONSE
    )

    # Response with one repository missing cloneUrlHttp
    partial_response = {
        "repositories": [
            {
                "repositoryName": "sagemaker-test-project-modelbuild",
                "cloneUrlHttp": "https://git-codecommit.us-west-2.amazonaws.com/v1/repos/sagemaker-test-project-modelbuild",
            },
            {
                "repositoryName": "sagemaker-test-project-modeldeploy",
                # Missing cloneUrlHttp
            },
        ],
        "repositoriesNotFound": [],
        "errors": [],
    }
    codecommit_client_mock.return_value = CodeCommitClientMock(partial_response)

    response = await _get_project_repository_urls("test-project")

    assert len(response) == 1
    assert (
        response[0]
        == "https://git-codecommit.us-west-2.amazonaws.com/v1/repos/sagemaker-test-project-modelbuild"
    )


@pytest.mark.asyncio
@patch("sagemaker_jupyterlab_extension.utils.project_clone_util.get_codecommit_client")
@patch(
    "sagemaker_jupyterlab_extension.utils.project_clone_util.get_resource_groups_tagging_api_client"
)
async def test_get_project_repository_urls_tagging_api_error(
    tagging_client_mock, codecommit_client_mock
):
    """Test error handling when Resource Groups Tagging API fails"""
    tagging_client_mock.return_value.get_resources = AsyncMock(
        side_effect=Exception("Tagging API error")
    )

    with pytest.raises(Exception) as exc_info:
        await _get_project_repository_urls("test-project")

    assert "Tagging API error" in str(exc_info.value)


@pytest.mark.asyncio
@patch("sagemaker_jupyterlab_extension.utils.project_clone_util.get_codecommit_client")
@patch(
    "sagemaker_jupyterlab_extension.utils.project_clone_util.get_resource_groups_tagging_api_client"
)
async def test_get_project_repository_urls_codecommit_error(
    tagging_client_mock, codecommit_client_mock
):
    """Test error handling when CodeCommit API fails"""
    tagging_client_mock.return_value = ResourceGroupsTaggingAPIClientMock(
        GET_RESOURCES_TEST_RESPONSE
    )
    codecommit_client_mock.return_value.batch_get_repositories = AsyncMock(
        side_effect=Exception("CodeCommit API error")
    )

    with pytest.raises(Exception) as exc_info:
        await _get_project_repository_urls("test-project")

    assert "CodeCommit API error" in str(exc_info.value)


@pytest.mark.asyncio
@patch("sagemaker_jupyterlab_extension.utils.project_clone_util.get_codecommit_client")
@patch(
    "sagemaker_jupyterlab_extension.utils.project_clone_util.get_resource_groups_tagging_api_client"
)
async def test_get_project_repository_urls_extracts_repo_names_correctly(
    tagging_client_mock, codecommit_client_mock
):
    """Test that repository names are correctly extracted from ARNs"""
    tagging_mock = ResourceGroupsTaggingAPIClientMock(GET_RESOURCES_TEST_RESPONSE)

    # Create a mock for batch_get_repositories that returns the expected response
    batch_get_mock = AsyncMock(return_value=BATCH_GET_REPOSITORIES_TEST_RESPONSE)

    # Create codecommit mock with the mocked method
    codecommit_mock = Mock()
    codecommit_mock.batch_get_repositories = batch_get_mock

    tagging_client_mock.return_value = tagging_mock
    codecommit_client_mock.return_value = codecommit_mock

    await _get_project_repository_urls("test-project")

    # Verify that batch_get_repositories was called with correct repository names
    batch_get_mock.assert_called_once()
    call_args = batch_get_mock.call_args
    repo_names = call_args.kwargs.get("repositoryNames", [])

    expected_repo_names = [
        "sagemaker-test-project-modelbuild",
        "sagemaker-test-project-modeldeploy",
        "sagemaker-test-project-modelmonitor",
    ]

    assert set(repo_names) == set(expected_repo_names)
