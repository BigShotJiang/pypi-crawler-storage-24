# Copyright 2025-2026 Hanlian Lu. SPDX-License-Identifier: Apache-2.0
"""Tests for VisualRetriever: KG retrieval, visual resolution, reranking, answer generation."""

from __future__ import annotations

import base64
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock, patch

import httpx

from dlightrag.unifiedrepresent.retriever import VisualRetriever

GRAPH_FIELD_SEP = "<SEP>"

# A tiny valid PNG (1x1 transparent pixel) encoded as base64.
_TINY_PNG_B64 = base64.b64encode(
    b"\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR\x00\x00\x00\x01"
    b"\x00\x00\x00\x01\x08\x06\x00\x00\x00\x1f\x15\xc4\x89"
    b"\x00\x00\x00\nIDATx\x9cc\x00\x01\x00\x00\x05\x00\x01"
    b"\r\n\xb4\x00\x00\x00\x00IEND\xaeB`\x82"
).decode()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_config() -> SimpleNamespace:
    return SimpleNamespace(default_mode="mix", top_k=60, chunk_top_k=10)


def _make_lightrag_result() -> dict:
    """Return a mock aquery_data result with entities, relationships, chunks."""
    return {
        "data": {
            "entities": [
                {
                    "entity_name": "E1",
                    "entity_type": "CONCEPT",
                    "description": "First entity",
                    "source_id": "chunk-abc",
                },
            ],
            "relationships": [
                {
                    "src_id": "E1",
                    "tgt_id": "E2",
                    "description": "relates to",
                    "source_id": f"chunk-abc{GRAPH_FIELD_SEP}chunk-def",
                },
            ],
            "chunks": [
                {
                    "chunk_id": "chunk-abc",
                    "content": "text from chunk abc",
                    "reference_id": "1",
                    "file_path": "/test/doc.pdf",
                },
            ],
        },
    }


def _make_visual_data() -> list[dict | None]:
    """Visual data list aligned with chunk_id_list from _make_lightrag_result.

    The lightrag result yields chunk IDs: {chunk-abc, chunk-def}.
    get_by_ids is called with a list of those IDs; we return data for both.
    """
    return [
        {
            "image_data": _TINY_PNG_B64,
            "page_index": 0,
            "full_doc_id": "doc-1",
            "file_path": "/test/doc.pdf",
            "doc_title": "Test",
        },
        {
            "image_data": _TINY_PNG_B64,
            "page_index": 1,
            "full_doc_id": "doc-1",
            "file_path": "/test/doc.pdf",
            "doc_title": "Test",
        },
    ]


def _make_retriever(
    *,
    rerank_model: str | None = None,
    rerank_base_url: str | None = None,
    rerank_api_key: str | None = None,
    rerank_backend: str | None = None,
    vision_model_func: AsyncMock | None = None,
    visual_data: list[dict | None] | None = None,
) -> VisualRetriever:
    lightrag = MagicMock()
    lightrag.aquery_data = AsyncMock(return_value=_make_lightrag_result())
    # Backfill lookup for entity/relationship chunks missing text
    lightrag.text_chunks.get_by_ids = AsyncMock(
        return_value=[{"content": "backfilled text", "file_path": "/test/doc.pdf"}],
    )

    visual_chunks = MagicMock()
    visual_chunks.get_by_ids = AsyncMock(
        return_value=visual_data if visual_data is not None else _make_visual_data(),
    )

    return VisualRetriever(
        lightrag=lightrag,
        visual_chunks=visual_chunks,
        config=_make_config(),
        vision_model_func=vision_model_func,
        rerank_model=rerank_model,
        rerank_base_url=rerank_base_url,
        rerank_api_key=rerank_api_key,
        rerank_backend=rerank_backend,
    )


# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
# TestRetrieve
# ---------------------------------------------------------------------------


class TestRetrieve:
    """Test retrieve() — Phases 1-3 without reranking."""

    async def test_returned_structure(self) -> None:
        retriever = _make_retriever()
        result = await retriever.retrieve("What is E1?")

        # Top-level keys
        assert "contexts" in result

        # Contexts sub-keys
        assert "entities" in result["contexts"]
        assert "relationships" in result["contexts"]
        assert "chunks" in result["contexts"]

    async def test_entities_passed_through(self) -> None:
        retriever = _make_retriever()
        result = await retriever.retrieve("What is E1?")
        entities = result["contexts"]["entities"]
        assert len(entities) == 1
        assert entities[0]["entity_name"] == "E1"

    async def test_relationships_passed_through(self) -> None:
        retriever = _make_retriever()
        result = await retriever.retrieve("What is E1?")
        rels = result["contexts"]["relationships"]
        assert len(rels) == 1
        assert rels[0]["src_id"] == "E1"
        assert rels[0]["tgt_id"] == "E2"

    async def test_chunk_ids_extracted_from_all_sources(self) -> None:
        """chunk-abc comes from chunks + entities; chunk-def from relationships."""
        retriever = _make_retriever()
        await retriever.retrieve("query")

        # get_by_ids should be called with a list containing both chunk IDs
        call_args = retriever.visual_chunks.get_by_ids.call_args
        chunk_id_list = call_args[0][0]
        assert set(chunk_id_list) == {"chunk-abc", "chunk-def"}

    async def test_resolved_chunks_in_output(self) -> None:
        retriever = _make_retriever()
        result = await retriever.retrieve("query")
        chunks = result["contexts"]["chunks"]
        # Both chunks resolved
        assert len(chunks) == 2
        # chunk-abc has reference_id="1" from chunks; chunk-def has "" (entity-sourced)
        for chunk in chunks:
            assert "chunk_id" in chunk
            assert "reference_id" in chunk
            assert "file_path" in chunk
            assert "page_idx" in chunk
        chunk_ids = {c["chunk_id"] for c in chunks}
        assert chunk_ids == {"chunk-abc", "chunk-def"}

    async def test_chunks_contain_image_data(self) -> None:
        retriever = _make_retriever()
        result = await retriever.retrieve("query")
        chunks = result["contexts"]["chunks"]
        assert len(chunks) == 2
        assert all(c["image_data"] is not None for c in chunks)

    async def test_none_visual_data_filtered(self) -> None:
        """Visual chunks returning None for some IDs should be filtered out."""
        retriever = _make_retriever(
            visual_data=[
                {
                    "image_data": _TINY_PNG_B64,
                    "page_index": 0,
                    "full_doc_id": "doc-1",
                    "file_path": "/test/doc.pdf",
                    "doc_title": "Test",
                },
                None,  # chunk-def not found
            ]
        )
        result = await retriever.retrieve("query")
        chunks = result["contexts"]["chunks"]
        assert len(chunks) == 1


# ---------------------------------------------------------------------------
# TestRetrieveNoRerank
# ---------------------------------------------------------------------------


class TestRetrieveNoRerank:
    """Without rerank_model, resolved should be truncated to chunk_top_k."""

    async def test_truncated_to_chunk_top_k(self) -> None:
        # Create visual data with more items than chunk_top_k=2
        many_chunks = {
            "data": {
                "entities": [],
                "relationships": [],
                "chunks": [
                    {
                        "chunk_id": f"c-{i}",
                        "content": f"text {i}",
                        "reference_id": "1",
                        "file_path": "/test/doc.pdf",
                    }
                    for i in range(5)
                ],
            },
        }
        visual_data_list = [
            {
                "image_data": f"img{i}",
                "page_index": i,
                "full_doc_id": "doc-1",
                "file_path": "/test/doc.pdf",
                "doc_title": "Test",
            }
            for i in range(5)
        ]

        lightrag = MagicMock()
        lightrag.aquery_data = AsyncMock(return_value=many_chunks)
        lightrag.text_chunks.get_by_ids = AsyncMock(return_value=[])

        visual_chunks = MagicMock()
        visual_chunks.get_by_ids = AsyncMock(return_value=visual_data_list)

        retriever = VisualRetriever(
            lightrag=lightrag,
            visual_chunks=visual_chunks,
            config=_make_config(),
            vision_model_func=None,
            rerank_model=None,
        )

        result = await retriever.retrieve("query", chunk_top_k=2)
        assert len(result["contexts"]["chunks"]) == 2


# ---------------------------------------------------------------------------
# TestVisualRerank
# ---------------------------------------------------------------------------


class TestVisualRerank:
    """Test _visual_rerank HTTP call and sorting."""

    async def test_reranking_sorts_by_relevance(self) -> None:
        retriever = _make_retriever(
            rerank_model="reranker-v1",
            rerank_base_url="http://localhost:8080",
            rerank_api_key="key-123",
        )

        resolved = {
            "c-0": {"image_data": "img0"},
            "c-1": {"image_data": "img1"},
            "c-2": {"image_data": "img2"},
        }

        mock_response = MagicMock()
        mock_response.json.return_value = {
            "results": [
                {"index": 2, "relevance_score": 0.95},
                {"index": 0, "relevance_score": 0.80},
                {"index": 1, "relevance_score": 0.60},
            ],
        }
        mock_response.raise_for_status = MagicMock()

        with patch("httpx.AsyncClient") as mock_client_cls:
            mock_client = AsyncMock()
            mock_client.post.return_value = mock_response
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=False)
            mock_client_cls.return_value = mock_client

            result = await retriever._visual_rerank("query", resolved, top_k=3)

        # Sorted descending by relevance_score
        keys = list(result.keys())
        assert keys == ["c-2", "c-0", "c-1"]
        assert result["c-2"]["relevance_score"] == 0.95
        assert result["c-0"]["relevance_score"] == 0.80
        assert result["c-1"]["relevance_score"] == 0.60

    async def test_reranking_respects_top_k(self) -> None:
        retriever = _make_retriever(
            rerank_model="reranker-v1",
            rerank_base_url="http://localhost:8080",
        )

        resolved = {
            "c-0": {"image_data": "img0"},
            "c-1": {"image_data": "img1"},
            "c-2": {"image_data": "img2"},
        }

        mock_response = MagicMock()
        mock_response.json.return_value = {
            "results": [
                {"index": 2, "relevance_score": 0.95},
                {"index": 0, "relevance_score": 0.80},
                {"index": 1, "relevance_score": 0.60},
            ],
        }
        mock_response.raise_for_status = MagicMock()

        with patch("httpx.AsyncClient") as mock_client_cls:
            mock_client = AsyncMock()
            mock_client.post.return_value = mock_response
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=False)
            mock_client_cls.return_value = mock_client

            result = await retriever._visual_rerank("query", resolved, top_k=2)

        assert len(result) == 2

    async def test_reranking_failure_returns_unranked(self) -> None:
        retriever = _make_retriever(
            rerank_model="reranker-v1",
            rerank_base_url="http://localhost:8080",
        )

        resolved = {
            "c-0": {},
            "c-1": {},
            "c-2": {},
        }

        with patch("httpx.AsyncClient") as mock_client_cls:
            mock_client = AsyncMock()
            mock_client.post.side_effect = httpx.HTTPError("connection refused")
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=False)
            mock_client_cls.return_value = mock_client

            result = await retriever._visual_rerank("query", resolved, top_k=2)

        # Fallback: first top_k items by insertion order
        assert len(result) == 2
        assert list(result.keys()) == ["c-0", "c-1"]

    async def test_text_fallback_from_chunk_text(self) -> None:
        """Chunks without image_data should use chunk_text for rerank documents."""
        retriever = _make_retriever(
            rerank_model="reranker-v1",
            rerank_base_url="http://localhost:8080",
        )

        resolved = {
            "c-0": {"image_data": "img0"},
            "c-1": {},  # no image — should fall back to chunk_text
        }
        chunk_text = {"c-1": "text description of page"}

        mock_response = MagicMock()
        mock_response.json.return_value = {
            "results": [
                {"index": 0, "relevance_score": 0.9},
                {"index": 1, "relevance_score": 0.7},
            ],
        }
        mock_response.raise_for_status = MagicMock()

        with patch("httpx.AsyncClient") as mock_client_cls:
            mock_client = AsyncMock()
            mock_client.post.return_value = mock_response
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=False)
            mock_client_cls.return_value = mock_client

            await retriever._visual_rerank("query", resolved, top_k=2, chunk_text=chunk_text)

        payload = mock_client.post.call_args[1]["json"]
        docs = payload["documents"]
        assert docs[0]["type"] == "image_url"  # c-0 has image
        assert docs[1] == "text description of page"  # c-1 falls back to text

    async def test_empty_resolved_returns_empty(self) -> None:
        retriever = _make_retriever(
            rerank_model="reranker-v1",
            rerank_base_url="http://localhost:8080",
        )
        result = await retriever._visual_rerank("query", {}, top_k=5)
        assert result == {}

    async def test_rerank_sends_correct_payload(self) -> None:
        retriever = _make_retriever(
            rerank_model="reranker-v1",
            rerank_base_url="http://localhost:8080/v1",
            rerank_api_key="secret",
        )

        resolved = {
            "c-0": {"image_data": "imgdata"},
        }

        mock_response = MagicMock()
        mock_response.json.return_value = {
            "results": [{"index": 0, "relevance_score": 0.9}],
        }
        mock_response.raise_for_status = MagicMock()

        with patch("httpx.AsyncClient") as mock_client_cls:
            mock_client = AsyncMock()
            mock_client.post.return_value = mock_response
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=False)
            mock_client_cls.return_value = mock_client

            await retriever._visual_rerank("my query", resolved, top_k=5)

        # Verify the POST call
        call_kwargs = mock_client.post.call_args
        assert call_kwargs[0][0] == "http://localhost:8080/v1/rerank"
        payload = call_kwargs[1]["json"]
        assert payload["model"] == "reranker-v1"
        assert payload["query"] == "my query"
        assert len(payload["documents"]) == 1
        assert payload["documents"][0]["type"] == "image_url"
        headers = call_kwargs[1]["headers"]
        assert headers["Authorization"] == "Bearer secret"


# ---------------------------------------------------------------------------
# TestParseRerankScore
# ---------------------------------------------------------------------------


class TestParseRerankScore:
    """Test _parse_rerank_score static method: parsing, clamping, edge cases."""

    def test_valid_float(self) -> None:
        assert VisualRetriever._parse_rerank_score("0.8") == 0.8

    def test_valid_decimal(self) -> None:
        assert VisualRetriever._parse_rerank_score("0.75") == 0.75

    def test_whitespace_stripped(self) -> None:
        assert VisualRetriever._parse_rerank_score("  0.9 \n") == 0.9

    def test_non_numeric_returns_zero(self) -> None:
        assert VisualRetriever._parse_rerank_score("This page is very relevant") == 0.0

    def test_clamped_above_one(self) -> None:
        assert VisualRetriever._parse_rerank_score("1.5") == 1.0

    def test_clamped_below_zero(self) -> None:
        assert VisualRetriever._parse_rerank_score("-0.3") == 0.0

    def test_json_schema_output(self) -> None:
        assert VisualRetriever._parse_rerank_score('{"score": 0.62}') == 0.62

    def test_thinking_with_trailing_score(self) -> None:
        text = "<think>analysis about figure 10 and section 4.4</think>\n\n0.0<|im_end|>\n"
        assert VisualRetriever._parse_rerank_score(text) == 0.0

    def test_thinking_with_nonzero_score(self) -> None:
        text = "<think>relevant content found</think>\n\n0.85<|im_end|>\n"
        assert VisualRetriever._parse_rerank_score(text) == 0.85

    def test_none_returns_zero(self) -> None:
        assert VisualRetriever._parse_rerank_score(None) == 0.0  # type: ignore[arg-type]


# ---------------------------------------------------------------------------
# TestLlmVisualRerank
# ---------------------------------------------------------------------------


class TestLlmVisualRerank:
    """Test _llm_visual_rerank: VLM pointwise scoring, sorting, error handling."""

    async def test_sorts_by_score_descending(self) -> None:
        call_count = 0

        async def mock_vision(prompt, **kwargs):
            nonlocal call_count
            scores = ["0.3", "0.9", "0.6"]
            result = scores[call_count]
            call_count += 1
            return result

        img = _TINY_PNG_B64
        resolved = {
            "chunk-a": {"image_data": img},
            "chunk-b": {"image_data": img},
            "chunk-c": {"image_data": img},
        }

        ret = _make_retriever(
            vision_model_func=mock_vision,
            rerank_backend="llm",
        )
        result = await ret._llm_visual_rerank("test query", resolved, top_k=2)

        # Should return 2 chunks, highest scores first
        assert len(result) == 2
        scores_out = [v["relevance_score"] for v in result.values()]
        assert scores_out == sorted(scores_out, reverse=True)
        # chunk-b scored 0.9, chunk-c scored 0.6 — those are the top 2
        assert list(result.keys()) == ["chunk-b", "chunk-c"]

    async def test_no_image_no_text_scores_zero(self) -> None:
        """No image_data and no chunk_text → score 0, VLM not called."""
        resolved = {
            "chunk-a": {},  # no image_data key
        }
        vision_func = AsyncMock(return_value="0.8")
        ret = _make_retriever(vision_model_func=vision_func, rerank_backend="llm")

        result = await ret._llm_visual_rerank("query", resolved, top_k=5)
        assert result["chunk-a"]["relevance_score"] == 0.0
        vision_func.assert_not_awaited()

    async def test_text_fallback_when_no_image(self) -> None:
        """No image_data but chunk_text available → VLM scores via text."""
        resolved = {
            "chunk-a": {},  # no image_data
        }
        vision_func = AsyncMock(return_value="0.7")
        ret = _make_retriever(vision_model_func=vision_func, rerank_backend="llm")

        result = await ret._llm_visual_rerank(
            "query", resolved, top_k=5, chunk_text={"chunk-a": "page text"}
        )
        assert result["chunk-a"]["relevance_score"] == 0.7
        vision_func.assert_awaited_once()

    async def test_vision_error_scores_zero(self) -> None:
        resolved = {
            "chunk-a": {"image_data": _TINY_PNG_B64},
        }
        vision_func = AsyncMock(side_effect=RuntimeError("API timeout"))
        ret = _make_retriever(vision_model_func=vision_func, rerank_backend="llm")

        result = await ret._llm_visual_rerank("query", resolved, top_k=5)
        assert result["chunk-a"]["relevance_score"] == 0.0


# ---------------------------------------------------------------------------
# TestRerankRouting
# ---------------------------------------------------------------------------


class TestRerankRouting:
    """Test Phase 3 routing: rerank_backend selects correct rerank path."""

    def test_llm_backend_with_vision_func(self) -> None:
        ret = _make_retriever(
            rerank_backend="llm",
            vision_model_func=AsyncMock(),
        )
        assert ret.rerank_backend == "llm"
        assert ret.vision_model_func is not None

    def test_api_backend_with_base_url(self) -> None:
        ret = _make_retriever(
            rerank_backend="cohere",
            rerank_model="rerank-v4",
            rerank_base_url="https://api.cohere.com/v2",
        )
        assert ret.rerank_backend == "cohere"
        assert ret.rerank_base_url is not None
