"""Module-level gateway client -- auto-configured from environment.

Usage in script tools:
    from mcpgateway_sdk import gateway

    result = await gateway.execute_tool("SALESFORCE__opps_list", {"query": "test"})
"""

from mcpgateway_sdk.client import GatewayClient

gateway = GatewayClient()
