"""MCP Gateway SDK -- async client for script tool sandboxes."""

from mcpgateway_sdk.client import GatewayClient

__all__ = ["GatewayClient"]
__version__ = "0.1.0"
