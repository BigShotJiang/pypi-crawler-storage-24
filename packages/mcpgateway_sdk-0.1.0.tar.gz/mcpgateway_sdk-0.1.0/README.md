# mcpgateway-sdk

Async Python SDK for MCP Gateway script tool sandboxes.

## Installation

```bash
pip install mcpgateway-sdk
```

## Usage

```python
from mcpgateway_sdk.client import GatewayClient

async with GatewayClient() as gw:
    result = await gw.execute_tool("SALESFORCE__opps_list", {"query": "test"})
    tools = await gw.search_tools("pipeline management")
    await gw.cache_set("key", {"data": 42}, ttl=300)
    cached = await gw.cache_get("key")
```

The client auto-configures from environment variables:

- `MCPGATEWAY_TOKEN` -- Bearer token for authentication
- `MCPGATEWAY_URL` -- Gateway base URL (default: `http://localhost:8000`)

## Module-level client

For convenience in script tools, a pre-configured singleton is available:

```python
from mcpgateway_sdk.gateway import gateway

result = await gateway.execute_tool("SALESFORCE__opps_list")
```
