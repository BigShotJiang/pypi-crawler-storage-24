import json
from pathlib import Path
from typing import Any, Dict, List, Optional

import requests

from worldjen._config import _config


def _headers() -> Dict[str, str]:
    api_key = _config.api_key
    if not api_key:
        raise RuntimeError(
            "worldjen.config(api_key=...) or WORLDJEN_API_KEY must be set"
        )
    return {
        "X-API-Key": api_key,
        "Content-Type": "application/json",
    }


def _raise_for_response(response: requests.Response, context: str) -> None:
    if not response.ok:
        try:
            detail = response.json().get("detail", response.text)
        except Exception:
            detail = response.text
        raise RuntimeError(f"{context}: {detail}")


def create_run(
    name: str,
    dimensions: List[str],
    run_instructions: Optional[Dict[str, Any]] = None,
    model_id: Optional[str] = None,
    runner_id: Optional[str] = None,
) -> str:
    url = f"{_config.api_url}/api/v1/runs"
    runner_id_val = (runner_id or "").strip() or None
    model_id_val = (model_id or "").strip() or None

    if runner_id_val and not model_id_val:
        raise ValueError("model_id is required when runner_id is set")

    if runner_id_val and model_id_val:
        payload: Dict[str, Any] = {
            "name": name,
            "runner_id": runner_id_val,
            "model_id": model_id_val,
            "run_instructions": _json_sanitize(
                run_instructions if run_instructions is not None else {}
            ),
            "evaluate_config": {"dimensions": dimensions},
        }
    else:
        payload = {
            "name": name,
            "dimensions": dimensions,
        }
        if run_instructions is not None:
            payload["run_instructions"] = _json_sanitize(run_instructions)
        if model_id_val is not None:
            payload["model_id"] = model_id_val
    response = requests.post(
        url, json=payload, headers=_headers(), timeout=_config.timeout
    )
    _raise_for_response(response, "Create run failed")
    data = response.json()
    run_id = data.get("run_id") or data.get("id") or data.get("_id")
    if not run_id:
        raise RuntimeError("Create run: response missing run id")
    return str(run_id)


def update_run_status(
    run_id: str,
    status: str,
    error_message: Optional[str] = None,
) -> None:
    url = f"{_config.api_url}/api/v1/runs/{run_id}"
    payload: Dict[str, Any] = {"status": status}
    if error_message is not None:
        payload["errorMessage"] = error_message
    response = requests.patch(
        url, json=payload, headers=_headers(), timeout=_config.timeout
    )
    _raise_for_response(response, "Update run status failed")


def get_run(run_id: str) -> Dict[str, Any]:
    url = f"{_config.api_url}/api/v1/runs/{run_id}"
    response = requests.get(url, headers=_headers(), timeout=_config.timeout)
    _raise_for_response(response, "Get run failed")
    return response.json()


def list_runs(
    status: Optional[str] = None,
    page: int = 1,
    limit: int = 50,
) -> Dict[str, Any]:
    params: List[str] = [f"page={page}", f"limit={limit}"]
    if status:
        params.append(f"status={status}")
    url = f"{_config.api_url}/api/v1/runs?{'&'.join(params)}"
    response = requests.get(url, headers=_headers(), timeout=_config.timeout)
    _raise_for_response(response, "List runs failed")
    return response.json()


def cancel_run(run_id: str) -> None:
    url = f"{_config.api_url}/api/v1/runs/{run_id}/cancel"
    response = requests.post(url, headers=_headers(), timeout=_config.timeout)
    _raise_for_response(response, "Cancel run failed")


def delete_run(run_id: str) -> None:
    url = f"{_config.api_url}/api/v1/runs/{run_id}"
    response = requests.delete(url, headers=_headers(), timeout=_config.timeout)
    _raise_for_response(response, "Delete run failed")


def get_run_logs(run_id: str) -> Dict[str, Any]:
    url = f"{_config.api_url}/api/v1/runs/{run_id}/logs"
    response = requests.get(url, headers=_headers(), timeout=_config.timeout)
    _raise_for_response(response, "Get run logs failed")
    return response.json()


def get_run_csv(run_id: str) -> bytes:
    url = f"{_config.api_url}/api/v1/runs/{run_id}/csv"
    response = requests.get(url, headers=_headers(), timeout=_config.timeout)
    _raise_for_response(response, "Get run CSV failed")
    return response.content


def get_run_videos(run_id: str) -> List[Dict[str, Any]]:
    url = f"{_config.api_url}/api/v1/runs/{run_id}/videos"
    response = requests.get(url, headers=_headers(), timeout=_config.timeout)
    _raise_for_response(response, "Get run videos failed")
    data = response.json()
    return data if isinstance(data, list) else data.get("videos", [])


def append_run_logs(run_id: str, logs: str) -> None:
    url = f"{_config.api_url}/api/v1/runner/runs/{run_id}/logs"
    response = requests.post(
        url, json={"logs": logs}, headers=_headers(), timeout=_config.timeout
    )
    _raise_for_response(response, "Append run logs failed")


def get_upload_url(run_id: str, file_name: str, content_type: str = "video/mp4") -> Dict[str, Any]:
    url = f"{_config.api_url}/api/v1/runner/runs/videos/upload-url"
    payload: Dict[str, Any] = {"runId": run_id, "fileName": file_name, "contentType": content_type}
    response = requests.post(
        url, json=payload, headers=_headers(), timeout=_config.timeout
    )
    _raise_for_response(response, "Get upload URL failed")
    return response.json()


def upload_to_presigned(
    upload_url: str,
    file_path: Any,
    content_type: str = "video/mp4",
) -> None:
    path = Path(file_path) if not isinstance(file_path, Path) else file_path
    with open(path, "rb") as f:
        body = f.read()
    response = requests.put(
        upload_url,
        data=body,
        headers={"Content-Type": content_type},
        timeout=_config.timeout,
    )
    if not response.ok:
        raise RuntimeError(f"Upload to presigned URL failed: {response.status_code} {response.text}")


def confirm_upload(
    run_id: str,
    video_id: str,
    file_name: str,
    s3_key: str,
    prompt: Optional[str] = None,
    dimension_ids: Optional[List[str]] = None,
    source: str = "sdk",
) -> Dict[str, Any]:
    url = f"{_config.api_url}/api/v1/runner/runs/videos/confirm-upload"
    payload: Dict[str, Any] = {
        "runId": run_id,
        "videoId": video_id,
        "fileName": file_name,
        "s3Key": s3_key,
        "source": source,
    }
    if prompt is not None:
        payload["prompt"] = prompt
    if dimension_ids is not None:
        payload["dimensionIds"] = dimension_ids
    response = requests.post(
        url, json=payload, headers=_headers(), timeout=_config.timeout
    )
    _raise_for_response(response, "Confirm upload failed")
    return response.json()


def list_user_models(sort_by: Optional[str] = None) -> List[Dict[str, Any]]:
    url = f"{_config.api_url}/api/v1/models"
    if sort_by:
        url += f"?sortBy={sort_by}"
    response = requests.get(url, headers=_headers(), timeout=_config.timeout)
    _raise_for_response(response, "List user models failed")
    data = response.json()
    return data if isinstance(data, list) else data.get("models", [])


def list_base_models(sort_by: Optional[str] = None) -> List[Dict[str, Any]]:
    url = f"{_config.api_url}/api/v1/models/base"
    if sort_by:
        url += f"?sortBy={sort_by}"
    response = requests.get(url, headers=_headers(), timeout=_config.timeout)
    _raise_for_response(response, "List base models failed")
    data = response.json()
    return data if isinstance(data, list) else data.get("models", [])


def list_ref_models(sort_by: Optional[str] = None) -> List[Dict[str, Any]]:
    url = f"{_config.api_url}/api/v1/models/ref"
    if sort_by:
        url += f"?sortBy={sort_by}"
    response = requests.get(url, headers=_headers(), timeout=_config.timeout)
    _raise_for_response(response, "List reference models failed")
    data = response.json()
    return data if isinstance(data, list) else data.get("models", [])


def create_model(
    name: str,
    provider: str,
    hf_repo_id: str,
    model_type: str,
    encrypted_tokens: Optional[List[Dict[str, str]]] = None,
) -> Dict[str, Any]:
    """Create a user model. For private repos, pass encrypted_tokens (from encrypt_token_for_runners) or use the dashboard."""
    url = f"{_config.api_url}/api/v1/models"
    payload: Dict[str, Any] = {
        "name": name,
        "provider": provider,
        "hfRepoId": hf_repo_id,
        "type": model_type,
    }
    if encrypted_tokens:
        payload["encryptedTokens"] = encrypted_tokens
    response = requests.post(
        url, json=payload, headers=_headers(), timeout=_config.timeout
    )
    _raise_for_response(response, "Create model failed")
    return response.json()


def delete_model(model_id: str) -> None:
    url = f"{_config.api_url}/api/v1/models/{model_id}"
    response = requests.delete(url, headers=_headers(), timeout=_config.timeout)
    _raise_for_response(response, "Delete model failed")


def list_api_keys() -> List[Dict[str, Any]]:
    url = f"{_config.api_url}/api/v1/api-keys"
    response = requests.get(url, headers=_headers(), timeout=_config.timeout)
    _raise_for_response(response, "List API keys failed")
    data = response.json()
    keys = data.get("keys", data) if isinstance(data, dict) else data
    return keys if isinstance(keys, list) else []


def list_dimensions() -> List[Dict[str, Any]]:
    url = f"{_config.api_url}/api/v1/dimensions"
    response = requests.get(url, headers=_headers(), timeout=_config.timeout)
    _raise_for_response(response, "List dimensions failed")
    data = response.json()
    return data if isinstance(data, list) else []


def create_api_key(
    name: Optional[str] = None,
    expires_in: Optional[str] = None,
) -> Dict[str, Any]:
    url = f"{_config.api_url}/api/v1/api-keys"
    payload: Dict[str, Any] = {}
    if name is not None:
        payload["name"] = name
    if expires_in is not None:
        payload["expires_in"] = expires_in
    response = requests.post(
        url, json=payload, headers=_headers(), timeout=_config.timeout
    )
    _raise_for_response(response, "Create API key failed")
    return response.json()


def revoke_api_key(key_id: str) -> None:
    url = f"{_config.api_url}/api/v1/api-keys/{key_id}"
    response = requests.delete(url, headers=_headers(), timeout=_config.timeout)
    _raise_for_response(response, "Revoke API key failed")


def list_runners() -> List[Dict[str, Any]]:
    url = f"{_config.api_url}/api/v1/runner"
    response = requests.get(url, headers=_headers(), timeout=_config.timeout)
    _raise_for_response(response, "List runners failed")
    data = response.json()
    return data if isinstance(data, list) else data.get("runners", [])


def init_runner_registration(name: Optional[str] = None) -> Dict[str, Any]:
    url = f"{_config.api_url}/api/v1/runner/register/init"
    payload: Dict[str, Any] = {}
    if name is not None:
        payload["name"] = name
    response = requests.post(
        url, json=payload, headers=_headers(), timeout=_config.timeout
    )
    _raise_for_response(response, "Init runner registration failed")
    return response.json()


def delete_runner(runner_id: str) -> None:
    url = f"{_config.api_url}/api/v1/runner/{runner_id}"
    response = requests.delete(url, headers=_headers(), timeout=_config.timeout)
    _raise_for_response(response, "Delete runner failed")


def _json_sanitize(obj: Any) -> Any:
    """Return a JSON-serializable copy of obj; non-serializable values are dropped."""
    if obj is None or isinstance(obj, (bool, int, float, str)):
        return obj
    if isinstance(obj, dict):
        out: Dict[str, Any] = {}
        for k, v in obj.items():
            if not isinstance(k, str):
                continue
            try:
                out[k] = _json_sanitize(v)
            except (TypeError, ValueError):
                continue
        return out
    if isinstance(obj, (list, tuple)):
        out_list: List[Any] = []
        for v in obj:
            try:
                out_list.append(_json_sanitize(v))
            except (TypeError, ValueError):
                continue
        return out_list
    try:
        json.dumps(obj)
        return obj
    except (TypeError, ValueError):
        raise TypeError(f"{type(obj).__name__} is not JSON serializable")

