"""
Public SDK for model management (list, create, delete).

Use these to list available models or register new ones programmatically.
"""

from typing import Any, Dict, List, Optional

from worldjen._api import (
    create_model as _create_model,
    delete_model,
    list_base_models,
    list_ref_models,
    list_user_models,
)


__all__ = [
    "list_user",
    "list_base",
    "list_ref",
    "create",
    "delete",
]


def list_user(sort_by: Optional[str] = None) -> List[Dict[str, Any]]:
    """List your models."""
    return list_user_models(sort_by=sort_by)


def list_base(sort_by: Optional[str] = None) -> List[Dict[str, Any]]:
    """List base (suggested) models."""
    return list_base_models(sort_by=sort_by)


def list_ref(sort_by: Optional[str] = None) -> List[Dict[str, Any]]:
    """List reference models."""
    return list_ref_models(sort_by=sort_by)


def create(
    name: str,
    provider: str,
    hf_repo_id: str,
    model_type: str,
    encrypted_tokens: Optional[List[Dict[str, str]]] = None,
) -> Dict[str, Any]:
    """
    Create a user model.

    For private Hugging Face repos, pass encrypted_tokens (from
    worldjen.encrypt_token_for_runners) or configure the token in the dashboard.
    """
    return _create_model(
        name=name,
        provider=provider,
        hf_repo_id=hf_repo_id,
        model_type=model_type,
        encrypted_tokens=encrypted_tokens,
    )


def delete(model_id: str) -> None:
    """Delete a model."""
    delete_model(model_id)
