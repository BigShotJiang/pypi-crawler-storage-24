"""
Public SDK for API key management (list, create, revoke).

Create and revoke are also available in the dashboard.
"""

from typing import Any, Dict, List, Optional

from worldjen._api import (
    create_api_key,
    list_api_keys,
    revoke_api_key,
)


__all__ = [
    "list_keys",
    "create",
    "revoke",
]


def list_keys() -> List[Dict[str, Any]]:
    """List API keys for your account."""
    return list_api_keys()


def create(
    name: Optional[str] = None,
    expires_in: Optional[str] = None,
) -> Dict[str, Any]:
    """Create an API key. Returns the full key once; store it securely."""
    return create_api_key(name=name, expires_in=expires_in)


def revoke(key_id: str) -> None:
    """Revoke an API key by ID."""
    revoke_api_key(key_id)
