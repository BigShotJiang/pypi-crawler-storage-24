import io
import sys
import time
from contextlib import contextmanager
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Union

from worldjen._config import _config
from worldjen._api import (
    append_run_logs,
    confirm_upload,
    create_run,
    get_run,
    get_upload_url,
    update_run_status,
    upload_to_presigned,
)
from worldjen.prompts import get_prompts
from worldjen.video import save_frames_as_video


@dataclass
class RunResult:
    run_id: str
    video_paths: List[Path] = field(default_factory=list)
    output_dir: Optional[Path] = None
    eval_results: Optional[Dict[str, Any]] = None
    status: str = "unknown"
    error_message: Optional[str] = None


def _resolve_dimension_ids(dimensions: Any) -> List[str]:
    from worldjen.dimensions import Dimensions

    out: List[str] = []
    for d in dimensions:
        if isinstance(d, Dimensions):
            if d == Dimensions.ALL:
                return [m.value for m in Dimensions if m != Dimensions.ALL]
            out.append(d.value)
        elif isinstance(d, str):
            if d == "all" or d == Dimensions.ALL.value:
                return [m.value for m in Dimensions if m != Dimensions.ALL]
            out.append(d)
        else:
            out.append(str(d))
    return out


def _normalize_frames(raw: Any) -> List[Any]:
    if raw is None:
        return []
    if hasattr(raw, "frames"):
        f = raw.frames
        if isinstance(f, list) and len(f) > 0 and isinstance(f[0], list):
            return list(f[0])
        return list(f) if isinstance(f, list) else [f]
    if hasattr(raw, "images"):
        img = raw.images
        return list(img) if isinstance(img, list) else [img]
    return list(raw) if isinstance(raw, (list, tuple)) else [raw]


@contextmanager
def _capture_stdout_stderr():
    out, err = io.StringIO(), io.StringIO()
    old_out, old_err = sys.stdout, sys.stderr
    sys.stdout = _Tee(old_out, out)
    sys.stderr = _Tee(old_err, err)
    try:
        yield out, err
    finally:
        sys.stdout, sys.stderr = old_out, old_err


class _Tee:
    def __init__(self, orig, buf):
        self._orig, self._buf = orig, buf

    def write(self, s):
        self._orig.write(s)
        return self._buf.write(s)

    def flush(self):
        self._orig.flush()

    def writelines(self, lines):
        for line in lines:
            self.write(line)

    def __getattr__(self, name):
        return getattr(self._orig, name)


def _append_log(run_id: str, message: str) -> None:
    try:
        append_run_logs(run_id, message if message.endswith("\n") else message + "\n")
    except Exception:
        pass


def _invoke_pipeline(
    pipeline: Union[Callable[..., Any], Any],
    prompt: str,
    **kwargs: Any,
) -> List[Any]:
    call_kw = {"prompt": prompt, **kwargs}
    if callable(pipeline):
        out = pipeline(**call_kw)
    elif hasattr(pipeline, "generate"):
        out = pipeline.generate(**call_kw)
    elif hasattr(pipeline, "infer"):
        out = pipeline.infer(**call_kw)
    else:
        raise TypeError(
            "pipeline must be callable or have .generate() or .infer(prompt, **kwargs)"
        )
    return _normalize_frames(out)


def run(
    pipeline: Union[Callable[..., Any], Any],
    dimensions: Union[List[str], List[Any]],
    run_name: Optional[str] = None,
    model_id: Optional[str] = None,
    wait_for_evals: bool = True,
    **pipeline_kwargs: Any,
) -> RunResult:
    dimension_ids = _resolve_dimension_ids(dimensions)
    if not dimension_ids:
        return RunResult(
            run_id="",
            status="failed",
            error_message="dimensions must be a non-empty list",
        )

    try:
        prompts = get_prompts(dimension_ids)
    except Exception as e:
        return RunResult(
            run_id="",
            status="failed",
            error_message=f"get_prompts failed: {e}",
        )

    if not prompts:
        return RunResult(
            run_id="",
            status="failed",
            error_message="No prompts returned for the given dimensions",
        )

    try:
        run_id = create_run(
            name=run_name or "sdk-run",
            dimensions=dimension_ids,
            run_instructions=pipeline_kwargs if pipeline_kwargs else None,
            model_id=model_id,
        )
        update_run_status(run_id, status="running")
    except Exception as e:
        return RunResult(
            run_id="",
            status="failed",
            error_message=f"create_run failed: {e}",
        )

    total_prompts = len(prompts)
    _append_log(
        run_id,
        f"Run started. Dimensions: {dimension_ids}. Processing {total_prompts} prompt(s).",
    )

    video_dir = _config.video_dir
    output_dir = Path(video_dir) / run_id
    output_dir.mkdir(parents=True, exist_ok=True)
    video_paths: List[Path] = []

    try:
        for idx, item in enumerate(prompts):
            prompt_text = item.get("prompt", "")
            dims = item.get("dimensions", dimension_ids)
            if isinstance(dims, list) and dims:
                dim_ids = [d if isinstance(d, str) else str(d) for d in dims]
            else:
                dim_ids = dimension_ids

            prompt_preview = (prompt_text[:80] + "…") if len(prompt_text) > 80 else prompt_text
            _append_log(run_id, f"[{idx + 1}/{total_prompts}] Processing: {prompt_preview}")

            with _capture_stdout_stderr() as (out_io, err_io):
                frames = _invoke_pipeline(pipeline, prompt_text, **pipeline_kwargs)
            out_str = out_io.getvalue().strip()
            err_str = err_io.getvalue().strip()
            if out_str:
                _append_log(run_id, out_str)
            if err_str:
                _append_log(run_id, err_str)

            if not frames:
                _append_log(run_id, f"Pipeline returned no frames for prompt index {idx}.")
                update_run_status(
                    run_id,
                    status="failed",
                    error_message=f"Pipeline returned no frames for prompt index {idx}",
                )
                return RunResult(
                    run_id=run_id,
                    video_paths=video_paths,
                    output_dir=output_dir,
                    status="failed",
                    error_message=f"Pipeline returned no frames for prompt index {idx}",
                )

            video_filename = f"video_{idx:04d}.mp4"
            video_path = output_dir / video_filename
            save_frames_as_video(frames, video_path)
            video_paths.append(video_path)
            _append_log(run_id, f"Generated {len(frames)} frames. Saved {video_filename}.")

            upload_info = get_upload_url(run_id, video_filename)
            upload_to_presigned(
                upload_info["uploadUrl"],
                video_path,
                content_type="video/mp4",
            )
            confirm_upload(
                run_id=run_id,
                video_id=upload_info["videoId"],
                file_name=video_filename,
                s3_key=upload_info["s3Key"],
                prompt=prompt_text or None,
                dimension_ids=dim_ids,
            )
            _append_log(run_id, f"Uploaded {video_filename}.")

        _append_log(run_id, "Run completed.")
        update_run_status(run_id, status="completed")
    except Exception as e:
        _append_log(run_id, f"Run failed: {e}")
        update_run_status(
            run_id,
            status="failed",
            error_message=str(e),
        )
        return RunResult(
            run_id=run_id,
            video_paths=video_paths,
            output_dir=output_dir,
            status="failed",
            error_message=str(e),
        )

    eval_results: Optional[Dict[str, Any]] = None
    status = "completed"
    expected_video_count = len(video_paths)

    if wait_for_evals and expected_video_count > 0:
        _append_log(run_id, f"Waiting for evaluations ({expected_video_count} video(s))…")
        poll_interval = 5
        max_wait = 600
        waited = 0
        while waited < max_wait:
            run_data = get_run(run_id)
            result_data = run_data.get("resultData") or {}
            videos = result_data.get("videos") or []
            scored_count = len(videos) if isinstance(videos, list) else 0
            if run_data.get("errorMessage"):
                eval_results = result_data or run_data.get("eval_results")
                return RunResult(
                    run_id=run_id,
                    video_paths=video_paths,
                    output_dir=output_dir,
                    eval_results=eval_results,
                    status=run_data.get("status", status),
                    error_message=run_data.get("errorMessage"),
                )
            if scored_count >= expected_video_count:
                eval_results = result_data or run_data.get("eval_results")
                break
            time.sleep(poll_interval)
            waited += poll_interval
        else:
            final = get_run(run_id)
            eval_results = final.get("resultData") or final.get("eval_results")

    return RunResult(
        run_id=run_id,
        video_paths=video_paths,
        output_dir=output_dir,
        eval_results=eval_results,
        status=status,
    )
