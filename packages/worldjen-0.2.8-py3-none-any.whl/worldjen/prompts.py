from pathlib import Path
from typing import Iterable, List

_PROMPTS_DIR = Path(__file__).parent / "prompts"


def get_prompts(dimensions: Iterable[str]) -> List[dict]:
    """Load prompts for the given dimensions from embedded .txt files (one per dimension).

    Same layout as runner: each dimension has a .txt file, one prompt per line.
    Prompts that appear in multiple dimension files are merged so one run covers all.
    """
    dimension_list = list(dimensions)
    if not dimension_list:
        return []

    if not _PROMPTS_DIR.exists():
        raise FileNotFoundError(f"Prompts directory not found: {_PROMPTS_DIR}")

    prompt_to_dimensions: dict[str, list[str]] = {}

    for dimension in dimension_list:
        prompt_file = _PROMPTS_DIR / f"{dimension}.txt"
        if not prompt_file.exists():
            raise FileNotFoundError(f"Prompt file not found for dimension '{dimension}': {prompt_file}")

        with open(prompt_file, encoding="utf-8") as f:
            lines = [line.strip() for line in f if line.strip()]

        for p in lines:
            if p not in prompt_to_dimensions:
                prompt_to_dimensions[p] = []
            if dimension not in prompt_to_dimensions[p]:
                prompt_to_dimensions[p].append(dimension)

    return [{"prompt": p, "dimensions": dims} for p, dims in prompt_to_dimensions.items()]
