# Runner model configs
from worldjen.runner.config.runner_config import config

__all__ = ["config"]
