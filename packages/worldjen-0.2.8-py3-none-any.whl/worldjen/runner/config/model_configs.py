"""
Hardcoded configurations for supported video generation models.
"""


def init_wan21_pipeline(repo_url, torch, hf_token=None):
    """Initialize Wan2.1 T2V 1.3B pipeline"""
    # Lazy import: defer diffusers until needed; avoids loading GPU libs at module load
    from diffusers import DiffusionPipeline

    print(f"Initializing Wan2.1 T2V 1.3B from {repo_url}...")
    
    pipe = DiffusionPipeline.from_pretrained(
        repo_url,
        torch_dtype=torch.bfloat16,
        use_safetensors=True
    )
    pipe.to("cuda")
    
    return pipe

def init_wan22_pipeline(repo_url, torch, hf_token=None):
    """Initialize Wan2.2 T2V 14B pipeline"""
    # Lazy import: defer diffusers until needed; avoids loading GPU libs at module load
    from diffusers import DiffusionPipeline

    print(f"Initializing Wan2.2 T2V 14B from {repo_url}...")
    
    pipe = DiffusionPipeline.from_pretrained(
        repo_url,
        torch_dtype=torch.bfloat16,
        use_safetensors=True
    )
    pipe.enable_model_cpu_offload()
    
    return pipe

def init_ltx_video_pipeline(repo_url, torch, hf_token=None):
    """Initialize LTX-Video pipeline with upsampler"""
    # Lazy import: defer diffusers until needed; avoids loading GPU libs at module load
    from diffusers import LTXImageToVideoPipeline, AutoModel
    from diffusers.hooks import apply_group_offloading

    print(f"Initializing LTX-Video from {repo_url}...")
    
    pipe = LTXImageToVideoPipeline.from_pretrained("Lightricks/LTX-Video", torch_dtype=torch.bfloat16)
    transformer = AutoModel.from_pretrained("Lightricks/LTX-Video", subfolder="transformer", torch_dtype=torch.bfloat16)
    transformer.enable_layerwise_casting(
        storage_dtype=torch.float8_e4m3fn, compute_dtype=torch.bfloat16
    )
    pipe.transformer = transformer

    onload_device = torch.device("cuda")
    offload_device = torch.device("cpu")
    pipe.transformer.enable_group_offload(onload_device=onload_device, offload_device=offload_device, offload_type="leaf_level", use_stream=True)
    apply_group_offloading(pipe.text_encoder, onload_device=onload_device, offload_type="block_level", num_blocks_per_group=2)
    apply_group_offloading(pipe.vae, onload_device=onload_device, offload_type="leaf_level")
    
    return pipe

def generate_wan_video(pipe, prompt, generation_kwargs, torch):
    """Generate video using Wan models"""
    output = pipe(prompt, **generation_kwargs)
    
    if hasattr(output, "frames"):
        frames = output.frames[0]
    elif hasattr(output, "images"):
        frames = output.images
    else:
        frames = output
    
    return frames

def generate_ltx_video(pipe, image, prompt, generation_kwargs, torch):
    """Generate video using LTX-Video with multi-stage upsampling

    LTX is an image-to-video model and REQUIRES an image input.
    """
    # Lazy import: defer diffusers until needed; avoids loading GPU libs at module load
    from diffusers.pipelines.ltx.pipeline_ltx_condition import LTXVideoCondition
    from diffusers.utils import export_to_video, load_video
    import sys

    if isinstance(pipe, dict):
        main_pipe = pipe['main']
        upsample_pipe = pipe['upsample']
    else:
        main_pipe = pipe
        upsample_pipe = None
    
    if image is None:
        raise ValueError("LTX-Video is an image-to-video model and requires an image input. Cannot generate video from text-only prompt.")
        
    # Set defaults
    expected_height = generation_kwargs.get('height', 480)
    expected_width = generation_kwargs.get('width', 832)
    num_frames = generation_kwargs.get('num_frames', 96)
    num_inference_steps = generation_kwargs.get('num_inference_steps', 30)
    negative_prompt = generation_kwargs.get('negative_prompt', "worst quality, inconsistent motion, blurry, jittery, distorted")
    
    def round_to_nearest_resolution_acceptable_by_vae(height, width):
        vae_ratio = main_pipe.vae_spatial_compression_ratio
        height = height - (height % vae_ratio)
        width = width - (width % vae_ratio)
        return height, width
    
    if upsample_pipe:
        # Multi-stage generation with upsampling
        downscale_factor = 2 / 3
        
        # Part 1: Generate at lower resolution
        downscaled_height = int(expected_height * downscale_factor)
        downscaled_width = int(expected_width * downscale_factor)
        downscaled_height, downscaled_width = round_to_nearest_resolution_acceptable_by_vae(downscaled_height, downscaled_width)
        
        print(f"Generating video at {downscaled_width}x{downscaled_height}...")
        sys.stdout.flush()
        
        # Build kwargs with required image for LTXImageToVideoPipeline
        pipe_kwargs = {
            'prompt': prompt,
            'negative_prompt': negative_prompt,
            'image': image,
            'width': downscaled_width,
            'height': downscaled_height,
            'num_frames': num_frames,
            'num_inference_steps': num_inference_steps,
            'generator': torch.Generator().manual_seed(0),
            'output_type': 'latent',
        }
        
        latents = main_pipe(**pipe_kwargs).frames
        
        # Part 2: Upscale
        upscaled_height, upscaled_width = downscaled_height * 2, downscaled_width * 2
        print(f"Upscaling to {upscaled_width}x{upscaled_height}...")
        sys.stdout.flush()
        
        upscaled_latents = upsample_pipe(
            latents=latents,
            output_type="latent"
        ).frames
        
        # Part 3: Denoise
        print(f"Denoising upscaled video...")
        sys.stdout.flush()
        
        # Build kwargs (always include image for LTXImageToVideoPipeline)
        denoise_kwargs = {
            'prompt': prompt,
            'negative_prompt': negative_prompt,
            'image': image,
            'width': upscaled_width,
            'height': upscaled_height,
            'num_frames': num_frames,
            'denoise_strength': 0.4,
            'num_inference_steps': 10,
            'latents': upscaled_latents,
            'decode_timestep': 0.05,
            'image_cond_noise_scale': 0.025,
            'generator': torch.Generator().manual_seed(0),
            'output_type': 'pil',
        }
        
        video = main_pipe(**denoise_kwargs).frames[0]
        
        # Part 4: Resize to final resolution if needed
        if upscaled_height != expected_height or upscaled_width != expected_width:
            print(f"Resizing to final resolution {expected_width}x{expected_height}...")
            sys.stdout.flush()
            video = [frame.resize((expected_width, expected_height)) for frame in video]
        
        return video
    else:
        # Simple generation without upsampling
        print(f"Generating video at {expected_width}x{expected_height}...")
        sys.stdout.flush()
        
        expected_height, expected_width = round_to_nearest_resolution_acceptable_by_vae(expected_height, expected_width)
        
        # Build kwargs (always include image for LTXImageToVideoPipeline)
        pipe_kwargs = {
            'prompt': prompt,
            'negative_prompt': negative_prompt,
            'image': image,
            'width': expected_width,
            'height': expected_height,
            'num_frames': num_frames,
            'num_inference_steps': num_inference_steps,
            'generator': torch.Generator().manual_seed(0),
            'output_type': 'pil',
        }
        
        output = main_pipe(**pipe_kwargs)
        
        if hasattr(output, "frames"):
            frames = output.frames[0] if isinstance(output.frames, list) else output.frames
        else:
            frames = output
        
        return frames


MODEL_CONFIGS = {
    'wan2.1-1.3b': {
        'init_fn': init_wan21_pipeline,
        'generate_fn': generate_wan_video,
        'supports_image_input': False,
        'requires_image_input': False
    },
    'wan2.2-14b': {
        'init_fn': init_wan22_pipeline,
        'generate_fn': generate_wan_video,
        'supports_image_input': False,
        'requires_image_input': False
    },
    'ltx-hf': {
        'init_fn': init_ltx_video_pipeline,
        'generate_fn': generate_ltx_video,
        'supports_image_input': True,
        'requires_image_input': True
    },
}