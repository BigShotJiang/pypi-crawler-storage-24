"""Centralized configuration for runner (runner.conf, RabbitMQ, API)."""
import os
from configparser import ConfigParser
from pathlib import Path
from typing import Optional
from urllib.parse import quote, urlparse, urlunparse


class RunnerConfig:
    _config_loaded = False
    _default_config_path = Path(__file__).parent.parent / "default.conf"
    _runner_config_path_cache: Optional[Path] = None

    @classmethod
    def _get_user_config_dir(cls) -> Path:
        return Path(os.getenv("XDG_CONFIG_HOME", Path.home() / ".config")) / "worldjen"

    @classmethod
    def _get_runner_config_path(cls) -> Optional[Path]:
        if cls._runner_config_path_cache is None:
            cls._runner_config_path_cache = cls._get_user_config_dir() / "runner.conf"
        return cls._runner_config_path_cache if cls._runner_config_path_cache.exists() else None

    @classmethod
    def _load_default_config(cls) -> ConfigParser:
        config = ConfigParser()
        if cls._default_config_path.exists():
            config.read(cls._default_config_path)
        return config

    @classmethod
    def _load_runner_config(cls) -> ConfigParser:
        config = ConfigParser()
        runner_config_path = cls._get_runner_config_path()
        if runner_config_path:
            config.read(runner_config_path)
        return config

    @classmethod
    def _get_config_value(
        cls, section: str, key: str, env_var: Optional[str] = None, default: str = ""
    ) -> str:
        if env_var:
            env_value = os.getenv(env_var)
            if env_value:
                return env_value
        runner_config = cls._load_runner_config()
        if runner_config.has_option(section, key):
            return runner_config.get(section, key)
        default_config = cls._load_default_config()
        if default_config.has_option(section, key):
            return default_config.get(section, key)
        return default

    @classmethod
    def _get_api_url(cls) -> str:
        return cls._get_config_value("api", "base_url", "WORLDJEN_API_URL", "https://www.worldjen.com")

    @classmethod
    def _get_api_timeout(cls) -> int:
        return int(cls._get_config_value("api", "timeout", "WORLDJEN_API_TIMEOUT", "30"))

    @classmethod
    def _get_password_length(cls) -> int:
        return int(cls._get_config_value("registration", "password_length", "WORLDJEN_PASSWORD_LENGTH", "32"))

    @classmethod
    def _get_rabbitmq_base_url(cls) -> Optional[str]:
        url = cls._get_config_value("rabbitmq", "url", "RABBITMQ_BASE_URL", "")
        return url if url else None

    @classmethod
    def _get_rabbitmq_user(cls) -> Optional[str]:
        runner_config = cls._load_runner_config()
        if runner_config.has_option("runner", "rabbitmq_user"):
            return runner_config.get("runner", "rabbitmq_user")
        return None

    @classmethod
    def _get_rabbitmq_password(cls) -> Optional[str]:
        runner_config = cls._load_runner_config()
        if runner_config.has_option("runner", "password"):
            return runner_config.get("runner", "password")
        return None

    @classmethod
    def _get_rabbitmq_vhost(cls) -> Optional[str]:
        runner_config = cls._load_runner_config()
        if runner_config.has_option("runner", "rabbitmq_vhost"):
            return runner_config.get("runner", "rabbitmq_vhost")
        return None

    @classmethod
    def _get_rabbitmq_queue(cls) -> Optional[str]:
        runner_config = cls._load_runner_config()
        if runner_config.has_option("runner", "rabbitmq_queue"):
            return runner_config.get("runner", "rabbitmq_queue")
        return None

    @classmethod
    def get_rabbitmq_url(cls) -> str:
        env_url = os.getenv("RABBITMQ_URL")
        if env_url:
            return env_url
        runner_config_path = cls._get_runner_config_path()
        if not runner_config_path:
            expected = cls._get_user_config_dir() / "runner.conf"
            raise RuntimeError(
                f"Runner configuration file not found at '{expected}'. "
                "The runner must be registered before it can run. "
                "Please run 'worldjen runner register --token <runner_token>' first."
            )
        user = cls._get_rabbitmq_user()
        password = cls._get_rabbitmq_password()
        vhost = cls._get_rabbitmq_vhost()
        base_url = cls._get_rabbitmq_base_url()
        if not user or not password or not base_url:
            raise RuntimeError(
                f"Runner configuration file '{runner_config_path.name}' is missing required RabbitMQ credentials."
            )
        parsed = urlparse(base_url)
        if not vhost or vhost == "/":
            vhost_encoded = "/"
        else:
            vhost_clean = vhost.lstrip("/")
            vhost_encoded = "/" + quote(vhost_clean, safe="")
        netloc = f"{user}:{password}@{parsed.hostname}"
        if parsed.port:
            netloc += f":{parsed.port}"
        return urlunparse((parsed.scheme, netloc, vhost_encoded, "", "", ""))

    DEFAULT_API_URL: Optional[str] = None
    DEFAULT_API_TIMEOUT: Optional[int] = None
    DEFAULT_PASSWORD_LENGTH: Optional[int] = None

    @classmethod
    def _initialize(cls) -> None:
        if not cls._config_loaded:
            cls.DEFAULT_API_URL = cls._get_api_url()
            cls.DEFAULT_API_TIMEOUT = cls._get_api_timeout()
            cls.DEFAULT_PASSWORD_LENGTH = cls._get_password_length()
            cls._config_loaded = True

    @classmethod
    def get_api_url(cls) -> str:
        # Env var takes precedence so WORLDJEN_API_URL works for non-production testing
        env_url = os.getenv("WORLDJEN_API_URL")
        if env_url:
            return env_url.rstrip("/")
        cls._initialize()
        return cls.DEFAULT_API_URL or "https://www.worldjen.com"

    @classmethod
    def get_api_timeout(cls) -> int:
        cls._initialize()
        return cls.DEFAULT_API_TIMEOUT or 30

    @classmethod
    def get_password_length(cls) -> int:
        cls._initialize()
        return cls.DEFAULT_PASSWORD_LENGTH or 32

    @classmethod
    def get_default_config_path(cls) -> Path:
        return cls._get_user_config_dir() / "runner.conf"

    @classmethod
    def get_runner_private_key_path(cls) -> Optional[Path]:
        p = cls.get_default_config_path().with_suffix(
            cls.get_default_config_path().suffix + ".key"
        )
        return p if p.exists() else None

    @classmethod
    def get_rabbitmq_user(cls) -> Optional[str]:
        return cls._get_rabbitmq_user()

    @classmethod
    def get_rabbitmq_password(cls) -> Optional[str]:
        return cls._get_rabbitmq_password()

    @classmethod
    def get_rabbitmq_vhost(cls) -> Optional[str]:
        return cls._get_rabbitmq_vhost()

    @classmethod
    def get_rabbitmq_queue(cls) -> Optional[str]:
        return cls._get_rabbitmq_queue()

    @classmethod
    def get_runner_token(cls) -> Optional[str]:
        runner_config = cls._load_runner_config()
        if runner_config.has_option("runner", "runner_token"):
            return runner_config.get("runner", "runner_token")
        return None

    @classmethod
    def get_data_dir(cls) -> Path:
        env_data_dir = os.getenv("WORLDJEN_DATA_DIR")
        if env_data_dir:
            return Path(env_data_dir)
        return Path.home() / ".worldjen" / "data"

    @classmethod
    def get_video_dir(cls) -> Path:
        video_dir = cls.get_data_dir() / "videos"
        video_dir.mkdir(parents=True, exist_ok=True)
        return video_dir

    @classmethod
    def get_results_dir(cls) -> Path:
        results_dir = cls.get_data_dir() / "results"
        results_dir.mkdir(parents=True, exist_ok=True)
        return results_dir

    @classmethod
    def get_cache_dir(cls) -> Path:
        env_cache_dir = os.getenv("HF_HOME")
        if env_cache_dir:
            return Path(env_cache_dir)
        cache_dir = Path.home() / ".worldjen" / "cache" / "huggingface"
        cache_dir.mkdir(parents=True, exist_ok=True)
        return cache_dir


config = RunnerConfig()
