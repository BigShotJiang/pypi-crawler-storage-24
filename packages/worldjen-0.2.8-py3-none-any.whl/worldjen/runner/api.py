"""API client for runner (Bearer token auth with backend)."""
from pathlib import Path
from typing import Any, Dict, List, Optional

import requests

from worldjen.runner.config import config


def _err(e: requests.exceptions.RequestException, context: str) -> str:
    if hasattr(e, "response") and e.response is not None:
        try:
            detail = e.response.json().get("detail", "Unknown error")
            return f"{context}: {detail}"
        except Exception:
            pass
        return f"{context}: {e.response.text}"
    return f"{context}: {e}"


def update_run_status(
    run_id: str,
    status: Optional[str] = None,
    error_message: Optional[str] = None,
    result_data: Optional[Dict[str, Any]] = None,
) -> None:
    runner_token = config.get_runner_token()
    if not runner_token:
        raise RuntimeError("Runner token not found. Runner must be registered first.")
    url = f"{config.get_api_url()}/api/v1/runner/runs/{run_id}/status"
    headers = {"Authorization": f"Bearer {runner_token}", "Content-Type": "application/json"}
    payload: Dict[str, Any] = {}
    if status is not None:
        payload["status"] = status
    if error_message is not None:
        payload["error_message"] = error_message
    if result_data is not None:
        payload["result_data"] = result_data
    try:
        response = requests.patch(
            url, json=payload, headers=headers, timeout=config.get_api_timeout()
        )
        response.raise_for_status()
    except requests.exceptions.RequestException as e:
        raise RuntimeError(_err(e, "Failed to update run status"))


def get_running_runs() -> List[str]:
    runner_token = config.get_runner_token()
    if not runner_token:
        raise RuntimeError("Runner token not found. Runner must be registered first.")
    url = f"{config.get_api_url()}/api/v1/runner/runs/running"
    headers = {"Authorization": f"Bearer {runner_token}", "Content-Type": "application/json"}
    try:
        response = requests.get(url, headers=headers, timeout=config.get_api_timeout())
        response.raise_for_status()
        return response.json().get("runs", [])
    except requests.exceptions.RequestException as e:
        raise RuntimeError(_err(e, "Failed to get running runs"))


def get_run(run_id: str) -> Dict[str, Any]:
    runner_token = config.get_runner_token()
    if not runner_token:
        raise RuntimeError("Runner token not found. Runner must be registered first.")
    url = f"{config.get_api_url()}/api/v1/runner/runs/{run_id}/data"
    headers = {"Authorization": f"Bearer {runner_token}", "Content-Type": "application/json"}
    try:
        response = requests.get(url, headers=headers, timeout=config.get_api_timeout())
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        raise RuntimeError(_err(e, "Failed to get run data"))


def send_logs(run_id: str, logs: str) -> None:
    runner_token = config.get_runner_token()
    if not runner_token:
        raise RuntimeError("Runner token not found. Runner must be registered first.")
    url = f"{config.get_api_url()}/api/v1/runner/runs/{run_id}/logs"
    headers = {"Authorization": f"Bearer {runner_token}", "Content-Type": "application/json"}
    try:
        response = requests.post(
            url, json={"logs": logs}, headers=headers, timeout=config.get_api_timeout()
        )
        response.raise_for_status()
    except requests.exceptions.RequestException as e:
        raise RuntimeError(_err(e, "Failed to send logs"))


def get_model(model_id: str) -> Dict[str, Any]:
    runner_token = config.get_runner_token()
    if not runner_token:
        raise RuntimeError("Runner token not found. Runner must be registered first.")
    url = f"{config.get_api_url()}/api/v1/runner/models/{model_id}"
    headers = {"Authorization": f"Bearer {runner_token}", "Content-Type": "application/json"}
    try:
        response = requests.get(url, headers=headers, timeout=config.get_api_timeout())
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        raise RuntimeError(_err(e, "Failed to get model data"))


def upload_video(
    video_path: Path,
    run_id: str,
    prompt: Optional[str] = None,
    source: str = "runner",
    dimension_ids: Optional[List[str]] = None,
) -> Dict[str, Any]:
    runner_token = config.get_runner_token()
    if not runner_token:
        raise RuntimeError("Runner token not found. Runner must be registered first.")
    api_url = config.get_api_url()
    headers = {"Authorization": f"Bearer {runner_token}", "Content-Type": "application/json"}
    file_name = video_path.name
    content_type = "video/mp4"
    if file_name.endswith(".webm"):
        content_type = "video/webm"
    elif file_name.endswith(".avi"):
        content_type = "video/x-msvideo"
    elif file_name.endswith(".mov"):
        content_type = "video/quicktime"
    file_size_mb = video_path.stat().st_size / (1024 * 1024)
    print(f"  [Upload] File: {file_name} ({file_size_mb:.2f} MB)")
    url = f"{api_url}/api/v1/runner/runs/videos/upload-url"
    payload: Dict[str, Any] = {
        "runId": run_id,
        "fileName": file_name,
        "contentType": content_type,
    }
    try:
        response = requests.post(url, json=payload, headers=headers, timeout=config.get_api_timeout())
        response.raise_for_status()
        upload_info = response.json()
    except requests.exceptions.RequestException as e:
        raise RuntimeError(_err(e, "Failed to get upload URL"))
    upload_url = upload_info["uploadUrl"]
    try:
        with open(video_path, "rb") as f:
            upload_response = requests.put(
                upload_url,
                data=f,
                headers={"Content-Type": content_type},
                timeout=300,
            )
            upload_response.raise_for_status()
    except requests.exceptions.RequestException as e:
        raise RuntimeError(f"Failed to upload video to S3: {e}")
    confirm_url = f"{api_url}/api/v1/runner/runs/videos/confirm-upload"
    confirm_payload: Dict[str, Any] = {
        "runId": run_id,
        "videoId": upload_info["videoId"],
        "fileName": file_name,
        "s3Key": upload_info["s3Key"],
        "source": source,
        "localPath": str(video_path),
    }
    if prompt:
        confirm_payload["prompt"] = prompt
    if dimension_ids:
        confirm_payload["dimensionIds"] = dimension_ids
    try:
        response = requests.post(
            confirm_url, json=confirm_payload, headers=headers, timeout=config.get_api_timeout()
        )
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        raise RuntimeError(_err(e, "Failed to confirm upload"))
