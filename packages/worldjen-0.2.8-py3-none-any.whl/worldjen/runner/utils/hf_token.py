"""Decrypt Hugging Face token from model response (RSA-OAEP)."""
import base64
from typing import Optional

from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding

from worldjen.runner.config import config


def decrypt_model_token(encrypted_token: Optional[str]) -> Optional[str]:
    if not encrypted_token or not encrypted_token.strip():
        return None
    s = encrypted_token.strip()
    if s.startswith("hf_"):
        return s
    key_path = config.get_runner_private_key_path()
    if not key_path or not key_path.exists():
        return None
    try:
        with open(key_path, "rb") as f:
            private_key = serialization.load_pem_private_key(
                f.read(), password=None, backend=default_backend()
            )
        ciphertext = base64.b64decode(s, validate=True)
        plaintext = private_key.decrypt(
            ciphertext,
            padding.OAEP(
                mgf=padding.MGF1(algorithm=hashes.SHA256()),
                algorithm=hashes.SHA256(),
                label=None,
            ),
        )
        return plaintext.decode("utf-8")
    except Exception:
        return None
