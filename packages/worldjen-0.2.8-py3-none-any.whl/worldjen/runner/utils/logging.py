"""Logging utilities for capturing run output."""
import sys
from contextlib import contextmanager
from datetime import datetime
from io import StringIO
import threading

from worldjen.runner.api import send_logs


def log_print(message: str, flush: bool = True) -> None:
    print(message)
    if flush:
        sys.stdout.flush()


class LogCapture:
    def __init__(self, run_id: str, debug: bool = False) -> None:
        self.run_id = run_id
        self.buffer = StringIO()
        self.lock = threading.Lock()
        self.old_stdout = None
        self.old_stderr = None
        self.last_flush = datetime.utcnow()
        self.auto_flush_interval = 2
        self.debug = debug

    def write(self, text: str) -> None:
        with self.lock:
            self.buffer.write(text)
            if self.old_stdout:
                self.old_stdout.write(text)
                self.old_stdout.flush()
            now = datetime.utcnow()
            if (now - self.last_flush).total_seconds() >= self.auto_flush_interval:
                self._flush_to_api_internal()

    def _flush_to_api_internal(self) -> None:
        content = self.buffer.getvalue()
        if content:
            try:
                send_logs(self.run_id, content)
                self.buffer = StringIO()
                self.last_flush = datetime.utcnow()
            except Exception as e:
                if self.old_stderr:
                    self.old_stderr.write(f"[LogCapture ERROR] Error flushing logs to API: {e}\n")
                    self.old_stderr.flush()

    def flush_to_api(self) -> None:
        with self.lock:
            self._flush_to_api_internal()

    def flush(self) -> None:
        self.flush_to_api()

    def isatty(self) -> bool:
        return False


@contextmanager
def capture_output(run_id: str):
    log_capture = LogCapture(run_id)
    log_capture.old_stdout = sys.stdout
    log_capture.old_stderr = sys.stderr
    sys.stdout = log_capture
    sys.stderr = log_capture
    try:
        yield log_capture
    finally:
        log_capture.flush_to_api()
        sys.stdout = log_capture.old_stdout
        sys.stderr = log_capture.old_stderr
