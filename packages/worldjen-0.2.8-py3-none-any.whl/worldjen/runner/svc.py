"""Systemd service management for runner (install, start, stop, logs)."""
import os
import platform
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Optional

from worldjen.runner.config import config

SERVICE_NAME = "worldjen-runner"


def _require_linux() -> None:
    if platform.system() != "Linux":
        raise RuntimeError(f"Service management is only supported on Linux. Current: {platform.system()}")


def _run_sudo(*args: str) -> None:
    """Run a single command under sudo. Used only for the minimal root operations (write unit, systemctl)."""
    subprocess.check_call(["sudo", *args])


def is_systemd_running() -> bool:
    try:
        return Path("/run/systemd/system").exists()
    except Exception:
        return False


def get_python_executable() -> str:
    return sys.executable


def get_service_path() -> Path:
    return Path("/etc/systemd/system") / f"{SERVICE_NAME}.service"


def generate_systemd_unit(
    queue_name: str,
    loglevel: str = "info",
    working_dir: Optional[Path] = None,
    user: str = "root",
    home_dir: str = "/root",
    path: str = "/usr/local/bin:/usr/bin:/bin",
) -> str:
    """Generate systemd unit. Intentionally does not pass WORLDJEN_API_KEY or other SDK env vars; runner uses its own token from runner.conf."""
    python = get_python_executable()
    celery_cmd = f"{python} -m celery -A worldjen.runner.celery_app worker -Q {queue_name} --loglevel={loglevel} --without-gossip --without-mingle --without-heartbeat -c 1"
    hf_home = f"{home_dir}/.worldjen/cache/huggingface"
    work_dir = working_dir or Path.cwd()
    return f"""[Unit]
Description=WorldJen Runner (Celery worker)
After=network.target

[Service]
Type=simple
User={user}
Environment="HOME={home_dir}"
Environment="PATH={path}"
Environment="HF_HOME={hf_home}"
WorkingDirectory={work_dir}
ExecStart={celery_cmd}
Restart=on-failure
RestartSec=10
StandardOutput=journal
StandardError=journal
LimitNOFILE=524288

[Install]
WantedBy=multi-user.target
"""


def install(
    loglevel: str = "info",
    working_dir: Optional[str] = None,
) -> None:
    _require_linux()
    queue = config.get_rabbitmq_queue()
    if not queue:
        raise RuntimeError(
            "Runner not registered. Register first with 'worldjen runner register --token <token>'."
        )
    work_dir = Path(working_dir) if working_dir else Path.cwd()
    service_path = get_service_path()
    user = os.environ.get("SUDO_USER") or os.environ.get("USER", "root")
    home_dir = os.environ.get("HOME", str(Path.home()))
    path = os.environ.get("PATH", "/usr/local/bin:/usr/bin:/bin")
    unit_content = generate_systemd_unit(
        queue_name=queue,
        loglevel=loglevel,
        working_dir=work_dir,
        user=user,
        home_dir=home_dir,
        path=path,
    )
    # Write unit to a temp file and copy with sudo; no full re-exec under sudo, so no API key needed
    with tempfile.NamedTemporaryFile(
        mode="w", suffix=".service", prefix="worldjen-runner-", delete=False
    ) as f:
        f.write(unit_content)
        tmp_path = f.name
    try:
        _run_sudo("cp", tmp_path, str(service_path))
        print(f"Service file created at: {service_path}")
        if is_systemd_running():
            _run_sudo("systemctl", "daemon-reload")
            _run_sudo("systemctl", "enable", SERVICE_NAME)
            print("Service enabled to start on boot. Start now with: worldjen runner start")
        else:
            print("Systemd not running. On a systemd system run: sudo systemctl daemon-reload && sudo systemctl enable worldjen-runner")
    finally:
        try:
            os.unlink(tmp_path)
        except OSError:
            pass


def uninstall() -> None:
    _require_linux()
    service_path = get_service_path()
    if is_systemd_running():
        subprocess.run(["sudo", "systemctl", "stop", SERVICE_NAME], check=False)
        subprocess.run(["sudo", "systemctl", "disable", SERVICE_NAME], check=False)
    _run_sudo("rm", "-f", str(service_path))
    if is_systemd_running():
        _run_sudo("systemctl", "daemon-reload")
        print("Service stopped and disabled")
    print(f"Service file removed: {service_path}")


def _require_systemd() -> None:
    _require_linux()
    if not is_systemd_running():
        raise RuntimeError("Systemd is not running. This command requires a systemd-based system.")


def start() -> None:
    _require_systemd()
    result = subprocess.run(
        ["sudo", "systemctl", "start", SERVICE_NAME], capture_output=True, text=True
    )
    if result.returncode != 0:
        raise RuntimeError(f"Failed to start service: {result.stderr}")
    print("Service started")


def stop() -> None:
    _require_systemd()
    result = subprocess.run(
        ["sudo", "systemctl", "stop", SERVICE_NAME], capture_output=True, text=True
    )
    if result.returncode != 0:
        raise RuntimeError(f"Failed to stop service: {result.stderr}")
    print("Service stopped")


def status() -> None:
    _require_systemd()
    result = subprocess.run(
        ["systemctl", "status", SERVICE_NAME],
        capture_output=True,
        text=True,
    )
    print(result.stdout)
    if result.stderr:
        print(result.stderr, file=sys.stderr)


def logs(follow: bool = False, lines: int = 50) -> None:
    _require_systemd()
    cmd = ["journalctl", "-u", SERVICE_NAME, "-n", str(lines)]
    if follow:
        cmd.append("-f")
    subprocess.run(cmd)
