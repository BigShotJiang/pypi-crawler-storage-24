"""Runner registration (backend + local config and key file)."""
import hashlib
import math
import os
import secrets
import base64
import platform
import subprocess
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

import requests
from configparser import ConfigParser
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import rsa

from worldjen.runner.config import config


def generate_rsa_key_pair() -> Tuple[str, str]:
    private_key = rsa.generate_private_key(
        public_exponent=65537, key_size=2048, backend=default_backend()
    )
    public_pem = private_key.public_key().public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo,
    ).decode("utf-8")
    private_pem = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    ).decode("utf-8")
    return public_pem, private_pem


def generate_password(length: Optional[int] = None) -> str:
    if length is None:
        length = config.get_password_length()
    bytes_needed = math.ceil(length * 3 / 4)
    random_bytes = secrets.token_bytes(bytes_needed)
    password = base64.urlsafe_b64encode(random_bytes).decode("utf-8").rstrip("=")
    return password[:length]


def hash_password(password: str) -> str:
    salt = secrets.token_bytes(4)
    password_bytes = password.encode("utf-8")
    salted_password = salt + password_bytes
    hash_obj = hashlib.sha256(salted_password)
    password_hash = hash_obj.digest()
    salted_hash = salt + password_hash
    return base64.b64encode(salted_hash).decode("utf-8")


def detect_runner_hardware_info() -> Dict[str, Any]:
    cpu_type = platform.processor() or platform.machine() or platform.platform()
    cpu_type = (cpu_type or "").strip() or None
    gpu_type, gpu_count = _detect_gpu()
    memory_gb = _detect_memory_gb()
    runner_version = None
    try:
        from importlib.metadata import version
        runner_version = version("worldjen")
    except Exception:
        pass
    return {
        "cpu_type": cpu_type,
        "gpu_type": gpu_type,
        "gpu_count": gpu_count,
        "memory_gb": memory_gb,
        "runner_version": runner_version,
    }


def _detect_gpu() -> Tuple[Optional[str], Optional[int]]:
    try:
        import torch
        if not torch.cuda.is_available():
            return None, 0
        count = torch.cuda.device_count()
        if count <= 0:
            return None, 0
        return (str(torch.cuda.get_device_name(0)).strip() or None, count)
    except Exception:
        pass
    try:
        out = subprocess.check_output(
            ["nvidia-smi", "--query-gpu=name", "--format=csv,noheader"],
            stderr=subprocess.DEVNULL, text=True, timeout=2,
        )
        names = [line.strip() for line in out.splitlines() if line.strip()]
        if not names:
            return None, 0
        return names[0], len(names)
    except Exception:
        return None, None


def _detect_memory_gb() -> Optional[float]:
    try:
        if hasattr(os, "sysconf"):
            page_size = os.sysconf("SC_PAGE_SIZE")
            phys_pages = os.sysconf("SC_PHYS_PAGES")
            if isinstance(page_size, int) and isinstance(phys_pages, int) and page_size > 0 and phys_pages > 0:
                return round((page_size * phys_pages) / (1024 ** 3), 2)
    except Exception:
        pass
    return None


def register_runner(
    runner_token: str,
    api_url: Optional[str] = None,
    config_path: Optional[Path] = None,
) -> Dict[str, Any]:
    if api_url is None:
        api_url = config.get_api_url()
    if config_path is None:
        config_path = config.get_default_config_path()
    config_path = Path(config_path)
    if config_path.exists():
        raise RuntimeError(
            f"Runner is already registered. Configuration file '{config_path}' already exists. "
            "Unregister first or use a different config path."
        )
    password = generate_password()
    password_hash = hash_password(password)
    public_key_pem, private_key_pem = generate_rsa_key_pair()
    url = f"{api_url.rstrip('/')}/api/v1/runner/register"
    payload = {
        "runner_token": runner_token,
        "password_hash": password_hash,
        "public_key": public_key_pem,
        "hardware_info": detect_runner_hardware_info(),
    }
    try:
        response = requests.post(url, json=payload, timeout=config.get_api_timeout())
        response.raise_for_status()
        data = response.json()
    except requests.exceptions.RequestException as e:
        if hasattr(e, "response") and e.response is not None:
            try:
                detail = e.response.json().get("detail", e.response.text)
            except Exception:
                detail = e.response.text
            raise RuntimeError(f"Registration failed: {detail}") from e
        raise RuntimeError(f"Registration failed: {e}") from e
    config_path.parent.mkdir(parents=True, exist_ok=True)
    key_file = config_path.with_suffix(config_path.suffix + ".key")
    key_file.write_text(private_key_pem)
    os.chmod(key_file, 0o600)
    config_parser = ConfigParser()
    config_parser["runner"] = {
        "runner_id": str(data.get("runner_id", "")),
        "user_id": str(data.get("user_id", "")),
        "runner_token": runner_token,
        "password": password,
        "rabbitmq_user": data.get("rabbitmq_user", ""),
        "rabbitmq_queue": data.get("rabbitmq_queue", ""),
        "rabbitmq_vhost": data.get("rabbitmq_vhost", ""),
        "registered_at": str(data.get("registered_at", "")),
    }
    config_parser["api"] = {"base_url": api_url.rstrip("/")}
    config_parser["rabbitmq"] = {"url": data.get("rabbitmq_url", "")}
    with open(config_path, "w") as f:
        config_parser.write(f)
    os.chmod(config_path, 0o600)
    return data
