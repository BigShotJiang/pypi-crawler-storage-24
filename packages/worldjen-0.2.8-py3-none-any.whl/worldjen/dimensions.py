from enum import Enum


class Dimensions(str, Enum):
    """Dimension IDs for evaluation. Use ALL to request prompts for every dimension."""

    ALL = "all"
    SUBJECT_CONSISTENCY = "subject_consistency"
    SCENE_CONSISTENCY = "scene_consistency"
    MOTION_SMOOTHNESS = "motion_smoothness"
    TEMPORAL_FLICKERING = "temporal_flickering"
    PHYSICAL_MECHANICS = "physical_mechanics"
    OBJECT_PERMANENCE = "object_permanence"
    HUMAN_FIDELITY = "human_fidelity"
    DYNAMIC_DEGREE = "dynamic_degree"
    SEMANTIC_ADHERENCE = "semantic_adherence"
    SPATIAL_RELATIONSHIP = "spatial_relationship"
    SEMANTIC_DRIFT = "semantic_drift"
