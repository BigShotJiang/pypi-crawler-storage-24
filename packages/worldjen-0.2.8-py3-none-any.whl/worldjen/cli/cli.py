"""Main CLI entrypoint for worldjen."""
import argparse
import sys

from worldjen.cli import api_keys, dimensions, models, runner_cmd, runs


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="worldjen",
        description="WorldJen SDK and runner CLI",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    subparsers = parser.add_subparsers(dest="command", required=True)
    runs.add_parser(subparsers)
    dimensions.add_parser(subparsers)
    models.add_parser(subparsers)
    api_keys.add_parser(subparsers)
    runner_cmd.add_parser(subparsers)
    args = parser.parse_args()
    run_fn = getattr(args, "_run", None)
    if run_fn is None:
        parser.print_help()
        sys.exit(0)
    try:
        run_fn(args)
    except SystemExit:
        raise
    except KeyboardInterrupt:
        print("Interrupted", file=sys.stderr)
        sys.exit(130)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
