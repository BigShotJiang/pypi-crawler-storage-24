"""CLI commands for worldjen API keys (list only; create and revoke are dashboard-only)."""
import argparse
import json

from worldjen.cli.common import apply_api_config
from worldjen.cli.table import print_table
from worldjen._api import list_api_keys


def cmd_list(args: argparse.Namespace) -> None:
    apply_api_config(args)
    keys = list_api_keys()
    if args.json:
        print(json.dumps(keys, indent=2))
        return
    rows = [
        (str(k.get("id") or ""), str(k.get("key_suffix") or k.get("keySuffix") or ""), str(k.get("name") or ""))
        for k in keys
    ]
    print_table(("ID", "SUFFIX", "NAME"), rows, empty_msg="No API keys found.")


def add_parser(subparsers: argparse._SubParsersAction) -> None:
    parser = subparsers.add_parser("api-keys", help="Manage API keys")
    sub = parser.add_subparsers(dest="api_keys_command", required=True)
    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("--api-key", help="API key (default: WORLDJEN_API_KEY)")
    common.add_argument("--api-url", help=argparse.SUPPRESS)
    common.add_argument("--json", action="store_true")

    p_list = sub.add_parser("list", parents=[common])
    p_list.set_defaults(_run=cmd_list)
