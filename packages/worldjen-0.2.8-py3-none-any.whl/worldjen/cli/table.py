"""Shared table formatting for CLI list output."""


def print_table(
    headers: tuple[str, ...],
    rows: list[tuple[str, ...]],
    empty_msg: str = "No items found.",
    max_widths: dict[int, int] | None = None,
) -> None:
    if not rows:
        print(empty_msg)
        return
    n = len(headers)
    max_widths = max_widths or {}
    widths = []
    for i in range(n):
        content_max = max(len(str(r[i])) for r in rows)
        if i in max_widths:
            content_max = min(content_max, max_widths[i])
        widths.append(max(len(headers[i]), content_max))
    fmt = "  ".join(f"{{:<{w}}}" for w in widths)
    print(fmt.format(*headers))
    print("-" * (sum(widths) + 2 * (n - 1)))
    for r in rows:
        cells = []
        for i in range(n):
            s = str(r[i])
            if i in max_widths and len(s) > max_widths[i]:
                s = s[: max_widths[i] - 3] + "..."
            cells.append(s)
        print(fmt.format(*cells))
