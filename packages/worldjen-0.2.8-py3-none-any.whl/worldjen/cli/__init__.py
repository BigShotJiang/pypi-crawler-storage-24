# WorldJen CLI
from worldjen.cli.cli import main

__all__ = ["main"]
