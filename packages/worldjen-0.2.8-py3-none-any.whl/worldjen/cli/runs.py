"""CLI commands for worldjen runs."""
import argparse
import json
import sys
from pathlib import Path
from typing import Any

from worldjen.cli.common import apply_api_config
from worldjen.cli.table import print_table
from worldjen._api import (
    cancel_run,
    create_run,
    delete_run,
    get_run,
    get_run_csv,
    get_run_logs,
    get_run_videos,
    list_runs,
)


def cmd_create(args: argparse.Namespace) -> None:
    apply_api_config(args)
    dimensions = [d.strip() for d in args.dimensions.split(",") if d.strip()]
    if not dimensions:
        print("Error: at least one dimension required", file=sys.stderr)
        sys.exit(1)
    runner_id = (args.runner_id or "").strip()
    model_id = (args.model_id or "").strip()
    if not runner_id or not model_id:
        print(
            "Error: --runner-id and --model-id are required.",
            file=sys.stderr,
        )
        sys.exit(1)
    run_instructions = _parse_run_instructions_arg(getattr(args, "run_instructions", None))
    try:
        run_id = create_run(
            name=args.name,
            dimensions=dimensions,
            model_id=model_id,
            runner_id=runner_id,
            run_instructions=run_instructions,
        )
    except ValueError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
    out = {
        "run_id": run_id,
        "name": args.name,
        "dimensions": dimensions,
        "runner_id": runner_id,
        "model_id": model_id,
    }
    if run_instructions is not None:
        out["run_instructions"] = run_instructions
    if args.json:
        print(json.dumps(out, indent=2))
    else:
        print(f"Created run: {run_id}")


def cmd_list(args: argparse.Namespace) -> None:
    apply_api_config(args)
    data = list_runs(status=args.status, page=args.page, limit=args.limit)
    runs = data.get("runs", data) if isinstance(data, dict) else data
    if not isinstance(runs, list):
        runs = []
    if args.json:
        print(json.dumps(data, indent=2))
        return
    rows = [
        (str(r.get("_id") or r.get("id") or ""), str(r.get("name") or ""), str(r.get("status") or ""))
        for r in runs
    ]
    print_table(("RUN ID", "NAME", "STATUS"), rows, empty_msg="No runs found.", max_widths={1: 50})


def _dimension_display_name(dim_id: str) -> str:
    return dim_id.replace("_", " ").title()


def _scores_per_dimension(data: dict) -> list[tuple[str, str, str, str]]:
    videos = data.get("resultData") or {}
    videos = videos.get("videos") if isinstance(videos, dict) else []
    if not isinstance(videos, list):
        return []
    by_dim: dict[str, list[float]] = {}
    for v in videos:
        scores = v.get("scores") or {}
        if not isinstance(scores, dict):
            continue
        for dim, val in scores.items():
            if val is None:
                continue
            try:
                n = float(val)
                if not (n != n or n == float("inf") or n == float("-inf")):
                    by_dim.setdefault(dim, []).append(n)
            except (TypeError, ValueError):
                continue
    config_dims = data.get("evaluateConfig") or {}
    dim_order = config_dims.get("dimensions") if isinstance(config_dims, dict) else []
    if not isinstance(dim_order, list):
        dim_order = []
    ordered = [d for d in dim_order if d in by_dim] + [d for d in sorted(by_dim) if d not in dim_order]
    rows = []
    for dim in ordered:
        vals = by_dim[dim]
        if not vals:  # pragma: no cover — defensive; vals are always non-empty when dim is in by_dim
            continue
        worst = min(vals)
        best = max(vals)
        avg = sum(vals) / len(vals)
        rows.append(
            (
                _dimension_display_name(dim),
                f"{worst:.2f}",
                f"{avg:.2f}",
                f"{best:.2f}",
            )
        )
    return rows


def cmd_get(args: argparse.Namespace) -> None:
    apply_api_config(args)
    data = get_run(args.run_id)
    if args.json:
        print(json.dumps(data, indent=2))
        return
    run_id = data.get("_id") or data.get("id")
    print(f"Run: {run_id}")
    print(f"Name: {data.get('name')}")
    print(f"Status: {data.get('status')}")
    dims = data.get("evaluateConfig", {}).get("dimensions", [])
    print(f"Dimensions: {dims}")
    score_rows = _scores_per_dimension(data)
    if score_rows:
        print()
        print("Scores per dimension (worst / average / best across videos):")
        print_table(("DIMENSION", "WORST", "AVERAGE", "BEST"), score_rows)


def cmd_cancel(args: argparse.Namespace) -> None:
    apply_api_config(args)
    cancel_run(args.run_id)
    if not args.json:
        print(f"Cancelled run {args.run_id}")


def cmd_delete(args: argparse.Namespace) -> None:
    apply_api_config(args)
    delete_run(args.run_id)
    if not args.json:
        print(f"Deleted run {args.run_id}")


def cmd_logs(args: argparse.Namespace) -> None:
    apply_api_config(args)
    data = get_run_logs(args.run_id)
    logs = data.get("logs", "") if isinstance(data, dict) else str(data)
    print(logs or "")


def cmd_csv(args: argparse.Namespace) -> None:
    apply_api_config(args)
    content = get_run_csv(args.run_id)
    if args.output:
        Path(args.output).write_bytes(content)
        if not args.json:
            print(f"Wrote CSV to {args.output}")
    else:
        sys.stdout.buffer.write(content)


def cmd_videos(args: argparse.Namespace) -> None:
    """List video metadata (id, prompt, URL) for a run. Does not download files."""
    apply_api_config(args)
    videos = get_run_videos(args.run_id)
    if args.json:
        print(json.dumps(videos, indent=2))
        return
    if not videos:
        print("No videos found for this run.")
        return
    rows = []
    for v in videos:
        vid = str(v.get("id") or v.get("_id") or "")
        prompt = str(v.get("prompt") or "")
        url = str(v.get("url") or v.get("s3Key") or "")
        rows.append((vid, prompt, url))
    print_table(
        ("VIDEO ID", "PROMPT", "URL"),
        rows,
        empty_msg="No videos found for this run.",
        max_widths={1: 50, 2: 60},
    )


def cmd_download_videos(args: argparse.Namespace) -> None:
    """Fetch video list for the run and download each video file to disk (--output-dir)."""
    apply_api_config(args)
    import requests
    videos = get_run_videos(args.run_id)
    out_dir = Path(args.output_dir or ".").resolve()
    out_dir.mkdir(parents=True, exist_ok=True)
    for i, v in enumerate(videos):
        url = v.get("url")
        if not url:
            continue
        vid = v.get("id") or v.get("_id") or str(i)
        ext = ".mp4" if "mp4" in (v.get("contentType") or "mp4") else ".webm"
        path = out_dir / f"{vid}{ext}"
        try:
            r = requests.get(url, timeout=300)
            r.raise_for_status()
            path.write_bytes(r.content)
            print(f"Saved {path.name}")
        except Exception as e:
            print(f"Error downloading {vid}: {e}", file=sys.stderr)
    if not args.json:
        print(f"Downloaded to {out_dir}")


def add_parser(subparsers: argparse._SubParsersAction) -> None:
    parser = subparsers.add_parser("runs", help="Manage runs")
    runs_sub = parser.add_subparsers(dest="runs_command", required=True)
    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("--api-key", help="API key (default: WORLDJEN_API_KEY)")
    common.add_argument("--api-url", help=argparse.SUPPRESS)
    common.add_argument("--json", action="store_true", help="Output JSON")

    p_create = runs_sub.add_parser(
        "create",
        parents=[common],
        help="Create a run on a worker queue (same as the web UI)",
        description=(
            "Create a run and enqueue it for the given runner and model. "
            "Requires --runner-id and --model-id (MongoDB ids from the dashboard). "
            "For local pipeline execution without a worker, use: worldjen.run() in Python."
        ),
    )
    p_create.add_argument("--name", required=True, help="Run display name")
    p_create.add_argument("--dimensions", required=True, help="Comma-separated dimension ids")
    p_create.add_argument(
        "--runner-id",
        required=True,
        help="Runner id (from worldjen runner list or the dashboard)",
    )
    p_create.add_argument(
        "--model-id",
        required=True,
        help="Model id (from worldjen models list or the dashboard)",
    )
    p_create.add_argument(
        "--run-instructions",
        metavar="JSON_OR_PATH",
        help="Optional JSON object or path to a .json file (runner pipeline kwargs)",
    )
    p_create.set_defaults(_run=cmd_create)

    p_list = runs_sub.add_parser("list", parents=[common])
    p_list.add_argument("--status")
    p_list.add_argument("--page", type=int, default=1)
    p_list.add_argument("--limit", type=int, default=50)
    p_list.set_defaults(_run=cmd_list)

    p_get = runs_sub.add_parser("get", parents=[common])
    p_get.add_argument("run_id")
    p_get.set_defaults(_run=cmd_get)

    p_cancel = runs_sub.add_parser("cancel", parents=[common])
    p_cancel.add_argument("run_id")
    p_cancel.set_defaults(_run=cmd_cancel)

    p_delete = runs_sub.add_parser("delete", parents=[common])
    p_delete.add_argument("run_id")
    p_delete.set_defaults(_run=cmd_delete)

    p_logs = runs_sub.add_parser("logs", parents=[common])
    p_logs.add_argument("run_id")
    p_logs.set_defaults(_run=cmd_logs)

    p_csv = runs_sub.add_parser("csv", parents=[common])
    p_csv.add_argument("run_id")
    p_csv.add_argument("--output", "-o", help="Write CSV to file")
    p_csv.set_defaults(_run=cmd_csv)

    p_videos = runs_sub.add_parser("videos", parents=[common])
    p_videos.add_argument("run_id")
    p_videos.set_defaults(_run=cmd_videos)

    p_dl = runs_sub.add_parser("download-videos", parents=[common])
    p_dl.add_argument("run_id")
    p_dl.add_argument("--output-dir", "-o", default=".", help="Directory to save videos")
    p_dl.set_defaults(_run=cmd_download_videos)


def _parse_run_instructions_arg(raw: str | None) -> dict[str, Any] | None:
    if raw is None:
        return None
    s = raw.strip()
    if not s:
        return None
    try:
        parsed: Any = json.loads(s)
    except json.JSONDecodeError:
        p = Path(s)
        if not p.is_file():
            print(
                "Error: --run-instructions must be valid JSON or a path to a JSON file",
                file=sys.stderr,
            )
            sys.exit(1)
        try:
            parsed = json.loads(p.read_text(encoding="utf-8"))
        except json.JSONDecodeError as e:
            print(f"Error: invalid JSON in {p}: {e}", file=sys.stderr)
            sys.exit(1)
    if not isinstance(parsed, dict):
        print("Error: run_instructions must be a JSON object", file=sys.stderr)
        sys.exit(1)
    return parsed
