import os
from pathlib import Path
from typing import Any, Optional


def _default_video_dir() -> Path:
    return Path.home() / ".worldjen" / "data" / "videos"


class _Config:
    def __init__(self) -> None:
        self._api_key: Optional[str] = os.environ.get("WORLDJEN_API_KEY")
        self._video_dir: Path = Path(
            os.environ.get("WORLDJEN_VIDEO_DIR", str(_default_video_dir()))
        )
        self._api_url: str = os.environ.get(
            "WORLDJEN_API_URL", "https://www.worldjen.com"
        )
        self._timeout: int = 60

    @property
    def api_key(self) -> Optional[str]:
        return self._api_key

    @api_key.setter
    def api_key(self, value: Optional[str]) -> None:
        self._api_key = value

    @property
    def video_dir(self) -> Path:
        return Path(self._video_dir)

    @video_dir.setter
    def video_dir(self, value: Any) -> None:
        self._video_dir = Path(value) if value is not None else _default_video_dir()

    @property
    def api_url(self) -> str:
        return self._api_url.rstrip("/")

    @api_url.setter
    def api_url(self, value: str) -> None:
        self._api_url = value.rstrip("/") if value else "https://www.worldjen.com"

    @property
    def timeout(self) -> int:
        return self._timeout

    @timeout.setter
    def timeout(self, value: int) -> None:
        self._timeout = value


_config = _Config()


def config(
    api_key: Optional[str] = None,
    video_dir: Optional[Any] = None,
    api_url: Optional[str] = None,
    timeout: Optional[int] = None,
) -> _Config:
    if api_key is not None:
        _config.api_key = api_key
    if video_dir is not None:
        _config.video_dir = video_dir
    if api_url is not None:
        _config.api_url = api_url
    if timeout is not None:
        _config.timeout = timeout
    return _config
