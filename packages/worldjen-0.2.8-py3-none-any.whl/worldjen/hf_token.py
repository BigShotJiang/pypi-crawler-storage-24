"""Encrypt a Hugging Face token for runner public keys (RSA-OAEP). Used when creating private models via CLI."""

import base64
from typing import Any, Dict, List


def encrypt_token_for_runners(
    plain_token: str,
    runners: List[Dict[str, Any]],
) -> List[Dict[str, str]]:
    """
    Encrypt plain_token with each runner's public key (RSA-OAEP SHA-256).
    Returns [{"runnerId": id, "ciphertext": base64}, ...] for runners that have a valid publicKey.
    """
    from cryptography.hazmat.backends import default_backend
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import padding

    plain_token = (plain_token or "").strip()
    if not plain_token:
        return []

    result: List[Dict[str, str]] = []
    for r in runners:
        runner_id = r.get("_id") or r.get("id")
        if not runner_id:
            continue
        runner_id = str(runner_id)
        pub_pem = (r.get("publicKey") or r.get("public_key") or "").strip()
        if not pub_pem:
            continue
        try:
            public_key = serialization.load_pem_public_key(
                pub_pem.encode("utf-8"),
                backend=default_backend(),
            )
            ciphertext = public_key.encrypt(
                plain_token.encode("utf-8"),
                padding.OAEP(
                    mgf=padding.MGF1(algorithm=hashes.SHA256()),
                    algorithm=hashes.SHA256(),
                    label=None,
                ),
            )
            result.append({"runnerId": runner_id, "ciphertext": base64.b64encode(ciphertext).decode("ascii")})
        except Exception:
            continue
    return result
