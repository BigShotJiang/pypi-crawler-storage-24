"""Nomenclatures API resource."""

from __future__ import annotations

from typing import TYPE_CHECKING

import httpx

from medelement_mis.models import GetNomenclaturesRequest, GetNomenclaturesResponse

if TYPE_CHECKING:
    from medelement_mis.client import MedelementClient


class NomenclaturesAPI:
    """API resource for clinic service nomenclature operations."""

    def __init__(self, client: MedelementClient) -> None:
        self._client = client

    def list(
        self,
        *,
        category_code: int | None = None,
        skip: int | None = None,
        q: str | None = None,
    ) -> GetNomenclaturesResponse:
        """List clinic service nomenclatures.

        GET /v1/doctor/nomenclatures

        Args:
            category_code: Filter by category identifier
            skip: Pagination offset
            q: Search query string

        Returns:
            GetNomenclaturesResponse with list of nomenclature items
        """
        request = GetNomenclaturesRequest(
            category_code=category_code,
            skip=skip,
            q=q,
        )

        response = httpx.get(
            f"{self._client.base_url}/v1/doctor/nomenclatures",
            params=request.model_dump(exclude_none=True),
            headers=self._client.auth_headers,
            timeout=self._client.timeout,
        )
        response.raise_for_status()

        return GetNomenclaturesResponse.model_validate(response.json())
