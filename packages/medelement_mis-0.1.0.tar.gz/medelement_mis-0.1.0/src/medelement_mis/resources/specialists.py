"""Specialists API resource."""

from __future__ import annotations

from typing import TYPE_CHECKING

import httpx

from medelement_mis.models import SpecialistsDict

if TYPE_CHECKING:
    from medelement_mis.client import MedelementClient


class SpecialistsAPI:
    """API resource for specialist operations."""

    def __init__(self, client: MedelementClient) -> None:
        self._client = client

    def list(self) -> SpecialistsDict:
        """Get list of all specialists.

        GET /v1/timetable/get_specialists

        Returns:
            SpecialistsDict containing specialists keyed by specialist code
        """
        response = httpx.get(
            f"{self._client.base_url}/v1/timetable/get_specialists",
            headers=self._client.auth_headers,
            timeout=self._client.timeout,
        )
        response.raise_for_status()

        return SpecialistsDict.model_validate(response.json())
