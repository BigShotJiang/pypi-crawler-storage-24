"""Medelement MIS API client."""

import base64

from medelement_mis.resources.nomenclatures import NomenclaturesAPI
from medelement_mis.resources.patients import PatientsAPI
from medelement_mis.resources.receptions import ReceptionsAPI
from medelement_mis.resources.specialists import SpecialistsAPI
from medelement_mis.resources.timetable import TimetableAPI


class MedelementClient:
    """Client for Medelement MIS API.

    Uses Basic HTTP authentication (RFC 7617) with X-Integrator-Key header.
    """

    def __init__(
        self,
        base_url: str,
        user_id: str,
        password: str,
        integrator_key: str,
        timeout: float = 10.0,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self._user_id = user_id
        self._password = password
        self._integrator_key = integrator_key
        self.timeout = timeout

        self.patients = PatientsAPI(self)
        self.specialists = SpecialistsAPI(self)
        self.timetable = TimetableAPI(self)
        self.receptions = ReceptionsAPI(self)
        self.nomenclatures = NomenclaturesAPI(self)

    @property
    def auth_headers(self) -> dict[str, str]:
        """Get authentication headers for API requests."""
        credentials = f"{self._user_id}:{self._password}"
        encoded = base64.b64encode(credentials.encode()).decode()
        return {
            "Authorization": f"Basic {encoded}",
            "X-Integrator-Key": self._integrator_key,
        }