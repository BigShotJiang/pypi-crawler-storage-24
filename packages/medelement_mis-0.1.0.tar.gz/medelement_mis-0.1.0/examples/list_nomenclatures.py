"""Browse the clinic service catalogue (nomenclatures)."""

from medelement_mis.client import MedelementClient
from medelement_mis.config import MedelementConfig

config = MedelementConfig()
client = MedelementClient(
    base_url=config.base_url,
    user_id=config.user_id,
    password=config.password,
    integrator_key=config.integrator_key,
    timeout=config.timeout,
)

# List all nomenclatures (first page)
services = client.nomenclatures.list()
print(f"Services (first page): {len(services)}")
for svc in services:
    print(f"  [{svc.nomenclature_code}] {svc.nomenclature_name}")

# Filter by category
by_category = client.nomenclatures.list(category_code=3)
print(f"\nCategory 3 services: {len(by_category)}")

# Search by keyword
found = client.nomenclatures.list(q="анализ")
print(f"\nSearch 'анализ': {len(found)} results")
for svc in found:
    print(f"  [{svc.nomenclature_code}] {svc.nomenclature_name}")

# Paginate
page2 = client.nomenclatures.list(skip=100)
print(f"\nPage 2 (skip=100): {len(page2)} services")
