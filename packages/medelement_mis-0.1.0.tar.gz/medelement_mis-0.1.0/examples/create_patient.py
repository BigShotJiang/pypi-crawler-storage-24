"""Create a new patient and retrieve their profile."""

from medelement_mis.client import MedelementClient
from medelement_mis.config import MedelementConfig
from medelement_mis.models import Gender

config = MedelementConfig(
    user_id="your_user_id",
    password="your_password",
    integrator_key="your_integrator_key",
    base_url="https://api.medelement.com/v1",
)
client = MedelementClient(
    base_url=config.base_url,
    user_id=config.user_id,
    password=config.password,
    integrator_key=config.integrator_key,
    timeout=config.timeout,
)

# Create a patient
created = client.patients.create(
    name="Анна",
    lastname="Смирнова",
    middlename="Петровна",
    birthday="15.03.1990",
    gender=Gender.FEMALE,
    patient_phone_2=["7", "701", "5551234"],
    patient_email="anna@example.com",
    iin="900315123456",
)
print(f"Created patient code: {created.profile_code}")

# Fetch full profile
detail = client.patients.get(patient_code=created.profile_code)
print(f"Name: {detail.lastname} {detail.name} {detail.middlename or ''}")
print(f"Birthday: {detail.birthday}")
print(f"Gender: {detail.gender}")

# Update patient profile
updated = client.patients.update(
    profile_code=created.profile_code,
    patient_email="anna.smirnova@example.com",
    social_status=11,
    benefit=15,
)
print(f"Updated patient: {updated.profile_code}, email={updated.patient_email}")
