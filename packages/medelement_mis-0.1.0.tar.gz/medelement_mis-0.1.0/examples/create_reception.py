"""Create, get, reschedule, search, and remove receptions."""

from medelement_mis.client import MedelementClient
from medelement_mis.config import MedelementConfig

config = MedelementConfig()
client = MedelementClient(
    base_url=config.base_url,
    user_id=config.user_id,
    password=config.password,
    integrator_key=config.integrator_key,
    timeout=config.timeout,
)

# Create a reception
created = client.receptions.create(
    patient_code=112946961558007465,
    specialist_code=456,
    company_cabinet_code=789,
    starttime="15.06.2025 10:00",
    endtime="15.06.2025 10:30",
    description="Первичный приём",
)
print(f"Created reception: {created.reception_code}")

# Get reception details
detail = client.receptions.get(reception_code=created.reception_code)
print(f"Reception detail: {detail}")

# Reschedule
client.receptions.reschedule(
    reception_code=created.reception_code,
    doctor_code=456,
    start_time="16.06.2025 11:00",
    end_time="16.06.2025 11:30",
)
print("Rescheduled successfully")

# Search receptions in a date range
results = client.receptions.search(
    begin_datetime="01.06.2025 00:00",
    end_datetime="30.06.2025 23:59",
    active=1,
)
print(f"\nOpen receptions: {len(results.receptions)}")
for r in results.receptions:
    print(f"  [{r.reception_code}] {r.starttime} — {r.endtime}")

# Search with extended specialist info
pd_results = client.receptions.search_pd(
    begin_datetime="01.06.2025",
    end_datetime="30.06.2025",
)
print(f"\nReceptions (PD): {len(pd_results.receptions)}")

# Remove a reception (only open, unpaid receptions can be deleted)
client.receptions.remove(reception_code=created.reception_code)
print("Reception removed")
