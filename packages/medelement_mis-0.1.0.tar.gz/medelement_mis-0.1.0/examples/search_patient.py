"""Search for patients by name, phone, or IIN."""

from medelement_mis.client import MedelementClient
from medelement_mis.config import MedelementConfig

config = MedelementConfig()  # reads MEDELEMENT_* env vars / .env
client = MedelementClient(
    base_url=config.base_url,
    user_id=config.user_id,
    password=config.password,
    integrator_key=config.integrator_key,
    timeout=config.timeout,
)

# Search by name
results = client.patients.search(name="Иван", lastname="Иванов")
print(f"Found {len(results)} patient(s)")
for p in results:
    print(f"  [{p.profile_code}] {p.lastname} {p.name} {p.middlename or ''}")

# Search by phone
results = client.patients.search(patient_phone_2=["7", "701", "1234567"])
for p in results:
    print(f"  [{p.profile_code}] {p.lastname} {p.name}")

# Get full patient details
if results:
    detail = client.patients.get(patient_code=results[0].profile_code)
    print(f"\nDetail: {detail}")
