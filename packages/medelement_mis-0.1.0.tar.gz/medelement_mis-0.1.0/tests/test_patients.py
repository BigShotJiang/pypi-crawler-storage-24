import httpx

from medelement_mis.client import MedelementClient
from medelement_mis.models import UpdatePatientResponse


def test_update_patient_calls_put_and_parses_response(monkeypatch):
    client = MedelementClient(
        base_url="https://api3.medelement.com",
        user_id="user",
        password="pass",
        integrator_key="key",
    )

    captured = {}

    def fake_put(url, json, headers, timeout):  # noqa: ANN001
        captured["url"] = url
        captured["json"] = json
        captured["headers"] = headers
        captured["timeout"] = timeout
        request = httpx.Request("PUT", url)
        return httpx.Response(
            201,
            request=request,
            json={
                "profile_code": 123,
                "name": "John",
                "lastname": "Golt",
                "social_status": 11,
                "benefit": 15,
            },
        )

    monkeypatch.setattr(httpx, "put", fake_put)

    result = client.patients.update(
        profile_code=123,
        name="John",
        lastname="Golt",
        social_status=11,
        benefit=15,
    )

    assert isinstance(result, UpdatePatientResponse)
    assert result.profile_code == 123
    assert result.social_status == 11
    assert result.benefit == 15
    assert captured["url"] == "https://api3.medelement.com/doctor/v1/patient"
    assert captured["json"]["profile_code"] == 123
    assert captured["json"]["name"] == "John"
