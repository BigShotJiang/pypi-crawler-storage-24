# medelement-mis

Typed Python SDK for Medelement MIS API.

## Public Interface

Top-level imports are stable and intended for package consumers:

```python
from medelement_mis import (
    MedelementClient,
    MedelementConfig,
    Environment,
    Gender,
    ColorCode,
    SOCIAL_STATUSES,
    CONCESSIONS,
)
```

Main API resources exposed by `MedelementClient`:

- `client.patients`
  - `search(...)`
  - `create(...)`
  - `get(patient_code)`
  - `update(...)`
- `client.receptions`
  - `create(...)`
  - `search(...)`
  - `search_pd(...)`
  - `get(reception_code)`
  - `reschedule(...)`
  - `remove(reception_code)`
- `client.specialists`
  - `list()`
- `client.timetable`
  - `get_timetable(...)`
  - `get_specialist_receptions(...)`
- `client.nomenclatures`
  - `list(...)`

Reference catalogs from docs:

- `SOCIAL_STATUSES` (from `docs/api/social_status.md`)
- `CONCESSIONS` (from `docs/api/concessions.md`)

## Quick Start

```python
from medelement_mis import MedelementClient, MedelementConfig

config = MedelementConfig()
client = MedelementClient(
    base_url=config.base_url,
    user_id=config.user_id,
    password=config.password,
    integrator_key=config.integrator_key,
    timeout=config.timeout,
)

patients = client.patients.search(lastname="Ivanov")
for patient in patients:
    print(patient.profile_code, patient.lastname, patient.name)
```
