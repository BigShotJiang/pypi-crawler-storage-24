# MEMORY.md — Blockparty Project Context

> Living document tracking design decisions, progress, and conventions.
> Updated each session.  Last updated: 2026-02-24 (Phase 7 complete).

---

## What Is Blockparty

A Python ≥3.12 client library providing a unified interface to EVM block
explorer APIs: **Etherscan**, **Routescan**, and **Blockscout**.  All three
use Etherscan-compatible API formats with provider-specific quirks that this
library normalises away.  MIT licensed.

Primary use case: fetching internal (trace) transactions across any supported
chain without caring which explorer serves the data.

---

## Architecture Overview

```
blockparty/
├── _types.py           # CoercedInt, ExplorerType literal
├── exceptions.py       # Hierarchy: BlockpartyError → typed sub-errors
├── warnings.py         # FallbackWarning, AuthFallbackWarning
├── models/
│   ├── registry.py     # ChainEntry, ExplorerInfo (Pydantic v2)
│   └── responses.py    # InternalTransaction, ExplorerResponse[T]
├── backends/
│   ├── _base.py        # Protocol + ExplorerBackendBase ABC
│   ├── _errors.py      # classify_error() — shared regex pattern matching
│   ├── etherscan.py    # 20 LOC — inherits everything from base
│   ├── routescan.py    # 20 LOC — inherits everything from base
│   └── blockscout.py   # Overrides normalize + parse_error
├── registry/
│   ├── chain_registry.py  # ChainRegistry (load, get, search, get_explorer)
│   ├── sources.py         # fetch_*_chains(), merge_chain_entries()
│   ├── generate.py        # CLI: python -m blockparty.registry.generate
│   └── data/chains.json   # Bundled snapshot (9 chains)
├── ratelimit/
│   ├── tiers.py        # Enums: EtherscanTier, RoutescanTier, BlockscoutTier
│   ├── budget.py       # Token-bucket rate limiter (async + sync)
│   └── registry.py     # RateLimitRegistry — dedup by (provider, api_key)
├── client/
│   ├── _base.py        # BACKENDS dict, resolve_explorer(), parse helpers
│   ├── _middleware.py   # ResponseCache (TTL), RetryConfig (exp backoff)
│   ├── async_client.py # AsyncBlockpartyClient (aiohttp)
│   └── sync_client.py  # SyncBlockpartyClient (requests)
├── pool/
│   ├── _base.py        # ProviderCredential, is_fallback_eligible()
│   ├── async_pool.py   # AsyncBlockpartyPool
│   └── sync_pool.py    # SyncBlockpartyPool
└── urls/
    └── builder.py      # ExplorerURLs — address/tx/token/block links
```

---

## Key Design Decisions

### Stateless backends (singletons)
Backends hold no state.  A single `EtherscanBackend()` instance is shared
across all chains and clients.  All context (API URL, chain ID, API key) is
passed as arguments.  This enables the `BACKENDS` dict in `client/_base.py`
to hold one instance per provider type.

### ExplorerBackendBase ABC (DRY refactor, Phase 7 session)
`build_request_params()` and `parse_error()` were **identical** across all
three backends.  We extracted them into `ExplorerBackendBase`:
- Etherscan and Routescan are now ~20 LOC each (just `name` property).
- Blockscout overrides `normalize_internal_tx()` (field remapping) and
  `parse_error()` (no `status` field).
- The `ExplorerBackend` Protocol remains for structural subtyping.

### Shared error classification (`_errors.py`)
`classify_error(message, result)` uses pre-compiled regex patterns to map
API error strings into typed exceptions.  Both `ExplorerBackendBase.parse_error()`
and `BlockscoutBackend.parse_error()` delegate to it, eliminating duplicated
pattern lists.

### Rate limits are per (provider, credential)
Two clients with the same Etherscan API key share one `RateLimitBudget`
via `RateLimitRegistry`.  Blockscout dynamically adapts from
`X-Ratelimit-*` response headers.

### Bundled chain registry (no runtime writes)
`chains.json` is a checked-in snapshot.  `python -m blockparty.registry.generate`
regenerates it by fetching from all three APIs and probing Routescan vanity
hostnames.  Users can also load a custom JSON path.

### Connection pool with credential-ordered fallback
`AsyncBlockpartyPool` / `SyncBlockpartyPool` accept an ordered list of
`ProviderCredential`.  On each request:
1. Filter credentials to those whose explorer type exists on the chain.
2. Try each in order.
3. On **fallback-eligible** errors (rate limit, auth, 5xx, connection):
   emit a `FallbackWarning` and try the next.
4. On **non-fallback** errors (invalid address, premium-only): raise
   immediately — no provider can help.
5. If all fail: raise `PoolExhaustedError` with the full error list.

Auth errors emit `AuthFallbackWarning` (subclass of `FallbackWarning`) for
more targeted `warnings.filterwarnings` control.

### Explorer auto-resolution
When `explorer_type` is omitted from a client:
- If `api_key` is provided → Etherscan (it requires keys).
- Otherwise → first available by priority: Etherscan > Routescan > Blockscout.

### URL builder: vanity vs generic
Routescan has vanity hostnames (`basescan.routescan.io`) that are probed
during registry generation.  The URL builder prefers vanity URLs when
available, falls back to generic `routescan.io/?chainid=`.  Routescan
`/block/` paths always include `chainid=` per their docs.

### Cache + Retry
- `ResponseCache`: SHA256-keyed TTL cache (default 30s).  `force_refresh`
  kwarg bypasses it.
- `RetryConfig`: Exponential backoff (1s base, 2x multiplier, 30s cap,
  ±25% jitter).  Retries on 429/5xx.  Respects `Retry-After` header.

---

## Phase Progress

| Phase | Description                | Status      | Tests |
|-------|----------------------------|-------------|-------|
| 1     | Types & exceptions         | ✅ Complete  | 31    |
| 2     | Backends                   | ✅ Complete  | 45    |
| 3     | Chain registry             | ✅ Complete  | 24    |
| 4     | Rate limiting              | ✅ Complete  | 28    |
| 5     | Async + Sync clients       | ✅ Complete  | 23    |
| 6     | URL builders               | ✅ Complete  | 19    |
| 7     | Connection pool            | ✅ Complete  | 38    |
| 8     | Polish & packaging         | 🔲 Next     | —     |

**Total: 210 tests, 2904 source LOC, 1900 test LOC.**

---

## Live Testing

```bash
# Install in editable mode
pip install -e ".[dev]"

# Unit tests (no network)
pytest

# Live smoke test against real APIs (needs network)
python live_test.py

# With Etherscan (tests all 3 providers with a valid key)
ETHERSCAN_API_KEY=your_key python live_test.py
```

The live test exercises: async single client (Blockscout), sync single client
(Routescan), pool fallback (Etherscan fails without key → FallbackWarning →
Routescan succeeds), sync pool, and cache hit timing.  Target: Base Mainnet
(8453), WETH contract (`0x4200...0006`).

---

## Phase 8 Plan (Polish & Packaging)

- [ ] README.md with usage examples (single client, pool, URL builder)
- [ ] SUPPORTED_CHAINS.md (auto-generated from registry)
- [ ] Top-level `__all__` audit + public API surface review
- [ ] `pyproject.toml` completeness (classifiers, URLs, entry points)
- [ ] Type stubs / py.typed marker
- [ ] CI config (GitHub Actions: test matrix, lint, type-check)
- [ ] Optional: `mypy --strict` pass

---

## Conventions

- **Python**: ≥3.12, use `X | Y` unions, no `typing.Optional`.
- **Pydantic**: v2.11.  `model_config` not `class Config`.
- **Testing**: pytest + pytest-asyncio (`mode=auto`).  No network in tests.
- **Formatting**: No `black`/`ruff` enforced yet but code follows their defaults.
- **Imports**: `from __future__ import annotations` everywhere.
- **Docstrings**: Google-ish style.  Module docstrings explain "why".

---

## Dependencies

### Runtime
- `pydantic >=2.11`
- `aiohttp` (async HTTP)
- `requests` (sync HTTP)

### Dev
- `pytest`
- `pytest-asyncio`

---

## Noteworthy Provider Quirks

| Quirk | Etherscan | Routescan | Blockscout |
|-------|-----------|-----------|------------|
| API key | Required | Optional | Optional |
| Chain ID in URL | Query param (`chainid`) | Path segment | Per-host |
| `hash` field | `hash` | `hash` | `transactionHash` |
| `type` field | `type` | `type` | `callType` (+ `type`) |
| Error format | `status=0` | `status=0` | No `status` field |
| Rate limit info | Static per tier | Static per tier | Response headers |
| Vanity domains | N/A (unified gateway) | `{chain}.routescan.io` | Per-chain host |
