"""Concurrent fetcher for Etherscan API documentation markdown files.

Fetches llms.txt, filters out eth_* RPC method docs and Solana references,
then downloads all remaining markdown files concurrently.
"""

from __future__ import annotations

import asyncio
import re
import sys
from pathlib import Path

import aiohttp

LLMS_TXT_URL = "https://docs.etherscan.io/llms.txt"
OUTPUT_DIR = Path(__file__).parent / "etherscan_docs"

# Pattern: markdown link like [Title](URL)
LINK_RE = re.compile(r"\[([^\]]+)\]\((https://docs\.etherscan\.io/[^\)]+\.md)\)")

# eth_* RPC method names to exclude
ETH_RPC_RE = re.compile(r"^eth_[a-zA-Z]")

# Solana-related keywords
SOLANA_KEYWORDS = {"solana", "solscan", "sol"}


def should_exclude(title: str, url: str) -> bool:
    """Return True if this entry should be skipped."""
    title_lower = title.lower()
    url_lower = url.lower()

    # Exclude eth_* RPC mirror methods
    if ETH_RPC_RE.match(title):
        return True

    # Exclude Solana references
    if any(kw in title_lower or kw in url_lower for kw in SOLANA_KEYWORDS):
        return True

    # Only include API reference endpoints
    if "/api-reference/endpoint/" not in url:
        return True

    return False


async def fetch_one(
    session: aiohttp.ClientSession,
    title: str,
    url: str,
    semaphore: asyncio.Semaphore,
) -> tuple[str, str, str | None]:
    """Fetch a single markdown file. Returns (title, url, content_or_None)."""
    async with semaphore:
        try:
            async with session.get(url, timeout=aiohttp.ClientTimeout(total=30)) as resp:
                if resp.status == 200:
                    text = await resp.text()
                    return title, url, text
                print(f"  WARN: {resp.status} for {url}", file=sys.stderr)
                return title, url, None
        except Exception as exc:
            print(f"  ERROR: {exc} for {url}", file=sys.stderr)
            return title, url, None


async def main() -> None:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    async with aiohttp.ClientSession() as session:
        # Step 1: Fetch llms.txt
        print("Fetching llms.txt ...")
        async with session.get(LLMS_TXT_URL) as resp:
            llms_text = await resp.text()

        # Step 2: Parse and filter links
        all_links = LINK_RE.findall(llms_text)
        filtered = [(t, u) for t, u in all_links if not should_exclude(t, u)]

        print(f"Found {len(all_links)} total links, {len(filtered)} after filtering")
        for title, url in filtered:
            print(f"  -> {title}")

        # Step 3: Fetch all concurrently (max 10 at a time)
        semaphore = asyncio.Semaphore(10)
        tasks = [fetch_one(session, t, u, semaphore) for t, u in filtered]
        results = await asyncio.gather(*tasks)

        # Step 4: Save to disk
        success = 0
        for title, url, content in results:
            if content is not None:
                # Extract filename from URL
                filename = url.rsplit("/", 1)[-1]
                out_path = OUTPUT_DIR / filename
                out_path.write_text(content, encoding="utf-8")
                success += 1

        print(f"\nSaved {success}/{len(filtered)} files to {OUTPUT_DIR}")


if __name__ == "__main__":
    asyncio.run(main())
