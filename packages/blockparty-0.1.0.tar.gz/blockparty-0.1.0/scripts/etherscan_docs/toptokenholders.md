> ## Documentation Index
> Fetch the complete documentation index at: https://docs.etherscan.io/llms.txt
> Use this file to discover all available pages before exploring further.

# Get Top Token Holders

> Returns the list of top holders for a specified ERC-20 token.

export const chain = '1';

<Note>This is a PRO endpoint, available to the [Standard Plan](/resources/rate-limits) and above</Note>
<Warning>This endpoint is throttled to **2 calls/second** regardless of API Pro tier.</Warning>
<Callout icon="globe" iconType="regular">HyperEVM (999) is not supported yet</Callout>

<img src="https://mintcdn.com/etherscan/_gIsWVKPgcVhiZQW/images/features/holders.png?fit=max&auto=format&n=_gIsWVKPgcVhiZQW&q=85&s=9e6457139c74e1173d79e860ae4c9b08" alt="Token holders" data-og-width="1440" width="1440" data-og-height="550" height="550" data-path="images/features/holders.png" data-optimize="true" data-opv="3" srcset="https://mintcdn.com/etherscan/_gIsWVKPgcVhiZQW/images/features/holders.png?w=280&fit=max&auto=format&n=_gIsWVKPgcVhiZQW&q=85&s=e221b7e761d61c170022a36d3b77a4a0 280w, https://mintcdn.com/etherscan/_gIsWVKPgcVhiZQW/images/features/holders.png?w=560&fit=max&auto=format&n=_gIsWVKPgcVhiZQW&q=85&s=a67bf803f38d4344f22a1fd0b35f9d8c 560w, https://mintcdn.com/etherscan/_gIsWVKPgcVhiZQW/images/features/holders.png?w=840&fit=max&auto=format&n=_gIsWVKPgcVhiZQW&q=85&s=657668003e5b1d9befe7dd6c732f5b87 840w, https://mintcdn.com/etherscan/_gIsWVKPgcVhiZQW/images/features/holders.png?w=1100&fit=max&auto=format&n=_gIsWVKPgcVhiZQW&q=85&s=95cb3838dda9a7de24b736ebb31b584b 1100w, https://mintcdn.com/etherscan/_gIsWVKPgcVhiZQW/images/features/holders.png?w=1650&fit=max&auto=format&n=_gIsWVKPgcVhiZQW&q=85&s=1ca9bb49cd735e8bbc68a64b2f0203e3 1650w, https://mintcdn.com/etherscan/_gIsWVKPgcVhiZQW/images/features/holders.png?w=2500&fit=max&auto=format&n=_gIsWVKPgcVhiZQW&q=85&s=10569f23cde4d2374743a40c7f6fc00d 2500w" />

### Query Parameters

<ParamField query="apikey" type="string" default="YourApiKeyToken">
  Your Etherscan API key.
</ParamField>

<ParamField query="chainid" type="string" default="1">
  Chain ID to query, eg `1` for Ethereum, `8453` for Base from our [supported chains](/supported-chains).
</ParamField>

<ParamField query="module" type="string" default="token">
  Set to `token` for this endpoint.
</ParamField>

<ParamField query="action" type="string" default="topholders">
  Set to `topholders` for this endpoint.
</ParamField>

<ParamField query="contractaddress" type="string" default="0x7fc66500c84a76ad7e9c93437bfc5ac33e2ddae9">
  Contract address of the ERC-20 token.
</ParamField>

<ParamField query="offset" type="integer" default="100">
  Number of top holders to return, up to 1000.
</ParamField>

<RequestExample>
  ```bash  theme={null}
  curl "https://api.etherscan.io/v2/api?chainid=1&module=token&action=topholders&contractaddress=0x7fc66500c84a76ad7e9c93437bfc5ac33e2ddae9&offset=100&apikey=YourApiKeyToken"
  ```
</RequestExample>

<ResponseExample>
  ```json Response theme={null}
  {
    "status": "1",
    "message": "Ok",
    "result": [
      {
        "TokenHolderAddress": "0x4da27a545c0c5b758a6ba100e3a049001de870f5",
        "TokenHolderQuantity": "2696124.3026660371030000",
        "TokenHolderAddressType": "C"
      },
      {
        "TokenHolderAddress": "0xa700b4eb416be35b2911fd5dee80678ff64ff6c9",
        "TokenHolderQuantity": "1650828.8050095955930000",
        "TokenHolderAddressType": "C"
      }
    ]
  }
  ```
</ResponseExample>
