"""Extract and print response shapes from all endpoint docs."""

from __future__ import annotations

import json
import os
import re
from pathlib import Path

DOCS_DIR = Path(__file__).parent / "etherscan_docs"
RESP_RE = re.compile(r"```json.*?\n(.*?)```", re.DOTALL)

for fname in sorted(os.listdir(DOCS_DIR)):
    if not fname.endswith(".md"):
        continue
    text = (DOCS_DIR / fname).read_text()
    m = RESP_RE.search(text)
    if m:
        try:
            d = json.loads(m.group(1))
            r = d.get("result")
            if isinstance(r, list) and r:
                print(f"{fname}: list keys={list(r[0].keys())}")
            elif isinstance(r, dict):
                print(f"{fname}: object keys={list(r.keys())}")
            else:
                print(f"{fname}: scalar={repr(r)[:100]}")
        except Exception:
            print(f"{fname}: parse error")
