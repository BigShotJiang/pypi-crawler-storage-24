"""Analyze all fetched Etherscan API docs to catalog endpoints and params."""

from __future__ import annotations

import os
import re
from pathlib import Path

DOCS_DIR = Path(__file__).parent / "etherscan_docs"

MODULE_RE = re.compile(r"Set to `(\w+)` for this endpoint")
COMMA_RE = re.compile(r"[Uu]p to (\d+)\s+\w+.*separated by commas", re.DOTALL)
TITLE_RE = re.compile(r"^#\s+(.+)", re.MULTILINE)
RESPONSE_RE = re.compile(r"```json.*?\n(.*?)```", re.DOTALL)


def analyze():
    results = []
    for fname in sorted(os.listdir(DOCS_DIR)):
        if not fname.endswith(".md"):
            continue
        text = (DOCS_DIR / fname).read_text()

        title_m = TITLE_RE.search(text)
        title = title_m.group(1).strip() if title_m else fname

        module = action = None
        params = []

        blocks = re.findall(
            r'<ParamField\s+query="([^"]+)"[^>]*>(.*?)</ParamField>',
            text,
            re.DOTALL,
        )

        for pname, pdesc in blocks:
            if pname in ("apikey", "chainid"):
                continue

            tag_match = re.search(
                r'<ParamField[^>]*query="' + re.escape(pname) + r'"[^>]*type="([^"]+)"',
                text,
            )
            ptype = tag_match.group(1) if tag_match else "string"

            def_match = re.search(
                r'<ParamField[^>]*query="' + re.escape(pname) + r'"[^>]*default="([^"]*)"',
                text,
            )
            default = def_match.group(1) if def_match else None

            if pname == "module":
                m = MODULE_RE.search(pdesc)
                if m:
                    module = m.group(1)
                continue
            if pname == "action":
                m = MODULE_RE.search(pdesc)
                if m:
                    action = m.group(1)
                continue

            comma_m = COMMA_RE.search(pdesc)
            max_items = int(comma_m.group(1)) if comma_m else None

            params.append({
                "name": pname,
                "type": ptype,
                "default": default,
                "max_items": max_items,
                "desc": pdesc.strip()[:300],
            })

        # Extract response example
        resp_m = RESPONSE_RE.search(text)
        resp_example = resp_m.group(1).strip() if resp_m else None

        results.append({
            "file": fname,
            "title": title,
            "module": module,
            "action": action,
            "params": params,
            "response_example": resp_example,
        })

    # Print summary
    for r in results:
        multi = [p for p in r["params"] if p["max_items"]]
        multi_str = ""
        if multi:
            multi_str = "  MULTI: " + ", ".join(
                f"{p['name']}({p['max_items']})" for p in multi
            )
        pnames = [p["name"] for p in r["params"]]
        print(f"{r['module']}.{r['action']}  [{r['file']}]  params=[{', '.join(pnames)}]{multi_str}")

    # Print endpoints with multi-value params
    print("\n\n=== COMMA-SEPARATED MULTI-VALUE PARAMS ===")
    for r in results:
        for p in r["params"]:
            if p["max_items"]:
                print(f"  {r['module']}.{r['action']} -> {p['name']} (up to {p['max_items']}): {p['desc'][:100]}")

    # Print response examples grouped by shape
    print("\n\n=== RESPONSE SHAPES ===")
    for r in results:
        if r["response_example"]:
            # Detect if result is list, string, or object
            resp = r["response_example"]
            if '"result": [' in resp:
                shape = "list"
            elif '"result": {' in resp:
                shape = "object"
            elif '"result":' in resp:
                shape = "scalar"
            else:
                shape = "unknown"
            print(f"  {r['module']}.{r['action']} -> {shape}")


if __name__ == "__main__":
    analyze()
