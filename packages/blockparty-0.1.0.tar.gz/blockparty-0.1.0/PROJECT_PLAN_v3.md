# blockparty — Project Plan v3 (Final)

> A unified Python client for EVM block explorer APIs (Etherscan, Routescan, Blockscout).
> Normalizes responses, supports sync and async, provides fallback routing via connection
> pooling, and builds frontend explorer URLs.

---

## 1. Package Identity

| Field | Value |
|-------|-------|
| **Name** | `blockparty` |
| **Python** | ≥ 3.12 |
| **License** | MIT |
| **Repo structure** | `src/blockparty/` (src layout) |
| **Build system** | `pyproject.toml` with hatchling or setuptools |

---

## 2. Dependency Stack

| Dependency | Role |
|------------|------|
| `pydantic >= 2.11` | Response models, config validation, hex/numeric coercion |
| `meatie` | Declarative API endpoint definitions, middleware pipeline |
| `meatie-aiohttp` | Async HTTP backend (aiohttp-based meatie adapter) |
| `meatie-requests` | Sync HTTP backend (requests-based meatie adapter) |
| `aiohttp` | Async HTTP (transitive via meatie-aiohttp) |
| `requests` | Sync HTTP (transitive via meatie-requests) |

### Dev / Test Dependencies

| Dependency | Role |
|------------|------|
| `pytest` | Test runner |
| `pytest-asyncio` | Async test support |
| `aioresponses` | Mock aiohttp requests |
| `responses` | Mock requests (sync) |
| `ruff` | Linting and formatting |
| `mypy` | Static type checking |

---

## 3. Architecture Overview

### Core Principle: Separate the Simple Unit from the Orchestrator

Two distinct objects, each simple in its own right:

- **`BlockpartyClient`** — one chain, one explorer, one credential. No fallback.
  Does one thing well. What 80% of users need.
- **`BlockpartyPool`** — multi-chain, multi-credential, fallback-aware.
  Creates and caches `BlockpartyClient` instances internally.

```
┌──────────────────────────────────────────────────────────┐
│ BlockpartyPool (orchestrator)                            │
│                                                          │
│  ┌─────────────────┐  ┌─────────────────┐               │
│  │ ProviderCredential │  │ ProviderCredential │  ...       │
│  │ type: etherscan  │  │ type: routescan │               │
│  │ api_key: "..."   │  │ tier: FREE      │               │
│  │ tier: STANDARD   │  │                 │               │
│  └────────┬────────┘  └────────┬────────┘               │
│           │                    │                         │
│           ▼                    ▼                         │
│  ┌─────────────────────────────────────────┐             │
│  │ RateLimitRegistry (shared)              │             │
│  │  (etherscan, "ES_KEY") → TokenBucket    │             │
│  │  (routescan, None)     → TokenBucket    │             │
│  └─────────────────────────────────────────┘             │
│           │                    │                         │
│           ▼                    ▼                         │
│  ┌────────────────┐  ┌────────────────┐                  │
│  │ BlockpartyClient│  │ BlockpartyClient│  (cached,      │
│  │ chain=8453     │  │ chain=53935    │   per chain+    │
│  │ explorer=ES    │  │ explorer=RS    │   provider)     │
│  └────────────────┘  └────────────────┘                  │
└──────────────────────────────────────────────────────────┘
```

### File Structure

```
src/blockparty/
├── __init__.py              # Public API re-exports
├── _types.py                # CoercedInt, ExplorerType, type aliases
├── exceptions.py            # Exception hierarchy
├── warnings.py              # Warning classes (FallbackWarning, etc.)
├── py.typed                 # PEP 561 marker
├── client/
│   ├── __init__.py
│   ├── _base.py             # Shared endpoint definitions (meatie descriptors)
│   ├── _middleware.py        # Cache, retry/backoff, auth, error parsing, rate limiting
│   ├── async_client.py      # AsyncBlockpartyClient (aiohttp + meatie)
│   └── sync_client.py       # SyncBlockpartyClient (requests + meatie)
├── pool/
│   ├── __init__.py
│   ├── _base.py             # Shared pool logic (resolution, fallback, client caching)
│   ├── async_pool.py        # AsyncBlockpartyPool
│   └── sync_pool.py         # SyncBlockpartyPool
├── backends/
│   ├── __init__.py
│   ├── _base.py             # ExplorerBackend protocol
│   ├── etherscan.py         # EtherscanBackend
│   ├── routescan.py         # RoutescanBackend
│   └── blockscout.py        # BlockscoutBackend
├── models/
│   ├── __init__.py
│   ├── responses.py         # Normalized Pydantic response models
│   └── registry.py          # Chain registry entry models
├── ratelimit/
│   ├── __init__.py
│   ├── tiers.py             # Provider tier enums + CustomRateLimit
│   ├── budget.py            # RateLimitBudget (token bucket)
│   └── registry.py          # RateLimitRegistry (shared budgets)
├── registry/
│   ├── __init__.py
│   ├── chain_registry.py    # ChainRegistry (load, get, list, search)
│   ├── sources.py           # Fetch + parse for all 3 provider APIs
│   ├── generate.py          # CLI: regenerate snapshot + SUPPORTED_CHAINS.md
│   └── data/
│       └── chains.json      # Bundled static snapshot
└── urls/
    ├── __init__.py
    └── builder.py           # Frontend URL builders
```

---

## 4. Design Decisions

### 4.1 Registry: Bundled Snapshot + Regeneration Script

Library directories are not reliably writable at runtime. No auto-refresh.

1. Ship a **bundled `data/chains.json`** (checked into git, included in wheel).
2. **CLI script** (`python -m blockparty.registry.generate`):
   - Fetches Etherscan API, Routescan (mainnet + testnet), Blockscout API
   - Merges and deduplicates by chain_id
   - Probes `{chain_id}.routescan.io` via HEAD requests to capture vanity
     hostname redirects (with browser-like User-Agent to avoid CDN blocks)
   - Writes `src/blockparty/registry/data/chains.json`
   - Writes `SUPPORTED_CHAINS.md` (name, chain ID, provider availability)
3. **CI hook** (optional): weekly cron → regenerate → auto-PR if changed.
4. New library releases include the latest snapshot.

**Consumer override:** `ChainRegistry.load()` accepts an optional path.

```python
registry = ChainRegistry.load()                              # bundled
registry = ChainRegistry.load(path="/etc/myapp/chains.json") # custom
```

### 4.2 Routescan Frontend URLs: Generic Pattern + Vanity Enrichment

**Layer 1 — Universal fallback (always works):**
Routescan documents a generic URL pattern that works for all supported chains:

```
Mainnet:  https://routescan.io/{path}?chainid={chain_id}
Testnet:  https://testnet.routescan.io/{path}?chainid={chain_id}

Paths: /address/{addr}, /tx/{hash}, /block/{num}, /token/{addr}
```

Note: `/block/{num}` requires `?chainid=` even on vanity hostnames (per docs).

**Layer 2 — Vanity hostnames (polish, populated by registry generate script):**
The generate script issues `HEAD` requests to `{chain_id}.routescan.io` and captures
the `Location` header redirect target (e.g., `basescan.routescan.io`).

Registry entries gain a `frontend_url_vanity: str | None` field. The URL builder
prefers vanity when present, falls back to the generic pattern for new/unmapped chains.

Vanity hostnames are captured during regeneration. New chains not yet probed get the
generic pattern automatically. Removed chains (404 from HEAD) have their vanity cleared.

### 4.3 Caching: meatie Middleware with Force-Refresh

- Keyed by `(backend_type, chain_id, module, action, params_hash)`
- Default TTL: 30 seconds
- `cache_ttl` kwarg on client init; `0` disables
- `force_refresh=True` on individual calls bypasses cache

```python
client = AsyncBlockpartyClient(chain_id=8453, cache_ttl=60)
txs = await client.get_internal_transactions(address="0x...", force_refresh=True)
```

### 4.4 Retry and Backoff: meatie Middleware

Exponential backoff with jitter, handling:

- HTTP 429 — respects `Retry-After` header
- HTTP 5xx — transient server errors
- `status=0` with rate-limit message — treated as soft 429

| Setting | Default |
|---------|---------|
| Max retries | 3 |
| Initial backoff | 1.0s |
| Backoff multiplier | 2.0 |
| Max backoff | 30s |
| Jitter | ±25% |
| Retryable status codes | 429, 500, 502, 503, 504 |

Configurable: `max_retries`, `backoff_base` kwargs on client.

### 4.5 Rate Limiting: Shared Token Bucket per (Provider, Credential)

Rate limits are fundamentally per *(provider, credential)* — not per client instance.
Two clients hitting Etherscan with the same key share one budget.

#### Provider Tiers (Enums)

```python
class EtherscanTier(Enum):
    FREE = "free"               # 3 rps / 100K rpd
    LITE = "lite"               # 5 rps / 100K rpd
    STANDARD = "standard"       # 10 rps / 200K rpd
    ADVANCED = "advanced"       # 20 rps / 500K rpd
    PROFESSIONAL = "pro"        # 30 rps / 1M rpd

class RoutescanTier(Enum):
    ANONYMOUS = "anonymous"     # 2 rps / 10K rpd (no key)
    FREE = "free"               # 5 rps / 100K rpd
    STANDARD = "standard"       # 10 rps / 200K rpd
    ADVANCED = "advanced"       # 20 rps / 500K rpd
    PROFESSIONAL = "pro"        # 30 rps / 1M rpd
    PRO_PLUS = "pro_plus"       # 30 rps / 1.5M rpd

class BlockscoutTier(Enum):
    ANONYMOUS = "anonymous"     # ~5 rps; refined by response headers
    KEYED = "keyed"             # ~10 rps; refined by response headers
```

#### Custom Escape Hatch

```python
@dataclass(frozen=True)
class CustomRateLimit:
    """For enterprise plans or non-standard limits."""
    rps: int
    rpd: int

# Usage
client = AsyncBlockpartyClient(
    chain_id=8453,
    explorer_type="etherscan",
    api_key="...",
    tier=CustomRateLimit(rps=50, rpd=2_000_000),
)
```

The `tier` parameter on `BlockpartyClient` and `ProviderCredential` accepts either
a provider-specific tier enum OR a `CustomRateLimit` instance:

```python
tier: EtherscanTier | RoutescanTier | BlockscoutTier | CustomRateLimit | None
```

#### Blockscout Header-Based Adaptive Limits

Blockscout returns rate limit state in response headers:

```
X-Ratelimit-Limit: 600
X-Ratelimit-Remaining: 598
X-Ratelimit-Reset: 60000   (milliseconds)
```

The rate limit middleware uses the tier as the *initial* token bucket configuration,
then adapts dynamically from these headers on every response. If headers are absent
(older/self-hosted instances), tier defaults are used. This mirrors how well-behaved
GitHub API clients handle rate limits — configure a starting point, refine from server
feedback.

Etherscan and Routescan do not expose these headers, so they rely solely on
configured tiers.

#### Shared Rate Limit Registry

```python
class RateLimitBudget:
    """Token bucket for a single (provider, credential) pair. Async-safe."""
    async def acquire(self) -> None: ...     # blocks until token available
    def acquire_sync(self) -> None: ...      # blocking sync variant
    def update_from_headers(self, headers: dict) -> None: ...

class RateLimitRegistry:
    """Maps (provider_type, api_key | None) → RateLimitBudget. Process-global."""
    def get_or_create(
        self,
        provider: ExplorerType,
        api_key: str | None,
        tier: ...,
    ) -> RateLimitBudget: ...
```

Standalone `BlockpartyClient` creates a single-entry registry. `BlockpartyPool`
creates a shared registry passed to all clients it manages.

### 4.6 Testnet Handling: Transparent to Consumer

Consumer provides `chain_id`. The registry knows `is_testnet`. Routescan backend
reads it to build `/mainnet/` vs `/testnet/` URL paths. Etherscan and Blockscout
don't care (chain_id or hostname is sufficient).

**Detection during registry generation:**

| Source | Method |
|--------|--------|
| Etherscan | `"Testnet"` substring in `chainname` |
| Routescan | Chains from `/testnet/` endpoint |
| Blockscout | `isTestnet` boolean in API |
| Conflicts | Majority vote; single-source chains trust that source |

### 4.7 Client Instantiation: Context Managers Optional

```python
# Context manager (preferred)
async with AsyncBlockpartyClient(chain_id=8453) as client:
    txs = await client.get_internal_transactions(address="0x...")

# Direct instantiation
client = AsyncBlockpartyClient(chain_id=8453)
txs = await client.get_internal_transactions(address="0x...")
await client.close()

# Sync equivalents
with SyncBlockpartyClient(chain_id=8453) as client: ...
client = SyncBlockpartyClient(chain_id=8453); ...; client.close()
```

### 4.8 Fallback: Pool-Only Feature with Warning Propagation

Fallback lives exclusively in `BlockpartyPool`. Standalone `BlockpartyClient` never
falls back — errors propagate directly.

#### Fallback Triggers

The pool's job is to get data. Warnings indicate degraded configuration.
Exceptions mean nobody could serve the request.

| Condition | Falls back? | Rationale |
|-----------|-------------|-----------|
| Connection error / timeout | ✅ Yes | Transient |
| HTTP 5xx | ✅ Yes | Transient |
| HTTP 429 / rate limit exhaustion | ✅ Yes | Budget exhausted for this provider |
| `InvalidAPIKeyError` | ✅ Yes (with warning) | Config issue, but data available elsewhere |
| `InvalidAddressError` | ❌ No (raise) | Input error; no provider will help |
| `PremiumEndpointError` | ❌ No (raise) | Endpoint unavailable on other providers |
| Validation / parameter errors | ❌ No (raise) | Caller's bug |

#### Warning Mechanism

Uses Python's standard `warnings` module (same pattern as urllib3, SQLAlchemy):

```python
class BlockpartyWarning(UserWarning):
    """Base warning for blockparty."""

class FallbackWarning(BlockpartyWarning):
    """Emitted when a request falls back to another explorer."""

class AuthFallbackWarning(FallbackWarning):
    """Emitted when fallback was triggered by an authentication failure."""
```

Consumers control behavior via standard mechanisms:

```python
import warnings
warnings.filterwarnings("error", category=FallbackWarning)    # escalate to exception
warnings.filterwarnings("ignore", category=FallbackWarning)   # silence
# Or: logging.captureWarnings(True) for logging integration
```

The pool emits warnings, never suppresses errors silently. If all providers in the
fallback chain fail, the pool raises the *last* exception with context about all
attempted providers.

---

## 5. Component Details

### 5.1 Explorer Backends

```python
class ExplorerBackend(Protocol):
    @property
    def name(self) -> ExplorerType: ...
    def build_request_url(self, api_url: str, params: dict) -> str: ...
    def inject_auth(self, params: dict, api_key: str | None) -> dict: ...
    def normalize_internal_tx(self, raw: dict) -> dict: ...
    def parse_error(self, response: dict) -> BlockpartyError | None: ...
```

| Behavior | Etherscan | Routescan | Blockscout |
|----------|-----------|-----------|------------|
| **API URL** | From registry | From registry (chain_id in path) | From registry (per-chain hostname) |
| **Chain ID in request** | `chainid` query param | Baked into `api_url` path | N/A |
| **API key** | Required (`apikey` param) | Optional | Optional |
| **`hash` field** | `hash` | `hash` | `transactionHash` → `hash` |
| **`type` field** | `type` | `type` | `callType` → `type` |
| **`traceId`** | Present | Present | Absent |
| **`index`** | Absent | Absent | Present |
| **Top-level `status`** | `"1"` / `"0"` | `"1"` / `"0"` | Absent |
| **Rate limit headers** | No | No | Yes (`X-Ratelimit-*`) |

### 5.2 Normalized Response Models

```python
from typing import Annotated
from pydantic import BaseModel, BeforeValidator, ConfigDict

def coerce_numeric(v: str | int) -> int:
    """Coerce '0x1a' or '12345' string to int."""
    if isinstance(v, int):
        return v
    if isinstance(v, str):
        v = v.strip()
        return int(v, 16) if v.startswith("0x") else int(v)
    raise ValueError(f"Cannot coerce {v!r} to int")

CoercedInt = Annotated[int, BeforeValidator(coerce_numeric)]

def coerce_bool(v: str | bool | int) -> bool:
    """Coerce '0'/'1' string to bool."""
    if isinstance(v, bool):
        return v
    if isinstance(v, (str, int)):
        return str(v) != "0"
    raise ValueError(f"Cannot coerce {v!r} to bool")

CoercedBool = Annotated[bool, BeforeValidator(coerce_bool)]


class InternalTransaction(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    block_number: CoercedInt           # "blockNumber"
    timestamp: CoercedInt              # "timeStamp" (unix epoch)
    hash: str                          # "hash" (ES/RS) or "transactionHash" (BS)
    from_address: str                  # "from"
    to_address: str                    # "to"
    value: CoercedInt                  # wei
    contract_address: str              # "contractAddress"
    input: str                         # "input"
    type: str                          # "type" (ES/RS) or "callType" (BS)
    gas: CoercedInt                    # "gas"
    gas_used: CoercedInt               # "gasUsed"
    is_error: CoercedBool              # "isError" — "0"/"1" → bool
    error_code: str                    # "errCode"

    # Provider-specific — not analogous
    trace_id: str | None = None        # Etherscan / Routescan only
    index: str | None = None           # Blockscout only


class ExplorerResponse[T](BaseModel):
    """API response envelope."""
    status: str | None = None          # "1"/"0"; None for Blockscout
    message: str
    result: list[T]
```

### 5.3 Chain Registry

```python
class ChainEntry(BaseModel):
    chain_id: int
    name: str
    is_testnet: bool
    explorers: list[ExplorerInfo]

class ExplorerInfo(BaseModel):
    type: ExplorerType                 # "etherscan" | "routescan" | "blockscout"
    api_url: str                       # full base URL for API calls
    frontend_url: str                  # generic frontend URL (always present)
    frontend_url_vanity: str | None    # vanity hostname URL (Routescan only, when available)
    status: int | None = None          # Etherscan status (0=offline, 1=ok, 2=degraded)
    hosted_by: str | None = None       # Blockscout: "blockscout" vs "self"

class ChainRegistry:
    @classmethod
    def load(cls, path: Path | None = None) -> ChainRegistry: ...
    def get(self, chain_id: int) -> ChainEntry: ...
    def list_chains(self) -> list[ChainEntry]: ...
    def search(self, query: str) -> list[ChainEntry]: ...
    def get_explorer(
        self, chain_id: int, explorer_type: ExplorerType | None = None,
    ) -> ExplorerInfo: ...
```

### 5.4 Standalone Client

```python
class AsyncBlockpartyClient:
    def __init__(
        self,
        chain_id: int,
        *,
        explorer_type: ExplorerType | None = None,
        api_key: str | None = None,
        hostname: str | None = None,
        tier: EtherscanTier | RoutescanTier | BlockscoutTier | CustomRateLimit | None = None,
        cache_ttl: int = 30,
        max_retries: int = 3,
        backoff_base: float = 1.0,
        registry: ChainRegistry | None = None,
        rate_limit_registry: RateLimitRegistry | None = None,
    ): ...

    async def close(self) -> None: ...
    async def __aenter__(self) -> Self: ...
    async def __aexit__(self, *exc) -> None: ...

    async def get_internal_transactions(
        self,
        address: str,
        start_block: int = 0,
        end_block: int = 99999999,
        page: int = 1,
        offset: int = 10,
        sort: Literal["asc", "desc"] = "asc",
        *,
        force_refresh: bool = False,
    ) -> ExplorerResponse[InternalTransaction]: ...

    @property
    def urls(self) -> ExplorerURLs: ...
```

`SyncBlockpartyClient` mirrors this without `async`/`await`.

#### Explorer Resolution (when `explorer_type` omitted)

```
1. Look up chain_id in ChainRegistry
2. If hostname provided → prefer Blockscout
3. If api_key provided → prefer Etherscan
4. Otherwise → priority: Etherscan > Routescan > Blockscout
5. Raise ExplorerNotFoundError if no explorer supports this chain
```

### 5.5 Connection Pool (Orchestrator)

```python
class ProviderCredential(BaseModel):
    """Defines a provider + its auth and rate limit configuration."""
    type: ExplorerType
    api_key: str | None = None
    tier: EtherscanTier | RoutescanTier | BlockscoutTier | CustomRateLimit | None = None

class AsyncBlockpartyPool:
    def __init__(
        self,
        credentials: list[ProviderCredential],
        *,
        cache_ttl: int = 30,
        max_retries: int = 3,
        backoff_base: float = 1.0,
        registry: ChainRegistry | None = None,
    ): ...

    async def close(self) -> None: ...
    async def __aenter__(self) -> Self: ...
    async def __aexit__(self, *exc) -> None: ...

    async def get_internal_transactions(
        self,
        chain_id: int,
        address: str,
        start_block: int = 0,
        end_block: int = 99999999,
        page: int = 1,
        offset: int = 10,
        sort: Literal["asc", "desc"] = "asc",
        *,
        force_refresh: bool = False,
    ) -> ExplorerResponse[InternalTransaction]: ...

    def urls(self, chain_id: int) -> ExplorerURLs: ...
```

`SyncBlockpartyPool` mirrors this.

#### Pool Routing Logic

```
1. Receive request with chain_id
2. For each credential in order:
   a. Check: does this provider support chain_id? (registry lookup)
   b. If not, skip to next credential
   c. Get or create a cached BlockpartyClient for (chain_id, provider)
   d. Execute request
   e. On success: return result
   f. On fallback-eligible error:
      - Emit FallbackWarning (or AuthFallbackWarning for auth errors)
      - Continue to next credential
   g. On non-fallback error: raise immediately
3. If all credentials exhausted: raise last error with context
```

#### Credential Order = Fallback Order

```python
pool = AsyncBlockpartyPool(
    credentials=[
        # First choice: Etherscan with paid tier
        ProviderCredential(type="etherscan", api_key="ES_KEY", tier=EtherscanTier.STANDARD),
        # Fallback: Routescan unauthenticated
        ProviderCredential(type="routescan", tier=RoutescanTier.ANONYMOUS),
        # Last resort: Blockscout unauthenticated
        ProviderCredential(type="blockscout"),
    ],
)
```

### 5.6 URL Builders

```python
class ExplorerURLs:
    def __init__(self, frontend_url: str, frontend_url_vanity: str | None = None): ...

    def address(self, address: str) -> str: ...     # /address/{addr}
    def tx(self, tx_hash: str) -> str: ...           # /tx/{hash}
    def token(self, token_address: str) -> str: ...  # /token/{addr}
    def block(self, block_number: int) -> str: ...   # /block/{num}
    def blocks(self) -> str: ...                     # /blocks
```

URL patterns across providers:

| Path | Etherscan | Routescan (vanity) | Routescan (generic) | Blockscout |
|------|-----------|--------------------|---------------------|------------|
| Address | `{host}/address/{addr}` | `{vanity}/address/{addr}` | `routescan.io/address/{addr}?chainid={id}` | `{host}/address/{addr}` |
| Transaction | `{host}/tx/{hash}` | `{vanity}/tx/{hash}` | `routescan.io/tx/{hash}?chainid={id}` | `{host}/tx/{hash}` |
| Token | `{host}/token/{addr}` | `{vanity}/token/{addr}` | `routescan.io/token/{addr}?chainid={id}` | `{host}/token/{addr}` |
| Block | `{host}/block/{num}` | `{vanity}/block/{num}?chainid={id}` | `routescan.io/block/{num}?chainid={id}` | `{host}/block/{num}` |
| All Blocks | `{host}/blocks` | `{vanity}/blocks` | `routescan.io/blocks?chainid={id}` | `{host}/blocks` |

Note: Routescan `/block/` requires `chainid` even on vanity hostnames (per their docs).
Builder prefers vanity URL when available, falls back to generic.

### 5.7 Exception Hierarchy

```python
class BlockpartyError(Exception):
    """Base exception for all blockparty errors."""

class ConfigurationError(BlockpartyError):
    """Missing required configuration."""

class ChainNotFoundError(BlockpartyError):
    """Chain ID not found in registry."""

class ExplorerNotFoundError(BlockpartyError):
    """No explorer of the requested type supports this chain."""

class ExplorerAPIError(BlockpartyError):
    """API returned status=0 or unexpected response."""
    def __init__(self, message: str, result: str | None = None):
        self.api_message = message
        self.api_result = result
        super().__init__(f"Explorer API error: {message}")

class InvalidAPIKeyError(ExplorerAPIError):
    """API key is missing, invalid, or lacks permissions."""

class RateLimitError(ExplorerAPIError):
    """Rate limit exceeded."""

class PremiumEndpointError(ExplorerAPIError):
    """Endpoint requires premium/paid API subscription."""

class InvalidAddressError(ExplorerAPIError):
    """Address format is invalid."""

class PoolExhaustedError(BlockpartyError):
    """All providers in the pool failed for a request."""
    def __init__(self, errors: list[tuple[ExplorerType, Exception]]):
        self.provider_errors = errors
        summary = "; ".join(f"{p}: {e}" for p, e in errors)
        super().__init__(f"All providers failed: {summary}")
```

Error detection heuristics (parsed from response `message` and `result`):

| Pattern | Exception |
|---------|-----------|
| "Invalid API Key" / "Missing/Invalid API Key" | `InvalidAPIKeyError` |
| "Max rate limit" / "Rate limit" | `RateLimitError` |
| "Invalid address" | `InvalidAddressError` |
| "premium" / "PRO endpoint" | `PremiumEndpointError` |
| Any other `status=0` | `ExplorerAPIError` |

### 5.8 Warning Classes

```python
class BlockpartyWarning(UserWarning):
    """Base warning for blockparty."""

class FallbackWarning(BlockpartyWarning):
    """A request fell back to another explorer due to a transient error."""

class AuthFallbackWarning(FallbackWarning):
    """A request fell back due to an authentication failure on the preferred provider."""
```

---

## 6. Registry Data Sources

### 6.1 Etherscan — `GET https://api.etherscan.io/v2/chainlist`

```json
{
  "totalcount": 68,
  "result": [
    {
      "chainname": "Base Mainnet",
      "chainid": "8453",
      "blockexplorer": "https://basescan.org/",
      "apiurl": "https://api.etherscan.io/v2/api?chainid=8453",
      "status": 1,
      "comment": ""
    }
  ]
}
```

**Fields extracted:** `chain_id` (int), `name`, `is_testnet` ("Testnet" in chainname),
`frontend_url` (blockexplorer), `api_url` (apiurl), `status`.

### 6.2 Routescan — `GET https://api.routescan.io/v2/network/{net}/evm/all/blockchains`

Fetch both `/mainnet/` and `/testnet/` variants.

```json
{
  "items": [
    {
      "name": "C-Chain",
      "chainId": "43114",
      "evmChainId": "43114",
      "symbol": "AVAX",
      "freeApiRateLimit": { "rps": 5, "rpd": 100000 }
    }
  ]
}
```

**Fields extracted:** `chain_id`, `name`, `is_testnet` (from endpoint variant).
**Constructed:** `api_url` = `https://api.routescan.io/v2/network/{net}/evm/{chain_id}/etherscan/api`
**Frontend:** Generic `https://routescan.io/...?chainid={id}` (testnet: `testnet.routescan.io`).
**Vanity:** Probed via HEAD to `{chain_id}.routescan.io` during `generate`.

### 6.3 Blockscout — `GET https://chains.blockscout.com/api/chains`

```json
{
  "8453": {
    "name": "Base",
    "isTestnet": false,
    "layer": 2,
    "explorers": [
      { "url": "https://base.blockscout.com/", "hostedBy": "blockscout" }
    ]
  }
}
```

**Fields extracted:** `chain_id` (from key), `name`, `is_testnet`, `frontend_url`
(explorer URL), `hosted_by`.
**Constructed:** `api_url` = `{explorer_url}api`.

### 6.4 Merged Format (chains.json)

```json
[
  {
    "chain_id": 8453,
    "name": "Base Mainnet",
    "is_testnet": false,
    "explorers": [
      {
        "type": "etherscan",
        "api_url": "https://api.etherscan.io/v2/api?chainid=8453",
        "frontend_url": "https://basescan.org/",
        "frontend_url_vanity": null,
        "status": 1,
        "hosted_by": null
      },
      {
        "type": "routescan",
        "api_url": "https://api.routescan.io/v2/network/mainnet/evm/8453/etherscan/api",
        "frontend_url": "https://routescan.io",
        "frontend_url_vanity": "https://basescan.routescan.io",
        "status": null,
        "hosted_by": null
      },
      {
        "type": "blockscout",
        "api_url": "https://base.blockscout.com/api",
        "frontend_url": "https://base.blockscout.com/",
        "frontend_url_vanity": null,
        "status": null,
        "hosted_by": "blockscout"
      }
    ]
  }
]
```

---

## 7. Implementation Phases

### Phase 1: Core Foundation
- [ ] Project scaffolding (`pyproject.toml`, src layout, ruff/mypy config)
- [ ] `_types.py` — `CoercedInt`, `CoercedBool`, `ExplorerType` literal, type aliases
- [ ] `exceptions.py` — full hierarchy including `PoolExhaustedError`
- [ ] `warnings.py` — `FallbackWarning`, `AuthFallbackWarning`
- [ ] `models/responses.py` — `InternalTransaction`, `ExplorerResponse[T]`
- [ ] `backends/_base.py` — `ExplorerBackend` protocol
- [ ] Unit tests for coercion types and models

### Phase 2: Backends
- [ ] `backends/etherscan.py`
- [ ] `backends/routescan.py`
- [ ] `backends/blockscout.py`
- [ ] Unit tests: URL building, auth injection, normalization, error parsing per backend

### Phase 3: Chain Registry
- [ ] `models/registry.py` — `ChainEntry`, `ExplorerInfo`
- [ ] `registry/sources.py` — fetch + parse for all 3 APIs + Routescan vanity probing
- [ ] `registry/chain_registry.py` — `load()`, `get()`, `list_chains()`, `search()`, `get_explorer()`
- [ ] `registry/generate.py` — CLI: regenerate snapshot + `SUPPORTED_CHAINS.md`
- [ ] Generate initial bundled `data/chains.json`
- [ ] Tests with mocked HTTP

### Phase 4: Rate Limiting
- [ ] `ratelimit/tiers.py` — provider tier enums, `CustomRateLimit`
- [ ] `ratelimit/budget.py` — `RateLimitBudget` (token bucket, async+sync safe)
- [ ] `ratelimit/registry.py` — `RateLimitRegistry` (shared budgets by provider+credential)
- [ ] Blockscout header-based adaptive logic
- [ ] Tests for token bucket behavior, budget sharing, header adaptation

### Phase 5: Clients (meatie)
- [ ] `client/_middleware.py` — cache, retry, auth, error parsing, rate limit middleware
- [ ] `client/_base.py` — shared endpoint definitions
- [ ] `client/async_client.py` — `AsyncBlockpartyClient`
- [ ] `client/sync_client.py` — `SyncBlockpartyClient`
- [ ] Explorer auto-resolution logic
- [ ] Unit tests (mocked HTTP) + optional integration tests (`--run-integration`)

### Phase 6: URL Builders
- [ ] `urls/builder.py` — `ExplorerURLs` with vanity preference
- [ ] Wired into client via `.urls` property
- [ ] Tests for all URL patterns across all providers (generic + vanity)

### Phase 7: Connection Pool
- [ ] `pool/_base.py` — shared routing, fallback, client caching logic
- [ ] `pool/async_pool.py` — `AsyncBlockpartyPool`
- [ ] `pool/sync_pool.py` — `SyncBlockpartyPool`
- [ ] Fallback logic with warning emission
- [ ] `PoolExhaustedError` with multi-provider context
- [ ] Tests: fallback scenarios, auth fallback, exhaustion, rate limit handoff

### Phase 8: Polish & Packaging
- [ ] `__init__.py` — clean public API with `__all__`
- [ ] `py.typed` marker
- [ ] README with comprehensive examples
- [ ] `SUPPORTED_CHAINS.md` (auto-generated)
- [ ] CI pipeline: ruff, mypy, pytest, weekly chain regeneration
- [ ] Publish to PyPI

---

## 8. Public API Surface

```python
from blockparty import (
    # Standalone clients
    AsyncBlockpartyClient,
    SyncBlockpartyClient,

    # Connection pools (orchestrators)
    AsyncBlockpartyPool,
    SyncBlockpartyPool,
    ProviderCredential,

    # Models
    InternalTransaction,
    ExplorerResponse,
    ChainEntry,
    ExplorerInfo,

    # Registry
    ChainRegistry,

    # URL builder
    ExplorerURLs,

    # Rate limiting
    EtherscanTier,
    RoutescanTier,
    BlockscoutTier,
    CustomRateLimit,

    # Exceptions
    BlockpartyError,
    ConfigurationError,
    ChainNotFoundError,
    ExplorerNotFoundError,
    ExplorerAPIError,
    InvalidAPIKeyError,
    RateLimitError,
    PremiumEndpointError,
    InvalidAddressError,
    PoolExhaustedError,

    # Warnings
    BlockpartyWarning,
    FallbackWarning,
    AuthFallbackWarning,
)
```

---

## 9. Usage Examples

### Standalone Client (Simple)

```python
# Async — auto-resolves best explorer
async with AsyncBlockpartyClient(chain_id=8453) as client:
    response = await client.get_internal_transactions(
        address="0x88D19A03C429029901d917510f8f582D2e5F803B",
        start_block=7775467,
        offset=10,
        sort="asc",
    )
    for tx in response.result:
        print(f"{tx.hash}: {tx.value} wei from {tx.from_address}")
        print(f"  Block: {tx.block_number}, Error: {tx.is_error}")

    # URL builder
    print(client.urls.address("0x88D19A..."))
    print(client.urls.tx(response.result[0].hash))
    print(client.urls.token("0x4200000000000000000000000000000000000006"))
    print(client.urls.block(7796207))
    print(client.urls.blocks())


# Explicit explorer + auth
async with AsyncBlockpartyClient(
    chain_id=8453,
    explorer_type="etherscan",
    api_key="YOUR_KEY",
    tier=EtherscanTier.STANDARD,
) as client:
    response = await client.get_internal_transactions(address="0x...")


# Sync
with SyncBlockpartyClient(chain_id=8453) as client:
    response = client.get_internal_transactions(address="0x...")


# Without context manager
client = AsyncBlockpartyClient(chain_id=8453)
response = await client.get_internal_transactions(address="0x...")
await client.close()
```

### Connection Pool (Multi-Chain + Fallback)

```python
# Multi-chain with fallback
async with AsyncBlockpartyPool(
    credentials=[
        ProviderCredential(type="etherscan", api_key="ES_KEY", tier=EtherscanTier.STANDARD),
        ProviderCredential(type="routescan", tier=RoutescanTier.ANONYMOUS),
        ProviderCredential(type="blockscout"),
    ],
) as pool:
    # Routes to best provider per chain, falls back on transient errors
    base_txs = await pool.get_internal_transactions(chain_id=8453, address="0x...")
    arb_txs = await pool.get_internal_transactions(chain_id=42161, address="0x...")

    # URL builder (requires chain_id)
    print(pool.urls(chain_id=8453).tx("0x..."))

# Handling fallback warnings
import warnings
import logging

logging.captureWarnings(True)  # route warnings to logging
# Or: warnings.filterwarnings("error", category=FallbackWarning)
```

### Registry Exploration

```python
registry = ChainRegistry.load()

entry = registry.get(8453)
print(entry.name)                    # "Base Mainnet"
print(entry.is_testnet)              # False
for explorer in entry.explorers:
    print(f"  {explorer.type}: {explorer.frontend_url}")

all_chains = registry.list_chains()
matches = registry.search("base")    # fuzzy search
```

### Custom Rate Limits

```python
# Enterprise plan with non-standard limits
client = AsyncBlockpartyClient(
    chain_id=8453,
    explorer_type="etherscan",
    api_key="ENTERPRISE_KEY",
    tier=CustomRateLimit(rps=50, rpd=2_000_000),
)
```

### CLI: Regenerate Chain Registry

```bash
python -m blockparty.registry.generate

# Output:
#   ✓ Fetched 68 chains from Etherscan
#   ✓ Fetched 142 chains from Routescan (mainnet)
#   ✓ Fetched 87 chains from Routescan (testnet)
#   ✓ Fetched 583 chains from Blockscout
#   ✓ Probed 142 Routescan vanity hostnames (128 resolved)
#   ✓ Merged: 647 unique chains
#   ✓ Written to src/blockparty/registry/data/chains.json
#   ✓ Written to SUPPORTED_CHAINS.md
```

---

## 10. File Tree (Final)

```
blockparty/
├── pyproject.toml
├── README.md
├── LICENSE
├── SUPPORTED_CHAINS.md               # Auto-generated chain support matrix
├── src/
│   └── blockparty/
│       ├── __init__.py
│       ├── _types.py
│       ├── exceptions.py
│       ├── warnings.py
│       ├── py.typed
│       ├── client/
│       │   ├── __init__.py
│       │   ├── _base.py
│       │   ├── _middleware.py
│       │   ├── async_client.py
│       │   └── sync_client.py
│       ├── pool/
│       │   ├── __init__.py
│       │   ├── _base.py
│       │   ├── async_pool.py
│       │   └── sync_pool.py
│       ├── backends/
│       │   ├── __init__.py
│       │   ├── _base.py
│       │   ├── etherscan.py
│       │   ├── routescan.py
│       │   └── blockscout.py
│       ├── models/
│       │   ├── __init__.py
│       │   ├── responses.py
│       │   └── registry.py
│       ├── ratelimit/
│       │   ├── __init__.py
│       │   ├── tiers.py
│       │   ├── budget.py
│       │   └── registry.py
│       ├── registry/
│       │   ├── __init__.py
│       │   ├── chain_registry.py
│       │   ├── sources.py
│       │   ├── generate.py
│       │   └── data/
│       │       └── chains.json
│       └── urls/
│           ├── __init__.py
│           └── builder.py
└── tests/
    ├── conftest.py
    ├── test_types.py
    ├── test_backends/
    │   ├── test_etherscan.py
    │   ├── test_routescan.py
    │   └── test_blockscout.py
    ├── test_models/
    │   └── test_responses.py
    ├── test_registry/
    │   ├── test_chain_registry.py
    │   └── test_sources.py
    ├── test_ratelimit/
    │   ├── test_budget.py
    │   ├── test_registry.py
    │   └── test_tiers.py
    ├── test_client/
    │   ├── test_async_client.py
    │   ├── test_sync_client.py
    │   └── test_middleware.py
    ├── test_pool/
    │   ├── test_async_pool.py
    │   ├── test_sync_pool.py
    │   └── test_fallback.py
    └── test_urls/
        └── test_builder.py
```
