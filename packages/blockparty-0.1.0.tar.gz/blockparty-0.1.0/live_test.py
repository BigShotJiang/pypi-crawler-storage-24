#!/usr/bin/env python
"""Live smoke test for blockparty.

Exercises the main code paths against real APIs.  Runs without API keys
by default (Routescan anonymous + Blockscout anonymous).  Set
ETHERSCAN_API_KEY to also test Etherscan.

Usage:
    python live_test.py
    ETHERSCAN_API_KEY=your_key python live_test.py
"""

from __future__ import annotations

import asyncio
import os
import sys
import time
import warnings

# Show all blockparty warnings (especially fallback warnings).
warnings.simplefilter("always", category=UserWarning)

from blockparty import (
    AsyncBlockpartyClient,
    AsyncBlockpartyPool,
    ProviderCredential,
    ProviderSet,
    SyncBlockpartyClient,
    SyncBlockpartyPool,
)

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

CHAIN_ID = 8453  # Base Mainnet
# WETH on Base — always has internal transactions.
ADDRESS = "0x4200000000000000000000000000000000000006"
ETHERSCAN_KEY = os.environ.get("ETHERSCAN_API_KEY")


def header(title: str) -> None:
    print(f"\n{'=' * 60}")
    print(f"  {title}")
    print(f"{'=' * 60}")


def show_results(label: str, resp) -> None:  # noqa: ANN001
    print(
        f"  [{label}] status={resp.status}  message={resp.message}  "
        f"count={len(resp.result)}  provider={resp.provider}"
    )
    if resp.result:
        tx = resp.result[0]
        print(f"  First tx: hash={tx.hash[:20]}...  value={tx.value}  type={tx.type}")


# ---------------------------------------------------------------------------
# 1. Async single client
# ---------------------------------------------------------------------------


async def test_async_client() -> None:
    header("1. AsyncBlockpartyClient — Blockscout (no key)")

    async with AsyncBlockpartyClient(
        chain_id=CHAIN_ID,
        explorer_type="blockscout",
    ) as client:
        resp = await client.get_internal_transactions(address=ADDRESS, limit=3)
        show_results("blockscout/async", resp)
        print(f"  Explorer URL: {client.urls.address(ADDRESS)}")


# ---------------------------------------------------------------------------
# 2. Sync single client
# ---------------------------------------------------------------------------


def test_sync_client() -> None:
    header("2. SyncBlockpartyClient — Routescan anonymous (no key)")

    with SyncBlockpartyClient(
        chain_id=CHAIN_ID,
        explorer_type="routescan",
    ) as client:
        resp = client.get_internal_transactions(address=ADDRESS, limit=3)
        show_results("routescan/sync", resp)

        url = client.urls.tx(resp.result[0].hash) if resp.result else "N/A"
        print(f"  TX URL: {url}")


# ---------------------------------------------------------------------------
# 3. Pool with fallback
# ---------------------------------------------------------------------------


async def test_pool_fallback() -> None:
    header("3. AsyncBlockpartyPool — credential-ordered fallback")

    credentials = []

    if ETHERSCAN_KEY:
        credentials.append(
            ProviderCredential(type="etherscan", api_key=ETHERSCAN_KEY),
        )
        print("  Etherscan key found — will try Etherscan first.")
    else:
        # Use Etherscan WITHOUT a key — it will fail with InvalidAPIKeyError,
        # triggering a visible fallback warning.  This is intentional.
        credentials.append(ProviderCredential(type="etherscan"))
        print(
            "  No ETHERSCAN_API_KEY — Etherscan will fail, expect a "
            "FallbackWarning."
        )

    credentials += [
        ProviderCredential(type="routescan"),
        ProviderCredential(type="blockscout"),
    ]

    async with AsyncBlockpartyPool(credentials=credentials) as pool:
        resp = await pool.get_internal_transactions(
            chain_id=CHAIN_ID, address=ADDRESS, limit=3,
        )
        show_results("pool", resp)

        url = pool.urls(CHAIN_ID).address(ADDRESS)
        print(f"  Pool URL (first matching provider): {url}")


# ---------------------------------------------------------------------------
# 4. Sync pool
# ---------------------------------------------------------------------------


def test_sync_pool() -> None:
    header("4. SyncBlockpartyPool — same fallback, sync")

    credentials = [
        ProviderCredential(type="routescan"),
        ProviderCredential(type="blockscout"),
    ]

    with SyncBlockpartyPool(credentials=credentials) as pool:
        resp = pool.get_internal_transactions(
            chain_id=CHAIN_ID, address=ADDRESS, limit=3,
        )
        show_results("sync pool", resp)


# ---------------------------------------------------------------------------
# 5. Shared ProviderSet across multiple clients
# ---------------------------------------------------------------------------


async def test_shared_providers() -> None:
    header("5. ProviderSet — shared rate limits across clients")

    providers = ProviderSet([
        ProviderCredential(type="routescan"),
        ProviderCredential(type="blockscout"),
    ])

    client_base = AsyncBlockpartyClient(chain_id=8453, providers=providers)
    client_eth = AsyncBlockpartyClient(chain_id=1, providers=providers)

    try:
        # Both clients share the same rate limit budgets via the ProviderSet.
        resp_base = await client_base.get_eth_price()
        resp_eth = await client_eth.get_eth_price()

        print(f"  Base ETH price:     {resp_base.result.ethusd}")
        print(f"  Ethereum ETH price: {resp_eth.result.ethusd}")
        print(f"  Same routescan budget? {
            providers.resolve_for_chain(8453, client_base._registry)[0].budget
            is providers.resolve_for_chain(1, client_eth._registry)[0].budget
        }")
    finally:
        await client_base.close()
        await client_eth.close()


# ---------------------------------------------------------------------------
# 6. Cache hit demonstration
# ---------------------------------------------------------------------------


async def test_cache_hit() -> None:
    header("6. Cache hit — second call should be instant")

    async with AsyncBlockpartyClient(
        chain_id=CHAIN_ID,
        explorer_type="blockscout",
        cache_ttl=60,
    ) as client:
        t0 = time.perf_counter()
        await client.get_internal_transactions(address=ADDRESS, limit=3)
        first = time.perf_counter() - t0

        t0 = time.perf_counter()
        await client.get_internal_transactions(address=ADDRESS, limit=3)
        second = time.perf_counter() - t0

        print(f"  First call:  {first:.3f}s (network)")
        print(f"  Second call: {second:.6f}s (cache)")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


async def async_main() -> None:
    await test_async_client()
    await test_pool_fallback()
    await test_shared_providers()
    await test_cache_hit()


def main() -> None:
    print("blockparty live smoke test")
    print(f"Chain: {CHAIN_ID} (Base Mainnet)")
    print(f"Address: {ADDRESS}")
    print(f"Etherscan key: {'set' if ETHERSCAN_KEY else 'not set'}")

    asyncio.run(async_main())
    test_sync_client()
    test_sync_pool()

    header("All tests passed!")


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print(f"\n❌ FAILED: {type(exc).__name__}: {exc}", file=sys.stderr)
        sys.exit(1)
