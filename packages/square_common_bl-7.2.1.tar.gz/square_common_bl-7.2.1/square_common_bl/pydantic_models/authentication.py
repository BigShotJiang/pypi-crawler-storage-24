from typing import List, TypeAlias, Dict

from pydantic import BaseModel
from square_commons.api_utils import StandardResponse
from square_database_structure.square.authentication.enums import RecoveryMethodEnum


class DeleteUserV0(BaseModel):
    password: str


class LogoutAppsV0(BaseModel):
    app_names: List[str]


class ValidateEmailVerificationCodeV0(BaseModel):
    verification_code: str


class SendResetPasswordEmailV0(BaseModel):
    username: str


class UpdateUserRecoveryMethodsV0(BaseModel):
    recovery_methods_to_add: List[RecoveryMethodEnum] = None
    recovery_methods_to_remove: List[RecoveryMethodEnum] = None


DeleteUserV0Response: TypeAlias = StandardResponse[None]


class UpdateUsernameV0ResponseMain(BaseModel):
    user_id: str
    username: str


class UpdateUsernameV0Response(BaseModel):
    main: UpdateUsernameV0ResponseMain


class GetUserDetailsV0ResponseMainProfile(BaseModel):
    user_profile_id: int
    user_profile_photo_storage_token: str | None
    user_profile_email: str | None
    user_profile_phone_number_country_code: str | None
    user_profile_phone_number: str | None
    user_profile_first_name: str | None
    user_profile_last_name: str | None
    user_profile_email_verified: str | None


class GetUserDetailsV0ResponseMainSession(BaseModel):
    app_name: str
    active_sessions: int


class GetUserDetailsV0ResponseMainEmailVerification(BaseModel):
    expires_at: str
    cooldown_reset_at: str


class GetUserDetailsV0ResponseMainBackupCodes(BaseModel):
    total: int
    available: int
    generated_at: str


class GetUserDetailsV0ResponseMain(BaseModel):
    user_id: str
    username: str
    profile: GetUserDetailsV0ResponseMainProfile
    apps: List[str]
    sessions: List[GetUserDetailsV0ResponseMainSession]
    recovery_methods: Dict[str, bool]
    email_verification_details: GetUserDetailsV0ResponseMainEmailVerification | None
    backup_code_details: GetUserDetailsV0ResponseMainBackupCodes | None
    auth_providers: List[str]


class GetUserDetailsV0Response(BaseModel):
    main: GetUserDetailsV0ResponseMain


class UpdateProfilePhotoV0Response(BaseModel):
    main: str | None


LogoutAppsV0Response: TypeAlias = StandardResponse[None]
LogoutAllV0Response: TypeAlias = StandardResponse[None]


class ValidateEmailVerificationCodeV0Response(BaseModel):
    user_profile_email_verified: str


class SendVerificationEmailV0Response(BaseModel):
    expires_at: str
    cooldown_reset_at: str


class UpdateProfileDetailsV0ResponseMain(BaseModel):
    user_profile_photo_storage_token: str | None
    user_profile_email: str | None
    user_profile_phone_number_country_code: str | None
    user_profile_first_name: str | None
    user_profile_last_name: str | None
    user_id: str
    user_profile_id: int
    user_profile_email_verified: str | None
    user_profile_phone_number: str | None


class UpdateProfileDetailsV0Response(BaseModel):
    main: UpdateProfileDetailsV0ResponseMain


class SendResetPasswordEmailV0Response(BaseModel):
    expires_at: str
    cooldown_reset_at: str


class GenerateAccountBackupCodesV0ResponseMain(BaseModel):
    user_id: str
    backup_codes: List[str]


class GenerateAccountBackupCodesV0Response(BaseModel):
    main: GenerateAccountBackupCodesV0ResponseMain


class UpdateUserRecoveryMethodsV0Response(BaseModel):
    main: List[str]


class GetUserRecoveryMethodsV0ResponseBackupCodes(BaseModel):
    total: int
    available: int
    generated_at: str


class GetUserRecoveryMethodsV0ResponseEmailRecovery(BaseModel):
    expires_at: str
    cooldown_reset_at: str


class GetUserRecoveryMethodsV0Response(BaseModel):
    main: Dict[str, bool]
    email_recovery_details: GetUserRecoveryMethodsV0ResponseEmailRecovery | None
    backup_code_details: GetUserRecoveryMethodsV0ResponseBackupCodes | None
