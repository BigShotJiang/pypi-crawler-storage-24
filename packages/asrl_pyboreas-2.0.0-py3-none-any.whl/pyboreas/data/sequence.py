import os
import os.path as osp
import numpy as np

from pyboreas.data.calib import Calib
from pyboreas.data.sensors import Camera, Lidar, Radar, Aeva
from pyboreas.data.auxsensors import AuxCSV, DMU, AevaIMU, Encoder
from pyboreas.utils.utils import get_closest_frame


class Sequence:
    """
    Class for working with an individual Boreas dataset sequence
    """

    def __init__(self, boreas_root, seqSpec, labelFolder="labels", load_aux_frames=False):
        """init
        Args:
            boreas_root (str): path to root folder ex: /path/to/data/boreas/
            seqSpec (list): defines sequence ID, start_time, and end_time
        """
        self.ID = seqSpec[0]
        if len(seqSpec) > 2:
            assert (
                seqSpec[2] > seqSpec[1]
            ), "Sequence timestamps must go forward in time"
            self.start_ts = str(seqSpec[1])
            self.end_ts = str(seqSpec[2])
        else:
            self.start_ts = "0"  # dummy start and end if not specified
            self.end_ts = "9" * 21
        self.labelFolder = labelFolder
        self.seq_root = osp.join(boreas_root, self.ID)
        self.applanix_root = osp.join(self.seq_root, "applanix")
        self.calib_root = osp.join(self.seq_root, "calib")
        self.aeva_root = osp.join(self.seq_root, "aeva")
        self.camera_root = osp.join(self.seq_root, "camera")
        self.lidar_root = osp.join(self.seq_root, "lidar")
        self.radar_root = osp.join(self.seq_root, "radar")
        self.imu_root = osp.join(self.seq_root, "imu")
        self.dmu_csv_path = osp.join(self.imu_root, "dmu_imu.csv")
        self.infilled_dmu_csv_path = osp.join(self.imu_root, "dmu_imu_infilled.csv")
        self.aeva_imu_csv_path = osp.join(self.imu_root, "aeva_imu.csv")
        self.encoder_csv_path = osp.join(self.applanix_root, "dmi.csv")

        self._check_dataroot_valid()  # Check if folder structure correct

        self.calib = Calib(self.calib_root)
        # Creates list of frame objects for cam, lidar, radar, and inits poses
        self.get_all_frames()

        # Optionally load auxiliary frames (not loaded by default since they take a bit to load in the first time)
        if load_aux_frames:
            self.get_all_aux_frames()
        else:
            self.dmu_frames = []
            self.aeva_imu_frames = []
            self.encoder_frames = []

        self.load_label_files()

        self._check_download()  # prints warning when sensor data missing

    def print(self):
        print("SEQ: {}".format(self.ID))
        if self.end_ts != "9" * 21:
            print("START: {} END: {}".format(self.start_ts, self.end_ts))
        print("camera frames: {}".format(len(self.camera_frames)))
        print("lidar frames: {}".format(len(self.lidar_frames)))
        print("radar frames: {}".format(len(self.radar_frames)))
        print("aeva frames: {}".format(len(self.aeva_frames)))
        print("dmu frames: {}".format(len(self.dmu_frames)))
        print("aeva imu frames: {}".format(len(self.aeva_imu_frames)))
        print("encoder frames: {}".format(len(self.encoder_frames)))
        print("-------------------------------")

    @property
    def has_aeva(self):
        """Returns true if sequence has Aeva lidar data"""
        return len(self.aeva_frames) > 0

    def get_camera(self, idx):
        self.camera_frames[idx].load_data()
        return self.camera_frames[idx]

    @property
    def camera(self):
        for camera_frame in self.camera_frames:
            camera_frame.load_data()
            yield camera_frame

    def get_camera_iter(self):
        """Retrieves an iterator on camera frames"""
        return iter(self.camera)

    def get_lidar(self, idx):
        self.lidar_frames[idx].load_data()
        return self.lidar_frames[idx]

    @property
    def lidar(self):
        for lidar_frame in self.lidar_frames:
            lidar_frame.load_data()
            yield lidar_frame

    def get_lidar_iter(self):
        """Retrieves an iterator on lidar frames"""
        return iter(self.lidar)

    def get_radar(self, idx):
        self.radar_frames[idx].load_data()
        return self.radar_frames[idx]

    @property
    def radar(self):
        for radar_frame in self.radar_frames:
            radar_frame.load_data()
            yield radar_frame

    def get_radar_iter(self):
        """Retrieves an iterator on radar frames"""
        return iter(self.radar)

    def get_dmu(self, idx):
        self.dmu_frames[idx].load_data()
        return self.dmu_frames[idx]

    @property
    def dmu(self):
        for dmu_frame in self.dmu_frames:
            dmu_frame.load_data()
            yield dmu_frame

    def get_dmu_data(self, start_micro=None, end_micro=None):
        if not osp.exists(self.dmu_csv_path):
            raise ValueError(f"DMU csv file not found at {self.dmu_csv_path}")
        csv = AuxCSV.get_instance(self.dmu_csv_path, timestamp_multiplier=DMU.timestamp_multiplier)
        timestamps, data = csv.get_all_data(start_micro, end_micro)
        return {
            'timestamps_micro': timestamps,
            'body_angvel': data[:, 1:4],
            'body_acc': data[:, 4:7],
        }

    def get_dmu_iter(self):
        """Retrieves an iterator on dmu frames"""
        return iter(self.dmu)

    def get_aeva_imu(self, idx):
        self.aeva_imu_frames[idx].load_data()
        return self.aeva_imu_frames[idx]

    @property
    def aeva_imu(self):
        for imu_frame in self.aeva_imu_frames:
            imu_frame.load_data()
            yield imu_frame

    def get_aeva_imu_data(self, start_micro=None, end_micro=None):
        if not osp.exists(self.aeva_imu_csv_path):
            raise ValueError(f"Aeva IMU csv file not found at {self.aeva_imu_csv_path}")
        csv = AuxCSV.get_instance(self.aeva_imu_csv_path, timestamp_multiplier=AevaIMU.timestamp_multiplier)
        timestamps, data = csv.get_all_data(start_micro, end_micro)
        return {
            'timestamps_micro': timestamps,
            'body_angvel': data[:, 1:4],
            'body_acc': data[:, 4:7],
        }

    def get_aeva_imu_iter(self):
        """Retrieves an iterator on aeva imu frames"""
        return iter(self.aeva_imu)

    def get_encoder(self, idx):
        self.encoder_frames[idx].load_data()
        return self.encoder_frames[idx]

    @property
    def encoder(self):
        for encoder_frame in self.encoder_frames:
            encoder_frame.load_data()
            yield encoder_frame

    def get_encoder_data(self, start_micro=None, end_micro=None):
        if not osp.exists(self.encoder_csv_path):
            raise ValueError(f"Encoder csv file not found at {self.encoder_csv_path}")
        csv = AuxCSV.get_instance(self.encoder_csv_path, timestamp_multiplier=Encoder.timestamp_multiplier)
        timestamps, data = csv.get_all_data(start_micro, end_micro)
        return {
            'timestamps_micro': timestamps,
            'pulse_count': data[:, 1],
        }

    def get_encoder_iter(self):
        """Retrieves an iterator on encoder frames"""
        return iter(self.encoder)

    def _check_dataroot_valid(self):
        """Checks if the sequence folder structure is valid"""
        if not osp.isdir(self.applanix_root):
            raise ValueError("ERROR: applanix dir missing from dataroot of sequence {}".format(self.ID))
        if not osp.isdir(self.calib_root):
            raise ValueError("ERROR: calib dir missing from dataroot of sequence {}".format(self.ID))

    def _check_download(self):
        """Checks if all sensor data has been downloaded, prints a warning otherwise"""
        if osp.isdir(self.aeva_root) and len(os.listdir(self.aeva_root)) < len(
            self.aeva_frames
        ):
            print("WARNING: aeva frames are not all downloaded")
        if osp.isdir(self.camera_root) and len(os.listdir(self.camera_root)) < len(
            self.camera_frames
        ):
            print("WARNING: camera images are not all downloaded: {}".format(self.ID))
        if osp.isdir(self.lidar_root) and len(os.listdir(self.lidar_root)) < len(
            self.lidar_frames
        ):
            print("WARNING: lidar frames are not all downloaded: {}".format(self.ID))
        if osp.isdir(self.radar_root) and len(os.listdir(self.radar_root)) < len(
            self.radar_frames
        ):
            print("WARNING: radar scans are not all downloaded: {}".format(self.ID))
        gtfile = osp.join(self.applanix_root, "gps_post_process.csv")
        if not osp.exists(gtfile):
            print(
                "WARNING: this may be a test sequence, or the groundtruth is not yet available: {}".format(
                    self.ID
                )
            )

    def _get_frames(self, posefile, root, ext, SensorType):
        """Initializes sensor frame objects with their ground truth pose information
        Args:
            posefile (str): path to ../sensor_poses.csv
            root (str): path to the root of the sensor folder ../sensor/
            ext (str): file extension specific to this sensor type
            SensorType (cls): sensor class specific to this sensor type
        Returns:
            frames (list): list of sensor frame objects
        """
        frames = []
        if osp.exists(posefile):
            with open(posefile, "r") as f:
                f.readline()  # header
                for line in f:
                    data = line.split(",")
                    ts = data[0]
                    if self.start_ts <= ts and ts <= self.end_ts:
                        frame = SensorType(osp.join(root, ts + ext))
                        frame.init_pose(data)
                        frame.labelFolder = self.labelFolder
                        frames.append(frame)
        elif osp.isdir(root):
            framenames = sorted([f for f in os.listdir(root) if f.endswith(ext)])
            for framename in framenames:
                ts = framename.split(",")[0]
                if self.start_ts <= ts and ts <= self.end_ts:
                    frame = SensorType(osp.join(root, framename))
                    frame.labelFolder = self.labelFolder
                    frames.append(frame)
        return frames

    def _get_aux_frames(self, csv_path, AuxSensorType):
        """Initializes aux sensor frame objects using the csv file

        Args:
            csv_path (str): path to <sensor>.csv
            AuxSensorType (cls): aux sensor class specific to this sensor

        Returns:
            frames (list): list of aux sensor frame objects
        """
        if not osp.exists(csv_path):
            return []

        frames = []
        csv = AuxCSV.get_instance(csv_path, timestamp_multiplier=AuxSensorType.timestamp_multiplier)
        timestamps_micro = csv.get_all_timestamps_micro()

        for ts_micro in timestamps_micro:
            if float(self.start_ts) <= ts_micro and ts_micro <= float(self.end_ts):
                frame = AuxSensorType(csv_path, ts_micro)
                frames.append(frame)
        return frames

    def get_all_frames(self):
        """Convenience method for retrieving sensor frames of all types"""
        afile = osp.join(self.applanix_root, "aeva_poses.csv")
        cfile = osp.join(self.applanix_root, "camera_poses.csv")
        lfile = osp.join(self.applanix_root, "lidar_poses.csv")
        rfile = osp.join(self.applanix_root, "radar_poses.csv")
        self.aeva_frames = self._get_frames(afile, self.aeva_root, ".bin", Aeva)
        self.camera_frames = self._get_frames(cfile, self.camera_root, ".png", Camera)
        self.lidar_frames = self._get_frames(lfile, self.lidar_root, ".bin", Lidar)
        self.radar_frames = self._get_frames(rfile, self.radar_root, ".png", Radar)

    def get_all_aux_frames(self):
        self.dmu_frames = self._get_aux_frames(self.dmu_csv_path, DMU)
        self.aeva_imu_frames = self._get_aux_frames(self.aeva_imu_csv_path, AevaIMU)
        self.encoder_frames = self._get_aux_frames(self.encoder_csv_path, Encoder)

    def reset_frames(self):
        """Resets all frames, removes downloaded data"""
        self.get_all_frames()

    def synchronize_frames(self, ref="camera"):
        """Simulates having synchronous measurements
        Note: measurements still won't be at the exact same timestamp and will have different poses
        However, for a given reference index, the other measurements will be as close to the reference
        in time as they can be.
        Args:
            ref (str): [camera, lidar, or radar] this determines which sensor's frames will be used as the
                reference for synchronization. This sensor's list of frames will not be modified. However,
                the other two list of sensor frames will be modified so that each index will approximately
                align with the reference in time.
        """
        cstamps = [frame.timestamp for frame in self.camera_frames]
        lstamps = [frame.timestamp for frame in self.lidar_frames]
        rstamps = [frame.timestamp for frame in self.radar_frames]
        astamps = [frame.timestamp for frame in self.aeva_frames]

        if ref == "camera":
            if lstamps:
                self.lidar_frames = [
                    get_closest_frame(cstamp, lstamps, self.lidar_frames)
                    for cstamp in cstamps
            ]
            if rstamps:
                self.radar_frames = [
                    get_closest_frame(cstamp, rstamps, self.radar_frames)
                    for cstamp in cstamps
                ]
            if astamps:
                self.aeva_frames = [
                    get_closest_frame(cstamp, astamps, self.aeva_frames)
                    for cstamp in cstamps
                ]
        elif ref == "lidar":
            if cstamps:
                self.camera_frames = [
                    get_closest_frame(lstamp, cstamps, self.camera_frames)
                    for lstamp in lstamps
                ]
            if rstamps:
                self.radar_frames = [
                    get_closest_frame(lstamp, rstamps, self.radar_frames)
                    for lstamp in lstamps
                ]
            if astamps:
                self.aeva_frames = [
                    get_closest_frame(lstamp, astamps, self.aeva_frames)
                    for lstamp in lstamps
                ]
        elif ref == "radar":
            if cstamps:
                self.camera_frames = [
                    get_closest_frame(rstamp, cstamps, self.camera_frames)
                    for rstamp in rstamps
                ]
            if lstamps:
                self.lidar_frames = [
                    get_closest_frame(rstamp, lstamps, self.lidar_frames)
                    for rstamp in rstamps
                ]
            if astamps:
                self.aeva_frames = [
                    get_closest_frame(rstamp, astamps, self.aeva_frames)
                    for rstamp in rstamps
                ]
        elif ref == "aeva":
            if cstamps:
                self.camera_frames = [
                    get_closest_frame(astamp, cstamps, self.camera_frames)
                    for astamp in astamps
                ]
            if lstamps:
                self.lidar_frames = [
                    get_closest_frame(astamp, lstamps, self.lidar_frames)
                    for astamp in astamps
                ]
            if rstamps:
                self.radar_frames = [
                    get_closest_frame(astamp, rstamps, self.radar_frames)
                    for astamp in astamps
                ]

    def filter_frames_gt(self):
        # Only keep lidar frames that were labelled, NO interpolated frames
        keep = []
        for frame in self.lidar_frames:
            if frame.has_bbs():
                keep.append(frame)
        self.lidar_frames = keep

    def load_label_files(self):
        self.labelFiles = []
        self.labelTimes = []
        self.labelPoses = []
        for frame in self.lidar_frames:
            if frame.has_bbs():
                self.labelFiles.append(
                    osp.join(self.seq_root, self.labelFolder, frame.frame + ".txt")
                )
                self.labelTimes.append(frame.timestamp)
                self.labelPoses.append(frame.pose)
