"""Additional coverage for console.py - unknown status badge and step()."""

from __future__ import annotations

from cli.console import status_badge, step


class TestStatusBadgeUnknown:
    def test_unknown_status_returns_question_mark(self):
        badge = status_badge("some-weird-status")
        assert "?" in badge.plain

    def test_known_statuses_all_render(self):
        for s in ("active", "inactive", "idle", "pending", "faulty", "unknown"):
            badge = status_badge(s)
            assert badge.plain  # non-empty

    def test_integer_status_active(self):
        badge = status_badge(1)
        assert "active" in badge.plain

    def test_integer_status_idle(self):
        badge = status_badge(2)
        assert "idle" in badge.plain

    def test_integer_status_faulty(self):
        badge = status_badge(3)
        assert "faulty" in badge.plain

    def test_integer_status_unknown(self):
        badge = status_badge(99)
        assert "?" in badge.plain


class TestStep:
    def test_step_does_not_raise(self):
        # step() writes to the shared console - just ensure it runs without error
        step("doing something")
        step("with [bold]markup[/bold]")
