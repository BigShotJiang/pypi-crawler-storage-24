from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("ethiack-beacon")
except PackageNotFoundError:
    __version__ = "dev"
