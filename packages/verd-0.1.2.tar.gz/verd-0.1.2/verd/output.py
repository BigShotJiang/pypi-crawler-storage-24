from rich.console import Console
from rich.text import Text
from rich.live import Live
from rich.spinner import Spinner

console = Console()

VERDICT_STYLES = {
    "PASS": "bold green",
    "FAIL": "bold red",
    "UNCERTAIN": "bold yellow",
}


class StatusDisplay:
    def __init__(self):
        self._live = Live(console=console, transient=True)
        self._started = False

    def update(self, message: str):
        renderable = Spinner("dots", text=f"  {message}", style="cyan")
        if not self._started:
            self._live.start()
            self._started = True
        self._live.update(renderable)

    def pause(self):
        """Temporarily stop live display so we can print static content."""
        if self._started:
            self._live.stop()
            self._started = False

    def stop(self):
        self.pause()


def format_result(result: dict) -> Text:
    verdict = result.get("verdict", "UNCERTAIN")
    confidence = result.get("confidence", 0.0)
    headline = result.get("headline") or result.get("summary", "")
    strengths = result.get("strengths", [])
    issues = result.get("issues", [])
    fixes = result.get("fixes", [])
    elapsed = result.get("elapsed", 0.0)

    style = VERDICT_STYLES.get(verdict, "bold white")
    pct = f"{int(confidence * 100)}%"

    output = Text()

    # Headline
    output.append(f"{verdict}  ", style=style)
    output.append(f"{pct}  ", style=style)
    output.append(headline)

    # Strengths
    if strengths:
        output.append("\n")
        for s in strengths:
            output.append(f"\n+ {s}", style="green")

    # Issues
    if issues:
        output.append("\n")
        for issue in issues:
            output.append(f"\n- {issue}", style="red")

    # Fixes
    if fixes:
        output.append("\n")
        for fix in fixes:
            output.append(f"\n\u2192 {fix}", style="cyan")

    # Footer
    usage = result.get("usage", {})
    footer_parts = [f"completed in {elapsed}s"]
    total_tokens = usage.get("prompt_tokens", 0) + usage.get("completion_tokens", 0)
    if total_tokens:
        reasoning = usage.get("reasoning_tokens", 0)
        footer_parts.append(f"{total_tokens:,} tokens")
        if reasoning:
            footer_parts.append(f"{reasoning:,} reasoning")
    cost = result.get("cost", 0)
    if cost:
        footer_parts.append(f"~${cost:.2f}")
    output.append(f"\n\n{' \u2022 '.join(footer_parts)}", style="dim")

    return output


def format_transcript(transcript: list[dict]) -> Text:
    return _format_transcript_text(transcript)


_ROUND_LABELS = [
    "Initial Assessment",
    "Cross-Examination",
    "Rebuttal",
    "Final Rebuttal",
]


def _format_transcript_text(transcript: list[dict]) -> Text:
    rounds: dict[int, list[tuple[str, str]]] = {}
    for entry in transcript:
        r = entry["round"]
        rounds.setdefault(r, []).append((entry["model"], entry["response"]))

    output = Text()
    for r in sorted(rounds):
        label = _ROUND_LABELS[r] if r < len(_ROUND_LABELS) else f"Round {r}"
        output.append(f"--- {label} ---\n", style="bold cyan")
        for model, response in rounds[r]:
            output.append(f"[{model}]\n", style="bold")
            output.append(f"{response}\n\n")
    return output


def print_round(round_num: int, entries: list[dict]):
    """Print a single round's results live as they come in."""
    label = _ROUND_LABELS[round_num] if round_num < len(_ROUND_LABELS) else f"Round {round_num}"
    console.print(f"\n--- {label} ---", style="bold cyan")
    for entry in entries:
        console.print(f"[{entry['model']}]", style="bold")
        console.print(entry["response"])
        console.print()


def print_result(result: dict):
    text = format_result(result)
    console.print(text)
