MODELS = {
    "verdl": {
        "debaters": [
            "gpt-5-mini",
            "gemini-2.5-flash",
        ],
        "judge": "claude-sonnet-4-6",
        "rounds": 1,
    },
    "verd": {
        "debaters": [
            "claude-sonnet-4-6",
            "gpt-5-mini",
            "gemini-2.5-flash",
            "gpt-4.1",
        ],
        "judge": "o3",
        "rounds": 2,
    },
    "verdh": {
        "debaters": [
            "claude-opus-4-6",
            "gpt-5.4",
            "gemini-3.1-pro-preview",
            "sonar-pro",
            "deepseek-r1",
        ],
        "judge": "o3",
        "rounds": 3,
    },
}

MODEL_PARAMS = {
    "sonar-pro": {
        "web_search_options": {"search_context_size": "high"},
    },
    "o3": {
        "reasoning_effort": "high",
    },
}
