import asyncio
import sys
import time

from verd.config import get_client, DEBATER_MAX_TOKENS, TIMEOUTS, estimate_cost
from verd.context import files_to_content
from verd.models import MODELS, MODEL_PARAMS
from verd.judge import run_judge
from verd.output import print_round
from verd.selector import select_relevant_files


async def call_model(
    model: str,
    messages: list[dict],
    max_tokens: int,
    timeout: int,
) -> tuple[str, dict]:
    """Returns (text, usage_dict). Retries once with 2x tokens on empty response."""
    extra = MODEL_PARAMS.get(model, {})
    for attempt in range(2):
        budget = max_tokens if attempt == 0 else max_tokens * 2
        response = await asyncio.wait_for(
            get_client().chat.completions.create(
                model=model,
                messages=messages,
                max_completion_tokens=budget,
                **extra,
            ),
            timeout=timeout,
        )
        text = response.choices[0].message.content
        usage = {
            "prompt_tokens": response.usage.prompt_tokens,
            "completion_tokens": response.usage.completion_tokens,
            "reasoning_tokens": getattr(
                response.usage.completion_tokens_details, "reasoning_tokens", 0
            ) or 0,
        }
        if text and text.strip():
            return text.strip(), usage
        if attempt == 0:
            print(f"⚠ {model} empty response, retrying with 2x tokens", file=sys.stderr)

    raise ValueError(f"{model} returned empty response after retry")


def _is_question(text: str) -> bool:
    """Detect if the input is a question vs a claim/assertion."""
    text = text.strip().lower()
    if text.endswith("?"):
        return True
    question_starters = ("what", "which", "how", "should", "is it", "can we", "would", "could",
                         "where", "when", "why", "who", "do we", "are we", "will")
    return any(text.startswith(w) for w in question_starters)


def _build_round0_prompt(content: str, claim: str) -> str:
    is_q = _is_question(claim)

    if is_q:
        preamble = (
            "You are an expert analyst participating in a structured multi-model debate. "
            "You've been given a question along with context from a conversation. "
            "Your job is to analyze the context, weigh the different perspectives and evidence, "
            "and give your clear recommendation or answer.\n\n"
            "Be specific and actionable. Reference what people said in the conversation. "
            "If there are trade-offs, state them clearly and pick a side. "
            "Don't just summarize — take a position and defend it."
        )
        verdict_instruction = (
            "Deliver your verdict:\n"
            "- PASS if there's a clear best answer/approach\n"
            "- FAIL if the proposed direction is wrong and you recommend something else\n"
            "- UNCERTAIN if genuinely insufficient information to decide\n"
            "Then give your recommendation with specific reasoning."
        )
    else:
        preamble = (
            "You are an expert reviewer and critical analyst participating in a structured debate. "
            "Your job is to rigorously evaluate whether a claim is correct, incorrect, or uncertain. "
            "You must be intellectually honest \u2014 do not hedge or give vague answers. "
            "If the claim is wrong, say so clearly and explain why. If it's right, identify the "
            "strongest possible objection. If you're genuinely uncertain, state exactly what "
            "information would resolve it.\n\n"
            "Think step by step. Consider edge cases, hidden assumptions, and common pitfalls. "
            "Ground your reasoning in specifics, not generalities."
        )
        verdict_instruction = (
            "Deliver your assessment: PASS (claim is correct), FAIL (claim is incorrect), "
            "or UNCERTAIN. Then explain your key reasoning. Be concise and specific."
        )

    if content:
        return (
            f"{preamble}\n\n"
            f"Context:\n{content}\n\n"
            f'Question: "{claim}"\n\n'
            f"{verdict_instruction}"
        )
    return (
        f"{preamble}\n\n"
        f'Question: "{claim}"\n\n'
        f"{verdict_instruction}"
    )


def _build_followup_prompt(
    claim: str,
    own_response: str,
    others: list[tuple[str, str]],
) -> str:
    parts = [
        "You are an expert reviewer in a structured multi-model debate. "
        "You gave an initial assessment and other independent reviewers have now weighed in. "
        "Your goal is to converge on the truth, not to win the argument.\n\n"
        "CRITICAL: Do NOT change your position just because other reviewers disagree. "
        "Only change if they present NEW EVIDENCE or identify a SPECIFIC FLAW in your reasoning. "
        "Headcount is not evidence — 4 wrong reviewers don't outweigh 1 right one. "
        "If you have concrete evidence (especially from web search, documentation, or direct knowledge) "
        "that contradicts the majority, HOLD YOUR GROUND and explain why your evidence is stronger. "
        "Consensus without new evidence is groupthink, not truth.\n\n"
        "You already have the full content from the previous round — focus on the arguments."
    ]
    parts.append(f'\nClaim: "{claim}"')
    parts.append(f"\nYour previous response:\n{own_response}")
    parts.append("\nOther reviewers said:")
    for name, resp in others:
        parts.append(f"[{name}]: {resp}")
    parts.append(
        "\nCritically evaluate the other reviewers' arguments. If you disagree, "
        "identify the specific flaw in their reasoning. If you agree, stress-test "
        "the consensus by stating the strongest possible counter-argument. "
        "If new evidence changed your mind, say exactly what and why. "
        "Conclude with your updated verdict: PASS, FAIL, or UNCERTAIN."
    )
    return "\n".join(parts)


async def run_debate(
    content: str,
    claim: str,
    mode: str,
    timeout_override: int | None = None,
    status_display=None,
    files: list | None = None,
    verbose: bool = False,
    status_callback=None,
) -> dict:
    cfg = MODELS[mode]
    debaters = cfg["debaters"]
    judge_model = cfg["judge"]
    num_rounds = cfg["rounds"]
    timeout = timeout_override or TIMEOUTS[mode]
    debater_tokens = DEBATER_MAX_TOKENS.get(mode, 4096)
    transcript: list[dict] = []
    total_usage = {"prompt_tokens": 0, "completion_tokens": 0, "reasoning_tokens": 0}
    total_cost = 0.0
    start = time.time()

    def status(msg: str):
        if status_display:
            status_display.update(msg)
        if status_callback:
            asyncio.ensure_future(status_callback(msg))

    def track_usage(model: str, usage: dict):
        for k in total_usage:
            total_usage[k] += usage.get(k, 0)
        nonlocal total_cost
        total_cost += estimate_cost(
            model, usage.get("prompt_tokens", 0), usage.get("completion_tokens", 0)
        )

    # Smart context selection — only when files come from dir scan
    if files is not None and len(files) > 0:
        selected = await select_relevant_files(files, claim, status_callback=status)
        content = files_to_content(selected)

    # Track which models are still valid
    valid_models = list(debaters)

    # Round 0
    model_names = " + ".join(debaters)
    status(f"spawning {len(debaters)} models: {model_names}")

    round_0_prompt = _build_round0_prompt(content, claim)
    round_0_messages = [{"role": "user", "content": round_0_prompt}]

    results = await asyncio.gather(
        *[call_model(m, round_0_messages, max_tokens=debater_tokens, timeout=timeout)
          for m in debaters],
        return_exceptions=True,
    )

    valid = [(m, r) for m, r in zip(debaters, results) if not isinstance(r, Exception)]
    failed = [(m, r) for m, r in zip(debaters, results) if isinstance(r, Exception)]

    if failed:
        for m, e in failed:
            print(f"\u26a0 {m} failed: {e}", file=sys.stderr)
    if len(valid) < 1:
        raise RuntimeError("No models responded. Check your API key and model availability.")

    for model, (response, usage) in valid:
        transcript.append({"round": 0, "model": model, "response": response})
        track_usage(model, usage)

    valid_models = [m for m, _ in valid]

    if verbose:
        if status_display:
            status_display.pause()
        round_entries = [e for e in transcript if e["round"] == 0]
        print_round(0, round_entries)

    status(f"{len(valid)} models responded, initial positions locked in")

    # Subsequent rounds — content NOT re-sent, only claim + previous responses
    round_messages = [
        "models challenging each other",
        "pressure-testing arguments",
        "final rebuttals",
    ]
    for round_num in range(1, num_rounds):
        msg = round_messages[min(round_num - 1, len(round_messages) - 1)]
        status(f"round {round_num + 1}/{num_rounds + 1} \u2014 {msg}")

        tasks = []
        for model in valid_models:
            own = next(
                e["response"]
                for e in reversed(transcript)
                if e["model"] == model
            )
            others = [
                (e["model"], e["response"])
                for e in transcript
                if e["round"] == round_num - 1 and e["model"] != model
            ]
            prompt = _build_followup_prompt(claim, own, others)
            tasks.append(
                call_model(model, [{"role": "user", "content": prompt}],
                           max_tokens=debater_tokens, timeout=timeout)
            )

        results = await asyncio.gather(*tasks, return_exceptions=True)

        round_valid = []
        for m, r in zip(valid_models, results):
            if isinstance(r, Exception):
                print(f"\u26a0 {m} failed in round {round_num}", file=sys.stderr)
            else:
                text, usage = r
                transcript.append({"round": round_num, "model": m, "response": text})
                track_usage(m, usage)
                round_valid.append(m)

        if len(round_valid) < 1:
            print(
                f"\u26a0 No models responded in round {round_num}, stopping early.",
                file=sys.stderr,
            )
            break
        valid_models = round_valid

        if verbose:
            if status_display:
                status_display.pause()
            round_entries = [e for e in transcript if e["round"] == round_num]
            print_round(round_num, round_entries)

    # Judge
    status(f"{judge_model} delivering verdict")

    try:
        result, judge_usage = await run_judge(judge_model, content, claim, transcript, timeout)
        track_usage(judge_model, judge_usage)
    except Exception as e:
        print(f"\u26a0 judge ({judge_model}) failed: {e}", file=sys.stderr)
        result = {
            "verdict": "UNCERTAIN",
            "confidence": 0.0,
            "headline": "Judge failed to respond.",
            "strengths": [],
            "issues": [f"Judge error: {e}"],
            "fixes": [],
            "model_votes": {},
            "consensus": "SPLIT",
            "dissent": None,
        }

    result["elapsed"] = round(time.time() - start, 1)
    result["mode"] = mode
    result["models_used"] = valid_models
    result["judge"] = judge_model
    result["transcript"] = transcript
    result["usage"] = total_usage
    result["cost"] = round(total_cost, 4)
    return result
