from __future__ import annotations

from typing import Any, Dict, List, Optional

from ...client import AielClient
from .remote import RemoteOpenAI
from .types import OpenAIChatCompletionsCreateRequest, OpenAIEmbeddingsCreateRequest

Json = Dict[str, Any]


def _to_float_list(value: Any) -> List[float]:
    if not isinstance(value, list):
        return []
    out: List[float] = []
    for item in value:
        try:
            out.append(float(item))
        except (TypeError, ValueError):
            return []
    return out


def _extract_embeddings(raw: Json) -> List[List[float]]:
    # OpenAI native shape: {"data": [{"embedding": [...]}, ...]}
    data = raw.get("data")
    if isinstance(data, list):
        out: List[List[float]] = []
        for item in data:
            if isinstance(item, dict):
                emb = _to_float_list(item.get("embedding"))
                if emb:
                    out.append(emb)
        if out:
            return out

    # Wrapped variants: {"data": {"data": [...]}} or {"result": {"data": [...]}}
    for key in ("data", "result"):
        nested = raw.get(key)
        if isinstance(nested, dict):
            nested_data = nested.get("data")
            if isinstance(nested_data, list):
                out = []
                for item in nested_data:
                    if isinstance(item, dict):
                        emb = _to_float_list(item.get("embedding"))
                        if emb:
                            out.append(emb)
                if out:
                    return out

    # Connector-friendly variants:
    # {"embedding":[...]} for single, {"embeddings":[...]} or {"vectors":[...]} for multi
    single = _to_float_list(raw.get("embedding"))
    if single:
        return [single]

    for key in ("embeddings", "vectors"):
        value = raw.get(key)
        if isinstance(value, list):
            out = []
            for item in value:
                if isinstance(item, dict):
                    emb = _to_float_list(item.get("embedding"))
                else:
                    emb = _to_float_list(item)
                if emb:
                    out.append(emb)
            if out:
                return out

    return []


class ChatOpenAI:
    """
    LangChain-style ChatOpenAI facade backed by AIEL RemoteOpenAI integration.
    """

    def __init__(
        self,
        *,
        client: AielClient,
        workspace_id: str,
        project_id: str,
        connection_id: str,
        model: str,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        **kwargs: Any,
    ) -> None:
        self._remote = RemoteOpenAI(
            client=client,
            workspace_id=workspace_id,
            project_id=project_id,
            connection_id=connection_id,
        )
        self.model = model
        self.temperature = temperature
        self.max_tokens = max_tokens
        self._extra_defaults: Json = dict(kwargs)

    def invoke(
        self,
        messages: List[Json],
        *,
        request_id: str | None = None,
        **kwargs: Any,
    ) -> Json:
        extra = dict(self._extra_defaults)
        extra.update(kwargs)
        req = OpenAIChatCompletionsCreateRequest(
            model=self.model,
            temperature=self.temperature,
            max_tokens=self.max_tokens,
            messages=messages,
            extra=extra,
        )
        return self._remote.chat_completions_create(req, request_id=request_id).raw


class OpenAIEmbeddings:
    """
    LangChain-style OpenAIEmbeddings facade backed by AIEL RemoteOpenAI integration.
    """

    def __init__(
        self,
        *,
        client: AielClient,
        workspace_id: str,
        project_id: str,
        connection_id: str,
        model: str = "text-embedding-3-small",
        dimensions: Optional[int] = None,
        **kwargs: Any,
    ) -> None:
        self._remote = RemoteOpenAI(
            client=client,
            workspace_id=workspace_id,
            project_id=project_id,
            connection_id=connection_id,
        )
        self.model = model
        self.dimensions = dimensions
        self._extra_defaults: Json = dict(kwargs)

    def invoke(
        self,
        input: Any,
        *,
        request_id: str | None = None,
        **kwargs: Any,
    ) -> Json:
        extra = dict(self._extra_defaults)
        extra.update(kwargs)
        req = OpenAIEmbeddingsCreateRequest(
            input=input,
            model=self.model,
            dimensions=self.dimensions,
            extra=extra,
        )
        return self._remote.embeddings_create(req, request_id=request_id).raw

    def embed_query(self, text: str, *, request_id: str | None = None, **kwargs: Any) -> List[float]:
        raw = self.invoke(text, request_id=request_id, **kwargs)
        vectors = _extract_embeddings(raw)
        return vectors[0] if vectors else []

    def embed_documents(
        self,
        texts: List[str],
        *,
        request_id: str | None = None,
        **kwargs: Any,
    ) -> List[List[float]]:
        raw = self.invoke(texts, request_id=request_id, **kwargs)
        return _extract_embeddings(raw)
