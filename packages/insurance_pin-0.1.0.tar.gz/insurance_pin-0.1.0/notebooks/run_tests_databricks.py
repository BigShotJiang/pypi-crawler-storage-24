# Databricks notebook source
# COMMAND ----------
# Run insurance-pin tests on Databricks serverless.
# We add src/ to PYTHONPATH explicitly instead of using pip install -e,
# because editable installs install into a different Python path than the notebook kernel.

import subprocess, sys, os, shutil, tempfile

# Stage files to writable temp location
tmpdir = tempfile.mkdtemp(prefix="pin-tests-")
print("Staging to:", tmpdir)
shutil.copytree("/Workspace/insurance-pin-tests/src", os.path.join(tmpdir, "src"))
shutil.copytree("/Workspace/insurance-pin-tests/tests", os.path.join(tmpdir, "tests"))
shutil.copy("/Workspace/insurance-pin-tests/pyproject.toml", os.path.join(tmpdir, "pyproject.toml"))
shutil.copy("/Workspace/insurance-pin-tests/README.md", os.path.join(tmpdir, "README.md"))

# Add src to this process's sys.path
src_path = os.path.join(tmpdir, "src")
sys.path.insert(0, src_path)

# Install dependencies (not matplotlib — use pre-installed Databricks version)
deps = ["torch", "polars", "numpy", "pytest"]
r = subprocess.run([sys.executable, "-m", "pip", "install"] + deps + ["--quiet"],
                   capture_output=True, text=True)
print("Deps install rc:", r.returncode)
if r.returncode != 0:
    print(r.stderr[-500:])

# Verify import works in this kernel
import insurance_pin
print("insurance_pin version:", insurance_pin.__version__)

# Run pytest with src in PYTHONPATH so subprocess can find the package
env = dict(os.environ)
env["PYTHONPATH"] = src_path + ":" + env.get("PYTHONPATH", "")

result = subprocess.run(
    [sys.executable, "-m", "pytest",
     os.path.join(tmpdir, "tests"),
     "-v", "--tb=short",
     "-p", "no:cacheprovider"],
    capture_output=True, text=True,
    cwd=tmpdir,
    env=env,
)
output = result.stdout
print(output)
if result.stderr:
    print("STDERR:", result.stderr[-500:])
print("Return code:", result.returncode)

if result.returncode == 0:
    dbutils.notebook.exit("PASSED")
else:
    dbutils.notebook.exit("FAILED\n" + output[-5000:])
