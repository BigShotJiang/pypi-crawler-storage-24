"""
Upload insurance-pin to Databricks workspace and run pytest via a serverless job.
Uses client '2' (supported by this workspace).
"""
import os
import time
import base64
import pathlib
import json
import requests

HOST = "https://dbc-150a27f5-e1e7.cloud.databricks.com"
TOKEN = "dapi895b482f1aaae1b0cfaab97cbfe4546b"
HEADERS = {"Authorization": f"Bearer {TOKEN}"}

os.environ["DATABRICKS_HOST"] = HOST + "/"
os.environ["DATABRICKS_TOKEN"] = TOKEN

from databricks.sdk import WorkspaceClient
from databricks.sdk.service.workspace import ImportFormat, Language

w = WorkspaceClient()

WORKSPACE_PATH = "/Workspace/insurance-pin-tests"
LOCAL_SRC = "/home/ralph/repos/insurance-pin"

UPLOAD_DIRS = ["src", "tests"]
UPLOAD_FILES = ["pyproject.toml"]
SKIP_PREFIXES = [".venv", "__pycache__", ".git", "egg-info", "dist", "build"]


def should_skip(rel_path: pathlib.PurePosixPath) -> bool:
    parts = rel_path.parts
    return any(any(skip in p for skip in SKIP_PREFIXES) for p in parts)


def ws_import(path, content_bytes, fmt=ImportFormat.AUTO, language=None, overwrite=True):
    b64 = base64.b64encode(content_bytes).decode()
    kwargs = dict(path=path, content=b64, format=fmt, overwrite=overwrite)
    if language is not None:
        kwargs["language"] = language
    w.workspace.import_(**kwargs)


print("Setting up workspace directories...")
w.workspace.mkdirs(WORKSPACE_PATH)

uploaded = 0
for dir_name in UPLOAD_DIRS:
    src_dir = pathlib.Path(LOCAL_SRC) / dir_name
    for p in src_dir.rglob("*.py"):
        rel = p.relative_to(LOCAL_SRC)
        if should_skip(rel):
            continue
        ws_path = f"{WORKSPACE_PATH}/{rel}"
        parent = str(pathlib.PurePosixPath(ws_path).parent)
        try:
            w.workspace.mkdirs(parent)
        except Exception:
            pass
        ws_import(ws_path, p.read_bytes())
        print(f"  Uploaded: {rel}")
        uploaded += 1

for fname in UPLOAD_FILES:
    p = pathlib.Path(LOCAL_SRC) / fname
    if p.exists():
        ws_import(f"{WORKSPACE_PATH}/{fname}", p.read_bytes())
        print(f"  Uploaded: {fname}")
        uploaded += 1

print(f"\nUploaded {uploaded} files total")

# The notebook installs the package then runs pytest.
# Use sys.path.insert to avoid editable install issues in serverless.
TEST_NOTEBOOK_CONTENT = """# Databricks notebook source
# COMMAND ----------
# MAGIC %pip install torch polars numpy matplotlib pytest --quiet

# COMMAND ----------
import sys, subprocess

# Add src directory to path (avoids pip editable install issues in serverless)
sys.path.insert(0, "/Workspace/insurance-pin-tests/src")

# Verify import works
import insurance_pin
print("insurance_pin imported successfully, version:", insurance_pin.__version__)

# COMMAND ----------
import subprocess, sys
result = subprocess.run(
    [sys.executable, "-m", "pytest",
     "/Workspace/insurance-pin-tests/tests/",
     "-v", "--tb=short",
     "--import-mode=importlib"],
    capture_output=True, text=True,
    env={**__import__("os").environ, "PYTHONPATH": "/Workspace/insurance-pin-tests/src"},
    cwd="/Workspace/insurance-pin-tests"
)
output = result.stdout
print(output[-8000:] if len(output) > 8000 else output)
if result.stderr:
    print("STDERR:", result.stderr[-1000:])
if result.returncode != 0:
    raise RuntimeError(f"Tests failed with return code {result.returncode}")
print("ALL TESTS PASSED")
"""

test_nb_path = f"{WORKSPACE_PATH}/run_tests"
ws_import(
    test_nb_path,
    TEST_NOTEBOOK_CONTENT.encode(),
    fmt=ImportFormat.SOURCE,
    language=Language.PYTHON,
)
print(f"Uploaded test notebook to {test_nb_path}")

# Submit via raw REST API with client '2'
print("\nSubmitting test job to Databricks (serverless client=2)...")
body = {
    "run_name": "insurance-pin-tests",
    "tasks": [{
        "task_key": "run-tests",
        "notebook_task": {"notebook_path": test_nb_path},
        "environment_key": "Default",
    }],
    "environments": [{
        "environment_key": "Default",
        "spec": {"client": "2"},
    }],
}
resp = requests.post(f"{HOST}/api/2.2/jobs/runs/submit", headers=HEADERS, json=body)
resp.raise_for_status()
run_id = resp.json()["run_id"]
print(f"Job submitted. Run ID: {run_id}")

while True:
    status_resp = requests.get(
        f"{HOST}/api/2.1/jobs/runs/get",
        headers=HEADERS,
        params={"run_id": run_id},
    )
    status = status_resp.json()
    lc = status["state"]["life_cycle_state"]
    print(f"  [{time.strftime('%H:%M:%S')}] State: {lc}")
    if lc in ("TERMINATED", "SKIPPED", "INTERNAL_ERROR"):
        break
    time.sleep(30)

result_state = status["state"].get("result_state", "UNKNOWN")
print(f"\nFinal result state: {result_state}")

# Get output via task run ID
task_run_id = None
if "tasks" in status and status["tasks"]:
    task_run_id = status["tasks"][0].get("run_id")

if task_run_id:
    out_resp = requests.get(
        f"{HOST}/api/2.1/jobs/runs/get-output",
        headers=HEADERS,
        params={"run_id": task_run_id},
    )
    out_data = out_resp.json()
    if "notebook_output" in out_data and out_data["notebook_output"].get("result"):
        print("\n=== NOTEBOOK OUTPUT ===")
        out_text = out_data["notebook_output"]["result"]
        print(out_text[-8000:] if len(out_text) > 8000 else out_text)
    if "error" in out_data and out_data["error"]:
        print(f"\n=== ERROR ===\n{out_data['error']}")
    if "error_trace" in out_data and out_data["error_trace"]:
        trace = out_data["error_trace"]
        print(f"\n=== TRACE ===\n{trace[-3000:]}")

if result_state != "SUCCESS":
    print("\nTESTS FAILED")
    exit(1)
else:
    print("\nALL TESTS PASSED ON DATABRICKS")
