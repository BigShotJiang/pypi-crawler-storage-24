"""Record all Delivery Machine CLI demos using Thea.

Uses Thea's Recorder class directly (library mode, no server needed).
Each demo produces an MP4 in the output directory.

Usage:
    python record_all.py              # record all demos
    python record_all.py quickstart   # record one demo
    python record_all.py --list       # list available demos
"""

import json
import os
import sys
import time
from pathlib import Path

from thea import Recorder, generate_report
from tests.support.mock_api import start_mock_api, _mock_jwt, MOCK_USER_EMAIL, MOCK_TENANT_ID

from demos import auth, quickstart, verifications, ephemeral
from demos.terminal import create_terminal, close_terminal

OUTPUT_DIR = os.environ.get("OUTPUT_DIR", "./output")
DISPLAY = int(os.environ.get("THEA_DISPLAY", "99"))
DISPLAY_SIZE = "1280x1080"
MOCK_API_PORT = 9199

DEMOS = {
    "auth": ("Authentication — TOTP + device flow login", auth),
    "quickstart": ("Quickstart — domain + rules + log", quickstart),
    "verifications": ("Verification workflow", verifications),
    "ephemeral": ("Ephemeral addresses", ephemeral),
}


def record_demo(rec, name, module):
    """Record a single demo."""
    print(f"\n{'='*60}")
    print(f"  Recording: {name}")
    print(f"{'='*60}")

    create_terminal(rec)
    rec.start_recording(f"dm-{name}")
    module.record(rec)
    path = rec.stop_recording()
    close_terminal()

    print(f"  Video: {path}")
    return path


def main():
    if "--list" in sys.argv:
        print("Available demos:")
        for name, (desc, _) in DEMOS.items():
            print(f"  {name:20s}  {desc}")
        return

    os.makedirs(OUTPUT_DIR, exist_ok=True)

    # Start mock API so dm CLI gets realistic responses
    start_mock_api(MOCK_API_PORT)
    os.environ["DELIVERY_MACHINE_API_URL"] = f"http://127.0.0.1:{MOCK_API_PORT}/v1"
    print(f"  Mock API running on port {MOCK_API_PORT}")

    # Pre-seed a session so non-auth demos can call the API.
    session_dir = Path.home() / ".config" / "dm"
    session_dir.mkdir(parents=True, exist_ok=True)
    session_file = session_dir / "session.json"
    token = _mock_jwt(MOCK_USER_EMAIL, MOCK_TENANT_ID)
    session_file.write_text(json.dumps({
        "token": token,
        "email": MOCK_USER_EMAIL,
        "tenant_id": MOCK_TENANT_ID,
        "expires_at": int(time.time()) + 28800,
    }))
    session_file.chmod(0o600)
    print(f"  Pre-seeded session for demos")

    rec = Recorder(
        output_dir=OUTPUT_DIR,
        display=DISPLAY,
        display_size=DISPLAY_SIZE,
        framerate=24,
    )

    rec.add_panel("scene", title="Demo", width=200)
    rec.add_panel("step", title="Step")
    rec.start_display()
    os.environ["DISPLAY"] = rec.display_string

    # Which demos to record
    requested = [a for a in sys.argv[1:] if not a.startswith("-")]
    if not requested:
        requested = list(DEMOS.keys())

    results = []
    for name in requested:
        if name not in DEMOS:
            print(f"Unknown demo: {name}")
            print(f"Available: {', '.join(DEMOS)}")
            sys.exit(1)
        desc, module = DEMOS[name]
        path = record_demo(rec, name, module)
        results.append({"name": name, "desc": desc, "path": path})

    rec.cleanup()

    # Generate HTML report with all videos
    videos = []
    for r in results:
        videos.append({
            "feature": "Delivery Machine CLI",
            "scenario": r["desc"],
            "status": "passed",
            "video": r["path"],
            "steps": [],
        })
    generate_report(
        videos,
        output_dir=OUTPUT_DIR,
        title="Delivery Machine Demos",
        subtitle="Recorded with Thea",
    )

    print(f"\n{'='*60}")
    print("  All recordings complete:")
    for r in results:
        print(f"    {r['name']:20s}  {r['path']}")
    print(f"\n  Report: {OUTPUT_DIR}/report.html")
    print(f"{'='*60}")


if __name__ == "__main__":
    main()
