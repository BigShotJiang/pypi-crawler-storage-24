"""Ephemeral address demo: create a temporary forwarding rule that expires."""

from demos.terminal import run_command, clear_screen, wait


def record(rec):
    """Run the ephemeral address demo on the Thea display."""
    rec.update_panel("scene", "Ephemeral Addresses")

    rec.update_panel("step", "1. Create an ephemeral address (7 days)")
    run_command(
        'dm rules add example.com temp-signup you@gmail.com --expires 7 '
        '--description "Conference signup form"',
        pause_after=3,
    )

    rec.update_panel("step", "2. View rules with expiry dates")
    run_command("dm rules list", pause_after=3)

    rec.update_panel("step", "3. Rule detail with expiry")
    run_command("dm rules show example.com temp-signup", pause_after=3)
    clear_screen()

    rec.update_panel("step", "4. Expiring catch-all")
    run_command(
        'dm rules add example.com "*" you@gmail.com --expires 30 '
        '--description "Catch-all for new project"',
        pause_after=3,
    )

    rec.update_panel("step", "5. Disable a rule")
    run_command("dm rules disable example.com temp-signup", pause_after=2)

    rec.update_panel("step", "6. Confirm disabled status")
    run_command("dm rules list", pause_after=3)

    rec.update_panel("step", "Done!")
    wait(2)
