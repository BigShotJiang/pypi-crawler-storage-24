"""Authentication demo: create account, login via device flow.

Shows the full auth lifecycle:
  1. Create user account (provisions TOTP + verifies in one step)
  2. Login via device flow (dm login)
  3. Confirm authenticated session
  4. Logout
"""

from pathlib import Path

from demos.terminal import run_command, type_text, press_key, clear_screen, wait


def record(rec):
    """Run the auth demo on the Thea display."""
    rec.update_panel("scene", "Authentication")

    # Clear any pre-seeded session so the demo starts unauthenticated.
    session_file = Path.home() / ".config" / "dm" / "session.json"
    session_file.unlink(missing_ok=True)

    rec.update_panel("step", "1. Create user account")
    type_text("dm users add you@deliverymachine.net")
    wait(0.2)
    press_key("Return")
    wait(4)
    type_text("123456")
    wait(0.2)
    press_key("Return")
    wait(3)
    clear_screen()

    rec.update_panel("step", "2. Login — device flow")
    run_command("dm login --hours 8", pause_after=10)
    clear_screen()

    rec.update_panel("step", "3. Confirm session")
    run_command("dm domains list", pause_after=3)

    rec.update_panel("step", "4. Logout")
    run_command("dm logout", pause_after=3)

    rec.update_panel("step", "Done!")
    wait(2)

    # Re-seed session for subsequent demos.
    import json
    import time as _time
    from tests.support.mock_api import _mock_jwt, MOCK_USER_EMAIL, MOCK_TENANT_ID
    session_dir = Path.home() / ".config" / "dm"
    session_dir.mkdir(parents=True, exist_ok=True)
    token = _mock_jwt(MOCK_USER_EMAIL, MOCK_TENANT_ID)
    session_file.write_text(json.dumps({
        "token": token,
        "email": MOCK_USER_EMAIL,
        "tenant_id": MOCK_TENANT_ID,
        "expires_at": int(_time.time()) + 28800,
    }))
    session_file.chmod(0o600)
