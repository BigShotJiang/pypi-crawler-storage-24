"""Terminal automation for Thea recordings.

Thin wrapper around thea.terminal.Terminal — configures the look and
feel for Delivery Machine demos and re-exports the run_command / clear
helpers so demo scripts don't need to know about Thea directly.
"""

from thea.terminal import Terminal as _Terminal

# Module-level terminal instance, set by record_all.py for each demo.
_term = None


def create_terminal(rec):
    """Create and store a Terminal on the recorder's display."""
    global _term
    _term = _Terminal(
        rec,
        font="JetBrains Mono",
        font_size=18,
        bg="#000000",
        fg="#00ff00",
        border=8,
        fill_viewport=True,
        wpm=200,
    )
    return _term


def close_terminal():
    """Close the current terminal."""
    global _term
    if _term:
        _term.close()
        _term = None


def run_command(cmd, pause_after=1.5):
    """Type a command, press Enter, wait for output."""
    _term.run_command(cmd, pause_after=pause_after)


def clear_screen():
    """Send Ctrl+L to clear the terminal."""
    _term.clear()


def type_text(text):
    """Type text without pressing Enter."""
    _term._recorder.keyboard_type(text, wpm=200)


def press_key(key):
    """Press a single key."""
    _term._recorder.keyboard_press(key)


def wait(seconds):
    """Pause for the viewer to read output."""
    import time
    time.sleep(seconds)
