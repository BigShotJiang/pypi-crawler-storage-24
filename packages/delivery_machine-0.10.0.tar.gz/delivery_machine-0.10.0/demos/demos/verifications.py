"""Verification workflow demo: check destination email verification status."""

from demos.terminal import run_command, clear_screen, wait


def record(rec):
    """Run the verification demo on the Thea display."""
    rec.update_panel("scene", "Verifications")

    rec.update_panel("step", "1. List all destination verifications")
    run_command("dm verifications list", pause_after=3)

    rec.update_panel("step", "2. Check a specific destination")
    run_command("dm verifications check craig@barkingiguana.com", pause_after=3)

    rec.update_panel("step", "3. Resend verification email")
    run_command("dm verifications resend craig@barkingiguana.com", pause_after=3)
    clear_screen()

    rec.update_panel("step", "4. View rules for this destination")
    run_command("dm rules list", pause_after=3)

    rec.update_panel("step", "Done!")
    wait(2)
