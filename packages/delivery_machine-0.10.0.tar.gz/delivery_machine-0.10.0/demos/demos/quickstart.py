"""Quickstart demo: register a domain, add a forwarding rule, check DNS.

Shows the core workflow of Delivery Machine in ~30 seconds.
"""

from demos.terminal import run_command, clear_screen, wait


def record(rec):
    """Run the quickstart demo on the Thea display."""
    rec.update_panel("scene", "Quickstart")

    rec.update_panel("step", "1. Register a domain")
    run_command("dm domains add example.com", pause_after=3)

    rec.update_panel("step", "2. Check domain DNS")
    run_command("dm domains check example.com", pause_after=3)
    clear_screen()

    rec.update_panel("step", "3. View domain details")
    run_command("dm domains show example.com", pause_after=3)
    clear_screen()

    rec.update_panel("step", "4. Add a forwarding rule")
    run_command("dm rules add example.com hello you@gmail.com", pause_after=3)

    rec.update_panel("step", "5. Multiple destinations with roles")
    run_command("dm rules add example.com support alice@team.com cc:bob@team.com", pause_after=3)

    rec.update_panel("step", "6. List all rules")
    run_command("dm rules list", pause_after=3)

    rec.update_panel("step", "7. View rule details")
    run_command("dm rules show example.com hello", pause_after=3)
    clear_screen()

    rec.update_panel("step", "8. Activity log")
    run_command("dm rules log example.com hello", pause_after=3)

    rec.update_panel("step", "Done!")
    wait(2)
