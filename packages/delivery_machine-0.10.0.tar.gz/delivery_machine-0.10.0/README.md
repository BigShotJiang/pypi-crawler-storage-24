# Delivery Machine

Route email from all your custom domains to one inbox.

## Install

```
pip install delivery-machine
```

## Quick start

```bash
# Create an account
dm signup you@example.com

# Log in (opens browser for device-flow authentication)
dm login

# Register a domain (prints the DNS records you need to add)
dm domains add example.com

# Verify DNS is set up correctly
dm domains check example.com

# Forward all email to your inbox
dm rules add example.com '*' you@yourdomain.com

# Create a throwaway address that expires in 7 days
dm rules add example.com temp you@yourdomain.com --expires 7

# List all rules
dm rules list

# Bulk import from YAML, JSON, or CSV
dm import rules.yaml
```

## User management

```bash
# Invite a user to your tenant (requires login)
dm users add colleague@example.com

# The invited user verifies their TOTP with the invite token you share
dm users verify colleague@example.com --invite-token <token>
```

## Tenant management

```bash
# Create a new tenant (ULID assigned automatically)
dm tenants add --plan starter

# List tenants
dm tenants list

# Check usage
dm tenants usage <tenant-id>
```

## macOS integration

On macOS, `dm signup` and `dm users add` offer to save the TOTP secret to
Passwords.app and copy it to the clipboard.

## Links

- [Website](https://deliverymachine.net)
- [Issues](https://github.com/BarkingIguana/delivery-machine/issues)
