"""
Delivery Machine - Management API Lambda.

Handles CRUD for routing rules, domain registration, and authentication.
Routed via API Gateway {proxy+} integration.

Routes:
  GET    /v1/rules                        list rules (optional ?domain= filter)
  POST   /v1/rules                        create rule
  GET    /v1/rules/{domain}/{localpart}       get rule
  PUT    /v1/rules/{domain}/{localpart}       update rule
  DELETE /v1/rules/{domain}/{localpart}       delete rule
  GET    /v1/rules/{domain}/{localpart}/log   activity log for rule

  GET    /v1/domains                      list domains
  POST   /v1/domains                      register domain, returns DNS records
  GET    /v1/domains/{domain}             get domain + verification status
  GET    /v1/domains/{domain}/check      check all DNS records for domain
  DELETE /v1/domains/{domain}             remove domain

  GET    /v1/tenants                      list tenants  (admin)
  POST   /v1/tenants                      create tenant (admin, ULID auto-assigned)

  GET    /v1/verify?token=<token>         verify destination email (public, no API key)
  GET    /v1/unsubscribe?token=<token>    remove a single recipient from a rule (public, no API key)

  GET    /v1/verifications                      list verification status for tenant's destinations
  GET    /v1/verifications/{destination}       check verification status + referencing rules
  POST   /v1/verifications                     resend verification email for a destination

  POST   /v1/auth/setup                   provision TOTP (requires JWT auth)
  POST   /v1/auth/totp/verify            confirm TOTP code (JWT, invite token, or grace period)
  POST   /v1/auth/login                  browser login with email + TOTP
  POST   /v1/auth/device                 CLI initiates device flow
  POST   /v1/auth/device/poll            CLI polls for completion
  POST   /v1/auth/device/confirm         browser confirms device code
  GET    /v1/auth/me                     current user info from JWT

  GET    /v1/health                      public health check (no auth)

Authentication: JWT (Authorization: Bearer).
Tenant isolation is enforced via the tenant_id claim in the JWT.
"""
import json
import logging
import os
import re
import secrets
import urllib.parse
import urllib.request
from datetime import datetime, timezone

import boto3
from boto3.dynamodb.conditions import Key

try:
    from auth import route_auth, verify_jwt, extract_bearer_token
except ImportError:
    route_auth = None
    verify_jwt = None
    extract_bearer_token = None

logger = logging.getLogger()
logger.setLevel(logging.INFO)

dynamodb = boto3.resource("dynamodb")
ses = boto3.client("ses")

RULES_TABLE = os.environ["RULES_TABLE"]
DOMAINS_TABLE = os.environ["DOMAINS_TABLE"]
TENANTS_TABLE = os.environ["TENANTS_TABLE"]
VERIFICATIONS_TABLE = os.environ["VERIFICATIONS_TABLE"]
EVENTS_TABLE = os.environ.get("EVENTS_TABLE", "")
SES_REGION = os.environ.get("SES_REGION", "us-east-1")
FORWARD_FROM = os.environ.get("FORWARD_FROM", "forward@deliverymachine.net")
API_BASE_URL = os.environ.get("API_BASE_URL", "")

# MX hostname shown in DNS instructions.
# Defaults to mx.deliverymachine.net (a CNAME to the regional SES endpoint).
MX_HOST = os.environ.get("MX_HOST", "mx.deliverymachine.net")

# Fallback: raw SES endpoints by region (used if MX_HOST is empty)
SES_MX = {
    "us-east-1": "inbound-smtp.us-east-1.amazonaws.com",
    "us-west-2": "inbound-smtp.us-west-2.amazonaws.com",
    "eu-west-1": "inbound-smtp.eu-west-1.amazonaws.com",
}

# Rate limit thresholds
RATE_LIMIT_RULES = 20        # max new rules per tenant per hour
RATE_LIMIT_DOMAINS = 5       # max new domains per tenant per hour
VERIFICATION_COOLDOWN = 300  # seconds between verification emails per destination

# CLI version bounds (set via terraform variables)
CLI_LATEST_VERSION = os.environ.get("CLI_LATEST_VERSION", "")
CLI_MIN_VERSION = os.environ.get("CLI_MIN_VERSION", "")


def _require_tenant(tenant_id):
    """Return the tenant item if it exists, otherwise None."""
    table = dynamodb.Table(TENANTS_TABLE)
    return table.get_item(Key={"tenant_id": tenant_id}).get("Item")


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def handler(event, context):
    method = event.get("httpMethod", "GET")
    path = event.get("path", "/")
    query = event.get("queryStringParameters") or {}
    headers = {k.lower(): v for k, v in (event.get("headers") or {}).items()}

    body = {}
    if event.get("body"):
        try:
            body = json.loads(event["body"])
        except (json.JSONDecodeError, ValueError):
            return resp(400, {"error": "Invalid JSON body"})

    # Health check — no auth, no body parsing needed.
    if method == "GET" and path.rstrip("/") == "/v1/health":
        return resp(200, {"status": "ok", "region": os.environ.get("AWS_REGION", "us-east-1")})

    # Route auth requests to the auth module.
    if path.startswith("/v1/auth") and route_auth:
        logger.info("%s %s (auth)", method, path)
        try:
            return route_auth(method, path, query, body, headers)
        except Exception:
            logger.exception("Unhandled error in auth")
            return resp(500, {"error": "Internal server error"})

    # Public endpoints — no auth required.
    if re.fullmatch(r"/v1/(verify|unsubscribe)/?", path):
        logger.info("%s %s (public)", method, path)
        try:
            return route(method, path, query, body, "default")
        except Exception:
            logger.exception("Unhandled error")
            return resp(500, {"error": "Internal server error"})

    # All other routes require JWT authentication.
    if not extract_bearer_token or not verify_jwt:
        return resp(500, {"error": "Auth module not available"})
    token = extract_bearer_token(headers)
    if not token:
        return resp(401, {"error": "Authentication required. Run 'dm login' to authenticate."})
    claims = verify_jwt(token)
    if not claims:
        return resp(401, {"error": "Invalid or expired token. Run 'dm login' to re-authenticate."})
    tenant_id = claims.get("tenant_id", "default")

    logger.info("%s %s tenant=%s", method, path, tenant_id)

    try:
        return route(method, path, query, body, tenant_id)
    except Exception:
        logger.exception("Unhandled error")
        return resp(500, {"error": "Internal server error"})


def route(method, path, query, body, tenant_id):
    # Public verify endpoint (no API key required)
    if re.fullmatch(r"/v1/verify/?", path):
        if method == "GET":
            return verify_destination(query)
        return resp(405, {"error": "Method not allowed"})

    # Public unsubscribe endpoint (no API key required)
    if re.fullmatch(r"/v1/unsubscribe/?", path):
        if method == "GET":
            return unsubscribe_destination(query)
        return resp(405, {"error": "Method not allowed"})

    # Rules collection
    if re.fullmatch(r"/v1/rules/?", path):
        if method == "GET":
            return list_rules(query, tenant_id)
        if method == "POST":
            return create_rule(body, tenant_id)
        return resp(405, {"error": "Method not allowed"})

    # Rule activity log
    m = re.fullmatch(r"/v1/rules/([^/]+)/([^/]+)/log/?", path)
    if m:
        domain = urllib.parse.unquote(m.group(1))
        localpart = urllib.parse.unquote(m.group(2))
        if method == "GET":
            return get_rule_log(domain, localpart, tenant_id)
        return resp(405, {"error": "Method not allowed"})

    # Rule item
    m = re.fullmatch(r"/v1/rules/([^/]+)/([^/]+)/?", path)
    if m:
        domain = urllib.parse.unquote(m.group(1))
        localpart = urllib.parse.unquote(m.group(2))
        if method == "GET":
            return get_rule(domain, localpart, tenant_id)
        if method == "PUT":
            return update_rule(domain, localpart, body, tenant_id)
        if method == "DELETE":
            return delete_rule(domain, localpart, tenant_id, query)
        return resp(405, {"error": "Method not allowed"})

    # Domains collection
    if re.fullmatch(r"/v1/domains/?", path):
        if method == "GET":
            return list_domains(tenant_id)
        if method == "POST":
            return register_domain(body, tenant_id)
        return resp(405, {"error": "Method not allowed"})

    # Domain DNS check
    m = re.fullmatch(r"/v1/domains/([^/]+)/check/?", path)
    if m:
        domain = urllib.parse.unquote(m.group(1))
        if method == "GET":
            return check_domain_dns(domain, tenant_id)
        return resp(405, {"error": "Method not allowed"})

    # Domain item
    m = re.fullmatch(r"/v1/domains/([^/]+)/?", path)
    if m:
        domain = urllib.parse.unquote(m.group(1))
        if method == "GET":
            return get_domain(domain, tenant_id)
        if method == "DELETE":
            return delete_domain(domain, tenant_id, query)
        return resp(405, {"error": "Method not allowed"})

    # Verification item check
    m = re.fullmatch(r"/v1/verifications/([^/]+)/?", path)
    if m:
        destination = urllib.parse.unquote(m.group(1))
        if method == "GET":
            return get_verification_status(destination, tenant_id)
        return resp(405, {"error": "Method not allowed"})

    # Verifications collection
    if re.fullmatch(r"/v1/verifications/?", path):
        if method == "GET":
            return list_verifications(tenant_id)
        if method == "POST":
            return resend_verification(body, tenant_id)
        return resp(405, {"error": "Method not allowed"})

    # Tenant usage
    m = re.fullmatch(r"/v1/tenants/([^/]+)/usage/?", path)
    if m:
        tid = urllib.parse.unquote(m.group(1))
        if method == "GET":
            return get_tenant_usage(tid)
        return resp(405, {"error": "Method not allowed"})

    # Tenants
    if re.fullmatch(r"/v1/tenants/?", path):
        if method == "GET":
            return list_tenants()
        if method == "POST":
            return create_tenant(body)
        return resp(405, {"error": "Method not allowed"})

    return resp(404, {"error": f"Not found: {path}"})


# ---------------------------------------------------------------------------
# Rate limiting
# ---------------------------------------------------------------------------

def check_rate_limit(tenant_id, action, max_count, window_hours=1):
    """
    Check and increment a per-tenant rate limit counter.

    Uses the tenants table with fields rate_<action>_count and
    rate_<action>_hour. Resets the count when the hour window changes.

    Returns (allowed: bool, message: str or None).
    """
    if not tenant_id or tenant_id == "default":
        return True, None

    table = dynamodb.Table(TENANTS_TABLE)
    now = datetime.now(timezone.utc)
    current_hour = now.strftime("%Y-%m-%dT%H")

    count_key = f"rate_{action}_count"
    hour_key = f"rate_{action}_hour"

    result = table.get_item(Key={"tenant_id": tenant_id})
    tenant = result.get("Item")
    if not tenant:
        return True, None

    stored_hour = tenant.get(hour_key, "")
    current_count = int(tenant.get(count_key, 0)) if stored_hour == current_hour else 0

    if current_count >= max_count:
        return False, f"Rate limit exceeded: max {max_count} {action}(s) per hour. Try again in the next hour."

    # Increment
    if stored_hour != current_hour:
        table.update_item(
            Key={"tenant_id": tenant_id},
            UpdateExpression=f"SET #count = :one, #hour = :hour",
            ExpressionAttributeNames={"#count": count_key, "#hour": hour_key},
            ExpressionAttributeValues={":one": 1, ":hour": current_hour},
        )
    else:
        table.update_item(
            Key={"tenant_id": tenant_id},
            UpdateExpression=f"SET #count = #count + :one",
            ExpressionAttributeNames={"#count": count_key},
            ExpressionAttributeValues={":one": 1},
        )

    return True, None


# ---------------------------------------------------------------------------
# Activity events
# ---------------------------------------------------------------------------

def log_event(domain, localpart, action, details=None):
    """Log an activity event for a rule."""
    if not EVENTS_TABLE:
        return
    table = dynamodb.Table(EVENTS_TABLE)
    now = datetime.now(timezone.utc).isoformat()
    item = {
        "rule_key": f"{domain}#{localpart}",
        "timestamp": now,
        "action": action,
    }
    if details:
        item["details"] = details
    table.put_item(Item=item)


def get_rule_log(domain, localpart, tenant_id):
    """GET /v1/rules/{domain}/{localpart}/log — return activity log for a rule."""
    # Verify ownership
    rules_table = dynamodb.Table(RULES_TABLE)
    rule = rules_table.get_item(Key={"domain": domain, "localpart": localpart}).get("Item")
    if not rule or rule.get("tenant_id") != tenant_id:
        return resp(404, {"error": "Rule not found"})

    if not EVENTS_TABLE:
        return resp(200, {"events": []})

    table = dynamodb.Table(EVENTS_TABLE)
    result = table.query(
        KeyConditionExpression=Key("rule_key").eq(f"{domain}#{localpart}"),
        ScanIndexForward=False,  # newest first
        Limit=50,
    )
    return resp(200, {"events": result.get("Items", [])})


# ---------------------------------------------------------------------------
# Destination verification
# ---------------------------------------------------------------------------

def get_verification(destination):
    """Look up verification record for a destination email."""
    table = dynamodb.Table(VERIFICATIONS_TABLE)
    result = table.get_item(Key={"destination": destination})
    return result.get("Item")


def send_verification_email(destination, token, rule_address=None):
    """Send a verification email to the destination with a clickable link.

    If *rule_address* is provided (e.g. "hello@example.com") the email will
    tell the recipient which forwarding rule triggered the verification.
    """
    verify_url = f"{API_BASE_URL}/verify?token={token}"

    if rule_address:
        rule_html = (
            f'<p>The rule <strong>{rule_address}</strong> is configured to '
            f'forward email to this address.</p>'
        )
        rule_text = (
            f"The rule {rule_address} is configured to forward email to this address.\n\n"
        )
    else:
        rule_html = ""
        rule_text = ""

    html_body = f"""\
<!DOCTYPE html>
<html>
<head><meta charset="utf-8"></head>
<body style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; color: #333;">
  <h2 style="color: #2c3e50;">Verify your email for Delivery Machine</h2>
  <p>Someone has set up email forwarding to this address using
     <a href="https://deliverymachine.net">Delivery Machine</a>.</p>
  {rule_html}
  <p>To confirm that you own this email address and activate forwarding, please click the button below:</p>
  <p style="text-align: center; margin: 30px 0;">
    <a href="{verify_url}"
       style="background-color: #3498db; color: #fff; padding: 14px 28px; text-decoration: none;
              border-radius: 6px; font-size: 16px; display: inline-block;">
      Verify my email
    </a>
  </p>
  <p style="font-size: 13px; color: #888;">Or copy and paste this link into your browser:<br>
     <a href="{verify_url}" style="color: #3498db;">{verify_url}</a></p>
  <hr style="border: none; border-top: 1px solid #eee; margin: 30px 0;">
  <p style="font-size: 12px; color: #999;">If you did not request this, you can safely ignore this email.
     No forwarding will be activated without your confirmation.</p>
</body>
</html>"""

    text_body = f"""\
Verify your email for Delivery Machine

Someone has set up email forwarding to this address using Delivery Machine.

{rule_text}To confirm that you own this email address and activate forwarding, visit:
{verify_url}

If you did not request this, you can safely ignore this email.
No forwarding will be activated without your confirmation."""

    ses.send_email(
        Source=f"Delivery Machine <{FORWARD_FROM}>",
        Destination={"ToAddresses": [destination]},
        Message={
            "Subject": {"Data": "Verify your email for Delivery Machine", "Charset": "UTF-8"},
            "Body": {
                "Text": {"Data": text_body, "Charset": "UTF-8"},
                "Html": {"Data": html_body, "Charset": "UTF-8"},
            },
        },
    )
    logger.info("Sent verification email to %s", destination)


def ensure_verification(destination, tenant_id, rule_address=None):
    """
    Check if destination is verified. If not, send/resend verification email.

    *rule_address* (e.g. "hello@example.com") is passed through to the email
    so the recipient knows which rule triggered the verification.

    Returns (verified: bool, message: str).
    """
    record = get_verification(destination)

    if record and record.get("verified"):
        return True, "Destination already verified"

    now = datetime.now(timezone.utc)

    # Check verification email cooldown
    if record and record.get("last_sent_at"):
        last_sent = datetime.fromisoformat(record["last_sent_at"])
        elapsed = (now - last_sent).total_seconds()
        if elapsed < VERIFICATION_COOLDOWN:
            remaining = int(VERIFICATION_COOLDOWN - elapsed)
            return False, f"Verification email already sent. You can resend in {remaining} seconds."

    # Generate token and store/update verification record
    token = secrets.token_urlsafe(32)
    now_iso = now.isoformat()

    table = dynamodb.Table(VERIFICATIONS_TABLE)
    item = {
        "destination": destination,
        "token": token,
        "tenant_id": tenant_id,
        "verified": False,
        "last_sent_at": now_iso,
        "created_at": record.get("created_at", now_iso) if record else now_iso,
        "updated_at": now_iso,
    }
    table.put_item(Item=item)

    send_verification_email(destination, token, rule_address=rule_address)
    return False, "Verification email sent. Please check your inbox and click the link to verify."


def ensure_rule_verification(dest, domain, localpart, tenant_id):
    """
    Check if a destination within a rule is verified. If not, send verification email.

    *dest* is the destination dict from the rule's destinations list (mutated in place).

    Returns (verified: bool, message: str).
    """
    if dest.get("verified"):
        return True, "Destination already verified for this rule"

    now = datetime.now(timezone.utc)
    rule_address = f"{localpart}@{domain}"

    # Check verification email cooldown
    if dest.get("last_sent_at"):
        last_sent = datetime.fromisoformat(dest["last_sent_at"])
        elapsed = (now - last_sent).total_seconds()
        if elapsed < VERIFICATION_COOLDOWN:
            remaining = int(VERIFICATION_COOLDOWN - elapsed)
            return False, f"Verification email already sent. You can resend in {remaining} seconds."

    # Generate a new token and update the destination entry
    token = secrets.token_urlsafe(32)
    now_iso = now.isoformat()
    dest["verification_token"] = token
    dest["last_sent_at"] = now_iso

    send_verification_email(dest["address"], token, rule_address=rule_address)
    return False, "Verification email sent. Please check your inbox and click the link to verify."


def verify_destination(query):
    """Handle GET /v1/verify?token=<token> — public endpoint, returns HTML.

    Checks both inline rule verification tokens (new) and the legacy
    VERIFICATIONS_TABLE so that old outstanding emails still work.
    """
    token = query.get("token", "").strip()
    if not token:
        return html_resp(400, "Missing token",
                         "No verification token was provided. Please use the link from your email.")

    now = datetime.now(timezone.utc).isoformat()

    # ── Check inline rule verification tokens (new model) ──
    rules_table = dynamodb.Table(RULES_TABLE)
    result = rules_table.scan()
    for item in result.get("Items", []):
        destinations = item.get("destinations", [])
        for i, dest in enumerate(destinations):
            if dest.get("verification_token") == token:
                if dest.get("verified"):
                    rule_addr = f"{item['localpart']}@{item['domain']}"
                    return html_resp(200, "Already verified",
                                     f"Your email address has already been verified for "
                                     f"<strong>{rule_addr}</strong>. You're all set!")

                # Mark this specific destination as verified
                destinations[i]["verified"] = True
                destinations[i]["verified_at"] = now
                rules_table.update_item(
                    Key={"domain": item["domain"], "localpart": item["localpart"]},
                    UpdateExpression="SET destinations = :d, updated_at = :now",
                    ExpressionAttributeValues={":d": destinations, ":now": now},
                )

                rule_addr = f"{item['localpart']}@{item['domain']}"
                logger.info("Verified destination %s for rule %s", dest["address"], rule_addr)
                return html_resp(200, "Verified!",
                                 f"Your email address has been verified for "
                                 f"<strong>{rule_addr}</strong>. "
                                 f"Email forwarding to this address is now active.")

    # ── Fallback: check legacy VERIFICATIONS_TABLE ──
    if VERIFICATIONS_TABLE:
        table = dynamodb.Table(VERIFICATIONS_TABLE)
        result = table.scan(
            FilterExpression="#t = :token",
            ExpressionAttributeNames={"#t": "token"},
            ExpressionAttributeValues={":token": token},
        )
        items = result.get("Items", [])

        if items:
            record = items[0]
            if record.get("verified"):
                return html_resp(200, "Already verified",
                                 "This email address has already been verified. You're all set!")

            table.update_item(
                Key={"destination": record["destination"]},
                UpdateExpression="SET verified = :v, verified_at = :now, updated_at = :now",
                ExpressionAttributeValues={":v": True, ":now": now},
            )
            logger.info("Verified destination (legacy): %s", record["destination"])
            return html_resp(200, "Verified!",
                             "Your email address has been verified successfully. "
                             "Email forwarding to this address is now active.")

    return html_resp(404, "Invalid token",
                     "This verification link is invalid or has expired. "
                     "Please request a new verification email.")


def unsubscribe_destination(query):
    """Handle GET /v1/unsubscribe?token=<token> — public endpoint, returns HTML."""
    token = query.get("token", "").strip()
    if not token:
        return html_resp(400, "Missing token",
                         "No unsubscribe token was provided. Please use the link from your email.")

    # Scan rules for the unsubscribe token
    table = dynamodb.Table(RULES_TABLE)
    result = table.scan()
    items = result.get("Items", [])

    for item in items:
        destinations = item.get("destinations", [])
        for i, dest in enumerate(destinations):
            if dest.get("unsubscribe_token") == token:
                address = dest["address"]
                domain = item["domain"]
                localpart = item["localpart"]
                source = f"{localpart}@{domain}" if localpart != "*" else f"*@{domain}"

                if len(destinations) == 1:
                    # Last destination — disable the rule
                    table.update_item(
                        Key={"domain": domain, "localpart": localpart},
                        UpdateExpression="SET destinations = :empty, enabled = :false, updated_at = :now",
                        ExpressionAttributeValues={
                            ":empty": [],
                            ":false": False,
                            ":now": datetime.now(timezone.utc).isoformat(),
                        },
                    )
                else:
                    # Remove just this destination
                    new_destinations = [d for d in destinations if d.get("unsubscribe_token") != token]
                    table.update_item(
                        Key={"domain": domain, "localpart": localpart},
                        UpdateExpression="SET destinations = :dests, updated_at = :now",
                        ExpressionAttributeValues={
                            ":dests": new_destinations,
                            ":now": datetime.now(timezone.utc).isoformat(),
                        },
                    )

                logger.info("Unsubscribed %s from %s", address, source)
                log_event(domain, localpart, "destination_unsubscribed", {
                    "address": address, "actor": "recipient",
                })
                return html_resp(200, "Unsubscribed",
                                 f"<strong>{address}</strong> has been removed from forwards for "
                                 f"<strong>{source}</strong>. You will no longer receive these emails.")

    return html_resp(404, "Invalid link",
                     "This unsubscribe link is invalid or has already been used.")


def list_verifications(tenant_id):
    """List per-rule-destination verification status for this tenant."""
    rules_table = dynamodb.Table(RULES_TABLE)
    result = rules_table.query(
        IndexName="tenant-index",
        KeyConditionExpression=Key("tenant_id").eq(tenant_id),
    )

    verifications = []
    for item in result["Items"]:
        domain = item["domain"]
        localpart = item["localpart"]
        for d in item.get("destinations", []):
            verifications.append({
                "destination": d["address"],
                "domain": domain,
                "localpart": localpart,
                "role": d.get("role", "to"),
                "verified": bool(d.get("verified", False)),
                "verified_at": d.get("verified_at"),
                "last_sent_at": d.get("last_sent_at"),
            })
        # Legacy format
        if "destination" in item and "destinations" not in item:
            verifications.append({
                "destination": item["destination"],
                "domain": domain,
                "localpart": localpart,
                "role": "to",
                "verified": False,
                "verified_at": None,
                "last_sent_at": None,
            })

    return resp(200, {"verifications": verifications})


def resend_verification(body, tenant_id):
    """POST /v1/verifications — resend verification email for a destination.

    Accepts:
      - {"destination": "...", "domain": "...", "localpart": "..."} — resend for a specific rule-destination
      - {"destination": "..."} — resend for all unverified rule-destinations matching that address
    """
    destination = body.get("destination", "").strip()
    if not destination or "@" not in destination:
        return resp(400, {"error": "destination must be a valid email address"})

    # Check rate limit for verification sending
    allowed, message = check_rate_limit(tenant_id, "verification", RATE_LIMIT_RULES)
    if not allowed:
        return resp(429, {"error": message})

    target_domain = body.get("domain", "").strip()
    target_localpart = body.get("localpart", "").strip()

    # Find matching rules and resend for unverified destinations
    rules_table = dynamodb.Table(RULES_TABLE)
    result = rules_table.query(
        IndexName="tenant-index",
        KeyConditionExpression=Key("tenant_id").eq(tenant_id),
    )

    any_sent = False
    all_verified = True
    messages = []
    for item in result["Items"]:
        domain = item["domain"]
        localpart = item["localpart"]
        if target_domain and domain != target_domain:
            continue
        if target_localpart and localpart != target_localpart:
            continue

        destinations = item.get("destinations", [])
        changed = False
        for dest in destinations:
            if dest["address"] != destination:
                continue
            verified, msg = ensure_rule_verification(dest, domain, localpart, tenant_id)
            if not verified:
                all_verified = False
                any_sent = True
                changed = True
            messages.append(f"{localpart}@{domain}: {msg}")

        if changed:
            rules_table.update_item(
                Key={"domain": domain, "localpart": localpart},
                UpdateExpression="SET destinations = :d, updated_at = :now",
                ExpressionAttributeValues={
                    ":d": destinations,
                    ":now": datetime.now(timezone.utc).isoformat(),
                },
            )

    if not messages:
        return resp(404, {"error": f"No rules found with destination {destination}"})

    if all_verified:
        return resp(200, {"message": "All matching destinations already verified", "verified": True})

    return resp(202, {"message": "; ".join(messages), "verified": False})


def get_verification_status(destination, tenant_id):
    """GET /v1/verifications/{destination} — check per-rule verification status."""
    rules_table = dynamodb.Table(RULES_TABLE)
    result = rules_table.query(
        IndexName="tenant-index",
        KeyConditionExpression=Key("tenant_id").eq(tenant_id),
    )

    referencing_rules = []
    for item in result["Items"]:
        for d in item.get("destinations", []):
            if d["address"] == destination:
                referencing_rules.append({
                    "domain": item["domain"],
                    "localpart": item["localpart"],
                    "role": d.get("role", "to"),
                    "enabled": item.get("enabled", True),
                    "verified": bool(d.get("verified", False)),
                    "verified_at": d.get("verified_at"),
                    "last_sent_at": d.get("last_sent_at"),
                })
        # Legacy format
        if item.get("destination") == destination and "destinations" not in item:
            referencing_rules.append({
                "domain": item["domain"],
                "localpart": item["localpart"],
                "role": "to",
                "enabled": item.get("enabled", True),
                "verified": False,
                "verified_at": None,
                "last_sent_at": None,
            })

    status_info = {
        "destination": destination,
        "rules": referencing_rules,
    }

    return resp(200, {"verification": status_info})


# ---------------------------------------------------------------------------
# Rules
# ---------------------------------------------------------------------------

def list_rules(query, tenant_id):
    table = dynamodb.Table(RULES_TABLE)
    domain = query.get("domain")

    if domain:
        result = table.query(KeyConditionExpression=Key("domain").eq(domain))
        items = [i for i in result["Items"] if i.get("tenant_id") == tenant_id]
    else:
        result = table.query(
            IndexName="tenant-index",
            KeyConditionExpression=Key("tenant_id").eq(tenant_id),
        )
        items = result["Items"]

    return resp(200, {"rules": items})


def _parse_destinations(body):
    """
    Parse destinations from request body.

    Accepts either:
      - "destination": "user@example.com"  (legacy single destination, role=to)
      - "destinations": [{"address": "a@b.com", "role": "to"}, ...]

    Returns (destinations_list, error_message).
    Each entry: {"address": str, "role": "to"|"cc"|"bcc", "unsubscribe_token": str}
    """
    valid_roles = {"to", "cc", "bcc"}

    if "destinations" in body:
        raw = body["destinations"]
        if not isinstance(raw, list) or not raw:
            return None, "destinations must be a non-empty list"
        destinations = []
        for entry in raw:
            if isinstance(entry, str):
                entry = {"address": entry}
            addr = entry.get("address", "").strip()
            role = entry.get("role", "to").strip().lower()
            if not addr or "@" not in addr:
                return None, f"invalid destination address: {addr!r}"
            if role not in valid_roles:
                return None, f"invalid role: {role!r}; must be one of {sorted(valid_roles)}"
            destinations.append({
                "address": addr,
                "role": role,
                "unsubscribe_token": secrets.token_urlsafe(32),
                "verification_token": secrets.token_urlsafe(32),
                "verified": False,
                "verified_at": None,
                "last_sent_at": None,
            })
        return destinations, None

    # Legacy single destination
    destination = body.get("destination", "").strip()
    if not destination or "@" not in destination:
        return None, "destination must be a valid email address"
    return [{
        "address": destination,
        "role": "to",
        "unsubscribe_token": secrets.token_urlsafe(32),
        "verification_token": secrets.token_urlsafe(32),
        "verified": False,
        "verified_at": None,
        "last_sent_at": None,
    }], None


def create_rule(body, tenant_id):
    domain = body.get("domain", "").strip().lower()
    localpart = body.get("localpart", "*").strip().lower()

    if not domain:
        return resp(400, {"error": "domain is required"})

    if not _require_tenant(tenant_id):
        return resp(400, {"error": "Tenant does not exist. Create a tenant first with POST /v1/tenants or sign up via POST /v1/auth/signup."})

    # Check domain is registered and verified (ownership proven via TXT record)
    domain_table = dynamodb.Table(DOMAINS_TABLE)
    domain_record = domain_table.get_item(Key={"domain": domain}).get("Item")
    if not domain_record or domain_record.get("tenant_id") != tenant_id:
        return resp(404, {"error": f"Domain '{domain}' is not registered. Use POST /v1/domains first."})
    if not domain_record.get("verified"):
        # Check DNS in case the TXT record was just added
        verified, status = sync_domain_verification(domain)
        if not verified:
            token = domain_record.get("verification_token", "")
            return resp(409, {
                "error": f"Domain '{domain}' is not yet verified. "
                         f"Add a TXT record: _dm-verify.{domain} = dm-verify={token}",
            })

    destinations, error = _parse_destinations(body)
    if error:
        return resp(400, {"error": error})

    # Rate limit: max new rules per hour
    allowed, message = check_rate_limit(tenant_id, "rule", RATE_LIMIT_RULES)
    if not allowed:
        return resp(429, {"error": message})

    # Send verification emails for each destination (per-rule)
    all_verified = True
    ver_messages = []
    for dest in destinations:
        verified, ver_message = ensure_rule_verification(dest, domain, localpart, tenant_id)
        if not verified:
            all_verified = False
            ver_messages.append(f"{dest['address']}: {ver_message}")

    table = dynamodb.Table(RULES_TABLE)
    now = datetime.now(timezone.utc).isoformat()

    item = {
        "domain": domain,
        "localpart": localpart,
        "destinations": destinations,
        "tenant_id": tenant_id,
        "enabled": body.get("enabled", True),
        "all_verified": all_verified,
        "description": body.get("description", ""),
        "created_at": now,
        "updated_at": now,
    }

    if "expires_in_days" in body:
        from datetime import timedelta
        expires = datetime.now(timezone.utc) + timedelta(days=int(body["expires_in_days"]))
        item["expires_at"] = int(expires.timestamp())

    if "expires_at" in body:
        item["expires_at"] = int(body["expires_at"])

    table.put_item(Item=item)
    addrs = ", ".join(d["address"] for d in destinations)
    logger.info("Created rule: %s@%s -> [%s] (all_verified=%s)", localpart, domain, addrs, all_verified)

    log_event(domain, localpart, "rule_created", {
        "destinations": [{"address": d["address"], "role": d["role"]} for d in destinations],
        "tenant_id": tenant_id,
    })

    if all_verified:
        return resp(201, {"rule": item})
    else:
        return resp(202, {"rule": item, "message": "; ".join(ver_messages)})


def get_rule(domain, localpart, tenant_id):
    table = dynamodb.Table(RULES_TABLE)
    result = table.get_item(Key={"domain": domain, "localpart": localpart})
    item = result.get("Item")
    if not item or item.get("tenant_id") != tenant_id:
        return resp(404, {"error": "Rule not found"})
    return resp(200, {"rule": item})


def update_rule(domain, localpart, body, tenant_id):
    table = dynamodb.Table(RULES_TABLE)

    # Verify ownership
    existing = table.get_item(Key={"domain": domain, "localpart": localpart}).get("Item")
    if not existing or existing.get("tenant_id") != tenant_id:
        return resp(404, {"error": "Rule not found"})

    updates = {}
    for k in ("enabled", "description", "expires_at"):
        if k in body:
            updates[k] = body[k]

    # Handle destinations update
    if "destinations" in body or "destination" in body:
        destinations, error = _parse_destinations(body)
        if error:
            return resp(400, {"error": error})
        # Preserve existing tokens and verification state for unchanged addresses
        existing_by_addr = {}
        for d in existing.get("destinations", []):
            existing_by_addr[d["address"]] = d
        for d in destinations:
            old = existing_by_addr.get(d["address"])
            if old:
                d["unsubscribe_token"] = old.get("unsubscribe_token", d["unsubscribe_token"])
                d["verification_token"] = old.get("verification_token", d["verification_token"])
                d["verified"] = old.get("verified", False)
                d["verified_at"] = old.get("verified_at")
                d["last_sent_at"] = old.get("last_sent_at")
            else:
                # New destination — send verification email
                ensure_rule_verification(d, domain, localpart, tenant_id)
        updates["destinations"] = destinations

        # Log added/removed destinations
        old_addrs = {d["address"] for d in existing.get("destinations", [])}
        new_addrs = {d["address"] for d in destinations}
        added = new_addrs - old_addrs
        removed = old_addrs - new_addrs
        if added:
            log_event(domain, localpart, "destination_added", {
                "addresses": sorted(added), "actor": tenant_id,
            })
        if removed:
            log_event(domain, localpart, "destination_removed", {
                "addresses": sorted(removed), "actor": tenant_id,
            })

    if not updates:
        return resp(400, {"error": "No updatable fields provided"})

    updates["updated_at"] = datetime.now(timezone.utc).isoformat()

    expr = "SET " + ", ".join(f"#{k} = :{k}" for k in updates)
    names = {f"#{k}": k for k in updates}
    values = {f":{k}": v for k, v in updates.items()}

    table.update_item(
        Key={"domain": domain, "localpart": localpart},
        UpdateExpression=expr,
        ExpressionAttributeNames=names,
        ExpressionAttributeValues=values,
    )
    return resp(200, {"updated": True})


def delete_rule(domain, localpart, tenant_id, query=None):
    query = query or {}
    table = dynamodb.Table(RULES_TABLE)
    existing = table.get_item(Key={"domain": domain, "localpart": localpart}).get("Item")
    if not existing or existing.get("tenant_id") != tenant_id:
        return resp(404, {"error": "Rule not found"})

    old_dests = existing.get("destinations", [])
    old_addrs = [d["address"] for d in old_dests]
    address = f"{localpart}@{domain}"

    # Notify destinations unless ?quiet=true
    if query.get("quiet", "").lower() != "true":
        _notify_rule_deleted(address, old_dests)

    table.delete_item(Key={"domain": domain, "localpart": localpart})
    logger.info("Deleted rule: %s@%s", localpart, domain)
    log_event(domain, localpart, "rule_deleted", {
        "destinations": old_addrs, "actor": tenant_id,
    })

    # Clean up orphaned verification records — delete any destination verification
    # that is no longer referenced by any other rule for this tenant.
    _cleanup_orphaned_verifications(old_addrs, tenant_id)

    return resp(204, {})


def _notify_rule_deleted(address, destinations):
    """Send a notification email to all destinations that a forwarding rule has been deleted."""
    for dest in destinations:
        dest_addr = dest.get("address", "")
        if not dest_addr:
            continue
        try:
            html_body = f"""\
<!DOCTYPE html>
<html>
<head><meta charset="utf-8"></head>
<body style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; color: #333;">
  <h2 style="color: #2c3e50;">Email forwarding rule deleted</h2>
  <p>The forwarding rule for <strong>{address}</strong> that was delivering
     email to <strong>{dest_addr}</strong> has been deleted.</p>
  <p>You will no longer receive forwarded email at this address from {address}.</p>
  <hr style="border: none; border-top: 1px solid #eee; margin: 30px 0;">
  <p style="font-size: 12px; color: #999;">This is an automated notification from
     <a href="https://deliverymachine.net" style="color: #3498db;">Delivery Machine</a>.</p>
</body>
</html>"""

            text_body = (
                f"Email forwarding rule deleted\n\n"
                f"The forwarding rule for {address} that was delivering "
                f"email to {dest_addr} has been deleted.\n\n"
                f"You will no longer receive forwarded email at this address from {address}."
            )

            ses.send_email(
                Source=f"Delivery Machine <{FORWARD_FROM}>",
                Destination={"ToAddresses": [dest_addr]},
                Message={
                    "Subject": {
                        "Data": f"Forwarding rule deleted: {address}",
                        "Charset": "UTF-8",
                    },
                    "Body": {
                        "Text": {"Data": text_body, "Charset": "UTF-8"},
                        "Html": {"Data": html_body, "Charset": "UTF-8"},
                    },
                },
            )
            logger.info("Sent rule-deleted notification to %s for %s", dest_addr, address)
        except Exception:
            logger.exception("Failed to send rule-deleted notification to %s", dest_addr)


def _cleanup_orphaned_verifications(destinations, tenant_id):
    """Delete legacy verification records for destinations no longer used by any rule.

    With per-rule-destination verification, verification data lives inline in the
    rule's destinations list and is automatically cleaned up when the rule is deleted.
    This function only cleans up the legacy VERIFICATIONS_TABLE.
    """
    if not destinations or not VERIFICATIONS_TABLE:
        return
    rules_table = dynamodb.Table(RULES_TABLE)
    ver_table = dynamodb.Table(VERIFICATIONS_TABLE)

    # Get all rules for this tenant
    result = rules_table.scan(
        FilterExpression="tenant_id = :t",
        ExpressionAttributeValues={":t": tenant_id},
        ProjectionExpression="destinations",
    )
    # Collect all destination addresses still in use
    in_use = set()
    for rule in result.get("Items", []):
        for d in rule.get("destinations", []):
            in_use.add(d.get("address", ""))

    # Delete verification records for destinations no longer referenced
    for dest in destinations:
        if dest not in in_use:
            ver_table.delete_item(Key={"destination": dest})
            logger.info("Cleaned up orphaned verification for %s", dest)


# ---------------------------------------------------------------------------
# Domains
# ---------------------------------------------------------------------------

def list_domains(tenant_id):
    table = dynamodb.Table(DOMAINS_TABLE)
    result = table.scan(
        FilterExpression="tenant_id = :t",
        ExpressionAttributeValues={":t": tenant_id},
    )
    return resp(200, {"domains": result["Items"]})


def register_domain(body, tenant_id):
    domain = body.get("domain", "").strip().lower()
    if not domain:
        return resp(400, {"error": "domain is required"})

    if not _require_tenant(tenant_id):
        return resp(400, {"error": "Tenant does not exist. Create a tenant first with POST /v1/tenants or sign up via POST /v1/auth/signup."})

    # Rate limit: max new domains per hour
    allowed, message = check_rate_limit(tenant_id, "domain", RATE_LIMIT_DOMAINS)
    if not allowed:
        return resp(429, {"error": message})

    # Check if already registered
    table = dynamodb.Table(DOMAINS_TABLE)
    existing = table.get_item(Key={"domain": domain}).get("Item")
    if existing:
        if existing.get("tenant_id") != tenant_id:
            return resp(409, {"error": f"Domain '{domain}' is already registered by another tenant."})
        # Re-registering own domain — return existing record
        return resp(200, _domain_response(existing))

    # Generate our own verification token
    token = secrets.token_urlsafe(32)

    # Register domain with SES so it can receive inbound email
    ses_token = None
    try:
        ses_resp = ses.verify_domain_identity(Domain=domain)
        ses_token = ses_resp.get("VerificationToken")
        logger.info("SES verify_domain_identity for %s, token=%s", domain, ses_token)
    except Exception:
        logger.exception("Failed to call SES verify_domain_identity for %s", domain)

    now = datetime.now(timezone.utc).isoformat()
    item = {
        "domain": domain,
        "tenant_id": tenant_id,
        "verification_token": token,
        "ses_verification_token": ses_token,
        "verified": False,
        "created_at": now,
    }
    table.put_item(Item=item)
    logger.info("Registered domain: %s for tenant %s", domain, tenant_id)

    return resp(202, _domain_response(item))


def _domain_response(item):
    """Build a standard domain response with DNS instructions."""
    domain = item["domain"]
    token = item.get("verification_token", "")
    ses_token = item.get("ses_verification_token")
    mx_host = MX_HOST or SES_MX.get(SES_REGION, SES_MX["us-east-1"])

    dns_records = [
        {
            "type": "TXT",
            "name": f"_dm-verify.{domain}",
            "value": f"dm-verify={token}",
            "purpose": "Prove domain ownership to Delivery Machine",
        },
        {
            "type": "MX",
            "name": domain,
            "value": f"10 {mx_host}",
            "purpose": "Route inbound email to Delivery Machine",
        },
    ]

    if ses_token:
        dns_records.append({
            "type": "TXT",
            "name": f"_amazonses.{domain}",
            "value": ses_token,
            "purpose": "Verify domain with Amazon SES for email receiving",
        })

    return {
        "domain": item,
        "dns_records": dns_records,
        "message": "Add all DNS records below. The TXT records prove ownership; "
                   "the MX record routes email. "
                   "Rules cannot be created until the domain is verified.",
    }


def _dns_lookup(name, record_type):
    """
    Query DNS via Google DNS-over-HTTPS. Returns list of answer data strings.
    """
    url = f"https://dns.google/resolve?name={urllib.parse.quote(name)}&type={record_type}"
    try:
        req = urllib.request.Request(url, headers={"Accept": "application/dns-json"})
        with urllib.request.urlopen(req, timeout=5) as response:
            data = json.loads(response.read())
        return [a.get("data", "").strip('"') for a in data.get("Answer", [])]
    except Exception:
        logger.exception("DNS lookup failed for %s %s", record_type, name)
        return []


def check_domain_txt(domain, expected_token):
    """
    Check DNS for _dm-verify.{domain} TXT record matching dm-verify={token}.
    Returns True if the expected TXT value is found.
    """
    expected = f"dm-verify={expected_token}"
    for txt_value in _dns_lookup(f"_dm-verify.{domain}", "TXT"):
        if txt_value == expected:
            return True
    return False


def check_domain_dns(domain, tenant_id):
    """
    GET /v1/domains/{domain}/check — check all expected DNS records for a domain.
    Returns status of each record (found/missing) and syncs verification.
    """
    table = dynamodb.Table(DOMAINS_TABLE)
    record = table.get_item(Key={"domain": domain}).get("Item")
    if not record or record.get("tenant_id") != tenant_id:
        return resp(404, {"error": "Domain not found"})

    token = record.get("verification_token", "")
    mx_host = MX_HOST or SES_MX.get(SES_REGION, SES_MX["us-east-1"])

    checks = []

    # 1. Ownership TXT record
    expected_txt = f"dm-verify={token}"
    txt_records = _dns_lookup(f"_dm-verify.{domain}", "TXT")
    txt_found = expected_txt in txt_records
    checks.append({
        "record": "TXT",
        "name": f"_dm-verify.{domain}",
        "expected": expected_txt,
        "found": txt_records,
        "ok": txt_found,
        "purpose": "Domain ownership verification",
    })

    # 2. SES domain verification TXT record
    ses_token = record.get("ses_verification_token")
    if ses_token:
        ses_txt_records = _dns_lookup(f"_amazonses.{domain}", "TXT")
        ses_txt_found = ses_token in ses_txt_records
        checks.append({
            "record": "TXT",
            "name": f"_amazonses.{domain}",
            "expected": ses_token,
            "found": ses_txt_records,
            "ok": ses_txt_found,
            "purpose": "SES email receiving verification",
        })
    else:
        # Try to register with SES if we don't have a token yet
        try:
            ses_resp = ses.verify_domain_identity(Domain=domain)
            ses_token = ses_resp.get("VerificationToken")
            if ses_token:
                table.update_item(
                    Key={"domain": domain},
                    UpdateExpression="SET ses_verification_token = :t",
                    ExpressionAttributeValues={":t": ses_token},
                )
                ses_txt_records = _dns_lookup(f"_amazonses.{domain}", "TXT")
                ses_txt_found = ses_token in ses_txt_records
                checks.append({
                    "record": "TXT",
                    "name": f"_amazonses.{domain}",
                    "expected": ses_token,
                    "found": ses_txt_records,
                    "ok": ses_txt_found,
                    "purpose": "SES email receiving verification",
                })
        except Exception:
            logger.exception("Failed to call SES verify_domain_identity for %s", domain)

    # 3. MX record — accept either the friendly alias or the raw SES endpoint
    mx_records = _dns_lookup(domain, "MX")
    ses_host = SES_MX.get(SES_REGION, SES_MX["us-east-1"])
    mx_found = any(mx_host in mx or ses_host in mx for mx in mx_records)
    checks.append({
        "record": "MX",
        "name": domain,
        "expected": f"10 {mx_host}",
        "found": mx_records,
        "ok": mx_found,
        "purpose": "Inbound email routing",
    })

    # Sync verification status if TXT is found
    if txt_found and not record.get("verified"):
        table.update_item(
            Key={"domain": domain},
            UpdateExpression="SET verified = :v, verified_at = :now",
            ExpressionAttributeValues={
                ":v": True,
                ":now": datetime.now(timezone.utc).isoformat(),
            },
        )

    all_ok = all(c["ok"] for c in checks)
    verified = txt_found  # domain ownership is proven by the TXT record alone

    return resp(200, {
        "domain": domain,
        "verified": verified,
        "all_records_ok": all_ok,
        "checks": checks,
    })


def sync_domain_verification(domain):
    """
    Check DNS for domain ownership TXT record and update the domain record.

    Returns (verified: bool, status: str).
    """
    table = dynamodb.Table(DOMAINS_TABLE)
    record = table.get_item(Key={"domain": domain}).get("Item")
    if not record:
        return False, "not_registered"

    if record.get("verified"):
        return True, "verified"

    token = record.get("verification_token", "")
    if not token:
        return False, "no_token"

    found = check_domain_txt(domain, token)
    if found:
        table.update_item(
            Key={"domain": domain},
            UpdateExpression="SET verified = :v, verified_at = :now",
            ExpressionAttributeValues={
                ":v": True,
                ":now": datetime.now(timezone.utc).isoformat(),
            },
        )
        logger.info("Domain %s verified via TXT record", domain)
        return True, "verified"

    return False, "txt_not_found"


def get_domain(domain, tenant_id):
    table = dynamodb.Table(DOMAINS_TABLE)
    result = table.get_item(Key={"domain": domain})
    item = result.get("Item")
    if not item or item.get("tenant_id") != tenant_id:
        return resp(404, {"error": "Domain not found"})

    # Check DNS if not yet verified
    verified, status = sync_domain_verification(domain)
    item["verified"] = verified
    item["verification_status"] = status

    return resp(200, _domain_response(item))


def delete_domain(domain, tenant_id, query=None):
    query = query or {}
    table = dynamodb.Table(DOMAINS_TABLE)
    item = table.get_item(Key={"domain": domain}).get("Item")
    if not item or item.get("tenant_id") != tenant_id:
        return resp(404, {"error": "Domain not found"})

    # Cascade-delete all rules for this domain, which in turn cleans up
    # orphaned verifications and notifies destinations.
    rules_table = dynamodb.Table(RULES_TABLE)
    result = rules_table.scan(
        FilterExpression="#d = :d AND tenant_id = :t",
        ExpressionAttributeNames={"#d": "domain"},
        ExpressionAttributeValues={":d": domain, ":t": tenant_id},
    )
    quiet = query.get("quiet", "").lower() == "true"
    for rule in result.get("Items", []):
        localpart = rule["localpart"]
        old_dests = rule.get("destinations", [])
        old_addrs = [d["address"] for d in old_dests]
        address = f"{localpart}@{domain}"

        if not quiet:
            _notify_rule_deleted(address, old_dests)

        rules_table.delete_item(Key={"domain": domain, "localpart": localpart})
        logger.info("Cascade-deleted rule: %s@%s (domain delete)", localpart, domain)
        log_event(domain, localpart, "rule_deleted", {
            "destinations": old_addrs, "actor": tenant_id, "reason": "domain_deleted",
        })
        _cleanup_orphaned_verifications(old_addrs, tenant_id)

    # Remove the SES domain identity
    try:
        ses.delete_identity(Identity=domain)
        logger.info("Deleted SES identity for %s", domain)
    except Exception:
        logger.exception("Failed to delete SES identity for %s", domain)

    table.delete_item(Key={"domain": domain})
    logger.info("Deleted domain: %s (cascade-deleted %d rules)", domain, len(result.get("Items", [])))
    return resp(204, {})


# ---------------------------------------------------------------------------
# Tenants (scaffold for future multi-tenancy / billing)
# ---------------------------------------------------------------------------

def list_tenants():
    table = dynamodb.Table(TENANTS_TABLE)
    result = table.scan()
    return resp(200, {"tenants": result["Items"]})


def get_tenant_usage(tenant_id):
    table = dynamodb.Table(TENANTS_TABLE)
    result = table.get_item(Key={"tenant_id": tenant_id})
    tenant = result.get("Item")
    if not tenant:
        return resp(404, {"error": "Tenant not found"})

    current_month = datetime.now(timezone.utc).strftime("%Y-%m")
    stored_month = tenant.get("count_month", "")
    email_count = int(tenant.get("email_count", 0)) if stored_month == current_month else 0
    email_quota = tenant.get("email_quota")

    usage = {
        "tenant_id": tenant_id,
        "plan": tenant.get("plan", "free"),
        "month": current_month,
        "email_count": email_count,
        "email_quota": email_quota,
        "pct_used": round(email_count / int(email_quota) * 100, 1) if email_quota else None,
        "unlimited": email_quota is None,
    }
    return resp(200, {"usage": usage})


PLAN_QUOTAS = {
    "free":      500,
    "starter":   5_000,
    "pro":       50_000,
    "business":  500_000,
    "unlimited": None,   # None = no cap
}


def create_tenant(body):
    try:
        from ulid import ULID
        tenant_id = body.get("tenant_id") or str(ULID())
    except ImportError:
        import uuid
        tenant_id = body.get("tenant_id") or str(uuid.uuid4())

    plan = body.get("plan", "free")
    if plan not in PLAN_QUOTAS:
        return resp(400, {"error": f"unknown plan '{plan}'; valid: {list(PLAN_QUOTAS)}"})

    # Allow explicit quota override; otherwise derive from plan.
    email_quota = body.get("email_quota", PLAN_QUOTAS[plan])
    now = datetime.now(timezone.utc).isoformat()

    item = {
        "tenant_id": tenant_id,
        "plan": plan,
        "email_quota": email_quota,  # None = unlimited
        "email_count": 0,
        "credits": body.get("credits", 0),
        "created_at": now,
        "updated_at": now,
    }

    dynamodb.Table(TENANTS_TABLE).put_item(Item=item)
    logger.info("Created tenant: %s plan=%s quota=%s", tenant_id, plan, email_quota)
    return resp(201, {"tenant": item})


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def resp(status_code, body):
    headers = {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Expose-Headers": "X-Latest-Version, X-Min-Version",
    }
    if CLI_LATEST_VERSION:
        headers["X-Latest-Version"] = CLI_LATEST_VERSION
    if CLI_MIN_VERSION:
        headers["X-Min-Version"] = CLI_MIN_VERSION
    return {
        "statusCode": status_code,
        "headers": headers,
        "body": json.dumps(body, default=str),
    }


def html_resp(status_code, title, message):
    """Return an HTML response for browser-facing endpoints."""
    body = f"""\
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>{title} - Delivery Machine</title>
  <style>
    body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
           display: flex; justify-content: center; align-items: center; min-height: 100vh;
           margin: 0; background: #f5f7fa; color: #333; }}
    .card {{ background: #fff; padding: 40px; border-radius: 12px; box-shadow: 0 2px 12px rgba(0,0,0,0.1);
             max-width: 480px; text-align: center; }}
    h1 {{ color: #2c3e50; margin-bottom: 16px; }}
    p {{ color: #666; line-height: 1.6; }}
  </style>
</head>
<body>
  <div class="card">
    <h1>{title}</h1>
    <p>{message}</p>
  </div>
</body>
</html>"""
    return {
        "statusCode": status_code,
        "headers": {
            "Content-Type": "text/html; charset=utf-8",
        },
        "body": body,
    }
