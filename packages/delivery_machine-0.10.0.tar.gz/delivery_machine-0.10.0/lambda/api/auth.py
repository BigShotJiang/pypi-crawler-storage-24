"""
Delivery Machine — Authentication module.

Handles TOTP-based authentication, JWT sessions, and OAuth Device Flow.

Endpoints:
  POST /v1/auth/setup          provision TOTP for a user (requires JWT auth)
  POST /v1/auth/totp/verify    confirm TOTP code (JWT, invite token, or grace period)
  POST /v1/auth/signup         public signup (creates tenant + user + TOTP)
  POST /v1/auth/login          browser login with email + TOTP → session JWT
  POST /v1/auth/device         CLI initiates device flow → returns code
  POST /v1/auth/device/poll    CLI polls for device code completion → JWT
  POST /v1/auth/device/confirm browser confirms device code (requires session)
  GET  /v1/auth/me             return current user info from JWT
"""
import hashlib
import hmac
import json
import logging
import os
import re
import secrets
import time
from datetime import datetime, timezone

import boto3

try:
    from ulid import ULID
except ImportError:
    ULID = None

try:
    import jwt
except ImportError:
    jwt = None

try:
    import pyotp
except ImportError:
    pyotp = None

logger = logging.getLogger()

dynamodb = boto3.resource("dynamodb")
ssm = boto3.client("ssm")

USERS_TABLE = os.environ.get("USERS_TABLE", "")
DEVICE_CODES_TABLE = os.environ.get("DEVICE_CODES_TABLE", "")
JWT_SECRET_PARAM = os.environ.get("JWT_SECRET_PARAM", "")
SITE_URL = os.environ.get("SITE_URL", "https://deliverymachine.net")
FORWARD_FROM = os.environ.get("FORWARD_FROM", "forward@deliverymachine.net")
TENANTS_TABLE = os.environ.get("TENANTS_TABLE", "")

DEFAULT_SESSION_HOURS = 8       # default when user doesn't specify
DEFAULT_MAX_SESSION_HOURS = 24  # tenant-level ceiling default
DEVICE_CODE_EXPIRY = 600        # 10 minutes
SIGNUP_GRACE_PERIOD = int(os.environ.get("SIGNUP_GRACE_PERIOD", "3600"))

PLAN_QUOTAS = {
    "free":      500,
    "starter":   5_000,
    "pro":       50_000,
    "business":  500_000,
}

CLI_LATEST_VERSION = os.environ.get("CLI_LATEST_VERSION", "")
CLI_MIN_VERSION = os.environ.get("CLI_MIN_VERSION", "")

# Cache JWT secret for Lambda instance lifetime.
_jwt_secret_cache = None


def _get_jwt_secret():
    global _jwt_secret_cache
    if _jwt_secret_cache is not None:
        return _jwt_secret_cache
    if not JWT_SECRET_PARAM:
        return None
    try:
        resp = ssm.get_parameter(Name=JWT_SECRET_PARAM, WithDecryption=True)
        _jwt_secret_cache = resp["Parameter"]["Value"]
        return _jwt_secret_cache
    except Exception:
        logger.exception("Failed to fetch JWT secret")
        return None


def _resp(status, body, headers=None):
    h = {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": SITE_URL,
        "Access-Control-Allow-Headers": "Content-Type,Authorization,X-Client-Version",
        "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
        "Access-Control-Expose-Headers": "X-Latest-Version, X-Min-Version",
    }
    if CLI_LATEST_VERSION:
        h["X-Latest-Version"] = CLI_LATEST_VERSION
    if CLI_MIN_VERSION:
        h["X-Min-Version"] = CLI_MIN_VERSION
    if headers:
        h.update(headers)
    return {"statusCode": status, "headers": h, "body": json.dumps(body)}


def _html_resp(status, html):
    return {
        "statusCode": status,
        "headers": {"Content-Type": "text/html; charset=utf-8"},
        "body": html,
    }


def _get_tenant_max_session_hours(tenant_id):
    """Look up the tenant's max session duration. Returns hours (int)."""
    if not TENANTS_TABLE or not tenant_id or tenant_id == "default":
        return DEFAULT_MAX_SESSION_HOURS
    try:
        table = dynamodb.Table(TENANTS_TABLE)
        result = table.get_item(Key={"tenant_id": tenant_id})
        tenant = result.get("Item")
        if tenant and "max_session_hours" in tenant:
            return int(tenant["max_session_hours"])
    except Exception:
        logger.exception("Failed to fetch tenant max_session_hours")
    return DEFAULT_MAX_SESSION_HOURS


def resolve_session_duration(requested_hours, tenant_id):
    """
    Resolve the actual session duration in seconds.

    Returns (duration_seconds, was_capped: bool).
    If requested exceeds tenant max, caps to max and signals a warning.
    """
    if requested_hours is None or requested_hours <= 0:
        requested_hours = DEFAULT_SESSION_HOURS
    max_hours = _get_tenant_max_session_hours(tenant_id)
    capped = requested_hours > max_hours
    actual_hours = min(requested_hours, max_hours)
    return int(actual_hours * 3600), capped


def create_jwt(email, tenant_id, duration_seconds=None):
    """Create a signed JWT for the user."""
    secret = _get_jwt_secret()
    if not secret or not jwt:
        return None
    if duration_seconds is None:
        duration_seconds = DEFAULT_SESSION_HOURS * 3600
    now = int(time.time())
    payload = {
        "sub": email,
        "tenant_id": tenant_id,
        "iat": now,
        "exp": now + duration_seconds,
    }
    return jwt.encode(payload, secret, algorithm="HS256")


def verify_jwt(token):
    """
    Verify and decode a JWT. Returns the payload dict or None.
    """
    secret = _get_jwt_secret()
    if not secret or not jwt:
        return None
    try:
        return jwt.decode(token, secret, algorithms=["HS256"])
    except jwt.ExpiredSignatureError:
        logger.info("JWT expired")
        return None
    except jwt.InvalidTokenError:
        logger.info("Invalid JWT")
        return None


def extract_bearer_token(headers):
    """Extract JWT from Authorization: Bearer <token> header."""
    auth = headers.get("authorization", "")
    if auth.startswith("Bearer "):
        return auth[7:].strip()
    return None


def _generate_device_code():
    """Generate a human-friendly device code like ABCD-1234."""
    chars = "ABCDEFGHJKLMNPQRSTUVWXYZ"
    digits = "23456789"
    part1 = "".join(secrets.choice(chars) for _ in range(4))
    part2 = "".join(secrets.choice(digits) for _ in range(4))
    return f"{part1}-{part2}"


def _generate_ulid():
    """Generate a ULID string for use as an ID."""
    if ULID:
        return str(ULID())
    # Fallback to UUID if python-ulid is not installed.
    import uuid
    return str(uuid.uuid4())


def _create_invite_token(email):
    """Create an HMAC-SHA256 invite token for the given email."""
    secret = _get_jwt_secret()
    if not secret:
        return None
    return hmac.new(
        secret.encode(), email.encode(), hashlib.sha256
    ).hexdigest()


def _verify_invite_token(token, email):
    """Verify an invite token matches the expected email."""
    expected = _create_invite_token(email)
    if not expected:
        return False
    return hmac.compare_digest(token, expected)


def _is_recently_created(user, max_age_seconds=None):
    """Check if a user account was created within the grace period."""
    if max_age_seconds is None:
        max_age_seconds = SIGNUP_GRACE_PERIOD
    created_at = user.get("created_at", "")
    if not created_at:
        return False
    try:
        created = datetime.fromisoformat(created_at.replace("Z", "+00:00"))
        age = (datetime.now(timezone.utc) - created).total_seconds()
        return age <= max_age_seconds
    except (ValueError, TypeError):
        return False


# ---------------------------------------------------------------------------
# Auth route dispatcher
# ---------------------------------------------------------------------------

def route_auth(method, path, query, body, headers):
    """Handle /v1/auth/* routes. Returns response dict or None if no match."""

    # CORS preflight
    if method == "OPTIONS":
        return _resp(200, {})

    # POST /v1/auth/setup — provision TOTP (requires API key = already authed)
    if re.fullmatch(r"/v1/auth/setup/?", path) and method == "POST":
        return setup_totp(body, headers)

    # POST /v1/auth/totp/verify — confirm TOTP code
    if re.fullmatch(r"/v1/auth/totp/verify/?", path) and method == "POST":
        return verify_totp_setup(body, headers)

    # POST /v1/auth/login — browser login with email + TOTP
    if re.fullmatch(r"/v1/auth/login/?", path) and method == "POST":
        return login(body)

    # POST /v1/auth/device — CLI initiates device flow
    if re.fullmatch(r"/v1/auth/device/?", path) and method == "POST":
        return initiate_device_flow(body)

    # POST /v1/auth/device/poll — CLI polls for completion
    if re.fullmatch(r"/v1/auth/device/poll/?", path) and method == "POST":
        return poll_device_flow(body)

    # POST /v1/auth/device/confirm — browser confirms device code
    if re.fullmatch(r"/v1/auth/device/confirm/?", path) and method == "POST":
        return confirm_device_flow(body, headers)

    # POST /v1/auth/signup — public signup (creates tenant + user + TOTP)
    if re.fullmatch(r"/v1/auth/signup/?", path) and method == "POST":
        return signup(body)

    # GET /v1/auth/me — current user info
    if re.fullmatch(r"/v1/auth/me/?", path) and method == "GET":
        return get_me(headers)

    return _resp(404, {"error": "Not found"})


# ---------------------------------------------------------------------------
# TOTP setup
# ---------------------------------------------------------------------------

def setup_totp(body, headers):
    """
    Provision a TOTP secret for a user. Requires JWT authentication.

    Body: {"email": "user@example.com"}
    Returns: {"provisioning_uri": "otpauth://...", "secret": "BASE32...", "invite_token": "..."}
    """
    if not pyotp:
        return _resp(500, {"error": "TOTP not available"})

    # Require JWT authentication.
    token = extract_bearer_token(headers)
    if not token:
        return _resp(401, {"error": "Authorization required. Log in first with dm login."})
    claims = verify_jwt(token)
    if not claims:
        return _resp(401, {"error": "Invalid or expired session"})

    email = body.get("email", "").strip().lower()
    tenant_id = body.get("tenant_id", "").strip() or claims.get("tenant_id", "")
    if not email or not tenant_id:
        return _resp(400, {"error": "email is required"})

    if not USERS_TABLE:
        return _resp(500, {"error": "Users table not configured"})

    table = dynamodb.Table(USERS_TABLE)

    # Check if user already exists and is verified.
    existing = table.get_item(Key={"email": email}).get("Item")
    if existing and existing.get("totp_verified"):
        return _resp(409, {"error": "User already has TOTP configured. Use /v1/auth/totp/reset to reconfigure."})

    # Generate TOTP secret.
    totp_secret = pyotp.random_base32()

    # Store user (or update if re-provisioning before verification).
    table.put_item(Item={
        "email": email,
        "tenant_id": tenant_id,
        "totp_secret": totp_secret,
        "totp_verified": False,
        "created_at": datetime.now(timezone.utc).isoformat(),
    })

    # Generate provisioning URI for authenticator apps.
    totp = pyotp.TOTP(totp_secret)
    uri = totp.provisioning_uri(name=email, issuer_name="Delivery Machine")

    invite_token = _create_invite_token(email)

    logger.info("TOTP provisioned for %s (tenant=%s)", email, tenant_id)
    result = {
        "email": email,
        "provisioning_uri": uri,
        "secret": totp_secret,
        "message": "Share the invite token with the user so they can verify their TOTP setup.",
    }
    if invite_token:
        result["invite_token"] = invite_token
    return _resp(201, result)


def verify_totp_setup(body, headers):
    """
    Confirm TOTP is working by validating a code. Activates the account.

    Accepts three auth methods:
    1. JWT (admin re-verifying)
    2. Invite token in body (invited user completing setup)
    3. Recently created account (within SIGNUP_GRACE_PERIOD)

    Body: {"email": "user@example.com", "code": "123456", "invite_token": "..."}
    """
    if not pyotp:
        return _resp(500, {"error": "TOTP not available"})

    email = body.get("email", "").strip().lower()
    code = body.get("code", "").strip()
    if not email or not code:
        return _resp(400, {"error": "email and code are required"})

    table = dynamodb.Table(USERS_TABLE)
    user = table.get_item(Key={"email": email}).get("Item")
    if not user:
        return _resp(404, {"error": "User not found"})

    # Check authorization: JWT, invite token, or recently created account.
    authorized = False

    # Method 1: JWT auth (admin)
    bearer = extract_bearer_token(headers)
    if bearer:
        claims = verify_jwt(bearer)
        if claims:
            authorized = True

    # Method 2: Invite token
    if not authorized:
        invite_token = body.get("invite_token", "")
        if invite_token and _verify_invite_token(invite_token, email):
            authorized = True

    # Method 3: Recently created account (signup grace period)
    if not authorized:
        if _is_recently_created(user):
            authorized = True

    if not authorized:
        return _resp(401, {"error": "Authorization required. Use an invite token or log in first."})

    if user.get("totp_verified"):
        return _resp(200, {"message": "TOTP already verified"})

    totp = pyotp.TOTP(user["totp_secret"])
    if not totp.verify(code, valid_window=1):
        return _resp(401, {"error": "Invalid TOTP code"})

    # Mark as verified.
    table.update_item(
        Key={"email": email},
        UpdateExpression="SET totp_verified = :v",
        ExpressionAttributeValues={":v": True},
    )

    logger.info("TOTP verified for %s", email)
    return _resp(200, {"message": "TOTP verified. You can now use dm login."})


# ---------------------------------------------------------------------------
# Browser login (TOTP)
# ---------------------------------------------------------------------------

def login(body):
    """
    Authenticate with email + TOTP code. Returns a session JWT.

    Body: {"email": "user@example.com", "code": "123456", "session_hours": 8}
    session_hours is optional; defaults to DEFAULT_SESSION_HOURS, capped by tenant max.
    """
    if not pyotp:
        return _resp(500, {"error": "TOTP not available"})

    email = body.get("email", "").strip().lower()
    code = body.get("code", "").strip()
    if not email or not code:
        return _resp(400, {"error": "email and code are required"})

    table = dynamodb.Table(USERS_TABLE)
    user = table.get_item(Key={"email": email}).get("Item")
    if not user:
        return _resp(401, {"error": "Invalid credentials"})

    if not user.get("totp_verified"):
        return _resp(401, {"error": "TOTP not yet verified. Complete setup first."})

    totp = pyotp.TOTP(user["totp_secret"])
    if not totp.verify(code, valid_window=1):
        return _resp(401, {"error": "Invalid credentials"})

    requested_hours = body.get("session_hours")
    if requested_hours is not None:
        try:
            requested_hours = float(requested_hours)
        except (TypeError, ValueError):
            requested_hours = None

    duration_seconds, was_capped = resolve_session_duration(requested_hours, user["tenant_id"])
    token = create_jwt(email, user["tenant_id"], duration_seconds)
    if not token:
        return _resp(500, {"error": "Failed to create session"})

    result = {
        "token": token,
        "email": email,
        "tenant_id": user["tenant_id"],
        "expires_in": duration_seconds,
    }
    if was_capped:
        max_hours = _get_tenant_max_session_hours(user["tenant_id"])
        result["warning"] = f"Requested duration exceeds tenant maximum of {max_hours}h. Session capped to {max_hours}h."

    logger.info("Login successful for %s (duration=%ds, capped=%s)", email, duration_seconds, was_capped)
    return _resp(200, result)


# ---------------------------------------------------------------------------
# OAuth Device Flow
# ---------------------------------------------------------------------------

def initiate_device_flow(body):
    """
    CLI starts a device authorization flow.

    Body: {"session_hours": 8}  (optional)
    Returns: {"code": "ABCD-1234", "device_url": "https://deliverymachine.net/device?code=ABCD-1234", "expires_in": 600}
    """
    if not DEVICE_CODES_TABLE:
        return _resp(500, {"error": "Device codes table not configured"})

    code = _generate_device_code()
    expires_at = int(time.time()) + DEVICE_CODE_EXPIRY

    session_hours = body.get("session_hours")

    table = dynamodb.Table(DEVICE_CODES_TABLE)
    item = {
        "code": code,
        "status": "pending",
        "expires_at": expires_at,
        "created_at": datetime.now(timezone.utc).isoformat(),
    }
    if session_hours is not None:
        item["session_hours"] = str(session_hours)
    table.put_item(Item=item)

    device_url = f"{SITE_URL}/device?code={code}"
    logger.info("Device flow initiated: %s", code)

    return _resp(200, {
        "code": code,
        "device_url": device_url,
        "expires_in": DEVICE_CODE_EXPIRY,
        "poll_interval": 5,
    })


def poll_device_flow(body):
    """
    CLI polls to check if the device code has been confirmed.

    Body: {"code": "ABCD-1234"}
    Returns:
      - 200 + {token, ...} if confirmed
      - 202 + {status: "pending"} if still waiting
      - 410 + {error: "expired"} if code expired
    """
    code = body.get("code", "").strip()
    if not code:
        return _resp(400, {"error": "code is required"})

    table = dynamodb.Table(DEVICE_CODES_TABLE)
    item = table.get_item(Key={"code": code}).get("Item")

    if not item:
        return _resp(404, {"error": "Unknown device code"})

    if int(item.get("expires_at", 0)) < int(time.time()):
        return _resp(410, {"error": "Device code expired"})

    status = item.get("status", "pending")

    if status == "confirmed":
        # Return the JWT that was stored when the browser confirmed.
        expires_in = int(item.get("expires_in_seconds", DEFAULT_SESSION_HOURS * 3600))
        return _resp(200, {
            "token": item.get("jwt", ""),
            "email": item.get("email", ""),
            "tenant_id": item.get("tenant_id", ""),
            "expires_in": expires_in,
        })

    # Still pending.
    return _resp(202, {"status": "pending", "message": "Waiting for browser confirmation"})


def confirm_device_flow(body, headers):
    """
    Browser confirms a device code after authenticating.

    Body: {"code": "ABCD-1234"}
    Requires: Authorization: Bearer <jwt> (from browser login)
    """
    # Verify browser session.
    token = extract_bearer_token(headers)
    if not token:
        return _resp(401, {"error": "Authorization required"})

    claims = verify_jwt(token)
    if not claims:
        return _resp(401, {"error": "Invalid or expired session"})

    code = body.get("code", "").strip()
    if not code:
        return _resp(400, {"error": "code is required"})

    table = dynamodb.Table(DEVICE_CODES_TABLE)
    item = table.get_item(Key={"code": code}).get("Item")

    if not item:
        return _resp(404, {"error": "Unknown device code"})

    if int(item.get("expires_at", 0)) < int(time.time()):
        return _resp(410, {"error": "Device code expired"})

    if item.get("status") != "pending":
        return _resp(409, {"error": "Device code already used"})

    # Resolve session duration from CLI's request (stored on device code).
    requested_hours = None
    if "session_hours" in item:
        try:
            requested_hours = float(item["session_hours"])
        except (TypeError, ValueError):
            pass
    duration_seconds, was_capped = resolve_session_duration(requested_hours, claims["tenant_id"])

    # Create a fresh JWT for the CLI.
    cli_token = create_jwt(claims["sub"], claims["tenant_id"], duration_seconds)
    if not cli_token:
        return _resp(500, {"error": "Failed to create CLI token"})

    # Update device code to confirmed + store the JWT.
    table.update_item(
        Key={"code": code},
        UpdateExpression="SET #s = :confirmed, jwt = :jwt, email = :email, tenant_id = :tid, expires_in_seconds = :exp",
        ExpressionAttributeNames={"#s": "status"},
        ExpressionAttributeValues={
            ":confirmed": "confirmed",
            ":jwt": cli_token,
            ":email": claims["sub"],
            ":tid": claims["tenant_id"],
            ":exp": duration_seconds,
        },
    )

    result = {"message": "Device authorized", "email": claims["sub"]}
    if was_capped:
        max_hours = _get_tenant_max_session_hours(claims["tenant_id"])
        result["warning"] = f"Session capped to tenant maximum of {max_hours}h."

    logger.info("Device code %s confirmed by %s (duration=%ds)", code, claims["sub"], duration_seconds)
    return _resp(200, result)


# ---------------------------------------------------------------------------
# Public signup
# ---------------------------------------------------------------------------

def signup(body):
    """
    Create a new account: tenant + user + TOTP in one step.

    Body: {"email": "user@example.com", "plan": "free"}
    Returns: {"provisioning_uri": "otpauth://...", "secret": "BASE32...", "email": "..."}
    """
    if not pyotp:
        return _resp(500, {"error": "TOTP not available"})

    email = body.get("email", "").strip().lower()
    if not email or "@" not in email:
        return _resp(400, {"error": "A valid email address is required"})

    plan = body.get("plan", "free").strip().lower()
    if plan not in PLAN_QUOTAS:
        return _resp(400, {"error": f"Unknown plan '{plan}'. Valid: {list(PLAN_QUOTAS)}"})

    if not USERS_TABLE or not TENANTS_TABLE:
        return _resp(500, {"error": "Tables not configured"})

    users_table = dynamodb.Table(USERS_TABLE)
    tenants_table = dynamodb.Table(TENANTS_TABLE)

    # Check if user already exists.
    existing = users_table.get_item(Key={"email": email}).get("Item")
    if existing and existing.get("totp_verified"):
        return _resp(409, {"error": "An account with this email already exists. Use dm login to sign in."})

    # Create tenant.
    tenant_id = _generate_ulid()
    now = datetime.now(timezone.utc).isoformat()

    tenants_table.put_item(Item={
        "tenant_id": tenant_id,
        "plan": plan,
        "email_quota": PLAN_QUOTAS[plan],
        "email_count": 0,
        "credits": 0,
        "created_at": now,
        "updated_at": now,
    })

    # Create user with TOTP.
    totp_secret = pyotp.random_base32()
    users_table.put_item(Item={
        "email": email,
        "tenant_id": tenant_id,
        "totp_secret": totp_secret,
        "totp_verified": False,
        "plan": plan,
        "created_at": now,
    })

    totp = pyotp.TOTP(totp_secret)
    uri = totp.provisioning_uri(name=email, issuer_name="Delivery Machine")

    invite_token = _create_invite_token(email)

    logger.info("Signup: %s plan=%s tenant=%s", email, plan, tenant_id)
    result = {
        "email": email,
        "tenant_id": tenant_id,
        "plan": plan,
        "provisioning_uri": uri,
        "secret": totp_secret,
    }
    if invite_token:
        result["invite_token"] = invite_token
    return _resp(201, result)


# ---------------------------------------------------------------------------
# Current user
# ---------------------------------------------------------------------------

def get_me(headers):
    """Return current user info from JWT."""
    token = extract_bearer_token(headers)
    if not token:
        return _resp(401, {"error": "Authorization required"})

    claims = verify_jwt(token)
    if not claims:
        return _resp(401, {"error": "Invalid or expired session"})

    return _resp(200, {
        "email": claims.get("sub"),
        "tenant_id": claims.get("tenant_id"),
        "expires_at": claims.get("exp"),
    })
