"""Tests for the auth module."""
import json
import os
import sys
import time
import unittest
from unittest.mock import MagicMock, patch

# Set env vars before importing.
os.environ["USERS_TABLE"] = "test-users"
os.environ["DEVICE_CODES_TABLE"] = "test-device-codes"
os.environ["TENANTS_TABLE"] = "test-tenants"
os.environ["JWT_SECRET_PARAM"] = "/delivery-machine/jwt-secret"
os.environ["SITE_URL"] = "https://test.example.com"

# Install real PyJWT for testing (via pip).  If not available, create a
# lightweight mock that behaves like the real thing.
try:
    import jwt as _real_jwt
except ImportError:
    # Build a minimal jwt mock that actually signs/verifies.
    import hmac
    import hashlib
    import base64 as _b64

    class _JWTMock:
        """Minimal HS256 JWT implementation for tests."""

        class ExpiredSignatureError(Exception):
            pass

        class InvalidTokenError(Exception):
            pass

        @staticmethod
        def encode(payload, secret, algorithm="HS256"):
            header = _b64.urlsafe_b64encode(json.dumps({"alg": "HS256", "typ": "JWT"}).encode()).rstrip(b"=").decode()
            body = _b64.urlsafe_b64encode(json.dumps(payload).encode()).rstrip(b"=").decode()
            sig_input = f"{header}.{body}"
            sig = _b64.urlsafe_b64encode(
                hmac.new(secret.encode(), sig_input.encode(), hashlib.sha256).digest()
            ).rstrip(b"=").decode()
            return f"{header}.{body}.{sig}"

        @staticmethod
        def decode(token, secret, algorithms=None):
            try:
                parts = token.split(".")
                if len(parts) != 3:
                    raise _JWTMock.InvalidTokenError("Bad token")
                header, body, sig = parts
                # Verify signature.
                sig_input = f"{header}.{body}"
                expected = _b64.urlsafe_b64encode(
                    hmac.new(secret.encode(), sig_input.encode(), hashlib.sha256).digest()
                ).rstrip(b"=").decode()
                if sig != expected:
                    raise _JWTMock.InvalidTokenError("Signature mismatch")
                # Pad body for base64.
                padded = body + "=" * (4 - len(body) % 4)
                payload = json.loads(_b64.urlsafe_b64decode(padded))
                if "exp" in payload and payload["exp"] < time.time():
                    raise _JWTMock.ExpiredSignatureError("Expired")
                return payload
            except (_JWTMock.ExpiredSignatureError, _JWTMock.InvalidTokenError):
                raise
            except Exception:
                raise _JWTMock.InvalidTokenError("Decode failed")

    _real_jwt = _JWTMock()
    # Make it behave like a module with exception classes as attributes.
    sys.modules["jwt"] = _real_jwt

try:
    import pyotp as _real_pyotp
except ImportError:
    _real_pyotp = MagicMock()
    _real_pyotp.random_base32.return_value = "JBSWY3DPEHPK3PXP"
    sys.modules["pyotp"] = _real_pyotp

# Mock boto3 before importing auth.
mock_dynamodb = MagicMock()
mock_ssm = MagicMock()
mock_ssm.get_parameter.return_value = {
    "Parameter": {"Value": "test-secret-key-that-is-long-enough-for-hs256-signing-purposes-ok"}
}

with patch("boto3.resource", return_value=mock_dynamodb), \
     patch("boto3.client", return_value=mock_ssm):
    import auth


# Reset JWT secret cache for tests.
def _reset_jwt_cache():
    auth._jwt_secret_cache = None


class TestResp(unittest.TestCase):
    def test_basic_response(self):
        r = auth._resp(200, {"ok": True})
        self.assertEqual(r["statusCode"], 200)
        body = json.loads(r["body"])
        self.assertTrue(body["ok"])
        self.assertIn("Access-Control-Allow-Origin", r["headers"])

    def test_cors_headers(self):
        r = auth._resp(200, {})
        self.assertEqual(r["headers"]["Access-Control-Allow-Origin"], "https://test.example.com")
        self.assertIn("Authorization", r["headers"]["Access-Control-Allow-Headers"])


class TestExtractBearerToken(unittest.TestCase):
    def test_valid_bearer(self):
        self.assertEqual(auth.extract_bearer_token({"authorization": "Bearer abc123"}), "abc123")

    def test_missing_header(self):
        self.assertIsNone(auth.extract_bearer_token({}))

    def test_not_bearer(self):
        self.assertIsNone(auth.extract_bearer_token({"authorization": "Basic abc"}))

    def test_strips_whitespace(self):
        self.assertEqual(auth.extract_bearer_token({"authorization": "Bearer  tok "}), "tok")


class TestGenerateDeviceCode(unittest.TestCase):
    def test_format(self):
        code = auth._generate_device_code()
        parts = code.split("-")
        self.assertEqual(len(parts), 2)
        self.assertEqual(len(parts[0]), 4)
        self.assertEqual(len(parts[1]), 4)

    def test_no_ambiguous_chars(self):
        # The charset excludes O and I from letters, and 0 and 1 from digits.
        for _ in range(50):
            code = auth._generate_device_code()
            letters = code.split("-")[0]
            digits = code.split("-")[1]
            for c in letters:
                self.assertNotIn(c, "0OI1")
            for d in digits:
                self.assertNotIn(d, "01")

    def test_uniqueness(self):
        codes = {auth._generate_device_code() for _ in range(100)}
        self.assertGreater(len(codes), 90)


class TestResolveSessionDuration(unittest.TestCase):
    def test_default_duration(self):
        with patch.object(auth, "_get_tenant_max_session_hours", return_value=24):
            dur, capped = auth.resolve_session_duration(None, "t1")
            self.assertEqual(dur, 8 * 3600)
            self.assertFalse(capped)

    def test_requested_within_limit(self):
        with patch.object(auth, "_get_tenant_max_session_hours", return_value=24):
            dur, capped = auth.resolve_session_duration(12, "t1")
            self.assertEqual(dur, 12 * 3600)
            self.assertFalse(capped)

    def test_requested_exceeds_limit(self):
        with patch.object(auth, "_get_tenant_max_session_hours", return_value=10):
            dur, capped = auth.resolve_session_duration(24, "t1")
            self.assertEqual(dur, 10 * 3600)
            self.assertTrue(capped)

    def test_negative_falls_to_default(self):
        with patch.object(auth, "_get_tenant_max_session_hours", return_value=24):
            dur, capped = auth.resolve_session_duration(-5, "t1")
            self.assertEqual(dur, 8 * 3600)
            self.assertFalse(capped)

    def test_zero_falls_to_default(self):
        with patch.object(auth, "_get_tenant_max_session_hours", return_value=24):
            dur, capped = auth.resolve_session_duration(0, "t1")
            self.assertEqual(dur, 8 * 3600)
            self.assertFalse(capped)


class TestJWT(unittest.TestCase):
    def setUp(self):
        _reset_jwt_cache()

    def test_create_and_verify(self):
        token = auth.create_jwt("user@test.com", "tenant1", 3600)
        self.assertIsNotNone(token)

        claims = auth.verify_jwt(token)
        self.assertIsNotNone(claims)
        self.assertEqual(claims["sub"], "user@test.com")
        self.assertEqual(claims["tenant_id"], "tenant1")
        self.assertIn("exp", claims)
        self.assertIn("iat", claims)

    def test_expired_token(self):
        token = auth.create_jwt("user@test.com", "tenant1", -1)
        claims = auth.verify_jwt(token)
        self.assertIsNone(claims)

    def test_invalid_token(self):
        claims = auth.verify_jwt("not.a.token")
        self.assertIsNone(claims)

    def test_no_secret_returns_none(self):
        with patch.object(auth, "_get_jwt_secret", return_value=None):
            token = auth.create_jwt("user@test.com", "tenant1")
            self.assertIsNone(token)


class TestRouteAuth(unittest.TestCase):
    def test_options_preflight(self):
        r = auth.route_auth("OPTIONS", "/v1/auth/login", {}, {}, {})
        self.assertEqual(r["statusCode"], 200)

    def test_unknown_route(self):
        r = auth.route_auth("GET", "/v1/auth/nonexistent", {}, {}, {})
        self.assertEqual(r["statusCode"], 404)

    def test_get_me_no_auth(self):
        r = auth.route_auth("GET", "/v1/auth/me", {}, {}, {})
        self.assertEqual(r["statusCode"], 401)

    def test_get_me_valid_jwt(self):
        _reset_jwt_cache()
        token = auth.create_jwt("me@test.com", "t1", 3600)
        r = auth.route_auth("GET", "/v1/auth/me", {}, {}, {"authorization": f"Bearer {token}"})
        self.assertEqual(r["statusCode"], 200)
        body = json.loads(r["body"])
        self.assertEqual(body["email"], "me@test.com")


class TestLogin(unittest.TestCase):
    def test_missing_fields(self):
        r = auth.login({})
        self.assertEqual(r["statusCode"], 400)

    def test_missing_code(self):
        r = auth.login({"email": "a@b.com"})
        self.assertEqual(r["statusCode"], 400)

    @patch.object(auth, "dynamodb")
    def test_user_not_found(self, mock_db):
        mock_table = MagicMock()
        mock_table.get_item.return_value = {}
        mock_db.Table.return_value = mock_table
        r = auth.login({"email": "a@b.com", "code": "123456"})
        self.assertEqual(r["statusCode"], 401)

    @patch.object(auth, "dynamodb")
    def test_totp_not_verified(self, mock_db):
        mock_table = MagicMock()
        mock_table.get_item.return_value = {"Item": {"email": "a@b.com", "totp_verified": False, "totp_secret": "BASE32SECRET"}}
        mock_db.Table.return_value = mock_table
        r = auth.login({"email": "a@b.com", "code": "123456"})
        self.assertEqual(r["statusCode"], 401)

    @patch.object(auth, "dynamodb")
    def test_successful_login(self, mock_db):
        _reset_jwt_cache()
        mock_totp = MagicMock()
        mock_totp.verify.return_value = True
        auth.pyotp.TOTP.return_value = mock_totp

        mock_table = MagicMock()
        mock_table.get_item.return_value = {"Item": {
            "email": "a@b.com",
            "totp_verified": True,
            "totp_secret": "BASE32SECRET",
            "tenant_id": "t1",
        }}
        mock_db.Table.return_value = mock_table

        with patch.object(auth, "_get_tenant_max_session_hours", return_value=24):
            r = auth.login({"email": "a@b.com", "code": "123456"})
        self.assertEqual(r["statusCode"], 200)
        body = json.loads(r["body"])
        self.assertIn("token", body)
        self.assertEqual(body["email"], "a@b.com")

    @patch.object(auth, "dynamodb")
    def test_login_capped_warning(self, mock_db):
        _reset_jwt_cache()
        mock_totp = MagicMock()
        mock_totp.verify.return_value = True
        auth.pyotp.TOTP.return_value = mock_totp

        mock_table = MagicMock()
        mock_table.get_item.return_value = {"Item": {
            "email": "a@b.com",
            "totp_verified": True,
            "totp_secret": "BASE32SECRET",
            "tenant_id": "t1",
        }}
        mock_db.Table.return_value = mock_table

        with patch.object(auth, "_get_tenant_max_session_hours", return_value=4):
            r = auth.login({"email": "a@b.com", "code": "123456", "session_hours": 12})
        self.assertEqual(r["statusCode"], 200)
        body = json.loads(r["body"])
        self.assertIn("warning", body)
        self.assertEqual(body["expires_in"], 4 * 3600)


class TestDeviceFlow(unittest.TestCase):
    @patch.object(auth, "dynamodb")
    def test_initiate(self, mock_db):
        mock_table = MagicMock()
        mock_db.Table.return_value = mock_table
        r = auth.initiate_device_flow({})
        self.assertEqual(r["statusCode"], 200)
        body = json.loads(r["body"])
        self.assertIn("code", body)
        self.assertIn("device_url", body)
        self.assertIn(body["code"], body["device_url"])

    @patch.object(auth, "dynamodb")
    def test_poll_pending(self, mock_db):
        mock_table = MagicMock()
        mock_table.get_item.return_value = {"Item": {
            "code": "ABCD-2345",
            "status": "pending",
            "expires_at": int(time.time()) + 600,
        }}
        mock_db.Table.return_value = mock_table
        r = auth.poll_device_flow({"code": "ABCD-2345"})
        self.assertEqual(r["statusCode"], 202)

    @patch.object(auth, "dynamodb")
    def test_poll_confirmed(self, mock_db):
        mock_table = MagicMock()
        mock_table.get_item.return_value = {"Item": {
            "code": "ABCD-2345",
            "status": "confirmed",
            "expires_at": int(time.time()) + 600,
            "jwt": "sometoken",
            "email": "a@b.com",
            "tenant_id": "t1",
            "expires_in_seconds": 28800,
        }}
        mock_db.Table.return_value = mock_table
        r = auth.poll_device_flow({"code": "ABCD-2345"})
        self.assertEqual(r["statusCode"], 200)
        body = json.loads(r["body"])
        self.assertEqual(body["token"], "sometoken")

    @patch.object(auth, "dynamodb")
    def test_poll_expired(self, mock_db):
        mock_table = MagicMock()
        mock_table.get_item.return_value = {"Item": {
            "code": "ABCD-2345",
            "status": "pending",
            "expires_at": int(time.time()) - 10,
        }}
        mock_db.Table.return_value = mock_table
        r = auth.poll_device_flow({"code": "ABCD-2345"})
        self.assertEqual(r["statusCode"], 410)

    @patch.object(auth, "dynamodb")
    def test_poll_not_found(self, mock_db):
        mock_table = MagicMock()
        mock_table.get_item.return_value = {}
        mock_db.Table.return_value = mock_table
        r = auth.poll_device_flow({"code": "NOPE-0000"})
        self.assertEqual(r["statusCode"], 404)

    @patch.object(auth, "dynamodb")
    def test_confirm_no_auth(self, mock_db):
        r = auth.confirm_device_flow({"code": "ABCD-2345"}, {})
        self.assertEqual(r["statusCode"], 401)

    @patch.object(auth, "dynamodb")
    def test_confirm_success(self, mock_db):
        _reset_jwt_cache()
        token = auth.create_jwt("user@test.com", "t1", 3600)

        mock_table = MagicMock()
        mock_table.get_item.return_value = {"Item": {
            "code": "ABCD-2345",
            "status": "pending",
            "expires_at": int(time.time()) + 600,
        }}
        mock_db.Table.return_value = mock_table

        with patch.object(auth, "_get_tenant_max_session_hours", return_value=24):
            r = auth.confirm_device_flow(
                {"code": "ABCD-2345"},
                {"authorization": f"Bearer {token}"},
            )
        self.assertEqual(r["statusCode"], 200)
        body = json.loads(r["body"])
        self.assertEqual(body["message"], "Device authorized")
        mock_table.update_item.assert_called_once()

    @patch.object(auth, "dynamodb")
    def test_confirm_already_used(self, mock_db):
        _reset_jwt_cache()
        token = auth.create_jwt("user@test.com", "t1", 3600)

        mock_table = MagicMock()
        mock_table.get_item.return_value = {"Item": {
            "code": "ABCD-2345",
            "status": "confirmed",
            "expires_at": int(time.time()) + 600,
        }}
        mock_db.Table.return_value = mock_table

        r = auth.confirm_device_flow(
            {"code": "ABCD-2345"},
            {"authorization": f"Bearer {token}"},
        )
        self.assertEqual(r["statusCode"], 409)


class TestSetupTotp(unittest.TestCase):
    def test_missing_fields(self):
        r = auth.setup_totp({}, {})
        self.assertEqual(r["statusCode"], 400)

    @patch.object(auth, "dynamodb")
    def test_success(self, mock_db):
        auth.pyotp.random_base32.return_value = "JBSWY3DPEHPK3PXP"
        mock_totp = MagicMock()
        mock_totp.provisioning_uri.return_value = "otpauth://totp/Delivery%20Machine:a@b.com?secret=JBSWY3DPEHPK3PXP"
        auth.pyotp.TOTP.return_value = mock_totp

        mock_table = MagicMock()
        mock_table.get_item.return_value = {}
        mock_db.Table.return_value = mock_table

        r = auth.setup_totp({"email": "a@b.com", "tenant_id": "t1"}, {})
        self.assertEqual(r["statusCode"], 201)
        body = json.loads(r["body"])
        self.assertIn("provisioning_uri", body)
        self.assertIn("secret", body)

    @patch.object(auth, "dynamodb")
    def test_already_configured(self, mock_db):
        mock_table = MagicMock()
        mock_table.get_item.return_value = {"Item": {"email": "a@b.com", "totp_verified": True}}
        mock_db.Table.return_value = mock_table
        r = auth.setup_totp({"email": "a@b.com", "tenant_id": "t1"}, {})
        self.assertEqual(r["statusCode"], 409)


class TestVerifyTotpSetup(unittest.TestCase):
    def test_missing_fields(self):
        r = auth.verify_totp_setup({})
        self.assertEqual(r["statusCode"], 400)

    @patch.object(auth, "dynamodb")
    def test_user_not_found(self, mock_db):
        mock_table = MagicMock()
        mock_table.get_item.return_value = {}
        mock_db.Table.return_value = mock_table
        r = auth.verify_totp_setup({"email": "a@b.com", "code": "123456"})
        self.assertEqual(r["statusCode"], 404)

    @patch.object(auth, "dynamodb")
    def test_invalid_code(self, mock_db):
        mock_totp = MagicMock()
        mock_totp.verify.return_value = False
        auth.pyotp.TOTP.return_value = mock_totp

        mock_table = MagicMock()
        mock_table.get_item.return_value = {"Item": {
            "email": "a@b.com",
            "totp_verified": False,
            "totp_secret": "BASE32SECRET",
        }}
        mock_db.Table.return_value = mock_table

        r = auth.verify_totp_setup({"email": "a@b.com", "code": "000000"})
        self.assertEqual(r["statusCode"], 401)

    @patch.object(auth, "dynamodb")
    def test_success(self, mock_db):
        mock_totp = MagicMock()
        mock_totp.verify.return_value = True
        auth.pyotp.TOTP.return_value = mock_totp

        mock_table = MagicMock()
        mock_table.get_item.return_value = {"Item": {
            "email": "a@b.com",
            "totp_verified": False,
            "totp_secret": "BASE32SECRET",
        }}
        mock_db.Table.return_value = mock_table

        r = auth.verify_totp_setup({"email": "a@b.com", "code": "123456"})
        self.assertEqual(r["statusCode"], 200)
        mock_table.update_item.assert_called_once()


if __name__ == "__main__":
    unittest.main()
