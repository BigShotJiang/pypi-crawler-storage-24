"""Daily status report — sends an HTML email with platform metrics.

Triggered daily by EventBridge. Queries CloudWatch and DynamoDB for the
last 24 hours of activity, then sends a summary via SES.
"""

import json
import logging
import os
from collections import Counter
from datetime import datetime, timezone, timedelta

import boto3

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Colours for the HTML email.
CYAN = "#00d4ff"
NAVY = "#06060e"
SURFACE = "#12121e"
BORDER = "#2a2a3e"
TEXT = "#e2e2ef"
MUTED = "#6a6a82"
RED = "#ff4466"
GREEN = "#28c840"


# ---------------------------------------------------------------------------
# Data collection
# ---------------------------------------------------------------------------

def _collect_cloudwatch_metrics(cw):
    """Fetch key CloudWatch metrics for the last 24 hours."""
    end = datetime.now(tz=timezone.utc)
    start = end - timedelta(hours=24)
    results = {}

    queries = [
        ("Errors_Forwarder", "AWS/Lambda", "Errors", "Sum", {"FunctionName": os.environ.get("FORWARDER_FUNCTION", "")}),
        ("Errors_API", "AWS/Lambda", "Errors", "Sum", {"FunctionName": os.environ.get("API_FUNCTION", "")}),
        ("Invocations_Forwarder", "AWS/Lambda", "Invocations", "Sum", {"FunctionName": os.environ.get("FORWARDER_FUNCTION", "")}),
        ("Invocations_API", "AWS/Lambda", "Invocations", "Sum", {"FunctionName": os.environ.get("API_FUNCTION", "")}),
        ("4xx", "AWS/ApiGateway", "4XXError", "Sum", {"ApiName": os.environ.get("API_NAME", ""), "Stage": "prod"}),
        ("5xx", "AWS/ApiGateway", "5XXError", "Sum", {"ApiName": os.environ.get("API_NAME", ""), "Stage": "prod"}),
        ("SES_Send", "AWS/SES", "Send", "Sum", {}),
        ("SES_Bounce", "AWS/SES", "Bounce", "Sum", {}),
        ("SES_Complaint", "AWS/SES", "Complaint", "Sum", {}),
    ]

    for key, namespace, metric_name, stat, dims in queries:
        try:
            resp = cw.get_metric_statistics(
                Namespace=namespace,
                MetricName=metric_name,
                StartTime=start,
                EndTime=end,
                Period=86400,
                Statistics=[stat],
                Dimensions=[{"Name": k, "Value": v} for k, v in dims.items()] if dims else [],
            )
            dp = resp.get("Datapoints", [])
            results[key] = dp[0][stat] if dp else 0
        except Exception:
            logger.warning("CloudWatch metric fetch failed: %s", key)
            results[key] = 0

    return results


def _collect_table_counts(ddb):
    """Count items in key DynamoDB tables."""
    counts = {}
    for table_env in ["RULES_TABLE", "DOMAINS_TABLE", "USERS_TABLE", "TENANTS_TABLE"]:
        table_name = os.environ.get(table_env, "")
        if not table_name:
            counts[table_env] = 0
            continue
        try:
            table = ddb.Table(table_name)
            total = 0
            params = {"Select": "COUNT"}
            while True:
                resp = table.scan(**params)
                total += resp.get("Count", 0)
                if "LastEvaluatedKey" not in resp:
                    break
                params["ExclusiveStartKey"] = resp["LastEvaluatedKey"]
            counts[table_env] = total
        except Exception:
            logger.warning("Failed to get count for %s", table_name)
            counts[table_env] = 0
    return counts


def _collect_user_plans(ddb):
    """Count users by plan."""
    table_name = os.environ.get("USERS_TABLE", "")
    if not table_name:
        return {}
    by_plan = Counter()
    try:
        table = ddb.Table(table_name)
        params = {
            "ProjectionExpression": "#p",
            "ExpressionAttributeNames": {"#p": "plan"},
        }
        while True:
            resp = table.scan(**params)
            for item in resp.get("Items", []):
                by_plan[item.get("plan", "free")] += 1
            if "LastEvaluatedKey" not in resp:
                break
            params["ExclusiveStartKey"] = resp["LastEvaluatedKey"]
    except Exception:
        logger.warning("Failed to scan users for plan distribution")
    return dict(by_plan)


def _collect_integrity_issues(ddb):
    """Check for data integrity issues across tables."""
    issues = []

    try:
        # Collect all tenant_ids that actually exist.
        tenant_ids = set()
        tenants_name = os.environ.get("TENANTS_TABLE", "")
        if tenants_name:
            table = ddb.Table(tenants_name)
            params = {"ProjectionExpression": "tenant_id"}
            while True:
                resp = table.scan(**params)
                for item in resp.get("Items", []):
                    tenant_ids.add(item["tenant_id"])
                if "LastEvaluatedKey" not in resp:
                    break
                params["ExclusiveStartKey"] = resp["LastEvaluatedKey"]

        # Check rules for orphaned tenant_ids.
        rules_name = os.environ.get("RULES_TABLE", "")
        if rules_name and tenants_name:
            table = ddb.Table(rules_name)
            params = {"ProjectionExpression": "tenant_id, #d, localpart",
                      "ExpressionAttributeNames": {"#d": "domain"}}
            orphaned_rules = []
            while True:
                resp = table.scan(**params)
                for item in resp.get("Items", []):
                    tid = item.get("tenant_id", "")
                    if tid and tid != "default" and tid not in tenant_ids:
                        orphaned_rules.append(
                            f"{item.get('localpart', '*')}@{item.get('domain', '?')} (tenant: {tid[:8]}…)")
                if "LastEvaluatedKey" not in resp:
                    break
                params["ExclusiveStartKey"] = resp["LastEvaluatedKey"]
            if orphaned_rules:
                issues.append(("Rules with missing tenant", orphaned_rules))

        # Check domains for orphaned tenant_ids.
        domains_name = os.environ.get("DOMAINS_TABLE", "")
        if domains_name and tenants_name:
            table = ddb.Table(domains_name)
            params = {"ProjectionExpression": "tenant_id, #d",
                      "ExpressionAttributeNames": {"#d": "domain"}}
            orphaned_domains = []
            while True:
                resp = table.scan(**params)
                for item in resp.get("Items", []):
                    tid = item.get("tenant_id", "")
                    if tid and tid != "default" and tid not in tenant_ids:
                        orphaned_domains.append(
                            f"{item.get('domain', '?')} (tenant: {tid[:8]}…)")
                if "LastEvaluatedKey" not in resp:
                    break
                params["ExclusiveStartKey"] = resp["LastEvaluatedKey"]
            if orphaned_domains:
                issues.append(("Domains with missing tenant", orphaned_domains))

        # Check users for orphaned tenant_ids.
        users_name = os.environ.get("USERS_TABLE", "")
        if users_name and tenants_name:
            table = ddb.Table(users_name)
            params = {"ProjectionExpression": "email, tenant_id"}
            orphaned_users = []
            while True:
                resp = table.scan(**params)
                for item in resp.get("Items", []):
                    tid = item.get("tenant_id", "")
                    if tid and tid != "default" and tid not in tenant_ids:
                        orphaned_users.append(
                            f"{item.get('email', '?')} (tenant: {tid[:8]}…)")
                if "LastEvaluatedKey" not in resp:
                    break
                params["ExclusiveStartKey"] = resp["LastEvaluatedKey"]
            if orphaned_users:
                issues.append(("Users with missing tenant", orphaned_users))

        # Check for tenants with no users.
        if tenants_name and users_name:
            user_table = ddb.Table(users_name)
            params = {"ProjectionExpression": "tenant_id"}
            user_tenant_ids = set()
            while True:
                resp = user_table.scan(**params)
                for item in resp.get("Items", []):
                    user_tenant_ids.add(item.get("tenant_id", ""))
                if "LastEvaluatedKey" not in resp:
                    break
                params["ExclusiveStartKey"] = resp["LastEvaluatedKey"]
            lonely_tenants = [
                tid for tid in tenant_ids
                if tid != "default" and tid not in user_tenant_ids
            ]
            if lonely_tenants:
                issues.append(("Tenants with no users",
                               [f"{tid[:8]}…" for tid in lonely_tenants]))

    except Exception:
        logger.warning("Failed to run integrity checks", exc_info=True)

    return issues


# ---------------------------------------------------------------------------
# HTML rendering
# ---------------------------------------------------------------------------

def _summary_card(title, value, color=CYAN):
    return (
        f'<td style="padding:16px;text-align:center;background:{SURFACE};'
        f'border-radius:10px;border:1px solid {BORDER};min-width:100px;">'
        f'<div style="font-size:28px;font-weight:700;color:{color};">{value}</div>'
        f'<div style="font-size:11px;color:{MUTED};text-transform:uppercase;'
        f'letter-spacing:0.5px;margin-top:6px;">{title}</div></td>'
    )


def _section(title, body):
    return (
        f'<div style="margin-bottom:24px;">'
        f'<h2 style="font-size:14px;color:{CYAN};border-bottom:1px solid {BORDER};'
        f'padding-bottom:6px;margin-bottom:12px;text-transform:uppercase;'
        f'letter-spacing:0.1em;font-weight:600;">{title}</h2>{body}</div>'
    )


def _bar_chart(data, max_width=20):
    if not data:
        return f'<p style="color:{MUTED};">No data</p>'
    peak = max(data.values()) or 1
    rows = []
    for label, value in data.items():
        bar_len = int((value / peak) * max_width)
        bar = "\u2588" * max(bar_len, 1) if value > 0 else ""
        rows.append(
            f'<tr><td style="padding:3px 10px 3px 0;white-space:nowrap;'
            f'font-size:13px;color:{TEXT};">{label}</td>'
            f'<td style="padding:3px 0;font-family:monospace;color:{CYAN};">'
            f'{bar}</td>'
            f'<td style="padding:3px 0 3px 8px;font-size:13px;color:{MUTED};">'
            f'{int(value):,}</td></tr>'
        )
    return f'<table style="border-collapse:collapse;">{"".join(rows)}</table>'


def _table_html(headers, rows):
    hdr = "".join(
        f'<th style="padding:8px 12px;text-align:left;background:{SURFACE};'
        f'color:{CYAN};font-size:11px;text-transform:uppercase;'
        f'letter-spacing:0.05em;border-bottom:1px solid {BORDER};">{h}</th>'
        for h in headers
    )
    body_rows = []
    for i, row in enumerate(rows):
        bg = SURFACE if i % 2 == 0 else NAVY
        cells = "".join(
            f'<td style="padding:6px 12px;font-size:13px;color:{TEXT};'
            f'border-bottom:1px solid {BORDER};">{c}</td>'
            for c in row
        )
        body_rows.append(f'<tr style="background:{bg};">{cells}</tr>')
    return (
        f'<table style="width:100%;border-collapse:collapse;border-radius:8px;'
        f'overflow:hidden;border:1px solid {BORDER};">'
        f'<thead><tr>{hdr}</tr></thead>'
        f'<tbody>{"".join(body_rows)}</tbody></table>'
    )


def _render_integrity(issues):
    if not issues:
        return _section("Data Integrity", f'<p style="color:{GREEN};">All checks passed</p>')
    rows = []
    for category, items in issues:
        detail = ", ".join(items[:10])
        if len(items) > 10:
            detail += f" … and {len(items) - 10} more"
        rows.append([category, f"{len(items)}", detail])
    body = _table_html(["Check", "Count", "Details"], rows)
    warning = (
        f'<p style="color:{RED};font-weight:600;margin-bottom:12px;">'
        f'⚠ {sum(len(items) for _, items in issues)} integrity issue(s) detected</p>'
    )
    return _section("Data Integrity", warning + body)


def _render_summary(*, cw, counts, integrity):
    """Build a plain-English summary of things that need attention."""
    YELLOW = "#f0c040"
    alerts = []

    # Server errors (5xx + Lambda errors) are always important.
    server_errors = int(cw.get("Errors_Forwarder", 0)) + int(cw.get("Errors_API", 0)) + int(cw.get("5xx", 0))
    if server_errors:
        alerts.append(f'<span style="color:{RED};">{server_errors:,} server error(s)</span> '
                       f'(Lambda crashes or 5xx responses)')

    # SES bounces / complaints need action.
    bounces = int(cw.get("SES_Bounce", 0))
    complaints = int(cw.get("SES_Complaint", 0))
    if bounces:
        alerts.append(f'<span style="color:{RED};">{bounces:,} email bounce(s)</span> '
                       f'&mdash; check destination addresses')
    if complaints:
        alerts.append(f'<span style="color:{RED};">{complaints:,} spam complaint(s)</span> '
                       f'&mdash; review forwarding rules')

    # Data integrity issues.
    integrity_count = sum(len(items) for _, items in integrity)
    if integrity_count:
        alerts.append(f'<span style="color:{RED};">{integrity_count} data integrity issue(s)</span> '
                       f'&mdash; see details below')

    # Empty platform (no users or no rules) is a warning, not an error.
    if counts.get("USERS_TABLE", 0) == 0:
        alerts.append(f'<span style="color:{YELLOW};">No users</span> &mdash; has anyone signed up?')
    if counts.get("RULES_TABLE", 0) == 0:
        alerts.append(f'<span style="color:{YELLOW};">No forwarding rules</span> &mdash; no email will be forwarded')

    if not alerts:
        return (
            f'<div style="padding:16px;background:rgba(40,200,64,0.08);border:1px solid {GREEN};'
            f'border-radius:8px;margin-bottom:20px;">'
            f'<p style="margin:0;color:{GREEN};font-weight:600;font-size:15px;">'
            f'All clear &mdash; nothing needs attention.</p></div>'
        )

    items_html = "".join(f'<li style="margin-bottom:6px;">{a}</li>' for a in alerts)
    return (
        f'<div style="padding:16px;background:rgba(255,68,102,0.06);border:1px solid {RED};'
        f'border-radius:8px;margin-bottom:20px;">'
        f'<p style="margin:0 0 10px;color:{RED};font-weight:600;font-size:15px;">'
        f'Needs attention</p>'
        f'<ul style="margin:0;padding-left:20px;color:{TEXT};font-size:13px;">'
        f'{items_html}</ul></div>'
    )


def _render_email(*, cw, counts, plans, integrity, env, report_date, region):
    emails_forwarded = int(cw.get("Invocations_Forwarder", 0))
    server_errors = int(cw.get("Errors_Forwarder", 0)) + int(cw.get("Errors_API", 0)) + int(cw.get("5xx", 0))
    error_color = RED if server_errors > 0 else GREEN

    cards = (
        _summary_card("Emails Forwarded", f"{emails_forwarded:,}")
        + _summary_card("API Requests", f"{int(cw.get('Invocations_API', 0)):,}")
        + _summary_card("Users", f"{counts.get('USERS_TABLE', 0):,}")
        + _summary_card("Server Errors", f"{server_errors:,}", color=error_color)
    )

    summary_html = _render_summary(cw=cw, counts=counts, integrity=integrity)

    # SES
    ses_data = {
        "Sent": int(cw.get("SES_Send", 0)),
        "Bounced": int(cw.get("SES_Bounce", 0)),
        "Complaints": int(cw.get("SES_Complaint", 0)),
    }
    ses_body = _bar_chart(ses_data)

    # API traffic breakdown — 4xx is informational, not an error
    api_data = {
        "Successful": max(int(cw.get("Invocations_API", 0)) - int(cw.get("4xx", 0)) - int(cw.get("5xx", 0)) - int(cw.get("Errors_API", 0)), 0),
        "Client errors (4xx)": int(cw.get("4xx", 0)),
        "Server errors (5xx)": int(cw.get("5xx", 0)),
        "Lambda errors": int(cw.get("Errors_API", 0)),
    }
    api_body = _bar_chart(api_data)

    # Forwarder
    fwd_data = {
        "Forwarded": max(int(cw.get("Invocations_Forwarder", 0)) - int(cw.get("Errors_Forwarder", 0)), 0),
        "Errors": int(cw.get("Errors_Forwarder", 0)),
    }
    fwd_body = _bar_chart(fwd_data)

    # Table counts
    count_rows = [
        ["Rules", f"{counts.get('RULES_TABLE', 0):,}"],
        ["Domains", f"{counts.get('DOMAINS_TABLE', 0):,}"],
        ["Users", f"{counts.get('USERS_TABLE', 0):,}"],
        ["Tenants", f"{counts.get('TENANTS_TABLE', 0):,}"],
    ]
    counts_body = _table_html(["Resource", "Count"], count_rows)

    # Plan distribution
    plan_rows = [[plan.capitalize(), str(count)] for plan, count in plans.items()]
    plans_body = (
        _table_html(["Plan", "Users"], plan_rows)
        if plan_rows else f'<p style="color:{MUTED};">No users</p>'
    )

    now_ts = datetime.now(tz=timezone.utc).strftime("%Y-%m-%d %H:%M UTC")

    return f"""\
<!DOCTYPE html>
<html lang="en">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width"></head>
<body style="margin:0;padding:0;background:#000;font-family:-apple-system,BlinkMacSystemFont,
'Segoe UI',Roboto,Helvetica,Arial,sans-serif;">
<div style="max-width:640px;margin:0 auto;padding:20px;">

  <div style="background:linear-gradient(135deg,rgba(0,212,255,0.08),rgba(0,85,255,0.04));
    border-radius:12px 12px 0 0;padding:28px 24px;text-align:center;
    border:1px solid {BORDER};border-bottom:none;">
    <h1 style="margin:0;color:#fff;font-size:20px;font-weight:700;">
      Delivery Machine Daily Report
    </h1>
    <p style="margin:6px 0 0;color:{MUTED};font-size:13px;">
      {report_date} &middot; {env.upper()} &middot; {region}
    </p>
  </div>

  <div style="background:{NAVY};padding:24px;border:1px solid {BORDER};border-top:none;">

    {summary_html}

    <table style="width:100%;border-collapse:separate;border-spacing:8px;" role="presentation">
      <tr>{cards}</tr>
    </table>

    <div style="height:20px;"></div>

    {_section("Email Delivery (24h)", ses_body)}
    {_section("Forwarder (24h)", fwd_body)}
    {_section("API Traffic (24h)", api_body)}
    {_section("Resource Counts", counts_body)}
    {_section("Plan Distribution", plans_body)}
    {_render_integrity(integrity)}

  </div>

  <div style="background:{SURFACE};border-radius:0 0 12px 12px;padding:16px 24px;
    text-align:center;border:1px solid {BORDER};border-top:none;">
    <p style="margin:0;color:{MUTED};font-size:11px;">
      Generated {now_ts}
    </p>
  </div>

</div>
</body>
</html>"""


# ---------------------------------------------------------------------------
# Lambda entry point
# ---------------------------------------------------------------------------

def handler(event, context):
    """Scheduled handler: collect metrics and send daily status email."""
    env = os.environ.get("ENVIRONMENT", "production")
    recipient = os.environ.get("REPORT_RECIPIENT", "craig@barkingiguana.com")
    sender = os.environ.get("SENDER_EMAIL", os.environ.get("FORWARD_FROM", ""))
    region = os.environ.get("AWS_REGION", "us-east-1")
    report_date = datetime.now(tz=timezone.utc).strftime("%A %d %B %Y")

    logger.info("Generating daily status report for %s", recipient)

    ddb = boto3.resource("dynamodb")
    cw = boto3.client("cloudwatch")

    cw_metrics = _collect_cloudwatch_metrics(cw)
    counts = _collect_table_counts(ddb)
    plans = _collect_user_plans(ddb)
    integrity = _collect_integrity_issues(ddb)

    html = _render_email(
        cw=cw_metrics,
        counts=counts,
        plans=plans,
        integrity=integrity,
        env=env,
        report_date=report_date,
        region=region,
    )

    # Summarise status in subject line so it's visible without opening.
    server_errors = int(cw_metrics.get("Errors_Forwarder", 0)) + int(cw_metrics.get("Errors_API", 0)) + int(cw_metrics.get("5xx", 0))
    bounces = int(cw_metrics.get("SES_Bounce", 0))
    complaints = int(cw_metrics.get("SES_Complaint", 0))
    integrity_count = sum(len(items) for _, items in integrity)
    has_issues = server_errors or bounces or complaints or integrity_count
    status_emoji = "\u26a0\ufe0f" if has_issues else "\u2705"
    subject = f"{status_emoji} Delivery Machine \u2014 {report_date}"

    ses = boto3.client("ses")
    ses.send_email(
        Source=sender,
        Destination={"ToAddresses": [recipient]},
        Message={
            "Subject": {"Data": subject, "Charset": "UTF-8"},
            "Body": {"Html": {"Data": html, "Charset": "UTF-8"}},
        },
    )

    stats = {
        "report_date": report_date,
        "recipient": recipient,
        "emails_forwarded": int(cw_metrics.get("Invocations_Forwarder", 0)),
        "errors": int(cw_metrics.get("Errors_Forwarder", 0)) + int(cw_metrics.get("Errors_API", 0)),
    }
    logger.info("Daily status report sent: %s", json.dumps(stats))
    return stats
