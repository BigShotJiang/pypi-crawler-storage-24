"""
Delivery Machine — core forwarding Lambda.

Triggered by S3 when SES deposits an incoming email.
Looks up routing rules in DynamoDB, checks per-tenant quota, then forwards via SES.

Builds a new envelope with From: Delivery Machine <forward@...>, Reply-To: original
sender, and the original message (with key headers) quoted in the body.
ARC (Authenticated Received Chain) headers are added to preserve authentication
chain-of-custody for downstream receivers.
"""
import boto3
import email
import email.utils
import json
import logging
import os
from datetime import datetime, timezone
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

try:
    import dkim
except ImportError:
    dkim = None

logger = logging.getLogger()
logger.setLevel(logging.INFO)

s3 = boto3.client("s3")
ses = boto3.client("ses")
dynamodb = boto3.resource("dynamodb")
ssm = boto3.client("ssm")

RULES_TABLE = os.environ["RULES_TABLE"]
EMAIL_BUCKET = os.environ["EMAIL_BUCKET"]
FORWARD_FROM = os.environ["FORWARD_FROM"]
TENANTS_TABLE = os.environ.get("TENANTS_TABLE", "")  # optional; absent = no quota
VERIFICATIONS_TABLE = os.environ.get("VERIFICATIONS_TABLE", "")
ARC_PRIVATE_KEY_PARAM = os.environ.get("ARC_PRIVATE_KEY_PARAM", "")
ARC_SELECTOR = os.environ.get("ARC_SELECTOR", "arc")
ARC_DOMAIN = os.environ.get("ARC_DOMAIN", "")
SES_CONFIGURATION_SET = os.environ.get("SES_CONFIGURATION_SET", "")

# Cache the ARC private key for the lifetime of the Lambda instance.
_arc_private_key_cache = None


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def handler(event, context):
    for record in event.get("Records", []):
        try:
            process_record(record)
        except Exception:
            logger.exception("Error processing record: %s", json.dumps(record))


def process_record(record):
    bucket = record["s3"]["bucket"]["name"]
    key = record["s3"]["object"]["key"]
    logger.info("Processing s3://%s/%s", bucket, key)

    raw_email = s3.get_object(Bucket=bucket, Key=key)["Body"].read()
    msg = email.message_from_bytes(raw_email)

    recipients = extract_recipients(msg)
    logger.info("Recipients found in headers: %s", recipients)

    for recipient in recipients:
        try:
            destinations, tenant_id = lookup_destinations(recipient)
            if not destinations:
                logger.info("No active rule for %s — dropping", recipient)
                continue

            allowed, reason = check_quota(tenant_id)
            if not allowed:
                logger.warning(
                    "Quota exceeded for tenant=%s recipient=%s: %s",
                    tenant_id, recipient, reason,
                )
                continue

            for dest in destinations:
                try:
                    address = dest["address"]
                    # Per-rule-destination verification (inline); fall back to
                    # legacy table check for rules that predate the migration.
                    verified = dest.get("verified")
                    if verified is None:
                        verified = is_destination_verified(address)
                    if not verified:
                        logger.warning(
                            "Destination %s is not verified — skipping forward for %s",
                            address, recipient,
                        )
                        continue
                    forward(msg, raw_email, recipient, dest)
                except Exception:
                    logger.exception("Error forwarding %s to %s", recipient, dest.get("address"))
        except Exception:
            logger.exception("Error handling recipient %s", recipient)


# ---------------------------------------------------------------------------
# Recipient extraction
# ---------------------------------------------------------------------------

def extract_recipients(msg):
    """Collect all To/CC/Delivered-To addresses from the email headers."""
    recipients = set()
    for header in ("To", "CC", "X-Original-To", "Delivered-To"):
        for value in msg.get_all(header, []):
            for _name, addr in email.utils.getaddresses([value]):
                if addr and "@" in addr:
                    recipients.add(addr.lower().strip())
    return recipients


# ---------------------------------------------------------------------------
# Rule lookup
# ---------------------------------------------------------------------------

def lookup_destinations(recipient):
    """
    Return (destinations, tenant_id) for the recipient, or (None, None).

    destinations is a list of dicts: [{"address": str, "role": str, "unsubscribe_token": str}, ...]
    Checks exact match first, then catch-all (*).
    Respects `enabled` and `expires_at` on each rule.
    """
    if "@" not in recipient:
        return None, None

    localpart, domain = recipient.rsplit("@", 1)
    table = dynamodb.Table(RULES_TABLE)
    now = int(datetime.now(timezone.utc).timestamp())

    for lp in (localpart, "*"):
        result = table.get_item(Key={"domain": domain, "localpart": lp})
        item = result.get("Item")
        if not item:
            continue
        if not item.get("enabled", True):
            continue
        if "expires_at" in item and int(item["expires_at"]) <= now:
            logger.info("Rule %s@%s has expired — skipping", lp, domain)
            continue

        # New format: destinations list
        if "destinations" in item:
            dests = item["destinations"]
            if not dests:
                continue
            _increment_receive_count(table, domain, lp)
            return dests, item.get("tenant_id", "default")

        # Legacy format: single destination string
        if "destination" in item:
            _increment_receive_count(table, domain, lp)
            return [{
                "address": item["destination"],
                "role": "to",
                "unsubscribe_token": "",
            }], item.get("tenant_id", "default")

    return None, None


def _increment_receive_count(table, domain, localpart):
    """Atomically increment the receive_count on a rule."""
    try:
        table.update_item(
            Key={"domain": domain, "localpart": localpart},
            UpdateExpression="ADD receive_count :one",
            ExpressionAttributeValues={":one": 1},
        )
    except Exception:
        logger.exception("Failed to increment receive_count for %s@%s", localpart, domain)


# ---------------------------------------------------------------------------
# Quota enforcement
# ---------------------------------------------------------------------------

def check_quota(tenant_id):
    """
    Return (allowed: bool, reason: str).

    Atomically increments the tenant's monthly email counter before checking
    against their quota. The counter resets on the first email of a new month.

    Race note: month rollover uses read-then-write which has a small window for
    over-counting in high concurrency. For a personal/small-team service this is
    acceptable; swap for a DynamoDB transaction if strict enforcement is needed.
    """
    if not TENANTS_TABLE or not tenant_id or tenant_id == "default":
        return True, None

    table = dynamodb.Table(TENANTS_TABLE)
    current_month = datetime.now(timezone.utc).strftime("%Y-%m")

    result = table.get_item(Key={"tenant_id": tenant_id})
    tenant = result.get("Item")
    if not tenant:
        return True, None  # unknown tenant — allow and let ops investigate

    raw_quota = tenant.get("email_quota")
    if raw_quota is None:
        return True, None  # unlimited plan

    quota = int(raw_quota)
    stored_month = tenant.get("count_month", "")
    current_count = int(tenant.get("email_count", 0)) if stored_month == current_month else 0

    if current_count >= quota:
        return False, f"monthly quota of {quota} reached ({current_count} used)"

    # Increment — reset the counter if the month rolled over.
    if stored_month != current_month:
        table.update_item(
            Key={"tenant_id": tenant_id},
            UpdateExpression="SET email_count = :one, count_month = :month",
            ExpressionAttributeValues={":one": 1, ":month": current_month},
        )
    else:
        table.update_item(
            Key={"tenant_id": tenant_id},
            UpdateExpression="ADD email_count :one",
            ExpressionAttributeValues={":one": 1},
        )

    return True, None


# ---------------------------------------------------------------------------
# Destination verification check
# ---------------------------------------------------------------------------

def is_destination_verified(destination):
    """Check the verifications table to see if the destination is verified."""
    if not VERIFICATIONS_TABLE:
        return True  # if no verifications table configured, allow all

    table = dynamodb.Table(VERIFICATIONS_TABLE)
    result = table.get_item(Key={"destination": destination})
    item = result.get("Item")
    if not item:
        return False
    return bool(item.get("verified", False))


# ---------------------------------------------------------------------------
# Forwarding
# ---------------------------------------------------------------------------

def _get_text_body(msg):
    """Extract the plain-text body from a message (handles multipart)."""
    if msg.is_multipart():
        for part in msg.walk():
            ct = part.get_content_type()
            if ct == "text/plain" and part.get("Content-Disposition") != "attachment":
                payload = part.get_payload(decode=True)
                if payload:
                    charset = part.get_content_charset() or "utf-8"
                    return payload.decode(charset, errors="replace")
    else:
        payload = msg.get_payload(decode=True)
        if payload:
            charset = msg.get_content_charset() or "utf-8"
            return payload.decode(charset, errors="replace")
    return ""


def _get_html_body(msg):
    """Extract the HTML body from a message (handles multipart)."""
    if msg.is_multipart():
        for part in msg.walk():
            ct = part.get_content_type()
            if ct == "text/html" and part.get("Content-Disposition") != "attachment":
                payload = part.get_payload(decode=True)
                if payload:
                    charset = part.get_content_charset() or "utf-8"
                    return payload.decode(charset, errors="replace")
    return ""


API_BASE_URL = os.environ.get("API_BASE_URL", "")


# ---------------------------------------------------------------------------
# ARC signing
# ---------------------------------------------------------------------------

def _get_arc_private_key():
    """Fetch the ARC private key from SSM Parameter Store (cached per Lambda instance)."""
    global _arc_private_key_cache
    if _arc_private_key_cache is not None:
        return _arc_private_key_cache
    if not ARC_PRIVATE_KEY_PARAM:
        return None
    try:
        resp = ssm.get_parameter(Name=ARC_PRIVATE_KEY_PARAM, WithDecryption=True)
        _arc_private_key_cache = resp["Parameter"]["Value"].encode()
        return _arc_private_key_cache
    except Exception:
        logger.exception("Failed to fetch ARC private key — forwarding without ARC")
        return None


def _extract_auth_results(msg):
    """
    Extract Authentication-Results from the original inbound email.

    SES adds this header when it receives the message. We include it in our
    ARC-Authentication-Results to document the inbound authentication state.
    """
    # Try the standard header first.
    auth_results = msg.get("Authentication-Results", "")
    if auth_results:
        return auth_results

    # Fallback: build a minimal auth-results from what SES provides.
    parts = []
    spf = msg.get("Received-SPF", "")
    if spf:
        verdict = spf.split()[0].lower() if spf.split() else "none"
        parts.append(f"spf={verdict}")

    dkim_result = msg.get("DKIM-Signature")
    if dkim_result:
        parts.append("dkim=pass")

    if not parts:
        parts.append("none")

    return f"deliverymachine.net; {'; '.join(parts)}"


def _arc_sign_message(message_bytes, original_msg):
    """
    Add ARC headers to the outgoing message.

    Returns the message bytes with ARC headers prepended, or the original
    bytes unchanged if ARC signing is unavailable or fails.
    """
    if dkim is None:
        logger.info("dkimpy not available — skipping ARC signing")
        return message_bytes

    private_key = _get_arc_private_key()
    if not private_key:
        return message_bytes

    if not ARC_DOMAIN:
        return message_bytes

    auth_results = _extract_auth_results(original_msg)

    try:
        arc_headers = dkim.arc_sign(
            message_bytes,
            ARC_SELECTOR.encode(),
            ARC_DOMAIN.encode(),
            private_key,
            ARC_DOMAIN.encode(),
            auth_results=auth_results.encode(),
        )
        if arc_headers:
            logger.info("ARC headers added (selector=%s, domain=%s)", ARC_SELECTOR, ARC_DOMAIN)
            return arc_headers + message_bytes
    except Exception:
        logger.exception("ARC signing failed — forwarding without ARC headers")

    return message_bytes


def forward(msg, raw_email, original_recipient, dest_info):
    """
    Build a new email wrapping the original content, sent from Delivery Machine.

    dest_info is a dict: {"address": str, "role": str, "unsubscribe_token": str}
    """
    destination = dest_info if isinstance(dest_info, str) else dest_info["address"]
    role = "to" if isinstance(dest_info, str) else dest_info.get("role", "to")
    unsubscribe_token = "" if isinstance(dest_info, str) else dest_info.get("unsubscribe_token", "")

    logger.info("Forwarding %s → %s (role=%s)", original_recipient, destination, role)

    original_from = msg.get("From", "unknown sender")
    original_name, original_addr = email.utils.parseaddr(original_from)
    original_to = msg.get("To", original_recipient)
    original_date = msg.get("Date", "unknown date")
    original_subject = msg.get("Subject", "(no subject)")

    # Header block shown above the original body.
    header_block_text = (
        f"From: {original_from}\n"
        f"Date: {original_date}\n"
        f"To: {original_to}\n"
        f"Subject: {original_subject}\n"
    )
    header_block_html = (
        f"<strong>From:</strong> {original_from}<br>"
        f"<strong>Date:</strong> {original_date}<br>"
        f"<strong>To:</strong> {original_to}<br>"
        f"<strong>Subject:</strong> {original_subject}<br>"
    )

    # Build unsubscribe link if token is available
    unsubscribe_url = ""
    if unsubscribe_token and API_BASE_URL:
        unsubscribe_url = f"{API_BASE_URL}/unsubscribe?token={unsubscribe_token}"

    footer_text = (
        "\n---\n"
        f"This email was sent to {original_recipient} and forwarded to {destination} by Delivery Machine.\n"
        "Manage your forwarding rules at https://deliverymachine.net\n"
    )
    if unsubscribe_url:
        footer_text += f"Stop receiving these forwards: {unsubscribe_url}\n"

    footer_html = (
        '<hr style="border:none;border-top:1px solid #ccc;margin:16px 0">'
        f'<p style="color:#888;font-size:12px">'
        f'This email was sent to {original_recipient} and forwarded to {destination} by '
        f'<a href="https://deliverymachine.net">Delivery Machine</a>.'
    )
    if unsubscribe_url:
        footer_html += (
            f' <a href="{unsubscribe_url}" style="color:#888">'
            f'Stop receiving these forwards</a>.'
        )
    footer_html += '</p>'

    text_body = _get_text_body(msg)
    html_body = _get_html_body(msg)

    new_msg = MIMEMultipart("alternative")
    via_name = f"{original_name} via Delivery Machine" if original_name else "Delivery Machine"
    new_msg["From"] = email.utils.formataddr((via_name, FORWARD_FROM))
    new_msg["To"] = destination
    new_msg["Subject"] = original_subject
    new_msg["Reply-To"] = original_from
    new_msg["X-Forwarded-To"] = original_recipient
    new_msg["X-Original-From"] = original_from

    # List-Unsubscribe header for email client integration
    if unsubscribe_url:
        new_msg["List-Unsubscribe"] = f"<{unsubscribe_url}>"
        new_msg["List-Unsubscribe-Post"] = "List-Unsubscribe=One-Click"

    # Preserve threading headers from the original.
    for hdr in ("Message-ID", "In-Reply-To", "References"):
        val = msg.get(hdr)
        if val:
            new_msg[hdr] = val

    # Plain text version.
    plain = f"{header_block_text}\n{text_body}{footer_text}"
    new_msg.attach(MIMEText(plain, "plain", "utf-8"))

    # HTML version (if original had HTML).
    if html_body:
        html = (
            f'<div style="background:#f5f5f5;padding:12px;border-radius:6px;'
            f'margin-bottom:16px;font-size:13px;color:#555">'
            f'{header_block_html}</div>'
            f'{html_body}'
            f'{footer_html}'
        )
        new_msg.attach(MIMEText(html, "html", "utf-8"))

    message_bytes = _arc_sign_message(new_msg.as_bytes(), msg)

    send_kwargs = {
        "Source": FORWARD_FROM,
        "Destinations": [destination],
        "RawMessage": {"Data": message_bytes},
    }
    if SES_CONFIGURATION_SET:
        send_kwargs["ConfigurationSetName"] = SES_CONFIGURATION_SET
    ses.send_raw_email(**send_kwargs)
    logger.info("Forwarded successfully to %s", destination)
