"""Tests for the forwarder Lambda handler."""
import email
import email.utils
import os
import sys
import unittest
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from unittest.mock import MagicMock, patch

# Set required env vars before importing handler.
os.environ.setdefault("RULES_TABLE", "test-rules")
os.environ.setdefault("EMAIL_BUCKET", "test-bucket")
os.environ.setdefault("FORWARD_FROM", "forward@deliverymachine.net")
os.environ.setdefault("VERIFICATIONS_TABLE", "test-verifications")
os.environ.setdefault("API_BASE_URL", "https://test.execute-api.us-east-1.amazonaws.com/prod/v1")
os.environ.setdefault("ARC_PRIVATE_KEY_PARAM", "")
os.environ.setdefault("ARC_SELECTOR", "arc")
os.environ.setdefault("ARC_DOMAIN", "deliverymachine.net")

# Stub boto3 before handler imports it.
sys.modules.setdefault("boto3", MagicMock())

from handler import (
    _get_html_body, _get_text_body, _extract_auth_results, _arc_sign_message,
    extract_recipients, forward, is_destination_verified, lookup_destinations,
)


def _make_plain_email(
    from_addr="Alice Smith <alice@example.com>",
    to_addr="hello@thearecorder.com",
    subject="Test subject",
    body="Hello, this is the body.",
    date="Mon, 10 Mar 2026 12:00:00 +0000",
    message_id="<abc123@example.com>",
    in_reply_to=None,
    references=None,
):
    """Build a simple plain-text email as bytes."""
    msg = MIMEText(body, "plain", "utf-8")
    msg["From"] = from_addr
    msg["To"] = to_addr
    msg["Subject"] = subject
    msg["Date"] = date
    msg["Message-ID"] = message_id
    if in_reply_to:
        msg["In-Reply-To"] = in_reply_to
    if references:
        msg["References"] = references
    return msg.as_bytes(), email.message_from_bytes(msg.as_bytes())


def _make_html_email(
    from_addr="Bob Jones <bob@example.com>",
    to_addr="hello@thearecorder.com",
    subject="HTML test",
    text_body="Plain version.",
    html_body="<p>Rich <b>HTML</b> version.</p>",
):
    """Build a multipart/alternative email with both plain and HTML parts."""
    msg = MIMEMultipart("alternative")
    msg["From"] = from_addr
    msg["To"] = to_addr
    msg["Subject"] = subject
    msg["Date"] = "Mon, 10 Mar 2026 13:00:00 +0000"
    msg["Message-ID"] = "<html456@example.com>"
    msg.attach(MIMEText(text_body, "plain", "utf-8"))
    msg.attach(MIMEText(html_body, "html", "utf-8"))
    return msg.as_bytes(), email.message_from_bytes(msg.as_bytes())


class TestExtractRecipients(unittest.TestCase):
    def test_extracts_to(self):
        _, msg = _make_plain_email(to_addr="hello@thearecorder.com")
        self.assertEqual(extract_recipients(msg), {"hello@thearecorder.com"})

    def test_extracts_cc(self):
        _, msg = _make_plain_email()
        msg["CC"] = "other@example.com"
        result = extract_recipients(msg)
        self.assertIn("other@example.com", result)

    def test_lowercases_addresses(self):
        _, msg = _make_plain_email(to_addr="Hello@TheArecorder.com")
        self.assertEqual(extract_recipients(msg), {"hello@thearecorder.com"})

    def test_handles_multiple_to(self):
        _, msg = _make_plain_email(to_addr="a@example.com, b@example.com")
        result = extract_recipients(msg)
        self.assertEqual(result, {"a@example.com", "b@example.com"})


class TestGetTextBody(unittest.TestCase):
    def test_plain_email(self):
        _, msg = _make_plain_email(body="Hello world")
        self.assertEqual(_get_text_body(msg), "Hello world")

    def test_multipart_email(self):
        _, msg = _make_html_email(text_body="Plain text here")
        self.assertEqual(_get_text_body(msg), "Plain text here")


class TestGetHtmlBody(unittest.TestCase):
    def test_plain_email_returns_empty(self):
        _, msg = _make_plain_email()
        self.assertEqual(_get_html_body(msg), "")

    def test_multipart_email(self):
        _, msg = _make_html_email(html_body="<p>Hello</p>")
        self.assertEqual(_get_html_body(msg), "<p>Hello</p>")


class TestForward(unittest.TestCase):
    """Test that forward() builds correct email envelopes."""

    def _make_dest(self, address="craig@barkingiguana.com", role="to", token="test-unsub-token"):
        return {"address": address, "role": role, "unsubscribe_token": token}

    def _call_forward(self, raw_email, msg, recipient="hello@thearecorder.com",
                      destination="craig@barkingiguana.com", dest_info=None):
        """Call forward() with a mock SES client and return the parsed sent message."""
        if dest_info is None:
            dest_info = self._make_dest(address=destination)
        mock_ses = MagicMock()
        with patch("handler.ses", mock_ses):
            forward(msg, raw_email, recipient, dest_info)

        mock_ses.send_raw_email.assert_called_once()
        call_kwargs = mock_ses.send_raw_email.call_args
        sent_data = call_kwargs[1]["RawMessage"]["Data"] if call_kwargs[1] else call_kwargs[0][2]["Data"]
        return email.message_from_bytes(sent_data), call_kwargs

    def test_from_includes_sender_name_via(self):
        raw, msg = _make_plain_email(from_addr="Alice Smith <alice@example.com>")
        sent, _ = self._call_forward(raw, msg)
        name, addr = email.utils.parseaddr(sent["From"])
        self.assertEqual(name, "Alice Smith via Delivery Machine")
        self.assertEqual(addr, "forward@deliverymachine.net")

    def test_from_fallback_when_no_name(self):
        raw, msg = _make_plain_email(from_addr="alice@example.com")
        sent, _ = self._call_forward(raw, msg)
        name, addr = email.utils.parseaddr(sent["From"])
        self.assertEqual(name, "Delivery Machine")
        self.assertEqual(addr, "forward@deliverymachine.net")

    def test_reply_to_is_original_sender(self):
        raw, msg = _make_plain_email(from_addr="Alice <alice@example.com>")
        sent, _ = self._call_forward(raw, msg)
        self.assertEqual(sent["Reply-To"], "Alice <alice@example.com>")

    def test_subject_preserved(self):
        raw, msg = _make_plain_email(subject="Important stuff")
        sent, _ = self._call_forward(raw, msg)
        self.assertEqual(sent["Subject"], "Important stuff")

    def test_to_is_destination(self):
        raw, msg = _make_plain_email()
        sent, _ = self._call_forward(raw, msg, destination="dest@example.com")
        self.assertEqual(sent["To"], "dest@example.com")

    def test_ses_destinations(self):
        raw, msg = _make_plain_email()
        _, call_kwargs = self._call_forward(raw, msg, destination="dest@example.com")
        kwargs = call_kwargs[1] if call_kwargs[1] else {}
        self.assertEqual(kwargs.get("Destinations"), ["dest@example.com"])

    def test_ses_source(self):
        raw, msg = _make_plain_email()
        _, call_kwargs = self._call_forward(raw, msg)
        kwargs = call_kwargs[1] if call_kwargs[1] else {}
        self.assertEqual(kwargs.get("Source"), "forward@deliverymachine.net")

    def test_x_forwarded_to_header(self):
        raw, msg = _make_plain_email()
        sent, _ = self._call_forward(raw, msg, recipient="hello@thearecorder.com")
        self.assertEqual(sent["X-Forwarded-To"], "hello@thearecorder.com")

    def test_x_original_from_header(self):
        raw, msg = _make_plain_email(from_addr="Alice <alice@example.com>")
        sent, _ = self._call_forward(raw, msg)
        self.assertEqual(sent["X-Original-From"], "Alice <alice@example.com>")

    def test_threading_headers_preserved(self):
        raw, msg = _make_plain_email(
            message_id="<msg1@example.com>",
            in_reply_to="<msg0@example.com>",
            references="<msg0@example.com>",
        )
        sent, _ = self._call_forward(raw, msg)
        self.assertEqual(sent["Message-ID"], "<msg1@example.com>")
        self.assertEqual(sent["In-Reply-To"], "<msg0@example.com>")
        self.assertEqual(sent["References"], "<msg0@example.com>")

    def test_body_contains_original_headers(self):
        raw, msg = _make_plain_email(
            from_addr="Alice <alice@example.com>",
            subject="Test subject",
        )
        sent, _ = self._call_forward(raw, msg)
        # Get the plain text part.
        if sent.is_multipart():
            text_part = sent.get_payload(0).get_payload(decode=True).decode()
        else:
            text_part = sent.get_payload(decode=True).decode()
        self.assertIn("From: Alice <alice@example.com>", text_part)
        self.assertIn("Subject: Test subject", text_part)

    def test_body_contains_original_text(self):
        raw, msg = _make_plain_email(body="Hello, this is the body.")
        sent, _ = self._call_forward(raw, msg)
        if sent.is_multipart():
            text_part = sent.get_payload(0).get_payload(decode=True).decode()
        else:
            text_part = sent.get_payload(decode=True).decode()
        self.assertIn("Hello, this is the body.", text_part)

    def test_footer_present(self):
        raw, msg = _make_plain_email()
        sent, _ = self._call_forward(raw, msg, recipient="hello@thearecorder.com")
        if sent.is_multipart():
            text_part = sent.get_payload(0).get_payload(decode=True).decode()
        else:
            text_part = sent.get_payload(decode=True).decode()
        self.assertIn("forwarded to craig@barkingiguana.com by Delivery Machine", text_part)
        self.assertIn("hello@thearecorder.com", text_part)
        self.assertIn("deliverymachine.net", text_part)

    def test_footer_contains_unsubscribe_link(self):
        raw, msg = _make_plain_email()
        sent, _ = self._call_forward(raw, msg, dest_info=self._make_dest(token="abc123"))
        if sent.is_multipart():
            text_part = sent.get_payload(0).get_payload(decode=True).decode()
        else:
            text_part = sent.get_payload(decode=True).decode()
        self.assertIn("unsubscribe?token=abc123", text_part)

    def test_list_unsubscribe_header(self):
        raw, msg = _make_plain_email()
        sent, _ = self._call_forward(raw, msg, dest_info=self._make_dest(token="abc123"))
        self.assertIn("unsubscribe?token=abc123", sent["List-Unsubscribe"])
        self.assertEqual(sent["List-Unsubscribe-Post"], "List-Unsubscribe=One-Click")

    def test_no_unsubscribe_when_no_token(self):
        raw, msg = _make_plain_email()
        dest = self._make_dest(token="")
        sent, _ = self._call_forward(raw, msg, dest_info=dest)
        self.assertIsNone(sent.get("List-Unsubscribe"))

    def test_html_email_has_both_parts(self):
        raw, msg = _make_html_email()
        sent, _ = self._call_forward(raw, msg)
        self.assertTrue(sent.is_multipart())
        parts = sent.get_payload()
        content_types = [p.get_content_type() for p in parts]
        self.assertIn("text/plain", content_types)
        self.assertIn("text/html", content_types)

    def test_html_part_contains_original_html(self):
        raw, msg = _make_html_email(html_body="<p>Rich <b>HTML</b> version.</p>")
        sent, _ = self._call_forward(raw, msg)
        html_parts = [p for p in sent.get_payload() if p.get_content_type() == "text/html"]
        html_content = html_parts[0].get_payload(decode=True).decode()
        self.assertIn("<p>Rich <b>HTML</b> version.</p>", html_content)

    def test_html_part_contains_header_block(self):
        raw, msg = _make_html_email(from_addr="Bob <bob@example.com>")
        sent, _ = self._call_forward(raw, msg)
        html_parts = [p for p in sent.get_payload() if p.get_content_type() == "text/html"]
        html_content = html_parts[0].get_payload(decode=True).decode()
        self.assertIn("bob@example.com", html_content)
        self.assertIn("<strong>From:</strong>", html_content)

    def test_html_part_contains_footer(self):
        raw, msg = _make_html_email()
        sent, _ = self._call_forward(raw, msg, recipient="hello@thearecorder.com")
        html_parts = [p for p in sent.get_payload() if p.get_content_type() == "text/html"]
        html_content = html_parts[0].get_payload(decode=True).decode()
        self.assertIn("Delivery Machine", html_content)
        self.assertIn("hello@thearecorder.com", html_content)

    def test_plain_only_email_no_html_part(self):
        raw, msg = _make_plain_email()
        sent, _ = self._call_forward(raw, msg)
        parts = sent.get_payload()
        content_types = [p.get_content_type() for p in parts]
        self.assertNotIn("text/html", content_types)

    def test_no_dkim_or_return_path(self):
        """Ensure stale DKIM/Return-Path headers are not in the sent message."""
        raw, msg = _make_plain_email()
        sent, _ = self._call_forward(raw, msg)
        self.assertIsNone(sent.get("DKIM-Signature"))
        self.assertIsNone(sent.get("Return-Path"))


class TestIsDestinationVerified(unittest.TestCase):
    """Test the destination verification check (legacy table fallback)."""

    def test_verified_destination_returns_true(self):
        mock_table = MagicMock()
        mock_table.get_item.return_value = {
            "Item": {"destination": "user@example.com", "verified": True}
        }
        mock_dynamodb = MagicMock()
        mock_dynamodb.Table.return_value = mock_table

        with patch("handler.dynamodb", mock_dynamodb):
            result = is_destination_verified("user@example.com")

        self.assertTrue(result)
        mock_dynamodb.Table.assert_called_with("test-verifications")
        mock_table.get_item.assert_called_once_with(Key={"destination": "user@example.com"})

    def test_unverified_destination_returns_false(self):
        mock_table = MagicMock()
        mock_table.get_item.return_value = {
            "Item": {"destination": "user@example.com", "verified": False}
        }
        mock_dynamodb = MagicMock()
        mock_dynamodb.Table.return_value = mock_table

        with patch("handler.dynamodb", mock_dynamodb):
            result = is_destination_verified("user@example.com")

        self.assertFalse(result)

    def test_missing_destination_returns_false(self):
        mock_table = MagicMock()
        mock_table.get_item.return_value = {}
        mock_dynamodb = MagicMock()
        mock_dynamodb.Table.return_value = mock_table

        with patch("handler.dynamodb", mock_dynamodb):
            result = is_destination_verified("unknown@example.com")

        self.assertFalse(result)

    def test_no_verifications_table_allows_all(self):
        with patch("handler.VERIFICATIONS_TABLE", ""):
            result = is_destination_verified("anyone@example.com")

        self.assertTrue(result)


class TestInlineVerification(unittest.TestCase):
    """Test per-rule-destination inline verification in process_record."""

    def test_inline_verified_true_forwards(self):
        """A dest with verified=True should be forwarded without table lookup."""
        raw, msg = _make_plain_email()
        mock_ses = MagicMock()
        dest_info = {
            "address": "craig@barkingiguana.com", "role": "to",
            "unsubscribe_token": "tok", "verified": True,
        }
        with patch("handler.ses", mock_ses):
            forward(msg, raw, "hello@thearecorder.com", dest_info)
        mock_ses.send_raw_email.assert_called_once()

    def test_inline_verified_false_skips(self):
        """A dest with verified=False should not forward."""
        dest_info = {
            "address": "unverified@example.com", "role": "to",
            "unsubscribe_token": "tok", "verified": False,
        }
        # The inline check happens in process_record, not forward itself.
        # We test the logic directly.
        verified = dest_info.get("verified")
        self.assertFalse(verified)

    def test_missing_verified_falls_back_to_table(self):
        """A dest without a 'verified' key should fall back to is_destination_verified."""
        dest_info = {
            "address": "legacy@example.com", "role": "to",
            "unsubscribe_token": "tok",
        }
        verified = dest_info.get("verified")
        self.assertIsNone(verified)
        # When None, process_record falls back to is_destination_verified()


class TestForwardWithVerification(unittest.TestCase):
    """Test that forward() integrates with verification checks in process_record."""

    def test_verified_destination_forwards_successfully(self):
        """A verified destination should result in forward() being called."""
        raw, msg = _make_plain_email()
        mock_ses = MagicMock()

        dest_info = {
            "address": "craig@barkingiguana.com", "role": "to",
            "unsubscribe_token": "tok", "verified": True,
        }
        with patch("handler.ses", mock_ses):
            forward(msg, raw, "hello@thearecorder.com", dest_info)

        mock_ses.send_raw_email.assert_called_once()

    def test_unverified_destination_skipped_with_warning(self):
        """An unverified destination should be skipped and logged as a warning."""
        mock_table = MagicMock()
        mock_table.get_item.return_value = {
            "Item": {"destination": "unverified@example.com", "verified": False}
        }
        mock_dynamodb = MagicMock()
        mock_dynamodb.Table.return_value = mock_table

        with patch("handler.dynamodb", mock_dynamodb), \
             patch("handler.logger") as mock_logger:
            result = is_destination_verified("unverified@example.com")

        self.assertFalse(result)


class TestLookupDestinations(unittest.TestCase):
    """Test that lookup_destinations returns the correct format."""

    def test_new_format_returns_destinations_list(self):
        mock_table = MagicMock()
        mock_table.get_item.return_value = {
            "Item": {
                "domain": "example.com",
                "localpart": "hello",
                "destinations": [
                    {"address": "a@b.com", "role": "to", "unsubscribe_token": "t1"},
                    {"address": "c@d.com", "role": "bcc", "unsubscribe_token": "t2"},
                ],
                "enabled": True,
                "tenant_id": "default",
            }
        }
        mock_dynamodb = MagicMock()
        mock_dynamodb.Table.return_value = mock_table

        with patch("handler.dynamodb", mock_dynamodb):
            dests, tenant = lookup_destinations("hello@example.com")

        self.assertEqual(len(dests), 2)
        self.assertEqual(dests[0]["address"], "a@b.com")
        self.assertEqual(dests[1]["role"], "bcc")
        self.assertEqual(tenant, "default")

    def test_legacy_format_returns_single_destination(self):
        mock_table = MagicMock()
        mock_table.get_item.return_value = {
            "Item": {
                "domain": "example.com",
                "localpart": "hello",
                "destination": "old@format.com",
                "enabled": True,
                "tenant_id": "t1",
            }
        }
        mock_dynamodb = MagicMock()
        mock_dynamodb.Table.return_value = mock_table

        with patch("handler.dynamodb", mock_dynamodb):
            dests, tenant = lookup_destinations("hello@example.com")

        self.assertEqual(len(dests), 1)
        self.assertEqual(dests[0]["address"], "old@format.com")
        self.assertEqual(dests[0]["role"], "to")
        self.assertEqual(tenant, "t1")

    def test_no_match_returns_none(self):
        mock_table = MagicMock()
        mock_table.get_item.return_value = {}
        mock_dynamodb = MagicMock()
        mock_dynamodb.Table.return_value = mock_table

        with patch("handler.dynamodb", mock_dynamodb):
            dests, tenant = lookup_destinations("nobody@nowhere.com")

        self.assertIsNone(dests)
        self.assertIsNone(tenant)


class TestExtractAuthResults(unittest.TestCase):
    """Test extraction of Authentication-Results from original messages."""

    def test_extracts_existing_auth_results(self):
        _, msg = _make_plain_email()
        msg["Authentication-Results"] = "mx.google.com; dkim=pass; spf=pass"
        result = _extract_auth_results(msg)
        self.assertEqual(result, "mx.google.com; dkim=pass; spf=pass")

    def test_fallback_to_received_spf(self):
        _, msg = _make_plain_email()
        msg["Received-SPF"] = "pass (domain of example.com)"
        result = _extract_auth_results(msg)
        self.assertIn("spf=pass", result)
        self.assertIn("deliverymachine.net", result)

    def test_fallback_with_dkim_signature(self):
        _, msg = _make_plain_email()
        msg["DKIM-Signature"] = "v=1; a=rsa-sha256; d=example.com"
        result = _extract_auth_results(msg)
        self.assertIn("dkim=pass", result)

    def test_no_auth_headers_returns_none(self):
        _, msg = _make_plain_email()
        result = _extract_auth_results(msg)
        self.assertIn("none", result)


class TestArcSignMessage(unittest.TestCase):
    """Test ARC signing wrapper."""

    def test_returns_original_when_dkim_unavailable(self):
        _, msg = _make_plain_email()
        message_bytes = msg.as_bytes()
        with patch("handler.dkim", None):
            result = _arc_sign_message(message_bytes, msg)
        self.assertEqual(result, message_bytes)

    def test_returns_original_when_no_private_key(self):
        _, msg = _make_plain_email()
        message_bytes = msg.as_bytes()
        with patch("handler._get_arc_private_key", return_value=None):
            result = _arc_sign_message(message_bytes, msg)
        self.assertEqual(result, message_bytes)

    def test_returns_original_when_no_domain(self):
        _, msg = _make_plain_email()
        message_bytes = msg.as_bytes()
        with patch("handler.ARC_DOMAIN", ""):
            result = _arc_sign_message(message_bytes, msg)
        self.assertEqual(result, message_bytes)

    def test_returns_original_on_signing_error(self):
        _, msg = _make_plain_email()
        message_bytes = msg.as_bytes()
        mock_dkim = MagicMock()
        mock_dkim.arc_sign.side_effect = Exception("signing failed")
        with patch("handler.dkim", mock_dkim), \
             patch("handler._get_arc_private_key", return_value=b"fake-key"), \
             patch("handler.ARC_DOMAIN", "deliverymachine.net"):
            result = _arc_sign_message(message_bytes, msg)
        self.assertEqual(result, message_bytes)

    def test_prepends_arc_headers_on_success(self):
        _, msg = _make_plain_email()
        message_bytes = msg.as_bytes()
        mock_dkim = MagicMock()
        mock_dkim.arc_sign.return_value = b"ARC-Seal: i=1; fake\r\n"
        with patch("handler.dkim", mock_dkim), \
             patch("handler._get_arc_private_key", return_value=b"fake-key"), \
             patch("handler.ARC_DOMAIN", "deliverymachine.net"):
            result = _arc_sign_message(message_bytes, msg)
        self.assertTrue(result.startswith(b"ARC-Seal: i=1; fake\r\n"))
        self.assertTrue(result.endswith(message_bytes))


if __name__ == "__main__":
    unittest.main()
