#!/usr/bin/env bash
# Build the dkimpy Lambda layer zip.
# Called by CI before terraform apply.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
REPO_ROOT="$(dirname "$SCRIPT_DIR")"
LAYER_DIR="$REPO_ROOT/lambda/layers/dkimpy"
BUILD_DIR="$LAYER_DIR/build/python"
OUTPUT="$REPO_ROOT/terraform/.build/dkimpy-layer.zip"

echo "==> Building dkimpy Lambda layer"

rm -rf "$LAYER_DIR/build"
mkdir -p "$BUILD_DIR" "$(dirname "$OUTPUT")"

python3 -m pip install -t "$BUILD_DIR" -r "$LAYER_DIR/requirements.txt" --quiet --no-cache-dir

# Remove unnecessary files to keep the layer small.
find "$BUILD_DIR" -type d -name "__pycache__" -exec rm -rf {} + 2>/dev/null || true
find "$BUILD_DIR" -name "*.dist-info" -exec rm -rf {} + 2>/dev/null || true

cd "$LAYER_DIR/build"
zip -r "$OUTPUT" python/ -q

SIZE=$(du -h "$OUTPUT" | cut -f1)
echo "==> Layer built: $OUTPUT ($SIZE)"
