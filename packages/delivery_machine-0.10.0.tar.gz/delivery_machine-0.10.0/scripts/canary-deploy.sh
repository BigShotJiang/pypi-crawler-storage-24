#!/usr/bin/env bash
# Canary deployment for Lambda functions via CodeDeploy.
#
# After terraform apply publishes new Lambda versions, this script triggers
# CodeDeploy to shift traffic from the old version to the new version using
# a canary strategy (10% for 5 minutes, then 100%). If the CloudWatch error
# alarm fires during the canary window, CodeDeploy auto-rolls back.
#
# Usage: canary-deploy.sh <function-name> <alias-name> <codedeploy-app> <deployment-group>

set -euo pipefail

FUNCTION_NAME=$1
ALIAS_NAME=$2
APP_NAME=$3
DEPLOYMENT_GROUP=$4

echo "=== Canary deploy: $FUNCTION_NAME ($ALIAS_NAME) ==="

# Get current alias version (the "old" version)
CURRENT_VERSION=$(aws lambda get-alias \
  --function-name "$FUNCTION_NAME" \
  --name "$ALIAS_NAME" \
  --query 'FunctionVersion' --output text 2>/dev/null || echo "")

# Get latest published version
LATEST_VERSION=$(aws lambda list-versions-by-function \
  --function-name "$FUNCTION_NAME" \
  --query 'Versions[-1].Version' --output text)

if [ "$CURRENT_VERSION" = "$LATEST_VERSION" ]; then
  echo "  Alias already points to latest version ($LATEST_VERSION). Nothing to deploy."
  exit 0
fi

echo "  Current: v${CURRENT_VERSION:-none} → Target: v${LATEST_VERSION}"

# If there's no current version (first deploy), just point the alias directly
if [ -z "$CURRENT_VERSION" ] || [ "$CURRENT_VERSION" = "\$LATEST" ]; then
  echo "  First deploy — setting alias directly to v${LATEST_VERSION}"
  aws lambda update-alias \
    --function-name "$FUNCTION_NAME" \
    --name "$ALIAS_NAME" \
    --function-version "$LATEST_VERSION"
  exit 0
fi

# Build the AppSpec for CodeDeploy
APPSPEC=$(cat <<EOF
{
  "version": 0.0,
  "Resources": [{
    "myFunction": {
      "Type": "AWS::Lambda::Function",
      "Properties": {
        "Name": "$FUNCTION_NAME",
        "Alias": "$ALIAS_NAME",
        "CurrentVersion": "$CURRENT_VERSION",
        "TargetVersion": "$LATEST_VERSION"
      }
    }
  }]
}
EOF
)

# Trigger the CodeDeploy deployment
DEPLOYMENT_ID=$(aws deploy create-deployment \
  --application-name "$APP_NAME" \
  --deployment-group-name "$DEPLOYMENT_GROUP" \
  --revision "{\"revisionType\": \"AppSpecContent\", \"appSpecContent\": {\"content\": $(echo "$APPSPEC" | jq -c '.' | jq -Rs '.')}}" \
  --query 'deploymentId' --output text)

echo "  Deployment: $DEPLOYMENT_ID"
echo "  Strategy: Canary 10% for 5 minutes, then 100%"
echo "  Waiting for deployment to complete..."

# Wait for deployment to finish (timeout after 10 minutes)
aws deploy wait deployment-successful \
  --deployment-id "$DEPLOYMENT_ID" 2>/dev/null && {
  echo "  ✓ Deployment succeeded — v${LATEST_VERSION} is now live"
} || {
  STATUS=$(aws deploy get-deployment \
    --deployment-id "$DEPLOYMENT_ID" \
    --query 'deploymentInfo.status' --output text)
  echo "  ✗ Deployment $STATUS"
  if [ "$STATUS" = "Failed" ] || [ "$STATUS" = "Stopped" ]; then
    REASON=$(aws deploy get-deployment \
      --deployment-id "$DEPLOYMENT_ID" \
      --query 'deploymentInfo.errorInformation.message' --output text)
    echo "  Reason: $REASON"
    echo "  Auto-rollback to v${CURRENT_VERSION} should have been triggered by CodeDeploy"
  fi
  exit 1
}
