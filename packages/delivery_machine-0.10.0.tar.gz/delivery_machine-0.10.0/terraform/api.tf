# ── API Gateway (REST, regional) ───────────────────────────────────────────
#
# Uses a {proxy+} catch-all resource so all routing logic lives in Lambda.
# Authentication is handled by JWT validation in the Lambda itself.

resource "aws_api_gateway_rest_api" "main" {
  name        = "${local.prefix}-api"
  description = "Delivery Machine management API"

  endpoint_configuration {
    types = ["REGIONAL"]
  }
}

# Proxy resource: catches everything after the root path.
resource "aws_api_gateway_resource" "proxy" {
  rest_api_id = aws_api_gateway_rest_api.main.id
  parent_id   = aws_api_gateway_rest_api.main.root_resource_id
  path_part   = "{proxy+}"
}

resource "aws_api_gateway_method" "proxy_any" {
  rest_api_id      = aws_api_gateway_rest_api.main.id
  resource_id      = aws_api_gateway_resource.proxy.id
  http_method      = "ANY"
  authorization    = "NONE"
  api_key_required = false
}

resource "aws_api_gateway_integration" "proxy_lambda" {
  rest_api_id             = aws_api_gateway_rest_api.main.id
  resource_id             = aws_api_gateway_resource.proxy.id
  http_method             = aws_api_gateway_method.proxy_any.http_method
  integration_http_method = "POST"
  type                    = "AWS_PROXY"
  uri                     = aws_lambda_alias.api_live.invoke_arn
}

# Also handle requests to the root path (e.g. GET /).
resource "aws_api_gateway_method" "root_any" {
  rest_api_id      = aws_api_gateway_rest_api.main.id
  resource_id      = aws_api_gateway_rest_api.main.root_resource_id
  http_method      = "ANY"
  authorization    = "NONE"
  api_key_required = false
}

resource "aws_api_gateway_integration" "root_lambda" {
  rest_api_id             = aws_api_gateway_rest_api.main.id
  resource_id             = aws_api_gateway_rest_api.main.root_resource_id
  http_method             = aws_api_gateway_method.root_any.http_method
  integration_http_method = "POST"
  type                    = "AWS_PROXY"
  uri                     = aws_lambda_alias.api_live.invoke_arn
}

# ── Public verify endpoint (no API key required) ──────────────────────────
#
# GET /v1/verify?token=<token> — clicked from a verification email.

resource "aws_api_gateway_resource" "v1" {
  rest_api_id = aws_api_gateway_rest_api.main.id
  parent_id   = aws_api_gateway_rest_api.main.root_resource_id
  path_part   = "v1"
}

resource "aws_api_gateway_resource" "verify" {
  rest_api_id = aws_api_gateway_rest_api.main.id
  parent_id   = aws_api_gateway_resource.v1.id
  path_part   = "verify"
}

resource "aws_api_gateway_method" "verify_get" {
  rest_api_id      = aws_api_gateway_rest_api.main.id
  resource_id      = aws_api_gateway_resource.verify.id
  http_method      = "GET"
  authorization    = "NONE"
  api_key_required = false
}

resource "aws_api_gateway_integration" "verify_lambda" {
  rest_api_id             = aws_api_gateway_rest_api.main.id
  resource_id             = aws_api_gateway_resource.verify.id
  http_method             = aws_api_gateway_method.verify_get.http_method
  integration_http_method = "POST"
  type                    = "AWS_PROXY"
  uri                     = aws_lambda_alias.api_live.invoke_arn
}

# ── Public unsubscribe endpoint (no API key required) ────────────────────
#
# GET /v1/unsubscribe?token=<token> — clicked from a forwarded email.

resource "aws_api_gateway_resource" "unsubscribe" {
  rest_api_id = aws_api_gateway_rest_api.main.id
  parent_id   = aws_api_gateway_resource.v1.id
  path_part   = "unsubscribe"
}

resource "aws_api_gateway_method" "unsubscribe_get" {
  rest_api_id      = aws_api_gateway_rest_api.main.id
  resource_id      = aws_api_gateway_resource.unsubscribe.id
  http_method      = "GET"
  authorization    = "NONE"
  api_key_required = false
}

resource "aws_api_gateway_integration" "unsubscribe_lambda" {
  rest_api_id             = aws_api_gateway_rest_api.main.id
  resource_id             = aws_api_gateway_resource.unsubscribe.id
  http_method             = aws_api_gateway_method.unsubscribe_get.http_method
  integration_http_method = "POST"
  type                    = "AWS_PROXY"
  uri                     = aws_lambda_alias.api_live.invoke_arn
}

# ── Deployment & stage ─────────────────────────────────────────────────────

resource "aws_api_gateway_deployment" "main" {
  rest_api_id = aws_api_gateway_rest_api.main.id

  # Force redeployment when integration config changes.
  triggers = {
    redeployment = sha1(jsonencode([
      aws_api_gateway_resource.proxy,
      aws_api_gateway_method.proxy_any,
      aws_api_gateway_integration.proxy_lambda,
      aws_api_gateway_method.root_any,
      aws_api_gateway_integration.root_lambda,
      aws_api_gateway_resource.v1,
      aws_api_gateway_resource.verify,
      aws_api_gateway_method.verify_get,
      aws_api_gateway_integration.verify_lambda,
      aws_api_gateway_resource.unsubscribe,
      aws_api_gateway_method.unsubscribe_get,
      aws_api_gateway_integration.unsubscribe_lambda,
      aws_api_gateway_resource.auth,
      aws_api_gateway_resource.auth_proxy,
      aws_api_gateway_method.auth_any,
      aws_api_gateway_integration.auth_lambda,
      aws_api_gateway_method.auth_proxy_any,
      aws_api_gateway_integration.auth_proxy_lambda,
    ]))
  }

  lifecycle {
    create_before_destroy = true
  }

  depends_on = [
    aws_api_gateway_integration.proxy_lambda,
    aws_api_gateway_integration.root_lambda,
    aws_api_gateway_integration.verify_lambda,
    aws_api_gateway_integration.unsubscribe_lambda,
    aws_api_gateway_integration.auth_lambda,
    aws_api_gateway_integration.auth_proxy_lambda,
  ]
}

resource "aws_api_gateway_stage" "main" {
  rest_api_id   = aws_api_gateway_rest_api.main.id
  deployment_id = aws_api_gateway_deployment.main.id
  stage_name    = "prod"
}

# ── Rate limiting (usage plan without API key) ────────────────────────────
#
# API keys are no longer used for authentication (JWT handles that).
# Keep the usage plan for rate limiting only.

resource "aws_api_gateway_usage_plan" "main" {
  name = "${local.prefix}-usage-plan"

  api_stages {
    api_id = aws_api_gateway_rest_api.main.id
    stage  = aws_api_gateway_stage.main.stage_name
  }

  throttle_settings {
    rate_limit  = 50   # requests/second
    burst_limit = 100
  }
}

# ── Custom domain: api.deliverymachine.net ─────────────────────────────────

# ACM certificate for the API subdomain (same region as API Gateway).
resource "aws_acm_certificate" "api" {
  domain_name       = "api.${var.site_domain}"
  validation_method = "DNS"

  lifecycle { create_before_destroy = true }
}

# DNS validation record for the API certificate.
resource "aws_route53_record" "api_acm_validation" {
  for_each = {
    for dvo in aws_acm_certificate.api.domain_validation_options : dvo.domain_name => {
      name   = dvo.resource_record_name
      type   = dvo.resource_record_type
      record = dvo.resource_record_value
    }
  }

  zone_id         = aws_route53_zone.site.zone_id
  name            = each.value.name
  type            = each.value.type
  ttl             = 300
  records         = [each.value.record]
  allow_overwrite = true
}

resource "aws_acm_certificate_validation" "api" {
  certificate_arn         = aws_acm_certificate.api.arn
  validation_record_fqdns = [for r in aws_route53_record.api_acm_validation : r.fqdn]
}

# Regional custom domain name for API Gateway.
resource "aws_api_gateway_domain_name" "api" {
  domain_name              = "api.${var.site_domain}"
  regional_certificate_arn = aws_acm_certificate_validation.api.certificate_arn

  endpoint_configuration {
    types = ["REGIONAL"]
  }
}

# Map the prod stage to the custom domain (empty base path = root).
resource "aws_api_gateway_base_path_mapping" "api" {
  api_id      = aws_api_gateway_rest_api.main.id
  stage_name  = aws_api_gateway_stage.main.stage_name
  domain_name = aws_api_gateway_domain_name.api.domain_name
}

# DNS A record: api.deliverymachine.net → API Gateway regional endpoint.
resource "aws_route53_record" "api_a" {
  zone_id = aws_route53_zone.site.zone_id
  name    = "api.${var.site_domain}"
  type    = "A"

  alias {
    name                   = aws_api_gateway_domain_name.api.regional_domain_name
    zone_id                = aws_api_gateway_domain_name.api.regional_zone_id
    evaluate_target_health = true
  }
}

# DNS AAAA record: api.deliverymachine.net → API Gateway regional endpoint.
resource "aws_route53_record" "api_aaaa" {
  zone_id = aws_route53_zone.site.zone_id
  name    = "api.${var.site_domain}"
  type    = "AAAA"

  alias {
    name                   = aws_api_gateway_domain_name.api.regional_domain_name
    zone_id                = aws_api_gateway_domain_name.api.regional_zone_id
    evaluate_target_health = true
  }
}
