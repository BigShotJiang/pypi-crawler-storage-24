# ── Lambda aliases (for canary deployments) ──────────────────────────────────
#
# Each Lambda has a "live" alias. API Gateway and S3 invoke the alias,
# not $LATEST. CodeDeploy shifts traffic from the old version to the new
# version using a canary strategy, with automatic rollback on errors.

resource "aws_lambda_alias" "forwarder_live" {
  name             = "live"
  function_name    = aws_lambda_function.forwarder.function_name
  function_version = aws_lambda_function.forwarder.version

  lifecycle {
    ignore_changes = [function_version, routing_config]
  }
}

resource "aws_lambda_alias" "api_live" {
  name             = "live"
  function_name    = aws_lambda_function.api.function_name
  function_version = aws_lambda_function.api.version

  lifecycle {
    ignore_changes = [function_version, routing_config]
  }
}

# ── CloudWatch alarms (canary health checks) ────────────────────────────────

resource "aws_cloudwatch_metric_alarm" "forwarder_errors" {
  alarm_name          = "${local.prefix}-forwarder-errors"
  alarm_description   = "Forwarder Lambda error rate too high — triggers canary rollback"
  namespace           = "AWS/Lambda"
  metric_name         = "Errors"
  statistic           = "Sum"
  period              = 60
  evaluation_periods  = 2
  threshold           = 3
  comparison_operator = "GreaterThanThreshold"
  treat_missing_data  = "notBreaching"

  dimensions = {
    FunctionName = aws_lambda_function.forwarder.function_name
    Resource     = "${aws_lambda_function.forwarder.function_name}:live"
  }
}

resource "aws_cloudwatch_metric_alarm" "api_errors" {
  alarm_name          = "${local.prefix}-api-errors"
  alarm_description   = "API Lambda error rate too high — triggers canary rollback"
  namespace           = "AWS/Lambda"
  metric_name         = "Errors"
  statistic           = "Sum"
  period              = 60
  evaluation_periods  = 2
  threshold           = 5
  comparison_operator = "GreaterThanThreshold"
  treat_missing_data  = "notBreaching"

  dimensions = {
    FunctionName = aws_lambda_function.api.function_name
    Resource     = "${aws_lambda_function.api.function_name}:live"
  }
}

# ── CodeDeploy (canary traffic shifting) ─────────────────────────────────────

resource "aws_codedeploy_app" "lambda" {
  compute_platform = "Lambda"
  name             = "${local.prefix}-lambda"
}

resource "aws_iam_role" "codedeploy" {
  name = "${local.prefix}-codedeploy"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = { Service = "codedeploy.amazonaws.com" }
      Action    = "sts:AssumeRole"
    }]
  })
}

resource "aws_iam_role_policy" "codedeploy" {
  name = "${local.prefix}-codedeploy"
  role = aws_iam_role.codedeploy.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect = "Allow"
        Action = [
          "lambda:GetAlias",
          "lambda:UpdateAlias",
          "lambda:GetFunction",
          "lambda:InvokeFunction",
        ]
        Resource = [
          aws_lambda_function.forwarder.arn,
          "${aws_lambda_function.forwarder.arn}:*",
          aws_lambda_function.api.arn,
          "${aws_lambda_function.api.arn}:*",
        ]
      },
      {
        Effect = "Allow"
        Action = [
          "cloudwatch:DescribeAlarms",
        ]
        Resource = "*"
      },
      {
        Effect = "Allow"
        Action = [
          "codedeploy:GetDeployment",
          "codedeploy:GetDeploymentConfig",
        ]
        Resource = "*"
      },
      {
        Effect = "Allow"
        Action = [
          "s3:GetObject",
          "s3:GetObjectVersion",
        ]
        Resource = "*"
      }
    ]
  })
}

resource "aws_codedeploy_deployment_group" "forwarder" {
  app_name               = aws_codedeploy_app.lambda.name
  deployment_group_name  = "forwarder"
  deployment_config_name = "CodeDeployDefault.LambdaCanary10Percent5Minutes"
  service_role_arn       = aws_iam_role.codedeploy.arn

  deployment_style {
    deployment_type   = "BLUE_GREEN"
    deployment_option = "WITH_TRAFFIC_CONTROL"
  }

  auto_rollback_configuration {
    enabled = true
    events  = ["DEPLOYMENT_FAILURE", "DEPLOYMENT_STOP_ON_ALARM"]
  }

  alarm_configuration {
    alarms  = [aws_cloudwatch_metric_alarm.forwarder_errors.alarm_name]
    enabled = true
  }
}

resource "aws_codedeploy_deployment_group" "api" {
  app_name               = aws_codedeploy_app.lambda.name
  deployment_group_name  = "api"
  deployment_config_name = "CodeDeployDefault.LambdaCanary10Percent5Minutes"
  service_role_arn       = aws_iam_role.codedeploy.arn

  deployment_style {
    deployment_type   = "BLUE_GREEN"
    deployment_option = "WITH_TRAFFIC_CONTROL"
  }

  auto_rollback_configuration {
    enabled = true
    events  = ["DEPLOYMENT_FAILURE", "DEPLOYMENT_STOP_ON_ALARM"]
  }

  alarm_configuration {
    alarms  = [aws_cloudwatch_metric_alarm.api_errors.alarm_name]
    enabled = true
  }
}
