# ── ARC (Authenticated Received Chain) signing ─────────────────────────────
#
# Adds ARC headers to forwarded emails so downstream receivers can verify
# the chain of custody. Uses dkimpy in a Lambda layer with an RSA key pair
# stored in Secrets Manager.

# ── Signing key ────────────────────────────────────────────────────────────

resource "tls_private_key" "arc" {
  algorithm = "RSA"
  rsa_bits  = 2048
}

resource "aws_ssm_parameter" "arc_private_key" {
  name        = "/${local.prefix}/arc-private-key"
  description = "RSA private key for ARC signing (Delivery Machine forwarder)"
  type        = "SecureString"
  value       = tls_private_key.arc.private_key_pem
  overwrite   = true
}

# ── DNS: ARC DKIM public key ──────────────────────────────────────────────
#
# Receivers look up arc._domainkey.deliverymachine.net to verify ARC-Seal
# and ARC-Message-Signature headers.

locals {
  # Strip PEM headers/footers and newlines to get the raw base64 public key.
  arc_pubkey_raw = replace(replace(replace(
    tls_private_key.arc.public_key_pem,
    "-----BEGIN PUBLIC KEY-----\n", ""),
    "\n-----END PUBLIC KEY-----\n", ""),
    "\n", ""
  )

  # DNS TXT records have a 255-char per-string limit. Split the value into
  # two quoted strings so Route 53 accepts it.
  arc_dkim_prefix = "v=DKIM1; k=rsa; p="
  arc_dkim_full   = "${local.arc_dkim_prefix}${local.arc_pubkey_raw}"
  arc_dkim_chunk1 = substr(local.arc_dkim_full, 0, 255)
  arc_dkim_chunk2 = substr(local.arc_dkim_full, 255, length(local.arc_dkim_full) - 255)
}

resource "aws_route53_record" "arc_dkim" {
  zone_id = aws_route53_zone.site.zone_id
  name    = "arc._domainkey.${var.site_domain}"
  type    = "TXT"
  ttl     = 300

  records = [
    "${local.arc_dkim_chunk1}\"\"${local.arc_dkim_chunk2}"
  ]
}

# ── Lambda layer: dkimpy ──────────────────────────────────────────────────
#
# Built by scripts/build-dkimpy-layer.sh in CI before terraform apply.

resource "aws_lambda_layer_version" "dkimpy" {
  filename            = "${path.module}/.build/dkimpy-layer.zip"
  source_code_hash    = filebase64sha256("${path.module}/.build/dkimpy-layer.zip")
  layer_name          = "${local.prefix}-dkimpy"
  compatible_runtimes = ["python3.12"]
  description         = "dkimpy + dnspython for ARC email signing"
}
