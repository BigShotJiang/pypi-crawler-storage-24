# ── Observability: SNS, CloudWatch Alarms, Synthetics Canary, Dashboard ──
#
# Adapted from the oneshot project's monitoring patterns.
# Alarms notify via SNS email subscription.

# ── SNS topics ──────────────────────────────────────────────────────────────

resource "aws_sns_topic" "alarms" {
  name         = "${local.prefix}-alarms"
  display_name = "Delivery Machine Alarms"
}

resource "aws_sns_topic_subscription" "alarms_email" {
  topic_arn = aws_sns_topic.alarms.arn
  protocol  = "email"
  endpoint  = var.alert_email
}

resource "aws_sns_topic" "billing_alarms" {
  name         = "${local.prefix}-billing-alarms"
  display_name = "Delivery Machine Billing Alarms"
}

resource "aws_sns_topic_subscription" "billing_email" {
  topic_arn = aws_sns_topic.billing_alarms.arn
  protocol  = "email"
  endpoint  = var.alert_email
}

# ── API Gateway alarms ──────────────────────────────────────────────────────

resource "aws_cloudwatch_metric_alarm" "api_5xx" {
  alarm_name          = "${local.prefix}-api-5xx"
  alarm_description   = "API Gateway 5xx error rate"
  namespace           = "AWS/ApiGateway"
  metric_name         = "5XXError"
  statistic           = "Sum"
  period              = 300
  evaluation_periods  = 1
  threshold           = 1
  comparison_operator = "GreaterThanOrEqualToThreshold"
  treat_missing_data  = "notBreaching"

  dimensions = {
    ApiName = aws_api_gateway_rest_api.main.name
    Stage   = "prod"
  }

  alarm_actions = [aws_sns_topic.alarms.arn]
  ok_actions    = [aws_sns_topic.alarms.arn]
}

resource "aws_cloudwatch_metric_alarm" "api_latency" {
  alarm_name          = "${local.prefix}-api-latency-p99"
  alarm_description   = "API Gateway p99 latency > 2s"
  namespace           = "AWS/ApiGateway"
  metric_name         = "Latency"
  extended_statistic  = "p99"
  period              = 300
  evaluation_periods  = 1
  threshold           = 2000
  comparison_operator = "GreaterThanThreshold"
  treat_missing_data  = "notBreaching"

  dimensions = {
    ApiName = aws_api_gateway_rest_api.main.name
    Stage   = "prod"
  }

  alarm_actions = [aws_sns_topic.alarms.arn]
  ok_actions    = [aws_sns_topic.alarms.arn]
}

# ── DynamoDB throttling alarm ───────────────────────────────────────────────

resource "aws_cloudwatch_metric_alarm" "dynamo_throttle" {
  alarm_name          = "${local.prefix}-dynamo-throttle"
  alarm_description   = "DynamoDB throttled requests (should not happen with PAY_PER_REQUEST)"
  namespace           = "AWS/DynamoDB"
  metric_name         = "ThrottledRequests"
  statistic           = "Sum"
  period              = 60
  evaluation_periods  = 3
  threshold           = 0
  comparison_operator = "GreaterThanThreshold"
  treat_missing_data  = "notBreaching"

  alarm_actions = [aws_sns_topic.alarms.arn]
  ok_actions    = [aws_sns_topic.alarms.arn]
}

# ── SES reputation alarms ──────────────────────────────────────────────────

resource "aws_cloudwatch_metric_alarm" "ses_bounce_rate" {
  alarm_name          = "${local.prefix}-ses-bounce-rate"
  alarm_description   = "SES bounce rate > 5%"
  namespace           = "AWS/SES"
  metric_name         = "Reputation.BounceRate"
  statistic           = "Average"
  period              = 900
  evaluation_periods  = 1
  threshold           = 0.05
  comparison_operator = "GreaterThanThreshold"
  treat_missing_data  = "notBreaching"

  alarm_actions = [aws_sns_topic.alarms.arn]
  ok_actions    = [aws_sns_topic.alarms.arn]
}

resource "aws_cloudwatch_metric_alarm" "ses_complaint_rate" {
  alarm_name          = "${local.prefix}-ses-complaint-rate"
  alarm_description   = "SES complaint rate > 0.1%"
  namespace           = "AWS/SES"
  metric_name         = "Reputation.ComplaintRate"
  statistic           = "Average"
  period              = 900
  evaluation_periods  = 1
  threshold           = 0.001
  comparison_operator = "GreaterThanThreshold"
  treat_missing_data  = "notBreaching"

  alarm_actions = [aws_sns_topic.alarms.arn]
  ok_actions    = [aws_sns_topic.alarms.arn]
}

# ── Lambda error alarms (service-wide, distinct from canary rollback) ──────

resource "aws_cloudwatch_metric_alarm" "forwarder_errors_alarm" {
  alarm_name          = "${local.prefix}-forwarder-errors-alarm"
  alarm_description   = "Forwarder Lambda errors (service alarm)"
  namespace           = "AWS/Lambda"
  metric_name         = "Errors"
  statistic           = "Sum"
  period              = 300
  evaluation_periods  = 1
  threshold           = 1
  comparison_operator = "GreaterThanOrEqualToThreshold"
  treat_missing_data  = "notBreaching"

  dimensions = {
    FunctionName = aws_lambda_function.forwarder.function_name
  }

  alarm_actions = [aws_sns_topic.alarms.arn]
  ok_actions    = [aws_sns_topic.alarms.arn]
}

resource "aws_cloudwatch_metric_alarm" "api_errors_alarm" {
  alarm_name          = "${local.prefix}-api-errors-alarm"
  alarm_description   = "API Lambda errors (service alarm)"
  namespace           = "AWS/Lambda"
  metric_name         = "Errors"
  statistic           = "Sum"
  period              = 300
  evaluation_periods  = 1
  threshold           = 1
  comparison_operator = "GreaterThanOrEqualToThreshold"
  treat_missing_data  = "notBreaching"

  dimensions = {
    FunctionName = aws_lambda_function.api.function_name
  }

  alarm_actions = [aws_sns_topic.alarms.arn]
  ok_actions    = [aws_sns_topic.alarms.arn]
}

# ── Daily spend alarm ──────────────────────────────────────────────────────

resource "aws_cloudwatch_metric_alarm" "daily_spend" {
  alarm_name          = "${local.prefix}-daily-spend"
  alarm_description   = "Estimated AWS charges exceed $10"
  namespace           = "AWS/Billing"
  metric_name         = "EstimatedCharges"
  statistic           = "Maximum"
  period              = 21600 # 6 hours
  evaluation_periods  = 1
  threshold           = 10
  comparison_operator = "GreaterThanThreshold"
  treat_missing_data  = "notBreaching"

  dimensions = {
    Currency = "USD"
  }

  alarm_actions = [aws_sns_topic.billing_alarms.arn]
}

# ── Health check Lambda (replaces CloudWatch Synthetics canary) ────────────
#
# Plain Lambda + EventBridge schedule — runs every 5 minutes within free tier
# instead of Synthetics at $0.0012/run.

data "archive_file" "health_check" {
  type        = "zip"
  output_path = "${path.module}/.build/health-check.zip"

  source {
    content  = <<-PY
      import json
      import urllib.request

      def handler(event, context):
          url = "https://api.${var.site_domain}/v1/health"
          req = urllib.request.Request(url, headers={"User-Agent": "delivery-machine-health-check"})
          resp = urllib.request.urlopen(req, timeout=10)
          body = json.loads(resp.read())
          if resp.status != 200 or body.get("status") != "ok":
              raise Exception(f"Health check failed: {body}")
          print(f"Health OK, region={body.get('region')}")
          return {"status": "ok"}
    PY
    filename = "handler.py"
  }
}

resource "aws_lambda_function" "health_check" {
  filename         = data.archive_file.health_check.output_path
  source_code_hash = data.archive_file.health_check.output_base64sha256
  function_name    = "${local.prefix}-health-check"
  role             = aws_iam_role.health_check.arn
  handler          = "handler.handler"
  runtime          = "python3.12"
  architectures    = ["arm64"]
  timeout          = 15
  memory_size      = 128
}

resource "aws_cloudwatch_log_group" "health_check" {
  name              = "/aws/lambda/${aws_lambda_function.health_check.function_name}"
  retention_in_days = var.lambda_log_retention_days
}

resource "aws_iam_role" "health_check" {
  name = "${local.prefix}-health-check"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = { Service = "lambda.amazonaws.com" }
      Action    = "sts:AssumeRole"
    }]
  })
}

resource "aws_iam_role_policy" "health_check" {
  name = "${local.prefix}-health-check"
  role = aws_iam_role.health_check.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect   = "Allow"
      Action   = ["logs:CreateLogGroup", "logs:CreateLogStream", "logs:PutLogEvents"]
      Resource = "arn:aws:logs:*:*:*"
    }]
  })
}

resource "aws_cloudwatch_event_rule" "health_check" {
  name                = "${local.prefix}-health-check"
  description         = "Trigger API health check every minute"
  schedule_expression = "rate(1 minute)"
}

resource "aws_cloudwatch_event_target" "health_check" {
  rule = aws_cloudwatch_event_rule.health_check.name
  arn  = aws_lambda_function.health_check.arn
}

resource "aws_lambda_permission" "eventbridge_health_check" {
  statement_id  = "AllowEventBridgeInvoke"
  action        = "lambda:InvokeFunction"
  function_name = aws_lambda_function.health_check.function_name
  principal     = "events.amazonaws.com"
  source_arn    = aws_cloudwatch_event_rule.health_check.arn
}

resource "aws_cloudwatch_metric_alarm" "health_check_failure" {
  alarm_name          = "${local.prefix}-health-check-failure"
  alarm_description   = "API health check failing"
  namespace           = "AWS/Lambda"
  metric_name         = "Errors"
  statistic           = "Sum"
  period              = 300
  evaluation_periods  = 2
  threshold           = 1
  comparison_operator = "GreaterThanOrEqualToThreshold"
  treat_missing_data  = "breaching"

  dimensions = {
    FunctionName = aws_lambda_function.health_check.function_name
  }

  alarm_actions = [aws_sns_topic.alarms.arn]
  ok_actions    = [aws_sns_topic.alarms.arn]
}
