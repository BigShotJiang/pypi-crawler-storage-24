output "deployer_role_arn" {
  description = "IAM role ARN for GitHub Actions to assume."
  value       = aws_iam_role.deployer.arn
}

output "state_bucket" {
  description = "S3 bucket for Terraform remote state."
  value       = aws_s3_bucket.tfstate.bucket
}

output "lock_table" {
  description = "DynamoDB table for Terraform state locking."
  value       = aws_dynamodb_table.tflock.name
}

output "oidc_provider_arn" {
  description = "GitHub OIDC provider ARN."
  value       = aws_iam_openid_connect_provider.github.arn
}

output "next_steps" {
  description = "Instructions for wiring up CI."
  value       = <<-EOT

    ======================================================================
    Bootstrap complete!
    ======================================================================

    1. Create terraform/backend.hcl with these values:

         bucket         = "${aws_s3_bucket.tfstate.bucket}"
         key            = "delivery-machine/terraform.tfstate"
         region         = "${var.aws_region}"
         dynamodb_table = "${aws_dynamodb_table.tflock.name}"

    2. Set these GitHub repo secrets/variables:

       Secrets:
         AWS_DEPLOY_ROLE_ARN  = ${aws_iam_role.deployer.arn}
         TF_VAR_forward_from_email = <your verified SES email>

       Variables (optional):
         TF_VAR_aws_region    = ${var.aws_region}

    3. Re-initialise the main Terraform config with the S3 backend:

         cd ../
         terraform init -backend-config=backend.hcl

    4. Push to the repo — the CI pipeline will handle plan/apply.

    ======================================================================
  EOT
}
