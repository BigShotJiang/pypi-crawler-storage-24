# ── Bootstrap: OIDC provider, deployer role, remote state backend ────────
#
# Run this ONCE manually (with admin credentials) before the CI pipeline
# can operate. It creates the trust relationship that lets GitHub Actions
# assume an IAM role, plus the S3/DynamoDB backend for Terraform state.
#
# Usage:
#   cd terraform/bootstrap
#   terraform init
#   terraform apply -var account_id=123456789012
#
# After apply, copy the outputs into:
#   - terraform/backend.hcl           (bucket, dynamodb_table, region)
#   - .github/workflows/infra.yml     (role ARN)

terraform {
  required_version = ">= 1.5"

  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
  }
}

provider "aws" {
  region = var.aws_region

  default_tags {
    tags = {
      Project   = "delivery-machine"
      ManagedBy = "terraform-bootstrap"
    }
  }
}

# ── Variables ──────────────────────────────────────────────────────────────

variable "aws_region" {
  description = "AWS region for all resources."
  type        = string
  default     = "us-east-1"
}

variable "github_repo" {
  description = "GitHub repo in owner/name format."
  type        = string
  default     = "BarkingIguana/delivery-machine"
}

variable "account_id" {
  description = "AWS account ID (used to scope resource ARNs in the policy)."
  type        = string
}

variable "state_bucket_name" {
  description = "Name for the Terraform state S3 bucket."
  type        = string
  default     = "delivery-machine-tfstate"
}

variable "lock_table_name" {
  description = "Name for the DynamoDB state-lock table."
  type        = string
  default     = "delivery-machine-tflock"
}

# ── GitHub OIDC provider ─────────────────────────────────────────────────

resource "aws_iam_openid_connect_provider" "github" {
  url             = "https://token.actions.githubusercontent.com"
  client_id_list  = ["sts.amazonaws.com"]
  thumbprint_list = ["ffffffffffffffffffffffffffffffffffffffff"]
}

# ── Deployer IAM role ────────────────────────────────────────────────────

resource "aws_iam_role" "deployer" {
  name = "delivery-machine-deployer"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid    = "AllowGitHubOIDC"
        Effect = "Allow"
        Principal = {
          Federated = aws_iam_openid_connect_provider.github.arn
        }
        Action = "sts:AssumeRoleWithWebIdentity"
        Condition = {
          StringEquals = {
            "token.actions.githubusercontent.com:aud" = "sts.amazonaws.com"
          }
          StringLike = {
            "token.actions.githubusercontent.com:sub" = "repo:${lower(var.github_repo)}:*"
          }
        }
      }
    ]
  })

  max_session_duration = 3600
}

# ── Deployer policies: customer-managed (6KB each) instead of inline (10KB total) ─

resource "aws_iam_policy" "deployer_infra" {
  name = "delivery-machine-deployer-infra"

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid    = "TerraformStateS3"
        Effect = "Allow"
        Action = ["s3:GetObject", "s3:PutObject", "s3:DeleteObject", "s3:ListBucket"]
        Resource = [
          "arn:aws:s3:::${var.state_bucket_name}",
          "arn:aws:s3:::${var.state_bucket_name}/*",
        ]
      },
      {
        Sid    = "TerraformStateLock"
        Effect = "Allow"
        Action = ["dynamodb:GetItem", "dynamodb:PutItem", "dynamodb:DeleteItem"]
        Resource = "arn:aws:dynamodb:${var.aws_region}:${var.account_id}:table/${var.lock_table_name}"
      },
      {
        Sid    = "S3Buckets"
        Effect = "Allow"
        Action = [
          "s3:CreateBucket", "s3:DeleteBucket", "s3:ListBucket",
          "s3:GetBucketLocation", "s3:GetBucketPolicy", "s3:PutBucketPolicy", "s3:DeleteBucketPolicy",
          "s3:GetBucketAcl", "s3:GetBucketCORS", "s3:PutBucketCORS",
          "s3:GetBucketVersioning", "s3:PutBucketVersioning",
          "s3:GetBucketTagging", "s3:PutBucketTagging",
          "s3:GetBucketLogging", "s3:PutBucketLogging",
          "s3:GetEncryptionConfiguration", "s3:PutEncryptionConfiguration",
          "s3:GetLifecycleConfiguration", "s3:PutLifecycleConfiguration",
          "s3:GetBucketPublicAccessBlock", "s3:PutBucketPublicAccessBlock",
          "s3:GetBucketNotification", "s3:PutBucketNotification",
          "s3:GetBucketObjectLockConfiguration",
          "s3:GetObject", "s3:PutObject", "s3:DeleteObject",
          "s3:GetObjectTagging", "s3:PutObjectTagging",
          "s3:GetBucketWebsite", "s3:PutBucketWebsite", "s3:DeleteBucketWebsite",
          "s3:GetAccelerateConfiguration", "s3:GetBucketRequestPayment",
          "s3:GetReplicationConfiguration", "s3:GetAnalyticsConfiguration",
          "s3:GetIntelligentTieringConfiguration", "s3:GetInventoryConfiguration",
          "s3:GetMetricsConfiguration",
        ]
        Resource = [
          "arn:aws:s3:::delivery-machine-emails-${var.account_id}",
          "arn:aws:s3:::delivery-machine-emails-${var.account_id}/*",
          "arn:aws:s3:::delivery-machine-site-${var.account_id}",
          "arn:aws:s3:::delivery-machine-site-${var.account_id}/*",
        ]
      },
      {
        Sid    = "DynamoDB"
        Effect = "Allow"
        Action = [
          "dynamodb:CreateTable", "dynamodb:DeleteTable", "dynamodb:DescribeTable",
          "dynamodb:DescribeTimeToLive", "dynamodb:UpdateTimeToLive",
          "dynamodb:DescribeContinuousBackups", "dynamodb:UpdateContinuousBackups",
          "dynamodb:ListTagsOfResource", "dynamodb:TagResource", "dynamodb:UntagResource",
          "dynamodb:UpdateTable",
          "dynamodb:CreateGlobalSecondaryIndex", "dynamodb:DeleteGlobalSecondaryIndex",
          "dynamodb:UpdateGlobalSecondaryIndex",
        ]
        Resource = [
          "arn:aws:dynamodb:${var.aws_region}:${var.account_id}:table/delivery-machine-rules",
          "arn:aws:dynamodb:${var.aws_region}:${var.account_id}:table/delivery-machine-rules/index/*",
          "arn:aws:dynamodb:${var.aws_region}:${var.account_id}:table/delivery-machine-domains",
          "arn:aws:dynamodb:${var.aws_region}:${var.account_id}:table/delivery-machine-tenants",
          "arn:aws:dynamodb:${var.aws_region}:${var.account_id}:table/delivery-machine-verifications",
          "arn:aws:dynamodb:${var.aws_region}:${var.account_id}:table/delivery-machine-events",
          "arn:aws:dynamodb:${var.aws_region}:${var.account_id}:table/delivery-machine-users",
          "arn:aws:dynamodb:${var.aws_region}:${var.account_id}:table/delivery-machine-device-codes",
        ]
      },
      {
        Sid    = "Lambda"
        Effect = "Allow"
        Action = [
          "lambda:CreateFunction", "lambda:DeleteFunction",
          "lambda:GetFunction", "lambda:GetFunctionConfiguration", "lambda:GetFunctionCodeSigningConfig",
          "lambda:UpdateFunctionCode", "lambda:UpdateFunctionConfiguration",
          "lambda:ListVersionsByFunction", "lambda:GetPolicy",
          "lambda:AddPermission", "lambda:RemovePermission",
          "lambda:TagResource", "lambda:UntagResource", "lambda:ListTags",
          "lambda:PublishVersion",
          "lambda:PutFunctionConcurrency", "lambda:DeleteFunctionConcurrency",
          "lambda:CreateAlias", "lambda:DeleteAlias", "lambda:GetAlias", "lambda:UpdateAlias",
        ]
        Resource = [
          "arn:aws:lambda:${var.aws_region}:${var.account_id}:function:delivery-machine-forwarder",
          "arn:aws:lambda:${var.aws_region}:${var.account_id}:function:delivery-machine-forwarder:*",
          "arn:aws:lambda:${var.aws_region}:${var.account_id}:function:delivery-machine-api",
          "arn:aws:lambda:${var.aws_region}:${var.account_id}:function:delivery-machine-api:*",
          "arn:aws:lambda:${var.aws_region}:${var.account_id}:function:delivery-machine-reporter",
          "arn:aws:lambda:${var.aws_region}:${var.account_id}:function:delivery-machine-reporter:*",
          "arn:aws:lambda:${var.aws_region}:${var.account_id}:function:delivery-machine-health-check",
          "arn:aws:lambda:${var.aws_region}:${var.account_id}:function:delivery-machine-health-check:*",
        ]
      },
      {
        Sid    = "LambdaLayers"
        Effect = "Allow"
        Action = [
          "lambda:PublishLayerVersion", "lambda:DeleteLayerVersion",
          "lambda:GetLayerVersion", "lambda:ListLayerVersions",
        ]
        Resource = [
          "arn:aws:lambda:${var.aws_region}:${var.account_id}:layer:delivery-machine-*",
        ]
      },
    ]
  })
}

resource "aws_iam_policy" "deployer_iam" {
  name = "delivery-machine-deployer-iam"

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid    = "IAMRoles"
        Effect = "Allow"
        Action = [
          "iam:CreateRole", "iam:DeleteRole", "iam:GetRole", "iam:UpdateRole",
          "iam:UpdateAssumeRolePolicy",
          "iam:ListRolePolicies", "iam:ListAttachedRolePolicies", "iam:ListInstanceProfilesForRole",
          "iam:PutRolePolicy", "iam:GetRolePolicy", "iam:DeleteRolePolicy",
          "iam:TagRole", "iam:UntagRole", "iam:ListRoleTags",
          "iam:AttachRolePolicy", "iam:DetachRolePolicy",
        ]
        Resource = [
          "arn:aws:iam::${var.account_id}:role/delivery-machine-forwarder",
          "arn:aws:iam::${var.account_id}:role/delivery-machine-api",
          "arn:aws:iam::${var.account_id}:role/delivery-machine-codedeploy",
          "arn:aws:iam::${var.account_id}:role/delivery-machine-github-actions",
          "arn:aws:iam::${var.account_id}:role/delivery-machine-reporter",
          "arn:aws:iam::${var.account_id}:role/delivery-machine-health-check",
        ]
      },
      {
        Sid    = "IAMPassRole"
        Effect = "Allow"
        Action = "iam:PassRole"
        Resource = [
          "arn:aws:iam::${var.account_id}:role/delivery-machine-forwarder",
          "arn:aws:iam::${var.account_id}:role/delivery-machine-api",
          "arn:aws:iam::${var.account_id}:role/delivery-machine-codedeploy",
          "arn:aws:iam::${var.account_id}:role/delivery-machine-reporter",
          "arn:aws:iam::${var.account_id}:role/delivery-machine-health-check",
        ]
        Condition = {
          StringEquals = {
            "iam:PassedToService" = ["lambda.amazonaws.com", "codedeploy.amazonaws.com"]
          }
        }
      },
      {
        Sid      = "OIDCProviderRead"
        Effect   = "Allow"
        Action   = ["iam:GetOpenIDConnectProvider", "iam:ListOpenIDConnectProviders"]
        Resource = "*"
      },
      {
        Sid      = "STSGetCaller"
        Effect   = "Allow"
        Action   = "sts:GetCallerIdentity"
        Resource = "*"
      },
      {
        Sid    = "CodeDeploy"
        Effect = "Allow"
        Action = [
          "codedeploy:CreateApplication", "codedeploy:DeleteApplication", "codedeploy:GetApplication",
          "codedeploy:CreateDeploymentGroup", "codedeploy:DeleteDeploymentGroup",
          "codedeploy:GetDeploymentGroup", "codedeploy:UpdateDeploymentGroup",
          "codedeploy:CreateDeployment", "codedeploy:GetDeployment", "codedeploy:StopDeployment",
          "codedeploy:TagResource", "codedeploy:UntagResource", "codedeploy:ListTagsForResource",
          "codedeploy:GetDeploymentConfig", "codedeploy:RegisterApplicationRevision",
        ]
        Resource = [
          "arn:aws:codedeploy:${var.aws_region}:${var.account_id}:application:delivery-machine-lambda",
          "arn:aws:codedeploy:${var.aws_region}:${var.account_id}:deploymentgroup:delivery-machine-lambda/*",
          "arn:aws:codedeploy:${var.aws_region}:${var.account_id}:deploymentconfig:*",
        ]
      },
      {
        Sid    = "APIGateway"
        Effect = "Allow"
        Action = [
          "apigateway:GET", "apigateway:POST", "apigateway:PUT",
          "apigateway:PATCH", "apigateway:DELETE", "apigateway:UpdateRestApiPolicy",
        ]
        Resource = [
          "arn:aws:apigateway:${var.aws_region}::/restapis",
          "arn:aws:apigateway:${var.aws_region}::/restapis/*",
          "arn:aws:apigateway:${var.aws_region}::/apikeys",
          "arn:aws:apigateway:${var.aws_region}::/apikeys/*",
          "arn:aws:apigateway:${var.aws_region}::/usageplans",
          "arn:aws:apigateway:${var.aws_region}::/usageplans/*",
          "arn:aws:apigateway:${var.aws_region}::/tags/*",
          "arn:aws:apigateway:${var.aws_region}::/domainnames",
          "arn:aws:apigateway:${var.aws_region}::/domainnames/*",
        ]
      },
    ]
  })
}

resource "aws_iam_policy" "deployer_services" {
  name = "delivery-machine-deployer-services"

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid    = "SES"
        Effect = "Allow"
        Action = [
          "ses:CreateReceiptRuleSet", "ses:DeleteReceiptRuleSet",
          "ses:DescribeReceiptRuleSet", "ses:DescribeActiveReceiptRuleSet",
          "ses:SetActiveReceiptRuleSet",
          "ses:CreateReceiptRule", "ses:DeleteReceiptRule",
          "ses:DescribeReceiptRule", "ses:UpdateReceiptRule",
          "ses:VerifyEmailIdentity", "ses:VerifyDomainIdentity", "ses:VerifyDomainDkim",
          "ses:GetIdentityDkimAttributes", "ses:DeleteIdentity",
          "ses:GetIdentityVerificationAttributes", "ses:ListIdentities",
          "ses:CreateConfigurationSet", "ses:DeleteConfigurationSet", "ses:GetConfigurationSet",
          "ses:CreateConfigurationSetEventDestination", "ses:DeleteConfigurationSetEventDestination",
          "ses:UpdateConfigurationSetEventDestination", "ses:GetConfigurationSetEventDestinations",
          "ses:TagResource", "ses:UntagResource", "ses:ListTagsForResource",
        ]
        Resource = "*"
      },
      {
        Sid    = "CloudFront"
        Effect = "Allow"
        Action = [
          "cloudfront:CreateDistribution", "cloudfront:DeleteDistribution",
          "cloudfront:GetDistribution", "cloudfront:UpdateDistribution",
          "cloudfront:TagResource", "cloudfront:UntagResource", "cloudfront:ListTagsForResource",
          "cloudfront:CreateOriginAccessControl", "cloudfront:DeleteOriginAccessControl",
          "cloudfront:GetOriginAccessControl", "cloudfront:UpdateOriginAccessControl",
          "cloudfront:ListOriginAccessControls", "cloudfront:CreateInvalidation",
          "cloudfront:CreateFunction", "cloudfront:DeleteFunction",
          "cloudfront:DescribeFunction", "cloudfront:GetFunction",
          "cloudfront:UpdateFunction", "cloudfront:PublishFunction",
        ]
        Resource = "*"
      },
      {
        Sid    = "ACM"
        Effect = "Allow"
        Action = [
          "acm:RequestCertificate", "acm:DeleteCertificate",
          "acm:DescribeCertificate", "acm:ListCertificates", "acm:GetCertificate",
          "acm:ListTagsForCertificate", "acm:AddTagsToCertificate", "acm:RemoveTagsFromCertificate",
        ]
        Resource = "*"
      },
      {
        Sid    = "Route53"
        Effect = "Allow"
        Action = [
          "route53:CreateHostedZone", "route53:DeleteHostedZone",
          "route53:GetHostedZone", "route53:ListHostedZones", "route53:GetHostedZoneCount",
          "route53:ListResourceRecordSets", "route53:ChangeResourceRecordSets",
          "route53:GetChange", "route53:ListTagsForResource", "route53:ChangeTagsForResource",
        ]
        Resource = "*"
      },
      {
        Sid      = "CloudWatchLogsDescribe"
        Effect   = "Allow"
        Action   = "logs:DescribeLogGroups"
        Resource = "*"
      },
      {
        Sid    = "CloudWatchLogs"
        Effect = "Allow"
        Action = [
          "logs:CreateLogGroup", "logs:DeleteLogGroup",
          "logs:PutRetentionPolicy", "logs:DeleteRetentionPolicy",
          "logs:ListTagsForResource", "logs:TagResource", "logs:UntagResource",
          "logs:ListTagsLogGroup", "logs:TagLogGroup", "logs:UntagLogGroup",
        ]
        Resource = [
          "arn:aws:logs:${var.aws_region}:${var.account_id}:log-group:/aws/lambda/delivery-machine-forwarder",
          "arn:aws:logs:${var.aws_region}:${var.account_id}:log-group:/aws/lambda/delivery-machine-forwarder:*",
          "arn:aws:logs:${var.aws_region}:${var.account_id}:log-group:/aws/lambda/delivery-machine-api",
          "arn:aws:logs:${var.aws_region}:${var.account_id}:log-group:/aws/lambda/delivery-machine-api:*",
          "arn:aws:logs:${var.aws_region}:${var.account_id}:log-group:/aws/lambda/delivery-machine-reporter",
          "arn:aws:logs:${var.aws_region}:${var.account_id}:log-group:/aws/lambda/delivery-machine-reporter:*",
          "arn:aws:logs:${var.aws_region}:${var.account_id}:log-group:/aws/lambda/delivery-machine-health-check",
          "arn:aws:logs:${var.aws_region}:${var.account_id}:log-group:/aws/lambda/delivery-machine-health-check:*",
        ]
      },
      {
        Sid    = "SSMParameters"
        Effect = "Allow"
        Action = [
          "ssm:PutParameter", "ssm:GetParameter", "ssm:GetParameters",
          "ssm:DeleteParameter",
          "ssm:ListTagsForResource", "ssm:AddTagsToResource", "ssm:RemoveTagsFromResource",
        ]
        Resource = "arn:aws:ssm:${var.aws_region}:${var.account_id}:parameter/delivery-machine/*"
      },
      {
        Sid      = "SSMDescribe"
        Effect   = "Allow"
        Action   = "ssm:DescribeParameters"
        Resource = "*"
      },
      {
        Sid    = "CloudWatchAlarms"
        Effect = "Allow"
        Action = [
          "cloudwatch:PutMetricAlarm", "cloudwatch:DeleteAlarms", "cloudwatch:DescribeAlarms",
          "cloudwatch:ListTagsForResource", "cloudwatch:TagResource", "cloudwatch:UntagResource",
        ]
        Resource = "arn:aws:cloudwatch:${var.aws_region}:${var.account_id}:alarm:delivery-machine-*"
      },
      {
        Sid    = "CloudWatchDashboards"
        Effect = "Allow"
        Action = ["cloudwatch:PutDashboard", "cloudwatch:DeleteDashboards", "cloudwatch:GetDashboard", "cloudwatch:ListDashboards"]
        Resource = "arn:aws:cloudwatch::${var.account_id}:dashboard/delivery-machine-*"
      },
      {
        Sid    = "SNS"
        Effect = "Allow"
        Action = [
          "sns:CreateTopic", "sns:DeleteTopic",
          "sns:GetTopicAttributes", "sns:SetTopicAttributes",
          "sns:Subscribe", "sns:Unsubscribe", "sns:GetSubscriptionAttributes",
          "sns:ListTagsForResource", "sns:TagResource", "sns:UntagResource",
        ]
        Resource = "arn:aws:sns:${var.aws_region}:${var.account_id}:delivery-machine-*"
      },
      {
        Sid    = "EventBridge"
        Effect = "Allow"
        Action = [
          "events:PutRule", "events:DeleteRule", "events:DescribeRule",
          "events:PutTargets", "events:RemoveTargets", "events:ListTargetsByRule",
          "events:ListTagsForResource", "events:TagResource", "events:UntagResource",
        ]
        Resource = "arn:aws:events:${var.aws_region}:${var.account_id}:rule/delivery-machine-*"
      },
    ]
  })
}

resource "aws_iam_role_policy_attachment" "deployer_infra" {
  role       = aws_iam_role.deployer.name
  policy_arn = aws_iam_policy.deployer_infra.arn
}

resource "aws_iam_role_policy_attachment" "deployer_iam" {
  role       = aws_iam_role.deployer.name
  policy_arn = aws_iam_policy.deployer_iam.arn
}

resource "aws_iam_role_policy_attachment" "deployer_services" {
  role       = aws_iam_role.deployer.name
  policy_arn = aws_iam_policy.deployer_services.arn
}

# ── Terraform state S3 bucket ─────────────────────────────────────────────

resource "aws_s3_bucket" "tfstate" {
  bucket = var.state_bucket_name

  lifecycle {
    prevent_destroy = true
  }
}

resource "aws_s3_bucket_versioning" "tfstate" {
  bucket = aws_s3_bucket.tfstate.id
  versioning_configuration {
    status = "Enabled"
  }
}

resource "aws_s3_bucket_server_side_encryption_configuration" "tfstate" {
  bucket = aws_s3_bucket.tfstate.id
  rule {
    apply_server_side_encryption_by_default {
      sse_algorithm = "AES256"
    }
  }
}

resource "aws_s3_bucket_public_access_block" "tfstate" {
  bucket                  = aws_s3_bucket.tfstate.id
  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}

# ── Terraform state lock DynamoDB table ──────────────────────────────────

resource "aws_dynamodb_table" "tflock" {
  name         = var.lock_table_name
  billing_mode = "PAY_PER_REQUEST"
  hash_key     = "LockID"

  attribute {
    name = "LockID"
    type = "S"
  }

  lifecycle {
    prevent_destroy = true
  }
}
