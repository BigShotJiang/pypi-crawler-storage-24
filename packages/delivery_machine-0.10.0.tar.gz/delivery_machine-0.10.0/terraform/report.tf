# ── Daily status report Lambda + EventBridge schedule ────────────────────
#
# Runs daily at 21:00 UTC (5 AM AWST) and sends an HTML email summary
# of the last 24 hours of platform activity.

data "archive_file" "reporter" {
  type        = "zip"
  source_dir  = "${path.module}/../lambda/reporter"
  output_path = "${path.module}/.build/reporter.zip"
}

resource "aws_lambda_function" "reporter" {
  filename         = data.archive_file.reporter.output_path
  source_code_hash = data.archive_file.reporter.output_base64sha256
  function_name    = "${local.prefix}-reporter"
  role             = aws_iam_role.reporter.arn
  handler          = "handler.handler"
  runtime          = "python3.12"
  architectures    = ["arm64"]
  timeout          = 120
  memory_size      = 128

  environment {
    variables = {
      ENVIRONMENT        = var.environment
      REPORT_RECIPIENT   = var.alert_email
      SENDER_EMAIL       = var.forward_from_email
      FORWARD_FROM       = var.forward_from_email
      FORWARDER_FUNCTION = aws_lambda_function.forwarder.function_name
      API_FUNCTION       = aws_lambda_function.api.function_name
      API_NAME           = aws_api_gateway_rest_api.main.name
      RULES_TABLE        = aws_dynamodb_table.rules.name
      DOMAINS_TABLE      = aws_dynamodb_table.domains.name
      USERS_TABLE        = aws_dynamodb_table.users.name
      TENANTS_TABLE      = aws_dynamodb_table.tenants.name
    }
  }
}

resource "aws_cloudwatch_log_group" "reporter" {
  name              = "/aws/lambda/${aws_lambda_function.reporter.function_name}"
  retention_in_days = var.lambda_log_retention_days
}

# ── Reporter IAM role ──────────────────────────────────────────────────────

resource "aws_iam_role" "reporter" {
  name = "${local.prefix}-reporter"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = { Service = "lambda.amazonaws.com" }
      Action    = "sts:AssumeRole"
    }]
  })
}

resource "aws_iam_role_policy" "reporter" {
  name = "${local.prefix}-reporter"
  role = aws_iam_role.reporter.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid      = "Logs"
        Effect   = "Allow"
        Action   = ["logs:CreateLogGroup", "logs:CreateLogStream", "logs:PutLogEvents"]
        Resource = "arn:aws:logs:*:*:*"
      },
      {
        Sid    = "CloudWatchMetrics"
        Effect = "Allow"
        Action = [
          "cloudwatch:GetMetricData",
          "cloudwatch:GetMetricStatistics",
        ]
        Resource = "*"
      },
      {
        Sid    = "DynamoDBRead"
        Effect = "Allow"
        Action = [
          "dynamodb:Scan",
          "dynamodb:DescribeTable",
        ]
        Resource = [
          aws_dynamodb_table.rules.arn,
          aws_dynamodb_table.domains.arn,
          aws_dynamodb_table.users.arn,
          aws_dynamodb_table.tenants.arn,
        ]
      },
      {
        Sid      = "SES"
        Effect   = "Allow"
        Action   = ["ses:SendEmail"]
        Resource = "*"
      },
    ]
  })
}

# ── EventBridge schedule ──────────────────────────────────────────────────

resource "aws_cloudwatch_event_rule" "daily_report" {
  name                = "${local.prefix}-daily-report"
  description         = "Trigger daily status report at 21:00 UTC (5 AM AWST)"
  schedule_expression = "cron(0 21 * * ? *)"
}

resource "aws_cloudwatch_event_target" "daily_report" {
  rule = aws_cloudwatch_event_rule.daily_report.name
  arn  = aws_lambda_function.reporter.arn
}

resource "aws_lambda_permission" "eventbridge_reporter" {
  statement_id  = "AllowEventBridgeInvoke"
  action        = "lambda:InvokeFunction"
  function_name = aws_lambda_function.reporter.function_name
  principal     = "events.amazonaws.com"
  source_arn    = aws_cloudwatch_event_rule.daily_report.arn
}
