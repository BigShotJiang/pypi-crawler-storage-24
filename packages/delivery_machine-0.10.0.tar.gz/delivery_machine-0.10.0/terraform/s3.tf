# ── Email storage bucket ───────────────────────────────────────────────────

resource "aws_s3_bucket" "emails" {
  # Bucket names must be globally unique; include account ID to be safe.
  bucket = "${local.prefix}-emails-${data.aws_caller_identity.current.account_id}"
}

resource "aws_s3_bucket_server_side_encryption_configuration" "emails" {
  bucket = aws_s3_bucket.emails.id
  rule {
    apply_server_side_encryption_by_default {
      sse_algorithm = "AES256"
    }
  }
}

resource "aws_s3_bucket_public_access_block" "emails" {
  bucket                  = aws_s3_bucket.emails.id
  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}

resource "aws_s3_bucket_lifecycle_configuration" "emails" {
  bucket = aws_s3_bucket.emails.id

  rule {
    id     = "expire-incoming"
    status = "Enabled"
    filter { prefix = "incoming/" }
    expiration { days = var.email_retention_days }
  }

  rule {
    id     = "abort-multipart"
    status = "Enabled"
    filter { prefix = "" }
    abort_incomplete_multipart_upload { days_after_initiation = 1 }
  }
}

# SES needs permission to write objects to this bucket.
resource "aws_s3_bucket_policy" "emails" {
  bucket = aws_s3_bucket.emails.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid    = "AllowSESPuts"
        Effect = "Allow"
        Principal = { Service = "ses.amazonaws.com" }
        Action   = "s3:PutObject"
        Resource = "${aws_s3_bucket.emails.arn}/incoming/*"
        Condition = {
          StringEquals = {
            "aws:Referer" = data.aws_caller_identity.current.account_id
          }
        }
      }
    ]
  })
}

# S3 notifies the forwarder Lambda when new emails land.
resource "aws_s3_bucket_notification" "emails" {
  bucket = aws_s3_bucket.emails.id

  lambda_function {
    lambda_function_arn = aws_lambda_alias.forwarder_live.arn
    events              = ["s3:ObjectCreated:*"]
    filter_prefix       = "incoming/"
  }

  depends_on = [aws_lambda_permission.s3_invoke_forwarder]
}
