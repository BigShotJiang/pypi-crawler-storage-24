# ── Lambda packaging ───────────────────────────────────────────────────────

data "archive_file" "forwarder" {
  type        = "zip"
  source_dir  = "${path.module}/../lambda/forwarder"
  output_path = "${path.module}/.build/forwarder.zip"
}

data "archive_file" "api" {
  type        = "zip"
  source_dir  = "${path.module}/../lambda/api"
  output_path = "${path.module}/.build/api.zip"
}

# ── Forwarder Lambda ───────────────────────────────────────────────────────

resource "aws_lambda_function" "forwarder" {
  filename         = data.archive_file.forwarder.output_path
  source_code_hash = data.archive_file.forwarder.output_base64sha256
  function_name    = "${local.prefix}-forwarder"
  role             = aws_iam_role.forwarder.arn
  handler          = "handler.handler"
  runtime          = "python3.12"
  architectures    = ["arm64"]
  timeout          = 30
  memory_size      = 256
  publish          = true
  layers           = [aws_lambda_layer_version.dkimpy.arn]

  environment {
    variables = {
      RULES_TABLE             = aws_dynamodb_table.rules.name
      EMAIL_BUCKET            = aws_s3_bucket.emails.bucket
      FORWARD_FROM            = var.forward_from_email
      SES_REGION              = var.aws_region
      TENANTS_TABLE           = aws_dynamodb_table.tenants.name
      VERIFICATIONS_TABLE     = aws_dynamodb_table.verifications.name
      API_BASE_URL            = "https://api.${var.site_domain}/v1"
      ARC_PRIVATE_KEY_PARAM   = aws_ssm_parameter.arc_private_key.name
      ARC_SELECTOR            = "arc"
      ARC_DOMAIN              = var.site_domain
      SES_CONFIGURATION_SET   = aws_sesv2_configuration_set.main.configuration_set_name
    }
  }
}

resource "aws_cloudwatch_log_group" "forwarder" {
  name              = "/aws/lambda/${aws_lambda_function.forwarder.function_name}"
  retention_in_days = var.lambda_log_retention_days
}

# S3 permission to invoke the forwarder alias
resource "aws_lambda_permission" "s3_invoke_forwarder" {
  statement_id  = "AllowS3Invoke"
  action        = "lambda:InvokeFunction"
  function_name = aws_lambda_function.forwarder.function_name
  qualifier     = aws_lambda_alias.forwarder_live.name
  principal     = "s3.amazonaws.com"
  source_arn    = aws_s3_bucket.emails.arn
}

# ── API Lambda ─────────────────────────────────────────────────────────────

resource "aws_lambda_function" "api" {
  filename         = data.archive_file.api.output_path
  source_code_hash = data.archive_file.api.output_base64sha256
  function_name    = "${local.prefix}-api"
  role             = aws_iam_role.api.arn
  handler          = "handler.handler"
  runtime          = "python3.12"
  architectures    = ["arm64"]
  timeout          = 30
  memory_size      = 128
  publish          = true
  layers           = [aws_lambda_layer_version.auth.arn]

  environment {
    variables = {
      RULES_TABLE          = aws_dynamodb_table.rules.name
      DOMAINS_TABLE        = aws_dynamodb_table.domains.name
      TENANTS_TABLE        = aws_dynamodb_table.tenants.name
      SES_REGION           = var.aws_region
      VERIFICATIONS_TABLE  = aws_dynamodb_table.verifications.name
      EVENTS_TABLE         = aws_dynamodb_table.events.name
      FORWARD_FROM         = var.forward_from_email
      API_BASE_URL         = "https://api.${var.site_domain}/v1"
      USERS_TABLE          = aws_dynamodb_table.users.name
      DEVICE_CODES_TABLE   = aws_dynamodb_table.device_codes.name
      JWT_SECRET_PARAM     = aws_ssm_parameter.jwt_secret.name
      SITE_URL             = "https://${var.site_domain}"
      CLI_LATEST_VERSION   = var.cli_latest_version
      CLI_MIN_VERSION      = var.cli_min_version
    }
  }
}

resource "aws_cloudwatch_log_group" "api" {
  name              = "/aws/lambda/${aws_lambda_function.api.function_name}"
  retention_in_days = var.lambda_log_retention_days
}

# API Gateway permission to invoke the API Lambda alias
resource "aws_lambda_permission" "api_gateway_invoke" {
  statement_id  = "AllowAPIGatewayInvoke"
  action        = "lambda:InvokeFunction"
  function_name = aws_lambda_function.api.function_name
  qualifier     = aws_lambda_alias.api_live.name
  principal     = "apigateway.amazonaws.com"
  source_arn    = "${aws_api_gateway_rest_api.main.execution_arn}/*/*"
}
