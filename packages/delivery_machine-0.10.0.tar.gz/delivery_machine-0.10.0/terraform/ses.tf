# ── SES receipt rule set ───────────────────────────────────────────────────
#
# Only one rule set can be active at a time in a region.
# If you already have an active rule set, import it or adjust the name.

resource "aws_ses_receipt_rule_set" "main" {
  rule_set_name = local.prefix
}

resource "aws_ses_active_receipt_rule_set" "main" {
  rule_set_name = aws_ses_receipt_rule_set.main.rule_set_name
}

# ── Receipt rule ───────────────────────────────────────────────────────────
#
# recipients = [] means "apply to all verified domains".
# SES stores raw email to S3; S3 then triggers the forwarder Lambda.
# scan_enabled runs SES spam/virus checks — recommended.

resource "aws_ses_receipt_rule" "store_incoming" {
  name          = "store-incoming"
  rule_set_name = aws_ses_receipt_rule_set.main.rule_set_name
  recipients    = []   # catch-all for all verified domains
  enabled       = true
  scan_enabled  = true

  s3_action {
    bucket_name       = aws_s3_bucket.emails.bucket
    object_key_prefix = "incoming/"
    position          = 1
  }

  depends_on = [aws_s3_bucket_policy.emails]
}

# ── Verify the forwarding From: address ───────────────────────────────────
#
# SES requires the Source address in send_raw_email to be a verified identity.
# This resource triggers a verification email; check your inbox and click the link.
#
# Alternatively, verify the whole domain (via POST /v1/domains) and SES will
# accept any address at that domain without individual verification.

resource "aws_ses_email_identity" "forward_from" {
  email = var.forward_from_email
}

# ── SES domain identity + DKIM ─────────────────────────────────────────────
#
# Verifying the whole domain lets SES send from any address @deliverymachine.net.
# DKIM signing improves deliverability and prevents spoofing warnings.

resource "aws_ses_domain_identity" "site" {
  domain = var.site_domain
}

resource "aws_ses_domain_dkim" "site" {
  domain = aws_ses_domain_identity.site.domain
}

# ── SES configuration set (for CloudWatch metrics) ───────────────────────
#
# Publishes bounce, complaint, send, and reject events to CloudWatch so
# we can alarm on reputation metrics.

resource "aws_sesv2_configuration_set" "main" {
  configuration_set_name = local.prefix

  reputation_options {
    reputation_metrics_enabled = true
  }

  sending_options {
    sending_enabled = true
  }
}

resource "aws_sesv2_configuration_set_event_destination" "cloudwatch" {
  configuration_set_name = aws_sesv2_configuration_set.main.configuration_set_name
  event_destination_name = "cloudwatch"

  event_destination {
    enabled              = true
    matching_event_types = ["SEND", "REJECT", "BOUNCE", "COMPLAINT", "DELIVERY"]

    cloud_watch_destination {
      dimension_configuration {
        default_dimension_value = "default"
        dimension_name          = "ses:configuration-set"
        dimension_value_source  = "MESSAGE_TAG"
      }
    }
  }
}
