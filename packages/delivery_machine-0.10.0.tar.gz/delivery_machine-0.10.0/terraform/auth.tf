# ── Authentication infrastructure ──────────────────────────────────────────
#
# Supports TOTP login via browser + OAuth Device Flow for CLI.
# JWTs signed with HS256 using a secret in SSM Parameter Store.

# ── JWT signing secret ────────────────────────────────────────────────────

resource "random_password" "jwt_secret" {
  length  = 64
  special = false
}

resource "aws_ssm_parameter" "jwt_secret" {
  name        = "/${local.prefix}/jwt-secret"
  description = "HS256 secret for signing Delivery Machine JWT tokens"
  type        = "SecureString"
  value       = random_password.jwt_secret.result
  overwrite   = true
}

# ── DynamoDB: users ───────────────────────────────────────────────────────
#
# PK: email
# Stores TOTP secrets and tenant association.

resource "aws_dynamodb_table" "users" {
  name         = "${local.prefix}-users"
  billing_mode = "PAY_PER_REQUEST"
  hash_key     = "email"

  attribute {
    name = "email"
    type = "S"
  }

  point_in_time_recovery { enabled = true }
}

# ── DynamoDB: device_codes ────────────────────────────────────────────────
#
# PK: code (e.g. "ABCD-1234")
# Short-lived codes for OAuth Device Flow.
# TTL auto-expires codes after 10 minutes.

resource "aws_dynamodb_table" "device_codes" {
  name         = "${local.prefix}-device-codes"
  billing_mode = "PAY_PER_REQUEST"
  hash_key     = "code"

  attribute {
    name = "code"
    type = "S"
  }

  ttl {
    attribute_name = "expires_at"
    enabled        = true
  }

  point_in_time_recovery { enabled = false }
}

# ── Lambda layer: auth ────────────────────────────────────────────────────
#
# PyJWT + pyotp + qrcode — built by scripts/build-auth-layer.sh.

resource "aws_lambda_layer_version" "auth" {
  filename            = "${path.module}/.build/auth-layer.zip"
  source_code_hash    = filebase64sha256("${path.module}/.build/auth-layer.zip")
  layer_name          = "${local.prefix}-auth"
  compatible_runtimes = ["python3.12"]
  description         = "PyJWT + pyotp + qrcode for authentication"
}

# ── API Gateway: public /v1/auth/* routes ─────────────────────────────────
#
# Auth endpoints must be public (no API key) so CLI can authenticate.

resource "aws_api_gateway_resource" "auth" {
  rest_api_id = aws_api_gateway_rest_api.main.id
  parent_id   = aws_api_gateway_resource.v1.id
  path_part   = "auth"
}

resource "aws_api_gateway_resource" "auth_proxy" {
  rest_api_id = aws_api_gateway_rest_api.main.id
  parent_id   = aws_api_gateway_resource.auth.id
  path_part   = "{proxy+}"
}

resource "aws_api_gateway_method" "auth_any" {
  rest_api_id      = aws_api_gateway_rest_api.main.id
  resource_id      = aws_api_gateway_resource.auth.id
  http_method      = "ANY"
  authorization    = "NONE"
  api_key_required = false
}

resource "aws_api_gateway_integration" "auth_lambda" {
  rest_api_id             = aws_api_gateway_rest_api.main.id
  resource_id             = aws_api_gateway_resource.auth.id
  http_method             = aws_api_gateway_method.auth_any.http_method
  integration_http_method = "POST"
  type                    = "AWS_PROXY"
  uri                     = aws_lambda_alias.api_live.invoke_arn
}

resource "aws_api_gateway_method" "auth_proxy_any" {
  rest_api_id      = aws_api_gateway_rest_api.main.id
  resource_id      = aws_api_gateway_resource.auth_proxy.id
  http_method      = "ANY"
  authorization    = "NONE"
  api_key_required = false
}

resource "aws_api_gateway_integration" "auth_proxy_lambda" {
  rest_api_id             = aws_api_gateway_rest_api.main.id
  resource_id             = aws_api_gateway_resource.auth_proxy.id
  http_method             = aws_api_gateway_method.auth_proxy_any.http_method
  integration_http_method = "POST"
  type                    = "AWS_PROXY"
  uri                     = aws_lambda_alias.api_live.invoke_arn
}
