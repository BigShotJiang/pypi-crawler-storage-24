# ── Forwarder Lambda role ──────────────────────────────────────────────────

resource "aws_iam_role" "forwarder" {
  name = "${local.prefix}-forwarder"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = { Service = "lambda.amazonaws.com" }
      Action    = "sts:AssumeRole"
    }]
  })
}

resource "aws_iam_role_policy" "forwarder" {
  name = "${local.prefix}-forwarder"
  role = aws_iam_role.forwarder.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid      = "Logs"
        Effect   = "Allow"
        Action   = ["logs:CreateLogGroup", "logs:CreateLogStream", "logs:PutLogEvents"]
        Resource = "arn:aws:logs:*:*:*"
      },
      {
        Sid      = "ReadEmails"
        Effect   = "Allow"
        Action   = ["s3:GetObject"]
        Resource = "${aws_s3_bucket.emails.arn}/incoming/*"
      },
      {
        Sid      = "LookupRules"
        Effect   = "Allow"
        Action   = ["dynamodb:GetItem"]
        Resource = aws_dynamodb_table.rules.arn
      },
      {
        Sid    = "QuotaCheck"
        Effect = "Allow"
        Action = ["dynamodb:GetItem", "dynamodb:UpdateItem"]
        Resource = aws_dynamodb_table.tenants.arn
      },
      {
        Sid      = "SendForwards"
        Effect   = "Allow"
        Action   = ["ses:SendRawEmail"]
        Resource = "*"
      },
      {
        Sid      = "CheckVerification"
        Effect   = "Allow"
        Action   = ["dynamodb:GetItem"]
        Resource = aws_dynamodb_table.verifications.arn
      },
      {
        Sid      = "ArcSigningKey"
        Effect   = "Allow"
        Action   = ["ssm:GetParameter"]
        Resource = aws_ssm_parameter.arc_private_key.arn
      }
    ]
  })
}

# ── API Lambda role ────────────────────────────────────────────────────────

resource "aws_iam_role" "api" {
  name = "${local.prefix}-api"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = { Service = "lambda.amazonaws.com" }
      Action    = "sts:AssumeRole"
    }]
  })
}

resource "aws_iam_role_policy" "api" {
  name = "${local.prefix}-api"
  role = aws_iam_role.api.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid      = "Logs"
        Effect   = "Allow"
        Action   = ["logs:CreateLogGroup", "logs:CreateLogStream", "logs:PutLogEvents"]
        Resource = "arn:aws:logs:*:*:*"
      },
      {
        Sid    = "DynamoDB"
        Effect = "Allow"
        Action = [
          "dynamodb:GetItem",
          "dynamodb:PutItem",
          "dynamodb:UpdateItem",
          "dynamodb:DeleteItem",
          "dynamodb:Query",
          "dynamodb:Scan",
        ]
        Resource = [
          aws_dynamodb_table.rules.arn,
          "${aws_dynamodb_table.rules.arn}/index/*",
          aws_dynamodb_table.domains.arn,
          aws_dynamodb_table.tenants.arn,
          aws_dynamodb_table.verifications.arn,
          aws_dynamodb_table.events.arn,
          aws_dynamodb_table.users.arn,
          aws_dynamodb_table.device_codes.arn,
        ]
      },
      {
        Sid    = "SES"
        Effect = "Allow"
        Action = [
          "ses:SendEmail",
          "ses:VerifyDomainIdentity",
          "ses:DeleteIdentity",
          "ses:GetIdentityVerificationAttributes",
        ]
        Resource = "*"
      },
      {
        Sid      = "JWTSigningKey"
        Effect   = "Allow"
        Action   = ["ssm:GetParameter"]
        Resource = aws_ssm_parameter.jwt_secret.arn
      }
    ]
  })
}
