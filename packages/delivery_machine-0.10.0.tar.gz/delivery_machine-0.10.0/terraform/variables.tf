variable "aws_region" {
  description = "AWS region. SES email receiving is only available in us-east-1, us-west-2, eu-west-1."
  type        = string
  default     = "us-east-1"
}

variable "environment" {
  description = "Deployment environment (e.g. production, staging)."
  type        = string
  default     = "production"
}

variable "forward_from_email" {
  description = <<-EOT
    Email address used as the From: header when forwarding messages.
    Must be verified in SES (or belong to a verified domain).
    Example: "forward@myservice.com"
  EOT
  type        = string
}

variable "email_retention_days" {
  description = "Days to keep raw emails in S3 before automatic deletion."
  type        = number
  default     = 30
}


variable "lambda_log_retention_days" {
  description = "CloudWatch log retention for Lambda functions."
  type        = number
  default     = 14
}

variable "site_domain" {
  description = "Custom domain for the marketing site (e.g. deliverymachine.net)."
  type        = string
  default     = "deliverymachine.net"
}

variable "github_repo" {
  description = "GitHub repo in owner/name format, for OIDC trust policy."
  type        = string
  default     = "BarkingIguana/delivery-machine"
}

variable "alert_email" {
  description = "Email address for CloudWatch alarm and report notifications."
  type        = string
  default     = "craig@barkingiguana.com"
}

variable "create_github_oidc_provider" {
  description = "Set to false if your account already has a GitHub OIDC provider (e.g. created by bootstrap)."
  type        = bool
  default     = false
}

variable "cli_latest_version" {
  description = "Latest published CLI version. Clients behind this get an upgrade nudge."
  type        = string
  default     = "0.1.0"
}

variable "cli_min_version" {
  description = "Minimum supported CLI version. Clients below this are told to upgrade."
  type        = string
  default     = "0.1.0"
}
