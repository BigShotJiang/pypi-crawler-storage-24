terraform {
  required_version = ">= 1.5"

  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
    archive = {
      source  = "hashicorp/archive"
      version = "~> 2.0"
    }
    tls = {
      source  = "hashicorp/tls"
      version = "~> 4.0"
    }
    random = {
      source  = "hashicorp/random"
      version = "~> 3.0"
    }
  }

  # Remote state — configure via backend.hcl (created after bootstrap).
  # Initialise with: terraform init -backend-config=backend.hcl
  backend "s3" {
    # Partial config — values supplied via backend.hcl:
    #   bucket, key, region, dynamodb_table
  }
}

provider "aws" {
  region = var.aws_region

  default_tags {
    tags = local.tags
  }
}

data "aws_caller_identity" "current" {}
data "aws_region" "current" {}

locals {
  prefix = "delivery-machine"
  tags = {
    Project     = "delivery-machine"
    Environment = var.environment
    ManagedBy   = "terraform"
  }
}
