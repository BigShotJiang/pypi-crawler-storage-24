output "email_bucket" {
  description = "S3 bucket where incoming emails are stored."
  value       = aws_s3_bucket.emails.bucket
}

output "api_endpoint" {
  description = "Base URL for the management API."
  value       = "${aws_api_gateway_stage.main.invoke_url}/v1"
}


output "rules_table" {
  description = "DynamoDB table name for forwarding rules."
  value       = aws_dynamodb_table.rules.name
}

output "domains_table" {
  description = "DynamoDB table name for registered domains."
  value       = aws_dynamodb_table.domains.name
}

output "verifications_table" {
  description = "DynamoDB table name for destination email verifications."
  value       = aws_dynamodb_table.verifications.name
}

output "events_table" {
  description = "DynamoDB table name for rule activity events."
  value       = aws_dynamodb_table.events.name
}

output "forwarder_lambda" {
  description = "Forwarder Lambda function name."
  value       = aws_lambda_function.forwarder.function_name
}

output "ses_receipt_rule_set" {
  description = "Active SES receipt rule set name."
  value       = aws_ses_receipt_rule_set.main.rule_set_name
}

output "site_bucket" {
  description = "S3 bucket for the marketing site."
  value       = aws_s3_bucket.site.bucket
}

output "site_cloudfront_domain" {
  description = "CloudFront domain (DNS is managed automatically via Route 53)."
  value       = aws_cloudfront_distribution.site.domain_name
}

output "site_cloudfront_distribution_id" {
  description = "CloudFront distribution ID (for cache invalidation in CI)."
  value       = aws_cloudfront_distribution.site.id
}

output "github_actions_role_arn" {
  description = "IAM role ARN for GitHub Actions — set as AWS_DEPLOY_ROLE_ARN in the repo's production environment."
  value       = aws_iam_role.github_actions.arn
}

output "site_nameservers" {
  description = "Set these as the NS records at your domain registrar."
  value       = aws_route53_zone.site.name_servers
}

output "site_zone_id" {
  description = "Route 53 hosted zone ID for the marketing site domain."
  value       = aws_route53_zone.site.zone_id
}

output "alarms_topic_arn" {
  description = "SNS topic ARN for alarm notifications."
  value       = aws_sns_topic.alarms.arn
}

output "setup_instructions" {
  description = "Quick-start instructions."
  value       = <<-EOT

    ═══════════════════════════════════════════════════════
    Delivery Machine deployed successfully!
    ═══════════════════════════════════════════════════════

    API endpoint : ${aws_api_gateway_stage.main.invoke_url}/v1

    Next steps:
    1. Update nameservers at your domain registrar for ${var.site_domain}:
       ${join("\n       ", aws_route53_zone.site.name_servers)}
       Wait for propagation, then run: terraform apply
       (ACM will validate and CloudFront will get its cert.)

    2. Verify your forward-from address (${var.forward_from_email})
       Check your inbox for a verification email from AWS.

    3. If your AWS account is in SES sandbox mode, also verify
       each DESTINATION address you want to forward to.
       Submit a sending-limit increase request to leave sandbox.

    4. Install the CLI:
         pip install -e .

    5. Create your first user account:
         dm users add you@example.com
       Scan the QR code with your authenticator app and enter the code when prompted.

    6. Log in:
         dm login

    7. Register a domain:
         dm domains add example.com
       Then add the returned DNS records to your domain registrar.
    ═══════════════════════════════════════════════════════
  EOT
}
