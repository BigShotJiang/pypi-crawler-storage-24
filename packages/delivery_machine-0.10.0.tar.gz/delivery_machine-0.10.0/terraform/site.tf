# ── Marketing site: S3 + CloudFront + Route 53 ────────────────────────────
#
# Static site served from S3 via CloudFront with HTTPS.
# ACM certificate must be in us-east-1 for CloudFront — we use a separate
# provider alias for that.
#
# Deployment note (chicken/egg):
#   Phase 1:  terraform apply -target=aws_route53_zone.site
#             → Copy the NS records from the output to your domain registrar.
#             → Wait for NS propagation (check: dig NS deliverymachine.net).
#   Phase 2:  terraform apply
#             → ACM validates via DNS, CloudFront gets its cert, done.

provider "aws" {
  alias  = "us_east_1"
  region = "us-east-1"
}

# ── Route 53 hosted zone ─────────────────────────────────────────────────

resource "aws_route53_zone" "site" {
  name = var.site_domain
}

# ── S3 bucket ──────────────────────────────────────────────────────────────

resource "aws_s3_bucket" "site" {
  bucket = "${local.prefix}-site-${data.aws_caller_identity.current.account_id}"
}

resource "aws_s3_bucket_public_access_block" "site" {
  bucket                  = aws_s3_bucket.site.id
  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}

resource "aws_s3_bucket_server_side_encryption_configuration" "site" {
  bucket = aws_s3_bucket.site.id
  rule {
    apply_server_side_encryption_by_default { sse_algorithm = "AES256" }
  }
}

# ── CloudFront OAC ────────────────────────────────────────────────────────

resource "aws_cloudfront_origin_access_control" "site" {
  name                              = "${local.prefix}-site"
  origin_access_control_origin_type = "s3"
  signing_behavior                  = "always"
  signing_protocol                  = "sigv4"
}

# ── ACM certificate (must be us-east-1 for CloudFront) ─────────────────────

resource "aws_acm_certificate" "site" {
  provider          = aws.us_east_1
  domain_name       = var.site_domain
  validation_method = "DNS"

  subject_alternative_names = ["www.${var.site_domain}"]

  lifecycle { create_before_destroy = true }
}

# ── ACM DNS validation records in Route 53 ────────────────────────────────

resource "aws_route53_record" "acm_validation" {
  for_each = {
    for dvo in aws_acm_certificate.site.domain_validation_options : dvo.domain_name => {
      name   = dvo.resource_record_name
      type   = dvo.resource_record_type
      record = dvo.resource_record_value
    }
  }

  zone_id         = aws_route53_zone.site.zone_id
  name            = each.value.name
  type            = each.value.type
  ttl             = 300
  records         = [each.value.record]
  allow_overwrite = true
}

resource "aws_acm_certificate_validation" "site" {
  provider                = aws.us_east_1
  certificate_arn         = aws_acm_certificate.site.arn
  validation_record_fqdns = [for r in aws_route53_record.acm_validation : r.fqdn]
}

# ── CloudFront Function: clean URLs ──────────────────────────────────────
#
# Rewrites /signup → /signup.html, /device → /device.html, etc.
# Leaves requests with extensions (e.g. /style.css) and / alone.

resource "aws_cloudfront_function" "url_rewrite" {
  name    = "${local.prefix}-url-rewrite"
  runtime = "cloudfront-js-2.0"
  publish = true
  code    = <<-EOF
    function handler(event) {
      var request = event.request;
      var uri = request.uri;
      if (uri === '/' || uri.indexOf('.') > -1) return request;
      request.uri = uri + '.html';
      return request;
    }
  EOF
}

# ── CloudFront distribution ───────────────────────────────────────────────

resource "aws_cloudfront_distribution" "site" {
  depends_on = [aws_acm_certificate_validation.site]

  enabled             = true
  default_root_object = "index.html"
  aliases             = [var.site_domain, "www.${var.site_domain}"]
  price_class         = "PriceClass_100" # US + Europe — cheapest

  origin {
    domain_name              = aws_s3_bucket.site.bucket_regional_domain_name
    origin_id                = "s3"
    origin_access_control_id = aws_cloudfront_origin_access_control.site.id
  }

  default_cache_behavior {
    target_origin_id       = "s3"
    viewer_protocol_policy = "redirect-to-https"
    allowed_methods        = ["GET", "HEAD"]
    cached_methods         = ["GET", "HEAD"]
    compress               = true

    forwarded_values {
      query_string = false
      cookies { forward = "none" }
    }

    min_ttl     = 0
    default_ttl = 3600
    max_ttl     = 86400

    function_association {
      event_type   = "viewer-request"
      function_arn = aws_cloudfront_function.url_rewrite.arn
    }
  }

  viewer_certificate {
    acm_certificate_arn      = aws_acm_certificate.site.arn
    ssl_support_method       = "sni-only"
    minimum_protocol_version = "TLSv1.2_2021"
  }

  restrictions {
    geo_restriction { restriction_type = "none" }
  }
}

# ── DNS records: apex + www → CloudFront ──────────────────────────────────

resource "aws_route53_record" "site_apex" {
  zone_id = aws_route53_zone.site.zone_id
  name    = var.site_domain
  type    = "A"

  alias {
    name                   = aws_cloudfront_distribution.site.domain_name
    zone_id                = aws_cloudfront_distribution.site.hosted_zone_id
    evaluate_target_health = false
  }
}

resource "aws_route53_record" "site_apex_aaaa" {
  zone_id = aws_route53_zone.site.zone_id
  name    = var.site_domain
  type    = "AAAA"

  alias {
    name                   = aws_cloudfront_distribution.site.domain_name
    zone_id                = aws_cloudfront_distribution.site.hosted_zone_id
    evaluate_target_health = false
  }
}

resource "aws_route53_record" "site_www" {
  zone_id = aws_route53_zone.site.zone_id
  name    = "www.${var.site_domain}"
  type    = "A"

  alias {
    name                   = aws_cloudfront_distribution.site.domain_name
    zone_id                = aws_cloudfront_distribution.site.hosted_zone_id
    evaluate_target_health = false
  }
}

resource "aws_route53_record" "site_www_aaaa" {
  zone_id = aws_route53_zone.site.zone_id
  name    = "www.${var.site_domain}"
  type    = "AAAA"

  alias {
    name                   = aws_cloudfront_distribution.site.domain_name
    zone_id                = aws_cloudfront_distribution.site.hosted_zone_id
    evaluate_target_health = false
  }
}

# ── MX alias for customer-facing DNS instructions ─────────────────────────
# Customers set MX to mx.deliverymachine.net instead of the raw SES hostname.

resource "aws_route53_record" "mx_alias" {
  zone_id = aws_route53_zone.site.zone_id
  name    = "mx.${var.site_domain}"
  type    = "CNAME"
  ttl     = 3600
  records = ["inbound-smtp.${var.aws_region}.amazonaws.com."]
}

# ── iCloud Mail DNS records ────────────────────────────────────────────────

resource "aws_route53_record" "icloud_mx" {
  zone_id = aws_route53_zone.site.zone_id
  name    = var.site_domain
  type    = "MX"
  ttl     = 3600
  records = [
    "10 mx01.mail.icloud.com.",
    "10 mx02.mail.icloud.com.",
  ]
}

resource "aws_route53_record" "icloud_domain_verification" {
  zone_id = aws_route53_zone.site.zone_id
  name    = var.site_domain
  type    = "TXT"
  ttl     = 3600
  records = [
    "apple-domain=0TEREtqwnX0xSsa7",
    "v=spf1 include:icloud.com include:amazonses.com ~all",
  ]
}

resource "aws_route53_record" "icloud_dkim" {
  zone_id = aws_route53_zone.site.zone_id
  name    = "sig1._domainkey.${var.site_domain}"
  type    = "CNAME"
  ttl     = 3600
  records = ["sig1.dkim.deliverymachine.net.at.icloudmailadmin.com."]
}

# ── SES DKIM CNAME records ────────────────────────────────────────────────
#
# SES generates 3 DKIM tokens; each needs a CNAME pointing to an SES-hosted key.

resource "aws_route53_record" "ses_dkim" {
  count   = 3
  zone_id = aws_route53_zone.site.zone_id
  name    = "${aws_ses_domain_dkim.site.dkim_tokens[count.index]}._domainkey.${var.site_domain}"
  type    = "CNAME"
  ttl     = 3600
  records = ["${aws_ses_domain_dkim.site.dkim_tokens[count.index]}.dkim.amazonses.com"]
}

# ── S3 bucket policy: allow CloudFront OAC ─────────────────────────────────

resource "aws_s3_bucket_policy" "site" {
  bucket = aws_s3_bucket.site.id
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Sid       = "AllowCloudFrontOAC"
      Effect    = "Allow"
      Principal = { Service = "cloudfront.amazonaws.com" }
      Action    = "s3:GetObject"
      Resource  = "${aws_s3_bucket.site.arn}/*"
      Condition = {
        StringEquals = {
          "AWS:SourceArn" = aws_cloudfront_distribution.site.arn
        }
      }
    }]
  })
}
