cli_latest_version = "0.10.0" # x-release-please-version
