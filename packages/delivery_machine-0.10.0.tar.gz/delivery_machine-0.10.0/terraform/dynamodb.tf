# ── Forwarding rules ───────────────────────────────────────────────────────
#
# PK: domain     (e.g. "example.com")
# SK: localpart  (e.g. "hello" or "*" for catch-all)
#
# Optional TTL via `expires_at` (Unix timestamp) enables ephemeral addresses.
# tenant_id supports future multi-tenant / billing segmentation.

resource "aws_dynamodb_table" "rules" {
  name         = "${local.prefix}-rules"
  billing_mode = "PAY_PER_REQUEST"
  hash_key     = "domain"
  range_key    = "localpart"

  attribute {
    name = "domain"
    type = "S"
  }
  attribute {
    name = "localpart"
    type = "S"
  }
  attribute {
    name = "tenant_id"
    type = "S"
  }

  ttl {
    attribute_name = "expires_at"
    enabled        = true
  }

  # Query all rules for a tenant (e.g. for a dashboard or billing count).
  global_secondary_index {
    name            = "tenant-index"
    hash_key        = "tenant_id"
    projection_type = "ALL"
  }

  point_in_time_recovery { enabled = true }
}

# ── Activity events ────────────────────────────────────────────────────────
#
# PK: rule_key  (e.g. "example.com#hello")
# SK: timestamp  (ISO 8601, e.g. "2026-03-10T12:00:00+00:00")
#
# Logs when destinations are added to or removed from forwarding rules.

resource "aws_dynamodb_table" "events" {
  name         = "${local.prefix}-events"
  billing_mode = "PAY_PER_REQUEST"
  hash_key     = "rule_key"
  range_key    = "timestamp"

  attribute {
    name = "rule_key"
    type = "S"
  }
  attribute {
    name = "timestamp"
    type = "S"
  }

  point_in_time_recovery { enabled = false }
}

# ── Registered domains ─────────────────────────────────────────────────────
#
# PK: domain
# Stores verification token for domain ownership proof.

resource "aws_dynamodb_table" "domains" {
  name         = "${local.prefix}-domains"
  billing_mode = "PAY_PER_REQUEST"
  hash_key     = "domain"

  attribute {
    name = "domain"
    type = "S"
  }

  point_in_time_recovery { enabled = true }
}

# ── Tenants (billing scaffold) ─────────────────────────────────────────────
#
# PK: tenant_id
# Tracks plan, email quota, credit balance, and rolling email count.
# Designed to support both subscription plans and prepaid credits.

resource "aws_dynamodb_table" "tenants" {
  name         = "${local.prefix}-tenants"
  billing_mode = "PAY_PER_REQUEST"
  hash_key     = "tenant_id"

  attribute {
    name = "tenant_id"
    type = "S"
  }

  point_in_time_recovery { enabled = true }
}

# ── Destination email verifications ───────────────────────────────────────
#
# PK: destination  (e.g. "user@example.com")
# Tracks whether a destination email address has been verified by the owner.
# Rules targeting unverified destinations are stored but not active.

resource "aws_dynamodb_table" "verifications" {
  name         = "${local.prefix}-verifications"
  billing_mode = "PAY_PER_REQUEST"
  hash_key     = "destination"

  attribute {
    name = "destination"
    type = "S"
  }

  point_in_time_recovery { enabled = false }
}
