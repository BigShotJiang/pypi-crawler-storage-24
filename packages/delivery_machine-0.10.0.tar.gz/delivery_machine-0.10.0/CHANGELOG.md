# Changelog

## [0.10.0](https://github.com/barkingiguana/delivery-machine/compare/v0.9.0...v0.10.0) (2026-03-14)


### Features

* register domains with SES for inbound email ([c83479d](https://github.com/barkingiguana/delivery-machine/commit/c83479d6ca4cc43208e6adad9a07a26fc21965b9))
* register domains with SES for inbound email receiving ([44505bd](https://github.com/barkingiguana/delivery-machine/commit/44505bda635d249b268c95d8cf122a7b432ba06e))

## [0.9.0](https://github.com/barkingiguana/delivery-machine/compare/v0.8.0...v0.9.0) (2026-03-14)


### Features

* per-rule-destination verification ([08e5502](https://github.com/barkingiguana/delivery-machine/commit/08e5502d6d03cbe40fc13d22b6b665ba7fd4e5bc))
* per-rule-destination verification ([534728c](https://github.com/barkingiguana/delivery-machine/commit/534728c57082759dd64c4e444d4557f27c44b4db))

## [0.8.0](https://github.com/barkingiguana/delivery-machine/compare/v0.7.0...v0.8.0) (2026-03-14)


### Features

* show destination confirmation status in rules list ([d60431a](https://github.com/barkingiguana/delivery-machine/commit/d60431a01e7ad5988528be42b256cac608530a5a))
* show destination confirmation status in rules list ([6400d98](https://github.com/barkingiguana/delivery-machine/commit/6400d98b04c20cc09c49564d05dffd6f9266a9c7))

## [0.7.0](https://github.com/barkingiguana/delivery-machine/compare/v0.6.2...v0.7.0) (2026-03-14)


### Features

* improve verification emails, add receive counts, fix API URL ([0dd4fca](https://github.com/barkingiguana/delivery-machine/commit/0dd4fca48cb3176a7c130fd6925519db838889bc))
* verification emails, receive counts, API URL fix ([f3ee376](https://github.com/barkingiguana/delivery-machine/commit/f3ee37643505d806335eb637969c54d2d375f9df))

## [0.6.2](https://github.com/barkingiguana/delivery-machine/compare/v0.6.1...v0.6.2) (2026-03-14)


### Bug Fixes

* dispatch pypi.yml from release workflow instead of publishing inline ([6de9001](https://github.com/barkingiguana/delivery-machine/commit/6de900162ef94b606c40229bb6debb365733c150))
* use pypi.yml for all publishing via workflow_dispatch ([c6335f9](https://github.com/barkingiguana/delivery-machine/commit/c6335f9a565d926ed576415d7f65186cee9aade8))

## [0.6.1](https://github.com/barkingiguana/delivery-machine/compare/v0.6.0...v0.6.1) (2026-03-14)


### Bug Fixes

* add actions:write for release workflow re-trigger ([6943c89](https://github.com/barkingiguana/delivery-machine/commit/6943c89c246c1a38253a95d3110a18a51ebe3ecd))
* add actions:write permission so release workflow can re-trigger itself ([52e922b](https://github.com/barkingiguana/delivery-machine/commit/52e922bcc7d5b731d102f108d027875ae47bb521))

## [0.6.0](https://github.com/barkingiguana/delivery-machine/compare/v0.5.2...v0.6.0) (2026-03-14)


### Features

* --totp flag for non-interactive login and verify ([048c438](https://github.com/barkingiguana/delivery-machine/commit/048c438f1f6bb93ce509eb6626b4d9fb5f03984d))
* add --totp flag for non-interactive login and verify ([3a62274](https://github.com/barkingiguana/delivery-machine/commit/3a62274ed7e946d7b785de7058097111122959a9))

## [0.5.2](https://github.com/barkingiguana/delivery-machine/compare/v0.5.1...v0.5.2) (2026-03-14)


### Bug Fixes

* auto-provision tenant for authenticated users ([099def1](https://github.com/barkingiguana/delivery-machine/commit/099def14905e2cb34a1e38b1ff0236e341c9823f))
* auto-provision tenant when missing for authenticated users ([8ef5943](https://github.com/barkingiguana/delivery-machine/commit/8ef5943fce337c429084e27bd43edf046a15bb6c))

## [0.5.1](https://github.com/barkingiguana/delivery-machine/compare/v0.5.0...v0.5.1) (2026-03-14)


### Bug Fixes

* chain PyPI publish into release workflow to fix automated publishing ([d174ccc](https://github.com/barkingiguana/delivery-machine/commit/d174ccc72b5872948ed422238302ff526d02d45e))

## [0.5.0](https://github.com/barkingiguana/delivery-machine/compare/v0.4.0...v0.5.0) (2026-03-13)


### Features

* authenticate user provisioning, deduplicate version warnings, ULID tenants, macOS Passwords.app ([38f3b69](https://github.com/barkingiguana/delivery-machine/commit/38f3b691258b840c7e9e57426a6de203684020da))

## [0.4.0](https://github.com/barkingiguana/delivery-machine/compare/v0.3.0...v0.4.0) (2026-03-13)


### Features

* adopt thea-recorder 0.18 APIs, remove 141 lines of boilerplate ([8e3b279](https://github.com/barkingiguana/delivery-machine/commit/8e3b27917e9f98ce2caacbdce80fc042303b4a2e))
* adopt thea-recorder 0.18, drop 141 lines of boilerplate ([5888905](https://github.com/barkingiguana/delivery-machine/commit/5888905c97200a9605463e03634eba737699cad2))

## [0.3.0](https://github.com/barkingiguana/delivery-machine/compare/v0.2.0...v0.3.0) (2026-03-13)


### Features

* upgrade thea-recorder to &gt;=0.14.0 and use Recorder APIs ([e6ff7c0](https://github.com/barkingiguana/delivery-machine/commit/e6ff7c036ee7d1527445a4b3b4330429707ebeec))
* upgrade thea-recorder to 0.14.0, use Recorder APIs ([170eb6e](https://github.com/barkingiguana/delivery-machine/commit/170eb6e3d8f51895bdbd6413df2d8cd64d93037e))

## [0.2.0](https://github.com/barkingiguana/delivery-machine/compare/v0.1.3...v0.2.0) (2026-03-12)


### Features

* redesign status email with actionable summary ([857233e](https://github.com/barkingiguana/delivery-machine/commit/857233e9aa69b09780a138fcb8371fa4f638901e))
* redesign status email with actionable summary ([5ff6270](https://github.com/barkingiguana/delivery-machine/commit/5ff6270cca288a5193f282e64693fe42fd67a6f8))

## [0.1.3](https://github.com/barkingiguana/delivery-machine/compare/v0.1.2...v0.1.3) (2026-03-12)


### Bug Fixes

* use scan count instead of approximate describe_table for status email ([95bb45e](https://github.com/barkingiguana/delivery-machine/commit/95bb45e232c7da0570ad6a09958e7594949c7223))

## [0.1.2](https://github.com/barkingiguana/delivery-machine/compare/v0.1.1...v0.1.2) (2026-03-12)


### Bug Fixes

* use plain v* tags for releases (no component prefix) ([ac0b0d5](https://github.com/barkingiguana/delivery-machine/commit/ac0b0d5a46c8ec7e469b196f9118daadc903f983))

## [0.1.1](https://github.com/barkingiguana/delivery-machine/compare/delivery-machine-v0.1.0...delivery-machine-v0.1.1) (2026-03-12)


### Bug Fixes

* use correct Thea API in demo recorder ([d7a4612](https://github.com/barkingiguana/delivery-machine/commit/d7a4612d0b5e0a9aadcc24be6c32239ce6cf1503))

## 0.1.0 (2026-03-12)


### Features

* add tenant constraints and data integrity checks ([db3839a](https://github.com/barkingiguana/delivery-machine/commit/db3839a64d845346a347ead8cde64103171cb0cd))
* rewrite CLI with JWT auth, device flow login, and signup ([2912fed](https://github.com/barkingiguana/delivery-machine/commit/2912fed35483d2908fb0dfdf8ffd65a48a702448))
* server-driven CLI version checking via API headers ([272b2bd](https://github.com/barkingiguana/delivery-machine/commit/272b2bdb0c1b425ba60941033a9a02a33528a24c))


### Bug Fixes

* remove CloudWatch dashboard for cost saving ([02a8d41](https://github.com/barkingiguana/delivery-machine/commit/02a8d410071bf55f037463304fba3364f6f57589))


### Dependencies

* upgrade thea-recorder to &gt;=0.13.0 ([bb8dcc4](https://github.com/barkingiguana/delivery-machine/commit/bb8dcc4b0a3e05c13d3d319728e08fa1d87c7b19))
