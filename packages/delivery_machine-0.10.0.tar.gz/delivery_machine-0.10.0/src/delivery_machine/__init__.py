"""Delivery Machine — route email from all your custom domains to one inbox."""

try:
    from delivery_machine._version import __version__, __version_tuple__
except ImportError:
    __version__ = "0.0.0.dev0"
    __version_tuple__ = (0, 0, 0, "dev0")
