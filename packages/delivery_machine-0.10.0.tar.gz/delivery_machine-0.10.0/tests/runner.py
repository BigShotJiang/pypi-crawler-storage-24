"""Test runner: executes CLI scenarios with assertions, recorded with Thea.

Each scenario is a module in tests/scenarios/ with a ``run(t)`` function
that receives a TestRunner. The runner executes ``dm`` commands via
subprocess, asserts on output, and records everything as video.

Runs against the real API Lambda handler backed by DynamoDB Local,
with SES and SSM stubbed out.

Usage:
    python -m tests.runner                  # run all scenarios
    python -m tests.runner full_flow        # run one scenario
    python -m tests.runner --list           # list scenarios
"""

import importlib
import os
import subprocess
import sys
import time
import traceback
from pathlib import Path

from thea import Recorder, generate_report

from tests.support.api_server import start_api_server
from tests.support.setup_tables import create_tables, drop_all_tables

OUTPUT_DIR = os.environ.get("OUTPUT_DIR", "./output")
DISPLAY = int(os.environ.get("THEA_DISPLAY", "99"))
DISPLAY_SIZE = "1280x1080"
API_PORT = 9199

# xterm font/geometry — font size 12 JetBrains Mono gives ~7px wide chars.
# With 1280px viewport and no border: 1280/7 ≈ 182 columns, 1080/15 ≈ 72 rows.
XTERM_FONT_SIZE = 12
XTERM_COLS = 170
XTERM_ROWS = 68

GREEN = "\033[1;32m"
RED = "\033[1;31m"
YELLOW = "\033[1;33m"
CYAN = "\033[1;36m"
DIM = "\033[2m"
RESET = "\033[0m"
BOLD = "\033[1m"

TEST_LOG = "/tmp/test-output.log"


class TestRunner:
    """Helpers for blackbox CLI testing."""

    def __init__(self, recorder, log_path):
        self._recorder = recorder
        self._log = open(log_path, "a")
        self.passed = 0
        self.failed = 0
        self.errors = []
        # COLUMNS tells Rich (in the dm CLI) how wide the terminal is.
        self._env = {
            **recorder.display_env,
            "DELIVERY_MACHINE_API_URL": f"http://127.0.0.1:{API_PORT}/v1",
            "TERM": "xterm-256color",
            "COLUMNS": str(XTERM_COLS),
            "BROWSER": "/bin/true",  # prevent webbrowser.open from blocking
        }
        # Remove any pre-existing session
        session_file = Path.home() / ".config" / "dm" / "session.json"
        session_file.unlink(missing_ok=True)

    def section(self, title):
        """Start a new test section."""
        self._recorder.update_panel("scene", title)
        self._update_progress()
        print(f"\n{CYAN}{'─' * 72}{RESET}")
        print(f"  {BOLD}{title}{RESET}")
        print(f"{CYAN}{'─' * 72}{RESET}")

    def step(self, description):
        """Announce a test step — uses Thea's step tracker for timing."""
        self._recorder.update_panel("step", description)
        self._step_ctx = self._recorder.step(description)
        self._step_ctx.__enter__()
        self._update_progress()
        print(f"\n  {DIM}▸ {description}{RESET}")
        time.sleep(0.3)

    def end_step(self):
        """End the current step (marked passed)."""
        if hasattr(self, "_step_ctx") and self._step_ctx:
            self._step_ctx.__exit__(None, None, None)
            self._step_ctx = None

    def _video_write(self, text):
        """Write text to the video log file (what xterm displays)."""
        self._log.write(text)
        self._log.flush()

    def _type(self, text, per_char=0.03):
        """Write text character-by-character for a typing effect in video."""
        for ch in text:
            self._video_write(ch)
            time.sleep(per_char)

    def _prompt(self):
        """Show a shell prompt in the video."""
        self._video_write(f"{GREEN}${RESET} ")

    def dm(self, *args, input_text=None, timeout=30):
        """Run a ``dm`` CLI command and return the CompletedProcess."""
        cmd = ["dm"] + list(args)
        display_cmd = " ".join(cmd)

        self._prompt()
        self._type(display_cmd)
        self._video_write("\n")
        time.sleep(0.2)

        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            env=self._env,
            input=input_text,
            timeout=timeout,
        )

        for line in result.stdout.splitlines():
            self._video_write(f"{line}\n")
        for line in result.stderr.splitlines():
            self._video_write(f"{RED}{line}{RESET}\n")

        time.sleep(0.5)
        self._prompt()
        self._video_write("\n")
        return result

    def close(self):
        """Close the video log file."""
        self._log.close()

    def assert_success(self, result, msg=""):
        label = msg or "exit code 0"
        if result.returncode == 0:
            self._pass(label)
        else:
            self._fail(label, f"exit code was {result.returncode}")

    def assert_exit_code(self, result, code, msg=""):
        label = msg or f"exit code {code}"
        if result.returncode == code:
            self._pass(label)
        else:
            self._fail(label, f"exit code was {result.returncode}")

    def assert_contains(self, result, text, msg=""):
        label = msg or f"output contains '{text}'"
        combined = result.stdout + result.stderr
        if text in combined:
            self._pass(label)
        else:
            self._fail(label, f"'{text}' not found in output")

    def assert_not_contains(self, result, text, msg=""):
        label = msg or f"output does not contain '{text}'"
        combined = result.stdout + result.stderr
        if text not in combined:
            self._pass(label)
        else:
            self._fail(label, f"'{text}' was found in output")

    def _pass(self, label):
        self.passed += 1
        self.end_step()
        self._update_progress()
        print(f"    {GREEN}✓ {label}{RESET}")

    def _fail(self, label, detail):
        self.failed += 1
        # End step with failure — the step context will record it
        if hasattr(self, "_step_ctx") and self._step_ctx:
            try:
                self._step_ctx.__exit__(type(Exception), Exception(detail), None)
            except Exception:
                pass
            self._step_ctx = None
        msg = f"{label}: {detail}"
        self.errors.append(msg)
        self._update_progress()
        print(f"    {RED}✗ {label}{RESET}")
        print(f"      {RED}{detail}{RESET}")

    def _update_progress(self):
        """Update the progress panel with current pass/fail counts."""
        parts = []
        if self.passed:
            parts.append(f"✓ {self.passed} passed")
        if self.failed:
            parts.append(f"✗ {self.failed} failed")
        if not parts:
            parts.append("Starting...")
        self._recorder.update_panel("progress", "  ".join(parts))


SCENARIO_DIR = Path(__file__).parent / "scenarios"


def discover_scenarios():
    scenarios = {}
    for p in sorted(SCENARIO_DIR.glob("test_*.py")):
        name = p.stem.removeprefix("test_")
        mod = importlib.import_module(f"tests.scenarios.{p.stem}")
        desc = (mod.__doc__ or name).strip().split("\n")[0]
        scenarios[name] = (desc, mod)
    return scenarios


def _launch_xterm(rec):
    """Launch xterm on the recorder's display, filling the viewport."""
    Path(TEST_LOG).write_text("")

    rec.launch_app(
        [
            "xterm",
            "-geometry", f"{XTERM_COLS}x{XTERM_ROWS}+0+0",
            "-fa", "JetBrains Mono",
            "-fs", str(XTERM_FONT_SIZE),
            "-bg", "#0d1117",
            "-fg", "#c9d1d9",
            "-cr", "#58a6ff",
            "+sb",
            "-b", "0",
            "-e", "tail", "-f", TEST_LOG,
        ],
        env={"TERM": "xterm-256color"},
        window_class="XTerm",
        fill_viewport=True,
    )

    time.sleep(0.5)


def main():
    scenarios = discover_scenarios()

    if "--list" in sys.argv:
        print("Available test scenarios:")
        for name, (desc, _) in scenarios.items():
            print(f"  {name:30s}  {desc}")
        return

    os.makedirs(OUTPUT_DIR, exist_ok=True)

    # Create DynamoDB tables
    print("  Setting up DynamoDB tables...")
    create_tables()

    # Start real API server (Lambda handler wrapped in HTTP)
    start_api_server(API_PORT)
    os.environ["DELIVERY_MACHINE_API_URL"] = f"http://127.0.0.1:{API_PORT}/v1"
    print(f"  API server on port {API_PORT}")

    rec = Recorder(
        output_dir=OUTPUT_DIR,
        display=DISPLAY,
        display_size=DISPLAY_SIZE,
        framerate=24,
    )

    rec.add_panel("scene", title="Test", width=200)
    rec.add_panel("step", title="Step")
    rec.add_panel("progress", title="Progress", width=200)
    rec.start_display()
    os.environ["DISPLAY"] = rec.display_string

    requested = [a for a in sys.argv[1:] if not a.startswith("-")]
    if not requested:
        requested = list(scenarios.keys())

    results = []
    total_passed = 0
    total_failed = 0

    for name in requested:
        if name not in scenarios:
            print(f"Unknown scenario: {name}")
            print(f"Available: {', '.join(scenarios)}")
            sys.exit(1)

        desc, module = scenarios[name]
        print(f"\n{'=' * 60}")
        print(f"  SCENARIO: {desc}")
        print(f"{'=' * 60}")

        # Fresh DynamoDB state per scenario
        drop_all_tables()
        create_tables()

        _launch_xterm(rec)

        rec.update_panel("scene", desc)
        rec.update_panel("step", "")
        rec.update_panel("progress", "Starting...")
        rec.start_recording(f"test-{name}")

        t = TestRunner(rec, TEST_LOG)
        try:
            module.run(t)
        except Exception:
            t.failed += 1
            t.errors.append(traceback.format_exc())
            print(f"\n    {RED}EXCEPTION:{RESET}")
            traceback.print_exc()

        # Print summary to terminal
        print(f"\n{'=' * 72}")
        if t.failed == 0:
            rec.update_panel("progress", f"✓ ALL {t.passed} PASSED")
            print(f"  {GREEN}{BOLD}ALL {t.passed} TESTS PASSED{RESET}")
        else:
            rec.update_panel("progress", f"✗ {t.failed} FAILED / {t.passed} passed")
            print(f"  {RED}{BOLD}{t.failed} FAILED{RESET}, {t.passed} passed")
            for e in t.errors:
                print(f"  {RED}• {e}{RESET}")
        print(f"{'=' * 72}")

        time.sleep(3)
        t.close()

        path = rec.stop_recording()

        total_passed += t.passed
        total_failed += t.failed
        status = "passed" if t.failed == 0 else "failed"
        results.append({
            "name": name,
            "desc": desc,
            "path": path,
            "status": status,
            "passed": t.passed,
            "failed": t.failed,
            "errors": t.errors,
        })

    rec.cleanup()

    # HTML report — step timelines come from Thea's step tracker
    videos = []
    for r in results:
        videos.append({
            "feature": "Delivery Machine CLI",
            "scenario": r["desc"],
            "status": r["status"],
            "video": r["path"],
            "steps": rec.last_recording_steps,
        })
    generate_report(
        videos,
        output_dir=OUTPUT_DIR,
        title="Delivery Machine Tests",
        subtitle="Blackbox CLI tests recorded with Thea",
    )

    # Summary
    print(f"\n{'=' * 60}")
    print(f"  TEST RESULTS")
    print(f"{'=' * 60}")
    for r in results:
        icon = f"{GREEN}PASS{RESET}" if r["status"] == "passed" else f"{RED}FAIL{RESET}"
        print(f"  [{icon}] {r['desc']}")
        print(f"         {r['passed']} passed, {r['failed']} failed")
        if r["errors"]:
            for e in r["errors"]:
                for line in e.strip().splitlines():
                    print(f"         {RED}• {line}{RESET}")
        print(f"         Video: {r['path']}")

    print(f"\n  Total: {total_passed} passed, {total_failed} failed")
    print(f"  Report: {OUTPUT_DIR}/report.html")
    print(f"{'=' * 60}")

    sys.exit(1 if total_failed > 0 else 0)


if __name__ == "__main__":
    main()
