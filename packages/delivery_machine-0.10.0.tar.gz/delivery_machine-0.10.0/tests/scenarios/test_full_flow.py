"""Full lifecycle: signup → login → domains → rules → verifications → cleanup."""

from pathlib import Path

import pyotp

# Must match the fixed secret in tests/support/api_server.py.
FIXED_TOTP_SECRET = "JBSWY3DPEHPK3PXP"


def _totp_code():
    """Generate a valid TOTP code using the fixed test secret."""
    return pyotp.TOTP(FIXED_TOTP_SECRET).now()


def run(t):
    session_file = Path.home() / ".config" / "dm" / "session.json"

    # ── Unauthenticated ─────────────────────────────────────────────────

    t.section("Unauthenticated access")

    t.step("Commands fail without a session")
    session_file.unlink(missing_ok=True)
    result = t.dm("domains", "list")
    t.assert_exit_code(result, 1, "exits non-zero without session")
    t.assert_contains(result, "Not authenticated", "tells user to log in")

    # ── Account creation ────────────────────────────────────────────────

    t.section("Account creation")

    t.step("Create a new account via signup")
    code = _totp_code()
    result = t.dm("signup", "alice@example.com", input_text=f"{code}\n")
    t.assert_success(result, "dm signup exits 0")
    t.assert_contains(result, "Account created", "confirms account created")
    t.assert_contains(result, "TOTP verified", "confirms TOTP verified")

    # ── Login ───────────────────────────────────────────────────────────

    t.section("Login via device flow")

    t.step("Log in (device code auto-confirmed by test harness)")
    result = t.dm("login", "--hours", "8", timeout=30)
    t.assert_success(result, "dm login exits 0")
    t.assert_contains(result, "Logged in as", "confirms login")

    t.step("dm users add requires authentication")
    # Now that we're logged in, users add should work
    code = _totp_code()
    result = t.dm("users", "add", "bob@example.com")
    t.assert_success(result, "dm users add exits 0 when authenticated")
    t.assert_contains(result, "Account created", "confirms account created")

    t.step("Session file exists after login")
    if session_file.exists():
        t._pass("session file created")
    else:
        t._fail("session file created", "file not found")

    # ── Domains ─────────────────────────────────────────────────────────

    t.section("Domain management")

    t.step("Empty domain list")
    result = t.dm("domains", "list")
    t.assert_success(result, "dm domains list exits 0")
    t.assert_contains(result, "No domains", "reports no domains")

    t.step("Register a domain")
    result = t.dm("domains", "add", "example.com")
    t.assert_success(result, "dm domains add exits 0")
    t.assert_contains(result, "example.com", "shows the domain name")
    t.assert_contains(result, "registered", "confirms registration")

    t.step("List domains shows the new domain")
    result = t.dm("domains", "list")
    t.assert_success(result)
    t.assert_contains(result, "example.com", "domain appears in list")

    t.step("Show domain details")
    result = t.dm("domains", "show", "example.com")
    t.assert_success(result)
    t.assert_contains(result, "example.com", "domain shown")

    t.step("Check domain DNS")
    result = t.dm("domains", "check", "example.com")
    t.assert_success(result, "dm domains check exits 0 (DNS stubbed)")
    t.assert_contains(result, "checks passed", "all DNS checks pass")

    # ── Rules ───────────────────────────────────────────────────────────

    t.section("Forwarding rules")

    t.step("No rules initially")
    result = t.dm("rules", "list")
    t.assert_success(result)
    t.assert_contains(result, "No rules", "reports no rules")

    t.step("Add a simple forwarding rule")
    result = t.dm("rules", "add", "example.com", "hello", "alice@gmail.com")
    t.assert_success(result, "dm rules add exits 0")
    t.assert_contains(result, "hello@example.com", "confirms the address")
    t.assert_contains(result, "alice@gmail.com", "confirms destination")

    t.step("Add a multi-destination rule")
    result = t.dm(
        "rules", "add", "example.com", "support",
        "alice@team.com", "cc:bob@team.com",
    )
    t.assert_success(result, "multi-dest rule created")
    t.assert_contains(result, "alice@team.com", "primary destination shown")
    t.assert_contains(result, "bob@team.com", "cc destination shown")

    t.step("Add an ephemeral rule (expires in 7 days)")
    result = t.dm(
        "rules", "add", "example.com", "temp-signup", "alice@gmail.com",
        "--expires", "7", "--description", "Conference signup",
    )
    t.assert_success(result, "ephemeral rule created")
    t.assert_contains(result, "expires", "shows expiry date")

    t.step("List all rules")
    result = t.dm("rules", "list")
    t.assert_success(result)
    t.assert_contains(result, "hello", "hello rule listed")
    t.assert_contains(result, "support", "support rule listed")
    t.assert_contains(result, "temp-signup", "ephemeral rule listed")

    t.step("Show rule detail")
    result = t.dm("rules", "show", "example.com", "hello")
    t.assert_success(result)
    t.assert_contains(result, "hello@example.com", "shows full address")
    t.assert_contains(result, "enabled", "shows enabled status")

    t.step("View activity log")
    result = t.dm("rules", "log", "example.com", "hello")
    t.assert_success(result)
    t.assert_contains(result, "rule created", "log shows creation event")

    # ── Disable / enable ────────────────────────────────────────────────

    t.section("Rule lifecycle")

    t.step("Disable a rule")
    result = t.dm("rules", "disable", "example.com", "temp-signup")
    t.assert_success(result)
    t.assert_contains(result, "disabled", "confirms disabled")

    t.step("Confirm rule shows as disabled")
    result = t.dm("rules", "show", "example.com", "temp-signup")
    t.assert_success(result)
    t.assert_contains(result, "disabled", "rule is disabled")

    t.step("Re-enable the rule")
    result = t.dm("rules", "enable", "example.com", "temp-signup")
    t.assert_success(result)
    t.assert_contains(result, "enabled", "confirms re-enabled")

    # ── Verifications ───────────────────────────────────────────────────

    t.section("Destination verifications")

    t.step("List verifications")
    result = t.dm("verifications", "list")
    t.assert_success(result)
    t.assert_contains(result, "alice@gmail.com", "destination listed")

    t.step("Check specific destination")
    result = t.dm("verifications", "check", "alice@gmail.com")
    t.assert_success(result)
    t.assert_contains(result, "alice@gmail.com", "destination shown")

    t.step("Resend verification email")
    result = t.dm("verifications", "resend", "alice@gmail.com")
    t.assert_success(result)

    # ── Cleanup ─────────────────────────────────────────────────────────

    t.section("Cleanup")

    t.step("Delete a rule")
    result = t.dm("rules", "delete", "example.com", "temp-signup", input_text="y\n")
    t.assert_success(result, "dm rules delete exits 0")
    t.assert_contains(result, "Deleted", "confirms deletion")

    t.step("Confirm rule is gone")
    result = t.dm("rules", "show", "example.com", "temp-signup")
    t.assert_exit_code(result, 1, "deleted rule returns error")

    t.step("Delete the domain")
    result = t.dm("domains", "delete", "example.com", input_text="y\n")
    t.assert_success(result, "dm domains delete exits 0")
    t.assert_contains(result, "deleted", "confirms domain deleted")

    # ── Logout ──────────────────────────────────────────────────────────

    t.section("Logout")

    t.step("Log out")
    result = t.dm("logout")
    t.assert_success(result, "dm logout exits 0")
    t.assert_contains(result, "Logged out", "confirms logout")

    t.step("Commands fail after logout")
    result = t.dm("domains", "list")
    t.assert_exit_code(result, 1, "exits non-zero after logout")
    t.assert_contains(result, "Not authenticated", "tells user to log in")
