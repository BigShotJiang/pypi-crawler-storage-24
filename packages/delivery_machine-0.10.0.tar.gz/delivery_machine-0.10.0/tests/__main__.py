"""Allow running tests with ``python -m tests``."""

from tests.runner import main

main()
