"""Mock API server for blackbox CLI tests and demo recordings.

Returns responses matching the real Delivery Machine API handler,
so the dm CLI works correctly against it.
Runs on localhost:9199 inside the test/recording container.
"""

import base64
import hashlib
import hmac
import json
import secrets
import threading
import time
import urllib.parse
from http.server import HTTPServer, BaseHTTPRequestHandler
from datetime import datetime, timezone, timedelta

NOW = datetime.now(timezone.utc)
MX_HOST = "mx.deliverymachine.net"

# Mock JWT — no real crypto needed.
MOCK_JWT_SECRET = "test-secret-not-for-production"
MOCK_USER_EMAIL = "you@deliverymachine.net"
MOCK_TENANT_ID = "default"

# Device code state
DEVICE_CODES = {}  # code -> {status, poll_count, ...}


def _ts(delta_days=0):
    return (NOW + timedelta(days=delta_days)).isoformat()


# In-memory state — reset between test scenarios via reset_state().
DOMAINS = {}
RULES = {}
EVENTS = {}  # key -> list of events


def reset_state():
    """Clear all in-memory state so each scenario starts fresh."""
    DOMAINS.clear()
    RULES.clear()
    EVENTS.clear()
    DEVICE_CODES.clear()


def _mock_jwt(email, tenant_id, duration=28800):
    """Create a minimal mock JWT (valid enough for the CLI to store)."""
    header = base64.urlsafe_b64encode(
        json.dumps({"alg": "HS256", "typ": "JWT"}).encode()
    ).rstrip(b"=").decode()
    now = int(time.time())
    payload = base64.urlsafe_b64encode(json.dumps({
        "sub": email, "tenant_id": tenant_id,
        "iat": now, "exp": now + duration,
    }).encode()).rstrip(b"=").decode()
    sig_input = f"{header}.{payload}"
    sig = base64.urlsafe_b64encode(
        hmac.new(MOCK_JWT_SECRET.encode(), sig_input.encode(), hashlib.sha256).digest()
    ).rstrip(b"=").decode()
    return f"{header}.{payload}.{sig}"


class MockHandler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        pass

    def _respond(self, status, body):
        raw = json.dumps(body).encode() if body else b""
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(raw)

    def _read_body(self):
        length = int(self.headers.get("Content-Length", 0))
        return json.loads(self.rfile.read(length)) if length else {}

    def _log_event(self, domain, localpart, action, details=None):
        key = f"{domain}#{localpart}"
        if key not in EVENTS:
            EVENTS[key] = []
        EVENTS[key].append({
            "rule_key": key,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "action": action,
            "details": details or {},
        })

    # -- routing --

    def do_GET(self):
        path = self.path.split("?")[0].rstrip("/")
        parts = path.strip("/").split("/")

        if path == "/v1/auth/me":
            return self._respond(200, {
                "email": MOCK_USER_EMAIL,
                "tenant_id": MOCK_TENANT_ID,
                "expires_at": int(time.time()) + 28800,
            })

        if path == "/v1/domains":
            return self._respond(200, {"domains": list(DOMAINS.values())})

        if len(parts) == 4 and parts[0] == "v1" and parts[1] == "domains" and parts[3] == "check":
            return self._domains_check(parts[2])

        if len(parts) == 3 and parts[0] == "v1" and parts[1] == "domains":
            return self._domains_show(parts[2])

        if len(parts) == 5 and parts[1] == "rules" and parts[4] == "log":
            return self._rules_log(parts[2], parts[3])

        if len(parts) == 4 and parts[1] == "rules":
            return self._rules_show(parts[2], parts[3])

        if path == "/v1/rules":
            return self._respond(200, {"rules": list(RULES.values())})

        if len(parts) == 3 and parts[1] == "verifications":
            return self._verifications_check(parts[2])

        if path == "/v1/verifications":
            return self._verifications_list()

        self._respond(404, {"error": "not found"})

    def do_POST(self):
        path = self.path.split("?")[0].rstrip("/")
        body = self._read_body()

        # Auth: device flow initiate
        if path == "/v1/auth/device":
            code = "ABCD-2345"
            DEVICE_CODES[code] = {"status": "pending", "poll_count": 0}
            return self._respond(200, {
                "code": code,
                "device_url": f"https://deliverymachine.net/device?code={code}",
                "expires_in": 600,
                "poll_interval": 1,
            })

        # Auth: device flow poll — auto-confirms after 2 polls for faster tests
        if path == "/v1/auth/device/poll":
            code = body.get("code", "")
            entry = DEVICE_CODES.get(code, {"poll_count": 0})
            entry["poll_count"] = entry.get("poll_count", 0) + 1
            if entry["poll_count"] >= 2:
                entry["status"] = "confirmed"
            if entry.get("status") == "confirmed":
                email = body.get("email", MOCK_USER_EMAIL)
                token = _mock_jwt(email, MOCK_TENANT_ID)
                return self._respond(200, {
                    "token": token,
                    "email": email,
                    "tenant_id": MOCK_TENANT_ID,
                    "expires_in": 28800,
                })
            return self._respond(202, {"status": "pending", "message": "Waiting for browser confirmation"})

        # Auth: device flow confirm (browser side)
        if path == "/v1/auth/device/confirm":
            code = body.get("code", "")
            if code in DEVICE_CODES:
                DEVICE_CODES[code]["status"] = "confirmed"
            return self._respond(200, {"message": "Device authorized", "email": MOCK_USER_EMAIL})

        # Auth: login (TOTP)
        if path == "/v1/auth/login":
            token = _mock_jwt(MOCK_USER_EMAIL, MOCK_TENANT_ID)
            return self._respond(200, {
                "token": token,
                "email": body.get("email", MOCK_USER_EMAIL),
                "tenant_id": MOCK_TENANT_ID,
                "expires_in": 28800,
            })

        # Auth: TOTP setup
        if path == "/v1/auth/setup":
            email = body.get("email", MOCK_USER_EMAIL)
            return self._respond(201, {
                "email": email,
                "provisioning_uri": f"otpauth://totp/Delivery%20Machine:{email}?secret=JBSWY3DPEHPK3PXP&issuer=Delivery%20Machine",
                "secret": "JBSWY3DPEHPK3PXP",
                "message": "Scan the QR code, then verify with POST /v1/auth/totp/verify",
            })

        # Auth: TOTP verify
        if path == "/v1/auth/totp/verify":
            return self._respond(200, {"message": "TOTP verified. You can now use dm login."})

        if path == "/v1/domains":
            return self._domains_add(body)

        if path == "/v1/rules":
            return self._rules_add(body)

        # POST /v1/verifications (resend)
        if path == "/v1/verifications":
            dest = body.get("destination", "")
            return self._respond(202, {
                "message": f"Verification email sent to {dest}.",
                "verified": False,
            })

        self._respond(404, {"error": "not found"})

    def do_PUT(self):
        path = self.path.split("?")[0].rstrip("/")
        parts = path.strip("/").split("/")
        body = self._read_body()

        if len(parts) == 4 and parts[1] == "rules":
            return self._rules_update(parts[2], parts[3], body)

        self._respond(404, {"error": "not found"})

    def do_DELETE(self):
        path = self.path.split("?")[0].rstrip("/")
        parts = path.strip("/").split("/")

        if len(parts) == 4 and parts[1] == "rules":
            key = f"{parts[2]}#{parts[3]}"
            RULES.pop(key, None)
            return self._respond(204, {})

        if len(parts) == 3 and parts[1] == "domains":
            DOMAINS.pop(parts[2], None)
            return self._respond(204, {})

        self._respond(404, {"error": "not found"})

    # -- domain handlers --

    def _domain_response(self, item):
        domain = item["domain"]
        token = item.get("verification_token", "")
        return {
            "domain": item,
            "dns_records": [
                {
                    "type": "TXT",
                    "name": f"_dm-verify.{domain}",
                    "value": f"dm-verify={token}",
                    "purpose": "Prove domain ownership to Delivery Machine",
                },
                {
                    "type": "MX",
                    "name": domain,
                    "value": f"10 {MX_HOST}",
                    "purpose": "Route inbound email to Delivery Machine",
                },
            ],
            "message": "Add the TXT record to prove domain ownership, then add the MX record. "
                       "Rules cannot be created until the domain is verified.",
        }

    def _domains_add(self, body):
        domain = body.get("domain", "unknown.com")
        if domain in DOMAINS:
            return self._respond(200, self._domain_response(DOMAINS[domain]))
        token = secrets.token_hex(12)
        item = {
            "domain": domain,
            "tenant_id": "default",
            "verified": False,
            "verification_token": token,
            "created_at": _ts(),
        }
        DOMAINS[domain] = item
        return self._respond(202, self._domain_response(item))

    def _domains_show(self, domain):
        if domain not in DOMAINS:
            return self._respond(404, {"error": "Domain not found"})
        return self._respond(200, self._domain_response(DOMAINS[domain]))

    def _domains_check(self, domain):
        if domain not in DOMAINS:
            return self._respond(404, {"error": "Domain not found"})
        item = DOMAINS[domain]
        token = item.get("verification_token", "")
        expected_txt = f"dm-verify={token}"

        checks = [
            {
                "record": "TXT",
                "name": f"_dm-verify.{domain}",
                "expected": expected_txt,
                "found": [expected_txt],
                "ok": True,
                "purpose": "Domain ownership verification",
            },
            {
                "record": "MX",
                "name": domain,
                "expected": f"10 {MX_HOST}",
                "found": [f"10 {MX_HOST}"],
                "ok": True,
                "purpose": "Inbound email routing",
            },
        ]
        item["verified"] = True
        return self._respond(200, {
            "domain": domain,
            "verified": True,
            "all_records_ok": True,
            "checks": checks,
        })

    # -- rule handlers --

    def _rules_add(self, body):
        domain = body.get("domain", "example.com")
        localpart = body.get("localpart", "hello")

        if domain not in DOMAINS:
            return self._respond(404, {
                "error": f"Domain '{domain}' is not registered. Use POST /v1/domains first.",
            })
        if not DOMAINS[domain].get("verified"):
            DOMAINS[domain]["verified"] = True

        # Parse destinations — support both list and single string
        dests = body.get("destinations", [])
        if not dests and body.get("destination"):
            dests = [{"address": body["destination"], "role": "to"}]
        for d in dests:
            d.setdefault("role", "to")
            d.setdefault("unsubscribe_token", secrets.token_hex(16))

        key = f"{domain}#{localpart}"
        item = {
            "domain": domain,
            "localpart": localpart,
            "destinations": dests,
            "enabled": True,
            "description": body.get("description", ""),
            "created_at": _ts(),
            "tenant_id": "default",
        }
        if body.get("expires_at"):
            item["expires_at"] = body["expires_at"]

        RULES[key] = item
        self._log_event(domain, localpart, "rule_created", {
            "destinations": [
                f"{d['address']} ({d.get('role', 'to')})" for d in dests
            ],
        })
        return self._respond(201, {"rule": item})

    def _rules_show(self, domain, localpart):
        key = f"{domain}#{localpart}"
        if key not in RULES:
            return self._respond(404, {"error": "Rule not found"})
        return self._respond(200, {"rule": RULES[key]})

    def _rules_update(self, domain, localpart, body):
        key = f"{domain}#{localpart}"
        if key not in RULES:
            return self._respond(404, {"error": "Rule not found"})
        if "enabled" in body:
            RULES[key]["enabled"] = body["enabled"]
        return self._respond(200, {"updated": True})

    def _rules_log(self, domain, localpart):
        key = f"{domain}#{localpart}"
        events = EVENTS.get(key, [])
        return self._respond(200, {"events": events})

    # -- verification handlers --

    def _verifications_list(self):
        dests = set()
        for r in RULES.values():
            for d in r.get("destinations", []):
                dests.add(d["address"])

        verifications = []
        for d in sorted(dests):
            verifications.append({
                "destination": d,
                "verified": True,
                "verified_at": _ts(-7),
            })
        return self._respond(200, {"verifications": verifications})

    def _verifications_check(self, destination):
        destination = urllib.parse.unquote(destination)
        referencing = []
        for r in RULES.values():
            for d in r.get("destinations", []):
                if d["address"] == destination:
                    referencing.append({
                        "domain": r["domain"],
                        "localpart": r["localpart"],
                        "enabled": r.get("enabled", True),
                        "role": d.get("role", "to"),
                    })

        return self._respond(200, {
            "verification": {
                "destination": destination,
                "verified": True,
                "verified_at": _ts(-7),
                "created_at": _ts(-14),
                "rules": referencing,
            },
        })


def start_mock_api(port=9199):
    server = HTTPServer(("127.0.0.1", port), MockHandler)
    t = threading.Thread(target=server.serve_forever, daemon=True)
    t.start()
    return server
