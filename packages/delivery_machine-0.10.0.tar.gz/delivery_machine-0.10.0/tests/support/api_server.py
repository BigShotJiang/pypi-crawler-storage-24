"""Thin HTTP server that wraps the real API Lambda handler.

Translates HTTP requests into API Gateway event dicts, calls the Lambda
handler, and returns the response. This lets the dm CLI talk to the real
API code running locally.

Stubs:
  - SES: all send_email calls are logged but not sent.
  - SSM: returns JWT secret from the JWT_SECRET env var.
  - DNS lookups: monkey-patched to return "found" for any domain
    registered in the local DynamoDB.
  - DynamoDB: pointed at DynamoDB Local via DYNAMODB_ENDPOINT env var.
  - TOTP: pyotp.random_base32 returns a fixed secret so tests can
    compute the correct code.
  - Device flow: pending device codes are auto-confirmed after a delay
    (simulating browser confirmation).
"""

import importlib
import json
import logging
import os
import sys
import threading
import time
from http.server import HTTPServer, BaseHTTPRequestHandler
from unittest.mock import MagicMock
from urllib.parse import urlparse, parse_qs

logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")
logger = logging.getLogger(__name__)

DYNAMODB_ENDPOINT = os.environ.get("DYNAMODB_ENDPOINT", "http://dynamodb-local:8000")

# Fixed TOTP secret — tests use this to compute valid codes.
FIXED_TOTP_SECRET = "JBSWY3DPEHPK3PXP"


def _configure_boto3():
    """Patch boto3 so DynamoDB points at DynamoDB Local, SES is a no-op,
    and SSM returns the JWT secret from env."""
    import boto3

    jwt_secret = os.environ.get("JWT_SECRET", "test-jwt-secret-not-for-production")

    _real_client = boto3.client.__wrapped__ if hasattr(boto3.client, "__wrapped__") else boto3.client
    _real_resource = boto3.resource.__wrapped__ if hasattr(boto3.resource, "__wrapped__") else boto3.resource

    def patched_client(service, *args, **kwargs):
        if service == "ses":
            mock = MagicMock()
            mock.send_email.return_value = {"MessageId": "stub-no-email-sent"}
            return mock
        if service == "ssm":
            mock = MagicMock()
            mock.get_parameter.return_value = {
                "Parameter": {"Value": jwt_secret}
            }
            return mock
        if service == "dynamodb":
            kwargs.setdefault("endpoint_url", DYNAMODB_ENDPOINT)
            kwargs.setdefault("region_name", "us-east-1")
        return _real_client(service, *args, **kwargs)

    def patched_resource(service, *args, **kwargs):
        if service == "dynamodb":
            kwargs.setdefault("endpoint_url", DYNAMODB_ENDPOINT)
            kwargs.setdefault("region_name", "us-east-1")
        return _real_resource(service, *args, **kwargs)

    patched_client.__wrapped__ = _real_client
    patched_resource.__wrapped__ = _real_resource
    boto3.client = patched_client
    boto3.resource = patched_resource


def _fix_totp_secret():
    """Make pyotp.random_base32 return a fixed secret so tests can
    compute valid TOTP codes."""
    import pyotp
    pyotp._real_random_base32 = pyotp.random_base32
    pyotp.random_base32 = lambda *a, **kw: FIXED_TOTP_SECRET


def _setup_import_path():
    """Make the ``auth`` module importable at top level (as the handler
    expects ``from auth import ...``)."""
    lambda_api_dir = os.path.join(os.path.dirname(__file__), "..", "..", "lambda_api")
    lambda_api_dir = os.path.abspath(lambda_api_dir)
    if lambda_api_dir not in sys.path:
        sys.path.insert(0, lambda_api_dir)

    auth_path = os.path.join(lambda_api_dir, "auth.py")
    spec = importlib.util.spec_from_file_location("auth", auth_path)
    auth_mod = importlib.util.module_from_spec(spec)
    sys.modules["auth"] = auth_mod
    spec.loader.exec_module(auth_mod)


# Apply stubs before importing the handler.
_configure_boto3()
_fix_totp_secret()
_setup_import_path()

# Now import the handler — it will pick up our patched boto3.
from lambda_api import handler as api_handler

# Import auth for device flow auto-confirmation.
import auth as auth_module


def _stub_dns():
    """Monkey-patch the handler's DNS lookup to always return matching records."""

    def fake_dns_lookup(name, record_type):
        import boto3
        dynamodb = boto3.resource("dynamodb")

        if record_type == "TXT" and name.startswith("_dm-verify."):
            domain = name[len("_dm-verify."):]
            try:
                table = dynamodb.Table(api_handler.DOMAINS_TABLE)
                item = table.get_item(Key={"domain": domain}).get("Item")
                if item:
                    token = item.get("verification_token", "")
                    return [f"dm-verify={token}"]
            except Exception:
                pass
            return []

        if record_type == "MX":
            return [f"10 {api_handler.MX_HOST}"]

        return []

    api_handler._dns_lookup = fake_dns_lookup


_stub_dns()


# ---------------------------------------------------------------------------
# Device flow auto-confirmer
# ---------------------------------------------------------------------------

_auto_confirm_running = False


def _start_device_auto_confirmer():
    """Background thread that watches for pending device codes in DynamoDB
    and auto-confirms them after a short delay (simulating browser auth)."""
    global _auto_confirm_running
    if _auto_confirm_running:
        return
    _auto_confirm_running = True

    import boto3
    dynamodb = boto3.resource("dynamodb")
    device_table_name = os.environ.get("DEVICE_CODES_TABLE", "dm-test-device-codes")
    users_table_name = os.environ.get("USERS_TABLE", "dm-test-users")

    def confirmer():
        while True:
            time.sleep(1)
            try:
                table = dynamodb.Table(device_table_name)
                result = table.scan()
                for item in result.get("Items", []):
                    if item.get("status") != "pending":
                        continue
                    code = item["code"]

                    # Find the first verified user to act as the confirmer.
                    users_table = dynamodb.Table(users_table_name)
                    users = users_table.scan().get("Items", [])
                    verified_user = next(
                        (u for u in users if u.get("totp_verified")),
                        None,
                    )
                    if not verified_user:
                        continue

                    email = verified_user["email"]
                    tenant_id = verified_user.get("tenant_id", "default")

                    # Resolve session duration
                    requested_hours = None
                    if "session_hours" in item:
                        try:
                            requested_hours = float(item["session_hours"])
                        except (TypeError, ValueError):
                            pass
                    duration_seconds, _ = auth_module.resolve_session_duration(
                        requested_hours, tenant_id
                    )

                    # Create JWT for the CLI
                    cli_token = auth_module.create_jwt(email, tenant_id, duration_seconds)
                    if not cli_token:
                        continue

                    # Confirm the device code
                    table.update_item(
                        Key={"code": code},
                        UpdateExpression="SET #s = :confirmed, jwt = :jwt, email = :email, tenant_id = :tid, expires_in_seconds = :exp",
                        ExpressionAttributeNames={"#s": "status"},
                        ExpressionAttributeValues={
                            ":confirmed": "confirmed",
                            ":jwt": cli_token,
                            ":email": email,
                            ":tid": tenant_id,
                            ":exp": duration_seconds,
                        },
                    )
                    logger.info("Auto-confirmed device code %s for %s", code, email)
            except Exception:
                pass  # DynamoDB Local might not be ready yet

    t = threading.Thread(target=confirmer, daemon=True)
    t.start()


# ---------------------------------------------------------------------------
# HTTP handler
# ---------------------------------------------------------------------------

class APIHandler(BaseHTTPRequestHandler):
    """Translate HTTP -> Lambda event -> HTTP response."""

    def log_message(self, fmt, *args):
        logger.debug(fmt, *args)

    def _call_lambda(self, method):
        parsed = urlparse(self.path)
        path = parsed.path
        qs = parse_qs(parsed.query)
        query_params = {k: v[0] for k, v in qs.items()} if qs else None

        content_length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(content_length).decode() if content_length else None

        event = {
            "httpMethod": method,
            "path": path,
            "queryStringParameters": query_params,
            "headers": dict(self.headers),
            "body": body,
        }

        result = api_handler.handler(event, None)

        status = result.get("statusCode", 200)
        resp_headers = result.get("headers", {})
        resp_body = result.get("body", "")

        self.send_response(status)
        for k, v in resp_headers.items():
            self.send_header(k, v)
        self.end_headers()
        if resp_body:
            self.wfile.write(resp_body.encode() if isinstance(resp_body, str) else resp_body)

    def do_GET(self):
        self._call_lambda("GET")

    def do_POST(self):
        self._call_lambda("POST")

    def do_PUT(self):
        self._call_lambda("PUT")

    def do_DELETE(self):
        self._call_lambda("DELETE")

    def do_OPTIONS(self):
        self._call_lambda("OPTIONS")


def start_api_server(port=9199):
    """Start the API server and device-code auto-confirmer."""
    _start_device_auto_confirmer()
    server = HTTPServer(("0.0.0.0", port), APIHandler)
    t = threading.Thread(target=server.serve_forever, daemon=True)
    t.start()
    logger.info("API server (real handler) on port %d", port)
    return server


if __name__ == "__main__":
    port = int(os.environ.get("PORT", "9199"))
    logger.info("Starting API server on port %d", port)
    _start_device_auto_confirmer()
    server = HTTPServer(("0.0.0.0", port), APIHandler)
    server.serve_forever()
