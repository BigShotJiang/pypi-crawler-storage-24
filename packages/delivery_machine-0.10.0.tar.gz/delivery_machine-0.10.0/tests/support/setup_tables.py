"""Create DynamoDB tables in DynamoDB Local for testing.

Matches the schemas in terraform/dynamodb.tf and terraform/auth.tf.
"""

import os
import time
import logging

import boto3
from botocore.exceptions import ClientError

logger = logging.getLogger(__name__)

DYNAMODB_ENDPOINT = os.environ.get("DYNAMODB_ENDPOINT", "http://dynamodb-local:8000")

TABLE_DEFS = [
    # Rules: PK=domain, SK=localpart, GSI tenant-index on tenant_id
    {
        "TableName": os.environ.get("RULES_TABLE", "dm-test-rules"),
        "KeySchema": [
            {"AttributeName": "domain", "KeyType": "HASH"},
            {"AttributeName": "localpart", "KeyType": "RANGE"},
        ],
        "AttributeDefinitions": [
            {"AttributeName": "domain", "AttributeType": "S"},
            {"AttributeName": "localpart", "AttributeType": "S"},
            {"AttributeName": "tenant_id", "AttributeType": "S"},
        ],
        "GlobalSecondaryIndexes": [
            {
                "IndexName": "tenant-index",
                "KeySchema": [
                    {"AttributeName": "tenant_id", "KeyType": "HASH"},
                ],
                "Projection": {"ProjectionType": "ALL"},
            },
        ],
    },
    # Events: PK=rule_key, SK=timestamp
    {
        "TableName": os.environ.get("EVENTS_TABLE", "dm-test-events"),
        "KeySchema": [
            {"AttributeName": "rule_key", "KeyType": "HASH"},
            {"AttributeName": "timestamp", "KeyType": "RANGE"},
        ],
        "AttributeDefinitions": [
            {"AttributeName": "rule_key", "AttributeType": "S"},
            {"AttributeName": "timestamp", "AttributeType": "S"},
        ],
    },
    # Domains: PK=domain
    {
        "TableName": os.environ.get("DOMAINS_TABLE", "dm-test-domains"),
        "KeySchema": [
            {"AttributeName": "domain", "KeyType": "HASH"},
        ],
        "AttributeDefinitions": [
            {"AttributeName": "domain", "AttributeType": "S"},
        ],
    },
    # Tenants: PK=tenant_id
    {
        "TableName": os.environ.get("TENANTS_TABLE", "dm-test-tenants"),
        "KeySchema": [
            {"AttributeName": "tenant_id", "KeyType": "HASH"},
        ],
        "AttributeDefinitions": [
            {"AttributeName": "tenant_id", "AttributeType": "S"},
        ],
    },
    # Verifications: PK=destination
    {
        "TableName": os.environ.get("VERIFICATIONS_TABLE", "dm-test-verifications"),
        "KeySchema": [
            {"AttributeName": "destination", "KeyType": "HASH"},
        ],
        "AttributeDefinitions": [
            {"AttributeName": "destination", "AttributeType": "S"},
        ],
    },
    # Users: PK=email
    {
        "TableName": os.environ.get("USERS_TABLE", "dm-test-users"),
        "KeySchema": [
            {"AttributeName": "email", "KeyType": "HASH"},
        ],
        "AttributeDefinitions": [
            {"AttributeName": "email", "AttributeType": "S"},
        ],
    },
    # Device codes: PK=code
    {
        "TableName": os.environ.get("DEVICE_CODES_TABLE", "dm-test-device-codes"),
        "KeySchema": [
            {"AttributeName": "code", "KeyType": "HASH"},
        ],
        "AttributeDefinitions": [
            {"AttributeName": "code", "AttributeType": "S"},
        ],
    },
]


def wait_for_dynamodb(endpoint, timeout=30):
    """Wait for DynamoDB Local to be ready."""
    client = boto3.client(
        "dynamodb",
        endpoint_url=endpoint,
        region_name="us-east-1",
        aws_access_key_id="test",
        aws_secret_access_key="test",
    )
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            client.list_tables()
            return client
        except Exception:
            time.sleep(0.5)
    raise RuntimeError(f"DynamoDB Local not ready at {endpoint} after {timeout}s")


def create_tables(endpoint=None):
    """Create all required tables. Idempotent — skips existing tables."""
    endpoint = endpoint or DYNAMODB_ENDPOINT
    client = wait_for_dynamodb(endpoint)

    for table_def in TABLE_DEFS:
        name = table_def["TableName"]
        try:
            client.create_table(
                **table_def,
                BillingMode="PAY_PER_REQUEST",
            )
            logger.info("Created table: %s", name)
        except ClientError as e:
            if e.response["Error"]["Code"] == "ResourceInUseException":
                logger.info("Table exists: %s", name)
            else:
                raise

    # Seed the "default" tenant so `dm users add` (which uses tenant_id="default")
    # can subsequently perform domain/rule operations.
    tenants_table = os.environ.get("TENANTS_TABLE", "dm-test-tenants")
    dynamodb = boto3.resource(
        "dynamodb",
        endpoint_url=endpoint,
        region_name="us-east-1",
        aws_access_key_id="test",
        aws_secret_access_key="test",
    )
    dynamodb.Table(tenants_table).put_item(Item={
        "tenant_id": "default",
        "plan": "test",
        "max_domains": 100,
        "max_rules_per_domain": 100,
    })
    logger.info("Seeded default tenant")


def drop_all_tables(endpoint=None):
    """Drop all test tables for a clean slate."""
    endpoint = endpoint or DYNAMODB_ENDPOINT
    client = boto3.client(
        "dynamodb",
        endpoint_url=endpoint,
        region_name="us-east-1",
        aws_access_key_id="test",
        aws_secret_access_key="test",
    )
    for table_def in TABLE_DEFS:
        name = table_def["TableName"]
        try:
            client.delete_table(TableName=name)
            logger.info("Dropped table: %s", name)
        except ClientError as e:
            if e.response["Error"]["Code"] != "ResourceNotFoundException":
                raise


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    create_tables()
