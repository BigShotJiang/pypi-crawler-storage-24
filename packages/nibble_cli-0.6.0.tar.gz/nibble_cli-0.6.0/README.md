[![npm](https://img.shields.io/npm/v/@backendsystems/nibble)](https://www.npmjs.com/package/@backendsystems/nibble)
[![PyPI](https://img.shields.io/pypi/v/nibble-cli)](https://pypi.org/project/nibble-cli/)
[![Go Reference](https://pkg.go.dev/badge/github.com/backendsystems/nibble.svg)](https://pkg.go.dev/github.com/backendsystems/nibble)

<div align="center">
  <img src="nibble.svg" alt="Nibble" width="200">
</div>


Nibble is a CLI tool for local network scanning that focuses on speed and ease of use.

Select a network interface, and Nibble scans your local subnet. Lists hosts, hardware manufacturer, open ports and their services.

![Nibble demo](https://raw.githubusercontent.com/backendsystems/nibble/main/demo.gif)

- Lightning fast scans using lightweight threads
- Stealthy, emits no network signals before a scan is started
- Colors uses your terminal theme colors
- Skips loopback and irrelevant adapters
- Defaults to SSH, Telnet, HTTP, HTTPS, SMB, RDP, and more
- Can be set to a list of custom ports that are stored for future use
- Target mode for targeted network scans
- Reads service banners on open ports (for example, OpenSSH or nginx versions)
- Looks up hardware vendors: 
  - Raspberry Pi, Ubiquiti, Apple and 40,000 other vendor ids

## History
See past scans, the found hosts and re-scan all hosts ports. hotkey: `r`  
History remembers your position between sessions, so jump right back in to your last viewed scan.

![Nibble history](https://raw.githubusercontent.com/backendsystems/nibble/main/history.gif)

## Hotkeys
`↑/↓/←/→`, `w/s/a/d`, `h/j/k/l`: selection
`Enter`: confirm
`p`: select ports
`r`: history
`t`: target mode
`q`: cancel
`Ctrl+C`: quit
`?`: help

## Mouse
Full mouse support. Click to select, click again to confirm. Scroll to navigate lists.
Hold `Shift` and drag to select text.

![Nibble click interface](https://raw.githubusercontent.com/backendsystems/nibble/main/click.gif)

## Installation
you may have to restart terminal to run `nibble` after install.


go:
```bash
go install github.com/backendsystems/nibble@latest
```
brew:
```bash
brew install backendsystems/tap/nibble
```
pip:
```bash
pipx install nibble-cli
```
npm:
```bash
npm install -g @backendsystems/nibble
```
or run without install
```bash
npx @backendsystems/nibble
```

## Usage
Run the CLI with `nibble`, select a network interface.  
Interface icons: `🔌` = Ethernet, `📶` = Wi-Fi, `📦` = Container, `🔒` = VPN.

Built with [Bubble Tea](https://github.com/charmbracelet/bubbletea)
