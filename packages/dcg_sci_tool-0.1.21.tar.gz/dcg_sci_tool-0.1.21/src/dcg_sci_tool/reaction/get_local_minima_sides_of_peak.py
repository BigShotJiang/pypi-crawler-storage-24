from ase.io import read,write


def get_local_minima_sides_of_peak():
    """
    读取跑lmps-neb获得的neb_mep.dat文件，找到处于能量峰值两侧的局部最小值对应的序号，
    如果没有，则输出端点序号（0或最大序号），并根据序号和result.xyz，
    输出相应的.xyz文件:mid_IS.xyz和mid_FS.xyz。
    """

    # 读取文件第四列数据
    fourth_column = []
    with open('neb_mep.dat', 'r') as file:
        for line in file:
            line = line.strip()
            if line and not line.startswith('#'):  # 跳过空行和注释行
                columns = line.split()
                if len(columns) >= 4:
                    try:
                        fourth_column.append(float(columns[3]))
                    except ValueError:
                        continue
    
    if not fourth_column:
        return
    
    # 找到最大元素的位置
    max_index = fourth_column.index(max(fourth_column))
    result_indices = []
    
    # 向左搜索
    if max_index > 0:  # 如果不是第一个元素
        for i in range(max_index - 1, -1, -1):
            if fourth_column[i] > fourth_column[i + 1]:
                result_indices.append(i + 1)
                break
        else:  # 如果搜索到数组开头都没有停止
            result_indices.append(0)
    else:  # 如果最大元素就是第一个元素
        result_indices.append(0)
    
    # 向右搜索
    if max_index < len(fourth_column) - 1:  # 如果不是最后一个元素
        for i in range(max_index + 1, len(fourth_column)):
            if fourth_column[i] > fourth_column[i - 1]:
                result_indices.append(i - 1)
                break
        else:  # 如果搜索到数组末尾都没有停止
            result_indices.append(len(fourth_column) - 1)
    else:  # 如果最大元素就是最后一个元素
        result_indices.append(len(fourth_column) - 1)
    
    # 按从小到大的顺序输出
    result_indices.sort()
    # print(f"{result_indices[0]} {result_indices[1]}")
    if result_indices[0] != 0 or result_indices[1] != len(fourth_column) - 1:
        structs=read('result.xyz',':')
        write('mid_IS.xyz',structs[result_indices[0]])
        write('mid_FS.xyz',structs[result_indices[1]])
    return result_indices[0],result_indices[1]