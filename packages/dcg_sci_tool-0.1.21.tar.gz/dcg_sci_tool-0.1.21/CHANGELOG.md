# Changelog

## [0.1.21] - 2026-03-19
### Fixed
- 修改 `resultData2extxyz` 方法，保留原子排序信息

## [0.1.20] - 2026-03-19
### Fixed
- 修改 `construct_CO2_formation_FS` 方法


## [0.1.19] - 2026-03-19
### Fixed
- 修改 `find_matching_files` 方法，使能够适应shell的通配符

## [0.1.18.beta2] - 2026-03-19
### Added
- 新增 `mpirun_lammps` 方法

## [0.1.17] - 2026-03-18
### Fixed
- 修复 `get_target_atoms_from_MD` 方法

## [0.1.16] - 2026-03-18
### Added
- 新增 `get_atoms_with_specific_color` 方法
- 新增 `get_target_atoms_from_MD` 方法

### Changed
- `construct_CO2_formation_FS` 方法中atoms = read(input_file)改为atoms = read(input_file, index = 0)

## [0.1.15] - 2026-03-18
### Added
- 新增 `get_local_minima_sides_of_peak` 方法
- 新增 `resultData2extxyz` 方法
- 新增 `traj2iniData` 方法

### Changed
- `construct_CO2_formation_FS` 方法中min_to_pdau_distance初始值改为float('inf')
- specific文件夹改为applications



## [0.1.14] - 2026-03-18
### Added

- 新增 `find_elements_exclusively_frames` 方法
- 新增 `mark_special_points` 方法
- 新增 `split_xyz_by_elements` 方法
- 新增 `get_xyz_prop_columns` 方法
- 新增 `pre_del_gases` 方法
- 新增 `construct_CO2_formation_FS` 方法

### Changed

- `plot_scatter_color` 方法中添加`mark_special_points`功能
- `create_filtered_structure` 方法中保留原始晶胞信息
- `extract_atom_types` 方法添加自动确定.xyz文件中元素信息所在的列功能


## [0.1.13] - 2026-03-16
### Added

- 新增 `add_config_to_xyz` 方法
- 新增 `plot_scatter_color` 方法

## [0.1.12] - 2026-03-13

### Added

- 新增 `get_hollowSite_outer_neighbors_with_subsurface` 方法
- 新增 `get_hollowSite_Au_Disperation` 方法
- 新增 `find_cluster_surface_hollow_sites` 方法

### Changed

- 文件目录结构重整
- 增加`get_pdau_surface_atoms.py`中的相关注释，提示对于高度标准的`PdAu`团簇，需要改变相关入参值

## [0.1.11] - 2026-03-10

### Added

- 新增 `get_reactants_ad_config_batches` 方法
- 新增 `get_pdau_surface_atoms` 方法
- 新增 `get_OC_bonded_metal_atoms` 方法
- 新增 `find_nearest_hollow_site` 方法
- 新增 `get_outer_surface_neighbors` 方法

### Changed

- 调整 `specific` 目录下的脚本
- 修改 `indexes2expression` 方法

## [0.1.10] - 2026-03-04

### Added

- 新增 `get_reactants_ad_config` 方法

### Changed

- 修改 `detect_CO_coordinating_to_Pd` 函数，使之同时分析与Au配位的CO分子，并更名为 `detect_CO_coordinating_to_PdAu`
- 修改 `create_filtered_structure` 函数，使入参包含 `old_indexes` ：要获得新序号的原始结构中原子的索引的列表，返回参数包含 `new_indexes` ：旧索引 `old_indexes` 对应的新的原子索引列表，并修改调用函数 `get_traj_focusing_reaction_site` 和 `get_traj_focusing_reaction_site_batches`

## [0.1.9] - 2026-03-02

### Added

- 新增 `get_traj_focusing_reaction_site` 方法
- 新增 `parse_nebTraj_file_name` 方法
- 新增 `find_matching_files` 方法
- 新增 `get_traj_focusing_reaction_site_batches` 方法

### Changed

- 调整 `create_filtered_structure` 方法参数列表排序
- 建立 `specific` 文件夹，用于存放粒度较大的代码，并相应调整 `init.py` 文件
- `init.py` 文件格式规范化

## [0.1.8] - 2026-03-02

### Added

- 新增 `get_pdau_cluster_center` 方法
- 新增 `indexes2expression` 方法
- 新增 `rotate_v1_around_p_to_v2` 方法
- 新增 `translate_structure_center` 方法
- 新增 `create_filtered_structure` 方法
- 新增 `get_struct_focusing_reaction_site` 方法

### Changed

- 将 `get_reaction_local_structure` 改名为 `get_reaction_local_atoms_list`
- 将 `identify_gas_molecules_to_delete` 函数改名为 `detect_gas_molecules_for_deletion`
- 将API html、deprecated文件夹（放一些可能有用的代码）放至 `.gitignore` 文件中

## [0.1.7] - 2026-03-01

### Added

- 新增 `identify_gas_molecules_to_delete` 方法
- 新增 `get_reaction_local_structure` 方法

### Changed

- 规范化各个库函数的解释文本

## [0.1.6] - 2026-03-01

### Added

- 新增 `detect_single_adsorbed_O` 方法

## [0.1.5] - 2026-02-28

### Added

- 新增 `detect_CO_coordinating_to_Pd` 方法

### Changed

- 恢复各函数返回分子元组的功能

## [0.1.4] - 2026-02-28

### Changed

- 删除相关函数冗余入参`frame`

## [0.1.3] - 2026-02-25

### Fixed

- 修复导出问题

## [0.1.2] - 2026-02-25

### Added

- 新增 `detect_O2_molecules` 方法
- 新增 `detect_CO_CO2_molecules` 方法

## [0.1.1] - 2026-02-24

### Added

- 新增 `extract_atom_types` 方法
- 新增 `sum_to_n` 方法
