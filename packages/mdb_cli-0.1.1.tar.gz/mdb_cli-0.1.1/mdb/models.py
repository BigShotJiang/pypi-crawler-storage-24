"""Data model classes for mdb tools."""

from dataclasses import dataclass, field


@dataclass
class FeedMarker:
    """A parsed feed marker found in a markdown file."""
    line_number: int
    scope: str
    raw_query: str
    table_name: str | None
    direction: str = "🌀"
    end_line_number: int | None = None


@dataclass
class MarkdownTable:
    """A parsed markdown table immediately following a query marker."""
    columns: list[str]
    rows: list[list[str]]
    start_line: int
    end_line: int
    column_types: list[str] | None = None


@dataclass
class FeedTask:
    """A marker and its associated table, ready for database execution."""
    marker: FeedMarker
    table: MarkdownTable
    resolved_db_path: str


@dataclass
class FeedResult:
    """The outcome of executing a single feed task."""
    task: FeedTask
    success: bool
    error: str | None = None
    rows_written: int = 0
    skipped: bool = False


@dataclass
class TapMarker:
    """A parsed tap marker found in a markdown file."""
    line_number: int
    scope: str
    raw_query: str
    direction: str = "💎"
    end_line_number: int | None = None


@dataclass
class TapResult:
    """The outcome of executing a single tap query."""
    marker: TapMarker
    success: bool
    columns: list[str] = field(default_factory=list)
    rows: list[list[str]] = field(default_factory=list)
    error: str | None = None


@dataclass
class FileMarkers:
    """All parsed markers and content for a single markdown file."""
    filepath: str
    content: str
    lines: list[str]
    tap_markers: list = field(default_factory=list)
    feed_markers: list = field(default_factory=list)


@dataclass
class FeedConflict:
    """A detected cross-file feed conflict."""
    scope: str
    resolved_path: str
    table_name: str
    conflicting: list  # list of (filepath, line_number) tuples
