"""SQL query validators for mdb."""

import re

# Write keywords to reject (case-insensitive, word boundary match)
_WRITE_KEYWORDS_RE = re.compile(
    r'\b(INSERT|UPDATE|DELETE|DROP|ALTER|CREATE)\b',
    re.IGNORECASE,
)


def validate_dql(query: str) -> str | None:
    """Validate that a SQL query contains only read-only (DQL) operations.

    Returns None if valid (read-only), error message string if invalid.
    """
    match = _WRITE_KEYWORDS_RE.search(query)
    if match:
        keyword = match.group(1).upper()
        return f"Query contains write operation: {keyword}"
    return None


def validate_dml(query: str) -> str | None:
    """Validate that all statements in a query are DML.

    Returns None if all statements are valid DML.
    Error message string if any statement is invalid.
    """
    _DML_KEYWORDS = {"INSERT", "UPDATE", "DELETE"}
    _SELECT_KEYWORDS = {"SELECT"}
    _DDL_KEYWORDS = {"CREATE", "DROP", "ALTER"}

    statements = query.split(";")
    for stmt in statements:
        stripped = stmt.strip()
        if not stripped:
            continue
        first_word = stripped.split()[0].upper()
        if first_word in _SELECT_KEYWORDS:
            return "Only mutative queries (INSERT, UPDATE, DELETE) are permitted with push. For SELECT queries, use mdb pull."
        if first_word in _DDL_KEYWORDS:
            return "Only DML statements are permitted. DDL (CREATE, DROP, ALTER) is not supported."
        if first_word not in _DML_KEYWORDS:
            return f"Unrecognized statement keyword: {first_word}. Only INSERT, UPDATE, DELETE are permitted."
    return None
