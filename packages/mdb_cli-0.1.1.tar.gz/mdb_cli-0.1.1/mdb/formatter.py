"""Markdown table generation from query result data."""


def format_markdown_table(
    columns: list[str],
    rows: list[list[str]],
    compaction: str = "full",
) -> str:
    """Generate a formatted markdown table string from columns and rows.

    Args:
        columns: Column header names.
        rows: Row data (list of cell value lists).
        compaction: Compaction mode - "full" (no padding) or "fit" (aligned).

    When compaction="fit":
    - Column widths based on max of header and cell widths (minimum 3 chars)
    - Left-aligned, padded with spaces
    - Zero rows produces header + separator only
    - No trailing newline

    When compaction="full":
    - No column width calculation for alignment purposes
    - Non-empty cells: ``| value |`` (single space before and after content)
    - Empty cells: ``||`` (no spaces, no content)
    - Separator row: ``| --- |`` per column (exactly 3 dashes, space-padded)
    - No trailing newline
    """
    if compaction == "fit":
        return _format_fit(columns, rows)
    # Default to "full" for any value (including unknown values)
    return _format_full(columns, rows)


def _format_fit(columns: list[str], rows: list[list[str]]) -> str:
    """Format a markdown table with aligned columns (fit compaction)."""
    # Calculate column widths
    widths = [max(3, len(col)) for col in columns]
    for row in rows:
        for i, cell in enumerate(row):
            if i < len(widths):
                widths[i] = max(widths[i], len(cell))

    # Build header row
    header_cells = [col.ljust(widths[i]) for i, col in enumerate(columns)]
    header = "| " + " | ".join(header_cells) + " |"

    # Build separator row
    sep_cells = ["-" * widths[i] for i in range(len(columns))]
    separator = "| " + " | ".join(sep_cells) + " |"

    # Build data rows
    lines = [header, separator]
    for row in rows:
        data_cells = []
        for i in range(len(columns)):
            cell = row[i] if i < len(row) else ""
            data_cells.append(cell.ljust(widths[i]))
        lines.append("| " + " | ".join(data_cells) + " |")

    return "\n".join(lines)


def _format_full(columns: list[str], rows: list[list[str]]) -> str:
    """Format a markdown table with no alignment padding (full compaction)."""
    # Build header row -- non-empty cells get single space padding
    header_parts = []
    for col in columns:
        if col:
            header_parts.append(f"| {col} ")
        else:
            header_parts.append("||")
    header = "".join(header_parts) + "|" if header_parts else "|"
    # Fix: if last part was a non-empty cell, it already ends with space
    # We just need trailing |
    # Actually, let's build it more carefully
    header_cells = []
    for col in columns:
        if col:
            header_cells.append(f" {col} ")
        else:
            header_cells.append("")
    header = "|" + "|".join(header_cells) + "|"

    # Build separator row -- exactly 3 dashes per column, space-padded
    sep_cells = [" --- "] * len(columns)
    separator = "|" + "|".join(sep_cells) + "|"

    # Build data rows
    lines = [header, separator]
    for row in rows:
        data_cells = []
        for i in range(len(columns)):
            cell = row[i] if i < len(row) else ""
            if cell:
                data_cells.append(f" {cell} ")
            else:
                data_cells.append("")
        lines.append("|" + "|".join(data_cells) + "|")

    return "\n".join(lines)
