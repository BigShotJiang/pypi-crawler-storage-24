"""Path resolution and file discovery for mdb CLI.

Pure-function module for resolving CLI glob patterns into a deduplicated,
sorted list of markdown file paths. This module has no knowledge of markers,
databases, or processing logic -- it operates purely on filesystem paths.
"""

import glob
import os
import os.path
import pathlib
import sys


def _has_hidden_segment(path: str) -> bool:
    """Check if any component of a path is a hidden directory (starts with '.').

    Args:
        path: File path string (relative or absolute).

    Returns:
        True if any path component starts with '.' (excluding '.' itself).
    """
    parts = pathlib.PurePosixPath(path).parts
    return any(p.startswith(".") and p != "." for p in parts)


def resolve_paths(patterns: list[str]) -> tuple[list[str], list[str]]:
    """Resolve a list of glob patterns into deduplicated, sorted markdown file paths.

    Args:
        patterns: List of glob pattern strings (e.g., ["**/*.md"], ["docs/*"]).

    Returns:
        Tuple of (files, warnings):
            files: Deduplicated, sorted list of resolved absolute .md file paths.
            warnings: List of warning messages (e.g., patterns matching zero files).
    """
    file_set: set[str] = set()
    warnings: list[str] = []

    for pattern in patterns:
        expanded = glob.glob(pattern, recursive=True)
        matched = False
        for path in expanded:
            if not os.path.isfile(path):
                continue
            if not _is_markdown_file(path):
                continue
            if _has_hidden_segment(path):
                continue
            file_set.add(os.path.realpath(path))
            matched = True
        if not matched:
            warnings.append(f"Pattern matched no markdown files: {pattern}")

    sorted_files = sorted(file_set)
    return (sorted_files, warnings)


def _is_markdown_file(path: str) -> bool:
    """Check if a path has a markdown file extension.

    Args:
        path: File path string.

    Returns:
        True if the path ends with .md (case-insensitive).
    """
    return os.path.splitext(path)[1].lower() == ".md"
