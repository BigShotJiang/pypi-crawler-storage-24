"""SQLite pull-phase operations: query execution and feed ingestion."""

import hashlib
import os
import sqlite3

from mdb.models import FeedResult, TapMarker, TapResult


def execute_tap_query(db_path: str, query: str) -> TapResult:
    """Execute a SELECT query against a SQLite database in read-only mode.

    Opens the database via file: URI with mode=ro.
    Returns TapResult with columns, rows, and success/error status.
    Always closes the connection.
    """
    # Create a dummy marker for the result
    marker = TapMarker(line_number=0, scope=db_path, raw_query=query)
    conn = None
    try:
        uri = f"file:{db_path}?mode=ro"
        conn = sqlite3.connect(uri, uri=True)
        cursor = conn.execute(query)
        columns = [desc[0] for desc in cursor.description]
        raw_rows = cursor.fetchall()
        rows = [
            [str(cell) if cell is not None else "" for cell in row]
            for row in raw_rows
        ]
        return TapResult(
            marker=marker,
            success=True,
            columns=columns,
            rows=rows,
        )
    except Exception as e:
        return TapResult(
            marker=marker,
            success=False,
            error=str(e),
        )
    finally:
        if conn:
            conn.close()


def compute_content_hash(
    columns: list[str],
    column_types: list[str],
    rows: list[list[str]],
) -> str:
    """Compute a deterministic SHA-256 hash from column names, types, and row values.

    Returns a 64-character lowercase hexadecimal string.
    """
    parts = []
    # Column definitions: name:TYPE joined by \0
    col_defs = "\0".join(f"{name}:{typ}" for name, typ in zip(columns, column_types))
    parts.append(col_defs)
    # Section separator
    parts.append("\0\0")
    # Row data: cells joined by \0, each row terminated by \n
    for row in rows:
        parts.append("\0".join(row))
        parts.append("\n")
    serialized = "".join(parts)
    return hashlib.sha256(serialized.encode("utf-8")).hexdigest()


def ingest_feed_table(db_path: str, table_name: str, columns: list[str], rows: list[list[str]], column_types: list[str] | None = None) -> FeedResult:
    """Drop and recreate a table in the SQLite database, inserting all rows.

    Creates the database file if it does not exist.
    Wraps DROP + CREATE + INSERT in a single transaction.
    When column_types is provided, uses specified types; otherwise defaults to TEXT.
    """
    try:
        os.makedirs(os.path.dirname(db_path), exist_ok=True)
        conn = sqlite3.connect(db_path)
        try:
            # Quote column names to handle spaces and reserved words
            quoted_cols = [f'"{col}"' for col in columns]
            types_for_hash = column_types if column_types is not None else ["TEXT"] * len(columns)
            if column_types is not None:
                col_defs = ", ".join(
                    f'{qc} {ct}' for qc, ct in zip(quoted_cols, column_types)
                )
            else:
                col_defs = ", ".join(f'{qc} TEXT' for qc in quoted_cols)
            col_list = ", ".join(quoted_cols)
            placeholders = ", ".join("?" for _ in columns)

            conn.execute("BEGIN TRANSACTION")

            # Ensure metadata table exists
            conn.execute(
                "CREATE TABLE IF NOT EXISTS _mdb_meta "
                "(table_name TEXT PRIMARY KEY, content_hash TEXT NOT NULL)"
            )

            # Compute content hash
            computed_hash = compute_content_hash(columns, types_for_hash, rows)

            # Look up stored hash
            cursor = conn.execute(
                "SELECT content_hash FROM _mdb_meta WHERE table_name = ?",
                (table_name,),
            )
            row_result = cursor.fetchone()

            # Skip if hash matches
            if row_result is not None and row_result[0] == computed_hash:
                return FeedResult(
                    task=None,
                    success=True,
                    skipped=True,
                    rows_written=0,
                )

            # Hash mismatch or no stored hash: full write
            conn.execute(f'DROP TABLE IF EXISTS "{table_name}"')
            conn.execute(f'CREATE TABLE "{table_name}" ({col_defs})')

            if rows:
                conn.executemany(
                    f'INSERT INTO "{table_name}" ({col_list}) VALUES ({placeholders})',
                    rows,
                )

            # Store hash
            conn.execute(
                "INSERT OR REPLACE INTO _mdb_meta (table_name, content_hash) VALUES (?, ?)",
                (table_name, computed_hash),
            )

            conn.commit()

            return FeedResult(
                task=None,
                success=True,
                rows_written=len(rows),
            )
        except Exception as e:
            conn.rollback()
            return FeedResult(
                task=None,
                success=False,
                error=str(e),
                rows_written=0,
            )
        finally:
            conn.close()
    except Exception as e:
        return FeedResult(
            task=None,
            success=False,
            error=str(e),
            rows_written=0,
        )


def cleanup_stale_tables(db_path: str, discovered_tables: set[str]) -> list[str]:
    """Remove orphaned tables and their metadata from a database.

    Compares tracked tables in _mdb_meta against the set of table names
    declared by markers in the known universe. Tables present in _mdb_meta
    but not in discovered_tables are dropped and their metadata removed.

    Returns sorted list of removed table names, or [] if no cleanup needed.
    Never raises exceptions to caller.
    """
    if not os.path.exists(db_path):
        return []

    try:
        conn = sqlite3.connect(db_path)
        try:
            # Check if _mdb_meta exists
            cursor = conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table' AND name='_mdb_meta'"
            )
            if cursor.fetchone() is None:
                return []

            # Get tracked table names
            cursor = conn.execute("SELECT table_name FROM _mdb_meta")
            tracked = set(row[0] for row in cursor.fetchall())

            # Compute orphans
            orphaned = tracked - discovered_tables
            if not orphaned:
                return []

            # Remove orphans in a single transaction
            removed = sorted(orphaned)
            conn.execute("BEGIN TRANSACTION")
            for name in removed:
                conn.execute(f'DROP TABLE IF EXISTS "{name}"')
                conn.execute("DELETE FROM _mdb_meta WHERE table_name = ?", (name,))
            conn.commit()

            return removed
        except Exception:
            try:
                conn.rollback()
            except Exception:
                pass
            return []
        finally:
            conn.close()
    except Exception:
        return []
