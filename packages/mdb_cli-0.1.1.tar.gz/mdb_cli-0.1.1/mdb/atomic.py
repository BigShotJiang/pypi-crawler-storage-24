"""Atomic file write via temp-file-then-rename."""

import os
import tempfile


def atomic_write(filepath: str, content: str) -> None:
    """Write content to filepath atomically.

    Creates a temporary file in the same directory, writes content,
    then atomically replaces the target via os.replace().
    On failure, cleans up the temp file and re-raises.
    """
    dir_ = os.path.dirname(filepath) or "."
    fd, tmp = tempfile.mkstemp(dir=dir_, suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(content)
        os.replace(tmp, filepath)
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise
