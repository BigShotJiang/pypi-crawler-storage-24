"""Advisory file locking for concurrency safety."""

import os
import sys
import time
from contextlib import contextmanager

LOCK_TIMEOUT = 3  # seconds
LOCK_RETRY_INTERVAL = 1  # second
LOCK_ERROR_MSG = "mdb: file locked by another process"

if sys.platform == "win32":
    import msvcrt

    def _lock(fd):
        """Acquire non-blocking exclusive lock (Windows)."""
        deadline = time.monotonic() + LOCK_TIMEOUT
        while True:
            try:
                msvcrt.locking(fd.fileno(), msvcrt.LK_NBLCK, 1)
                return
            except OSError:
                if time.monotonic() >= deadline:
                    raise OSError(LOCK_ERROR_MSG)
                time.sleep(LOCK_RETRY_INTERVAL)

    def _unlock(fd):
        """Release exclusive lock (Windows)."""
        try:
            msvcrt.locking(fd.fileno(), msvcrt.LK_UNLCK, 1)
        except OSError:
            pass
else:
    import fcntl

    def _lock(fd):
        """Acquire non-blocking exclusive lock (Unix/macOS)."""
        deadline = time.monotonic() + LOCK_TIMEOUT
        while True:
            try:
                fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                return
            except OSError:
                if time.monotonic() >= deadline:
                    raise OSError(LOCK_ERROR_MSG)
                time.sleep(LOCK_RETRY_INTERVAL)

    def _unlock(fd):
        """Release exclusive lock (Unix/macOS)."""
        fcntl.flock(fd, fcntl.LOCK_UN)


@contextmanager
def batch_lock(filepaths):
    """Context manager: acquire exclusive locks on all filepaths in sorted order.

    Uses separate .lock sidecar files so that atomic_write (which replaces the
    data file via os.replace) does not invalidate the lock fd's inode — avoids
    EIO on close() in overlayfs / container environments.

    On timeout or error, releases all previously acquired locks.
    """
    sorted_paths = sorted(filepaths)
    held = []  # list of (lock_path, open file object)
    try:
        for filepath in sorted_paths:
            if not os.path.exists(filepath):
                raise FileNotFoundError(f"No such file: '{filepath}'")
            lock_path = filepath + ".lock"
            fd = open(lock_path, "a")
            try:
                _lock(fd)
            except BaseException:
                fd.close()
                raise
            held.append((lock_path, fd))
        yield
    finally:
        for lock_path, fd in reversed(held):
            try:
                _unlock(fd)
            except OSError:
                pass
            try:
                fd.close()
            except OSError:
                pass
            try:
                os.unlink(lock_path)
            except OSError:
                pass
