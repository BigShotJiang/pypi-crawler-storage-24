"""Unified CLI entry point for mdb: push, pull subcommands."""

import argparse
import csv
import os
import sqlite3
import sys
from mdb.models import FileMarkers, FeedConflict
from mdb.parser import find_tap_markers, find_feed_markers, find_adjacent_table, parse_markdown_table, resolve_scope_path, parse_header_types_with_annotation_flags, parse_cast_types, resolve_column_types, parse_post_pull_tap_query, parse_pre_push_feed_query
from mdb.formatter import format_markdown_table
from mdb.puller import execute_tap_query, ingest_feed_table, cleanup_stale_tables
from mdb.validators import validate_dql, validate_dml
from mdb.discovery import resolve_paths
from mdb.atomic import atomic_write
from mdb.filelock import batch_lock


def _scope_prefix(scope: str) -> str:
    """Return 'scope ' if non-empty, else '' — avoids double-space in output."""
    return f"{scope} " if scope else ""


# ---------------------------------------------------------------------------
# Row-diff helpers
# ---------------------------------------------------------------------------

def _compute_row_diff(old_rows, new_rows):
    """Compute row-level diff between old and new row lists.

    Returns (added, removed) counts. Treats each row as a tuple.
    A modified row counts as +1 added, +1 removed (like git diff).
    Uses multiset (Counter) logic to handle duplicate rows.
    """
    from collections import Counter
    old_counts = Counter(tuple(r) for r in old_rows)
    new_counts = Counter(tuple(r) for r in new_rows)
    added = 0
    removed = 0
    all_keys = set(old_counts) | set(new_counts)
    for key in all_keys:
        old_n = old_counts.get(key, 0)
        new_n = new_counts.get(key, 0)
        if new_n > old_n:
            added += new_n - old_n
        elif old_n > new_n:
            removed += old_n - new_n
    return added, removed


def _format_row_diff(added, removed):
    """Format row diff as a compact string like (+3), (-2), or (+1 -1)."""
    parts = []
    if added:
        parts.append(f"+{added}")
    if removed:
        parts.append(f"-{removed}")
    if not parts:
        return "(~)"  # content changed but same rows (e.g. schema change)
    return "(" + " ".join(parts) + ")"



def _parse_table_rows(table_str):
    """Parse rows from a markdown table string (header | separator | data rows).

    Returns list of row lists, or empty list if unparseable.
    """
    if not table_str:
        return []
    lines = table_str.strip().split("\n")
    if len(lines) < 2:
        return []
    # Skip header (line 0) and separator (line 1), parse data rows
    rows = []
    for line in lines[2:]:
        cells = [c.strip() for c in line.strip().strip("|").split("|")]
        rows.append(cells)
    return rows


# ---------------------------------------------------------------------------
# Helpers (T002, T003, T004)
# ---------------------------------------------------------------------------

def _collect_file_markers(filepath, include_taps, include_feeds):
    """Parse a single markdown file and extract relevant markers.

    Returns FileMarkers or None on file read error.
    """
    try:
        with open(filepath, "r", encoding="utf-8") as f:
            content = f.read()
    except UnicodeDecodeError:
        print(f"Error [{filepath}]: File is not valid UTF-8", file=sys.stderr)
        return None
    except FileNotFoundError:
        print(f"Error [{filepath}]: File not found", file=sys.stderr)
        return None
    except OSError as e:
        print(f"Error [{filepath}]: {e}", file=sys.stderr)
        return None

    lines = content.splitlines()
    tap_markers = find_tap_markers(content) if include_taps else []
    feed_markers = find_feed_markers(content) if include_feeds else []

    return FileMarkers(
        filepath=filepath,
        content=content,
        lines=lines,
        tap_markers=tap_markers,
        feed_markers=feed_markers,
    )


def _print_summary(files_processed, markers_found, changed, unchanged, failed):
    """Print the final push summary line."""
    print(
        f"Processed {files_processed} files, {markers_found} markers: "
        f"{changed} changed, {unchanged} unchanged, {failed} failed"
    )


def _print_status_summary(files_inspected, markers_found, problems):
    """Print the final status summary line."""
    print(
        f"Inspected {files_inspected} files, {markers_found} markers: "
        f"{problems} problems"
    )


def _discover_files(include_arg: str | None) -> list[str]:
    """Unified file discovery: convert --include CLI arg to sorted list of .md paths.

    Args:
        include_arg: Raw --include argument value, or None if not provided.

    Returns:
        Sorted, deduplicated list of absolute .md file paths.
    """
    if include_arg and include_arg.strip():
        patterns = include_arg.split()
    else:
        patterns = ["**/*.md"]

    files, warnings = resolve_paths(patterns)
    for w in warnings:
        print(w, file=sys.stderr)
    return files


def _normalize_include_for_hash(include_arg: str | None) -> str | None:
    """Normalize include_arg for database path hashing.

    Returns None if include_arg is unset, empty, or equivalent to the default '**/*.md'.
    Otherwise returns the raw include_arg for hashing.
    """
    if not include_arg or not include_arg.strip():
        return None
    tokens = include_arg.split()
    if tokens == ["**/*.md"]:
        return None
    return include_arg


# ---------------------------------------------------------------------------
# Conflict detection (T005)
# ---------------------------------------------------------------------------

def _detect_feed_conflicts(all_file_markers, include_paths=None):
    """Detect cross-file feed conflicts.

    Groups all 🌀 markers by (resolved_path, table_name).
    If markers from more than one file target the same key, that is a conflict.
    Returns list of FeedConflict objects.
    """
    # key: (resolved_path, table_name) -> list of (filepath, line_number)
    groups = {}
    scope_for_key = {}
    for fm in all_file_markers:
        for wm in fm.feed_markers:
            if wm.table_name is None:
                continue
            resolved = resolve_scope_path(wm.scope, fm.filepath, include_paths)
            key = (resolved, wm.table_name)
            groups.setdefault(key, []).append((fm.filepath, wm.line_number))
            scope_for_key[key] = wm.scope

    conflicts = []
    for (resolved_path, table_name), entries in groups.items():
        # Check if entries come from more than one file
        files_seen = set(fp for fp, _ in entries)
        if len(files_seen) > 1:
            conflicts.append(FeedConflict(
                scope=scope_for_key[(resolved_path, table_name)],
                resolved_path=resolved_path,
                table_name=table_name,
                conflicting=entries,
            ))
    return conflicts


def _conflicted_keys(conflicts):
    """Return a set of (resolved_path, table_name) that are conflicted."""
    return set((c.resolved_path, c.table_name) for c in conflicts)


# ---------------------------------------------------------------------------
# Push subcommand (T006, T007)
# ---------------------------------------------------------------------------

def _run_push(filepaths, compaction="full", verbose=False, include_paths=None):
    """Execute the push subcommand: pull phase (all 🌀 markers) first, then push phase (all 💎 markers)."""
    with batch_lock(filepaths):
        return _run_push_locked(filepaths, compaction, verbose, include_paths)


def _run_push_locked(filepaths, compaction="full", verbose=False, include_paths=None):
    """Execute push with all filepaths already locked."""
    changed = 0
    unchanged = 0
    failed = 0
    files_processed = 0

    # Collect all markers from all files (both feed and tap)
    all_fm = []
    for filepath in filepaths:
        fm = _collect_file_markers(filepath, include_taps=True, include_feeds=True)
        if fm is None:
            failed += 1
            files_processed += 1
            continue
        files_processed += 1
        all_fm.append(fm)

    # --- Pull phase: detect conflicts and execute all 🌀 markers ---
    conflicts = _detect_feed_conflicts(all_fm, include_paths)
    conflict_keys = _conflicted_keys(conflicts)

    for conflict in conflicts:
        parts = [f"{fp}:{ln}" for fp, ln in conflict.conflicting]
        locations = " and ".join(parts)
        print(
            f"CONFLICT {_scope_prefix(conflict.scope)}💾 {conflict.table_name} - "
            f"conflicting writes from {locations}"
        )
        failed += len(conflict.conflicting)

    # Collect declared table names per db_path for orphan cleanup (FR-006, FR-013)
    discovered_by_db = {}
    for fm in all_fm:
        for marker in fm.feed_markers:
            if marker.table_name is None:
                continue
            resolved = resolve_scope_path(marker.scope, fm.filepath, include_paths)
            discovered_by_db.setdefault(resolved, set()).add(marker.table_name)

    # Orphan cleanup BEFORE writes (FR-013)
    for db_path, discovered_tables in discovered_by_db.items():
        cleanup_stale_tables(db_path, discovered_tables)

    for fm in all_fm:
        for marker in fm.feed_markers:
            resolved = resolve_scope_path(marker.scope, fm.filepath, include_paths)

            if marker.table_name is None:
                msg = f"Could not parse table name from query: {marker.raw_query}"
                print(
                    f"FAIL {_scope_prefix(marker.scope)}🌀 (unknown) - {msg} "
                    f"[{fm.filepath}:{marker.line_number}]"
                )
                print(
                    f"Error [{fm.filepath}:{marker.line_number}]: {msg}",
                    file=sys.stderr,
                )
                failed += 1
                continue

            if (resolved, marker.table_name) in conflict_keys:
                continue

            table, table_line_idx = find_adjacent_table(
                fm.lines, marker.line_number, marker.end_line_number
            )
            if table is None:
                msg = "No markdown table found after marker"
                print(
                    f"WARN {_scope_prefix(marker.scope)}🌀 {marker.table_name} - {msg} "
                    f"[{fm.filepath}:{marker.line_number}]"
                )
                print(
                    f"Error [{fm.filepath}:{marker.line_number}]: {msg}",
                    file=sys.stderr,
                )
                failed += 1
                continue

            col_names, col_types, was_annotated, type_warnings, type_errors = \
                parse_header_types_with_annotation_flags(table.columns)

            for warn in type_warnings:
                print(
                    f"WARN {warn} [{fm.filepath}:{marker.line_number}]",
                    file=sys.stderr,
                )

            if type_errors:
                for err in type_errors:
                    print(
                        f"FAIL {_scope_prefix(marker.scope)}🌀 {marker.table_name} - "
                        f"{err} [{fm.filepath}:{marker.line_number}]"
                    )
                    print(
                        f"Error [{fm.filepath}:{marker.line_number}]: {err}",
                        file=sys.stderr,
                    )
                failed += 1
                continue

            cast_types, cast_errors = parse_cast_types(marker.raw_query)

            if cast_errors:
                for err in cast_errors:
                    print(
                        f"FAIL {_scope_prefix(marker.scope)}🌀 {marker.table_name} - "
                        f"{err} [{fm.filepath}:{marker.line_number}]"
                    )
                    print(
                        f"Error [{fm.filepath}:{marker.line_number}]: {err}",
                        file=sys.stderr,
                    )
                failed += 1
                continue

            final_types = resolve_column_types(
                col_types, cast_types, len(col_names), was_annotated
            )

            # Capture original table string for before/after markdown
            # comparison — same change-detection approach as tap markers.
            original_feed_str = "\n".join(
                fm.lines[table.start_line - 1:table.end_line]
            )

            try:
                result = ingest_feed_table(
                    db_path=resolved,
                    table_name=marker.table_name,
                    columns=col_names,
                    rows=table.rows,
                    column_types=final_types,
                )
                if result.success:
                    # Re-read markdown after ingestion to detect changes.
                    # Standard push ingests markdown → DB without rewriting
                    # the feed table, so the snapshot is unchanged here.
                    # (Mutative-query push rewrites feeds separately via
                    # _run_push_with_feed_query.)
                    current_feed_str = "\n".join(
                        fm.lines[table.start_line - 1:table.end_line]
                    )
                    feed_changed = (current_feed_str != original_feed_str)

                    if feed_changed:
                        old_feed_rows = _parse_table_rows(original_feed_str)
                        added, removed = _compute_row_diff(
                            old_feed_rows, table.rows
                        )
                        diff_str = _format_row_diff(added, removed)
                        print(
                            f"OK   {_scope_prefix(marker.scope)}🌀 {marker.table_name} "
                            f"{diff_str} [{fm.filepath}:{marker.line_number}]"
                        )
                        changed += 1
                    else:
                        if verbose:
                            print(
                                f"SKIP {_scope_prefix(marker.scope)}🌀 {marker.table_name} "
                                f"(unchanged) [{fm.filepath}:{marker.line_number}]"
                            )
                        unchanged += 1
                else:
                    print(
                        f"FAIL {_scope_prefix(marker.scope)}🌀 {marker.table_name} - "
                        f"{result.error} [{fm.filepath}:{marker.line_number}]"
                    )
                    print(
                        f"Error [{fm.filepath}:{marker.line_number}]: {result.error}",
                        file=sys.stderr,
                    )
                    failed += 1
            except Exception as e:
                print(
                    f"FAIL {_scope_prefix(marker.scope)}🌀 {marker.table_name} - "
                    f"{e} [{fm.filepath}:{marker.line_number}]"
                )
                print(
                    f"Error [{fm.filepath}:{marker.line_number}]: {e}",
                    file=sys.stderr,
                )
                failed += 1

    # --- Push phase: execute all 💎 markers ---
    file_replacements = {}

    for fm in all_fm:
        replacements = []

        for marker in fm.tap_markers:
            db_path = resolve_scope_path(marker.scope, fm.filepath, include_paths)

            validation_error = validate_dql(marker.raw_query)
            if validation_error:
                print(
                    f"FAIL {_scope_prefix(marker.scope)}💎 {marker.raw_query} - "
                    f"{validation_error} [{fm.filepath}:{marker.line_number}]"
                )
                print(
                    f"Error [{fm.filepath}:{marker.line_number}]: {validation_error}",
                    file=sys.stderr,
                )
                failed += 1
                continue

            table, table_line_idx = find_adjacent_table(
                fm.lines, marker.line_number, marker.end_line_number
            )

            # Capture original table lines for before/after comparison (FR-006a)
            if table is not None:
                original_table_str = "\n".join(
                    fm.lines[table.start_line - 1:table.end_line]
                )
            else:
                original_table_str = None  # dangling: no original table

            result = execute_tap_query(db_path, marker.raw_query)
            if not result.success:
                print(
                    f"FAIL {_scope_prefix(marker.scope)}💎 {marker.raw_query} - "
                    f"{result.error} [{fm.filepath}:{marker.line_number}]"
                )
                print(
                    f"Error [{fm.filepath}:{marker.line_number}]: {result.error}",
                    file=sys.stderr,
                )
                failed += 1
                continue

            new_table_str = format_markdown_table(
                result.columns, result.rows, compaction=compaction
            )
            new_table_lines = new_table_str.split("\n")

            if table is None:
                # Dangling tap marker: insert new table after marker/fence
                insert_after = marker.end_line_number if marker.end_line_number else marker.line_number
                insert_idx = insert_after  # 0-based index after marker line
                new_lines = [""] + new_table_lines  # blank line before table
                replacements.append((insert_idx, insert_idx - 1, new_lines))
                # Dangling tap is always "changed" (C-009)
                tap_changed = True
            else:
                table_start_idx = table.start_line - 1
                table_end_idx = table.end_line - 1
                replacements.append((table_start_idx, table_end_idx, new_table_lines))
                # Compare before/after (C-008)
                tap_changed = (new_table_str != original_table_str)

            if tap_changed:
                old_tap_rows = _parse_table_rows(original_table_str)
                added, removed = _compute_row_diff(old_tap_rows, result.rows)
                diff_str = _format_row_diff(added, removed)
                print(
                    f"OK   {_scope_prefix(marker.scope)}💎 {marker.raw_query} "
                    f"{diff_str} [{fm.filepath}:{marker.line_number}]"
                )
                changed += 1
            else:
                if verbose:
                    print(
                        f"SKIP {_scope_prefix(marker.scope)}💎 {marker.raw_query} "
                        f"(unchanged) [{fm.filepath}:{marker.line_number}]"
                    )
                unchanged += 1

        if replacements:
            file_replacements[fm.filepath] = (fm, replacements)

    # Apply read replacements to files
    for filepath, (fm, replacements) in file_replacements.items():
        replacements.sort(key=lambda r: r[0], reverse=True)
        lines = list(fm.lines)
        for start_idx, end_idx, new_lines in replacements:
            lines[start_idx:end_idx + 1] = new_lines

        new_content = "\n".join(lines)
        if fm.content.endswith("\n"):
            new_content += "\n"
        atomic_write(filepath, new_content)

    total_markers = changed + unchanged + failed
    _print_summary(files_processed, total_markers, changed, unchanged, failed)

    if failed > 0:
        return 1
    return 0


# ---------------------------------------------------------------------------
# Pull-with-tap-query subcommand (027-pull-query)
# ---------------------------------------------------------------------------

def _run_pull_with_tap_query(query, include_paths, cwd, verbose=False):
    """Execute the pull-with-tap-query subcommand: discover markers, pull to DB, run query, output CSV."""
    # Parse scope from query argument
    scope_name, sql_query = parse_post_pull_tap_query(query)

    # File discovery
    filepaths = _discover_files(include_paths)

    if not filepaths:
        if scope_name:
            print(f"Error: No markers found for scope '{scope_name}'", file=sys.stderr)
        else:
            print("Error: No data sources found for default scope", file=sys.stderr)
        return 1

    normalized_include = _normalize_include_for_hash(include_paths)
    with batch_lock(filepaths):
        return _run_pull_with_tap_query_locked(filepaths, scope_name, sql_query, normalized_include, verbose)


def _run_pull_with_tap_query_locked(filepaths, scope_name, sql_query, include_paths, verbose=False):
    """Execute pull-with-tap-query with all filepaths already locked."""
    # Collect feed markers from all discovered files
    all_fm = []
    for filepath in filepaths:
        fm = _collect_file_markers(filepath, include_taps=False, include_feeds=True)
        if fm is None:
            continue
        all_fm.append(fm)

    # Scope filtering
    filtered_fm = []
    for fm in all_fm:
        filtered_markers = []
        for marker in fm.feed_markers:
            if scope_name == "":
                # Implicit scope: only markers with empty/whitespace scope
                if marker.scope.strip() == "":
                    filtered_markers.append(marker)
            else:
                # Explicit scope: only markers with exact scope name match
                if marker.scope.strip() == scope_name:
                    filtered_markers.append(marker)
        if filtered_markers:
            # Create a copy of FileMarkers with only matching feed markers
            filtered_fm.append(FileMarkers(
                filepath=fm.filepath,
                content=fm.content,
                lines=fm.lines,
                tap_markers=[],
                feed_markers=filtered_markers,
            ))

    if not filtered_fm:
        if scope_name:
            print(f"Error: No markers found for scope '{scope_name}'", file=sys.stderr)
        else:
            print("Error: No data sources found for default scope", file=sys.stderr)
        return 1

    # Conflict detection
    conflicts = _detect_feed_conflicts(filtered_fm, include_paths)
    conflict_keys = _conflicted_keys(conflicts)

    for conflict in conflicts:
        parts = [f"{fp}:{ln}" for fp, ln in conflict.conflicting]
        locations = " and ".join(parts)
        print(
            f"CONFLICT {_scope_prefix(conflict.scope)}\U0001f4be {conflict.table_name} - "
            f"conflicting writes from {locations}",
            file=sys.stderr,
        )
        return 1

    # Collect declared table names per db_path for orphan cleanup (FR-006, FR-013)
    discovered_by_db = {}
    for fm in filtered_fm:
        for marker in fm.feed_markers:
            if marker.table_name is None:
                continue
            resolved = resolve_scope_path(marker.scope, fm.filepath, include_paths)
            discovered_by_db.setdefault(resolved, set()).add(marker.table_name)

    # Orphan cleanup BEFORE writes (FR-013)
    for db_path, discovered_tables in discovered_by_db.items():
        cleanup_stale_tables(db_path, discovered_tables)

    # Pull phase: feed markers to DB
    pull_failed = 0
    for fm in filtered_fm:
        for marker in fm.feed_markers:
            resolved = resolve_scope_path(marker.scope, fm.filepath, include_paths)

            if marker.table_name is None:
                msg = f"Could not parse table name from query: {marker.raw_query}"
                print(f"Error [{fm.filepath}:{marker.line_number}]: {msg}", file=sys.stderr)
                pull_failed += 1
                continue

            if (resolved, marker.table_name) in conflict_keys:
                continue

            table, table_line_idx = find_adjacent_table(
                fm.lines, marker.line_number, marker.end_line_number
            )
            if table is None:
                msg = "No markdown table found after marker"
                print(f"Error [{fm.filepath}:{marker.line_number}]: {msg}", file=sys.stderr)
                pull_failed += 1
                continue

            col_names, col_types, was_annotated, type_warnings, type_errors = \
                parse_header_types_with_annotation_flags(table.columns)

            for warn in type_warnings:
                print(f"WARN {warn} [{fm.filepath}:{marker.line_number}]", file=sys.stderr)

            if type_errors:
                for err in type_errors:
                    print(f"Error [{fm.filepath}:{marker.line_number}]: {err}", file=sys.stderr)
                pull_failed += 1
                continue

            cast_types, cast_errors = parse_cast_types(marker.raw_query)

            if cast_errors:
                for err in cast_errors:
                    print(f"Error [{fm.filepath}:{marker.line_number}]: {err}", file=sys.stderr)
                pull_failed += 1
                continue

            final_types = resolve_column_types(
                col_types, cast_types, len(col_names), was_annotated
            )

            try:
                result = ingest_feed_table(
                    db_path=resolved,
                    table_name=marker.table_name,
                    columns=col_names,
                    rows=table.rows,
                    column_types=final_types,
                )
                if not result.success:
                    print(f"Error [{fm.filepath}:{marker.line_number}]: {result.error}", file=sys.stderr)
                    pull_failed += 1
            except Exception as e:
                print(f"Error [{fm.filepath}:{marker.line_number}]: {e}", file=sys.stderr)
                pull_failed += 1

    if pull_failed > 0:
        return 1

    # Determine target DB path
    target_db_path = resolve_scope_path(scope_name, "", include_paths)

    # Read-only validation
    validation_error = validate_dql(sql_query)
    if validation_error:
        print(f"Error: Only SELECT queries are permitted. Found: {validation_error.split(': ')[-1]}", file=sys.stderr)
        return 1

    # Query execution
    result = execute_tap_query(target_db_path, sql_query)
    if not result.success:
        print(f"Error: {result.error}", file=sys.stderr)
        return 1

    # CSV output
    writer = csv.writer(sys.stdout)
    writer.writerow(result.columns)
    writer.writerows(result.rows)

    return 0


# ---------------------------------------------------------------------------
# Push-with-feed-query subcommand (028-push-query)
# ---------------------------------------------------------------------------

def _run_push_with_feed_query(scope_name, sql_query, include_paths, compaction, cwd, verbose=False):
    """Execute the push-with-feed-query pipeline: discover -> pull -> mutate -> push back."""
    # File discovery
    filepaths = _discover_files(include_paths)

    if not filepaths:
        if scope_name:
            print(f"Error: No markers found for scope '{scope_name}'", file=sys.stderr)
        else:
            print("Error: No data sources found for default scope", file=sys.stderr)
        return 1

    normalized_include = _normalize_include_for_hash(include_paths)
    with batch_lock(filepaths):
        return _run_push_with_feed_query_locked(filepaths, scope_name, sql_query, normalized_include, compaction, verbose)


def _run_push_with_feed_query_locked(filepaths, scope_name, sql_query, include_paths, compaction, verbose=False):
    """Execute push-with-feed-query with all filepaths already locked."""
    # Collect both feed and tap markers from all discovered files
    all_fm = []
    for filepath in filepaths:
        fm = _collect_file_markers(filepath, include_taps=True, include_feeds=True)
        if fm is None:
            continue
        all_fm.append(fm)

    # Scope filtering: filter both 🌀 and 💎 markers by scope
    filtered_fm = []
    for fm in all_fm:
        filtered_feed = []
        filtered_tap = []
        for marker in fm.feed_markers:
            if scope_name == "":
                if marker.scope.strip() == "":
                    filtered_feed.append(marker)
            else:
                if marker.scope.strip() == scope_name:
                    filtered_feed.append(marker)
        for marker in fm.tap_markers:
            if scope_name == "":
                if marker.scope.strip() == "":
                    filtered_tap.append(marker)
            else:
                if marker.scope.strip() == scope_name:
                    filtered_tap.append(marker)
        if filtered_feed or filtered_tap:
            filtered_fm.append(FileMarkers(
                filepath=fm.filepath,
                content=fm.content,
                lines=fm.lines,
                tap_markers=filtered_tap,
                feed_markers=filtered_feed,
            ))

    # Check for feed markers (needed for pull phase)
    has_feed_markers = any(fm.feed_markers for fm in filtered_fm)
    if not has_feed_markers:
        if scope_name:
            print(f"Error: No markers found for scope '{scope_name}'", file=sys.stderr)
        else:
            print("Error: No data sources found for default scope", file=sys.stderr)
        return 1

    # Conflict detection on feed markers
    conflicts = _detect_feed_conflicts(filtered_fm, include_paths)
    if conflicts:
        for conflict in conflicts:
            parts = [f"{fp}:{ln}" for fp, ln in conflict.conflicting]
            locations = " and ".join(parts)
            print(
                f"CONFLICT {_scope_prefix(conflict.scope)}\U0001f4be {conflict.table_name} - "
                f"conflicting writes from {locations}",
                file=sys.stderr,
            )
        return 1

    # Collect declared table names per db_path for orphan cleanup (FR-006, FR-013)
    discovered_by_db = {}
    for fm in filtered_fm:
        for marker in fm.feed_markers:
            if marker.table_name is None:
                continue
            resolved = resolve_scope_path(marker.scope, fm.filepath, include_paths)
            discovered_by_db.setdefault(resolved, set()).add(marker.table_name)

    # Orphan cleanup BEFORE writes (FR-013)
    for db_path, discovered_tables in discovered_by_db.items():
        cleanup_stale_tables(db_path, discovered_tables)

    # Pull phase: feed 🌀 marker data to DB (re-pull from markdown)
    pull_failed = 0
    for fm in filtered_fm:
        for marker in fm.feed_markers:
            resolved = resolve_scope_path(marker.scope, fm.filepath, include_paths)

            if marker.table_name is None:
                msg = f"Could not parse table name from query: {marker.raw_query}"
                print(f"Error [{fm.filepath}:{marker.line_number}]: {msg}", file=sys.stderr)
                pull_failed += 1
                continue

            table, table_line_idx = find_adjacent_table(
                fm.lines, marker.line_number, marker.end_line_number
            )
            if table is None:
                msg = "No markdown table found after marker"
                print(f"Error [{fm.filepath}:{marker.line_number}]: {msg}", file=sys.stderr)
                pull_failed += 1
                continue

            col_names, col_types, was_annotated, type_warnings, type_errors = \
                parse_header_types_with_annotation_flags(table.columns)

            for warn in type_warnings:
                print(f"WARN {warn} [{fm.filepath}:{marker.line_number}]", file=sys.stderr)

            if type_errors:
                for err in type_errors:
                    print(f"Error [{fm.filepath}:{marker.line_number}]: {err}", file=sys.stderr)
                pull_failed += 1
                continue

            cast_types, cast_errors = parse_cast_types(marker.raw_query)

            if cast_errors:
                for err in cast_errors:
                    print(f"Error [{fm.filepath}:{marker.line_number}]: {err}", file=sys.stderr)
                pull_failed += 1
                continue

            final_types = resolve_column_types(
                col_types, cast_types, len(col_names), was_annotated
            )

            try:
                result = ingest_feed_table(
                    db_path=resolved,
                    table_name=marker.table_name,
                    columns=col_names,
                    rows=table.rows,
                    column_types=final_types,
                )
                if result.success and result.skipped and verbose:
                    print(
                        f"SKIP {_scope_prefix(marker.scope)}🌀 {marker.table_name} "
                        f"(unchanged) [{fm.filepath}:{marker.line_number}]",
                        file=sys.stderr,
                    )
                elif not result.success:
                    print(f"Error [{fm.filepath}:{marker.line_number}]: {result.error}", file=sys.stderr)
                    pull_failed += 1
            except Exception as e:
                print(f"Error [{fm.filepath}:{marker.line_number}]: {e}", file=sys.stderr)
                pull_failed += 1

    if pull_failed > 0:
        return 1

    # Determine target DB path
    target_db_path = resolve_scope_path(scope_name, "", include_paths)

    # Execute mutative query in a single transaction
    conn = None
    try:
        conn = sqlite3.connect(target_db_path)
        conn.execute("BEGIN TRANSACTION")
        for stmt in sql_query.split(";"):
            stripped = stmt.strip()
            if stripped:
                conn.execute(stripped)
        conn.commit()
    except Exception as e:
        if conn:
            conn.rollback()
        print(f"Error: {e}", file=sys.stderr)
        return 1
    finally:
        if conn:
            conn.close()

    # Push-back phase: re-execute queries for both 💎 and 🌀 markers
    file_replacements = {}

    for fm in filtered_fm:
        replacements = []

        # Push-back 💎 tap markers
        for marker in fm.tap_markers:
            db_path = resolve_scope_path(marker.scope, fm.filepath, include_paths)

            validation_error = validate_dql(marker.raw_query)
            if validation_error:
                print(
                    f"Error [{fm.filepath}:{marker.line_number}]: {validation_error}",
                    file=sys.stderr,
                )
                continue

            table, table_line_idx = find_adjacent_table(
                fm.lines, marker.line_number, marker.end_line_number
            )

            result = execute_tap_query(db_path, marker.raw_query)
            if not result.success:
                print(
                    f"Error [{fm.filepath}:{marker.line_number}]: {result.error}",
                    file=sys.stderr,
                )
                continue

            new_table_str = format_markdown_table(
                result.columns, result.rows, compaction=compaction
            )
            new_table_lines = new_table_str.split("\n")

            if table is None:
                # Dangling tap marker: insert new table after marker/fence
                insert_after = marker.end_line_number if marker.end_line_number else marker.line_number
                insert_idx = insert_after  # 0-based index after marker line
                new_lines = [""] + new_table_lines  # blank line before table
                replacements.append((insert_idx, insert_idx - 1, new_lines))
            else:
                table_start_idx = table.start_line - 1
                table_end_idx = table.end_line - 1
                replacements.append((table_start_idx, table_end_idx, new_table_lines))

        # Push-back 🌀 feed markers (conditionally bidirectional)
        for marker in fm.feed_markers:
            db_path = resolve_scope_path(marker.scope, fm.filepath, include_paths)

            table, table_line_idx = find_adjacent_table(
                fm.lines, marker.line_number, marker.end_line_number
            )
            if table is None:
                continue

            # Re-execute the marker's original SELECT query against mutated DB
            result = execute_tap_query(db_path, marker.raw_query)
            if not result.success:
                print(
                    f"Error [{fm.filepath}:{marker.line_number}]: {result.error}",
                    file=sys.stderr,
                )
                continue

            new_table_str = format_markdown_table(
                result.columns, result.rows, compaction=compaction
            )
            new_table_lines = new_table_str.split("\n")

            table_start_idx = table.start_line - 1
            table_end_idx = table.end_line - 1
            replacements.append((table_start_idx, table_end_idx, new_table_lines))

        if replacements:
            file_replacements[fm.filepath] = (fm, replacements)

    # Write all modified files
    for filepath, (fm, replacements) in file_replacements.items():
        replacements.sort(key=lambda r: r[0], reverse=True)
        lines = list(fm.lines)
        for start_idx, end_idx, new_lines in replacements:
            lines[start_idx:end_idx + 1] = new_lines

        new_content = "\n".join(lines)
        if fm.content.endswith("\n"):
            new_content += "\n"
        atomic_write(filepath, new_content)

    return 0


# ---------------------------------------------------------------------------
# Status subcommand (050-status-diff-output)
# ---------------------------------------------------------------------------

def _run_status(filepaths, include_paths=None):
    """Execute the status subcommand: read-only marker inventory."""
    with batch_lock(filepaths):
        return _run_status_locked(filepaths, include_paths)


def _run_status_locked(filepaths, include_paths=None):
    """Execute status with all filepaths already locked."""
    files_inspected = 0
    total_markers = 0
    problems = 0

    all_fm = []
    for filepath in filepaths:
        fm = _collect_file_markers(filepath, include_taps=True, include_feeds=True)
        files_inspected += 1
        if fm is None:
            # File read error -> FAIL
            print(
                f"FAIL - Could not read file [{filepath}]"
            )
            problems += 1
            continue
        all_fm.append(fm)

    for fm in all_fm:
        for marker in fm.feed_markers:
            total_markers += 1

            if marker.table_name is None:
                print(
                    f"FAIL {_scope_prefix(marker.scope)}🌀 (unknown) - Could not parse table name from query "
                    f"[{fm.filepath}:{marker.line_number}]"
                )
                print(
                    f"Error [{fm.filepath}:{marker.line_number}]: "
                    f"Could not parse table name from query",
                    file=sys.stderr,
                )
                problems += 1
                continue

            table, table_line_idx = find_adjacent_table(
                fm.lines, marker.line_number, marker.end_line_number
            )
            if table is None:
                print(
                    f"FAIL {_scope_prefix(marker.scope)}🌀 {marker.table_name} - No markdown table found after marker "
                    f"[{fm.filepath}:{marker.line_number}]"
                )
                print(
                    f"Error [{fm.filepath}:{marker.line_number}]: "
                    f"No markdown table found after marker",
                    file=sys.stderr,
                )
                problems += 1
                continue

            col_names, col_types, was_annotated, type_warnings, type_errors = \
                parse_header_types_with_annotation_flags(table.columns)

            for warn in type_warnings:
                print(
                    f"WARN {_scope_prefix(marker.scope)}🌀 {marker.table_name} - {warn} "
                    f"[{fm.filepath}:{marker.line_number}]"
                )
            # In status mode, type errors are WARN (informational, not blocking)
            for err in type_errors:
                print(
                    f"WARN {_scope_prefix(marker.scope)}🌀 {marker.table_name} - {err} "
                    f"[{fm.filepath}:{marker.line_number}]"
                )

            col_count = len(col_names)
            row_count = len(table.rows)
            col_descriptors = []
            for i, name in enumerate(col_names):
                if was_annotated[i]:
                    col_descriptors.append(f"{name}:{col_types[i]}")
                else:
                    col_descriptors.append(name)
            col_detail = ', '.join(col_descriptors)
            print(
                f"OK   {_scope_prefix(marker.scope)}🌀 {marker.table_name} "
                f"{{cols: {col_detail} | rows: {row_count}}} "
                f"[{fm.filepath}:{marker.line_number}]"
            )

        for marker in fm.tap_markers:
            total_markers += 1
            table, table_line_idx = find_adjacent_table(
                fm.lines, marker.line_number, marker.end_line_number
            )
            if table is not None:
                col_count = len(table.columns)
                row_count = len(table.rows)
                col_detail = ', '.join(c.strip() for c in table.columns)
                print(
                    f"OK   {_scope_prefix(marker.scope)}💎 {marker.raw_query} "
                    f"{{cols: {col_detail} | rows: {row_count}}} "
                    f"[{fm.filepath}:{marker.line_number}]"
                )
            else:
                print(
                    f"OK   {_scope_prefix(marker.scope)}💎 {marker.raw_query} "
                    f"(no table) "
                    f"[{fm.filepath}:{marker.line_number}]"
                )

    # Conflict detection
    conflicts = _detect_feed_conflicts(all_fm, include_paths)
    for conflict in conflicts:
        parts = [f"{fp}:{ln}" for fp, ln in conflict.conflicting]
        locations = " and ".join(parts)
        print(
            f"CONFLICT {_scope_prefix(conflict.scope)}💾 {conflict.table_name} - "
            f"conflicting writes from {locations}"
        )
        problems += 1

    _print_status_summary(files_inspected, total_markers, problems)

    if problems > 0:
        return 1
    return 0


# ---------------------------------------------------------------------------
# ASCII art banner (009-ascii-art-help)
# ---------------------------------------------------------------------------

MDB_ASCII_ART = r"""
▒▒██▓▓█▒▙                _ _
▒▒██▓▓█▒▒  _ __ ___   __| | |__
▒▒▒▒▒▒▒▒▒ | '_ ` _ \ / _` | '_ \
▒███████▒ | | | | | | (_| | |_) |
▒▓▓▓▓▓▓▓▒ |_| |_| |_|\__,_|_.__/
""".strip()


# ---------------------------------------------------------------------------
# .mdbrc config helpers (051-mdbrc-config)
# ---------------------------------------------------------------------------

def _apply_config(args, config) -> None:
    """Apply .mdbrc config values where CLI flags were not explicitly set."""
    if args.subcommand in ("push", "pull", "status"):
        if args.include is None and config.include is not None:
            args.include = config.include

    if args.subcommand == "push":
        if args.compaction is None:
            args.compaction = config.compaction
        if not args.verbose and config.verbose:
            args.verbose = True


def _apply_defaults(args) -> None:
    """Apply built-in defaults for any values still unset after config merge."""
    if args.subcommand == "push":
        if getattr(args, 'compaction', None) is None:
            args.compaction = "full"


# ---------------------------------------------------------------------------
# Main entry point (T001)
# ---------------------------------------------------------------------------

def main(argv=None):
    """Entry point for the unified mdb CLI tool."""
    parser = argparse.ArgumentParser(
        prog="mdb",
        description="Push and pull markdown tables with SQLite databases.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""\
examples:
  mdb push                            pull 🌀, then push 💎
  mdb push -i "docs/**"              restrict to docs/ (recursive)
  mdb push -i "docs/*"               restrict to docs/ (shallow)
  mdb pull "SELECT * FROM t"          query markdown data (CSV output)
  mdb pull -i "docs/**" "SELECT ..."  restrict discovery to docs/
  mdb push "INSERT INTO t ..."        mutate + push back
  mdb push "scope 🌀 DELETE ..."      scoped mutate + push back
  mdb pull "scope 💎 SELECT ..."      scoped query
""",
    )

    subparsers = parser.add_subparsers(dest="subcommand")

    # push subcommand
    push_parser = subparsers.add_parser(
        "push",
        help="Process all markers: feed (🌀) first, then tap (💎). Optionally run a mutative query.",
    )
    push_parser.add_argument(
        "-i", "--include",
        type=str,
        default=None,
        help="Space-separated glob patterns to restrict file discovery (default: **/*.md)",
    )
    push_parser.add_argument(
        "-c", "--compaction",
        choices=["full", "fit"],
        default=None,
        help="Table compaction mode: full (no padding, default) or fit (aligned columns)",
    )
    push_parser.add_argument(
        "-v", "--verbose",
        action="store_true",
        default=False,
        help="Show detailed output including skipped tables",
    )
    push_parser.add_argument(
        "query",
        nargs="?",
        default=None,
        help='Optional: DML query or "<scope_name> 🌀 <dml_query>"',
    )

    # pull subcommand (027-pull-query: query-based interface)
    pull_parser = subparsers.add_parser(
        "pull",
        help="Query markdown table data via SQL",
    )
    pull_parser.add_argument(
        "-i", "--include",
        type=str,
        default=None,
        help="Space-separated glob patterns to restrict file discovery (default: **/*.md)",
    )
    pull_parser.add_argument(
        "query",
        help='SQL query or "<scope_name> 💎 <sql_query>"',
    )

    # status subcommand (050-status-diff-output)
    status_parser = subparsers.add_parser(
        "status",
        help="Read-only marker inventory: list all markers with metadata and detect problems.",
    )
    status_parser.add_argument(
        "-i", "--include",
        type=str,
        default=None,
        help="Space-separated glob patterns to restrict file discovery (default: **/*.md)",
    )

    # init subcommand (014-init-command, 045-init-skill-path)
    init_parser = subparsers.add_parser(
        "init",
        help="Install the mdb skill into the current project",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""\
examples:
  mdb init                       write to .mdb/skills/mdb/SKILL.md (default)
  mdb init .claude/skills        write to .claude/skills/mdb/SKILL.md
  mdb init path/to/skills        write to path/to/skills/mdb/SKILL.md
  mdb init --force               overwrite without prompting
""",
    )
    init_parser.add_argument(
        "dir",
        nargs="?",
        default=".mdb/skills",
        metavar="DIR",
        help="Parent directory for the skill file (default: .mdb/skills). "
             "The tool writes to DIR/mdb/SKILL.md.",
    )
    init_parser.add_argument(
        "--force",
        action="store_true",
        help="Overwrite existing skill file without prompting",
    )

    args = parser.parse_args(argv)

    if args.subcommand is None:
        parser.print_help()
        return 2

    # Init subcommand: dispatch BEFORE resolve_paths() since init
    # does not use path resolution (014-init-command)
    if args.subcommand == "init":
        print(MDB_ASCII_ART)
        print()
        from mdb.init import init_skill
        from mdb.config import generate_mdbrc
        result = init_skill(target_dir=args.dir, force=args.force)
        generate_mdbrc()
        return 0 if result.success else 1

    # Load .mdbrc for non-exempt subcommands (051-mdbrc-config)
    from mdb.config import load_config
    config = load_config()
    if config is not None:
        _apply_config(args, config)
    _apply_defaults(args)

    # Status subcommand (050-status-diff-output)
    if args.subcommand == "status":
        filepaths = _discover_files(args.include)
        if not filepaths:
            _print_status_summary(0, 0, 0)
            return 0
        normalized_include = _normalize_include_for_hash(args.include)
        return _run_status(filepaths, include_paths=normalized_include)

    # Pull subcommand: dispatch BEFORE resolve_paths() since pull
    # uses its own discovery logic (027-pull-query)
    if args.subcommand == "pull":
        if not args.query.strip():
            print("Error: Query argument is empty", file=sys.stderr)
            return 1
        return _run_pull_with_tap_query(args.query, args.include, os.getcwd())

    # Push subcommand: uses its own discovery logic (028-push-query)
    if args.subcommand == "push":
        # Empty query validation (FR-011)
        if args.query is not None and args.query.strip() == "":
            print("Error: Query argument is empty", file=sys.stderr)
            return 1

        if args.query is not None:
            # Push-query mode: parse scope, validate DML, run pipeline
            scope_name, sql_query = parse_pre_push_feed_query(args.query)
            dml_error = validate_dml(sql_query)
            if dml_error:
                print(f"Error: {dml_error}", file=sys.stderr)
                return 1
            return _run_push_with_feed_query(scope_name, sql_query, args.include, args.compaction, os.getcwd(), verbose=args.verbose)
        else:
            # Standard push: discover files, run pull-then-push
            filepaths = _discover_files(args.include)

            if not filepaths:
                print("No markdown files found")
                return 0

            normalized_include = _normalize_include_for_hash(args.include)
            return _run_push(filepaths, compaction=args.compaction, verbose=args.verbose, include_paths=normalized_include)

    return 2


if __name__ == "__main__":
    sys.exit(main())
