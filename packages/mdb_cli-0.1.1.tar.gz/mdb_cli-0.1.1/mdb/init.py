"""Initialize the mdb skill in the current project.

Copies the bundled SKILL.md file into <dir>/mdb/SKILL.md relative
to the current working directory, where <dir> defaults to .mdb/skills.
"""

import importlib.resources
import os
import sys
from dataclasses import dataclass


@dataclass
class InitResult:
    """Outcome of an init operation."""
    success: bool
    target_path: str
    action: str  # "created", "updated", "up_to_date", "skipped", "error"
    error: str | None = None


# ---------------------------------------------------------------------------
# Helper functions (T004, T005)
# ---------------------------------------------------------------------------

def _load_bundled_skill() -> str | None:
    """Load the bundled SKILL.md content from the package data directory.

    Returns the content as a string, or None if the file cannot be loaded.
    """
    try:
        return (
            importlib.resources.files("mdb.data")
            .joinpath("SKILL.md")
            .read_text(encoding="utf-8")
        )
    except Exception:
        return None


def _prompt_overwrite(rel_path: str) -> bool:
    """Prompt the user for confirmation to overwrite an existing file.

    Returns True if the user confirms (y/yes, case-insensitive),
    False otherwise (including empty input, n, or EOFError).
    """
    print(
        f"{rel_path} already exists and differs "
        "from the bundled version."
    )
    try:
        response = input("Overwrite? [y/N]: ")
    except EOFError:
        return False
    return response.strip().lower() in ("y", "yes")


# ---------------------------------------------------------------------------
# Main orchestration (T006)
# ---------------------------------------------------------------------------

def init_skill(target_dir: str = ".mdb/skills", force: bool = False) -> InitResult:
    """Install the bundled mdb skill file into the current project.

    Args:
        target_dir: Parent directory for the skill file. The tool always
            appends mdb/SKILL.md to this directory.
        force: If True, overwrite existing file without prompting.

    Returns:
        InitResult with success status and action taken.
    """
    # Step 1: Load bundled skill file
    bundled_content = _load_bundled_skill()
    if bundled_content is None:
        error = ("Could not load bundled skill file: "
                 "package installation may be corrupted")
        print(f"Error: {error}", file=sys.stderr)
        return InitResult(success=False, target_path="", action="error",
                          error=error)

    # Step 2: Determine target path
    target_path = os.path.join(
        os.getcwd(), target_dir, "mdb", "SKILL.md"
    )
    display_path = os.path.join(target_dir, "mdb", "SKILL.md")
    target_parent = os.path.dirname(target_path)

    # Step 3: Check existing file
    if os.path.exists(target_path):
        if not os.path.isfile(target_path):
            error = f"{display_path} exists but is not a file"
            print(f"Error: {error}", file=sys.stderr)
            return InitResult(success=False, target_path=target_path,
                              action="error", error=error)

        try:
            with open(target_path, "r", encoding="utf-8") as f:
                existing_content = f.read()
        except OSError as e:
            error = f"Cannot read {display_path}: {e}"
            print(f"Error: {error}", file=sys.stderr)
            return InitResult(success=False, target_path=target_path,
                              action="error", error=error)

        if existing_content == bundled_content:
            print(f"mdb skill is already up to date at "
                  f"{display_path}")
            return InitResult(success=True, target_path=target_path,
                              action="up_to_date")

        # Content differs
        if not force:
            if not _prompt_overwrite(display_path):
                print("Skipped (no changes made)")
                return InitResult(success=True, target_path=target_path,
                                  action="skipped")

        is_update = True
    else:
        is_update = False

    # Step 4: Create directory structure
    try:
        os.makedirs(target_parent, exist_ok=True)
    except OSError as e:
        error = f"Cannot create directory {os.path.dirname(display_path)}/: {e}"
        print(f"Error: {error}", file=sys.stderr)
        return InitResult(success=False, target_path=target_path,
                          action="error", error=error)

    # Step 5: Write skill file
    try:
        with open(target_path, "w", encoding="utf-8") as f:
            f.write(bundled_content)
    except OSError as e:
        error = f"Cannot write to {display_path}: {e}"
        print(f"Error: {error}", file=sys.stderr)
        return InitResult(success=False, target_path=target_path,
                          action="error", error=error)

    # Step 6: Print status and return
    if is_update:
        print(f"Updated mdb skill at {display_path}")
        return InitResult(success=True, target_path=target_path,
                          action="updated")
    else:
        print(f"Installed mdb skill to {display_path}")
        return InitResult(success=True, target_path=target_path,
                          action="created")
