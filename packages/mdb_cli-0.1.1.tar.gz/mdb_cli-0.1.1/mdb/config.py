"""Configuration file (.mdbrc) support for mdb.

Handles JSONC parsing, config loading/validation, and template generation
for the .mdbrc project-level configuration file.
"""

import json
import os
import sys
from dataclasses import dataclass


@dataclass
class MdbConfig:
    """Parsed .mdbrc configuration."""
    include: str | None = None
    compaction: str = "full"
    verbose: bool = False


MDBRC_TEMPLATE = """\
{
    // \u2699\ufe0f uncomment below to change defaults

    // "include": "**/*.md", // (string|null)
    // "compaction": "full", // ("full"|"fit")
    // "verbose": false, // (bool, default false)
}
"""

_RECOGNIZED_KEYS = {"include", "compaction", "verbose"}


def strip_jsonc_comments(text: str) -> str:
    """Remove // line comments from JSONC text, preserving // inside strings.

    Also strips trailing commas before } and ] to handle JSONC trailing comma
    syntax that json.loads() rejects.

    Uses a character-by-character state machine to correctly handle string
    literals containing // sequences.
    """
    result = []
    i = 0
    in_string = False
    length = len(text)

    while i < length:
        ch = text[i]

        if in_string:
            result.append(ch)
            if ch == '\\' and i + 1 < length:
                # Escaped character inside string -- consume next char too
                i += 1
                result.append(text[i])
            elif ch == '"':
                in_string = False
            i += 1
            continue

        # Outside string
        if ch == '"':
            in_string = True
            result.append(ch)
            i += 1
            continue

        if ch == '/' and i + 1 < length and text[i + 1] == '/':
            # Line comment -- skip to end of line
            while i < length and text[i] != '\n':
                i += 1
            continue

        result.append(ch)
        i += 1

    stripped = ''.join(result)

    # Remove trailing commas before } and ]
    # Match: comma, optional whitespace/newlines, then } or ]
    import re
    stripped = re.sub(r',(\s*[}\]])', r'\1', stripped)

    return stripped


def load_config(cwd: str | None = None) -> 'MdbConfig | None':
    """Load and validate .mdbrc from the given directory.

    Args:
        cwd: Directory to search for .mdbrc. Defaults to os.getcwd().

    Returns:
        MdbConfig with parsed values, or None if no .mdbrc exists.
        Calls sys.exit(1) on hard errors (invalid JSON, bad values, etc.).
    """
    config_dir = cwd or os.getcwd()
    config_path = os.path.join(config_dir, ".mdbrc")

    if not os.path.exists(config_path):
        return None

    # FR-016: Must be a regular file
    if not os.path.isfile(config_path):
        print("Error: .mdbrc is not a regular file", file=sys.stderr)
        sys.exit(1)

    # FR-017: Must be valid UTF-8
    try:
        with open(config_path, "r", encoding="utf-8") as f:
            raw = f.read()
    except UnicodeDecodeError:
        print("Error: .mdbrc contains non-UTF-8 content", file=sys.stderr)
        sys.exit(1)
    except OSError as e:
        print(f"Error: Cannot read .mdbrc: {e}", file=sys.stderr)
        sys.exit(1)

    # FR-007: Announce config discovery
    print("Using .mdbrc", file=sys.stderr)

    # Strip JSONC comments
    stripped = strip_jsonc_comments(raw)

    # FR-015: Empty/comments-only treated as empty object
    if not stripped.strip():
        return MdbConfig()

    # FR-011: Parse JSON
    try:
        data = json.loads(stripped)
    except json.JSONDecodeError as e:
        print(f"Error: .mdbrc contains invalid JSON: {e}", file=sys.stderr)
        sys.exit(1)

    # CHK023: Root must be an object (dict)
    if not isinstance(data, dict):
        print("Error: .mdbrc root must be a JSON object", file=sys.stderr)
        sys.exit(1)

    # FR-012: Warn on unrecognized keys
    for key in data:
        if key not in _RECOGNIZED_KEYS:
            print(f"Warning: .mdbrc contains unrecognized key: {key}", file=sys.stderr)

    # FR-013: Validate recognized keys
    config = MdbConfig()

    if "include" in data:
        val = data["include"]
        if val is not None and not isinstance(val, str):
            print("Error: .mdbrc 'include' must be a string or null", file=sys.stderr)
            sys.exit(1)
        config.include = val

    if "compaction" in data:
        val = data["compaction"]
        if val not in ("full", "fit"):
            print(f"Error: .mdbrc 'compaction' must be \"full\" or \"fit\", got: {val!r}", file=sys.stderr)
            sys.exit(1)
        config.compaction = val

    if "verbose" in data:
        val = data["verbose"]
        if not isinstance(val, bool):
            print(f"Error: .mdbrc 'verbose' must be a boolean, got: {val!r}", file=sys.stderr)
            sys.exit(1)
        config.verbose = val

    return config


def generate_mdbrc(cwd: str | None = None) -> bool:
    """Generate .mdbrc template file in the given directory.

    Args:
        cwd: Directory to write .mdbrc into. Defaults to os.getcwd().

    Returns:
        True on success (created or preserved), False on error.
    """
    config_dir = cwd or os.getcwd()
    config_path = os.path.join(config_dir, ".mdbrc")

    # FR-003: Never overwrite existing
    if os.path.exists(config_path):
        print(".mdbrc already exists (preserved)")
        return True

    try:
        with open(config_path, "w", encoding="utf-8") as f:
            f.write(MDBRC_TEMPLATE)
        print("Created .mdbrc")
        return True
    except OSError as e:
        print(f"Error: Cannot write .mdbrc: {e}", file=sys.stderr)
        return False
