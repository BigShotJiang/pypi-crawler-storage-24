# Changelog

## [0.1.2] - 2026-03-07

### Fixed
- MCP tools no longer hang under load — blocking calls moved to thread pool (`asyncio.to_thread`)
- Transcript file now written in real-time (not lost if buffer is cleared mid-session)
- Transcript buffer is now per-session (cleared on each `start_listening`)

## [0.1.1] - 2026-03-07

### Changed
- Whisper debug data now always written to `debug.log` in session directory (no longer pollutes transcript buffer)
- Removed `WHISPER_DEBUG` environment variable (debug logging is always on for local backend)

## [0.1.0] - 2026-03-06

### Added
- Dual audio capture: mic + system audio (WASAPI loopback)
- Deepgram nova-3 cloud STT backend with WebSocket streaming
- Local faster-whisper STT backend with GPU/CUDA support
- Runtime backend switching via MCP tool
- Stereo opus recording (L=mic, R=system audio) per session
- Per-session directories with transcript.txt and audio.opus
- Chunk overlap with text deduplication for whisper
- Whisper hallucination filter (no_speech_prob + avg_logprob)
- Stateful high-quality resampling via soxr
- Auto-reconnect for Deepgram WebSocket
- GPU model unload/reload on stop/start
- Configurable via environment variables
- PyPI package with `audio-transcript-mcp` CLI entry point
