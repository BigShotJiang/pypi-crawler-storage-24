"""Allow running as `python -m audio_transcript_mcp`."""

from audio_transcript_mcp.server import main

main()
