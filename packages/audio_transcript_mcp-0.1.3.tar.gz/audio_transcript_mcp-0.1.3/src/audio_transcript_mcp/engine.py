"""Audio capture engine and transcript buffer."""

import os
import pathlib
import queue
import threading
import time
from dataclasses import dataclass

import numpy as np
import soxr

from audio_transcript_mcp.backends import create_backend

try:
    from audio_transcript_mcp.recorder import StereoOpusRecorder
except ImportError:
    StereoOpusRecorder = None

# ── config ──────────────────────────────────────────────────────────

stt_backend = os.environ.get("STT_BACKEND", "deepgram").lower()

CONFIG = {
    "deepgram_api_key": os.environ.get("DEEPGRAM_API_KEY", ""),
    "deepgram_language": os.environ.get("DEEPGRAM_LANGUAGE", "ru"),
    "deepgram_model": os.environ.get("DEEPGRAM_MODEL", "nova-3"),
    "deepgram_utterance_end_ms": os.environ.get("DEEPGRAM_UTTERANCE_END_MS", "2500"),
    "deepgram_endpointing": os.environ.get("DEEPGRAM_ENDPOINTING", "500"),
    "whisper_model": os.environ.get("WHISPER_MODEL", "large-v3"),
    "whisper_device": os.environ.get("WHISPER_DEVICE", "cuda"),
    "whisper_language": os.environ.get("WHISPER_LANGUAGE", ""),
    "whisper_chunk_sec": float(os.environ.get("WHISPER_CHUNK_SEC", "5")),
    "whisper_overlap_sec": float(os.environ.get("WHISPER_OVERLAP_SEC", "2")),
}

BUFFER_MAX_AGE = int(os.environ.get("TRANSCRIPT_MAX_AGE", "3600"))
TRANSCRIPT_DIR = pathlib.Path(os.environ.get("TRANSCRIPT_DIR", pathlib.Path.home() / ".audio-transcript-mcp" / "transcripts"))
RECONNECT_DELAY = 3


# ── transcript buffer ───────────────────────────────────────────────

@dataclass
class Entry:
    ts: float
    speaker: str
    text: str


class Buffer:
    def __init__(self, max_age: int = 3600):
        self._entries: list[Entry] = []
        self._lock = threading.Lock()
        self._max_age = max_age
        self._transcript_file = None

    def set_transcript_file(self, path):
        """Write entries to file in real-time (append mode)."""
        with self._lock:
            if self._transcript_file:
                self._transcript_file.close()
            self._transcript_file = open(str(path), "a", encoding="utf-8") if path else None

    def close_transcript_file(self):
        with self._lock:
            if self._transcript_file:
                self._transcript_file.close()
                self._transcript_file = None

    def add(self, speaker: str, text: str):
        with self._lock:
            entry = Entry(time.time(), speaker, text)
            self._entries.append(entry)
            cutoff = time.time() - self._max_age
            self._entries = [e for e in self._entries if e.ts > cutoff]
            if self._transcript_file:
                t = time.strftime("%H:%M:%S", time.localtime(entry.ts))
                self._transcript_file.write(f"[{t}] {speaker} — {text}\n\n")
                self._transcript_file.flush()

    def since(self, ts: float) -> list[Entry]:
        with self._lock:
            return [e for e in self._entries if e.ts >= ts]

    def last(self, seconds: float) -> list[Entry]:
        return self.since(time.time() - seconds)

    def all(self) -> list[Entry]:
        with self._lock:
            return list(self._entries)

    def clear(self):
        with self._lock:
            self._entries.clear()

    @staticmethod
    def format(entries: list[Entry]) -> str:
        if not entries:
            return "(empty transcript)"
        lines = []
        for e in entries:
            t = time.strftime("%H:%M:%S", time.localtime(e.ts))
            lines.append(f"[{t}] {e.speaker}: {e.text}")
        return "\n".join(lines)


buf = Buffer(BUFFER_MAX_AGE)


# ── audio engine ────────────────────────────────────────────────────

class AudioEngine:
    """Captures mic + loopback via PyAudioWPatch callbacks,
    sends to chosen STT backend. Auto-reconnects on drop."""

    def __init__(self):
        self._running = False
        self._stop = threading.Event()
        self._threads: list[threading.Thread] = []
        self._streams = []
        self._pa = None
        self._session_start: float = 0.0
        self._session_dir: pathlib.Path | None = None
        self._recorder = None

    @property
    def running(self) -> bool:
        return self._running

    def start(self) -> str:
        if self._running:
            return "Already listening."

        try:
            import ctypes
            ctypes.windll.ole32.CoInitializeEx(0, 0)
        except Exception:
            pass

        try:
            import pyaudiowpatch as pyaudio
        except ImportError:
            return "ERROR: PyAudioWPatch not installed."

        self._stop.clear()
        self._running = True
        self._session_start = time.time()
        buf.clear()
        self._pa = pyaudio.PyAudio()

        # Create per-session directory and open stereo opus recorder
        self._recorder = None
        self._session_dir = None
        if TRANSCRIPT_DIR:
            try:
                ts = time.strftime("%Y-%m-%d_%H-%M-%S", time.localtime(self._session_start))
                self._session_dir = TRANSCRIPT_DIR / ts
                self._session_dir.mkdir(parents=True, exist_ok=True)
                if StereoOpusRecorder is not None:
                    self._recorder = StereoOpusRecorder(self._session_dir / "audio.opus")
                buf.set_transcript_file(self._session_dir / "transcript.txt")
            except Exception:
                pass

        for label, use_loopback in [("me", False), ("others", True)]:
            t = threading.Thread(
                target=self._worker,
                args=(label, use_loopback),
                daemon=True,
                name=f"{label}-worker",
            )
            self._threads.append(t)
            t.start()

        backend_name = "local (faster-whisper)" if stt_backend == "local" else "Deepgram"
        return f"Listening started (mic + system audio) via {backend_name}."

    def stop(self) -> str:
        if not self._running:
            return "Not listening."
        self._stop.set()
        for s in self._streams:
            try:
                s.stop_stream()
                s.close()
            except Exception:
                pass
        self._streams.clear()
        for t in self._threads:
            t.join(timeout=10)
        self._threads.clear()
        if self._pa:
            try:
                self._pa.terminate()
            except Exception:
                pass
            self._pa = None
        self._running = False
        return "Listening stopped."

    def _worker(self, label: str, use_loopback: bool):
        import pyaudiowpatch as pyaudio

        p = self._pa

        try:
            if use_loopback:
                device = p.get_default_wasapi_loopback()
            else:
                device = p.get_default_input_device_info()
        except Exception as exc:
            buf.add("system", f"[ERROR: device not found: {exc}]")
            return

        sample_rate = int(device["defaultSampleRate"])
        channels = max(1, int(device["maxInputChannels"]))
        pa_format = pyaudio.paFloat32 if use_loopback else pyaudio.paInt16
        chunk_frames = sample_rate // 10  # 100ms

        audio_q: queue.Queue[bytes | None] = queue.Queue(maxsize=100)

        def audio_callback(in_data, frame_count, time_info, status):
            if self._stop.is_set():
                return (None, pyaudio.paComplete)
            try:
                audio_q.put_nowait(in_data)
            except queue.Full:
                pass
            return (None, pyaudio.paContinue)

        try:
            stream = p.open(
                format=pa_format,
                channels=channels,
                rate=sample_rate,
                input=True,
                input_device_index=device["index"],
                frames_per_buffer=chunk_frames,
                stream_callback=audio_callback,
            )
            stream.start_stream()
            self._streams.append(stream)
        except Exception as exc:
            buf.add("system", f"[ERROR: audio open failed: {exc}]")
            return

        buf.add("system", f"[STARTED: {device['name']}, {sample_rate}Hz, {channels}ch]")

        is_float32 = pa_format == pyaudio.paFloat32

        # Stateful resampler for opus recording (avoids boundary artifacts)
        opus_resampler = None
        if self._recorder and sample_rate != 48000:
            opus_resampler = soxr.ResampleStream(sample_rate, 48000, 1, dtype="float32", quality="HQ")

        while not self._stop.is_set():
            backend = create_backend(stt_backend, label, sample_rate, channels, is_float32, buf, CONFIG)
            if self._session_dir and hasattr(backend, 'set_debug_file'):
                backend.set_debug_file(self._session_dir / "debug.log")
            if not backend.connect():
                buf.add("system", f"[RECONNECT: backend connect failed, retry in {RECONNECT_DELAY}s]")
                self._stop.wait(RECONNECT_DELAY)
                continue

            # Drain stale audio
            while not audio_q.empty():
                try:
                    audio_q.get_nowait()
                except queue.Empty:
                    break

            disconnected = False
            while not self._stop.is_set():
                try:
                    data = audio_q.get(timeout=0.5)
                except queue.Empty:
                    continue
                if data is None:
                    break

                # Record to stereo opus
                if self._recorder:
                    try:
                        if is_float32:
                            arr = np.frombuffer(data, dtype=np.float32)
                            if channels >= 2:
                                arr = arr.reshape(-1, channels).mean(axis=1)
                        else:
                            arr = np.frombuffer(data, dtype=np.int16).astype(np.float32) / 32768.0
                            if channels >= 2:
                                arr = arr.reshape(-1, channels).mean(axis=1)
                        if opus_resampler is not None:
                            arr = opus_resampler.resample_chunk(arr)
                        mono_i16 = np.clip(arr * 32767, -32768, 32767).astype(np.int16)
                        self._recorder.write(label, mono_i16.tobytes())
                    except Exception:
                        pass

                if not backend.send(data):
                    disconnected = True
                    break

            backend.close()

            if disconnected and not self._stop.is_set():
                buf.add("system", f"[RECONNECT: connection lost, retry in {RECONNECT_DELAY}s...]")
                self._stop.wait(RECONNECT_DELAY)

            if stt_backend == "local" and not disconnected:
                break

        # Flush remaining resampler state into opus recorder
        if opus_resampler is not None and self._recorder:
            try:
                tail = opus_resampler.resample_chunk(np.empty(0, dtype=np.float32), last=True)
                if len(tail) > 0:
                    mono_i16 = np.clip(tail * 32767, -32768, 32767).astype(np.int16)
                    self._recorder.write(label, mono_i16.tobytes())
            except Exception:
                pass

        try:
            stream.stop_stream()
            stream.close()
        except Exception:
            pass
        buf.add("system", "[STOPPED]")
