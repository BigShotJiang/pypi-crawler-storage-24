#!/usr/bin/env python3
"""MCP server — thin wrapper over AudioEngine exposing tools."""

import asyncio
import gc

from mcp.server.fastmcp import FastMCP

from audio_transcript_mcp.backends.whisper import WhisperBackend
from audio_transcript_mcp.engine import CONFIG, AudioEngine, buf
import audio_transcript_mcp.engine as _engine

engine = AudioEngine()
mcp = FastMCP("audio-transcript")


@mcp.tool()
async def start_listening() -> str:
    """Start capturing mic + system audio and transcribing via current backend.
    Returns status message.
    """
    if _engine.stt_backend == "deepgram" and not CONFIG["deepgram_api_key"]:
        return "ERROR: Set DEEPGRAM_API_KEY env var first."
    return await asyncio.to_thread(engine.start)


@mcp.tool()
async def stop_listening() -> str:
    """Stop audio capture and transcription."""
    return await asyncio.to_thread(_stop_listening_sync)


def _stop_listening_sync() -> str:
    result = engine.stop()
    buf.close_transcript_file()
    with WhisperBackend._model_lock:
        if WhisperBackend._model is not None:
            WhisperBackend._model.model.unload_model()
    gc.collect()

    # Close stereo opus recorder
    if engine._recorder:
        try:
            engine._recorder.close()
            p = engine._recorder.path
            size_kb = p.stat().st_size / 1024
            result += f" Audio saved to {p} ({size_kb:.0f} KB)."
        except Exception as exc:
            result += f" (opus save failed: {exc})"
        engine._recorder = None

    return result


@mcp.tool()
async def is_listening() -> str:
    """Check if audio capture is currently active."""
    return f"Listening: {engine.running}"


@mcp.tool()
async def get_transcript(last_seconds: float = 60) -> str:
    """Get transcript for the last N seconds.

    Args:
        last_seconds: how far back in seconds (default 60)
    """
    return buf.format(buf.last(last_seconds))


@mcp.tool()
async def get_full_transcript() -> str:
    """Get the entire accumulated transcript (up to max buffer age)."""
    return buf.format(buf.all())


@mcp.tool()
async def get_transcript_since(timestamp: float) -> str:
    """Get transcript entries since a Unix timestamp.

    Args:
        timestamp: Unix epoch timestamp (e.g. from time.time())
    """
    return buf.format(buf.since(timestamp))


@mcp.tool()
async def clear_transcript() -> str:
    """Clear the transcript buffer."""
    buf.clear()
    return "Transcript cleared."


@mcp.tool()
async def get_backend() -> str:
    """Get current STT backend name ("deepgram" or "local")."""
    return f"Current backend: {_engine.stt_backend}"


@mcp.tool()
async def set_backend(backend: str) -> str:
    """Switch STT backend. If currently listening, restarts capture automatically.

    Args:
        backend: "deepgram" or "local"
    """
    backend = backend.strip().lower()
    if backend not in ("deepgram", "local"):
        return f"ERROR: unknown backend '{backend}'. Use 'deepgram' or 'local'."
    if backend == _engine.stt_backend:
        return f"Already using '{_engine.stt_backend}'."
    old = _engine.stt_backend
    _engine.stt_backend = backend
    if engine.running:
        await asyncio.to_thread(engine.stop)
        msg = await asyncio.to_thread(engine.start)
        return f"Switched {old} -> {_engine.stt_backend} and restarted. {msg}"
    return f"Switched {old} -> {_engine.stt_backend}. Start listening when ready."


# ── entrypoint ──────────────────────────────────────────────────────


def main():
    mcp.run()


if __name__ == "__main__":
    main()
