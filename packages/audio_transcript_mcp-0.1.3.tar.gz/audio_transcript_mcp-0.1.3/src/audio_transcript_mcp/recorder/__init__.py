"""Audio recorder module."""

try:
    from audio_transcript_mcp.recorder.opus import StereoOpusRecorder
except ImportError:
    StereoOpusRecorder = None

__all__ = ["StereoOpusRecorder"]
