"""Real-time audio transcription MCP server."""

__version__ = "0.1.3"
