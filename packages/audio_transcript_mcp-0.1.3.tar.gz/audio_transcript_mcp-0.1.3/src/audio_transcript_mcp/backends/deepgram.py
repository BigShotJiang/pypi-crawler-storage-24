"""Deepgram WebSocket STT backend."""

import json
import threading

from audio_transcript_mcp.audio_utils import float32_to_int16


class DeepgramBackend:
    """Streams audio to Deepgram via WebSocket. One instance per audio source."""

    def __init__(self, label, sample_rate, channels, is_float32, buf, config):
        self.label = label
        self.sample_rate = sample_rate
        self.channels = channels
        self._is_float32 = is_float32
        self._buf = buf
        self._language = config.get("deepgram_language", "ru")
        self._api_key = config.get("deepgram_api_key", "")
        self._model = config.get("deepgram_model", "nova-3")
        self._utterance_end_ms = config.get("deepgram_utterance_end_ms", "2500")
        self._endpointing = config.get("deepgram_endpointing", "500")
        self._ws = None
        self._recv_thread = None
        self._recv_stop = threading.Event()

    def connect(self):
        from websockets.sync.client import connect as ws_connect
        url = (
            f"wss://api.deepgram.com/v1/listen"
            f"?encoding=linear16"
            f"&sample_rate={self.sample_rate}"
            f"&channels={self.channels}"
            f"&language={self._language}"
            f"&model={self._model}"
            f"&punctuate=true"
            f"&smart_format=true"
            f"&interim_results=true"
            f"&utterance_end_ms={self._utterance_end_ms}"
            f"&endpointing={self._endpointing}"
        )
        headers = {"Authorization": f"Token {self._api_key}"}
        try:
            self._ws = ws_connect(url, additional_headers=headers)
        except Exception:
            return False

        self._recv_stop.clear()
        self._recv_thread = threading.Thread(target=self._receiver, daemon=True)
        self._recv_thread.start()
        return True

    def send(self, data):
        """Send audio chunk. Converts float32 to int16 if needed."""
        if self._is_float32:
            data = float32_to_int16(data)
        try:
            self._ws.send(data)
            return True
        except Exception:
            return False

    def close(self):
        self._recv_stop.set()
        try:
            self._ws.send(json.dumps({"type": "CloseStream"}))
            self._ws.close()
        except Exception:
            pass
        if self._recv_thread:
            self._recv_thread.join(timeout=2)

    def _receiver(self):
        while not self._recv_stop.is_set():
            try:
                raw = self._ws.recv(timeout=1.0)
            except TimeoutError:
                continue
            except Exception:
                break
            if not isinstance(raw, str):
                continue
            try:
                msg = json.loads(raw)
            except json.JSONDecodeError:
                continue
            ch = msg.get("channel", {})
            alt = ch.get("alternatives", [{}])[0]
            text = alt.get("transcript", "").strip()
            if text and msg.get("is_final"):
                self._buf.add(self.label, text)
