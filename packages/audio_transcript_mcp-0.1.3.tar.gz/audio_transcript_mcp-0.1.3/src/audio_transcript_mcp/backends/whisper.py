"""Local faster-whisper STT backend."""

import threading
import time

import numpy as np

from audio_transcript_mcp.audio_utils import stereo_to_mono_f32

try:
    from faster_whisper import WhisperModel
except ImportError:
    WhisperModel = None

try:
    import soxr
except ImportError:
    soxr = None


class WhisperBackend:
    """Accumulates audio chunks and transcribes locally with faster-whisper."""

    _model = None
    _model_lock = threading.Lock()

    def __init__(self, label, sample_rate, channels, is_float32, buf, config):
        self.label = label
        self.sample_rate = sample_rate
        self.channels = channels
        self._is_float32 = is_float32
        self._buf = buf
        self._model_name = config.get("whisper_model", "large-v3")
        self._device = config.get("whisper_device", "cuda")
        self._language = config.get("whisper_language", "")
        self._chunk_sec = config.get("whisper_chunk_sec", 5.0)
        self._overlap_sec = config.get("whisper_overlap_sec", 2.0)
        self._pcm_buf = bytearray()
        # mono float32 = 4 bytes/sample
        self._chunk_bytes = int(self._chunk_sec * sample_rate * 4)
        self._overlap_bytes = int(self._overlap_sec * sample_rate * 4)
        self._step_bytes = self._chunk_bytes - self._overlap_bytes
        self._prev_words: list[str] = []
        self._debug_file = None

    def set_debug_file(self, path):
        """Set path for debug log file. Called by engine after backend creation."""
        if path:
            self._debug_file = open(str(path), "a", encoding="utf-8")

    def _debug(self, msg: str):
        """Write timestamped debug line to file."""
        if self._debug_file:
            t = time.strftime("%H:%M:%S")
            self._debug_file.write(f"[{t}] {self.label}: {msg}\n")
            self._debug_file.flush()

    @classmethod
    def _ensure_model(cls, buf, model_name, device):
        with cls._model_lock:
            if cls._model is not None and cls._model.model.model_is_loaded:
                return
            if cls._model is not None:
                buf.add("system", f"[Reloading whisper model to {device}...]")
                cls._model.model.load_model()
                buf.add("system", "[Whisper model reloaded]")
            else:
                buf.add("system", f"[Loading whisper model '{model_name}' on {device}...]")
                cls._model = WhisperModel(
                    model_name,
                    device=device,
                    compute_type="float16" if device == "cuda" else "int8",
                )
                buf.add("system", "[Whisper model loaded]")

    def connect(self):
        try:
            self._ensure_model(self._buf, self._model_name, self._device)
            return True
        except Exception as exc:
            self._buf.add(self.label, f"[ERROR: whisper load failed: {exc}]")
            return False

    def send(self, data):
        """Accumulate audio. Converts to mono float32 internally."""
        if self._is_float32:
            if self.channels >= 2:
                data = stereo_to_mono_f32(data, self.channels)
        else:
            arr = np.frombuffer(data, dtype=np.int16).astype(np.float32) / 32768.0
            if self.channels >= 2:
                arr = arr.reshape(-1, self.channels).mean(axis=1)
            data = arr.tobytes()
        self._pcm_buf.extend(data)

        if len(self._pcm_buf) >= self._chunk_bytes:
            chunk = bytes(self._pcm_buf[:self._chunk_bytes])
            self._pcm_buf = self._pcm_buf[self._step_bytes:]
            try:
                self._transcribe(chunk)
            except Exception as exc:
                self._buf.add(self.label, f"[TRANSCRIBE ERROR: {exc}]")
        return True

    def close(self):
        if len(self._pcm_buf) > self.sample_rate:
            self._transcribe(bytes(self._pcm_buf), is_tail=True)
        self._pcm_buf.clear()
        if self._debug_file:
            self._debug_file.close()
            self._debug_file = None

    def _transcribe(self, mono_f32, is_tail=False):
        audio = np.frombuffer(mono_f32, dtype=np.float32)
        duration_sec = len(audio) / self.sample_rate

        if self.sample_rate != 16000:
            audio = soxr.resample(audio, self.sample_rate, 16000, quality="HQ").astype(np.float32)

        peak = float(np.max(np.abs(audio)))
        rms = float(np.sqrt(np.mean(audio ** 2)))

        self._debug(f"chunk {duration_sec:.1f}s | peak={peak:.4f} rms={rms:.4f}")

        if peak < 0.01:
            self._debug("skipped: silence")
            return

        lang = self._language or None
        t0 = time.monotonic()
        segments, info = self._model.transcribe(
            audio,
            language=lang,
            beam_size=3,
            vad_filter=True,
            vad_parameters=dict(min_silence_duration_ms=500),
            condition_on_previous_text=False,
        )

        step_sec = self._chunk_sec - self._overlap_sec
        all_segs = []
        texts = []
        for seg in segments:
            all_segs.append(seg)
            if not is_tail and self._overlap_sec > 0 and seg.start >= step_sec:
                break
            word_count = len(seg.text.strip().split())
            nsp_threshold = 0.7 if word_count <= 3 else 0.85
            if seg.no_speech_prob > nsp_threshold:
                self._debug(f"hallucination filtered: nsp={seg.no_speech_prob:.2f} thr={nsp_threshold} words={word_count} | {seg.text.strip()}")
                continue
            text = seg.text.strip()
            if text:
                texts.append(text)
        elapsed = time.monotonic() - t0

        seg_details = " | ".join(
            f"[{s.start:.1f}-{s.end:.1f} p={s.avg_logprob:.2f} nsp={s.no_speech_prob:.2f}] {s.text.strip()}"
            for s in all_segs
        )
        self._debug(f"whisper {elapsed:.2f}s | lang={info.language} prob={info.language_probability:.2f} | segs={len(all_segs)} kept={len(texts)} | {seg_details}")

        if not texts:
            return

        combined = " ".join(texts)
        words = combined.split()

        if self._prev_words and self._overlap_sec > 0:
            before = len(words)
            words = self._strip_overlap(self._prev_words, words)
            if before != len(words):
                self._debug(f"dedup: stripped {before - len(words)} words")

        self._prev_words = combined.split()
        if words:
            self._buf.add(self.label, " ".join(words))

    @staticmethod
    def _strip_overlap(prev, new):
        """Remove the longest prefix of `new` that matches a suffix of `prev`."""
        def norm(w):
            return w.strip(".,!?;:\"'()[]{}«»\u2014\u2013-").lower()

        max_check = min(len(prev), len(new), 12)
        best = 0
        for n in range(1, max_check + 1):
            if all(norm(a) == norm(b) for a, b in zip(prev[-n:], new[:n])):
                best = n
        return new[best:] if best > 0 else new
