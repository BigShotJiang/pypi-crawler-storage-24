from setuptools import setup, find_packages

setup(
    name="token-metrics",
    version="0.1.0",
    packages=find_packages(),
    install_requires=["litellm"],
    description="A simple token utilization tracking library for LLM APIs",
    author="Monica P",
)
