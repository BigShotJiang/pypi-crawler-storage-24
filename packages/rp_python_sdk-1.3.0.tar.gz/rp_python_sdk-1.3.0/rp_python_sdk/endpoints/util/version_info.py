def get_version_info() -> str:
    return "1.3.0"  # Version number
