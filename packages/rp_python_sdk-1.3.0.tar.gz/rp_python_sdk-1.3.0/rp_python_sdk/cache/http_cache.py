from collections import OrderedDict
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from threading import Lock
from typing import Optional
from rp_python_sdk.sdk_config import CustomConfig

from rp_python_sdk.setup_logger import logger

@dataclass
class CacheEntry:
    content: str
    fetched_at: datetime
    size_bytes: int


class HttpCache:
    def __init__(self, config: CustomConfig) -> None:
        self._enabled = config.cache_enabled
        self._ttl_minutes = config.cache_ttl_minutes
        self._max_entries = config.cache_max_entries
        self._max_element_size_bytes = config.cache_max_element_size_bytes

        self._cache: OrderedDict[str, CacheEntry] = OrderedDict()
        self._lock = Lock()

        logger.debug(
            f"HTTP cache initialized: enabled={self._enabled}, ttlMinutes={self._ttl_minutes}, "
            f"maxEntries={self._max_entries}, maxElementSize={self._max_element_size_bytes}"
        )

    def get(self, url: str) -> Optional[str]:
        if not self._enabled:
            return None

        with self._lock:
            if url not in self._cache:
                return None

            entry = self._cache[url]

            if self._is_stale_entry(entry):
                logger.debug(f"Cache entry stale for URL: {url}")
                return None

            self._cache.move_to_end(url)
            logger.debug(f"Cache hit for URL: {url}")
            return entry.content

    def put(self, url: str, content: str) -> None:
        if not self._enabled:
            return

        size_bytes = len(content.encode('utf-8'))

        if size_bytes > self._max_element_size_bytes:
            logger.warning(
                f"Response too large to cache: {size_bytes} bytes (max: {self._max_element_size_bytes}), URL: {url}"
            )
            return

        with self._lock:
            entry = CacheEntry(
                content=content,
                fetched_at=datetime.now(timezone.utc),
                size_bytes=size_bytes
            )

            self._cache[url] = entry
            self._cache.move_to_end(url)

            logger.debug(f"Cached response for URL: {url}, size: {size_bytes} bytes")

            if len(self._cache) > self._max_entries:
                evicted_url, _ = self._cache.popitem(last=False)
                logger.debug(f"Evicted cache entry for URL: {evicted_url}")

    def is_stale(self, url: str) -> bool:
        if not self._enabled:
            return False

        with self._lock:
            if url not in self._cache:
                return False

            entry = self._cache[url]
            return self._is_stale_entry(entry)

    def evict(self, url: str) -> None:
        if not self._enabled:
            return

        with self._lock:
            if url in self._cache:
                del self._cache[url]
                logger.debug(f"Evicted cache entry for URL: {url}")

    def clear(self) -> None:
        if not self._enabled:
            return

        with self._lock:
            self._cache.clear()
            logger.debug("Cache cleared")

    def size(self) -> int:
        with self._lock:
            return len(self._cache)

    def is_enabled(self) -> bool:
        return self._enabled

    def _is_stale_entry(self, entry: CacheEntry) -> bool:
        expiry_time: datetime = entry.fetched_at + timedelta(minutes=self._ttl_minutes)
        current_time: datetime = datetime.now(timezone.utc)
        is_stale: bool = current_time >= expiry_time
        return is_stale
