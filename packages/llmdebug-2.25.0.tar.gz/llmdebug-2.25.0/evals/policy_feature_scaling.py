"""Shared feature scaling helpers for adaptive LinUCB policies."""

from __future__ import annotations

import math
from collections.abc import Mapping

POLICY_FEATURE_SCALING_PROFILES = {"none", "v1"}
DEFAULT_POLICY_FEATURE_SCALING_PROFILE = "v1"

# Fixed caps for count-like features in v1 profile.
_V1_COUNT_CAPS = {
    "stagnation_streak": 10.0,
    "adaptive_no_progress_streak": 10.0,
    "helper_calls_used": 8.0,
    "adaptive_no_progress_token_sum_k": 200.0,
    "base_propose_budget_sec": 300.0,
}
_V1_DEFAULT_STREAK_CAP = 10.0
_V1_FINAL_CLIP = 4.0


def normalize_feature_scaling_profile(profile: str | None) -> str:
    candidate = str(profile or "").strip().lower()
    if candidate in POLICY_FEATURE_SCALING_PROFILES:
        return candidate
    return DEFAULT_POLICY_FEATURE_SCALING_PROFILE


def _safe_float(value: float) -> float:
    out = float(value)
    if math.isnan(out) or math.isinf(out):
        return 0.0
    return out


def _is_count_like_feature(name: str) -> bool:
    if name.endswith("_streak"):
        return True
    return name in _V1_COUNT_CAPS


def _count_cap_for(name: str) -> float:
    if name in _V1_COUNT_CAPS:
        return _V1_COUNT_CAPS[name]
    if name.endswith("_streak"):
        return _V1_DEFAULT_STREAK_CAP
    return 1.0


def _clip(value: float, *, clip_abs: float) -> float:
    if value > clip_abs:
        return clip_abs
    if value < -clip_abs:
        return -clip_abs
    return value


def scale_feature_mapping(
    feature_values: Mapping[str, float],
    *,
    profile: str | None = DEFAULT_POLICY_FEATURE_SCALING_PROFILE,
) -> dict[str, float]:
    normalized_profile = normalize_feature_scaling_profile(profile)
    out: dict[str, float] = {}
    for key, raw_value in dict(feature_values).items():
        name = str(key)
        value = _safe_float(float(raw_value))

        if normalized_profile == "none":
            out[name] = value
            continue

        if _is_count_like_feature(name):
            cap = max(1.0, _count_cap_for(name))
            normalized = math.log1p(max(0.0, value)) / math.log1p(cap)
            out[name] = _clip(normalized, clip_abs=_V1_FINAL_CLIP)
            continue

        # Keep bounded probabilities/features unchanged.
        if 0.0 <= value <= 1.0:
            out[name] = value
            continue

        out[name] = _clip(value, clip_abs=_V1_FINAL_CLIP)
    return out


__all__ = [
    "DEFAULT_POLICY_FEATURE_SCALING_PROFILE",
    "POLICY_FEATURE_SCALING_PROFILES",
    "normalize_feature_scaling_profile",
    "scale_feature_mapping",
]
