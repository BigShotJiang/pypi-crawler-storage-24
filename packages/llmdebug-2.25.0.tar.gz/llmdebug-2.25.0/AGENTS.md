> **Note:** `CLAUDE.md` is canonical for thresholds, release details, and the full research-compute guidance. This file is the shorter derivative for non-Claude AI agents.

# Repository Guidelines

## Debug Snapshot Workflow
- On any failing test or command, inspect `.llmdebug/latest.json` first, or run `llmdebug show --json --detail context`.
- Read the crash frame, exception message, locals, array shapes, and captured git/env context before editing.
- Form 2-4 ranked hypotheses from the evidence, then apply the smallest fix that matches the best-supported hypothesis.
- Re-run after each fix; avoid speculative multi-change patches.
- If the snapshot shows the symptom but not the cause, add targeted instrumentation such as `snapshot_section("stage_x")`, regenerate the snapshot, and continue the hypothesis loop.
- Useful CLI helpers:
  - `llmdebug show --detail full`
  - `llmdebug show --detail context`
  - `llmdebug show previous`
  - `llmdebug diff`

## Project Structure & Architecture
- `src/llmdebug/`: package code.
  - Capture and presentation: `capture.py`, `serialize.py`, `output.py`, `detail_filter.py`, `_snapshot_loader.py`, `_formatting.py`, `_presentation.py`, `_json.py`, `snapshot_types.py`, `snapshot_diff.py`.
  - RCA workflow: `rca_state.py`, `rca_transitions.py`, `rca_engine.py`, `rca_backend.py`, `rca_identity.py`, `gates.py`, `state_db.py`, `rca_store.py`.
  - Interfaces and contracts: `cli.py`, `mcp_server.py`, `mcp_git_context.py`, `mcp_rca.py`, `mcp_contract.py`, `mcp_types.py`, `pytest_plugin.py`, `jupyter_plugin.py`, `middleware.py`.
  - Runtime integrations: `hooks.py`, `redaction_policy.py`, `git_context.py`, `coverage_context.py`, `async_context.py`, `log_capture.py`.
- `evals/`: local benchmark and analysis harness.
  - Core runners: `run_eval.py`, `analyze_results.py`, `eval_summary.py`, `eval_two_pass_summary.py`, `report_run_metrics.py`, `validate_cases.py`.
  - Policy and contract logic: `adaptive_online_policy.py`, `adaptive_budget_online_policy.py`, `policy_feature_scaling.py`, `stage_a_contract.py`.
  - Support packages: `patchers/`, `importers/`, `swebench/`, `cases/`, `configs/`.
- `tests/`: pytest suite for library, RCA, MCP, CLI, and eval tooling.
- `docs/`, `slurm/`, `quality/`, `scripts/`: docs, cluster/runbook assets, quality baselines, and helper tooling.
- Generated artifacts should not be committed: `.llmdebug/`, `.benchmarks/`, `evals/artifacts/`, `evals/results/*.jsonl`, `reports/`, `dist/`, `coverage.xml`, `coverage.json`.

### Architecture guardrails
- Keep interface modules (`cli.py`, `mcp_server.py`, `pytest_plugin.py`, `jupyter_plugin.py`, `middleware.py`) thin.
- Keep reusable logic in composable core modules; avoid reverse imports from core into interface layers.
- Prefer clear seams around capture, serialization, RCA state transitions, and eval patcher/importer boundaries instead of cross-cutting edits.

## Build, Test, and Development Commands
Use `uv` for environments and direct tool execution. Use `just` when you want the repo’s standard wrapper commands.

### Quick checks
```bash
uv sync --extra dev
just lint
just typecheck
just test-quick
```

Equivalent direct commands:
```bash
uv run ruff check src tests
uv run ruff format --check src tests
uv run pyright
uv run pytest -x -q
```

### Full local quality pass
```bash
just check
just quality
```

Key direct commands:
```bash
uv run ruff check src tests evals
uv run ruff format src tests evals
uv run pytest --cov=src/llmdebug --cov-branch --cov-report=term-missing --cov-report=xml --cov-report=json --cov-fail-under=85
uv run diff-cover coverage.xml --compare-branch=origin/main --fail-under=80
uv run bandit -c pyproject.toml -r src/llmdebug
uv run vulture src/llmdebug vulture_whitelist.py --min-confidence 90
uv run deptry src/llmdebug
uv run radon cc -s -a src/llmdebug
uv run xenon --max-absolute C --max-modules C --max-average B src/llmdebug
uv run python -m evals.doc_sync --check
uv build --no-sources
```

### Formatting and doc sync
```bash
just format
just docs-sync
```

### Eval and benchmark helpers
```bash
uv run python -m evals.validate_cases --schema-only
just eval-summary <run_id>
just eval-two-pass-summary <baseline_run_id> <rescue_run_id>
```

## Server Command Convention (`pueue`)
- When suggesting commands for a server, prefer queueing them:
  - `pueue add -- <command>`
  - `pueue status`
  - `pueue log <task_id>`
  - `pueue follow <task_id>`
- If you intentionally suggest a foreground command instead, say that the direct run is deliberate.

## Coding Style & Naming
- Python 3.10+, 4-space indentation, max line length 100.
- Ruff config lives in `pyproject.toml` and currently enforces `E`, `W`, `F`, `I`, `UP`, `B`, `SIM`, `C4`, `RUF`, `PERF`, and `FURB`.
- Pyright runs in `strict` mode for `src/llmdebug`.
- Prefer precise type annotations on new or changed APIs.
- Naming conventions: `snake_case` for modules/functions/variables, `PascalCase` for classes, `UPPER_SNAKE_CASE` for constants.
- Keep patches focused and local; prefer adapters or helper seams over broad refactors.

## Testing & Quality Expectations
- Framework: `pytest` with `testpaths = ["tests"]`.
- Add a regression test for each bug fix or behavior change when feasible.
- Use async tests when touching coroutine paths.
- Coverage floor is `>=85%`; changed-line coverage is `>=80%`.
- Treat `bandit`, `deptry`, `vulture`, `radon`, and `xenon` findings as part of the normal review surface, not optional extras.
- When touching generated documentation blocks, run `just docs-sync` or at least `uv run python -m evals.doc_sync --check`.
- When touching `slurm/` scripts or runbooks, run `just slurm-check`.

## Eval & Research Notes
- Read `evals/README.md` before changing the eval harness or adding cases.
- Keep importers, patchers, and run-summary/reporting code loosely coupled; they are reused across multiple benchmark flows.
- For long-running research jobs, keep a smoke test in front of every full run and log machine-readable configs/results.
- Common `slurm/` playbook:
  - `slurm/check_env_gguf_eval.sh`
  - `slurm/run_gguf_smoke.sh`
  - `slurm/submit_gguf_sweep.sh`
  - `slurm/submit_gguf_resume_chain.sh <RUN_ID> 4`
  - `slurm/collect_gguf_debug_bundle.sh <JOBID>`
- See `slurm/README.md` and the "Research Compute Best-Practices (Hybrid)" section in `CLAUDE.md` for the full portable and HAICore-specific guidance.

## Release & PR Guidance
- Releases use `python-semantic-release`; version sources are `pyproject.toml` and `src/llmdebug/__init__.py`.
- CI and release automation live in `.github/workflows/ci-cd.yml` and `.github/workflows/release.yml`.
- Prefer Conventional Commits: `feat:`, `fix:`, `perf:`, `docs:`, `test:`, `chore:`.
- Use `feat!:` or a `BREAKING CHANGE:` footer for incompatible changes.
- Helpful release commands:
```bash
uv run semantic-release version --noop
uv run semantic-release version --print
```
- Before opening a PR or preparing a release, run `just check` at minimum and `just quality` for changes that touch tooling, docs sync, or release paths.
