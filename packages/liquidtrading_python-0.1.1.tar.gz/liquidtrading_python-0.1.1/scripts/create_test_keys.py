"""Create test API keys for integration testing.

Usage:
    cd ../combined && uv run python ../liquidtrading-python/scripts/create_test_keys.py

Requires:
    - combined repo virtualenv with prisma client generated
    - DEV_DATABASE_URL and API_KEY_ENCRYPTION_KEYS in combined/.env
"""

from __future__ import annotations

import asyncio
import os
import sys
from pathlib import Path

# Add combined repo root to path so we can import server modules
COMBINED_DIR = Path(__file__).resolve().parent.parent.parent / "combined"
sys.path.insert(0, str(COMBINED_DIR))

SDK_DIR = Path(__file__).resolve().parent.parent
ENV_FILE = SDK_DIR / ".env"


async def main() -> None:
    from dotenv import load_dotenv

    load_dotenv(COMBINED_DIR / ".env")

    from prisma import Prisma

    is_dev = os.environ.get("MODAL_ENVIRONMENT") == "dev"
    db_url = os.environ.get("DEV_DATABASE_URL") if is_dev else os.environ.get("DATABASE_URL")
    if not db_url:
        print("ERROR: selected database URL is not set in combined/.env/environment")
        sys.exit(1)

    prisma = Prisma(datasource={"url": db_url})
    await prisma.connect()

    try:
        from liquidserver.public_api.services.key_management import create_api_key

        # Create a read-only test key (permissions=1)
        result = await create_api_key(
            prisma_client=prisma,
            user_id="sdk-integration-test",
            wallet_address="0x0000000000000000000000000000000000000000",
            label="liquidtrading-sdk-integration-test",
            permissions=1,  # read-only (safe for testing)
        )

        api_key = result["api_key"]
        api_secret = result["api_secret"]

        env_content = (
            f"LIQUID_TEST_KEY={api_key}\n"
            f"LIQUID_TEST_SECRET={api_secret}\n"
            f"LIQUID_TEST_URL=http://localhost:8001\n"
        )

        ENV_FILE.write_text(env_content)
        print(f"Written to {ENV_FILE}")
        print(f"  Key:    {api_key[:15]}...")
        print(f"  Secret: {api_secret[:15]}...")
        print(f"  Perms:  read-only")
        print()
        print("To run integration tests:")
        print("  1. cd ../combined && make start_liquidserver")
        print("  2. cd ../liquidtrading-python && source .env && uv run pytest tests/test_integration.py -v")

    finally:
        await prisma.disconnect()


if __name__ == "__main__":
    asyncio.run(main())
