"""Compatibility package that mirrors the upstream ``liquid`` import path."""

from __future__ import annotations

import sys

import liquidtrading.auth as _auth
import liquidtrading.client as _client
import liquidtrading.constants as _constants
import liquidtrading.errors as _errors
import liquidtrading.http as _http
import liquidtrading.models as _models
import liquidtrading as _liquidtrading
from liquidtrading import *  # noqa: F403

sys.modules[__name__ + ".auth"] = _auth
sys.modules[__name__ + ".client"] = _client
sys.modules[__name__ + ".constants"] = _constants
sys.modules[__name__ + ".errors"] = _errors
sys.modules[__name__ + ".http"] = _http
sys.modules[__name__ + ".models"] = _models

__all__ = list(getattr(_liquidtrading, "__all__", ()))
