from __future__ import annotations

from liquid import Client, LiquidError
from liquid.client import Client as ClientSubmodule
from liquid.errors import LiquidError as LiquidErrorSubmodule


def test_liquid_compatibility_package_re_exports_sdk():
    assert Client is ClientSubmodule
    assert LiquidError is LiquidErrorSubmodule
