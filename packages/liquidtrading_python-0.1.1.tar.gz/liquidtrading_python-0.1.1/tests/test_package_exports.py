from __future__ import annotations

from liquid import Client as CompatClient
from liquidtrading import Client, LiquidClient, __version__


def test_root_exports_are_consistent():
    assert Client is LiquidClient
    assert CompatClient is LiquidClient
    assert LiquidClient.__name__ == "LiquidClient"
    assert __version__
