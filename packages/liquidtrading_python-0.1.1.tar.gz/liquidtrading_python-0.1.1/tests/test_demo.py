from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from liquidtrading.demo import main
from liquidtrading.errors import AuthenticationError


class TestDemo:
    def test_missing_credentials_exits(self, monkeypatch):
        monkeypatch.setattr("sys.argv", ["liquidtrading-demo"])

        with pytest.raises(SystemExit, match="Missing credentials"):
            main()

    def test_demo_calls_safe_sdk_methods(self, monkeypatch, capsys):
        monkeypatch.setattr(
            "sys.argv",
            [
                "liquidtrading-demo",
                "--api-key", "lq_test",
                "--api-secret", "sk_test",
                "--base-url", "http://localhost:8001",
            ],
        )

        with patch("liquidtrading.demo.LiquidClient") as mock_client_cls:
            mock_client = MagicMock()
            mock_client.get_markets.return_value = [{"symbol": "BTC-PERP"}]
            mock_client.get_ticker.return_value = {"symbol": "BTC-PERP", "mark_price": "50000"}
            mock_client.get_orderbook.return_value = {"bids": [], "asks": []}
            mock_client.get_account.return_value = {"equity": "1000"}
            mock_client.get_positions.return_value = []
            mock_client_cls.return_value.__enter__.return_value = mock_client

            main()

        output = capsys.readouterr().out
        assert "=== Markets ===" in output
        assert "=== Account ===" in output
        mock_client.get_markets.assert_called_once()
        mock_client.get_ticker.assert_called_once_with("BTC-PERP")
        mock_client.get_orderbook.assert_called_once_with("BTC-PERP", depth=5)
        mock_client.get_account.assert_called_once()
        mock_client.get_positions.assert_called_once()
        mock_client.get_open_orders.assert_not_called()

    def test_demo_can_include_open_orders(self, monkeypatch):
        monkeypatch.setattr(
            "sys.argv",
            [
                "liquidtrading-demo",
                "--api-key", "lq_test",
                "--api-secret", "sk_test",
                "--include-open-orders",
            ],
        )

        with patch("liquidtrading.demo.LiquidClient") as mock_client_cls:
            mock_client = MagicMock()
            mock_client.get_markets.return_value = []
            mock_client.get_ticker.return_value = {"symbol": "BTC-PERP", "mark_price": "50000"}
            mock_client.get_orderbook.return_value = {"bids": [], "asks": []}
            mock_client.get_account.return_value = {"equity": "1000"}
            mock_client.get_positions.return_value = []
            mock_client.get_open_orders.return_value = []
            mock_client_cls.return_value.__enter__.return_value = mock_client

            main()

        mock_client.get_open_orders.assert_called_once()

    def test_demo_prints_sdk_errors_instead_of_crashing(self, monkeypatch, capsys):
        monkeypatch.setattr(
            "sys.argv",
            [
                "liquidtrading-demo",
                "--api-key", "lq_test",
                "--api-secret", "sk_test",
                "--include-open-orders",
            ],
        )

        with patch("liquidtrading.demo.LiquidClient") as mock_client_cls:
            mock_client = MagicMock()
            mock_client.get_markets.return_value = []
            mock_client.get_ticker.return_value = {"symbol": "BTC-PERP", "mark_price": "50000"}
            mock_client.get_orderbook.return_value = {"bids": [], "asks": []}
            mock_client.get_account.return_value = {"equity": "1000"}
            mock_client.get_positions.return_value = []
            mock_client.get_open_orders.side_effect = AuthenticationError(
                code="UNAUTHORIZED",
                message="Authentication failed: You must call init first!",
                status_code=401,
            )
            mock_client_cls.return_value.__enter__.return_value = mock_client

            main()

        output = capsys.readouterr().out
        assert "=== Open Orders ===" in output
        assert "You must call init first!" in output
