"""Auth tests cross-validated with server's test_hmac_auth.py test vectors."""

from __future__ import annotations

import hashlib
import hmac
import json
import re

from liquidtrading.auth import (
    canonicalize_path,
    canonicalize_query,
    compute_body_hash,
    compute_signature,
    generate_nonce,
    generate_timestamp,
    sign_request,
)


class TestComputeSignature:
    """Mirrored from server test_hmac_auth.py::TestComputeSignature."""

    def test_known_input_produces_expected_signature(self):
        """Exact test vector from server test_hmac_auth.py:32-48."""
        sig = compute_signature(
            secret="my_secret",
            timestamp="1000000",
            nonce="abc123",
            method="GET",
            path="/v1/orders",
            query="",
            body_hash="e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
        )
        message = "1000000\nabc123\nGET\n/v1/orders\n\ne3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
        expected = hmac.new(
            b"my_secret", message.encode("utf-8"), hashlib.sha256
        ).hexdigest()
        assert sig == expected

    def test_method_is_uppercased(self):
        sig_lower = compute_signature(
            secret="s", timestamp="1000", nonce="n",
            method="get", path="/test", query="", body_hash="h",
        )
        sig_upper = compute_signature(
            secret="s", timestamp="1000", nonce="n",
            method="GET", path="/test", query="", body_hash="h",
        )
        assert sig_lower == sig_upper

    def test_different_secrets_produce_different_signatures(self):
        common = dict(
            timestamp="1000", nonce="n", method="GET",
            path="/test", query="", body_hash="h",
        )
        sig1 = compute_signature(secret="secret_a", **common)
        sig2 = compute_signature(secret="secret_b", **common)
        assert sig1 != sig2

    def test_different_body_hashes_produce_different_signatures(self):
        common = dict(
            secret="s", timestamp="1000", nonce="n",
            method="GET", path="/test", query="",
        )
        sig1 = compute_signature(body_hash="hash_a", **common)
        sig2 = compute_signature(body_hash="hash_b", **common)
        assert sig1 != sig2

    def test_different_methods_produce_different_signatures(self):
        common = dict(
            secret="s", timestamp="1000", nonce="n",
            path="/test", query="", body_hash="h",
        )
        sig1 = compute_signature(method="GET", **common)
        sig2 = compute_signature(method="POST", **common)
        assert sig1 != sig2

    def test_different_paths_produce_different_signatures(self):
        common = dict(
            secret="s", timestamp="1000", nonce="n",
            method="GET", query="", body_hash="h",
        )
        sig1 = compute_signature(path="/a", **common)
        sig2 = compute_signature(path="/b", **common)
        assert sig1 != sig2

    def test_empty_body_hash_produces_valid_64_char_hex(self):
        sig = compute_signature(
            secret="s", timestamp="1000", nonce="n",
            method="GET", path="/test", query="", body_hash="",
        )
        assert isinstance(sig, str)
        assert len(sig) == 64


class TestCanonicalizePath:
    """Mirrored from server test_hmac_auth.py::TestCanonicalizePath."""

    def test_strips_trailing_slash(self):
        assert canonicalize_path("/v1/orders/") == "/v1/orders"

    def test_lowercases_path(self):
        assert canonicalize_path("/V1/Orders") == "/v1/orders"

    def test_strips_query_from_path(self):
        assert canonicalize_path("/v1/orders?foo=bar") == "/v1/orders"

    def test_root_path_stays_root(self):
        assert canonicalize_path("/") == "/"

    def test_empty_after_strip_returns_slash(self):
        assert canonicalize_path("///") == "/"


class TestCanonicalizeQuery:
    """Mirrored from server test_hmac_auth.py::TestCanonicalizeQuery."""

    def test_sorts_params_alphabetically(self):
        assert canonicalize_query("z=1&a=2&m=3") == "a=2&m=3&z=1"

    def test_empty_query_returns_empty(self):
        assert canonicalize_query("") == ""

    def test_duplicate_params_sorted_by_value(self):
        assert canonicalize_query("a=2&a=1") == "a=1&a=2"

    def test_preserves_blank_values(self):
        assert canonicalize_query("a=&b=1") == "a=&b=1"

    def test_percent_encodes_special_characters(self):
        assert canonicalize_query("q=hello world&b=1") == "b=1&q=hello%20world"

    def test_safe_chars_not_encoded(self):
        assert canonicalize_query("a=foo-bar.baz_qux~x") == "a=foo-bar.baz_qux~x"


class TestComputeBodyHash:
    """Mirrored from server test_hmac_auth.py::TestComputeBodyHash."""

    def test_none_body_hashes_empty_string(self):
        result = compute_body_hash(None)
        expected = hashlib.sha256(b"").hexdigest()
        assert result == expected

    def test_empty_bytes_hashes_empty_string(self):
        result = compute_body_hash(b"")
        expected = hashlib.sha256(b"").hexdigest()
        assert result == expected

    def test_sorts_keys_deterministically(self):
        body1 = json.dumps({"z": 1, "a": 2}).encode()
        body2 = json.dumps({"a": 2, "z": 1}).encode()
        assert compute_body_hash(body1) == compute_body_hash(body2)

    def test_compact_separators_used(self):
        body = json.dumps({"key": "value"}).encode()
        result = compute_body_hash(body)
        canonical = json.dumps({"key": "value"}, separators=(",", ":"), sort_keys=True).encode()
        expected = hashlib.sha256(canonical).hexdigest()
        assert result == expected

    def test_non_json_body_hashed_as_is(self):
        body = b"not-json"
        result = compute_body_hash(body)
        expected = hashlib.sha256(body).hexdigest()
        assert result == expected


class TestGenerateNonce:
    def test_nonce_is_32_hex_chars(self):
        nonce = generate_nonce()
        assert len(nonce) == 32
        assert re.match(r"^[a-f0-9]{32}$", nonce)

    def test_nonce_matches_server_pattern(self):
        """Server requires ^[a-zA-Z0-9_-]{8,64}$."""
        nonce = generate_nonce()
        assert re.match(r"^[a-zA-Z0-9_-]{8,64}$", nonce)

    def test_nonces_are_unique(self):
        nonces = {generate_nonce() for _ in range(100)}
        assert len(nonces) == 100


class TestGenerateTimestamp:
    def test_timestamp_is_ms_string(self):
        ts = generate_timestamp()
        assert ts.isdigit()
        assert len(ts) >= 13  # ms since epoch


class TestSignRequest:
    def test_returns_four_auth_headers(self):
        headers = sign_request(
            api_secret="sk_test",
            method="GET",
            path="/v1/orders",
            query_string="",
            body=None,
        )
        assert "X-Liquid-Key" not in headers  # key added by http layer
        assert "X-Liquid-Timestamp" in headers
        assert "X-Liquid-Nonce" in headers
        assert "X-Liquid-Signature" in headers

    def test_signature_is_verifiable(self):
        """Reproduce the signature manually to verify correctness."""
        headers = sign_request(
            api_secret="my_secret",
            method="POST",
            path="/v1/orders",
            query_string="",
            body=b'{"symbol":"BTC","side":"buy"}',
        )
        ts = headers["X-Liquid-Timestamp"]
        nonce = headers["X-Liquid-Nonce"]
        sig = headers["X-Liquid-Signature"]

        body_hash = compute_body_hash(b'{"symbol":"BTC","side":"buy"}')
        path = canonicalize_path("/v1/orders")
        expected_sig = compute_signature(
            secret="my_secret",
            timestamp=ts,
            nonce=nonce,
            method="POST",
            path=path,
            query="",
            body_hash=body_hash,
        )
        assert sig == expected_sig
