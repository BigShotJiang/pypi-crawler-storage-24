from __future__ import annotations

import pytest

from liquidtrading.errors import (
    AuthenticationError,
    ConnectionError,
    ExchangeError,
    ExpiredTimestampError,
    ForbiddenError,
    GatewayTimeoutError,
    InsufficientBalanceError,
    InsufficientScopeError,
    InvalidApiKeyError,
    InvalidSignatureError,
    IpForbiddenError,
    LiquidError,
    NotFoundError,
    OrderRejectedError,
    RateLimitError,
    ReplayedNonceError,
    ServiceUnavailableError,
    ServerError,
    SymbolNotFoundError,
    TimeoutError,
    ValidationError,
    error_from_response,
)


class TestLiquidError:
    def test_str_format(self):
        err = LiquidError(code="BAD_REQUEST", message="something broke", status_code=400)
        assert str(err) == "[BAD_REQUEST] something broke"

    def test_fields_accessible(self):
        err = LiquidError(code="X", message="Y", status_code=500)
        assert err.code == "X"
        assert err.message == "Y"
        assert err.status_code == 500

    def test_is_exception(self):
        assert issubclass(LiquidError, Exception)


class TestErrorFromResponse:
    # --- 401 auth errors ---

    def test_401_returns_authentication_error(self):
        err = error_from_response(401, "MISSING_AUTH_HEADERS", "missing headers", {})
        assert isinstance(err, AuthenticationError)
        assert isinstance(err, LiquidError)

    def test_401_invalid_api_key(self):
        err = error_from_response(401, "INVALID_API_KEY", "bad key", {})
        assert isinstance(err, InvalidApiKeyError)
        assert isinstance(err, AuthenticationError)
        assert err.code == "INVALID_API_KEY"

    def test_401_invalid_signature(self):
        err = error_from_response(401, "INVALID_SIGNATURE", "sig mismatch", {})
        assert isinstance(err, InvalidSignatureError)
        assert isinstance(err, AuthenticationError)

    def test_401_expired_timestamp(self):
        err = error_from_response(401, "EXPIRED_TIMESTAMP", "too old", {})
        assert isinstance(err, ExpiredTimestampError)
        assert isinstance(err, AuthenticationError)

    def test_401_invalid_timestamp(self):
        err = error_from_response(401, "INVALID_TIMESTAMP", "not a number", {})
        assert isinstance(err, AuthenticationError)

    def test_401_invalid_nonce(self):
        err = error_from_response(401, "INVALID_NONCE", "bad format", {})
        assert isinstance(err, AuthenticationError)

    def test_401_replayed_nonce(self):
        err = error_from_response(401, "REPLAYED_NONCE", "already used", {})
        assert isinstance(err, ReplayedNonceError)
        assert isinstance(err, AuthenticationError)

    def test_401_unknown_code_falls_back_to_authentication_error(self):
        err = error_from_response(401, "UNKNOWN_AUTH_CODE", "mystery", {})
        assert isinstance(err, AuthenticationError)
        assert type(err) is AuthenticationError

    # --- 403 forbidden errors ---

    def test_403_returns_forbidden_error(self):
        err = error_from_response(403, "FORBIDDEN", "no access", {})
        assert isinstance(err, ForbiddenError)

    def test_403_ip_forbidden(self):
        err = error_from_response(403, "IP_FORBIDDEN", "ip not allowed", {})
        assert isinstance(err, IpForbiddenError)
        assert isinstance(err, ForbiddenError)

    def test_403_insufficient_scope(self):
        err = error_from_response(403, "INSUFFICIENT_SCOPE", "need trade", {})
        assert isinstance(err, InsufficientScopeError)
        assert isinstance(err, ForbiddenError)

    # --- 404 not found errors ---

    def test_404_returns_not_found_error(self):
        err = error_from_response(404, "NOT_FOUND", "gone", {})
        assert isinstance(err, NotFoundError)

    def test_404_symbol_not_found(self):
        err = error_from_response(404, "SYMBOL_NOT_FOUND", "no such symbol", {})
        assert isinstance(err, SymbolNotFoundError)
        assert isinstance(err, NotFoundError)

    # --- 429 rate limit ---

    def test_429_returns_rate_limit_error_with_retry_after(self):
        err = error_from_response(429, "RATE_LIMIT_EXCEEDED", "slow down", {"Retry-After": "5"})
        assert isinstance(err, RateLimitError)
        assert err.retry_after == 5.0

    def test_429_without_retry_after_defaults_to_none(self):
        err = error_from_response(429, "RATE_LIMIT_EXCEEDED", "slow", {})
        assert isinstance(err, RateLimitError)
        assert err.retry_after is None

    # --- 400/422 validation errors ---

    def test_400_insufficient_balance(self):
        err = error_from_response(400, "INSUFFICIENT_BALANCE", "not enough", {})
        assert isinstance(err, InsufficientBalanceError)
        assert isinstance(err, ValidationError)

    def test_400_order_rejected(self):
        err = error_from_response(400, "ORDER_REJECTED", "rejected", {})
        assert isinstance(err, OrderRejectedError)
        assert isinstance(err, ValidationError)

    def test_400_validation_error(self):
        err = error_from_response(400, "VALIDATION_ERROR", "invalid field", {})
        assert isinstance(err, ValidationError)

    def test_400_bad_request(self):
        err = error_from_response(400, "BAD_REQUEST", "bad", {})
        assert isinstance(err, ValidationError)

    def test_400_unknown_code_falls_back_to_validation_error(self):
        err = error_from_response(400, "SOME_NEW_CODE", "unknown", {})
        assert isinstance(err, ValidationError)
        assert type(err) is ValidationError

    # --- 5xx server errors ---

    def test_500_returns_server_error(self):
        err = error_from_response(500, "INTERNAL_ERROR", "oops", {})
        assert isinstance(err, ServerError)

    def test_502_returns_exchange_error(self):
        err = error_from_response(502, "EXCHANGE_ERROR", "hl down", {})
        assert isinstance(err, ExchangeError)

    def test_504_returns_gateway_timeout_error(self):
        err = error_from_response(504, "TIMEOUT", "timed out", {})
        assert isinstance(err, GatewayTimeoutError)
        assert isinstance(err, LiquidError)

    def test_503_returns_service_unavailable_error(self):
        err = error_from_response(503, "AUTH_UNAVAILABLE", "temporarily unavailable", {})
        assert isinstance(err, ServiceUnavailableError)
        assert isinstance(err, LiquidError)

    # --- fallback ---

    def test_unknown_status_returns_liquid_error(self):
        err = error_from_response(418, "TEAPOT", "I'm a teapot", {})
        assert isinstance(err, LiquidError)
        assert err.status_code == 418


class TestTransportErrors:
    def test_timeout_error_is_liquid_error(self):
        err = TimeoutError(message="request timed out")
        assert isinstance(err, LiquidError)
        assert err.code == "TIMEOUT"

    def test_connection_error_is_liquid_error(self):
        err = ConnectionError(message="cannot connect")
        assert isinstance(err, LiquidError)
        assert err.code == "CONNECTION_ERROR"
