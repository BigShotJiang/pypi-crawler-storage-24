from __future__ import annotations

from unittest.mock import patch

import pytest

from liquidtrading.client import LiquidClient
from liquidtrading.models import (
    Account,
    Balance,
    Candle,
    CloseResult,
    LeverageResult,
    MarginResult,
    OpenOrder,
    Order,
    Orderbook,
    Position,
    Ticker,
    TpSlResult,
)


@pytest.fixture()
def mock_http():
    with patch("liquidtrading.client.HttpClient") as mock_http_cls:
        yield mock_http_cls.return_value


@pytest.fixture()
def client(mock_http):
    yield LiquidClient(api_key="lq_test", api_secret="sk_test")


class TestPublicMarketData:
    def test_get_markets_returns_raw_market_dicts(self, client, mock_http):
        mock_http.get.return_value = [
            {"symbol": "BTC-PERP", "ticker": "BTC", "exchange": "hyperliquid"},
        ]

        result = client.get_markets()

        assert result[0]["symbol"] == "BTC-PERP"
        mock_http.get.assert_called_once_with("/v1/markets")

    def test_get_ticker_returns_typed_model(self, client, mock_http):
        mock_http.get.return_value = {"symbol": "BTC-PERP", "mark_price": "50000"}

        result = client.get_ticker("BTC-PERP")

        assert isinstance(result, Ticker)
        assert result.mark_price == 50000.0

    def test_get_orderbook_returns_typed_model(self, client, mock_http):
        mock_http.get.return_value = {
            "symbol": "BTC-PERP",
            "bids": [{"price": "49999", "size": "1.0"}],
            "asks": [{"price": "50001", "size": "0.5"}],
            "timestamp": 1700000000000,
        }

        result = client.get_orderbook("BTC-PERP", depth=10)

        assert isinstance(result, Orderbook)
        assert result.bids[0].price == 49999.0
        mock_http.get.assert_called_once_with(
            "/v1/markets/BTC-PERP/orderbook",
            params={"depth": 10},
        )

    def test_get_candles_returns_typed_models(self, client, mock_http):
        mock_http.get.return_value = [
            {
                "timestamp": 1700000000000,
                "open": "50000",
                "high": "51000",
                "low": "49000",
                "close": "50500",
                "volume": "1234",
            },
        ]

        result = client.get_candles("BTC-PERP", interval="1h", limit=50)

        assert isinstance(result[0], Candle)
        assert result[0].close == 50500.0

    def test_get_candles_rejects_invalid_interval(self, client):
        with pytest.raises(ValueError, match="Invalid interval"):
            client.get_candles("BTC-PERP", interval="2h")


class TestReadEndpoints:
    def test_get_account_returns_typed_model(self, client, mock_http):
        mock_http.get.return_value = {
            "equity": "10000",
            "margin_used": "500",
            "available_balance": "9500",
            "account_value": "10000",
        }

        result = client.get_account()

        assert isinstance(result, Account)
        assert result.available_balance == 9500.0

    def test_get_balances_returns_typed_model(self, client, mock_http):
        mock_http.get.return_value = {
            "exchange": "hyperliquid",
            "equity": "10000",
            "available_balance": "9500",
            "margin_used": "500",
            "cross_margin": {
                "account_value": "10000",
                "total_margin_used": "500",
                "total_ntl_pos": "1000",
            },
        }

        result = client.get_balances()

        assert isinstance(result, Balance)
        assert result.cross_margin is not None
        assert result.cross_margin.total_ntl_pos == 1000.0

    def test_get_positions_returns_typed_models(self, client, mock_http):
        mock_http.get.return_value = [
            {
                "symbol": "BTC-PERP",
                "side": "long",
                "size": "0.5",
                "entry_price": "50000",
                "leverage": "10",
                "unrealized_pnl": "500",
            },
        ]

        result = client.get_positions()

        assert isinstance(result[0], Position)
        assert result[0].size == 0.5


class TestOrders:
    def test_place_order_returns_typed_model(self, client, mock_http):
        mock_http.post.return_value = {
            "order_id": "abc",
            "symbol": "BTC-PERP",
            "side": "buy",
            "type": "market",
            "size": 100.0,
            "price": None,
            "leverage": 1,
            "status": "filled",
            "exchange": "hyperliquid",
            "tp": None,
            "sl": None,
            "reduce_only": False,
            "created_at": None,
        }

        result = client.place_order("BTC-PERP", "buy", size=100.0)

        assert isinstance(result, Order)
        assert result.order_id == "abc"

    def test_place_order_validates_inputs(self, client):
        with pytest.raises(ValueError, match="side"):
            client.place_order("BTC-PERP", "long", size=100.0)
        with pytest.raises(ValueError, match="price"):
            client.place_order("BTC-PERP", "buy", type="limit", size=100.0)
        with pytest.raises(ValueError, match="leverage"):
            client.place_order("BTC-PERP", "buy", size=100.0, leverage=201)
        with pytest.raises(ValueError, match="time_in_force"):
            client.place_order("BTC-PERP", "buy", size=100.0, time_in_force="fok")

    def test_get_open_orders_returns_typed_models(self, client, mock_http):
        mock_http.get.return_value = [
            {
                "order_id": "x",
                "symbol": "BTC-PERP",
                "side": "buy",
                "size": "100.0",
                "price": "50000.0",
                "timestamp": 1700000000000,
            },
        ]

        result = client.get_open_orders()

        assert isinstance(result[0], OpenOrder)
        assert result[0].price == 50000.0

    def test_get_order_uses_order_model_with_endpoint_defaults(self, client, mock_http):
        mock_http.get.return_value = {
            "order_id": "x",
            "symbol": "BTC-PERP",
            "side": "buy",
            "size": "100.0",
            "price": "50000.0",
            "timestamp": 1700000000000,
        }

        result = client.get_order("x")

        assert isinstance(result, Order)
        assert result.type == "unknown"
        assert result.status == "unknown"

    def test_cancel_order_returns_true(self, client, mock_http):
        mock_http.delete.return_value = {"status": "cancelled"}

        assert client.cancel_order("x") is True

    def test_cancel_all_orders_returns_count(self, client, mock_http):
        mock_http.delete.return_value = [
            {"order_id": "1", "symbol": "BTC-PERP", "status": "cancelled"},
            {"order_id": "2", "symbol": "ETH-PERP", "status": "cancelled"},
        ]

        assert client.cancel_all_orders() == 2

    def test_cancel_all_orders_returns_zero_for_non_list(self, client, mock_http):
        mock_http.delete.return_value = {"status": "ok"}

        assert client.cancel_all_orders() == 0


class TestPositions:
    def test_close_position_returns_typed_model(self, client, mock_http):
        mock_http.post.return_value = {
            "symbol": "BTC-PERP",
            "status": "closed",
            "message": "ok",
        }

        result = client.close_position("BTC-PERP")

        assert isinstance(result, CloseResult)
        assert result.status == "closed"

    def test_set_tp_sl_returns_typed_model(self, client, mock_http):
        mock_http.patch.return_value = {"tp": {"status": "ok"}, "sl": {"status": "ok"}}

        result = client.set_tp_sl("BTC-PERP", tp=55000, sl=48000)

        assert isinstance(result, TpSlResult)
        assert result.tp == {"status": "ok"}

    def test_update_leverage_returns_typed_model(self, client, mock_http):
        mock_http.patch.return_value = {
            "symbol": "BTC-PERP",
            "leverage": 10,
            "is_cross": False,
        }

        result = client.update_leverage("BTC-PERP", leverage=10)

        assert isinstance(result, LeverageResult)
        assert result.leverage == 10

    def test_update_margin_returns_typed_model(self, client, mock_http):
        mock_http.patch.return_value = {
            "symbol": "BTC-PERP",
            "margin_adjusted": 25.0,
        }

        result = client.update_margin("BTC-PERP", amount=25.0)

        assert isinstance(result, MarginResult)
        assert result.margin_adjusted == 25.0

