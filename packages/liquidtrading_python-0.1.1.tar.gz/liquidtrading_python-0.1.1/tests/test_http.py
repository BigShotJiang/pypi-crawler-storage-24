from __future__ import annotations

import httpx
import pytest
import respx

from liquidtrading.errors import (
    AuthenticationError,
    ConnectionError,
    ExchangeError,
    GatewayTimeoutError,
    InvalidApiKeyError,
    RateLimitError,
    ServiceUnavailableError,
    ServerError,
    TimeoutError,
    ValidationError,
)
from liquidtrading.http import HttpClient


@pytest.fixture()
def unauthenticated_client():
    client = HttpClient(base_url="https://api.liquid.trade")
    yield client
    client.close()


@pytest.fixture()
def authenticated_client():
    client = HttpClient(
        base_url="https://api.liquid.trade",
        api_key="lq_testkey",
        api_secret="sk_testsecret",
    )
    yield client
    client.close()


class TestSuccessResponses:
    @respx.mock
    def test_get_returns_unwrapped_data(self, unauthenticated_client):
        respx.get("https://api.liquid.trade/v1/markets").mock(
            return_value=httpx.Response(200, json={"success": True, "data": [{"symbol": "BTC-PERP"}], "error": None})
        )
        result = unauthenticated_client.get("/v1/markets")
        assert result == [{"symbol": "BTC-PERP"}]

    @respx.mock
    def test_post_returns_unwrapped_data(self, authenticated_client):
        respx.post("https://api.liquid.trade/v1/orders").mock(
            return_value=httpx.Response(200, json={"success": True, "data": {"order_id": "123"}, "error": None})
        )
        result = authenticated_client.post("/v1/orders", json={"symbol": "BTC"})
        assert result == {"order_id": "123"}


class TestErrorResponses:
    @respx.mock
    def test_401_raises_authentication_error(self, unauthenticated_client):
        respx.get("https://api.liquid.trade/v1/account").mock(
            return_value=httpx.Response(401, json={
                "success": False, "data": None,
                "error": {"code": "INVALID_API_KEY", "message": "bad key"},
            })
        )
        with pytest.raises(InvalidApiKeyError) as exc_info:
            unauthenticated_client.get("/v1/account")
        assert exc_info.value.status_code == 401
        assert isinstance(exc_info.value, AuthenticationError)

    @respx.mock
    def test_400_raises_validation_error(self, unauthenticated_client):
        respx.post("https://api.liquid.trade/v1/orders").mock(
            return_value=httpx.Response(400, json={
                "success": False, "data": None,
                "error": {"code": "BAD_REQUEST", "message": "invalid"},
            })
        )
        with pytest.raises(ValidationError):
            unauthenticated_client.post("/v1/orders", json={})

    @respx.mock
    def test_429_raises_rate_limit_with_retry_after(self, unauthenticated_client):
        respx.get("https://api.liquid.trade/v1/markets").mock(
            return_value=httpx.Response(
                429,
                json={"success": False, "data": None,
                      "error": {"code": "RATE_LIMIT_EXCEEDED", "message": "slow"}},
                headers={"Retry-After": "3"},
            )
        )
        with pytest.raises(RateLimitError) as exc_info:
            unauthenticated_client.get("/v1/markets")
        assert exc_info.value.retry_after == 3.0

    @respx.mock
    def test_500_raises_server_error(self, unauthenticated_client):
        respx.get("https://api.liquid.trade/v1/markets").mock(
            return_value=httpx.Response(500, json={
                "success": False, "data": None,
                "error": {"code": "INTERNAL_ERROR", "message": "boom"},
            })
        )
        with pytest.raises(ServerError):
            unauthenticated_client.get("/v1/markets")

    @respx.mock
    def test_502_raises_exchange_error(self, unauthenticated_client):
        respx.get("https://api.liquid.trade/v1/markets").mock(
            return_value=httpx.Response(502, json={
                "success": False, "data": None,
                "error": {"code": "EXCHANGE_ERROR", "message": "hl down"},
            })
        )
        with pytest.raises(ExchangeError):
            unauthenticated_client.get("/v1/markets")

    @respx.mock
    def test_504_raises_gateway_timeout_error(self, unauthenticated_client):
        respx.get("https://api.liquid.trade/v1/markets").mock(
            return_value=httpx.Response(504, json={
                "success": False, "data": None,
                "error": {"code": "TIMEOUT", "message": "timed out"},
            })
        )
        with pytest.raises(GatewayTimeoutError):
            unauthenticated_client.get("/v1/markets")

    @respx.mock
    def test_503_raises_service_unavailable_error(self, unauthenticated_client):
        respx.get("https://api.liquid.trade/v1/markets").mock(
            return_value=httpx.Response(503, json={
                "success": False, "data": None,
                "error": {"code": "AUTH_UNAVAILABLE", "message": "unavailable"},
            })
        )
        with pytest.raises(ServiceUnavailableError):
            unauthenticated_client.get("/v1/markets")


class TestAuthHeaders:
    @respx.mock
    def test_auth_headers_present_when_credentials_set(self, authenticated_client):
        route = respx.get("https://api.liquid.trade/v1/account").mock(
            return_value=httpx.Response(200, json={"success": True, "data": {}, "error": None})
        )
        authenticated_client.get("/v1/account")
        request = route.calls[0].request
        assert "X-Liquid-Key" in request.headers
        assert "X-Liquid-Signature" in request.headers
        assert "X-Liquid-Timestamp" in request.headers
        assert "X-Liquid-Nonce" in request.headers

    @respx.mock
    def test_auth_headers_absent_when_no_credentials(self, unauthenticated_client):
        route = respx.get("https://api.liquid.trade/v1/markets").mock(
            return_value=httpx.Response(200, json={"success": True, "data": [], "error": None})
        )
        unauthenticated_client.get("/v1/markets")
        request = route.calls[0].request
        assert "X-Liquid-Key" not in request.headers
        assert "X-Liquid-Signature" not in request.headers

    @respx.mock
    def test_api_key_in_header(self, authenticated_client):
        route = respx.get("https://api.liquid.trade/v1/account").mock(
            return_value=httpx.Response(200, json={"success": True, "data": {}, "error": None})
        )
        authenticated_client.get("/v1/account")
        request = route.calls[0].request
        assert request.headers["X-Liquid-Key"] == "lq_testkey"


class TestUserAgent:
    @respx.mock
    def test_user_agent_header_set(self, unauthenticated_client):
        route = respx.get("https://api.liquid.trade/v1/markets").mock(
            return_value=httpx.Response(200, json={"success": True, "data": [], "error": None})
        )
        unauthenticated_client.get("/v1/markets")
        request = route.calls[0].request
        assert "liquidtrading-python/" in request.headers["User-Agent"]


class TestTransportErrors:
    @respx.mock
    def test_httpx_timeout_maps_to_timeout_error(self, unauthenticated_client):
        respx.get("https://api.liquid.trade/v1/markets").mock(
            side_effect=httpx.TimeoutException("timed out")
        )
        with pytest.raises(TimeoutError):
            unauthenticated_client.get("/v1/markets")

    @respx.mock
    def test_httpx_connect_error_maps_to_connection_error(self, unauthenticated_client):
        respx.get("https://api.liquid.trade/v1/markets").mock(
            side_effect=httpx.ConnectError("connection refused")
        )
        with pytest.raises(ConnectionError):
            unauthenticated_client.get("/v1/markets")


class TestRetries:
    @respx.mock
    def test_get_retries_on_429(self):
        client = HttpClient(base_url="https://api.liquid.trade", max_retries=2)
        route = respx.get("https://api.liquid.trade/v1/markets")
        route.side_effect = [
            httpx.Response(429, json={"success": False, "data": None,
                                      "error": {"code": "RATE_LIMIT_EXCEEDED", "message": "slow"}},
                           headers={"Retry-After": "0"}),
            httpx.Response(200, json={"success": True, "data": ["ok"], "error": None}),
        ]
        result = client.get("/v1/markets")
        assert result == ["ok"]
        assert route.call_count == 2
        client.close()

    @respx.mock
    def test_post_never_retries_on_429(self):
        client = HttpClient(
            base_url="https://api.liquid.trade",
            api_key="lq_k", api_secret="sk_s",
            max_retries=2,
        )
        respx.post("https://api.liquid.trade/v1/orders").mock(
            return_value=httpx.Response(429, json={
                "success": False, "data": None,
                "error": {"code": "RATE_LIMIT_EXCEEDED", "message": "slow"},
            }, headers={"Retry-After": "0"})
        )
        with pytest.raises(RateLimitError):
            client.post("/v1/orders", json={"symbol": "BTC"})
        client.close()

    @respx.mock
    def test_get_retries_on_500(self):
        client = HttpClient(base_url="https://api.liquid.trade", max_retries=1)
        route = respx.get("https://api.liquid.trade/v1/markets")
        route.side_effect = [
            httpx.Response(500, json={"success": False, "data": None,
                                      "error": {"code": "INTERNAL_ERROR", "message": "boom"}}),
            httpx.Response(200, json={"success": True, "data": [], "error": None}),
        ]
        result = client.get("/v1/markets")
        assert result == []
        client.close()

    @respx.mock
    def test_exhausted_retries_raises(self):
        client = HttpClient(base_url="https://api.liquid.trade", max_retries=1)
        respx.get("https://api.liquid.trade/v1/markets").mock(
            return_value=httpx.Response(500, json={
                "success": False, "data": None,
                "error": {"code": "INTERNAL_ERROR", "message": "boom"},
            })
        )
        with pytest.raises(ServerError):
            client.get("/v1/markets")
        client.close()


class TestClose:
    def test_close_does_not_raise(self):
        client = HttpClient(base_url="https://api.liquid.trade")
        client.close()  # should not raise
