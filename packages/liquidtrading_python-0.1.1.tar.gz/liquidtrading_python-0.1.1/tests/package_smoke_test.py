from __future__ import annotations

from liquid import Client as CompatClient
from liquidtrading import Client, LiquidClient, __version__


def main() -> None:
    client = LiquidClient(api_key="lq_test", api_secret="sk_test")
    assert client.__class__.__name__ == "LiquidClient"
    assert Client is LiquidClient
    assert CompatClient is LiquidClient
    assert __version__
    print(f"liquidtrading-python {__version__} import smoke test passed")


if __name__ == "__main__":
    main()
