from __future__ import annotations

import pytest

from liquidtrading.models import (
    Account,
    Balance,
    Candle,
    CloseResult,
    LeverageResult,
    MarginResult,
    Market,
    OpenOrder,
    Order,
    Orderbook,
    Position,
    Ticker,
    TpSlResult,
    _account_from_dict,
    _balance_from_dict,
    _candle_from_dict,
    _close_result_from_dict,
    _leverage_result_from_dict,
    _margin_result_from_dict,
    _market_from_dict,
    _open_order_from_dict,
    _order_from_dict,
    _orderbook_from_dict,
    _position_from_dict,
    _ticker_from_dict,
    _tp_sl_result_from_dict,
)


def test_market_from_dict():
    market = _market_from_dict(
        {
            "symbol": "BTC-PERP",
            "ticker": "BTC",
            "exchange": "hyperliquid",
            "max_leverage": 50,
            "sz_decimals": 4,
        }
    )

    assert isinstance(market, Market)
    assert market.max_leverage == 50


def test_market_is_frozen():
    market = Market("BTC-PERP", "BTC", "hyperliquid", None, None)

    with pytest.raises(AttributeError):
        market.symbol = "ETH-PERP"  # type: ignore[misc]


def test_ticker_converts_numeric_strings():
    ticker = _ticker_from_dict(
        {
            "symbol": "BTC-PERP",
            "mark_price": "50000.0",
            "volume_24h": "1000000",
            "change_24h": "2.5",
            "funding_rate": "0.01",
        }
    )

    assert isinstance(ticker, Ticker)
    assert ticker.mark_price == 50000.0
    assert ticker.funding_rate == 0.01


def test_orderbook_converts_levels_to_float():
    orderbook = _orderbook_from_dict(
        {
            "symbol": "BTC-PERP",
            "bids": [{"price": "49999", "size": "1.0", "count": 1}],
            "asks": [{"price": "50001", "size": "0.5", "count": 2}],
            "timestamp": 1700000000000,
        }
    )

    assert isinstance(orderbook, Orderbook)
    assert orderbook.bids[0].price == 49999.0
    assert orderbook.asks[0].size == 0.5


def test_candle_converts_numeric_strings():
    candle = _candle_from_dict(
        {
            "timestamp": 1700000000000,
            "open": "50000",
            "high": "51000",
            "low": "49000",
            "close": "50500",
            "volume": "1234",
        }
    )

    assert isinstance(candle, Candle)
    assert candle.volume == 1234.0


def test_account_converts_numeric_strings():
    account = _account_from_dict(
        {
            "equity": "10000",
            "margin_used": "500",
            "available_balance": "9500",
            "account_value": "10000",
        }
    )

    assert isinstance(account, Account)
    assert account.available_balance == 9500.0


def test_balance_parses_cross_margin():
    balance = _balance_from_dict(
        {
            "exchange": "hyperliquid",
            "equity": "10000",
            "available_balance": "9500",
            "margin_used": "500",
            "cross_margin": {
                "account_value": "10000",
                "total_margin_used": "500",
                "total_ntl_pos": "1000",
            },
        }
    )

    assert isinstance(balance, Balance)
    assert balance.cross_margin is not None
    assert balance.cross_margin.total_ntl_pos == 1000.0


def test_position_converts_numeric_strings():
    position = _position_from_dict(
        {
            "symbol": "BTC-PERP",
            "side": "long",
            "size": "0.5",
            "entry_price": "50000",
            "mark_price": "51000",
            "leverage": "10",
            "unrealized_pnl": "500",
            "liquidation_price": "45000",
            "margin_used": "2500",
        }
    )

    assert isinstance(position, Position)
    assert position.leverage == 10.0
    assert position.margin_used == 2500.0


def test_order_uses_defaults_for_sparse_order_lookup_payloads():
    order = _order_from_dict(
        {
            "order_id": "abc123",
            "symbol": "BTC-PERP",
            "side": "buy",
            "size": 100.0,
            "price": 50000.0,
        }
    )

    assert isinstance(order, Order)
    assert order.type == "unknown"
    assert order.status == "unknown"


def test_open_order_converts_numeric_strings():
    open_order = _open_order_from_dict(
        {
            "order_id": "xyz",
            "symbol": "ETH-PERP",
            "side": "sell",
            "size": "10.0",
            "price": "3000",
            "timestamp": 1700000000000,
        }
    )

    assert isinstance(open_order, OpenOrder)
    assert open_order.price == 3000.0


def test_result_models_parse():
    close_result = _close_result_from_dict(
        {"symbol": "BTC-PERP", "status": "closed", "message": "ok"}
    )
    tp_sl_result = _tp_sl_result_from_dict({"tp": {"status": "ok"}, "sl": None})
    leverage_result = _leverage_result_from_dict(
        {"symbol": "BTC-PERP", "leverage": 20, "is_cross": True}
    )
    margin_result = _margin_result_from_dict(
        {"symbol": "BTC-PERP", "margin_adjusted": 100.0}
    )

    assert isinstance(close_result, CloseResult)
    assert isinstance(tp_sl_result, TpSlResult)
    assert isinstance(leverage_result, LeverageResult)
    assert isinstance(margin_result, MarginResult)

