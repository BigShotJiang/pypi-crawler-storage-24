from __future__ import annotations

import pytest


@pytest.fixture()
def api_key() -> str:
    return "lq_test_key_abc123def456"


@pytest.fixture()
def api_secret() -> str:
    return "sk_test_secret_xyz789"


@pytest.fixture()
def base_url() -> str:
    return "https://api.liquid.trade"
