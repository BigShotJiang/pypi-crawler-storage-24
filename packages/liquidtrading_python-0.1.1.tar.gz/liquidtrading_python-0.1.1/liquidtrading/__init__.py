"""Liquid Trading SDK — ``from liquidtrading import LiquidClient``."""

from __future__ import annotations

import logging

from .client import Client, LiquidClient
from .constants import SDK_VERSION as __version__
from .errors import (
    AuthenticationError,
    ConnectionError,
    ExchangeError,
    ExpiredTimestampError,
    ForbiddenError,
    GatewayTimeoutError,
    InsufficientBalanceError,
    InsufficientScopeError,
    InvalidApiKeyError,
    InvalidSignatureError,
    IpForbiddenError,
    LiquidError,
    NotFoundError,
    OrderRejectedError,
    RateLimitError,
    ReplayedNonceError,
    ServiceUnavailableError,
    ServerError,
    SymbolNotFoundError,
    TimeoutError,
    ValidationError,
)
from .models import (
    Account,
    Balance,
    Candle,
    CloseResult,
    LeverageResult,
    MarginResult,
    Market,
    OpenOrder,
    Order,
    Orderbook,
    OrderbookLevel,
    Position,
    Ticker,
    TpSlResult,
)

logging.getLogger("liquidtrading").addHandler(logging.NullHandler())

__all__ = [
    "__version__",
    "LiquidClient",
    "Client",
    # Errors
    "LiquidError",
    "AuthenticationError",
    "InvalidApiKeyError",
    "InvalidSignatureError",
    "ExpiredTimestampError",
    "ReplayedNonceError",
    "ForbiddenError",
    "IpForbiddenError",
    "InsufficientScopeError",
    "NotFoundError",
    "SymbolNotFoundError",
    "ValidationError",
    "InsufficientBalanceError",
    "OrderRejectedError",
    "RateLimitError",
    "ServerError",
    "ExchangeError",
    "GatewayTimeoutError",
    "ServiceUnavailableError",
    "TimeoutError",
    "ConnectionError",
    # Models
    "Market",
    "Account",
    "Balance",
    "Candle",
    "CloseResult",
    "LeverageResult",
    "MarginResult",
    "OpenOrder",
    "Order",
    "Orderbook",
    "OrderbookLevel",
    "Position",
    "Ticker",
    "TpSlResult",
]
