"""High-level Liquid Trading API client."""

from __future__ import annotations

from typing import Any

from .constants import (
    DEFAULT_BASE_URL,
    DEFAULT_MAX_RETRIES,
    DEFAULT_TIMEOUT,
    VALID_CANDLE_INTERVALS,
)
from .http import HttpClient
from .models import (
    Account,
    Balance,
    Candle,
    CloseResult,
    LeverageResult,
    MarginResult,
    OpenOrder,
    Order,
    Orderbook,
    Position,
    Ticker,
    TpSlResult,
    _account_from_dict,
    _balance_from_dict,
    _candle_from_dict,
    _close_result_from_dict,
    _leverage_result_from_dict,
    _margin_result_from_dict,
    _open_order_from_dict,
    _order_from_dict,
    _orderbook_from_dict,
    _position_from_dict,
    _ticker_from_dict,
    _tp_sl_result_from_dict,
)


class LiquidClient:
    """Liquid Trading API client.

    Usage::

        from liquidtrading import LiquidClient

        client = LiquidClient(api_key="lq_...", api_secret="sk_...")
        markets = client.get_markets()
    """

    def __init__(
        self,
        api_key: str | None = None,
        api_secret: str | None = None,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = DEFAULT_MAX_RETRIES,
    ) -> None:
        """Initialize the Liquid API client.

        Args:
            api_key: Liquid API key (``lq_...``). Required for all SDK methods.
            api_secret: Liquid API secret (``sk_...``). Required for all SDK methods.
            base_url: API base URL. Defaults to ``https://api.liquid.trade``.
            timeout: Request timeout in seconds. Defaults to 30.
            max_retries: Number of retries for GET requests on 429/5xx.
                Uses exponential backoff with jitter. Defaults to 0 (no retries).
        """
        self._http = HttpClient(
            base_url=base_url,
            api_key=api_key,
            api_secret=api_secret,
            timeout=timeout,
            max_retries=max_retries,
        )

    # --- Market data (read scope) ---

    def get_markets(self) -> list[dict[str, Any]]:
        """List all tradeable markets.

        Requires an API key with **read** scope on the hosted Liquid API.

        Returns:
            List of market dicts with keys: ``symbol``, ``ticker``,
            ``exchange``, ``max_leverage``, ``sz_decimals``.
        """
        return self._http.get("/v1/markets")

    def get_ticker(self, symbol: str) -> Ticker:
        """Get the 24-hour ticker for a symbol.

        Requires an API key with **read** scope.

        Args:
            symbol: Trading pair symbol (e.g. ``"BTC-PERP"``).

        Returns:
            Ticker with ``mark_price``, ``volume_24h``, ``change_24h``,
            ``funding_rate``.

        Raises:
            SymbolNotFoundError: If the symbol does not exist.
        """
        data = self._http.get(f"/v1/markets/{symbol}/ticker")
        return _ticker_from_dict(data)

    def get_orderbook(self, symbol: str, depth: int = 20) -> Orderbook:
        """Get the L2 order book for a symbol.

        Requires an API key with **read** scope on the hosted Liquid API.

        Args:
            symbol: Trading pair symbol (e.g. ``"BTC-PERP"``).
            depth: Number of price levels per side. Defaults to 20.

        Returns:
            An :class:`Orderbook` with ``symbol``, ``bids``, ``asks``,
            and ``timestamp``.

        Raises:
            SymbolNotFoundError: If the symbol does not exist.
        """
        params: dict[str, Any] = {"depth": depth}
        data = self._http.get(f"/v1/markets/{symbol}/orderbook", params=params)
        return _orderbook_from_dict(data)

    def get_candles(
        self,
        symbol: str,
        interval: str = "1h",
        limit: int = 100,
        start: int | None = None,
        end: int | None = None,
    ) -> list[Candle]:
        """Get OHLCV candle data for a symbol.

        Requires an API key with **read** scope on the hosted Liquid API.

        Args:
            symbol: Trading pair symbol (e.g. ``"BTC-PERP"``).
            interval: Candle interval. One of ``"1m"``, ``"5m"``, ``"15m"``,
                ``"30m"``, ``"1h"``, ``"4h"``, ``"1d"``. Defaults to ``"1h"``.
            limit: Maximum number of candles to return. Defaults to 100.
            start: Optional start time as Unix timestamp (seconds).
            end: Optional end time as Unix timestamp (seconds).

        Returns:
            List of :class:`Candle` objects with ``timestamp``, ``open``,
            ``high``, ``low``, ``close``, ``volume``.

        Raises:
            ValueError: If ``interval`` is not a valid candle interval.
            SymbolNotFoundError: If the symbol does not exist.
        """
        if interval not in VALID_CANDLE_INTERVALS:
            raise ValueError(
                f"Invalid interval '{interval}'. Must be one of {VALID_CANDLE_INTERVALS}"
            )
        params: dict[str, Any] = {"interval": interval, "limit": limit}
        if start is not None:
            params["start"] = start
        if end is not None:
            params["end"] = end
        data = self._http.get(f"/v1/markets/{symbol}/candles", params=params)
        return [_candle_from_dict(d) for d in data]

    # --- Account (read scope) ---

    def get_account(self) -> Account:
        """Get account overview.

        Requires an API key with **read** scope.

        Returns:
            An :class:`Account` with ``equity``, ``margin_used``,
            ``available_balance``, ``account_value``.

        Raises:
            AuthenticationError: If credentials are invalid.
            ForbiddenError: If the API key lacks read scope.
        """
        data = self._http.get("/v1/account")
        return _account_from_dict(data)

    def get_balances(self) -> Balance:
        """Get balance breakdown.

        Requires an API key with **read** scope.

        Returns:
            A :class:`Balance` with ``exchange``, ``equity``,
            ``available_balance``, ``margin_used``, ``cross_margin``.

        Raises:
            AuthenticationError: If credentials are invalid.
            ForbiddenError: If the API key lacks read scope.
        """
        data = self._http.get("/v1/account/balances")
        return _balance_from_dict(data)

    def get_positions(self) -> list[Position]:
        """Get all open positions.

        Requires an API key with **read** scope.

        Returns:
            List of :class:`Position` objects with ``symbol``, ``side``,
            ``size``, ``entry_price``, ``leverage``, ``unrealized_pnl``,
            ``mark_price``, ``liquidation_price``, ``margin_used``.

        Raises:
            AuthenticationError: If credentials are invalid.
            ForbiddenError: If the API key lacks read scope.
        """
        data = self._http.get("/v1/account/positions")
        return [_position_from_dict(d) for d in data]

    # --- Orders (trade scope) ---

    def place_order(
        self,
        symbol: str,
        side: str,
        type: str = "market",
        size: float = 0.0,
        leverage: int = 1,
        price: float | None = None,
        tp: float | None = None,
        sl: float | None = None,
        reduce_only: bool = False,
        time_in_force: str = "gtc",
    ) -> Order:
        """Place a new order.

        Requires an API key with **trade** scope.

        Args:
            symbol: Trading pair symbol (e.g. ``"BTC-PERP"``).
            side: Order side — ``"buy"`` or ``"sell"``.
            type: Order type — ``"market"`` or ``"limit"``. Defaults to ``"market"``.
            size: Order size in USD notional. Must be > 0.
            leverage: Leverage multiplier (1–200). Defaults to 1.
            price: Limit price. Required when ``type="limit"``.
            tp: Optional take-profit trigger price.
            sl: Optional stop-loss trigger price.
            reduce_only: If ``True``, the order can only reduce a position.
            time_in_force: ``"gtc"`` (good-til-cancelled) or ``"ioc"``
                (immediate-or-cancel). Defaults to ``"gtc"``.

        Returns:
            An :class:`Order` with the placed order details.

        Raises:
            ValueError: If client-side validation fails (invalid side, size,
                leverage, missing limit price, or invalid time_in_force).
            InsufficientBalanceError: If account balance is too low.
            OrderRejectedError: If the exchange rejects the order.
            SymbolNotFoundError: If the symbol does not exist.
        """
        if side not in ("buy", "sell"):
            raise ValueError("side must be 'buy' or 'sell'")
        if type not in ("market", "limit"):
            raise ValueError("type must be 'market' or 'limit'")
        if size <= 0:
            raise ValueError("size must be > 0")
        if not 1 <= leverage <= 200:
            raise ValueError("leverage must be between 1 and 200")
        if type == "limit" and price is None:
            raise ValueError("price is required for limit orders")
        if time_in_force not in ("gtc", "ioc"):
            raise ValueError("time_in_force must be 'gtc' or 'ioc'")

        body: dict[str, Any] = {
            "symbol": symbol,
            "side": side,
            "type": type,
            "size": size,
            "leverage": leverage,
            "time_in_force": time_in_force,
            "reduce_only": reduce_only,
        }
        if price is not None:
            body["price"] = price
        if tp is not None:
            body["tp"] = tp
        if sl is not None:
            body["sl"] = sl

        data = self._http.post("/v1/orders", json=body)
        return _order_from_dict(data)

    def get_open_orders(self) -> list[OpenOrder]:
        """List all open orders.

        Requires an API key with **read** scope.

        Returns:
            List of :class:`OpenOrder` objects for all open orders.

        Raises:
            AuthenticationError: If credentials are invalid.
        """
        data = self._http.get("/v1/orders")
        return [_open_order_from_dict(d) for d in data]

    def get_order(self, order_id: str) -> Order:
        """Get a specific order by ID.

        Requires an API key with **read** scope.

        Args:
            order_id: The order ID to look up.

        Returns:
            An :class:`Order` with the order details.

        Raises:
            NotFoundError: If the order does not exist.
        """
        data = self._http.get(f"/v1/orders/{order_id}")
        return _order_from_dict(data)

    def cancel_order(self, order_id: str) -> bool:
        """Cancel an open order.

        Requires an API key with **trade** scope.

        Args:
            order_id: The order ID to cancel.

        Returns:
            ``True`` if the order was successfully cancelled.

        Raises:
            NotFoundError: If the order does not exist.
        """
        self._http.delete(f"/v1/orders/{order_id}")
        return True

    def cancel_all_orders(self) -> int:
        """Cancel all open orders.

        Requires an API key with **trade** scope.

        Returns:
            Number of orders cancelled.
        """
        data = self._http.delete("/v1/orders")
        if isinstance(data, list):
            return len(data)
        return 0

    # --- Positions (trade scope) ---

    def close_position(
        self, symbol: str, size: float | None = None,
    ) -> CloseResult:
        """Close an open position entirely or partially.

        Requires an API key with **trade** scope.

        Args:
            symbol: Trading pair symbol (e.g. ``"BTC-PERP"``).
            size: Partial close size in coin units. Omit for full close.

        Returns:
            A :class:`CloseResult` with ``symbol``, ``status``, ``message``.

        Raises:
            ValueError: If ``size`` is <= 0.
            NotFoundError: If no open position exists for the symbol.
        """
        if size is not None and size <= 0:
            raise ValueError("size must be > 0")
        body: dict[str, Any] = {}
        if size is not None:
            body["size"] = size
        data = self._http.post(f"/v1/positions/{symbol}/close", json=body)
        return _close_result_from_dict(data)

    def set_tp_sl(
        self,
        symbol: str,
        tp: float | None = None,
        sl: float | None = None,
    ) -> TpSlResult:
        """Set or update take-profit and/or stop-loss on a position.

        Requires an API key with **trade** scope.

        Args:
            symbol: Trading pair symbol (e.g. ``"BTC-PERP"``).
            tp: Take-profit trigger price. Pass ``None`` to leave unchanged.
            sl: Stop-loss trigger price. Pass ``None`` to leave unchanged.

        Returns:
            A :class:`TpSlResult` with ``tp`` and/or ``sl`` values.

        Raises:
            ValueError: If both ``tp`` and ``sl`` are ``None``.
            NotFoundError: If no open position exists for the symbol.
        """
        if tp is None and sl is None:
            raise ValueError("at least one of tp or sl must be provided")
        body: dict[str, Any] = {}
        if tp is not None:
            body["tp"] = tp
        if sl is not None:
            body["sl"] = sl
        data = self._http.patch(f"/v1/positions/{symbol}/tp-sl", json=body)
        return _tp_sl_result_from_dict(data)

    def update_leverage(
        self, symbol: str, leverage: int, is_cross: bool = False,
    ) -> LeverageResult:
        """Update the leverage for a symbol.

        Requires an API key with **trade** scope.

        Args:
            symbol: Trading pair symbol (e.g. ``"BTC-PERP"``).
            leverage: New leverage multiplier (1–200).
            is_cross: Whether to use cross margin mode. Defaults to
                ``False`` (isolated margin).

        Returns:
            A :class:`LeverageResult` with ``symbol``, ``leverage``,
            ``is_cross``.

        Raises:
            ValueError: If ``leverage`` is outside the 1–200 range.
        """
        if not 1 <= leverage <= 200:
            raise ValueError("leverage must be between 1 and 200")
        data = self._http.patch(
            f"/v1/positions/{symbol}/leverage",
            json={"leverage": leverage, "is_cross": is_cross},
        )
        return _leverage_result_from_dict(data)

    def update_margin(self, symbol: str, amount: float) -> MarginResult:
        """Adjust the isolated margin on a position.

        Requires an API key with **trade** scope.

        Args:
            symbol: Trading pair symbol (e.g. ``"BTC-PERP"``).
            amount: Margin amount to add (positive) or remove (negative).

        Returns:
            A :class:`MarginResult` with ``symbol``, ``margin_adjusted``.
        """
        data = self._http.patch(
            f"/v1/positions/{symbol}/margin", json={"amount": amount},
        )
        return _margin_result_from_dict(data)

    # --- Lifecycle ---

    def close(self) -> None:
        """Close the underlying HTTP client and release connections."""
        self._http.close()

    def __enter__(self) -> LiquidClient:
        """Enter the context manager. Returns ``self``."""
        return self

    def __exit__(self, *args: Any) -> None:
        """Exit the context manager and close the client."""
        self.close()


Client = LiquidClient
