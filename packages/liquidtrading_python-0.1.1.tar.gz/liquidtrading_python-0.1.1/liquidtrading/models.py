"""Frozen dataclasses matching server response shapes."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any


def _to_float(value: object) -> float:
    return float(value)


def _to_float_or_none(value: object) -> float | None:
    return float(value) if value is not None else None


@dataclass(frozen=True)
class Market:
    symbol: str
    ticker: str
    exchange: str
    max_leverage: int | None
    sz_decimals: int | None


@dataclass(frozen=True)
class Ticker:
    symbol: str
    mark_price: float
    volume_24h: float | None
    change_24h: float | None
    funding_rate: float | None


@dataclass(frozen=True)
class OrderbookLevel:
    price: float
    size: float
    count: int


@dataclass(frozen=True)
class Orderbook:
    symbol: str
    bids: tuple[OrderbookLevel, ...]
    asks: tuple[OrderbookLevel, ...]
    timestamp: int | None


@dataclass(frozen=True)
class Candle:
    timestamp: int
    open: float
    high: float
    low: float
    close: float
    volume: float


@dataclass(frozen=True)
class Account:
    equity: float
    margin_used: float
    available_balance: float
    account_value: float


@dataclass(frozen=True)
class Position:
    symbol: str
    side: str
    size: float
    entry_price: float
    leverage: float
    unrealized_pnl: float
    mark_price: float | None
    liquidation_price: float | None
    margin_used: float | None


@dataclass(frozen=True)
class Order:
    order_id: str | None
    symbol: str
    side: str
    type: str
    size: float
    price: float | None
    leverage: int
    status: str
    exchange: str
    tp: float | None
    sl: float | None
    reduce_only: bool
    created_at: str | None


@dataclass(frozen=True)
class OpenOrder:
    order_id: str
    symbol: str
    side: str
    size: float
    price: float
    timestamp: int


@dataclass(frozen=True)
class CloseResult:
    symbol: str
    status: str
    message: str


@dataclass(frozen=True)
class TpSlResult:
    tp: dict[str, Any] | None
    sl: dict[str, Any] | None


@dataclass(frozen=True)
class MarginResult:
    symbol: str
    margin_adjusted: float


@dataclass(frozen=True)
class LeverageResult:
    symbol: str
    leverage: int
    is_cross: bool


@dataclass(frozen=True)
class CrossMargin:
    account_value: float
    total_margin_used: float
    total_ntl_pos: float


@dataclass(frozen=True)
class Balance:
    exchange: str
    equity: float
    available_balance: float
    margin_used: float
    cross_margin: CrossMargin | None


# --- Factory functions ---


def _market_from_dict(d: dict[str, Any]) -> Market:
    return Market(
        symbol=d["symbol"],
        ticker=d["ticker"],
        exchange=d["exchange"],
        max_leverage=d.get("max_leverage"),
        sz_decimals=d.get("sz_decimals"),
    )


def _ticker_from_dict(d: dict[str, Any]) -> Ticker:
    return Ticker(
        symbol=d["symbol"],
        mark_price=_to_float(d["mark_price"]),
        volume_24h=_to_float_or_none(d.get("volume_24h")),
        change_24h=_to_float_or_none(d.get("change_24h")),
        funding_rate=_to_float_or_none(d.get("funding_rate")),
    )


def _orderbook_level_from_dict(d: dict[str, Any]) -> OrderbookLevel:
    return OrderbookLevel(
        price=_to_float(d["price"]),
        size=_to_float(d["size"]),
        count=d.get("count", 1),
    )


def _orderbook_from_dict(d: dict[str, Any]) -> Orderbook:
    return Orderbook(
        symbol=d["symbol"],
        bids=tuple(_orderbook_level_from_dict(b) for b in d["bids"]),
        asks=tuple(_orderbook_level_from_dict(a) for a in d["asks"]),
        timestamp=d.get("timestamp"),
    )


def _candle_from_dict(d: dict[str, Any]) -> Candle:
    return Candle(
        timestamp=d["timestamp"],
        open=_to_float(d["open"]),
        high=_to_float(d["high"]),
        low=_to_float(d["low"]),
        close=_to_float(d["close"]),
        volume=_to_float(d["volume"]),
    )


def _account_from_dict(d: dict[str, Any]) -> Account:
    return Account(
        equity=_to_float(d["equity"]),
        margin_used=_to_float(d["margin_used"]),
        available_balance=_to_float(d["available_balance"]),
        account_value=_to_float(d["account_value"]),
    )


def _position_from_dict(d: dict[str, Any]) -> Position:
    return Position(
        symbol=d["symbol"],
        side=d["side"],
        size=_to_float(d["size"]),
        entry_price=_to_float(d["entry_price"]),
        leverage=_to_float(d["leverage"]),
        unrealized_pnl=_to_float(d["unrealized_pnl"]),
        mark_price=_to_float_or_none(d.get("mark_price")),
        liquidation_price=_to_float_or_none(d.get("liquidation_price")),
        margin_used=_to_float_or_none(d.get("margin_used")),
    )


def _order_from_dict(d: dict[str, Any]) -> Order:
    return Order(
        order_id=d.get("order_id"),
        symbol=d["symbol"],
        side=d["side"],
        type=d.get("type", "unknown"),
        size=d.get("size", 0.0),
        price=d.get("price"),
        leverage=d.get("leverage", 1),
        status=d.get("status", "unknown"),
        exchange=d.get("exchange", "hyperliquid"),
        tp=d.get("tp"),
        sl=d.get("sl"),
        reduce_only=d.get("reduce_only", False),
        created_at=d.get("created_at"),
    )


def _open_order_from_dict(d: dict[str, Any]) -> OpenOrder:
    return OpenOrder(
        order_id=d["order_id"],
        symbol=d["symbol"],
        side=d["side"],
        size=_to_float(d["size"]),
        price=_to_float(d["price"]),
        timestamp=d["timestamp"],
    )


def _close_result_from_dict(d: dict[str, Any]) -> CloseResult:
    return CloseResult(
        symbol=d["symbol"],
        status=d["status"],
        message=d["message"],
    )


def _tp_sl_result_from_dict(d: dict[str, Any]) -> TpSlResult:
    return TpSlResult(tp=d.get("tp"), sl=d.get("sl"))


def _margin_result_from_dict(d: dict[str, Any]) -> MarginResult:
    return MarginResult(
        symbol=d["symbol"],
        margin_adjusted=d["margin_adjusted"],
    )


def _leverage_result_from_dict(d: dict[str, Any]) -> LeverageResult:
    return LeverageResult(
        symbol=d["symbol"],
        leverage=d["leverage"],
        is_cross=d["is_cross"],
    )


def _cross_margin_from_dict(d: dict[str, Any]) -> CrossMargin:
    return CrossMargin(
        account_value=_to_float(d["account_value"]),
        total_margin_used=_to_float(d["total_margin_used"]),
        total_ntl_pos=_to_float(d["total_ntl_pos"]),
    )


def _balance_from_dict(d: dict[str, Any]) -> Balance:
    cm = d.get("cross_margin")
    return Balance(
        exchange=d["exchange"],
        equity=_to_float(d["equity"]),
        available_balance=_to_float(d["available_balance"]),
        margin_used=_to_float(d["margin_used"]),
        cross_margin=_cross_margin_from_dict(cm) if isinstance(cm, dict) else None,
    )
