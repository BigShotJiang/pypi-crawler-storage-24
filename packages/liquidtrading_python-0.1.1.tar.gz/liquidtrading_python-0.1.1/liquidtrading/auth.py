"""HMAC-SHA256 request signing — mirrors liquidserver/public_api/middleware/auth.py."""

from __future__ import annotations

import hashlib
import hmac
import json
import secrets
import time
from urllib.parse import parse_qsl, quote, urlparse

from .constants import (
    HEADER_NONCE,
    HEADER_SIGNATURE,
    HEADER_TIMESTAMP,
)


def canonicalize_path(path: str) -> str:
    """Normalize a URL path for HMAC signing.

    Strips trailing slashes, lowercases the path, and removes any query
    string component. Returns ``"/"`` for empty paths.

    Args:
        path: The raw request path, e.g. ``"/v1/Orders/?foo=bar"``.

    Returns:
        Canonical path string, e.g. ``"/v1/orders"``.
    """
    parsed = urlparse(path)
    clean = parsed.path.rstrip("/").lower()
    return clean if clean else "/"


def canonicalize_query(query_string: str) -> str:
    """Sort query parameters alphabetically for deterministic signing.

    Parses the query string, sorts by ``(key, value)`` tuples, and
    re-encodes as ``key=value&...``. Returns ``""`` for empty input.

    Args:
        query_string: Raw query string without leading ``?``.

    Returns:
        Sorted, canonicalized query string.
    """
    if not query_string:
        return ""
    params = parse_qsl(query_string, keep_blank_values=True)
    sorted_params = sorted(params, key=lambda x: (x[0], x[1]))
    return "&".join(
        f"{quote(k, safe='-_.~')}={quote(v, safe='-_.~')}"
        for k, v in sorted_params
    )


def compute_body_hash(body: bytes | None) -> str:
    """Compute SHA-256 hash of the request body for HMAC signing.

    If the body is valid JSON, it is first canonicalized (sorted keys,
    compact separators) to ensure deterministic hashing regardless of
    key ordering. Non-JSON bodies are hashed as-is. ``None`` or empty
    bodies hash the empty byte string.

    Args:
        body: Raw request body bytes, or ``None``.

    Returns:
        Hex-encoded SHA-256 digest.
    """
    if body is None or len(body) == 0:
        return hashlib.sha256(b"").hexdigest()

    try:
        parsed = json.loads(body)
        canonical = json.dumps(parsed, separators=(",", ":"), sort_keys=True).encode()
        return hashlib.sha256(canonical).hexdigest()
    except (json.JSONDecodeError, UnicodeDecodeError):
        return hashlib.sha256(body).hexdigest()


def compute_signature(
    secret: str,
    timestamp: str,
    nonce: str,
    method: str,
    path: str,
    query: str,
    body_hash: str,
) -> str:
    """Compute the HMAC-SHA256 signature for a request.

    Constructs a newline-delimited message from the request components
    and signs it with the API secret. The message format is::

        {timestamp}\\n{nonce}\\n{METHOD}\\n{path}\\n{query}\\n{body_hash}

    Args:
        secret: The API secret (``sk_...``).
        timestamp: Millisecond Unix timestamp string.
        nonce: Unique request nonce.
        method: HTTP method (uppercased).
        path: Canonicalized request path.
        query: Canonicalized query string.
        body_hash: SHA-256 hex digest of the canonical body.

    Returns:
        Hex-encoded HMAC-SHA256 signature.
    """
    message = f"{timestamp}\n{nonce}\n{method.upper()}\n{path}\n{query}\n{body_hash}"
    return hmac.new(
        secret.encode("utf-8"),
        message.encode("utf-8"),
        hashlib.sha256,
    ).hexdigest()


def generate_nonce() -> str:
    """Generate a cryptographically random 32-character hex nonce.

    Satisfies the server's nonce pattern ``^[a-zA-Z0-9_-]{8,64}$``.

    Returns:
        A 32-character hex string.
    """
    return secrets.token_hex(16)


def generate_timestamp() -> str:
    """Return the current UTC time as a millisecond Unix timestamp string.

    Returns:
        Millisecond timestamp, e.g. ``"1709654400000"``.
    """
    return str(int(time.time() * 1000))


def sign_request(
    api_secret: str,
    method: str,
    path: str,
    query_string: str,
    body: bytes | None,
) -> dict[str, str]:
    """Sign an HTTP request and return the authentication headers.

    Generates a timestamp and nonce, canonicalizes the path/query/body,
    computes the HMAC-SHA256 signature, and returns a dict containing
    ``X-Liquid-Timestamp``, ``X-Liquid-Nonce``, and ``X-Liquid-Signature``.

    Args:
        api_secret: The API secret (``sk_...``).
        method: HTTP method (e.g. ``"GET"``, ``"POST"``).
        path: Request path (e.g. ``"/v1/orders"``).
        query_string: Raw query string without leading ``?``.
        body: Raw request body bytes, or ``None``.

    Returns:
        Dict with the three HMAC auth headers.
    """
    timestamp = generate_timestamp()
    nonce = generate_nonce()
    canonical_path = canonicalize_path(path)
    canonical_query = canonicalize_query(query_string)
    body_hash = compute_body_hash(body)

    signature = compute_signature(
        secret=api_secret,
        timestamp=timestamp,
        nonce=nonce,
        method=method.upper(),
        path=canonical_path,
        query=canonical_query,
        body_hash=body_hash,
    )

    return {
        HEADER_TIMESTAMP: timestamp,
        HEADER_NONCE: nonce,
        HEADER_SIGNATURE: signature,
    }
