from __future__ import annotations


class LiquidError(Exception):
    """Base exception for all Liquid SDK errors.

    Attributes:
        code: Machine-readable error code (e.g. ``"INVALID_SIGNATURE"``).
        message: Human-readable error description.
        status_code: HTTP status code, or ``None`` for client-side errors.
    """

    def __init__(self, code: str, message: str, status_code: int | None = None) -> None:
        self.code = code
        self.message = message
        self.status_code = status_code
        super().__init__(f"[{code}] {message}")


# --- Authentication (401) ---

class AuthenticationError(LiquidError):
    """Raised on 401 responses."""


class InvalidApiKeyError(AuthenticationError):
    """Raised when error code is INVALID_API_KEY."""


class InvalidSignatureError(AuthenticationError):
    """Raised when error code is INVALID_SIGNATURE."""


class ExpiredTimestampError(AuthenticationError):
    """Raised when error code is EXPIRED_TIMESTAMP."""


class ReplayedNonceError(AuthenticationError):
    """Raised when error code is REPLAYED_NONCE."""


# --- Forbidden (403) ---

class ForbiddenError(LiquidError):
    """Raised on 403 responses."""


class IpForbiddenError(ForbiddenError):
    """Raised when error code is IP_FORBIDDEN."""


class InsufficientScopeError(ForbiddenError):
    """Raised when error code is INSUFFICIENT_SCOPE."""


# --- Not Found (404) ---

class NotFoundError(LiquidError):
    """Raised on 404 responses."""


class SymbolNotFoundError(NotFoundError):
    """Raised when a trading symbol is not found."""


# --- Validation (400/422) ---

class ValidationError(LiquidError):
    """Raised on 400/422 responses."""


class InsufficientBalanceError(ValidationError):
    """Raised when error code is INSUFFICIENT_BALANCE."""


class OrderRejectedError(ValidationError):
    """Raised when error code is ORDER_REJECTED."""


# --- Rate Limit (429) ---

class RateLimitError(LiquidError):
    """Raised on 429 responses when the rate limit is exceeded.

    Attributes:
        retry_after: Seconds to wait before retrying, from the
            ``Retry-After`` header. ``None`` if the header was absent.
    """

    def __init__(
        self,
        code: str,
        message: str,
        status_code: int | None = None,
        retry_after: float | None = None,
    ) -> None:
        super().__init__(code=code, message=message, status_code=status_code)
        self.retry_after = retry_after


# --- Server (5xx) ---

class ServerError(LiquidError):
    """Raised on 500 responses."""


class ExchangeError(LiquidError):
    """Raised on 502 responses (upstream exchange failure)."""


class GatewayTimeoutError(LiquidError):
    """Raised on 504 responses (server-side timeout)."""


class ServiceUnavailableError(LiquidError):
    """Raised on 503 responses."""


# --- Transport (client-side) ---

class TimeoutError(LiquidError):
    """Raised when the HTTP client times out (client-side)."""

    def __init__(self, message: str = "Request timed out") -> None:
        super().__init__(code="TIMEOUT", message=message, status_code=None)


class ConnectionError(LiquidError):
    """Raised when the HTTP client cannot connect."""

    def __init__(self, message: str = "Connection failed") -> None:
        super().__init__(code="CONNECTION_ERROR", message=message, status_code=None)


# --- Error code → exception mappings ---

_CODE_MAP: dict[str, type[LiquidError]] = {
    # Auth (401)
    "MISSING_AUTH_HEADERS": AuthenticationError,
    "INVALID_API_KEY": InvalidApiKeyError,
    "INVALID_SIGNATURE": InvalidSignatureError,
    "EXPIRED_TIMESTAMP": ExpiredTimestampError,
    "INVALID_TIMESTAMP": AuthenticationError,
    "INVALID_NONCE": AuthenticationError,
    "REPLAYED_NONCE": ReplayedNonceError,
    # Forbidden (403)
    "IP_FORBIDDEN": IpForbiddenError,
    "INSUFFICIENT_SCOPE": InsufficientScopeError,
    # Validation (400/422)
    "VALIDATION_ERROR": ValidationError,
    "BAD_REQUEST": ValidationError,
    "INSUFFICIENT_BALANCE": InsufficientBalanceError,
    "ORDER_REJECTED": OrderRejectedError,
    # Not Found (404)
    "NOT_FOUND": NotFoundError,
    "SYMBOL_NOT_FOUND": SymbolNotFoundError,
    # Rate Limit (429)
    "RATE_LIMIT_EXCEEDED": RateLimitError,
    # Server (5xx)
    "INTERNAL_ERROR": ServerError,
    "AUTH_UNAVAILABLE": ServiceUnavailableError,
    "TIMEOUT": GatewayTimeoutError,
}

_STATUS_FALLBACK: dict[int, type[LiquidError]] = {
    400: ValidationError,
    401: AuthenticationError,
    403: ForbiddenError,
    404: NotFoundError,
    422: ValidationError,
    429: RateLimitError,
    500: ServerError,
    502: ExchangeError,
    503: ServiceUnavailableError,
    504: GatewayTimeoutError,
}


def error_from_response(
    status_code: int,
    code: str,
    message: str,
    headers: dict[str, str],
) -> LiquidError:
    """Map an API error response to the appropriate exception class.

    Checks the error ``code`` first for the most specific match, then
    falls back to ``status_code``. For 429 responses, extracts
    ``Retry-After`` from headers.

    Args:
        status_code: HTTP status code from the response.
        code: Machine-readable error code from the response body.
        message: Human-readable error message from the response body.
        headers: Response headers dict.

    Returns:
        The appropriate :class:`LiquidError` subclass instance.
    """
    if status_code == 429:
        raw = headers.get("Retry-After") or headers.get("retry-after")
        retry_after = float(raw) if raw is not None else None
        return RateLimitError(
            code=code, message=message, status_code=429, retry_after=retry_after,
        )

    cls = _CODE_MAP.get(code) or _STATUS_FALLBACK.get(status_code, LiquidError)
    return cls(code=code, message=message, status_code=status_code)
