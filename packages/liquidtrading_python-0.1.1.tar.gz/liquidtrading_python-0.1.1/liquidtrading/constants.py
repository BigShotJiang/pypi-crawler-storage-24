from __future__ import annotations

DEFAULT_BASE_URL = "https://api.liquid.trade"
DEFAULT_TIMEOUT = 30.0
DEFAULT_MAX_RETRIES = 0
DEFAULT_RETRY_BACKOFF = 0.5
SDK_VERSION = "0.1.1"
SDK_PACKAGE_NAME = "liquidtrading-python"

HEADER_API_KEY = "X-Liquid-Key"
HEADER_SIGNATURE = "X-Liquid-Signature"
HEADER_TIMESTAMP = "X-Liquid-Timestamp"
HEADER_NONCE = "X-Liquid-Nonce"

VALID_CANDLE_INTERVALS = ("1m", "5m", "15m", "30m", "1h", "4h", "1d")
