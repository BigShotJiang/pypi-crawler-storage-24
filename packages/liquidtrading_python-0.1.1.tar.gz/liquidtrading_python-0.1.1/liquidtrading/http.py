"""HTTP client wrapping httpx with signing, envelope unwrapping, and retries."""

from __future__ import annotations

import logging
import random
import time
from typing import Any

import httpx

from .auth import sign_request
from .constants import (
    DEFAULT_MAX_RETRIES,
    DEFAULT_RETRY_BACKOFF,
    DEFAULT_TIMEOUT,
    HEADER_API_KEY,
    SDK_PACKAGE_NAME,
    SDK_VERSION,
)
from .errors import (
    ConnectionError,
    LiquidError,
    TimeoutError,
    error_from_response,
)

logger = logging.getLogger("liquidtrading.http")


class HttpClient:
    """Low-level HTTP client with HMAC signing, envelope unwrapping, and retry logic.

    Wraps ``httpx.Client`` to automatically sign requests, unwrap the
    ``{"success": ..., "data": ...}`` API envelope, and optionally retry
    transient failures on GET requests with exponential backoff.
    """

    def __init__(
        self,
        base_url: str,
        api_key: str | None = None,
        api_secret: str | None = None,
        timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = DEFAULT_MAX_RETRIES,
    ) -> None:
        """Initialize the HTTP client.

        Args:
            base_url: API base URL (e.g. ``"https://api.liquid.trade"``).
            api_key: Liquid API key (``lq_...``). Omit for public endpoints.
            api_secret: Liquid API secret (``sk_...``). Omit for public endpoints.
            timeout: Request timeout in seconds.
            max_retries: Number of retries for GET requests on 429/5xx errors.
        """
        self._base_url = base_url.rstrip("/")
        self._api_key = api_key
        self._api_secret = api_secret
        self._max_retries = max_retries
        self._client = httpx.Client(
            base_url=self._base_url,
            timeout=timeout,
            headers={"User-Agent": f"{SDK_PACKAGE_NAME}/{SDK_VERSION}"},
        )

    def get(self, path: str, params: dict[str, Any] | None = None) -> Any:
        """Send a signed GET request and return the unwrapped response data.

        Args:
            path: API path (e.g. ``"/v1/markets"``).
            params: Optional query parameters.

        Returns:
            Parsed response data from the API envelope.

        Raises:
            LiquidError: On API error responses.
            TimeoutError: On request timeout.
            ConnectionError: On connection failure.
        """
        return self._request("GET", path, params=params)

    def post(self, path: str, json: dict[str, Any] | None = None) -> Any:
        """Send a signed POST request and return the unwrapped response data.

        Args:
            path: API path (e.g. ``"/v1/orders"``).
            json: Optional JSON request body.

        Returns:
            Parsed response data from the API envelope.

        Raises:
            LiquidError: On API error responses.
        """
        return self._request("POST", path, json=json)

    def delete(self, path: str) -> Any:
        """Send a signed DELETE request and return the unwrapped response data.

        Args:
            path: API path (e.g. ``"/v1/orders/abc123"``).

        Returns:
            Parsed response data from the API envelope.

        Raises:
            LiquidError: On API error responses.
        """
        return self._request("DELETE", path)

    def patch(self, path: str, json: dict[str, Any] | None = None) -> Any:
        """Send a signed PATCH request and return the unwrapped response data.

        Args:
            path: API path (e.g. ``"/v1/positions/BTC-PERP/leverage"``).
            json: Optional JSON request body.

        Returns:
            Parsed response data from the API envelope.

        Raises:
            LiquidError: On API error responses.
        """
        return self._request("PATCH", path, json=json)

    def close(self) -> None:
        """Close the underlying httpx client and release connections."""
        self._client.close()

    def _request(
        self,
        method: str,
        path: str,
        params: dict[str, Any] | None = None,
        json: dict[str, Any] | None = None,
    ) -> Any:
        headers = self._build_auth_headers(method, path, params, json)
        retryable = method == "GET" and self._max_retries > 0
        last_error: LiquidError | None = None

        attempts = 1 + (self._max_retries if retryable else 0)
        for attempt in range(attempts):
            try:
                response = self._client.request(
                    method, path, params=params, json=json, headers=headers,
                )
            except httpx.TimeoutException as exc:
                raise TimeoutError(message=str(exc)) from exc
            except httpx.ConnectError as exc:
                raise ConnectionError(message=str(exc)) from exc

            logger.debug(
                "%s %s -> %s", method, path, response.status_code,
            )

            if response.status_code == 200:
                return self._unwrap(response)

            error = self._parse_error(response)

            if retryable and response.status_code in (429, 500, 502, 503, 504):
                last_error = error
                if attempt < attempts - 1:
                    self._backoff(attempt, response)
                    continue

            raise error

        if last_error is not None:
            raise last_error

        raise LiquidError(code="UNKNOWN", message="Unexpected retry exhaustion")  # pragma: no cover

    def _build_auth_headers(
        self,
        method: str,
        path: str,
        params: dict[str, Any] | None,
        json_body: dict[str, Any] | None,
    ) -> dict[str, str]:
        if self._api_key is None or self._api_secret is None:
            return {}

        query_string = "&".join(f"{k}={v}" for k, v in params.items()) if params else ""

        body: bytes | None = None
        if json_body is not None:
            import json as _json
            body = _json.dumps(json_body).encode()

        auth_headers = sign_request(
            api_secret=self._api_secret,
            method=method,
            path=path,
            query_string=query_string,
            body=body,
        )
        auth_headers[HEADER_API_KEY] = self._api_key
        return auth_headers

    def _unwrap(self, response: httpx.Response) -> Any:
        data = response.json()
        if isinstance(data, dict) and "success" in data:
            if data["success"]:
                return data.get("data")
            error_detail = data.get("error", {})
            raise error_from_response(
                status_code=response.status_code,
                code=error_detail.get("code", "UNKNOWN"),
                message=error_detail.get("message", "Unknown error"),
                headers=dict(response.headers),
            )
        return data

    def _parse_error(self, response: httpx.Response) -> LiquidError:
        try:
            data = response.json()
            error_detail = data.get("error", {}) if isinstance(data, dict) else {}
        except Exception:
            error_detail = {}

        return error_from_response(
            status_code=response.status_code,
            code=error_detail.get("code", "UNKNOWN"),
            message=error_detail.get("message", f"HTTP {response.status_code}"),
            headers=dict(response.headers),
        )

    def _backoff(self, attempt: int, response: httpx.Response) -> None:
        retry_after = response.headers.get("Retry-After")
        if retry_after is not None:
            delay = float(retry_after)
        else:
            delay = DEFAULT_RETRY_BACKOFF * (2 ** attempt)
        jitter = random.uniform(0, delay * 0.1)  # noqa: S311
        time.sleep(delay + jitter)
