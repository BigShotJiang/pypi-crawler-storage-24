"""Simple demo entrypoint for validating SDK connectivity."""

from __future__ import annotations

import argparse
import json
import os
from typing import Any

from .client import LiquidClient
from .errors import LiquidError


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Run a safe SDK demo against the Liquid Public API.",
    )
    parser.add_argument(
        "--base-url",
        default=os.environ.get("LIQUID_API_URL", "http://localhost:8001"),
        help="Liquid Public API base URL",
    )
    parser.add_argument(
        "--api-key",
        default=os.environ.get("LIQUID_API_KEY"),
        help="Liquid API key (or set LIQUID_API_KEY)",
    )
    parser.add_argument(
        "--api-secret",
        default=os.environ.get("LIQUID_API_SECRET"),
        help="Liquid API secret (or set LIQUID_API_SECRET)",
    )
    parser.add_argument(
        "--symbol",
        default="BTC-PERP",
        help="Market symbol to inspect",
    )
    parser.add_argument(
        "--include-open-orders",
        action="store_true",
        help="Also fetch open orders. This may fail on accounts that have not initialized trading yet.",
    )
    return parser


def _print_section(title: str, payload: Any) -> None:
    print(f"\n=== {title} ===")
    print(json.dumps(payload, indent=2, default=str))


def _run_section(title: str, fn: Any) -> None:
    try:
        payload = fn()
    except LiquidError as exc:
        _print_section(
            title,
            {
                "error": exc.code,
                "message": exc.message,
                "status_code": exc.status_code,
            },
        )
        return

    _print_section(title, payload)


def main() -> None:
    args = _build_parser().parse_args()
    if not args.api_key or not args.api_secret:
        raise SystemExit(
            "Missing credentials. Pass --api-key/--api-secret or set "
            "LIQUID_API_KEY and LIQUID_API_SECRET."
        )

    with LiquidClient(
        api_key=args.api_key,
        api_secret=args.api_secret,
        base_url=args.base_url,
    ) as client:
        _run_section("Markets", lambda: client.get_markets()[:5])
        _run_section("Ticker", lambda: client.get_ticker(args.symbol))
        _run_section("Orderbook", lambda: client.get_orderbook(args.symbol, depth=5))
        _run_section("Account", client.get_account)
        _run_section("Positions", client.get_positions)
        if args.include_open_orders:
            _run_section("Open Orders", client.get_open_orders)


if __name__ == "__main__":
    main()
