# Publishing `liquidtrading-python`

This package is set up to publish as:

- package name: `liquidtrading-python`
- canonical import path: `from liquidtrading import LiquidClient`
- legacy compatibility import: `from liquid import Client`
- console scripts: `liquidtrading-demo` (primary) and `liquid-demo` (compatibility)

## One-time setup

1. Create accounts on both [PyPI](https://pypi.org/) and [TestPyPI](https://test.pypi.org/).
2. Verify the email address on both sites.
3. Confirm that the name `liquidtrading-python` is still available on both indexes before you publish. If it is already taken, pick a different package name before going further.
4. In GitHub, create two repository environments:
   - `testpypi`
   - `pypi`
5. In TestPyPI, create a pending GitHub trusted publisher for project `liquidtrading-python` with:
   - owner: your GitHub org or username
   - repository: this repository
   - workflow filename: `.github/workflows/publish-liquidtrading-python.yml`
   - environment: `testpypi`
6. In PyPI, create the same pending trusted publisher, but set the environment to `pypi`.

Pending publishers let the first successful upload create the project. They do not reserve the name until that first publish succeeds.

## Release flow

### 1. Update the version

Edit [pyproject.toml](/Users/raymondcosgrove/Liquid/Public%20Apis/liquidtrading-python/pyproject.toml) and bump:

```toml
version = "0.1.1"
```

### 2. Run the SDK tests

From the repo root:

```bash
PYTHONPATH=. .venv/bin/python -m pytest \
  tests/test_auth.py \
  tests/test_client.py \
  tests/test_demo.py \
  tests/test_errors.py \
  tests/test_models.py \
  tests/test_package_exports.py -q
```

### 3. Publish to TestPyPI

In GitHub Actions, run the `Publish liquidtrading-python` workflow manually. That will:

- build the package from this repository
- run import smoke tests against both the wheel and source distribution
- publish to TestPyPI using GitHub Trusted Publishing

### 4. Verify the TestPyPI package

After the workflow succeeds:

```bash
python3 -m venv /tmp/liquidtrading-python-test
source /tmp/liquidtrading-python-test/bin/activate
python -m pip install --upgrade pip
python -m pip install --index-url https://test.pypi.org/simple/ --extra-index-url https://pypi.org/simple/ liquidtrading-python
python -c "from liquidtrading import LiquidClient; print(LiquidClient)"
```

### 5. Publish to real PyPI

Create and push a tag that starts with `liquidtrading-python-v`:

```bash
git tag -a liquidtrading-python-v0.1.1 -m "liquidtrading-python v0.1.1"
git push origin liquidtrading-python-v0.1.1
```

That tag triggers the same workflow, but publishes to PyPI instead of TestPyPI.

### 6. Verify the real package

```bash
python3 -m venv /tmp/liquidtrading-python-prod
source /tmp/liquidtrading-python-prod/bin/activate
python -m pip install --upgrade pip
python -m pip install liquidtrading-python
python -c "from liquidtrading import LiquidClient; print(LiquidClient)"
```

## Fallback manual publish

If you do not want to use Trusted Publishing, you can publish with an API token instead:

```bash
cd /path/to/liquidtrading-python
python3 -m pip install --upgrade build twine
python3 -m build
python3 -m twine upload --repository testpypi dist/*
python3 -m twine upload dist/*
```

Use a project-scoped API token when prompted.
