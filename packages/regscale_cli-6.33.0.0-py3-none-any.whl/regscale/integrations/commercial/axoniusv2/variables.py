"""Axonius V2 configuration reader.

Reads flat keys from init.yaml (e.g. ``axoniusApiKey``, ``axoniusUrl``).
"""

import logging
from typing import Any

from regscale.core.app.utils.config_utils import get_integration_config
from regscale.core.app.utils.variables import RsVariableType

logger = logging.getLogger("regscale")


class AxoniusVariables:
    """Axonius V2 configuration variables.

    Declares configuration fields using :class:`RsVariableType` annotations so
    that the AST-based secret extractor in rs-am2 can discover required secrets
    without executing the module.  Runtime config loading is still handled by
    :func:`get_axonius_config` below.
    """

    axoniusUrl: RsVariableType(  # type: ignore[valid-type]
        str,
        "YOUR_AXONIUS_URL",
        required=True,
    )
    axoniusApiKey: RsVariableType(  # type: ignore[valid-type]
        str,
        "YOUR_AXONIUS_V2_API_KEY",
        required=True,
        sensitive=True,
    )
    axoniusApiSecret: RsVariableType(  # type: ignore[valid-type]
        str,
        "YOUR_AXONIUS_V2_API_SECRET",
        required=True,
        sensitive=True,
    )
    axoniusVerifySsl: RsVariableType(  # type: ignore[valid-type]
        bool,
        "True",
        required=False,
        default=True,
    )
    axoniusTimeout: RsVariableType(  # type: ignore[valid-type]
        int,
        "120",
        required=False,
        default=120,
    )
    axoniusPageSize: RsVariableType(  # type: ignore[valid-type]
        int,
        "2000",
        required=False,
        default=2000,
    )


_DEFAULTS = {
    "url": "YOUR_AXONIUS_URL",
    "apiKey": "YOUR_AXONIUS_V2_API_KEY",
    "apiSecret": "YOUR_AXONIUS_V2_API_SECRET",
    "verifySsl": True,
    "timeout": 120,
    "pageSize": 2000,
    "savedQueryConfig": {
        "queryName": "RegScale Default Query",
        "queryDescription": "Default query used by RegScale for asset retrieval. Modify or replace as needed.",
    },
    "stateDir": "./artifacts/axonius",
}


def get_axonius_config() -> dict[str, Any]:
    """Return the Axonius configuration from init.yaml flat keys.

    Reads flat keys like ``axoniusApiKey``, ``axoniusUrl``, etc. via
    :func:`get_integration_config` which strips the ``axonius`` prefix.

    Falls back to compiled defaults for any missing keys.

    :return: Merged axonius configuration dictionary.
    :rtype: dict[str, Any]
    """
    from regscale.core.app.application import Application

    app = Application()
    cfg = get_integration_config(app.config, "axonius")
    if not isinstance(cfg, dict):
        cfg = {}

    merged = {**_DEFAULTS, **cfg}

    # Fall back to 'host' if 'url' is not configured (backward compat)
    if merged.get("url") in (None, "", _DEFAULTS["url"]) and merged.get("host"):
        merged["url"] = merged["host"]

    return merged
