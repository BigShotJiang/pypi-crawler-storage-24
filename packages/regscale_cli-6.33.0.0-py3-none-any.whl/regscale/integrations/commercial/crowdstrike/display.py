#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""CrowdStrike Rich console display helpers for incident tables."""

import logging
from enum import Enum

from rich.console import Console
from rich.table import Table

from regscale.core.app.utils.app_utils import error_and_exit
from regscale.integrations.commercial.crowdstrike.sdk import get_user_detail

logger = logging.getLogger("regscale")
console = Console()


class Status(Enum):
    """Enum used to describe status values."""

    NEW = 20
    REOPENED = 25
    INPROGRESS = 30
    CLOSED = 40


class StatusColor(Enum):
    """Enum to describe colors used for status displays."""

    NEW = "[cornsilk1]"
    REOPENED = "[bright_yellow]"
    INPROGRESS = "[deep_sky_blue1]"
    CLOSED = "[bright_green]"


def status_information(inc_data: dict) -> str:
    """
    Parse status information for tabular display.

    :param dict inc_data: Incident data to parse
    :return: Status information
    :rtype: str
    """
    inc_status = [
        f"{StatusColor[Status(inc_data['status']).name].value}"
        f"{Status(inc_data['status']).name.title().replace('Inp', 'InP')}[/]"
    ]
    tag_list = inc_data.get("tags", [])
    if tag_list:
        inc_status.append(" ")
        tag_list = [f"[magenta]{tg}[/]" for tg in tag_list]
        inc_status.extend(tag_list)

    return "\n".join(inc_status)


def incident_information(inc_data: dict) -> str:
    """
    Parse incident overview information for tabular display.

    :param dict inc_data: Incident data to parse
    :return: Incident overview information
    :rtype: str
    """
    inc_info = []
    inc_info.append(inc_data.get("name", ""))
    inc_info.append(f"[bold]{inc_data['incident_id'].split(':')[2]}[/]")
    inc_info.append(f"Start: {inc_data.get('start', 'Unknown').replace('T', ' ')}")
    inc_info.append(f"  End: {inc_data.get('end', 'Unknown').replace('T', ' ')}")
    if assigned := inc_data.get("assigned_to"):
        inc_info.append("\n[underline]Assignment[/]")
        inc_info.append(get_user_detail(assigned))
    if inc_data.get("description"):
        inc_info.append(" ")
        inc_info.append(chunk_long_description(inc_data["description"], 50))

    return "\n".join(inc_info)


def chunk_long_description(desc: str, col_width: int) -> str:
    """
    Chunk a long string by delimiting with CR based upon column length.

    :param str desc: Description to parse
    :param int col_width: Column width to chunk by
    :return: Chunked description
    :rtype: str
    """
    desc_chunks = []
    chunk = ""
    for word in desc.split():
        new_chunk = f"{chunk}{word.strip()} "
        if len(new_chunk) >= col_width:
            desc_chunks.append(new_chunk)
            chunk = ""
        else:
            chunk = new_chunk

    delim = "\n"
    desc_chunks.append(chunk)

    return delim.join(desc_chunks)


def hosts_information(inc_data: dict) -> str:
    """
    Parse hosts information for tabular display.

    :param dict inc_data: Incident data to parse
    :return: Host information
    :rtype: str
    """
    returned = ""
    if "hosts" in inc_data:
        host_str = []
        for host in inc_data["hosts"]:
            host_info = []
            host_info.append(
                f"<strong>{host.get('hostname', 'Unidentified')}</strong>"
                f" ({host.get('platform_name', 'Not available')})"
            )
            host_info.append(f"<span style='color:cyan'>{host.get('device_id', 'Not available')}</span>")
            host_info.append(f"  Int: {host.get('local_ip', 'Not available')}")
            host_info.append(f"  Ext: {host.get('external_ip', 'Not available')}")
            first = host.get("first_seen", "Unavailable").replace("T", " ").replace("Z", " ")
            host_info.append(f"First: {first}")
            last = host.get("last_seen", "Unavailable").replace("T", " ").replace("Z", " ")
            host_info.append(f" Last: {last}")
            host_str.append("\n".join(host_info))
        if host_str:
            returned = "\n".join(host_str)
        else:
            returned = "Unidentified"

    return returned


def show_incident_table(incident_listing: list) -> None:
    """
    Display all returned incidents in tabular fashion.

    :param list incident_listing: List of incidents to parse and print to console
    :raises General Error: If incident_listing is empty
    :rtype: None
    """
    if not incident_listing:
        error_and_exit("No incidents found, code 404")
    table = Table(show_header=True, header_style="bold magenta", title="Incidents")
    headers = {
        "status": "[bold]Status[/] ",
        "incident": "[bold]Incident[/]",
        "hostname": "[bold]Host[/]",
        "tactics": "[bold]Tactics[/]",
        "techniques": "[bold]Techniques[/]",
        "objectives": "[bold]Objective[/]s",
    }
    for value in headers.values():
        table.add_column(value, justify="left")
    for inc in incident_listing:
        inc_detail = {"status": status_information(inc)}
        inc_detail["incident"] = incident_information(inc)
        inc_detail["hostname"] = hosts_information(inc)
        inc_detail["tactics"] = "\n".join(inc["tactics"])
        inc_detail["techniques"] = "\n".join(inc["techniques"])
        inc_detail["objectives"] = "\n".join(inc["objectives"])
        table.add_row(
            inc_detail["status"],
            inc_detail["incident"],
            inc_detail["hostname"],
            inc_detail["tactics"],
            inc_detail["techniques"],
            inc_detail["objectives"],
        )
    console.print(table)
