#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""CrowdStrike compliance integration using the ComplianceIntegration base class.

Maps CrowdStrike's static compliance data to RegScale control implementations
using the standard compliance framework patterns. Supports NIST, CSF, SOC2, CMMC,
ISO, CIS, and OWASP frameworks via the framework handler registry.
The framework is auto-detected from the SSP's existing control implementations.

For frameworks without direct CrowdStrike mapping data (SOC2, CMMC, ISO, CIS, OWASP),
the NIST mapping is automatically translated using the CrossFrameworkMapper.
"""

import json
import logging
from html import escape as html_escape
from typing import Any, Dict, List, Optional

from regscale.integrations.compliance_integration import (
    ComplianceIntegration,
    ComplianceItem,
    FrameworkDetectionError,
    detect_framework_from_control_ids,
)
from regscale.models.regscale_models import ControlImplementation

logger = logging.getLogger("regscale")

FRAMEWORK_FILE_MAP = {
    "NIST": "nist_800_53_r5_controls",
    "CSF": "csf_controls",
}


class CrowdStrikeComplianceItem(ComplianceItem):
    """
    Compliance item from CrowdStrike static mapping data.

    Each item represents a control that CrowdStrike supports at Full or Partial level.
    """

    def __init__(
        self,
        control_id: str,
        support_level: str,
        notes: List[str],
        framework: str,
    ):
        """
        Initialize from CrowdStrike mapping data.

        :param str control_id: Control identifier (e.g., AC-2, SI-4)
        :param str support_level: "Full" or "Partial"
        :param List[str] notes: Implementation notes from CrowdStrike
        :param str framework: Compliance framework
        """
        self._control_id = control_id
        self._support_level = support_level
        self._notes = notes
        self._framework = framework

    @property
    def resource_id(self) -> str:
        """CrowdStrike Falcon is the resource."""
        return "crowdstrike-falcon"

    @property
    def resource_name(self) -> str:
        """CrowdStrike Falcon platform name."""
        return "CrowdStrike Falcon"

    @property
    def control_id(self) -> str:
        """Control identifier."""
        return self._control_id

    @property
    def compliance_result(self) -> str:
        """Both Full and Partial support are PASS (control is supported)."""
        return "PASS"

    @property
    def severity(self) -> Optional[str]:
        """No severity for static mappings."""
        return None

    @property
    def description(self) -> str:
        """Implementation notes as description."""
        return "\n".join(self._notes) if self._notes else "CrowdStrike supported control"

    @property
    def framework(self) -> str:
        """Compliance framework."""
        return self._framework

    @property
    def support_level(self) -> str:
        """CrowdStrike support level (Full or Partial)."""
        return self._support_level

    @property
    def implementation_text(self) -> str:
        """HTML-formatted implementation notes for control implementation."""
        return "\n".join(f"<p>{html_escape(note)}</p>" for note in self._notes) if self._notes else ""


def _load_compliance_data(framework_file: str) -> dict:
    """
    Load compliance data for the given framework from the package resources.

    :param str framework_file: The framework file name to load
    :return: The compliance data as a dictionary
    :rtype: dict
    """
    from importlib.resources import open_text

    with open_text("regscale.integrations.commercial.mappings", f"{framework_file}.json") as f:
        return json.load(f)


class CrowdStrikeComplianceIntegration(ComplianceIntegration):
    """
    CrowdStrike compliance integration extending the standard ComplianceIntegration base class.

    Maps CrowdStrike's static compliance data to RegScale control implementations,
    using the SSP's compliance settings for proper status mapping (FedRAMP, DoD, NIST, etc.).

    Supports all frameworks in the handler registry: NIST, CSF, SOC2, CMMC, ISO, CIS, OWASP.
    The framework is auto-detected from the SSP's existing control implementations.

    For frameworks without direct CrowdStrike mapping data, the NIST mapping is
    automatically translated via CrossFrameworkMapper using known public crosswalks.

    CrowdStrike controls have Full or Partial support levels. The base class handles
    Pass/Fail/Not Applicable, so we track partial controls separately and override
    the status determination to map:
    - Full support -> "Pass" -> compliance settings maps to appropriate "Implemented" status
    - Partial support -> "Partial Pass" -> compliance settings maps to "Partially Implemented"
    """

    def __init__(
        self,
        plan_id: int,
        framework: Optional[str] = None,
        **kwargs,
    ):
        """
        Initialize CrowdStrike compliance integration.

        :param int plan_id: RegScale SSP ID
        :param Optional[str] framework: Compliance framework override. If None, auto-detected from SSP controls.
        """
        super().__init__(
            plan_id=plan_id,
            framework=framework or "NIST",
            create_issues=False,
            update_control_status=True,
            create_poams=False,
            parent_module="securityplans",
            **kwargs,
        )
        self._framework_override = framework
        self._framework_file: Optional[str] = None
        self._compliance_mapping: Dict[str, Any] = {}
        self._partial_controls: set[str] = set()

    @property
    def title(self) -> str:
        """Integration title for logging."""
        return "CrowdStrike"

    def _resolve_framework(self) -> str:
        """
        Resolve the framework by auto-detecting from SSP control implementations.

        :return: Resolved framework name
        :rtype: str
        :raises FrameworkDetectionError: If auto-detection fails and no framework override was provided
        """
        if self._framework_override:
            logger.info("Using user-specified framework: %s", self._framework_override)
            return self._framework_override

        try:
            implementations = ControlImplementation.get_existing_control_implementations(parent_id=self.plan_id)
        except (AttributeError, KeyError, ValueError, TypeError) as e:
            raise FrameworkDetectionError(
                "Failed to retrieve control implementations from SSP %d: %s. "
                "Please specify a framework explicitly." % (self.plan_id, e)
            ) from e

        control_names = list(implementations.keys()) if implementations else []

        detected = detect_framework_from_control_ids(control_names)
        logger.info(
            "Auto-detected framework '%s' from %d control implementations on SSP %d.",
            detected,
            len(control_names),
            self.plan_id,
        )
        return detected

    def _apply_cross_framework_mapping(
        self,
        raw_data: List[Dict[str, Any]],
        source_framework: str,
        target_framework: str,
    ) -> List[Dict[str, Any]]:
        """
        Translate compliance data from source to target framework using CrossFrameworkMapper.

        :param List[Dict[str, Any]] raw_data: Original compliance data
        :param str source_framework: Framework of the loaded mapping data
        :param str target_framework: SSP's detected framework
        :return: Translated compliance data with target framework control IDs
        :rtype: List[Dict[str, Any]]
        """
        from regscale.integrations.cross_framework_mapper import CrossFrameworkMapper

        mapper = CrossFrameworkMapper()
        if not mapper.has_crosswalk(source_framework, target_framework):
            logger.warning(
                "No crosswalk available from %s to %s. Cannot translate compliance data.",
                source_framework,
                target_framework,
            )
            return []

        source_ids = [item["control_id"] for item in raw_data]
        translated = mapper.map_controls(source_framework, target_framework, source_ids)

        translated_data = []
        for item in raw_data:
            target_ids = translated.get(item["control_id"], [])
            for target_id in target_ids:
                translated_data.append(
                    {
                        "control_id": target_id,
                        "support": item["support"],
                        "notes": item["notes"],
                        "framework": target_framework,
                    }
                )

        logger.info(
            "Cross-framework mapping: translated %d %s controls to %d %s controls.",
            len(raw_data),
            source_framework,
            len(translated_data),
            target_framework,
        )
        return translated_data

    def fetch_compliance_data(self) -> List[Dict[str, Any]]:
        """
        Load CrowdStrike compliance mapping from static JSON files.

        Auto-detects the framework from the SSP's control implementations if not
        explicitly provided. If a direct mapping file exists (NIST, CSF), uses it.
        Otherwise, loads the NIST mapping and translates to the target framework
        via CrossFrameworkMapper.

        :return: List of raw compliance data dictionaries
        :rtype: List[Dict[str, Any]]
        """
        resolved_framework = self._resolve_framework()
        self.framework = resolved_framework
        self._framework_file = FRAMEWORK_FILE_MAP.get(resolved_framework)

        # If no direct mapping, fall back to NIST and translate
        mapping_framework = resolved_framework
        if not self._framework_file:
            mapping_framework = "NIST"
            self._framework_file = FRAMEWORK_FILE_MAP.get("NIST")
            if not self._framework_file:
                logger.warning("No mapping file available for framework: %s", self.framework)
                return []
            logger.info(
                "No direct CrowdStrike mapping for %s. Will translate from NIST.",
                resolved_framework,
            )

        self._compliance_mapping = _load_compliance_data(self._framework_file)

        if not self._compliance_mapping:
            logger.warning(
                "Mapping file for %s is empty. No compliance data to process.",
                mapping_framework,
            )
            return []

        logger.info(
            "Loaded CrowdStrike %s mapping with %d controls.",
            mapping_framework,
            len(self._compliance_mapping),
        )

        raw_data = []
        for control_id, mapping in self._compliance_mapping.items():
            support = mapping.get("support")
            if support not in ("Full", "Partial"):
                continue

            if support == "Partial":
                self._partial_controls.add(control_id.lower())

            raw_data.append(
                {
                    "control_id": control_id,
                    "support": support,
                    "notes": mapping.get("notes", []),
                    "framework": mapping_framework,
                }
            )

        # Translate to target framework if we loaded a different one
        if mapping_framework != resolved_framework:
            raw_data = self._apply_cross_framework_mapping(raw_data, mapping_framework, resolved_framework)
            self._partial_controls = {item["control_id"].lower() for item in raw_data if item["support"] == "Partial"}

        full_count = len(raw_data) - len(self._partial_controls)
        logger.info(
            "Found %d CrowdStrike-supported controls (%d full, %d partial).",
            len(raw_data),
            full_count,
            len(self._partial_controls),
        )
        return raw_data

    def create_compliance_item(self, raw_data: Dict[str, Any]) -> ComplianceItem:
        """
        Create a CrowdStrikeComplianceItem from raw compliance data.

        :param Dict[str, Any] raw_data: Raw compliance data dictionary
        :return: ComplianceItem instance
        :rtype: ComplianceItem
        """
        return CrowdStrikeComplianceItem(
            control_id=raw_data["control_id"],
            support_level=raw_data["support"],
            notes=raw_data.get("notes", []),
            framework=raw_data.get("framework", self.framework),
        )

    def _determine_overall_result(self, control_id: str) -> str:
        """
        Override to return 'Partial Pass' for partially supported controls.

        :param str control_id: Control identifier to check
        :return: Assessment result ('Pass', 'Partial Pass', 'Fail', or 'Not Applicable')
        :rtype: str
        """
        if control_id.lower() in self._partial_controls:
            return "Partial Pass"

        return super()._determine_overall_result(control_id)

    def _get_implementation_status_from_result(self, result: str, override: Optional[str] = None) -> str:
        """
        Override to handle 'Partial Pass' mapping to 'Partially Implemented'.

        :param str result: Assessment result
        :param Optional[str] override: Optional override value
        :return: Implementation status string
        :rtype: str
        """
        if override:
            return override

        if result == "Partial Pass":
            from regscale.models.regscale_models.compliance_settings import ComplianceSettings

            compliance_settings = self._get_compliance_settings()
            if compliance_settings:
                try:
                    return compliance_settings.get_implementation_status_for_result("partial", None)
                except Exception as e:
                    logger.debug("Error getting partial status from compliance settings: %s", e)

            framework = self._detect_compliance_framework()
            return ComplianceSettings.get_status_mapping(framework, "partial", None)

        return super()._get_implementation_status_from_result(result, override)

    def _update_implementation_status(self, implementation: ControlImplementation, result: str) -> None:
        """
        Override to also set implementation notes from CrowdStrike mapping data.

        :param ControlImplementation implementation: Control implementation to update
        :param str result: Assessment result
        """
        control_id = None
        if hasattr(self, "_impl_to_control_id_cache") and implementation.id in self._impl_to_control_id_cache:
            control_id = self._impl_to_control_id_cache[implementation.id]

        if control_id:
            mapping = self._compliance_mapping.get(control_id) or self._compliance_mapping.get(control_id.upper())
            if mapping:
                notes = mapping.get("notes", [])
                if notes:
                    implementation.implementation = "\n".join(f"<p>{html_escape(note)}</p>" for note in notes)

        super()._update_implementation_status(implementation, result)
