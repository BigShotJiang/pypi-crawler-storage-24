#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SentinelOne configuration variables for RegScale integration.

This module defines configuration variables loaded from init.yaml
for connecting to the SentinelOne Management API.
"""

import logging

from regscale.core.app.application import Application
from regscale.core.app.utils.config_utils import get_integration_config
from regscale.core.app.utils.variables import RsVariableType

logger = logging.getLogger("regscale")


class SentinelOneConfigurationError(ValueError):
    """Exception raised for SentinelOne configuration errors."""

    pass


class SentinelOneVariables:
    """
    Configuration variables for SentinelOne integration.

    These variables are loaded from init.yaml and can be overridden
    via environment variables.  The :class:`RsVariableType` annotations
    allow the AST-based secret extractor in rs-am2 to discover required
    secrets without executing the module.

    Configuration in init.yaml:
        sentinelone:
            url: "https://usea1-partners.sentinelone.net"
            token: "your-api-token"
            verify_ssl: true
            timeout: 30
            site_id: ""  # Optional: filter by site ID
            account_id: ""  # Optional: filter by account ID
    """

    app = Application()
    _cfg = get_integration_config(app.config, "sentinelone", snake_case=True)

    # Base URL for SentinelOne Management Console
    # Example: https://usea1-partners.sentinelone.net
    sentineloneUrl: RsVariableType(  # type: ignore[valid-type]
        str,
        "https://usea1-partners.sentinelone.net",
        required=True,
    ) = _cfg.get("url", "")

    # API Token generated from Settings > Users > Edit User > API Token
    sentineloneToken: RsVariableType(  # type: ignore[valid-type]
        str,
        "",
        required=True,
        sensitive=True,
    ) = _cfg.get("token", "")

    # Whether to verify SSL certificates
    sentineloneVerifySsl: RsVariableType(  # type: ignore[valid-type]
        bool,
        "True",
        required=False,
        default=True,
    ) = _cfg.get("verify_ssl", True)

    # Request timeout in seconds
    sentineloneTimeout: RsVariableType(  # type: ignore[valid-type]
        int,
        "30",
        required=False,
        default=30,
    ) = _cfg.get("timeout", 30)

    # Optional: Filter by site ID
    sentineloneSiteId: RsVariableType(  # type: ignore[valid-type]
        str,
        "",
        required=False,
    ) = _cfg.get("site_id", "")

    # Optional: Filter by account ID
    sentineloneAccountId: RsVariableType(  # type: ignore[valid-type]
        str,
        "",
        required=False,
    ) = _cfg.get("account_id", "")

    # Page size for API pagination
    sentinelonePageSize: RsVariableType(  # type: ignore[valid-type]
        int,
        "100",
        required=False,
        default=100,
    ) = _cfg.get("page_size", 100)

    @classmethod
    def validate(cls) -> None:
        """
        Validate SentinelOne configuration values.

        Raises:
            SentinelOneConfigurationError: If configuration is invalid
        """
        cls._validate_url()
        cls._validate_token()
        cls._validate_timeout()
        cls._validate_page_size()

    @classmethod
    def _validate_url(cls) -> None:
        """Validate the SentinelOne URL configuration."""
        if not cls.sentineloneUrl:
            raise SentinelOneConfigurationError(
                "SentinelOne URL not configured. Add 'url' to sentinelone section in init.yaml"
            )
        if not cls.sentineloneUrl.startswith(("https://", "http://")):
            raise SentinelOneConfigurationError("Invalid SentinelOne URL: must start with https:// or http://")

    @classmethod
    def _validate_token(cls) -> None:
        """Validate the SentinelOne API token configuration."""
        if not cls.sentineloneToken:
            raise SentinelOneConfigurationError(
                "SentinelOne API token not configured. Add 'token' to sentinelone section in init.yaml"
            )

    @classmethod
    def _validate_timeout(cls) -> None:
        """Validate the timeout configuration."""
        if cls.sentineloneTimeout <= 0:
            raise SentinelOneConfigurationError("Invalid SentinelOne timeout: must be a positive integer")

    @classmethod
    def _validate_page_size(cls) -> None:
        """Validate the page size configuration."""
        if cls.sentinelonePageSize <= 0 or cls.sentinelonePageSize > 1000:
            raise SentinelOneConfigurationError("Invalid SentinelOne page_size: must be between 1 and 1000")
