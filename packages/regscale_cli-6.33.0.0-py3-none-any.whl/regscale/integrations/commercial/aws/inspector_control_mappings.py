#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""AWS Inspector V2 Control Mappings for RegScale Compliance Integration."""

import logging
from typing import Dict, List, Optional

logger = logging.getLogger("regscale")

# NIST 800-53 R5 Control Mappings for AWS Inspector V2
INSPECTOR_CONTROL_MAPPINGS = {
    "RA-5": {
        "name": "Vulnerability Monitoring and Scanning",
        "description": "Monitor and scan for vulnerabilities in the system",
        "checks": {
            "scanning_coverage": {
                "weight": 100,
                "pass_criteria": "Inspector is actively scanning eligible resources",
                "fail_criteria": "Inspector scanning is not active or has no coverage",
            },
            "vulnerability_detection": {
                "weight": 90,
                "pass_criteria": "CVEs are detected and tracked for all covered resources",
                "fail_criteria": "Vulnerability detection is not operational",
            },
        },
    },
    "SI-2": {
        "name": "Flaw Remediation",
        "description": "Identify, report, and correct system flaws in a timely manner",
        "checks": {
            "patch_status": {
                "weight": 100,
                "pass_criteria": "No unpatched critical or high severity vulnerabilities",
                "fail_criteria": "Critical or high severity vulnerabilities remain unpatched",
            },
            "remediation_tracking": {
                "weight": 90,
                "pass_criteria": "Remediation recommendations are followed and tracked",
                "fail_criteria": "Remediation recommendations are not being followed",
            },
        },
    },
    "CM-6": {
        "name": "Configuration Settings",
        "description": "Establish and document configuration settings for system components",
        "checks": {
            "coverage_gaps": {
                "weight": 100,
                "pass_criteria": "All eligible resources are covered by Inspector scanning",
                "fail_criteria": "Coverage gaps detected - eligible resources are not being scanned",
            },
            "scan_configuration": {
                "weight": 90,
                "pass_criteria": "Inspector is properly configured for all resource types",
                "fail_criteria": "Inspector configuration is incomplete or misconfigured",
            },
        },
    },
    "SA-11": {
        "name": "Developer Testing and Evaluation",
        "description": "Require developers to create and implement testing and evaluation plans",
        "checks": {
            "code_scanning": {
                "weight": 100,
                "pass_criteria": "ECR image vulnerability scanning is enabled and active",
                "fail_criteria": "ECR image vulnerability scanning is not enabled",
            },
            "lambda_scanning": {
                "weight": 90,
                "pass_criteria": "Lambda function code scanning is enabled and active",
                "fail_criteria": "Lambda function scanning is not enabled",
            },
        },
    },
}

# Inspector V2 severity string mapping
INSPECTOR_SEVERITY_MAP = {
    "CRITICAL": "Critical",
    "HIGH": "High",
    "MEDIUM": "Moderate",
    "LOW": "Low",
    "INFORMATIONAL": "Low",
    "UNTRIAGED": "Low",
}


class InspectorControlMapper:
    """Map AWS Inspector V2 findings to compliance control status."""

    def __init__(self, framework: str = "NIST800-53R5"):
        """
        Initialize Inspector control mapper.

        :param str framework: Compliance framework
        """
        self.framework = framework
        self.mappings = INSPECTOR_CONTROL_MAPPINGS

    def assess_inspector_compliance(self, inspector_data: Dict) -> Dict[str, str]:
        """
        Assess Inspector compliance against all mapped controls.

        :param Dict inspector_data: Inspector findings, coverage, and account status
        :return: Dictionary mapping control IDs to compliance results (PASS/FAIL)
        :rtype: Dict[str, str]
        """
        results = {}

        if self.framework == "NIST800-53R5":
            results["RA-5"] = self._assess_ra5(inspector_data)
            results["SI-2"] = self._assess_si2(inspector_data)
            results["CM-6"] = self._assess_cm6(inspector_data)
            results["SA-11"] = self._assess_sa11(inspector_data)

        return results

    def _assess_ra5(self, inspector_data: Dict) -> str:
        """
        Assess RA-5 (Vulnerability Monitoring and Scanning) compliance.

        FAIL if no coverage or no active scanning.

        :param Dict inspector_data: Inspector data
        :return: Compliance result (PASS/FAIL)
        :rtype: str
        """
        coverage = inspector_data.get("Coverage", [])
        account_status = inspector_data.get("AccountStatus", {})

        if not coverage and not account_status:
            logger.debug("Inspector FAILS RA-5: No coverage data or account status available")
            return "FAIL"

        # Check if Inspector is enabled
        state = account_status.get("state", {})
        if isinstance(state, dict) and state.get("status") not in ("ENABLED", "ENABLING"):
            logger.debug("Inspector FAILS RA-5: Inspector is not enabled")
            return "FAIL"

        if not coverage:
            logger.debug("Inspector FAILS RA-5: No resources covered by Inspector scanning")
            return "FAIL"

        logger.debug(f"Inspector PASSES RA-5: {len(coverage)} resource(s) covered by scanning")
        return "PASS"

    def _assess_si2(self, inspector_data: Dict) -> str:
        """
        Assess SI-2 (Flaw Remediation) compliance.

        FAIL if CRITICAL or HIGH findings exist.

        :param Dict inspector_data: Inspector data
        :return: Compliance result (PASS/FAIL)
        :rtype: str
        """
        findings = inspector_data.get("Findings", [])

        critical_high_findings = [f for f in findings if f.get("severity", "").upper() in ("CRITICAL", "HIGH")]

        if critical_high_findings:
            logger.debug(
                f"Inspector FAILS SI-2: {len(critical_high_findings)} critical/high severity "
                "findings requiring remediation"
            )
            return "FAIL"

        logger.debug("Inspector PASSES SI-2: No critical or high severity findings detected")
        return "PASS"

    def _assess_cm6(self, inspector_data: Dict) -> str:
        """
        Assess CM-6 (Configuration Settings) compliance.

        FAIL if coverage gaps detected (resources not scanned).

        :param Dict inspector_data: Inspector data
        :return: Compliance result (PASS/FAIL)
        :rtype: str
        """
        coverage = inspector_data.get("Coverage", [])

        # Check for resources that are not actively scanned
        not_scanned = [r for r in coverage if r.get("scanStatus", {}).get("statusCode") != "ACTIVE"]

        if not_scanned:
            logger.debug(f"Inspector FAILS CM-6: {len(not_scanned)} resource(s) not actively scanned")
            return "FAIL"

        if not coverage:
            logger.debug("Inspector FAILS CM-6: No coverage data available")
            return "FAIL"

        logger.debug(f"Inspector PASSES CM-6: All {len(coverage)} resource(s) actively scanned")
        return "PASS"

    def _assess_sa11(self, inspector_data: Dict) -> str:
        """
        Assess SA-11 (Developer Testing) compliance.

        FAIL if ECR or Lambda scanning is not enabled.

        :param Dict inspector_data: Inspector data
        :return: Compliance result (PASS/FAIL)
        :rtype: str
        """
        account_status = inspector_data.get("AccountStatus", {})

        resource_state = account_status.get("resourceState", {})
        ecr_status = resource_state.get("ecr", {}).get("status", "")
        lambda_status = resource_state.get("lambdaCode", {}).get("status", "")

        if ecr_status not in ("ENABLED", "ENABLING"):
            logger.debug("Inspector FAILS SA-11: ECR image scanning is not enabled")
            return "FAIL"

        if lambda_status not in ("ENABLED", "ENABLING"):
            logger.debug("Inspector FAILS SA-11: Lambda function scanning is not enabled")
            return "FAIL"

        logger.debug("Inspector PASSES SA-11: ECR and Lambda scanning are enabled")
        return "PASS"

    def get_severity_from_inspector(self, severity_str: str) -> str:
        """
        Map Inspector severity string to RegScale severity.

        :param str severity_str: Inspector severity (CRITICAL, HIGH, MEDIUM, LOW, INFORMATIONAL, UNTRIAGED)
        :return: RegScale severity level
        :rtype: str
        """
        return INSPECTOR_SEVERITY_MAP.get(severity_str.upper(), "Low")

    def get_control_description(self, control_id: str) -> Optional[str]:
        """Get human-readable description for a control."""
        control_data = self.mappings.get(control_id)
        if control_data:
            return f"{control_data.get('name')}: {control_data.get('description', '')}"
        return None

    def get_mapped_controls(self) -> List[str]:
        """Get list of all control IDs mapped for this framework."""
        return list(self.mappings.keys())

    def get_check_details(self, control_id: str) -> Optional[Dict]:
        """Get detailed check criteria for a control."""
        control_data = self.mappings.get(control_id)
        if control_data:
            return control_data.get("checks", {})
        return None
