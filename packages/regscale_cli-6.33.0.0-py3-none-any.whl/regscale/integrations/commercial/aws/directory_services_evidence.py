#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""AWS Directory Services Evidence Integration for RegScale CLI."""

import gzip
import json
import logging
import os
import time
from dataclasses import dataclass
from datetime import datetime, timedelta
from io import BytesIO
from typing import Any, Dict, List, Optional

import boto3
from botocore.exceptions import ClientError

from regscale.core.app.api import Api
from regscale.core.app.utils.app_utils import get_current_datetime
from regscale.integrations.commercial.aws.directory_services_control_mappings import (
    DirectoryServicesControlMapper,
)
from regscale.integrations.compliance_integration import (
    ComplianceIntegration,
    ComplianceItem,
)
from regscale.models.regscale_models.evidence import Evidence
from regscale.models.regscale_models.evidence_mapping import EvidenceMapping
from regscale.models.regscale_models.file import File

logger = logging.getLogger("regscale")

DIRECTORY_SERVICES_CACHE_FILE = os.path.join("artifacts", "aws", "directory_services_data.json")
CACHE_TTL_SECONDS = 4 * 60 * 60

HTML_STRONG_OPEN = "<strong>"
HTML_STRONG_CLOSE = "</strong>"
HTML_P_OPEN = "<p>"
HTML_P_CLOSE = "</p>"
HTML_UL_OPEN = "<ul>"
HTML_UL_CLOSE = "</ul>"
HTML_LI_OPEN = "<li>"
HTML_LI_CLOSE = "</li>"
HTML_H2_OPEN = "<h2>"
HTML_H2_CLOSE = "</h2>"
HTML_H3_OPEN = "<h3>"
HTML_H3_CLOSE = "</h3>"
HTML_BR = "<br>"


@dataclass
class DirectoryServicesEvidenceConfig:
    """Configuration for AWS Directory Services evidence collection."""

    plan_id: int
    region: str = "us-east-1"
    framework: str = "NIST800-53R5"
    create_issues: bool = True
    update_control_status: bool = True
    create_poams: bool = False
    parent_module: str = "securityplans"
    collect_evidence: bool = False
    evidence_as_attachments: bool = False
    evidence_control_ids: Optional[List[str]] = None
    evidence_frequency: int = 30
    force_refresh: bool = False
    account_id: Optional[str] = None
    tags: Optional[Dict[str, str]] = None
    profile: Optional[str] = None
    aws_access_key_id: Optional[str] = None
    aws_secret_access_key: Optional[str] = None
    aws_session_token: Optional[str] = None


class DirectoryServicesComplianceItem(ComplianceItem):
    """
    Compliance item representing a Directory Services assessment for a specific control.

    Maps Directory Services configuration data to compliance control requirements.
    """

    def __init__(
        self,
        control_id: str,
        ds_data: Dict[str, Any],
        control_mapper: DirectoryServicesControlMapper,
    ):
        """
        Initialize Directory Services compliance item.

        :param str control_id: The control ID being assessed (e.g., 'AC-2', 'IA-2')
        :param Dict[str, Any] ds_data: Complete Directory Services data including directories
        :param DirectoryServicesControlMapper control_mapper: Control mapper for compliance assessment
        """
        self._control_id = control_id
        self.ds_data = ds_data
        self.control_mapper = control_mapper

        # Assess compliance for this specific control
        all_results = control_mapper.assess_directory_services_compliance(ds_data)
        self._compliance_result = all_results.get(control_id, "PASS")

        # Extract directory statistics
        self.directories = ds_data.get("Directories", [])
        self.active_directories = [d for d in self.directories if d.get("Stage") == "Active"]
        self.microsoft_ad_dirs = [d for d in self.directories if d.get("Type") == "MicrosoftAD"]
        self.ad_connector_dirs = [d for d in self.directories if d.get("Type") == "ADConnector"]
        self.simple_ad_dirs = [d for d in self.directories if d.get("Type") == "SimpleAD"]
        self.mfa_configured_dirs = [d for d in self.directories if d.get("RadiusSettings")]

        # Get the account ID from the first directory if available
        self._account_id = self._extract_account_id()

    def _extract_account_id(self) -> str:
        """Extract AWS account ID from directory data."""
        if self.directories:
            directory = self.directories[0]
            if isinstance(directory, dict):
                return directory.get("OwnerAccount", "")
        return ""

    @property
    def resource_id(self) -> str:
        """Unique identifier for the Directory Services in this account/region."""
        if self._account_id:
            return "ds-%s" % self._account_id
        return "ds-service"

    @property
    def resource_name(self) -> str:
        """Human-readable name of the Directory Services."""
        if self._account_id:
            return "AWS Directory Services - Account %s" % self._account_id
        return "AWS Directory Services"

    @property
    def control_id(self) -> str:
        """Control identifier (e.g., AC-2, IA-2)."""
        return self._control_id

    @property
    def compliance_result(self) -> str:
        """Result of compliance check (PASS, FAIL)."""
        return self._compliance_result

    @property
    def severity(self) -> Optional[str]:
        """Severity level based on the control and directory state."""
        if self.compliance_result == "PASS":
            return None

        severity_map = {
            "AC-2": "High",
            "IA-2": "High",
            "IA-5": "Medium",
            "SC-8": "Medium",
        }
        return severity_map.get(self._control_id, "Medium")

    @property
    def description(self) -> str:
        """Detailed description of the Directory Services compliance assessment."""
        desc_parts = self._build_assessment_header()
        desc_parts.extend(self._build_directory_summary())
        desc_parts.extend(self._build_control_assessment())

        if self.compliance_result == "FAIL":
            desc_parts.extend(self._build_remediation_guidance())

        return "".join(desc_parts)

    def _build_assessment_header(self) -> List[str]:
        """Build the assessment header section."""
        control_desc = self.control_mapper.get_control_description(self._control_id)
        return [
            "%sDirectory Services Compliance Assessment%s" % (HTML_H3_OPEN, HTML_H3_CLOSE),
            HTML_P_OPEN,
            "%sControl:%s %s - %s%s" % (HTML_STRONG_OPEN, HTML_STRONG_CLOSE, self._control_id, control_desc, HTML_BR),
            "%sResult:%s %s%s" % (HTML_STRONG_OPEN, HTML_STRONG_CLOSE, self._compliance_result, HTML_BR),
            "%sAccount:%s %s" % (HTML_STRONG_OPEN, HTML_STRONG_CLOSE, self._account_id or "N/A"),
            HTML_P_CLOSE,
        ]

    def _build_directory_summary(self) -> List[str]:
        """Build directory status summary."""
        return [
            "%sDirectory Summary%s" % (HTML_H3_OPEN, HTML_H3_CLOSE),
            HTML_UL_OPEN,
            "%sTotal Directories: %d%s" % (HTML_LI_OPEN, len(self.directories), HTML_LI_CLOSE),
            "%sActive: %d%s" % (HTML_LI_OPEN, len(self.active_directories), HTML_LI_CLOSE),
            "%sMicrosoftAD: %d%s" % (HTML_LI_OPEN, len(self.microsoft_ad_dirs), HTML_LI_CLOSE),
            "%sADConnector: %d%s" % (HTML_LI_OPEN, len(self.ad_connector_dirs), HTML_LI_CLOSE),
            "%sSimpleAD: %d%s" % (HTML_LI_OPEN, len(self.simple_ad_dirs), HTML_LI_CLOSE),
            "%sMFA Configured: %d%s" % (HTML_LI_OPEN, len(self.mfa_configured_dirs), HTML_LI_CLOSE),
            HTML_UL_CLOSE,
        ]

    def _build_control_assessment(self) -> List[str]:
        """Build control-specific assessment details."""
        control_mapping = self.control_mapper.mappings.get(self._control_id, {})
        checks = control_mapping.get("checks", {})

        section_parts = [
            "%sControl Assessment Details%s" % (HTML_H3_OPEN, HTML_H3_CLOSE),
            HTML_UL_OPEN,
        ]

        for _check_name, check_info in checks.items():
            if self.compliance_result == "PASS":
                criteria = check_info.get("pass_criteria", "")
            else:
                criteria = check_info.get("fail_criteria", "")
            section_parts.append("%s%s%s" % (HTML_LI_OPEN, criteria, HTML_LI_CLOSE))

        section_parts.append(HTML_UL_CLOSE)
        return section_parts

    def _build_remediation_guidance(self) -> List[str]:
        """Build remediation guidance for failed controls."""
        section_parts = [
            "%sRemediation Guidance%s" % (HTML_H3_OPEN, HTML_H3_CLOSE),
            HTML_UL_OPEN,
        ]

        if self._control_id == "AC-2":
            section_parts.append(
                "%sDeploy AWS Managed Microsoft AD or AD Connector for centralized account management%s"
                % (HTML_LI_OPEN, HTML_LI_CLOSE)
            )
            section_parts.append("%sEnsure directory is in Active stage%s" % (HTML_LI_OPEN, HTML_LI_CLOSE))
        elif self._control_id == "IA-2":
            section_parts.append(
                "%sConfigure RADIUS MFA server for directory authentication%s" % (HTML_LI_OPEN, HTML_LI_CLOSE)
            )
            section_parts.append(
                "%sEnable multi-factor authentication for all directory users%s" % (HTML_LI_OPEN, HTML_LI_CLOSE)
            )
        elif self._control_id == "IA-5":
            section_parts.append(
                "%sEnsure directory is active and password policies are enforced%s" % (HTML_LI_OPEN, HTML_LI_CLOSE)
            )
            section_parts.append("%sReview and strengthen password policy settings%s" % (HTML_LI_OPEN, HTML_LI_CLOSE))
        elif self._control_id == "SC-8":
            section_parts.append(
                "%sDeploy AWS Managed Microsoft AD to enable LDAPS capability%s" % (HTML_LI_OPEN, HTML_LI_CLOSE)
            )
            section_parts.append(
                "%sConfigure client-side LDAPS for encrypted directory communications%s" % (HTML_LI_OPEN, HTML_LI_CLOSE)
            )

        section_parts.append(HTML_UL_CLOSE)
        return section_parts

    @property
    def framework(self) -> str:
        """Compliance framework used for assessment."""
        return self.control_mapper.framework


class AWSDirectoryServicesEvidenceIntegration(ComplianceIntegration):
    """Process AWS Directory Services data and create assessments/issues in RegScale."""

    def __init__(self, config: DirectoryServicesEvidenceConfig):
        """
        Initialize AWS Directory Services evidence integration.

        :param DirectoryServicesEvidenceConfig config: Configuration object containing all parameters
        """
        super().__init__(
            plan_id=config.plan_id,
            framework=config.framework,
            create_issues=config.create_issues,
            update_control_status=config.update_control_status,
            create_poams=config.create_poams,
            parent_module=config.parent_module,
        )

        # Initialize API for file operations
        self.api = Api()

        self.region = config.region
        self.title = "AWS Directory Services"
        self.framework = config.framework
        self.create_issues = config.create_issues
        self.collect_evidence = config.collect_evidence
        self.evidence_as_attachments = config.evidence_as_attachments
        self.evidence_control_ids = config.evidence_control_ids
        self.evidence_frequency = config.evidence_frequency
        self.force_refresh = config.force_refresh
        self.account_id = config.account_id
        self.tags = config.tags or {}

        self.control_mapper = DirectoryServicesControlMapper(framework=config.framework)

        profile = config.profile
        aws_access_key_id = config.aws_access_key_id
        aws_secret_access_key = config.aws_secret_access_key
        aws_session_token = config.aws_session_token

        if aws_access_key_id and aws_secret_access_key:
            logger.info("Initializing AWS Directory Services client with explicit credentials")
            self.session = boto3.Session(
                region_name=config.region,
                aws_access_key_id=aws_access_key_id,
                aws_secret_access_key=aws_secret_access_key,
                aws_session_token=aws_session_token,
            )
        else:
            logger.info(
                "Initializing AWS Directory Services client with profile: %s",
                profile if profile else "default",
            )
            self.session = boto3.Session(profile_name=profile, region_name=config.region)

        try:
            self.client = self.session.client("ds")
            logger.info("Successfully created AWS Directory Services client")
        except Exception as e:
            logger.error("Failed to create AWS Directory Services client: %s", e)
            raise

        self.raw_ds_data: Dict[str, Any] = {}

    def fetch_compliance_data(self) -> List[Dict[str, Any]]:
        """
        Fetch Directory Services compliance data.

        Returns the raw Directory Services data which will be used to create compliance items
        for each control that Directory Services maps to.

        :return: List containing raw Directory Services data
        :rtype: List[Dict[str, Any]]
        """
        self._fetch_ds_data()

        # Return the raw data wrapped in a list
        return [self.raw_ds_data] if self.raw_ds_data else []

    def create_compliance_item(self, raw_data: Dict[str, Any]) -> List[ComplianceItem]:
        """
        Create compliance items from Directory Services data.

        Creates multiple compliance items (one per control) from the same data set.

        :param Dict[str, Any] raw_data: Raw Directory Services data
        :return: List of compliance items for each control
        :rtype: List[ComplianceItem]
        """
        compliance_items = []

        # Get all controls that Directory Services maps to
        control_results = self.control_mapper.assess_directory_services_compliance(raw_data)

        # Create a compliance item for each control
        for control_id in control_results:
            compliance_item = DirectoryServicesComplianceItem(
                control_id=control_id,
                ds_data=raw_data,
                control_mapper=self.control_mapper,
            )
            compliance_items.append(compliance_item)

        return compliance_items

    def process_compliance_data(self) -> None:
        """
        Override process_compliance_data to handle Directory Services unique pattern.

        Directory Services creates multiple compliance items from a single data fetch,
        so we need to handle this differently than the base implementation.
        """
        logger.info("Processing Directory Services compliance data...")

        self._reset_compliance_state()
        raw_compliance_data = self.fetch_compliance_data()

        # Process the raw data - Directory Services returns a list with one item
        for raw_item in raw_compliance_data:
            try:
                # Create multiple compliance items from the single raw data
                compliance_items = self.create_compliance_item(raw_item)

                # Process each compliance item
                for compliance_item in compliance_items:
                    control_id = getattr(compliance_item, "control_id", "")
                    resource_id = getattr(compliance_item, "resource_id", "")

                    if not control_id or not resource_id:
                        continue

                    # Add to collections
                    self.all_compliance_items.append(compliance_item)

                    # Build asset mapping
                    self.asset_compliance_map[compliance_item.resource_id].append(compliance_item)

                    # Categorize by result
                    if compliance_item.compliance_result in self.FAIL_STATUSES:
                        self.failed_compliance_items.append(compliance_item)
                        self.failing_controls[control_id.lower()] = compliance_item
                    else:
                        self.passing_controls[control_id.lower()] = compliance_item

            except Exception as e:
                logger.error("Error processing Directory Services compliance data: %s", e)
                continue

        logger.info(
            "Processed %d compliance items: %d passing controls, %d failing controls",
            len(self.all_compliance_items),
            len(self.passing_controls),
            len(self.failing_controls),
        )

    def _is_cache_valid(self) -> bool:
        """Check if cached data is still valid."""
        if not os.path.exists(DIRECTORY_SERVICES_CACHE_FILE):
            return False
        file_age = time.time() - os.path.getmtime(DIRECTORY_SERVICES_CACHE_FILE)
        is_valid = file_age < CACHE_TTL_SECONDS
        if is_valid:
            logger.info("Using cached Directory Services data (age: %.1f hours)", file_age / 3600)
        return is_valid

    def _load_cached_data(self) -> Dict[str, Any]:
        """Load data from cache file."""
        try:
            with open(DIRECTORY_SERVICES_CACHE_FILE, encoding="utf-8") as file:
                data = json.load(file)

            # Validate cache format - must be a dict
            if not isinstance(data, dict):
                logger.warning("Invalid cache format detected (not a dict). Invalidating cache.")
                return {}

            return data
        except (json.JSONDecodeError, IOError) as e:
            logger.warning("Error reading cache: %s", e)
            return {}

    def _save_to_cache(self, ds_data: Dict[str, Any]) -> None:
        """Save data to cache file."""
        try:
            os.makedirs(os.path.dirname(DIRECTORY_SERVICES_CACHE_FILE), exist_ok=True)
            with open(DIRECTORY_SERVICES_CACHE_FILE, "w", encoding="utf-8") as file:
                json.dump(ds_data, file, indent=2, default=str)
            os.chmod(DIRECTORY_SERVICES_CACHE_FILE, 0o600)
            logger.info("Cached Directory Services data to %s", DIRECTORY_SERVICES_CACHE_FILE)
        except IOError as e:
            logger.warning("Error writing cache: %s", e)

    def _fetch_fresh_ds_data(self) -> Dict[str, Any]:
        """Fetch fresh Directory Services data from AWS API."""
        logger.info("Fetching Directory Services data from AWS...")

        directories = []
        try:
            paginator = self.client.get_paginator("describe_directories")
            for page in paginator.paginate():
                directories.extend(page.get("DirectoryDescriptions", []))
        except ClientError as e:
            logger.error("Error fetching directories: %s", e)
            raise

        ds_data = {"Directories": directories}
        logger.info("Fetched %d directory(ies)", len(directories))
        return ds_data

    def _fetch_ds_data(self) -> Dict[str, Any]:
        """Fetch Directory Services data with caching support."""
        if not self.force_refresh and self._is_cache_valid():
            cached_data = self._load_cached_data()
            if cached_data:
                self.raw_ds_data = cached_data
                return cached_data

        if self.force_refresh:
            logger.info("Force refresh requested, fetching fresh Directory Services data...")

        try:
            ds_data = self._fetch_fresh_ds_data()
            self.raw_ds_data = ds_data
            self._save_to_cache(ds_data)
            return ds_data
        except ClientError as e:
            from regscale.integrations.commercial.aws.common import handle_aws_client_error

            handle_aws_client_error(e, "fetching Directory Services data", region=self.region)
            return {}

    def sync_compliance(self) -> None:
        """
        Main method to sync Directory Services compliance data.

        This extends the base sync_compliance to:
        1. Create assessments for controls (AC-2, IA-2, IA-5, SC-8)
        2. Update control implementation status
        3. Create issues for failed compliance
        4. Collect evidence if requested
        """
        # Call the base class sync_compliance to handle control assessments and issues
        super().sync_compliance()

        # If evidence collection is enabled, collect evidence after compliance sync
        if self.collect_evidence:
            logger.info("Evidence collection enabled, starting evidence collection...")
            self._collect_ds_evidence()

    def _collect_ds_evidence(self) -> None:
        """Collect and store Directory Services evidence."""
        if not self.raw_ds_data:
            logger.warning("No Directory Services data available for evidence collection")
            return

        scan_date = get_current_datetime(dt_format="%Y%m%d_%H%M%S")

        if self.evidence_as_attachments:
            logger.info("Creating SSP file attachment with Directory Services evidence...")
            self._create_ssp_attachment(scan_date)
        else:
            logger.info("Creating Evidence record with Directory Services evidence...")
            self._create_evidence_record(scan_date)

    def _create_ssp_attachment(self, scan_date: str) -> None:
        """Create SSP attachment with Directory Services evidence data."""
        try:
            # Check for existing evidence to avoid duplicates
            date_str = datetime.now().strftime("%Y%m%d")
            file_name_pattern = "directory_services_evidence_%s" % date_str

            if self.check_for_existing_evidence(file_name_pattern):
                logger.info(
                    "Evidence file for Directory Services already exists for today. "
                    "Skipping upload to avoid duplicates."
                )
                return

            # Add timestamp to make filename unique if run multiple times per day
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            file_name = "directory_services_evidence_%s.jsonl.gz" % timestamp

            # Build compliance assessment
            compliance_results = self.control_mapper.assess_directory_services_compliance(self.raw_ds_data)

            evidence_entry = {
                **self.raw_ds_data,
                "compliance_assessment": {
                    "control_results": compliance_results,
                    "assessed_controls": list(compliance_results.keys()),
                    "assessment_date": scan_date,
                },
                "directory_summary": {
                    "total": len(self.raw_ds_data.get("Directories", [])),
                    "active": len([d for d in self.raw_ds_data.get("Directories", []) if d.get("Stage") == "Active"]),
                    "mfa_configured": len(
                        [d for d in self.raw_ds_data.get("Directories", []) if d.get("RadiusSettings")]
                    ),
                },
            }

            jsonl_content = json.dumps(evidence_entry, default=str)

            compressed_buffer = BytesIO()
            with gzip.open(compressed_buffer, "wt", encoding="utf-8", compresslevel=9) as gz_file:
                gz_file.write(jsonl_content)

            compressed_data = compressed_buffer.getvalue()

            api = Api()
            success = File.upload_file_to_regscale(
                file_name=file_name,
                parent_id=self.plan_id,
                parent_module=self.parent_module,
                api=api,
                file_data=compressed_data,
                tags="aws,directory-services,compliance,automated",
            )

            if success:
                logger.info("Successfully uploaded Directory Services evidence file: %s", file_name)
            else:
                logger.error("Failed to upload Directory Services evidence file")

        except Exception as e:
            logger.error("Error creating SSP attachment: %s", e, exc_info=True)

    def _create_evidence_record(self, scan_date: str) -> None:
        """Create an Evidence record in RegScale with Directory Services data."""
        try:
            title = "AWS Directory Services Evidence - %s" % scan_date
            description = self._build_evidence_description(scan_date)
            due_date = (datetime.now() + timedelta(days=self.evidence_frequency)).isoformat()

            evidence = Evidence(
                title=title,
                description=description,
                status="Collected",
                updateFrequency=self.evidence_frequency,
                dueDate=due_date,
            )

            created_evidence = evidence.create()
            if not created_evidence or not created_evidence.id:
                logger.error("Failed to create evidence record")
                return

            logger.info("Created evidence record %s: %s", created_evidence.id, title)
            self._upload_evidence_file(created_evidence.id, scan_date)
            self._link_evidence_to_ssp(created_evidence.id)

            # Link to controls if specified
            if self.evidence_control_ids:
                self._link_evidence_to_controls(created_evidence.id, is_attachment=False)

        except Exception as e:
            logger.error("Error creating evidence record: %s", e, exc_info=True)

    def _build_evidence_description(self, scan_date: str) -> str:
        """Build HTML-formatted evidence description."""
        summary = self._get_ds_summary()
        compliance_results = self.control_mapper.assess_directory_services_compliance(self.raw_ds_data)

        desc_parts = self._build_evidence_header(scan_date)
        desc_parts.extend(self._build_summary_section(summary))
        desc_parts.extend(self._build_compliance_section(compliance_results))

        return "".join(desc_parts)

    def _get_ds_summary(self) -> Dict[str, int]:
        """Extract summary statistics from Directory Services data."""
        directories = self.raw_ds_data.get("Directories", [])
        return {
            "total": len(directories),
            "active": len([d for d in directories if d.get("Stage") == "Active"]),
            "microsoft_ad": len([d for d in directories if d.get("Type") == "MicrosoftAD"]),
            "ad_connector": len([d for d in directories if d.get("Type") == "ADConnector"]),
            "simple_ad": len([d for d in directories if d.get("Type") == "SimpleAD"]),
            "mfa_configured": len([d for d in directories if d.get("RadiusSettings")]),
        }

    def _build_evidence_header(self, scan_date: str) -> List[str]:
        """Build evidence header section."""
        return [
            "<h1>AWS Directory Services Compliance Evidence</h1>",
            "%s%sAssessment Date:%s %s%s" % (HTML_P_OPEN, HTML_STRONG_OPEN, HTML_STRONG_CLOSE, scan_date, HTML_P_CLOSE),
        ]

    def _build_summary_section(self, summary: Dict[str, int]) -> List[str]:
        """Build Directory Services summary section."""
        return [
            "%sDirectory Services Summary%s" % (HTML_H2_OPEN, HTML_H2_CLOSE),
            HTML_UL_OPEN,
            "%s%sTotal Directories:%s %d%s"
            % (HTML_LI_OPEN, HTML_STRONG_OPEN, HTML_STRONG_CLOSE, summary["total"], HTML_LI_CLOSE),
            "%s%sActive:%s %d%s"
            % (HTML_LI_OPEN, HTML_STRONG_OPEN, HTML_STRONG_CLOSE, summary["active"], HTML_LI_CLOSE),
            "%s%sMicrosoftAD:%s %d%s"
            % (HTML_LI_OPEN, HTML_STRONG_OPEN, HTML_STRONG_CLOSE, summary["microsoft_ad"], HTML_LI_CLOSE),
            "%s%sADConnector:%s %d%s"
            % (HTML_LI_OPEN, HTML_STRONG_OPEN, HTML_STRONG_CLOSE, summary["ad_connector"], HTML_LI_CLOSE),
            "%s%sSimpleAD:%s %d%s"
            % (HTML_LI_OPEN, HTML_STRONG_OPEN, HTML_STRONG_CLOSE, summary["simple_ad"], HTML_LI_CLOSE),
            "%s%sMFA Configured:%s %d%s"
            % (HTML_LI_OPEN, HTML_STRONG_OPEN, HTML_STRONG_CLOSE, summary["mfa_configured"], HTML_LI_CLOSE),
            HTML_UL_CLOSE,
        ]

    def _build_compliance_section(self, compliance_results: Dict[str, str]) -> List[str]:
        """Build control compliance results section."""
        section_parts = [
            "%sControl Compliance Results%s" % (HTML_H2_OPEN, HTML_H2_CLOSE),
            HTML_UL_OPEN,
        ]

        for control_id, result in compliance_results.items():
            control_item = self._format_control_result(control_id, result)
            section_parts.append(control_item)

        section_parts.append(HTML_UL_CLOSE)
        return section_parts

    def _format_control_result(self, control_id: str, result: str) -> str:
        """Format a single control result for display."""
        control_desc = self.control_mapper.get_control_description(control_id)
        result_color = "#d32f2f" if result == "FAIL" else "#2e7d32"
        return "%s%s%s:%s <span style='color: %s;'>%s</span> - %s%s" % (
            HTML_LI_OPEN,
            HTML_STRONG_OPEN,
            control_id,
            HTML_STRONG_CLOSE,
            result_color,
            result,
            control_desc,
            HTML_LI_CLOSE,
        )

    def _upload_evidence_file(self, evidence_id: int, scan_date: str) -> None:
        """Upload evidence file to an Evidence record."""
        try:
            compliance_results = self.control_mapper.assess_directory_services_compliance(self.raw_ds_data)
            evidence_entry = {
                **self.raw_ds_data,
                "compliance_assessment": {
                    "control_results": compliance_results,
                    "assessed_controls": list(compliance_results.keys()),
                    "assessment_date": scan_date,
                },
            }
            jsonl_content = json.dumps(evidence_entry, default=str)

            compressed_buffer = BytesIO()
            with gzip.open(compressed_buffer, "wt", encoding="utf-8", compresslevel=9) as gz_file:
                gz_file.write(jsonl_content)

            compressed_data = compressed_buffer.getvalue()
            file_name = "directory_services_evidence_%s.jsonl.gz" % scan_date

            api = Api()
            success = File.upload_file_to_regscale(
                file_name=file_name,
                parent_id=evidence_id,
                parent_module="evidence",
                api=api,
                file_data=compressed_data,
                tags="aws,directory-services,compliance",
            )

            if success:
                logger.info("Uploaded Directory Services evidence file to Evidence %s", evidence_id)
            else:
                logger.warning("Failed to upload evidence file to Evidence %s", evidence_id)

        except Exception as e:
            logger.error("Error uploading evidence file: %s", e, exc_info=True)

    def _link_evidence_to_ssp(self, evidence_id: int) -> None:
        """Link evidence record to the SSP."""
        try:
            mapping = EvidenceMapping(
                evidenceID=evidence_id,
                mappedID=self.plan_id,
                mappingType=self.parent_module,
            )
            mapping.create()
            logger.info("Linked evidence %s to SSP %s", evidence_id, self.plan_id)
        except Exception as ex:
            logger.warning("Failed to link evidence to SSP: %s", ex)

    def _link_evidence_to_controls(self, evidence_id: int, is_attachment: bool = False) -> None:
        """
        Link evidence to specified control IDs.

        :param int evidence_id: Evidence or attachment ID
        :param bool is_attachment: True if linking attachment, False for evidence record
        """
        if not self.evidence_control_ids:
            return
        try:
            for control_id in self.evidence_control_ids:
                if is_attachment:
                    self.api.link_ssp_attachment_to_control(self.plan_id, evidence_id, control_id)
                else:
                    self.api.link_evidence_to_control(evidence_id, control_id)
                logger.info("Linked evidence %s to control %s", evidence_id, control_id)
        except Exception as e:
            logger.error("Failed to link evidence to controls: %s", e, exc_info=True)

    def _map_resource_type_to_asset_type(self, compliance_item: ComplianceItem) -> str:
        """
        Map Directory Services to RegScale asset type.

        :param ComplianceItem compliance_item: Compliance item
        :return: Asset type string
        :rtype: str
        """
        return "AWS Directory Services"

    def fetch_findings(self, *args, **kwargs):
        """
        Fetch findings from failed Directory Services compliance items.

        Delegates to the parent ComplianceIntegration implementation which
        iterates over failed_compliance_items and yields IntegrationFinding objects.

        :return: Iterator of IntegrationFinding objects
        :rtype: Iterator
        """
        yield from super().fetch_findings(*args, **kwargs)

    def fetch_assets(self, *args, **kwargs):
        """
        Fetch assets from Directory Services (implements ScannerIntegration abstract method).

        Directory Services creates a single asset representing the service itself.

        :return: Iterator of assets
        :rtype: Iterator
        """
        if self.all_compliance_items:
            first_item = self.all_compliance_items[0]
            asset = self.create_asset_from_compliance_item(first_item)
            if asset:
                yield asset
