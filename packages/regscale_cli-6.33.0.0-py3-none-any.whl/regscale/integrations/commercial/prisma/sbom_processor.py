#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Prisma Cloud SBOM Processor

This module provides CycloneDX SBOM parsing and software inventory management
for Prisma Cloud Compute integration.
"""

import io
import json
import logging
import sys
import tarfile
import tempfile
from pathlib import Path
from typing import Dict, List, Optional

from regscale.core.app.api import Api
from regscale.core.app.application import Application
from regscale.models.regscale_models.sbom import Sbom
from regscale.models.regscale_models.software_inventory import SoftwareInventory

logger = logging.getLogger("regscale")


def _is_valid_tarfile(tar_bytes: bytes) -> bool:
    """
    Validate that the bytes represent a valid tar.gz file before extraction.

    :param bytes tar_bytes: Raw tar.gz file bytes
    :return: True if valid tarfile, False otherwise
    :rtype: bool
    """
    try:
        # Validate it's a valid tar file without extracting
        # NOSONAR - This is format validation only, no extraction occurs
        # Actual extraction with security controls happens in extract_sbom_archive()
        with tarfile.open(fileobj=io.BytesIO(tar_bytes), mode="r:gz") as tar:
            # Just verify we can read the members without extracting
            _ = tar.getmembers()
        return True
    except (tarfile.TarError, OSError, EOFError) as e:
        logger.error(f"Invalid tar.gz file: {e}")
        return False


def _validate_tar_members(tar: tarfile.TarFile, tmpdir: str) -> tuple[list, int, int]:
    """
    Validate tar members for security (path traversal, symlink attacks, resource exhaustion).

    :param tarfile.TarFile tar: Open tarfile object
    :param str tmpdir: Target extraction directory
    :return: Tuple of (safe_members, skipped_symlinks, skipped_traversal)
    :rtype: tuple[list, int, int]
    :raises ValueError: If archive exceeds safety limits
    """
    safe_members = []
    skipped_symlinks = 0
    skipped_traversal = 0
    total_size = 0
    max_size = 1024 * 1024 * 1024  # 1GB limit
    max_members = 10000  # Maximum number of files

    members = tar.getmembers()
    if len(members) > max_members:
        raise ValueError(f"Archive contains too many files ({len(members)} > {max_members})")

    for member in members:
        # Check for resource exhaustion (zip bomb protection)
        if member.size > max_size:
            raise ValueError(f"File {member.name} is too large ({member.size} bytes > {max_size} bytes)")

        total_size += member.size
        if total_size > max_size:
            raise ValueError(f"Total archive size exceeds limit ({total_size} > {max_size})")

        # Skip symbolic links and hard links for security
        if member.issym() or member.islnk():
            logger.debug(f"Skipping symbolic/hard link: {member.name}")
            skipped_symlinks += 1
            continue

        # Validate path doesn't escape extraction directory
        if _is_safe_tar_member(member, tmpdir):
            safe_members.append(member)
        else:
            logger.warning(f"Skipping potentially malicious tar member (path traversal): {member.name}")
            skipped_traversal += 1

    return safe_members, skipped_symlinks, skipped_traversal


def _is_safe_tar_member(member: tarfile.TarInfo, tmpdir: str) -> bool:
    """
    Check if tar member path is safe (doesn't escape extraction directory).

    :param tarfile.TarInfo member: Tar member to validate
    :param str tmpdir: Target extraction directory
    :return: True if safe, False if potentially malicious
    :rtype: bool
    """
    member_path = Path(tmpdir) / member.name
    try:
        resolved_path = member_path.resolve()
        resolved_tmpdir = Path(tmpdir).resolve()
        resolved_path.relative_to(resolved_tmpdir)
        return True
    except ValueError:
        return False


def _sanitize_filename_for_windows(filename: str) -> str:
    r"""
    Sanitize filename to be Windows-compatible by replacing invalid characters.

    Windows doesn't allow these characters in filenames: < > : " / \ | ? *
    We replace them with safe alternatives while preserving readability.

    :param str filename: Original filename
    :return: Sanitized filename safe for Windows
    :rtype: str
    """
    # Replace Windows-invalid characters
    # : -> - (most common in urn:uuid: patterns)
    # / and \ -> - (path separators)
    # < > " | ? * -> - (other invalid chars)
    replacements = {":": "-", "/": "-", "\\": "-", "<": "-", ">": "-", '"': "-", "|": "-", "?": "-", "*": "-"}
    result = filename
    for invalid_char, replacement in replacements.items():
        result = result.replace(invalid_char, replacement)
    return result


def _extract_tar_safely(tar: tarfile.TarFile, tmpdir: str, safe_members: list) -> None:
    """
    Extract tar members using appropriate security filter based on Python version.

    Sanitizes member names for Windows compatibility (replaces colons and other
    invalid characters in filenames like 'urn:uuid:host-name.json').

    :param tarfile.TarFile tar: Open tarfile object
    :param str tmpdir: Target extraction directory
    :param list safe_members: Pre-validated safe tar members
    """
    # Sanitize member names for Windows compatibility
    # This fixes issues with filenames containing colons (e.g., 'urn:uuid:host-name.json')
    for member in safe_members:
        original_name = member.name
        sanitized_name = _sanitize_filename_for_windows(original_name)
        if sanitized_name != original_name:
            logger.debug(f"Sanitized filename: '{original_name}' -> '{sanitized_name}'")
            member.name = sanitized_name

    python_version = sys.version_info
    if python_version >= (3, 12):
        logger.debug("Using Python 3.12+ 'data' filter for enhanced security")
        # Use kwargs to avoid static analysis issues with 'filter' parameter
        tar.extractall(path=tmpdir, members=safe_members, **{"filter": "data"})
    else:
        logger.debug("Using manual path validation (Python < 3.12)")
        tar.extractall(path=tmpdir, members=safe_members)


def _parse_sbom_file(sbom_file: Path) -> Optional[tuple[str, Dict]]:
    """
    Parse a single SBOM JSON file and extract its identifier.

    :param Path sbom_file: Path to SBOM JSON file
    :return: Tuple of (resource_id, sbom_data) or None if parsing fails
    :rtype: Optional[tuple[str, Dict]]
    """
    try:
        with open(sbom_file, "r", encoding="utf-8") as f:
            sbom_data = json.load(f)

        # Extract identifier from SBOM metadata or filename
        resource_id = _extract_sbom_identifier(sbom_data, sbom_file)
        if not resource_id:
            resource_id = sbom_file.stem

        logger.debug(f"Parsed SBOM for resource: {resource_id}")
        return resource_id, sbom_data

    except json.JSONDecodeError as e:
        logger.warning(f"Failed to parse SBOM file {sbom_file.name}: Invalid JSON - {e}")
        return None
    except Exception as e:
        logger.warning(f"Failed to parse SBOM file {sbom_file.name}: {e}")
        return None


def extract_sbom_archive(tar_gz_bytes: bytes) -> Dict[str, Dict]:
    """
    Extract SBOM tar.gz archive and parse individual SBOMs with security protections.

    This function handles the bulk SBOM download format from Prisma Cloud,
    which returns a tar.gz archive containing multiple SBOM JSON files.

    Based on Platform One (P1) customer feedback, this is the working approach
    for bulk SBOM retrieval, replacing individual SBOM API calls that return 404.

    Security measures implemented:
    - Archive format validation before extraction
    - Resource consumption limits (file size, member count)
    - Path traversal protection (blocks files attempting to escape extraction directory)
    - Symbolic link filtering (prevents symlink attacks)
    - Python 3.12+ data filter for additional safety
    - Safe member validation before extraction

    :param bytes tar_gz_bytes: Raw tar.gz file bytes from download endpoint
    :return: Dict mapping resource identifier → parsed SBOM data
    :rtype: Dict[str, Dict]

    Example:
        >>> tar_gz_data = client.get_sbom_download_hosts()
        >>> sbom_map = extract_sbom_archive(tar_gz_data)
        >>> print(f"Extracted {len(sbom_map)} SBOMs")
        >>> for resource_id, sbom in sbom_map.items():
        ...     print(f"Resource: {resource_id}, Components: {len(sbom.get('components', []))}")
    """
    # Validate archive is safe before proceeding
    if not _is_valid_tarfile(tar_gz_bytes):
        logger.error("Invalid or corrupted tar.gz archive")
        return {}

    try:
        with tempfile.TemporaryDirectory() as tmpdir:
            logger.info(f"Extracting SBOM archive to temporary directory: {tmpdir}")

            # Extract tar.gz archive with comprehensive security protections
            with tarfile.open(fileobj=io.BytesIO(tar_gz_bytes), mode="r:gz") as tar:
                safe_members, skipped_symlinks, skipped_traversal = _validate_tar_members(tar, tmpdir)

                # Log security filtering results
                if skipped_symlinks > 0:
                    logger.info(f"Security: Filtered {skipped_symlinks} symbolic/hard links")
                if skipped_traversal > 0:
                    logger.warning(f"Security: Blocked {skipped_traversal} path traversal attempts")

                _extract_tar_safely(tar, tmpdir, safe_members)
                logger.debug(f"Extracted tar.gz archive with {len(safe_members)} safe members")

            # Parse SBOM files and build result map
            sbom_files = list(Path(tmpdir).rglob("*.json"))
            logger.info(f"Found {len(sbom_files)} SBOM JSON files")

            sbom_map = {}
            for sbom_file in sbom_files:
                result = _parse_sbom_file(sbom_file)
                if result:
                    resource_id, sbom_data = result
                    sbom_map[resource_id] = sbom_data

            logger.info(f"Successfully extracted {len(sbom_map)} SBOMs from archive")
            return sbom_map

    except ValueError as e:
        logger.error(f"Archive failed security validation: {e}")
        return {}
    except tarfile.TarError as e:
        logger.error(f"Failed to extract tar.gz archive: {e}")
        return {}
    except Exception as e:
        logger.error(f"Error extracting SBOM archive: {e}")
        return {}


def _extract_sbom_identifier(sbom_data: Dict, sbom_file: Path) -> Optional[str]:
    """
    Extract resource identifier from SBOM metadata.

    Attempts to extract identifier from CycloneDX metadata component name,
    falling back to filename if not found.

    :param Dict sbom_data: Parsed SBOM JSON data
    :param Path sbom_file: Path to SBOM file (fallback for ID)
    :return: Resource identifier or None
    :rtype: Optional[str]
    """
    try:
        # Try metadata.component.name (CycloneDX standard location)
        metadata = sbom_data.get("metadata", {})
        component = metadata.get("component", {})
        resource_name = component.get("name", "")

        if resource_name:
            return resource_name

        # Try serialNumber or bomRef as alternatives
        serial_number = sbom_data.get("serialNumber", "")
        if serial_number:
            # Extract meaningful part from URN format
            # Example: urn:uuid:abc-123 → abc-123
            if ":" in serial_number:
                return serial_number.split(":")[-1]
            return serial_number

        # Fallback to filename without extension
        return sbom_file.stem

    except Exception as e:
        logger.debug(f"Error extracting SBOM identifier: {e}")
        return None


def parse_cyclonedx_sbom(sbom_json: Dict) -> List[Dict]:
    """
    Parse CycloneDX 1.4 format SBOM to software package dictionaries.

    Extracts component information from CycloneDX SBOM including:
    - Package name and version
    - License information
    - PURL (Package URL)
    - CPE (Common Platform Enumeration) if available
    - Author/supplier information

    :param Dict sbom_json: CycloneDX SBOM JSON data
    :return: List of package dictionaries
    :rtype: List[Dict]

    Example:
        >>> sbom_data = {"bomFormat": "CycloneDX", "components": [...]}
        >>> packages = parse_cyclonedx_sbom(sbom_data)
        >>> print(f"Found {len(packages)} packages")
    """
    packages = []

    # Validate SBOM format
    bom_format = sbom_json.get("bomFormat", "")
    if bom_format != "CycloneDX":
        logger.warning(f"Unexpected SBOM format: {bom_format}. Expected CycloneDX.")
        return packages

    spec_version = sbom_json.get("specVersion", "")
    logger.info(f"Parsing CycloneDX SBOM version {spec_version}")

    # Extract components array
    components = sbom_json.get("components", [])
    if not components:
        logger.warning("SBOM contains no components")
        return packages

    logger.info(f"Processing {len(components)} components from SBOM")

    for component in components:
        try:
            package_dict = _parse_component(component)
            if package_dict:
                packages.append(package_dict)
        except Exception as e:
            logger.error(f"Error parsing component: {e}")
            continue

    logger.info(f"Successfully parsed {len(packages)} packages from SBOM")
    return packages


def _extract_license_info(component: Dict) -> str:
    """
    Extract license information from CycloneDX component.

    :param Dict component: CycloneDX component object
    :return: Comma-separated license string or "Unknown"
    :rtype: str
    """
    licenses_list = component.get("licenses", [])
    license_names = []
    for lic in licenses_list:
        if isinstance(lic, dict):
            license_obj = lic.get("license", {})
            if isinstance(license_obj, dict):
                license_name = license_obj.get("name", license_obj.get("id", ""))
                if license_name:
                    license_names.append(license_name)
            elif isinstance(license_obj, str):
                license_names.append(license_obj)
    return ", ".join(license_names) if license_names else "Unknown"


def _extract_cpe_info(component: Dict) -> str:
    """
    Extract CPE from CycloneDX component.

    Checks both direct 'cpe' field (CycloneDX 1.2+) and externalReferences.

    :param Dict component: CycloneDX component object
    :return: CPE string or empty string if not found
    :rtype: str
    """
    cpe = component.get("cpe", "")
    if not cpe:
        external_refs = component.get("externalReferences", [])
        for ref in external_refs:
            if ref.get("type") == "cpe":
                cpe = ref.get("url", "")
                break
    return cpe


def _parse_component(component: Dict) -> Optional[Dict]:
    """
    Parse a single CycloneDX component to package dictionary.

    :param Dict component: CycloneDX component object
    :return: Package dictionary or None if invalid
    :rtype: Optional[Dict]
    """
    name = component.get("name", "")
    if not name:
        logger.debug("Component missing name, skipping")
        return None

    package_dict = {
        "name": name,
        "version": component.get("version", "unknown"),
        "license": _extract_license_info(component),
        "purl": component.get("purl", ""),
        "cpe": _extract_cpe_info(component),
        "author": component.get("author", ""),
        "type": component.get("type", "library"),
    }

    return package_dict


def create_sbom_record(asset_id: int, sbom_data: dict, resource_name: str) -> Optional[int]:
    """
    Create an SBOM record in RegScale linked to an asset.

    :param int asset_id: RegScale Asset ID to link the SBOM to
    :param dict sbom_data: Parsed CycloneDX SBOM JSON data
    :param str resource_name: Human-readable name for the SBOM record
    :return: The created SBOM record ID, or None on failure
    :rtype: Optional[int]
    """
    try:
        sbom = Sbom(
            name=resource_name,
            sbomStandard="CycloneDX",
            tool="Prisma Cloud",
            standardVersion=sbom_data.get("specVersion", "1.4"),
            results=json.dumps(sbom_data),
            parentId=asset_id,
            parentModule="Assets",
        )
        created = sbom.create()
        if created and created.id:
            logger.info("Created SBOM record %d for asset %d (%s)", created.id, asset_id, resource_name)
            return created.id
        logger.warning("SBOM create returned no ID for asset %d (%s)", asset_id, resource_name)
        return None
    except Exception as e:
        logger.error("Failed to create SBOM record for asset %d (%s): %s", asset_id, resource_name, e)
        return None


def create_software_inventory_from_sbom(
    asset_id: int,
    sbom_data: Dict,
    deduplicate: bool = True,
) -> int:
    """
    Create SoftwareInventory records in RegScale from SBOM data.

    This function:
    1. Parses the CycloneDX SBOM
    2. Optionally deduplicates against existing inventory
    3. Batch creates software inventory records using the SoftwareInventory model

    :param int asset_id: RegScale Asset ID to associate inventory with
    :param Dict sbom_data: CycloneDX SBOM JSON data
    :param bool deduplicate: Enable deduplication against existing inventory (default True)
    :return: Number of software inventory records created
    :rtype: int
    """
    packages = parse_cyclonedx_sbom(sbom_data)

    if not packages:
        logger.warning("No packages found in SBOM, nothing to create")
        return 0

    logger.info("Creating software inventory for %d packages on asset %d", len(packages), asset_id)

    if deduplicate:
        packages = _deduplicate_against_existing_models(asset_id, packages)
        logger.info("After deduplication: %d packages to create", len(packages))

    if not packages:
        logger.info("All packages already exist in inventory, nothing to create")
        return 0

    inventory_items = []
    for pkg in packages:
        item = SoftwareInventory(
            name=pkg["name"],
            version=pkg["version"],
            parentHardwareAssetId=asset_id,
        )
        inventory_items.append(item)

    try:
        created = SoftwareInventory.batch_create(inventory_items)
        count = len(created) if created else 0
        logger.info("Successfully created %d software inventory records for asset %d", count, asset_id)
        return count
    except Exception as e:
        logger.error("Error creating software inventory for asset %d: %s", asset_id, e)
        return 0


def _deduplicate_against_existing_models(asset_id: int, packages: List[Dict]) -> List[Dict]:
    """
    Deduplicate packages against existing software inventory for the asset.

    Uses the SoftwareInventory model to fetch existing records and filters out
    packages that already exist based on (name, version) tuple.

    :param int asset_id: RegScale Asset ID
    :param List[Dict] packages: List of package dictionaries
    :return: Filtered list of packages not in existing inventory
    :rtype: List[Dict]
    """
    logger.info("Fetching existing software inventory for asset %d", asset_id)

    try:
        app = Application()
        existing_items = SoftwareInventory.fetch_by_asset(app=app, asset_id=asset_id)

        existing_packages = {(item.name, item.version) for item in existing_items if item.name}
        logger.info("Found %d existing software inventory records", len(existing_packages))

        new_packages = [pkg for pkg in packages if (pkg["name"], pkg["version"]) not in existing_packages]

        duplicate_count = len(packages) - len(new_packages)
        logger.info("Deduplication removed %d existing packages", duplicate_count)
        return new_packages

    except Exception as e:
        logger.error("Error during deduplication: %s. Proceeding without deduplication.", e)
        return packages


def attach_sbom_as_evidence(
    api: Api,
    asset_id: int,
    sbom_data: Dict,
    file_name: Optional[str] = None,
) -> bool:
    """
    Attach SBOM file as evidence to a RegScale asset.

    Converts SBOM to JSON string and uploads as an attachment to the asset.

    :param Api api: RegScale API client
    :param int asset_id: RegScale Asset ID
    :param Dict sbom_data: CycloneDX SBOM JSON data
    :param Optional[str] file_name: Custom filename for attachment (default: auto-generated)
    :return: True if successful, False otherwise
    :rtype: bool

    Example:
        >>> api = Api()
        >>> sbom = {...}
        >>> success = attach_sbom_as_evidence(api, 123, sbom, "sbom-host-123.json")
    """
    import json
    from datetime import datetime

    try:
        # Generate filename if not provided
        if not file_name:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            file_name = f"prisma_sbom_{timestamp}.json"

        # Convert SBOM to JSON string
        sbom_json_str = json.dumps(sbom_data, indent=2)

        # Prepare file upload
        files = {"file": (file_name, sbom_json_str, "application/json")}
        data = {
            "parentId": asset_id,
            "parentModule": "assets",
            "name": file_name,
            "description": f"Prisma Cloud SBOM - CycloneDX {sbom_data.get('specVersion', 'unknown')}",
        }

        # Upload file
        response = api.post("/api/files", files=files, data=data)

        if response.status_code == 200 or response.status_code == 201:
            logger.info(f"Successfully attached SBOM as evidence: {file_name}")
            return True
        else:
            logger.error(f"Failed to attach SBOM: {response.status_code} - {response.text}")
            return False

    except Exception as e:
        logger.error(f"Error attaching SBOM as evidence: {e}")
        return False


def get_sbom_summary(sbom_data: Dict) -> Dict:
    """
    Generate a summary of SBOM contents.

    :param Dict sbom_data: CycloneDX SBOM JSON data
    :return: Summary dictionary with statistics
    :rtype: Dict

    Example:
        >>> summary = get_sbom_summary(sbom_data)
        >>> print(f"Total components: {summary['total_components']}")
    """
    components = sbom_data.get("components", [])

    # Count by type
    type_counts = {}
    license_counts = {}

    for component in components:
        comp_type = component.get("type", "unknown")
        type_counts[comp_type] = type_counts.get(comp_type, 0) + 1

        # Count licenses
        licenses = component.get("licenses", [])
        for lic in licenses:
            if isinstance(lic, dict):
                license_obj = lic.get("license", {})
                if isinstance(license_obj, dict):
                    license_name = license_obj.get("name", "Unknown")
                    license_counts[license_name] = license_counts.get(license_name, 0) + 1

    metadata = sbom_data.get("metadata", {})
    component_metadata = metadata.get("component", {})

    summary = {
        "total_components": len(components),
        "bom_format": sbom_data.get("bomFormat", ""),
        "spec_version": sbom_data.get("specVersion", ""),
        "timestamp": metadata.get("timestamp", ""),
        "target_name": component_metadata.get("name", ""),
        "target_version": component_metadata.get("version", ""),
        "type_breakdown": type_counts,
        "license_breakdown": license_counts,
    }

    return summary


def create_name_mappings(hosts_data: List[Dict], images_data: List[Dict], resource_type: str) -> Dict[str, str]:
    """
    Create SHA → Name mappings for SBOM correlation.

    Based on Platform One (P1) customer's get_name_maps() function.
    This function creates mappings from SBOM identifiers to human-readable names.

    :param List[Dict] hosts_data: List of host dictionaries from /api/v1/hosts
    :param List[Dict] images_data: List of image dictionaries from /api/v1/images
    :param str resource_type: "host" or "image"
    :return: Dict mapping SHA/ID → human-readable name
    :rtype: Dict[str, str]

    Example:
        >>> hosts = list(client.get_hosts())
        >>> images = list(client.get_images())
        >>> name_map = create_name_mappings(hosts, images, "image")
        >>> print(f"Mapped {len(name_map)} resources")
        >>> # Example: {"sha256:abc123": "registry.io/myapp:latest"}
    """
    if resource_type == "host":
        return _create_host_name_mappings(hosts_data)
    elif resource_type == "image":
        return _create_image_name_mappings(images_data)
    return {}


def _create_host_name_mappings(hosts_data: List[Dict]) -> Dict[str, str]:
    """Create name mappings for hosts."""
    name_map = {}
    for host in hosts_data:
        resource_id = host.get("_id", "")
        hostname = host.get("hostname", resource_id)
        if resource_id:
            name_map[resource_id] = hostname

    logger.info(f"Created name mappings for {len(name_map)} hosts")
    return name_map


def _create_image_name_mappings(images_data: List[Dict]) -> Dict[str, str]:
    """Create name mappings for images."""
    name_map = {}
    for image in images_data:
        sha = image.get("_id", "")
        if not sha:
            continue

        readable_name = _build_image_readable_name(image, sha)
        name_map[sha] = readable_name

    logger.info(f"Created name mappings for {len(name_map)} images")
    return name_map


def _build_image_readable_name(image: Dict, fallback_sha: str) -> str:
    """Build readable name for image from repoTag or imageName."""
    repo_tag = image.get("repoTag", {})
    registry = repo_tag.get("registry", "")
    repo = repo_tag.get("repo", "")
    tag = repo_tag.get("tag", "")

    if registry and repo:
        return f"{registry}/{repo}:{tag}" if tag else f"{registry}/{repo}"

    return image.get("imageName", fallback_sha)


def apply_name_mapping(sbom_map: Dict[str, Dict], name_map: Dict[str, str]) -> Dict[str, Dict]:
    """
    Apply name mappings to SBOM identifiers.

    Replaces SHA identifiers with human-readable names in the SBOM map.
    Based on Platform One (P1) customer workflow.

    :param Dict[str, Dict] sbom_map: Dict mapping resource identifier → SBOM data
    :param Dict[str, str] name_map: Dict mapping SHA/ID → human-readable name
    :return: SBOM map with readable names as keys
    :rtype: Dict[str, Dict]

    Example:
        >>> sbom_map = {"sha256:abc123": {...sbom_data...}}
        >>> name_map = {"sha256:abc123": "registry.io/myapp:latest"}
        >>> readable_sboms = apply_name_mapping(sbom_map, name_map)
        >>> # Result: {"registry.io/myapp:latest": {...sbom_data...}}
    """
    readable_sbom_map = {}
    unmapped_count = 0

    for resource_id, sbom_data in sbom_map.items():
        # Try to find readable name
        readable_name = name_map.get(resource_id)

        if readable_name:
            readable_sbom_map[readable_name] = sbom_data
            logger.debug(f"Mapped SBOM: {resource_id} → {readable_name}")
        else:
            # Keep original ID if no mapping found
            readable_sbom_map[resource_id] = sbom_data
            unmapped_count += 1
            logger.debug(f"No mapping found for SBOM: {resource_id}")

    if unmapped_count > 0:
        logger.warning(f"{unmapped_count} SBOMs could not be mapped to readable names")

    logger.info(f"Applied name mappings to {len(sbom_map)} SBOMs ({len(sbom_map) - unmapped_count} mapped)")
    return readable_sbom_map
