from typing import TYPE_CHECKING

from regscale import __version__
from regscale.integrations.commercial.tenablev2.constants import REGSCALE_CLI, REGSCALE_INC
from regscale.integrations.commercial.tenablev2.variables import TenableVariables
from regscale.integrations.variables import ScannerVariables

# Delay import of Tenable libraries
if TYPE_CHECKING:
    from tenable.io import TenableIO  # type: ignore
    from tenable.sc import TenableSC  # type: ignore


def gen_tio() -> "TenableIO":
    """
    Generate Tenable IO Object

    :return: Tenable IO client
    :rtype: "TenableIO"
    """

    from tenable.io import TenableIO

    return TenableIO(
        url=TenableVariables.tenableUrl.rstrip("/"),
        access_key=TenableVariables.tenableAccessKey,
        secret_key=TenableVariables.tenableSecretKey,
        vendor=REGSCALE_INC,
        product=REGSCALE_CLI,
        build=__version__,
    )


def gen_tsc() -> "TenableSC":
    """
    Generate Tenable SC Object

    Prefers SC-specific credentials (tenableScAccessKey, tenableScSecretKey, tenableScUrl)
    and falls back to the shared Tenable IO credentials if SC-specific ones are not configured.

    :return: Tenable SC client
    :rtype: "TenableSC"
    """

    from tenable.sc import TenableSC

    url = TenableVariables.tenableScUrl or TenableVariables.tenableUrl
    access_key = TenableVariables.tenableScAccessKey or TenableVariables.tenableAccessKey
    secret_key = TenableVariables.tenableScSecretKey or TenableVariables.tenableSecretKey

    return TenableSC(
        url=url.rstrip("/"),
        access_key=access_key,
        secret_key=secret_key,
        vendor=REGSCALE_INC,
        product=REGSCALE_CLI,
        build=__version__,
        ssl_verify=ScannerVariables.sslVerify,
    )
