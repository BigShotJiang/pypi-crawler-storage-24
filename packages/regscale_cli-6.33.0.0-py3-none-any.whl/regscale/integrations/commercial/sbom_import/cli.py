"""CLI command for generic SBOM file import."""

import json
import logging

import click

from regscale.integrations.commercial.sbom_import.importer import (
    SbomFileImporter,
    SbomFormatError,
    SbomValidationError,
)

logger = logging.getLogger("regscale")


@click.command("import_file")
@click.option(
    "--file-path",
    required=True,
    type=click.Path(exists=True),
    help="Path to SBOM JSON file (SPDX or CycloneDX)",
)
@click.option(
    "--parent-id",
    required=True,
    type=int,
    help="RegScale parent record ID",
)
@click.option(
    "--parent-module",
    required=True,
    type=str,
    help="Parent module (e.g., assets, components, securityPlans)",
)
@click.option(
    "--format",
    "sbom_format",
    type=click.Choice(["spdx", "cyclonedx", "auto"], case_sensitive=False),
    default="auto",
    show_default=True,
    help="SBOM format (default: auto-detect from file content)",
)
def import_file(file_path: str, parent_id: int, parent_module: str, sbom_format: str) -> None:
    """Import an SPDX or CycloneDX JSON file as an SBOM record in RegScale."""
    importer = SbomFileImporter(
        file_path=file_path,
        parent_id=parent_id,
        parent_module=parent_module,
        sbom_format=sbom_format,
    )
    try:
        sbom = importer.import_sbom()
        click.echo(f"SBOM '{sbom.name}' imported successfully (ID: {sbom.id})")
    except json.JSONDecodeError as exc:
        logger.error("File is not valid JSON: %s", exc)
        raise SystemExit(1) from exc
    except SbomFormatError as exc:
        logger.error("Format detection failed: %s", exc)
        raise SystemExit(1) from exc
    except SbomValidationError as exc:
        logger.error("Validation failed: %s", exc)
        for error in exc.errors:
            logger.error("  - %s", error)
        raise SystemExit(1) from exc
