#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""NIST Cybersecurity Framework (CSF) Handler for control ID parsing and matching."""

import re
from typing import Optional, Set

from regscale.integrations.framework_handlers.base import FrameworkHandler


class CSFHandler(FrameworkHandler):
    """
    Handler for NIST Cybersecurity Framework (CSF) control IDs.

    Formats supported:
    - CSF 2.0 functions: GV (Govern), ID (Identify), PR (Protect),
      DE (Detect), RS (Respond), RC (Recover)
    - Category format: ID.AM-1, PR.AC-1, DE.AE-1, GV.PO-1
    - Subcategory format: ID.AM-01, PR.AC-02
    """

    framework_name = "CSF"
    detection_pattern = r"^(ID|PR|DE|RS|RC|GV)\."
    detection_priority = 9  # Between OWASP (8) and NIST/SOC2/ISO (10)

    # Valid CSF function prefixes
    CSF_FUNCTIONS = {"ID", "PR", "DE", "RS", "RC", "GV"}

    def parse(self, control_string: str) -> Optional[str]:
        """
        Parse CSF control ID from string.

        :param str control_string: Raw control string
        :return: Parsed and normalized control ID or None
        :rtype: Optional[str]
        """
        if not control_string:
            return None

        control_string = control_string.strip().upper()

        # Match CSF format: FUNCTION.CATEGORY-NUMBER
        pattern = r"^(ID|PR|DE|RS|RC|GV)\.([A-Z]{2,4})-(\d+)"
        match = re.match(pattern, control_string)
        if not match:
            return None

        function = match.group(1)
        category = match.group(2)
        number = match.group(3)

        return self.normalize(f"{function}.{category}-{number}")

    def normalize(self, control_id: str) -> str:
        """
        Normalize CSF control ID.

        Removes leading zeros from the number portion.
        ID.AM-01 -> ID.AM-1

        :param str control_id: Control ID to normalize
        :return: Normalized control ID
        :rtype: str
        """
        control_id = control_id.strip().upper()

        pattern = r"^((?:ID|PR|DE|RS|RC|GV)\.[A-Z]{2,4})-(\d+)"
        match = re.match(pattern, control_id)
        if match:
            prefix = match.group(1)
            number = str(int(match.group(2)))
            return f"{prefix}-{number}"

        return control_id

    def get_variations(self, control_id: str) -> Set[str]:
        """
        Generate all CSF control ID variations.

        :param str control_id: Control ID to generate variations for
        :return: Set of all valid variations
        :rtype: Set[str]
        """
        parsed = self.parse(control_id)
        if not parsed:
            return set()

        pattern = r"^((?:ID|PR|DE|RS|RC|GV)\.[A-Z]{2,4})-(\d+)"
        match = re.match(pattern, parsed)
        if not match:
            return {parsed}

        prefix = match.group(1)
        number = int(match.group(2))

        return {
            f"{prefix}-{number}",
            f"{prefix}-{number:02d}",
        }

    def matches(self, control_id: str) -> bool:
        """
        Check if control ID matches CSF pattern.

        :param str control_id: Control ID to check
        :return: True if matches CSF pattern
        :rtype: bool
        """
        if not control_id:
            return False

        control_id = control_id.strip().upper()
        return bool(re.match(r"^(ID|PR|DE|RS|RC|GV)\.[A-Z]{2,4}-\d+", control_id))
