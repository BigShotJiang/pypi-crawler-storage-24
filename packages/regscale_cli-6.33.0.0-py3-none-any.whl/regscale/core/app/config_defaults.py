#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Default configuration values for the RegScale CLI.

This module contains the default configuration template and placeholder constants
used throughout the application. The template defines all supported configuration
keys and their default values.

Usage:
    from regscale.core.app.config_defaults import get_default_template, DEFAULT_CONFIG_TEMPLATE

    # Get a fresh copy of the template (recommended for modification)
    template = get_default_template()

    # Or access the frozen template directly (read-only)
    from regscale.core.app.config_defaults import DEFAULT_CONFIG_TEMPLATE
"""

import copy
import os
from types import MappingProxyType
from typing import Any, Dict, Set


# =============================================================================
# Empty Dict Validation
# =============================================================================
def _find_empty_dicts(d: Dict[str, Any], parent_key: str = "") -> Set[str]:
    """
    Recursively find all keys that have empty dict {} as their value.

    Empty dicts in config defaults break encryption and should never be used.
    Use None or a placeholder string instead.

    :param d: Dictionary to check
    :param parent_key: Parent key path for nested dicts
    :return: Set of key paths with empty dict values
    """
    empty_keys: Set[str] = set()
    for key, value in d.items():
        full_key = f"{parent_key}.{key}" if parent_key else key
        if isinstance(value, dict):
            if not value:
                empty_keys.add(full_key)
            else:
                empty_keys.update(_find_empty_dicts(value, full_key))
    return empty_keys


def _validate_config_template(template: Dict[str, Any]) -> None:
    """
    Validate that the config template has no empty dict values.

    This runs at module load time to catch issues early during development.
    Empty dicts break encryption and should never be used in config defaults.

    :param template: The config template to validate
    :raises ValueError: If empty dict values are found
    """
    empty_keys = _find_empty_dicts(template)
    if empty_keys:
        raise ValueError(
            f"Config template contains empty dict values at keys: {sorted(empty_keys)}. "
            "Empty dicts break encryption. Use None or a placeholder string instead."
        )


# =============================================================================
# ExampleConfig Marker Class
# =============================================================================
class ExampleConfig(dict):
    """
    Marker class for example/placeholder config dicts.

    Use this to wrap config dicts that serve as examples or templates for users.
    These configs contain placeholder values that users should replace with their own.

    Merge behavior (in Config._merge_dicts):
    - If user has NO value for this key: add the example dict as a starting point
    - If user HAS a value: don't merge into it (user owns their config entirely)

    This prevents example placeholders from polluting user-defined configs like
    dynamic filters or custom mappings.

    Example:
        # In template
        "csamFilter": ExampleConfig({"Id": "YOUR_CSAM_SYSTEM_ID"}),

        # User has their own filter - example NOT merged in
        user_config = {"csamFilter": {"organization": "MGMT"}}
        # Result: {"csamFilter": {"organization": "MGMT"}}  # No "Id" added

        # User has no filter - example IS added
        user_config = {}
        # Result: {"csamFilter": {"Id": "YOUR_CSAM_SYSTEM_ID"}}
    """

    pass


def sanitize_for_yaml(obj: Any) -> Any:
    """
    Recursively convert ExampleConfig instances to plain dicts for safe YAML serialization.

    Call this before every yaml.dump() to ensure no ExampleConfig marker classes
    leak into the YAML output.

    :param Any obj: Object to sanitize (typically the config dict)
    :return: Sanitized object safe for yaml.dump()
    :rtype: Any
    """
    if isinstance(obj, dict):
        return {k: sanitize_for_yaml(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [sanitize_for_yaml(item) for item in obj]
    return obj


# =============================================================================
# Placeholder Constants
# =============================================================================
# These placeholders indicate values that need to be configured by the user
# or are populated programmatically at runtime.

DEFAULT_CLIENT = "YOUR_CLIENT_ID"
DEFAULT_SECRET = "YOUR_SECRET"
DEFAULT_POPULATED = "YOUR_PROGRAMMATIC_VALUE"
DEFAULT_TENANT = "YOUR_TENANT_ID"

# =============================================================================
# Issue Due Date Configurations by Integration
# =============================================================================
# These define the default number of days until an issue is due based on severity.
# Status indicates the default issue status when created.
# minimumSeverity filters which severities to process.
# useKev indicates whether to use CISA KEV dates to override due dates.

ISSUE_DEFAULTS_AQUA = MappingProxyType(
    {
        "critical": 30,
        "high": 30,
        "moderate": 90,
        "low": 180,
        "status": "Open",
        "minimumSeverity": "low",
        "useKev": True,
    }
)

ISSUE_DEFAULTS_AWS = MappingProxyType(
    {
        "high": 30,
        "low": 365,
        "moderate": 90,
        "status": "Open",
        "minimumSeverity": "low",
        "useKev": True,
    }
)

ISSUE_DEFAULTS_AXONIUS = MappingProxyType(
    {
        "critical": 15,
        "high": 30,
        "moderate": 90,
        "low": 180,
    }
)

ISSUE_DEFAULTS_DEFENDER365 = MappingProxyType(
    {
        "high": 30,
        "low": 365,
        "moderate": 90,
        "status": "Open",
    }
)

ISSUE_DEFAULTS_DEFENDER_CLOUD = MappingProxyType(
    {
        "high": 30,
        "low": 365,
        "moderate": 90,
        "status": "Open",
    }
)

ISSUE_DEFAULTS_DEFENDER_FILE = MappingProxyType(
    {
        "high": 30,
        "low": 365,
        "moderate": 90,
        "status": "Open",
        "useKev": True,
    }
)

ISSUE_DEFAULTS_ECR = MappingProxyType(
    {
        "critical": 30,
        "high": 30,
        "moderate": 90,
        "low": 180,
        "status": "Open",
        "minimumSeverity": "low",
        "useKev": True,
    }
)

ISSUE_DEFAULTS_JIRA = MappingProxyType(
    {
        "highest": 7,
        "high": 30,
        "medium": 90,
        "low": 180,
        "lowest": 365,
        "status": "Open",
    }
)

ISSUE_DEFAULTS_QUALYS = MappingProxyType(
    {
        "high": 30,
        "moderate": 90,
        "low": 365,
        "status": "Open",
        "useKev": True,
    }
)

ISSUE_DEFAULTS_SALESFORCE = MappingProxyType(
    {
        "critical": 7,
        "high": 30,
        "medium": 90,
        "low": 365,
        "status": "Open",
    }
)

ISSUE_DEFAULTS_SNYK = MappingProxyType(
    {
        "critical": 30,
        "high": 30,
        "moderate": 90,
        "low": 180,
        "status": "Open",
        "minimumSeverity": "low",
        "useKev": True,
    }
)

ISSUE_DEFAULTS_SONARCLOUD = MappingProxyType(
    {
        "blocker": 7,
        "critical": 30,
        "major": 90,
        "minor": 365,
        "status": "Open",
    }
)

ISSUE_DEFAULTS_NEXPOSE = MappingProxyType(
    {
        "critical": 30,
        "high": 30,
        "moderate": 90,
        "low": 180,
        "status": "Open",
        "minimumSeverity": "low",
        "useKev": True,
    }
)

ISSUE_DEFAULTS_PRISMA = MappingProxyType(
    {
        "critical": 30,
        "high": 30,
        "moderate": 90,
        "low": 180,
        "status": "Open",
        "minimumSeverity": "low",
        "useKev": True,
    }
)

ISSUE_DEFAULTS_TANIUM_CLOUD = MappingProxyType(
    {
        "critical": 30,
        "high": 30,
        "moderate": 90,
        "low": 180,
    }
)

ISSUE_DEFAULTS_TENABLE = MappingProxyType(
    {
        "critical": 30,
        "high": 30,
        "moderate": 90,
        "low": 180,
        "status": "Open",
        "useKev": False,
    }
)

ISSUE_DEFAULTS_WIZ = MappingProxyType(
    {
        "critical": 30,
        "high": 90,
        "low": 365,
        "medium": 90,
        "status": "Open",
        "minimumSeverity": "low",
    }
)

ISSUE_DEFAULTS_XRAY = MappingProxyType(
    {
        "critical": 30,
        "high": 30,
        "moderate": 90,
        "low": 180,
        "status": "Open",
        "minimumSeverity": "low",
        "useKev": True,
    }
)

ISSUE_DEFAULTS_VERACODE = MappingProxyType(
    {
        "critical": 30,
        "high": 30,
        "moderate": 90,
        "low": 180,
        "status": "Open",
        "minimumSeverity": "low",
        "useKev": False,
    }
)

# Combined issue defaults for all integrations
ISSUE_DEFAULTS_ALL = MappingProxyType(
    {
        "aqua": dict(ISSUE_DEFAULTS_AQUA),
        "aws": dict(ISSUE_DEFAULTS_AWS),
        "axonius": dict(ISSUE_DEFAULTS_AXONIUS),
        "defender365": dict(ISSUE_DEFAULTS_DEFENDER365),
        "defenderCloud": dict(ISSUE_DEFAULTS_DEFENDER_CLOUD),
        "defenderFile": dict(ISSUE_DEFAULTS_DEFENDER_FILE),
        "ecr": dict(ISSUE_DEFAULTS_ECR),
        "jira": dict(ISSUE_DEFAULTS_JIRA),
        "qualys": dict(ISSUE_DEFAULTS_QUALYS),
        "salesforce": dict(ISSUE_DEFAULTS_SALESFORCE),
        "snyk": dict(ISSUE_DEFAULTS_SNYK),
        "sonarcloud": dict(ISSUE_DEFAULTS_SONARCLOUD),
        "nexpose": dict(ISSUE_DEFAULTS_NEXPOSE),
        "prisma": dict(ISSUE_DEFAULTS_PRISMA),
        "tanium_cloud": dict(ISSUE_DEFAULTS_TANIUM_CLOUD),
        "tenable": dict(ISSUE_DEFAULTS_TENABLE),
        "wiz": dict(ISSUE_DEFAULTS_WIZ),
        "xray": dict(ISSUE_DEFAULTS_XRAY),
        "veracode": dict(ISSUE_DEFAULTS_VERACODE),
    }
)

# =============================================================================
# Finding Field Mapping Defaults
# =============================================================================
FINDING_FROM_MAPPING_DEFAULTS = MappingProxyType(
    {
        "aqua": MappingProxyType(
            {
                "remediation": "default",
                "title": "default",
                "description": "default",
            }
        ),
        "tenable_sc": MappingProxyType(
            {
                "remediation": "default",
                "title": "default",
                "description": "default",
            }
        ),
    }
)

# =============================================================================
# CSAM Configuration Defaults
# =============================================================================
# These define the default CSAM integration configuration values.
# Users should replace placeholder values with their actual CSAM settings.

CSAM_FILTER_DEFAULTS = MappingProxyType(
    {
        "Id": "YOUR_CSAM_SYSTEM_ID",
    }
)

CSAM_AGENCY_DEFINED_DEFAULTS = MappingProxyType(
    {
        "AI-ML": "YOUR_AI_ML_MAPPING",
    }
)

CSAM_FRAMEWORK_CATALOG_DEFAULTS = MappingProxyType(
    {
        "800-53R5": "YOUR_FRAMEWORK_CATALOG_ID",
    }
)


# =============================================================================
# Default Configuration Template
# =============================================================================
# This is the master configuration template containing all supported keys
# and their default values. Use get_default_template() to get a mutable copy.


def _build_config_template() -> Dict[str, Any]:
    """
    Build the default configuration template.

    This function constructs the template dynamically to handle
    any runtime-dependent values (like paths).

    :return: Default configuration template dictionary
    :rtype: Dict[str, Any]
    """
    # Handle the wizStigMapperFile path - create artifacts dir if needed
    artifacts_dir = os.path.join(os.getcwd(), "artifacts")
    os.makedirs(artifacts_dir, exist_ok=True)
    wiz_stig_mapper_file = os.path.join(artifacts_dir, "stig_mapper_rules.json")

    return {
        # STIG Configuration
        "stigBatchSize": 100,
        # Azure AD Configuration
        "adAccessToken": DEFAULT_POPULATED,
        "adAuthUrl": "https://login.microsoftonline.com/",
        "adClientId": DEFAULT_CLIENT,
        "adClientSecret": DEFAULT_SECRET,
        "adGraphUrl": "https://graph.microsoft.com/.default",
        "adTenantId": DEFAULT_TENANT,
        # Assessment Configuration
        "assessmentDays": 10,
        # Axonius Configuration
        "axoniusAccessToken": "YOUR_AXONIUS_ACCESS_TOKEN",
        "axoniusApiKey": "YOUR_AXONIUS_V2_API_KEY",
        "axoniusApiSecret": "YOUR_AXONIUS_V2_API_SECRET",
        "axoniusPageSize": 2000,
        "axoniusSecretToken": "YOUR_AXONIUS_SECRET_TOKEN",
        "axoniusTimeout": 120,
        "axoniusUrl": "YOUR_AXONIUS_URL",
        "axoniusVerifySsl": True,
        # Azure 365 Configuration
        "azure365AccessToken": DEFAULT_POPULATED,
        "azure365ClientId": DEFAULT_CLIENT,
        "azure365Secret": DEFAULT_SECRET,
        "azure365TenantId": DEFAULT_TENANT,
        # Azure Cloud Configuration
        "azureCloudAccessToken": DEFAULT_POPULATED,
        "azureCloudClientId": DEFAULT_CLIENT,
        "azureCloudSecret": DEFAULT_SECRET,
        "azureCloudTenantId": DEFAULT_TENANT,
        "azureCloudSubscriptionId": "YOUR_SUBSCRIPTION_ID",
        # Azure Entra Configuration
        "azureEntraAccessToken": DEFAULT_POPULATED,
        "azureEntraClientId": DEFAULT_CLIENT,
        "azureEntraSecret": DEFAULT_SECRET,
        "azureEntraTenantId": DEFAULT_TENANT,
        # CISA KEV Configuration
        "cisaKev": "https://www.cisa.gov/sites/default/files/feeds/known_exploited_vulnerabilities.json",
        # Compliance Configuration
        "complianceCreation": "Assessment",
        # CrowdStrike Configuration
        "crowdstrikeClientId": DEFAULT_CLIENT,
        "crowdstrikeClientSecret": DEFAULT_SECRET,
        "crowdstrikeBaseUrl": "YOUR_CROWDSTRIKE_API_URL",
        # CSAM Configuration
        "csamToken": DEFAULT_SECRET,
        "csamURL": "YOUR_CSAM_URL",
        "csamArtifactTypes": "YOUR_CSAM_ARTIFACT_TYPES",
        # These are marked as ExampleConfig because they are user-defined mapping dicts
        # where users add their own keys. If user has their own config, don't merge examples.
        "csamFilter": ExampleConfig(CSAM_FILTER_DEFAULTS),
        "csamAgencyDefinedDataItems": ExampleConfig(CSAM_AGENCY_DEFINED_DEFAULTS),
        "csamFrameworkCatalog": ExampleConfig(CSAM_FRAMEWORK_CATALOG_DEFAULTS),
        # Databricks Configuration
        "databricksHostname": "YOUR_DATABRICKS_SQL_HOSTNAME",
        "databricksPath": "YOUR_DATABRICKS_HTTP_PATH",
        "databricksAccessToken": "YOUR_DATABRICKS_PAT",
        # Dependabot Configuration
        "dependabotId": "YOUR_GITHUB_USER_ID",
        "dependabotOwner": "YOUR_GITHUB_REPO_OWNER",
        "dependabotRepo": "YOUR_GITHUB_REPO_NAME",
        "dependabotToken": "YOUR_GITHUB_PERSONAL_ACCESS_TOKEN",
        # RegScale Domain Configuration
        "domain": "https://regscale.yourcompany.com/",
        "disableCache": False,
        # Evidence Configuration
        "evidenceFolder": "./evidence",
        # Scoring Configuration
        "passScore": 80,
        "failScore": 30,
        # GCP Configuration
        "gcpCredentials": "YOUR_GCP_CREDENTIALS_PATH",
        "gcpOrganizationId": "YOUR_GCP_ORGANIZATION_ID",
        "gcpProjectId": "YOUR_GCP_PROJECT_ID",
        "gcpScanType": "YOUR_GCP_SCAN_TYPE",
        # GitHub Configuration
        "githubDomain": "api.github.com",
        # Issue Creation Configuration
        "issueCreation": "Consolidated",
        "issues": {
            "kevDueDate": 14,
            "aqua": dict(ISSUE_DEFAULTS_AQUA),
            "aws": dict(ISSUE_DEFAULTS_AWS),
            "axonius": dict(ISSUE_DEFAULTS_AXONIUS),
            "defender365": dict(ISSUE_DEFAULTS_DEFENDER365),
            "defenderCloud": dict(ISSUE_DEFAULTS_DEFENDER_CLOUD),
            "defenderFile": dict(ISSUE_DEFAULTS_DEFENDER_FILE),
            "ecr": dict(ISSUE_DEFAULTS_ECR),
            "jira": dict(ISSUE_DEFAULTS_JIRA),
            "qualys": dict(ISSUE_DEFAULTS_QUALYS),
            "salesforce": dict(ISSUE_DEFAULTS_SALESFORCE),
            "snyk": dict(ISSUE_DEFAULTS_SNYK),
            "sonarcloud": dict(ISSUE_DEFAULTS_SONARCLOUD),
            "nexpose": dict(ISSUE_DEFAULTS_NEXPOSE),
            "prisma": dict(ISSUE_DEFAULTS_PRISMA),
            "tanium_cloud": dict(ISSUE_DEFAULTS_TANIUM_CLOUD),
            "tenable": dict(ISSUE_DEFAULTS_TENABLE),
            "wiz": dict(ISSUE_DEFAULTS_WIZ),
            "xray": dict(ISSUE_DEFAULTS_XRAY),
            "veracode": dict(ISSUE_DEFAULTS_VERACODE),
        },
        # AWS Integration Configuration
        "awsAccessKeyId": "YOUR_AWS_ACCESS_KEY_ID",
        "awsSecretAccessKey": "YOUR_AWS_SECRET_ACCESS_KEY",
        "aws": {
            "inventory": {
                "enabled_services": {
                    "compute": {
                        "enabled": True,
                        "services": {
                            "ec2": True,
                            "ecs": True,
                            "lambda": True,
                            "systems_manager": True,
                        },
                    },
                    "containers": {
                        "enabled": True,
                        "services": {
                            "ecr": True,
                        },
                    },
                    "database": {
                        "enabled": True,
                        "services": {
                            "dynamodb": True,
                            "rds": True,
                        },
                    },
                    "integration": {
                        "enabled": True,
                        "services": {
                            "api_gateway": True,
                            "eventbridge": True,
                            "sns": True,
                            "sqs": True,
                        },
                    },
                    "networking": {
                        "enabled": True,
                        "services": {
                            "cloudfront": True,
                            "elastic_ips": True,
                            "load_balancers": True,
                            "route53": True,
                            "vpc": True,
                        },
                    },
                    "security": {
                        "enabled": True,
                        "services": {
                            "acm": True,
                            "audit_manager": True,
                            "cloudtrail": True,
                            "config": True,
                            "guardduty": True,
                            "iam": True,
                            "inspector": True,
                            "kms": True,
                            "secrets_manager": True,
                            "securityhub": True,
                            "waf": True,
                        },
                    },
                    "storage": {
                        "enabled": True,
                        "services": {
                            "ebs": True,
                            "s3": True,
                        },
                    },
                },
            },
        },
        # Jira Configuration
        "jiraApiToken": "YOUR_JIRA_API_TOKEN",
        "jiraUrl": "YOUR_JIRA_URL",
        "jiraUserName": "YOUR_JIRA_USERNAME",
        # Threading Configuration
        "maxThreads": 1000,
        # NIST Configuration
        "nistCpeApiKey": "YOUR_NIST_CPE_API_KEY",
        # Okta Configuration
        "oktaApiToken": "Can be a SSWS token from Okta or created programmatically",
        "oktaClientId": "YOUR_OKTA_CLIENT_ID",
        "oktaUrl": "YOUR_OKTA_URL",
        # OSCAL Configuration
        "oscalLocation": "/opt/OSCAL",
        # POAM Configuration
        "poamTitleType": "Cve",
        # PowerShell Configuration
        "pwshPath": "/opt/microsoft/powershell/7/pwsh",
        # Prisma Cloud Configuration
        "prismaApiRetries": 3,
        "prismaApiTimeout": 30,
        "prismaConsoleUrl": "YOUR_PRISMA_CONSOLE_URL",
        "prismaDeduplicateFindings": True,
        "prismaDeduplicationMode": "by_asset",
        "prismaDefaultFilters": '{"collections": []}',
        "prismaEnableSoftwareInventory": False,
        "prismaPageSize": 50,
        "prismaPassword": "YOUR_PRISMA_PASSWORD",
        "prismaUsername": "YOUR_PRISMA_USERNAME",
        "prismaVerifySsl": True,
        # Qualys Configuration
        "qualysUrl": "https://yourcompany.qualys.com/api/2.0/fo/scan/",
        "qualysUserName": "YOUR_QUALYS_USERNAME",
        "qualysPassword": "YOUR_QUALYS_PASSWORD",
        # Sicura Configuration
        "sicuraUrl": "YOUR_SICURA_URL",
        "sicuraToken": "YOUR_SICURA_TOKEN",
        # Salesforce Configuration
        "salesforceUserName": "YOUR_SALESFORCE_USERNAME",
        "salesforcePassword": "YOUR_SALESFORCE_PASSWORD",
        "salesforceToken": "YOUR_SALESFORCE_SECURITY_TOKEN",
        # ServiceNow Configuration
        "snowPassword": "YOUR_SERVICENOW_PASSWORD",
        "snowUrl": "YOUR_SERVICENOW_URL",
        "snowUserName": "YOUR_SERVICENOW_USERNAME",
        # SonarCloud Configuration
        "sonarUrl": "https://sonarcloud.io",
        "sonarToken": "YOUR_SONAR_TOKEN",
        # Tenable Configuration
        "tenableAccessKey": "YOUR_TENABLE_ACCESS_KEY",
        "tenableSecretKey": "YOUR_TENABLE_SECRET_KEY",
        "tenableUrl": "https://sc.tenalab.online",
        "tenableMinimumSeverityFilter": "low",
        "tenableGroupByPlugin": False,
        # RegScale Authentication
        "token": DEFAULT_POPULATED,
        "userId": "enter RegScale user id here",
        # Feature Flags
        "useMilestones": False,
        "preventAutoClose": False,
        # AlienVault OTX Configuration
        "otx": "enter AlienVault API key here",
        # Vulnerability Configuration
        "vulnerabilityCreation": "NoIssue",
        # Wiz Configuration
        "wizAccessToken": DEFAULT_POPULATED,
        "wizAuthUrl": "https://auth.wiz.io/oauth/token",
        "wizExcludes": "My things to exclude here",
        "wizScope": "YOUR_WIZ_SCOPE",
        "wizUrl": "YOUR_WIZ_URL",
        "wizReportAge": 15,
        "wizLastInventoryPull": "YOUR_WIZ_LAST_INVENTORY_PULL",
        "wizInventoryFilterBy": "YOUR_WIZ_INVENTORY_FILTER",
        "wizIssueFilterBy": "YOUR_WIZ_ISSUE_FILTER",
        "wizVulnerabilitiesFilterBy": "YOUR_WIZ_VULNERABILITIES_FILTER",
        "wizFullPullLimitHours": 8,
        "wizStigMapperFile": wiz_stig_mapper_file,
        # Timeout Configuration
        "timeout": 60,
        # Finding Mapping Configuration
        "findingFromMapping": {
            "aqua": {
                "remediation": "default",
                "title": "default",
                "description": "default",
            },
            "tenable_sc": {
                "remediation": "default",
                "title": "default",
                "description": "default",
            },
        },
    }


def get_default_template() -> Dict[str, Any]:
    """
    Get a fresh, mutable copy of the default configuration template.

    This function returns a deep copy of the template, safe for modification.
    Use this when you need to modify the template or merge it with user config.

    :return: A mutable copy of the default configuration template
    :rtype: Dict[str, Any]

    Example:
        >>> template = get_default_template()
        >>> template["maxThreads"] = 500  # Safe to modify
    """
    return copy.deepcopy(_build_config_template())


# Expose a frozen version of the template for read-only access
# Note: This is built once at module import time
DEFAULT_CONFIG_TEMPLATE = _build_config_template()

# Validate template at module load time - fails fast if empty dicts are present
# This catches developer mistakes early during development/testing
_validate_config_template(DEFAULT_CONFIG_TEMPLATE)
