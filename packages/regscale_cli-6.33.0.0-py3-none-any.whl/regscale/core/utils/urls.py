"""Provide simple functions for interacting with URLs."""

import logging
from os import getenv
from re import match
from urllib.parse import urlparse

from regscale.core.static.regex import URL_REGEX

_LOCALHOST_HOSTS = {"localhost", "127.0.0.1", "::1"}


def warn_ssl_disabled(url: str, verify_ssl: bool, logger: logging.Logger) -> None:
    """Warn when SSL verification is disabled for a non-localhost URL.

    :param str url: The URL being connected to
    :param bool verify_ssl: Whether SSL verification is enabled
    :param logging.Logger logger: Logger to use for the warning
    """
    if verify_ssl:
        return
    host = urlparse(url or "").hostname or ""
    if host not in _LOCALHOST_HOSTS:
        logger.warning(
            "SSL verification is disabled (verify_ssl=False) for non-localhost URL '%s'. "
            "This is a security risk - enable SSL verification in production environments.",
            url,
        )


def generate_regscale_domain_url(
    domain: str = getenv("REGSCALE_DOMAIN"),
) -> str:
    """Generate a RegScale domain url

    :param str domain: The domain to use, defaults to getenv("REGSCALE_DOMAIN")
    :raises EnvironmentError: if domain is None
    :return: The domain url
    :rtype: str
    """
    if domain is None:
        raise EnvironmentError("The `REGSCALE_DOMAIN` envar needs set or pass domain arg.")
    if match(URL_REGEX, domain) is not None:
        return domain
    return f"https://{domain}.regscale.io"
