#!/usr/bin/env python
#MCP server for interfacing with smartbill.ro for conducting financial operations
from urllib.request import urlopen, Request
from urllib.error import HTTPError
import mcp.server.fastmcp
import mcp.types
import logging
import json
import os
import base64

logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

SMARTBILL_BASE_URL = "https://ws.smartbill.ro/SBORO/api"
SMARTBILL_BILL_ID = "cif={cif}&seriesname={series}&number={number}"
SMARTBILL_PAYMENT_STATUS_URL = SMARTBILL_BASE_URL + "/invoice/paymentstatus?" + SMARTBILL_BILL_ID
SMARTBILL_GET_BILL_URL = SMARTBILL_BASE_URL + "/invoice/pdf?" + SMARTBILL_BILL_ID
SMARTBILL_TYPE_F = "f"
SMARTBILL_TYPE_C = "c"
SMARTBILL_TYPE_P = "p"
SMARTBILL_TYPE_ID = "cif={cif}&type={type}"
#https://api.smartbill.ro/#!/Configurari/getAllSeries
SMARTBILL_SERIES_URL = SMARTBILL_BASE_URL + "/series?" + SMARTBILL_TYPE_ID

def _build_auth() -> str:
    username = os.environ["SMARTBILL_USERNAME"]
    token = os.environ["SMARTBILL_TOKEN"]
    return base64.b64encode(f"{username}:{token}".encode()).decode()

mymcp = mcp.server.fastmcp.FastMCP("SmartBill Interface Server")

@mymcp.tool()
def _get_payment_status(cif: str, series: str, number: int) -> tuple[float, float, float]:
    """Get the payment status for a bill.

    Returns total amount, paid amount and unpaid amount.
    """
    logger.debug(f"_get_payment_status for bill with cif: {cif}, series: {series} and number: {number}")
    url = SMARTBILL_PAYMENT_STATUS_URL.format(cif=cif, series=series, number=number)
    req = Request(url, headers={
        "Accept": "application/json",
        "Authorization": f"Basic {_build_auth()}",
    })
    try:
        with urlopen(req) as response:
            data = response.read()
            logger.debug(f"Received answer: {data}")
            json_data = json.loads(data)
            total_amount = float(json_data["invoiceTotalAmount"])
            logger.debug(f"Answer contains total amount: {total_amount}")
            paid_amount = float(json_data["paidAmount"])
            logger.debug(f"Answer contains paid amount: {paid_amount}")
            unpaid_amount = float(json_data["unpaidAmount"])
            logger.debug(f"Answer contains unpaid amount: {unpaid_amount}")
            return total_amount, paid_amount, unpaid_amount
    except HTTPError as e:
        logger.error(f"HTTP error {e.code} for URL {url}: {e.reason}")
        raise

@mymcp.tool()
def _get_bill(cif: str, series: str, number: str) -> mcp.types.BlobResourceContents:
    """Get a bill.

    Returns the bill in PDF format as a blob.
    """
    logger.debug(f"_get_bill for bill with cif: {cif}, series: {series} and number: {number}")
    url = SMARTBILL_GET_BILL_URL.format(cif=cif, series=series, number=number)
    req = Request(url, headers={
        "Accept": "application/octet-stream",
        "Authorization": f"Basic {_build_auth()}",
        "Content-Disposition": "attachment; filename=\"bill.pdf\"",
    })
    try:
        with urlopen(req) as response:
            bill = response.read()
            logger.debug(f"Received {len(bill)} bytes")
            return mcp.types.BlobResourceContents(
                uri=url,
                blob=base64.b64encode(bill).decode(),
                mimeType="application/pdf",
            )
    except HTTPError as e:
        logger.error(f"HTTP error {e.code} for URL {url}: {e.reason}")
        raise

@mymcp.tool()
def _get_next_invoice_number(cif: str, year: int) -> int:
    """Get the next invoice number for a given CIF and year.

    Returns the next available number for the bills from that year.
    """
    logger.debug(f"_get_next_invoice_number for cif: {cif}, year: {year}")
    url = SMARTBILL_SERIES_URL.format(cif=cif, type=SMARTBILL_TYPE_F)
    req = Request(url, headers={
        "Accept": "application/json",
        "Authorization": f"Basic {_build_auth()}",
    })
    try:
        with urlopen(req) as response:
            data = response.read()
            logger.debug(f"Received answer: {data}")
            json_data = json.loads(data)
            series_list = json_data.get("list") or []
            for entry in series_list:
                name = entry.get("name", "")
                if name.endswith(str(year)):
                    return entry["nextNumber"]
            raise ValueError(f"No series found for year {year}")
    except HTTPError as e:
        logger.error(f"HTTP error {e.code} for URL {url}: {e.reason}")
        raise

def main():
    """Entry point for the SmartBill MCP server."""
    missing = [v for v in ("SMARTBILL_USERNAME", "SMARTBILL_TOKEN") if not os.environ.get(v)]
    if missing:
        logger.error(f"Missing required environment variables: {', '.join(missing)}")
        return
    mymcp.run(transport="stdio")

if __name__ == "__main__":
    main()
