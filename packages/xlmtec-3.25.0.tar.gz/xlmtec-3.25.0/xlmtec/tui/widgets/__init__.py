"""TUI widgets package."""
