import pytest

from matterlab_balances import MTXPRBalance
from matterlab_balances.mt_balance import WeighingCaptureMode


@pytest.mark.real
def test_mt_real_connect_and_read_weight(hardware_host, hardware_port, hardware_password):
    balance = MTXPRBalance(
        host=hardware_host,
        port=hardware_port,
        password=hardware_password,
    )
    try:
        value, unit, stable = balance.get_weight(capture_mode=WeighingCaptureMode.IMMEDIATE)
        assert isinstance(value, float)
        assert isinstance(unit, str)
        assert isinstance(stable, bool)
    finally:
        balance.close_session()
