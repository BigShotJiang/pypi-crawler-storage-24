from matterlab_balances import SartoriusBalance, create_sartorius_sim_transport_factory


def test_sartorius_transport_sim_uses_public_api():
    transport_factory = create_sartorius_sim_transport_factory(weight=1.234, stable=True)
    balance = SartoriusBalance(com_port="SIM::sartorius", transport_factory=transport_factory)

    assert balance.weigh(stable=False) == 1.234
    assert balance.weigh(stable=True) == 1.234
    balance.tare()
    assert transport_factory.state.weight == 0.0
    assert balance.weigh(stable=True) == 0.0


def test_sartorius_transport_sim_supports_unstable_reads():
    transport_factory = create_sartorius_sim_transport_factory(weight=0.456, stable=False)
    balance = SartoriusBalance(com_port="SIM::sartorius", transport_factory=transport_factory)

    assert balance.weigh(stable=False) == 0.456
