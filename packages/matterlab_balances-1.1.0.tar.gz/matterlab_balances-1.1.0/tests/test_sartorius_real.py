import pytest

from matterlab_balances import SartoriusBalance


@pytest.mark.real
def test_sartorius_real_weigh(hardware_com_port):
    balance = SartoriusBalance(com_port=hardware_com_port)

    assert isinstance(balance.weigh(stable=False), float)


@pytest.mark.real
def test_sartorius_real_tare(hardware_com_port):
    balance = SartoriusBalance(com_port=hardware_com_port)

    balance.tare(stable=False)
