from abc import ABC, abstractmethod
from logging import Logger, getLogger
from typing import Optional


class Balance(ABC):
    """
    Abstract Base Class for handling different kinds of syringe pumps.
    """
    category="Balance"
    ui_fields  = ("com_port")
    def __init__(self, logger: Optional[Logger] = None):
        self.logger = logger if logger is not None else getLogger(
            f"{self.__class__.__module__}.{self.__class__.__name__}"
        )

    @abstractmethod
    def weigh(self, stable: bool = True) -> float:
        """
        abstract method to get weight of the balance
        :param stable:  if wait until the balance is stable
        :return:
        """
        pass

    @abstractmethod
    def tare(self, stable: bool = True):
        """
        abstract method to tare a balance
        :param stable: if wait until balance is stable
        :return:
        """
        pass
