from typing import Any, Callable, Dict

def 值映射(
    数据: Dict[str, Any],
    处理函数: Callable[[Any], Any]
) -> Dict[str, Any]:
    """对字典中的所有值应用同一个转换函数，并返回新字典。

    功能说明:
        - 这个函数用于对字典中的所有值应用同一个转换函数，并返回新字典。
        - 它会把原始字典整理成更容易继续使用的结果，适合做数据预处理。
        - 当输入不符合要求时，函数会返回空字典或约定结果，避免程序因为异常中断。

    Args:
        数据 (dict): 原始字典对象。
        处理函数 (Callable[[Any], Any]): 值转换函数。
        - 示例： str
        - 示例： lambda 值: 值 * 2

    Returns:
        dict[str, Any]:
        - 成功：返回值处理后的新字典；
        - 失败：返回空字典 {}。"""
    try:
        if not isinstance(数据, dict):
            return {}

        if not callable(处理函数):
            return {}

        return {
            str(键): 处理函数(值)
            for 键, 值 in 数据.items()
        }
    except Exception:
        return {}


if __name__ == "__main__":
    print("===== 示例1：基础用法 =====")
    数据 = {"名称": "zfx", "年龄": 18, "城市": "上海"}
    处理函数 = lambda 值: str(值)
    print("结果:", 值映射(数据, 处理函数))
    print("数据:", 数据)

    print("\n===== 示例2：常见变体 =====")
    数据 = {"name": "zfx", "phone": None, "items": [1, 2]}
    处理函数 = lambda 值: 值 if isinstance(值, int) else 0
    print("结果:", 值映射(数据, 处理函数))
    print("数据:", 数据)

    print("\n===== 示例3：边界情况 =====")
    数据 = {}
    处理函数 = lambda 值: 值
    print("结果:", 值映射(数据, 处理函数))
    print("数据:", 数据)

    print("\n===== 示例4：异常情况 =====")
    数据 = []
    处理函数 = 123
    print("结果:", 值映射(数据, 处理函数))
    print("数据:", 数据)

    print("\n===== 示例5：特殊值情况 =====")
    数据 = {"名称": "", "备注": None, "标签": []}
    处理函数 = lambda 值: "空" if 值 in (None, "", []) else 值
    print("结果:", 值映射(数据, 处理函数))
    print("数据:", 数据)

    print("\n===== 示例6：应用场景-整理业务字典 =====")
    数据 = {"订单号": "A001", "状态": "待发货", "数量": 3}
    处理函数 = lambda 值: 值 * 2 if isinstance(值, int) else 值
    print("结果:", 值映射(数据, 处理函数))
    print("数据:", 数据)
