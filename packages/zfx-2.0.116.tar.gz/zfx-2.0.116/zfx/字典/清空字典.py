from typing import Any, Dict

def 清空字典(数据: Dict[str, Any]) -> bool:
    """清空字典中的所有键值对。

    功能说明:
        - 这个函数用于清空字典中的所有键值对。
        - 它主要返回 True 或 False，适合直接写在 if 判断里控制后续流程。
        - 当输入不符合要求时，函数会直接返回 False，方便你快速判断这次操作有没有成功。

    Args:
        数据 (dict): 需要被清空的字典对象。

    Returns:
        bool:
        True  - 字典已成功清空（或原本为空）；
        False - 传入对象不是字典或发生异常。"""
    try:
        if not isinstance(数据, dict):
            return False

        数据.clear()
        return True
    except Exception:
        return False


if __name__ == "__main__":
    print("===== 示例1：基础用法 =====")
    数据 = {"名称": "zfx", "年龄": 18, "城市": "上海"}
    print("结果:", 清空字典(数据))
    print("数据:", 数据)

    print("\n===== 示例2：常见变体 =====")
    数据 = {"name": "zfx", "phone": None, "items": [1, 2]}
    print("结果:", 清空字典(数据))
    print("数据:", 数据)

    print("\n===== 示例3：边界情况 =====")
    数据 = {}
    print("结果:", 清空字典(数据))
    print("数据:", 数据)

    print("\n===== 示例4：异常情况 =====")
    数据 = []
    print("结果:", 清空字典(数据))
    print("数据:", 数据)

    print("\n===== 示例5：特殊值情况 =====")
    数据 = {"名称": "", "备注": None, "标签": []}
    print("结果:", 清空字典(数据))
    print("数据:", 数据)

    print("\n===== 示例6：应用场景-整理业务字典 =====")
    数据 = {"订单号": "A001", "状态": "待发货", "数量": 3}
    print("结果:", 清空字典(数据))
    print("数据:", 数据)
