import os
import shutil


def 移动文件(源文件路径, 目标文件路径, 是否覆盖=False):
    """移动文件到目标位置。

    Args:
        源文件路径: 需要移动的文件路径。
        目标文件路径: 移动后的目标文件路径。
        是否覆盖: 目标已存在时是否覆盖，默认为 ``False``。

    Returns:
        移动成功时返回 ``True``，否则返回 ``False``。
    """
    try:
        if not 是否覆盖 and os.path.exists(目标文件路径):
            return False

        if 是否覆盖 and os.path.exists(目标文件路径):
            os.remove(目标文件路径)

        shutil.move(源文件路径, 目标文件路径)
        return True
    except Exception:
        return False
