import os


def 取大小B(文件完整路径):
    """返回文件大小，单位为字节。

    Args:
        文件完整路径: 要获取大小的文件完整路径。

    Returns:
        文件大小的字节数；获取失败时返回 ``None``。
    """
    try:
        return os.path.getsize(文件完整路径)
    except Exception:
        return None
