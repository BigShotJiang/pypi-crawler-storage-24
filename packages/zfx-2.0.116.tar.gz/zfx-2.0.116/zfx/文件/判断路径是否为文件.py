import os


def 判断路径是否为文件(文件完整路径):
    """判断指定路径是否为文件。

    Args:
        文件完整路径: 要检查的路径。

    Returns:
        是文件时返回 ``True``，否则返回 ``False``。
    """
    try:
        return os.path.isfile(文件完整路径)
    except Exception:
        return False
