﻿from numbers import Number
from typing import Any, Tuple


def 取平均值(元组数据: Tuple[Any, ...]):
    """返回元组成员的平均值。

    功能说明:
        - 这个函数用于返回元组成员的平均值。
        - 常用于从元组中读取某个成员、某一段数据，或者计算出一个统计结果。
        - 如果当前数据不适合处理，函数会返回约定好的结果，方便新手直接判断这次是否成功取到值。

    Args:
        元组数据: 仅包含数字成员的元组。

    Returns:
        成功时返回平均值；失败时返回 ``None``。
    """
    try:
        if not isinstance(元组数据, tuple) or not 元组数据:
            return None
        if not all(isinstance(元素, Number) for 元素 in 元组数据):
            return None
        return sum(元组数据) / len(元组数据)
    except Exception:
        return None


if __name__ == "__main__":
    print("===== 示例1：基础平均值 =====")
    数据 = (10, 20, 30)
    print("结果:", 取平均值(数据))

    print("\n===== 示例2：包含布尔值 =====")
    数据 = (True, 1, 2)
    print("结果:", 取平均值(数据))

    print("\n===== 示例3：包含非数字 =====")
    数据 = (10, "20", 30)
    print("结果:", 取平均值(数据))

    print("\n===== 示例4：单个数字 =====")
    数据 = (99,)
    print("结果:", 取平均值(数据))

    print("\n===== 示例5：空元组 =====")
    数据 = ()
    print("结果:", 取平均值(数据))

    print("\n===== 示例6：应用场景-计算近7天平均销售额 =====")
    销售额 = (1200, 1350, 1280, 1420, 1310, 1380, 1400)
    print("结果:", 取平均值(销售额))



