﻿from numbers import Number
from typing import Any, Tuple


def 取总和与平均值(元组数据: Tuple[Any, ...]):
    """同时返回元组成员的总和与平均值。

    功能说明:
        - 这个函数用于同时返回元组成员的总和与平均值。
        - 常用于从元组中读取某个成员、某一段数据，或者计算出一个统计结果。
        - 如果当前数据不适合处理，函数会返回约定好的结果，方便新手直接判断这次是否成功取到值。

    Args:
        元组数据: 仅包含数字成员的元组。

    Returns:
        成功时返回 ``(总和, 平均值, True)``；失败时返回 ``(None, None, False)``。
    """
    try:
        if not isinstance(元组数据, tuple) or not 元组数据:
            return None, None, False
        if not all(isinstance(元素, Number) for 元素 in 元组数据):
            return None, None, False

        总和 = sum(元组数据)
        平均值 = 总和 / len(元组数据)
        return 总和, 平均值, True
    except Exception:
        return None, None, False


if __name__ == "__main__":
    print("===== 示例1：基础总和与平均值 =====")
    数据 = (10, 20, 30)
    print("结果:", 取总和与平均值(数据))

    print("\n===== 示例2：包含浮点数 =====")
    数据 = (1.5, 2.5, 3.0)
    print("结果:", 取总和与平均值(数据))

    print("\n===== 示例3：包含布尔值 =====")
    数据 = (True, 1, 2)
    print("结果:", 取总和与平均值(数据))

    print("\n===== 示例4：包含非数字 =====")
    数据 = (10, "20", 30)
    print("结果:", 取总和与平均值(数据))

    print("\n===== 示例5：空元组 =====")
    数据 = ()
    print("结果:", 取总和与平均值(数据))

    print("\n===== 示例6：应用场景-统计本周销售总额和日均值 =====")
    本周销售额 = (1200, 1350, 1280, 1420, 1310, 1380, 1400)
    print("结果:", 取总和与平均值(本周销售额))



