﻿from typing import Any, Tuple


def 排序(元组数据: Tuple[Any, ...], 逆序: bool = False):
    """对元组进行排序并返回排序结果。

    功能说明:
        - 这个函数用于对元组进行排序并返回排序结果。
        - 这个函数围绕元组数据做处理，重点是把常见操作封装成更容易直接调用的形式。
        - 使用时一般只需要关注传入什么数据、返回什么结果，不需要自己重复写底层处理逻辑。

    Args:
        元组数据: 待排序的元组。
        逆序: 是否逆序排序，默认为 ``False``。

    Returns:
        成功时返回 ``(排序后元组, True)``；失败时返回 ``((), False)``。
    """
    try:
        if not isinstance(元组数据, tuple):
            return (), False
        return tuple(sorted(元组数据, reverse=逆序)), True
    except Exception:
        return (), False


if __name__ == "__main__":
    print("===== 示例1：默认升序 =====")
    数据 = (5, 2, 9, 1)
    print("结果:", 排序(数据))

    print("\n===== 示例2：逆序排序 =====")
    数据 = (5, 2, 9, 1)
    print("结果:", 排序(数据, True))

    print("\n===== 示例3：无法比较的混合类型 =====")
    数据 = (1, "2", 3)
    print("结果:", 排序(数据))

    print("\n===== 示例4：空元组 =====")
    数据 = ()
    print("结果:", 排序(数据))

    print("\n===== 示例5：字符串排序 =====")
    数据 = ("pear", "apple", "banana")
    print("结果:", 排序(数据))

    print("\n===== 示例6：应用场景-按销量从低到高查看商品 =====")
    商品销量 = (320, 120, 560, 240, 180)
    print("结果:", 排序(商品销量))



