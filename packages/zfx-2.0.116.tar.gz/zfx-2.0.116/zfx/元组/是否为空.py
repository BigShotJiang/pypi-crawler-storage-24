﻿from typing import Any, Tuple


def 是否为空(元组数据: Tuple[Any, ...]) -> bool:
    """判断元组是否为空。

    功能说明:
        - 这个函数用于判断元组是否为空。
        - 常用于先判断元组数据是否满足某个条件，再决定后续要不要继续处理。
        - 返回结果一般是 ``True`` 或 ``False``，适合直接写在 ``if`` 判断里使用。

    Args:
        元组数据: 待判断的元组。

    Returns:
        为空时返回 ``True``，否则返回 ``False``。
    """
    try:
        if not isinstance(元组数据, tuple):
            return False
        return len(元组数据) == 0
    except Exception:
        return False


if __name__ == "__main__":
    print("===== 示例1：空元组 =====")
    数据 = ()
    print("结果:", 是否为空(数据))

    print("\n===== 示例2：非空元组 =====")
    数据 = (1,)
    print("结果:", 是否为空(数据))

    print("\n===== 示例3：数据不是元组 =====")
    数据 = []
    print("结果:", 是否为空(数据))

    print("\n===== 示例4：多成员元组 =====")
    数据 = (1, 2, 3)
    print("结果:", 是否为空(数据))

    print("\n===== 示例5：包含 None 也不算空 =====")
    数据 = (None,)
    print("结果:", 是否为空(数据))

    print("\n===== 示例6：应用场景-判断待发送短信队列是否为空 =====")
    短信队列 = ("短信1", "短信2")
    print("结果:", 是否为空(短信队列))



