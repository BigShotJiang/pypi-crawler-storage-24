﻿from typing import Any, Tuple


def 是否全为字符串(元组数据: Tuple[Any, ...]) -> bool:
    """判断元组成员是否全部为字符串。

    功能说明:
        - 这个函数用于判断元组成员是否全部为字符串。
        - 常用于先判断元组数据是否满足某个条件，再决定后续要不要继续处理。
        - 返回结果一般是 ``True`` 或 ``False``，适合直接写在 ``if`` 判断里使用。

    Args:
        元组数据: 待验证的元组。

    Returns:
        全部为字符串时返回 ``True``，否则返回 ``False``。
    """
    try:
        if not isinstance(元组数据, tuple) or not 元组数据:
            return False
        return all(isinstance(元素, str) for 元素 in 元组数据)
    except Exception:
        return False


if __name__ == "__main__":
    print("===== 示例1：全部为字符串 =====")
    数据 = ("a", "b", "c")
    print("结果:", 是否全为字符串(数据))

    print("\n===== 示例2：包含数字 =====")
    数据 = ("a", 1, "c")
    print("结果:", 是否全为字符串(数据))

    print("\n===== 示例3：包含 None =====")
    数据 = ("a", None, "c")
    print("结果:", 是否全为字符串(数据))

    print("\n===== 示例4：空元组 =====")
    数据 = ()
    print("结果:", 是否全为字符串(数据))

    print("\n===== 示例5：数据不是元组 =====")
    数据 = ["a", "b", "c"]
    print("结果:", 是否全为字符串(数据))

    print("\n===== 示例6：应用场景-验证导入的手机号列是否全是文本 =====")
    手机号列 = ("13800000001", "13800000002", "13800000003")
    print("结果:", 是否全为字符串(手机号列))



