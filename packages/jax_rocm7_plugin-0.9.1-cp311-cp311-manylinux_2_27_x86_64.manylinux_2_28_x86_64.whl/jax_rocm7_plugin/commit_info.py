
# auto-generated; do not edit

commits = {
    "ROCm/xla": "fa5a92b33cfa726ce40ffd73edc69fbca5bf246b",
    "ROCm/rocm-jax": "ab4f2cf779692d2a72b425aa9d4c09c75160b7c4",
    "jax": "58cb6e556c996bf0361bca9e64890a551e513280",
}
