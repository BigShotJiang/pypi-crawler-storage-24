"""
The version of the SplxAI Proxy package.
"""

__all__ = ["VERSION"]

VERSION = "1.3.0"
"""The version of the SplxAI Proxy package."""
