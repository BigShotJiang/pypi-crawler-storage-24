# formelement

`formelement` is a Python package for form automation.

It currently provides:

- answer pattern helpers
- Google Form browser automation with Selenium
- Google Form HTTP submission helpers

The package is structured so you can later extend it with other drivers such as `MonkeyFormBrowser`.

## Install

```bash
pip install formelement
```

`selenium` is installed automatically because browser automation is part of the core package.

## Quick start

Generate answer patterns:

```python
from formelement import AnswerPatternGenerator

generator = AnswerPatternGenerator()
answers = generator.polaJawab3(0, 1, 5)
print(answers)
```

Use the browser driver:

```python
from selenium import webdriver
from formelement import AnswerFieldType, GoogleFormBrowser

driver = webdriver.Firefox()
form = GoogleFormBrowser(driver)

short_inputs = form.tombol(AnswerFieldType.ISIANPENDEK)
```

Submit form answers:

```python
from formelement import submit_answers

status, payload, encoded = submit_answers(
    [["Alice", "24"], ["Yes"]],
    data_module="my_form_data",
    dry_run=True,
)
```

Your `data_module` must define:

```python
FORM_ID = "your-form-id"
FORM_ENTRY_IDS = [
    ["entry.123", "entry.456"],
    ["entry.789"],
]
FORM_SESSION_STATE = ""
FORM_FBZX = ""
```

## Public API

- `AnswerPatternGenerator`
- `AnswerFieldType`
- `GoogleFormBrowser`
- `submit_answers`

Legacy aliases from the original project are still available:

- `dataGoogleForm`
- `dataPilihan`
