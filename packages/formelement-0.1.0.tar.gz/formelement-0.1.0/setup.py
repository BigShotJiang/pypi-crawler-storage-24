from setuptools import find_packages, setup


setup(
    name="formelement",
    version="0.1.0",
    description="Form automation utilities with browser drivers such as GoogleFormBrowser.",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    author="Iqbal Rahman",
    author_email="iqbal@example.com",
    license="MIT",
    package_dir={"": "src"},
    packages=find_packages(where="src"),
    python_requires=">=3.9",
    install_requires=["selenium>=4.20"],
    url="https://pypi.org/project/formelement/",
)
