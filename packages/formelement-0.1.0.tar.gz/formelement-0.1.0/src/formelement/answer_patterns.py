import random


class AnswerPatternGenerator:
    def hitungUsia(self, batasAwal: int, batasAkhir: int) -> int:
        return random.randint(batasAwal, batasAkhir)

    def pilihTipe(self, jenis: list[int]) -> int:
        data: list[int] = []

        for i in range(len(jenis)):
            if jenis[i] != 0:
                data.append(i)

        return random.sample(data, 1)[0]

    def pilihanCheckbox(self, awal: int, akhir: int, banyakData: int) -> list[int]:
        temp = random.randint(1, banyakData)

        listData: list[int] = []
        i = awal
        while i <= akhir:
            listData.append(i)
            i += 1

        return random.sample(listData, temp)

    def polaJawab1(
        self,
        pola: int,
        awal: int,
        banyakSoal: int,
        kelipatan: int,
    ) -> list[int]:
        p = awal
        hasil: list[int] = []
        for _ in range(banyakSoal):
            hasil.append(p)
            p += kelipatan
        return hasil

    def polaJawab2(
        self,
        pola: int,
        awal: int,
        banyakSoal: int,
        kelipatan: int,
    ) -> list[int]:
        p = awal
        hasil: list[int] = []
        for _ in range(banyakSoal):
            if pola == 0:
                s1 = random.choice([p, p + 1])
            elif pola == 1:
                s1 = random.choice([p, p + 1, p + 1])
            elif pola == 2:
                s1 = random.choice([p, p + 1, p + 1, p + 1])
            elif pola == 3:
                s1 = random.choice([p, p, p + 1])
            elif pola == 4:
                s1 = random.choice([p, p, p, p + 1])
            else:
                s1 = random.choice([p, p + 1])

            hasil.append(s1)
        return hasil

    def polaJawab3(
        self,
        pola: int,
        awal: int,
        banyakSoal: int,
    ) -> list[int]:
        p = awal
        hasil: list[int] = []
        for _ in range(banyakSoal):
            if pola == 0:
                s1 = random.choice([p, p + 1, p + 2])
            elif pola == 1:
                s1 = random.choice([p, p + 1, p + 1, p + 2, p + 2])
            elif pola == 2:
                s1 = random.choice([p, p + 1, p + 1, p + 1, p + 2, p + 2, p + 2])
            elif pola == 3:
                s1 = random.choice(
                    [p, p + 1, p + 1, p + 1, p + 1, p + 2, p + 2, p + 2, p + 2]
                )
            elif pola == 4:
                s1 = random.choice([p, p, p + 1, p + 1, p + 2])
            elif pola == 5:
                s1 = random.choice([p, p, p, p + 1, p + 1, p + 1, p + 2])
            elif pola == 6:
                s1 = random.choice([p, p, p, p, p + 1, p + 1, p + 1, p + 1, p + 2])
            elif pola == 7:
                s1 = random.choice([p, p, p + 1, p + 1, p + 1, p + 2])
            else:
                s1 = random.choice([p, p + 1, p + 2])

            hasil.append(s1)
        return hasil

    def polaJawab4(
        self,
        pola: int,
        awal: int,
        banyakSoal: int,
        kelipatan: int,
    ) -> list[int]:
        p = awal
        hasil: list[int] = []
        for _ in range(banyakSoal):
            if pola == 0:
                s1 = random.choice([p, p + 1, p + 2, p + 3])
            elif pola == 1:
                s1 = random.choice([p, p + 1, p + 1, p + 2, p + 2, p + 3, p + 3])
            elif pola == 2:
                s1 = random.choice(
                    [p, p + 1, p + 1, p + 1, p + 2, p + 2, p + 2, p + 3, p + 3, p + 3]
                )
            else:
                s1 = random.choice([p, p + 1, p + 2, p + 3])

            hasil.append(s1)
            p += kelipatan
        return hasil

    def polaJawabCustom(
        self,
        awal: int,
        soal: list[int],
        kelipatan: int,
    ) -> list[int]:
        p = awal
        hasil: list[int] = []
        for i in range(len(soal)):
            s1 = soal[i] + p
            hasil.append(s1)
            p += kelipatan
        return hasil


dataGoogleForm = AnswerPatternGenerator
