import json
import time
from importlib import import_module
from typing import Dict, Iterable, List, Optional, Sequence, Tuple
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import Request, urlopen

POST_URL_TEMPLATE = "https://docs.google.com/forms/d/e/{form_id}/formResponse"


def _load_data_module(module_name: str):
    return import_module(module_name)


def _ensure_pages_aligned(
    entry_ids: Sequence[Sequence[str]],
    answers: Sequence[Sequence[str]],
) -> None:
    if len(entry_ids) != len(answers):
        raise ValueError(
            "Answer pages do not match FORM_ENTRY_IDS pages. "
            f"Expected {len(entry_ids)}, got {len(answers)}."
        )

    for index, (ids, values) in enumerate(zip(entry_ids, answers)):
        if len(ids) != len(values):
            raise ValueError(
                f"Answer count on page {index + 1} mismatches FORM_ENTRY_IDS "
                f"(expected {len(ids)}, got {len(values)})."
            )


def _compute_page_history(total_pages: int) -> str:
    if total_pages <= 0:
        return "0"
    return ",".join(str(i) for i in range(total_pages))


def _extract_entry_token(entry_id: str) -> int:
    try:
        return int(entry_id.split(".", 1)[1])
    except (IndexError, ValueError) as error:
        raise ValueError(f"Invalid entry id format: {entry_id}") from error


def _build_partial_response(
    entry_pages: Sequence[Sequence[str]],
    answer_pages: Sequence[Sequence[str]],
    session_state: str,
) -> Optional[str]:
    entries: List[List[object]] = []
    for ids, values in zip(entry_pages, answer_pages):
        for entry_id, answer in zip(ids, values):
            entries.append(
                [
                    None,
                    _extract_entry_token(entry_id),
                    [answer],
                    0,
                ]
            )

    if not entries:
        return None

    payload: List[object] = [entries, None]
    if session_state:
        payload.append(session_state)

    return json.dumps(payload, separators=(",", ":"))


def _build_payload(
    entry_ids: Sequence[Sequence[str]],
    answers: Sequence[Sequence[str]],
    session_state: str,
    fbzx: Optional[str] = None,
) -> Dict[str, str]:
    total_pages = len(entry_ids)
    last_page_ids = entry_ids[-1] if entry_ids else []
    last_page_answers = answers[-1] if answers else []
    timestamp_ms = str(int(time.time() * 1000))

    payload: Dict[str, str] = {
        entry_id: answer
        for entry_id, answer in zip(last_page_ids, last_page_answers)
    }

    for entry_id in last_page_ids:
        payload[f"{entry_id}_sentinel"] = ""

    payload["dlut"] = timestamp_ms

    partial = _build_partial_response(
        entry_ids[:-1],
        answers[:-1],
        session_state,
    )
    if partial is not None:
        payload["partialResponse"] = partial

    payload["pageHistory"] = _compute_page_history(total_pages)
    payload["fvv"] = "1"
    if fbzx:
        payload["fbzx"] = fbzx
    payload["submissionTimestamp"] = timestamp_ms

    return payload


def submit_answers(
    answers: Iterable[Iterable[str]],
    *,
    data_module: str = "2_data",
    session_state: Optional[str] = None,
    fbzx: Optional[str] = None,
    dry_run: bool = False,
) -> Tuple[Optional[int], Dict[str, str], str]:
    """
    Submit a multi-page Google Form response.

    The referenced data module must expose:
    - FORM_ID
    - FORM_ENTRY_IDS
    - optionally FORM_SESSION_STATE
    - optionally FORM_FBZX
    """

    normalized_answers = [
        [str(value) for value in page]
        for page in answers
    ]

    module = _load_data_module(data_module)
    form_id: str = getattr(module, "FORM_ID", "")
    entry_ids: Sequence[Sequence[str]] = getattr(module, "FORM_ENTRY_IDS", [])
    default_session_state: str = getattr(module, "FORM_SESSION_STATE", "")
    default_fbzx: str = getattr(module, "FORM_FBZX", "")

    if not form_id:
        raise ValueError("FORM_ID is missing in the data module.")

    entry_ids = [list(page) for page in entry_ids]
    _ensure_pages_aligned(entry_ids, normalized_answers)

    payload = _build_payload(
        entry_ids,
        normalized_answers,
        session_state if session_state is not None else default_session_state,
        fbzx if fbzx is not None else default_fbzx,
    )

    encoded = urlencode(payload)

    if dry_run:
        return None, payload, encoded

    request = Request(
        POST_URL_TEMPLATE.format(form_id=form_id),
        data=encoded.encode("utf-8"),
        headers={"Content-Type": "application/x-www-form-urlencoded"},
    )

    try:
        with urlopen(request) as response:
            response.read()
            status = response.status
    except HTTPError as error:
        raise RuntimeError(f"HTTP {error.code}: {error.reason}") from error
    except URLError as error:
        raise RuntimeError(f"Request failed: {error.reason}") from error

    return status, payload, encoded
