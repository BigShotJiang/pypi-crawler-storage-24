from enum import Enum


class AnswerFieldType(Enum):
    ISIANPENDEK = 0
    ISIANPANJANG = 1
    KEBAWAH = 2
    KESAMPING = 3
    CHECKBOX = 4
    LAINNYA = 5
    DROPDOWN = 6
    BUBBLE = 7


dataPilihan = AnswerFieldType
