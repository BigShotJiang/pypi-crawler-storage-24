"""
IDA Pro Batch Decompiler

A Python library and CLI tool for batch decompiling binary files using IDA Pro's
idat command-line tool.

Usage as library:

    from ida_batch_decompile import IDABatchDecompiler

    # Create decompiler instance
    decompiler = IDABatchDecompiler(
        idat_path="/path/to/idat",
        output_dir="./output",
        jobs=4,
        timeout=300
    )

    # Decompile entire directory
    results = decompiler.decompile_directory("./binaries")

    # Or decompile single binary
    result = decompiler.decompile_binary("./binaries/hello")

Usage as CLI:

    $ ida-decompile -i ./binaries -o ./output
    $ ida-decompile -i ./binaries -o ./output -j 8 -t 600
"""

from .core import IDABatchDecompiler
from .discovery import BinaryScanner

__version__ = "0.2.0"
__all__ = ["IDABatchDecompiler", "BinaryScanner"]
