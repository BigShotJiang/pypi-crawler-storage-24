"""Shared test fixtures for mcp-forge's own test suite."""

from __future__ import annotations

import os
from pathlib import Path

import pytest

from mcp_forge import MCPTestClient

SERVERS_DIR = Path(__file__).parent / "servers"
ECHO_SERVER = str(SERVERS_DIR / "echo_server.py")


@pytest.fixture
async def echo_client():
    """Create a test client connected to the echo test server."""
    command = f"python {ECHO_SERVER}"
    async with MCPTestClient.from_command(command, timeout=10.0) as client:
        yield client
