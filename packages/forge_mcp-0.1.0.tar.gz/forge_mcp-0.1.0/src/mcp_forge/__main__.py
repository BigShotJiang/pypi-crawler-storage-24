"""Allow running mcp-forge CLI via `python -m mcp_forge`."""

from mcp_forge.cli import main

if __name__ == "__main__":
    main()
