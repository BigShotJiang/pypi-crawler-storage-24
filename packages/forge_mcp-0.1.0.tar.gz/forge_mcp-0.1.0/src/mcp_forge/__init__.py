"""mcp-forge — pytest for MCP servers.

Test any MCP server — Python, TypeScript, Go, Rust — with zero LLM calls.
Tests are deterministic, fast, and free to run in CI/CD.

Usage:
    from mcp_forge import MCPTestClient
    from mcp_forge.assertions import assert_tool_exists, assert_no_error

    async with MCPTestClient.from_command("python my_server.py") as client:
        tools = await client.list_tools()
        assert_tool_exists(tools, "search_files")

        result = await client.call_tool("search_files", {"query": "README"})
        assert_no_error(result)
"""

from mcp_forge._types import (
    ContentBlock,
    PromptInfo,
    PromptResult,
    ResourceInfo,
    ResourceResult,
    ServerCapabilities,
    ToolInfo,
    ToolResult,
)
from mcp_forge.client import MCPTestClient
from mcp_forge.snapshot import SnapshotManager, SnapshotMismatchError

__version__ = "0.1.0"

__all__ = [
    # Core client
    "MCPTestClient",
    # Types
    "ToolInfo",
    "ToolResult",
    "ContentBlock",
    "ResourceInfo",
    "ResourceResult",
    "PromptInfo",
    "PromptResult",
    "ServerCapabilities",
    # Snapshot
    "SnapshotManager",
    "SnapshotMismatchError",
]
