"""Tests for strands-pack."""
