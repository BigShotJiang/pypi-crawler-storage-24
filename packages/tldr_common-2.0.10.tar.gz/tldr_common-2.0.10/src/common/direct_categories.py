"""Public category registry for TL;DR Direct RTMP streams.

This module ships the public category list for services like ``tldr_api``.
It must not import from ``stream_processing_service`` at runtime.
"""

from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache


@dataclass(frozen=True)
class DirectCategory:
    """User-facing category option for direct RTMP streams."""

    category_key: str
    category_label: str


_DIRECT_CATEGORIES: tuple[DirectCategory, ...] = (
    DirectCategory("apex_legends", "Apex Legends"),
    DirectCategory("arc_raiders", "ARC Raiders"),
    DirectCategory("arena_breakout_infinite", "Arena Breakout: Infinite"),
    DirectCategory("battlefield_6", "Battlefield 6"),
    DirectCategory("blue_protocol_star_resonance", "Blue Protocol: Star Resonance"),
    DirectCategory("borderlands_4", "Borderlands 4"),
    DirectCategory("call_of_duty", "Call of Duty"),
    DirectCategory("call_of_duty_black_ops_6", "Call of Duty: Black Ops 6"),
    DirectCategory("call_of_duty_warzone", "Call of Duty: Warzone"),
    DirectCategory("counter_strike", "Counter-Strike 2"),
    DirectCategory("cyberpunk_2077", "Cyberpunk 2077"),
    DirectCategory("dayz", "DayZ"),
    DirectCategory("dead_by_daylight", "Dead by Daylight"),
    DirectCategory("delta_force", "Delta Force"),
    DirectCategory("destiny_2", "Destiny 2"),
    DirectCategory("dota_2", "Dota 2"),
    DirectCategory("dying_light_the_beast", "Dying Light: The Beast"),
    DirectCategory("ea_sports_college_football_26", "EA Sports College Football 26"),
    DirectCategory("ea_sports_fc", "EA Sports FC"),
    DirectCategory("escape_from_tarkov", "Escape from Tarkov"),
    DirectCategory("final_fantasy_xiv", "Final Fantasy XIV Online"),
    DirectCategory("fortnite", "Fortnite"),
    DirectCategory("ghost_of_yotei", "Ghost of Yōtei"),
    DirectCategory("gta_v", "Grand Theft Auto V"),
    DirectCategory("helldivers_2", "HELLDIVERS 2"),
    DirectCategory("hogwarts_legacy", "Hogwarts Legacy"),
    DirectCategory("hollow_knight_silksong", "Hollow Knight: Silksong"),
    DirectCategory("irl", "IRL"),
    DirectCategory("just_chatting", "Just Chatting"),
    DirectCategory("league_of_legends", "League of Legends"),
    DirectCategory("madden_nfl_26", "Madden NFL 26"),
    DirectCategory("marvel_rivals", "Marvel Rivals"),
    DirectCategory("megabonk", "Megabonk"),
    DirectCategory("minecraft", "Minecraft"),
    DirectCategory("music", "Music"),
    DirectCategory("nba_2k26", "NBA 2K26"),
    DirectCategory("new_world_aeternum", "New World: Aeternum"),
    DirectCategory("overwatch", "Overwatch 2"),
    DirectCategory("phasmophobia", "Phasmophobia"),
    DirectCategory("pubg_battlegrounds", "PUBG: BATTLEGROUNDS"),
    DirectCategory("rainbow_six_siege", "Tom Clancy's Rainbow Six Siege"),
    DirectCategory("roblox", "ROBLOX"),
    DirectCategory("rocket_league", "Rocket League"),
    DirectCategory("rust", "Rust"),
    DirectCategory("silent_hill_f", "SILENT HILL ƒ"),
    DirectCategory("skate", "skate."),
    DirectCategory("teamfight_tactics", "Teamfight Tactics"),
    DirectCategory("terraria", "Terraria"),
    DirectCategory("valorant", "Valorant"),
    DirectCategory("world_of_warcraft", "World of Warcraft"),
    DirectCategory("wwe_2k25", "WWE 2K25"),
)


@lru_cache(maxsize=1)
def list_direct_categories() -> tuple[DirectCategory, ...]:
    """Return the public TL;DR Direct categories."""

    return tuple(
        sorted(_DIRECT_CATEGORIES, key=lambda item: item.category_label.casefold())
    )


@lru_cache(maxsize=1)
def _direct_category_map() -> dict[str, DirectCategory]:
    return {category.category_key: category for category in _DIRECT_CATEGORIES}


def get_direct_category(category_key: str | None) -> DirectCategory | None:
    """Return the matching direct category when the key is valid."""

    normalized = (category_key or "").strip()
    if not normalized:
        return None
    return _direct_category_map().get(normalized)


def is_valid_direct_category_key(category_key: str | None) -> bool:
    """Return whether the supplied direct category key is supported."""

    return get_direct_category(category_key) is not None


def resolve_direct_category_label(category_key: str | None) -> str | None:
    """Return the user-facing label for a supported category key."""

    category = get_direct_category(category_key)
    return category.category_label if category else None
