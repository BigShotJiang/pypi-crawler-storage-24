from typing import Optional
from uuid import UUID

import kolena_agents.types.api_key as api_key_types
from kolena_agents._generated.openapi_client import ApiClient  # type: ignore
from kolena_agents._generated.openapi_client.api import ClientApi  # type: ignore


class ApiKey:
    def __init__(self, client: ApiClient) -> None:
        """Initialize the ApiKey resource.

        Args:
            client: The configured API client instance.
        """
        self._api = ClientApi(client)

    def create(
        self, name: str, expiration_days: Optional[int] = None
    ) -> api_key_types.ClientApiKeyCreateResponse:
        """Create a new API key.

        Args:
            name: The name of the API key
            expiration_days: Optional number of days until the API key expires
        """
        return self._api.client_create_api_key_api_v1_client_api_keys_post(
            client_api_key_create_request=api_key_types.ClientApiKeyCreateRequest(
                name=name, expiration_days=expiration_days
            )
        )

    def list(
        self, page_number: int = 0, page_size: int = 50
    ) -> api_key_types.ClientApiKeyListResponse:
        """Get a paginated list of API keys.

        Args:
            page_number: Page number for pagination (default: 0)
            page_size: Number of items per page (default: 50, max: 1000)
        """
        return self._api.client_list_api_keys_api_v1_client_api_keys_get(
            page_number=page_number, page_size=page_size
        )

    def get(self, key_id: str) -> api_key_types.ApiKeyInfo:
        """Get details of a specific API key.

        Args:
            key_id: The ID of the API key
        """
        return self._api.client_get_api_key_api_v1_client_api_keys_key_id_get(
            key_id=UUID(key_id)
        )

    def delete(self, key_id: str) -> None:
        """Delete an API key.

        Args:
            key_id: The ID of the API key to delete
        """
        self._api.client_delete_api_key_api_v1_client_api_keys_key_id_delete(
            key_id=UUID(key_id)
        )
