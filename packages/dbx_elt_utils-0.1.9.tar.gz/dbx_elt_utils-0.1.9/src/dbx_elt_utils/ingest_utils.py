# src/common/ingest_utils.py
from pyspark.sql.functions import current_timestamp, lit, input_file_name
from dbx_elt_utils.notebook_utils import get_schema_location_base

def ingesta_hibrida(spark, origen, tipo="auto_detect", formato_archivo="json", env_suffix="_dev", streaming=True):
    """
    Ingestor Universal.
    Args:
        origen (str): Nombre de tabla (cat.esq.tab) O Ruta (abfss://...)
        tipo (str): "delta_table", "auto_loader" o "auto_detect"
        formato_archivo (str): csv, json, parquet (Solo para Auto Loader)
        env_suffix (str): Sufijo de ambiente ("_dev", "_prod") para rutas de checkpoint
    """
    # 1. Auto-detección inteligente
    if tipo == "auto_detect":
        # Si parece una ruta de nube o ruta unix, asumimos archivo
        if "abfss://" in origen or "s3://" in origen or "/" in origen:
            tipo = "auto_loader"
        else:
            tipo = "delta_table"

    print(f"🏭 Ingesta Híbrida activada: {tipo.upper()} -> {origen}")

    # 2. Lógica de Lectura
    reader = spark.readStream if streaming else spark.read

    # --- CASO A: UNITY CATALOG (Tablas Fivetran) ---
    if tipo == "delta_table":
        return (
            reader.table(origen)
            .withColumn("_origen_datos", lit("unity_catalog"))
            .withColumn("_ingestado_en", current_timestamp())
        )

    # --- CASO B: AUTO LOADER (Archivos Sueltos) ---
    elif tipo == "auto_loader":
        # Configuración "Schema Evolution" (Clave para archivos sueltos que cambian)
        cloud_reader = (
            reader.format("cloudFiles")
            .option("cloudFiles.format", formato_archivo)
            .option("cloudFiles.inferColumnTypes", "true")
            .option("cloudFiles.schemaEvolutionMode", "addNewColumns") # Si el Excel trae columna nueva, no falla
            .option("cloudFiles.schemaLocation", f"{get_schema_location_base(env_suffix)}/{origen.split('/')[-1]}")
        )

        # Ajustes específicos para CSV
        if formato_archivo == "csv":
            cloud_reader = cloud_reader.option("header", "true").option("delimiter", ",")

        return (
            cloud_reader.load(origen)
            .withColumn("_origen_datos", lit(f"file_{formato_archivo}"))
            .withColumn("_nombre_archivo", input_file_name()) # Útil para saber qué archivo trajo el dato
            .withColumn("_ingestado_en", current_timestamp())
        )

    else:
        raise ValueError(f"Tipo desconocido: {tipo}")