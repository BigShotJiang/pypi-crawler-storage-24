import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from docx import Document

from rwe.clients.genebass import (
    GeneBassClient,
    generate_genebass_clinical_report,
    generate_genebass_indication_specific_report,
    generate_genebass_labs_measurements_report,
)
from tests._fixtures import write_genebass_csv


class GeneBassReportSmokeTest(unittest.TestCase):
    def setUp(self) -> None:
        self.tmpdir = tempfile.TemporaryDirectory()
        self.output_dir = Path(self.tmpdir.name)
        self.gene = "TESTGENE"
        write_genebass_csv(self.output_dir, self.gene)

    def tearDown(self) -> None:
        self.tmpdir.cleanup()

    def test_genebass_report_smoke(self) -> None:
        with patch("rwe.clients.genebass.get_gene_info", return_value=(self.gene, "ENSG_TEST", "1")):
            doc = Document()
            doc = generate_genebass_clinical_report(doc, self.gene, str(self.output_dir))
            doc = generate_genebass_labs_measurements_report(doc, self.gene, str(self.output_dir))
            doc = generate_genebass_indication_specific_report(doc, self.gene, str(self.output_dir), ["diabetes", "obesity"])

        out_path = self.output_dir / f"{self.gene}_genebass.docx"
        doc.save(out_path)

        self.assertTrue(out_path.exists())
        full_text = "\n".join(p.text for p in doc.paragraphs)
        self.assertIn("Phenome-wide Association Study (PheWAS) in UK Biobank cohort collected from GeneBass", full_text)
        self.assertIn("Indication specific PheWAS results in UK Biobank cohort collected from GeneBass", full_text)

    def test_genebass_carrier_info_smoke(self) -> None:
        info = GeneBassClient(gene=self.gene, phewas_dir="").get_carrier_info()
        self.assertEqual(info["gene"], self.gene)
        self.assertIn("nhetz", info)
        self.assertIn("nhomz", info)


if __name__ == "__main__":
    unittest.main()
