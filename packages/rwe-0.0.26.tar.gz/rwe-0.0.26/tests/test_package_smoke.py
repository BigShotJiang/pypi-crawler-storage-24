import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from pptx import Presentation

import rwe.clients.aou as aou
from rwe.generate_report import generate_rwe_report
from tests._fixtures import write_azn_binary_csv, write_azn_continuous_csv, write_genebass_csv


class PackageSmokeTest(unittest.TestCase):
    def setUp(self) -> None:
        self.tmpdir = tempfile.TemporaryDirectory()
        self.output_dir = Path(self.tmpdir.name)
        self.gene = "TESTGENE"
        write_genebass_csv(self.output_dir, self.gene)
        write_azn_binary_csv(self.output_dir, self.gene)
        write_azn_continuous_csv(self.output_dir, self.gene)

    def tearDown(self) -> None:
        self.tmpdir.cleanup()

    def test_generate_rwe_report_ukb_only_smoke(self) -> None:
        def _unexpected_aou_call(*args, **kwargs):
            raise AssertionError("AoU path should not be used in UKB-only smoke test")

        out_docx = self.output_dir / "RWE_TESTGENE_report.docx"
        with patch.object(aou, "generate_aou_variant_info_demographics_report", side_effect=_unexpected_aou_call), \
            patch.object(aou, "generate_aou_clinical_report", side_effect=_unexpected_aou_call), \
            patch.object(aou, "generate_aou_labs_measurements_report", side_effect=_unexpected_aou_call), \
            patch.object(aou, "generate_aou_survey_report", side_effect=_unexpected_aou_call), \
            patch.object(aou, "generate_aou_homozygous_lof_carriers_report", side_effect=_unexpected_aou_call), \
            patch.object(aou, "generate_aou_indication_specific_report", side_effect=_unexpected_aou_call), \
            patch("rwe.clients.genebass.get_gene_info", return_value=(self.gene, "ENSG_TEST", "1")), \
            patch("rwe.utils.presentation.gnomad.get_gnomad_constraint_info", return_value={
                "input_gene": self.gene,
                "gene": self.gene,
                "loeuf": 0.42,
                "nhetz": 98,
                "nhomz": 2,
            }), \
            patch("rwe.utils.presentation.gbs.get_genebass_carrier_info", return_value={
                "gene": self.gene,
                "nhetz": 40,
                "nhomz": 1,
            }), \
            patch("rwe.utils.presentation.aou.get_aou_carrier_info", side_effect=_unexpected_aou_call):
            result = generate_rwe_report(
                gene=self.gene,
                chrm="1",
                out_docx_path=str(out_docx),
                indications="obesity",
                allofus=False,
                genebass=True,
                astrazeneca=True,
                generate_pptx=True,
            )

        self.assertTrue(Path(result["docx_path"]).exists())
        self.assertTrue(Path(result["pptx_path"]).exists())

        prs = Presentation(result["pptx_path"])
        slide4_text = "\n".join(shape.text for shape in prs.slides[3].shapes if getattr(shape, "has_text_frame", False))
        self.assertIn("LOEUF score: 0.420.", slide4_text)
        self.assertIn("gnomAD and UK Biobank cohorts have 138 (98 + 40) heterozygous and 3 (2 + 1) homozygous", slide4_text)


if __name__ == "__main__":
    unittest.main()
