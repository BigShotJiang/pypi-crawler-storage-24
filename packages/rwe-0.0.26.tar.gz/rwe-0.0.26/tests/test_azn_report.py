import tempfile
import unittest
from pathlib import Path

from docx import Document

from rwe.clients.azn import (
    generate_azn_clinical_report,
    generate_azn_indication_specific_report,
    generate_azn_labs_measurements_report,
    generate_azn_plasma_protein_biomarkers_report,
)
from tests._fixtures import write_azn_binary_csv, write_azn_continuous_csv


class AstraZenecaReportSmokeTest(unittest.TestCase):
    def setUp(self) -> None:
        self.tmpdir = tempfile.TemporaryDirectory()
        self.output_dir = Path(self.tmpdir.name)
        self.gene = "TESTGENE"
        write_azn_binary_csv(self.output_dir, self.gene)
        write_azn_continuous_csv(self.output_dir, self.gene)

    def tearDown(self) -> None:
        self.tmpdir.cleanup()

    def test_azn_report_smoke(self) -> None:
        doc = Document()
        doc = generate_azn_clinical_report(doc, self.gene, str(self.output_dir))
        doc = generate_azn_labs_measurements_report(doc, self.gene, str(self.output_dir))
        doc = generate_azn_plasma_protein_biomarkers_report(doc, self.gene, str(self.output_dir))
        doc = generate_azn_indication_specific_report(doc, self.gene, str(self.output_dir), ["diabetes", "obesity"])

        out_path = self.output_dir / f"{self.gene}_azn.docx"
        doc.save(out_path)

        self.assertTrue(out_path.exists())
        full_text = "\n".join(p.text for p in doc.paragraphs)
        self.assertIn("AstraZeneca", full_text)
        self.assertIn("Indication specific PheWAS results in UK Biobank cohort collected from AstraZeneca", full_text)


if __name__ == "__main__":
    unittest.main()
