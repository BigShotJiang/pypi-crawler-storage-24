import os

# get GC bucket and CDR info
BUCKET = os.getenv("WORKSPACE_BUCKET")
CDR = os.environ["WORKSPACE_CDR"]
GOOGLE_PROJECT = os.getenv("GOOGLE_PROJECT")


MEASUREMENT_GROUPS = {
    "vitals": [
        "Body mass index (BMI) [Ratio]", "Body height", "Body weight", 
        "Systolic blood pressure", "Diastolic blood pressure" , "Heart rate"
    ],
    "hematology": [
        "Hemoglobin [Mass/volume] in Blood",
        "Hematocrit [Volume Fraction] of Blood by Automated count",
        "Erythrocytes [#/volume] in Blood by Automated count",
        "Erythrocyte distribution width [Entitic volume]",
        "MCV [Entitic volume] by Automated count",
        "Platelets [#/volume] in Blood by Automated count",
    ],
    "renal": [
        "Creatinine [Mass/volume] in Serum or Plasma",
        "Urea nitrogen [Mass/volume] in Serum or Plasma",
        "Glomerular filtration rate/1.73 sq M.predicted [Volume Rate/Area] in Serum, Plasma or Blood by Creatinine-based formula (MDRD)",
        "Sodium [Moles/volume] in Serum or Plasma",
        "Potassium [Moles/volume] in Serum or Plasma",
        "Bicarbonate [Moles/volume] in Serum or Plasma",
    ],
    "liver": [
        "Albumin [Mass/volume] in Serum or Plasma",
        "Protein [Mass/volume] in Serum or Plasma",
        "Alanine aminotransferase [Enzymatic activity/volume] in Serum or Plasma",
        "Aspartate aminotransferase [Enzymatic activity/volume] in Serum or Plasma",
        "Alkaline phosphatase [Enzymatic activity/volume] in Serum or Plasma",
        "Bilirubin.total [Mass/volume] in Serum or Plasma",
    ],
    "metabolic": [
        "Glucose [Mass/volume] in Serum or Plasma",
        "Hemoglobin A1c/Hemoglobin.total in Blood",
        "Cholesterol [Mass/volume] in Serum or Plasma",
        "Cholesterol in LDL [Mass/volume] in Serum or Plasma by calculation",
        "Cholesterol in HDL [Mass/volume] in Serum or Plasma",
        "Triglyceride [Mass/volume] in Serum or Plasma",
    ],
    "miscellaneous": [
        "C reactive protein [Mass/volume] in Serum or Plasma",
        "Erythrocyte sedimentation rate by Westergren method",
        "Natriuretic peptide B [Mass/volume] in Serum or Plasma",
        "Natriuretic peptide.B prohormone N-Terminal [Mass/volume] in Serum or Plasma",
        "Troponin I.cardiac [Mass/volume] in Serum or Plasma",
        "Creatine kinase [Enzymatic activity/volume] in Serum or Plasma",
    ]
}

NORMAL_TRAIT_RANGES = {
    # Obesity / vital signs
    "Body mass index (BMI) [Ratio]": (18.5, 24.9),  # kg/m^2
    "Systolic blood pressure": (90, 120),           # mmHg
    "Diastolic blood pressure": (60, 80),           # mmHg
    "Heart rate": (60, 100),                        # bpm

    # Diabetes / glycemia
    "Glucose [Mass/volume] in Serum or Plasma": (70, 99),                 # fasting mg/dL
    "Hemoglobin A1c/Hemoglobin.total in Blood": (4.0, 5.6),               # %

    # Lipids / CVD risk
    "Cholesterol [Mass/volume] in Serum or Plasma": (0, 200),             # total mg/dL (desirable <200)
    "Cholesterol in LDL [Mass/volume] in Serum or Plasma by calculation": (0, 100),  # mg/dL (optimal <100)
    "Cholesterol in HDL [Mass/volume] in Serum or Plasma": (60, 80),       # mg/dL (ideal range)
    "Triglyceride [Mass/volume] in Serum or Plasma": (0, 150),             # mg/dL (normal <150)

    # Kidney function / kidney disease translation
    "Creatinine [Mass/volume] in Serum or Plasma": (0.6, 1.3),             # mg/dL (typical adult)
    "Urea nitrogen [Mass/volume] in Serum or Plasma": (7, 20),             # BUN mg/dL
    "Glomerular filtration rate/1.73 sq M.predicted [Volume Rate/Area] in Serum, Plasma or Blood by Creatinine-based formula (MDRD)": (90, 120),  # mL/min/1.73m^2 (normal ~>=90)
    "Albumin/Creatinine [Mass Ratio] in Urine": (0, 30),                   # mg/g (normal <30)

    # Inflammation / infection risk adjunct
    "C reactive protein [Mass/volume] in Serum or Plasma": (0, 10),         # mg/L (general reference; hs-CRP differs)
    "Leukocytes [#/volume] in Blood by Automated count": (4.0, 11.0),  # x10^3/uL
    "Erythrocytes [#/area] in Urine sediment by Microscopy high power field": (0, 2),  # RBC/HPF
    "Erythrocyte sedimentation rate by Westergren method": (0.0, 20.0),  # mm/hr (broad adult ref)
    
    # Anemia
    "Hemoglobin [Mass/volume] in Blood": (120.0, 175.0),  # g/L (broad adult range)
    "MCV [Entitic volume] by Automated count": (80.0, 100.0),  # fL
}


MEASUREMENT_NAMES_MAP = {
    "25-Hydroxyvitamin D3+25-Hydroxyvitamin D2 [Mass/volume] in Serum or Plasma": "vitamin_d_25oh_total",
    "Alanine aminotransferase [Enzymatic activity/volume] in Serum or Plasma": "alt",
    "Albumin [Mass/volume] in Serum or Plasma": "albumin_serum",
    "Albumin/Creatinine [Mass Ratio] in Urine": "uacr",
    "Alkaline phosphatase [Enzymatic activity/volume] in Serum or Plasma": "alp",
    "Anion gap 3 in Serum or Plasma": "anion_gap",
    "Aspartate aminotransferase [Enzymatic activity/volume] in Serum or Plasma": "ast",
    "Basophils [#/volume] in Blood": "basophils_abs",
    "Basophils [#/volume] in Blood by Automated count": "basophils_abs_auto",
    "Basophils/100 leukocytes in Blood": "basophils_pct",
    "Basophils/100 leukocytes in Blood by Automated count": "basophils_pct_auto",
    "Basophils/100 leukocytes in Blood by Manual count": "basophils_pct_manual",
    "Bicarbonate [Moles/volume] in Serum or Plasma": "bicarbonate",
    "Bilirubin.total [Mass/volume] in Serum or Plasma": "bilirubin_total",
    "Body height": "height",
    "Body mass index (BMI) [Ratio]": "bmi",
    "Body weight": "weight",
    "C reactive protein [Mass/volume] in Serum or Plasma": "crp",
    "Calcium [Mass/volume] in Serum or Plasma": "calcium",
    "Chloride [Moles/volume] in Serum or Plasma": "chloride",
    "Cholesterol [Mass/volume] in Serum or Plasma": "chol_total",
    "Cholesterol in HDL [Mass/volume] in Serum or Plasma": "hdl_c",
    "Cholesterol in LDL [Mass/volume] in Serum or Plasma by calculation": "ldl_c_calc",
    "Creatine kinase [Enzymatic activity/volume] in Serum or Plasma": "ck",
    "Creatinine [Mass/volume] in Serum or Plasma": "creatinine",
    "Diastolic blood pressure": "dbp",
    "Eosinophils [#/volume] in Blood by Automated count": "eosinophils_abs_auto",
    "Epithelial cells.squamous [#/area] in Urine sediment by Microscopy high power field": "urine_squamous_epi_hpf",
    "Erythrocyte distribution width [Entitic volume]": "rdw_sd",
    "Erythrocyte distribution width [Ratio] by Automated count": "rdw_cv_auto",
    "Erythrocyte sedimentation rate by Westergren method": "esr_westergren",
    "Erythrocytes [#/area] in Urine sediment by Microscopy high power field": "urine_rbc_hpf",
    "Erythrocytes [#/volume] in Blood by Automated count": "rbc_abs_auto",
    "Glomerular filtration rate/1.73 sq M.predicted [Volume Rate/Area] in Serum, Plasma or Blood by Creatinine-based formula (MDRD)": "egfr_mdrd",
    "Glucose [Mass/volume] in Serum or Plasma": "glucose",
    "Heart rate": "heart_rate",
    "Hematocrit [Volume Fraction] of Blood by Automated count": "hematocrit_auto",
    "Hemoglobin A1c/Hemoglobin.total in Blood": "hba1c",
    "Hemoglobin [Mass/volume] in Blood": "hemoglobin",
    "Immature granulocytes [#/volume] in Blood": "immature_granulocytes_abs",
    "Immature granulocytes [#/volume] in Blood by Automated count": "immature_granulocytes_abs_auto",
    "Immature granulocytes/100 leukocytes in Blood": "immature_granulocytes_pct",
    "Immature granulocytes/100 leukocytes in Blood by Automated count": "immature_granulocytes_pct_auto",
    "Leukocytes [#/area] in Urine sediment by Microscopy high power field": "urine_wbc_hpf",
    "Leukocytes [#/volume] in Blood by Automated count": "wbc_abs_auto",
    "Lymphocytes [#/volume] in Blood by Automated count": "lymphocytes_abs_auto",
    "MCH [Entitic mass] by Automated count": "mch_auto",
    "MCHC [Mass/volume] by Automated count": "mchc_auto",
    "MCV [Entitic volume] by Automated count": "mcv_auto",
    "Magnesium [Mass/volume] in Serum or Plasma": "magnesium",
    "Monocytes [#/volume] in Blood by Automated count": "monocytes_abs_auto",
    "Natriuretic peptide B [Mass/volume] in Serum or Plasma": "bnp",
    "Natriuretic peptide.B prohormone N-Terminal [Mass/volume] in Serum or Plasma": "ntprobnp",
    "Neutrophils [#/volume] in Blood by Automated count": "neutrophils_abs_auto",
    "Nucleated erythrocytes [#/volume] in Blood by Automated count": "nrbc_abs_auto",
    "Nucleated erythrocytes/100 leukocytes [Ratio] in Blood": "nrbc_pct",
    "Nucleated erythrocytes/100 leukocytes [Ratio] in Blood by Automated count": "nrbc_pct_auto",
    "Phosphate [Mass/volume] in Serum or Plasma": "phosphate",
    "Platelet mean volume [Entitic volume] in Blood by Automated count": "mpv_auto",
    "Platelets [#/volume] in Blood by Automated count": "platelets_abs_auto",
    "Potassium [Moles/volume] in Serum or Plasma": "potassium",
    "Protein [Mass/volume] in Serum or Plasma": "protein_total_serum",
    "Protein [Mass/volume] in Urine by Test strip": "urine_protein_dipstick",
    "Sodium [Moles/volume] in Serum or Plasma": "sodium",
    "Systolic blood pressure": "sbp",
    "Thyroxine (T4) free [Mass/volume] in Serum or Plasma": "free_t4",
    "Triglyceride [Mass/volume] in Serum or Plasma": "triglycerides",
    "Troponin I.cardiac [Mass/volume] in Serum or Plasma": "troponin_i",
    "Urea nitrogen [Mass/volume] in Serum or Plasma": "bun",
}


