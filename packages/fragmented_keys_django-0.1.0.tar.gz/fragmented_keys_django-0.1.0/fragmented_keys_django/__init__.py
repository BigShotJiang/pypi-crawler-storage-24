"""Django cache management with fragmented keys for better invalidation support."""

__version__ = "0.1.0"
