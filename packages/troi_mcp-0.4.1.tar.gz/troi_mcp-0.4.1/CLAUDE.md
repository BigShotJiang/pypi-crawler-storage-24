# Troi MCP — Project Guide

## Overview
MCP server connecting Claude Desktop to Troi project management.
Version 0.3.0 on PyPI (`pip install troi-mcp`).

## Architecture

### API Layers (troi.py → TroiClient)
| Layer | Base Path | Auth | Used For |
|-------|-----------|------|----------|
| REST API | `/api/v2/rest/...` | Basic Auth | All standard CRUD (projects, positions, time entries, etc.) |
| Legacy API | `/api/v2/...` | Basic Auth | calculationObjects, some read endpoints |
| Component API | `/components/...` | Basic Auth | Project create/delete (REST returns 500 for these) |
| PHP Session | `/site/index.php` | Basic Auth + PHPSESSID | Print, approval, generate_offer_number |

### Critical: GET vs POST for /site/index.php
- **GET** to `/site/index.php` with API Basic Auth **always redirects to login.php (302)**
- **POST** to `/site/index.php` with form data **works** with API Basic Auth
- The browser form uses GET (works via web session cookie), but our API must use POST
- `_ensure_session()` must be called before any `/site/` endpoint to warm up PHPSESSID

### PHP Session Behavior
- A simple GET to any page warms up the PHPSESSID
- The FOP PDF endpoint (`print_document.php`) creates a **new** PHPSESSID on every request
- This session invalidation is expected and doesn't break the workflow

## PDF Workflow

### 3-Step PDF Generation
1. **POST** print form → HTML response with `window.open("...fop/print_document.php?...")` URL
2. **GET** FOP URL + `&start` → JSON `{"url": "../../../config/temp/.../filename.pdf"}`
3. **Poll** the PDF URL (1.5s initial wait, then 2s intervals, max 6 attempts)

### PDF Label Bug & Fix (`_fix_pdf_labels`)
**Problem**: FOP template doesn't render bold labels (Angebotsnummer:, Projektnummer:, Kunde:, column headers) when PDF is generated via API session. Only the colon ":" remains. Browser-generated PDFs are fine.

**Root cause**: FOP template resolves label strings differently for API vs web sessions. NOT a locale issue (`x-served-locale: de` confirms German locale is active). Cannot fix server-side because web login requires user password (not API key) — all login endpoints return 403 with API key.

**Fix** (PyMuPDF post-processing):
- Detects colon-only `Poppins-SemiBold` spans using `page.get_text('rawdict')`
- Uses the span's `origin` (baseline) coordinates for precise text placement
- Page 1: inserts Angebotsnummer, Projektnummer, Kunde before their colons
- Calculation pages: inserts BEZEICHNUNG, ANZAHL, EINZELPREIS, PREIS headers 18pt above first content line
- Last page: inserts Angebotsnummer, Ansprechpartner, Projekt, Projekt-Laufzeit
- En-dash "–" before project title: redacted and redrawn without prefix

### macOS Download Timestamp
Overwriting a file in ~/Downloads keeps the original "Date Added" (macOS Spotlight metadata).
Fix: `os.remove()` the file before writing so Finder shows it as latest.

## MCP SDK
Uses MCP SDK v1.26+ with `stdio_server()` context manager pattern:
```python
async with mcp.server.stdio.stdio_server() as (read_stream, write_stream):
    await server.run(read_stream, write_stream, server.create_initialization_options())
```
The old `mcp.server.stdio.run_server()` no longer exists.

## Dependencies
- `mcp>=1.0.0`, `requests>=2.28.0`, `pymupdf>=1.24.0`
- System fonts: `Poppins-SemiBold.ttf` + `Poppins-Bold.ttf` (graceful fallback if missing)
