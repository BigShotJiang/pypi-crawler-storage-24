# PRD: Troi MCP – Kontakt- & Kundenverwaltung

**Autor:** Nick / AirLST GmbH
**Datum:** 07.03.2026
**Status:** Draft
**Betroffenes System:** Troi MCP Server (Custom Integration)

---

## 1. Problem Statement

Der Troi MCP Server kann aktuell keine Kunden (Auftraggeber) oder Kontakte (Firmen/Abteilungen/Ansprechpartner) anlegen oder bearbeiten. Wenn ein neuer Kunde für ein Angebot benötigt wird, muss der User die Troi-UI öffnen und alles manuell anlegen. Das unterbricht den automatisierten Workflow.

### 1.1 Ist-Zustand

| Endpoint | Status |
|---|---|
| `troi_list_customers` | ✅ Vorhanden (lesend) |
| `troi_get_customer` | ✅ Vorhanden (lesend) |
| `troi_list_contacts` | ✅ Vorhanden (lesend) |
| `troi_get_contact` | ✅ Vorhanden (lesend) |
| `troi_create_customer` | ❌ Fehlt |
| `troi_update_customer` | ❌ Fehlt |
| `troi_create_contact` | ❌ Fehlt |
| `troi_update_contact` | ❌ Fehlt |

### 1.2 Typischer Use Case (heute)

> "Lege ein Angebot für Mercedes-Benz AG, Abteilung HCP 098 an, Ansprechpartner Michael Kuhn"

**Aktuell:**
1. Claude prüft `troi_list_customers` → Abteilung existiert nicht als Kunde
2. Claude muss den User bitten, den Kunden manuell in Troi anzulegen
3. User wechselt zur Troi-UI, legt Abteilung + Kontaktperson + Kunde an
4. User kommt zurück und sagt Claude die neue Customer-ID
5. Claude kann endlich das Angebot erstellen

**Ziel:**
1. Claude sucht die Firma (existiert meistens schon), legt nur Abteilung + Person + Kunde an
2. Claude erstellt sofort das Angebot mit `troi_create_offer`

---

## 2. Troi Datenmodell

### 2.1 Flexible Kontakthierarchie (2 oder 3 Ebenen)

Troi nutzt eine **flexible Kontakthierarchie**. Die Abteilungsebene ist **optional** und nur bei Konzernkunden relevant.

```
VARIANTE A – Standardfall (kleine/mittlere Kunden):

Firma (Contact:Company, Parent = null)
  z.B. Nick Test GmbH
  → Wird direkt zum CUSTOMER (Auftraggeber)
  │
  └── Kontaktperson (Contact:Person, Parent = Firma)
        z.B. Rohm, Nicolas


VARIANTE B – Konzernkunden (mit Abteilungsstruktur):

Firma (Contact:Company, Parent = null)
  z.B. MERCEDES-BENZ AG
  → Dachgesellschaft, existiert meistens schon, wird NICHT zum Customer
  │
  ├── Person direkt unter Firma (möglich, z.B. übergreifende Kontakte)
  │     z.B. Sautter, Jan
  │
  └── Abteilung / Filiale (Contact:Company, Parent = Firma)
        z.B. Mercedes-Benz AG HCP 098
        → Hat eigene Adresse (Werk/HPC), wird zum CUSTOMER (Auftraggeber)
        │
        └── Kontaktperson (Contact:Person, Parent = Abteilung)
              z.B. Kuhn, Michael
```

**Entscheidungslogik:** Der **Customer** wird auf der Ebene angelegt, auf der die Rechnungsadresse und der Auftraggeber sitzen. Bei kleinen Firmen ist das die Firma selbst, bei Konzernen die Abteilung/Filiale.

### 2.2 Real-World-Beispiele

**Variante A – Kleiner Kunde (Nick Test GmbH):**
```
Nick Test GmbH (Contact:Company, Parent: null)
├── Rohm, Nicolas (Contact:Person, Parent: Nick Test GmbH)
└── Customer: "Nick Test GmbH" (Shortcut: "NTG", Contact → Nick Test GmbH)
```

**Variante B – Konzernkunde (Mercedes-Benz AG):**
```
MERCEDES-BENZ AG (Contact:Company, Parent: null)
├── Sautter, Jan (Contact:Person, direkt unter Firma)
├── Zejnić, Saša (Contact:Person, direkt unter Firma)
├── Mercedes-Benz AG HCP 098 (Contact:Company, Parent: MERCEDES-BENZ AG)
│   ├── Kuhn, Michael (Contact:Person, Parent: HCP 098)
│   └── Customer: "Mercedes-Benz AG HCP 098" (Shortcut: "MER")
├── Mercedes-Benz AG / Werk 3054 (Contact:Company)
├── Mercedes-Benz AG Einkaufsabrechnung (Contact:Company)
└── ... (weitere Abteilungen, jeweils eigener Customer)
```

### 2.3 API-Endpunkte (Troi REST API v2)

| Ressource | GET (list) | GET (single) | POST (create) | PUT (update) |
|---|---|---|---|---|
| `/contacts` | ✅ im MCP | ✅ im MCP | ✅ in Troi API | ✅ in Troi API |
| `/customers` | ✅ im MCP | ✅ im MCP | ✅ in Troi API | ✅ in Troi API |

Die Troi API unterstützt CRUD auf beiden Ressourcen. Der MCP muss nur die POST/PUT-Wrapper hinzufügen.

### 2.4 Datenfelder (aus API-Responses und UI-Analyse)

**Firma (Contact:Company, Parent = null)**
```json
{
  "Type": "ApiContact:Company",
  "Name2": "MERCEDES-BENZ AG",
  "CompanyAddressStreet": "Mercedesstraße 120",
  "CompanyAddressZipCode": "70372",
  "CompanyAddressCity": "Stuttgart",
  "CompanyAddressCountry": "Deutschland",
  "CompanyAddressCountryIso": "DE",
  "CompanyPhone": "",
  "CompanyMail": "",
  "CompanyWeb": "",
  "Parent": null,
  "IsInactive": false,
  "AccessGroup": 0
}
```

**Abteilung/Filiale – optional, nur bei Konzernen (Contact:Company, Parent = Firma)**
```json
{
  "Type": "ApiContact:Company",
  "Name2": "Mercedes-Benz AG HCP 098",
  "CompanyAddressStreet": "Werk/HPC: 098",
  "CompanyAddressZipCode": "70546",
  "CompanyAddressCity": "Stuttgart",
  "CompanyAddressCountry": "Deutschland",
  "CompanyAddressCountryIso": "DE",
  "CompanyAddressState": "",
  "Parent": { "Path": "/contacts/{firma_id}" },
  "IsInactive": false,
  "AccessGroup": 0
}
```

**Kontaktperson (Contact:Person, Parent = Firma oder Abteilung)**
```json
{
  "Type": "ApiContact:Person",
  "Salutation": "Herr",
  "Name1": "Michael",
  "Name2": "Kuhn",
  "Title": "",
  "Position": "",
  "OfficeMail": "michael.kuhn@mercedes-benz.com",
  "OfficePhone": "",
  "OfficeMobile": "",
  "Parent": { "Path": "/contacts/{firma_or_abteilung_id}" },
  "IsInactive": false
}
```

**Customer (Auftraggeber) – auf Firma- oder Abteilungsebene**
```json
{
  "Name": "Nick Test GmbH",
  "Shortcut": "NTG",
  "Contact": { "Path": "/contacts/{firma_or_abteilung_contact_id}" },
  "Client": { "Path": "/clients/1" },
  "IsActive": true,
  "PaymentTerm": { "Path": "/misc/paymentTerms/{id}" },
  "VatNumber": "",
  "TaxNumber": ""
}
```

**Felder aus der UI (Abteilung/Kunde):**
| UI-Feld | API-Feld | Beispielwert |
|---|---|---|
| Filiale | `Name2` (Contact) | Mercedes-Benz AG HCP 098 |
| Straße | `CompanyAddressStreet` | Werk/HPC: 098 |
| PLZ (3 Felder: Land, PLZ, Ort) | `CompanyAddressCountryIso`, `CompanyAddressZipCode`, `CompanyAddressCity` | DE, 70546, Stuttgart |
| Zugriff | `AccessGroup` | 0 (= öffentlich) |
| Zahlungsziel | `PaymentTerm` (auf Customer) | 14 Tage |
| Ist Aktiver Kunde? | `IsActive` (auf Customer) | true |
| Kundenkürzel | `Shortcut` (auf Customer) | MER (3-stellig) |
| Name (in Kundendaten) | `Name` (auf Customer) | = Filialname |

---

## 3. Neue MCP Endpoints

### 3.1 `troi_create_contact` – Firma, Abteilung oder Person anlegen

Erstellt einen neuen Kontakt in Troi. Der `type`-Parameter bestimmt die Ebene.

**Parameter:**

```
troi_create_contact:
  # Pflicht
  name: string                # Firmenname / Abteilungsname / Nachname
  type: "company" | "person"  # Kontakttyp (Firma & Abteilung sind beide "company")

  # Hierarchie
  parent_contact_id?: integer # Für Abteilungen: ID der Firma
                              # Für Personen: ID der Abteilung (oder Firma)
                              # Für Firmen: null/nicht gesetzt

  # Nur für Personen
  first_name?: string         # Vorname
  salutation?: string         # "Herr" / "Frau" / null
  title?: string              # "Dr." / "Prof." etc.
  position?: string           # "Geschäftsführer" etc.

  # Kontaktdaten
  email?: string              # CompanyMail (Company) oder OfficeMail (Person)
  phone?: string              # CompanyPhone (Company) oder OfficePhone (Person)
  mobile?: string             # OfficeMobile (nur Person)
  fax?: string
  website?: string            # CompanyWeb (nur Company)

  # Adresse
  street?: string
  zip_code?: string
  city?: string
  country?: string            # Default: "Deutschland"
  country_iso?: string        # Default: "DE"

  # Sonstiges
  access_group?: integer      # 0 = öffentlich (Default)
  remark?: string
```

**Mapping zu Troi API:**

| Parameter | Company/Abteilung → Troi | Person → Troi |
|---|---|---|
| `name` | `Name2` | `Name2` (Nachname) |
| `first_name` | – | `Name1` (Vorname) |
| `parent_contact_id` | `Parent.Path` → `/contacts/{id}` | `Parent.Path` → `/contacts/{id}` |
| `email` | `CompanyMail` | `OfficeMail` |
| `phone` | `CompanyPhone` | `OfficePhone` |
| `street` | `CompanyAddressStreet` | `CompanyAddressStreet` |
| `zip_code` | `CompanyAddressZipCode` | `CompanyAddressZipCode` |
| `city` | `CompanyAddressCity` | `CompanyAddressCity` |
| `country_iso` | `CompanyAddressCountryIso` | `CompanyAddressCountryIso` |

**Response:** `{ "contact_id": 500, "type": "company", "name": "Mercedes-Benz AG HCP 098" }`

### 3.2 `troi_update_contact` – Kontakt aktualisieren

```
troi_update_contact:
  contact_id: integer (required)
  data: object               # Felder analog zu create, nur gesetzte werden aktualisiert
```

### 3.3 `troi_create_customer` – Auftraggeber anlegen

Erstellt einen Kunden (Auftraggeber) und verknüpft ihn mit einem Contact:Company (Firma direkt oder Abteilung).

```
troi_create_customer:
  name: string               # Kundenname, = Firmenname oder Abteilungsname (required)
  contact_id: integer         # Contact:Company ID – Firma oder Abteilung (required)
  shortcut: string            # 3-stelliges Kürzel, z.B. "MER" (required)
  is_active?: boolean         # Default: true
  payment_term_id?: integer   # Zahlungsziel-ID (z.B. 14 Tage)
  vat_number?: string         # USt-ID
  tax_number?: string         # Steuernummer
```

**Mapping zu Troi API:**
```json
{
  "Name": "Nick Test GmbH",
  "Shortcut": "NTG",
  "Contact": { "Path": "/contacts/{contact_id}" },
  "Client": { "Path": "/clients/1" },
  "IsActive": true,
  "PaymentTerm": { "Path": "/misc/paymentTerms/{id}" }
}
```

**Response:** Customer-Hash-ID (die für `troi_create_offer` und `troi_create_project` benötigt wird).

### 3.4 `troi_update_customer` – Kunden aktualisieren

```
troi_update_customer:
  customer_id: string (hash, required)
  data: object               # Felder analog zu create
```

### 3.5 Compound: `troi_create_customer_with_contact` (P1)

Erstellt Kunde + optional Abteilung + optional Ansprechpartner in einem Call. **Immer mit Dublettencheck.**

Unterstützt beide Varianten:
- **Variante A (Standardfall):** Firma existiert noch nicht → Firma + Person + Customer anlegen
- **Variante B (Konzern):** Firma existiert schon → Abteilung + Person + Customer anlegen

```
troi_create_customer_with_contact:
  # Firma (wird GESUCHT oder NEU angelegt)
  company_name: string (required)          # Name der Firma
  company_id?: integer                     # Falls bekannt, überspringt Dublettencheck
  create_company_if_missing?: boolean      # Default: true – legt Firma an wenn nicht gefunden

  # Abteilung / Filiale (OPTIONAL – nur bei Konzernkunden)
  department_name?: string                 # z.B. "Mercedes-Benz AG HCP 098"
  department_street?: string
  department_zip_code?: string
  department_city?: string
  department_country_iso?: string          # Default: "DE"

  # Adresse (für Firma ODER Abteilung, je nachdem was der Customer wird)
  street?: string
  zip_code?: string
  city?: string
  country_iso?: string                     # Default: "DE"

  # Customer-Daten
  shortcut: string (required)             # 3-stellig, z.B. "MER" oder "NTG"
  is_active?: boolean                      # Default: true
  payment_term_id?: integer                # Zahlungsziel

  # Ansprechpartner (optional)
  contact_first_name?: string
  contact_last_name?: string
  contact_email?: string
  contact_phone?: string
  contact_mobile?: string
  contact_position?: string
  contact_salutation?: string              # "Herr" / "Frau"
```

**Interner Ablauf – Variante A (kein department_name):**

```
1. DUBLETTENCHECK FIRMA
   → troi_list_contacts(search: company_name, type: company)
   → Filtern: nur Contact:Company mit Parent=null
   → 1 Treffer → verwenden
   → 0 Treffer + create_company_if_missing=true → Firma NEU anlegen
   → 0 Treffer + create_company_if_missing=false → Fehler
   → >1 Treffer → Fehler mit Liste, company_id manuell angeben

2. KONTAKTPERSON ANLEGEN (optional, Parent = Firma)
   → POST /contacts (Person, Parent=firma_contact_id)

3. KUNDE ANLEGEN (Contact = Firma)
   → POST /customers (Contact=firma_contact_id)
```

**Interner Ablauf – Variante B (mit department_name):**

```
1. DUBLETTENCHECK FIRMA (wie oben, aber Firma wird NIE neu angelegt)
   → Firma muss existieren bei Konzernkunden

2. DUBLETTENCHECK ABTEILUNG
   → Existiert Abteilung mit gleichem Namen unter Firma? → Fehler

3. ABTEILUNG ANLEGEN (Parent = Firma)
   → POST /contacts (Company, Parent=firma_contact_id)

4. KONTAKTPERSON ANLEGEN (optional, Parent = Abteilung)
   → POST /contacts (Person, Parent=abteilung_contact_id)

5. KUNDE ANLEGEN (Contact = Abteilung)
   → POST /customers (Contact=abteilung_contact_id)
```

**Response:**
```json
{
  "customer_id": "abc123...",
  "customer_name": "Nick Test GmbH",
  "customer_shortcut": "NTG",
  "company_contact_id": 200,
  "company_name": "Nick Test GmbH",
  "company_created": true,
  "department_contact_id": null,
  "department_name": null,
  "person_contact_id": 501,
  "person_name": "Nicolas Rohm"
}
```

Oder bei Konzern-Variante:
```json
{
  "customer_id": "def456...",
  "customer_name": "Mercedes-Benz AG HCP 098",
  "customer_shortcut": "MER",
  "company_contact_id": 200,
  "company_name": "MERCEDES-BENZ AG",
  "company_created": false,
  "department_contact_id": 500,
  "department_name": "Mercedes-Benz AG HCP 098",
  "person_contact_id": 501,
  "person_name": "Michael Kuhn"
}
```

---

## 4. Dublettencheck-Logik

### 4.1 Prinzip

Die **Firma existiert meistens schon** – besonders bei Konzernkunden. Der Workflow soll:

1. **Firma suchen** – Wenn gefunden → verwenden. Wenn nicht gefunden → je nach `create_company_if_missing` anlegen oder Fehler werfen
2. **Abteilung prüfen** (nur wenn `department_name` gesetzt) – Existiert eine Abteilung mit gleichem Namen unter der Firma? Wenn ja → Fehler/Warnung
3. **Person prüfen** – Optional: Existiert eine Person mit gleichem Namen unter Firma/Abteilung?

### 4.2 Suchlogik Firma

```python
# Pseudocode
if company_id:
    # Direkte ID angegeben → kein Dublettencheck
    firma_id = company_id
else:
    results = troi_list_contacts(search=company_name)
    companies = [r for r in results if r.Type == "ApiContact:Company" and r.Parent is None]

    if len(companies) == 1:
        firma_id = companies[0].id
    elif len(companies) == 0:
        if create_company_if_missing:
            # Variante A: Kleine Firma → neu anlegen
            firma_id = POST /contacts (Company, Parent=null)
        else:
            raise Error("Firma '{company_name}' nicht gefunden. "
                        "Bitte exakten Namen prüfen oder manuell anlegen.")
    else:
        raise Error(f"Mehrere Firmen gefunden: {[c.Name2 for c in companies]}. "
                    f"Bitte company_id angeben: {[c.id for c in companies]}")
```

### 4.3 Suchlogik Abteilung (nur wenn department_name gesetzt)

```python
if department_name:
    results = troi_list_contacts(search=department_name)
    existing = [r for r in results
                if r.Type == "ApiContact:Company"
                and r.Parent and r.Parent.id == firma_id
                and r.Name2 == department_name]

    if existing:
        raise Error(f"Abteilung '{department_name}' existiert bereits unter "
                    f"'{firma_name}' (Contact-ID: {existing[0].id}). "
                    f"Bestehende verwenden oder anderen Namen wählen.")
```

---

## 5. Integration mit bestehendem Workflow

### 5.1 End-to-End: Variante A – Kleiner Neukunde + Angebot

```
User: "Lege ein Angebot für Nick Test GmbH an,
       Ansprechpartner Nicolas Rohm (n.rohm@airlst.com),
       Seitzstraße 23, 80538 München.
       1x Professional Lizenz, 3 Tage Dev, ..."

Claude:
  1. troi_create_customer_with_contact
       company_name: "Nick Test GmbH"      → Suche → nicht gefunden → NEU anlegen
       shortcut: "NTG"
       street: "Seitzstraße 23"
       zip_code: "80538"
       city: "München"
       contact_first_name: "Nicolas"
       contact_last_name: "Rohm"
       contact_email: "n.rohm@airlst.com"
     → customer_hash_id (Firma = Customer)

  2. troi_create_offer(customer: customer_hash_id, ...)
     → project_id + positions

Fertig in 2 Calls.
```

### 5.2 End-to-End: Variante B – Neue Abteilung bei Konzernkunde

```
User: "Lege ein Angebot für Mercedes-Benz AG an,
       Abteilung HCP 098, Werk/HPC: 098, 70546 Stuttgart.
       Ansprechpartner Michael Kuhn."

Claude:
  1. troi_create_customer_with_contact
       company_name: "MERCEDES-BENZ AG"   → Suche → gefunden (existiert)
       department_name: "Mercedes-Benz AG HCP 098"
       shortcut: "MER"
       department_street: "Werk/HPC: 098"
       department_zip_code: "70546"
       department_city: "Stuttgart"
       contact_first_name: "Michael"
       contact_last_name: "Kuhn"
     → customer_hash_id (Abteilung = Customer)

  2. troi_create_offer(customer: customer_hash_id, ...)
     → project_id + positions

Fertig in 2 Calls.
```

### 5.3 Person direkt unter Firma (ohne Abteilung, existierende Firma)

```
User: "Füge Jan Sautter als neuen Kontakt bei Mercedes-Benz AG hinzu"

Claude:
  1. troi_list_contacts(search: "MERCEDES-BENZ AG") → firma_id
  2. troi_create_contact(type: "person", name: "Sautter",
       first_name: "Jan", parent_contact_id: firma_id)

Person hängt direkt unter der Firma, keine Abteilung nötig.
```

---

## 6. Priorisierung

| Priorität | Feature | Aufwand | Impact |
|---|---|---|---|
| **P0** | `troi_create_contact` (Firma/Abteilung/Person) | Klein – POST `/contacts` | Grundlage für alles |
| **P0** | `troi_create_customer` | Klein – POST `/customers` | Ermöglicht neue Kunden für Angebote |
| **P1** | `troi_create_customer_with_contact` (Compound mit Dublettencheck) | Mittel – Search + 3 POSTs + Validierung | 1-Call-Workflow, verhindert Duplikate |
| **P1** | `troi_update_contact` / `troi_update_customer` | Klein – PUT auf bestehende Endpoints | Datenkorrektur ohne UI |

---

## 7. Erfolgskriterien

| Metrik | Ist | Soll |
|---|---|---|
| Neuen Kunden anlegen ohne Troi-UI | Nicht möglich | Ja, via MCP |
| Neuer Kunde + Angebot (End-to-End) | 2 Systeme (Troi-UI + Claude) | 1 System (Claude) |
| API-Calls für Neukunde + Angebot | n/a (manuell) | 2 Calls (Compound + Offer) |
| Duplikat-Firmen durch MCP | Möglich | Verhindert durch Dublettencheck |

---

## 8. Technischer Kontext

### 8.1 Troi REST API Basis-URL
```
POST https://airlst.troi.software/api/v2/rest/contacts
POST https://airlst.troi.software/api/v2/rest/customers
PUT  https://airlst.troi.software/api/v2/rest/contacts/{id}
PUT  https://airlst.troi.software/api/v2/rest/customers/{id}
```

### 8.2 Client-ID
Alle Kunden gehören zu Client 1 (AirLST GmbH): `{ "Path": "/clients/1" }`

### 8.3 Validierte Datenstruktur (aus API-Responses)

**Contact:Company als Firma (id: 76, Parent: null):**
- `Name2`: "Mustermann AG" – Firmenname
- `CompanyAddress*`: Firmensitz
- `Parent`: `null` – Top-Level

**Contact:Company als Abteilung (Parent: Firma):**
- `Name2`: "Mercedes-Benz AG HCP 098" – Abteilungsname
- `CompanyAddressStreet`: "Werk/HPC: 098" – kann Werk-Referenz sein
- `CompanyAddressCountryIso`: "DE" – wird separat von PLZ/Ort gespeichert
- `Parent`: `{ "Path": "/contacts/{firma_id}" }` – Verknüpfung zur Dachfirma

**Contact:Person (id: 77, Parent: Firma oder Abteilung):**
- `Name1`: Vorname, `Name2`: Nachname
- `Salutation`, `Title`, `Position`: optional
- `OfficeMail`, `OfficePhone`, `OfficeMobile`: Kontaktdaten
- `Parent`: `{ "Path": "/contacts/{firma_or_abteilung_id}" }` – Parent kann Firma ODER Abteilung sein

**Customer (Auftraggeber):**
- `Name`: Kundenname (= Firmenname oder Abteilungsname)
- `Shortcut`: 3-stellig, Großbuchstaben (bestimmt Projektnummern-Präfix)
- `Contact`: `{ "Path": "/contacts/{firma_or_abteilung_contact_id}" }` – verknüpfte Firma oder Abteilung
- `Client`: `{ "Path": "/clients/1" }`
- `IsActive`: boolean
- `PaymentTerm`: Zahlungsziel-Referenz

### 8.4 Shortcut-Konvention
- 3 Buchstaben, Großbuchstaben
- Abgeleitet vom Firmennamen: Mercedes → MER, Mustermann → MUS, Nick Test → NTG
- Wird als Präfix für Projektnummern verwendet: MER_26_xxxx

### 8.5 PLZ-Format (Besonderheit)
In der Troi-UI werden PLZ-Daten in 3 separaten Feldern eingegeben: Land-ISO (DE), PLZ (70546), Ort (Stuttgart). In der API sind das:
- `CompanyAddressCountryIso`: "DE"
- `CompanyAddressZipCode`: "70546"
- `CompanyAddressCity`: "Stuttgart"
- `CompanyAddressCountry`: "Deutschland" (Langname, zusätzlich)

---

## 9. Open Questions

1. Gibt es Pflichtfelder beim Erstellen von Contacts/Customers, die nicht aus den GET-Responses ersichtlich sind?
2. Wird der `Shortcut` bei der Customer-Erstellung auf Eindeutigkeit geprüft oder kann er doppelt vergeben werden?
3. Welche `PaymentTerm`-IDs sind verfügbar? Gibt es einen Endpoint zum Auflisten (`/misc/paymentTerms`)?
4. Soll der Compound-Endpoint bei Konzernkunden (`department_name` gesetzt) die Firma automatisch anlegen dürfen, oder immer nur bestehende Firmen nutzen?
5. Gibt es Contact-Kategorien oder Tags, die beim Anlegen gesetzt werden müssen?
