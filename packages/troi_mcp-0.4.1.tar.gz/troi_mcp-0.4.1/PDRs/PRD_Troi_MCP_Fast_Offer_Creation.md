# PRD: Troi MCP – Schnelle Angebotserstellung

**Autor:** Nick / AirLST GmbH
**Datum:** 06.03.2026
**Status:** Draft
**Betroffenes System:** Troi MCP Server (Custom Integration)

---

## 1. Problem Statement

Die Erstellung eines vollständigen Troi-Angebots über den MCP Server ist aktuell extrem langsam und fehleranfällig. Ein typisches Angebot mit 10 Positionen erfordert **30+ sequentielle API-Calls** und dauert mehrere Minuten. Zum Vergleich: In der Troi-UI dauert das gleiche Angebot ca. 5 Minuten manuell.

### 1.1 Ist-Zustand: Ablauf eines Angebots (Real-World-Beispiel)

Angebot "Nick Test Event" – 4 Phasen, 10 Positionen, Gesamtwert 11.648 € netto.

| Schritt | Aktion | API-Calls |
|---------|--------|-----------|
| 1 | `tool_search` – Troi-Tools laden | 3–4 |
| 2 | `troi_create_project` (fehlgeschlagen ohne Projekttyp) | 1 |
| 3 | `troi_list_project_types` | 1 |
| 4 | `troi_create_project` (erfolgreich mit project_type) | 1 |
| 5 | `troi_create_subproject` × 4 Phasen | 4 |
| 6 | `troi_create_position_from_pricelist` × 10 Positionen | 10 |
| 7 | `troi_update_position` × 10 (Menge/Preis setzen) | 10 |
| 8 | `troi_get_offer_summary` (Verifizierung) | 1 |
| **Gesamt** | | **~31 Calls** |

**Zusätzliche Probleme, die aufgetreten sind:**

- Projekt wurde ohne Status (`null`) angelegt → unsichtbar in Troi-UI
- Duplikat-Projekt durch fehlgeschlagenen ersten Versuch (Troi erstellt trotz 400-Error)
- `troi_list_projects` gab das korrekte Projekt nicht zurück (vermutlich wegen fehlendem Status)
- PDF-Export (`troi_download_offer_pdf`) funktioniert nicht (Session-Problem mit Legacy-Print-Seite)

### 1.2 Kernprobleme

1. **Keine Batch-Operationen:** Jede Position erfordert 2 sequentielle Calls (create + update für Quantity). Bei 10 Positionen = 20 Calls allein für Positionen.

2. **`create_position_from_pricelist` setzt keine Quantity:** Die Position wird mit `Quantity: 0` angelegt. Ein separater `update_position`-Call ist immer nötig.

3. **Kein Status-Default bei Projekt-Erstellung:** `troi_create_project` setzt keinen Default-Status. Das Projekt ist in der UI unsichtbar, bis manuell gepatcht.

4. **Kein Projekttyp-Default:** Ohne expliziten `project_type`-Parameter schlägt die Erstellung fehl – aber Troi legt trotzdem ein leeres Geisterprojekt an.

5. **Kein Compound-Endpoint für Angebotsstruktur:** Es gibt keinen Weg, Projekt + Subprojekte + Positionen in einem einzigen Call anzulegen.

---

## 2. Ziel

Die Angebotserstellung über den MCP Server soll **von ~31 Calls auf maximal 3–5 Calls** reduziert werden. Ein vollständiges Angebot mit beliebig vielen Phasen und Positionen soll in **unter 30 Sekunden** stehen.

---

## 3. Vorgeschlagene Änderungen

### 3.1 Neuer Endpoint: `troi_create_offer` (Compound/Batch)

Ein einzelner Endpoint, der ein komplettes Angebot in einem Call erstellt:

```json
{
  "customer": "015d3067bec162d009282905b1ba41e8",
  "name": "Nick Test Event",
  "project_type": 28,
  "status_id": 55,
  "internal_description": "Pipedrive Deal #6580",
  "phases": [
    {
      "name": "Lizenzen",
      "positions": [
        {
          "pricelist_item_uuid": "2e9bc11f-3ade-4208-bfb4-695190f2b390",
          "quantity": 1
        }
      ]
    },
    {
      "name": "Programmierung",
      "positions": [
        {
          "pricelist_item_uuid": "948ae9ac-25c8-4bcb-bd57-08d0c7973513",
          "quantity": 3
        }
      ]
    },
    {
      "name": "Projektmanagement, Service & Support",
      "positions": [
        {
          "pricelist_item_uuid": "9cf46666-9270-45e0-a996-446bafdf0a82",
          "quantity": 2
        },
        {
          "pricelist_item_uuid": "643f3f81-75bd-40c6-82d0-97ff6b901eb3",
          "quantity": 0.5
        },
        {
          "pricelist_item_uuid": "ef507273-dbc5-4508-bec8-7632a2b85f04",
          "quantity": 1
        },
        {
          "pricelist_item_uuid": "302cb1f7-c034-4ae7-8292-771c9f2f864f",
          "quantity": 2
        }
      ]
    },
    {
      "name": "Fremdkosten",
      "positions": [
        {
          "pricelist_item_uuid": "12993108-df69-4532-879b-564f223b74af",
          "quantity": 1
        },
        {
          "pricelist_item_uuid": "83f42cdb-2461-4e28-8df0-150e83cab1bf",
          "quantity": 2
        },
        {
          "pricelist_item_uuid": "8b0950b2-ae5d-48dc-a702-a614fa473709",
          "quantity": 1,
          "sale_price_override": 150
        },
        {
          "pricelist_item_uuid": "e94e426d-8504-4aab-b795-f29e60a2168a",
          "quantity": 1,
          "sale_price_override": 500
        }
      ]
    }
  ]
}
```

**Response:** Komplettes Projekt mit allen IDs (project_id, subproject_ids, position_ids) + Gesamtsumme.

**Vorteile:** 1 Call statt 25+. Der MCP Server führt intern die sequentiellen Troi-API-Calls aus, mit Fehlerbehandlung und automatischem Rollback bei Fehlern.

### 3.2 `create_position_from_pricelist` – Quantity-Parameter hinzufügen

Falls der Compound-Endpoint zu aufwändig ist, würde allein die Erweiterung von `create_position_from_pricelist` um einen `quantity`-Parameter (und optional `sale_price_override`) die Calls halbieren:

```
troi_create_position_from_pricelist:
  item_uuid: string (required)
  project_id: integer (required)
  subproject_id: integer (required)
  quantity: number (NEW – default 1)
  sale_price_override: number (NEW – optional)
  group_id: string (optional)
```

**Impact:** 10 Positionen = 10 statt 20 Calls.

### 3.3 `troi_create_project` – Defaults fixen

| Parameter | Aktuell | Vorschlag |
|-----------|---------|-----------|
| `project_type` | Kein Default → 400-Error | Default: `28` (Custom Projekt) |
| Status | `null` → Projekt unsichtbar in UI | Default: `55` (angeboten) |
| Fehlerverhalten | Geisterprojekt bei 400-Error | Kein Projekt anlegen bei Validierungsfehler |

### 3.4 PDF-Export fixen

Der aktuelle `troi_download_offer_pdf` versucht, die Legacy-PHP-Druckseite zu scrapen. Das funktioniert nicht, da die MCP-Session keinen Browser-Cookie hat.

**Alternativen:**
- Troi REST-API PDF-Endpoint nutzen (falls vorhanden – prüfen)
- PDF serverseitig via Puppeteer/Playwright generieren mit authentifizierter Session
- Workaround: `troi_generate_offer_number` funktioniert für genehmigte Dokumente – prüfen ob ein ähnlicher Pfad für Entwürfe existiert

---

## 4. Priorisierung

| Priorität | Feature | Aufwand (geschätzt) | Impact |
|-----------|---------|---------------------|--------|
| **P0** | `create_position_from_pricelist` + quantity | Klein (1 Parameter) | Halbiert Position-Calls |
| **P0** | `create_project` Defaults (status + type) | Klein (2 Defaults) | Verhindert Ghost-Projekte + UI-Unsichtbarkeit |
| **P1** | `troi_create_offer` Compound-Endpoint | Mittel (neuer Endpoint) | Reduziert auf 1 Call |
| **P2** | PDF-Export Fix | Mittel-Hoch (Session-Mgmt) | Ermöglicht End-to-End-Workflow |

---

## 5. Erfolgskriterien

| Metrik | Ist | Soll |
|--------|-----|------|
| API-Calls pro Angebot (10 Pos.) | ~31 | ≤ 5 (mit Compound) oder ≤ 15 (mit Quantity-Param) |
| Fehlerrate bei Projekterstellung | ~50% (Typ/Status-Probleme) | 0% |
| Ghost-Projekte nach fehlerhaften Calls | Ja | Nein |
| PDF-Export funktionsfähig | Nein | Ja |
| Erstellungszeit (End-to-End) | 3–5 Min | < 30 Sek |

---

## 6. Technischer Kontext

### 6.1 Betroffene MCP-Endpoints (aktuell)

- `troi_create_project` – Projekt anlegen
- `troi_create_subproject` – Phase/Unterprojekt anlegen
- `troi_create_position_from_pricelist` – Position aus Preisliste hinzufügen
- `troi_update_position` – Menge/Preis nachträglich setzen
- `troi_download_offer_pdf` – PDF-Export (broken)

### 6.2 Troi API Constraints

- Keine native Batch-API in Troi selbst
- Positionen können nur einzeln angelegt werden
- PDF-Generierung läuft über Legacy-PHP-Frontend (`/site/index.php?page=print`)
- Rate Limit: Auto-Retry bis 5x bei HTTP 429 (exponential backoff), 150ms zwischen Pages

### 6.3 Preisliste Referenz

Standard-Gruppe: **Preisliste 05/25** (`3aaa0d93-5087-11e9-929d-0050569ff533`)

Häufig verwendete Positionen sind im `company_cache.md` des Projekts dokumentiert (UUIDs, Preise, Einheiten).

---

## 7. Open Questions

1. Hat Troi eine undokumentierte Batch-API oder einen Bulk-Import-Endpoint?
2. Gibt es einen REST-Endpoint für PDF-Generierung, der keine Browser-Session braucht?
3. Kann `troi_create_project` so angepasst werden, dass bei Validierungsfehlern kein Geisterprojekt entsteht – oder ist das Troi-seitig ein Bug?
4. Soll der Compound-Endpoint auch bestehende Projekte erweitern können (Positionen zu bestehendem Projekt hinzufügen)?
