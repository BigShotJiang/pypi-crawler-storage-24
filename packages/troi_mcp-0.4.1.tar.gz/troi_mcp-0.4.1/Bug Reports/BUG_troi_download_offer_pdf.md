# Bug Report: `troi_download_offer_pdf` – Fails for Draft Documents, Works for Approved

**Reported:** 2026-03-07
**Updated:** 2026-03-07 (downgraded after approved doc test)
**Severity:** Medium (approved PDFs work; only draft preview is broken)
**Component:** Troi MCP Server – PDF Download Endpoint

---

## Summary

`troi_download_offer_pdf` fails with a 500 error for **draft documents** (Status "N") but **works correctly for approved documents** (Status "A") with an assigned offer number. The tool description claims support for both draft and approved documents, but draft downloads return the Troi SPA shell HTML instead of a PDF.

---

## Reproduction Steps

1. Create a Troi project with positions (e.g. via `troi_create_offer`)
2. Get the document ID via `troi_list_documents` for the project
3. Call `troi_download_offer_pdf` with the document ID

## Test Cases

### FAILED: Document 1718 (Project 749, Status "N", no offer number)
```
Tool:       troi_download_offer_pdf
Parameters: { document_id: 1718, form_id: 45, blank_copies: 1, stationery_copies: 0 }
Result:     500 – Could not find PDF generation URL in print response
```

### FAILED: Document 1715 (Project 746, Status "N", no offer number)
```
Tool:       troi_download_offer_pdf
Parameters: { document_id: 1715 }
Result:     500 – Could not find PDF generation URL in print response
```

### FAILED: Document 1715 with custom output_path
```
Tool:       troi_download_offer_pdf
Parameters: { document_id: 1715, output_path: "/home/claude/Angebot_MUS_26_0663.pdf" }
Result:     [Errno 2] No such file or directory (before even hitting Troi API)
```

### ✅ SUCCESS: Document 1597 (Project 673, Status "A", Offer Nr. 5032_26)
```
Tool:       troi_download_offer_pdf
Parameters: { document_id: 1597 }
Result:     SUCCESS – 469,552 bytes, saved to Downloads/Angebot_FOL_26_0593_07.03.26.pdf
```
**Key difference:** This document is **approved** (Status "A") and has an **assigned offer number** (5032_26). The project is "111 Jahre Sindelfingen" (FOL_26_0593, Follow Red GmbH), a real production project currently "in Arbeit".

---

## Error Response (for draft documents, Status "N")

```
Troi API Error [500]: [500] Could not find PDF generation URL in print response
URL: /site/index.php?page=print&type=O&id=1718
Response: <!DOCTYPE html><html lang="en-US"><head>
    <meta charset="UTF-8">
    <base href="/app">
    ...
```

## Success Response (for approved documents, Status "A")

```json
{
  "path": "/Users/nicolasfuhrmann/Downloads/Angebot_FOL_26_0593_07.03.26.pdf",
  "size": 469552,
  "filename": "Angebot_FOL_26_0593_07.03.26.pdf",
  "document_id": 1597,
  "labels_fixed": true
}
```

---

## Root Cause Analysis (Updated 2026-03-07)

The MCP server calls Troi's legacy PHP print endpoint:
```
GET /site/index.php?page=print&type=O&id={document_id}
```

**Expected response:** HTML page containing a PDF generation URL (likely an `<iframe>` or `<a>` with a PDF link) that the MCP server extracts and follows to download the actual PDF.

**Actual response (for draft documents):** The Troi SPA shell (`<!DOCTYPE html>` with Vue/React app bootstrap CSS). This is the **Angular/Vue app entry point**, not the legacy PHP print page.

### Updated Hypothesis: Document Status Determines Print Access

After testing with an approved document (Doc 1597, Status "A", Nr. 5032_26), the PDF download **works perfectly** in Claude.ai. This disproves the earlier hypothesis that the issue was session/auth-related.

**The actual pattern is:**

| Document Status | Has Number | PDF Download | 
|---|---|---|
| `N` (Entwurf/Draft) | No | ❌ FAILS – Troi redirects to SPA shell |
| `A` (Approved) | Yes (e.g. 5032_26) | ✅ WORKS – PDF generated, 470 KB |
| `A` (Approved) | No | ❓ Untested |

**Revised hypothesis:** Troi's legacy print endpoint (`/site/index.php?page=print`) only generates PDFs for documents that have been approved AND/OR have an assigned offer number. For draft documents (Status "N"), the legacy backend doesn't render the print view and instead falls through to the SPA shell.

### Implication for MCP Server

The `troi_download_offer_pdf` tool description says it works for "BOTH draft (unapproved) and approved documents" with draft offers showing an "Entwurf watermark". This is **not the case in Claude.ai** – draft downloads fail entirely. Either:

1. The MCP tool description needs to be corrected (draft PDFs are not supported), or
2. The print endpoint needs different handling for draft vs. approved documents (possibly a different URL or parameter)

### Secondary Issue: `output_path` causes file system error (unchanged)

When `output_path` is provided, the tool throws `[Errno 2] No such file or directory` before even making the API call. This suggests the MCP server tries to open/create the output file before downloading, and the path either doesn't exist or isn't writable in the Claude.ai container filesystem.

---

## Document Details for Reference

### ❌ Document 1718 (FAILED)
```json
{
  "id": 1718,
  "Status": "N",          // Neu/Entwurf → FAILS
  "Number": null,          // No offer number
  "DocumentType": "O",
  "ProjectId": 749,
  "Project.Name": "Nick Test GmbH - Nick Test Event",
  "Project.Number": "MUS_26_0666"
}
```

### ❌ Document 1715 (FAILED)
```json
{
  "id": 1715,
  "Status": "N",          // Neu/Entwurf → FAILS
  "Number": null,          // No offer number
  "DocumentType": "O",
  "ProjectId": 746,
  "Project.Name": "Nick Test Event 06.03",
  "Project.Number": "MUS_26_0663"
}
```

### ✅ Document 1597 (SUCCESS)
```json
{
  "id": 1597,
  "Status": "A",           // Approved → WORKS
  "Number": "5032_26",     // Has offer number
  "DocumentType": "O",
  "ProjectId": 673,
  "Project.Name": "111 Jahre Sindelfingen",
  "Project.Number": "FOL_26_0593",
  "Customer": "Follow Red GmbH",
  "Signee": "Herter, Aljoscha",
  "Contact": "Maier, Selina"
}
```
Result: PDF saved as `Angebot_FOL_26_0593_07.03.26.pdf` (469,552 bytes), `labels_fixed: true`

---

## Environment

- **Platform:** Claude.ai (web interface) – confirmed working for approved docs
- **MCP Runtime:** Cloud-hosted (Anthropic infrastructure)
- **Troi Instance:** https://airlst.troi.software
- **Troi MCP Server Version:** v0.4.0+ (has `troi_create_offer`)
- **Note:** Earlier hypothesis that this was a Claude.ai vs. Claude Code difference is **disproven**. The issue is document status, not platform.

---

## Suggested Fix (Updated)

### Option A: Support draft PDF downloads via different endpoint/parameter
The legacy print endpoint likely needs a different parameter for drafts vs. approved documents. Investigate whether there's a `&draft=1` parameter or a separate endpoint for Entwurf PDFs in Troi's legacy PHP backend.

### Option B: Update tool description to document the limitation
If draft PDFs are genuinely not supported via the print workflow, update the `troi_download_offer_pdf` description to clarify:
- Draft documents (Status "N") **cannot** be downloaded as PDF
- The document must be approved (Status "A") before PDF download works
- Recommend using `troi_start_approval` → `troi_generate_offer_number` → `troi_download_offer_pdf` as the correct workflow

### Option C: Auto-detect document status and fail gracefully
Before attempting the print endpoint, check the document status via `GET /api/v2/rest/documents/{id}`. If Status is "N", return a helpful error message instead of the cryptic 500:
```
"Cannot download PDF for draft document {id}. The document must be approved first. 
Use troi_start_approval to submit for approval."
```

### Fix for output_path (unchanged)
Ensure the MCP server creates parent directories before attempting to write the output file, or default to a writable temp directory in the Claude.ai container environment.

---

---

## Additional Bug: Wrong Project URL Format

### Problem

The MCP server returns incorrect project URLs in `troi_create_offer` and `troi_get_offer_summary` responses.

### Returned (wrong)
```
https://airlst.troi.software/app/#/project/749
```

### Expected (correct)
```
https://airlst.troi.software/site/index.php?page=project_calculation&status=55&project=749
```

### Details

The `/app/#/project/{id}` URL points to Troi's modern SPA, but the project calculation/offer view is only accessible through the legacy PHP frontend at `/site/index.php`. The `status=55` parameter filters for "angeboten" status which is the default for new offers.

### Fix

In the MCP server, change the URL template from:
```python
f"https://airlst.troi.software/app/#/project/{project_id}"
```
to:
```python
f"https://airlst.troi.software/site/index.php?page=project_calculation&status=55&project={project_id}"
```

This affects the `troi_project_url` / `troi_url` field in responses from:
- `troi_create_offer`
- `troi_get_offer_summary`

---

## Impact

**Approved documents:** PDF download works end-to-end. The full workflow (create offer → approve → generate number → download PDF) is functional.

**Draft documents:** Cannot preview offers as PDF before approval. Users must navigate to Troi UI to preview draft offers manually. This is inconvenient but not blocking, since the approval → download workflow works.

**Workaround:** Complete the approval workflow before downloading. Use `troi_start_approval` → get approval in Troi UI → `troi_generate_offer_number` → `troi_download_offer_pdf`.
