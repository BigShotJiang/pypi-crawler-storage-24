#!/usr/bin/env python3
"""
Troi API Client for AirLST
===========================
Interactive CLI to connect to Troi and explore projects, time entries, and more.

Setup (once):
  export TROI_URL="https://airlst.troi.software"
  export TROI_USER="n.rohm@airlst.com"
  export TROI_API_KEY="a4462d4c7e40932d"
  export TROI_CLIENT_ID="27"

Run:
  python troi_client.py
"""

import os
import sys
import time
from datetime import datetime

try:
    import requests
    from requests.exceptions import HTTPError
except ImportError:
    print("❌ 'requests' nicht installiert. Bitte ausführen: pip install requests")
    sys.exit(1)


# ─── Config ───────────────────────────────────────────────────────────────────

TROI_URL = "https://airlst.troi.software"
TROI_USER = "n.rohm"
TROI_API_KEY = "233f37acc9be5700"
TROI_CLIENT_ID = "1"


def get_headers():
    return {
        "Accept": "application/json",
        "User-Agent": "Mozilla/5.0 (compatible; TroiClient/1.0)",
    }


BASE = f"{TROI_URL}/api/v2/rest"


# ─── API Helpers ──────────────────────────────────────────────────────────────

def _print_debug_response(r, url, params=None):
    """Print detailed debug info about a failed request."""
    print(f"\n  {'─'*55}")
    print(f"  🔍 DEBUG – HTTP {r.status_code}")
    print(f"  URL:     {r.url}")
    if params:
        print(f"  Params:  {params}")
    print(f"  Headers:")
    for k, v in r.headers.items():
        print(f"           {k}: {v}")
    body = r.text.strip()
    print(f"  Body ({len(body)} Zeichen):")
    if body:
        print(f"    {body}")
    else:
        print("    (leer)")
    print(f"  {'─'*55}\n")


def api_get(path: str, params: dict = None):
    headers = get_headers()
    url = f"{BASE}{path}"
    try:
        r = requests.get(url, headers=headers, params=params, auth=(TROI_USER, TROI_API_KEY), timeout=15)
        r.raise_for_status()
        return r.json()
    except HTTPError as e:
        status = r.status_code
        if status == 401:
            print("❌ Nicht authentifiziert (401) – TROI_USER / TROI_API_KEY prüfen")
        elif status == 403:
            print(f"❌ Keine Berechtigung (403) – API-Key hat nicht die nötigen Rechte")
        elif status == 404:
            print(f"❌ Nicht gefunden (404) – Endpunkt existiert nicht oder CLIENT_ID falsch")
        elif status == 429:
            print("⏳ Rate limit (429) – warte 5 Sekunden...")
            time.sleep(5)
            return api_get(path, params)
        else:
            print(f"❌ HTTP {status}: {e}")
        _print_debug_response(r, url, params)
        return []
    except requests.exceptions.ConnectionError as e:
        print(f"❌ Keine Verbindung zu {TROI_URL}")
        print(f"   Detail: {e}")
        return []
    except requests.exceptions.Timeout:
        print(f"❌ Timeout nach 15s – {url}")
        return []
    except Exception as e:
        print(f"❌ Unerwarteter Fehler: {type(e).__name__}: {e}")
        return []


# ─── Features ─────────────────────────────────────────────────────────────────

def test_connection():
    print(f"\n🔗 Verbinde mit {TROI_URL} als {TROI_USER}...")
    print(f"   CLIENT_ID: {TROI_CLIENT_ID}")
    print(f"   API_KEY:   {TROI_API_KEY[:4]}{'*' * (len(TROI_API_KEY) - 4)}")
    params = {"clientId": TROI_CLIENT_ID, "size": 1}
    print(f"   Endpunkt:  GET {BASE}/projects")
    print(f"   Parameter: {params}\n")
    result = api_get("/projects", params)
    if result is not None and result != []:
        print("✅ Verbindung erfolgreich!\n")
        return True
    print("⚠️  Verbindung fehlgeschlagen oder keine Projekte gefunden.\n")
    return False


def diagnose():
    """Test multiple endpoints to figure out what's accessible."""
    print(f"\n🩺 Diagnose – teste verschiedene Endpunkte...")
    print(f"   Base: {BASE}")
    test_url = f"{BASE}/projects?clientId={TROI_CLIENT_ID}&size=1"
    print(f"\n   curl-Äquivalent zum manuellen Testen:")
    print(f"   curl -u '{TROI_USER}:{TROI_API_KEY}' '{test_url}'\n")
    endpoints = [
        ("/clients", None),
        (f"/clients/{TROI_CLIENT_ID}", None),
        ("/employees", {"clientId": TROI_CLIENT_ID}),
        ("/projects", {"clientId": TROI_CLIENT_ID, "size": 1}),
        ("/calculationPositions", {"clientId": TROI_CLIENT_ID}),
        ("/billings/hours", {"clientId": TROI_CLIENT_ID}),
    ]
    for path, params in endpoints:
        url = f"{BASE}{path}"
        headers = get_headers()
        try:
            r = requests.get(url, headers=headers, params=params, auth=(TROI_USER, TROI_API_KEY), timeout=15)
            icon = "✅" if r.ok else "❌"
            print(f"  {icon} {r.status_code}  {path}" + (f"  params={params}" if params else ""))
            if not r.ok:
                body = r.text.strip()[:200]
                print(f"       → {body}")
        except Exception as e:
            print(f"  ❌ ERR  {path} → {e}")


def list_projects(archived: bool = False, search: str = None):
    print(f"\n📁 Lade {'archivierte ' if archived else ''}Projekte...")
    params = {
        "clientId": TROI_CLIENT_ID,
        "size": 200,
    }
    if not archived:
        params["projectIsInProcess"] = "true"
    if search:
        params["search"] = search
    projects = api_get("/projects", params)
    if not projects:
        print("Keine Projekte gefunden.")
        return []

    if search:
        print(f"🔍 Suche nach '{search}': {len(projects)} Treffer\n")

    print(f"{'ID':<8} {'Status':<12}  Name")
    print("─" * 80)
    for p in projects:
        pid = str(p.get("id", ""))
        status = str(p.get("projectStatus", {}).get("name", "") if isinstance(p.get("projectStatus"), dict) else "")
        name = p.get("name", "")
        customer = p.get("customer", {}).get("name", "") if isinstance(p.get("customer"), dict) else ""
        display = f"{customer} / {name}" if customer else name
        print(f"{pid:<8} {status:<12}  {display}")

    print(f"\nTotal: {len(projects)} Projekt(e)")
    return projects


def show_project(project_id: int):
    print(f"\n📋 Projekt {project_id}...")
    project = api_get(f"/projects/{project_id}")
    if not project:
        return

    print(f"\n{'─'*50}")
    for key, val in project.items():
        if val is not None and val != "" and val != []:
            print(f"  {key:<30} {val}")

    # Calculation positions
    positions = api_get("/calculationPositions", {"clientId": TROI_CLIENT_ID, "projectId": project_id})
    if positions:
        print(f"\n  📊 Positionen ({len(positions)}):")
        print(f"  {'ID':<8}  Name")
        print("  " + "─" * 50)
        for pos in positions:
            print(f"  {str(pos.get('id', '')):<8}  {pos.get('name', '')}")


def list_time_entries(project_id: int, start: str = None, end: str = None):
    print(f"\n⏱  Zeiteinträge für Projekt {project_id}...")
    params = {
        "projectId": project_id,
        "clientId": TROI_CLIENT_ID,
    }
    if start:
        params["startDate"] = start
    if end:
        params["endDate"] = end

    entries = api_get("/billings/hours", params)
    if not entries:
        print("Keine Zeiteinträge gefunden.")
        return

    print(f"\n{'Datum':<12} {'Mitarbeiter':<25} {'Stunden':>8}  Beschreibung")
    print("─" * 80)
    total = 0.0
    for e in sorted(entries, key=lambda x: x.get("date", "")):
        date = e.get("date", "")[:10]
        employee = e.get("employee", {})
        user = employee.get("displayName") or employee.get("name", "") if isinstance(employee, dict) else ""
        hours = e.get("hours") or e.get("quantity") or 0
        desc = (e.get("description") or e.get("note") or "")[:40]
        print(f"{date:<12} {user:<25} {hours:>8.2f}  {desc}")
        total += float(hours)
    print(f"\nGesamt: {total:.2f} Stunden")


def list_billings(project_id: int):
    print(f"\n💰 Stunden-Abrechnungen für Projekt {project_id}...")
    params = {
        "projectId": project_id,
        "clientId": TROI_CLIENT_ID,
    }
    billings = api_get("/billings/hours", params)
    if not billings:
        print("Keine Rechnungen gefunden.")
        return

    print(f"\n{'Datum':<12} {'Betrag':>12}  Beschreibung")
    print("─" * 60)
    total = 0.0
    for b in billings:
        date = (b.get("date") or b.get("billingDate") or "")[:10]
        amount = b.get("amount") or b.get("net") or 0
        desc = (b.get("description") or b.get("name") or "")[:35]
        print(f"{date:<12} {float(amount):>12,.2f} €  {desc}")
        total += float(amount)
    print(f"\nGesamt: {total:,.2f} €")


# ─── Interactive Menu ─────────────────────────────────────────────────────────

def menu():
    print("\n" + "═" * 50)
    print("  🎯 Troi API Client – AirLST")
    print("═" * 50)
    print("  1  Verbindung testen")
    print("  2  Aktive Projekte listen")
    print("  3  Projekte suchen")
    print("  4  Projekt-Detail anzeigen")
    print("  5  Zeiteinträge eines Projekts")
    print("  6  Rechnungen eines Projekts")
    print("  7  Archivierte Projekte listen")
    print("  d  Diagnose (alle Endpunkte testen)")
    print("  0  Beenden")
    print("─" * 50)
    return input("  Auswahl: ").strip()


def prompt(label: str, default: str = None) -> str:
    hint = f" [{default}]" if default else ""
    val = input(f"  {label}{hint}: ").strip()
    return val or default or ""


def run():
    while True:
        choice = menu()
        if choice == "0":
            print("\n👋 Tschüss!\n")
            break
        elif choice == "1":
            test_connection()
        elif choice == "2":
            list_projects()
        elif choice == "3":
            q = prompt("Suchbegriff (Name oder Kunde)")
            list_projects(search=q)
        elif choice == "4":
            pid = prompt("Projekt-ID")
            if pid.isdigit():
                show_project(int(pid))
            else:
                print("❌ Ungültige ID")
        elif choice == "5":
            pid = prompt("Projekt-ID")
            start = prompt("Von (YYYY-MM-DD, leer = alle)", "")
            end = prompt("Bis (YYYY-MM-DD, leer = alle)", "")
            if pid.isdigit():
                list_time_entries(int(pid), start or None, end or None)
            else:
                print("❌ Ungültige ID")
        elif choice == "6":
            pid = prompt("Projekt-ID")
            if pid.isdigit():
                list_billings(int(pid))
            else:
                print("❌ Ungültige ID")
        elif choice == "7":
            list_projects(archived=True)
        elif choice == "d":
            diagnose()
        else:
            print("❌ Ungültige Auswahl")

        input("\n  ↩️  Enter zum Fortfahren...")


if __name__ == "__main__":
    run()