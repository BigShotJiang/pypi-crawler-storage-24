# troi-mcp

MCP server that connects Claude Desktop to [Troi](https://www.troi.de/) project management & time tracking.

## Setup

### 1. Install

```bash
pip install troi-mcp
```

### 2. Get your Troi API key

Troi → Profile (top right) → API → Copy key

### 3. Add to Claude Desktop config

Edit `~/Library/Application Support/Claude/claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "troi": {
      "command": "uvx",
      "args": ["troi-mcp"],
      "env": {
        "TROI_URL": "https://yourcompany.troi.software",
        "TROI_USER": "j.doe",
        "TROI_API_KEY": "your-api-key",
        "TROI_CLIENT_ID": "1"
      }
    }
  }
}
```

**Important:** `TROI_USER` is your Troi login name (e.g. `j.doe`), *not* your email address.

### 4. Restart Claude Desktop

The Troi tools will be available automatically.

## Available Tools

| Tool | Description |
|------|-------------|
| `troi_list_projects` | List/search projects |
| `troi_get_project` | Get project details |
| `troi_list_positions` | List calculation positions (service lines) |
| `troi_get_position` | Get position details |
| `troi_list_time_entries` | List booked hours |
| `troi_get_time_entry` | Get time entry details |
| `troi_create_time_entry` | Book time |
| `troi_update_time_entry` | Update a time entry |
| `troi_delete_time_entry` | Delete a time entry |
| `troi_list_employees` | List employees |
| `troi_get_employee` | Get employee details |
| `troi_list_customers` | List customers |
| `troi_get_customer` | Get customer details |
| `troi_list_clients` | List clients (Mandanten) |
| `troi_get_client` | Get client details |
| `troi_list_absences` | List absences |
| `troi_list_contacts` | List/search contacts |
| `troi_get_contact` | Get contact details |
| `troi_list_calendar_events` | List calendar events |
| `troi_list_booking_years` | List booking years |

## License

MIT
