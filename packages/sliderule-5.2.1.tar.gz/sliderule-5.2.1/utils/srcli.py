# Copyright (c) 2026, University of Washington
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
# 1. Redistributions of source code must retain the above copyright notice,
#    this list of conditions and the following disclaimer.
#
# 2. Redistributions in binary form must reproduce the above copyright notice,
#    this list of conditions and the following disclaimer in the documentation
#    and/or other materials provided with the distribution.
#
# 3. Neither the name of the University of Washington nor the names of its
#    contributors may be used to endorse or promote products derived from this
#    software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE UNIVERSITY OF WASHINGTON AND CONTRIBUTORS
# “AS IS” AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
# TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
# PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE UNIVERSITY OF WASHINGTON OR
# CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
# EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
# PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
# OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
# WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
# OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
# ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

import json
import argparse
import sliderule

# Command Line Arguments
parser = argparse.ArgumentParser(description="""SlideRule Command Line Interface""")
parser.add_argument('--domain',             type=str,               default="slideruleearth.io")
parser.add_argument('--cluster',            type=str,               default="developers")
parser.add_argument('--is_public',          type=str,               default="false")
parser.add_argument('--node_capacity',      type=int,               default=None)
parser.add_argument('--ttl',                type=int,               default=60) # 1 hour
parser.add_argument('--version',            type=str,               default="unstable")
parser.add_argument('--branch',             type=str,               default="main")
parser.add_argument('--report',             type=str,               default="clusters")
parser.add_argument('--args',               nargs='+', type=str,    default=None)
parser.add_argument('-j', '--asjson',       action='store_true',    default=False)
parser.add_argument('-c', '--commands',     nargs='+', type=str,    default=[])
args,_ = parser.parse_known_args()

# Create Session
session = sliderule.create_session(domain=args.domain, cluster=args.cluster, verbose=True)

# Command Runner
CommandRunner = {
    # Provisioner
    "deploy": lambda: session.provisioner.deploy(is_public=(args.is_public == "true"), node_capacity=args.node_capacity, ttl=args.ttl, version=args.version),
    "extend": lambda: session.provisioner.extend(ttl=args.ttl),
    "destroy": session.provisioner.destroy,
    "status": session.provisioner.status,
    "events": session.provisioner.events,
    "report": lambda: session.provisioner.report(kind=args.report),
    "test": lambda: session.provision("test", {"branch":args.branch}),
    "info": session.provisioner.info,
    # Cluster
    "version": lambda: session.source("version"),
    # Runner
    "jobs": lambda: session.runner.jobs(job_list=args.args),
    "job_queue": lambda: session.runner.queue(job_state=args.args),
    "job_cancel": lambda: session.runner.cancel_all(job_list=args.args),
    "job_cancel_all": session.runner.cancel_all
}

# Execute Commands
for command in args.commands:
    result = CommandRunner[command]()
    if args.asjson:
        print(json.dumps(result, indent=2))
    else:
        print(result)