from .auth import using_refresh_token as using_refresh_token, using_uname_pword as using_uname_pword
from .user import get_student_info as get_student_info

__all__ = ["get_student_info", "using_uname_pword", "using_refresh_token",]

import subprocess
import sys

def init():
    try:
        subprocess.run(
            [sys.executable, "-m", "playwright", "install"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            check=True
        )
    except Exception:
        pass