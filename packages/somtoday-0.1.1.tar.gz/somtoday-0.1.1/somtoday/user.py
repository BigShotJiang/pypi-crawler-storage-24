import requests
from somtoday import auth

def get_student_info(login_method, *args):
    """get_student_info

    Args:
        login_method (string): How do you login? (access_token/refresh_token/uname_pword)
        Access_token:
            argh[0]: access_token
        refresh
            
        

    Returns:
        JSON: Student info.
    """
    
    try:
        match login_method:
            case "access_token": 
                access_token = args[0]
            case "refresh_token":                
                returned_rt = auth.using_refresh_token(args[0])
                access_token = returned_rt["access_token"]
            case "uname_pword":
                if len(args) > 3: email = args[3]
                else: email = None
                returned_up = auth.using_uname_pword(args[0], args[1], args[2], email)
                access_token = returned_up["access_token"]
            case _:
                return "This login method does not exist."
    except IndexError as e:
        return "Somewhere there is this error."
    
    headers = {
        "Authorization": f"Bearer {access_token}",
        "Accept": "application/json",
        "Accept-Language": "en-US",
        "User-Agent": "Mozilla/5.0"
    }
    getStudentInfo = requests.get(url="https://api.somtoday.nl/rest/v1/leerlingen", headers=headers)
    
    return getStudentInfo.json()