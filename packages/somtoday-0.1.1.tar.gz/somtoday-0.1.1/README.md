# SomToday 
Just something everybody can use for creating their own app using SomToday's endpoints!