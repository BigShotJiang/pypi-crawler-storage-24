# 🤖 AI Assistant Automator

This Python script uses the Google Gemini AI to automate solving Multiple Choice Questions (MCQs) and answering subjective/coding questions directly from your screen. It is controlled entirely by global hotkeys.

## ✨ Features

-   **Two distinct modes:** MCQ Solver and Subjective/Coding Assistant.
-   **MCQ Mode:**
    -   Captures a question and any number of options from the screen.
    -   Optionally uses a "context" screenshot for reading comprehension questions.
    -   Automatically identifies the correct option and clicks it.
-   **Subjective/Coding Mode:**
    -   Captures one or more screenshots of a question.
    -   Generates a detailed text or code answer.
    -   **Auto-types** the response with human-like delays.
    -   Supports **pausing and resuming** the auto-typing process.
-   **Hotkey Driven:** No command-line interaction needed after launching.
-   **Robust Logging:** Saves all actions to `mcq_automator.log` for easy debugging.

---

## ⚙️ Setup and Installation

### 1. Prerequisites
-   Python 3.7+

### 2. Get Your API Key
-   You need a Google AI (Gemini) API key. You can get one from [Google AI Studio](https://aistudio.google.com/app/apikey).

### 3. Configure the Script
-   Create a file named `.env` in the same directory as the script.
-   Add your API key to this file like so:
    ```
    GEMINI_API_KEY="your_actual_api_key_here"
    ```
-   The script will automatically load this key. **Do not paste your key directly into the Python script.**

### 4. Install Dependencies
-   Open your terminal or command prompt and run the following command to install all the required libraries:

- For Windows

    ```bash
    pip install -r requirements.txt
    ```

- For Mac

    ```bash
    python3 -m pip install -r requirements.txt
    ```

---

## 🚀 How to Use

1.  **Easy Setup:** Double-click `setup_and_run.bat` to install dependencies and start the app automatically.
2.  **Manual Run:**
    ```bash
    python run.py
    ```
3.  **Auto-Restart Mode (Recommended):**
    -   If you want the application to automatically restart if it crashes (e.g., due to an error), run:
    ```bash
    python auto_restart.py
    ```
4.  The script will now be running in the background, listening for hotkeys.

### Workflow 1: Solving an MCQ

1.  **(Optional) Capture Context:** If the MCQ is based on a passage of text, press `Ctrl+Alt+C`. Click the top-left and then the bottom-right corners of the passage. A confirmation will appear in the console.
2.  **Capture Question:** Press `Ctrl+Alt+P`.
    -   First, click the **top-left** and then the **bottom-right** corners of the entire question area (including the options).
    -   Next, the console will ask you to click on each option. Click the center of each option button or text in order (1, 2, 3, 4, ...).
    -   Press the **Enter** key when you are done clicking all the options.
3.  **Wait:** The script will send the images to the AI and, once it gets a response, will automatically move the mouse and click the correct option.
4.  **(Optional) Clear Context:** If you want to solve the next MCQ without the previous context, press `Ctrl+Alt+R`.

### Workflow 2: Answering a Subjective/Coding Question

1.  **Capture Screenshot(s):** Press `Ctrl+Alt+S`. Click the top-left and bottom-right corners of the question. You can do this multiple times to capture different parts of a long question. The script will remember all screenshots in order.
2.  **Generate Response:** Once you have captured all necessary screenshots, press `Ctrl+Alt+G`. The script will send the images to the AI in the background. The console will show "AI is working...". Wait for atleast **60 seconds** for the response to be generated. 
3.  **Auto-Type the Response:**
    -   Click your mouse inside the text box where you want the answer to be typed.
    -   Press `Ctrl+Alt+T`. After a 3-second delay, the script will start typing the AI's response.
    -   **To Pause:** If you click your mouse anywhere while it's typing, the process will pause automatically.
    -   **To Resume:** Press `Ctrl+Alt+Z` to resume typing from where it left off.

### Workflow 3: Step-by-Step Solution

1.  **Capture Screenshot(s):** Press `Ctrl+Alt+S` (same as Subjective Mode).ā
2.  **Generate Solution:** Press `Ctrl+Alt+O`.
    -   The AI will generate a detailed, step-by-step breakdown of the solution without classifying the question type.
    -   The result will appear in the **Explanation Window**.
3.  **View/Hide:** Press `Ctrl+Alt+A` to toggle the Explanation Window visibility.

### Workflow 4: Stealth Tools (Hidden Notes & Explanations)

1.  **Hidden Notes:**
    -   Press `Ctrl+Alt+N` to toggle a stealthy, dark-mode notepad.
    -   **Stealth:** It is invisible to screen sharing software (Zoom/Teams/OBS) and does not appear on the taskbar.
    -   **Move:** Use `Ctrl+Alt+ArrowKeys` (Left/Right) or `Ctrl+Alt+PageUp/PageDown` to move the window around.
2.  **Code Explanation:**
    -   After generating a code solution (`Ctrl+Alt+G`), press `Ctrl+Alt+J`.
    -   The AI will generate a summary, step-by-step approach, dry run, and complexity analysis.
    -   A new window (sharing the same stealth properties) will appear with the explanation.
    -   Toggle this window with `Ctrl+Alt+A`.

### Workflow 5: Control Panel

1.  **Open Control Panel:**
    -   Press `Ctrl+Alt+M` to open the Master Control Panel.
    -   **Features:**
        -   **Change API Key:** Update your Google Gemini API key directly.
        -   **Customize Hotkeys:** Change any of the global hotkeys to your preference.
        -   **Toggle Features:** Enable or disable the Hidden Notes or Code Explanation features.
        -   **Resize Windows:** Adjust the default width and height for the Notes and Explanation windows.
    -   **Restart:** Click the "Restart AI" button to apply changes immediately (especially for hotkeys).

---

## 📦 Building and Running Deployed Version

You can package this application as a standalone Windows application with a graphical manager.

### 1. Build the Application
We have provided an automated script to build the application.
1.  Double-click **`build_app.bat`**.
2.  Wait for the process to complete. It will create a `dist/LuluApp` folder.

### 2. Run the Application
1.  Double-click **`run_manager.bat`** (or run `dist/LuluApp/LuluManager.exe`).
2.  The **Lulu AI Manager** window will open.
3.  Click **Start Service** to enable the AI hotkeys.
4.  You can close the manager window; the service will run in the background.

### 3. Logs & Troubleshooting
-   Logs are stored in `%LOCALAPPDATA%\LuluApp\logs\app.log`.
-   You can view live logs in the Manager window.

---

## ⌨️ Hotkey Reference

| Hotkey                 | Action                                                  |
| ---------------------- | ------------------------------------------------------- |
| `Ctrl+Alt+C`           | **Capture Context** for an MCQ.                         |
| `Ctrl+Alt+P`           | **Capture Question & Options** for an MCQ.              |
| `Ctrl+Alt+S`           | **Capture a Screenshot** for a subjective question.     |
| `Ctrl+Alt+G`           | **Generate AI Response** from captured screenshots.     |
| `Ctrl+Alt+J`           | **Explain Code** (Summary, Dry Run, Complexity).        |
| `Ctrl+Alt+O`           | **Step-by-Step Solution** (No classification).          |
| `Ctrl+Alt+K`           | **Debug AI Response** from captured screenshots.        |
| `Ctrl+Alt+T`           | **Auto-Type** the generated AI response.                |
| `Ctrl+Alt+Z`           | **Resume** a paused auto-typing session.                |
| `Ctrl+Alt+N`           | **Toggle Hidden Notes** window.                         |
| `Ctrl+Alt+A`           | **Toggle Explanation** window.                          |
| `Ctrl+Alt+M`           | **Open Control Panel** to configure settings.           |
| `Ctrl+Alt+Arrows`      | **Move** the active stealth window.                     |
| `Ctrl+Alt+R`           | **Reset/Clear** all captured context and screenshots.   |
| `Ctrl+Alt+E`           | **Exit** the script.                                    |