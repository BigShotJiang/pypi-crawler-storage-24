from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.create_file_connection_request import CreateFileConnectionRequest
from ...models.file_connection import FileConnection
from ...models.http_validation_error import HTTPValidationError
from ...types import UNSET, Response


def _get_kwargs(
    *,
    body: CreateFileConnectionRequest,
    project_id: str,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    params: dict[str, Any] = {}

    params["projectId"] = project_id

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/connections/file",
        "params": params,
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> FileConnection | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = FileConnection.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[FileConnection | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: CreateFileConnectionRequest,
    project_id: str,
) -> Response[FileConnection | HTTPValidationError]:
    """Create File Connection

     Create a new file connection. Requires member role.

    Args:
        project_id (str):
        body (CreateFileConnectionRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[FileConnection | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        body=body,
        project_id=project_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: CreateFileConnectionRequest,
    project_id: str,
) -> FileConnection | HTTPValidationError | None:
    """Create File Connection

     Create a new file connection. Requires member role.

    Args:
        project_id (str):
        body (CreateFileConnectionRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        FileConnection | HTTPValidationError
    """

    return sync_detailed(
        client=client,
        body=body,
        project_id=project_id,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: CreateFileConnectionRequest,
    project_id: str,
) -> Response[FileConnection | HTTPValidationError]:
    """Create File Connection

     Create a new file connection. Requires member role.

    Args:
        project_id (str):
        body (CreateFileConnectionRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[FileConnection | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        body=body,
        project_id=project_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: CreateFileConnectionRequest,
    project_id: str,
) -> FileConnection | HTTPValidationError | None:
    """Create File Connection

     Create a new file connection. Requires member role.

    Args:
        project_id (str):
        body (CreateFileConnectionRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        FileConnection | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
            project_id=project_id,
        )
    ).parsed
