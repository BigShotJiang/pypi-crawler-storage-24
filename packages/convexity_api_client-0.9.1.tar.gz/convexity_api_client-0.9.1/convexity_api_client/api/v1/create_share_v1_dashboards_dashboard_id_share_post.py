from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.create_share_request import CreateShareRequest
from ...models.dashboard_share_response import DashboardShareResponse
from ...models.http_validation_error import HTTPValidationError
from ...types import Response


def _get_kwargs(
    dashboard_id: str,
    *,
    body: CreateShareRequest,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/dashboards/{dashboard_id}/share".format(
            dashboard_id=quote(str(dashboard_id), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> DashboardShareResponse | HTTPValidationError | None:
    if response.status_code == 201:
        response_201 = DashboardShareResponse.from_dict(response.json())

        return response_201

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[DashboardShareResponse | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    dashboard_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: CreateShareRequest,
) -> Response[DashboardShareResponse | HTTPValidationError]:
    """Create Share

     Create or update a share for a dashboard.
    If an active share already exists, it will be updated with the new settings.
    Requires member role.

    Args:
        dashboard_id (str):
        body (CreateShareRequest): Request to create or update a dashboard share.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DashboardShareResponse | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        dashboard_id=dashboard_id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    dashboard_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: CreateShareRequest,
) -> DashboardShareResponse | HTTPValidationError | None:
    """Create Share

     Create or update a share for a dashboard.
    If an active share already exists, it will be updated with the new settings.
    Requires member role.

    Args:
        dashboard_id (str):
        body (CreateShareRequest): Request to create or update a dashboard share.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DashboardShareResponse | HTTPValidationError
    """

    return sync_detailed(
        dashboard_id=dashboard_id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    dashboard_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: CreateShareRequest,
) -> Response[DashboardShareResponse | HTTPValidationError]:
    """Create Share

     Create or update a share for a dashboard.
    If an active share already exists, it will be updated with the new settings.
    Requires member role.

    Args:
        dashboard_id (str):
        body (CreateShareRequest): Request to create or update a dashboard share.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DashboardShareResponse | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        dashboard_id=dashboard_id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    dashboard_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: CreateShareRequest,
) -> DashboardShareResponse | HTTPValidationError | None:
    """Create Share

     Create or update a share for a dashboard.
    If an active share already exists, it will be updated with the new settings.
    Requires member role.

    Args:
        dashboard_id (str):
        body (CreateShareRequest): Request to create or update a dashboard share.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DashboardShareResponse | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            dashboard_id=dashboard_id,
            client=client,
            body=body,
        )
    ).parsed
