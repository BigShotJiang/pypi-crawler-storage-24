from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.schema_response import SchemaResponse
from ...types import Response


def _get_kwargs(
    connection_id: str,
    table_name: str,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/connections/{connection_id}/tables/{table_name}/schema".format(
            connection_id=quote(str(connection_id), safe=""),
            table_name=quote(str(table_name), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | SchemaResponse | None:
    if response.status_code == 200:
        response_200 = SchemaResponse.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | SchemaResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    connection_id: str,
    table_name: str,
    *,
    client: AuthenticatedClient | Client,
) -> Response[HTTPValidationError | SchemaResponse]:
    """Get Table Schema

     Get table schema. Requires viewer role.

    Args:
        connection_id (str):
        table_name (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | SchemaResponse]
    """

    kwargs = _get_kwargs(
        connection_id=connection_id,
        table_name=table_name,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    connection_id: str,
    table_name: str,
    *,
    client: AuthenticatedClient | Client,
) -> HTTPValidationError | SchemaResponse | None:
    """Get Table Schema

     Get table schema. Requires viewer role.

    Args:
        connection_id (str):
        table_name (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | SchemaResponse
    """

    return sync_detailed(
        connection_id=connection_id,
        table_name=table_name,
        client=client,
    ).parsed


async def asyncio_detailed(
    connection_id: str,
    table_name: str,
    *,
    client: AuthenticatedClient | Client,
) -> Response[HTTPValidationError | SchemaResponse]:
    """Get Table Schema

     Get table schema. Requires viewer role.

    Args:
        connection_id (str):
        table_name (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | SchemaResponse]
    """

    kwargs = _get_kwargs(
        connection_id=connection_id,
        table_name=table_name,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    connection_id: str,
    table_name: str,
    *,
    client: AuthenticatedClient | Client,
) -> HTTPValidationError | SchemaResponse | None:
    """Get Table Schema

     Get table schema. Requires viewer role.

    Args:
        connection_id (str):
        table_name (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | SchemaResponse
    """

    return (
        await asyncio_detailed(
            connection_id=connection_id,
            table_name=table_name,
            client=client,
        )
    ).parsed
