from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.preview_response import PreviewResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    connection_id: str,
    *,
    limit: int | Unset = 10,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["limit"] = limit

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/connections/api/{connection_id}/preview".format(
            connection_id=quote(str(connection_id), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | PreviewResponse | None:
    if response.status_code == 200:
        response_200 = PreviewResponse.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | PreviewResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    connection_id: str,
    *,
    client: AuthenticatedClient | Client,
    limit: int | Unset = 10,
) -> Response[HTTPValidationError | PreviewResponse]:
    """Preview Api Data

     Preview API data. Requires viewer role.

    Args:
        connection_id (str):
        limit (int | Unset): Max rows to return Default: 10.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | PreviewResponse]
    """

    kwargs = _get_kwargs(
        connection_id=connection_id,
        limit=limit,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    connection_id: str,
    *,
    client: AuthenticatedClient | Client,
    limit: int | Unset = 10,
) -> HTTPValidationError | PreviewResponse | None:
    """Preview Api Data

     Preview API data. Requires viewer role.

    Args:
        connection_id (str):
        limit (int | Unset): Max rows to return Default: 10.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | PreviewResponse
    """

    return sync_detailed(
        connection_id=connection_id,
        client=client,
        limit=limit,
    ).parsed


async def asyncio_detailed(
    connection_id: str,
    *,
    client: AuthenticatedClient | Client,
    limit: int | Unset = 10,
) -> Response[HTTPValidationError | PreviewResponse]:
    """Preview Api Data

     Preview API data. Requires viewer role.

    Args:
        connection_id (str):
        limit (int | Unset): Max rows to return Default: 10.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | PreviewResponse]
    """

    kwargs = _get_kwargs(
        connection_id=connection_id,
        limit=limit,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    connection_id: str,
    *,
    client: AuthenticatedClient | Client,
    limit: int | Unset = 10,
) -> HTTPValidationError | PreviewResponse | None:
    """Preview Api Data

     Preview API data. Requires viewer role.

    Args:
        connection_id (str):
        limit (int | Unset): Max rows to return Default: 10.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | PreviewResponse
    """

    return (
        await asyncio_detailed(
            connection_id=connection_id,
            client=client,
            limit=limit,
        )
    ).parsed
