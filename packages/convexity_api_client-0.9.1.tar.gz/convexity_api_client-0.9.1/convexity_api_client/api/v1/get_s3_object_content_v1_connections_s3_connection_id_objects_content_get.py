from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.s3_object_content import S3ObjectContent
from ...types import UNSET, Response


def _get_kwargs(
    connection_id: str,
    *,
    key: str,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["key"] = key

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/connections/s3/{connection_id}/objects/content".format(
            connection_id=quote(str(connection_id), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | S3ObjectContent | None:
    if response.status_code == 200:
        response_200 = S3ObjectContent.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | S3ObjectContent]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    connection_id: str,
    *,
    client: AuthenticatedClient | Client,
    key: str,
) -> Response[HTTPValidationError | S3ObjectContent]:
    """Get S3 Object Content

     Get S3 object content. Requires viewer role.

    Args:
        connection_id (str):
        key (str): Object key to preview

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | S3ObjectContent]
    """

    kwargs = _get_kwargs(
        connection_id=connection_id,
        key=key,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    connection_id: str,
    *,
    client: AuthenticatedClient | Client,
    key: str,
) -> HTTPValidationError | S3ObjectContent | None:
    """Get S3 Object Content

     Get S3 object content. Requires viewer role.

    Args:
        connection_id (str):
        key (str): Object key to preview

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | S3ObjectContent
    """

    return sync_detailed(
        connection_id=connection_id,
        client=client,
        key=key,
    ).parsed


async def asyncio_detailed(
    connection_id: str,
    *,
    client: AuthenticatedClient | Client,
    key: str,
) -> Response[HTTPValidationError | S3ObjectContent]:
    """Get S3 Object Content

     Get S3 object content. Requires viewer role.

    Args:
        connection_id (str):
        key (str): Object key to preview

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | S3ObjectContent]
    """

    kwargs = _get_kwargs(
        connection_id=connection_id,
        key=key,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    connection_id: str,
    *,
    client: AuthenticatedClient | Client,
    key: str,
) -> HTTPValidationError | S3ObjectContent | None:
    """Get S3 Object Content

     Get S3 object content. Requires viewer role.

    Args:
        connection_id (str):
        key (str): Object key to preview

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | S3ObjectContent
    """

    return (
        await asyncio_detailed(
            connection_id=connection_id,
            client=client,
            key=key,
        )
    ).parsed
