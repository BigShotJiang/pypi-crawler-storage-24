from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.worker_task_response import WorkerTaskResponse
from ...types import Response


def _get_kwargs(
    dataset_id: str,
    task_id: str,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/datasets/{dataset_id}/refresh/{task_id}/cancel".format(
            dataset_id=quote(str(dataset_id), safe=""),
            task_id=quote(str(task_id), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | WorkerTaskResponse | None:
    if response.status_code == 200:
        response_200 = WorkerTaskResponse.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | WorkerTaskResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    dataset_id: str,
    task_id: str,
    *,
    client: AuthenticatedClient | Client,
) -> Response[HTTPValidationError | WorkerTaskResponse]:
    """Cancel Refresh Task

     Cancel a pending or running refresh task for a dataset. Requires member role.

    Args:
        dataset_id (str):
        task_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | WorkerTaskResponse]
    """

    kwargs = _get_kwargs(
        dataset_id=dataset_id,
        task_id=task_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    dataset_id: str,
    task_id: str,
    *,
    client: AuthenticatedClient | Client,
) -> HTTPValidationError | WorkerTaskResponse | None:
    """Cancel Refresh Task

     Cancel a pending or running refresh task for a dataset. Requires member role.

    Args:
        dataset_id (str):
        task_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | WorkerTaskResponse
    """

    return sync_detailed(
        dataset_id=dataset_id,
        task_id=task_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    dataset_id: str,
    task_id: str,
    *,
    client: AuthenticatedClient | Client,
) -> Response[HTTPValidationError | WorkerTaskResponse]:
    """Cancel Refresh Task

     Cancel a pending or running refresh task for a dataset. Requires member role.

    Args:
        dataset_id (str):
        task_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | WorkerTaskResponse]
    """

    kwargs = _get_kwargs(
        dataset_id=dataset_id,
        task_id=task_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    dataset_id: str,
    task_id: str,
    *,
    client: AuthenticatedClient | Client,
) -> HTTPValidationError | WorkerTaskResponse | None:
    """Cancel Refresh Task

     Cancel a pending or running refresh task for a dataset. Requires member role.

    Args:
        dataset_id (str):
        task_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | WorkerTaskResponse
    """

    return (
        await asyncio_detailed(
            dataset_id=dataset_id,
            task_id=task_id,
            client=client,
        )
    ).parsed
