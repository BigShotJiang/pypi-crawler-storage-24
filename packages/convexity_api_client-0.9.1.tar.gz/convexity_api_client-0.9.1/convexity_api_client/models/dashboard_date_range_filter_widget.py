from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, Literal, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.date_range_value import DateRangeValue


T = TypeVar("T", bound="DashboardDateRangeFilterWidget")


@_attrs_define
class DashboardDateRangeFilterWidget:
    """Date range filter widget with start and end date pickers.

    Attributes:
        id (str): Unique widget identifier
        column_name (str): Name of the column in dataset rows to filter on
        title (None | str | Unset): Widget title
        description (None | str | Unset): Widget description
        show_title (bool | None | Unset): Whether to display the widget title Default: True.
        show_description (bool | None | Unset): Whether to display the widget description Default: True.
        type_ (Literal['daterange_filter'] | Unset):  Default: 'daterange_filter'.
        is_filter (bool | Unset): Indicates this is a filter widget Default: True.
        dataset_ids (list[str] | None | Unset): Dataset IDs this filter applies to (default: all datasets)
        required (bool | Unset): Whether a value is required Default: False.
        default_value (DateRangeValue | None | Unset): Default date range
        min_date (None | str | Unset): Minimum selectable date
        max_date (None | str | Unset): Maximum selectable date
    """

    id: str
    column_name: str
    title: None | str | Unset = UNSET
    description: None | str | Unset = UNSET
    show_title: bool | None | Unset = True
    show_description: bool | None | Unset = True
    type_: Literal["daterange_filter"] | Unset = "daterange_filter"
    is_filter: bool | Unset = True
    dataset_ids: list[str] | None | Unset = UNSET
    required: bool | Unset = False
    default_value: DateRangeValue | None | Unset = UNSET
    min_date: None | str | Unset = UNSET
    max_date: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.date_range_value import DateRangeValue

        id = self.id

        column_name = self.column_name

        title: None | str | Unset
        if isinstance(self.title, Unset):
            title = UNSET
        else:
            title = self.title

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        show_title: bool | None | Unset
        if isinstance(self.show_title, Unset):
            show_title = UNSET
        else:
            show_title = self.show_title

        show_description: bool | None | Unset
        if isinstance(self.show_description, Unset):
            show_description = UNSET
        else:
            show_description = self.show_description

        type_ = self.type_

        is_filter = self.is_filter

        dataset_ids: list[str] | None | Unset
        if isinstance(self.dataset_ids, Unset):
            dataset_ids = UNSET
        elif isinstance(self.dataset_ids, list):
            dataset_ids = self.dataset_ids

        else:
            dataset_ids = self.dataset_ids

        required = self.required

        default_value: dict[str, Any] | None | Unset
        if isinstance(self.default_value, Unset):
            default_value = UNSET
        elif isinstance(self.default_value, DateRangeValue):
            default_value = self.default_value.to_dict()
        else:
            default_value = self.default_value

        min_date: None | str | Unset
        if isinstance(self.min_date, Unset):
            min_date = UNSET
        else:
            min_date = self.min_date

        max_date: None | str | Unset
        if isinstance(self.max_date, Unset):
            max_date = UNSET
        else:
            max_date = self.max_date

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "columnName": column_name,
            }
        )
        if title is not UNSET:
            field_dict["title"] = title
        if description is not UNSET:
            field_dict["description"] = description
        if show_title is not UNSET:
            field_dict["showTitle"] = show_title
        if show_description is not UNSET:
            field_dict["showDescription"] = show_description
        if type_ is not UNSET:
            field_dict["type"] = type_
        if is_filter is not UNSET:
            field_dict["isFilter"] = is_filter
        if dataset_ids is not UNSET:
            field_dict["datasetIds"] = dataset_ids
        if required is not UNSET:
            field_dict["required"] = required
        if default_value is not UNSET:
            field_dict["defaultValue"] = default_value
        if min_date is not UNSET:
            field_dict["minDate"] = min_date
        if max_date is not UNSET:
            field_dict["maxDate"] = max_date

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.date_range_value import DateRangeValue

        d = dict(src_dict)
        id = d.pop("id")

        column_name = d.pop("columnName")

        def _parse_title(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        title = _parse_title(d.pop("title", UNSET))

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        def _parse_show_title(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        show_title = _parse_show_title(d.pop("showTitle", UNSET))

        def _parse_show_description(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        show_description = _parse_show_description(d.pop("showDescription", UNSET))

        type_ = cast(Literal["daterange_filter"] | Unset, d.pop("type", UNSET))
        if type_ != "daterange_filter" and not isinstance(type_, Unset):
            raise ValueError(f"type must match const 'daterange_filter', got '{type_}'")

        is_filter = d.pop("isFilter", UNSET)

        def _parse_dataset_ids(data: object) -> list[str] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                dataset_ids_type_0 = cast(list[str], data)

                return dataset_ids_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[str] | None | Unset, data)

        dataset_ids = _parse_dataset_ids(d.pop("datasetIds", UNSET))

        required = d.pop("required", UNSET)

        def _parse_default_value(data: object) -> DateRangeValue | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                default_value_type_0 = DateRangeValue.from_dict(data)

                return default_value_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(DateRangeValue | None | Unset, data)

        default_value = _parse_default_value(d.pop("defaultValue", UNSET))

        def _parse_min_date(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        min_date = _parse_min_date(d.pop("minDate", UNSET))

        def _parse_max_date(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        max_date = _parse_max_date(d.pop("maxDate", UNSET))

        dashboard_date_range_filter_widget = cls(
            id=id,
            column_name=column_name,
            title=title,
            description=description,
            show_title=show_title,
            show_description=show_description,
            type_=type_,
            is_filter=is_filter,
            dataset_ids=dataset_ids,
            required=required,
            default_value=default_value,
            min_date=min_date,
            max_date=max_date,
        )

        dashboard_date_range_filter_widget.additional_properties = d
        return dashboard_date_range_filter_widget

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
