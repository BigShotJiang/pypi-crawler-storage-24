from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="TokenResponse")


@_attrs_define
class TokenResponse:
    """Response containing the issued JWT.

    Attributes:
        access_token (str): The JWT access token
        expires_in (int): Token lifetime in seconds
        expires_at (datetime.datetime): Token expiration timestamp
        dashboard_id (str): The dashboard ID this token grants access to
        user_id (str): The user ID who owns this share
        token_type (str | Unset):  Default: 'Bearer'.
    """

    access_token: str
    expires_in: int
    expires_at: datetime.datetime
    dashboard_id: str
    user_id: str
    token_type: str | Unset = "Bearer"
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        access_token = self.access_token

        expires_in = self.expires_in

        expires_at = self.expires_at.isoformat()

        dashboard_id = self.dashboard_id

        user_id = self.user_id

        token_type = self.token_type

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "accessToken": access_token,
                "expiresIn": expires_in,
                "expiresAt": expires_at,
                "dashboardId": dashboard_id,
                "userId": user_id,
            }
        )
        if token_type is not UNSET:
            field_dict["tokenType"] = token_type

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        access_token = d.pop("accessToken")

        expires_in = d.pop("expiresIn")

        expires_at = isoparse(d.pop("expiresAt"))

        dashboard_id = d.pop("dashboardId")

        user_id = d.pop("userId")

        token_type = d.pop("tokenType", UNSET)

        token_response = cls(
            access_token=access_token,
            expires_in=expires_in,
            expires_at=expires_at,
            dashboard_id=dashboard_id,
            user_id=user_id,
            token_type=token_type,
        )

        token_response.additional_properties = d
        return token_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
