from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, Literal, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.chart_config import ChartConfig


T = TypeVar("T", bound="DashboardChartWidget")


@_attrs_define
class DashboardChartWidget:
    """Chart widget definition.

    Attributes:
        id (str): Unique widget identifier
        title (None | str | Unset): Widget title
        description (None | str | Unset): Widget description
        show_title (bool | None | Unset): Whether to display the widget title Default: True.
        show_description (bool | None | Unset): Whether to display the widget description Default: True.
        type_ (Literal['chart'] | Unset):  Default: 'chart'.
        dataset_id (None | str | Unset): Dataset ID for the chart
        chart_config (ChartConfig | None | Unset): Chart configuration
        sql_query (None | str | Unset): Custom SQL query to execute against the datalake instead of a dataset
    """

    id: str
    title: None | str | Unset = UNSET
    description: None | str | Unset = UNSET
    show_title: bool | None | Unset = True
    show_description: bool | None | Unset = True
    type_: Literal["chart"] | Unset = "chart"
    dataset_id: None | str | Unset = UNSET
    chart_config: ChartConfig | None | Unset = UNSET
    sql_query: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.chart_config import ChartConfig

        id = self.id

        title: None | str | Unset
        if isinstance(self.title, Unset):
            title = UNSET
        else:
            title = self.title

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        show_title: bool | None | Unset
        if isinstance(self.show_title, Unset):
            show_title = UNSET
        else:
            show_title = self.show_title

        show_description: bool | None | Unset
        if isinstance(self.show_description, Unset):
            show_description = UNSET
        else:
            show_description = self.show_description

        type_ = self.type_

        dataset_id: None | str | Unset
        if isinstance(self.dataset_id, Unset):
            dataset_id = UNSET
        else:
            dataset_id = self.dataset_id

        chart_config: dict[str, Any] | None | Unset
        if isinstance(self.chart_config, Unset):
            chart_config = UNSET
        elif isinstance(self.chart_config, ChartConfig):
            chart_config = self.chart_config.to_dict()
        else:
            chart_config = self.chart_config

        sql_query: None | str | Unset
        if isinstance(self.sql_query, Unset):
            sql_query = UNSET
        else:
            sql_query = self.sql_query

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
            }
        )
        if title is not UNSET:
            field_dict["title"] = title
        if description is not UNSET:
            field_dict["description"] = description
        if show_title is not UNSET:
            field_dict["showTitle"] = show_title
        if show_description is not UNSET:
            field_dict["showDescription"] = show_description
        if type_ is not UNSET:
            field_dict["type"] = type_
        if dataset_id is not UNSET:
            field_dict["datasetId"] = dataset_id
        if chart_config is not UNSET:
            field_dict["chartConfig"] = chart_config
        if sql_query is not UNSET:
            field_dict["sqlQuery"] = sql_query

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.chart_config import ChartConfig

        d = dict(src_dict)
        id = d.pop("id")

        def _parse_title(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        title = _parse_title(d.pop("title", UNSET))

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        def _parse_show_title(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        show_title = _parse_show_title(d.pop("showTitle", UNSET))

        def _parse_show_description(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        show_description = _parse_show_description(d.pop("showDescription", UNSET))

        type_ = cast(Literal["chart"] | Unset, d.pop("type", UNSET))
        if type_ != "chart" and not isinstance(type_, Unset):
            raise ValueError(f"type must match const 'chart', got '{type_}'")

        def _parse_dataset_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        dataset_id = _parse_dataset_id(d.pop("datasetId", UNSET))

        def _parse_chart_config(data: object) -> ChartConfig | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                chart_config_type_0 = ChartConfig.from_dict(data)

                return chart_config_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(ChartConfig | None | Unset, data)

        chart_config = _parse_chart_config(d.pop("chartConfig", UNSET))

        def _parse_sql_query(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        sql_query = _parse_sql_query(d.pop("sqlQuery", UNSET))

        dashboard_chart_widget = cls(
            id=id,
            title=title,
            description=description,
            show_title=show_title,
            show_description=show_description,
            type_=type_,
            dataset_id=dataset_id,
            chart_config=chart_config,
            sql_query=sql_query,
        )

        dashboard_chart_widget.additional_properties = d
        return dashboard_chart_widget

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
