from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.task_scenario import TaskScenario
from ..types import UNSET, Unset

T = TypeVar("T", bound="CreateTaskRequest")


@_attrs_define
class CreateTaskRequest:
    """Payload for creating a new task.

    Attributes:
        name (str):
        project_id (str):
        scenario (TaskScenario):
        description (None | str | Unset):
        schedule_mode (None | str | Unset):  Default: 'MANUAL'.
        schedule_cron (None | str | Unset):
    """

    name: str
    project_id: str
    scenario: TaskScenario
    description: None | str | Unset = UNSET
    schedule_mode: None | str | Unset = "MANUAL"
    schedule_cron: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        name = self.name

        project_id = self.project_id

        scenario = self.scenario.value

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        schedule_mode: None | str | Unset
        if isinstance(self.schedule_mode, Unset):
            schedule_mode = UNSET
        else:
            schedule_mode = self.schedule_mode

        schedule_cron: None | str | Unset
        if isinstance(self.schedule_cron, Unset):
            schedule_cron = UNSET
        else:
            schedule_cron = self.schedule_cron

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "name": name,
                "projectId": project_id,
                "scenario": scenario,
            }
        )
        if description is not UNSET:
            field_dict["description"] = description
        if schedule_mode is not UNSET:
            field_dict["scheduleMode"] = schedule_mode
        if schedule_cron is not UNSET:
            field_dict["scheduleCron"] = schedule_cron

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        name = d.pop("name")

        project_id = d.pop("projectId")

        scenario = TaskScenario(d.pop("scenario"))

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        def _parse_schedule_mode(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        schedule_mode = _parse_schedule_mode(d.pop("scheduleMode", UNSET))

        def _parse_schedule_cron(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        schedule_cron = _parse_schedule_cron(d.pop("scheduleCron", UNSET))

        create_task_request = cls(
            name=name,
            project_id=project_id,
            scenario=scenario,
            description=description,
            schedule_mode=schedule_mode,
            schedule_cron=schedule_cron,
        )

        create_task_request.additional_properties = d
        return create_task_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
