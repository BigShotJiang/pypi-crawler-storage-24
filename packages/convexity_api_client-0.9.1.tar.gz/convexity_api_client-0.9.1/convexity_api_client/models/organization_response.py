from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.organization_role import OrganizationRole
from ..types import UNSET, Unset

T = TypeVar("T", bound="OrganizationResponse")


@_attrs_define
class OrganizationResponse:
    """Response model for an organization.

    Attributes:
        id (str):
        name (str):
        slug (str):
        created_at (datetime.datetime):
        updated_at (datetime.datetime):
        description (None | str | Unset):
        logo_url (None | str | Unset):
        member_count (int | None | Unset):
        project_count (int | None | Unset):
        current_user_role (None | OrganizationRole | Unset):
    """

    id: str
    name: str
    slug: str
    created_at: datetime.datetime
    updated_at: datetime.datetime
    description: None | str | Unset = UNSET
    logo_url: None | str | Unset = UNSET
    member_count: int | None | Unset = UNSET
    project_count: int | None | Unset = UNSET
    current_user_role: None | OrganizationRole | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = self.id

        name = self.name

        slug = self.slug

        created_at = self.created_at.isoformat()

        updated_at = self.updated_at.isoformat()

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        logo_url: None | str | Unset
        if isinstance(self.logo_url, Unset):
            logo_url = UNSET
        else:
            logo_url = self.logo_url

        member_count: int | None | Unset
        if isinstance(self.member_count, Unset):
            member_count = UNSET
        else:
            member_count = self.member_count

        project_count: int | None | Unset
        if isinstance(self.project_count, Unset):
            project_count = UNSET
        else:
            project_count = self.project_count

        current_user_role: None | str | Unset
        if isinstance(self.current_user_role, Unset):
            current_user_role = UNSET
        elif isinstance(self.current_user_role, OrganizationRole):
            current_user_role = self.current_user_role.value
        else:
            current_user_role = self.current_user_role

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "name": name,
                "slug": slug,
                "createdAt": created_at,
                "updatedAt": updated_at,
            }
        )
        if description is not UNSET:
            field_dict["description"] = description
        if logo_url is not UNSET:
            field_dict["logoUrl"] = logo_url
        if member_count is not UNSET:
            field_dict["memberCount"] = member_count
        if project_count is not UNSET:
            field_dict["projectCount"] = project_count
        if current_user_role is not UNSET:
            field_dict["currentUserRole"] = current_user_role

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = d.pop("id")

        name = d.pop("name")

        slug = d.pop("slug")

        created_at = isoparse(d.pop("createdAt"))

        updated_at = isoparse(d.pop("updatedAt"))

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        def _parse_logo_url(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        logo_url = _parse_logo_url(d.pop("logoUrl", UNSET))

        def _parse_member_count(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        member_count = _parse_member_count(d.pop("memberCount", UNSET))

        def _parse_project_count(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        project_count = _parse_project_count(d.pop("projectCount", UNSET))

        def _parse_current_user_role(data: object) -> None | OrganizationRole | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                current_user_role_type_0 = OrganizationRole(data)

                return current_user_role_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | OrganizationRole | Unset, data)

        current_user_role = _parse_current_user_role(d.pop("currentUserRole", UNSET))

        organization_response = cls(
            id=id,
            name=name,
            slug=slug,
            created_at=created_at,
            updated_at=updated_at,
            description=description,
            logo_url=logo_url,
            member_count=member_count,
            project_count=project_count,
            current_user_role=current_user_role,
        )

        organization_response.additional_properties = d
        return organization_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
