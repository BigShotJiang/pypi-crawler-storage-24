from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, Literal, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.table_chart_config_column_display_names_type_0 import TableChartConfigColumnDisplayNamesType0
    from ..models.table_chart_config_column_formats_type_0 import TableChartConfigColumnFormatsType0


T = TypeVar("T", bound="TableChartConfig")


@_attrs_define
class TableChartConfig:
    """Table chart configuration - displays query results as a plain table.

    Attributes:
        type_ (Literal['table'] | Unset):  Default: 'table'.
        page_size (int | None | Unset):
        show_row_numbers (bool | None | Unset):
        enable_pagination (bool | None | Unset):
        enable_sorting (bool | None | Unset):
        enable_filtering (bool | None | Unset):
        visible_columns (list[str] | None | Unset):
        column_display_names (None | TableChartConfigColumnDisplayNamesType0 | Unset):
        prettify_column_names (bool | None | Unset):
        column_formats (None | TableChartConfigColumnFormatsType0 | Unset):
    """

    type_: Literal["table"] | Unset = "table"
    page_size: int | None | Unset = UNSET
    show_row_numbers: bool | None | Unset = UNSET
    enable_pagination: bool | None | Unset = UNSET
    enable_sorting: bool | None | Unset = UNSET
    enable_filtering: bool | None | Unset = UNSET
    visible_columns: list[str] | None | Unset = UNSET
    column_display_names: None | TableChartConfigColumnDisplayNamesType0 | Unset = UNSET
    prettify_column_names: bool | None | Unset = UNSET
    column_formats: None | TableChartConfigColumnFormatsType0 | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.table_chart_config_column_display_names_type_0 import TableChartConfigColumnDisplayNamesType0
        from ..models.table_chart_config_column_formats_type_0 import TableChartConfigColumnFormatsType0

        type_ = self.type_

        page_size: int | None | Unset
        if isinstance(self.page_size, Unset):
            page_size = UNSET
        else:
            page_size = self.page_size

        show_row_numbers: bool | None | Unset
        if isinstance(self.show_row_numbers, Unset):
            show_row_numbers = UNSET
        else:
            show_row_numbers = self.show_row_numbers

        enable_pagination: bool | None | Unset
        if isinstance(self.enable_pagination, Unset):
            enable_pagination = UNSET
        else:
            enable_pagination = self.enable_pagination

        enable_sorting: bool | None | Unset
        if isinstance(self.enable_sorting, Unset):
            enable_sorting = UNSET
        else:
            enable_sorting = self.enable_sorting

        enable_filtering: bool | None | Unset
        if isinstance(self.enable_filtering, Unset):
            enable_filtering = UNSET
        else:
            enable_filtering = self.enable_filtering

        visible_columns: list[str] | None | Unset
        if isinstance(self.visible_columns, Unset):
            visible_columns = UNSET
        elif isinstance(self.visible_columns, list):
            visible_columns = self.visible_columns

        else:
            visible_columns = self.visible_columns

        column_display_names: dict[str, Any] | None | Unset
        if isinstance(self.column_display_names, Unset):
            column_display_names = UNSET
        elif isinstance(self.column_display_names, TableChartConfigColumnDisplayNamesType0):
            column_display_names = self.column_display_names.to_dict()
        else:
            column_display_names = self.column_display_names

        prettify_column_names: bool | None | Unset
        if isinstance(self.prettify_column_names, Unset):
            prettify_column_names = UNSET
        else:
            prettify_column_names = self.prettify_column_names

        column_formats: dict[str, Any] | None | Unset
        if isinstance(self.column_formats, Unset):
            column_formats = UNSET
        elif isinstance(self.column_formats, TableChartConfigColumnFormatsType0):
            column_formats = self.column_formats.to_dict()
        else:
            column_formats = self.column_formats

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if type_ is not UNSET:
            field_dict["type"] = type_
        if page_size is not UNSET:
            field_dict["pageSize"] = page_size
        if show_row_numbers is not UNSET:
            field_dict["showRowNumbers"] = show_row_numbers
        if enable_pagination is not UNSET:
            field_dict["enablePagination"] = enable_pagination
        if enable_sorting is not UNSET:
            field_dict["enableSorting"] = enable_sorting
        if enable_filtering is not UNSET:
            field_dict["enableFiltering"] = enable_filtering
        if visible_columns is not UNSET:
            field_dict["visibleColumns"] = visible_columns
        if column_display_names is not UNSET:
            field_dict["columnDisplayNames"] = column_display_names
        if prettify_column_names is not UNSET:
            field_dict["prettifyColumnNames"] = prettify_column_names
        if column_formats is not UNSET:
            field_dict["columnFormats"] = column_formats

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.table_chart_config_column_display_names_type_0 import TableChartConfigColumnDisplayNamesType0
        from ..models.table_chart_config_column_formats_type_0 import TableChartConfigColumnFormatsType0

        d = dict(src_dict)
        type_ = cast(Literal["table"] | Unset, d.pop("type", UNSET))
        if type_ != "table" and not isinstance(type_, Unset):
            raise ValueError(f"type must match const 'table', got '{type_}'")

        def _parse_page_size(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        page_size = _parse_page_size(d.pop("pageSize", UNSET))

        def _parse_show_row_numbers(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        show_row_numbers = _parse_show_row_numbers(d.pop("showRowNumbers", UNSET))

        def _parse_enable_pagination(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        enable_pagination = _parse_enable_pagination(d.pop("enablePagination", UNSET))

        def _parse_enable_sorting(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        enable_sorting = _parse_enable_sorting(d.pop("enableSorting", UNSET))

        def _parse_enable_filtering(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        enable_filtering = _parse_enable_filtering(d.pop("enableFiltering", UNSET))

        def _parse_visible_columns(data: object) -> list[str] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                visible_columns_type_0 = cast(list[str], data)

                return visible_columns_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[str] | None | Unset, data)

        visible_columns = _parse_visible_columns(d.pop("visibleColumns", UNSET))

        def _parse_column_display_names(data: object) -> None | TableChartConfigColumnDisplayNamesType0 | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                column_display_names_type_0 = TableChartConfigColumnDisplayNamesType0.from_dict(data)

                return column_display_names_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | TableChartConfigColumnDisplayNamesType0 | Unset, data)

        column_display_names = _parse_column_display_names(d.pop("columnDisplayNames", UNSET))

        def _parse_prettify_column_names(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        prettify_column_names = _parse_prettify_column_names(d.pop("prettifyColumnNames", UNSET))

        def _parse_column_formats(data: object) -> None | TableChartConfigColumnFormatsType0 | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                column_formats_type_0 = TableChartConfigColumnFormatsType0.from_dict(data)

                return column_formats_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | TableChartConfigColumnFormatsType0 | Unset, data)

        column_formats = _parse_column_formats(d.pop("columnFormats", UNSET))

        table_chart_config = cls(
            type_=type_,
            page_size=page_size,
            show_row_numbers=show_row_numbers,
            enable_pagination=enable_pagination,
            enable_sorting=enable_sorting,
            enable_filtering=enable_filtering,
            visible_columns=visible_columns,
            column_display_names=column_display_names,
            prettify_column_names=prettify_column_names,
            column_formats=column_formats,
        )

        table_chart_config.additional_properties = d
        return table_chart_config

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
