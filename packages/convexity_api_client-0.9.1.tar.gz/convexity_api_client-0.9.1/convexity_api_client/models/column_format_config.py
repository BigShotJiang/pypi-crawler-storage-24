from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.column_format_config_formattype import ColumnFormatConfigFormattype
from ..types import UNSET, Unset

T = TypeVar("T", bound="ColumnFormatConfig")


@_attrs_define
class ColumnFormatConfig:
    """Per-column value formatting configuration.

    Attributes:
        format_type (ColumnFormatConfigFormattype | Unset):  Default: ColumnFormatConfigFormattype.TEXT.
        decimal_places (int | None | Unset):
        currency_symbol (None | str | Unset):
        thousand_separator (bool | None | Unset):
    """

    format_type: ColumnFormatConfigFormattype | Unset = ColumnFormatConfigFormattype.TEXT
    decimal_places: int | None | Unset = UNSET
    currency_symbol: None | str | Unset = UNSET
    thousand_separator: bool | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        format_type: str | Unset = UNSET
        if not isinstance(self.format_type, Unset):
            format_type = self.format_type.value

        decimal_places: int | None | Unset
        if isinstance(self.decimal_places, Unset):
            decimal_places = UNSET
        else:
            decimal_places = self.decimal_places

        currency_symbol: None | str | Unset
        if isinstance(self.currency_symbol, Unset):
            currency_symbol = UNSET
        else:
            currency_symbol = self.currency_symbol

        thousand_separator: bool | None | Unset
        if isinstance(self.thousand_separator, Unset):
            thousand_separator = UNSET
        else:
            thousand_separator = self.thousand_separator

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if format_type is not UNSET:
            field_dict["formatType"] = format_type
        if decimal_places is not UNSET:
            field_dict["decimalPlaces"] = decimal_places
        if currency_symbol is not UNSET:
            field_dict["currencySymbol"] = currency_symbol
        if thousand_separator is not UNSET:
            field_dict["thousandSeparator"] = thousand_separator

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        _format_type = d.pop("formatType", UNSET)
        format_type: ColumnFormatConfigFormattype | Unset
        if isinstance(_format_type, Unset):
            format_type = UNSET
        else:
            format_type = ColumnFormatConfigFormattype(_format_type)

        def _parse_decimal_places(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        decimal_places = _parse_decimal_places(d.pop("decimalPlaces", UNSET))

        def _parse_currency_symbol(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        currency_symbol = _parse_currency_symbol(d.pop("currencySymbol", UNSET))

        def _parse_thousand_separator(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        thousand_separator = _parse_thousand_separator(d.pop("thousandSeparator", UNSET))

        column_format_config = cls(
            format_type=format_type,
            decimal_places=decimal_places,
            currency_symbol=currency_symbol,
            thousand_separator=thousand_separator,
        )

        column_format_config.additional_properties = d
        return column_format_config

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
