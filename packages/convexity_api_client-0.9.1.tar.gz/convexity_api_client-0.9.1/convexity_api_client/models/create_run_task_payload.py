from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.notebook_document import NotebookDocument


T = TypeVar("T", bound="CreateRunTaskPayload")


@_attrs_define
class CreateRunTaskPayload:
    """Minimal task payload required for run creation.

    Attributes:
        id (None | str | Unset):
        notebook (None | NotebookDocument | Unset):
    """

    id: None | str | Unset = UNSET
    notebook: None | NotebookDocument | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.notebook_document import NotebookDocument

        id: None | str | Unset
        if isinstance(self.id, Unset):
            id = UNSET
        else:
            id = self.id

        notebook: dict[str, Any] | None | Unset
        if isinstance(self.notebook, Unset):
            notebook = UNSET
        elif isinstance(self.notebook, NotebookDocument):
            notebook = self.notebook.to_dict()
        else:
            notebook = self.notebook

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if id is not UNSET:
            field_dict["id"] = id
        if notebook is not UNSET:
            field_dict["notebook"] = notebook

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.notebook_document import NotebookDocument

        d = dict(src_dict)

        def _parse_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        id = _parse_id(d.pop("id", UNSET))

        def _parse_notebook(data: object) -> None | NotebookDocument | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                notebook_type_0 = NotebookDocument.from_dict(data)

                return notebook_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | NotebookDocument | Unset, data)

        notebook = _parse_notebook(d.pop("notebook", UNSET))

        create_run_task_payload = cls(
            id=id,
            notebook=notebook,
        )

        create_run_task_payload.additional_properties = d
        return create_run_task_payload

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
