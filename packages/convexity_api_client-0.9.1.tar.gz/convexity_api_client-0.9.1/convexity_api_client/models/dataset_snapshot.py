from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.dataset import Dataset


T = TypeVar("T", bound="DatasetSnapshot")


@_attrs_define
class DatasetSnapshot:
    """Represents a DatasetSnapshot record

    Attributes:
        id (str):
        dataset_id (str):
        version (int):
        columns (str):
        row_count (int):
        data_blob (str):
        created_at (datetime.datetime):
        execution_ms (int | None | Unset):
        error (None | str | Unset):
        dataset (Dataset | None | Unset):
    """

    id: str
    dataset_id: str
    version: int
    columns: str
    row_count: int
    data_blob: str
    created_at: datetime.datetime
    execution_ms: int | None | Unset = UNSET
    error: None | str | Unset = UNSET
    dataset: Dataset | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.dataset import Dataset

        id = self.id

        dataset_id = self.dataset_id

        version = self.version

        columns = self.columns

        row_count = self.row_count

        data_blob = self.data_blob

        created_at = self.created_at.isoformat()

        execution_ms: int | None | Unset
        if isinstance(self.execution_ms, Unset):
            execution_ms = UNSET
        else:
            execution_ms = self.execution_ms

        error: None | str | Unset
        if isinstance(self.error, Unset):
            error = UNSET
        else:
            error = self.error

        dataset: dict[str, Any] | None | Unset
        if isinstance(self.dataset, Unset):
            dataset = UNSET
        elif isinstance(self.dataset, Dataset):
            dataset = self.dataset.to_dict()
        else:
            dataset = self.dataset

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "dataset_id": dataset_id,
                "version": version,
                "columns": columns,
                "row_count": row_count,
                "data_blob": data_blob,
                "created_at": created_at,
            }
        )
        if execution_ms is not UNSET:
            field_dict["execution_ms"] = execution_ms
        if error is not UNSET:
            field_dict["error"] = error
        if dataset is not UNSET:
            field_dict["dataset"] = dataset

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.dataset import Dataset

        d = dict(src_dict)
        id = d.pop("id")

        dataset_id = d.pop("dataset_id")

        version = d.pop("version")

        columns = d.pop("columns")

        row_count = d.pop("row_count")

        data_blob = d.pop("data_blob")

        created_at = isoparse(d.pop("created_at"))

        def _parse_execution_ms(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        execution_ms = _parse_execution_ms(d.pop("execution_ms", UNSET))

        def _parse_error(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        error = _parse_error(d.pop("error", UNSET))

        def _parse_dataset(data: object) -> Dataset | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                dataset_type_0 = Dataset.from_dict(data)

                return dataset_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(Dataset | None | Unset, data)

        dataset = _parse_dataset(d.pop("dataset", UNSET))

        dataset_snapshot = cls(
            id=id,
            dataset_id=dataset_id,
            version=version,
            columns=columns,
            row_count=row_count,
            data_blob=data_blob,
            created_at=created_at,
            execution_ms=execution_ms,
            error=error,
            dataset=dataset,
        )

        dataset_snapshot.additional_properties = d
        return dataset_snapshot

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
