from enum import Enum


class AreaChartConfigLegendOrientationType0(str, Enum):
    HORIZONTAL = "horizontal"
    VERTICAL = "vertical"

    def __str__(self) -> str:
        return str(self.value)
