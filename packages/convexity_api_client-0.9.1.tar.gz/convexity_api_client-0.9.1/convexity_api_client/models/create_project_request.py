from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="CreateProjectRequest")


@_attrs_define
class CreateProjectRequest:
    """Request to create a new project.

    Attributes:
        name (str): Project name
        slug (str): URL-friendly slug
        organization_id (str): ID of the organization
        description (None | str | Unset): Project description
        general_system_prompt (None | str | Unset): Custom system prompt for General chat mode
    """

    name: str
    slug: str
    organization_id: str
    description: None | str | Unset = UNSET
    general_system_prompt: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        name = self.name

        slug = self.slug

        organization_id = self.organization_id

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        general_system_prompt: None | str | Unset
        if isinstance(self.general_system_prompt, Unset):
            general_system_prompt = UNSET
        else:
            general_system_prompt = self.general_system_prompt

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "name": name,
                "slug": slug,
                "organizationId": organization_id,
            }
        )
        if description is not UNSET:
            field_dict["description"] = description
        if general_system_prompt is not UNSET:
            field_dict["generalSystemPrompt"] = general_system_prompt

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        name = d.pop("name")

        slug = d.pop("slug")

        organization_id = d.pop("organizationId")

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        def _parse_general_system_prompt(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        general_system_prompt = _parse_general_system_prompt(d.pop("generalSystemPrompt", UNSET))

        create_project_request = cls(
            name=name,
            slug=slug,
            organization_id=organization_id,
            description=description,
            general_system_prompt=general_system_prompt,
        )

        create_project_request.additional_properties = d
        return create_project_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
