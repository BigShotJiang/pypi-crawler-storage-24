from enum import Enum


class ColumnFormatConfigFormattype(str, Enum):
    CURRENCY = "currency"
    NUMBER = "number"
    PERCENT = "percent"
    TEXT = "text"

    def __str__(self) -> str:
        return str(self.value)
