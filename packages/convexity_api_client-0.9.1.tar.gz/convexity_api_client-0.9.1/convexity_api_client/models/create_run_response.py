from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.run import Run


T = TypeVar("T", bound="CreateRunResponse")


@_attrs_define
class CreateRunResponse:
    """Response model for creating a run.

    Attributes:
        success (bool):
        run_id (str):
        message (str):
        run (Run): Represents a Run record
    """

    success: bool
    run_id: str
    message: str
    run: Run
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        success = self.success

        run_id = self.run_id

        message = self.message

        run = self.run.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "success": success,
                "run_id": run_id,
                "message": message,
                "run": run,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.run import Run

        d = dict(src_dict)
        success = d.pop("success")

        run_id = d.pop("run_id")

        message = d.pop("message")

        run = Run.from_dict(d.pop("run"))

        create_run_response = cls(
            success=success,
            run_id=run_id,
            message=message,
            run=run,
        )

        create_run_response.additional_properties = d
        return create_run_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
