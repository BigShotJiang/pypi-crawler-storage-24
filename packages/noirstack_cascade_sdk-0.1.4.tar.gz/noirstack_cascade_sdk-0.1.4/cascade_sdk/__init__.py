"""
Cascade SDK - Python client for Cascade workflow orchestration.

Provides:
- @task and @flow decorators for workflow definition
- DAG compilation from decorated functions
- HTTP client for flow registration and execution
- Polling utilities for run completion

Quick Start:
    from cascade_sdk import task, flow, CascadeClient
    
    @task
    def add(a: int, b: int) -> int:
        return a + b
    
    @flow
    def math_workflow(a: int, b: int) -> int:
        return add(a, b)
    
    # Compile flow to DAG
    from cascade_sdk.compiler import build_dag_from_flow
    dag = build_dag_from_flow(math_workflow)
    
    # Register and execute
    client = CascadeClient(
        base_url="http://localhost:3000",
        api_key="your_api_key"
    )
    flow_id = client.register_flow("math_workflow", dag)
    run_id = client.trigger_flow(flow_id, {"a": 10, "b": 20})
    
    # Wait for completion
    from cascade_sdk.client import wait_for_completion
    result = wait_for_completion(client, run_id)
    print(result['result'])  # 30
"""

__version__ = "0.1.2"

# Compiler exports
from .compiler import (
    task,
    flow,
    build_dag_from_flow,
    build_dag_from_flow_json,
    canonical_json,
    canonicalize_dag,
    bpmn_xml_to_dag,
    airflow_dag_to_dag,
    flyte_workflow_to_dag,
    mlrun_pipeline_to_dag,
    metaflow_to_dag,
    nifi_flow_to_dag,
    shipyard_blueprint_to_dag,
    mage_pipeline_to_dag,
    argo_workflow_to_dag,
    kestra_flow_to_dag,
    luigi_pipeline_to_dag,
    dagster_job_to_dag,
)

# Client exports
from .client import (
    CascadeClient,
    CascadeSDKError,
    AuthenticationError,
    ValidationError,
    NotFoundError,
    RateLimitError,
    OrchestrationError,
    NetworkError,
    TimeoutError,
    wait_for_completion,
    wait_for_completion_async,
)

# Standards exports
from .standards import (
    build_cloudevent,
    cloudevent_json,
    prov_agent,
    prov_entity,
    prov_activity,
    build_prov_bundle,
    build_trace_context_headers,
    validate_cloudevent,
    validate_dag,
)

__all__ = [
    # Version
    '__version__',
    
    # Decorators
    'task',
    'flow',
    
    # Compiler
    'build_dag_from_flow',
    'build_dag_from_flow_json',
    'canonical_json',
    'canonicalize_dag',
    'bpmn_xml_to_dag',
    'airflow_dag_to_dag',
    'flyte_workflow_to_dag',
    'mlrun_pipeline_to_dag',
    'metaflow_to_dag',
    'nifi_flow_to_dag',
    'shipyard_blueprint_to_dag',
    'mage_pipeline_to_dag',
    'argo_workflow_to_dag',
    'kestra_flow_to_dag',
    'luigi_pipeline_to_dag',
    'dagster_job_to_dag',
    
    # Client
    'CascadeClient',
    'wait_for_completion',
    'wait_for_completion_async',

    # Standards
    'build_cloudevent',
    'cloudevent_json',
    'prov_agent',
    'prov_entity',
    'prov_activity',
    'build_prov_bundle',
    'build_trace_context_headers',
    'validate_cloudevent',
    'validate_dag',
    
    # Errors
    'CascadeSDKError',
    'AuthenticationError',
    'ValidationError',
    'NotFoundError',
    'RateLimitError',
    'OrchestrationError',
    'NetworkError',
    'TimeoutError',
]
