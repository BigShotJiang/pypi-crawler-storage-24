"""OpenTelemetry trace context helpers.

OpenTelemetry reference: https://opentelemetry.io
"""

from typing import Dict, Optional


def build_trace_context_headers(
    traceparent: Optional[str] = None,
    tracestate: Optional[str] = None,
) -> Dict[str, str]:
    """Build W3C trace context headers.

    If headers are not supplied, attempts to derive them from the current
    OpenTelemetry span context when ``opentelemetry-api`` is installed.
    """
    headers: Dict[str, str] = {}

    if traceparent:
        headers["traceparent"] = traceparent
        if tracestate:
            headers["tracestate"] = tracestate
        return headers

    try:
        from opentelemetry import trace  # type: ignore

        span_ctx = trace.get_current_span().get_span_context()
        if not getattr(span_ctx, "is_valid", False):
            return headers

        version = "00"
        trace_id = format(span_ctx.trace_id, "032x")
        span_id = format(span_ctx.span_id, "016x")
        sampled = "01" if (span_ctx.trace_flags.sampled) else "00"
        headers["traceparent"] = f"{version}-{trace_id}-{span_id}-{sampled}"

        if getattr(span_ctx, "trace_state", None):
            ts = str(span_ctx.trace_state)
            if ts:
                headers["tracestate"] = ts

        return headers
    except Exception:
        return headers
