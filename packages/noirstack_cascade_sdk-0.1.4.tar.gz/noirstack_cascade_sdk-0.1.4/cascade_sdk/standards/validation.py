"""Schema and contract validation helpers for standards artifacts."""

from datetime import datetime
from pathlib import Path
from typing import Any, Dict
import json


def validate_cloudevent(event: Dict[str, Any]) -> None:
    """Validate CloudEvent envelope against contract.

    Uses jsonschema when available, then enforces required keys fallback.
    Raises ValueError with validation context on failure.
    """
    schema = _load_schema("workflow.cloudevent.schema.json")
    _validate_with_optional_jsonschema(event, schema)

    required = ["specversion", "id", "type", "source", "time"]
    for key in required:
        if key not in event:
            raise ValueError(f"CloudEvent missing required field: {key}")

    if event.get("specversion") != "1.0":
        raise ValueError("CloudEvent specversion must be '1.0'")

    if not str(event.get("type", "")).startswith("cascade."):
        raise ValueError("CloudEvent type must start with 'cascade.'")

    # Basic timestamp sanity; strict RFC checks are delegated to jsonschema format checks.
    try:
        datetime.fromisoformat(str(event["time"]).replace("Z", "+00:00"))
    except Exception as exc:
        raise ValueError("CloudEvent time must be an ISO date-time string") from exc


def validate_dag(dag: Dict[str, Any]) -> None:
    """Validate Cascade DAG shape used by registration APIs."""
    if not isinstance(dag, dict):
        raise ValueError("dag must be an object")

    nodes = dag.get("nodes")
    if not isinstance(nodes, list) or not nodes:
        raise ValueError("dag.nodes must be a non-empty list")

    edges = dag.get("edges")
    if not isinstance(edges, list):
        raise ValueError("dag.edges must be a list")

    return_node = dag.get("return_node")
    if not isinstance(return_node, str) or not return_node:
        raise ValueError("dag.return_node is required")

    node_ids = set()
    for node in nodes:
        if not isinstance(node, dict):
            raise ValueError("dag node must be an object")
        nid = node.get("id")
        tname = node.get("task_name")
        deps = node.get("dependencies", [])

        if not isinstance(nid, str) or not nid:
            raise ValueError("each node requires non-empty id")
        if nid in node_ids:
            raise ValueError(f"duplicate node id: {nid}")
        node_ids.add(nid)

        if not isinstance(tname, str) or not tname:
            raise ValueError(f"node {nid} requires task_name")
        if not isinstance(deps, list):
            raise ValueError(f"node {nid} dependencies must be a list")

    if return_node not in node_ids:
        raise ValueError("return_node must reference an existing node id")

    for edge in edges:
        if not isinstance(edge, dict):
            raise ValueError("edge must be an object")
        src = edge.get("from")
        dst = edge.get("to")
        if src not in node_ids or dst not in node_ids:
            raise ValueError("edge references unknown node id")


def _load_schema(filename: str) -> Dict[str, Any]:
    repo_root = Path(__file__).resolve().parents[2]
    schema_path = repo_root / "contracts" / filename
    with schema_path.open("r", encoding="utf-8") as fh:
        return json.load(fh)


def _validate_with_optional_jsonschema(instance: Dict[str, Any], schema: Dict[str, Any]) -> None:
    try:
        from jsonschema import Draft202012Validator  # type: ignore

        validator = Draft202012Validator(schema)
        errors = sorted(validator.iter_errors(instance), key=lambda e: e.path)
        if errors:
            msg = "; ".join(err.message for err in errors)
            raise ValueError(f"Schema validation failed: {msg}")
    except ImportError:
        # Optional dependency not installed; fallback checks happen in caller.
        return
