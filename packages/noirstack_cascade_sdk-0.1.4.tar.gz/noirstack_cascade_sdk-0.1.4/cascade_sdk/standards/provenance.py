"""W3C PROV (PROV-JSON) helpers for provenance tracking.

W3C PROV reference: https://www.w3.org/TR/prov-overview/
"""

from datetime import datetime, timezone
from typing import Any, Dict, Iterable, Optional


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def prov_agent(agent_id: str, attrs: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Create a PROV agent node."""
    if not agent_id:
        raise ValueError("agent_id is required")
    return {agent_id: attrs or {}}


def prov_entity(entity_id: str, attrs: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Create a PROV entity node."""
    if not entity_id:
        raise ValueError("entity_id is required")
    return {entity_id: attrs or {}}


def prov_activity(
    activity_id: str,
    started_at: Optional[str] = None,
    ended_at: Optional[str] = None,
    attrs: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Create a PROV activity node."""
    if not activity_id:
        raise ValueError("activity_id is required")

    node = dict(attrs or {})
    node.setdefault("prov:startTime", started_at or _now_iso())
    if ended_at:
        node["prov:endTime"] = ended_at
    return {activity_id: node}


def build_prov_bundle(
    entities: Optional[Iterable[Dict[str, Any]]] = None,
    activities: Optional[Iterable[Dict[str, Any]]] = None,
    agents: Optional[Iterable[Dict[str, Any]]] = None,
    was_generated_by: Optional[Dict[str, Dict[str, str]]] = None,
    was_associated_with: Optional[Dict[str, Dict[str, str]]] = None,
    was_derived_from: Optional[Dict[str, Dict[str, str]]] = None,
) -> Dict[str, Any]:
    """Build a minimal PROV-JSON document."""
    doc: Dict[str, Any] = {
        "prefix": {"prov": "http://www.w3.org/ns/prov#"},
        "entity": {},
        "activity": {},
        "agent": {},
        "wasGeneratedBy": was_generated_by or {},
        "wasAssociatedWith": was_associated_with or {},
        "wasDerivedFrom": was_derived_from or {},
    }

    for item in entities or []:
        doc["entity"].update(item)
    for item in activities or []:
        doc["activity"].update(item)
    for item in agents or []:
        doc["agent"].update(item)

    return doc
