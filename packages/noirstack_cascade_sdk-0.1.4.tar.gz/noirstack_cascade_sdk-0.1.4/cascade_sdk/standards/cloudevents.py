"""CloudEvents helpers for workflow and orchestration events.

CNCF CloudEvents reference: https://cloudevents.io
"""

from datetime import datetime, timezone
import json
import uuid
from typing import Any, Dict, Optional


def build_cloudevent(
    event_type: str,
    source: str,
    data: Optional[Any] = None,
    subject: Optional[str] = None,
    event_id: Optional[str] = None,
    event_time: Optional[str] = None,
    extensions: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Build a CloudEvents 1.0 event envelope.

    Args:
        event_type: Event type, e.g. ``cascade.flow.run.started``.
        source: Producer identifier, often a URI-like value.
        data: Event payload object.
        subject: Optional event subject.
        event_id: Optional unique id. Generated when omitted.
        event_time: Optional RFC3339 timestamp. Generated when omitted.
        extensions: Optional CloudEvents extension attributes.
    """
    if not event_type:
        raise ValueError("event_type is required")
    if not source:
        raise ValueError("source is required")

    event = {
        "specversion": "1.0",
        "id": event_id or str(uuid.uuid4()),
        "type": event_type,
        "source": source,
        "time": event_time or datetime.now(timezone.utc).isoformat(),
    }

    if subject:
        event["subject"] = subject
    if data is not None:
        event["data"] = data
    if extensions:
        event.update(extensions)

    return event


def cloudevent_json(event: Dict[str, Any]) -> str:
    """Serialize a CloudEvent with deterministic key ordering."""
    return json.dumps(event, sort_keys=True, separators=(",", ":"))
