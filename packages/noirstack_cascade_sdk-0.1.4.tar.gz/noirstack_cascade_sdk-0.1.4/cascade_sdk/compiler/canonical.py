"""Deterministic JSON serialization for DAG definitions."""

import json
from typing import Any, Dict, List

def canonical_json(obj: Any) -> str:
    """
    Serialize object to canonical JSON string.
    
    Ensures deterministic output by:
    - Sorting all dictionary keys
    - No extra whitespace
    - Consistent encoding
    
    Args:
        obj: Python object to serialize
    
    Returns:
        Canonical JSON string
    """
    normalized = _normalize(obj)
    return json.dumps(normalized, sort_keys=True, separators=(',', ':'))


def canonicalize_dag(dag: Dict[str, Any]) -> Dict[str, Any]:
    """
    Normalize DAG structure for deterministic comparison.
    
    - Sorts nodes by ID
    - Sorts edges by from/to
    - Sorts all object keys
    - Normalizes nested structures
    
    Args:
        dag: DAG definition dictionary
    
    Returns:
        Canonicalized DAG dictionary
    """
    normalized_dag = {}
    
    # Copy top-level fields in sorted order
    for key in sorted(dag.keys()):
        normalized_dag[key] = _normalize(dag[key])
    
    return normalized_dag


def _normalize(obj: Any) -> Any:
    """
    Recursively normalize Python objects for canonical serialization.
    
    - Lists: preserve order (no sorting)
    - Dicts: sort keys alphabetically
    - Primitives: return as-is
    """
    if isinstance(obj, dict):
        # Sort dictionary keys
        return {key: _normalize(obj[key]) for key in sorted(obj.keys())}
    elif isinstance(obj, list):
        # Preserve list order, but normalize elements
        return [_normalize(item) for item in obj]
    elif isinstance(obj, (str, int, float, bool, type(None))):
        # Primitives: return as-is
        return obj
    else:
        # Fallback: convert to string
        return str(obj)
