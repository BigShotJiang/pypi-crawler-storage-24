"""DAG builder - Extract DAG from @flow functions."""

from typing import Any, Callable, Dict, List
from .context import FlowContext
from .decorators import _TaskPlaceholder
from .canonical import canonical_json

def build_dag_from_flow(flow_func: Callable) -> Dict[str, Any]:
    """
    Build DAG from a @flow decorated function.
    
    Executes the flow in capture mode, intercepting task calls
    to construct the DAG structure.
    
    Args:
        flow_func: Flow function decorated with @flow
    
    Returns:
        DAG definition dictionary with nodes and edges
    
    Raises:
        ValueError: If flow_func is not a @flow decorated function
    
    Example:
        @flow
        def my_flow(a: int, b: int):
            x = add(a, b)
            return multiply(x, 2)
        
        dag = build_dag_from_flow(my_flow)
        # dag = {'nodes': [...], 'edges': [...], 'return_node_id': '...'}
    """
    # Validate that this is a flow
    if not getattr(flow_func, '_is_flow', False):
        raise ValueError(f"{flow_func.__name__} is not decorated with @flow")
    
    # Create capture context
    context = FlowContext()
    
    # Execute flow in capture mode
    with context:
        # Call flow with placeholder arguments
        # (actual values don't matter during compilation)
        try:
            result = flow_func()
        except TypeError:
            # Flow requires arguments - call with None placeholders
            import inspect
            sig = inspect.signature(flow_func)
            num_params = len(sig.parameters)
            result = flow_func(*([None] * num_params))
        
        # Track return node
        if isinstance(result, _TaskPlaceholder):
            context.set_return_node(result.node_id)
    
    # Build DAG from captured context
    dag = {
        'nodes': context.nodes,
        'edges': context.edges,
    }

    if context.return_node_id:
        dag['return_node'] = context.return_node_id

    # Provide a default entrypoint for graph tooling compatibility.
    if context.nodes:
        dag['entrypoints'] = {'default': {'node': context.nodes[0]['id']}}
    
    return dag


def build_dag_from_flow_json(flow_func: Callable) -> str:
    """
    Build DAG from flow and return as canonical JSON string.
    
    Args:
        flow_func: Flow function decorated with @flow
    
    Returns:
        Canonical JSON string representation of DAG
    """
    dag = build_dag_from_flow(flow_func)
    return canonical_json(dag)
