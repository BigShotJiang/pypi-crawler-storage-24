"""Apache Airflow DAG to Cascade DAG adapter.

This adapter allows teams to reuse existing Airflow DAG topology while
migrating orchestration execution to Cascade.
"""

from typing import Any, Dict, List, Optional


def airflow_dag_to_dag(airflow_dag: Any) -> Dict[str, Any]:
    """Convert an Airflow DAG-like object into Cascade DAG format.

    Expected Airflow-like shape:
    - ``airflow_dag.tasks`` iterable with task objects
    - each task has ``task_id`` and optional ``upstream_task_ids`` set/list

    Args:
        airflow_dag: Airflow DAG instance or DAG-like object.

    Returns:
        Dict containing ``nodes``, ``edges``, ``entrypoints``, and ``return_node``.
    """
    tasks = list(getattr(airflow_dag, "tasks", []) or [])
    if not tasks:
        raise ValueError("airflow_dag.tasks is required and must be non-empty")

    task_ids = [getattr(t, "task_id", None) for t in tasks]
    if not all(task_ids):
        raise ValueError("All Airflow tasks must define task_id")

    task_ids = [str(tid) for tid in task_ids]
    task_to_node: Dict[str, str] = {tid: f"node-{idx}" for idx, tid in enumerate(task_ids)}

    nodes: List[Dict[str, Any]] = []
    edges: List[Dict[str, str]] = []

    for task in tasks:
        tid = str(task.task_id)
        upstream_ids = sorted(str(u) for u in (getattr(task, "upstream_task_ids", set()) or set()))
        dependencies = [task_to_node[u] for u in upstream_ids if u in task_to_node]

        nodes.append(
            {
                "id": task_to_node[tid],
                "task_name": _normalize_task_name(tid),
                "dependencies": dependencies,
            }
        )

        for upstream in dependencies:
            edge = {"from": upstream, "to": task_to_node[tid]}
            if edge not in edges:
                edges.append(edge)

    entry_node = _first_no_dependency(nodes) or nodes[0]["id"]
    return_node = _sink_node(nodes, edges) or nodes[-1]["id"]

    return {
        "nodes": nodes,
        "edges": edges,
        "entrypoints": {"default": {"node": entry_node}},
        "return_node": return_node,
    }


def _first_no_dependency(nodes: List[Dict[str, Any]]) -> Optional[str]:
    for node in nodes:
        if not node.get("dependencies"):
            return node["id"]
    return None


def _sink_node(nodes: List[Dict[str, Any]], edges: List[Dict[str, str]]) -> Optional[str]:
    has_outgoing = {e["from"] for e in edges}
    for node in nodes:
        if node["id"] not in has_outgoing:
            return node["id"]
    return None


def _normalize_task_name(name: str) -> str:
    lowered = name.strip().lower()
    chars = []
    prev_us = False
    for ch in lowered:
        if ch.isalnum():
            chars.append(ch)
            prev_us = False
        else:
            if not prev_us:
                chars.append("_")
                prev_us = True
    normalized = "".join(chars).strip("_")
    return normalized or "task"
