"""BPMN 2.0 XML to Cascade DAG mapper.

This is a practical subset mapper for orchestration workflows.
Supported BPMN elements include task-like nodes, sequence flows,
start events and end events.
"""

from typing import Any, Dict, List, Optional
import xml.etree.ElementTree as ET


_TASK_TAGS = {
    "task",
    "serviceTask",
    "scriptTask",
    "businessRuleTask",
    "manualTask",
    "userTask",
    "callActivity",
}


def bpmn_xml_to_dag(xml_text: str, process_id: Optional[str] = None) -> Dict[str, Any]:
    """Convert BPMN 2.0 XML into Cascade DAG format.

    Args:
        xml_text: BPMN XML document.
        process_id: Optional process ID when multiple processes exist.

    Returns:
        Dict containing ``nodes``, ``edges``, ``entrypoints``, and ``return_node``.
    """
    if not xml_text or not xml_text.strip():
        raise ValueError("xml_text is required")

    root = ET.fromstring(xml_text)
    process = _select_process(root, process_id)
    if process is None:
        raise ValueError("No BPMN process found")

    task_elements = [
        el for el in list(process)
        if _local(el.tag) in _TASK_TAGS
    ]
    if not task_elements:
        raise ValueError("No task-like BPMN elements found")

    bpmn_task_ids = [el.attrib.get("id") for el in task_elements if el.attrib.get("id")]
    if not bpmn_task_ids:
        raise ValueError("Task-like BPMN elements require id attributes")

    task_id_to_node: Dict[str, str] = {
        task_id: f"node-{idx}" for idx, task_id in enumerate(bpmn_task_ids)
    }

    task_name_map: Dict[str, str] = {}
    for el in task_elements:
        tid = el.attrib.get("id")
        if not tid:
            continue
        name = (el.attrib.get("name") or tid).strip()
        task_name_map[tid] = _normalize_task_name(name)

    sequence_flows = [el for el in list(process) if _local(el.tag) == "sequenceFlow"]

    upstream: Dict[str, List[str]] = {tid: [] for tid in bpmn_task_ids}
    edges: List[Dict[str, str]] = []

    for flow in sequence_flows:
        src = flow.attrib.get("sourceRef")
        dst = flow.attrib.get("targetRef")
        if not src or not dst:
            continue
        if src in task_id_to_node and dst in task_id_to_node:
            from_node = task_id_to_node[src]
            to_node = task_id_to_node[dst]
            upstream[dst].append(from_node)
            edge = {"from": from_node, "to": to_node}
            if edge not in edges:
                edges.append(edge)

    nodes: List[Dict[str, Any]] = []
    for tid in bpmn_task_ids:
        nodes.append(
            {
                "id": task_id_to_node[tid],
                "task_name": task_name_map[tid],
                "dependencies": sorted(set(upstream[tid])),
            }
        )

    entry_node = _find_entry_node(process, sequence_flows, task_id_to_node, nodes)
    return_node = _find_return_node(process, sequence_flows, task_id_to_node, nodes)

    return {
        "nodes": nodes,
        "edges": edges,
        "entrypoints": {"default": {"node": entry_node}},
        "return_node": return_node,
    }


def _select_process(root: ET.Element, process_id: Optional[str]) -> Optional[ET.Element]:
    processes = [el for el in root.iter() if _local(el.tag) == "process"]
    if not processes:
        return None
    if process_id is None:
        return processes[0]
    for p in processes:
        if p.attrib.get("id") == process_id:
            return p
    raise ValueError(f"Process '{process_id}' not found")


def _find_entry_node(
    process: ET.Element,
    sequence_flows: List[ET.Element],
    task_id_to_node: Dict[str, str],
    nodes: List[Dict[str, Any]],
) -> str:
    starts = [el.attrib.get("id") for el in list(process) if _local(el.tag) == "startEvent"]
    for s in starts:
        if not s:
            continue
        for flow in sequence_flows:
            if flow.attrib.get("sourceRef") == s:
                target = flow.attrib.get("targetRef")
                if target in task_id_to_node:
                    return task_id_to_node[target]

    # Fallback: first node with no dependencies.
    for node in nodes:
        if not node["dependencies"]:
            return node["id"]

    return nodes[0]["id"]


def _find_return_node(
    process: ET.Element,
    sequence_flows: List[ET.Element],
    task_id_to_node: Dict[str, str],
    nodes: List[Dict[str, Any]],
) -> str:
    ends = [el.attrib.get("id") for el in list(process) if _local(el.tag) == "endEvent"]
    for e in ends:
        if not e:
            continue
        for flow in sequence_flows:
            if flow.attrib.get("targetRef") == e:
                source = flow.attrib.get("sourceRef")
                if source in task_id_to_node:
                    return task_id_to_node[source]

    # Fallback: node that is not a source of any edge target (sink node).
    source_nodes = {edge["from"] for edge in [
        {"from": task_id_to_node.get(flow.attrib.get("sourceRef", ""), ""), "to": task_id_to_node.get(flow.attrib.get("targetRef", ""), "")}
        for flow in sequence_flows
        if flow.attrib.get("sourceRef") in task_id_to_node and flow.attrib.get("targetRef") in task_id_to_node
    ] if edge["from"]}

    sink_candidates = [n["id"] for n in nodes if n["id"] not in source_nodes]
    if sink_candidates:
        return sink_candidates[0]

    return nodes[-1]["id"]


def _local(tag: str) -> str:
    return tag.rsplit("}", 1)[-1]


def _normalize_task_name(name: str) -> str:
    lowered = name.strip().lower()
    chars = []
    prev_us = False
    for ch in lowered:
        if ch.isalnum():
            chars.append(ch)
            prev_us = False
        else:
            if not prev_us:
                chars.append("_")
                prev_us = True
    normalized = "".join(chars).strip("_")
    return normalized or "task"
