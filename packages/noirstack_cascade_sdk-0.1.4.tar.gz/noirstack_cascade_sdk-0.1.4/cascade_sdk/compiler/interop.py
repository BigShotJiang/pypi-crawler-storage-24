"""Multi-orchestrator adapters to Cascade DAG format.

Adapters are intentionally lightweight and dictionary-based so teams can
reuse topology from existing orchestrators without forcing heavy runtime deps.
"""

from typing import Any, Dict, Iterable, List, Optional


def flyte_workflow_to_dag(workflow: Dict[str, Any]) -> Dict[str, Any]:
    nodes = workflow.get("nodes", [])
    return _from_node_records(nodes, id_key="id", name_key="name", deps_key="upstream")


def mlrun_pipeline_to_dag(pipeline: Dict[str, Any]) -> Dict[str, Any]:
    steps = pipeline.get("steps", [])
    return _from_node_records(steps, id_key="name", name_key="name", deps_key="depends_on")


def metaflow_to_dag(flow: Dict[str, Any]) -> Dict[str, Any]:
    steps = flow.get("steps", [])
    return _from_node_records(steps, id_key="name", name_key="name", deps_key="next")


def nifi_flow_to_dag(flow: Dict[str, Any]) -> Dict[str, Any]:
    processors = flow.get("processors", [])
    connections = flow.get("connections", [])

    proc_ids = [p.get("id") for p in processors if p.get("id")]
    if not proc_ids:
        raise ValueError("nifi flow requires processors with id")

    upstream: Dict[str, List[str]] = {pid: [] for pid in proc_ids}
    for c in connections:
        src = c.get("source")
        dst = c.get("target")
        if src in upstream and dst in upstream:
            upstream[dst].append(src)

    records = []
    for p in processors:
        pid = p.get("id")
        if not pid:
            continue
        records.append({"id": pid, "name": p.get("name", pid), "deps": upstream[pid]})

    return _from_node_records(records, id_key="id", name_key="name", deps_key="deps")


def shipyard_blueprint_to_dag(blueprint: Dict[str, Any]) -> Dict[str, Any]:
    steps = blueprint.get("steps", [])
    return _from_node_records(steps, id_key="name", name_key="name", deps_key="depends_on")


def mage_pipeline_to_dag(pipeline: Dict[str, Any]) -> Dict[str, Any]:
    blocks = pipeline.get("blocks", [])
    return _from_node_records(blocks, id_key="name", name_key="name", deps_key="upstream_blocks")


def argo_workflow_to_dag(workflow: Dict[str, Any]) -> Dict[str, Any]:
    spec = workflow.get("spec", {})
    templates = spec.get("templates", [])
    dag_template = next((t for t in templates if isinstance(t, dict) and "dag" in t), None)
    if not dag_template:
        raise ValueError("argo workflow requires a template with dag.tasks")
    tasks = dag_template.get("dag", {}).get("tasks", [])
    return _from_node_records(tasks, id_key="name", name_key="name", deps_key="dependencies")


def kestra_flow_to_dag(flow: Dict[str, Any]) -> Dict[str, Any]:
    tasks = flow.get("tasks", [])
    return _from_node_records(tasks, id_key="id", name_key="id", deps_key="dependsOn")


def luigi_pipeline_to_dag(pipeline: Dict[str, Any]) -> Dict[str, Any]:
    tasks = pipeline.get("tasks", [])
    return _from_node_records(tasks, id_key="task_id", name_key="task_id", deps_key="requires")


def dagster_job_to_dag(job: Dict[str, Any]) -> Dict[str, Any]:
    ops = job.get("ops", [])
    return _from_node_records(ops, id_key="name", name_key="name", deps_key="deps")


def _from_node_records(
    records: Iterable[Dict[str, Any]],
    id_key: str,
    name_key: str,
    deps_key: str,
) -> Dict[str, Any]:
    records = list(records)
    if not records:
        raise ValueError("records must be non-empty")

    ids = [str(r[id_key]) for r in records if r.get(id_key)]
    if len(ids) != len(records):
        raise ValueError(f"all records require '{id_key}'")

    id_to_node = {rid: f"node-{idx}" for idx, rid in enumerate(ids)}

    edges: List[Dict[str, str]] = []
    nodes: List[Dict[str, Any]] = []

    for r in records:
        rid = str(r[id_key])
        raw_deps = r.get(deps_key, [])
        dep_ids = _coerce_deps(raw_deps)
        mapped_deps = [id_to_node[d] for d in dep_ids if d in id_to_node]

        nodes.append(
            {
                "id": id_to_node[rid],
                "task_name": _normalize_task_name(str(r.get(name_key, rid))),
                "dependencies": mapped_deps,
            }
        )

        for dep in mapped_deps:
            edge = {"from": dep, "to": id_to_node[rid]}
            if edge not in edges:
                edges.append(edge)

    entry = _first_no_deps(nodes) or nodes[0]["id"]
    ret = _sink(nodes, edges) or nodes[-1]["id"]
    return {
        "nodes": nodes,
        "edges": edges,
        "entrypoints": {"default": {"node": entry}},
        "return_node": ret,
    }


def _coerce_deps(raw: Any) -> List[str]:
    if raw is None:
        return []
    if isinstance(raw, str):
        return [raw]
    if isinstance(raw, (list, tuple, set)):
        return [str(x) for x in raw]
    return []


def _first_no_deps(nodes: List[Dict[str, Any]]) -> Optional[str]:
    for n in nodes:
        if not n.get("dependencies"):
            return n["id"]
    return None


def _sink(nodes: List[Dict[str, Any]], edges: List[Dict[str, str]]) -> Optional[str]:
    outgoing = {e["from"] for e in edges}
    for n in nodes:
        if n["id"] not in outgoing:
            return n["id"]
    return None


def _normalize_task_name(name: str) -> str:
    lowered = name.strip().lower()
    chars = []
    prev_us = False
    for ch in lowered:
        if ch.isalnum():
            chars.append(ch)
            prev_us = False
        else:
            if not prev_us:
                chars.append("_")
                prev_us = True
    normalized = "".join(chars).strip("_")
    return normalized or "task"
