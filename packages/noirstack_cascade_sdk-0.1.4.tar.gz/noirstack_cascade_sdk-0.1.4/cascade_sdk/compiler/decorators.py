"""Decorators for task and flow definitions."""

import functools
from typing import Any, Callable, TypeVar
from .context import FlowContext

T = TypeVar('T', bound=Callable[..., Any])

def task(func: T) -> T:
    """
    Decorator to mark a function as a task.
    
    Tasks are executable units in a workflow. During flow compilation,
    task calls are captured to build the DAG. During execution, tasks
    run directly.
    
    Example:
        @task
        def add(a: int, b: int) -> int:
            return a + b
    """
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        # Check if we're in DAG capture mode
        context = FlowContext.get_current()
        
        if context is not None:
            # Capture mode: Record task call as DAG node
            
            # Extract dependencies from args/kwargs
            dependencies = []
            for arg in args:
                if isinstance(arg, _TaskPlaceholder):
                    dependencies.append(arg.node_id)
            for value in kwargs.values():
                if isinstance(value, _TaskPlaceholder):
                    dependencies.append(value.node_id)
            
            # Add node with dependencies
            node_id = context.add_node(func, args, kwargs, dependencies)
            
            # Return a placeholder that references this node
            return _TaskPlaceholder(node_id, func.__name__)
        else:
            # Execute mode: Run task directly
            return func(*args, **kwargs)
    
    # Mark as task for introspection
    wrapper._is_task = True
    wrapper._task_name = func.__name__
    wrapper._original_func = func
    
    return wrapper


def flow(func: T) -> T:
    """
    Decorator to mark a function as a flow definition.
    
    Flows orchestrate tasks into a DAG. The @flow decorator enables
    compilation mode where task calls are captured rather than executed.
    
    Example:
        @flow
        def math_workflow(a: int, b: int) -> int:
            x = add(a, b)
            return multiply(x, 2)
    """
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        # Flows always execute directly the user code
        # DAG compilation happens via build_dag_from_flow()
        return func(*args, **kwargs)
    
    # Mark as flow for introspection
    wrapper._is_flow = True
    wrapper._flow_name = func.__name__
    wrapper._original_func = func
    
    return wrapper


class _TaskPlaceholder:
    """
    Placeholder object returned by tasks during DAG capture.
    
    Tracks node ID and task name for dependency resolution.
    """
    def __init__(self, node_id: str, task_name: str):
        self.node_id = node_id
        self.task_name = task_name
    
    def __repr__(self):
        return f"<TaskPlaceholder {self.task_name} @ {self.node_id}>"
