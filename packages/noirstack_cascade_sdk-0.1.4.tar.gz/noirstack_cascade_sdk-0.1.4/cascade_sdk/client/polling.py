"""Polling utilities for run completion."""

import asyncio
import time
from typing import Dict, Any, Optional, Callable
from .client import CascadeClient
from .errors import TimeoutError as SDKTimeoutError


def wait_for_completion(
    client: CascadeClient,
    run_id: str,
    timeout: int = 300,
    poll_interval: float = 1.0,
    on_status_change: Optional[Callable[[str], None]] = None
) -> Dict[str, Any]:
    """
    Poll run until completion or timeout.
    
    Blocks until run reaches terminal state.
    
    Args:
        client: CascadeClient instance
        run_id: Run UUID to poll
        timeout: Max wait time in seconds (default: 300)
        poll_interval: Seconds between polls (default: 1.0)
        on_status_change: Optional callback for status updates
    
    Returns:
        Final run object with status and result
    
    Raises:
        TimeoutError: Run didn't complete within timeout
    
    Example:
        run_id = client.trigger_flow(flow_id, inputs)
        result = wait_for_completion(client, run_id, timeout=60)
        
        if result['status'] == 'completed':
            print("Success:", result['result'])
        else:
            print("Failed:", result.get('error'))
    """
    start_time = time.time()
    last_status = None
    
    while True:
        # Check timeout
        elapsed = time.time() - start_time
        if elapsed > timeout:
            raise SDKTimeoutError(
                f"Run {run_id} did not complete within {timeout}s"
            )
        
        # Poll run status
        run = client.get_run(run_id)
        status = run['status']
        
        # Notify on status change
        if status != last_status and on_status_change:
            on_status_change(status)
            last_status = status
        
        # Check if terminal
        if status in ('completed', 'failed', 'canceled', 'cancelled', 'timedout', 'crashed'):
            return run
        
        # Wait before next poll
        time.sleep(poll_interval)


async def wait_for_completion_async(
    client: CascadeClient,
    run_id: str,
    timeout: int = 300,
    poll_interval: float = 1.0,
    on_status_change: Optional[Callable[[str], None]] = None,
) -> Dict[str, Any]:
    """Asynchronously poll run status until completion or timeout.

    This helper preserves the existing synchronous HTTP client contract while
    avoiding event-loop blocking by executing `client.get_run(...)` in a worker
    thread.

    Args:
        client: CascadeClient instance
        run_id: Run UUID to poll
        timeout: Max wait time in seconds (default: 300)
        poll_interval: Seconds between polls (default: 1.0)
        on_status_change: Optional callback for status updates

    Returns:
        Final run object with status and result

    Raises:
        TimeoutError: Run didn't complete within timeout
    """
    loop = asyncio.get_running_loop()
    start_time = loop.time()
    last_status = None

    while True:
        elapsed = loop.time() - start_time
        if elapsed > timeout:
            raise SDKTimeoutError(
                f"Run {run_id} did not complete within {timeout}s"
            )

        run = await asyncio.to_thread(client.get_run, run_id)
        status = run['status']

        if status != last_status and on_status_change:
            on_status_change(status)
            last_status = status

        if status in ('completed', 'failed', 'canceled', 'cancelled', 'timedout', 'crashed'):
            return run

        await asyncio.sleep(poll_interval)
