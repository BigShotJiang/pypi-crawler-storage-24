"""HTTP client for Cascade control plane API."""

import requests
from typing import Dict, Any, Optional, Callable, Set
from .errors import (
    CascadeSDKError,
    AuthenticationError,
    ValidationError,
    NotFoundError,
    RateLimitError,
    OrchestrationError,
    NetworkError,
    TimeoutError as SDKTimeoutError,
)
from ..standards import (
    build_cloudevent,
    build_prov_bundle,
    prov_activity,
    prov_agent,
    prov_entity,
    build_trace_context_headers,
)


class CascadeClient:
    """
    HTTP client for Cascade control plane API.
    
    Provides methods for:
    - Flow registration
    - Flow triggering
    - Run status polling
    - DAG graph retrieval
    
    Authentication: API key via X-API-Key header
    
    Example:
        client = CascadeClient(
            base_url="http://localhost:3000",
            api_key="cascade_dev_key"
        )
        
        flow_id = client.register_flow("my_flow", dag_definition)
        run_id = client.trigger_flow(flow_id, {"input": "data"})
        status = client.get_run(run_id)
    """
    
    def __init__(
        self,
        base_url: str,
        api_key: str,
        timeout: int = 30,
        verify_ssl: bool = True,
        metadata_hook: Optional[Callable[[Dict[str, Any], Dict[str, Any]], None]] = None,
        standards_source: str = "urn:cascade:sdk:python",
        task_output_path_template: str = "/api/runs/{run_id}/tasks/{task_id}/output",
    ):
        """
        Initialize Cascade client.
        
        Args:
            base_url: Server base URL (e.g., "http://localhost:3000")
            api_key: API key for authentication
            timeout: Request timeout in seconds (default: 30)
            verify_ssl: Verify SSL certificates (default: True)
            metadata_hook: Optional callback receiving (cloudevent, provenance)
            standards_source: CloudEvents source value for emitted metadata
            task_output_path_template: Path template for HITL task output submit
                endpoints. Supports placeholders `{run_id}` and `{task_id}`.
        """
        self.base_url = base_url.rstrip('/')
        self.api_key = api_key
        self.timeout = timeout
        self.verify_ssl = verify_ssl
        self.metadata_hook = metadata_hook
        self.standards_source = standards_source
        self.task_output_path_template = task_output_path_template
        self._emitted_terminal_states: Dict[str, Set[str]] = {}
        self.last_cloudevent: Optional[Dict[str, Any]] = None
        self.last_provenance: Optional[Dict[str, Any]] = None
        
        self.session = requests.Session()
        self.session.headers.update({
            'X-API-Key': api_key,
            'Content-Type': 'application/json',
            'User-Agent': 'cascade-sdk-python/0.1.0'
        })
    
    def _request(
        self,
        method: str,
        path: str,
        json: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        """
        Make HTTP request with error handling.
        
        Args:
            method: HTTP method (GET, POST, etc.)
            path: API path (e.g., "/api/flows")
            json: Request body as dict
            params: Query parameters
        
        Returns:
            Response JSON as dict
        
        Raises:
            AuthenticationError: 401
            ValidationError: 400
            NotFoundError: 404
            RateLimitError: 429
            OrchestrationError: 5xx
            NetworkError: Connection failed
            TimeoutError: Request timeout
        """
        url = f"{self.base_url}{path}"
        
        try:
            response = self.session.request(
                method=method,
                url=url,
                json=json,
                params=params,
                headers=headers,
                timeout=self.timeout,
                verify=self.verify_ssl
            )
        except requests.exceptions.Timeout as e:
            raise SDKTimeoutError(f"Request timeout after {self.timeout}s") from e
        except requests.exceptions.ConnectionError as e:
            raise NetworkError(f"Connection failed: {e}") from e
        except requests.exceptions.RequestException as e:
            raise NetworkError(f"Network error: {e}") from e
        
        # Parse response body
        try:
            response_body = response.json() if response.content else {}
        except ValueError:
            response_body = {'raw': response.text}
        
        # Handle HTTP errors
        if response.status_code == 401:
            raise AuthenticationError(
                "Authentication failed - check API key",
                status_code=401,
                response_body=response_body
            )
        elif response.status_code == 400:
            msg = response_body.get('title', 'Validation failed')
            raise ValidationError(msg, status_code=400, response_body=response_body)
        elif response.status_code == 404:
            msg = response_body.get('title', 'Resource not found')
            raise NotFoundError(msg, status_code=404, response_body=response_body)
        elif response.status_code == 429:
            msg = response_body.get('title', 'Rate limit exceeded')
            raise RateLimitError(msg, status_code=429, response_body=response_body)
        elif response.status_code >= 500:
            msg = response_body.get('title', 'Server error')
            raise OrchestrationError(msg, status_code=response.status_code, response_body=response_body)
        elif not response.ok:
            raise CascadeSDKError(
                f"HTTP {response.status_code}: {response.text}",
                status_code=response.status_code,
                response_body=response_body
            )
        
        return response_body

    def _emit_standards_metadata(
        self,
        event_type: str,
        run_id: str,
        flow_id: Optional[str],
        data: Dict[str, Any],
        trace_headers: Optional[Dict[str, str]] = None,
    ) -> None:
        """Emit CloudEvents + W3C PROV metadata through optional hook."""
        extensions = dict(trace_headers or {})
        extensions["provref"] = f"prov:run:{run_id}"

        event = build_cloudevent(
            event_type=event_type,
            source=self.standards_source,
            subject=run_id,
            data=data,
            extensions=extensions,
        )

        entities = []
        if data.get("inputs") is not None:
            entities.append(prov_entity(f"entity:{run_id}:inputs", {"kind": "inputs"}))
        if data.get("result") is not None:
            entities.append(prov_entity(f"entity:{run_id}:result", {"kind": "result"}))

        prov = build_prov_bundle(
            entities=entities,
            activities=[prov_activity(f"activity:{run_id}", attrs={"flow_id": flow_id})],
            agents=[prov_agent("agent:cascade_sdk", {"role": "client"})],
            was_generated_by=(
                {"wgb:result": {"prov:entity": f"entity:{run_id}:result", "prov:activity": f"activity:{run_id}"}}
                if data.get("result") is not None
                else {}
            ),
        )

        self.last_cloudevent = event
        self.last_provenance = prov
        if self.metadata_hook:
            self.metadata_hook(event, prov)
    
    def register_flow(self, flow_name: str, dag: Dict[str, Any], version: str = '1.0.0') -> str:
        """
        Register a flow definition.
        
        Args:
            flow_name: Unique flow name
            dag: DAG definition dictionary
                Required: {nodes: [...], edges: [...], return_node: 'node-x'}
            version: Flow version for immutable registration
        
        Returns:
            flow_id: UUID of registered flow
        
        Raises:
            ValidationError: Invalid DAG structure
            AuthenticationError: Invalid API key
        
        Example:
            flow_id = client.register_flow("math_flow", {
                'nodes': [{'id': 'n1', 'task': 'add'}],
                'edges': []
            })
        """
        response = self._request(
            'POST',
            '/api/flows/register',
            json={'name': flow_name, 'version': version, 'dag': dag}
        )
        return response['id']
    
    def trigger_flow(self, flow_id: str, inputs: Dict[str, Any]) -> str:
        """
        Trigger a flow execution.
        
        Args:
            flow_id: Flow UUID from register_flow()
            inputs: Input parameters for flow
        
        Returns:
            run_id: UUID of triggered run
        
        Raises:
            NotFoundError: Flow doesn't exist
            ValidationError: Invalid inputs
        
        Example:
            run_id = client.trigger_flow(flow_id, {'a': 10, 'b': 20})
        """
        trace_headers = build_trace_context_headers()
        response = self._request(
            'POST',
            '/api/runs',
            json={'flow_id': flow_id, 'input': inputs},
            headers=trace_headers or None,
        )
        run_id = response['run_id']

        self._emit_standards_metadata(
            event_type='cascade.flow.run.triggered',
            run_id=run_id,
            flow_id=flow_id,
            data={'run_id': run_id, 'flow_id': flow_id, 'inputs': inputs, 'status': 'queued'},
            trace_headers=trace_headers,
        )
        return run_id
    
    def get_run(self, run_id: str) -> Dict[str, Any]:
        """
        Get run status and result.
        
        Args:
            run_id: Run UUID from trigger_flow()
        
        Returns:
            Run object with status, result, error, timestamps
        
        Raises:
            NotFoundError: Run doesn't exist
        
        Example:
            status = client.get_run(run_id)
            if status['status'] == 'completed':
                print(status['result'])
        """
        run = self._request('GET', f'/api/runs/{run_id}')

        # Normalize server state casing to SDK contract.
        status = run.get('status')
        if isinstance(status, str):
            run['status'] = status.lower()

        # Keep a stable SDK field for successful results.
        if 'result' not in run and 'output' in run:
            run['result'] = run.get('output')

        # Emit terminal state metadata once per run+status.
        run_id = run.get('run_id') or run_id
        status = run.get('status')
        if isinstance(status, str) and status in ('completed', 'failed', 'cancelled', 'canceled', 'timedout', 'crashed'):
            seen = self._emitted_terminal_states.setdefault(run_id, set())
            if status not in seen:
                seen.add(status)
                self._emit_standards_metadata(
                    event_type=f'cascade.flow.run.{status}',
                    run_id=run_id,
                    flow_id=run.get('flow_id'),
                    data={
                        'run_id': run_id,
                        'flow_id': run.get('flow_id'),
                        'status': status,
                        'result': run.get('result'),
                        'error': run.get('state', {}).get('message') if isinstance(run.get('state'), dict) else None,
                    },
                    trace_headers=build_trace_context_headers(),
                )

        return run
    
    def get_flow_graph(self, flow_id: str) -> Dict[str, Any]:
        """
        Get flow DAG definition.
        
        Args:
            flow_id: Flow UUID
        
        Returns:
            Flow object with name, dag, metadata
        
        Raises:
            NotFoundError: Flow doesn't exist
        """
        return self._request('GET', f'/api/flows/definitions/{flow_id}/graph')
    
    def get_run_graph(self, run_id: str) -> Dict[str, Any]:
        """
        Get run execution graph with node states.
        
        Args:
            run_id: Run UUID
        
        Returns:
            Graph with nodes, edges, node states, timing
        
        Raises:
            NotFoundError: Run doesn't exist
        """
        return self._request('GET', f'/api/flow-runs/{run_id}/graph')

    def submit_task_output(
        self,
        run_id: str,
        task_id: str,
        output: Any,
        metadata: Optional[Dict[str, Any]] = None,
        path_template: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Submit output for a paused/manual task to resume workflow execution.

        This helper is intentionally thin and endpoint-template driven so users
        can align with control-plane variations without embedding orchestration
        logic in the SDK.

        Args:
            run_id: Run identifier
            task_id: Task/node identifier awaiting output
            output: Task output payload
            metadata: Optional metadata for audit or routing
            path_template: Optional path template override. Supports
                `{run_id}` and `{task_id}` placeholders.

        Returns:
            Response body from control plane
        """
        template = path_template or self.task_output_path_template
        path = template.format(run_id=run_id, task_id=task_id)

        payload: Dict[str, Any] = {
            'run_id': run_id,
            'task_id': task_id,
            'output': output,
        }
        if metadata is not None:
            payload['metadata'] = metadata

        response = self._request('POST', path, json=payload)

        self._emit_standards_metadata(
            event_type='cascade.task.output.submitted',
            run_id=run_id,
            flow_id=response.get('flow_id') if isinstance(response, dict) else None,
            data={
                'run_id': run_id,
                'task_id': task_id,
                'status': response.get('status') if isinstance(response, dict) else None,
            },
            trace_headers=build_trace_context_headers(),
        )

        return response
