"""Exception hierarchy for Cascade SDK."""

class CascadeSDKError(Exception):
    """Base exception for all Cascade SDK errors."""
    
    def __init__(self, message: str, status_code: int = None, response_body: dict = None):
        super().__init__(message)
        self.status_code = status_code
        self.response_body = response_body


class AuthenticationError(CascadeSDKError):
    """
    Authentication failed.
    
    Raised when:
    - API key is missing
    - API key is invalid
    - API key is expired
    
    HTTP Status: 401
    """
    pass


class ValidationError(CascadeSDKError):
    """
    Request validation failed.
    
    Raised when:
    - DAG structure is invalid
    - Required fields are missing
    - Field values are out of range
    
    HTTP Status: 400
    """
    pass


class NotFoundError(CascadeSDKError):
    """
    Resource not found.
    
    Raised when:
    - Flow ID doesn't exist
    - Run ID doesn't exist
    - Endpoint doesn't exist
    
    HTTP Status: 404
    """
    pass


class RateLimitError(CascadeSDKError):
    """
    Rate limit exceeded.
    
    Raised when:
    - Too many requests in time window
    - Quota exceeded
    
    HTTP Status: 429
    """
    pass


class OrchestrationError(CascadeSDKError):
    """
    Orchestration operation failed.
    
    Raised when:
    - Flow registration failed
    - Trigger failed
    - Job execution failed
    
    HTTP Status: 5xx
    """
    pass


class NetworkError(CascadeSDKError):
    """
    Network communication failed.
    
    Raised when:
    - Cannot connect to server
    - Connection lost during request
    - DNS resolution failed
    """
    pass


class TimeoutError(CascadeSDKError):
    """
    Request timeout.
    
    Raised when:
    - Request exceeds timeout duration
    - Server doesn't respond
    """
    pass
