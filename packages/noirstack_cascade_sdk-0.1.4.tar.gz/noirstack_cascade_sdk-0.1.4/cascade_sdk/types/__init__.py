"""Type definitions for Cascade SDK.

TypedDict definitions for IDE autocompletion and type checking.
These are optional - the SDK works without them.
"""

from typing import TypedDict, List, Optional, Any


class Node(TypedDict, total=False):
    """DAG node definition."""
    id: str
    task: str
    depends_on: List[str]


class Edge(TypedDict):
    """DAG edge definition."""
    from_node: str  # 'from' field
    to_node: str     # 'to' field


class DAGDefinition(TypedDict, total=False):
    """Complete DAG structure."""
    nodes: List[Node]
    edges: List[Edge]
    return_node_id: Optional[str]


class FlowDefinition(TypedDict):
    """Flow registration request."""
    name: str
    dag: DAGDefinition


class TriggerRequest(TypedDict):
    """Flow trigger request."""
    inputs: dict


class FlowRun(TypedDict, total=False):
    """Flow run status object."""
    run_id: str
    flow_id: str
    status: str  # 'pending' | 'running' | 'completed' | 'failed' | 'canceled'
    result: Optional[Any]
    error: Optional[str]
    created_at: str
    started_at: Optional[str]
    completed_at: Optional[str]


class FlowGraph(TypedDict):
    """Flow definition with metadata."""
    flow_id: str
    name: str
    dag: DAGDefinition
    created_at: str


class NodeState(TypedDict, total=False):
    """Node execution state."""
    node_id: str
    status: str  # 'pending' | 'running' | 'completed' | 'failed'
    result: Optional[Any]
    error: Optional[str]
    started_at: Optional[str]
    completed_at: Optional[str]


class RunGraph(TypedDict):
    """Run execution graph with node states."""
    run_id: str
    flow_id: str
    dag: DAGDefinition
    node_states: List[NodeState]
    created_at: str
