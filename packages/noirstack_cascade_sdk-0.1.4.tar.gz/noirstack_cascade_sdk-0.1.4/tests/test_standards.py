from cascade_sdk.standards import (
    build_cloudevent,
    cloudevent_json,
    prov_agent,
    prov_entity,
    prov_activity,
    build_prov_bundle,
    build_trace_context_headers,
)


def test_cloudevent_minimal_fields():
    event = build_cloudevent(
        event_type="cascade.flow.run.started",
        source="urn:cascade:test",
        data={"run_id": "r1"},
    )
    assert event["specversion"] == "1.0"
    assert event["type"] == "cascade.flow.run.started"
    assert event["source"] == "urn:cascade:test"
    assert "id" in event
    assert "time" in event
    assert "run_id" in event["data"]

    serialized = cloudevent_json(event)
    assert serialized.startswith("{")


def test_prov_bundle_relations():
    ent_in = prov_entity("entity:input", {"format": "json"})
    ent_out = prov_entity("entity:output", {"format": "json"})
    act = prov_activity("activity:flow_run")
    ag = prov_agent("agent:worker", {"role": "orchestrator"})

    bundle = build_prov_bundle(
        entities=[ent_in, ent_out],
        activities=[act],
        agents=[ag],
        was_generated_by={
            "wgb1": {"prov:entity": "entity:output", "prov:activity": "activity:flow_run"}
        },
        was_derived_from={
            "wdf1": {"prov:generatedEntity": "entity:output", "prov:usedEntity": "entity:input"}
        },
    )

    assert "entity" in bundle
    assert "activity" in bundle
    assert "agent" in bundle
    assert "wgb1" in bundle["wasGeneratedBy"]
    assert "wdf1" in bundle["wasDerivedFrom"]


def test_trace_context_headers_fallback():
    headers = build_trace_context_headers()
    # Works with or without opentelemetry installed.
    assert isinstance(headers, dict)
