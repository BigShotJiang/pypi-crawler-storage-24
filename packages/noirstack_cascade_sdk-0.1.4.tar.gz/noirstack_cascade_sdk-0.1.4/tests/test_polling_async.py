import asyncio

from cascade_sdk.client.client import CascadeClient
from cascade_sdk.client.polling import wait_for_completion_async


class DummyAsyncPollClient(CascadeClient):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.calls = 0

    def get_run(self, run_id):
        self.calls += 1
        if self.calls == 1:
            return {"run_id": run_id, "status": "running"}
        return {"run_id": run_id, "status": "completed", "result": {"ok": True}}


def test_wait_for_completion_async_reaches_terminal_state():
    client = DummyAsyncPollClient(base_url="http://localhost:3000", api_key="k")

    async def run_test():
        statuses = []

        def on_status(status):
            statuses.append(status)

        result = await wait_for_completion_async(
            client,
            "run-1",
            timeout=5,
            poll_interval=0.01,
            on_status_change=on_status,
        )
        assert result["status"] == "completed"
        assert result["result"] == {"ok": True}
        assert statuses == ["running", "completed"]

    asyncio.run(run_test())
