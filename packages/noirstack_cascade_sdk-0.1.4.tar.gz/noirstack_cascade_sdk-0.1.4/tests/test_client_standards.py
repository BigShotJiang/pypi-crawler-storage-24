from cascade_sdk.client.client import CascadeClient


class DummyClient(CascadeClient):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._poll_count = 0

    def _request(self, method, path, json=None, params=None, headers=None):
        if method == "POST" and path == "/api/runs":
            return {"run_id": "run-1"}
        if method == "GET" and path == "/api/runs/run-1":
            self._poll_count += 1
            return {
                "run_id": "run-1",
                "flow_id": "flow-1",
                "status": "COMPLETED",
                "output": {"ok": True},
                "state": {"message": "done"},
            }
        raise AssertionError(f"Unexpected call: {method} {path}")


def test_metadata_hook_emits_trigger_and_terminal_once():
    events = []

    def hook(evt, prov):
        events.append((evt, prov))

    client = DummyClient(
        base_url="http://localhost:3000",
        api_key="k",
        metadata_hook=hook,
    )

    run_id = client.trigger_flow("flow-1", {"a": 1})
    assert run_id == "run-1"

    run = client.get_run("run-1")
    assert run["status"] == "completed"

    # second poll should not duplicate terminal event
    client.get_run("run-1")

    event_types = [e[0]["type"] for e in events]
    assert "cascade.flow.run.triggered" in event_types
    assert event_types.count("cascade.flow.run.completed") == 1
