from cascade_sdk import (
    flyte_workflow_to_dag,
    mlrun_pipeline_to_dag,
    metaflow_to_dag,
    nifi_flow_to_dag,
    shipyard_blueprint_to_dag,
    mage_pipeline_to_dag,
    argo_workflow_to_dag,
    kestra_flow_to_dag,
    luigi_pipeline_to_dag,
    dagster_job_to_dag,
)


def _assert_dag_shape(dag, expected_nodes):
    assert "nodes" in dag
    assert "edges" in dag
    assert "entrypoints" in dag
    assert "return_node" in dag
    assert len(dag["nodes"]) == expected_nodes


def test_flyte_adapter():
    dag = flyte_workflow_to_dag({"nodes": [{"id": "a", "name": "extract"}, {"id": "b", "name": "load", "upstream": ["a"]}]})
    _assert_dag_shape(dag, 2)


def test_mlrun_adapter():
    dag = mlrun_pipeline_to_dag({"steps": [{"name": "extract"}, {"name": "train", "depends_on": ["extract"]}]})
    _assert_dag_shape(dag, 2)


def test_metaflow_adapter():
    dag = metaflow_to_dag({"steps": [{"name": "start"}, {"name": "end", "next": ["start"]}]})
    _assert_dag_shape(dag, 2)


def test_nifi_adapter():
    dag = nifi_flow_to_dag({
        "processors": [{"id": "p1", "name": "ingest"}, {"id": "p2", "name": "enrich"}],
        "connections": [{"source": "p1", "target": "p2"}],
    })
    _assert_dag_shape(dag, 2)


def test_shipyard_adapter():
    dag = shipyard_blueprint_to_dag({"steps": [{"name": "a"}, {"name": "b", "depends_on": ["a"]}]})
    _assert_dag_shape(dag, 2)


def test_mage_adapter():
    dag = mage_pipeline_to_dag({"blocks": [{"name": "a"}, {"name": "b", "upstream_blocks": ["a"]}]})
    _assert_dag_shape(dag, 2)


def test_argo_adapter():
    dag = argo_workflow_to_dag({
        "spec": {
            "templates": [
                {
                    "name": "main",
                    "dag": {
                        "tasks": [
                            {"name": "a"},
                            {"name": "b", "dependencies": ["a"]},
                        ]
                    },
                }
            ]
        }
    })
    _assert_dag_shape(dag, 2)


def test_kestra_adapter():
    dag = kestra_flow_to_dag({"tasks": [{"id": "a"}, {"id": "b", "dependsOn": ["a"]}]})
    _assert_dag_shape(dag, 2)


def test_luigi_adapter():
    dag = luigi_pipeline_to_dag({"tasks": [{"task_id": "a"}, {"task_id": "b", "requires": ["a"]}]})
    _assert_dag_shape(dag, 2)


def test_dagster_adapter():
    dag = dagster_job_to_dag({"ops": [{"name": "a"}, {"name": "b", "deps": ["a"]}]})
    _assert_dag_shape(dag, 2)
