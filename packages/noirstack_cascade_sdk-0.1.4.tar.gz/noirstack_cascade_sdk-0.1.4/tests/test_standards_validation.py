from cascade_sdk import build_cloudevent, validate_cloudevent, validate_dag


def test_validate_cloudevent_success():
    event = build_cloudevent(
        event_type="cascade.flow.run.started",
        source="urn:test",
        data={"run_id": "r1"},
    )
    validate_cloudevent(event)


def test_validate_cloudevent_missing_required():
    bad = {"specversion": "1.0", "id": "x", "source": "urn:test", "time": "2026-03-09T00:00:00Z"}
    try:
        validate_cloudevent(bad)
        raise AssertionError("Expected validation failure")
    except ValueError as exc:
        msg = str(exc).lower()
        assert ("missing required field: type" in msg) or ("required property" in msg)


def test_validate_dag_success():
    dag = {
        "nodes": [
            {"id": "node-0", "task_name": "a", "dependencies": []},
            {"id": "node-1", "task_name": "b", "dependencies": ["node-0"]},
        ],
        "edges": [{"from": "node-0", "to": "node-1"}],
        "entrypoints": {"default": {"node": "node-0"}},
        "return_node": "node-1",
    }
    validate_dag(dag)


def test_validate_dag_duplicate_nodes():
    dag = {
        "nodes": [
            {"id": "node-0", "task_name": "a", "dependencies": []},
            {"id": "node-0", "task_name": "b", "dependencies": []},
        ],
        "edges": [],
        "entrypoints": {"default": {"node": "node-0"}},
        "return_node": "node-0",
    }
    try:
        validate_dag(dag)
        raise AssertionError("Expected duplicate node error")
    except ValueError as exc:
        assert "duplicate node id" in str(exc).lower()
