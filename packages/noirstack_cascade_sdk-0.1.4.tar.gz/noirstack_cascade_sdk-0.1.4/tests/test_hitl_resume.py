from cascade_sdk.client.client import CascadeClient


class DummyResumeClient(CascadeClient):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.last_request = None

    def _request(self, method, path, json=None, params=None, headers=None):
        self.last_request = {
            "method": method,
            "path": path,
            "json": json,
        }
        return {"ok": True, "status": "running", "flow_id": "flow-1"}


def test_submit_task_output_uses_default_template_and_payload():
    client = DummyResumeClient(base_url="http://localhost:3000", api_key="k")

    result = client.submit_task_output(
        run_id="run-123",
        task_id="task-abc",
        output={"approved": True},
        metadata={"actor": "hira@example.com"},
    )

    assert result["ok"] is True
    assert client.last_request["method"] == "POST"
    assert client.last_request["path"] == "/api/runs/run-123/tasks/task-abc/output"
    assert client.last_request["json"]["run_id"] == "run-123"
    assert client.last_request["json"]["task_id"] == "task-abc"
    assert client.last_request["json"]["output"] == {"approved": True}
    assert client.last_request["json"]["metadata"] == {"actor": "hira@example.com"}


def test_submit_task_output_supports_path_override():
    client = DummyResumeClient(base_url="http://localhost:3000", api_key="k")

    client.submit_task_output(
        run_id="run-7",
        task_id="node-2",
        output={"decision": "APPROVE"},
        path_template="/api/hitl/{run_id}/tasks/{task_id}/complete",
    )

    assert client.last_request["path"] == "/api/hitl/run-7/tasks/node-2/complete"
