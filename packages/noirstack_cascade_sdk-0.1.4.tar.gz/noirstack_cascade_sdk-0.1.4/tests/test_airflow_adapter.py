from cascade_sdk import airflow_dag_to_dag


class FakeTask:
    def __init__(self, task_id, upstream=None):
        self.task_id = task_id
        self.upstream_task_ids = set(upstream or [])


class FakeDAG:
    def __init__(self, tasks):
        self.tasks = tasks


def test_airflow_adapter_basic_chain():
    dag = FakeDAG(
        [
            FakeTask("extract"),
            FakeTask("transform", upstream=["extract"]),
            FakeTask("load", upstream=["transform"]),
        ]
    )

    out = airflow_dag_to_dag(dag)
    assert len(out["nodes"]) == 3
    assert len(out["edges"]) == 2
    assert out["entrypoints"]["default"]["node"] == "node-0"
    assert out["return_node"] == "node-2"

    names = [n["task_name"] for n in out["nodes"]]
    assert names == ["extract", "transform", "load"]


def test_airflow_adapter_requires_tasks():
    class Empty:
        tasks = []

    try:
        airflow_dag_to_dag(Empty())
        raise AssertionError("Expected ValueError")
    except ValueError as e:
        assert "non-empty" in str(e)
