from cascade_sdk import task, flow
from cascade_sdk.compiler import build_dag_from_flow, canonical_json


@task
def add(a: int, b: int) -> int:
    return a + b


@task
def mul(x: int, y: int) -> int:
    return x * y


@flow
def sample_flow(a: int, b: int) -> int:
    s = add(a, b)
    return mul(s, 2)


def test_build_dag_shape():
    dag = build_dag_from_flow(sample_flow)

    assert "nodes" in dag
    assert "edges" in dag
    assert dag["return_node"] == "node-1"
    assert dag["entrypoints"]["default"]["node"] == "node-0"
    assert len(dag["nodes"]) == 2
    assert len(dag["edges"]) == 1


def test_canonical_json_deterministic():
    dag1 = build_dag_from_flow(sample_flow)
    dag2 = build_dag_from_flow(sample_flow)
    assert canonical_json(dag1) == canonical_json(dag2)
