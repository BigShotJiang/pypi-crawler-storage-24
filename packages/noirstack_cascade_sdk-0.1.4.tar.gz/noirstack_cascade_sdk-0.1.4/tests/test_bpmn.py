from cascade_sdk import bpmn_xml_to_dag


def test_bpmn_xml_to_dag_basic_mapping():
    xml = """<?xml version=\"1.0\" encoding=\"UTF-8\"?>
<definitions xmlns=\"http://www.omg.org/spec/BPMN/20100524/MODEL\">
  <process id=\"Process_1\" isExecutable=\"true\">
    <startEvent id=\"StartEvent_1\"/>
    <task id=\"Task_A\" name=\"Collect Evidence\"/>
    <serviceTask id=\"Task_B\" name=\"Verify Chain\"/>
    <endEvent id=\"EndEvent_1\"/>
    <sequenceFlow id=\"Flow_1\" sourceRef=\"StartEvent_1\" targetRef=\"Task_A\"/>
    <sequenceFlow id=\"Flow_2\" sourceRef=\"Task_A\" targetRef=\"Task_B\"/>
    <sequenceFlow id=\"Flow_3\" sourceRef=\"Task_B\" targetRef=\"EndEvent_1\"/>
  </process>
</definitions>
"""

    dag = bpmn_xml_to_dag(xml)
    assert len(dag["nodes"]) == 2
    assert len(dag["edges"]) == 1
    assert dag["entrypoints"]["default"]["node"] == "node-0"
    assert dag["return_node"] == "node-1"

    names = [n["task_name"] for n in dag["nodes"]]
    assert names == ["collect_evidence", "verify_chain"]
