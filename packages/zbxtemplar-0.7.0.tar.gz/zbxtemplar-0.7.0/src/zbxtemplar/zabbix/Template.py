from typing import Dict, List, Union
from enum import Enum

from zbxtemplar.zabbix.ZbxEntity import ZbxEntity, WithTags, WithMacros, WithGroups, Macro
from zbxtemplar.zabbix.Trigger import WithTriggers
from zbxtemplar.zabbix.Graph import WithGraphs
from zbxtemplar.zabbix.Dashboard import Dashboard
from zbxtemplar.zabbix.Item import Item


class TemplateGroup(ZbxEntity):
    def __init__(self, name: str):
        super().__init__(name)


class ValueMapType(str, Enum):
    EQUAL = "EQUAL"
    GREATER_OR_EQUAL = "GREATER_OR_EQUAL"
    LESS_OR_EQUAL = "LESS_OR_EQUAL"
    IN_RANGE = "IN_RANGE"
    REGEXP = "REGEXP"
    DEFAULT = "DEFAULT"


class ValueMap(ZbxEntity):
    def __init__(self, name: str):
        super().__init__(name)
        self.mappings: List[Dict[str, str]] = []

    def add_mapping(self, value: str, newvalue: str, type: ValueMapType = ValueMapType.EQUAL):
        self.mappings.append({"value": value, "newvalue": newvalue, "type": type.value})
        return self


class Template(ZbxEntity, WithTags, WithMacros, WithGroups, WithTriggers, WithGraphs):
    def __init__(self, name: str, groups: Union[None, List[TemplateGroup]] = None):
        super().__init__(name)
        self.template = name
        self.items: List[Item] = []
        self.dashboards: List[Dashboard] = []
        self.valuemaps: List[ValueMap] = []
        self.groups = groups or []

    def add_item(self, item: Item):
        if not any(i.key == item.key for i in self.items):
            item._host = self.name
            self.items.append(item)
        return self

    def add_dashboard(self, dashboard: Dashboard):
        if not any(d.name == dashboard.name for d in self.dashboards):
            self.dashboards.append(dashboard)
        return self

    def add_value_map(self, value_map: ValueMap):
        if not any(v.name == value_map.name for v in self.valuemaps):
            self.valuemaps.append(value_map)
        return self

    @classmethod
    def from_dict(cls, data: dict, template_groups=None):
        groups = []
        for g in data.get("groups", []):
            name = g["name"]
            if template_groups is not None:
                if name not in template_groups:
                    template_groups[name] = TemplateGroup(name)
                groups.append(template_groups[name])
            else:
                groups.append(TemplateGroup(name))
        template = cls(name=data["name"], groups=groups)
        for m in data.get("macros", []):
            macro = Macro.from_dict(m)
            template.macros[macro.name] = macro
        for t in data.get("tags", []):
            template.add_tag(t["tag"], t.get("value", ""))
        for i in data.get("items", []):
            template.items.append(Item.from_dict(i, host=data["name"]))
        return template
