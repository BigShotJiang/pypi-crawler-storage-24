from collections.abc import Sequence
from typing import Literal

import pandas as pd
import polars as pl

from pylifemap.abc import LifemapABC
from pylifemap.utils import MAX_HOVER_DATA_LEN, init_lazy, is_hex_color


class ArcsMixin:
    def layer_arcs(
        self: LifemapABC,
        data: pl.DataFrame | pd.DataFrame | None = None,
        *,
        taxid_col: str = "taxid",
        taxid_dest_col: str,
        width: int | float | str = 3,
        width_range: tuple | list = (1, 10),
        color: str | None = None,
        color_cat: bool | None = None,
        categories: Sequence | None = None,
        scheme: str | None = None,
        linetype: Literal["solid", "dotted", "smalldash", "dashed"] = "solid",
        arrow: bool = False,
        arrow_width: int = 9,
        arrow_width_range: Sequence = (7, 20),
        opacity: float = 1.0,
        popup: bool = True,
        popup_col: str | None = None,
        hover: bool | None = None,
        label: str | None = None,
        lazy: bool | None = None,
        lazy_zoom: int = 10,
        lazy_mode: Literal["self", "parent"] = "self",
    ) -> LifemapABC:
        """
        Add an arcs layer.

        Parameters
        ----------
        data : pl.DataFrame | pd.DataFrame | None, optional
            Layer data. If not provided, use the base widget data.
        taxid_col : str, optional
            Name of the data column with arc start taxonomy ids. By default `'taxid'`.
        taxid_dest_col : str, optional
            Name of the data column with arc end taxonomy ids.
        width : int | float | str, optional
            If numeric, the fixed width of the arcs. If a string, the name of a numerical DataFrame column
            to compute arc width from.
        width_range : tuple | list, optional
            Min and max values for arcs widths, only used if `width` is a data column. By default (1, 30).
        color : str | None, optional
            Either the name of a numerical DataFrame column to determine arc color, or a fixed CSS color for
            arcs.
        color_cat : bool | None, optional
            If `True`, force color scheme to be categorical. If `False`, force it to be
            continuous. If `None`, let `pylifemap` decide. By default `None`.
        categories : Sequence | None, optional
            Custom order of categories when a categorical variable is used for the `color` argument.
            Defaults to `None`.
        scheme : str | None, optional
            Color scheme for arcs color. It is the name of
            an [Observable Plot color scale](https://observablehq.com/plot/features/scales#color-scales).
        linetype: Literal['solid', 'dotted', 'smalldash', dashed'], optional
            Type of arcs. Defaults to `'solid'`.
        arrow: bool, optional
            If True, add an arrow head to the destination point. By default false.
        arrow_width: int, optional
            Width of arrow heads if arrow is True and width is not a data column. By default 9.
        width_range : tuple | list, optional
            Min and max values for arrow heads widths, only used if `width` is a data column.
            By default (8, 20).
        opacity : float
            Arc opacity as a floating number between 0 and 1. By default 1.
        popup : bool
            If `True`, display informations in a popup when a point is clicked.
            By default `True`.
        popup_col : str | None
            Name of a data column containing custom popup content. By default `None`.
        hover : bool | None, optional
            If `True`, highlight points on mouse hovering. By default `True` if less than 10_000 data points,
            `False` otherwise.
        label : str | None, optional
            Legend title for this layer if `color` is defined. If `None`, the value
            of `color` is used.
        lazy : bool | None
            If `True`, points are displayed depending on the widget view. If `False`, all points are
            displayed. Can be useful when displaying a great number of items. Defaults to `None`.
        lazy_zoom : int
            If lazy is `True`, only arcs with a zoom level less than (current zoom + `lazy_zoom`) level will
            be displayed. Defaults to 10.
        lazy_mode : Literal["self", "parent"], optional
            If `lazy` is `True`, choose the zoom level to apply to each taxa. If `'self'`, keep the taxa zoom
            level. If `'parent'`, get the nearest ancestor zoom level. Defaults to `'self'`.

        Returns
        -------
        Lifemap
            A Lifemap visualization object.

        Examples
        --------
        >>> import polars as pl
        >>> from pylifemap import Lifemap
        >>> d = pl.DataFrame(
        ...     {
        ...         "taxid": [
        ...             9685,
        ...             9615,
        ...             9994,
        ...             2467430,
        ...             2514524,
        ...             2038938,
        ...             1021470,
        ...             1415565,
        ...             1928562,
        ...             1397240,
        ...             230741,
        ...         ],
        ...         "dest_taxid": [
        ...             9615,
        ...             1415565,
        ...             2467430,
        ...             9994,
        ...             9685,
        ...             2514524,
        ...             2038938,
        ...             1397240,
        ...             1021470,
        ...             1928562,
        ...             230741,
        ...         ],
        ...         "relation": ["A", "A", "B", "C", "A", "A", "B", "C", "B", "A", "A"],
        ...     }
        ... )
        Lifemap(d).layer_arcs(taxid_dest_col="dest_taxid", color="relation", arrow=True).show()
        """
        layer_id, options, df = self._process_layer_options(locals())

        lazy_mode_values = ["self", "parent"]
        if options["lazy_mode"] not in lazy_mode_values:
            msg = f"lazy_mode must be one of {lazy_mode_values}"
            raise ValueError(msg)

        if options["hover"] is None:
            options["hover"] = len(df) < MAX_HOVER_DATA_LEN
        options["lazy"] = init_lazy(lazy=options["lazy"], df_len=len(df))

        layer = {"id": layer_id, "layer": "arcs", "options": options}
        self._layers.append(layer)

        data_columns = [
            options[k]
            for k in ("width", "color")
            if isinstance(options[k], str) and not is_hex_color(options[k])
        ]
        if popup_col is not None:
            data_columns.append(options["popup_col"])
        d = df.arcs_data(options, data_columns, lazy_mode=lazy_mode)
        self._layers_data[layer_id] = d

        # Compute color range
        key = options["color"]
        if key in data_columns:
            min_value = d.get_column(key).min()
            max_value = d.get_column(key).max()
            if key in self._color_ranges:
                self._color_ranges[key]["min"] = min(self._color_ranges[key]["min"], min_value)  # type: ignore
                self._color_ranges[key]["max"] = max(self._color_ranges[key]["max"], max_value)  # type: ignore
            else:
                self._color_ranges[key] = {"min": min_value, "max": max_value}

        return self
