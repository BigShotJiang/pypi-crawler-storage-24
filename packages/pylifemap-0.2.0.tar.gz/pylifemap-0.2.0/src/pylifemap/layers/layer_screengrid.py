import pandas as pd
import polars as pl

from pylifemap.abc import LifemapABC


class ScreengridMixin:
    def layer_screengrid(
        self: LifemapABC,
        data: pl.DataFrame | pd.DataFrame | None = None,
        *,
        taxid_col: str = "taxid",
        cell_size: int = 30,
        extruded: bool = False,
        opacity: float = 0.5,
    ) -> LifemapABC:
        """
        Add a screengrid layer.

        This layer is used to display observations distribution. It should be noted
        that the visualization is highly sensitive to the zoom level and the map extent.

        Parameters
        ----------
        data : pl.DataFrame | pd.DataFrame | None, optional
            Layer data. If not provided, use the base widget data.
        taxid_col : str, optional
            If `data` is provided, name of the `data` column with taxonomy ids. By default `'taxid'`.
        cell_size : int, optional
            Screen grid cell size, in pixels. By default 30.
        extruded : bool, optionals
            If `True`, show the grid as extruded. By default `False`.
        opacity : float, optional
            Screengrid opacity as a floating point number between 0 and 1.
            By default 0.5.

        Returns
        -------
        Lifemap
            A Lifemap visualization object.

        Examples
        --------
        >>> import polars as pl
        >>> from pylifemap import Lifemap
        >>> d = pl.DataFrame(
        ...     {
        ...         "taxid": [
        ...             9685,
        ...             9615,
        ...             9994,
        ...             2467430,
        ...             2514524,
        ...             2038938,
        ...             1021470,
        ...             1415565,
        ...             1928562,
        ...             1397240,
        ...             230741,
        ...         ],
        ...     }
        ... )
        >>> Lifemap(d).layer_screengrid().show()

        """
        layer_id, options, df = self._process_layer_options(locals())
        layer = {"id": layer_id, "layer": "screengrid", "options": options}
        self._layers.append(layer)
        self._layers_data[layer_id] = df.points_data(options)
        self._has_deck_layers = True
        return self
