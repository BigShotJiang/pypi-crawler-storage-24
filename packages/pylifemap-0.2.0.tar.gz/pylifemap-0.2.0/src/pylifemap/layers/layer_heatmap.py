import pandas as pd
import polars as pl

from pylifemap.abc import LifemapABC


class HeatmapMixin:
    def layer_heatmap(
        self: LifemapABC,
        data: pl.DataFrame | pd.DataFrame | None = None,
        *,
        taxid_col: str = "taxid",
        radius: float = 5.0,
        blur: float = 5.0,
        opacity: float = 1.0,
        gradient: tuple = (
            "#4675ed",
            "#39a2fc",
            "#1bcfd4",
            "#24eca6",
            "#61fc6c",
            "#a4fc3b",
            "#d1e834",
            "#f3363a",
        ),
    ) -> LifemapABC:
        """
        Add an heatmap layer.

        This layer is used to display observations distribution.

        Parameters
        ----------
        data : pl.DataFrame | pd.DataFrame | None, optional
            Layer data. If not provided, use the base widget data.
        taxid_col : str, optional
            If `data` is provided, name of the `data` column with taxonomy ids. By default `'taxid'`.
        radius : float
            Heatmap radius. By default 5.0.
        blur : float
            Heatmap blur. By default 5.0.
        opacity : float
            Heatmap opacity as a floating number between 0 and 1. By default 1.0.
        gradient: tuple
            Tuple of CSS colors to define the heatmap gradient. By default gradient
            inspired from the 'turbo' color ramp.

        Returns
        -------
        Lifemap
            A Lifemap visualization object.

        Examples
        --------
        >>> import polars as pl
        >>> from pylifemap import Lifemap
        >>> d = pl.DataFrame(
        ...     {
        ...         "taxid": [
        ...             9685,
        ...             9615,
        ...             9994,
        ...             2467430,
        ...             2514524,
        ...             2038938,
        ...             1021470,
        ...             1415565,
        ...             1928562,
        ...             1397240,
        ...             230741,
        ...         ],
        ...     }
        ... )
        >>> Lifemap(d).layer_heatmap().show()

        """

        layer_id, options, df = self._process_layer_options(locals())
        layer = {"id": layer_id, "layer": "heatmap", "options": options}
        self._layers.append(layer)
        self._layers_data[layer_id] = df.points_data(options)
        return self
