"""Allow running as python -m tcptune."""

from .cli import main

if __name__ == "__main__":
    main()
