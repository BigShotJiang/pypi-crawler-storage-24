"""Linux platform and privilege checks."""

import os
import sys


def is_linux() -> bool:
    return sys.platform == "linux"


def require_linux() -> None:
    if not is_linux():
        print("This tool is for Linux only. Exiting.", file=sys.stderr)
        sys.exit(1)


def is_root() -> bool:
    return os.geteuid() == 0


def require_root(message: str = "This operation requires root. Run with sudo.") -> None:
    if not is_root():
        print(message, file=sys.stderr)
        sys.exit(1)
