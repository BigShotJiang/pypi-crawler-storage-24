"""Read and write Linux sysctl via /proc/sys."""

import json
from pathlib import Path

PROC_SYS = Path("/proc/sys")


class SysctlError(Exception):
    pass


def _sysctl_path(key: str) -> Path:
    return PROC_SYS / key.replace(".", "/")


def read(key: str) -> str:
    path = _sysctl_path(key)
    if not path.exists():
        raise SysctlError(f"Key does not exist: {key}")
    try:
        return path.read_text().strip()
    except OSError as e:
        raise SysctlError(f"Cannot read {key}: {e}") from e


def read_multi(key: str) -> list[str]:
    raw = read(key)
    return raw.split()


def write(key: str, value: str | int | list[int]) -> None:
    path = _sysctl_path(key)
    if not path.exists():
        raise SysctlError(f"Key does not exist: {key}")
    if isinstance(value, list):
        for v in value:
            if not isinstance(v, int) or v < 0:
                raise SysctlError(f"Invalid value for {key}: list must be non-negative integers")
        value_str = "\t".join(str(v) for v in value)
    else:
        value_str = str(value)
    try:
        path.write_text(value_str + "\n")
    except PermissionError as e:
        raise SysctlError(f"Permission denied writing {key}. Run as root.") from e
    except OSError as e:
        raise SysctlError(f"Failed to set {key}: {e}") from e


def get(key: str) -> str | list[str]:
    raw = read(key).strip()
    if "\t" in raw or (raw and raw.split()[0].isdigit() and len(raw.split()) > 1):
        return raw.split()
    return raw


def exists(key: str) -> bool:
    return _sysctl_path(key).exists()


def bbr_available() -> bool:
    key = "net.ipv4.tcp_available_congestion_control"
    if not exists(key):
        return False
    try:
        raw = read(key)
    except SysctlError:
        return False
    return "bbr" in raw.split()


def backup_current(keys: list[str]) -> dict[str, str | list[str]]:
    result: dict[str, str | list[str]] = {}
    for k in keys:
        if exists(k):
            try:
                result[k] = get(k)
            except SysctlError:
                pass
    return result


def load_backup_file(path: Path) -> dict[str, str]:
    data = json.loads(path.read_text())
    if not isinstance(data, dict):
        raise ValueError("Backup file must be a JSON object.")
    out: dict[str, str] = {}
    for k, v in data.items():
        if not isinstance(k, str):
            continue
        if isinstance(v, list):
            out[k] = " ".join(str(x) for x in v)
        elif isinstance(v, str):
            out[k] = v
        else:
            out[k] = str(v)
    return out


def parse_backup_value(s: str) -> str | int | list[int]:
    s = s.strip()
    parts = s.split()
    if len(parts) > 1 and all(p.isdigit() for p in parts):
        return [int(p) for p in parts]
    if s.isdigit():
        return int(s)
    return s


def apply_backup(data: dict[str, str]) -> list[tuple[str, str]]:
    failures: list[tuple[str, str]] = []
    for key, s in data.items():
        if not key or not isinstance(s, str):
            continue
        try:
            val = parse_backup_value(s)
            if exists(key):
                write(key, val)
        except SysctlError as e:
            failures.append((key, str(e)))
    return failures
