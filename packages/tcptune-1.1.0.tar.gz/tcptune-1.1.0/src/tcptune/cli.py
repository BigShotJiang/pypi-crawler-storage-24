"""CLI entrypoint and subcommands."""

import json
import sys
from pathlib import Path

import click
from rich.console import Console
from rich.table import Table

from . import __version__
from ._linux import require_linux, require_root
from .bdp import parse_bandwidth, parse_rtt_ms, recommend_buffers
from .detect import detect
from .info import gather_info
from .presets import PRESET_DESCRIPTIONS, TUNE_KEYS, get_preset, get_preset_names
from .report import gather_report_data, write_html, write_json
from .sysctl import (
    SysctlError,
    apply_backup,
    backup_current,
    bbr_available,
    exists,
    get,
    load_backup_file,
    write,
)
from .sysctl_d import render_dropin
from .viz import run_viz

console = Console()

BBR_CC_KEY = "net.ipv4.tcp_congestion_control"


def _linux_check() -> None:
    require_linux()


def _format_val(v: str | int | list[str] | list[int]) -> str:
    if isinstance(v, list):
        return " ".join(str(x) for x in v)
    return str(v)


def _keys_after_bbr_guard(preset_data: dict, keys_existing: list[str]) -> tuple[list[str], bool]:
    keys = list(keys_existing)
    skipped_bbr = False
    if BBR_CC_KEY in keys and str(preset_data.get(BBR_CC_KEY)) == "bbr" and not bbr_available():
        keys = [k for k in keys if k != BBR_CC_KEY]
        skipped_bbr = True
    return keys, skipped_bbr


@click.group()
@click.version_option(version=__version__, prog_name="tcptune")
def main() -> None:
    """Tune Linux TCP/sysctl, detect bottlenecks, adjust buffers, visualize congestion."""
    _linux_check()


@main.command()
@click.option(
    "--preset",
    "-p",
    type=click.Choice(get_preset_names()),
    required=True,
    help="Preset to apply",
)
@click.option("--dry-run", is_flag=True, help="Only print what would be set (two columns)")
@click.option(
    "--diff",
    is_flag=True,
    help="Show current vs preset value per key (no root; exit without applying)",
)
@click.option(
    "--write-file",
    "write_file_path",
    type=click.Path(path_type=Path),
    default=None,
    help="Write sysctl.d-style drop-in to PATH (does not apply live sysctl)",
)
@click.option(
    "--backup",
    "backup_path",
    type=click.Path(path_type=Path),
    default=None,
    help="Save current values to file before applying",
)
def tune(
    preset: str,
    dry_run: bool,
    diff: bool,
    write_file_path: Path | None,
    backup_path: Path | None,
) -> None:
    """Apply a named sysctl preset."""
    try:
        preset_data = get_preset(preset)
    except KeyError as e:
        console.print(f"[red]{e}[/red]")
        sys.exit(1)

    keys_existing = [k for k in preset_data if exists(k)]
    skipped_missing = [k for k in preset_data if k not in keys_existing]
    keys_to_apply, skipped_bbr = _keys_after_bbr_guard(preset_data, keys_existing)

    for k in skipped_missing:
        console.print(f"[yellow]Skipped (not present): {k}[/yellow]")
    if skipped_bbr:
        console.print(
            "[yellow]BBR not listed in net.ipv4.tcp_available_congestion_control; "
            f"skipping {BBR_CC_KEY}[/yellow]"
        )

    preview_only = diff or dry_run or write_file_path is not None
    if not preview_only:
        require_root()

    if diff:
        table = Table(title=f"Preset [bold]{preset}[/bold]: current → new")
        table.add_column("Key", style="cyan")
        table.add_column("Current", style="dim")
        table.add_column("New", style="green")
        for k in keys_existing:
            try:
                cur = _format_val(get(k))
            except SysctlError:
                cur = "(read error)"
            new_v = preset_data[k]
            new_s = _format_val(new_v)
            if k == BBR_CC_KEY and str(new_v) == "bbr" and not bbr_available():
                new_s = f"{new_s} [dim](would be skipped: no BBR)[/dim]"
            table.add_row(k, cur, new_s)
        console.print(table)

    elif dry_run:
        table = Table(title=f"Would apply preset: {preset}")
        table.add_column("Key", style="cyan")
        table.add_column("Value", style="green")
        for k in keys_to_apply:
            v = preset_data[k]
            table.add_row(k, _format_val(v))
        console.print(table)

    if write_file_path is not None:
        lines = render_dropin(preset, preset_data, keys_to_apply)
        try:
            write_file_path.parent.mkdir(parents=True, exist_ok=True)
            write_file_path.write_text(lines, encoding="utf-8")
        except OSError as e:
            console.print(f"[red]Could not write {write_file_path}: {e}[/red]")
            sys.exit(1)
        console.print(f"[green]Wrote drop-in to {write_file_path}[/green]")

    if diff or dry_run or write_file_path is not None:
        return

    if backup_path:
        backup = backup_current(TUNE_KEYS)
        data = {k: (v if isinstance(v, str) else " ".join(map(str, v))) for k, v in backup.items()}
        backup_path.write_text(json.dumps(data, indent=2))
        console.print(f"[green]Backed up to {backup_path}[/green]")

    failed = []
    for k in keys_to_apply:
        v = preset_data[k]
        try:
            write(k, v)
            console.print(f"  [green]Set {k}[/green]")
        except SysctlError as e:
            console.print(f"  [red]{k}: {e}[/red]")
            failed.append(k)

    if failed:
        console.print(f"[red]Preset applied with {len(failed)} failure(s).[/red]")
        sys.exit(1)
    console.print(f"[green]Preset [bold]{preset}[/bold] applied.[/green]")


@main.command()
@click.option("--from-file", "backup_path", type=click.Path(path_type=Path), required=True)
@click.option("--dry-run", is_flag=True, help="Only print what would be restored")
def restore(backup_path: Path, dry_run: bool) -> None:
    """Restore sysctl from a backup file (from tune --backup)."""
    if not backup_path.exists():
        console.print(f"[red]File not found: {backup_path}[/red]")
        sys.exit(1)
    if not dry_run:
        require_root()
    try:
        data = load_backup_file(backup_path)
    except (json.JSONDecodeError, ValueError) as e:
        console.print(f"[red]Invalid backup file: {e}[/red]")
        sys.exit(1)
    if not data:
        console.print("[yellow]Backup file is empty.[/yellow]")
        return
    if dry_run:
        table = Table(title="Would restore")
        table.add_column("Key", style="cyan")
        table.add_column("Value", style="green")
        for k, v in sorted(data.items()):
            table.add_row(k, v)
        console.print(table)
        return
    failures = apply_backup(data)
    if failures:
        for k, err in failures:
            console.print(f"  [red]{k}: {err}[/red]")
        console.print(f"[red]Restore completed with {len(failures)} failure(s).[/red]")
        sys.exit(1)
    console.print("[green]Restore complete.[/green]")


@main.command("detect")
@click.option("--json-output", "json_out", is_flag=True, help="Output as JSON")
def detect_cmd(json_out: bool) -> None:
    """Detect bottlenecks (retransmissions, interface drops)."""
    _linux_check()
    result = detect()
    if json_out:
        out = {
            "retrans_rate": result.retrans_rate,
            "out_segs": result.out_segs,
            "retrans_segs": result.retrans_segs,
            "curr_estab": result.curr_estab,
            "findings": [
                {"severity": f.severity, "message": f.message, "recommendation": f.recommendation}
                for f in result.findings
            ],
        }
        console.print(json.dumps(out, indent=2))
        if any(f.severity == "critical" for f in result.findings):
            sys.exit(1)
        return
    if result.retrans_rate is not None:
        console.print(f"Retransmission rate: [bold]{result.retrans_rate:.2%}[/bold]")
        console.print(f"Connections (CurrEstab): {result.curr_estab}")
    if not result.findings:
        console.print("[green]No issues detected.[/green]")
        return
    for f in result.findings:
        style = (
            "red" if f.severity == "critical" else "yellow" if f.severity == "warning" else "blue"
        )
        console.print(f"[{style}]{f.severity.upper()}:[/{style}] {f.message}")
        console.print(f"  [dim]→ {f.recommendation}[/dim]")
    if any(f.severity == "critical" for f in result.findings):
        sys.exit(1)


@main.command()
@click.option("--bandwidth", "-b", required=True, help="e.g. 1Gbps, 100Mbps")
@click.option("--rtt", "-r", required=True, help="RTT in ms, e.g. 2 or 2ms")
@click.option("--apply", "do_apply", is_flag=True, help="Apply recommended values (requires root)")
@click.option("--dry-run", is_flag=True, help="Show what would be set")
@click.option(
    "--no-compare",
    is_flag=True,
    help="Do not show current sysctl vs recommended",
)
def buffers(
    bandwidth: str,
    rtt: str,
    do_apply: bool,
    dry_run: bool,
    no_compare: bool,
) -> None:
    """Compute BDP and recommend buffer sizes; optionally apply them."""
    _linux_check()
    try:
        bps = parse_bandwidth(bandwidth)
        rtt_ms = parse_rtt_ms(rtt)
    except ValueError as e:
        console.print(f"[red]{e}[/red]")
        sys.exit(1)
    try:
        rec = recommend_buffers(bps, rtt_ms)
    except ValueError as e:
        console.print(f"[red]{e}[/red]")
        sys.exit(1)
    console.print(f"BDP: [bold]{rec.bdp_bytes / 1024:.1f} KiB[/bold]")
    console.print(
        f"Recommended tcp_rmem: {rec.tcp_rmem_min} {rec.tcp_rmem_default} {rec.tcp_rmem_max}"
    )
    console.print(
        f"Recommended tcp_wmem: {rec.tcp_wmem_min} {rec.tcp_wmem_default} {rec.tcp_wmem_max}"
    )
    console.print(f"Recommended net.core.rmem_max: {rec.core_rmem_max}")
    console.print(f"Recommended net.core.wmem_max: {rec.core_wmem_max}")

    compare_keys = [
        ("net.ipv4.tcp_rmem", [rec.tcp_rmem_min, rec.tcp_rmem_default, rec.tcp_rmem_max]),
        ("net.ipv4.tcp_wmem", [rec.tcp_wmem_min, rec.tcp_wmem_default, rec.tcp_wmem_max]),
        ("net.core.rmem_max", rec.core_rmem_max),
        ("net.core.wmem_max", rec.core_wmem_max),
    ]
    if not no_compare:
        table = Table(title="Current vs recommended")
        table.add_column("Key", style="cyan")
        table.add_column("Current", style="dim")
        table.add_column("Recommended", style="green")
        for key, rec_val in compare_keys:
            rec_s = _format_val(rec_val)
            if exists(key):
                try:
                    cur_s = _format_val(get(key))
                except SysctlError:
                    cur_s = "(read error)"
            else:
                cur_s = "(missing)"
            table.add_row(key, cur_s, rec_s)
        console.print(table)

    if do_apply or dry_run:
        if do_apply:
            require_root()
        sysctl_ops = [
            ("net.core.rmem_max", rec.core_rmem_max),
            ("net.core.wmem_max", rec.core_wmem_max),
            ("net.ipv4.tcp_rmem", [rec.tcp_rmem_min, rec.tcp_rmem_default, rec.tcp_rmem_max]),
            ("net.ipv4.tcp_wmem", [rec.tcp_wmem_min, rec.tcp_wmem_default, rec.tcp_wmem_max]),
        ]
        failed = []
        for key, val in sysctl_ops:
            if dry_run:
                console.print(f"  [dim]Would set {key} = {val}[/dim]")
            else:
                if exists(key):
                    try:
                        write(key, val)
                        console.print(f"  [green]Set {key}[/green]")
                    except SysctlError as e:
                        console.print(f"  [red]{key}: {e}[/red]")
                        failed.append(key)
        if failed:
            sys.exit(1)


@main.command("presets")
def list_presets() -> None:
    """List available tune presets and short descriptions."""
    _linux_check()
    for name in get_preset_names():
        desc = PRESET_DESCRIPTIONS.get(name, "")
        console.print(f"[bold]{name}[/bold]  {desc}")


@main.command()
def info() -> None:
    """Show current sysctl and kernel version."""
    _linux_check()
    data = gather_info()
    console.print(f"Kernel: [bold]{data['kernel']}[/bold]")
    table = Table(title="Sysctl")
    table.add_column("Key", style="cyan")
    table.add_column("Value", style="green")
    for k, v in sorted(data["sysctl"].items()):
        table.add_row(k, str(v) if not isinstance(v, list) else " ".join(map(str, v)))
    console.print(table)


@main.command()
@click.option("--duration", "-d", type=int, default=30, help="Seconds to run")
@click.option("--refresh", "-r", type=float, default=1.0, help="Refresh interval (seconds)")
def viz(duration: int, refresh: float) -> None:
    """Live view of retransmission rate and connection count."""
    _linux_check()
    run_viz(duration_sec=duration, refresh_sec=refresh)


@main.command()
@click.option("--json", "out_json", type=click.Path(path_type=Path), default=None)
@click.option("--html", "out_html", type=click.Path(path_type=Path), default=None)
def report(out_json: Path | None, out_html: Path | None) -> None:
    """Export sysctl and TCP stats (JSON and/or HTML)."""
    _linux_check()
    try:
        data = gather_report_data()
    except Exception as e:
        console.print(f"[red]{e}[/red]")
        sys.exit(1)
    if out_json:
        write_json(data, out_json)
        console.print(f"[green]Wrote JSON to {out_json}[/green]")
    if out_html:
        write_html(data, out_html)
        console.print(f"[green]Wrote HTML to {out_html}[/green]")
    if not out_json and not out_html:
        console.print(json.dumps({k: v for k, v in data.items() if k == "sysctl"}, indent=2))


if __name__ == "__main__":
    main()
