"""Parse /proc/net/snmp and /proc/net/netstat."""

from pathlib import Path

PROC_NET = Path("/proc/net")


def _parse_key_value_proc(filepath: Path) -> dict[str, dict[str, int]]:
    if not filepath.exists():
        return {}
    try:
        text = filepath.read_text()
    except OSError:
        return {}
    result: dict[str, dict[str, int]] = {}
    current_name: str | None = None
    current_keys: list[str] = []
    for line in text.splitlines():
        if not line.strip():
            continue
        parts = line.split()
        if not parts:
            continue
        name = parts[0].rstrip(":")
        if name and name[0].isupper() and current_name != name:
            current_name = name
            current_keys = parts[1:]
            continue
        if current_keys and len(parts) >= len(current_keys) + 1:
            values = parts[1 : 1 + len(current_keys)]
            section: dict[str, int] = {}
            for k, v in zip(current_keys, values):
                try:
                    section[k] = int(v)
                except ValueError:
                    section[k] = 0
            result[current_name] = section
            current_name = None
            current_keys = []
    return result


def read_snmp() -> dict[str, dict[str, int]]:
    return _parse_key_value_proc(PROC_NET / "snmp")


def read_netstat() -> dict[str, dict[str, int]]:
    return _parse_key_value_proc(PROC_NET / "netstat")


def get_tcp_stats() -> dict[str, int]:
    try:
        data = read_snmp()
        return data.get("Tcp", {})
    except Exception:
        return {}
