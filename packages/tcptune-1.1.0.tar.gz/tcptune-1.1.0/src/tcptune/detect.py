"""Bottleneck detection from procfs and interface stats."""

from dataclasses import dataclass, field
from pathlib import Path

from .procfs import get_tcp_stats

RETRANS_THRESHOLD = 0.05
RETRANS_HIGH = 0.10


@dataclass
class Finding:
    severity: str
    message: str
    recommendation: str


@dataclass
class DetectionResult:
    findings: list[Finding] = field(default_factory=list)
    retrans_rate: float | None = None
    out_segs: int = 0
    retrans_segs: int = 0
    curr_estab: int = 0


def detect() -> DetectionResult:
    result = DetectionResult()
    tcp = get_tcp_stats()
    if not tcp:
        return result

    out_segs = tcp.get("OutSegs", 0)
    retrans = tcp.get("RetransSegs", 0)
    result.out_segs = out_segs
    result.retrans_segs = retrans
    result.curr_estab = tcp.get("CurrEstab", 0)

    if out_segs > 0:
        result.retrans_rate = retrans / out_segs
        if result.retrans_rate >= RETRANS_HIGH:
            result.findings.append(
                Finding(
                    severity="critical",
                    message=(
                        f"High retransmission rate: {result.retrans_rate:.1%} "
                        f"({retrans} / {out_segs} segments)"
                    ),
                    recommendation=(
                        "Check link quality, congestion, and buffer sizes. "
                        "Consider 'tcptune buffers' or a throughput preset."
                    ),
                )
            )
        elif result.retrans_rate >= RETRANS_THRESHOLD:
            result.findings.append(
                Finding(
                    severity="warning",
                    message=f"Elevated retransmission rate: {result.retrans_rate:.1%}",
                    recommendation=(
                        "Monitor with 'tcptune viz'. "
                        "Consider tuning buffers if on high-BDP links."
                    ),
                )
            )

    sys_net = Path("/sys/class/net")
    if sys_net.exists():
        for iface in sys_net.iterdir():
            if iface.name == "lo":
                continue
            stats = iface / "statistics"
            if not stats.exists():
                continue
            rx_drop = stats / "rx_dropped"
            tx_drop = stats / "tx_dropped"
            try:
                rxd = int(rx_drop.read_text()) if rx_drop.exists() else 0
                txd = int(tx_drop.read_text()) if tx_drop.exists() else 0
                if rxd > 1000 or txd > 1000:
                    result.findings.append(
                        Finding(
                            severity="warning",
                            message=f"Interface {iface.name}: rx_dropped={rxd}, tx_dropped={txd}",
                            recommendation=(
                                "Increase net.core.netdev_max_backlog or check driver/queue."
                            ),
                        )
                    )
            except (ValueError, OSError):
                pass

    return result
