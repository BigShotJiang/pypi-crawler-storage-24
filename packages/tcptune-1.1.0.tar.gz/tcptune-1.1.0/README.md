# TcpTune

<div align="center">

[![CI](https://github.com/muxover/tcptune/actions/workflows/ci.yml/badge.svg)](https://github.com/muxover/tcptune/actions/workflows/ci.yml)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

**Tune Linux TCP/sysctl, detect bottlenecks, adjust buffers.**

</div>

---

TcpTune is a Linux-only CLI for tuning TCP and related sysctl parameters, detecting retransmission and interface drop issues, computing BDP-based buffer recommendations, and viewing live TCP stats. Intended for system administrators and anyone optimizing network performance on Linux.

## Features

- Apply named presets (throughput, low-latency, wan, conservative) to sysctl; skip BBR if the kernel does not expose it
- **`tune --diff`** to compare live sysctl to a preset; **`tune --write-file`** for a sysctl.d drop-in without live apply
- **`presets`** lists preset names and short descriptions
- Backup current values before applying; restore from a backup file
- Detect bottlenecks (retransmission rate, interface drops); **critical** findings yield exit code 1
- Recommend and optionally apply buffer sizes from bandwidth and RTT (BDP), with current vs recommended table
- Live view of retransmission rate and connection count
- Export sysctl and TCP stats to JSON or HTML

## Installation

```bash
pip install tcptune
```

From source:

```bash
git clone https://github.com/muxover/tcptune.git
cd tcptune
pip install -e .
```

Requires Python 3.10+ and Linux. Root is required only for applying presets or buffer values.

## Commands

| Command | Description |
|---------|-------------|
| `tcptune tune -p PRESET` | Apply a preset (`--dry-run`, `--diff`, `--write-file PATH`, `--backup PATH`) |
| `tcptune presets` | List presets and short descriptions |
| `tcptune restore --from-file PATH` | Restore sysctl from a backup JSON file |
| `tcptune detect` | Show retransmission rate and findings; exit 1 on **critical** |
| `tcptune buffers -b BANDWIDTH -r RTT` | BDP + recommendations + current vs recommended (`--no-compare` to hide) |
| `tcptune info` | Show current sysctl and kernel version |
| `tcptune viz` | Live view of retrans rate and connections |
| `tcptune report --json PATH` / `--html PATH` | Export snapshot to JSON or HTML |

## Quick Start

```bash
# See current settings
tcptune info

# See what would be applied (no root)
tcptune tune -p throughput --dry-run

# Compare live values to a preset (no root)
tcptune tune -p throughput --diff

# Write a drop-in file for review / sysctl --system (no live apply)
tcptune tune -p throughput --write-file ./99-tcptune.conf

# List presets
tcptune presets

# Apply a preset (root), backing up first
sudo tcptune tune -p throughput --backup ./backup.json

# Restore if needed
sudo tcptune restore --from-file ./backup.json

# Check for issues
tcptune detect
```

## Project Layout

```
tcptune/
  src/tcptune/     # CLI and core logic
  tests/           # Unit tests
  pyproject.toml
```

## Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md).

## License

Licensed under [MIT](LICENSE).

## Links

- Repository: https://github.com/muxover/tcptune
- Issues: https://github.com/muxover/tcptune/issues
- Changelog: [CHANGELOG.md](CHANGELOG.md)

---

<p align="center">Made with ❤️ by Jax (@muxover)</p>
