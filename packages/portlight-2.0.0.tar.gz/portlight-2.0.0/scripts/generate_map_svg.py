#!/usr/bin/env python3
"""Generate an SVG world map from Portlight port and route data.

Usage:
    python scripts/generate_map_svg.py [--output docs/world-map.svg]

Reads port coordinates and route connections from the game data and
produces a maritime-styled SVG atlas of The Known World.
"""

from __future__ import annotations

import argparse
import math
import sys
from pathlib import Path
from xml.etree.ElementTree import Element, SubElement, tostring

# Add the src directory to the path so we can import game data
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))

from portlight.content.ports import PORTS  # noqa: E402
from portlight.content.routes import ROUTES  # noqa: E402
from portlight.engine.models import PortFeature  # noqa: E402

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

# SVG canvas
CANVAS_W = 1200
CANVAS_H = 800
PADDING = 80

# Game grid
GAME_W = 50
GAME_H = 36

# Region colors (matching theme.py but as hex)
REGION_COLORS = {
    "Mediterranean": "#3b82f6",   # blue
    "North Atlantic": "#06b6d4",  # cyan
    "West Africa": "#eab308",     # yellow
    "East Indies": "#ef4444",     # red
    "South Seas": "#22c55e",      # green
}

REGION_BG = {
    "Mediterranean": "#3b82f610",
    "North Atlantic": "#06b6d410",
    "West Africa": "#eab30810",
    "East Indies": "#ef444410",
    "South Seas": "#22c55e10",
}

# Route tier styles
ROUTE_STYLES = {
    "sloop":      {"stroke": "#475569", "stroke-width": "1",   "stroke-dasharray": "4,4"},
    "brigantine": {"stroke": "#64748b", "stroke-width": "1.5", "stroke-dasharray": ""},
    "galleon":    {"stroke": "#eab308", "stroke-width": "2",   "stroke-dasharray": ""},
    "man_of_war": {"stroke": "#ef4444", "stroke-width": "2.5", "stroke-dasharray": ""},
}

# Feature icons (SVG text)
FEATURE_LABELS = {
    PortFeature.SHIPYARD: "\u2693",      # ⚓
    PortFeature.BLACK_MARKET: "\u2620",  # ☠
    PortFeature.SAFE_HARBOR: "\u2604",   # ☄
}


def game_to_svg(gx: int, gy: int) -> tuple[float, float]:
    """Convert game coordinates to SVG pixel positions."""
    sx = PADDING + (gx / GAME_W) * (CANVAS_W - 2 * PADDING)
    sy = PADDING + (gy / GAME_H) * (CANVAS_H - 2 * PADDING)
    return (sx, sy)


def build_svg() -> Element:
    """Build the complete SVG document."""
    svg = Element("svg", {
        "xmlns": "http://www.w3.org/2000/svg",
        "viewBox": f"0 0 {CANVAS_W} {CANVAS_H}",
        "width": str(CANVAS_W),
        "height": str(CANVAS_H),
    })

    # --- Background ---
    defs = SubElement(svg, "defs")

    # Ocean gradient
    grad = SubElement(defs, "radialGradient", {"id": "ocean", "cx": "50%", "cy": "50%", "r": "70%"})
    SubElement(grad, "stop", {"offset": "0%", "stop-color": "#0f1d35"})
    SubElement(grad, "stop", {"offset": "100%", "stop-color": "#0a1628"})

    # Parchment filter for title
    filt = SubElement(defs, "filter", {"id": "glow"})
    SubElement(filt, "feGaussianBlur", {"stdDeviation": "2", "result": "blur"})
    merge = SubElement(filt, "feMerge")
    SubElement(merge, "feMergeNode", {"in": "blur"})
    SubElement(merge, "feMergeNode", {"in": "SourceGraphic"})

    # Ocean background
    SubElement(svg, "rect", {
        "width": str(CANVAS_W), "height": str(CANVAS_H),
        "fill": "url(#ocean)",
    })

    # Ocean wave texture (subtle horizontal lines)
    waves = SubElement(svg, "g", {"opacity": "0.05"})
    for y in range(0, CANVAS_H, 12):
        SubElement(waves, "line", {
            "x1": "0", "y1": str(y), "x2": str(CANVAS_W), "y2": str(y),
            "stroke": "#2a9d8f", "stroke-width": "0.5",
        })

    # --- Region backgrounds (convex hull approximation) ---
    regions: dict[str, list[tuple[float, float]]] = {}
    for port in PORTS.values():
        sx, sy = game_to_svg(port.map_x, port.map_y)
        regions.setdefault(port.region, []).append((sx, sy))

    region_group = SubElement(svg, "g", {"opacity": "0.12"})
    for region_name, points in regions.items():
        if len(points) < 2:
            continue
        color = REGION_COLORS.get(region_name, "#ffffff")
        # Draw expanded ellipse around region
        cx = sum(p[0] for p in points) / len(points)
        cy = sum(p[1] for p in points) / len(points)
        max_dx = max(abs(p[0] - cx) for p in points) + 60
        max_dy = max(abs(p[1] - cy) for p in points) + 40
        SubElement(region_group, "ellipse", {
            "cx": str(cx), "cy": str(cy),
            "rx": str(max_dx), "ry": str(max_dy),
            "fill": color, "stroke": color, "stroke-width": "1",
        })

    # --- Routes ---
    route_group = SubElement(svg, "g")
    for route in ROUTES:
        if route.port_a not in PORTS or route.port_b not in PORTS:
            continue
        pa = PORTS[route.port_a]
        pb = PORTS[route.port_b]
        ax, ay = game_to_svg(pa.map_x, pa.map_y)
        bx, by = game_to_svg(pb.map_x, pb.map_y)
        style = ROUTE_STYLES.get(route.min_ship_class, ROUTE_STYLES["sloop"])
        attrs = {
            "x1": f"{ax:.1f}", "y1": f"{ay:.1f}",
            "x2": f"{bx:.1f}", "y2": f"{by:.1f}",
            "stroke": style["stroke"],
            "stroke-width": style["stroke-width"],
            "opacity": "0.6",
        }
        if style["stroke-dasharray"]:
            attrs["stroke-dasharray"] = style["stroke-dasharray"]
        SubElement(route_group, "line", attrs)

    # --- Ports ---
    port_group = SubElement(svg, "g")
    for port in PORTS.values():
        sx, sy = game_to_svg(port.map_x, port.map_y)
        color = REGION_COLORS.get(port.region, "#ffffff")

        # Port circle
        SubElement(port_group, "circle", {
            "cx": f"{sx:.1f}", "cy": f"{sy:.1f}", "r": "6",
            "fill": color, "stroke": "#ffffff", "stroke-width": "1.5",
            "filter": "url(#glow)",
        })

        # Feature icon (small, offset)
        for feat in port.features:
            if feat in FEATURE_LABELS:
                icon = SubElement(port_group, "text", {
                    "x": f"{sx + 8:.1f}", "y": f"{sy - 8:.1f}",
                    "font-size": "12", "fill": "#ffffff",
                    "text-anchor": "start", "opacity": "0.8",
                })
                icon.text = FEATURE_LABELS[feat]

        # Port name label
        # Offset right by default, left if in the right half
        text_anchor = "start"
        label_x = sx + 12
        if port.map_x > GAME_W * 0.7:
            text_anchor = "end"
            label_x = sx - 12

        label = SubElement(port_group, "text", {
            "x": f"{label_x:.1f}", "y": f"{sy + 4:.1f}",
            "font-family": "'Segoe UI', 'Helvetica Neue', sans-serif",
            "font-size": "11", "fill": color,
            "text-anchor": text_anchor,
            "font-weight": "600",
        })
        label.text = port.name

    # --- Title cartouche ---
    title_group = SubElement(svg, "g")

    # Title background
    SubElement(title_group, "rect", {
        "x": str(CANVAS_W // 2 - 180), "y": "15", "width": "360", "height": "40",
        "rx": "6", "fill": "#0a1628", "stroke": "#2a9d8f", "stroke-width": "1",
        "opacity": "0.9",
    })
    title = SubElement(title_group, "text", {
        "x": str(CANVAS_W // 2), "y": "42",
        "font-family": "'Georgia', serif",
        "font-size": "20", "fill": "#e9c46a",
        "text-anchor": "middle", "font-weight": "bold",
    })
    title.text = "The Known World \u2014 Portlight"

    # --- Legend ---
    legend_y = CANVAS_H - 55
    legend_group = SubElement(svg, "g")

    # Legend background
    SubElement(legend_group, "rect", {
        "x": "20", "y": str(legend_y - 10), "width": str(CANVAS_W - 40), "height": "50",
        "rx": "6", "fill": "#0a1628", "stroke": "#264653", "stroke-width": "1",
        "opacity": "0.9",
    })

    # Region legend
    lx = 40
    for region_name, color in REGION_COLORS.items():
        SubElement(legend_group, "circle", {
            "cx": str(lx), "cy": str(legend_y + 8), "r": "5",
            "fill": color,
        })
        t = SubElement(legend_group, "text", {
            "x": str(lx + 10), "y": str(legend_y + 12),
            "font-family": "sans-serif", "font-size": "10", "fill": "#94a3b8",
        })
        t.text = region_name
        lx += len(region_name) * 7 + 30

    # Route tier legend
    lx = 40
    for tier_name, style in ROUTE_STYLES.items():
        label_text = tier_name.replace("_", " ").title()
        attrs = {
            "x1": str(lx), "y1": str(legend_y + 28),
            "x2": str(lx + 25), "y2": str(legend_y + 28),
            "stroke": style["stroke"],
            "stroke-width": style["stroke-width"],
        }
        if style["stroke-dasharray"]:
            attrs["stroke-dasharray"] = style["stroke-dasharray"]
        SubElement(legend_group, "line", attrs)
        t = SubElement(legend_group, "text", {
            "x": str(lx + 30), "y": str(legend_y + 32),
            "font-family": "sans-serif", "font-size": "9", "fill": "#64748b",
        })
        t.text = label_text
        lx += len(label_text) * 6 + 50

    # Feature legend
    feat_items = [("\u2693 Shipyard", 820), ("\u2620 Black Market", 920), ("\u2604 Safe Harbor", 1050)]
    for text_str, fx in feat_items:
        t = SubElement(legend_group, "text", {
            "x": str(fx), "y": str(legend_y + 32),
            "font-family": "sans-serif", "font-size": "9", "fill": "#64748b",
        })
        t.text = text_str

    # --- Compass rose (simple) ---
    compass_x, compass_y = CANVAS_W - 60, 80
    compass = SubElement(svg, "g", {"opacity": "0.5"})
    # N arrow
    SubElement(compass, "line", {
        "x1": str(compass_x), "y1": str(compass_y - 25),
        "x2": str(compass_x), "y2": str(compass_y + 25),
        "stroke": "#2a9d8f", "stroke-width": "1",
    })
    SubElement(compass, "line", {
        "x1": str(compass_x - 25), "y1": str(compass_y),
        "x2": str(compass_x + 25), "y2": str(compass_y),
        "stroke": "#2a9d8f", "stroke-width": "1",
    })
    for direction, dx, dy in [("N", 0, -30), ("S", 0, 32), ("E", 30, 4), ("W", -30, 4)]:
        t = SubElement(compass, "text", {
            "x": str(compass_x + dx), "y": str(compass_y + dy),
            "font-family": "serif", "font-size": "12", "fill": "#2a9d8f",
            "text-anchor": "middle", "font-weight": "bold",
        })
        t.text = direction

    return svg


def main():
    parser = argparse.ArgumentParser(description="Generate Portlight world map SVG")
    parser.add_argument("--output", "-o", default="docs/world-map.svg",
                        help="Output SVG file path (default: docs/world-map.svg)")
    args = parser.parse_args()

    svg = build_svg()

    # Write with XML declaration
    xml_bytes = b'<?xml version="1.0" encoding="UTF-8"?>\n'
    xml_bytes += tostring(svg, encoding="unicode").encode("utf-8")

    output_path = Path(args.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_bytes(xml_bytes)
    print(f"Generated: {output_path} ({len(xml_bytes):,} bytes)")
    print(f"  {len(PORTS)} ports, {len(ROUTES)} routes across {len(REGION_COLORS)} regions")


if __name__ == "__main__":
    main()
