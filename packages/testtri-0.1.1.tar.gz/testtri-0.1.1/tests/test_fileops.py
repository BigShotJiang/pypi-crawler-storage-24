import pytest

from testtri import append_file, delete_file, read_file, write_file


def test_write_and_read_file(tmp_path):
    target = tmp_path / "hello.txt"
    write_file(str(target), "Hello, world!")
    assert read_file(str(target)) == "Hello, world!"


def test_write_overwrites_existing_file(tmp_path):
    target = tmp_path / "data.txt"
    write_file(str(target), "first")
    write_file(str(target), "second")
    assert read_file(str(target)) == "second"


def test_write_creates_parent_directories(tmp_path):
    target = tmp_path / "a" / "b" / "file.txt"
    write_file(str(target), "nested")
    assert read_file(str(target)) == "nested"


def test_append_file(tmp_path):
    target = tmp_path / "log.txt"
    append_file(str(target), "line1\n")
    append_file(str(target), "line2\n")
    assert read_file(str(target)) == "line1\nline2\n"


def test_append_creates_file_if_missing(tmp_path):
    target = tmp_path / "new.txt"
    append_file(str(target), "data")
    assert read_file(str(target)) == "data"


def test_delete_file(tmp_path):
    target = tmp_path / "todelete.txt"
    write_file(str(target), "bye")
    delete_file(str(target))
    assert not target.exists()


def test_delete_file_raises_if_missing(tmp_path):
    target = tmp_path / "ghost.txt"
    with pytest.raises(FileNotFoundError):
        delete_file(str(target))


def test_read_file_raises_if_missing(tmp_path):
    target = tmp_path / "missing.txt"
    with pytest.raises(FileNotFoundError):
        read_file(str(target))
