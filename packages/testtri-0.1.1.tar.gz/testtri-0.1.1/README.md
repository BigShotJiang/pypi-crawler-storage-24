# testTRI

[![Release and Publish to PyPI](https://github.com/TRI-IE/testTRI/actions/workflows/publish.yaml/badge.svg)](https://github.com/TRI-IE/testTRI/actions/workflows/publish.yaml)

A simple Python library for common file operations.

## Installation

```bash
pip install testtri
```

Or install locally in development mode:

```bash
pip install -e .
```

## Usage

```python
from testtri import read_file, write_file, append_file, delete_file

# Create / overwrite a file
write_file("hello.txt", "Hello, world!")

# Read a file
content = read_file("hello.txt")
print(content)  # Hello, world!

# Append to a file
append_file("hello.txt", "\nA second line.")

# Delete a file
delete_file("hello.txt")
```

## API

| Function | Description |
|---|---|
| `read_file(path)` | Read and return file contents as a string |
| `write_file(path, content)` | Create or overwrite a file with the given content |
| `append_file(path, content)` | Append content to a file (creates it if missing) |
| `delete_file(path)` | Delete a file (raises `FileNotFoundError` if missing) |

## Running Tests

```bash
pip install pytest
pytest tests/
```
