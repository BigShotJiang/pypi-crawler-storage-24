from importlib.metadata import PackageNotFoundError, version

from .fileops import append_file, delete_file, read_file, write_file

__all__ = ["read_file", "write_file", "append_file", "delete_file"]

try:
    __version__ = version("testtri")
except PackageNotFoundError:
    __version__ = "unknown"
