from pathlib import Path


def read_file(path: str) -> str:
    """Read and return the contents of a file as a string."""
    return Path(path).read_text(encoding="utf-8")


def write_file(path: str, content: str) -> None:
    """Create a new file (or overwrite an existing one) with the given content."""
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(content, encoding="utf-8")


def append_file(path: str, content: str) -> None:
    """Append content to a file. Creates the file if it does not exist."""
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open("a", encoding="utf-8") as f:
        f.write(content)


def delete_file(path: str) -> None:
    """Delete a file. Raises FileNotFoundError if the file does not exist."""
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"No such file: '{path}'")
    p.unlink()
