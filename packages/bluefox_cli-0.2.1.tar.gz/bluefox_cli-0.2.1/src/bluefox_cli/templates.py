"""Templates for generated project files.

Each function takes project_name and returns the file content as a string.
"""


def _main_py(project_name: str) -> str:
    return """from bluefox_core import BluefoxSettings, create_bluefox_app


def create_app() -> object:
    settings = BluefoxSettings()
    return create_bluefox_app(settings, welcome=True)


app = create_app()
"""


def _models_py(project_name: str) -> str:
    return """# Root-level models. For module-specific models, use items/models.py etc.
# All */models.py files are auto-discovered by bluefox-core.
"""


def _env_example(project_name: str) -> str:
    app_name = project_name.replace("_", "-")
    return f"""# Application
APP_NAME={app_name}
ENVIRONMENT=development
DEBUG=false
LOG_LEVEL=INFO
SECRET_KEY=change-me-in-production

# Database (PostgreSQL)
DATABASE_URL=postgresql://myuser:mypass@localhost:5432/{project_name}

# Redis (optional)
REDIS_URL=
"""


def _env(project_name: str) -> str:
    app_name = project_name.replace("_", "-")
    return f"""# Application
APP_NAME={app_name}
ENVIRONMENT=development
DEBUG=true
LOG_LEVEL=DEBUG
SECRET_KEY=dev-secret-key

# Database (PostgreSQL)
DATABASE_URL=postgresql://myuser:mypass@localhost:5432/{project_name}

# Redis (optional)
REDIS_URL=
"""


def _makefile(project_name: str) -> str:
    db_url = f"postgresql+asyncpg://myuser:mypass@localhost:5432/{project_name}"
    return f""".PHONY: dev dev-down run migrate migrate-make test

DB_URL = {db_url}

dev:
	docker compose -f docker-compose.yml -f docker-compose.dev.yml up --build

dev-down:
	docker compose -f docker-compose.yml -f docker-compose.dev.yml down

run:
	DATABASE_URL=$(DB_URL) uv run uvicorn main:app --reload --port 8000

migrate:
	DATABASE_URL=$(DB_URL) uv run python -m alembic upgrade head

migrate-make:
	DATABASE_URL=$(DB_URL) uv run python -m alembic revision --autogenerate -m "$(name)"

test:
	uv run pytest
"""


def _dockerfile(project_name: str) -> str:
    return """# --- Build stage ---
FROM ghcr.io/astral-sh/uv:python3.12-bookworm-slim AS builder
WORKDIR /app
COPY pyproject.toml uv.lock ./
RUN uv sync --frozen --no-dev --no-install-project
COPY . .
RUN uv sync --frozen --no-dev

# --- Runtime stage ---
FROM python:3.12-slim-bookworm
WORKDIR /app
RUN apt-get update && apt-get install -y --no-install-recommends curl && rm -rf /var/lib/apt/lists/* \\
    && groupadd --system app && useradd --system --gid app app
COPY --from=builder /app/.venv /app/.venv
COPY . .
ENV PATH="/app/.venv/bin:$PATH"
USER app
EXPOSE 8000
CMD ["uvicorn", "main:app", "--host", "0.0.0.0", "--port", "8000"]
"""


def _docker_compose(project_name: str) -> str:
    return """services:
  migrate:
    build: .
    environment:
      - DATABASE_URL=${DATABASE_URL:-}
    command: ["python", "-m", "alembic", "upgrade", "head"]
    restart: "no"
    networks:
      - dokploy-network

  app:
    build: .
    restart: unless-stopped
    ports:
      - "${APP_PORT:-8000}:8000"
    environment:
      - DATABASE_URL=${DATABASE_URL:-}
      - SECRET_KEY=${SECRET_KEY:-change-me-in-production}
    depends_on:
      migrate:
        condition: service_completed_successfully
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8000/health"]
      interval: 30s
      timeout: 5s
      start_period: 10s
      retries: 3
    networks:
      - dokploy-network

networks:
  dokploy-network:
    external: true
"""


def _docker_compose_dev(project_name: str) -> str:
    return f"""services:
  db:
    image: postgres:17-alpine
    restart: unless-stopped
    environment:
      POSTGRES_USER: myuser
      POSTGRES_PASSWORD: mypass
      POSTGRES_DB: {project_name}
    ports:
      - "5432:5432"
    volumes:
      - pgdata:/var/lib/postgresql/data
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U myuser -d {project_name}"]
      interval: 2s
      timeout: 3s
      retries: 10

  migrate:
    depends_on:
      db:
        condition: service_healthy
    environment:
      - DATABASE_URL=postgresql+asyncpg://myuser:mypass@db:5432/{project_name}
    volumes:
      - ./migrations:/app/migrations
    networks:
      - default

  app:
    environment:
      - DATABASE_URL=postgresql+asyncpg://myuser:mypass@db:5432/{project_name}
      - ENVIRONMENT=development
      - DEBUG=true
    volumes:
      - ./main.py:/app/main.py
      - ./models.py:/app/models.py
      - ./items:/app/items
      - ./migrations:/app/migrations
    command: ["uvicorn", "main:app", "--host", "0.0.0.0", "--port", "8000", "--reload"]
    networks:
      - default

networks:
  dokploy-network:
    driver: bridge

volumes:
  pgdata:
"""


def _alembic_ini(project_name: str) -> str:
    return """[alembic]
script_location = migrations
prepend_sys_path = .
# sqlalchemy.url is set via DATABASE_URL env var in migrations/env.py

[loggers]
keys = root,sqlalchemy,alembic

[handlers]
keys = console

[formatters]
keys = generic

[logger_root]
level = WARN
handlers = console
qualname =

[logger_sqlalchemy]
level = WARN
handlers =
qualname = sqlalchemy.engine

[logger_alembic]
level = INFO
handlers =
qualname = alembic

[handler_console]
class = StreamHandler
args = (sys.stderr,)
level = NOTSET
formatter = generic

[formatter_generic]
format = %(levelname)-5.5s [%(name)s] %(message)s
datefmt = %H:%M:%S
"""


def _migrations_env_py(project_name: str) -> str:
    return """from alembic import context
from bluefox_core.migrations import configure_alembic

configure_alembic(context)
"""


def _conftest_py(project_name: str) -> str:
    return """from bluefox_test import bluefox_test_setup
from bluefox_core import BluefoxBase

globals().update(bluefox_test_setup(base=BluefoxBase, app_factory="main:create_app"))
"""


def _test_health_py(project_name: str) -> str:
    return """import pytest


@pytest.mark.asyncio
async def test_health(client):
    response = await client.get("/health")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "ok"
"""


def _items_init_py(project_name: str) -> str:
    return ""


def _items_api_py(project_name: str) -> str:
    return """from fastapi import APIRouter

router = APIRouter()


@router.get("/")
async def list_items():
    return {"items": []}
"""


def _items_models_py(project_name: str) -> str:
    return """from sqlalchemy import Column, Integer, String
from bluefox_core import BluefoxBase


class Item(BluefoxBase):
    __tablename__ = "items"

    id = Column(Integer, primary_key=True)
    name = Column(String, nullable=False)
"""


def _dockerignore(project_name: str) -> str:
    return """.venv
__pycache__
*.pyc
.env
"""


def _pyproject_toml(project_name: str) -> str:
    # This is intentionally empty — uv init will create it,
    # then uv add will populate dependencies.
    # We don't write this file.
    return ""


# Map of relative paths to template functions
TEMPLATES: dict[str, callable] = {
    "main.py": _main_py,
    "models.py": _models_py,
    "items/__init__.py": _items_init_py,
    "items/api.py": _items_api_py,
    "items/models.py": _items_models_py,
    ".env.example": _env_example,
    ".env": _env,
    "Makefile": _makefile,
    "Dockerfile": _dockerfile,
    ".dockerignore": _dockerignore,
    "docker-compose.yml": _docker_compose,
    "docker-compose.dev.yml": _docker_compose_dev,
    "alembic.ini": _alembic_ini,
    "migrations/env.py": _migrations_env_py,
    "tests/conftest.py": _conftest_py,
    "tests/test_health.py": _test_health_py,
}
