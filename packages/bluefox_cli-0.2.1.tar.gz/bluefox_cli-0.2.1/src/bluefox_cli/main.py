import os
import subprocess
import sys
from pathlib import Path

import click

from bluefox_cli.templates import TEMPLATES


@click.group()
def cli():
    """Bluefox Stack CLI."""


@cli.command()
@click.argument("project_name")
def init(project_name: str):
    """Create a new Bluefox project."""
    project_dir = Path.cwd() / project_name

    if project_dir.exists():
        click.echo(f"Error: directory '{project_name}' already exists.", err=True)
        sys.exit(1)

    click.echo(f"Creating project '{project_name}'...")

    # Create directories
    project_dir.mkdir()
    (project_dir / "migrations" / "versions").mkdir(parents=True)
    (project_dir / "tests").mkdir()

    # Write all template files
    for rel_path, content_fn in TEMPLATES.items():
        file_path = project_dir / rel_path
        file_path.parent.mkdir(parents=True, exist_ok=True)
        file_path.write_text(content_fn(project_name))

    # Initialize uv project and add dependencies
    _run(["uv", "init", "--no-readme"], cwd=project_dir)
    _run(["uv", "add", "bluefox-core>=0.3.0", "alembic", "asyncpg"], cwd=project_dir)
    _run(["uv", "add", "--dev", "bluefox-test", "pytest"], cwd=project_dir)

    click.echo("")
    click.echo(f"Project '{project_name}' created successfully!")
    click.echo("")
    click.echo("Next steps:")
    click.echo(f"  cd {project_name}")
    click.echo("  make dev")


def _run(cmd: list[str], cwd: Path) -> None:
    result = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True)
    if result.returncode != 0:
        click.echo(f"Error running {' '.join(cmd)}:", err=True)
        click.echo(result.stderr, err=True)
        sys.exit(1)
