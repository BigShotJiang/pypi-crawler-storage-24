# Janet AI MCP Server

> Give AI Agents full access to your Janet.ai organization. Create tickets, manage sprints, search across projects, and more.

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)

## Quick Setup

One command installs, authenticates, and configures all detected clients automatically:

```bash
pip install janet-mcp && janet-mcp-setup
```

The wizard auto-detects and configures Claude Code, Claude Desktop, Cursor, VS Code, Windsurf, and Codex.

### Updating

```bash
janet-mcp-update
```

Or: `pip install --upgrade janet-mcp`

### Manual Setup

**1. Install**

```bash
pip install janet-mcp
```

**2. Generate an API key** in your Janet.ai dashboard → **Organization Settings** → **API Keys**.

**3. Configure your client:**

<details>
<summary>Claude Code</summary>

```bash
claude mcp add janet-ai -e JANET_API_KEY=jnt_your_key_here -- janet-mcp
```
</details>

<details>
<summary>Claude Desktop</summary>

Add to `~/Library/Application Support/Claude/claude_desktop_config.json`:
```json
{
  "mcpServers": {
    "janet-ai": {
      "command": "janet-mcp",
      "env": { "JANET_API_KEY": "jnt_your_key_here" }
    }
  }
}
```
</details>

<details>
<summary>Cursor</summary>

Add to `~/.cursor/mcp.json`:
```json
{
  "mcpServers": {
    "janet-ai": {
      "command": "janet-mcp",
      "env": { "JANET_API_KEY": "jnt_your_key_here" }
    }
  }
}
```
</details>

<details>
<summary>VS Code</summary>

Add to `.vscode/mcp.json`:
```json
{
  "servers": {
    "janet-ai": {
      "type": "stdio",
      "command": "janet-mcp",
      "env": { "JANET_API_KEY": "jnt_your_key_here" }
    }
  }
}
```
</details>

<details>
<summary>Windsurf</summary>

Add to `~/.codeium/windsurf/mcp_config.json`:
```json
{
  "servers": [
    {
      "name": "janet-ai",
      "type": "stdio",
      "command": "janet-mcp",
      "env": { "JANET_API_KEY": "jnt_your_key_here" }
    }
  ]
}
```
</details>

<details>
<summary>Codex</summary>

```bash
codex mcp add janet-ai -- janet-mcp -e JANET_API_KEY=jnt_your_key_here
```
</details>

## What You Can Do

Talk to your AI agent naturally:

- "Show me my assigned tickets in MAIN"
- "Create a bug ticket for the login redirect issue, assign it to me"
- "Move MAIN-452 to In Progress"
- "Search for tickets about authentication"
- "Add a comment to MAIN-100 saying the fix is deployed"
- "List all high-priority bugs in the current sprint"
- "Sort the To Do column by priority"
- "Break MAIN-200 into child tasks for each component"
- "Create a document called API Design with the proposed endpoint structure"
- "Update the Architecture doc with the new database schema"
- "What are the best libraries for rate limiting in Node.js?"
- "Delete MAIN-452"
- "Restore MAIN-452"

## Available Tools

| Tool | What it does |
|------|-------------|
| `get_workspace_context` | Lists your projects, statuses, and team members. Called automatically first. |
| `list_tickets` | Search and filter tickets. When filtering by a single status, returns tickets in kanban column order with position numbers. |
| `get_ticket` | Get full ticket details — description, comments, child tasks. |
| `create_ticket` | Create a ticket with title, description, status, priority, assignees, labels, sprint. |
| `update_tickets` | Batch update tickets. Change status, priority, assignees, etc. |
| `delete_tickets` | Soft-delete one or more tickets (restorable). Also deletes child tasks and sub-tasks. |
| `restore_tickets` | Restore previously deleted tickets, including their child tasks and sub-tasks. |
| `move_ticket` | Reposition tickets — top, bottom, before/after another ticket, bulk reorder, or sort. List tickets first for relative moves. |
| `manage_child_task` | Create, update, or delete child tasks. |
| `manage_sub_task` | Create, update, or delete sub-tasks on child tasks. |
| `manage_comment` | Add, edit, or delete comments. |
| `list_child_tasks` | List child tasks and sub-tasks for a ticket. |
| `list_comments` | List comments on a ticket. |
| `list_sprints` | List sprints with status and dates. |
| `manage_sprint` | Create or update sprints. |
| `manage_sprint_tickets` | Add or remove tickets from a sprint. |
| `list_sprint_tickets` | List tickets in a sprint, grouped by status column with position numbers. |
| `list_documents` | List documents in the workspace. |
| `get_document` | Get a document's full content. |
| `create_document` | Create a new document with a title and optional markdown content. |
| `update_document` | Update a document's title and/or content. |
| `web_search` | Search the web for current information — best practices, libraries, error messages, docs, news. |
| `list_api_keys` | List all saved named keys and which one is active. Call before `switch_organization` to see available names. |
| `add_api_key` | Save a named API key to your local config (e.g. `name="staging"`). Optionally activate it immediately with `switch_to=True`. |
| `switch_organization` | Switch to a previously saved named key / organization mid-session. |
| `remove_api_key` | Remove a saved named key from your local config. |
| `sign_out` | Clear the active key. Saved keys are preserved. |

### API Key Management

You can manage multiple organizations without restarting the MCP server:

```
add_api_key(name="staging", key="jnt_...", switch_to=True)
switch_organization(key_name="prod")
remove_api_key(name="staging")
sign_out()
```

`get_workspace_context` shows the active key name and last 4 characters.

### Filtering & Search

`list_tickets` supports: `assignees` (use `["me"]`), `status`, `keyword` (full-text search), `priorities`, `issue_types`, `tags`. When filtering by a single status, tickets are returned in kanban column order with numbered positions — use this before `move_ticket` for relative moves.

### Activity Log

Every MCP tool call is logged in the **MCP** page → **Calls** tab in your dashboard.

### API Key Scope

- **Org-scoped**: each key only accesses one organization
- **Auto-expiration**: keys expire after 1 year
- **Revocable**: instant revocation from the dashboard

## Requirements

- Python 3.8+
- Janet AI account ([sign up](https://janet.ai))

## Documentation

- [Janet AI](https://janet.ai) — Platform
- [Documentation](https://docs.janet.ai) — Full docs

## License

MIT License — see [LICENSE](LICENSE) for details.
