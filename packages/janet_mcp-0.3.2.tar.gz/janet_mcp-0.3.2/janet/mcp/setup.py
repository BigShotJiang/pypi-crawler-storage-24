"""janet-mcp-setup — One-command MCP setup wizard."""

import json
import os
import pathlib
import platform
import shutil
import socket
import subprocess
import sys

import httpx

from janet.utils.console import console, print_success, print_error, print_info


def _get_hostname() -> str:
    import re
    name = None
    if platform.system() == "Darwin":
        try:
            result = subprocess.run(
                ["scutil", "--get", "ComputerName"],
                capture_output=True, text=True, timeout=2,
            )
            if result.returncode == 0 and result.stdout.strip():
                name = result.stdout.strip()
        except Exception:
            pass
    if not name:
        name = socket.gethostname()
        for suffix in (".local", ".lan", ".home"):
            if name.endswith(suffix):
                name = name[: -len(suffix)]
    name = re.sub(r"[^a-zA-Z0-9\s._-]", "", name)
    return name or "MCP"


# ── Client detection ────────────────────────────────────────────────────────

def detect_clients() -> list[tuple[str, str]]:
    """Detect installed MCP-compatible clients."""
    system = platform.system()
    home = pathlib.Path.home()
    clients = []

    if shutil.which("claude"):
        clients.append(("Claude Code", "claude_code"))

    if system == "Darwin":
        p = home / "Library" / "Application Support" / "Claude"
    elif system == "Windows":
        p = pathlib.Path(os.environ.get("APPDATA", "")) / "Claude"
    else:
        p = home / ".config" / "Claude"
    if p.exists():
        clients.append(("Claude Desktop", "claude_desktop"))

    if (home / ".cursor").exists():
        clients.append(("Cursor", "cursor"))

    if shutil.which("code"):
        clients.append(("VS Code", "vscode"))

    if (home / ".codeium" / "windsurf").exists():
        clients.append(("Windsurf", "windsurf"))

    if shutil.which("codex"):
        clients.append(("Codex", "codex"))

    return clients


# ── Client configuration ────────────────────────────────────────────────────

def _merge_json(path: pathlib.Path, key: str, server_entry: dict):
    config = {}
    if path.exists():
        try:
            config = json.loads(path.read_text())
        except (json.JSONDecodeError, OSError):
            config = {}
    config.setdefault(key, {})["janet-ai"] = server_entry
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(config, indent=2) + "\n")


def configure_client(client_id: str, api_key: str) -> bool:
    """Configure a single MCP client. Returns True on success."""
    home = pathlib.Path.home()
    system = platform.system()

    server_entry = {
        "command": "janet-mcp",
        "env": {"JANET_API_KEY": api_key},
    }

    try:
        if client_id == "claude_code":
            subprocess.run(
                ["claude", "mcp", "remove", "janet-ai", "--scope", "user"],
                capture_output=True,
            )
            subprocess.run(
                ["claude", "mcp", "add", "janet-ai",
                 "-e", f"JANET_API_KEY={api_key}",
                 "--scope", "user",
                 "--", "janet-mcp"],
                check=True, capture_output=True,
            )

        elif client_id == "claude_desktop":
            if system == "Darwin":
                p = home / "Library" / "Application Support" / "Claude" / "claude_desktop_config.json"
            elif system == "Windows":
                p = pathlib.Path(os.environ.get("APPDATA", "")) / "Claude" / "claude_desktop_config.json"
            else:
                p = home / ".config" / "Claude" / "claude_desktop_config.json"
            _merge_json(p, "mcpServers", server_entry)

        elif client_id == "cursor":
            _merge_json(home / ".cursor" / "mcp.json", "mcpServers", server_entry)

        elif client_id == "vscode":
            vscode_dir = pathlib.Path.cwd() / ".vscode"
            vscode_dir.mkdir(exist_ok=True)
            _merge_json(vscode_dir / "mcp.json", "servers", {"type": "stdio", **server_entry})

        elif client_id == "windsurf":
            p = home / ".codeium" / "windsurf" / "mcp_config.json"
            config = {}
            if p.exists():
                try:
                    config = json.loads(p.read_text())
                except (json.JSONDecodeError, OSError):
                    config = {}
            servers = [s for s in config.get("servers", []) if s.get("name") != "janet-ai"]
            servers.append({"name": "janet-ai", "type": "stdio", **server_entry})
            config["servers"] = servers
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text(json.dumps(config, indent=2) + "\n")

        elif client_id == "codex":
            subprocess.run(["codex", "mcp", "remove", "janet-ai"], capture_output=True)
            subprocess.run(
                ["codex", "mcp", "add", "janet-ai", "--", "janet-mcp",
                 "-e", f"JANET_API_KEY={api_key}"],
                check=True, capture_output=True,
            )

        return True
    except Exception:
        return False


# ── API key verification ─────────────────────────────────────────────────────

def verify_api_key(api_key: str, base_url: str) -> dict | None:
    """Call /api/v1/api-keys/me and return the response, or None on failure."""
    try:
        resp = httpx.get(
            f"{base_url}/api/v1/api-keys/me",
            headers={"X-API-Key": api_key},
            timeout=10,
        )
        data = resp.json()
        if data.get("success"):
            return data
    except Exception:
        pass
    return None


# ── Main wizard ──────────────────────────────────────────────────────────────

def run_setup():
    """Run the MCP setup wizard."""
    from janet.config.models import APIConfig

    base_url = APIConfig().base_url

    console.print()
    console.print("[bold]Janet AI — MCP Setup[/bold]")
    console.print()

    # ── Step 1: Get API key ──
    console.print("  1. Go to [cyan]https://app.janet.ai[/cyan]")
    console.print("  2. Open [bold]Organization Settings → API Keys[/bold]")
    console.print("  3. Click [bold]Generate Key[/bold] and copy it")
    console.print()

    try:
        api_key = input("  Paste your API key: ").strip()
    except (KeyboardInterrupt, EOFError):
        console.print()
        sys.exit(0)

    if not api_key:
        print_error("No API key provided")
        sys.exit(1)

    if not api_key.startswith("jnt_"):
        print_error("Invalid key format — Janet API keys start with jnt_")
        sys.exit(1)

    # ── Step 2: Verify key ──
    console.print()
    print_info("Verifying API key...")
    result = verify_api_key(api_key, base_url)

    if not result:
        print_error("Could not verify API key — check the key and try again")
        sys.exit(1)

    org_name = result.get("organization", {}).get("name", "your organization")
    print_success(f"Connected to [bold]{org_name}[/bold]")

    # ── Step 3: Detect & configure clients ──
    console.print()
    clients = detect_clients()

    all_clients = [
        ("Claude Code", "claude_code"),
        ("Claude Desktop", "claude_desktop"),
        ("Cursor", "cursor"),
        ("VS Code", "vscode"),
        ("Windsurf", "windsurf"),
        ("Codex", "codex"),
    ]

    if not clients:
        console.print("[yellow]  No MCP clients detected.[/yellow]")
        console.print()
        console.print("  Add manually to Claude Code:")
        console.print(f"  [cyan]claude mcp add janet-ai -e JANET_API_KEY={api_key} -- janet-mcp[/cyan]")
        console.print()
        return

    detected_ids = {cid for _, cid in clients}

    for display_name, client_id in all_clients:
        if client_id in detected_ids:
            ok = configure_client(client_id, api_key)
            if ok:
                console.print(f"  [green]✓[/green] {display_name}")
            else:
                console.print(f"  [red]✗[/red] {display_name} — failed to configure")
        else:
            console.print(f"  [dim]○ {display_name} — not installed[/dim]")

    # ── Done ──
    console.print()
    console.print("[green]✓ Setup complete![/green]")
    console.print()
    console.print('  Try asking Claude: [cyan]"Show me my assigned tickets"[/cyan]')
    console.print()


def run_update():
    """Upgrade janet-mcp to the latest version via pip."""
    console.print("[bold]Updating janet-mcp...[/bold]")
    result = subprocess.run(
        [sys.executable, "-m", "pip", "install", "--upgrade", "janet-mcp"],
        capture_output=False,
    )
    if result.returncode == 0:
        print_success("janet-mcp updated. Restart your MCP client to pick up the new version.")
    else:
        print_error("Update failed. Try running manually: pip install --upgrade janet-mcp")


def main():
    if len(sys.argv) > 1 and sys.argv[1] == "update":
        run_update()
    else:
        run_setup()
