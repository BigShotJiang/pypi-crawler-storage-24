import sys
def main():
    print("Fuck you infinityx")
    
if __name__ == "__main__":
    main()
