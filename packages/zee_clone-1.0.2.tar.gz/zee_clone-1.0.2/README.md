# 🌐 ZEE-CLONE - Professional Website Cloning Tool

[![Python Version](https://img.shields.io/badge/python-3.7%2B-blue)](https://www.python.org/)
[![License](https://img.shields.io/badge/license-MIT-green)](LICENSE)
[![Version](https://img.shields.io/badge/version-1.0.0-orange)](https://pypi.org/project/zee-clone/)

**ZEE-CLONE** is a powerful, professional website cloning tool that downloads and reconstructs any website locally. Perfect for offline viewing, website backups, and development reference.

Created by **Zeeshan Khan (Jupiter_17z)**

## ✨ Features

- 🚀 **Complete Website Download** - Downloads HTML, CSS, JavaScript, images, and internal pages
- 📁 **Preserves Structure** - Maintains the original folder structure
- 🔗 **Smart Link Rewriting** - Updates links to work offline
- 🎯 **Internal Only** - Only clones resources from the same domain
- 📊 **Beautiful CLI** - Rich, colorful terminal interface with progress bars
- ⚡ **Fast & Parallel** - Multi-threaded downloading for speed
- 🛡️ **Error Handling** - Gracefully handles errors and continues
- 💻 **Cross-Platform** - Works on Linux, macOS, and Windows

## 📦 Installation

### Via pip (Recommended)
```bash
pip install zee-clone