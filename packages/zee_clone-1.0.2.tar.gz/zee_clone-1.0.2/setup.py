from setuptools import setup, find_packages

setup(
    name="zee-clone",
    version="1.0.2",
    author="Zeeshan Khan",
    description="Website cloning tool",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    packages=find_packages(),
    install_requires=[
        "requests",
        "beautifulsoup4",
        "rich",
        "tqdm"
    ],
    entry_points={
        "console_scripts": [
            "zee-clone=zee_clone.main:main"
        ]
    },
)
