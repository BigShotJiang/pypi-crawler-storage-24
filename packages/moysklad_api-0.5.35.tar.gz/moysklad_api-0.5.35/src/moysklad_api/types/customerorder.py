from datetime import datetime

from pydantic import Field

from .account import Account
from .agent import Agent
from .attribute import Attribute
from .contract import Contract
from .customerorder_position import CustomerOrderPosition
from .employee import Employee
from .entity import Entity
from .file import File
from .group import Group
from .meta_array import MetaArray
from .organization import Organization
from .project import Project
from .rate import Rate
from .sales_channel import SalesChannel
from .shipment_address_full import ShipmentAddressFull
from .state import State
from .store import Store


class CustomerOrder(Entity):
    account_id: str | None = Field(None, alias="accountId")
    agent: Agent | None = Field(None, alias="agent")
    agent_account: Account | None = Field(None, alias="agentAccount")
    applicable: bool | None = Field(None, alias="applicable")
    attributes: list[Attribute] | None = Field(None, alias="attributes")
    code: str | None = Field(None, alias="code")
    contract: Contract | None = Field(None, alias="contract")
    created: datetime | None = Field(None, alias="created")
    deleted: datetime | None = Field(None, alias="deleted")
    delivery_planned_moment: datetime | None = Field(None, alias="deliveryPlannedMoment")
    description: str | None = Field(None, alias="description")
    external_code: str | None = Field(None, alias="externalCode")
    files: File | None = Field(None, alias="files")
    group: Group | None = Field(None, alias="group")
    id: str | None = Field(None, alias="id")
    invoiced_sum: float | None = Field(None, alias="invoicedSum")
    moment: datetime | None = Field(None, alias="moment")
    name: str | None = Field(None, alias="name")
    organization: Organization | None = Field(None, alias="organization")
    organization_account: Account | None = Field(None, alias="organizationAccount")
    owner: Employee | None = Field(None, alias="owner")
    payed_sum: float | None = Field(None, alias="payedSum")
    positions: MetaArray[CustomerOrderPosition] | CustomerOrderPosition | None = Field(None, alias="positions")
    printed: bool | None = Field(None, alias="printed")
    project: Project | None = Field(None, alias="project")
    published: bool | None = Field(None, alias="published")
    rate: Rate | None = Field(None, alias="rate")
    reserved_sum: float | None = Field(None, alias="reservedSum")
    sales_channel: SalesChannel | None = Field(None, alias="salesChannel")
    shared: bool | None = Field(None, alias="shared")
    shipment_address: str | None = Field(None, alias="shipmentAddress")
    shipment_address_full: ShipmentAddressFull | None = Field(None, alias="shipmentAddressFull")
    shipped_sum: float | None = Field(None, alias="shippedSum")
    state: State | None = Field(None, alias="state")
    store: Store | None = Field(None, alias="store")
    sum: float | None = Field(None, alias="sum")
    sync_id: str | None = Field(None, alias="syncId")
    tax_system: str | None = Field(None, alias="taxSystem")
    updated: datetime | None = Field(None, alias="updated")
    vat_enabled: bool | None = Field(None, alias="vatEnabled")
    vat_included: bool | None = Field(None, alias="vatIncluded")
    vat_sum: float | None = Field(None, alias="vatSum")
