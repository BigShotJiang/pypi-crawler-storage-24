from ..methods.base import MSMethod
from ..types import CustomerOrder


class UpdateCustomerOrders(MSMethod[CustomerOrder]):
    __return__ = list[CustomerOrder]
    __api_method__ = "entity/customerorder"

    data: list[CustomerOrder]
