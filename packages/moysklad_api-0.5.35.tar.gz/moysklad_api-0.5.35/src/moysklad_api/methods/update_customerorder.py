from pydantic import Field

from ..methods.base import MSMethod
from ..types import CustomerOrder


class UpdateCustomerOrder(MSMethod[CustomerOrder]):
    __return__ = CustomerOrder
    __api_method__ = "entity/customerorder"

    id: str = Field(..., alias="customerorder_id")
    data: CustomerOrder
