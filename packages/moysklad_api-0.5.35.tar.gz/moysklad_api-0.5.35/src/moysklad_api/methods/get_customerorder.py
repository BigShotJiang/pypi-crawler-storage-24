from collections.abc import Sequence

from pydantic import Field

from ..filters.condition import Condition
from ..methods import MSMethod
from ..types import CustomerOrder


class GetCustomerOrder(MSMethod):
    __return__ = CustomerOrder
    __api_method__ = "entity/customerorder"

    id: str = Field(..., alias="customerorder_id")

    limit: int | None = None
    offset: int | None = None
    expand: Sequence[str] | str | None = None
    filters: Condition | Sequence[Condition] | None = None
