from collections.abc import Sequence

from ..filters.condition import Condition
from ..methods import MSMethod
from ..types import CustomerOrder, MetaArray


class GetCustomerOrders(MSMethod):
    __return__ = MetaArray[CustomerOrder]
    __api_method__ = "entity/customerorder"

    limit: int | None = None
    offset: int | None = None
    expand: Sequence[str] | str | None = None
    filters: Condition | Sequence[Condition] | None = None
