#%%
import numpy as np
import os
import matplotlib.pyplot as plt

# %%
from oma.data.datasets.numpy_dataset import NumpyDataset

# %%
dataset = NumpyDataset(
    data_dir="/auto/data2/farslan/datasets/IXI",
    stage="train",
    source_modality="T1",
    target_modality="T2",
    image_size=256,
    padding=True,
    norm=True,
)
# %%
sample = dataset[0]
print("Sample keys:", sample.keys())
print("Source shape:", sample["source"].shape)
print("Target shape:", sample["target"].shape)
# %%
# Visualize the source and target slices
fig, axes = plt.subplots(1, 2, figsize=(10, 5))
axes[0].imshow(sample["source"][0], cmap="gray")
axes[0].set_title("Source (T1)")
axes[0].axis("off")
axes[1].imshow(sample["target"][0], cmap="gray")
axes[1].set_title("Target (T2)")
axes[1].axis("off")
plt.show()
# %%
from oma.data.datamodule.datamodules import LSplitDataModule

# %%
load_engine = LSplitDataModule(
    dataset_cls=NumpyDataset,
    dataset_kwargs={
        "data_dir": "/auto/data2/farslan/datasets/IXI",
        "source_modality": "T1",
        "target_modality": "T2",
        "image_size": 256,
        "padding": True,
        "norm": True,
    },
    train_dataloader_kwargs={"batch_size": 8, "shuffle": True, "drop_last": True},
    val_dataloader_kwargs={"batch_size": 8, "shuffle": False},
    test_dataloader_kwargs={"batch_size": 8, "shuffle": False},
)

load_engine.setup(stage="fit")
train_loader = load_engine.train_dataloader()
batch = next(iter(train_loader))
print("Batch keys:", batch.keys())
print("Source batch shape:", batch["source"].shape)
print("Target batch shape:", batch["target"].shape)
# Visualize the first sample in the batch
fig, axes = plt.subplots(1, 2, figsize=(10, 5))
axes[0].imshow(batch["source"][0, 0], cmap="gray")
axes[0].set_title("Source (T1)")
axes[0].axis("off")
axes[1].imshow(batch["target"][0, 0], cmap="gray")
axes[1].set_title("Target (T2)")
axes[1].axis("off")
plt.show()