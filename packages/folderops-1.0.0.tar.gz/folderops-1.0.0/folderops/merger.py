from __future__ import annotations

from pathlib import Path
from typing import Sequence

from tqdm import tqdm

from .utils import ensure_directory, normalize_extensions, transfer_file, unique_destination_path, validate_operation


def merge_folders(
    source: str | Path,
    output: str | Path,
    mode: str = 'copy',
    extensions: Sequence[str] | None = None,
) -> list[Path]:
    """
    Merge all files from a directory (including subfolders) into a single output folder.

    This function recursively scans the source directory, collects all files,
    and transfers them into the output directory. If multiple files share the
    same name, unique names are automatically generated to avoid overwriting.

    Example:
        source/
            cats/
                a.jpg
            dogs/
                a.jpg
                b.jpg

        merge_folders(source="source", output="merged")

    Result:
        merged/
            a.jpg
            a_1.jpg
            b.jpg

    Args:
        source:
            Root directory containing files and subfolders to merge.
        output:
            Destination directory where all files will be collected.
        mode:
            File transfer mode: 'copy' or 'move'.
        extensions:
            Optional list of allowed file extensions (e.g., ['.jpg', '.png']).
            If None, all files are included.

    Returns:
        A list of Path objects representing the merged files in the output directory.

    Raises:
        FileNotFoundError: If the source directory does not exist.
    """
    mode = validate_operation(mode)
    extensions = normalize_extensions(extensions)

    source_path = Path(source)
    if not source_path.exists():
        raise FileNotFoundError(f"{source} not found")

    output_dir = ensure_directory(output)
    merged_paths: list[Path] = []

    if extensions is None:
        all_images = [p for p in source_path.rglob("*") if p.is_file()]
    else:
        all_images = [p for p in source_path.rglob("*") if p.is_file() and p.suffix.lower() in extensions]

    for image_path in tqdm(all_images, desc="Merging images", dynamic_ncols=True, ascii=True):
        destination = unique_destination_path(output_dir, image_path.name)
        merged_paths.append(transfer_file(image_path, destination, operation=mode))

    return merged_paths