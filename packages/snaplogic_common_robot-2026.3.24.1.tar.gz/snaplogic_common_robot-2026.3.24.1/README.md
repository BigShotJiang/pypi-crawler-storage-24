# SnapLogic Common Robot Library Guide

## Table of Contents

1. [Overview](#overview)
2. [Embedded Documentation](#embedded-documentation)
3. [Library Distribution](#library-distribution)
4. [Library Structure](#library-structure)
5. [Installation](#installation)
6. [Exploring Keywords](#exploring-keywords)
7. [Usage in Test Framework](#usage-in-test-framework)
8. [Summary](#summary)

## Overview

**snaplogic_common_robot** is a custom Robot Framework library that provides reusable keywords and utilities specifically designed for SnapLogic automation testing. This library encapsulates common SnapLogic operations, API interactions, and testing patterns into convenient Robot Framework keywords.

### Key Features

- **SnapLogic API Integration** - Keywords for SnapLogic REST API operations
- **Pipeline Management** - Keywords for pipeline import, export, and execution
- **Account Management** - Keywords for creating and managing SnapLogic accounts
- **Project Operations** - Keywords for project space and project management
- **Groundplex Operations** - Keywords for Groundplex creation and management
- **Embedded Documentation** - Complete keyword documentation included in the package
- **Reusable Components** - Common testing patterns abstracted into keywords

### Library Benefits

- **Consistency** - Standardized approach to SnapLogic testing across projects
- **Productivity** - Pre-built keywords reduce test development time
- **Maintainability** - Centralized library simplifies updates and bug fixes
- **Documentation** - Built-in keyword documentation and examples
- **Version Control** - Semantic versioning for stable releases
- **Rich Dependencies** - Includes comprehensive set of testing libraries automatically

## Embedded Documentation

The library includes comprehensive documentation that is packaged with the installation:

### 1. Keyword Documentation (LibDoc)
```bash
# Generated Robot Framework keyword documentation
snaplogic-common-robot/src/snaplogic_common_robot/libdocs/index.html
snaplogic-common-robot/src/snaplogic_common_robot/libdocs/snaplogic_keywords.html
snaplogic-common-robot/src/snaplogic_common_robot/libdocs/snaplogic_apis.html
snaplogic-common-robot/src/snaplogic_common_robot/libdocs/common_utilities.html
```

**📖 Quick Access**: To browse the complete keyword documentation with an interactive interface, simply open the `index.html` file in your web browser. This provides a comprehensive overview with navigation links to all available keyword libraries and their detailed documentation.

### 2. Resource Files Documentation
```robot
# All keywords include detailed documentation in resource files
# snaplogic_keywords.resource - Main keyword resource file
# snaplogic_apis.resource - SnapLogic API resource file
# common_utilities.resource - Common utility keywords

# Example keyword documentation structure:
# Create Account From Template
#     [Documentation]    Creates a SnapLogic account from a JSON template file.
#     [Arguments]    ${template_path}
#     ...
```

## Library Distribution

### PyPI Publication

The **snaplogic_common_robot** library is published to a PyPI server, making it easily installable and distributable:

```bash
# Library is available on PyPI server
Package Name: snaplogic-common-robot
Distribution: Python Package Index (PyPI)
Format: Python Wheel (.whl) and Source Distribution (.tar.gz)
```




### Bundled Dependencies

When you install snaplogic-common-robot via `pip install`, the following libraries are automatically installed (defined in `pyproject.toml`):

#### Core Robot Framework Libraries
- robotframework>=3.2
- robotframework-requests
- robotframework-docker
- robotframework-databaselibrary
- robotframework-jsonlibrary
- robotframework-csvlibrary
- robotframework-robocop
- robotframework-tidy[generate_config]
- robotframework-dependencylibrary
- robotframework-pabot==2.18.0

#### Data Processing Libraries
- requests>=2.25.0
- envyaml
- deepdiff
- pyyaml
- jinja2>=2.11.0
- tabulate
- python-dotenv

#### Development and Build Tools
- cookiecutter

#### Optional Development Dependencies (`pip install snaplogic-common-robot[dev]`)
- pytest, pytest-cov
- black, flake8, mypy
- pre-commit

> **Note:** The following libraries are used in the Docker-based test environment (via `requirements.txt`) but are **not** bundled with the pip install: `awscli`, `boto3`, `stomp-py`, `twine`, `build`.

## Library Structure

### Package Structure

```
snaplogic-common-robot/
├── .env
├── .env.example
├── .gitignore
├── .pre-commit-config.yaml
├── .travis.yml
├── ENV_SETUP.md
├── README.md
├── Makefile
├── pyproject.toml
├── snaplogic_common_robot.Dockerfile
├── entrypoint.sh
├── scripts/
│   ├── delete_old_package_versions.sh
│   ├── generate_calver.py
│   ├── generate_libdoc.sh
│   └── upload_lib_docs_to_s3.py
├── meta-data/
├── dist/
└── src/
    ├── requirements.txt
    ├── snaplogic_common_robot/
    │   ├── __init__.py
    │   ├── libdocs/
    │   │   ├── index.html
    │   │   ├── common_utilities.html
    │   │   ├── raw_common_utilities.html
    │   │   ├── raw_snaplogic_apis.html
    │   │   ├── raw_snaplogic_keywords.html
    │   │   ├── robot-doc-styles.css
    │   │   ├── snaplogic_apis.html
    │   │   └── snaplogic_keywords.html
    │   ├── libraries/
    │   │   ├── __init__.py
    │   │   ├── auth_manager.py
    │   │   └── utils.py
    │   ├── snaplogic_apis_keywords/
    │   │   ├── __init__.py
    │   │   ├── common_utilities.resource      # Common utility keywords
    │   │   ├── snaplogic_apis.resource       # SnapLogic API resource file
    │   │   └── snaplogic_keywords.resource   # Main keyword resource file
    │   └── test_data/
    │       ├── __init__.py
    │       ├── slim_groundplex.json
    │       ├── triggered_task.json
    │       └── ultra_task.json
    └── snaplogic_common_robot.egg-info/
        ├── PKG-INFO
        ├── SOURCES.txt
        ├── dependency_links.txt
        ├── requires.txt
        └── top_level.txt
```

## Installation

```bash
# Install from PyPI (automatically installs all dependencies)
pip install snaplogic-common-robot

# Verify installation
pip show snaplogic-common-robot

# Check Robot Framework installation
robot --version
```

## Exploring Keywords

```bash
# List all keywords in the library
python -m robot.libdoc snaplogic_common_robot list

# Get specific keyword information
python -m robot.libdoc snaplogic_common_robot show "Create Snaplex"
```

## Usage in Test Framework

### Add the keywords path as resource

```robot
*** Settings ***

Resource    snaplogic_common_robot/snaplogic_apis_keywords/snaplogic_keywords.resource
Resource    snaplogic_common_robot/snaplogic_apis_keywords/snaplogic_apis.resource
Resource    snaplogic_common_robot/snaplogic_apis_keywords/common_utilities.resource

```

### Example Keyword Usage

```robot
*** Test Cases ***
Create And Configure Account
    [Documentation]    Example of using snaplogic-common-robot keywords
    
    # Use keywords from the library
    Create Account From Template    ${account_payload_path}/acc_oracle.json
    
    Import Pipelines From Template    ${unique_id}    ${pipeline_file_path}    ${pipeline_name}    ${pipeline_name_slp}
    
    Create Triggered Task From Template
    ...    ${unique_id}
    ...    ${project_path}
    ...    ${pipeline_name}
    ...    ${task_name}
    ...    ${task_params}
    ...    ${task_notifications}
```

### Available Keyword Categories

1. **Authentication Keywords**
   - Set Up SnapLogic Connection
   - Authenticate User
   - Get Auth Token

2. **Project Management Keywords**
   - Create Project Space
   - Delete Project Space
   - Create Project
   - Get Project Details

3. **Account Management Keywords**
   - Create Account From Template
   - Update Account Settings
   - Delete Account
   - Validate Account

4. **Pipeline Keywords**
   - Import Pipelines From Template
   - Export Pipeline
   - Validate Pipeline
   - Execute Pipeline

5. **Groundplex Keywords**
   - Create Snaplex
   - Download Config File
   - Check Snaplex Status
   - Delete Snaplex

6. **Task Management Keywords**
   - Create Triggered Task From Template
   - Run Triggered Task
   - Get Task Status
   - Update Task Parameters

7. **Utility Functions**
   - File and JSON handling utilities
   - Template processing functions
   - Data validation helpers


### Troubleshooting

```bash
# Check library installation
pip show snaplogic-common-robot

# Verify keyword availability
python -m robot.libdoc snaplogic_common_robot.snaplogic_apis_keywords.snaplogic_keywords list
python -m robot.libdoc snaplogic_common_robot.snaplogic_apis_keywords.snaplogic_apis list
```

## Summary

The **snaplogic_common_robot** library provides a comprehensive set of Robot Framework keywords specifically designed for SnapLogic automation testing. Key points:

- **Distributed via PyPI** for easy installation and version management
- **Comprehensive Dependencies** — Single `pip install` brings 20+ testing libraries automatically
- **Includes embedded documentation** with keywords, examples, and API references
- **Complete Testing Ecosystem** — Includes Robot Framework extensions, data processing libraries, and development utilities

---

## 📚 Related Resources

- **[SnapLogic Robot Framework Examples](https://github.com/SnapLogic/snaplogic-robotframework-examples)** — End-to-end test framework that uses this library
- **[Robot Framework](https://robotframework.org/)** — Official Robot Framework documentation

---

*The snaplogic_common_robot library is the foundation for consistent, maintainable SnapLogic automation testing across all projects and environments.*