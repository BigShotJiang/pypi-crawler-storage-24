"""
Authentication Manager for SnapLogic Robot Framework.

Provides OAuth2 Client Credentials authentication with automatic token
caching and refresh. Used by the Robot Framework keywords in
snaplogic_apis.resource to support multiple authentication methods.

Supported Authentication Methods:
    - Basic Auth: Handled directly in Robot Framework (no Python needed)
    - JWT/Bearer Token: Handled directly in Robot Framework (no Python needed)
    - OAuth2 Client Credentials: Managed by this library (token fetch + refresh)

Usage in Robot Framework:
    | Library | ../libraries/auth_manager.py |
    |
    | Configure OAuth2 Client Credentials | ${token_url} | ${client_id} | ${client_secret} | ${scope} |
    | ${token} = | Get OAuth2 Access Token |
"""

import time
import requests
from robot.api.deco import keyword
from robot.api import logger


class AuthManager:
    """Manages OAuth2 Client Credentials authentication with automatic token refresh.

    This class maintains a cached access token and automatically refreshes it
    when it expires or is near expiry. It uses the OAuth2 Client Credentials
    grant type, which is designed for machine-to-machine authentication.

    The refresh buffer (default 60 seconds) ensures tokens are refreshed
    before they actually expire, preventing authentication failures during
    API calls.
    """

    ROBOT_LIBRARY_SCOPE = "GLOBAL"

    def __init__(self):
        self._token = None
        self._token_expiry = 0
        self._token_url = None
        self._client_id = None
        self._client_secret = None
        self._scope = None
        self._refresh_buffer_seconds = 60  # Refresh 60s before expiry

    @keyword("Configure OAuth2 Client Credentials")
    def configure_oauth2(self, token_url, client_id, client_secret, scope=""):
        """Configures OAuth2 Client Credentials parameters for token acquisition.

        Must be called before ``Get OAuth2 Access Token``. Stores the OAuth2
        configuration and clears any previously cached token.

        Args:
            token_url: The OAuth2 token endpoint URL
                (e.g., https://company.okta.com/oauth2/default/v1/token)
            client_id: The OAuth2 client ID from your Identity Provider
            client_secret: The OAuth2 client secret from your Identity Provider
            scope: Optional space-separated OAuth2 scopes (default: empty string)

        Examples:
            | Configure OAuth2 Client Credentials |
            | ... | https://company.okta.com/oauth2/default/v1/token |
            | ... | 0oa1b2c3d4e5f6g7h8 |
            | ... | abcdef123456 |
            | ... | snaplogic.api |
        """
        self._token_url = token_url
        self._client_id = client_id
        self._client_secret = client_secret
        self._scope = scope
        self._token = None
        self._token_expiry = 0
        logger.info(
            f"OAuth2 configured: token_url={token_url}, client_id={client_id}, "
            f"scope={scope or '(none)'}"
        )

    @keyword("Get OAuth2 Access Token")
    def get_oauth2_access_token(self):
        """Retrieves a valid OAuth2 access token, refreshing if necessary.

        If a cached token exists and is still valid (not within the refresh
        buffer period), returns the cached token. Otherwise, requests a new
        token from the configured token endpoint.

        Returns:
            str: A valid OAuth2 access token

        Raises:
            RuntimeError: If OAuth2 is not configured or token acquisition fails

        Examples:
            | Configure OAuth2 Client Credentials | ${url} | ${id} | ${secret} |
            | ${token} = | Get OAuth2 Access Token |
            | Should Not Be Empty | ${token} |
        """
        if not self._token_url:
            raise RuntimeError(
                "OAuth2 not configured. Call 'Configure OAuth2 Client Credentials' first."
            )

        # Return cached token if still valid
        if self._token and time.time() < (
            self._token_expiry - self._refresh_buffer_seconds
        ):
            logger.info("Using cached OAuth2 token (still valid)")
            return self._token

        # Acquire new token
        logger.info(f"Acquiring new OAuth2 token from {self._token_url}")
        data = {
            "grant_type": "client_credentials",
            "client_id": self._client_id,
            "client_secret": self._client_secret,
        }
        if self._scope:
            data["scope"] = self._scope

        try:
            response = requests.post(self._token_url, data=data, timeout=30)
            response.raise_for_status()
        except requests.exceptions.ConnectionError as e:
            raise RuntimeError(
                f"OAuth2 token request failed - cannot connect to {self._token_url}: {e}"
            )
        except requests.exceptions.Timeout:
            raise RuntimeError(
                f"OAuth2 token request timed out after 30s: {self._token_url}"
            )
        except requests.exceptions.HTTPError as e:
            raise RuntimeError(
                f"OAuth2 token request failed with HTTP {response.status_code}: "
                f"{response.text}"
            )
        except requests.exceptions.RequestException as e:
            raise RuntimeError(f"OAuth2 token request failed: {e}")

        token_data = response.json()

        if "access_token" not in token_data:
            raise RuntimeError(
                f"OAuth2 response missing 'access_token'. "
                f"Response keys: {list(token_data.keys())}. "
                f"Check your client_id, client_secret, and scope configuration."
            )

        self._token = token_data["access_token"]
        # Default to 3600 seconds (1 hour) if expires_in not provided
        expires_in = token_data.get("expires_in", 3600)
        self._token_expiry = time.time() + expires_in

        logger.info(f"OAuth2 token acquired successfully, expires in {expires_in}s")
        return self._token

    @keyword("Is OAuth2 Token Expired")
    def is_token_expired(self):
        """Checks if the current OAuth2 token is expired or near expiry.

        Returns True if no token exists, the token has expired, or the token
        will expire within the refresh buffer period (default 60 seconds).

        Returns:
            bool: True if token needs refresh, False if still valid

        Examples:
            | ${expired} = | Is OAuth2 Token Expired |
            | IF | ${expired} |
            |     | ${token} = | Get OAuth2 Access Token |
            | END |
        """
        if not self._token:
            return True
        return time.time() >= (self._token_expiry - self._refresh_buffer_seconds)

    @keyword("Clear OAuth2 Token")
    def clear_oauth2_token(self):
        """Clears the cached OAuth2 token, forcing a refresh on next request.

        Use this keyword when you need to force a token refresh, for example
        after a 401 Unauthorized response from the API.

        Examples:
            | Clear OAuth2 Token |
            | ${token} = | Get OAuth2 Access Token |    # Will fetch a new token
        """
        self._token = None
        self._token_expiry = 0
        logger.info("OAuth2 token cache cleared")

    @keyword("Get OAuth2 Token Info")
    def get_token_info(self):
        """Returns information about the current OAuth2 token state.

        Useful for debugging and logging. Returns a dictionary with:
        - configured: Whether OAuth2 has been configured
        - has_token: Whether a token is cached
        - is_expired: Whether the token is expired or near expiry
        - seconds_until_expiry: Seconds until the token expires (0 if expired)

        Returns:
            dict: Token state information

        Examples:
            | ${info} = | Get OAuth2 Token Info |
            | Log | Token configured: ${info}[configured] |
            | Log | Expires in: ${info}[seconds_until_expiry]s |
        """
        now = time.time()
        seconds_until_expiry = max(0, int(self._token_expiry - now))
        return {
            "configured": bool(self._token_url),
            "has_token": bool(self._token),
            "is_expired": self.is_token_expired(),
            "seconds_until_expiry": seconds_until_expiry,
            "token_url": self._token_url or "",
        }
