Events = Annotated[FileSecret, {
    "placeholder": "114514-apple-banana-cat",
    "description": "事件目录的传输密钥（madgraph-launch 的产出）",
}]

Script = Annotated[str, {
    "placeholder": "import {EVENTS_DIR}/Events/run_01/unweighted_events.lhe.gz as signal\nset signal.type = signal\nplot PT(mu+) 50 0 500",
    "description": "MadAnalysis5 分析脚本，使用 {EVENTS_DIR} 占位符引用事件文件路径",
    "allow_empty": False,
    "multi_line": True,
    "min_lines": 3,
}]

Output = Annotated[str, {
    "placeholder": "e.g. tmp/ma5_output",
    "description": "分析结果的下载路径（仅远端调用时生效）",
    "allow_empty": False,
}]

Level = Annotated[Literal["parton", "hadron", "reco"], {                                 
    "description": "分析级别",                                                           
    "options": {                                                                         
        "parton": {"label": "parton", "description": "LHE"},    
        "hadron": {"label": "hadron", "description": "HepMC"},
        "reco": {"label": "reco", "description": "LHCO/ROOT"},
    },
}]


def blueprint(
    events: Events,
    script: Script,
    output: Output,
    level: Level = "parton",
):

    description = "## MadAnalysis5 分析任务"

    safe_events = events.replace("'", "'\\''")
    safe_script = script.replace("'", "'\\''")
    safe_target = output.replace("'", "'\\''")
    safe_level = level.replace("'", "'\\''")

    system_entry_command = """
# No system entry command needed.
"""

    entry_command = f"""
pip3 install "magnus-sdk>=0.5.5" --quiet
python3 scripts/on_magnus/run_madanalysis_process.py --events_secret '{safe_events}' --script '{safe_script}' --level '{safe_level}' --target_path '{safe_target}'
"""

    submit_job(
        task_name = "[Blueprint] MadAnalysis Process",
        description = description,
        namespace = "HET-AGI",
        repo_name = "Collider-Agent",
        commit_sha = "HEAD",
        system_entry_command = system_entry_command,
        entry_command = entry_command,
        container_image = "docker://git.pku.edu.cn/het-agi/collider:latest",
        job_type = JobType.A2,
        runner = "magnus",
        cpu_count = 10,
        memory_demand = "64G",
    )

