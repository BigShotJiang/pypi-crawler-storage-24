import logging
from struct import unpack

from kazoo.client import KazooClient
from kazoo.exceptions import NoNodeError
from kazoo.handlers.threading import KazooTimeoutError

from hbasedriver.protobuf_py import ZooKeeper_pb2
from hbasedriver.protobuf_py.ZooKeeper_pb2 import Master

logger = logging.getLogger('pybase.' + __name__)
logger.setLevel(logging.DEBUG)

znode = "/hbase"


# locate_master takes a string representing the location of the ZooKeeper
# quorum. It then asks ZK for the location of the MetaRegionServer.
# i.e. this gets the region server that holds the hbase:meta table.
def locate_meta_region(zkquorum: list, establish_connection_timeout=15, missing_znode_retries=10) -> (bytes, bytes):
    if type(zkquorum) != list:
        raise ValueError("must provide a list for zookeeper quorum.")
    try:
        for host in zkquorum:
            zk = KazooClient(hosts=host, timeout=10)
            zk.start(timeout=establish_connection_timeout)
            break
        else:
            raise Exception("can not connect to zk via any contact point {}".format(zkquorum))
    except KazooTimeoutError:
        raise Exception("Cannot connect to ZooKeeper at {}".format(zkquorum[0]))

    # locate meta region
    attempts = 0
    while True:
        try:
            rsp, znodestat = zk.get(znode + "/meta-region-server")
            break
        except NoNodeError:
            attempts += 1
            if attempts > missing_znode_retries:
                logger.error("cant locate meta-region-server, zk has no such node. ")
                raise Exception("zk locate meta failed")
            logger.info("/hbase/meta-region-server znode missing, retrying (%d/%d)", attempts, missing_znode_retries)
            import time
            time.sleep(1)

    zk.stop()
    if len(rsp) == 0:
        # Empty response is bad.
        raise Exception("ZooKeeper returned an empty response")
    # The first byte must be \xff.
    # 4 byte: length of id
    first_byte, id_length = unpack(">cI", rsp[:5])
    if first_byte != b'\xff':
        # Malformed response
        raise Exception(
            "ZooKeeper returned an invalid response")
    # skip bytes already read , id and an 8-byte long type salt.
    rsp = rsp[5 + id_length:]
    # data is prepended with PBMagic
    assert rsp[:4] == b'PBUF'
    rsp = rsp[4:]

    meta = ZooKeeper_pb2.MetaRegionServer()
    meta.ParseFromString(rsp)
    # here we got the master host and port.
    hostname = meta.server.host_name
    port = meta.server.port

    logger.info('Discovered meta region at %s:%s', hostname, port)
    return hostname, port


def locate_master(zk_quorum: list, establish_connection_timeout=15, missing_znode_retries=10):
    if not isinstance(zk_quorum, list):
        raise ValueError("must provide a list for zookeeper quorum.")
    zk = None
    try:
        for host in zk_quorum:
            zk = KazooClient(hosts=host, timeout=10)
            zk.start(timeout=establish_connection_timeout)
            break
    except KazooTimeoutError:
        raise Exception("Cannot connect to ZooKeeper at {}".format(zk_quorum[0]))

    if not zk:
        raise Exception("can not connect to zk via any contact point {}".format(zk_quorum))

    # locate master with retries
    attempts = 0
    while True:
        try:
            rsp, stat = zk.get("/hbase/master")
            first_byte, id_length = unpack(">cI", rsp[:5])
            if first_byte != b'\xff':
                # Malformed response
                raise Exception(
                    "ZooKeeper returned an invalid response")
            # skip bytes already read , id and an 8-byte long type salt.
            rsp = rsp[5 + id_length:]
            # skip PBUF
            rsp = rsp[4:]
            master = Master.FromString(rsp)
            master_host = master.master.host_name
            master_port = master.master.port
            zk.stop()
            return master_host, master_port
        except NoNodeError:
            attempts += 1
            if attempts > missing_znode_retries:
                logger.error("cant locate master, zk has no such node after retries.")
                raise Exception("zk locate master failed")
            logger.info("/hbase/master znode missing, retrying (%d/%d)", attempts, missing_znode_retries)
            import time
            time.sleep(1)
        except Exception:
            zk.stop()
            raise
