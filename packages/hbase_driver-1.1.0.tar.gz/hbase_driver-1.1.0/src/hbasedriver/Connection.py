import random
import socket
from abc import abstractmethod
from struct import pack, unpack
from threading import Lock

from google.protobuf import message

from hbasedriver.client.admin import Admin
from hbasedriver.common.table_name import TableName
from hbasedriver.protobuf_py.RPC_pb2 import ConnectionHeader, RequestHeader, ResponseHeader
from hbasedriver.exceptions.RemoteException import RemoteException, TableExistsException
from hbasedriver.response import response_types
from hbasedriver.util import to_varint, decoder


# encapsule low level connections to zookeeper and servers.
class Connection:
    def __init__(self, service_name):
        self.conn: socket.socket | None = None
        assert service_name in ["ClientService", "MasterService"]
        self.service_name = service_name
        self.meta_region = None
        self.host = None
        self.port = None
        self.timeout = 60
        self.user = "pythonHbaseDriver"
        self.lock = Lock()  # Mutex

    def connect(self, host, port=16000, timeout=60, user="pythonHbaseDriver"):
        with self.lock:
            if not isinstance(host, str):
                host = host.decode("utf-8")
            if not isinstance(port, int):
                port = int(port)
            try:
                self.conn = socket.create_connection((host, port), timeout=timeout)
            except OSError as e:
                # If we encounter EADDRNOTAVAIL (Errno 99), try forcing IPv4 resolution
                if getattr(e, 'errno', None) == 99:
                    last_exc = e
                    for af, socktype, proto, canonname, sa in socket.getaddrinfo(host, port, socket.AF_INET, socket.SOCK_STREAM):
                        try:
                            sock = socket.socket(af, socktype, proto)
                            if timeout is not None:
                                sock.settimeout(timeout)
                            sock.connect(sa)
                            self.conn = sock
                            last_exc = None
                            break
                        except Exception as e2:
                            last_exc = e2
                    if last_exc is not None:
                        raise last_exc
                else:
                    raise
            ch = ConnectionHeader()
            ch.user_info.effective_user = self.user
            ch.service_name = self.service_name
            serialized = ch.SerializeToString()
            # 6 bytes : 'HBas' + RPC_VERSION(0) + AUTH_CODE(80) +
            msg = b"HBas\x00\x50" + pack(">I", len(serialized)) + serialized
            self.conn.send(msg)
            self.host = host
            self.port = port
            self.timeout = timeout
            self.user = user
            return self

    def get_admin(self):
        return Admin()

    @abstractmethod
    def clone(self):
        """
        build another new connection with the same settings as this.
        """
        pass

    def send_request(self, req: message.Message, method_name: str, need_response=True):
        with self.lock:
            rpc_serialized = req.SerializeToString()
            call_id = random.randint(1, 999)
            # call_id = 66
            serialized_header = self._get_call_header_bytes(method_name, call_id)
            rpc_length_bytes = to_varint(len(rpc_serialized)).encode('utf-8')
            total_size = 4 + 1 + len(serialized_header) + len(rpc_length_bytes) + len(rpc_serialized)

            # Total length doesn't include the initial 4 bytes (for the total_length uint32)
            # size(4bytes) + header size(1byte)
            to_send = pack(">IB", total_size - 4, len(serialized_header))
            to_send += serialized_header + rpc_length_bytes + rpc_serialized

            self.conn.send(to_send)
            if need_response:
                return self._receive_rpc(call_id, req, method_name)
            else:
                return

    @staticmethod
    def _get_call_header_bytes(method_name, call_id: int):
        header = RequestHeader()
        header.call_id = call_id
        header.method_name = method_name
        header.request_param = True
        serialized_header: bytes = header.SerializeToString()
        return serialized_header

    # Receives exactly n bytes from the socket. Will block until n bytes are
    # received. If a socket is closed (RegionServer died) then raise an
    # exception that goes all the way back to the main client
    @staticmethod
    def _recv_n(sock: socket.socket, n):
        res = b''
        partial_len = 0
        while partial_len < n:
            packet = sock.recv(n - partial_len)
            if not packet:
                raise socket.error()
            partial_len += len(packet)
            res += packet
        return res

    def _receive_rpc(self, call_id, rq: message.Message, rq_type: str, data=None):
        # Total message length is going to be the first four bytes
        # (little-endian uint32)
        try:
            msg_length = self._recv_n(self.conn, 4)
            if msg_length is None:
                raise
            msg_length = unpack(">I", msg_length)[0]
            # The message is then going to be however many bytes the first four
            # bytes specified. We don't want to overread or underread as that'll
            # cause havoc.
            full_data = self._recv_n(self.conn, msg_length)
        except socket.error:
            raise Exception("cant read enough data when receiving response. ")
        # Pass in the full data as well as your current position to the
        # decoder. It'll then return two variables:
        #       - next_pos: The number of bytes of data specified by the varint
        #       - pos: The starting location of the data to read.

        header_size, pos = decoder(full_data, 0)

        header = ResponseHeader()
        header.ParseFromString(full_data[pos: pos + header_size])

        if header.exception.exception_class_name != '':
            if header.exception.exception_class_name == "org.apache.hadoop.hbase.TableExistsException":
                raise TableExistsException(header.exception.exception_class_name, header.exception.stack_trace)

            raise RemoteException(header.exception.exception_class_name, header.exception.stack_trace)

        pos += header_size
        if header.call_id != call_id:
            # this should not happen, currently we don't provide concurrent access throw a single instance.
            raise Exception("call id is wrong. ")

        rpc_size, pos = decoder(full_data, pos)
        # if we didn't put the related response type, it means that we do not need a response.
        if response_types.get(rq_type) is None:
            return

        rpc: message.Message = response_types[rq_type]()
        rpc.ParseFromString(full_data[pos: pos + rpc_size])
        # The rpc is fully built!
        return rpc

    def get_region_locator(self, table_name: TableName):
        from hbasedriver.client.region_locator import RegionLocator
        return RegionLocator(table_name, self)
