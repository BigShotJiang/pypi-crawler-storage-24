"""
Marziel AI — Pre-compiled llama-server binary manager

Downloads and runs the official llama-server binary from
ggml-org/llama.cpp GitHub releases. No compilation, no Python
dependencies, works on ANY Python version and ANY platform.

Supports:
  - Linux x64 (CPU, Vulkan/NVIDIA)
  - macOS arm64 (Apple Silicon w/ Metal)
  - macOS x64 (Intel)
  - Windows x64 (CPU, CUDA 12.4, CUDA 13.1, Vulkan)
"""
from __future__ import annotations

import json
import logging
import os
import platform
import shutil
import stat
import subprocess
import sys
import tarfile
import tempfile
import zipfile
from pathlib import Path
from typing import Optional, List, Dict
from urllib.request import urlopen, Request

logger = logging.getLogger("marziel.llama_server")

BINARY_DIR = Path.home() / ".marziel" / "bin"
LLAMA_REPO = "ggml-org/llama.cpp"


def _detect_platform() -> List[Dict]:
    """Return list of asset name patterns to try, best match first."""
    system = platform.system()
    machine = platform.machine().lower()
    patterns = []

    # Detect NVIDIA GPU
    has_nvidia = False
    try:
        result = subprocess.run(["nvidia-smi"], capture_output=True, timeout=5)
        has_nvidia = result.returncode == 0
    except Exception:
        pass

    # Detect AMD GPU (Linux)
    has_amd = False
    if system == "Linux":
        try:
            result = subprocess.run(["rocm-smi"], capture_output=True, timeout=5)
            has_amd = result.returncode == 0
        except Exception:
            pass

    if system == "Darwin":
        if machine in ("arm64", "aarch64"):
            patterns.append({"match": "macos-arm64", "ext": ".tar.gz"})
        else:
            patterns.append({"match": "macos-x64", "ext": ".tar.gz"})

    elif system == "Linux":
        if has_nvidia:
            # Vulkan works with NVIDIA GPUs on Linux
            patterns.append({"match": "ubuntu-vulkan-x64", "ext": ".tar.gz"})
        if has_amd:
            patterns.append({"match": "ubuntu-rocm", "ext": ".tar.gz"})
        # CPU fallback
        patterns.append({"match": "ubuntu-x64", "ext": ".tar.gz"})

    elif system == "Windows":
        if has_nvidia:
            patterns.append({"match": "win-cuda-12.4-x64", "ext": ".zip"})
            patterns.append({"match": "win-cuda-13.1-x64", "ext": ".zip"})
            patterns.append({"match": "win-vulkan-x64", "ext": ".zip"})
        patterns.append({"match": "win-cpu-x64", "ext": ".zip"})

    return patterns


def _get_latest_release() -> dict:
    """Get the latest release info from GitHub API."""
    url = f"https://api.github.com/repos/{LLAMA_REPO}/releases/latest"
    req = Request(url, headers={"User-Agent": "marziel"})
    with urlopen(req, timeout=15) as resp:
        return json.loads(resp.read())


def _find_asset(release: dict, match: str) -> Optional[dict]:
    """Find asset matching the platform pattern."""
    for asset in release.get("assets", []):
        name = asset["name"]
        if match in name and "cudart" not in name:
            return asset
    return None


def _download_file(url: str, dest: Path, label: str = ""):
    """Download a file with progress indication."""
    req = Request(url, headers={"User-Agent": "marziel"})
    with urlopen(req, timeout=300) as resp:
        total = int(resp.headers.get("Content-Length", 0))
        chunk_size = 1024 * 1024  # 1MB
        downloaded = 0
        with open(dest, "wb") as f:
            while True:
                chunk = resp.read(chunk_size)
                if not chunk:
                    break
                f.write(chunk)
                downloaded += len(chunk)
                if total > 0:
                    pct = int(downloaded * 100 / total)
                    mb = downloaded / (1024 * 1024)
                    total_mb = total / (1024 * 1024)
                    print(f"\r       {label} {mb:.0f}/{total_mb:.0f} MB ({pct}%)",
                          end="", flush=True)
        print()  # newline after progress


def _extract(archive_path: Path, dest_dir: Path):
    """Extract tar.gz or zip archive."""
    if archive_path.suffix == ".gz" or str(archive_path).endswith(".tar.gz"):
        with tarfile.open(archive_path, "r:gz") as tar:
            tar.extractall(dest_dir)
    elif archive_path.suffix == ".zip":
        with zipfile.ZipFile(archive_path, "r") as zf:
            zf.extractall(dest_dir)


def get_server_binary() -> Optional[Path]:
    """Get path to llama-server binary, downloading if needed."""
    # Check if already downloaded
    if platform.system() == "Windows":
        server_bin = BINARY_DIR / "llama-server.exe"
    else:
        server_bin = BINARY_DIR / "llama-server"

    if server_bin.exists():
        return server_bin

    # Download
    print("   📥 Downloading llama-server binary...")
    print("       (pre-compiled, no compiler needed)")

    try:
        release = _get_latest_release()
        tag = release["tag_name"]
        print(f"       Latest release: {tag}")
    except Exception as e:
        logger.error(f"Failed to get latest release: {e}")
        print(f"   ⚠️  Could not reach GitHub: {e}")
        return None

    patterns = _detect_platform()
    if not patterns:
        print("   ⚠️  Unsupported platform")
        return None

    for pattern in patterns:
        asset = _find_asset(release, pattern["match"])
        if asset:
            print(f"       Platform: {pattern['match']}")
            break
    else:
        print(f"   ⚠️  No binary found for this platform")
        return None

    # Download to temp, extract, move
    BINARY_DIR.mkdir(parents=True, exist_ok=True)

    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        archive_name = asset["name"]
        archive_path = tmpdir / archive_name

        try:
            _download_file(asset["browser_download_url"], archive_path,
                          label="Downloading:")
        except Exception as e:
            print(f"   ⚠️  Download failed: {e}")
            return None

        # Extract
        print("       Extracting...")
        extract_dir = tmpdir / "extracted"
        extract_dir.mkdir()
        try:
            _extract(archive_path, extract_dir)
        except Exception as e:
            print(f"   ⚠️  Extract failed: {e}")
            return None

        # Find llama-server binary in extracted files
        server_name = "llama-server.exe" if platform.system() == "Windows" else "llama-server"
        found = None
        for root, dirs, files in os.walk(extract_dir):
            if server_name in files:
                found = Path(root) / server_name
                break

        if not found:
            print(f"   ⚠️  {server_name} not found in archive")
            return None

        # Copy binary and any shared libraries
        shutil.copy2(found, server_bin)

        # Copy shared libs (.so, .dylib, .dll) from same directory
        for f in found.parent.iterdir():
            if f.suffix in (".so", ".dylib", ".dll", ".metal") or ".so." in f.name:
                shutil.copy2(f, BINARY_DIR / f.name)

        # Make executable
        if platform.system() != "Windows":
            server_bin.chmod(server_bin.stat().st_mode | stat.S_IEXEC | stat.S_IXGRP | stat.S_IXOTH)

    print(f"   ✅ llama-server binary ready")
    return server_bin


def start_server(model_path: str, port: int = 8000,
                 n_gpu_layers: int = 999) -> Optional[subprocess.Popen]:
    """Start the llama-server binary."""
    binary = get_server_binary()
    if not binary:
        return None

    cmd = [
        str(binary),
        "--model", model_path,
        "--host", "0.0.0.0",
        "--port", str(port),
        "--n-gpu-layers", str(n_gpu_layers),
        "--ctx-size", "4096",
    ]

    env = dict(os.environ)
    # Add binary dir to library path for shared libs
    ld_path = str(BINARY_DIR)
    if "LD_LIBRARY_PATH" in env:
        env["LD_LIBRARY_PATH"] = f"{ld_path}:{env['LD_LIBRARY_PATH']}"
    else:
        env["LD_LIBRARY_PATH"] = ld_path

    if "DYLD_LIBRARY_PATH" in env:
        env["DYLD_LIBRARY_PATH"] = f"{ld_path}:{env['DYLD_LIBRARY_PATH']}"
    else:
        env["DYLD_LIBRARY_PATH"] = ld_path

    try:
        proc = subprocess.Popen(
            cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            env=env,
        )
        return proc
    except Exception as e:
        logger.error(f"Failed to start llama-server: {e}")
        return None
