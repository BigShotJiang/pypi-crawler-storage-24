from __future__ import annotations

import asyncio
import difflib
import json
import logging
import pathlib
import re
import subprocess
import sys
import tempfile
from argparse import ArgumentParser, RawDescriptionHelpFormatter
from collections.abc import Iterable, Mapping
from functools import lru_cache
from io import StringIO
from typing import Any, ClassVar, Final, Literal, NamedTuple, TypedDict, cast, overload

import httpx
import tomlkit
from httpx import URL
from tomlkit import TOMLDocument, table
from tomlkit.items import Table
from tomlkit.toml_file import TOMLFile

__version__ = "0.0.3"

_DEFAULT_EXCLUDE: Final[set[str]] = {"lint.per-file-ignores"}
_GITHUB_REPO_PATH_PARTS_COUNT: Final[int] = 2
_GITHUB_HOSTS: Final[set[str]] = {"github.com", "www.github.com"}
_GITHUB_RAW_HOST: Final[str] = "raw.githubusercontent.com"
_GITLAB_HOSTS: Final[set[str]] = {"gitlab.com"}

LOGGER = logging.getLogger(__name__)


class ColoredFormatter(logging.Formatter):
    """Logging Formatter to add colors"""

    RESET: ClassVar[str] = "\x1b[0m"
    COLORS: ClassVar[Mapping[int, str]] = {
        logging.DEBUG: "\x1b[36m",  # Cyan
        logging.INFO: "\x1b[32m",  # Green
        logging.WARNING: "\x1b[33m",  # Yellow
        logging.ERROR: "\x1b[31m",  # Red
        logging.CRITICAL: "\x1b[1;31m",  # Bold Red
    }

    def __init__(self, fmt: str = "%(message)s") -> None:
        super().__init__(fmt)

    def format(self, record: logging.LogRecord) -> str:  # type: ignore[explicit-override]
        if sys.stderr.isatty():
            color = self.COLORS.get(record.levelno, self.RESET)
            return f"{color}{super().format(record)}{self.RESET}"
        return super().format(record)


class Arguments(NamedTuple):
    command: str
    upstream: URL
    source: pathlib.Path
    exclude: Iterable[str]
    verbose: int
    branch: str = "main"
    path: str = ""
    semantic: bool = False
    diff: bool = True

    @classmethod
    @lru_cache(maxsize=1)
    def fields(cls) -> set[str]:
        return set(cls._fields)


class Config(TypedDict, total=False):
    upstream: str
    source: str
    exclude: list[str]
    verbose: int
    branch: str
    path: str
    semantic: bool
    diff: bool


@lru_cache(maxsize=1)
def get_config(
    source: pathlib.Path,
) -> Config:
    local_toml = source / "pyproject.toml"
    # TODO: use pydantic to validate the toml file
    cfg_result: dict[str, Any] = {}
    if local_toml.exists():
        toml = tomlkit.parse(local_toml.read_text())
        config = toml.get("tool", {}).get("ruff-sync")
        if config:
            for arg, value in config.items():
                if arg in Arguments.fields():
                    cfg_result[arg] = value
                else:
                    LOGGER.warning(f"Unknown ruff-sync configuration: {arg}")
    return cast("Config", cfg_result)


@lru_cache(maxsize=1)
def _resolve_source(source: str | pathlib.Path) -> pathlib.Path:
    if isinstance(source, str):
        source = pathlib.Path(source)
    return source.resolve(strict=True)


def _get_cli_parser() -> ArgumentParser:
    parser = ArgumentParser(
        prog="ruff-sync",
        description=(
            "Synchronize Ruff linter configuration across Python projects.\n\n"
            "Downloads a pyproject.toml from an upstream URL, extracts the\n"
            "[tool.ruff] section, and merges it into the local pyproject.toml\n"
            "while preserving formatting, comments, and whitespace.\n\n"
            "Defaults to the 'pull' subcommand when none is specified."
        ),
        epilog=(
            "Examples:\n"
            "  ruff-sync pull https://github.com/org/repo/blob/main/pyproject.toml\n"
            "  ruff-sync check https://github.com/org/repo/blob/main/pyproject.toml\n"
            "  ruff-sync pull git@github.com:org/repo.git\n"
            "  ruff-sync pull ssh://git@gitlab.com/org/repo.git\n"
            "  ruff-sync check --semantic  # ignore formatting-only differences\n\n"
            "The upstream URL can also be set in [tool.ruff-sync] in pyproject.toml\n"
            "so you can simply run: ruff-sync pull"
        ),
        formatter_class=RawDescriptionHelpFormatter,
    )
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    subparsers = parser.add_subparsers(dest="command", help="Subcommand to run (default: pull)")

    # Common arguments
    common_parser = ArgumentParser(add_help=False)
    common_parser.add_argument(
        "upstream",
        type=URL,
        nargs="?",
        help="The URL to download the pyproject.toml file from."
        " Optional if defined in [tool.ruff-sync].",
    )
    common_parser.add_argument(
        "--source",
        type=pathlib.Path,
        default=".",
        help="The directory to sync the pyproject.toml file to. Default: .",
        required=False,
    )
    common_parser.add_argument(
        "--exclude",
        nargs="+",
        help=f"Exclude certain ruff configs. Default: {' '.join(_DEFAULT_EXCLUDE)}",
        default=None,
    )
    common_parser.add_argument(
        "-v",
        "--verbose",
        action="count",
        default=0,
        help="Increase verbosity. -v for INFO, -vv for DEBUG.",
    )
    common_parser.add_argument(
        "--branch",
        help="The default branch to use when resolving repo URLs. Default: main",
        default=None,
    )
    common_parser.add_argument(
        "--path",
        help="The parent path where pyproject.toml is located. Default: root",
        default=None,
    )

    # Pull subcommand (the default action)
    subparsers.add_parser(
        "pull",
        parents=[common_parser],
        help="Pull and apply upstream ruff configuration",
    )

    # Check subcommand
    check_parser = subparsers.add_parser(
        "check", parents=[common_parser], help="Check if ruff configuration is in sync"
    )
    check_parser.add_argument(
        "--semantic",
        action="store_true",
        help="Ignore non-functional differences like whitespace and comments.",
    )
    check_parser.add_argument(
        "--diff",
        action="store_true",
        default=True,
        help="Show a diff of what would change. Default: True.",
    )
    check_parser.add_argument(
        "--no-diff",
        action="store_false",
        dest="diff",
        help="Do not show a diff.",
    )

    return parser


def _convert_github_url(url: URL, branch: str = "main", path: str = "") -> URL:
    """Convert a GitHub URL to its corresponding raw content URL.

    Supports:
    - Blob URLs: https://github.com/org/repo/blob/branch/path/to/file
    - Repo URLs: https://github.com/org/repo (defaults to {branch}/{path}/pyproject.toml)

    Args:
        url (URL): The GitHub URL to be converted.
        branch (str): The default branch to use for repo URLs.
        path (str): The directory prefix for pyproject.toml.

    Returns:
        URL: The corresponding raw content URL.
    """
    # Handle blob URLs (e.g. .../blob/main/pyproject.toml)
    if "/blob/" in url.path:
        new_path = url.path.replace("/blob/", "/", 1)
        raw_url = url.copy_with(host=_GITHUB_RAW_HOST, path=new_path)
        LOGGER.info(f"Converting GitHub blob URL to raw content URL: {raw_url}")
        return raw_url

    # Handle repository URLs (e.g. https://github.com/org/repo)
    # We assume if it has exactly two path components, it's a repo URL.
    path_parts = [p for p in url.path.split("/") if p]
    if len(path_parts) == _GITHUB_REPO_PATH_PARTS_COUNT:
        org, repo = path_parts
        target_path = f"{path.strip('/')}/pyproject.toml" if path else "pyproject.toml"
        raw_url = url.copy_with(
            host=_GITHUB_RAW_HOST,
            path=f"/{org}/{repo}/{branch}/{target_path}",
        )
        LOGGER.info(f"Converting GitHub repo URL to raw content URL: {raw_url}")
        return raw_url

    LOGGER.info("URL is a GitHub URL but doesn't match known patterns, returning as is.")
    return url


def _convert_gitlab_url(url: URL, branch: str = "main", path: str = "") -> URL:
    """Convert a GitLab URL to its corresponding raw content URL.

    Supports:
    - Blob URLs: https://gitlab.com/org/repo/-/blob/branch/path/to/file
    - Repo URLs: https://gitlab.com/org/repo (defaults to {branch}/{path}/pyproject.toml)

    Args:
        url (URL): The GitLab URL to be converted.
        branch (str): The default branch to use for repo URLs.
        path (str): The directory prefix for pyproject.toml.

    Returns:
        URL: The corresponding raw content URL.
    """
    # Handle blob URLs (e.g. .../-/blob/main/pyproject.toml)
    if "/-/blob/" in url.path:
        new_path = url.path.replace("/-/blob/", "/-/raw/", 1)
        raw_url = url.copy_with(path=new_path)
        LOGGER.info(f"Converting GitLab blob URL to raw content URL: {raw_url}")
        return raw_url

    # Handle repository URLs (e.g. https://gitlab.com/org/repo)
    # If the path doesn't contain the separator '/-/', we assume it's a project root.
    if "/-/" not in url.path:
        # Avoid empty paths or just a slash
        path_prefix = url.path.rstrip("/")
        if path_prefix:
            target_path = f"{path.strip('/')}/pyproject.toml" if path else "pyproject.toml"
            raw_url = url.copy_with(path=f"{path_prefix}/-/raw/{branch}/{target_path}")
            LOGGER.info(f"Converting GitLab repo URL to raw content URL: {raw_url}")
            return raw_url

    LOGGER.info("URL is a GitLab URL but doesn't match known patterns, returning as is.")
    return url


def is_git_url(url: URL) -> bool:
    """Return True if the URL should be treated as a git repository."""
    return str(url).startswith("git@") or url.scheme in ("ssh", "git", "git+ssh")


def resolve_raw_url(url: URL, branch: str = "main", path: str | None = None) -> URL:
    """Convert a GitHub or GitLab repository/blob URL to a raw content URL.

    Args:
        url (URL): The URL to resolve.
        branch (str): The default branch to use for repo URLs.
        path (str | None): The directory prefix for pyproject.toml.

    Returns:
        URL: The resolved raw content URL, or the original URL if no conversion applies.
    """
    # If it's a git URL, leave it alone; we'll handle it via git clone
    if is_git_url(url):
        return url
    LOGGER.debug(f"Initial URL: {url}")
    if url.host in _GITHUB_HOSTS:
        return _convert_github_url(url, branch=branch, path=path or "")
    if url.host in _GITLAB_HOSTS:
        return _convert_gitlab_url(url, branch=branch, path=path or "")
    return url


async def download(url: URL, client: httpx.AsyncClient) -> StringIO:
    """Download a file from a URL and return a StringIO object."""
    response = await client.get(url)
    response.raise_for_status()
    return StringIO(response.text)


async def fetch_upstream_config(
    url: URL, client: httpx.AsyncClient, branch: str, path: str | None
) -> StringIO:
    """Fetch the upstream pyproject.toml either via HTTP or git clone."""
    if is_git_url(url):
        LOGGER.info(f"Cloning {url} via git...")

        def _git_clone_and_read() -> str:
            """Clone the git repo into a temp directory and read pyproject.toml.

            Uses an efficient cloning strategy to minimize network traffic and disk space:
            - `--depth 1`: only fetches the tip of the requested branch
            - `--filter=blob:none`: avoids downloading any file contents (blobs) during the clone
            - `--no-checkout`: prevents git from populating the working tree

            After the metadata is cloned, we try `git restore` to explicitly download and place
            only the requested `pyproject.toml` file into the working tree. If `restore` fails
            (e.g. on older git versions), we fall back to a specific `git checkout`.
            """
            with tempfile.TemporaryDirectory() as temp_dir:
                # Use --no-checkout and --filter=blob:none to avoid downloading unnecessary files
                cmd = [
                    "git",
                    "clone",
                    "--depth",
                    "1",
                    "--filter=blob:none",
                    "--no-checkout",
                    "--branch",
                    branch,
                    str(url),
                    temp_dir,
                ]
                LOGGER.info(f"Running git command: {' '.join(cmd)}")
                try:
                    subprocess.run(  # noqa: S603
                        cmd,
                        check=True,
                        capture_output=True,
                        text=True,
                    )
                    target_path = (
                        pathlib.Path(path.strip("/")) / "pyproject.toml"
                        if path
                        else pathlib.Path("pyproject.toml")
                    )

                    # Restore just the pyproject_toml file
                    restore_cmd = [
                        "git",
                        "-C",
                        temp_dir,
                        "restore",
                        "--source",
                        branch,
                        str(target_path),
                    ]
                    LOGGER.info(f"Running git restore: {' '.join(restore_cmd)}")

                    try:
                        subprocess.run(  # noqa: S603
                            restore_cmd,
                            check=True,
                            capture_output=True,
                            text=True,
                        )
                    except subprocess.CalledProcessError:
                        LOGGER.info("git restore failed, falling back to git checkout")
                        checkout_cmd = [
                            "git",
                            "-C",
                            temp_dir,
                            "checkout",
                            branch,
                            "--",
                            str(target_path),
                        ]
                        LOGGER.info(f"Running git checkout: {' '.join(checkout_cmd)}")
                        subprocess.run(  # noqa: S603
                            checkout_cmd,
                            check=True,
                            capture_output=True,
                            text=True,
                        )
                except subprocess.CalledProcessError as e:
                    LOGGER.exception(f"Git operation failed: {e.stderr}")
                    raise

                full_target_path = pathlib.Path(temp_dir) / target_path
                if not full_target_path.exists():
                    raise FileNotFoundError(
                        f"Configuration file not found in repository at {target_path}"
                    )
                return full_target_path.read_text()

        content = await asyncio.to_thread(_git_clone_and_read)
        return StringIO(content)

    return await download(url, client)


@overload
def get_ruff_tool_table(
    toml: str | TOMLDocument,
    create_if_missing: Literal[True] = ...,
    exclude: Iterable[str] = ...,
) -> Table: ...


@overload
def get_ruff_tool_table(
    toml: str | TOMLDocument,
    create_if_missing: Literal[False] = ...,
    exclude: Iterable[str] = ...,
) -> Table | None: ...


def get_ruff_tool_table(
    toml: str | TOMLDocument,
    create_if_missing: bool = True,
    exclude: Iterable[str] = (),
) -> Table | None:
    """Get the tool.ruff section from a TOML string.
    If it does not exist, create it.
    """
    if isinstance(toml, str):
        doc: TOMLDocument = tomlkit.parse(toml)
    else:
        doc = toml
    try:
        tool: Table = doc["tool"]  # type: ignore[assignment]
        ruff = tool["ruff"]
        LOGGER.debug("Found `tool.ruff` section.")
    except KeyError:
        if not create_if_missing:
            return None
        LOGGER.info("✨ No `tool.ruff` section found, creating it.")
        tool = table(True)
        ruff = table()
        tool.append("ruff", ruff)
        doc.append("tool", tool)
    if not isinstance(ruff, Table):
        raise TypeError(f"Expected table, got {type(ruff)}")
    _apply_exclusions(ruff, exclude)
    return ruff


def _apply_exclusions(tbl: Table, exclude: Iterable[str]) -> None:
    """Remove excluded keys from a ruff table, supporting dotted paths.

    Keys can be simple (e.g. ``"target-version"``) to match top-level ruff
    keys, or dotted (e.g. ``"lint.per-file-ignores"``) to reach into nested
    sub-tables.
    """
    for key_path in exclude:
        parts = key_path.split(".")
        target: Any = tbl
        for part in parts[:-1]:
            target = target.get(part) if hasattr(target, "get") else None
            if target is None:
                break
        if target is not None and hasattr(target, "pop"):
            leaf = parts[-1]
            if leaf in target:
                LOGGER.info(f"Excluding `{key_path}` from upstream ruff config.")
                target.pop(leaf)


def toml_ruff_parse(toml_s: str, exclude: Iterable[str]) -> TOMLDocument:
    """Parse a TOML string for the tool.ruff section excluding certain ruff configs."""
    ruff_toml: TOMLDocument = tomlkit.parse(toml_s)["tool"]["ruff"]  # type: ignore[index,assignment]
    for section in exclude:
        LOGGER.info(f"Excluding section `lint.{section}` from ruff config.")
        ruff_toml["lint"].pop(section, None)  # type: ignore[union-attr]
    return ruff_toml


def _recursive_update(source_table: Any, upstream: Any) -> None:
    """Recursively update a TOML table, preserving formatting of existing keys."""
    if hasattr(upstream, "items") or isinstance(upstream, Mapping):
        items = upstream.items()
    else:
        return

    for key, value in items:
        if key in source_table:
            if hasattr(source_table[key], "items") and (
                hasattr(value, "items") or isinstance(value, Mapping)
            ):
                # Structural fix: if the target is a proxy (dotted key),
                # and we are adding NEW keys to it, we must convert it to a real
                # table to ensure children get correct headers.
                source_sub_keys = set(source_table[key].keys())
                upstream_sub_keys = set(value.keys())
                if not upstream_sub_keys.issubset(source_sub_keys):
                    current_val = source_table[key].unwrap()
                    # DELETE PROXY FIRST to avoid structural doubling
                    del source_table[key]
                    # ADD AS REAL TABLE
                    source_table.add(key, current_val)

                _recursive_update(source_table[key], value)
            else:
                # Overwrite existing leaf value only if it's semantically different.
                # Compare unwrapped values, but assign the raw tomlkit Item to
                # preserve inline comments attached to the upstream value.
                current_val = (
                    source_table[key].unwrap()
                    if hasattr(source_table[key], "unwrap")
                    else source_table[key]
                )
                new_val_unwrapped = value.unwrap() if hasattr(value, "unwrap") else value
                if current_val != new_val_unwrapped:
                    source_table[key] = value
        else:
            # New key: assign the raw tomlkit Item to preserve comments
            source_table[key] = value


def merge_ruff_toml(
    source: TOMLDocument, upstream_ruff_doc: TOMLDocument | Table | None
) -> TOMLDocument:
    """Merge the source and upstream tool ruff config with better whitespace preservation."""
    if not upstream_ruff_doc:
        LOGGER.warning("No upstream ruff config section found.")
        return source

    source_tool_ruff = get_ruff_tool_table(source)

    _recursive_update(source_tool_ruff, upstream_ruff_doc)

    # Add a blank separator line after the ruff section — but only when another
    # top-level section follows it. Adding \n\n at end-of-file is unnecessary.
    doc_str = source.as_string()
    ruff_start = doc_str.find("[tool.ruff]")
    # Look for any non-ruff top-level section header after [tool.ruff]
    ruff_is_last = ruff_start == -1 or not re.search(
        r"^\[(?!tool\.ruff)", doc_str[ruff_start:], re.MULTILINE
    )
    if not ruff_is_last and not source_tool_ruff.as_string().endswith("\n\n"):
        source_tool_ruff.add(tomlkit.nl())

    return source


async def check(
    args: Arguments,
) -> int:
    """Check if the local pyproject.toml is in sync with the upstream."""
    print("🔍 Checking Ruff sync status...")
    _source_toml_path = args.source if args.source.is_file() else args.source / "pyproject.toml"

    _source_toml_path = _source_toml_path.resolve(strict=True)
    source_toml_file = TOMLFile(_source_toml_path)
    source_doc = source_toml_file.read()

    async with httpx.AsyncClient() as client:
        file_buffer = await fetch_upstream_config(
            args.upstream, client, branch=args.branch, path=args.path
        )
        LOGGER.info(f"Loaded upstream file from {args.upstream}")

    upstream_ruff_toml = get_ruff_tool_table(
        file_buffer.read(), create_if_missing=False, exclude=args.exclude
    )

    # Create a copy for comparison
    source_doc_copy = tomlkit.parse(source_doc.as_string())
    merged_doc = merge_ruff_toml(source_doc_copy, upstream_ruff_toml)

    if args.semantic:
        source_ruff = source_doc.get("tool", {}).get("ruff")
        merged_ruff = merged_doc.get("tool", {}).get("ruff")

        # Compare unwrapped versions
        source_val = source_ruff.unwrap() if source_ruff is not None else None
        merged_val = merged_ruff.unwrap() if merged_ruff is not None else None

        if source_val == merged_val:
            print("✅ Ruff configuration is semantically in sync.")
            return 0
    elif source_doc.as_string() == merged_doc.as_string():
        print("✅ Ruff configuration is in sync.")
        return 0

    try:
        rel_path = _source_toml_path.relative_to(pathlib.Path.cwd())
    except ValueError:
        rel_path = _source_toml_path
    print(f"❌ Ruff configuration at {rel_path} is out of sync!")
    if args.diff:
        if args.semantic:
            # Semantic diff of the managed section
            from_lines = json.dumps(source_val, indent=2, sort_keys=True).splitlines(keepends=True)
            to_lines = json.dumps(merged_val, indent=2, sort_keys=True).splitlines(keepends=True)
            from_file = "local (semantic)"
            to_file = "upstream (semantic)"
        else:
            # Full text diff of the file
            from_lines = source_doc.as_string().splitlines(keepends=True)
            to_lines = merged_doc.as_string().splitlines(keepends=True)
            from_file = f"local/{_source_toml_path.name}"
            to_file = f"upstream/{_source_toml_path.name}"

        diff = difflib.unified_diff(
            from_lines,
            to_lines,
            fromfile=from_file,
            tofile=to_file,
        )
        sys.stdout.writelines(diff)
    return 1


async def pull(
    args: Arguments,
) -> int:
    """Pull the upstream ruff config and apply it to the source pyproject.toml."""
    print("🔄 Syncing Ruff...")
    _source_toml_path = args.source if args.source.is_file() else args.source / "pyproject.toml"
    source_toml_file = TOMLFile(_source_toml_path.resolve(strict=True))

    # NOTE: there's no particular reason to use async here.
    async with httpx.AsyncClient() as client:
        file_buffer = await fetch_upstream_config(
            args.upstream, client, branch=args.branch, path=args.path
        )
        LOGGER.info(f"Loaded upstream file from {args.upstream}")

    upstream_ruff_toml = get_ruff_tool_table(
        file_buffer.read(), create_if_missing=False, exclude=args.exclude
    )
    merged_toml = merge_ruff_toml(
        source_toml_file.read(),
        upstream_ruff_toml,
    )
    source_toml_file.write(merged_toml)
    print(f"✅ Updated {_source_toml_path.resolve().relative_to(pathlib.Path.cwd())}")
    return 0


PARSER: Final[ArgumentParser] = _get_cli_parser()


def _resolve_upstream(args: Any, config: Mapping[str, Any]) -> URL:
    """Resolve upstream URL from CLI or config."""
    if args.upstream:
        return cast("URL", args.upstream)
    if "upstream" in config:
        config_upstream = config["upstream"]
        if not isinstance(config_upstream, str):
            PARSER.error(
                "❌ upstream in [tool.ruff-sync] must be a string, "
                f"got {type(config_upstream).__name__}"
            )
        upstream = URL(config_upstream)
        LOGGER.info(f"📂 Using upstream from [tool.ruff-sync]: {upstream}")
        return upstream
    PARSER.error(
        "❌ the following arguments are required: upstream "
        "(or define it in [tool.ruff-sync] in pyproject.toml) 💥"
    )


def _resolve_exclude(args: Any, config: Mapping[str, Any]) -> Iterable[str]:
    """Resolve exclude patterns from CLI, config, or default."""
    if args.exclude is not None:
        return cast("Iterable[str]", args.exclude)
    if "exclude" in config:
        exclude = config["exclude"]
        LOGGER.info(f"🚫 Using exclude from [tool.ruff-sync]: {list(exclude)}")
        return cast("Iterable[str]", exclude)
    return _DEFAULT_EXCLUDE


def _resolve_branch(args: Any, config: Mapping[str, Any]) -> str:
    """Resolve branch name from CLI, config, or default."""
    if args.branch:
        return cast("str", args.branch)
    if "branch" in config:
        branch = cast("str", config["branch"])
        LOGGER.info(f"🌿 Using branch from [tool.ruff-sync]: {branch}")
        return branch
    return "main"


def _resolve_path(args: Any, config: Mapping[str, Any]) -> str:
    """Resolve path prefix from CLI, config, or default."""
    if args.path:
        return cast("str", args.path)
    if "path" in config:
        path = cast("str", config["path"])
        LOGGER.info(f"📄 Using path from [tool.ruff-sync]: {path}")
        return path
    return ""


def _resolve_args(args: Any, config: Mapping[str, Any]) -> tuple[URL, Iterable[str], str, str]:
    """Resolve upstream, exclude, branch, and path from CLI and config."""
    upstream = _resolve_upstream(args, config)
    exclude = _resolve_exclude(args, config)
    branch = _resolve_branch(args, config)
    path = _resolve_path(args, config)
    return upstream, exclude, branch, path


def main() -> int:
    # Handle backward compatibility: default to 'pull' if no command provided
    if len(sys.argv) > 1 and sys.argv[1] not in (
        "pull",
        "check",
        "-h",
        "--help",
        "--version",
    ):
        sys.argv.insert(1, "pull")
    elif len(sys.argv) == 1:
        sys.argv.append("pull")

    args = PARSER.parse_args()
    config: Config = get_config(args.source)

    # Configure logging
    log_level = {
        0: logging.WARNING,
        1: logging.INFO,
    }.get(args.verbose, logging.DEBUG)

    LOGGER.setLevel(log_level)
    handler = logging.StreamHandler()
    handler.setFormatter(ColoredFormatter())
    LOGGER.addHandler(handler)
    LOGGER.propagate = False  # Avoid double logging if root is also configured

    upstream, exclude, branch, path = _resolve_args(args, config)

    # Convert non-raw github/gitlab upstream url to the raw equivalent
    upstream = resolve_raw_url(upstream, branch=branch, path=path)

    # Create Arguments object
    exec_args = Arguments(
        command=args.command,
        upstream=upstream,
        source=args.source,
        exclude=exclude,
        verbose=args.verbose,
        branch=branch,
        path=path,
        semantic=getattr(args, "semantic", False),
        diff=getattr(args, "diff", True),
    )

    if exec_args.command == "check":
        return asyncio.run(check(exec_args))
    return asyncio.run(pull(exec_args))


if __name__ == "__main__":
    sys.exit(main())
