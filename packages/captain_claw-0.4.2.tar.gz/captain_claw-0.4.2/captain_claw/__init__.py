"""Captain Claw - A powerful console-based AI agent."""

__version__ = "0.4.2"
__author__ = "Stevica Kuharski"

from captain_claw.config import Config
from captain_claw.main import main

__all__ = ["Config", "main", "__version__"]
