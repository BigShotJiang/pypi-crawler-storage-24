#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Copyright 2025. Huawei Technologies Co.,Ltd. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ==============================================================================

from abc import ABC
import copy
import os
import functools
import json
import glob
from typing import List

from .config import ConfigMgr
from .interface import ToDict
from .topo import TopoSingleFactory
from .dcmi import dcmi
from .npu import NPU
from .roce import get_npu_roce_ip
from .product_card import process_rootinfo_card
from .product_server import process_rootinfo_server
from .product_pod import process_rootinfo_pod

from .const import (
    ROOTINFO_VERSION,
)

def exclude_fields(*fields):
    """Decorator to exclude specified field names when converting objects to Dict"""

    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            data = func(*args, **kwargs)
            for field in fields:
                data.pop(field, None)
            return data

        return wrapper

    return decorator


class RootInfoEncoder(json.JSONEncoder):
    """Serializer: Convert objects to dictionaries via to_dict method for serialization"""

    def default(self, obj):
        if isinstance(obj, ToDict):
            return obj.to_dict()
        return json.JSONEncoder.default(self, obj)


class RootInfo(ToDict):
    version = ROOTINFO_VERSION

    def __init__(self, rank_list: List[NPU] = None):
        self.version = RootInfo.version
        self.topo_file_path = ""
        self.rank_count = 0
        self.rank_list = [] if not rank_list else rank_list

    @exclude_fields()
    def to_dict(self):
        self.rank_count = len(self.rank_list)
        return copy.deepcopy(self.__dict__)



def get_topo_file_by_mainboard_id(mainboard_id):
    topo_map = {
        3: "/usr/local/Ascend/driver/topo/950/atlas_950_1.json",
        7: "/usr/local/Ascend/driver/topo/950/atlas_950_1.json",
        37: "/usr/local/Ascend/driver/topo/950/atlas_850_1.json",
        39: "/usr/local/Ascend/driver/topo/950/atlas_850_1.json",
        108: "/usr/local/Ascend/driver/topo/950/atlas_350_3.json",
    }
    return topo_map[mainboard_id]

def construct_rootinfo(params):
    for key, value in params.items():
        ConfigMgr().set(key, value)
    

    start_id = int(ConfigMgr().get("start_id"))
    if start_id > 0:
        rank_count = int(ConfigMgr().get("rank_count"))
        npus = [i for i in range(start_id, (start_id + rank_count))]
    else:
        npus = sorted([int(i[len("/dev/davinci"):]) for i in glob.glob("/dev/davinci[0-9]*")])

    if len(npus) == 0:
        npus = list(range(params["rank_count"]))

    rootinfo = RootInfo([])
    dcmi.dcmi_init()
    if dcmi.is_dcmiv2():
        for npu_id in range(len(npus)):
            phy_id = dcmi.get_phyid_from_logicid(npu_id)
            rootinfo.rank_list.append(NPU(npu_id, phy_id))
    else:
        for npu_id in npus:
            rootinfo.rank_list.append(NPU(npu_id, npu_id))

    
    try:
        mainboard_id = dcmi.get_mainboard_id(npus[0])
        spinfo = dcmi.get_super_pod_info(npus[0])
        ConfigMgr().set("super_pod_id", spinfo.super_pod_id)
        ConfigMgr().set("chassis_id", spinfo.chassis_id)
        ConfigMgr().set("server_index", spinfo.server_index)
        ConfigMgr().set("mainboard_id", mainboard_id)
    except Exception as e:
        print(e)
        pass

    topo_file = ConfigMgr().get("topo_path")
    if topo_file is None:
        topo_file = get_topo_file_by_mainboard_id(mainboard_id)
        ConfigMgr().set("topo_path", topo_file)

    rootinfo.topo_file_path = ConfigMgr().get("topo_path")
    TopoSingleFactory.set_topo_path(topo_file)
    if mainboard_id in (3, 7):
        process_rootinfo_pod(rootinfo)
    if mainboard_id in (35, 37, 39):
        process_rootinfo_server(rootinfo)
    if mainboard_id == 108:
        process_rootinfo_card(rootinfo)

    rootinfo_json = json.dumps(rootinfo, indent=2, cls=RootInfoEncoder)
    try:
        output = ConfigMgr().get("output")
    except:
        pass

    if output is None:
        output = "new_hccl_rootinfo.json"
    with open(output, "w+") as f:
        f.write(rootinfo_json)
    print(f"rankinfo [{output}] generated")
