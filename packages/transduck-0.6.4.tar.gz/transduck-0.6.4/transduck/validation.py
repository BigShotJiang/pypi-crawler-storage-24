"""Placeholder extraction and translation validation."""

import re


# Matches: {name}, {{ count }}, %s, %d, ${value}
_PLACEHOLDER_PATTERNS = [
    r"\{\{[^}]*\}\}",   # {{ count }}
    r"\$\{[^}]+\}",     # ${value}
    r"\{[^{}]+\}",      # {name}
    r"%[sd]",           # %s, %d
]

_PLACEHOLDER_RE = re.compile("|".join(_PLACEHOLDER_PATTERNS))


def extract_placeholders(text: str) -> set[str]:
    return set(_PLACEHOLDER_RE.findall(text))


def validate_translation(source_text: str, translated_text: str) -> bool:
    if not translated_text or not translated_text.strip():
        return False

    source_placeholders = extract_placeholders(source_text)
    if not source_placeholders:
        return True

    translated_placeholders = extract_placeholders(translated_text)
    return source_placeholders.issubset(translated_placeholders)
