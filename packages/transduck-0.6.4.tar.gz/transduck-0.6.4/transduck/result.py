"""TranslationResult — a str subclass carrying translation metadata."""


class TranslationResult(str):
    """A string that also carries translation metadata.

    Behaves identically to ``str`` in all contexts (templates, f-strings,
    concatenation, ``==``).  The extra attributes ``pending``, ``source_lang``,
    and ``lang`` are available for introspection.
    """

    pending: bool
    source_lang: str
    lang: str
    source: str | None

    def __new__(cls, text: str, *, pending: bool, source_lang: str, lang: str,
                source: str | None = None) -> "TranslationResult":
        instance = super().__new__(cls, text)
        instance.pending = pending
        instance.source_lang = source_lang
        instance.lang = lang
        instance.source = source
        return instance
