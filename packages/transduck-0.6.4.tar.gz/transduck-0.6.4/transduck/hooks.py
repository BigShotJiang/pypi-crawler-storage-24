"""TransDuck hooks — event types and dispatch helpers."""

import logging
from dataclasses import dataclass
from typing import Callable

logger = logging.getLogger("transduck")


@dataclass(frozen=True)
class TranslationEvent:
    """Event passed to translation hooks.

    Field names match TranslationResult for consistency.
    """

    source_text: str
    translated_text: str
    source_lang: str
    lang: str  # target language — matches TranslationResult.lang
    context: str | None
    project_context: str
    source: str  # "cache" | "translated" | "shared_cache"
    plural: bool = False
    plural_category: str | None = None
    plural_forms: dict[str, str] | None = None


def _fire_hooks(
    hooks: list[Callable],
    event: TranslationEvent,
    per_call_hook: Callable | None = None,
) -> None:
    """Invoke global hooks then per-call hook. Errors are logged, never raised."""
    for hook in hooks:
        try:
            hook(event)
        except Exception:
            logger.warning("Global translation hook error", exc_info=True)
    if per_call_hook is not None:
        try:
            per_call_hook(event)
        except Exception:
            logger.warning("Per-call translation hook error", exc_info=True)
