"""
GPU Hardware State & Identification diagnostics.
Uses pynvml for GPU enumeration and metrics, sysfs/proc for kernel-level detail.
"""

from pathlib import Path
from typing import Dict, List, Optional
from dataclasses import asdict
from datetime import datetime
import json
import pynvml
from .constants import ARCHITECTURE_MAP, THROTTLE_REASONS
from .models import GPUDevice, GPUHardwareResult, GPUProcess
from .nvml_mixin import NVMLMixin

_CLOCKS_THROTTLE_REASON_HW_SLOWDOWN = getattr(
    pynvml, "nvmlClocksThrottleReasonHwSlowdown", 0x0000000000000008
)


class GPUHardwareDiagnostics(NVMLMixin):
    """
    GPU Hardware State & Identification diagnostics.

    Collects:
    - GPU enumeration via pynvml (NVML)
    - GPU properties (name, VBIOS, memory, serial, UUID, ECC, thermals, PCIe)
    - Per-GPU power state from /proc/driver/nvidia/gpus/<BUS_ID>/power
    - Per-GPU sysfs power management info
    """

    PROC_DRIVER_GPUS_PATH = Path("/proc/driver/nvidia/gpus")

    def __init__(self):
        super().__init__()

    def normalize_pci_bus_id(self, pci_bus_id: str) -> str:
        if pci_bus_id.count(":") >= 2:
            domain, rest = pci_bus_id.split(":", 1)
            return f"{domain[-4:]}:{rest}".lower()
        return pci_bus_id.lower()

    def _string_or_none(self, value: int | float | str | bool | None) -> Optional[str]:
        if isinstance(value,  str):
            return value if value is not None else None
        return str(value) if value is not None else None


    
    def _memory_info_to_mib(self, bytes_value: Optional[int]) -> Optional[str]:
        return f"{bytes_value // (1024 * 1024)} MiB" if bytes_value is not None else None

    def _format_watts(self, milliwatts: Optional[int]) -> Optional[str]:
        return f"{milliwatts / 1000:.1f} W" if milliwatts is not None else None

    def _format_mhz(self, mhz: Optional[int]) -> Optional[str]:
        return f"{mhz} MHz" if mhz is not None else None
    
    def _len_to_string(self, value: list | tuple ) -> str:
        try:
            return str(len(value)) if value is not None else None
        except Exception:
            return None

    def _decode_throttle_reasons(self, bitmask):
        """Decode throttle reason bitmask into a human-readable list."""
        if bitmask is None:
            return None
        reasons = []
        for bit, name in THROTTLE_REASONS.items():
            if bitmask & bit:
                reasons.append(name)
        return reasons if reasons else ["None"]

    def _format_ns_to_seconds(self, nanoseconds: int | None) -> Optional[str]:
        """Convert nanoseconds to a formatted seconds string."""
        if nanoseconds is None:
            return None
        return f"{nanoseconds / 1_000_000_000:.3f} s"

    def _format_energy(self, millijoules: int | None) -> Optional[str]:
        """Convert millijoules to a human-readable energy string."""
        if millijoules is None:
            return None
        joules = millijoules / 1000.0
        if joules >= 3_600_000:
            return f"{joules / 3_600_000:.2f} kWh"
        return f"{joules:.2f} J"

        

    def enumerate_gpus(self) -> List[GPUDevice]:
        """Enumerate GPUs with full metrics via pynvml."""
        if not self._init_nvml():
            return []

        driver_version = self._safe_nvml_call(pynvml.nvmlSystemGetDriverVersion)
        gpu_count = self._safe_nvml_call(pynvml.nvmlDeviceGetCount, default=0)

        gpus = []
        for i in range(gpu_count):
            handle = self._safe_nvml_call(pynvml.nvmlDeviceGetHandleByIndex, i)
            if handle is None:
                continue

            pci_info = self._safe_nvml_call(pynvml.nvmlDeviceGetPciInfo, handle)
            bus_id = pci_info.busId if pci_info else None

            # Memory
            mem_info = self._safe_nvml_call(pynvml.nvmlDeviceGetMemoryInfo, handle)
            mem_total_mib = self._memory_info_to_mib(mem_info.total if mem_info else None)
            mem_used_mib = self._memory_info_to_mib(mem_info.used if mem_info else None)
            mem_free_mib = self._memory_info_to_mib(mem_info.free if mem_info else None)

            # Power
            power_usage_mw = self._safe_nvml_call(pynvml.nvmlDeviceGetPowerUsage, handle)
            power_limit_mw = self._safe_nvml_call(pynvml.nvmlDeviceGetPowerManagementLimit, handle)

            # Clocks
            clock_graphics = self._safe_nvml_call(
                pynvml.nvmlDeviceGetClockInfo, handle, pynvml.NVML_CLOCK_GRAPHICS
            )
            clock_sm = self._safe_nvml_call(
                pynvml.nvmlDeviceGetClockInfo, handle, pynvml.NVML_CLOCK_SM
            )
            clock_mem = self._safe_nvml_call(
                pynvml.nvmlDeviceGetClockInfo, handle, pynvml.NVML_CLOCK_MEM
            )
            clock_max_graphics = self._safe_nvml_call(
                pynvml.nvmlDeviceGetMaxClockInfo, handle, pynvml.NVML_CLOCK_GRAPHICS
            )
            clock_max_mem = self._safe_nvml_call(
                pynvml.nvmlDeviceGetMaxClockInfo, handle, pynvml.NVML_CLOCK_MEM
            )

            # Persistence mode
            persistence_mode = self._safe_nvml_call(pynvml.nvmlDeviceGetPersistenceMode, handle)

            # ECC mode
            ecc_mode_result = self._safe_nvml_call(pynvml.nvmlDeviceGetEccMode, handle)

            # Compute mode
            compute_mode_raw = self._safe_nvml_call(pynvml.nvmlDeviceGetComputeMode, handle)
            compute_mode_map = {
                0: "Default",
                1: "Exclusive Thread",
                2: "Prohibited",
                3: "Exclusive Process",
            }

            # ECC errors
            ecc_corr_vol = self._safe_nvml_call(
                pynvml.nvmlDeviceGetTotalEccErrors, handle,
                pynvml.NVML_MEMORY_ERROR_TYPE_CORRECTED, pynvml.NVML_VOLATILE_ECC
            )
            ecc_corr_agg = self._safe_nvml_call(
                pynvml.nvmlDeviceGetTotalEccErrors, handle,
                pynvml.NVML_MEMORY_ERROR_TYPE_CORRECTED, pynvml.NVML_AGGREGATE_ECC
            )
            ecc_uncorr_vol = self._safe_nvml_call(
                pynvml.nvmlDeviceGetTotalEccErrors, handle,
                pynvml.NVML_MEMORY_ERROR_TYPE_UNCORRECTED, pynvml.NVML_VOLATILE_ECC
            )
            ecc_uncorr_agg = self._safe_nvml_call(
                pynvml.nvmlDeviceGetTotalEccErrors, handle,
                pynvml.NVML_MEMORY_ERROR_TYPE_UNCORRECTED, pynvml.NVML_AGGREGATE_ECC
            )

            # Retired pages
            retired_sbe = self._safe_nvml_call(
                pynvml.nvmlDeviceGetRetiredPages, handle,
                pynvml.NVML_PAGE_RETIREMENT_CAUSE_MULTIPLE_SINGLE_BIT_ECC_ERRORS
            )
            retired_dbe = self._safe_nvml_call(
                pynvml.nvmlDeviceGetRetiredPages, handle,
                pynvml.NVML_PAGE_RETIREMENT_CAUSE_DOUBLE_BIT_ECC_ERROR
            )
            retired_pending = self._safe_nvml_call(
                pynvml.nvmlDeviceGetRetiredPagesPendingStatus, handle
            )

            # Throttle reasons
            throttle_reasons = self._safe_nvml_call(
                pynvml.nvmlDeviceGetCurrentClocksThrottleReasons, handle
            )

            # Temperature
            temp_gpu = self._safe_nvml_call(
                pynvml.nvmlDeviceGetTemperature, handle, pynvml.NVML_TEMPERATURE_GPU
            )

            # PCIe link info
            pcie_gen_cur = self._safe_nvml_call(pynvml.nvmlDeviceGetCurrPcieLinkGeneration, handle)
            pcie_gen_max = self._safe_nvml_call(pynvml.nvmlDeviceGetMaxPcieLinkGeneration, handle)
            pcie_width_cur = self._safe_nvml_call(pynvml.nvmlDeviceGetCurrPcieLinkWidth, handle)
            pcie_width_max = self._safe_nvml_call(pynvml.nvmlDeviceGetMaxPcieLinkWidth, handle)

            # Remapped rows
            remapped = self._safe_nvml_call(pynvml.nvmlDeviceGetRemappedRows, handle)
            remapped_corr = remapped[0] if remapped else None
            remapped_uncorr = remapped[1] if remapped else None
            remapped_pending = remapped[2] if remapped else None
            remapped_failure = remapped[3] if remapped else None

            # Memory temperature (HBM)
            temp_mem = None
            nvml_fi_mem_temp = getattr(pynvml, "NVML_FI_DEV_MEMORY_TEMP", None)
            if nvml_fi_mem_temp is not None:
                field_val = self._safe_nvml_call(
                    pynvml.nvmlDeviceGetFieldValues, handle, [nvml_fi_mem_temp]
                )
                if field_val and len(field_val) > 0:
                    val = field_val[0]
                    # nvmlReturn_t == 0 means success
                    if hasattr(val, "nvmlReturn") and val.nvmlReturn == 0:
                        temp_mem = val.value.uiVal if hasattr(val.value, "uiVal") else val.value

            # Enforced power limit and hardware constraints
            enforced_power_mw = self._safe_nvml_call(pynvml.nvmlDeviceGetEnforcedPowerLimit, handle)
            power_constraints = self._safe_nvml_call(
                pynvml.nvmlDeviceGetPowerManagementLimitConstraints, handle
            )
            power_min_mw = power_constraints[0] if power_constraints else None
            power_max_mw = power_constraints[1] if power_constraints else None

            # Running processes
            processes = []
            compute_procs = self._safe_nvml_call(
                pynvml.nvmlDeviceGetComputeRunningProcesses, handle
            ) or []
            graphics_procs = self._safe_nvml_call(
                pynvml.nvmlDeviceGetGraphicsRunningProcesses, handle
            ) or []
            for proc in compute_procs + graphics_procs:
                proc_name = self._safe_nvml_call(
                    pynvml.nvmlSystemGetProcessName, proc.pid
                )
                used_mem = getattr(proc, "usedGpuMemory", None)
                processes.append(GPUProcess(
                    pid=proc.pid,
                    name=proc_name,
                    used_gpu_memory=self._memory_info_to_mib(used_mem),
                ))

            # Utilization rates
            util_rates = self._safe_nvml_call(pynvml.nvmlDeviceGetUtilizationRates, handle)
            gpu_util = self._string_or_none(util_rates.gpu) if util_rates else None
            mem_util = self._string_or_none(util_rates.memory) if util_rates else None

            # Performance state (P0-P15)
            perf_state = self._safe_nvml_call(pynvml.nvmlDeviceGetPerformanceState, handle)
            perf_state_str = f"P{perf_state}" if perf_state is not None else None

            # Total energy consumption (millijoules)
            energy_mj = self._safe_nvml_call(pynvml.nvmlDeviceGetTotalEnergyConsumption, handle)

            # Violation status
            violation_power_raw = self._safe_nvml_call(
                pynvml.nvmlDeviceGetViolationStatus, handle, pynvml.NVML_PERF_POLICY_POWER
            )
            violation_thermal_raw = self._safe_nvml_call(
                pynvml.nvmlDeviceGetViolationStatus, handle, pynvml.NVML_PERF_POLICY_THERMAL
            )
            violation_reliability_raw = self._safe_nvml_call(
                pynvml.nvmlDeviceGetViolationStatus, handle, pynvml.NVML_PERF_POLICY_RELIABILITY
            )
            violation_board_limit_raw = self._safe_nvml_call(
                pynvml.nvmlDeviceGetViolationStatus, handle, pynvml.NVML_PERF_POLICY_BOARD_LIMIT
            )
            violation_power_ns = violation_power_raw.violationTime if violation_power_raw else None
            violation_thermal_ns = violation_thermal_raw.violationTime if violation_thermal_raw else None
            violation_reliability_ns = violation_reliability_raw.violationTime if violation_reliability_raw else None
            violation_board_limit_ns = violation_board_limit_raw.violationTime if violation_board_limit_raw else None

            # Temperature thresholds
            temp_shutdown = self._safe_nvml_call(
                pynvml.nvmlDeviceGetTemperatureThreshold, handle, pynvml.NVML_TEMPERATURE_THRESHOLD_SHUTDOWN
            )
            temp_slowdown = self._safe_nvml_call(
                pynvml.nvmlDeviceGetTemperatureThreshold, handle, pynvml.NVML_TEMPERATURE_THRESHOLD_SLOWDOWN
            )
            temp_mem_max = self._safe_nvml_call(
                pynvml.nvmlDeviceGetTemperatureThreshold, handle, pynvml.NVML_TEMPERATURE_THRESHOLD_MEM_MAX
            )
            temp_gpu_max = self._safe_nvml_call(
                pynvml.nvmlDeviceGetTemperatureThreshold, handle, pynvml.NVML_TEMPERATURE_THRESHOLD_GPU_MAX
            )

            # PCIe throughput
            pcie_tx = self._safe_nvml_call(
                pynvml.nvmlDeviceGetPcieThroughput, handle, pynvml.NVML_PCIE_UTIL_TX_BYTES
            )
            pcie_rx = self._safe_nvml_call(
                pynvml.nvmlDeviceGetPcieThroughput, handle, pynvml.NVML_PCIE_UTIL_RX_BYTES
            )

            # PCIe error counters via field values
            pcie_fields = [
                (173, "correctable"), (180, "fatal"), (179, "nonfatal"),
                (94, "replay"), (169, "l0_to_recovery")
            ]
            pcie_error_vals = {}
            pcie_field_result = self._safe_nvml_call(
                pynvml.nvmlDeviceGetFieldValues, handle, [f[0] for f in pcie_fields]
            )
            if pcie_field_result and len(pcie_field_result) == len(pcie_fields):
                for idx, (field_id, field_name) in enumerate(pcie_fields):
                    fv = pcie_field_result[idx]
                    if hasattr(fv, "nvmlReturn") and fv.nvmlReturn == 0:
                        pcie_error_vals[field_name] = str(
                            fv.value.uiVal if hasattr(fv.value, "uiVal") else fv.value
                        )

            # BAR1 memory info
            bar1_info = self._safe_nvml_call(pynvml.nvmlDeviceGetBAR1MemoryInfo, handle)

            # Architecture
            arch_raw = self._safe_nvml_call(pynvml.nvmlDeviceGetArchitecture, handle)
            arch_name = ARCHITECTURE_MAP.get(arch_raw, f"Unknown({arch_raw})") if arch_raw is not None else None

            # GPU cores
            gpu_cores_raw = self._safe_nvml_call(pynvml.nvmlDeviceGetNumGpuCores, handle)

            # CUDA compute capability
            cuda_cc = self._safe_nvml_call(pynvml.nvmlDeviceGetCudaComputeCapability, handle)
            cuda_cc_str = f"{cuda_cc[0]}.{cuda_cc[1]}" if cuda_cc else None

            # GSP firmware version
            gsp_fw_raw = self._safe_nvml_call(pynvml.nvmlDeviceGetGspFirmwareVersion, handle)
            gsp_fw_version = gsp_fw_raw.decode("utf-8") if isinstance(gsp_fw_raw, bytes) else gsp_fw_raw

            # NVLink throughput via field values (138=TX, 139=RX)
            nvlink_tp_tx = None
            nvlink_tp_rx = None
            nvlink_field_result = self._safe_nvml_call(
                pynvml.nvmlDeviceGetFieldValues, handle, [138, 139]
            )
            if nvlink_field_result and len(nvlink_field_result) >= 2:
                fv_tx = nvlink_field_result[0]
                if hasattr(fv_tx, "nvmlReturn") and fv_tx.nvmlReturn == 0:
                    nvlink_tp_tx = str(fv_tx.value.uiVal if hasattr(fv_tx.value, "uiVal") else fv_tx.value)
                fv_rx = nvlink_field_result[1]
                if hasattr(fv_rx, "nvmlReturn") and fv_rx.nvmlReturn == 0:
                    nvlink_tp_rx = str(fv_rx.value.uiVal if hasattr(fv_rx.value, "uiVal") else fv_rx.value)

            # MIG mode
            mig_mode = self._safe_nvml_call(pynvml.nvmlDeviceGetMigMode, handle)
            mig_current = None
            mig_pending = None
            if mig_mode is not None:
                mig_current = "Enabled" if mig_mode[0] == pynvml.NVML_FEATURE_ENABLED else "Disabled"
                mig_pending = "Enabled" if mig_mode[1] == pynvml.NVML_FEATURE_ENABLED else "Disabled"

            # Default power limit
            default_power_mw = self._safe_nvml_call(pynvml.nvmlDeviceGetPowerManagementDefaultLimit, handle)

            # Power source
            power_source_fn = getattr(pynvml, 'nvmlDeviceGetPowerSource', None)
            power_source_val = None
            if power_source_fn:
                ps_raw = self._safe_nvml_call(power_source_fn, handle)
                if ps_raw is not None:
                    power_source_val = "AC" if ps_raw == 0 else "Battery" if ps_raw == 1 else f"Unknown({ps_raw})"

            # Accounting mode
            acct_raw = self._safe_nvml_call(pynvml.nvmlDeviceGetAccountingMode, handle)
            acct_mode = None
            if acct_raw is not None:
                acct_mode = "Enabled" if acct_raw == pynvml.NVML_FEATURE_ENABLED else "Disabled"

            # Supported throttle reasons
            supported_throttle = self._safe_nvml_call(pynvml.nvmlDeviceGetSupportedClocksThrottleReasons, handle)

            gpu = GPUDevice(
                index=i,
                name=self._safe_nvml_call(pynvml.nvmlDeviceGetName, handle, default="Unknown"),
                pci_bus_id=bus_id,
                driver_version=driver_version,
                vbios_version=self._safe_nvml_call(pynvml.nvmlDeviceGetVbiosVersion, handle),
                serial=self._safe_nvml_call(pynvml.nvmlDeviceGetSerial, handle),
                uuid=self._safe_nvml_call(pynvml.nvmlDeviceGetUUID, handle),
                memory_total=mem_total_mib,
                memory_used=mem_used_mib,
                memory_free=mem_free_mib,
                # Power
                power_draw=self._format_watts(power_usage_mw),
                power_limit=self._format_watts(power_limit_mw),
                power_limit_enforced=self._format_watts(enforced_power_mw),
                power_limit_max=self._format_watts(power_max_mw),
                power_limit_min=self._format_watts(power_min_mw),
                # Clocks
                clock_graphics=self._format_mhz(clock_graphics),
                clock_sm=self._format_mhz(clock_sm),
                clock_memory=self._format_mhz(clock_mem),
                clock_max_graphics=self._format_mhz(clock_max_graphics),
                clock_max_memory=self._format_mhz(clock_max_mem),
                # Modes
                persistence_mode="Enabled" if persistence_mode == pynvml.NVML_FEATURE_ENABLED else "Disabled" if persistence_mode is not None else None,
                ecc_mode="Enabled" if ecc_mode_result and ecc_mode_result[0] == pynvml.NVML_FEATURE_ENABLED else "Disabled" if ecc_mode_result is not None else None,
                compute_mode=compute_mode_map.get(compute_mode_raw) if compute_mode_raw is not None else None,
                # ECC
                ecc_errors_corrected_volatile=self._string_or_none(ecc_corr_vol),
                ecc_errors_corrected_aggregate=self._string_or_none(ecc_corr_agg),
                ecc_errors_uncorrected_volatile=self._string_or_none(ecc_uncorr_vol),
                ecc_errors_uncorrected_aggregate=self._string_or_none(ecc_uncorr_agg),
                # Retired pages
                retired_pages_single_bit_ecc=self._len_to_string(retired_sbe),
                retired_pages_double_bit=self._len_to_string(retired_dbe),
                retired_pages_pending=self._string_or_none(retired_pending),
                # Remapped rows
                remapped_rows_correctable=remapped_corr,
                remapped_rows_uncorrectable=remapped_uncorr,
                remapped_rows_pending=bool(remapped_pending) if remapped_pending is not None else None,
                remapped_rows_failure=bool(remapped_failure) if remapped_failure is not None else None,
                # Temperature
                temperature_gpu=self._string_or_none(temp_gpu),
                temperature_memory=self._string_or_none(temp_mem),
                # Throttle
                clocks_throttle_reasons_active=hex(throttle_reasons) if throttle_reasons is not None else None,
                clocks_throttle_reasons_hw_slowdown=str(
                    bool(throttle_reasons & _CLOCKS_THROTTLE_REASON_HW_SLOWDOWN)
                ) if throttle_reasons is not None else None,
                # PCIe
                pcie_link_gen_current=self._string_or_none(pcie_gen_cur),
                pcie_link_gen_max=self._string_or_none(pcie_gen_max),
                pcie_link_width_current=self._string_or_none(pcie_width_cur),
                pcie_link_width_max=self._string_or_none(pcie_width_max),
                # Utilization
                gpu_utilization=gpu_util,
                memory_utilization=mem_util,
                # Performance state
                performance_state=perf_state_str,
                # Energy
                total_energy_consumption=self._format_energy(energy_mj),
                # Violation status
                violation_power=self._format_ns_to_seconds(violation_power_ns),
                violation_thermal=self._format_ns_to_seconds(violation_thermal_ns),
                violation_reliability=self._format_ns_to_seconds(violation_reliability_ns),
                violation_board_limit=self._format_ns_to_seconds(violation_board_limit_ns),
                # Temperature thresholds
                temperature_shutdown=self._string_or_none(temp_shutdown),
                temperature_slowdown=self._string_or_none(temp_slowdown),
                temperature_mem_max=self._string_or_none(temp_mem_max),
                temperature_gpu_max=self._string_or_none(temp_gpu_max),
                # PCIe throughput
                pcie_tx_throughput_kbps=self._string_or_none(pcie_tx),
                pcie_rx_throughput_kbps=self._string_or_none(pcie_rx),
                # PCIe error counters
                pcie_correctable_errors=pcie_error_vals.get("correctable"),
                pcie_fatal_errors=pcie_error_vals.get("fatal"),
                pcie_nonfatal_errors=pcie_error_vals.get("nonfatal"),
                pcie_replay_counter=pcie_error_vals.get("replay"),
                pcie_l0_to_recovery_counter=pcie_error_vals.get("l0_to_recovery"),
                # BAR1 memory
                bar1_total=self._memory_info_to_mib(bar1_info.bar1Total if bar1_info else None),
                bar1_used=self._memory_info_to_mib(bar1_info.bar1Used if bar1_info else None),
                bar1_free=self._memory_info_to_mib(bar1_info.bar1Free if bar1_info else None),
                # Decoded throttle reasons
                clocks_throttle_reasons_decoded=self._decode_throttle_reasons(throttle_reasons),
                # Architecture and core count
                architecture=arch_name,
                gpu_cores=self._string_or_none(gpu_cores_raw),
                cuda_compute_capability=cuda_cc_str,
                # NVLink throughput
                nvlink_throughput_data_tx=nvlink_tp_tx,
                nvlink_throughput_data_rx=nvlink_tp_rx,
                # GSP firmware
                gsp_firmware_version=self._string_or_none(gsp_fw_version),
                # MIG mode
                mig_mode_current=mig_current,
                mig_mode_pending=mig_pending,
                # Default power limit
                power_limit_default=self._format_watts(default_power_mw),
                # Power source
                power_source=power_source_val,
                # Accounting mode
                accounting_mode=acct_mode,
                # Supported throttle reasons
                clocks_throttle_reasons_supported=hex(supported_throttle) if supported_throttle is not None else None,
                # Processes
                processes=processes,
            )
            gpus.append(gpu)

        return gpus

    async def get_sysfs_power_info(self, pci_bus_id: str) -> Dict[str, Optional[str]]:
        """Read sysfs power management settings for GPU."""
        if not pci_bus_id:
            return {}

        normalized_bus_id = self.normalize_pci_bus_id(pci_bus_id)
        device_path = Path(f"/sys/bus/pci/devices/{normalized_bus_id}")

        power_info = {}
        for attr in ["control", "runtime_status", "runtime_usage"]:
            attr_path = device_path / "power" / attr
            try:
                if attr_path.exists():
                    power_info[attr] = attr_path.read_text().strip()
                else:
                    power_info[attr] = None
            except Exception:
                power_info[attr] = None

        return power_info

    async def list_proc_gpus(self) -> List[str]:
        """List all GPU directories in /proc/driver/nvidia/gpus/"""
        if not self.PROC_DRIVER_GPUS_PATH.exists():
            return []

        try:
            return [d.name for d in self.PROC_DRIVER_GPUS_PATH.iterdir() if d.is_dir()]
        except Exception:
            return []

    async def run_all_checks(self) -> GPUHardwareResult:
        """Run all GPU hardware identification checks."""
        result = GPUHardwareResult(timestamp=datetime.now())

        try:
            result.gpus = self.enumerate_gpus()
        except Exception as e:
            result.errors.append(f"Failed to enumerate GPUs: {e}")
            return result
        finally:
            self._shutdown_nvml()

        result.total_gpus = len(result.gpus)

        if result.total_gpus == 0:
            result.errors.append("No GPUs detected")
            return result

        # Get sysfs power management detail for each GPU
        for gpu in result.gpus:
            if gpu.pci_bus_id:
                sysfs_power = await self.get_sysfs_power_info(gpu.pci_bus_id)
                gpu.sysfs_power_control = sysfs_power.get("control")
                gpu.sysfs_runtime_status = sysfs_power.get("runtime_status")
                gpu.sysfs_runtime_usage = sysfs_power.get("runtime_usage")

            (
                ecc_error_message,
                retired_pages_message,
                remapped_rows_message,
                clocks_throttle_message,
                pcie_link_message,
                pcie_link_width_message,
                pcie_errors_message,
                thermal_headroom_message,
                violations_message,
                mig_mode_message,
                power_limit_message,
            ) = gpu.check_all_errors()

            if ecc_error_message:
                result.errors.append(ecc_error_message)
            if retired_pages_message:
                result.warnings.append(retired_pages_message)
            if remapped_rows_message:
                result.errors.append(remapped_rows_message)
            if clocks_throttle_message:
                result.warnings.append(clocks_throttle_message)
            if pcie_link_message:
                result.warnings.append(pcie_link_message)
            if pcie_link_width_message:
                result.warnings.append(pcie_link_width_message)
            if pcie_errors_message:
                result.errors.append(pcie_errors_message)
            if thermal_headroom_message:
                result.warnings.append(thermal_headroom_message)
            if violations_message:
                result.warnings.append(violations_message)
            if mig_mode_message:
                result.warnings.append(mig_mode_message)
            if power_limit_message:
                result.warnings.append(power_limit_message)

        proc_gpus = await self.list_proc_gpus()
        nvml_bus_ids = {self.normalize_pci_bus_id(gpu.pci_bus_id) for gpu in result.gpus if gpu.pci_bus_id}

        for proc_gpu in proc_gpus:
            if proc_gpu.lower() not in nvml_bus_ids:
                result.warnings.append(f"GPU {proc_gpu} found in /proc but not reported by NVML")

        return result

    def format_report(self, result: GPUHardwareResult) -> str:
        """Format results as a JSON report."""
        result_dict = asdict(result)
        result_dict.pop("warnings", None)
        return json.dumps(result_dict, indent=4, default=str)


async def run_gpu_hardware_diagnostics():
    """Run GPU hardware diagnostics and return the JSON report."""
    diagnostics = GPUHardwareDiagnostics()
    result = await diagnostics.run_all_checks()
    return diagnostics.format_report(result)
