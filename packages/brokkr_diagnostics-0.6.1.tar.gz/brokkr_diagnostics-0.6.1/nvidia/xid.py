"""
NVIDIA Xid error code lookup table.

Provides a comprehensive mapping of GPU Xid error codes to their names,
descriptions, severity levels, and suggested actions. Used by kernel log
analysis to enrich detected Xid errors with actionable context.

Reference: https://docs.nvidia.com/deploy/xid-errors/index.html
"""

from dataclasses import dataclass
from typing import Optional


@dataclass(frozen=True)
class XidEntry:
    """A single Xid error code entry."""

    code: int
    name: str
    description: str
    severity: str  # "critical", "error", "warning", "info"
    action: str


# ---------------------------------------------------------------------------
# Comprehensive Xid error code table
# ---------------------------------------------------------------------------
XID_CODES: dict[int, XidEntry] = {
    8: XidEntry(
        code=8,
        name="GPU Stopped Processing",
        description="GPU stopped processing - possible hang or hardware fault",
        severity="critical",
        action="Check GPU thermals and power; may require RMA if persistent",
    ),
    13: XidEntry(
        code=13,
        name="Graphics Engine Exception",
        description="Graphics engine exception - shader or execution unit error",
        severity="error",
        action="Update driver; check application for illegal memory access",
    ),
    31: XidEntry(
        code=31,
        name="GPU Memory Page Fault",
        description="GPU memory page fault due to invalid address access",
        severity="error",
        action="Check application for out-of-bounds GPU memory access; update driver",
    ),
    32: XidEntry(
        code=32,
        name="Invalid Push Buffer",
        description="Invalid or corrupted push buffer entry",
        severity="error",
        action="Update driver; check for system memory corruption or faulty RAM",
    ),
    38: XidEntry(
        code=38,
        name="Driver Firmware Error",
        description="Driver firmware error during command processing",
        severity="error",
        action="Update GPU driver and VBIOS firmware",
    ),
    40: XidEntry(
        code=40,
        name="GPU Correctable ECC Error",
        description="SRAM correctable ECC error detected",
        severity="info",
        action="Monitor - informational, but high counts warrant investigation",
    ),
    41: XidEntry(
        code=41,
        name="GPU Correctable ECC Count Exceeded",
        description="Correctable ECC error count exceeded driver threshold",
        severity="warning",
        action="Monitor memory health closely; GPU may be degrading",
    ),
    42: XidEntry(
        code=42,
        name="GPU Uncorrectable ECC Error",
        description="Uncorrectable ECC error in video memory",
        severity="critical",
        action="Check ECC error counts; RMA if persistent",
    ),
    43: XidEntry(
        code=43,
        name="GPU Stopped Processing",
        description="GPU stopped processing - context switch timeout",
        severity="critical",
        action="Check GPU thermals and power; update driver; may require RMA",
    ),
    44: XidEntry(
        code=44,
        name="GPU Correctable ECC Count Exceeded",
        description="Correctable ECC threshold exceeded (alternate path)",
        severity="warning",
        action="Monitor memory health; may indicate degrading HBM",
    ),
    45: XidEntry(
        code=45,
        name="Preemptive Cleanup",
        description="Preemptive cleanup triggered after an earlier error",
        severity="warning",
        action="Monitor - usually follows another Xid error; investigate root cause",
    ),
    48: XidEntry(
        code=48,
        name="Double-Bit ECC Error",
        description="Uncorrectable double-bit ECC error in GPU memory",
        severity="critical",
        action="RMA GPU if persistent; run nvidia-smi to check retired pages",
    ),
    56: XidEntry(
        code=56,
        name="Display Engine Error",
        description="Display engine error - display hardware fault",
        severity="error",
        action="Check display connections; update driver",
    ),
    57: XidEntry(
        code=57,
        name="Channel Error",
        description="GPU channel error - channel has encountered an unrecoverable fault",
        severity="error",
        action="Update driver; may indicate application bug or hardware issue",
    ),
    61: XidEntry(
        code=61,
        name="Internal Microcontroller Halt",
        description="GPU internal microcontroller halt - fatal firmware error",
        severity="critical",
        action="GPU reset required; RMA GPU if persistent",
    ),
    62: XidEntry(
        code=62,
        name="Internal Microcontroller Halt (Non-Fatal)",
        description="GPU internal microcontroller breakpoint or non-fatal halt",
        severity="warning",
        action="Monitor - usually recoverable; update firmware if persistent",
    ),
    63: XidEntry(
        code=63,
        name="ECC Page Retirement Event",
        description="ECC page retirement or row remapping event succeeded",
        severity="warning",
        action="Monitor retired page count via nvidia-smi; RMA if count is high",
    ),
    64: XidEntry(
        code=64,
        name="ECC Page Retirement Failure",
        description="ECC page retirement or row remapping failed - no more spare rows",
        severity="critical",
        action="RMA GPU - memory retirement capacity exhausted",
    ),
    68: XidEntry(
        code=68,
        name="Video Processor Exception",
        description="Video processor (NVDEC/NVENC) exception",
        severity="error",
        action="Update driver; check video encode/decode workload",
    ),
    69: XidEntry(
        code=69,
        name="Graphics Engine Class Error",
        description="Graphics engine exception on accessor - class error",
        severity="error",
        action="Update driver; check application for illegal operations",
    ),
    72: XidEntry(
        code=72,
        name="D2D ECC Error",
        description="Device-to-device (NVLink fabric) ECC error detected",
        severity="critical",
        action="Check NVLink health and connections; may require RMA",
    ),
    73: XidEntry(
        code=73,
        name="Contained Compute SM Error",
        description="Streaming multiprocessor contained error, may have ECC root cause",
        severity="warning",
        action="Monitor SM health; check for ECC errors as root cause",
    ),
    74: XidEntry(
        code=74,
        name="NVLink Error",
        description="NVLink hardware error detected",
        severity="critical",
        action="Check NVLink cables and connections; run nvidia-smi nvlink -s; RMA if persistent",
    ),
    79: XidEntry(
        code=79,
        name="GPU Fallen Off Bus",
        description="GPU has fallen off the PCIe bus - no longer responding",
        severity="critical",
        action="Check PCIe seating and power cables; check PSU; RMA GPU if persistent",
    ),
    92: XidEntry(
        code=92,
        name="High Single-Bit ECC Rate",
        description="High single-bit ECC error rate detected in GPU memory",
        severity="warning",
        action="Monitor - may indicate degrading memory; RMA if rate accelerates",
    ),
    93: XidEntry(
        code=93,
        name="Contained Compute SM Error (Non-Fatal)",
        description="SM contained error, recovered successfully",
        severity="info",
        action="Monitor - usually recoverable; investigate if frequent",
    ),
    94: XidEntry(
        code=94,
        name="Contained ECC Error",
        description="Contained ECC error - error was isolated and did not affect running work",
        severity="warning",
        action="Monitor ECC counts; usually no immediate action needed",
    ),
    95: XidEntry(
        code=95,
        name="Uncontained ECC Error",
        description="Uncontained ECC error - affected work is unreliable, GPU reset needed",
        severity="critical",
        action="Reset GPU; rerun affected workload; RMA GPU if persistent",
    ),
    96: XidEntry(
        code=96,
        name="Contained ECC Error (Subsystem)",
        description="Contained ECC error affecting a specific subsystem",
        severity="warning",
        action="Monitor ECC counts for the affected subsystem",
    ),
    119: XidEntry(
        code=119,
        name="GSP Error",
        description="GPU System Processor (GSP) firmware error",
        severity="critical",
        action="Update driver and GPU firmware; RMA if persistent",
    ),
    120: XidEntry(
        code=120,
        name="GSP Context Teardown",
        description="GPU System Processor context teardown notification",
        severity="warning",
        action="Can follow ECC-triggered faults; check for preceding XID errors",
    ),
}


def lookup_xid(code: int) -> XidEntry:
    """
    Look up an Xid error code and return its entry.

    Returns a generic "Unknown Xid" entry if the code is not in the table.
    """
    if code in XID_CODES:
        return XID_CODES[code]

    return XidEntry(
        code=code,
        name="Unknown Xid",
        description=f"Unrecognised Xid error code {code}",
        severity="error",
        action="Consult NVIDIA Xid documentation for this error code",
    )
