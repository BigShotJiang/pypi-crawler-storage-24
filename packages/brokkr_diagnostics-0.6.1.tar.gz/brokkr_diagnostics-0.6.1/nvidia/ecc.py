"""
Deep ECC/RAS diagnostics with per-location error counters, row remapper
histogram, InfoROM validation, and automated RMA recommendation.

Ampere+ GPUs (architecture >= 7) use row remapping instead of page retirement.
This module detects the architecture and chooses the correct ECC path.
"""

from dataclasses import dataclass, field, asdict
from datetime import datetime
from typing import List, Optional
import json
import pynvml

from .constants import ARCHITECTURE_MAP
from .nvml_mixin import NVMLMixin


# ---------------------------------------------------------------------------
# Architecture mapping
# ---------------------------------------------------------------------------

# Ampere and newer use row remapping; older architectures use page retirement
USES_ROW_REMAPPING_MIN_ARCH = 7

# Memory location constants for nvmlDeviceGetMemoryErrorCounter
_MEMORY_LOCATIONS = {
    "DRAM": getattr(pynvml, "NVML_MEMORY_LOCATION_DRAM", 2),
    "SRAM": getattr(pynvml, "NVML_MEMORY_LOCATION_SRAM", 7),
}

# Threshold for "high" corrected error count warnings
_HIGH_CORRECTED_THRESHOLD = 100


# ---------------------------------------------------------------------------
# Dataclass models
# ---------------------------------------------------------------------------

@dataclass
class PerLocationECC:
    """ECC error counters for a single memory location."""
    location: str  # "DRAM", "SRAM"
    corrected_volatile: Optional[int] = None
    corrected_aggregate: Optional[int] = None
    uncorrected_volatile: Optional[int] = None
    uncorrected_aggregate: Optional[int] = None


@dataclass
class RowRemapperHistogram:
    """Row remapper spare-capacity histogram (Ampere+)."""
    max_banks: int = 0      # banks with full spare capacity
    high_banks: int = 0     # banks with high spare capacity
    partial_banks: int = 0  # banks with partial spare capacity
    low_banks: int = 0      # banks with low spare capacity
    none_banks: int = 0     # banks with NO spare capacity (RMA critical)


@dataclass
class GPUECCDetail:
    """Full ECC/RAS detail for a single GPU."""
    gpu_index: int
    gpu_name: str
    architecture: Optional[str] = None  # "Ampere", "Hopper", etc.
    ecc_mode_current: Optional[str] = None
    ecc_mode_pending: Optional[str] = None
    ecc_mode_mismatch: bool = False
    # Per-location ECC
    per_location_ecc: List[PerLocationECC] = field(default_factory=list)
    # Row remapper (Ampere+)
    row_remapper_histogram: Optional[RowRemapperHistogram] = None
    # Repair status
    channel_repair_pending: Optional[bool] = None
    tpc_repair_pending: Optional[bool] = None
    # InfoROM
    inforom_valid: Optional[bool] = None
    inforom_image_version: Optional[str] = None
    # RMA recommendation
    rma_recommended: bool = False
    rma_reasons: List[str] = field(default_factory=list)


@dataclass
class ECCDiagnosticsResult:
    """Aggregate result from ECC/RAS diagnostics across all GPUs."""
    timestamp: datetime
    gpu_count: int = 0
    gpu_ecc_details: List[GPUECCDetail] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)


# ---------------------------------------------------------------------------
# ECCDiagnostics class
# ---------------------------------------------------------------------------

class ECCDiagnostics(NVMLMixin):
    """
    Deep ECC/RAS diagnostics.

    Collects per-location ECC counters (DRAM, SRAM),
    row remapper histogram (Ampere+), repair status, InfoROM validation,
    and produces an automated RMA recommendation for each GPU.
    """

    def __init__(self):
        super().__init__()

    # ------------------------------------------------------------------
    # Per-location ECC counters
    # ------------------------------------------------------------------

    def _get_per_location_ecc(self, handle) -> List[PerLocationECC]:
        """Collect ECC error counters for DRAM and SRAM."""
        locations = [
            ("DRAM", _MEMORY_LOCATIONS["DRAM"]),
            ("SRAM", _MEMORY_LOCATIONS["SRAM"]),
        ]

        results = []
        for name, loc_id in locations:
            entry = PerLocationECC(location=name)

            entry.corrected_volatile = self._safe_nvml_call(
                pynvml.nvmlDeviceGetMemoryErrorCounter,
                handle,
                pynvml.NVML_MEMORY_ERROR_TYPE_CORRECTED,
                pynvml.NVML_VOLATILE_ECC,
                loc_id,
            )
            entry.corrected_aggregate = self._safe_nvml_call(
                pynvml.nvmlDeviceGetMemoryErrorCounter,
                handle,
                pynvml.NVML_MEMORY_ERROR_TYPE_CORRECTED,
                pynvml.NVML_AGGREGATE_ECC,
                loc_id,
            )
            entry.uncorrected_volatile = self._safe_nvml_call(
                pynvml.nvmlDeviceGetMemoryErrorCounter,
                handle,
                pynvml.NVML_MEMORY_ERROR_TYPE_UNCORRECTED,
                pynvml.NVML_VOLATILE_ECC,
                loc_id,
            )
            entry.uncorrected_aggregate = self._safe_nvml_call(
                pynvml.nvmlDeviceGetMemoryErrorCounter,
                handle,
                pynvml.NVML_MEMORY_ERROR_TYPE_UNCORRECTED,
                pynvml.NVML_AGGREGATE_ECC,
                loc_id,
            )

            results.append(entry)

        return results

    # ------------------------------------------------------------------
    # Row remapper histogram (Ampere+)
    # ------------------------------------------------------------------

    def _get_row_remapper_histogram(self, handle) -> Optional[RowRemapperHistogram]:
        """
        Read the row remapper spare-capacity histogram.

        Returns None if the GPU does not support row remapping (pre-Ampere).
        The pynvml call returns a c_nvmlRowRemapperHistogramValues struct
        with attributes: max, high, partial, low, none.
        """
        result = self._safe_nvml_call(
            pynvml.nvmlDeviceGetRowRemapperHistogram, handle
        )
        if result is None:
            return None

        return RowRemapperHistogram(
            max_banks=getattr(result, "max", 0),
            high_banks=getattr(result, "high", 0),
            partial_banks=getattr(result, "partial", 0),
            low_banks=getattr(result, "low", 0),
            none_banks=getattr(result, "none", 0),
        )

    # ------------------------------------------------------------------
    # Repair status
    # ------------------------------------------------------------------

    def _get_repair_status(self, handle) -> tuple:
        """
        Query channel and TPC repair pending status.

        Returns (channel_pending: bool|None, tpc_pending: bool|None).
        The API may not exist in all pynvml versions.
        """
        fn = getattr(pynvml, "nvmlDeviceGetRepairStatus", None)
        if fn is None:
            return (None, None)

        result = self._safe_nvml_call(fn, handle)
        if result is None:
            return (None, None)

        channel_pending = bool(result[0]) if result[0] is not None else None
        tpc_pending = bool(result[1]) if result[1] is not None else None
        return (channel_pending, tpc_pending)

    # ------------------------------------------------------------------
    # InfoROM validation
    # ------------------------------------------------------------------

    def _validate_inforom(self, handle) -> tuple:
        """
        Validate InfoROM and retrieve image version.

        Returns (valid: bool|None, version: str|None).
        nvmlDeviceValidateInforom returns None on success, raises NVMLError
        on corruption. We must distinguish corruption from not-supported.
        """
        valid = None
        try:
            pynvml.nvmlDeviceValidateInforom(handle)
            valid = True
        except pynvml.NVMLError as e:
            err_code = e.value if hasattr(e, 'value') else None
            not_supported = getattr(pynvml, 'NVML_ERROR_NOT_SUPPORTED', 3)
            if err_code == not_supported:
                valid = None  # not supported, not corrupt
            else:
                valid = False  # actual validation failure

        version = self._safe_nvml_call(
            pynvml.nvmlDeviceGetInforomImageVersion, handle
        )

        return (valid, version)

    # ------------------------------------------------------------------
    # ECC mode with pending check
    # ------------------------------------------------------------------

    def _get_ecc_mode_with_pending(self, handle) -> tuple:
        """
        Get current and pending ECC mode.

        Returns (current: str|None, pending: str|None, mismatch: bool).
        nvmlDeviceGetEccMode returns [current, pending] as integer enable states.
        """
        result = self._safe_nvml_call(pynvml.nvmlDeviceGetEccMode, handle)
        if result is None:
            return (None, None, False)

        current_val = result[0]
        pending_val = result[1]

        current_str = "Enabled" if current_val == pynvml.NVML_FEATURE_ENABLED else "Disabled"
        pending_str = "Enabled" if pending_val == pynvml.NVML_FEATURE_ENABLED else "Disabled"
        mismatch = current_val != pending_val

        return (current_str, pending_str, mismatch)

    # ------------------------------------------------------------------
    # RMA evaluation
    # ------------------------------------------------------------------

    @staticmethod
    def _evaluate_rma(detail: GPUECCDetail) -> None:
        """
        Evaluate whether a GPU should be recommended for RMA.

        Sets detail.rma_recommended and populates detail.rma_reasons.
        """
        reasons = []

        # Row remapper: no spare capacity remaining
        if detail.row_remapper_histogram is not None:
            hist = detail.row_remapper_histogram
            if hist.none_banks > 0:
                reasons.append(
                    f"Row remapper: {hist.none_banks} bank(s) with NO spare capacity"
                )
            if hist.low_banks > 0:
                reasons.append(
                    f"Row remapper: {hist.low_banks} bank(s) with low spare capacity"
                )
            if hist.partial_banks > 0:
                reasons.append(
                    f"Row remapper: {hist.partial_banks} bank(s) with partial spare capacity"
                )

        # Uncorrected aggregate DRAM errors
        for loc_ecc in detail.per_location_ecc:
            if loc_ecc.location == "DRAM" and loc_ecc.uncorrected_aggregate is not None:
                if loc_ecc.uncorrected_aggregate > 0:
                    reasons.append(
                        f"DRAM uncorrected aggregate errors: {loc_ecc.uncorrected_aggregate}"
                    )

        # Repair pending
        if detail.channel_repair_pending:
            reasons.append("Channel repair is pending")
        if detail.tpc_repair_pending:
            reasons.append("TPC repair is pending")

        # High corrected error counts (warning-level)
        for loc_ecc in detail.per_location_ecc:
            if loc_ecc.corrected_aggregate is not None:
                if loc_ecc.corrected_aggregate > _HIGH_CORRECTED_THRESHOLD:
                    reasons.append(
                        f"{loc_ecc.location} high corrected aggregate count: "
                        f"{loc_ecc.corrected_aggregate}"
                    )

        detail.rma_reasons = reasons

        # Immediate RMA conditions: none_banks > 0, uncorrected DRAM > 0,
        # or repair pending
        immediate_rma = False
        if detail.row_remapper_histogram is not None:
            if detail.row_remapper_histogram.none_banks > 0:
                immediate_rma = True
        for loc_ecc in detail.per_location_ecc:
            if loc_ecc.location == "DRAM" and loc_ecc.uncorrected_aggregate is not None:
                if loc_ecc.uncorrected_aggregate > 0:
                    immediate_rma = True
        if detail.channel_repair_pending or detail.tpc_repair_pending:
            immediate_rma = True

        detail.rma_recommended = immediate_rma

    # ------------------------------------------------------------------
    # Run all checks
    # ------------------------------------------------------------------

    async def run_all_checks(self) -> ECCDiagnosticsResult:
        """Enumerate all GPUs and collect deep ECC/RAS diagnostics."""
        result = ECCDiagnosticsResult(timestamp=datetime.now())

        if not self._init_nvml():
            result.errors.append("Failed to initialize NVML")
            return result

        try:
            gpu_count = self._safe_nvml_call(
                pynvml.nvmlDeviceGetCount, default=0
            )
            result.gpu_count = gpu_count

            if gpu_count == 0:
                result.errors.append("No GPUs detected")
                return result

            for i in range(gpu_count):
                handle = self._safe_nvml_call(
                    pynvml.nvmlDeviceGetHandleByIndex, i
                )
                if handle is None:
                    result.errors.append(f"Could not get handle for GPU {i}")
                    continue

                gpu_name = self._safe_nvml_call(
                    pynvml.nvmlDeviceGetName, handle, default="Unknown"
                )

                detail = GPUECCDetail(gpu_index=i, gpu_name=gpu_name)

                # Architecture
                arch_id = self._safe_nvml_call(
                    pynvml.nvmlDeviceGetArchitecture, handle
                )
                if arch_id is not None:
                    detail.architecture = ARCHITECTURE_MAP.get(arch_id, f"Unknown({arch_id})")

                # ECC mode
                current, pending, mismatch = self._get_ecc_mode_with_pending(handle)
                detail.ecc_mode_current = current
                detail.ecc_mode_pending = pending
                detail.ecc_mode_mismatch = mismatch

                if mismatch:
                    result.warnings.append(
                        f"GPU {i} ({gpu_name}): ECC mode mismatch - "
                        f"current={current}, pending={pending} (reboot required)"
                    )

                # Per-location ECC counters
                detail.per_location_ecc = self._get_per_location_ecc(handle)

                # Row remapper histogram (Ampere+ only)
                if arch_id is not None and arch_id >= USES_ROW_REMAPPING_MIN_ARCH:
                    detail.row_remapper_histogram = self._get_row_remapper_histogram(handle)

                # Repair status
                channel_pending, tpc_pending = self._get_repair_status(handle)
                detail.channel_repair_pending = channel_pending
                detail.tpc_repair_pending = tpc_pending

                # InfoROM validation
                inforom_valid, inforom_version = self._validate_inforom(handle)
                detail.inforom_valid = inforom_valid
                detail.inforom_image_version = inforom_version

                if inforom_valid is False:
                    result.warnings.append(
                        f"GPU {i} ({gpu_name}): InfoROM validation failed - "
                        f"data may be corrupt"
                    )

                # RMA evaluation
                self._evaluate_rma(detail)

                if detail.rma_recommended:
                    result.warnings.append(
                        f"GPU {i} ({gpu_name}): RMA recommended - "
                        + "; ".join(detail.rma_reasons)
                    )

                result.gpu_ecc_details.append(detail)

        except Exception as e:
            result.errors.append(f"Unexpected error during ECC diagnostics: {e}")
        finally:
            self._shutdown_nvml()

        return result

    # ------------------------------------------------------------------
    # Report formatting
    # ------------------------------------------------------------------

    def format_report(self, result: ECCDiagnosticsResult) -> str:
        """Format results as a JSON report."""
        result_dict = asdict(result)
        result_dict.pop("warnings", None)
        return json.dumps(result_dict, indent=4, default=str)


# ---------------------------------------------------------------------------
# Module entry point
# ---------------------------------------------------------------------------

async def run_ecc_diagnostics():
    """Run deep ECC/RAS diagnostics and return the JSON report."""
    diagnostics = ECCDiagnostics()
    result = await diagnostics.run_all_checks()
    return diagnostics.format_report(result)
