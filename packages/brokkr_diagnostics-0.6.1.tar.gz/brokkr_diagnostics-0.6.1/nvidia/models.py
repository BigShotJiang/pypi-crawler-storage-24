"""
GPU Hardware State & Identification models.
"""

from typing import List, Optional
from dataclasses import dataclass, field
from datetime import datetime


@dataclass
class GPUProcess:
    """A process using a GPU."""
    pid: int
    name: Optional[str] = None
    used_gpu_memory: Optional[str] = None


@dataclass
class GPUDevice:
    """Detailed information about a single GPU"""

    index: int
    name: str
    pci_bus_id: str
    driver_version: Optional[str] = None
    vbios_version: Optional[str] = None
    serial: Optional[str] = None
    uuid: Optional[str] = None
    memory_total: Optional[str] = None

    # Sysfs power management
    sysfs_power_control: Optional[str] = None
    sysfs_runtime_status: Optional[str] = None
    sysfs_runtime_usage: Optional[str] = None

    # Memory usage
    memory_used: Optional[str] = None
    memory_free: Optional[str] = None

    # Power
    power_draw: Optional[str] = None
    power_limit: Optional[str] = None
    power_limit_enforced: Optional[str] = None
    power_limit_max: Optional[str] = None
    power_limit_min: Optional[str] = None

    # Clocks
    clock_graphics: Optional[str] = None
    clock_sm: Optional[str] = None
    clock_memory: Optional[str] = None
    clock_max_graphics: Optional[str] = None
    clock_max_memory: Optional[str] = None

    # Modes
    persistence_mode: Optional[str] = None
    ecc_mode: Optional[str] = None

    compute_mode: Optional[str] = None

    # ECC Errors
    ecc_errors_corrected_volatile: Optional[str] = None
    ecc_errors_corrected_aggregate: Optional[str] = None
    ecc_errors_uncorrected_volatile: Optional[str] = None
    ecc_errors_uncorrected_aggregate: Optional[str] = None

    # Retired Pages
    retired_pages_single_bit_ecc: Optional[str] = None
    retired_pages_double_bit: Optional[str] = None
    retired_pages_pending: Optional[str] = None

    # Remapped Rows
    remapped_rows_correctable: Optional[int] = None
    remapped_rows_uncorrectable: Optional[int] = None
    remapped_rows_pending: Optional[bool] = None
    remapped_rows_failure: Optional[bool] = None

    # Temperature and Throttling
    temperature_gpu: Optional[str] = None
    temperature_memory: Optional[str] = None
    clocks_throttle_reasons_active: Optional[str] = None
    clocks_throttle_reasons_hw_slowdown: Optional[str] = None

    # PCIe Link Status
    pcie_link_gen_current: Optional[str] = None
    pcie_link_gen_max: Optional[str] = None
    pcie_link_width_current: Optional[str] = None
    pcie_link_width_max: Optional[str] = None

    # Utilization
    gpu_utilization: Optional[str] = None  # percentage
    memory_utilization: Optional[str] = None  # percentage

    # Performance state
    performance_state: Optional[str] = None  # P0-P15

    # Energy
    total_energy_consumption: Optional[str] = None  # in Joules

    # Violation status (cumulative throttle time in seconds)
    violation_power: Optional[str] = None
    violation_thermal: Optional[str] = None
    violation_reliability: Optional[str] = None
    violation_board_limit: Optional[str] = None

    # Temperature thresholds
    temperature_shutdown: Optional[str] = None
    temperature_slowdown: Optional[str] = None
    temperature_mem_max: Optional[str] = None
    temperature_gpu_max: Optional[str] = None

    # PCIe throughput
    pcie_tx_throughput_kbps: Optional[str] = None
    pcie_rx_throughput_kbps: Optional[str] = None

    # PCIe error counters (from NVML field values)
    pcie_correctable_errors: Optional[str] = None
    pcie_fatal_errors: Optional[str] = None
    pcie_nonfatal_errors: Optional[str] = None
    pcie_replay_counter: Optional[str] = None
    pcie_l0_to_recovery_counter: Optional[str] = None

    # BAR1 memory
    bar1_total: Optional[str] = None
    bar1_used: Optional[str] = None
    bar1_free: Optional[str] = None

    # Decoded throttle reasons (human-readable list)
    clocks_throttle_reasons_decoded: Optional[list] = None

    # Architecture and core count
    architecture: Optional[str] = None
    gpu_cores: Optional[str] = None
    cuda_compute_capability: Optional[str] = None

    # NVLink throughput (aggregate)
    nvlink_throughput_data_tx: Optional[str] = None
    nvlink_throughput_data_rx: Optional[str] = None

    # GSP firmware
    gsp_firmware_version: Optional[str] = None

    # MIG mode
    mig_mode_current: Optional[str] = None
    mig_mode_pending: Optional[str] = None

    # Default power limit (factory)
    power_limit_default: Optional[str] = None

    # Power source
    power_source: Optional[str] = None

    # Accounting mode
    accounting_mode: Optional[str] = None

    # Supported throttle reasons
    clocks_throttle_reasons_supported: Optional[str] = None

    # Running processes
    processes: List[GPUProcess] = field(default_factory=list)

    errors: List[str] = field(default_factory=list)

    def check_ecc_errors(self) -> Optional[str]:
        if self.ecc_errors_uncorrected_aggregate and self.ecc_errors_uncorrected_aggregate != "N/A":
            try:
                uncorrected_count = int(self.ecc_errors_uncorrected_aggregate)
                if uncorrected_count > 0:
                    return f"GPU {self.index}: {uncorrected_count} uncorrected ECC errors detected"
            except ValueError:
                return f"GPU {self.index}: {self.ecc_errors_uncorrected_aggregate} uncorrected ECC errors detected"
        return None

    def check_retired_pages(self) -> Optional[str]:
        if self.retired_pages_pending and self.retired_pages_pending not in ["N/A", "0", "None"]:
            return f"GPU {self.index}: Retired pages pending - {self.retired_pages_pending}"
        return None

    # Benign throttle reasons that don't indicate a problem
    BENIGN_THROTTLE_REASONS = {
        "N/A",
        "0x0", "0x0000000000000000",  # No throttling
        "0x1", "0x0000000000000001",  # GPU idle
        "0x2", "0x0000000000000002",  # Applications clocks setting
        "0x3", "0x0000000000000003",  # GPU idle + Applications clocks
    }

    def check_clocks_throttle(self) -> Optional[str]:
        if self.clocks_throttle_reasons_active and self.clocks_throttle_reasons_active not in self.BENIGN_THROTTLE_REASONS:
            return f"GPU {self.index}: Clock throttling active - {self.clocks_throttle_reasons_active}"
        return None

    def check_pcie_link(self) -> Optional[str]:
        if self.pcie_link_gen_current and self.pcie_link_gen_max:
            if self.pcie_link_gen_current != self.pcie_link_gen_max and self.pcie_link_gen_current not in [
                "N/A",
                "None",
            ]:
                return f"GPU {self.index}: PCIe link speed degraded - running at Gen{self.pcie_link_gen_current} (max: Gen{self.pcie_link_gen_max})"

    def check_pcie_link_width(self) -> Optional[str]:
        if self.pcie_link_width_current and self.pcie_link_width_max:
            if self.pcie_link_width_current != self.pcie_link_width_max and self.pcie_link_width_current not in [
                "N/A",
                "None",
            ]:
                return f"GPU {self.index}: PCIe link width degraded - running at x{self.pcie_link_width_current} (max: x{self.pcie_link_width_max})"
        return None

    def check_remapped_rows(self) -> Optional[str]:
        if self.remapped_rows_failure is True:
            return (
                f"GPU {self.index}: Row remapping FAILED - no spare rows remaining. "
                f"GPU needs RMA (correctable={self.remapped_rows_correctable}, "
                f"uncorrectable={self.remapped_rows_uncorrectable})"
            )
        if self.remapped_rows_uncorrectable and self.remapped_rows_uncorrectable > 0:
            return (
                f"GPU {self.index}: {self.remapped_rows_uncorrectable} uncorrectable "
                f"remapped rows (pending={self.remapped_rows_pending})"
            )
        return None

    def check_pcie_errors(self) -> Optional[str]:
        """Flag if PCIe fatal errors > 0 or L0-to-recovery counter exceeds threshold."""
        messages = []
        if self.pcie_fatal_errors and self.pcie_fatal_errors not in ("N/A", "None"):
            try:
                if int(self.pcie_fatal_errors) > 0:
                    messages.append(f"GPU {self.index}: {self.pcie_fatal_errors} PCIe fatal errors detected")
            except ValueError:
                pass
        if self.pcie_l0_to_recovery_counter and self.pcie_l0_to_recovery_counter not in ("N/A", "None"):
            try:
                count = int(self.pcie_l0_to_recovery_counter)
                if count > 100:
                    messages.append(f"GPU {self.index}: PCIe L0-to-recovery count elevated ({count})")
            except ValueError:
                pass
        return messages[0] if messages else None

    def check_thermal_headroom(self) -> Optional[str]:
        """Warn if GPU temperature is within 5C of slowdown threshold."""
        if self.temperature_gpu and self.temperature_slowdown:
            if self.temperature_gpu in ("N/A", "None") or self.temperature_slowdown in ("N/A", "None"):
                return None
            try:
                temp_current = int(self.temperature_gpu)
                temp_slowdown = int(self.temperature_slowdown)
                headroom = temp_slowdown - temp_current
                if headroom <= 5:
                    return (
                        f"GPU {self.index}: Temperature {temp_current}C is within "
                        f"{headroom}C of slowdown threshold ({temp_slowdown}C)"
                    )
            except ValueError:
                pass
        return None

    def check_violations(self) -> Optional[str]:
        """Warn if any violation time is greater than 0."""
        violations = {
            "power": self.violation_power,
            "thermal": self.violation_thermal,
            "reliability": self.violation_reliability,
            "board_limit": self.violation_board_limit,
        }
        active = []
        for name, val in violations.items():
            if val and val not in ("N/A", "None", "0.000 s"):
                try:
                    # Parse the numeric portion (e.g. "1.234 s" -> 1.234)
                    numeric = float(val.split()[0])
                    if numeric > 0:
                        active.append(f"{name}={val}")
                except (ValueError, IndexError):
                    pass
        if active:
            return f"GPU {self.index}: Throttle violations detected - {', '.join(active)}"
        return None

    def check_mig_mode_mismatch(self) -> Optional[str]:
        if self.mig_mode_current and self.mig_mode_pending:
            if self.mig_mode_current != self.mig_mode_pending:
                return f"GPU {self.index}: MIG mode mismatch - current={self.mig_mode_current}, pending={self.mig_mode_pending} (reboot required)"
        return None

    def check_power_limit_vs_default(self) -> Optional[str]:
        if self.power_limit and self.power_limit_default:
            try:
                current_w = float(self.power_limit.split()[0])
                default_w = float(self.power_limit_default.split()[0])
                if current_w < default_w * 0.8:
                    return f"GPU {self.index}: Power limit {self.power_limit} is below 80% of factory default {self.power_limit_default}"
            except (ValueError, IndexError):
                pass
        return None

    def check_all_errors(self) -> List[Optional[str]]:
        return [
            self.check_ecc_errors(),
            self.check_retired_pages(),
            self.check_remapped_rows(),
            self.check_clocks_throttle(),
            self.check_pcie_link(),
            self.check_pcie_link_width(),
            self.check_pcie_errors(),
            self.check_thermal_headroom(),
            self.check_violations(),
            self.check_mig_mode_mismatch(),
            self.check_power_limit_vs_default(),
        ]


@dataclass
class GPUHardwareResult:
    """Results from GPU hardware diagnostics"""

    timestamp: datetime
    gpus: List[GPUDevice] = field(default_factory=list)
    total_gpus: int = 0
    warnings: List[str] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)
