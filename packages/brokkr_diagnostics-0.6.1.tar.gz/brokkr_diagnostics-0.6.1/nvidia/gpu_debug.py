"""
Hardware register-level GPU debug diagnostics.

Uses nvidia-gpu-admin-tools (nvidia_gpu_tools) to scan PCI devices for NVIDIA
GPUs via BAR0 MMIO mapping, detecting broken GPUs (0xbadf), security faults,
and NVLink training states that pynvml cannot see.

Requires root access for hardware register reads.
"""

import asyncio
import logging
import os
from dataclasses import dataclass, field, asdict
from datetime import datetime
from typing import List, Optional
import json


# ---------------------------------------------------------------------------
# Dataclass models
# ---------------------------------------------------------------------------

@dataclass
class GPUDebugLinkState:
    """NVLink state for a single link on a GPU."""
    link_id: int
    nvlipt_state: Optional[str] = None  # active, l2, reset, shutdown, contain, disable, etc.
    dl_state: Optional[str] = None      # init, hwcfg, swcfg, active, fault, sleep, rcvy_ac, rcvy_rx, train


@dataclass
class GPUDebugDevice:
    """Debug information for a single GPU device."""
    bdf: str
    is_broken: bool = False
    arch: Optional[str] = None
    module_id: Optional[str] = None
    sec_fault: Optional[str] = None
    err_info: Optional[str] = None
    nvlink_enabled_count: int = 0
    nvlink_links_in_hs: int = 0
    link_states: List[GPUDebugLinkState] = field(default_factory=list)


@dataclass
class GPUDebugResult:
    """Aggregate result from GPU debug diagnostics."""
    timestamp: datetime = field(default_factory=datetime.now)
    total_devices: int = 0
    healthy_gpus: int = 0
    broken_gpus: int = 0
    devices: List[GPUDebugDevice] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Diagnostics class
# ---------------------------------------------------------------------------

class GPUDebugDiagnostics:
    """
    Hardware register-level GPU debug diagnostics.

    Scans PCI bus for NVIDIA devices via nvidia-gpu-admin-tools, detecting
    broken GPUs, security faults, and NVLink training states that are
    invisible to pynvml.
    """

    def __init__(self):
        pass

    # ------------------------------------------------------------------
    # NVLink state collection
    # ------------------------------------------------------------------

    def _populate_nvlink_config(self, dev) -> None:
        """
        Populate missing nvlink config from the nvlink_unit class attributes.

        The Gpu.nvlink dict may only contain {'number': N} from GPU_MAP,
        but the per-link state methods need 'links_per_group', 'base_offset',
        and 'per_group_offset'. The architecture-specific nvlink_unit
        (e.g. AmpereNvlink) has these as class attributes.
        """
        try:
            nvlink_dict = getattr(dev, "nvlink", None)
            if not isinstance(nvlink_dict, dict):
                return
            unit = getattr(dev, "nvlink_unit", None)
            if unit is None:
                return
            if "links_per_group" not in nvlink_dict:
                lpg = getattr(unit, "_links_per_group", None)
                if lpg is not None:
                    nvlink_dict["links_per_group"] = lpg
            if "base_offset" not in nvlink_dict:
                bo = getattr(unit, "_base_offset", None)
                if bo is not None:
                    nvlink_dict["base_offset"] = bo
            if "per_group_offset" not in nvlink_dict:
                pgo = getattr(unit, "_per_group_offset", None)
                if pgo is not None:
                    nvlink_dict["per_group_offset"] = pgo
        except Exception:
            pass

    def _collect_link_states(self, dev, device_info: GPUDebugDevice) -> None:
        """
        Collect NVLink states from a healthy GPU device.

        Wraps every attribute access in try/except since the
        nvidia-gpu-admin-tools API may vary across versions.
        """
        # Check if NVLink is supported
        try:
            if not getattr(dev, "is_nvlink_supported", False):
                return
        except Exception:
            return

        # Get link count from nvlink dict or nvlink_unit
        try:
            nvlink_dict = getattr(dev, "nvlink", None)
            num_links = nvlink_dict.get("number", 0) if isinstance(nvlink_dict, dict) else 0
            if num_links == 0:
                unit = getattr(dev, "nvlink_unit", None)
                if unit:
                    num_links = getattr(unit, "num_nvlinks", 0)
        except Exception:
            num_links = 0

        if num_links == 0:
            return

        # Populate missing nvlink config from unit before reading states
        self._populate_nvlink_config(dev)

        enabled_count = 0
        hs_count = 0

        for link_id in range(num_links):
            link_state = GPUDebugLinkState(link_id=link_id)

            # Read NVLIPT link state (method is on the Gpu object, not the unit)
            try:
                nvlipt = dev.nvlink_get_link_state(link_id)
                if nvlipt is not None:
                    link_state.nvlipt_state = str(nvlipt).lower()
                    if link_state.nvlipt_state not in ("disable", "empty"):
                        enabled_count += 1
            except Exception:
                pass

            # Read DL (data-link) state
            try:
                dl = dev.nvlink_dl_get_link_state(link_id)
                if dl is not None:
                    link_state.dl_state = str(dl).lower()
                    if link_state.dl_state == "active":
                        hs_count += 1
            except Exception:
                pass

            device_info.link_states.append(link_state)

        device_info.nvlink_enabled_count = enabled_count
        device_info.nvlink_links_in_hs = hs_count

    # ------------------------------------------------------------------
    # Device processing
    # ------------------------------------------------------------------

    def _process_broken_gpu(self, dev) -> GPUDebugDevice:
        """Process a broken (unresponsive) GPU device."""
        bdf = ""
        try:
            bdf = str(getattr(dev, "bdf", "unknown"))
        except Exception:
            bdf = "unknown"

        device_info = GPUDebugDevice(bdf=bdf, is_broken=True)

        # Extract security fault info if available
        try:
            sec_fault = getattr(dev, "sec_fault", None)
            if sec_fault is not None:
                device_info.sec_fault = str(sec_fault)
        except Exception:
            pass

        # Extract error info if available
        try:
            err_info = getattr(dev, "err_info", None)
            if err_info is not None:
                device_info.err_info = str(err_info)
        except Exception:
            pass

        return device_info

    def _process_healthy_gpu(self, dev) -> GPUDebugDevice:
        """Process a healthy (responsive) GPU device."""
        bdf = ""
        try:
            bdf = str(getattr(dev, "bdf", "unknown"))
        except Exception:
            bdf = "unknown"

        device_info = GPUDebugDevice(bdf=bdf, is_broken=False)

        # Architecture
        try:
            arch = getattr(dev, "arch", None)
            if arch is not None:
                device_info.arch = str(arch)
        except Exception:
            pass

        # Module ID (SXM form-factor GPUs only)
        try:
            if getattr(dev, "is_sxm", False):
                module_id = dev.read_module_id()
                if module_id is not None:
                    device_info.module_id = str(module_id)
        except Exception:
            pass

        # NVLink states
        try:
            self._collect_link_states(dev, device_info)
        except Exception:
            pass

        return device_info

    # ------------------------------------------------------------------
    # Error/warning generation
    # ------------------------------------------------------------------

    def _generate_diagnostics(self, result: GPUDebugResult) -> None:
        """Generate errors and warnings from collected device data."""
        for device_info in result.devices:
            # ERROR for each broken GPU
            if device_info.is_broken:
                msg = f"Broken GPU detected at {device_info.bdf} (BAR0 returns 0xbadf)"
                if device_info.sec_fault:
                    msg += f" - security fault: {device_info.sec_fault}"
                result.errors.append(msg)

            # ERROR for security faults (also on non-broken GPUs if present)
            if device_info.sec_fault and not device_info.is_broken:
                result.errors.append(
                    f"GPU {device_info.bdf}: security fault detected: "
                    f"{device_info.sec_fault}"
                )

            # WARNING for links in FAULT/RCVY/TRAIN states
            for link in device_info.link_states:
                dl = link.dl_state or ""
                if dl in ("fault", "rcvy_ac", "rcvy_rx", "train"):
                    result.warnings.append(
                        f"GPU {device_info.bdf} link {link.link_id}: "
                        f"DL state is {dl.upper()}"
                    )

            # WARNING if fewer links in high-speed than enabled
            if (
                device_info.nvlink_enabled_count > 0
                and device_info.nvlink_links_in_hs < device_info.nvlink_enabled_count
            ):
                result.warnings.append(
                    f"GPU {device_info.bdf}: only {device_info.nvlink_links_in_hs}/"
                    f"{device_info.nvlink_enabled_count} NVLinks in high-speed (active) state"
                )

    # ------------------------------------------------------------------
    # Run all checks
    # ------------------------------------------------------------------

    async def run_all_checks(self) -> GPUDebugResult:
        """Run hardware register-level GPU debug diagnostics."""
        result = GPUDebugResult(timestamp=datetime.now())

        # Requires root for BAR0 MMIO access
        if os.geteuid() != 0:
            result.errors.append(
                "gpu_debug requires root for hardware register access"
            )
            return result

        # Step 1: Try to import nvidia_gpu_tools
        try:
            from nvidia_gpu_tools import find_gpus
        except ImportError:
            result.errors.append("nvidia-gpu-admin-tools not available")
            return result

        # Step 2: Call find_gpus() in a thread to avoid blocking the event loop.
        # Suppress noisy logging from nvidia_gpu_tools inside the thread
        # so we don't affect other concurrent coroutines' logging.
        def _find_gpus_quiet():
            prev_level = logging.root.level
            logging.root.setLevel(logging.CRITICAL)
            try:
                return find_gpus()
            finally:
                logging.root.setLevel(prev_level)

        try:
            gpus_list, nvswitches_list = await asyncio.to_thread(_find_gpus_quiet)
        except Exception as e:
            result.errors.append(f"Error scanning PCI devices: {e}")
            return result

        # Step 3: Process each device
        all_devices = list(gpus_list or [])
        result.total_devices = len(all_devices)

        for dev in all_devices:
            try:
                is_broken = False
                try:
                    is_broken = hasattr(dev, "is_broken_gpu") and dev.is_broken_gpu()
                except Exception:
                    pass

                if is_broken:
                    device_info = self._process_broken_gpu(dev)
                    result.broken_gpus += 1
                else:
                    device_info = self._process_healthy_gpu(dev)
                    result.healthy_gpus += 1

                result.devices.append(device_info)

            except Exception as e:
                result.errors.append(
                    f"Error processing device: {e}"
                )

        # Step 4: Generate errors and warnings
        try:
            self._generate_diagnostics(result)
        except Exception as e:
            result.errors.append(f"Error generating diagnostics: {e}")

        return result

    # ------------------------------------------------------------------
    # Report formatting
    # ------------------------------------------------------------------

    def format_report(self, result: GPUDebugResult) -> str:
        """Format results as a JSON report."""
        result_dict = asdict(result)
        result_dict.pop("warnings", None)
        return json.dumps(result_dict, indent=4, default=str)


# ---------------------------------------------------------------------------
# Module entry point
# ---------------------------------------------------------------------------

async def run_gpu_debug_diagnostics():
    """Run hardware register-level GPU debug diagnostics and return the JSON report."""
    diagnostics = GPUDebugDiagnostics()
    result = await diagnostics.run_all_checks()
    return diagnostics.format_report(result)
