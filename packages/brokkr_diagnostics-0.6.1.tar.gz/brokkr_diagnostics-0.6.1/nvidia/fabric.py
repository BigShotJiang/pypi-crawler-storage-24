"""
Fabric Manager and NVSwitch diagnostics.
Checks NVSwitch presence, Fabric Manager service health, version compatibility,
GPU fabric state via NVML, and FM log analysis.
"""

from pathlib import Path
from typing import List, Optional
from dataclasses import dataclass, field, asdict
from datetime import datetime
import ctypes
import json
import re
import pynvml
from ..core.executor import Executor
from .nvml_mixin import NVMLMixin


# ---------------------------------------------------------------------------
# Dataclass models
# ---------------------------------------------------------------------------

@dataclass
class NVSwitchDevice:
    """Information about a single NVSwitch discovered via /proc."""
    pci_bus_id: str
    bios_version: Optional[str] = None
    uuid: Optional[str] = None
    physical_id: Optional[str] = None


@dataclass
class FabricManagerStatus:
    """Fabric Manager service and version information."""
    service_active: bool = False
    service_enabled: bool = False
    service_status: Optional[str] = None  # "active", "failed", "inactive"
    fm_version: Optional[str] = None
    driver_version: Optional[str] = None
    version_match: Optional[bool] = None


@dataclass
class FMLogEntry:
    """A notable entry from the Fabric Manager log."""
    level: Optional[str] = None  # ERROR, CRITICAL, INFO
    message: Optional[str] = None


@dataclass
class GPUFabricState:
    gpu_index: int
    fabric_state: str  # NOT_SUPPORTED, NOT_STARTED, IN_PROGRESS, COMPLETED


@dataclass
class FabricDiagnosticsResult:
    """Aggregate result from Fabric Manager diagnostics."""
    timestamp: datetime = field(default_factory=datetime.now)
    fabric_manager: Optional[FabricManagerStatus] = None
    nvswitches: List[NVSwitchDevice] = field(default_factory=list)
    nvswitch_count: int = 0
    system_needs_fabric_manager: bool = False
    # GPU fabric info from NVML
    gpu_fabric_states: List[GPUFabricState] = field(default_factory=list)
    nvswitch_bios_version_mismatch: bool = False
    expected_nvswitch_count: Optional[int] = None
    fm_log_errors: List[FMLogEntry] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

NVSWITCH_PROC_PATH = Path("/proc/driver/nvidia-nvswitch/devices")
FM_LOG_PATH = Path("/var/log/fabricmanager.log")

GPU_FABRIC_STATE_MAP = {
    0: "NOT_SUPPORTED",
    1: "NOT_STARTED",
    2: "IN_PROGRESS",
    3: "COMPLETED",
}


# ---------------------------------------------------------------------------
# Diagnostics class
# ---------------------------------------------------------------------------

class FabricDiagnostics(NVMLMixin):
    """
    Fabric Manager and NVSwitch diagnostics.

    Collects:
    - NVSwitch device enumeration from /proc/driver/nvidia-nvswitch/devices/
    - Fabric Manager service status via systemctl
    - FM/driver version comparison
    - GPU fabric state via NVML
    - Fabric Manager log error analysis
    """

    def __init__(self):
        super().__init__()
        self.executor = Executor()
        self.systemctl_path = self.executor.find_binary("systemctl")

    # ------------------------------------------------------------------
    # NVSwitch detection
    # ------------------------------------------------------------------

    def detect_nvswitches(self) -> List[NVSwitchDevice]:
        """Discover NVSwitch devices from /proc/driver/nvidia-nvswitch/devices/."""
        switches: List[NVSwitchDevice] = []

        if not NVSWITCH_PROC_PATH.exists():
            return switches

        try:
            for dev_dir in sorted(NVSWITCH_PROC_PATH.iterdir()):
                if not dev_dir.is_dir():
                    continue

                pci_bus_id = dev_dir.name
                switch = NVSwitchDevice(pci_bus_id=pci_bus_id)

                # Read information file for BIOS version, UUID, physical ID
                info_file = dev_dir / "information"
                if info_file.exists():
                    try:
                        content = info_file.read_text()
                        for line in content.strip().split("\n"):
                            line = line.strip()
                            if line.startswith("BIOS Version:"):
                                switch.bios_version = line.split(":", 1)[1].strip()
                            elif line.startswith("UUID:"):
                                switch.uuid = line.split(":", 1)[1].strip()
                            elif line.startswith("Physical location ID:"):
                                switch.physical_id = line.split(":", 1)[1].strip()
                    except Exception:
                        pass

                switches.append(switch)
        except Exception:
            pass

        return switches

    # ------------------------------------------------------------------
    # Fabric Manager service health
    # ------------------------------------------------------------------

    async def check_fabric_manager_service(self) -> FabricManagerStatus:
        """Check Fabric Manager service status, version, and driver compatibility."""
        status = FabricManagerStatus()

        if not self.systemctl_path:
            return status

        # Check service active state
        is_active = await self.executor.execute(
            f"{self.systemctl_path} is-active nvidia-fabricmanager",
            allow_nonzero=True,
        )
        if is_active is not None:
            is_active = is_active.strip()
            status.service_status = is_active
            status.service_active = (is_active == "active")

        # Check service enabled state
        is_enabled = await self.executor.execute(
            f"{self.systemctl_path} is-enabled nvidia-fabricmanager",
            allow_nonzero=True,
        )
        if is_enabled is not None:
            status.service_enabled = (is_enabled.strip() == "enabled")

        # Get FM version from nv-fabricmanager --version
        fm_binary = self.executor.find_binary("nv-fabricmanager")
        if fm_binary:
            version_output = await self.executor.execute(
                f"{fm_binary} --version",
                allow_nonzero=True,
            )
            if version_output:
                # Parse "Fabric Manager version is : 590.48.01"
                match = re.search(r"version\s+(?:is\s*:?\s*)?(\d+\.\d+\.\d+)", version_output)
                if match:
                    status.fm_version = match.group(1)

        # If binary version not found, try to parse from log startup line
        if not status.fm_version:
            status.fm_version = self._parse_fm_version_from_log()

        # Get driver version via NVML
        if self._init_nvml():
            try:
                driver_ver = self._safe_nvml_call(pynvml.nvmlSystemGetDriverVersion)
                if driver_ver:
                    status.driver_version = driver_ver
            finally:
                self._shutdown_nvml()

        # Compare major versions (e.g., 590.x must match 590.x)
        if status.fm_version and status.driver_version:
            fm_major = status.fm_version.split(".")[0]
            driver_major = status.driver_version.split(".")[0]
            status.version_match = (fm_major == driver_major)

        return status

    def _parse_fm_version_from_log(self) -> Optional[str]:
        """Extract FM version from startup line in fabricmanager.log."""
        if not FM_LOG_PATH.exists():
            return None

        try:
            with open(FM_LOG_PATH, "r") as f:
                for line in f:
                    # Match "Fabric Manager version 570.133.20 is running"
                    match = re.search(
                        r"Fabric Manager version\s+(\d+\.\d+\.\d+)", line
                    )
                    if match:
                        return match.group(1)
                    # Stop after first 50 lines to avoid reading entire log
                    if f.tell() > 10000:
                        break
        except Exception:
            pass

        return None

    # ------------------------------------------------------------------
    # GPU fabric info via NVML
    # ------------------------------------------------------------------

    def check_gpu_fabric_info(self) -> List[GPUFabricState]:
        """Check GPU fabric state for ALL GPUs.

        Prefers the versioned v2 API (nvmlDeviceGetGpuFabricInfoV) which
        includes a ``version`` field that prevents ABI mismatches between
        pynvml's ctypes struct and the driver's NVML library.  Falls back
        to the deprecated v1 API only when v2 is unavailable.
        """
        states = []
        if not self._init_nvml():
            return states

        try:
            gpu_count = self._safe_nvml_call(pynvml.nvmlDeviceGetCount, default=0)

            # Prefer v2 (versioned struct with ABI safety)
            fabric_info_struct_v2 = getattr(pynvml, "c_nvmlGpuFabricInfo_v2_t", None)
            fabric_info_func_v2 = getattr(pynvml, "nvmlDeviceGetGpuFabricInfoV", None)

            # Fall back to v1 (deprecated, no version field)
            fabric_info_struct_v1 = getattr(pynvml, "c_nvmlGpuFabricInfo_t", None)
            fabric_info_func_v1 = getattr(pynvml, "nvmlDeviceGetGpuFabricInfo", None)

            use_v2 = fabric_info_struct_v2 is not None and fabric_info_func_v2 is not None
            use_v1 = fabric_info_struct_v1 is not None and fabric_info_func_v1 is not None

            if not use_v2 and not use_v1:
                return states

            for i in range(gpu_count):
                handle = self._safe_nvml_call(pynvml.nvmlDeviceGetHandleByIndex, i)
                if handle is None:
                    continue

                try:
                    if use_v2:
                        info = fabric_info_struct_v2()
                        info.version = ctypes.sizeof(fabric_info_struct_v2) | (2 << 24)
                        fabric_info_func_v2(handle, ctypes.byref(info))
                    else:
                        info = fabric_info_struct_v1()
                        fabric_info_func_v1(handle, ctypes.byref(info))

                    state_int = info.state
                    state_str = GPU_FABRIC_STATE_MAP.get(state_int, f"UNKNOWN({state_int})")
                    states.append(GPUFabricState(gpu_index=i, fabric_state=state_str))
                except pynvml.NVMLError:
                    continue
                except Exception:
                    continue
        finally:
            self._shutdown_nvml()

        return states

    # ------------------------------------------------------------------
    # FM log parsing
    # ------------------------------------------------------------------

    def parse_fm_log(self) -> List[FMLogEntry]:
        """Parse last 200 lines of fabricmanager.log for errors and notable entries."""
        entries: List[FMLogEntry] = []

        if not FM_LOG_PATH.exists():
            return entries

        try:
            with open(FM_LOG_PATH, "r") as f:
                lines = f.readlines()

            # Take last 200 lines
            tail_lines = lines[-200:] if len(lines) > 200 else lines

            for line in tail_lines:
                line = line.strip()
                if not line:
                    continue

                # Match ERROR and CRITICAL lines
                if "[ERROR]" in line or "[CRITICAL]" in line:
                    level = "ERROR" if "[ERROR]" in line else "CRITICAL"
                    entries.append(FMLogEntry(level=level, message=line))

        except Exception:
            pass

        return entries

    # ------------------------------------------------------------------
    # Run all checks
    # ------------------------------------------------------------------

    async def run_all_checks(self) -> FabricDiagnosticsResult:
        """Run all Fabric Manager and NVSwitch diagnostics."""
        result = FabricDiagnosticsResult(timestamp=datetime.now())

        # Known NVSwitch counts per platform.
        # Order matters: longer/more-specific names first to avoid
        # substring false positives (e.g. "B200" matching "GB200").
        EXPECTED_NVSWITCH_COUNTS = [
            ("GB200", 18),   # GB200 NVL72 has 18 NVSwitches
            ("B200", 4),     # DGX B200
            ("H200", 4),     # DGX H200
            ("H100", 4),     # DGX H100
            ("A100", 6),     # DGX A100 / HGX A100
        ]

        try:
            # Step 1: Detect NVSwitches
            result.nvswitches = self.detect_nvswitches()
            result.nvswitch_count = len(result.nvswitches)
            result.system_needs_fabric_manager = result.nvswitch_count > 0

            if not result.system_needs_fabric_manager:
                # No NVSwitches -- nothing more to check
                return result

            # Step 1b: Check for NVSwitch BIOS version mismatches
            if result.nvswitches:
                bios_versions = set()
                for sw in result.nvswitches:
                    if sw.bios_version:
                        bios_versions.add(sw.bios_version)
                if len(bios_versions) > 1:
                    result.nvswitch_bios_version_mismatch = True
                    result.warnings.append(
                        f"NVSwitch BIOS versions differ: {', '.join(sorted(bios_versions))}"
                    )

            # Step 1c: Validate NVSwitch count against expected for GPU platform
            if result.nvswitch_count > 0 and self._init_nvml():
                try:
                    handle = self._safe_nvml_call(pynvml.nvmlDeviceGetHandleByIndex, 0)
                    if handle:
                        gpu_name = self._safe_nvml_call(pynvml.nvmlDeviceGetName, handle, default="")
                        for platform, expected in EXPECTED_NVSWITCH_COUNTS:
                            if platform in gpu_name:
                                result.expected_nvswitch_count = expected
                                if result.nvswitch_count != expected:
                                    result.warnings.append(
                                        f"Expected {expected} NVSwitches for {platform} but found {result.nvswitch_count}"
                                    )
                                break
                finally:
                    self._shutdown_nvml()

            # Step 2: Check FM service health and versions
            result.fabric_manager = await self.check_fabric_manager_service()

            # Step 3: Check GPU fabric state via NVML (all GPUs)
            result.gpu_fabric_states = self.check_gpu_fabric_info()

            # Step 4: Parse FM log for errors
            result.fm_log_errors = self.parse_fm_log()

            # Step 5: Generate errors and warnings
            fm = result.fabric_manager

            if fm and not fm.service_active:
                if fm.service_status == "failed":
                    result.errors.append(
                        "Fabric Manager service is in FAILED state "
                        "- NVSwitch fabric is not operational"
                    )
                else:
                    result.errors.append(
                        f"Fabric Manager service is not running "
                        f"(status: {fm.service_status}) "
                        f"- NVSwitches present but fabric is not managed"
                    )

            if fm and not fm.service_enabled:
                result.warnings.append(
                    "Fabric Manager service is not enabled "
                    "- it will not start automatically on boot"
                )

            if fm and fm.version_match is False:
                result.errors.append(
                    f"Fabric Manager / driver version MISMATCH: "
                    f"FM {fm.fm_version} vs driver {fm.driver_version} "
                    f"- major versions must match"
                )

            # Check per-GPU fabric states for issues
            for gpu_state in result.gpu_fabric_states:
                if gpu_state.fabric_state == "NOT_SUPPORTED":
                    result.warnings.append(
                        f"GPU {gpu_state.gpu_index} fabric state reports NOT_SUPPORTED despite NVSwitches being present"
                    )
                elif gpu_state.fabric_state == "NOT_STARTED":
                    result.warnings.append(
                        f"GPU {gpu_state.gpu_index} fabric state is NOT_STARTED - "
                        "Fabric Manager may need to be started"
                    )

            if result.fm_log_errors:
                error_count = len(result.fm_log_errors)
                result.warnings.append(
                    f"Fabric Manager log contains {error_count} error(s) "
                    f"in the last 200 lines"
                )

        except Exception as e:
            result.errors.append(
                f"Unexpected error during fabric diagnostics: {e}"
            )

        return result

    # ------------------------------------------------------------------
    # Report formatting
    # ------------------------------------------------------------------

    def format_report(self, result: FabricDiagnosticsResult) -> str:
        """Format results as a JSON report."""
        result_dict = asdict(result)
        result_dict.pop("warnings", None)
        return json.dumps(result_dict, indent=4, default=str)


# ---------------------------------------------------------------------------
# Module entry point
# ---------------------------------------------------------------------------

async def run_fabric_diagnostics():
    """Run Fabric Manager diagnostics and return the JSON report."""
    diagnostics = FabricDiagnostics()
    result = await diagnostics.run_all_checks()
    return diagnostics.format_report(result)
