"""Shared constants for NVIDIA diagnostic modules."""

ARCHITECTURE_MAP = {
    2: "Kepler",
    3: "Maxwell",
    4: "Pascal",
    5: "Volta",
    6: "Turing",
    7: "Ampere",
    8: "Ada",
    9: "Hopper",
    10: "Blackwell",
}

THROTTLE_REASONS = {
    0x0000000000000001: "GPU Idle",
    0x0000000000000002: "Applications Clocks Setting",
    0x0000000000000004: "SW Power Cap",
    0x0000000000000008: "HW Slowdown",
    0x0000000000000010: "Sync Boost",
    0x0000000000000020: "SW Thermal Slowdown",
    0x0000000000000040: "HW Thermal Slowdown",
    0x0000000000000080: "HW Power Brake Slowdown",
    0x0000000000000100: "Display Clock Setting",
}
