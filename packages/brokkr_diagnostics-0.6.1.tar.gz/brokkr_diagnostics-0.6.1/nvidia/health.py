"""
Unified machine health check.

Auto-detects machine topology (PCIe-only, NVLink, NVSwitch) and runs
the appropriate checks to produce a single HEALTHY / DEGRADED / UNHEALTHY
verdict with per-category breakdowns.
"""

from dataclasses import dataclass, field, asdict
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional
import json
import pynvml

from .nvml_mixin import NVMLMixin
from .constants import ARCHITECTURE_MAP
from ..core.executor import Executor
from ..core.cuda import CUDAInterface


# ---------------------------------------------------------------------------
# Dataclass models
# ---------------------------------------------------------------------------

@dataclass
class HealthCheck:
    """A single health check result."""
    name: str
    status: str  # "pass", "warn", "fail"
    message: Optional[str] = None


@dataclass
class HealthCategory:
    """Health status for a category of checks."""
    category: str
    status: str  # "pass", "warn", "fail"
    checks: List[HealthCheck] = field(default_factory=list)


@dataclass
class MachineTopology:
    """Detected machine topology."""
    gpu_count: int = 0
    gpu_name: Optional[str] = None
    architecture: Optional[str] = None
    nvlink_present: bool = False
    nvlink_per_gpu: int = 0
    nvswitch_present: bool = False
    nvswitch_count: int = 0
    infiniband_present: bool = False
    topology_type: str = "unknown"  # "pcie", "nvlink", "nvswitch"


@dataclass
class HealthResult:
    """Aggregate health result."""
    timestamp: datetime
    overall_status: str = "HEALTHY"  # HEALTHY, DEGRADED, UNHEALTHY
    topology: Optional[MachineTopology] = None
    categories: List[HealthCategory] = field(default_factory=list)
    issue_count: int = 0
    issues: List[str] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Health diagnostics
# ---------------------------------------------------------------------------

class HealthDiagnostics(NVMLMixin):
    """
    Unified machine health check.

    Detects machine topology, then runs targeted checks:
    - GPU enumeration and basic health (all machines)
    - ECC / memory health (all machines)
    - NVLink health (NVLink/NVSwitch machines)
    - Fabric Manager health (NVSwitch machines)
    - PCIe link health (all machines)
    - Thermal / throttle health (all machines)
    - Driver / services health (all machines)
    - Kernel error check (all machines)
    """

    NVSWITCH_PROC = Path("/proc/driver/nvidia-nvswitch/devices")
    IB_SYSFS = Path("/sys/class/infiniband")

    def __init__(self):
        super().__init__()
        self.executor = Executor()

    # ------------------------------------------------------------------
    # Topology detection
    # ------------------------------------------------------------------

    def detect_topology(self) -> MachineTopology:
        """Detect machine topology from hardware."""
        topo = MachineTopology()

        if not self._init_nvml():
            return topo

        topo.gpu_count = self._safe_nvml_call(pynvml.nvmlDeviceGetCount, default=0)

        if topo.gpu_count > 0:
            handle = self._safe_nvml_call(pynvml.nvmlDeviceGetHandleByIndex, 0)
            if handle:
                topo.gpu_name = self._safe_nvml_call(
                    pynvml.nvmlDeviceGetName, handle, default="Unknown"
                )
                arch_id = self._safe_nvml_call(pynvml.nvmlDeviceGetArchitecture, handle)
                if arch_id is not None:
                    topo.architecture = ARCHITECTURE_MAP.get(arch_id)

                # Count NVLink links on first GPU
                for link in range(24):
                    state = self._safe_nvml_call(
                        pynvml.nvmlDeviceGetNvLinkState, handle, link
                    )
                    if state is None:
                        break
                    if state == 1:
                        topo.nvlink_per_gpu += 1
                topo.nvlink_present = topo.nvlink_per_gpu > 0

        # NVSwitch detection
        if self.NVSWITCH_PROC.exists():
            try:
                switches = [d for d in self.NVSWITCH_PROC.iterdir() if d.is_dir()]
                topo.nvswitch_count = len(switches)
                topo.nvswitch_present = topo.nvswitch_count > 0
            except Exception:
                pass

        # InfiniBand detection
        topo.infiniband_present = self.IB_SYSFS.exists() and any(
            d.is_dir() for d in self.IB_SYSFS.iterdir()
        ) if self.IB_SYSFS.exists() else False

        # Classify topology type
        if topo.nvswitch_present:
            topo.topology_type = "nvswitch"
        elif topo.nvlink_present:
            topo.topology_type = "nvlink"
        else:
            topo.topology_type = "pcie"

        return topo

    # ------------------------------------------------------------------
    # Per-category health checks
    # ------------------------------------------------------------------

    def check_gpu_presence(self, topo: MachineTopology) -> HealthCategory:
        """Check that GPUs are present and enumerable."""
        cat = HealthCategory(category="gpu_presence", status="pass")

        if topo.gpu_count == 0:
            cat.checks.append(HealthCheck(
                name="gpu_count", status="fail",
                message="No GPUs detected",
            ))
            cat.status = "fail"
            return cat

        cat.checks.append(HealthCheck(
            name="gpu_count", status="pass",
            message=f"{topo.gpu_count} GPU(s) detected ({topo.gpu_name})",
        ))

        # Check all GPUs respond to NVML
        for i in range(topo.gpu_count):
            handle = self._safe_nvml_call(pynvml.nvmlDeviceGetHandleByIndex, i)
            if handle is None:
                cat.checks.append(HealthCheck(
                    name=f"gpu_{i}_handle", status="fail",
                    message=f"GPU {i}: cannot get NVML handle",
                ))
                cat.status = "fail"

        return cat

    def check_ecc_health(self) -> HealthCategory:
        """Check ECC errors and memory health across all GPUs."""
        cat = HealthCategory(category="memory_health", status="pass")
        gpu_count = self._safe_nvml_call(pynvml.nvmlDeviceGetCount, default=0)

        for i in range(gpu_count):
            handle = self._safe_nvml_call(pynvml.nvmlDeviceGetHandleByIndex, i)
            if not handle:
                continue

            # ECC mode
            ecc_mode = self._safe_nvml_call(pynvml.nvmlDeviceGetEccMode, handle)
            if ecc_mode is not None and ecc_mode[0] != pynvml.NVML_FEATURE_ENABLED:
                cat.checks.append(HealthCheck(
                    name=f"gpu_{i}_ecc_mode", status="warn",
                    message=f"GPU {i}: ECC is disabled",
                ))
                if cat.status == "pass":
                    cat.status = "warn"

            # Uncorrected ECC errors
            uncorr_agg = self._safe_nvml_call(
                pynvml.nvmlDeviceGetTotalEccErrors, handle,
                pynvml.NVML_MEMORY_ERROR_TYPE_UNCORRECTED, pynvml.NVML_AGGREGATE_ECC,
            )
            if uncorr_agg is not None and uncorr_agg > 0:
                cat.checks.append(HealthCheck(
                    name=f"gpu_{i}_uncorrected_ecc", status="fail",
                    message=f"GPU {i}: {uncorr_agg} uncorrected ECC errors (aggregate)",
                ))
                cat.status = "fail"

            # Remapped rows (Ampere+)
            remapped = self._safe_nvml_call(pynvml.nvmlDeviceGetRemappedRows, handle)
            if remapped:
                if remapped[3]:  # failure flag
                    cat.checks.append(HealthCheck(
                        name=f"gpu_{i}_row_remap_failure", status="fail",
                        message=f"GPU {i}: row remapping FAILED - no spare rows, needs RMA",
                    ))
                    cat.status = "fail"
                elif remapped[1] and remapped[1] > 0:  # uncorrectable remapped
                    cat.checks.append(HealthCheck(
                        name=f"gpu_{i}_row_remap_uncorr", status="warn",
                        message=f"GPU {i}: {remapped[1]} uncorrectable remapped rows",
                    ))
                    if cat.status == "pass":
                        cat.status = "warn"

            # Pending repair
            repair_fn = getattr(pynvml, "nvmlDeviceGetRepairStatus", None)
            if repair_fn:
                repair = self._safe_nvml_call(repair_fn, handle)
                if repair and (repair[0] or repair[1]):
                    cat.checks.append(HealthCheck(
                        name=f"gpu_{i}_repair_pending", status="warn",
                        message=f"GPU {i}: repair pending (channel={repair[0]}, tpc={repair[1]})",
                    ))
                    if cat.status == "pass":
                        cat.status = "warn"

        if cat.status == "pass":
            cat.checks.append(HealthCheck(
                name="ecc_summary", status="pass",
                message=f"All {gpu_count} GPU(s): zero uncorrected ECC errors, memory healthy",
            ))

        return cat

    def check_nvlink_health(self, topo: MachineTopology) -> Optional[HealthCategory]:
        """Check NVLink health. Only runs if NVLink is present."""
        if not topo.nvlink_present:
            return None

        cat = HealthCategory(category="nvlink", status="pass")
        gpu_count = self._safe_nvml_call(pynvml.nvmlDeviceGetCount, default=0)

        total_errors = 0
        inactive_links = 0

        for i in range(gpu_count):
            handle = self._safe_nvml_call(pynvml.nvmlDeviceGetHandleByIndex, i)
            if not handle:
                continue

            active_count = 0
            for link in range(24):
                state = self._safe_nvml_call(pynvml.nvmlDeviceGetNvLinkState, handle, link)
                if state is None:
                    break
                if state == 1:
                    active_count += 1
                else:
                    inactive_links += 1

                # Error counters
                for err_const_name in ["NVML_NVLINK_ERROR_DL_CRC_FLIT", "NVML_NVLINK_ERROR_DL_REPLAY"]:
                    err_const = getattr(pynvml, err_const_name, None)
                    if err_const is None:
                        continue
                    count = self._safe_nvml_call(
                        pynvml.nvmlDeviceGetNvLinkErrorCounter, handle, link, err_const
                    )
                    if count is not None and count > 0:
                        total_errors += count

        if inactive_links > 0:
            cat.checks.append(HealthCheck(
                name="nvlink_inactive", status="warn",
                message=f"{inactive_links} NVLink link(s) inactive across all GPUs",
            ))
            cat.status = "warn"

        if total_errors > 0:
            cat.checks.append(HealthCheck(
                name="nvlink_errors", status="warn",
                message=f"{total_errors} NVLink CRC/replay errors across all GPUs",
            ))
            cat.status = "warn"

        if cat.status == "pass":
            cat.checks.append(HealthCheck(
                name="nvlink_summary", status="pass",
                message=f"All NVLink links active, zero errors",
            ))

        return cat

    async def check_fabric_health(self, topo: MachineTopology) -> Optional[HealthCategory]:
        """Check Fabric Manager / NVSwitch health. Only runs if NVSwitch present."""
        if not topo.nvswitch_present:
            return None

        cat = HealthCategory(category="fabric_manager", status="pass")

        # FM service status
        systemctl = self.executor.find_binary("systemctl")
        if systemctl:
            is_active = await self.executor.execute(
                f"{systemctl} is-active nvidia-fabricmanager", allow_nonzero=True
            )
            if is_active and is_active.strip() != "active":
                cat.checks.append(HealthCheck(
                    name="fm_service", status="fail",
                    message=f"Fabric Manager service is {is_active.strip()} (expected: active)",
                ))
                cat.status = "fail"
            else:
                cat.checks.append(HealthCheck(
                    name="fm_service", status="pass",
                    message="Fabric Manager service is active",
                ))

        # FM / driver version match
        driver_ver = self._safe_nvml_call(pynvml.nvmlSystemGetDriverVersion)
        if driver_ver:
            fm_bin = self.executor.find_binary("nv-fabricmanager")
            if fm_bin:
                import re
                fm_ver_output = await self.executor.execute(
                    f"{fm_bin} --version", allow_nonzero=True
                )
                if fm_ver_output:
                    fm_match = re.search(r"(\d+)\.\d+\.\d+", fm_ver_output)
                    drv_match = re.search(r"(\d+)\.\d+\.\d+", driver_ver)
                    if fm_match and drv_match:
                        if fm_match.group(1) != drv_match.group(1):
                            cat.checks.append(HealthCheck(
                                name="fm_version_match", status="fail",
                                message=f"FM/driver version mismatch: FM {fm_ver_output.strip()} vs driver {driver_ver}",
                            ))
                            cat.status = "fail"

        # NVSwitch count
        cat.checks.append(HealthCheck(
            name="nvswitch_count", status="pass",
            message=f"{topo.nvswitch_count} NVSwitch(es) detected",
        ))

        return cat

    def check_pcie_health(self) -> HealthCategory:
        """Check PCIe link speed and width for all GPUs."""
        cat = HealthCategory(category="pcie", status="pass")
        gpu_count = self._safe_nvml_call(pynvml.nvmlDeviceGetCount, default=0)

        for i in range(gpu_count):
            handle = self._safe_nvml_call(pynvml.nvmlDeviceGetHandleByIndex, i)
            if not handle:
                continue

            gen_cur = self._safe_nvml_call(pynvml.nvmlDeviceGetCurrPcieLinkGeneration, handle)
            gen_max = self._safe_nvml_call(pynvml.nvmlDeviceGetMaxPcieLinkGeneration, handle)
            width_cur = self._safe_nvml_call(pynvml.nvmlDeviceGetCurrPcieLinkWidth, handle)
            width_max = self._safe_nvml_call(pynvml.nvmlDeviceGetMaxPcieLinkWidth, handle)

            if gen_cur is not None and gen_max is not None and gen_cur < gen_max:
                cat.checks.append(HealthCheck(
                    name=f"gpu_{i}_pcie_gen", status="warn",
                    message=f"GPU {i}: PCIe Gen{gen_cur} (max Gen{gen_max})",
                ))
                if cat.status == "pass":
                    cat.status = "warn"

            if width_cur is not None and width_max is not None and width_cur < width_max:
                severity = "fail" if width_cur <= width_max // 4 else "warn"
                cat.checks.append(HealthCheck(
                    name=f"gpu_{i}_pcie_width", status=severity,
                    message=f"GPU {i}: PCIe x{width_cur} (max x{width_max})",
                ))
                if severity == "fail":
                    cat.status = "fail"
                elif cat.status == "pass":
                    cat.status = "warn"

            # PCIe fatal errors via field values
            fv = self._safe_nvml_call(pynvml.nvmlDeviceGetFieldValues, handle, [180])
            if fv and len(fv) > 0 and hasattr(fv[0], 'nvmlReturn') and fv[0].nvmlReturn == 0:
                fatal_count = fv[0].value.uiVal if hasattr(fv[0].value, 'uiVal') else 0
                if fatal_count > 0:
                    cat.checks.append(HealthCheck(
                        name=f"gpu_{i}_pcie_fatal", status="fail",
                        message=f"GPU {i}: {fatal_count} PCIe fatal error(s)",
                    ))
                    cat.status = "fail"

        if cat.status == "pass":
            cat.checks.append(HealthCheck(
                name="pcie_summary", status="pass",
                message=f"All {gpu_count} GPU(s): PCIe links at full speed/width, zero fatal errors",
            ))

        return cat

    def check_thermal_health(self) -> HealthCategory:
        """Check GPU temperatures and throttle violations."""
        cat = HealthCategory(category="thermal_power", status="pass")
        gpu_count = self._safe_nvml_call(pynvml.nvmlDeviceGetCount, default=0)

        for i in range(gpu_count):
            handle = self._safe_nvml_call(pynvml.nvmlDeviceGetHandleByIndex, i)
            if not handle:
                continue

            # Temperature vs slowdown threshold
            temp = self._safe_nvml_call(
                pynvml.nvmlDeviceGetTemperature, handle, pynvml.NVML_TEMPERATURE_GPU
            )
            slowdown = self._safe_nvml_call(
                pynvml.nvmlDeviceGetTemperatureThreshold, handle,
                pynvml.NVML_TEMPERATURE_THRESHOLD_SLOWDOWN,
            )
            if temp is not None and slowdown is not None:
                headroom = slowdown - temp
                if headroom <= 3:
                    cat.checks.append(HealthCheck(
                        name=f"gpu_{i}_temp", status="fail",
                        message=f"GPU {i}: {temp}C — only {headroom}C below slowdown ({slowdown}C)",
                    ))
                    cat.status = "fail"
                elif headroom <= 10:
                    cat.checks.append(HealthCheck(
                        name=f"gpu_{i}_temp", status="warn",
                        message=f"GPU {i}: {temp}C — {headroom}C below slowdown ({slowdown}C)",
                    ))
                    if cat.status == "pass":
                        cat.status = "warn"

            # HW throttle active right now
            throttle = self._safe_nvml_call(
                pynvml.nvmlDeviceGetCurrentClocksThrottleReasons, handle
            )
            hw_throttle_bits = 0x0000000000000008 | 0x0000000000000040 | 0x0000000000000080
            if throttle is not None and (throttle & hw_throttle_bits):
                cat.checks.append(HealthCheck(
                    name=f"gpu_{i}_hw_throttle", status="fail",
                    message=f"GPU {i}: hardware throttling active (0x{throttle:x})",
                ))
                cat.status = "fail"

            # Violation time (cumulative)
            for policy_name, policy_const in [
                ("power", pynvml.NVML_PERF_POLICY_POWER),
                ("thermal", pynvml.NVML_PERF_POLICY_THERMAL),
            ]:
                violation = self._safe_nvml_call(
                    pynvml.nvmlDeviceGetViolationStatus, handle, policy_const
                )
                if violation and violation.violationTime > 0:
                    secs = violation.violationTime / 1_000_000_000
                    if secs > 60:
                        cat.checks.append(HealthCheck(
                            name=f"gpu_{i}_{policy_name}_violation", status="warn",
                            message=f"GPU {i}: {secs:.0f}s cumulative {policy_name} throttling",
                        ))
                        if cat.status == "pass":
                            cat.status = "warn"

        if cat.status == "pass":
            cat.checks.append(HealthCheck(
                name="thermal_summary", status="pass",
                message=f"All {gpu_count} GPU(s): temperatures normal, no throttling",
            ))

        return cat

    def check_p2p_health(self, topo: MachineTopology) -> Optional[HealthCategory]:
        """Check GPU-to-GPU P2P communication. Only runs if >1 GPU."""
        if topo.gpu_count < 2:
            return None

        cat = HealthCategory(category="p2p_communication", status="pass")

        try:
            cuda = CUDAInterface()
        except RuntimeError:
            cat.checks.append(HealthCheck(
                name="cuda_runtime", status="warn",
                message="libcudart.so not available — cannot test P2P",
            ))
            cat.status = "warn"
            return cat

        gpu_count = cuda.get_device_count()
        failed_pairs = []
        size_bytes = 4 * 1024 * 1024  # 4 MiB — small, fast, enough to validate path

        for i in range(gpu_count):
            for j in range(i + 1, gpu_count):
                src_ptr = None
                dst_ptr = None
                try:
                    # Check P2P capability
                    can_p2p = cuda.can_access_peer(i, j)

                    # Allocate on source
                    cuda.set_device(i)
                    src_ptr = cuda.malloc(size_bytes)

                    # Allocate on destination
                    cuda.set_device(j)
                    dst_ptr = cuda.malloc(size_bytes)

                    # Enable P2P if supported
                    if can_p2p:
                        cuda.set_device(i)
                        cuda.enable_peer_access(j)
                        cuda.set_device(j)
                        cuda.enable_peer_access(i)

                    # Copy GPU i -> GPU j
                    cuda.set_device(i)
                    cuda.memcpy_d2d(dst_ptr, src_ptr, size_bytes)
                    cuda.device_synchronize()

                except Exception as e:
                    failed_pairs.append((i, j, str(e)))
                finally:
                    if src_ptr is not None:
                        try:
                            cuda.set_device(i)
                            cuda.free(src_ptr)
                        except Exception:
                            pass
                    if dst_ptr is not None:
                        try:
                            cuda.set_device(j)
                            cuda.free(dst_ptr)
                        except Exception:
                            pass

        if failed_pairs:
            for src, dst, err in failed_pairs:
                cat.checks.append(HealthCheck(
                    name=f"p2p_{src}_{dst}", status="fail",
                    message=f"GPU {src} -> GPU {dst}: P2P copy failed — {err}",
                ))
            cat.status = "fail"

            # Check known issues for this architecture
            known_fix = self._lookup_known_issue("p2p_failure", topo)
            if known_fix:
                cat.checks.append(HealthCheck(
                    name="known_issue", status="fail",
                    message=known_fix,
                ))
        else:
            cat.checks.append(HealthCheck(
                name="p2p_summary", status="pass",
                message=f"All {gpu_count * (gpu_count - 1) // 2} GPU pair(s): P2P communication working",
            ))

        return cat

    # ------------------------------------------------------------------
    # Known issues database
    # ------------------------------------------------------------------

    # (symptom, architecture) -> fix message
    KNOWN_ISSUES = {
        ("p2p_failure", "Blackwell"): (
            "Known Blackwell issue: P2P may fail with all GPUs unless UVM HMM is disabled. "
            "Fix: set nvidia_uvm.uvm_hmm=0 via kernel parameter or "
            "echo 0 > /sys/module/nvidia_uvm/parameters/uvm_hmm"
        ),
    }

    def _lookup_known_issue(self, symptom: str, topo: MachineTopology) -> Optional[str]:
        """Look up a known issue by symptom and architecture."""
        if topo.architecture:
            fix = self.KNOWN_ISSUES.get((symptom, topo.architecture))
            if fix:
                return fix
        return None

    # ------------------------------------------------------------------

    def check_driver_health(self) -> HealthCategory:
        """Check driver is loaded and in good state."""
        cat = HealthCategory(category="driver", status="pass")

        driver_ver = self._safe_nvml_call(pynvml.nvmlSystemGetDriverVersion)
        if not driver_ver:
            cat.checks.append(HealthCheck(
                name="driver_loaded", status="fail",
                message="NVIDIA driver not loaded or NVML unavailable",
            ))
            cat.status = "fail"
            return cat

        cat.checks.append(HealthCheck(
            name="driver_version", status="pass",
            message=f"Driver {driver_ver} loaded",
        ))

        # Persistence mode on all GPUs
        gpu_count = self._safe_nvml_call(pynvml.nvmlDeviceGetCount, default=0)
        for i in range(gpu_count):
            handle = self._safe_nvml_call(pynvml.nvmlDeviceGetHandleByIndex, i)
            if not handle:
                continue
            pm = self._safe_nvml_call(pynvml.nvmlDeviceGetPersistenceMode, handle)
            if pm is not None and pm != pynvml.NVML_FEATURE_ENABLED:
                cat.checks.append(HealthCheck(
                    name=f"gpu_{i}_persistence", status="warn",
                    message=f"GPU {i}: persistence mode disabled",
                ))
                if cat.status == "pass":
                    cat.status = "warn"

        return cat

    async def check_kernel_errors(self) -> HealthCategory:
        """Check for critical kernel errors (XID, SXid, OOM, lockups)."""
        cat = HealthCategory(category="kernel_errors", status="pass")

        dmesg_path = self.executor.find_binary("dmesg")
        if not dmesg_path:
            return cat

        output = await self.executor.execute(f"sudo {dmesg_path}", allow_nonzero=True)
        if not output:
            return cat

        xid_count = 0
        sxid_count = 0
        fallen_off = 0
        oom_count = 0

        for line in output.split("\n"):
            lower = line.lower()
            if "xid" in lower and "nvidia" in lower:
                xid_count += 1
            if "sxid" in lower:
                sxid_count += 1
            if "fallen off" in lower or "gpu has fallen" in lower:
                fallen_off += 1
            if "out of memory" in lower and "killed process" in lower:
                oom_count += 1

        if fallen_off > 0:
            cat.checks.append(HealthCheck(
                name="gpu_fallen_off_bus", status="fail",
                message=f"{fallen_off} GPU fallen-off-bus event(s) in dmesg",
            ))
            cat.status = "fail"

        if xid_count > 0:
            severity = "fail" if xid_count > 5 else "warn"
            cat.checks.append(HealthCheck(
                name="xid_errors", status=severity,
                message=f"{xid_count} XID error(s) in dmesg",
            ))
            if severity == "fail" or cat.status == "pass":
                cat.status = severity

        if sxid_count > 0:
            cat.checks.append(HealthCheck(
                name="sxid_errors", status="warn",
                message=f"{sxid_count} SXid error(s) in dmesg",
            ))
            if cat.status == "pass":
                cat.status = "warn"

        if oom_count > 0:
            cat.checks.append(HealthCheck(
                name="oom_kills", status="warn",
                message=f"{oom_count} OOM kill event(s) in dmesg",
            ))
            if cat.status == "pass":
                cat.status = "warn"

        if cat.status == "pass":
            cat.checks.append(HealthCheck(
                name="kernel_summary", status="pass",
                message="No XID errors, SXid errors, OOM kills, or GPU faults in dmesg",
            ))

        return cat

    # ------------------------------------------------------------------
    # Run all checks
    # ------------------------------------------------------------------

    async def run_all_checks(self) -> HealthResult:
        """Run all health checks and produce unified verdict."""
        result = HealthResult(timestamp=datetime.now())

        if not self._init_nvml():
            result.overall_status = "UNHEALTHY"
            result.errors.append("Failed to initialize NVML — driver may not be loaded")
            return result

        try:
            # Step 1: Detect topology
            topo = self.detect_topology()
            result.topology = topo

            # Step 2: Run checks based on detected topology
            categories = []

            # Always run
            categories.append(self.check_gpu_presence(topo))
            categories.append(self.check_driver_health())
            categories.append(self.check_ecc_health())
            categories.append(self.check_pcie_health())
            categories.append(self.check_thermal_health())
            categories.append(await self.check_kernel_errors())

            # P2P communication (multi-GPU only)
            p2p_cat = self.check_p2p_health(topo)
            if p2p_cat:
                categories.append(p2p_cat)

            # Only if NVLink present
            nvlink_cat = self.check_nvlink_health(topo)
            if nvlink_cat:
                categories.append(nvlink_cat)

            # Only if NVSwitch present
            fabric_cat = await self.check_fabric_health(topo)
            if fabric_cat:
                categories.append(fabric_cat)

            result.categories = categories

            # Step 3: Compute overall status
            has_fail = any(c.status == "fail" for c in categories)
            has_warn = any(c.status == "warn" for c in categories)

            if has_fail:
                result.overall_status = "UNHEALTHY"
            elif has_warn:
                result.overall_status = "DEGRADED"
            else:
                result.overall_status = "HEALTHY"

            # Collect all non-pass checks as issues
            for cat in categories:
                for check in cat.checks:
                    if check.status != "pass":
                        result.issues.append(check.message)
            result.issue_count = len(result.issues)

        except Exception as e:
            result.errors.append(f"Health check error: {e}")
            result.overall_status = "UNHEALTHY"
        finally:
            self._shutdown_nvml()

        return result

    # ------------------------------------------------------------------
    # Report formatting
    # ------------------------------------------------------------------

    def format_report(self, result: HealthResult) -> str:
        """Format results as a JSON report."""
        result_dict = asdict(result)
        result_dict.pop("warnings", None)
        return json.dumps(result_dict, indent=4, default=str)


# ---------------------------------------------------------------------------
# Module entry point
# ---------------------------------------------------------------------------

async def run_health_check():
    """Run unified health check and return the JSON report."""
    diagnostics = HealthDiagnostics()
    result = await diagnostics.run_all_checks()
    return diagnostics.format_report(result)
