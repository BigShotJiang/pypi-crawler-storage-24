"""
Send diagnostic results to Brokkr API.
"""

import asyncio
import gzip
import json
from typing import Optional
from termcolor import cprint

from .config import load_creds, get_api_url, get_timeout, BrokkrCreds
from ..console.commands import COMMANDS, resolve_command
import aiohttp

DIAG_TYPE_MAP = {
    "driver": "Driver",
    "gpu": "Gpu",
    "nvlink": "Nvlink",
    "lspci": "Lspci",
    "services": "Services",
    "kernel": "Kernel",
    "system": "System",
    "ib": "Infiniband",
    "storage": "Storage",
    "thermal": "Thermal",
    "cuda": "Cuda",
    "health": "Health",
    "fabric": "Fabric",
    "ecc": "Ecc",
}


def _build_headers(creds: BrokkrCreds) -> Optional[dict]:
    """Build request headers from creds. Returns None if auth is missing."""
    if not creds.cipher or not creds.signature:
        cprint(
            "Error: Missing cipher or signature, please contact support",
            "red"
        )
        return None

    return {
        "Content-Type": "application/json",
        "x-brokkr-cipher": creds.cipher,
        "x-brokkr-signature": creds.signature,
        "x-brokkr-job-id": creds.job_id,
    }


async def _run_and_send(name: str, config: dict, base_url: str, headers: dict) -> bool:
    """Run a single diagnostic and POST the result."""
    diag_type = DIAG_TYPE_MAP.get(name)
    if not diag_type:
        return True

    cprint(f"  Running {name}...", "cyan", end="", flush=True)
    try:
        result_json = await config["func"]()
        if not result_json:
            cprint(" skipped (no output)", "yellow")
            return True
        data = json.loads(result_json)
    except Exception as e:
        cprint(f" failed: {e}", "red")
        return False

    payload = {"type": diag_type, "data": data}
    raw = json.dumps(payload).encode()
    compressed = gzip.compress(raw)
    url = f"{base_url}/bmc/diagnostics"

    try:
        timeout = aiohttp.ClientTimeout(total=get_timeout())
        send_headers = {**headers, "Content-Encoding": "gzip"}
        async with aiohttp.ClientSession(timeout=timeout) as session:
            async with session.post(url, data=compressed, headers=send_headers) as resp:
                if resp.status in (200, 201, 202):
                    cprint(f" sent ({resp.status})", "green")
                    return True
                else:
                    body = await resp.text()
                    cprint(f" HTTP {resp.status}: {body[:200]}", "red")
                    return False
    except Exception as e:
        cprint(f" send failed: {e}", "red")
        return False


async def _send_all(command: Optional[str], base_url: str, headers: dict) -> int:
    if command:
        resolved = resolve_command(command)
        if not resolved or resolved not in DIAG_TYPE_MAP:
            cprint(f"Unknown or unsendable command: '{command}'", "red")
            return 1
        ok = await _run_and_send(resolved, COMMANDS[resolved], base_url, headers)
        return 0 if ok else 1

    failures = 0
    for name, config in COMMANDS.items():
        if name not in DIAG_TYPE_MAP:
            continue
        if config.get("requires_root") or not config.get("async"):
            continue
        ok = await _run_and_send(name, config, base_url, headers)
        if not ok:
            failures += 1

    return 1 if failures else 0


def send_diagnostics(command: Optional[str] = None) -> int:
    """Run diagnostics and send results to Brokkr."""
    creds = load_creds()
    base_url = get_api_url()
    headers = _build_headers(creds)

    if headers is None:
        return 1

    cprint(f"Sending diagnostics to {base_url} (job: {creds.job_id})", "cyan")
    return asyncio.run(_send_all(command, base_url, headers))
