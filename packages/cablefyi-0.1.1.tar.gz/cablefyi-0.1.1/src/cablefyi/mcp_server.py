"""MCP server for cablefyi — AI assistant tools for cablefyi.com.

Run: uvx --from "cablefyi[mcp]" python -m cablefyi.mcp_server
"""
from __future__ import annotations

from mcp.server.fastmcp import FastMCP

mcp = FastMCP("CableFYI")


@mcp.tool()
def list_cables(limit: int = 20, offset: int = 0) -> str:
    """List cables from cablefyi.com.

    Args:
        limit: Maximum number of results. Default 20.
        offset: Number of results to skip. Default 0.
    """
    from cablefyi.api import CableFYI

    with CableFYI() as api:
        data = api.list_cables(limit=limit, offset=offset)
        results = data.get("results", data) if isinstance(data, dict) else data
        if not results:
            return "No cables found."
        items = results[:limit] if isinstance(results, list) else []
        return "\n".join(f"- {item.get('name', item.get('slug', '?'))}" for item in items)


@mcp.tool()
def get_cable(slug: str) -> str:
    """Get detailed information about a specific cable.

    Args:
        slug: URL slug identifier for the cable.
    """
    from cablefyi.api import CableFYI

    with CableFYI() as api:
        data = api.get_cable(slug)
        return str(data)


@mcp.tool()
def list_connectors(limit: int = 20, offset: int = 0) -> str:
    """List connectors from cablefyi.com.

    Args:
        limit: Maximum number of results. Default 20.
        offset: Number of results to skip. Default 0.
    """
    from cablefyi.api import CableFYI

    with CableFYI() as api:
        data = api.list_connectors(limit=limit, offset=offset)
        results = data.get("results", data) if isinstance(data, dict) else data
        if not results:
            return "No connectors found."
        items = results[:limit] if isinstance(results, list) else []
        return "\n".join(f"- {item.get('name', item.get('slug', '?'))}" for item in items)


@mcp.tool()
def search_cable(query: str) -> str:
    """Search cablefyi.com for cables, connectors, and compatibility.

    Args:
        query: Search query string.
    """
    from cablefyi.api import CableFYI

    with CableFYI() as api:
        data = api.search(query)
        results = data.get("results", data) if isinstance(data, dict) else data
        if not results:
            return f"No results found for \"{query}\"."
        items = results[:10] if isinstance(results, list) else []
        return "\n".join(f"- {item.get('name', item.get('slug', '?'))}" for item in items)


def main() -> None:
    """Run the MCP server."""
    mcp.run()


if __name__ == "__main__":
    main()
