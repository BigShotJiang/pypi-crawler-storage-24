"""Command-line interface for cablefyi."""

from __future__ import annotations

import json

import typer

from cablefyi.api import CableFYI

app = typer.Typer(help="CableFYI — Submarine cables and landing points API client.")


@app.command()
def search(query: str) -> None:
    """Search cablefyi.com."""
    with CableFYI() as api:
        result = api.search(query)
        typer.echo(json.dumps(result, indent=2))
