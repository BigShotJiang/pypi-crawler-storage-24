"""HTTP API client for cablefyi.com REST endpoints.

Requires the ``api`` extra: ``pip install cablefyi[api]``

Usage::

    from cablefyi.api import CableFYI

    with CableFYI() as api:
        items = api.list_benchmarks()
        detail = api.get_benchmark("example-slug")
        results = api.search("query")
"""

from __future__ import annotations

from typing import Any

import httpx


class CableFYI:
    """API client for the cablefyi.com REST API.

    Provides typed access to all cablefyi.com endpoints including
    list, detail, and search operations.

    Args:
        base_url: API base URL. Defaults to ``https://cablefyi.com``.
        timeout: Request timeout in seconds. Defaults to ``10.0``.
    """

    def __init__(
        self,
        base_url: str = "https://cablefyi.com",
        timeout: float = 10.0,
    ) -> None:
        self._client = httpx.Client(base_url=base_url, timeout=timeout)

    def _get(self, path: str, **params: Any) -> dict[str, Any]:
        resp = self._client.get(
            path,
            params={k: v for k, v in params.items() if v is not None},
        )
        resp.raise_for_status()
        result: dict[str, Any] = resp.json()
        return result

    # -- Endpoints -----------------------------------------------------------

    def list_benchmarks(self, **params: Any) -> dict[str, Any]:
        """List all benchmarks."""
        return self._get("/api/v1/benchmarks/", **params)

    def get_benchmark(self, slug: str) -> dict[str, Any]:
        """Get benchmark by slug."""
        return self._get(f"/api/v1/benchmarks/" + slug + "/")

    def list_cables(self, **params: Any) -> dict[str, Any]:
        """List all cables."""
        return self._get("/api/v1/cables/", **params)

    def get_cable(self, slug: str) -> dict[str, Any]:
        """Get cable by slug."""
        return self._get(f"/api/v1/cables/" + slug + "/")

    def list_compatibility(self, **params: Any) -> dict[str, Any]:
        """List all compatibility."""
        return self._get("/api/v1/compatibility/", **params)

    def get_compatibility(self, slug: str) -> dict[str, Any]:
        """Get compatibility by slug."""
        return self._get(f"/api/v1/compatibility/" + slug + "/")

    def list_connectors(self, **params: Any) -> dict[str, Any]:
        """List all connectors."""
        return self._get("/api/v1/connectors/", **params)

    def get_connector(self, slug: str) -> dict[str, Any]:
        """Get connector by slug."""
        return self._get(f"/api/v1/connectors/" + slug + "/")

    def list_devices(self, **params: Any) -> dict[str, Any]:
        """List all devices."""
        return self._get("/api/v1/devices/", **params)

    def get_device(self, slug: str) -> dict[str, Any]:
        """Get device by slug."""
        return self._get(f"/api/v1/devices/" + slug + "/")

    def list_faqs(self, **params: Any) -> dict[str, Any]:
        """List all faqs."""
        return self._get("/api/v1/faqs/", **params)

    def get_faq(self, slug: str) -> dict[str, Any]:
        """Get faq by slug."""
        return self._get(f"/api/v1/faqs/" + slug + "/")

    def list_guide_series(self, **params: Any) -> dict[str, Any]:
        """List all guide series."""
        return self._get("/api/v1/guide-series/", **params)

    def get_guide_sery(self, slug: str) -> dict[str, Any]:
        """Get guide sery by slug."""
        return self._get(f"/api/v1/guide-series/" + slug + "/")

    def list_guides(self, **params: Any) -> dict[str, Any]:
        """List all guides."""
        return self._get("/api/v1/guides/", **params)

    def get_guide(self, slug: str) -> dict[str, Any]:
        """Get guide by slug."""
        return self._get(f"/api/v1/guides/" + slug + "/")

    def list_setup_guides(self, **params: Any) -> dict[str, Any]:
        """List all setup guides."""
        return self._get("/api/v1/setup-guides/", **params)

    def get_setup_guide(self, slug: str) -> dict[str, Any]:
        """Get setup guide by slug."""
        return self._get(f"/api/v1/setup-guides/" + slug + "/")

    def list_standards(self, **params: Any) -> dict[str, Any]:
        """List all standards."""
        return self._get("/api/v1/standards/", **params)

    def get_standard(self, slug: str) -> dict[str, Any]:
        """Get standard by slug."""
        return self._get(f"/api/v1/standards/" + slug + "/")

    def list_terms(self, **params: Any) -> dict[str, Any]:
        """List all terms."""
        return self._get("/api/v1/terms/", **params)

    def get_term(self, slug: str) -> dict[str, Any]:
        """Get term by slug."""
        return self._get(f"/api/v1/terms/" + slug + "/")

    def search(self, query: str, **params: Any) -> dict[str, Any]:
        """Search across all content."""
        return self._get(f"/api/v1/search/", q=query, **params)

    # -- Lifecycle -----------------------------------------------------------

    def close(self) -> None:
        """Close the underlying HTTP client."""
        self._client.close()

    def __enter__(self) -> CableFYI:
        return self

    def __exit__(self, *_: object) -> None:
        self.close()
