"""Graph primitives."""

