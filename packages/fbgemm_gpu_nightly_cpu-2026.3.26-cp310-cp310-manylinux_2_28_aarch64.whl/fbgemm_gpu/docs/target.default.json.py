
{
    "version": "2026.3.26",
    "target": "default",
    "variant": "cpu"
}
