#  PyroRatnaGram - Telegram MTProto API Client Library for Python
#  Copyright (C) 2017-present Dan <https://github.com/delivrance>
#  Copyright (C) 2022-present AnmolRatna25 <https://github.com/AnmolRatna25>
#
#  This file is part of PyroRatnaGram.
#
#  PyroRatnaGram is free software: you can redistribute it and/or modify
#  it under the terms of the GNU Lesser General Public License as published
#  by the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.
#
#  PyroRatnaGram is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU Lesser General Public License for more details.
#
#  You should have received a copy of the GNU Lesser General Public License
#  along with PyroRatnaGram.  If not, see <http://www.gnu.org/licenses/>.

from .file_storage import FileStorage
from .memory_storage import MemoryStorage
MONGO_AVAIL = False
try:
    import pymongo
except Exception:
    pass
else:
    MONGO_AVAIL = True
    from .mongo_storage import MongoStorage
from .storage import Storage

__all__ = [
    "FileStorage",
    "MemoryStorage",
    "Storage"
]
if MONGO_AVAIL:
    __all__.append("MongoStorage")
