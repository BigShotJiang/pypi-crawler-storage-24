"""Tests for release_pilot.git_ops."""

from __future__ import annotations

import os
import subprocess

from release_pilot.git_ops import (
    _run_git,
    create_tag,
    determine_bump_type,
    get_commit_count,
    get_commits_since_tag,
    get_current_branch,
    get_latest_tag,
    get_latest_version,
    get_repo_root,
    get_tags,
    is_git_repo,
    is_working_tree_clean,
    run_preflight_checks,
)
from release_pilot.models import BumpType, CommitType, ConventionalCommit, SemanticVersion

# ── _run_git ────────────────────────────────────────────────────────


class TestRunGit:
    def test_success(self, git_repo):
        ok, output = _run_git(["status"], git_repo)
        assert ok is True

    def test_failure(self, temp_dir):
        ok, output = _run_git(["log"], temp_dir)
        # log in non-repo should fail
        assert ok is False

    def test_invalid_command(self, git_repo):
        ok, output = _run_git(["nonexistent-command"], git_repo)
        assert ok is False


# ── is_git_repo ─────────────────────────────────────────────────────


class TestIsGitRepo:
    def test_in_repo(self, git_repo):
        assert is_git_repo(git_repo) is True

    def test_not_in_repo(self, temp_dir):
        not_repo = os.path.join(temp_dir, "not_a_repo")
        os.makedirs(not_repo)
        assert is_git_repo(not_repo) is False


# ── get_repo_root ───────────────────────────────────────────────────


class TestGetRepoRoot:
    def test_returns_root(self, git_repo):
        root = get_repo_root(git_repo)
        assert root is not None
        assert os.path.isdir(root)

    def test_returns_none_for_non_repo(self, temp_dir):
        not_repo = os.path.join(temp_dir, "not_a_repo")
        os.makedirs(not_repo)
        assert get_repo_root(not_repo) is None


# ── get_current_branch ──────────────────────────────────────────────


class TestGetCurrentBranch:
    def test_returns_branch(self, git_repo):
        branch = get_current_branch(git_repo)
        assert branch is not None
        assert isinstance(branch, str)
        assert len(branch) > 0


# ── is_working_tree_clean ───────────────────────────────────────────


class TestIsWorkingTreeClean:
    def test_clean_repo(self, git_repo):
        assert is_working_tree_clean(git_repo) is True

    def test_dirty_repo(self, git_repo):
        # Add an untracked file
        with open(os.path.join(git_repo, "new_file.txt"), "w") as f:
            f.write("dirty")
        assert is_working_tree_clean(git_repo) is False


# ── get_tags ────────────────────────────────────────────────────────


class TestGetTags:
    def test_returns_tags(self, git_repo):
        tags = get_tags(git_repo)
        assert "v0.1.0" in tags

    def test_no_tags(self, temp_dir):
        _init_repo(temp_dir)
        tags = get_tags(temp_dir)
        assert tags == []


# ── get_latest_tag ──────────────────────────────────────────────────


class TestGetLatestTag:
    def test_returns_latest(self, git_repo):
        tag = get_latest_tag(git_repo)
        assert tag == "v0.1.0"

    def test_no_tags_returns_none(self, temp_dir):
        _init_repo(temp_dir)
        assert get_latest_tag(temp_dir) is None


# ── get_latest_version ──────────────────────────────────────────────


class TestGetLatestVersion:
    def test_returns_version(self, git_repo):
        v = get_latest_version(git_repo)
        assert v == SemanticVersion(0, 1, 0)

    def test_no_tags_returns_zero(self, temp_dir):
        _init_repo(temp_dir)
        v = get_latest_version(temp_dir)
        assert v == SemanticVersion(0, 0, 0)


# ── get_commits_since_tag ───────────────────────────────────────────


class TestGetCommitsSinceTag:
    def test_returns_commits(self, git_repo):
        commits = get_commits_since_tag("v0.1.0", git_repo)
        assert len(commits) >= 2  # feat(core) + fix(utils) + docs
        types = {c.type for c in commits}
        assert CommitType.FEAT in types
        assert CommitType.FIX in types

    def test_no_tag_returns_all(self, git_repo):
        commits = get_commits_since_tag(None, git_repo)
        assert len(commits) >= 3

    def test_empty_returns_empty(self, git_repo_empty):
        commits = get_commits_since_tag("v1.0.0", git_repo_empty)
        assert commits == []


# ── determine_bump_type ─────────────────────────────────────────────


class TestDetermineBumpType:
    def test_breaking_is_major(self):
        commits = [
            ConventionalCommit("a", "a", CommitType.FEAT, None, "x", "", True, "", "", ""),
        ]
        assert determine_bump_type(commits) == BumpType.MAJOR

    def test_feat_is_minor(self):
        commits = [
            ConventionalCommit("a", "a", CommitType.FEAT, None, "x", "", False, "", "", ""),
        ]
        assert determine_bump_type(commits) == BumpType.MINOR

    def test_fix_is_patch(self):
        commits = [
            ConventionalCommit("a", "a", CommitType.FIX, None, "x", "", False, "", "", ""),
        ]
        assert determine_bump_type(commits) == BumpType.PATCH

    def test_chore_is_patch(self):
        commits = [
            ConventionalCommit("a", "a", CommitType.CHORE, None, "x", "", False, "", "", ""),
        ]
        assert determine_bump_type(commits) == BumpType.PATCH

    def test_empty_is_none(self):
        assert determine_bump_type([]) == BumpType.NONE

    def test_mixed_highest_wins(self):
        commits = [
            ConventionalCommit("a", "a", CommitType.FIX, None, "x", "", False, "", "", ""),
            ConventionalCommit("b", "b", CommitType.FEAT, None, "y", "", False, "", "", ""),
        ]
        assert determine_bump_type(commits) == BumpType.MINOR


# ── create_tag ──────────────────────────────────────────────────────


class TestCreateTag:
    def test_creates_tag(self, git_repo):
        ok, _ = create_tag("v0.2.0", "Release v0.2.0", git_repo)
        assert ok is True
        tags = get_tags(git_repo)
        assert "v0.2.0" in tags

    def test_duplicate_tag_fails(self, git_repo):
        ok, _ = create_tag("v0.1.0", "Duplicate", git_repo)
        assert ok is False


# ── get_commit_count ────────────────────────────────────────────────


class TestGetCommitCount:
    def test_count_since_tag(self, git_repo):
        count = get_commit_count("v0.1.0", git_repo)
        assert count >= 3  # feat(core) + fix(utils) + docs

    def test_total_count(self, git_repo):
        count = get_commit_count(None, git_repo)
        assert count >= 4  # initial + 3 after tag


# ── run_preflight_checks ───────────────────────────────────────────


class TestRunPreflightChecks:
    def test_clean_repo_passes(self, git_repo):
        checklist = run_preflight_checks(cwd=git_repo)
        git_check = next(c for c in checklist.checks if c.name == "Git Repository")
        assert git_check.passed is True

    def test_dirty_repo_fails_clean(self, git_repo):
        with open(os.path.join(git_repo, "dirty.txt"), "w") as f:
            f.write("dirty")
        checklist = run_preflight_checks(require_clean=True, cwd=git_repo)
        clean_check = next(c for c in checklist.checks if c.name == "Clean Working Tree")
        assert clean_check.passed is False

    def test_branch_check(self, git_repo):
        branch = get_current_branch(git_repo)
        checklist = run_preflight_checks(required_branch=branch, cwd=git_repo)
        branch_check = next(c for c in checklist.checks if c.name == "Branch")
        assert branch_check.passed is True

    def test_wrong_branch_fails(self, git_repo):
        checklist = run_preflight_checks(required_branch="nonexistent", cwd=git_repo)
        branch_check = next(c for c in checklist.checks if c.name == "Branch")
        assert branch_check.passed is False

    def test_checks_commits_exist(self, git_repo):
        checklist = run_preflight_checks(require_clean=False, cwd=git_repo)
        commit_check = next(c for c in checklist.checks if c.name == "New Commits")
        assert commit_check.passed is True

    def test_not_git_repo(self, temp_dir):
        not_repo = os.path.join(temp_dir, "nope")
        os.makedirs(not_repo)
        checklist = run_preflight_checks(cwd=not_repo)
        assert checklist.all_passed is False


def _init_repo(cwd):
    """Create a minimal git repo with one commit."""
    subprocess.run(["git", "init"], cwd=cwd, capture_output=True, check=True)
    subprocess.run(["git", "config", "user.email", "t@t.com"], cwd=cwd, capture_output=True, check=True)
    subprocess.run(["git", "config", "user.name", "T"], cwd=cwd, capture_output=True, check=True)
    f = os.path.join(cwd, "init.txt")
    with open(f, "w") as fh:
        fh.write("init")
    subprocess.run(["git", "add", "."], cwd=cwd, capture_output=True, check=True)
    subprocess.run(["git", "commit", "-m", "init"], cwd=cwd, capture_output=True, check=True)
