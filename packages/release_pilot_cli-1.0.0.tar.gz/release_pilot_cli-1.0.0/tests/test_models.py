"""Tests for release_pilot.models."""

from __future__ import annotations

from release_pilot.models import (
    BREAKING_CHANGE_PATTERN,
    CONVENTIONAL_COMMIT_PATTERN,
    BumpType,
    CommitType,
    ReleaseCheck,
    ReleaseChecklist,
    ReleaseInfo,
    ReleaseReport,
    SemanticVersion,
    VersionFileUpdate,
    parse_commit_message,
)

# ── CommitType ──────────────────────────────────────────────────────


class TestCommitType:
    def test_values(self):
        assert CommitType.FEAT.value == "feat"
        assert CommitType.FIX.value == "fix"
        assert CommitType.DOCS.value == "docs"
        assert CommitType.PERF.value == "perf"
        assert CommitType.CHORE.value == "chore"

    def test_label(self):
        assert CommitType.FEAT.label == "Features"
        assert CommitType.FIX.label == "Bug Fixes"
        assert CommitType.BREAKING.label == "BREAKING CHANGES"
        assert CommitType.PERF.label == "Performance Improvements"

    def test_changelog_priority(self):
        assert CommitType.BREAKING.changelog_priority < CommitType.FEAT.changelog_priority
        assert CommitType.FEAT.changelog_priority < CommitType.FIX.changelog_priority
        assert CommitType.FIX.changelog_priority < CommitType.CHORE.changelog_priority

    def test_all_types_have_labels(self):
        for ct in CommitType:
            assert isinstance(ct.label, str)
            assert len(ct.label) > 0

    def test_all_types_have_priority(self):
        for ct in CommitType:
            assert isinstance(ct.changelog_priority, int)


# ── BumpType ────────────────────────────────────────────────────────


class TestBumpType:
    def test_values(self):
        assert BumpType.MAJOR.value == "major"
        assert BumpType.MINOR.value == "minor"
        assert BumpType.PATCH.value == "patch"
        assert BumpType.NONE.value == "none"


# ── SemanticVersion ─────────────────────────────────────────────────


class TestSemanticVersion:
    def test_parse_simple(self):
        v = SemanticVersion.parse("1.2.3")
        assert v.major == 1
        assert v.minor == 2
        assert v.patch == 3
        assert v.prerelease is None

    def test_parse_with_v_prefix(self):
        v = SemanticVersion.parse("v2.0.1")
        assert v.major == 2
        assert v.minor == 0
        assert v.patch == 1

    def test_parse_with_prerelease(self):
        v = SemanticVersion.parse("1.0.0-beta.1")
        assert v.major == 1
        assert v.prerelease == "beta.1"

    def test_parse_empty(self):
        v = SemanticVersion.parse("")
        assert v == SemanticVersion(0, 0, 0)

    def test_parse_partial(self):
        v = SemanticVersion.parse("3")
        assert v.major == 3
        assert v.minor == 0
        assert v.patch == 0

    def test_parse_two_parts(self):
        v = SemanticVersion.parse("1.5")
        assert v.major == 1
        assert v.minor == 5
        assert v.patch == 0

    def test_parse_invalid(self):
        v = SemanticVersion.parse("abc")
        assert v == SemanticVersion(0, 0, 0)

    def test_str(self):
        assert str(SemanticVersion(1, 2, 3)) == "1.2.3"

    def test_str_with_prerelease(self):
        assert str(SemanticVersion(1, 0, 0, "rc.1")) == "1.0.0-rc.1"

    def test_tag(self):
        assert SemanticVersion(1, 2, 3).tag == "v1.2.3"

    def test_bump_major(self):
        v = SemanticVersion(1, 2, 3).bump(BumpType.MAJOR)
        assert v == SemanticVersion(2, 0, 0)

    def test_bump_minor(self):
        v = SemanticVersion(1, 2, 3).bump(BumpType.MINOR)
        assert v == SemanticVersion(1, 3, 0)

    def test_bump_patch(self):
        v = SemanticVersion(1, 2, 3).bump(BumpType.PATCH)
        assert v == SemanticVersion(1, 2, 4)

    def test_bump_none(self):
        v = SemanticVersion(1, 2, 3).bump(BumpType.NONE)
        assert v == SemanticVersion(1, 2, 3)

    def test_equality(self):
        assert SemanticVersion(1, 0, 0) == SemanticVersion(1, 0, 0)
        assert SemanticVersion(1, 0, 0) != SemanticVersion(2, 0, 0)

    def test_comparison_lt(self):
        assert SemanticVersion(1, 0, 0) < SemanticVersion(2, 0, 0)
        assert SemanticVersion(1, 0, 0) < SemanticVersion(1, 1, 0)
        assert SemanticVersion(1, 0, 0) < SemanticVersion(1, 0, 1)

    def test_comparison_prerelease(self):
        # Pre-release versions are less than release
        assert SemanticVersion(1, 0, 0, "alpha") < SemanticVersion(1, 0, 0)
        assert not SemanticVersion(1, 0, 0) < SemanticVersion(1, 0, 0, "alpha")

    def test_comparison_gt(self):
        assert SemanticVersion(2, 0, 0) > SemanticVersion(1, 0, 0)

    def test_comparison_ge_le(self):
        assert SemanticVersion(1, 0, 0) >= SemanticVersion(1, 0, 0)
        assert SemanticVersion(1, 0, 0) <= SemanticVersion(1, 0, 0)
        assert SemanticVersion(2, 0, 0) >= SemanticVersion(1, 0, 0)

    def test_eq_not_implemented(self):
        assert SemanticVersion(1, 0, 0).__eq__("not a version") == NotImplemented


# ── parse_commit_message ────────────────────────────────────────────


class TestParseCommitMessage:
    def test_simple_feat(self):
        c = parse_commit_message("abc", "abc", "feat: add login")
        assert c is not None
        assert c.type == CommitType.FEAT
        assert c.description == "add login"
        assert c.scope is None
        assert c.breaking is False

    def test_feat_with_scope(self):
        c = parse_commit_message("abc", "abc", "feat(auth): add OAuth")
        assert c.type == CommitType.FEAT
        assert c.scope == "auth"
        assert c.description == "add OAuth"

    def test_fix(self):
        c = parse_commit_message("abc", "abc", "fix: handle null pointer")
        assert c.type == CommitType.FIX

    def test_breaking_with_bang(self):
        c = parse_commit_message("abc", "abc", "feat!: remove deprecated API")
        assert c.breaking is True
        assert c.type == CommitType.FEAT

    def test_breaking_in_body(self):
        msg = "feat: new config format\n\nBREAKING CHANGE: old format no longer supported"
        c = parse_commit_message("abc", "abc", msg)
        assert c.breaking is True

    def test_breaking_change_dash(self):
        msg = "feat: new config\n\nBREAKING-CHANGE: old config removed"
        c = parse_commit_message("abc", "abc", msg)
        assert c.breaking is True

    def test_non_conventional(self):
        c = parse_commit_message("abc", "abc", "updated readme")
        assert c is None

    def test_all_types(self):
        for ct in CommitType:
            if ct == CommitType.BREAKING:
                continue
            msg = f"{ct.value}: test description"
            c = parse_commit_message("abc", "abc", msg)
            assert c is not None, f"Failed for {ct.value}"
            assert c.type == ct

    def test_multiline_body(self):
        msg = "feat(core): add feature\n\nThis is the body.\nMultiple lines."
        c = parse_commit_message("abc", "abc", msg)
        assert c.body == "This is the body.\nMultiple lines."

    def test_author_and_date(self):
        c = parse_commit_message("abc", "abc", "fix: bug", author="Dev", date="2025-01-01")
        assert c.author == "Dev"
        assert c.date == "2025-01-01"

    def test_case_insensitive(self):
        c = parse_commit_message("abc", "abc", "FEAT: uppercase type")
        assert c is not None
        assert c.type == CommitType.FEAT


# ── ConventionalCommit ──────────────────────────────────────────────


class TestConventionalCommit:
    def test_display_scope_with_scope(self):
        c = parse_commit_message("abc", "abc", "feat(auth): add login")
        assert c.display_scope == "**auth**: "

    def test_display_scope_without(self):
        c = parse_commit_message("abc", "abc", "feat: add login")
        assert c.display_scope == ""

    def test_changelog_entry(self):
        c = parse_commit_message("abc", "abc", "feat(auth): add login")
        entry = c.changelog_entry
        assert "**auth:**" in entry
        assert "add login" in entry
        assert "(abc)" in entry

    def test_changelog_entry_breaking(self):
        c = parse_commit_message("abc", "abc", "feat!: break things")
        assert "**BREAKING**" in c.changelog_entry


# ── Regex Patterns ──────────────────────────────────────────────────


class TestPatterns:
    def test_conventional_pattern_matches(self):
        assert CONVENTIONAL_COMMIT_PATTERN.match("feat: hello")
        assert CONVENTIONAL_COMMIT_PATTERN.match("fix(scope): hello")
        assert CONVENTIONAL_COMMIT_PATTERN.match("feat!: breaking")

    def test_conventional_pattern_no_match(self):
        assert CONVENTIONAL_COMMIT_PATTERN.match("random message") is None
        assert CONVENTIONAL_COMMIT_PATTERN.match("updated code") is None

    def test_breaking_change_pattern(self):
        assert BREAKING_CHANGE_PATTERN.search("BREAKING CHANGE: removed API")
        assert BREAKING_CHANGE_PATTERN.search("BREAKING-CHANGE: removed API")
        assert BREAKING_CHANGE_PATTERN.search("nothing here") is None


# ── ReleaseInfo ─────────────────────────────────────────────────────


class TestReleaseInfo:
    def test_properties(self, sample_commits):
        info = ReleaseInfo(
            version=SemanticVersion(1, 1, 0),
            previous_version=SemanticVersion(1, 0, 0),
            bump_type=BumpType.MINOR,
            commits=sample_commits,
            changelog="",
            tag="v1.1.0",
            date="2025-01-20",
        )
        assert info.total_commits == 5
        assert info.features_count == 2
        assert info.fixes_count == 1
        assert info.has_breaking_changes is False

    def test_breaking_flag(self, sample_breaking_commits):
        info = ReleaseInfo(
            version=SemanticVersion(2, 0, 0),
            previous_version=SemanticVersion(1, 0, 0),
            bump_type=BumpType.MAJOR,
            commits=sample_breaking_commits,
            changelog="",
            tag="v2.0.0",
            date="2025-01-20",
        )
        assert info.has_breaking_changes is True
        assert info.total_commits == 6


# ── ReleaseCheck / Checklist ────────────────────────────────────────


class TestReleaseCheck:
    def test_passed_icon(self):
        check = ReleaseCheck(name="Test", passed=True, message="OK")
        assert check.status_icon == "✓"

    def test_failed_required_icon(self):
        check = ReleaseCheck(name="Test", passed=False, message="Fail", required=True)
        assert check.status_icon == "✗"

    def test_failed_optional_icon(self):
        check = ReleaseCheck(name="Test", passed=False, message="Warn", required=False)
        assert check.status_icon == "⚠"


class TestReleaseChecklist:
    def test_all_passed(self):
        checks = [
            ReleaseCheck("A", True, "ok"),
            ReleaseCheck("B", True, "ok"),
        ]
        cl = ReleaseChecklist(checks=checks)
        assert cl.all_passed is True
        assert cl.total == 2
        assert cl.passed_count == 2

    def test_required_failure(self):
        checks = [
            ReleaseCheck("A", True, "ok"),
            ReleaseCheck("B", False, "fail", required=True),
        ]
        cl = ReleaseChecklist(checks=checks)
        assert cl.all_passed is False
        assert len(cl.failed_required) == 1

    def test_optional_failure(self):
        checks = [
            ReleaseCheck("A", True, "ok"),
            ReleaseCheck("B", False, "warn", required=False),
        ]
        cl = ReleaseChecklist(checks=checks)
        assert cl.all_passed is True
        assert len(cl.warnings) == 1

    def test_empty_checklist(self):
        cl = ReleaseChecklist()
        assert cl.all_passed is True
        assert cl.total == 0


# ── VersionFileUpdate ───────────────────────────────────────────────


class TestVersionFileUpdate:
    def test_defaults(self):
        u = VersionFileUpdate("pyproject.toml", "1.0.0", "1.1.0", "pattern")
        assert u.updated is False
        assert u.error is None


# ── ReleaseReport ───────────────────────────────────────────────────


class TestReleaseReport:
    def test_success_dry_run(self, sample_release):
        report = ReleaseReport(
            release=sample_release,
            checks=ReleaseChecklist(checks=[ReleaseCheck("A", True, "ok")]),
            file_updates=[],
            tag_created=False,
            pushed=False,
            dry_run=True,
        )
        assert report.success is True

    def test_success_real(self, sample_release):
        report = ReleaseReport(
            release=sample_release,
            checks=ReleaseChecklist(checks=[ReleaseCheck("A", True, "ok")]),
            file_updates=[],
            tag_created=True,
            pushed=False,
            dry_run=False,
        )
        assert report.success is True

    def test_failure_no_tag(self, sample_release):
        report = ReleaseReport(
            release=sample_release,
            checks=ReleaseChecklist(checks=[ReleaseCheck("A", True, "ok")]),
            file_updates=[],
            tag_created=False,
            pushed=False,
            dry_run=False,
        )
        assert report.success is False
