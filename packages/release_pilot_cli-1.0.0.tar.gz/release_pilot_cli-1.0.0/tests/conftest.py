"""Shared fixtures for release-pilot tests."""

from __future__ import annotations

import os
import subprocess
import tempfile

import pytest

from release_pilot.models import (
    BumpType,
    CommitType,
    ConventionalCommit,
    ReleaseInfo,
    SemanticVersion,
)


@pytest.fixture
def temp_dir():
    """Create a temporary directory."""
    with tempfile.TemporaryDirectory() as tmpdir:
        yield tmpdir


@pytest.fixture
def git_repo(temp_dir):
    """Create a temporary git repository with some conventional commits."""
    cwd = temp_dir
    _git(["init"], cwd)
    _git(["config", "user.email", "test@test.com"], cwd)
    _git(["config", "user.name", "Test User"], cwd)

    # Initial commit
    _write_file(cwd, "README.md", "# Test Project")
    _git(["add", "."], cwd)
    _git(["commit", "-m", "feat: initial project setup"], cwd)

    # Tag v0.1.0
    _git(["tag", "-a", "v0.1.0", "-m", "Release v0.1.0"], cwd)

    # Add more commits after the tag
    _write_file(cwd, "src/main.py", "print('hello')")
    _git(["add", "."], cwd)
    _git(["commit", "-m", "feat(core): add main module"], cwd)

    _write_file(cwd, "src/utils.py", "def helper(): pass")
    _git(["add", "."], cwd)
    _git(["commit", "-m", "fix(utils): handle edge case"], cwd)

    _write_file(cwd, "docs/guide.md", "# Guide")
    _git(["add", "."], cwd)
    _git(["commit", "-m", "docs: add user guide"], cwd)

    yield cwd


@pytest.fixture
def git_repo_breaking(git_repo):
    """Git repo with a breaking change commit."""
    _write_file(git_repo, "src/api.py", "def new_api(): pass")
    _git(["add", "."], git_repo)
    _git(["commit", "-m", "feat!: redesign public API\n\nBREAKING CHANGE: removed old endpoints"], git_repo)
    yield git_repo


@pytest.fixture
def git_repo_empty(temp_dir):
    """Create a git repo with no conventional commits after tag."""
    cwd = temp_dir
    _git(["init"], cwd)
    _git(["config", "user.email", "test@test.com"], cwd)
    _git(["config", "user.name", "Test User"], cwd)

    _write_file(cwd, "README.md", "# Test")
    _git(["add", "."], cwd)
    _git(["commit", "-m", "initial commit (not conventional)"], cwd)
    _git(["tag", "-a", "v1.0.0", "-m", "Release v1.0.0"], cwd)

    yield cwd


@pytest.fixture
def sample_commits():
    """Create a list of sample ConventionalCommit objects."""
    return [
        ConventionalCommit(
            hash="abc123def456", short_hash="abc123d",
            type=CommitType.FEAT, scope="auth",
            description="add OAuth2 support", body="",
            breaking=False, raw_message="feat(auth): add OAuth2 support",
            author="Dev A", date="2025-01-15",
        ),
        ConventionalCommit(
            hash="def456ghi789", short_hash="def456g",
            type=CommitType.FIX, scope="parser",
            description="handle empty input", body="",
            breaking=False, raw_message="fix(parser): handle empty input",
            author="Dev B", date="2025-01-16",
        ),
        ConventionalCommit(
            hash="ghi789jkl012", short_hash="ghi789j",
            type=CommitType.FEAT, scope=None,
            description="add CLI dashboard", body="",
            breaking=False, raw_message="feat: add CLI dashboard",
            author="Dev A", date="2025-01-17",
        ),
        ConventionalCommit(
            hash="jkl012mno345", short_hash="jkl012m",
            type=CommitType.DOCS, scope=None,
            description="update installation guide", body="",
            breaking=False, raw_message="docs: update installation guide",
            author="Dev C", date="2025-01-18",
        ),
        ConventionalCommit(
            hash="mno345pqr678", short_hash="mno345p",
            type=CommitType.PERF, scope="db",
            description="optimize query performance", body="",
            breaking=False, raw_message="perf(db): optimize query performance",
            author="Dev B", date="2025-01-19",
        ),
    ]


@pytest.fixture
def sample_breaking_commits(sample_commits):
    """Sample commits including a breaking change."""
    breaking = ConventionalCommit(
        hash="pqr678stu901", short_hash="pqr678s",
        type=CommitType.FEAT, scope="api",
        description="redesign REST endpoints", body="BREAKING CHANGE: removed v1 endpoints",
        breaking=True, raw_message="feat(api)!: redesign REST endpoints",
        author="Dev A", date="2025-01-20",
    )
    return [breaking] + sample_commits


@pytest.fixture
def sample_release(sample_commits):
    """Create a sample ReleaseInfo."""
    return ReleaseInfo(
        version=SemanticVersion(1, 1, 0),
        previous_version=SemanticVersion(1, 0, 0),
        bump_type=BumpType.MINOR,
        commits=sample_commits,
        changelog="## [1.1.0] - 2025-01-20\n\n### Features\n\n- **auth:** add OAuth2 support (abc123d)\n",
        tag="v1.1.0",
        date="2025-01-20",
    )


def _git(args, cwd):
    """Helper to run git commands."""
    subprocess.run(
        ["git"] + args,
        cwd=cwd,
        capture_output=True,
        text=True,
        check=True,
    )


def _write_file(root, path, content):
    """Helper to write a file, creating dirs as needed."""
    full = os.path.join(root, path)
    os.makedirs(os.path.dirname(full), exist_ok=True)
    with open(full, "w") as f:
        f.write(content)
