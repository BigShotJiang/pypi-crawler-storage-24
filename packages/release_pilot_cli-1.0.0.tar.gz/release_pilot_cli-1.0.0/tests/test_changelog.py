"""Tests for release_pilot.changelog."""

from __future__ import annotations

import os

from release_pilot.changelog import (
    _find_changelog_insert_point,
    generate_changelog_section,
    generate_full_changelog,
    generate_release_notes,
    read_existing_changelog,
    summarize_commits,
    write_changelog,
)
from release_pilot.models import SemanticVersion

# ── generate_changelog_section ──────────────────────────────────────


class TestGenerateChangelogSection:
    def test_basic_section(self, sample_commits):
        v = SemanticVersion(1, 1, 0)
        section = generate_changelog_section(v, sample_commits, date="2025-01-20")
        assert "## [1.1.0] - 2025-01-20" in section
        assert "### Features" in section
        assert "### Bug Fixes" in section
        assert "add OAuth2 support" in section
        assert "handle empty input" in section

    def test_includes_hash(self, sample_commits):
        section = generate_changelog_section(SemanticVersion(1, 0, 0), sample_commits)
        assert "(abc123d)" in section
        assert "(def456g)" in section

    def test_includes_scope(self, sample_commits):
        section = generate_changelog_section(SemanticVersion(1, 0, 0), sample_commits)
        assert "**auth:**" in section
        assert "**parser:**" in section

    def test_breaking_changes_section(self, sample_breaking_commits):
        section = generate_changelog_section(SemanticVersion(2, 0, 0), sample_breaking_commits)
        assert "### ⚠ BREAKING CHANGES" in section
        assert "redesign REST endpoints" in section

    def test_no_header(self, sample_commits):
        section = generate_changelog_section(
            SemanticVersion(1, 0, 0), sample_commits, include_header=False
        )
        assert "## [" not in section
        assert "### Features" in section

    def test_empty_commits(self):
        section = generate_changelog_section(SemanticVersion(1, 0, 0), [])
        assert "## [1.0.0]" in section

    def test_performance_section(self, sample_commits):
        section = generate_changelog_section(SemanticVersion(1, 0, 0), sample_commits)
        assert "### Performance Improvements" in section

    def test_docs_section(self, sample_commits):
        section = generate_changelog_section(SemanticVersion(1, 0, 0), sample_commits)
        assert "### Documentation" in section


# ── generate_full_changelog ─────────────────────────────────────────


class TestGenerateFullChangelog:
    def test_new_changelog(self, sample_commits):
        full = generate_full_changelog(
            SemanticVersion(1, 0, 0), sample_commits, project_name="MyProject"
        )
        assert "# Changelog" in full
        assert "MyProject" in full
        assert "## [1.0.0]" in full
        assert "Semantic Versioning" in full

    def test_prepend_to_existing(self, sample_commits):
        existing = "# Changelog\n\n## [0.1.0] - 2024-01-01\n\n### Features\n\n- initial release\n"
        full = generate_full_changelog(
            SemanticVersion(1, 0, 0), sample_commits, existing_changelog=existing
        )
        assert "## [1.0.0]" in full
        assert "## [0.1.0]" in full
        # New version should come before old
        idx_new = full.index("[1.0.0]")
        idx_old = full.index("[0.1.0]")
        assert idx_new < idx_old

    def test_no_existing_no_project_name(self, sample_commits):
        full = generate_full_changelog(SemanticVersion(1, 0, 0), sample_commits)
        assert "# Changelog" in full


# ── _find_changelog_insert_point ────────────────────────────────────


class TestFindInsertPoint:
    def test_finds_first_version_header(self):
        content = "# Changelog\n\nSome intro text\n\n## [1.0.0] - 2024-01-01\n\n### Features\n"
        pos = _find_changelog_insert_point(content)
        assert pos > 0
        assert content[pos:].startswith("## [1.0.0]")

    def test_no_version_header(self):
        content = "# Changelog\n\nJust some text\n"
        pos = _find_changelog_insert_point(content)
        assert pos == -1


# ── generate_release_notes ──────────────────────────────────────────


class TestGenerateReleaseNotes:
    def test_basic_notes(self, sample_commits):
        notes = generate_release_notes(
            SemanticVersion(1, 1, 0), sample_commits,
            previous_version=SemanticVersion(1, 0, 0),
        )
        assert "Release 1.1.0" in notes
        assert "Changes since 1.0.0" in notes
        assert "feature(s)" in notes
        assert "fix(es)" in notes

    def test_breaking_marker(self, sample_breaking_commits):
        notes = generate_release_notes(SemanticVersion(2, 0, 0), sample_breaking_commits)
        assert "breaking change(s)" in notes

    def test_no_previous_version(self, sample_commits):
        notes = generate_release_notes(SemanticVersion(1, 0, 0), sample_commits)
        assert "Release 1.0.0" in notes
        assert "Changes since" not in notes


# ── summarize_commits ───────────────────────────────────────────────


class TestSummarizeCommits:
    def test_summary_counts(self, sample_commits):
        summary = summarize_commits(sample_commits)
        assert summary["feat"] == 2
        assert summary["fix"] == 1
        assert summary["docs"] == 1
        assert summary["perf"] == 1

    def test_sorted_by_count(self, sample_commits):
        summary = summarize_commits(sample_commits)
        counts = list(summary.values())
        assert counts == sorted(counts, reverse=True)

    def test_empty_commits(self):
        summary = summarize_commits([])
        assert summary == {}


# ── read/write changelog ────────────────────────────────────────────


class TestReadWriteChangelog:
    def test_read_existing(self, temp_dir):
        with open(os.path.join(temp_dir, "CHANGELOG.md"), "w") as f:
            f.write("# Changelog\n\nContent\n")
        content = read_existing_changelog(temp_dir)
        assert content is not None
        assert "Changelog" in content

    def test_read_nonexistent(self, temp_dir):
        assert read_existing_changelog(temp_dir) is None

    def test_write_changelog(self, temp_dir):
        path = write_changelog(temp_dir, "# Changelog\n\nNew content\n")
        assert os.path.exists(path)
        with open(path) as f:
            assert "New content" in f.read()

    def test_read_alternate_names(self, temp_dir):
        with open(os.path.join(temp_dir, "CHANGES.md"), "w") as f:
            f.write("# Changes\n")
        content = read_existing_changelog(temp_dir)
        assert content is not None
