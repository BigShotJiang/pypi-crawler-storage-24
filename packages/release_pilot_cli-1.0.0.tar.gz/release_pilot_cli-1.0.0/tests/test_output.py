"""Tests for release_pilot.output (smoke tests for rendering)."""

from __future__ import annotations

import io

from rich.console import Console

from release_pilot.models import (
    BumpType,
    CommitType,
    ConventionalCommit,
    ReleaseCheck,
    ReleaseChecklist,
    ReleaseReport,
    SemanticVersion,
    VersionFileUpdate,
)
from release_pilot.output import (
    render_changelog_preview,
    render_checklist,
    render_commit_list,
    render_commit_summary,
    render_file_updates,
    render_release_history,
    render_release_report,
    render_version_info,
)


def _capture(func, *args, **kwargs) -> str:
    """Capture Rich console output."""
    buf = io.StringIO()
    from release_pilot import output as out_mod
    original = out_mod.console
    out_mod.console = Console(file=buf, force_terminal=True, width=120)
    try:
        func(*args, **kwargs)
    finally:
        out_mod.console = original
    return buf.getvalue()


# ── render_version_info ─────────────────────────────────────────────


class TestRenderVersionInfo:
    def test_renders(self):
        output = _capture(render_version_info, SemanticVersion(1, 0, 0), SemanticVersion(1, 1, 0), BumpType.MINOR)
        assert "1.0.0" in output
        assert "1.1.0" in output

    def test_major_bump(self):
        output = _capture(render_version_info, SemanticVersion(1, 0, 0), SemanticVersion(2, 0, 0), BumpType.MAJOR)
        assert "2.0.0" in output
        assert "MAJOR" in output

    def test_patch_bump(self):
        output = _capture(render_version_info, SemanticVersion(1, 0, 0), SemanticVersion(1, 0, 1), BumpType.PATCH)
        assert "1.0.1" in output


# ── render_checklist ────────────────────────────────────────────────


class TestRenderChecklist:
    def test_all_pass(self):
        cl = ReleaseChecklist(checks=[
            ReleaseCheck("Git", True, "OK"),
            ReleaseCheck("Clean", True, "No changes"),
        ])
        output = _capture(render_checklist, cl)
        assert "2" in output
        assert "passed" in output.lower()

    def test_failure(self):
        cl = ReleaseChecklist(checks=[
            ReleaseCheck("Git", True, "OK"),
            ReleaseCheck("Clean", False, "Dirty", required=True),
        ])
        output = _capture(render_checklist, cl)
        assert "Dirty" in output

    def test_warning(self):
        cl = ReleaseChecklist(checks=[
            ReleaseCheck("Branch", False, "Not main", required=False),
        ])
        output = _capture(render_checklist, cl)
        assert "Not main" in output


# ── render_commit_summary ───────────────────────────────────────────


class TestRenderCommitSummary:
    def test_with_commits(self, sample_commits):
        output = _capture(render_commit_summary, sample_commits)
        assert "5" in output
        assert "Features" in output

    def test_empty(self):
        output = _capture(render_commit_summary, [])
        assert "No conventional commits" in output


# ── render_commit_list ──────────────────────────────────────────────


class TestRenderCommitList:
    def test_renders_commits(self, sample_commits):
        output = _capture(render_commit_list, sample_commits)
        assert "abc123d" in output
        assert "add OAuth2 support" in output

    def test_truncated(self):
        commits = [
            ConventionalCommit(f"hash{i}", f"h{i}", CommitType.FIX, None,
                               f"fix {i}", "", False, "", "Dev", "2025-01-01")
            for i in range(25)
        ]
        output = _capture(render_commit_list, commits, max_show=5)
        assert "20" in output
        assert "more" in output

    def test_empty(self):
        output = _capture(render_commit_list, [])
        assert output.strip() == ""


# ── render_file_updates ─────────────────────────────────────────────


class TestRenderFileUpdates:
    def test_updated(self):
        updates = [
            VersionFileUpdate("pyproject.toml", "1.0.0", "2.0.0", "pat", updated=True),
        ]
        output = _capture(render_file_updates, updates)
        assert "pyproject.toml" in output
        assert "2.0.0" in output

    def test_error(self):
        updates = [
            VersionFileUpdate("bad.toml", "", "2.0.0", "", error="File not found"),
        ]
        output = _capture(render_file_updates, updates)
        assert "File not found" in output

    def test_empty(self):
        output = _capture(render_file_updates, [])
        assert "No version files" in output


# ── render_release_report ───────────────────────────────────────────


class TestRenderReleaseReport:
    def test_success(self, sample_release):
        report = ReleaseReport(
            release=sample_release,
            checks=ReleaseChecklist(checks=[ReleaseCheck("A", True, "ok")]),
            file_updates=[],
            tag_created=True,
            pushed=False,
            dry_run=False,
        )
        output = _capture(render_release_report, report)
        assert "1.1.0" in output
        assert "complete" in output.lower()

    def test_dry_run(self, sample_release):
        report = ReleaseReport(
            release=sample_release,
            checks=ReleaseChecklist(checks=[ReleaseCheck("A", True, "ok")]),
            file_updates=[],
            tag_created=False,
            pushed=False,
            dry_run=True,
        )
        output = _capture(render_release_report, report)
        assert "DRY RUN" in output

    def test_failure(self, sample_release):
        report = ReleaseReport(
            release=sample_release,
            checks=ReleaseChecklist(checks=[ReleaseCheck("A", False, "fail", required=True)]),
            file_updates=[],
            tag_created=False,
            pushed=False,
            dry_run=False,
        )
        output = _capture(render_release_report, report)
        assert "failed" in output.lower()


# ── render_changelog_preview ────────────────────────────────────────


class TestRenderChangelogPreview:
    def test_renders(self):
        output = _capture(render_changelog_preview, "## [1.0.0]\n\n### Features\n\n- new stuff")
        assert "1.0.0" in output
        assert "Features" in output

    def test_truncated(self):
        long = "\n".join(f"line {i}" for i in range(100))
        output = _capture(render_changelog_preview, long, max_lines=10)
        assert "more lines" in output


# ── render_release_history ──────────────────────────────────────────


class TestRenderReleaseHistory:
    def test_renders(self):
        releases = [
            {"version": SemanticVersion(2, 0, 0), "date": "2025-02-01", "commits": 15, "tag": "v2.0.0"},
            {"version": SemanticVersion(1, 0, 0), "date": "2025-01-01", "commits": 10, "tag": "v1.0.0"},
        ]
        output = _capture(render_release_history, releases)
        assert "2.0.0" in output
        assert "1.0.0" in output

    def test_empty(self):
        output = _capture(render_release_history, [])
        assert "No releases" in output
