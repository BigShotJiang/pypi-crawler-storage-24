"""Tests for release_pilot.cli."""

from __future__ import annotations

import os

import pytest
from click.testing import CliRunner

from release_pilot.cli import cli


@pytest.fixture
def runner():
    return CliRunner()


# ── Help commands ───────────────────────────────────────────────────


class TestCliHelp:
    def test_main_help(self, runner):
        result = runner.invoke(cli, ["--help"])
        assert result.exit_code == 0
        assert "release-pilot" in result.output

    def test_release_help(self, runner):
        result = runner.invoke(cli, ["release", "--help"])
        assert result.exit_code == 0
        assert "--bump" in result.output
        assert "--dry-run" in result.output
        assert "--push" in result.output

    def test_check_help(self, runner):
        result = runner.invoke(cli, ["check", "--help"])
        assert result.exit_code == 0
        assert "--branch" in result.output

    def test_log_help(self, runner):
        result = runner.invoke(cli, ["log", "--help"])
        assert result.exit_code == 0
        assert "--since" in result.output

    def test_changelog_help(self, runner):
        result = runner.invoke(cli, ["changelog", "--help"])
        assert result.exit_code == 0
        assert "--output" in result.output

    def test_version_help(self, runner):
        result = runner.invoke(cli, ["version", "--help"])
        assert result.exit_code == 0

    def test_history_help(self, runner):
        result = runner.invoke(cli, ["history", "--help"])
        assert result.exit_code == 0

    def test_bump_help(self, runner):
        result = runner.invoke(cli, ["bump", "--help"])
        assert result.exit_code == 0
        assert "VERSION_STR" in result.output

    def test_init_help(self, runner):
        result = runner.invoke(cli, ["init", "--help"])
        assert result.exit_code == 0

    def test_version_option(self, runner):
        result = runner.invoke(cli, ["--version"])
        assert result.exit_code == 0
        assert "1.0.0" in result.output


# ── Init command ────────────────────────────────────────────────────


class TestInitCommand:
    def test_shows_commit_types(self, runner):
        result = runner.invoke(cli, ["init"])
        assert result.exit_code == 0
        assert "feat" in result.output
        assert "fix" in result.output
        assert "Breaking" in result.output


# ── Command integration with git repos ──────────────────────────────


class TestCheckCommand:
    def test_check_in_git_repo(self, runner, git_repo):
        result = runner.invoke(cli, ["check"], catch_exceptions=False)
        # Will work or fail depending on current dir
        # The important thing is it doesn't crash
        assert result.exit_code in (0, 1)

    def test_log_in_git_repo(self, runner, git_repo):
        original_dir = os.getcwd()
        os.chdir(git_repo)
        try:
            result = runner.invoke(cli, ["log"], catch_exceptions=False)
            assert result.exit_code == 0
        finally:
            os.chdir(original_dir)

    def test_version_in_git_repo(self, runner, git_repo):
        original_dir = os.getcwd()
        os.chdir(git_repo)
        try:
            result = runner.invoke(cli, ["version"], catch_exceptions=False)
            assert result.exit_code == 0
        finally:
            os.chdir(original_dir)

    def test_history_in_git_repo(self, runner, git_repo):
        original_dir = os.getcwd()
        os.chdir(git_repo)
        try:
            result = runner.invoke(cli, ["history"], catch_exceptions=False)
            assert result.exit_code == 0
        finally:
            os.chdir(original_dir)

    def test_changelog_preview(self, runner, git_repo):
        original_dir = os.getcwd()
        os.chdir(git_repo)
        try:
            result = runner.invoke(cli, ["changelog"], catch_exceptions=False)
            assert result.exit_code == 0
        finally:
            os.chdir(original_dir)


class TestBumpCommand:
    def test_bump_version(self, runner, git_repo):
        # Create a version file
        with open(os.path.join(git_repo, "pyproject.toml"), "w") as f:
            f.write('[project]\nversion = "0.1.0"\n')

        original_dir = os.getcwd()
        os.chdir(git_repo)
        try:
            result = runner.invoke(cli, ["bump", "1.0.0"], catch_exceptions=False)
            assert result.exit_code == 0
        finally:
            os.chdir(original_dir)

    def test_bump_dry_run(self, runner, git_repo):
        with open(os.path.join(git_repo, "pyproject.toml"), "w") as f:
            f.write('[project]\nversion = "0.1.0"\n')

        original_dir = os.getcwd()
        os.chdir(git_repo)
        try:
            result = runner.invoke(cli, ["bump", "2.0.0", "--dry-run"], catch_exceptions=False)
            assert result.exit_code == 0
            assert "DRY RUN" in result.output
        finally:
            os.chdir(original_dir)


class TestReleaseCommand:
    def test_release_dry_run(self, runner, git_repo):
        original_dir = os.getcwd()
        os.chdir(git_repo)
        try:
            result = runner.invoke(cli, ["release", "--dry-run"], catch_exceptions=False)
            assert result.exit_code == 0
        finally:
            os.chdir(original_dir)

    def test_release_abort(self, runner, git_repo):
        original_dir = os.getcwd()
        os.chdir(git_repo)
        try:
            result = runner.invoke(cli, ["release"], input="n\n", catch_exceptions=False)
            # Should abort without error
            assert result.exit_code == 0
        finally:
            os.chdir(original_dir)
