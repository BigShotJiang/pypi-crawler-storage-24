"""Tests for release_pilot.engine."""

from __future__ import annotations

import os
import subprocess

from release_pilot.engine import execute_release, prepare_release
from release_pilot.models import BumpType, SemanticVersion

# ── prepare_release ─────────────────────────────────────────────────


class TestPrepareRelease:
    def test_auto_detect_minor(self, git_repo):
        release_info, checklist = prepare_release(cwd=git_repo, require_clean=False)
        # Has feat commit, so should be minor
        assert release_info.bump_type == BumpType.MINOR
        assert release_info.version == SemanticVersion(0, 2, 0)
        assert release_info.previous_version == SemanticVersion(0, 1, 0)
        assert len(release_info.commits) >= 2

    def test_forced_bump(self, git_repo):
        release_info, _ = prepare_release(bump="patch", cwd=git_repo, require_clean=False)
        assert release_info.bump_type == BumpType.PATCH
        assert release_info.version == SemanticVersion(0, 1, 1)

    def test_major_bump_forced(self, git_repo):
        release_info, _ = prepare_release(bump="major", cwd=git_repo, require_clean=False)
        assert release_info.version == SemanticVersion(1, 0, 0)

    def test_breaking_commit_triggers_major(self, git_repo_breaking):
        release_info, _ = prepare_release(cwd=git_repo_breaking, require_clean=False)
        assert release_info.bump_type == BumpType.MAJOR
        assert release_info.version == SemanticVersion(1, 0, 0)

    def test_changelog_generated(self, git_repo):
        release_info, _ = prepare_release(cwd=git_repo, require_clean=False)
        assert len(release_info.changelog) > 0
        assert "##" in release_info.changelog

    def test_checklist_passes_clean(self, git_repo):
        _, checklist = prepare_release(cwd=git_repo, require_clean=True)
        git_check = next(c for c in checklist.checks if c.name == "Git Repository")
        assert git_check.passed is True

    def test_tag_format(self, git_repo):
        release_info, _ = prepare_release(cwd=git_repo, require_clean=False)
        assert release_info.tag.startswith("v")

    def test_date_set(self, git_repo):
        release_info, _ = prepare_release(cwd=git_repo, require_clean=False)
        assert len(release_info.date) == 10  # YYYY-MM-DD


# ── execute_release ─────────────────────────────────────────────────


class TestExecuteRelease:
    def test_dry_run(self, git_repo):
        release_info, _ = prepare_release(cwd=git_repo, require_clean=False)
        report = execute_release(
            release=release_info,
            root=git_repo,
            dry_run=True,
            cwd=git_repo,
        )
        assert report.dry_run is True
        assert report.tag_created is False
        assert report.pushed is False

    def test_creates_tag(self, git_repo):
        release_info, _ = prepare_release(cwd=git_repo, require_clean=False)
        report = execute_release(
            release=release_info,
            root=git_repo,
            update_files=False,
            update_changelog=False,
            create_git_tag=True,
            push=False,
            dry_run=False,
            cwd=git_repo,
        )
        assert report.tag_created is True

        # Verify tag exists
        result = subprocess.run(
            ["git", "tag"], cwd=git_repo, capture_output=True, text=True
        )
        assert release_info.tag in result.stdout

    def test_creates_changelog(self, git_repo):
        release_info, _ = prepare_release(cwd=git_repo, require_clean=False)
        execute_release(
            release=release_info,
            root=git_repo,
            update_files=False,
            update_changelog=True,
            create_git_tag=False,
            push=False,
            dry_run=False,
            cwd=git_repo,
        )
        # CHANGELOG.md should exist
        changelog_path = os.path.join(git_repo, "CHANGELOG.md")
        assert os.path.exists(changelog_path)
        with open(changelog_path) as f:
            content = f.read()
        assert "Changelog" in content

    def test_updates_version_files(self, git_repo):
        # Create a version file
        with open(os.path.join(git_repo, "pyproject.toml"), "w") as f:
            f.write('[project]\nversion = "0.1.0"\n')
        subprocess.run(["git", "add", "."], cwd=git_repo, capture_output=True)
        subprocess.run(["git", "commit", "-m", "chore: add pyproject"], cwd=git_repo, capture_output=True)

        release_info, _ = prepare_release(cwd=git_repo, require_clean=False)
        report = execute_release(
            release=release_info,
            root=git_repo,
            update_files=True,
            update_changelog=False,
            create_git_tag=False,
            push=False,
            dry_run=False,
            cwd=git_repo,
        )
        updated = [u for u in report.file_updates if u.updated]
        assert len(updated) >= 1

    def test_report_success_with_tag(self, git_repo):
        release_info, _ = prepare_release(cwd=git_repo, require_clean=False)
        report = execute_release(
            release=release_info,
            root=git_repo,
            update_files=False,
            update_changelog=False,
            create_git_tag=True,
            push=False,
            dry_run=False,
            cwd=git_repo,
        )
        assert report.success is True

    def test_no_empty_repo_release(self, git_repo_empty):
        release_info, checklist = prepare_release(cwd=git_repo_empty, require_clean=False)
        report = execute_release(
            release=release_info,
            root=git_repo_empty,
            dry_run=True,
            cwd=git_repo_empty,
        )
        assert report.dry_run is True
