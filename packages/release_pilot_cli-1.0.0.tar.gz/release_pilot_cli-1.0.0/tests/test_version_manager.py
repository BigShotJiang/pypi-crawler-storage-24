"""Tests for release_pilot.version_manager."""

from __future__ import annotations

import os

from release_pilot.models import SemanticVersion
from release_pilot.version_manager import (
    detect_version_in_file,
    find_version_files,
    update_all_version_files,
    update_version_in_file,
)

# ── find_version_files ──────────────────────────────────────────────


class TestFindVersionFiles:
    def test_finds_pyproject(self, temp_dir):
        _write(temp_dir, "pyproject.toml", '[project]\nversion = "1.0.0"')
        files = find_version_files(temp_dir)
        assert "pyproject.toml" in files

    def test_finds_init_py(self, temp_dir):
        os.makedirs(os.path.join(temp_dir, "pkg"))
        _write(temp_dir, "pkg/__init__.py", '__version__ = "1.0.0"')
        files = find_version_files(temp_dir)
        assert any("__init__.py" in f for f in files)

    def test_finds_package_json(self, temp_dir):
        _write(temp_dir, "package.json", '{"version": "2.0.0"}')
        files = find_version_files(temp_dir)
        assert "package.json" in files

    def test_skips_venv(self, temp_dir):
        os.makedirs(os.path.join(temp_dir, ".venv", "lib"))
        _write(temp_dir, ".venv/lib/setup.py", 'version="0.0.1"')
        files = find_version_files(temp_dir)
        assert not any(".venv" in f for f in files)

    def test_finds_multiple(self, temp_dir):
        _write(temp_dir, "pyproject.toml", 'version = "1.0.0"')
        _write(temp_dir, "package.json", '{"version": "1.0.0"}')
        files = find_version_files(temp_dir)
        assert len(files) >= 2

    def test_empty_dir(self, temp_dir):
        files = find_version_files(temp_dir)
        assert files == []


# ── detect_version_in_file ──────────────────────────────────────────


class TestDetectVersionInFile:
    def test_pyproject_toml(self, temp_dir):
        _write(temp_dir, "pyproject.toml", '[project]\nname = "test"\nversion = "1.2.3"')
        v = detect_version_in_file("pyproject.toml", temp_dir)
        assert v == "1.2.3"

    def test_init_py(self, temp_dir):
        os.makedirs(os.path.join(temp_dir, "pkg"))
        _write(temp_dir, "pkg/__init__.py", '__version__ = "2.0.1"')
        v = detect_version_in_file("pkg/__init__.py", temp_dir)
        assert v == "2.0.1"

    def test_package_json(self, temp_dir):
        _write(temp_dir, "package.json", '{\n  "name": "test",\n  "version": "3.1.0"\n}')
        v = detect_version_in_file("package.json", temp_dir)
        assert v == "3.1.0"

    def test_setup_py(self, temp_dir):
        _write(temp_dir, "setup.py", 'setup(name="test", version="0.5.2")')
        v = detect_version_in_file("setup.py", temp_dir)
        assert v == "0.5.2"

    def test_version_file(self, temp_dir):
        _write(temp_dir, "VERSION", "4.0.0")
        v = detect_version_in_file("VERSION", temp_dir)
        assert v == "4.0.0"

    def test_file_not_found(self, temp_dir):
        v = detect_version_in_file("nonexistent.toml", temp_dir)
        assert v is None

    def test_no_version_in_file(self, temp_dir):
        _write(temp_dir, "pyproject.toml", '[project]\nname = "test"')
        v = detect_version_in_file("pyproject.toml", temp_dir)
        assert v is None

    def test_prerelease_version(self, temp_dir):
        _write(temp_dir, "pyproject.toml", 'version = "1.0.0-beta.1"')
        v = detect_version_in_file("pyproject.toml", temp_dir)
        assert v == "1.0.0-beta.1"

    def test_cargo_toml(self, temp_dir):
        _write(temp_dir, "Cargo.toml", '[package]\nname = "test"\nversion = "0.3.0"')
        v = detect_version_in_file("Cargo.toml", temp_dir)
        assert v == "0.3.0"


# ── update_version_in_file ─────────────────────────────────────────


class TestUpdateVersionInFile:
    def test_update_pyproject(self, temp_dir):
        _write(temp_dir, "pyproject.toml", '[project]\nversion = "1.0.0"\nname = "test"')
        result = update_version_in_file("pyproject.toml", SemanticVersion(2, 0, 0), temp_dir)
        assert result.updated is True
        assert result.old_version == "1.0.0"
        assert result.new_version == "2.0.0"

        # Verify file was actually updated
        with open(os.path.join(temp_dir, "pyproject.toml")) as f:
            content = f.read()
        assert '"2.0.0"' in content

    def test_update_init_py(self, temp_dir):
        os.makedirs(os.path.join(temp_dir, "pkg"))
        _write(temp_dir, "pkg/__init__.py", '__version__ = "1.0.0"')
        result = update_version_in_file("pkg/__init__.py", SemanticVersion(1, 1, 0), temp_dir)
        assert result.updated is True

    def test_dry_run(self, temp_dir):
        _write(temp_dir, "pyproject.toml", 'version = "1.0.0"')
        result = update_version_in_file("pyproject.toml", SemanticVersion(2, 0, 0), temp_dir, dry_run=True)
        assert result.updated is True

        # File should NOT be changed
        with open(os.path.join(temp_dir, "pyproject.toml")) as f:
            assert '"1.0.0"' in f.read()

    def test_file_not_found(self, temp_dir):
        result = update_version_in_file("nonexistent.toml", SemanticVersion(1, 0, 0), temp_dir)
        assert result.updated is False
        assert result.error is not None

    def test_unknown_file_type(self, temp_dir):
        _write(temp_dir, "config.yaml", "version: 1.0.0")
        result = update_version_in_file("config.yaml", SemanticVersion(2, 0, 0), temp_dir)
        assert result.updated is False
        assert result.error is not None

    def test_already_correct_version(self, temp_dir):
        _write(temp_dir, "pyproject.toml", 'version = "1.0.0"')
        result = update_version_in_file("pyproject.toml", SemanticVersion(1, 0, 0), temp_dir)
        assert result.updated is True

    def test_update_package_json(self, temp_dir):
        _write(temp_dir, "package.json", '{"name": "test", "version": "0.1.0"}')
        result = update_version_in_file("package.json", SemanticVersion(1, 0, 0), temp_dir)
        assert result.updated is True


# ── update_all_version_files ────────────────────────────────────────


class TestUpdateAllVersionFiles:
    def test_updates_all(self, temp_dir):
        _write(temp_dir, "pyproject.toml", 'version = "1.0.0"')
        _write(temp_dir, "package.json", '{"version": "1.0.0"}')
        results = update_all_version_files(temp_dir, SemanticVersion(2, 0, 0))
        updated = [r for r in results if r.updated]
        assert len(updated) >= 2

    def test_specific_files(self, temp_dir):
        _write(temp_dir, "pyproject.toml", 'version = "1.0.0"')
        _write(temp_dir, "package.json", '{"version": "1.0.0"}')
        results = update_all_version_files(
            temp_dir, SemanticVersion(2, 0, 0), files=["pyproject.toml"]
        )
        assert len(results) == 1

    def test_dry_run_all(self, temp_dir):
        _write(temp_dir, "pyproject.toml", 'version = "1.0.0"')
        results = update_all_version_files(temp_dir, SemanticVersion(2, 0, 0), dry_run=True)
        assert all(r.updated for r in results)

        # Files unchanged
        with open(os.path.join(temp_dir, "pyproject.toml")) as f:
            assert '"1.0.0"' in f.read()


def _write(root, path, content):
    full = os.path.join(root, path)
    os.makedirs(os.path.dirname(full), exist_ok=True)
    with open(full, "w") as f:
        f.write(content)
