"""Test initialization."""
