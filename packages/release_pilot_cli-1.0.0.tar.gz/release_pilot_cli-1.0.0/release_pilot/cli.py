"""CLI commands for release-pilot."""

from __future__ import annotations

import os
import sys

import click
from rich.console import Console

from release_pilot import __version__

console = Console()


@click.group()
@click.version_option(__version__, prog_name="release-pilot")
def cli():
    """release-pilot — Automated release management CLI.

    Semantic versioning, changelog generation, and release automation
    from conventional commits.
    """
    pass


@cli.command()
@click.option("--bump", "-b", type=click.Choice(["major", "minor", "patch"]), help="Force a specific version bump type")
@click.option("--branch", type=str, default=None, help="Required branch for release (e.g., main)")
@click.option("--push", "-p", is_flag=True, help="Push tag and commits to remote after release")
@click.option("--no-changelog", is_flag=True, help="Skip changelog generation")
@click.option("--no-version-update", is_flag=True, help="Skip version file updates")
@click.option("--dry-run", "-n", is_flag=True, help="Preview release without making changes")
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation prompt")
def release(bump, branch, push, no_changelog, no_version_update, dry_run, yes):
    """Create a new release.

    Analyzes conventional commits since the last tag, determines version bump,
    generates changelog, updates version files, and creates a git tag.

    Examples:

        release-pilot release                # Auto-detect bump type

        release-pilot release --bump minor   # Force minor bump

        release-pilot release --dry-run      # Preview only

        release-pilot release --push         # Release and push
    """
    from release_pilot.engine import execute_release, prepare_release
    from release_pilot.output import (
        render_changelog_preview,
        render_checklist,
        render_commit_summary,
        render_release_report,
        render_version_info,
    )

    cwd = os.getcwd()
    root = _get_repo_root(cwd)

    # Prepare
    release_info, checklist = prepare_release(
        bump=bump,
        required_branch=branch,
        require_clean=not dry_run,
        cwd=cwd,
    )

    # Show preview
    render_version_info(
        release_info.previous_version or _zero_version(),
        release_info.version,
        release_info.bump_type,
    )
    render_checklist(checklist)
    render_commit_summary(release_info.commits)

    if not release_info.commits:
        console.print("  [yellow]No conventional commits found since last release[/yellow]")
        console.print("  [dim]Use conventional commit format: feat: description, fix: description, etc.[/dim]")
        return

    # Preview changelog
    render_changelog_preview(release_info.changelog)

    if not checklist.all_passed and not dry_run:
        console.print("  [red]Pre-release checks failed. Fix issues or use --dry-run to preview.[/red]")
        sys.exit(1)

    # Confirm
    if not dry_run and not yes:
        if not click.confirm(f"\n  Create release {release_info.version}?"):
            console.print("  [dim]Aborted[/dim]")
            return

    # Execute
    report = execute_release(
        release=release_info,
        root=root,
        update_files=not no_version_update,
        update_changelog=not no_changelog,
        create_git_tag=True,
        push=push,
        dry_run=dry_run,
        cwd=cwd,
    )

    render_release_report(report)

    if not report.success and not dry_run:
        sys.exit(1)


@cli.command()
@click.option("--bump", "-b", type=click.Choice(["major", "minor", "patch"]), help="Force a specific version bump type")
@click.option("--branch", type=str, default=None, help="Required branch for release")
def check(bump, branch):
    """Run pre-release checks without making changes.

    Validates repository state and previews what would happen during release.

    Examples:

        release-pilot check

        release-pilot check --branch main
    """
    from release_pilot.engine import prepare_release
    from release_pilot.output import (
        render_checklist,
        render_commit_summary,
        render_version_info,
    )

    cwd = os.getcwd()

    release_info, checklist = prepare_release(
        bump=bump,
        required_branch=branch,
        require_clean=False,
        cwd=cwd,
    )

    render_version_info(
        release_info.previous_version or _zero_version(),
        release_info.version,
        release_info.bump_type,
    )
    render_checklist(checklist)
    render_commit_summary(release_info.commits)

    if not checklist.all_passed:
        sys.exit(1)


@cli.command()
@click.option("--since", "-s", type=str, default=None, help="Tag to start from (default: latest)")
@click.option("--show-all", "-a", is_flag=True, help="Show all commits, not just summary")
def log(since, show_all):
    """Show conventional commits since last tag.

    Displays a summary of commits grouped by type, useful for
    reviewing what would go into the next release.

    Examples:

        release-pilot log

        release-pilot log --since v1.0.0

        release-pilot log --show-all
    """
    from release_pilot.git_ops import get_commits_since_tag, get_latest_tag
    from release_pilot.output import render_commit_list, render_commit_summary

    cwd = os.getcwd()
    _ensure_git_repo(cwd)

    tag = since or get_latest_tag(cwd)
    commits = get_commits_since_tag(tag, cwd)

    if not commits:
        since_str = f" since {tag}" if tag else ""
        console.print(f"  [dim]No conventional commits found{since_str}[/dim]")
        return

    render_commit_summary(commits)
    if show_all:
        render_commit_list(commits)


@cli.command()
@click.option("--bump", "-b", type=click.Choice(["major", "minor", "patch"]), help="Force bump type")
@click.option("--output", "-o", type=click.Path(), help="Write changelog to file")
def changelog(bump, output):
    """Generate changelog from conventional commits.

    Creates a formatted changelog section from commits since the last tag.

    Examples:

        release-pilot changelog

        release-pilot changelog --output CHANGELOG.md

        release-pilot changelog --bump minor
    """
    from release_pilot.changelog import (
        generate_full_changelog,
        read_existing_changelog,
    )
    from release_pilot.engine import prepare_release
    from release_pilot.output import render_changelog_preview

    cwd = os.getcwd()
    _ensure_git_repo(cwd)
    root = _get_repo_root(cwd)

    release_info, _ = prepare_release(bump=bump, require_clean=False, cwd=cwd)

    if not release_info.commits:
        console.print("  [dim]No conventional commits found[/dim]")
        return

    if output:
        existing = read_existing_changelog(root)
        full = generate_full_changelog(
            release_info.version, release_info.commits, existing,
        )
        with open(output, "w", encoding="utf-8") as f:
            f.write(full)
        console.print(f"  [green]✓[/green] Changelog written to {output}")
    else:
        render_changelog_preview(release_info.changelog)


@cli.command()
def version():
    """Show current version from git tags and version files.

    Displays the current version detected from git tags and any
    version files found in the project.
    """
    from release_pilot.git_ops import get_latest_tag, get_latest_version
    from release_pilot.version_manager import detect_version_in_file, find_version_files

    cwd = os.getcwd()
    _ensure_git_repo(cwd)
    root = _get_repo_root(cwd)

    tag = get_latest_tag(cwd)
    git_version = get_latest_version(cwd)

    console.print()
    console.print(f"  [bold]Git tag version:[/bold]  [cyan]{git_version}[/cyan]" + (f"  [dim]({tag})[/dim]" if tag else "  [dim](no tags)[/dim]"))

    # Find version files
    files = find_version_files(root)
    if files:
        console.print("  [bold]Version files:[/bold]")
        for f in files:
            detected = detect_version_in_file(f, root)
            if detected:
                match = "✓" if detected == str(git_version) else "✗ mismatch"
                icon_color = "green" if detected == str(git_version) else "yellow"
                console.print(f"    [{icon_color}]{match}[/{icon_color}] {f}: [cyan]{detected}[/cyan]")
            else:
                console.print(f"    [dim]- {f}: (no version detected)[/dim]")
    else:
        console.print("  [dim]No version files found[/dim]")
    console.print()


@cli.command()
def history():
    """Show release history from git tags.

    Lists all version tags with dates and commit counts.
    """
    from release_pilot.git_ops import _run_git, get_tags
    from release_pilot.models import SemanticVersion
    from release_pilot.output import render_release_history

    cwd = os.getcwd()
    _ensure_git_repo(cwd)

    tags = get_tags(cwd)
    version_tags = [t for t in tags if any(c.isdigit() for c in t)]

    releases = []
    for tag in version_tags:
        # Get tag date
        ok, date = _run_git(["log", "-1", "--format=%ai", tag], cwd)
        date_str = date[:10] if ok and date else "unknown"

        # Get commit count between this tag and previous
        tag_idx = version_tags.index(tag)
        if tag_idx < len(version_tags) - 1:
            prev_tag = version_tags[tag_idx + 1]
            ok, count = _run_git(["rev-list", "--count", f"{prev_tag}..{tag}"], cwd)
        else:
            ok, count = _run_git(["rev-list", "--count", tag], cwd)

        commit_count = int(count) if ok and count.isdigit() else 0

        releases.append({
            "version": SemanticVersion.parse(tag),
            "date": date_str,
            "commits": commit_count,
            "tag": tag,
        })

    render_release_history(releases)


@cli.command()
@click.argument("version_str")
@click.option("--dry-run", "-n", is_flag=True, help="Preview changes without writing files")
def bump(version_str, dry_run):
    """Manually set version in all project files.

    Updates version numbers in pyproject.toml, package.json, __init__.py, etc.

    Examples:

        release-pilot bump 2.0.0

        release-pilot bump 1.5.0 --dry-run
    """
    from release_pilot.models import SemanticVersion
    from release_pilot.output import render_file_updates
    from release_pilot.version_manager import update_all_version_files

    cwd = os.getcwd()
    root = _get_repo_root(cwd)

    new_version = SemanticVersion.parse(version_str)
    mode = "[yellow][DRY RUN][/yellow] " if dry_run else ""
    console.print(f"\n  {mode}Setting version to [bold cyan]{new_version}[/bold cyan]\n")

    updates = update_all_version_files(root, new_version, dry_run=dry_run)
    render_file_updates(updates)

    if not dry_run:
        updated = sum(1 for u in updates if u.updated)
        console.print(f"  [green]✓[/green] Updated {updated} file(s)")
    console.print()


@cli.command()
def init():
    """Initialize conventional commit configuration.

    Creates example commit message templates and hook configurations.
    """
    console.print()
    console.print("  [bold]Conventional Commit Format[/bold]")
    console.print()
    console.print("  [cyan]type(scope): description[/cyan]")
    console.print()
    console.print("  [bold]Types:[/bold]")

    types = [
        ("feat", "A new feature", "minor"),
        ("fix", "A bug fix", "patch"),
        ("docs", "Documentation only", "patch"),
        ("style", "Code style (formatting)", "patch"),
        ("refactor", "Code restructuring", "patch"),
        ("perf", "Performance improvement", "patch"),
        ("test", "Adding tests", "patch"),
        ("build", "Build system changes", "patch"),
        ("ci", "CI/CD changes", "patch"),
        ("chore", "Maintenance tasks", "patch"),
        ("revert", "Revert a commit", "patch"),
    ]

    from rich.table import Table

    table = Table(show_header=True, header_style="bold", box=None, padding=(0, 2))
    table.add_column("Type", min_width=12, style="cyan")
    table.add_column("Description", min_width=30)
    table.add_column("Bump", style="dim")

    for type_, desc, bump_type in types:
        table.add_row(type_, desc, bump_type)

    console.print(table)
    console.print()
    console.print("  [bold]Breaking Changes:[/bold]")
    console.print("    [cyan]feat!: remove deprecated API[/cyan]    → [red]MAJOR[/red] bump")
    console.print()
    console.print("  [bold]Examples:[/bold]")
    console.print("    [dim]feat(auth): add OAuth2 support[/dim]")
    console.print("    [dim]fix(parser): handle empty input[/dim]")
    console.print("    [dim]feat!: redesign config format[/dim]")
    console.print("    [dim]docs: update installation guide[/dim]")
    console.print()


def _ensure_git_repo(cwd: str) -> None:
    """Exit if not in a git repository."""
    from release_pilot.git_ops import is_git_repo
    if not is_git_repo(cwd):
        console.print("  [red]Error: Not a git repository[/red]")
        sys.exit(1)


def _get_repo_root(cwd: str) -> str:
    """Get repo root, exit on failure."""
    from release_pilot.git_ops import get_repo_root
    root = get_repo_root(cwd)
    if not root:
        console.print("  [red]Error: Cannot determine repository root[/red]")
        sys.exit(1)
    return root


def _zero_version():
    """Return a zero semantic version."""
    from release_pilot.models import SemanticVersion
    return SemanticVersion(0, 0, 0)
