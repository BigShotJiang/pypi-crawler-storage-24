"""release-pilot — Automated release management CLI."""

__version__ = "1.0.0"
