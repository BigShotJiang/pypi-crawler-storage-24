"""Allow running as python -m release_pilot."""

from release_pilot.cli import cli

if __name__ == "__main__":
    cli()
