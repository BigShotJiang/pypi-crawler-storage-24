"""Rich terminal output for release-pilot."""

from __future__ import annotations

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from release_pilot.models import (
    BumpType,
    CommitType,
    ConventionalCommit,
    ReleaseChecklist,
    ReleaseReport,
    SemanticVersion,
    VersionFileUpdate,
)

console = Console()


def render_version_info(current: SemanticVersion, new: SemanticVersion, bump: BumpType) -> None:
    """Display version bump information."""
    bump_colors = {
        BumpType.MAJOR: "red",
        BumpType.MINOR: "yellow",
        BumpType.PATCH: "green",
        BumpType.NONE: "dim",
    }
    color = bump_colors.get(bump, "white")

    panel = Panel(
        Text.from_markup(
            f"  [dim]{current}[/dim]  →  [bold {color}]{new}[/bold {color}]\n"
            f"  [dim]Bump:[/dim] [{color}]{bump.value.upper()}[/{color}]"
        ),
        title="[bold]Version[/bold]",
        border_style=color,
        padding=(0, 2),
    )
    console.print(panel)


def render_checklist(checklist: ReleaseChecklist) -> None:
    """Display pre-release checklist."""
    table = Table(show_header=True, header_style="bold", box=None, padding=(0, 2))
    table.add_column("", width=3)
    table.add_column("Check", min_width=20)
    table.add_column("Details")

    for check in checklist.checks:
        if check.passed:
            icon = "[green]✓[/green]"
        elif check.required:
            icon = "[red]✗[/red]"
        else:
            icon = "[yellow]⚠[/yellow]"

        if check.passed:
            name_cell = check.name
        elif check.required:
            name_cell = f"[red]{check.name}[/red]"
        else:
            name_cell = f"[yellow]{check.name}[/yellow]"
        table.add_row(icon, name_cell, f"[dim]{check.message}[/dim]")

    status = "[green]All checks passed[/green]" if checklist.all_passed else "[red]Some checks failed[/red]"
    console.print()
    console.print(f"  [bold]Pre-release Checks[/bold]  ({checklist.passed_count}/{checklist.total} passed)")
    console.print(table)
    console.print(f"  {status}")
    console.print()


def render_commit_summary(commits: list[ConventionalCommit]) -> None:
    """Display commit type summary."""
    if not commits:
        console.print("  [dim]No conventional commits found[/dim]")
        return

    # Count by type
    type_counts: dict[CommitType, int] = {}
    for c in commits:
        type_counts[c.type] = type_counts.get(c.type, 0) + 1

    table = Table(show_header=True, header_style="bold", box=None, padding=(0, 2))
    table.add_column("Type", min_width=15)
    table.add_column("Count", justify="right")
    table.add_column("", min_width=20)

    type_colors = {
        CommitType.FEAT: "green",
        CommitType.FIX: "red",
        CommitType.PERF: "cyan",
        CommitType.BREAKING: "red bold",
        CommitType.REFACTOR: "yellow",
        CommitType.DOCS: "blue",
    }

    sorted_types = sorted(type_counts.items(), key=lambda x: x[0].changelog_priority)
    for ctype, count in sorted_types:
        color = type_colors.get(ctype, "dim")
        bar = "█" * min(count, 30)
        table.add_row(f"[{color}]{ctype.label}[/{color}]", str(count), f"[{color}]{bar}[/{color}]")

    breaking = sum(1 for c in commits if c.breaking)
    console.print(f"  [bold]Commits[/bold]  ({len(commits)} total, {breaking} breaking)")
    console.print(table)
    console.print()


def render_commit_list(commits: list[ConventionalCommit], max_show: int = 20) -> None:
    """Display individual commits."""
    if not commits:
        return

    table = Table(show_header=True, header_style="bold", box=None, padding=(0, 1))
    table.add_column("Hash", width=8, style="cyan")
    table.add_column("Type", width=10)
    table.add_column("Description", min_width=40)
    table.add_column("Author", style="dim")

    type_colors = {
        CommitType.FEAT: "green",
        CommitType.FIX: "red",
        CommitType.PERF: "cyan",
        CommitType.REFACTOR: "yellow",
    }

    for commit in commits[:max_show]:
        color = type_colors.get(commit.type, "dim")
        breaking = " !" if commit.breaking else ""
        scope = f"({commit.scope})" if commit.scope else ""
        type_str = f"[{color}]{commit.type.value}{scope}{breaking}[/{color}]"
        table.add_row(commit.short_hash, type_str, commit.description, commit.author)

    console.print(table)
    if len(commits) > max_show:
        console.print(f"  [dim]... and {len(commits) - max_show} more commits[/dim]")
    console.print()


def render_file_updates(updates: list[VersionFileUpdate]) -> None:
    """Display version file update results."""
    if not updates:
        console.print("  [dim]No version files found[/dim]")
        return

    table = Table(show_header=True, header_style="bold", box=None, padding=(0, 2))
    table.add_column("", width=3)
    table.add_column("File", min_width=30)
    table.add_column("Version Change")

    for update in updates:
        if update.updated:
            icon = "[green]✓[/green]"
            if update.old_version == update.new_version:
                change = f"[dim]{update.new_version} (already up to date)[/dim]"
            else:
                change = f"[dim]{update.old_version}[/dim] → [green]{update.new_version}[/green]"
        elif update.error:
            icon = "[red]✗[/red]"
            change = f"[red]{update.error}[/red]"
        else:
            icon = "[yellow]⚠[/yellow]"
            change = "[dim]skipped[/dim]"

        table.add_row(icon, update.file_path, change)

    console.print("  [bold]Version Files[/bold]")
    console.print(table)
    console.print()


def render_release_report(report: ReleaseReport) -> None:
    """Display complete release report."""
    release = report.release
    mode = "[yellow][DRY RUN][/yellow] " if report.dry_run else ""

    console.print()
    console.print(f"  {mode}[bold]Release Report[/bold]")
    console.print()

    # Version info
    render_version_info(
        release.previous_version or SemanticVersion(0, 0, 0),
        release.version,
        release.bump_type,
    )

    # Checklist
    render_checklist(report.checks)

    # Commit summary
    render_commit_summary(release.commits)

    # File updates
    if report.file_updates:
        render_file_updates(report.file_updates)

    # Actions taken
    actions = []
    if report.file_updates:
        updated = sum(1 for u in report.file_updates if u.updated)
        actions.append(f"Updated {updated} file(s)")
    if report.tag_created:
        actions.append(f"Created tag {release.tag}")
    if report.pushed:
        actions.append("Pushed to remote")

    if actions:
        console.print("  [bold]Actions[/bold]")
        for action in actions:
            console.print(f"    [green]✓[/green] {action}")
        console.print()

    # Final status
    if report.success:
        console.print(f"  [green bold]✓ Release {release.version} {'ready' if report.dry_run else 'complete'}![/green bold]")
    else:
        console.print("  [red bold]✗ Release failed — check errors above[/red bold]")
    console.print()


def render_changelog_preview(changelog: str, max_lines: int = 40) -> None:
    """Preview generated changelog."""
    lines = changelog.split("\n")
    preview = "\n".join(lines[:max_lines])
    if len(lines) > max_lines:
        preview += f"\n\n... ({len(lines) - max_lines} more lines)"

    panel = Panel(
        preview,
        title="[bold]Changelog Preview[/bold]",
        border_style="blue",
        padding=(1, 2),
    )
    console.print(panel)


def render_release_history(releases: list[dict]) -> None:
    """Display release history from git tags."""
    if not releases:
        console.print("  [dim]No releases found[/dim]")
        return

    table = Table(show_header=True, header_style="bold", box=None, padding=(0, 2))
    table.add_column("Version", min_width=12, style="cyan bold")
    table.add_column("Date", min_width=12, style="dim")
    table.add_column("Commits", justify="right")
    table.add_column("Tag")

    for rel in releases:
        table.add_row(
            str(rel.get("version", "?")),
            rel.get("date", "?"),
            str(rel.get("commits", "?")),
            rel.get("tag", "?"),
        )

    console.print()
    console.print("  [bold]Release History[/bold]")
    console.print(table)
    console.print()
