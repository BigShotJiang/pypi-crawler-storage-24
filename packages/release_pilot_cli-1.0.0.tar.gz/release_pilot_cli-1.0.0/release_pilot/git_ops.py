"""Git operations for release-pilot."""

from __future__ import annotations

import os
import subprocess
from typing import Optional

from release_pilot.models import (
    BumpType,
    CommitType,
    ConventionalCommit,
    ReleaseCheck,
    ReleaseChecklist,
    SemanticVersion,
    parse_commit_message,
)


def _run_git(args: list[str], cwd: Optional[str] = None) -> tuple[bool, str]:
    """Run a git command and return (success, output)."""
    try:
        result = subprocess.run(
            ["git"] + args,
            capture_output=True,
            text=True,
            cwd=cwd or os.getcwd(),
            timeout=30,
        )
        output = result.stdout.strip()
        if result.returncode != 0:
            return False, result.stderr.strip() or output
        return True, output
    except FileNotFoundError:
        return False, "git is not installed or not in PATH"
    except subprocess.TimeoutExpired:
        return False, "git command timed out"
    except Exception as e:
        return False, str(e)


def is_git_repo(cwd: Optional[str] = None) -> bool:
    """Check if current directory is a git repository."""
    ok, _ = _run_git(["rev-parse", "--is-inside-work-tree"], cwd)
    return ok


def get_repo_root(cwd: Optional[str] = None) -> Optional[str]:
    """Get the root directory of the git repository."""
    ok, output = _run_git(["rev-parse", "--show-toplevel"], cwd)
    return output if ok else None


def get_current_branch(cwd: Optional[str] = None) -> Optional[str]:
    """Get the current branch name."""
    ok, output = _run_git(["rev-parse", "--abbrev-ref", "HEAD"], cwd)
    return output if ok else None


def get_remote_url(cwd: Optional[str] = None) -> Optional[str]:
    """Get the origin remote URL."""
    ok, output = _run_git(["remote", "get-url", "origin"], cwd)
    return output if ok else None


def is_working_tree_clean(cwd: Optional[str] = None) -> bool:
    """Check if the working tree has no uncommitted changes."""
    ok, output = _run_git(["status", "--porcelain"], cwd)
    return ok and output == ""


def get_tags(cwd: Optional[str] = None) -> list[str]:
    """Get all tags sorted by version."""
    ok, output = _run_git(["tag", "--sort=-v:refname"], cwd)
    if not ok or not output:
        return []
    return [t.strip() for t in output.split("\n") if t.strip()]


def get_latest_tag(cwd: Optional[str] = None) -> Optional[str]:
    """Get the most recent version tag."""
    tags = get_tags(cwd)
    # Filter to semver-like tags
    version_tags = [t for t in tags if t.startswith("v") and any(c.isdigit() for c in t)]
    if not version_tags:
        # Try without v prefix
        version_tags = [t for t in tags if any(c.isdigit() for c in t)]
    return version_tags[0] if version_tags else None


def get_latest_version(cwd: Optional[str] = None) -> SemanticVersion:
    """Get the latest version from git tags."""
    tag = get_latest_tag(cwd)
    if tag:
        return SemanticVersion.parse(tag)
    return SemanticVersion(0, 0, 0)


def get_commits_since_tag(tag: Optional[str] = None, cwd: Optional[str] = None) -> list[ConventionalCommit]:
    """Get all conventional commits since the given tag."""
    separator = "---COMMIT_SEP---"
    fmt = f"%H{separator}%h{separator}%an{separator}%ai{separator}%B{separator}---END---"

    if tag:
        ok, output = _run_git(["log", f"{tag}..HEAD", f"--format={fmt}"], cwd)
    else:
        ok, output = _run_git(["log", f"--format={fmt}"], cwd)

    if not ok or not output:
        return []

    commits = []
    raw_commits = output.split("---END---")

    for raw in raw_commits:
        raw = raw.strip()
        if not raw:
            continue

        parts = raw.split(separator)
        if len(parts) < 5:
            continue

        hash_full = parts[0].strip()
        hash_short = parts[1].strip()
        author = parts[2].strip()
        date = parts[3].strip()
        message = parts[4].strip()

        commit = parse_commit_message(hash_full, hash_short, message, author, date)
        if commit:
            commits.append(commit)

    return commits


def determine_bump_type(commits: list[ConventionalCommit]) -> BumpType:
    """Determine the version bump type from commits."""
    if not commits:
        return BumpType.NONE

    has_breaking = any(c.breaking for c in commits)
    has_feat = any(c.type == CommitType.FEAT for c in commits)
    has_fix = any(c.type in (CommitType.FIX, CommitType.PERF, CommitType.REFACTOR) for c in commits)

    if has_breaking:
        return BumpType.MAJOR
    elif has_feat:
        return BumpType.MINOR
    elif has_fix:
        return BumpType.PATCH
    else:
        return BumpType.PATCH  # Default to patch for any other changes


def create_tag(tag: str, message: str, cwd: Optional[str] = None) -> tuple[bool, str]:
    """Create an annotated git tag."""
    return _run_git(["tag", "-a", tag, "-m", message], cwd)


def push_tag(tag: str, cwd: Optional[str] = None) -> tuple[bool, str]:
    """Push a tag to the remote."""
    return _run_git(["push", "origin", tag], cwd)


def push_changes(cwd: Optional[str] = None) -> tuple[bool, str]:
    """Push commits to the remote."""
    return _run_git(["push"], cwd)


def commit_files(files: list[str], message: str, cwd: Optional[str] = None) -> tuple[bool, str]:
    """Stage and commit specific files."""
    ok, err = _run_git(["add"] + files, cwd)
    if not ok:
        return False, f"Failed to stage files: {err}"
    return _run_git(["commit", "-m", message], cwd)


def get_commit_count(since_tag: Optional[str] = None, cwd: Optional[str] = None) -> int:
    """Get number of commits since a tag or total."""
    if since_tag:
        ok, output = _run_git(["rev-list", "--count", f"{since_tag}..HEAD"], cwd)
    else:
        ok, output = _run_git(["rev-list", "--count", "HEAD"], cwd)

    if ok:
        try:
            return int(output.strip())
        except ValueError:
            return 0
    return 0


def run_preflight_checks(
    required_branch: Optional[str] = None,
    require_clean: bool = True,
    cwd: Optional[str] = None,
) -> ReleaseChecklist:
    """Run pre-release validation checks."""
    checks = []

    # Check: git repository
    repo_ok = is_git_repo(cwd)
    checks.append(ReleaseCheck(
        name="Git Repository",
        passed=repo_ok,
        message="Inside a git repository" if repo_ok else "Not a git repository",
        required=True,
    ))

    if not repo_ok:
        return ReleaseChecklist(checks=checks)

    # Check: clean working tree
    if require_clean:
        clean = is_working_tree_clean(cwd)
        checks.append(ReleaseCheck(
            name="Clean Working Tree",
            passed=clean,
            message="No uncommitted changes" if clean else "Uncommitted changes detected — commit or stash first",
            required=True,
        ))

    # Check: branch
    branch = get_current_branch(cwd)
    if required_branch:
        branch_ok = branch == required_branch
        checks.append(ReleaseCheck(
            name="Branch",
            passed=branch_ok,
            message=f"On branch '{branch}'" if branch_ok else f"Expected branch '{required_branch}', on '{branch}'",
            required=True,
        ))
    else:
        main_branch = branch in ("main", "master")
        checks.append(ReleaseCheck(
            name="Branch",
            passed=main_branch,
            message=f"On branch '{branch}'" + ("" if main_branch else " (not main/master)"),
            required=False,
        ))

    # Check: remote configured
    remote = get_remote_url(cwd)
    checks.append(ReleaseCheck(
        name="Remote Origin",
        passed=remote is not None,
        message=f"Remote: {remote}" if remote else "No remote 'origin' configured",
        required=False,
    ))

    # Check: commits exist since last tag
    latest_tag = get_latest_tag(cwd)
    commit_count = get_commit_count(latest_tag, cwd)
    has_commits = commit_count > 0
    tag_msg = f" since {latest_tag}" if latest_tag else ""
    checks.append(ReleaseCheck(
        name="New Commits",
        passed=has_commits,
        message=f"{commit_count} commit(s){tag_msg}" if has_commits else f"No new commits{tag_msg}",
        required=True,
    ))

    # Check: conventional commits found
    commits = get_commits_since_tag(latest_tag, cwd)
    has_conventional = len(commits) > 0
    checks.append(ReleaseCheck(
        name="Conventional Commits",
        passed=has_conventional,
        message=f"{len(commits)} conventional commit(s) found" if has_conventional else "No conventional commits found",
        required=False,
    ))

    return ReleaseChecklist(checks=checks)
