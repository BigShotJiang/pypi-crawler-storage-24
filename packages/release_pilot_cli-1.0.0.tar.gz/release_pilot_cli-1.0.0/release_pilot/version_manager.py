"""Version file management for release-pilot."""

from __future__ import annotations

import os
import re
from typing import Optional

from release_pilot.models import SemanticVersion, VersionFileUpdate

# Patterns for finding versions in common files
VERSION_PATTERNS: dict[str, list[tuple[str, str]]] = {
    "pyproject.toml": [
        (r'(version\s*=\s*["\'])(\d+\.\d+\.\d+(?:-[a-zA-Z0-9.]+)?)', r'\g<1>{version}'),
    ],
    "setup.py": [
        (r'(version\s*=\s*["\'])(\d+\.\d+\.\d+(?:-[a-zA-Z0-9.]+)?)', r'\g<1>{version}'),
    ],
    "setup.cfg": [
        (r'(version\s*=\s*)(\d+\.\d+\.\d+(?:-[a-zA-Z0-9.]+)?)', r'\g<1>{version}'),
    ],
    "package.json": [
        (r'("version"\s*:\s*")(\d+\.\d+\.\d+(?:-[a-zA-Z0-9.]+)?)', r'\g<1>{version}'),
    ],
    "Cargo.toml": [
        (r'(version\s*=\s*")(\d+\.\d+\.\d+(?:-[a-zA-Z0-9.]+)?)', r'\g<1>{version}'),
    ],
    "__init__.py": [
        (r'(__version__\s*=\s*["\'])(\d+\.\d+\.\d+(?:-[a-zA-Z0-9.]+)?)', r'\g<1>{version}'),
    ],
    "version.py": [
        (r'(__version__\s*=\s*["\'])(\d+\.\d+\.\d+(?:-[a-zA-Z0-9.]+)?)', r'\g<1>{version}'),
        (r'(VERSION\s*=\s*["\'])(\d+\.\d+\.\d+(?:-[a-zA-Z0-9.]+)?)', r'\g<1>{version}'),
    ],
    "VERSION": [
        (r'^()(\d+\.\d+\.\d+(?:-[a-zA-Z0-9.]+)?)$', r'{version}'),
    ],
}


def find_version_files(root: str) -> list[str]:
    """Find files that likely contain version numbers."""
    found = []
    known_filenames = set(VERSION_PATTERNS.keys())

    for dirpath, dirnames, filenames in os.walk(root):
        # Skip common non-project directories
        dirnames[:] = [
            d for d in dirnames
            if d not in (".git", ".venv", "venv", "node_modules", "__pycache__", ".tox",
                         "dist", "build", ".eggs", "*.egg-info", ".mypy_cache")
        ]

        for filename in filenames:
            if filename in known_filenames:
                full_path = os.path.join(dirpath, filename)
                rel_path = os.path.relpath(full_path, root)
                found.append(rel_path)

    return sorted(found)


def detect_version_in_file(file_path: str, root: str) -> Optional[str]:
    """Detect the current version string in a file."""
    full_path = os.path.join(root, file_path) if not os.path.isabs(file_path) else file_path
    filename = os.path.basename(file_path)

    if not os.path.exists(full_path):
        return None

    patterns = VERSION_PATTERNS.get(filename, [])
    if not patterns:
        return None

    try:
        with open(full_path, encoding="utf-8") as f:
            content = f.read()
    except (OSError, UnicodeDecodeError):
        return None

    for search_pattern, _ in patterns:
        match = re.search(search_pattern, content)
        if match:
            return match.group(2)

    return None


def update_version_in_file(
    file_path: str,
    new_version: SemanticVersion,
    root: str,
    dry_run: bool = False,
) -> VersionFileUpdate:
    """Update the version in a specific file."""
    full_path = os.path.join(root, file_path) if not os.path.isabs(file_path) else file_path
    filename = os.path.basename(file_path)
    version_str = str(new_version)

    update = VersionFileUpdate(
        file_path=file_path,
        old_version="",
        new_version=version_str,
        pattern="",
    )

    if not os.path.exists(full_path):
        update.error = f"File not found: {file_path}"
        return update

    patterns = VERSION_PATTERNS.get(filename, [])
    if not patterns:
        update.error = f"No version pattern for: {filename}"
        return update

    try:
        with open(full_path, encoding="utf-8") as f:
            content = f.read()
    except (OSError, UnicodeDecodeError) as e:
        update.error = f"Read error: {e}"
        return update

    for search_pattern, replace_template in patterns:
        match = re.search(search_pattern, content)
        if match:
            old_version = match.group(2)
            update.old_version = old_version
            update.pattern = search_pattern

            if old_version == version_str:
                update.updated = True  # Already correct
                return update

            replacement = replace_template.format(version=version_str)
            new_content = re.sub(search_pattern, replacement, content, count=1)

            if not dry_run:
                try:
                    with open(full_path, "w", encoding="utf-8") as f:
                        f.write(new_content)
                except OSError as e:
                    update.error = f"Write error: {e}"
                    return update

            update.updated = True
            return update

    update.error = "No version pattern matched in file content"
    return update


def update_all_version_files(
    root: str,
    new_version: SemanticVersion,
    dry_run: bool = False,
    files: Optional[list[str]] = None,
) -> list[VersionFileUpdate]:
    """Update version in all detected files or specified files."""
    if files is None:
        files = find_version_files(root)

    updates = []
    for file_path in files:
        update = update_version_in_file(file_path, new_version, root, dry_run)
        updates.append(update)

    return updates
