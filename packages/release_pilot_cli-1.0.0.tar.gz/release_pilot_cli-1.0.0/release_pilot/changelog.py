"""Changelog generation for release-pilot."""

from __future__ import annotations

import os
from collections import defaultdict
from datetime import datetime
from typing import Optional

from release_pilot.models import (
    CommitType,
    ConventionalCommit,
    SemanticVersion,
)


def generate_changelog_section(
    version: SemanticVersion,
    commits: list[ConventionalCommit],
    date: Optional[str] = None,
    include_header: bool = True,
) -> str:
    """Generate a changelog section for a specific version."""
    if date is None:
        date = datetime.now().strftime("%Y-%m-%d")

    lines = []

    if include_header:
        lines.append(f"## [{version}] - {date}")
        lines.append("")

    # Group commits by type
    grouped: dict[CommitType, list[ConventionalCommit]] = defaultdict(list)
    breaking_commits = []

    for commit in commits:
        if commit.breaking:
            breaking_commits.append(commit)
        grouped[commit.type].append(commit)

    # Breaking changes first
    if breaking_commits:
        lines.append("### ⚠ BREAKING CHANGES")
        lines.append("")
        for commit in breaking_commits:
            scope = f"**{commit.scope}:** " if commit.scope else ""
            lines.append(f"- {scope}{commit.description} ({commit.short_hash})")
        lines.append("")

    # Sort by changelog priority
    sorted_types = sorted(grouped.keys(), key=lambda t: t.changelog_priority)

    for commit_type in sorted_types:
        type_commits = grouped[commit_type]
        # Skip breaking section since we already showed it
        if commit_type == CommitType.BREAKING:
            continue

        lines.append(f"### {commit_type.label}")
        lines.append("")

        # Group by scope within type
        scoped: dict[Optional[str], list[ConventionalCommit]] = defaultdict(list)
        for commit in type_commits:
            scoped[commit.scope].append(commit)

        # None scope first, then alphabetical
        scope_order = sorted(scoped.keys(), key=lambda s: (s is not None, s or ""))

        for scope in scope_order:
            for commit in scoped[scope]:
                scope_prefix = f"**{commit.scope}:** " if commit.scope else ""
                breaking_flag = " ⚠" if commit.breaking else ""
                lines.append(f"- {scope_prefix}{commit.description}{breaking_flag} ({commit.short_hash})")

        lines.append("")

    return "\n".join(lines).rstrip() + "\n"


def generate_full_changelog(
    version: SemanticVersion,
    commits: list[ConventionalCommit],
    existing_changelog: Optional[str] = None,
    date: Optional[str] = None,
    project_name: Optional[str] = None,
) -> str:
    """Generate a complete CHANGELOG.md with new section prepended."""
    section = generate_changelog_section(version, commits, date)

    if existing_changelog:
        # Find where to insert (after the header)
        header_end = _find_changelog_insert_point(existing_changelog)
        if header_end >= 0:
            before = existing_changelog[:header_end].rstrip()
            after = existing_changelog[header_end:].strip()
            return f"{before}\n\n{section}\n{after}\n"
        else:
            # Prepend with header
            return f"# Changelog\n\nAll notable changes to this project will be documented in this file.\n\n{section}\n{existing_changelog.strip()}\n"
    else:
        title = project_name or "this project"
        header = f"# Changelog\n\nAll notable changes to {title} will be documented in this file.\n\nThe format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),\nand this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).\n\n"
        return f"{header}{section}"


def _find_changelog_insert_point(content: str) -> int:
    """Find the position to insert new changelog entry."""
    lines = content.split("\n")
    for i, line in enumerate(lines):
        # First ## header marks start of version entries
        if line.startswith("## "):
            # Return position just before this line
            pos = sum(len(lines[j]) + 1 for j in range(i))
            return pos
    return -1


def read_existing_changelog(root: str) -> Optional[str]:
    """Read existing CHANGELOG.md if it exists."""
    for name in ("CHANGELOG.md", "changelog.md", "CHANGES.md", "HISTORY.md"):
        path = os.path.join(root, name)
        if os.path.exists(path):
            try:
                with open(path, encoding="utf-8") as f:
                    return f.read()
            except (OSError, UnicodeDecodeError):
                continue
    return None


def write_changelog(root: str, content: str, filename: str = "CHANGELOG.md") -> str:
    """Write changelog content to file."""
    path = os.path.join(root, filename)
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)
    return path


def generate_release_notes(
    version: SemanticVersion,
    commits: list[ConventionalCommit],
    previous_version: Optional[SemanticVersion] = None,
) -> str:
    """Generate release notes for GitHub releases."""
    lines = []
    lines.append(f"# Release {version}")
    lines.append("")

    if previous_version:
        lines.append(f"Changes since {previous_version}:")
    lines.append("")

    # Summary stats
    features = [c for c in commits if c.type == CommitType.FEAT]
    fixes = [c for c in commits if c.type == CommitType.FIX]
    breaking = [c for c in commits if c.breaking]
    others = [c for c in commits if c.type not in (CommitType.FEAT, CommitType.FIX) and not c.breaking]

    stats = []
    if breaking:
        stats.append(f"⚠ {len(breaking)} breaking change(s)")
    if features:
        stats.append(f"✨ {len(features)} feature(s)")
    if fixes:
        stats.append(f"🐛 {len(fixes)} fix(es)")
    if others:
        stats.append(f"🔧 {len(others)} other change(s)")

    if stats:
        lines.append(" | ".join(stats))
        lines.append("")

    # Generate the changelog body
    section = generate_changelog_section(version, commits, include_header=False)
    lines.append(section)

    return "\n".join(lines)


def summarize_commits(commits: list[ConventionalCommit]) -> dict[str, int]:
    """Create a summary count by commit type."""
    summary: dict[str, int] = {}
    for commit in commits:
        key = commit.type.value
        summary[key] = summary.get(key, 0) + 1
    return dict(sorted(summary.items(), key=lambda x: x[1], reverse=True))
