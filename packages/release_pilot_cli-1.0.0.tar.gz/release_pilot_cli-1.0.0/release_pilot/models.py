"""Data models for release-pilot."""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional


class CommitType(Enum):
    """Conventional commit types."""
    FEAT = "feat"
    FIX = "fix"
    DOCS = "docs"
    STYLE = "style"
    REFACTOR = "refactor"
    PERF = "perf"
    TEST = "test"
    BUILD = "build"
    CI = "ci"
    CHORE = "chore"
    REVERT = "revert"
    BREAKING = "breaking"

    @property
    def label(self) -> str:
        """Human-readable label for changelog sections."""
        labels = {
            "feat": "Features",
            "fix": "Bug Fixes",
            "docs": "Documentation",
            "style": "Styles",
            "refactor": "Code Refactoring",
            "perf": "Performance Improvements",
            "test": "Tests",
            "build": "Build System",
            "ci": "CI/CD",
            "chore": "Chores",
            "revert": "Reverts",
            "breaking": "BREAKING CHANGES",
        }
        return labels.get(self.value, self.value.title())

    @property
    def changelog_priority(self) -> int:
        """Sort order for changelog sections (lower = shown first)."""
        order = {
            "breaking": 0,
            "feat": 1,
            "fix": 2,
            "perf": 3,
            "refactor": 4,
            "docs": 5,
            "style": 6,
            "test": 7,
            "build": 8,
            "ci": 9,
            "chore": 10,
            "revert": 11,
        }
        return order.get(self.value, 99)


class BumpType(Enum):
    """Semantic version bump types."""
    MAJOR = "major"
    MINOR = "minor"
    PATCH = "patch"
    NONE = "none"


@dataclass
class ConventionalCommit:
    """A parsed conventional commit."""
    hash: str
    short_hash: str
    type: CommitType
    scope: Optional[str]
    description: str
    body: str
    breaking: bool
    raw_message: str
    author: str
    date: str

    @property
    def display_scope(self) -> str:
        """Scope formatted for display."""
        return f"**{self.scope}**: " if self.scope else ""

    @property
    def changelog_entry(self) -> str:
        """Formatted changelog line."""
        scope = f"**{self.scope}:** " if self.scope else ""
        breaking = " **BREAKING**" if self.breaking else ""
        return f"- {scope}{self.description}{breaking} ({self.short_hash})"


# Regex for parsing conventional commits
CONVENTIONAL_COMMIT_PATTERN = re.compile(
    r"^(?P<type>feat|fix|docs|style|refactor|perf|test|build|ci|chore|revert)"
    r"(?:\((?P<scope>[^)]+)\))?"
    r"(?P<breaking>!)?"
    r":\s*(?P<description>.+)$",
    re.IGNORECASE,
)

BREAKING_CHANGE_PATTERN = re.compile(
    r"^BREAKING[ -]CHANGE:\s*(?P<description>.+)$",
    re.MULTILINE,
)


def parse_commit_message(hash: str, short_hash: str, message: str, author: str = "", date: str = "") -> Optional[ConventionalCommit]:
    """Parse a commit message into a ConventionalCommit."""
    lines = message.strip().split("\n")
    subject = lines[0].strip()
    body = "\n".join(lines[1:]).strip() if len(lines) > 1 else ""

    match = CONVENTIONAL_COMMIT_PATTERN.match(subject)
    if not match:
        return None

    commit_type_str = match.group("type").lower()
    try:
        commit_type = CommitType(commit_type_str)
    except ValueError:
        return None

    scope = match.group("scope")
    breaking_marker = match.group("breaking") == "!"
    description = match.group("description").strip()

    # Check body for BREAKING CHANGE footer
    breaking_in_body = bool(BREAKING_CHANGE_PATTERN.search(body))
    is_breaking = breaking_marker or breaking_in_body

    return ConventionalCommit(
        hash=hash,
        short_hash=short_hash,
        type=commit_type,
        scope=scope,
        description=description,
        body=body,
        breaking=is_breaking,
        raw_message=message,
        author=author,
        date=date,
    )


@dataclass
class SemanticVersion:
    """Semantic version representation."""
    major: int = 0
    minor: int = 0
    patch: int = 0
    prerelease: Optional[str] = None

    @classmethod
    def parse(cls, version_str: str) -> "SemanticVersion":
        """Parse a version string like 'v1.2.3' or '1.2.3-beta.1'."""
        cleaned = version_str.strip().lstrip("vV")
        if not cleaned:
            return cls(0, 0, 0)

        prerelease = None
        if "-" in cleaned:
            cleaned, prerelease = cleaned.split("-", 1)

        parts = cleaned.split(".")
        try:
            major = int(parts[0]) if len(parts) > 0 else 0
            minor = int(parts[1]) if len(parts) > 1 else 0
            patch = int(parts[2]) if len(parts) > 2 else 0
        except ValueError:
            return cls(0, 0, 0)

        return cls(major=major, minor=minor, patch=patch, prerelease=prerelease)

    def bump(self, bump_type: BumpType) -> "SemanticVersion":
        """Return a new version after applying the bump."""
        if bump_type == BumpType.MAJOR:
            return SemanticVersion(self.major + 1, 0, 0)
        elif bump_type == BumpType.MINOR:
            return SemanticVersion(self.major, self.minor + 1, 0)
        elif bump_type == BumpType.PATCH:
            return SemanticVersion(self.major, self.minor, self.patch + 1)
        return SemanticVersion(self.major, self.minor, self.patch, self.prerelease)

    def __str__(self) -> str:
        base = f"{self.major}.{self.minor}.{self.patch}"
        if self.prerelease:
            return f"{base}-{self.prerelease}"
        return base

    @property
    def tag(self) -> str:
        """Version as a git tag string."""
        return f"v{self}"

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, SemanticVersion):
            return NotImplemented
        return (self.major, self.minor, self.patch, self.prerelease) == (other.major, other.minor, other.patch, other.prerelease)

    def __lt__(self, other: "SemanticVersion") -> bool:
        if (self.major, self.minor, self.patch) != (other.major, other.minor, other.patch):
            return (self.major, self.minor, self.patch) < (other.major, other.minor, other.patch)
        # No prerelease > any prerelease
        if self.prerelease is None and other.prerelease is None:
            return False
        if self.prerelease is None:
            return False
        if other.prerelease is None:
            return True
        return self.prerelease < other.prerelease

    def __le__(self, other: "SemanticVersion") -> bool:
        return self == other or self < other

    def __gt__(self, other: "SemanticVersion") -> bool:
        return not self <= other

    def __ge__(self, other: "SemanticVersion") -> bool:
        return not self < other


@dataclass
class ReleaseInfo:
    """Information about a release to be created."""
    version: SemanticVersion
    previous_version: Optional[SemanticVersion]
    bump_type: BumpType
    commits: list[ConventionalCommit]
    changelog: str
    tag: str
    date: str

    @property
    def has_breaking_changes(self) -> bool:
        return any(c.breaking for c in self.commits)

    @property
    def features_count(self) -> int:
        return sum(1 for c in self.commits if c.type == CommitType.FEAT)

    @property
    def fixes_count(self) -> int:
        return sum(1 for c in self.commits if c.type == CommitType.FIX)

    @property
    def total_commits(self) -> int:
        return len(self.commits)


@dataclass
class ReleaseCheck:
    """A pre-release validation check."""
    name: str
    passed: bool
    message: str
    required: bool = True

    @property
    def status_icon(self) -> str:
        if self.passed:
            return "✓"
        return "✗" if self.required else "⚠"


@dataclass
class ReleaseChecklist:
    """Collection of pre-release checks."""
    checks: list[ReleaseCheck] = field(default_factory=list)

    @property
    def all_passed(self) -> bool:
        return all(c.passed for c in self.checks if c.required)

    @property
    def total(self) -> int:
        return len(self.checks)

    @property
    def passed_count(self) -> int:
        return sum(1 for c in self.checks if c.passed)

    @property
    def failed_required(self) -> list[ReleaseCheck]:
        return [c for c in self.checks if not c.passed and c.required]

    @property
    def warnings(self) -> list[ReleaseCheck]:
        return [c for c in self.checks if not c.passed and not c.required]


@dataclass
class VersionFileUpdate:
    """Record of a version update in a file."""
    file_path: str
    old_version: str
    new_version: str
    pattern: str
    updated: bool = False
    error: Optional[str] = None


@dataclass
class ReleaseReport:
    """Complete release report."""
    release: ReleaseInfo
    checks: ReleaseChecklist
    file_updates: list[VersionFileUpdate]
    tag_created: bool
    pushed: bool
    dry_run: bool

    @property
    def success(self) -> bool:
        if self.dry_run:
            return self.checks.all_passed
        return self.checks.all_passed and self.tag_created
