"""Release engine — orchestrates the release process."""

from __future__ import annotations

from datetime import datetime
from typing import Optional

from release_pilot.changelog import (
    generate_changelog_section,
    generate_full_changelog,
    read_existing_changelog,
    write_changelog,
)
from release_pilot.git_ops import (
    commit_files,
    create_tag,
    determine_bump_type,
    get_commits_since_tag,
    get_latest_tag,
    get_latest_version,
    push_changes,
    push_tag,
    run_preflight_checks,
)
from release_pilot.models import (
    BumpType,
    ReleaseChecklist,
    ReleaseInfo,
    ReleaseReport,
)
from release_pilot.version_manager import update_all_version_files


def prepare_release(
    bump: Optional[str] = None,
    required_branch: Optional[str] = None,
    require_clean: bool = True,
    cwd: Optional[str] = None,
) -> tuple[ReleaseInfo, ReleaseChecklist]:
    """Analyze the repo and prepare release info without making changes.

    Returns (release_info, checklist).
    """

    # Run preflight checks
    checklist = run_preflight_checks(
        required_branch=required_branch,
        require_clean=require_clean,
        cwd=cwd,
    )

    # Get current version + commits
    latest_tag = get_latest_tag(cwd)
    current_version = get_latest_version(cwd)
    commits = get_commits_since_tag(latest_tag, cwd)

    # Determine bump type
    if bump:
        try:
            bump_type = BumpType(bump.lower())
        except ValueError:
            bump_type = determine_bump_type(commits)
    else:
        bump_type = determine_bump_type(commits)

    # Calculate new version
    if bump_type == BumpType.NONE and not commits:
        new_version = current_version
    else:
        new_version = current_version.bump(bump_type)

    # Generate changelog
    date = datetime.now().strftime("%Y-%m-%d")
    changelog = generate_changelog_section(new_version, commits, date)

    release_info = ReleaseInfo(
        version=new_version,
        previous_version=current_version if latest_tag else None,
        bump_type=bump_type,
        commits=commits,
        changelog=changelog,
        tag=new_version.tag,
        date=date,
    )

    return release_info, checklist


def execute_release(
    release: ReleaseInfo,
    root: str,
    update_files: bool = True,
    update_changelog: bool = True,
    create_git_tag: bool = True,
    push: bool = False,
    dry_run: bool = False,
    version_files: Optional[list[str]] = None,
    cwd: Optional[str] = None,
) -> ReleaseReport:
    """Execute the release — update files, create tag, optionally push."""

    # Re-run checks
    checklist = run_preflight_checks(require_clean=not dry_run, cwd=cwd)
    file_updates = []
    tag_created = False
    pushed = False

    if dry_run:
        # In dry run, still do file detection but skip writes
        if update_files:
            file_updates = update_all_version_files(
                root, release.version, dry_run=True, files=version_files,
            )
        return ReleaseReport(
            release=release,
            checks=checklist,
            file_updates=file_updates,
            tag_created=False,
            pushed=False,
            dry_run=True,
        )

    # Don't proceed if required checks fail
    if not checklist.all_passed:
        return ReleaseReport(
            release=release,
            checks=checklist,
            file_updates=file_updates,
            tag_created=False,
            pushed=False,
            dry_run=False,
        )

    # Update version files
    committed_files = []
    if update_files:
        file_updates = update_all_version_files(
            root, release.version, dry_run=False, files=version_files,
        )
        committed_files.extend(
            u.file_path for u in file_updates if u.updated
        )

    # Update changelog
    if update_changelog:
        existing = read_existing_changelog(root)
        full_changelog = generate_full_changelog(
            release.version, release.commits, existing,
        )
        changelog_path = write_changelog(root, full_changelog)  # noqa: F841
        committed_files.append("CHANGELOG.md")

    # Commit version updates
    if committed_files:
        commit_msg = f"chore(release): {release.version}"
        commit_files(committed_files, commit_msg, cwd)

    # Create tag
    if create_git_tag:
        tag_msg = f"Release {release.version}"
        ok, err = create_tag(release.tag, tag_msg, cwd)
        tag_created = ok

    # Push
    if push and tag_created:
        push_changes(cwd)
        push_tag(release.tag, cwd)
        pushed = True

    return ReleaseReport(
        release=release,
        checks=checklist,
        file_updates=file_updates,
        tag_created=tag_created,
        pushed=pushed,
        dry_run=False,
    )
