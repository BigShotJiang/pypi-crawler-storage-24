"""Utilities that plot to the current Axes.
"""
import matplotlib.pyplot as plt
import matplotlib.colors as colors
import numpy as np
import matplotlib as mpl
from typing import overload

from .ofig import ensure_axes_dimension

from matplotlib.typing import ColorType

from typing import Any, Self
import math
from numpy.typing import ArrayLike

from typing import Optional, Sequence, Callable

from scipy.spatial import ConvexHull, distance  # type: ignore[import-untyped]

from matplotlib.patches import FancyArrowPatch

from mpl_toolkits.mplot3d.art3d import Poly3DCollection  # type: ignore[import-untyped] # noqa: E501
from mpl_toolkits.mplot3d.axes3d import Axes3D  # type: ignore[import-untyped]
from mpl_toolkits.mplot3d.art3d import Line3DCollection
from mpl_toolkits.mplot3d.proj3d import proj_transform  # type: ignore[import-untyped] # noqa: E501

from numpy import ndarray

from matplotlib.patches import Patch
from matplotlib.text import Text
from matplotlib.legend import Legend

type Array1D = np.ndarray[tuple[Any],
                          np.dtype[np.float64]]
type Array2D = np.ndarray[tuple[Any, Any],
                          np.dtype[np.float64]]
type Array3D = np.ndarray[tuple[Any, Any, Any],
                          np.dtype[np.float64]]

type Sequence1D = Sequence[float]
type Sequence2D = Sequence[Sequence[float]]
type Sequence3D = Sequence[Sequence[Sequence[float]]]

type Vec1D = Array1D | Sequence1D
type Vec2D = Array2D | Sequence2D
type Vec3D = Array3D | Sequence3D

type Point2D = Vec1D
type Point3D = Vec1D

type Points2D = Vec2D
type Points3D = Vec2D

FILL_CONFIG: dict[str, Any] = {"alpha": 0.5}
EDGE_CONFIG: dict[str, Any] = {"color": "black", "alpha": 1}
NODE_CONFIG: dict[str, Any] = {"color": "black", "alpha": 0.5}
CONTOUR_CMAP: str = "viridis"


def heatmap(data: Vec2D,
            xlabels: Optional[Sequence[str]] = None,
            ylabels: Optional[Sequence[str]] = None) -> None:
    """Plot a matrix to the current active axis as a heatmap.

    Args:
        data: A Numpy matrix.
        xlabels: labels for cells along the x axis.
        ylabels: labels for cells along the x axis.

    Effects:
        Plot at the current active axis.
    """
    if not isinstance(data, ndarray):
        # If the input is not an numpy array, attempt to cast it into one.
        data = np.array(data)

    # Configure the size of the plot to accommodate the size of each cell
    plt.rcParams["figure.figsize"] = [len(data) * math.sqrt(len(data)),
                                      len(data[0]) * math.sqrt(len(data[0]))]

    xlabels = xlabels if (xlabels is not None)\
        else ["X" + str(i) for i, _ in enumerate(data[0])]
    ylabels = ylabels if (ylabels is not None)\
        else ["Y" + str(i) for i, _ in enumerate(data)]

    ax = plt.gca()

    ensure_axes_dimension(ax, 2)
    ax.imshow(data, cmap="Greys")

    ax.set_xticks(np.arange(len(xlabels)), labels=xlabels)
    ax.set_yticks(np.arange(len(ylabels)), labels=ylabels)

    plt.setp(ax.get_xticklabels(),
             rotation=45,
             ha="right",
             rotation_mode="anchor")

    max_cell_value = data.max()
    min_cell_value = data.min()

    for i in range(len(ylabels)):
        for j in range(len(xlabels)):
            cell_value_scale = max_cell_value - min_cell_value
            ratio = (data[i, j] - min_cell_value) / cell_value_scale
            ax.text(j, i, "{:.2f}".format(data[i, j]),
                    ha="center",
                    va="center",
                    color="w" if ratio > .6 else "k")

    my_fig = ax.get_figure()
    if (my_fig is not None):
        my_fig.tight_layout()  # type: ignore[union-attr]
        # (When called on an `Axes`, ->get_figure(.) always returns a `Figure`)


def chull(shape: Points2D | Points3D) -> None:
    """Plot a convex hull to the current active axes.

    Detect the shape of points by inspecting the first in the sequence.

    Args:
        shape: A sequence of 2- or 3-dimensional points.

    Effects:
        Plot at the current active axis.
    """
    # The checker only checks if the first element has the correct dimension.
    # This is bad, but performant.
    match len(shape[0]):
        case 2:
            _chull_2d(np.array(shape))  # type: ignore[arg-type]
        case 3:
            _chull_3d(np.array(shape))  # type: ignore
        case _:
            raise ValueError("Input must be either 2 or 3")


def _chull_3d(shape: Array2D) -> None:
    ax: Axes3D = plt.gca()  # type: ignore[no-any-unimported]
    ensure_axes_dimension(ax, 3)

    hull = ConvexHull(shape)
    for s in hull.simplices:
        tri = Poly3DCollection([shape[s]])

        if "alpha" in FILL_CONFIG:
            tri.set_alpha(FILL_CONFIG["alpha"])
        if "color" in FILL_CONFIG:
            tri.set_color(FILL_CONFIG["color"])

        tri.set_edgecolor('none')
        ax.add_collection3d(tri)
        edges = []
        if distance.euclidean(shape[s[0]], shape[s[1]])\
                < distance.euclidean(shape[s[1]], shape[s[2]]):
            edges.append((s[0], s[1]))
            if distance.euclidean(shape[s[1]], shape[s[2]])\
                    < distance.euclidean(shape[s[2]], shape[s[0]]):
                edges.append((s[1], s[2]))
            else:
                edges.append((s[2], s[0]))
        else:
            edges.append((s[1], s[2]))
            if distance.euclidean(shape[s[0]], shape[s[1]]) <\
                    distance.euclidean(shape[s[2]], shape[s[0]]):
                edges.append((s[0], s[1]))
            else:
                edges.append((s[2], s[0]))
        for v0, v1 in edges:
            ax.plot(xs=shape[[v0, v1], 0],
                    ys=shape[[v0, v1], 1],
                    zs=shape[[v0, v1], 2],
                    **EDGE_CONFIG)

    ax.scatter(shape[:, 0],
               shape[:, 1],
               shape[:, 2],
               marker='o',
               **NODE_CONFIG)


def _chull_2d(points: Array2D) -> None:
    ax = plt.gca()
    ensure_axes_dimension(ax, 2)
    hull = ConvexHull(points)
    ax.plot(points[:, 0], points[:, 1], 'o', **NODE_CONFIG)  # type: ignore[arg-type] # noqa: E501
    for simplex in hull.simplices:
        ax.plot(points[simplex, 0],
                points[simplex, 1],
                **EDGE_CONFIG)  # type: ignore[arg-type]

    ax.fill(points[hull.vertices, 0],
            points[hull.vertices, 1],
            lw=2,
            **FILL_CONFIG)


class BigArrow(FancyArrowPatch):
    """An 2- or 3-dimensional arrow.

    :meta private:
    """
    def __init__(self,
                 start: Vec1D,
                 end: Vec1D,
                 *args: Any,
                 **kwargs: Any):
        default_styles = {
            "mutation_scale": 30,
            "arrowstyle": "-|>",
            "linestyle": "--"
        }
        # start[i] for example can be either a number or a vector.
        super().__init__((start[0], start[1]),  # type: ignore[arg-type]
                         (end[0], end[1]),
                         *args,
                         **(kwargs | default_styles))
        # Note that two copies of `start` and `end` are preserved:
        #   One copy is passed to ->_posA_posB of the parent class; this copy
        #       is used in `draw`.
        #   the other copy is passed to ->start and ->end of this class; this
        #       copt is used in do_3d_projections.
        self.start = start
        self.end = end

    def draw(self: Self, renderer: Any) -> None:
        super().draw(renderer)

    def do_3d_projection(self: Self, renderer: Any = None) -> Any:
        # The reference
        #   https://github.com/matplotlib/matplotlib/blob/v3.8.2/lib/
        #       mpl_toolkits/mplot3d/art3d.py#L998-L1065
        #   appears to return np.min(tzs).
        # Removing it does not seem to change anything. Still, just to be safe.
        if self.axes is None or not isinstance(self.axes, Axes3D):
            raise Exception("Rendered without axes")
        else:
            txs, tys, tzs = proj_transform(*zip(self.start, self.end),
                                           self.axes.M)
            self.set_positions((txs[0], tys[0]), (txs[1], tys[1]))
            return np.min(tzs)


@overload
def arrow(start: Point2D, end: Point2D,
          *args: Any,
          **kwargs: Any) -> None:
    pass


# Suppress the error. This overload will never be matched
#   since :class:`Point3D` and :class:`Point2D` alias
#   the same thing. The overload is there for the user's knowledge.
@overload
def arrow(start: Point3D,  # type: ignore[overload-cannot-match]
          end: Point3D,
          *args: Any,
          **kwargs: Any) -> None:
    pass


def arrow(start: Point2D | Point3D,
          end: Point2D | Point3D,
          *args: Any,
          **kwargs: Any) -> None:
    '''Plot an arrow to the current Axes or Axes3D.

    Args:
        start: The starting point of the arrow.
        end: The ending point of the arrow.

    '''
    ax = plt.gca()
    # Type checking `ax` is necessary, since the arrow
    #       class can handle the difference.
    #   Plotting to 2D (projection='rectilinear') Axes calls `draw`.
    #   Plotting to 3D (projection='3d') calls do_3d_projection.
    #   Still, this function might not work for other projections.
    arrow = BigArrow(start, end, *args, **kwargs)
    ax.add_artist(arrow)


def plot(fun: Callable[[float], float],
         x_range: tuple[float, float],
         density: int = 1000,
         *args: ArrayLike,
         **kwargs: Any) -> None:
    '''Plot a contour map to the current Axes or Axes3D.

    Args:
        fun: The function to plot.
        x_range: A tuple of the beginning and end of the x axis.
        density: Number of data point to plot. These points are
            evenly spaced over (:arg:`x_range` * :arg:`y_range`).
    '''
    ax = plt.gca()
    x_max: float = max(x_range)
    x_min: float = min(x_range)
    xs, ys = _make_ys(fun=fun,
                      x_range=(x_min, x_max),
                      density=density)
    ax.plot(xs, ys, *args, **kwargs)


def _make_zs(fun: Callable[[float, float], float],
             x_range: tuple[float, float],
             y_range: tuple[float, float],
             density: int = 100,) -> tuple[ndarray, ndarray, ndarray]:

    x_max: float = max(x_range)
    x_min: float = min(x_range)
    y_max: float = max(y_range)
    y_min: float = min(y_range)

    xs = np.arange(x_min, x_max, step=(x_max - x_min) / density)
    ys = np.arange(y_min, y_max, step=(y_max - y_min) / density)

    xs, ys = np.meshgrid(xs, ys)
    zs = np.vectorize(fun)(xs, ys)

    # This code is for functions that cannot be properly vectorised.
    # zs = np.empty(shape=(len(ys), len(xs)))
    # for i, x in enumerate(xs):
    #     for j, y in enumerate(ys):
    #         zs[j][i] = fun(x, y)

    return (xs, ys, zs)


def contour(fun: Callable[[float, float], float],
            x_range: tuple[float, float],
            y_range: tuple[float, float],
            density: int = 100,
            levels: int = 50,
            cmap: str = CONTOUR_CMAP,
            colorbar: bool = True,
            alpha: float = 0.5) -> None:
    '''Plot a contour map to the current Axes3D.

    Args:
        fun: The function to plot.
        x_range: A tuple of the beginning and end of the x axis.
        y_range: A tuple of the beginning and end of the y axis.
        density: Number of point to plot. These points are
            evenly spaced over (:arg:`x_range` * :arg:`y_range`).
        levels: The number of contour lines.
        cmap: The colour map used by the contour map.
        colorbar: If True, draw the colour bar.
    '''
    ax = plt.gca()
    xs, ys, zs = _make_zs(fun, x_range, y_range, density)
    cs = ax.contour(xs, ys, zs, levels=levels, cmap=cmap,
                    norm=colors.Normalize(vmin=zs.min(),
                                          vmax=zs.max()),
                    alpha=alpha)

    current_figure = ax.get_figure()
    if colorbar and current_figure is not None:
        current_figure.colorbar(cs)


def wireframe(fun:  # type: ignore[no-any-unimported]
              # Reason: I'm not sure which import is causing this.
              Callable[[float, float], float],
              x_range: tuple[float, float],
              y_range: tuple[float, float],
              density: int = 100,
              cmap: str = CONTOUR_CMAP,
              alpha: float = 0.9,
              **kwargs: dict[str, Any]) -> Line3DCollection:
    '''Plot a wireframe map to the current Axes or Axes3D.

    Args:
        fun: The function to plot.
        x_range: A tuple of the beginning and end of the x axis.
        y_range: A tuple of the beginning and end of the y axis.
        density: Number of point to plot. These points are
            evenly spaced over :arg:`x_range`.
        cmap: The colour map used by the contour map.
        alpha: Alpha value (transparency) of the frame.
    '''
    ax: Axes3D = plt.gca()  # type: ignore[no-any-unimported]
    xs, ys, zs = _make_zs(fun, x_range, y_range, density)
    return ax.plot_wireframe(xs, ys, zs,
                             cmap=cmap,
                             norm=colors.Normalize(vmin=zs.min(),
                                                   vmax=zs.max()),
                             alpha=alpha,
                             **kwargs)


def surface(fun: Callable[[float, float], float],  # type: ignore[no-any-unimported] # noqa: E501
            x_range: tuple[float, float],
            y_range: tuple[float, float],
            density: int = 100,
            cmap: str = CONTOUR_CMAP,
            colorbar: bool = True,
            alpha: float = 0.9,) -> Line3DCollection:
    ax: Axes3D = plt.gca()  # type: ignore[no-any-unimported]
    xs, ys, zs = _make_zs(fun, x_range, y_range, density)
    cs = ax.plot_surface(xs, ys, zs,
                         cmap=cmap,
                         norm=colors.Normalize(vmin=zs.min(), vmax=zs.max()),
                         alpha=alpha,
                         rstride=1,
                         cstride=1,
                         edgecolor='none')

    if colorbar:
        ax.get_figure().colorbar(cs)
    return cs


def _make_ys(fun: Callable[[float], float],
             x_range: tuple[float, float],
             density: int = 20) -> tuple[Vec1D, Vec1D]:
    x_max: float = max(x_range)
    x_min: float = min(x_range)
    xs = np.linspace(x_min, x_max, num=density, dtype=np.float64)
    ys = np.array([fun(x) for x in xs])
    return xs, ys


def stems(fun: Callable[[float], float],
          x_range: tuple[float, float],
          density: int = 30,
          plot_links: bool = False,
          *,
          edge_args: dict[str, Any] = {},
          node_args: dict[str, Any] = {},
          fill_args: dict[str, Any] = {}) -> None:
    """PLot a stem plot to the current Axes.

    Args:
        x_range: A tuple of the beginning and end of the x axis.
        density: Number of point to plot. These points are
            evenly spaced over :arg:`x_range`.
        plot_links: If ``True``, then plot links.
    """

    xs, ys = _make_ys(fun, x_range, density)

    stem(xs=xs,
         ys=ys,
         plot_links=plot_links,
         edge_args=edge_args,
         node_args=node_args,
         fill_args=fill_args)


def stem(xs: Vec1D, ys: Vec1D,
         plot_links: bool = False,
         *,
         edge_args: dict[str, Any] = {},
         node_args: dict[str, Any] = {},
         fill_args: dict[str, Any] = {}) -> None:
    """Plot a stem plot to the current Axes.
    Similar to :meth:`Axes.stem`, but offers more control over style.
    """

    edge_args = EDGE_CONFIG | edge_args
    # The default node style now borrows from edge style.
    node_args = node_args
    fill_args = FILL_CONFIG | fill_args

    ax = plt.gca()

    # Incorporate alpha into edge color. Because `->scatter(.)` does not allow
    #   alpha to be specified for `edgecolors`, this is necessary.

    # Suppressing this error because `.get` is maltyped to return
    #   (Any | None). This is not very helpful.
    edge_color: Optional[ColorType]\
        = edge_args.get("color")  # type: ignore[assignment]
    edge_alpha: Optional[float]\
        = edge_args.get("alpha")  # type: ignore[assignment]
    if edge_color is not None and edge_alpha is not None:
        line_color = mpl.colors.colorConverter.to_rgba(
            edge_color,
            edge_alpha
        )

    old_x = old_y = None

    if (plot_links):
        ax.plot((min(xs), max(xs)), (0, 0),
                color=line_color,
                linewidth=1,
                zorder=-1)

    for (x, y) in zip(xs, ys):
        ax.plot([x, x], [0, y],
                zorder=0,
                linewidth=1,
                **edge_args)

        if (plot_links):
            if old_x is not None and old_y is not None:
                #Hull it
                ax.plot((old_x, x), (old_y, y), color="#696969", linewidth=0.5,
                        zorder=-1)
                ax.fill_between((old_x, x), (old_y, y),
                                zorder=-2,
                                color="#F5F5F5", **fill_args)
        old_x = x
        old_y = y

    ax.scatter(xs, ys, zorder=4,
               facecolor=fill_args.get("color", "white"),
               edgecolors=line_color,
               linewidth=1.5,
               **node_args)


#: Legacy alias for :meth:`stem`.
shatter = stem


def _add_patch_to_current_legend(patch: Patch, label: str) -> None:
    ax = plt.gca()
    legend = [c for c in ax.get_children() if isinstance(c, Legend)][0]

    handles = legend.legend_handles
    labels = legend.texts

    handles.append(patch)
    labels.append(Text(0, 0, label))

    plt.legend(handles)


def patch(facecolor: ColorType,
          label: str,
          alpha: float = 1,
          width: float = 1,
          height: float = 0.8) -> None:
    """Add and label a rectangular colour patch to the current
    plot.

    Args:
        label: Label to the patch.
        alpha: Alpha value of the patch.
        width: Width of the patch.
        height: Height of the patch.
    """
    new_patch = Patch(facecolor=facecolor,
                      edgecolor=facecolor,
                      label=label,
                      alpha=alpha)

    if plt.gca().get_legend() is None:
        plt.gca().legend(handles=[new_patch],
                         handlelength=width,
                         handleheight=height,
                         loc="lower left")
    else:
        _add_patch_to_current_legend(Patch(facecolor=facecolor,
                                           edgecolor=facecolor,
                                           label=label,
                                           alpha=alpha),
                                     label=label)
