"""Test functions and matrices. Examples are
the Himmelblau function and the unit cube.
"""
from numpy import array


def rosenbrock(*args: float) -> float:
    """Rosenbrock function.

    Multi-dimensional test function where the global minimum is located
    inside a flat valley.
    """
    result: float = 0
    for i in range(len(args) - 1):
        result += 100 * (args[i + 1] - args[i]**2)**2 + (1 - args[i])**2
    return result


def himmelblau(x: float, y: float) -> float:
    """Himmelblau function.

    2-dimensional test function with several minimum.
    """
    return (x ** 2 + y - 11) ** 2 + (x + y ** 2 - 7) ** 2


#! Immutable 2-dimensional unit square.
unit_square = array(
    [[0, 0],
     [0, 1],
     [1, 0],
     [1, 1]]
)
unit_square.flags.writeable = False


#! Immutable 3-dimensional unit cube. Fancy!
unit_cube = array(
    [[0, 0, 0],
     [1, 0, 0],
     [0, 1, 0],
     [0, 0, 1],
     [1, 1, 0],
     [0, 1, 1],
     [1, 0, 1],
     [1, 1, 1],]
)
unit_cube.flags.writeable = False
