"""Tests for the send_email skill."""

import os
from unittest.mock import MagicMock, patch

import pytest

from fliiq.runtime.package_data import bundled_skills_dir
from fliiq.runtime.skills.base import SkillBase

SKILLS_DIR = str(bundled_skills_dir())


def _load_skill() -> SkillBase:
    return SkillBase(os.path.join(SKILLS_DIR, "send_email"))


def test_send_email_schema():
    skill = _load_skill()
    schema = skill.schema()
    assert schema["name"] == "send_email"
    props = schema["parameters"]["properties"]
    assert "to" in props
    assert "subject" in props
    assert "body" in props
    assert "cc" in props
    assert "bcc" in props
    assert "in_reply_to" in props
    assert "references" in props
    assert set(schema["parameters"]["required"]) == {"to", "subject", "body"}


async def test_send_email_missing_gmail_address(monkeypatch):
    monkeypatch.delenv("GMAIL_ADDRESS", raising=False)
    monkeypatch.delenv("GMAIL_APP_PASSWORD", raising=False)
    skill = _load_skill()
    with pytest.raises(ValueError, match="GMAIL_ADDRESS"):
        await skill.execute({"to": "a@b.com", "subject": "Hi", "body": "Test"})


async def test_send_email_missing_app_password(monkeypatch):
    monkeypatch.setenv("GMAIL_ADDRESS", "test@gmail.com")
    monkeypatch.delenv("GMAIL_APP_PASSWORD", raising=False)
    skill = _load_skill()
    with pytest.raises(ValueError, match="GMAIL_APP_PASSWORD"):
        await skill.execute({"to": "a@b.com", "subject": "Hi", "body": "Test"})


async def test_send_email_no_recipients(monkeypatch):
    monkeypatch.setenv("GMAIL_ADDRESS", "test@gmail.com")
    monkeypatch.setenv("GMAIL_APP_PASSWORD", "fake-password")
    skill = _load_skill()
    with pytest.raises(ValueError, match="No valid recipient"):
        await skill.execute({"to": "  ", "subject": "Hi", "body": "Test"})


async def test_send_email_success(monkeypatch):
    monkeypatch.setenv("GMAIL_ADDRESS", "test@gmail.com")
    monkeypatch.setenv("GMAIL_APP_PASSWORD", "fake-password")
    skill = _load_skill()

    with patch("smtplib.SMTP") as mock_smtp:
        mock_server = MagicMock()
        mock_smtp.return_value.__enter__ = MagicMock(return_value=mock_server)
        mock_smtp.return_value.__exit__ = MagicMock(return_value=False)
        result = await skill.execute({"to": "a@b.com", "subject": "Hi", "body": "Test"})

    assert "sent" in result["status"].lower()
    assert "a@b.com" in result["status"]


async def test_send_email_multiple_recipients(monkeypatch):
    monkeypatch.setenv("GMAIL_ADDRESS", "test@gmail.com")
    monkeypatch.setenv("GMAIL_APP_PASSWORD", "fake-password")
    skill = _load_skill()

    with patch("smtplib.SMTP") as mock_smtp:
        mock_server = MagicMock()
        mock_smtp.return_value.__enter__ = MagicMock(return_value=mock_server)
        mock_smtp.return_value.__exit__ = MagicMock(return_value=False)
        result = await skill.execute({
            "to": "a@b.com, c@d.com",
            "subject": "Hi",
            "body": "Test",
        })

    assert "a@b.com" in result["status"]
    assert "c@d.com" in result["status"]


async def test_send_email_env_override(monkeypatch):
    """Env var override: FLIIQ_GMAIL_* env vars configure credentials."""
    monkeypatch.setenv("FLIIQ_GMAIL_ADDRESS", "work@gmail.com")
    monkeypatch.setenv("FLIIQ_GMAIL_APP_PASSWORD", "work-pass")
    skill = _load_skill()

    with patch("smtplib.SMTP") as mock_smtp:
        mock_server = MagicMock()
        mock_smtp.return_value.__enter__ = MagicMock(return_value=mock_server)
        mock_smtp.return_value.__exit__ = MagicMock(return_value=False)
        result = await skill.execute({
            "to": "a@b.com",
            "subject": "Hi",
            "body": "Test",
        })

    assert "sent" in result["status"].lower()
    mock_server.login.assert_called_once_with("work@gmail.com", "work-pass")


async def test_send_email_with_threading(monkeypatch):
    """Threading headers are set on outbound email when provided."""
    monkeypatch.setenv("GMAIL_ADDRESS", "test@gmail.com")
    monkeypatch.setenv("GMAIL_APP_PASSWORD", "fake-password")
    skill = _load_skill()

    sent_msg = None

    def capture_sendmail(sender, recipients, msg_str):
        nonlocal sent_msg
        import email
        sent_msg = email.message_from_string(msg_str)

    with patch("smtplib.SMTP") as mock_smtp:
        mock_server = MagicMock()
        mock_server.sendmail.side_effect = capture_sendmail
        mock_smtp.return_value.__enter__ = MagicMock(return_value=mock_server)
        mock_smtp.return_value.__exit__ = MagicMock(return_value=False)
        await skill.execute({
            "to": "alice@example.com",
            "subject": "Re: Project",
            "body": "Sounds good",
            "in_reply_to": "<msg-001@mail.gmail.com>",
            "references": "<msg-000@mail.gmail.com> <msg-001@mail.gmail.com>",
        })

    assert sent_msg["In-Reply-To"] == "<msg-001@mail.gmail.com>"
    assert sent_msg["References"] == "<msg-000@mail.gmail.com> <msg-001@mail.gmail.com>"


async def test_send_email_without_threading(monkeypatch):
    """No threading headers when not provided."""
    monkeypatch.setenv("GMAIL_ADDRESS", "test@gmail.com")
    monkeypatch.setenv("GMAIL_APP_PASSWORD", "fake-password")
    skill = _load_skill()

    sent_msg = None

    def capture_sendmail(sender, recipients, msg_str):
        nonlocal sent_msg
        import email
        sent_msg = email.message_from_string(msg_str)

    with patch("smtplib.SMTP") as mock_smtp:
        mock_server = MagicMock()
        mock_server.sendmail.side_effect = capture_sendmail
        mock_smtp.return_value.__enter__ = MagicMock(return_value=mock_server)
        mock_smtp.return_value.__exit__ = MagicMock(return_value=False)
        await skill.execute({
            "to": "alice@example.com",
            "subject": "Hello",
            "body": "Hi there",
        })

    assert sent_msg.get("In-Reply-To") is None
    assert sent_msg.get("References") is None


async def test_send_email_with_cc(monkeypatch):
    """CC recipients get Cc header and are included in sendmail."""
    monkeypatch.setenv("GMAIL_ADDRESS", "test@gmail.com")
    monkeypatch.setenv("GMAIL_APP_PASSWORD", "fake-password")
    skill = _load_skill()

    sent_msg = None
    sent_recipients = None

    def capture_sendmail(sender, recipients, msg_str):
        nonlocal sent_msg, sent_recipients
        import email
        sent_msg = email.message_from_string(msg_str)
        sent_recipients = recipients

    with patch("smtplib.SMTP") as mock_smtp:
        mock_server = MagicMock()
        mock_server.sendmail.side_effect = capture_sendmail
        mock_smtp.return_value.__enter__ = MagicMock(return_value=mock_server)
        mock_smtp.return_value.__exit__ = MagicMock(return_value=False)
        await skill.execute({
            "to": "alice@example.com",
            "subject": "Hello",
            "body": "Hi",
            "cc": "bob@example.com, carol@example.com",
        })

    assert sent_msg["Cc"] == "bob@example.com, carol@example.com"
    assert "alice@example.com" in sent_recipients
    assert "bob@example.com" in sent_recipients
    assert "carol@example.com" in sent_recipients


async def test_send_email_with_bcc(monkeypatch):
    """BCC recipients are in sendmail recipients but NOT in message headers."""
    monkeypatch.setenv("GMAIL_ADDRESS", "test@gmail.com")
    monkeypatch.setenv("GMAIL_APP_PASSWORD", "fake-password")
    skill = _load_skill()

    sent_msg = None
    sent_recipients = None

    def capture_sendmail(sender, recipients, msg_str):
        nonlocal sent_msg, sent_recipients
        import email
        sent_msg = email.message_from_string(msg_str)
        sent_recipients = recipients

    with patch("smtplib.SMTP") as mock_smtp:
        mock_server = MagicMock()
        mock_server.sendmail.side_effect = capture_sendmail
        mock_smtp.return_value.__enter__ = MagicMock(return_value=mock_server)
        mock_smtp.return_value.__exit__ = MagicMock(return_value=False)
        await skill.execute({
            "to": "alice@example.com",
            "subject": "Hello",
            "body": "Hi",
            "bcc": "secret@example.com",
        })

    # BCC must NOT appear in headers
    assert sent_msg.get("Bcc") is None
    # But BCC recipient must be in the SMTP envelope
    assert "alice@example.com" in sent_recipients
    assert "secret@example.com" in sent_recipients
