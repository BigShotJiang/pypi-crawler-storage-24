---
name: receive_emails
description: "Fetch emails via Gmail IMAP. Uses OAuth (via `fliiq google auth`) or app password fallback."
---

Fetch emails from Gmail via IMAP4_SSL. Returns up to max_results emails with sender, subject, date, and body text.

Body extraction prefers plain text; falls back to HTML with tags stripped. Body truncated to 4000 chars.

Each email includes an `id` field (IMAP UID) that can be passed to `mark_email_read` to prevent it appearing in future calls.

Each email includes `message_id`, `in_reply_to`, `references`, `to`, and `cc` headers for email threading. When replying to an email, pass its `message_id` as the `in_reply_to` parameter to `send_email`, and pass `references` with the `message_id` appended.

Setup: Run `fliiq google auth` for OAuth access (recommended). Alternatively, set GMAIL_ADDRESS and GMAIL_APP_PASSWORD in .env as fallback. IMAP must be enabled in Gmail settings.
