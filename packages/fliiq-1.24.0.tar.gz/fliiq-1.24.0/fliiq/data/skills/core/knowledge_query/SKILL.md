---
name: knowledge_query
description: "Search the institutional knowledge base by keyword, domain, file, or tags."
---

Use this tool to retrieve knowledge records from the persistent knowledge base.

**Search modes:**
- `query` — keyword search across all record fields
- `domain` — filter by domain tag (e.g., "coding", "business")
- `file` — find records anchored to a specific file (includes drift detection)
- `tags` — filter by tags

All filters are optional and can be combined. Results are ranked by relevance and confidence.
