---
name: knowledge_save
description: "Save a structured knowledge record (decision, constraint, heuristic, or domain rule)."
---

Use this tool to persist institutional knowledge as a structured record.

**Record types:**
- `decision` — a choice that was made, with rationale
- `constraint` — a rule or limitation that must be respected
- `heuristic` — a learned rule of thumb or best practice
- `domain_rule` — a domain-specific rule (regulatory, business, etc.)

**Source types:**
- `human_in_loop` — knowledge provided by the user during conversation
- `agent_decision` — a significant decision made by the agent
- `agent_inference` — knowledge inferred by the agent from context

**Code anchoring (optional):** Set `anchor_file` and `anchor_lines` to bind knowledge to specific code. The system computes a content hash for drift detection.

Before saving user-provided knowledge, briefly restate your understanding for confirmation.
