---
name: send_email
description: "Send an email via Gmail SMTP. Uses OAuth (via `fliiq google auth`) or app password fallback."
---

Send an email to one or more recipients via Gmail SMTP. Supports plain text body and subject line.

Setup: Run `fliiq google auth` for OAuth access (recommended). Alternatively, set GMAIL_ADDRESS and GMAIL_APP_PASSWORD in .env as fallback.

The "to" field accepts a single email or comma-separated list for multiple recipients. Supports `cc` and `bcc` for additional recipients.

To reply in an existing email thread, pass `in_reply_to` and `references` from the original email (obtained via `receive_emails`). Use "Re: <original subject>" as the subject. Omit these fields for new standalone emails.
