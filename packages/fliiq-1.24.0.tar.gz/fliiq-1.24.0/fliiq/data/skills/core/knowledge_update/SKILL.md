---
name: knowledge_update
description: "Update or expire a knowledge record by ID."
---

Use this tool to modify an existing knowledge record. You can:
- Update confidence, decision text, or rationale
- Add or replace tags
- Mark a record as expired (soft delete)

Requires the record ID (shown in knowledge_query results).
