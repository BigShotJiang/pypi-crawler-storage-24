"""Update or expire a knowledge record."""

from fliiq.runtime.knowledge.store import KnowledgeStore


async def handler(params: dict) -> dict:
    """Update fields on an existing knowledge record."""
    store = KnowledgeStore.from_fliiq_dir()
    record_id = params["id"]

    updates = {}
    for field in ("confidence", "decision", "rationale", "tags", "expired"):
        if field in params:
            updates[field] = params[field]

    if not updates:
        return {"result": "No fields to update.", "updated": False}

    record = store.update(record_id, updates)
    if record is None:
        return {"result": f"Record '{record_id}' not found.", "updated": False}

    action = "expired" if params.get("expired") else "updated"
    return {"result": f"Record {record_id} {action}.", "updated": True}
