"""Institutional Knowledge System — structured decision rationale capture and retrieval."""
