"""Persistent message log for Telegram sessions — bridges job→listener context gap."""

import json
from datetime import datetime, timezone
from pathlib import Path


class TelegramSessionStore:
    """Append-only JSONL log per chat for session recovery and cross-path context."""

    def __init__(self, fliiq_dir: Path):
        self._dir = fliiq_dir / "telegram_sessions"
        self._dir.mkdir(parents=True, exist_ok=True)

    def _log_path(self, chat_id: int, thread_id: int | None = None) -> Path:
        if thread_id:
            return self._dir / f"{chat_id}_thread_{thread_id}.jsonl"
        return self._dir / f"{chat_id}.jsonl"

    def log_message(
        self,
        chat_id: int,
        role: str,
        text: str,
        thread_id: int | None = None,
    ) -> None:
        """Append a message to the chat's persistent log."""
        entry = {
            "role": role,
            "text": text,
            "ts": datetime.now(timezone.utc).isoformat(),
        }
        path = self._log_path(chat_id, thread_id)
        with open(path, "a") as f:
            f.write(json.dumps(entry) + "\n")

    def load_recent(
        self,
        chat_id: int,
        thread_id: int | None = None,
        max_messages: int = 20,
        max_age_hours: int = 24,
    ) -> list[dict]:
        """Load recent messages as OpenAI-format message dicts.

        Returns up to *max_messages* within the last *max_age_hours*.
        Inbound (user) messages are wrapped in <external_message> tags.
        """
        path = self._log_path(chat_id, thread_id)
        if not path.exists():
            return []

        cutoff = datetime.now(timezone.utc).timestamp() - (max_age_hours * 3600)
        entries: list[dict] = []

        with open(path) as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    entry = json.loads(line)
                    ts = datetime.fromisoformat(entry["ts"]).timestamp()
                    if ts >= cutoff:
                        entries.append(entry)
                except (json.JSONDecodeError, KeyError, ValueError):
                    continue

        recent = entries[-max_messages:] if entries else []

        messages: list[dict] = []
        for entry in recent:
            role = entry["role"]
            text = entry["text"]
            if role == "user":
                thread_attr = f' message_thread_id="{thread_id}"' if thread_id else ""
                content = (
                    f'<external_message source="telegram" chat_id="{chat_id}"{thread_attr}>'
                    f"\n{text}\n</external_message>"
                )
                messages.append({"role": "user", "content": content})
            else:
                messages.append({"role": "assistant", "content": text})

        return messages
