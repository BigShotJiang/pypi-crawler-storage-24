import typer
from rich.console import Console
from importlib.metadata import version as _pkg_version
from promptun.commands import auth, sync

app = typer.Typer(
    name="promptun",
    help="PromptHub CLI - Git for Prompts",
    add_completion=False,
    no_args_is_help=True
)

# Auth commands
app.command(name="login")(auth.login)
app.command(name="logout")(auth.logout)
app.command(name="whoami")(auth.whoami)

# Sync commands
app.command(name="init")(sync.init)
app.command(name="push")(sync.push)
app.command(name="pull")(sync.pull)
app.command(name="clone")(sync.clone)
app.command(name="log")(sync.log)
app.command(name="revert")(sync.revert)
app.command(name="rm")(sync.rm)
app.command(name="history")(sync.history)

@app.command()
def version():
    """
    Show CLI version.
    """
    console = Console()
    console.print(f"Promptun CLI v{_pkg_version('promptun-cli')}")

if __name__ == "__main__":
    app()
