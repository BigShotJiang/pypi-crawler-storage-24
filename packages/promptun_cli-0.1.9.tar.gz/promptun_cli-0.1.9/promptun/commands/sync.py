import typer
import yaml
import glob
import os
from pathlib import Path
from rich.console import Console
from rich.table import Table
import requests
from promptun import config, utils

console = Console()
app = typer.Typer(help="Manage prompt synchronization")


@app.command()
def init(name: str = typer.Argument(..., help="Project slug/name")):
    """
    Initialize a new PromptHub project in the current directory.
    """
    if (Path('.') / 'prompthub.yaml').exists():
        console.print("[red]prompthub.yaml already exists![/red]")
        raise typer.Exit(1)

    utils.create_project_config(name)
    console.print(f"[green]Initialized project '{name}' in prompthub.yaml[/green]")
    console.print("Add .prompt.md files and run 'promptun push'.")
    console.print("Place shared files in the [cyan]assets/[/cyan] folder and reference them in your frontmatter.")


@app.command()
def push(
    message: str = typer.Option(None, "--message", "-m", help="Commit message (changelog)"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Validate without sending to server")
):
    """
    Upload prompts to PromptHub.
    """
    # 1. Load Config
    project_conf = utils.get_project_config()
    if not project_conf:
        console.print("[red]No prompthub.yaml found. Run 'promptun init <name>' first.[/red]")
        raise typer.Exit(1)

    collection_slug = project_conf.get('project')
    base_dir = Path('.')  # Collection root (where prompthub.yaml lives)

    # 2. Find Files
    patterns = project_conf.get('include', ['**/*.prompt.md'])
    exclude_patterns = project_conf.get('exclude', ['node_modules/**', '.git/**', 'assets/**'])
    files = []
    for pattern in patterns:
        found = glob.glob(pattern, recursive=True)
        # Apply exclude patterns
        for f_path in found:
            excluded = any(
                glob.fnmatch.fnmatch(f_path, exc) for exc in exclude_patterns
            )
            if not excluded:
                files.append(f_path)

    # 3. Parse Files
    prompts_payload = []
    slug_to_path = {}
    parse_errors = []

    table = Table(title=f"Pushing to collection: [bold]{collection_slug}[/bold]")
    table.add_column("File", style="cyan")
    table.add_column("Slug", style="magenta")
    table.add_column("Version", style="green")
    table.add_column("Files", style="yellow")
    table.add_column("Status", style="white")

    for f_path in files:
        path_obj = Path(f_path)
        try:
            data = utils.parse_prompt_file(path_obj)
            meta = data['meta']
            content = data['content']

            slug = str(meta.get('slug', path_obj.stem))
            slug_to_path[slug] = path_obj

            # Load referenced asset files
            files_payload = []
            if meta.get('files'):
                try:
                    files_payload = utils.load_files_for_push(meta, base_dir)
                except ValueError as fe:
                    parse_errors.append(f"[{f_path}] {fe}")
                    table.add_row(f_path, slug, "???", "0", f"[red]File error: {fe}[/red]")
                    continue

            # Build prompt payload with all fields
            payload = {
                'slug': slug,
                'title': str(meta.get('title', slug)),
                'version': str(meta.get('version', '0.0.1')),
                'description': str(meta.get('description', '')),
                'long_description': str(meta.get('long_description', '')),
                'visibility': meta.get('visibility', 'private'),
                'content_hidden': bool(meta.get('content_hidden', False)),
                'output_type': meta.get('output_type', 'text'),
                'language': meta.get('language') or None,
                'tags': meta.get('tags', []) or [],
                'area': meta.get('area') or None,
                'content': {
                    'user': content,
                    'system': meta.get('system_prompt', '') or ''
                },
                'config': meta.get('config', {}),
                'files': files_payload,
                'forked_from_slug': meta.get('cloned_from') or None,
            }
            prompts_payload.append(payload)
            files_count = len(files_payload)
            table.add_row(
                f_path, slug, payload['version'],
                str(files_count) if files_count else "-",
                "Parsed OK"
            )

        except Exception as e:
            parse_errors.append(f"[{f_path}] {e}")
            table.add_row(f_path, "???", "???", "-", f"[red]Error: {e}[/red]")

    console.print(table)

    if parse_errors:
        console.print(f"\n[red]Found {len(parse_errors)} parse error(s). Fix them before pushing.[/red]")
        raise typer.Exit(1)

    if not prompts_payload and not project_conf.get('pending_deletions'):
        console.print("[yellow]No valid prompts found to push.[/yellow]")
        raise typer.Exit()

    # Check batch limit client-side (server also enforces)
    if len(prompts_payload) > 50:
        console.print(f"[red]Batch too large: {len(prompts_payload)} prompts (max 50 per push).[/red]")
        console.print("Split your push into smaller batches using the 'include' pattern in prompthub.yaml.")
        raise typer.Exit(1)

    if dry_run:
        console.print("[yellow]Dry run complete. Nothing sent.[/yellow]")
        return

    # 4. Send to API
    token = config.get_token()
    host = config.get_host()

    if not token:
        console.print("[red]Not logged in. Run 'promptun login' first.[/red]")
        raise typer.Exit(1)

    pending_deletions = project_conf.get('pending_deletions', [])

    with console.status(f"Uploading {len(prompts_payload)} prompt(s){f' + {len(pending_deletions)} deletion(s)' if pending_deletions else ''}..."):
        try:
            response = requests.post(
                f"{host}/api/cli/v1/push",
                json={
                    'collection': collection_slug,
                    'prompts': prompts_payload,
                    'deletions': pending_deletions,
                    'message': message
                },
                headers={"Authorization": f"Bearer {token}"},
                timeout=120  # Allow time for file uploads
            )

            if response.status_code == 200:
                result = response.json()
                console.print(f"[bold green]Success![/bold green] Processed {len(result.get('results', []))} items.")

                # Clear pending deletions after successful push
                if pending_deletions:
                    utils.pop_pending_deletions()
                    for deleted_slug in result.get('deletions', []):
                        console.print(f"  - {deleted_slug}: [red]deleted[/red]")

                # Display warnings (spam checks, etc.)
                for warning in result.get('warnings', []):
                    console.print(f"  [yellow]⚠ {warning}[/yellow]")

                for res in result.get('results', []):
                    slug = res['slug']
                    new_version = res.get('version')
                    status_text = res['status']
                    slug_modified_from = res.get('slug_modified_from')
                    status_color = "green" if status_text == 'updated' else ("yellow" if status_text == 'skipped' else "red")

                    # Use the original slug for display/lookup when there was a conflict rename
                    display_slug = slug_modified_from or slug
                    msg = f"  - {display_slug}: [{status_color}]{status_text}[/{status_color}]"
                    if new_version:
                        msg += f" (v{new_version})"
                    if slug_modified_from:
                        msg += f" [yellow]⚠ slug conflict — renamed to '{slug}'[/yellow]"
                    if res.get('message'):
                        msg += f" — {res['message']}"

                    # If slug was renamed due to conflict, update the local file with new slug
                    if slug_modified_from and slug_modified_from in slug_to_path:
                        f_path = slug_to_path[slug_modified_from]
                        try:
                            from promptun.utils import update_prompt_slug
                            update_prompt_slug(f_path, slug)
                            msg += " [blue](local file slug updated)[/blue]"
                        except Exception as e:
                            msg += f" [red](failed to update local file: {e})[/red]"

                    # Auto-update local file version if it changed
                    lookup_slug = slug_modified_from or slug
                    if status_text == 'updated' and lookup_slug in slug_to_path:
                        original_payload = next((p for p in prompts_payload if p['slug'] == lookup_slug), None)
                        if original_payload and original_payload['version'] != new_version:
                            f_path = slug_to_path[lookup_slug]
                            try:
                                file_data = utils.parse_prompt_file(f_path)
                                dump_data = {
                                    'slug': slug,
                                    'version': new_version,
                                    'title': file_data['meta'].get('title'),
                                    'description': file_data['meta'].get('description'),
                                    'long_description': file_data['meta'].get('long_description'),
                                    'visibility': file_data['meta'].get('visibility', 'private'),
                                    'content_hidden': file_data['meta'].get('content_hidden', False),
                                    'output_type': file_data['meta'].get('output_type', 'text'),
                                    'language': file_data['meta'].get('language'),
                                    'tags': file_data['meta'].get('tags'),
                                    'area': file_data['meta'].get('area'),
                                    'config': file_data['meta'].get('config'),
                                    'files': [
                                        {'path': fe['path'], 'is_public': fe['is_public']}
                                        for fe in file_data['meta'].get('files', [])
                                    ],
                                    'content': {
                                        'user': file_data['content'],
                                        'system': file_data['meta'].get('system_prompt')
                                    }
                                }
                                utils.dump_prompt_file(f_path, dump_data)
                                msg += " [blue](local version updated)[/blue]"
                            except Exception as e:
                                msg += f" [red](failed to update local file: {e})[/red]"

                    console.print(msg)

            elif response.status_code == 400:
                error_data = response.json()
                console.print(f"[red]Push rejected:[/red] {error_data.get('error', response.text)}")
                raise typer.Exit(1)
            elif response.status_code == 403:
                error_data = response.json()
                error_code = error_data.get('error')
                if error_code == 'collection_not_yours':
                    author = error_data.get('collection_author', 'another user')
                    is_public = error_data.get('is_public', True)
                    visibility = "public" if is_public else "private"
                    console.print(f"\n[bold red]Cannot push to '{collection_slug}' — this {visibility} collection belongs to @{author}.[/bold red]\n")
                    console.print("You have two options:\n")
                    console.print(f"  [cyan]1.[/cyan] Ask [bold]@{author}[/bold] to grant you write access to '{collection_slug}'.")
                    console.print(f"  [cyan]2.[/cyan] Create your own collection with a different name:")
                    console.print(f"       [bold]promptun init <new-slug>[/bold]  (then run push again)\n")
                else:
                    console.print(f"[red]Access denied:[/red] {error_data.get('error', response.text)}")
                raise typer.Exit(1)
            elif response.status_code == 429:
                console.print("[red]Rate limit exceeded.[/red] Please wait before pushing again.")
                retry_after = response.headers.get('Retry-After', 'unknown')
                if retry_after != 'unknown':
                    console.print(f"  Retry after: {retry_after} seconds")
                raise typer.Exit(1)
            else:
                console.print(f"[red]Upload failed ({response.status_code}):[/red] {response.text}")

        except requests.exceptions.RequestException as e:
            console.print(f"[red]Network error:[/red] {e}")
            raise typer.Exit(1)


@app.command()
def pull(
    collection: str = typer.Argument(None, help="Collection slug to pull from. Accepts 'username/slug' or just 'slug'. Defaults to current project."),
    author: str = typer.Option(None, "--author", "-a", help="Collection owner username (alternative to 'username/slug' syntax)."),
    force: bool = typer.Option(False, "--force", "-f", help="Overwrite local files without asking")
):
    """
    Download prompts from PromptHub to local files.
    """
    # 1. Determine Collection
    project_conf = utils.get_project_config()

    if not collection:
        if not project_conf:
            console.print("[red]No collection specified and no prompthub.yaml found.[/red]")
            console.print("Usage: promptun pull <collection-slug>")
            console.print("       promptun pull username/collection-slug")
            console.print("       promptun pull <collection-slug> --author username")
            raise typer.Exit(1)
        collection = project_conf.get('project')
        if not author:
            author = project_conf.get('author')
    else:
        parsed_collection, parsed_author = utils.parse_repo_string(collection)
        collection = parsed_collection
        if not author:
            author = parsed_author

    # 2. Auth
    token = config.get_token()
    host = config.get_host()
    if not token:
        console.print("[red]Not logged in.[/red]")
        raise typer.Exit(1)

    # 3. Fetch
    params = {'collection': collection}
    if author:
        params['author'] = author

    with console.status(f"Fetching prompts from '{collection}'..."):
        try:
            response = requests.get(
                f"{host}/api/cli/v1/pull",
                params=params,
                headers={"Authorization": f"Bearer {token}"},
                timeout=60
            )

            if response.status_code != 200:
                console.print(f"[red]Failed to pull ({response.status_code}):[/red] {response.text}")
                raise typer.Exit(1)

            data = response.json()
            prompts = data.get('prompts', [])

        except requests.exceptions.RequestException as e:
            console.print(f"[red]Network error:[/red] {e}")
            raise typer.Exit(1)

    # 4. Initialize if needed
    base_dir = Path('.')
    if not project_conf:
        if typer.confirm(f"Initialize new project '{collection}' in current directory?"):
            api_author = data.get('author') or author
            utils.create_project_config(collection, author=api_author)
            project_conf = utils.get_project_config()
        else:
            console.print("Aborted.")
            raise typer.Exit(1)

    # 4.5 Scan for existing files to map Slug -> FilePath
    existing_files_map = {}
    if project_conf:
        patterns = project_conf.get('include', ['**/*.prompt.md'])
        for pattern in patterns:
            for f_path in glob.glob(pattern, recursive=True):
                try:
                    p_data = utils.parse_prompt_file(Path(f_path))
                    f_slug = p_data.get('meta', {}).get('slug')
                    if f_slug:
                        existing_files_map[f_slug] = Path(f_path)
                except Exception:
                    pass

    # 5. Write Files
    table = Table(title=f"Pulling from: [bold]{collection}[/bold]")
    table.add_column("Slug", style="cyan")
    table.add_column("File", style="magenta")
    table.add_column("Version", style="green")
    table.add_column("Files", style="yellow")
    table.add_column("Action", style="white")

    for p_data in prompts:
        slug = p_data['slug']

        # Determine target file path
        if slug in existing_files_map:
            file_path = existing_files_map[slug]
            action = "Updated"
        else:
            filename = f"{slug}.prompt.md"
            file_path = Path(filename)
            action = "Created"

        if file_path.exists() and action == "Created":
            if not force:
                action = "Updated"
            else:
                action = "Overwritten"

        # Download associated files to assets/
        files_frontmatter = []
        remote_files = p_data.get('files', [])
        if remote_files:
            files_frontmatter = utils.save_pulled_files(remote_files, base_dir)

        # Inject files list into data for dump
        p_data['files'] = files_frontmatter

        try:
            utils.dump_prompt_file(file_path, p_data)
            files_count = len(files_frontmatter)
            table.add_row(
                slug, str(file_path), p_data.get('version', '?'),
                str(files_count) if files_count else "-",
                f"[green]{action}[/green]"
            )
        except Exception as e:
            table.add_row(slug, str(file_path), "error", "-", f"[red]{e}[/red]")

    console.print(table)
    console.print(f"[bold green]Done![/bold green] Synced {len(prompts)} prompts.")


@app.command()
def clone(
    repo: str = typer.Argument(..., help="Collection URL or 'user/slug' to clone.")
):
    """
    Clone a remote collection into a new directory.
    Accepts:
    - Full URL: https://promptun.com/username/collections/slug
    - Shorthand: username/slug
    - Slug only: slug (assumes your user)
    """
    collection_slug, author = utils.parse_repo_string(repo)
    target_dir = Path(collection_slug)

    # 1. Check Dir
    if target_dir.exists():
        console.print(f"[red]Directory '{collection_slug}' already exists.[/red]")
        raise typer.Exit(1)

    # 2. Auth Check
    token = config.get_token()
    host = config.get_host()
    if not token:
        console.print("[red]Not logged in. Run 'promptun login' first.[/red]")
        raise typer.Exit(1)

    # 3. Create Dir
    try:
        target_dir.mkdir(parents=True)
    except Exception as e:
        console.print(f"[red]Failed to create directory:[/red] {e}")
        raise typer.Exit(1)

    # 4. Fetch Prompts
    params = {'collection': collection_slug}
    if author:
        params['author'] = author

    with console.status(f"Cloning '{collection_slug}'..."):
        try:
            response = requests.get(
                f"{host}/api/cli/v1/pull",
                params=params,
                headers={"Authorization": f"Bearer {token}"},
                timeout=60
            )

            if response.status_code != 200:
                console.print(f"[red]Failed to clone ({response.status_code}):[/red] {response.text}")
                import shutil
                shutil.rmtree(target_dir, ignore_errors=True)
                raise typer.Exit(1)

            data = response.json()
            prompts = data.get('prompts', [])
            real_author = data.get('author')

        except requests.exceptions.RequestException as e:
            console.print(f"[red]Network error:[/red] {e}")
            import shutil
            shutil.rmtree(target_dir, ignore_errors=True)
            raise typer.Exit(1)

    access_type = data.get('access_type', 'public')
    is_read_only = access_type not in ('owner', 'edit')

    # Create prompthub.yaml only when the user has write access.
    # For public/read-only clones the user must run 'promptun init' to start their own collection.
    if not is_read_only:
        utils.create_project_config(collection_slug, author=real_author, root=target_dir)
        console.print(f"[green]Initialized project in {target_dir}/ (Author: {real_author})[/green]")
    else:
        # Write attribution file so the user knows the origin
        (target_dir / '.cloned_from').write_text(
            f"collection: {collection_slug}\nauthor: {real_author}\n"
        )
        console.print(f"[yellow]Cloned read-only collection from @{real_author}.[/yellow]")
        console.print("[cyan]No prompthub.yaml created — run 'promptun init <your-collection-name>' inside the directory before pushing.[/cyan]")

    # 5. Write Files
    table = Table(title=f"Cloning: [bold]{collection_slug}[/bold]")
    table.add_column("Slug", style="cyan")
    table.add_column("File", style="magenta")
    table.add_column("Version", style="green")
    table.add_column("Files", style="yellow")

    for p_data in prompts:
        slug = p_data['slug']
        filename = f"{slug}.prompt.md"
        file_path = target_dir / filename

        # Download associated files
        files_frontmatter = []
        remote_files = p_data.get('files', [])
        if remote_files:
            files_frontmatter = utils.save_pulled_files(remote_files, target_dir)

        p_data['files'] = files_frontmatter

        # For read-only clones, embed fork attribution in each prompt file
        if is_read_only:
            p_data['cloned_from'] = f"{real_author}/{collection_slug}"

        try:
            utils.dump_prompt_file(file_path, p_data)
            files_count = len(files_frontmatter)
            table.add_row(slug, str(file_path), p_data.get('version', '?'),
                          str(files_count) if files_count else "-")
        except Exception as e:
            table.add_row(slug, str(file_path), f"[red]Error: {e}[/red]", "-")

    console.print(table)
    if is_read_only:
        console.print(f"[bold green]Cloned successfully![/bold green] Run 'cd {collection_slug} && promptun init <your-collection-name>' to start working.")
    else:
        console.print(f"[bold green]Cloned successfully![/bold green] Run 'cd {collection_slug}' to start working.")


@app.command()
def log(slug: str = typer.Argument(..., help="Prompt slug")):
    """
    Show version history for a prompt.
    """
    token = config.get_token()
    host = config.get_host()
    if not token:
        console.print("[red]Not logged in.[/red]")
        raise typer.Exit(1)

    try:
        response = requests.get(
            f"{host}/api/cli/v1/log",
            params={'slug': slug},
            headers={"Authorization": f"Bearer {token}"},
            timeout=30
        )

        if response.status_code != 200:
            console.print(f"[red]Error ({response.status_code}):[/red] {response.text}")
            raise typer.Exit(1)

        history = response.json()

        table = Table(title=f"History: [bold]{slug}[/bold]")
        table.add_column("Version", style="green")
        table.add_column("Date", style="cyan")
        table.add_column("Changelog", style="white")

        for entry in history:
            date_str = entry['created_at'].split('T')[0]
            table.add_row(entry['version'], date_str, entry['changelog'])

        console.print(table)

    except requests.exceptions.RequestException as e:
        console.print(f"[red]Network error:[/red] {e}")


@app.command()
def revert(
    slug: str = typer.Argument(..., help="Prompt slug"),
    version: str = typer.Argument(..., help="Version to revert to")
):
    """
    Revert a prompt to a specific version (overwrites local file).
    """
    token = config.get_token()
    host = config.get_host()
    if not token:
        console.print("[red]Not logged in.[/red]")
        raise typer.Exit(1)

    with console.status(f"Fetching {slug} v{version}..."):
        try:
            response = requests.get(
                f"{host}/api/cli/v1/get",
                params={'slug': slug, 'version': version},
                headers={"Authorization": f"Bearer {token}"},
                timeout=30
            )

            if response.status_code != 200:
                console.print(f"[red]Error ({response.status_code}):[/red] {response.text}")
                raise typer.Exit(1)

            data = response.json()

        except requests.exceptions.RequestException as e:
            console.print(f"[red]Network error:[/red] {e}")
            raise typer.Exit(1)

    # Find local file
    target_file = Path(f"{slug}.prompt.md")
    project_conf = utils.get_project_config()
    if project_conf:
        patterns = project_conf.get('include', ['**/*.prompt.md'])
        for pattern in patterns:
            for f_path in glob.glob(pattern, recursive=True):
                try:
                    p_data = utils.parse_prompt_file(Path(f_path))
                    if p_data.get('meta', {}).get('slug') == slug:
                        target_file = Path(f_path)
                        break
                except Exception:
                    pass

    try:
        utils.dump_prompt_file(target_file, data)
        console.print(f"[bold green]Success![/bold green] Reverted {target_file} to v{version}.")
    except Exception as e:
        console.print(f"[red]Failed to write file:[/red] {e}")


@app.command()
def rm(slug: str = typer.Argument(..., help="Prompt slug to mark for deletion")):
    """
    Mark a prompt for deletion. The prompt will be deleted from the server on the next push.
    """
    project_conf = utils.get_project_config()
    if not project_conf:
        console.print("[red]No prompthub.yaml found. Run 'promptun init <name>' first.[/red]")
        raise typer.Exit(1)

    if not typer.confirm(f"Mark '{slug}' for deletion? (will be deleted on next push)"):
        raise typer.Exit()

    # 1. Delete local file
    target_file = None
    patterns = project_conf.get('include', ['**/*.prompt.md'])
    for pattern in patterns:
        for f_path in glob.glob(pattern, recursive=True):
            try:
                p_data = utils.parse_prompt_file(Path(f_path))
                if p_data.get('meta', {}).get('slug') == slug:
                    target_file = Path(f_path)
                    break
            except Exception:
                pass

    if not target_file:
        target_file = Path(f"{slug}.prompt.md")

    if target_file.exists():
        try:
            os.remove(target_file)
            console.print(f"[green]Deleted local file: {target_file}[/green]")
        except Exception as e:
            console.print(f"[red]Failed to delete local file:[/red] {e}")

    # 2. Stage deletion in prompthub.yaml
    utils.add_pending_deletion(slug)

    console.print(f"[bold yellow]Prompt '{slug}' marked for deletion.[/bold yellow] Run [bold]promptun push[/bold] to apply.")


@app.command()
def history(
    collection: str = typer.Argument(None, help="Collection slug (optional)")
):
    """
    Show status of all prompts in the collection (Active & Deleted).
    """
    project_conf = utils.get_project_config()

    if not collection:
        if not project_conf:
            console.print("[red]No collection specified and no prompthub.yaml found.[/red]")
            raise typer.Exit(1)
        collection = project_conf.get('project')

    token = config.get_token()
    host = config.get_host()
    if not token:
        console.print("[red]Not logged in.[/red]")
        raise typer.Exit(1)

    try:
        response = requests.get(
            f"{host}/api/cli/v1/history",
            params={'collection': collection},
            headers={"Authorization": f"Bearer {token}"},
            timeout=30
        )

        if response.status_code != 200:
            console.print(f"[red]Error ({response.status_code}):[/red] {response.text}")
            raise typer.Exit(1)

        data = response.json()

        table = Table(title=f"Collection History: [bold]{collection}[/bold]")
        table.add_column("Slug", style="cyan")
        table.add_column("Status", style="bold")
        table.add_column("Latest Ver", style="green")
        table.add_column("Last Updated", style="white")

        for item in data:
            status_style = "green" if item['status'] == 'Active' else "red"
            date_str = item['updated_at'].split('T')[0] if item.get('updated_at') else '?'
            table.add_row(
                item['slug'],
                f"[{status_style}]{item['status']}[/{status_style}]",
                item['latest_version'],
                date_str
            )

        console.print(table)

    except requests.exceptions.RequestException as e:
        console.print(f"[red]Network error:[/red] {e}")
