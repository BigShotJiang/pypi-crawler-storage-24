"""
Tests for promptun.utils — pending deletion helpers.
"""
import pytest
import yaml
from pathlib import Path

from promptun.utils import add_pending_deletion, pop_pending_deletions, create_project_config


@pytest.fixture
def project_dir(tmp_path):
    """A temp dir with a valid prompthub.yaml."""
    create_project_config("test-project", root=tmp_path)
    return tmp_path


class TestAddPendingDeletion:

    def test_adds_slug_to_yaml(self, project_dir):
        add_pending_deletion("my-prompt", root=project_dir)
        config = yaml.safe_load((project_dir / "prompthub.yaml").read_text())
        assert "my-prompt" in config["pending_deletions"]

    def test_no_duplicates(self, project_dir):
        add_pending_deletion("my-prompt", root=project_dir)
        add_pending_deletion("my-prompt", root=project_dir)
        config = yaml.safe_load((project_dir / "prompthub.yaml").read_text())
        assert config["pending_deletions"].count("my-prompt") == 1

    def test_multiple_slugs_accumulated(self, project_dir):
        add_pending_deletion("slug-a", root=project_dir)
        add_pending_deletion("slug-b", root=project_dir)
        config = yaml.safe_load((project_dir / "prompthub.yaml").read_text())
        assert "slug-a" in config["pending_deletions"]
        assert "slug-b" in config["pending_deletions"]

    def test_no_config_file_is_noop(self, tmp_path):
        """No prompthub.yaml — add_pending_deletion must not crash."""
        add_pending_deletion("slug-x", root=tmp_path)
        assert not (tmp_path / "prompthub.yaml").exists()


class TestPopPendingDeletions:

    def test_returns_slugs_and_clears(self, project_dir):
        add_pending_deletion("slug-1", root=project_dir)
        add_pending_deletion("slug-2", root=project_dir)

        result = pop_pending_deletions(root=project_dir)

        assert set(result) == {"slug-1", "slug-2"}
        config = yaml.safe_load((project_dir / "prompthub.yaml").read_text())
        assert "pending_deletions" not in config

    def test_empty_when_no_pending(self, project_dir):
        result = pop_pending_deletions(root=project_dir)
        assert result == []

    def test_no_config_file_returns_empty(self, tmp_path):
        result = pop_pending_deletions(root=tmp_path)
        assert result == []

    def test_idempotent_second_pop_returns_empty(self, project_dir):
        add_pending_deletion("slug-once", root=project_dir)
        pop_pending_deletions(root=project_dir)
        result = pop_pending_deletions(root=project_dir)
        assert result == []
