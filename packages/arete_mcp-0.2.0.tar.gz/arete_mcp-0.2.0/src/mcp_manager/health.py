"""Health check implementations for MCP servers."""

from __future__ import annotations

import asyncio
import logging
import time

import httpx

from mcp_manager.config import HEALTH_STDIO_TIMEOUT_SECONDS, HEALTH_TIMEOUT_SECONDS
from mcp_manager.models import HealthResult, McpServer, ServerStatus, TransportType
from mcp_manager.protocol import (
    build_initialize_request,
    build_initialized_notification,
    build_ping_request,
    extract_server_info,
    parse_jsonrpc_response,
)

logger = logging.getLogger(__name__)


class HealthChecker:
    """Check health of MCP servers across transport types."""

    def __init__(self, timeout: int | None = None) -> None:
        self._timeout = timeout or HEALTH_TIMEOUT_SECONDS

    async def check(self, server: McpServer) -> HealthResult:
        """Route to the correct transport-specific check."""
        try:
            if server.transport == TransportType.STDIO:
                return await self._check_stdio(server)
            if server.transport == TransportType.SSE:
                return await self._check_sse(server)
            if server.transport == TransportType.HTTP:
                return await self._check_http(server)
            return HealthResult(
                server_name=server.name,
                status=ServerStatus.ERROR,
                transport=server.transport,
                error_message=f"Unknown transport: {server.transport}",
            )
        except Exception as exc:
            return HealthResult(
                server_name=server.name,
                status=ServerStatus.ERROR,
                transport=server.transport,
                error_message=str(exc),
            )

    async def check_all(self, servers: list[McpServer]) -> list[HealthResult]:
        """Check all servers concurrently."""
        tasks = [self.check(s) for s in servers]
        return list(await asyncio.gather(*tasks))

    # ------------------------------------------------------------------
    # Transport-specific checks
    # ------------------------------------------------------------------

    async def _check_stdio(self, server: McpServer) -> HealthResult:
        """Spawn process, send initialize + ping, measure latency."""
        if not server.stdio_config:
            return HealthResult(
                server_name=server.name,
                status=ServerStatus.ERROR,
                transport=TransportType.STDIO,
                error_message="No stdio config",
            )

        cfg = server.stdio_config
        start = time.monotonic()

        try:
            proc = await asyncio.create_subprocess_exec(
                cfg.command,
                *cfg.args,
                stdin=asyncio.subprocess.PIPE,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                env=cfg.env if cfg.env else None,
            )
        except FileNotFoundError:
            return HealthResult(
                server_name=server.name,
                status=ServerStatus.UNREACHABLE,
                transport=TransportType.STDIO,
                error_message=f"Command not found: {cfg.command}",
            )
        except OSError as exc:
            return HealthResult(
                server_name=server.name,
                status=ServerStatus.UNREACHABLE,
                transport=TransportType.STDIO,
                error_message=str(exc),
            )

        try:
            return await asyncio.wait_for(
                self._stdio_handshake(server.name, proc, start),
                timeout=HEALTH_STDIO_TIMEOUT_SECONDS,
            )
        except TimeoutError:
            return HealthResult(
                server_name=server.name,
                status=ServerStatus.UNREACHABLE,
                transport=TransportType.STDIO,
                error_message="Handshake timeout",
            )
        finally:
            try:
                proc.kill()
                await proc.wait()
            except ProcessLookupError:
                pass

    async def _stdio_handshake(
        self,
        name: str,
        proc: asyncio.subprocess.Process,
        start: float,
    ) -> HealthResult:
        """Run the MCP initialize + ping handshake over stdio."""
        assert proc.stdin is not None
        assert proc.stdout is not None

        # Send initialize.
        proc.stdin.write(build_initialize_request())
        await proc.stdin.drain()

        # Read response.
        init_data = await proc.stdout.readline()
        if not init_data:
            return HealthResult(
                server_name=name,
                status=ServerStatus.ERROR,
                transport=TransportType.STDIO,
                error_message="No response to initialize",
            )

        init_response = parse_jsonrpc_response(init_data)
        server_info = extract_server_info(init_response)

        # Send initialized notification.
        proc.stdin.write(build_initialized_notification())
        await proc.stdin.drain()

        # Send ping.
        proc.stdin.write(build_ping_request())
        await proc.stdin.drain()

        # Read ping response.
        await proc.stdout.readline()

        latency = (time.monotonic() - start) * 1000

        return HealthResult(
            server_name=name,
            status=ServerStatus.HEALTHY,
            latency_ms=round(latency, 1),
            transport=TransportType.STDIO,
            protocol_version=server_info.get("protocol_version"),
            server_info=server_info,
        )

    async def _check_sse(self, server: McpServer) -> HealthResult:
        """Check SSE server reachability."""
        if not server.network_config:
            return HealthResult(
                server_name=server.name,
                status=ServerStatus.ERROR,
                transport=TransportType.SSE,
                error_message="No network config",
            )

        url = server.network_config.url
        headers = dict(server.network_config.headers)
        start = time.monotonic()

        try:
            async with httpx.AsyncClient(timeout=self._timeout) as client:
                resp = await client.get(url, headers=headers)
        except httpx.ConnectError:
            return HealthResult(
                server_name=server.name,
                status=ServerStatus.UNREACHABLE,
                transport=TransportType.SSE,
                error_message=f"Connection refused: {url}",
            )
        except httpx.TimeoutException:
            return HealthResult(
                server_name=server.name,
                status=ServerStatus.UNREACHABLE,
                transport=TransportType.SSE,
                error_message="Timeout",
            )

        latency = (time.monotonic() - start) * 1000
        content_type = resp.headers.get("content-type", "")

        if resp.status_code >= 400:
            return HealthResult(
                server_name=server.name,
                status=ServerStatus.ERROR,
                latency_ms=round(latency, 1),
                transport=TransportType.SSE,
                error_message=f"HTTP {resp.status_code}",
            )

        status = ServerStatus.HEALTHY
        if "text/event-stream" not in content_type:
            status = ServerStatus.DEGRADED

        return HealthResult(
            server_name=server.name,
            status=status,
            latency_ms=round(latency, 1),
            transport=TransportType.SSE,
        )

    async def _check_http(self, server: McpServer) -> HealthResult:
        """POST JSON-RPC initialize to HTTP server."""
        if not server.network_config:
            return HealthResult(
                server_name=server.name,
                status=ServerStatus.ERROR,
                transport=TransportType.HTTP,
                error_message="No network config",
            )

        url = server.network_config.url
        headers = {"Content-Type": "application/json", **server.network_config.headers}
        init_request = {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "initialize",
            "params": {
                "protocolVersion": "2024-11-05",
                "capabilities": {},
                "clientInfo": {"name": "mcp-manager", "version": "0.1.0"},
            },
        }
        start = time.monotonic()

        try:
            async with httpx.AsyncClient(timeout=self._timeout) as client:
                resp = await client.post(url, json=init_request, headers=headers)
        except httpx.ConnectError:
            return HealthResult(
                server_name=server.name,
                status=ServerStatus.UNREACHABLE,
                transport=TransportType.HTTP,
                error_message=f"Connection refused: {url}",
            )
        except httpx.TimeoutException:
            return HealthResult(
                server_name=server.name,
                status=ServerStatus.UNREACHABLE,
                transport=TransportType.HTTP,
                error_message="Timeout",
            )

        latency = (time.monotonic() - start) * 1000

        if resp.status_code >= 400:
            return HealthResult(
                server_name=server.name,
                status=ServerStatus.ERROR,
                latency_ms=round(latency, 1),
                transport=TransportType.HTTP,
                error_message=f"HTTP {resp.status_code}",
            )

        # Try to parse JSON-RPC response.
        try:
            body = resp.json()
            server_info = extract_server_info(body)
            return HealthResult(
                server_name=server.name,
                status=ServerStatus.HEALTHY,
                latency_ms=round(latency, 1),
                transport=TransportType.HTTP,
                protocol_version=server_info.get("protocol_version"),
                server_info=server_info,
            )
        except Exception:
            return HealthResult(
                server_name=server.name,
                status=ServerStatus.DEGRADED,
                latency_ms=round(latency, 1),
                transport=TransportType.HTTP,
                error_message="Reachable but invalid JSON-RPC response",
            )
