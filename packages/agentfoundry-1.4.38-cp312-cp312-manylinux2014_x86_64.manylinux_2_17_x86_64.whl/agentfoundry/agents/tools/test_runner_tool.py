"""Test runner tool for coding agents.

Supports pytest and unittest. Returns structured results with
passed/failed/errors counts, output, and returncode.
Configurable timeout.
"""

import logging
import subprocess
from typing import Dict, List, Optional

from pydantic import BaseModel, Field
from langchain_core.tools import StructuredTool

logger = logging.getLogger(__name__)

_DEFAULT_TIMEOUT: int = 120


class TestRunnerInput(BaseModel):
    framework: str = Field(
        default="pytest",
        description="Test framework to use: 'pytest' or 'unittest'.",
    )
    path: Optional[str] = Field(
        None,
        description="Path to test file or directory. Defaults to current directory.",
    )
    args: Optional[List[str]] = Field(
        default=None,
        description="Additional arguments to pass to the test runner (e.g., ['-v', '-k', 'test_name']).",
    )
    timeout: Optional[int] = Field(
        None,
        description="Timeout in seconds (default: 120).",
    )
    cwd: Optional[str] = Field(None, description="Working directory for test execution.")


def _parse_pytest_output(stdout: str) -> Dict[str, int]:
    """Extract pass/fail/error counts from pytest output."""
    counts = {"passed": 0, "failed": 0, "errors": 0}
    for line in reversed(stdout.splitlines()):
        line_lower = line.lower()
        if "passed" in line_lower or "failed" in line_lower or "error" in line_lower:
            import re
            for key in counts:
                match = re.search(rf"(\d+)\s+{key}", line_lower)
                if match:
                    counts[key] = int(match.group(1))
            break
    return counts


def run_tests(
    framework: str = "pytest",
    path: Optional[str] = None,
    args: Optional[List[str]] = None,
    timeout: Optional[int] = None,
    cwd: Optional[str] = None,
) -> Dict[str, object]:
    """
    Run tests using pytest or unittest and return structured results.

    Returns a dict with 'passed', 'failed', 'errors' counts,
    'output' (combined stdout/stderr), and 'returncode'.
    """
    logger.info("run_tests: framework=%s path=%s", framework, path)
    extra_args = args or []
    effective_timeout = timeout or _DEFAULT_TIMEOUT

    if framework == "pytest":
        cmd = ["python", "-m", "pytest", "-v"]
        if path:
            cmd.append(path)
        cmd.extend(extra_args)
    elif framework == "unittest":
        cmd = ["python", "-m", "unittest"]
        if path:
            cmd.append(path)
        else:
            cmd.append("discover")
        cmd.extend(extra_args)
    else:
        return {"error": f"Unsupported test framework: {framework}"}

    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=effective_timeout,
            cwd=cwd,
        )
        output = result.stdout + result.stderr

        if framework == "pytest":
            counts = _parse_pytest_output(output)
        else:
            # Basic unittest parsing
            counts = {"passed": 0, "failed": 0, "errors": 0}
            for line in reversed(output.splitlines()):
                if "OK" in line:
                    import re
                    m = re.search(r"Ran (\d+) test", output)
                    if m:
                        counts["passed"] = int(m.group(1))
                    break
                if "FAILED" in line:
                    import re
                    fm = re.search(r"failures=(\d+)", line)
                    em = re.search(r"errors=(\d+)", line)
                    if fm:
                        counts["failed"] = int(fm.group(1))
                    if em:
                        counts["errors"] = int(em.group(1))
                    m = re.search(r"Ran (\d+) test", output)
                    if m:
                        total = int(m.group(1))
                        counts["passed"] = total - counts["failed"] - counts["errors"]
                    break

        return {
            "passed": counts["passed"],
            "failed": counts["failed"],
            "errors": counts["errors"],
            "output": output,
            "returncode": result.returncode,
        }
    except subprocess.TimeoutExpired:
        return {
            "error": f"Tests timed out after {effective_timeout}s.",
            "passed": 0,
            "failed": 0,
            "errors": 0,
            "output": "",
            "returncode": -1,
        }
    except Exception as ex:
        logger.error("run_tests error: %s", ex, exc_info=True)
        return {"error": str(ex), "returncode": -1}


test_runner_tool = StructuredTool.from_function(
    func=run_tests,
    name="test_runner",
    description=run_tests.__doc__,
    args_schema=TestRunnerInput,
)
