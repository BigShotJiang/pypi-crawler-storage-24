"""Kyber PQC Provider implementation using liboqs and PyCryptodome."""

import struct
import hashlib
import logging
from typing import Tuple

from agentfoundry.crypto.base import PQCProvider
from agentfoundry.crypto.factory import PQCFactory
from agentfoundry.crypto.providers.mouse_rng import collect_mouse_entropy

logger = logging.getLogger(__name__)

try:
    import oqs
    from Crypto.Cipher import AES
    from Crypto.Random import get_random_bytes
    HAS_OQS = True
    logger.debug("Successfully imported liboqs and PyCryptodome.")
except ImportError as e:
    HAS_OQS = False
    logger.warning("Failed to import liboqs or PyCryptodome: %s", e)

KEM_ALG = "ML-KEM-768"
SIG_ALG = "ML-DSA-65"

@PQCFactory.register_provider("kyber")
class KyberProvider(PQCProvider):
    def __init__(self, use_mouse_entropy=False):
        logger.info("Initializing KyberProvider (use_mouse_entropy=%s)", use_mouse_entropy)
        if not HAS_OQS:
            logger.error("Required libraries 'liboqs-python' and/or 'pycryptodome' are missing.")
            raise RuntimeError(
                "liboqs-python and pycryptodome are required for KyberProvider. "
                "Install with 'pip install liboqs-python pycryptodome'."
            )
        self.use_mouse_entropy = use_mouse_entropy

    def _get_entropy(self) -> bytes:
        logger.debug("Generating entropy...")
        if self.use_mouse_entropy:
            logger.info("Collecting mouse entropy to mix with system entropy.")
            mouse_ent = collect_mouse_entropy()
            sys_ent = get_random_bytes(32)
            mixed = hashlib.sha256(mouse_ent + sys_ent).digest()
            logger.debug("Successfully generated mixed entropy.")
            return mixed
        logger.debug("Using standard system entropy.")
        return get_random_bytes(32)

    def generate_keypair(self) -> Tuple[bytes, bytes]:
        """Generates ML-KEM-768 public and private keys."""
        logger.info("Generating %s keypair for KEM...", KEM_ALG)
        if self.use_mouse_entropy:
            self._get_entropy()
            
        with oqs.KeyEncapsulation(KEM_ALG) as kem:
            public_key = kem.generate_keypair()
            private_key = kem.export_secret_key()
            logger.info("Successfully generated %s keypair.", KEM_ALG)
            return public_key, private_key

    def generate_signing_keypair(self) -> Tuple[bytes, bytes]:
        """Generates ML-DSA-65 public and private keys."""
        logger.info("Generating %s keypair for signatures...", SIG_ALG)
        if self.use_mouse_entropy:
            self._get_entropy()
            
        with oqs.Signature(SIG_ALG) as sig:
            public_key = sig.generate_keypair()
            private_key = sig.export_secret_key()
            logger.info("Successfully generated %s signing keypair.", SIG_ALG)
            return public_key, private_key

    def encrypt(self, data: bytes, public_key: bytes) -> bytes:
        """
        Encrypts data using Kyber KEM and AES-256-GCM.
        Returns: [4 bytes kem_ct_len] + [kem_ct] + [12 bytes nonce] + [16 bytes tag] + [aes_ct]
        """
        logger.info("Encrypting data using %s and AES-256-GCM...", KEM_ALG)
        with oqs.KeyEncapsulation(KEM_ALG) as kem:
            logger.debug("Encapsulating secret...")
            kem_ciphertext, shared_secret = kem.encap_secret(public_key)
            
        logger.debug("Performing AES-256-GCM encryption with encapsulated secret...")
        nonce = get_random_bytes(12)
        cipher = AES.new(shared_secret, AES.MODE_GCM, nonce=nonce)
        encrypted_data, auth_tag = cipher.encrypt_and_digest(data)
        
        kem_ct_len = len(kem_ciphertext)
        packed_data = struct.pack(">I", kem_ct_len) + kem_ciphertext + nonce + auth_tag + encrypted_data
        logger.info("Successfully encrypted data (payload size: %d bytes).", len(packed_data))
        return packed_data

    def decrypt(self, encrypted_data: bytes, private_key: bytes) -> bytes:
        """
        Decrypts data packed by encrypt().
        """
        logger.info("Decrypting data using %s and AES-256-GCM...", KEM_ALG)
        kem_ct_len = struct.unpack(">I", encrypted_data[:4])[0]
        offset = 4
        
        kem_ciphertext = encrypted_data[offset:offset+kem_ct_len]
        offset += kem_ct_len
        
        nonce = encrypted_data[offset:offset+12]
        offset += 12
        
        auth_tag = encrypted_data[offset:offset+16]
        offset += 16
        
        aes_ct = encrypted_data[offset:]
        
        logger.debug("Decapsulating secret...")
        with oqs.KeyEncapsulation(KEM_ALG, secret_key=private_key) as kem:
            shared_secret = kem.decap_secret(kem_ciphertext)
            
        logger.debug("Performing AES-256-GCM decryption...")
        cipher = AES.new(shared_secret, AES.MODE_GCM, nonce=nonce)
        decrypted_data = cipher.decrypt_and_verify(aes_ct, auth_tag)
        logger.info("Successfully decrypted data.")
        return decrypted_data

    def sign(self, data: bytes, private_key: bytes) -> bytes:
        """Signs data using ML-DSA-65."""
        logger.info("Signing data using %s...", SIG_ALG)
        with oqs.Signature(SIG_ALG, secret_key=private_key) as sig:
            signature = sig.sign(data)
            logger.info("Successfully signed data (signature size: %d bytes).", len(signature))
            return signature

    def verify(self, data: bytes, signature: bytes, public_key: bytes) -> bool:
        """Verifies an ML-DSA-65 signature."""
        logger.info("Verifying %s signature...", SIG_ALG)
        with oqs.Signature(SIG_ALG) as sig:
            is_valid = sig.verify(data, signature, public_key)
            if is_valid:
                logger.info("Signature verification passed.")
            else:
                logger.warning("Signature verification failed.")
            return is_valid
