# PipSlim
> Lightweight Python package used for generating minimal requirements.txt files.
> This package completely removes the need for manually removing unecessary packages included by the `pip freeze` command when generating requirements.txt files.

## Installation
The package can be installed by the Python Package Index (PYPI) using the following command. If you install the package to your global python environment, the command will work globally for all virtual environments too.
> `python -m pip install pipslim`

## Usage
This module provides the `pipslim` command which is a replacement for `pip freeze`.
You can dump package dependencies to requirements.txt using `pipslim > requirements.txt`

## Side-by-Side Comparison

| **pipslim** | **pip freeze** |
| --- | --- |
| <img width="110" height="68" alt="image" src="https://commonsystems.com.au/images/pipslim_screenshot_2.png" /> | <img width="188" height="490" alt="image" src="https://commonsystems.com.au/images/pipslim_screenshot_1.png" /> |
 
