from .util import *
import threading

def run():
    """
    Program entry point
    """
    packages = []
    def _threaded_list_package_deps(package:dict=None):
        if package == None : return
        if len(list_package_dependencies(package['name'])) == 0:
            packages.append(f"{package['name']}=={package['version']}")

    threads = []
    for package in list_packages():
        thread = threading.Thread(target=lambda: _threaded_list_package_deps(package), daemon=True)
        threads.append(thread)
        thread.start()

    for thread in threads: thread.join()
    
    print('\n'.join(sorted(packages)))

if __name__ == '__main__':
    run()