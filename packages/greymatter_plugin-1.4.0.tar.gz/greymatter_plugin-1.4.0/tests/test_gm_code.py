"""Tests for the gm_code MCP tool integration."""
import json
import os
import tempfile

import pytest

from greymatter_core.db import SQLiteDatabase, register_schema_extension, _schema_extensions
from greymatter_plugin.server import create_app


@pytest.fixture
def tmpdir():
    """Create a temp directory with a small Python file for indexing."""
    with tempfile.TemporaryDirectory() as d:
        py_file = os.path.join(d, "example.py")
        with open(py_file, "w") as f:
            f.write(
                "def greet(name: str) -> str:\n"
                "    \"\"\"Say hello.\"\"\"\n"
                "    return f\"Hello, {name}\"\n"
                "\n"
                "\n"
                "class Calculator:\n"
                "    \"\"\"A simple calculator.\"\"\"\n"
                "\n"
                "    def add(self, a: int, b: int) -> int:\n"
                "        return a + b\n"
            )
        yield d


@pytest.fixture
def db_and_app(tmpdir):
    """Create a file-backed DB and app."""
    from greymatter_core.semantic import register_table, register_fts_backend, _TABLE_CONFIG, _FTS_BACKENDS
    from greymatter_salesos.schema import salesos_schema_extension
    from greymatter_salesos.semantic import SALESOS_TABLE_CONFIGS, SALESOS_FTS_BACKENDS

    register_schema_extension(salesos_schema_extension)
    for name, config in SALESOS_TABLE_CONFIGS.items():
        register_table(name, config)
    for name, backend in SALESOS_FTS_BACKENDS.items():
        register_fts_backend(name, **backend)

    db_file = os.path.join(tmpdir, "test.db")
    database = SQLiteDatabase(db_file)
    app = create_app(database)

    try:
        yield database, app
    finally:
        database.close()
        _schema_extensions.pop()
        for name in SALESOS_TABLE_CONFIGS:
            _TABLE_CONFIG.pop(name, None)
        for name in SALESOS_FTS_BACKENDS:
            _FTS_BACKENDS.pop(name, None)


# ---- index action ----

def test_index_returns_stats(tmpdir, db_and_app):
    """Index action should scan files and return symbol counts."""
    _, app = db_and_app
    gm_code = app._tool_functions["gm_code"]
    result = json.loads(gm_code(action="index", directory=tmpdir, repo="test"))
    assert result["files_scanned"] >= 1
    assert result["symbols_indexed"] >= 1
    assert result["repo"] == "test"


# ---- search action ----

def test_search_finds_indexed_symbols(tmpdir, db_and_app):
    """Search should find symbols indexed from the test file."""
    _, app = db_and_app
    gm_code = app._tool_functions["gm_code"]
    gm_code(action="index", directory=tmpdir, repo="test")
    result = json.loads(gm_code(action="search", query="greet"))
    assert result["count"] >= 1
    assert any("greet" in s["name"] for s in result["symbols"])


def test_search_with_repo_filter(tmpdir, db_and_app):
    """Search should filter by repo."""
    _, app = db_and_app
    gm_code = app._tool_functions["gm_code"]
    gm_code(action="index", directory=tmpdir, repo="test")
    result = json.loads(gm_code(action="search", repo="nonexistent"))
    assert result["count"] == 0


def test_search_with_kind_filter(tmpdir, db_and_app):
    """Search should filter by symbol kind."""
    _, app = db_and_app
    gm_code = app._tool_functions["gm_code"]
    gm_code(action="index", directory=tmpdir, repo="test")
    result = json.loads(gm_code(action="search", kind="class", repo="test"))
    assert result["count"] >= 1
    assert all(s["kind"] == "class" for s in result["symbols"])


# ---- get_symbol action ----

def test_get_symbol_returns_full_record(tmpdir, db_and_app):
    """get_symbol should return the full symbol."""
    _, app = db_and_app
    gm_code = app._tool_functions["gm_code"]
    gm_code(action="index", directory=tmpdir, repo="test")

    search = json.loads(gm_code(action="search", query="greet", kind="function", repo="test"))
    assert search["count"] >= 1
    sym_id = search["symbols"][0]["id"]

    result = json.loads(gm_code(action="get", symbol_id=sym_id))
    assert result["name"] == "greet"
    assert result["kind"] == "function"


def test_get_symbol_not_found(tmpdir, db_and_app):
    """get for unknown ID should return null."""
    _, app = db_and_app
    gm_code = app._tool_functions["gm_code"]
    raw = gm_code(action="get", symbol_id="nonexistent::file.py::func#function")
    result = json.loads(raw)
    assert result is None


# ---- outline action ----

def test_outline_returns_file_symbols(tmpdir, db_and_app):
    """Outline should return all symbols in a file."""
    _, app = db_and_app
    gm_code = app._tool_functions["gm_code"]
    gm_code(action="index", directory=tmpdir, repo="test")
    result = json.loads(gm_code(action="outline", repo="test", file_path="example.py"))
    assert len(result["symbols"]) >= 2  # greet + Calculator (+ possibly add method)


# ---- link action ----

def test_link_creates_symbol_link(tmpdir, db_and_app):
    """Link action should create a connection between a symbol and a target."""
    _, app = db_and_app
    gm_code = app._tool_functions["gm_code"]
    gm_code(action="index", directory=tmpdir, repo="test")

    search = json.loads(gm_code(action="search", query="greet", kind="function", repo="test"))
    sym_id = search["symbols"][0]["id"]

    result = json.loads(gm_code(
        action="link",
        symbol_id=sym_id,
        target_type="knowledge",
        target_id="k-001",
        relationship="implements",
    ))
    assert result["linked"] is True
    assert result["symbol_id"] == sym_id
    assert result["target"] == "knowledge:k-001"


# ---- status action ----

def test_status_returns_stats(tmpdir, db_and_app):
    """Status action should return indexing stats."""
    _, app = db_and_app
    gm_code = app._tool_functions["gm_code"]
    gm_code(action="index", directory=tmpdir, repo="test")
    result = json.loads(gm_code(action="status"))
    # Should have some stats about indexed repos
    assert isinstance(result, dict)


# ---- unknown action ----

def test_unknown_action_returns_error(tmpdir, db_and_app):
    """Unknown action should return an error."""
    _, app = db_and_app
    gm_code = app._tool_functions["gm_code"]
    result = json.loads(gm_code(action="bogus"))
    assert result is None or (isinstance(result, dict) and "error" in result)
