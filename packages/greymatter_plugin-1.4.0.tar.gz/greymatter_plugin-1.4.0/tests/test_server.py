"""Tests for GreyMatter MCP server."""
import json
import pytest
from greymatter_core.db import SQLiteDatabase, register_schema_extension, _schema_extensions
from greymatter_plugin.server import create_app


@pytest.fixture
def db():
    """DB with SalesOS extension — server tools reference SalesOS tables.
    Registers schema, TABLE_CONFIG entries, and FTS backends."""
    from greymatter_core.semantic import register_table, register_fts_backend, _TABLE_CONFIG, _FTS_BACKENDS
    from greymatter_salesos.schema import salesos_schema_extension
    from greymatter_salesos.semantic import SALESOS_TABLE_CONFIGS, SALESOS_FTS_BACKENDS

    register_schema_extension(salesos_schema_extension)
    for name, config in SALESOS_TABLE_CONFIGS.items():
        register_table(name, config)
    for name, backend in SALESOS_FTS_BACKENDS.items():
        register_fts_backend(name, **backend)

    try:
        database = SQLiteDatabase(":memory:")
        yield database
        database.close()
    finally:
        _schema_extensions.pop()
        for name in SALESOS_TABLE_CONFIGS:
            _TABLE_CONFIG.pop(name, None)
        for name in SALESOS_FTS_BACKENDS:
            _FTS_BACKENDS.pop(name, None)


@pytest.fixture
def app(db):
    return create_app(db)


def test_app_creates(app):
    assert app is not None
    assert app.name == "greymatter"


def test_gm_status(app, db):
    result = app._tool_functions["gm_status"]()
    parsed = json.loads(result)
    assert "patterns" in parsed
    assert "knowledge" in parsed
    assert "work_items" in parsed


def test_gm_pattern_list(app, db):
    result = app._tool_functions["gm_pattern"](action="list")
    parsed = json.loads(result)
    assert "total" in parsed
    assert "returned" in parsed
    assert "patterns" in parsed
    assert isinstance(parsed["patterns"], list)


def test_gm_pattern_create(app, db):
    result = app._tool_functions["gm_pattern"](
        action="create",
        type="convention",
        domain="testing",
        title="Test Pattern",
        observation="Always write tests first",
    )
    parsed = json.loads(result)
    assert parsed["title"] == "Test Pattern"
    assert parsed["confidence"] == "low"


def test_gm_pattern_search(app, db):
    app._tool_functions["gm_pattern"](
        action="create", type="convention", domain="testing",
        title="TDD Pattern", observation="Write tests first",
    )
    result = app._tool_functions["gm_pattern"](action="search", domain="testing")
    parsed = json.loads(result)
    assert parsed["total"] > 0
    assert len(parsed["patterns"]) > 0


def test_gm_knowledge_create(app, db):
    result = app._tool_functions["gm_knowledge"](
        action="create",
        entry_type="expertise",
        title="SQL Knowledge",
        content="Use parameterized queries",
    )
    parsed = json.loads(result)
    assert parsed["entry_type"] == "expertise"


def test_gm_knowledge_search(app, db):
    app._tool_functions["gm_knowledge"](
        action="create", entry_type="gotcha",
        title="LEFT JOIN trap", content="LEFT JOINs inflate aggregates",
    )
    result = app._tool_functions["gm_knowledge"](action="search", query="JOIN")
    parsed = json.loads(result)
    assert parsed["total"] > 0
    assert len(parsed["entries"]) > 0


def test_gm_work_create(app, db):
    result = app._tool_functions["gm_work"](
        action="create",
        title="Build MCP server",
        priority=50,
    )
    parsed = json.loads(result)
    assert parsed["title"] == "Build MCP server"
    assert parsed["status"] == "queued"


def test_gm_work_list(app, db):
    app._tool_functions["gm_work"](action="create", title="Task 1")
    result = app._tool_functions["gm_work"](action="list")
    parsed = json.loads(result)
    assert len(parsed) == 1


def test_gm_context(app, db):
    from greymatter_core.standards import StandardsManager
    StandardsManager(db).seed_defaults()
    result = app._tool_functions["gm_context"]()
    parsed = json.loads(result)
    assert "quality_standards" in parsed
    assert "recent_context" in parsed


def test_gm_standards_list(app, db):
    from greymatter_core.standards import StandardsManager
    StandardsManager(db).seed_defaults()
    result = app._tool_functions["gm_standards"](action="list")
    parsed = json.loads(result)
    assert len(parsed) >= 10


def test_gm_docs_list(app, db):
    result = app._tool_functions["gm_docs"](action="list")
    parsed = json.loads(result)
    assert "total" in parsed
    assert "documents" in parsed
    assert isinstance(parsed["documents"], list)


def test_gm_benchmark_summary(app, db):
    result = app._tool_functions["gm_benchmark"](action="summary")
    parsed = json.loads(result)
    assert isinstance(parsed, list)


@pytest.mark.skip(reason="gm_salesos tool not yet implemented")
def test_gm_salesos_search(app, db):
    result = app._tool_functions["gm_salesos"](action="search", account="Nobody")
    parsed = json.loads(result)
    assert parsed["total"] == 0
    assert parsed["meetings"] == []


@pytest.mark.skip(reason="gm_salesos tool not yet implemented")
def test_gm_salesos_semantic_search(app, db):
    db.execute(
        "INSERT INTO salesos_meetings (id, title, summary, transcript, account, date) VALUES (?, ?, ?, ?, ?, ?)",
        ("m1", "Network Review", "Reviewed network", "Discussed Cisco switches", "Acme", "2026-01-15"),
    )
    result = app._tool_functions["gm_salesos"](action="semantic_search", keyword="Cisco switches")
    parsed = json.loads(result)
    assert parsed["total"] >= 1
    assert parsed["meetings"][0]["id"] == "m1"


@pytest.mark.skip(reason="gm_salesos tool not yet implemented")
def test_gm_salesos_influence_map(app, db):
    db.execute(
        "INSERT INTO influence_map (account_name, entity_name, entity_type, relationship) VALUES (?, ?, ?, ?)",
        ("Acme", "Cisco", "Incumbent", "Current vendor"),
    )
    result = app._tool_functions["gm_salesos"](action="influence_map", account="Acme")
    parsed = json.loads(result)
    assert len(parsed) == 1
    assert parsed[0]["entity_name"] == "Cisco"


@pytest.mark.skip(reason="gm_salesos tool not yet implemented")
def test_gm_salesos_analytics(app, db):
    db.execute(
        "INSERT INTO salesos_meetings (id, title, summary, transcript, account, date) VALUES (?, ?, ?, ?, ?, ?)",
        ("m1", "Call", "s", "t", "Acme", "2026-01-01"),
    )
    result = app._tool_functions["gm_salesos"](action="analytics")
    parsed = json.loads(result)
    assert parsed["total_accounts"] >= 1
    assert len(parsed["top_accounts"]) >= 1


def test_gm_semantic_status(app, db):
    """gm_semantic status action should return document-layer and chunk-layer counts."""
    from unittest.mock import patch, MagicMock
    mock_embedder = MagicMock()
    mock_embedder.dimensions = 768

    with patch("greymatter_core.embeddings.OllamaEmbedding", return_value=mock_embedder):
        result = app._tool_functions["gm_semantic"](action="status")
    parsed = json.loads(result)
    assert "document_layer" in parsed
    assert "meetings" in parsed["document_layer"]
    assert "documents" in parsed["document_layer"]
    assert "knowledge" in parsed["document_layer"]
    assert "accounts" in parsed["document_layer"]
    assert "chunk_layer" in parsed
    assert "total_chunks" in parsed["chunk_layer"]


def test_gm_semantic_accepts_detail_parameter(app, db):
    """gm_semantic should accept the detail parameter."""
    from unittest.mock import patch, MagicMock
    mock_embedder = MagicMock()
    mock_embedder.dimensions = 768
    mock_embedder.embed = MagicMock(return_value=[0.0] * 768)
    mock_embedder.embed_batch = MagicMock(return_value=[[0.0] * 768])

    with patch("greymatter_core.embeddings.OllamaEmbedding", return_value=mock_embedder):
        result = app._tool_functions["gm_semantic"](
            action="search", query="test", detail="documents"
        )
    parsed = json.loads(result)
    assert isinstance(parsed, list)


def test_gm_semantic_search_requires_query(app, db):
    """gm_semantic search without query should return error."""
    from unittest.mock import patch, MagicMock
    mock_embedder = MagicMock()
    mock_embedder.dimensions = 768

    with patch("greymatter_core.embeddings.OllamaEmbedding", return_value=mock_embedder):
        result = app._tool_functions["gm_semantic"](action="search")
    parsed = json.loads(result)
    assert "error" in parsed


# --- gm_app_register tests ---

def test_gm_app_register_stores_manifest(app, db):
    """gm_app_register should store the app manifest as a document."""
    agents = json.dumps([
        {"name": "account_analyst", "domains": ["organizational", "procurement"]},
        {"name": "infra_analyst", "domains": ["infrastructure"], "requires_web": True},
    ])
    result = app._tool_functions["gm_app_register"](
        app_name="salesos", version="4.0.0", agents=agents,
    )
    assert "Registered salesos v4.0.0 with 2 agents" in result

    # Verify stored as document (search now returns summary format)
    docs_result = app._tool_functions["gm_docs"](
        action="search", doc_type="app_manifest", project="salesos",
    )
    docs_parsed = json.loads(docs_result)
    assert docs_parsed["total"] >= 1
    # Use get action for full content
    doc_id = docs_parsed["documents"][0]["id"]
    full_doc = json.loads(app._tool_functions["gm_docs"](action="get", doc_id=doc_id))
    stored = json.loads(full_doc["content"])
    assert stored["app"] == "salesos"
    assert len(stored["agents"]) == 2


def test_gm_app_register_rejects_invalid_json(app, db):
    """gm_app_register should reject invalid JSON for agents."""
    result = app._tool_functions["gm_app_register"](
        app_name="salesos", version="4.0.0", agents="not valid json",
    )
    assert "Error" in result


# --- gm_app_dispatch tests ---

def test_gm_app_dispatch_creates_work_item(app, db):
    """gm_app_dispatch should create a work item for tracking."""
    result = app._tool_functions["gm_app_dispatch"](
        app_name="salesos",
        agent_name="infra_analyst",
        task_description="Infrastructure analysis for Test County",
        account_id="acct-001",
        domains="infrastructure",
    )
    parsed = json.loads(result)
    assert "work_item_id" in parsed
    assert parsed["status"] == "dispatched"

    # Verify work item was created (work list is still a flat list)
    work_result = app._tool_functions["gm_work"](action="list")
    work_parsed = json.loads(work_result)
    assert any("salesos:infra_analyst" in w["title"] for w in work_parsed)


# --- Response size optimization tests ---

@pytest.mark.skip(reason="gm_salesos tool not yet implemented")
def test_salesos_search_omits_transcripts(app, db):
    """Search summary should NOT include full transcripts."""
    long_transcript = "x" * 5000
    db.execute(
        "INSERT INTO salesos_meetings (id, title, summary, transcript, account, date) VALUES (?, ?, ?, ?, ?, ?)",
        ("m-big", "Big Meeting", "Short summary", long_transcript, "TestCo", "2026-03-01"),
    )
    result = app._tool_functions["gm_salesos"](action="search", account="TestCo")
    parsed = json.loads(result)
    assert parsed["total"] == 1
    meeting = parsed["meetings"][0]
    assert "transcript" not in meeting
    assert len(json.dumps(meeting)) < 500  # compact response


def test_knowledge_search_truncates_content(app, db):
    """Knowledge search should return content_preview, not full content."""
    long_content = "important " * 500  # 5000 chars
    app._tool_functions["gm_knowledge"](
        action="create", entry_type="expertise",
        title="Big Entry", content=long_content,
    )
    result = app._tool_functions["gm_knowledge"](action="search", query="important")
    parsed = json.loads(result)
    entry = parsed["entries"][0]
    assert "content_preview" in entry
    assert len(entry["content_preview"]) <= 200
    assert "content" not in entry  # full content excluded


def test_pattern_list_omits_observation(app, db):
    """Pattern list should NOT include full observation body."""
    long_obs = "observe " * 500
    app._tool_functions["gm_pattern"](
        action="create", type="convention", domain="test",
        title="Verbose Pattern", observation=long_obs,
    )
    result = app._tool_functions["gm_pattern"](action="list")
    parsed = json.loads(result)
    pattern = parsed["patterns"][0]
    assert "observation" not in pattern
    assert "title" in pattern
    assert "confidence" in pattern


def test_docs_list_truncates_content(app, db):
    """Docs list should return content_preview, not full content."""
    long_content = "design " * 1000
    app._tool_functions["gm_docs"](
        action="create", doc_type="design",
        title="Big Doc", content=long_content,
    )
    result = app._tool_functions["gm_docs"](action="list")
    parsed = json.loads(result)
    doc = parsed["documents"][0]
    assert "content_preview" in doc
    assert len(doc["content_preview"]) <= 200
    assert "content" not in doc  # full content excluded


@pytest.mark.skip(reason="gm_salesos tool not yet implemented")
def test_salesos_accounts_bounded(app, db):
    """Accounts summary should have total count and bounded results."""
    for i in range(30):
        db.execute(
            "INSERT INTO salesos_meetings (id, title, summary, transcript, account, date) VALUES (?, ?, ?, ?, ?, ?)",
            (f"m-{i}", f"Meeting {i}", "s", "t", f"Account-{i:03d}", "2026-01-01"),
        )
    result = app._tool_functions["gm_salesos"](action="accounts")
    parsed = json.loads(result)
    assert parsed["total"] == 30
    assert parsed["returned"] == 25  # default limit
    assert len(parsed["accounts"]) == 25


def test_get_actions_still_return_full_content(app, db):
    """Get actions should still return full content for drill-down."""
    long_content = "detail " * 500
    create_result = app._tool_functions["gm_knowledge"](
        action="create", entry_type="reference",
        title="Full Detail", content=long_content,
    )
    entry = json.loads(create_result)
    get_result = app._tool_functions["gm_knowledge"](action="get", entry_id=entry["id"])
    got = json.loads(get_result)
    assert got["content"] == long_content  # full content preserved


def test_gm_app_dispatch_injects_pattern_context(app, db):
    """gm_app_dispatch should inject relevant patterns as enhanced context."""
    # Seed a pattern in the infrastructure domain
    app._tool_functions["gm_pattern"](
        action="create", type="convention", domain="infrastructure",
        title="Check EOL dates", observation="Always verify equipment end-of-life status",
    )
    result = app._tool_functions["gm_app_dispatch"](
        app_name="salesos",
        agent_name="infra_analyst",
        task_description="Infrastructure analysis",
        domains="infrastructure",
    )
    parsed = json.loads(result)
    # Pattern may or may not appear depending on confidence filter —
    # but the response should be valid JSON with the expected shape
    assert "enhanced_context" in parsed
    assert "work_item_id" in parsed


# --- Budget integration tests ---

def test_gm_pattern_list_budget_minimal(app):
    """Minimal budget returns count only."""
    patterns = app._tool_functions["gm_pattern"]
    # Create a pattern first
    patterns(action="create", type="test", domain="test", title="Budget Test", observation="Testing budget")
    result = json.loads(patterns(action="list", budget="minimal"))
    assert result["budget"] == "minimal"
    assert result["total"] >= 1
    assert "results" not in result
    assert "hint" in result


def test_gm_pattern_list_budget_compact(app):
    """Compact budget returns limited fields."""
    patterns = app._tool_functions["gm_pattern"]
    patterns(action="create", type="test", domain="test", title="Compact Test", observation="Testing compact")
    result = json.loads(patterns(action="list", budget="compact"))
    assert result["budget"] == "compact"
    assert "results" in result
    # Compact should only have id, title, confidence
    if result["results"]:
        keys = set(result["results"][0].keys())
        assert keys == {"id", "title", "confidence"}


def test_gm_pattern_list_budget_full(app):
    """Full budget returns all fields including observation."""
    patterns = app._tool_functions["gm_pattern"]
    patterns(action="create", type="test", domain="test", title="Full Test", observation="Full observation text")
    result = json.loads(patterns(action="list", budget="full"))
    assert result["budget"] == "full"
    assert "results" in result
    if result["results"]:
        assert "observation" in result["results"][0]


def test_gm_pattern_list_no_budget_unchanged(app):
    """No budget parameter preserves existing behavior."""
    patterns = app._tool_functions["gm_pattern"]
    patterns(action="create", type="test", domain="test", title="Default Test", observation="Default behavior")
    result = json.loads(patterns(action="list"))
    # Should have the old format with "patterns" key from list_summary
    assert "patterns" in result


def test_gm_status_budget_minimal(app):
    """Minimal budget on status returns ok only."""
    status = app._tool_functions["gm_status"]
    result = json.loads(status(budget="minimal"))
    assert result["budget"] == "minimal"
    assert result["status"] == "ok"


def test_gm_status_budget_compact(app):
    """Compact budget on status returns summary string."""
    status = app._tool_functions["gm_status"]
    result = json.loads(status(budget="compact"))
    assert result["budget"] == "compact"
    assert "summary" in result


def test_gm_knowledge_budget_minimal(app):
    """Minimal budget on knowledge returns count."""
    knowledge = app._tool_functions["gm_knowledge"]
    knowledge(action="create", entry_type="reference", title="Budget Test", content="Test content")
    result = json.loads(knowledge(action="list", budget="minimal"))
    assert result["budget"] == "minimal"
    assert result["total"] >= 1
    assert "results" not in result


def test_gm_work_budget_minimal(app):
    """Minimal budget on work items returns count."""
    work = app._tool_functions["gm_work"]
    work(action="create", title="Budget Work Test")
    result = json.loads(work(action="list", budget="minimal"))
    assert result["budget"] == "minimal"
    assert result["total"] >= 1
    assert "results" not in result


@pytest.mark.skip(reason="gm_salesos tool not yet implemented")
def test_gm_salesos_budget_compact(app):
    """Compact budget on salesos returns limited fields."""
    salesos = app._tool_functions["gm_salesos"]
    result = json.loads(salesos(action="search", budget="compact"))
    assert result["budget"] == "compact"


def test_gm_pattern_get_ignores_budget(app):
    """Get actions always return full content regardless of budget."""
    patterns = app._tool_functions["gm_pattern"]
    created = json.loads(patterns(action="create", type="test", domain="test", title="Get Test", observation="Full content here"))
    pid = created["id"]
    result = json.loads(patterns(action="get", pattern_id=pid, budget="minimal"))
    # Get should return full content even with minimal budget
    assert result["id"] == pid
    assert result["observation"] == "Full content here"


# --- gm_checkpoint tests ---

def test_gm_checkpoint_save(app, db):
    """gm_checkpoint save should create a checkpoint for the current session."""
    result = app._tool_functions["gm_checkpoint"](
        action="save",
        context_summary="Working on MCP server implementation",
        open_items='[{"id": "wi-001", "title": "Build checkpoint tool"}]',
    )
    parsed = json.loads(result)
    assert "checkpoint_id" in parsed
    assert "session_id" in parsed
    assert "checkpoint_at" in parsed
    assert parsed["checkpoint_id"].startswith("cp-")


def test_gm_checkpoint_restore(app, db):
    """gm_checkpoint restore should return the latest checkpoint."""
    # First save a checkpoint
    save_result = app._tool_functions["gm_checkpoint"](
        action="save",
        context_summary="Context before compaction",
        open_items='[{"id": "wi-002", "title": "Fix tests"}]',
    )
    save_parsed = json.loads(save_result)
    session_id = save_parsed["session_id"]

    # Now restore
    result = app._tool_functions["gm_checkpoint"](
        action="restore",
        session_id=session_id,
    )
    parsed = json.loads(result)
    assert parsed["context_summary"] == "Context before compaction"
    assert parsed["open_items"] == '[{"id": "wi-002", "title": "Fix tests"}]'
    assert parsed["session_id"] == session_id


def test_gm_checkpoint_list(app, db):
    """gm_checkpoint list should return recent checkpoints."""
    # Save two checkpoints
    app._tool_functions["gm_checkpoint"](
        action="save",
        context_summary="First checkpoint",
    )
    app._tool_functions["gm_checkpoint"](
        action="save",
        context_summary="Second checkpoint",
    )

    result = app._tool_functions["gm_checkpoint"](action="list")
    parsed = json.loads(result)
    assert "total" in parsed
    assert "checkpoints" in parsed
    assert parsed["total"] >= 2
    assert len(parsed["checkpoints"]) >= 2


# --- gm_observe tests ---

def test_gm_observe_list(app):
    gm_observe = app._tool_functions["gm_observe"]
    result = json.loads(gm_observe())
    assert "total" in result
    assert "results" in result


def test_gm_observe_create(app):
    gm_observe = app._tool_functions["gm_observe"]
    result = json.loads(gm_observe(
        action="create",
        title="Test observation",
        content="Test content",
        category="decision",
    ))
    assert result["id"].startswith("obs-")
    assert result["category"] == "decision"


def test_gm_observe_get(app):
    gm_observe = app._tool_functions["gm_observe"]
    # First create one
    created = json.loads(gm_observe(
        action="create",
        title="Test get",
        content="Content",
        category="insight",
    ))
    # Then get it
    result = json.loads(gm_observe(
        action="get",
        observation_id=created["id"],
    ))
    assert result["id"] == created["id"]
    assert result["content"] == "Content"


def test_gm_observe_confirm(app):
    gm_observe = app._tool_functions["gm_observe"]
    created = json.loads(gm_observe(
        action="create",
        title="Test confirm",
        content="Content",
        category="pattern",
    ))
    result = json.loads(gm_observe(
        action="confirm",
        observation_id=created["id"],
    ))
    assert result["confidence"] > created["confidence"]


def test_gm_observe_prune(app):
    gm_observe = app._tool_functions["gm_observe"]
    created = json.loads(gm_observe(
        action="create",
        title="Test prune",
        content="Content",
        category="correction",
    ))
    result = json.loads(gm_observe(
        action="prune",
        observation_id=created["id"],
    ))
    assert result["status"] == "pruned"


def test_gm_observe_create_missing_fields(app):
    gm_observe = app._tool_functions["gm_observe"]
    result = json.loads(gm_observe(action="create", title="Missing content"))
    assert "error" in result


def test_gm_status_includes_observations(app):
    gm_status = app._tool_functions["gm_status"]
    result = json.loads(gm_status())
    assert "observations" in result


# --- gm_security tests ---

def test_gm_security_registered(app):
    """gm_security tool should be registered."""
    assert "gm_security" in app._tool_functions


def test_gm_security_classify(app):
    """classify action should detect PII in text."""
    gm_security = app._tool_functions["gm_security"]
    result = json.loads(gm_security(
        action="classify",
        content="Contact admin@school.edu about SSN 123-45-6789",
    ))
    if "error" in result:
        pytest.skip("Security module not available")
    assert "detections" in result
    assert "summary" in result
    types = {d["entity_type"] for d in result["detections"]}
    assert "SSN" in types
    assert "EMAIL" in types


def test_gm_security_classify_truncates_values(app):
    """classify should truncate detected values for safety."""
    gm_security = app._tool_functions["gm_security"]
    result = json.loads(gm_security(
        action="classify",
        content="SSN 123-45-6789",
    ))
    if "error" in result:
        pytest.skip("Security module not available")
    for det in result["detections"]:
        assert det["value"].endswith("***")
        assert len(det["value"]) <= 6  # 3 chars + "***"


def test_gm_security_protect_tokenize(app):
    """protect action should replace sensitive data with tokens."""
    gm_security = app._tool_functions["gm_security"]
    result = json.loads(gm_security(
        action="protect",
        content="Email: admin@school.edu SSN: 123-45-6789",
    ))
    if "error" in result:
        pytest.skip("Security module not available")
    assert "protected_text" in result
    assert "123-45-6789" not in result["protected_text"]
    assert "admin@school.edu" not in result["protected_text"]
    assert result["items_protected"] >= 2


def test_gm_security_protect_redact_mode(app):
    """protect with mode=redact should use type placeholders."""
    gm_security = app._tool_functions["gm_security"]
    result = json.loads(gm_security(
        action="protect",
        content="SSN 123-45-6789",
        mode="redact",
    ))
    if "error" in result:
        pytest.skip("Security module not available")
    assert "[SSN]" in result["protected_text"]
    assert result["mode"] == "redact"


def test_gm_security_restore(app):
    """restore action should detokenize protected text."""
    gm_security = app._tool_functions["gm_security"]
    # First protect
    protected = json.loads(gm_security(
        action="protect",
        content="SSN 123-45-6789",
    ))
    if "error" in protected:
        pytest.skip("Security module not available")
    # Then restore
    restored = json.loads(gm_security(
        action="restore",
        content=protected["protected_text"],
    ))
    assert "123-45-6789" in restored["restored_text"]
    assert restored["tokens_restored"] is True


def test_gm_security_audit(app):
    """audit action should return stats."""
    gm_security = app._tool_functions["gm_security"]
    # Do a protect first to generate audit data
    gm_security(action="protect", content="SSN 123-45-6789")
    result = json.loads(gm_security(action="audit"))
    if "error" in result:
        pytest.skip("Security module not available")
    assert "total_events" in result
    assert "total_items_masked" in result


@pytest.mark.skip(reason="report action not yet implemented")
def test_gm_security_report_requires_framework(app):
    """report action without framework should return error."""
    gm_security = app._tool_functions["gm_security"]
    result = json.loads(gm_security(action="report"))
    if "error" in result and "Security module" in result["error"]:
        pytest.skip("Security module not available")
    assert "error" in result
    assert "framework" in result["error"]


@pytest.mark.skip(reason="report action not yet implemented")
def test_gm_security_report_ferpa(app):
    """report with FERPA framework should return compliance report."""
    gm_security = app._tool_functions["gm_security"]
    # Generate some FERPA-relevant audit data
    gm_security(action="protect", content="Student SSN 123-45-6789 email student@school.edu")
    result = json.loads(gm_security(action="report", framework="FERPA"))
    if "error" in result and "Security module" in result["error"]:
        pytest.skip("Security module not available")
    assert result["framework"] == "FERPA"
    assert "total_events" in result


def test_gm_security_classify_missing_text(app):
    """classify without text should return error."""
    gm_security = app._tool_functions["gm_security"]
    result = json.loads(gm_security(action="classify"))
    assert "error" in result


def test_gm_security_unknown_action(app):
    """Unknown action should return error."""
    gm_security = app._tool_functions["gm_security"]
    result = json.loads(gm_security(action="invalid"))
    assert "error" in result
    assert "Unknown action" in result["error"]
