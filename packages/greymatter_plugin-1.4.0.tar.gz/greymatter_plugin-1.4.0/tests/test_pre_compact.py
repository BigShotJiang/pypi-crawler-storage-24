"""Tests for PreCompact hook: sparse checkpoints + consolidation cycle.

Tests cover:
- Sparse checkpoint behavior (existing)
- Observation extraction from conversation text
- Consolidation cycle (decay + cross-session)
- Conversation state capture
- Metamemory signal generation
"""
import json
import pytest
from unittest.mock import patch

from greymatter_core.db import SQLiteDatabase
from greymatter_core.sessions import SessionManager
from greymatter_core.work_items import WorkItemManager
from cognitive import MemorySystem


@pytest.fixture
def db():
    database = SQLiteDatabase(":memory:")
    yield database
    database.close()


@pytest.fixture
def memory(db):
    """Create a MemorySystem backed by the test's in-memory DB, patched as the singleton."""
    mem = MemorySystem(db_path=":memory:", license_key="test")
    # Share the test DB's connection for observations table access
    # The MemorySystem has its own DB, but we need observations readable by both
    with patch("greymatter_core.cognitive_bridge.get_memory", return_value=mem):
        yield mem


@pytest.fixture(autouse=True)
def _patch_memory(memory):
    """Auto-patch get_memory for all tests in this module."""
    with patch("greymatter_core.cognitive_bridge.get_memory", return_value=memory):
        yield


@pytest.fixture
def sessions(db):
    return SessionManager(db)


@pytest.fixture
def work_items(db):
    return WorkItemManager(db)


def _add_hook_paths():
    """Add hook and lib paths for imports."""
    import sys
    import os
    hooks_dir = os.path.join(
        os.path.dirname(__file__), "..", "..", "plugin", "hooks"
    )
    lib_dir = os.path.join(
        os.path.dirname(__file__), "..", "..", "lib"
    )
    if hooks_dir not in sys.path:
        sys.path.insert(0, os.path.abspath(hooks_dir))
    if lib_dir not in sys.path:
        sys.path.insert(0, os.path.abspath(lib_dir))


def _build_checkpoint(db):
    """Helper to call the hook's build function."""
    _add_hook_paths()
    from pre_compact import build_sparse_checkpoint
    return build_sparse_checkpoint(db)


# --- Tier 1: Unit Tests ---


class TestSparseCheckpoint:
    """Verify checkpoints are sparse and bounded."""

    def test_checkpoint_created_with_no_work_items(self, db, sessions):
        """When no work items exist, checkpoint still works."""
        sessions.start()
        result = _build_checkpoint(db)
        assert "checkpoint" in result
        assert "compaction_number" in result
        assert result["open_work_items"] == 0
        assert result["compaction_number"] == 1

    def test_checkpoint_includes_work_item_ids(self, db, sessions, work_items):
        """Work items in progress are captured with id and title."""
        sessions.start()
        wi = work_items.create(title="Build MCP server", priority=50)
        work_items.update_status(wi["id"], "in_progress")

        result = _build_checkpoint(db)
        assert result["open_work_items"] == 1

        # Verify the checkpoint stored sparse work items
        cp = result["checkpoint"]
        session_id = cp["session_id"]
        stored = sessions.get_latest_checkpoint(session_id)
        items = json.loads(stored["open_items"])
        assert len(items) == 1
        assert items[0]["id"] == wi["id"]
        assert items[0]["title"] == "Build MCP server"

    def test_checkpoint_caps_at_10_work_items(self, db, sessions, work_items):
        """Only the first 10 work items are included in checkpoint."""
        sessions.start()
        for i in range(15):
            wi = work_items.create(title=f"Task {i}", priority=50)
            work_items.update_status(wi["id"], "in_progress")

        result = _build_checkpoint(db)
        assert result["open_work_items"] == 15  # total count is accurate

        # But the stored checkpoint only has 10
        cp = result["checkpoint"]
        stored = sessions.get_latest_checkpoint(cp["session_id"])
        items = json.loads(stored["open_items"])
        assert len(items) <= 10

    def test_checkpoint_truncates_long_titles(self, db, sessions, work_items):
        """Work item titles are truncated to 80 chars in checkpoint."""
        sessions.start()
        long_title = "A" * 200
        wi = work_items.create(title=long_title, priority=50)
        work_items.update_status(wi["id"], "in_progress")

        result = _build_checkpoint(db)
        cp = result["checkpoint"]
        stored = sessions.get_latest_checkpoint(cp["session_id"])
        items = json.loads(stored["open_items"])
        assert len(items[0]["title"]) <= 80

    def test_compaction_counter_increments(self, db, sessions):
        """Each checkpoint increments the compaction counter."""
        sessions.start()

        result1 = _build_checkpoint(db)
        assert result1["compaction_number"] == 1

        result2 = _build_checkpoint(db)
        assert result2["compaction_number"] == 2

        result3 = _build_checkpoint(db)
        assert result3["compaction_number"] == 3

    def test_checkpoint_context_summary_is_brief(self, db, sessions):
        """The context summary should be a short string."""
        sessions.start()
        result = _build_checkpoint(db)
        cp = result["checkpoint"]
        stored = sessions.get_latest_checkpoint(cp["session_id"])
        summary = stored["context_summary"]
        assert len(summary) < 100
        assert "compaction" in summary.lower()

    def test_checkpoint_open_items_serialized_size_bounded(self, db, sessions, work_items):
        """Total serialized open_items should not exceed 500 chars."""
        sessions.start()
        # Create work items with long titles
        for i in range(10):
            wi = work_items.create(
                title=f"Very long work item title for task number {i} with extra description text",
                priority=50,
            )
            work_items.update_status(wi["id"], "in_progress")

        result = _build_checkpoint(db)
        cp = result["checkpoint"]
        stored = sessions.get_latest_checkpoint(cp["session_id"])
        open_items_str = stored["open_items"]
        # The hook caps at 500 chars or falls back to IDs only
        assert len(open_items_str) <= 600  # Allow small margin


# --- Tier 1: Extraction Tests ---


SAMPLE_CONVERSATION = """
user: We decided to use SQLite for the local database with WAL mode enabled.

assistant: Good choice. WAL mode allows concurrent reads during writes
which is ideal for multi-process scenarios. I'll update the config.

user: Actually, the config path should be ~/.greymatter/config.yaml not ~/.greymatter/config.json.

assistant: You're right, that's a correction. I'll fix that in lib/config.py.
We should always use YAML for human-editable config files.

user: Remember to always run tests before committing.
"""


class TestExtractionFromConversation:
    """Verify observation extraction from conversation text."""

    def test_extract_produces_observations(self, db, sessions):
        """Extraction pipeline should find observations in sample conversation."""
        _add_hook_paths()
        from pre_compact import extract_observations

        session = sessions.start()
        obs = extract_observations(db, session["id"], SAMPLE_CONVERSATION)

        assert len(obs) > 0
        categories = {o["category"] for o in obs}
        # Should find at least decisions and corrections
        assert len(categories) >= 1

    def test_extract_empty_conversation(self, db, sessions):
        """Empty conversation produces no observations."""
        _add_hook_paths()
        from pre_compact import extract_observations

        session = sessions.start()
        obs = extract_observations(db, session["id"], "")
        assert obs == []

    def test_extract_short_conversation(self, db, sessions):
        """Very short text produces no observations."""
        _add_hook_paths()
        from pre_compact import extract_observations

        session = sessions.start()
        obs = extract_observations(db, session["id"], "hello")
        assert obs == []

    def test_extracted_observations_stored_in_db(self, db, sessions, memory):
        """Extracted observations should be persisted in the database."""
        _add_hook_paths()
        from pre_compact import extract_observations

        session = sessions.start()
        obs = extract_observations(db, session["id"], SAMPLE_CONVERSATION)

        # Verify through cognitive's DB
        stored = memory.db.execute(
            "SELECT * FROM observations WHERE pruned = 0 AND session_id = ?",
            (session["id"],),
        )
        assert len(stored) == len(obs)

    def test_extracted_observations_have_pre_compact_source(self, db, sessions, memory):
        """All extracted observations should have source='pre_compact'."""
        _add_hook_paths()
        from pre_compact import extract_observations

        session = sessions.start()
        obs = extract_observations(db, session["id"], SAMPLE_CONVERSATION)

        for o in obs:
            # cognitive stores source in the 'trigger' column (legacy name)
            assert o.get("trigger") == "pre_compact" or o.get("source_tool") == "pre_compact"


# --- Tier 1: Consolidation Tests ---


class TestConsolidationCycle:
    """Verify consolidation runs during compaction."""

    def test_consolidation_runs_without_error(self, db):
        """Consolidation cycle should complete even with no data."""
        _add_hook_paths()
        from pre_compact import run_consolidation

        result = run_consolidation(db)

        assert "decay" in result
        assert "consolidation" in result

    def test_consolidation_decay_runs(self, db, sessions):
        """Decay cycle should run and return stats."""
        _add_hook_paths()
        from pre_compact import run_consolidation

        sessions.start()
        result = run_consolidation(db)

        # Should have decay stats (even if 0 decayed)
        assert isinstance(result["decay"], dict)


# --- Tier 1: Conversation State Tests ---


class TestConversationStateCapture:
    """Verify structured state extraction from conversation."""

    def test_captures_file_paths(self):
        """Should extract file paths from conversation."""
        _add_hook_paths()
        from pre_compact import capture_conversation_state

        text = "I modified lib/config.py and tests/test_config.py to add budget support."
        state = capture_conversation_state(text)

        assert "recent_files" in state
        assert any("config.py" in f for f in state["recent_files"])

    def test_captures_current_task(self):
        """Should detect task/goal from conversation."""
        _add_hook_paths()
        from pre_compact import capture_conversation_state

        text = "We are working on implementing the budget config system for GreyMatter."
        state = capture_conversation_state(text)

        assert "current_task" in state

    def test_empty_conversation_returns_empty(self):
        """Empty conversation should return empty state."""
        _add_hook_paths()
        from pre_compact import capture_conversation_state

        state = capture_conversation_state("")
        assert state == {}


# --- Tier 1: Metamemory Tests ---


class TestMetamemorySignals:
    """Verify metamemory output for post-compaction context."""

    def test_builds_signals_from_observations(self):
        """Should describe extracted observations."""
        _add_hook_paths()
        from pre_compact import build_metamemory_signals

        obs = [
            {"category": "decision"},
            {"category": "decision"},
            {"category": "correction"},
        ]
        consolidation = {"decay": {}, "consolidation": {}}
        signals = build_metamemory_signals(obs, consolidation)

        assert "3 observations" in signals
        assert "decision" in signals

    def test_includes_promotion_count(self):
        """Should mention promoted observations."""
        _add_hook_paths()
        from pre_compact import build_metamemory_signals

        obs = [{"category": "pattern"}]
        consolidation = {"decay": {}, "consolidation": {"promoted": 2}}
        signals = build_metamemory_signals(obs, consolidation)

        assert "Promoted 2" in signals

    def test_includes_decay_stats(self):
        """Should mention decay and pruning."""
        _add_hook_paths()
        from pre_compact import build_metamemory_signals

        consolidation = {"decay": {"decayed": 5, "pruned": 1}, "consolidation": {}}
        signals = build_metamemory_signals([], consolidation)

        assert "5 decayed" in signals
        assert "1 pruned" in signals

    def test_empty_when_nothing_happened(self):
        """No observations + no consolidation = empty string."""
        _add_hook_paths()
        from pre_compact import build_metamemory_signals

        signals = build_metamemory_signals([], {"decay": {}, "consolidation": {}})
        assert signals == ""
