"""Tests for async extraction runner."""
import os
import sys
import pytest
from unittest.mock import patch, MagicMock

# Add paths
_hooks_dir = os.path.join(os.path.dirname(__file__), "..", "hooks")
_core_dir = os.path.join(os.path.dirname(__file__), "..", "..", "core", "src")
_cognitive_dir = os.path.join(os.path.dirname(__file__), "..", "..", "cognitive", "src")
for d in [_hooks_dir, _core_dir, _cognitive_dir]:
    if d not in sys.path:
        sys.path.insert(0, os.path.abspath(d))


class TestRunExtraction:
    """Verify the extraction runner processes text and stores observations."""

    @patch("greymatter_core.cognitive_bridge.get_memory")
    @patch("greymatter_core.llm_gateway.OllamaLLM")
    def test_extracts_and_stores(self, MockLLM, mock_get_memory):
        from run_extraction import run_extraction

        mock_memory = MagicMock()
        mock_memory.observe.return_value = {"id": "obs-test"}
        mock_get_memory.return_value = mock_memory

        mock_llm_instance = MockLLM.return_value
        mock_llm_instance.is_available.return_value = False  # force heuristic

        text = "We decided to use PostgreSQL. Let's go with REST for the API."
        count = run_extraction("test-session", text)
        assert count >= 1
        assert mock_memory.observe.called

    @patch("greymatter_core.cognitive_bridge.get_memory")
    def test_handles_empty_text(self, mock_get_memory):
        from run_extraction import run_extraction

        count = run_extraction("test-session", "")
        assert count == 0

    @patch("greymatter_core.cognitive_bridge.get_memory")
    def test_handles_short_text(self, mock_get_memory):
        from run_extraction import run_extraction

        count = run_extraction("test-session", "hello")
        assert count == 0
