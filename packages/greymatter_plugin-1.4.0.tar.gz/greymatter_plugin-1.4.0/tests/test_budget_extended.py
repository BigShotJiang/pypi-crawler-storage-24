"""Extended budget formatter tests — all tool actions, savings metadata, edge cases."""
import json
import pytest

from greymatter_plugin.budget import (
    BudgetLevel,
    BudgetFormatter,
    TOOL_FIELDS,
    MINIMAL_HINTS,
    CHARS_PER_TOKEN,
)


# --- Savings metadata ---

class TestSavingsMetadata:
    SAMPLE = [{"id": f"x-{i}", "title": f"Item {i}", "content": "x" * 200} for i in range(5)]

    def test_full_budget_has_savings(self):
        result = BudgetFormatter.format_response(self.SAMPLE, BudgetLevel.FULL, "pattern_list")
        assert "_savings" in result
        assert "tokens_returned" in result["_savings"]
        assert "tokens_avoided" in result["_savings"]
        assert "reduction_pct" in result["_savings"]
        assert result["_savings"]["method"] == "budget_format"

    def test_minimal_has_highest_reduction(self):
        full = BudgetFormatter.format_response(self.SAMPLE, BudgetLevel.FULL, "pattern_list")
        minimal = BudgetFormatter.format_response(self.SAMPLE, BudgetLevel.MINIMAL, "pattern_list")
        assert minimal["_savings"]["reduction_pct"] > full["_savings"]["reduction_pct"]

    def test_compact_smaller_than_normal(self):
        import json
        normal = BudgetFormatter.format_response(self.SAMPLE, BudgetLevel.NORMAL, "pattern_list")
        compact = BudgetFormatter.format_response(self.SAMPLE, BudgetLevel.COMPACT, "pattern_list")
        # Compact results should have fewer fields than normal
        normal_results_size = len(json.dumps(normal["results"]))
        compact_results_size = len(json.dumps(compact["results"]))
        assert compact_results_size <= normal_results_size

    def test_tokens_returned_positive(self):
        result = BudgetFormatter.format_response(self.SAMPLE, BudgetLevel.NORMAL, "pattern_list")
        assert result["_savings"]["tokens_returned"] > 0

    def test_empty_input_no_division_error(self):
        result = BudgetFormatter.format_response([], BudgetLevel.MINIMAL, "pattern_list")
        assert "_savings" in result
        assert result["_savings"]["reduction_pct"] >= 0


# --- All tool actions ---

class TestAllToolActions:
    """Verify format_response works with every configured tool action."""

    GENERIC_DATA = [
        {"id": "x-1", "type": "test", "domain": "test", "title": "Title 1",
         "observation": "obs", "confidence": "high", "confirmations": 1,
         "created_at": "2026-01-01", "content": "content", "content_preview": "preview",
         "entry_type": "ref", "scope": "cross-cutting", "status": "queued",
         "priority": 10, "domain_tags": "tag", "date": "2026-01-01",
         "account": "Acme", "summary_preview": "summary", "meeting_count": 5,
         "latest_meeting": "2026-01-01", "doc_type": "design", "project": "gm",
         "source_id": "s-1", "source_table": "patterns", "chunk_text": "chunk",
         "score": 0.9, "session_id": "sess-1", "trigger": "api", "category": "insight",
         "repo": "gm", "language": "python", "kind": "function", "name": "foo",
         "qualified_name": "mod.foo", "signature": "def foo()"},
    ]

    @pytest.mark.parametrize("tool_action", list(TOOL_FIELDS.keys()))
    def test_normal_budget(self, tool_action):
        result = BudgetFormatter.format_response(self.GENERIC_DATA, BudgetLevel.NORMAL, tool_action)
        assert result["budget"] == "normal"
        assert result["returned"] == 1
        fields = TOOL_FIELDS[tool_action][BudgetLevel.NORMAL]
        if fields is not None:
            assert set(result["results"][0].keys()) == set(fields)

    @pytest.mark.parametrize("tool_action", list(TOOL_FIELDS.keys()))
    def test_compact_budget(self, tool_action):
        result = BudgetFormatter.format_response(self.GENERIC_DATA, BudgetLevel.COMPACT, tool_action)
        assert result["budget"] == "compact"
        fields = TOOL_FIELDS[tool_action][BudgetLevel.COMPACT]
        if fields is not None:
            assert set(result["results"][0].keys()) == set(fields)

    @pytest.mark.parametrize("tool_action", list(TOOL_FIELDS.keys()))
    def test_minimal_budget(self, tool_action):
        result = BudgetFormatter.format_response(self.GENERIC_DATA, BudgetLevel.MINIMAL, tool_action)
        assert result["budget"] == "minimal"
        assert "results" not in result
        assert result["total"] == 1

    @pytest.mark.parametrize("tool_action", list(TOOL_FIELDS.keys()))
    def test_full_budget_passes_through(self, tool_action):
        result = BudgetFormatter.format_response(self.GENERIC_DATA, BudgetLevel.FULL, tool_action)
        assert result["budget"] == "full"
        assert result["results"] == self.GENERIC_DATA


# --- Edge cases ---

class TestEdgeCases:
    def test_empty_results_list(self):
        result = BudgetFormatter.format_response([], BudgetLevel.NORMAL, "pattern_list")
        assert result["total"] == 0
        assert result["returned"] == 0
        assert result["results"] == []

    def test_total_override(self):
        data = [{"id": "p-1", "title": "T"}]
        result = BudgetFormatter.format_response(data, BudgetLevel.FULL, "pattern_list", total=999)
        assert result["total"] == 999
        assert result["returned"] == 1

    def test_format_single_with_all_budgets(self):
        item = {"id": "p-1", "title": "Test", "observation": "Full text"}
        for level in BudgetLevel:
            result = BudgetFormatter.format_single(item, level)
            assert result == item  # Always returns full item

    def test_format_status_full_passthrough(self):
        status = {"patterns": {"total": 10}, "knowledge": {"total": 5}}
        result = BudgetFormatter.format_status(status, BudgetLevel.FULL)
        assert result == status

    def test_format_status_normal_passthrough(self):
        status = {"patterns": {"total": 10}}
        result = BudgetFormatter.format_status(status, BudgetLevel.NORMAL)
        assert result == status

    def test_large_dataset_performance(self):
        large = [{"id": f"p-{i}", "title": f"P{i}", "type": "t", "domain": "d",
                   "confidence": "low", "confirmations": 0, "created_at": "2026-01-01",
                   "observation": "x" * 1000} for i in range(100)]
        result = BudgetFormatter.format_response(large, BudgetLevel.COMPACT, "pattern_list")
        assert result["returned"] == 100
        # Compact should not include observation field
        assert "observation" not in result["results"][0]


# --- CHARS_PER_TOKEN constant ---

class TestCharsPerToken:
    def test_chars_per_token_value(self):
        assert CHARS_PER_TOKEN == 4

    def test_token_calculation(self):
        text = "a" * 100
        expected_tokens = 100 // CHARS_PER_TOKEN
        assert expected_tokens == 25


# --- Minimal hints domain coverage ---

class TestMinimalHintsDomains:
    @pytest.mark.parametrize("tool_action", list(TOOL_FIELDS.keys()))
    def test_tool_domain_has_hint(self, tool_action):
        domain = tool_action.split("_")[0]
        assert domain in MINIMAL_HINTS, f"No hint for domain '{domain}' (from tool '{tool_action}')"
