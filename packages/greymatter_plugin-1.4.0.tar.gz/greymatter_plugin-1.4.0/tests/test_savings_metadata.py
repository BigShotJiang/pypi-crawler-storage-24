"""Tests for token savings metadata on BudgetFormatter responses."""
import json

from greymatter_plugin.budget import BudgetFormatter, BudgetLevel


def test_format_response_includes_savings():
    results = [{"id": "1", "title": "Test", "content": "Long content " * 50}]
    resp = BudgetFormatter.format_response(results, BudgetLevel.NORMAL, "knowledge_search")
    assert "_savings" in resp
    assert "tokens_returned" in resp["_savings"]
    assert "tokens_avoided" in resp["_savings"]
    assert "reduction_pct" in resp["_savings"]
    assert resp["_savings"]["method"] == "budget_format"


def test_savings_compact_reduces_more_than_normal():
    results = [{"id": str(i), "title": f"Item {i}", "content": f"{'x' * 200}"} for i in range(10)]
    normal = BudgetFormatter.format_response(results, BudgetLevel.NORMAL, "knowledge_search")
    compact = BudgetFormatter.format_response(results, BudgetLevel.COMPACT, "knowledge_search")
    assert compact["_savings"]["reduction_pct"] >= normal["_savings"]["reduction_pct"]


def test_savings_minimal_has_high_reduction():
    results = [{"id": str(i), "title": f"Item {i}", "content": f"{'x' * 500}"} for i in range(20)]
    resp = BudgetFormatter.format_response(results, BudgetLevel.MINIMAL, "knowledge_search")
    assert "_savings" in resp
    assert resp["_savings"]["reduction_pct"] > 50


def test_savings_full_has_zero_or_low_reduction():
    results = [{"id": "1", "title": "Test"}]
    resp = BudgetFormatter.format_response(results, BudgetLevel.FULL, "knowledge_search")
    assert "_savings" in resp
    # FULL returns all fields, so reduction is minimal (just from metadata overhead)


def test_savings_empty_results():
    resp = BudgetFormatter.format_response([], BudgetLevel.NORMAL, "knowledge_search")
    assert "_savings" in resp
    assert resp["_savings"]["tokens_returned"] >= 0
