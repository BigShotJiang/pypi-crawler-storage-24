"""Tests for budget-aware response formatting."""
import pytest

from greymatter_plugin.budget import BudgetLevel, BudgetFormatter, TOOL_FIELDS, MINIMAL_HINTS


class TestBudgetLevel:
    def test_parse_valid_values(self):
        assert BudgetLevel.parse("full") == BudgetLevel.FULL
        assert BudgetLevel.parse("normal") == BudgetLevel.NORMAL
        assert BudgetLevel.parse("compact") == BudgetLevel.COMPACT
        assert BudgetLevel.parse("minimal") == BudgetLevel.MINIMAL

    def test_parse_case_insensitive(self):
        assert BudgetLevel.parse("FULL") == BudgetLevel.FULL
        assert BudgetLevel.parse("Normal") == BudgetLevel.NORMAL
        assert BudgetLevel.parse("  compact  ") == BudgetLevel.COMPACT

    def test_parse_none_defaults_to_normal(self):
        assert BudgetLevel.parse(None) == BudgetLevel.NORMAL

    def test_parse_unknown_defaults_to_normal(self):
        assert BudgetLevel.parse("invalid") == BudgetLevel.NORMAL
        assert BudgetLevel.parse("") == BudgetLevel.NORMAL
        assert BudgetLevel.parse("verbose") == BudgetLevel.NORMAL


class TestBudgetFormatter:
    SAMPLE_PATTERNS = [
        {"id": "p1", "type": "debugging", "domain": "infra", "title": "Pattern 1",
         "observation": "Full observation text here", "confidence": "high",
         "confirmations": 5, "created_at": "2026-03-01"},
        {"id": "p2", "type": "performance", "domain": "api", "title": "Pattern 2",
         "observation": "Another full observation", "confidence": "medium",
         "confirmations": 2, "created_at": "2026-03-02"},
    ]

    def test_full_budget_returns_all_fields(self):
        result = BudgetFormatter.format_response(
            self.SAMPLE_PATTERNS, BudgetLevel.FULL, "pattern_list"
        )
        assert result["total"] == 2
        assert result["returned"] == 2
        assert result["budget"] == "full"
        assert "observation" in result["results"][0]

    def test_normal_budget_filters_fields(self):
        result = BudgetFormatter.format_response(
            self.SAMPLE_PATTERNS, BudgetLevel.NORMAL, "pattern_list"
        )
        assert result["total"] == 2
        assert result["budget"] == "normal"
        assert "observation" not in result["results"][0]
        assert "id" in result["results"][0]
        assert "title" in result["results"][0]

    def test_compact_budget_minimal_fields(self):
        result = BudgetFormatter.format_response(
            self.SAMPLE_PATTERNS, BudgetLevel.COMPACT, "pattern_list"
        )
        assert result["budget"] == "compact"
        assert set(result["results"][0].keys()) == {"id", "title", "confidence"}

    def test_minimal_budget_count_only(self):
        result = BudgetFormatter.format_response(
            self.SAMPLE_PATTERNS, BudgetLevel.MINIMAL, "pattern_list"
        )
        assert result["total"] == 2
        assert result["budget"] == "minimal"
        assert "results" not in result
        assert "hint" in result

    def test_minimal_budget_uses_provided_total(self):
        result = BudgetFormatter.format_response(
            [], BudgetLevel.MINIMAL, "pattern_list", total=42
        )
        assert result["total"] == 42

    def test_format_single_always_returns_full(self):
        item = {"id": "p1", "title": "Test", "observation": "Full text"}
        result = BudgetFormatter.format_single(item, BudgetLevel.MINIMAL)
        assert result == item

    def test_format_single_none_returns_error(self):
        result = BudgetFormatter.format_single(None, BudgetLevel.NORMAL)
        assert result == {"error": "Not found"}

    def test_format_status_minimal(self):
        status = {"patterns": {"total": 10}, "knowledge": {"total": 20}}
        result = BudgetFormatter.format_status(status, BudgetLevel.MINIMAL)
        assert result["budget"] == "minimal"
        assert "status" in result

    def test_format_status_compact(self):
        status = {"patterns": {"total": 10}, "knowledge": {"total": 20}}
        result = BudgetFormatter.format_status(status, BudgetLevel.COMPACT)
        assert result["budget"] == "compact"
        assert "summary" in result

    def test_format_status_normal(self):
        status = {"patterns": {"total": 10}}
        result = BudgetFormatter.format_status(status, BudgetLevel.NORMAL)
        assert "counts" not in result or result == status

    def test_unknown_tool_action_passes_through(self):
        data = [{"a": 1, "b": 2}]
        result = BudgetFormatter.format_response(data, BudgetLevel.COMPACT, "unknown_tool")
        assert result["results"] == data  # no filtering when no config


class TestToolFieldsCoverage:
    """Verify all tool actions have configs for all budget levels."""

    def test_all_tools_have_all_levels(self):
        for tool_action, config in TOOL_FIELDS.items():
            for level in BudgetLevel:
                assert level in config, f"{tool_action} missing config for {level}"

    def test_full_level_always_none(self):
        """Full budget should always pass through all fields."""
        for tool_action, config in TOOL_FIELDS.items():
            assert config[BudgetLevel.FULL] is None, f"{tool_action} FULL should be None"

    def test_minimal_level_always_empty(self):
        """Minimal budget should always be count-only (empty list)."""
        for tool_action, config in TOOL_FIELDS.items():
            assert config[BudgetLevel.MINIMAL] == [], f"{tool_action} MINIMAL should be []"


class TestMinimalHints:
    def test_all_domains_have_hints(self):
        expected_domains = {"pattern", "knowledge", "work", "salesos", "docs", "semantic", "observation", "code"}
        assert set(MINIMAL_HINTS.keys()) == expected_domains

    def test_hints_contain_action_info(self):
        for domain, hint in MINIMAL_HINTS.items():
            assert "action" in hint.lower() or "budget" in hint.lower(), (
                f"{domain} hint missing action/budget guidance: {hint}"
            )


class TestResponseSizes:
    """Verify budget levels produce progressively smaller responses."""

    LARGE_DATASET = [
        {"id": f"item-{i}", "title": f"Item {i}", "type": "test",
         "domain": "test", "content": "x" * 500, "observation": "y" * 500,
         "confidence": "high", "confirmations": i, "created_at": "2026-01-01"}
        for i in range(25)
    ]

    def test_response_size_decreases_with_budget(self):
        import json

        sizes = {}
        for level in BudgetLevel:
            result = BudgetFormatter.format_response(
                self.LARGE_DATASET, level, "pattern_list", total=100
            )
            sizes[level] = len(json.dumps(result))

        assert sizes[BudgetLevel.FULL] > sizes[BudgetLevel.NORMAL]
        assert sizes[BudgetLevel.NORMAL] > sizes[BudgetLevel.COMPACT]
        assert sizes[BudgetLevel.COMPACT] > sizes[BudgetLevel.MINIMAL]
