"""Tests for GreyMatter agent harness enrichment."""
import json
import pytest
from greymatter_core.db import SQLiteDatabase
from greymatter_core.standards import StandardsManager
from greymatter_core.patterns import PatternManager
from greymatter_core.knowledge import KnowledgeStore
from greymatter_plugin.harness import HarnessEnricher


@pytest.fixture
def db():
    database = SQLiteDatabase(":memory:")
    yield database
    database.close()


@pytest.fixture
def enricher(db):
    return HarnessEnricher(db=db)


@pytest.fixture
def seeded_db(db):
    """DB with standards, patterns, and knowledge for testing."""
    standards = StandardsManager(db)
    standards.seed_defaults()
    patterns = PatternManager(db)
    patterns.create(
        type="convention",
        domain="greymatter",
        title="TDD Required",
        observation="Always write tests before implementation code",
    )
    patterns.create(
        type="anti-pattern",
        domain="greymatter",
        title="No Shallow Work",
        observation="Never produce sketches when production-grade is expected",
    )
    # PatternManager.create() defaults confidence to 'low'.
    # The harness only queries medium/high confidence patterns.
    # Promote these test patterns to 'medium' so enrichment tests work.
    db.execute(
        "UPDATE patterns SET confidence = 'medium' WHERE domain = 'greymatter'"
    )
    knowledge = KnowledgeStore(db)
    knowledge.create(
        entry_type="reference",
        title="Plugin Architecture",
        content="GreyMatter plugin uses MCP protocol with FastMCP server",
        domain="greymatter",
    )
    return db


@pytest.fixture
def seeded_enricher(seeded_db):
    return HarnessEnricher(db=seeded_db)


# --- Tier 1: Unit Tests ---


def test_enricher_creates(enricher):
    assert enricher is not None


def test_enrich_returns_dict(enricher):
    result = enricher.enrich("Build a login page", "general-purpose")
    assert isinstance(result, dict)
    assert "enriched_prompt" in result
    assert "work_item_title" in result
    assert "tier1_tokens" in result
    assert "tier2_tokens" in result


def test_enrich_preserves_original_prompt(enricher):
    original = "Build a login page with OAuth"
    result = enricher.enrich(original, "general-purpose")
    assert original in result["enriched_prompt"]


def test_enrich_includes_standards_block(seeded_enricher):
    result = seeded_enricher.enrich("Build something", "general-purpose")
    assert "<greymatter-standards>" in result["enriched_prompt"]
    assert "</greymatter-standards>" in result["enriched_prompt"]


def test_enrich_includes_patterns_block(seeded_enricher):
    result = seeded_enricher.enrich("Build a greymatter plugin", "general-purpose")
    assert "<greymatter-patterns>" in result["enriched_prompt"]
    assert "TDD Required" in result["enriched_prompt"]


def test_enrich_domain_matching(seeded_enricher):
    result = seeded_enricher.enrich("Fix the greymatter plugin", "general-purpose")
    assert "TDD Required" in result["enriched_prompt"]


def test_enrich_no_domain_match(seeded_enricher):
    result = seeded_enricher.enrich("Make me a sandwich", "general-purpose")
    assert "<greymatter-standards>" in result["enriched_prompt"]


def test_enrich_work_item_title_format(enricher):
    result = enricher.enrich("Do stuff", "general-purpose", "my-agent")
    assert result["work_item_title"] == "Agent: general-purpose/my-agent"


def test_enrich_work_item_title_unnamed(enricher):
    result = enricher.enrich("Do stuff", "Explore")
    assert result["work_item_title"] == "Agent: Explore/unnamed"


def test_enrich_token_counts_are_integers(seeded_enricher):
    result = seeded_enricher.enrich("Build a greymatter thing", "general-purpose")
    assert isinstance(result["tier1_tokens"], int)
    assert isinstance(result["tier2_tokens"], int)


def test_enrich_standards_at_end(seeded_enricher):
    result = seeded_enricher.enrich("Build a greymatter plugin", "general-purpose")
    prompt = result["enriched_prompt"]
    standards_pos = prompt.find("<greymatter-standards>")
    original_pos = prompt.find("Build a greymatter plugin")
    assert standards_pos > original_pos


def test_enrich_patterns_at_top(seeded_enricher):
    result = seeded_enricher.enrich("Build a greymatter plugin", "general-purpose")
    prompt = result["enriched_prompt"]
    patterns_pos = prompt.find("<greymatter-patterns>")
    original_pos = prompt.find("Build a greymatter plugin")
    if patterns_pos >= 0:
        assert patterns_pos < original_pos


def test_enrich_empty_db(enricher):
    result = enricher.enrich("Build something", "general-purpose")
    assert "Build something" in result["enriched_prompt"]
    assert result["tier1_tokens"] == 0
    assert result["tier2_tokens"] == 0


def test_build_capture_instructions_code_agent(enricher):
    result = enricher.build_capture_instructions("Agent: general-purpose/impl", "general-purpose")
    assert "pending_review" in result
    assert "gm_work" in result


def test_build_capture_instructions_readonly_agent(enricher):
    result = enricher.build_capture_instructions("Agent: Explore/research", "Explore")
    assert "completed" in result
    assert "pending_review" not in result


def test_extract_domains_greymatter(enricher):
    domains = enricher._extract_domains("Fix the greymatter plugin hook")
    assert "greymatter" in domains


def test_extract_domains_neuralpulse(enricher):
    domains = enricher._extract_domains("Build the NeuralPulse hardware monitor")
    assert "neuralpulse" in domains


def test_extract_domains_none_matched(enricher):
    domains = enricher._extract_domains("Make me a sandwich")
    assert domains == ["general"]


def test_budget_instruction_in_standards(seeded_enricher):
    result = seeded_enricher.enrich("Build something", "general-purpose")
    assert "gm_knowledge" in result["enriched_prompt"] or "gm_standards" in result["enriched_prompt"]


# --- Tier 2: Behavior Tests ---


def test_behavior_full_enrichment_pipeline(seeded_enricher):
    """
    Given: A DB with quality standards, patterns, and knowledge entries
    When: A greymatter-related prompt is enriched for a general-purpose agent
    Then: The enriched prompt contains patterns (top), original prompt (middle), standards (bottom)
    """
    result = seeded_enricher.enrich(
        "Implement the new greymatter MCP tool for pattern search",
        "general-purpose",
        "implementer-1",
    )

    prompt = result["enriched_prompt"]
    patterns_pos = prompt.find("<greymatter-patterns>")
    original_pos = prompt.find("Implement the new greymatter MCP tool")
    standards_pos = prompt.find("<greymatter-standards>")

    assert patterns_pos >= 0, "Patterns block should exist"
    assert patterns_pos < original_pos, "Patterns before original prompt"
    assert original_pos < standards_pos, "Original before standards"
    assert result["work_item_title"] == "Agent: general-purpose/implementer-1"
    assert result["tier1_tokens"] > 0
    assert result["tier2_tokens"] > 0


def test_behavior_graceful_with_no_matching_domain(seeded_enricher):
    """
    Given: A DB with greymatter-domain patterns only
    When: A prompt about an unrelated topic is enriched
    Then: Standards are still injected, patterns block may be absent, no crash
    """
    result = seeded_enricher.enrich(
        "Deploy the application to production",
        "general-purpose",
    )

    prompt = result["enriched_prompt"]
    assert "Deploy the application" in prompt
    assert "<greymatter-standards>" in prompt
