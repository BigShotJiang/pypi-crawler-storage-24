"""Tests for PostToolUse retrieval hook."""
import pytest
import sys
import os


def _add_hook_paths():
    hooks_dir = os.path.join(os.path.dirname(__file__), "..", "..", "plugin", "hooks")
    lib_dir = os.path.join(os.path.dirname(__file__), "..", "..", "lib")
    if hooks_dir not in sys.path:
        sys.path.insert(0, os.path.abspath(hooks_dir))
    if lib_dir not in sys.path:
        sys.path.insert(0, os.path.abspath(lib_dir))


class TestExtractContextCues:

    def test_read_tool_extracts_path_keywords(self):
        _add_hook_paths()
        from post_tool_retrieval import extract_context_cues

        cues = extract_context_cues("Read", {"file_path": "/Users/dev/greymatter/lib/config.py"})

        assert "greymatter" in cues
        assert "config" in cues

    def test_grep_tool_extracts_pattern(self):
        _add_hook_paths()
        from post_tool_retrieval import extract_context_cues

        cues = extract_context_cues("Grep", {"pattern": "budget_for_mode", "path": "/dev/greymatter"})

        assert "budget_for_mode" in cues

    def test_glob_tool_extracts_pattern(self):
        _add_hook_paths()
        from post_tool_retrieval import extract_context_cues

        cues = extract_context_cues("Glob", {"pattern": "tests/lib/test_config.py"})

        assert "tests" in cues
        assert "test_config" in cues or "config" in cues

    def test_empty_input_returns_empty(self):
        _add_hook_paths()
        from post_tool_retrieval import extract_context_cues

        cues = extract_context_cues("Read", {})
        assert cues == []

    def test_cues_capped_at_10(self):
        _add_hook_paths()
        from post_tool_retrieval import extract_context_cues

        long_path = "/".join(f"dir{i}" for i in range(20))
        cues = extract_context_cues("Read", {"file_path": long_path})

        assert len(cues) <= 10
