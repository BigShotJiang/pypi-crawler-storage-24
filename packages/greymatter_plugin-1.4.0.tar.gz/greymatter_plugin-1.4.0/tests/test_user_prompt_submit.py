"""Tests for UserPromptSubmit hook: recovery + momentum-based retrieval."""
import pytest
from pathlib import Path
from unittest.mock import patch, MagicMock

from greymatter_core.db import SQLiteDatabase
from greymatter_core.sessions import SessionManager


@pytest.fixture
def db():
    database = SQLiteDatabase(":memory:")
    yield database
    database.close()


@pytest.fixture
def sessions(db):
    return SessionManager(db)


@pytest.fixture
def recovery_dir(tmp_path):
    rd = tmp_path / "recovery"
    rd.mkdir()
    return rd


def _add_hook_paths():
    import sys
    import os
    hooks_dir = os.path.join(os.path.dirname(__file__), "..", "..", "plugin", "hooks")
    lib_dir = os.path.join(os.path.dirname(__file__), "..", "..", "lib")
    if hooks_dir not in sys.path:
        sys.path.insert(0, os.path.abspath(hooks_dir))
    if lib_dir not in sys.path:
        sys.path.insert(0, os.path.abspath(lib_dir))


def _import_recovery():
    _add_hook_paths()
    import importlib
    import recovery as mod
    importlib.reload(mod)
    return mod


# --- Recovery Injection Tests ---


class TestRecoveryInjection:

    def test_no_artifact_returns_empty(self, db, sessions, recovery_dir):
        _add_hook_paths()
        recovery_mod = _import_recovery()
        from user_prompt_submit import check_and_inject_recovery

        session = sessions.start()
        with patch.object(recovery_mod, "RECOVERY_DIR", recovery_dir):
            result = check_and_inject_recovery(session["id"])

        assert result == ""

    def test_injects_recovery_artifact(self, db, sessions, recovery_dir):
        _add_hook_paths()
        recovery_mod = _import_recovery()
        from user_prompt_submit import check_and_inject_recovery

        session = sessions.start()
        sid = session["id"][:12]

        artifact_path = recovery_dir / f"session-{sid}-1.md"
        artifact_path.write_text("## Recovery Context\nTest recovery content")

        with patch.object(recovery_mod, "RECOVERY_DIR", recovery_dir):
            result = check_and_inject_recovery(session["id"])

        assert "Recovery Context" in result

    def test_artifact_consumed_after_injection(self, db, sessions, recovery_dir):
        _add_hook_paths()
        recovery_mod = _import_recovery()
        from user_prompt_submit import check_and_inject_recovery

        session = sessions.start()
        sid = session["id"][:12]

        artifact_path = recovery_dir / f"session-{sid}-1.md"
        artifact_path.write_text("Recovery content")

        with patch.object(recovery_mod, "RECOVERY_DIR", recovery_dir):
            check_and_inject_recovery(session["id"])
            assert not artifact_path.exists()
            consumed = recovery_dir / f"session-{sid}-1.consumed"
            assert consumed.exists()

    def test_second_call_returns_empty(self, db, sessions, recovery_dir):
        _add_hook_paths()
        recovery_mod = _import_recovery()
        from user_prompt_submit import check_and_inject_recovery

        session = sessions.start()
        sid = session["id"][:12]

        artifact_path = recovery_dir / f"session-{sid}-1.md"
        artifact_path.write_text("Recovery content")

        with patch.object(recovery_mod, "RECOVERY_DIR", recovery_dir):
            first = check_and_inject_recovery(session["id"])
            second = check_and_inject_recovery(session["id"])

        assert first != ""
        assert second == ""

    def test_empty_session_id_returns_empty(self):
        _add_hook_paths()
        from user_prompt_submit import check_and_inject_recovery
        assert check_and_inject_recovery("") == ""

    def test_get_current_session_id(self, db, sessions):
        _add_hook_paths()
        from user_prompt_submit import get_current_session_id
        session = sessions.start()
        assert get_current_session_id(db) == session["id"]

    def test_get_current_session_id_none(self, db):
        _add_hook_paths()
        from user_prompt_submit import get_current_session_id
        assert get_current_session_id(db) == ""


# --- Retrieval Format Tests ---


class TestRetrievalFormat:

    def test_format_entries(self):
        _add_hook_paths()
        from user_prompt_submit import format_retrieval_context

        entries = [
            {"title": "Use SQLite", "content": "Always use SQLite for local storage.", "type": "reference", "confidence": "high"},
            {"title": "Fix config path", "content": "Config must be YAML.", "type": "correction", "confidence": "high"},
        ]
        output = format_retrieval_context(entries, tier=1)

        assert "Relevant from your memory:" in output
        assert "[Reference] Use SQLite" in output
        assert "[Correction] Fix config path" in output

    def test_format_empty_entries(self):
        _add_hook_paths()
        from user_prompt_submit import format_retrieval_context
        assert format_retrieval_context([], tier=0) == ""

    def test_format_respects_budget(self):
        _add_hook_paths()
        from user_prompt_submit import format_retrieval_context

        # Create many entries that exceed budget
        entries = [
            {"title": f"Entry {i}", "content": "A" * 200, "type": "reference"}
            for i in range(50)
        ]
        output = format_retrieval_context(entries, tier=2)

        # Should be truncated to ~MAX_RETRIEVAL_TOKENS
        assert len(output) < 2000 * 4 + 200  # Budget + header overhead

    def test_format_no_json(self):
        """Output should not contain JSON to avoid prompt injection detection."""
        _add_hook_paths()
        from user_prompt_submit import format_retrieval_context

        entries = [{"title": "Test", "content": "Content here", "type": "reference"}]
        output = format_retrieval_context(entries, tier=0)

        assert "{" not in output
        assert "}" not in output


# --- Tier Tests ---


class TestTieredRetrieval:

    def test_tier0_uses_priming_cache(self):
        _add_hook_paths()
        from user_prompt_submit import tier0_lookup
        from priming import build_priming_file, save_priming_file

        data = build_priming_file("sess", [
            {"id": "kn-1", "title": "SQLite local storage", "content": "Use SQLite for local DB."},
        ])

        with patch("priming.load_priming_file", return_value=data):
            results = tier0_lookup(["sqlite", "storage"])

        assert len(results) > 0
        assert results[0]["id"] == "kn-1"

    def test_tier0_no_priming_file(self):
        _add_hook_paths()
        from user_prompt_submit import tier0_lookup

        with patch("priming.load_priming_file", return_value=None):
            results = tier0_lookup(["sqlite"])

        assert results == []
