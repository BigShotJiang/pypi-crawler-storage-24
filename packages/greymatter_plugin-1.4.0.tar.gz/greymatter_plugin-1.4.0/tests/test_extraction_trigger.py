"""Tests for extraction trigger in UserPromptSubmit hook."""
import json
import os
import sys
import pytest

# Add hooks dir to path
_hooks_dir = os.path.join(os.path.dirname(__file__), "..", "hooks")
if _hooks_dir not in sys.path:
    sys.path.insert(0, os.path.abspath(_hooks_dir))

from user_prompt_submit import detect_extraction_signal, ExtractionState

TEST_STATE_FILE = "/tmp/.greymatter-extraction-state-test.json"


class TestSignalDetection:
    """Verify high-value signal detection in user messages."""

    def test_detects_decision(self):
        assert detect_extraction_signal("Let's go with PostgreSQL for the backend")

    def test_detects_preference(self):
        assert detect_extraction_signal("I want every session to capture observations automatically")

    def test_detects_trade_off(self):
        assert detect_extraction_signal("The trade-off is latency versus accuracy")

    def test_detects_business(self):
        assert detect_extraction_signal("The pricing model should be freemium")

    def test_ignores_hello(self):
        assert not detect_extraction_signal("hello")

    def test_ignores_continue(self):
        assert not detect_extraction_signal("continue")

    def test_ignores_short(self):
        assert not detect_extraction_signal("yes")


class TestExtractionState:
    """Verify message counter and watermark tracking."""

    def setup_method(self):
        if os.path.exists(TEST_STATE_FILE):
            os.unlink(TEST_STATE_FILE)

    def teardown_method(self):
        if os.path.exists(TEST_STATE_FILE):
            os.unlink(TEST_STATE_FILE)

    def test_counter_increments(self):
        state = ExtractionState(TEST_STATE_FILE)
        assert state.message_count == 0
        state.increment()
        assert state.message_count == 1
        state.save()

        state2 = ExtractionState(TEST_STATE_FILE)
        assert state2.message_count == 1

    def test_should_extract_at_floor(self):
        state = ExtractionState(TEST_STATE_FILE)
        for _ in range(20):
            state.increment()
        assert state.should_extract(signal_detected=False) is True

    def test_should_extract_on_signal(self):
        state = ExtractionState(TEST_STATE_FILE)
        state.increment()
        assert state.should_extract(signal_detected=True) is True

    def test_no_extract_without_signal_below_floor(self):
        state = ExtractionState(TEST_STATE_FILE)
        state.increment()
        assert state.should_extract(signal_detected=False) is False

    def test_watermark_resets_after_extraction(self):
        state = ExtractionState(TEST_STATE_FILE)
        for _ in range(5):
            state.increment("msg")
        state.mark_extracted()

        state2 = ExtractionState(TEST_STATE_FILE)
        assert state2.should_extract(signal_detected=False) is False

    def test_get_new_messages(self):
        state = ExtractionState(TEST_STATE_FILE)
        state.increment("first message")
        state.increment("second message")
        new = state.get_new_messages()
        assert "first message" in new
        assert "second message" in new
