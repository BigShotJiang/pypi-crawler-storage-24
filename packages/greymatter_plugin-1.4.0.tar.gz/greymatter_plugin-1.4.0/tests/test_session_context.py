"""Tests for SessionStart hook context capping.

The session_context.py hook should cap injected context to avoid
exhausting the coordinator's context window. When context exceeds
the cap (~400 tokens / ~1600 chars), it truncates to summaries only.
"""
import json
import pytest
from unittest.mock import patch, MagicMock

from greymatter_core.db import SQLiteDatabase
from greymatter_core.sessions import SessionManager
from greymatter_core.standards import StandardsManager
from greymatter_core.patterns import PatternManager
from cognitive import MemorySystem


@pytest.fixture
def db():
    database = SQLiteDatabase(":memory:")
    yield database
    database.close()


@pytest.fixture
def memory():
    """Create a MemorySystem for tests, patched as the singleton."""
    mem = MemorySystem(db_path=":memory:", license_key="test")
    with patch("greymatter_core.cognitive_bridge.get_memory", return_value=mem):
        yield mem


@pytest.fixture(autouse=True)
def _patch_memory(memory):
    """Auto-patch get_memory for all tests."""
    with patch("greymatter_core.cognitive_bridge.get_memory", return_value=memory):
        yield


@pytest.fixture
def sessions(db):
    return SessionManager(db)


@pytest.fixture
def patterns(db):
    return PatternManager(db)


@pytest.fixture
def standards(db):
    return StandardsManager(db)


@pytest.fixture
def observations(memory):
    """Provide observation creation through cognitive's MemorySystem."""
    return memory


# --- Helper: run the context builder logic extracted from session_context.py ---

def build_session_context_output(db, max_chars=1600):
    """Replicate the session_context.py logic with capping.

    This mirrors the hook's build logic so we can test capping without
    needing to run the hook as a subprocess.
    """
    # Import the extracted function
    import sys
    import os
    hooks_dir = os.path.join(
        os.path.dirname(__file__), "..", "..", "plugin", "hooks"
    )
    sys.path.insert(0, os.path.abspath(hooks_dir))

    # Use the hook's build function directly
    from session_context import build_context_parts, cap_context

    parts = build_context_parts(db)
    return cap_context(parts, max_chars)


# --- Tier 1: Unit Tests ---


class TestContextCapping:
    """Test that SessionStart context is capped when it exceeds the limit."""

    def test_short_context_not_truncated(self, db, sessions):
        """When context is under the cap, all parts are returned."""
        sessions.start()
        result = build_session_context_output(db, max_chars=5000)
        # Should contain session info at minimum
        assert "Session:" in result

    def test_context_capped_at_limit(self, db, sessions, standards, patterns, observations):
        """When context exceeds the cap, it is truncated to summaries."""
        session = sessions.start()
        standards.seed_defaults()

        # Create many patterns to inflate context
        for i in range(20):
            patterns.create(
                type="convention",
                domain=f"domain-{i}",
                title=f"Pattern with a very long title number {i} that takes up space",
                observation=f"A very detailed observation about pattern {i} " * 10,
            )
            # Promote to medium confidence so they show up
            db.execute(
                "UPDATE patterns SET confidence = 'medium' WHERE title LIKE ?",
                (f"%number {i}%",),
            )

        # Create many observations via cognitive
        for i in range(10):
            observations.observe(
                content=f"Detailed content about observation {i} " * 20,
                category="insight",
                title=f"Observation {i} with lots of detail about the system",
                session_id=session["id"],
                confidence=0.8,
            )

        result = build_session_context_output(db, max_chars=1600)
        # The result should be capped
        assert len(result) <= 1800  # Allow small overshoot for the summary line
        # Should still have key information
        assert "Session:" in result

    def test_capped_context_has_truncation_notice(self, db, sessions, standards, patterns):
        """When truncated, a notice is appended."""
        session = sessions.start()
        standards.seed_defaults()

        # Create enough patterns to exceed the cap
        for i in range(20):
            patterns.create(
                type="convention",
                domain="greymatter",
                title=f"Long pattern title {i} for inflation purposes",
                observation="x" * 200,
            )
            db.execute(
                "UPDATE patterns SET confidence = 'medium' WHERE title LIKE ?",
                (f"%{i} for inflation%",),
            )

        result = build_session_context_output(db, max_chars=800)
        # Either fits naturally or has truncation notice
        if len(result) > 800:
            # If it would exceed, it should be truncated
            assert "truncated" in result or len(result) <= 900

    def test_no_session_returns_empty(self, db):
        """When no session exists, still returns something sensible."""
        result = build_session_context_output(db, max_chars=1600)
        # Should handle no session gracefully
        assert isinstance(result, str)


class TestCapContextFunction:
    """Test the cap_context helper directly."""

    def test_empty_parts(self):
        """Empty parts list returns empty string."""
        import sys
        import os
        hooks_dir = os.path.join(
            os.path.dirname(__file__), "..", "..", "plugin", "hooks"
        )
        sys.path.insert(0, os.path.abspath(hooks_dir))
        from session_context import cap_context

        result = cap_context([], 1600)
        assert result == ""

    def test_parts_under_limit(self):
        """Parts under the limit are all included."""
        import sys
        import os
        hooks_dir = os.path.join(
            os.path.dirname(__file__), "..", "..", "plugin", "hooks"
        )
        sys.path.insert(0, os.path.abspath(hooks_dir))
        from session_context import cap_context

        parts = ["Session: abc123", "Data: patterns: 5"]
        result = cap_context(parts, 1600)
        assert "Session: abc123" in result
        assert "Data: patterns: 5" in result

    def test_parts_over_limit_truncated(self):
        """Parts exceeding the limit are truncated with a notice."""
        import sys
        import os
        hooks_dir = os.path.join(
            os.path.dirname(__file__), "..", "..", "plugin", "hooks"
        )
        sys.path.insert(0, os.path.abspath(hooks_dir))
        from session_context import cap_context

        parts = [
            "Session: abc123",
            "Quality standards: 15 active",
            "Active patterns:\n" + "\n".join(
                [f"  - Pattern {i} (medium)" for i in range(30)]
            ),
            "Data: patterns: 100, knowledge: 50, meetings: 730",
            "Recent observations:\n" + "\n".join(
                [f"  - [insight] Observation {i} (conf: 0.8)" for i in range(20)]
            ),
            "--- Checkpoint Recovery ---",
            "Last context: " + "x" * 500,
            "Open items: " + "y" * 500,
        ]
        result = cap_context(parts, 400)
        assert len(result) <= 500  # Allow small overshoot
        assert "truncated" in result
        # First part (session info) should survive
        assert "Session: abc123" in result
