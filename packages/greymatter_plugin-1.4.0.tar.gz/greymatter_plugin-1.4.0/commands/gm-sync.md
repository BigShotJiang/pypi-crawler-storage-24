---
name: gm-sync
description: Sync SalesOS meeting data from Mac Mini into local GreyMatter SQLite
---

Sync meeting data from the Mac Mini into local GreyMatter:

1. Export meetings from Mac Mini as JSON:
   ```bash
   ssh agenticai@100.81.247.14 'sqlite3 ~/.greymatter/greymatter.db "SELECT json_group_array(json_object(\"id\",id,\"title\",title,\"date\",date,\"summary\",summary,\"transcript\",transcript,\"account\",account,\"tags\",tags)) FROM salesos_meetings"' > /tmp/meetings.json
   ```

2. Import into local GreyMatter:
   ```bash
   cd /Users/keithcotterman/Development/greymatter/core
   python3 scripts/import_crdb_data.py --meetings /tmp/meetings.json
   ```

3. Report sync results from the script output.

The script:
- Reads meeting JSON exported from Mac Mini SQLite
- Imports meetings with upsert (new records added, existing updated)

**Requirements:** SSH access to `agenticai@100.81.247.14` (Mac Mini via Tailscale).

If SSH fails, suggest: `tailscale status` to check connectivity.
