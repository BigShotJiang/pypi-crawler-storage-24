#!/usr/bin/env bash
# Run the GreyMatter MCP server
cd "$(dirname "$0")"
source ../../.venv/bin/activate
exec python -m greymatter_plugin.server
