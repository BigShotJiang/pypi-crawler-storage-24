"""Entry point for running the GreyMatter MCP server."""
from .server import main

main()
