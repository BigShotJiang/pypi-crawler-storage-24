"""GreyMatter MCP Server.

Exposes all core modules as compound MCP tools for Claude Code, Gemini CLI, and Codex.
Each domain gets one tool with an 'action' parameter.
Extensions register their own tools via the extension callback system.
"""
import json
import logging
import os
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

from fastmcp import FastMCP

from greymatter_core.db import Database, SQLiteDatabase
from greymatter_core.patterns import PatternManager
from greymatter_core.knowledge import KnowledgeStore
from greymatter_core.work_items import WorkItemManager
from greymatter_core.sessions import SessionManager
from greymatter_core.soul import SoulManager
from greymatter_core.standards import StandardsManager
from greymatter_core.benchmarks import BenchmarkManager
from greymatter_core.documents import DocumentStore
from greymatter_core.context import ContextEngine
from greymatter_core.config import load_config
from greymatter_core.cognitive_bridge import get_memory
from cognitive.memory import VALID_CATEGORIES
from greymatter_plugin.budget import BudgetLevel, BudgetFormatter


# --- Extension tool registration ---
# Extensions call register_tool_extension() to add their MCP tools.
# Callbacks receive (mcp, db, config) and should register @mcp.tool() functions.
_tool_extensions: list[Callable] = []


def register_tool_extension(callback: Callable[[FastMCP, Database, Any], None]) -> None:
    """Register an extension's tool registration callback.

    Extensions call this before create_app() to register their MCP tools.
    The callback receives (mcp, db, config) and should define @mcp.tool() functions.
    """
    _tool_extensions.append(callback)


logger = logging.getLogger("greymatter.plugin")


def _json(obj: Any) -> str:
    """Serialize to JSON, handling non-serializable types."""
    return json.dumps(obj, default=str, indent=2)


def create_app(db: Database | None = None) -> FastMCP:
    """Create the GreyMatter MCP application.

    Args:
        db: Database instance. If None, opens default SQLite database.
    """
    config = None
    if db is None:
        config = load_config()
        db = SQLiteDatabase(config.db_path)

    # Initialize all managers
    patterns = PatternManager(db)
    knowledge = KnowledgeStore(db)
    work_items = WorkItemManager(db)
    sessions = SessionManager(db)
    standards = StandardsManager(db)
    benchmarks = BenchmarkManager(db)
    docs = DocumentStore(db)
    context = ContextEngine(db, docs, standards, patterns)
    # When db was passed directly (testing), derive path from db to avoid
    # opening a second connection to the production database.
    memory_db_path = None
    if config is not None:
        memory_db_path = config.db_path
    elif hasattr(db, '_path'):
        memory_db_path = str(db._path)
    memory = get_memory(memory_db_path)
    soul = SoulManager(Path("~/.greymatter/soul/default.md"))

    # --- Rate limiter for MCP tool calls ---
    from collections import defaultdict
    import time as _time

    _rate_calls: dict[str, list[float]] = defaultdict(list)
    _RATE_LIMIT = 60           # max calls per tool per window
    _RATE_WINDOW = 60.0        # window in seconds

    def _check_rate_limit(tool_name: str) -> str | None:
        """Check if a tool call exceeds rate limit. Returns error message or None."""
        now = _time.time()
        calls = _rate_calls[tool_name]
        # Prune old entries
        cutoff = now - _RATE_WINDOW
        _rate_calls[tool_name] = [t for t in calls if t > cutoff]
        calls = _rate_calls[tool_name]

        if len(calls) >= _RATE_LIMIT:
            logger.warning("Rate limit exceeded for tool %s: %d calls in %.0fs",
                           tool_name, len(calls), _RATE_WINDOW)
            _log_security_event(
                "rate_limit_exceeded", "high", tool_name=tool_name,
                action_taken="rejected",
                detail=f"{len(calls)} calls in {_RATE_WINDOW:.0f}s window",
            )
            return f"Rate limit exceeded: {tool_name} ({_RATE_LIMIT} calls/{_RATE_WINDOW:.0f}s). Try again shortly."
        calls.append(now)
        return None

    # --- Input size limits ---
    _MAX_CONTENT_SIZE = 100_000   # 100KB per field
    _MAX_TITLE_SIZE = 1_000       # 1KB for titles

    def _check_size(text: str, field_name: str = "content", max_size: int = 0) -> str | None:
        """Check if input exceeds size limit. Returns error message or None."""
        limit = max_size or (_MAX_TITLE_SIZE if "title" in field_name else _MAX_CONTENT_SIZE)
        if len(text) > limit:
            _log_security_event(
                "size_limit_exceeded", "medium", tool_name=field_name,
                action_taken="rejected",
                detail=f"{len(text)} chars exceeds {limit} limit",
            )
            return f"Input too large: {field_name} is {len(text):,} chars (max {limit:,})"
        return None

    # --- Policy engine for declarative rule evaluation ---
    _policy_engine = None

    def _get_policy_engine():
        nonlocal _policy_engine
        if _policy_engine is None:
            try:
                from greymatter_core.policy import PolicyEngine
                policy_path = Path("~/.greymatter/policy.yaml").expanduser()
                if policy_path.exists():
                    _policy_engine = PolicyEngine.from_yaml(policy_path.read_text())
                    logger.info("Policy engine loaded: %d rules", len(_policy_engine.rules))
                else:
                    _policy_engine = PolicyEngine()  # No rules = default allow
            except Exception as e:
                from greymatter_core.policy import PolicyEngine
                logger.warning("Policy engine init failed: %s", e)
                _policy_engine = PolicyEngine()
        return _policy_engine

    def _check_policy(tool_name: str, action: str, content: str = "") -> str | None:
        """Evaluate policy rules. Returns error message if refused, None if allowed."""
        try:
            from greymatter_core.policy import EvalContext, PolicyOutcome
            engine = _get_policy_engine()
            ctx = EvalContext(tool=tool_name, action=action, content=content)
            decision = engine.evaluate(ctx)

            if decision.outcome == PolicyOutcome.REFUSE:
                _log_security_event(
                    "policy_refused", "high", tool_name=tool_name,
                    action_taken="refused",
                    detail=f"Rule {decision.rule_id}: {decision.reason}",
                )
                return f"Policy violation: {decision.reason} (rule: {decision.rule_id})"
            elif decision.outcome == PolicyOutcome.ESCALATE:
                _log_security_event(
                    "policy_escalated", "medium", tool_name=tool_name,
                    action_taken="escalated",
                    detail=f"Rule {decision.rule_id}: {decision.reason}",
                )
                # Escalate logs but allows
            return None
        except Exception as e:
            logger.debug("Policy check failed: %s", e)
            return None  # Fail open

    # --- Lazy semantic search for auto-indexing on write ---
    _semantic_search = None

    def _get_semantic():
        nonlocal _semantic_search
        if _semantic_search is None:
            from greymatter_core.embeddings import OllamaEmbedding
            from greymatter_core.semantic import SemanticSearch
            _semantic_search = SemanticSearch(db, OllamaEmbedding())
        return _semantic_search

    def _auto_index(table: str, row_id: str, text: str) -> None:
        """Auto-index a row into semantic search. Logs and continues if embeddings unavailable."""
        try:
            _get_semantic().index_row(table, row_id, text)
        except Exception as e:
            logger.debug("Auto-index failed for %s/%s: %s", table, row_id, e)

    # --- Secret scanner for ingest/recall protection ---
    _scanner = None

    def _get_scanner():
        nonlocal _scanner
        if _scanner is None:
            from greymatter_core.scanner import SecretScanner, ScannerConfig
            try:
                cfg = load_config()
                scanner_cfg = ScannerConfig(
                    enabled=cfg.scanner_enabled,
                    mode=cfg.scanner_mode,
                    min_confidence=cfg.scanner_min_confidence,
                )
            except Exception:
                scanner_cfg = ScannerConfig()
            _scanner = SecretScanner(scanner_cfg)
        return _scanner

    def _scan_and_redact(text: str) -> tuple[str, list]:
        """Scan text and redact secrets. Returns (processed_text, detections).

        Used on ingest to prevent secrets from entering memory, and on
        recall to catch secrets that entered before the scanner was installed.
        """
        try:
            scanner = _get_scanner()
            detections = scanner.scan(text)
            if detections:
                text = scanner.redact(text, detections)
                return text, [
                    {"pattern": d.pattern_name, "severity": d.severity}
                    for d in detections
                ]
            return text, []
        except Exception as e:
            logger.warning("Scanner failed during scan_and_redact: %s", e)
            return text, []

    def _scan_ingest(text: str, mode: str = "redact") -> tuple[str, list, str | None]:
        """Scan content on ingest. Returns (text, detections, warning_or_error).

        mode: 'warn' returns original text + warning,
              'redact' returns redacted text,
              'block' returns original text + error message.
        """
        try:
            scanner = _get_scanner()
            detections = scanner.scan(text)
            if not detections:
                return text, [], None

            det_summary = [
                {"pattern": d.pattern_name, "severity": d.severity}
                for d in detections
            ]

            cfg_mode = scanner.config.mode
            effective_mode = cfg_mode if cfg_mode != "warn" else mode

            if effective_mode == "block":
                names = ", ".join(d.pattern_name for d in detections)
                for d in detections:
                    _log_security_event(
                        "ingest_blocked", d.severity, d.pattern_name,
                        action_taken="blocked",
                        detail=f"Secret blocked from entering memory",
                    )
                return text, det_summary, f"BLOCKED: secrets detected ({names}). Remove secrets and retry."

            if effective_mode == "redact":
                for d in detections:
                    _log_security_event(
                        "ingest_redacted", d.severity, d.pattern_name,
                        action_taken="redacted",
                        detail=f"Secret redacted on ingest",
                    )
                redacted = scanner.redact(text, detections)
                return redacted, det_summary, None

            # warn mode
            for d in detections:
                _log_security_event(
                    "ingest_warning", d.severity, d.pattern_name,
                    action_taken="warned",
                    detail=f"Secret detected but stored (warn mode)",
                )
            return text, det_summary, None
        except Exception as e:
            logger.warning("Scanner failed during ingest scan: %s", e)
            return text, [], None

    def _log_security_event(event_type: str, severity: str, pattern_name: str = "",
                           tool_name: str = "", action_taken: str = "", detail: str = "") -> None:
        """Append a security event to the audit log."""
        try:
            db.execute(
                "INSERT INTO security_events (event_type, severity, pattern_name, tool_name, action_taken, detail) "
                "VALUES (?, ?, ?, ?, ?, ?)",
                (event_type, severity, pattern_name, tool_name, action_taken, detail),
            )
        except Exception as e:
            logger.debug("Failed to log security event: %s", e)

    def _redact_recall(text: str | None) -> str | None:
        """Redact secrets from recalled content before it reaches the LLM."""
        if not text:
            return text
        try:
            scanner = _get_scanner()
            detections = scanner.scan(text)
            if detections:
                names = [d.pattern_name for d in detections]
                logger.warning(
                    "Outbound redaction: caught %d secret(s) [%s] before LLM delivery",
                    len(detections), ", ".join(names),
                )
                for d in detections:
                    _log_security_event(
                        "outbound_redaction", d.severity, d.pattern_name,
                        action_taken="redacted",
                        detail=f"Caught on recall before LLM delivery",
                    )
                return scanner.redact(text, detections)
            return text
        except Exception as e:
            logger.warning("Scanner failed during recall redaction: %s", e)
            return text

    def _redact_results(results: list[dict], fields: tuple[str, ...] = ("content", "observation", "summary", "transcript")) -> list[dict]:
        """Redact secrets from a list of result dicts before returning to LLM."""
        for r in results:
            for field in fields:
                if field in r and r[field]:
                    r[field] = _redact_recall(r[field])
        return results

    mcp = FastMCP("greymatter")

    # Store tool functions for testing
    mcp._tool_functions = {}

    # --- gm_status ---
    @mcp.tool()
    def gm_status(budget: str = "") -> str:
        """Get GreyMatter system overview: pattern counts, knowledge entries, work items, standards, documents.

        Optional budget parameter: full/normal/compact/minimal
        """
        level = BudgetLevel.parse(budget or None)
        # Use COUNT queries instead of loading all rows
        pattern_counts = db.execute_one(
            "SELECT COUNT(*) as total FROM patterns"
        ) or {"total": 0}
        pattern_high = db.execute_one(
            "SELECT COUNT(*) as cnt FROM patterns WHERE confidence = 'high'"
        ) or {"cnt": 0}
        pattern_med = db.execute_one(
            "SELECT COUNT(*) as cnt FROM patterns WHERE confidence = 'medium'"
        ) or {"cnt": 0}
        knowledge_count = db.execute_one(
            "SELECT COUNT(*) as total FROM knowledge_entries WHERE pruned_at IS NULL"
        ) or {"total": 0}
        work_total = db.execute_one(
            "SELECT COUNT(*) as total FROM work_items"
        ) or {"total": 0}
        work_queued = db.execute_one(
            "SELECT COUNT(*) as cnt FROM work_items WHERE status = 'queued'"
        ) or {"cnt": 0}
        work_in_progress = db.execute_one(
            "SELECT COUNT(*) as cnt FROM work_items WHERE status = 'in_progress'"
        ) or {"cnt": 0}
        observation_count = db.execute_one(
            "SELECT COUNT(*) as total FROM observations WHERE pruned = 0"
        ) or {"total": 0}
        active_standards = standards.get_active()
        status = {
            "patterns": {
                "total": pattern_counts["total"],
                "high_confidence": pattern_high["cnt"],
                "medium_confidence": pattern_med["cnt"],
            },
            "knowledge": {"total": knowledge_count["total"]},
            "work_items": {
                "total": work_total["total"],
                "queued": work_queued["cnt"],
                "in_progress": work_in_progress["cnt"],
            },
            "observations": {"total": observation_count["total"]},
            "standards": {"active": len(active_standards)},
            "soul": {"exists": soul.exists()},
        }
        # Memory health metrics
        try:
            from datetime import datetime as _dt, timezone as _tz
            avg_conf = db.execute_one(
                "SELECT AVG(confidence) as avg FROM observations WHERE pruned = 0"
            )
            stale_count = db.execute_one(
                "SELECT COUNT(*) as cnt FROM observations WHERE pruned = 0 AND confidence < 0.3"
            ) or {"cnt": 0}
            strong_count = db.execute_one(
                "SELECT COUNT(*) as cnt FROM observations WHERE pruned = 0 AND confidence >= 0.7"
            ) or {"cnt": 0}
            pruned_total = db.execute_one(
                "SELECT COUNT(*) as cnt FROM observations WHERE pruned = 1"
            ) or {"cnt": 0}
            status["memory_health"] = {
                "avg_confidence": round(avg_conf["avg"], 3) if avg_conf and avg_conf["avg"] else 0.0,
                "strong_memories": strong_count["cnt"],
                "stale_memories": stale_count["cnt"],
                "pruned_total": pruned_total["cnt"],
            }
            # Knowledge quality score
            try:
                from greymatter_core.quality import QualityEngine
                qe = QualityEngine(db)
                report = qe.full_check()
                status["knowledge_quality"] = {
                    "score": round(report.score, 3),
                    "issues": report.issue_count,
                    "total_entries": report.total_entries,
                }
            except Exception:
                pass
        except Exception:
            pass  # Memory health is informational, don't break status
        if budget:
            return _json(BudgetFormatter.format_status(status, level))
        return _json(status)
    mcp._tool_functions["gm_status"] = gm_status

    # --- gm_pattern ---
    @mcp.tool()
    def gm_pattern(
        action: str,
        type: str = "",
        domain: str = "",
        title: str = "",
        observation: str = "",
        query: str = "",
        pattern_id: str = "",
        confidence: str = "",
        budget: str = "",
    ) -> str:
        """Manage patterns. Actions: create, search, list, get, confirm.

        create: requires type, domain, title, observation
        search: optional domain, type, min_confidence filters
        list: optional confidence filter
        get: requires pattern_id
        confirm: requires pattern_id (adds evidence)

        Optional budget parameter: full/normal/compact/minimal
        """
        if action in ("create", "confirm"):
            rl_err = _check_rate_limit("gm_pattern")
            if rl_err:
                return _json({"error": rl_err})

        level = BudgetLevel.parse(budget or None)
        if action == "create":
            for fname, fval in [("title", title), ("observation", observation)]:
                sz_err = _check_size(fval, fname)
                if sz_err:
                    return _json({"error": sz_err})
            observation, scan_dets, scan_err = _scan_ingest(observation, mode="redact")
            if scan_err:
                return _json({"error": scan_err})
            title = _redact_recall(title) or title
            result = patterns.create(type=type, domain=domain, title=title, observation=observation)
            if scan_dets:
                result["_redacted_secrets"] = scan_dets
            _auto_index("observations", result["id"], f"{title} {observation}")
            if budget:
                return _json(BudgetFormatter.format_single(result, level))
            return _json(result)
        elif action == "search":
            if budget:
                if level == BudgetLevel.FULL:
                    results = patterns.search(
                        domain=domain or None,
                        type=type or None,
                        min_confidence=confidence or "low",
                    )
                    return _json(BudgetFormatter.format_response(results, level, "pattern_search"))
                elif level == BudgetLevel.MINIMAL:
                    count = patterns.count(confidence=confidence or None)
                    return _json(BudgetFormatter.format_response([], level, "pattern_search", total=count))
                else:
                    summary = patterns.search_summary(
                        domain=domain or None,
                        type=type or None,
                        min_confidence=confidence or "low",
                    )
                    return _json(BudgetFormatter.format_response(
                        summary["patterns"], level, "pattern_search", total=summary["total"]
                    ))
            return _json(patterns.search_summary(
                domain=domain or None,
                type=type or None,
                min_confidence=confidence or "low",
            ))
        elif action == "list":
            if budget:
                if level == BudgetLevel.FULL:
                    results = patterns.list_all()
                    return _json(BudgetFormatter.format_response(results, level, "pattern_list"))
                elif level == BudgetLevel.MINIMAL:
                    count = patterns.count(confidence=confidence or None)
                    return _json(BudgetFormatter.format_response([], level, "pattern_list", total=count))
                else:
                    summary = patterns.list_summary(confidence=confidence or None)
                    return _json(BudgetFormatter.format_response(
                        summary["patterns"], level, "pattern_list", total=summary["total"]
                    ))
            return _json(patterns.list_summary(
                confidence=confidence or None,
            ))
        elif action == "get":
            result = patterns.get(pattern_id)
            if result:
                _redact_results([result])
            if budget:
                return _json(BudgetFormatter.format_single(result, level))
            return _json(result)
        elif action == "confirm":
            # add_evidence requires a session_id; use a placeholder for direct calls
            current = sessions.get_current()
            session_id = current["id"] if current else "manual"
            patterns.add_evidence(pattern_id, session_id=session_id)
            # Strengthen linked observations via spaced repetition
            linked_obs = db.execute(
                "SELECT id FROM observations WHERE pattern_id = ? AND pruned = 0",
                (pattern_id,),
            )
            boosted = 0
            for obs in linked_obs:
                memory.confirm(obs["id"])
                boosted += 1
            result = patterns.get(pattern_id)
            if result:
                _redact_results([result])
                if boosted > 0:
                    result["_observations_strengthened"] = boosted
            if budget:
                return _json(BudgetFormatter.format_single(result, level))
            return _json(result)
        return _json({"error": f"Unknown action: {action}"})
    mcp._tool_functions["gm_pattern"] = gm_pattern

    # --- gm_knowledge ---
    @mcp.tool()
    def gm_knowledge(
        action: str,
        entry_type: str = "",
        title: str = "",
        content: str = "",
        domain: str = "",
        scope: str = "cross-cutting",
        query: str = "",
        entry_id: str = "",
        tags: str = "",
        budget: str = "",
    ) -> str:
        """Manage knowledge graph. Actions: create, search, list, get, prune, check_quality, merge, export, import.

        create: requires entry_type (pattern/correction/expertise/gotcha/reference), title, content
        search: requires query (text search) or entry_type/domain filters
        list: optional entry_type filter
        get: requires entry_id
        prune: requires entry_id to mark as pruned
        check_quality: run quality analysis (duplicates, contradictions, stale entries)
        merge: merge duplicate entries (requires entry_id=keep, query=remove)
        export: export knowledge as JSON (optional domain/entry_type filters)
        import: import from JSON (content = JSON string)

        Optional budget parameter: full/normal/compact/minimal
        """
        if action in ("create", "prune"):
            rl_err = _check_rate_limit("gm_knowledge")
            if rl_err:
                return _json({"error": rl_err})

        level = BudgetLevel.parse(budget or None)
        if action == "create":
            for fname, fval in [("title", title), ("content", content)]:
                sz_err = _check_size(fval, fname)
                if sz_err:
                    return _json({"error": sz_err})
            content, scan_dets, scan_err = _scan_ingest(content, mode="redact")
            if scan_err:
                return _json({"error": scan_err})
            title = _redact_recall(title) or title
            result = knowledge.create(
                entry_type=entry_type, title=title, content=content,
                domain=domain or None, scope=scope, tags=tags or None,
            )
            if scan_dets:
                result["_redacted_secrets"] = scan_dets
            _auto_index("knowledge", result["id"], f"{title} {content}")

            # Auto-quality check: warn on duplicates/contradictions
            try:
                from greymatter_core.quality import QualityEngine
                qe = QualityEngine(db)
                issues = qe.find_duplicates(threshold=0.7) + qe.find_contradictions()
                # Only include issues involving the new entry
                relevant = [i for i in issues if result["id"] in i.entry_ids]
                if relevant:
                    result["_quality_warnings"] = [
                        {"type": i.issue_type, "severity": i.severity,
                         "description": i.description, "suggestion": i.suggestion}
                        for i in relevant
                    ]
            except Exception:
                pass  # Quality check is advisory, never block creation

            if budget:
                return _json(BudgetFormatter.format_single(result, level))
            return _json(result)
        elif action == "search":
            if budget:
                if level == BudgetLevel.FULL:
                    results = knowledge.search(
                        text=query or None,
                        entry_type=entry_type or None,
                        domain=domain or None,
                    )
                    return _json(BudgetFormatter.format_response(results, level, "knowledge_search"))
                elif level == BudgetLevel.MINIMAL:
                    count = knowledge.count(
                        entry_type=entry_type or None,
                        domain=domain or None,
                    )
                    return _json(BudgetFormatter.format_response([], level, "knowledge_search", total=count))
                else:
                    summary = knowledge.search_summary(
                        text=query or None,
                        entry_type=entry_type or None,
                        domain=domain or None,
                    )
                    return _json(BudgetFormatter.format_response(
                        summary["entries"], level, "knowledge_search", total=summary["total"]
                    ))
            return _json(knowledge.search_summary(
                text=query or None,
                entry_type=entry_type or None,
                domain=domain or None,
            ))
        elif action == "list":
            if budget:
                if level == BudgetLevel.FULL:
                    results = knowledge.search(entry_type=entry_type or None)
                    return _json(BudgetFormatter.format_response(results, level, "knowledge_list"))
                elif level == BudgetLevel.MINIMAL:
                    count = knowledge.count(entry_type=entry_type or None)
                    return _json(BudgetFormatter.format_response([], level, "knowledge_list", total=count))
                else:
                    summary = knowledge.search_summary(entry_type=entry_type or None)
                    return _json(BudgetFormatter.format_response(
                        summary["entries"], level, "knowledge_list", total=summary["total"]
                    ))
            return _json(knowledge.search_summary(
                entry_type=entry_type or None,
            ))
        elif action == "get":
            result = knowledge.get(entry_id)
            if result:
                _redact_results([result])
            if budget:
                return _json(BudgetFormatter.format_single(result, level))
            return _json(result)
        elif action == "prune":
            if entry_id:
                success = knowledge.prune(entry_id)
                return _json({"pruned": entry_id, "success": success})
            return _json({"error": "prune requires entry_id"})
        elif action == "check_quality":
            from greymatter_core.quality import QualityEngine
            qe = QualityEngine(db)
            report = qe.full_check()
            return _json(report.to_dict())
        elif action == "merge":
            if not entry_id or not query:
                return _json({"error": "merge requires entry_id (keep) and query (remove ID)"})
            from greymatter_core.quality import QualityEngine
            qe = QualityEngine(db)
            success = qe.merge_duplicates(keep_id=entry_id, remove_id=query)
            if success:
                _log_security_event(
                    "knowledge_merge", "low",
                    tool_name="gm_knowledge",
                    action_taken="merged",
                    detail=f"Kept {entry_id}, pruned {query}",
                )
            return _json({"merged": success, "kept": entry_id, "pruned": query})
        elif action == "export":
            from greymatter_core.export import KnowledgeExporter
            exporter = KnowledgeExporter(db)
            data = exporter.to_json(
                domain=domain or None,
                entry_type=entry_type or None,
            )
            return _json(data)
        elif action == "import":
            if not content:
                return _json({"error": "import requires content (JSON string)"})
            rl_err = _check_rate_limit("gm_knowledge")
            if rl_err:
                return _json({"error": rl_err})
            from greymatter_core.export import KnowledgeImporter
            try:
                import_data = json.loads(content)
            except json.JSONDecodeError as e:
                return _json({"error": f"Invalid JSON: {e}"})
            importer = KnowledgeImporter(db)
            result = importer.from_json(import_data)
            return _json(result)
        return _json({"error": f"Unknown action: {action}"})
    mcp._tool_functions["gm_knowledge"] = gm_knowledge

    # --- gm_work ---
    @mcp.tool()
    def gm_work(
        action: str,
        title: str = "",
        description: str = "",
        priority: int = 100,
        domain_tags: str = "",
        work_id: str = "",
        status: str = "",
        budget: str = "",
    ) -> str:
        """Manage work items. Actions: create, list, complete, update, get.

        create: requires title, optional description/priority/domain_tags
        list: optional status filter
        complete: requires work_id
        update: requires work_id, status
        get: requires work_id

        Optional budget parameter: full/normal/compact/minimal
        """
        level = BudgetLevel.parse(budget or None)
        if action == "create":
            result = work_items.create(
                title=title, description=description or None,
                priority=priority, domain_tags=domain_tags or None,
            )
            if budget:
                return _json(BudgetFormatter.format_single(result, level))
            return _json(result)
        elif action == "list":
            if budget:
                if level == BudgetLevel.MINIMAL:
                    count = work_items.count(status=status or None)
                    return _json(BudgetFormatter.format_response([], level, "work_list", total=count))
                else:
                    items = work_items.list(status=status or None)
                    return _json(BudgetFormatter.format_response(items, level, "work_list"))
            items = work_items.list(status=status or None)
            return _json(items)
        elif action == "complete":
            work_items.complete(work_id)
            result = work_items.get(work_id)
            if budget:
                return _json(BudgetFormatter.format_single(result, level))
            return _json(result)
        elif action == "update":
            work_items.update_status(work_id, status)
            result = work_items.get(work_id)
            if budget:
                return _json(BudgetFormatter.format_single(result, level))
            return _json(result)
        elif action == "get":
            result = work_items.get(work_id)
            if budget:
                return _json(BudgetFormatter.format_single(result, level))
            return _json(result)
        return _json({"error": f"Unknown action: {action}"})
    mcp._tool_functions["gm_work"] = gm_work

    # --- gm_soul ---
    @mcp.tool()
    def gm_soul(
        action: str = "read",
        section: str = "",
        content: str = "",
    ) -> str:
        """Manage soul document. Actions: read, section, summary.

        read: returns full soul document
        section: requires section name, returns that section
        summary: returns first 50 lines of soul document
        """
        if action == "read":
            if soul.exists():
                return _redact_recall(soul.load()) or "No soul document found."
            return "No soul document found."
        elif action == "section":
            if soul.exists():
                raw = soul.get_section(section) or f"Section '{section}' not found."
                return _redact_recall(raw) or raw
            return "No soul document found."
        elif action == "summary":
            if soul.exists():
                return _redact_recall(soul.get_summary()) or "No soul document found."
            return "No soul document found."
        return _json({"error": f"Unknown action: {action}"})
    mcp._tool_functions["gm_soul"] = gm_soul

    # --- gm_context ---
    @mcp.tool()
    def gm_context(
        action: str = "build",
        project: str = "",
        max_tokens: int = 4000,
        domains: str = "",
    ) -> str:
        """Build and manage session context for agent injection.

        Actions: build, bootstrap, relevance.

        build: Build session context (standards + documents + patterns)
        bootstrap: Full context bootstrap — build + soul summary + recent observations + quality score.
            Use this at session start for comprehensive context injection.
        relevance: Score context relevance (requires project)
        """
        if action == "build":
            ctx = context.build_session_context(
                project=project or None,
                max_tokens=max_tokens,
            )
            for key in ("recent_context", "active_patterns"):
                if key in ctx and isinstance(ctx[key], list):
                    _redact_results(ctx[key])
            return _json(ctx)

        elif action == "bootstrap":
            # Full context bootstrap for session start
            ctx = context.build_session_context(
                project=project or None,
                max_tokens=max_tokens,
            )
            for key in ("recent_context", "active_patterns"):
                if key in ctx and isinstance(ctx[key], list):
                    _redact_results(ctx[key])

            # Add soul summary
            soul_doc = soul.get_soul()
            if soul_doc:
                ctx["soul_summary"] = soul_doc[:500] if len(soul_doc) > 500 else soul_doc

            # Add recent high-confidence observations
            recent_obs = memory.db.execute(
                "SELECT title, category, confidence FROM observations "
                "WHERE pruned = 0 AND confidence >= 0.7 "
                "ORDER BY created_at DESC LIMIT 10"
            )
            ctx["recent_memories"] = recent_obs

            # Add knowledge quality score
            try:
                from greymatter_core.quality import QualityEngine
                qe = QualityEngine(db)
                report = qe.full_check()
                ctx["knowledge_quality"] = {
                    "score": round(report.score, 3),
                    "issues": report.issue_count,
                }
            except Exception:
                pass

            # Add domain-specific knowledge if domains specified
            if domains:
                domain_list = [d.strip() for d in domains.split(",") if d.strip()]
                domain_knowledge = {}
                for d in domain_list:
                    entries = knowledge.search(domain=d, limit=5)
                    if entries:
                        domain_knowledge[d] = [
                            {"title": e["title"], "type": e.get("entry_type", "")}
                            for e in entries
                        ]
                if domain_knowledge:
                    ctx["domain_knowledge"] = domain_knowledge

            return _json(ctx)

        elif action == "relevance":
            # Check context serving stats
            stats = {
                "project": project or "all",
                "observations": memory.stats().get("observations", 0),
                "patterns": memory.stats().get("patterns", 0),
                "knowledge": memory.stats().get("knowledge", 0),
            }
            return _json(stats)

        return _json({"error": f"Unknown action: {action}"})
    mcp._tool_functions["gm_context"] = gm_context

    # --- gm_standards ---
    @mcp.tool()
    def gm_standards(
        action: str = "list",
        severity: str = "",
    ) -> str:
        """Manage quality standards. Actions: list, seed, payload.

        list: returns active standards, optional severity filter
        seed: seeds default standards if not already present
        payload: returns compact JSON for context injection
        """
        if action == "list":
            severity_filter = [severity] if severity else None
            return _json(standards.get_active(severity_filter=severity_filter))
        elif action == "seed":
            count = standards.seed_defaults()
            return _json({"seeded": count})
        elif action == "payload":
            return standards.get_context_payload()
        return _json({"error": f"Unknown action: {action}"})
    mcp._tool_functions["gm_standards"] = gm_standards

    # --- gm_benchmark ---
    @mcp.tool()
    def gm_benchmark(
        action: str = "summary",
        approach: str = "",
    ) -> str:
        """View benchmark data. Actions: summary, density, quality, compare.

        summary: overall summary by approach
        density: defect density by approach
        quality: first-pass quality scores
        compare: compare two approaches (set approach to filter)
        """
        if action == "summary":
            return _json(benchmarks.summary())
        elif action == "density":
            return _json(benchmarks.defect_density(approach=approach or None))
        elif action == "quality":
            return _json(benchmarks.first_pass_quality())
        elif action == "compare":
            return _json({
                "density": benchmarks.defect_density(),
                "quality": benchmarks.first_pass_quality(),
                "summary": benchmarks.summary(),
            })
        return _json({"error": f"Unknown action: {action}"})
    mcp._tool_functions["gm_benchmark"] = gm_benchmark

    # --- gm_docs ---
    @mcp.tool()
    def gm_docs(
        action: str = "list",
        doc_type: str = "",
        project: str = "",
        tags: str = "",
        query: str = "",
        doc_id: str = "",
        title: str = "",
        content: str = "",
        file_path: str = "",
        budget: str = "",
    ) -> str:
        """Manage documents. Actions: list, search, get, create, import.

        list: optional doc_type/project/tags filter
        search: uses doc_type/project/tags filters
        get: requires doc_id
        create: requires doc_type, title, content
        import: requires file_path, optional doc_type/project

        Optional budget parameter: full/normal/compact/minimal
        """
        level = BudgetLevel.parse(budget or None)
        if action == "list" or action == "search":
            if budget:
                if level == BudgetLevel.FULL:
                    results = docs.search(
                        doc_type=doc_type or None,
                        project=project or None,
                        tags=tags or None,
                    )
                    return _json(BudgetFormatter.format_response(results, level, "docs_list"))
                elif level == BudgetLevel.MINIMAL:
                    count = docs.count(
                        doc_type=doc_type or None,
                        project=project or None,
                    )
                    return _json(BudgetFormatter.format_response([], level, "docs_list", total=count))
                else:
                    summary = docs.search_summary(
                        doc_type=doc_type or None,
                        project=project or None,
                        tags=tags or None,
                    )
                    return _json(BudgetFormatter.format_response(
                        summary["documents"], level, "docs_list", total=summary["total"]
                    ))
            return _json(docs.search_summary(
                doc_type=doc_type or None,
                project=project or None,
                tags=tags or None,
            ))
        elif action == "get":
            result = docs.get(doc_id)
            if result:
                _redact_results([result])
            if budget:
                return _json(BudgetFormatter.format_single(result, level))
            return _json(result)
        elif action == "create":
            content, scan_dets, scan_err = _scan_ingest(content, mode="redact")
            if scan_err:
                return _json({"error": scan_err})
            title = _redact_recall(title) or title
            result = docs.create(
                doc_type=doc_type, title=title, content=content,
                project=project or None, tags=tags or None,
            )
            if scan_dets:
                result["_redacted_secrets"] = scan_dets
            _auto_index("documents", result["id"], f"{title} {content}")
            if budget:
                return _json(BudgetFormatter.format_single(result, level))
            return _json(result)
        elif action == "import":
            result = docs.import_file(
                file_path, doc_type=doc_type or "research",
                project=project or None,
            )
            if budget:
                return _json(BudgetFormatter.format_single(result, level))
            return _json(result)
        return _json({"error": f"Unknown action: {action}"})
    mcp._tool_functions["gm_docs"] = gm_docs

    # --- gm_app_register ---
    @mcp.tool()
    def gm_app_register(
        app_name: str,
        version: str,
        agents: str,
    ) -> str:
        """Register an external app's agent manifest with GreyMatter.

        GreyMatter stores the manifest so it knows what agents are available,
        their domains, and capabilities. This enables GreyMatter to dispatch,
        schedule, and review agents from registered apps.

        Args:
            app_name: Application name (e.g., "salesos")
            version: Application version (e.g., "4.0.0")
            agents: JSON array of agent definitions, each with:
                - name: Agent name
                - domains: List of domains the agent covers
                - requires_web: Whether the agent needs web access (optional)
        """
        try:
            agent_list = json.loads(agents)
        except json.JSONDecodeError:
            return "Error: agents must be valid JSON array"

        manifest = {
            "app": app_name,
            "version": version,
            "agents": agent_list,
            "registered_at": datetime.now(timezone.utc).isoformat(),
        }

        docs.create(
            doc_type="app_manifest",
            title=f"{app_name}-manifest",
            content=json.dumps(manifest, indent=2),
            project=app_name,
        )

        return f"Registered {app_name} v{version} with {len(agent_list)} agents"
    mcp._tool_functions["gm_app_register"] = gm_app_register

    # --- gm_app_dispatch ---
    @mcp.tool()
    def gm_app_dispatch(
        action: str = "dispatch",
        app_name: str = "",
        agent_name: str = "",
        task_description: str = "",
        account_id: str = "",
        domains: str = "",
        work_id: str = "",
        result_summary: str = "",
    ) -> str:
        """Agent orchestration with lifecycle tracking.

        Actions: dispatch, complete, fail, status, list.

        dispatch: Create tracked agent task (requires app_name, agent_name, task_description)
        complete: Mark agent task as complete (requires work_id, optional result_summary)
        fail: Mark agent task as failed (requires work_id, optional result_summary)
        status: Get agent task status (requires work_id)
        list: List active agent tasks (optional app_name filter)
        """
        if action == "dispatch":
            if not app_name or not agent_name or not task_description:
                return _json({"error": "dispatch requires app_name, agent_name, task_description"})

            item = work_items.create(
                title=f"{app_name}:{agent_name} - {task_description[:50]}",
                description=task_description,
                domain_tags=domains or None,
                project=app_name,
            )

            context_parts = []
            domain_list = [d.strip() for d in domains.split(",") if d.strip()]
            for domain in domain_list:
                domain_patterns = patterns.search(domain=domain, min_confidence="medium")
                if domain_patterns:
                    context_parts.append(f"Patterns for {domain}:")
                    for p in domain_patterns[:3]:
                        context_parts.append(f"  - {p['title']}: {p['observation']}")
                domain_knowledge = knowledge.search(domain=domain)
                if domain_knowledge:
                    context_parts.append(f"Knowledge for {domain}:")
                    for k in domain_knowledge[:3]:
                        context_parts.append(f"  - {k['title']}: {k['content'][:100]}")

            return _json({
                "work_item_id": item["id"],
                "enhanced_context": "\n".join(context_parts) if context_parts else "",
                "status": "dispatched",
            })

        elif action == "complete":
            if not work_id:
                return _json({"error": "complete requires work_id"})
            work_items.complete(work_id)
            if result_summary:
                work_items.update_review(work_id, "completed", result_summary)
            return _json({"work_id": work_id, "status": "completed"})

        elif action == "fail":
            if not work_id:
                return _json({"error": "fail requires work_id"})
            work_items.update_status(work_id, "failed")
            if result_summary:
                work_items.update_review(work_id, "failed", f"FAILED: {result_summary}")
            return _json({"work_id": work_id, "status": "failed"})

        elif action == "status":
            if not work_id:
                return _json({"error": "status requires work_id"})
            item = work_items.get(work_id)
            return _json(item)

        elif action == "list":
            items = work_items.list(status="in_progress")
            if app_name:
                items = [i for i in items if i.get("project") == app_name]
            return _json({"active_tasks": len(items), "tasks": items})

        return _json({"error": f"Unknown action: {action}"})
    mcp._tool_functions["gm_app_dispatch"] = gm_app_dispatch

    # --- gm_semantic ---
    @mcp.tool()
    def gm_semantic(
        action: str = "search",
        query: str = "",
        tables: str = "",
        limit: int = 10,
        detail: str = "chunks",
        budget: str = "",
    ) -> str:
        """Semantic vector search across GreyMatter data.

        Actions:
        - search: semantic search (requires query). tables: comma-separated filter (meetings,documents,knowledge,accounts)
        - hybrid: combined keyword + semantic search (requires query)
        - index: batch index a table (tables param) or all tables if empty
        - status: show embedding counts per table

        detail: 'chunks' returns individual chunk matches; 'documents' groups by parent document.

        Optional budget parameter: full/normal/compact/minimal
        """
        from greymatter_core.embeddings import OllamaEmbedding
        from greymatter_core.semantic import SemanticSearch

        level = BudgetLevel.parse(budget or None)

        if action == "status":
            try:
                embedder = OllamaEmbedding()
                search = SemanticSearch(db, embedder)
                return _json(search.status())
            except Exception as e:
                return _json({"error": str(e)})

        if action == "index":
            try:
                embedder = OllamaEmbedding()
                search = SemanticSearch(db, embedder)
                table_list = [t.strip() for t in tables.split(",") if t.strip()] if tables else None
                if table_list:
                    results = {t: search.index_table(t) for t in table_list}
                else:
                    results = {t: search.index_table(t) for t in ["meetings", "documents", "knowledge", "observations", "accounts"]}
                return _json(results)
            except Exception as e:
                return _json({"error": str(e)})

        if not query:
            return _json({"error": "query is required for search/hybrid actions"})

        try:
            embedder = OllamaEmbedding()
            search = SemanticSearch(db, embedder)
            table_list = [t.strip() for t in tables.split(",") if t.strip()] if tables else None

            if action == "hybrid":
                results = search.hybrid_search(query, tables=table_list, limit=limit, detail=detail)
            else:
                results = search.search(query, tables=table_list, limit=limit, detail=detail)

            # Strip large fields to avoid MCP response size limits
            for r in results:
                if "transcript" in r and r["transcript"] and len(r["transcript"]) > 500:
                    r["transcript"] = r["transcript"][:500] + "..."
                if "content" in r and r["content"] and len(r["content"]) > 500:
                    r["content"] = r["content"][:500] + "..."

            # Redact secrets from recall results
            _redact_results(results)

            if budget:
                return _json(BudgetFormatter.format_response(results, level, "semantic_search"))
            return _json(results)
        except Exception as e:
            return _json({"error": str(e)})
    mcp._tool_functions["gm_semantic"] = gm_semantic

    # --- gm_checkpoint ---
    @mcp.tool()
    def gm_checkpoint(
        action: str = "save",
        session_id: str = "",
        context_summary: str = "",
        open_items: str = "",
    ) -> str:
        """Session checkpoint management for context continuity.

        Actions:
        - save: Create a checkpoint (auto-detects current session if session_id empty)
        - restore: Get latest checkpoint for recovery
        - list: List recent checkpoints
        """
        if action == "save":
            sid = session_id
            if not sid:
                current = sessions.get_current()
                if not current:
                    current = sessions.start()
                sid = current["id"]
            result = sessions.checkpoint(sid, context_summary=context_summary, open_items=open_items)
            return _json(result)
        elif action == "restore":
            sid = session_id
            if not sid:
                current = sessions.get_current()
                sid = current["id"] if current else ""
            if not sid:
                return _json({"error": "No active session found"})
            cp = sessions.get_latest_checkpoint(sid)
            return _json(cp or {"error": "No checkpoints found"})
        elif action == "list":
            # Get recent checkpoints across sessions
            rows = db.execute(
                "SELECT * FROM session_checkpoints ORDER BY checkpoint_at DESC LIMIT 10"
            )
            return _json({"total": len(rows), "checkpoints": rows})
        return _json({"error": f"Unknown action: {action}"})
    mcp._tool_functions["gm_checkpoint"] = gm_checkpoint

    # --- gm_observe ---
    @mcp.tool()
    def gm_observe(
        action: str = "list",
        observation_id: str = "",
        session_id: str = "",
        category: str = "",
        title: str = "",
        content: str = "",
        budget: str = "",
    ) -> str:
        """Manage observational memory with spaced repetition.

        Actions: list, get, create, confirm, prune, consolidate, maintain, due.

        list: List observations (optional category/session_id filter)
        get: Get full observation by ID (requires observation_id)
        create: Manually create an observation (requires title + content + category)
        confirm: Boost confidence of an observation (requires observation_id)
        prune: Mark observation as incorrect/irrelevant (requires observation_id)
        consolidate: Run FSRS-6 decay maintenance + cross-session consolidation.
            Decays old memories, prunes forgotten ones, and promotes recurring themes.
        maintain: Run FSRS-6 decay only (no consolidation). Returns decayed/pruned counts.
        due: List memories approaching decay threshold (retrievability < 50%).
            These are candidates for review/confirmation to prevent forgetting.
        """
        # Rate limit write operations
        if action in ("create", "confirm", "prune", "consolidate", "maintain"):
            rl_err = _check_rate_limit("gm_observe")
            if rl_err:
                return _json({"error": rl_err})
            # Policy check
            pol_err = _check_policy("gm_observe", action, content)
            if pol_err:
                return _json({"error": pol_err})

        level = BudgetLevel.parse(budget or None)

        if action == "list":
            params = []
            where_parts = ["pruned = 0"]
            if category:
                where_parts.append("category = ?")
                params.append(category)
            if session_id:
                where_parts.append("session_id = ?")
                params.append(session_id)
            where_clause = " AND ".join(where_parts)

            results = memory.db.execute(
                f"SELECT * FROM observations WHERE {where_clause}"
                " ORDER BY confidence DESC LIMIT 25",
                tuple(params),
            )
            _redact_results(results, fields=("content", "title", "observation"))

            count_params = []
            count_where = ["pruned = 0"]
            if category:
                count_where.append("category = ?")
                count_params.append(category)
            count_row = memory.db.execute_one(
                f"SELECT COUNT(*) as total FROM observations WHERE {' AND '.join(count_where)}",
                tuple(count_params),
            )
            total = count_row["total"] if count_row else 0

            if budget:
                return _json(BudgetFormatter.format_response(
                    results, level, "observation_list", total=total
                ))
            # Default compact format for list
            compact = [{
                "id": r["id"],
                "category": r["category"],
                "title": r["title"],
                "confidence": r["confidence"],
                "created_at": r["created_at"],
            } for r in results]
            return _json({"total": total, "returned": len(compact), "results": compact})

        elif action == "get":
            if not observation_id:
                return _json({"error": "observation_id required for get action"})
            result = memory.db.execute_one(
                "SELECT * FROM observations WHERE id = ? AND pruned = 0",
                (observation_id,),
            )
            if result:
                _redact_results([result], fields=("content", "title", "observation"))
            return _json(result or {"error": f"Observation {observation_id} not found"})

        elif action == "create":
            if not all([title, content, category]):
                return _json({"error": "title, content, and category required for create action"})
            for fname, fval in [("title", title), ("content", content)]:
                sz_err = _check_size(fval, fname)
                if sz_err:
                    return _json({"error": sz_err})
            if category not in VALID_CATEGORIES:
                return _json({"error": f"Invalid category. Must be one of: {VALID_CATEGORIES}"})
            content, scan_dets, scan_err = _scan_ingest(content, mode="redact")
            if scan_err:
                return _json({"error": scan_err})
            title = _redact_recall(title) or title
            sid = session_id
            if not sid:
                current = sessions.get_current()
                if not current:
                    current = sessions.start()
                sid = current["id"]
            result = memory.observe(
                content=content,
                category=category,
                title=title,
                session_id=sid,
                source="manual",
            )
            if scan_dets:
                result["_redacted_secrets"] = scan_dets
            _auto_index("observations", result["id"], f"{title} {content}")
            return _json(result)

        elif action == "confirm":
            if not observation_id:
                return _json({"error": "observation_id required for confirm action"})
            result = memory.confirm(observation_id)
            return _json(result or {"error": f"Observation {observation_id} not found"})

        elif action == "prune":
            if not observation_id:
                return _json({"error": "observation_id required for prune action"})
            memory.db.execute(
                "UPDATE observations SET pruned = 1, updated_at = datetime('now') WHERE id = ?",
                (observation_id,),
            )
            return _json({"status": "pruned", "observation_id": observation_id})

        elif action == "consolidate":
            # Run maintenance (FSRS-6 decay) before consolidation
            maintain_result = memory.maintain()
            consolidate_result = memory.consolidate()
            if maintain_result["decayed"] > 0 or maintain_result["pruned"] > 0:
                _log_security_event(
                    "memory_maintenance", "low",
                    tool_name="gm_observe",
                    action_taken="maintained",
                    detail=f"Decayed {maintain_result['decayed']}, pruned {maintain_result['pruned']}",
                )
            return _json({
                "maintenance": maintain_result,
                "consolidation": consolidate_result,
            })

        elif action == "maintain":
            result = memory.maintain()
            if result["decayed"] > 0 or result["pruned"] > 0:
                _log_security_event(
                    "memory_maintenance", "low",
                    tool_name="gm_observe",
                    action_taken="maintained",
                    detail=f"Decayed {result['decayed']}, pruned {result['pruned']}",
                )
            return _json(result)

        elif action == "due":
            # Find observations approaching decay threshold
            import math
            from datetime import datetime as _dt, timezone as _tz
            candidates = memory.db.execute(
                """SELECT id, title, category, confidence, stability_days,
                          last_confirmed_at, created_at, domains
                   FROM observations
                   WHERE pruned = 0
                   ORDER BY confidence ASC
                   LIMIT 50""",
            )
            now = _dt.now(_tz.utc)
            due_items = []
            for obs in candidates:
                stability = obs.get("stability_days") or 45
                ref_str = obs.get("last_confirmed_at") or obs["created_at"]
                try:
                    ref = _dt.fromisoformat(ref_str)
                    if ref.tzinfo is None:
                        ref = ref.replace(tzinfo=_tz.utc)
                except (ValueError, TypeError):
                    continue
                days_elapsed = max((now - ref).total_seconds() / 86400, 0)
                # FSRS-6 retrievability
                retrievability = 0.05 + 0.95 * (1 + days_elapsed / (2 * stability)) ** (-2)
                if retrievability < 0.5:  # Below 50% retrievability = due for review
                    due_items.append({
                        "id": obs["id"],
                        "title": obs["title"],
                        "category": obs["category"],
                        "confidence": obs["confidence"],
                        "retrievability": round(retrievability, 3),
                        "days_since_review": round(days_elapsed, 1),
                        "domains": obs.get("domains", ""),
                    })
            due_items.sort(key=lambda d: d["retrievability"])
            return _json({"due_count": len(due_items), "due": due_items[:25]})

        return _json({"error": f"Unknown action: {action}"})

    mcp._tool_functions["gm_observe"] = gm_observe

    # --- gm_code ---
    @mcp.tool()
    def gm_code(
        action: str,
        directory: str = "",
        repo: str = "",
        query: str = "",
        language: str = "",
        kind: str = "",
        symbol_id: str = "",
        file_path: str = "",
        target_type: str = "",
        target_id: str = "",
        relationship: str = "",
        limit: int = 50,
    ) -> str:
        """Code intelligence — index, search, and navigate code symbols.

        Actions: index, search, get, outline, link, links, status.

        index: Index a directory's source files (requires directory, optional repo name)
        search: Search symbols by name/signature (requires query, optional language/kind/repo)
        get: Get full symbol details (requires symbol_id)
        outline: Get file outline — all symbols in a file (requires repo + file_path)
        link: Link a symbol to knowledge/pattern/work item (requires symbol_id, target_type, target_id, relationship)
        links: Get all links for a symbol (requires symbol_id)
        status: Show indexing stats
        """
        try:
            from greymatter_code.db import CodeDB
            code_db = CodeDB()
        except Exception as e:
            return _json({"error": f"Code module not available: {e}"})

        if action == "index":
            if not directory:
                return _json({"error": "index requires directory"})
            from greymatter_code.indexer import Indexer
            from greymatter_code.registry import get_registry
            registry = get_registry()
            indexer = Indexer(code_db, registry)
            repo_name = repo or Path(directory).name
            result = indexer.index_directory(directory, repo_name)
            return _json(result)
        elif action == "search":
            results = code_db.search_symbols(
                query=query or None,
                repo=repo or None,
                language=language or None,
                kind=kind or None,
                limit=limit,
            )
            return _json({"count": len(results), "symbols": results})
        elif action == "get":
            if not symbol_id:
                return _json({"error": "get requires symbol_id"})
            result = code_db.get_symbol(symbol_id)
            return _json(result)
        elif action == "outline":
            if not repo or not file_path:
                return _json({"error": "outline requires repo and file_path"})
            results = code_db.get_file_outline(repo, file_path)
            return _json({"file": file_path, "symbols": results})
        elif action == "link":
            if not symbol_id or not target_type or not target_id or not relationship:
                return _json({"error": "link requires symbol_id, target_type, target_id, relationship"})
            from greymatter_code.models import SymbolLink
            link_obj = SymbolLink(
                symbol_id=symbol_id,
                target_type=target_type,
                target_id=target_id,
                relationship=relationship,
            )
            code_db.link_symbol(link_obj)
            return _json({"linked": True, "symbol_id": symbol_id, "target": f"{target_type}:{target_id}"})
        elif action == "links":
            if not symbol_id:
                return _json({"error": "links requires symbol_id"})
            results = code_db.get_symbol_links(symbol_id)
            return _json({"symbol_id": symbol_id, "links": results})
        elif action == "status":
            total = code_db.count_symbols()
            repos = code_db.execute(
                "SELECT repo, COUNT(*) as count FROM code_symbols GROUP BY repo ORDER BY count DESC"
            ).fetchall()
            return _json({
                "total_symbols": total,
                "repos": [{"repo": r[0], "count": r[1]} for r in repos],
            })
        return _json({"error": f"Unknown action: {action}"})
    mcp._tool_functions["gm_code"] = gm_code

    # --- gm_security ---
    @mcp.tool()
    def gm_security(
        action: str,
        content: str = "",
        file_path: str = "",
        mode: str = "",
        rule_id: str = "",
        tool_name: str = "",
        severity: str = "",
        limit: int = 50,
    ) -> str:
        """Security operations — scan, policy, audit, LLM-powered analysis.

        Actions: scan, redact, policy_check, audit_log, posture,
                 llm_scan, llm_redact, injection_check, content_safety, full_scan.

        scan: Regex scan for secrets/PII (requires content or file_path)
        redact: Regex scan and return redacted version (requires content)
        policy_check: Evaluate content against policy rules (requires content, optional tool_name)
        audit_log: View security events (optional severity filter, limit)
        posture: Full security posture report
        llm_scan: Deep PII scan using Nemotron Nano (requires content)
        llm_redact: Deep PII redaction using Nemotron Nano (requires content)
        injection_check: Prompt injection detection using Nemotron Nano (requires content)
        content_safety: Content safety classification using Nemotron Nano (requires content)
        full_scan: Run all SecureLLM checks at once (requires content)
        """
        if action == "scan":
            from greymatter_core.scanner import SecretScanner
            scanner = SecretScanner()
            text = content
            if not text and file_path:
                try:
                    text = Path(file_path).read_text()
                except Exception as e:
                    return _json({"error": f"Cannot read file: {e}"})
            if not text:
                return _json({"error": "scan requires content or file_path"})
            detections = scanner.scan(text)
            return _json({
                "detections": len(detections),
                "findings": [
                    {"pattern": d.pattern_name, "severity": d.severity,
                     "confidence": d.confidence, "start": d.start, "end": d.end}
                    for d in detections
                ],
            })
        elif action == "redact":
            if not content:
                return _json({"error": "redact requires content"})
            from greymatter_core.scanner import SecretScanner
            scanner = SecretScanner()
            redacted = scanner.redact(content)
            detections = scanner.scan(content)
            return _json({
                "redacted_content": redacted,
                "secrets_found": len(detections),
            })
        elif action == "policy_check":
            if not content:
                return _json({"error": "policy_check requires content"})
            try:
                from greymatter_core.policy import PolicyEngine, EvalContext
                policy_path = Path.home() / ".greymatter" / "policy.yaml"
                if not policy_path.exists():
                    return _json({"outcome": "allow", "reason": "No policy rules configured"})
                engine = PolicyEngine.from_yaml(policy_path.read_text())
                ctx = EvalContext(
                    tool=tool_name or "gm_security",
                    action="check",
                    content=content,
                )
                decision = engine.evaluate(ctx)
                return _json({
                    "outcome": decision.outcome.value,
                    "rule_id": decision.rule_id,
                    "reason": decision.reason,
                })
            except Exception as e:
                return _json({"error": f"Policy check failed: {e}"})
        elif action == "audit_log":
            query = "SELECT * FROM security_events"
            params: list = []
            conditions = []
            if severity:
                conditions.append("severity = ?")
                params.append(severity)
            if conditions:
                query += " WHERE " + " AND ".join(conditions)
            query += " ORDER BY created_at DESC LIMIT ?"
            params.append(limit)
            try:
                events = db.execute(query, tuple(params))
                return _json({"count": len(events), "events": events})
            except Exception:
                return _json({"count": 0, "events": []})
        elif action == "posture":
            report: dict[str, Any] = {}
            # Encryption
            keyfile = Path.home() / ".greymatter" / ".keyfile"
            report["encryption"] = {
                "key_exists": keyfile.exists(),
            }
            # Scanner
            report["scanner"] = {
                "enabled": config.scanner_enabled if config else True,
                "mode": config.scanner_mode if config else "redact",
            }
            # Policy
            policy_path = Path.home() / ".greymatter" / "policy.yaml"
            if policy_path.exists():
                try:
                    from greymatter_core.policy import PolicyEngine
                    engine = PolicyEngine.from_yaml(policy_path.read_text())
                    report["policy"] = {
                        "rules_count": len(engine.rules),
                        "active_rules": len([r for r in engine.rules if r.enabled and not r.shadow]),
                    }
                except Exception:
                    report["policy"] = {"rules_count": 0}
            else:
                report["policy"] = {"rules_count": 0}
            # Audit
            try:
                total = db.execute_one("SELECT COUNT(*) as cnt FROM security_events")
                report["audit"] = {"total_events": total["cnt"] if total else 0}
            except Exception:
                report["audit"] = {"total_events": 0}
            return _json(report)
        elif action == "llm_scan":
            # SecureLLM deep PII scan using Nemotron Nano
            if not content:
                return _json({"error": "llm_scan requires content"})
            try:
                import asyncio
                sys.path.insert(0, str(Path(__file__).resolve().parents[3]))
                from securellm.actions.pii_detection import detect_pii
                result = asyncio.run(detect_pii(text=content, source="mcp"))
                return _json({
                    "has_pii": result["has_pii"],
                    "count": result["count"],
                    "categories": result["categories"],
                    "masked_text": result["masked_text"],
                    "engine": "nemotron-nano",
                })
            except Exception as e:
                return _json({"error": f"SecureLLM PII scan failed: {e}"})
        elif action == "llm_redact":
            # SecureLLM deep redaction using Nemotron Nano
            if not content:
                return _json({"error": "llm_redact requires content"})
            try:
                import asyncio
                sys.path.insert(0, str(Path(__file__).resolve().parents[3]))
                from securellm.actions.pii_detection import detect_pii
                result = asyncio.run(detect_pii(text=content, source="mcp"))
                return _json({
                    "redacted_content": result["masked_text"],
                    "pii_found": result["count"],
                    "categories": result["categories"],
                    "engine": "nemotron-nano",
                })
            except Exception as e:
                return _json({"error": f"SecureLLM redaction failed: {e}"})
        elif action == "injection_check":
            # SecureLLM prompt injection detection using Nemotron Nano
            if not content:
                return _json({"error": "injection_check requires content"})
            try:
                import asyncio
                sys.path.insert(0, str(Path(__file__).resolve().parents[3]))
                from securellm.actions.prompt_injection import detect_injection
                result = asyncio.run(detect_injection(text=content))
                return _json({
                    "is_injection": result["is_injection"],
                    "confidence": result["confidence"],
                    "attack_type": result["attack_type"],
                    "engine": "nemotron-nano",
                })
            except Exception as e:
                return _json({"error": f"SecureLLM injection check failed: {e}"})
        elif action == "content_safety":
            # SecureLLM content safety classification using Nemotron Nano
            if not content:
                return _json({"error": "content_safety requires content"})
            try:
                import asyncio
                sys.path.insert(0, str(Path(__file__).resolve().parents[3]))
                from securellm.actions.content_safety import content_safety as cs_check
                result = asyncio.run(cs_check(text=content, source="mcp"))
                return _json({
                    "is_safe": result["is_safe"],
                    "confidence": result["confidence"],
                    "violated_categories": result["violated_categories"],
                    "engine": "nemotron-nano",
                })
            except Exception as e:
                return _json({"error": f"SecureLLM safety check failed: {e}"})
        elif action == "full_scan":
            # Run all SecureLLM checks at once
            if not content:
                return _json({"error": "full_scan requires content"})
            try:
                import asyncio
                sys.path.insert(0, str(Path(__file__).resolve().parents[3]))
                from securellm.actions.pii_detection import detect_pii
                from securellm.actions.prompt_injection import detect_injection
                from securellm.actions.content_safety import content_safety as cs_check

                pii = asyncio.run(detect_pii(text=content, source="mcp"))
                injection = asyncio.run(detect_injection(text=content))
                safety = asyncio.run(cs_check(text=content, source="mcp"))

                safe = (
                    not pii["has_pii"]
                    and not injection["is_injection"]
                    and safety["is_safe"]
                )
                flags = []
                if pii["has_pii"]:
                    flags.append(f"PII: {pii['count']} items ({', '.join(pii['categories'])})")
                if injection["is_injection"]:
                    flags.append(f"Injection: {injection['attack_type']} ({injection['confidence']:.0%})")
                if not safety["is_safe"]:
                    flags.append(f"Unsafe: {', '.join(safety['violated_categories'])}")

                return _json({
                    "verdict": "SAFE" if safe else "FLAGGED",
                    "flags": flags,
                    "pii": {"has_pii": pii["has_pii"], "count": pii["count"], "categories": pii["categories"]},
                    "injection": {"is_injection": injection["is_injection"], "confidence": injection["confidence"], "attack_type": injection["attack_type"]},
                    "content_safety": {"is_safe": safety["is_safe"], "violated_categories": safety["violated_categories"]},
                    "masked_text": pii["masked_text"] if pii["has_pii"] else None,
                    "engine": "nemotron-nano",
                })
            except Exception as e:
                return _json({"error": f"SecureLLM full scan failed: {e}"})
        return _json({"error": f"Unknown action: {action}"})
    mcp._tool_functions["gm_security"] = gm_security

    # --- gm_cluster ---
    @mcp.tool()
    def gm_cluster(
        action: str,
        hub_url: str = "",
        join_token: str = "",
        node_id: str = "",
    ) -> str:
        """Cluster management — status, health, join, leave.

        Actions: status, health, join, leave, discover.

        status: Show current node state and cluster info
        health: Run node health checks (db accessible, writable, sync state, disk)
        join: Join a cluster hub (requires hub_url + join_token)
        leave: Gracefully leave the cluster
        discover: Discover cluster endpoints (manual config + Tailscale)
        """
        if action == "status":
            try:
                from greymatter_core.cluster.state import NodeStateMachine
                from greymatter_core.sync.tracking import get_node_id, get_sync_version
                sm = NodeStateMachine()
                nid = get_node_id(db)
                version = get_sync_version(db)
                return _json({
                    "state": sm.state.value,
                    "node_id": nid,
                    "sync_version": version,
                    "is_clustered": sm.is_clustered,
                })
            except Exception as e:
                return _json({"state": "solo", "error": str(e)})
        elif action == "health":
            try:
                from greymatter_core.cluster.health import HealthChecker
                db_path = str(Path.home() / ".greymatter" / "greymatter.db")
                checker = HealthChecker(db, db_path=db_path)
                report = checker.check_node()
                return _json(report.to_dict())
            except Exception as e:
                return _json({"status": "unknown", "error": str(e)})
        elif action == "join":
            if not hub_url or not join_token:
                return _json({"error": "join requires hub_url and join_token"})
            return _json({
                "status": "join_not_implemented_in_solo",
                "message": "Cluster join requires distributed mode. Use gm_cluster status to check current state.",
            })
        elif action == "leave":
            return _json({
                "status": "not_clustered",
                "message": "Node is in solo mode. No cluster to leave.",
            })
        elif action == "discover":
            try:
                from greymatter_core.cluster.discovery import discover_all
                config_path = Path.home() / ".greymatter" / "cluster.json"
                endpoints = discover_all(
                    config_path=str(config_path) if config_path.exists() else None,
                )
                return _json({
                    "endpoints": [ep.to_dict() for ep in endpoints],
                    "count": len(endpoints),
                })
            except Exception as e:
                return _json({"endpoints": [], "error": str(e)})
        return _json({"error": f"Unknown action: {action}"})
    mcp._tool_functions["gm_cluster"] = gm_cluster

    # --- Extension tool registration ---
    # Extensions that called register_tool_extension() get their tools wired up here.
    for ext_callback in _tool_extensions:
        try:
            ext_callback(mcp, db, config)
            logger.info("Loaded extension tools: %s", ext_callback.__module__)
        except Exception as e:
            logger.warning("Failed to load extension tools from %s: %s", ext_callback, e)

    return mcp


# Entry point for running the MCP server
def main():
    app = create_app()
    app.run()


if __name__ == "__main__":
    main()
