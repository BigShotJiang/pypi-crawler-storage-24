"""GreyMatter MCP Plugin for Claude Code."""
