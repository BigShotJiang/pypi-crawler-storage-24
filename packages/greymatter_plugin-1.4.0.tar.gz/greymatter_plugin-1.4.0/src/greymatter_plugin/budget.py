"""Budget-aware response formatting for GreyMatter MCP tools.

Provides dynamic response verbosity scaling based on a budget parameter.
Tools return less detail as context pressure increases:

    full    → complete records (all fields, full text)
    normal  → summaries with IDs (Item 1 behavior, default)
    compact → IDs + one-line titles only
    minimal → counts only, no individual items
"""
from __future__ import annotations

import json
from enum import Enum
from typing import Any

CHARS_PER_TOKEN = 4


class BudgetLevel(Enum):
    """Response verbosity levels, ordered most verbose to most terse."""

    FULL = "full"
    NORMAL = "normal"
    COMPACT = "compact"
    MINIMAL = "minimal"

    @classmethod
    def parse(cls, value: str | None) -> BudgetLevel:
        """Parse budget string, defaulting to NORMAL for unknown values."""
        if value is None:
            return cls.NORMAL
        try:
            return cls(value.lower().strip())
        except ValueError:
            return cls.NORMAL


# Per-tool field configurations.
# Keys: tool action identifiers (e.g., "pattern_list", "salesos_search")
# Values: dict mapping budget level to field whitelist.
# None = all fields (passthrough). [] = count only (minimal).

TOOL_FIELDS: dict[str, dict[BudgetLevel, list[str] | None]] = {
    "pattern_list": {
        BudgetLevel.FULL: None,
        BudgetLevel.NORMAL: ["id", "type", "domain", "title", "confidence", "confirmations", "created_at"],
        BudgetLevel.COMPACT: ["id", "title", "confidence"],
        BudgetLevel.MINIMAL: [],
    },
    "pattern_search": {
        BudgetLevel.FULL: None,
        BudgetLevel.NORMAL: ["id", "type", "domain", "title", "confidence", "confirmations", "created_at"],
        BudgetLevel.COMPACT: ["id", "title", "confidence"],
        BudgetLevel.MINIMAL: [],
    },
    "knowledge_list": {
        BudgetLevel.FULL: None,
        BudgetLevel.NORMAL: ["id", "title", "content_preview", "entry_type", "domain", "scope", "created_at"],
        BudgetLevel.COMPACT: ["id", "title", "entry_type"],
        BudgetLevel.MINIMAL: [],
    },
    "knowledge_search": {
        BudgetLevel.FULL: None,
        BudgetLevel.NORMAL: ["id", "title", "content_preview", "entry_type", "domain", "scope", "created_at"],
        BudgetLevel.COMPACT: ["id", "title", "entry_type"],
        BudgetLevel.MINIMAL: [],
    },
    "work_list": {
        BudgetLevel.FULL: None,
        BudgetLevel.NORMAL: ["id", "title", "status", "priority", "domain_tags"],
        BudgetLevel.COMPACT: ["id", "title", "status"],
        BudgetLevel.MINIMAL: [],
    },
    "salesos_search": {
        BudgetLevel.FULL: None,
        BudgetLevel.NORMAL: ["id", "title", "date", "account", "summary_preview"],
        BudgetLevel.COMPACT: ["id", "title", "date"],
        BudgetLevel.MINIMAL: [],
    },
    "salesos_accounts": {
        BudgetLevel.FULL: None,
        BudgetLevel.NORMAL: ["account", "meeting_count", "latest_meeting"],
        BudgetLevel.COMPACT: ["account", "meeting_count"],
        BudgetLevel.MINIMAL: [],
    },
    "salesos_analytics": {
        BudgetLevel.FULL: None,
        BudgetLevel.NORMAL: ["account", "meeting_count", "latest_meeting"],
        BudgetLevel.COMPACT: ["account", "meeting_count"],
        BudgetLevel.MINIMAL: [],
    },
    "docs_list": {
        BudgetLevel.FULL: None,
        BudgetLevel.NORMAL: ["id", "title", "content_preview", "doc_type", "project", "created_at"],
        BudgetLevel.COMPACT: ["id", "title", "doc_type"],
        BudgetLevel.MINIMAL: [],
    },
    "semantic_search": {
        BudgetLevel.FULL: None,
        BudgetLevel.NORMAL: ["source_id", "source_table", "chunk_text", "score"],
        BudgetLevel.COMPACT: ["source_id", "source_table", "score"],
        BudgetLevel.MINIMAL: [],
    },
    "observation_list": {
        BudgetLevel.FULL: None,
        BudgetLevel.NORMAL: ["id", "category", "title", "confidence", "session_id", "trigger", "created_at"],
        BudgetLevel.COMPACT: ["id", "title", "confidence"],
        BudgetLevel.MINIMAL: [],
    },
    "code_search": {
        BudgetLevel.FULL: None,
        BudgetLevel.NORMAL: ["id", "repo", "language", "kind", "name", "qualified_name", "signature"],
        BudgetLevel.COMPACT: ["id", "name", "kind"],
        BudgetLevel.MINIMAL: [],
    },
    "code_outline": {
        BudgetLevel.FULL: None,
        BudgetLevel.NORMAL: ["id", "kind", "name", "qualified_name", "signature"],
        BudgetLevel.COMPACT: ["id", "name", "kind"],
        BudgetLevel.MINIMAL: [],
    },
}

# Hint messages for minimal budget — tells the agent how to get details.
MINIMAL_HINTS: dict[str, str] = {
    "pattern": "Use gm_pattern(action='get', pattern_id=...) for details",
    "knowledge": "Use gm_knowledge(action='get', entry_id=...) for details",
    "work": "Use gm_work(action='get', work_id=...) for details",
    "salesos": "Use gm_salesos(action='meeting', meeting_id=...) for details",
    "docs": "Use gm_docs(action='get', doc_id=...) for details",
    "semantic": "Use gm_semantic with budget='normal' for content",
    "observation": "Use gm_observe(action='get', observation_id=...) for details",
    "code": "Use gm_code(action='get_symbol', symbol_id=...) for full source",
}


class BudgetFormatter:
    """Formats tool responses based on budget level.

    Core modules return full data; this class trims it for the wire.
    Single point of control for all budget-based response formatting.
    """

    @staticmethod
    def format_response(
        results: list[dict[str, Any]],
        budget: BudgetLevel,
        tool_action: str,
        total: int | None = None,
    ) -> dict[str, Any]:
        """Format a list of results according to budget level.

        Args:
            results: Full result dicts from core module.
            budget: Desired verbosity level.
            tool_action: Key into TOOL_FIELDS (e.g., "pattern_list").
            total: Total count if known; otherwise len(results).

        Returns:
            Formatted response dict with metadata.
        """
        actual_total = total if total is not None else len(results)

        if budget == BudgetLevel.MINIMAL:
            tool_domain = tool_action.split("_")[0]
            hint = MINIMAL_HINTS.get(tool_domain, "Use get action with ID for details")
            response = {
                "total": actual_total,
                "budget": budget.value,
                "hint": hint,
            }
            full_size = max(1, len(json.dumps(results, default=str)))
            response_size = max(1, len(json.dumps(response, default=str)))
            response["_savings"] = {
                "tokens_returned": response_size // CHARS_PER_TOKEN,
                "tokens_avoided": full_size // CHARS_PER_TOKEN,
                "reduction_pct": round(max(0.0, (1 - response_size / full_size) * 100), 1) if full_size > 0 else 0.0,
                "method": "budget_format",
            }
            return response

        fields_config = TOOL_FIELDS.get(tool_action, {})
        field_whitelist = fields_config.get(budget)

        if field_whitelist is None:
            formatted = results
        else:
            formatted = [
                {k: v for k, v in item.items() if k in field_whitelist}
                for item in results
            ]

        response = {
            "total": actual_total,
            "returned": len(formatted),
            "budget": budget.value,
            "results": formatted,
        }

        full_size = max(1, len(json.dumps(results, default=str)))
        response_size = max(1, len(json.dumps(response, default=str)))
        response["_savings"] = {
            "tokens_returned": response_size // CHARS_PER_TOKEN,
            "tokens_avoided": full_size // CHARS_PER_TOKEN,
            "reduction_pct": round(max(0.0, (1 - response_size / full_size) * 100), 1) if full_size > 0 else 0.0,
            "method": "budget_format",
        }

        return response

    @staticmethod
    def format_single(
        result: dict[str, Any] | None,
        budget: BudgetLevel,
    ) -> dict[str, Any]:
        """Format a single-item response (get actions).

        Get actions always return full content regardless of budget.
        """
        return result if result is not None else {"error": "Not found"}

    @staticmethod
    def format_status(
        status: dict[str, Any],
        budget: BudgetLevel,
    ) -> dict[str, Any]:
        """Format gm_status response based on budget."""
        if budget == BudgetLevel.MINIMAL:
            return {"status": "ok", "budget": "minimal"}

        if budget == BudgetLevel.COMPACT:
            parts = []
            for section, data in status.items():
                if isinstance(data, dict) and "total" in data:
                    parts.append(f"{section}: {data['total']}")
            return {
                "summary": ", ".join(parts) if parts else "GreyMatter active",
                "budget": "compact",
            }

        return status
