"""GreyMatter Agent Harness — shared enrichment for hooks and skills.

Reads quality standards, patterns, and knowledge from the DB (read-only)
and builds tiered context blocks for agent prompt injection.

Tier 1 (~400 tokens): Critical standards — always injected, placed at END
Tier 2 (~400-600 tokens): Domain-matched patterns + knowledge — placed at TOP
Tier 3 (0 tokens): On-demand via MCP tools — not injected, just referenced

See: docs/plans/2026-03-03-greymatter-harness-design.md
"""

from __future__ import annotations

import sqlite3
from pathlib import Path
from typing import Any

from greymatter_core.db import Database


# Agent types that produce code and need review
CODE_WRITING_AGENTS = frozenset({
    "general-purpose",
    "greymatter:implementer",
    "code-simplifier:code-simplifier",
})

# Domain keyword map for matching patterns/knowledge to prompts
DOMAIN_KEYWORDS: dict[str, list[str]] = {
    "greymatter": ["greymatter", "plugin", "mcp", "hook", "pattern", "knowledge", "harness"],
    "digital-twin": ["twin", "keith", "salesos", "meeting"],
    "neuralpulse": ["neuralpulse", "hardware", "monitor", "swift", "macos"],
    "infrastructure": ["deploy", "docker", "nginx", "cluster", "ssh", "tailscale"],
}


class HarnessEnricher:
    """Enriches agent prompts with GreyMatter quality context.

    Uses the Database protocol for testability — accepts in-memory DBs in tests,
    real DBs in production. All reads go through the Database abstraction.
    """

    def __init__(self, db: Database | None = None, db_path: str | None = None):
        if db is not None:
            self._db = db
        else:
            # Open read-only connection for hooks (avoids MCP server write lock)
            resolved = db_path or str(Path("~/.greymatter/greymatter.db").expanduser())
            conn = sqlite3.connect(f"file:{resolved}?mode=ro", uri=True, timeout=2)
            conn.row_factory = sqlite3.Row
            self._db = _ReadOnlyDB(conn)

    def enrich(
        self,
        agent_prompt: str,
        agent_type: str,
        agent_name: str | None = None,
    ) -> dict[str, Any]:
        """Enrich an agent prompt with tiered GreyMatter context.

        Returns dict with: enriched_prompt, work_item_title, tier1_tokens, tier2_tokens
        """
        # 1. Get critical + important quality standards (Tier 1)
        standards = self._get_standards()

        # 2. Extract domains from prompt text
        domains = self._extract_domains(agent_prompt)

        # 3. Get domain-matched patterns (Tier 2)
        patterns = self._get_patterns(domains)

        # 4. Get domain-matched knowledge (Tier 2)
        knowledge = self._get_knowledge(domains)

        # 5. Build blocks
        tier1_block = self._build_standards_block(standards)
        tier2_block = self._build_patterns_block(patterns, knowledge)

        # 6. Compose: Tier 2 (top) + original + Tier 1 (end)
        parts = []
        if tier2_block:
            parts.append(tier2_block)
        parts.append(agent_prompt)
        if tier1_block:
            parts.append(tier1_block)
        enriched = "\n\n".join(parts)

        # 7. Work item title
        name = agent_name or "unnamed"
        work_item_title = f"Agent: {agent_type}/{name}"

        return {
            "enriched_prompt": enriched,
            "work_item_title": work_item_title,
            "tier1_tokens": _estimate_tokens(tier1_block),
            "tier2_tokens": _estimate_tokens(tier2_block),
        }

    def build_capture_instructions(
        self, work_item_title: str, agent_type: str
    ) -> str:
        """Build PostToolUse instructions for Claude to execute via MCP tools."""
        needs_review = agent_type in CODE_WRITING_AGENTS
        status = "pending_review" if needs_review else "completed"

        lines = [
            f"After this agent completes, execute these GreyMatter tracking calls:",
            f'1. gm_work create: title="{work_item_title}", status="{status}"',
            f"2. gm_observe create: summary of what the agent produced and any issues noted",
        ]
        if needs_review:
            lines.append(
                "3. Review the agent's output before marking the work item approved"
            )
        return "\n".join(lines)

    def _extract_domains(self, prompt: str) -> list[str]:
        """Extract domain keywords from prompt text."""
        prompt_lower = prompt.lower()
        matched = [
            domain
            for domain, keywords in DOMAIN_KEYWORDS.items()
            if any(kw in prompt_lower for kw in keywords)
        ]
        return matched or ["general"]

    def _get_standards(self) -> list[dict]:
        """Get critical + important quality standards."""
        try:
            return self._db.execute(
                "SELECT rule, severity FROM quality_standards "
                "WHERE severity IN ('critical', 'important') AND active = 1 "
                "ORDER BY severity, category"
            )
        except Exception:
            return []

    def _get_patterns(self, domains: list[str], limit: int = 5) -> list[dict]:
        """Get top patterns matching domains, ordered by confidence."""
        if not domains or domains == ["general"]:
            return []
        try:
            placeholders = ",".join("?" for _ in domains)
            return self._db.execute(
                f"SELECT title, observation, confidence FROM patterns "
                f"WHERE domain IN ({placeholders}) "
                f"AND confidence IN ('medium', 'high') "
                f"ORDER BY CASE confidence WHEN 'high' THEN 0 ELSE 1 END, "
                f"applications DESC LIMIT ?",
                (*domains, limit),
            )
        except Exception:
            return []

    def _get_knowledge(self, domains: list[str], limit: int = 3) -> list[dict]:
        """Get knowledge entries matching domains or cross-cutting."""
        if not domains or domains == ["general"]:
            # Still get cross-cutting knowledge
            try:
                return self._db.execute(
                    "SELECT title, content FROM knowledge_entries "
                    "WHERE scope = 'cross-cutting' AND pruned_at IS NULL "
                    "ORDER BY created_at DESC LIMIT ?",
                    (limit,),
                )
            except Exception:
                return []
        try:
            placeholders = ",".join("?" for _ in domains)
            return self._db.execute(
                f"SELECT title, content FROM knowledge_entries "
                f"WHERE (domain IN ({placeholders}) OR scope = 'cross-cutting') "
                f"AND pruned_at IS NULL "
                f"ORDER BY created_at DESC LIMIT ?",
                (*domains, limit),
            )
        except Exception:
            return []

    def _build_standards_block(self, standards: list[dict]) -> str:
        """Build Tier 1 standards block (placed at END for max recall)."""
        if not standards:
            return ""
        lines = ["<greymatter-standards>"]
        for s in standards:
            severity = s.get("severity", "important").upper()
            rule = s.get("rule", "")
            lines.append(f"- [{severity}] {rule}")
        lines.append("")
        lines.append(
            "For additional context: use gm_knowledge, gm_standards, and gm_patterns tools."
        )
        lines.append(
            'When using GreyMatter MCP tools, prefer budget="compact" unless you need full detail.'
        )
        lines.append("</greymatter-standards>")
        return "\n".join(lines)

    def _build_patterns_block(
        self, patterns: list[dict], knowledge: list[dict]
    ) -> str:
        """Build Tier 2 patterns + knowledge block (placed at TOP for reference)."""
        if not patterns and not knowledge:
            return ""
        lines = ["<greymatter-patterns>"]
        for p in patterns:
            title = p.get("title", "")
            obs = p.get("observation", "")[:200]
            conf = p.get("confidence", "low")
            lines.append(f"- {title} (confidence: {conf}): {obs}")
        if knowledge:
            if patterns:
                lines.append("")
            for k in knowledge:
                title = k.get("title", "")
                content = k.get("content", "")[:200]
                lines.append(f"- {title}: {content}")
        lines.append("</greymatter-patterns>")
        return "\n".join(lines)


class _ReadOnlyDB:
    """Minimal Database-like wrapper around a raw sqlite3 read-only connection."""

    def __init__(self, conn: sqlite3.Connection):
        self._conn = conn

    def execute(self, query: str, params: tuple = ()) -> list[dict]:
        cursor = self._conn.execute(query, params)
        columns = [desc[0] for desc in cursor.description] if cursor.description else []
        return [dict(zip(columns, row)) for row in cursor.fetchall()]

    def execute_one(self, query: str, params: tuple = ()) -> dict | None:
        rows = self.execute(query, params)
        return rows[0] if rows else None


def _estimate_tokens(text: str) -> int:
    """Rough token estimate: ~4 chars per token."""
    return len(text) // 4 if text else 0
