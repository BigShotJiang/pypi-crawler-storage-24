"""GreyMatter MCP HTTP Server.

Runs the GreyMatter MCP server over streamable-http transport,
enabling remote access from NemoClaw, NeMo Agent Toolkit, and
other MCP-compatible agents.

Usage:
    python -m greymatter_plugin.http_server [--port 8100] [--host 0.0.0.0]

The server exposes all 17+ GreyMatter MCP tools over HTTP with
streamable-http transport (MCP 2025 standard).
"""
import argparse
import json
import logging
import os
from pathlib import Path

from greymatter_plugin.server import create_app

logger = logging.getLogger("greymatter.http_server")

# A2A Agent Card — advertises GreyMatter capabilities
AGENT_CARD = {
    "name": "GreyMatter",
    "description": "AI orchestration platform with knowledge graph, pattern recognition, work management, semantic search, and security tools.",
    "version": "1.4.0",
    "protocol": "mcp",
    "transport": "streamable-http",
    "capabilities": {
        "tools": True,
        "resources": False,
        "prompts": False,
    },
    "tool_domains": [
        "knowledge_management",
        "pattern_recognition",
        "work_orchestration",
        "semantic_search",
        "code_analysis",
        "security",
        "agent_dispatch",
        "benchmarking",
        "standards",
        "documentation",
    ],
    "authentication": {
        "type": "bearer",
        "required": False,
        "description": "Optional bearer token for access control (set GM_HTTP_TOKEN env var)",
    },
    "contact": {
        "organization": "GreyMatter LLC",
    },
}


def main():
    parser = argparse.ArgumentParser(description="GreyMatter MCP HTTP Server")
    parser.add_argument("--port", type=int, default=int(os.getenv("GM_HTTP_PORT", "8100")))
    parser.add_argument("--host", default=os.getenv("GM_HTTP_HOST", "0.0.0.0"))
    args = parser.parse_args()

    logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(name)s] %(levelname)s: %(message)s")

    app = create_app()

    # Write agent card for A2A discovery
    card_dir = Path.home() / ".greymatter"
    card_dir.mkdir(exist_ok=True)
    card_path = card_dir / "agent-card.json"
    card = {**AGENT_CARD, "endpoint": f"http://{args.host}:{args.port}/mcp"}
    card_path.write_text(json.dumps(card, indent=2))
    logger.info("A2A agent card written to %s", card_path)

    logger.info("Starting GreyMatter MCP HTTP server on %s:%d", args.host, args.port)
    logger.info("MCP endpoint: http://%s:%d/mcp", args.host, args.port)
    logger.info("Transport: streamable-http")

    app.run(
        transport="streamable-http",
        host=args.host,
        port=args.port,
    )


if __name__ == "__main__":
    main()
