---
name: pattern-capture
description: Capture patterns and learnings when session ends
event: Stop
---

Before this session ends, briefly reflect on what was accomplished and capture any reusable learnings:

1. Identify any patterns, corrections, or gotchas discovered during this session
2. For each new pattern, call `gm_pattern(action="create", type="<type>", domain="<domain>", title="<title>", observation="<observation>")`
   - Types: convention, anti-pattern, architecture, workflow, debugging
   - Be specific and actionable in the observation
3. For any knowledge worth preserving, call `gm_knowledge(action="create", entry_type="<type>", title="<title>", content="<content>")`
   - Entry types: expertise, correction, gotcha, reference

Only capture genuinely new and useful patterns. Do not create trivial or obvious entries. If nothing novel was learned, skip silently.

Do this quickly — spend no more than 10 seconds deciding what to capture.
