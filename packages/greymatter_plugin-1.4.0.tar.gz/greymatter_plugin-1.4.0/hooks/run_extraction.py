#!/Users/keithcotterman/Development/greymatter/.venv/bin/python
"""Async extraction runner — called by UserPromptSubmit hook.

Receives session_id and conversation text, runs LLM extraction,
stores observations via cognitive bridge.

Usage: python run_extraction.py <session_id> <text>
       python run_extraction.py <session_id> --file <path>
"""
import os
import sys

GREYMATTER_ROOT = os.path.join(os.path.dirname(__file__), "..", "..", "core", "src")
COGNITIVE_ROOT = os.path.join(os.path.dirname(__file__), "..", "..", "cognitive", "src")
sys.path.insert(0, os.path.abspath(GREYMATTER_ROOT))
sys.path.insert(0, os.path.abspath(COGNITIVE_ROOT))


def run_extraction(session_id: str, text: str) -> int:
    """Run LLM extraction on text and store observations.

    Returns number of observations created.
    """
    if not text or len(text.strip()) < 50:
        return 0

    from greymatter_core.extraction import ExtractionPipeline
    from greymatter_core.llm_gateway import OllamaLLM
    from greymatter_core.cognitive_bridge import get_memory

    # Try LLM extraction with fallback
    llm = OllamaLLM()
    observations = ExtractionPipeline.extract(
        text,
        session_id=session_id,
        trigger="llm_extraction",
        llm=llm if llm.is_available() else None,
    )

    if not observations:
        return 0

    memory = get_memory()
    created = 0

    for obs in observations:
        try:
            domains = obs.get("domains", "")
            domain_list = [d.strip() for d in domains.split(",") if d.strip()] if domains else None

            memory.observe(
                content=obs.get("content", ""),
                category=obs.get("category", "insight"),
                title=obs.get("title", "Untitled"),
                domains=domain_list,
                confidence=obs.get("confidence", 0.4),
                session_id=session_id,
                source="llm_extraction",
            )
            created += 1
        except Exception:
            continue

    return created


def main():
    if len(sys.argv) < 3:
        sys.exit(1)

    session_id = sys.argv[1]

    # Support --file <path> for large texts
    if sys.argv[2] == "--file" and len(sys.argv) > 3:
        filepath = sys.argv[3]
        try:
            with open(filepath) as f:
                text = f.read()
            os.unlink(filepath)  # Clean up temp file
        except Exception:
            sys.exit(1)
    else:
        text = sys.argv[2]

    count = run_extraction(session_id, text)

    # Log result
    try:
        sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "..", "lib"))
        from injection_log import log_injection
        log_injection(
            hook="llm_extraction",
            mode="async",
            tokens_injected=0,
            tokens_available=0,
            entries_included=count,
        )
    except Exception:
        pass


if __name__ == "__main__":
    main()
