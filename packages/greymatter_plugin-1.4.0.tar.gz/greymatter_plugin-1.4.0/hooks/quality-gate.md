---
name: quality-gate
description: Check quality standards before git commits
event: PreToolUse
tool: Bash
---

Before executing this Bash command, check if it contains `git commit`.

If it does NOT contain `git commit`, allow it to proceed without any action.

If it DOES contain `git commit`:

1. Call `gm_standards(action="payload")` to get active quality standards
2. Review the staged changes (the diff that will be committed) against the standards
3. If any critical or high-severity violations are found:
   - List the violations with their standard references
   - Suggest specific fixes
   - Ask the user whether to proceed or fix first
4. If no violations found, allow the commit to proceed

Keep the review focused and fast. Only flag clear violations, not style preferences.
