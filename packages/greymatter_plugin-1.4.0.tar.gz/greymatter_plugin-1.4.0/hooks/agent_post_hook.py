#!/Users/keithcotterman/Development/greymatter/.venv/bin/python
"""PostToolUse hook: output tracking instructions after Agent tool completes.

Instructs Claude to create work items and observations via MCP tools.
Falls through gracefully on any error.

Input (stdin JSON): {"toolName": "Agent", "toolInput": {...}, "toolResult": "..."}
Output (stdout JSON): {} (with optional stderr message for Claude)
"""

import json
import os
import sys

# Add greymatter core + plugin to path
GREYMATTER_ROOT = os.path.join(os.path.dirname(__file__), "..", "..", "core", "src")
PLUGIN_ROOT = os.path.join(os.path.dirname(__file__), "..", "src")
sys.path.insert(0, os.path.abspath(GREYMATTER_ROOT))
sys.path.insert(0, os.path.abspath(PLUGIN_ROOT))


def main() -> None:
    try:
        input_data = json.load(sys.stdin)
    except (json.JSONDecodeError, EOFError):
        print("{}")
        sys.exit(0)

    try:
        tool_input = input_data.get("toolInput", {})
        agent_type = tool_input.get("subagent_type", "general-purpose")
        agent_name = tool_input.get("name", "")

        from greymatter_plugin.harness import HarnessEnricher

        enricher = HarnessEnricher()
        name = agent_name or "unnamed"
        work_item_title = f"Agent: {agent_type}/{name}"
        instructions = enricher.build_capture_instructions(work_item_title, agent_type)

        # Output instructions via stderr so Claude sees them
        sys.stderr.write(f"[GreyMatter Harness] {instructions}\n")
        print("{}")

    except Exception as e:
        sys.stderr.write(f"[GreyMatter Harness] PostToolUse skipped: {e}\n")
        print("{}")

    sys.exit(0)


if __name__ == "__main__":
    main()
