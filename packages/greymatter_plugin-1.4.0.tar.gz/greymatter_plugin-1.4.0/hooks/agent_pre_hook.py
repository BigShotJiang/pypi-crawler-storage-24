#!/Users/keithcotterman/Development/greymatter/.venv/bin/python
"""PreToolUse hook: enrich Agent tool prompts with GreyMatter quality context.

Reads DB in read-only mode. Modifies the agent prompt via updatedInput.
Falls through gracefully on any error — never blocks agent dispatch.

Input (stdin JSON): {"toolName": "Agent", "toolInput": {"prompt": "...", "subagent_type": "...", ...}}
Output (stdout JSON): {"decision": "approve", "updatedInput": {...}} or {"decision": "approve"}
"""

import json
import os
import sys

# Add greymatter core + plugin to path
GREYMATTER_ROOT = os.path.join(os.path.dirname(__file__), "..", "..", "core", "src")
PLUGIN_ROOT = os.path.join(os.path.dirname(__file__), "..", "src")
sys.path.insert(0, os.path.abspath(GREYMATTER_ROOT))
sys.path.insert(0, os.path.abspath(PLUGIN_ROOT))


def main() -> None:
    try:
        input_data = json.load(sys.stdin)
    except (json.JSONDecodeError, EOFError):
        print(json.dumps({"decision": "approve"}))
        sys.exit(0)

    try:
        tool_input = input_data.get("toolInput", {})
        agent_prompt = tool_input.get("prompt", "")
        agent_type = tool_input.get("subagent_type", "general-purpose")
        agent_name = tool_input.get("name", "")

        if not agent_prompt:
            print(json.dumps({"decision": "approve"}))
            sys.exit(0)

        from greymatter_plugin.harness import HarnessEnricher

        enricher = HarnessEnricher()
        result = enricher.enrich(agent_prompt, agent_type, agent_name)

        # Build updated tool input with enriched prompt
        updated_input = dict(tool_input)
        updated_input["prompt"] = result["enriched_prompt"]

        output = {
            "decision": "approve",
            "updatedInput": updated_input,
        }
        print(json.dumps(output))

    except Exception as e:
        # Graceful degradation: approve without enrichment
        sys.stderr.write(f"[GreyMatter Harness] PreToolUse skipped: {e}\n")
        print(json.dumps({"decision": "approve"}))

    sys.exit(0)


if __name__ == "__main__":
    main()
