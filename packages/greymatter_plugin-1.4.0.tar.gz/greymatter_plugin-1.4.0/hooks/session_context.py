#!/Users/keithcotterman/Development/greymatter/.venv/bin/python
"""SessionStart hook: Auto-load GreyMatter context at session start.

Queries the GreyMatter SQLite database directly and injects quality standards,
active patterns, system status, and checkpoint recovery info into the session context.

Context is capped at ~400 tokens (~1600 chars) to avoid exhausting the
coordinator's context window. When the cap is exceeded, parts are
progressively dropped starting from the least essential (consolidation,
full observations, full patterns) while keeping session ID, data counts,
and a truncation notice.
"""

import json
import os
import sys

# Add greymatter core to path
GREYMATTER_ROOT = os.path.join(os.path.dirname(__file__), "..", "..", "core", "src")
sys.path.insert(0, os.path.abspath(GREYMATTER_ROOT))

# Add cognitive src to path
COGNITIVE_ROOT = os.path.join(os.path.dirname(__file__), "..", "..", "cognitive", "src")
sys.path.insert(0, os.path.abspath(COGNITIVE_ROOT))

# Default cap: ~400 tokens = ~1600 chars
DEFAULT_MAX_CHARS = 1600


def build_context_parts(db) -> list[str]:
    """Build the list of context parts from the database.

    Each part is a string representing one section of context (session info,
    standards count, pattern list, data counts, observations, checkpoint, etc.).

    Args:
        db: A greymatter_core.db.Database instance.

    Returns:
        List of context part strings, ordered by priority (most essential first).
    """
    from greymatter_core.context import ContextEngine
    from greymatter_core.documents import DocumentStore
    from greymatter_core.standards import StandardsManager
    from greymatter_core.patterns import PatternManager
    from greymatter_core.sessions import SessionManager
    from greymatter_core.cognitive_bridge import get_memory

    sessions = SessionManager(db)
    ctx = ContextEngine(
        db=db,
        doc_store=DocumentStore(db),
        standards=StandardsManager(db),
        patterns=PatternManager(db),
    )

    # 1. Start or resume a GreyMatter session
    current = sessions.get_current()
    if not current:
        current = sessions.start()

    session_id = current["id"]

    # 2. Load latest checkpoint if one exists (context recovery after compaction)
    checkpoint = sessions.get_latest_checkpoint(session_id)

    # 3. Build context payload
    payload = ctx.build_session_context(max_tokens=2000)

    # Parts are ordered by priority: essential info first, nice-to-have last.
    # cap_context() will drop from the end when the cap is exceeded.
    parts = []

    # --- Priority 1: Session identity (always kept) ---
    parts.append(f"Session: {session_id}")
    compaction_count = current.get("compaction_count", 0)
    if compaction_count:
        parts.append(f"Compactions: {compaction_count}")

    # --- Priority 2: Data counts (compact, high value) ---
    tables = ["patterns", "knowledge", "meetings", "accounts", "documents"]
    counts = {}
    for table in tables:
        try:
            row = db.execute_one(f"SELECT COUNT(*) as c FROM {table}")
            if row:
                counts[table] = row["c"]
        except Exception:
            pass

    # Add observations count
    try:
        obs_row = db.execute_one(
            "SELECT COUNT(*) as c FROM observations WHERE pruned = 0"
        )
        if obs_row and obs_row["c"] > 0:
            counts["observations"] = obs_row["c"]
    except Exception:
        pass

    if counts:
        count_str = ", ".join(f"{k}: {v}" for k, v in counts.items() if v > 0)
        parts.append(f"Data: {count_str}")

    # --- Priority 3: Quality standards count ---
    standards = payload.get("quality_standards")
    if standards:
        if isinstance(standards, str):
            try:
                std_list = json.loads(standards)
            except (json.JSONDecodeError, TypeError):
                std_list = []
        elif isinstance(standards, list):
            std_list = standards
        elif isinstance(standards, dict):
            std_list = standards.get("standards", [])
        else:
            std_list = []
        if std_list:
            parts.append(f"Quality standards: {len(std_list)} active")

    # --- Priority 4: Active patterns (top 5 titles only) ---
    patterns = payload.get("active_patterns", [])
    if patterns:
        pattern_lines = []
        for p in patterns[:5]:
            title = p.get("title", "untitled")
            conf = p.get("confidence", "unknown")
            pattern_lines.append(f"  - {title} ({conf})")
        parts.append("Active patterns:\n" + "\n".join(pattern_lines))

    # --- Priority 5: Recent docs count ---
    docs = payload.get("recent_context", [])
    if docs:
        parts.append(f"Recent documents: {len(docs)} available")

    # --- Priority 6: Checkpoint recovery (important after compaction) ---
    if checkpoint:
        parts.append("--- Checkpoint Recovery ---")
        cp_summary = checkpoint.get("context_summary", "")
        if cp_summary:
            parts.append(f"Last context: {cp_summary[:200]}")
        cp_items = checkpoint.get("open_items", "")
        if cp_items:
            parts.append(f"Open items: {cp_items[:200]}")
        cp_at = checkpoint.get("checkpoint_at", "")
        if cp_at:
            parts.append(f"Checkpoint at: {cp_at}")

    # --- Priority 7: Recent observations via cognitive MemorySystem ---
    memory = None
    try:
        memory = get_memory()
        recent_obs = memory.retrieve(context="session_start", budget=2000)
        if recent_obs:
            obs_lines = []
            for o in recent_obs[:5]:
                obs_lines.append(
                    f"  - [{o['category']}] {o['title']} (conf: {o['confidence']:.1f})"
                )
            parts.append("Recent observations:\n" + "\n".join(obs_lines))
    except Exception:
        pass

    # --- Priority 8: Run memory maintenance via cognitive MemorySystem ---
    try:
        if memory is None:
            memory = get_memory()
        memory.maintain()
    except Exception:
        pass

    # --- Priority 9: Cross-session consolidation via cognitive MemorySystem ---
    try:
        if memory is None:
            memory = get_memory()
        consolidation = memory.consolidate()
        if consolidation["promoted"] > 0:
            parts.append(
                f"Cross-session consolidation: {consolidation['promoted']} promoted, "
                f"{consolidation['clusters_found']} clusters found"
            )
    except Exception:
        pass

    return parts


def cap_context(parts: list[str], max_chars: int = DEFAULT_MAX_CHARS) -> str:
    """Cap context output to a maximum character count.

    Strategy: Include parts in priority order (first = highest priority).
    When the next part would exceed the cap, stop and append a truncation notice.

    This ensures the most essential information (session ID, data counts)
    always survives, while verbose sections (observations, consolidation)
    are dropped first since they are at the end of the list.

    Args:
        parts: List of context part strings, ordered by priority.
        max_chars: Maximum character count for the output.

    Returns:
        The capped context string.
    """
    if not parts:
        return ""

    # Reserve space for the truncation notice
    truncation_notice = " [truncated — use gm_context() for full details]"
    reserve = len(truncation_notice) + 1  # +1 for newline

    included = []
    current_len = 0
    truncated = False

    for part in parts:
        # Account for the newline separator between parts
        separator_len = 1 if included else 0
        part_len = len(part) + separator_len

        if current_len + part_len <= max_chars - reserve:
            included.append(part)
            current_len += part_len
        else:
            truncated = True
            break

    result = "\n".join(included)
    if truncated:
        result += "\n" + truncation_notice

    return result


def main() -> None:
    try:
        input_data = json.load(sys.stdin)
    except (json.JSONDecodeError, EOFError):
        print("{}")
        sys.exit(0)

    try:
        from greymatter_core.db import SQLiteDatabase
        from greymatter_core.config import Config

        config = Config()
        db = SQLiteDatabase(config.db_path)

        parts = build_context_parts(db)

        if not parts:
            print("{}")
            sys.exit(0)

        capped = cap_context(parts, max_chars=DEFAULT_MAX_CHARS)
        additional_context = "GreyMatter context loaded:\n" + capped

        output = {
            "hookSpecificOutput": {
                "hookEventName": "SessionStart",
                "additionalContext": additional_context,
            }
        }

        print(json.dumps(output))

    except Exception:
        # Fail silently — don't block session start
        print("{}")

    sys.exit(0)


if __name__ == "__main__":
    main()
