---
name: session-context
description: Auto-load GreyMatter context at session start
event: SessionStart
---

At the start of this session, silently load GreyMatter context:

1. Call `gm_context()` to get the session payload (quality standards, recent documents, active patterns)
2. Call `gm_status()` to get system overview counts

Absorb this context silently. Do NOT print it to the user unless they ask. Use it to inform your responses throughout the session.

If GreyMatter MCP server is not available, skip silently — do not error or warn the user.
