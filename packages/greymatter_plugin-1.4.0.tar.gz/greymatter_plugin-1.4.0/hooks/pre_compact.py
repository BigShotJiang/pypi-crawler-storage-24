#!/Users/keithcotterman/Development/greymatter/.venv/bin/python
"""PreCompact hook: consolidation cycle before context compaction.

Implements "compaction as consolidation" — the AI equivalent of memory
consolidation during sleep (Stickgold & Walker, 2013):

1. CHECKPOINT: Save sparse session state (work items, compaction count)
2. EXTRACT: Run ExtractionPipeline on conversation text to create observations
3. CONSOLIDATE: Decay cycle (FSRS-6), interference, cross-session promotion
4. STATE CAPTURE: Save structured conversation state for recovery

The hook's stdout is injected into the compacted context, so we output
metamemory signals ("you knew about X, Y, Z") to help post-compaction recovery.
"""
import json
import os
import sys
import time

# Add greymatter core + lib to path
GREYMATTER_ROOT = os.path.join(os.path.dirname(__file__), "..", "..", "core", "src")
GREYMATTER_LIB = os.path.join(os.path.dirname(__file__), "..", "..", "lib")
COGNITIVE_ROOT = os.path.join(os.path.dirname(__file__), "..", "..", "cognitive", "src")
sys.path.insert(0, os.path.abspath(GREYMATTER_ROOT))
sys.path.insert(0, os.path.abspath(GREYMATTER_LIB))
sys.path.insert(0, os.path.abspath(COGNITIVE_ROOT))

MAX_CHECKPOINT_WORK_ITEMS = 10
MAX_CONVERSATION_CHARS = 50000  # Cap extraction input


def read_conversation_from_stdin() -> str:
    """Read conversation context from stdin (Claude Code sends JSON).

    Returns plain text representation of conversation messages.
    """
    try:
        if sys.stdin.isatty():
            return ""
        raw = sys.stdin.read()
        if not raw.strip():
            return ""
        data = json.loads(raw)
        # Claude Code PreCompact payload has conversation_history or messages
        messages = data.get("conversation_history", data.get("messages", []))
        if not messages:
            return raw[:MAX_CONVERSATION_CHARS]
        parts = []
        for msg in messages:
            role = msg.get("role", "unknown")
            content = msg.get("content", "")
            if isinstance(content, list):
                # Handle content blocks
                text_parts = [
                    block.get("text", "")
                    for block in content
                    if isinstance(block, dict) and block.get("type") == "text"
                ]
                content = "\n".join(text_parts)
            if content:
                parts.append(f"{role}: {content}")
        text = "\n\n".join(parts)
        return text[:MAX_CONVERSATION_CHARS]
    except Exception:
        return ""


def build_sparse_checkpoint(db) -> dict:
    """Build a sparse checkpoint from current session state."""
    from greymatter_core.sessions import SessionManager
    from greymatter_core.work_items import WorkItemManager

    sessions = SessionManager(db)
    work_items = WorkItemManager(db)

    current = sessions.get_current()
    if not current:
        current = sessions.start()

    open_items = work_items.list(status="in_progress")
    sparse_items = [
        {"id": w["id"], "title": w["title"][:80]}
        for w in open_items[:MAX_CHECKPOINT_WORK_ITEMS]
    ]
    open_items_json = json.dumps(sparse_items)
    if len(open_items_json) > 500:
        sparse_items = [{"id": w["id"]} for w in open_items[:MAX_CHECKPOINT_WORK_ITEMS]]
        open_items_json = json.dumps(sparse_items)

    count = sessions.increment_compaction(current["id"])

    cp = sessions.checkpoint(
        current["id"],
        context_summary=f"Auto-checkpoint before compaction #{count}",
        open_items=open_items_json,
    )

    return {
        "session_id": current["id"],
        "checkpoint": cp,
        "compaction_number": count,
        "open_work_items": len(open_items),
    }


def extract_observations(db, session_id: str, conversation_text: str) -> list:
    """Extract observations from conversation using LLM with heuristic fallback."""
    from greymatter_core.extraction import ExtractionPipeline
    from greymatter_core.llm_gateway import OllamaLLM
    from greymatter_core.cognitive_bridge import get_memory

    if not conversation_text or len(conversation_text) < 50:
        return []

    memory = get_memory()

    # Always try LLM — extract_llm falls back to heuristic on failure
    llm = OllamaLLM()
    raw_observations = ExtractionPipeline.extract(
        conversation_text,
        session_id=session_id,
        trigger="pre_compact",
        llm=llm,
    )

    created = []
    for raw in raw_observations:
        try:
            domains = raw.get("domains", "")
            domain_list = [d.strip() for d in domains.split(",") if d.strip()] if domains else None

            obs = memory.observe(
                content=raw.get("content", ""),
                category=raw.get("category", "insight"),
                title=raw.get("title", "Untitled"),
                domains=domain_list,
                confidence=raw.get("confidence", 0.4),
                session_id=raw.get("session_id", session_id),
                source="pre_compact",
            )
            created.append(obs)
        except Exception:
            continue

    return created


def run_consolidation(db) -> dict:
    """Run the consolidation cycle: decay + cross-session analysis."""
    from greymatter_core.cognitive_bridge import get_memory

    memory = get_memory()

    results = {"decay": {}, "consolidation": {}}

    # 1. Decay cycle (FSRS-6 power-law)
    try:
        decay_stats = memory.maintain()
        results["decay"] = decay_stats
    except Exception:
        results["decay"] = {"error": "decay_failed"}

    # 2. Cross-session consolidation (cluster + promote)
    try:
        consol_stats = memory.consolidate()
        results["consolidation"] = consol_stats
    except Exception:
        results["consolidation"] = {"error": "consolidation_failed"}

    return results


def capture_conversation_state(conversation_text: str) -> dict:
    """Extract structured state from conversation for recovery.

    Captures: current task, progress, key files, pending decisions.
    Uses simple heuristics (fast, no LLM needed).
    """
    if not conversation_text:
        return {}

    state = {}

    lines = conversation_text.split("\n")
    last_lines = lines[-50:] if len(lines) > 50 else lines
    last_text = "\n".join(last_lines)

    # Extract file paths mentioned (common in coding sessions)
    import re
    file_refs = set()
    for match in re.finditer(r'[\w/.-]+\.\w{1,10}', last_text):
        path = match.group()
        if "/" in path and not path.startswith("http"):
            file_refs.add(path)
    if file_refs:
        state["recent_files"] = sorted(file_refs)[:20]

    # Look for task/goal indicators in recent text
    for pattern in [
        r"(?i)(?:working on|implementing|building|fixing)\s+(.{10,100})",
        r"(?i)(?:task|goal|objective):\s*(.{10,100})",
    ]:
        m = re.search(pattern, last_text)
        if m:
            state["current_task"] = m.group(1).strip()[:200]
            break

    # Look for "next steps" or "remaining" indicators
    for pattern in [
        r"(?i)(?:next|remaining|todo|still need).*?:\s*(.{10,200})",
        r"(?i)(?:then we|after that|next we).*?(.{10,200})",
    ]:
        m = re.search(pattern, last_text)
        if m:
            state["next_steps"] = m.group(1).strip()[:200]
            break

    return state


def build_metamemory_signals(observations: list, consolidation: dict) -> str:
    """Build metamemory output for post-compaction context.

    These signals tell Claude "you knew about X, Y, Z" after compaction,
    helping it reconstruct working context.
    """
    parts = []

    if observations:
        categories = {}
        for obs in observations:
            cat = obs.get("category", "unknown")
            categories[cat] = categories.get(cat, 0) + 1
        cat_summary = ", ".join(f"{v} {k}s" for k, v in sorted(categories.items()))
        parts.append(f"Extracted {len(observations)} observations ({cat_summary}) before compaction.")

    promoted = consolidation.get("consolidation", {}).get("promoted", 0)
    if promoted:
        parts.append(f"Promoted {promoted} recurring observations to permanent memory.")

    decayed = consolidation.get("decay", {}).get("decayed", 0)
    pruned = consolidation.get("decay", {}).get("pruned", 0)
    if decayed or pruned:
        parts.append(f"Memory maintenance: {decayed} decayed, {pruned} pruned.")

    return " ".join(parts) if parts else ""


def main() -> None:
    start_time = time.time()

    try:
        from greymatter_core.config import Config
        from greymatter_core.db import SQLiteDatabase

        config = Config()
        db = SQLiteDatabase(config.db_path)

        # Read conversation from stdin
        conversation_text = read_conversation_from_stdin()

        # 1. Sparse checkpoint (always runs)
        checkpoint_result = build_sparse_checkpoint(db)
        session_id = checkpoint_result.get("session_id", "")

        # 2. Extract observations from conversation
        observations = []
        if conversation_text:
            observations = extract_observations(db, session_id, conversation_text)

        # 3. Run consolidation cycle
        consolidation_result = run_consolidation(db)

        # 4. Capture conversation state
        conv_state = capture_conversation_state(conversation_text)

        # 5. Build and save recovery artifact
        recovery_artifact = ""
        try:
            from recovery import (
                build_recovery_artifact,
                save_recovery_artifact,
            )
            recovery_artifact = build_recovery_artifact(
                session_id=session_id,
                compaction_number=checkpoint_result.get("compaction_number", 1),
                conversation_state=conv_state,
                observations=[o for o in observations if isinstance(o, dict)],
                consolidation_result=consolidation_result,
                db=db,
            )
            save_recovery_artifact(
                session_id=session_id,
                compaction_number=checkpoint_result.get("compaction_number", 1),
                artifact=recovery_artifact,
            )
        except Exception:
            pass  # Recovery is best-effort

        # 6. Build metamemory output
        metamemory = build_metamemory_signals(observations, consolidation_result)

        elapsed = round(time.time() - start_time, 2)

        # Build full result
        result = {
            **checkpoint_result,
            "observations_extracted": len(observations),
            "consolidation": consolidation_result,
            "conversation_state": conv_state,
            "recovery_artifact_built": bool(recovery_artifact),
            "elapsed_seconds": elapsed,
        }

        # Log injection data
        try:
            from injection_log import log_injection
            log_injection(
                hook="pre_compact",
                mode="recovery",
                tokens_injected=len(json.dumps(result)) // 4,
                tokens_available=16000,
                entries_included=len(observations),
            )
        except Exception:
            pass

        # Output: metamemory signals + JSON
        output_parts = []
        if metamemory:
            output_parts.append(metamemory)
        output_parts.append(json.dumps(result))
        print("\n".join(output_parts))

    except Exception:
        print("{}")

    sys.exit(0)


if __name__ == "__main__":
    main()
