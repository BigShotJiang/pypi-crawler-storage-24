#!/Users/keithcotterman/Development/greymatter/.venv/bin/python
"""PostToolUse hook: evaluate tool results for observational memory.

Monitors MCP tool calls and queues observation-worthy results
for batch extraction at the next token threshold.
"""

import json
import os
import sys

# Add greymatter core and cognitive to path
GREYMATTER_ROOT = os.path.join(os.path.dirname(__file__), "..", "..", "core", "src")
sys.path.insert(0, os.path.abspath(GREYMATTER_ROOT))
COGNITIVE_ROOT = os.path.join(os.path.dirname(__file__), "..", "..", "cognitive", "src")
sys.path.insert(0, os.path.abspath(COGNITIVE_ROOT))


# Tools that are never observation-worthy
SKIP_TOOLS = {"gm_status", "gm_context", "gm_standards", "gm_benchmark", "gm_checkpoint"}

# Tools whose create/mutation actions should be captured
MUTATION_ACTIONS = {"create", "confirm"}


def main() -> None:
    try:
        input_data = json.load(sys.stdin)
    except (json.JSONDecodeError, EOFError):
        print("{}")
        sys.exit(0)

    try:
        tool_name = input_data.get("toolName", "")
        tool_input = input_data.get("toolInput", {})
        tool_result = input_data.get("toolResult", "")

        # Skip non-observation-worthy tools
        if tool_name in SKIP_TOOLS:
            print("{}")
            sys.exit(0)

        # Only capture mutations and errors
        action = ""
        if isinstance(tool_input, dict):
            action = tool_input.get("action", "")

        is_mutation = action in MUTATION_ACTIONS
        is_error = False
        if isinstance(tool_result, str):
            try:
                parsed = json.loads(tool_result)
                is_error = "error" in parsed
            except (json.JSONDecodeError, TypeError):
                pass

        if not is_mutation and not is_error:
            print("{}")
            sys.exit(0)

        # Record the tool event for batch extraction
        from greymatter_core.config import Config
        from greymatter_core.db import SQLiteDatabase
        from greymatter_core.sessions import SessionManager
        from greymatter_core.cognitive_bridge import get_memory

        config = Config()
        db = SQLiteDatabase(config.db_path)
        sessions = SessionManager(db)
        memory = get_memory()

        current = sessions.get_current()
        if not current:
            print("{}")
            sys.exit(0)

        session_id = current["id"]

        # For mutations, create an observation from the tool result
        if is_mutation and isinstance(tool_result, str):
            content = f"Tool {tool_name} action={action}: {tool_result[:500]}"
            title = f"[tool] {tool_name} {action}"

            # Check for duplicate
            existing = memory.db.execute_one(
                "SELECT id FROM observations WHERE title = ? AND pruned = 0", (title,)
            )
            if not existing:
                memory.observe(
                    content=content,
                    category="insight",
                    title=title,
                    session_id=session_id,
                    source="post_tool_use",
                    confidence=0.3,
                )

        # For errors, capture the error pattern
        if is_error and isinstance(tool_result, str):
            memory.observe(
                content=tool_result[:500],
                category="correction",
                title=f"[error] {tool_name} {action} failed",
                session_id=session_id,
                source="post_tool_use",
                confidence=0.4,
            )

        print("{}")

    except Exception:
        # Fail silently — don't block tool execution
        print("{}")

    sys.exit(0)


if __name__ == "__main__":
    main()
