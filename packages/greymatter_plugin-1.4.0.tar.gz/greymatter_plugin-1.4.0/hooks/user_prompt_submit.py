#!/Users/keithcotterman/Development/greymatter/.venv/bin/python
"""UserPromptSubmit hook: spreading activation retrieval engine.

Fires on every user message. Implements the Budget Cascade:
1. Post-compaction recovery: inject full recovery artifact (one-shot)
2. Momentum analysis: detect topic shifts
3. Tiered retrieval:
   - Tier 0 (stable): keyword lookup from priming cache (<10ms)
   - Tier 1 (partial shift): SQLite query via KnowledgeContextBuilder (<50ms)
   - Tier 2 (full shift): full retrieval + priming file refresh (<200ms)
4. Format + inject context via stdout
"""
import json
import os
import re
import subprocess
import sys
import time

# Add greymatter core + lib to path
GREYMATTER_ROOT = os.path.join(os.path.dirname(__file__), "..", "..", "core", "src")
GREYMATTER_LIB = os.path.join(os.path.dirname(__file__), "..", "..", "lib")
sys.path.insert(0, os.path.abspath(GREYMATTER_ROOT))
sys.path.insert(0, os.path.abspath(GREYMATTER_LIB))

# Budget for retrieval injection (tokens)
MAX_RETRIEVAL_TOKENS = 2000


def get_current_session_id(db) -> str:
    """Get the current session ID, or empty string if none."""
    from greymatter_core.sessions import SessionManager
    sessions = SessionManager(db)
    current = sessions.get_current()
    return current["id"] if current else ""


def read_user_message() -> str:
    """Read the user's message from stdin."""
    try:
        if sys.stdin.isatty():
            return ""
        raw = sys.stdin.read()
        if not raw.strip():
            return ""
        data = json.loads(raw)
        # UserPromptSubmit receives the user's message
        return data.get("message", data.get("content", data.get("prompt", raw)))
    except (json.JSONDecodeError, Exception):
        return ""


def check_and_inject_recovery(session_id: str) -> str:
    """Check for recovery artifact and return it if found."""
    if not session_id:
        return ""
    from recovery import get_latest_recovery_artifact, consume_recovery_artifact

    artifact = get_latest_recovery_artifact(session_id)
    if not artifact:
        return ""
    consume_recovery_artifact(session_id)
    return artifact


def tier0_lookup(keywords: list) -> list:
    """Tier 0: keyword lookup from priming cache (<10ms)."""
    from priming import lookup_by_keywords
    return lookup_by_keywords(keywords, max_results=3)


def tier1_retrieval(keywords: list, db) -> list:
    """Tier 1: SQLite query via knowledge store (<50ms)."""
    try:
        from greymatter_core.knowledge import KnowledgeStore
        store = KnowledgeStore(db)
        results = []
        for kw in keywords[:5]:
            entries = store.search(query=kw, limit=3)
            for e in entries:
                if e["id"] not in {r["id"] for r in results}:
                    results.append(e)
                if len(results) >= 5:
                    break
            if len(results) >= 5:
                break
        return results
    except Exception:
        return []


def tier2_retrieval(keywords: list, session_id: str, db) -> list:
    """Tier 2: full KnowledgeContextBuilder retrieval + priming refresh (<200ms)."""
    try:
        from greymatter_core.knowledge import KnowledgeStore
        store = KnowledgeStore(db)

        # Full search across all keywords
        results = []
        seen_ids = set()
        for kw in keywords[:10]:
            entries = store.search(query=kw, limit=5)
            for e in entries:
                if e["id"] not in seen_ids:
                    results.append(e)
                    seen_ids.add(e["id"])

        # Refresh priming file with new results
        try:
            from priming import refresh_priming_file
            refresh_priming_file(results)
        except Exception:
            pass

        return results[:10]
    except Exception:
        return []


def format_retrieval_context(entries: list, tier: int) -> str:
    """Format retrieved entries for context injection.

    Uses plain text format (not JSON) to avoid false prompt injection detection.
    """
    if not entries:
        return ""

    lines = []
    tokens_used = 0

    for entry in entries:
        title = entry.get("title", "Untitled")
        content = entry.get("content", entry.get("preview", ""))
        entry_type = entry.get("type", entry.get("entry_type", ""))
        confidence = entry.get("confidence", "")

        # Format based on type
        if entry_type == "correction":
            prefix = "[Correction]"
        elif entry_type in ("gotcha", "warning"):
            prefix = "[Warning]"
        elif entry_type == "pattern":
            prefix = "[Pattern]"
        else:
            prefix = "[Reference]"

        # Truncate content
        preview = content[:150] if content else ""
        if len(content) > 150:
            preview += "..."

        line = f"- {prefix} {title}"
        if preview and preview != title:
            line += f": {preview}"
        if confidence:
            line += f" (confidence: {confidence})"

        est_tokens = len(line) // 4
        if tokens_used + est_tokens > MAX_RETRIEVAL_TOKENS:
            break

        lines.append(line)
        tokens_used += est_tokens

    if not lines:
        return ""

    return "Relevant from your memory:\n" + "\n".join(lines)


# --- Extraction trigger ---

EXTRACTION_SIGNALS = [
    r"(?i)let's go with\b",
    r"(?i)(?:I|we) (?:decided|chose|picked|selected)\b",
    r"(?i)(?:I want|I need|I prefer)\b",
    r"(?i)the (?:plan|approach|strategy|design) is\b",
    r"(?i)(?:trade-?off|instead of|rather than)\b",
    r"(?i)actually,?\s+(?:no|let's|we should)\b",
    r"(?i)(?:important|critical|key thing|remember)\b",
    r"(?i)(?:the problem is|root cause|the issue)\b",
    r"(?i)(?:pricing|license|revenue|customer)\b",
    r"(?i)(?:never|always|must|rule)\b.*(?:do|use|have)\b",
]

EXTRACTION_STATE_FILE = "/tmp/.greymatter-extraction-state.json"
EXTRACTION_FLOOR = 20


def detect_extraction_signal(message: str) -> bool:
    """Check if a user message contains a high-value extraction signal."""
    if len(message.strip()) < 10:
        return False
    return any(re.search(p, message) for p in EXTRACTION_SIGNALS)


class ExtractionState:
    """Track message count and extraction watermark."""

    def __init__(self, state_file: str = EXTRACTION_STATE_FILE):
        self.state_file = state_file
        self.message_count = 0
        self.watermark = 0
        self.messages: list[str] = []
        self._load()

    def _load(self):
        try:
            with open(self.state_file) as f:
                data = json.load(f)
                self.message_count = data.get("message_count", 0)
                self.watermark = data.get("watermark", 0)
                self.messages = data.get("messages", [])
        except (FileNotFoundError, json.JSONDecodeError):
            pass

    def save(self):
        with open(self.state_file, "w") as f:
            json.dump({
                "message_count": self.message_count,
                "watermark": self.watermark,
                "messages": self.messages[-100:],
            }, f)

    def increment(self, message: str = ""):
        self.message_count += 1
        if message:
            self.messages.append(message)

    def should_extract(self, signal_detected: bool) -> bool:
        msgs_since = self.message_count - self.watermark
        if signal_detected and msgs_since >= 1:
            return True
        if msgs_since >= EXTRACTION_FLOOR:
            return True
        return False

    def get_new_messages(self) -> str:
        """Get messages since last extraction."""
        new = self.messages[self.watermark:]
        return "\n\n".join(new)

    def mark_extracted(self):
        self.watermark = self.message_count
        self.save()


def main() -> None:
    message = ""
    session_id = ""
    try:
        from greymatter_core.config import Config
        from greymatter_core.db import SQLiteDatabase

        config = Config()
        db = SQLiteDatabase(config.db_path)

        session_id = get_current_session_id(db)
        if not session_id:
            sys.exit(0)

        # Priority 1: Post-compaction recovery
        recovery = check_and_inject_recovery(session_id)
        if recovery:
            try:
                from injection_log import log_injection
                log_injection(
                    hook="user_prompt_submit",
                    mode="recovery",
                    tokens_injected=len(recovery) // 4,
                    tokens_available=16000,
                    entries_included=1,
                )
            except Exception:
                pass
            print(recovery)
            sys.exit(0)

        # Priority 2: Momentum-based retrieval
        message = read_user_message()
        if not message or len(message.strip()) < 5:
            sys.exit(0)

        from momentum import MomentumTracker
        tracker = MomentumTracker.load(session_id=session_id)
        analysis = tracker.process_message(message)

        if not analysis["should_retrieve"]:
            tracker.save()
            sys.exit(0)

        tier = analysis["tier"]
        keywords = analysis["keywords"]

        # Execute tiered retrieval
        entries = []
        if tier == 0:
            entries = tier0_lookup(keywords)
        elif tier == 1:
            entries = tier1_retrieval(keywords, db)
        else:  # tier == 2
            entries = tier2_retrieval(keywords, session_id, db)

        # Save momentum state
        tracker.save()

        # Format and output
        context = format_retrieval_context(entries, tier)
        if context:
            try:
                from injection_log import log_injection
                log_injection(
                    hook="user_prompt_submit",
                    mode="retrieval",
                    tokens_injected=len(context) // 4,
                    tokens_available=MAX_RETRIEVAL_TOKENS,
                    entries_included=len(entries),
                )
            except Exception:
                pass
            print(context)

    except Exception:
        pass  # Never block user input

    # --- Extraction trigger ---
    try:
        ext_state = ExtractionState()
        ext_state.increment(message)
        signal = detect_extraction_signal(message)

        if ext_state.should_extract(signal):
            new_text = ext_state.get_new_messages()
            if new_text and len(new_text) > 50:
                import tempfile
                tmp = tempfile.NamedTemporaryFile(
                    mode="w", suffix=".txt", delete=False, prefix="gm-extract-"
                )
                tmp.write(new_text[:50000])
                tmp.close()
                extract_script = os.path.join(
                    os.path.dirname(__file__), "run_extraction.py"
                )
                subprocess.Popen(
                    [sys.executable, extract_script, session_id, "--file", tmp.name],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                )
            ext_state.mark_extracted()
        else:
            ext_state.save()
    except Exception:
        pass  # Never block user input

    sys.exit(0)


if __name__ == "__main__":
    main()
