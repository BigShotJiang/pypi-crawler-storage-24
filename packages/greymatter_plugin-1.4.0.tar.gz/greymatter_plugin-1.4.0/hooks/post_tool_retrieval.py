#!/Users/keithcotterman/Development/greymatter/.venv/bin/python
"""PostToolUse retrieval hook: surface relevant memories after read-type tools.

Fires after Read, Grep, Glob tool executions. Extracts context cues
from the tool result and queries the priming cache for relevant memories.

Budget: max 1000 tokens per injection.
Only fires for read-type tools (never for writes).
"""
import json
import os
import sys

# Add greymatter lib to path
GREYMATTER_LIB = os.path.join(os.path.dirname(__file__), "..", "..", "lib")
sys.path.insert(0, os.path.abspath(GREYMATTER_LIB))

MAX_TOKENS = 1000


def extract_context_cues(tool_name: str, tool_input: dict) -> list:
    """Extract context keywords from tool input.

    Read: file path → language, framework keywords
    Grep: search pattern → topic keywords
    Glob: file pattern → language keywords
    """
    from priming import extract_keywords

    cues = []

    if tool_name == "Read":
        file_path = tool_input.get("file_path", "")
        if file_path:
            # Extract meaningful parts from the path
            cues.extend(extract_keywords(file_path.replace("/", " ").replace(".", " ")))

    elif tool_name == "Grep":
        pattern = tool_input.get("pattern", "")
        if pattern:
            cues.extend(extract_keywords(pattern))
        path = tool_input.get("path", "")
        if path:
            cues.extend(extract_keywords(path.replace("/", " ")))

    elif tool_name == "Glob":
        pattern = tool_input.get("pattern", "")
        if pattern:
            cues.extend(extract_keywords(pattern.replace("*", " ").replace("/", " ")))

    # Deduplicate while preserving order
    seen = set()
    unique = []
    for c in cues:
        if c not in seen:
            seen.add(c)
            unique.append(c)

    return unique[:10]


def main() -> None:
    try:
        input_data = json.load(sys.stdin)
    except (json.JSONDecodeError, EOFError):
        print("{}")
        sys.exit(0)

    try:
        tool_name = input_data.get("tool_name", input_data.get("toolName", ""))
        tool_input = input_data.get("tool_input", input_data.get("toolInput", {}))

        if not isinstance(tool_input, dict):
            print("{}")
            sys.exit(0)

        # Extract context cues
        cues = extract_context_cues(tool_name, tool_input)
        if not cues:
            print("{}")
            sys.exit(0)

        # Tier 0 lookup from priming cache
        from priming import lookup_by_keywords
        entries = lookup_by_keywords(cues, max_results=3)

        if not entries:
            print("{}")
            sys.exit(0)

        # Format as additional context
        lines = []
        tokens_used = 0
        for entry in entries:
            title = entry.get("title", "")
            preview = entry.get("preview", "")[:100]
            line = f"- {title}"
            if preview and preview != title:
                line += f": {preview}"

            est_tokens = len(line) // 4
            if tokens_used + est_tokens > MAX_TOKENS:
                break
            lines.append(line)
            tokens_used += est_tokens

        if lines:
            context = "Related from memory:\n" + "\n".join(lines)
            print(context)
        else:
            print("{}")

    except Exception:
        print("{}")

    sys.exit(0)


if __name__ == "__main__":
    main()
