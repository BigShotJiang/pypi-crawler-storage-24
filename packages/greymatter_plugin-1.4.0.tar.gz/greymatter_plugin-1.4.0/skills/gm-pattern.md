---
name: gm-pattern
description: Create a new GreyMatter pattern with guided prompts for type, domain, and observation
---

Guide the user through creating a new pattern:

1. Ask what type of pattern this is:
   - **convention** — a coding or workflow convention to follow
   - **anti-pattern** — something to avoid
   - **architecture** — an architectural decision or principle
   - **workflow** — a process or workflow pattern
   - **debugging** — a debugging insight or technique

2. Ask what domain it applies to (e.g., testing, security, performance, operations, architecture, business)

3. Ask for a concise title (5-10 words)

4. Ask for the observation — the specific, actionable insight

5. Call `gm_pattern(action="create", type="<type>", domain="<domain>", title="<title>", observation="<observation>")`

6. Confirm the pattern was created and show its ID
