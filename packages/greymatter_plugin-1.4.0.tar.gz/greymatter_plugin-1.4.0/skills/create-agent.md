---
name: create-agent
description: Create a new Claude Code agent through a guided wizard — combines reference materials, autonomous research, and interactive interview to generate expert agent definitions
---

# Expert Agent Creator

Create a Claude Code agent through a 5-phase wizard. Announce at start: "I'm using the create-agent skill to build a new expert agent."

## Phase 1: Name & Mission

Ask these using AskUserQuestion (one question with three fields if possible, otherwise sequentially):

1. **Agent name** — kebab-case identifier (e.g., `security-analyst`, `market-researcher`)
2. **Mission** — One sentence: what does this agent do? (e.g., "Research an organization's cybersecurity posture and compliance readiness")
3. **Domain tags** — Comma-separated for GreyMatter categorization (e.g., `security, compliance, risk`)

## Phase 2: Knowledge Gathering

Run three tracks sequentially. Each builds on the previous.

### Track A: Reference Materials

Ask: "Do you have reference materials to feed this agent? Provide URLs, PDF file paths, or YouTube video URLs. Type 'none' to skip."

For each provided source:
- **URLs**: Use WebFetch to read the page. Extract domain-specific knowledge, terminology, frameworks, research patterns, and quality criteria.
- **PDF files**: Use Read tool. Extract key concepts, methodologies, and domain structure.
- **YouTube videos**: Use `mcp__youtube-transcript-npm__get-transcript` to get the transcript. Extract domain knowledge and expert insights.
- **Local files**: Use Read tool directly.

After processing each source, summarize what was extracted in 3-5 bullet points. Store all extracted knowledge for Phase 3.

### Track B: Claude Research

Based on the mission and any Track A materials, autonomously research the domain:

1. Use WebSearch to find:
   - Common data sources for this domain
   - Industry terminology and standard frameworks
   - Typical analysis outputs and report structures
   - Quality benchmarks and best practices

2. Synthesize findings into structured knowledge bullets under these categories:
   - **Domain expertise** — key concepts, terminology, frameworks
   - **Data sources** — where to find information
   - **Output patterns** — what good analysis looks like
   - **Quality markers** — how to judge confidence and completeness

Present a summary of research findings to the user before proceeding.

### Track C: Interview

Ask these questions using AskUserQuestion, one at a time:

1. **Research targets**: "What specifically should this agent research? What questions should it answer?"

2. **Data sources**: "What data sources should it prioritize?"
   - Options: Web search, Local files, Specific websites (list them), APIs, Other

3. **Output structure**: "What output format do you need?"
   - Options: Findings list (like SalesOS agents), Narrative report, Scorecard/rating, Structured analysis, Custom (describe)

4. **Confidence levels**: "What confidence framework should it use?"
   - Options: FACT/CONFIRMED/EMERGING (SalesOS standard), HIGH/MEDIUM/LOW, Custom levels (describe)

5. **Tools needed**: "What tools does this agent need?"
   - Options (multi-select): WebSearch, Read (files), Grep (search code), Bash (run commands), None (reasoning only)

6. **Model**: "What model should it default to?"
   - Options: sonnet (fast, good for most research), opus (deep reasoning, complex synthesis)

## Phase 3: Prompt Synthesis

Compose the system prompt from all gathered knowledge. Follow this template:

```markdown
# {Agent Name} — {Mission}

## Domain Expertise

{Synthesized from Track A reference materials + Track B research.
Include key terminology, frameworks, industry context, and domain-specific
knowledge that makes this agent an expert.}

## Research Protocol

{From Track C interview — what to research, in what order, from what sources.
Be specific about the research steps the agent should follow.}

## Data Sources

{Prioritized list of data sources from interview + research.
Include specific sites, databases, or file paths if mentioned.}

## Output Format

Respond with a JSON object following this schema:

```json
{Derive schema from the output structure chosen in interview.
Always include a top-level findings array if the agent does research.
Include confidence field on each finding.}
```

## Quality Expectations

{Confidence framework from interview.
Source citation requirements.
Depth and completeness expectations.
What constitutes a high-quality vs. low-quality output.}
```

Present the synthesized prompt to the user for review. Ask: "Does this system prompt capture the right expertise? Any changes?"

Iterate until approved.

## Phase 4: Agent File Generation

Generate the `.md` agent definition file:

```yaml
---
name: {agent-name}
description: {mission sentence}
tools: [{tools from interview, comma-separated}]
model: {model from interview}
---

{system prompt from Phase 3}
```

Show the complete file to the user for final approval.

## Phase 5: Save & Register

### Save Location

Ask using AskUserQuestion:
- **Project agents** — Save to `.claude/agents/{agent-name}.md` in the current project
- **Global agents** — Save to `~/.claude/agents/{agent-name}.md` available across all projects

Write the file to the chosen location.

### GreyMatter Registration

Register the agent as a GreyMatter knowledge entry:

```
gm_knowledge create
  entry_type: reference
  title: "Agent Blueprint: {agent-name}"
  domain: {primary domain tag}
  tags: agent-blueprint
  content: |
    Name: {agent-name}
    Mission: {mission}
    Domains: {domain tags}
    Tools: {tool list}
    Model: {model}
    Path: {saved file path}
    Created: {YYYY-MM-DD}
```

### App Registration (Optional)

Ask: "Register this agent with a GreyMatter app for dispatch? (e.g., salesos, greymatter)"

If yes, call `gm_app_register` with the agent definition:
```
gm_app_register
  app_name: {chosen app}
  version: "1.0.0"
  agents: [{"name": "{agent-name}", "domains": [{domain tags}]}]
```

## Completion

Report:
```
Agent created successfully:
  Name: {agent-name}
  Path: {file path}
  GreyMatter: registered as knowledge entry

To use: reference @{agent-name} in conversation or dispatch via GreyMatter
```

## Quality Checklist

Before saving, verify:
- Agent name is valid kebab-case (lowercase, hyphens only)
- Mission is a single clear sentence
- System prompt includes all sections (expertise, protocol, output format, quality)
- Output format has a JSON schema
- Tools list is specified
- Model is specified
- At least one knowledge track produced substantive content
- User approved the system prompt
