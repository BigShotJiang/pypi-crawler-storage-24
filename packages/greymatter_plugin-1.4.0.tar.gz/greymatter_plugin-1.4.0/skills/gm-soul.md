---
name: gm-soul
description: Read or display the GreyMatter soul document — identity, values, and operating principles
---

Help the user interact with the soul document:

**Read full soul:**
- Call `gm_soul(action="read")` and display the content

**Read a section:**
- Call `gm_soul(action="section", section="<section_name>")`
- Common sections: Values, Identity, Principles, Relationships

**Summary:**
- Call `gm_soul(action="summary")` for a quick overview
