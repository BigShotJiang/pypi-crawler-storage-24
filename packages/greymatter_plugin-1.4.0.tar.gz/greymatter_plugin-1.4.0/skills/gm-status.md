---
name: gm-status
description: Show GreyMatter system status including pattern counts, knowledge entries, work items, and quality standards
---

Display a comprehensive GreyMatter system overview:

1. Call `gm_status()` to get system counts
2. Format the results as a clean summary table showing:
   - Patterns: total, high confidence, medium confidence
   - Knowledge: total entries
   - Work items: total, queued, in progress
   - Standards: active count
   - Soul: loaded/not found
