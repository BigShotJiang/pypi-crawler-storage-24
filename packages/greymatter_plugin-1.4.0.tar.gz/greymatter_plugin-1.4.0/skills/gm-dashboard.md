---
name: gm-dashboard
description: Display a formatted GreyMatter dashboard with patterns, work items, knowledge, and quality metrics
---

Build and display a comprehensive GreyMatter dashboard:

1. Call `gm_status()` for system counts
2. Call `gm_pattern(action="list", confidence="high")` for established patterns
3. Call `gm_work(action="list", status="in_progress")` for active work
4. Call `gm_benchmark(action="summary")` for quality metrics

Format as a clean markdown dashboard:

## GreyMatter Dashboard

### System Health
| Metric | Count |
|--------|-------|
| Patterns | X total (Y high confidence) |
| Knowledge | X entries |
| Work Items | X active, Y queued |
| Standards | X active |

### High-Confidence Patterns
- [pattern title]: [observation summary]
- ...

### Active Work
- [work item title] (priority X)
- ...

### Quality Metrics
- Defect density: X/KLOC
- First-pass quality: X%
