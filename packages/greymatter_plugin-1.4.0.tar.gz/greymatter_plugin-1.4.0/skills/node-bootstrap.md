---
name: node-bootstrap
description: Bootstrap a new Ubuntu server node into the GreyMatter cluster — SSH key auth, hardening, Tailscale, Python 3.12, and validation. Use when adding a new physical or virtual Ubuntu machine to the fleet.
---

# Node Bootstrap

Bootstrap a fresh Ubuntu server into the GreyMatter cluster with secure SSH, Tailscale networking, and Python runtime.

**Announce:** "I'm using the node-bootstrap skill to set up this machine."

## Prerequisites

- Target machine running Ubuntu 22.04+ with SSH accessible on the local network
- Username and password for initial access
- Local machine has an SSH key pair (`~/.ssh/id_ed25519`)
- Tailscale account with existing tailnet

## Process

### Step 1: Initial Connection

Connect via `expect` to handle password authentication (the `!!` in passwords causes bash history expansion — always use single-quoted `printf` or `expect` with proper escaping):

```bash
expect -c '
set timeout 60
spawn ssh -o StrictHostKeyChecking=no <user>@<ip>
expect "password:"
send "<password>\r"
expect "$ "
send "hostname && uname -a\r"
expect "$ "
send "exit\r"
expect eof
'
```

Record: hostname, OS version, kernel, disk usage, memory, network interface.

### Step 2: Update and Upgrade

```bash
# Use DEBIAN_FRONTEND=noninteractive to avoid prompts
sudo DEBIAN_FRONTEND=noninteractive apt update -y
sudo DEBIAN_FRONTEND=noninteractive apt upgrade -y
```

For sudo with passwords containing special characters (like `!!`), use this pattern:
```bash
# Write password to temp file using single-quoted printf (avoids shell expansion)
printf '%s' 'ThePassword!!' > /tmp/.p
cat /tmp/.p | sudo -S <command>
rm -f /tmp/.p
```

### Step 3: Verify Python 3.12

```bash
python3 --version
python3.12 --version
```

If not installed:
```bash
sudo apt install -y python3.12 python3.12-venv python3-pip
```

### Step 4: SSH Key Authentication

Copy the local public key to the remote machine:

```bash
# On remote:
mkdir -p ~/.ssh && chmod 700 ~/.ssh
echo "<public_key_content>" >> ~/.ssh/authorized_keys
chmod 600 ~/.ssh/authorized_keys
```

### Step 5: Harden SSH

Back up and modify sshd_config:

```bash
sudo cp /etc/ssh/sshd_config /etc/ssh/sshd_config.bak
sudo sed -i 's/#PasswordAuthentication yes/PasswordAuthentication no/' /etc/ssh/sshd_config
sudo sed -i 's/PasswordAuthentication yes/PasswordAuthentication no/' /etc/ssh/sshd_config
sudo sed -i 's/#PermitRootLogin prohibit-password/PermitRootLogin no/' /etc/ssh/sshd_config
sudo sed -i 's/PermitRootLogin yes/PermitRootLogin no/' /etc/ssh/sshd_config
sudo sed -i 's/#PubkeyAuthentication yes/PubkeyAuthentication yes/' /etc/ssh/sshd_config
```

Restart SSH (Ubuntu 24.04 uses `ssh` not `sshd`):
```bash
sudo systemctl restart ssh   # NOT sshd
```

**Verify** key-based auth works before proceeding:
```bash
ssh -i ~/.ssh/id_ed25519 -o PasswordAuthentication=no <user>@<ip> 'echo KEY_AUTH_OK'
```

### Step 6: Set Up Passwordless Sudo (for automation)

```bash
# From remote session:
printf '%s' '<password>' > /tmp/.p
cat /tmp/.p | sudo -S bash -c 'echo "<user> ALL=(ALL) NOPASSWD: ALL" > /etc/sudoers.d/<user>'
rm -f /tmp/.p
# Verify:
sudo whoami  # Should return "root" with no prompt
```

### Step 7: Install Tailscale

```bash
curl -fsSL https://tailscale.com/install.sh | sudo sh
```

Start Tailscale — this generates an auth URL:
```bash
sudo tailscale up
```

**STOP and present the auth URL to the user.** Wait for them to approve in the Tailscale admin console.

After approval, verify:
```bash
sudo tailscale status
sudo tailscale ip
```

### Step 8: Enable Persistent Services

```bash
# Ensure both services start on boot
sudo systemctl enable ssh
sudo systemctl start ssh
sudo systemctl enable tailscaled
# Set operator for non-root tailscale access
sudo tailscale set --operator=<user>
```

Verify:
```bash
sudo systemctl is-enabled ssh        # → enabled
sudo systemctl is-active ssh         # → active
sudo systemctl is-enabled tailscaled # → enabled
sudo systemctl is-active tailscaled  # → active
```

### Step 9: Verify Tailscale SSH

From the local machine, confirm SSH works over the Tailscale IP:
```bash
ssh -i ~/.ssh/id_ed25519 -o StrictHostKeyChecking=no <user>@<tailscale_ip> 'echo TAILSCALE_SSH_OK && hostname'
```

### Step 10: Report

Present a summary table:

| Item | Status | Details |
|------|--------|---------|
| OS updated | | |
| Python 3.12 | | version |
| SSH key auth | | working/failed |
| SSH hardened | | password disabled, root disabled |
| Tailscale | | version, IP |
| Services persistent | | ssh + tailscaled enabled |
| Tailscale SSH verified | | |

## Known Gotchas

1. **`!!` in passwords** — Bash expands `!!` to last command. Always use single-quoted strings or `printf '%s'`.
2. **SSH service name** — Ubuntu 24.04 uses `ssh.service`, not `sshd.service`.
3. **Tailscale auth** — Requires interactive browser approval. Cannot be fully automated without pre-auth keys.
4. **sudo via pipe** — Use `sudo -S` to read password from stdin when non-interactive.

## Tailscale Pre-Auth Keys (Optional)

For fully automated setup without browser approval:
```bash
# Generate at https://login.tailscale.com/admin/settings/keys
sudo tailscale up --authkey=tskey-auth-<key>
```

## Fleet Reference

| Hostname | Role | Local IP | Tailscale IP |
|----------|------|----------|--------------|
| agentics-mac-mini | Coordinator | — | 100.81.247.14 |
| agenticai2 (Alienware) | Worker | 192.168.50.195 | 100.116.214.4 |
| agenticai3 (Legion) | Worker | 192.168.50.234 | 100.98.4.35 |
