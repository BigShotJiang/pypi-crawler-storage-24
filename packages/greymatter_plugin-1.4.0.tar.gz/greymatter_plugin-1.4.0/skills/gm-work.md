---
name: gm-work
description: Manage GreyMatter work items — list, create, complete, or update status
---

Help the user manage work items. Based on what they ask:

**List work items:**
- Call `gm_work(action="list")` for all items
- Call `gm_work(action="list", status="in_progress")` for active items
- Format as a table with status, priority, and title

**Create a work item:**
- Ask for title and optional description
- Ask for priority (1-100, lower = higher priority, default 100)
- Call `gm_work(action="create", title="<title>", description="<desc>", priority=<n>)`

**Complete a work item:**
- If they specify an ID, call `gm_work(action="complete", work_id="<id>")`
- If they describe it, search for it first with `gm_work(action="list")`, then complete

**Update status:**
- Call `gm_work(action="update", work_id="<id>", status="<status>")`
- Valid statuses: queued, in_progress, completed
