---
name: gm-review
description: Run a GreyMatter quality review against recent code changes, checking standards and capturing issues
---

Run a quality review against recent changes:

1. Call `gm_standards(action="list")` to get all active quality standards
2. Get the recent changes: run `git diff HEAD~1` (or `git diff --staged` if there are staged changes)
3. Review each changed file against the applicable standards:
   - Check for critical violations first (security, correctness)
   - Then high-severity (error handling, testing)
   - Then medium-severity (naming, structure)
4. For each violation found:
   - Note the standard it violates
   - Show the specific code
   - Suggest a fix
5. Summarize findings:
   - Critical: X issues
   - High: X issues
   - Medium: X issues
6. If any new patterns are discovered during review, capture them with `gm_pattern(action="create", ...)`
