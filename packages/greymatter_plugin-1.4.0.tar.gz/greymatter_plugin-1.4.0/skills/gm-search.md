---
name: gm-search
description: Semantic search across GreyMatter — find meetings, docs, accounts, and knowledge by meaning, not just keywords
---

Use semantic search when the user asks questions about their data that require understanding meaning rather than matching exact words.

**When to use semantic search vs keyword search:**
- Keyword (gm_salesos search): user knows exact terms — "Washoe County meetings"
- Semantic (gm_semantic search): user describes meaning — "deals where customer pushed back on pricing"

## Search Modes

### Chunk mode (default) — precise answers

Returns matching text segments from within documents. Best for:
- Finding specific moments in transcripts
- Locating exact passages that match a concept
- "What did they say about pricing?"

```
gm_semantic(action="search", query="pushed back on pricing", detail="chunks")
```

### Document mode — broad overview

Groups results by parent document, shows best matching excerpt. Best for:
- Finding which meetings/docs relate to a topic
- Getting a list of relevant documents
- "Which meetings discussed Cisco?"

```
gm_semantic(action="search", query="Cisco campus refresh", detail="documents")
```

## Hybrid Search

For best results combining keywords and meaning:

1. Call `gm_semantic(action="hybrid", query="<user's question>", limit=10)`
2. This combines FTS5 keyword matching with vector similarity
3. Supports both `detail="chunks"` and `detail="documents"`

## Cross-Table Search

To search across all data types at once:

1. Call `gm_semantic(action="search", query="<question>")` with no tables filter
2. Results will include meetings, documents, knowledge entries, and accounts
3. Each result has a `source_type` field indicating where it came from

## Indexing

If search returns no results or the user just imported new data:

1. Call `gm_semantic(action="status")` to check embedding counts (document + chunk layers)
2. If counts are 0, call `gm_semantic(action="index")` to batch embed all data
3. For a specific table: `gm_semantic(action="index", tables="meetings")`
4. Indexing requires Ollama to be running with nomic-embed-text model
5. Long documents are automatically chunked into overlapping segments

## Troubleshooting

- **No results:** Check `gm_semantic(action="status")` — data may not be indexed yet
- **Ollama error:** Ensure Ollama is running: `ollama serve` and model is pulled: `ollama pull nomic-embed-text`
- **Slow indexing:** Normal for first run — ~9,250 vectors takes ~15 minutes
