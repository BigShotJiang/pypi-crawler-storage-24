# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class UpdateVirtualInterfaceRequestBody:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'virtual_interface': 'UpdateVirtualInterface'
    }

    attribute_map = {
        'virtual_interface': 'virtual_interface'
    }

    def __init__(self, virtual_interface=None):
        r"""UpdateVirtualInterfaceRequestBody

        The model defined in huaweicloud sdk

        :param virtual_interface: 
        :type virtual_interface: :class:`huaweicloudsdkdc.v3.UpdateVirtualInterface`
        """
        
        

        self._virtual_interface = None
        self.discriminator = None

        self.virtual_interface = virtual_interface

    @property
    def virtual_interface(self):
        r"""Gets the virtual_interface of this UpdateVirtualInterfaceRequestBody.

        :return: The virtual_interface of this UpdateVirtualInterfaceRequestBody.
        :rtype: :class:`huaweicloudsdkdc.v3.UpdateVirtualInterface`
        """
        return self._virtual_interface

    @virtual_interface.setter
    def virtual_interface(self, virtual_interface):
        r"""Sets the virtual_interface of this UpdateVirtualInterfaceRequestBody.

        :param virtual_interface: The virtual_interface of this UpdateVirtualInterfaceRequestBody.
        :type virtual_interface: :class:`huaweicloudsdkdc.v3.UpdateVirtualInterface`
        """
        self._virtual_interface = virtual_interface

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, UpdateVirtualInterfaceRequestBody):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
