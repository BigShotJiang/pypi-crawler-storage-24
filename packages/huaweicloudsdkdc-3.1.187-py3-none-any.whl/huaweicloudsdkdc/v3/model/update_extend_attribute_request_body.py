# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class UpdateExtendAttributeRequestBody:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'extend_attribute': 'VifExtendAttribute'
    }

    attribute_map = {
        'extend_attribute': 'extend_attribute'
    }

    def __init__(self, extend_attribute=None):
        r"""UpdateExtendAttributeRequestBody

        The model defined in huaweicloud sdk

        :param extend_attribute: 
        :type extend_attribute: :class:`huaweicloudsdkdc.v3.VifExtendAttribute`
        """
        
        

        self._extend_attribute = None
        self.discriminator = None

        self.extend_attribute = extend_attribute

    @property
    def extend_attribute(self):
        r"""Gets the extend_attribute of this UpdateExtendAttributeRequestBody.

        :return: The extend_attribute of this UpdateExtendAttributeRequestBody.
        :rtype: :class:`huaweicloudsdkdc.v3.VifExtendAttribute`
        """
        return self._extend_attribute

    @extend_attribute.setter
    def extend_attribute(self, extend_attribute):
        r"""Sets the extend_attribute of this UpdateExtendAttributeRequestBody.

        :param extend_attribute: The extend_attribute of this UpdateExtendAttributeRequestBody.
        :type extend_attribute: :class:`huaweicloudsdkdc.v3.VifExtendAttribute`
        """
        self._extend_attribute = extend_attribute

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, UpdateExtendAttributeRequestBody):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
