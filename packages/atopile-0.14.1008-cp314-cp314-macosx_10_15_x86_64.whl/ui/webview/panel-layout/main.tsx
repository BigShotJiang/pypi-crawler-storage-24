import { useEffect, useMemo, useRef, useState } from "react";
import { render } from "../common/render";
import { WebviewRpcClient, rpcClient } from "../common/webviewRpcClient";
import { createWebviewLogger } from "../common/logger";
import {
  ensureLayoutViewerShell,
  mountLayoutViewer,
  RpcLayoutClient,
  type LayoutViewerHandle,
  type LayoutViewerShellElements,
} from "../common/layout";
import "../common/layout/layout-shell.css";

const logger = createWebviewLogger("PanelLayout");

function setOverlayState(
  shell: LayoutViewerShellElements | null,
  message: string,
  subtext: string,
  options?: {
    isError?: boolean;
    showSpinner?: boolean;
  },
): void {
  const overlay = shell?.initialLoadingEl;
  if (!overlay) {
    return;
  }
  const { isError = false, showSpinner = false } = options ?? {};

  overlay.classList.remove("hidden");
  overlay.classList.toggle("error", isError);
  overlay.setAttribute("aria-busy", showSpinner ? "true" : "false");

  const spinnerEl = overlay.querySelector(".initial-loading-spinner") as HTMLElement | null;
  const messageEl = overlay.querySelector(".initial-loading-message") as HTMLElement | null;
  const subtextEl = overlay.querySelector(".initial-loading-subtext") as HTMLElement | null;
  if (spinnerEl) {
    spinnerEl.hidden = !showSpinner;
  }
  if (messageEl) {
    messageEl.textContent = message;
  }
  if (subtextEl) {
    subtextEl.textContent = subtext;
  }
}

function App() {
  const projectState = WebviewRpcClient.useSubscribe("projectState");
  const layoutData = WebviewRpcClient.useSubscribe("layoutData");
  const selectedBuildInProgress = WebviewRpcClient.useSubscribe("selectedBuildInProgress");
  const hostRef = useRef<HTMLDivElement | null>(null);
  const panelClient = useMemo(
    () => (rpcClient ? new RpcLayoutClient(rpcClient, logger) : null),
    [],
  );
  const viewerRef = useRef<LayoutViewerHandle | null>(null);
  const [shell, setShell] = useState<LayoutViewerShellElements | null>(null);

  function resetViewerShell(): LayoutViewerShellElements | null {
    viewerRef.current?.dispose();
    viewerRef.current = null;
    if (!hostRef.current) {
      return null;
    }
    const nextShell = ensureLayoutViewerShell(hostRef.current);
    setShell(nextShell);
    return nextShell;
  }

  useEffect(() => {
    if (!hostRef.current) {
      return;
    }

    setShell(ensureLayoutViewerShell(hostRef.current));

    return () => {
      hostRef.current?.replaceChildren();
      setShell(null);
    };
  }, []);

  useEffect(() => {
    if (!shell) {
      return;
    }

    if (!projectState.selectedProjectRoot || !projectState.selectedTarget) {
      const activeShell = viewerRef.current ? resetViewerShell() : shell;
      setOverlayState(
        activeShell,
        "Layout",
        "Select a project and build target to view the PCB layout.",
      );
      return;
    }

    if (layoutData.error) {
      logger.error(`Layout state reported error: ${String(layoutData.error)}`);
      const activeShell = viewerRef.current ? resetViewerShell() : shell;
      setOverlayState(activeShell, "Layout unavailable", String(layoutData.error), {
        isError: true,
      });
      return;
    }

    if (!layoutData.path) {
      const activeShell = viewerRef.current ? resetViewerShell() : shell;
      setOverlayState(
        activeShell,
        "No layout yet",
        selectedBuildInProgress
          ? "Build in progress. The layout will appear here automatically when it completes."
          : "Start a build to see the layout here. It will appear automatically when the build completes.",
      );
      return;
    }

    if (!viewerRef.current) {
      if (!panelClient) {
        logger.error("Panel layout RPC client is unavailable.");
        setOverlayState(shell, "Layout unavailable", "RPC client is unavailable.", {
          isError: true,
        });
        return;
      }

      try {
        logger.info(
          `Mounting layout viewer over RPC pcbPath=${layoutData.path}`,
        );
        viewerRef.current = mountLayoutViewer({
          canvas: shell.canvas,
          client: panelClient,
          initialLoadingEl: shell.initialLoadingEl,
          layerPanelEl: shell.layerPanelEl,
          statusEl: shell.statusEl,
          coordsEl: shell.coordsEl,
          busyEl: shell.busyEl,
          fpsEl: shell.fpsEl,
          helpEl: shell.helpEl,
          logger,
        });
      } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        const detail = error instanceof Error && error.stack
          ? error.stack
          : message;
        logger.error(`Failed to mount layout viewer: ${detail}`);
        setOverlayState(
          shell,
          "Layout unavailable",
          message || "Failed to initialize layout viewer.",
          { isError: true },
        );
        return;
      }
    }
  }, [
    panelClient,
    projectState.selectedProjectRoot,
    projectState.selectedTarget,
    selectedBuildInProgress,
    layoutData.error,
    layoutData.path,
    shell,
  ]);

  useEffect(() => {
    return () => {
      viewerRef.current?.dispose();
      viewerRef.current = null;
    };
  }, []);

  return <div id="layout-viewer-root" ref={hostRef} />;
}

render(App);
