export interface LayoutViewerShellElements {
  root: HTMLElement;
  canvas: HTMLCanvasElement;
  initialLoadingEl: HTMLElement;
  layerPanelEl: HTMLElement;
  statusEl: HTMLElement;
  coordsEl: HTMLElement;
  busyEl: HTMLElement;
  fpsEl: HTMLElement;
  helpEl: HTMLElement;
}

const SHELL_HTML = `
  <div class="layout-viewer-shell">
    <canvas id="editor-canvas"></canvas>
    <div id="initial-loading" role="status" aria-live="polite" aria-busy="true">
      <div class="initial-loading-content">
        <div class="initial-loading-spinner"></div>
        <div class="initial-loading-message">Loading PCB</div>
        <div class="initial-loading-subtext">Preparing layout editor...</div>
      </div>
    </div>
    <div id="layer-panel"></div>
    <div id="status">
      <span id="status-coords"></span>
      <span id="status-busy" aria-hidden="true">
        <span class="status-busy-spinner"></span>
        Syncing...
      </span>
      <span id="status-fps"></span>
      <span id="status-help">
        Scroll zoom · Middle-click pan · Click group/select · Shift+drag box-select ·
        Double-click single · Esc clear · R rotate · F flip · Ctrl+Z undo ·
        Ctrl+Shift+Z redo
      </span>
    </div>
  </div>
`;

function requireElement<T extends Element>(
  container: ParentNode,
  selector: string,
  expectedType: { new (): T },
): T {
  const element = container.querySelector(selector);
  if (!(element instanceof expectedType)) {
    throw new Error(`Layout viewer shell missing required element: ${selector}`);
  }
  return element;
}

export function ensureLayoutViewerShell(
  host: HTMLElement,
): LayoutViewerShellElements {
  host.replaceChildren();
  host.insertAdjacentHTML("beforeend", SHELL_HTML);

  const root = requireElement(host, ".layout-viewer-shell", HTMLElement);
  return {
    root,
    canvas: requireElement(root, "#editor-canvas", HTMLCanvasElement),
    initialLoadingEl: requireElement(root, "#initial-loading", HTMLElement),
    layerPanelEl: requireElement(root, "#layer-panel", HTMLElement),
    statusEl: requireElement(root, "#status", HTMLElement),
    coordsEl: requireElement(root, "#status-coords", HTMLElement),
    busyEl: requireElement(root, "#status-busy", HTMLElement),
    fpsEl: requireElement(root, "#status-fps", HTMLElement),
    helpEl: requireElement(root, "#status-help", HTMLElement),
  };
}
