import { Editor } from "./editor";
import { getLayerColor } from "./colors";
import {
    type LayoutClientLogger,
    type LayoutTransport,
} from "./layout_client";
import type { LayerModel } from "./types";

export interface LayoutViewerMountOptions {
    canvas: HTMLCanvasElement;
    client: LayoutTransport;
    readOnly?: boolean;
    logger?: LayoutClientLogger;
    initialLoadingEl?: HTMLElement | null;
    layerPanelEl?: HTMLElement | null;
    statusEl?: HTMLElement | null;
    coordsEl?: HTMLElement | null;
    busyEl?: HTMLElement | null;
    fpsEl?: HTMLElement | null;
    helpEl?: HTMLElement | null;
}

export interface LayoutViewerHandle {
    editor: Editor;
    dispose(): void;
}

interface LayerGroup {
    group: string;
    layers: LayerModel[];
}

const OBJECT_ROOT_FILTERS = [
    { id: "__type:zones", label: "Zones", color: "#5a8a3a" },
    { id: "__type:tracks", label: "Tracks & Vias", color: "#c05030" },
    { id: "__type:pads", label: "Pads", color: "#a07020" },
] as const;

const TEXT_SHAPES_FILTERS = [
    { id: "__type:text", label: "Text", color: "#4a8cad" },
    { id: "__type:shapes", label: "Shapes", color: "#356982" },
] as const;

const TEXT_SHAPES_FILTER_IDS = TEXT_SHAPES_FILTERS.map((t) => t.id);
const OBJECT_TYPE_IDS = [
    ...OBJECT_ROOT_FILTERS.map((t) => t.id),
    ...TEXT_SHAPES_FILTER_IDS,
];
const HELP_TEXT =
    "Scroll zoom · Middle-click pan · Click group/select · Shift+drag box-select · Double-click single · Esc clear · R rotate · F flip · Ctrl+Z undo · Ctrl+Shift+Z redo";
const READ_ONLY_HELP_TEXT = "Scroll zoom · Middle-click pan";

function groupLayers(layers: LayerModel[]): { groups: LayerGroup[]; topLevel: LayerModel[] } {
    const groupMap = new Map<string, LayerModel[]>();
    const topLevel: LayerModel[] = [];

    for (const layer of layers) {
        const group = layer.group?.trim() ?? "";
        if (!group) {
            topLevel.push(layer);
            continue;
        }
        if (!groupMap.has(group)) groupMap.set(group, []);
        groupMap.get(group)!.push(layer);
    }

    const groups = [...groupMap.entries()]
        .map(([group, groupedLayers]) => ({ group, layers: groupedLayers }))
        .sort((a, b) => {
            const aOrder = a.layers[0]?.panel_order ?? Number.MAX_SAFE_INTEGER;
            const bOrder = b.layers[0]?.panel_order ?? Number.MAX_SAFE_INTEGER;
            if (aOrder !== bOrder) return aOrder - bOrder;
            return a.group.localeCompare(b.group);
        });

    return { groups, topLevel };
}

function colorToCSS(layerName: string, layerById: Map<string, LayerModel>): string {
    const [r, g, b] = getLayerColor(layerName, layerById);
    return `rgb(${Math.round(r * 255)},${Math.round(g * 255)},${Math.round(b * 255)})`;
}

function createSwatch(color: string): HTMLSpanElement {
    const swatch = document.createElement("span");
    swatch.className = "layer-swatch";
    swatch.style.background = color;
    return swatch;
}

function updateRowVisual(row: HTMLElement, visible: boolean): void {
    row.style.opacity = visible ? "1" : "0.3";
}

function updateGroupVisual(editor: Editor, row: HTMLElement, childLayers: string[]): void {
    const allVisible = childLayers.every((l) => editor.isLayerVisible(l));
    const allHidden = childLayers.every((l) => !editor.isLayerVisible(l));
    if (allVisible) {
        row.style.opacity = "1";
    } else if (allHidden) {
        row.style.opacity = "0.3";
    } else {
        row.style.opacity = "0.6";
    }
}

function setLoadingState(
    initialLoadingEl: HTMLElement | null | undefined,
    message: string,
    subtext: string,
    isError = false,
): void {
    if (!initialLoadingEl) return;
    const messageEl = initialLoadingEl.querySelector(".initial-loading-message") as HTMLElement | null;
    const subtextEl = initialLoadingEl.querySelector(".initial-loading-subtext") as HTMLElement | null;
    initialLoadingEl.classList.remove("hidden");
    initialLoadingEl.classList.toggle("error", isError);
    initialLoadingEl.setAttribute("aria-busy", isError ? "false" : "true");
    if (messageEl) messageEl.textContent = message;
    if (subtextEl) subtextEl.textContent = subtext;
}

function hideLoadingState(initialLoadingEl: HTMLElement | null | undefined): void {
    if (!initialLoadingEl) return;
    initialLoadingEl.classList.add("hidden");
    initialLoadingEl.classList.remove("error");
    initialLoadingEl.setAttribute("aria-busy", "false");
}

function formatErrorDetail(error: unknown): string {
    if (error instanceof Error) {
        return error.stack || error.message || String(error);
    }
    return String(error);
}

export function mountLayoutViewer(options: LayoutViewerMountOptions): LayoutViewerHandle {
    const {
        canvas,
        client,
        readOnly = false,
        logger,
        initialLoadingEl = document.getElementById("initial-loading"),
        layerPanelEl = document.getElementById("layer-panel"),
        statusEl = document.getElementById("status"),
        coordsEl = document.getElementById("status-coords"),
        busyEl = document.getElementById("status-busy"),
        fpsEl = document.getElementById("status-fps"),
        helpEl = document.getElementById("status-help"),
    } = options;

    logger?.info?.("Initializing layout viewer");

    const editor = new Editor(canvas, client, { readOnly, logger });
    let disposed = false;
    let panelCollapsed = false;
    let objectTypesExpanded = false;
    let textShapesExpanded = false;
    let fpsAnimationId: number | null = null;
    const collapsedGroups = new Set<string>();
    const cleanupFns: Array<() => void> = [];

    function buildLayerPanel(): void {
        const panel = layerPanelEl;
        if (!panel) return;
        panel.innerHTML = "";

        const header = document.createElement("div");
        header.className = "layer-panel-header";

        const headerTitle = document.createElement("span");
        headerTitle.textContent = "Layers";

        let expandTab = document.getElementById("layer-expand-tab");
        if (!expandTab) {
            expandTab = document.createElement("div");
            expandTab.id = "layer-expand-tab";
            expandTab.className = "layer-expand-tab";
            expandTab.textContent = "Layers";
            expandTab.addEventListener("click", () => {
                panelCollapsed = false;
                panel.classList.remove("collapsed");
                expandTab!.classList.remove("visible");
            });
            document.body.appendChild(expandTab);
        }

        const collapseBtn = document.createElement("span");
        collapseBtn.className = "layer-collapse-btn";
        collapseBtn.textContent = "\u25C0";
        collapseBtn.addEventListener("click", (e) => {
            e.stopPropagation();
            panelCollapsed = true;
            panel.classList.add("collapsed");
            expandTab!.classList.add("visible");
        });

        header.appendChild(headerTitle);
        header.appendChild(collapseBtn);
        panel.appendChild(header);

        const content = document.createElement("div");
        content.className = "layer-panel-content";

        const objGroupRow = document.createElement("div");
        objGroupRow.className = "layer-group-header";

        const objChevron = document.createElement("span");
        objChevron.className = "layer-chevron";
        objChevron.textContent = objectTypesExpanded ? "\u25BE" : "\u25B8";

        const objSwatch = document.createElement("span");
        objSwatch.className = "layer-swatch";
        objSwatch.style.background = "linear-gradient(135deg, #5a8a3a 50%, #c05030 50%)";

        const objLabel = document.createElement("span");
        objLabel.className = "layer-group-name";
        objLabel.textContent = "Objects";

        objGroupRow.appendChild(objChevron);
        objGroupRow.appendChild(objSwatch);
        objGroupRow.appendChild(objLabel);

        const objectRows = new Map<string, HTMLElement>();

        function updateObjGroupVisual(): void {
            const allVis = OBJECT_TYPE_IDS.every((id) => editor.isLayerVisible(id));
            const allHid = OBJECT_TYPE_IDS.every((id) => !editor.isLayerVisible(id));
            objGroupRow.style.opacity = allVis ? "1" : allHid ? "0.3" : "0.6";
        }

        const objChildContainer = document.createElement("div");
        objChildContainer.className = "layer-group-children";
        if (!objectTypesExpanded) {
            objChildContainer.style.maxHeight = "0";
        }

        objChevron.addEventListener("click", (e) => {
            e.stopPropagation();
            if (objectTypesExpanded) {
                objectTypesExpanded = false;
                objChevron.textContent = "\u25B8";
                objChildContainer.style.maxHeight = objChildContainer.scrollHeight + "px";
                requestAnimationFrame(() => {
                    objChildContainer.style.maxHeight = "0";
                });
            } else {
                objectTypesExpanded = true;
                objChevron.textContent = "\u25BE";
                objChildContainer.style.maxHeight = objChildContainer.scrollHeight + "px";
                const onEnd = () => {
                    objChildContainer.style.maxHeight = "";
                    objChildContainer.removeEventListener("transitionend", onEnd);
                };
                objChildContainer.addEventListener("transitionend", onEnd);
            }
        });

        const updateTextShapesGroupVisual = (row: HTMLElement) => {
            const allVis = TEXT_SHAPES_FILTER_IDS.every((id) => editor.isLayerVisible(id));
            const allHid = TEXT_SHAPES_FILTER_IDS.every((id) => !editor.isLayerVisible(id));
            row.style.opacity = allVis ? "1" : allHid ? "0.3" : "0.6";
        };

        const updateObjectRows = (textShapesGroupRow: HTMLElement) => {
            for (const [id, row] of objectRows.entries()) {
                updateRowVisual(row, editor.isLayerVisible(id));
            }
            updateTextShapesGroupVisual(textShapesGroupRow);
            updateObjGroupVisual();
        };

        objGroupRow.addEventListener("click", () => {
            const allVis = OBJECT_TYPE_IDS.every((id) => editor.isLayerVisible(id));
            editor.setLayersVisible([...OBJECT_TYPE_IDS], !allVis);
            updateObjectRows(textShapesGroupRow);
        });

        for (const objType of OBJECT_ROOT_FILTERS) {
            const row = document.createElement("div");
            row.className = "layer-row";
            const swatch = document.createElement("span");
            swatch.className = "layer-swatch";
            swatch.style.background = objType.color;
            const label = document.createElement("span");
            label.textContent = objType.label;
            row.appendChild(swatch);
            row.appendChild(label);
            updateRowVisual(row, editor.isLayerVisible(objType.id));
            row.addEventListener("click", () => {
                const vis = !editor.isLayerVisible(objType.id);
                editor.setLayerVisible(objType.id, vis);
                updateObjectRows(textShapesGroupRow);
            });
            objectRows.set(objType.id, row);
            objChildContainer.appendChild(row);
        }

        const textShapesGroupRow = document.createElement("div");
        textShapesGroupRow.className = "layer-group-header";
        const textShapesChevron = document.createElement("span");
        textShapesChevron.className = "layer-chevron";
        textShapesChevron.textContent = textShapesExpanded ? "\u25BE" : "\u25B8";
        const textShapesSwatch = document.createElement("span");
        textShapesSwatch.className = "layer-swatch";
        textShapesSwatch.style.background = "linear-gradient(135deg, #4a8cad 50%, #356982 50%)";
        const textShapesLabel = document.createElement("span");
        textShapesLabel.className = "layer-group-name";
        textShapesLabel.textContent = "Text & Shapes";
        textShapesGroupRow.appendChild(textShapesChevron);
        textShapesGroupRow.appendChild(textShapesSwatch);
        textShapesGroupRow.appendChild(textShapesLabel);

        const textShapesChildContainer = document.createElement("div");
        textShapesChildContainer.className = "layer-group-children";
        if (!textShapesExpanded) {
            textShapesChildContainer.style.maxHeight = "0";
        }

        textShapesChevron.addEventListener("click", (e) => {
            e.stopPropagation();
            if (textShapesExpanded) {
                textShapesExpanded = false;
                textShapesChevron.textContent = "\u25B8";
                textShapesChildContainer.style.maxHeight = textShapesChildContainer.scrollHeight + "px";
                requestAnimationFrame(() => {
                    textShapesChildContainer.style.maxHeight = "0";
                });
            } else {
                textShapesExpanded = true;
                textShapesChevron.textContent = "\u25BE";
                textShapesChildContainer.style.maxHeight = textShapesChildContainer.scrollHeight + "px";
                const onEnd = () => {
                    textShapesChildContainer.style.maxHeight = "";
                    textShapesChildContainer.removeEventListener("transitionend", onEnd);
                };
                textShapesChildContainer.addEventListener("transitionend", onEnd);
            }
        });

        textShapesGroupRow.addEventListener("click", () => {
            const allVis = TEXT_SHAPES_FILTER_IDS.every((id) => editor.isLayerVisible(id));
            editor.setLayersVisible([...TEXT_SHAPES_FILTER_IDS], !allVis);
            updateObjectRows(textShapesGroupRow);
        });

        for (const objType of TEXT_SHAPES_FILTERS) {
            const row = document.createElement("div");
            row.className = "layer-row";
            const swatch = document.createElement("span");
            swatch.className = "layer-swatch";
            swatch.style.background = objType.color;
            const label = document.createElement("span");
            label.textContent = objType.label;
            row.appendChild(swatch);
            row.appendChild(label);
            row.addEventListener("click", () => {
                const vis = !editor.isLayerVisible(objType.id);
                editor.setLayerVisible(objType.id, vis);
                updateObjectRows(textShapesGroupRow);
            });
            objectRows.set(objType.id, row);
            textShapesChildContainer.appendChild(row);
        }

        objChildContainer.appendChild(textShapesGroupRow);
        objChildContainer.appendChild(textShapesChildContainer);
        updateObjectRows(textShapesGroupRow);

        content.appendChild(objGroupRow);
        content.appendChild(objChildContainer);

        const layers = editor.getLayerModels();
        const layerById = new Map(layers.map((layer) => [layer.id, layer]));
        const { groups, topLevel } = groupLayers(layers);

        for (const group of groups) {
            const childNames = group.layers.map((l) => l.id);
            const isCollapsed = collapsedGroups.has(group.group);
            const groupRow = document.createElement("div");
            groupRow.className = "layer-group-header";

            const chevron = document.createElement("span");
            chevron.className = "layer-chevron";
            chevron.textContent = isCollapsed ? "\u25B8" : "\u25BE";

            const primaryColor = colorToCSS(childNames[0]!, layerById);
            const swatch = createSwatch(primaryColor);
            const label = document.createElement("span");
            label.className = "layer-group-name";
            label.textContent = group.group;

            groupRow.appendChild(chevron);
            groupRow.appendChild(swatch);
            groupRow.appendChild(label);
            updateGroupVisual(editor, groupRow, childNames);

            groupRow.addEventListener("click", () => {
                const allVisible = childNames.every((l) => editor.isLayerVisible(l));
                editor.setLayersVisible(childNames, !allVisible);
                updateGroupVisual(editor, groupRow, childNames);
                const childContainer = groupRow.nextElementSibling as HTMLElement | null;
                if (childContainer) {
                    const rows = childContainer.querySelectorAll<HTMLElement>(".layer-row");
                    rows.forEach((row, i) => {
                        updateRowVisual(row, editor.isLayerVisible(childNames[i]!));
                    });
                }
            });

            chevron.addEventListener("click", (e) => {
                e.stopPropagation();
                const childContainer = groupRow.nextElementSibling as HTMLElement | null;
                if (!childContainer) return;
                if (collapsedGroups.has(group.group)) {
                    collapsedGroups.delete(group.group);
                    chevron.textContent = "\u25BE";
                    childContainer.style.maxHeight = childContainer.scrollHeight + "px";
                    const onEnd = () => {
                        childContainer.style.maxHeight = "";
                        childContainer.removeEventListener("transitionend", onEnd);
                    };
                    childContainer.addEventListener("transitionend", onEnd);
                } else {
                    collapsedGroups.add(group.group);
                    chevron.textContent = "\u25B8";
                    childContainer.style.maxHeight = childContainer.scrollHeight + "px";
                    requestAnimationFrame(() => {
                        childContainer.style.maxHeight = "0";
                    });
                }
            });

            content.appendChild(groupRow);

            const childContainer = document.createElement("div");
            childContainer.className = "layer-group-children";
            if (isCollapsed) {
                childContainer.style.maxHeight = "0";
            }

            for (const child of group.layers) {
                const row = document.createElement("div");
                row.className = "layer-row";
                const childSwatch = createSwatch(colorToCSS(child.id, layerById));
                const childLabel = document.createElement("span");
                childLabel.textContent = child.label ?? child.id;
                row.appendChild(childSwatch);
                row.appendChild(childLabel);
                updateRowVisual(row, editor.isLayerVisible(child.id));
                row.addEventListener("click", () => {
                    const vis = !editor.isLayerVisible(child.id);
                    editor.setLayerVisible(child.id, vis);
                    updateRowVisual(row, vis);
                    updateGroupVisual(editor, groupRow, childNames);
                });
                childContainer.appendChild(row);
            }

            content.appendChild(childContainer);
        }

        for (const layer of topLevel) {
            const row = document.createElement("div");
            row.className = "layer-row layer-top-level";
            const swatch = createSwatch(colorToCSS(layer.id, layerById));
            const label = document.createElement("span");
            label.textContent = layer.label ?? layer.id;
            row.appendChild(swatch);
            row.appendChild(label);
            updateRowVisual(row, editor.isLayerVisible(layer.id));
            row.addEventListener("click", () => {
                const vis = !editor.isLayerVisible(layer.id);
                editor.setLayerVisible(layer.id, vis);
                updateRowVisual(row, vis);
            });
            content.appendChild(row);
        }

        panel.appendChild(content);

        if (panelCollapsed) {
            panel.classList.add("collapsed");
            expandTab!.classList.add("visible");
        }
    }

    function attachGridSettings(): void {
        if (!statusEl) return;
        const gridSizes = [0.05, 0.1, 0.2, 0.25, 0.5, 1, 1.27, 2.54];
        let gridSize: number | null = 0.25;
        let settingsPopup: HTMLElement | null = null;

        const settingsBtn = document.createElement("span");
        settingsBtn.id = "settings-btn";
        settingsBtn.title = "Grid settings";
        settingsBtn.textContent = "\u2699";

        editor.setSnapDelta((dx, dy) => {
            if (gridSize === null) return { dx, dy };
            return {
                dx: Math.round(dx / gridSize) * gridSize,
                dy: Math.round(dy / gridSize) * gridSize,
            };
        });

        statusEl.insertBefore(settingsBtn, statusEl.firstChild);
        cleanupFns.push(() => settingsBtn.remove());

        settingsBtn.addEventListener("click", (e) => {
            e.stopPropagation();
            if (settingsPopup) {
                settingsPopup.remove();
                settingsPopup = null;
                return;
            }

            settingsPopup = document.createElement("div");
            settingsPopup.className = "settings-popup";
            const label = document.createElement("div");
            label.className = "settings-label-title";
            label.textContent = "Grid snap";
            settingsPopup.appendChild(label);

            const btnRow = document.createElement("div");
            btnRow.className = "settings-source-buttons";
            const allOptions: { label: string; value: number | null }[] = [
                { label: "OFF", value: null },
                ...gridSizes.map((s) => ({ label: String(s), value: s })),
            ];
            const buttons: HTMLButtonElement[] = [];
            for (const opt of allOptions) {
                const btn = document.createElement("button");
                btn.className = "source-btn";
                if (gridSize === opt.value) btn.classList.add("active");
                btn.textContent = opt.label;
                btn.addEventListener("click", () => {
                    gridSize = opt.value;
                    for (const b of buttons) b.classList.remove("active");
                    btn.classList.add("active");
                });
                buttons.push(btn);
                btnRow.appendChild(btn);
            }

            settingsPopup.appendChild(btnRow);
            document.body.appendChild(settingsPopup);

            const removeListeners = () => {
                document.removeEventListener("mousedown", closeOnOutside);
                document.removeEventListener("keydown", closeOnEsc);
            };
            const closeOnOutside = (ev: MouseEvent) => {
                if (
                    settingsPopup
                    && !settingsPopup.contains(ev.target as Node)
                    && ev.target !== settingsBtn
                    && !settingsBtn.contains(ev.target as Node)
                ) {
                    settingsPopup.remove();
                    settingsPopup = null;
                    removeListeners();
                }
            };
            const closeOnEsc = (ev: KeyboardEvent) => {
                if (ev.key === "Escape" && settingsPopup) {
                    settingsPopup.remove();
                    settingsPopup = null;
                    removeListeners();
                }
            };
            document.addEventListener("mousedown", closeOnOutside);
            document.addEventListener("keydown", closeOnEsc);
        });
    }

    function attachStatusBar(): void {
        if (helpEl) {
            helpEl.textContent = readOnly ? READ_ONLY_HELP_TEXT : HELP_TEXT;
        }

        const onMouseEnter = () => {
            if (coordsEl) coordsEl.dataset.hover = "1";
        };
        const onMouseLeave = () => {
            if (coordsEl) {
                delete coordsEl.dataset.hover;
                coordsEl.textContent = "";
            }
        };

        canvas.addEventListener("mouseenter", onMouseEnter);
        canvas.addEventListener("mouseleave", onMouseLeave);
        cleanupFns.push(() => {
            canvas.removeEventListener("mouseenter", onMouseEnter);
            canvas.removeEventListener("mouseleave", onMouseLeave);
        });

        editor.setOnMouseMove((x, y) => {
            if (coordsEl && coordsEl.dataset.hover) {
                coordsEl.textContent = `X: ${x.toFixed(2)}  Y: ${y.toFixed(2)}`;
            }
        });
        editor.setOnActionBusyChanged((busy) => {
            if (!busyEl) return;
            busyEl.classList.toggle("visible", busy);
            busyEl.setAttribute("aria-hidden", busy ? "false" : "true");
        });
    }

    function startFpsCounter(): void {
        if (!fpsEl) return;
        let frames = 0;
        let lastTime = performance.now();
        const tick = () => {
            if (disposed) return;
            frames += 1;
            const now = performance.now();
            if (now - lastTime >= 1000) {
                fpsEl.textContent = `${frames} fps`;
                frames = 0;
                lastTime = now;
            }
            fpsAnimationId = requestAnimationFrame(tick);
        };
        fpsAnimationId = requestAnimationFrame(tick);
    }

    if (!readOnly) {
        attachGridSettings();
    }
    attachStatusBar();
    startFpsCounter();

    setLoadingState(initialLoadingEl, "Loading PCB", "Building scene geometry...");
    void editor.init().then(() => {
        if (disposed) return;
        logger?.info?.("Layout viewer initialized successfully.");
        if (!readOnly) {
            buildLayerPanel();
            editor.setOnLayersChanged(buildLayerPanel);
        }
        hideLoadingState(initialLoadingEl);
    }).catch((err) => {
        if (disposed) return;
        logger?.error?.(`Failed to initialize editor: ${formatErrorDetail(err)}`);
        setLoadingState(initialLoadingEl, "Load failed", "Could not initialize PCB viewer.", true);
    });

    return {
        editor,
        dispose() {
            if (disposed) return;
            disposed = true;
            if (fpsAnimationId !== null) {
                cancelAnimationFrame(fpsAnimationId);
            }
            editor.setOnLayersChanged(() => {});
            editor.setOnMouseMove(() => {});
            editor.setOnActionBusyChanged(() => {});
            for (const cleanup of cleanupFns) {
                cleanup();
            }
            editor.dispose();
        },
    };
}
