import { useEffect, useState } from "react";
import type { ResolvedBuildTarget } from "../../protocol/generated-types";
import { samePath } from "../../protocol/paths";
import { render } from "../common/render";
import { WebviewRpcClient, rpcClient } from "../common/webviewRpcClient";
import { createWebviewLogger } from "../common/logger";
import { ThreeDPreview } from "./threeDPreviewManager";
import "./panel-3d.css";

const logger = createWebviewLogger("Panel3D");

type ThreeDModel = {
  exists: boolean;
  modelPath: string;
  modelUri: string;
};

type PanelState =
  | { kind: "message"; text: string }
  | { kind: "loading"; text: string }
  | { kind: "ready"; model: ThreeDModel };

function getPanelState(options: {
  hasSelection: boolean;
  hasLayout: boolean;
  buildInProgress: boolean;
  layoutError: unknown;
  model: ThreeDModel | null;
  error: string | null;
}): PanelState {
  const {
    hasSelection,
    hasLayout,
    buildInProgress,
    layoutError,
    model,
    error,
  } = options;

  if (!hasSelection) {
    return {
      kind: "message",
      text: "Select a project and build target to generate a GLB preview.",
    };
  }
  if (layoutError) {
    return { kind: "message", text: String(layoutError) };
  }
  if (!hasLayout) {
    return {
      kind: "message",
      text: buildInProgress
        ? "Build in progress. The 3D preview will appear automatically when the PCB layout is available."
        : "Run a build to generate the PCB layout first. The 3D preview will update automatically after that.",
    };
  }
  if (model?.exists && model.modelUri) {
    return { kind: "ready", model };
  }
  if (error) {
    return { kind: "message", text: error };
  }
  return { kind: "loading", text: "Generating 3D model" };
}

async function waitForModel(
  target: ResolvedBuildTarget,
  options?: {
    attempts?: number;
    delayMs?: number;
  },
): Promise<ThreeDModel> {
  const attempts = options?.attempts ?? 10;
  const delayMs = options?.delayMs ?? 150;
  for (let attempt = 0; attempt < attempts; attempt += 1) {
    const model = await rpcClient!.requestAction<ThreeDModel>("vscode.resolveThreeDModel", {
      target,
    });
    if (model.exists && model.modelUri) {
      return model;
    }
    if (attempt < attempts - 1) {
      await new Promise((resolve) => setTimeout(resolve, delayMs));
    }
  }
  throw new Error(`3D model was not generated at ${target.modelPath}`);
}

function App() {
  const projectState = WebviewRpcClient.useSubscribe("projectState");
  const layoutData = WebviewRpcClient.useSubscribe("layoutData");
  const selectedBuildInProgress = WebviewRpcClient.useSubscribe("selectedBuildInProgress");
  const selectedTarget = projectState.selectedTarget;
  const hasSelection = Boolean(projectState.selectedProjectRoot && selectedTarget);
  const hasLayout = Boolean(
    selectedTarget
    && layoutData.path
    && samePath(layoutData.path, selectedTarget.pcbPath),
  );
  const layoutRevisionKey = selectedTarget && hasLayout
    ? `${selectedTarget.root}::${selectedTarget.name}::${selectedTarget.entry}::${selectedTarget.pcbPath}::${selectedTarget.modelPath}:${layoutData.revision}`
    : "";

  const [model, setModel] = useState<ThreeDModel | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;

    setError(null);
    if (!layoutRevisionKey || !selectedTarget) {
      setIsGenerating(false);
      setModel(null);
      return;
    }

    setError(null);
    setIsGenerating(true);
    setModel(null);
    void rpcClient!.requestAction("generateThreeDModel", { target: selectedTarget })
      .then(() => waitForModel(selectedTarget))
      .then((nextModel) => {
        if (!cancelled) {
          setModel(nextModel);
        }
      })
      .catch((nextError) => {
        logger.error(
          `Failed to generate 3D model: ${nextError instanceof Error ? nextError.message : String(nextError)}`,
        );
        if (!cancelled) {
          setError(nextError instanceof Error ? nextError.message : String(nextError));
        }
      })
      .finally(() => {
        if (!cancelled) {
          setIsGenerating(false);
        }
      });

    return () => {
      cancelled = true;
    };
  }, [layoutRevisionKey, selectedTarget]);

  const panelState = getPanelState({
    hasSelection,
    hasLayout,
    buildInProgress: selectedBuildInProgress,
    layoutError: layoutData.error,
    model,
    error,
  });

  if (panelState.kind !== "ready") {
    return (
      <div className="panel-3d-state">
        {panelState.kind === "loading" && (
          <div className="panel-3d-spinner" aria-label="Loading" />
        )}
        <div className="panel-3d-state-title">3D Model</div>
        <p>{panelState.text}</p>
      </div>
    );
  }

  return (
    <div className="panel-3d-container">
      <ThreeDPreview
        key={layoutRevisionKey}
        modelUri={panelState.model.modelUri}
      />
      {isGenerating && (
        <div className="panel-3d-badge">
          <span className="panel-3d-badge-spinner" />
          <span>Generating...</span>
        </div>
      )}
    </div>
  );
}

render(App);
