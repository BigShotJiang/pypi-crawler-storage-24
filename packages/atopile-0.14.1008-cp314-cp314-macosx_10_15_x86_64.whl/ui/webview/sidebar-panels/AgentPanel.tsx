import { useEffect, useMemo, useRef, useState } from 'react';
import { ChevronDown, Plus, MessageSquareText } from 'lucide-react';
import { AgentComposer } from '../agent/components/AgentComposer';
import { AgentHistoryDrawer } from '../agent/components/AgentHistoryDrawer';
import { AgentMessagesView } from '../agent/components/AgentMessagesView';
import { formatCount, renderLineDelta } from '../agent/components/viewHelpers';
import { useAgentChatRuntime } from '../agent/useAgentChatRuntime';
import { SidebarDockHeader, SidebarDockPanel, SidebarSubpanel, useResizeHandle } from '../common/components';
import type { FileNode, ModuleDefinition } from '../../protocol/generated-types';
import './AgentPanel.css';

interface AgentPanelProps {
  projectRoot: string | null;
  selectedTargets: string[];
  projectModules: ModuleDefinition[];
  projectFileNodes: FileNode[];
}

export function AgentPanel({
  projectRoot,
  selectedTargets,
  projectModules,
  projectFileNodes,
}: AgentPanelProps) {
  const minimizedDockHeight = 54;
  const minDockHeight = 120;
  const defaultDockHeight = useMemo(() => {
    if (typeof window === 'undefined') return 460;
    const maxHeight = Math.floor(window.innerHeight * 0.78);
    return Math.max(minDockHeight, Math.min(520, maxHeight));
  }, []);
  const maxDockHeight = typeof window === 'undefined'
    ? 520
    : Math.max(minDockHeight, Math.floor(window.innerHeight * 0.88));
  const runtime = useAgentChatRuntime(
    projectRoot,
    selectedTargets,
    projectModules,
    projectFileNodes,
  );
  const [isChatsPanelOpen, setIsChatsPanelOpen] = useState(false);
  const [dockHeight, setDockHeight] = useState(defaultDockHeight);
  const [isMinimized, setIsMinimized] = useState(false);
  const [changesExpanded, setChangesExpanded] = useState(false);
  const [expandedTraceKeys, setExpandedTraceKeys] = useState<Set<string>>(new Set());
  const messagesRef = useRef<HTMLDivElement | null>(null);
  const chatsPanelRef = useRef<HTMLDivElement | null>(null);
  const chatsPanelToggleRef = useRef<HTMLButtonElement | null>(null);
  const dockResize = useResizeHandle({
    height: dockHeight,
    minHeight: minDockHeight,
    maxHeight: maxDockHeight,
    onHeightChange: setDockHeight,
  });

  useEffect(() => {
    const element = messagesRef.current;
    if (!element) return;
    element.scrollTop = element.scrollHeight;
  }, [runtime.messages]);

  useEffect(() => {
    setChangesExpanded(false);
    setExpandedTraceKeys(new Set());
  }, [runtime.activeChatId]);

  useEffect(() => {
    if (!isChatsPanelOpen) return;
    const onPointerDown = (event: MouseEvent) => {
      const target = event.target as Node | null;
      if (!target) return;
      if (chatsPanelRef.current?.contains(target)) return;
      if (chatsPanelToggleRef.current?.contains(target)) return;
      setIsChatsPanelOpen(false);
    };
    window.addEventListener('mousedown', onPointerDown);
    return () => window.removeEventListener('mousedown', onPointerDown);
  }, [isChatsPanelOpen]);

  return (
    <SidebarDockPanel
      className={`agent-chat-dock ${isMinimized ? 'minimized' : ''}`}
      collapsed={isMinimized}
      collapsedHeight={minimizedDockHeight}
      height={dockHeight}
      maxHeight="88vh"
      resizing={dockResize.isResizing}
      resizeHandleProps={dockResize.resizeHandleProps}
    >
      <SidebarSubpanel className="agent-chat-panel">
        <SidebarDockHeader
          className="agent-chat-header"
          title={runtime.headerTitle}
          subtitle={(
            <span className="agent-chat-thread-row">
              <span className="agent-chat-thread-title" title={runtime.activeChatTitle}>
                {runtime.activeChatTitle}
              </span>
              <span
                className={`agent-chat-thread-status ${runtime.statusClass}`}
                aria-label={`Status: ${runtime.statusText}`}
                title={`Status: ${runtime.statusText}`}
              >
                <span className="agent-chat-thread-dot" />
              </span>
            </span>
          )}
          actions={(
            <>
              <button
                ref={chatsPanelToggleRef}
                type="button"
                className={`agent-chat-action ${isChatsPanelOpen ? 'active' : ''}`}
                onClick={() => setIsChatsPanelOpen((current) => !current)}
                disabled={!projectRoot}
                title="Show chat history for this project"
                aria-label="Toggle chat history panel"
              >
                <MessageSquareText size={13} />
              </button>
              <button
                type="button"
                className="agent-chat-action"
                onClick={() => {
                  runtime.startNewChat();
                  setIsChatsPanelOpen(false);
                }}
                disabled={!projectRoot}
                title="Start a new chat session"
                aria-label="Start a new chat session"
              >
                <Plus size={12} />
              </button>
            </>
          )}
          collapsed={isMinimized}
          onToggleCollapsed={() => setIsMinimized((current) => !current)}
        />

        <div
          className={[
            'sidebar-dock-content',
            'sidebar-panel-body',
            'agent-chat-shell',
            isMinimized ? 'collapsed' : '',
          ].filter(Boolean).join(' ')}
          aria-hidden={isMinimized}
        >
          <AgentHistoryDrawer
            projectRoot={projectRoot}
            projectChats={runtime.projectChats}
            activeChatId={runtime.activeChatId}
            isChatsPanelOpen={isChatsPanelOpen}
            chatsPanelRef={chatsPanelRef}
            onClose={() => setIsChatsPanelOpen(false)}
            onStartNewChat={() => {
              runtime.startNewChat();
              setIsChatsPanelOpen(false);
            }}
            onActivateChat={(chatId) => {
              runtime.activateChat(chatId);
              setIsChatsPanelOpen(false);
            }}
          />
          <div className="agent-chat-main">
            <AgentMessagesView
              messagesRef={messagesRef}
              messages={runtime.messages}
              expandedTraceKeys={expandedTraceKeys}
              onToggleTraceExpanded={(traceKey) => {
                setExpandedTraceKeys((previous) => {
                  const next = new Set(previous);
                  if (next.has(traceKey)) next.delete(traceKey);
                  else next.add(traceKey);
                  return next;
                });
              }}
              onSubmitDesignQuestions={(answers) => void runtime.sendMessage({ directMessage: answers, hideUserMessage: true })}
            />
            {runtime.changedFilesSummary && (
              <div className="agent-changes-summary">
                <button
                  type="button"
                  className="agent-changes-toggle"
                  onClick={() => setChangesExpanded((value) => !value)}
                  aria-expanded={changesExpanded}
                >
                  <ChevronDown
                    size={12}
                    className={`agent-changes-chevron ${changesExpanded ? 'open' : ''}`}
                  />
                  <span className="agent-changes-title">
                    {formatCount(runtime.changedFilesSummary.files.length, 'changed file', 'changed files')}
                  </span>
                  <span className="agent-changes-stats">
                    {renderLineDelta(
                      runtime.changedFilesSummary.totalAdded,
                      runtime.changedFilesSummary.totalRemoved,
                      'agent-line-delta-compact',
                    )}
                  </span>
                </button>
                {changesExpanded && (
                  <div className="agent-changes-list">
                    {runtime.changedFilesSummary.files.map((file) => (
                      <button
                        key={file.path}
                        type="button"
                        className="agent-changes-file"
                        onClick={() => runtime.openFileDiff(file)}
                        title={file.path}
                      >
                        <span className="agent-changes-file-path">{file.path}</span>
                        {renderLineDelta(file.added, file.removed, 'agent-line-delta-compact')}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            )}

            <AgentComposer
              composerInputRef={runtime.composerInputRef}
              input={runtime.input}
              mentionToken={runtime.mentionToken}
              mentionItems={runtime.mentionItems}
              mentionIndex={runtime.mentionIndex}
              projectRoot={projectRoot}
              isReady={runtime.isReady}
              isSending={runtime.isSending}
              isStopping={runtime.isStopping}
              compactionNotice={runtime.compactionNotice}
              contextUsage={runtime.contextUsage}
              onInputChange={(nextValue, textarea) => {
                runtime.setInput(nextValue);
                runtime.refreshMentionFromInput(
                  nextValue,
                  textarea.selectionStart ?? nextValue.length,
                );
                textarea.style.height = 'auto';
                textarea.style.height = `${textarea.scrollHeight}px`;
              }}
              onInputClick={runtime.refreshMentionFromInput}
              onInputKeyUp={(key, value, caret) => {
                if (
                  runtime.mentionToken
                  && runtime.mentionItems.length > 0
                  && (
                    key === 'ArrowDown'
                    || key === 'ArrowUp'
                    || key === 'Enter'
                    || key === 'Tab'
                    || key === 'Escape'
                  )
                ) {
                  return;
                }
                runtime.refreshMentionFromInput(value, caret);
              }}
              onKeyDown={(event) => {
                if (runtime.mentionToken && runtime.mentionItems.length > 0) {
                  if (event.key === 'ArrowDown') {
                    event.preventDefault();
                    runtime.setMentionIndex((current) => (current + 1) % runtime.mentionItems.length);
                    return;
                  }
                  if (event.key === 'ArrowUp') {
                    event.preventDefault();
                    runtime.setMentionIndex((current) => (
                      (current - 1 + runtime.mentionItems.length) % runtime.mentionItems.length
                    ));
                    return;
                  }
                  if (event.key === 'Enter' || event.key === 'Tab') {
                    event.preventDefault();
                    runtime.insertMention(runtime.mentionItems[runtime.mentionIndex]);
                    return;
                  }
                  if (event.key === 'Escape') {
                    event.preventDefault();
                    runtime.setMentionToken(null);
                    runtime.setMentionIndex(0);
                    return;
                  }
                }
                if (event.key === 'Enter' && !event.shiftKey) {
                  event.preventDefault();
                  if (runtime.isSending) {
                    void runtime.sendSteeringMessage();
                  } else {
                    void runtime.sendMessage();
                  }
                }
              }}
              onInsertMention={runtime.insertMention}
              onSend={() => {
                if (runtime.isSending) {
                  void runtime.sendSteeringMessage();
                } else {
                  void runtime.sendMessage();
                }
              }}
              onStop={() => {
                void runtime.stopRun();
              }}
            />

            {runtime.error && <div className="agent-chat-error">{runtime.error}</div>}
          </div>
        </div>
      </SidebarSubpanel>
    </SidebarDockPanel>
  );
}
