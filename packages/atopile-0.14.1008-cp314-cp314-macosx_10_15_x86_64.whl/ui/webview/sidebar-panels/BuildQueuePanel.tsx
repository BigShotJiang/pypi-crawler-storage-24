import { useState } from "react";
import { SidebarDockHeader, SidebarDockPanel, SidebarSubpanel, useResizeHandle } from "../common/components";
import { BuildQueueItem } from "../sidebar/BuildQueueItem";
import type { Build, BuildStage } from "../../protocol/generated-types";
import "./BuildQueuePanel.css";

interface BuildQueuePanelProps {
  builds: Array<Build & { currentStage: BuildStage | null }>;
}

export function BuildQueuePanel({ builds }: BuildQueuePanelProps) {
  const [collapsed, setCollapsed] = useState(false);
  const resize = useResizeHandle({ initialHeight: 120, minHeight: 60 });

  return (
    <SidebarDockPanel
      className="build-queue-panel-container"
      collapsed={collapsed}
      collapsedHeight={32}
      height={resize.height}
      resizing={resize.isResizing}
      resizeHandleProps={resize.resizeHandleProps}
    >
      <SidebarSubpanel className="build-queue-panel">
        <SidebarDockHeader
          title="Build Queue"
          badge={builds.length > 0 ? builds.length : undefined}
          collapsed={collapsed}
          onToggleCollapsed={() => setCollapsed((value) => !value)}
        />
        <div
          className={["sidebar-dock-content", collapsed ? "collapsed" : ""].filter(Boolean).join(" ")}
          aria-hidden={collapsed}
        >
          <div className="sidebar-panel-scroll">
            {builds.length === 0 ? (
              <div className="build-queue-empty">No recent builds</div>
            ) : (
              builds.map((build) => (
                <BuildQueueItem
                  key={build.buildId ?? build.name}
                  build={build}
                />
              ))
            )}
          </div>
        </div>
      </SidebarSubpanel>
    </SidebarDockPanel>
  );
}
