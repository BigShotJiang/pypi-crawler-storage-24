import { memo, useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  AlertTriangle,
  Check,
  ChevronDown,
  ChevronRight,
  Copy,
  ExternalLink,
  Package,
  RefreshCw,
} from "lucide-react";
import { Alert, AlertTitle, AlertDescription, CopyableCodeBlock, EmptyState, PanelSearchBox } from "../common/components";
import { WebviewRpcClient, rpcClient } from "../common/webviewRpcClient";
import type { UiBOMComponent, UiLcscPartData } from "../../protocol/generated-types";
import { joinPath, samePath } from "../../protocol/paths";
import "./BOMPanel.css";

interface UsageLocation {
  path: string;
  designator: string;
  line?: number;
}

interface UsageGroup {
  parentPath: string;
  parentLabel: string;
  instances: UsageLocation[];
}

interface BOMComponentUI {
  id: string;
  type: string;
  value: string;
  package: string;
  manufacturer?: string;
  mpn?: string;
  lcsc?: string;
  description?: string;
  quantity: number;
  unitCost?: number;
  totalCost?: number;
  inStock?: boolean;
  stockQuantity?: number;
  isBasic?: boolean;
  isPreferred?: boolean;
  lcscLoading?: boolean;
  parameters: UiBOMComponent["parameters"];
  source?: string;
  usages: UsageLocation[];
}



function normalizeUsagePath(path: string): string {
  const parts = path.split("::");
  const addressPart = parts.length > 1 ? parts[1] : path;
  return addressPart.split("|")[0] ?? addressPart;
}

function getUsageDisplayPath(path: string): string {
  const normalized = normalizeUsagePath(path);
  const segments = normalized.split(".");
  if (segments.length <= 1) {
    return normalized;
  }
  return segments.slice(1).join(".");
}

function resolveUsageFilePath(projectRoot: string | null, path: string): string | null {
  if (!path) {
    return null;
  }
  const primary = path.split("|")[0] ?? path;
  const filePart = primary.split("::")[0] ?? "";
  if (!filePart.endsWith(".ato")) {
    return null;
  }
  if (filePart.startsWith("/") || /^[A-Za-z]:[\\/]/.test(filePart)) {
    return filePart;
  }
  if (!projectRoot) {
    return filePart;
  }
  return joinPath(projectRoot, filePart);
}

function transformBOMComponent(apiComp: UiBOMComponent): BOMComponentUI {
  const unitCost = apiComp.unitCost ?? undefined;
  const totalCost = unitCost !== undefined ? unitCost * apiComp.quantity : undefined;
  const stock = apiComp.stock ?? undefined;

  return {
    id: apiComp.id,
    type: apiComp.type ?? "other",
    value: apiComp.value || apiComp.description || apiComp.mpn || apiComp.manufacturer || "-",
    package: apiComp.package,
    manufacturer: apiComp.manufacturer || undefined,
    mpn: apiComp.mpn || undefined,
    lcsc: apiComp.lcsc || undefined,
    description: apiComp.description || undefined,
    quantity: apiComp.quantity,
    unitCost,
    totalCost,
    inStock: stock != null ? stock > 0 : undefined,
    stockQuantity: stock,
    isBasic: apiComp.isBasic ?? undefined,
    isPreferred: apiComp.isPreferred ?? undefined,
    parameters: apiComp.parameters,
    source: apiComp.source || undefined,
    usages: apiComp.usages.map((usage) => ({
      path: usage.address,
      designator: usage.designator,
      line: usage.line ?? undefined,
    })),
  };
}

function getTypeLabel(type: string): string {
  switch (type) {
    case "resistor": return "R";
    case "capacitor": return "C";
    case "inductor": return "L";
    case "ic": return "IC";
    case "connector": return "J";
    case "led": return "LED";
    case "diode": return "D";
    case "transistor": return "Q";
    case "crystal": return "Y";
    default: return "X";
  }
}

function formatCurrency(value: number): string {
  if (value < 0.01) {
    return `$${value.toFixed(4)}`;
  }
  if (value < 1) {
    return `$${value.toFixed(3)}`;
  }
  return `$${value.toFixed(2)}`;
}

function groupUsagesByModule(usages: UsageLocation[]): UsageGroup[] {
  const groups = new Map<string, UsageGroup>();

  for (const usage of usages) {
    const normalizedPath = normalizeUsagePath(usage.path);
    const segments = normalizedPath.split(".");

    let parentPath: string;
    let parentLabel: string;

    if (segments.length >= 3) {
      parentPath = segments.slice(0, -1).join(".");
      parentLabel = segments[segments.length - 2] ?? normalizedPath;
    } else if (segments.length === 2) {
      parentPath = segments[0] ?? normalizedPath;
      parentLabel = segments[0] ?? normalizedPath;
    } else {
      parentPath = normalizedPath;
      parentLabel = normalizedPath;
    }

    const group = groups.get(parentPath) ?? {
      parentPath,
      parentLabel,
      instances: [],
    };
    group.instances.push(usage);
    groups.set(parentPath, group);
  }

  return Array.from(groups.values());
}

function formatStock(stock: number): string {
  if (stock >= 1_000_000) {
    return `${(stock / 1_000_000).toFixed(1)}M`;
  }
  if (stock >= 1_000) {
    return `${(stock / 1_000).toFixed(0)}K`;
  }
  return stock.toString();
}

const BOMRow = memo(function BOMRow({
  component,
  isExpanded,
  onToggle,
  onCopy,
  onGoToSource,
}: {
  component: BOMComponentUI;
  isExpanded: boolean;
  onToggle: () => void;
  onCopy: (text: string) => void;
  onGoToSource: (path: string, line?: number) => void;
}) {
  const [copiedField, setCopiedField] = useState<string | null>(null);
  const [expandedGroups, setExpandedGroups] = useState<Set<string>>(() => new Set());

  const handleCopy = (field: string, value: string, event: React.MouseEvent) => {
    event.stopPropagation();
    onCopy(value);
    setCopiedField(field);
    window.setTimeout(() => setCopiedField(null), 1500);
  };

  const handleUsageClick = (event: React.MouseEvent, usage: UsageLocation) => {
    event.stopPropagation();
    onGoToSource(usage.path, usage.line);
  };

  const toggleGroup = (groupPath: string, event: React.MouseEvent) => {
    event.stopPropagation();
    setExpandedGroups((prev) => {
      const next = new Set(prev);
      if (next.has(groupPath)) {
        next.delete(groupPath);
      } else {
        next.add(groupPath);
      }
      return next;
    });
  };

  const usageGroups = component.usages.length > 0 ? groupUsagesByModule(component.usages) : [];

  return (
    <div className={`bom-row ${isExpanded ? "expanded" : ""}`} onClick={onToggle}>
      <div className="bom-row-header">
        <span className="bom-expand">
          {isExpanded ? <ChevronDown size={12} /> : <ChevronRight size={12} />}
        </span>
        <span className={`bom-type-badge type-${component.type}`}>{getTypeLabel(component.type)}</span>
        <span className="bom-value">{component.value}</span>
        {component.mpn && (
          <span className="bom-mpn" title={component.mpn}>
            {component.mpn}
          </span>
        )}
        <span className="bom-quantity">x{component.quantity}</span>
        {component.totalCost !== undefined && (
          <span className="bom-cost">{formatCurrency(component.totalCost)}</span>
        )}
        {component.inStock === false && <AlertTriangle size={12} className="bom-stock-warning" />}
      </div>

      {isExpanded && (
        <div className="bom-row-details">
          <table className="bom-detail-table">
            <tbody>
              <tr>
                <td className="detail-cell-label">Manufacturer</td>
                <td className="detail-cell-value">{component.manufacturer || "-"}</td>
              </tr>
              <tr>
                <td className="detail-cell-label">Package</td>
                <td className="detail-cell-value">{component.package || "-"}</td>
              </tr>
              <tr>
                <td className="detail-cell-label">LCSC</td>
                <td className="detail-cell-value">
                  {component.lcsc ? (
                    <span
                      className="lcsc-link"
                      onClick={(event) => handleCopy("lcsc", component.lcsc!, event)}
                    >
                      <span className="mono">{component.lcsc}</span>
                      <button
                        type="button"
                        className="external-link"
                        onClick={(event) => {
                          event.stopPropagation();
                          window.open(
                            `https://www.lcsc.com/product-detail/${component.lcsc}.html`,
                            "_blank",
                            "noopener,noreferrer",
                          );
                        }}
                        aria-label="Open LCSC part in browser"
                      >
                        <ExternalLink size={10} />
                      </button>
                      {copiedField === "lcsc" ? (
                        <Check size={10} className="copy-icon copied" />
                      ) : (
                        <Copy size={10} className="copy-icon" />
                      )}
                    </span>
                  ) : "-"}
                </td>
              </tr>
              <tr>
                <td className="detail-cell-label">Stock</td>
                <td className={`detail-cell-value ${component.inStock === false ? "out-of-stock" : "in-stock"}`}>
                  {component.inStock === false ? (
                    <span className="stock-out">
                      <AlertTriangle size={10} />
                      Out of stock
                    </span>
                  ) : component.lcscLoading && component.stockQuantity == null ? (
                    <span className="inline-loading">
                      <RefreshCw size={10} className="loading-spinner" />
                      Fetching...
                    </span>
                  ) : component.stockQuantity != null ? (
                    formatStock(component.stockQuantity)
                  ) : (
                    "In stock"
                  )}
                </td>
              </tr>
              <tr>
                <td className="detail-cell-label">Unit Cost</td>
                <td className="detail-cell-value cost">
                  {component.unitCost != null ? (
                    formatCurrency(component.unitCost)
                  ) : component.lcscLoading ? (
                    <span className="inline-loading">
                      <RefreshCw size={10} className="loading-spinner" />
                      Fetching...
                    </span>
                  ) : (
                    "-"
                  )}
                </td>
              </tr>
              <tr>
                <td className="detail-cell-label">Source</td>
                <td className="detail-cell-value">
                  <span className={`source-badge source-${component.source ?? "manual"}`}>
                    {component.source === "picked"
                      ? "Auto-picked"
                      : component.source === "specified"
                        ? "Specified"
                        : "Manual"}
                  </span>
                </td>
              </tr>
            </tbody>
          </table>

          {usageGroups.length > 0 && (
            <div className="bom-usages-tree">
              <div className="usages-header">
                <span>Used in design</span>
                <span className="usages-count">
                  {component.quantity} instance{component.quantity !== 1 ? "s" : ""}
                </span>
              </div>
              <div className="usage-groups">
                {usageGroups.map((group) => (
                  <div key={group.parentPath} className="usage-group">
                    {group.instances.length > 1 ? (
                      <>
                        <div
                          className="usage-group-header"
                          onClick={(event) => toggleGroup(group.parentPath, event)}
                        >
                          <span className="usage-expand">
                            {expandedGroups.has(group.parentPath) ? (
                              <ChevronDown size={11} />
                            ) : (
                              <ChevronRight size={11} />
                            )}
                          </span>
                          <span className="usage-module-name">{group.parentLabel}</span>
                          <span className="usage-count-badge">x{group.instances.length}</span>
                        </div>
                        {expandedGroups.has(group.parentPath) && (
                          <div className="usage-instances">
                            {group.instances.map((usage, index) => (
                              <div
                                key={`${usage.path}-${index}`}
                                className="usage-instance"
                                onClick={(event) => handleUsageClick(event, usage)}
                                title={usage.path}
                              >
                                <span className="usage-designator">{usage.designator}</span>
                                <span className="usage-leaf">{getUsageDisplayPath(usage.path)}</span>
                                <ExternalLink size={9} className="usage-goto" />
                              </div>
                            ))}
                          </div>
                        )}
                      </>
                    ) : (
                      <div
                        className="usage-single"
                        onClick={(event) => handleUsageClick(event, group.instances[0]!)}
                        title={group.instances[0]!.path}
                      >
                        <span className="usage-designator">{group.instances[0]!.designator}</span>
                        <span className="usage-module-path">
                          {getUsageDisplayPath(group.instances[0]!.path)}
                        </span>
                        <ExternalLink size={10} className="usage-goto" />
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
});

export function BOMPanel() {
  const projectState = WebviewRpcClient.useSubscribe("projectState");
  const bomData = WebviewRpcClient.useSubscribe("bomData");
  const currentBuilds = WebviewRpcClient.useSubscribe("currentBuilds");
  const buildsByProjectData = WebviewRpcClient.useSubscribe("buildsByProjectData");
  const lcscPartsData = WebviewRpcClient.useSubscribe("lcscPartsData");
  const [searchQuery, setSearchQuery] = useState("");
  const [expandedIds, setExpandedIds] = useState<Set<string>>(new Set());
  const [copiedValue, setCopiedValue] = useState<string | null>(null);
  const [forceRefreshBuildId, setForceRefreshBuildId] = useState<string | null>(null);
  const lastLcscRefreshBuildIdRef = useRef<string | null>(null);

  const refreshBom = useCallback(() => {
    if (!projectState.selectedProjectRoot) {
      return;
    }
    rpcClient?.sendAction("getBom", {
      projectRoot: projectState.selectedProjectRoot,
      target: projectState.selectedTarget,
    });
  }, [projectState.selectedProjectRoot, projectState.selectedTarget]);

  useEffect(() => {
    setExpandedIds(new Set());
    setForceRefreshBuildId(null);
    lastLcscRefreshBuildIdRef.current = null;
    refreshBom();
  }, [refreshBom]);

  useEffect(() => {
    if (
      projectState.selectedProjectRoot &&
      currentBuilds.every((build) => build.status !== "building" && build.status !== "queued")
    ) {
      refreshBom();
    }
  }, [currentBuilds, projectState.selectedProjectRoot, refreshBom]);

  useEffect(() => {
    if (!projectState.selectedProjectRoot) {
      return;
    }
    rpcClient?.sendAction("getBuildsByProject", {
      projectRoot: projectState.selectedProjectRoot,
      target: projectState.selectedTarget,
      limit: 1,
    });
  }, [projectState.selectedProjectRoot, projectState.selectedTarget]);

  const latestBuildInfo = useMemo(
    () =>
      samePath(buildsByProjectData.projectRoot, projectState.selectedProjectRoot)
        ? buildsByProjectData.builds[0] ?? null
        : null,
    [buildsByProjectData, projectState.selectedProjectRoot],
  );

  useEffect(() => {
    const buildId = latestBuildInfo?.buildId;
    const startedAt = latestBuildInfo?.startedAt;
    if (!buildId || !startedAt) {
      return;
    }
    const completedAt = startedAt + (latestBuildInfo?.elapsedSeconds ?? 0);
    const ageSeconds = Date.now() / 1000 - completedAt;
    if (ageSeconds <= 24 * 60 * 60) {
      return;
    }
    if (lastLcscRefreshBuildIdRef.current === buildId) {
      return;
    }
    setForceRefreshBuildId(buildId);
  }, [latestBuildInfo]);

  const lcscIds = useMemo(() => {
    const ids = new Set<string>();
    for (const component of bomData.components) {
      if (component.lcsc) {
        ids.add(component.lcsc);
      }
    }
    return Array.from(ids);
  }, [bomData.components]);

  const lcscIdsToFetch = useMemo(() => {
    const ids = new Set<string>();
    for (const component of bomData.components) {
      if (!component.lcsc) {
        continue;
      }
      if (component.unitCost != null && component.stock != null) {
        continue;
      }
      ids.add(component.lcsc);
    }
    return Array.from(ids);
  }, [bomData.components]);

  useEffect(() => {
    const forceRefresh = !!forceRefreshBuildId;
    const idsToRequest = forceRefresh ? lcscIds : lcscIdsToFetch;
    if (!projectState.selectedProjectRoot || idsToRequest.length === 0) {
      return;
    }
    const lcscParts =
      samePath(lcscPartsData.projectRoot, projectState.selectedProjectRoot)
        ? lcscPartsData.parts
        : {};
    const lcscLoadingIds = new Set(
      samePath(lcscPartsData.projectRoot, projectState.selectedProjectRoot)
        ? lcscPartsData.loadingIds
        : [],
    );
    const missing = forceRefresh
      ? idsToRequest
      : idsToRequest.filter((id) => !(id in lcscParts) && !lcscLoadingIds.has(id));
    if (missing.length === 0) {
      return;
    }
    rpcClient?.sendAction("fetchLcscParts", {
      lcscIds: missing,
      projectRoot: projectState.selectedProjectRoot,
      target: projectState.selectedTarget,
    });
    if (forceRefresh && latestBuildInfo?.buildId) {
      lastLcscRefreshBuildIdRef.current = latestBuildInfo.buildId;
      setForceRefreshBuildId(null);
    }
  }, [
    forceRefreshBuildId,
    latestBuildInfo?.buildId,
    lcscIds,
    lcscIdsToFetch,
    lcscPartsData,
    projectState.selectedProjectRoot,
    projectState.selectedTarget,
  ]);

  const lcscParts = useMemo<Record<string, UiLcscPartData | null>>(
    () =>
      samePath(lcscPartsData.projectRoot, projectState.selectedProjectRoot)
        ? lcscPartsData.parts
        : {},
    [lcscPartsData, projectState.selectedProjectRoot],
  );
  const lcscLoadingIds = useMemo(
    () =>
      new Set(
        samePath(lcscPartsData.projectRoot, projectState.selectedProjectRoot)
          ? lcscPartsData.loadingIds
          : [],
      ),
    [lcscPartsData, projectState.selectedProjectRoot],
  );

  const bomComponents = useMemo((): BOMComponentUI[] => {
    return bomData.components.map((component) => {
      const uiComponent = transformBOMComponent(component);
      if (!component.lcsc) {
        return uiComponent;
      }

      const lcscInfo = lcscParts[component.lcsc];
      uiComponent.lcscLoading = lcscLoadingIds.has(component.lcsc);
      if (!lcscInfo) {
        return uiComponent;
      }

      if (uiComponent.unitCost == null && lcscInfo.unitCost != null) {
        uiComponent.unitCost = lcscInfo.unitCost;
        uiComponent.totalCost = lcscInfo.unitCost * uiComponent.quantity;
      }
      if (uiComponent.inStock == null && lcscInfo.stock != null) {
        uiComponent.inStock = lcscInfo.stock > 0;
        uiComponent.stockQuantity = lcscInfo.stock;
      }
      if (!uiComponent.description && lcscInfo.description) {
        uiComponent.description = lcscInfo.description;
      }
      if (!uiComponent.manufacturer && lcscInfo.manufacturer) {
        uiComponent.manufacturer = lcscInfo.manufacturer;
      }
      if (!uiComponent.mpn && lcscInfo.mpn) {
        uiComponent.mpn = lcscInfo.mpn;
      }
      if (uiComponent.isBasic == null && lcscInfo.isBasic != null) {
        uiComponent.isBasic = lcscInfo.isBasic;
      }
      if (uiComponent.isPreferred == null && lcscInfo.isPreferred != null) {
        uiComponent.isPreferred = lcscInfo.isPreferred;
      }

      return uiComponent;
    });
  }, [bomData.components, lcscLoadingIds, lcscParts]);

  const handleToggle = useCallback((id: string) => {
    setExpandedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  }, []);

  const handleCopy = useCallback((value: string) => {
    void navigator.clipboard.writeText(value);
    setCopiedValue(value);
    window.setTimeout(() => setCopiedValue(null), 2000);
  }, []);

  const handleGoToSource = useCallback((address: string, line?: number) => {
    const filePath = resolveUsageFilePath(projectState.selectedProjectRoot, address);
    if (!filePath) {
      return;
    }
    void rpcClient?.requestAction("vscode.openFile", { path: filePath, line });
  }, [projectState.selectedProjectRoot]);

  const filteredComponents = useMemo(() => {
    const searchLower = searchQuery.toLowerCase();
    return bomComponents
      .filter((component) => {
        if (!searchLower) {
          return true;
        }
        return (
          component.value.toLowerCase().includes(searchLower) ||
          component.mpn?.toLowerCase().includes(searchLower) ||
          component.lcsc?.toLowerCase().includes(searchLower) ||
          component.manufacturer?.toLowerCase().includes(searchLower) ||
          component.description?.toLowerCase().includes(searchLower)
        );
      })
      .sort((left, right) => (right.totalCost || 0) - (left.totalCost || 0));
  }, [bomComponents, searchQuery]);

  const EXTENDED_LOADING_FEE = 3;
  const { totalComponents, partsCost, setupFees, extendedPartCount, totalCost, uniqueParts, outOfStock } = useMemo(() => {
    let total = 0;
    let cost = 0;
    let out = 0;
    let extendedParts = 0;

    for (const component of bomComponents) {
      total += component.quantity;
      cost += component.totalCost || 0;
      if (component.inStock === false) {
        out += 1;
      }
      if (component.isBasic !== true && component.isPreferred !== true) {
        extendedParts += 1;
      }
    }

    const setup = extendedParts * EXTENDED_LOADING_FEE;
    return {
      totalComponents: total,
      partsCost: cost,
      setupFees: setup,
      extendedPartCount: extendedParts,
      totalCost: cost + setup,
      uniqueParts: bomComponents.length,
      outOfStock: out,
    };
  }, [bomComponents]);

  const buildIdShort = useMemo(() => {
    if (!bomData.buildId) {
      return null;
    }
    const match = bomData.buildId.match(/^build-(\d+)-/);
    return match ? `#${match[1]}` : bomData.buildId.substring(0, 12);
  }, [bomData.buildId]);

  if (!projectState.selectedProjectRoot) {
    return (
      <EmptyState
        icon={<Package size={24} />}
        title="No project selected"
        description="Select a project to view the Bill of Materials"
      />
    );
  }

  const getEmptyDescription = () => {
    if (projectState.selectedTarget) {
      return `Run a build for "${projectState.selectedTarget.name}" to generate the Bill of Materials`;
    }
    return "Run a build to generate the Bill of Materials";
  };

  if (bomData.loading) {
    return (
      <div className="bom-panel">
        <PanelSearchBox value={searchQuery} onChange={setSearchQuery} placeholder="Search value, MPN..." />
        <div className="bom-loading">
          <RefreshCw size={24} className="loading-spinner" />
          <span>Loading BOM...</span>
        </div>
      </div>
    );
  }

  if (bomData.error) {
    return (
      <div className="bom-panel">
        <PanelSearchBox value={searchQuery} onChange={setSearchQuery} placeholder="Search value, MPN..." />
        <div className="bom-error-container">
          <Alert variant="destructive">
            <AlertTitle>Error loading BOM</AlertTitle>
            <AlertDescription>{bomData.error}</AlertDescription>
            {bomData.errorTraceback && (
              <details className="bom-error-traceback">
                <summary>Traceback</summary>
                <CopyableCodeBlock code={bomData.errorTraceback} label="Traceback" />
              </details>
            )}
          </Alert>
        </div>
      </div>
    );
  }

  if (bomComponents.length === 0) {
    return (
      <div className="bom-panel">
        <PanelSearchBox value={searchQuery} onChange={setSearchQuery} placeholder="Search value, MPN..." />
        <EmptyState title="No BOM data available" description={getEmptyDescription()} />
      </div>
    );
  }

  return (
    <div className="bom-panel">
      <div className="bom-summary">
        <div className="bom-summary-item">
          <span className="summary-value">{uniqueParts}</span>
          <span className="summary-label">unique</span>
        </div>
        <div className="bom-summary-item">
          <span className="summary-value">{totalComponents}</span>
          <span className="summary-label">total</span>
        </div>
        <div className="bom-summary-item">
          <span className="summary-value">{formatCurrency(partsCost)}</span>
          <span className="summary-label">parts</span>
        </div>
        {setupFees > 0 && (
          <div
            className="bom-summary-item"
            title={`${extendedPartCount} extended part${extendedPartCount !== 1 ? "s" : ""} x $${EXTENDED_LOADING_FEE} loading fee`}
          >
            <span className="summary-value">+{formatCurrency(setupFees)}</span>
            <span className="summary-label">setup</span>
          </div>
        )}
        <div className="bom-summary-item primary">
          <span className="summary-value">{formatCurrency(totalCost)}</span>
          <span className="summary-label">total</span>
        </div>
        {outOfStock > 0 && (
          <div className="bom-summary-item warning">
            <AlertTriangle size={12} />
            <span className="summary-value">{outOfStock}</span>
            <span className="summary-label">out of stock</span>
          </div>
        )}
        {buildIdShort && (
          <div className="bom-summary-item muted" title={`Build: ${bomData.buildId}`}>
            <span className="summary-value">{buildIdShort}</span>
            <span className="summary-label">build</span>
          </div>
        )}
      </div>

      <PanelSearchBox value={searchQuery} onChange={setSearchQuery} placeholder="Search value, MPN..." />

      <div className="bom-list">
        {filteredComponents.map((component) => (
          <BOMRow
            key={component.id}
            component={component}
            isExpanded={expandedIds.has(component.id)}
            onToggle={() => handleToggle(component.id)}
            onCopy={handleCopy}
            onGoToSource={handleGoToSource}
          />
        ))}

        {filteredComponents.length === 0 && (
          <div className="bom-empty">
            <Package size={24} />
            <span>No components found</span>
          </div>
        )}
      </div>

      {copiedValue && (
        <div className="bom-toast">
          <Check size={10} />
          Copied: {copiedValue}
        </div>
      )}
    </div>
  );
}
