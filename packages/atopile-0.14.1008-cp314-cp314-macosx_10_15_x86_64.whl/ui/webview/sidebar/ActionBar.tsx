import { useCallback, useEffect, useRef, useState, type ReactElement } from "react";
import { Hammer, Compass, Box, Layout, Factory, RefreshCcw, Table2, GitCompareArrows, ChevronDown } from "lucide-react";
import {
  Button,
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  Spinner,
} from "../common/components";
import { rpcClient } from "../common/webviewRpcClient";
import { createWebviewLogger } from "../common/logger";
import "./ActionBar.css";

const logger = createWebviewLogger("Sidebar");

async function requestPanel(panelId: string): Promise<void> {
  logger.info(`openPanel click panelId=${panelId}`);
  try {
    await rpcClient?.requestAction("vscode.openPanel", { panelId });
    logger.info(`openPanel resolved panelId=${panelId}`);
  } catch (error) {
    logger.error(
      `openPanel failed panelId=${panelId} error=${error instanceof Error ? error.message : String(error)}`,
    );
  }
}

interface ActionItem {
  key: string;
  icon: ReactElement;
  label: string;
  onClick: () => void;
  disabled?: boolean;
  primary?: boolean;
}

interface ActionBarProps {
  onBuild: () => void;
  onOpenKicad: () => void;
  onOpenManufacture: () => void;
  buildDisabled: boolean;
  isBuilding: boolean;
  showMigration: boolean;
  onOpenMigration: () => void;
}

export function ActionBar({
  onBuild,
  onOpenKicad,
  onOpenManufacture,
  buildDisabled,
  isBuilding,
  showMigration,
  onOpenMigration,
}: ActionBarProps) {
  const rowRef = useRef<HTMLDivElement>(null);
  const [visibleCount, setVisibleCount] = useState(Infinity);

  const items: ActionItem[] = [];

  if (showMigration) {
    items.push({
      key: "migrate",
      icon: <RefreshCcw size={12} />,
      label: "Migrate",
      onClick: onOpenMigration,
    });
  }

  items.push(
    {
      key: "build",
      icon: isBuilding ? <Spinner size={12} /> : <Hammer size={12} />,
      label: isBuilding ? "Building" : "Build",
      onClick: onBuild,
      disabled: buildDisabled || isBuilding,
      primary: true,
    },
    {
      key: "kicad",
      icon: <Compass size={12} />,
      label: "KiCad",
      onClick: onOpenKicad,
      disabled: buildDisabled,
    },
    {
      key: "3d",
      icon: <Box size={12} />,
      label: "3D",
      onClick: () => void requestPanel("panel-3d"),
      disabled: buildDisabled,
    },
    {
      key: "layout",
      icon: <Layout size={12} />,
      label: "Layout",
      onClick: () => void requestPanel("panel-layout"),
      disabled: buildDisabled,
    },
    {
      key: "pinout",
      icon: <Table2 size={12} />,
      label: "Pinout",
      onClick: () => void requestPanel("panel-pinout"),
      disabled: buildDisabled,
    },
    {
      key: "manufacture",
      icon: <Factory size={12} />,
      label: "Manufacture",
      onClick: onOpenManufacture,
      disabled: buildDisabled,
    },
  );

  // Min width per button: icon (12) + gap (4) + ~longest label chars + padding
  const BTN_MIN_WIDTH = 80;
  // Width for the chevron-only overflow trigger
  const OVERFLOW_WIDTH = 32;

  const recalc = useCallback(() => {
    const row = rowRef.current;
    if (!row) return;
    const available = row.clientWidth;
    // How many buttons fit? Reserve space for the overflow trigger if we can't fit all.
    let fits = Math.floor(available / BTN_MIN_WIDTH);
    if (fits < items.length) {
      // Need overflow menu — reserve space for its trigger
      fits = Math.max(1, Math.floor((available - OVERFLOW_WIDTH) / BTN_MIN_WIDTH));
    }
    setVisibleCount(fits);
  }, [items.length]);

  useEffect(() => {
    recalc();
    const ro = new ResizeObserver(recalc);
    if (rowRef.current) ro.observe(rowRef.current);
    return () => ro.disconnect();
  }, [recalc]);

  const visible = items.slice(0, visibleCount);
  const overflowed = items.slice(visibleCount);

  return (
    <div className="action-bar-wrapper">
      <div className="build-actions-row" ref={rowRef}>
        {visible.map((item, i) => (
          <ActionButton key={item.key} item={item} showDivider={i > 0} />
        ))}

        {overflowed.length > 0 && (
          <>
            <div className="action-divider" />
            <DropdownMenu className="action-overflow-menu">
              <DropdownMenuTrigger className="action-btn action-btn-overflow">
                <ChevronDown size={12} />
              </DropdownMenuTrigger>
              <DropdownMenuContent className="action-menu-content">
                {overflowed.map((item) => (
                  <DropdownMenuItem
                    key={item.key}
                    onClick={item.onClick}
                    disabled={item.disabled}
                  >
                    {item.icon}
                    <span>{item.label}</span>
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>
          </>
        )}
      </div>
    </div>
  );
}

function ActionButton({ item, showDivider }: { item: ActionItem; showDivider: boolean }) {
  return (
    <>
      {showDivider && <div className="action-divider" />}
      <Button
        variant="ghost"
        size="sm"
        className={`action-btn${item.primary ? " primary" : ""}`}
        onClick={item.onClick}
        disabled={item.disabled}
      >
        {item.icon}
        <span className="action-label">{item.label}</span>
      </Button>
    </>
  );
}
