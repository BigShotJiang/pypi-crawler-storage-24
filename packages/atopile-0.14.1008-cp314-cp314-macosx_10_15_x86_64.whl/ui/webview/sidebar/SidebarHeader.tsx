import { useMemo } from "react";
import { AlertCircle, Check, Loader2, Settings, X } from "lucide-react";
import type { UiCoreStatus } from "../../protocol/generated-types";
import { logoUrl } from "../common/render";
import { rpcClient } from "../common/webviewRpcClient";
import "./SidebarHeader.css";

interface SidebarHeaderProps {
  coreStatus: UiCoreStatus;
  hasExtensionError: boolean;
  connected: boolean;
}

export function SidebarHeader({
  coreStatus,
  hasExtensionError,
  connected,
}: SidebarHeaderProps) {
  const health = useMemo(() => {
    if (!connected) {
      return {
        tone: "error",
        label: "Disconnected",
        icon: <X size={12} />,
      };
    }
    if (hasExtensionError) {
      return {
        tone: "warning",
        label: "Degraded",
        icon: <AlertCircle size={12} />,
      };
    }
    if (!coreStatus.version) {
      return {
        tone: "loading",
        label: "Starting",
        icon: <Loader2 size={12} className="spin" />,
      };
    }
    return {
      tone: "success",
      label: "Healthy",
      icon: <Check size={12} />,
    };
  }, [connected, hasExtensionError, coreStatus.version]);

  return (
    <div className="sidebar-header">
      {logoUrl ? <img src={logoUrl} alt="atopile" className="sidebar-logo" /> : null}
      <span className="sidebar-title">atopile</span>
      {coreStatus.version ? <span className="version-badge">v{coreStatus.version}</span> : null}
      <span className={`sidebar-health sidebar-health-${health.tone}`} title={health.label}>
        {health.icon}
        <span>{health.label}</span>
      </span>

      <button
        type="button"
        className="sidebar-settings-btn"
        title="Settings"
        onClick={() => {
          void rpcClient?.requestAction("vscode.openPanel", { panelId: "panel-settings" });
        }}
      >
        <Settings size={14} />
      </button>
    </div>
  );
}
