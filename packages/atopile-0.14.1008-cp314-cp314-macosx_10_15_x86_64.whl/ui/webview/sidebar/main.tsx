import { useEffect, useMemo, useState } from "react";
import { render } from "../common/render";
import { WebviewRpcClient, rpcClient } from "../common/webviewRpcClient";
import { getVscodeApi } from "../common/vscodeApi";
import { createWebviewLogger } from "../common/logger";
import {
  Spinner,
  Alert,
  AlertTitle,
  AlertDescription,
  CopyableCodeBlock,
} from "../common/components";
import { getCurrentStage } from "../common/utils";
import { ProjectTargetSelector } from "./ProjectTargetSelector";
import { samePath } from "../../protocol/paths";
import { ActionBar } from "./ActionBar";
import { SidebarHeader } from "./SidebarHeader";
import { TabBar, type TabId } from "./TabBar";
import {
  FilesPanel,
  PackagesPanel,
  PartsPanel,
  LibraryPanel,
  StructurePanel,
  ParametersPanel,
  BOMPanel,
  AgentPanel,
  BuildQueuePanel,
} from "../sidebar-panels";
import { PackageDetailPanel } from "../sidebar-details/PackageDetailPanel";
import { PartsDetailPanel } from "../sidebar-details/PartsDetailPanel";
import { MigrateDialog } from "../sidebar-details/MigrateDialog";
import "./sidebar.css";

const POST_CONNECT_DISCONNECT_GRACE_MS = 5_000;
const logger = createWebviewLogger("Sidebar");

function DisconnectedOverlay({
  isConnected,
  extensionError,
  extensionTraceback,
  connected,
}: {
  isConnected: boolean;
  extensionError: string | null;
  extensionTraceback: string | null;
  connected: boolean;
}) {
  const [hasEverConnected, setHasEverConnected] = useState(false);
  const [show, setShow] = useState(false);

  useEffect(() => {
    if (isConnected) {
      setHasEverConnected(true);
      setShow(Boolean(extensionError));
      return;
    }
    if (extensionError) {
      setShow(true);
      return;
    }
    if (!hasEverConnected) {
      return;
    }
    const timeoutId = window.setTimeout(() => {
      setShow(true);
    }, POST_CONNECT_DISCONNECT_GRACE_MS);
    return () => window.clearTimeout(timeoutId);
  }, [isConnected, hasEverConnected, extensionError]);

  if (!show) return null;

  const overlayTitle = extensionError
    ? hasEverConnected
      ? "Extension Error"
      : "Failed to Start"
    : "Connection Lost";

  return (
    <div className="disconnected-overlay">
      <Alert variant={extensionError ? "destructive" : "warning"}>
        <AlertTitle>{overlayTitle}</AlertTitle>
        <AlertDescription>
          {extensionError ? (
            <code>{extensionError}</code>
          ) : (
            !connected
              ? "Unable to connect to the core server."
              : "Disconnected from the extension bridge."
          )}
        </AlertDescription>
        {extensionError && extensionTraceback ? (
          <details className="startup-traceback">
            <summary>Traceback</summary>
            <CopyableCodeBlock code={extensionTraceback} label="Traceback" />
          </details>
        ) : null}
        {extensionError && (
          <button
            className="open-settings-button"
            onClick={() => {
              getVscodeApi()?.postMessage({
                type: "extension:openSettings",
                query: "atopile.ato",
              });
            }}
          >
            Open atopile Settings
          </button>
        )}
        <AlertDescription>
          Run <code>Restart Extension Host</code> from the command palette.
          Check the <code>atopile</code> output channel for errors.
        </AlertDescription>
        <AlertDescription>
          Need help?{" "}
          <a href="https://discord.gg/CRe5xaDBr3" target="_blank" rel="noopener noreferrer">
            Join our Discord
          </a>
        </AlertDescription>
      </Alert>
    </div>
  );
}

function App() {
  const projectState = WebviewRpcClient.useSubscribe("projectState");
  const projects = WebviewRpcClient.useSubscribe("projects");
  const connected = WebviewRpcClient.useSubscribe("connected");
  const coreStatus = WebviewRpcClient.useSubscribe("coreStatus");
  const queueBuilds = WebviewRpcClient.useSubscribe("queueBuilds");
  const selectedBuildInProgress = WebviewRpcClient.useSubscribe("selectedBuildInProgress");
  const projectFiles = WebviewRpcClient.useSubscribe("projectFiles");
  const sidebarDetails = WebviewRpcClient.useSubscribe("sidebarDetails");
  const structureData = WebviewRpcClient.useSubscribe("structureData");
  const extensionErrorState = WebviewRpcClient.useSubscribe("extensionError");
  const extensionSettings = WebviewRpcClient.useSubscribe("extensionSettings");

  const [activeTab, setActiveTab] = useState<TabId>("files");
  const [isPackageInstalling, setIsPackageInstalling] = useState(false);

  const isConnected = connected;
  const extensionError = extensionErrorState.error;
  const extensionTraceback = extensionErrorState.traceback;
  const [hasEverConnected, setHasEverConnected] = useState(false);

  useEffect(() => {
    if (isConnected) {
      setHasEverConnected(true);
    }
  }, [isConnected]);

  const selectedProject = useMemo(
    () =>
      projects.find((project) => samePath(project.root, projectState.selectedProjectRoot)) ??
      null,
    [projects, projectState.selectedProjectRoot],
  );

  const projectBuilds = useMemo(() => {
    if (!projectState.selectedProjectRoot) return [];

    return queueBuilds
      .filter((build) => samePath(build.projectRoot, projectState.selectedProjectRoot))
      .map((b) => ({
        ...b,
        currentStage: getCurrentStage(b),
      }));
  }, [queueBuilds, projectState.selectedProjectRoot]);

  const isBuilding = selectedBuildInProgress;

  const panelMap: Record<TabId, React.ReactNode> = {
    files: <FilesPanel />,
    packages: <PackagesPanel />,
    parts: <PartsPanel />,
    library: <LibraryPanel />,
    structure: <StructurePanel />,
    parameters: <ParametersPanel />,
    bom: <BOMPanel />,
  };

  const detailContent = useMemo(() => {
    switch (sidebarDetails.view) {
      case "package":
        if (!sidebarDetails.package.summary) {
          return null;
        }
        return (
          <PackageDetailPanel
            package={{
              name: sidebarDetails.package.summary.name,
              fullName: sidebarDetails.package.summary.identifier,
              version: sidebarDetails.package.summary.version ?? undefined,
              description: sidebarDetails.package.summary.description ?? undefined,
              installed: sidebarDetails.package.summary.installed,
              availableVersions: sidebarDetails.package.details?.versions.map((version) => ({
                version: version.version,
                released: version.releasedAt ?? "",
              })),
              homepage: sidebarDetails.package.summary.homepage ?? undefined,
              repository: sidebarDetails.package.summary.repository ?? undefined,
            }}
            packageDetails={sidebarDetails.package.details}
            isLoading={sidebarDetails.package.loading}
            isInstalling={isPackageInstalling}
            installError={sidebarDetails.package.actionError}
            error={sidebarDetails.package.error}
            packageSyncProgress={sidebarDetails.package.syncProgress}
            onClose={() => rpcClient?.sendAction("closeSidebarDetails")}
            onInstall={(version) => {
              setIsPackageInstalling(true);
              rpcClient?.sendAction("installPackage", {
                projectRoot: sidebarDetails.package.projectRoot,
                packageId: sidebarDetails.package.summary?.identifier,
                version,
              });
            }}
            onUninstall={() => {
              setIsPackageInstalling(true);
              rpcClient?.sendAction("removePackage", {
                projectRoot: sidebarDetails.package.projectRoot,
                packageId: sidebarDetails.package.summary?.identifier,
              });
            }}
          />
        );
      case "part":
        if (!sidebarDetails.part.part) {
          return null;
        }
        return (
          <PartsDetailPanel
            part={sidebarDetails.part.part}
            projectRoot={sidebarDetails.part.projectRoot}
            onClose={() => rpcClient?.sendAction("closeSidebarDetails")}
          />
        );
      case "migration":
        if (!sidebarDetails.migration.projectRoot) {
          return null;
        }
        return (
          <MigrateDialog
            migration={sidebarDetails.migration}
            actualVersion={coreStatus.version}
            onClose={() => rpcClient?.sendAction("closeSidebarDetails")}
          />
        );
      default:
        return null;
    }
  }, [coreStatus.version, isPackageInstalling, sidebarDetails]);

  useEffect(() => {
    if (!sidebarDetails.package.loading) {
      setIsPackageInstalling(false);
    }
  }, [sidebarDetails.package.loading, sidebarDetails.package.details?.installedVersion, sidebarDetails.package.actionError]);

  return (
    <div className="sidebar">
      <SidebarHeader
        coreStatus={coreStatus}
        hasExtensionError={Boolean(extensionError)}
        connected={connected}
      />

      {!isConnected && !hasEverConnected ? (
        <div className="sidebar-status">
          <Spinner size={14} />
          <span>Connecting...</span>
        </div>
      ) : (
        <>
          {/* Top section: selectors + action bar */}
          <div className="sidebar-top">
            <ProjectTargetSelector
              projects={projects}
              modules={structureData.modules}
              selectedProjectRoot={projectState.selectedProjectRoot}
              onSelectProject={(root) =>
                rpcClient?.sendAction("selectProject", { projectRoot: root })
              }
              selectedTarget={projectState.selectedTarget}
              onSelectTarget={(target) =>
                rpcClient?.sendAction("selectTarget", { target })
              }
            />
            <ActionBar
              onBuild={() =>
                rpcClient?.sendAction("startBuild", {
                  projectRoot: projectState.selectedProjectRoot,
                  targets: projectState.selectedTarget ? [projectState.selectedTarget] : [],
                })
              }
              onOpenKicad={() =>
                void rpcClient?.requestAction("vscode.openKicad", {
                  projectRoot: projectState.selectedProjectRoot,
                  target: projectState.selectedTarget,
                })
              }
              onOpenManufacture={() => {
                logger.info("openPanel click panelId=panel-manufacture");
                void rpcClient?.requestAction("vscode.openPanel", {
                  panelId: "panel-manufacture",
                });
              }}
              buildDisabled={
                !projectState.selectedProjectRoot ||
                !projectState.selectedTarget ||
                Boolean(selectedProject?.needsMigration) ||
                Boolean(selectedProject?.error)
              }
              isBuilding={isBuilding}
              showMigration={Boolean(
                selectedProject?.needsMigration && projectState.selectedProjectRoot,
              )}
              onOpenMigration={() => {
                if (!projectState.selectedProjectRoot) return;
                rpcClient?.sendAction("showMigrationDetails", {
                  projectRoot: projectState.selectedProjectRoot,
                });
              }}
            />
            {selectedProject?.error ? (
              <Alert variant="destructive">
                <AlertTitle>Project Error</AlertTitle>
                <AlertDescription>{selectedProject.error}</AlertDescription>
              </Alert>
            ) : null}
          </div>

          {detailContent ? (
            <div className="sidebar-tab-content sidebar-tab-content-detail">
              {detailContent}
            </div>
          ) : (
            <>
              <TabBar activeTab={activeTab} onTabChange={setActiveTab} />
              <div className="sidebar-tab-content">
                {panelMap[activeTab]}
              </div>
            </>
          )}

          {extensionSettings.enableChat && (
            <AgentPanel
              projectRoot={projectState.selectedProjectRoot}
              selectedTargets={projectState.selectedTarget ? [projectState.selectedTarget.name] : []}
              projectModules={structureData.modules}
              projectFileNodes={projectFiles.files}
            />
          )}

          {/* Resizable builds pane at bottom */}
          <BuildQueuePanel builds={projectBuilds} />
        </>
      )}

      <DisconnectedOverlay
        isConnected={isConnected}
        extensionError={extensionError}
        extensionTraceback={extensionTraceback}
        connected={connected}
      />
    </div>
  );
}

render(App);
