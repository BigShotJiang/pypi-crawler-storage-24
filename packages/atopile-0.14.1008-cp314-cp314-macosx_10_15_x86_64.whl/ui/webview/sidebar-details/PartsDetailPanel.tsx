import { useMemo, useRef, useState } from 'react'
import { ArrowLeft, Loader2, CheckCircle, AlertCircle, Download, Cuboid, Image, FileCode } from 'lucide-react'
import type { UiPartDetail } from '../../protocol/generated-types'
import { CopyableCodeBlock, LayoutPreview, StepViewer } from '../common/components'
import type { RenderModel } from '../common/layout'
import { rpcClient } from '../common/webviewRpcClient'
import { useBlobAssetUrl } from '../common/utils'
import './PackageDetailPanel.css'
import './PartsDetailPanel.css'

interface PartsDetailPanelProps {
  part: UiPartDetail
  projectRoot: string | null
  onClose: () => void
}

function formatCurrency(value: number | null | undefined): string {
  if (value == null || Number.isNaN(value)) return '-'
  if (value < 0.01) return `$${value.toFixed(4)}`
  return `$${value.toFixed(2)}`
}

function formatStock(stock: number | null | undefined): string {
  if (stock == null) return '-'
  if (stock <= 0) return 'Out of stock'
  if (stock >= 1_000_000) return `${(stock / 1_000_000).toFixed(1)}M`
  if (stock >= 1_000) return `${(stock / 1_000).toFixed(1)}K`
  return stock.toLocaleString()
}

export function PartsDetailPanel({
  part,
  projectRoot,
  onClose,
}: PartsDetailPanelProps) {
  const [installMode, setInstallMode] = useState<'plain' | 'package' | null>(null)
  const [isUninstalling, setIsUninstalling] = useState(false)
  const [actionError, setActionError] = useState<string | null>(null)
  const [actionNotice, setActionNotice] = useState<string | null>(null)
  // Track local override of installed state: null = use part.installed, true/false = override
  const [installedOverride, setInstalledOverride] = useState<boolean | null>(null)
  const [activeVisualTab, setActiveVisualTab] = useState<'image' | 'layout' | '3d'>('image')
  const details = part

  const attributes = useMemo(() => {
    if (!details?.attributes) return []
    return Object.entries(details.attributes).slice(0, 12)
  }, [details?.attributes])

  // Cooldown timestamp to debounce rapid clicking
  const cooldownUntil = useRef(0)
  const COOLDOWN_MS = 1000 // 1 second cooldown between operations
  const isInstalling = installMode !== null

  const handleInstall = async (createPackage = false) => {
    if (!projectRoot) {
      setActionError('Select a project to install parts.')
      return
    }
    if (Date.now() < cooldownUntil.current) return
    if (isInstalling || isUninstalling) return

    setInstallMode(createPackage ? 'package' : 'plain')
    setActionError(null)
    setActionNotice(null)
    rpcClient?.sendAction('installPart', {
      lcsc: part.lcsc,
      projectRoot,
      createPackage,
    })
    if (createPackage) {
      setInstalledOverride(null)
      setActionNotice('Created a local package for this part.')
    } else {
      setInstalledOverride(true)
    }
    cooldownUntil.current = Date.now() + COOLDOWN_MS
    window.setTimeout(() => setInstallMode(null), 5000)
  }

  const handleUninstall = async () => {
    if (!projectRoot) {
      setActionError('Select a project to uninstall parts.')
      return
    }
    if (Date.now() < cooldownUntil.current) return
    if (isInstalling || isUninstalling) return

    setIsUninstalling(true)
    setActionError(null)
    setActionNotice(null)
    rpcClient?.sendAction('uninstallPart', {
      lcsc: part.lcsc,
      projectRoot,
    })
    setInstalledOverride(false)
    cooldownUntil.current = Date.now() + COOLDOWN_MS
    setIsUninstalling(false)
  }

  const description = details?.description || part.description || 'No description available.'
  const displayManufacturer = details?.manufacturer || part.manufacturer
  const displayMpn = details?.mpn || part.mpn
  const imageUrl = details?.imageUrl || part.imageUrl
  const isInstalled = installedOverride !== null ? installedOverride : part.installed
  const importSnippet = details?.importStatement || part.importStatement
  const layoutPreviewKey = part.lcsc ?? null
  const layoutPreviewLoad = useMemo(
    () => {
      const client = rpcClient
      if (!part.lcsc || !client) {
        return null
      }
      return () => client.requestAction<RenderModel>('getPartFootprintRenderModel', { lcsc: part.lcsc })
    },
    [part.lcsc],
  )
  const modelAsset = useBlobAssetUrl(
    activeVisualTab === '3d' ? 'getPartModelData' : null,
    activeVisualTab === '3d' ? { lcsc: part.lcsc } : null,
  )

  return (
    <div className="package-detail-panel parts-detail-panel">
      <div className="detail-panel-header">
        <button className="detail-back-btn" onClick={onClose} title="Back">
          <ArrowLeft size={18} />
        </button>
        <div className="detail-header-info">
          <div className="detail-title-row">
            <h2 className="detail-package-name">{displayMpn}</h2>
            {isInstalled && (
              <span className="detail-installed">
                <CheckCircle size={14} />
                Installed
              </span>
            )}
          </div>
          <p className="detail-package-blurb">{description}</p>
        </div>
      </div>

      <div className="detail-panel-content">
          <div className="parts-detail-grid">
            <div className="parts-detail-section">
              <div className="detail-install-row">
                {isInstalled ? (
                  <button
                    className={`detail-install-btn uninstall ${isUninstalling ? 'installing' : ''}`}
                    onClick={handleUninstall}
                    disabled={isInstalling || isUninstalling}
                  >
                    {isUninstalling ? (
                      <>
                        <Loader2 size={14} className="animate-spin" />
                        Uninstalling...
                      </>
                    ) : (
                      <>
                        <Download size={14} />
                        Uninstall
                      </>
                    )}
                  </button>
                ) : (
                  <div className="detail-install-split">
                    <button
                      className={`detail-install-btn install ${installMode === 'plain' ? 'installing' : ''}`}
                      onClick={() => void handleInstall(false)}
                      disabled={isInstalling || isUninstalling}
                    >
                      {installMode === 'plain' ? (
                        <>
                          <Loader2 size={14} className="animate-spin" />
                          Installing...
                        </>
                      ) : (
                        <>
                          <Download size={14} />
                          Install
                        </>
                      )}
                    </button>
                    <button
                      className={`detail-install-btn install-package ${installMode === 'package' ? 'installing' : ''}`}
                      onClick={() => void handleInstall(true)}
                      disabled={isInstalling || isUninstalling}
                    >
                      {installMode === 'package' ? (
                        <>
                          <Loader2 size={14} className="animate-spin" />
                          Creating package...
                        </>
                      ) : (
                        <>
                          <Download size={14} />
                          Install as package
                        </>
                      )}
                    </button>
                  </div>
                )}
              </div>
              {actionError && (
                <div className="detail-install-error">
                  <AlertCircle size={12} />
                  <span>{actionError}</span>
                </div>
              )}
              {actionNotice && (
                <div className="parts-install-success">
                  <CheckCircle size={12} />
                  <span>{actionNotice}</span>
                </div>
              )}
            </div>
            <div className="detail-section parts-detail-section">
              <div className="parts-detail-section-title">Overview</div>
              <dl className="detail-info-list">
                <div className="detail-info-row">
                  <dt>Manufacturer</dt>
                  <dd className="detail-info-value">{displayManufacturer || '-'}</dd>
                </div>
                <div className="detail-info-row">
                  <dt>MPN</dt>
                  <dd className="detail-info-value">{displayMpn}</dd>
                </div>
                <div className="detail-info-row">
                  <dt>LCSC</dt>
                  <dd className="detail-info-value">
                    <span className="detail-info-mono">{part.lcsc}</span>
                  </dd>
                </div>
                <div className="detail-info-row">
                  <dt>Package</dt>
                  <dd className="detail-info-value">
                    <span className="detail-info-mono">{details?.package || part.package || '-'}</span>
                  </dd>
                </div>
                <div className="detail-info-row">
                  <dt>Stock</dt>
                  <dd className="detail-info-value">{formatStock(details?.stock)}</dd>
                </div>
                <div className="detail-info-row">
                  <dt>Unit price</dt>
                  <dd className="detail-info-value">{formatCurrency(details?.unitCost)}</dd>
                </div>
                <div className="detail-info-row">
                  <dt>Type</dt>
                  <dd className="detail-info-value">
                    <span className={`parts-type-badge ${details?.isBasic ? 'basic' : details?.isPreferred ? 'preferred' : 'extended'}`}>
                      {details?.isBasic ? 'Basic' : details?.isPreferred ? 'Preferred' : 'Extended'}
                    </span>
                  </dd>
                </div>
                {details?.datasheetUrl && (
                  <div className="detail-info-row">
                    <dt>Datasheet</dt>
                    <dd className="detail-info-value">
                      <a
                        className="detail-text-link"
                        href={details.datasheetUrl}
                        target="_blank"
                        rel="noreferrer"
                      >
                        {details.datasheetUrl}
                      </a>
                    </dd>
                  </div>
                )}
              </dl>
            </div>

            <div className="detail-section parts-detail-section">
              <div className="parts-detail-section-title">Attributes</div>
              {attributes.length === 0 && (
                <div className="detail-empty">None</div>
              )}
              {attributes.length > 0 && (
                <dl className="detail-info-list">
                  {attributes.map(([key, value]) => (
                    <div key={key} className="detail-info-row">
                      <dt>{key}</dt>
                      <dd className="detail-info-value">
                        <span className="detail-info-mono">
                          {typeof value === 'string' ? value : JSON.stringify(value)}
                        </span>
                      </dd>
                    </div>
                  ))}
                </dl>
              )}
            </div>

            <section className="detail-section parts-detail-section">
              <h3 className="detail-section-title">
                <FileCode size={14} />
                Import
              </h3>
              {importSnippet ? (
                <div className="detail-usage-code">
                  <CopyableCodeBlock code={importSnippet} label="Import" highlightAto />
                </div>
              ) : (
                <div className="detail-empty detail-usage-empty">
                  Install this part to get a project-local import statement.
                </div>
              )}
            </section>

            <div className="parts-visual-section">
              <div className="parts-visual-tabs">
                <button
                  className={`parts-visual-tab ${activeVisualTab === 'image' ? 'active' : ''}`}
                  onClick={() => setActiveVisualTab('image')}
                >
                  <Image size={14} />
                  Image
                </button>
                <button
                  className={`parts-visual-tab ${activeVisualTab === 'layout' ? 'active' : ''}`}
                  onClick={() => setActiveVisualTab('layout')}
                >
                  <FileCode size={14} />
                  Footprint
                </button>
                <button
                  className={`parts-visual-tab ${activeVisualTab === '3d' ? 'active' : ''}`}
                  onClick={() => setActiveVisualTab('3d')}
                >
                  <Cuboid size={14} />
                  3D Model
                </button>
              </div>
              <div className="parts-visual-content">
                {activeVisualTab === 'image' ? (
                  imageUrl ? (
                    <img src={imageUrl} alt={displayMpn} className="parts-visual-image" />
                  ) : (
                    <div className="parts-visual-empty">No image available</div>
                  )
                ) : activeVisualTab === 'layout' ? (
                  <LayoutPreview
                    cacheKey={layoutPreviewKey}
                    load={layoutPreviewLoad}
                    emptyMessage="No footprint available"
                    loadingMessage="Loading footprint..."
                  />
                ) : (
                  modelAsset.url ? (
                    <StepViewer
                      src={modelAsset.url}
                    />
                  ) : modelAsset.loading ? (
                    <div className="parts-visual-empty">Loading 3D model...</div>
                  ) : (
                    <div className="parts-visual-empty">{modelAsset.error || 'No 3D model available'}</div>
                  )
                )}
              </div>
            </div>
          </div>
        </div>
    </div>
  )
}
