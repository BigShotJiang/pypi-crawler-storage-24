"""
Deferred execution phase for the ato compiler.

After the AST visitor has built the type graph and the linker has resolved
all type references, this module executes deferred operations that require
fully linked types:

1. Inheritance resolution - copies parent structure into derived types
2. Retype operations - updates type references for `target -> NewType` statements
3. For-loop execution - expands deferred for-loops (delegated to visitor)
"""

from pathlib import Path
from typing import TYPE_CHECKING, Protocol, Sequence

import faebryk.core.faebrykpy as fbrk
import faebryk.core.graph as graph
import faebryk.core.node as fabll
from atopile.compiler import DslException, DslRichException
from atopile.compiler.ast_visitor import BuildState
from atopile.compiler.gentypegraph import FieldPath, ImportRef
from faebryk.libs.util import DAG, prefixes

if TYPE_CHECKING:
    from atopile.compiler.ast_visitor import ASTVisitor

_Address = Sequence[str]


class StdlibLookup(Protocol):
    """Protocol for stdlib type lookup (matches StdlibRegistry interface)."""

    def get(self, name: str) -> graph.BoundNode: ...
    def __contains__(self, name: str) -> bool: ...


class FileImportLookup(Protocol):
    """Protocol for looking up types from linked file imports."""

    def resolve(
        self, path: str, name: str, base_file: Path | None
    ) -> graph.BoundNode | None: ...


class RetypeException(DslException):
    def __init__(self, target_path: FieldPath, detail: str) -> None:
        super().__init__(f"Cannot retype `{target_path}`: {detail}")


class DeferredExecutor:
    """
    Executes deferred operations after linking is complete.

    This is phase 2 of compilation, running after:
    - Phase 1a: AST visiting (builds type graph structure)
    - Phase 1b: Linking (resolves type references)

    And before:
    - Phase 3: Instantiation
    """

    def __init__(
        self,
        g: graph.GraphView,
        tg: fbrk.TypeGraph,
        state: BuildState,
        visitor: "ASTVisitor",
        stdlib: StdlibLookup | None = None,
        file_imports: FileImportLookup | None = None,
    ) -> None:
        self._g = g
        self._tg = tg
        self._pending_inheritance = state.pending_inheritance
        self._pending_retypes = state.pending_retypes
        self._type_roots = state.type_roots
        self._base_file = state.file_path
        self._visitor = visitor
        self._stdlib = stdlib
        self._file_imports = file_imports

    def execute(self) -> None:
        """Execute all deferred operations in order."""
        self._resolve_inheritance()
        self._execute_retypes()
        self._visitor._execute_for_loops()
        for type_node in self._type_roots.values():
            self._tg.mark_constructable(type_node=type_node)

    def _resolve_inheritance(self) -> None:
        """
        Resolve inheritance by copying parent structure into derived types.

        Processes base types before derived types using topological sort.
        """

        def _get_parent_name(parent_ref: ImportRef | str) -> str:
            return parent_ref.name if isinstance(parent_ref, ImportRef) else parent_ref

        def _resolve_parent_type(
            parent_ref: ImportRef | str,
        ) -> graph.BoundNode | None:
            """
            Resolve parent type from local type_roots, stdlib, or file imports.

            For stdlib imports (ImportRef with path=None), look up in stdlib registry.
            For file imports (ImportRef with path), use the file import resolver.
            For local types (str), look up in type_roots.
            """
            if isinstance(parent_ref, ImportRef):
                if parent_ref.path is None:
                    # stdlib import - look up in stdlib registry
                    if self._stdlib is not None and parent_ref.name in self._stdlib:
                        return self._stdlib.get(parent_ref.name)
                else:
                    # file import - use the file import resolver
                    if self._file_imports is not None:
                        return self._file_imports.resolve(
                            path=parent_ref.path,
                            name=parent_ref.name,
                            base_file=self._base_file,
                        )
            # Local type - look up in type_roots
            parent_name = _get_parent_name(parent_ref)
            return self._type_roots.get(parent_name)

        dag: DAG[str] = DAG()
        pending_by_name = {}

        for item in self._pending_inheritance:
            parent_name = _get_parent_name(item.parent_ref)
            dag.add_edge(parent=parent_name, child=item.derived_name)
            pending_by_name[item.derived_name] = item

        try:
            sorted_types = dag.topologically_sorted()
        except ValueError as e:
            raise DslRichException(
                "Circular inheritance detected",
                file_path=self._base_file,
            ) from e

        for type_name in sorted_types:
            if type_name not in pending_by_name:
                continue  # Base type without parent in this file

            item = pending_by_name[type_name]
            parent_name = _get_parent_name(item.parent_ref)

            if (parent_type := _resolve_parent_type(item.parent_ref)) is None:
                raise DslException(
                    f"Parent type `{parent_name}` not found for `{item.derived_name}`"
                )

            # Apply inheritance
            self._tg.merge_types(
                target=item.derived_type,
                source=parent_type,
            )

    def _execute_retypes(self) -> None:
        """
        Apply retype operations after all types are linked.

        Retypes are applied in source order.

        For each retype `target -> NewType`:
        1. Resolve and localize the traversed parent path, if any
        2. Get the MakeChild's type reference for the leaf field
        3. Resolve the replacement type
        4. Update the leaf type reference to point to the new type

        Nested retypes first clone the traversed parent path so the final leaf rewrite
        does not mutate a shared type definition in place.
        """

        def _resolve_type_ref(
            target_path: FieldPath, type_ref: graph.BoundNode
        ) -> graph.BoundNode:
            if (out := fbrk.Linker.get_resolved_type(type_reference=type_ref)) is None:
                type_id = fbrk.TypeGraph.get_type_reference_identifier(
                    type_reference=type_ref
                )

                raise RetypeException(target_path, f"type `{type_id}` is not linked")

            return out

        def _resolve_child(
            owning_type: graph.BoundNode, path: _Address
        ) -> graph.BoundNode:
            if (
                out := self._tg.get_make_child_type_reference_by_identifier(
                    type_node=owning_type, identifier=path[-1]
                )
            ) is None:
                raise RetypeException(target_path, "path does not exist")

            return out

        def _clone_type(
            source_type: graph.BoundNode,
            containing_type: graph.BoundNode,
            source_order: int,
            path: _Address,
        ) -> graph.BoundNode:
            localized_type = self._tg.add_type(
                identifier=(
                    f"{self._tg.get_type_name(type_node=source_type)}"
                    f"__rt_{source_order}__"
                    f"{self._tg.get_type_name(type_node=containing_type)}__"
                    f"{FieldPath.format_identifiers(path, flatten=True)}"
                )
            )
            self._tg.merge_types(target=localized_type, source=source_type)
            self._tg.mark_constructable(type_node=localized_type)

            return localized_type

        def _localize_parent_path(
            containing_type: graph.BoundNode, parent_path: _Address, source_order: int
        ) -> graph.BoundNode:
            owning_type = containing_type

            for path_prefix in prefixes(parent_path):
                type_ref = _resolve_child(owning_type=owning_type, path=path_prefix)
                source_type = _resolve_type_ref(
                    target_path=target_path, type_ref=type_ref
                )

                if not fabll.TypeNodeBoundTG.has_instance_of_type_has_trait(
                    source_type, fabll.is_module
                ):
                    raise RetypeException(
                        target_path, "path traverses a non-module type"
                    )

                # Nested retypes must localize the traversed branch first — otherwise we
                # would rewrite a shared type definition in place
                localized_type = _clone_type(
                    source_type=source_type,
                    containing_type=containing_type,
                    source_order=source_order,
                    path=path_prefix,
                )
                fbrk.Linker.update_type_reference(
                    g=self._g, type_reference=type_ref, target_type_node=localized_type
                )
                owning_type = localized_type

            return owning_type

        for retype in sorted(self._pending_retypes, key=lambda r: r.source_order):
            try:
                target_path = retype.target_path
                path_ids = target_path.identifiers()
                owning_type = _localize_parent_path(
                    containing_type=retype.containing_type,
                    parent_path=path_ids[:-1],
                    source_order=retype.source_order,
                )
                type_ref = _resolve_child(owning_type=owning_type, path=path_ids)
                source_type = _resolve_type_ref(
                    target_path=target_path, type_ref=type_ref
                )
                new_type = _resolve_type_ref(
                    target_path=target_path, type_ref=retype.new_type_ref
                )

                for type_ in [owning_type, source_type, new_type]:
                    if not fabll.TypeNodeBoundTG.has_instance_of_type_has_trait(
                        type_, fabll.is_module
                    ):
                        type_name = self._tg.get_type_name(type_node=type_)
                        raise RetypeException(
                            target_path,
                            f"type `{type_name}` is not a module",
                        )

                fbrk.Linker.update_type_reference(
                    g=self._g, type_reference=type_ref, target_type_node=new_type
                )
            except DslException as ex:
                raise DslRichException(
                    str(ex), original=ex, source_node=retype.source_node
                ) from ex
