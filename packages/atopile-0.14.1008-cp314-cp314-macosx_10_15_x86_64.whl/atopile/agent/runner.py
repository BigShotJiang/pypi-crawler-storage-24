"""Agent runner — the core while(tool_calls) loop."""

from __future__ import annotations

import asyncio
import copy
import inspect
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Awaitable, Callable

from atopile.agent import tools as _legacy_tools
from atopile.agent.checklist import VALID_TRANSITIONS
from atopile.agent.circuit_breaker import CircuitBreaker
from atopile.agent.config import AgentConfig
from atopile.agent.context import build_initial_user_message, build_system_prompt
from atopile.agent.dataclasses import Checklist, ChecklistItem
from atopile.agent.message_log import (
    MSG_ACKNOWLEDGED,
    MSG_ACTIVE,
    MSG_PENDING,
    TrackedChecklistItem,
    TrackedMessage,
)
from atopile.agent.orchestrator_helpers import (
    _build_function_call_outputs_for_model,
    _build_steering_inputs_for_model,
    _consume_steering_updates,
    _limit_tool_output_for_model,
    _sanitize_tool_output_for_model,
    _summarize_tool_result_for_trace,
)
from atopile.agent.provider import (
    LLMProvider,
    LLMResponse,
    TokenUsage,
    ToolCall,
)
from atopile.agent.registry import ToolRegistry
from atopile.data_models import AppContext
from atopile.logging import get_logger

log = get_logger(__name__)

ProgressCallback = Callable[[dict[str, Any]], Awaitable[None] | None]
SteeringMessagesCallback = Callable[[], list[str]]
InterruptMessagesCallback = Callable[[], list[str]]
StopRequestedCallback = Callable[[], bool]
MessageCallback = Callable[[dict[str, Any]], Awaitable[None] | None]
TraceCallback = Callable[[str, dict[str, Any]], Awaitable[None] | None]

_CHECKLIST_TOOLS = frozenset(
    {"checklist_create", "checklist_update", "checklist_add_items"}
)
_MESSAGE_TOOLS = frozenset({"message_acknowledge", "message_log_query"})
_PLANNING_TOOLS = frozenset({"design_questions"})
_MANAGED_TOOLS = _CHECKLIST_TOOLS | _MESSAGE_TOOLS | _PLANNING_TOOLS

# Tools that represent productive work (reading, editing, building, etc.)
_WORK_TOOLS = frozenset(
    {
        "project_read_file",
        "project_edit_file",
        "project_list_files",
        "project_create_path",
        "build_run",
        "build_create",
        "build_rename",
        "parts_search",
        "parts_install",
        "packages_search",
        "packages_install",
        "layout_set_component_position",
        "layout_set_board_shape",
        "web_search",
    }
)


def _summarize_model_preamble(text: str, *, max_chars: int = 180) -> str | None:
    cleaned = " ".join(text.strip().split())
    if not cleaned:
        return None
    if len(cleaned) <= max_chars:
        return cleaned
    return f"{cleaned[: max_chars - 1].rstrip()}…"


async def _wait_for_indexing(vs_id: str, file_id: str, filename: str) -> str:
    """Poll vector store file status until indexed. Returns a message for the model."""
    from atopile.agent.tools import _get_openai_file_client

    client = _get_openai_file_client()
    for _ in range(120):
        try:
            vs_file = await client.vector_stores.files.retrieve(
                vector_store_id=vs_id,
                file_id=file_id,
            )
            status = getattr(vs_file, "status", "unknown")
            if status == "completed":
                return f"Datasheet {filename} is now indexed and searchable."
            if status == "failed":
                return f"Datasheet {filename} indexing failed."
        except Exception:
            pass
        await asyncio.sleep(1)
    return (
        f"Datasheet {filename} indexing timed out — search may return partial results."
    )


def _build_turn_time_budget_stop_text(
    elapsed: float, loops: int, traces: list[ToolTrace]
) -> str:
    return (
        f"Stopped after exceeding the per-turn time budget "
        f"({elapsed:.1f}s, {loops} loops, {len(traces)} tool calls)."
    )


def _build_stop_inputs_for_model() -> list[dict[str, Any]]:
    return [
        {
            "role": "user",
            "content": (
                "The user requested that you stop at the next safe boundary. "
                "Do not call any more tools. Reply with a concise handoff "
                "covering what was completed, what remains, and the best next "
                "step if work resumes."
            ),
        }
    ]


def _build_interrupt_inputs_for_model(messages: list[str]) -> list[dict[str, Any]]:
    if not messages:
        return _build_stop_inputs_for_model()
    bullets = "\n".join(f"- {message}" for message in messages)
    return [
        {
            "role": "user",
            "content": (
                "The user interrupted your current work and wants a direct reply "
                "now. Stop at this safe boundary, do not call any more tools, "
                "answer the user's message directly, then include a brief "
                "handoff covering what was completed and the best next step if "
                "work resumes.\n"
                f"{bullets}"
            ),
        }
    ]


def _next_checklist_item_id(existing_items: list[ChecklistItem]) -> str:
    numeric_ids = [int(item.id) for item in existing_items if item.id.isdigit()]
    next_id = (max(numeric_ids) + 1) if numeric_ids else (len(existing_items) + 1)
    return str(next_id)


def _resolve_checklist_item(
    items: list[ChecklistItem], requested_id: str
) -> ChecklistItem | None:
    target = next((item for item in items if item.id == requested_id), None)
    if target is not None:
        return target

    digits = "".join(ch for ch in requested_id if ch.isdigit())
    if not digits:
        return None

    return next((item for item in items if item.id == digits), None)


@dataclass
class BackgroundTask:
    """A background task that produces a message for the model when done."""

    name: str
    task: asyncio.Task[str]  # resolves to a user message string


class BackgroundTasks:
    """Manage background tasks that can inject messages into the conversation."""

    def __init__(self) -> None:
        self._tasks: list[BackgroundTask] = []

    def add(self, name: str, coro: Any) -> None:
        """Start a background coroutine. It should return a message string."""
        self._tasks.append(BackgroundTask(name=name, task=asyncio.ensure_future(coro)))

    def collect_completed(self) -> list[dict[str, Any]]:
        """Return model input messages for any completed tasks, removing them."""
        completed: list[dict[str, Any]] = []
        remaining: list[BackgroundTask] = []
        for bt in self._tasks:
            if bt.task.done():
                try:
                    message = bt.task.result()
                    if message:
                        completed.append({"role": "user", "content": message})
                except Exception as exc:
                    log.warning("Background task %s failed: %s", bt.name, exc)
            else:
                remaining.append(bt)
        self._tasks = remaining
        return completed


@dataclass
class _TurnState:
    checklist: Checklist | None = None
    current_message_id: str = ""
    force_turn_end: bool = False
    checklist_finalized: bool = False
    background: BackgroundTasks = field(default_factory=BackgroundTasks)
    _traces: list[ToolTrace] = field(default_factory=list)


@dataclass
class ToolTrace:
    name: str
    args: dict[str, Any]
    ok: bool
    result: dict[str, Any]


@dataclass
class AgentTurnResult:
    text: str
    tool_traces: list[ToolTrace]
    model: str
    response_id: str | None = None
    skill_state: dict[str, Any] = field(default_factory=dict)
    context_metrics: dict[str, Any] = field(default_factory=dict)


def _apply_project_edit_remaps(
    arguments: dict[str, Any],
    remaps: dict[str, Any],
) -> tuple[dict[str, Any], bool]:
    """Re-map hashline anchors when the model uses stale names."""
    normalized_remaps = {
        str(k).strip().lower(): str(v).strip()
        for k, v in remaps.items()
        if str(k).strip() and str(v).strip()
    }
    if not normalized_remaps:
        return arguments, False

    raw_edits = arguments.get("edits")
    if not isinstance(raw_edits, list):
        return arguments, False

    changed = False
    updated_arguments = dict(arguments)
    updated_edits: list[dict[str, Any]] = []

    for raw_edit in raw_edits:
        if not isinstance(raw_edit, dict):
            continue
        edit = dict(raw_edit)

        for key_name, anchor_keys in [
            ("set_line", ["anchor"]),
            ("replace_lines", ["start_anchor", "end_anchor"]),
            ("insert_after", ["anchor"]),
        ]:
            sub = edit.get(key_name)
            if not isinstance(sub, dict):
                continue
            updated_sub = dict(sub)
            for ak in anchor_keys:
                raw_anchor = updated_sub.get(ak)
                if not isinstance(raw_anchor, str):
                    continue
                prefix, sep, suffix = raw_anchor.partition("|")
                mapped = normalized_remaps.get(prefix.strip().lower())
                if mapped:
                    updated_sub[ak] = f"{mapped}|{suffix}" if sep else mapped
                    changed = True
            edit[key_name] = updated_sub

        updated_edits.append(edit)

    if not changed:
        return arguments, False
    updated_arguments["edits"] = updated_edits
    return updated_arguments, True


def _resolve_message_id(raw: str | None, fallback: str) -> str | None:
    """Normalize a model-provided message_id.

    If the model made up a value (e.g. ``"user-request"``), fall back to the
    current turn's real message_id.  A valid id is a 32-char hex UUID.
    """
    if not raw or not isinstance(raw, str):
        return fallback or None
    cleaned = raw.strip()
    # Accept 32-char hex strings (uuid4().hex format)
    if len(cleaned) == 32:
        try:
            int(cleaned, 16)
            return cleaned
        except ValueError:
            pass
    # Model made up an id — use the turn's message_id
    return fallback or None


class AgentRunner:
    def __init__(
        self,
        config: AgentConfig,
        provider: LLMProvider,
        registry: ToolRegistry,
    ) -> None:
        self._config = config
        self._provider = provider
        self._registry = registry

    # ── Public API ────────────────────────────────────────────────────
    # Signature matches AgentOrchestrator.run_turn() exactly.

    async def run_turn(
        self,
        *,
        ctx: AppContext,
        project_root: str,
        history: list[dict[str, str]],
        user_message: str,
        session_id: str = "",
        selected_targets: list[str] | None = None,
        previous_response_id: str | None = None,
        prior_skill_state: dict[str, Any] | None = None,
        tool_memory: dict[str, dict[str, Any]] | None = None,
        progress_callback: ProgressCallback | None = None,
        consume_steering_messages: SteeringMessagesCallback | None = None,
        consume_interrupt_messages: InterruptMessagesCallback | None = None,
        stop_requested: StopRequestedCallback | None = None,
        message_callback: MessageCallback | None = None,
        trace_callback: TraceCallback | None = None,
    ) -> AgentTurnResult:
        _ = message_callback  # reserved for future multi-agent messaging
        cfg = self._config

        project_path = _legacy_tools.validate_tool_scope(project_root, ctx)
        selected = selected_targets or []
        include_primer = previous_response_id is None and len(history) == 0

        # Build system prompt + skill state
        instructions, skill_state = build_system_prompt(
            config=cfg,
            project_root=project_path,
            selected_targets=selected,
            include_session_primer=include_primer,
        )
        if isinstance(prior_skill_state, dict):
            persisted_state = {
                key: value
                for key, value in prior_skill_state.items()
                if key
                not in {
                    "mode",
                    "skills_dir",
                    "requested_skill_ids",
                    "selected_skill_ids",
                    "selected_skills",
                    "missing_skill_ids",
                    "per_skill_max_chars",
                    "reasoning",
                    "total_chars",
                    "max_chars",
                    "generated_at",
                }
            }
            skill_state.update(copy.deepcopy(persisted_state))

        # Build initial input
        user_content = await build_initial_user_message(
            project_root=project_path,
            selected_targets=selected,
            user_message=user_message,
            context_max_chars=cfg.context_summary_max_chars,
            message_max_chars=cfg.user_message_max_chars,
        )
        history_for_model = history if previous_response_id is None else []
        request_input: list[dict[str, Any]] = list(history_for_model)

        tool_defs = list(self._registry.definitions())
        vector_store_ids: list[str] = []

        breaker = CircuitBreaker()
        traces: list[ToolTrace] = []
        loops = 0
        last_response_id = previous_response_id
        started_at = time.monotonic()
        telemetry: dict[str, Any] = {
            "api_retry_count": 0,
            "compaction_events": [],
            "checklist_tool_count": 0,
            "work_tool_count": 0,
            "model_call_count": 0,
            "tool_call_count": 0,
            "input_tokens": 0,
            "output_tokens": 0,
            "total_tokens": 0,
            "reasoning_tokens": 0,
            "cached_input_tokens": 0,
            "model_duration_ms": 0,
            "tool_duration_ms": 0,
            "decision_duration_ms": 0,
        }

        # Checklist-driven continuation state
        turn_state = _TurnState(
            checklist=Checklist.from_skill_state(skill_state),
            _traces=traces,
        )
        # Register this user message in the message log and inject
        # the message_id into the user content so the model can link
        # checklist items to it.
        if session_id:
            now_iso = datetime.now(timezone.utc).isoformat()
            msg_id = uuid.uuid4().hex
            turn_state.current_message_id = msg_id
            try:
                from atopile.model.sqlite import MessageLog

                MessageLog.register_message(
                    TrackedMessage(
                        message_id=msg_id,
                        session_id=session_id,
                        project_root=str(project_path),
                        role="user",
                        content=user_message,
                        status=MSG_PENDING,
                        created_at=now_iso,
                        updated_at=now_iso,
                    )
                )
            except Exception:
                log.warning("Failed to register user message", exc_info=True)

        request_input.append({"role": "user", "content": user_content})

        # Consume any early steering
        steering_inputs = self._collect_steering(
            consume_steering_messages,
            session_id=session_id,
            project_root=str(project_path),
        )
        if steering_inputs:
            request_input.extend(steering_inputs)

        active_trace = trace_callback if cfg.trace_enabled else None
        last_activity_at = started_at
        await self._emit_trace(
            active_trace,
            "turn_started",
            {
                "model": cfg.model,
                "project_root": str(project_path),
                "selected_targets": list(selected),
                "history_items": len(history),
            },
        )

        async def _complete_with_telemetry(
            *,
            messages: list[dict[str, Any]],
            previous_response_id_for_call: str | None,
            loop: int,
            reason: str,
            status_text: str,
            detail_text: str,
        ) -> LLMResponse:
            nonlocal last_activity_at

            request_started_at = time.monotonic()
            decision_duration_ms = max(
                0, int((request_started_at - last_activity_at) * 1000)
            )
            telemetry["decision_duration_ms"] = (
                telemetry.get("decision_duration_ms", 0) + decision_duration_ms
            )
            await self._emit_progress(
                progress_callback,
                {
                    "phase": "thinking",
                    "step_kind": "model_request_started",
                    "loop": loop,
                    "model": cfg.model,
                    "previous_response_id": previous_response_id_for_call,
                    "duration_ms": decision_duration_ms,
                    "status_text": status_text,
                    "detail_text": detail_text,
                    "reason": reason,
                },
            )

            response = await self._provider.complete(
                messages=messages,
                instructions=instructions,
                tools=tool_defs,
                skill_state=skill_state,
                project_path=project_path,
                previous_response_id=previous_response_id_for_call,
            )

            response_received_at = time.monotonic()
            model_duration_ms = max(
                0, int((response_received_at - request_started_at) * 1000)
            )
            telemetry["model_call_count"] = telemetry.get("model_call_count", 0) + 1
            telemetry["model_duration_ms"] = (
                telemetry.get("model_duration_ms", 0) + model_duration_ms
            )

            usage_payload: dict[str, Any] = {}
            if response.usage is not None:
                if isinstance(response.usage.input_tokens, int):
                    telemetry["input_tokens"] = (
                        telemetry.get("input_tokens", 0) + response.usage.input_tokens
                    )
                    usage_payload["input_tokens"] = response.usage.input_tokens
                if isinstance(response.usage.output_tokens, int):
                    telemetry["output_tokens"] = (
                        telemetry.get("output_tokens", 0) + response.usage.output_tokens
                    )
                    usage_payload["output_tokens"] = response.usage.output_tokens
                if isinstance(response.usage.total_tokens, int):
                    telemetry["total_tokens"] = (
                        telemetry.get("total_tokens", 0) + response.usage.total_tokens
                    )
                    usage_payload["total_tokens"] = response.usage.total_tokens
                if isinstance(response.usage.reasoning_tokens, int):
                    telemetry["reasoning_tokens"] = (
                        telemetry.get("reasoning_tokens", 0)
                        + response.usage.reasoning_tokens
                    )
                    usage_payload["reasoning_tokens"] = response.usage.reasoning_tokens
                if isinstance(response.usage.cached_input_tokens, int):
                    telemetry["cached_input_tokens"] = (
                        telemetry.get("cached_input_tokens", 0)
                        + response.usage.cached_input_tokens
                    )
                    usage_payload["cached_input_tokens"] = (
                        response.usage.cached_input_tokens
                    )

            await self._emit_progress(
                progress_callback,
                {
                    "phase": "thinking",
                    "step_kind": "model_response_received",
                    "loop": loop,
                    "model": cfg.model,
                    "response_id": response.id,
                    "previous_response_id": previous_response_id_for_call,
                    "duration_ms": model_duration_ms,
                    "status_text": "Model response received",
                    "detail_text": (
                        f"{len(response.tool_calls)} tool call(s), "
                        f"phase={response.phase or 'unspecified'}"
                    ),
                    "reason": reason,
                    **usage_payload,
                },
            )

            last_activity_at = response_received_at
            return response

        # Initial LLM call
        await self._emit_progress(
            progress_callback,
            {
                "phase": "thinking",
                "status_text": "Thinking",
                "detail_text": "",
            },
        )
        response = await _complete_with_telemetry(
            messages=request_input,
            previous_response_id_for_call=previous_response_id,
            loop=0,
            reason="initial_request",
            status_text="Thinking",
            detail_text="",
        )
        last_response_id = response.id or last_response_id
        initial_preamble = _summarize_model_preamble(response.text)
        if initial_preamble and response.tool_calls:
            await self._emit_progress(
                progress_callback,
                {
                    "phase": "thinking",
                    "status_text": "Planning",
                    "detail_text": initial_preamble,
                },
            )
        log.info(
            "Initial response: status=%s, phase=%s, tool_calls=%d, text_len=%d",
            response.status,
            response.phase,
            len(response.tool_calls),
            len(response.text),
        )

        # ── Main loop ────────────────────────────────────────────────
        while loops < cfg.max_tool_loops:
            elapsed = time.monotonic() - started_at

            loops += 1
            loop_started_at = time.monotonic()
            loop_model_calls_before = telemetry.get("model_call_count", 0)
            loop_model_duration_before = telemetry.get("model_duration_ms", 0)
            loop_tool_duration_before = telemetry.get("tool_duration_ms", 0)
            loop_decision_duration_before = telemetry.get("decision_duration_ms", 0)
            loop_total_tokens_before = telemetry.get("total_tokens", 0)
            loop_reasoning_tokens_before = telemetry.get("reasoning_tokens", 0)
            loop_cached_input_tokens_before = telemetry.get("cached_input_tokens", 0)

            # No tool calls → model is done (or incomplete/interrupt)
            if not response.tool_calls:
                if elapsed >= cfg.max_turn_seconds:
                    return self._stop(
                        reason="turn_time_budget_exceeded",
                        text=_build_turn_time_budget_stop_text(elapsed, loops, traces),
                        traces=traces,
                        last_response_id=last_response_id,
                        skill_state=skill_state,
                        telemetry=telemetry,
                    )

                # Incomplete or commentary: model was cut short or is
                # still thinking. Re-prompt to continue.
                if response.status == "incomplete" or response.phase == "commentary":
                    log.info(
                        "Model incomplete/commentary (status=%s, phase=%s), "
                        "re-prompting",
                        response.status,
                        response.phase,
                    )
                    response = await _complete_with_telemetry(
                        messages=[],
                        previous_response_id_for_call=last_response_id,
                        loop=loops,
                        reason="continuation",
                        status_text="Working",
                        detail_text="Continuing",
                    )
                    last_response_id = response.id or last_response_id
                    continue

                # Check for interrupt/stop before ending
                interrupt_messages = self._collect_interrupts(
                    consume_interrupt_messages
                )
                stop_now = self._is_stop_requested(stop_requested)
                stop_steering_messages = (
                    _consume_steering_updates(consume_steering_messages)
                    if stop_now and not interrupt_messages
                    else []
                )
                if interrupt_messages or stop_now:
                    response = await self._provider.complete(
                        messages=(
                            _build_interrupt_inputs_for_model(interrupt_messages)
                            if interrupt_messages
                            else (
                                _build_interrupt_inputs_for_model(
                                    stop_steering_messages
                                )
                                if stop_steering_messages
                                else _build_stop_inputs_for_model()
                            )
                        ),
                        instructions=instructions,
                        tools=[],
                        skill_state=skill_state,
                        project_path=project_path,
                        previous_response_id=last_response_id,
                    )
                    last_response_id = response.id or last_response_id
                    if turn_state.checklist is not None:
                        turn_state.checklist.save_to_skill_state(skill_state)
                    return AgentTurnResult(
                        text=response.text or "Stopped.",
                        tool_traces=traces,
                        model=cfg.model,
                        response_id=last_response_id,
                        skill_state=skill_state,
                        context_metrics=telemetry,
                    )

                # Check for steering before ending
                steering = self._collect_steering(
                    consume_steering_messages,
                    session_id=session_id,
                    project_root=str(project_path),
                )
                if steering:
                    response = await _complete_with_telemetry(
                        messages=steering,
                        previous_response_id_for_call=last_response_id,
                        loop=loops,
                        reason="steering",
                        status_text="Steering",
                        detail_text="Applying latest user guidance",
                    )
                    last_response_id = response.id or last_response_id
                    continue

                # If the checklist has in-progress items, give the model
                # one chance to finalize them before ending the turn.
                cl = turn_state.checklist
                if (
                    cl is not None
                    and not turn_state.checklist_finalized
                    and any(i.status == "doing" for i in cl.items)
                ):
                    turn_state.checklist_finalized = True
                    response = await _complete_with_telemetry(
                        messages=[
                            {
                                "role": "user",
                                "content": (
                                    "You have checklist items still marked "
                                    "'doing'. Update them to 'done' or "
                                    "'blocked' before finishing."
                                ),
                            }
                        ],
                        previous_response_id_for_call=last_response_id,
                        loop=loops,
                        reason="checklist_finalize",
                        status_text="Finalizing",
                        detail_text="Updating checklist",
                    )
                    last_response_id = response.id or last_response_id
                    # If the model called tools (checklist_update), loop
                    # back to process them. Otherwise fall through to end.
                    if response.tool_calls:
                        continue

                # Model stopped calling tools → turn is over.
                if turn_state.checklist is not None:
                    turn_state.checklist.save_to_skill_state(skill_state)

                text = response.text or ""
                done_payload: dict[str, Any] = {
                    "phase": "done",
                    "loop": loops,
                    "tool_calls_total": len(traces),
                }
                if turn_state.checklist is not None:
                    done_payload["checklist"] = turn_state.checklist.to_dict()
                await self._emit_progress(progress_callback, done_payload)
                return AgentTurnResult(
                    text=text,
                    tool_traces=traces,
                    model=cfg.model,
                    response_id=last_response_id,
                    skill_state=skill_state,
                    context_metrics=telemetry,
                )

            # Execute tool calls
            outputs: list[dict[str, Any]] = []
            tool_count = len(response.tool_calls)
            for tool_index, call in enumerate(response.tool_calls, start=1):
                await self._emit_progress(
                    progress_callback,
                    {
                        "phase": "tool_start",
                        "loop": loops,
                        "tool_index": tool_index,
                        "tool_count": tool_count,
                        "call_id": call.id,
                        "name": call.name,
                        "args": call.arguments,
                    },
                )
                await self._emit_trace(
                    active_trace,
                    "tool_call_started",
                    {
                        "loop": loops,
                        "tool_index": tool_index,
                        "tool_count": tool_count,
                        "call_id": call.id,
                        "name": call.name,
                        "parsed_arguments": call.arguments,
                    },
                )

                # Intercept managed tools — handled in-process, not
                # dispatched to the registry.
                tool_started_at = time.monotonic()

                if call.name in _MANAGED_TOOLS:
                    args = call.arguments or {}
                    result_payload, ok = self._handle_managed_tool(
                        call.name,
                        args,
                        turn_state,
                        skill_state,
                        session_id=session_id,
                        project_root=str(project_path),
                    )
                    # Emit structured questions to frontend
                    if call.name == "design_questions" and ok:
                        await self._emit_progress(
                            progress_callback,
                            {
                                "phase": "design_questions",
                                "context": (call.arguments or {}).get("context", ""),
                                "questions": (call.arguments or {}).get(
                                    "questions", []
                                ),
                            },
                        )
                else:
                    args, result_payload, ok = await self._execute_tool(
                        tool_name=call.name,
                        raw_args=call.arguments_raw,
                        parsed_args=call.arguments,
                        project_path=project_path,
                        ctx=ctx,
                    )
                tool_duration_ms = max(
                    0, int((time.monotonic() - tool_started_at) * 1000)
                )
                telemetry["tool_call_count"] = telemetry.get("tool_call_count", 0) + 1
                telemetry["tool_duration_ms"] = (
                    telemetry.get("tool_duration_ms", 0) + tool_duration_ms
                )
                last_activity_at = time.monotonic()

                trace = ToolTrace(
                    name=call.name, args=args, ok=ok, result=result_payload
                )
                traces.append(trace)

                if ok:
                    breaker.record_success()
                    if call.name in _WORK_TOOLS:
                        telemetry["work_tool_count"] = (
                            telemetry.get("work_tool_count", 0) + 1
                        )
                    elif call.name in _CHECKLIST_TOOLS:
                        telemetry["checklist_tool_count"] = (
                            telemetry.get("checklist_tool_count", 0) + 1
                        )

                    # When a datasheet is uploaded, add file_search
                    # to the tools so the model can query it, and start
                    # a background task to notify when indexing completes.
                    vs_id = result_payload.get("vector_store_id")
                    file_id_for_vs = result_payload.get("openai_file_id")
                    if (
                        isinstance(vs_id, str)
                        and vs_id
                        and vs_id not in vector_store_ids
                    ):
                        vector_store_ids.append(vs_id)
                        tool_defs = [
                            t for t in tool_defs if t.get("type") != "file_search"
                        ]
                        tool_defs.append(
                            {
                                "type": "file_search",
                                "vector_store_ids": list(vector_store_ids),
                            }
                        )
                        if isinstance(file_id_for_vs, str) and file_id_for_vs:
                            filename = result_payload.get("filename", "datasheet")
                            turn_state.background.add(
                                f"index:{filename}",
                                _wait_for_indexing(vs_id, file_id_for_vs, filename),
                            )
                else:
                    trip_msg = breaker.record_failure(
                        call.name, args, str(result_payload.get("error", ""))
                    )
                    if trip_msg:
                        result_payload["circuit_breaker"] = trip_msg
                        await self._emit_trace(
                            active_trace,
                            "circuit_breaker",
                            {"tool": call.name, "message": trip_msg},
                        )

                tool_end_payload: dict[str, Any] = {
                    "phase": "tool_end",
                    "loop": loops,
                    "tool_index": tool_index,
                    "tool_count": tool_count,
                    "call_id": call.id,
                    "duration_ms": tool_duration_ms,
                    "trace": {
                        "name": call.name,
                        "args": args,
                        "ok": ok,
                        "result": result_payload,
                    },
                }
                # Attach checklist snapshot whenever it changes
                if call.name in _MANAGED_TOOLS and turn_state.checklist:
                    tool_end_payload["checklist"] = turn_state.checklist.to_dict()
                await self._emit_progress(progress_callback, tool_end_payload)
                await self._emit_trace(
                    active_trace,
                    "tool_call_completed",
                    {
                        "loop": loops,
                        "call_id": call.id,
                        "name": call.name,
                        "ok": ok,
                        "arguments": args,
                        "result": _summarize_tool_result_for_trace(
                            result_payload, max_chars=cfg.trace_preview_max_chars
                        ),
                    },
                )

                # Build function call output for model
                outputs.extend(
                    _build_function_call_outputs_for_model(
                        call_id=call.id,
                        tool_name=call.name,
                        result_payload=_limit_tool_output_for_model(
                            _sanitize_tool_output_for_model(result_payload),
                            max_chars=cfg.tool_output_max_chars,
                        ),
                    )
                )

            # Force turn end (e.g. after design_questions)
            if turn_state.force_turn_end:
                log.info("Force turn end (loop=%d, traces=%d)", loops, len(traces))
                last_response_id = await self._close_provider_tool_chain(
                    outputs=outputs,
                    instructions=instructions,
                    skill_state=skill_state,
                    project_path=project_path,
                    previous_response_id=last_response_id,
                    active_trace=active_trace,
                    loops=loops,
                    reason="force_turn_end",
                )
                if turn_state.checklist is not None:
                    turn_state.checklist.save_to_skill_state(skill_state)
                await self._emit_trace(
                    active_trace,
                    "turn_completed",
                    {
                        "loop": loops,
                        "tool_calls_total": len(traces),
                        "reason": "design_questions",
                    },
                )
                done_payload: dict[str, Any] = {
                    "phase": "done",
                    "loop": loops,
                    "tool_calls_total": len(traces),
                    "reason": "design_questions",
                }
                if turn_state.checklist is not None:
                    done_payload["checklist"] = turn_state.checklist.to_dict()
                await self._emit_progress(progress_callback, done_payload)
                return AgentTurnResult(
                    text="",
                    tool_traces=traces,
                    model=cfg.model,
                    response_id=last_response_id,
                    skill_state=skill_state,
                    context_metrics=telemetry,
                )

            interrupt_messages = self._collect_interrupts(consume_interrupt_messages)
            stop_now = self._is_stop_requested(stop_requested)
            stop_steering_messages = (
                _consume_steering_updates(consume_steering_messages)
                if stop_now and not interrupt_messages
                else []
            )

            # Append steering if available
            steering = (
                []
                if stop_steering_messages
                else self._collect_steering(
                    consume_steering_messages,
                    session_id=session_id,
                    project_root=str(project_path),
                )
            )
            if steering and not interrupt_messages and not stop_now:
                outputs.extend(steering)

            # Inject messages from completed background tasks
            bg_messages = turn_state.background.collect_completed()
            if bg_messages:
                outputs.extend(bg_messages)

            elapsed_after_tools = time.monotonic() - started_at
            if elapsed_after_tools >= cfg.max_turn_seconds:
                last_response_id = await self._close_provider_tool_chain(
                    outputs=outputs,
                    instructions=instructions,
                    skill_state=skill_state,
                    project_path=project_path,
                    previous_response_id=last_response_id,
                    active_trace=active_trace,
                    loops=loops,
                    reason="turn_time_budget_exceeded",
                )
                return self._stop(
                    reason="turn_time_budget_exceeded",
                    text=_build_turn_time_budget_stop_text(
                        elapsed_after_tools, loops, traces
                    ),
                    traces=traces,
                    last_response_id=last_response_id,
                    skill_state=skill_state,
                    telemetry=telemetry,
                )

            if interrupt_messages or stop_now:
                await self._emit_progress(
                    progress_callback,
                    {
                        "phase": "thinking",
                        "status_text": "Stopping",
                        "detail_text": (
                            "Responding to your interruption"
                            if interrupt_messages
                            else (
                                "Reviewing your latest guidance before stopping"
                                if stop_steering_messages
                                else "Preparing a handoff"
                            )
                        ),
                        "loop": loops,
                        "tool_calls_total": len(traces),
                    },
                )
                response = await self._provider.complete(
                    messages=outputs
                    + (
                        _build_interrupt_inputs_for_model(interrupt_messages)
                        if interrupt_messages
                        else (
                            _build_interrupt_inputs_for_model(stop_steering_messages)
                            if stop_steering_messages
                            else _build_stop_inputs_for_model()
                        )
                    ),
                    instructions=instructions,
                    tools=[],
                    skill_state=skill_state,
                    project_path=project_path,
                    previous_response_id=last_response_id,
                )
                last_response_id = response.id or last_response_id
                if turn_state.checklist is not None:
                    turn_state.checklist.save_to_skill_state(skill_state)
                return AgentTurnResult(
                    text=response.text or "Stopped.",
                    tool_traces=traces,
                    model=cfg.model,
                    response_id=last_response_id,
                    skill_state=skill_state,
                    context_metrics=telemetry,
                )

            # Thinking progress
            await self._emit_progress(
                progress_callback,
                {
                    "phase": "thinking",
                    "status_text": "Reviewing tool results",
                    "detail_text": "Choosing next step",
                    "loop": loops,
                    "tool_calls_total": len(traces),
                },
            )

            # Next LLM call with tool results
            response = await _complete_with_telemetry(
                messages=outputs,
                previous_response_id_for_call=last_response_id,
                loop=loops,
                reason="tool_results",
                status_text="Reviewing tool results",
                detail_text="Choosing next step",
            )
            last_response_id = response.id or last_response_id
            checklist_remaining = 0
            if turn_state.checklist is not None:
                checklist_remaining = len(turn_state.checklist.incomplete_items())
            await self._emit_progress(
                progress_callback,
                {
                    "phase": "thinking",
                    "step_kind": "loop_summary",
                    "loop": loops,
                    "model": cfg.model,
                    "duration_ms": max(
                        0, int((time.monotonic() - loop_started_at) * 1000)
                    ),
                    "model_call_count": (
                        telemetry.get("model_call_count", 0) - loop_model_calls_before
                    ),
                    "model_duration_ms": (
                        telemetry.get("model_duration_ms", 0)
                        - loop_model_duration_before
                    ),
                    "tool_duration_ms": (
                        telemetry.get("tool_duration_ms", 0) - loop_tool_duration_before
                    ),
                    "decision_duration_ms": (
                        telemetry.get("decision_duration_ms", 0)
                        - loop_decision_duration_before
                    ),
                    "tool_count": tool_count,
                    "checklist_remaining": checklist_remaining,
                    "total_tokens": (
                        telemetry.get("total_tokens", 0) - loop_total_tokens_before
                    ),
                    "reasoning_tokens": (
                        telemetry.get("reasoning_tokens", 0)
                        - loop_reasoning_tokens_before
                    ),
                    "cached_input_tokens": (
                        telemetry.get("cached_input_tokens", 0)
                        - loop_cached_input_tokens_before
                    ),
                    "status_text": "Loop summary",
                    "detail_text": "Loop telemetry recorded",
                },
            )

        # Exhausted loop budget
        return self._stop(
            reason="too_many_tool_iterations",
            text="Stopped after too many tool iterations.",
            traces=traces,
            last_response_id=last_response_id,
            skill_state=skill_state,
            telemetry=telemetry,
        )

    # ── Private helpers ───────────────────────────────────────────────

    async def _execute_tool(
        self,
        *,
        tool_name: str,
        raw_args: str,
        parsed_args: dict[str, Any] | None,
        project_path: Path,
        ctx: AppContext,
    ) -> tuple[dict[str, Any], dict[str, Any], bool]:
        """Execute a tool call with auto-remap retry for project_edit_file."""
        args: dict[str, Any] = parsed_args if parsed_args is not None else {}
        ok = True
        try:
            if parsed_args is None:
                args = _legacy_tools.parse_tool_arguments(raw_args)
            result_payload = await self._registry.execute(
                tool_name, args, project_path, ctx
            )
        except Exception as exc:
            ok = False
            remaps = getattr(exc, "remaps", None)
            auto_remap_attempted = False

            # Auto-remap retry for project_edit_file
            if tool_name == "project_edit_file" and isinstance(remaps, dict):
                remapped_args, did_remap = _apply_project_edit_remaps(args, remaps)
                if did_remap:
                    auto_remap_attempted = True
                    try:
                        result_payload = await self._registry.execute(
                            tool_name, remapped_args, project_path, ctx
                        )
                        args = remapped_args
                        ok = True
                        if isinstance(result_payload, dict):
                            result_payload = dict(result_payload)
                            result_payload["auto_remap_retry"] = True
                    except Exception as remap_exc:
                        args = remapped_args
                        exc = remap_exc
                        remaps = getattr(remap_exc, "remaps", None)

            if not ok:
                result_payload = {
                    "error": str(exc),
                    "error_type": type(exc).__name__,
                }
                if auto_remap_attempted:
                    result_payload["auto_remap_retry"] = True
                if isinstance(remaps, dict):
                    result_payload["remaps"] = remaps
                mismatches = getattr(exc, "mismatches", None)
                if isinstance(mismatches, list):
                    result_payload["mismatches"] = [
                        {
                            "line": getattr(m, "line", None),
                            "expected": getattr(m, "expected", None),
                            "actual": getattr(m, "actual", None),
                        }
                        for m in mismatches
                    ]

        return args, result_payload, ok

    def _stop(
        self,
        *,
        reason: str,
        text: str,
        traces: list[ToolTrace],
        last_response_id: str | None,
        skill_state: dict[str, Any],
        telemetry: dict[str, Any],
    ) -> AgentTurnResult:
        return AgentTurnResult(
            text=text,
            tool_traces=traces,
            model=self._config.model,
            response_id=last_response_id,
            skill_state=skill_state,
            context_metrics=telemetry,
        )

    async def _close_provider_tool_chain(
        self,
        *,
        outputs: list[dict[str, Any]],
        instructions: str,
        skill_state: dict[str, Any],
        project_path: Path,
        previous_response_id: str | None,
        active_trace: TraceCallback | None,
        loops: int,
        reason: str,
    ) -> str | None:
        if not outputs:
            return previous_response_id

        closing_response = await self._provider.complete(
            messages=outputs,
            instructions=instructions,
            tools=[],
            skill_state=skill_state,
            project_path=project_path,
            previous_response_id=previous_response_id,
        )
        next_response_id = closing_response.id or previous_response_id
        if closing_response.tool_calls:
            await self._emit_trace(
                active_trace,
                "provider_chain_closed_with_ignored_tool_calls",
                {
                    "loop": loops,
                    "reason": reason,
                    "tool_calls_total": len(closing_response.tool_calls),
                    "tool_names": [call.name for call in closing_response.tool_calls],
                },
            )
        return next_response_id

    @staticmethod
    def _handle_managed_tool(
        tool_name: str,
        args: dict[str, Any],
        state: _TurnState,
        skill_state: dict[str, Any],
        *,
        session_id: str = "",
        project_root: str = "",
    ) -> tuple[dict[str, Any], bool]:
        """Handle checklist + message + planning tools in-process."""
        try:
            # ── Planning tools ─────────────────────────────────────
            if tool_name == "design_questions":
                questions = args.get("questions", [])
                if not questions:
                    return {"error": "questions list is empty"}, False
                if state.checklist is not None:
                    for item in state.checklist.items:
                        if item.id == "questions" and item.status in {
                            "not_started",
                            "doing",
                        }:
                            item.status = "done"
                            break
                    state.checklist.save_to_skill_state(skill_state)
                # Signal the runner to end the turn after this tool call.
                state.force_turn_end = True
                return {
                    "ok": True,
                    "status": "questions_sent",
                    "question_count": len(questions),
                    "message": (
                        "Design questions sent to the user. "
                        "Your turn is ending now — the user's answers "
                        "will arrive as a new message."
                    ),
                }, True

            # ── Message tools ──────────────────────────────────────
            if tool_name == "message_acknowledge":
                message_id = str(args.get("message_id", ""))
                justification = str(args.get("justification", "")).strip()
                if not message_id or not justification:
                    return {"error": "message_id and justification are required"}, False
                if len(justification.split()) < 3:
                    return {
                        "error": (
                            "Justification must be a meaningful sentence "
                            "(at least a few words explaining why no action is needed)."
                        )
                    }, False
                try:
                    from atopile.model.sqlite import MessageLog

                    msg = MessageLog.get_message(message_id)
                    if msg is None:
                        return {"error": f"Message '{message_id}' not found."}, False
                    if msg.status != MSG_PENDING:
                        return {
                            "error": (
                                f"Message '{message_id}' has status "
                                f"'{msg.status}', expected 'pending'."
                            )
                        }, False
                    MessageLog.update_message_status(
                        message_id, MSG_ACKNOWLEDGED, justification
                    )
                except ImportError:
                    return {"error": "MessageLog not available"}, False
                return {
                    "ok": True,
                    "message_id": message_id,
                    "status": MSG_ACKNOWLEDGED,
                }, True

            if tool_name == "message_log_query":
                scope = str(args.get("scope", "thread"))
                q_status = args.get("status")
                q_search = args.get("search")
                include_items = bool(args.get("include_items", False))
                q_limit = int(args.get("limit", 20))
                try:
                    from atopile.model.sqlite import MessageLog

                    query_kwargs: dict[str, Any] = {
                        "status": q_status,
                        "search": q_search,
                        "include_items": include_items,
                        "limit": q_limit,
                    }
                    if scope == "project":
                        query_kwargs["project_root"] = project_root
                    else:
                        query_kwargs["session_id"] = session_id
                    result = MessageLog.query(**query_kwargs)
                except ImportError:
                    result = {"messages": [], "total": 0}
                return result, True

            # ── Checklist tools ──────────────────────────────────
            if tool_name == "checklist_create":
                raw_items = args.get("items", [])
                if not raw_items:
                    return {"error": "items list is empty"}, False

                now_iso = datetime.now(timezone.utc).isoformat()
                existing = state.checklist
                created = existing is None
                if existing is None:
                    state.checklist = Checklist(items=[], created_at=time.time())
                    existing = state.checklist

                added: list[ChecklistItem] = []
                for it in raw_items:
                    item = ChecklistItem(
                        id=_next_checklist_item_id(existing.items),
                        description=str(it["description"]),
                        criteria=str(it["criteria"]),
                        requirement_id=it.get("requirement_id"),
                        source=it.get("source"),
                        message_id=_resolve_message_id(
                            it.get("message_id"), state.current_message_id
                        ),
                    )
                    existing.items.append(item)
                    added.append(item)

                state.checklist.save_to_skill_state(skill_state)

                # Persist items and update linked messages
                if session_id:
                    try:
                        from atopile.model.sqlite import MessageLog

                        linked_message_ids: set[str] = set()
                        for item in added:
                            MessageLog.save_checklist_item(
                                TrackedChecklistItem(
                                    item_id=item.id,
                                    session_id=session_id,
                                    message_id=item.message_id,
                                    description=item.description,
                                    criteria=item.criteria,
                                    status=item.status,
                                    requirement_id=item.requirement_id,
                                    source=item.source,
                                    created_at=now_iso,
                                    updated_at=now_iso,
                                )
                            )
                            if item.message_id:
                                linked_message_ids.add(item.message_id)
                        for mid in linked_message_ids:
                            msg = MessageLog.get_message(mid)
                            if msg and msg.status == MSG_PENDING:
                                MessageLog.update_message_status(mid, MSG_ACTIVE)
                    except Exception:
                        log.warning("Failed to persist checklist items", exc_info=True)

                if created:
                    message = f"Checklist created with {len(added)} items."
                else:
                    message = f"Checklist already existed. Added {len(added)} item(s)."
                return {
                    "ok": True,
                    "message": message,
                    "added": len(added),
                    "skipped": [],
                    "checklist": state.checklist.summary_text(),
                }, True

            elif tool_name == "checklist_add_items":
                if state.checklist is None:
                    return {
                        "error": "No checklist exists. Call checklist_create first."
                    }, False
                raw_items = args.get("items", [])
                if not raw_items:
                    return {"error": "items list is empty"}, False

                now_iso = datetime.now(timezone.utc).isoformat()
                added: list[ChecklistItem] = []
                for it in raw_items:
                    item = ChecklistItem(
                        id=_next_checklist_item_id(state.checklist.items + added),
                        description=str(it["description"]),
                        criteria=str(it["criteria"]),
                        requirement_id=it.get("requirement_id"),
                        source=it.get("source"),
                        message_id=_resolve_message_id(
                            it.get("message_id"), state.current_message_id
                        ),
                    )
                    added.append(item)
                state.checklist.items.extend(added)
                state.checklist.save_to_skill_state(skill_state)

                # Persist items and update linked messages
                if session_id:
                    try:
                        from atopile.model.sqlite import MessageLog

                        linked_message_ids: set[str] = set()
                        for item in added:
                            MessageLog.save_checklist_item(
                                TrackedChecklistItem(
                                    item_id=item.id,
                                    session_id=session_id,
                                    message_id=item.message_id,
                                    description=item.description,
                                    criteria=item.criteria,
                                    status=item.status,
                                    requirement_id=item.requirement_id,
                                    source=item.source,
                                    created_at=now_iso,
                                    updated_at=now_iso,
                                )
                            )
                            if item.message_id:
                                linked_message_ids.add(item.message_id)
                        for mid in linked_message_ids:
                            msg = MessageLog.get_message(mid)
                            if msg and msg.status == MSG_PENDING:
                                MessageLog.update_message_status(mid, MSG_ACTIVE)
                    except Exception:
                        log.warning(
                            "Failed to persist added checklist items", exc_info=True
                        )

                msg = f"Added {len(added)} item(s)."
                return {
                    "ok": True,
                    "message": msg,
                    "added": len(added),
                    "skipped": [],
                    "checklist": state.checklist.summary_text(),
                }, True

            elif tool_name == "checklist_update":
                if state.checklist is None:
                    return {
                        "error": "No checklist exists. Call checklist_create first."
                    }, False
                item_id = str(args.get("item_id", ""))
                new_status = str(args.get("status", ""))
                justification = args.get("justification")
                target = _resolve_checklist_item(state.checklist.items, item_id)
                if target is None:
                    return {"error": f"Item '{item_id}' not found."}, False
                canonical_item_id = target.id
                # Treat same-status transitions as a harmless no-op.
                # This avoids errors when auto-doing already moved an
                # item to "doing" before the model explicitly requests it.
                if target.status == new_status:
                    return {
                        "ok": True,
                        "item_id": canonical_item_id,
                        "status": new_status,
                        "noop": True,
                        "checklist": state.checklist.summary_text(),
                    }, True
                allowed = VALID_TRANSITIONS.get(target.status, set())
                if new_status not in allowed:
                    return {
                        "error": (
                            f"Cannot transition '{canonical_item_id}' from "
                            f"'{target.status}' to '{new_status}'. "
                            f"Allowed: {sorted(allowed) or 'none (terminal)'}."
                        )
                    }, False
                target.status = new_status
                if justification:
                    target.justification = str(justification)
                state.checklist.save_to_skill_state(skill_state)

                # Persist status change and check for message completion
                if session_id:
                    try:
                        from atopile.model.sqlite import MessageLog

                        MessageLog.update_checklist_item(
                            session_id,
                            canonical_item_id,
                            new_status,
                            str(justification) if justification else None,
                        )
                        MessageLog.check_and_complete_messages(session_id)
                    except Exception:
                        log.warning("Failed to persist checklist update", exc_info=True)

                # Auto-inject design review items when the last
                # user-created item becomes terminal and .ato files
                # were modified.  This keeps the agent working through
                # review before the turn ends.
                result: dict[str, Any] = {
                    "ok": True,
                    "item_id": canonical_item_id,
                    "status": new_status,
                    "checklist": state.checklist.summary_text(),
                }

                return result, True

            return {"error": f"Unknown managed tool: {tool_name}"}, False
        except Exception as exc:
            return {"error": str(exc), "error_type": type(exc).__name__}, False

    @staticmethod
    def _collect_steering(
        consume_steering_messages: SteeringMessagesCallback | None,
        session_id: str = "",
        project_root: str = "",
    ) -> list[dict[str, Any]]:
        messages = _consume_steering_updates(consume_steering_messages)
        if not messages:
            return []

        # Register steering messages in the message log
        message_ids: list[str] = []
        if session_id:
            now_iso = datetime.now(timezone.utc).isoformat()
            try:
                from atopile.model.sqlite import MessageLog

                for msg_text in messages:
                    mid = uuid.uuid4().hex
                    MessageLog.register_message(
                        TrackedMessage(
                            message_id=mid,
                            session_id=session_id,
                            project_root=project_root,
                            role="steering",
                            content=msg_text,
                            status=MSG_PENDING,
                            created_at=now_iso,
                            updated_at=now_iso,
                        )
                    )
                    message_ids.append(mid)
            except Exception:
                log.warning("Failed to register steering messages", exc_info=True)

        return _build_steering_inputs_for_model(messages, message_ids=message_ids)

    @staticmethod
    def _collect_interrupts(
        consume_interrupt_messages: InterruptMessagesCallback | None,
    ) -> list[str]:
        if consume_interrupt_messages is None:
            return []
        try:
            raw_messages = consume_interrupt_messages()
        except Exception:
            log.warning("Interrupt message callback failed", exc_info=True)
            return []
        if not isinstance(raw_messages, list):
            return []

        messages: list[str] = []
        for raw_message in raw_messages:
            if not isinstance(raw_message, str):
                continue
            stripped = raw_message.strip()
            if stripped:
                messages.append(stripped[:2000])
        return messages

    @staticmethod
    def _is_stop_requested(stop_requested: StopRequestedCallback | None) -> bool:
        if stop_requested is None:
            return False
        try:
            return bool(stop_requested())
        except Exception:
            log.warning("Stop request callback failed", exc_info=True)
            return False

    @staticmethod
    async def _emit_progress(
        callback: ProgressCallback | None,
        payload: dict[str, Any],
    ) -> None:
        if callback is None:
            return
        maybe = callback(payload)
        if inspect.isawaitable(maybe):
            await maybe

    @staticmethod
    async def _emit_trace(
        callback: TraceCallback | None,
        event: str,
        payload: dict[str, Any],
    ) -> None:
        if callback is None:
            return
        maybe = callback(event, payload)
        if inspect.isawaitable(maybe):
            await maybe


# ----------------------------------------
#                 Tests
# ----------------------------------------


class _StubProvider:
    def __init__(self) -> None:
        self.calls: list[dict[str, object]] = []

    async def complete(
        self,
        *,
        messages,
        instructions,
        tools,
        skill_state,
        project_path,
        previous_response_id=None,
    ) -> LLMResponse:
        self.calls.append(
            {
                "messages": messages,
                "instructions": instructions,
                "tools": tools,
                "skill_state": dict(skill_state),
                "project_path": str(project_path),
                "previous_response_id": previous_response_id,
            }
        )
        if len(self.calls) == 1:
            return LLMResponse(
                id="resp_tool_call",
                text="",
                tool_calls=[
                    ToolCall(
                        id="call_design_1",
                        name="design_questions",
                        arguments_raw=(
                            '{"context":"Need preferences","questions":['
                            '{"id":"Q1","question":"Pick one","options":["A","B"],'
                            '"default":"A"}]}'
                        ),
                        arguments={
                            "context": "Need preferences",
                            "questions": [
                                {
                                    "id": "Q1",
                                    "question": "Pick one",
                                    "options": ["A", "B"],
                                    "default": "A",
                                }
                            ],
                        },
                    )
                ],
                phase=None,
            )
        return LLMResponse(
            id="resp_closed",
            text="Questions sent.",
            tool_calls=[],
            phase="final_answer",
        )


class _StubRegistry:
    def definitions(self) -> list[dict[str, object]]:
        return [{"type": "function", "name": "design_questions"}]


class TestRunner:
    def test_design_questions_force_end_closes_provider_chain(
        self, monkeypatch, tmp_path: Path
    ) -> None:
        project_root = tmp_path / "project"
        project_root.mkdir()
        (project_root / "ato.yaml").write_text("builds: {}\n", encoding="utf-8")

        monkeypatch.setattr(
            "atopile.agent.runner.build_system_prompt",
            lambda **_: ("system prompt", {}),
        )

        async def _fake_initial_user_message(**_: object) -> str:
            return "user message"

        monkeypatch.setattr(
            "atopile.agent.runner.build_initial_user_message",
            _fake_initial_user_message,
        )

        provider = _StubProvider()
        runner = AgentRunner(
            config=type(
                "Cfg",
                (),
                {
                    "model": "test-model",
                    "max_tool_loops": 4,
                    "max_turn_seconds": 60,
                    "trace_enabled": False,
                    "trace_preview_max_chars": 200,
                    "tool_output_max_chars": 10_000,
                    "context_summary_max_chars": 2_000,
                    "user_message_max_chars": 2_000,
                },
            )(),
            provider=provider,
            registry=_StubRegistry(),
        )

        import asyncio

        result = asyncio.run(
            runner.run_turn(
                ctx=AppContext(workspace_paths=[project_root.parent]),
                project_root=str(project_root),
                history=[],
                user_message="Build a robot controller",
                session_id="session_1",
            )
        )

        assert result.response_id == "resp_closed"
        assert result.text == ""
        assert len(provider.calls) == 2
        assert provider.calls[1]["previous_response_id"] == "resp_tool_call"
        assert provider.calls[1]["tools"] == []
        outputs = provider.calls[1]["messages"]
        assert isinstance(outputs, list)
        assert outputs[0]["type"] == "function_call_output"
        assert outputs[0]["call_id"] == "call_design_1"

    def test_design_questions_marks_questions_checklist_item_done(
        self, monkeypatch, tmp_path: Path
    ) -> None:
        project_root = tmp_path / "project"
        project_root.mkdir()
        (project_root / "ato.yaml").write_text("builds: {}\n", encoding="utf-8")

        checklist = Checklist(
            items=[
                ChecklistItem(
                    id="questions",
                    description="Ask the user the remaining design questions",
                    criteria="Questions asked",
                    status="doing",
                )
            ],
            created_at=0,
        )

        monkeypatch.setattr(
            "atopile.agent.runner.build_system_prompt",
            lambda **_: ("system prompt", {"checklist": checklist.to_dict()}),
        )

        async def _fake_initial_user_message(**_: object) -> str:
            return "user message"

        monkeypatch.setattr(
            "atopile.agent.runner.build_initial_user_message",
            _fake_initial_user_message,
        )

        provider = _StubProvider()
        runner = AgentRunner(
            config=type(
                "Cfg",
                (),
                {
                    "model": "test-model",
                    "max_tool_loops": 4,
                    "max_turn_seconds": 60,
                    "trace_enabled": False,
                    "trace_preview_max_chars": 200,
                    "tool_output_max_chars": 10_000,
                    "context_summary_max_chars": 2_000,
                    "user_message_max_chars": 2_000,
                },
            )(),
            provider=provider,
            registry=_StubRegistry(),
        )

        import asyncio

        result = asyncio.run(
            runner.run_turn(
                ctx=AppContext(workspace_paths=[project_root.parent]),
                project_root=str(project_root),
                history=[],
                user_message="Build a robot controller",
                session_id="session_1",
            )
        )

        updated_checklist = result.skill_state["checklist"]["items"]
        assert updated_checklist[0]["id"] == "questions"
        assert updated_checklist[0]["status"] == "done"

    def test_model_commentary_preamble_is_emitted_as_progress(
        self, monkeypatch, tmp_path: Path
    ) -> None:
        project_root = tmp_path / "project"
        project_root.mkdir()
        (project_root / "ato.yaml").write_text("builds: {}\n", encoding="utf-8")

        monkeypatch.setattr(
            "atopile.agent.runner.build_system_prompt",
            lambda **_: ("system prompt", {}),
        )

        async def _fake_initial_user_message(**_: object) -> str:
            return "user message"

        monkeypatch.setattr(
            "atopile.agent.runner.build_initial_user_message",
            _fake_initial_user_message,
        )

        class _CommentaryProvider:
            def __init__(self) -> None:
                self.calls = 0

            async def complete(
                self,
                *,
                messages,
                instructions,
                tools,
                skill_state,
                project_path,
                previous_response_id=None,
            ) -> LLMResponse:
                self.calls += 1
                if self.calls == 1:
                    return LLMResponse(
                        id="resp_commentary",
                        text=(
                            "I'm going to inspect the project structure, then "
                            "draft the controller architecture."
                        ),
                        tool_calls=[],
                        phase="commentary",
                    )
                return LLMResponse(
                    id="resp_final",
                    text="Done.",
                    tool_calls=[],
                    phase="final_answer",
                )

        progress_events: list[dict[str, object]] = []

        async def _progress(payload: dict[str, object]) -> None:
            progress_events.append(payload)

        runner = AgentRunner(
            config=type(
                "Cfg",
                (),
                {
                    "model": "test-model",
                    "max_tool_loops": 4,
                    "max_turn_seconds": 60,
                    "trace_enabled": False,
                    "trace_preview_max_chars": 200,
                    "tool_output_max_chars": 10_000,
                    "context_summary_max_chars": 2_000,
                    "user_message_max_chars": 2_000,
                },
            )(),
            provider=_CommentaryProvider(),
            registry=_StubRegistry(),
        )

        import asyncio

        asyncio.run(
            runner.run_turn(
                ctx=AppContext(workspace_paths=[project_root.parent]),
                project_root=str(project_root),
                history=[],
                user_message="Build a robot controller",
                session_id="session_1",
                progress_callback=_progress,
            )
        )

        # Commentary phase triggers a re-prompt — provider should be
        # called twice (initial commentary + continuation).
        assert runner._provider.calls == 2

    def test_turn_timeout_closes_pending_tool_chain_before_stopping(
        self, monkeypatch, tmp_path: Path
    ) -> None:
        project_root = tmp_path / "project"
        project_root.mkdir()
        (project_root / "ato.yaml").write_text("builds: {}\n", encoding="utf-8")

        monkeypatch.setattr(
            "atopile.agent.runner.build_system_prompt",
            lambda **_: ("system prompt", {}),
        )

        async def _fake_initial_user_message(**_: object) -> str:
            return "user message"

        monkeypatch.setattr(
            "atopile.agent.runner.build_initial_user_message",
            _fake_initial_user_message,
        )

        monotonic_calls = 0

        def _fake_monotonic() -> float:
            nonlocal monotonic_calls
            monotonic_calls += 1
            # Allow the model response and tool execution path to start at
            # t=0, then advance time once the tool outputs are ready to close.
            return 0.0 if monotonic_calls < 8 else 61.0

        monkeypatch.setattr(
            "atopile.agent.runner.time.monotonic",
            _fake_monotonic,
        )

        class _TimeoutProvider:
            def __init__(self) -> None:
                self.calls: list[dict[str, object]] = []

            async def complete(
                self,
                *,
                messages,
                instructions,
                tools,
                skill_state,
                project_path,
                previous_response_id=None,
            ) -> LLMResponse:
                self.calls.append(
                    {
                        "messages": messages,
                        "tools": tools,
                        "previous_response_id": previous_response_id,
                    }
                )
                if len(self.calls) == 1:
                    return LLMResponse(
                        id="resp_tool_call",
                        text="",
                        tool_calls=[
                            ToolCall(
                                id="call_timeout_1",
                                name="project_read_file",
                                arguments_raw='{"path":"main.ato"}',
                                arguments={"path": "main.ato"},
                            )
                        ],
                        phase=None,
                    )
                return LLMResponse(
                    id="resp_closed_after_timeout",
                    text="",
                    tool_calls=[],
                    phase="final_answer",
                )

        class _TimeoutRegistry:
            def definitions(self) -> list[dict[str, object]]:
                return [{"type": "function", "name": "project_read_file"}]

            async def execute(self, tool_name, args, project_path, ctx):
                _ = tool_name, project_path, ctx
                return {"ok": True, "path": args["path"], "content": "module main"}

        runner = AgentRunner(
            config=type(
                "Cfg",
                (),
                {
                    "model": "test-model",
                    "max_tool_loops": 4,
                    "max_turn_seconds": 60,
                    "trace_enabled": False,
                    "trace_preview_max_chars": 200,
                    "tool_output_max_chars": 10_000,
                    "context_summary_max_chars": 2_000,
                    "user_message_max_chars": 2_000,
                },
            )(),
            provider=_TimeoutProvider(),
            registry=_TimeoutRegistry(),
        )

        import asyncio

        result = asyncio.run(
            runner.run_turn(
                ctx=AppContext(workspace_paths=[project_root.parent]),
                project_root=str(project_root),
                history=[],
                user_message="Build a robot controller",
                session_id="session_1",
            )
        )

        assert result.response_id == "resp_closed_after_timeout"
        assert result.text.startswith(
            "Stopped after exceeding the per-turn time budget"
        )
        assert len(runner._provider.calls) == 2
        assert runner._provider.calls[1]["previous_response_id"] == "resp_tool_call"
        assert runner._provider.calls[1]["tools"] == []
        outputs = runner._provider.calls[1]["messages"]
        assert isinstance(outputs, list)
        assert outputs[0]["type"] == "function_call_output"
        assert outputs[0]["call_id"] == "call_timeout_1"

    def test_stop_request_returns_graceful_handoff_after_tool_outputs(
        self, monkeypatch, tmp_path: Path
    ) -> None:
        project_root = tmp_path / "project"
        project_root.mkdir()
        (project_root / "ato.yaml").write_text("builds: {}\n", encoding="utf-8")

        monkeypatch.setattr(
            "atopile.agent.runner.build_system_prompt",
            lambda **_: ("system prompt", {}),
        )

        async def _fake_initial_user_message(**_: object) -> str:
            return "user message"

        monkeypatch.setattr(
            "atopile.agent.runner.build_initial_user_message",
            _fake_initial_user_message,
        )

        class _StopProvider:
            def __init__(self) -> None:
                self.calls: list[dict[str, object]] = []

            async def complete(
                self,
                *,
                messages,
                instructions,
                tools,
                skill_state,
                project_path,
                previous_response_id=None,
            ) -> LLMResponse:
                self.calls.append(
                    {
                        "messages": messages,
                        "tools": tools,
                        "previous_response_id": previous_response_id,
                    }
                )
                if len(self.calls) == 1:
                    return LLMResponse(
                        id="resp_tool_call",
                        text="",
                        tool_calls=[
                            ToolCall(
                                id="call_stop_1",
                                name="project_read_file",
                                arguments_raw='{"path":"main.ato"}',
                                arguments={"path": "main.ato"},
                            )
                        ],
                        phase=None,
                    )
                return LLMResponse(
                    id="resp_stop_handoff",
                    text=(
                        "Stopped cleanly. Completed the current read and can "
                        "resume from wrapper integration."
                    ),
                    tool_calls=[],
                    phase="final_answer",
                )

        class _StopRegistry:
            def definitions(self) -> list[dict[str, object]]:
                return [{"type": "function", "name": "project_read_file"}]

            async def execute(self, tool_name, args, project_path, ctx):
                _ = tool_name, project_path, ctx
                return {"ok": True, "path": args["path"], "content": "module main"}

        provider = _StopProvider()
        runner = AgentRunner(
            config=type(
                "Cfg",
                (),
                {
                    "model": "test-model",
                    "max_tool_loops": 4,
                    "max_turn_seconds": 60,
                    "trace_enabled": False,
                    "trace_preview_max_chars": 200,
                    "tool_output_max_chars": 10_000,
                    "context_summary_max_chars": 2_000,
                    "user_message_max_chars": 2_000,
                },
            )(),
            provider=provider,
            registry=_StopRegistry(),
        )

        import asyncio

        result = asyncio.run(
            runner.run_turn(
                ctx=AppContext(workspace_paths=[project_root.parent]),
                project_root=str(project_root),
                history=[],
                user_message="Build a robot controller",
                session_id="session_1",
                stop_requested=lambda: True,
            )
        )

        assert result.text.startswith("Stopped cleanly.")
        assert result.response_id == "resp_stop_handoff"
        assert len(provider.calls) == 2
        outputs = provider.calls[1]["messages"]
        assert isinstance(outputs, list)
        assert outputs[0]["type"] == "function_call_output"
        assert outputs[0]["call_id"] == "call_stop_1"
        assert outputs[1]["role"] == "user"
        assert "stop at the next safe boundary" in outputs[1]["content"]

    def test_interrupt_request_returns_direct_response_after_tool_outputs(
        self, monkeypatch, tmp_path: Path
    ) -> None:
        project_root = tmp_path / "project"
        project_root.mkdir()
        (project_root / "ato.yaml").write_text("builds: {}\n", encoding="utf-8")

        monkeypatch.setattr(
            "atopile.agent.runner.build_system_prompt",
            lambda **_: ("system prompt", {}),
        )

        async def _fake_initial_user_message(**_: object) -> str:
            return "user message"

        monkeypatch.setattr(
            "atopile.agent.runner.build_initial_user_message",
            _fake_initial_user_message,
        )

        class _InterruptProvider:
            def __init__(self) -> None:
                self.calls: list[dict[str, object]] = []

            async def complete(
                self,
                *,
                messages,
                instructions,
                tools,
                skill_state,
                project_path,
                previous_response_id=None,
            ) -> LLMResponse:
                self.calls.append(
                    {
                        "messages": messages,
                        "tools": tools,
                        "previous_response_id": previous_response_id,
                    }
                )
                if len(self.calls) == 1:
                    return LLMResponse(
                        id="resp_tool_call",
                        text="",
                        tool_calls=[
                            ToolCall(
                                id="call_interrupt_1",
                                name="project_read_file",
                                arguments_raw='{"path":"main.ato"}',
                                arguments={"path": "main.ato"},
                            )
                        ],
                        phase=None,
                    )
                return LLMResponse(
                    id="resp_interrupt_reply",
                    text=(
                        "The wrapper work was blocked because the MCU and driver "
                        "wrappers still needed pin mapping."
                    ),
                    tool_calls=[],
                    phase="final_answer",
                )

        class _InterruptRegistry:
            def definitions(self) -> list[dict[str, object]]:
                return [{"type": "function", "name": "project_read_file"}]

            async def execute(self, tool_name, args, project_path, ctx):
                _ = tool_name, project_path, ctx
                return {"ok": True, "path": args["path"], "content": "module main"}

        provider = _InterruptProvider()
        runner = AgentRunner(
            config=type(
                "Cfg",
                (),
                {
                    "model": "test-model",
                    "max_tool_loops": 4,
                    "max_turn_seconds": 60,
                    "trace_enabled": False,
                    "trace_preview_max_chars": 200,
                    "tool_output_max_chars": 10_000,
                    "context_summary_max_chars": 2_000,
                    "user_message_max_chars": 2_000,
                },
            )(),
            provider=provider,
            registry=_InterruptRegistry(),
        )

        import asyncio

        result = asyncio.run(
            runner.run_turn(
                ctx=AppContext(workspace_paths=[project_root.parent]),
                project_root=str(project_root),
                history=[],
                user_message="Build a robot controller",
                session_id="session_1",
                consume_interrupt_messages=lambda: [
                    "What are you blocked on for the reusable wrappers?"
                ],
                stop_requested=lambda: True,
            )
        )

        assert "blocked because" in result.text
        outputs = provider.calls[1]["messages"]
        assert isinstance(outputs, list)
        assert outputs[0]["type"] == "function_call_output"
        assert outputs[1]["role"] == "user"
        assert "wants a direct reply now" in outputs[1]["content"]

    def test_runner_emits_model_usage_and_loop_summary_progress(
        self, monkeypatch, tmp_path: Path
    ) -> None:
        project_root = tmp_path / "project"
        project_root.mkdir()
        (project_root / "ato.yaml").write_text("builds: {}\n", encoding="utf-8")

        monkeypatch.setattr(
            "atopile.agent.runner.build_system_prompt",
            lambda **_: ("system prompt", {}),
        )

        async def _fake_initial_user_message(**_: object) -> str:
            return "user message"

        monkeypatch.setattr(
            "atopile.agent.runner.build_initial_user_message",
            _fake_initial_user_message,
        )

        class _UsageProvider:
            def __init__(self) -> None:
                self.calls = 0

            async def complete(
                self,
                *,
                messages,
                instructions,
                tools,
                skill_state,
                project_path,
                previous_response_id=None,
            ) -> LLMResponse:
                _ = (
                    messages,
                    instructions,
                    tools,
                    skill_state,
                    project_path,
                    previous_response_id,
                )
                self.calls += 1
                if self.calls == 1:
                    return LLMResponse(
                        id="resp_tool",
                        text="",
                        tool_calls=[
                            ToolCall(
                                id="call_read_1",
                                name="project_read_file",
                                arguments_raw='{"path":"main.ato"}',
                                arguments={"path": "main.ato"},
                            )
                        ],
                        usage=TokenUsage(
                            input_tokens=100,
                            output_tokens=25,
                            total_tokens=125,
                            reasoning_tokens=7,
                            cached_input_tokens=80,
                        ),
                    )
                return LLMResponse(
                    id="resp_done",
                    text="Done.",
                    tool_calls=[],
                    phase="final_answer",
                    usage=TokenUsage(
                        input_tokens=50,
                        output_tokens=10,
                        total_tokens=60,
                        reasoning_tokens=3,
                        cached_input_tokens=40,
                    ),
                )

        class _UsageRegistry:
            def definitions(self) -> list[dict[str, object]]:
                return [{"type": "function", "name": "project_read_file"}]

            async def execute(self, tool_name, args, project_path, ctx):
                _ = tool_name, project_path, ctx
                return {"ok": True, "path": args["path"], "content": "module main"}

        progress_events: list[dict[str, object]] = []

        async def _progress(payload: dict[str, object]) -> None:
            progress_events.append(payload)

        runner = AgentRunner(
            config=type(
                "Cfg",
                (),
                {
                    "model": "test-model",
                    "max_tool_loops": 4,
                    "max_turn_seconds": 60,
                    "trace_enabled": False,
                    "trace_preview_max_chars": 200,
                    "tool_output_max_chars": 10_000,
                    "context_summary_max_chars": 2_000,
                    "user_message_max_chars": 2_000,
                },
            )(),
            provider=_UsageProvider(),
            registry=_UsageRegistry(),
        )

        import asyncio

        result = asyncio.run(
            runner.run_turn(
                ctx=AppContext(workspace_paths=[project_root.parent]),
                project_root=str(project_root),
                history=[],
                user_message="Build a robot controller",
                session_id="",
                prior_skill_state={
                    "checklist": Checklist(
                        items=[
                            ChecklistItem(
                                id="existing",
                                description="Already tracked",
                                criteria="Tracked",
                                status="done",
                            )
                        ],
                        created_at=0,
                    ).to_dict()
                },
                progress_callback=_progress,
            )
        )

        assert result.context_metrics["input_tokens"] == 150
        assert result.context_metrics["output_tokens"] == 35
        assert result.context_metrics["total_tokens"] == 185
        assert result.context_metrics["reasoning_tokens"] == 10
        assert result.context_metrics["cached_input_tokens"] == 120
        assert result.context_metrics["model_call_count"] == 2

        response_events = [
            event
            for event in progress_events
            if event.get("step_kind") == "model_response_received"
        ]
        assert len(response_events) == 2
        assert response_events[0]["input_tokens"] == 100
        assert response_events[0]["output_tokens"] == 25
        assert response_events[0]["total_tokens"] == 125
        assert response_events[0]["reasoning_tokens"] == 7
        assert response_events[0]["cached_input_tokens"] == 80

        loop_summaries = [
            event
            for event in progress_events
            if event.get("step_kind") == "loop_summary"
        ]
        assert len(loop_summaries) == 1
        assert loop_summaries[0]["loop"] == 1
        assert loop_summaries[0]["tool_count"] == 1
        assert loop_summaries[0]["model_call_count"] == 1
        assert loop_summaries[0]["total_tokens"] == 60
        assert loop_summaries[0]["reasoning_tokens"] == 3
        assert loop_summaries[0]["cached_input_tokens"] == 40
