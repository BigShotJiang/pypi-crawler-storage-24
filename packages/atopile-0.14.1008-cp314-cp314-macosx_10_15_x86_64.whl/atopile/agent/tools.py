"""Typed agent tools for atopile operations."""

from __future__ import annotations

import asyncio
import json
import os
from collections import OrderedDict
from dataclasses import asdict
from datetime import UTC, datetime
from io import BytesIO
from pathlib import Path
from typing import Any, Awaitable, Callable

from openai import APIConnectionError, APIStatusError, APITimeoutError, AsyncOpenAI
from pydantic import BaseModel, ConfigDict, Field, model_validator

from atopile.agent import policy
from atopile.agent.config import AgentConfig
from atopile.agent.tool_layout import (
    _layout_get_component_position,
    _layout_set_component_position,
    _resolve_layout_file_for_tool,
)
from atopile.agent.tool_references import (
    _collect_example_projects,
    _list_package_reference_files,
    _read_package_reference_file,
    _resolve_example_ato_file,
    _resolve_example_project,
    _resolve_examples_root,
    _search_example_ato_files,
    _search_package_reference_files,
)
from atopile.agent.tool_web_helpers import _exa_web_search
from atopile.data_models import (
    AddBuildTargetRequest,
    AppContext,
    Build,
    BuildRequest,
    BuildStatus,
    Log,
    ResolvedBuildTarget,
    UpdateBuildTargetRequest,
)
from atopile.logging import get_logger, read_build_logs
from atopile.model import artifacts as artifacts_domain
from atopile.model import builds as builds_domain
from atopile.model import manufacturing as manufacturing_domain
from atopile.model import module_introspection
from atopile.model import packages as packages_domain
from atopile.model import parts_search as parts_domain
from atopile.model import parts_search_jlc as parts_jlc_domain
from atopile.model import projects as projects_domain
from atopile.model import stdlib as stdlib_domain
from atopile.model.sqlite import BuildHistory

log = get_logger(__name__)

_openai_file_client: AsyncOpenAI | None = None
_OPENAI_FILE_CACHE_MAX_ENTRIES = max(
    256,
    min(
        int(os.getenv("ATOPILE_AGENT_OPENAI_FILE_CACHE_MAX_ENTRIES", "4096")),
        200_000,
    ),
)
_DATASHEET_READ_CACHE_MAX_ENTRIES = max(
    256,
    min(
        int(os.getenv("ATOPILE_AGENT_DATASHEET_READ_CACHE_MAX_ENTRIES", "4096")),
        200_000,
    ),
)
_openai_file_cache: OrderedDict[str, str] = OrderedDict()
_datasheet_read_cache: OrderedDict[str, dict[str, Any]] = OrderedDict()
_EXPECTED_MANUFACTURING_OUTPUT_KEYS: tuple[str, ...] = (
    "gerbers",
    "bom_json",
    "bom_csv",
    "pick_and_place",
    "step",
    "glb",
    "kicad_pcb",
    "kicad_sch",
    "pcb_summary",
)
_DEFAULT_BUILD_LOG_LEVELS: tuple[Log.Level, ...] = (
    Log.Level.INFO,
    Log.Level.WARNING,
    Log.Level.ERROR,
    Log.Level.ALERT,
)


class _BuildLogsSearchRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    build_id: str | None = None
    query: str | None = None
    stage: str | None = None
    log_levels: list[Log.Level] = Field(
        default_factory=lambda: list(_DEFAULT_BUILD_LOG_LEVELS)
    )
    audience: Log.Audience | None = None
    limit: int = Field(default=200, ge=1, le=1000)

    @model_validator(mode="before")
    @classmethod
    def _normalize(cls, value: Any) -> Any:
        if not isinstance(value, dict):
            return value

        normalized = dict(value)
        for key in ("build_id", "query", "stage"):
            entry = normalized.get(key)
            if isinstance(entry, str):
                normalized[key] = entry.strip() or None
        if not normalized.get("log_levels"):
            normalized["log_levels"] = list(_DEFAULT_BUILD_LOG_LEVELS)
        return normalized


def _trim_message(text: str | None, limit: int = 2200) -> str:
    if not text:
        return ""
    if len(text) <= limit:
        return text
    return text[: limit - 3].rstrip() + "..."


def _normalize_history_build(build: Build) -> dict[str, Any]:
    return {
        "build_id": build.build_id,
        "project_root": build.project_root,
        "target": build.target.model_dump(mode="json", by_alias=True),
        "status": build.status.value,
        "started_at": build.started_at,
        "elapsed_seconds": build.elapsed_seconds,
        "warnings": build.warnings,
        "errors": build.errors,
        "return_code": build.return_code,
        "error": _trim_message(build.error),
        "timestamp": build.started_at,
    }


def _build_empty_log_stub(
    *,
    build_id: str,
    query: str,
    build: Build | None,
) -> dict[str, Any]:
    status = build.status.value if build is not None else "unknown"
    return_code = build.return_code if build is not None else None
    error_message = _trim_message(build.error if build is not None else None)

    intro = (
        f"No log lines matched query '{query}'."
        if query
        else "No log lines were captured for this build."
    )
    details = [f"status={status}"]
    if return_code is not None:
        details.append(f"return_code={return_code}")
    if error_message:
        details.append(f"error={error_message}")

    return {
        "timestamp": None,
        "stage": "agent_diagnostic",
        "level": "ERROR" if status == BuildStatus.FAILED.value else "INFO",
        "logger_name": "atopile.agent",
        "audience": "developer",
        "message": f"{intro} {'; '.join(details)}",
        "build_id": build_id,
        "synthetic": True,
    }


def _datasheet_cache_key(*, project_root: Path, source_type: str, source: str) -> str:
    root = str(project_root.resolve())
    return f"{root}|{source_type}:{source.strip()}"


def _cache_get_lru[T](cache: OrderedDict[str, T], key: str) -> T | None:
    value = cache.get(key)
    if value is None:
        return None
    cache.move_to_end(key)
    return value


def _cache_set_lru[T](
    cache: OrderedDict[str, T],
    key: str,
    value: T,
    *,
    max_entries: int,
) -> None:
    cache[key] = value
    cache.move_to_end(key)
    while len(cache) > max_entries:
        cache.popitem(last=False)


def _datasheet_cache_keys(
    *,
    project_root: Path,
    lcsc_id: str | None = None,
    url: str | None = None,
    path: str | None = None,
    source_kind: str | None = None,
    source: str | None = None,
) -> list[str]:
    keys: list[str] = []
    seen: set[str] = set()

    def add(source_type: str, value: str | None) -> None:
        if not value:
            return
        key = _datasheet_cache_key(
            project_root=project_root,
            source_type=source_type,
            source=value,
        )
        if key in seen:
            return
        seen.add(key)
        keys.append(key)

    if lcsc_id:
        add("lcsc_id", lcsc_id.upper())
    if url:
        add("url", url)
    if path:
        add("path", path)
    if source_kind and source:
        add(source_kind, source)

    return keys


def _dedupe_non_empty_strings(values: list[str]) -> list[str]:
    deduped: list[str] = []
    seen: set[str] = set()
    for value in values:
        candidate = str(value).strip()
        if not candidate or candidate in seen:
            continue
        seen.add(candidate)
        deduped.append(candidate)
    return deduped


async def _append_lcsc_jlc_datasheet_candidates(
    *,
    lcsc_id: str,
    candidate_urls: list[str],
    fallback_sources: list[dict[str, Any]],
) -> None:
    try:
        jlc_candidates, jlc_error = await asyncio.to_thread(
            parts_jlc_domain.search_jlc_parts,
            lcsc_id,
            limit=6,
        )
    except Exception as exc:
        fallback_sources.append(
            {
                "source": "jlc_search_error",
                "error": _trim_message(
                    f"{type(exc).__name__}: {exc}",
                    220,
                ),
            }
        )
        return

    if isinstance(jlc_error, str) and jlc_error.strip():
        fallback_sources.append(
            {
                "source": "jlc_search_error",
                "error": _trim_message(jlc_error, 220),
            }
        )

    for item in jlc_candidates or []:
        if not isinstance(item, dict):
            continue
        candidate_url = str(item.get("datasheet_url") or "").strip()
        if not candidate_url:
            continue
        candidate_urls.append(candidate_url)
        fallback_sources.append(
            {
                "source": "jlc_search",
                "url": candidate_url,
                "lcsc": item.get("lcsc"),
                "mpn": item.get("mpn"),
            }
        )


async def _read_first_datasheet_from_urls(
    *,
    project_root: Path,
    candidate_urls: list[str],
) -> tuple[bytes, dict[str, Any], str]:
    last_error: Exception | None = None
    attempted_errors: list[str] = []

    for candidate_url in candidate_urls:
        try:
            datasheet_bytes, metadata = await asyncio.to_thread(
                policy.read_datasheet_file,
                project_root,
                path=None,
                url=candidate_url,
            )
            return datasheet_bytes, metadata, candidate_url
        except Exception as exc:
            last_error = exc
            attempted_errors.append(_trim_message(f"{candidate_url} -> {exc}", 320))

    details = "; ".join(attempted_errors[:3]) or "unknown"
    raise policy.ScopeError(
        f"Failed to fetch datasheet from all resolved URLs ({details})"
    ) from last_error


def _resolve_web_search_content_mode(arguments: dict[str, Any]) -> str:
    raw_mode = arguments.get("content_mode")
    content_mode = str(raw_mode).strip().lower() if raw_mode is not None else ""
    if content_mode and content_mode not in {"none", "highlights", "text"}:
        raise ValueError("content_mode must be one of: none, highlights, text")
    if content_mode:
        return content_mode
    return "highlights"


def _resolve_web_search_max_characters(
    arguments: dict[str, Any],
    *,
    content_mode: str,
) -> int | None:
    raw_max_characters = arguments.get("max_characters")
    if raw_max_characters is None:
        if content_mode == "highlights":
            return 2_000
        if content_mode == "text":
            return 10_000
        return None

    max_characters = int(raw_max_characters)
    return max(200, min(max_characters, 100_000))


def _resolve_web_search_max_age_hours(arguments: dict[str, Any]) -> int | None:
    raw_max_age_hours = arguments.get("max_age_hours")
    if raw_max_age_hours is None:
        return None
    max_age_hours = int(raw_max_age_hours)
    return max(-1, min(max_age_hours, 24 * 365))


def _normalize_domain_filters(raw: Any, *, field_name: str) -> list[str]:
    if raw is None:
        return []
    if not isinstance(raw, list):
        raise ValueError(f"{field_name} must be an array of domain strings")

    normalized: list[str] = []
    seen: set[str] = set()
    for item in raw:
        if not isinstance(item, str):
            raise ValueError(f"{field_name} must contain only strings")
        domain = item.strip().lower()
        if not domain or domain in seen:
            continue
        seen.add(domain)
        normalized.append(domain)
    return normalized


def _to_float_or_none(value: Any, *, field_name: str) -> float | None:
    if value is None:
        return None
    try:
        return float(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{field_name} must be a number") from exc


def _to_int_or_none(value: Any, *, field_name: str) -> int | None:
    if value is None:
        return None
    try:
        return int(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{field_name} must be an integer") from exc


def _get_openai_file_client() -> AsyncOpenAI:
    global _openai_file_client
    if _openai_file_client is not None:
        return _openai_file_client

    config = AgentConfig.from_env()
    if not config.api_key:
        raise RuntimeError(
            "Missing API key. Set it in apps/open-atopile/.env or your environment."
        )

    _openai_file_client = AsyncOpenAI(
        api_key=config.api_key,
        base_url=config.base_url,
        timeout=config.timeout_s,
    )
    return _openai_file_client


def _extract_openai_api_error(exc: APIStatusError) -> str:
    response = getattr(exc, "response", None)
    response_text = getattr(response, "text", None)
    if isinstance(response_text, str) and response_text:
        return response_text
    body = getattr(exc, "body", None)
    if body is None:
        return str(exc)
    try:
        return json.dumps(body)
    except TypeError:
        return str(body)


_session_vector_store_id: str | None = None


async def _upload_to_vector_store(
    *,
    filename: str,
    content: bytes,
    cache_key: str,
) -> tuple[str, str, bool]:
    """Upload a file to OpenAI and add it to a session-level vector store.

    Reuses a single vector store across the session. The store expires
    after 7 days of inactivity (last_active_at).

    Returns (vector_store_id, file_id, cached).
    """
    global _session_vector_store_id

    cached = _cache_get_lru(_openai_file_cache, cache_key)
    if cached:
        # Cache stores "vs_id:file_id"
        vs_id, sep, fid = cached.partition(":")
        if sep and vs_id and fid:
            return vs_id, fid, True
        # Stale cache entry from old format — ignore it
        log.warning("Ignoring malformed file cache entry: %s", cache_key)

    client = _get_openai_file_client()

    # 1. Upload file
    try:
        uploaded = await client.files.create(
            file=(filename, BytesIO(content), "application/pdf"),
            purpose="assistants",
        )
    except APIStatusError as exc:
        snippet = _extract_openai_api_error(exc)[:500]
        status_code = getattr(exc, "status_code", "unknown")
        raise RuntimeError(
            f"OpenAI files.create failed ({status_code}): {snippet}"
        ) from exc
    except (APIConnectionError, APITimeoutError) as exc:
        raise RuntimeError(f"OpenAI files.create failed: {exc}") from exc

    file_id = str(getattr(uploaded, "id", "") or "")
    if not file_id:
        raise RuntimeError("OpenAI files.create returned no file id")

    # 2. Reuse or create session-level vector store
    try:
        vs_id = _session_vector_store_id
        if not vs_id:
            vector_store = await client.vector_stores.create(
                name="atopile-datasheets",
                expires_after={"anchor": "last_active_at", "days": 7},
            )
            vs_id = str(vector_store.id)
            _session_vector_store_id = vs_id

        await client.vector_stores.files.create(
            vector_store_id=vs_id,
            file_id=file_id,
        )
        # Indexing happens asynchronously on OpenAI's side.
        # Don't block — the model can continue working and
        # file_search will return results once indexing completes.
    except APIStatusError as exc:
        snippet = _extract_openai_api_error(exc)[:500]
        status_code = getattr(exc, "status_code", "unknown")
        raise RuntimeError(
            f"OpenAI vector_stores failed ({status_code}): {snippet}"
        ) from exc
    except (APIConnectionError, APITimeoutError) as exc:
        raise RuntimeError(f"OpenAI vector_stores failed: {exc}") from exc

    _cache_set_lru(
        _openai_file_cache,
        cache_key,
        f"{vs_id}:{file_id}",
        max_entries=_OPENAI_FILE_CACHE_MAX_ENTRIES,
    )
    return vs_id, file_id, False


def _count_modules_by_type(modules: list[dict[str, Any]]) -> dict[str, int]:
    counts: dict[str, int] = {}
    for module in modules:
        module_type = module.get("type")
        if not isinstance(module_type, str):
            continue
        counts[module_type] = counts.get(module_type, 0) + 1
    return counts


def _count_module_children(children: list[Any]) -> dict[str, int]:
    counts: dict[str, int] = {}
    stack = list(children)
    while stack:
        child = stack.pop()
        item_type = getattr(child, "item_type", None)
        if isinstance(item_type, str):
            counts[item_type] = counts.get(item_type, 0) + 1
        nested = getattr(child, "children", None)
        if isinstance(nested, list):
            stack.extend(nested)
    return counts


def _build_artifact_summary(
    data: Any,
    *,
    preferred_list_keys: tuple[str, ...],
) -> dict[str, Any]:
    if not isinstance(data, dict):
        return {"shape": type(data).__name__}

    top_level_keys = [str(key) for key in data.keys()][:30]
    list_lengths: dict[str, int] = {}
    for key, value in data.items():
        if isinstance(value, list):
            list_lengths[str(key)] = len(value)

    records_key: str | None = None
    records_count: int | None = None
    sample_fields: list[str] = []

    for key in preferred_list_keys:
        value = data.get(key)
        if isinstance(value, list):
            records_key = key
            records_count = len(value)
            if value and isinstance(value[0], dict):
                sample_fields = [str(field) for field in value[0].keys()][:20]
            break

    if records_key is None and list_lengths:
        records_key = next(iter(list_lengths))
        records_count = list_lengths[records_key]
        maybe_rows = data.get(records_key)
        if (
            isinstance(maybe_rows, list)
            and maybe_rows
            and isinstance(maybe_rows[0], dict)
        ):
            sample_fields = [str(field) for field in maybe_rows[0].keys()][:20]

    return {
        "shape": "dict",
        "top_level_keys": top_level_keys,
        "records_key": records_key,
        "records_count": records_count,
        "list_lengths": list_lengths,
        "sample_fields": sample_fields,
    }


def _manufacturing_outputs_dict(outputs: Any) -> dict[str, Any]:
    return {
        "gerbers": getattr(outputs, "gerbers", None),
        "bom_json": getattr(outputs, "bom_json", None),
        "bom_csv": getattr(outputs, "bom_csv", None),
        "pick_and_place": getattr(outputs, "pick_and_place", None),
        "step": getattr(outputs, "step", None),
        "glb": getattr(outputs, "glb", None),
        "kicad_pcb": getattr(outputs, "kicad_pcb", None),
        "kicad_sch": getattr(outputs, "kicad_sch", None),
        "pcb_summary": getattr(outputs, "pcb_summary", None),
    }


def _present_output_keys(outputs: dict[str, Any]) -> list[str]:
    return [
        key
        for key in _EXPECTED_MANUFACTURING_OUTPUT_KEYS
        if isinstance(outputs.get(key), str) and str(outputs.get(key)).strip()
    ]


def _expected_screenshot_outputs(
    *,
    project_root: Path,
    target: str,
    view: str,
) -> dict[str, Any]:
    build_cfg = builds_domain.resolve_build_target_config(project_root, target)
    output_base = build_cfg.paths.output_base

    want_2d = view in {"2d", "both"}
    want_3d = view in {"3d", "both"}

    outputs: dict[str, Any] = {
        "view": view,
        "target": target,
        "paths": {},
        "exists": {},
    }
    if want_2d:
        two_d = output_base.with_suffix(".pcba.svg")
        outputs["paths"]["2d"] = str(two_d)
        outputs["exists"]["2d"] = two_d.exists()
    if want_3d:
        three_d = output_base.with_suffix(".pcba.png")
        outputs["paths"]["3d"] = str(three_d)
        outputs["exists"]["3d"] = three_d.exists()
    return outputs


def _stdlib_matches_child_query(item: Any, query: str) -> bool:
    needle = query.strip().lower()
    if not needle:
        return True

    stack = list(getattr(item, "children", []))
    while stack:
        child = stack.pop()
        child_name = str(getattr(child, "name", "")).lower()
        child_type = str(getattr(child, "type", "")).lower()
        child_item_type = str(getattr(child, "item_type", "")).lower()
        if needle in child_name or needle in child_type or needle in child_item_type:
            return True
        nested = getattr(child, "children", None)
        if isinstance(nested, list):
            stack.extend(nested)
    return False


def _stdlib_matches_parameter_query(item: Any, query: str) -> bool:
    needle = query.strip().lower()
    if not needle:
        return True

    parameters = getattr(item, "parameters", [])
    if isinstance(parameters, list):
        for parameter in parameters:
            if not isinstance(parameter, dict):
                continue
            name = str(parameter.get("name", "")).lower()
            value = str(parameter.get("value", "")).lower()
            if needle in name or needle in value:
                return True
    return False


_TOOL_REGISTRY_VALIDATED = False
_INTERNAL_ONLY_TOOL_HANDLERS: frozenset[str] = frozenset()


def _ensure_tool_registry_consistency(definitions: list[dict[str, Any]]) -> None:
    schema_tool_names = {
        str(item.get("name"))
        for item in definitions
        if isinstance(item, dict)
        and item.get("type") == "function"
        and isinstance(item.get("name"), str)
        and str(item.get("name")).strip()
    }
    handler_tool_names = set(_TOOL_HANDLERS.keys())

    missing_handlers = sorted(schema_tool_names - handler_tool_names)
    missing_schemas = sorted(
        (handler_tool_names - schema_tool_names) - _INTERNAL_ONLY_TOOL_HANDLERS
    )
    if missing_handlers or missing_schemas:
        parts: list[str] = []
        if missing_handlers:
            parts.append("schema without handler: " + ", ".join(missing_handlers[:20]))
        if missing_schemas:
            parts.append("handler without schema: " + ", ".join(missing_schemas[:20]))
        raise RuntimeError("Tool registry/schema mismatch: " + " | ".join(parts))


def get_tool_definitions() -> list[dict[str, Any]]:
    from atopile.agent.tool_definitions import get_tool_definitions as _impl

    definitions = _impl()

    global _TOOL_REGISTRY_VALIDATED
    if not _TOOL_REGISTRY_VALIDATED:
        _ensure_tool_registry_consistency(definitions)
        _TOOL_REGISTRY_VALIDATED = True

    return definitions


ToolHandler = Callable[[dict[str, Any], Path, AppContext], Awaitable[dict[str, Any]]]
_TOOL_HANDLERS: dict[str, ToolHandler] = {}


def _register_tool(name: str):
    def _decorator(func: ToolHandler) -> ToolHandler:
        _TOOL_HANDLERS[name] = func
        return func

    return _decorator


def get_tool_names() -> list[str]:
    """Return registered runtime tool handler names."""
    return sorted(_TOOL_HANDLERS.keys())


def _resolve_nested_project_path(project_root: Path, raw_project_path: object) -> Path:
    if not isinstance(raw_project_path, str) or not raw_project_path.strip():
        return project_root

    candidate = (project_root / raw_project_path.strip()).resolve()
    try:
        candidate.relative_to(project_root.resolve())
    except ValueError as exc:
        raise ValueError("project_path must stay within the selected project") from exc
    return candidate


def _resolve_project_target(
    project_root: Path,
    target_name: str,
) -> ResolvedBuildTarget:
    project = projects_domain.handle_get_project(str(project_root))
    if project is None:
        raise ValueError(f"Project not found: {project_root}")

    resolved_target = next(
        (target for target in project.targets if target.name == target_name),
        None,
    )
    if resolved_target is not None:
        return resolved_target

    known_targets = ", ".join(sorted(target.name for target in project.targets))
    raise ValueError(
        f"Unknown build target '{target_name}'. Available: {known_targets}"
    )


def _resolve_requested_build_targets(
    project_root: Path,
    raw_targets: list[object],
) -> list[ResolvedBuildTarget]:
    target_names = [
        str(target).strip() for target in raw_targets if str(target).strip()
    ]
    return [
        _resolve_project_target(project_root, target_name)
        for target_name in target_names
    ]


# ── Skill loader ──────────────────────────────────────────────────

_AGENT_SKILL_IDS = frozenset({"ato", "ato-language", "planning", "package-agent"})


@_register_tool("get_skill")
async def _tool_get_skill(
    arguments: dict[str, Any], project_root: Path, ctx: AppContext
) -> dict[str, Any]:
    skill_id = str(arguments.get("skill_id", "")).strip()
    if skill_id not in _AGENT_SKILL_IDS:
        return {
            "error": f"Unknown skill: {skill_id}",
            "available": sorted(_AGENT_SKILL_IDS),
        }
    skills_dir = Path(__file__).resolve().parents[3] / ".claude" / "skills"
    skill_path = skills_dir / skill_id / "SKILL.md"
    if not skill_path.is_file():
        return {"error": f"Skill file not found: {skill_path}"}
    body = skill_path.read_text(encoding="utf-8").strip()
    return {"skill_id": skill_id, "content": body}


@_register_tool("project_list_files")
async def _tool_project_list_files(
    arguments: dict[str, Any], project_root: Path, ctx: AppContext
) -> dict[str, Any]:
    limit = int(arguments.get("limit", 300))
    files = await asyncio.to_thread(policy.list_context_files, project_root, limit)
    return {"files": files, "total": len(files)}


@_register_tool("project_read_file")
async def _tool_project_read_file(
    arguments: dict[str, Any], project_root: Path, ctx: AppContext
) -> dict[str, Any]:
    return await asyncio.to_thread(
        policy.read_file_chunk,
        project_root,
        str(arguments.get("path", "")),
        start_line=int(arguments.get("start_line", 1)),
        max_lines=int(arguments.get("max_lines", 220)),
    )


@_register_tool("project_search")
async def _tool_project_search(
    arguments: dict[str, Any], project_root: Path, ctx: AppContext
) -> dict[str, Any]:
    matches = await asyncio.to_thread(
        policy.search_in_files,
        project_root,
        str(arguments.get("query", "")),
        limit=int(arguments.get("limit", 60)),
    )
    return {
        "matches": [asdict(match) for match in matches],
        "total": len(matches),
    }


@_register_tool("package_create_local")
async def _tool_package_create_local(
    arguments: dict[str, Any], project_root: Path, ctx: AppContext
) -> dict[str, Any]:
    result = await asyncio.to_thread(
        projects_domain.create_local_package,
        project_root,
        str(arguments.get("name", "")),
        str(arguments.get("entry_module", "")),
        (
            str(arguments.get("description"))
            if isinstance(arguments.get("description"), str)
            else None
        ),
    )
    return {"success": True, **result}


@_register_tool("workspace_list_targets")
async def _tool_workspace_list_targets(
    arguments: dict[str, Any], project_root: Path, ctx: AppContext
) -> dict[str, Any]:
    _ = arguments
    roots = list(ctx.workspace_paths) or [project_root]
    response = await asyncio.to_thread(projects_domain.handle_get_projects, roots)
    projects = [project.model_dump(by_alias=True) for project in response.projects]
    return {
        "projects": projects,
        "total_projects": len(projects),
        "total_targets": sum(len(project["targets"]) for project in projects),
    }


@_register_tool("web_search")
async def _tool_web_search(
    arguments: dict[str, Any], project_root: Path, ctx: AppContext
) -> dict[str, Any]:
    query = str(arguments.get("query", "")).strip()
    if not query:
        raise ValueError("query is required")
    num_results = max(1, min(25, int(arguments.get("num_results", 8))))
    search_type = str(arguments.get("search_type", "auto")).strip().lower()
    if search_type not in {"auto", "fast", "neural", "deep", "instant"}:
        raise ValueError(
            "search_type must be one of: auto, fast, neural, deep, instant"
        )
    include_domains = _normalize_domain_filters(
        arguments.get("include_domains"),
        field_name="include_domains",
    )
    exclude_domains = _normalize_domain_filters(
        arguments.get("exclude_domains"),
        field_name="exclude_domains",
    )
    content_mode = _resolve_web_search_content_mode(arguments)
    max_characters = _resolve_web_search_max_characters(
        arguments,
        content_mode=content_mode,
    )
    max_age_hours = _resolve_web_search_max_age_hours(arguments)
    timeout_s = float(os.getenv("ATOPILE_AGENT_EXA_TIMEOUT_S", "30"))
    timeout_s = max(3.0, min(timeout_s, 120.0))
    hard_timeout_s = timeout_s + 5.0

    try:
        return await asyncio.wait_for(
            asyncio.to_thread(
                _exa_web_search,
                query=query,
                num_results=num_results,
                search_type=search_type,
                include_domains=include_domains,
                exclude_domains=exclude_domains,
                content_mode=content_mode,
                max_characters=max_characters,
                max_age_hours=max_age_hours,
                timeout_s=timeout_s,
            ),
            timeout=hard_timeout_s,
        )
    except asyncio.TimeoutError as exc:
        raise RuntimeError(
            f"web_search timed out after {hard_timeout_s:.0f}s "
            f"(HTTP timeout={timeout_s:.0f}s)"
        ) from exc


@_register_tool("examples_list")
async def _tool_examples_list(
    arguments: dict[str, Any], project_root: Path, ctx: AppContext
) -> dict[str, Any]:
    limit = int(arguments.get("limit", 60))
    include_without_ato_yaml = bool(arguments.get("include_without_ato_yaml", False))
    examples_root = _resolve_examples_root(project_root)
    projects = _collect_example_projects(
        examples_root,
        include_without_ato_yaml=include_without_ato_yaml,
    )
    returned = projects[:limit]
    return {
        "examples_root": str(examples_root),
        "examples": returned,
        "total": len(projects),
        "returned": len(returned),
    }


@_register_tool("examples_search")
async def _tool_examples_search(
    arguments: dict[str, Any], project_root: Path, ctx: AppContext
) -> dict[str, Any]:
    query = str(arguments.get("query", "")).strip()
    if not query:
        raise ValueError("query is required")
    limit = int(arguments.get("limit", 100))
    examples_root = _resolve_examples_root(project_root)
    matches = _search_example_ato_files(
        examples_root=examples_root,
        query=query,
        limit=limit,
    )
    return {
        "examples_root": str(examples_root),
        "query": query,
        "matches": matches,
        "total": len(matches),
    }


@_register_tool("examples_read_ato")
async def _tool_examples_read_ato(
    arguments: dict[str, Any], project_root: Path, ctx: AppContext
) -> dict[str, Any]:
    example = str(arguments.get("example", "")).strip()
    examples_root = _resolve_examples_root(project_root)
    example_project_root = _resolve_example_project(examples_root, example)
    example_file = _resolve_example_ato_file(
        example_project_root,
        arguments.get("path") if isinstance(arguments.get("path"), str) else None,
    )
    relative_path = str(example_file.relative_to(example_project_root))
    chunk = await asyncio.to_thread(
        policy.read_file_chunk,
        example_project_root,
        relative_path,
        start_line=int(arguments.get("start_line", 1)),
        max_lines=int(arguments.get("max_lines", 220)),
    )
    return {
        "example": example,
        "example_root": str(example_project_root),
        **chunk,
    }


@_register_tool("package_ato_list")
async def _tool_package_ato_list(
    arguments: dict[str, Any], project_root: Path, ctx: AppContext
) -> dict[str, Any]:
    package_query = (
        str(arguments.get("package_query")).strip()
        if isinstance(arguments.get("package_query"), str)
        and str(arguments.get("package_query")).strip()
        else None
    )
    path_query = (
        str(arguments.get("path_query")).strip()
        if isinstance(arguments.get("path_query"), str)
        and str(arguments.get("path_query")).strip()
        else None
    )
    limit = max(1, min(1000, int(arguments.get("limit", 200))))
    return _list_package_reference_files(
        project_root=project_root,
        package_query=package_query,
        path_query=path_query,
        limit=limit,
    )


@_register_tool("package_ato_search")
async def _tool_package_ato_search(
    arguments: dict[str, Any], project_root: Path, ctx: AppContext
) -> dict[str, Any]:
    query = str(arguments.get("query", "")).strip()
    if not query:
        raise ValueError("query is required")
    package_query = (
        str(arguments.get("package_query")).strip()
        if isinstance(arguments.get("package_query"), str)
        and str(arguments.get("package_query")).strip()
        else None
    )
    path_query = (
        str(arguments.get("path_query")).strip()
        if isinstance(arguments.get("path_query"), str)
        and str(arguments.get("path_query")).strip()
        else None
    )
    limit = max(1, min(1000, int(arguments.get("limit", 120))))
    return _search_package_reference_files(
        project_root=project_root,
        query=query,
        package_query=package_query,
        path_query=path_query,
        limit=limit,
    )


@_register_tool("package_ato_read")
async def _tool_package_ato_read(
    arguments: dict[str, Any], project_root: Path, ctx: AppContext
) -> dict[str, Any]:
    package_identifier = str(arguments.get("package_identifier", "")).strip()
    if not package_identifier:
        raise ValueError("package_identifier is required")
    path_in_package = (
        str(arguments.get("path_in_package")).strip()
        if isinstance(arguments.get("path_in_package"), str)
        and str(arguments.get("path_in_package")).strip()
        else None
    )
    start_line = max(1, int(arguments.get("start_line", 1)))
    max_lines = max(1, min(400, int(arguments.get("max_lines", 220))))
    return _read_package_reference_file(
        project_root=project_root,
        package_identifier=package_identifier,
        path_in_package=path_in_package,
        start_line=start_line,
        max_lines=max_lines,
    )


@_register_tool("project_list_modules")
async def _tool_project_list_modules(
    arguments: dict[str, Any], project_root: Path, ctx: AppContext
) -> dict[str, Any]:
    type_filter = arguments.get("type_filter")
    limit = int(arguments.get("limit", 200))
    response = await asyncio.to_thread(
        projects_domain.handle_get_modules,
        str(project_root),
        str(type_filter) if isinstance(type_filter, str) and type_filter else None,
    )
    if response is None:
        return {"modules": [], "total": 0, "returned": 0, "types": {}}
    modules = [module.model_dump(by_alias=True) for module in response.modules][:limit]
    return {
        "modules": modules,
        "total": response.total,
        "returned": len(modules),
        "types": _count_modules_by_type(modules),
    }


@_register_tool("project_module_children")
async def _tool_project_module_children(
    arguments: dict[str, Any], project_root: Path, ctx: AppContext
) -> dict[str, Any]:
    entry_point = str(arguments.get("entry_point", "")).strip()
    if not entry_point:
        raise ValueError("entry_point is required")
    max_depth = int(arguments.get("max_depth", 2))
    max_depth = max(0, min(5, max_depth))
    children = await asyncio.to_thread(
        module_introspection.introspect_module,
        project_root,
        entry_point,
        max_depth,
    )
    if children is None:
        return {
            "entry_point": entry_point,
            "found": False,
            "children": [],
            "counts": {},
        }
    return {
        "entry_point": entry_point,
        "found": True,
        "children": [child.model_dump(by_alias=True) for child in children],
        "counts": _count_module_children(children),
    }


@_register_tool("stdlib_list")
async def _tool_stdlib_list(
    arguments: dict[str, Any], project_root: Path, ctx: AppContext
) -> dict[str, Any]:
    type_filter = arguments.get("type_filter")
    search = arguments.get("search")
    child_query = arguments.get("child_query")
    parameter_query = arguments.get("parameter_query")
    max_depth = int(arguments.get("max_depth", 2))
    limit = int(arguments.get("limit", 120))

    response = await asyncio.to_thread(
        stdlib_domain.handle_get_stdlib,
        str(type_filter) if isinstance(type_filter, str) and type_filter else None,
        str(search) if isinstance(search, str) and search else None,
        False,
        max_depth,
    )
    items = list(response.items)
    if isinstance(child_query, str) and child_query.strip():
        items = [
            item for item in items if _stdlib_matches_child_query(item, child_query)
        ]
    if isinstance(parameter_query, str) and parameter_query.strip():
        items = [
            item
            for item in items
            if _stdlib_matches_parameter_query(item, parameter_query)
        ]

    items = items[:limit]
    return {
        "items": [item.model_dump() for item in items],
        "total": response.total,
        "returned": len(items),
        "filters": {
            "type_filter": type_filter,
            "search": search,
            "child_query": child_query,
            "parameter_query": parameter_query,
        },
        "hints": [
            "Try search='usb' and child_query='i2c' for bus-related modules.",
            "Try type_filter='component' and parameter_query='voltage'.",
            "Use stdlib_get_item on a returned id for full details and usage.",
        ],
    }


@_register_tool("stdlib_get_item")
async def _tool_stdlib_get_item(
    arguments: dict[str, Any], project_root: Path, ctx: AppContext
) -> dict[str, Any]:
    item_id = str(arguments.get("item_id", "")).strip()
    if not item_id:
        raise ValueError("item_id is required")
    item = await asyncio.to_thread(
        lambda: next(
            (
                entry
                for entry in stdlib_domain.get_standard_library()
                if entry.id == item_id
            ),
            None,
        )
    )
    if item is None:
        return {"found": False, "item_id": item_id}
    return {
        "found": True,
        "item_id": item_id,
        "item": item.model_dump(),
    }


@_register_tool("project_edit_file")
async def _tool_project_edit_file(
    arguments: dict[str, Any], project_root: Path, ctx: AppContext
) -> dict[str, Any]:
    edits = arguments.get("edits")
    if not isinstance(edits, list):
        raise ValueError("edits must be a list")
    return await asyncio.to_thread(
        policy.apply_hashline_edits,
        project_root,
        str(arguments.get("path", "")),
        edits,
    )


@_register_tool("project_create_path")
async def _tool_project_create_path(
    arguments: dict[str, Any], project_root: Path, ctx: AppContext
) -> dict[str, Any]:
    content = arguments.get("content", "")
    if content is None:
        content = ""
    if not isinstance(content, str):
        raise ValueError("content must be a string")
    kind = str(arguments.get("kind", "file")).strip().lower()
    return await asyncio.to_thread(
        policy.create_path,
        project_root,
        str(arguments.get("path", "")),
        kind=kind,
        content=content,
        overwrite=bool(arguments.get("overwrite", False)),
        parents=bool(arguments.get("parents", True)),
    )


@_register_tool("project_move_path")
async def _tool_project_move_path(
    arguments: dict[str, Any], project_root: Path, ctx: AppContext
) -> dict[str, Any]:
    return await asyncio.to_thread(
        policy.rename_path,
        project_root,
        str(arguments.get("old_path", "")),
        str(arguments.get("new_path", "")),
        overwrite=bool(arguments.get("overwrite", False)),
    )


@_register_tool("project_delete_path")
async def _tool_project_delete_path(
    arguments: dict[str, Any], project_root: Path, ctx: AppContext
) -> dict[str, Any]:
    return await asyncio.to_thread(
        policy.delete_path,
        project_root,
        str(arguments.get("path", "")),
        recursive=bool(arguments.get("recursive", True)),
    )


@_register_tool("parts_search")
async def _tool_parts_search(
    arguments: dict[str, Any], project_root: Path, ctx: AppContext
) -> dict[str, Any]:
    parts, error = await asyncio.to_thread(
        parts_domain.handle_search_parts,
        str(arguments.get("query", "")).strip(),
        limit=int(arguments.get("limit", 20)),
    )
    return {"parts": parts, "total": len(parts), "error": error}


@_register_tool("parts_install")
async def _tool_parts_install(
    arguments: dict[str, Any], project_root: Path, ctx: AppContext
) -> dict[str, Any]:
    lcsc_id = str(arguments.get("lcsc_id", "")).strip().upper()
    create_package = bool(arguments.get("create_package", False))
    install_root = _resolve_nested_project_path(
        project_root, arguments.get("project_path")
    )

    if not create_package:
        result = await asyncio.to_thread(
            parts_domain.handle_install_part,
            lcsc_id,
            str(install_root),
        )
        payload = {
            "success": True,
            "lcsc_id": lcsc_id,
            "implementation_hint": (
                "For complex parts (MCUs/sensors/PMICs/radios), use "
                "web_search next to inspect the vendor datasheet, hardware "
                "design guides, and required support circuitry."
            ),
            **result,
        }
        if install_root != project_root:
            payload["projectPath"] = str(install_root.relative_to(project_root))
        return payload

    result = await asyncio.to_thread(
        parts_domain.handle_install_part_as_package,
        lcsc_id,
        str(install_root),
    )

    payload = {
        "success": True,
        "lcsc_id": lcsc_id,
        "implementation_hint": (
            "For complex parts (MCUs/sensors/PMICs/radios), use "
            "web_search next to inspect the vendor datasheet, hardware "
            "design guides, and required support circuitry."
        ),
        **result,
    }
    if install_root != project_root:
        payload["projectPath"] = str(install_root.relative_to(project_root))
    return payload


@_register_tool("datasheet_read")
async def _tool_datasheet_read(
    arguments: dict[str, Any], project_root: Path, ctx: AppContext
) -> dict[str, Any]:
    raw_lcsc_id = arguments.get("lcsc_id")
    raw_url = arguments.get("url")
    raw_path = arguments.get("path")
    raw_target = arguments.get("target")
    raw_query = arguments.get("query")
    lcsc_id = (
        str(raw_lcsc_id).strip()
        if isinstance(raw_lcsc_id, str) and raw_lcsc_id.strip()
        else None
    )
    url = str(raw_url).strip() if isinstance(raw_url, str) and raw_url.strip() else None
    path = (
        str(raw_path).strip()
        if isinstance(raw_path, str) and raw_path.strip()
        else None
    )
    target = (
        str(raw_target).strip()
        if isinstance(raw_target, str) and raw_target.strip()
        else None
    )
    query = (
        str(raw_query).strip()
        if isinstance(raw_query, str) and raw_query.strip()
        else None
    )

    provided = [bool(lcsc_id), bool(url), bool(path)]
    if sum(1 for value in provided if value) != 1:
        raise ValueError("Provide exactly one of lcsc_id, url, or path")

    request_cache_keys = _datasheet_cache_keys(
        project_root=project_root,
        lcsc_id=lcsc_id,
        url=url,
        path=path,
    )
    for cache_ref in request_cache_keys:
        cached_payload = _cache_get_lru(_datasheet_read_cache, cache_ref)
        if not cached_payload:
            continue
        result = dict(cached_payload)
        result["query"] = query
        result["message"] = "Reusing previously attached datasheet file."
        result["openai_file_cached"] = True
        result["datasheet_cache_hit"] = True
        return result

    source_url = url
    source_path = path
    source_meta: dict[str, Any] = {}
    resolution: dict[str, Any] = {}
    fallback_sources: list[dict[str, Any]] = []
    if lcsc_id:
        if not source_path:
            details = await asyncio.to_thread(
                parts_domain.handle_get_part_details,
                lcsc_id,
            )
            if details is None:
                return {
                    "found": False,
                    "lcsc_id": lcsc_id,
                    "message": f"Part not found: {lcsc_id}",
                }

            datasheet_url = str(getattr(details, "datasheet_url", "") or "").strip()
            if not datasheet_url:
                return {
                    "found": False,
                    "lcsc_id": lcsc_id,
                    "message": "No datasheet URL available for this part",
                }
            source_url = datasheet_url
            source_path = None
            resolution = {
                "mode": "parts_api_fallback",
                "reason": (
                    "No cached datasheet was found for this lcsc_id in the "
                    "project install cache."
                ),
            }
            if target:
                resolution["requested_target"] = target
            source_meta["part"] = {
                "manufacturer": getattr(details, "manufacturer", None),
                "part_number": getattr(details, "mpn", None),  # UiPartDetail.mpn
                "description": getattr(details, "description", None),
            }
            fallback_sources.append(
                {
                    "source": "parts_api",
                    "url": datasheet_url,
                }
            )

        source_meta = {
            "lcsc_id": lcsc_id.upper(),
            **source_meta,
        }

    datasheet_bytes: bytes
    metadata: dict[str, Any]
    if source_path:
        datasheet_bytes, metadata = await asyncio.to_thread(
            policy.read_datasheet_file,
            project_root,
            path=source_path,
            url=None,
        )
    else:
        candidate_urls: list[str] = []
        if source_url:
            candidate_urls.append(source_url)
        if lcsc_id:
            await _append_lcsc_jlc_datasheet_candidates(
                lcsc_id=lcsc_id,
                candidate_urls=candidate_urls,
                fallback_sources=fallback_sources,
            )

        candidate_urls = _dedupe_non_empty_strings(candidate_urls)
        if not candidate_urls:
            raise policy.ScopeError(
                "No datasheet URL could be resolved for this request."
            )

        datasheet_bytes, metadata, selected_url = await _read_first_datasheet_from_urls(
            project_root=project_root,
            candidate_urls=candidate_urls,
        )

        if selected_url and source_url and selected_url != source_url:
            resolution = {
                **resolution,
                "url_fallback": {
                    "selected_url": selected_url,
                    "primary_url": source_url,
                    "attempted_urls": len(candidate_urls),
                },
            }

    if fallback_sources:
        resolution = {
            **resolution,
            "fallback_sources": fallback_sources[:8],
        }
    cache_key = str(
        metadata.get("sha256")
        or f"{metadata.get('source_kind')}:{metadata.get('source')}"
    )
    filename = str(metadata.get("filename") or "datasheet.pdf")
    vector_store_id, file_id, cached = await _upload_to_vector_store(
        filename=filename,
        content=datasheet_bytes,
        cache_key=cache_key,
    )

    result_payload = {
        "found": True,
        "query": query,
        "message": (
            "Datasheet uploaded and indexing. "
            "Continue working — it will be searchable shortly."
        ),
        "openai_file_id": file_id,
        "vector_store_id": vector_store_id,
        "openai_file_cached": cached,
        "datasheet_cache_hit": False,
        "bytes_uploaded": len(datasheet_bytes),
        "resolution": resolution or None,
        **source_meta,
        **metadata,
    }

    metadata_source_kind = metadata.get("source_kind")
    metadata_source = metadata.get("source")
    source_kind = (
        str(metadata_source_kind).strip()
        if isinstance(metadata_source_kind, str) and metadata_source_kind.strip()
        else None
    )
    source_value = (
        str(metadata_source).strip()
        if isinstance(metadata_source, str) and metadata_source.strip()
        else None
    )

    for cache_ref in _datasheet_cache_keys(
        project_root=project_root,
        lcsc_id=lcsc_id,
        url=url,
        path=path,
        source_kind=source_kind,
        source=source_value,
    ):
        _cache_set_lru(
            _datasheet_read_cache,
            cache_ref,
            dict(result_payload),
            max_entries=_DATASHEET_READ_CACHE_MAX_ENTRIES,
        )

    return result_payload


@_register_tool("packages_search")
async def _tool_packages_search(
    arguments: dict[str, Any], project_root: Path, ctx: AppContext
) -> dict[str, Any]:
    result = await asyncio.to_thread(
        packages_domain.handle_search_registry,
        str(arguments.get("query", "")),
        project_root,
    )
    return result.model_dump(by_alias=True)


@_register_tool("packages_install")
async def _tool_packages_install(
    arguments: dict[str, Any], project_root: Path, ctx: AppContext
) -> dict[str, Any]:
    identifier = str(arguments.get("identifier", ""))
    version = arguments.get("version")
    clean_version = str(version) if isinstance(version, str) and version else None
    await asyncio.to_thread(
        packages_domain.install_package_to_project,
        project_root,
        identifier,
        clean_version,
    )
    return {
        "success": True,
        "identifier": identifier,
        "version": clean_version,
        "message": "Package installed",
    }


@_register_tool("build_run")
async def _tool_build_run(
    arguments: dict[str, Any], project_root: Path, ctx: AppContext
) -> dict[str, Any]:
    targets = arguments.get("targets") or []
    if not isinstance(targets, list):
        raise ValueError("targets must be a list")
    include_targets = arguments.get("include_targets") or []
    if not isinstance(include_targets, list):
        raise ValueError("include_targets must be a list")
    exclude_targets = arguments.get("exclude_targets") or []
    if not isinstance(exclude_targets, list):
        raise ValueError("exclude_targets must be a list")
    build_root = _resolve_nested_project_path(
        project_root, arguments.get("project_path")
    )

    request = BuildRequest(
        project_root=str(build_root),
        targets=_resolve_requested_build_targets(build_root, targets),
        entry=(str(arguments["entry"]) if arguments.get("entry") else None),
        standalone=bool(arguments.get("standalone", False)),
        frozen=bool(arguments.get("frozen", False)),
        include_targets=[str(target) for target in include_targets],
        exclude_targets=[str(target) for target in exclude_targets],
    )
    response = await asyncio.to_thread(builds_domain.handle_start_build, request)
    payload = {
        "success": True,
        "builds": [build.model_dump(by_alias=True) for build in response],
        "count": len(response),
        "queued_build_ids": [build.build_id for build in response if build.build_id],
    }
    if build_root != project_root:
        payload["projectPath"] = str(build_root.relative_to(project_root))
    return payload


@_register_tool("build_create")
async def _tool_build_create(
    arguments: dict[str, Any], project_root: Path, ctx: AppContext
) -> dict[str, Any]:
    request = AddBuildTargetRequest(
        project_root=str(project_root),
        name=str(arguments.get("name", "")),
        entry=str(arguments.get("entry", "")),
    )
    result = await asyncio.to_thread(projects_domain.handle_add_build_target, request)
    return result.model_dump(by_alias=True)


@_register_tool("build_rename")
async def _tool_build_rename(
    arguments: dict[str, Any], project_root: Path, ctx: AppContext
) -> dict[str, Any]:
    request = UpdateBuildTargetRequest(
        project_root=str(project_root),
        old_name=str(arguments.get("old_name", "")),
        new_name=(str(arguments["new_name"]) if arguments.get("new_name") else None),
        new_entry=(str(arguments["new_entry"]) if arguments.get("new_entry") else None),
    )
    result = await asyncio.to_thread(
        projects_domain.handle_update_build_target,
        request,
    )
    return result.model_dump(by_alias=True)


@_register_tool("build_logs_search")
async def _tool_build_logs_search(
    arguments: dict[str, Any], project_root: Path, ctx: AppContext
) -> dict[str, Any]:
    request = _BuildLogsSearchRequest.model_validate(arguments)
    limit = request.limit
    build_id = request.build_id
    query = request.query.lower() if request.query else ""
    stage_filter = request.stage
    log_levels = [level.value for level in request.log_levels]
    audience = request.audience.value if request.audience else None

    if not build_id:
        builds, active_ids = await asyncio.gather(
            asyncio.to_thread(builds_domain.get_recent_builds, min(limit, 120)),
            asyncio.to_thread(builds_domain.get_active_build_ids),
        )
        normalized = [_normalize_history_build(build) for build in builds]
        if query:
            normalized = [
                build
                for build in normalized
                if query
                in " ".join(
                    [
                        str(build.get("build_id", "")),
                        str(build.get("target", "")),
                        str(build.get("status", "")),
                        str(build.get("error", "")),
                    ]
                ).lower()
            ]
        return {
            "builds": normalized[:limit],
            "total": len(normalized[:limit]),
            "active_ids": sorted(active_ids),
            "filters": {
                "query": query or None,
                "stage": stage_filter,
                "log_levels": log_levels,
                "audience": audience,
            },
        }

    clean_build_id = str(build_id)
    history_build = await asyncio.to_thread(BuildHistory.get, clean_build_id)
    logs, _ = await asyncio.to_thread(
        read_build_logs,
        build_id=clean_build_id,
        stage=stage_filter,
        log_levels=log_levels,
        audience=audience,
        count=min(limit, 1000),
    )

    if query:
        logs = [
            entry for entry in logs if query in str(entry.get("message", "")).lower()
        ]

    synthesized_stub = False
    if not logs:
        logs = [
            _build_empty_log_stub(
                build_id=clean_build_id,
                query=query,
                build=history_build,
            )
        ]
        synthesized_stub = True

    status = None
    error = None
    return_code = None
    if history_build is not None:
        status = history_build.status.value
        error = _trim_message(history_build.error)
        return_code = history_build.return_code

    return {
        "build_id": clean_build_id,
        "logs": logs,
        "total": len(logs),
        "synthesized_stub": synthesized_stub,
        "status": status,
        "return_code": return_code,
        "error": error,
        "stage_summary": builds_domain.summarize_build_stages(history_build),
        "filters": {
            "query": query or None,
            "stage": stage_filter,
            "log_levels": log_levels,
            "audience": audience,
        },
    }


@_register_tool("layout_get_component_position")
async def _tool_layout_get_component_position(
    arguments: dict[str, Any], project_root: Path, ctx: AppContext
) -> dict[str, Any]:
    target = str(arguments.get("target", "default")).strip() or "default"
    address = str(arguments.get("address", "")).strip()
    if not address:
        raise ValueError("address is required")
    fuzzy_limit = max(1, min(20, int(arguments.get("fuzzy_limit", 6))))

    return await asyncio.to_thread(
        _layout_get_component_position,
        project_root=project_root,
        target=target,
        address=address,
        fuzzy_limit=fuzzy_limit,
    )


@_register_tool("layout_set_component_position")
async def _tool_layout_set_component_position(
    arguments: dict[str, Any], project_root: Path, ctx: AppContext
) -> dict[str, Any]:
    target = str(arguments.get("target", "default")).strip() or "default"
    address = str(arguments.get("address", "")).strip()
    if not address:
        raise ValueError("address is required")

    mode = str(arguments.get("mode", "absolute")).strip().lower() or "absolute"
    x_mm = _to_float_or_none(arguments.get("x_mm"), field_name="x_mm")
    y_mm = _to_float_or_none(arguments.get("y_mm"), field_name="y_mm")
    rotation_deg = _to_float_or_none(
        arguments.get("rotation_deg"),
        field_name="rotation_deg",
    )
    dx_mm = _to_float_or_none(arguments.get("dx_mm"), field_name="dx_mm")
    dy_mm = _to_float_or_none(arguments.get("dy_mm"), field_name="dy_mm")
    drotation_deg = _to_float_or_none(
        arguments.get("drotation_deg"),
        field_name="drotation_deg",
    )
    layer_raw = arguments.get("layer")
    layer = str(layer_raw).strip() if isinstance(layer_raw, str) else None
    fuzzy_limit = max(1, min(20, int(arguments.get("fuzzy_limit", 6))))

    return await asyncio.to_thread(
        _layout_set_component_position,
        project_root=project_root,
        target=target,
        address=address,
        mode=mode,
        x_mm=x_mm,
        y_mm=y_mm,
        rotation_deg=rotation_deg,
        dx_mm=dx_mm,
        dy_mm=dy_mm,
        drotation_deg=drotation_deg,
        layer=layer,
        fuzzy_limit=fuzzy_limit,
    )


@_register_tool("layout_run_drc")
async def _tool_layout_run_drc(
    arguments: dict[str, Any], project_root: Path, ctx: AppContext
) -> dict[str, Any]:
    from faebryk.libs.kicad.drc import run_drc

    target = str(arguments.get("target", "default")).strip() or "default"
    max_findings = max(1, min(500, int(arguments.get("max_findings", 120))))
    max_items_per_finding = max(
        1, min(20, int(arguments.get("max_items_per_finding", 4)))
    )

    build_cfg = builds_domain.resolve_build_target_config(project_root, target)
    layout_path = _resolve_layout_file_for_tool(
        project_root=project_root,
        target=target,
    )
    if not layout_path.exists():
        raise ValueError(f"Layout file does not exist: {layout_path}")

    try:
        drc_report = await asyncio.to_thread(run_drc, layout_path)
    except Exception as exc:  # pragma: no cover - passthrough for runtime failures
        raise RuntimeError(f"Failed to run KiCad DRC: {exc}") from exc

    timestamp = datetime.now(tz=UTC).strftime("%Y%m%dT%H%M%SZ")
    report_dir = (
        builds_domain.get_build_output_dir_for_config(build_cfg) / "layout" / "drc"
    )
    report_dir.mkdir(parents=True, exist_ok=True)
    report_path = report_dir / f"{target}.{timestamp}.drc.json"
    await asyncio.to_thread(drc_report.dumps, report_path)

    severity_rank = {
        "error": 0,
        "warning": 1,
        "action": 2,
        "info": 3,
        "debug": 4,
        "exclusion": 5,
        "": 6,
    }

    findings: list[dict[str, Any]] = []
    severity_counts: dict[str, int] = {}
    type_counts: dict[str, int] = {}

    for category_name, entries in (
        ("violations", list(getattr(drc_report, "violations", []) or [])),
        (
            "unconnected_items",
            list(getattr(drc_report, "unconnected_items", []) or []),
        ),
        (
            "schematic_parity",
            list(getattr(drc_report, "schematic_parity", []) or []),
        ),
    ):
        for entry in entries:
            severity = str(getattr(entry, "severity", "") or "").lower()
            violation_type = str(getattr(entry, "type", "") or "").lower()
            severity_counts[severity] = severity_counts.get(severity, 0) + 1
            type_counts[violation_type] = type_counts.get(violation_type, 0) + 1

            if len(findings) >= max_findings:
                continue

            items_payload: list[dict[str, Any]] = []
            for item in list(getattr(entry, "items", []) or [])[:max_items_per_finding]:
                position = getattr(item, "pos", None)
                items_payload.append(
                    {
                        "description": str(
                            getattr(item, "description", "") or ""
                        ).strip(),
                        "uuid": str(getattr(item, "uuid", "") or "").strip(),
                        "x_mm": float(getattr(position, "x", 0.0) or 0.0)
                        if position is not None
                        else None,
                        "y_mm": float(getattr(position, "y", 0.0) or 0.0)
                        if position is not None
                        else None,
                    }
                )

            findings.append(
                {
                    "category": category_name,
                    "severity": severity or None,
                    "type": violation_type or None,
                    "description": str(getattr(entry, "description", "") or "").strip(),
                    "item_count": len(list(getattr(entry, "items", []) or [])),
                    "items": items_payload,
                }
            )

    findings.sort(
        key=lambda finding: (
            severity_rank.get(str(finding.get("severity", "")).lower(), 99),
            str(finding.get("category", "")),
            str(finding.get("type", "")),
        )
    )

    total_findings = (
        len(list(getattr(drc_report, "violations", []) or []))
        + len(list(getattr(drc_report, "unconnected_items", []) or []))
        + len(list(getattr(drc_report, "schematic_parity", []) or []))
    )

    error_count = severity_counts.get("error", 0)
    warning_count = severity_counts.get("warning", 0)

    top_types = sorted(
        type_counts.items(),
        key=lambda item: item[1],
        reverse=True,
    )

    return {
        "success": True,
        "target": target,
        "layout_path": str(layout_path),
        "report_path": str(report_path),
        "kicad_version": str(getattr(drc_report, "kicad_version", "") or ""),
        "date": str(getattr(drc_report, "date", "") or ""),
        "total_findings": total_findings,
        "error_count": error_count,
        "warning_count": warning_count,
        "severity_counts": severity_counts,
        "top_types": [
            {"type": violation_type, "count": count}
            for violation_type, count in top_types[:20]
            if violation_type
        ],
        "clean": error_count == 0 and warning_count == 0 and total_findings == 0,
        "findings": findings,
        "findings_truncated": total_findings > len(findings),
    }


@_register_tool("report_bom")
async def _tool_report_bom(
    arguments: dict[str, Any], project_root: Path, ctx: AppContext
) -> dict[str, Any]:
    target = str(arguments.get("target", "default"))
    data = await asyncio.to_thread(
        artifacts_domain.read_target_json_artifact,
        str(project_root),
        ".bom.json",
        label="BOM",
        target=_resolve_project_target(project_root, target),
    )
    if data is None:
        return {
            "target": target,
            "found": False,
            "message": "BOM not found for target. Run build_run and retry.",
        }
    return {
        "target": target,
        "found": True,
        "bom": data,
        "summary": _build_artifact_summary(
            data,
            preferred_list_keys=(
                "items",
                "line_items",
                "rows",
                "components",
                "bom",
                "entries",
            ),
        ),
    }


@_register_tool("report_variables")
async def _tool_report_variables(
    arguments: dict[str, Any], project_root: Path, ctx: AppContext
) -> dict[str, Any]:
    target = str(arguments.get("target", "default"))
    data = await asyncio.to_thread(
        artifacts_domain.read_target_json_artifact,
        str(project_root),
        ".variables.json",
        label="variables",
        target=_resolve_project_target(project_root, target),
    )
    if data is None:
        return {
            "target": target,
            "found": False,
            "message": (
                "Variables report not found for target. Run build_run and retry."
            ),
        }
    return {
        "target": target,
        "found": True,
        "variables": data,
        "summary": _build_artifact_summary(
            data,
            preferred_list_keys=(
                "variables",
                "parameters",
                "params",
                "values",
                "entries",
                "items",
            ),
        ),
    }


@_register_tool("manufacturing_generate")
async def _tool_manufacturing_generate(
    arguments: dict[str, Any], project_root: Path, ctx: AppContext
) -> dict[str, Any]:
    target = str(arguments.get("target", "default")).strip() or "default"
    frozen = bool(arguments.get("frozen", False))

    raw_include_targets = arguments.get("include_targets")
    if raw_include_targets is None:
        include_targets = ["mfg-data"]
    elif isinstance(raw_include_targets, list):
        include_targets = [
            str(value).strip() for value in raw_include_targets if str(value).strip()
        ]
    else:
        raise ValueError("include_targets must be a list")
    if not include_targets:
        include_targets = ["mfg-data"]

    raw_exclude_targets = arguments.get("exclude_targets")
    if raw_exclude_targets is None:
        exclude_targets: list[str] = []
    elif isinstance(raw_exclude_targets, list):
        exclude_targets = [
            str(value).strip() for value in raw_exclude_targets if str(value).strip()
        ]
    else:
        raise ValueError("exclude_targets must be a list")

    outputs_before_obj = await asyncio.to_thread(
        manufacturing_domain.get_build_outputs,
        str(project_root),
        target,
    )
    outputs_before = _manufacturing_outputs_dict(outputs_before_obj)
    present_before = _present_output_keys(outputs_before)

    request = BuildRequest(
        project_root=str(project_root),
        targets=[_resolve_project_target(project_root, target)],
        frozen=frozen,
        include_targets=include_targets,
        exclude_targets=exclude_targets,
    )
    response = await asyncio.to_thread(builds_domain.handle_start_build, request)
    build_targets = [
        {
            "target": entry.target.model_dump(by_alias=True) if entry.target else None,
            "build_id": entry.build_id,
        }
        for entry in response
    ]
    queued_build_id = build_targets[0]["build_id"] if build_targets else None

    return {
        "success": True,
        "message": f"Queued {len(response)} build(s)",
        "target": target,
        "frozen": frozen,
        "include_targets": include_targets,
        "exclude_targets": exclude_targets,
        "build_targets": build_targets,
        "queued_build_id": queued_build_id,
        "expected_outputs": list(_EXPECTED_MANUFACTURING_OUTPUT_KEYS),
        "outputs_before": outputs_before,
        "present_outputs_before": present_before,
        "missing_outputs_before": [
            key
            for key in _EXPECTED_MANUFACTURING_OUTPUT_KEYS
            if key not in set(present_before)
        ],
        "next_step": (
            "Use build_logs_search with queued_build_id to track progress, "
            "then use manufacturing_summary after completion."
        ),
    }


@_register_tool("manufacturing_summary")
async def _tool_manufacturing_summary(
    arguments: dict[str, Any], project_root: Path, ctx: AppContext
) -> dict[str, Any]:
    target = str(arguments.get("target", "default"))
    quantity = int(arguments.get("quantity", 10))

    outputs = await asyncio.to_thread(
        manufacturing_domain.get_build_outputs,
        str(project_root),
        target,
    )
    estimate = await asyncio.to_thread(
        manufacturing_domain.estimate_cost,
        str(project_root),
        [target],
        quantity,
    )

    return {
        "target": target,
        "outputs": _manufacturing_outputs_dict(outputs),
        "cost_estimate": {
            "total_cost": estimate.total_cost,
            "currency": estimate.currency,
            "quantity": estimate.quantity,
            "pcb_cost": estimate.pcb_cost,
            "components_cost": estimate.components_cost,
            "assembly_cost": estimate.assembly_cost,
        },
    }


@_register_tool("checklist_create")
async def _tool_checklist_create(
    arguments: dict[str, Any], project_root: Path, ctx: AppContext
) -> dict[str, Any]:
    raise RuntimeError("checklist_create is intercepted by the runner")


@_register_tool("checklist_update")
async def _tool_checklist_update(
    arguments: dict[str, Any], project_root: Path, ctx: AppContext
) -> dict[str, Any]:
    raise RuntimeError("checklist_update is intercepted by the runner")


@_register_tool("checklist_add_items")
async def _tool_checklist_add_items(
    arguments: dict[str, Any], project_root: Path, ctx: AppContext
) -> dict[str, Any]:
    raise RuntimeError("checklist_add_items is intercepted by the runner")


@_register_tool("message_acknowledge")
async def _tool_message_acknowledge(
    arguments: dict[str, Any], project_root: Path, ctx: AppContext
) -> dict[str, Any]:
    raise RuntimeError("message_acknowledge is intercepted by the runner")


@_register_tool("message_log_query")
async def _tool_message_log_query(
    arguments: dict[str, Any], project_root: Path, ctx: AppContext
) -> dict[str, Any]:
    raise RuntimeError("message_log_query is intercepted by the runner")


@_register_tool("design_questions")
async def _tool_design_questions(
    arguments: dict[str, Any], project_root: Path, ctx: AppContext
) -> dict[str, Any]:
    raise RuntimeError("design_questions is intercepted by the runner")


@_register_tool("layout_set_board_shape")
async def _tool_layout_set_board_shape(
    arguments: dict[str, Any], project_root: Path, ctx: AppContext
) -> dict[str, Any]:
    raise RuntimeError("layout_set_board_shape is not yet implemented")


async def execute_tool(
    *,
    name: str,
    arguments: dict[str, Any],
    project_root: Path,
    ctx: AppContext,
) -> dict[str, Any]:
    """Execute a named agent tool with typed arguments."""
    handler = _TOOL_HANDLERS.get(name)
    if handler is None:
        raise ValueError(f"Unknown tool: {name}")
    return await handler(arguments, project_root, ctx)


def parse_tool_arguments(raw_arguments: str) -> dict[str, Any]:
    """Parse JSON function arguments safely."""
    if not raw_arguments:
        return {}
    parsed = json.loads(raw_arguments)
    if not isinstance(parsed, dict):
        raise ValueError("Tool arguments must be an object")
    return parsed


def validate_tool_scope(project_root: str, ctx: AppContext) -> Path:
    """Validate and resolve project root for tool execution."""
    return policy.resolve_project_root(project_root, ctx)
