"""Agent configuration — pure data, zero runtime dependencies."""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path


def _env(key: str, default: str) -> str:
    return os.getenv(key, default)


def _env_int(
    key: str, default: str, *, lo: int | None = None, hi: int | None = None
) -> int:
    v = int(_env(key, default))
    if lo is not None:
        v = max(lo, v)
    if hi is not None:
        v = min(hi, v)
    return v


def _env_float(
    key: str, default: str, *, lo: float | None = None, hi: float | None = None
) -> float:
    v = float(_env(key, default))
    if lo is not None:
        v = max(lo, v)
    if hi is not None:
        v = min(hi, v)
    return v


_TRACE_DISABLE_VALUES = {"0", "false", "no", "off"}


def _load_app_root_env() -> None:
    env_path = Path(__file__).resolve().parents[3] / ".env"
    if not env_path.is_file():
        return
    for raw_line in env_path.read_text().splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("export "):
            line = line[7:].lstrip()
        key, sep, value = line.partition("=")
        if not sep:
            continue
        os.environ.setdefault(key.strip(), value.strip().strip("'\""))


@dataclass
class AgentConfig:
    base_url: str = "https://api.openai.com/v1"
    model: str = "gpt-5.4"
    summary_model: str = "gpt-4.1-nano"
    api_key: str | None = None
    timeout_s: float = 120.0
    summary_timeout_s: float = 8.0
    max_tool_loops: int = 240
    max_turn_seconds: float = 7_200.0
    api_retries: int = 4
    api_retry_base_delay_s: float = 0.5
    api_retry_max_delay_s: float = 8.0
    skills_dir: Path = field(
        default_factory=lambda: (
            Path(__file__).resolve().parents[3] / ".claude" / "skills"
        )
    )
    fixed_skill_ids: list[str] = field(default_factory=lambda: ["agent"])
    fixed_skill_token_budgets: dict[str, int] = field(default_factory=dict)
    fixed_skill_chars_per_token: float = 4.0
    fixed_skill_total_max_chars: int = 220_000
    prefix_max_chars: int = 220_000
    context_summary_max_chars: int = 8_000
    user_message_max_chars: int = 12_000
    tool_output_max_chars: int = 10_000
    context_hard_max_tokens: int = 1_000_000
    prompt_cache_retention: str = "24h"

    trace_enabled: bool = True
    trace_preview_max_chars: int = 4_000
    activity_summary_enabled: bool = True
    activity_summary_max_events: int = 6
    activity_summary_min_interval_s: float = 1.5

    @classmethod
    def from_env(cls) -> AgentConfig:
        """Build config from env for deployed agents and local tuning.

        The agent runs in several contexts: local development, tests, and hosted
        backends. The env surface is intentionally limited to deployment-facing
        concerns such as credentials, model selection, and coarse timeouts.
        """
        from atopile.agent.orchestrator_helpers import (
            _parse_fixed_skill_token_budgets,
        )

        # Load the app-root .env (if present) so API keys are available.
        _load_app_root_env()

        fixed_skill_ids = ["agent"]
        return cls(
            base_url=_env("ATOPILE_AGENT_BASE_URL", "https://api.openai.com/v1"),
            model=_env("ATOPILE_AGENT_MODEL", "gpt-5.4"),
            summary_model=_env("ATOPILE_AGENT_SUMMARY_MODEL", "gpt-4.1-nano"),
            api_key=os.getenv("ATOPILE_AGENT_OPENAI_API_KEY")
            or os.getenv("OPENAI_API_KEY"),
            timeout_s=_env_float("ATOPILE_AGENT_TIMEOUT_S", "120"),
            summary_timeout_s=_env_float(
                "ATOPILE_AGENT_SUMMARY_TIMEOUT_S", "8", lo=1.0, hi=30.0
            ),
            max_tool_loops=_env_int("ATOPILE_AGENT_MAX_TOOL_LOOPS", "240"),
            max_turn_seconds=_env_float(
                "ATOPILE_AGENT_MAX_TURN_SECONDS", "7200", lo=30.0, hi=7_200.0
            ),
            fixed_skill_ids=fixed_skill_ids,
            fixed_skill_token_budgets=_parse_fixed_skill_token_budgets(
                _env(
                    "ATOPILE_AGENT_FIXED_SKILL_TOKEN_BUDGETS",
                    "agent:10000",
                ),
                default_skill_ids=fixed_skill_ids,
            ),
            trace_enabled=_env("ATOPILE_AGENT_TRACE_ENABLED", "1").strip().lower()
            not in _TRACE_DISABLE_VALUES,
            activity_summary_enabled=_env("ATOPILE_AGENT_ACTIVITY_SUMMARY_ENABLED", "1")
            .strip()
            .lower()
            not in _TRACE_DISABLE_VALUES,
        )
